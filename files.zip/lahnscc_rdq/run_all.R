# =============================================================================
# LA-HNSCC RDQ (VeevaRIO 338681) - run from the project root: source("run_all.R")
# =============================================================================
source("R/00_setup.R")          # parameters, connection, source tables
source("R/01_table1.R")         # study population, Table 1, chemo date check
source("R/02_seer_compare.R")   # Flatiron vs SEER (skipped if no SEER table)
