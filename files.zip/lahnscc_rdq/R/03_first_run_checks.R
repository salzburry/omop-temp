# =============================================================================
# 03_first_run_checks.R : one-off checks for the open questions (prints only)
# =============================================================================
# Run once after run_all.R, in the same R session:  source("R/03_first_run_checks.R")
# Nothing is written; the outputs of run_all.R are unchanged.
# =============================================================================
options(width = 200)                           # print the wide tables on one line

# 1. Surgery group by whether the patient has a primary-surgery record
#    (patients without one go to no_surgery_group)
with_record <- unique(fetch("surgery", surgerytype)$patientid)
surg_rec <- table(`Surgery group` = ads$surg_group,
                  `Primary-surgery record` = ifelse(ads$patientid %in% with_record, "Yes", "No"))
message("\n1. Surgery group by primary-surgery record:"); print(surg_rec)

# 2. Stage edition: HPV-positive oropharynx at stage IVA/IVB exists only in
#    AJCC 7th edition (the 8th has no IVA/IVB for HPV-positive oropharynx).
opc <- ads %>% inner_join(fetch("cohort", primarysite), by = "patientid") %>%
  filter(norm(primarysite) == "oropharynx")
message("\n2. Oropharynx: HPVStatus x GroupStage")
print(table(HPV = opc$hpvstatus, GroupStage = opc$groupstage, useNA = "ifany"))

# 3. Patients removed by the C11/C12 (ICD-9 147 / 148.1) exclusion
excl_site <- src("cohort") %>% filter(patientid %in% !!unique(excluded$patientid)) %>%
  select(patientid, primarysite) %>% collect()
message("\n3. Excluded for C11/C12: ", nrow(excl_site), " patient(s); their PrimarySite and codes:")
excl_codes <- count(distinct(excluded, patientid, code = toupper(diagnosiscode)), code, name = "patients")
print(as.data.frame(count(excl_site, primarysite, name = "patients")), row.names = FALSE)
print(as.data.frame(excl_codes), row.names = FALSE)              # a patient can have several codes

# 4. Radiation courses against Table 1's first-course window, placed exactly as
#    01 does (a month/year-only start date must lie wholly inside the window)
rt_chk <- fetch("radiation", rtstartdate, rtstartdategranularity, rtsite) %>%
  inner_join(fc_end, by = "patientid") %>%
  mutate(start = as.Date(rtstartdate), g = toupper(coalesce(trimws(rtstartdategranularity), "DAY")),
         lo = case_when(g == "YEAR" ~ floor_date(start, "year"), g == "MONTH" ~ floor_date(start, "month"),
                        TRUE ~ start),
         hi = case_when(g == "YEAR" ~ ceiling_date(start, "year", change_on_boundary = TRUE) - 1,
                        g == "MONTH" ~ ceiling_date(start, "month", change_on_boundary = TRUE) - 1,
                        TRUE ~ start),
         win_lo = dx_date - rt_lookback_days,
         site_ok = norm(coalesce(rtsite, "Unknown/not documented")) %in% rt_sites,
         position = case_when(!site_ok ~ "Distant site (not counted)",
                              is.na(start) ~ "No start date",
                              is.na(dx_date) ~ "No diagnosis date",
                              hi < win_lo ~ sprintf("More than %d days before diagnosis", rt_lookback_days),
                              !is.na(fc_end) & lo >= fc_end ~ "After end of first course",
                              lo < win_lo | (!is.na(fc_end) & hi >= fc_end) ~
                                "Month/year date crosses a window edge (not counted)",
                              TRUE ~ "Inside window"))                # = counted in Table 1
message("\n4. Radiation courses by position:")
print(as.data.frame(count(rt_chk, position, name = "courses")), row.names = FALSE)
rt_pat <- rt_chk %>% group_by(patientid) %>%
  summarise(site_ok = any(site_ok), inside = any(position == "Inside window"))
message("Patients with primary/unknown-site RT but none inside the window (counted No): ",
        sum(rt_pat$site_ok & !rt_pat$inside))
message("Patients with a course inside the window: ", sum(rt_pat$inside),
        " (Table 1 radiation Yes: ", sum(ads$radiation == "Yes"), ")")
