# =============================================================================
# 03_first_run_checks.R : one-off checks for the open questions (prints only)
# =============================================================================
# Run once after run_all.R, in the same R session:  source("R/03_first_run_checks.R")
# Nothing is written; the outputs of run_all.R are unchanged.
# =============================================================================
options(width = 200)                           # print the wide tables on one line

# 1. What is in the Unresected column: "lymph node dissection only" (the RDQ
#    definition) or no primary-surgery record at all (counted as Unresected
#    by no_surgery_group)?
with_record <- unique(fetch("surgery", surgerytype)$patientid)
unresected_split <- ads %>% filter(surg_group == "Unresected") %>%
  mutate(source = ifelse(patientid %in% with_record, "Lymph node dissection only", "No primary-surgery record")) %>%
  group_by(source) %>%
  summarise(patients = n(), chemo_yes_pct = round(100 * mean(chemo == "Yes"), 1),
            radiation_yes_pct = round(100 * mean(radiation == "Yes"), 1)) %>%
  mutate(pct_of_unresected = round(100 * patients / sum(patients), 1), .after = patients)
message("\n1. Unresected column by source:"); print(as.data.frame(unresected_split), row.names = FALSE)

# 1b. The no-surgery patients in more detail, beside the other columns.
#     Signs that a surgery was not recorded: an ADJUVANT or NEOADJUVANT drug
#     line, or first-course RT at a postoperative dose (60 to <66 Gy; definitive
#     RT is usually 70 Gy). Salvage surgery comes after the first course, so it
#     does not move a patient out of Unresected (SEER first course).
#     RT courses are placed against Table 1's window exactly as 01 does (a
#     month/year-only start date must lie wholly inside it); used again in 4.
opt_tbl <- function(pattern) {                 # optional table; NULL if not exactly one match
  t <- schema_tables[grepl(paste0("_", refresh, "$"), tolower(schema_tables))]
  t <- t[grepl(pattern, sub(paste0("_", refresh, "$"), "", tolower(t)))]
  if (length(t) == 1) tbl(con, in_schema(schema, t)) %>% rename_with(tolower) else NULL
}
opt_ids <- function(pattern, ...) {
  t <- opt_tbl(pattern)
  if (is.null(t)) return(NULL)
  t %>% filter(patientid %in% !!ids) %>% select(patientid, ...) %>% collect()
}
rt_chk <- fetch("radiation", rtstartdate, rtstartdategranularity, rtsite, rttotaldosage, rtdosageunit) %>%
  inner_join(fc_end, by = "patientid") %>%
  mutate(start = as.Date(rtstartdate), g = toupper(coalesce(trimws(rtstartdategranularity), "DAY")),
         lo = case_when(g == "YEAR" ~ floor_date(start, "year"), g == "MONTH" ~ floor_date(start, "month"),
                        TRUE ~ start),
         hi = case_when(g == "YEAR" ~ ceiling_date(start, "year", change_on_boundary = TRUE) - 1,
                        g == "MONTH" ~ ceiling_date(start, "month", change_on_boundary = TRUE) - 1,
                        TRUE ~ start),
         win_lo = dx_date - rt_lookback_days,
         site_ok = norm(coalesce(rtsite, "Unknown/not documented")) %in% rt_sites,
         position = case_when(!site_ok ~ "Distant site (not counted)",
                              is.na(start) ~ "No start date",
                              is.na(dx_date) ~ "No diagnosis date",
                              hi < win_lo ~ sprintf("More than %d days before diagnosis", rt_lookback_days),
                              !is.na(fc_end) & lo >= fc_end ~ "After end of first course",
                              lo < win_lo | (!is.na(fc_end) & hi >= fc_end) ~
                                "Month/year date crosses a window edge (not counted)",
                              TRUE ~ "Inside window"),                # = counted in Table 1
         # cGy/cGyE by unit; with any other unit a value above 100 is cGy (no course gives 100 Gy)
         dose = suppressWarnings(as.numeric(rttotaldosage)),
         gy = ifelse(grepl("^cgy", norm(rtdosageunit)) | dose > 100, dose / 100, dose))
rt_dose <- rt_chk %>% filter(position == "Inside window") %>% group_by(patientid) %>%
  summarise(gy = if (all(is.na(gy))) NA_real_ else max(gy, na.rm = TRUE), .groups = "drop")
any_rt  <- unique(rt_chk$patientid)                            # any RT record, any time or site
lines   <- drugs %>% mutate(s = toupper(norm(linesetting)))
salvage <- opt_ids(paste0(hnc, "_?salv"), salvagesurgerytype)
tstage  <- opt_ids(paste0(hnc, "_?deep"), tstage)
cols <- c("No surgery record", "LND only", "Resected", "Unknown")
detail <- ads %>%
  left_join(fetch("cohort", primarysite), by = "patientid") %>%
  left_join(rt_dose, by = "patientid") %>%
  mutate(column = factor(case_when(!patientid %in% with_record ~ "No surgery record",
                                   surg_group == "Unresected" ~ "LND only", TRUE ~ as.character(surg_group)), cols),
         treatment = factor(case_when(
           chemo == "Yes" & radiation == "Yes" ~ "Chemo + RT",
           radiation == "Yes" ~ "RT, no chemo", chemo == "Yes" ~ "Chemo, no RT",
           patientid %in% c(drugs$patientid, any_rt) ~ "Neither (other drug/RT records only)",
           TRUE ~ "No drug or RT record at all"),
           c("Chemo + RT", "RT, no chemo", "Chemo, no RT", "Neither (other drug/RT records only)",
             "No drug or RT record at all")),
         drug_line = factor(case_when(patientid %in% lines$patientid[lines$s == "ADJUVANT"] ~ "ADJUVANT line",
                                      patientid %in% lines$patientid[lines$s == "NEOADJUVANT"] ~ "NEOADJUVANT line (no ADJUVANT)",
                                      TRUE ~ "Neither"),
                            c("ADJUVANT line", "NEOADJUVANT line (no ADJUVANT)", "Neither")),
         rt_dose = factor(case_when(radiation != "Yes" ~ "No first-course RT", is.na(gy) ~ "Dose not recorded",
                                    gy < 60 ~ "<60 Gy", gy < 66 ~ "60 to <66 Gy (postoperative range)",
                                    gy < 70 ~ "66 to <70 Gy", TRUE ~ "70+ Gy (definitive range)"),
                          c("<60 Gy", "60 to <66 Gy (postoperative range)", "66 to <70 Gy",
                            "70+ Gy (definitive range)", "Dose not recorded", "No first-course RT")),
         salvage = if (is.null(salvage)) "Salvage surgery table not found" else
           ifelse(patientid %in% salvage$patientid, "Yes", "No"),
         primary_site = coalesce(primarysite, "Missing"),
         t_stage = if (is.null(tstage)) "Deep diagnosis table not found" else
           coalesce(tstage$tstage[match(patientid, tstage$patientid)], "Missing"))
xt <- function(var, title) {                   # n (% of column) for each value
  t <- detail %>% count(column, value = .data[[var]]) %>% group_by(column) %>%
    mutate(cell = sprintf("%d (%.1f%%)", n, 100 * n / sum(n))) %>% ungroup() %>% select(-n) %>%
    pivot_wider(names_from = column, values_from = cell, values_fill = "0", names_sort = TRUE) %>% arrange(value)
  message("\n", title); print(as.data.frame(t), row.names = FALSE)
}
message("\n1b. Columns: ", paste0(cols, " = ", table(detail$column)[cols], collapse = "; "))
xt("treatment", "Treatment in the first course")
xt("drug_line", "Drug lines that imply surgery (any drug)")
xt("rt_dose", "First-course RT dose (largest course to the primary/unknown site)")
message("Median first-course RT dose (Gy):")
print(as.data.frame(detail %>% group_by(column, .drop = FALSE) %>%
                      summarise(median_gy = median(gy[radiation == "Yes"], na.rm = TRUE), .groups = "drop")),
      row.names = FALSE)
xt("salvage", "Salvage surgery record (after the first course)")
xt("primary_site", "Primary site")
xt("t_stage", "Clinical T stage (T4b = unresectable)")

# 2. Stage edition: HPV-positive oropharynx at stage IVA/IVB exists only in
#    AJCC 7th edition (the 8th has no IVA/IVB for HPV-positive oropharynx).
opc <- ads %>% inner_join(fetch("cohort", primarysite), by = "patientid") %>%
  filter(norm(primarysite) == "oropharynx")
message("\n2. Oropharynx: HPVStatus x GroupStage")
print(table(HPV = opc$hpvstatus, GroupStage = opc$groupstage, useNA = "ifany"))

# 3. Patients removed by the C11/C12 (ICD-9 147 / 148.1) exclusion
excl_site <- src("cohort") %>% filter(patientid %in% !!unique(excluded$patientid)) %>%
  select(patientid, primarysite) %>% collect()
message("\n3. Excluded for C11/C12: ", nrow(excl_site), " patient(s); their PrimarySite and codes:")
excl_codes <- count(distinct(excluded, patientid, code = toupper(diagnosiscode)), code, name = "patients")
print(as.data.frame(count(excl_site, primarysite, name = "patients")), row.names = FALSE)
print(as.data.frame(excl_codes), row.names = FALSE)              # a patient can have several codes

# 4. Radiation courses against Table 1's first-course window (rt_chk, built in 1b)
message("\n4. Radiation courses by position:")
print(as.data.frame(count(rt_chk, position, name = "courses")), row.names = FALSE)
rt_pat <- rt_chk %>% group_by(patientid) %>%
  summarise(site_ok = any(site_ok), inside = any(position == "Inside window"))
message("Patients with primary/unknown-site RT but none inside the window (counted No): ",
        sum(rt_pat$site_ok & !rt_pat$inside))
message("Patients with a course inside the window: ", sum(rt_pat$inside),
        " (Table 1 radiation Yes: ", sum(ads$radiation == "Yes"), ")")
