# LA-HNSCC RDQ: Flatiron Table 1

Descriptive characteristics of LA-HNSCC patients in the Flatiron "GSK Dostarlimab Locally Advanced Head & Neck Custom Data" (`clnprw_flatiron_la_hnc_use`, July 2026 delivery, data cut-off Dec 2025), in the layout of the RDQ table shell. VeevaRIO 338681; asset 61431, Dostarlimab (GSK4057190), JADE HNSCC.

## Running it

Set `DATABRICKS_PWD` in the environment, then run from the project root:

```r
source("run_all.R")
```

| File | Content |
|---|---|
| `R/00_setup.R` | Parameters (edit here), ODBC connection (DSN `RWDE`), source tables |
| `R/01_table1.R` | Study population, Table 1 variables, Table 1, chemotherapy date check |

**Outputs** go to `/mnt/artifacts/results`:
- `TFL_HNSCC_FI_RDQ_v0.1_<DDMONYYYY>.xlsx`, with these sheets:
  - Table 1;
  - Attrition;
  - Chemo date check.
- `..._table1_long.csv`: every Table 1 cell (section, label, group, n, pct), for a cell-by-cell comparison.
- `..._ads.rds`: the analysis dataset, one row per patient with every Table 1 variable.

**Source tables** are found in `SHOW TABLES` by a name pattern (`tbl_patterns` in `00_setup.R`), because GSK renames tables on load (for example `t_enh_lahnc_drg_epsode`). The run prints the tables it picked. It stops if a pattern matches no table, or more than one.

## Derivations

**Population.** The custom data already applies Flatiron's LA-HNSCC criteria. The run stops if Demographics has more than one row for a patient, or if the analysis dataset is not exactly one row per cohort patient. The RDQ adds one exclusion: any ICD-10 C11.x/C12.x diagnosis (ICD-9 147.x/148.1). The exclusion is matched on the code itself, so a missing or differently spelled code system does not matter.

| Row | Rule |
|---|---|
| Surgery group (columns) | `SurgeryType`: primary tumor resection (with or without lymph node dissection) is Resected; lymph node dissection only is Unresected; unknown/not specified is Unknown. A patient with several records takes Resected, then Unknown, then Unresected. A patient with no primary-surgery record is shown in a separate No surgery record column; setting `no_surgery_group` to "Unresected" or "Unknown" puts these patients in that column instead. |
| Sex | `BirthSex`. A row added beyond the shell holds missing values as Unknown. |
| Age | Year of diagnosis minus `BirthYear`. Mean (SD), median [IQR], and the shell's age groups. |
| Race/ethnicity | Hispanic if `Race` or `Ethnicity` is Hispanic or Latino; otherwise the non-Hispanic group from `Race`. Other Race and missing go to Other/Unknown, a row added beyond the shell. |
| Year, stage, HPV | `DiagnosisDate` year. `GroupStage` collapsed to 0–IV and Unknown. `HPVStatus` positive, negative, or Other/Unknown. |
| Chemotherapy (1L) | SEER first course. Yes if a `DrugEpisode` row has a first-course `LineSetting` (NEOADJUVANT, INDUCTION CHEMO, CONCURRENT, ADJUVANT, EARLY, RADIATION THERAPY) and its `DetailedDrugCategory` is chemotherapy. Cetuximab is not counted, whatever its `DetailedDrugCategory` (`count_cetuximab = FALSE`): SEER*Rx has coded it as biologic/immunotherapy, not chemotherapy, for diagnoses from 2013. If `DrugEpisode.EnhancedCohort` holds more than one disease setting, the run stops until `drug_cohorts` in `00_setup.R` names the LA-HNSCC value(s). |
| Radiation (1L) | Yes if an RT course goes to the primary site, or the site is unknown or missing. It must start no earlier than 30 days before diagnosis and before the end of first course. The end of first course is the earliest of first locoregional recurrence, distant recurrence and `AdvancedDiagnosisDate`. A start date known only to the month or year must lie wholly inside that window. |
| Reporting source | `PracticeType`: Academic, Community, Both, or Unknown. |

Percentages are column percentages within each surgery group. The Overall row shows each group's share of the cohort.

**Chemo date check.** This is a diagnostic only; it does not change Table 1. It counts first-course chemotherapy episodes inside or outside the radiation window. It also counts how many chemo "Yes" patients a date window would change.

## Scope of the QC

- In scope: the Table 1 and Attrition sheets. The Chemo date check sheet is a diagnostic and does not feed Table 1.
- Years of diagnosis: Flatiron's cohort criteria limit initial diagnosis to January 2019 - November 2022, so the 2023-2025 rows are 0 by design.
- `seer_file` in `00_setup.R` is used only by the SEER comparison, which is not part of this package.
- The counts are not final: an additional population restriction is under discussion, and where patients with no surgery record go is still open (`no_surgery_group`).

## Open questions

1. An additional restriction on the study population is under discussion.
2. Patients with no surgery record: shown in their own column until it is confirmed whether they belong in Unresected or Unknown.
3. "1L" read as SEER first course; EARLY lines count (by timing they fall in the first course).
4. rw-TTD is in the RDQ description ("details TBD") but not in the shell, so it is not built.
