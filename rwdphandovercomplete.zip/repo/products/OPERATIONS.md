# Operations: refresh lifecycle, QC, and TFLs

How an RWDP goes from a new data cut to a signed-off, delivered set of tables — and how git tracks
all of it. Complements `ROADMAP.md` (the build framework) with the **delivery + governance** layer.

## The lifecycle (per tumor, per refresh)

```
  new refresh (data cut)                       e.g. 2026q1 -> 2026q2
        │
        ▼
  build STAGING    databricks bundle run rwdp_build_<slug> --var <slug>_refresh=…
        │          (shared engine: validate -> preflight -> build; rows stamped spec_version+data_refresh)
        ▼
  semantic QC      engine/qc.run_qc(staged) -> engine/qc.qc_gate(report, thresholds)
        │          (null-rates, treatment catch-all rate, unmapped-stage rate, date-castability)
        ▼
  golden compare   engine/golden.run_golden(staged, reference_ads) -> golden_gate
        │          (row/cohort deltas, lotcat distributions, OS summary; either gate fails -> no publish)
        ▼
  deliverables     engine/tfl.generate(staged,…) + engine/dictionary (.md + .xlsx) + engine/dashboard
        │          (the dashboard MANIFEST contract; a REQUIRED one failing blocks publish)
        ▼
  durable ledger   engine/refresh.build_manifest(...) -> artifact_root manifest + QC  (BEFORE publish, fail-loud)
        │          (spec_version, git_commit, counts, qc+golden gates, per-deliverable status, release pointer)
        ▼
  publish          versioned + view pointer: write IMMUTABLE {final}__{refresh}__{build_id}[ __tfl_<id>]
        │          (build_id = git sha + run id/timestamp, UNIQUE PER RUN -> a rerun mints a NEW version,
        │          never overwriting a live one; a versioned-table collision fails loud). All versioned
        │          writes first, THEN swap public VIEWS — TFLs first, ADS last; THEN the one-row
        │          {final}__release pointer, which is the commit anchor and the only ATOMIC surface
        │          (one Delta INSERT OVERWRITE = one transaction across the whole set). Consumers
        │          resolve through the pointer; the views are the compatibility surface and are not
        │          atomic as a set. staging is NOT auto-dropped (see note); published_at is the
        │          pointer's stamp.
        │
        ▼
  release          promote manifest -> refreshes/<family>/<product>/<spec_version>/<refresh>.yaml (COMMIT); status: released + sign-off; tag
```

> **Consuming a release — resolve through the pointer.** `{final}__release` is a ONE-ROW table naming
> the whole current set, written by a single Delta `INSERT OVERWRITE`. Because that is one
> transaction, a reader gets the whole previous release or the whole new one and never a mixture:
>
> ```sql
> SELECT ads, tfls, build_id, published_at FROM <final>__release
> ```
>
> then read the table named in `ads` and the ones in `tfls` (JSON, `{tfl_id: table}`).
>
> The public **views** (`{final}`, `{final}__tfl_{tid}`) remain and are still swapped, for everything
> already reading them. They are NOT atomic as a set: each swap is its own DDL statement and
> Databricks has no transaction across them, so a consumer reading a TFL view directly can catch this
> build's TFL beside the previous build's ADS. Anchoring on the ADS view (swapped last) narrows that
> window; only the pointer closes it.
>
> A TFL that a later spec stops producing leaves its old public view live (the runner records these as
> `retired_tfls` and warns); retire it manually — the engine never auto-drops a consumer-readable view.
> The same manual rule covers **staging tables**: promotion never drops `{final}__staging__{build_id}`
> — they are the approved bytes a receipt's identity points back at, and an automatic drop would
> destroy the evidence the moment it stopped being needed for serving. They are build-scoped, so they
> collide with nothing; clean them up deliberately, oldest first, once their release is superseded
> and its audit bundle no longer needs the physical bytes.
> A manifest with `status: released` is guaranteed to carry `published_at` + a valid `release` block
> (validated), and its `published_at` is the pointer's own timestamp, not a second reading of the clock.

## Git architecture (refreshes tracked)

- **Spec/engine changes** → feature branch → PR → `main` (reviewed config diff; CI lints every
  tumor config + runs the pure-Python tests).
- **A refresh** (data cut only, no code change) → a `--var refresh=…` run + a committed
  `refreshes/<family>/<product>/<spec_version>/<refresh>.yaml` manifest. The manifest's `git_commit` pins the exact
  engine + spec, so the ADS is **reproducible**: checkout the tag, re-run the same config.
- **Release tag**: `release/<registry_code>/<spec_version>/<refresh>` (e.g. `release/mcrpc/202606/2026q1`) — the
  `spec_version` segment avoids cross-version collisions (see `../docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md` §G);
  none cut yet. The ADS rows carry matching `spec_version` + `data_refresh` stamps (added in `assemble`).
- **Audit**: git history of `refreshes/` is the ledger — who built/QC'd/released what, when, from
  which commit. Superseded refreshes are kept (`status: superseded`).

See `../refreshes/README.md` (+ `REFRESH_TEMPLATE.yaml`) for the manifest, and `_reporting/tfl/README.md` for TFLs.

## Side-by-side R validation (optional — NOT a governed run)

The R engine (`../platform/engine-r/`) reads the **same config** and builds the same ADS, for the
R-proficient team to cross-check the Python build. It is a **validation aid, not part of the lifecycle
above**: it has no source-QC/golden/release gates, no manifest, and no view swap — it writes the table
**directly**, so it must target a **separate `_r` schema**, never the governed `output_schema`. On a
Databricks cluster (or Domino→Databricks via sparklyr), from the repo root:

```bash
Rscript platform/engine-r/run_rwdp.R --allow_direct_write=true \
  --config_path=products/oncology/<product>/<spec_version>/config/data_product.yaml \
  --refresh=<cut> --source_schema=<src> --output_schema=<out>_r
```

Then close the loop with the **same `engine/golden.py` gate** the lifecycle uses: re-run the Python
build pointing `--var reference_table=<out>_r.<ads_table>`, so the R ADS is golden-compared against the
governed Python ADS (row/cohort counts, lotcat distribution, OS summary, column diff). `--allow_direct_write=true`
is required (fail-closed); full Domino→Databricks connection detail + caveats: `../platform/engine-r/README.md`.

## Gate 6: the promotion path

**The two-run flow is built.** A prod run stages a candidate and stops; a promotion run publishes
THOSE bytes and builds nothing. The approval travels through git and the deployment tree — the
sequence is spelled out in requirement 4 below. What remains outstanding is that none of this has
executed on a cluster.

    build run  (env=prod)              -> staging tables + a persisted, hashed candidate manifest,
                                          no versioned table, no public view touched
    a person signs RELEASE_APPROVAL     -> approved_build_id + approved_manifest_sha256, committed
                                          AFTER the candidate is built and validated; the REDEPLOY
                                          carries it into the runtime tree (new tree digest — expected)
    promotion run  (promote_build_id=A) -> reads the approval from the DEPLOYED TREE, verifies it
                                          names A + A's manifest digest, materialises A's versioned
                                          tables from A's staging, swaps the public views, mints nothing

**Why it could not complete before.** `build_id` is `{commit}_{job.run_id}` and `built_at` is stamped
per execution, so every run had a new identity and a new manifest digest. An approval naming build A
was unsatisfiable by run B, and no path resumed A. `promote_build_id` is that path: it ADOPTS the
build id rather than minting one, so every downstream name — staging tables, artifact dir, manifest —
is A's.

**What it refuses, and why each matters.** `release.promotion_blockers` answers the physical half
that no paperwork can: the staged bytes must still exist (gone means a rebuild would be a different
candidate wearing an approval), the versioned table must NOT already exist (immutable, and a public
view may already serve it), and the staged bytes must be THE APPROVED ONES. `publish_approval_errors`
answers Gate 6, and the block separately re-asserts `may_publish` — running before the build means it
does not inherit the validate-only stop, and Gate 6 alone would have let a pack failing Gates 1–4
publish on a hand-written approval.

**A candidate is not a table name.** The first two refusals both ask which names exist in the output
schema, and an approval that binds a name is satisfied by a table with that name holding different
rows. So the candidate run probes each staged table — `DESCRIBE HISTORY … LIMIT 1`,
`DESCRIBE DETAIL`, then `COUNT(*) … VERSION AS OF` the version it just read — and records
**Delta table id, version and row count** in `manifest.candidate_identity` *before* the digest is
taken, putting the physical facts inside what the approver signs. The promotion run re-probes and
refuses any table whose id, version or row count has moved.

The **table id** is why a version alone is not enough: drop the staging table, create it again and
write the same rows, and the replacement can carry the same version with a different transaction log
behind it — `VERSION AS OF` would resolve against a table nobody approved while every number agreed.
`num_files` and `size_bytes` are recorded and deliberately **not** compared: an `OPTIMIZE` changes
both without changing a row, and a gate that refused compaction would be routed around; the version
moves for it anyway, which is the honest signal.

**Whole or not at all.** The expected staging set is derived from the promotion plan, and it must
equal the recorded set and the observed set. A candidate signed over the ADS with one TFL's probe
missing is refused — not published with the measured half pinned and the unmeasured half taken from
live staging. There is no unpinned materialise: `materialise_sql` raises without a version rather
than emitting SQL, so the fallback that made partial evidence dangerous cannot be reached.

**Pinned, not merely checked.** The blockers read the version and the `CREATE TABLE … AS SELECT`
reads the table — two reads with a gap, and a write landing in that gap would be published with the
check's blessing. The materialise names the approved version (`… FROM {staging} VERSION AS OF {n}`),
so what is published cannot be anything else. After every table is materialised and **before the
first view swaps**, each versioned table's row count is compared to the approved count; a mismatch
aborts with the previous release still being served.

**Fail closed on absence.** A candidate manifest with no `candidate_identity` — one written before
this existed, or one whose probe failed — cannot be verified after the fact and is refused. Unstated
is not unchanged.

**An interrupted promotion resumes.** Promotion used to perform three side effects — materialise,
swap, receipt — with nothing recorded between them, so every gap was a state a retry could not tell
from the others, and the blanket "already promoted" refusal then stopped the retry *for having got
part of the way*. The operator's instruction was "drop the versioned tables by hand", which is wrong
once a public view points at one.

Intent is now written to `<artifact_root>/promotion_state.yaml` **before the first side effect**, and
each completed stage is recorded:

```
prepared → materialised → views_switched → receipted
```

A retry reads the journal and continues. What it buys is a distinction nothing else can reconstruct:
a versioned table *this* promotion made and did not finish, versus one belonging to somebody else's
release. `reconcile` classifies every existing target as **absent** (still to do), **present with the
approved row count** (a completed step — skipped, never dropped and remade), or **present with the
wrong count** (a partial write — refused, with advice that differs by state, because whether it is
safe to drop depends on whether a view has been pointed at it). The swaps are never skipped:
`CREATE OR REPLACE VIEW` is idempotent, and working out which views a crashed run reached would be a
second, fallible answer to a free question.

**The release set is published atomically.** Swapping the public views is N separate DDL statements
and Databricks has no transaction across them, so a consumer reading a TFL view directly could see
this build's TFL beside the previous build's ADS. The fix is a one-row `{final}__release` table
written by a single Delta `INSERT OVERWRITE` — one transaction — which a consumer resolves the whole
set through. It is written LAST, after every view, so it keeps one commit-anchor concept: the release
is published when the pointer says so, and `published_at` is the pointer's own timestamp.

That the write really is one transaction is not assertable offline; scenario 12 asserts it against
Delta by publishing two releases and reading the pointer's own version history, finding that every
version holds one COMPLETE set and none pairs one build's ADS with another's TFLs. The pointer is
also read back before the receipt: a pointer naming the wrong release is worse than no pointer,
because it is the one place a consumer is told to trust over the views.

**One promotion per product at a time.** Two promotions interleaving their view swaps leave the
public set mixed — one run's TFL beside another's ADS — with each believing it published a consistent
release. The swap order (TFLs, then the ADS as the commit anchor) bounds what a consumer sees within
*one* run and says nothing about two. The mutex is a table CREATE: `{public ADS}__promotion_lock`,
taken before anything a concurrent run could move and dropped only after the receipt is durable. The
metastore refuses a name that exists — verified against Delta, not assumed — so exactly one caller
wins and the loser sees a refusal naming the holder, its actor and when it was taken.

There is deliberately **no lease and no timeout**: a lock that expired mid-swap would permit exactly
the interleaving it exists to prevent. A stale lock is a person's decision, and the row says whose. A
**resuming run re-enters its own lock**, because a lock that refused its owner would make every crash
need a person before the resume could run — turning a recoverable state back into an outage.

**A late promotion cannot move the public views backwards.** Nothing bound a promotion to the state
of the world it was approved against: build A is staged and signed, build B is built, approved and
published while A waits, and A is then promoted — moving every consumer onto older data with every
check passing, because A's bytes really are the bytes A's approver signed. The approval was never
wrong; it was never *about* the release it would replace.

So the candidate run records what the public views serve, in `manifest.supersedes`, **before the
digest is taken** — the approver signs which release is being replaced. Promotion re-reads and
refuses a difference. It is a compare-and-set, so it needs no clock and no ordering between build
ids, and it catches a newer release, a rollback somebody did by hand, and a view repointed at another
product's table as the same event. `None` is a real value meaning "no release yet", so a product's
first promotion is not refused forever. **A deliberate rollback is its own approved operation** — a
new candidate approved against the release that is actually live — not a side effect of a late
promotion.

**The grant this cannot make for itself.** A versioned table is immutable by *convention*: nothing in
this code stops a sufficiently privileged identity dropping or overwriting one, and the promotion
lock is a table that identity could also drop. Restricting `MODIFY`/`DROP` on the output schema to
the release job's principal is a Unity Catalog grant and belongs with whoever administers the
catalog. Everything above narrows what a *correct* operator can do by accident; none of it constrains
one who is not.

Three guards on the journal itself: it must name **this** build and **this** approved digest —
resuming another would finish somebody else's promotion under this run's approval — and `advance` is
**forward-only**, so a retry that re-ran a recorded stage cannot walk the state backwards and make
the next retry redo finished work. Held by
`test_an_interrupted_promotion_resumes_instead_of_becoming_unrecoverable` and, against real Delta,
by scenarios 8 and 9 of the promotion smoke test.

**Materialise everything, then swap.** A failure among the tables leaves the public names on the
previous release rather than on half of this one; within the swap, TFLs first and the ADS last, the
same commit anchor a build-and-publish run uses — and literally the same `swap_plan`.

**Design note, against requirement 1 below.** The versioned table is created at PROMOTION, not at
candidate time. Requirement 1 asked for it at candidate time, and the runner's own reasoning argues
the other way: a run that has not been approved must not leave release-NAMED objects behind, or a
later reader cannot tell "this build was validated" from "a release was prepared and abandoned".
Staging is already build-scoped (`staging_ads` is `{final}__staging__{build_id}`), so the candidate's
bytes are as durable as a versioned table would be, without claiming to be a release. Requirement 1
is therefore **not** implemented as written, deliberately.

**The SQL is executed — on open-source Delta, not on a cluster.**
`platform/tests/test_delta_promotion_spark.py` runs fourteen scenarios against real Delta tables in the
`spark` CI job: the probe reads Delta's id, version, count, format, files and size; an untouched
candidate materialises pinned and its views swap; a second promotion is refused; a write after
approval is refused **and the pinned read still yields the approved rows, not the current ones**; a
drop-and-recreate at the same version and row count is refused on `table_id`; a candidate signed over
part of its tables is refused; the materialised table carries the approved row count; a promotion
interrupted after one table resumes and completes; a partial write from an interrupted attempt is
refused with state-aware advice; the promotion lock is a real mutex that a build re-enters for its own
resume; a candidate approved against an older release is refused, read from live views; every version
of the release pointer holds one COMPLETE release set; and a consumer resolves the whole set through
the pointer with every table it names present.

That suite has already paid for itself three times. It caught the defect that shipped — the probe
wrapping `DESCRIBE HISTORY` in a `SELECT` subquery Databricks does not permit, which would have
raised on first contact while the runner swallowed it and printed approval instructions for a
candidate that could never be promoted. It caught `DESCRIBE DETAIL`'s column names, read from
documentation, where a wrong name returns `None` and every downstream comparison becomes vacuously
equal. And on its first run it caught an `_existing` set that read one side of each pair, so the
"already promoted" refusal had nothing to fire on.

**What is still not proven.** Open-source Delta with a local Hive-style catalog is not Unity Catalog:
three-level namespaces, permissions, `logRetentionDuration` expiring a pinned version, and cluster
behaviour under concurrency are all untested. **No promotion has run on a Databricks cluster.** Until
one has, the honest claim is *"the mechanism is executed and correct on Delta; the deployment is
not"*. Do not use this path for a governed release.

**The runtime the suite tests is not the runtime the docs target.** The `spark` CI job pins
pyspark 4.0.1 with delta-spark 4.0.0 (Spark 4 / Delta 4); a Databricks Runtime target such as DBR
15.4 LTS runs Spark 3.5 with Databricks' own Delta. The SQL this module emits is deliberately
conservative, but "passes on Spark 4" is not "passes on the cluster" — the SIT run on the actual
DBR/Unity target is what closes that gap, and the promotion receipt now records the deployment it
actually ran on (`deployment: {spark_version, databricks_runtime}`) so an auditor can see which
runtime a release came from rather than assuming.

**Three runtime pins are weaker than this repository's own standards — known, and open.**
(1) `resources/products.yml` pins `spark_version: 15.4.x-scala2.12` — a MOVING pin: the `.x`
resolves to whatever maintenance release Databricks serves that day, so two runs of one commit can
execute on different runtimes. The receipt's `deployment` block makes that detectable after the
fact; only an exact version makes it impossible. (2) The job clusters set
`data_security_mode: SINGLE_USER` but carry no `policy_id`, so nothing constrains what a redeploy
may change about the compute a governed release runs on. (3) CI's Python dependencies are
VERSION-pinned but not hash-pinned (`--require-hashes`); a version pin trusts the index to serve
the same bytes for the same version. Each is a deployment decision — which exact DBR the
organisation has validated, which policy governs its compute — so each is named here rather than
guessed at in code.

**Known and not yet closed:**

* **The public VIEWS are still not atomic as a set.** The one-row `{final}__release` pointer is, and
  is what a consumer should resolve through; the views remain as the compatibility surface for
  everything already reading them, and a direct TFL-view reader can still catch a mixed set during a
  swap. Removing the views would break consumers to fix a race they may not have.
* **The swap is not atomic across ADS and TFLs.** Databricks DDL is not transactional across
  statements. TFLs-first-ADS-last bounds the damage; it does not remove it. The `release_pointer`
  record is the data a single-row pointer would need if consumers resolved through one.
* **Versioned tables are immutable by convention, not by permission.** A sufficiently privileged
  identity can still drop or overwrite one. That is a Unity Catalog grant, not a code change — see
  "The grant this cannot make for itself" below.

**The original three properties, for the record:**

| | requirement |
|---|---|
| 1 | **DONE, by a different mechanism than it asked for — see the design note above.** The candidate must SURVIVE the run *unchanged*. Durability was already there: `staging_ads` is build-scoped, so no later run overwrites it. What was missing was the second half — nothing established that the surviving table still held the approved rows, because the approval bound a NAME. The candidate run now records each staged table's Delta version and row count in `manifest.candidate_identity` before the digest is taken, and promotion re-probes, refuses a mismatch, and reads `VERSION AS OF` the approved version. Requirement 1 asked for the versioned table to be written at candidate time; that is still declined, and for the original reason — it would put release-named objects in the output schema for a build nobody approved. Held by `test_a_candidate_is_pinned_to_its_BYTES_and_not_to_a_table_NAME`. |
| 2 | **DONE.** The approval must bind to the PERSISTED bytes. The digest used to be taken over the manifest *before* a `release_approval` block was added and the file put again — so `manifest.yaml` on disk did not hash to the value the approver was told to sign, and a promotion step verifying the file would have rejected the build the approval named. The candidate is now serialized ONCE into `_persisted`, written and hashed from that same string, and never rewritten: the stop is recorded in a sibling `release_candidate.yaml`. Held by `test_the_approved_digest_and_the_persisted_candidate_are_the_same_bytes`, which reads the runner through `ast` rather than by substring — the block explains this failure in a comment, so a text scan would be satisfied by the description of the bug. |
| 3 | **DONE.** Promotion must not rebuild. `promote_build_id` adopts that build id, reads the persisted candidate manifest and hashes it, verifies `may_publish` + `publish_approval_errors` + `promotion_blockers` against it, materialises the versioned tables from staging, swaps, and writes a SIBLING `published_manifest.yaml` — the candidate manifest is the subject of the approval, so rewriting it would break the binding just verified. The block cannot reach `build()`, and a governance test asserts that rather than trusting it. |
| 4 | **DONE.** The approval must be READABLE from where the run executes. `publish_approval_errors(root, rel, …)` opens `<runtime root>/<pack>/handoff/RELEASE_APPROVAL.yaml` — the DEPLOYED REPO TREE, at promote time. Under `--evidence-out DIR` the whole audit bundle — that file included — used to land in DIR and never enter the tree, so the runner looked where the file was not; `deploy_tree.RUNTIME_EVIDENCE` now deploys it into the tree either way (and still archives it), which is safe unlike the rest of the bundle because it holds no source-provenance prose: six fields, each a name, a date, a build id or a digest. The sequence follows from a tree being digest-bound — the approval names a build produced by a run OF a deployment, so it cannot exist when that deployment is packaged — and is adopted as: **candidate run → the approval is committed AFTER the candidate is built and validated → REDEPLOY (new `tree_sha256`) → promotion run**. The promotion run's tree digest differing from the candidate's is EXPECTED and harmless: the binding is **approval content → candidate identity** — `approved_build_id` + `approved_manifest_sha256`, verified against the candidate manifest persisted in `artifact_root`, which no redeploy touches — never tree digest → candidate. Each deployment proves only its own consistency (`evidence_verdict` over its own `RELEASE_EVIDENCE`, commit and recomputed digest), and nothing compares the promotion tree's digest to the candidate's; the gates the new tree re-evidences are about the PACK, and the approval carries the run-specific half across the redeploy. The alternative — reading the approval from `artifact_root` beside `manifest.yaml` — was not taken: the approval is a governed record, and `handoff/` in git is where every other gate's approval lives and is reviewed; a volume file would be signable outside version control. |

Two constraints that are easy to get wrong, and were:

- **Gates 1–4 come from `RELEASE_EVIDENCE.yaml` in prod, not from a live `releasable()`.** The
  allowlisted tree deliberately omits the Gate 1 material a live evaluation needs, so re-deriving
  fails for the reason the packaging exists to create.
- **The manifest status must stay inside `engine.refresh.STATUSES`.** `validate_manifest` rejects
  anything else, and it already requires `sign_off.released_by` for `status: released` — the
  vocabulary for a named releaser has existed all along.

`handoff/RELEASE_APPROVAL.yaml` is in `deploy_tree.PACK_EVIDENCE` (it reaches the audit bundle) AND
in `deploy_tree.RUNTIME_EVIDENCE` (it is deployed into the runtime tree, which is where the promotion
run reads it — see requirement 4). `source_manifest.publish_approval_errors` is the check and is
tested offline; what is untested is the Databricks control flow, which is exactly the part that
production SIT has to prove.

## What's built vs next

- **Built + tested (pure-Python cores):** refresh manifest build/validate/**write** + `artifacts`
  (`engine/refresh.py`); the **source QC gate** + ADS QC gate + thresholds + **QC report**
  (`engine/qc.py`, `engine/qc_report.py`); the **data dictionary** per neutral audience —
  internal/partner/customer, `partner` replacing the old "sales", with PII drop + `.xlsx`
  (`engine/dictionary.py`); the TFL spec + producibility planner + **product-limit KM** table
  (`engine/tfl.py`); all with catalog cross-checks.
- **R cross-validation engine** (`engine-r/`): a side-by-side R implementation on the **same
  config/YAML**, for the R-proficient team to validate logic and cross-check the build. The
  config→Spark-SQL compilers are **proven byte-identical** to PySpark in CI
  (`tests/test_r_parity.py`); the sparklyr build is review-only and its **acceptance gate is the
  golden-compare** of the R ADS vs the Python ADS (`engine/golden.py`). See `engine-r/README.md`.
- **Runner wired end-to-end** (`databricks/run_rwdp.py`, Spark/cluster-only): preflight →
  **source-QC gate** → build → staging → **ADS QC gate + golden gate** (either failing keeps
  staging, no publish) → **required deliverables** (dictionary + TFLs, each required/optional/skip
  per the config `deliverables:` block; a **required** one that fails blocks publish, status
  recorded) → **durable release ledger** (manifest + QC report written to `artifact_root`,
  **fail-loud**) → **temp-then-swap publish**. The ledger is written BEFORE the swap so a publish
  can never happen without a durable record; `artifact_root` is **writability-probed up front**
  (hard-fail in prod, warn in dev). The pre-swap manifest carries `published_at: null`; it is stamped
  with `published_at` and re-written only AFTER a successful swap, so a null `published_at` can never
  be mistaken for a successful publish. The manifest carries the full source-QC **report + gate**, the
  **golden gate**, and per-deliverable status. A **promote** step commits the manifest from
  `artifact_root` into `refreshes/` (a job can't push to git). Spark execution
  (`run_qc`/`run_golden`/`tfl.generate`/stages) is cluster-only.
- **Next (a lot more):**
  - confirm a first end-to-end cluster run (the bundle has notifications + UC + temp-swap; retries are
    disabled — deterministic QC/golden/source-QC gate failures should not be re-run blindly);
  - figures (KM curve render) + listings export in `tfl.generate`; per-tumor TFL overlays;
  - extend proven R↔Python parity to the inline clinical/OS SQL (death imputation, OS anchor) — see
    `engine-r/README.md` "Next";
  - tumor-class modules (heme Ann Arbor/IPI/Lugano-EFS) — `ROADMAP.md` Phase 7;
  - access control / PII suppression on dashboard + listings.
