#!/usr/bin/env python3
"""The source-preflight SQL for one pack, with every name filled in — paste-ready, no cluster.

    python3 platform/tools/source_preflight.py <pack> --refresh 2026m06 --source-schema cat.sch
    python3 platform/tools/source_preflight.py <pack> --refresh 2026m06 --source-schema cat.sch --sql-only

WHY THIS EXISTS. `DEV_SMOKE.md` already carries the right questions, and every one of them contains
`<source_schema>` and `<refresh>`. That is a dozen hand-substitutions on the morning of the first
real-data run, each of which can be got wrong quietly — and the queries are the cheapest failure to
hit, so getting them wrong is expensive in exactly the wrong place. This resolves the names from the
pack's own config and prints the SQL as you would run it.

IT ALSO PRINTS WHAT THE ENGINE EXPECTS BACK. A `SELECT DISTINCT biomarkername` is only useful next
to the list the derivations actually branch on; without it the operator reads forty strings and has
no way to tell which matter. Every expectation here is READ FROM THE CONFIG — `biomarkers.panel[].
match_any`, `lab_values.panel[].match`, `lot_line_setting`, the cohort definitions — so it cannot
drift from what the build will do.

WHAT IT DOES NOT DO. It runs nothing, reads no vendor data, and reaches no warehouse. It is a text
generator: the operator runs the SQL in a SQL editor and compares. `engine.validate.preflight_report`
is the live version and needs a cluster and a table reader; this is the half you can do the day
before, from a laptop, with no access at all.

RESOLUTION IS THE CONFIG'S, NEVER A FORMAT STRING. Source names come from `cfg.source_fqns()` and
`cfg.table_in()` — `run.source_layout` is a documented per-product override and `{schema}` may appear
inside a physical name, so `{stem}_{refresh}` is wrong for any pack that overrides it. Under a
`source_union` one run covers ONE member; the fan-out is what preflight wants, so `source_fqns` is
the right call and `table_in` is not.

Read-only. stdlib + PyYAML.
"""
import argparse
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)
sys.path.insert(0, os.path.dirname(TOOLS))

import product_gates as pg                                                          # noqa: E402
from engine.config import load_config                                               # noqa: E402

WIDTH = 96

# The LOT setting COLUMN is a physical name the engine carries as a literal
# (`engine/stages/treatment.py` filters `F.col("linesetting") == line_setting`), while the config
# holds only the VALUE to compare it against (`lot.line_setting`). Named once, in `engine.qc` —
# where the EXECUTING check lives — and imported here, so the paste-ready SQL and the on-cluster
# gate cannot ask different columns. The first version of this file printed `SELECT DISTINCT
# mCRPC`, having read the value as though it were the column; `test_governance` still asserts the
# engine uses it.
from engine.qc import LOT_SETTING_COLUMN, source_expectations as _engine_expectations  # noqa: E402


def _binding(cfg, name, override):
    """The runtime value, or None when it is still the placeholder. Fail-closed: never emit a
    query containing `REPLACE_ME`, because it fails as "no such schema" and reads like a real
    finding about the delivery."""
    if override:
        return override
    v = str((cfg.raw.get("run") or {}).get(name, "") or "")
    return None if (not v or any(p in v for p in pg.PLACEHOLDERS_PREFIX)) else v


# display topic <- the engine's key. One derivation (`engine.qc.source_expectations`); this file
# only renames for the page.
_TOPICS = {"biomarker_names": "biomarker names", "lab_names": "lab names",
           "line_settings": "line settings"}


def expectations(cfg):
    """{topic: (what the engine branches on, where it is declared)} — the ENGINE's derivation,
    renamed for display. A second reading of the config here would drift from what the on-cluster
    gate (`engine.qc.run_source_qc`) actually checks, which is the exact disagreement this file
    exists to prevent."""
    return {_TOPICS.get(k, k): (v["expected"], v["declared_in"])
            for k, v in _engine_expectations(cfg).items()}


def blocks(cfg, refresh, source_schema):
    """[(heading, why it matters, [sql lines])] — the preflight, in the order it gets cheaper to
    fail. Existence first: a missing table makes every value query below it meaningless."""
    out = []

    fqns, unresolved = {}, []
    for name in sorted(cfg.sources):
        try:
            fqns[name] = cfg.source_fqns(name)
        except Exception as exc:                        # noqa: BLE001 — report, never guess a name
            unresolved.append(f"{name}: {exc}")

    every = sorted({f for v in fqns.values() for f in v})
    out.append((
        "1. DO THE DECLARED SOURCES EXIST FOR THIS REFRESH?",
        f"{len(every)} table(s) resolved from {len(fqns)} declared source(s). A name that differs "
        f"here is a `formats:` overlay, NOT a config edit to the logical name — the engine only ever "
        f"sees the logical name.",
        [f"SHOW TABLES IN {source_schema};", ""] +
        [f"DESCRIBE TABLE {f};" for f in every]))

    exp = expectations(cfg)
    val = []
    if "line settings" in exp and "lot" in fqns:
        val += [f"-- expect these among the results: {', '.join(exp['line settings'][0])}",
                f"SELECT DISTINCT {LOT_SETTING_COLUMN} FROM {fqns['lot'][0]};", ""]
    if "biomarker names" in exp and "biomarkers" in fqns:
        bio = cfg.pack("clinical")["biomarkers"]
        val += [f"-- the derivations branch on {len(exp['biomarker names'][0])} name(s); anything "
                f"the feed spells differently is INVISIBLE, not an error",
                f"SELECT DISTINCT {bio.get('name_column')} FROM {fqns['biomarkers'][0]};", ""]
    if "lab names" in exp and "lab" in fqns:
        lv = cfg.pack("clinical")["lab_values"]
        val += [f"-- expect the {len(exp['lab names'][0])}-lab panel: "
                f"{', '.join(exp['lab names'][0])}",
                f"SELECT DISTINCT {lv.get('name_column')} FROM {fqns['lab'][0]};",
                f"SELECT DISTINCT {lv.get('unit_column')} FROM {fqns['lab'][0]};", ""]
    if val:
        out.append((
            "2. THE VALUE STRINGS THE DERIVATIONS BRANCH ON",
            "A value the feed spells differently does not fail — it silently matches nothing, and "
            "the column comes back empty or Unknown. This is the check that finds that.",
            val))

    if unresolved:
        out.append((
            "!! SOURCES THAT DID NOT RESOLVE",
            "These could not be turned into a physical name from this config. Fix before running "
            "anything else — a preflight over a partial source list is not a preflight.",
            [f"-- {u}" for u in unresolved]))
    return out


def render(pack, refresh, source_schema, sql_only=False):
    # THE PACK'S OWN CONFIG, LOADED DIRECTLY. This resolved the pack through the registry —
    # `product_config(root, slug)` — which returns the CURRENT spec version, so asking for
    # prostate/202603 or /202607 silently emitted prostate/202606's twenty tables. Worse than a
    # wrong version: 202607 has no `config/` at all and still produced a full preflight, from a
    # different pack, with nothing to say it had. `docs/ENGINEERING.md` states the rule this broke — take the
    # PACK PATH as an argument, never re-resolve an explicit pack through a registry whose
    # `current_spec_version` moves.
    conf = os.path.join(os.path.abspath(pack), "config", "data_product.yaml")
    if not os.path.exists(conf):
        raise SystemExit(
            f"{pack}: no config/data_product.yaml — there is no source list to preflight. A pack "
            f"before its config stage has nothing here to check, and answering from another pack's "
            f"config is how a preflight comes to describe a product nobody asked about.")
    cfg = load_config(conf)
    if refresh:
        cfg.raw.setdefault("run", {})["refresh"] = refresh
    if source_schema:
        cfg.raw.setdefault("run", {})["source_schema"] = source_schema
    refresh = _binding(cfg, "refresh", refresh)
    source_schema = _binding(cfg, "source_schema", source_schema)
    if not refresh or not source_schema:
        missing = [n for n, v in (("--refresh", refresh), ("--source-schema", source_schema)) if not v]
        raise SystemExit(
            f"{pack}: {' and '.join(missing)} not supplied and the config still holds the "
            f"placeholder. REFUSING to emit SQL — a query against a schema called REPLACE_ME fails "
            f"as 'no such schema', which reads like a finding about the delivery rather than a "
            f"missing argument. Pass them, or fill run.* in the pack's config.")

    B = blocks(cfg, refresh, source_schema)
    if sql_only:
        return "\n".join(l for _h, _w, lines in B for l in lines)

    L = ["", "=" * WIDTH, "  SOURCE PREFLIGHT — " + pack, "=" * WIDTH,
         f"  refresh={refresh}   source_schema={source_schema}",
         "  Run these in a SQL editor BEFORE a cluster starts. Nothing here is run by this tool,",
         "  and no vendor data is read to produce it.", ""]
    for heading, why, lines in B:
        L += ["-" * WIDTH, "  " + heading, "-" * WIDTH]
        L += ["  " + w for w in _wrap(why)]
        L += [""] + ["    " + l if l else "" for l in lines] + [""]
    L += ["-" * WIDTH,
          "  WHAT AN ANSWER CHANGES. A physical NAME that differs is a `formats:` overlay plus",
          "  `run.data_format` — never an edit to the logical name the engine reads. A VALUE that",
          "  differs is a config edit to the panel or codelist that branches on it. Neither is a",
          "  guess: set it from what these queries returned, and record the evidence.", ""]
    return "\n".join(L)


def _wrap(text, width=WIDTH - 4):
    words, line, out = text.split(), "", []
    for w in words:
        if len(line) + len(w) + 1 > width:
            out.append(line)
            line = w
        else:
            line = (line + " " + w).strip()
    return out + ([line] if line else [])


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack", help="the pack directory")
    ap.add_argument("--refresh", help="the delivery suffix, e.g. 2026m06")
    ap.add_argument("--source-schema", dest="source_schema", help="catalog.schema of the delivery")
    ap.add_argument("--sql-only", action="store_true", help="emit only the SQL, for piping to a file")
    a = ap.parse_args(argv)
    if not os.path.isdir(a.pack):
        sys.exit(f"{a.pack}: not a directory")
    print(render(a.pack, a.refresh, a.source_schema, a.sql_only))
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
