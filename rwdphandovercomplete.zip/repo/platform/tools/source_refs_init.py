#!/usr/bin/env python3
"""Write a pack's FIRST source_refs.yaml — the Gate 1 registration — from a human's classification.

    python3 platform/tools/source_refs_init.py products/oncology/mcrc/YYYYMM \\
        --ai-classification vendor_restricted \\
        --classified-by "A. Person" \\
        --classified-date 2026-08-14 \\
        --path-or-link "TBD — workbook not yet supplied"

WHY THIS IS A TOOL AND NOT A GENERATOR. Everything in a new pack's source_refs.yaml is derivable
except three fields, and those three are the whole point of the file:

  * `ai_classification` decides what AI may read AT ALL. The template says it in as many words —
    "a human act of authority: it must NOT be inferred from the filename, the folder or the role
    line". A tool that guessed it would be guessing the answer to the one question the AI boundary
    rests on.
  * `classified_by` is a NAMED person, because a classification attributed to a function is one
    nobody can be asked about. `person_rules.not_a_person` refuses a team or a bare acronym, and
    is honest that it cannot tell a real name from an invented one — which is exactly why the name
    has to come from a person at a keyboard rather than from a program with a template.
  * `classified_date` pins the call to a revision, because provenance changes underneath a document.

So this tool REQUIRES all three as arguments and supplies no default for any of them. It composes
the rest — product code and spec_version from the pack path and the registry, the pending-material
body, the `why_provisional` sentence Gate 1 asks for — validates the result against
governance/schemas/source_refs.schema.json BEFORE writing, and then runs Gate 1 over the pack and
prints what it said. What it will not do is invent a judgement or sign one.

It also REFUSES TO OVERWRITE. An existing source_refs.yaml is a registration record, possibly with
an approval on it; re-running this against a live pack must not quietly replace it.
"""
from __future__ import annotations

import argparse
import datetime
import json
import os
import re
import sys

import yaml                       # for `scalar()`: hand-quoting silently corrupted Windows paths

TOOLS = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import person_rules as pr        # noqa: E402
import product_gates as pg       # noqa: E402
import source_manifest as sm     # noqa: E402

SCHEMA = os.path.join(REPO, "governance", "schemas", "source_refs.schema.json")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
# The schema's own rule for spec_version. Restated here ONLY to produce a better refusal than the
# raw validator error: a pack still sitting at the literal `YYYYMM` placeholder has no spec version,
# and "which cut of the workbook does this register" is the question a registration answers first.
SPEC_VERSION_RE = re.compile(r"^[0-9]{6}$")
# The `pending` sentence Gate 1 asks for. It says what is MISSING, which is the only thing a
# provisional registration can honestly claim.
WHY = ("Not yet approved: no revision, checksum, approval date or approver recorded. The workbook "
       "has not been supplied to this pack. Fill those in and set status: reviewed once RWB's "
       "approved workbook is in hand.")

# ...AND THE SAME SENTENCE FOR A PACK WHOSE WORKBOOK IS IN HAND. The one above is written for the
# `--path-or-link TBD` case and says the workbook "has not been supplied" — which was emitted
# verbatim on the day somebody registered a real file, contradicting the `path_or_link` three lines
# above it. Everything provisional here is provisional for a different reason once a document
# exists: what is missing is the APPROVAL, not the document.
WHY_SUPPLIED = ("Not yet approved: the document is registered at the path above, but no revision, "
                "checksum, approval date or approver is recorded, so nothing here attests that it "
                "is the document RWB approved. Record the digest, fill those in, and set status: "
                "reviewed.")


def unsupplied(path_or_link):
    """Whether `path_or_link` names a document at all, rather than standing in for one.

    Deliberately a PREFIX test on the placeholder vocabulary and not `os.path.exists`: the workbook
    routinely sits on a share this machine cannot see, and treating unreachable as unsupplied would
    print the wrong sentence for the commonest real registration there is.
    """
    head = str(path_or_link or "").strip().upper()
    return not head or any(head.startswith(p) for p in ("TBD", "TODO", "REPLACE_ME", "TBC", "N/A"))


def human_errors(ai_classification, classified_by, classified_date):
    """Why these three human values are not usable, or [] — checked BEFORE anything is written.

    Deliberately separate from the schema check: the schema would accept `classified_by: RWP` and
    `classified_by: TBD` as strings, and both are the failure this field exists to prevent.
    """
    out = []
    if ai_classification not in sm.AI_CLASSES:
        out.append(f"--ai-classification {ai_classification!r} is not one of {list(sm.AI_CLASSES)}")
    if pr.unstated(classified_by):
        out.append(f"--classified-by {classified_by!r} is a placeholder, not a person — this field "
                   f"records who made the classification call")
    else:
        why = pr.not_a_person(classified_by)
        if why:
            out.append(f"--classified-by {classified_by!r}: {why}")
    if not DATE_RE.match(str(classified_date or "")):
        out.append(f"--classified-date {classified_date!r} is not YYYY-MM-DD")
    else:
        try:
            datetime.date.fromisoformat(str(classified_date))
        except ValueError as e:
            out.append(f"--classified-date {classified_date!r}: {e}")
    return out


def document(pack, ai_classification, classified_by, classified_date, path_or_link, root=None):
    """The source_refs document for `pack`, as a mapping — composed, not templated.

    product and spec_version come from the registry and the pack path, so a typo in either is a
    registry mismatch rather than a value this tool made up.

    `root` resolves at CALL time, not at def time: a default of `root=REPO` binds the module
    constant once, and a test that points the tool at a sandbox would silently keep reading the
    real repository's registry — passing for the wrong reason.
    """
    root = root or REPO
    rel = pg.repo_relative(os.path.join(root, pack), root) if os.path.isabs(pack) else pack
    entry = pg.registry_entry(root, rel)
    if entry is None:
        raise SystemExit(f"{rel} matches no products/registry.yaml entry — register the tumour "
                         f"before registering its source materials")
    spec_version = os.path.basename(rel.rstrip("/"))
    code = str(entry.get("code") or "")
    return {
        "product": code,
        "spec_version": spec_version,
        "source_materials": [{
            "material_id": "program_spec",
            "material_type": "program_spec",
            "path_or_link": path_or_link,
            "role": f"{spec_version} program specification — the governed source for the contract",
            "status": "pending",
            "ai_classification": ai_classification,
            "classified_by": classified_by,
            "classified_date": classified_date,
            # The reason this registration is provisional depends on whether there is a document.
            # One sentence for both cases told half of the callers something false about their pack.
            "why_provisional": WHY if unsupplied(path_or_link) else WHY_SUPPLIED,
        }],
        "notes": [
            "The source workbook is NOT an engine runtime input; it is a governed "
            "specification-pipeline input, parsed by spec_extract.py to produce the extraction, "
            "coverage and contract artifacts. The governed implementation the build executes is "
            "the Git-tracked YAML + catalog.",
        ],
    }


def schema_errors(doc):
    """Schema violations, or [] — and a clear line when jsonschema is not installed rather than a
    silent pass, because "it validated" and "nothing checked it" must not look the same."""
    try:
        import jsonschema
    except ImportError:
        return ["jsonschema is not installed, so the document was NOT validated — "
                "pip install -r platform/requirements.txt and re-run"]
    with open(SCHEMA, encoding="utf-8") as fh:
        schema = json.load(fh)
    try:
        jsonschema.validate(doc, schema)
    except jsonschema.ValidationError as e:
        return [f"schema: {e.message} (at {'/'.join(str(p) for p in e.absolute_path)})"]
    return []


def scalar(value):
    """`value` as a YAML scalar YAML will read back as the same string.

    THE BUG THIS EXISTS FOR. Every field below used to be interpolated inside literal double quotes,
    and a double-quoted YAML scalar processes backslash escapes. A Windows path is nothing but
    backslashes, so `--path-or-link C:\\temp\\new\\PANO.xlsx` was written as

        path_or_link: "C:\\temp\\new\\PANO.xlsx"

    and read back as `C:<TAB>emp<NEWLINE>ew<U+2029>ANO.xlsx` — silently, with no error anywhere. The
    registration named a file that does not exist and cannot be typed, while `--check` reported a
    perfectly well-formed document. `C:\\specs\\...` was luckier: `\\s` is not a valid escape at all,
    so that one failed to parse and at least said so.

    Round-tripped through the YAML dumper instead of quoted by hand, which also covers the fields
    that are not paths: a `classified_by` of `Dr: X`, a name holding an apostrophe, and a
    `spec_version` of `202606` that must stay a string and not become an integer.
    """
    if "\n" in str(value):
        # Not serialized. A path or a person's name containing a newline is a defect in what was
        # typed, and folding it into a multi-line scalar would hide that inside a valid-looking file.
        raise SystemExit(f"refusing to register a value containing a newline: {value!r}")
    # Dumped as a one-key mapping and split at the key, rather than as a bare scalar document: a
    # scalar document picks up `...` end markers that would then have to be stripped by hand, and
    # stripping trailing dots would eat the last character of a value that legitimately ends in one.
    return yaml.safe_dump({"k": value}, default_flow_style=False, allow_unicode=True,
                          width=10 ** 6).split("k:", 1)[1].strip()


def render(doc):
    """The file text. Hand-composed rather than yaml.safe_dump'd, so the registration a person is
    asked to read carries the comments that tell them what each field is for.

    Hand-composed for the COMMENTS, never for the values: every interpolated value goes through
    `scalar()`, because hand-quoting is what silently corrupted a Windows path here."""
    m = doc["source_materials"][0]
    return f"""\
# Gate 1 SOURCE REGISTRATION — the human materials behind this pack.
#
# WRITTEN BY platform/tools/source_refs_init.py, from a classification a PERSON supplied on the
# command line. The three fields below that no tool may infer — ai_classification, classified_by,
# classified_date — were typed by that person and are their judgement, not this file's.
#
# `status: pending` means exactly what it says: no workbook has been approved for this pack, so no
# contract record here may claim `requirement: approved`, and the spec pipeline has nothing to
# extract. To move to `reviewed`, add document_id, revision, sha256, approval_date, approved_by and
# a path_or_link naming the exact approved document — plus data_refresh and rwb_qc_reference, which
# WORKFLOW.md Gate 1 requires of a program_spec. No field may be TODO/TBD/REPLACE_ME.
#
# See governance/schemas/source_refs.schema.json and platform/TUMOR_TEMPLATE/source_refs.yaml.
product: {scalar(doc['product'])}
spec_version: {scalar(doc['spec_version'])}

source_materials:
  - material_id: {scalar(m['material_id'])}
    material_type: {scalar(m['material_type'])}
    path_or_link: {scalar(m['path_or_link'])}
    role: {scalar(m['role'])}
    status: {scalar(m['status'])}
    # What AI may read at all. A human act of authority — never inferred from the filename or role.
    ai_classification: {scalar(m['ai_classification'])}
    classified_by: {scalar(m['classified_by'])}
    classified_date: {scalar(m['classified_date'])}
    why_provisional: >
      {m['why_provisional']}

notes:
  - {scalar(doc['notes'][0])}
"""


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack", help="repo-relative pack path, e.g. products/oncology/mcrc/YYYYMM")
    # NO DEFAULTS. Each of these is the human judgement this tool exists to carry, not to supply.
    ap.add_argument("--ai-classification", required=True, choices=list(sm.AI_CLASSES),
                    help="what AI may read: this is YOUR call, and it is not inferable")
    ap.add_argument("--classified-by", required=True,
                    help="who made that call, BY NAME — a team or a bare acronym is refused")
    ap.add_argument("--classified-date", required=True, help="YYYY-MM-DD")
    ap.add_argument("--path-or-link", default="TBD — workbook not yet supplied to this pack",
                    help="where the material is; leave as TBD while the workbook is not in hand")
    a = ap.parse_args(argv)

    pack = a.pack.rstrip("/").replace("\\", "/")
    target = os.path.join(REPO, pack, "source_refs.yaml")
    if os.path.exists(target):
        print(f"REFUSED — {pack}/source_refs.yaml already exists. That file is a registration "
              f"record and may carry an approval; edit it deliberately rather than regenerating "
              f"it.", file=sys.stderr)
        return 1
    if not os.path.isdir(os.path.join(REPO, pack)):
        print(f"REFUSED — no pack at {pack}", file=sys.stderr)
        return 1

    version = os.path.basename(pack)
    if not SPEC_VERSION_RE.match(version):
        print(f"REFUSED — this pack's version directory is {version!r}, not a YYYYMM spec version. "
              f"A registration records WHICH cut of the workbook governs the pack, so a placeholder "
              f"directory cannot carry one. Rename {pack} to the spec version the workbook governs "
              f"(e.g. .../202608) and re-run.", file=sys.stderr)
        return 1

    bad = human_errors(a.ai_classification, a.classified_by, a.classified_date)
    if bad:
        for e in bad:
            print(f"REFUSED — {e}", file=sys.stderr)
        return 1

    doc = document(pack, a.ai_classification, a.classified_by, a.classified_date, a.path_or_link,
                   root=REPO)
    bad = schema_errors(doc)
    if bad:
        for e in bad:
            print(f"REFUSED — {e}", file=sys.stderr)
        return 1

    with open(target, "w", encoding="utf-8", newline="") as fh:
        fh.write(render(doc))
    print(f"wrote {pack}/source_refs.yaml — program_spec, status: pending, "
          f"ai_classification: {a.ai_classification}")

    # ...and then say what Gate 1 makes of it, rather than leaving the author to wonder.
    errs = sm.check(REPO, pack)
    if errs:
        print("\nGate 1 reports:")
        for e in errs:
            print(f"  - {e}")
    else:
        print("Gate 1: no errors (the material is registered and provisional, not approved)")
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
