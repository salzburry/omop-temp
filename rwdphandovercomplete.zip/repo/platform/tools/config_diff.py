#!/usr/bin/env python3
"""What a change to the executable YAML actually DOES — dropped, added, changed, reordered.

    python3 platform/tools/config_diff.py <pack> --base <rev>          # one pack, base-to-head
    python3 platform/tools/config_diff.py --all --base <rev>           # every registered pack

WHY THIS EXISTS. The controls on the executable surface validate syntax, currency and raw-byte
digests. A byte change correctly invalidates an approval — and explains nothing: the diff a reviewer
sees is line noise, in which "a comment moved" and "the cohort window narrowed by a year" look the
same. The failure mode that leaves open is the expensive one: internally consistent, syntactically
valid, clinically wrong.

WHAT "SEMANTIC" MEANS HERE, exactly. Both revisions are PARSED, then compared as structures:

  * a comment, whitespace or key-order edit produces NO finding — the structures are equal;
  * a key that exists on one side only is DROPPED or ADDED, by its full path — a derivation
    disappearing from variables/ is named as itself, not as a hunk;
  * a value that differs is CHANGED, old -> new, so "the window moved from -30 to -365" is a
    sentence rather than an inference;
  * a KEYED list (every item a mapping sharing one identity key) is compared per item, and an
    order change over equal membership is REORDERED — which matters exactly where precedence is
    positional;
  * a SCALAR list (codes, values) is compared as membership first — entries added/removed by
    value — and as a reorder when membership held.

WHAT IT DOES NOT DO. It attaches no clinical meaning: whether a narrowed window is a correction or
a catastrophe is the judgment `rule_review.py` exists to put in front of the right person, beside
the specification's words. And it is ADVISORY in CI until branch protection exists — it can make a
change legible; nothing in this repository can make anyone read it before merging.

Findings are the CONFIG's own content (paths, config values, code strings) — governed material,
never vendor data.

stdlib plus PyYAML, through product_gates.read_yaml for head files; base bytes via `git show`.
"""
import argparse
import os
import subprocess
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)
from spec_extract import repo_relative                                  # noqa: E402

import yaml                                                              # noqa: E402
import product_gates as pg                                               # noqa: E402

# The directories that ARE the executable surface of a pack. Docs, handoff and spec_pipeline change
# constantly and are governed elsewhere; what the BUILD reads is exactly this.
EXECUTABLE_DIRS = ("config", "variables", "codelists")

# The keys a list item may be identified by, tried in order. A list whose items all carry one of
# these with distinct values is compared PER ITEM; anything else is compared as a value.
ITEM_KEYS = ("variable", "name", "id", "match", "code", "key", "cohort")


def _git(root, *args):
    r = subprocess.run(["git", "-C", root, *args], capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    return r.returncode, r.stdout


def base_files(root, rev, pack):
    """The executable YAML paths at `rev`, repo-relative. Errors are the CALLER's to see: an
    unreachable rev must fail the run, never read as an empty base — an empty base makes every
    current file 'added' and the real change invisible in the noise."""
    code, out = _git(root, "ls-tree", "-r", "--name-only", rev, "--",
                     *[f"{pack}/{d}" for d in EXECUTABLE_DIRS])
    if code != 0:
        raise RuntimeError(f"git ls-tree {rev} failed — is the base revision fetched?")
    return sorted(p for p in out.splitlines() if p.endswith((".yaml", ".yml")))


def head_files(root, pack):
    out = []
    for d in EXECUTABLE_DIRS:
        base = os.path.join(root, pack, d)
        for dirpath, _dirs, files in os.walk(base):
            for f in sorted(files):
                if f.endswith((".yaml", ".yml")):
                    out.append(repo_relative(os.path.join(dirpath, f), root))
    return sorted(out)


def _load_base(root, rev, rel):
    code, out = _git(root, "show", f"{rev}:{rel}")
    if code != 0:
        raise RuntimeError(f"git show {rev}:{rel} failed")
    # STRICT: a duplicate key at the base revision would load last-wins and the semantic diff
    # would compare against a config the file never was — hiding exactly the change it reports.
    from engine.strict_yaml import strict_load
    return strict_load(out)


def _item_key(items):
    """The identity key a keyed list uses, or None. ALL items must carry it, with distinct values —
    a partial key would silently compare half the list per item and the rest not at all."""
    if not items or not all(isinstance(i, dict) for i in items):
        return None
    for k in ITEM_KEYS:
        vals = [i.get(k) for i in items]
        if all(v is not None for v in vals) and len(set(map(str, vals))) == len(vals):
            return k
    return None


def flatten(doc, prefix=""):
    """({path: value}, {path: [order]}) — mappings by key, keyed lists per item, the rest as values.

    The order map carries every keyed list's identity sequence, so membership and ORDER are separate
    questions with separate findings — precedence lists change meaning under a reorder that leaves
    every item byte-identical.
    """
    values, orders = {}, {}
    if isinstance(doc, dict):
        for k, v in doc.items():
            sub_v, sub_o = flatten(v, f"{prefix}/{k}")
            values.update(sub_v)
            orders.update(sub_o)
    elif isinstance(doc, list):
        key = _item_key(doc)
        if key:
            orders[prefix] = [str(i[key]) for i in doc]
            for item in doc:
                sub_v, sub_o = flatten(item, f"{prefix}[{key}={item[key]}]")
                values.update(sub_v)
                orders.update(sub_o)
        else:
            values[prefix] = doc
    else:
        values[prefix] = doc
    return values, orders


def _show(v):
    s = str(v)
    return s if len(s) <= 120 else s[:117] + "..."


def diff_docs(base, head):
    """[(kind, path, detail)] — kind in dropped/added/changed/reordered/list_changed."""
    bv, bo = flatten(base)
    hv, ho = flatten(head)
    out = []
    for path in sorted(set(bv) - set(hv)):
        out.append(("dropped", path, f"was: {_show(bv[path])}"))
    for path in sorted(set(hv) - set(bv)):
        out.append(("added", path, f"now: {_show(hv[path])}"))
    for path in sorted(set(bv) & set(hv)):
        a, b = bv[path], hv[path]
        if a == b:
            continue
        if isinstance(a, list) and isinstance(b, list):
            gone, new = [x for x in a if x not in b], [x for x in b if x not in a]
            if gone or new:
                bits = []
                if gone:
                    bits.append(f"-{len(gone)}: {', '.join(_show(x) for x in gone[:8])}")
                if new:
                    bits.append(f"+{len(new)}: {', '.join(_show(x) for x in new[:8])}")
                out.append(("list_changed", path, "; ".join(bits)))
            else:
                out.append(("reordered", path, "same entries, different order"))
        else:
            out.append(("changed", path, f"{_show(a)} -> {_show(b)}"))
    for path in sorted(set(bo) & set(ho)):
        if bo[path] != ho[path] and sorted(bo[path]) == sorted(ho[path]):
            out.append(("reordered", path,
                        f"{' > '.join(bo[path][:6])} -> {' > '.join(ho[path][:6])}"))
    return out


def diff_pack(pack, rev, root=ROOT):
    """{file: [findings]} for one pack, base rev -> working tree. Whole files appearing or
    vanishing are findings too — a derivation FILE dropped is every rule in it dropped."""
    b, h = set(base_files(root, rev, pack)), set(head_files(root, pack))
    out = {}
    for rel in sorted(b - h):
        out[rel] = [("dropped", "(entire file)", "every rule in it is gone from the build")]
    for rel in sorted(h - b):
        doc, err = pg.read_yaml(os.path.join(root, rel))
        n = len(flatten(doc)[0]) if not err else "?"
        out[rel] = [("added", "(entire file)", f"{n} value(s) enter the build")]
    for rel in sorted(b & h):
        head_doc, err = pg.read_yaml(os.path.join(root, rel))
        if err:
            out[rel] = [("error", "(head)", f"unreadable: {err}")]
            continue
        try:
            base_doc = _load_base(root, rev, rel)
        except Exception as e:                                          # noqa: BLE001
            out[rel] = [("error", "(base)", str(e))]
            continue
        findings = diff_docs(base_doc, head_doc)
        if findings:
            out[rel] = findings
    return out


def render(pack, per_file):
    L = [f"== {pack}"]
    if not per_file:
        L.append("   no semantic change to the executable surface")
        return L
    n = sum(len(v) for v in per_file.values())
    L[0] += f" — {n} semantic change(s)"
    for rel, findings in sorted(per_file.items()):
        L.append(f"   {rel}")
        for kind, path, detail in findings:
            L.append(f"      {kind:<12} {path}  {detail}")
    return L


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack", nargs="?", help="one pack; or --all for every registered pack")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--base", required=True, help="the git revision to diff FROM")
    a = ap.parse_args(argv)
    if bool(a.pack) == bool(a.all):
        ap.error("name a pack or pass --all")
    packs = ([repo_relative(os.path.abspath(a.pack), ROOT)] if a.pack
             else sorted(pg.products(ROOT)))
    had_error = False
    any_change = False
    for pack in packs:
        if not os.path.isdir(os.path.join(ROOT, pack, "config")):
            continue
        try:
            per_file = diff_pack(pack, a.base)
        except RuntimeError as e:
            print(f"== {pack}\n   ERROR: {e}")
            had_error = True
            continue
        for line in render(pack, per_file):
            print(line)
        any_change = any_change or bool(per_file)
        had_error = had_error or any(k == "error" for v in per_file.values() for k, _p, _d in v)
    if not any_change and not had_error:
        print("\nno semantic change to any pack's executable surface")
    # ADVISORY: findings exit 0 — a person judges them (rule_review puts each rule beside its spec).
    # Only an inability to LOOK is a failure: an unreadable file or unreachable base would otherwise
    # read as "no change", which is the one thing this must never say by accident.
    return 1 if had_error else 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
