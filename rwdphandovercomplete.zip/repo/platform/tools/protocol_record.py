#!/usr/bin/env python3
"""A PROTOCOL's record — what we said we would do, frozen before we did it.

    python3 platform/tools/protocol_record.py --new prot-2026-001   # scaffold
    python3 platform/tools/protocol_record.py --digest prot-2026-001 # the freeze digest to record
    python3 platform/tools/protocol_record.py --check               # lint every registered protocol

WHY THIS IS NOT A THINNER FUNCTIONAL_CONTRACT. A product's contract is an ONGOING RECONCILIATION:
the workbook states a requirement, the configuration claims to implement it, and the record's job is
to keep those two facing each other as both change. A protocol's record answers a different question
entirely, and only once — *was this specified BEFORE the results were seen?* Everything a protocol
is worth rests on that. An objective added after the analysis, an endpoint quietly swapped for the
one that reached significance, a subgroup that appears in the write-up and not the plan: each is
invisible in the finished document, and each is the thing pre-specification exists to prevent.

So the governed property here is a FREEZE, not a reconciliation.

  * `prespecified:` holds the content that must not move — objectives, design, population,
    endpoints, analyses.
  * At registration a person records `prespecification_sha256` over exactly that subtree. From then
    on `--check` recomputes it, and a mismatch is a refusal.
  * Changing a registered protocol is not forbidden — protocols legitimately amend. It requires an
    AMENDMENT: a date, a person, what changed, why, and the new digest it covers. The change becomes
    visible instead of silent, which is the whole of the difference.

The digest is over the CANONICAL FORM of the subtree (sorted keys, normalised scalars), not the file
bytes, so reflowing a paragraph or reordering two keys does not read as an amendment — and altering
a single endpoint does.

WHAT A PROTOCOL OWES (governance/WORKFLOW.md, "Which gates apply"): `contract` — this record — and
`provenance`, the releases it will read, which live on its registry entry beside every other work
object's citation. A request executed under it may not read a release the protocol never named:
that check is `request_scope_errors`, and it is what stops a study growing new data sources one
analysis at a time.

HUMAN FIELDS. `registered_by`, `registered_date`, every amendment's `by`/`date`, and any status past
`draft` are a person's acts, exactly as a Gate 1 classification is. `--new` writes markers; `--check`
refuses a registered protocol still carrying one.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import product_gates as pg       # noqa: E402
import request_record as rr      # noqa: E402
import source_manifest as sm     # noqa: E402

RECORD = "PROTOCOL.yaml"
MARK = "REPLACE_ME"
STATUSES = ("draft", "registered", "amended", "closed")
FROZEN = ("registered", "amended", "closed")          # the states a freeze digest must hold in
HUMAN_FIELDS = ("registered_by", "registered_date")
# The subtree the freeze covers. Named here so that adding a pre-specified field is a deliberate
# act that moves every existing digest, rather than a new field quietly outside the freeze.
PRESPECIFIED = ("objectives", "design", "population", "endpoints", "analyses")

TEMPLATE = f"""\
# A PROTOCOL — the plan, frozen before the analysis. It owes `contract` (this record) and
# `provenance` (the releases it reads, on its registry entry). See governance/WORKFLOW.md.
#
# Everything under `prespecified:` is covered by `prespecification_sha256`. Once this protocol is
# registered, changing any of it requires an AMENDMENT — a date, a person, what changed and why.
# That is not friction for its own sake: an endpoint swapped after the fact is invisible in the
# finished document, and this is the only place it can be made visible.
#
# Every {MARK} is a person's to fill. `--check` refuses a registered protocol still carrying one.
protocol_id: {{pid}}
title: "{MARK}"

status: draft                   # draft -> registered -> amended -> closed; only `draft` is a tool's
registered_by: {MARK}           # a NAMED person, not a team
registered_date: {MARK}         # YYYY-MM-DD

# Recorded at registration: `--digest {{pid}}` prints it. It covers `prespecified:` below and
# nothing else, so an edit to the title or a note is not an amendment and an edit to an endpoint is.
prespecification_sha256: {MARK}

prespecified:
  objectives:
    - {MARK}
  design: >
    {MARK}
  population: >
    {MARK}
  endpoints:
    primary:
      - {MARK}
    secondary: []
  analyses:
    - {MARK}

# Append one entry per amendment. `covers_digest` is the digest AFTER the change — `--digest` prints
# it, and --check requires the newest entry to match what `prespecified:` now hashes to.
amendments: []
# - date: YYYY-MM-DD
#   by: "a NAMED person"
#   what_changed: "the secondary endpoint list"
#   why: "…"
#   covers_digest: "…"
"""


def record_path(pid, root=None):
    return os.path.join(root or REPO, rr.WORK, str(pid), RECORD)


def _protocols(root):
    return [w for w in pg.work_entries(root) if str(w.get("kind") or "") == "protocol"]


def _canonical(node):
    """The comparable form of a pre-specified value.

    Digesting the FILE would make a reflowed paragraph or two swapped keys read as an amendment, and
    a record that cries amendment over whitespace teaches people to re-stamp the digest without
    reading — which is exactly the habit the freeze exists to prevent. So: mappings sorted, scalars
    stringified and whitespace-collapsed, lists left in order because the order of endpoints is part
    of what was specified.
    """
    if isinstance(node, dict):
        return {str(k): _canonical(node[k]) for k in sorted(node, key=str)}
    if isinstance(node, (list, tuple)):
        return [_canonical(v) for v in node]
    return " ".join(str(node).split())


def prespecification_digest(doc):
    """sha256 over the `prespecified:` subtree in canonical form, or None when it is absent.

    Every key in PRESPECIFIED is folded in BY NAME even when missing, so a protocol that drops an
    endpoint list cannot hash equal to one that never had it — the same rule
    `config_bundle_sha256` applies to a referenced file the pack lacks.
    """
    pre = (doc or {}).get("prespecified")
    if not isinstance(pre, dict):
        return None
    payload = {k: _canonical(pre.get(k)) for k in PRESPECIFIED}
    blob = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def record_errors(root, entry):
    """[why this protocol's record is not usable], or []."""
    pid = str(entry.get("id") or "")
    path = record_path(pid, root)
    rel = os.path.relpath(path, root)
    if not os.path.exists(path):
        return [f"{pid}: no record at {rel} — scaffold it with --new {pid}"]
    doc, err = pg.read_yaml(path)
    if err:
        return [f"{rel}: {err}"]
    out = []
    if str(doc.get("protocol_id") or "") != pid:
        out.append(f"{rel}: protocol_id {doc.get('protocol_id')!r} does not match the registry id "
                   f"{pid!r} — the record and its registration must name the same object")
    status = str(doc.get("status") or "")
    if status not in STATUSES:
        out.append(f"{rel}: status {status!r} is not one of {list(STATUSES)}")

    live = prespecification_digest(doc)
    if live is None:
        out.append(f"{rel}: no `prespecified:` block — a protocol with nothing pre-specified has "
                   f"nothing to freeze, and nothing to be held to afterwards")

    if status in FROZEN:
        # The module header claims `--check` refuses a registered protocol still carrying a marker.
        # It checked two fields, so a registered protocol could carry `title: REPLACE_ME` and a
        # scaffold objective while reporting clean — the header was describing a check that did not
        # exist. One sweep of the loaded record, with no list to fall behind the template.
        for where in pg.marker_paths(doc, MARK):
            out.append(f"{rel}: status is {status!r} and `{where}` still holds {MARK}. A frozen plan "
                       f"is what somebody committed to; a marker in it is the scaffold speaking in "
                       f"their place.")
        for f in HUMAN_FIELDS:
            v = doc.get(f)
            if pg.unstated(v) or MARK in str(v):
                out.append(f"{rel}: status is {status!r} but {f} is still {str(v)!r} — a protocol "
                           f"cannot be registered by a marker")
            # ...and `registered_by` has to be a person. A prespecification is the record that
            # somebody committed to an analysis BEFORE seeing the result; attributing that
            # commitment to a team is attributing it to nobody, which is the state the freeze
            # exists to rule out.
            elif f.endswith("_by"):
                bad = pg.not_a_person(v)
                if bad:
                    out.append(f"{rel}: `{f}`: {bad}")
        if not pg.unstated(doc.get("registered_date")) and pg.bad_date(doc.get("registered_date")):
            out.append(f"{rel}: registered_date {doc.get('registered_date')!r} is not YYYY-MM-DD")

        recorded = str(doc.get("prespecification_sha256") or "")
        if pg.unstated(recorded) or MARK in recorded:
            out.append(f"{rel}: status is {status!r} with no prespecification_sha256 — the freeze "
                       f"is the digest; without it the record claims a plan nobody can prove was "
                       f"the plan. Record `--digest {pid}`.")
        elif live and recorded != live:
            amend = [a for a in (doc.get("amendments") or []) if isinstance(a, dict)]
            newest = str((amend[-1].get("covers_digest") if amend else "") or "")
            if newest == live:
                # An amendment covers the change; the top-level digest simply has not been moved
                # forward with it. Say exactly that rather than reporting an unexplained mismatch.
                out.append(f"{rel}: prespecification_sha256 is {recorded[:12]}… but the newest "
                           f"amendment covers {live[:12]}… — move the top-level digest to the one "
                           f"the amendment records, so the record names its CURRENT plan")
            else:
                out.append(f"{rel}: `prespecified:` hashes to {live[:12]}… but the record was "
                           f"registered against {recorded[:12]}… and no amendment covers the "
                           f"change. A registered protocol may be amended, never edited: append an "
                           f"amendment (date, by, what_changed, why, covers_digest) or restore the "
                           f"plan that was registered.")

    for i, a in enumerate(doc.get("amendments") or []):
        where = f"{rel} amendments[{i}]"
        if not isinstance(a, dict):
            out.append(f"{where}: not a mapping")
            continue
        for f in ("date", "by", "what_changed", "why", "covers_digest"):
            v = a.get(f)
            if pg.unstated(v) or MARK in str(v):
                out.append(f"{where}: {f} is unstated — an amendment that does not say who changed "
                           f"what, when and why is the silent edit it exists to replace")
        if not pg.unstated(a.get("date")) and pg.bad_date(a.get("date")):
            out.append(f"{where}: date {a.get('date')!r} is not YYYY-MM-DD")
        # `by` is the amendment's whole accountability: the record exists so that a change to a
        # frozen plan names somebody rather than appearing. A team there names nobody.
        if not pg.unstated(a.get("by")):
            bad = pg.not_a_person(a.get("by"))
            if bad:
                out.append(f"{where}: `by`: {bad}")
    return out


def _pack_key(c):
    """The PACK a citation names — (product, spec_version)."""
    return (str(c.get("product") or ""), str(c.get("spec_version") or ""))


def _build_pin(c):
    """The BUILD a citation pins, or None when it names the pack only.

    `source_manifest.citation_errors` already distinguishes the two strengths — a pack-level
    citation buys Gates 1-4 on the pack, a build-level one adds Gate 6 for that build. Scope was
    blind to the difference: it compared pack keys, so a request under a protocol pinned to one
    build could read a DIFFERENT cut of the same spec version and pass.
    """
    bid, man = str(c.get("build_id") or "").strip(), str(c.get("manifest_sha256") or "").strip()
    return (bid, man) if (bid or man) else None


def request_scope_errors(root):
    """[why a request reads outside the protocol it runs under] — the study-drift check.

    A request may declare `under_protocol:`. When it does, every release it cites must be one the
    PROTOCOL cites: a study that acquires a new data source one analysis at a time has changed its
    own scope without anyone deciding to, and each individual step looks reasonable.

    SCOPE IS THE BUILD, NOT ONLY THE PACK, wherever the protocol says so. A protocol registered
    against a pack it has not yet read pins nothing — that is the normal order, because
    pre-specification comes BEFORE the cut — and its requests may pin whichever build they ran on. A
    protocol written against an EXISTING release pins that build, and then a request reading another
    cut of the same spec version is reading different data under a plan that named specific data.
    Comparing spec versions alone could not tell those apart.

    The third case is the one no single record can see: two requests under one protocol reading two
    DIFFERENT builds of the same pack. Neither request is outside scope, and the study's numbers came
    from two cuts. `scope_report` is where that surfaces.
    """
    out = []
    by_id = {str(w.get("id") or ""): w for w in pg.work_entries(root)}
    for w in pg.work_entries(root):
        pid = str(w.get("under_protocol") or "").strip()
        if not pid:
            continue
        wid = str(w.get("id") or "?")
        prot = by_id.get(pid)
        if prot is None or str(prot.get("kind") or "") != "protocol":
            out.append(f"{wid}: under_protocol {pid!r} is not a registered protocol")
            continue
        doc, err = pg.read_yaml(record_path(pid, root))
        if err is None and str((doc or {}).get("status") or "") == "draft":
            out.append(f"{wid}: runs under {pid}, which is still `draft` — work executed under an "
                       f"unregistered plan is not pre-specified, which is the only thing running "
                       f"under a protocol buys")
        pinned = {}
        for c in (prot.get("cites_release") or []):
            if isinstance(c, dict):
                pinned.setdefault(_pack_key(c), []).append(_build_pin(c))
        for c in (w.get("cites_release") or []):
            if not isinstance(c, dict):
                continue
            key = _pack_key(c)
            if key not in pinned:
                out.append(f"{wid}: reads {key[0]} {key[1]}, which {pid} does not cite. A study "
                           f"does not acquire a data source one analysis at a time — amend the "
                           f"protocol to name it, or run this request outside the protocol.")
                continue
            pins = [p for p in pinned[key] if p]
            if not pins:
                continue                      # the protocol named the pack, not a cut: any build
            mine = _build_pin(c)
            if mine is None:
                names = ", ".join(sorted(b or m for b, m in pins))
                out.append(f"{wid}: reads {key[0]} {key[1]} without naming a build, but {pid} is "
                           f"pre-specified against {names}. A plan written against specific data "
                           f"is not a plan for whatever that pack becomes — pin the build this "
                           f"request read, or amend the protocol to the pack level.")
            elif mine not in pins:
                names = ", ".join(sorted(b or m for b, m in pins))
                out.append(f"{wid}: reads {key[0]} {key[1]} build {mine[0] or mine[1]}, and {pid} "
                           f"is pre-specified against {names}. A different cut of the same "
                           f"specification is different data — amend the protocol, or run this "
                           f"request outside it.")
    return out


def scope_report(root=None):
    """{protocol_id: {pack_key: {"pinned": [...], "read": [...]}}} — what each study ACTUALLY read.

    The question no individual record answers: "which data did this study use?" A protocol names
    packs; each request under it names a build; nothing joined the two, so recovering a study's data
    provenance meant opening every request.

    It also exposes the failure `request_scope_errors` structurally cannot see. Two requests under
    one protocol, each citing a build the protocol permits, each perfectly in scope, reading two
    DIFFERENT cuts of the same pack — the study's numbers then come from two deliveries and no
    record says so. That is a finding about the SET, so it has to be computed over the set.
    """
    root = root or REPO
    entries = pg.work_entries(root)
    by_id = {str(w.get("id") or ""): w for w in entries}
    report = {}
    for w in entries:
        if str(w.get("kind") or "") != "protocol":
            continue
        pid = str(w.get("id") or "")
        packs = {}
        for c in (w.get("cites_release") or []):
            if isinstance(c, dict):
                packs.setdefault(_pack_key(c), {"pinned": [], "read": []})
                pin = _build_pin(c)
                if pin:
                    packs[_pack_key(c)]["pinned"].append(pin)
        report[pid] = packs
    for w in entries:
        pid = str(w.get("under_protocol") or "").strip()
        if pid not in report:
            continue
        for c in (w.get("cites_release") or []):
            if not isinstance(c, dict):
                continue
            slot = report[pid].setdefault(_pack_key(c), {"pinned": [], "read": []})
            pin = _build_pin(c)
            if pin and pin not in slot["read"]:
                slot["read"].append(pin)
    return report


def split_build_findings(report):
    """[sentences] naming every protocol whose requests read more than one build of one pack."""
    out = []
    for pid, packs in sorted(report.items()):
        for (slug, ver), slot in sorted(packs.items()):
            if len(slot["read"]) > 1:
                builds = ", ".join(sorted(b or m for b, m in slot["read"]))
                out.append(f"{pid}: requests under this protocol read {len(slot['read'])} different "
                           f"builds of {slug} {ver} ({builds}). Each request is individually in "
                           f"scope and the study's numbers came from more than one cut — state "
                           f"which build each result is from, or re-run them onto one.")
    return out


def check(root=None):
    """[(protocol_id, [errors])] for every registered protocol, plus the scope check."""
    root = root or REPO
    rows = [(str(w.get("id") or "?"), record_errors(root, w) + sm.citation_errors(root, w))
            for w in _protocols(root)]
    scope = request_scope_errors(root) + split_build_findings(scope_report(root))
    if scope:
        rows.append(("(scope)", scope))
    return rows


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--new", metavar="ID", help="scaffold work/<ID>/PROTOCOL.yaml")
    ap.add_argument("--digest", metavar="ID",
                    help="print the sha256 of that protocol's `prespecified:` block — what a "
                         "registration or an amendment records")
    ap.add_argument("--check", action="store_true", help="exit non-zero on any error")
    ap.add_argument("--scope", action="store_true",
                    help="per protocol: the packs it cites, the builds it PINS, and the builds its "
                         "requests actually read")
    a = ap.parse_args(argv)

    if a.new is not None:
        pid = a.new.strip()
        if not pid or "/" in pid or os.path.sep in pid:
            print(f"REFUSED — {a.new!r} is not a usable protocol id", file=sys.stderr)
            return 1
        path = record_path(pid)
        if os.path.exists(path):
            print(f"REFUSED — {os.path.relpath(path, REPO)} already exists; a registered plan is "
                  f"amended, never regenerated", file=sys.stderr)
            return 1
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8", newline="") as fh:
            fh.write(TEMPLATE.format(pid=pid))
        print(f"wrote {os.path.relpath(path, REPO)}")
        print(f"Fill every {MARK}, register the protocol in products/registry.yaml under `work:` "
              f"with the releases it will read, then record `--digest {pid}` and set status: "
              f"registered.")
        return 0

    if a.digest is not None:
        doc, err = pg.read_yaml(record_path(a.digest.strip()))
        if err:
            print(f"REFUSED — {err}", file=sys.stderr)
            return 1
        d = prespecification_digest(doc)
        if d is None:
            print("REFUSED — no `prespecified:` block to digest", file=sys.stderr)
            return 1
        print(d)
        return 0

    if a.scope:
        report = scope_report()
        if not report:
            print("no protocols registered — nothing to scope")
            return 0
        for pid, packs in sorted(report.items()):
            print(pid)
            for (slug, ver), slot in sorted(packs.items()):
                pins = ", ".join(sorted(b or m for b, m in slot["pinned"])) or "the pack, any build"
                read = ", ".join(sorted(b or m for b, m in slot["read"])) or "nothing yet"
                print(f"    {slug} {ver}")
                print(f"        pre-specified against: {pins}")
                print(f"        builds actually read:  {read}")
        findings = split_build_findings(report)
        for f in findings:
            print(f"\n  ! {f}")
        return 1 if findings else 0

    rows = check()
    if not rows:
        print("no protocols registered (products/registry.yaml has no `work:` entry of kind "
              "protocol)")
        return 0
    bad = 0
    for pid, errs in rows:
        bad += len(errs)
        print(f"{pid:<30} " + ("OK" if not errs else f"{len(errs)} error(s)"))
        for e in errs:
            print(f"    {e}")
    print(f"\n{len(rows)} protocol(s); {bad} error(s)")
    return 1 if (a.check and bad) else 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
