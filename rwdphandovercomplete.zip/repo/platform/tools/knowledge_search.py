#!/usr/bin/env python3
"""One question, asked across every knowledge surface at once — with each answer's AUTHORITY.

    python3 platform/tools/knowledge_search.py follow-up end
    python3 platform/tools/knowledge_search.py --kind capability --kind decision response
    python3 platform/tools/knowledge_search.py --json biomarker window

WHY THIS EXISTS. The repository holds six kinds of knowledge about the same subjects, in six places
with six readers: decision registers, the precedent store, contract records, the variable inventory,
the citation register and the capability registry. Someone asking "how do we handle end of
follow-up?" had to know all six existed, and know which of them could ANSWER as opposed to merely
mention. The last part is the dangerous one — an inventory entry and an attributed ruling look
equally authoritative in a grep, and the inventory authorises nothing whatever state it reaches.

AUTHORITY IS TWO FACETS, NOT ONE LADDER. The first version ranked everything on a single scale, so
an engine-wiring claim (`checked_claim`) sat ABOVE an unsigned methodology answer — as though the two
were stronger and weaker versions of one thing. They are not. RWDE evidence that a capability is
wired cannot settle an RWP methodology question however well tested it is, and a signed product
ruling says nothing about whether the engine implements it. So every hit carries:

    domain    WHAT KIND of authority it could ever have
              product_ruling · implementation_evidence · literature · provenance
    state     HOW FAR that authority has been taken, IN THAT DOMAIN'S OWN VOCABULARY

STATES ARE PER-DOMAIN, and that is the second thing this had to unlearn. One shared ladder let a
surface reach for the strongest-sounding word without holding what the word named: `signed` meant
"a named person and a usable date stand behind it", and two surfaces awarded it with neither — one
from the bare string `requirement: approved`, the other from any capability that was not merely
`declared`. Each domain now has its own ladder (see STATES), the ranking is within-domain only, and
`search()` REFUSES a hit whose state does not belong to its domain, so the words cannot migrate
again.

Ordering is by DOMAIN first, then state within it, so a reader never has to compare two
incomparable things by position.

VALIDATED BEFORE IT IS RANKED. Each surface is run through its OWN validator before its hits are
included; a surface that does not validate is REPORTED as unusable rather than silently promoted. A
capability was previously reported `checked_claim` without ever calling `registry_errors`, which is
the claim the registry exists to make and this tool was asserting for free.

NOTHING HERE IS AN APPROVAL. An `attributed` product ruling was decided for THAT pack against THAT
workbook; reusing it is evidence to show an answerer, never authority to adopt. The banner says so on
every run, including the runs that find nothing.

READ-ONLY, computed on demand, no cache. Composes the owning readers (`knowledge_graph`,
`precedents`, `contract_lint`, `capability_registry`, `citation_register`) rather than re-parsing
anything, so a surface that changes its shape changes here in one place — its own reader.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from spec_extract import repo_relative, repo_root                                       # noqa: E402

ROOT = repo_root(os.path.abspath(__file__))

# WHAT KIND of authority a hit could ever carry. Ordered because a reader skims from the top, but
# these are DIFFERENT KINDS, not degrees — the ordering says which to read first, never which
# outranks which. An implementation_evidence hit cannot settle a methodology question at any state,
# and the banner says so rather than leaving the position to imply otherwise.
DOMAIN = (
    ("product_ruling", "what a product DECIDED — the only domain that can settle a methodology "
                       "question, and only for the pack that decided it"),
    ("implementation_evidence", "what the ENGINE does. It cannot settle what a variable should "
                                "mean, however well tested it is"),
    ("literature", "what published work defines. A drafting aid; it authorises nothing"),
    ("provenance", "how a claim was CHECKED, never what the claim says"),
)
DOMAIN_RANK = {name: i for i, (name, _) in enumerate(DOMAIN)}

# HOW FAR the evidence has been taken, PER DOMAIN. One shared ladder was the defect: it let
# unrelated evidence be compared on one axis, and — worse — it let a surface reach for the
# strongest-sounding word without holding the thing that word named.
#
# `signed` was defined as "a named person and a usable date stand behind it", and TWO surfaces
# awarded it without either. `_contract_records` set it from the string `requirement: approved`,
# reading no approver and no date and importing nothing that could read one. `_capabilities` set it
# for any capability whose engines were not merely `declared` — so a passing unit test read as a
# person's signature, in the one domain whose own description says implementation evidence "cannot
# settle what a variable should mean, however well tested it is".
#
# So each domain now has its OWN ladder, in its own vocabulary, and states are never compared
# across domains. A state cannot be borrowed to make weak evidence look strong, because the word
# does not exist outside the domain that earned it.
STATES = {
    # What a product DECIDED. The ladder is who stands behind it, not how sure it sounds.
    "product_ruling": (
        ("authenticated", "the attribution is bound to a signature (approval_identity.py)"),
        ("attributed", "a named person and a usable date are RECORDED — typed, not authenticated"),
        ("answered_unattributed", "answered, with nobody recorded as having answered it"),
        ("open", "asked and not settled — the value is knowing it will come up"),
    ),
    # What the ENGINE does. Reuses `capability_registry.VERIFICATION` rather than inventing a
    # second vocabulary for one question — the duplication this repository keeps paying for.
    "implementation_evidence": (
        ("stage_conformance", "a shared row fixture through both engines, outputs compared"),
        ("component_parity", "both engines compared on what they compile or compute"),
        ("unit_tested", "a named test exercises one engine's implementation"),
        ("declared", "the parts resolve to each other; nothing proves the code is correct"),
        ("absent", "not implemented in this engine"),
    ),
    # What published work defines. It authorises nothing, so its top state is still not authority.
    "literature": (
        ("human_reviewed", "a named person read the source and confirmed what it says"),
        ("claim_bound", "the citation is bound to the specific claim it supports"),
        ("bibliographic_only", "a resolvable reference and nothing more"),
        ("reference_only", "a drafting AID, and it can never leave this state"),
    ),
    # How a claim was CHECKED, never what the claim says.
    #
    # LITERAL NAMES, because the aspirational ones were false the moment they were used. The first
    # version of this ladder read `source_verified` ("the bytes were retrieved and compared to the
    # recorded digest") / `human_attested` ("a named person recorded that they checked it") /
    # `automated`, and `_citations` mapped `pubmed_or_publisher` to the first and
    # `in_house_drafting_surface` to the second. CITATIONS.yaml says in capitals that NO HUMAN HAS
    # VERIFIED ANY OF THESE, and `pubmed_or_publisher` is an IDENTIFIER RESOLUTION — no bytes were
    # fetched and no digest was compared. So a commit that removed a state named `signed` which no
    # signature stood behind introduced a state named `source_verified` which no bytes verified.
    #
    # These states now say what the pass actually DID. Byte verification and human review are real
    # and different things; when either exists it gets its own field, not a reused word.
    "provenance": (
        ("identifier_resolved", "a PMID or DOI resolved against PubMed or the publisher page"),
        ("web_discovered", "identity came from live web-search results carrying the identifier"),
        ("in_house_reference", "not literature — a concept stated on a pack's own drafting surface"),
        ("identifier_unresolved", "no PMID or DOI could be resolved; journal/volume/pages only"),
    ),
}
# Rank WITHIN a domain. There is deliberately no cross-domain rank: `attributed` and
# `component_parity` are not comparable, and a single number would imply they were.
STATE_RANK = {d: {n: i for i, (n, _) in enumerate(ladder)} for d, ladder in STATES.items()}
ALL_STATES = {n for ladder in STATES.values() for n, _ in ladder}


def state_error(domain, state):
    """Why `state` may not be used for `domain`, or None. The vocabularies do not overlap."""
    if domain not in STATES:
        return f"unknown domain {domain!r} — one of {sorted(STATES)}"
    if state not in STATE_RANK[domain]:
        return (f"state {state!r} does not belong to domain {domain!r}; that domain's states are "
                f"{[n for n, _ in STATES[domain]]}. States are per-domain so a surface cannot "
                f"borrow a stronger domain's word for weaker evidence")
    return None
KINDS = ("decision", "precedent", "contract_record", "capability", "inventory", "citation")


def _matches(hay: str, wants) -> int:
    """Substring over the whole haystack, all terms required; the score is total occurrences.

    Substring rather than tokens for the reason `knowledge_graph.query` gives: a searcher types
    fragments, and a search that misses a fragment teaches people not to ask.
    """
    hay = hay.lower()
    if not all(w in hay for w in wants):
        return 0
    return sum(hay.count(w) for w in wants)


def _hit(kind, domain, state, ident, where, title, detail, score):
    return {"kind": kind, "domain": domain, "state": state, "id": ident, "where": where,
            "title": " ".join((title or "").split()),
            "detail": " ".join((detail or "").split()), "score": score}


def _decisions(wants, root):
    import knowledge_graph as kg
    out = []
    for n in kg.build(root):
        score = _matches(" ".join((n["id"], n["question"], n["evidence"], n["answer"])), wants)
        if not score:
            continue
        if kg.ruled(n):
            # `ruled()` means a NAMED approver and a usable date are recorded — typed, by a person,
            # and not bound to anything. `attributed` says exactly that. `authenticated` is the
            # state above it and nothing in this repository can reach it yet: it needs the
            # attribution bound to a signature, which `approval_identity.py` reports as 0 of 6.
            state, note = "attributed", f"ruled by {n['approved_by']} on {n['approval_date']}"
        elif kg.resolved_unsigned(n):
            state, note = "answered_unattributed", \
                "RESOLVED with no named approver or no usable date"
        else:
            state, note = "open", n["status"] or "OPEN"
        out.append(_hit("decision", "product_ruling", state, n["id"], n["pack"], n["question"],
                        f"{note}. {n['answer']}" if n["answer"] else note, score))
    return out


def _precedents(wants, root):
    import precedents as store
    entries, _ = store.load(root)
    cache = {}
    out = []
    for e in entries:
        score = _matches(" ".join((e.get("id", ""), e.get("question", ""))), wants)
        if not score:
            continue
        graded = store.strength(e, root, cache)
        # The precedent store's OWN authority axis decides the search state: an entry every pack has
        # signed is a ruling wherever you meet it, and one resting on open questions is an open
        # question. REACH is deliberately not consulted — how far a question travelled says nothing
        # about whether its answer was signed, and mapping the collapsed tier used to let a
        # single-tumour entry read `open` however well its answers were attested.
        state = {"ruling": "attributed", "answer": "answered_unattributed",
                 "partial": "answered_unattributed"}.get(graded.authority, "open")
        out.append(_hit("precedent", "product_ruling", state, e.get("id", "?"),
                        "governance/precedents.yaml", e.get("question", ""),
                        f"[reach: {graded.reach}] [authority: {graded.authority}] "
                        f"{store.corroboration(e)}", score))
    return out


def _contract_approval(pack, root):
    """(approver, date) from a pack's Gate 2 approval form, or ("", "").

    The evidence `_contract_records` used to assert without reading. Held to `not_a_person` and
    `bad_date` — the same predicates every gate uses — so a team name or an unusable date leaves
    the record `answered_unattributed` rather than promoting it on a string somebody typed.
    """
    from product_gates import bad_date, not_a_person, read_yaml, unstated
    doc, err = read_yaml(os.path.join(root, pack, "handoff", "CONTRACT_APPROVAL.yaml"))
    if err or not isinstance(doc, dict):
        return "", ""
    who, when = str(doc.get("approved_by") or ""), str(doc.get("approval_date") or "")
    if unstated(who) or not_a_person(who) or unstated(when) or bad_date(when):
        return "", ""
    return who, when


def _contract_records(wants, root):
    import glob
    from contract_lint import read, records, _scalar, _list, _kv, _inline
    out = []
    pattern = os.path.join(root, "products", "*", "*", "*", "handoff", "FUNCTIONAL_CONTRACT.md")
    for path in sorted(glob.glob(pattern)):
        pack = repo_relative(os.path.dirname(os.path.dirname(path)), root)
        for block in records(read(path)):
            vid = _scalar(block, "variable_id") or "?"
            rule = _scalar(block, "required_rule") or ""
            req = (_kv(_inline(block, "status"), "requirement") or "").strip()
            score = _matches(" ".join((vid, rule, block)), wants)
            if not score:
                continue
            # THE RECORD'S OWN WORD IS NOT THE EVIDENCE. `requirement: approved` used to become
            # `signed` — a state defined as "a named person and a usable date stand behind it" —
            # while this function read no approver, no date, and no approval file. It could not
            # have: it imports only readers. So `approved` now buys `attributed` ONLY when the
            # pack's Gate 2 approval form actually names somebody and dates it; otherwise the
            # record is answered with nobody recorded, which is what it is.
            if req == "decision_required":
                state, why = "open", "decision_required"
            elif req == "approved":
                who, when = _contract_approval(pack, root)
                if who and when:
                    state, why = "attributed", f"approved_by {who} on {when}"
                else:
                    state, why = "answered_unattributed", (
                        "requirement:approved but handoff/CONTRACT_APPROVAL.yaml names no "
                        "approver+date")
            else:
                state, why = "answered_unattributed", f"requirement:{req or '?'}"
            cited = ", ".join(_list(block, "decision_ids") or []) or "no decisions cited"
            out.append(_hit("contract_record", "product_ruling", state, vid, pack, rule,
                            f"{why} · {cited}", score))
    return out


def _capabilities(wants, root):
    import capability_registry as cr
    out = []
    for cap in (cr.load().get("capabilities") or []):
        blob = " ".join([cap.get("id", ""), cap.get("master", ""), cap.get("summary", ""),
                         " ".join(cap.get("config_keys") or []),
                         " ".join(cap.get("emits") or []), cap.get("limits") or ""])
        score = _matches(blob, wants)
        if not score:
            continue
        detail = f"config {', '.join(cap.get('config_keys') or [])} → " \
                 f"{', '.join(cap.get('emits') or [])}"
        if cap.get("limits"):
            detail += f" · LIMITS: {cap['limits']}"
        # THE REGISTRY'S OWN LADDER, not a translation of it. This used to collapse every
        # verification state that was not `declared` into `signed` — so a unit-tested capability
        # read as though a person had signed it, in the domain whose description says
        # implementation evidence cannot settle what a variable should mean however well tested.
        # The WEAKEST of the two engines decides: a capability is only as compared as its
        # least-compared side, which is exactly the CCI case (Python tested, R merely declared).
        v = cap.get("verification") or {}
        rank = STATE_RANK["implementation_evidence"]
        states = [s for s in (v.get("python"), v.get("r")) if s in rank]
        state = max(states, key=lambda s: rank[s]) if states else "declared"
        detail = f"verified py={v.get('python', '?')} / r={v.get('r', '?')} · " + detail
        out.append(_hit("capability", "implementation_evidence", state, cap.get("id", "?"),
                        "platform/capabilities.yaml", cap.get("summary", ""), detail, score))
    return out


def _inventory(wants, root):
    import citation_register as cite
    doc = cite._load(cite.INVENTORY)
    out = []
    for slug, t in sorted((doc.get("tumours") or {}).items()):
        for v in t.get("variables") or []:
            blob = " ".join([v.get("name", ""), v.get("definition_sketch", ""),
                             v.get("common_sources", ""), v.get("master") or ""])
            score = _matches(blob, wants)
            if not score:
                continue
            cov = v.get("coverage") or {}
            # A shelf entry's BASIS travels with it. A `workbook_confirmed` entry is still
            # `reference_only` — the shelf authorises nothing — but a reader deciding whether to
            # lean on it needs to know which of the three bases it rests on.
            basis = cite.basis_of(v)
            # THE BASIS IS THE STATE. `reference_only` for everything erased the distinction the
            # basis exists to record: a variable a named person confirmed against the approved
            # workbook is further along than one inferred from literature. It is still a drafting
            # aid — that is the DOMAIN's job to say, and `literature` authorises nothing whatever
            # its state — but a reader deciding how hard to lean needs the difference.
            state = {"workbook_confirmed": "human_reviewed",
                     "literature_inferred": "bibliographic_only",
                     "in_house_drafting": "reference_only"}.get(basis, "reference_only")
            out.append(_hit("inventory", "literature", state, v.get("name", "?"),
                            f"variable_inventory:{slug}", v.get("definition_sketch", ""),
                            f"basis:{basis} · coverage:{cov.get('class', '?')} · "
                            f"{cov.get('via', '')}", score))
    return out


def _citations(wants, root):
    import citation_register as cite
    reg, inv = cite._load(cite.REGISTER), cite._load(cite.INVENTORY)
    used = cite.uses(inv)
    out = []
    for rec in reg.get("citations") or []:
        score = _matches(rec["text"], wants)
        if not score:
            continue
        # THE ROUTE IS THE STATE, and now it is the SAME WORD. The mapping used to translate each
        # route into a stronger-sounding name — `pubmed_or_publisher` became `source_verified`,
        # `in_house_drafting_surface` became `human_attested` — which asserted byte verification and
        # human review that CITATIONS.yaml states outright did not happen. A translation layer
        # between what a pass did and what its state is called is where overstatement lives, so
        # there is no longer one: the route IS the state, and an unknown route is refused rather
        # than defaulted into a name that would claim something.
        state = {"pubmed_or_publisher": "identifier_resolved",
                 "web_search_result": "web_discovered",
                 "in_house_drafting_surface": "in_house_reference",
                 "identifier_route_unavailable": "identifier_unresolved"}.get(rec["route"])
        if state is None:
            raise ValueError(
                f"citation route {rec['route']!r} has no provenance state. Add it to STATES and to "
                f"this mapping deliberately — defaulting an unrecognised route into an existing "
                f"state is how a pass acquires a strength nobody gave it.")
        out.append(_hit("citation", "provenance", state, rec["text"][:60],
                        "variable_inventory:CITATIONS.yaml", rec["text"],
                        f"route:{rec['route']} · cited by "
                        f"{', '.join(sorted(used.get(rec['text'], set())))}", score))
    return out


FINDERS = {"decision": _decisions, "precedent": _precedents, "contract_record": _contract_records,
           "capability": _capabilities, "inventory": _inventory, "citation": _citations}


def surface_errors(root=ROOT):
    """{kind: [why this surface may not be ranked]} — each through its OWN validator.

    FAIL CLOSED, because ranking is a claim. A capability hit was reported `checked_claim` without
    anyone calling `registry_errors`, which is the claim the registry exists to make: the search was
    asserting for free the very thing the registry checks. A surface whose validator is unhappy is
    now REPORTED as unusable and excluded from the results, rather than contributing hits that carry
    a state nothing stands behind. The reader is told which surface they did not get.
    """
    out = {}
    try:
        import capability_registry as cr
        errs = cr.registry_errors(cr.load(), cr.inventory_classes())
        if errs:
            out["capability"] = errs
    except Exception as exc:                     # noqa: BLE001 - a broken surface is a finding
        out["capability"] = [f"registry could not be read: {exc}"]
    try:
        import citation_register as cite
        errs = cite.register_errors(cite._load(cite.REGISTER), cite._load(cite.INVENTORY))
        errs += cite.provenance_errors(cite._load(cite.INVENTORY))
        if errs:
            out["citation"] = errs
            out["inventory"] = errs
    except Exception as exc:                     # noqa: BLE001
        out["citation"] = out["inventory"] = [f"citation register could not be read: {exc}"]
    try:
        import precedents as store
        errs = store.errors(root)
        if errs:
            out["precedent"] = errs
    except Exception as exc:                     # noqa: BLE001
        out["precedent"] = [f"precedent store could not be read: {exc}"]
    # THE TWO SURFACES THIS FUNCTION USED TO SKIP. Its docstring says every surface goes through
    # its own validator; `decision` and `contract_record` went through none, so a malformed
    # register or contract contributed hits that were ranked exactly like validated ones. A
    # validator list that quietly omits two of six surfaces is the same defect as a check that
    # compares nothing: it reports clean because it never looked.
    try:
        import contract_lint as cl
        import glob
        errs = []
        for path in sorted(glob.glob(os.path.join(root, "products", "*", "*", "*", "handoff",
                                                  "DECISIONS.md"))):
            text = cl.read(path)
            rel = repo_relative(path, root)
            # A register whose rows cannot be read is not an empty register.
            if cl.decision_rows(text) == {} and text.strip():
                errs.append(f"{rel}: no decision rows could be read from a non-empty register")
        if errs:
            out["decision"] = errs
    except Exception as exc:                     # noqa: BLE001
        out["decision"] = [f"decision registers could not be read: {exc}"]
    try:
        import contract_lint as cl
        import glob
        errs = []
        for path in sorted(glob.glob(os.path.join(root, "products", "*", "*", "*", "handoff",
                                                  "FUNCTIONAL_CONTRACT.md"))):
            rel = repo_relative(path, root)
            blocks = list(cl.records(cl.read(path)))
            missing = [b for b in blocks if not cl._scalar(b, "variable_id")]
            if missing:
                errs.append(f"{rel}: {len(missing)} record block(s) carry no variable_id — a "
                            f"record nothing can be keyed by cannot be ranked")
        if errs:
            out["contract_record"] = errs
    except Exception as exc:                     # noqa: BLE001
        out["contract_record"] = [f"contract records could not be read: {exc}"]
    return out


def search(terms, kinds=None, root=ROOT, skip=None, unusable=None):
    """Ranked hits. VALIDATES ITSELF unless the caller has already done it.

    `skip` used to be the only way an unusable surface was excluded, and only `main` computed it —
    so every programmatic caller of `search()` got hits from surfaces that had passed no validator,
    ranked identically to validated ones. Fail-closed has to live in the API, not in one CLI
    wrapper, or it is a convention rather than a property. Pass `unusable=` (from `surface_errors`)
    to reuse a validation you already ran; omit it and this runs one.
    """
    wants = [t.lower() for t in terms if t.strip()]
    if not wants:
        return []
    if unusable is None:
        unusable = surface_errors(root)
    skip = set(skip or ()) | set(unusable or {})
    hits = []
    for kind in (kinds or KINDS):
        if kind in skip:
            continue
        hits.extend(FINDERS[kind](wants, root))
    # ...and no hit may leave here carrying a state its domain does not define. A surface reaching
    # for another domain's word is exactly how `signed` spread to evidence that had no signature.
    for h in hits:
        why = state_error(h["domain"], h["state"])
        if why:
            raise ValueError(f"{h['kind']} hit {h['id']!r}: {why}")
    # DOMAIN first, then state. Never one flat rank: an implementation_evidence hit above an unsigned
    # product_ruling would read as outranking it, and it cannot — they answer different questions.
    return sorted(hits, key=lambda h: (DOMAIN_RANK.get(h["domain"], 99),
                                       STATE_RANK.get(h["domain"], {}).get(h["state"], 99),
                                       -h["score"], h["kind"], h["where"], h["id"]))


def render(terms, hits, kinds=None, unusable=None) -> str:
    L = [f"KNOWLEDGE SEARCH  {' '.join(terms)}",
         f"  surfaces: {', '.join(kinds or KINDS)}",
         ""]
    for kind, errs in sorted((unusable or {}).items()):
        L.append(f"  !! {kind} EXCLUDED — its own validator refuses it, so nothing from it is "
                 f"ranked here:")
        for e in errs[:3]:
            L.append(f"       {e}")
        if len(errs) > 3:
            L.append(f"       …and {len(errs) - 3} more")
        L.append("")
    if not hits:
        L += ["  no hits.",
              "",
              "  That is not the same as \"nothing has been decided\" — it means these words do not",
              "  appear in any register, record, shelf entry or capability. Try a fragment "
              "(`biomark`),",
              "  or the term of art the specification would use rather than the one you would.",
              ""]
    counts = {}
    for h in hits:
        counts[h["domain"]] = counts.get(h["domain"], 0) + 1
    if hits:
        L.append(f"  {len(hits)} hit(s), by DOMAIN — different KINDS of authority, not degrees of "
                 f"one:")
        for name, meaning in DOMAIN:
            if counts.get(name):
                L.append(f"      {name:24} {counts[name]:>3}  {meaning}")
        L.append("")
    L += ["  NOTHING BELOW IS AN APPROVAL. An `attributed` product_ruling was decided for the pack it",
          "  belongs to, against that pack's workbook; carrying it into another product is a new",
          "  decision that a person makes. And implementation_evidence never settles a methodology",
          "  question however well tested it is — it says what the engine DOES, not what a variable",
          "  should MEAN.",
          ""]
    for h in hits:
        L.append(f"  [{h['domain']}/{h['state']}] {h['kind']}  {h['id']}")
        L.append(f"      {h['where']}")
        if h["title"]:
            L.append(f"      {h['title'][:300]}")
        if h["detail"]:
            L.append(f"      → {h['detail'][:300]}")
        L.append("")
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("terms", nargs="*", help="all terms must appear (substring, case-insensitive)")
    ap.add_argument("--kind", action="append", choices=KINDS, dest="kinds",
                    help="restrict to a surface; repeatable. Default: all six")
    ap.add_argument("--json", action="store_true", help="typed hits as JSON, for another tool")
    a = ap.parse_args(argv)
    if not a.terms:
        ap.error("give at least one term")
    unusable = surface_errors()
    hits = search(a.terms, a.kinds, skip=set(unusable))
    if a.json:
        print(json.dumps({"terms": a.terms, "kinds": a.kinds or list(KINDS),
                          "domain_order": [n for n, _ in DOMAIN],
                          # PER DOMAIN, because that is what the ranking now is. A flat list here
                          # would tell a JSON consumer the old story the code no longer tells.
                          "state_order": {d: [n for n, _ in ladder]
                                          for d, ladder in STATES.items()},
                          "excluded_surfaces": {k: v for k, v in unusable.items()},
                          "hits": hits}, indent=2))
    else:
        print(render(a.terms, hits, a.kinds, unusable))
    # A surface excluded because its own validator refuses it is a finding, not a clean run.
    return 1 if unusable else 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
