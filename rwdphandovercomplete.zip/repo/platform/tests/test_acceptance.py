#!/usr/bin/env python3
"""CAN A STRANGER RUN THIS? The standalone-package claim, executed rather than asserted.

The claim is not "the tests pass". It is that somebody who did not write this can clone it, check
their environment, walk the demonstration, resolve one question, produce an evidence file, and come
away with a correct understanding of what was and was not shown. Every suite beside this one runs
INSIDE the developer's checkout, and the three ways that claim fails are all invisible from there:

  A FILE THAT WAS NEVER COMMITTED. The package is materialised from `git ls-files` — the file set a
  clone actually receives — so a tool that works only because of something sitting untracked in the
  author's working directory fails here and nowhere else. This is the defect no amount of in-tree
  testing can see, because in-tree the file is present.

  A PATH THE CODE CANNOT HOLD. It is materialised under a directory whose name carries spaces and
  characters outside cp1252. `Program Files`, `OneDrive - <Company>` and a person's own name are the
  ordinary cases, and the failures are `subprocess` argument quoting and a path encoded through a
  Windows code page — neither of which a developer with an all-ASCII, space-free checkout will meet.

  TEMPORARY FILES ASSUMED TO BE NEARBY. TMPDIR is pointed at a root OUTSIDE the package, which is the
  portable statement of "the repository is on D: and the temp directory is on C:". Code that builds a
  temp path by joining to the package root, or that renames across what is one filesystem here and
  two there, breaks only in that arrangement.

...and it runs under a NON-UTF-8 IO encoding, because the console defect this repository has actually
had appears on redirect under a code page and not in an interactive terminal.

WHAT IT ASSERTS IS THE JOURNEY, not the internals. Each step is a command from the runbook, run as a
person types it, checked for the thing that step is FOR: the doctor names what is missing, the demo
reaches its gate tally, the authoring path can still resolve a decision, the renderer writes a page
that names no vendor table, and the demonstration states in its own words what it did not show. The
properties of each tool belong to that tool's suite; duplicating them here would be a second opinion
that eventually disagrees.

Slow by construction — it copies the tracked tree and runs four real tools over it. That is the cost
of the only test that answers the question, and the question is the handover.
"""
import os
import shutil
import sys
import tempfile
import textwrap
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
TOOLS = REPO / "platform" / "tools"
sys.path.insert(0, str(TOOLS))

import console                                                                  # noqa: E402

# SPACES, AND A CHARACTER cp1252 CANNOT ENCODE. `ü` is in cp1252 and `ō` is not, so the pair covers
# both the path a Windows code page mangles and the one it silently survives. No emoji and no
# character outside the BMP: this must be a directory name every filesystem in scope can hold, and a
# test that fails because of an exotic glyph reports a defect nobody has.
HOSTILE = "rwdp acceptance ünïcōde"

# The pack the runbook demonstrates. Asserted to exist rather than assumed: a rename would otherwise
# turn every step below into a silent skip.
PACK = "products/oncology/prostate/202606"

# A NON-UTF-8 CONSOLE, on purpose. `console.use_utf8()` reconfigures the streams after startup and
# is supposed to make this irrelevant; that is the claim, and this is where it is paid for.
CODEPAGE = "cp1252:replace"


def _package(dest):
    """Materialise the package at `dest` from the checkout's TRACKED FILES, with a clean git state.

    `git ls-files` rather than `shutil.copytree`, and the difference IS the test: copytree carries
    whatever is lying in the working directory, which is precisely the condition being ruled out. A
    tracked path that does not exist on disk is a hard error here — a partially deleted checkout
    would otherwise produce a package missing a tool and a failure several steps later.

    Then `git init` + one commit, because the packaging steps read HEAD and refuse a dirty or
    unresolvable tree. The commit's SHA is not the origin's, which is correct: what is under test is
    the CONTENT of the working tree, not the last thing that happened to be pushed.
    """
    listing = console.run(["git", "-C", str(REPO), "ls-files", "-z"],
                          binary=True, capture_output=True)
    assert listing.returncode == 0, f"git ls-files failed in {REPO}"
    names = [n.decode("utf-8") for n in listing.stdout.split(b"\0") if n]
    assert len(names) > 300, f"only {len(names)} tracked files — this is not the whole package"

    for name in names:
        src = REPO / name
        assert src.exists(), f"tracked but not on disk: {name}"
        out = dest / name
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, out)

    for argv in (["init", "-q"], ["add", "-A"],
                 ["-c", "user.email=a@b.c", "-c", "user.name=acceptance",
                  "commit", "-q", "-m", "acceptance package"]):
        p = console.run(["git", "-C", str(dest)] + argv, capture_output=True)
        assert p.returncode == 0, f"git {argv[0]} failed in the package: {p.stderr}"
    return len(names)


def _env(tmp_root):
    """The child's environment: temp files OUTSIDE the package, and a code page on the streams."""
    env = dict(os.environ)
    env["TMPDIR"] = env["TEMP"] = env["TMP"] = str(tmp_root)
    env["PYTHONIOENCODING"] = CODEPAGE
    env.pop("PYTHONPATH", None)          # a stranger has none; ours would hide a missing sys.path fix
    return env


def _step(pkg, tmp_root, *argv, expect=0):
    """One command, as the runbook gives it — from the package root, never from ours."""
    p = console.run([sys.executable] + list(argv), cwd=str(pkg), env=_env(tmp_root),
                    capture_output=True)
    out = (p.stdout or "") + (p.stderr or "")
    assert p.returncode == expect, \
        f"`{' '.join(argv)}` exited {p.returncode}, wanted {expect}:\n{out[-3000:]}"
    return out


def test_a_stranger_can_run_this_package_from_a_clean_clone():
    """The whole journey, in one test, because the journey is what the claim is about.

    Split into six tests it would read better and prove less: each step consumes the package the
    previous one produced, and a suite that rebuilt it per step would be six minutes of copying to
    assert the same thing once.
    """
    # TWO ROOTS, not two directories under one. `mkdtemp` twice gives temp files a parent that is not
    # an ancestor of the package, which is the arrangement the code has to survive.
    with tempfile.TemporaryDirectory() as a, tempfile.TemporaryDirectory() as b:
        pkg = Path(a) / HOSTILE
        tmp_root = Path(b) / "elsewhere"
        pkg.mkdir(parents=True)
        tmp_root.mkdir(parents=True)
        assert not str(tmp_root).startswith(str(pkg)), "temp root is inside the package"

        files = _package(pkg)
        assert (pkg / PACK).is_dir(), f"{PACK} is not in the package — the runbook demonstrates it"

        # 1 — THE ENVIRONMENT CHECK, and it must be the thing that reports a problem rather than the
        #     thing that has one. `--out-dir` outside the package, as every restricted write must be.
        out_dir = Path(b) / "rwdp-out"
        doctor = _step(pkg, tmp_root, "platform/tools/doctor.py", "--out-dir", str(out_dir))
        assert "READY" in doctor, f"doctor did not report ready:\n{doctor[-2000:]}"
        for subject in ("Python", "pyyaml", "git", "output directory", "console encoding"):
            assert subject in doctor, f"doctor never checked {subject!r}"

        # 2 — THE WALKTHROUGH. Its own gate tally, not one recomputed here: `demo.py` owns that
        #     number and a second count in this file would be the one that goes stale.
        demo = _step(pkg, tmp_root, "platform/tools/demo.py", PACK)
        assert "gate step(s) passed" in demo, f"demo produced no tally:\n{demo[-2000:]}"

        # 3 — ...AND IT SAYS WHAT IT DID NOT SHOW. A stranger coming away believing a build was
        #     demonstrated is the specific failure this whole package exists to prevent, and the
        #     sentence that prevents it is printed by the demo rather than by a person presenting it.
        assert "WHAT YOU DID NOT JUST SEE" in demo, "the demo made no claim boundary at all"
        for unshown in ("A BUILD", "AN APPROVAL", "VENDOR DATA"):
            assert unshown in demo, f"the demo did not disclaim {unshown!r}"

        # 4 — THE QUESTIONS A PERSON ANSWERS. The worksheet is what a reviewer opens; it must render
        #     from the package, over a real contract, without the checkout it was written in.
        work = _step(pkg, tmp_root, "platform/tools/worksheet.py", PACK)
        assert len(work) > 1000, f"worksheet printed almost nothing:\n{work}"

        # 5 — RESOLVING ONE. The authoring suite is INVOKED, not reimplemented: it already walks
        #     scaffold -> open decision -> derived status -> --apply -> lint -> idempotent re-run, and
        #     a second copy of that sequence here would be the copy that drifts. What this adds is
        #     the environment — it has never run from a packaged tree, under a code page, with temp
        #     files on another root, and every one of those is where it would break for a stranger.
        author = _step(pkg, tmp_root, "platform/tests/test_authoring.py")
        assert "passed" in author.lower(), f"the authoring path did not pass:\n{author[-2000:]}"

        # 6 — THE EVIDENCE FILE, written where restricted output belongs: outside the package. That
        #     it renders is half the check; that it carries no vendor table name is the half that
        #     makes it forwardable, and it is re-earned here because this is a different tree.
        page = out_dir / "rules.html"
        _step(pkg, tmp_root, "platform/tools/render_html.py", "rules", PACK, "--out", str(page))
        assert page.exists(), "render_html reported success and wrote nothing"
        html = page.read_text(encoding="utf-8")
        assert len(html) > 5000, f"the evidence page is {len(html)} bytes — it rendered nothing"
        # ASKED OF THE PACKAGE, in the package's own interpreter. Importing the packaged renderer
        # into THIS process would put its modules beside ours in `sys.modules` and answer half the
        # question with the developer's checkout — and the leftover `sys.path` entry outlives the
        # temp directory, so the next test in the session imports from a directory that is gone.
        verdict = _step(pkg, tmp_root, "-c", _VENDOR_PROBE, str(page), PACK)
        assert verdict.strip().endswith("[]"), \
            f"the packaged renderer put vendor table(s) on the page: {verdict.strip()}"

        # ...and nothing restricted was left in the package, which is the rule the whole output
        # convention exists for and the easiest one to lose when a path is assembled somewhere new.
        stray = [str(p.relative_to(pkg)) for p in pkg.rglob("*.html")]
        assert not stray, f"the package now contains generated page(s) {stray}"

        assert files > 300 and len(demo) > 2000, "the run was too small to have proved anything"


# The packaged renderer's own answer about its own output. Run with `-c` from the package root so
# every import — render_html, and the worksheet and engine modules it reaches — resolves inside the
# package rather than half here and half there.
_VENDOR_PROBE = (
    "import sys; sys.path.insert(0, 'platform/tools')\n"
    "import render_html\n"
    "print(render_html.vendor_tables("
    "open(sys.argv[1], encoding='utf-8').read(), sys.argv[2]))\n"
)


def test_the_vscode_menu_offers_only_steps_this_journey_actually_walks():
    """The launch surface for someone who will not open a terminal, held to the tested journey.

    A task list is the first thing a colleague touches and the last thing anybody re-reads, so its
    failure mode is a label pointing at a tool that has since moved — discovered by the person you
    handed this to, which is the one place it must not be. Two directions, and both matter:

      every task names a script that EXISTS, and
      every task names a tool the acceptance journey above actually runs.

    The second is what stops the menu from growing an unproven step. A button that has never been
    executed by anything is a claim, and this repository's whole argument is that a claim nobody ran
    is not evidence.
    """
    import json
    import re
    raw = (REPO / ".vscode" / "tasks.json").read_text(encoding="utf-8")
    # JSON with comments — VS Code's dialect. Stripped rather than banned: the comments say WHY each
    # task exists, and a config file people must not annotate is one they stop reading.
    tasks = json.loads(re.sub(r"^\s*//.*$", "", raw, flags=re.M))["tasks"]
    assert len(tasks) >= 4, f"only {len(tasks)} task(s) — the menu does not cover the journey"

    walked = _journey_tools()
    assert len(walked) >= 4, f"only {len(walked)} tool(s) in the journey — the scan broke"
    for task in tasks:
        for key, command in [("posix", task["command"])] + \
                            [("windows", task["windows"]["command"])]:
            script = next((w for w in command.replace("\\", "/").split() if w.endswith(".py")), None)
            assert script, f"{task['label']} ({key}) runs no .py script: {command}"
            assert (REPO / script).exists(), f"{task['label']} ({key}) names {script}, which is gone"
            assert Path(script).name in walked, \
                f"{task['label']} ({key}) runs {script}, which the acceptance journey never walks — " \
                "either add it to the journey or take it off the menu"


def _journey_tools():
    """{tool.py} the journey above runs — read from THIS FILE's own `_step` calls, not listed twice.

    Parsed rather than restated: a second list would be the one that stops matching the test it is
    supposed to describe, and it would stop matching in the direction of approving a task.
    """
    import ast
    names = set()
    tree = ast.parse(Path(__file__).read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and getattr(node.func, "id", None) == "_step":
            for arg in node.args:
                if isinstance(arg, ast.Constant) and str(arg.value).endswith(".py"):
                    names.add(os.path.basename(str(arg.value)))
    return names


def test_the_doctor_survives_the_machine_it_exists_to_diagnose():
    """A DIAGNOSTIC MAY NOT DIE OF THE THING IT DIAGNOSES.

    The first version imported `pack_run` for its output-directory check. `pack_run` imports
    `product_gates` and `engine.config`, both of which import yaml — so on a machine with no PyYAML
    this tool exited with an ImportError traceback having printed NOTHING. Not the row saying PyYAML
    is missing; not any row. The one situation it exists for was the one situation it could not
    report, and CI never saw it because CI installs the dependencies first.

    So the dependency is genuinely blocked here, at `find_spec`, and the tool is required to name
    what is missing and exit non-zero. `sys.modules`-poking would not do: `importlib.util.find_spec`
    is what the check calls, and a probe that does not go through it proves nothing — an earlier
    version of this test used the legacy `find_module` hook and watched the doctor report `ok pyyaml`
    while yaml was supposedly absent.
    """
    blocked = textwrap.dedent("""
        import sys
        class Block:
            def find_spec(self, name, path=None, target=None):
                if name.split(".")[0] in ("yaml", "_yaml"):
                    raise ModuleNotFoundError("No module named %r" % name)
                return None
        sys.meta_path.insert(0, Block())
        sys.argv = ["doctor.py"]; sys.path.insert(0, "platform/tools")
        import runpy; runpy.run_path("platform/tools/doctor.py", run_name="__main__")
    """)
    p = console.run([sys.executable, "-c", blocked], cwd=str(REPO), capture_output=True)
    out = (p.stdout or "") + (p.stderr or "")
    assert "Traceback" not in out, f"the doctor crashed on a machine with no PyYAML:\n{out[-2500:]}"
    assert p.returncode == 1, f"a missing REQUIRED dependency must exit 1, got {p.returncode}:\n{out}"
    assert "REQUIRED thing(s) missing" in out and "pyyaml" in out, \
        f"the doctor did not name the missing dependency:\n{out}"
    # ...and it got PAST the failure to the rest of the report. A tool that stops at the first
    # problem makes a person fix one thing, re-run, fix the next — which is the experience this
    # exists to replace.
    for later in ("git", "output directory", "console encoding"):
        assert later in out, f"the doctor stopped before checking {later!r}"


def test_the_doctor_reports_a_broken_environment_rather_than_crashing_in_it():
    """A check that only ever runs green is a check nobody has seen work.

    The two REQUIRED failures a stranger actually hits are a missing dependency and an output
    directory they cannot use, so both are provoked: `requirements` is asked about a file naming a
    package nobody has, and `restricted_dir` is pointed inside the checkout — which is the control
    refusing, not a bug, and the doctor must say so in those terms rather than exit non-zero silently.
    """
    import doctor
    rows = doctor.checks(out_dir=str(REPO / "some" / "output"))
    bad = [r for r in rows if r[0] == doctor.MISSING]
    assert any("inside the checkout" in r[2] for r in bad), \
        f"the doctor accepted an output directory inside the checkout: {rows}"

    with tempfile.TemporaryDirectory() as d:
        req = Path(d) / "requirements.txt"
        req.write_text("no-such-distribution>=1.0   # a comment\n\npyyaml>=6.0\n", encoding="utf-8")
        parsed = doctor.requirements(str(req))
        assert ("no-such-distribution", "no_such_distribution") in parsed, parsed
        # THE NAME PIP USES IS NOT THE NAME PYTHON IMPORTS. Reporting `pyyaml` missing on a machine
        # that has it is how an environment check trains people to ignore it.
        assert ("pyyaml", "yaml") in parsed, parsed


if __name__ == "__main__":
    # The rule this suite spends its runtime enforcing, applied to itself: the summary below carries
    # an em dash, CI's Linux step runs these standalone with output redirected, and a suite that
    # crashed printing its own result would be a fine joke at the worst moment.
    console.use_utf8()
    failed = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"ok   {name}")
            except AssertionError as err:
                failed += 1
                print(f"FAIL {name}\n     {err}")
    print(f"\n{'FAILED' if failed else 'OK'} — {failed} failure(s)")
    sys.exit(1 if failed else 0)
