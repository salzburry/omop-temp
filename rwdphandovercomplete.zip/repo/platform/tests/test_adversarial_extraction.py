"""A hostile program specification, scored: what survived, what was reported, what vanished.

`spec_extract` documents its own qualification boundary — whitespace stripped, formulas read from
cache, the header taken as the first row with three populated cells, merges and hidden rows
REPORTED rather than read. Those limits were established against the prostate template. This suite
asks the question that matters when a new and more complex workbook arrives: WHEN A LIMIT BITES,
DOES ANYTHING SAY SO?

Three outcomes, and only one of them is a defect:

    EXTRACTED   the text came through; a reader can see it
    REPORTED    the text was lost or altered, and workbook_structure/spec_lint says so
    SILENT      the text was lost or altered and nothing anywhere indicates it

TWO SILENT LOSSES WERE FOUND BY THIS FIXTURE, and both are fixed:

  * A FULL-WIDTH MERGE SPANNING SEVERAL ROWS deleted two requirement rows and reported nothing.
    `workbook_structure` exempted every full-width merge as a banner — true of a merge one row
    tall, false of one that covers the rows beneath it, since a merge blanks every non-anchor cell
    in its rectangle. `A6:H8` over three real rows returned `{}` while two requirements vanished.

  * THE DUPLICATE-NAME CHECK COULD NOT SEE SHORT NAMES. `_VARLIKE` requires four characters,
    correctly, because it also scans prose. `_duplicate_variables` reads the VARIABLE COLUMN, where
    that floor bought nothing and hid `OS`, `PFS`, `RAS`, `MSI`, `AGE` — most of the variables an
    oncology specification argues hardest about. `OS` defined on two tabs with contradictory
    censoring rules drew no finding, while the four-letter `TTNT` beside it drew one.

The fixture is built in a temp directory and deleted. It is synthetic throughout — no vendor
material, no delivered data — and must never be registered as any pack's specification.

Needs openpyxl. Run: python3 platform/tests/test_adversarial_extraction.py (or pytest).
"""
import json
import os
import re
import shutil
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))
sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))

try:
    import openpyxl  # noqa: F401
    HAVE = True
except Exception:                                                        # noqa: BLE001
    HAVE = False

import spec_extract as se     # noqa: E402
import spec_lint as sl        # noqa: E402

_BUILT = []


def _workbook():
    """Built once per process, in a temp directory, and removed at exit."""
    if not HAVE:
        return None
    if not _BUILT:
        import adversarial_spec
        d = tempfile.mkdtemp(prefix="adversarial_spec_")
        _BUILT.append((adversarial_spec.build(os.path.join(d, "adversarial_mcrc.xlsx")), d))
    return _BUILT[0][0]


def _extracted(path):
    """Through `se.extract`, the CLI's own entry point — NOT `read_xlsx`.

    `read_xlsx` returns rows with no domain and therefore no `item_id`, so a suite built on it
    scores the cross-row checks against rows that cannot be cited. The first version of this file
    did exactly that and every `domain`-keyed assertion in it was vacuous.
    """
    return se.extract(path, domains=se.shared_domains())


def _findings(path):
    data = _extracted(path)
    return data, sl.scan(data) + sl.scan_across(data) + sl.scan_structure(data)


def _skip():
    if HAVE:
        return False
    print("  (skipped: openpyxl absent)")
    return True


# --------------------------------------------------------------- the two silent losses, closed

def test_a_full_width_merge_spanning_rows_is_reported():
    """THE FIRST SILENT LOSS. A merge blanks every non-anchor cell in its rectangle, so a
    full-width merge three rows tall deletes two whole requirement rows. Reported as a banner —
    which it is not — the deletion was invisible: `workbook_structure` returned `{}`."""
    if _skip():
        return
    import openpyxl as xl
    d = tempfile.mkdtemp()
    try:
        p = os.path.join(d, "m.xlsx")
        wb = xl.Workbook()
        ws = wb.active
        ws.title = "6. Outcomes"
        ws.append(["Time Period", "Variable", "Label", "Values", "Definition", "Additional Notes"])
        ws.append(["OUTCOME", "OS", "Overall survival", "Months", "index to death", "control"])
        ws.append(["OUTCOME", "PFS", "PFS", "Months", "index to progression", "victim"])
        ws.append(["OUTCOME", "TTNT", "TTNT", "Months", "index to next line", "victim"])
        ws.merge_cells(start_row=3, start_column=1, end_row=4, end_column=6)
        wb.save(p)

        st = se.workbook_structure(p)
        assert "6. Outcomes" in st, "a merge that deleted two requirement rows reported nothing"
        assert any("A3:F4" in m for m in st["6. Outcomes"].get("merged", [])), st

        # ...and the loss it reports is real: the victim rows come back with nothing in them.
        rows = se.extract(p, domains=se.shared_domains())["rows"]
        assert not any((r.get("fields") or {}).get("variable") == "PFS" for r in rows), \
            "the fixture did not actually delete the row — the test would prove nothing"
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_a_one_row_full_width_banner_is_still_exempt():
    """The exemption exists for a reason: without it the ovarian workbook produced six HIGH
    findings for its A1:K1 titles, and a finding everyone learns to ignore is worse than none.
    Fixing the multi-row case must not bring that back."""
    if _skip():
        return
    import openpyxl as xl
    d = tempfile.mkdtemp()
    try:
        p = os.path.join(d, "b.xlsx")
        wb = xl.Workbook()
        ws = wb.active
        ws.title = "5.Demographics"
        ws.append(["mCRC PROGRAM SPECIFICATION", None, None, None, None, None])
        ws.append(["Time Period", "Variable", "Label", "Values", "Definition", "Additional Notes"])
        ws.append(["BASELINE", "AGE", "Age", "Integer", "year(index)-birthyear", "control"])
        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=6)
        wb.save(p)
        assert se.workbook_structure(p) == {}, "a genuine one-row banner is being reported again"
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_a_two_letter_variable_defined_twice_is_caught():
    """THE SECOND SILENT LOSS. `OS` is two characters, and `_VARLIKE`'s four-character floor —
    correct where it scans prose — made it invisible in the variable COLUMN. The fixture defines
    `OS` on two tabs with contradictory censoring rules."""
    if _skip():
        return
    _data, found = _findings(_workbook())
    dupes = {re.findall(r"`([^`]+)`", f["detail"])[0]
             for f in found if f.get("kind") == "DUPLICATE_VARIABLE"}
    assert "OS" in dupes, f"a two-letter variable defined twice drew no finding: {sorted(dupes)}"
    assert "TTNT" in dupes, "the four-letter control stopped being caught"


def test_the_short_name_rule_adds_no_noise_to_the_committed_packs():
    """The fix is only worth having if it is quiet. Measured against the packs whose lint.json is
    committed and byte-compared: if this rule fired on them, `run_spec_pipeline --check` would go
    red and somebody would relax the rule rather than read the finding."""
    for pack in ("products/oncology/prostate/202606", "products/oncology/oc/202606"):
        out = REPO / pack / "spec_pipeline" / "out" / "extracted.json"
        if not out.exists():
            continue
        data = json.loads(out.read_text(encoding="utf-8"))
        by_old, by_new = {}, {}
        for r in data["rows"]:
            v = (r.get("fields") or {}).get("variable", "").strip()
            if not v:
                continue
            if sl._VARLIKE.fullmatch(v):
                by_old.setdefault(v, []).append(r)
            if sl._NAMED.fullmatch(v):
                by_new.setdefault(v, []).append(r)
        old = {k for k, v in by_old.items() if len(v) > 1}
        new = {k for k, v in by_new.items() if len(v) > 1}
        assert new == old, f"{pack}: the looser rule changes the finding set: {sorted(new ^ old)}"


# ------------------------------------------------------------------- the boundary, still true

def test_every_structural_hazard_the_fixture_plants_is_reported():
    """The controls. Each of these is a documented limit, and each must announce itself: a merge
    over a named column, a formula with no cached value, a hidden row, a hidden column shadowing a
    field, a dropdown that IS the enumeration, and a comment carrying the caveat."""
    if _skip():
        return
    st = se.workbook_structure(_workbook())
    clin = st.get("5B. ClinChars", {})
    assert clin.get("merged"), "the partial-width merge over Values..Definition is unreported"
    assert clin.get("formula_no_value"), "a formula with no cached value is unreported"
    assert clin.get("hidden_rows") == [6], f"the hidden retired row is unreported: {clin}"
    assert any("definition" in s for s in clin.get("shadowing_cols", [])), \
        "a hidden column shadowing `definition` is unreported"
    assert clin.get("comments"), "the comment carrying the caveat is unreported"
    out = st.get("6. Outcomes", {})
    assert out.get("validation_lists"), "a dropdown holding the enumeration is unreported"


def test_the_content_checks_catch_what_they_claim_to():
    """The lint's own vocabulary, exercised together rather than one at a time — an impossible
    date, a prose placeholder, an unterminated if/else chain and a [verify] marker, all inside
    rules that otherwise read as finished."""
    if _skip():
        return
    _data, found = _findings(_workbook())
    kinds = {f.get("kind") for f in found}
    for want in ("IMPOSSIBLE_DATE", "PLACEHOLDER", "NO_TERMINAL_ELSE", "VERIFY_MARKER"):
        assert want in kinds, f"{want} not raised by the adversarial workbook: {sorted(kinds)}"


def test_a_title_row_that_becomes_the_header_is_announced_not_silent():
    """The header is the first row with three or more populated cells, so a three-cell title row
    above the real header captures it — a documented limit. What matters is that the run SAYS so
    rather than quietly resolving every column to nothing."""
    if _skip():
        return
    rows = _extracted(_workbook())["rows"]
    demos = [r for r in rows if r.get("domain") == "demographics"]
    assert demos, "the fixture's Demos tab produced no rows"
    resolved = [r for r in demos if (r.get("fields") or {}).get("variable")]
    assert not resolved, (
        "the title row no longer captures the header — this test has lost its subject, and the "
        "POSITIONAL/WARNING path it guards is no longer exercised")


# ------------------------------------------- what remains undetectable, recorded rather than fixed

def test_a_stale_formula_cache_is_undetectable_and_that_is_written_down():
    """THE LIMIT WITH NO FIX. `data_only=True` returns the cached `<v>` without consulting the
    `<f>` beside it. A formula edited and never recalculated therefore publishes the OLD number as
    the specification's value, and no amount of reading the file can tell: separating them means
    EVALUATING the formula, which an extractor that refuses to transform anything must not start
    doing.

    The fixture plants `=90*3` with a cached 180. This test asserts the loss is real and silent,
    so the limit is recorded as measured rather than assumed — and so that anyone who later claims
    the extractor validates formulas has a counter-example in the suite.
    """
    if _skip():
        return
    import openpyxl as xl
    p = _workbook()
    formula = xl.load_workbook(p, data_only=False)["5B. ClinChars"]["F5"].value
    cached = xl.load_workbook(p, data_only=True)["5B. ClinChars"]["F5"].value
    assert str(formula).replace("=", "") == "90*3" and str(cached) == "180", (formula, cached)

    st = se.workbook_structure(p).get("5B. ClinChars", {})
    assert "F5" not in st.get("formula_no_value", []), \
        "F5 now reports as having no cached value — the fixture's stale cache did not take"
    # And the extractor publishes the stale number, with nothing marking it.
    rows = _extracted(p)["rows"]
    lookback = [r for r in rows if (r.get("fields") or {}).get("variable") == "LOOKBACK"]
    assert lookback and "180" in (lookback[0].get("text") or ""), lookback
    assert "270" not in (lookback[0].get("text") or ""), \
        "the extractor evaluated the formula — it must not; see this test's docstring"


def test_the_extractor_docstring_states_the_stale_cache_limit():
    """A limit that only a test knows about is a limit the next reader will rediscover the hard
    way. The docstring already names the empty-cache case; the stale one is the dangerous half."""
    src = (FRAMEWORK / "tools" / "spec_extract.py").read_text(encoding="utf-8")
    head = src.split('"""')[1]
    assert "stale" in head.lower(), \
        "spec_extract's docstring does not warn that a CACHED value can be stale — the case where " \
        "the extractor publishes a number the workbook's own arithmetic contradicts"


if __name__ == "__main__":
    os.chdir(FRAMEWORK)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    for _p, d in _BUILT:
        shutil.rmtree(d, ignore_errors=True)
    print(f"\n{len(fns)} tests passed")
