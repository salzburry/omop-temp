"""platform/tools/run_product_profile.py — the SHARED, tumour-agnostic profile entry point.

Two things are proven here that per-pack tests cannot cover.

1. MEMBER SCOPING. A profile covers ONE source-union member. The runner must derive DC_TABLES for
   that member only. Under the Flatiron layout a member mix-up is invisible (see the fixture below),
   so this asserts it against a layout where it is visible.

2. THE RUNTIME CONTRACT. Everything else stops at `Rscript`. This actually runs the profiler in
   local mode over synthetic CSVs and feeds its output to the real consumers, so the chain
   run_product_profile -> data_profiler.R -> profile_<cut>.tsv -> profile_io -> profile_facts is
   covered end to end. That is what caught the doubled-cut output path, which compiled and passed
   every parse-level check. Skips (does not fail) when R or its packages are absent, so the suite
   still runs on a machine without them.

No vendor data: every byte the profiler reads here is written by this file.
"""
import importlib.util
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))

RUNNER = FRAMEWORK / "tools" / "run_product_profile.py"
_spec = importlib.util.spec_from_file_location("run_product_profile", RUNNER)
rpp = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(rpp)

# A source_layout that puts the schema INSIDE the physical table name. The template documents
# {schema} as available (engine/vendors.py), so this is a legal product layout — and it is the case
# where resolving a union's tables from the wrong member stops being a silent no-op.
SCHEMA_SENSITIVE = "{schema}.pre_{schema}_{stem}_{refresh}"

UNION_PACK = """\
data_product_id: union_fixture
name: "union fixture"
owner: RWP
version: "1"
vendor: flatiron
tumor_class: solid
run:
  refresh: "REPLACE_ME"
  source_schema: "REPLACE_ME"
  output_schema: out
  output_table: t_out
  write_mode: overwrite
  source_layout: "%s"
source_union:
  discriminator: db
  members:
    - { schema: schema_a, flag: A }
    - { schema: schema_b, flag: B }
sources:
  demographics: t_demographics
  vitals: t_vitals
""" % SCHEMA_SENSITIVE

PLAIN_PACK = """\
data_product_id: plain_fixture
name: "plain fixture"
owner: RWP
version: "1"
vendor: flatiron
tumor_class: solid
run:
  refresh: "REPLACE_ME"
  source_schema: "REPLACE_ME"
  output_schema: out
  output_table: t_out
  write_mode: overwrite
sources:
  demographics: t_demographics
  vitals: t_vitals
"""


def _pack(root, body):
    d = Path(root) / "pack"
    (d / "config").mkdir(parents=True, exist_ok=True)
    (d / "config" / "data_product.yaml").write_text(body, encoding="utf-8")
    return str(d)


def test_union_member_tables_are_scoped_to_that_member():
    """One run, one member. resolve_tables() must not fan out across the union.

    cfg.source_fqns() returns EVERY member's table by design (preflight wants that — fail fast on
    any member's missing table). Using it here meant a --member schema_a run also carried schema_b's
    physical tables. Invisible under `{schema}.{stem}_{refresh}`, because stripping the schema makes
    both members dedup to the same bare names; visible here.
    """
    with tempfile.TemporaryDirectory() as tmp:
        pack = _pack(tmp, UNION_PACK)
        a = rpp.resolve_tables(rpp.pack_config(pack, "2026m06", "schema_a"))
        b = rpp.resolve_tables(rpp.pack_config(pack, "2026m06", "schema_b"))

        assert a == ["pre_schema_a_t_demographics_2026m06", "pre_schema_a_t_vitals_2026m06"], a
        assert b == ["pre_schema_b_t_demographics_2026m06", "pre_schema_b_t_vitals_2026m06"], b
        # the decisive assertion: neither run may mention the other member at all
        assert not [t for t in a if "schema_b" in t], f"member A run leaked member B tables: {a}"
        assert not [t for t in b if "schema_a" in t], f"member B run leaked member A tables: {b}"
        # and each run is exactly one table per configured source, not one per source*member
        assert len(a) == 2, f"expected one table per source, got {a}"


def test_flatiron_layout_is_unaffected():
    """The fix must not change the (correct) behaviour under the standard layout."""
    with tempfile.TemporaryDirectory() as tmp:
        pack = _pack(tmp, PLAIN_PACK)
        tables = rpp.resolve_tables(rpp.pack_config(pack, "2026m06", "anything"))
        assert tables == ["t_demographics_2026m06", "t_vitals_2026m06"], tables
        assert all("." not in t for t in tables), tables


def _r_ready():
    if not shutil.which("Rscript"):
        return False
    probe = subprocess.run(
        ["Rscript", "-e", 'q(status = as.integer(!all(sapply(c("dplyr","stringr","readr"),'
                          ' requireNamespace, quietly = TRUE))))'],
        capture_output=True)
    return probe.returncode == 0


def test_local_runtime_chain_produces_a_tsv_the_consumers_accept():
    """run_product_profile --local-dir -> data_profiler.R -> TSV -> profile_io.load().

    The TSV format is a contract between an R producer and a Python consumer with nothing but
    convention holding the two sides together. Parse-checking the R and unit-testing the Python
    leaves exactly that seam uncovered.
    """
    if not _r_ready():
        print("SKIP runtime chain (Rscript or dplyr/stringr/readr unavailable)")
        return
    with tempfile.TemporaryDirectory() as tmp:
        pack = _pack(tmp, PLAIN_PACK)
        extracts = Path(tmp) / "extracts"
        extracts.mkdir()
        for t in rpp.resolve_tables(rpp.pack_config(pack, "2026m06", "synthetic")):
            (extracts / f"{t}.csv").write_text("patientid,birthyear,gender\nP1,1950,M\nP2,1961,F\n", encoding="utf-8")

        out = Path(tmp) / "restricted"
        rc = rpp.main([pack, "--cut", "2026m06", "--schema", "synthetic",
                       "--local-dir", str(extracts), "--out-dir", str(out)])
        assert rc == 0, f"runner exited {rc}"

        # the documented location: <root>/<product_id>/<schema>/<cut>/ — the cut appears ONCE
        tsv = out / "plain_fixture" / "synthetic" / "2026m06" / "profile_2026m06.tsv"
        assert tsv.exists(), f"profile not at the documented path; got {sorted(out.rglob('*.tsv'))}"

        sys.path.insert(0, str(FRAMEWORK / "tools"))
        import profile_io
        tables, cuts = profile_io.load(str(tsv))
        assert cuts == {"2026m06"}, cuts
        assert set(tables) == {"t_demographics", "t_vitals"}, sorted(tables)
        for cols in tables.values():
            assert "patientid" in cols, sorted(cols)


def test_restricted_output_cannot_land_in_the_checkout():
    """--out-dir inside the repo must be refused: .gitignore stops a commit, not a read."""
    with tempfile.TemporaryDirectory() as tmp:
        pack = _pack(tmp, PLAIN_PACK)
        try:
            rpp.main([pack, "--cut", "2026m06", "--schema", "s",
                      "--out-dir", str(FRAMEWORK.parent / "scratch_profile")])
        except SystemExit as e:
            assert "inside the checkout" in str(e), e
            return
        raise AssertionError("--out-dir inside the checkout was accepted")


# --- profile identity (the TSV says what it was measured from) ------------------------------------

def _stamped(tmp, **over):
    """A minimal profile TSV with the identity columns, so the checks can be driven directly."""
    sys.path.insert(0, str(FRAMEWORK / "tools"))
    import profile_io
    # Identity columns from profile_io, not restated — the profiler stamping a fifth one must not
    # leave this fixture silently writing a four-column profile.
    cols = list(profile_io.PROVENANCE) + [
            "table_base", "table", "column", "kind", "sampled", "n_rows", "n_rows_total",
            "pct_missing", "distinct", "date_min", "date_max", "top_values"]
    base = {"profile_product_id": "p1", "profile_schema": "s1", "profile_cut": "2026m06",
            "profile_source_mode": "dbi", "profile_mode": profile_io.FULL_PROFILE,
            "table_base": "t_demographics",
            "table": "t_demographics_2026m06", "column": "patientid", "kind": "id",
            "sampled": "FALSE", "n_rows": "10", "n_rows_total": "10", "pct_missing": "0",
            "distinct": "10", "date_min": "", "date_max": "", "top_values": ""}
    rows = [dict(base, **over), dict(base, column="birthyear", **over)]
    p = Path(tmp) / "profile_2026m06.tsv"
    p.write_text("\t".join(cols) + "\n"
                 + "".join("\t".join(str(r[c]) for c in cols) + "\n" for r in rows), encoding="utf-8")
    return str(p)


def test_provenance_roundtrips_and_absence_is_reported_as_none():
    sys.path.insert(0, str(FRAMEWORK / "tools"))
    import profile_io
    with tempfile.TemporaryDirectory() as tmp:
        tables, _ = profile_io.load(_stamped(tmp))
        assert profile_io.provenance(tables) == {
            "product_id": "p1", "schema": "s1", "cut": "2026m06", "source_mode": "dbi",
            "mode": "full"}

        # a pre-identity profile still loads; provenance simply says it does not know
        old = Path(tmp) / "old.tsv"
        txt = Path(_stamped(tmp)).read_text(encoding="utf-8").split("\n")
        keep = [i for i, c in enumerate(txt[0].split("\t")) if not c.startswith("profile_")]
        old.write_text("\n".join("\t".join(l.split("\t")[i] for i in keep) for l in txt if l) + "\n", encoding="utf-8")
        tables, _ = profile_io.load(str(old))
        assert profile_io.provenance(tables) == {
            "product_id": None, "schema": None, "cut": None, "source_mode": None, "mode": None}


def test_a_file_mixing_two_runs_is_refused():
    """Identity is per row, so two runs' output concatenates into a structurally valid file."""
    sys.path.insert(0, str(FRAMEWORK / "tools"))
    import profile_io
    with tempfile.TemporaryDirectory() as tmp:
        a = Path(_stamped(tmp)).read_text(encoding="utf-8").split("\n")
        mixed = Path(tmp) / "mixed.tsv"
        # header + row 1 from schema s1, then a row claiming schema s2
        mixed.write_text(a[0] + "\n" + a[1] + "\n" + a[2].replace("\ts1\t", "\ts2\t", 1) + "\n", encoding="utf-8")
        try:
            profile_io.load(str(mixed))
        except SystemExit as e:
            assert "different values for profile_schema" in str(e), e
            return
        raise AssertionError("a profile mixing two schemas was accepted")




# --- the shared schema checker (same pack/member/output contract, different runtime) --------------

SCHEMA_CHECK = FRAMEWORK / "tools" / "run_product_schema_check.py"
_sspec = importlib.util.spec_from_file_location("run_product_schema_check", SCHEMA_CHECK)
rpsc = importlib.util.module_from_spec(_sspec)
_sspec.loader.exec_module(rpsc)


def test_schema_check_refuses_output_inside_the_checkout():
    """The report names physical vendor tables/columns and their observed types. The retired
    prostate copy DEFAULTED here (`out_dir = DC_OUT_DIR or HERE.parent`)."""
    with tempfile.TemporaryDirectory() as tmp:
        pack = _pack(tmp, PLAIN_PACK)
        for out, expect in ((None, "REQUIRED"),
                            (str(FRAMEWORK.parent / "scratch_schema"), "inside the checkout")):
            argv = [pack, "--cut", "2026m06", "--schema", "s"] + (["--out-dir", out] if out else [])
            try:
                rpsc.main(argv)
            except SystemExit as e:
                assert expect in str(e), (out, e)
                continue
            raise AssertionError(f"--out-dir {out!r} was accepted")


def test_schema_check_requires_a_member_for_a_union_pack():
    """One report covers ONE member — the same rule the profile runner enforces, from pack_run."""
    with tempfile.TemporaryDirectory() as tmp:
        pack = _pack(tmp, UNION_PACK)
        try:
            rpsc.main([pack, "--cut", "2026m06", "--schema", "s", "--out-dir", tmp])
        except SystemExit as e:
            assert "source_union" in str(e) and "--member" in str(e), e
            return
        raise AssertionError("a union pack was accepted without --member")


def test_both_runners_share_one_pack_and_output_contract():
    """pack_run is the single answer to which pack / which cut / which member / where output goes.

    Two tools producing evidence for the same delivery must not disagree about any of those, and
    each answering separately is how the copies drift.
    """
    sys.path.insert(0, str(FRAMEWORK / "tools"))
    import pack_run
    import run_product_profile as rpp_mod
    import run_product_schema_check as rpsc_mod
    # Both resolve a pack through the same function object — not two that merely agree today.
    assert rpp_mod.pack_config is pack_run.pack_config
    assert rpsc_mod.pack_run.pack_config is pack_run.pack_config
    with tempfile.TemporaryDirectory() as tmp:
        pack = _pack(tmp, PLAIN_PACK)
        cfg = pack_run.pack_config(pack, "2026m06", "s1")
        # both land on <root>/<product_id>/<schema>[/<cut>] — the profiler appends the cut itself,
        # the schema checker writes the leaf directly, and the shapes must agree.
        prof_dir = pack_run.evidence_dir(tmp, pack_run.product_id(cfg, pack), "s1")
        schema_dir = pack_run.evidence_dir(tmp, pack_run.product_id(cfg, pack), "s1", "2026m06")
        assert schema_dir == os.path.join(prof_dir, "2026m06"), (prof_dir, schema_dir)


def test_every_real_pack_resolves_its_own_configured_sources():
    """The derivation, against every DISCOVERED pack's real config — not one tumour's.

    This replaced platform/tests/test_prostate_profile.py, which asserted exactly this for prostate
    202606 alone. A per-tumour copy of a shared tool's test is the same duplication the shared runner
    removed: HNSCC, GIST, SCLC and DLBCL would each have grown one, and a pack nobody wrote a test
    for would be silently unprotected. Discovery means a new tumour is covered the day it lands.
    """
    sys.path.insert(0, str(FRAMEWORK / "tools"))
    import product_gates
    # Explicit root: products() defaults to repo_root(), which is derived from the CWD, and CI runs
    # this suite from platform/ — where it discovers nothing. The assertion below is what turned a
    # silently-vacuous pass into a failure; keep it.
    packs = [os.path.join(FRAMEWORK.parent, p)
             for p in product_gates.products(str(FRAMEWORK.parent))
             if os.path.exists(os.path.join(FRAMEWORK.parent, p, "config", "data_product.yaml"))]
    assert packs, "no packs discovered — the sweep would pass vacuously"
    for pack in packs:
        cfg = rpp.pack_config(pack, "2026m06", "myschema")
        tables = rpp.resolve_tables(cfg)
        label = os.path.relpath(pack, FRAMEWORK.parent)

        # Assertions are LAYOUT-AGNOSTIC on purpose. Asserting `f"{stem}_{cut}" in tables` baked in
        # the Flatiron `{schema}.{stem}_{refresh}` template, so the first pack to set a
        # run.source_layout — the mechanism engine/vendors.py exists to provide — would fail a test
        # of behaviour that is actually correct. Comparing against cfg.table() instead would be
        # tautological: that IS what resolve_tables computes. So assert the properties the runner
        # must hold under ANY layout.
        assert len(tables) == len(set(cfg.sources.values())), \
            f"{label}: {len(tables)} tables for {len(set(cfg.sources.values()))} distinct stems — a " \
            f"union must not multiply the scope by its members"
        # bare names only: the profiler prepends catalog.schema itself, so a schema left on the
        # front would be read as catalog.schema.schema.table
        assert all("." not in t for t in tables), f"{label}: not bare table names: {tables}"
        assert all(t for t in tables), f"{label}: empty table name in {tables}"
        # the cut reaches the physical name, wherever the layout puts it
        q1 = rpp.resolve_tables(rpp.pack_config(pack, "2026q1", "myschema"))
        assert all("2026q1" in t for t in q1), f"{label}: cut absent from {q1}"
        assert set(q1) != set(tables), f"{label}: changing the cut changed nothing: {q1}"

        # For a union pack, no member's run may name another member's tables — under any layout.
        members = rpp.union_members(pack)
        for m in members:
            mine = rpp.resolve_tables(rpp.pack_config(pack, "2026m06", m))
            for other in members:
                if other != m:
                    assert not [t for t in mine if other in t], \
                        f"{label}: member {m} run names member {other}'s tables: {mine}"


TESTS = [v for k, v in sorted(globals().items()) if k.startswith("test_")]

if __name__ == "__main__":
    for t in TESTS:
        t()
        print(f"ok  {t.__name__}")
    print(f"\n{len(TESTS)} tests passed")
