"""Spark in-memory tests for the engine stages.

Run on a Spark runtime (Databricks, or anywhere pyspark is installed):

    python3 tests/test_stages_spark.py      # skips cleanly if pyspark is unavailable

These DO run here, and a note claiming otherwise would hide a real gap. PySpark
was believed unbuildable in this sandbox; what actually failed was `pip install pyspark` against
Debian's patched setuptools (`AttributeError: install_layout`), because PySpark ships an sdist and
the Debian `install_lib` refuses it. A venv with setuptools from PyPI installs it in one command.

Until that was found, every assertion in this file had never executed — not locally, and not in CI,
whose "Spark / smoke tests (skip without PySpark)" step runs in a job that does not install PySpark
(it is commented out of requirements.txt). The first real run failed twice: a `Decimal`/`float`
comparison (see `_f`) and a registry walk over planned-only tumours. Both were defects in the tests
rather than the engine, which is the good outcome — but a suite that has never run is not evidence,
and "skips cleanly" is how a suite looks green while running nothing.

Covers the behaviours called out in review: the treated/untreated split, deterministic
new_lot_n (incl. start-date ties), index windowing, treatment categorisation, and the
spec-version stamp.
"""
import sys
from datetime import date
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent   # _framework/ (the shared engine lives here)
sys.path.insert(0, str(FRAMEWORK))

try:
    from pyspark.sql import SparkSession
except Exception:                       # pyspark not installed -> tests skip
    SparkSession = None

# Stage modules import without pyspark OR pyyaml (spark imports are lazy; no yaml at module load).
# engine.config (which needs pyyaml) is imported lazily in _cfg() so this file imports cleanly in
# a runtime that has neither, and reaches the pyspark skip instead of a ModuleNotFoundError.
from engine.stages import lot as lot_stage, index as index_stage          # noqa: E402
from engine.stages import treatment as treatment_stage, assemble as assemble_stage  # noqa: E402
from engine.stages import clinical as clinical_stage, outcomes as outcomes_stage    # noqa: E402
from engine.stages import proc as proc_stage                                        # noqa: E402
from engine.config import product_config                                            # noqa: E402

try:                                    # proper pytest skip when pytest is driving
    import pytest
    pytestmark = pytest.mark.skipif(SparkSession is None, reason="pyspark not installed")
except Exception:
    pytest = None

CONFIG = product_config(FRAMEWORK.parent / "products", "prostate")   # reference tumor
GOOD = {"run.refresh": "2026q1", "run.source_schema": "rwd", "run.output_schema": "out"}
_SPARK = None


def _f(v):
    """A Spark numeric as a float, for comparison against a Python literal.

    Spark 4 returns DecimalType columns as `decimal.Decimal`, and `Decimal("12.1") == 12.1` is
    FALSE — 12.1 has no exact binary representation, so the float the interpreter builds is not the
    number the Decimal names. Every duration assertion below compares a computed month count against
    `<days> / 30.4375`, so without this they all fail on a value that is correct to seven decimal
    places. Coercing the SPARK side keeps the expected side written the way the specification states
    it.

    It surfaced the day PySpark was first installed here: these suites had been skipping — locally
    AND in CI, which never installs PySpark — so no assertion in this file had ever executed.
    """
    return float(v) if v is not None else None


def _spark():
    global _SPARK
    if _SPARK is None:
        _SPARK = (SparkSession.builder.master("local[1]").appName("prostate-tests")
                  .config("spark.sql.shuffle.partitions", "1").getOrCreate())
    return _SPARK


def _cfg():
    from engine.config import load_config        # deferred: needs pyyaml
    return load_config(CONFIG, overrides=GOOD)


def test_lot_normalized_mcrpc_only_and_deterministic():
    if SparkSession is None:
        return
    lot = _spark().createDataFrame([
        ("p1", "Abiraterone", "mCRPC", date(2020, 1, 1), 1, date(2020, 6, 1)),
        ("p1", "Docetaxel",   "mCRPC", date(2020, 1, 1), 2, date(2020, 9, 1)),  # tie on startdate
        ("p1", "ADT",         "HSPC",  date(2019, 1, 1), 1, date(2019, 6, 1)),  # non-mCRPC dropped
    ], ["patientid", "linename", "linesetting", "startdate", "linenumber", "enddate"])
    rows = lot_stage.normalized({"lot": lot}, line_setting="mCRPC").collect()   # config-driven filter
    assert all(r["linesetting"] == "mCRPC" for r in rows)            # HSPC dropped
    by_n = {r["new_lot_n"]: r["linename"] for r in rows}
    assert by_n[1] == "abiraterone" and by_n[2] == "docetaxel"      # lowercased + tie broken by linenumber
    assert len({(r["patientid"], r["new_lot_n"]) for r in rows}) == len(rows)  # unique per (patient, line)
    # With no line_setting, ALL lines are kept (the non-prostate / heme behaviour)
    assert lot_stage.normalized({"lot": lot}).count() == 3


def test_index_overall_windowed():
    if SparkSession is None:
        return
    enh = _spark().createDataFrame([
        ("p1", date(2020, 1, 1)),
        ("p2", date(2010, 1, 1)),   # before index_start -> excluded
    ], ["patientid", "advanceddiagnosisdate"])
    cfg = _cfg()
    rows = index_stage.build({"enhanced": enh}, cfg, cfg.cohort("overall_mcrpc")).collect()
    assert {r["patientid"] for r in rows} == {"p1"}
    assert rows[0]["index_date"] == date(2020, 1, 1)


def test_index_lot1_uses_line_start():
    if SparkSession is None:
        return
    cfg = _cfg()
    # advanceddiagnosisdate must be IN the study window: a line cohort gates on BOTH the setting
    # diagnosis date AND the line start (index.py). Here it's 2020-01-15 (in window) but DISTINCT from
    # the line-1 start (2020-01-01), so index_date==line start proves the cohort indexes off the LINE
    # START, not the diagnosis date.
    enh = _spark().createDataFrame([("p1", date(2020, 1, 15))],
                                   ["patientid", "advanceddiagnosisdate"])
    lot = _spark().createDataFrame([
        ("p1", "Abiraterone", "mCRPC", date(2020, 1, 1), 1, date(2020, 6, 1)),
        ("p1", "Docetaxel",   "mCRPC", date(2020, 7, 1), 2, date(2020, 12, 1)),
    ], ["patientid", "linename", "linesetting", "startdate", "linenumber", "enddate"])
    rows = index_stage.build({"enhanced": enh, "lot": lot}, cfg, cfg.cohort("lot1_mcrpc")).collect()
    assert len(rows) == 1
    assert rows[0]["index_date"] == date(2020, 1, 1) and rows[0]["new_lot_n"] == 1


def test_treatment_categorises_line():
    if SparkSession is None:
        return
    cfg = _cfg()
    idx = _spark().createDataFrame([("p1", date(2020, 1, 1))], ["patientid", "index_date"])
    lot = _spark().createDataFrame([
        ("p1", "Abiraterone", "mCRPC", date(2020, 1, 1), 1, date(2020, 6, 1)),
    ], ["patientid", "linename", "linesetting", "startdate", "linenumber", "enddate"])
    rows = treatment_stage.build({"lot": lot}, idx, cfg).collect()
    assert len(rows) == 1                                   # one row per patient
    # category 1 matches on linename (equals abiraterone) — no drug_episode needed here
    assert rows[0]["lot1cat"] == "Abiraterone monotherapy" and rows[0]["lot1catn"] == 1


def test_prior_taxane_mcrpc_cohort_behaviour():
    if SparkSession is None:
        return
    cfg = _cfg()
    idx = _spark().createDataFrame([("p1", date(2020, 6, 1))], ["patientid", "index_date"])
    lot = _spark().createDataFrame([
        ("p1", "Docetaxel",    "mCRPC", date(2020, 1, 1), 1, date(2020, 5, 1)),
        ("p1", "Enzalutamide", "mCRPC", date(2020, 6, 1), 2, date(2020, 9, 1)),
    ], ["patientid", "linename", "linesetting", "startdate", "linenumber", "enddate"])

    def ptm(coh):
        return (treatment_stage.build({"lot": lot}, idx, cfg, cfg.cohort(coh))
                .collect()[0]["prior_tax_mcrpc"])

    assert ptm("lot2_mcrpc") == "Yes"     # line 1 (the prior mCRPC line) was a taxane (linename LIKE)
    assert ptm("lot1_mcrpc") is None      # 1L cohort: no prior line -> not applicable
    assert ptm("overall_mcrpc") == "No"   # not a line cohort -> No


def test_treatment_chemo_category_from_drug_episode():
    """B1: the drug category lives on drug_episode, not LOT. drug_episode is filtered to the cohort's
    setting, then the per-line chemotherapy indicator is aggregated per (patientid, linenumber) and joined
    on (patientid, linenumber), so lotcatn=9 ("Other chemotherapy-containing") is episode-driven, stays one
    row per patient (no LOT inflation), and does NOT leak across settings (mHSPC line-1 and mCRPC line-1
    share a linenumber but are in different settings, so each cohort sees only its own setting's episodes)."""
    if SparkSession is None:
        return
    cfg = _cfg()
    idx = _spark().createDataFrame([("p1", date(2020, 1, 1))], ["patientid", "index_date"])
    # 'Carboplatin' matches no named linename category (1-8, 10-15), so its category is decided ONLY by
    # the drug-episode detaileddrugcategory (=chemotherapy -> lotcatn 9) — and only in the setting whose
    # line actually has a chemotherapy episode.
    lot = _spark().createDataFrame([
        ("p1", "Carboplatin", "mCRPC", date(2020, 1, 1), 1, date(2020, 6, 1)),
        ("p1", "Carboplatin", "mHSPC", date(2019, 1, 1), 1, date(2019, 6, 1)),
    ], ["patientid", "linename", "linesetting", "startdate", "linenumber", "enddate"])
    # many episodes per line; a chemotherapy episode exists ONLY under mCRPC line 1.
    de = _spark().createDataFrame([
        ("p1", "mCRPC", 1, date(2020, 2, 1), "chemotherapy"),
        ("p1", "mCRPC", 1, date(2020, 3, 1), "targeted/non-biologic"),
        ("p1", "mHSPC", 1, date(2019, 2, 1), "hormonal"),
    ], ["patientid", "linesetting", "linenumber", "episodedate", "detaileddrugcategory"])
    src = {"lot": lot, "drug_episode": de}

    mcrpc = treatment_stage.build(src, idx, cfg, cfg.cohort("overall_mcrpc")).collect()
    mhspc = treatment_stage.build(src, idx, cfg, cfg.cohort("overall_mhspc")).collect()
    assert len(mcrpc) == 1 and len(mhspc) == 1              # one row per patient (setting-scoped aggregate, no fan-out)
    assert mcrpc[0]["lot1catn"] == 9                        # mCRPC L1 chemo episode -> "Other chemotherapy-containing"
    assert mhspc[0]["lot1catn"] != 9                        # mHSPC L1 has no chemo episode -> no cross-setting leak
    # the episode-DATE aggregate (lot1ed) is ALSO setting-scoped: each setting's line-1 gets its own
    # max(episodedate), never the other setting's — proving drug_episode is filtered to the cohort setting.
    assert mcrpc[0]["lot1ed"] == date(2020, 3, 1)          # max mCRPC L1 episode date
    assert mhspc[0]["lot1ed"] == date(2019, 2, 1)          # max mHSPC L1 episode date (not the mCRPC max)


def test_treatment_category_falls_back_to_lot_when_episode_lacks_category():
    """B1 fallback: when drug_episode has line/date fields but NO detaileddrugcategory, the line keeps any
    LOT-native category instead of losing it (the episode aggregate is authoritative for the category only
    when it actually sources one). loted still comes from the episode date."""
    if SparkSession is None:
        return
    cfg = _cfg()
    idx = _spark().createDataFrame([("p1", date(2020, 1, 1))], ["patientid", "index_date"])
    lot = _spark().createDataFrame([
        ("p1", "Carboplatin", "mCRPC", date(2020, 1, 1), 1, date(2020, 6, 1), "chemotherapy"),
    ], ["patientid", "linename", "linesetting", "startdate", "linenumber", "enddate",
        "detaileddrugcategory"])                          # LOT-native category present
    de = _spark().createDataFrame([
        ("p1", "mCRPC", 1, date(2020, 2, 1)),
    ], ["patientid", "linesetting", "linenumber", "episodedate"])   # dates only, NO category column
    rows = treatment_stage.build({"lot": lot, "drug_episode": de}, idx, cfg,
                                 cfg.cohort("overall_mcrpc")).collect()
    assert len(rows) == 1
    assert rows[0]["lot1catn"] == 9                        # LOT-native 'chemotherapy' preserved -> Other-chemo
    assert rows[0]["lot1ed"] == date(2020, 2, 1)          # loted still from the episode date


def test_treatment_no_setting_model_aggregates_across_settings():
    """B1 non-setting path: with NO line-setting model (global cleared, cohort=None), drug_episode is NOT
    filtered by setting — same-numbered lines aggregate together on (patientid, linenumber), one row per
    patient (no fan-out). This is the intended behaviour for heme/COTA products with no setting model."""
    if SparkSession is None:
        return
    cfg = _cfg()
    cfg.raw.setdefault("lot", {})["line_setting"] = None   # clear the global setting model
    idx = _spark().createDataFrame([("p1", date(2020, 1, 1))], ["patientid", "index_date"])
    lot = _spark().createDataFrame([
        ("p1", "Carboplatin", "mCRPC", date(2020, 1, 1), 1, date(2020, 6, 1)),
    ], ["patientid", "linename", "linesetting", "startdate", "linenumber", "enddate"])
    # two settings share linenumber=1; with no setting model they collapse into one (patientid, linenumber)
    # aggregate — the mCRPC chemo episode makes _has_chemo=1 for line 1.
    de = _spark().createDataFrame([
        ("p1", "mCRPC", 1, date(2020, 2, 1), "chemotherapy"),
        ("p1", "mHSPC", 1, date(2019, 2, 1), "hormonal"),
    ], ["patientid", "linesetting", "linenumber", "episodedate", "detaileddrugcategory"])
    rows = treatment_stage.build({"lot": lot, "drug_episode": de}, idx, cfg).collect()   # cohort=None
    assert len(rows) == 1                                  # one row per patient (no fan-out)
    assert rows[0]["lot1catn"] == 9                        # line-1 collapse across settings -> Other-chemo


def test_assemble_treated_untreated_split_and_stamp():
    if SparkSession is None:
        return
    cfg = _cfg()
    keys = _spark().createDataFrame(
        [("p1", date(2020, 1, 1)), ("p2", date(2020, 1, 1))], ["patientid", "index_date"])
    treated = _spark().createDataFrame([("p1", 1)], ["patientid", "treat_flag"])  # only p1 treated
    rows = assemble_stage.build(keys, keys, keys, keys, keys, cfg,
                                cfg.cohort("overall_mcrpc"), treated).collect()
    by = {r["patientid"]: r for r in rows}
    # per-setting COHORTUN (4.StudyPop): Treated mCRPC = 2, Untreated mCRPC = 1
    assert by["p1"]["cohortu"] == "Treated mCRPC" and by["p1"]["cohortun"] == 2
    assert by["p2"]["cohortu"] == "Untreated mCRPC" and by["p2"]["cohortun"] == 1
    assert by["p1"]["cohort"] == "Overall mCRPC"
    # spec_version stamp is the CalVer contract alone (cfg.spec_version = 202606), NOT cfg.version
    # (202606.2026q1) — the data cut is the separate data_refresh axis.
    assert by["p1"]["spec_version"] == cfg.spec_version and by["p1"]["data_refresh"] == "2026q1"
    assert by["p1"]["spec_version"] == "202606"
    # row self-identifies its product (build-level provenance lives in the manifest)
    assert by["p1"]["data_product_id"] == cfg.data_product_id == "prostate_mcrpc_rwdp"


def test_baseline_ecog_unknown_vs_missing():
    if SparkSession is None:
        return
    cfg = _cfg()
    idx = _spark().createDataFrame(
        [("p1", date(2020, 1, 1)), ("p2", date(2020, 1, 1)), ("p3", date(2020, 1, 1))],
        ["patientid", "index_date"])
    becog = _spark().createDataFrame([
        ("p1", "1",       date(2020, 1, 5)),     # numeric -> "1" / code 2
        ("p2", "Unknown", date(2020, 1, 3)),     # explicit unknown -> "Unknown" / code 6
    ], ["patientid", "ecogvalue", "ecogdate"])   # p3 has no record -> "Missing" / code 7
    rows = clinical_stage.baseline_ecog(
        {"baseline_ecog": becog}, idx, cfg.pack("clinical")["baseline_ecog"]).collect()
    by = {r["patientid"]: r for r in rows}
    assert by["p1"]["ecog"] == "1" and by["p1"]["ecogn"] == 2
    assert by["p2"]["ecog"] == "Unknown" and by["p2"]["ecogn"] == 6     # NOT "Missing"
    assert by["p3"]["ecog"] == "Missing" and by["p3"]["ecogn"] == 7


def test_follow_up_and_death():
    if SparkSession is None:
        return
    s, cfg = _spark(), _cfg()
    idx = s.createDataFrame(
        [("p1", date(2020, 1, 1)), ("p2", date(2020, 1, 1)), ("p3", date(2020, 1, 1))],
        ["patientid", "index_date"])
    src = {
        "visit":     s.createDataFrame([("p1", date(2021, 3, 1))], ["patientid", "visitdate"]),
        "telemed":   s.createDataFrame([("p1", date(2021, 1, 1))], ["patientid", "visitdate"]),
        "lot":       s.createDataFrame([("p1", date(2021, 2, 1))], ["patientid", "enddate"]),
        "orals":     s.createDataFrame([("p1", "Month", date(2021, 2, 15))],
                                       ["patientid", "startdategranularity", "enddate"]),
        "alphabet":  s.createDataFrame([("p1", date(2021, 1, 15))], ["patientid", "administrationdate"]),
        "provenge":  s.createDataFrame([("p1", date(2020, 6, 1))], ["patientid", "startdate"]),
        # p2 one death; p3 has TWO death rows -> must collapse to one (earliest), no fan-out.
        "mortality": s.createDataFrame(
            [("p2", "2020-06"), ("p3", "2021-01"), ("p3", "2020-03")], ["patientid", "dateofdeath"]),
    }
    rows = clinical_stage.follow_up_and_death(src, idx, cfg.pack("clinical")).collect()
    assert len(rows) == 3                                                    # P1: no mortality fan-out
    by = {r["patientid"]: r for r in rows}
    assert by["p1"]["dthfl"] == 0 and by["p1"]["fued"] == date(2021, 3, 1)   # latest activity date
    assert by["p1"]["dthfufl"] == "Missing" and by["p1"]["dth_before_fued"] == 0
    assert by["p2"]["dthfl"] == 1 and by["p2"]["dthdt"] == date(2020, 6, 15) # imputed 15th
    assert by["p2"]["fued"] == date(2020, 1, 1)                              # never before index
    assert by["p2"]["dthfufl_dur"] == 166 and by["p2"]["dthfufl"] == "0"     # 166 > 120-day window
    assert by["p3"]["dthfl"] == 1 and by["p3"]["dthdt"] == date(2020, 3, 15) # earliest of the two


def test_mortality_dedup_prefers_specific():
    if SparkSession is None:
        return
    s, cfg = _spark(), _cfg()
    idx = s.createDataFrame([("p1", date(2020, 1, 1))], ["patientid", "index_date"])
    empty = lambda ddl: s.createDataFrame([], ddl)
    src = {
        "visit":     empty("patientid string, visitdate date"),
        "telemed":   empty("patientid string, visitdate date"),
        "lot":       empty("patientid string, enddate date"),
        "orals":     empty("patientid string, startdategranularity string, enddate date"),
        "alphabet":  empty("patientid string, administrationdate date"),
        "provenge":  empty("patientid string, startdate date"),
        # one year-only AND one more-specific month-level row for the same patient
        "mortality": s.createDataFrame([("p1", "2020"), ("p1", "2020-11")],
                                       "patientid string, dateofdeath string"),
    }
    rows = clinical_stage.follow_up_and_death(src, idx, cfg.pack("clinical")).collect()
    assert len(rows) == 1                              # one death row per patient/index
    assert rows[0]["dthdt"] == date(2020, 11, 15)      # specific "2020-11" beats year-only "2020"


def test_mortality_conflict_policy_earliest():
    if SparkSession is None:
        return
    s, cfg = _spark(), _cfg()
    pack = cfg.pack("clinical")
    pack["death_date_imputation"]["conflict_resolution"] = "earliest"   # override the policy
    idx = s.createDataFrame([("p1", date(2020, 1, 1))], ["patientid", "index_date"])
    empty = lambda ddl: s.createDataFrame([], ddl)
    src = {
        "visit":     empty("patientid string, visitdate date"),
        "telemed":   empty("patientid string, visitdate date"),
        "lot":       empty("patientid string, enddate date"),
        "orals":     empty("patientid string, startdategranularity string, enddate date"),
        "alphabet":  empty("patientid string, administrationdate date"),
        "provenge":  empty("patientid string, startdate date"),
        # a more specific later row vs an earlier coarse row
        "mortality": s.createDataFrame([("p1", "2020-11"), ("p1", "2019")],
                                       "patientid string, dateofdeath string"),
    }
    rows = clinical_stage.follow_up_and_death(src, idx, pack).collect()
    assert len(rows) == 1
    # 'earliest' picks the 2019 death (2019-07-15), NOT the more-specific later 2020-11.
    assert rows[0]["dthdt"] == date(2019, 7, 15)


def test_year_level_death_index_aware():
    if SparkSession is None:
        return
    s, cfg = _spark(), _cfg()
    # p1: index Oct (>= July) -> a same-year YYYY death snaps to Dec 31, NOT Jul 15 (pre-index).
    # p2: index Mar (< July)  -> a same-year YYYY death stays Jul 15.
    idx = s.createDataFrame([("p1", date(2020, 10, 1)), ("p2", date(2020, 3, 1))],
                            ["patientid", "index_date"])
    empty = lambda ddl: s.createDataFrame([], ddl)
    src = {
        "visit":     empty("patientid string, visitdate date"),
        "telemed":   empty("patientid string, visitdate date"),
        "lot":       empty("patientid string, enddate date"),
        "orals":     empty("patientid string, startdategranularity string, enddate date"),
        "alphabet":  empty("patientid string, administrationdate date"),
        "provenge":  empty("patientid string, startdate date"),
        "mortality": s.createDataFrame([("p1", "2020"), ("p2", "2020")],
                                       "patientid string, dateofdeath string"),
    }
    by = {r["patientid"]: r for r in
          clinical_stage.follow_up_and_death(src, idx, cfg.pack("clinical")).collect()}
    assert by["p1"]["dthdt"] == date(2020, 12, 31)   # same-year, index >= July -> Dec 31
    assert by["p1"]["fued"] == date(2020, 10, 1)      # death no longer precedes index
    assert by["p1"]["dthdt"] >= by["p1"]["fued"]      # so OS will be non-negative
    assert by["p2"]["dthdt"] == date(2020, 7, 15)     # index < July -> default Jul 15


def test_outcomes_os():
    if SparkSession is None:
        return
    from pyspark.sql.types import (StructType, StructField, StringType, DateType, IntegerType)
    s, cfg = _spark(), _cfg()
    idx = s.createDataFrame([("p1", date(2020, 1, 1)), ("p2", date(2020, 1, 1))],
                            ["patientid", "index_date"])
    schema = StructType([
        StructField("patientid", StringType()), StructField("index_date", DateType()),
        StructField("dthfl", IntegerType()), StructField("dthdt", DateType()),
        StructField("fued", DateType())])
    clin = s.createDataFrame([
        ("p1", date(2020, 1, 1), 1, date(2021, 1, 1), date(2021, 1, 1)),   # died ~12 months
        ("p2", date(2020, 1, 1), 0, None, date(2020, 7, 1)),               # censored ~6 months
    ], schema)
    rows = outcomes_stage.build({}, idx, clin, None, cfg).collect()
    by = {r["patientid"]: r for r in rows}
    assert by["p1"]["id3mosfu"] == 1 and by["p2"]["id3mosfu"] == 1         # index_end is 2025
    assert round(_f(by["p1"]["os"]), 1) == round(367 / 30.4375, 1)            # (datediff+1)/days_per_month
    assert round(_f(by["p2"]["os"]), 1) == round(183 / 30.4375, 1)


def test_line_outcomes_maintenance_cohort_keys_off_maintenance_line():
    # A lot{N}m cohort indexes the maintenance line, so vis120/TTD must key off lot{N}m* (lot1med),
    # NOT the non-maintenance lot{N}* (lot1ed). OC/EC keep line_outcomes off, so enable it here.
    if SparkSession is None:
        return
    from pyspark.sql.types import StructType, StructField, StringType, DateType, IntegerType
    s, cfg = _spark(), _cfg()
    cfg.pack("outcomes")["line_outcomes"] = {
        "visit_sources": ["visit", "telemed"], "visit_date_column": "visitdate", "ttd_from_line": 1}
    idx = s.createDataFrame([("p1", date(2020, 1, 1))], ["patientid", "index_date"])
    clin = s.createDataFrame(
        [("p1", date(2020, 1, 1), 0, None, date(2021, 1, 1))],
        StructType([StructField("patientid", StringType()), StructField("index_date", DateType()),
                    StructField("dthfl", IntegerType()), StructField("dthdt", DateType()),
                    StructField("fued", DateType())]))
    # line-1 maintenance last-activity (lot1med, 2020-06-01) is LATER than the non-maintenance line-1
    # end (lot1ed, 2020-03-01); the lot1m cohort's ttd must use lot1med.
    trt = s.createDataFrame(
        [("p1", date(2020, 1, 1), 1, date(2020, 3, 1), date(2020, 1, 1), date(2020, 6, 1))],
        StructType([StructField("patientid", StringType()), StructField("index_date", DateType()),
                    StructField("lotn", IntegerType()), StructField("lot1ed", DateType()),
                    StructField("lot1msd", DateType()), StructField("lot1med", DateType())]))
    cohort = {"id": "lot1m", "cohortn": 3, "label": "L1m", "lot_number": 1, "maintenance": True}
    row = outcomes_stage.build({}, idx, clin, trt, cfg, cohort).collect()[0]
    assert row["id3mosfu"] == 1
    assert round(row["ttd"], 1) == round(152 / 30.4375, 1)    # datediff(lot1med 2020-06-01) -> ~5.0
    assert round(row["ttd"], 1) != round(60 / 30.4375, 1)     # NOT lot1ed 2020-03-01 -> ~2.0


def test_progression_pfs_event_and_censor():
    # Real-world PFS: a qualifying progression (evidence 'Yes', not pseudo, after index) is the event;
    # no progression + no death -> censored at follow-up end.
    if SparkSession is None:
        return
    from pyspark.sql.types import StructType, StructField, StringType, DateType, IntegerType
    s, cfg = _spark(), _cfg()
    cfg.pack("outcomes")["progression"] = {
        "source": "progression", "date_column": "progressiondate",
        "evidence_columns": ["isradiographicevidence"],
        "pseudoprogression_column": "ispseudoprogressionmentioned",
        "yes_value": "Yes", "no_value": "No", "pfs2": True}
    idx = s.createDataFrame([("p1", date(2020, 1, 1)), ("p2", date(2020, 1, 1)),
                             ("p3", date(2099, 1, 1))], ["patientid", "index_date"])
    clin = s.createDataFrame(
        [("p1", date(2020, 1, 1), 0, None, date(2021, 1, 1)),
         ("p2", date(2020, 1, 1), 0, None, date(2020, 7, 1)),    # p2 censored at fu-end 2020-07-01
         ("p3", date(2099, 1, 1), 0, None, date(2099, 7, 1))],   # p3 indexes after study end -> id3mosfu=0
        StructType([StructField("patientid", StringType()), StructField("index_date", DateType()),
                    StructField("dthfl", IntegerType()), StructField("dthdt", DateType()),
                    StructField("fued", DateType())]))
    prog = s.createDataFrame(   # p1 and p3 progress (radiographic, not pseudo, after index); p2 does not
        [("p1", date(2020, 4, 1), "Yes", "No"), ("p3", date(2099, 4, 1), "Yes", "No")],
        StructType([StructField("patientid", StringType()), StructField("progressiondate", DateType()),
                    StructField("isradiographicevidence", StringType()),
                    StructField("ispseudoprogressionmentioned", StringType())]))
    by = {r["patientid"]: r for r in
          outcomes_stage.build({"progression": prog}, idx, clin, None, cfg).collect()}
    assert by["p1"]["pfsfl"] == 1 and round(_f(by["p1"]["pfs"]), 1) == round(92 / 30.4375, 1)   # to progression
    assert by["p2"]["pfsfl"] == 0 and round(_f(by["p2"]["pfs"]), 1) == round(183 / 30.4375, 1)  # censored at fued
    # p3 has a qualifying progression but is ineligible (id3mosfu=0) -> the whole family is gated to null.
    assert by["p3"]["id3mosfu"] == 0 and by["p3"]["pfsfl"] is None and by["p3"]["pfsdt"] is None


def test_progression_pfs2_dedupes_same_day_evidence():
    # Two qualifying progression rows on the SAME date are one event, not two: PFS2 must not fire on
    # the duplicate. A genuinely distinct second date DOES drive PFS2.
    if SparkSession is None:
        return
    from pyspark.sql.types import StructType, StructField, StringType, DateType, IntegerType
    s, cfg = _spark(), _cfg()
    cfg.pack("outcomes")["progression"] = {
        "source": "progression", "date_column": "progressiondate",
        "evidence_columns": ["isradiographicevidence"],
        "pseudoprogression_column": "ispseudoprogressionmentioned",
        "yes_value": "Yes", "no_value": "No", "pfs2": True}
    idx = s.createDataFrame([("dup", date(2020, 1, 1)), ("two", date(2020, 1, 1))],
                            ["patientid", "index_date"])
    clin = s.createDataFrame(
        [("dup", date(2020, 1, 1), 0, None, date(2022, 1, 1)),
         ("two", date(2020, 1, 1), 0, None, date(2022, 1, 1))],
        StructType([StructField("patientid", StringType()), StructField("index_date", DateType()),
                    StructField("dthfl", IntegerType()), StructField("dthdt", DateType()),
                    StructField("fued", DateType())]))
    prog = s.createDataFrame(
        [("dup", date(2020, 4, 1), "Yes", "No"), ("dup", date(2020, 4, 1), "Yes", "No"),   # same day x2
         ("two", date(2020, 4, 1), "Yes", "No"), ("two", date(2020, 8, 1), "Yes", "No")],   # two distinct
        StructType([StructField("patientid", StringType()), StructField("progressiondate", DateType()),
                    StructField("isradiographicevidence", StringType()),
                    StructField("ispseudoprogressionmentioned", StringType())]))
    by = {r["patientid"]: r for r in
          outcomes_stage.build({"progression": prog}, idx, clin, None, cfg).collect()}
    # 'dup' progressed once (the two same-day rows collapse) -> no real 2nd progression, PFS2 censored.
    assert by["dup"]["pfsfl"] == 1 and by["dup"]["pfs2fl"] == 0
    # 'two' has a genuine 2nd progression on 2020-08-01 -> PFS2 fires there (~7.0 months).
    assert by["two"]["pfs2fl"] == 1 and round(_f(by["two"]["pfs2"]), 1) == round(214 / 30.4375, 1)


def test_derived_cohorts_appends_filtered_relabeled():
    # A derived cohort splits rows out of its `from` cohorts (by cohortn) matching `where`, relabeled.
    if SparkSession is None:
        return
    from pyspark.sql import functions as F, Window
    from engine.build_ads import _apply_derived_cohorts
    s = _spark()
    ads = s.createDataFrame(
        [("p1", 4, "L2", "Resistant"), ("p2", 4, "L2", "Sensitive"),     # cohortn 4 = lot2
         ("p3", 6, "L3", "Resistant"), ("p4", 2, "L1", "Resistant")],    # p4 cohortn 2 not in `from`
        ["patientid", "cohortn", "cohort", "plat_sen_v1"])

    class _Cfg:                                                          # _apply_derived_cohorts needs only these
        cohorts = [{"id": "lot1", "cohortn": 2}, {"id": "lot2", "cohortn": 4}, {"id": "lot3", "cohortn": 6}]
        raw = {"derived_cohorts": [{"id": "proc", "cohortn": 9, "label": "2L+ PROC",
                                    "from": ["lot2", "lot3"], "where": "plat_sen_v1 = 'Resistant'"}]}

    out = _apply_derived_cohorts(ads, _Cfg(), F, Window)
    proc = [r for r in out.collect() if r["cohortn"] == 9]
    assert {r["patientid"] for r in proc} == {"p1", "p3"}    # resistant 2L/3L only (p2 sensitive, p4 1L)
    assert all(r["cohort"] == "2L+ PROC" for r in proc)
    assert out.count() == 6                                  # 4 original rows + 2 PROC rows


def test_derived_cohorts_pick_first_one_row_per_patient():
    # pick: first keeps only the EARLIEST qualifying line per patient (PROC = first platinum resistance).
    if SparkSession is None:
        return
    from pyspark.sql import functions as F, Window
    from engine.build_ads import _apply_derived_cohorts
    s = _spark()
    ads = s.createDataFrame(
        [("multi", 4, "L2", date(2020, 1, 1), "Resistant"),
         ("multi", 6, "L3", date(2021, 1, 1), "Resistant"),    # same patient, LATER resistant line
         ("single", 4, "L2", date(2020, 6, 1), "Resistant")],
        ["patientid", "cohortn", "cohort", "index_date", "plat_sen_v1"])

    class _Cfg:
        cohorts = [{"id": "lot2", "cohortn": 4}, {"id": "lot3", "cohortn": 6}]
        raw = {"derived_cohorts": [{"id": "proc", "cohortn": 9, "label": "PROC", "pick": "first",
                                    "from": ["lot2", "lot3"], "where": "plat_sen_v1 = 'Resistant'"}]}

    proc = [r for r in _apply_derived_cohorts(ads, _Cfg(), F, Window).collect() if r["cohortn"] == 9]
    assert sorted(r["patientid"] for r in proc) == ["multi", "single"]    # one PROC row per patient
    multi = next(r for r in proc if r["patientid"] == "multi")
    assert multi["index_date"] == date(2020, 1, 1)                        # the EARLIEST resistant line


def test_platinum_sensitivity_classifies_pfi():
    # PFI from the prior platinum line's end to the current line's start: >= threshold -> Sensitive,
    # < threshold -> Resistant. Attaches plat_sen_v1 to the 2L line cohort.
    if SparkSession is None:
        return
    from pyspark.sql import functions as F
    s, cfg = _spark(), _cfg()
    cfg.pack("outcomes")["platinum_sensitivity"] = {
        "source": "lot", "line_number_column": "linenumber", "name_column": "linename",
        "start_column": "startdate", "end_column": "enddate",
        "platinum_agents": ["%carboplatin%", "%cisplatin%"], "threshold_months": 6,
        "pfi_window_days": 14, "from_line": 2}
    lot = s.createDataFrame(
        [("sens", 1, "Carboplatin", date(2020, 1, 1), date(2020, 4, 1)),   # platinum L1
         ("sens", 2, "Doxorubicin", date(2021, 1, 1), date(2021, 6, 1)),   # L2 ~9 mo later -> Sensitive
         ("res",  1, "Carboplatin", date(2020, 1, 1), date(2020, 4, 1)),
         ("res",  2, "Doxorubicin", date(2020, 6, 1), date(2020, 9, 1))],  # L2 ~2 mo later -> Resistant
        ["patientid", "linenumber", "linename", "startdate", "enddate"])
    idx = s.createDataFrame([("sens", date(2021, 1, 1)), ("res", date(2020, 6, 1))],
                            ["patientid", "index_date"])
    by = {r["patientid"]: r for r in
          proc_stage.build(F, {"lot": lot}, idx, cfg, {"lot_number": 2}).collect()}
    assert by["sens"]["plat_sen_v1"] == "Sensitive" and round(_f(by["sens"]["pfi"]), 1) == round(275 / 30.4375, 1)
    assert by["res"]["plat_sen_v1"] == "Resistant" and round(_f(by["res"]["pfi"]), 1) == round(61 / 30.4375, 1)
    assert by["res"]["pcycled"] == 0                       # L2 is non-platinum -> not a re-challenge


def test_surgery_pcs_vs_ics_classification():
    # Surgery before 1L chemo -> Primary (PCS); at/after 1L start -> Interval (ICS); neoadj when during
    # the 1L window. tt_first_tx_diag = days from diagnosis to the earlier of surgery / 1L start.
    if SparkSession is None:
        return
    from pyspark.sql import functions as F
    from engine.stages.clinical import _surgery
    s = _spark()
    enh = s.createDataFrame(
        [("pcs", "Yes", date(2019, 12, 1), date(2019, 10, 1)),    # surgery BEFORE 1L -> PCS
         ("ics", "Yes", date(2020, 3, 1), date(2019, 10, 1)),     # surgery AFTER 1L start -> ICS
         ("no", "No", date(2019, 12, 1), date(2019, 10, 1))],     # No surgery + stray date -> No Surgery
        ["patientid", "issurgery", "surgerydate", "diagnosisdate"])
    lot = s.createDataFrame(
        [("pcs", 1, "False", date(2020, 1, 1), date(2020, 6, 1)),
         ("ics", 1, "False", date(2020, 1, 1), date(2020, 6, 1)),
         ("no", 1, "False", date(2020, 1, 1), date(2020, 6, 1))],
        ["patientid", "linenumber", "ismaintenancetherapy", "startdate", "enddate"])
    idx = s.createDataFrame([("pcs", date(2020, 1, 1)), ("ics", date(2020, 1, 1)),
                             ("no", date(2020, 1, 1))], ["patientid", "index_date"])
    scfg = {"source": "enhanced", "surgery_flag_column": "issurgery", "surgery_date_column": "surgerydate",
            "init_date_column": "diagnosisdate", "line_source": "lot", "line_number_column": "linenumber",
            "line_start_column": "startdate", "line_end_column": "enddate",
            "maintenance_column": "ismaintenancetherapy", "yes_value": "Yes", "no_value": "No",
            "pcs_label": "Primary cytoreductive surgery (PCS)",
            "ics_label": "Interval cytoreductive surgery (ICS)", "none_label": "No Surgery"}
    by = {r["patientid"]: r for r in _surgery(F, {"enhanced": enh, "lot": lot}, idx, scfg).collect()}
    assert by["pcs"]["surgn"] == 1 and "PCS" in by["pcs"]["surg"] and by["pcs"]["neoadj"] == "No"
    assert by["ics"]["surgn"] == 2 and "ICS" in by["ics"]["surg"] and by["ics"]["neoadj"] == "Yes"
    assert by["ics"]["tt_first_tx_diag"] == 92             # diagnosis 2019-10-01 -> 1L start 2020-01-01
    # issurgery='No' with a stray date must NOT be classified as PCS/neoadj (gated on the flag).
    assert by["no"]["surg"] == "No Surgery" and by["no"]["surgn"] == 3 and by["no"]["neoadj"] == "No"


def test_baseline_ecog_same_date_tie_picks_worst_known():
    # 6-step final tie-break: among same-gap + same-date records the WORST (max) ECOG wins, and a real
    # grade beats Unknown (which ranks last).
    if SparkSession is None:
        return
    from engine.stages.clinical import baseline_ecog
    s, cfg = _spark(), _cfg()
    ecfg = cfg.pack("clinical")["baseline_ecog"]
    idx = s.createDataFrame([("p1", date(2020, 1, 10)), ("p2", date(2020, 1, 10))],
                            ["patientid", "index_date"])
    ec = s.createDataFrame(
        [("p1", date(2020, 1, 8), "1"), ("p1", date(2020, 1, 8), "3"),         # tie -> max grade 3
         ("p2", date(2020, 1, 8), "2"), ("p2", date(2020, 1, 8), "Unknown")],  # tie -> grade 2 beats Unknown
        ["patientid", "ecogdate", "ecogvalue"])
    by = {r["patientid"]: r for r in baseline_ecog({"baseline_ecog": ec}, idx, ecfg).collect()}
    assert by["p1"]["ecog"] == "3" and by["p2"]["ecog"] == "2"


def test_min_avail_date_earliest_across_sources():
    # minavaildate = earliest of the base date and the first date in each source; basedur = index - it.
    if SparkSession is None:
        return
    from pyspark.sql import functions as F
    from engine.stages.clinical import _min_avail_date
    s = _spark()
    idx = s.createDataFrame([("p1", date(2021, 1, 1))], ["patientid", "index_date"])
    src = {
        "enh": s.createDataFrame([("p1", date(2020, 6, 1))], ["patientid", "diagnosisdate"]),
        "visit": s.createDataFrame([("p1", date(2020, 3, 1)), ("p1", date(2020, 9, 1))],
                                   ["patientid", "visitdate"]),
        "lot": s.createDataFrame([("p1", date(2020, 12, 1))], ["patientid", "startdate"]),
    }
    blk = {"base_columns": ["diagnosisdate"],
           "sources": [{"source": "visit", "date_column": "visitdate"},
                       {"source": "lot", "date_column": "startdate"}]}
    row = _min_avail_date(F, src, idx, blk, "enh").collect()[0]
    assert row["minavaildate"] == date(2020, 3, 1)    # earliest: visit 2020-03 < diagnosis 2020-06 < lot 2020-12
    assert row["basedur"] == 306                       # datediff(2021-01-01, 2020-03-01)


def test_passthrough_columns_and_presence_flag():
    # Config-driven enhanced pass-through: alias raw columns + a presence flag (EC radiation).
    if SparkSession is None:
        return
    from pyspark.sql import functions as F
    from engine.stages.clinical import _passthrough
    s = _spark()
    enh = s.createDataFrame(
        [("p1", "EBRT", date(2020, 5, 1)), ("p2", None, None)],     # p2 has no radiation date
        ["patientid", "radiationtype", "radiationtherapydate"])
    idx = s.createDataFrame([("p1", date(2021, 1, 1)), ("p2", date(2021, 1, 1))],
                            ["patientid", "index_date"])
    blk = {"source": "enh",
           "columns": [{"column": "radiationtype", "as": "radiation_type"},
                       {"column": "radiationtherapydate", "as": "radiationdt"}],
           "flags": [{"name": "radiation_flag", "from": "radiationtherapydate",
                      "absent": "No/unknown", "present": "Yes"}]}
    by = {r["patientid"]: r for r in _passthrough(F, {"enh": enh}, idx, blk, "enh").collect()}
    assert by["p1"]["radiation_type"] == "EBRT" and by["p1"]["radiation_flag"] == "Yes"
    assert by["p2"]["radiationdt"] is None and by["p2"]["radiation_flag"] == "No/unknown"


def test_windowed_categorical_answers_the_value_at_index_not_the_latest_value():
    """A payer category is the coverage IN FORCE AT INDEX, and that is a different question from
    the patient's latest coverage ever — which is all `_categorical_pick` could answer.

    The fixture is built so the two answers DISAGREE. p1 is commercial at index and switches to
    Medicare eighteen months later; the unwindowed pick returns Medicare (latest), the windowed one
    returns Commercial (nearest to index, inside the window). A test whose fixture made them agree
    would pass against either implementation and prove nothing.

    And the second half is the reason this is keyed on (patientid, index_date): p2 appears in TWO
    cohorts with two index dates and legitimately has two different payers. Keyed on patientid
    alone, one cohort's answer would be broadcast across the other.
    """
    if SparkSession is None:
        return
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window
    from engine.stages.clinical import _categorical_pick, _categorical_pick_windowed
    s = _spark()
    cov = s.createDataFrame([
        ("p1", "COMMERCIAL", date(2021, 1, 10)),      # in force at p1's index
        ("p1", "MEDICARE",   date(2022, 7, 1)),       # later, and outside the window
        ("p2", "MEDICAID",   date(2020, 2, 1)),       # in force at p2's FIRST index
        ("p2", "COMMERCIAL", date(2023, 2, 1)),       # in force at p2's SECOND index
    ], ["patientid", "payertype", "coveragedate"])
    idx = s.createDataFrame([("p1", date(2021, 1, 1)),
                             ("p2", date(2020, 1, 15)),
                             ("p2", date(2023, 3, 1))], ["patientid", "index_date"])
    groups = [{"from_equals_ci": ["COMMERCIAL"], "label": "Commercial", "code": 1},
              {"from_equals_ci": ["MEDICARE"], "label": "Medicare", "code": 2},
              {"from_equals_ci": ["MEDICAID"], "label": "Medicaid", "code": 3},
              {"when": "fallthrough", "label": "Unknown", "code": 9}]
    cat = {"name": "payer", "column": "payertype", "date_column": "coveragedate",
           "groups": groups, "window_days": [-90, 30]}

    windowed = {(r["patientid"], r["index_date"]): (r["payer"], r["payern"])
                for r in _categorical_pick_windowed(F, Window, cov, cat, idx).collect()}
    assert windowed[("p1", date(2021, 1, 1))] == ("Commercial", 1)
    # ...the same patient, two cohorts, two answers — the whole reason for the (patient, index) key
    assert windowed[("p2", date(2020, 1, 15))] == ("Medicaid", 3)
    assert windowed[("p2", date(2023, 3, 1))] == ("Commercial", 1)

    # THE CONTRAST: the unwindowed pick answers the other question, and gets p1 wrong for this use.
    latest = {r["patientid"]: r["payer"] for r in
              _categorical_pick(F, Window, cov, "payertype", groups, "payer",
                                "coveragedate", "latest").collect()}
    assert latest["p1"] == "Medicare", \
        "the fixture no longer distinguishes the two picks — it would pass against either"

    # A record outside the window contributes NOTHING: p1 with only the 2022 row falls through to
    # no row at all (a left join elsewhere makes that NULL), rather than reaching back for it.
    only_late = cov.filter((F.col("patientid") == "p1") & (F.col("payertype") == "MEDICARE"))
    assert _categorical_pick_windowed(F, Window, only_late, cat,
                                      idx.filter(F.col("patientid") == "p1")).collect() == []


def test_response_best_of_window_carries_its_assessment_date():
    """Real-world response is a BEST-of category over a window, with the date it was assessed.

    Both halves are load-bearing and neither existed before. `pick: priority` already ranked rows
    by a config-stated label order — that is how a multi-gene HRR panel rolls up to its worst-case
    status — and best overall response is the same operation with the order reading CR > PR > SD >
    PD. What was missing is that `response` was not in the block list the stage loops, and that the
    ASSESSMENT DATE was not emitted: for a priority pick the winning row is NOT the nearest one, so
    nothing downstream can re-derive when the best response happened.

    The fixture separates the two orderings on purpose. p1's best response (PR) is the FURTHEST
    record from index and its worst (PD) is the nearest, so a nearest-pick would return PD and a
    priority-pick returns PR — and the emitted date must be PR's, not the nearest record's.
    """
    if SparkSession is None:
        return
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window
    from engine.stages.clinical import _closest_panel
    s = _spark()
    resp = s.createDataFrame([
        ("p1", "RESPONSE", "Stable Disease",     date(2021, 3, 1)),
        ("p1", "RESPONSE", "Partial Response",   date(2021, 6, 1)),   # BEST, and furthest away
        ("p1", "RESPONSE", "Progressive Disease", date(2021, 2, 1)),  # nearest to index
        ("p2", "RESPONSE", "Complete Response",  date(2021, 4, 1)),
    ], ["patientid", "assessment", "responsevalue", "assessmentdate"])
    idx = s.createDataFrame([("p1", date(2021, 1, 1)), ("p2", date(2021, 1, 1))],
                            ["patientid", "index_date"])
    groups = [{"from_equals_ci": ["Complete Response"], "label": "CR", "code": 1},
              {"from_equals_ci": ["Partial Response"], "label": "PR", "code": 2},
              {"from_equals_ci": ["Stable Disease"], "label": "SD", "code": 3},
              {"from_equals_ci": ["Progressive Disease"], "label": "PD", "code": 4},
              {"when": "fallthrough", "label": "Not evaluable", "code": 9}]
    blk = {"source": "resp", "name_column": "assessment", "value_column": "responsevalue",
           "date_column": "assessmentdate", "window_days": [0, 365], "emit_date": True,
           "panel": [{"name": "rwresp", "match": "RESPONSE", "groups": groups,
                      "pick": "priority", "priority": ["CR", "PR", "SD", "PD", "Not evaluable"]}]}
    by = {r["patientid"]: r for r in _closest_panel(F, Window, resp, blk, idx).collect()}
    assert by["p1"]["rwresp"] == "PR" and by["p1"]["rwrespn"] == 2
    assert by["p1"]["rwrespdt"] == date(2021, 6, 1), \
        "the emitted date is not the winning record's — for a priority pick it is not the nearest"
    assert by["p2"]["rwresp"] == "CR" and by["p2"]["rwrespdt"] == date(2021, 4, 1)

    # THE CONTRAST that makes the priority pick meaningful: the default nearest-pick returns the
    # worst of the three for p1, because PD happens to be closest to index.
    nearest_blk = dict(blk, panel=[{"name": "rwresp", "match": "RESPONSE", "groups": groups}])
    near = {r["patientid"]: r for r in _closest_panel(F, Window, resp, nearest_blk, idx).collect()}
    assert near["p1"]["rwresp"] == "PD", \
        "the fixture no longer distinguishes priority from nearest — it would pass against either"

    # ...and emit_date is OPT-IN: without it the block emits exactly the two columns it always did,
    # which is what keeps the biomarker and lab panels byte-identical.
    no_date = _closest_panel(F, Window, resp, dict(blk, emit_date=False), idx)
    assert "rwrespdt" not in no_date.columns and "rwresp" in no_date.columns


def test_comorbidity_score_counts_conditions_once_and_honours_hierarchy():
    """Two ways to compute a plausible-looking wrong comorbidity score, both exercised here.

    COUNTING ROWS instead of conditions. p1 carries three myocardial-infarction codes in the
    window; MI is worth 1, so the score contribution is 1, not 3. Summing rows would measure how
    often a patient was coded — health-system contact — and present it as disease burden, and the
    number would look entirely reasonable.

    IGNORING HIERARCHY. p2 has both mild and severe liver disease. Charlson-type indices do not
    count both: the severe member supersedes the mild one. Counting both inflates the score for
    precisely the sickest patients, which is the direction that does the most damage to a
    confounder.

    p3 has a diagnosis OUTSIDE the lookback and nothing inside it, so it scores NULL rather than 0 —
    "no data" and "no comorbidity" are different facts and the left join keeps them apart.
    """
    if SparkSession is None:
        return
    from pyspark.sql import functions as F
    from engine.stages.clinical import comorbidity_index
    s = _spark()
    dx = s.createDataFrame([
        ("p1", "I21.0", date(2020, 6, 1)),    # MI, three times, one condition
        ("p1", "I21.9", date(2020, 7, 1)),
        ("p1", "I22.1", date(2020, 8, 1)),
        ("p1", "E11.9", date(2020, 9, 1)),    # diabetes, weight 1
        ("p2", "K70.0", date(2020, 5, 1)),    # mild liver disease, weight 1
        ("p2", "K72.1", date(2020, 6, 1)),    # SEVERE liver disease, weight 3 — supersedes mild
        ("p3", "I21.0", date(2015, 1, 1)),    # outside the lookback entirely
    ], ["patientid", "dxcode", "dxdate"])
    idx = s.createDataFrame([("p1", date(2021, 1, 1)), ("p2", date(2021, 1, 1)),
                             ("p3", date(2021, 1, 1))], ["patientid", "index_date"])
    blk = {"source": "dx", "code_column": "dxcode", "code_system": "icd10cm",
           "date_column": "dxdate", "window_days": [-365, -1], "name": "cci",
           "conditions": [
               {"name": "mi", "weight": 1, "code_prefix_any": ["I21", "I22"]},
               {"name": "diabetes", "weight": 1, "code_prefix_any": ["E10", "E11"]},
               {"name": "liver_mild", "weight": 1, "code_prefix_any": ["K70", "K71"]},
               {"name": "liver_severe", "weight": 3, "code_prefix_any": ["K72"],
                "supersedes": ["liver_mild"]},
           ]}
    by = {r["patientid"]: r["cci"] for r in comorbidity_index(F, {"dx": dx}, idx, blk).collect()}
    assert by["p1"] == 2, f"MI(1) + diabetes(1) = 2; got {by['p1']} — three MI rows counted as three"
    assert by["p2"] == 3, f"severe liver(3) alone, mild superseded; got {by['p2']}"
    assert by["p3"] is None, "a patient with no in-window diagnosis scored a number, not NULL"

    # Without the hierarchy declaration the same fixture scores 4 — which is the whole point of
    # `supersedes` being config: the rule is clinical, and the engine must not assume it.
    flat = dict(blk, conditions=[{k: v for k, v in c.items() if k != "supersedes"}
                                 for c in blk["conditions"]])
    by2 = {r["patientid"]: r["cci"] for r in comorbidity_index(F, {"dx": dx}, idx, flat).collect()}
    assert by2["p2"] == 4, "the fixture no longer distinguishes hierarchy from its absence"

    # Bands turn the score into the published band label + code, like age_bands.
    banded = dict(blk, bands=[{"code": 1, "label": "0-1", "max": 1},
                              {"code": 2, "label": "2+", "min": 2}])
    rows = {r["patientid"]: r for r in comorbidity_index(F, {"dx": dx}, idx, banded).collect()}
    assert rows["p1"]["ccigr"] == "2+" and rows["p1"]["ccigrn"] == 2
    assert rows["p2"]["ccigr"] == "2+"


def test_comorbidity_hierarchy_is_transitive_and_weights_are_not_truncated():
    """Two defects an external review found in the first version of this family.

    A CHAIN, masked sequentially, leaves the bottom of it counted. severe supersedes moderate,
    moderate supersedes mild; masking column by column zeroes moderate first, so the later test for
    "is moderate present" reads the already-zeroed flag and mild survives. The score then depends on
    the order the conditions happen to be listed in — reorder the YAML and the number changes. The
    closure is computed first and every mask reads the flags as aggregated.

    FRACTIONAL WEIGHTS were cast to int unconditionally, so a 1.5 + 0.5 index scored 2 and a
    0.5 + 0.5 index scored 1 — but 1.5 alone scored 1, silently truncated. The cast now follows the
    weights.
    """
    if SparkSession is None:
        return
    from pyspark.sql import functions as F
    from engine.stages.clinical import comorbidity_index
    s = _spark()
    dx = s.createDataFrame([("p1", "K70.0", date(2020, 6, 1)),     # mild
                            ("p1", "K71.0", date(2020, 6, 2)),     # moderate, supersedes mild
                            ("p1", "K72.1", date(2020, 6, 3))],    # severe, supersedes moderate
                           ["patientid", "dxcode", "dxdate"])
    idx = s.createDataFrame([("p1", date(2021, 1, 1))], ["patientid", "index_date"])
    chain = {"source": "dx", "code_column": "dxcode", "code_system": "icd10cm",
             "date_column": "dxdate", "window_days": [-365, -1], "name": "cci",
             "conditions": [
                 {"name": "mild", "weight": 1, "code_prefix_any": ["K70"]},
                 {"name": "moderate", "weight": 2, "code_prefix_any": ["K71"],
                  "supersedes": ["mild"]},
                 {"name": "severe", "weight": 3, "code_prefix_any": ["K72"],
                  "supersedes": ["moderate"]}]}
    got = comorbidity_index(F, {"dx": dx}, idx, chain).collect()[0]["cci"]
    assert got == 3, f"severe alone scores 3; got {got} — the chain left a superseded member counted"

    # ...and the answer must not depend on the LISTING ORDER, which is what sequential masking made
    # it depend on. The same three conditions, reversed.
    rev = dict(chain, conditions=list(reversed(chain["conditions"])))
    assert comorbidity_index(F, {"dx": dx}, idx, rev).collect()[0]["cci"] == 3, \
        "reordering the conditions changed the score"

    # FRACTIONAL weights survive. 1.5 alone would truncate to 1 under an unconditional int cast.
    frac = {"source": "dx", "code_column": "dxcode", "code_system": "icd10cm",
            "date_column": "dxdate", "window_days": [-365, -1], "name": "cci",
            "conditions": [{"name": "mild", "weight": 1.5, "code_prefix_any": ["K70"]}]}
    assert comorbidity_index(F, {"dx": dx}, idx, frac).collect()[0]["cci"] == 1.5
    # ...while an all-integer index still comes back an int, not a float.
    whole = dict(frac, conditions=[{"name": "mild", "weight": 2, "code_prefix_any": ["K70"]}])
    v = comorbidity_index(F, {"dx": dx}, idx, whole).collect()[0]["cci"]
    assert v == 2 and isinstance(v, int), f"an integer-weighted score came back as {type(v)}"


def test_tfl_generate_skips_inapplicable_table():
    # A TFL whose columns aren't in the ADS (the OC platinum table on a prostate-like ADS) must be
    # SKIPPED, not error on the unresolved `where` column — otherwise it fails the (now required) TFL
    # deliverable on prostate.
    if SparkSession is None:
        return
    from engine import tfl as tfl_engine
    s = _spark()
    ads = s.createDataFrame([("A", "1L"), ("A", "2L"), ("B", "1L")], ["cohort", "lot1cat"])
    specs = {"tfls": [
        {"id": "t4_platinum", "kind": "table", "by": "cohort", "summarise": ["plat_sen_v1"],
         "where": "plat_sen_v1 IS NOT NULL", "where_columns": ["plat_sen_v1"]},
        {"id": "t3", "kind": "table", "by": "cohort", "summarise": ["lotcat"]}]}
    out = tfl_engine.generate(s, ads, specs)
    assert "t4_platinum" not in out      # skipped (no unresolved-column error)
    assert "t3" in out                   # the producible table still generates (lotcat -> lot1cat)


def test_record_selection_is_named_and_defaults_to_todays_behaviour():
    """THE SAME THREE QUESTIONS, ASKED ONCE: which DATE, which ROW, and what on a TIE.

    `_closest_panel` had two hardcoded ordering branches with the tie fixed at "earliest". That is
    why so much of ENGINE_GAPS.md is one shape — G-BIOMARKER-CLOSEST, G-LABS, G-VITALS-DATES,
    G-MET-METDT and G-PSA-INDEX-PICK each ask for a different point in this same space, and each
    needed engine work to reach it. They are now named registry members a pack states in YAML.

    THE DEFAULTS MUST REPRODUCE TODAY EXACTLY, or this is not a refactor, it is a silent change to
    every existing product's biomarker and lab values. The fixture is deliberately EQUIDISTANT — one
    record five days before index and one five days after — because that is the only arrangement in
    which the tie-break is observable at all; on any other data the default and its alternative agree
    and the assertion proves nothing.

    `date_basis: later_of` is B2's shape: the prostate feed ships `resultdate` +
    `specimencollecteddate` and no `biomarkerdate`, and G-LABS wants the same later-of rule. Both
    become a config edit rather than an engine change.
    """
    from pyspark.sql import Window, functions as F
    from engine.stages.clinical import _closest_panel
    s = _spark()
    idx = (s.createDataFrame([("p1", "2026-01-10")], "patientid string, index_date string")
           .withColumn("index_date", F.col("index_date").cast("date")))
    src = s.createDataFrame(
        [("p1", "HRR", "Positive", "2026-01-05", "2026-01-06"),
         ("p1", "HRR", "Negative", "2026-01-15", "2026-01-16")],
        "patientid string, biomarkername string, biomarkerstatus string, "
        "resultdate string, specimencollecteddate string")
    for c in ("resultdate", "specimencollecteddate"):
        src = src.withColumn(c, F.col(c).cast("date"))
    src = src.withColumn("biomarkerdate", F.col("resultdate"))

    groups = [{"code": 1, "label": "Positive", "from_equals_ci": ["Positive"]},
              {"code": 2, "label": "Negative", "from_equals_ci": ["Negative"]}]
    base = {"source": "biomarkers", "name_column": "biomarkername",
            "value_column": "biomarkerstatus", "date_column": "biomarkerdate",
            "window_days": [-30, 7],
            "panel": [{"name": "hrr", "match_any": ["HRR"], "groups": groups}]}

    def pick(blk):
        return _closest_panel(F, Window, src, blk, idx).collect()[0]["hrr"]

    assert pick(base) == "Positive", "the DEFAULT selection changed — every pack's values move"
    assert pick({**base, "tie_break": "later"}) == "Negative", "tie_break: later is not honoured"
    assert pick({**base, "pick": "earliest"}) == "Positive"
    assert pick({**base, "pick": "latest"}) == "Negative"

    # The pre-registry spelling still works, so no pack has to be edited for this change...
    legacy = {"name": "hrr", "match_any": ["HRR"], "groups": groups,
              "aggregate": "priority", "priority": ["Positive", "Negative"]}
    assert pick({**base, "panel": [legacy]}) == "Positive"
    # ...and the registry spelling means the same thing.
    modern = {k: v for k, v in legacy.items() if k != "aggregate"}
    assert pick({**base, "panel": [{**modern, "pick": "priority"}]}) == "Positive"

    # B2's shape: two candidate date columns, no single one, and NO `date_column` key at all.
    later_of = {k: v for k, v in base.items() if k != "date_column"}
    later_of["date_basis"] = {"method": "later_of",
                              "columns": ["resultdate", "specimencollecteddate"]}
    assert pick(later_of) == "Positive", "date_basis: later_of did not resolve a record date"


def test_a_mistyped_value_matcher_is_refused_not_ignored():
    """`from_startwith_ci` — one letter short — compiled to `CASE  ELSE 'CHECK' END`.

    `_stage_case` read the operators it knew and ignored every other key, so a typo produced a group
    that claims nothing and every patient landed in the fallthrough. STAGE became CHECK for the whole
    product and nothing failed. An operator vocabulary that is not enforced is a suggestion.

    Pure Python — no Spark needed — but it lives beside the compiler's other tests because it is
    about the same function.
    """
    from engine.stages.clinical import (GROUP_MARKERS, VALUE_MATCHERS, _stage_case,
                                        value_matcher_errors)
    ok = [{"when": "missing", "label": "Unknown", "code": 5},
          {"label": "Early", "code": 1, "from_startswith_ci": ["II"]},
          {"when": "fallthrough", "label": "CHECK", "code": 99}]
    assert value_matcher_errors(ok) == [], value_matcher_errors(ok)

    typo = [{"label": "Early", "code": 1, "from_startwith_ci": ["II"]},
            {"when": "fallthrough", "label": "CHECK", "code": 99}]
    # The damage is real and silent without the check...
    assert _stage_case(typo, "groupstage", "label") == "CASE  ELSE 'CHECK' END"
    # ...so the check must name it.
    assert any("is not a value matcher" in e for e in value_matcher_errors(typo))

    assert any("no matcher and no marker" in e
               for e in value_matcher_errors([{"label": "E", "code": 1}]))
    assert any("is not a group marker" in e for e in
               value_matcher_errors([{"when": "fallthrouhg", "label": "C", "code": 99}]))
    # Both markers are reserved words the compiler acts on, not labels a pack may invent.
    assert set(GROUP_MARKERS) == {"fallthrough", "missing"}
    assert "from_equals_ci" in VALUE_MATCHERS and "from_startwith_ci" not in VALUE_MATCHERS

    # A MARKER GROUP MATCHES BY POSITION, and `_stage_case` skips it entirely — so a group carrying
    # both a marker and matchers states two ways of claiming a value and runs only one. Same
    # fail-open as the typo above, wearing a valid key: the validator saw a legal marker and stopped
    # looking. Proven the same way — the damage first, then the refusal.
    both = [{"when": "missing", "label": "Unknown", "code": 5, "from_equals_ci": ["N/A"]},
            {"when": "fallthrough", "label": "CHECK", "code": 99}]
    sql = _stage_case(both, "groupstage", "label")
    assert "'N/A'" not in sql, "the matcher IS compiled — this test has the wrong subject"
    assert any("never evaluated" in e for e in value_matcher_errors(both)), \
        "a marker group's matchers are dropped silently"

    # ...and only the FIRST group with a given marker is emitted, so a second one is dead config.
    dupe = [{"when": "missing", "label": "A", "code": 1},
            {"when": "missing", "label": "B", "code": 2},
            {"when": "fallthrough", "label": "C", "code": 9}]
    assert "'B'" not in _stage_case(dupe, "g", "label")
    assert any("only the first is emitted" in e for e in value_matcher_errors(dupe))
    assert any("only the first is emitted" in e for e in value_matcher_errors(
        [{"when": "fallthrough", "label": "A", "code": 1},
         {"when": "fallthrough", "label": "B", "code": 2}])), "duplicate fallthrough accepted"


def test_from_regex_classifies_on_real_spark():
    """`from_regex` end to end — because the ONLY thing that settles the escaping is Spark.

    The compiler emitting a plausible-looking string proves nothing here. A pattern crosses four
    layers before java.util.regex sees it (YAML, the Python literal, the Spark string literal, the
    regex engine), and the third one is where it dies: Spark parses escapes inside a string literal
    and drops an unrecognised one, so `'\\d'` IS the string "d" and `v REGEXP '\\d'` matches nothing
    at all — no error, no warning, every row in the fallthrough. That is why `codelists.sql_str`
    doubles backslashes, and this test is what proves the doubling is right rather than merely
    present. Revert that `.replace("\\\\", "\\\\\\\\")` and the Gleason row below lands on CHECK.
    """
    from pyspark.sql import Row
    from engine.stages.clinical import _stage_case
    s = _spark()

    groups = [
        {"when": "missing", "label": "Unknown", "code": 5},
        # ANCHORED and whitespace-tolerant — the case the four named operators cannot cover without
        # enumerating every spelling the feed happens to use. Needs \s, hence a backslash.
        {"label": "Gleason7", "code": 7, "from_regex": [r"^\s*[34]\s*\+\s*[34]\s*=\s*7\s*$"]},
        # Case-insensitivity is asked for with Java's inline flag, never by folding the pattern.
        {"label": "MutNeg", "code": 2, "from_regex": [r"(?i)^mutation\s+negative$"]},
        {"when": "fallthrough", "label": "CHECK", "code": 99},
    ]
    df = s.createDataFrame([Row(v="3 + 4 = 7"), Row(v="4+3=7"), Row(v="MUTATION  Negative"),
                            Row(v="Mutation Negative"), Row(v="8"), Row(v=None)])
    got = {r["v"]: (r["g"], r["n"]) for r in
           df.selectExpr("v", f"{_stage_case(groups, 'v', 'label')} AS g",
                         f"{_stage_case(groups, 'v', 'code')} AS n").collect()}

    assert got["3 + 4 = 7"] == ("Gleason7", 7), "spaced form not matched — backslash escaping"
    assert got["4+3=7"] == ("Gleason7", 7), "unspaced form not matched"
    assert got["MUTATION  Negative"] == ("MutNeg", 2), "(?i) inline flag did not take"
    assert got["Mutation Negative"] == ("MutNeg", 2)
    assert got["8"] == ("CHECK", 99), "an unmatched value must reach the fallthrough"
    assert got[None] == ("Unknown", 5), "a null must be claimed by `when: missing`, not by a regex"

    # CASE-SENSITIVE without the flag — asserted, because "it happens to be insensitive" is exactly
    # the assumption that makes an author write a pattern that works until the feed changes case.
    sens = [{"label": "Upper", "code": 1, "from_regex": ["^IV"]},
            {"when": "fallthrough", "label": "CHECK", "code": 99}]
    out = {r["v"]: r["g"] for r in
           s.createDataFrame([Row(v="IVB"), Row(v="ivb")])
            .selectExpr("v", f"{_stage_case(sens, 'v', 'label')} AS g").collect()}
    assert out == {"IVB": "Upper", "ivb": "CHECK"}, out


def test_a_malformed_regex_is_refused_at_config_lint():
    """A bad pattern must fail where the author is, not mid-build on a cluster.

    And a BLANK one must fail too, for a different reason: `''` is a perfectly valid regex that
    matches every value, so an empty YAML cell hands the whole column to one group. Valid syntax,
    catastrophic semantics — the widest fail-open in the operator.
    """
    from engine.stages.clinical import value_matcher_errors
    ok = [{"label": "A", "code": 1, "from_regex": [r"^\d+$"]},
          {"when": "fallthrough", "label": "C", "code": 99}]
    assert value_matcher_errors(ok) == [], value_matcher_errors(ok)

    bad = [{"label": "A", "code": 1, "from_regex": ["^(unclosed"]}]
    assert any("not a valid regular expression" in e for e in value_matcher_errors(bad)), \
        "a malformed pattern reached the cluster"
    blank = [{"label": "A", "code": 1, "from_regex": ["   "]}]
    assert any("matches EVERY value" in e for e in value_matcher_errors(blank)), \
        "a blank pattern silently claims the whole column"
    # The refusal names WHICH pattern, so a long group is diagnosable.
    two = [{"label": "A", "code": 1, "from_regex": [r"^\d+$", "*nope"]}]
    assert any("from_regex[1]" in e for e in value_matcher_errors(two)), value_matcher_errors(two)


def test_an_unknown_selection_method_is_refused_not_defaulted():
    """A silently-defaulted selector is a variable derived by a rule nobody chose.

    `selection_errors` is the registry's refusal and `validate.check` is what calls it, so a typo in
    `pick:` fails the config lint rather than quietly selecting the nearest record.
    """
    from engine.stages.clinical import DEFAULT_SELECTION, RECORD_PICK, selection_errors
    assert selection_errors({"pick": "nearest"}) == []
    assert any("not a registered selection method" in e
               for e in selection_errors({"pick": "closest"})), "a typo was accepted"
    assert any("at least two" in e for e in
               selection_errors({"date_basis": {"method": "later_of", "columns": ["only_one"]}}))
    # Every default is itself a registered name — a default outside its own registry is a rule the
    # config cannot state and `blocks.py` never prints.
    assert DEFAULT_SELECTION["pick"] in RECORD_PICK

    # THE VOCABULARY MAY NOT BE WIDER THAN EXECUTION. The record date is computed once per block
    # (`_record_date_expr` reads the block and nothing else), so an item-level `date_basis` was
    # accepted by the validator and then ignored at run time — a selector that validates and does
    # not select. Refused, and the block-level form still passes so the refusal is about placement.
    from engine.stages.clinical import BLOCK_ONLY, _record_date_expr
    import inspect
    basis = {"method": "later_of", "columns": ["resultdate", "specimencollecteddate"]}
    assert selection_errors({"date_basis": basis}) == []
    assert any("BLOCK-level choice" in e for e in selection_errors(None, {"date_basis": basis})), \
        "an item-level date_basis is accepted and then ignored"
    # ...and the reason it is block-only is a property of the compiler, not a convention: assert the
    # signature, so implementing per-item support forces this list to be revisited.
    assert "item" not in inspect.signature(_record_date_expr).parameters, \
        "_record_date_expr takes an item now — date_basis no longer belongs in BLOCK_ONLY"
    assert "date_basis" in BLOCK_ONLY
    # Per-item pick/tie_break ARE honoured, so this is not a blanket ban on item-level selection.
    assert selection_errors(None, {"pick": "earliest", "tie_break": "later"}) == []


def test_source_vocabulary_qc_compares_the_feed_against_the_config_case_insensitively():
    """The executing end of the preflight: the value strings the derivations branch on, read from
    the feed itself. Case differences match (the engine lower-cases both sides); a configured value
    the feed does not spell is named; what the feed holds beyond the config is a COUNT, never a
    value. The lot table also proves a rename overlay is honoured before the column is looked up."""
    from engine import qc as engine_qc

    sp = _spark()
    sp.createDataFrame([("PSA",), ("Testosterone",), ("SomethingElse",)],
                       ["BiomarkerName"]).createOrReplaceTempView("qc_bio")
    sp.createDataFrame([("mCRPC",)], ["line_context"]).createOrReplaceTempView("qc_lot")

    class _QCCfg:
        cohorts = [{"line_setting": "mCRPC"}, {"line_setting": "mHSPC"}]
        source_renames = {"lot": {"line_context": engine_qc.LOT_SETTING_COLUMN}}

        def pack(self, name):
            return {"biomarkers": {"name_column": "biomarkername",
                                   "panel": [{"match_any": ["psa", "BRCA1"]}]},
                    "lab_values": {}}

        def source_fqns(self, name):
            return {"biomarkers": ["qc_bio"], "lot": ["qc_lot"],
                    "mortality": ["qc_no_such_table"]}[name]

    report = engine_qc.run_source_qc(sp, _QCCfg())
    v = report["vocabulary"]
    assert v["biomarker_names"]["missing_expected"] == ["BRCA1"], v["biomarker_names"]
    assert v["biomarker_names"]["found"] == 1
    assert v["biomarker_names"]["unexpected_count"] == 2          # counts, never the values
    assert "Testosterone" not in str(v), "a vendor-observed value leaked into the verdict"
    assert v["line_settings"]["missing_expected"] == ["mHSPC"], \
        "the rename overlay was not honoured before the lookup"
    assert report.get("mortality_qc_error"), "the missing mortality source must be reported, not lost"

    gate = engine_qc.source_qc_gate(report)
    assert not gate["passed"]
    assert any("BRCA1" in f for f in gate["failures"])
    assert any("mHSPC" in f for f in gate["failures"])


def test_ads_derived_landmark_interval_and_skip():
    """The cross-stage family, on a real frame: the landmark's three states land on the right
    patients, a banded interval computes and bands, and an item whose `requires` column is absent
    in this cut is skipped rather than raised — the graceful contract the block documents."""
    if SparkSession is None:
        return
    from types import SimpleNamespace
    from pyspark.sql import functions as F
    from engine.stages import ads_derived as ads_stage

    ads = _spark().createDataFrame([
        # p1: death 100 days after index -> FAILED. p2: no event, follow-up past the horizon ->
        # ACHIEVED. p3: no event, follow-up ends short -> NOT EVALUABLE.
        ("p1", date(2020, 1, 1), date(2020, 4, 10), date(2020, 4, 10), date(2019, 6, 1)),
        ("p2", date(2020, 1, 1), None, date(2021, 3, 1), date(2019, 1, 1)),
        ("p3", date(2020, 1, 1), None, date(2020, 6, 1), date(2019, 9, 1)),
    ], ["patientid", "index_date", "dthdt", "fued", "metdate"])

    items = [
        {"name": "efs12", "requires": ["index_date", "dthdt", "fued"],
         "landmark": {"anchor": "index_date", "horizon_days": 365,
                      "events": [{"date": "dthdt"}], "censor": {"date": "fued"},
                      "labels": {"achieved": {"label": "Achieved", "code": 1},
                                 "failed": {"label": "Failed", "code": 2},
                                 "not_evaluable": {"label": "Not evaluable", "code": 3}}}},
        {"name": "premet", "requires": ["metdate", "index_date"],
         "interval": {"from": "metdate", "to": "index_date", "unit": "days"},
         "bands": [{"label": "<1y", "code": 1, "max": 365},
                   {"label": "1y+", "code": 2, "min": 366},
                   {"when": "fallthrough", "label": "Missing", "code": 9}]},
        {"name": "ghost", "requires": ["no_such_column"], "expr": "1"},
    ]
    cfg = SimpleNamespace(pack=lambda role: {"ads_derived": items, "days_per_month": 30.4375},
                          study={"index_start": "2020-01-01", "index_end": "2022-12-31"})
    out = ads_stage.build(F, ads, cfg)
    rows = {r["patientid"]: r for r in out.collect()}
    assert rows["p1"]["efs12"] == "Failed" and rows["p1"]["efs12n"] == 2
    assert rows["p2"]["efs12"] == "Achieved" and rows["p2"]["efs12n"] == 1
    assert rows["p3"]["efs12"] == "Not evaluable" and rows["p3"]["efs12n"] == 3
    assert rows["p1"]["premet"] == 214 and rows["p1"]["premetgr"] == "<1y"
    assert rows["p2"]["premet"] == 365 and rows["p2"]["premetgr"] == "<1y"
    assert rows["p3"]["premetgr"] == "<1y"
    assert "ghost" not in out.columns, "an item with an absent required column must be skipped"


if __name__ == "__main__":
    if SparkSession is None:
        print("SKIP: pyspark not installed — run on a Spark runtime.")
        sys.exit(0)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    _spark().stop()
    print(f"\n{len(fns)} tests passed")
