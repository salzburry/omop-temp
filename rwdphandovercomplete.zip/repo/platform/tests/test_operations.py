"""Tests for the operational layer cores (pure Python, no Spark): refresh manifests, the QC gate,
and the TFL plan + catalog cross-check. Run: python3 test_operations.py (or pytest).
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))
sys.path.insert(0, str(FRAMEWORK / "tools"))
PRODUCTS = FRAMEWORK.parent / "products"

from engine.config import load_yaml, load_config   # noqa: E402
from engine.config import product_config  # noqa: E402
from engine import refresh, qc, tfl                 # noqa: E402

PROSTATE = product_config(PRODUCTS, "prostate")
CATALOG = PRODUCTS / "metadata" / "catalog.yaml"
TFL = PRODUCTS / "_reporting" / "tfl" / "tfl_specs.yaml"
GOOD = {"run.refresh": "2026q1", "run.source_schema": "rwd", "run.output_schema": "out"}


# ---- refresh manifests -------------------------------------------------
def test_build_manifest_valid():
    cfg = load_config(PROSTATE, overrides=GOOD)
    m = refresh.build_manifest(cfg, tumor="mcrpc", git_commit="abc123",
                               counts={"total_rows": 100, "cohorts": {"Overall mCRPC": 100}},
                               qc={"passed": True, "failures": []})
    assert refresh.validate_manifest(m) == []
    # spec_version is the CalVer contract alone (202606), NOT the snapshot-filled 202606.2026q1 — the
    # data cut lives in `refresh`, so the manifest's two version axes don't duplicate.
    assert m["spec_version"] == "202606" and m["refresh"] == "2026q1" and m["status"] == "qc_passed"
    assert m["output_table"] == "out.rwdp_pros_pano_202606"
    # build-level provenance: engine version + product id in the manifest (keyed by spec_version+refresh)
    import re as _re
    assert _re.match(r"^\d+\.\d+\.\d+$", m["engine_version"]) and m["data_product_id"] == "prostate_mcrpc_rwdp"


def test_manifest_published_at_marks_publish():
    # The PRE-publish ledger has published_at=None (QC passed but NOT published); the runner sets it
    # only AFTER a successful swap. A null published_at must never look like a successful publish.
    cfg = load_config(PROSTATE, overrides=GOOD)
    pre = refresh.build_manifest(cfg, tumor="mcrpc", counts={"total_rows": 1}, qc={"passed": True})
    assert pre["status"] == "qc_passed" and pre["published_at"] is None
    post = refresh.build_manifest(cfg, tumor="mcrpc", counts={"total_rows": 1}, qc={"passed": True},
                                  published_at="2026-06-03T16:00:00+00:00")
    post["release"] = {"public": "out.x", "version": "2026q1", "build_id": "abc123",
                       "ads": "out.x__2026q1__abc123", "views": {"out.x": "out.x__2026q1__abc123"}}
    assert post["published_at"] == "2026-06-03T16:00:00+00:00"
    assert refresh.validate_manifest(pre) == [] and refresh.validate_manifest(post) == []
    # a published manifest WITHOUT a release pointer is invalid
    no_rel = {**post}; no_rel.pop("release")
    assert any("release pointer" in p for p in refresh.validate_manifest(no_rel))
    # a release pointer MISSING build_id (or whose views[public] != ads) is invalid
    bad_bid = {**post, "release": {k: v for k, v in post["release"].items() if k != "build_id"}}
    assert any("build_id" in p for p in refresh.validate_manifest(bad_bid))
    bad_anchor = {**post, "release": {**post["release"], "views": {"out.x": "out.x__2026q1__WRONG"}}}
    assert any("views[public]" in p for p in refresh.validate_manifest(bad_anchor))


def test_manifest_missing_fields_flagged():
    assert any("missing" in p for p in refresh.validate_manifest({"tumor": "x"}))


def test_write_manifest_roundtrip():
    import tempfile
    cfg = load_config(PROSTATE, overrides=GOOD)
    m = refresh.build_manifest(cfg, tumor="mcrpc", counts={"total_rows": 5}, qc={"passed": True})
    path = refresh.write_manifest(m, tempfile.mkdtemp())
    # SPEC-VERSIONED ledger path: refreshes/<family>/<product>/<spec_version>/<refresh>.yaml — so 202603
    # and 202606 manifests for the same refresh never collide.
    assert path.replace("\\", "/").endswith("refreshes/oncology/mcrpc/202606/2026q1.yaml")
    back = load_yaml(path)
    assert back["tumor"] == "mcrpc" and back["family"] == "oncology" and back["spec_version"] == "202606"


def test_spec_versioned_ledger_paths():
    # The refreshes/ manifest and releases/ evidence dirs are spec-versioned + family-scoped, so two
    # contracts of the same product (202603 vs 202606) never collide for the same refresh.
    cfg = load_config(PROSTATE, overrides=GOOD)
    m = refresh.build_manifest(cfg, tumor="mcrpc", counts={"total_rows": 1}, qc={"passed": True})
    assert refresh.manifest_path(m, "/r").as_posix() == "/r/refreshes/oncology/mcrpc/202606/2026q1.yaml"
    assert refresh.release_dir("/r", m, "abc_run1").as_posix() == "/r/releases/oncology/mcrpc/202606/2026q1/abc_run1"


def test_write_manifest_refuses_invalid():
    try:
        refresh.write_manifest({"tumor": "x"}, "/tmp")
    except ValueError:
        return
    raise AssertionError("expected write_manifest to refuse an invalid manifest")


def test_released_requires_signoff():
    cfg = load_config(PROSTATE, overrides=GOOD)
    m = refresh.build_manifest(cfg, tumor="mcrpc", counts={"total_rows": 1},
                               qc={"passed": True})
    m["status"] = "released"
    assert any("released" in p for p in refresh.validate_manifest(m))


def test_released_requires_git_commit():
    cfg = load_config(PROSTATE, overrides=GOOD)
    m = refresh.build_manifest(cfg, tumor="mcrpc", git_commit=None, counts={"total_rows": 1},
                               qc={"passed": True})
    m["status"] = "released"
    # ALL FOUR sign-off fields — released without a QC reviewer is exactly what the receipt used
    # to allow (qc_by/qc_date silently dropped during promotion); isolate the git_commit check
    m["sign_off"].update({"released_by": "qa", "released_date": "2026-06-03",
                          "qc_by": "qc reviewer", "qc_date": "2026-06-02"})
    assert any("git_commit" in p for p in refresh.validate_manifest(m))
    m["git_commit"] = "abc123"
    # a released manifest must ALSO carry published_at + a release pointer + a passed tfl_promotion
    # (it was published, with the public views swapped, at run time)
    m["published_at"] = "2026-06-03T16:00:00+00:00"
    m["release"] = {"public": "out.x", "version": "2026q1", "build_id": "abc123",
                    "ads": "out.x__2026q1__abc123", "views": {"out.x": "out.x__2026q1__abc123"}}
    m["tfl_promotion"] = {"passed": True, "promoted": []}
    # ...and Gate 5's own evidence, re-derived rather than read off the status word — in the
    # RUNNER'S structures: physically pinned inputs, a pinned passing golden, the source-QC gate,
    # the deliverable outcomes, the build mode, and the staged-table identity the approval signed.
    m["source_lineage"] = {"rwd": [{"fqn": "rwd.t", "table_id": "T", "delta_version": 0,
                                    "location": "s3://t"}]}
    m["candidate_identity"] = {"out.x__staging__abc123": {"table_id": "A", "delta_version": 0,
                                                          "row_count": 1}}
    m["golden"] = {"reference": "cat.ref", "identity": {"table_id": "R", "location": "s3://r"},
                   "summary": {}, "gate": {"passed": True, "failures": []}}
    m["source_qc_gate"] = {"passed": True}
    m["deliverables"] = {"dictionary": {"status": "ok"}, "tfls": {"status": "ok"}}
    m["run_mode"] = {"env": "prod", "release_grade": True}
    # ...and the OUTPUT contract, the mirror of source_qc_gate above: a receipt that never asked
    # whether its product was uniquely keyed and carried every configured cohort stands on an
    # unexamined product exactly as one with no source verdict stands on unexamined inputs.
    m["output_contract"] = {"passed": True, "failures": [], "unconfigured": []}
    assert refresh.validate_manifest(m) == []


def _candidate(**over):
    base = {"source_qc_gate": {"passed": True}, "qc": {"passed": True},
            "output_contract": {"passed": True, "failures": [], "unconfigured": []},
            "golden": {"reference": "cat.ref", "gate": {"passed": True, "failures": []}},
            "differential": {"passed": True, "failures": [], "unapproved": []}}
    base.update(over)
    return base


def test_the_candidate_verdict_covers_every_gate_the_run_computes():
    """AN EXTERNAL REVIEW FOUND THE DEFECT THIS CLOSES. The runner computed the output-contract and
    differential gates, printed them, wrote them into the manifest — and failed the job on `qc` and
    `golden` alone. Two gates built the same week, neither wired to the thing that stops the run.

    The fix is one LIST, not another `if`: a sixth gate added tomorrow lands in every consumer at
    once, which is precisely what did not happen to these two.
    """
    assert [k for k, _, _ in refresh.CANDIDATE_VERDICTS] == \
        ["source_qc_gate", "qc", "output_contract", "golden", "differential"]
    v = refresh.candidate_verdict(_candidate())
    assert v["passed"] is True, v
    assert len(v["evaluated"]) == 5, v

    # each one, failed in isolation, must fail the whole verdict
    for key in ("source_qc_gate", "qc", "output_contract", "differential"):
        bad = refresh.candidate_verdict(_candidate(**{key: {"passed": False, "failures": ["x"]}}))
        assert bad["passed"] is False, key
    g = refresh.candidate_verdict(_candidate(golden={"gate": {"passed": False, "failures": ["d"]}}))
    assert g["passed"] is False, "golden nests its decision under .gate and was read at top level"


def test_a_missing_verdict_is_not_a_pass_but_an_absent_reference_is_not_a_failure():
    """Two different absences. No output-contract verdict means nobody asked whether the product
    had the right shape. No differential means there was no reference ADS to compare against —
    an evaluated answer, which `golden_gate` already returns as `{passed: True, skipped: ...}`."""
    m = _candidate()
    del m["output_contract"]
    v = refresh.candidate_verdict(m)
    assert v["passed"] is False and "NO verdict" in v["failures"][0]

    m2 = _candidate()
    del m2["differential"]
    del m2["golden"]
    v2 = refresh.candidate_verdict(m2)
    assert v2["passed"] is True, v2
    assert set(v2["not_evaluated"]) == {"aggregate golden", "patient differential"}, v2


def test_an_unapproved_differential_change_fails_even_if_something_wrote_passed_true():
    """The differential's whole point is that a change nobody accepted stops the run. A writer that
    set `passed: True` beside a non-empty `unapproved` list must not get through."""
    v = refresh.candidate_verdict(_candidate(
        differential={"passed": True, "failures": [], "unapproved": ["ecog: 40 patients differ"]}))
    assert v["passed"] is False, v
    assert "unapproved change" in " ".join(v["failures"])


def test_released_requires_an_output_contract_verdict():
    """AN EXTERNAL REVIEW FOUND THE GAP THIS CLOSES: the QC gate scored four rates and could pass a
    duplicated, incomplete or nearly empty product. A MISSING verdict must fail exactly as a failed
    one does — otherwise the way to release without the check is to not run it."""
    cfg = load_config(PROSTATE, overrides=GOOD)
    m = refresh.build_manifest(cfg, tumor="mcrpc", git_commit="abc123", counts={"total_rows": 1},
                               qc={"passed": True})
    m.update({"status": "released", "published_at": "2026-06-03T16:00:00+00:00",
              "release": {"public": "out.x", "version": "2026q1", "build_id": "abc123",
                          "ads": "out.x__2026q1__abc123",
                          "views": {"out.x": "out.x__2026q1__abc123"}},
              "tfl_promotion": {"passed": True, "promoted": []},
              "source_lineage": {"rwd": [{"fqn": "rwd.t", "table_id": "T", "delta_version": 0,
                                          "location": "s3://t"}]},
              "candidate_identity": {"out.x__staging__abc123": {"table_id": "A"}},
              "golden": {"reference": "cat.ref", "identity": {"table_id": "R", "location": "s3://r"},
                         "summary": {}, "gate": {"passed": True, "failures": []}},
              "source_qc_gate": {"passed": True},
              "deliverables": {"dictionary": {"status": "ok"}, "tfls": {"status": "ok"}},
              "run_mode": {"env": "prod", "release_grade": True}})
    m["sign_off"].update({"released_by": "qa", "released_date": "2026-06-03",
                          "qc_by": "qc reviewer", "qc_date": "2026-06-02"})

    # ABSENT — build_manifest defaults it to {}, so `.get("passed")` is None, not True.
    assert any("output_contract.passed" in p for p in refresh.validate_manifest(m)), \
        "a released receipt with NO output-contract verdict validated"
    # FAILED — the same refusal, so a run cannot publish by ignoring its own red gate.
    m["output_contract"] = {"passed": False, "failures": ["2 output key(s) carry more than one row"]}
    assert any("output_contract.passed" in p for p in refresh.validate_manifest(m))
    # PASSED — and nothing else is left objecting, or this test would pass for the wrong reason.
    m["output_contract"] = {"passed": True, "failures": [], "unconfigured": []}
    assert refresh.validate_manifest(m) == [], refresh.validate_manifest(m)


def test_released_rederives_gate5_from_the_receipts_own_evidence():
    """A manifest saying `released` with its own qc block saying `passed: false` used to validate;
    then a receipt carrying the RUNNER'S real failed structure (`golden.gate.passed: false`, not a
    top-level `golden.passed` the runner never writes) validated too — an external review's
    adversarial receipt. Every check below names the field the runner actually writes, and for a
    released receipt ABSENT evidence and FAILED evidence are the same answer."""
    cfg = load_config(PROSTATE, overrides=GOOD)
    m = refresh.build_manifest(cfg, tumor="mcrpc", git_commit="abc123", counts={"total_rows": 1},
                               qc={"passed": True},
                               source_lineage={"rwd": [{"fqn": "rwd.t", "table_id": "T",
                                                        "delta_version": 0,
                                                        "location": "s3://t"}]},
                               golden={"reference": "cat.ref",
                                       "identity": {"table_id": "R", "location": "s3://r"},
                                       "summary": {}, "gate": {"passed": True, "failures": []}},
                               source_qc_gate={"passed": True},
                               output_contract={"passed": True, "failures": [], "unconfigured": []},
                               deliverables={"dictionary": {"status": "ok"},
                                             "tfls": {"status": "ok"}},
                               run_mode={"env": "prod", "release_grade": True})
    m["status"] = "released"
    m["sign_off"].update({"released_by": "qa", "released_date": "2026-06-03",
                          "qc_by": "qc reviewer", "qc_date": "2026-06-02"})
    m["published_at"] = "2026-06-03T16:00:00+00:00"
    m["release"] = {"public": "out.x", "version": "2026q1", "build_id": "abc123",
                    "ads": "out.x__2026q1__abc123", "views": {"out.x": "out.x__2026q1__abc123"}}
    m["tfl_promotion"] = {"passed": True, "promoted": []}
    m["candidate_identity"] = {"out.x__staging__abc123": {"table_id": "A", "delta_version": 0,
                                                          "row_count": 1}}
    assert refresh.validate_manifest(m) == []
    # each contradiction, isolated — the receipt's own block disagrees with its status word
    assert any("qc.passed" in p for p in
               refresh.validate_manifest({**m, "qc": {"passed": False, "failures": ["x"]}}))
    assert any("qc.passed" in p for p in refresh.validate_manifest({**m, "qc": {}}))
    # the adversarial receipt: the runner's REAL failed golden structure
    assert any("golden.gate.passed" in p for p in refresh.validate_manifest(
        {**m, "golden": {"reference": "cat.ref", "identity": {"table_id": "R",
                                                              "location": "s3://r"},
                         "gate": {"passed": False, "failures": ["y"]}}}))
    # no comparison at all is a REFUSAL for a released receipt, not a shrug
    assert any("golden comparison" in p for p in
               refresh.validate_manifest({**m, "golden": {"reference": "none"}}))
    assert any("golden comparison" in p for p in refresh.validate_manifest({**m, "golden": {}}))
    # an unpinned reference: the comparison could have been against anything
    assert any("golden.identity" in p for p in refresh.validate_manifest(
        {**m, "golden": {"reference": "cat.ref", "gate": {"passed": True}}}))
    assert any("source_qc_gate.passed" in p for p in
               refresh.validate_manifest({**m, "source_qc_gate": {"passed": False}}))
    assert any("source_qc_gate.passed" in p for p in
               refresh.validate_manifest({**m, "source_qc_gate": {}}))
    assert any("source_lineage" in p for p in
               refresh.validate_manifest({**m, "source_lineage": {}}))
    assert any("no storage location" in p for p in refresh.validate_manifest(
        {**m, "source_lineage": {"rwd": [{"fqn": "rwd.t", "table_id": "T",
                                          "delta_version": 0}]}}))
    assert any("candidate_identity" in p for p in
               refresh.validate_manifest({**m, "candidate_identity": {}}))
    # deliverables: skipped and failed both shipped without something; absent never accounted
    assert any("deliverables.tfls" in p for p in
               refresh.validate_manifest({**m, "deliverables": {"tfls": {"status": "failed"}}}))
    assert any("deliverables.tfls" in p for p in
               refresh.validate_manifest({**m, "deliverables": {"tfls": {"status": "skipped"}}}))
    assert any("deliverables block" in p for p in
               refresh.validate_manifest({**m, "deliverables": {}}))
    # `empty` stays legal — a product that configures no TFLs records that honestly
    assert refresh.validate_manifest(
        {**m, "deliverables": {"dictionary": {"status": "ok"},
                               "tfls": {"status": "empty"}}}) == []
    # the receipt must say which MODE built it
    assert any("run_mode.env" in p for p in refresh.validate_manifest({**m, "run_mode": {}}))


def test_released_requires_published_and_release():
    # 'released' is set only after a successful publish -> published_at + a release pointer are required,
    # not just QC + sign-off (a manifest can't be marked released while still showing published_at=null).
    cfg = load_config(PROSTATE, overrides=GOOD)
    m = refresh.build_manifest(cfg, tumor="mcrpc", git_commit="abc123", counts={"total_rows": 1},
                               qc={"passed": True})
    m["status"] = "released"; m["sign_off"]["released_by"] = "qa"
    probs = refresh.validate_manifest(m)   # has git_commit + sign-off but NOT published_at/release/promotion
    assert any("published_at" in p for p in probs) and any("release pointer" in p for p in probs)
    assert any("tfl_promotion" in p for p in probs)


def test_manifest_validates_source_union_and_tfl_promotion():
    cfg = load_config(PROSTATE, overrides=GOOD)
    base = refresh.build_manifest(cfg, tumor="mcrpc", git_commit="abc", counts={"total_rows": 1},
                                  qc={"passed": True})
    assert refresh.validate_manifest(base) == []                          # prostate: source_union None
    assert any("source_union" in p for p in
               refresh.validate_manifest({**base, "source_union": {"discriminator": "db"}}))  # no members
    assert any("tfl_promotion" in p for p in
               refresh.validate_manifest({**base, "tfl_promotion": {"promoted": []}}))         # no 'passed'
    assert refresh.validate_manifest(
        {**base, "source_union": {"members": [{"schema": "s", "flag": "EDM"}]},
         "tfl_promotion": {"passed": True, "promoted": ["t1"]}}) == []


# ---- QC gate -----------------------------------------------------------
def test_qc_gate_passes_clean_report():
    rep = {"n_rows": 100, "catchall_rate": {"lot1cat": 0.1}, "stage_check_rate": 0.0}
    assert qc.qc_gate(rep)["passed"]


def test_qc_gate_fails_on_smells():
    rep = {"n_rows": 0, "catchall_rate": {"lot1cat": 0.9}, "stage_check_rate": 0.5,
           "uncastable_date_rate": {"dthdt": 0.2}}
    g = qc.qc_gate(rep)
    assert not g["passed"] and len(g["failures"]) >= 3


def test_qc_gate_stage_message_uses_derived_label_not_hardcoded_check():
    # The stage-smell message must name the ACTUAL staging fallthrough label from the report, not a
    # hardcoded 'CHECK' (a tumor whose fallthrough label differs would otherwise get a wrong message).
    rep = {"n_rows": 100, "stage_check_rate": 0.5, "stage_check_label": "UNMAPPED"}
    g = qc.qc_gate(rep)
    assert not g["passed"]
    assert any("UNMAPPED" in f and "CHECK" not in f for f in g["failures"])


def test_source_qc_gate():
    assert qc.source_qc_gate({"patients_with_conflicting_death_dates": 5})["passed"]   # no threshold
    assert not qc.source_qc_gate({"mortality_qc_error": "boom"})["passed"]            # read error
    g = qc.source_qc_gate({"patients_with_conflicting_death_dates": 5}, {"max_death_conflicts": 0})
    assert not g["passed"] and "conflicting" in g["failures"][0]


def test_source_vocabulary_gate_fails_closed_on_a_value_the_feed_does_not_spell():
    """A configured value the feed spells differently does not error a build — it silently matches
    nothing and the column comes back Unknown. The gate turns that silence into a refusal, at the
    point where the fix is one config edit. Unreadable expectations fail outright; the threshold is
    config-overridable but defaults to zero."""
    rep = {"vocabulary": {"biomarker_names": {
        "declared_in": "variables/clinical.yaml#/biomarkers panel[].match_any",
        "expected": 3, "found": 2, "missing_expected": ["cdk4"], "unexpected_count": 40}}}
    g = qc.source_qc_gate(rep)
    assert not g["passed"] and any("cdk4" in f and "clinical.yaml" in f for f in g["failures"])
    assert qc.source_qc_gate(rep, {"max_missing_expected": 1})["passed"]
    ok = {"vocabulary": {"biomarker_names": {"expected": 3, "found": 3,
                                             "missing_expected": [], "unexpected_count": 40}}}
    assert qc.source_qc_gate(ok)["passed"], "unexpected feed values are a count, never a failure"
    broken = {"vocabulary": {"lab_names": {"error": "lab carries no column 'testname'"}}}
    g = qc.source_qc_gate(broken)
    assert not g["passed"] and "not checkable" in g["failures"][0]


def test_source_expectations_read_the_config_the_build_will_run():
    """The one derivation both the paste-ready SQL and the on-cluster gate read. Against the live
    prostate config: the three topics exist, every entry names a source, a column and where it was
    declared, and the values are the config's own strings."""
    cfg = load_config(PROSTATE, overrides=GOOD)
    exp = qc.source_expectations(cfg)
    assert set(exp) == {"biomarker_names", "lab_names", "line_settings"}, sorted(exp)
    for topic, e in exp.items():
        assert e["source"] and e["column"] and e["expected"] and e["declared_in"], (topic, e)
    assert e is not None and exp["line_settings"]["column"] == qc.LOT_SETTING_COLUMN
    # ...and the offline SQL generator renders THIS derivation, not its own reading
    import source_preflight
    off = source_preflight.expectations(cfg)
    assert off["biomarker names"][0] == exp["biomarker_names"]["expected"]
    assert off["line settings"][0] == exp["line_settings"]["expected"]


def test_source_qc_evidence_is_verdicts_and_config_strings_only():
    """The machine-readable end of the loop that used to run through a person reading DISTINCT
    results out of a SQL editor. Its identity fields make the artifact attributable; its result is
    pass/fail; nothing vendor-observed appears except as a count."""
    import json as _json
    cfg = load_config(PROSTATE, overrides=GOOD)
    rep = {"vocabulary": {"biomarker_names": {"expected": 2, "found": 1,
                                              "missing_expected": ["cdk4"],
                                              "unexpected_count": 17}}}
    ev = qc.source_qc_evidence(cfg, rep, {"passed": False, "failures": ["x"]},
                               generated_at="2026-08-10T00:00:00Z", git_commit="abc")
    assert ev["kind"] == "source_qc" and ev["result"] == "failed_live"
    assert ev["data_product_id"] and ev["data_refresh"] and ev["source_schema"]
    flat = _json.dumps(ev)
    assert "cdk4" in flat and "17" in flat, "the config strings and counts are the content"

    # ...and source_check folds exactly that artifact into a committed report's front matter
    import tempfile
    import source_check
    with tempfile.TemporaryDirectory() as tmp:
        import os
        path = os.path.join(tmp, "source_qc.json")
        with open(path, "w", encoding="utf-8") as fh:
            _json.dump(ev, fh)
        fields = source_check._preflight_fields(path)
        assert fields["preflight_result"] == "failed_live"
        assert fields["preflight_missing_expected"] == 1
        assert fields["preflight_product_id"] == ev["data_product_id"]
        # a wrong artifact is refused, never quietly folded
        wrong = os.path.join(tmp, "other.json")
        with open(wrong, "w", encoding="utf-8") as fh:
            _json.dump({"kind": "schema_preflight"}, fh)
        try:
            source_check._preflight_fields(wrong)
            raise AssertionError("a schema-validation artifact was folded in as source QC")
        except SystemExit:
            pass
        # absence is explicit `none`, never omission
        empty = source_check._preflight_fields(None)
        assert set(empty) and all(v == "none" for v in empty.values())


def test_the_manifest_pins_the_data_the_build_read_not_just_the_code():
    """Git pins the code; source_lineage pins the rows: per input table, Delta's own table_id and
    the version read, so `VERSION AS OF` can re-read the exact bytes. The shape is validated —
    a half-entry with neither a probed identity nor an error is a lineage that can re-read
    nothing, riding the ledger looking like one that can."""
    from engine import release as rel
    cfg = load_config(PROSTATE, overrides=GOOD)
    row = rel.input_lineage_row(
        "cat.sch.t_lot", {"version": 41, "timestamp": "2026-08-01 10:00:00"},
        {"id": "abc-123", "format": "delta", "location": "s3://bucket/t_lot"})
    assert row == {"fqn": "cat.sch.t_lot", "table_id": "abc-123", "table_format": "delta",
                   "location": "s3://bucket/t_lot",
                   "delta_version": 41, "last_commit_at": "2026-08-01 10:00:00"}
    m = refresh.build_manifest(cfg, tumor="mcrpc", counts={"total_rows": 1}, qc={"passed": True},
                               source_lineage={"lot": [row]})
    assert refresh.validate_manifest(m) == []
    assert m["source_lineage"]["lot"][0]["delta_version"] == 41
    # an error entry is legal — an input with no recordable lineage is NAMED, never omitted
    m2 = refresh.build_manifest(cfg, tumor="mcrpc", counts={"total_rows": 1}, qc={"passed": True},
                                source_lineage={"lot": [{"fqn": "cat.sch.t_lot",
                                                         "error": "not a Delta table"}]})
    assert refresh.validate_manifest(m2) == []
    # ...but a half-entry is refused: no identity AND no error pins nothing
    m3 = refresh.build_manifest(cfg, tumor="mcrpc", counts={"total_rows": 1}, qc={"passed": True},
                                source_lineage={"lot": [{"fqn": "cat.sch.t_lot"}]})
    bad = refresh.validate_manifest(m3)
    assert any("pins nothing" in b for b in bad), bad
    m4 = refresh.build_manifest(cfg, tumor="mcrpc", counts={"total_rows": 1}, qc={"passed": True},
                                source_lineage={"lot": []})
    assert any("non-empty" in b for b in refresh.validate_manifest(m4))


def test_manifest_carries_artifacts():
    cfg = load_config(PROSTATE, overrides=GOOD)
    m = refresh.build_manifest(cfg, tumor="mcrpc", counts={"total_rows": 1}, qc={"passed": True},
                               artifacts={"qc_report": "/x/qc.md", "dictionary": "/x/dict.md"})
    assert refresh.validate_manifest(m) == []
    assert m["artifacts"]["qc_report"] == "/x/qc.md"


def test_manifest_carries_source_qc_and_deliverables():
    cfg = load_config(PROSTATE, overrides=GOOD)
    m = refresh.build_manifest(
        cfg, tumor="mcrpc", counts={"total_rows": 1}, qc={"passed": True},
        source_qc={"mortality_granularity": {"10": 90, "7": 10},
                   "patients_with_conflicting_death_dates": 3},
        source_qc_gate={"passed": True, "failures": []},
        deliverables={"dictionary": {"status": "ok", "audiences": ["internal"]},
                      "tfls": {"status": "empty", "tfls": []}})
    assert refresh.validate_manifest(m) == []
    # full source-QC REPORT preserved in the ledger, not just the gate
    assert m["source_qc"]["mortality_granularity"]["7"] == 10
    assert m["source_qc"]["patients_with_conflicting_death_dates"] == 3
    assert m["source_qc_gate"]["passed"] is True
    assert m["deliverables"]["dictionary"]["status"] == "ok"


def test_qc_thresholds_merge_config():
    cfg = load_config(PROSTATE, overrides=GOOD)
    assert qc.qc_thresholds(cfg)["min_rows"] == 1   # framework default present


# ---- TFL ---------------------------------------------------------------
def test_tfl_variables_resolve_to_catalog():
    catalog = {v["code"] for v in load_yaml(CATALOG)["variables"]}
    for t in tfl.load_specs(TFL)["tfls"]:
        for v in tfl.tfl_variables(t):
            assert v in catalog, f"TFL {t['id']} references unknown variable '{v}'"


def test_tfl_platinum_table_not_producible_without_plat_sen():
    # The OC-only platinum table (where plat_sen_v1 IS NOT NULL) is not producible on a prostate-like
    # ADS — so generate() skips it instead of erroring on the unresolved `where` column.
    specs = tfl.load_specs(TFL)
    prostate_cols = ["cohort", "lot1cat", "os", "dthfl", "ecog", "bmi", "stage"]
    assert tfl.tfl_plan(specs, prostate_cols)["t4_platinum"]            # missing plat_sen_v1 -> skip
    assert tfl.tfl_plan(specs, prostate_cols + ["plat_sen_v1"])["t4_platinum"] == []   # OC: producible


def test_every_tfl_with_where_declares_where_columns():
    # Keep the standard safe as TFLs expand: a `where` without `where_columns` could reintroduce the
    # unresolved-column failure (generate() can only pre-check columns it's told about).
    for t in tfl.load_specs(TFL)["tfls"]:
        if t.get("where"):
            assert t.get("where_columns"), f"TFL {t['id']} has `where` but no `where_columns`"


def test_tfl_plan_missing_and_lotcat_resolution():
    specs = tfl.load_specs(TFL)
    assert tfl.tfl_plan(specs, ["cohort", "agegrl"])["t1_demographics"]   # still missing some vars
    # catalog 'lotcat' is satisfied by a per-line lot<i>cat column
    assert tfl.tfl_plan(specs, ["cohort", "lot1cat"])["t3_treatment"] == []


def test_tfl_qc_gate_required_vs_optional_split():
    # The TFL QC gate (enforced in the runner) must NOT block a governed publish for a TFL the product
    # legitimately doesn't produce. The tumor-specific TFLs are required: false (warn, not fail); the
    # core ones default required (fail if unproducible). Guards the spec config so a future edit can't
    # silently make a conditional TFL required and block every non-OC / non-PFS product.
    specs = tfl.load_specs(TFL)
    by_id = {t["id"]: t for t in specs["tfls"]}
    for opt in ("t4_platinum", "f2_pfs_km", "f3_pfs2_km"):
        assert by_id[opt].get("required") is False, f"{opt} must be required: false (conditional TFL)"
    for req in ("t1_demographics", "t2_clinical", "t3_treatment", "f1_os_km", "l1_patient"):
        assert by_id[req].get("required", True) is True, f"{req} must be required (core TFL)"
    # a prostate-like ADS (core columns + OS + PFS, but no platinum / PFS2) -> gate PASSES (the missing
    # OC/PFS2 TFLs only WARN); flip a core column out and it FAILS.
    cols = ["cohort", "agegrl", "regionl", "race", "eth", "practic", "ses", "ecog", "bmi", "stage",
            "lot1cat", "os", "dthfl", "pfs", "pfsfl", "lotn"]
    gate = tfl.tfl_qc(specs, tfl.tfl_plan(specs, cols, hard=True))
    assert gate["passed"], [r for r in gate["tfls"] if r["status"] == "failure"]
    assert {r["status"] for r in gate["tfls"] if r["id"] in ("t4_platinum", "f3_pfs2_km")} == {"warning"}
    bad = tfl.tfl_qc(specs, tfl.tfl_plan(specs, [c for c in cols if c != "os"], hard=True))   # drop a required input
    assert not bad["passed"]


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
