"""The walkthrough must not rot, and must not write.

`platform/tools/demo.py` is the handover artifact: the one command a successor runs to watch the
governed lifecycle happen. Nothing in CI runs it end to end — it builds a deployment tree and runs a
pack's suites, which is minutes — so without these checks it would break silently on the first tool
rename and be discovered by the one person we most need it to work for.

Two properties, and they are the only two worth a test here:

  * every command it claims to run RESOLVES — the tool exists and the pack discovery it relies on is
    the shared one, not a private glob;
  * every command it runs is READ-ONLY — a walkthrough that mutated a governed pack would be a
    demonstration that quietly changed the thing being demonstrated.

Run: python3 tests/test_demo.py (or pytest).
"""
import os
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent          # platform/
TOOLS = FRAMEWORK / "tools"
REPO = FRAMEWORK.parent
sys.path.insert(0, str(TOOLS))

import demo            # noqa: E402
import product_gates   # noqa: E402


def _plan(dirty=False):
    """The step list, built against a real discovered pack.

    Discovery, not a literal: a pack path spelled here would be one tumour's name in shared code and
    would go stale the first time a version folder moved.
    """
    packs = sorted(product_gates.products(str(REPO)))
    assert packs, ("discovered no packs — this test would pass vacuously. products() derives its "
                   "root from the CWD; run the suite from platform/ as CI does.")
    return demo.steps(packs[0], "demographics", dirty)


def test_every_tool_the_walkthrough_names_exists():
    """A renamed or deleted tool breaks the demo, and only a successor would find out."""
    named = 0
    for st in _plan():
        if not st.get("argv"):
            continue
        tool = Path(st["argv"][1])
        assert tool.is_file(), f"{st['title']!r} runs {tool}, which does not exist"
        assert tool.parent == TOOLS, f"{st['title']!r} runs {tool}, which is not a platform tool"
        named += 1
    assert named >= 10, f"only {named} direct tool step(s) — the plan lost most of its steps"


def test_the_expanded_steps_name_real_tools_too():
    """The three hand-rolled steps call tools by name inside their helpers, out of reach of the
    check above. Assert the files they reach for are present."""
    for name in ("product_gates.py", "deploy_tree.py"):
        assert (TOOLS / name).is_file(), f"an expanded step needs {name}"
    assert {st.get("expand") for st in _plan() if st.get("expand")} == {"tests", "deploy",
                                                                       "check_tree"}


def test_no_step_can_write():
    """Read-only is the property that lets anyone run this against a governed pack.

    A denylist of the writing flags these tools actually have — the gates are otherwise all
    `--check` and reports. `--out`/`--evidence-out` are permitted ONLY for the deployment tree,
    which the walkthrough builds into a temp directory; every other appearance would be a tool
    writing an artifact somewhere a demo has no business putting one.
    """
    forbidden = {"--write-legacy-allowlist", "--promote", "--register-ai-extraction",
                 "--out", "--evidence-out", "--records", "--coverage"}
    for st in _plan():
        for flag in st.get("argv") or []:
            assert flag not in forbidden, f"{st['title']!r} passes {flag}, which writes"


def test_discovery_is_the_shared_one_not_a_private_glob():
    """The same function OBJECT, per docs/ENGINEERING.md: worth more than two tests asserting agreement.

    Then: no walking of its own. Checked against the parsed SOURCE rather than the text, because the
    text says "never glob products/*/*" in a comment and a substring search cannot tell the rule from
    a breach of it — which is the same positional-versus-named mistake this repo keeps paying for.
    """
    assert demo.product_gates.products is product_gates.products

    import ast
    tree = ast.parse((TOOLS / "demo.py").read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            names = [a.name for a in getattr(node, "names", [])] + [getattr(node, "module", "") or ""]
            assert "glob" not in names, "demo.py imports glob — discovery belongs to products()"
        if isinstance(node, ast.Attribute) and node.attr in ("glob", "rglob", "walk", "iterdir"):
            raise AssertionError(f"demo.py calls .{node.attr}() — it must not enumerate packs itself")


def test_the_walkthrough_opens_no_file():
    """It orchestrates and narrates. The moment it parses a pack artifact it becomes a second
    implementation of whichever tool owns that number, free to print a greener one than CI.

    Stated as "opens nothing", which is the enforceable form. Checked against the parsed SOURCE, not
    the text: demo.py NAMES FUNCTIONAL_CONTRACT.md and source_refs.yaml in the sentences it prints
    to explain what a pack is missing, and a substring search cannot tell prose from a read — the
    same trap as searching for the glob it forbids in a comment.

    Reading through an owner is fine and is the point: source_manifest.materials() opens
    source_refs.yaml, and that is exactly where that knowledge belongs.
    """
    import ast
    tree = ast.parse((TOOLS / "demo.py").read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        fn = node.func
        name = fn.id if isinstance(fn, ast.Name) else (fn.attr if isinstance(fn, ast.Attribute) else "")
        assert name != "open", "demo.py calls open() — pack artifacts are read through their owner"
        assert name not in ("read_text", "read_bytes", "safe_load", "load", "loads"), \
            f"demo.py calls {name}() — it must not parse an artifact itself"


def test_a_gate_step_that_fails_is_reported_as_a_failure():
    """The verdict wording is the whole point of the summary; a SHOWS step must never be scored."""
    assert demo._verdict(demo.GATE, 0) == "PASS"
    assert "FAILS THIS GATE" in demo._verdict(demo.GATE, 1)
    assert demo._verdict(demo.SHOWS, 0) == "shown"
    assert "REFUSED" in demo._verdict(demo.SHOWS, 1)


def test_nothing_to_run_is_never_reported_as_a_pass():
    """The fail-open this walkthrough actually shipped with, briefly.

    A pack with no test suite of its own scored PASS on Gate 5 — an ABSENT suite rendered as passing
    evidence, inside a demonstration whose entire subject is gates that fail closed. It is the exact
    shape docs/ENGINEERING.md names: an absent counter is not a zero.
    """
    assert demo.NO_EVIDENCE != 0, "the sentinel must not collide with a clean exit"
    for kind in (demo.GATE, demo.SHOWS):
        verdict = demo._verdict(kind, demo.NO_EVIDENCE)
        assert "NO EVIDENCE" in verdict and "Not a pass" in verdict
        assert "PASS" not in verdict.replace("Not a pass", ""), \
            f"a step with nothing to run reads as a pass: {verdict!r}"


def test_a_pack_with_no_suite_of_its_own_reports_no_evidence():
    """End to end through the real discovery, on a pack that genuinely ships no tests."""
    with_tests, without = None, None
    for pack in sorted(product_gates.products(str(REPO))):
        code, _ = demo.do_tests(pack, False)
        if code == demo.NO_EVIDENCE:
            without = pack
        elif code == 0:
            with_tests = pack
    assert without, "no pack lacks a suite — this test can no longer prove anything"
    assert with_tests, "no pack HAS a passing suite — the comparison is vacuous"
    assert demo.do_tests(without, False)[0] == demo.NO_EVIDENCE
    assert demo.do_tests(with_tests, False)[0] == 0


def test_a_dirty_checkout_does_not_score_as_the_pack_failing_gate_6():
    """On a modified working copy the packaging steps cannot produce a bindable tree, and blaming
    the pack for that would teach a successor exactly the wrong lesson."""
    packaging = [st for st in _plan(dirty=True) if st.get("expand") in ("deploy", "check_tree")]
    assert len(packaging) == 2
    assert all(st["kind"] is demo.SHOWS for st in packaging), \
        "a dirty checkout must demote the packaging steps, not fail the pack"
    assert all(st["note"] for st in packaging), "and must say why"

    clean = [st for st in _plan(dirty=False) if st.get("expand") in ("deploy", "check_tree")]
    assert all(st["kind"] is demo.GATE for st in clean), \
        "on a clean checkout — the only state a release is packaged from — they are gates again"


def test_a_gate_with_nothing_to_read_does_not_pass_vacuously():
    """The second fail-open, and the one that made a pack look finished.

    prostate/202607 has no config/ at all, so contract_binding reported "covered config: 0/0
    governed block(s)" and exited 0 — a clean sweep, indistinguishable in the summary from 202606,
    which actually has 38 bound blocks. Applicability now comes from the discovery list that owns
    the artifact.
    """
    every = sorted(product_gates.products(str(REPO)))
    with_config = [p for p in every if demo.applicable(p, "configs")]
    assert with_config, "no pack has a config — applicability cannot be exercised at all"

    # THE GUARD, not the repo's current variety. This asserted that some REAL pack lacks a config,
    # which was true only while prostate/202607 sat in the tree as a fixture. Every pack has a config
    # now, so that phrasing would have to be deleted or the fixture kept forever; the property the
    # test is actually about is that `applicable` says NO to a pack the list does not contain.
    absent = "products/oncology/fixtures/no_such_pack"
    assert absent not in every, "the negative fixture collides with a real pack"
    assert not demo.applicable(absent, "configs"), \
        "applicable() says a pack outside --list-configs is config-applicable"

    for st in _plan():
        if st.get("applies") != "configs":
            continue
        assert not demo.applicable(absent, "configs")
        break
    else:
        raise AssertionError("no step keys on --list-configs — the binding gate lost its guard")


def test_applicability_never_suppresses_a_real_failure():
    """Every list a step keys on must mean 'has the artifact', never 'is finished'.

    Keying the binding step on --list-buildable instead of --list-configs would exclude oc, whose
    binding genuinely fails — turning a real defect into NO EVIDENCE. A walkthrough that hides a
    failure is worse than one that passes vacuously, so the stricter list is refused outright.
    """
    for st in _plan():
        assert st.get("applies") != "buildable", (
            f"{st['title']!r} keys on --list-buildable, which means 'complete', not 'has the "
            f"artifact' — a pack with the artifact and a real failure would be scored NO EVIDENCE")
    assert set(demo.APPLIES) >= {st["applies"] for st in _plan() if st.get("applies")}, \
        "a step names an applicability list with no explanation in APPLIES"


def test_every_applicability_list_resolves():
    """A list name product_gates does not offer would make every pack look inapplicable."""
    for which in demo.APPLIES:
        if which == "materials":
            continue
        assert demo.applicable("products/oncology/prostate/202606", which) in (True, False)
        assert demo._LISTS[which], f"--list-{which} came back empty; the flag is probably gone"


def test_every_step_says_what_it_proves():
    """The narration is the deliverable. A step with no `proves` is a command with no lesson."""
    for st in _plan():
        assert st["proves"].strip(), f"{st['title']!r} says nothing about what it proves"
        assert st["kind"] in (demo.GATE, demo.SHOWS), f"{st['title']!r} has an unknown kind"



def test_the_dirty_retry_is_conditioned_on_the_checkout_not_on_the_exit_code():
    """A GENUINE PACKAGING FAILURE MUST NOT BE NARRATED AS SOMEBODY'S LOCAL EDITS.

    `do_deploy` retried with `--allow-dirty` on ANY non-zero exit. On a CLEAN checkout that means a
    real failure — a forbidden file reaching the allowlist, an unreadable config graph — is retried
    under weaker rules and then explained to the audience as "your working copy is modified". A
    walkthrough that misattributes a failure is worse than one that simply fails, and this is the
    walkthrough whose entire subject is gates that refuse honestly.

    `walk` already asks `deploy_tree.git_state` once and threads the answer to `steps`; the retry
    now takes the same answer. Asserted by calling `do_deploy` with a command that always fails.
    """
    import tempfile
    import demo

    calls = []
    real = demo.run
    try:
        demo.run = lambda argv: (calls.append(list(argv)), (1, "boom"))[1]
        with tempfile.TemporaryDirectory() as tmp:
            calls.clear()
            demo.do_deploy("products/oncology/prostate/202606", tmp, False, False)
            assert not any("--allow-dirty" in c for c in calls), (
                "a clean checkout retried with --allow-dirty after an unrelated failure")
            calls.clear()
            demo.do_deploy("products/oncology/prostate/202606", tmp, False, True)
            assert any("--allow-dirty" in c for c in calls), (
                "a dirty checkout did not retry — the demotion story is unreachable")
    finally:
        demo.run = real

def test_a_pack_that_generated_nothing_is_not_a_passing_gate_2():
    """MEASURED ON A REAL PACK, not asserted about the flag. mCRC is on `--list-pipelines` and has
    generated none of the seven artifacts, and the walkthrough printed:

        NONE   Gate 1       the AI boundary, over the whole pack
        PASS   Gate 2       the generated artifacts are current
        NONE   Gate 2       every contract record holds its invariants

    — a PASS about seven files that do not exist, between two honest NONEs. `--check` alone returns 0
    for "never generated" because that is right for a repo-wide sweep, where a pack that has
    generated nothing has claimed nothing. It is wrong here, where the artifacts ARE the subject.

    NO EVIDENCE rather than FAIL, deliberately: such a pack has not failed a gate, it has not yet
    made a claim — which is exactly what its neighbouring gates already say about it.
    """
    step = next((s for s in _plan()
                 if s.get("argv") and s["argv"][1].endswith("run_spec_pipeline.py")), None)
    assert step, "the plan no longer runs the spec pipeline — this test cannot prove anything"
    assert "--require-generated" in step["argv"], \
        "Gate 2 runs --check without --require-generated, so a never-generated pack scores PASS"
    assert step.get("no_evidence_exit") == demo.run_spec_pipeline.NOTHING_GENERATED, \
        "the never-generated exit code is not mapped, so that state renders as a failing gate"

    # ...and the mapping is the shared one, so a code the tool changes cannot drift from the demo's
    # copy of it. Asserted as the same object's value, not a literal repeated here.
    import run_spec_pipeline
    assert demo.run_spec_pipeline is run_spec_pipeline
    assert run_spec_pipeline.NOTHING_GENERATED not in (0, 1, 2), \
        "the never-generated code collides with success, generic failure or argparse's exit"


if __name__ == "__main__":
    os.chdir(FRAMEWORK)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
