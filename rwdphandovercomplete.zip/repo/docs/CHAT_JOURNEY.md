# Running the whole journey from chat

The chat interface is not a future feature — it is how this repository is operated today. Claude
Code **is** the chat surface: open this repo in VS Code with the Claude Code extension (the panel
is the "popup") or run `claude` in a terminal at the repo root, and type the questions below in
plain language. The five skills in `.claude/skills/` cover the recurring governed workflows —
drafting contract records, answering decisions, applying source verdicts, starting the next cut,
and operating a product; a request outside those five goes straight to the tool that owns it,
with `governance/INDEX.yaml` as the routing map. Nothing here bypasses a gate — the chat
drives the same tools CI verifies, and the acts that need a named human still refuse a session.

## One loop, one thing on screen

The many files under `<pack>/handoff/` are the **ledger, not the interface**. Nobody browses that
folder from chat: `DECISIONS.md` is the register the tools write, `RWB_QUESTIONS.md` is a generated
ranked view of that same register (CI fails if it drifts — the two can never disagree), and the
rest is RWP/RWDE working evidence. The only files a stakeholder ever *opens* are the answer forms
in `decision_answers/` — one small YAML per question, and only to type their answer and name.

What chat shows is a loop of four turns, each producing **exactly one page**, repeated until the
question list is empty:

1. **"where do we stand"** → one status view: the six gates, the blockers, the single next action
   and who owes it.
2. **"what do you need from me"** → one ranked question page for the PACK — highest
   blast-radius first, evidence and precedents on the same page. (The page lists each
   question's owner; it is one page per pack, not one page per answerer — several owners
   share it and read their own rows.)
3. **The person types their answers** into the named forms and commits — the one step outside
   chat, by design. Chat points at the exact file; it never types the values.
4. **"the answers are in"** → one all-or-nothing wave (`decision_record.py --apply`), one unblock
   worklist back, and turn 1's standing has moved.

The session rule the skills enforce: **one artifact per turn**. If an answer seems to need two
pages, it is two turns — nothing else pops up alongside.

## The journey, as chat

| you type | what runs | what you get |
|---|---|---|
| "where does prostate stand" / "what is blocking us" | `operate-rwd-product` → `status.py` | the six gates, blockers, next action and its owner |
| "extract the new spec" (a person registers the workbook first) | `run_spec_pipeline.py` | extraction + lint + coverage, `--check`-fenced |
| "draft the record for clinical:61" | `draft-contract-record` → `contract_record.py --item` | a lint-clean record quoting the spec verbatim (I22) |
| "what should we ask RWB" | `answer-decisions` → `decision_report.py`, `decision_packet.py` | questions ranked by blast radius, one page per pack with each question's owner named |
| "have we decided something like this before" | `knowledge_graph.py --query` | every pack's ruling, with approver, date and citations |
| "what do we know about X, anywhere" | `knowledge_search.py <terms>` | every surface at once — decisions, precedents, contract records, the shelf, capabilities, citations — each hit carrying WHAT KIND of authority it has and how far that has been taken |
| "RWB's answers came back" | `answer-decisions` → `decision_record.py --forms` / `--apply` | the signed forms transcribed, all-or-nothing, plus the unblock worklist |
| "apply the source verdicts" | `apply-source-verdicts` → `contract_record.py --apply-verdicts` | Gate 3 evidence moved into the two evidence-fed axes |
| "the revised workbook landed" | `next-cut` → `spec_diff.py` / `--carry-plan` | what provably carries, what needs re-reading, where |
| "run the build" / "validate it" | `run_rwdp.py` (Databricks), the Spark test suites | candidate vs published, goldens, QC — Gate 5/6 evidence |

A session like the one that built this platform IS the demo: spec extraction, 202 contract
records, 21 ranked questions, config, tests and release machinery — all driven conversationally,
every write through a tool that refuses what a session must not do.

## What chat deliberately cannot do

Approvals, signatures, decision answers, maturity claims. Those arrive only as **committed file
edits by a named person** — the forms in `handoff/decision_answers/`, the approval YAMLs, the
`source_refs.yaml` record. A chat interface that could perform them would be the hole the whole
design exists to close. The chat's job is to make the human act tiny and exactly located.

## For people who will never open VS Code

The read-only surfaces are HTML, generated out-of-checkout and shareable:

    python3 platform/tools/render_html.py flow <pack> --out ~/flow.html      # the status page
    python3 platform/tools/decision_packet.py <pack> --out ~/questions.html  # the pack's question page

## If a standalone chat page is ever wanted

A hosted web chat (an HTML page with a chat box driving these tools) would be a Claude Agent SDK
app wrapping this repository as its backend — feasible, but it is a SECOND harness: it must
re-implement the permission boundary Claude Code already enforces, and it must inherit every
refusal above or it becomes the approval hole. Build it when a stakeholder-facing hosted surface
is genuinely needed; until then, the extension panel and the generated pages cover the operator
and the reader respectively.
