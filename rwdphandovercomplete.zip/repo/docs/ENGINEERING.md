# Engineering notes

`README.md` describes what this repository is; `governance/WORKFLOW.md` describes the six gates. This
file covers the things that are easy to get wrong and expensive to get wrong.

## Before writing a predicate, a parser, or a checksum: check for the existing one

The rule with the worst track record here is duplication. A second implementation of an existing
concept is dangerous in a specific way: the two agree when written and diverge later, on either side
of a decision that matters. A checksum written by one and verified by the other; a status word one
gate accepts and another refuses. That is not a style problem — it is how a governed gate comes to
pass something it exists to stop.

A test asserting two modules share the same function *object* (`a.fn is b.fn`) is worth more than two
tests asserting they agree.

### Where the shared definitions live

Check these before adding to them. All are low in the import graph, so importing from them is
generally safe — `source_manifest` and `source_check` already import from `product_gates`, so
`product_gates` must never import back from those.

**`platform/tools/contract_lint.py`** — owns the CONTRACT and its registers (stdlib only, so every
product's test wrapper can run it standalone).
`decision_rows` · `cell` · `has_register` · `decision_status` · `register_errors` ·
`decision_register_errors` · `open_decisions` · `records` · `read` · `source_kind` ·
`vendor_sourced` · `unverified_sources` · `spec_digest` · `SOURCE_KINDS` · `NOT_VENDOR` · `ID_RE` ·
`DECISION_STATUSES`

`register_errors` is the one structural validator for those registers — required columns, duplicate
ids, blank and unknown statuses — parameterised because `DECISIONS.md` and `SPEC_QC_FINDINGS.md` are
the same shape with different vocabularies. `decision_rows` is the one reader of any `| ID | … |`
markdown register; it locates columns **by name**, since anything positional breaks on the first
product that orders its table differently. `cell` is the one way to read a named column out of a row
— case- and spacing-insensitively, with `default=None` distinguishing an ABSENT column from a blank
cell, which the gates depend on. `has_register` is the one definition of the canonical header, which
separates "QC found nothing" from "nobody looked".

**`platform/tools/product_gates.py`** — owns pack DISCOVERY and the gate vocabulary.
`products` (shape-based, any depth) · `maturity` · `union_members` · `verdict_rel` · `sha256` ·
`unstated` · `bad_date` · `spec_qc_errors` · `approval_record_errors` · `contract_approval_errors` ·
`configuration_approval_errors` · `waiver_errors` · `read_yaml` · `pack_yaml` ·
`config_bundle_sha256` · `delivery_sha256` · `PACK_FILES` · `WAIVED` · `QC_STATUSES` ·
`PLACEHOLDERS_PREFIX` · `PLACEHOLDERS_EXACT` · `QC_ACCOUNTED` · `WAIVER_FIELDS` ·
`CONTRACT_APPROVAL` · `CONFIGURATION_APPROVAL` · `*_APPROVAL_FIELDS` · `registry_entry` ·
`evidence_route` · `uses_data_profiler` · `vendor_policy_errors` · `VENDOR_POLICY` ·
`SCHEMA_EVIDENCE`

`evidence_route` is the one answer to "does this product use the data profiler". The route is
DECLARED per vendor in `governance/vendor_policy.yaml`, overridable per product on the registry
entry, and it FAILS CLOSED: an unknown vendor or unreadable policy refuses rather than defaulting to
"run", because a tool must not read patient-level data on the grounds that nobody said not to.
`registry_entry` matches family/slug and deliberately NOT `current_spec_version` — the vendor is a
property of the product, not of a spec revision.

`approval_record_errors` is the one reader of a formal approval form. Gate 2 and Gate 4 both ask
who / when / over which bytes; each supplies only its own field list and hash targets.

`read_yaml` is the one reader of a governed YAML FILE — it catches the parse AND rejects a
non-mapping root, because `- a\n- b` parses fine and then kills the caller with `AttributeError`.
Every gate reads through it, so a tool keeping its own `yaml.safe_load` is a gate that crashes
instead of reporting.

`pack_yaml` is the one resolver of a pack's ACTIVE config graph, and `config_bundle_sha256` digests
it. The binder and the Gate 4 approval subject must be the same set of files, or an approval covers
something the build does not execute. `delivery_sha256` is the separate DELIVERY digest (refresh,
source schema, data format, source layout) that Gate 3 governs.

**`platform/tools/source_manifest.py`** — owns Gate 1's vocabulary for a source material, and the one
answer to "may this pack publish".
`AI_CLASSES` · `AI_CLASSIFICATION` · `APPROVAL_FIELDS` · `POLICY_FIELDS` · `ATTESTATION_FIELDS` ·
`PENDING_FIELDS` · `materials` · `authoritative` · `source_status` · `resolve` · `vendor_prose` ·
`redact_vendor_prose` · `boundary_report` · `AI_READABLE` · `ai_extraction` · `ai_readable` ·
`ai_extraction_block` · `redaction_policy_sha256` · `AI_EXTRACTION` · `AI_EXTRACTION_FIELDS` ·
`AI_EXTRACTION_APPROVAL_FIELDS` · `releasable` · `evidence_verdict` · `RELEASE_EVIDENCE` ·
`delivery_drift`

These field tuples are mirrored by `governance/schemas/source_refs.schema.json`, which CI validates
every pack against. A parity test holds the two equal — edit one and edit the other, or a pack passes
CI while Gate 1 refuses it.

`ai_readable` is the one answer to "may AI read this pack", and it asks about the DERIVED artifact —
the sanitized `extracted.json` registered as `material_type: ai_extraction` — never the input it came
from. Reading the input's class is unsafe: a sponsor-authored document can quote vendor
documentation and still be recorded `sponsor_ai_eligible`. The approval binds to the BYTES (`sha256`
on `path_or_link`, which must name the file the slicer opens), to the run
(`extraction_fingerprint`), to the policy (`redaction_policy_sha256`) and to the counts it shows a
person — so editing the artifact, re-extracting, or weakening the marker list all revoke it. It
requires `status: reviewed`, because a signature beside a `why_provisional` is two statements about
one artifact. The whole `derived_from` ANCESTRY must be free of `vendor_restricted`, not just the
parent. No tool may fill in the five human fields, including the classification, so
`--register-ai-extraction` prints them as TODO and the pack stays red until a person answers.

`vendor_prose` DETECTS reproduced vendor documentation and `redact_vendor_prose` REMOVES it, side by
side so one marker list serves both — a redactor cleaning a different set than the check refuses
would leave a pack simultaneously sanitized and blocked. The redaction runs in `spec_extract` AFTER
`content_hash`, so `spec_digest` still binds a record to the real specification text; the sponsor's
stand-in is never edited, because `attested_against_sha256` records that it is faithful. Nothing the
redactor emits may contain a marker, including its own notice — naming which markers fired would put
them back in the file.

`releasable` DERIVES the release decision from Gates 1–4; `evidence_verdict` reads that same decision
back out of a `RELEASE_EVIDENCE.yaml` that `deploy_tree.py` wrote. A production tree cannot re-derive
it — the stand-in Gate 1 needs is deliberately not deployed — so the recorded form exists, and
everything that makes it safe (commit binding, `is True` rather than truthiness, refusing
cleared-and-blocked) lives in that one function.

**`platform/tools/profile_io.py`** — the one fail-closed reader of a `data_profiler.R` profile TSV.
`load` · `provenance` · `table_base` · `top_values` · `CUT` · `REQUIRED` · `PROVENANCE` ·
`FULL_PROFILE`

The STAMPED `profile_cut` is the cut identity; the `CUT` table-name suffix only corroborates it.
Reading the cut from the name alone would make one vendor's naming convention load-bearing for every
tumour.

**`platform/tools/contract_record.py`** — the one renderer of a contract row, and the one place a
drafter's judgment is merged with the spec's evidence. `row_for` · `merge_evidence` · `load`

`contract_scaffold.MACHINE_OWNED` / `evidence_for` own the fields the SPEC establishes — `spec_refs`,
`spec_digest`, `required_rule`. `--item <domain:row>` supplies them and the tool REFUSES a draft that
also carries them: a retyped digest fails I15 loudly, but a tidied-up `required_rule` replaces the
spec's exact words with a paraphrase and nothing fails at all. `--product` is REQUIRED
(`--format-only` is the named opt-out) because I8, I15, I17 and the reference checks need the pack.

**`platform/tools/spec_slice.py`** — the one way to assemble one drafting unit's context.
`slice_pack` · `render` · `STYLE_CAP` · `DROP`

It re-derives nothing: domains come from `extracted.json`'s own `domain` field, records through
`contract_lint.records`, decisions through `contract_lint.decision_status`. Recomputing a domain from
the tab label here would be a second mapping free to disagree with the pipeline's — and the tab label
is exactly what differs per tumour. An unknown domain FAILS naming the ones that exist, because an
empty slice reads exactly like a specification that says nothing.

It carries an index of all three registers for the rows in scope — decisions, QC findings, gaps — so
a drafter reuses an id instead of raising the same thing under a second one. Register citations it
cannot resolve to a row are REPORTED, never dropped: dropping one makes a recorded defect read as "no
finding here".

**`platform/tools/finalize.py`** — the one place a pack's stated SUMMARY is checked against the
evidence it summarizes. `facts` · `claim_errors` · `claim_text` · `scope_errors` · `section_errors` ·
`CLAIMS` · `contract_header`

It DERIVES every number from the tool that already owns it — `contract_lint.records`,
`contract_lint.INVARIANTS`, `contract_scaffold.coverage_report` — and reads coverage counts from the
PRODUCER, never by parsing the rendered `COVERAGE.md`. It does not rewrite claims: `MATURITY.yaml` is
a human claim on purpose, and a generator that silently corrected it would destroy what that file
exists to make visible.

**`platform/tools/pack_run.py`** — the pack/cut/member/output contract shared by the two live-evidence
runners (`run_product_profile.py`, `run_product_schema_check.py`).
`pack_config` · `config_path` · `targets` · `restricted_dir` · `evidence_dir` · `product_id`

**`platform/tools/bundle_products.py`** — the one generator of the deployed job set, and the one place
activation is decided. `entries` · `activation` · `activation_errors` · `document` · `render` ·
`ACTIVATION` · `ACTIVATION_FIELDS`

Jobs come from `products/registry.yaml` (materialized products only); pause state, `run_as`,
CAN_MANAGE/CAN_VIEW and cluster policy come from `products/activation.yaml`. `activation_errors` owns
the rule that makes activation governed rather than a `pause_status` somebody edits:
`schedule_enabled: true` REQUIRES `source_manifest.releasable(pack)`. That is not a second release
flag — releasability is derived and unsettable — so the dependency runs one way, and `is True` rather
than truthiness because `1` and `"yes"` are what a hand-edit looks like.

**`platform/tools/repo_hygiene.py`** — the one definition of what may never be COMMITTED.
`NEVER_COMMITTED` · `MACHINE_PATHS` · `GENERATED_ONLY` · `tracked` · `restricted_files` ·
`present_files` · `registered_workbooks` · `production_eligible_workbooks` · `machine_paths_in` ·
`errors` · `NotAGitCheckout`

Two different questions about a spreadsheet: `registered_workbooks` is the CHECKOUT rule (some pack
says what this is — a draft under review belongs in a development repo), and
`production_eligible_workbooks` is the stricter one (`status: reviewed`) that
`deploy_tree.forbidden_in` applies. Conflating them would make "only approved specifications reach
production" untrue. It returns an empty set today, which is the honest answer: no pack yet has a
reviewed specification input.

Stdlib-only and the FIRST thing CI runs. It refuses exported DOCUMENTS (`.pdf` `.doc(x)` `.ppt(x)`
`.msg` `.eml`, page images, saved web pages, archives), whole-repo transfer snapshots, and any
tracked text file naming somebody's machine. A SPREADSHEET is judged by REGISTRATION, not extension:
permitted when some pack's `source_refs.yaml` names it as `program_spec` or `extraction_input`,
refused otherwise — a blanket `.xlsx` allowance would equally admit a vendor data dictionary, a
patient-level extract or a saved profile. `restricted_files` reads the git INDEX and `present_files`
WALKS the working tree, because a gitignored file is still on disk and still readable by any local
process. `deploy_tree.forbidden_in` DERIVES its file-kind refusals from `NEVER_COMMITTED` and
`test_spec_pipeline` takes `MACHINE_PATHS` from here, so neither can come to permit what the other
refuses. `tracked` RAISES rather than returning `[]` when git cannot be read: an empty list would
report a clean repository, which is the one answer it may not invent.

**`platform/tools/deploy_tree.py`** — the one definition of what production is allowed to see.
`build` · `check_tree` · `runtime_tools` · `forbidden_in` · `deployed_files` · `tree_digest` ·
`git_state` · `MARKER` · `PLATFORM` · `PACK_EVIDENCE` · `ROOT_FILES` · `FORBIDDEN`

`check_tree` is the one check that looks at a GENERATED tree, and `--check-tree DIR` is what to run
immediately before packaging one. `repo_hygiene --check` cannot: it reads the git INDEX and a tree
has no `.git`, and from the repository it skips `build/` as generated. `runtime_tools` DERIVES the
deployed tool set from what `platform/databricks/` imports, transitively, with `ast`.
`--evidence-out DIR` writes the per-pack audit bundle outside the runtime tree — it answers "what was
approved" and carries source-provenance prose a workspace has no business holding.

An ALLOWLIST, because syncing the repo root minus a few globs ships every stand-in, reference
document and sandbox experiment into the one environment where exposure matters most. Building the
tree DEPLOYS NOTHING and RUNS NOTHING — it copies files into a local directory, and
`test_governance.py` checks the result offline, both directions: nothing forbidden got in, and
nothing the build reads was left out. Take the config graph from `product_gates.pack_yaml` and the
shared product files from `engine.config.SHARED_ASSETS` — never a directory listing, and never a
second inventory.

`deployed_files` WALKS the tree (so an added file counts) and `tree_digest` hashes path+bytes; both
run at build time AND at run time, which is the only reason the recorded digest can be verified. The
commit alone is two strings, and can be satisfied by a dirty checkout stamped with a clean SHA.

**`platform/engine/`** — `config.product_dir` resolves a pack including its registry `family`;
`config.SHARED_ASSETS` / `config.shared_asset` own where the cross-pack runtime files live (registry,
catalog, audiences, dashboard_vars, tfl_specs); `release.versioned_ads` / `release.staging_ads` /
`release.public_tfl` / `release.staging_tfl` own what a release's tables are called — staging is
BUILD-SCOPED, so a validate-only run's staging tables are not overwritten by the next run;
`vendors.resolve` owns physical table layout. Never restate any of these as a path or name literal.

`codelists.sql_str` is the one Spark SQL string literal quoter, and it escapes BACKSLASHES as well as
quotes. Spark drops an unrecognised escape silently — `'\d'` is the string `d` — so a config carrying
a regex would compile to a pattern matching nothing, with no error anywhere. `stages/clinical.py`
imports it as its `_q` and `test_r_parity` asserts the two are the same function OBJECT. `engine-r/`
must define it twice (`cases.R` and `codelists.R` are each `source()`d ALONE by their parity
harnesses, so neither can call the other); the same test compares all three against a hostile string
set, which is what keeps two definitions from becoming two behaviours.

`release.swap_plan` is the one order in which public views move — TFLs first, the ADS last as the
commit anchor — and `release.promotion_plan` reuses it rather than restating it. A build-and-publish
run and a promotion run publish the same set in the same order; two orderings for one operation would
agree today and diverge on the first change to either. `promotion_blockers` is the PHYSICAL half of
Gate 6, separate from `publish_approval_errors`' paperwork half: an approval says a person signed for
a build id and a manifest digest, and says nothing about whether those bytes are still on the cluster.
Promotion is the one step that publishes something it did not just build, so both are required.

`contract_scaffold.judgment_stub` is the one definition of what a DRAFTER answers, and the one place
the field-default policy lives — the rule was written twice already, once building the scaffold record
and once per cell in `to_contract_records`. It omits `MACHINE_OWNED` and `status` because
`contract_record` refuses all four as coming from the extraction and from an accountable person; a
starting point that carried them had to be hand-stripped before the tool that consumes it would take
it, once per record, on every pack. `spec_slice` renders it directly under the spec rows, so the rule
the record must state is on the same page as the stub.

`spec_extract.sheet_key` is the one comparison key for an Excel tab label — casefolded, all whitespace
removed. The shared map's keys, the domain lookup, `ignored:`, a pack's `IGNORE` and an explicit
`--tabs` list all go through it. Comparing `strip().lower()` made `5B. ClinChars` and `5B.ClinChars`
two keys, so a workbook spelling the label without the space matched neither half of the map and an
entire domain — 96 requirement rows — went unscanned, with the symptom appearing far downstream as
citations that would not resolve. `shared_sheet_map` refuses two labels that normalise together and
carry different rulings, because merging spellings is safe and merging answers is not.

`console.use_utf8` is the one place the tools' output encoding is set, called from every
`__main__` block. Python picks stdout's encoding from the platform — cp1252 on Windows — and a `—` or
`∪` in an unrelated message then raises `UnicodeEncodeError` from inside `print`, most often on
redirection. `test_governance.py` holds every tool with an entry point to calling it.

### If it genuinely is a new concept

Put it in the module that owns the thing it is about, export it, and import it everywhere else. Do
not copy it for one caller.

## This is a multi-tumour framework — never write one tumour's name into shared code

Every path assumption is a latent failure for the next product, and it fails silently.

- Discover packs with `product_gates.products()`, never `products/*/*/*` — a fixed depth drops every
  pack under a new grouping level, with nothing going red.
- Take the **pack path** as an argument; never resolve a pack through the registry inside a tool
  stored in a pack. The registry's `current_spec_version` moves, and the tool starts reading a
  different version than the one it lives in.
- Get the family from the registry (`t["family"]`, default `oncology`) — the first heme product fails
  on a hardcoded `products/oncology/…` path, not on anything about its content.
- Resolve table names through `cfg.table()` / `cfg.table_in()`. Do not assume `{stem}_{refresh}`:
  `run.source_layout` is a documented per-product override, and `{schema}` may appear inside the
  physical name.
- Under a `source_union`, one run covers ONE member. `cfg.source_fqns()` deliberately fans out across
  all members (preflight wants that); `cfg.table_in(source, member)` is what member-scoped evidence
  needs.

## Evidence and approval gates fail CLOSED

A field that is not stated is an unanswered question, never a default:

- an absent counter is not a zero;
- `none` / blank identity is not a match;
- a placeholder (`TODO`, `TBD`, `REPLACE_ME`) is not an answer — use `unstated()`;
- a blank status in a register is not "resolved".

When adding a check, add the test that proves it **bites** — revert the fix and confirm the test
fails. A test that passes against the bug is worse than no test.

## Restricted output never enters the checkout

Profiles carry per-column top values and date ranges with no small-cell floor; schema reports name
physical vendor tables and columns. `.gitignore` stops a commit, not a read by an indexing tool or
any local process. `--out-dir` is required and is refused inside the checkout. Local/synthetic mode
is a development aid and is refused as Gate 3 evidence.

Neither does an exported DOCUMENT: a program spec exported to PDF, a delivered data dictionary, a
screen captured into a file. `platform/tools/repo_hygiene.py --check` refuses those, and it reads the
git INDEX — `.gitignore` says nothing about what is already tracked and is overridden by
`git add -f`. Link the document from `source_refs.yaml`; do not carry it.

**The AI boundary is VENDOR-derived content, and `governance/WORKFLOW.md` §"Eligibility" defines it
— read there, not here.** Two things this file will not restate, because a second copy of a policy is
how the two come to disagree:

- Eligibility follows the CONTENT's classification and provenance (`source_refs.yaml`'s
  `ai_classification`), never the folder it sits in.
- It is not changed by a task instruction. A prompt saying "go ahead" is not an approval mechanism;
  the classification on the material is.

The one point worth repeating: a sponsor-authored RWB specification is AI-eligible **when its
recorded `ai_classification` is `sponsor_ai_eligible`** — drafting contract records from such a spec
is the framework's primary AI function (WORKFLOW.md Gate 2, "AI drafts; humans approve"). Never infer
eligibility from a document's title or folder: an internally authored document that quotes or embeds
vendor material inherits the restricted classification, which is exactly why the field exists. What
AI must never ingest is vendor-originated or vendor-derived content — the delivered data, vendor
prose, a profile TSV, a schema report. Verdicts cross that boundary; contents do not.

## Verify before claiming

**The working directory matters, and mirrors CI.** The Python suites run from `platform/`; the gate
tools run from the repo root, because `product_gates --list-*` emits repo-root-relative pack paths.
`products()` also derives its root from the working directory, so a discovery-based test can pass
from one directory and be silently vacuous from the other — run the suites from **both** and assert
non-empty discovery inside any test that sweeps packs.

```bash
set -euo pipefail          # this block states a PASS; without it a failing suite prints and continues
# suites — from platform/ (matches the CI job's working-directory)
cd platform
python3 -m py_compile engine/*.py engine/stages/*.py tests/*.py tools/*.py \
                      TUMOR_TEMPLATE/handoff/tests/*.py
# the two spark suites skip without PySpark; r_parity is its own CI job
for t in tests/test_*.py; do
  case "$(basename "$t")" in test_stages_spark.py|test_smoke_spark.py|test_r_parity.py|test_patient_goldens_spark.py) continue;; esac
  python3 "$t" >/dev/null
done
python3 tests/test_r_parity.py

# gates — from the repo root (pack paths are root-relative)
cd ..
# FIRST in CI and first here: stdlib-only, and it answers "is there an exported document or a machine
# path in the index" before anything else is known to work.
python3 platform/tools/repo_hygiene.py --check
# The product tests are the first gate CI runs. Because CI stops at the first failure, everything
# after this step gets SKIPPED when they are red — so run these FIRST; they are what "is the repo
# green" means.
for t in $(python3 platform/tools/product_gates.py --list-tests); do python3 "$t"; done
python3 platform/tools/source_manifest.py --all --check
for p in $(python3 platform/tools/product_gates.py --list-contracts); do
  python3 platform/tools/source_check.py "$p" --structure-only --check
done
for p in $(python3 platform/tools/product_gates.py --list-buildable); do
  python3 platform/tools/contract_binding.py "$p" --enumerations --parameters --check
done
# Every other gate checks an ARTIFACT; this one checks the sentences a pack writes ABOUT its
# artifacts — scope, counts, maturity note.
for p in $(python3 platform/tools/product_gates.py --list-contracts); do
  python3 platform/tools/finalize.py "$p" --check
done
```

State what was run and what it said. If a step was skipped, say so. **"The suites pass" is not "the
repo is green"** — they are different claims, and only one is what CI gates on.

### Editing a file and re-running is not enough: clear `__pycache__` first

Python decides a `.pyc` is current by comparing the source's **mtime (whole seconds) and size** with
the two numbers recorded in the `.pyc` header. Both matching means "unchanged" — the contents are
never hashed. So an edit that preserves the byte size and lands in the same second as the compile
that preceded it is **invisible**, and the interpreter keeps serving the old code with nothing to
show for it: the source on disk reads correctly, `grep` agrees, and the imported module disagrees.

This is not a corner case; it is the exact shape of a mutation test. Reverting a mutation is a
same-second, same-size write by construction when the mutation swapped, renamed, or reordered
something of equal length. It has already happened here: a two-element reorder inside a tuple was
"restored", the restore was invisible, and every run afterwards — including a full sweep and six
mutation checks — executed the mutant. One of those six was recorded as caught when nothing had
caught it, and the defect it was supposed to prove was real went unnoticed.

```bash
find . -name __pycache__ -type d -prune -exec rm -rf {} +   # BEFORE the run, not after
python3 -B -m pytest platform/tests/ -q                     # and do not write new ones
```

`-B` alone is not enough — it stops new caches being written, not stale ones being read. Delete
first. Treat any result from a mutation loop that did not clear the cache as unmeasured, and take it
again.

### Counting failures: use pytest, not the standalone runners

Each suite is also a script, and its `__main__` block calls its tests in turn — so it **stops at the
first failing assertion** and the rest of that file never runs. That is fine for "is it green"; it is
not a failure count. A sweep of the standalone runners once reported a handful of failures where
pytest reported 65, because thirteen suites had each aborted on their first.

```bash
python3 -m pytest platform/tests/ -q        # the count
```

Use the loops above to answer *green or not*, and pytest to answer *how many and which*.

### On Windows

Every tool is pure Python and runs unchanged; only the loops above are bash. **A PowerShell twin for
every one of them, in the same order** — an earlier version of this section carried three of the six
and dropped the skip-list from the one it did carry, which is worse than carrying none: a runner who
follows an incomplete list believes they ran the suite.

**Read this first, because it is the one that fails silently.** PowerShell does not stop a loop when
a native command exits non-zero, and `$ErrorActionPreference` does not change that — it governs
PowerShell's own errors, not a program's exit code. A failing `py` inside `ForEach-Object` prints its
traceback and the loop carries on to the end, so the block *completes* and reads as a pass. Check
`$LASTEXITCODE` per iteration, or a red gate looks green:

```powershell
$fail = 0
# …inside each loop body, after each `py` call:
if ($LASTEXITCODE -ne 0) { $fail++ ; Write-Host "FAILED: $_" }
# …and at the end:
if ($fail) { Write-Host "$fail step(s) failed" } else { Write-Host "all steps passed" }
```

```powershell
cd platform
# PowerShell does NOT expand wildcards for external programs — `py -m py_compile engine\*.py` passes
# the literal string. Expand them first.
py -m py_compile (Get-ChildItem engine\*.py, engine\stages\*.py, tests\*.py, tools\*.py,
                                TUMOR_TEMPLATE\handoff\tests\*.py | ForEach-Object FullName)

# the two spark suites skip without PySpark; r_parity is its own CI job — SAME exclusions as bash
$skip = 'test_stages_spark.py', 'test_smoke_spark.py', 'test_r_parity.py'
Get-ChildItem tests\test_*.py |
  Where-Object { $skip -notcontains $_.Name } |
  ForEach-Object { py $_.FullName > $null }
py tests\test_r_parity.py

cd ..
py platform\tools\repo_hygiene.py --check
foreach ($t in (py platform\tools\product_gates.py --list-tests)) { py $t }
py platform\tools\source_manifest.py --all --check
foreach ($p in (py platform\tools\product_gates.py --list-contracts)) {
  py platform\tools\source_check.py $p --structure-only --check
}
foreach ($p in (py platform\tools\product_gates.py --list-buildable)) {
  py platform\tools\contract_binding.py $p --enumerations --parameters --check
}
foreach ($p in (py platform\tools\product_gates.py --list-contracts)) {
  py platform\tools\finalize.py $p --check
}
```

`run_spec_pipeline.py` exists for this reason: the shell wrapper was the only bash in the workflow, so
on a Windows checkout Gate 2 generation and the `--check` drift verification were unreachable.

Console encoding needs nothing set. Each tool calls `console.use_utf8()` at its entry point, so its
output is UTF-8 whatever the machine's code page is — including when redirected to a file, which is
where a cp1252 default used to raise `UnicodeEncodeError` on a character in an unrelated message.
