# Handover plan — a working RWDP product/process someone can take forward

**Purpose of this file.** A plain-language record of *what we are trying to build*, *where it actually
stands today* (verified against the code, not remembered), and *the ordered work* that turns it from a
governed-but-empty framework into a demonstrable, handover-ready product/process. It is a roadmap and a
status board, not a governed artifact — no gate reads it, and it is not deployed.

Companion visual (the compounding idea, drawn from real prostate data):
<https://claude.ai/code/artifact/c17bbfde-8642-4f49-855a-38feb715e1c8>

Last grounded: 2026-08-15 (sixth external review, responded to in full below).

---

## 0. See it work

**Get on `main` and pull.** This work was merged to the default branch on 2026-08-03 (PR #359,
#360); an earlier version of this paragraph said it was branch-only, which is no longer true:

```bash
git checkout main && git pull
git rev-parse --short HEAD        # say this number when you present
```

**First, check the machine.** The first way this repository fails a stranger is not a bug — it is a
missing dependency or an unwritable output directory, surfacing as a traceback several steps inside a
tool that had nothing to do with it:

```bash
pip install -r platform/requirements.txt
python3 platform/tools/doctor.py        # and what each missing optional thing costs you
```

One command. It runs the real governance tools over one pack, in lifecycle order, and shows what each
one says:

```bash
python3 platform/tools/demo.py                                   # the packs you can walk
python3 platform/tools/demo.py products/oncology/prostate/202606  # walk the reference product
python3 platform/tools/demo.py products/oncology/prostate/202606 --full   # untruncated output
```

It is **read-only** — every command is a `--check` or a report, the deployment tree is built into a
temp directory, and nothing signs anything. Sixteen steps, from "what may never be committed" through
registration, the AI boundary, the contract, the config binding, the pack's own tests, and the derived
release decision, ending at the deployment tree and activation.

**Watch step 4.** It reports whether the slicer may read the specification, and the answer is
DERIVED from `ai_readable`, not asserted by the walkthrough. Today NO pack's extraction is
approved — prostate/202606's registration is `status: pending`, unsigned, and oc/202606 has no
registration at all — so every pack refuses, each naming its own missing human act. Either way the point is
the same and it is the single clearest demonstration of what makes this governed rather than merely tidy: **the
permission comes from a named person against specific bytes, never from asking.** **And watch step 13**: the release decision is *derived*
from Gates 1–4 — there is no flag to set — so it reports BLOCKED and names the exact remaining
distance to production.

A shareable page of what the walkthrough shows and proves — for anyone who won't run it themselves:
<https://claude.ai/code/artifact/2383a2dd-e34d-404e-b138-de1705e0ccf0>

**It doubles as a maturity x-ray.** Run it across the portfolio and each pack's real state falls out,
including the difference between a gate that *passed*, one that *refused*, and one that had
*nothing to read* — prostate/202606 refuses at step 4 (its extraction is unsigned), oc/202606
additionally fails the contract↔config binding, and the placeholder packs have several gates with
nothing to read at all. The step COUNT has grown as steps were added; don't quote one from here,
run it: `python3 platform/tools/demo.py <pack>`.

The walkthrough is guarded by `platform/tests/test_demo.py`: every tool it names must exist, every
command must be read-only, and it must derive no governed fact of its own. Nothing in CI runs the
walkthrough end to end (it builds a tree and runs suites), so without those tests it would rot
silently and break for exactly the person it exists for.

### 0.1 The precedent store

Questions more than one pack has already had to argue out, and where they were answered:

```bash
python3 platform/tools/precedents.py                                        # the store, live statuses
python3 platform/tools/precedents.py --for products/oncology/endometrial/YYYYMM   # what to expect
python3 platform/tools/precedents.py --check                                # every citation resolves
```

Nine entries today, seeded from real recurrence across the live registers — not from guesswork. Two
of them (`follow-up-end-definition`, `days-per-month-constant`) have already been argued on **three
packs across two tumours**, which is what makes them precedents rather than prostate trivia.

Three design rules make it safe to trust:

- **It holds no answers, only pointers.** Each entry cites `(pack, decision id)`; the question text,
  status and agreed answer are read live from that pack's `DECISIONS.md` through
  `contract_lint.decision_rows`. A copied answer would be a second copy of a governed fact, free to
  diverge the moment someone edits one side. A pointer cannot go stale — it can only stop resolving,
  and `--check` turns that red.
- **It is advisory and powerless.** No gate reads it; a test asserts no gate ever starts to. It
  cannot resolve a decision, approve a record or make a pack releasable.
- **It over-proposes rather than under-proposes.** "Already covered" means the pack is cited in
  `seen_in` — no fuzzy matching of question wording, because any matcher good enough to pair
  `PRACTICE-MISSING-CODE` with `PRACTICE-NO-RECORD` would also pair two questions that merely sound
  alike and wrongly declare a pack covered.
- **Only governed product packs count as sightings.** The store used to hold **nine** entries; seven
  of them met the two-sighting floor on one real prostate pack plus
  `platform/tests/fixtures/prostate_202607` — a parked spec revision the test suite owns and edits.
  Refusing it as a *tumour* was the first half of that fix and left the sighting count intact;
  refusing it as a *sighting* is the rest, and it took the store from nine entries to **two**.
  Nothing was lost: all seven questions are still in `products/oncology/prostate/202606`'s own
  register, which is where a question one pack has asked belongs. They come back the day a second
  product's register asks the same thing. A governed pack is whatever `product_gates.products()`
  discovers — the same definition every gate uses.
- **It grades TWO INDEPENDENT AXES, and never collapses them.** `reach()` is how far the evidence
  travels (`multi_tumour` · `single_tumour`); `authority()` is what stands behind the answers
  (`ruling` — answered and signed in every pack · `answer` — answered, at least one unsigned ·
  `partial` · `question` · `unresolvable`). A single tier used to conflate them, letting
  `single_tumour` short-circuit the grade so a *signed* answer inside one programme rendered
  identically to an *open* question inside one programme — the stronger fact was computed and
  thrown away. Both print on every entry. **Today the store grades 2 multi_tumour, 2 question**, and
  the tool prints the consequence: every answer these entries rest on is still open, so the whole
  store is questions-to-expect and evidence to show an answerer, never authority to cite. It stops
  printing that sentence when a signature makes it untrue. Neither axis is ever stored — `--check`
  refuses an entry carrying `strength:`, `tier:`, `authority:` or `reach:`, because a stored grade
  is a claim about a register this file does not own, free to say `ruling` about a row whose
  approver column is empty.

Today it tells the endometrial seed there are **2 questions to expect** — each with the packs that
already fought over it — and tells prostate and ovarian there is nothing they have not raised.
Adding an entry is the whole maintenance model: notice a question for the *second* time, on a second
*governed* pack, and add it.

**Source keys are DERIVED, not stored.** The second half of the store answers "which sources does a
product of this kind need?" — and unlike decisions, nothing needs curating: `demographics` in one
config and `demographics` in another are the *same string*, so recurrence is computed from the configs
every time and cannot go stale. Two rules make it safe:

- **Scoped to the vendor**, taken from the registry. Every Flatiron pack declares `practice`, `ses`,
  `telemed` and `vitals`; neither COTA pack declares any of them. A pack with no registry entry gets
  nothing proposed at all. **That evidence is confounded**: every Flatiron registry entry is `solid`
  and every COTA entry is `heme`, so "does not cross vendors" and "does not cross solid/heme" fit the
  data equally well, and the scoping may be right for the wrong reason. A tripwire test fires on the
  first Flatiron heme (or COTA solid) product — the pack that can finally tell the two apart.
- **Counted in distinct tumours, not packs** — the lesson the decision half taught. prostate 202603
  and 202606 both declare `psa` and `provenge`, but that is one specification re-read across two
  revisions, not evidence any other tumour needs them.

**No physical table name is ever proposed.** They are not stable even within a vendor
(`t_demographics` vs `t_meg_demographics`; mortality differs across all three Flatiron packs), and
confirming that a table is the *right* one needs a profile and a human at Gate 3. What carries across
a vendor's tumours is *which sources a pack needs*, never what they are called.

It already finds real things: endometrial is the only Flatiron pack with no `lab` source, and
prostate/202606 the only one with no separate `ecog`. The contract-only test fixture, which has no config, gets
all 16 keys as a starting checklist.

**Version drift** is reported separately, and is a different question again. Precedent asks what
*other tumours* needed; drift asks what *this product's own other versions* declare. The proposals
exclude the pack's own tumour on purpose — that is what stops `psa` and `provenge` being offered to
an endometrial analyst — but on prostate/202606 the exclusion hid the most actionable fact available:
**202603 declares `ecog` and 202606 does not.** Reported in one direction only (what is absent here),
without deciding which version came first, and without claiming to know whether a removal was
deliberate or a regression — only one of those is fine, and the tool cannot tell which it is.

A pack that has declared *nothing* is handled apart from one that has diverged: **not started and
regressed are different states, and only one is a defect.** The contract-only test fixture has no `config/` at all,
so it is told exactly that, and shown only the sources its own earlier versions needed that no other
tumour would propose (`alphabet`, `lab`, `metastasis`, `provenge`, `psa`) — five lines instead of
twenty-one, sixteen of which merely repeated the checklist above them.

### 0.2 The block catalogue

What a pack's config may **name** — the engine's vocabulary, printed:

```bash
python3 platform/tools/blocks.py            # every named thing config can select
python3 platform/tools/blocks.py --check    # CI: no vocabulary has gone empty
```

Ten sections: codelist match operators, BMI/BSA methods, follow-up row filters and sources,
death-conflict policy, vendors, tumour classes, required sources, variable pack roles — each with
**the config key that takes it**, which is the half a bare list of valid names leaves out.

**Derived, never restated.** Every name is imported from the module that owns it, and a test asserts
each section equals its registry *and* that `blocks.py` reads the same objects `validate.py` checks
against. A hand-written list would be right the day it was typed and wrong from the first edit after
— and a stale catalogue is worse than none, because an analyst believes it and writes a method the
validator then refuses.

**The one gap it closed.** Every other named thing already had a registry and an error that listed
the valid values. The codelist DSL did not: its operators were a hardcoded `if/elif` chain and an
unknown one raised `unknown match operator: 'x'` — no help at all to someone authoring YAML.
`codelists.MATCH_OPERATORS` is now the single place those names live; the error lists them, the
catalogue prints them, and a test reads the dispatch back out of the module's own syntax tree to
prove the two cannot drift.

Guided errors were otherwise already in place — `validate.py` names the valid options in seven
places, and the engine's `_resolve_formula` does the same at build time. Phase 2 was mostly
*discovering* that and filling the one hole, not building a layer.

### 0.3 The config worksheet

A contract exists and `config/` is blank — what now?

```bash
python3 platform/tools/worksheet.py products/oncology/prostate/202606
python3 platform/tools/worksheet.py <pack> --values    # candidate YAML in full
```

Three sections, and **the order is the product**:

1. **Answer these** — open decisions ranked by how many records each unblocks. On prostate,
   `OUTCOME-COHORT-MAP` alone blocks **19 records** while ten others block one or two each, so
   working in file order is close to the worst possible sequence. Decisions blocking nothing today
   are listed separately, off the critical path.
2. **Paste these** — the value lists the spec already states (4 blocks on prostate), lifted so
   nobody retypes them, each naming what the spec does *not* state.
3. **Account for these** — config the contract does not claim. Ovarian has **33** such blocks.

**It composes; it computes nothing.** Every number comes from the tool that owns it —
`finalize.facts`, `decision_report.blast_radius`, `contract_binding.check`/`.promote`. A test
asserts it opens no file and calls no parser, and that its headline counts equal what those tools
return. Like §0.2, most of Phase 3 already existed in pieces; what was missing was the sequence and
one entry point.

A pack with **no contract** gets told so and pointed at the spec pipeline, rather than a worklist of
truthful zeroes — the same "not started ≠ nothing to do" distinction the precedent store makes.

**An empty section says which kind of empty it is.** "None" means either *we looked and found
nothing* or *there was nothing to look at*, and printing the same line for both is the single failure
this codebase has now produced five times in five tools — an absent test suite scored `PASS`, an
unstarted config called "drifted", a pack with no contract given a worklist of zeroes, an undrafted
specification making a pack look nearly done, and section 3 telling a config-less pack that *"every
governed block is claimed"* when the count was **0 of 0** (that pack has no `config/` at all). Every
zero-denominator branch now carries one shared phrase, and a test asserts the rule across **every
section of every pack** rather than fixing the instance in front of it.

**Spec coverage is stated before anything is ranked**, because a short list is only good news if the
list is complete. Ovarian's contract holds **9 of 360 spec items, 299 undispositioned** — and the
worksheet was reporting 3 blocking decisions and 33 unclaimed blocks, small numbers that read as
"nearly done" when almost nothing has been drafted. The banner now carries the coverage, and where
rows are undispositioned it says plainly that the three lists cover only the drafted part, so a short
list is not evidence of little remaining work. Packs with complete coverage get the numbers and no
warning.

---

### 0.4 Four more tools, and what each answers

All read-only, all composing tools that already own the numbers.

```bash
python3 platform/tools/dry_run.py      <pack>   # what breaks the moment you CLAIM approval
python3 platform/tools/spec_diff.py    <old> <new>   # what a revision changed; what may carry
python3 platform/tools/decision_packet.py <pack> --out p.html   # the questions, for whoever answers
python3 platform/tools/placeholders.py --all     # what every REPLACE_ME is doing there
```

**`dry_run`** makes both approval claims on a *copy* and subtracts: `latent = blockers when claiming
− blockers today`. Run it for the CURRENT split (`python3 platform/tools/dry_run.py <pack>` prints
"blocked today by N" and "N LATENT blocker(s)") — the latent count RISES as the gates get sharper,
so any number written here is stale by construction; at the time of writing prostate/202606 stood at
3 today and 12 latent. Latent blockers are the ones invisible until the approval meeting. One is the
pack's unaccounted spec-QC findings, a count that grew once findings sitting under a second table
with its own header were found unreadable and their Status unparseable.

**`spec_diff`** answers what a new spec revision actually costs, measured 202606 → 202607 before that pack became a test fixture: **199 of 200 rows
byte-identical, and 200 of 202 records carry as-is** — proven, not assumed, by recomputing each
record's `spec_digest` against the new extraction. the revision nonetheless re-drafted 199 records and
re-raised 22 decisions under new ids, inheriting **zero** answers. This is the largest single waste
in the process and it is now measurable.

**`decision_packet`** renders one page per open decision — question, spec evidence, how many records
it blocks, what other tumours decided — for someone who will never open a terminal. It also prints
what it *cannot* record (who approved, when, against which bytes), because the register has nowhere
to put them.

**`placeholders`** classifies every `TODO`/`TBD`/`REPLACE_ME` rather than counting them — run
`python3 platform/tools/placeholders.py --all` for the CURRENT counts (every number this paragraph
ever carried went stale within days; the tool is the count). The `REPLACE_ME` in each config are
environment values the pack refuses to hardcode, and `engine.validate.check` **raises** while they
are unfilled. The UNACCOUNTED class is real work: prostate/202606's `DATA_SOURCE` carries fifteen
empty fields, cites no decision, and every invariant passes over it.

The first version of this tool reported **45**, and the difference is the point. It excused every
placeholder on any record citing any decision or gap id — so a decision about the lab selection
window was excusing an empty `type` field on the same row. The excuse now requires BOTH a cited
question and `requirement: decision_required`, the status that actually means the record is waiting
on it. On prostate/202606 that took 8 unaccounted to **49**: 8 records citing nothing, and **41
citing a question they are not blocked by**. A tool whose only real output is the number nobody can
explain must not make that number smaller than it is.

### 0.5 The knowledge layer — what the repository knows, and what any of it may SETTLE

```bash
python3 platform/tools/knowledge_search.py follow-up end   # all six surfaces, ranked by authority
python3 platform/tools/capability_registry.py --check      # every coverage claim resolves to code
python3 platform/tools/portfolio_status.py --check         # declared status vs what is on disk
python3 platform/tools/citation_register.py --check        # every citation's verification route
python3 platform/tools/protocol_record.py --scope          # which builds each study actually read
```

**The problem this layer answers.** The repository holds six kinds of knowledge about the same
subjects — decision registers, the precedent store, contract records, the variable inventory, the
citation register, the capability registry — in six places with six readers. Someone asking "how do
we handle end of follow-up?" had to know all six existed, and worse, had to know which of them could
ANSWER as opposed to merely mention. In a grep an inventory entry and an attributed ruling look
alike, and the inventory authorises nothing whatever state it reaches.

`knowledge_search.py` searches all six in one pass and ranks by **two facets**, not one ladder:
a **domain** (`product_ruling` · `implementation_evidence` · `literature` · `provenance`) saying what
kind of authority a hit could ever carry, and a **state** IN THAT DOMAIN'S OWN VOCABULARY saying how
far it has been taken. A single shared ladder was the defect: it let a surface reach for the
strongest-sounding word without holding what the word named — `signed` meant "a named person and a
usable date", and two surfaces awarded it with neither. States are now per-domain, ranking is
within-domain only, and `search()` refuses a hit whose state does not belong to its domain. The state
is computed from each record's live state, never assumed from its surface — a `decision_required`
contract record is `open`, and an `approved` one is `attributed` only if the pack's Gate 2 form
actually names an approver and a date, else `answered_unattributed`. Every render carries the line that nothing returned is an approval, including the renders that
find nothing, which is exactly when a reader is most likely to reuse something half-remembered.

**A coverage claim now resolves to code.** `platform/capabilities.yaml` names, for each of the 22
master families, the config key a pack authors, the Python and R symbols that read it, the columns it
publishes, its stated limits, and its tests. `capability_registry.py` refuses the file unless every
one of those resolves — module defines the symbol (by AST, so CI's pure-Python job can check it
without Spark), R file defines the function, test file defines the test, and the config key is
actually READ by one of the named modules. It refuses the *pair* of files if the registry and the
inventory disagree about which classes a family answers, in either direction.

This is what closed the review's central complaint. `inventory_coverage.py` checked a coverage class
for shape only: a value from the enum and a non-empty `via` sentence. That is how LINE_OF_THERAPY sat
classed `engine_family` while `stages/lot.py` only normalises a table the vendor derived — a wrong
claim that had passed every check in the repository, because every check was reading the claim rather
than the code. **What the registry still does not prove**: that the code is correct, that the named
test is a good test, or that `emits` is complete. `CAPABILITIES.md` says so in its own header.

**The portfolio table is generated.** The root README carried it by hand under the words "status
mirrors registry.yaml (test-enforced)". Nothing enforced it, and six of its eight rows said `planned`
for products the registry had already moved to `scaffold`. `products/PORTFOLIO.md` now derives status
and spec version from the registry, pack and milestones from the filesystem, variable and gap counts
from the reference shelf, and per-variable native/configurable/upstream/gap counts from the
capability registry — and reports where those four DISAGREE. Ten drift findings today: eight template packs being counted as products, two
reference overlays with no registered product. **Drift is reported, never repaired** — a tool that
edited the registry and the shelf into agreement would destroy the evidence that they disagreed.

**Citations carry a strength.** Each citation has one record naming its identifier and the route it
was checked by. *(Counts live in `governance/CURRENT_STATE.md`, which is generated from the register
and byte-compared in CI — four hand-carried figures in this document had already drifted from the
code by the time a seventh review read it, so the numbers moved to where they cannot.)* The routes
are PubMed/publisher, web-search (the mcrc pass could reach neither PubMed nor Crossref), citations
with no resolvable identifier, and in-house. The two per-tumour caveats that
said "a few citations carry journal/volume/page identity without a PMID or DOI" — true, and unusable
— now name all six, and the checker refuses a weak citation that is not named where its variables are
read. Nine are recorded without a confirmed author list, named individually.

**Three things a person alone may write, and all three are empty today.** Each is a place where a
generated value would be a claim nobody made:

| field | what it asserts | count |
|---|---|---|
| `supports:` on a citation | which CLAIM this paper supports, not just which variable lists it | 0 of 281 |
| `provenance.basis: workbook_confirmed` | a named person read the approved workbook and it states this | 0 of 509 |
| a sealed holdout benchmark key | an independent reviewer's questions, sealed before any run scored | none exist |

The counts are printed, not hidden. An AI must not fill any of them: choosing which paper supports
which clause, or asserting that a workbook says something, IS the judgement the field exists to
record. `workbook_confirmed` additionally requires a valid date and a workbook registered at Gate 1
as `<pack>#<material_id>` — this is the path an mcrc entry takes when RWB's workbook arrives.

**A protocol's scope is the BUILD, wherever it pins one.** `request_scope_errors` compared spec
versions only, so a request under a protocol written against one release could read a different cut of
the same specification and pass. A protocol naming only the pack still permits any build —
pre-specification comes *before* the cut — but one that pins a build refuses both a mismatched request
and one naming no build at all. `--scope` answers the question no individual record answers ("which
data did this study read?") and surfaces a failure no per-record check can see: two requests under one
protocol, each individually in scope, reading two different cuts of the same pack.

---

## 1. The goal

Hand this framework to someone who can take it forward — and to do that, show a **working product or
process**, not a pile of tooling. Concretely, three things a successor must be able to see:

1. **The pipeline runs end to end** on a real (stand-in) spec: spec → extraction → contract → config →
   engine build → gates evaluate. **DONE** — `platform/tools/demo.py` walks it in one command (§0), and
   §3 builds an ADS through the production entrypoint. *(This said "nothing strings them into one
   runnable demo", which was true when written and contradicted §0 of this same file.)*
2. **A new tumour is mostly configuration, and the framework helps you write it** — an analyst is handed
   *proposals with reasoning attached*, not a blank pack. Today the framework proposes value-lists and
   refuses to guess the rest, but there is no store of precedent and no guided authoring, so a first-time
   analyst still faces a blank `config/`.
3. **The governance is real, not theatre** — approvals bind to bytes, releases are derived not toggled,
   and nothing reaches production unapproved. The MECHANISM is done and tested (see §3); the
   ENFORCEMENT is not — the gates live in this repository and the repository can be merged past
   while `main` is unprotected and CI is not running (see §8, first item).

The strategic thesis behind it: today an analyst is a *project programmer* re-implementing each product
from a spec. The target is an analyst who is a **block-builder** — assembling a product from reusable
engine blocks and a growing store of precedent, with the machine drafting the mechanical parts and
raising a decision wherever judgment is required.

---

## 2. The vision

**Analysts as block-builders.** The engine is already tumour-agnostic reusable blocks (stages) +
named-formula registries + a codelist DSL, all assembled by per-product config (confirmed in code, §3).
So "adding a tumour" is *mostly authoring config + variables + codelists*, not writing engine code. The
missing half is making that authoring **assisted** rather than blank-page.

**Propose-and-confirm from a precedent store.** Every approved product deposits precedents:
- *decisions* it answered (study window, follow-up-end, cohort-union logic, output-column contract…),
- *domain→table resolutions* it verified against the live warehouse (demographics, SES, practice,
  mortality, vitals, lab — standard across a vendor's tumours),
- its *source mappings* (some reusable, some tumour-specific).

The next product starts by having the **reusable** precedents *proposed for a human to confirm*, and only
answers what is genuinely new. The store is git-versioned, grows with every product, and holds **only the
framework's own governance artifacts (decisions, patterns, which domains exist) — never vendor data**.
This is the "compounding" idea: each product makes the next one cheaper. (Illustrated in the companion
visual: prostate answered 22 decisions from scratch; endometrial would have ~15 proposed and ~9 net-new.)

**What stays human, permanently.** The framework *deliberately refuses* to auto-generate the interpretive
layer — which physical column is the right one, the numeric codes, the terminal fallthrough, the
missing-value codes. That refusal is a feature (it is why a governed gate can be trusted), so the vision
is **assisted authoring + guided validation**, never "spec in, config out."

---

## 3. Where we are today (grounded against the code)

| Layer | State | One-line reading |
|---|---|---|
| **Engine (reusable blocks)** | ✅ built | 9 stages + `BMI/BSA_FORMULAS`, `FOLLOWUP_FILTERS` registries + codelist DSL; `validate.py` imports the same registries/compiler it executes, so validation cannot drift. |
| **Governance gates (1–6)** | 🟡 built, NOT enforced on the branch | Releasability *derived* from Gates 1–4 (no settable flag); deploy tree is an allowlist; scheduling requires `releasable()`. **No pack is releasable and every job is paused** — proven by tests, never yet traversed live. **But every one of these gates is repository-LOCAL and can be merged past**: `main` is unprotected, no review is required, and CI has not executed (see §8). A gate that runs only when someone chooses to run it is a convention, not a control. |
| **AI drafting layer** | ✅ built, deliberately bounded | Proposes spec-stated values + hashes evidence; **refuses** to invent mappings/codes/fallthrough — emits each as a named gap. |
| **Knowledge layer** (§0.5) | ✅ built, and it grades itself | Six surfaces searchable in one pass, every hit carrying what it may SETTLE; every coverage claim resolved to a symbol, config key, column and test; portfolio and citation strength generated rather than typed. Its own verdict on the repository is the useful part: **0 attributed rulings, 0 workbook-confirmed shelf entries, 0 claim-level citations, no independent benchmark** — each a place where only a person can write, and each printed rather than omitted. |
| **Prostate (202606)** | 🟡 furthest along | Full executable config+variables+codelists; 200-item traceable contract (`coverage_complete`); config `draft`. Gate 1 provenance **pending** (no approved workbook); 2 of 23 decisions resolved; 0 records approved. |
| **Ovarian (oc/202606)** | 🟠 scaffold | config+4 variables+codelist authored; contract covers **only** study_period (5 records); 299/360 spec items undispositioned; source is an unapproved reconstruction. |
| **Endometrial (YYYYMM)** | 🔴 seed | Reconstructed, **NOT VERIFIED**; has config/variables/codelists + partial R (~522/~11,650 lines). **Missing** `source_refs.yaml`, `handoff/`, `prog_spec/`, `spec_pipeline/`, `MATURITY.yaml` — passes no gate; version is the literal placeholder `YYYYMM`. |

### The three things that are genuinely done

- **The engine is a block-builder, confirmed.** Stages under `platform/engine/stages/` orchestrated by
  `build_ads.py`; formulas selected by name from registries in `clinical.py`; codelists compiled from a
  DSL (`equals`, `like_any`, `regexp`, `category_equals`, `is_null`, `all_of`, `any_of`, `always`) in
  `codelists.py`. `validate.py` imports those very registries and the same `compile_case`, and a test
  asserts `BMI_METHODS == set(BMI_FORMULAS)` — validation and execution cannot diverge. Adding a genuinely
  new primitive (e.g. a Mosteller BSA formula) is the *only* thing that requires an engine change.
- **The propose/refuse boundary is real, confirmed.** `contract_binding.promote()` emits candidate
  *values* lifted verbatim from the cited spec row, and its docstring refuses the rest by name: "numeric
  codes … fallthrough … missing-value codes, operators, source mappings and output names are judgment,
  and a generator that guessed them would guess silently. It proposes; it never writes into `variables/`."
  The only machine-authored fields are `spec_refs`, `spec_digest`, `required_rule` — citations and hashes,
  refused if a drafter tries to author them.
- **Release governance is derived, not toggled, confirmed.** `releasable()` requires source approved +
  contract approved + configuration approved + maturity clean; `evidence_verdict()` reads it back from
  `RELEASE_EVIDENCE.yaml` and fails closed on commit, tree digest, evidence digest, and `is True`.
  `bundle_products.activation_errors` refuses `schedule_enabled: true` unless `releasable(pack)`.

### The honest gap

Everything is *ready* and nothing has *shipped*: no source is `reviewed`, no contract record is
`approved`, no config is `approved`, so the release path has never run green end-to-end. That is a
**provenance** state (the approved workbooks were never supplied), **not** a capability gap — the pipeline
can be demonstrated today on the stand-in.

**The engine now demonstrably executes.** PySpark was believed unbuildable in this sandbox; what
actually failed was `pip install pyspark` against Debian's patched setuptools
(`AttributeError: install_layout`), since PySpark ships an sdist. A venv with setuptools from PyPI
installs it in one command. `platform/tools/local_smoke.py <pack>` builds any configured product's ADS — for prostate a
**187-column ADS with seven cohort definitions CONFIGURED and four POPULATED by the fixture** through
the production entrypoint on synthetic sources — see `DEMO.md` §3. Synthetic data, real engine, real
config: it proves the configuration assembles and executes, not that any clinical number is right.

Two suites had also never executed anywhere — `test_stages_spark` and `test_smoke_spark` printed
`SKIP` and exited 0, in CI too, so the engine's stage dataflow had never been run by CI at all. They
now pass (26 + 2) in their own CI job that refuses to proceed if the PySpark import fails.

---

## 4. The gap between here and the vision

The three capabilities this section used to list — a runnable demo, a precedent store, a block
catalogue — are all built (§0–§0.3). What remains is smaller, countable, and mostly not code.

**1. 26 engine gaps stand between "config-driven" and "specs are edited, not code."**
163 of prostate/202606's 202 records already point at a config block, and only **two** have behaviour
that lives solely in code. But 63 records are blocked on an engine gap, and the register triages them
**26 engine-side vs 7 config-side** (`handoff/ENGINE_GAPS.md`). The 26 are not 26 features — they
cluster into roughly four capabilities:

| cluster | examples | what it really is |
|---|---|---|
| match operators | `G-STAGE-PREFIX` (longest-prefix), `G-ETHNICITY-OR` | extend `MATCH_OPERATORS` — there are 8 today |
| row selection | `G-BIOMARKER-CLOSEST`, `G-VITALS-DATES`, `G-ECOG` | one concept: window + anchor + tie-break |
| duration/outcome formulas | `G-TTD-PLUS1`, `G-RWPFS`, `G-FUED` | a named-formula registry, like `BMI_FORMULAS` |
| line/setting parameters | `G-ABSENT-LINE` (17 vs null), `G-LOTN-ZERO` | hardcoded **choices**, not missing capability |

Several are literally config decisions frozen in Python. Build those four and a new tumour is
configuration.

**2. The review loop, not the code, is the scaling limit.** 48 of 51 decisions across all packs are
open; three have ever been answered. Every tool that compounds knowledge — the precedent store,
`spec_diff`'s carry-forward — is downstream of decisions being *settled*. The machinery is built and
starved.

**3. A decision carries no attestation.** Every other approval in the framework records who, when,
and a hash of the bytes (`APPROVAL_FIELDS`, `CONTRACT_APPROVAL_FIELDS`,
`AI_EXTRACTION_APPROVAL_FIELDS`). A methodology decision — which changes what the code computes —
records none of them, and its answer column is called "Approved answer". `decision_packet.py` prints
this gap on the page rather than offering a signature box the register cannot store.

---

## 5. The roadmap

Ordered so the *demonstrable* value comes first (Phase 0 is the handover artifact itself), then the
compounding capability, then measurement. Effort is a rough T-shirt estimate, not a commitment.

| # | Deliverable | What it unlocks | Effort |
|---|---|---|---|
| **0** | ✅ **DONE** — `platform/tools/demo.py` (§0) + this `HANDOVER.md` + the visual | A successor can *run* the pipeline and *watch* the gates evaluate — the "working process" to show. | S–M |
| **1** | ✅ **DONE** — `governance/precedents.yaml` + `platform/tools/precedents.py --for <pack>` (§0.1): curated decision precedents *and* derived source-key precedents. | The compounding idea becomes a thing you run, not a diagram. | M |
| **2** | ✅ **DONE** — `platform/tools/blocks.py` (§0.2), plus a registry for the codelist DSL so its errors name the valid operators. | Directly answers "which function do I enter" for a first-time analyst. | M |
| **3** | ✅ **DONE** — `platform/tools/worksheet.py` (§0.3): the three existing answers, in the order the work comes. | Turns the blank `config/` into a checklist with the reasoning attached. | M |
| **4** | ✅ **DONE** — `dry_run.py`, `spec_diff.py`, `decision_packet.py`, `placeholders.py` (§0.4); `GLOSSARY.md`, `DEMO.md`, `REVIEW_BRIEF.md`; the Spark build and CI job | Latent blockers, revision carry-forward, a stakeholder-facing question page, placeholder accounting — and an engine that demonstrably executes. | L |
| **5** | **The four engine generalisations** (§4.1): match operators, row selection, a duration-formula registry, LOT/setting parameters | Closes the 26 engine gaps and makes a new tumour *configuration*. **The highest-value remaining work.** | L |
| **6** | **Attested decisions**: give the decisions register `approved_by` / `approval_date` / a binding to the answer, plus a tool that writes the row so the parser cannot break | Makes a methodology decision as auditable as every other approval, and stops a human being the typist. | M |
| **7** | **Profiler-driven source discovery**: propose candidate source columns from the profile TSV for a human to confirm at Gate 3 (never auto-confirm) | Shrinks the most tedious human step without crossing the judgment boundary. | M–L |
| **8** | **Eval harness on sanitized real examples**: measure drafting accuracy against known-good records | Makes "the skill is good enough to hand over" a measured claim. | M |

Phase 5 is the one that changes the economics; 6 unblocks the compounding loop. 7–8 are optional.
**Neither is worth starting before decisions are being answered** — see §4.2.

---

## 6. What a first-time analyst's day looks like (target state)

1. Drop the approved spec into `prog_spec/`, run the spec pipeline → extraction + coverage + scaffolded
   contract records.
2. The **precedent store proposes** the reusable decisions and domain resolutions from prior products;
   the analyst confirms or overrides each (Phase 1).
3. For each contract record, the analyst opens the **gap worksheet**: value-lists are pre-filled, and the
   *N genuine decisions* are listed with spec citations (Phase 3).
4. When authoring `config/`, **validation errors name the available blocks** — "unknown `bmi_method: x`;
   valid: standard" — so the analyst never has to grep the engine to learn what exists (Phase 2).
5. The gates run and tell them, in plain terms, exactly what is still unapproved.

The point is not that the machine answers for them — it is that they start from **a short list of
proposals with reasoning attached**, and the list gets longer, and the blank part shorter, with every
product that ships.

---

## 7. Honest boundaries (what will not be automated, and why)

- **Config correctness lives in the data, not the spec.** Which physical column is the *right* one needs
  the vendor dictionary and the live warehouse — a human confirms it at Gate 3. The framework proposes
  `pending_mapping` from the spec's own identifiers; it never infers a column from a naming convention.
- **The machine drafts values, humans make decisions.** Codes, fallthrough, missing-value handling,
  operators, output names — the framework refuses to guess these and raises a decision instead. Automating
  them away would defeat the gate that exists to catch a silently-invented value.
- **No auto-approval, ever.** Every green proposal is a *proposal a human confirms*. The six gates are
  unchanged. Nothing in the roadmap flips a maturity level or marks a decision resolved.
- **No vendor data in the precedent store.** Only decisions and their outcomes cross the boundary —
  never patient-level values, vendor prose, profiles, or physical schema.

---

## 8. Open governance items (immediate, independent of the roadmap)

- **RESTORE CI AND PROTECT `main` — everything else in this list is downstream of it.** Three
  external reviews have now found the same thing: GitHub reports `main.protected=false`, the last
  large merge went in with zero reviews minutes after it opened, and every CI job failed before
  running a step because of account billing. That is not red tests; it is no tests. CODEOWNERS
  admits in its own text that it is advisory without branch protection. **Nothing this repository
  can do about it from the inside** — every gate, lint and sweep described in this document runs
  only when somebody chooses to run it. Restore Actions billing, protect `main`, require the checks
  and a second reviewer/Code Owner, dismiss stale approvals, disallow admin bypass, and re-run the
  exact merged SHA. Until then, read every "enforced" in this document as "implemented and tested".
- **Approve the `ai_extraction` records.** NO pack's extraction is currently approved:
  prostate/202606's registration exists but is `status: pending` with no `approved_by`/`approval_date`
  (an earlier signature did not survive later re-extraction — the binding revokes on changed bytes,
  exactly as designed), and oc/202606 has never registered one. A human must review the
  redacted-cell counts, checksum and fingerprint and set `reviewed` with `approved_by`/`approval_date`.
  No tool may do this; it is one of the five human-only fields. *(This paragraph has flipped with
  the tree twice — trust `spec_slice`'s own output over any sentence here.)*

  Until a pack is signed, `spec_slice` refuses to assemble a drafting context and
  `contract_record --item` refuses to supply the spec's own words, so no record on it can be drafted
  or revised through the tools. The refusal names the command, so it is a five-minute human act
  rather than a mystery. The gap it closed: the slicer asked `ai_readable` and the drafter did not, so

      contract_record.py d.yaml --product products/oncology/prostate/202606 --item study_period:18

  returned the specification's own sentence — `Earliest available data through INDEX, inclusive.` —
  from the artifact the slicer had just refused to show. Two doors onto one decision, and the second
  was the one the drafting skill used.
- **Supply an approved workbook (or accept the stand-in explicitly)** to move any pack off Gate-1
  `pending`. Until then no record can reach `requirement: approved` and nothing is releasable.
- **Sign a decision, or accept that the repository holds no precedent.** `knowledge_graph.ruled()`
  requires RESOLVED **plus** a named approver **plus** a valid approval date, and **not one decision
  in any register meets all three**. Three are RESOLVED with both columns blank — prostate's
  STUDY-WINDOW and MAXINDEX, and oc's OC-PSOC-SHEET — and 30 decisions exist in total. They now
  render as "UNVERIFIED RESOLUTION — an answer, not a citable ruling", and
  `precedents.py` grades the whole store 0 `ruling`. This is not a defect to fix in code: a
  resolved-but-unsigned row is genuinely useful (knowing another pack answered your question is real
  value) and it is a signature away from being precedent. The signature is a person's to give.
- **Register a signing key, or accept that no approval here is authenticated.**
  `python3 platform/tools/approval_identity.py` reports the state: **0 registered `person_review`
  keys, 0 of 3 approvals authenticated, 3 baselined as predating the mechanism.** Those are two
  separate problems needing two different acts. (a) `governance/allowed_signers.yaml` is empty
  because registering a key is a person's own act — nothing automated may add an entry, since
  registering a key on somebody's behalf forges the identity the mechanism exists to prove. That is
  a five-minute fix. (b) Every commit that set an approval is unsigned, and **this one cannot be
  fixed at all**: no check applied later turns an unsigned commit into a signed one, so those
  approvals are re-made under signature or they stay what they are. The repository's 32 signed
  commits are all GitHub *merge* commits on the forge's key; registering it would make them verify
  and authenticate nothing, so it is recorded in `known_ineligible` rather than left as an
  unexplained absence. A `person_review` signature still proves only WHO wrote a value, never that
  the value is right.
  **`--check` now fails on any NEW unsupported approval.** The unit is the approval, not the file:
  each one binds to the commit whose diff wrote *that line* (`git log -G`), so an unrelated edit
  elsewhere in a form no longer re-dates every approval in it. Which field carries the approval is
  declared per surface — `approved_by` on a Gate 2 form, not `spec_qc_reviewed_by` beside it — after
  a version that read every `*_by` as an approver and let a QC reviewer's signature authenticate
  somebody else's approval. The three approvals that exist today are grandfathered in
  `governance/approval_baseline.yaml`, keyed on **(file, field, who, commit)**: re-make one and it
  drops out and comes back under the check, and a *new* approval in a baselined file is never
  covered. The tool **prints** that baseline and never writes it — a judge that could write its own
  exemption list is a check that can green itself.
- **Four fields only a person may write, all empty (§0.5).** A citation's `supports:` (0 of 281), a
  shelf entry's `provenance.basis: workbook_confirmed` (0 of 509), a cross-scheme `same_work:` group
  merging a PMID and a DOI into one paper (0 — so the register's 246 is an upper bound on the works,
  not the works), and a sealed holdout benchmark key (none —
  `platform/tools/skill_benchmark.py --holdout-new` scaffolds one, `--seal` seals it before any run
  is scored, and `--score` refuses an unsealed key rather than quoting a number with a caveat). Each
  is printed with its count rather than omitted, because an empty count is the honest reading of the
  shelf's evidentiary strength. None may be AI-authored — deciding which paper supports which clause,
  asserting what a workbook states, resolving two identifiers to one paper, or writing an
  "independent" reviewer's questions is the judgement the field exists to record.
- **~~Reconcile published names with emitted codes~~ — DONE (2026-08-03), and the 92 was an
  artifact.** The comparison was against `validate.emitted_variables`, which returns 153 codes for a
  187-column ADS and excludes the parallel `-n` columns by design — a catalog-completeness helper,
  not a column manifest. Against `products/metadata/catalog.yaml` and scoped by the record's own
  claims (`role: published` + `implementation: implemented` + `name_status: aligned`), the real
  number was **three**, each a different defect, and all three now say `name_status: undecided`,
  which is what is true. `contract_binding.published_name_errors` keeps it that way.
- **Assign endometrial a real `current_spec_version`** (it is the literal string `YYYYMM`) and add the
  missing pack files before it can enter the gates.
- **Fill or raise 86 unaccounted placeholders** — `placeholders.py --all --check`. Forty-nine are in
  prostate/202606: eight cite nothing at all (`DATA_SOURCE` alone carries fifteen empty fields), and
  forty-one cite a decision that is not what they are waiting on. All 17 invariants pass over them: a
  record can be almost entirely empty and satisfy every existing check, because nothing yet claims it
  is finished.
- **Ovarian is split across two directories.** The governed pack holds 5 records against 360 spec
  items; `sandbox/experiments/ovarian_202606_contract_draft` holds **295 records covering all 360**,
  with a QC findings file, outside every gate. No tool can see both halves. `contract_binding` no
  longer asserts "behaviour nobody required" over that pack (it says the conclusion is not
  established), but merging the halves — or deciding not to — is unresolved.
- **Answer decisions.** 48 open, 3 ever resolved. This is not a tooling item and it gates everything
  that compounds: `spec_diff` now carries a settled answer to the next revision automatically, so an
  answer given today stops being re-argued. Before that existed, answering had no leverage.

### History was rewritten on 2026-08-02 — re-clone, do not pull

History was rewritten to remove **183 paths** that `repo_hygiene.py` now refuses: exported source
documents, vendor data dictionaries and documentation captures, duplicate workbooks at unregistered
paths, decks, and a whole-repo transfer snapshot. The repository went from **502 MB to 6 MB**.

**Any clone made before that date must be re-cloned.** A `git pull` into an old clone reintroduces
every removed document, because the old objects are still in that clone and pulling merges the two
histories.

Why it was necessary rather than tidy: those documents had been deleted from the working tree months
earlier and `repo_hygiene --check` was green, because it reads the git INDEX. They remained
retrievable by `git show` from every clone the entire time. `main` and this branch both had clean
*trees* — the exposure was history, plus five stale feature branches that still carried between 1 and
36 of the documents in their live trees. "Those documents are not in this repository" was a sentence
nothing re-derived until now.

What preserves the claim: `repo_hygiene.py --history --check`, wired into CI ahead of everything
else, with `fetch-depth: 0` on the checkout because the step refuses a shallow clone rather than
scanning one commit and calling it clean. A re-added document that someone later deletes leaves the
index green and turns that step red.

Nothing else moved. The two branches that held no refused files have byte-identical trees before and
after; every branch that changed changed only by document deletions; and all 30 commits `filter-repo`
dropped as empty touched purged documents and nothing else. A pre-rewrite mirror was taken but lives
only in this session's scratch directory — it is **not** a durable backup.

---

## 9. Pointers

**If you are taking this over, read in this order:** `GLOSSARY.md` (the words — half framework, half
oncology, and nothing distinguishes them on sight) → `DEMO.md` (run it) → this file → `docs/ENGINEERING.md`.

| document | what it is for |
|---|---|
| `GLOSSARY.md` | every term, pointing at the code that owns it. Self-checking — a renamed function fails a test rather than leaving a dead pointer. |
| `DEMO.md` | the run sheet: what to say, what to run, the questions you will get, the boundaries to state first. Every command was executed before it was written down. |
| `REVIEW_BRIEF.md` | hand this to a reviewer. States the system in domain-neutral terms and points five engineering questions at exact code. No clinician needed. |
| `docs/ENGINEERING.md` | the rules that are expensive to get wrong, chiefly "never a second implementation". |
| `docs/CHAT_JOURNEY.md` | how the repository is OPERATED from chat — the five skills, and what to type. Nothing here bypasses a gate. |
| `docs/PRODUCTION_READINESS.md` | what "production ready" means concretely, and the plan to it, from a four-angle stress round. |
| `governance/CURRENT_STATE.md` | **generated** — every count this framework can compute about itself. Prose points here rather than restating a figure. |

- **Start here**: `python3 platform/tools/demo.py` — the walkthrough (§0), and the fastest way to see
  what the framework does before reading a line of it.
- **Framework orientation**: `README.md`, `governance/WORKFLOW.md` (the six gates).
- **Engine blocks**: `platform/engine/stages/`, `platform/engine/codelists.py`,
  `platform/engine/validate.py`.
- **Drafting layer**: `.claude/skills/draft-contract-record/SKILL.md`,
  `platform/tools/contract_binding.py` (`promote`), `platform/tools/contract_scaffold.py`.
- **Gates/deploy/release**: `platform/tools/product_gates.py`, `source_manifest.py`, `deploy_tree.py`,
  `bundle_products.py`, `repo_hygiene.py`.
- **Approver identity**: `platform/tools/approval_identity.py` + `governance/allowed_signers.yaml`
  + `governance/approval_baseline.yaml` — who signed the commit whose diff wrote each approval.
  Reports **0 registered keys, 0 of 3 approvals authenticated, 3 baselined** today, which is the
  true state; see `governance/APPROVAL_IDENTITY.md`.
- **Knowledge layer** (§0.5): `platform/tools/knowledge_search.py` (ask everything at once),
  `capability_registry.py` + `platform/capabilities.yaml` (what a coverage claim resolves to),
  `portfolio_status.py`, `citation_register.py`, `knowledge_graph.py`, `precedents.py`.
- **A revised workbook moved rows — what is now unverified**:
  `platform/tools/change_impact.py <pack> clinical:12 …` walks specification row → contract record
  → config block → capability → published column → the goldens that must be re-run. Read-only, and
  it reports REACH rather than risk: what the change touches, so "we re-ran everything affected"
  is checkable instead of recalled. A row NO record cites is reported as a finding, because
  "unimplemented" and "citation missing" both look like "no impact" in a report that prints
  nothing. Pairs with `spec_diff.py`, which tells you WHICH rows moved.
- **How big is the plan this pack builds**: `platform/tools/plan_size.py <pack> --scale` —
  the ANALYZED plan, per cohort count. Prostate measures **54,377 nodes / 22.6M characters at 7
  cohorts**, growing 2.6x per cohort between 1 and 7 because each cohort embeds a COMPLETE copy of
  the stage pipeline before the union. Measured before proposing any redesign, and it killed the
  obvious one: de-duplicating `lot.normalized` (40 calls, 3 distinct frames) leaves the plan
  UNCHANGED, because a Spark plan is a tree and handing one DataFrame to two parents embeds the
  subtree twice. Only building the cohorts as one frame changes the shape.
- **What stands behind each config block**: `platform/tools/config_propose.py <pack>` —
  confirmed / changed / unresolved / unsupported, per governed block, with the specification rows.
  `confirmed` means the workbook reached the block; Gate 4 decides whether the values are right.
- **Does the drafting skill raise what an SME raises**: `platform/tools/skill_benchmark.py` —
  `--build` derives an answer key from a pack's own register (so it measures agreement with that
  register, and says so), `--holdout-new` / `--seal` set up the independent key that would measure
  recall, and `--score` reports ROW-OVERLAP SCREENING COVERAGE as a range. Read its docstring before
  quoting any number from it: the matching is by affected specification row, not by question.
- **Most-complete product to demo from**: `products/oncology/prostate/202606/`.
- **Companion visual**: <https://claude.ai/code/artifact/c17bbfde-8642-4f49-855a-38feb715e1c8>
