# R (sparklyr / dbplyr) mirror of engine/stages/*.py — the SECOND engine, for cross-validation.
#
# ============================ PARITY CONTRACT (read me) ============================
# The two engines share the SAME config/YAML. ALL config-driven business logic (the treatment
# codelist + every banding/mapping/stage CASE) is compiled by the SHARED, PROVEN helpers sourced
# below (codelists.R + cases.R), which tests/test_r_parity.py shows emit byte-identical Spark SQL to
# the Python engine. So the "codes" the R team reviews here ARE the same expressions PySpark runs.
#
# This file is the Spark ORCHESTRATION (reads / joins / windows / writes) around those expressions,
# written in the team's native sparklyr/dbplyr idiom (the original RWDP was R/dbplyr). It needs a
# Spark connection (sparklyr) + the `yaml` package, neither of which installs in the offline
# authoring sandbox, so it is REVIEW-ONLY here. ACCEPTANCE GATE: run it on Databricks and
# golden-compare the R ADS against the Python ADS (engine/golden.py) before relying on it.
# Where the Python stage builds an inline SQL string (clinical death/OS imputation, ECOG code map,
# BMI), the same string is built here line-for-line so a reviewer can diff R vs Python directly.
# ===================================================================================
#
# Load order (the caller — run_rwdp.R / tests — sources these first):
#   source("vendors.R"); source("vocabularies.R"); source("config.R"); source("codelists.R")
#   source("cases.R"); source("stages.R")

suppressPackageStartupMessages({
  # dplyr/dbplyr verbs + sparklyr are resolved at RUN time on the cluster (lazy: referenced only
  # inside functions), so sourcing this file in a plain R session does not require them.
})

# %>% comes from dplyr/magrittr on the cluster; bind it here too if present (no-op otherwise — the
# function bodies resolve %>% at call time once library(dplyr) is on the search path).
if (requireNamespace("magrittr", quietly = TRUE)) `%>%` <- magrittr::`%>%`

# --- sources: load ONLY declared tables, lower-case columns, derive advanceddiagnosisdate --------
# Mirrors engine/stages/sources.py::load.
load_sources <- function(sc, cfg) {
  srcs <- cfg_sources(cfg)
  union <- cfg_source_union(cfg)
  out <- list()
  for (name in names(srcs)) {
    if (!is.null(union)) {                                  # EC: read each source from every member
      disc <- union[["discriminator"]] %||% "db"           # schema, tag db=EDM/DOS, union_all (== union_func)
      parts <- lapply(union[["members"]], function(m)
        dplyr::mutate(dplyr::tbl(sc, cfg_table_in(cfg, name, m[["schema"]])), !!disc := m[["flag"]]))
      # sdf_bind_rows aligns by NAME and fills missing columns with typed NA == Python
      # unionByName(allowMissingColumns=True); plain union_all would fail/diverge on a member whose
      # column set differs (the registry vs EDM case Python was made tolerant of).
      df <- Reduce(function(a, b) sparklyr::sdf_bind_rows(a, b), parts)
    } else {
      df <- dplyr::tbl(sc, cfg_table(cfg, name))            # vendor-resolved FQN (config.R)
    }
    df <- dplyr::rename_with(df, tolower)                   # R: rename_with(tolower)
    ren <- cfg_source_renames(cfg)[[name]] %||% list()      # per-format column renames (Panoramic -> logical)
    for (phys in names(ren)) {
      p <- tolower(phys); lo <- tolower(ren[[phys]])
      if (p %in% colnames(df) && p != lo) df <- dplyr::rename(df, !!lo := !!rlang::sym(p))
    }
    out[[name]] <- df
  }
  # Materialize each index_dates model as a column on the index source (key without underscores;
  # advanced_diagnosis_date -> advanceddiagnosisdate). A dual-setting product adds hspc/crpc models so
  # each overall cohort indexes off its setting's date. Only where the rule's columns exist. == sources.py.
  isrc <- cfg_index_source(cfg)
  if (!is.null(out[[isrc]])) {
    for (key in names(cfg$raw[["index_dates"]] %||% list())) {
      rule <- cfg$raw[["index_dates"]][[key]]
      if (!is.list(rule)) next
      of <- tolower(unlist(rule[["of"]] %||% list()))
      present <- of[of %in% colnames(out[[isrc]])]
      if (length(present) == 0) next
      expr <- if ((rule[["method"]] %||% "max") == "max")
        sprintf("greatest(%s)", paste(present, collapse = ", ")) else present[1]
      out[[isrc]] <- dplyr::mutate(out[[isrc]], !!gsub("_", "", key) := dplyr::sql(expr))
    }
  }
  out
}

# --- lot: the single source of new_lot_n. Mirrors engine/stages/lot.py (config-driven model). ----
lot_normalized <- function(src, line_setting = NULL, exclude_settings = list(), maintenance = NULL,
                           line_number_col = "new_lot_n", maintenance_column = "ismaintenancetherapy") {
  lot <- dplyr::mutate(src[["lot"]], linename = dplyr::sql("lower(linename)"))
  cols <- colnames(lot)
  if (!is.null(line_setting) && "linesetting" %in% cols)
    lot <- dplyr::filter(lot, linesetting == line_setting)
  if (length(exclude_settings) > 0 && "linesetting" %in% cols)
    lot <- dplyr::filter(lot, !(linesetting %in% unlist(exclude_settings)))
  if (!is.null(maintenance) && maintenance_column %in% cols)
    lot <- dplyr::filter(lot, dplyr::sql(sprintf("%s = '%s'", maintenance_column,
                                                 if (isTRUE(maintenance)) "True" else "False")))
  if (identical(line_number_col, "linenumber"))
    return(dplyr::mutate(lot, new_lot_n = linenumber))      # OC/EC: raw LOT line number
  # Default (prostate): derive new_lot_n; deterministic tie-break (== PySpark Window orderBy).
  lot %>%
    dplyr::group_by(patientid) %>%
    dbplyr::window_order(startdate, linenumber, enddate, linename) %>%
    dplyr::mutate(new_lot_n = dplyr::row_number()) %>%
    dplyr::ungroup()
}

# --- index: overall = advanceddiagnosisdate in window; lotN = line-N start. engine/stages/index.py -
index_build <- function(src, cfg, cohort) {
  start <- cfg$raw[["study"]][["index_start"]]
  end   <- cfg$raw[["study"]][["index_end"]]
  enh   <- src[[cfg_index_source(cfg)]]
  in_window <- function(df, col)
    dplyr::filter(df, dplyr::sql(sprintf("%s >= date('%s') AND %s <= date('%s')", col, start, col, end)))

  if (is.null(cohort[["lot_number"]])) {            # overall = any cohort without a lot_number; it
    dcol <- gsub("_", "", cohort[["index"]] %||% "advanced_diagnosis_date")   # indexes off its model col
    return(enh %>%
      in_window(dcol) %>%
      dplyr::transmute(patientid,
                       index_date = dplyr::sql(sprintf("cast(%s as date)", dcol)),
                       advanceddiagnosisdate = dplyr::sql(dcol)) %>%
      dplyr::distinct())
  }
  lot_number <- cohort[["lot_number"]]
  lot_norm <- lot_normalized(src, cohort[["line_setting"]] %||% cfg_lot_line_setting(cfg),
                             exclude_settings   = cfg_lot_exclude_settings(cfg),
                             maintenance        = cohort[["maintenance"]],
                             line_number_col    = cfg_lot_line_number_col(cfg),
                             maintenance_column = cfg_lot_maintenance_column(cfg)) %>%
    in_window("startdate") %>%
    dplyr::filter(new_lot_n == lot_number) %>%
    dplyr::select(patientid, linename, linenumber, startdate, enddate, new_lot_n)
  dcol <- gsub("_", "", cohort[["diag"]] %||% "advanced_diagnosis_date")   # setting diagnosis anchor
  enh_index <- enh %>% in_window(dcol) %>%
    dplyr::transmute(patientid, advanceddiagnosisdate = dplyr::sql(dcol))
  dplyr::inner_join(lot_norm, enh_index, by = "patientid") %>%
    dplyr::mutate(index_date = dplyr::sql("cast(startdate as date)")) %>%
    dplyr::select(patientid, index_date, advanceddiagnosisdate,
                  linenumber, linename, startdate, enddate, new_lot_n) %>%
    dplyr::distinct()
}

# --- demographics: age band + region/race/eth/practice/SES. engine/stages/demographics.py --------
demographics_build <- function(src, idx, cfg) {
  dem <- cfg_pack(cfg, "demographics")
  df <- dplyr::left_join(dplyr::select(idx, patientid, index_date),
                         src[["demographics"]], by = "patientid")
  if (!is.null(src[["ses"]]))      df <- dplyr::left_join(df, src[["ses"]], by = "patientid")
  if (!is.null(src[["practice"]])) {
    agg <- src[["practice"]] %>% dplyr::group_by(patientid) %>%
      dplyr::summarise(practicetype_agg =
        dplyr::sql("concat_ws(',', sort_array(collect_set(upper(practicetype))))")) %>%
      dplyr::ungroup()
    df <- dplyr::left_join(df, agg, by = "patientid")
  }
  df <- df %>%
    dplyr::mutate(year_index = dplyr::sql("year(index_date)"),
                  age = dplyr::sql("year(index_date) - cast(birthyear as int)")) %>%
    dplyr::mutate(
      agegrl  = dplyr::sql(bands_case(dem[["age_bands"]], "age", "label")),
      agegrln = dplyr::sql(bands_case(dem[["age_bands"]], "age", "code")),
      race    = dplyr::sql(map_case(dem[["race_map"]], "race", "label")),
      racen   = dplyr::sql(map_case(dem[["race_map"]], "race", "code")),
      eth     = dplyr::sql(map_case(dem[["ethnicity_map"]], "ethnicity", "label")),
      ethn    = dplyr::sql(map_case(dem[["ethnicity_map"]], "ethnicity", "code")),
      regionl = dplyr::sql(region_case(dem[["regions"]], "state", "label")),
      regionln= dplyr::sql(region_case(dem[["regions"]], "state", "code")))
  keep <- c("patientid", "index_date", "age", "agegrl", "agegrln", "race", "racen",
            "eth", "ethn", "regionl", "regionln")
  if (!is.null(src[["practice"]])) {
    df <- df %>% dplyr::mutate(
      practic  = dplyr::sql(map_case(dem[["practice_map"]], "practicetype_agg", "label")),
      practicn = dplyr::sql(map_case(dem[["practice_map"]], "practicetype_agg", "code")))
    keep <- c(keep, "practic", "practicn")
  }
  ses <- dem[["ses"]] %||% list()
  if (!is.null(ses[["source_column"]]) && !is.null(src[["ses"]])) {   # need the ses SOURCE, not just config
    df <- dplyr::mutate(df, ses = dplyr::sql(sprintf("coalesce(cast(%s as string), %s)",
      ses[["source_column"]], .q(ses[["missing_label"]] %||% "Missing"))))
    keep <- c(keep, "ses")
  }
  dplyr::select(df, dplyr::all_of(keep))
}

# --- clinical: baseline ECOG. engine/stages/clinical.py::baseline_ecog --------------------------
clinical_baseline_ecog <- function(src, idx, ecog_cfg) {
  lo <- ecog_cfg[["window_days"]][[1]]; hi <- ecog_cfg[["window_days"]][[2]]
  miss <- ecog_cfg[["missing_label"]]; miss_code <- ecog_cfg[["missing_code"]]
  # present null/Unknown -> 'Unknown' (NOT 'Missing'); numeric path RLIKE-guarded (== clinical.py).
  label <- paste0(
    "CASE WHEN ecogvalue IS NULL THEN 'Unknown' ",
    "WHEN lower(trim(cast(ecogvalue as string))) = 'unknown' THEN 'Unknown' ",
    "WHEN cast(ecogvalue as string) rlike '^[0-9]+([.]0+)?$' ",
    "  THEN cast(cast(cast(ecogvalue as double) as int) as string) ",
    "ELSE 'Unknown' END")
  pulled <- dplyr::select(idx, patientid, index_date) %>%
    dplyr::inner_join(dplyr::select(src[["baseline_ecog"]], patientid, ecogdate, ecogvalue),
                      by = "patientid") %>%
    dplyr::filter(dplyr::sql(sprintf(
      "ecogdate >= date_add(index_date, %s) AND ecogdate <= date_add(index_date, %s)", lo, hi))) %>%
    dplyr::mutate(gap = dplyr::sql("abs(datediff(ecogdate, index_date))")) %>%
    # 6-step final tie-break: worst (max) ECOG wins a same-gap+same-date tie; Unknown ranks last.
    dplyr::mutate(`_rank` = dplyr::sql(paste0(
      "CASE WHEN cast(ecogvalue as string) rlike '^[0-9]+([.]0+)?$' ",
      "THEN cast(cast(ecogvalue as double) as int) ELSE -1 END")))
  nearest <- pulled %>% dplyr::group_by(patientid, index_date)
  nearest <- if (identical(ecog_cfg[["tie_break"]], "latest_date"))   # date direction among same-gap
    dbplyr::window_order(nearest, gap, dplyr::desc(ecogdate), dplyr::desc(`_rank`))
  else dbplyr::window_order(nearest, gap, ecogdate, dplyr::desc(`_rank`))
  nearest <- nearest %>%
    dplyr::mutate(rn = dplyr::row_number()) %>%
    dplyr::ungroup() %>%
    dplyr::filter(rn == 1) %>%
    dplyr::mutate(ecog = dplyr::sql(label)) %>%
    dplyr::select(patientid, index_date, ecog)
  code_when <- paste(vapply(names(ecog_cfg[["value_codes"]]),
    function(k) sprintf("WHEN ecog = %s THEN %s", .q(k), ecog_cfg[["value_codes"]][[k]]), ""),
    collapse = " ")
  dplyr::select(idx, patientid, index_date) %>%
    dplyr::left_join(nearest, by = c("patientid", "index_date")) %>%
    dplyr::mutate(ecog  = dplyr::sql(sprintf("coalesce(ecog, %s)", .q(miss))),
                  ecogn = dplyr::sql(sprintf("CASE %s ELSE %s END", code_when, miss_code))) %>%
    dplyr::select(patientid, index_date, ecog, ecogn)
}

# --- clinical: config-driven enhanced pass-through + presence flags. == clinical.py::_passthrough --
clinical_passthrough <- function(src, idx, blk, index_source) {
  isrc <- src[[blk[["source"]] %||% index_source]]
  if (is.null(isrc)) return(NULL)
  ec <- colnames(isrc)
  cols  <- Filter(function(c) c[["column"]] %in% ec, blk[["columns"]] %||% list())
  flags <- Filter(function(f) f[["from"]] %in% ec, blk[["flags"]] %||% list())
  if (length(cols) == 0 && length(flags) == 0) return(NULL)
  raw <- unique(c(vapply(cols, function(c) c[["column"]], ""), vapply(flags, function(f) f[["from"]], "")))
  e <- isrc %>% dplyr::select(patientid, dplyr::all_of(raw)) %>% dplyr::distinct(patientid, .keep_all = TRUE)
  out <- idx %>% dplyr::select(patientid, index_date) %>% dplyr::left_join(e, by = "patientid")
  keep <- c("patientid", "index_date")
  for (c in cols) {
    nm <- c[["as"]] %||% c[["column"]]
    if (!is.null(c[["bands"]])) {              # categorize a numeric enhanced column (e.g. Gleason score)
      out <- out %>% dplyr::mutate(
        !!nm := dplyr::sql(num_bands_case(c[["bands"]], c[["column"]], "label")),
        !!paste0(nm, "n") := dplyr::sql(num_bands_case(c[["bands"]], c[["column"]], "code")))
      keep <- c(keep, nm, paste0(nm, "n"))
    } else {
      out <- out %>% dplyr::mutate(!!nm := !!rlang::sym(c[["column"]]))
      keep <- c(keep, nm)
    }
  }
  for (f in flags) { out <- out %>% dplyr::mutate(!!f[["name"]] := dplyr::sql(presence_flag_sql(f))); keep <- c(keep, f[["name"]]) }
  dplyr::select(out, dplyr::all_of(keep))
}

# --- clinical: derived durations (months/days between dated milestones). == clinical.py::_durations ----
clinical_durations <- function(src, idx, blk, index_source) {
  isrc <- src[[blk[["source"]] %||% index_source]]
  if (is.null(isrc)) return(NULL)
  dpm <- as.numeric(blk[["days_per_month"]] %||% 30.4375); ec <- colnames(isrc)
  avail <- function(c) identical(c, "index_date") || c %in% ec
  items <- Filter(function(it) avail(it[["from"]]) && avail(it[["to"]]), blk[["items"]] %||% list())
  if (length(items) == 0) return(NULL)
  cols <- setdiff(unique(unlist(lapply(items, function(it) c(it[["from"]], it[["to"]])))), "index_date")
  e <- isrc %>% dplyr::select(patientid, dplyr::all_of(cols)) %>% dplyr::distinct(patientid, .keep_all = TRUE)
  out <- idx %>% dplyr::select(patientid, index_date) %>% dplyr::left_join(e, by = "patientid")
  for (it in items) {
    days <- sprintf("datediff(%s, %s)", it[["to"]], it[["from"]])
    out <- out %>% dplyr::mutate(!!it[["name"]] := dplyr::sql(
      if (identical(it[["unit"]], "days")) days else sprintf("(%s)/%s", days, dpm)))
  }
  dplyr::select(out, patientid, index_date, dplyr::all_of(vapply(items, function(it) it[["name"]], "")))
}

# --- clinical: data-availability floor (minavaildate/basedur). == clinical.py::_min_avail_date -----
clinical_min_avail_date <- function(src, idx, blk, index_source) {
  parts <- idx %>% dplyr::select(patientid, index_date); cols <- c()
  isrc <- src[[index_source]]
  for (bc in (blk[["base_columns"]] %||% list())) {
    if (!is.null(isrc) && bc %in% colnames(isrc)) {
      nm <- paste0("_b_", bc)
      b <- isrc %>% dplyr::transmute(patientid, !!nm := !!rlang::sym(bc)) %>% dplyr::distinct(patientid, .keep_all = TRUE)
      parts <- dplyr::left_join(parts, b, by = "patientid"); cols <- c(cols, nm)
    }
  }
  srcs <- blk[["sources"]] %||% list()
  for (i in seq_along(srcs)) {
    s <- srcs[[i]]; sd <- src[[s[["source"]]]]
    if (is.null(sd)) next
    dcs <- Filter(function(d) !is.null(d) && d %in% colnames(sd),
                  s[["date_columns"]] %||% list(s[["date_column"]]))
    if (length(dcs) == 0) next
    row_date <- if (length(dcs) > 1) sprintf("least(%s)", paste(unlist(dcs), collapse = ", ")) else dcs[[1]]
    nm <- paste0("_f", i)
    agg <- sd %>% dplyr::group_by(patientid) %>%
      dplyr::summarise(!!nm := dplyr::sql(sprintf("min(%s)", row_date)), .groups = "drop")
    parts <- dplyr::left_join(parts, agg, by = "patientid"); cols <- c(cols, nm)
  }
  if (length(cols) == 0) return(NULL)
  parts %>%
    dplyr::mutate(minavaildate = dplyr::sql(sprintf("least(%s)", paste(cols, collapse = ", "))),
                  basedur = dplyr::sql("datediff(index_date, minavaildate)")) %>%
    dplyr::select(patientid, index_date, minavaildate, basedur)
}

# --- clinical: OC surgery sub-block. == engine/stages/clinical.py::_surgery -----------------------
clinical_surgery <- function(src, idx, scfg) {
  enh <- src[[scfg[["source"]]]]; lot <- src[[scfg[["line_source"]] %||% "lot"]]
  if (is.null(enh) || is.null(lot)) return(NULL)
  fl <- scfg[["surgery_flag_column"]]; dt <- scfg[["surgery_date_column"]]
  init <- scfg[["init_date_column"]] %||% "diagnosisdate"; size <- scfg[["size_column"]]
  ecols <- Filter(function(c) !is.null(c) && c %in% colnames(enh), c("patientid", fl, dt, init, size))
  first_per_patient <- function(df, order_col) {        # one deterministic row/patient (== _first in py)
    df %>% dplyr::group_by(patientid) %>% dbplyr::window_order(!!rlang::sym(order_col)) %>%
      dplyr::mutate(`_rn` = dplyr::row_number()) %>% dplyr::ungroup() %>%
      dplyr::filter(`_rn` == 1) %>% dplyr::select(-`_rn`)
  }
  e <- first_per_patient(enh %>% dplyr::select(dplyr::all_of(ecols)), dt)
  l1 <- lot %>% dplyr::filter(!!rlang::sym(scfg[["line_number_column"]] %||% "linenumber") == 1)
  mnt <- scfg[["maintenance_column"]]
  if (!is.null(mnt) && mnt %in% colnames(lot))
    l1 <- l1 %>% dplyr::filter(dplyr::sql(sprintf("lower(cast(%s as string)) != 'true'", mnt)))
  l1 <- first_per_patient(
    l1 %>% dplyr::transmute(patientid, `_line1_start` = !!rlang::sym(scfg[["line_start_column"]]),
                            `_line1_end` = !!rlang::sym(scfg[["line_end_column"]])), "_line1_start")
  j <- idx %>% dplyr::select(patientid, index_date) %>%
    dplyr::left_join(e, by = "patientid") %>% dplyr::left_join(l1, by = "patientid")
  sql <- surgery_sql(scfg)
  j <- j %>% dplyr::mutate(issurg = dplyr::sql(sql$issurg), surg = dplyr::sql(sql$surg),
                           surgn = dplyr::sql(sql$surgn), neoadj = dplyr::sql(sql$neoadj))
  keep <- c("patientid", "index_date", "issurg", "surg", "surgn", "neoadj")
  if (init %in% colnames(j)) {
    j <- j %>% dplyr::mutate(tt_first_tx_diag = dplyr::sql(
      sprintf("datediff(least(%s, _line1_start), %s)", dt, init)))
    keep <- c(keep, "tt_first_tx_diag")
  }
  if (!is.null(size) && size %in% colnames(j)) keep <- c(keep, size)
  dplyr::select(j, dplyr::all_of(keep))
}

# Named body-composition formulas — mirrors engine/stages/clinical.py BMI_FORMULAS / BSA_FORMULAS.
# Config `vitals.bmi_method` / `vitals.bsa_method` NAME one; the engine resolves and compiles it (config
# never carries the raw formula). height in cm, weight in kg.
BMI_FORMULAS <- list(
  standard = "weight / pow(height/100, 2)"                             # WHO: kg / m^2
)
BSA_FORMULAS <- list(
  dubois = "0.007184 * pow(height, 0.725) * pow(weight, 0.425)"        # Du Bois & Du Bois (1916)
  # (Mosteller etc. are added here when an approved product asks for them — not kept speculatively.)
)

# Named follow-up row filters — mirrors engine/stages/clinical.py FOLLOWUP_FILTERS: name -> predicate SQL.
FOLLOWUP_FILTERS <- list(
  valid_oral_end = "(startdategranularity <> 'Year' OR startdategranularity IS NULL) AND enddate IS NOT NULL"
)

resolve_formula <- function(registry, name, kind) {
  key <- as.character(name)
  if (is.null(registry[[key]]))
    stop(sprintf("unknown %s method '%s'; valid: %s", kind, key, paste(names(registry), collapse = ", ")))
  registry[[key]]
}

resolve_followup_filter <- function(s) {
  fm <- s[["filter_method"]]
  if (!is.null(fm)) {
    if (is.null(FOLLOWUP_FILTERS[[fm]]))
      stop(sprintf("unknown follow_up filter_method '%s'; valid: %s", fm,
                   paste(names(FOLLOWUP_FILTERS), collapse = ", ")))
    return(FOLLOWUP_FILTERS[[fm]])
  }
  s[["filter"]]
}

# --- clinical: baseline BMI from vitals. engine/stages/clinical.py::vitals ----------------------
clinical_vitals <- function(src, idx, vcfg) {
  ht <- toupper(vcfg[["height_test"]]); wt <- toupper(vcfg[["weight_test"]])
  base <- dplyr::select(idx, patientid, index_date)
  pull <- base %>%
    dplyr::inner_join(src[["vitals"]], by = "patientid") %>%
    dplyr::mutate(test_u = dplyr::sql("upper(test)")) %>%
    dplyr::filter(dplyr::sql(sprintf(paste0(
      "(((test_u = %s AND testunitscleaned = 'cm') OR ",
      "  (test_u = %s AND testunitscleaned = 'kg')) AND testresultcleaned > 0)"),
      .q(ht), .q(wt)))) %>%
    dplyr::mutate(vitaldate = dplyr::sql("greatest(testdate, resultdate)")) %>%
    dplyr::filter(dplyr::sql("vitaldate <= index_date"))
  closest <- pull %>%
    dplyr::group_by(patientid, index_date, test_u) %>%
    dbplyr::window_order(dplyr::desc(vitaldate)) %>%
    dplyr::mutate(rn = dplyr::row_number()) %>%
    dplyr::ungroup() %>% dplyr::filter(rn == 1)
  h <- closest %>% dplyr::filter(dplyr::sql(sprintf("test_u = %s", .q(ht)))) %>%
    dplyr::transmute(patientid, index_date, height = testresultcleaned)
  g <- closest %>% dplyr::filter(dplyr::sql(sprintf("test_u = %s", .q(wt)))) %>%
    dplyr::transmute(patientid, index_date, weight = testresultcleaned)
  # null / empty / missing all resolve to 'standard' (matches Python `or "standard"`); the validator
  # separately requires an explicit method when vitals is configured.
  bmi_m <- vcfg[["bmi_method"]]
  if (is.null(bmi_m) || !nzchar(as.character(bmi_m))) bmi_m <- "standard"
  bmi_expr <- resolve_formula(BMI_FORMULAS, bmi_m, "bmi")
  out <- base %>%
    dplyr::left_join(h, by = c("patientid", "index_date")) %>%
    dplyr::left_join(g, by = c("patientid", "index_date")) %>%
    dplyr::mutate(bmi = dplyr::sql(paste0(
      "CASE WHEN weight IS NOT NULL AND height > 0 THEN ", bmi_expr, " ELSE NULL END")),
      bmigrl  = dplyr::sql(num_bands_case(vcfg[["bmi_bands"]], "bmi", "label")),
      bmigrln = dplyr::sql(num_bands_case(vcfg[["bmi_bands"]], "bmi", "code")))
  keep <- c("patientid", "index_date", "height", "weight", "bmi", "bmigrl", "bmigrln")
  # BSA emitted only when a method is named. Back-compat: a legacy truthy `bsa_formula` -> Du Bois.
  bsa_method <- vcfg[["bsa_method"]] %||% (if (!is.null(vcfg[["bsa_formula"]])) "dubois" else NULL)
  if (!is.null(bsa_method)) {
    bsa_expr <- resolve_formula(BSA_FORMULAS, bsa_method, "bsa")
    out <- dplyr::mutate(out, bsa = dplyr::sql(paste0(
      "CASE WHEN weight IS NOT NULL AND height > 0 THEN ", bsa_expr, " ELSE NULL END")))
    keep <- c(keep, "bsa")
  }
  dplyr::select(out, dplyr::all_of(keep))
}

DEATH_CONFLICT_POLICIES <- c("most_specific_then_earliest", "earliest", "latest")

FOLLOWUP_SOURCES <- list(
  list("visit",    "visitdate",          "last_visitdate",     NULL),
  list("telemed",  "visitdate",          "last_televisitdate", NULL),
  list("lot",      "enddate",            "last_lotenddate",    NULL),
  list("orals",    "enddate",            "last_oralenddate", FOLLOWUP_FILTERS[["valid_oral_end"]]),
  list("alphabet", "administrationdate", "last_alphadate",     NULL),
  list("provenge", "startdate",          "last_provdate",      NULL)
)

# --- clinical: follow-up-end / death anchors. engine/stages/clinical.py::follow_up_and_death -----
# REVIEW-ONLY (intricate; was mid-revision in the original R). The death-imputation / OS-anchor SQL
# below mirrors clinical.py line-for-line; golden-compare dthdt/dthfl/fued/os before relying on it.
clinical_follow_up_and_death <- function(src, idx, clin_cfg) {
  imp <- clin_cfg[["death_date_imputation"]]
  month_day  <- as.integer(imp[["month_level_day"]])
  year_md    <- as.character(imp[["year_level_monthday"]])
  year_late  <- as.character(imp[["year_level_late_monthday"]] %||% year_md)
  year_month <- as.integer(strsplit(year_md, "-", fixed = TRUE)[[1]][1])
  conflict   <- as.character(imp[["conflict_resolution"]] %||% DEATH_CONFLICT_POLICIES[1])
  dth_window <- as.integer(imp[["death_followup_window_days"]])

  # Resolve the follow-up source spec (config override or the present-only default set).
  spec <- imp[["follow_up_sources"]]
  if (!is.null(spec) && is.list(spec[[1]])) {
    fu_spec <- lapply(spec, function(s) list(s[["source"]], s[["date_column"]],
      s[["alias"]] %||% paste0("last_", s[["source"]], "date"), resolve_followup_filter(s)))
  } else {
    fu_spec <- FOLLOWUP_SOURCES
    if (!is.null(spec)) fu_spec <- Filter(function(t) t[[1]] %in% unlist(spec), FOLLOWUP_SOURCES)
  }

  fu <- dplyr::select(idx, patientid, index_date)
  added <- character(0)
  for (t in fu_spec) {
    srcname <- t[[1]]; datecol <- t[[2]]; alias <- t[[3]]; filt <- t[[4]]
    if (is.null(src[[srcname]])) next
    d <- src[[srcname]]
    if (!is.null(filt)) d <- dplyr::filter(d, dplyr::sql(filt))
    last <- d %>% dplyr::group_by(patientid) %>%
      dplyr::summarise(!!alias := dplyr::sql(sprintf("max(%s)", datecol))) %>% dplyr::ungroup()
    fu <- dplyr::left_join(fu, last, by = "patientid")
    added <- c(added, alias)
  }
  fu <- dplyr::mutate(fu, fu_enddt_preliminary = dplyr::sql(
    if (length(added)) sprintf("greatest(%s)", paste(added, collapse = ", ")) else "cast(NULL as date)"))
  if (!("last_lotenddate" %in% added))
    fu <- dplyr::mutate(fu, last_lotenddate = dplyr::sql("cast(NULL as date)"))

  dod <- "cast(dateofdeath as string)"
  fu <- dplyr::left_join(fu, dplyr::select(src[["mortality"]], patientid, dateofdeath),
                         by = "patientid")
  # Index-aware imputation (month-level -> day; year-only in index year on/after year_month -> late).
  fu <- dplyr::mutate(fu, dateofdeath_init = dplyr::sql(sprintf(paste0(
    "CASE WHEN length(%s)=7 THEN cast(concat(%s,'-%02d') as date) ",
    "WHEN length(%s)=4 THEN ",
    "  CASE WHEN cast(%s as int) = year(index_date) AND month(index_date) >= %d ",
    "       THEN cast(concat(%s,'-%s') as date) ",
    "       ELSE cast(concat(%s,'-%s') as date) END ",
    "WHEN length(%s)=10 THEN cast(dateofdeath as date) ELSE NULL END"),
    dod, dod, month_day, dod, dod, year_month, dod, year_late, dod, year_md, dod)))
  fu <- dplyr::mutate(fu, f_death = dplyr::sql("CASE WHEN dateofdeath IS NOT NULL THEN 1 ELSE 0 END"))

  # Collapse to ONE death row per (patientid, index_date) AFTER imputation (policy-driven order).
  ord <- death_conflict_order(dod, conflict)
  fu <- fu %>%
    dplyr::group_by(patientid, index_date) %>%
    dbplyr::window_order(!!!ord) %>%
    dplyr::mutate(`_rn` = dplyr::row_number()) %>%
    dplyr::ungroup() %>% dplyr::filter(`_rn` == 1) %>% dplyr::select(-`_rn`)

  fu <- dplyr::mutate(fu, death_dt_preliminary = dplyr::sql(sprintf(paste0(
    "CASE WHEN length(%s)=7 AND substr(cast(fu_enddt_preliminary as string),1,7) = substr(%s,1,7) ",
    "  THEN last_day(dateofdeath_init) ELSE dateofdeath_init END"), dod, dod)))
  fu <- dplyr::mutate(fu, fu_enddt = dplyr::sql(paste0(
    "CASE WHEN death_dt_preliminary IS NOT NULL AND fu_enddt_preliminary > death_dt_preliminary THEN ",
    "  CASE WHEN substr(cast(death_dt_preliminary as string),1,7) = substr(cast(last_lotenddate as string),1,7) ",
    "       THEN last_lotenddate ELSE death_dt_preliminary END ",
    "ELSE fu_enddt_preliminary END")))
  fu <- dplyr::mutate(fu, dthdt = dplyr::sql(paste0(
    "CASE WHEN substr(cast(death_dt_preliminary as string),1,7) = substr(cast(last_lotenddate as string),1,7) ",
    "     THEN cast(last_day(death_dt_preliminary) as date) ELSE death_dt_preliminary END")))
  fu <- dplyr::mutate(fu, dthfl = dplyr::sql("CASE WHEN dthdt IS NOT NULL THEN 1 ELSE 0 END"))
  fu <- dplyr::mutate(fu, fued  = dplyr::sql("CASE WHEN fu_enddt > index_date THEN fu_enddt ELSE index_date END"))
  fu <- dplyr::mutate(fu, dthfufl_dur = dplyr::sql("datediff(dthdt, fued)"))
  fu <- dplyr::mutate(fu, dthfufl = dplyr::sql(sprintf(paste0(
    "CASE WHEN dthdt IS NULL THEN 'Missing' WHEN dthfufl_dur <= %d THEN '1' ",
    "WHEN dthfufl_dur > %d THEN '0' ELSE NULL END"), dth_window, dth_window)))
  fu <- dplyr::mutate(fu, dth_before_fued = dplyr::sql(
    "CASE WHEN dthdt IS NOT NULL AND fued IS NOT NULL AND dthdt < fued THEN 1 ELSE 0 END"))
  dplyr::select(fu, patientid, index_date, f_death, dthdt, dthfl, fu_enddt, fued,
                dthfufl_dur, dthfufl, dth_before_fued)
}

# Window-order columns selecting ONE mortality row per group. Mirrors clinical.py::_death_conflict_order.
death_conflict_order <- function(dod, policy) {
  specific <- dplyr::desc(dplyr::sql(sprintf("length(%s)", dod)))   # full > YYYY-MM > YYYY
  earliest <- rlang::expr(dateofdeath_init)
  latest   <- dplyr::desc(dplyr::sql("dateofdeath_init"))
  tiebreak <- rlang::expr(!!dplyr::sql(dod))
  if (policy == "most_specific_then_earliest") return(list(specific, earliest, tiebreak))
  if (policy == "earliest") return(list(earliest, specific, tiebreak))
  if (policy == "latest")   return(list(latest, specific, tiebreak))
  stop(sprintf("unknown death_date_imputation.conflict_resolution: %s", policy))
}

# --- clinical: assemble. engine/stages/clinical.py::build ---------------------------------------
# --- clinical: closest-to-index raw lab VALUE panel. == clinical.py::_closest_values_panel ---------
clinical_closest_values_panel <- function(src, idx, blk) {
  name_col <- blk[["name_column"]]; val_col <- blk[["value_column"]]; date_col <- blk[["date_column"]]
  unit_col <- blk[["unit_column"]]; cast <- toupper(blk[["value_cast"]] %||% "double")
  present <- blk[["present_label"]] %||% "Present"; missing <- blk[["missing_label"]] %||% "Missing"
  wd <- blk[["window_days"]] %||% list(NULL, NULL)
  base <- dplyr::select(idx, patientid, index_date)
  pulled <- dplyr::inner_join(base, src[[blk[["source"]]]], by = "patientid")
  if (!is.null(wd[[1]])) pulled <- dplyr::filter(pulled, dplyr::sql(sprintf("%s >= date_add(index_date, %s)", date_col, wd[[1]])))
  if (!is.null(wd[[2]])) pulled <- dplyr::filter(pulled, dplyr::sql(sprintf("%s <= date_add(index_date, %s)", date_col, wd[[2]])))
  pulled <- pulled %>%
    dplyr::mutate(`_gap` = dplyr::sql(sprintf("abs(datediff(%s, index_date))", date_col)),
                  `_v` = dplyr::sql(sprintf("try_cast(%s AS %s)", val_col, cast)))
  unknown <- blk[["unknown_label"]]                  # optional 3-state: Present / Unknown / Missing
  out <- base
  for (item in blk[["panel"]]) {
    nm <- item[["name"]]
    named <- dplyr::filter(pulled, dplyr::sql(sprintf("upper(%s) = %s", name_col, .q(toupper(item[["match"]])))))
    rows <- named
    if (!is.null(unit_col) && !is.null(item[["units"]]))
      rows <- dplyr::filter(rows, dplyr::sql(sprintf("lower(%s) IN (%s)", unit_col,
        paste(vapply(item[["units"]], function(u) .q(tolower(u)), character(1)), collapse = ", "))))
    rows <- dplyr::filter(rows, dplyr::sql("`_v` IS NOT NULL"))
    vorder <- if ((item[["tiebreak"]] %||% "lowest") == "highest") "`_v` DESC" else "`_v` ASC"
    near <- rows %>%
      dplyr::group_by(patientid, index_date) %>%
      dbplyr::window_order(dplyr::sql(sprintf("`_gap`, %s, %s", date_col, vorder))) %>%
      dplyr::mutate(`_rn` = dplyr::row_number()) %>% dplyr::ungroup() %>%
      dplyr::filter(`_rn` == 1) %>%
      dplyr::transmute(patientid, index_date, !!paste0(nm, "v") := `_v`,
                       !!paste0(nm, "dt") := !!rlang::sym(date_col), !!nm := present)
    out <- dplyr::left_join(out, near, by = c("patientid", "index_date"))
    if (!is.null(unknown)) {                          # test exists but no usable value -> Unknown; none -> Missing
      anyrec <- named %>% dplyr::distinct(patientid, index_date) %>% dplyr::mutate(`_any` = 1L)
      out <- out %>% dplyr::left_join(anyrec, by = c("patientid", "index_date")) %>%
        dplyr::mutate(!!nm := dplyr::sql(sprintf(
          "coalesce(%s, CASE WHEN `_any` IS NOT NULL THEN %s ELSE %s END)", nm, .q(unknown), .q(missing)))) %>%
        dplyr::select(-`_any`)
    } else {
      out <- out %>% dplyr::mutate(!!nm := dplyr::sql(sprintf("coalesce(%s, %s)", nm, .q(missing))))
    }
  }
  out
}

# --- clinical: metastatic-site presence flags. == engine/stages/clinical.py::_metastatic_sites ----
# Weighted comorbidity score over a pre-index lookback == clinical.py comorbidity_index.
# The sum is over DISTINCT conditions (max per condition, then weighted sum), never over rows: a
# patient coded five times for myocardial infarction scores it once. Code sets and weights come
# from the pack — the engine ships no Charlson/Elixhauser table, because a published algorithm has
# versions and adaptations and an engine carrying one would choose it for every product silently.
# {winner -> every condition it supersedes, transitively} == clinical.py::supersedes_closure.
#
# NAMED AND SHARED because both engines had their own version and only one was right. Applying the
# edges one at a time zeroes a loser and then reads that zeroed flag when deciding the loser's OWN
# losers: in severe -> moderate -> mild, `mild` survived a present `severe` here, so R returned 4
# where Python returned 3 — and the answer depended on the order the conditions were listed in.
# Self-edges are dropped; the validator refuses them, and refuses cycles, which is what lets this
# loop terminate.
supersedes_closure <- function(suprs) {
  closure <- lapply(suprs, function(l) unique(as.character(unlist(l))))
  repeat {
    changed <- FALSE
    for (w in names(closure)) {
      grown <- unique(c(closure[[w]], unlist(closure[closure[[w]]], use.names = FALSE)))
      grown <- setdiff(grown[!is.na(grown)], w)
      if (!setequal(grown, closure[[w]])) { closure[[w]] <- grown; changed <- TRUE }
    }
    if (!changed) break
  }
  closure
}

# Whether every weight is a whole number — the cast the score is emitted with.
# == clinical.py::weights_are_integral. An unconditional `as int` here truncated a 1.5 weight to 1
# while Python kept 1.5, so the decision is one named line on each side and a parity test compares
# them rather than a reader comparing two files.
weights_are_integral <- function(weights) {
  ws <- suppressWarnings(as.numeric(unlist(weights)))
  length(ws) > 0 && all(!is.na(ws)) && all(ws == floor(ws))
}

clinical_comorbidity_index <- function(src, idx, blk) {
  dx_src <- src[[blk[["source"]]]]
  conds <- blk[["conditions"]] %||% list()
  if (is.null(dx_src) || length(conds) == 0) return(NULL)
  code_col <- blk[["code_column"]]; system <- blk[["code_system"]]
  dc <- blk[["date_column"]]; wd <- blk[["window_days"]] %||% list(NULL, NULL)
  nm <- blk[["name"]]
  base <- dplyr::select(idx, patientid, index_date)
  rows <- dplyr::inner_join(base, dx_src, by = "patientid")
  if (!is.null(dc)) {
    if (!is.null(wd[[1]])) rows <- dplyr::filter(rows, dplyr::sql(sprintf("%s >= date_add(index_date, %s)", dc, wd[[1]])))
    if (!is.null(wd[[2]])) rows <- dplyr::filter(rows, dplyr::sql(sprintf("%s <= date_add(index_date, %s)", dc, wd[[2]])))
  }
  # One 0/1 per condition per patient — `max` over the window is what makes it DISTINCT.
  aggs <- list(); wts <- list(); suprs <- list()
  for (i in seq_along(conds)) {
    cd <- conds[[i]]
    match <- cd[setdiff(names(cd), c("name", "weight", "supersedes"))]
    pred <- compile_match(match, code_col, code_col, code_col, system)
    col <- paste0("_cc", i)
    aggs[[col]] <- dplyr::sql(sprintf("max(CASE WHEN %s THEN 1 ELSE 0 END)", pred))
    wts[[cd[["name"]]]] <- list(col = col, weight = cd[["weight"]] %||% 1)
    if (!is.null(cd[["supersedes"]])) suprs[[cd[["name"]]]] <- cd[["supersedes"]]
  }
  scored <- rows %>% dplyr::group_by(patientid, index_date) %>%
    dplyr::summarise(!!!aggs, .groups = "drop")
  # HIERARCHY: TRANSITIVE, and read off the ORIGINAL flags == clinical.py comorbidity_index.
  if (length(suprs) > 0) {
    closure <- supersedes_closure(suprs)
    original <- vapply(wts, function(w) sprintf("`%s`", w$col), "")
    for (winner in names(closure)) {
      wsrc <- original[[winner]]
      for (loser in closure[[winner]]) {
        if (!is.null(wts[[loser]])) {
          lcol <- wts[[loser]]$col
          scored <- dplyr::mutate(scored, !!lcol := dplyr::sql(
            sprintf("CASE WHEN %s = 1 THEN 0 ELSE `%s` END", wsrc, lcol)))
        }
      }
    }
  }
  total <- paste(vapply(wts, function(w) sprintf("(`%s` * %s)", w$col, w$weight), ""), collapse = " + ")
  integral <- weights_are_integral(lapply(wts, function(w) w$weight))
  scored <- dplyr::mutate(scored, !!nm := dplyr::sql(
    sprintf("cast(%s as %s)", total, if (integral) "int" else "double")))
  keep <- c(nm)
  if (!is.null(blk[["bands"]])) {
    scored <- dplyr::mutate(scored,
      !!paste0(nm, "gr") := dplyr::sql(num_bands_case(blk[["bands"]], nm, "label")),
      !!paste0(nm, "grn") := dplyr::sql(num_bands_case(blk[["bands"]], nm, "code")))
    keep <- c(keep, paste0(nm, "gr"), paste0(nm, "grn"))
  }
  # LEFT join: a patient with no in-window diagnosis keeps NULL, not 0 — different facts.
  dplyr::left_join(base, dplyr::select(scored, patientid, index_date, dplyr::all_of(keep)),
                   by = c("patientid", "index_date"))
}


clinical_metastatic_sites <- function(src, idx, blk) {
  s <- src[[blk[["source"]]]]
  if (is.null(s)) return(NULL)
  site_col <- blk[["site_column"]]; date_col <- blk[["date_column"]]
  if (!(site_col %in% colnames(s)) || !(date_col %in% colnames(s))) return(NULL)
  yes <- blk[["yes_label"]] %||% "Yes"; no <- blk[["no_label"]] %||% "No"
  base <- dplyr::select(idx, patientid, index_date)
  j <- dplyr::left_join(base, dplyr::select(s, patientid, !!rlang::sym(site_col), !!rlang::sym(date_col)),
                        by = "patientid")
  aggs <- lapply(blk[["sites"]], function(it) dplyr::sql(sprintf(
    "max(CASE WHEN lower(%s) = %s AND %s < index_date THEN 1 ELSE 0 END)",
    site_col, .q(tolower(it[["match"]])), date_col)))
  names(aggs) <- vapply(blk[["sites"]], function(it) paste0("_", it[["name"]]), character(1))
  g <- j %>% dplyr::group_by(patientid, index_date) %>% dplyr::summarise(!!!aggs, .groups = "drop")
  for (it in blk[["sites"]]) {
    g <- dplyr::mutate(g, !!it[["name"]] := dplyr::sql(sprintf(
      "CASE WHEN `_%s` = 1 THEN %s ELSE %s END", it[["name"]], .q(yes), .q(no))))
    g <- dplyr::select(g, -!!rlang::sym(paste0("_", it[["name"]])))
  }
  g
}

# --- clinical: windowed PSA timepoints + PSA-response endpoints. == clinical.py::_psa_timepoints -----
clinical_psa_timepoints <- function(src, idx, blk) {
  val_col <- blk[["value_column"]]; date_col <- blk[["date_column"]]; cast <- toupper(blk[["value_cast"]] %||% "double")
  base <- dplyr::select(idx, patientid, index_date)
  pulled <- dplyr::inner_join(base, src[[blk[["source"]]]], by = "patientid") %>%
    dplyr::mutate(`_v` = dplyr::sql(sprintf("try_cast(%s AS %s)", val_col, cast))) %>%
    dplyr::filter(dplyr::sql("`_v` IS NOT NULL"))
  out <- base
  for (p in blk[["points"]]) {
    wd <- p[["window_days"]]
    rows <- dplyr::filter(pulled, dplyr::sql(sprintf(
      "%s >= date_add(index_date, %s) AND %s <= date_add(index_date, %s)", date_col, wd[[1]], date_col, wd[[2]])))
    if ((p[["pick"]] %||% "closest") == "earliest") {
      ord <- sprintf("%s, `_v` DESC", date_col)
    } else {
      rows <- dplyr::mutate(rows, `_g` = dplyr::sql(sprintf("abs(datediff(%s, index_date))", date_col)))
      ord <- sprintf("`_g`, %s", date_col)
    }
    near <- rows %>% dplyr::group_by(patientid, index_date) %>% dbplyr::window_order(dplyr::sql(ord)) %>%
      dplyr::mutate(`_rn` = dplyr::row_number()) %>% dplyr::ungroup() %>% dplyr::filter(`_rn` == 1) %>%
      dplyr::transmute(patientid, index_date, !!p[["name"]] := `_v`)
    out <- dplyr::left_join(out, near, by = c("patientid", "index_date"))
  }
  resp <- blk[["response"]]
  if (!is.null(resp)) {
    bl <- resp[["baseline"]]; p50 <- resp[["psa50_threshold"]] %||% -0.5; pun <- resp[["undetectable_threshold"]] %||% 0.2
    for (pt in resp[["points"]]) {
      v <- pt[["value"]]
      out <- out %>%
        dplyr::mutate(!!pt[["psa50"]] := dplyr::sql(sprintf(paste0(   # NULL = not evaluable
          "CASE WHEN %s IS NULL OR %s = 0 OR %s IS NULL THEN NULL ",
          "WHEN (%s - %s)/%s <= %s THEN 'Y' ELSE 'N' END"), bl, bl, v, v, bl, bl, p50))) %>%
        dplyr::mutate(!!pt[["undetectable"]] := dplyr::sql(sprintf(
          "CASE WHEN %s IS NOT NULL AND %s < %s THEN 'Y' WHEN %s IS NOT NULL THEN 'N' ELSE NULL END", v, v, pun, v)))
    }
  }
  out
}

# The closest-to-index panel blocks == clinical.py CLOSEST_PANELS. Spelled here because R cannot
# import the Python constant; test_r_parity asserts the two lists are identical, so a family added
# to one engine and not the other fails rather than silently producing a column in only one.
CLOSEST_PANELS <- c("biomarkers", "labs", "response")

# THE SELECTION REGISTRY == clinical.py DEFAULT_SELECTION / _selection_spec. Two divergences lived
# here and both produced a different variable in R than in Python, silently:
#
#   tie_break  R had no default at all and fell through to DESCENDING date, while Python defaults to
#              `prior` (ascending). Two records equidistant either side of index therefore resolved
#              to opposite rows — the later one in R, the earlier one in Python.
#   pick       R read only the legacy `aggregate: priority` spelling. A block written as
#              `pick: priority` — which is what the generated scaffold emits — ranked by priority in
#              Python and by nearest-to-index in R. For a response panel that is the difference
#              between best-of-window and whatever happened to fall closest to index.
#
# Neither showed up in the parity suite, which compares compiled CASE strings and block names but
# does not run rows through both engines. So the DEFAULTS are now one object per engine, compared
# directly by test_r_parity.
# == clinical.py DEFAULT_SELECTION. `same_date_conflict` says what happens when two records on the
# SAME DATE disagree about the value — a different question from `tie_break`, which only ever
# decided which DATE wins. `deterministic` is what both engines have always done once the ordering
# is total, so no pack's output moves by adding it.
SELECTION_DEFAULTS <- list(date_basis = "column", pick = "nearest", tie_break = "prior",
                           same_date_conflict = "deterministic")

# The effective value of one selection key: the ITEM's, else the BLOCK's, else the registered
# default — item-over-block, exactly as _selection_spec resolves it.
selection_spec <- function(blk, item, key) {
  for (src in list(item, blk)) {
    if (!is.null(src) && !is.null(src[[key]])) {
      v <- src[[key]]
      return(if (is.list(v)) (v[["method"]] %||% v) else v)
    }
  }
  # `aggregate: priority` is the pre-registry spelling of `pick: priority`, still honoured so no
  # pack needs editing — the same allowance _selection_spec makes.
  if (identical(key, "pick") && !is.null(item) && identical(item[["aggregate"]], "priority")) {
    return("priority")
  }
  SELECTION_DEFAULTS[[key]]
}

# THE RECORD'S DATE, per the block's `date_basis` == clinical.py::_record_date_expr.
#
# This file DEFINED the default and then never used it: the panel loop read `blk[["date_column"]]`
# for the window filter, the gap, the ordering and the emitted date. A pack configuring
# `date_basis: {method: later_of, columns: [collected, resulted]}` therefore either failed here for
# want of a `date_column`, or — with both keys present — silently windowed and ranked on a DIFFERENT
# date from the one Python used, selecting a different row. `greatest`/`least` ignore nulls in Spark
# SQL, so a record dated on only one of two columns still has a date rather than dropping out.
record_date_sql <- function(blk) {
  basis <- blk[["date_basis"]] %||% SELECTION_DEFAULTS[["date_basis"]]
  method <- if (is.list(basis)) (basis[["method"]] %||% "column") else basis
  if (identical(as.character(method), "column")) return(blk[["date_column"]])
  cols <- paste(unlist(basis[["columns"]]), collapse = ", ")
  sprintf("%s(%s)", if (identical(as.character(method), "later_of")) "greatest" else "least", cols)
}

clinical_build <- function(src, idx, cfg) {
  clin_cfg <- cfg_pack(cfg, "clinical")
  base <- dplyr::select(idx, patientid, index_date)
  ecog_cfg <- clin_cfg[["baseline_ecog"]]
  if (!is.null(src[["baseline_ecog"]])) {
    ecog <- clinical_baseline_ecog(src, idx, ecog_cfg)
  } else {
    ecog <- base %>% dplyr::mutate(ecog = ecog_cfg[["missing_label"]], ecogn = ecog_cfg[["missing_code"]])
  }
  clin <- base %>%
    dplyr::left_join(ecog, by = c("patientid", "index_date")) %>%
    dplyr::left_join(clinical_follow_up_and_death(src, idx, clin_cfg),
                     by = c("patientid", "index_date"))

  # Stage grouping (deterministic pick via staging.source/date_column/pick). == clinical.py.
  stcfg <- clin_cfg[["staging"]] %||% list()
  groups <- stcfg[["groups"]]
  st_src <- src[[stcfg[["source"]] %||% cfg_index_source(cfg)]]
  if (!is.null(st_src) && !is.null(groups) && "groupstage" %in% colnames(st_src)) {
    sel <- c("patientid", "groupstage")
    dc <- stcfg[["date_column"]]
    st <- st_src
    if (!is.null(dc) && dc %in% colnames(st_src)) {
      sel <- c(sel, dc)
      st <- st %>% dplyr::group_by(patientid)
      st <- if ((stcfg[["pick"]] %||% "latest") == "latest")
        dbplyr::window_order(st, dplyr::desc(!!rlang::sym(dc)), groupstage)
      else dbplyr::window_order(st, !!rlang::sym(dc), groupstage)
    } else {
      st <- st %>% dplyr::group_by(patientid) %>% dbplyr::window_order(groupstage)
    }
    st <- st %>% dplyr::select(dplyr::all_of(sel)) %>%
      dplyr::mutate(`_rn` = dplyr::row_number()) %>% dplyr::ungroup() %>%
      dplyr::filter(`_rn` == 1) %>%
      dplyr::mutate(stage  = dplyr::sql(stage_case(groups, "groupstage", "label")),
                    stagen = dplyr::sql(stage_case(groups, "groupstage", "code"))) %>%
      dplyr::select(patientid, stage, stagen)
    clin <- dplyr::left_join(clin, st, by = "patientid")
  }

  # Generic categorical clinical characteristics (grade/histology/…): same value->group CASE as
  # staging, via the parity-proven stage_case compiler. == clinical.py categoricals loop. The row
  # pick honours date_column + pick (latest|earliest) like the staging block above — NOT an
  # arbitrary order — so the selected value matches _categorical_pick().
  for (cat in (clin_cfg[["categoricals"]] %||% list())) {
    cat_src <- src[[cat[["source"]] %||% cfg_index_source(cfg)]]
    col <- cat[["column"]]; cg <- cat[["groups"]]; nm <- cat[["name"]]
    if (is.null(cat_src) || is.null(cg) || is.null(col) || is.null(nm) || !(col %in% colnames(cat_src))) next
    dc <- cat[["date_column"]]

    # WINDOWED (index-anchored) categorical == clinical.py _categorical_pick_windowed. Keyed on
    # (patientid, index_date), NOT patientid: the window is measured from index, so a patient in two
    # cohorts has two index dates and may legitimately have two answers. A window whose date column
    # the source lacks is SKIPPED, never silently demoted to the unwindowed pick — "the value at
    # index" and "the patient's latest value" are different questions.
    if (!is.null(cat[["window_days"]])) {
      if (is.null(dc) || !(dc %in% colnames(cat_src))) next
      wdc <- cat[["window_days"]]
      label_sql <- stage_case(cg, col, "label"); code_sql <- stage_case(cg, col, "code")
      cbase <- dplyr::select(idx, patientid, index_date)
      crows <- dplyr::inner_join(cbase, dplyr::select(cat_src, patientid, dplyr::all_of(c(col, dc))),
                                 by = "patientid")
      if (!is.null(wdc[[1]])) crows <- dplyr::filter(crows, dplyr::sql(sprintf("%s >= date_add(index_date, %s)", dc, wdc[[1]])))
      if (!is.null(wdc[[2]])) crows <- dplyr::filter(crows, dplyr::sql(sprintf("%s <= date_add(index_date, %s)", dc, wdc[[2]])))
      crows <- dplyr::mutate(crows, `_gap` = dplyr::sql(sprintf("abs(datediff(%s, index_date))", dc)))
      cpick <- selection_spec(cat, NULL, "pick")
      ctie <- selection_spec(cat, NULL, "tie_break")
      cdt <- if (identical(ctie, "prior")) rlang::expr(!!rlang::sym(dc)) else rlang::expr(dplyr::desc(!!rlang::sym(dc)))
      cgrp <- crows %>% dplyr::group_by(patientid, index_date)
      if (identical(cpick, "priority")) {
        prio <- cat[["priority"]] %||% lapply(cg, function(g) g[["label"]])
        rank_sql <- paste0("CASE ", paste(vapply(seq_along(prio), function(i)
          sprintf("WHEN (%s) = '%s' THEN %d", label_sql,
                  gsub("'", "''", as.character(prio[[i]])), i - 1L), ""), collapse = " "),
          sprintf(" ELSE %d END", length(prio)))
        cgrp <- cgrp %>% dplyr::mutate(`_rank` = dplyr::sql(rank_sql)) %>%
          dbplyr::window_order(`_rank`, !!cdt)
      } else if (identical(cpick, "earliest")) {
        cgrp <- dbplyr::window_order(cgrp, !!rlang::sym(dc), !!cdt)
      } else if (identical(cpick, "latest")) {
        cgrp <- dbplyr::window_order(cgrp, dplyr::desc(!!rlang::sym(dc)), !!cdt)
      } else {
        cgrp <- dbplyr::window_order(cgrp, `_gap`, !!cdt)
      }
      cwin <- cgrp %>%
        dplyr::mutate(`_rn` = dplyr::row_number()) %>% dplyr::ungroup() %>%
        dplyr::filter(`_rn` == 1) %>%
        dplyr::mutate(!!nm := dplyr::sql(label_sql), !!paste0(nm, "n") := dplyr::sql(code_sql)) %>%
        dplyr::select(patientid, index_date, dplyr::all_of(c(nm, paste0(nm, "n"))))
      clin <- dplyr::left_join(clin, cwin, by = c("patientid", "index_date"))
      next
    }

    cdf <- cat_src %>% dplyr::group_by(patientid)
    # == clinical.py: unwrap the mapping form `pick: {method: latest}`, which the windowed branch
    # above already sees through via selection_spec(). Reading the raw value made the same
    # spelling mean different things in the two branches.
    cpick <- cat[["pick"]] %||% "latest"
    if (is.list(cpick)) cpick <- cpick[["method"]] %||% "latest"
    if (!is.null(dc) && dc %in% colnames(cat_src)) {
      cdf <- if (cpick == "latest")
        dbplyr::window_order(cdf, dplyr::desc(!!rlang::sym(dc)), !!rlang::sym(col))
      else dbplyr::window_order(cdf, !!rlang::sym(dc), !!rlang::sym(col))
    } else {
      cdf <- dbplyr::window_order(cdf, !!rlang::sym(col))
    }
    cdf <- cdf %>%
      dplyr::mutate(`_rn` = dplyr::row_number()) %>% dplyr::ungroup() %>%
      dplyr::filter(`_rn` == 1) %>%
      dplyr::mutate(!!nm := dplyr::sql(stage_case(cg, col, "label")),
                    !!paste0(nm, "n") := dplyr::sql(stage_case(cg, col, "code"))) %>%
      dplyr::select(patientid, dplyr::all_of(c(nm, paste0(nm, "n"))))
    clin <- dplyr::left_join(clin, cdf, by = "patientid")
  }

  # Closest-to-index PANELS (biomarkers / labs): each item picks the record nearest index within
  # its window, maps the value via stage_case. == clinical.py _closest_panel.
  for (blk_key in CLOSEST_PANELS) {
    blk <- clin_cfg[[blk_key]]
    if (is.null(blk) || is.null(src[[blk[["source"]]]]) || is.null(blk[["panel"]])) next
    name_col <- blk[["name_column"]]; val_col <- blk[["value_column"]]
    unit_col <- blk[["unit_column"]]
    wd <- blk[["window_days"]] %||% list(NULL, NULL)
    base <- dplyr::select(idx, patientid, index_date)
    pulled <- dplyr::inner_join(base, src[[blk[["source"]]]], by = "patientid")
    # Materialised ONCE into `_rdate` and used by the window filter, the gap, the ordering and the
    # emitted date == clinical.py _closest_panel. Four places that each spelled `date_column` are
    # four places that can come to disagree the moment the basis stops being a single column.
    date_col <- "_rdate"
    pulled <- dplyr::mutate(pulled, `_rdate` = dplyr::sql(record_date_sql(blk)))
    if (!is.null(wd[[1]])) pulled <- dplyr::filter(pulled, dplyr::sql(sprintf("`%s` >= date_add(index_date, %s)", date_col, wd[[1]])))
    if (!is.null(wd[[2]])) pulled <- dplyr::filter(pulled, dplyr::sql(sprintf("`%s` <= date_add(index_date, %s)", date_col, wd[[2]])))
    pulled <- dplyr::mutate(pulled, `_gap` = dplyr::sql(sprintf("abs(datediff(`%s`, index_date))", date_col)))
    for (item in blk[["panel"]]) {
      nm <- item[["name"]]
      if (!is.null(item[["bands"]])) {                # numeric value -> num_bands_case (e.g. CA-125)
        cast <- item[["value_cast"]] %||% blk[["value_cast"]] %||% "double"
        num_col <- sprintf("try_cast(%s AS %s)", val_col, toupper(cast))   # == clinical.py _band_value_expr
        label_sql <- num_bands_case(item[["bands"]], num_col, "label")
        code_sql  <- num_bands_case(item[["bands"]], num_col, "code")
      } else {                                        # categorical value -> stage_case
        label_sql <- stage_case(item[["groups"]], val_col, "label")
        code_sql  <- stage_case(item[["groups"]], val_col, "code")
      }
      names <- item[["match_any"]] %||% list(item[["match"]])   # match_any: a multi-name set (HRR gene panel)
      inlist <- paste(sprintf("'%s'", toupper(unlist(names))), collapse = ", ")
      rows <- dplyr::filter(pulled, dplyr::sql(sprintf("upper(%s) IN (%s)", name_col, inlist)))
      if (!is.null(unit_col) && !is.null(item[["units"]])) {              # restrict to configured units (ci)
        ulist <- paste(vapply(item[["units"]], function(u) sprintf("'%s'", tolower(as.character(u))), ""), collapse = ", ")
        rows <- dplyr::filter(rows, dplyr::sql(sprintf("lower(%s) IN (%s)", unit_col, ulist)))
      }
      # ORDERING FROM THE SHARED REGISTRY == clinical.py _selection_order. All four picks, and the
      # date tie resolved by `tie_break` — not the legacy `aggregate` key alone, which made a block
      # written `pick: priority` rank by nearest here and by priority in Python.
      ipick <- selection_spec(blk, item, "pick")
      itie <- selection_spec(blk, item, "tie_break")
      idt <- if (identical(itie, "prior")) rlang::expr(!!rlang::sym(date_col))
             else rlang::expr(dplyr::desc(!!rlang::sym(date_col)))
      # A TOTAL ORDER == clinical.py `value_tie`. Two records on the SAME DATE with different
      # values is the ordinary case; without a final key each engine returns whichever row its
      # own backend happened to place first, so the two could disagree — and either could
      # disagree with itself between runs. Ordering last on the mapped label makes the choice
      # deterministic. It does not make it right; `same_date_conflict` is what says that.
      ival <- rlang::expr(dplyr::sql(!!label_sql))
      if (identical(ipick, "priority")) {
        prio <- item[["priority"]] %||% lapply(item[["groups"]], function(g) g[["label"]])
        rank_sql <- paste0("CASE ", paste(vapply(seq_along(prio), function(i)
          sprintf("WHEN (%s) = '%s' THEN %d", label_sql,
                  gsub("'", "''", as.character(prio[[i]])), i - 1L), ""), collapse = " "),
          sprintf(" ELSE %d END", length(prio)))
        ord <- rows %>% dplyr::mutate(`_rank` = dplyr::sql(rank_sql)) %>%
          dplyr::group_by(patientid, index_date) %>%
          dbplyr::window_order(`_rank`, !!idt, !!ival)
      } else if (identical(ipick, "earliest")) {
        ord <- rows %>% dplyr::group_by(patientid, index_date) %>%
          dbplyr::window_order(!!rlang::sym(date_col), !!ival)
      } else if (identical(ipick, "latest")) {
        ord <- rows %>% dplyr::group_by(patientid, index_date) %>%
          dbplyr::window_order(dplyr::desc(!!rlang::sym(date_col)), !!ival)
      } else {
        ord <- rows %>% dplyr::group_by(patientid, index_date) %>%
          dbplyr::window_order(`_gap`, !!idt, !!ival)
      }
      # `emit_date` adds the WINNING record's date as <name>dt == clinical.py _closest_panel. Opt-in
      # per block: biomarkers and labs leave it unset, so their columns are unchanged. For a
      # `priority` pick the winner is not the nearest row, so the date cannot be re-derived later.
      keep <- c(nm, paste0(nm, "n"))
      near <- ord %>%
        dplyr::mutate(`_rn` = dplyr::row_number()) %>% dplyr::ungroup() %>%
        dplyr::filter(`_rn` == 1) %>%
        dplyr::mutate(!!nm := dplyr::sql(label_sql), !!paste0(nm, "n") := dplyr::sql(code_sql))
      if (isTRUE(blk[["emit_date"]])) {
        near <- dplyr::mutate(near, !!paste0(nm, "dt") := !!rlang::sym(date_col))
        keep <- c(keep, paste0(nm, "dt"))
      }
      near <- near %>% dplyr::select(patientid, index_date, dplyr::all_of(keep))
      clin <- dplyr::left_join(clin, near, by = c("patientid", "index_date"))
    }
  }

  # Metastatic-site presence flags at index (hepatic/lung/adrenal/bone/brain). == clinical.py.
  # Baseline comorbidity burden == clinical.py, config-gated like every other optional family.
  ccib <- clin_cfg[["comorbidity_index"]]
  if (!is.null(ccib) && !is.null(src[[ccib[["source"]]]]) && !is.null(ccib[["conditions"]])) {
    cc <- clinical_comorbidity_index(src, idx, ccib)
    if (!is.null(cc)) clin <- dplyr::left_join(clin, cc, by = c("patientid", "index_date"))
  }

  msblk <- clin_cfg[["metastatic_sites"]]
  if (!is.null(msblk) && !is.null(src[[msblk[["source"]]]]) && !is.null(msblk[["sites"]])) {
    ms <- clinical_metastatic_sites(src, idx, msblk)
    if (!is.null(ms)) clin <- dplyr::left_join(clin, ms, by = c("patientid", "index_date"))
  }

  # Closest-to-index raw lab VALUE panel (LABNEU present + LABNEUv value + LABNEUdt date). == clinical.py.
  lvblk <- clin_cfg[["lab_values"]]
  if (!is.null(lvblk) && !is.null(src[[lvblk[["source"]]]]) && !is.null(lvblk[["panel"]]))
    clin <- dplyr::left_join(clin, clinical_closest_values_panel(src, idx, lvblk),
                             by = c("patientid", "index_date"))

  # Windowed PSA timepoints + PSA-response endpoints (PSA at index/6mo/12mo; PSA50/undetectable). == clinical.py.
  psablk <- clin_cfg[["psa_timepoints"]]
  if (!is.null(psablk) && !is.null(src[[psablk[["source"]]]]) && !is.null(psablk[["points"]]))
    clin <- dplyr::left_join(clin, clinical_psa_timepoints(src, idx, psablk), by = c("patientid", "index_date"))

  # OC surgery sub-block (issurg/surg/surgn/neoadj + tt_first_tx_diag). == clinical.py _surgery.
  scfg <- clin_cfg[["surgery"]]
  if (!is.null(scfg) && !is.null(src[[scfg[["source"]]]])) {
    sg <- clinical_surgery(src, idx, scfg)
    if (!is.null(sg)) clin <- dplyr::left_join(clin, sg, by = c("patientid", "index_date"))
  }

  mblk <- clin_cfg[["min_avail_date"]]
  if (!is.null(mblk) && (!is.null(mblk[["sources"]]) || !is.null(mblk[["base_columns"]]))) {
    mad <- clinical_min_avail_date(src, idx, mblk, cfg_index_source(cfg))
    if (!is.null(mad)) clin <- dplyr::left_join(clin, mad, by = c("patientid", "index_date"))
  }

  if (!is.null(src[["vitals"]]) && !is.null(clin_cfg[["vitals"]]))
    clin <- dplyr::left_join(clin, clinical_vitals(src, idx, clin_cfg[["vitals"]]),
                             by = c("patientid", "index_date"))

  # Config-driven enhanced pass-through + presence flags. == clinical.py _passthrough.
  pblk <- clin_cfg[["passthrough"]]
  if (!is.null(pblk)) {
    pt <- clinical_passthrough(src, idx, pblk, cfg_index_source(cfg))
    if (!is.null(pt)) clin <- dplyr::left_join(clin, pt, by = c("patientid", "index_date"))
  }

  # Derived durations (months/days between dated milestones). == clinical.py _durations.
  dblk <- clin_cfg[["durations"]]
  if (!is.null(dblk) && !is.null(dblk[["items"]])) {
    du <- clinical_durations(src, idx, dblk, cfg_index_source(cfg))
    if (!is.null(du)) clin <- dplyr::left_join(clin, du, by = c("patientid", "index_date"))
  }

  # mCRPC index-window flag + MCRPCDD date — config-gated (clinical.mcrpc_window). == clinical.py.
  mcw <- clin_cfg[["mcrpc_window"]]
  isrc <- src[[cfg_index_source(cfg)]]
  if (!is.null(mcw) && !is.null(isrc)) {
    ecols <- colnames(isrc)
    if (all(unlist(mcw[["columns"]]) %in% ecols)) {
      start <- cfg$raw[["study"]][["index_start"]]; end <- cfg$raw[["study"]][["index_end"]]
      dnm <- mcw[["date_as"]] %||% "mcrpcdd"; fnm <- mcw[["flag_as"]] %||% "mcrpc"
      mc <- isrc %>%
        dplyr::transmute(patientid, !!dnm := dplyr::sql(sprintf("greatest(%s)",
          paste(unlist(mcw[["columns"]]), collapse = ", ")))) %>%
        dplyr::distinct(patientid, .keep_all = TRUE) %>%
        dplyr::mutate(!!fnm := dplyr::sql(sprintf(
          "CASE WHEN %s >= date('%s') AND %s <= date('%s') THEN 1 ELSE 0 END", dnm, start, dnm, end)))
      clin <- dplyr::left_join(clin, mc, by = "patientid")
    }
  }

  # Derived columns over the assembled frame (spec master mutate). == clinical.py::_derived.
  dvb <- clin_cfg[["derived"]]
  if (!is.null(dvb)) {
    have <- colnames(clin)
    for (it in dvb) {
      if (all(unlist(it[["requires"]]) %in% have)) {
        expr <- gsub("\\{index_start\\}", sprintf("date('%s')", cfg$raw[["study"]][["index_start"]]),
                     it[["expr"]], fixed = FALSE)
        expr <- gsub("\\{index_end\\}", sprintf("date('%s')", cfg$raw[["study"]][["index_end"]]),
                     expr, fixed = FALSE)
        clin <- dplyr::mutate(clin, !!it[["name"]] := dplyr::sql(expr))
      }
    }
  }
  clin
}

# --- treatment: per-line lotcat + line-count bands. engine/stages/treatment.py ------------------
# config-driven drug-category column + category_equals values (== treatment.py::_drug_category_column /
# _category_equals_values) so the treatment stage never hardcodes a name/value the codelist can override.
drug_category_column <- function(codelist)
  codelist[["match_on"]][["drug_category_column"]] %||% "detaileddrugcategory"

category_equals_values <- function(codelist) {
  vals <- character(0)
  for (cat in codelist[["categories"]]) {
    v <- cat[["match"]][["category_equals"]]
    if (!is.null(v)) { v <- tolower(as.character(v)); if (!(v %in% vals)) vals <- c(vals, v) }
  }
  vals
}

treatment_categorize_line <- function(df, codelist, label_col = "lotcat", code_col = "lotcatn") {
  cc <- compile_case(codelist)               # PROVEN identical to Python (codelists.R)
  df %>% dplyr::mutate(!!label_col := dplyr::sql(cc$label),
                       !!code_col  := dplyr::sql(cc$code))
}

# One deterministic per-line frame (lot{i}* / lot{i}m*). == engine/stages/treatment.py::_line_frame.
# Column names come from the SHARED line_cols (cases.R) — the same source the Python engine and the
# parity test use — so the producer/consumer contract can't drift across engines.
treatment_line_frame <- function(rows, i, maint, mc, epi, codelist) {
  lc <- line_cols(i, maint)
  cat_col <- drug_category_column(codelist)    # config-driven (not a hardcoded "detaileddrugcategory")
  g <- dplyr::group_by(rows, patientid)
  g <- if (!isTRUE(maint) && mc %in% colnames(rows))
    dbplyr::window_order(g, !!rlang::sym(mc), startdate, enddate, linename)  # prefer non-maintenance
  else dbplyr::window_order(g, startdate, enddate, linename)
  line <- g %>% dplyr::mutate(`_rn` = dplyr::row_number()) %>% dplyr::ungroup() %>%
    dplyr::filter(`_rn` == 1)
  if (!is.null(epi)) {
    # epi is already scoped to this cohort's setting (treatment_build filters drug_episode before
    # aggregating) and lot_norm is single-setting, so the join keys on (patientid, linenumber) — the same
    # grain the pre-B1 loted join used. Drop the LOT-native category ONLY when epi supplies its own
    # (episode wins, avoids an ambiguous column); otherwise keep the LOT-native one. == treatment.py.
    if ((cat_col %in% colnames(line)) && (cat_col %in% colnames(epi)))
      line <- dplyr::select(line, -dplyr::all_of(cat_col))
    line <- line %>% dplyr::left_join(epi, by = c("patientid", "linenumber")) %>%
      dplyr::mutate(loted = dplyr::sql("coalesce(epi_lastdate, enddate)"))
  } else {
    line <- line %>% dplyr::mutate(loted = enddate)
  }
  # the drug-category column feeds the (unchanged) classifier; ensure it exists (typed null) for a tumor
  # without drug-episode data so the compiled CASE stays valid.
  if (!(cat_col %in% colnames(line)))
    line <- line %>% dplyr::mutate(!!cat_col := dplyr::sql("CAST(NULL AS STRING)"))
  line <- line %>%
    dplyr::transmute(patientid,
                     !!lc$name     := linename,
                     !!lc$start    := startdate,
                     !!lc$end      := enddate,
                     !!lc$lastdate := loted,
                     !!lc$dur      := dplyr::sql("datediff(loted, startdate) + 1"),  # lot{i}dur (days)
                     linename, !!rlang::sym(cat_col))
  line <- treatment_categorize_line(line, codelist, label_col = lc$cat, code_col = lc$catn)
  line %>% dplyr::select(-linename, -dplyr::all_of(cat_col))
}

# Generic prior-treatment predicate + flags. == engine/stages/treatment.py::_prior_pred/_prior_treatments.
prior_pred <- function(fl) {
  likes <- function(xs) paste(vapply(xs, function(x) sprintf("lower(linename) LIKE '%s'", tolower(x)),
                                     character(1)), collapse = " OR ")
  if (!is.null(fl[["all_of"]]))
    return(paste(vapply(fl[["all_of"]], function(grp) sprintf("(%s)", likes(grp)), character(1)),
                 collapse = " AND "))
  likes(fl[["like_any"]])
}

treatment_prior_treatments <- function(trt, idx, src, cfg, ptcfg) {
  yes <- ptcfg[["yes_label"]] %||% "Yes"; no <- ptcfg[["no_label"]] %||% "No"
  lot_all <- lot_normalized(src, NULL, exclude_settings = cfg_lot_exclude_settings(cfg),
                            line_number_col = cfg_lot_line_number_col(cfg),
                            maintenance_column = cfg_lot_maintenance_column(cfg))
  pre <- dplyr::select(idx, patientid, index_date) %>%
    dplyr::inner_join(lot_all, by = "patientid") %>% dplyr::filter(startdate <= index_date)
  for (fl in ptcfg[["flags"]]) {
    hit <- pre %>% dplyr::filter(dplyr::sql(sprintf("(%s)", prior_pred(fl)))) %>%
      dplyr::select(patientid, index_date) %>% dplyr::distinct() %>% dplyr::mutate(`_h` = 1L)
    trt <- trt %>% dplyr::left_join(hit, by = c("patientid", "index_date")) %>%
      dplyr::mutate(!!fl[["name"]] := dplyr::sql(sprintf(
        "CASE WHEN `_h` IS NOT NULL THEN '%s' ELSE '%s' END", yes, no))) %>%
      dplyr::select(-`_h`)
  }
  trt
}

# Concomitant/supportive-med exposure flags (BP/CSF/steroid). == treatment.py::_conmed_exposures.
treatment_conmed_exposures <- function(trt, idx, src, ccfg) {
  csrc <- src[[ccfg[["source"]]]]; nc <- ccfg[["name_column"]]; dc <- ccfg[["date_column"]]
  if (is.null(csrc) || !(nc %in% colnames(csrc))) return(trt)
  yes <- ccfg[["yes_label"]] %||% "Yes"; no <- ccfg[["no_label"]] %||% "No"
  wd <- ccfg[["window_days"]] %||% list(NULL, NULL)
  pulled <- dplyr::select(idx, patientid, index_date) %>% dplyr::inner_join(csrc, by = "patientid")
  if (dc %in% colnames(csrc) && !is.null(wd[[1]]))
    pulled <- dplyr::filter(pulled, dplyr::sql(sprintf("%s >= date_add(index_date, %s)", dc, wd[[1]])))
  if (dc %in% colnames(csrc) && !is.null(wd[[2]]))
    pulled <- dplyr::filter(pulled, dplyr::sql(sprintf("%s <= date_add(index_date, %s)", dc, wd[[2]])))
  for (fl in ccfg[["flags"]]) {
    pred <- paste(vapply(fl[["like_any"]], function(p) sprintf("lower(%s) LIKE '%s'", nc, tolower(p)),
                         character(1)), collapse = " OR ")
    hit <- pulled %>% dplyr::filter(dplyr::sql(sprintf("(%s)", pred))) %>%
      dplyr::select(patientid, index_date) %>% dplyr::distinct() %>% dplyr::mutate(`_h` = 1L)
    trt <- trt %>% dplyr::left_join(hit, by = c("patientid", "index_date")) %>%
      dplyr::mutate(!!fl[["name"]] := dplyr::sql(sprintf(
        "CASE WHEN `_h` IS NOT NULL THEN '%s' ELSE '%s' END", yes, no))) %>%
      dplyr::select(-`_h`)
  }
  trt
}

# Per-setting line columns (LOT*_MHSPC / LOT*_MCRPC). == treatment.py::_setting_line_columns.
treatment_setting_line_columns <- function(src, idx, cfg, slc) {
  col_map <- list(sd = "startdate", ed = "enddate", name = "linename")
  attrs <- Filter(function(a) !is.null(col_map[[a]]), slc[["attributes"]] %||% c("sd", "name"))
  out <- idx %>% dplyr::select(patientid, index_date)
  nlines <- as.integer(slc[["lines"]] %||% 2)
  for (setting in slc[["settings"]]) {
    suffix <- tolower(setting)
    norm <- lot_normalized(src, setting, exclude_settings = cfg_lot_exclude_settings(cfg),
                           line_number_col = cfg_lot_line_number_col(cfg),
                           maintenance_column = cfg_lot_maintenance_column(cfg))
    for (i in seq_len(nlines)) {
      sels <- stats::setNames(lapply(attrs, function(a) rlang::sym(col_map[[a]])),
                              vapply(attrs, function(a) sprintf("lot%d%s_%s", i, a, suffix), ""))
      li <- norm %>% dplyr::filter(new_lot_n == i) %>%
        dplyr::transmute(patientid, !!!sels) %>% dplyr::distinct(patientid, .keep_all = TRUE)
      out <- dplyr::left_join(out, li, by = "patientid")
    }
  }
  out
}

treatment_build <- function(src, idx, cfg, cohort = NULL) {
  trt_cfg <- cfg_pack(cfg, "treatment")
  codelist <- cfg_codelist(cfg, "treatment_categories")
  base <- dplyr::select(idx, patientid, index_date)
  # Full configured LOT model (exclude_settings / line_number_col / maintenance_column) like the
  # Python treatment stage and the R index stage — NO maintenance filter (all lines) — so the
  # per-line columns are numbered identically for the OC/EC linenumber model. == treatment.py.
  line_setting <- cohort[["line_setting"]] %||% cfg_lot_line_setting(cfg)   # effective setting (or NULL)
  lot_norm <- lot_normalized(src, line_setting,
                             exclude_settings   = cfg_lot_exclude_settings(cfg),   # per-cohort setting
                             line_number_col    = cfg_lot_line_number_col(cfg),    # (dual-setting products)
                             maintenance_column = cfg_lot_maintenance_column(cfg))

  # Per-line drug-episode aggregate (loted -> lot{i}ed AND the per-line chemotherapy indicator that
  # feeds lotcatn=9): the delivered data carries detaileddrugcategory on DrugEpisode, not LOT, so the
  # category is aggregated here and joined onto the line. SETTING GRAIN (config-driven): scope the
  # aggregate to the SAME setting as lot_norm — when a line setting is configured, FILTER drug_episode to
  # it and aggregate by (patientid, linenumber); otherwise aggregate on (patientid, linenumber) with no
  # setting. Do NOT key on linesetting just because the physical source carries it. The classifier/codelist
  # DSL is unchanged (compiler parity unaffected). Optional: falls back to enddate + null category without
  # the drug_episode source. == engine/stages/treatment.py.
  de <- src[["drug_episode"]]
  epi <- NULL
  if (!is.null(de) && all(c("linenumber", "episodedate") %in% colnames(de))) {
    de_cols <- colnames(de)
    if (!is.null(line_setting)) {
      # a setting IS configured -> the aggregate MUST be scoped to it; fail loudly rather than silently
      # combine episodes across settings (preflight normally catches this). == engine/stages/treatment.py.
      if (!("linesetting" %in% de_cols))
        stop(sprintf(paste0("treatment stage: line setting '%s' is configured but drug_episode has no ",
                            "'linesetting' column to scope the per-line aggregate — this would combine ",
                            "episodes across settings. Add linesetting to drug_episode, or clear the ",
                            "line setting."), line_setting))
      de <- de %>% dplyr::filter(linesetting == !!line_setting)   # scope to this cohort's setting
    }
    cat_col <- drug_category_column(codelist)
    cat_values <- category_equals_values(codelist)
    if ((cat_col %in% de_cols) && length(cat_values) > 0) {
      # synthesize cat_col = the FIRST category_equals value present on the line (codelist order keeps
      # first-match-wins), else NULL — column + values from config, not hardcoded. == treatment.py.
      cat_sql <- paste0("CASE ",
        paste(vapply(cat_values, function(v)
          sprintf("WHEN max(CASE WHEN lower(`%s`) = '%s' THEN 1 ELSE 0 END) = 1 THEN '%s'",
                  cat_col, gsub("'", "''", v), gsub("'", "''", v)), character(1)), collapse = " "),
        " ELSE CAST(NULL AS STRING) END")
      epi <- de %>% dplyr::group_by(patientid, linenumber) %>%
        dplyr::summarise(epi_lastdate = max(episodedate, na.rm = TRUE),
                         !!cat_col := dplyr::sql(cat_sql), .groups = "drop")
    } else {
      # no category column / no category_equals -> epi carries only epi_lastdate; the line keeps any
      # LOT-native category (episode wins ONLY when it sources one). == engine/stages/treatment.py.
      epi <- de %>% dplyr::group_by(patientid, linenumber) %>%
        dplyr::summarise(epi_lastdate = max(episodedate, na.rm = TRUE), .groups = "drop")
    }
  }

  lotn <- base %>%
    dplyr::left_join(dplyr::select(lot_norm, patientid, new_lot_n), by = "patientid") %>%
    dplyr::group_by(patientid) %>%
    dplyr::mutate(lotn = dplyr::sql("max(new_lot_n) over (partition by patientid)")) %>%
    dplyr::ungroup() %>%
    dplyr::select(patientid, index_date, lotn) %>% dplyr::distinct()
  bands <- trt_cfg[["lot_count_bands"]]
  if (!is.null(bands))
    lotn <- lotn %>% dplyr::mutate(
      lotngrl  = dplyr::sql(lot_bands_case(bands, "lotn", "label")),
      lotngrln = dplyr::sql(lot_bands_case(bands, "lotn", "code")))

  trt <- base
  mc <- cfg_lot_maintenance_column(cfg)
  # ALSO emit lot{i}m* (maintenance line) for tumors with maintenance cohorts. == treatment.py.
  emit_maint <- (mc %in% colnames(lot_norm)) &&
    any(vapply(cfg_cohorts(cfg), function(co) !is.null(co[["maintenance"]]), logical(1)))
  for (i in seq_len(trt_cfg[["max_lines"]])) {
    li <- lot_norm %>% dplyr::filter(new_lot_n == i)
    trt <- dplyr::left_join(trt, treatment_line_frame(li, i, FALSE, mc, epi, codelist), by = "patientid")
    if (emit_maint) {
      li_m <- li %>% dplyr::filter(dplyr::sql(sprintf("%s = 'True'", mc)))
      trt <- dplyr::left_join(trt, treatment_line_frame(li_m, i, TRUE, mc, epi, codelist), by = "patientid")
    }
  }

  # prior taxane flags — cohort-aware, prostate-specific (optional). == engine/stages/treatment.py.
  pt <- trt_cfg[["prior_taxane"]]
  if (!is.null(pt) && !is.null(cohort)) {
    yes <- pt[["yes_label"]] %||% "Yes"; no <- pt[["no_label"]] %||% "No"
    pred <- taxane_pred(pt[["drug_name_like_any"]])
    ln <- cohort[["lot_number"]]
    if (is.null(ln)) {
      trt <- dplyr::mutate(trt, prior_tax_mcrpc = no)
    } else if (ln == 1) {
      trt <- dplyr::mutate(trt, prior_tax_mcrpc = dplyr::sql("CAST(NULL AS STRING)"))
    } else {
      prior <- lot_norm %>%
        dplyr::filter(new_lot_n >= 1, new_lot_n < ln, dplyr::sql(sprintf("(%s)", pred))) %>%
        dplyr::distinct(patientid) %>% dplyr::mutate(`_ptm` = 1L)
      trt <- trt %>% dplyr::left_join(prior, by = "patientid") %>%
        dplyr::mutate(prior_tax_mcrpc = dplyr::sql(sprintf(
          "CASE WHEN `_ptm` IS NOT NULL THEN '%s' ELSE '%s' END", yes, no))) %>%
        dplyr::select(-`_ptm`)
    }
    pre_name <- pt[["pre_mcrpc_source"]]
    if (!is.null(pre_name) && !is.null(src[[pre_name]])) {
      ppt <- dplyr::select(idx, patientid, index_date) %>%
        dplyr::inner_join(dplyr::select(src[[pre_name]], patientid, linename, startdate), by = "patientid") %>%
        dplyr::filter(startdate <= index_date, dplyr::sql(sprintf("(%s)", pred))) %>%
        dplyr::distinct(patientid) %>% dplyr::mutate(`_ptp` = 1L)
      trt <- trt %>% dplyr::left_join(ppt, by = "patientid") %>%
        dplyr::mutate(prior_tax_pre_mcrpc = dplyr::sql(sprintf(
          "CASE WHEN `_ptp` IS NOT NULL THEN '%s' ELSE '%s' END", yes, no))) %>%
        dplyr::select(-`_ptp`)
    }
  }

  # Generic prior-treatment flags (PRIOR_*) — cohort-independent (any prior line, any setting). Optional.
  ptm <- trt_cfg[["prior_treatments"]]
  if (!is.null(ptm) && !is.null(ptm[["flags"]]))
    trt <- treatment_prior_treatments(trt, idx, src, cfg, ptm)

  # Concomitant/supportive-med exposure flags (BP / CSF / STEROID) — cohort-independent. Optional.
  cm <- trt_cfg[["conmed_exposures"]]
  if (!is.null(cm) && !is.null(cm[["flags"]]))
    trt <- treatment_conmed_exposures(trt, idx, src, cm)

  # Per-setting line columns (LOT*_MHSPC / LOT*_MCRPC). == treatment.py.
  slc <- trt_cfg[["setting_line_columns"]]
  if (!is.null(slc) && !is.null(slc[["settings"]]))
    trt <- dplyr::left_join(trt, treatment_setting_line_columns(src, idx, cfg, slc),
                            by = c("patientid", "index_date"))

  dplyr::left_join(trt, lotn, by = c("patientid", "index_date"))
}

# --- outcomes: id3mosfu + OS. engine/stages/outcomes.py ----------------------------------------
outcomes_build <- function(src, idx, clin, trt, cfg, cohort = NULL) {
  out_cfg <- cfg_pack(cfg, "outcomes")
  min_fu <- out_cfg[["min_followup_days"]]; dpm <- out_cfg[["days_per_month"]]
  end <- cfg$raw[["study"]][["index_end"]]
  keys <- c("patientid", "index_date")
  base <- dplyr::select(idx, patientid, index_date)
  out <- base %>% dplyr::mutate(id3mosfu = dplyr::sql(sprintf(
    "CASE WHEN datediff(date('%s'), index_date) >= %s THEN 1 ELSE 0 END", end, min_fu)))

  # Death/follow-up anchors (dthfl/dthdt/fued) feed BOTH OS and the line outcomes — join once.
  anchors <- intersect(c("dthfl", "dthdt", "fued"), if (is.null(clin)) character(0) else colnames(clin))
  if (length(anchors) > 0)
    out <- dplyr::left_join(out, dplyr::select(clin, dplyr::all_of(c(keys, anchors))), by = keys)

  os_cfg <- out_cfg[["overall_survival"]]
  if (!is.null(os_cfg)) {
    required <- c(os_cfg[["event_flag"]], os_cfg[["death_anchor"]], os_cfg[["censor_anchor"]])
    missing <- setdiff(required, if (is.null(clin)) character(0) else colnames(clin))
    if (length(missing) > 0)
      stop(sprintf(paste0("outcomes_build: clinical stage did not emit OS anchor column(s) %s ",
        "(from clinical_follow_up_and_death) — or remove overall_survival from outcomes.yaml."),
        paste(missing, collapse = ", ")))
    out <- out %>% dplyr::mutate(os = dplyr::sql(sprintf(paste0(
        "CASE WHEN id3mosfu = 0 THEN NULL ",
        "WHEN id3mosfu = 1 AND %s = 1 THEN (datediff(%s, index_date)+1)/%s ",
        "WHEN id3mosfu = 1 AND %s = 0 THEN (datediff(%s, index_date)+1)/%s ",
        "ELSE NULL END"),
        os_cfg[["event_flag"]], os_cfg[["death_anchor"]], dpm,
        os_cfg[["event_flag"]], os_cfg[["censor_anchor"]], dpm)))
  }
  emitted <- c("id3mosfu", if (!is.null(os_cfg)) "os")

  # Line-cohort outcomes (vis120/trtdis/ttd/ttntfl/ttnt). Optional + config-gated; == outcomes.py.
  lo <- out_cfg[["line_outcomes"]]
  if (!is.null(lo) && !is.null(trt)) {
    win <- out_cfg[["visit_recency_days"]]
    ln <- cohort[["lot_number"]]
    maint <- isTRUE(cohort[["maintenance"]])          # a lot{N}m cohort keys off the maintenance line
    if (!is.null(ln)) {
      cur <- line_cols(ln, maint); nxt <- line_cols(ln + 1)   # this line (maint-aware) + next (non-maint)
      nxt2 <- line_cols(ln + 2)
      has_next <- nxt$start %in% colnames(trt)
      has_n2 <- nxt2$start %in% colnames(trt)
      want <- c("lotn", cur$start, cur$lastdate, if (has_next) nxt$start,
                if (isTRUE(lo[["tsst"]]) && has_n2) nxt2$start)
      tcols <- intersect(want, colnames(trt))
      out <- dplyr::left_join(out, dplyr::select(trt, dplyr::all_of(c(keys, tcols))), by = keys)
      vis <- outcomes_vis120(src, dplyr::select(out, patientid, index_date, !!rlang::sym(cur$lastdate)),
                             lo, win, cur$lastdate)
      out <- dplyr::left_join(out, vis, by = keys)
      gate <- sprintf("id3mosfu = 1 AND %s IS NOT NULL", cur$start)
      out <- out %>% dplyr::mutate(
        trtdis = dplyr::sql(sprintf("CASE WHEN %s THEN (%s) ELSE NULL END", gate, trtdis_sql(ln))),
        ttntfl = dplyr::sql(sprintf("CASE WHEN id3mosfu = 1 THEN (%s) ELSE NULL END", ttntfl_sql(ln))),
        ttnt   = dplyr::sql(sprintf("CASE WHEN id3mosfu = 1 THEN (%s) ELSE NULL END",
                                    ttnt_sql(ln, dpm, has_next))))
      if (ln >= as.integer(lo[["ttd_from_line"]] %||% 1))
        out <- dplyr::mutate(out, ttd = dplyr::sql(sprintf(
          "CASE WHEN id3mosfu = 1 THEN (%s) ELSE NULL END", ttd_sql(ln, dpm, maint))))
      else
        out <- dplyr::mutate(out, ttd = dplyr::sql("CAST(NULL AS DOUBLE)"))
      if (isTRUE(lo[["tsst"]]))                          # time to 2nd subsequent treatment (TSST)
        out <- out %>% dplyr::mutate(
          tsstfl = dplyr::sql(sprintf("CASE WHEN id3mosfu = 1 THEN (%s) ELSE NULL END", tsstfl_sql(ln))),
          tsst   = dplyr::sql(sprintf("CASE WHEN id3mosfu = 1 THEN (%s) ELSE NULL END",
                                      tsst_sql(ln, dpm, has_n2))))
    } else {
      out <- out %>% dplyr::mutate(
        vis120 = 0L, lastvisitdate = dplyr::sql("CAST(NULL AS DATE)"),
        trtdis = dplyr::sql("CAST(NULL AS INT)"), ttntfl = dplyr::sql("CAST(NULL AS INT)"),
        ttd = dplyr::sql("CAST(NULL AS DOUBLE)"), ttnt = dplyr::sql("CAST(NULL AS DOUBLE)"))
      if (isTRUE(lo[["tsst"]]))
        out <- out %>% dplyr::mutate(tsstfl = dplyr::sql("CAST(NULL AS INT)"),
                                     tsst = dplyr::sql("CAST(NULL AS DOUBLE)"))
    }
    emitted <- c(emitted, "vis120", "lastvisitdate", "trtdis", "ttd", "ttntfl", "ttnt")
    if (isTRUE(lo[["tsst"]])) emitted <- c(emitted, "tsstfl", "tsst")
  }

  # Real-world PFS / PFS2 (progression family). Optional. == engine/stages/outcomes.py.
  pcfg <- out_cfg[["progression"]]
  if (!is.null(pcfg) && !is.null(src[[pcfg[["source"]]]])) {
    miss <- setdiff(c("dthdt", "fued"), colnames(out))
    if (length(miss) > 0)
      stop(sprintf(paste0("outcomes_build: progression PFS needs clinical anchor(s) %s ",
        "(from clinical_follow_up_and_death) — or remove progression from outcomes.yaml."),
        paste(miss, collapse = ", ")))
    is_line <- !is.null(cohort[["lot_number"]])
    suppress <- isTRUE(pcfg[["line_cohorts_only"]]) && !is_line
    # rwPFS censor: emit the RAW last clinic-note date (NULL when no clinic note); censor at
    # coalesce(clinic-note, fued). Keeping raw separate lets ELIGPFS require a note AFTER index. == outcomes.py.
    censor_anchor <- "fued"; ccfg <- pcfg[["censor"]]; clinic_raw <- NULL
    if (!is.null(ccfg) && !is.null(src[[ccfg[["source"]]]])) {
      cas <- ccfg[["as"]] %||% "lastclinicnotedate"; cdate <- ccfg[["date_column"]]
      aggf <- if (identical(ccfg[["aggregate"]], "min")) "min" else "max"
      censor_df <- src[[ccfg[["source"]]]] %>% dplyr::group_by(patientid) %>%
        dplyr::summarise(!!cas := dplyr::sql(sprintf("%s(%s)", aggf, cdate)), .groups = "drop")
      out <- dplyr::left_join(out, censor_df, by = "patientid") %>%                # cas = RAW clinic-note date
        dplyr::mutate(`_censor` = dplyr::sql(sprintf("coalesce(%s, fued)", cas)))  # censor anchor (fallback)
      censor_anchor <- "_censor"; clinic_raw <- cas
      emitted <- c(emitted, cas)
    }

    # rwPFS gate (== ELIGPFS): id3mosfu AND (when configured) a clinic note after index; drives BOTH the
    # eligibility flag and the PFS family so ineligible -> NULL throughout. Default (OC/EC) = id3mosfu only.
    gate <- "id3mosfu = 1"
    if (isTRUE(pcfg[["eligibility_requires_censor"]]) && !is.null(clinic_raw))
      gate <- sprintf("id3mosfu = 1 AND %s > index_date", clinic_raw)

    eflag <- pcfg[["eligibility_flag"]]                    # prostate ELIGPFS
    if (!is.null(eflag)) {
      out <- dplyr::mutate(out, !!eflag := dplyr::sql(
        if (is_line) sprintf("CASE WHEN %s THEN 1 ELSE 0 END", gate) else "CAST(NULL AS INT)"))
      emitted <- c(emitted, eflag)
    }
    out <- dplyr::left_join(out, outcomes_progression(src[[pcfg[["source"]]]], idx, pcfg, dpm), by = keys)
    specs <- list(c("pfsfl", "pfsdt", "pfs", "_prog1"), c("pfs2fl", "pfs2dt", "pfs2", "_prog2"))
    for (sp in specs) {
      if (identical(sp[3], "pfs2") && !isTRUE(pcfg[["pfs2"]])) next
      if (suppress) {                                       # overall cohort -> NULL family (column-aligned)
        out <- out %>%
          dplyr::mutate(!!sp[1] := dplyr::sql("CAST(NULL AS INT)")) %>%
          dplyr::mutate(!!sp[2] := dplyr::sql("CAST(NULL AS DATE)")) %>%
          dplyr::mutate(!!sp[3] := dplyr::sql("CAST(NULL AS DOUBLE)"))
      } else {
        # flag/date/months all gated on the rwPFS `gate` (== ELIGPFS); ineligible patients null throughout.
        out <- out %>%
          dplyr::mutate(`_evt` = dplyr::sql(sprintf("least(%s, dthdt)", sp[4]))) %>%
          dplyr::mutate(!!sp[1] := dplyr::sql(sprintf(
            "CASE WHEN %s AND `_evt` IS NOT NULL THEN 1 WHEN %s THEN 0 ELSE NULL END", gate, gate))) %>%
          dplyr::mutate(!!sp[2] := dplyr::sql(sprintf("CASE WHEN %s THEN coalesce(`_evt`, %s) ELSE NULL END", gate, censor_anchor))) %>%
          dplyr::mutate(!!sp[3] := dplyr::sql(sprintf(
            "CASE WHEN %s THEN (datediff(%s, index_date)+1)/%s ELSE NULL END", gate, sp[2], dpm))) %>%
          dplyr::select(-`_evt`)
      }
      emitted <- c(emitted, sp[1], sp[2], sp[3])
    }
    out <- dplyr::select(out, -`_prog1`, -`_prog2`)
  }
  dplyr::select(out, dplyr::all_of(c("patientid", "index_date", emitted)))
}

# First/second qualifying progression dates per (patientid, index_date). == outcomes.py::_progression.
outcomes_progression <- function(prog_df, idx, pcfg, dpm) {
  date_col <- pcfg[["date_column"]]
  excl <- as.integer(pcfg[["exclusion_days"]] %||% 0)      # progression > index + excl (rwPFS window)
  cutoff <- if (excl != 0) sprintf("date_add(index_date, %d)", excl) else "index_date"
  pred <- progression_pred(pcfg[["evidence_columns"]], pcfg[["pseudoprogression_column"]],
                           pcfg[["yes_value"]] %||% "Yes", pcfg[["no_value"]] %||% "No")
  base <- dplyr::select(idx, patientid, index_date)
  ev <- base %>% dplyr::inner_join(prog_df, by = "patientid") %>%
    dplyr::filter(dplyr::sql(sprintf("%s > %s", date_col, cutoff))) %>%
    dplyr::filter(dplyr::sql(sprintf("(%s)", pred))) %>%
    dplyr::select(patientid, index_date, !!rlang::sym(date_col)) %>%
    dplyr::distinct() %>%                                  # collapse same-day duplicate evidence rows
    dplyr::group_by(patientid, index_date) %>%
    dbplyr::window_order(!!rlang::sym(date_col)) %>%
    dplyr::mutate(`_pr` = dplyr::row_number()) %>% dplyr::ungroup()
  out <- base
  for (rn in 1:2) {
    alias <- paste0("_prog", rn)
    d <- ev %>% dplyr::filter(`_pr` == rn) %>%
      dplyr::transmute(patientid, index_date, !!alias := !!rlang::sym(date_col))
    out <- dplyr::left_join(out, d, by = c("patientid", "index_date"))
  }
  out
}

# vis120 / lastvisitdate for a line cohort. == engine/stages/outcomes.py::_vis120.
outcomes_vis120 <- function(src, base_end, lo, win, end_col) {
  keys <- c("patientid", "index_date")
  vsrcs <- Filter(function(s) !is.null(src[[s]]), lo[["visit_sources"]] %||% list())
  vdate <- lo[["visit_date_column"]] %||% "visitdate"
  if (length(vsrcs) == 0)
    return(base_end %>% dplyr::select(dplyr::all_of(keys)) %>%
             dplyr::mutate(vis120 = 0L, lastvisitdate = dplyr::sql("CAST(NULL AS DATE)")))
  enc <- NULL
  for (s in vsrcs) {                                   # union encounter dates across sources
    e <- src[[s]] %>% dplyr::transmute(patientid, `_vd` = !!rlang::sym(vdate))
    enc <- if (is.null(enc)) e else sparklyr::sdf_bind_rows(enc, e)
  }
  qualifying <- base_end %>% dplyr::left_join(enc, by = "patientid") %>%
    dplyr::filter(dplyr::sql(sprintf("`_vd` >= date_add(%s, %s)", end_col, win))) %>%
    dplyr::group_by(patientid, index_date) %>%
    dplyr::summarise(lastvisitdate = max(`_vd`, na.rm = TRUE), .groups = "drop")
  base_end %>% dplyr::select(dplyr::all_of(keys)) %>%
    dplyr::left_join(qualifying, by = keys) %>%
    dplyr::mutate(vis120 = dplyr::sql("CASE WHEN lastvisitdate IS NOT NULL THEN 1 ELSE 0 END"))
}

# --- assemble one cohort's ADS. engine/stages/assemble.py --------------------------------------
assemble_build <- function(idx, dem, clin, trt, out, cfg, cohort, treated) {
  keys <- c("patientid", "index_date")
  ts <- cfg$raw[["treatment_status"]]
  # Per-setting COHORTU/COHORTUN for a dual-setting product (treatment_status.by_setting keyed on the
  # cohort's lower-cased line_setting); else the flat treated/untreated labels, codes 1/2. == assemble.py.
  sts <- (ts[["by_setting"]] %||% list())[[tolower(cohort[["line_setting"]] %||% "")]] %||% ts
  tlabel <- sts[["treated_label"]]; ulabel <- sts[["untreated_label"]]
  tcode  <- sts[["treated_code"]] %||% 1L; ucode <- sts[["untreated_code"]] %||% 2L
  ads <- idx %>%
    dplyr::left_join(dem,  by = keys) %>%
    dplyr::left_join(clin, by = keys) %>%
    dplyr::left_join(trt,  by = keys) %>%
    dplyr::left_join(out,  by = keys) %>%
    dplyr::left_join(treated, by = "patientid") %>%
    dplyr::mutate(
      cohort   = cohort[["label"]],
      cohortn  = cohort[["cohortn"]],
      cohortu  = dplyr::sql(sprintf("CASE WHEN treat_flag IS NOT NULL THEN %s ELSE %s END",
                                    .q(tlabel), .q(ulabel))),
      cohortun = dplyr::sql(sprintf("CASE WHEN treat_flag IS NOT NULL THEN %d ELSE %d END",
                                    as.integer(tcode), as.integer(ucode))),
      data_product_id = cfg_data_product_id(cfg),   # product self-id (== assemble.py)
      spec_version = cfg_spec_version(cfg),   # CalVer contract only (202606), NOT the snapshot-filled
      data_refresh = cfg_refresh(cfg))        # version — matches assemble.py / refresh.py / dashboard.py
  # Cohort-indexed line category (lotN / lotNm / line 1 for overall). == engine/stages/assemble.py.
  ln <- cohort[["lot_number"]]
  suffix <- if (isTRUE(cohort[["maintenance"]])) "m" else ""
  cat_col  <- if (!is.null(ln)) paste0("lot", ln, suffix, "cat")  else "lot1cat"
  catn_col <- if (!is.null(ln)) paste0("lot", ln, suffix, "catn") else "lot1catn"
  if (cat_col %in% colnames(ads))
    ads <- ads %>% dplyr::mutate(lotcat  = !!rlang::sym(cat_col),
                                 lotcatn = !!rlang::sym(catn_col))
  dplyr::distinct(ads)
}

# OC platinum-sensitivity. Per-(patient, linenumber) pfi/plat_sen/pcycled. == proc.py::_plat_sen_table.
proc_plat_sen_table <- function(lot_df, pcfg, dpm) {
  lnc <- pcfg[["line_number_column"]]; nmc <- pcfg[["name_column"]]
  sdc <- pcfg[["start_column"]]; edc <- pcfg[["end_column"]]
  window <- pcfg[["pfi_window_days"]] %||% 14
  thr    <- pcfg[["threshold_months"]] %||% 6
  lines <- lot_df %>% dplyr::transmute(
    patientid, linenumber = as.integer(!!rlang::sym(lnc)),
    `_sd` = !!rlang::sym(sdc), `_ed` = !!rlang::sym(edc),
    `_isplat` = dplyr::sql(platinum_pred(pcfg[["platinum_agents"]], nmc)))
  plat <- lines %>% dplyr::filter(`_isplat`) %>%
    dplyr::transmute(patientid, `_pln` = linenumber, `_ped` = `_ed`)
  prior <- lines %>% dplyr::inner_join(plat, by = "patientid") %>%
    dplyr::filter(dplyr::sql(sprintf("`_pln` < linenumber AND `_ped` < date_add(`_sd`, %s)", window))) %>%
    dplyr::group_by(patientid, linenumber) %>%
    dplyr::summarise(`_prior_end` = max(`_ped`, na.rm = TRUE), .groups = "drop")
  lines %>% dplyr::select(patientid, linenumber, `_sd`, `_isplat`) %>% dplyr::distinct(patientid, linenumber, .keep_all = TRUE) %>%
    dplyr::left_join(prior, by = c("patientid", "linenumber")) %>%
    dplyr::mutate(
      pfi = dplyr::sql(sprintf(
        "CASE WHEN `_prior_end` IS NULL THEN NULL ELSE datediff(`_sd`, `_prior_end`)/%s END", dpm)),
      plat_sen = dplyr::sql(sensitivity_case(thr)),
      pcycled  = dplyr::sql("CASE WHEN `_isplat` AND `_prior_end` IS NOT NULL THEN 1 ELSE 0 END")) %>%
    dplyr::select(patientid, linenumber, pfi, plat_sen, pcycled)
}

# plat_sen_v1/v2/pfi/pcycled for a line cohort (NULL when not applicable). == proc.py::build.
proc_build <- function(src, idx, cfg, cohort) {
  pcfg <- cfg_pack(cfg, "outcomes")[["platinum_sensitivity"]]
  if (is.null(pcfg) || is.null(src[[pcfg[["source"]]]])) return(NULL)
  ln <- cohort[["lot_number"]]
  if (is.null(ln) || ln < (pcfg[["from_line"]] %||% 2)) return(NULL)
  dpm <- cfg_pack(cfg, "outcomes")[["days_per_month"]]
  tbl <- proc_plat_sen_table(src[[pcfg[["source"]]]], pcfg, dpm)
  cur  <- tbl %>% dplyr::filter(linenumber == ln) %>%
    dplyr::transmute(patientid, plat_sen_v1 = plat_sen, pfi, pcycled)
  prev <- tbl %>% dplyr::filter(linenumber == ln - 1) %>%
    dplyr::transmute(patientid, plat_sen_v2 = plat_sen)
  idx %>% dplyr::select(patientid, index_date) %>%
    dplyr::left_join(cur, by = "patientid") %>% dplyr::left_join(prev, by = "patientid")
}

# --- ads_derived: cross-stage derivations over the ASSEMBLED cohort frame -----------------------
# == engine/stages/ads_derived.py::build. Runs after assemble+proc, when every stage's columns sit
# on one frame; an item whose `requires` columns are absent in this cut is skipped (same graceful
# contract as clinical `derived`). The compiled SQL comes from cases.R (interval_expr /
# landmark_case), parity-proven against the Python compilers.
ads_derived_build <- function(cohort_ads, cfg) {
  out_cfg <- cfg_pack(cfg, "outcomes")
  items <- out_cfg[["ads_derived"]]
  if (is.null(items) || length(items) == 0) return(cohort_ads)
  dpm <- as.numeric(out_cfg[["days_per_month"]] %||% 30.4375)
  study <- cfg$raw[["study"]]
  have <- colnames(cohort_ads)
  for (it in items) {
    if (!all(unlist(it[["requires"]]) %in% have)) next
    name <- it[["name"]]
    if (!is.null(it[["expr"]])) {
      expr <- gsub("\\{index_start\\}", sprintf("date('%s')", study[["index_start"]]), it[["expr"]])
      expr <- gsub("\\{index_end\\}", sprintf("date('%s')", study[["index_end"]]), expr)
      cohort_ads <- dplyr::mutate(cohort_ads, !!name := dplyr::sql(expr))
    } else if (!is.null(it[["interval"]])) {
      iv <- it[["interval"]]
      cohort_ads <- dplyr::mutate(cohort_ads, !!name := dplyr::sql(
        interval_expr(iv[["from"]], iv[["to"]], iv[["unit"]] %||% "months", dpm)))
      if (!is.null(it[["bands"]])) {
        cohort_ads <- dplyr::mutate(
          cohort_ads,
          !!paste0(name, "gr") := dplyr::sql(num_bands_case(it[["bands"]], name, "label")),
          !!paste0(name, "grn") := dplyr::sql(num_bands_case(it[["bands"]], name, "code")))
      }
    } else {
      lm <- it[["landmark"]]
      cohort_ads <- dplyr::mutate(
        cohort_ads,
        !!name := dplyr::sql(landmark_case(lm[["anchor"]], lm[["horizon_days"]], lm[["events"]],
                                           lm[["censor"]][["date"]], lm[["labels"]], "label")),
        !!paste0(name, "n") := dplyr::sql(landmark_case(lm[["anchor"]], lm[["horizon_days"]],
                                           lm[["events"]], lm[["censor"]][["date"]],
                                           lm[["labels"]], "code")))
    }
    have <- c(have, name)
  }
  cohort_ads
}
