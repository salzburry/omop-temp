# R (sparklyr) mirror of engine/build_ads.py — orchestrate a tumor's ADS build from its config.
# REVIEW-ONLY (needs sparklyr + yaml on a Spark cluster). See the parity contract in stages.R.
#
# Load order (caller sources first): vendors.R, config.R, codelists.R, cases.R, stages.R, build_ads.R

`%||%` <- function(a, b) if (is.null(a)) b else a

# Union two tbl_spark BY NAME, filling missing columns with NULL of the CORRECT type — the analogue
# of PySpark unionByName(..., allowMissingColumns=True). The "overall" cohort lacks the LOT line/index
# columns (linenumber/startdate/new_lot_n/...) that lotN cohorts carry. sparklyr::sdf_bind_rows aligns
# by column NAME and fills the missing columns with a TYPED NA (so a date/int column present in the
# other cohort is null-filled as date/int, not coerced to string) — matching unionByName's schema.
union_by_name <- function(a, b) sparklyr::sdf_bind_rows(a, b)

# Build and return the unioned ADS (one tbl_spark) for all configured cohorts. == build_ads.py::build.
build_ads <- function(sc, cfg) {
  src <- load_sources(sc, cfg)

  # Treated = a patient with >=1 line in the cohort's RELEVANT setting, using the SAME LOT model as
  # index/treatment (line_setting + exclude_settings + line_number_col) but NO maintenance filter.
  # Derived PER COHORT off the cohort's line_setting so a dual-setting product gets per-setting COHORTU;
  # single-setting tumors fall back to the global lot.line_setting (unchanged). == build_ads.py.
  ads <- NULL
  for (cohort in cfg_cohorts(cfg)) {
    treated <- lot_normalized(src, cohort[["line_setting"]] %||% cfg_lot_line_setting(cfg),
                              exclude_settings   = cfg_lot_exclude_settings(cfg),
                              line_number_col    = cfg_lot_line_number_col(cfg),
                              maintenance_column = cfg_lot_maintenance_column(cfg)) %>%
      dplyr::select(patientid) %>% dplyr::distinct() %>%
      dplyr::mutate(treat_flag = 1L)
    idx  <- index_build(src, cfg, cohort)
    dem  <- demographics_build(src, idx, cfg)
    clin <- clinical_build(src, idx, cfg)
    trt  <- treatment_build(src, idx, cfg, cohort)             # cohort -> prior-taxane flags
    out  <- outcomes_build(src, idx, clin, trt, cfg, cohort)   # cohort -> line N for the line outcomes
    cohort_ads <- assemble_build(idx, dem, clin, trt, out, cfg, cohort, treated)
    ps <- proc_build(src, idx, cfg, cohort)                    # OC platinum-sensitivity (2L+ cohorts)
    if (!is.null(ps)) cohort_ads <- dplyr::left_join(cohort_ads, ps, by = c("patientid", "index_date"))
    cohort_ads <- ads_derived_build(cohort_ads, cfg)           # cross-stage derivations (== Python)
    ads <- if (is.null(ads)) cohort_ads
           else union_by_name(ads, cohort_ads)   # name-aligned, NULL-filled (== unionByName)
  }
  if (!is.null(ads)) ads <- apply_derived_cohorts(ads, cfg)   # OC PROC split (cohortn 9)
  ads
}

# Append each derived cohort: rows of its `from` cohorts (by cohortn) matching `where`, relabeled with
# the derived cohort's cohort/cohortn. == build_ads.py::_apply_derived_cohorts.
apply_derived_cohorts <- function(ads, cfg) {
  dcs <- cfg$raw[["derived_cohorts"]] %||% list()
  cohorts <- cfg_cohorts(cfg)
  id_to_n <- setNames(lapply(cohorts, function(c) c[["cohortn"]]),
                      vapply(cohorts, function(c) c[["id"]], ""))
  for (dc in dcs) {
    from_ns <- unlist(id_to_n[unlist(dc[["from"]])], use.names = FALSE)
    sub <- ads %>% dplyr::filter(cohortn %in% from_ns) %>% dplyr::filter(dplyr::sql(dc[["where"]]))
    if (identical(dc[["pick"]], "first")) {      # earliest qualifying line per patient (== build_ads.py)
      sub <- sub %>% dplyr::group_by(patientid) %>% dbplyr::window_order(index_date) %>%
        dplyr::mutate(`_rn` = dplyr::row_number()) %>% dplyr::ungroup() %>%
        dplyr::filter(`_rn` == 1) %>% dplyr::select(-`_rn`)
    }
    sub <- sub %>% dplyr::mutate(cohort = dc[["label"]], cohortn = dc[["cohortn"]])
    ads <- union_by_name(ads, sub)
  }
  ads
}

# Spark connection SEAM — environment-agnostic. Default is a Databricks-managed cluster (unchanged
# behaviour); override for Domino / YARN / standalone / local Spark via method + master. run_rwdp.R
# exposes --spark_method / --spark_master / --spark_version (env: SPARK_METHOD / SPARK_MASTER /
# SPARK_VERSION); a Databricks R notebook can call this directly.
#   Databricks (default):   connect_spark()                          # method="databricks", no master
#   Domino / generic YARN:  connect_spark(master = "yarn")           # -> sparklyr "shell" + master
#   Local single node:      connect_spark(master = "local[*]")
#   Livy (remote gateway):  connect_spark("livy", "https://livy:8998")
# The rest of the engine is connection-agnostic: it reads/writes CATALOG tables (dplyr::tbl(sc, fqn)
# / spark_write_table), so any Spark whose catalog (Hive metastore / Unity / Glue) exposes
# {source_schema}.{table} and accepts the {output_schema}.{output_table} write works unchanged.
connect_spark <- function(method = Sys.getenv("SPARK_METHOD", "databricks"),
                          master = Sys.getenv("SPARK_MASTER", ""),
                          version = Sys.getenv("SPARK_VERSION", ""),
                          config = sparklyr::spark_config()) {
  # Databricks-managed cluster: the zero-config default (the cluster injects the master).
  if (identical(method, "databricks") && !nzchar(master)) {
    return(sparklyr::spark_connect(method = "databricks", config = config))
  }
  # Otherwise connect by master (Domino/YARN/standalone/local/Livy). A master supplied with the
  # default 'databricks' method means "generic Spark" -> use sparklyr's default 'shell' method.
  if (identical(method, "databricks")) method <- "shell"
  argl <- list(master = if (nzchar(master)) master else "local", method = method, config = config)
  if (nzchar(version)) argl$version <- version
  do.call(sparklyr::spark_connect, argl)
}

# Persist the ADS to {output_schema}.{output_table}. Returns the table FQN. == build_ads.py::write_ads.
write_ads <- function(sc, ads, cfg) {
  fqn <- cfg_output_fqn(cfg)
  sparklyr::spark_write_table(ads, fqn, mode = cfg_write_mode(cfg),
                              options = list(overwriteSchema = "true"))
  fqn
}
