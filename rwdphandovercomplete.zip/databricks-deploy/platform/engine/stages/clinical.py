"""Stage: clinical characteristics. Ports clin_char_master() and its sub-functions.

Implemented: baseline ECOG (clin_char_ecog_var); the follow-up-end / death-date anchors
(clin_char_fuend_dthdt_var) that OS depends on; enhanced vars — stage grouping plus the generic
value->group categoricals (grade/histology/TNM/…); closest-to-index biomarker & lab PANELS
(numeric lab bands use a try_cast numeric expression); vitals (BMI, + BSA when configured); and the prostate-specific
gleason/PSA/mCRPC pass-throughs. Every window, band, grouping and imputation rule comes from
variables/clinical.yaml so it is reviewable config, and each block is added only when its source
columns exist — a tumor that doesn't declare a block simply omits those columns.

NOTE on the death/follow-up port: the original R for this section carried author "Before/After"
and "seem to be wrong" comments and was mid-revision. This is a faithful port of the
straightforward interpretation (coarse-date imputation from config; cap follow-up at death;
snap a same-month death to month end alongside last_lotenddate). Confirm against the original
R ADS in the golden comparison before treating OS as final.
"""
from __future__ import annotations

import re

try:                                     # package import
    from .. import grain
except ImportError:                      # engine/ on sys.path (validate.py, test_blocks, R parity)
    import grain

# The SQL string quoter is shared with the codelist compiler, so a value map and a codelist cannot
# quote a pattern differently. `test_r_parity` asserts `clinical._q is codelists.sql_str`.
#
# Both import spellings are needed: this module is loaded under two package roots. `engine/
# validate.py` imports it as `stages.clinical` with `engine/` on sys.path; `engine/stages/
# treatment.py` imports it as a subpackage. A relative import alone breaks every caller of the
# first kind.
try:                                     # imported as engine.stages.clinical
    from ..codelists import sql_str as _q, sequence_error as _sequence_error
except ImportError:                      # imported as stages.clinical, engine/ on sys.path
    from codelists import sql_str as _q, sequence_error as _sequence_error  # noqa: F401

# EVERY list-valued field in this module, named in one place. The scalar/list defect was fixed for
# the codelist operators and left standing here, so the fix has to be keyed on the field name
# rather than on the call site that happened to be reported.
SEQUENCE_FIELDS = ("from_prefixes", "from_equals_ci", "from_startswith_ci", "from_contains_ci",
                   "from_regex", "match_any", "priority", "units")


def _num_bands_case(bands, col, key="label"):
    """CASE over numeric bands with a fallthrough (BMI groups; lab value bands).

    Per band, any of: min (>=), min_excl (>), max_excl (<), max (<=). Conditions are emitted in
    this fixed order so the R compiler (cases.R::num_bands_case) stays byte-identical. min_excl lets
    a band express a strict lower bound (e.g. a lab `value > 0` "Measured" status).
    """
    whens = []
    for b in bands:
        if b.get("when") == "fallthrough":
            continue
        out = _q(b[key]) if key == "label" else str(b[key])
        conds = []
        if "min" in b:
            conds.append(f"{col} >= {b['min']}")
        if "min_excl" in b:
            conds.append(f"{col} > {b['min_excl']}")
        if "max_excl" in b:
            conds.append(f"{col} < {b['max_excl']}")
        if "max" in b:
            conds.append(f"{col} <= {b['max']}")
        if conds:
            whens.append(f"WHEN {' AND '.join(conds)} THEN {out}")
    default = next((b for b in bands if b.get("when") == "fallthrough"), None)
    tail = f" ELSE {_q(default[key]) if key == 'label' else default[key]}" if default else ""
    return "CASE " + " ".join(whens) + tail + " END"


# HOW A GROUP CLAIMS A RAW VALUE. The second half of the "only YAML edits" question, after record
# selection: G-STAGE-PREFIX, G-GLEASON-MAP, G-BIOMARKER-NEG and G-STAGE-MISSING are all one shape —
# a value-to-group map whose operator or missing rule the config could not state.
#
# Named, like MATCH_OPERATORS in codelists and for the same reason: config names an operator, the
# engine owns the SQL. `_stage_case` is compiled IDENTICALLY in engine-r/cases.R and the two are held
# byte-identical by test_r_parity, so an operator added here must be added there in the same change.
VALUE_MATCHERS = {
    "from_prefixes":      "exact match on any listed value (case-SENSITIVE; the legacy spelling)",
    "from_equals_ci":     "case-insensitive equality with any listed value",
    "from_startswith_ci": "case-insensitive prefix — the LONGEST matching prefix wins, whatever "
                          "order the groups are written in",
    "from_contains_ci":   "case-insensitive substring",
    # THE ESCAPE HATCH, AND LAST BECAUSE IT IS ONE. The four above say what they match in their own
    # name, so a reviewer reads the group and knows the rule. A regex does not: it is a small
    # program in a YAML cell, and reviewing it is a different and harder act. Reach for a named
    # operator whenever one expresses the rule — an enumerated `from_equals_ci`, a prefix collapse
    # via `from_startswith_ci` — and use this only where none can: anchoring, alternation, or
    # tolerance of whitespace and punctuation the feed varies (`3+4=7` beside `3 + 4 = 7`).
    #
    # CASE-SENSITIVE, and the pattern is passed through UNTOUCHED. Every other operator here
    # lowercases both sides; a regex must not be lowercased, because `\D` `\S` `\W` `\B` are the
    # NEGATIONS of `\d` `\s` `\w` `\b` and case-folding silently inverts them. Write `(?i)` for
    # case-insensitivity — Java's inline flag, verified working on Spark.
    "from_regex":         "the value matches this Java/Spark regular expression, applied verbatim "
                          "and case-SENSITIVELY — write a leading (?i) for case-insensitive",
}
# Two RESERVED group markers, which are not matchers: `fallthrough` is the ELSE, `missing` fires when
# the value IS NULL. They are different answers: a null stage
# and an unmapped stage value are different facts; collapsing them is gap G-STAGE-MISSING.
GROUP_MARKERS = ("fallthrough", "missing")

# Selection keys an ITEM may not state. `pick` and `tie_break` are resolved per item by
# `_selection_spec` — a panel is a set of different questions sharing one source. The record DATE is
# not: `_record_date_expr` computes one `_rdate` for the whole pulled block, so a per-item basis has
# nowhere to land and would be accepted and ignored.
BLOCK_ONLY = ("date_basis",)

# THE CLOSEST-TO-INDEX PANEL BLOCKS, named once. `_closest_panel` is generic — a long table with a
# name column and a value column, windowed around index, each item's value mapped through the same
# CASE compiler — and the only thing that decided which config keys reached it was this tuple,
# spelled out in SIX places (this stage, three checks in validate, the dashboard, and the R engine).
# A seventh family could be added to five of them and silently do nothing in the sixth.
#
# `response` is here because the machinery it needs already existed: real-world response is a
# clinician-documented category at an assessment date, and BEST response across a window is exactly
# `pick: priority` — the same ranking that rolls a multi-gene HRR panel up to its worst-case status,
# with the order reading CR > PR > SD > PD instead. What it additionally needs is the assessment
# DATE, which `emit_date` adds per block (biomarkers and labs do not set it, so their output is
# unchanged to the byte).
CLOSEST_PANELS = ("biomarkers", "labs", "response")


def value_matcher_errors(groups, where=""):
    """[why this value map is not a value map] — an unrecognised `from_*` key, or a group with no way
    to match at all.

    THE FAIL-OPEN THIS CLOSES. `_stage_case` reads the operators it knows and ignores every other
    key, so `from_startwith_ci` (one letter short) compiled to `CASE  ELSE 'CHECK' END` — a group
    that claims nothing, silently, and every patient landing in the fallthrough. Nothing failed;
    STAGE simply became CHECK for the whole product. An operator vocabulary that is not enforced is
    a suggestion.

    A group carrying ONLY a marker (`fallthrough` / `missing`) is fine — those are the two groups
    that match by position rather than by value.
    """
    why = []
    for i, g in enumerate(groups or []):
        tag = f"{where}groups[{i}]" if where else f"groups[{i}]"
        unknown = [k for k in g if k.startswith("from_") and k not in VALUE_MATCHERS]
        for k in sorted(unknown):
            why.append(f"{tag}: '{k}' is not a value matcher — one of "
                       f"{', '.join(sorted(VALUE_MATCHERS))}")
        if g.get("when") is not None:
            if g["when"] not in GROUP_MARKERS:
                # `when: fallthrouhg` is ignored exactly like a mistyped matcher: the group stops
                # being the ELSE and every unmatched value goes to whatever follows, or to NULL.
                why.append(f"{tag}: when: {g['when']!r} is not a group marker — one of "
                           f"{', '.join(GROUP_MARKERS)}")
                continue
            # A MARKER GROUP MATCHES BY POSITION, AND `_stage_case` SKIPS IT ENTIRELY. So a group
            # carrying both a marker and a `from_*` list states two ways of claiming a value and
            # only one of them runs — the same fail-open as a mistyped operator, wearing a valid
            # key. Refused rather than picked between: which one the author meant is not derivable.
            also = sorted(k for k in g if k in VALUE_MATCHERS and g.get(k))
            if also:
                why.append(f"{tag}: `when: {g['when']}` matches by POSITION, so {', '.join(also)} "
                           f"is never evaluated. Give this group a marker or matchers, not both.")
            dupes = [j for j, o in enumerate(groups) if j < i and o.get("when") == g["when"]]
            if dupes:
                why.append(f"{tag}: a second `when: {g['when']}` group — groups[{dupes[0]}] already "
                           f"claims it, and only the first is emitted. The later one is dead.")
            continue
        if not any(g.get(k) for k in VALUE_MATCHERS) and not unknown:
            why.append(f"{tag}: no matcher and no marker — it can never claim a value. Give it one "
                       f"of {', '.join(sorted(VALUE_MATCHERS))}, or `when: fallthrough|missing`.")
        why += _regex_errors(g.get("from_regex"), tag)
    return why


def _regex_errors(patterns, tag):
    """[why these patterns are not usable]. A malformed regex must fail HERE, not on a cluster.

    Spark raises on a bad pattern at RUNTIME, part-way through a build, with a stack trace naming
    java.util.regex and not the config key that carried it. Config-lint is where the author is.

    A blank pattern is refused separately because it is not a syntax error: `''` compiles fine and
    matches EVERY value, so the group silently swallows the whole column — the widest possible
    fail-open, from an empty YAML cell.

    THE LIMIT, stated because it is real: the runtime engine is java.util.regex and this check is
    Python's `re`. They agree on ordinary patterns and on every malformation worth catching
    (unbalanced parens or classes, a dangling quantifier, a bad escape), but Java has constructs
    Python lacks — `\\p{...}` classes, possessive quantifiers. Such a pattern is REFUSED here even
    though Spark would run it. That is deliberate: this framework fails closed, and a pattern the
    two engines' toolchains disagree about is a thing to raise, not to wave through. The message
    says so, so the refusal is diagnosable rather than mysterious.
    """
    why = []
    for i, p in enumerate(patterns or []):
        where = f"{tag}: from_regex[{i}]"
        if not str(p).strip():
            why.append(f"{where} is blank — an empty pattern matches EVERY value, so this group "
                       f"would claim the whole column. Remove it or write a pattern.")
            continue
        try:
            re.compile(str(p))
        except re.error as e:
            why.append(f"{where} {str(p)!r} is not a valid regular expression: {e}. (Checked with "
                       f"Python's `re`; Spark runs java.util.regex. A pattern valid in Java but not "
                       f"in Python — \\p{{...}}, possessive quantifiers — is refused here on "
                       f"purpose; raise it rather than working around it.)")
    return why


def _stage_case(groups, col, key="label"):
    """CASE mapping a raw value to its configured group.

    ORDER OF THE EMITTED WHENs, which is the whole semantics:
      1. `when: missing`      -> IS NULL, first, so a null is never tested against a text operator
      2. EXACT operators      -> from_prefixes / from_equals_ci, in config order (unchanged)
      3. from_startswith_ci   -> LONGEST prefix first, across all groups
      4. from_contains_ci     -> config order
      5. from_regex           -> config order, LAST because it is the most general
      6. `when: fallthrough`  -> the ELSE

    Exact before prefix before substring before regex, because a value that a group claims exactly
    should not be taken by another group that merely starts the same way. Longest-prefix is resolved by SORTING
    rather than by asking authors to write their groups in the right order, so adding a group
    cannot silently change which one claims a value.

    Existing packs use only (2) and (5), so their SQL is byte-identical to before; `test_r_parity`
    compares this string against engine-r/cases.R and would fail otherwise.
    """
    def out_of(g):
        return _q(g[key]) if key == "label" else str(g[key])

    whens, prefixes = [], []
    miss = next((g for g in groups if g.get("when") == "missing"), None)
    if miss is not None:
        whens.append(f"WHEN {col} IS NULL THEN {out_of(miss)}")
    for g in groups:
        if g.get("when") in GROUP_MARKERS:
            continue
        conds = []
        # REFUSE A SCALAR BEFORE IT BECOMES SQL. Every one of these is iterated below, so a bare
        # string becomes a per-character predicate that runs, returns the wrong cohort, and matches
        # nothing R would build from the same config.
        for _f in SEQUENCE_FIELDS:
            if _f in g and g.get(_f) is not None:
                _why = _sequence_error(_f, g[_f])
                if _why:
                    raise ValueError(_why)
        if g.get("from_prefixes"):
            conds.append(f"{col} IN ({', '.join(_q(v) for v in g['from_prefixes'])})")
        if g.get("from_equals_ci"):
            conds.append(f"LOWER({col}) IN ({', '.join(_q(str(v).lower()) for v in g['from_equals_ci'])})")
        if conds:
            whens.append(f"WHEN ({' OR '.join(conds)}) THEN {out_of(g)}")
        for p in (g.get("from_startswith_ci") or []):
            prefixes.append((len(str(p)), str(p), g))
    # Longest prefix first; length descending, then the prefix itself so the SQL is deterministic
    # rather than dependent on dict iteration for two prefixes of equal length.
    for _n, p, g in sorted(prefixes, key=lambda t: (-t[0], t[1])):
        whens.append(f"WHEN LOWER({col}) LIKE {_q(p.lower() + '%')} THEN {out_of(g)}")
    for g in groups:
        if g.get("when") in GROUP_MARKERS:
            continue
        for c in (g.get("from_contains_ci") or []):
            whens.append(f"WHEN LOWER({col}) LIKE {_q('%' + str(c).lower() + '%')} THEN {out_of(g)}")
    # REGEX LAST of the matchers, because it is the most general: a pattern that would also claim a
    # value some named operator claims exactly must not take it first. Same principle as exact
    # before prefix before substring, one step further out.
    for g in groups:
        if g.get("when") in GROUP_MARKERS:
            continue
        for r in (g.get("from_regex") or []):
            whens.append(f"WHEN {col} REGEXP {_q(str(r))} THEN {out_of(g)}")
    default = next((g for g in groups if g.get("when") == "fallthrough"), None)
    tail = f" ELSE {out_of(default)}" if default else ""
    return "CASE " + " ".join(whens) + tail + " END"


def _categorical_pick(F, Window, src_df, column, groups, name, date_column=None, pick="latest"):
    """One deterministic row per patient of `column`, mapped via _stage_case -> name / <name>n.

    Generalises the staging pick (stage IS the categorical named 'stage' on 'groupstage') so any
    value->group clinical characteristic (grade / histology / …) reuses the SAME parity-proven
    _stage_case compiler. Tie-break: by date_column (latest/earliest) when present, then the value.
    """
    order, sel = [], ["patientid", column]
    if date_column and date_column in src_df.columns:
        order.append(F.col(date_column).desc() if pick == "latest" else F.col(date_column).asc())
        sel.append(date_column)
    order.append(F.col(column).asc_nulls_last())                # deterministic tiebreak
    w = Window.partitionBy("patientid").orderBy(*order)
    return (src_df.select(*sel).withColumn("_rn", F.row_number().over(w)).filter(F.col("_rn") == 1)
            .withColumn(name, F.expr(_stage_case(groups, column, "label")))
            .withColumn(name + "n", F.expr(_stage_case(groups, column, "code")))
            .select("patientid", name, name + "n"))


def _categorical_pick_windowed(F, Window, src_df, cat, idx):
    """A categorical picked from a window AROUND INDEX, rather than one row per patient ever.

    `_categorical_pick` answers "this patient's value" — latest or earliest across all time. Some
    characteristics are not that question. Payer category is the standard case: the coverage record
    that matters is the one in force AT INDEX, and a patient's coverage two years later says nothing
    about the line they started. Same shape as the closest-to-index panels, on a WIDE column rather
    than a long name/value table, which is why neither existing family reached it.

    KEYED ON (patientid, index_date), NOT patientid. That is the whole reason this is a separate
    function rather than a flag on the other one: the window is relative to index, so a patient in
    two cohorts has two index dates and can legitimately have two different answers. Returning a
    per-patient row here would silently broadcast one cohort's payer across the other.

    Ordering comes from `_selection_order` — the same `pick`/`tie_break` vocabulary the panels use,
    not a third spelling of the same question. == engine-r/stages.R (categoricals loop, windowed).
    """
    col, name = cat["column"], cat["name"]
    lo, hi = (cat.get("window_days") or [None, None])
    date_col = cat["date_column"]                 # required when windowed; validate refuses without
    label_sql = _stage_case(cat["groups"], col, "label")
    code_sql = _stage_case(cat["groups"], col, "code")
    base = idx.select("patientid", "index_date")
    rows = base.join(src_df.select("patientid", col, date_col), "patientid", "inner")
    if lo is not None:
        rows = rows.filter(F.col(date_col) >= F.expr(f"date_add(index_date, {lo})"))
    if hi is not None:
        rows = rows.filter(F.col(date_col) <= F.expr(f"date_add(index_date, {hi})"))
    rows = rows.withColumn("_gap", F.abs(F.datediff(F.col(date_col), F.col("index_date"))))
    order = _selection_order(F, cat, cat, date_col, label_sql)
    # THE SAME CONTRACT AS A PANEL. This ordered by `same_date_conflict` (via `_selection_order`)
    # and never REFUSED on it: a pack could set `refuse` here, watch it validate, and get the
    # deterministic pick instead — the option meaning one thing in a panel and nothing here.
    _refuse_same_date_conflict(F, rows, cat, cat, date_col, label_sql, name,
                               ("patientid", "index_date"))
    w = Window.partitionBy("patientid", "index_date").orderBy(*order)
    return (rows.withColumn("_rn", F.row_number().over(w)).filter(F.col("_rn") == 1)
            .withColumn(name, F.expr(label_sql))
            .withColumn(name + "n", F.expr(code_sql))
            .select("patientid", "index_date", name, name + "n"))


def supersedes_closure(supersedes):
    """{winner -> every condition it supersedes, transitively}. == engine-r/stages.R.

    NAMED AND SHARED because the two engines each had their own version and only one was right.
    Applying the edges one at a time zeroes a loser and then reads that zeroed flag when deciding
    the loser's OWN losers: in severe -> moderate -> mild, `mild` survives a present `severe`, and
    the score depends on the order the conditions happen to be listed in. R returned 4 where Python
    returned 3 on exactly that shape.

    Self-edges are dropped rather than propagated — a condition that supersedes itself would be
    zeroed by its own presence, and the validator refuses it separately with that explanation.
    Cycles are refused by the validator too, which is what lets this loop terminate.
    """
    closure = {w: set(l) for w, l in supersedes.items()}
    changed = True
    while changed:
        changed = False
        for w, losers in closure.items():
            grown = set(losers)
            for l in losers:
                grown |= closure.get(l, set())
            grown.discard(w)
            if grown != losers:
                closure[w], changed = grown, True
    return closure


def weights_are_integral(weights):
    """Whether every weight is a whole number — the cast the score is emitted with. == the R side.

    An unconditional int cast truncated a 1.5 weight to 1 in R while Python kept 1.5. The decision
    is one line in each engine and it has to be the SAME line, so it is named on both sides and
    compared by a parity test rather than by reading.
    """
    try:
        return all(float(w).is_integer() for w in weights)
    except (TypeError, ValueError):
        return False


def comorbidity_index(F, src, idx, blk):
    """Weighted comorbidity score from coded diagnoses in a pre-index lookback.

    THE SUM IS OVER DISTINCT CONDITIONS, NOT OVER ROWS. A patient with five myocardial-infarction
    diagnoses scores myocardial infarction ONCE. Summing rows would turn "how sick is this patient"
    into "how often were they coded", which correlates with health-system contact rather than with
    disease — and would read as a plausible number the whole way.

    THE CODE SETS AND THE WEIGHTS ARE THE PACK'S, AND THE ENGINE HAS NONE. Quan-Charlson,
    NCI/Klabunde and Elixhauser are published algorithms with versions, ICD-9 and ICD-10 variants
    and disease-specific adaptations; an engine shipping one of them would be choosing the
    algorithm for every product silently, and the choice would then be invisible to the approval
    that is supposed to cover it. So `conditions:` comes from the pack, each entry carrying its own
    matcher and weight, and the matcher is compiled by the same `compile_match` the codelists use —
    so `code_prefix_any: [I21, I22]` normalises under the declared coding system exactly as it does
    everywhere else.

    HIERARCHY IS CONFIG TOO. Charlson-type indices do not count both mild and severe liver disease,
    or both "any tumour" and "metastatic solid tumour" — the severe member supersedes the mild one.
    That is clinical content, so a condition names what it `supersedes:` and the engine masks those
    after aggregation. Without it the score is quietly inflated for exactly the sickest patients.

    Config: { source, code_column, code_system, date_column, window_days: [lo, hi], name,
              conditions: [{name, weight, <one match operator>, supersedes?: [name, ...]}],
              bands?: [{code, label, min?, max?}] }
    Emits <name> (the numeric score) and, when `bands` is set, <name>gr / <name>grn.
    == engine-r/stages.R::clinical_comorbidity_index.
    """
    try:                                     # package import
        from .. import codelists
    except ImportError:                      # engine/ on sys.path
        import codelists
    dx_src = src.get(blk.get("source"))
    conds = blk.get("conditions") or []
    if dx_src is None or not conds:
        return None
    code_col, system = blk.get("code_column"), blk.get("code_system")
    date_col = blk.get("date_column")
    lo, hi = (blk.get("window_days") or [None, None])
    name = blk["name"]

    base = idx.select("patientid", "index_date")
    rows = base.join(dx_src, "patientid", "inner")
    if date_col:
        if lo is not None:
            rows = rows.filter(F.col(date_col) >= F.expr(f"date_add(index_date, {lo})"))
        if hi is not None:
            rows = rows.filter(F.col(date_col) <= F.expr(f"date_add(index_date, {hi})"))

    # One 0/1 per condition per patient: `max` over the window is what makes it DISTINCT.
    flags, weights, supersedes = [], {}, {}
    for i, c in enumerate(conds):
        match = {k: v for k, v in c.items()
                 if k not in ("name", "weight", "supersedes")}
        pred = codelists.compile_match(match, code_col or "", code_col or "",
                                       code_col=code_col, code_system=system)
        col = f"_cc{i}"
        flags.append(F.max(F.when(F.expr(pred), F.lit(1)).otherwise(F.lit(0))).alias(col))
        weights[c["name"]] = (col, c.get("weight", 1))
        if c.get("supersedes"):
            supersedes[c["name"]] = list(c["supersedes"])
    scored = rows.groupBy("patientid", "index_date").agg(*flags)

    # HIERARCHY, applied after aggregation and over the TRANSITIVE CLOSURE of the ORIGINAL flags.
    #
    # Both halves matter. Masking sequentially, column by column, reads each loser's ALREADY-MASKED
    # value: in a chain severe -> moderate -> mild, moderate is zeroed first, and the test for "is
    # moderate present" then fails, so mild survives — and reordering the YAML changes the score. So
    # the closure is computed first (severe supersedes moderate AND everything moderate supersedes),
    # and every mask reads a snapshot of the flags as aggregated.
    if supersedes:
        closure = supersedes_closure(supersedes)
        original = {name: F.col(col) for name, (col, _) in weights.items()}
        for winner, losers in closure.items():
            if winner not in weights:
                continue
            for loser in losers:
                if loser in weights:
                    lcol = weights[loser][0]
                    scored = scored.withColumn(
                        lcol, F.when(original[winner] == 1, F.lit(0)).otherwise(F.col(lcol)))

    total = None
    for col, weight in weights.values():
        term = F.col(col) * F.lit(weight)
        total = term if total is None else (total + term)
    # INTEGER ONLY WHEN EVERY WEIGHT IS ONE. Charlson weights are integers and an int score reads
    # correctly; but an algorithm with fractional weights (some Elixhauser-derived indices carry
    # them) would have every score silently TRUNCATED toward zero by an unconditional cast — a
    # smaller number that still looks like a score. The cast follows the weights.
    integral = weights_are_integral([w for _, w in weights.values()])
    scored = scored.withColumn(name, total.cast("int" if integral else "double"))
    keep = ["patientid", "index_date", name]
    if blk.get("bands"):                     # score -> published band label + code
        scored = (scored
                  .withColumn(name + "gr", F.expr(_num_bands_case(blk["bands"], name, "label")))
                  .withColumn(name + "grn", F.expr(_num_bands_case(blk["bands"], name, "code"))))
        keep += [name + "gr", name + "grn"]
    # LEFT-joined back onto the index, so a patient with NO diagnosis row in the window keeps a NULL
    # score rather than silently scoring 0. Those are different facts — no data versus no
    # comorbidity — and a config that wants 0 says so with a band whose `max` covers it.
    return base.join(scored.select(*keep), ["patientid", "index_date"], "left")


def _band_value_expr(val_col, item, blk):
    """The numeric expression a `bands` panel item compares: try_cast(<value_column> AS <type>).

    Numeric lab bands must compare a NUMBER, never the raw string column (a dirty/non-numeric value
    would otherwise make `testresultcleaned <= 35` a string comparison). try_cast yields NULL for a
    non-numeric value, so it falls through to the configured Missing band. The cast type is config
    (item.value_cast | block.value_cast, default DOUBLE). Built identically in engine-r/stages.R so
    the num_bands_case input — and thus the compiled CASE — stays byte-identical across engines.
    """
    cast = (item.get("value_cast") or blk.get("value_cast") or "double")
    return f"try_cast({val_col} AS {cast.upper()})"


def _closest_panel(F, Window, src_df, blk, idx):
    """Closest-to-index PANEL: for each item, filter the long table to its row(s) (name_column ==
    match), keep records within window_days of index, pick the one closest to index (tie: earliest
    date), and map its value -> name / <name>n. Returns (patientid, index_date) + one column pair
    per item. Used for biomarker / lab panels; reuses the parity-proven _stage_case/_num_bands_case.

    Config block: { source, name_column, value_column, date_column, window_days: [lo, hi],
                    value_cast?, unit_column?, panel: [{name, match, groups | bands,
                    value_cast?, units?}] }. lo/hi may be null (open-ended). A numeric `bands` item
    compares try_cast(value_column AS value_cast|DOUBLE) (see _band_value_expr) so a dirty value
    can't string-compare. An optional unit_column + per-item `units` restrict that item to matching
    units (case-insensitive) — so e.g. a CA-125 in the wrong unit doesn't get banded.
    """
    name_col, val_col = blk["name_column"], blk["value_column"]
    lo, hi = (blk.get("window_days") or [None, None])
    unit_col = blk.get("unit_column")
    base = idx.select("patientid", "index_date")
    pulled = base.join(src_df, "patientid", "inner")
    # THE RECORD'S DATE, from the named basis. Materialised ONCE into `_rdate` and used by the window
    # filter, the gap and the ordering — three places that would otherwise each spell `date_col` and so
    # could have come to disagree the moment the basis stopped being a single column.
    date_col = "_rdate"
    pulled = pulled.withColumn(date_col, _record_date_expr(F, blk))
    if lo is not None:
        pulled = pulled.filter(F.col(date_col) >= F.expr(f"date_add(index_date, {lo})"))
    if hi is not None:
        pulled = pulled.filter(F.col(date_col) <= F.expr(f"date_add(index_date, {hi})"))
    pulled = pulled.withColumn("_gap", F.abs(F.datediff(F.col(date_col), F.col("index_date"))))
    out = base
    for item in blk["panel"]:
        name = item["name"]
        if item.get("bands"):                       # numeric value -> num_bands_case (e.g. CA-125)
            num_col = _band_value_expr(val_col, item, blk)
            label_sql = _num_bands_case(item["bands"], num_col, "label")
            code_sql = _num_bands_case(item["bands"], num_col, "code")
        else:                                        # categorical value -> stage_case
            label_sql = _stage_case(item["groups"], val_col, "label")
            code_sql = _stage_case(item["groups"], val_col, "code")
        for _f in SEQUENCE_FIELDS:
            if _f in item and item.get(_f) is not None:
                _why = _sequence_error(_f, item[_f])
                if _why:
                    raise ValueError(_why)
        names = item.get("match_any") or [item["match"]]   # match_any: a multi-name set (e.g. HRR gene panel)
        rows = pulled.filter(F.upper(F.col(name_col)).isin([str(n).upper() for n in names]))
        units = item.get("units")
        if unit_col and units:                      # restrict to the configured measurement units
            rows = rows.filter(F.lower(F.col(unit_col)).isin([str(u).lower() for u in units]))
        order = _selection_order(F, blk, item, date_col, label_sql)
        w_item = Window.partitionBy("patientid", "index_date").orderBy(*order)
        _refuse_same_date_conflict(F, rows, blk, item, date_col, label_sql, name, ("patientid",
                                                                                  "index_date"))
        picked = (rows.withColumn("_rn", F.row_number().over(w_item)).filter(F.col("_rn") == 1)
                  .withColumn(name, F.expr(label_sql))
                  .withColumn(name + "n", F.expr(code_sql)))
        # THE DATE OF THE RECORD THAT WON, opt-in per block. A response category without its
        # assessment date is half the variable — "best response was PR" says nothing about when —
        # and for a `priority` pick the winning row is NOT the nearest one, so the date cannot be
        # re-derived downstream. Off by default: biomarkers and labs do not set it, so their
        # emitted columns stay byte-identical.
        cols = [name, name + "n"]
        if blk.get("emit_date"):
            picked = picked.withColumn(name + "dt", F.col(date_col))
            cols.append(name + "dt")
        out = out.join(picked.select("patientid", "index_date", *cols),
                       ["patientid", "index_date"], "left")
    return out


def _closest_values_panel(F, Window, src_df, blk, idx):
    """Closest-to-index raw-VALUE panel (prostate ClinChars lab values LABNEU/LABNEUV/LABNEUDT …): for
    each item, the record nearest index within window_days — ties broken by the item's `tiebreak`
    (lowest|highest value), then earliest date — emits <name> (Present/Missing flag, or the optional
    3-state Present/Unknown/Missing when `unknown_label` is set), <name>v (numeric
    value) and <name>dt (date). Unlike _closest_panel (which maps the value to a group) this carries the
    raw value + date. Config: { source, name_column, value_column, date_column, window_days, value_cast?,
    unit_column?, present_label?, missing_label?, panel: [{name, match, tiebreak?, units?}] }. The base
    <name> is the cataloged code; <name>v/<name>dt are its parallel value/date columns (like the -n cols).
    == engine-r/stages.R::clinical_closest_values_panel.
    """
    name_col, val_col, date_col = blk["name_column"], blk["value_column"], blk["date_column"]
    lo, hi = (blk.get("window_days") or [None, None])
    unit_col = blk.get("unit_column")
    cast = (blk.get("value_cast") or "double").upper()
    present, missing = blk.get("present_label", "Present"), blk.get("missing_label", "Missing")
    base = idx.select("patientid", "index_date")
    pulled = base.join(src_df, "patientid", "inner")
    if lo is not None:
        pulled = pulled.filter(F.col(date_col) >= F.expr(f"date_add(index_date, {lo})"))
    if hi is not None:
        pulled = pulled.filter(F.col(date_col) <= F.expr(f"date_add(index_date, {hi})"))
    pulled = (pulled.withColumn("_gap", F.abs(F.datediff(F.col(date_col), F.col("index_date"))))
              .withColumn("_v", F.expr(f"try_cast({val_col} AS {cast})")))
    unknown = blk.get("unknown_label")               # optional 3-state: Present / Unknown / Missing
    out = base
    for item in blk["panel"]:
        name = item["name"]
        named = pulled.filter(F.upper(F.col(name_col)) == str(item["match"]).upper())  # any matching test
        rows = named
        units = item.get("units")
        if unit_col and units:                       # restrict to the configured measurement units
            rows = rows.filter(F.lower(F.col(unit_col)).isin([str(u).lower() for u in units]))
        rows = rows.filter(F.col("_v").isNotNull())  # a real numeric result = a "Present" value
        vorder = (F.col("_v").desc() if item.get("tiebreak", "lowest") == "highest"
                  else F.col("_v").asc())            # same-day ties: lowest (default) or highest value
        w = Window.partitionBy("patientid", "index_date").orderBy(
            F.col("_gap").asc(), F.col(date_col).asc(), vorder)
        nearest = (rows.withColumn("_rn", F.row_number().over(w)).filter(F.col("_rn") == 1)
                   .select("patientid", "index_date", F.col("_v").alias(name + "v"),
                           F.col(date_col).alias(name + "dt"), F.lit(present).alias(name)))
        out = out.join(nearest, ["patientid", "index_date"], "left")
        if unknown:
            # 3-state: a matching test EXISTS in the window but yielded no usable value -> Unknown; no
            # matching test at all -> Missing. (2-state when unknown_label is unset: OC/EC byte-identical.)
            anyrec = named.select("patientid", "index_date").distinct().withColumn("_any", F.lit(1))
            out = (out.join(anyrec, ["patientid", "index_date"], "left")
                   .withColumn(name, F.coalesce(F.col(name),
                               F.when(F.col("_any").isNotNull(), F.lit(unknown)).otherwise(F.lit(missing))))
                   .drop("_any"))
        else:
            out = out.withColumn(name, F.coalesce(F.col(name), F.lit(missing)))   # no record -> Missing
    return out


def _psa_timepoints(F, Window, src_df, blk, idx):
    """Windowed PSA values relative to index + PSA-response endpoints (prostate 6.Outcomes). For each
    point, the PSA (value_column) whose date is within [index+lo, index+hi] — picked CLOSEST to index
    (pick: closest) or EARLIEST in the window (pick: earliest; same-day ties -> max value, per the spec)
    — is emitted as <name>. Response endpoints per `response`: psa50 = (point-baseline)/baseline <=
    threshold -> 'Y' (else 'N'); undetectable = point < threshold -> 'Y'. baseline is one of the points
    (PSA at index = PSABL). Config: { source, value_column, date_column, value_cast?, points: [{name,
    window_days:[lo,hi], pick}], response?: {baseline, psa50_threshold, undetectable_threshold, points:
    [{value, psa50, undetectable}]} }. == engine-r/stages.R::clinical_psa_timepoints.
    """
    val_col, date_col = blk["value_column"], blk["date_column"]
    cast = (blk.get("value_cast") or "double").upper()
    base = idx.select("patientid", "index_date")
    pulled = (base.join(src_df, "patientid", "inner")
              .withColumn("_v", F.expr(f"try_cast({val_col} AS {cast})")).filter(F.col("_v").isNotNull()))
    out = base
    for p in blk["points"]:
        lo, hi = p["window_days"]
        rows = pulled.filter((F.col(date_col) >= F.expr(f"date_add(index_date, {lo})")) &
                             (F.col(date_col) <= F.expr(f"date_add(index_date, {hi})")))
        if p.get("pick") == "earliest":
            order = [F.col(date_col).asc(), F.col("_v").desc()]    # earliest result; same-day -> max value
        else:                                                      # closest to index
            rows = rows.withColumn("_g", F.abs(F.datediff(F.col(date_col), F.col("index_date"))))
            order = [F.col("_g").asc(), F.col(date_col).asc()]
        w = Window.partitionBy("patientid", "index_date").orderBy(*order)
        near = (rows.withColumn("_rn", F.row_number().over(w)).filter(F.col("_rn") == 1)
                .select("patientid", "index_date", F.col("_v").alias(p["name"])))
        out = out.join(near, ["patientid", "index_date"], "left")
    resp = blk.get("response")
    if resp:
        bl = resp["baseline"]
        p50, pun = resp.get("psa50_threshold", -0.5), resp.get("undetectable_threshold", 0.2)
        for pt in resp.get("points", []):
            v = pt["value"]
            out = out.withColumn(pt["psa50"], F.expr(   # NULL = not evaluable (no baseline, zero baseline,
                f"CASE WHEN {bl} IS NULL OR {bl} = 0 OR {v} IS NULL THEN NULL "   # or no follow-up value)
                f"WHEN ({v} - {bl})/{bl} <= {p50} THEN 'Y' ELSE 'N' END"))
            out = out.withColumn(pt["undetectable"], F.expr(
                f"CASE WHEN {v} IS NOT NULL AND {v} < {pun} THEN 'Y' "
                f"WHEN {v} IS NOT NULL THEN 'N' ELSE NULL END"))
    return out


# Named body-composition formulas. Config `vitals.bmi_method` / `vitals.bsa_method` NAME one of these
# (e.g. `bsa_method: dubois`); the engine looks it up and compiles it. The formula is NEVER carried as a
# raw string in config — that would be either decorative (config lies) or an eval hazard. height in cm,
# weight in kg. To add a formula, add a registry entry here (a small validated operator), not config code.
BMI_FORMULAS = {
    "standard": "weight / pow(height/100, 2)",                            # WHO: kg / m^2
}
BSA_FORMULAS = {
    "dubois": "0.007184 * pow(height, 0.725) * pow(weight, 0.425)",       # Du Bois & Du Bois (1916)
    # (Mosteller etc. are added here when an approved product asks for them — not kept speculatively.)
}

# Named row filters a follow-up source may apply (config `follow_up_sources[].filter_method`). Each maps
# to (predicate SQL, [columns it references]) so config NAMES the filter instead of carrying raw SQL, and
# preflight can require the predicate's columns. Same small-validated-operator pattern as BMI/BSA.
FOLLOWUP_FILTERS = {
    "valid_oral_end": (
        "(startdategranularity <> 'Year' OR startdategranularity IS NULL) AND enddate IS NOT NULL",
        ["startdategranularity", "enddate"]),
}


# ---------------------------------------------------------------------------------------------
# RECORD SELECTION — the vocabulary for "which row of a long table represents this patient".
#
# The same three questions recur across every panel, lab, vital and biomarker in every tumour: which
# DATE is the record's date, which row WINS, and what happens on a TIE. They were two hardcoded
# branches inside `_closest_panel` with the tie fixed at "earliest", which is why so much of
# ENGINE_GAPS.md is one shape — G-BIOMARKER-CLOSEST, G-LABS, G-VITALS-DATES, G-MET-METDT,
# G-PSA-INDEX-PICK all ask for a different point in this same space and each needed engine work.
#
# Named, not expressed: config NAMES a member and the engine owns the arithmetic, exactly as with
# BMI_FORMULAS and FOLLOWUP_FILTERS. A config that could express arbitrary ordering would be a
# programming language with no tests.
#
# ALL THREE DEFAULT TO TODAY'S BEHAVIOUR. A pack that sets none of them selects records exactly as
# before — the defaults are named here rather than left implicit so the current behaviour is itself
# a choice somebody can read.

# WHICH DATE a record is measured by. `later_of` is what B2 needs: the prostate feed ships
# `resultdate` + `specimencollecteddate` and no `biomarkerdate`, and G-LABS asks for the same
# later-of rule — both are a config edit once this exists rather than an engine change.
DATE_BASIS = {
    "column":     "the single named date column (the default)",
    "later_of":   "the greatest of several date columns, ignoring nulls",
    "earlier_of": "the least of several date columns, ignoring nulls",
}

# WHICH ROW wins, once the window has been applied.
RECORD_PICK = {
    "nearest":  "the record closest to the anchor date (the default)",
    "earliest": "the earliest record in the window",
    "latest":   "the latest record in the window",
    "priority": "the best status by the item's `priority` label order, across ALL in-window rows",
}

# HOW A TIE IS BROKEN — two records equally near the anchor, or two on the same date.
TIE_BREAK = {
    "prior": "the earlier record (the default)",
    "later": "the later record",
}

# WHAT TO DO WHEN TWO RECORDS ON THE SAME DATE DISAGREE ABOUT THE VALUE.
#
# `tie_break` answers "which DATE wins", which is a different question and the only one that was
# ever asked. Two results dated the same day carrying different values — a repeat assay, a
# corrected result, two labs — fell through every selector to an ORDER BY that did not mention the
# value, so the engine returned whichever row the shuffle placed first. Deterministic ordering (see
# `_selection_order`) makes that stable; it does not make it a decision. Which of two contradictory
# clinical values is the patient's is a methodology question, and the config has to say.
SAME_DATE_CONFLICT = {
    "deterministic": "keep the first by the total order — stable, but nobody chose which is right "
                     "(the default, and what the engine has always done once ordering is total)",
    "refuse":        "fail the build. For a variable where two same-day values mean the data is "
                     "wrong rather than merely ambiguous",
    "priority":      "the best status by the item's `priority` label order",
    "min":           "the lowest mapped value",
    "max":           "the highest mapped value",
}
DEFAULT_SELECTION = {"date_basis": "column", "pick": "nearest", "tie_break": "prior",
                     "same_date_conflict": "deterministic"}


def selection_errors(blk, item=None):
    """[why this selection spec is not selectable] — unknown names, refused by name.

    Structural only, and it never guesses: an unknown `pick` is refused listing the registry rather
    than falling back to the default, because a silently-defaulted selector is a variable derived by
    a rule nobody chose.
    """
    why = []
    for where, src in (("block", blk or {}), ("item", item or {})):
        for key, registry in (("date_basis", DATE_BASIS), ("pick", RECORD_PICK),
                              ("tie_break", TIE_BREAK),
                              ("same_date_conflict", SAME_DATE_CONFLICT)):
            val = src.get(key)
            if val is None:
                continue
            # THE RECORD DATE IS COMPUTED ONCE PER BLOCK. `_record_date_expr` reads the block and
            # nothing else, so an item-level `date_basis` validated cleanly and then did nothing:
            # a valid-looking selector silently not selecting, which is the shape this registry
            # exists to remove. Refused rather than implemented per item — no pack needs it, and
            # accepting a key the engine ignores is worse than not offering it.
            if where == "item" and key in BLOCK_ONLY:
                why.append(f"{key} is a BLOCK-level choice — one record date is computed for the "
                           f"whole panel, so an item stating it would be ignored. Move it up.")
                continue
            name = val.get("method") if isinstance(val, dict) else val
            if str(name) not in registry:
                why.append(f"{key}: {name!r} is not a registered selection method — one of "
                           f"{', '.join(sorted(registry))}")
                continue
            if key == "date_basis" and str(name) in ("later_of", "earlier_of"):
                cols = val.get("columns") if isinstance(val, dict) else None
                if not (isinstance(cols, list) and len(cols) >= 2):
                    why.append(f"date_basis.{name} needs `columns: [a, b, …]` naming at least two "
                               f"date columns; got {cols!r}")
    return why


def _selection_spec(blk, item, key):
    """The effective value of one selection key: the ITEM's if it states one, else the BLOCK's, else
    the registered default. Item-over-block because a panel is a set of different questions sharing
    one source — HRR rolls up across genes while a PSA reading wants the nearest single record."""
    for src in (item or {}, blk or {}):
        if src.get(key) is not None:
            v = src[key]
            # UNWRAP `{method: …}` exactly as the R `selection_spec` does. `date_basis` is a mapping
            # by design, so the mapping form is a natural thing for someone to write for `pick` too
            # — and it validated. R unwrapped it to `priority`; Python stringified the whole dict,
            # matched no branch, and fell through to `nearest`. Two engines, two winning rows, from
            # a config that passed lint.
            return v.get("method", v) if isinstance(v, dict) else v
    # `aggregate: priority` is the pre-registry spelling of `pick: priority`. Still honoured so no
    # pack has to be edited for this change, and named here rather than in two call sites.
    if key == "pick" and (item or {}).get("aggregate") == "priority":
        return "priority"
    return DEFAULT_SELECTION[key]


def _record_date_expr(F, blk):
    """The record's date, per the block's `date_basis`.

    Default `column` reads `date_column`, which is exactly what every pack does today. `later_of` /
    `earlier_of` take `columns:` and use greatest/least, which IGNORE nulls in Spark — a record dated
    on only one of two columns still has a date, rather than dropping out of the window silently.
    """
    basis = blk.get("date_basis") or DEFAULT_SELECTION["date_basis"]
    method = basis.get("method") if isinstance(basis, dict) else basis
    if str(method) == "column":
        return F.col(blk["date_column"])
    cols = [F.col(c) for c in basis["columns"]]
    return F.greatest(*cols) if str(method) == "later_of" else F.least(*cols)


def _refuse_same_date_conflict(F, rows, blk, item, date_col, label_sql, name, keys):
    """Raise when `same_date_conflict: refuse` and two records on one date disagree. THE one place.

    It lived inline in `_closest_panel` and nowhere else, so a pack could set `refuse` on a
    windowed categorical, watch it validate, and get no refusal at all — a selector that validates
    and then does nothing, which is the defect the option was added to remove. Every selector that
    has a date column now calls this, so the option means the same thing wherever it is written.

    Counting DISTINCT mapped values per (partition keys, date) is the whole check: >1 means two
    records dated the same day carry different values.
    """
    if str(_selection_spec(blk, item, "same_date_conflict")) != "refuse":
        return
    if not date_col:
        return                                  # no date to conflict on; the validator refuses this
    clash = (rows.withColumn("_v", F.expr(label_sql))
             .groupBy(*keys, date_col)
             .agg(F.countDistinct("_v").alias("_n"))
             .filter(F.col("_n") > 1))
    if clash.limit(1).count():
        raise ValueError(
            f"{name}: same_date_conflict is `refuse` and at least one patient has two records on "
            f"one date carrying different values. This pack has declared that two same-day values "
            f"mean the data is wrong rather than ambiguous — correct the source, or state which "
            f"value wins ({', '.join(sorted(SAME_DATE_CONFLICT))}).")


def _selection_order(F, blk, item, date_col, label_sql):
    """The ORDER BY that decides which record wins, from the named `pick` + `tie_break`.

    One place, so a panel, a lab and a vital cannot drift into three orderings of the same question.
    `priority` ranks by the item's `priority` label order across ALL in-window rows (HRR/BRCA roll up
    to the worst-case status); everything else orders on the date or the gap to the anchor.
    """
    pick = str(_selection_spec(blk, item, "pick"))
    tie = str(_selection_spec(blk, item, "tie_break"))
    date_tie = F.col(date_col).asc() if tie == "prior" else F.col(date_col).desc()
    # A TOTAL ORDER, always. Every branch below could still leave two rows tied — two results on
    # the SAME DATE with different values is the ordinary case, not a rare one — and Spark then
    # returns whichever row the shuffle happened to place first. That is not a wrong answer once;
    # it is a DIFFERENT answer between runs of the same build over the same data, which no golden
    # can pin and no reviewer can reproduce. Ordering last on the mapped label makes the choice
    # deterministic; it does not make it RIGHT, which is what `same_date_conflict` is for.
    value_tie = F.expr(label_sql).asc_nulls_last()
    # ...and where the pack has STATED which of two same-day values it wants, that choice orders
    # ahead of the arbitrary one. `deterministic` leaves the label order, which is the historical
    # behaviour once the order is total. `refuse` is enforced separately — it is not an ordering.
    sdc = str(_selection_spec(blk, item, "same_date_conflict"))
    if sdc == "min":
        value_tie = F.expr(label_sql).asc_nulls_last()
    elif sdc == "max":
        value_tie = F.expr(label_sql).desc_nulls_last()
    elif sdc == "priority":
        _prio = (item or {}).get("priority") or [g.get("label")
                                                 for g in ((item or {}).get("groups") or [])]
        if _prio:
            _sql = "CASE " + " ".join(
                f"WHEN ({label_sql}) = {_q(str(lab))} THEN {i}" for i, lab in enumerate(_prio)
            ) + f" ELSE {len(_prio)} END"
            value_tie = F.expr(_sql).asc()
    if pick == "priority":
        prio = item.get("priority") or [g.get("label") for g in (item.get("groups") or [])]
        rank_sql = "CASE " + " ".join(
            f"WHEN ({label_sql}) = {_q(str(lab))} THEN {i}" for i, lab in enumerate(prio)
        ) + f" ELSE {len(prio)} END"
        return [F.expr(rank_sql).asc(), date_tie, value_tie]
    if pick == "earliest":
        return [F.col(date_col).asc(), value_tie]
    if pick == "latest":
        return [F.col(date_col).desc(), value_tie]
    return [F.col("_gap").asc(), date_tie, value_tie]      # nearest — the default


def _resolve_formula(registry, name, kind):
    """Look a named formula up in its registry; raise a clear error (not KeyError) on an unknown name."""
    key = str(name)
    if key not in registry:
        raise ValueError(f"unknown {kind} method {name!r}; valid: {sorted(registry)}")
    return registry[key]


def _resolve_followup_filter(s):
    """A follow-up source row filter: a named `filter_method` (preferred, resolved from FOLLOWUP_FILTERS)
    or a raw `filter` SQL string (back-compat escape hatch). Returns the predicate SQL or None."""
    fm = s.get("filter_method")
    if fm:
        if fm not in FOLLOWUP_FILTERS:
            raise ValueError(f"unknown follow_up filter_method {fm!r}; valid: {sorted(FOLLOWUP_FILTERS)}")
        return FOLLOWUP_FILTERS[fm][0]
    return s.get("filter")


def vitals(src, idx, vcfg):
    """clin_char_vitals_var: baseline BMI (+ BSA, when `bsa_method` names a BSA_FORMULAS entry) from the
    height/weight closest to (and on/before) index. The BMI/BSA formulas are named in config and resolved
    from the BMI_FORMULAS / BSA_FORMULAS registries — config never carries the raw formula."""
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window

    ht, wt = vcfg["height_test"].upper(), vcfg["weight_test"].upper()
    base = idx.select("patientid", "index_date")
    pull = (base.join(src["vitals"], "patientid", "inner")
            .withColumn("test_u", F.upper(F.col("test")))
            .filter((((F.col("test_u") == ht) & (F.col("testunitscleaned") == "cm")) |
                     ((F.col("test_u") == wt) & (F.col("testunitscleaned") == "kg"))) &
                    (F.col("testresultcleaned") > 0))
            .withColumn("vitaldate", F.greatest("testdate", "resultdate"))
            .filter(F.col("vitaldate") <= F.col("index_date")))
    w = Window.partitionBy("patientid", "index_date", "test_u").orderBy(F.col("vitaldate").desc())
    closest = (pull.withColumn("rn", F.row_number().over(w)).filter(F.col("rn") == 1))
    h = closest.filter(F.col("test_u") == ht).select(
        "patientid", "index_date", F.col("testresultcleaned").alias("height"))
    g = closest.filter(F.col("test_u") == wt).select(
        "patientid", "index_date", F.col("testresultcleaned").alias("weight"))
    # null / empty / missing all resolve to 'standard' (matches R's `%||%`); the validator separately
    # requires an explicit method when vitals is configured, so this is only a divergence-proof default.
    bmi_expr = _resolve_formula(BMI_FORMULAS, vcfg.get("bmi_method") or "standard", "bmi")
    out = (base.join(h, ["patientid", "index_date"], "left").join(g, ["patientid", "index_date"], "left")
           .withColumn("bmi", F.expr(f"CASE WHEN weight IS NOT NULL AND height > 0 "
                                     f"THEN {bmi_expr} ELSE NULL END"))
           .withColumn("bmigrl", F.expr(_num_bands_case(vcfg["bmi_bands"], "bmi", "label")))
           .withColumn("bmigrln", F.expr(_num_bands_case(vcfg["bmi_bands"], "bmi", "code"))))
    keep = ["patientid", "index_date", "height", "weight", "bmi", "bmigrl", "bmigrln"]
    # BSA emitted only when a method is named. Back-compat: a legacy truthy `bsa_formula` -> Du Bois.
    bsa_method = vcfg.get("bsa_method") or ("dubois" if vcfg.get("bsa_formula") else None)
    if bsa_method:
        bsa_expr = _resolve_formula(BSA_FORMULAS, bsa_method, "bsa")
        out = out.withColumn("bsa", F.expr(f"CASE WHEN weight IS NOT NULL AND height > 0 "
                                           f"THEN {bsa_expr} ELSE NULL END"))
        keep.append("bsa")
    return out.select(*keep)


# Allowed mortality conflict-resolution policies (config: death_date_imputation.conflict_resolution).
# Keep in sync with the same-named set in engine/validate.py.
DEATH_CONFLICT_POLICIES = ("most_specific_then_earliest", "earliest", "latest")


def _death_conflict_order(F, dod, policy):
    """Window ordering that selects ONE mortality row per (patientid, index_date).

    `dod` is the cast-to-string dateofdeath SQL expression; longer string = finer granularity
    (full date > YYYY-MM > YYYY). `dateofdeath_init` must already be computed (index-aware).
    """
    specific = F.length(F.expr(dod)).desc_nulls_last()      # full > YYYY-MM > YYYY
    earliest = F.col("dateofdeath_init").asc_nulls_last()
    latest = F.col("dateofdeath_init").desc_nulls_last()
    tiebreak = F.expr(dod).asc_nulls_last()                 # deterministic final tiebreak
    if policy == "most_specific_then_earliest":
        return [specific, earliest, tiebreak]
    if policy == "earliest":
        return [earliest, specific, tiebreak]
    if policy == "latest":
        return [latest, specific, tiebreak]
    raise ValueError(f"unknown death_date_imputation.conflict_resolution: {policy!r} "
                     f"(allowed: {', '.join(DEATH_CONFLICT_POLICIES)})")


def baseline_ecog(src, idx, ecog_cfg):
    """clin_char_ecog_var: ECOG closest to index within window_days, ties -> earliest.

    A baseline record that EXISTS but has a null/"Unknown" value -> "Unknown" (code from
    value_codes), NOT "Missing". "Missing" is reserved for patients with NO baseline record.
    The numeric path is RLIKE-guarded so ANSI casting can't fail on a non-numeric value.
    """
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window

    lo, hi = ecog_cfg["window_days"]
    code_map = ecog_cfg["value_codes"]
    miss, miss_code = ecog_cfg["missing_label"], ecog_cfg["missing_code"]

    ecog = src["baseline_ecog"].select("patientid", "ecogdate", "ecogvalue")
    pulled = (idx.select("patientid", "index_date")
              .join(ecog, "patientid", "inner")
              .filter((F.col("ecogdate") >= F.expr(f"date_add(index_date, {lo})")) &
                      (F.col("ecogdate") <= F.expr(f"date_add(index_date, {hi})")))
              .withColumn("gap", F.abs(F.datediff("ecogdate", "index_date")))
              # 6-step nearest-record final tie-break: among records at the same gap AND same date,
              # the WORST (max) ECOG wins; Unknown/non-numeric ranks last so a real grade is preferred.
              # (The reconstruction documents this max-ecogvalue step but its summarise drops the value.)
              .withColumn("_rank", F.expr(
                  "CASE WHEN cast(ecogvalue as string) rlike '^[0-9]+([.]0+)?$' "
                  "THEN cast(cast(ecogvalue as double) as int) ELSE -1 END")))
    # tie_break selects the date direction among same-gap records (earliest_date default; latest_date
    # supported), then the worst-grade rank breaks a same-date tie.
    dt_order = (F.col("ecogdate").desc() if ecog_cfg.get("tie_break") == "latest_date"
                else F.col("ecogdate").asc())
    w = Window.partitionBy("patientid", "index_date").orderBy(
        F.col("gap").asc(), dt_order, F.col("_rank").desc())
    # Resolve the label on records that exist (present null/Unknown -> "Unknown").
    label = (
        "CASE WHEN ecogvalue IS NULL THEN 'Unknown' "
        "WHEN lower(trim(cast(ecogvalue as string))) = 'unknown' THEN 'Unknown' "
        "WHEN cast(ecogvalue as string) rlike '^[0-9]+([.]0+)?$' "
        "  THEN cast(cast(cast(ecogvalue as double) as int) as string) "
        "ELSE 'Unknown' END")
    nearest = (pulled.withColumn("rn", F.row_number().over(w))
                     .filter(F.col("rn") == 1)
                     .withColumn("ecog", F.expr(label))
                     .select("patientid", "index_date", "ecog"))

    code_when = " ".join(f"WHEN ecog = {_q(k)} THEN {v}" for k, v in code_map.items())
    return (idx.select("patientid", "index_date")
            .join(nearest, ["patientid", "index_date"], "left")
            .withColumn("ecog", F.coalesce(F.col("ecog"), F.lit(miss)))    # no record -> Missing
            .withColumn("ecogn", F.expr(f"CASE {code_when} ELSE {miss_code} END"))
            .select("patientid", "index_date", "ecog", "ecogn"))


def _last_date(df, datecol, alias, filt_sql=None):
    """max(datecol) per patient, optionally filtered. Helper for the follow-up-end maxima."""
    from pyspark.sql import functions as F
    d = df.filter(F.expr(filt_sql)) if filt_sql else df
    return d.groupBy("patientid").agg(F.max(F.col(datecol)).alias(alias))


# (logical source, date column, output alias, optional filter). fu_enddt is the latest of these
# that are PRESENT — heme/COTA tumors lacking alphabet/provenge simply contribute fewer.
FOLLOWUP_SOURCES = [
    ("visit",    "visitdate",          "last_visitdate",     None),
    ("telemed",  "visitdate",          "last_televisitdate", None),
    ("lot",      "enddate",            "last_lotenddate",    None),
    ("orals",    "enddate",            "last_oralenddate", FOLLOWUP_FILTERS["valid_oral_end"][0]),
    ("alphabet", "administrationdate", "last_alphadate",     None),
    ("provenge", "startdate",          "last_provdate",      None),
]


def follow_up_and_death(src, idx, clin_cfg):
    """clin_char_fuend_dthdt_var: derive the follow-up-end / death anchors.

    Emits f_death, dthdt, dthfl, fu_enddt, fued, plus dthfufl_dur / dthfufl / dth_before_fued.
    fu_enddt_preliminary = latest of last visit / televisit / LOT end / oral end / alphabet /
    provenge dates. Death date is imputed from coarse granularity per config, then follow-up is
    capped at death and dates are snapped to month end where the R did.
    """
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window

    imp = clin_cfg["death_date_imputation"]
    month_day = int(imp["month_level_day"])          # 15
    year_md = str(imp["year_level_monthday"])        # "07-15"
    year_late = str(imp.get("year_level_late_monthday", year_md))   # "12-31"
    year_month = int(year_md.split("-")[0])          # 7 (month of the year-level default)
    conflict = str(imp.get("conflict_resolution", DEATH_CONFLICT_POLICIES[0]))
    dth_window = int(imp["death_followup_window_days"])   # 120

    fu = idx.select("patientid", "index_date")
    # follow_up_sources (config, optional):
    #   - omitted  -> the engine default set (FOLLOWUP_SOURCES), present-only
    #   - [names]  -> restrict the default set to these logical sources
    #   - [{source, date_column, alias[, filter]}] -> full override (a tumor whose follow-up table
    #     uses a different date column declares it here)
    spec = imp.get("follow_up_sources")
    if spec and isinstance(spec[0], dict):
        fu_spec = [(s["source"], s["date_column"],
                    s.get("alias", f"last_{s['source']}date"), _resolve_followup_filter(s)) for s in spec]
    else:
        fu_spec = FOLLOWUP_SOURCES
        if spec is not None:
            fu_spec = [t for t in FOLLOWUP_SOURCES if t[0] in set(spec)]

    added = []
    for srcname, datecol, alias, filt in fu_spec:
        if srcname not in src:                       # tumor/vendor doesn't have this table
            continue
        fu = fu.join(_last_date(src[srcname], datecol, alias, filt), "patientid", "left")
        added.append(alias)

    fu = fu.withColumn("fu_enddt_preliminary",
                       F.greatest(*added) if added else F.lit(None).cast("date"))
    if "last_lotenddate" not in added:              # referenced by the reconciliation below
        fu = fu.withColumn("last_lotenddate", F.lit(None).cast("date"))

    # Death from mortality (cast to string so a date- or string-typed dateofdeath both work:
    # a real date stringifies to length-10 -> direct cast).
    dod = "cast(dateofdeath as string)"
    # Join ALL mortality rows (do NOT pre-dedupe). The imputation below is index-aware, so the
    # "best" death row can only be chosen AFTER imputation, per (patientid, index_date).
    fu = fu.join(src["mortality"].select("patientid", "dateofdeath"), "patientid", "left")

    # Index-aware imputation: month-level -> day-`month_day`; a year-only (YYYY) death in the SAME
    # year as an on/after-`year_month` index -> `year_late` (e.g. Dec 31) so it can't precede the
    # index and yield negative OS. (Mirrors the original R index-year logic.)
    fu = fu.withColumn("dateofdeath_init", F.expr(
        f"CASE WHEN length({dod})=7 THEN cast(concat({dod},'-{month_day:02d}') as date) "
        f"WHEN length({dod})=4 THEN "
        f"  CASE WHEN cast({dod} as int) = year(index_date) AND month(index_date) >= {year_month} "
        f"       THEN cast(concat({dod},'-{year_late}') as date) "
        f"       ELSE cast(concat({dod},'-{year_md}') as date) END "
        f"WHEN length({dod})=10 THEN cast(dateofdeath as date) ELSE NULL END"))
    fu = fu.withColumn("f_death", F.expr("CASE WHEN dateofdeath IS NOT NULL THEN 1 ELSE 0 END"))

    # Collapse to ONE death row per (patientid, index_date) AFTER imputation. A patient dies once;
    # multiple mortality rows would otherwise fan out the ADS / distort OS. The tie-break policy
    # is config-driven (death_date_imputation.conflict_resolution) so it's a reviewed choice.
    mw = Window.partitionBy("patientid", "index_date").orderBy(
        *_death_conflict_order(F, dod, conflict))
    fu = (fu.withColumn("_rn", F.row_number().over(mw))
          .filter(F.col("_rn") == 1).drop("_rn"))

    # Month-level death in the FU-end month -> last day of that month.
    fu = fu.withColumn("death_dt_preliminary", F.expr(
        f"CASE WHEN length({dod})=7 "
        f"  AND substr(cast(fu_enddt_preliminary as string),1,7) = substr({dod},1,7) "
        f"  THEN last_day(dateofdeath_init) ELSE dateofdeath_init END"))

    # Cap follow-up at death; snap to last_lotenddate when in the same month (R reconciliation).
    fu = fu.withColumn("fu_enddt", F.expr(
        "CASE WHEN death_dt_preliminary IS NOT NULL "
        "  AND fu_enddt_preliminary > death_dt_preliminary THEN "
        "  CASE WHEN substr(cast(death_dt_preliminary as string),1,7) "
        "       = substr(cast(last_lotenddate as string),1,7) "
        "       THEN last_lotenddate ELSE death_dt_preliminary END "
        "ELSE fu_enddt_preliminary END"))
    fu = fu.withColumn("dthdt", F.expr(
        "CASE WHEN substr(cast(death_dt_preliminary as string),1,7) "
        "       = substr(cast(last_lotenddate as string),1,7) "
        "     THEN cast(last_day(death_dt_preliminary) as date) ELSE death_dt_preliminary END"))
    fu = fu.withColumn("dthfl", F.expr("CASE WHEN dthdt IS NOT NULL THEN 1 ELSE 0 END"))
    fu = fu.withColumn("fued", F.expr(
        "CASE WHEN fu_enddt > index_date THEN fu_enddt ELSE index_date END"))

    # Death within the follow-up window (R: dthfufl_dur / dthfufl / dth_before_fued).
    fu = fu.withColumn("dthfufl_dur", F.datediff("dthdt", "fued"))
    fu = fu.withColumn("dthfufl", F.expr(
        f"CASE WHEN dthdt IS NULL THEN 'Missing' "
        f"WHEN dthfufl_dur <= {dth_window} THEN '1' "
        f"WHEN dthfufl_dur > {dth_window} THEN '0' ELSE NULL END"))
    fu = fu.withColumn("dth_before_fued", F.expr(
        "CASE WHEN dthdt IS NOT NULL AND fued IS NOT NULL AND dthdt < fued THEN 1 ELSE 0 END"))

    return fu.select("patientid", "index_date", "f_death", "dthdt", "dthfl", "fu_enddt", "fued",
                     "dthfufl_dur", "dthfufl", "dth_before_fued")


def _surgery_sql(scfg) -> dict:
    """The fixed OC surgery-classification CASEs, parameterised by column names + labels. The 1L window
    columns _line1_start / _line1_end are joined by _surgery. Mirrored in cases.R::surgery_sql
    (parity-tested). PCS = surgery before 1L chemo (or flagged with no date); ICS = surgery at/after
    1L start; neoadj = surgery during the 1L window. (verify-vs-source: the reconstruction's final
    select aliased issurg=issurgery / surgn=stagen — copy-paste slips; this emits the mutate intent.)
    """
    fl, dt = scfg["surgery_flag_column"], scfg["surgery_date_column"]
    yes, no = scfg.get("yes_value", "Yes"), scfg.get("no_value", "No")
    pcs, ics, none = scfg["pcs_label"], scfg["ics_label"], scfg["none_label"]
    # surg/surgn/neoadj only classify when a surgery actually occurred (issurgery = Yes) — a stray
    # surgery date on a No/Unknown/Missing row must NOT become PCS/ICS/neoadj. Within Yes: no date or
    # before 1L start -> Primary (PCS); at/after 1L start -> Interval (ICS).
    typ = (f"CASE WHEN {dt} IS NULL OR {dt} < _line1_start THEN '{pcs}' "
           f"WHEN {dt} >= _line1_start THEN '{ics}' ELSE '{none}' END")
    typn = (f"CASE WHEN {dt} IS NULL OR {dt} < _line1_start THEN 1 "
            f"WHEN {dt} >= _line1_start THEN 2 ELSE 3 END")
    return {
        "issurg": (f"CASE WHEN {fl} = '{yes}' THEN 'Yes' WHEN {fl} = '{no}' THEN '{none}' "
                   f"WHEN {fl} != '{yes}' AND {dt} IS NULL THEN 'Unknown' ELSE 'Missing' END"),
        "surg": f"CASE WHEN {fl} = '{yes}' THEN ({typ}) ELSE '{none}' END",
        "surgn": f"CASE WHEN {fl} = '{yes}' THEN ({typn}) ELSE 3 END",
        "neoadj": (f"CASE WHEN {fl} = '{yes}' AND {dt} >= _line1_start AND {dt} <= _line1_end "
                   f"THEN 'Yes' ELSE 'No' END"),
    }


def _surgery(F, src, idx, scfg):
    """OC surgery sub-block: issurg / surg / surgn / neoadj (+ tt_first_tx_diag) from the enhanced
    surgery fields and the 1L (linenumber 1, non-maintenance) line window. Cohort-independent — surgery
    is a baseline characteristic relative to 1L. Returns None when a required source is absent."""
    from pyspark.sql.window import Window
    enh, lot = src.get(scfg["source"]), src.get(scfg.get("line_source", "lot"))
    if enh is None or lot is None:
        return None
    base = idx.select("patientid", "index_date")
    fl, dt = scfg["surgery_flag_column"], scfg["surgery_date_column"]
    init, size = scfg.get("init_date_column", "diagnosisdate"), scfg.get("size_column")

    def _first(df, order_col):    # one DETERMINISTIC row per patient (== R window_order+row_number)
        w = Window.partitionBy("patientid").orderBy(F.col(order_col).asc())
        return df.withColumn("_rn", F.row_number().over(w)).filter(F.col("_rn") == 1).drop("_rn")

    e = _first(enh.select(*[c for c in ("patientid", fl, dt, init, size) if c and c in enh.columns]), dt)
    l1 = lot.filter(F.col(scfg.get("line_number_column", "linenumber")) == 1)
    mnt = scfg.get("maintenance_column")
    if mnt and mnt in lot.columns:
        l1 = l1.filter(f"lower(cast({mnt} as string)) != 'true'")    # non-maintenance 1L
    l1 = _first(l1.select("patientid", F.col(scfg["line_start_column"]).alias("_line1_start"),
                          F.col(scfg["line_end_column"]).alias("_line1_end")), "_line1_start")
    j = base.join(e, "patientid", "left").join(l1, "patientid", "left")
    sql = _surgery_sql(scfg)
    for name, expr in sql.items():
        j = j.withColumn(name, F.expr(expr))
    keep = ["patientid", "index_date", "issurg", "surg", "surgn", "neoadj"]
    if init in j.columns:                       # tt_first_tx_diag = days from diagnosis to first tx
        j = j.withColumn("tt_first_tx_diag", F.expr(f"datediff(least({dt}, _line1_start), {init})"))
        keep.append("tt_first_tx_diag")
    if size and size in j.columns:
        keep.append(size)
    return j.select(*keep)


def _min_avail_date(F, src, idx, blk, index_source):
    """Data-availability floor: minavaildate = the EARLIEST of the configured base date(s) and the
    first (min) date seen in each source; basedur = datediff(index_date, minavaildate). least()/min()
    skip nulls, so a patient absent from a source just doesn't lower the floor. == stages.R
    clinical_min_avail_date. Config: { base_columns?: [..], sources: [{source, date_column |
    date_columns:[..]}] }.
    """
    base = idx.select("patientid", "index_date")
    parts, cols = base, []
    isrc = src.get(index_source)
    for bc in (blk.get("base_columns") or []):           # per-patient base date(s) (e.g. diagnosis)
        if isrc is not None and bc in isrc.columns:
            parts = parts.join(
                grain.one_row_per_key(F, isrc.select("patientid", F.col(bc).alias(f"_b_{bc}")),
                                      ["patientid"]), "patientid", "left")
            cols.append(f"_b_{bc}")
    for i, s in enumerate(blk.get("sources") or []):      # first (min) date per source
        sd = src.get(s.get("source"))
        if sd is None:
            continue
        dcs = [d for d in (s.get("date_columns") or [s.get("date_column")]) if d and d in sd.columns]
        if not dcs:
            continue
        row_date = f"least({', '.join(dcs)})" if len(dcs) > 1 else dcs[0]   # row-wise min (e.g. test/result)
        parts = parts.join(sd.groupBy("patientid").agg(F.min(F.expr(row_date)).alias(f"_f{i}")),
                           "patientid", "left")
        cols.append(f"_f{i}")
    if not cols:
        return None
    return (parts.withColumn("minavaildate", F.expr(f"least({', '.join(cols)})"))
            .withColumn("basedur", F.expr("datediff(index_date, minavaildate)"))
            .select("patientid", "index_date", "minavaildate", "basedur"))


def _presence_flag_sql(fl) -> str:
    """A presence flag CASE: <from> IS NULL -> `absent` label, else `present` label (e.g. EC
    radiation_flag from radiationtherapydate). Mirrored in cases.R::presence_flag_sql (parity-tested)."""
    return f"CASE WHEN {fl['from']} IS NULL THEN '{fl['absent']}' ELSE '{fl['present']}' END"


def _passthrough(F, src, idx, blk, index_source):
    """Config-driven enhanced pass-through + presence flags (retires the former prostate-hardcoded
    gleason/PSA list; also carries EC radiation/recurrence columns). `columns: [{column, as?}]` aliases
    raw index-source columns; `flags: [{name, from, absent, present}]` adds a presence flag. Any column
    or flag whose source column is absent is skipped. == engine-r/stages.R::clinical_passthrough.
    """
    isrc = src.get(blk.get("source") or index_source)
    if isrc is None:
        return None
    cols = [c for c in (blk.get("columns") or []) if c["column"] in isrc.columns]
    flags = [f for f in (blk.get("flags") or []) if f["from"] in isrc.columns]
    if not cols and not flags:
        return None
    raw = sorted({c["column"] for c in cols} | {f["from"] for f in flags})
    # "enhanced = one row per patient" is an ASSUMPTION about the source, not a fact about it.
    # A deterministic pick means a false assumption yields the same wrong answer every run instead
    # of a different one per run; `grain.assert_one_row_per_key` is what says it is false.
    e = grain.one_row_per_key(F, isrc.select("patientid", *raw), ["patientid"])
    out = idx.select("patientid", "index_date").join(e, "patientid", "left")
    keep = ["patientid", "index_date"]
    for c in cols:
        nm = c.get("as", c["column"])
        if c.get("bands"):                       # categorize a numeric enhanced column (e.g. Gleason score)
            out = (out.withColumn(nm, F.expr(_num_bands_case(c["bands"], c["column"], "label")))
                   .withColumn(nm + "n", F.expr(_num_bands_case(c["bands"], c["column"], "code"))))
            keep += [nm, nm + "n"]
        else:
            out = out.withColumn(nm, F.col(c["column"]))
            keep.append(nm)
    for f in flags:
        out = out.withColumn(f["name"], F.expr(_presence_flag_sql(f)))
        keep.append(f["name"])
    return out.select(*keep)


def _durations(F, src, idx, blk, index_source):
    """Config-driven derived durations: datediff between two dated milestones, in months (default) or
    days. `from`/`to` are enhanced-source date columns or the literal 'index_date'; each item is emitted
    only when BOTH its date columns are available (an absent enhanced column -> the item is skipped).
    Config: durations: { source?, days_per_month?, items: [{name, from, to, unit?: months|days}] }.
    == engine-r/stages.R::clinical_durations.
    """
    isrc = src.get(blk.get("source") or index_source)
    if isrc is None:
        return None
    dpm = float(blk.get("days_per_month", 30.4375))
    avail = lambda c: c == "index_date" or c in isrc.columns          # noqa: E731
    items = [it for it in (blk.get("items") or []) if avail(it.get("from")) and avail(it.get("to"))]
    if not items:
        return None
    cols = sorted({it[k] for it in items for k in ("from", "to")} - {"index_date"})
    e = grain.one_row_per_key(F, isrc.select("patientid", *cols), ["patientid"])
    out = idx.select("patientid", "index_date").join(e, "patientid", "left")
    for it in items:
        days = f"datediff({it['to']}, {it['from']})"
        out = out.withColumn(it["name"], F.expr(days if it.get("unit") == "days" else f"({days})/{dpm}"))
    return out.select("patientid", "index_date", *[it["name"] for it in items])


def _metastatic_sites(F, src, idx, blk):
    """Per-site Yes/No presence flags at index (prostate ClinChars: HEPATIC/LUNG/ADRENAL/BONE/BRAIN_MET):
    Yes if the patient has a metastasis record at the site dated BEFORE index (DateOfMetastasis <
    index_date AND SiteOfMetastasis == match), else No. blk: { source, site_column, date_column,
    yes_label?, no_label?, sites: [{name, match}] }. Presence = max() over the metastasis rows in the
    (patientid, index_date) group. == engine-r/stages.R::clinical_metastatic_sites.
    """
    s = src.get(blk["source"])
    if s is None:
        return None
    site_col, date_col = blk["site_column"], blk["date_column"]
    if site_col not in s.columns or date_col not in s.columns:
        return None
    yes, no = blk.get("yes_label", "Yes"), blk.get("no_label", "No")
    base = idx.select("patientid", "index_date")
    j = base.join(s.select("patientid", site_col, date_col), "patientid", "left")
    aggs = [F.max(F.expr(
        f"CASE WHEN lower({site_col}) = {_q(str(it['match']).lower())} AND {date_col} < index_date "
        f"THEN 1 ELSE 0 END")).alias("_" + it["name"]) for it in blk["sites"]]
    g = j.groupBy("patientid", "index_date").agg(*aggs)
    for it in blk["sites"]:
        g = (g.withColumn(it["name"], F.expr(f"CASE WHEN _{it['name']} = 1 THEN {_q(yes)} ELSE {_q(no)} END"))
             .drop("_" + it["name"]))
    return g


def _derived(F, clin, items, study):
    """Config-driven derived columns over the ASSEMBLED clinical frame + study constants — the spec
    master mutate (INDEXYR / INITYR / MCRPCDDYR / MPCDDYR / PINDDUR / FUDUR / PFUDUR). Each item is emitted
    only when all its `requires` columns are present (graceful — so a tumor lacking mcrpcdd/fued simply
    omits the dependent variable). `{index_start}` / `{index_end}` in the expr are substituted from study
    config. == engine-r/stages.R::clinical_derived.
    """
    cols = set(clin.columns)
    for it in (items or []):
        if not all(c in cols for c in (it.get("requires") or [])):
            continue
        expr = (it["expr"].replace("{index_start}", f"date('{study['index_start']}')")
                .replace("{index_end}", f"date('{study['index_end']}')"))
        clin = clin.withColumn(it["name"], F.expr(expr))
    return clin


def build(src, idx, cfg):
    from pyspark.sql import functions as F
    clin_cfg = cfg.pack("clinical")
    base = idx.select("patientid", "index_date")

    # Baseline ECOG is OPTIONAL: a tumor/vendor without a baseline_ecog table lints clean and
    # gets the configured Missing value rather than a KeyError.
    ecog_cfg = clin_cfg["baseline_ecog"]
    if "baseline_ecog" in src:
        ecog = baseline_ecog(src, idx, ecog_cfg)
    else:
        ecog = (base
                .withColumn("ecog", F.lit(ecog_cfg["missing_label"]))
                .withColumn("ecogn", F.lit(ecog_cfg["missing_code"])))

    clin = (base
            .join(ecog, ["patientid", "index_date"], "left")
            .join(follow_up_and_death(src, idx, clin_cfg),
                  ["patientid", "index_date"], "left"))

    # Stage (config-driven grouping) from `groupstage`. The source/date/priority are configurable
    # (staging.source / staging.date_column / staging.pick) so a patient with multiple stage rows
    # is resolved DETERMINISTICALLY (latest/earliest by date, then stable tiebreak) — not an
    # arbitrary dropDuplicates pick. Defaults: index source, latest, groupstage tiebreak.
    from pyspark.sql.window import Window
    stcfg = clin_cfg.get("staging") or {}
    groups = stcfg.get("groups")
    st_src = src.get(stcfg.get("source", cfg.index_source))
    if st_src is not None and groups and "groupstage" in st_src.columns:
        st = _categorical_pick(F, Window, st_src, "groupstage", groups, "stage",
                               stcfg.get("date_column"), stcfg.get("pick", "latest"))
        clin = clin.join(st, "patientid", "left")

    # Generic categorical clinical characteristics (grade / histology / …): the same value->group
    # CASE as staging, on any source column, picked deterministically per patient. Reuses the
    # parity-proven _stage_case compiler. Config: clinical.categoricals:
    #   [{name, column, source?, date_column?, pick?, groups: [...]}].
    for cat in (clin_cfg.get("categoricals") or []):
        cat_src = src.get(cat.get("source", cfg.index_source))
        col, cgroups, cname = cat.get("column"), cat.get("groups"), cat.get("name")
        if cat_src is None or not cgroups or not col or not cname or col not in cat_src.columns:
            continue
        # `window_days` makes the pick INDEX-ANCHORED, and therefore per (patientid, index_date)
        # rather than per patient — see _categorical_pick_windowed for why the join key differs.
        # A window whose date column the source does not carry is skipped rather than silently
        # falling back to the unwindowed pick: "the value at index" and "the patient's latest
        # value" are different answers, and quietly substituting one for the other is the failure
        # this branch exists to avoid. Preflight requires the column, so this is belt-and-braces.
        wd = cat.get("window_days")
        if wd is not None:
            if cat.get("date_column") in cat_src.columns:
                clin = clin.join(_categorical_pick_windowed(F, Window, cat_src, cat, idx),
                                 ["patientid", "index_date"], "left")
            continue
        # THE MAPPING FORM, UNWRAPPED. `pick: {method: latest}` is legal config the windowed path
        # already sees through (`_selection_spec`); this path read the raw value, so the mapping
        # form arrived as a dict, matched no branch, and fell through to the default — the same
        # spelling answering two different questions depending on which branch read it.
        _pk = cat.get("pick", "latest")
        _pk = _pk.get("method", _pk) if isinstance(_pk, dict) else _pk
        clin = clin.join(
            _categorical_pick(F, Window, cat_src, col, cgroups, cname,
                              cat.get("date_column"), _pk),
            "patientid", "left")

    # Closest-to-index PANELS (biomarkers / labs): each item picks the record nearest index within
    # its window and maps the value via the shared _stage_case compiler. Optional per tumor.
    for blk_key in CLOSEST_PANELS:
        blk = clin_cfg.get(blk_key)
        if blk and blk.get("source") in src and blk.get("panel"):
            clin = clin.join(_closest_panel(F, Window, src[blk["source"]], blk, idx),
                             ["patientid", "index_date"], "left")

    # Baseline comorbidity burden: distinct matched conditions in a pre-index lookback, weighted
    # and summed. Optional and config-gated like every other family; the code sets and weights are
    # the pack's (see comorbidity_index for why the engine ships none).
    cci = clin_cfg.get("comorbidity_index")
    if cci and cci.get("source") in src and cci.get("conditions"):
        cc = comorbidity_index(F, src, idx, cci)
        if cc is not None:
            clin = clin.join(cc, ["patientid", "index_date"], "left")

    # Metastatic-site presence flags at index (hepatic/lung/adrenal/bone/brain) — optional, config-gated.
    msblk = clin_cfg.get("metastatic_sites")
    if msblk and msblk.get("source") in src and msblk.get("sites"):
        ms = _metastatic_sites(F, src, idx, msblk)
        if ms is not None:
            clin = clin.join(ms, ["patientid", "index_date"], "left")

    # Closest-to-index raw lab VALUES (LABNEU present flag + LABNEUv value + LABNEUdt date) — optional.
    lvblk = clin_cfg.get("lab_values")
    if lvblk and lvblk.get("source") in src and lvblk.get("panel"):
        clin = clin.join(_closest_values_panel(F, Window, src[lvblk["source"]], lvblk, idx),
                         ["patientid", "index_date"], "left")

    # Windowed PSA timepoints + PSA-response endpoints (PSA at index / 6mo / 12mo; PSA50 / undetectable).
    psablk = clin_cfg.get("psa_timepoints")
    if psablk and psablk.get("source") in src and psablk.get("points"):
        clin = clin.join(_psa_timepoints(F, Window, src[psablk["source"]], psablk, idx),
                         ["patientid", "index_date"], "left")

    # OC surgery sub-block (issurg / surg / surgn / neoadj + tt_first_tx_diag) — optional, config-gated.
    scfg = clin_cfg.get("surgery")
    if scfg and scfg.get("source") in src:
        sg = _surgery(F, src, idx, scfg)
        if sg is not None:
            clin = clin.join(sg, ["patientid", "index_date"], "left")

    # minavaildate / basedur (data-availability floor) — optional, config-gated (OC/EC).
    mblk = clin_cfg.get("min_avail_date")
    if mblk and (mblk.get("sources") or mblk.get("base_columns")):
        mad = _min_avail_date(F, src, idx, mblk, cfg.index_source)
        if mad is not None:
            clin = clin.join(mad, ["patientid", "index_date"], "left")

    # Baseline BMI from vitals — optional (a tumor without a vitals table just omits these columns).
    if "vitals" in src and clin_cfg.get("vitals"):
        clin = clin.join(vitals(src, idx, clin_cfg["vitals"]), ["patientid", "index_date"], "left")

    # Config-driven enhanced pass-through + presence flags (EC radiation/recurrence; prostate
    # gleason/PSA) — see clinical.passthrough. Replaces the former hardcoded gleason/PSA list.
    pblk = clin_cfg.get("passthrough")
    if pblk:
        pt = _passthrough(F, src, idx, pblk, cfg.index_source)
        if pt is not None:
            clin = clin.join(pt, ["patientid", "index_date"], "left")

    # Derived durations (months/days between two dated milestones, e.g. diagnosis->metastasis) — optional.
    dblk = clin_cfg.get("durations")
    if dblk and dblk.get("items"):
        du = _durations(F, src, idx, dblk, cfg.index_source)
        if du is not None:
            clin = clin.join(du, ["patientid", "index_date"], "left")

    # mCRPC index-window flag + MCRPCDD date — config-gated (clinical.mcrpc_window): greatest(columns)
    # within the study window. Emitted when all configured date columns exist on the index source.
    mcw = clin_cfg.get("mcrpc_window")
    isrc = src.get(cfg.index_source)
    if mcw and isrc is not None and set(mcw.get("columns") or []) <= set(isrc.columns):
        start = F.lit(cfg.study["index_start"]).cast("date")
        end = F.lit(cfg.study["index_end"]).cast("date")
        dnm, fnm = mcw.get("date_as", "mcrpcdd"), mcw.get("flag_as", "mcrpc")
        mc = (grain.one_row_per_key(
                  F, isrc.select("patientid", F.greatest(*mcw["columns"]).alias(dnm)),
                  ["patientid"])                      # enhanced index source = one row per patient
              .withColumn(fnm, F.when((F.col(dnm) >= start) & (F.col(dnm) <= end),
                                      F.lit(1)).otherwise(F.lit(0))))
        clin = clin.join(mc, "patientid", "left")

    # Derived columns over the assembled frame (spec master mutate: INDEXYR / diagnosis-years / durations).
    dvb = clin_cfg.get("derived")
    if dvb:
        clin = _derived(F, clin, dvb, cfg.study)
    return clin
