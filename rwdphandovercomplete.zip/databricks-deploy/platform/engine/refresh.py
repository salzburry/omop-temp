"""Refresh governance — per-refresh manifests so git IS the refresh ledger.

Each released data cut (a `refresh`, e.g. 2026q1) writes a manifest under
`refreshes/<family>/<product>/<spec_version>/<refresh>.yaml`, committed to git. The manifest records exactly what produced
the ADS (spec version, git commit, run params, row/cohort counts, QC result, golden summary) and
its sign-off — so any number is reproducible (checkout the commit/tag, re-run the same config).

Pure Python (no Spark): build_manifest() assembles the manifest; validate_manifest() checks it.
The Databricks runner can write it after build+QC; sign-off fields are filled by a reviewed commit.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

try:                       # engine version stamp (build-level provenance); cheap, no Spark
    from .version import ENGINE_VERSION
except Exception:          # noqa: BLE001 - keep manifest buildable even if VERSION is unreadable
    ENGINE_VERSION = "unknown"

STATUSES = ["qc_pending", "qc_passed", "released", "superseded"]
REQUIRED = ["tumor", "refresh", "spec_version", "built_at", "status", "counts"]


def build_manifest(cfg, *, tumor, family="oncology", git_commit=None, counts=None, qc=None, golden=None,
                   source_qc=None, source_qc_gate=None, deliverables=None, artifacts=None,
                   published_at=None, source_lineage=None, config_identity=None,
                   run_mode=None, output_contract=None, differential=None) -> dict:
    """Assemble a refresh manifest from the resolved config + the run's outputs.

    `source_qc` is the full pre-build source-QC REPORT (mortality granularity + death-conflict
    counts); `source_qc_gate` is its pass/fail decision. `deliverables` records per-artifact status
    (dictionary / TFLs: ok | empty | failed | skipped) so the ledger shows whether the refresh's
    deliverables are complete.

    `published_at` is None for the PRE-publish ledger (written before the temp-then-swap) and is set
    to the swap timestamp only AFTER a successful publish. So `status: qc_passed` with a null
    `published_at` means "cleared QC, NOT yet published" and can never be mistaken for a successful
    publish (e.g. if the swap failed after the pre-publish ledger was written).
    """
    return {
        "tumor": tumor,
        "family": family,                       # product family (oncology) — first segment of the ledger path
        "refresh": cfg.refresh,
        "spec_version": cfg.spec_version,       # CalVer contract (e.g. 202606); the cut is `refresh`
        "data_product_id": cfg.data_product_id, # stable product id (also stamped on every ADS row)
        "engine_version": ENGINE_VERSION,       # build-level provenance: which engine produced this
        "vendor": cfg.vendor,
        "tumor_class": cfg.tumor_class,
        "built_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "git_commit": git_commit,
        "source_schema": cfg.source_schema,
        "source_union": cfg.source_union,      # the member schemas+flags that produced the build (EC);
                                               # None for a single-schema source. source_schema is
                                               # unused under a union, so this is the real provenance.
        "output_table": cfg.output_fqn,
        # THE CONFIG THE BUILD EXECUTED, as digests — {config_bundle_sha256, delivery_sha256} from
        # product_gates. `spec_version` names a config; this pins its BYTES, so a candidate built
        # under one configuration cannot promote after the pack quietly becomes another
        # (release.candidate_binding_blockers compares these against the runtime pack).
        "config_identity": dict(config_identity or {}),
        # THE MODE THIS CANDIDATE WAS BUILT IN — {env, release_grade}. A dev candidate used to be
        # indistinguishable from a release-grade one in its own bytes; promotion under prod now
        # refuses a candidate that does not record release-grade construction.
        "run_mode": dict(run_mode or {}),
        "status": "qc_passed" if (qc or {}).get("passed") else "qc_pending",
        "published_at": published_at,          # None until the swap succeeds (set post-publish)
        "counts": counts or {},
        # {source name: [{fqn, table_id, delta_version, last_commit_at, ...} | {fqn, error}]}.
        # Git pins the CODE this run executed; this pins the DATA it read — `VERSION AS OF
        # delta_version` on table_id re-reads the exact bytes. An input whose identity could not be
        # probed appears as an error entry, never as an omission.
        "source_lineage": source_lineage or {},
        "source_qc": source_qc or {},          # full report (granularity, conflict counts)
        "source_qc_gate": source_qc_gate or {},  # pass/fail decision
        "qc": qc or {},
        # THE OUTPUT CONTRACT — is the product the SHAPE it promised, as distinct from `qc`, which
        # scores its distributions. Carried separately and never folded into `qc`: they fail for
        # different reasons and a reader tracing a bad release needs to know which one let it out.
        "output_contract": output_contract or {},
        "golden": golden or {"reference": "none"},
        # PATIENT-LEVEL comparison against the reference. Separate from `golden`, which
        # scores aggregates: the two can disagree, and when they do it is the
        # aggregate one that looks clean.
        "differential": differential or {"reference": "none"},
        "deliverables": deliverables or {},    # {dictionary: {...}, tfls: {...}} status
        "artifacts": artifacts or {},   # durable paths: qc_report, dictionary, tfl_dir
        "sign_off": {"qc_by": "", "qc_date": "", "released_by": "", "released_date": ""},
    }


def manifest_path(manifest: dict, root) -> Path:
    """The SPEC-VERSIONED ledger path for a manifest:
    `<root>/refreshes/<family>/<product>/<spec_version>/<refresh>.yaml`. The spec_version segment lets two
    contracts of the same product (e.g. 202603 and 202606) coexist for the same refresh without colliding.
    `<product>` is the registry CODE (the durable identity, == the release-tag segment)."""
    return (Path(root) / "refreshes" / str(manifest.get("family", "oncology")) / str(manifest["tumor"])
            / str(manifest["spec_version"]) / f"{manifest['refresh']}.yaml")


def release_dir(root, manifest: dict, build_id: str) -> Path:
    """The matching immutable evidence dir for a build:
    `<root>/releases/<family>/<product>/<spec_version>/<refresh>/<build_id>/` (engine/audit.py bundle)."""
    return (Path(root) / "releases" / str(manifest.get("family", "oncology")) / str(manifest["tumor"])
            / str(manifest["spec_version"]) / str(manifest["refresh"]) / str(build_id))


def write_manifest(manifest: dict, root) -> str:
    """Write a VALID manifest to the spec-versioned ledger path (see manifest_path). Returns the path.

    Refuses to write an invalid manifest. (The runner calls this best-effort; the manifest is then
    committed to git — that commit is the audited refresh record.)
    """
    import yaml
    probs = validate_manifest(manifest)
    if probs:
        raise ValueError("refusing to write an invalid manifest:\n  - " + "\n  - ".join(probs))
    path = manifest_path(manifest, root)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        yaml.safe_dump(manifest, fh, sort_keys=False, default_flow_style=False)
    return str(path)


# THE FIVE VERDICTS A CANDIDATE STANDS ON, and the ONE place they are listed.
#
# (manifest key, human name, whether a MISSING verdict blocks)
#
# An external review found the defect this closes: the runner computed the output-contract and
# differential gates, printed them, wrote them into the manifest — and failed the job on `qc` and
# `golden` alone. Two gates built in the same week as the review, neither wired to the thing that
# stops the run. A failed output contract produced a green candidate; a failed differential reached
# release validation unexamined.
#
# The fix is not another `if` beside the first: it is ONE list, consumed by the job's failure
# condition, the manifest status, and the release check, so a sixth gate cannot be added to two of
# the three again. That is exactly how these two came to be enforced in one place out of three.
#
# `required` distinguishes a verdict that must EXIST from one that is legitimately absent. Golden
# and differential compare against a reference ADS, and there is not always one — `golden_gate`
# already returns `{passed: True, skipped: ...}` in that case, which is an evaluated answer. A
# missing `output_contract`, by contrast, means nobody asked whether the product had the right
# shape, and "not asked" must never read as "passed".
CANDIDATE_VERDICTS = (
    ("source_qc_gate", "source QC", True),
    ("qc", "ADS QC", True),
    ("output_contract", "output contract", True),
    ("golden", "aggregate golden", False),
    ("differential", "patient differential", False),
)


def candidate_verdict(m: dict) -> dict:
    """{passed, failures, evaluated, not_evaluated} over ALL FIVE gates. Pure data.

    The single verdict the review asked for. `golden` nests its decision under `gate`; the others
    carry `passed` at the top level, and that shape difference is read here once rather than at
    every call site — which is how a caller comes to check the wrong key and always see None.
    """
    failures, evaluated, missing = [], [], []
    for key, name, required in CANDIDATE_VERDICTS:
        block = m.get(key) or {}
        # `golden` is {reference, summary, gate:{passed}}; everything else is {passed}.
        decision = (block.get("gate") or {}) if key == "golden" and "gate" in block else block
        passed = decision.get("passed")
        if passed is True:
            evaluated.append(name)
        elif passed is False:
            evaluated.append(name)
            det = decision.get("failures") or decision.get("unapproved") or []
            failures.append(f"{name} FAILED" + (f": {det[0]}" if det else ""))
        elif required:
            failures.append(f"{name} has NO verdict — nothing asked whether this candidate passed "
                            f"it, and 'not asked' is not 'passed'")
        else:
            missing.append(name)
        # An UNAPPROVED difference is a failure even when `passed` was set True by an older writer:
        # the differential's whole point is that a change nobody accepted must stop the run.
        if key == "differential" and decision.get("unapproved") and passed is not False:
            failures.append(f"{name}: {len(decision['unapproved'])} unapproved change(s) — "
                            f"{decision['unapproved'][0]}")
    return {"passed": not failures, "failures": failures,
            "evaluated": evaluated, "not_evaluated": missing}


def validate_manifest(m: dict) -> list:
    """Return a list of problems with a manifest (empty = valid). Pure data check."""
    out = []
    for k in REQUIRED:
        if k not in m or m[k] in (None, ""):
            out.append(f"manifest missing '{k}'")
    if m.get("status") not in STATUSES:
        out.append(f"status '{m.get('status')}' not one of {STATUSES}")
    if m.get("status") == "released":
        # ALL FOUR, not just the release approver: Gate 5's reviewer (qc_by/qc_date) was dropped
        # during promotion, so the receipt said who released and not who reviewed the evidence.
        for _f in ("released_by", "released_date", "qc_by", "qc_date"):
            if not m.get("sign_off", {}).get(_f):
                out.append(f"status 'released' requires sign_off.{_f}")
        if not m.get("git_commit"):
            out.append("status 'released' requires git_commit (reproducibility)")
        # 'released' is set only AFTER a successful publish (refreshes/README.md step 5) -> it must carry
        # the publish timestamp, the release pointer (the versioned set that went live), AND a passed
        # tfl_promotion (the public views were swapped) — not just QC. The runner sets passed False on a
        # release-phase failure and True only after every public view swaps, so this rejects a released
        # manifest whose swap never completed.
        if not m.get("published_at"):
            out.append("status 'released' requires published_at (a released refresh was published)")
        if m.get("release") is None:
            out.append("status 'released' requires a release pointer (the versioned set that went live)")
        if not (m.get("tfl_promotion") or {}).get("passed"):
            out.append("status 'released' requires tfl_promotion.passed True (the public views swapped)")
        # GATE 5, RE-DERIVED FROM THE RECEIPT'S OWN EVIDENCE — not read off the status word. A
        # manifest saying `released` with its own qc block saying `passed: false` used to validate:
        # every check above asks about the RELEASE (pointer, swap, sign-off) and none asked whether
        # the thing released had passed the gates that authorise a release. The receipt carries the
        # evidence; a validator that does not read it certifies a contradiction.
        if (m.get("qc") or {}).get("passed") is not True:
            out.append("status 'released' requires qc.passed True — this receipt's own QC block "
                       "says the released build failed QC or never ran it")
        # THE RUNNER'S ACTUAL STRUCTURES, not lookalikes. The first version of this block read a
        # top-level `golden.passed` — a key the runner never writes (it writes `golden.gate.passed`)
        # — so an adversarial receipt carrying the runner's REAL failed structure validated with no
        # errors, which an external review demonstrated. Every check below names the field the
        # runner writes, and absence is a refusal, never a pass: for a released receipt, missing
        # evidence and failed evidence are the same answer.
        _g = m.get("golden") or {}
        if str(_g.get("reference") or "").strip() in ("", "none"):
            out.append("status 'released' requires a golden comparison against a named reference — "
                       "`reference: none` (or absent) is a build nobody compared, and a release is "
                       "not the place to find that out")
        else:
            if ((_g.get("gate") or {}).get("passed")) is not True:
                out.append("status 'released' requires golden.gate.passed True — this receipt's "
                           "own golden gate records a failure, or never ran")
            _gi = _g.get("identity") or {}
            if not (_gi.get("table_id") and _gi.get("location")):
                out.append("status 'released' requires golden.identity {table_id, location} — an "
                           "unpinned reference can be swapped for another table between the "
                           "comparison and the reader")
        if ((m.get("source_qc_gate") or {}).get("passed")) is not True:
            out.append("status 'released' requires source_qc_gate.passed True — a released receipt "
                       "with no source-QC verdict (or a failed one) stands on unexamined inputs")
        # THE OUTPUT CONTRACT, and a MISSING one fails exactly as a failed one does. A receipt that
        # never asked whether its product was uniquely keyed, carried every configured cohort and
        # held only values its codelists enumerate is a receipt standing on an unexamined OUTPUT —
        # the mirror of the source-QC clause above, and the gap an external review found: the QC
        # gate scored four rates and could pass a duplicated or incomplete product.
        if ((m.get("output_contract") or {}).get("passed")) is not True:
            out.append("status 'released' requires output_contract.passed True — a released receipt "
                       "with no output-contract verdict (or a failed one) stands on an unexamined "
                       "product: nothing has checked its grain, its cohorts or its vocabularies")
        # THE PATIENT DIFFERENTIAL, which had no clause here at all. The clauses above are precise
        # and are what a reader sees; this is the backstop that makes the SET complete, because the
        # defect was never a badly worded clause — it was a gate with no clause, and a fifth one
        # added tomorrow would land the same way. `candidate_verdict` owns the list.
        for _f in candidate_verdict(m)["failures"]:
            if not any(_f.split(" FAILED")[0].split(" has NO")[0] in existing for existing in out):
                out.append(f"status 'released': {_f}")
        if not m.get("source_lineage"):
            out.append("status 'released' requires source_lineage — a released receipt that pins "
                       "no inputs cannot re-read what it published from")
        if not m.get("candidate_identity"):
            out.append("status 'released' requires candidate_identity — the staged-table identity "
                       "the approval was signed over is the receipt's subject, not an option")
        # DELIVERABLES: recorded, and each one either produced (`ok`) or honestly not configured
        # (`empty`). `skipped` and `failed` both mean the release shipped without something it was
        # asked to ship; a receipt with NO deliverables block recorded is a build that never
        # accounted for them at all.
        if not m.get("deliverables"):
            out.append("status 'released' requires a deliverables block — a release that recorded "
                       "no deliverable outcomes cannot claim they were produced")
        for _name, _d in sorted((m.get("deliverables") or {}).items()):
            _st = str((_d or {}).get("status") if isinstance(_d, dict) else _d)
            if _st not in ("ok", "empty"):
                out.append(f"status 'released' with deliverables.{_name} '{_st}' — every "
                           f"deliverable is `ok` (produced) or `empty` (none configured); anything "
                           f"else shipped without something it was asked to ship")
        # THE MODE THE CANDIDATE WAS BUILT IN, recorded — promotion additionally refuses a governed
        # (prod) publish of a candidate that does not record release-grade mode
        # (release.candidate_binding_blockers); the receipt merely has to SAY which mode it was.
        if not str(((m.get("run_mode") or {}).get("env")) or "").strip():
            out.append("status 'released' requires run_mode.env — a receipt that cannot say which "
                       "environment built it cannot evidence release-grade construction")
    counts = m.get("counts") or {}
    if "total_rows" in counts and not isinstance(counts["total_rows"], int):
        out.append("counts.total_rows must be an integer")
    # source_lineage, when present, is shape-checked: every entry names its fqn and carries either
    # a probed identity (table_id + delta_version) or an error. A half-entry — identity fields with
    # neither id nor version, and no error — is a lineage that cannot re-read anything and would
    # ride the ledger looking like one that can.
    for src, entries in (m.get("source_lineage") or {}).items():
        if not isinstance(entries, list) or not entries:
            out.append(f"source_lineage['{src}'] must be a non-empty list of per-table entries")
            continue
        for e in entries:
            if not isinstance(e, dict) or not e.get("fqn"):
                out.append(f"source_lineage['{src}'] has an entry with no fqn")
            elif e.get("error") and m.get("status") == "released":
                out.append(f"source_lineage['{src}'] {e.get('fqn')}: carries error, not a pinned "
                           f"identity — a RELEASED manifest may not claim inputs it never pinned")
            elif not e.get("error") and not (e.get("table_id") and e.get("delta_version") is not None):
                out.append(f"source_lineage['{src}'] {e.get('fqn')}: neither a probed identity "
                           f"(table_id + delta_version) nor an error — this pins nothing")
            elif not e.get("error") and m.get("status") == "released" and not e.get("location"):
                out.append(f"source_lineage['{src}'] {e.get('fqn')}: no storage location — a "
                           f"RELEASED receipt pins inputs physically (id + version + location), "
                           f"because a name re-pointed at another path is a different table")
    su = m.get("source_union")
    if su is not None and not (isinstance(su, dict) and su.get("members")):
        out.append("source_union must carry members when present")
    tp = m.get("tfl_promotion")
    if tp is not None and (not isinstance(tp, dict) or "passed" not in tp):
        out.append("tfl_promotion must record a 'passed' flag when present")
    rel = m.get("release")
    if rel is not None:
        if not isinstance(rel, dict):
            out.append("release must be a mapping when present")
        else:
            miss = [k for k in ("public", "version", "build_id", "ads", "views") if not rel.get(k)]
            if miss:
                out.append(f"release missing {miss} (public/version/build_id/ads/views required when present)")
            elif not isinstance(rel["views"], dict) or rel["views"].get(rel["public"]) != rel["ads"]:
                out.append("release.views must map the public name to release.ads "
                           "(views[public] == ads, the ADS view is the commit anchor)")
    if m.get("published_at") and rel is None:
        out.append("a published manifest (published_at set) must carry a release pointer")
    return out
