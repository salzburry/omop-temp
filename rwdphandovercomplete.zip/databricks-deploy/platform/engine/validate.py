#!/usr/bin/env python3
"""Validate the prostate RWDP config + codelists before a build. Pure Python (no Spark).

Two entry points:
  * problems(cfg, strict=...) -> list[str]   collect issues (lint / tests)
  * check(cfg, strict=True)                  raise RuntimeError on the first build run

`strict=True` (the default for check) treats unfilled REPLACE_ME placeholders as errors, so the
Databricks job fails fast with an actionable message instead of resolving tables like
`REPLACE_ME.t_enh_prostate_REPLACE_ME`.

CLI (lint mode, placeholders allowed):
    python engine/validate.py config/data_product.yaml
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from config import load_config            # noqa: E402
from codelists import compile_case        # noqa: E402
import vocabularies                       # noqa: E402
# Registries the validator checks against — imported (not duplicated) so validation can't drift from
# what the engine actually resolves. clinical.py's module level is PySpark-free (pyspark is imported
# inside each stage function), so this is a cheap, side-effect-free import.
from stages.clinical import (BMI_FORMULAS, BSA_FORMULAS, CLOSEST_PANELS,   # noqa: E402
                            DEATH_CONFLICT_POLICIES, FOLLOWUP_FILTERS, FOLLOWUP_SOURCES,
                            selection_errors, value_matcher_errors)
from stages.ads_derived import ads_derived_errors, emitted as ads_derived_emitted   # noqa: E402

# The scaffold marker, checked as a SUBSTRING: a config value like `rwdp_REPLACE_ME_202606` is still
# unfilled even though it does not equal the marker. Deliberately NOT product_gates.unstated(), which
# asks a different question — "is this human-entered approval field an answer?" — with token/exact
# semantics, so that `NA-2026-01` stays a valid document id. Two predicates, one marker; do not merge
# them, and do not add a second spelling of the marker.
PLACEHOLDER = "REPLACE_ME"
REQUIRED_RUN_KEYS = ["refresh", "source_schema", "output_schema", "output_table"]
# Pack ROLES (file stems) the shared engine requires — tumor-agnostic (pack_id is just a label).
EXPECTED_ROLES = {"demographics", "clinical", "treatment", "outcomes"}
# Source mappings the shared engine genuinely REQUIRES (index/LOT/demographics/follow-up+death).
# Everything else is OPTIONAL — a tumor declares only the sources it has, so heme/COTA products
# without provenge/alphabet/vitals still validate. The engine + preflight handle declared-only.
REQUIRED_SOURCES = {"enhanced", "lot", "demographics", "mortality"}
KNOWN_VENDORS = {"flatiron", "cota"}
KNOWN_TUMOR_CLASSES = {"solid", "heme"}
# Mortality conflict-resolution policies are IMPORTED above, not restated. This was a set declared
# here with "keep in sync with engine/stages/clinical.py" above it — a hand-sync, two lines under an
# import from that very module and directly above a comment explaining why BMI/BSA are derived rather
# than copied. Two ways it broke: a policy added here only made the validator ACCEPT a config the
# engine then refuses mid-build (clinical.py raises on an unknown policy), and a policy added there
# only made the validator refuse one the engine supports. Worse, clinical.py's is a TUPLE whose
# element 0 is the default conflict resolution — order carries meaning that a set cannot hold, so
# reordering it silently changed which death date is selected (feeding OS, TTNT, PFS and follow-up
# duration) with no config edit and nothing to notice.
# Named BMI/BSA formula methods config may select (vitals.bmi_method / bsa_method) — DERIVED from the
# engine registries above, so a method added/removed in the engine is automatically valid/invalid here.
BMI_METHODS = set(BMI_FORMULAS)
BSA_METHODS = set(BSA_FORMULAS)
# Logical source names the NAMES-LIST form of follow_up_sources may restrict the default set to —
# DERIVED from the engine's FOLLOWUP_SOURCES so a source added/removed there stays in sync here.
FOLLOWUP_SOURCE_NAMES = {t[0] for t in FOLLOWUP_SOURCES}
# Banded lists that need exactly one `when: fallthrough` row, else out-of-range values become
# null instead of the intended catch-all (e.g. age "Unknown"/8). (pack ROLE, key-path).
BANDED_LISTS = [
    ("demographics", ("age_bands",)),
    ("clinical", ("vitals", "bmi_bands")),
    ("treatment", ("lot_count_bands",)),
]
# Columns the ported engine dereferences by exact (lower-cased) name, per source. Sources not
# listed are checked for existence only (loaded but not yet read by a ported stage). `enhanced`
# also needs the index-date `of` columns — added dynamically in required_columns().
REQUIRED_COLUMNS = {
    # detaileddrugcategory is NOT here: the delivered data carries the drug category on drug_episode,
    # not LOT (the treatment stage aggregates it per line). Required on drug_episode below, gated on the
    # codelist actually using category_equals.
    "lot": ["patientid", "linename", "linesetting", "startdate", "enddate", "linenumber"],
    "demographics": ["patientid", "birthyear", "race", "ethnicity", "state"],   # state -> regionl
    "baseline_ecog": ["patientid", "ecogdate", "ecogvalue"],
    "visit": ["patientid", "visitdate"],
    "telemed": ["patientid", "visitdate"],
    "orals": ["patientid", "enddate", "startdategranularity"],
    "alphabet": ["patientid", "administrationdate"],
    "provenge": ["patientid", "startdate"],
    "mortality": ["patientid", "dateofdeath"],
}


def problems(cfg, strict: bool = False) -> list[str]:
    out: list[str] = []

    # --- run / output -----------------------------------------------------
    for k in REQUIRED_RUN_KEYS:
        if not cfg.run.get(k):
            out.append(f"run.{k} is missing or empty")
        elif strict and PLACEHOLDER in str(cfg.run.get(k)):
            out.append(f"run.{k} = '{cfg.run.get(k)}' still contains the '{PLACEHOLDER}' "
                       f"placeholder — set a real value before running (prod values like "
                       f"'{PLACEHOLDER}_prod_source' are NOT real schemas)")

    # --- study window -----------------------------------------------------
    # Presence was the only check, so the template's shipped 2013-01-01 / 2025-12-31 passed as a real
    # answer for every product that copied it — a scientific decision from the SPEC, inherited. The
    # window is now REPLACE_ME in the template, and the placeholder has to be refused the same way
    # `run.*` placeholders are or the trap just changes shape.
    #
    # Deliberately NOT a date-format check here: `bad_date` is the one date predicate and it lives in
    # platform/tools, which the engine must not import. Adding a second ISO regex to this file is the
    # duplication this repo keeps paying for; a window that is present and not a placeholder but
    # misspelled is a real remaining gap, and one predicate in one place is how it should be closed.
    for k in ("index_start", "index_end"):
        if not cfg.study.get(k):
            out.append(f"study.{k} is missing")
        elif strict and PLACEHOLDER in str(cfg.study.get(k)):
            out.append(f"study.{k} = '{cfg.study.get(k)}' still contains the '{PLACEHOLDER}' "
                       f"placeholder — the study window comes from this product's specification, "
                       f"never from the template")

    # --- variable-pack placeholders ---------------------------------------
    # `variables_scaffold.py` emits parameter SKELETONS whose every value is the ONE placeholder
    # marker, meant to be filled from the approved workbook after a human copies a skeleton into
    # variables/. Only run.* and study.* were scanned, so a half-filled skeleton — bands copied,
    # window forgotten — would have built with the marker as a literal band label. Strict mode
    # (the build) refuses the marker ANYWHERE in a pack; lint mode keeps allowing it, the same
    # split every other placeholder check here has.
    if strict:
        def _holes(node, path):
            if isinstance(node, dict):
                for k, v in node.items():
                    yield from _holes(v, f"{path}.{k}")
            elif isinstance(node, list):
                for i, v in enumerate(node):
                    yield from _holes(v, f"{path}[{i}]")
            elif isinstance(node, str) and PLACEHOLDER in node:
                yield path
        try:
            for role in sorted(cfg.roles()):
                for where in _holes(cfg.pack(role), f"variables/{role}"):
                    out.append(f"{where} still contains the '{PLACEHOLDER}' placeholder — every "
                               f"scaffolded parameter value comes from the approved workbook "
                               f"before a build may run")
        except Exception:  # noqa: BLE001 - pack load problems reported elsewhere
            pass

    # --- cohorts ----------------------------------------------------------
    if not cfg.cohorts:
        out.append("cohorts is empty")
    ids, ns = set(), set()
    for c in cfg.cohorts:
        for f in ("id", "label", "cohortn", "index"):
            if f not in c:
                out.append(f"cohort {c.get('id', '?')} missing '{f}'")
        if c.get("id") in ids:
            out.append(f"duplicate cohort id '{c.get('id')}'")
        ids.add(c.get("id"))
        if c.get("cohortn") in ns:
            out.append(f"duplicate cohortn {c.get('cohortn')}")
        ns.add(c.get("cohortn"))
        idx = c.get("index")
        if idx and idx != "lot_start_date" and idx not in cfg.index_dates:
            out.append(f"cohort {c.get('id')} index '{idx}' not in index_dates and != lot_start_date")
        m = c.get("maintenance")
        if m is not None and not isinstance(m, bool):
            out.append(f"cohort {c.get('id')} maintenance must be true/false, got {m!r}")

    # --- LOT model (config-driven line numbering; defaults reproduce prostate) -------------
    ln = (cfg.raw.get("lot") or {}).get("line_number")
    if ln is not None and ln not in ("new_lot_n", "linenumber"):
        out.append(f"lot.line_number '{ln}' must be 'new_lot_n' or 'linenumber'")

    # --- sources (only the core set is required; the rest are optional per tumor) ----------
    if not cfg.sources:
        out.append("sources is empty")
    else:
        for missing in sorted(REQUIRED_SOURCES - set(cfg.sources)):
            out.append(f"sources is missing required mapping '{missing}'")

    # --- data format / formats overlay (EDM | Panoramic …) --------------------
    fmts = cfg.raw.get("formats") or {}
    if cfg.data_format != "EDM" and cfg.data_format not in fmts:
        out.append(f"data_format '{cfg.data_format}' has no `formats.{cfg.data_format}` overlay — "
                   "it would silently run on the base (EDM) sources")
    for fname, fblk in fmts.items():
        if not isinstance(fblk, dict):
            out.append(f"formats.{fname} must be a mapping")
            continue
        avail = {**(cfg.raw.get("sources") or {}), **(fblk.get("sources") or {})}
        for s in (fblk.get("rename") or {}):
            if s not in avail:
                out.append(f"formats.{fname}.rename references undeclared source '{s}'")

    # --- source_union (optional multi-schema union: EC = Flatiron EDM ∪ Dostar registry) --------
    u = cfg.source_union
    if u is not None:
        members = u.get("members") or []
        if not members:
            out.append("source_union.members is empty")
        for i, m in enumerate(members):
            for f in ("schema", "flag"):
                if not (isinstance(m, dict) and m.get(f)):
                    out.append(f"source_union.members[{i}] missing '{f}'")
            if strict and isinstance(m, dict) and PLACEHOLDER in str(m.get("schema")):
                out.append(f"source_union.members[{i}].schema '{m.get('schema')}' still "
                           f"contains the '{PLACEHOLDER}' placeholder")

    # --- vendor / tumor class --------------------------------------------
    if cfg.vendor not in KNOWN_VENDORS and not cfg.source_layout:
        out.append(f"vendor '{cfg.vendor}' is unknown and no run.source_layout override is set "
                   f"(known vendors: {sorted(KNOWN_VENDORS)})")
    if cfg.tumor_class not in KNOWN_TUMOR_CLASSES:
        out.append(f"tumor_class '{cfg.tumor_class}' not one of {sorted(KNOWN_TUMOR_CLASSES)}")

    # the index-date source must itself be a declared source
    if cfg.index_dates.get("advanced_diagnosis_date") and cfg.index_source not in cfg.sources:
        out.append(f"index source '{cfg.index_source}' "
                   f"(index_dates.advanced_diagnosis_date.source) is not a declared source")

    # --- variable packs (by role / file stem) ----------------------------
    try:
        roles = cfg.roles()
        for missing in sorted(EXPECTED_ROLES - roles):
            out.append(f"variable pack for role '{missing}' not found "
                       f"(expected variables/{missing}.yaml)")
    except Exception as e:  # noqa: BLE001 - surface any load/parse error as a problem
        out.append(f"failed to load variable packs: {e}")

    # --- banded lists need a catch-all -----------------------------------
    out += _bands_problems(cfg)

    # --- clinical categoricals (grade/histology/…): each needs name/column/groups -----------
    try:
        clin_pack = cfg.pack("clinical")
        # clinical.staging.source (when set) must be a declared source — else `stage` is silently
        # dropped at runtime (the stage uses src.get(...)). No source -> the index source.
        ss = (clin_pack.get("staging") or {}).get("source")
        if ss and ss not in cfg.sources:
            out.append(f"clinical.staging.source '{ss}' is not a declared source")
        for i, cat in enumerate(clin_pack.get("categoricals") or []):
            for f in ("name", "column", "groups"):
                if not cat.get(f):
                    out.append(f"clinical.categoricals[{i}] missing '{f}'")
            # An explicit source must be a declared source — a typo (source: enhnaced) would
            # otherwise lint clean, be skipped by required_columns()/preflight, and silently omit
            # the variable at runtime. (No source -> the index source, validated above.)
            cs = cat.get("source")
            if cs and cs not in cfg.sources:
                out.append(f"clinical.categoricals[{i}].source '{cs}' is not a declared source")
            # A WINDOWED categorical is a different question from an unwindowed one — the value at
            # index, not the patient's latest value ever — and the window needs a date to be
            # measured from. `window_days` without `date_column` is the silent case: the engine
            # cannot apply the window, and the nearest thing it could do (fall back to the
            # unwindowed pick) would answer the other question while the config says this one.
            wd = cat.get("window_days")
            if wd is not None:
                if not cat.get("date_column"):
                    out.append(f"clinical.categoricals[{i}] sets window_days without date_column — "
                               f"there is no date for the window to be measured from, and the "
                               f"value AT INDEX is not the patient's latest value")
                if not (isinstance(wd, (list, tuple)) and len(wd) == 2
                        and all(x is None or isinstance(x, int) for x in wd)):
                    out.append(f"clinical.categoricals[{i}].window_days must be [lo, hi] day offsets "
                               f"(either may be null for open-ended), got {wd!r}")
            # THE TWO CHECKS THE PANEL LOOP RUNS AND THIS ONE DID NOT. A generic categorical was
            # held to presence of name/column/groups and a declared source, and nothing else — so
            # an unregistered matcher operator or an unregistered `pick` reached the engine from a
            # categorical while the identical mistake in a panel was refused at lint time. Same
            # config shape, two answers, and the weaker one was the default path.
            out += [f"clinical.categoricals[{i}] {e}" for e in value_matcher_errors(cat.get("groups"))]
            out += [f"clinical.categoricals[{i}] {e}" for e in selection_errors(cat)]
            # THE MAPPING FORM, seen through. `pick: {method: priority}` is legal config that the
            # engine unwraps at runtime; comparing the raw value to the string "priority" missed it,
            # so the refusal below could be escaped by spelling the same thing the other way.
            pk = cat.get("pick")
            pk = pk.get("method", pk) if isinstance(pk, dict) else pk
            # A KEY THE SELECTOR CANNOT CONSUME IS REFUSED, not ignored. `same_date_conflict` is
            # resolved per (patient, index, DATE), so a categorical with no `date_column` has no
            # date for two records to conflict on and the unwindowed path cannot honour it. It used
            # to validate and do nothing — the shape this whole option exists to remove.
            if cat.get("same_date_conflict") is not None and not cat.get("date_column"):
                out.append(f"clinical.categoricals[{i}] sets same_date_conflict without "
                           f"date_column — the rule resolves two records dated the SAME DAY, and "
                           f"with no date column there is no such comparison to make")
            # `priority` ranks across ALL in-window rows and is meaningless without a window: with
            # one row per patient there is nothing to rank against.
            if pk == "priority" and wd is None:
                out.append(f"clinical.categoricals[{i}] picks 'priority' without window_days — "
                           f"priority ranks the rows inside a window, and there is no window")
        # closest-to-index panels (biomarkers / labs): block + each panel item need their fields
        for blk_key in CLOSEST_PANELS:
            blk = clin_pack.get(blk_key)
            if not blk:
                continue
            # `date_column` is required only under the DEFAULT date basis. A block selecting
            # `later_of` names `columns:` instead, and demanding both would make the new basis
            # unusable while looking like a completeness check.
            needed = ["source", "name_column", "value_column", "panel"]
            basis = blk.get("date_basis") or "column"
            if (basis.get("method") if isinstance(basis, dict) else basis) == "column":
                needed.insert(3, "date_column")
            for f in needed:
                if not blk.get(f):
                    out.append(f"clinical.{blk_key} missing '{f}'")
            # Named selection vocabulary, refused by the registry that owns it — never guessed.
            out += [f"clinical.{blk_key} {e}" for e in selection_errors(blk)]
            for i, item in enumerate(blk.get("panel") or []):
                out += [f"clinical.{blk_key}.panel[{i}] {e}" for e in selection_errors(None, item)]
                out += [f"clinical.{blk_key}.panel[{i}] {e}"
                        for e in value_matcher_errors(item.get("groups"))]
                if not item.get("name"):
                    out.append(f"clinical.{blk_key}.panel[{i}] missing 'name'")
                if not item.get("match") and not item.get("match_any"):   # scalar match OR a multi-name set
                    out.append(f"clinical.{blk_key}.panel[{i}] needs 'match' or 'match_any'")
                if not item.get("groups") and not item.get("bands"):
                    out.append(f"clinical.{blk_key}.panel[{i}] needs 'groups' or 'bands'")
            if blk.get("source") and blk["source"] not in cfg.sources:
                out.append(f"clinical.{blk_key}.source '{blk['source']}' is not a declared source")
            # `emit_date` is a switch, and a truthy non-bool (`emit_date: "no"`) would turn the
            # column ON while reading as off. The column it adds is published, so a silent
            # misreading here changes the delivered schema.
            ed = blk.get("emit_date")
            if ed is not None and not isinstance(ed, bool):
                out.append(f"clinical.{blk_key}.emit_date must be true or false, got {ed!r}")

        # --- comorbidity index: a weighted sum of DISTINCT conditions over a lookback -----------
        cci = clin_pack.get("comorbidity_index")
        if cci:
            for f in ("source", "name", "code_column", "conditions"):
                if not cci.get(f):
                    out.append(f"clinical.comorbidity_index missing '{f}'")
            if cci.get("source") and cci["source"] not in cfg.sources:
                out.append(f"clinical.comorbidity_index.source '{cci['source']}' is not a "
                           f"declared source")
            # The lookback is what makes it BASELINE comorbidity. Without a date column there is no
            # window, so the score would silently be computed over the patient's whole record —
            # including diagnoses made after index, which is the confounder measuring the outcome.
            if cci.get("window_days") and not cci.get("date_column"):
                out.append("clinical.comorbidity_index sets window_days without date_column — the "
                           "lookback cannot be applied, and a score over the whole record counts "
                           "diagnoses made AFTER index")
            wd = cci.get("window_days")
            if not wd:
                out.append("clinical.comorbidity_index has no window_days — baseline comorbidity is "
                           "defined by its pre-index lookback, and without one this scores every "
                           "diagnosis ever recorded, including post-index")
            elif not (isinstance(wd, (list, tuple)) and len(wd) == 2
                      and all(isinstance(x, int) and not isinstance(x, bool) for x in wd)):
                # Truthiness was the only test, so `[30, 90]`, `["a", "b"]` and a bare `True` all
                # passed. BOTH bounds are required and both must be integers: an open-ended
                # comorbidity lookback is not a lookback, and a non-integer reaches Spark as a
                # malformed `date_add`.
                out.append(f"clinical.comorbidity_index.window_days must be two integer day offsets "
                           f"[lo, hi] — neither may be null, because an open-ended lookback is not a "
                           f"lookback; got {wd!r}")
            else:
                lo, hi = wd
                if lo > hi:
                    out.append(f"clinical.comorbidity_index.window_days is reversed ({lo} > {hi}) — "
                               f"the window selects no rows, and every patient scores 0")
                if hi > 0 and not cci.get("post_index_days_reviewed"):
                    # THE ONE THAT PRODUCES A PLAUSIBLE WRONG NUMBER. A window ending after index
                    # counts diagnoses recorded AFTER the anchor, so a covariate meant to describe
                    # the patient at baseline has partly measured the outcome. Refused unless the
                    # pack says in as many words that the choice was reviewed — some claims designs
                    # do allow a short post-index tail for coding lag, and that is a decision, not a
                    # default.
                    out.append(f"clinical.comorbidity_index.window_days ends {hi} days AFTER index — "
                               f"baseline comorbidity measured past the anchor has partly measured "
                               f"the outcome. If a post-index tail is intended (coding lag), state "
                               f"`post_index_days_reviewed: <who/why>` beside it.")
            # HIERARCHY MUST BE ACYCLIC. A cycle, or a condition superseding itself, would make the
            # score depend on evaluation order — and self-supersession zeroes the winner by its own
            # presence, so the condition can never contribute.
            edges = {c.get("name"): set(c.get("supersedes") or [])
                     for c in cci.get("conditions") or [] if c.get("name")}
            for nm, losers in edges.items():
                if nm in losers:
                    out.append(f"clinical.comorbidity_index: condition '{nm}' supersedes itself — "
                               f"its own presence would zero it, so it can never contribute")
            # A CYCLE IS A NODE ON ITS OWN CURRENT PATH — not a node seen twice anywhere in the walk.
            #
            # The first version kept ONE `path` set for the whole traversal from each start and never
            # removed anything from it, so a converging DAG read as cyclic: with A→B, A→C, B→D and
            # C→D, D is reached down the C branch, added to `path`, and then reached again down the B
            # branch — reported as a cycle in a hierarchy that has none. That is a valid Charlson
            # shape (two severe conditions both superseding one mild one), and the validator refused
            # it. A check that rejects correct configurations gets deleted, which costs the cycles
            # it does catch.
            #
            # Colour-marked DFS instead: GREY = on the current path, BLACK = finished. Recursion is
            # explicit so a deep hierarchy cannot blow the stack.
            grey, black, seen_cycle = set(), set(), set()
            for start in edges:
                if start in black:
                    continue
                stack = [(start, iter(sorted(e for e in edges.get(start, ()) if e in edges)))]
                grey.add(start)
                while stack:
                    node, children = stack[-1]
                    nxt = next(children, None)
                    if nxt is None:
                        grey.discard(node)
                        black.add(node)
                        stack.pop()
                        continue
                    if nxt in grey:                       # a back edge — a real cycle
                        if nxt not in seen_cycle:
                            seen_cycle.add(nxt)
                            out.append(f"clinical.comorbidity_index: the supersedes hierarchy has a "
                                       f"cycle through '{nxt}' — the score would depend on the order "
                                       f"the conditions happen to be listed in")
                        continue
                    if nxt in black:                      # already fully explored — a diamond, fine
                        continue
                    grey.add(nxt)
                    stack.append((nxt, iter(sorted(e for e in edges.get(nxt, ()) if e in edges))))
            names = set()
            for i, c in enumerate(cci.get("conditions") or []):
                where = f"clinical.comorbidity_index.conditions[{i}]"
                nm = c.get("name")
                if not nm:
                    out.append(f"{where} missing 'name'")
                elif nm in names:
                    # Duplicate names make `supersedes` ambiguous and double-count silently.
                    out.append(f"{where} repeats the condition name '{nm}'")
                else:
                    names.add(nm)
                if c.get("weight") is None:
                    out.append(f"{where} has no 'weight' — the weight is the algorithm's, and a "
                               f"default of 1 would silently flatten a weighted index")
                elif not isinstance(c.get("weight"), (int, float)) or isinstance(c["weight"], bool):
                    out.append(f"{where}.weight must be a number, got {c['weight']!r}")
                ops = [k for k in c if k not in ("name", "weight", "supersedes")]
                if len(ops) != 1:
                    out.append(f"{where} needs exactly one match operator, got {sorted(ops)}")
            # A `supersedes` naming a condition that is not in the list does nothing, and reads
            # exactly like a hierarchy that is being applied.
            for i, c in enumerate(cci.get("conditions") or []):
                for s in c.get("supersedes") or []:
                    if s not in names:
                        out.append(f"clinical.comorbidity_index.conditions[{i}] supersedes "
                                   f"'{s}', which is not a condition in this list — the hierarchy "
                                   f"reads as applied and does nothing")
    except Exception:  # noqa: BLE001 - pack load problems reported elsewhere
        pass

    # --- mortality conflict-resolution policy ----------------------------
    try:
        imp = cfg.pack("clinical").get("death_date_imputation", {})
        cr = imp.get("conflict_resolution")
        if cr is not None and cr not in DEATH_CONFLICT_POLICIES:
            out.append("clinical.death_date_imputation.conflict_resolution "
                       f"'{cr}' not one of {sorted(DEATH_CONFLICT_POLICIES)}")
    except Exception:  # noqa: BLE001 - pack load problems reported elsewhere
        pass

    # --- BMI/BSA formula methods (named, resolved from the engine registries) --------------------
    try:
        vit = cfg.pack("clinical").get("vitals")
        if vit:
            # Legacy decorative keys the engine no longer reads -> flag so they can't silently mislead.
            for legacy in ("bmi_formula", "bsa_formula"):
                if legacy in vit:
                    out.append(f"clinical.vitals.{legacy} is a legacy decorative key the engine no longer "
                               f"reads — replace it with {legacy.split('_')[0]}_method: <name>")
            bm = vit.get("bmi_method")                 # required + non-empty string when vitals is on
            if not (isinstance(bm, str) and bm):
                out.append("clinical.vitals.bmi_method is required (a non-empty method name) when vitals "
                           f"is configured; one of {sorted(BMI_METHODS)}")
            elif bm not in BMI_METHODS:
                out.append(f"clinical.vitals.bmi_method '{bm}' not one of {sorted(BMI_METHODS)}")
            bs = vit.get("bsa_method")                 # optional; if present must be a known method
            if bs is not None and (not isinstance(bs, str) or bs not in BSA_METHODS):
                out.append(f"clinical.vitals.bsa_method '{bs}' not one of {sorted(BSA_METHODS)}")
    except Exception:  # noqa: BLE001 - pack load problems reported elsewhere
        pass

    # --- follow_up_sources: strict per-entry structure so a typo fails lint, not Spark --------------
    # Two forms mirror the engine: a DICT list (full override) or a NAMES list (restrict the engine
    # default set to these logical sources). BOTH are validated — an unchecked typo in either silently
    # yields empty follow-up, which nulls out fu_enddt for every patient.
    try:
        fus = cfg.pack("clinical").get("death_date_imputation", {}).get("follow_up_sources")
        if fus and isinstance(fus[0], dict):
            aliases = []
            for i, s in enumerate(fus):
                if not isinstance(s, dict):
                    out.append(f"death_date_imputation.follow_up_sources[{i}] must be a mapping")
                    continue
                srcn = s.get("source")
                if not (isinstance(srcn, str) and srcn):
                    out.append(f"follow_up_sources[{i}] missing 'source'")
                # NB: an entry pointing at an UNDECLARED source is NOT flagged — the engine gracefully
                # skips absent sources (a heme product declares fewer; see test_optional_source_not_required).
                if not (isinstance(s.get("date_column"), str) and s.get("date_column")):
                    out.append(f"follow_up_sources[{i}] missing 'date_column'")
                al = s.get("alias", f"last_{srcn}date" if srcn else None)
                if al is not None and not isinstance(al, str):
                    out.append(f"follow_up_sources[{i}].alias must be a string")
                else:
                    aliases.append(al)
                # the LOT activity date is referenced BY NAME downstream (death-date reconciliation), so
                # its alias is not freely configurable.
                if srcn == "lot" and al != "last_lotenddate":
                    out.append(f"follow_up_sources[{i}] (lot) must use alias 'last_lotenddate' — the "
                               "death-date reconciliation depends on that exact name")
                # filter_method must be a NON-EMPTY STRING naming a FOLLOWUP_FILTERS entry. Type-check
                # FIRST: a non-string such as `filter_method: []` raises an unhashable-key TypeError
                # in `fm not in FOLLOWUP_FILTERS`, which the outer except would swallow, letting a malformed
                # value pass lint.
                fm = s.get("filter_method")
                if fm is not None:
                    if not (isinstance(fm, str) and fm):
                        out.append(f"follow_up_sources[{i}].filter_method must be a non-empty string "
                                   f"naming a registry filter, got {fm!r}")
                    elif fm not in FOLLOWUP_FILTERS:
                        out.append(f"follow_up_sources[{i}].filter_method '{fm}' not one of "
                                   f"{sorted(FOLLOWUP_FILTERS)}")
                    if s.get("filter") is not None:   # the named filter_method WINS; raw 'filter' is dropped
                        out.append(f"follow_up_sources[{i}] sets both 'filter' and 'filter_method' — the "
                                   "named filter_method wins and 'filter' is silently ignored; keep one")
            dups = sorted({a for a in aliases if a is not None and aliases.count(a) > 1})
            if dups:
                out.append(f"follow_up_sources has duplicate aliases: {dups}")
        elif fus:
            # NAMES-list form: each entry restricts the engine default set to a KNOWN logical source.
            # An unknown name matches nothing -> empty follow-up, so flag it (the dict-form skip-undeclared
            # rule does NOT apply here: these names select FROM the fixed engine set, they don't add sources).
            for i, name in enumerate(fus):
                if not (isinstance(name, str) and name in FOLLOWUP_SOURCE_NAMES):
                    out.append(f"follow_up_sources[{i}] '{name}' is not a known follow-up source "
                               f"(one of {sorted(FOLLOWUP_SOURCE_NAMES)}); a typo silently yields "
                               "empty follow-up")
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # --- treatment prior-taxane (optional pre-mCRPC line source) ---------
    try:
        pt = cfg.pack("treatment").get("prior_taxane") or {}
        pre = pt.get("pre_mcrpc_source")
        if pre and pre not in cfg.sources:
            out.append(f"treatment.prior_taxane.pre_mcrpc_source '{pre}' is not a declared source")
    except Exception:  # noqa: BLE001 - pack load problems reported elsewhere
        pass

    # --- outcomes progression / PFS (optional) ---------------------------
    try:
        pcfg = cfg.pack("outcomes").get("progression")
        if pcfg:
            if pcfg.get("source") and pcfg["source"] not in cfg.sources:
                out.append(f"outcomes.progression.source '{pcfg['source']}' is not a declared source")
            for f in ("source", "date_column", "evidence_columns", "pseudoprogression_column"):
                if not pcfg.get(f):
                    out.append(f"outcomes.progression missing '{f}'")
    except Exception:  # noqa: BLE001 - pack load problems reported elsewhere
        pass

    # --- outcomes platinum_sensitivity / PROC (optional: OC) -------------
    try:
        psc = cfg.pack("outcomes").get("platinum_sensitivity")
        if psc:
            if psc.get("source") and psc["source"] not in cfg.sources:
                out.append(f"outcomes.platinum_sensitivity.source '{psc['source']}' is not a declared source")
            for f in ("source", "line_number_column", "name_column", "start_column", "end_column",
                      "platinum_agents"):
                if not psc.get(f):
                    out.append(f"outcomes.platinum_sensitivity missing '{f}'")
    except Exception:  # noqa: BLE001 - pack load problems reported elsewhere
        pass

    # --- outcomes ads_derived (optional: cross-stage landmarks/intervals/expressions) ----
    try:
        out += [f"outcomes.{e}" for e in
                ads_derived_errors(cfg.pack("outcomes").get("ads_derived"))]
    except Exception:  # noqa: BLE001 - pack load problems reported elsewhere
        pass

    # --- derived cohorts (optional: OC PROC split) -----------------------
    try:
        ids = {c.get("id") for c in cfg.cohorts}
        base_ns = {c.get("cohortn") for c in cfg.cohorts}
        for dc in (cfg.raw.get("derived_cohorts") or []):
            for f in ("id", "cohortn", "label", "from", "where"):
                if not dc.get(f):
                    out.append(f"derived_cohorts entry missing '{f}'")
            for frm in (dc.get("from") or []):
                if frm not in ids:
                    out.append(f"derived_cohorts '{dc.get('id')}' from-cohort '{frm}' is not a declared cohort")
            if dc.get("cohortn") in base_ns:
                out.append(f"derived_cohorts '{dc.get('id')}' cohortn {dc.get('cohortn')} collides with a base cohort")
    except Exception:  # noqa: BLE001 - pack load problems reported elsewhere
        pass

    # --- clinical surgery sub-block (optional: OC) -----------------------
    try:
        scfg = cfg.pack("clinical").get("surgery")
        if scfg:
            for s in (scfg.get("source"), scfg.get("line_source", "lot")):
                if s and s not in cfg.sources:
                    out.append(f"clinical.surgery source '{s}' is not a declared source")
            for f in ("source", "surgery_flag_column", "surgery_date_column", "line_start_column",
                      "line_end_column", "pcs_label", "ics_label", "none_label"):
                if not scfg.get(f):
                    out.append(f"clinical.surgery missing '{f}'")
    except Exception:  # noqa: BLE001 - pack load problems reported elsewhere
        pass

    # --- declared coding systems ------------------------------------------
    out += _vocabulary_problems(cfg)

    # --- treatment codelist ----------------------------------------------
    out += _codelist_problems(cfg)

    return out


def _vocabulary_problems(cfg) -> list[str]:
    """The `vocabularies:` block itself: every entry names a declared source, a column and a system.

    Absent means absent. A pack that declares nothing is not asserting its columns are text, and
    nothing here or in `_codelist_problems` refuses it — the engine behaves exactly as it did before
    this block existed. The value of declaring is that a CONTRADICTION becomes reportable; the cost
    of not declaring is that it stays invisible, which is the state every pack was already in.
    """
    out: list[str] = []
    seen = {}
    for i, v in enumerate(cfg.vocabularies):
        where = f"vocabularies[{i}]"
        source = str(v.get("source") or "").strip()
        column = str(v.get("column") or "").strip()
        if not source:
            out.append(f"{where}: no source named")
        elif source not in cfg.sources:
            out.append(f"{where}: source '{source}' is not declared in sources: "
                       f"{sorted(cfg.sources)}")
        if not column:
            out.append(f"{where}: no column named")
        for why in vocabularies.system_errors(v.get("system")):
            out.append(f"{where}: {why}")
        key = (source.lower(), column.lower())
        if source and column:
            if key in seen:
                # Last-wins on a duplicate would silently pick one of two contradictory answers to
                # "what does this column carry" — the question the block exists to settle.
                out.append(f"{where}: {source}.{column} already declared at {seen[key]} — one "
                           f"column carries one coding system")
            else:
                seen[key] = where
    return out


def _bands_problems(cfg) -> list[str]:
    out: list[str] = []
    for role, path in BANDED_LISTS:
        try:
            node = cfg.pack(role)
        except Exception:           # missing pack reported by the roles check
            continue
        for key in path:
            node = node.get(key) if isinstance(node, dict) else None
        if not isinstance(node, list):
            continue
        n = sum(1 for b in node if isinstance(b, dict) and b.get("when") == "fallthrough")
        if n != 1:
            out.append(f"{role}.{'.'.join(path)} needs exactly one 'when: fallthrough' "
                       f"catch-all band, found {n}")
        out += _band_coverage_problems(f"{role}.{'.'.join(path)}", node)
    return out


def _band_coverage_problems(where, node) -> list[str]:
    """Gaps and overlaps between numeric bands — the two ways a legal band list is clinically wrong.

    The fallthrough check above asks whether UNMATCHED input has a defined answer. It cannot see the
    two failures that matter more, because both produce a perfectly legal list:

      GAP       `18-64` then `70-79` leaves 65-69 matching nothing, so every 65-to-69-year-old
                lands in the catch-all and is reported as Unknown. The counts still add up. The
                distribution still looks plausible. An entire age group is silently mislabelled.
      OVERLAP   `18-64` alongside `60-74` means a 62-year-old matches both, and the compiled CASE
                takes the FIRST matching WHEN — so the answer depends on the order the bands happen
                to sit in the YAML, which nobody reviews as semantics.

    Both were silent: an adversarial config planted each and `_bands_problems` returned nothing.

    ONLY CLOSED INTEGER BANDS ARE CHAINED. A band needs both `min` and `max`, both integers, to
    take part: `75+` (min only) legitimately ends the chain, and BMI bands are written `min: 18.5,
    max: 24.9` where the arithmetic gap to 25.0 is conventional rather than a defect. Bands this
    cannot read are COUNTED AND REPORTED rather than passed over, because "no gap found" over a
    list this only half understood is the absence-reads-as-clean failure again.
    """
    bands = [b for b in node if isinstance(b, dict) and b.get("when") != "fallthrough"]
    closed, unread = [], 0
    for b in bands:
        lo, hi = b.get("min"), b.get("max")
        if isinstance(lo, int) and isinstance(hi, int) and not isinstance(lo, bool):
            closed.append((lo, hi, str(b.get("label") or b.get("code") or "?")))
        else:
            unread += 1
    out = []
    closed.sort()
    for (lo, hi, lab), (lo2, hi2, lab2) in zip(closed, closed[1:]):
        if hi >= lo2:
            out.append(f"{where}: bands '{lab}' [{lo}-{hi}] and '{lab2}' [{lo2}-{hi2}] OVERLAP — a "
                       f"value in [{lo2}-{min(hi, hi2)}] matches both, and the compiled CASE takes "
                       f"whichever is written first, so the answer depends on YAML order")
        elif hi + 1 < lo2:
            out.append(f"{where}: GAP between '{lab}' [{lo}-{hi}] and '{lab2}' [{lo2}-{hi2}] — "
                       f"[{hi + 1}-{lo2 - 1}] matches no band and falls to the catch-all, so that "
                       f"whole range is reported as the fallthrough value, not as its own group")
    # Reported only when something was actually checked; a list of purely open-ended bands is not a
    # finding, it is a list this check has nothing to say about.
    if out and unread:
        out.append(f"{where}: {unread} band(s) are not closed integer ranges and were NOT checked "
                   f"for gaps or overlaps — this report is partial")
    return out


def _codelist_problems(cfg) -> list[str]:
    out: list[str] = []
    try:
        cl = cfg.codelist("treatment_categories")
    except Exception as e:  # noqa: BLE001
        return [f"failed to load treatment_categories codelist: {e}"]

    cats = cl.get("categories") or []
    if not cats:
        return ["treatment_categories has no categories"]

    codes = []
    catchalls = []
    for i, c in enumerate(cats):
        for f in ("code", "label", "match"):
            if f not in c:
                out.append(f"treatment category #{i} missing '{f}'")
        codes.append(c.get("code"))
        if c.get("match") == {"always": True}:
            catchalls.append(i)
    dup = {x for x in codes if codes.count(x) > 1}
    if dup:
        out.append(f"treatment category codes not unique: {sorted(dup)}")
    if len(catchalls) != 1:
        out.append(f"treatment_categories needs exactly one always-true catch-all, found {len(catchalls)}")
    elif catchalls[0] != len(cats) - 1:
        out.append("the always-true catch-all must be the LAST category (case_when order)")

    out += _operator_vocabulary_problems(cfg, cl)

    try:
        compile_case(cl)   # exercises the match DSL compiler on every entry
    except Exception as e:  # noqa: BLE001
        out.append(f"treatment_categories failed to compile: {e}")
    return out


# Which match operators read the NAME column, and which read a CODE column. Split here rather than
# inside the compiler because this is a question about the DSL's surface, not about its SQL.
NAME_OPERATORS = ("equals", "like_any", "regexp", "is_null")
CATEGORY_OPERATORS = ("category_equals",)


def _operator_vocabulary_problems(cfg, cl) -> list[str]:
    """Refuse a name-based operator against a column the pack DECLARED as coded.

    This is the whole reason the declaration exists. `like_any: ["%bevacizumab%"]` against an NDC
    column is valid SQL over a real column that matches nothing: every line falls to the catch-all
    category, the build succeeds, and the numbers are wrong with no error anywhere. Nothing else in
    the framework can see it — a preflight column check passes (the column exists), the compiler
    passes (the operator is real), and a golden built from the same wrong config agrees with itself.

    ONLY fires on a positive contradiction. An undeclared column yields None from `system_for` and
    is left alone: this must not become a rule that every pack has to satisfy before it can run.
    """
    mo = cl.get("match_on") or {}
    name_col = mo.get("name_column", "linename")
    cat_col = mo.get("drug_category_column", "detaileddrugcategory")
    # Where those columns live. Defaults are what the treatment stage actually reads — linename off
    # `lot`, the drug category off `drug_episode` — and are overridable for a feed that differs.
    name_src = mo.get("source", "lot")
    cat_src = mo.get("category_source", "drug_episode")

    out: list[str] = []
    checked = ((name_col, name_src, NAME_OPERATORS, "name"),
               (cat_col, cat_src, CATEGORY_OPERATORS, "drug-category"))

    def _ops(match, found):
        if not isinstance(match, dict):
            return
        for op, val in match.items():
            if op in ("all_of", "any_of"):
                for sub in (val or []):
                    _ops(sub, found)
            else:
                found.add(op)

    used = set()
    for c in cats_of(cl):
        _ops(c.get("match"), used)

    for column, source, operators, what in checked:
        system = cfg.system_for(source, column)
        if system is None or not vocabularies.is_coded(system):
            continue
        hit = sorted(used & set(operators))
        if hit:
            out.append(
                f"treatment_categories matches the {what} column {source}.{column} with "
                f"{hit} — but this pack declares it as {system}, a coding system. A LIKE or "
                f"equality against a code column matches nothing and sends every line to the "
                f"catch-all category without an error. Use code_in / code_prefix_any, or correct "
                f"the vocabularies declaration if the column really carries text.")
    return out


def cats_of(cl) -> list:
    """The codelist's categories, defensively — callers here run before the shape checks pass."""
    return [c for c in (cl.get("categories") or []) if isinstance(c, dict)]


def check(cfg, strict: bool = True) -> None:
    """Raise RuntimeError listing all problems, or return None if the config is clean."""
    probs = problems(cfg, strict=strict)
    if probs:
        raise RuntimeError("config validation failed:\n  - " + "\n  - ".join(probs))


def required_columns(cfg) -> dict:
    """Per-source required columns for the sources this tumor DECLARES.

    Includes the index-date `of` columns on the CONFIGURED index source (not always `enhanced`),
    and the date columns of any custom follow-up sources (dict-form follow_up_sources), so preflight
    catches a missing column on the right table.
    """
    req = {k: list(v) for k, v in REQUIRED_COLUMNS.items() if k in cfg.sources}

    # A product "uses a line-setting model" if the GLOBAL lot.line_setting is set OR ANY cohort declares
    # its own line_setting — because the treatment/index stages resolve `cohort.line_setting` first and
    # only fall back to the global. So both `lot.linesetting` and the drug_episode aggregation below must
    # gate on this combined condition, not the global alone (else a cohort-setting product with no global
    # would pass preflight while the runtime filters on a `linesetting` column that isn't required).
    uses_line_setting = bool(cfg.lot_line_setting or
                             any(c.get("line_setting") is not None for c in cfg.cohorts))
    # `lot.linesetting` is only read when a line setting is configured (e.g. prostate mCRPC). COTA/heme
    # tumors (DLBCL/CLL/MDS) have no such column and no line setting -> don't require it.
    if "lot" in req and not uses_line_setting and "linesetting" in req["lot"]:
        req["lot"].remove("linesetting")
    # If any cohort filters on the maintenance flag (OC/EC), the LOT table must carry that column.
    if "lot" in req and any(c.get("maintenance") is not None for c in cfg.cohorts):
        mc = cfg.lot_maintenance_column
        if mc and mc not in req["lot"]:
            req["lot"].append(mc)

    def _need(source, cols):
        if source not in cfg.sources:
            return
        req.setdefault(source, ["patientid"])
        for c in cols:
            if c and c not in req[source]:
                req[source].append(c)

    # index date is built on cfg.index_source from EACH index_dates model's `of` columns — require ALL
    # of them (not just advanced_diagnosis_date) so a column a cohort indexes off (e.g. the mHSPC
    # cohort's hspc_diagnosis_date -> hspcdate) that is missing/typoed fails preflight, instead of
    # sources.load silently materializing the model from whatever `of` columns happen to be present.
    for _rule in (cfg.index_dates or {}).values():
        if isinstance(_rule, dict):
            _need(_rule.get("source", cfg.index_source), ["patientid"] + list(_rule.get("of", [])))

    # custom follow-up sources (dict form) declare their own date column AND any columns their
    # filter SQL references (filter_columns) -> require all of them, so a filter can't reference a
    # column that passes preflight then fails at runtime in F.expr().
    try:
        fus = cfg.pack("clinical").get("death_date_imputation", {}).get("follow_up_sources")
        if fus and isinstance(fus[0], dict):
            for s in fus:
                # a named filter_method contributes the columns its predicate references (from the
                # registry); a raw filter still declares them via filter_columns.
                fm = s.get("filter_method")
                fcols = list(FOLLOWUP_FILTERS.get(fm, ("", []))[1]) if fm else list(s.get("filter_columns") or [])
                _need(s.get("source"), [s.get("date_column")] + fcols)
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # clinical sub-blocks dereference specific source columns — require them so a typo'd/absent
    # column fails preflight up front, not deep inside a Spark stage (categoricals would otherwise
    # silently skip; biomarker/lab panels would fail at runtime).
    try:
        cp = cfg.pack("clinical")
        st = cp.get("staging")        # `stage` is grouped from `groupstage`; require it so a source
        if st and st.get("groups"):   # lacking groupstage fails preflight instead of dropping `stage`.
            _need(st.get("source", cfg.index_source), ["groupstage"])
        for cat in cp.get("categoricals") or []:
            _need(cat.get("source", cfg.index_source), [cat.get("column"), cat.get("date_column")])
        cci = cp.get("comorbidity_index")     # code + date, so a typo fails preflight not Spark
        if cci and cci.get("conditions"):
            _need(cci.get("source"), [cci.get("code_column"), cci.get("date_column")])
        for blk_key in CLOSEST_PANELS + ("lab_values",):   # all closest-to-index panels (name/value/date)
            blk = cp.get(blk_key)
            if blk:
                # unit_column is only dereferenced when an item declares `units` to filter on.
                unit_col = blk.get("unit_column") if any(
                    it.get("units") for it in (blk.get("panel") or [])) else None
                # `date_basis.columns` too. `_record_date_expr` hard-dereferences them to build the
                # `later_of`/`earlier_of` record date, so a typo there is a runtime AnalysisException
                # from a column preflight said nothing about — the one thing preflight exists to
                # prevent. They are required, not optional; a block with no `date_basis` contributes
                # an empty list and is unaffected.
                basis = blk.get("date_basis")
                dcols = list(basis.get("columns") or []) if isinstance(basis, dict) else []
                _need(blk.get("source"), [blk.get("name_column"), blk.get("value_column"),
                                          blk.get("date_column"), unit_col] + dcols)
        ms = cp.get("metastatic_sites")     # per-site flags from a SiteOfMetastasis/DateOfMetastasis table
        if ms:
            _need(ms.get("source"), [ms.get("site_column"), ms.get("date_column")])
        psa = cp.get("psa_timepoints")      # windowed PSA values from a value/date table
        if psa:
            _need(psa.get("source"), [psa.get("value_column"), psa.get("date_column")])
        if cp.get("vitals") and "vitals" in cfg.sources:   # BMI/BSA reads test/units/result/dates
            _need("vitals", ["test", "testunitscleaned", "testresultcleaned", "testdate", "resultdate"])
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # demographics.practice_map reads `practicetype` from the practice source; demographics.ses reads its
    # source_column from the ses source — both source-gated (the stage uses src.get / "in src").
    try:
        dem = cfg.pack("demographics")
        if dem.get("practice_map") and "practice" in cfg.sources:
            _need("practice", ["practicetype"])
        ses = dem.get("ses") or {}
        if ses.get("source_column") and "ses" in cfg.sources:
            _need("ses", [ses["source_column"]])
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # outcomes.line_outcomes (vis120) reads a date column from each DECLARED visit source. Visit
    # sources are OPTIONAL (vis120 degrades to 0 when absent), so _need skips undeclared ones —
    # but a declared visit source must expose the configured date column.
    try:
        lo = cfg.pack("outcomes").get("line_outcomes")
        if lo:
            vdate = lo.get("visit_date_column", "visitdate")
            for s in (lo.get("visit_sources") or []):
                _need(s, [vdate])
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # treatment.prior_taxane.pre_mcrpc_source (when set + declared) is read for linename/startdate.
    try:
        pt = cfg.pack("treatment").get("prior_taxane") or {}
        _need(pt.get("pre_mcrpc_source"), ["linename", "startdate"])
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # treatment.conmed_exposures: when flags are configured the conmed_* outputs ARE expected, so the name
    # column is REQUIRED — its absence would silently DROP every configured conmed output (the stage skips
    # the whole block). The date column is CONDITIONALLY required: only when a window boundary is set. A set
    # window that can't read the date silently evaluates exposure over ALL time (wrong Yes/No), not just a
    # dropped column — so require it there; a [null,null] any-time window doesn't read the date (optional).
    try:
        ce = cfg.pack("treatment").get("conmed_exposures") or {}
        if ce.get("flags"):
            need = [ce.get("name_column")]
            lo, hi = (ce.get("window_days") or [None, None])
            if lo is not None or hi is not None:
                need.append(ce.get("date_column"))
            _need(ce.get("source"), need)
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # drug_episode powers lot{i}ed (each line's last-activity date). The treatment stage falls back to
    # the line enddate when its columns are absent — harmless UNLESS the line outcomes consume lot{i}ed
    # (vis120/TTD/TTNT), where a silent fallback would shift results. So require its key columns only
    # when drug_episode is declared AND outcomes.line_outcomes is enabled (catches the prostate case
    # without forcing the columns on COTA/other tumors that declare drug_episode but don't use it).
    # `linesetting` too when a setting model is used, since the aggregate that feeds lot{i}ed is filtered
    # to the cohort's setting (without the column it would silently combine episode dates across settings).
    try:
        if "drug_episode" in cfg.sources and cfg.pack("outcomes").get("line_outcomes"):
            _need("drug_episode", ["linenumber", "episodedate"] +
                  (["linesetting"] if uses_line_setting else []))
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # The per-line category classifier (lotcatn) detects "Other chemotherapy-containing" via the
    # codelist's category_equals, which reads the drug-category column. That column lives on drug_episode
    # in the delivered data (the treatment stage filters drug_episode to the cohort's setting, then
    # aggregates a per-line chemo indicator by patient+linenumber). So require it — plus linesetting to
    # scope the filter (only when a setting model is used), and episodedate because the runtime only
    # BUILDS that per-line aggregate when episodedate is present
    # (without it the category would silently fall to NULL) — only when drug_episode is declared AND the
    # treatment codelist actually uses category_equals (so a tumor whose classifier never references the
    # drug category isn't forced to carry it).
    def _uses_category_equals(m):
        if not isinstance(m, dict):
            return False
        if "category_equals" in m:
            return True
        return any(_uses_category_equals(sub) for k in ("all_of", "any_of") for sub in (m.get(k) or []))

    try:
        if "drug_episode" in cfg.sources:
            cl = cfg.codelist("treatment_categories") or {}
            if any(_uses_category_equals(c.get("match")) for c in cl.get("categories", [])):
                cat_col = (cl.get("match_on") or {}).get("drug_category_column", "detaileddrugcategory")
                need = ["linenumber", "episodedate", cat_col]
                # linesetting is only read when a line-setting model is configured (the treatment stage
                # filters drug_episode to the cohort's setting). Products with no line setting (heme/COTA)
                # aggregate on patient+linenumber and must NOT be forced to carry linesetting — use the
                # combined global-or-cohort gate (the same one lot.linesetting uses above).
                if uses_line_setting:
                    need.append("linesetting")
                _need("drug_episode", need)
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # outcomes.progression (PFS) reads the progression date, the evidence flags, and the
    # pseudo-progression column from its declared source.
    try:
        pcfg = cfg.pack("outcomes").get("progression")
        if pcfg:
            _need(pcfg.get("source"), [pcfg.get("date_column"), pcfg.get("pseudoprogression_column")]
                  + list(pcfg.get("evidence_columns") or []))
            cc = pcfg.get("censor")          # rwPFS censor (LASTCLINICNOTEDATE) source/date column
            if cc:
                _need(cc.get("source"), [cc.get("date_column")])
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # outcomes.platinum_sensitivity reads the line number / name / start / end from its source (lot).
    try:
        psc = cfg.pack("outcomes").get("platinum_sensitivity")
        if psc:
            _need(psc.get("source"), [psc.get("line_number_column"), psc.get("name_column"),
                                      psc.get("start_column"), psc.get("end_column")])
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # clinical.surgery reads the surgery flag/date from its source + the 1L line start/end.
    try:
        scfg = cfg.pack("clinical").get("surgery")
        if scfg:
            _need(scfg.get("source"), [scfg.get("surgery_flag_column"), scfg.get("surgery_date_column")])
            _need(scfg.get("line_source", "lot"), [scfg.get("line_number_column", "linenumber"),
                  scfg.get("line_start_column"), scfg.get("line_end_column")])
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # clinical.min_avail_date: the runtime consumes EVERY configured base column and date column that
    # exists (least-of-present), so require them all on their declared sources -> a typo fails preflight
    # instead of silently shifting the floor. _need skips undeclared sources, so a refresh legitimately
    # missing one stays graceful (configs list only real columns, so no `optional` metadata is needed).
    try:
        mblk = cfg.pack("clinical").get("min_avail_date") or {}
        _need(cfg.index_source, list(mblk.get("base_columns") or []))
        for s in (mblk.get("sources") or []):
            _need(s.get("source"), list(s.get("date_columns") or [s.get("date_column")]))
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # clinical.passthrough: every aliased column and every flag's source column is dereferenced, so a
    # typo would otherwise be silently skipped -> require them all on the pass-through source. EXCEPT
    # columns/flags marked `optional: true` (genuinely feed-dependent, e.g. PSA-at-diagnosis): the engine
    # already skips those gracefully when absent, so preflight must not hard-require them (it would
    # contradict the graceful contract and fail a legitimate cut that simply lacks the column).
    try:
        pblk = cfg.pack("clinical").get("passthrough") or {}
        cols = [c.get("column") for c in (pblk.get("columns") or []) if not c.get("optional")]
        cols += [f.get("from") for f in (pblk.get("flags") or []) if not f.get("optional")]
        _need(pblk.get("source") or cfg.index_source, cols)
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass
    return req


def emitted_variables(cfg) -> set:
    """The label-level variable codes a tumor's packs emit (excluding the parallel -n code columns,
    which the catalog documents via their label, like stage/stagen). Covers demographics / ECOG / BMI /
    staging / categoricals / biomarker+lab panels / passthrough / surgery / min_avail / cohort
    provenance / outcomes `emits`. Used to assert the master catalog documents every emitted variable
    per tumor (cross-tumor completeness — tests/test_catalog.py)."""
    # always emitted: cohort/cohortu/stamps by assemble, advanceddiagnosisdate (setting diagnosis anchor)
    # by the index stage. Enumerating it here makes the catalog-completeness test cover it too.
    em: set = {"cohort", "cohortu", "data_product_id", "data_refresh", "spec_version", "advanceddiagnosisdate"}
    try:
        dem = cfg.pack("demographics")
        for block, name in (("age_bands", "agegrl"), ("regions", "regionl"), ("race_map", "race"),
                            ("ethnicity_map", "eth")):
            if dem.get(block):
                em.add(name)
        if dem.get("age_bands"):
            em.add("age")
        # SOURCE-aware: practic/ses are emitted only when their (optional) source is declared — so the
        # guard matches what the stage actually emits, not what a pack block merely mentions (e.g. a
        # heme scaffold may carry a ses block but no ses source).
        if dem.get("practice_map") and "practice" in cfg.sources:
            em.add("practic")
        if dem.get("ses") and "ses" in cfg.sources:
            em.add("ses")
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass
    try:
        clin = cfg.pack("clinical")
        em.add("ecog")                                  # always emitted (baseline_ecog or Missing)
        if clin.get("vitals") and "vitals" in cfg.sources:
            em.add("bmi")
            if clin["vitals"].get("bsa_method") or clin["vitals"].get("bsa_formula"):  # method (new) or legacy
                em.add("bsa")
        if clin.get("staging"):
            em.add("stage")
        for c in clin.get("categoricals") or []:
            em.add(c.get("name"))
        for blk in CLOSEST_PANELS:
            _b = clin.get(blk) or {}
            for it in _b.get("panel") or []:
                em.add(it.get("name"))
                # `emit_date` adds the winning record's date as <name>dt. Registered here or the
                # published-surface check reports a column the engine really does produce as a leak.
                if _b.get("emit_date"):
                    em.add(str(it.get("name")) + "dt")
        cci = clin.get("comorbidity_index") or {}
        if cci.get("name") and cci.get("conditions"):
            em.add(cci["name"])
            if cci.get("bands"):
                em.update({cci["name"] + "gr", cci["name"] + "grn"})
        pt = clin.get("passthrough") or {}
        for c in pt.get("columns") or []:
            em.add(c.get("as", c.get("column")))
        for f in pt.get("flags") or []:
            em.add(f.get("name"))
        s = clin.get("surgery")
        if s:
            em |= {"issurg", "surg", "neoadj", "tt_first_tx_diag"}
            if s.get("size_column"):
                em.add(s["size_column"])
        for it in (clin.get("metastatic_sites") or {}).get("sites") or []:
            em.add(it.get("name"))                          # hepatic_met / lung_met / … presence flags
        for it in (clin.get("lab_values") or {}).get("panel") or []:
            nm = it.get("name")
            if nm:
                em |= {nm, nm + "v", nm + "dt"}             # present flag + numeric value + date (all cataloged)
        psa = clin.get("psa_timepoints") or {}
        for p in psa.get("points") or []:
            em.add(p.get("name"))                           # psa_index / psa6mo / psa12mo
        for pt in (psa.get("response") or {}).get("points") or []:
            em.add(pt.get("psa50")); em.add(pt.get("undetectable"))   # psa50_6mo / psal6mo / …
        for it in (clin.get("durations") or {}).get("items") or []:
            em.add(it.get("name"))                          # generic durations (if a tumor configures them)
        for it in clin.get("derived") or []:
            em.add(it.get("name"))                          # INDEXYR / INITYR / MCRPCDDYR / PINDDUR / FUDUR / …
        mcw = clin.get("mcrpc_window")                      # mCRPC index-window flag + MCRPCDD date
        if mcw:
            em.add(mcw.get("flag_as", "mcrpc")); em.add(mcw.get("date_as", "mcrpcdd"))
        if clin.get("min_avail_date"):
            em |= {"minavaildate", "basedur"}
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass
    try:
        trt = cfg.pack("treatment")
        from .stages import treatment as _t                 # per-line lot{i}* family (template-documented)
        em |= set(_t.emitted_line_columns(cfg))
        for fl in (trt.get("prior_treatments") or {}).get("flags") or []:
            em.add(fl.get("name"))                          # prior_pluvicto / prior_parp / …
        for fl in (trt.get("conmed_exposures") or {}).get("flags") or []:
            em.add(fl.get("name"))                          # conmed_bp / conmed_csf / conmed_steroid
        pt = trt.get("prior_taxane") or {}                  # cohort-aware prior-taxane flags
        if pt:
            em.add("prior_tax_mcrpc")                       # always emitted when prior_taxane is configured
            if pt.get("pre_mcrpc_source") in cfg.sources:   # optional: only when pre-mCRPC source declared
                em.add("prior_tax_pre_mcrpc")
        slc = trt.get("setting_line_columns") or {}         # lot{i}{sd|name}_{setting} per setting
        for s in slc.get("settings") or []:
            for i in range(1, int(slc.get("lines", 2)) + 1):
                for a in slc.get("attributes", ["sd", "name"]):
                    em.add(f"lot{i}{a}_{str(s).lower()}")
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass
    try:
        out_pack = cfg.pack("outcomes")
        em |= set(out_pack.get("emits") or [])
        # cross-stage derivations (EFS24-style landmarks / intervals / expressions)
        em |= ads_derived_emitted(out_pack.get("ads_derived"))
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass
    em.discard(None)
    return em


def optional_columns(cfg) -> dict:
    """Configured columns the build reads OPTIONALLY (emit-if-present): the engine skips the dependent
    output gracefully when they are absent, so they are NOT in required_columns() and never fail preflight.
    Reported (present/absent) so a schema-evidence run shows EVERY configured column, not only the
    hard-required ones — an absent optional column is ALLOWED (the output just isn't emitted for this cut),
    but silently omitting it from the evidence would hide, e.g., a missing `drugname` that drops the whole
    conmed block. Returns {source: [col, ...]}.
    """
    opt: dict = {}

    def _add(source, cols):
        if not source or source not in cfg.sources:
            return
        for c in cols:
            if c and c not in opt.setdefault(source, []):
                opt[source].append(c)

    try:    # clinical.passthrough optional:true columns/flags (e.g. PSA-at-diagnosis passthroughs)
        pblk = cfg.pack("clinical").get("passthrough") or {}
        src = pblk.get("source") or cfg.index_source
        _add(src, [c.get("column") for c in (pblk.get("columns") or []) if c.get("optional")])
        _add(src, [f.get("from") for f in (pblk.get("flags") or []) if f.get("optional")])
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass
    try:    # treatment.conmed_exposures.date_column is optional ONLY under an any-time [null,null] window;
            # the name column (and the date column under a real window) are REQUIRED — see required_columns.
        ce = cfg.pack("treatment").get("conmed_exposures") or {}
        if ce.get("flags"):
            lo, hi = (ce.get("window_days") or [None, None])
            if lo is None and hi is None:
                _add(ce.get("source"), [ce.get("date_column")])
    except Exception:  # noqa: BLE001
        pass
    try:    # clinical.surgery optional init/size columns (emit tt_first_tx_diag / residual size when present)
        scfg = cfg.pack("clinical").get("surgery") or {}
        _add(scfg.get("source"), [scfg.get("init_date_column"), scfg.get("size_column")])
    except Exception:  # noqa: BLE001
        pass
    return opt


def preflight_report(cfg, table_reader, member_schema=None) -> dict:
    """Structured table/column validation — the READABLE form of preflight(). For every DECLARED source it
    resolves the table FQN(s) and records, per column, whether it is present in the delivered schema
    (honouring the vendor rename overlay). Config-driven: tables come from `sources:`, REQUIRED columns from
    required_columns(cfg), OPTIONAL configured columns from optional_columns(cfg).

    This is a BUILD-PREFLIGHT check: `ok` gates only on readability + REQUIRED columns (exactly what the
    build needs to run). It does NOT prove data types are correct, values match the expected vocabulary,
    grain/joins/windows hold, or that a column is the clinically intended source — those need the value
    profiler + targeted checks + RWP review before a source is 'verified'.

    `member_schema` scopes the report to ONE source_union member. Without it, `source_fqns()` returns
    every declared member's table, so a report LABELLED as member A's evidence actually inspected A and
    B: both members' reports covered the same tables, one member's restricted output carried the
    other's physical identifiers, and A's evidence could fail because B was unavailable. Pass it for a
    member run; omit it for a single-schema pack or a deliberate whole-union preflight.

    `table_reader(fqn)` returns either a list of column names OR a {name: type} dict (pass the latter —
    `{f.name: f.dataType.simpleString() for f in spark.table(fqn).schema.fields}` — to capture observed
    types); it raises if the table is unreadable. Pure data (no Spark import here). Returns:
      {"ok": bool, "sources": {name: {"ok": bool, "tables": [{fqn, readable, present:{col:bool},
       missing:[...], optional_present:{col:bool}, types:{col:type}}]}}}
    """
    req = required_columns(cfg)
    opt = optional_columns(cfg)
    sources: dict = {}
    ok = True
    for name in sorted(cfg.sources):
        # Under a non-EDM data format, columns arrive with PHYSICAL names that source load renames to the
        # required LOGICAL names — so a required logical column is satisfied by its physical name too.
        phys_for = {lo.lower(): ph.lower() for ph, lo in (cfg.source_renames.get(name) or {}).items()}
        need = req.get(name, ["patientid"])
        opt_need = opt.get(name, [])
        tables, src_ok = [], True
        fqns = [cfg.table_in(name, member_schema)] if member_schema else cfg.source_fqns(name)
        for fqn in fqns:                         # 1 normally; one per member schema under a union
            t = {"fqn": fqn, "readable": True, "present": {}, "missing": [],
                 "optional_present": {}, "types": {}}
            try:
                raw = table_reader(fqn)
            except Exception as e:  # noqa: BLE001 - any read failure is a preflight problem
                t["readable"] = False
                t["error"] = str(e)
                src_ok = False
                tables.append(t)
                continue
            if isinstance(raw, dict):            # {name: type} -> capture observed types (keyed lowercase)
                t["types"] = {str(c).lower(): str(ty) for c, ty in raw.items()}
                cols = set(t["types"])
            else:
                cols = {str(c).lower() for c in raw}

            def _has(col):
                cl = col.lower()
                return cl in cols or phys_for.get(cl) in cols

            for c in need:                       # required: a miss fails the source (build can't run)
                present = _has(c)
                t["present"][c] = present
                if not present:
                    t["missing"].append(c)
                    src_ok = False
            for c in opt_need:                   # optional: recorded present/absent, never fails
                t["optional_present"][c] = _has(c)
            tables.append(t)
        sources[name] = {"ok": src_ok, "tables": tables}
        ok = ok and src_ok
    return {"ok": ok, "sources": sources}


def preflight_report_md(report: dict) -> str:
    """Render preflight_report() as a stakeholder markdown report: a summary table plus a per-source detail
    listing every column checked (required + optional) with its observed type. Names WHICH columns were
    checked so an auditor doesn't need the source to reconstruct the evidence."""
    head = ("✅ every BUILD-REQUIRED table & column is present in the cut" if report["ok"]
            else "❌ mismatches below — the config's physical names do not all match the delivered cut")
    lines = ["# Schema validation — configured tables & columns vs the delivered cut", "",
             f"**Result:** {head}", "",
             "_Scope: a BUILD-PREFLIGHT check. It confirms the tables read and the columns the build "
             "REQUIRES exist (and records optional configured columns + observed types). It does NOT "
             "establish data types are correct, value vocabularies, grain / joins / duplicates / windows, "
             "or that a column is the clinically intended source — those need the value profiler + targeted "
             "checks + RWP review before a source is marked `verified`._", "",
             "| Source | Table (FQN) | Readable | Required present | Missing | Optional present |",
             "|---|---|---|---|---|---|"]
    for name, s in report["sources"].items():
        for t in s["tables"]:
            readable = "✅" if t["readable"] else f"❌ {t.get('error', '')}"
            n = len(t["present"])
            npresent = sum(1 for v in t["present"].values() if v)
            missing = ", ".join(f"`{c}`" for c in t["missing"]) if t["missing"] else "—"
            opt = t.get("optional_present") or {}
            optstr = ", ".join(f"`{c}`{'✅' if v else '➖'}" for c, v in opt.items()) if opt else "—"
            lines.append(f"| {name} | `{t['fqn']}` | {readable} | {npresent}/{n} | {missing} | {optstr} |")

    lines += ["", "## Columns checked (per source)"]
    for name, s in report["sources"].items():
        for t in s["tables"]:
            lines += ["", f"### {name} — `{t['fqn']}`", ""]
            if not t["readable"]:
                lines.append(f"- ❌ unreadable: {t.get('error', '')}")
                continue
            types = t.get("types") or {}

            def _typ(c):
                ty = types.get(c.lower())
                return f" — `{ty}`" if ty else ""

            for c, present in t["present"].items():
                lines.append(f"- {'✅' if present else '❌'} required `{c}`{_typ(c)}")
            for c, present in (t.get("optional_present") or {}).items():
                lines.append(f"- {'✅' if present else '➖ absent (allowed)'} optional `{c}`{_typ(c)}")
    return "\n".join(lines) + "\n"


def preflight_evidence(cfg, report: dict, generated_at=None, git_commit=None) -> dict:
    """Wrap preflight_report() with run provenance into a machine-readable evidence object — the stable
    input for a draft reconciliation/prepopulation step, and an auditable record of exactly what was
    checked. Establishes `schema_presence` (passed_live / failed_live), NOT `source: verified` — a green
    presence check is one input to source verification, not the whole evidence package. Pure data; the
    runner supplies generated_at + git_commit (this module imports no clock/git)."""
    return {
        "kind": "schema_preflight",
        "schema_presence": "passed_live" if report["ok"] else "failed_live",
        "data_product_id": cfg.data_product_id,
        "spec_version": cfg.spec_version,
        "data_refresh": cfg.refresh,
        "source_schema": cfg.source_schema,
        "data_format": cfg.data_format,
        "git_commit": git_commit,
        "generated_at": generated_at,
        "ok": report["ok"],
        "sources": report["sources"],
    }


def preflight(spark, cfg, _table_reader=None) -> bool:
    """Spark preflight: every DECLARED source TABLE resolves and has its required COLUMNS. Run on the
    cluster before build() so a missing table/column fails fast with a clear list instead of deep inside a
    Spark stage. Delegates to preflight_report(); raises on any mismatch. `_table_reader(fqn) -> list[col]`
    is injectable for unit tests; by default it reads `spark.table(fqn).columns`."""
    read = _table_reader or (lambda fqn: spark.table(fqn).columns)
    rep = preflight_report(cfg, read)
    if not rep["ok"]:
        problems: list[str] = []
        for name, s in rep["sources"].items():
            for t in s["tables"]:
                if not t["readable"]:
                    problems.append(f"source '{name}' table {t['fqn']} not readable: {t.get('error')}")
                for c in t["missing"]:
                    problems.append(f"source '{name}' table {t['fqn']} missing column '{c}'")
        raise RuntimeError("source preflight failed:\n  - " + "\n  - ".join(problems))
    return True


def main(argv):
    if len(argv) != 2:
        print("usage: python engine/validate.py <path-to-data_product.yaml>")
        return 2
    cfg = load_config(argv[1])
    probs = problems(cfg, strict=False)   # lint mode: REPLACE_ME placeholders allowed
    if probs:
        print(f"{len(probs)} problem(s):")
        for p in probs:
            print(f"  - {p}")
        return 1
    print("config OK (lint mode — REPLACE_ME placeholders allowed)")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
