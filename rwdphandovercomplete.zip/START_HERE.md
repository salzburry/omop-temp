# RWD Data Product — complete handover

Everything needed to test this locally, operate it from chat, and deploy it to Databricks.
Self-contained: no network access is required to read, test or deploy any of it.

Built from commit `3eea38e` on branch `claude/xlsx-second-table-header`.

```
START_HERE.md          this file
repo/                  the full repository — 551 tracked files, complete git history, the chat skills
databricks-deploy/     a pre-built, verified runtime tree for mCRC (67 files)
audit-evidence/        mCRC's governance evidence, kept OUT of the runtime tree on purpose
```

`repo/` is a real git clone, not a file dump. That matters: `repo_hygiene.py` reads the git index
and `deploy_tree.py` reads the checkout's git state, so both are inert against a folder with no
`.git`. Verified inside this copy: `repo hygiene: 551 tracked files, none refused`, working tree
clean, and rebuilding the deployment tree from it reproduces the shipped one byte for byte
(`tree e623f7d45ca9`, `evidence 868c08359e58`).

---

## What this product is, stated honestly

The **framework** is mature and tested: 1,270 tests pass with zero skips, covering six governance
gates, the Spark engine, and every tool. The **prostate** pack is the one worked example — it is on
`--list-buildable` and its walkthrough passes 13 of 13 gate steps.

**mCRC is a scaffold.** No approved RWB workbook is registered for it, so it has no `source_refs.yaml`
and no functional contract, and Gate 1 has not started. Its config is *inferred from published RWD
practice* — that is written at the top of `config/data_product.yaml`, and every value marked
`verify-vs-source` must be confirmed against the approved workbook. `deploy_tree` reports it as
`1 product(s), 0 releasable`.

So an mCRC run answers "does the engine execute against this delivery" — not "are the numbers right".
Nothing has yet checked that configuration against a specification. Registering the workbook (§3) is
what changes that, and it is the single highest-value thing anyone can do with this package.

---

## 1. Local setup and test (VS Code)

```bash
cd repo
python3 -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r platform/requirements.txt
pip install "pyspark>=3.5"                            # only for the Spark stages; Databricks supplies it on-cluster
```

Run the full suite the way CI does:

```bash
cd platform
python3 -m pytest tests/ -q
# expect: 1270 passed
```

That takes about 20 minutes, most of it Spark. For a fast signal, the local end-to-end build of
every configured product — mCRC included — against synthetic sources, no cluster and no data:

```bash
python3 -m pytest tests/test_smoke_spark.py -q
```

Then watch the whole governed lifecycle on the worked example:

```bash
cd repo
python3 platform/tools/demo.py products/oncology/prostate/202606
# expect: 13/13 gate step(s) passed
```

Run it against mCRC too and compare. It passes 6/6 — a smaller set, because most gates correctly
report NO EVIDENCE rather than PASS on a pack that has not yet claimed anything:

```bash
python3 platform/tools/demo.py products/oncology/mcrc/202606
```

## 2. The chat interface

It is not a separate application. It is five skills under `repo/.claude/skills/`, loaded by Claude
Code when the **`repo/` folder** is opened in VS Code with the Claude Code extension.

| skill | ask it |
|---|---|
| `operate-rwd-product` | "where does mcrc stand", "what is blocking us", "what do I run next" |
| `draft-contract-record` | draft, revise or audit Gate 2 records from specification rows |
| `answer-decisions` | "what should we ask RWB" |
| `apply-source-verdicts` | ingest a committed Gate 3 verdict report |
| `next-cut` | a revised workbook has landed; what carries forward |

Test it by opening `repo/` and typing **`where does mcrc stand`**. You should get the Gate 1 blocker:
source unregistered, not approved.

The skills are read-only about judgment. No tool in this repository approves anything, answers a
decision, or promotes a build — those are human acts recorded in the pack's own files, and the tools
refuse to perform them.

## 3. Registering the mCRC specification — the thing that unblocks everything

Do this from `repo/` once the approved workbook is in hand. Full runbook:
`repo/products/oncology/mcrc/202606/prog_spec/README.md`.

```bash
# 1 — register. The three classification values are a PERSON's to type; no tool may supply them.
python3 platform/tools/source_refs_init.py products/oncology/mcrc/202606 \
    --ai-classification <sponsor_ai_eligible|vendor_restricted|restricted_derived> \
    --classified-by "<a named person>" --classified-date <YYYY-MM-DD> \
    --path-or-link "<path to the approved workbook>"

# 2 — bind the registration to the BYTES, not just to a filename
python3 platform/tools/source_manifest.py products/oncology/mcrc/202606 --record-digest program_spec
python3 platform/tools/source_manifest.py products/oncology/mcrc/202606 --check

# 3 — extract (produces the sanitized extraction, the only artifact AI may read)
python3 platform/tools/run_spec_pipeline.py products/oncology/mcrc/202606

# 4 — register the extraction for AI use. PRINTS a block; paste it and sign it.
python3 platform/tools/source_manifest.py --register-ai-extraction products/oncology/mcrc/202606

# 5 — candidate values the spec states, for a person to finish into config
python3 platform/tools/contract_binding.py products/oncology/mcrc/202606 --promote
```

`ai_classification` decides what AI may read at all. It is a human act of authority and must never be
inferred from a filename, a folder or a role line — which is why step 1 has no defaults and step 4
prints rather than writes. Expect the pack to go **RED** the moment step 4's block is pasted: that is
what an unclassified material is, and the fix is the human act, not a default.

Expect real findings from step 3. The extractor reports a requirement sheet that yields zero rows, a
hidden or `veryHidden` tab, and cells whose number format makes Excel display `5%` where the file
stores `0.05` — a hundred-fold gap between what a reviewer approved and what a contract would state.

## 4. Databricks

Two options, and they produce the same bytes.

**Use the pre-built tree** — already validated (`--check-tree`: *no findings — safe to package*):

```bash
cd databricks-deploy
databricks bundle validate -t prod
databricks bundle deploy   -t prod
databricks bundle run rwdp_build_mcrc -t prod \
    --var mcrc_refresh=<cut> \
    --var mcrc_source_schema=<catalog.schema with the source tables> \
    --var mcrc_output_schema=<catalog.schema for the ADS> \
    --var mcrc_artifact_root=/Volumes/<volume>/rwdp/artifacts \
    --var git_commit=3eea38e05db8 \
    --var release_evidence_sha256=868c08359e5851d82d171af812c2deaa8a80bb4007868522a0689211f6383b76
```

**Or rebuild it** from a clean checkout, which is the documented sequence and gives the same digests:

```bash
cd repo
python3 platform/tools/bundle_products.py                 # after any registry change
python3 platform/tools/deploy_tree.py --out ../build/deploy --evidence-out ../build/audit-evidence
python3 platform/tools/deploy_tree.py --check-tree ../build/deploy
```

Three things that are easy to get wrong:

- **Deploy from the tree, never from the checkout.** `databricks bundle deploy` in `repo/` syncs the
  repository root minus three globs, pushing specification stand-ins and reference material into the
  workspace. The tree is an allowlist instead.
- **Run `rwdp_build_mcrc`, not `rwdp_publish_mcrc`.** The publish job sets `require_published=true`,
  which turns every legitimate stop-short into a job failure.
- **`env=prod` hard-fails a placeholder `artifact_root`.** Supply a real volume.

`pipeline.yaml` ships `refresh`, `source_schema` and `output_schema` as `REPLACE_ME`. Do not edit
them — they sit outside `config_bundle_sha256` deliberately, so that changing *where* a product runs
cannot invalidate an approval of *what it means*. Pass them per run, as above.

Pre-flight your schema names locally first, without a cluster. `validate.py <config>` reaches only
lint mode, which passes with `REPLACE_ME` in place; this reaches the strict check:

```bash
cd repo
python3 - <<'PY'
import sys; sys.path.insert(0, "platform")
from engine.config import load_config
from engine.validate import problems
probs = problems(load_config("products/oncology/mcrc/202606/config/data_product.yaml", {
    "run.refresh": "202606", "run.source_schema": "cat.schema", "run.output_schema": "cat.out",
}), strict=True)
print(f"{len(probs)} problem(s)"); [print("  -", p) for p in probs]
PY
```

The ADS lands at `<output_schema>.rwdp_mcrc_pano_202606`. The run reads 14 tables from
`<source_schema>`: `t_enh_advcrc`, `t_lineoftherapy`, `t_diagnosis`, `t_demographics`,
`t_socdetofhealth`, `t_practice`, `t_visit`, `t_telemedicine`, `t_drugepisode`,
`t_enh_mortality_v2`, `t_enh_advcrc_orals`, `t_baseline_ecog`, `t_ecog`, `t_vitals`. A missing one
fails the run rather than quietly shrinking the cohort.

## 5. Reading the result

Under `<artifact_root>/mcrc/<refresh>/`, the build manifest carries the composite candidate verdict
across source QC, ADS QC, the output contract, the golden comparison and the patient differential —
each recorded as **evaluated or not evaluated**, so a check that did not run can never read as a pass.

Expect the run to **stage a candidate and stop**, and expect golden and differential to come back
*not evaluated*: mCRC's golden matrix (`platform/tests/fixtures/mcrc_goldens.yaml`) holds ten
hand-shaped patients whose every `expect:` is still `REPLACE_ME`, awaiting RWP/RWB, and there is no
reference ADS to diff against. Both are correct for a scaffold pack.

---

## Where to read further, in this order

| document | what it is |
|---|---|
| `repo/HANDOVER.md` | the goal, the grounded status of every layer, the roadmap |
| `repo/governance/WORKFLOW.md` | the six gates in full, and the eligibility rule |
| `repo/docs/ENGINEERING.md` | the rules that are expensive to get wrong |
| `repo/docs/CHAT_JOURNEY.md` | operating the repository from chat |
| `repo/DEMO.md` | the walkthrough `demo.py` performs |
| `repo/GLOSSARY.md` | RWB / RWP / RWDE / ADS / LOT and the rest |

## Known open items, so nobody rediscovers them

- **Human-only, and no tool here may do them:** register the mCRC workbook (§3); fill the ten golden
  `expect:` values; restore GitHub Actions billing and re-run CI at this SHA; protect `main` with
  required checks; independent RWB/RWP/RWDE review of the inferred mCRC configuration.
- **Open engineering question (Q1):** C1/A7 regimen membership, both directions.
- `validate.py --help` crashes — it treats `--help` as a config path — and its strict mode has no CLI
  route, which is why §4's pre-flight is a heredoc rather than a flag.
- There is no `CLAUDE.md`, so Claude Code starts colder in VS Code than it needs to.
