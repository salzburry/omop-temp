# =============================================================================
# PREFLIGHT IN R - SOURCE GATES, RUN IN DATABRICKS BEFORE EVERY BUILD
# =============================================================================
#   Rscript validation/01_preflight.R             (before a build, repo root)
#
# The build only creates. These checks used to run inside
# code/modules/00_setup.R; they are still mandatory preconditions (Q78) - a
# failure here means DO NOT BUILD. Section B of
# validation/01_preflight_databricks.sql is the canonical, reviewed statement
# of the same gates.
#
# Each gate guards a silent corruption. A duplicate row fans out the clinical
# block. A non-deterministic NEW_LOT_N moves cohort membership, index dates,
# ECOG matching and TTNT between runs of the same code (Q24). Neither shows in
# the finished table, so the answer has to come before the build.
#
# Every check runs inside Databricks and lands as a table in the personal
# schema. The only fetches are the per-table column listings for the input
# contract and the one-row verdict at the end.
#
#   qcr_contract_r      one row per source table - required columns present?
#   qcr_preflight_r     the twelve B-gates plus C10. Every failed count must
#                       be 0.
#   qcr_c10_labs_r      the expected lab analyte/unit combinations and the
#                       rows found for each (Q25). C10 fails on any zero.
#   qcr_hrr_excluded_r  HRR panel drift, both directions (Q44): a gene in
#                       the table but off the active panel classifies as
#                       not-HRR; a panel gene absent from the cut narrows
#                       the case definition. A reading, not a gate. Under
#                       flatiron_all, empty means no drift; under a smaller
#                       panel the deliberately omitted genes also appear as
#                       EXCLUDED - expected, not drift.
#
# Exit 0 = clear to build. Exit 1 = the contract or a gate failed. Exit 2 =
# results written but the verdict could not be fetched; read qcr_preflight_r
# before building.
# =============================================================================

if (!exists("con")) {
  message("no open connection - sourcing validation/00_connect.R")
  source("validation/00_connect.R")
}
stopifnot(exists("con"), exists("personal_schema"), exists("source_schema"),
          exists("refresh"), exists("hrr_panel_mode"))

src_ <- function(tb) dplyr::tbl(con, dbplyr::in_schema(
          source_schema, paste0(tb, "_", refresh)))

# ---- input contract  (3.Data Prep, section A) -------------------------------
# Every source column the build reads, by table. Checked before the build, so
# a missing column stops the run before it starts instead of failing partway -
# which would leave the personal schema holding a mixture of this run's stages
# and the last one's (Q54). The offline harness diffs this list against
# validation/00_input_contract.csv, so the two cannot drift.
required_columns <- list(
  t_demographics = c("patientid", "birthyear", "race", "ethnicity", "state"),
  t_ecog = c("patientid", "ecogdate", "ecogvalue"),
  t_enh_prostate = c(
    "patientid", "diagnosisdate", "groupstage", "gleasonscore",
    "metastaticdiagnosisdate", "crpcdate", "crpctype", "hspcdate",
    "hspctype", "psainitialdiagnosis", "psametdiagnosis"),
  t_enh_prostate_biomarker = c(
    "patientid", "biomarkername", "biomarkerstatus", "resultdate",
    "specimencollecteddate"),
  t_enh_prostate_bsln_ecog = c(
    "patientid", "ecogdate", "ecogvalue", "linenumber",
    "linestartdate"),
  t_enh_prostate_drg_epsode = c(
    "patientid", "linename", "linenumber", "linesetting",
    "episodedate", "episodedatasource", "drugcategory",
    "detaileddrugcategory"),
  t_enh_prostate_lot = c(
    "patientid", "linename", "linenumber", "linesetting",
    "startdate", "enddate"),
  t_enh_prostate_orals = c("patientid", "startdategranularity", "enddate"),
  t_enh_prostate_prog_scled = c(
    "patientid", "progressiondate", "lastclinicnotedate",
    "isradiographicevidence", "ispathologicevidence",
    "ismixedresponsementioned", "ispseudoprogressionmentioned",
    "isphysicalexamevidence", "istumormarkerevidence",
    "ispsaincreased"),
  t_enh_prostate_psa = c("patientid", "scoreserial", "resultdate"),
  t_enh_prostate_psmapet = c("patientid", "scandate", "isdiseaseevidence"),
  t_enh_prostate_som = c("patientid", "siteofmetastasis", "dateofmetastasis"),
  t_lab = c(
    "patientid", "testbasename", "labcomponent", "testdate",
    "resultdate", "testresultcleaned", "testunitscleaned"),
  t_medicationadmin = c(
    "patientid", "administereddate", "drugcategory",
    "detaileddrugcategory"),
  t_medicationorder = c(
    "patientid", "expectedstartdate", "iscanceled",
    "drugcategory", "detaileddrugcategory"),
  t_mortality_v2 = c("patientid", "dateofdeath"),
  t_practice = c("patientid", "practicetype"),
  t_socdetofhealth = c("patientid", "sesindex2015_2019"),
  t_telemedicine = c("patientid", "visitdate"),
  t_visit = c("patientid", "visitdate"),
  t_vitals = c(
    "patientid", "test", "testdate", "resultdate", "testresult",
    "testresultcleaned", "testunitscleaned")
)

message("checking the input contract (", length(required_columns), " tables / ",
        length(unlist(required_columns)), " columns)")
contract_gap <- character(0)
for (t in names(required_columns)) {
  have <- tryCatch(colnames(src_(t)), error = function(e) NULL)
  contract_gap[t] <- if (is.null(have)) {
    "TABLE NOT READABLE"
  } else {
    gap <- setdiff(required_columns[[t]], tolower(have))
    if (length(gap)) paste("missing:", paste(gap, collapse = ", ")) else "ok"
  }
}

message("writing qcr_contract_r")
createInPersonalSchema(
  dbplyr::copy_inline(con, data.frame(
    tab        = names(required_columns),
    n_required = as.integer(lengths(required_columns)),
    status     = unname(contract_gap),
    stringsAsFactors = FALSE)),
  "qcr_contract_r", replace = TRUE)
contract_ok <- all(contract_gap == "ok")

# ---- the twelve B-gates -----------------------------------------------------
lot_all <- src_("t_enh_prostate_lot")
lot     <- lot_all %>% dplyr::filter(linesetting %in% c("mHSPC", "mCRPC"))
drugep  <- src_("t_enh_prostate_drg_epsode")

# dplyr:: qualified - the site helpers sourced by 00_connect.R mask count().
dup <- function(tb, ...) tb %>% dplyr::count(...) %>%
  dplyr::filter(n > 1) %>% dplyr::tally()

gate <- function(q, id, what, why) {
  q %>% dplyr::transmute(gate = !!id, what = !!what, why = !!why,
                         failed = as.integer(n))
}

# The LINENAME allow-list (B13/B14): a token is letters, digits, dots,
# brackets and hyphens, with single internal spaces (Clinical Study Drug,
# Radium-223). Tokens join with a bare comma or slash. Anything else - an
# outer space, a spaced separator, a trailing comma, an empty token - the
# anchored category parser cannot read: the regimen reads as one drug name,
# matches no rule, and lands in category 16 with nothing reporting it (Q65).
# An allow-list, not a reject-list - a reject-list only catches the
# characters somebody thought of.
LINENAME_OK <- "'^[A-Za-z0-9.()-]+( [A-Za-z0-9.()-]+)*([,/][A-Za-z0-9.()-]+( [A-Za-z0-9.()-]+)*)*$'"

gates <- list(
  gate(lot %>% dplyr::filter(is.na(startdate)) %>% dplyr::tally(),
       "B12", "NULL line start dates",
       "NEW_LOT_N ordering is not well defined"),
  gate(dup(lot, patientid, linesetting, startdate),
       "B1", "same-day line-of-therapy ties",
       "NEW_LOT_N is non-deterministic (Q24)"),
  gate(dup(lot, patientid, linesetting, linenumber),
       "B6", "duplicate LineNumbers per patient and setting",
       "baseline ECOG would join to the wrong line"),
  # Each table is tested at the grain the clinical block joins it on.
  # Pre-aggregating here would make a duplicate impossible and the gate
  # useless. Mortality is joined through a distinct(), so its gate matches.
  gate(dup(src_("t_enh_prostate"), patientid),
       "B2", "t_enh_prostate patients with >1 row", "joins fan out"),
  gate(dup(src_("t_demographics"), patientid),
       "B4", "t_demographics patients with >1 row", "joins fan out"),
  gate(dup(src_("t_socdetofhealth"), patientid),
       "B5", "t_socdetofhealth patients with >1 row", "joins fan out"),
  gate(dup(src_("t_mortality_v2") %>%
             dplyr::select(patientid, dateofdeath) %>% dplyr::distinct(),
           patientid),
       "B3", "patients with conflicting death dates", "joins fan out"),
  gate(lot %>%
         dplyr::filter(sql(paste0("linename IS NOT NULL
                     AND NOT linename RLIKE ", LINENAME_OK))) %>%
         dplyr::tally(),
       "B13", "LOT LINENAME separator/whitespace contract",
       "the regimen parser reads them as one drug -> category 16 (Q65)"),
  # Same contract on the drug-episode table: PRIOR_PARP and PRIOR_NHA_ADT
  # parse LINENAME from drug episodes, so an unexpected separator there
  # changes a delivered flag while B13 passes.
  gate(drugep %>%
         dplyr::filter(sql(paste0("linename IS NOT NULL
                     AND NOT linename RLIKE ", LINENAME_OK))) %>%
         dplyr::tally(),
       "B14", "drugepisode LINENAME separator/whitespace contract",
       "PRIOR_PARP and PRIOR_NHA_ADT parse the same names"),
  # LINESETTING is matched exactly in the build. A near-miss - mhspc, an
  # outer space - does not raise anything there: the row simply is not
  # selected, the line vanishes from its cohort, and the table still looks
  # complete. Catch the near-miss; a value that reads as neither setting is
  # out of the study by design.
  gate(lot_all %>%
         dplyr::filter(sql("linesetting IS NOT NULL
                     AND LOWER(TRIM(linesetting)) IN ('mhspc', 'mcrpc')
                     AND linesetting NOT IN ('mHSPC', 'mCRPC')")) %>%
         dplyr::tally(),
       "B15", "LOT LINESETTING case or whitespace variants",
       "the setting filter is exact - the line vanishes from its cohort"),
  gate(drugep %>%
         dplyr::filter(sql("linesetting IS NOT NULL
                     AND LOWER(TRIM(linesetting)) IN ('mhspc', 'mcrpc')
                     AND linesetting NOT IN ('mHSPC', 'mCRPC')")) %>%
         dplyr::tally(),
       "B16", "drugepisode LINESETTING case or whitespace variants",
       "the per-line episode look-up filters on the same exact value"),
  # A comma is taken as proof of a second drug, so 'abiraterone,abiraterone'
  # reads as an NHA combination rather than a monotherapy, and B13 passes it
  # because the format is legal. Split on the comma only: the slash binds
  # inside one co-formulated product name (Niraparib/Abiraterone), it does
  # not separate regimen components (Q65, Q78).
  gate(lot %>%
         dplyr::select(patientid, linename) %>%
         dplyr::union_all(drugep %>% dplyr::select(patientid, linename)) %>%
         dplyr::filter(sql("linename IS NOT NULL
                     AND SIZE(SPLIT(LOWER(linename), ','))
                         <> SIZE(ARRAY_DISTINCT(SPLIT(LOWER(linename), ',')))")) %>%
         dplyr::tally(),
       "B17", "LINENAME with the same drug listed twice",
       "a repeat reads as a combination regimen, not a monotherapy")
)

# ---- C10: expected lab analytes exist  (mandatory, Q25) ---------------------
# An absent combination empties its analyte (values and dates NULL), so this
# is a gate. NA component = no component filter. Compared the way the build
# compares (Q69): lower-cased name, trimmed unit, exact component - a raw
# compare would refuse a source the build accepts.
lab_expected <- data.frame(
  testbasename = c("neutrophils", "platelets", "hemoglobin", "creatinine",
                   "bilirubin", "aspartate aminotransferase",
                   "alanine aminotransferase", "alkaline phosphatase",
                   "albumin", "lymphocytes"),
  unit = c("10*9/L", "10*9/L", "g/dL", "mg/dL", "mg/dL", "U/L", "U/L",
           "U/L", "g/L", "10*9/L"),
  component = c(NA, NA, NA, "Creatinine, serum", NA, NA, NA, NA,
                "Albumin, serum", NA),
  stringsAsFactors = FALSE)

lab_found <- src_("t_lab") %>%
  dplyr::group_by(tb = tolower(testbasename), u = trimws(testunitscleaned),
                  lc = labcomponent) %>%
  dplyr::summarise(n = dplyr::n(), .groups = "drop")

lab_matches <- dbplyr::copy_inline(con, lab_expected) %>%
  dplyr::inner_join(lab_found, by = c("testbasename" = "tb")) %>%
  dplyr::filter(u == unit, is.na(component) | lc == component) %>%
  dplyr::group_by(testbasename, unit, component) %>%
  dplyr::summarise(found_rows = sum(n, na.rm = TRUE), .groups = "drop")

c10 <- dbplyr::copy_inline(con, lab_expected) %>%
  dplyr::left_join(lab_matches, by = c("testbasename", "unit", "component"),
                   na_matches = "na") %>%
  dplyr::mutate(found_rows = coalesce(found_rows, 0),
                status = dplyr::case_when(found_rows > 0 ~ "PASS",
                                          TRUE ~ "FAIL"))

message("writing qcr_c10_labs_r")
createInPersonalSchema(c10, "qcr_c10_labs_r", replace = TRUE)

gates <- c(gates, list(
  gate(c10 %>% dplyr::summarise(
         n = sum(dplyr::case_when(found_rows == 0 ~ 1L, TRUE ~ 0L),
                 na.rm = TRUE)),
       "C10", "expected lab analyte/unit combinations all present",
       "an absent combination empties its analyte - values and dates all NULL (Q25)")))

message("writing qcr_preflight_r (", length(gates), " gates)")
createInPersonalSchema(Reduce(dplyr::union_all, gates), "qcr_preflight_r",
                       replace = TRUE)

# ---- HRR panel drift, both directions  (Q44) --------------------------------
# A gene in the table but off the panel classifies as not-HRR; a panel gene
# missing from the cut narrows the case definition. Both land here. Under
# flatiron_all, empty = no drift; smaller panels also list their deliberate
# omissions as EXCLUDED. Canonical B7b always compares the frozen 19.
hrr_panels <- list(
  flatiron_all   = c("ATM", "ATR", "BARD1", "BRCA1", "BRCA2", "BRIP1",
                     "CDK12", "CHEK1", "CHEK2", "FANCA", "FANCL", "MLH1",
                     "MRE11A", "NBN", "PALB2", "RAD51B", "RAD51C",
                     "RAD51D", "RAD54L"),
  olaparib_label = c("ATM", "BARD1", "BRCA1", "BRCA2", "BRIP1", "CDK12",
                     "CHEK1", "CHEK2", "FANCL", "PALB2", "RAD51B",
                     "RAD51C", "RAD51D", "RAD54L"),
  talapro2       = c("ATM", "ATR", "BRCA1", "BRCA2", "CDK12", "CHEK2",
                     "FANCA", "MLH1", "MRE11A", "NBN", "PALB2", "RAD51C"))
hrr_genes <- hrr_panels[[hrr_panel_mode]]

hrr_actual <- src_("t_enh_prostate_biomarker") %>%
  dplyr::mutate(gene = toupper(biomarkername)) %>%
  dplyr::group_by(gene) %>%
  dplyr::summarise(n_results = dplyr::n(),
                   n_patients = dplyr::n_distinct(patientid),
                   .groups = "drop")

message("writing qcr_hrr_excluded_r (panel: ", hrr_panel_mode, ", ",
        length(hrr_genes), " genes)")
createInPersonalSchema(
  hrr_actual %>%
    dplyr::full_join(dbplyr::copy_inline(con, data.frame(
                       gene = hrr_genes, on_panel = 1L,
                       stringsAsFactors = FALSE)),
                     by = "gene") %>%
    dplyr::filter(is.na(on_panel) | is.na(n_results)) %>%
    dplyr::transmute(
      gene,
      n_results  = coalesce(n_results, 0L),
      n_patients = coalesce(n_patients, 0L),
      drift = dplyr::case_when(
        is.na(on_panel) ~
          "EXCLUDED - in the table, off the panel; classifies as not-HRR",
        TRUE ~
          "MISSING - on the panel, absent from the cut; narrows the case definition")),
  "qcr_hrr_excluded_r", replace = TRUE)

if (exists("qcr_stamp")) qcr_stamp("01_preflight")

message("Results written. Read in the SQL editor:")
for (t in c("qcr_contract_r", "qcr_preflight_r", "qcr_c10_labs_r",
            "qcr_hrr_excluded_r"))
  message("  SELECT * FROM ", personal_schema, ".", t)

if (!contract_ok) {
  bad <- names(contract_gap)[contract_gap != "ok"]
  message("FAIL - input contract: ",
          paste0(bad, " (", contract_gap[bad], ")", collapse = "; "),
          ". DO NOT BUILD.")
  quit(status = 1L, save = "no")
}

# Fail-closed: a verdict that cannot be fetched is not a pass. The tables are
# already written, so exit 2 and read qcr_preflight_r yourself.
v <- tryCatch(DBI::dbGetQuery(con, paste0(
       "SELECT COUNT(*) AS n FROM ", personal_schema,
       ".qcr_preflight_r WHERE failed IS NULL OR failed > 0")),
     error = function(e) NULL)
if (is.null(v)) {
  message("verdict fetch failed - read qcr_preflight_r before building")
  quit(status = 2L, save = "no")
}
if (v$n[1] > 0) {
  message("FAIL - ", v$n[1], " gate(s) hit. See qcr_preflight_r. DO NOT BUILD.")
  quit(status = 1L, save = "no")
}
message("PASS - the input contract holds and every gate reads 0. ",
        "Clear to build.")
