# =============================================================================
# OPEN-QUESTION QUERIES IN R - RUN IN DATABRICKS, NOTHING FETCHED
# =============================================================================
#   Rscript validation/04_open_questions.R        (repo root; reads source only)
#
# Same queries as validation/04_open_question_queries.sql, written as dplyr.
# Each closes a register row without a judgement call. Every query runs inside
# Databricks and lands as a table in the personal schema with
# createInPersonalSchema - nothing comes back to this session. Read the
# tables in the SQL editor.
#
#   qcr_q25_albumin_r     Q25. LABALB scale - the median settles g/L vs g/dL
#                         on sight. Run/read this one FIRST.
#   qcr_q52_granularity_r Q52. Granularity of the component that wins the
#                         index-date max(), cohorts 1-2 only. YEAR ~0% closes
#                         the row. Cohorts 3-7 have no granularity column.
#   qcr_q34_prog_chron_r  Q34. Progression after death / after the last note.
#                         Zeros close the row with no decision at all.
#   qcr_q42_next_trt_r    Q42. Next line on or before the previous one,
#                         within setting. Zero closes Q42 and supports Q24.
#   qcr_q42b_cross_setting_r  Q42b. mCRPC L1 start vs the cohort 3 index -
#                         the cross-setting half Q42 cannot see. n_le = 0
#                         closes Q42 on evidence that tests the case.
#   qcr_q38_line_before_milestone_r  Q38. Index line starting before its
#                         milestone, sized per cohort before the SME rules.
#
# The SQL's USE CATALOG / USE SCHEMA are replaced by the connection plus
# source_schema and refresh from 00_setup, so the schema is set in one place.
#
# The SQL's NULL rules carry over exactly:
#   `CASE WHEN c THEN x ELSE y`  ->  case_when(c ~ x, TRUE ~ y)
#       A NULL condition lands on the next arm / the ELSE, never on NULL.
#   SUM(CASE WHEN ...)           ->  sum(case_when(...), na.rm = TRUE)
#   GREATEST(a, b)               ->  pmax(a, b, na.rm = TRUE)  (null-skipping)
#
# NEW_LOT_N is derived, not stored: row_number() within patientid+linesetting
# ordered by startdate - the same window the build uses, so the numbers
# describe the delivered cohorts rather than the raw table.
# =============================================================================

if (!exists("con")) {
  message("no open connection - sourcing validation/00_connect.R")
  source("validation/00_connect.R")
}
stopifnot(exists("con"), exists("personal_schema"), exists("output_table"),
          exists("source_schema"), exists("refresh"))

src_ <- function(tb) dplyr::tbl(con, dbplyr::in_schema(
          source_schema, paste0(tb, "_", refresh)))

IDX_LO <- as.Date("2011-01-01")
IDX_HI <- as.Date("2026-04-30")

# ---- Q25: LABALB / LABALBV - is the delivered value g/L or g/dL? ------------
# Serum albumin is ~3.5-5.0 g/dL or ~35-50 g/L, so the median settles it.
message("writing qcr_q25_albumin_r")
createInPersonalSchema(
  src_("t_lab") %>%
    dplyr::filter(tolower(testbasename) == "albumin" &
                  !is.na(testresultcleaned)) %>%
    dplyr::mutate(unit = coalesce(testunitscleaned, "<NULL>")) %>%
    dplyr::group_by(labcomponent, unit) %>%
    dplyr::summarise(
      n_rows  = dplyr::n(),
      n_pts   = dplyr::n_distinct(patientid),
      min_val = round(min(testresultcleaned, na.rm = TRUE), 2),
      p25     = round(percentile_approx(testresultcleaned, 0.25), 2),
      median  = round(percentile_approx(testresultcleaned, 0.50), 2),
      p75     = round(percentile_approx(testresultcleaned, 0.75), 2),
      max_val = round(max(testresultcleaned, na.rm = TRUE), 2),
      .groups = "drop") %>%
    dplyr::arrange(dplyr::desc(n_rows)),
  "qcr_q25_albumin_r", replace = TRUE)

# ---- Q52: index-date granularity, Overall cohorts 1-2 only ------------------
# Which component wins max(metastaticdiagnosisdate, milestone), and how
# precisely that winner was known. Equal dates with equal granularities report
# the shared value; a tie whose granularities differ is broken out as TIE:a/b
# rather than silently assigned to one side. If the granularity names error,
# DESCRIBE t_enh_prostate and use its names (see the SQL header).
q52_c1 <- src_("t_enh_prostate") %>%
  dplyr::filter(dplyr::between(pmax(metastaticdiagnosisdate, hspcdate,
                                    na.rm = TRUE), !!IDX_LO, !!IDX_HI)) %>%
  dplyr::transmute(
    cohortn = 1L,
    win_granularity = dplyr::case_when(
      is.na(hspcdate) ~ coalesce(metastaticdiagnosisdategranularity, "<NULL>"),
      metastaticdiagnosisdate == hspcdate &
        coalesce(metastaticdiagnosisdategranularity, "x") ==
        coalesce(hspcdategranularity, "x")
        ~ coalesce(metastaticdiagnosisdategranularity, "<NULL>"),
      metastaticdiagnosisdate == hspcdate
        ~ paste0("TIE:", coalesce(metastaticdiagnosisdategranularity, "<NULL>"),
                 "/", coalesce(hspcdategranularity, "<NULL>")),
      metastaticdiagnosisdate > hspcdate
        ~ coalesce(metastaticdiagnosisdategranularity, "<NULL>"),
      TRUE ~ coalesce(hspcdategranularity, "<NULL>")))

q52_c2 <- src_("t_enh_prostate") %>%
  dplyr::filter(dplyr::between(pmax(metastaticdiagnosisdate, crpcdate,
                                    na.rm = TRUE), !!IDX_LO, !!IDX_HI)) %>%
  dplyr::transmute(
    cohortn = 2L,
    win_granularity = dplyr::case_when(
      is.na(crpcdate) ~ coalesce(metastaticdiagnosisdategranularity, "<NULL>"),
      metastaticdiagnosisdate == crpcdate &
        coalesce(metastaticdiagnosisdategranularity, "x") ==
        coalesce(crpcdategranularity, "x")
        ~ coalesce(metastaticdiagnosisdategranularity, "<NULL>"),
      metastaticdiagnosisdate == crpcdate
        ~ paste0("TIE:", coalesce(metastaticdiagnosisdategranularity, "<NULL>"),
                 "/", coalesce(crpcdategranularity, "<NULL>")),
      metastaticdiagnosisdate > crpcdate
        ~ coalesce(metastaticdiagnosisdategranularity, "<NULL>"),
      TRUE ~ coalesce(crpcdategranularity, "<NULL>")))

message("writing qcr_q52_granularity_r")
createInPersonalSchema(
  dplyr::union_all(q52_c1, q52_c2) %>%
    dplyr::group_by(cohortn, win_granularity) %>%
    dplyr::summarise(n_pts = dplyr::n(), .groups = "drop") %>%
    dplyr::group_by(cohortn) %>%
    dplyr::mutate(pct = round(100 * n_pts / sum(n_pts, na.rm = TRUE), 2)) %>%
    dplyr::ungroup() %>%
    dplyr::arrange(cohortn, dplyr::desc(n_pts)),
  "qcr_q52_granularity_r", replace = TRUE)
# Reading it: YEAR on the winning component means INDEXDT is almost certainly
# 1 January of that year. If YEAR is ~0%, close the row.

# ---- Q34: progression recorded after death or after the last note -----------
# PFSDT is taken as recorded, with no clamping and no exclusion. DateOfDeath
# is month/year granular, so "after death" is approximate at the month
# boundary - treat a small non-zero count as "check the rows", not proof.
# The evidence filter matches the build: any flag except pseudo-progression.
prog <- src_("t_enh_prostate_prog_scled") %>%
  dplyr::filter(!is.na(progressiondate) &
                (tolower(isradiographicevidence)   == "true" |
                 tolower(ispathologicevidence)     == "true" |
                 tolower(ismixedresponsementioned) == "true" |
                 tolower(isphysicalexamevidence)   == "true" |
                 tolower(istumormarkerevidence)    == "true" |
                 tolower(ispsaincreased)           == "true")) %>%
  dplyr::select(patientid, progressiondate, lastclinicnotedate)

message("writing qcr_q34_prog_chron_r")
createInPersonalSchema(
  prog %>%
    dplyr::left_join(src_("t_mortality_v2") %>%
                       dplyr::select(patientid, dateofdeath),
                     by = "patientid") %>%
    dplyr::summarise(
      n_qualifying_prog_rows = dplyr::n(),
      n_pts                  = dplyr::n_distinct(patientid),
      n_after_last_note = sum(dplyr::case_when(
        !is.na(lastclinicnotedate) &
          progressiondate > lastclinicnotedate ~ 1L,
        TRUE ~ 0L), na.rm = TRUE),
      n_after_death_month_end = sum(dplyr::case_when(
        !is.na(dateofdeath) &
          progressiondate > last_day(dateofdeath) ~ 1L,
        TRUE ~ 0L), na.rm = TRUE)),
  "qcr_q34_prog_chron_r", replace = TRUE)

# ---- Q42: next-treatment date on or before index, within setting ------------
# TTNT takes the next line's start with no after-index requirement; ordered by
# startdate, line n+1 can only tie or precede on a shared start date (Q24).
message("writing qcr_q42_next_trt_r")
createInPersonalSchema(
  src_("t_enh_prostate_lot") %>%
    dplyr::filter(linesetting %in% c("mHSPC", "mCRPC")) %>%
    dplyr::group_by(patientid, linesetting) %>%
    dbplyr::window_order(startdate) %>%
    dplyr::mutate(next_startdate = dplyr::lead(startdate)) %>%
    dplyr::ungroup() %>%
    dplyr::filter(!is.na(next_startdate) & next_startdate <= startdate) %>%
    dplyr::group_by(linesetting) %>%
    dplyr::summarise(
      n_consecutive_pairs_same_or_earlier = dplyr::n(),
      n_pts = dplyr::n_distinct(patientid),
      .groups = "drop") %>%
    dplyr::arrange(linesetting),
  "qcr_q42_next_trt_r", replace = TRUE)

# ---- Shared by Q42b and Q38: numbered lines and milestone dates -------------
# The SQL repeats these CTEs per query; they are identical, so one definition
# here is the way they cannot drift.
lot_n <- src_("t_enh_prostate_lot") %>%
  dplyr::filter(linesetting %in% c("mHSPC", "mCRPC")) %>%
  dplyr::group_by(patientid, linesetting) %>%
  dbplyr::window_order(startdate) %>%
  dplyr::mutate(new_lot_n = dplyr::row_number()) %>%
  dplyr::ungroup() %>%
  dplyr::select(patientid, linesetting, startdate, new_lot_n)

ms <- src_("t_enh_prostate") %>%
  dplyr::transmute(
    patientid,
    mhspcdd = pmax(metastaticdiagnosisdate, hspcdate, na.rm = TRUE),
    mcrpcdd = pmax(metastaticdiagnosisdate, crpcdate, na.rm = TRUE))

# ---- Q42b: the cross-setting half, cohort 3 only ----------------------------
# Cohort 3's next treatment is min(mHSPC LOT2, mCRPC LOT1); a within-setting
# LEAD() can never see the mCRPC side, which is why Q42 was reopened. The
# population is the delivered cohort 3: line start AND mHSPC milestone in the
# index window, exactly as 01_studypop.R requires. PASS: n_le = 0. Read
# n_before and n_same separately - a same-day start is the milder finding.
coh3 <- lot_n %>%                             # the delivered L1+ treated mHSPC
  dplyr::inner_join(ms, by = "patientid") %>%
  dplyr::filter(linesetting == "mHSPC" & new_lot_n == 1L &
                dplyr::between(startdate, !!IDX_LO, !!IDX_HI) &
                dplyr::between(mhspcdd,  !!IDX_LO, !!IDX_HI)) %>%
  dplyr::transmute(patientid, indexdt = startdate)

crpc1 <- lot_n %>%                            # their first mCRPC line, if any
  dplyr::filter(linesetting == "mCRPC" & new_lot_n == 1L) %>%
  dplyr::select(patientid, crpc1_start = startdate)

message("writing qcr_q42b_cross_setting_r")
createInPersonalSchema(
  coh3 %>%
    dplyr::left_join(crpc1, by = "patientid") %>%
    dplyr::summarise(
      n_cohort3       = dplyr::n(),
      n_with_mcrpc_l1 = sum(dplyr::case_when(!is.na(crpc1_start) ~ 1L,
                                             TRUE ~ 0L), na.rm = TRUE),
      n_le     = sum(dplyr::case_when(crpc1_start <= indexdt ~ 1L,
                                      TRUE ~ 0L), na.rm = TRUE),
      n_before = sum(dplyr::case_when(crpc1_start <  indexdt ~ 1L,
                                      TRUE ~ 0L), na.rm = TRUE),
      n_same   = sum(dplyr::case_when(crpc1_start == indexdt ~ 1L,
                                      TRUE ~ 0L), na.rm = TRUE),
      worst_gap_days = min(datediff(crpc1_start, indexdt), na.rm = TRUE)),
  "qcr_q42b_cross_setting_r", replace = TRUE)

# ---- Q38: index line starting before the milestone it is joined to ----------
# The cohort join matches on patientid only and enforces no chronology; this
# sizes the mismatch per cohort before the SME is asked to rule.
message("writing qcr_q38_line_before_milestone_r")
createInPersonalSchema(
  lot_n %>%
    dplyr::inner_join(ms, by = "patientid") %>%
    dplyr::filter(
      dplyr::between(startdate, !!IDX_LO, !!IDX_HI) &
      ((linesetting == "mHSPC" & dplyr::between(mhspcdd, !!IDX_LO, !!IDX_HI)) |
       (linesetting == "mCRPC" & dplyr::between(mcrpcdd, !!IDX_LO, !!IDX_HI))) &
      ((linesetting == "mHSPC" & new_lot_n == 1L) |
       (linesetting == "mCRPC" & dplyr::between(new_lot_n, 1L, 4L)))) %>%
    dplyr::mutate(cohort = dplyr::case_when(
      linesetting == "mHSPC" & new_lot_n == 1L ~ "3 L1+ mHSPC",
      linesetting == "mCRPC" & new_lot_n == 1L ~ "4 L1+ mCRPC",
      linesetting == "mCRPC" & new_lot_n == 2L ~ "5 L2+ mCRPC",
      linesetting == "mCRPC" & new_lot_n == 3L ~ "6 L3+ mCRPC",
      linesetting == "mCRPC" & new_lot_n == 4L ~ "7 L4+ mCRPC")) %>%
    dplyr::group_by(cohort) %>%
    dplyr::summarise(
      n_pts_in_cohort = dplyr::n_distinct(patientid),
      n_pts_line_before_milestone = dplyr::n_distinct(dplyr::case_when(
        (linesetting == "mHSPC" & startdate < mhspcdd) |
        (linesetting == "mCRPC" & startdate < mcrpcdd) ~ patientid)),
      .groups = "drop") %>%
    dplyr::mutate(pct = round(100 * n_pts_line_before_milestone /
                              dplyr::na_if(n_pts_in_cohort, 0L), 1)) %>%
    dplyr::arrange(cohort),
  "qcr_q38_line_before_milestone_r", replace = TRUE)

if (exists("qcr_stamp")) qcr_stamp("04_open_questions")

message("DONE - nothing was fetched. Read in the SQL editor:")
for (t in c("qcr_q25_albumin_r", "qcr_q52_granularity_r", "qcr_q34_prog_chron_r",
            "qcr_q42_next_trt_r", "qcr_q42b_cross_setting_r",
            "qcr_q38_line_before_milestone_r"))
  message("  SELECT * FROM ", personal_schema, ".", t)
