# Open questions

**Part A is everything still unanswered, grouped by who can answer it.** Part B,
below, is how to run the build.

**Every row here is already decided and already implemented.** The rulings are
in `DEVIATIONS.md` and the rule each produced is in `SPEC.csv`; nothing below
blocks the build from running, and nothing is being re-opened.

What is outstanding is **ratification**, which is a different thing from a
decision. A1 and A2 rows read `RESOLVED` in the register because the data
product owner approved them. They are listed here because an owner cannot
ratify a clinical judgement on a clinician's behalf, and because two of them
are release-procedure calls that a reviewer should see before signing. Read
each as *owner-approved, ratification pending* - not as an open question.

---

## A1. For the clinical SME

Five items. Everything else in this file is either operational or answered by
running the build.

| Row | Question | Blocks sign-off? |
|---|---|---|
| Q03, Q20, Q29, Q37 | These four biomarker rulings reached us second-hand, through the data product owner: test type stays `Unknown`; the `[-30, +7]` window beats "any time prior to index"; `Negative` outranks `VUS` across genes; one shared winning test date for HRR and BRCA. Did you rule them, and may we record your name against them? | Yes - a release record needs a named clinician |
| Q68 | Height and weight are admitted at any non-null value, because that is what the spec asks for. A negative weight therefore delivers a negative `BMI`, banded `Underweight`. Every step follows the spec. The result is not a measurement. Owner confirmed 2026-08-09: the spec overrides 202603's positive-only filter (register Q68). The clinical question stands: add a plausibility range, or accept? | Yes |
| Q34 | `PFS` can exceed `OS`, because a progression can be recorded after the death date. The spec says to treat this as a data limitation and take no action, which we have. At most 896 source rows of 231,261 are affected, and the delivered count is lower. Owner confirmed 2026-08-09 (register Q34); clinical ratification pending. | Yes |
| Q38 | 10,170 treated patients are indexed on a line of therapy that began **before** the disease milestone that admitted them to the cohort - 6.1% of L1+ mHSPC, 10.5% of L1+ mCRPC. Their baseline windows, `OS`, `TTNT` and `PFS` all anchor on that earlier date. Accepted, not repaired. Owner confirmed 2026-08-09; 202603 used the same mechanism, mCRPC-only (register Q38). Ratification and data-dictionary note pending. | Yes |
| Q52 | About 17% of Overall mHSPC index dates are not day-level. A year-level milestone resolves to 1 January, so `OS`, `FUDUR` and every index window can be up to a year early for those patients. Accepted, not repaired. Owner confirmed 2026-08-09; 202603 did the same, mCRPC-only (register Q52). Ratification and data-dictionary note pending. | Yes |

---

## A2. For the data product owner

| Row | Question | Blocks sign-off? |
|---|---|---|
| Q43 | The build writes the deliverable directly under a stable name with `replace = TRUE`. A re-run silently overwrites the exact table QC just reviewed, and nothing in the QC pack records which build produced it. Add a build ID, or accept? Affects every run, not rare data. | Yes |
| Q16 | `max_drug_ep_abstracted_dt` is NULL for every patient - its source value does not exist in this cut. Ship an empty column, or drop it? Dropping takes the contract from 190 columns to 189 and breaks anyone already coding against it. | Yes |

---

## A3. Answered by running the build, not by a person

The query is named for each. Q66, Q67 and Q69 are counts that a zero closes with no judgement. Q68's count only SIZES its exposure - the decision it feeds is the A1 plausibility ruling, which stays clinical. Q70 is not a count - it is a review-and-commit step: the first run captures the column types, somebody reads them, and committing the file is what pins them.

| Row | What to count | Query |
|---|---|---|
| Q66 | Death dates the build cannot parse - wrong length or impossible content - read as censored. `validation/06` q66 at zero closes it (ADS-scoped); `qc/08` sizes the source-wide exposure. | `validation/06` q66 (oracle); `qc/08` Q08a-d |
| Q67 | Blood pressure readings that are positive but not whole numbers. Those now read `Unknown`. | `qc/09` Q09a |
| Q68 | Zero or negative height/weight - sizing only; closure is the A1 clinical ruling. | `qc/09` Q09b, Q09c |
| Q69 | Whether `LABHEM` is populated at all. If every row reads `Missing`, the unit filter matched nothing. | `qc/03` R54 |
| Q70 | The captured column types. Review `qc/qc_column_types.csv` and commit it - nothing is pinned until you do. | `qc/07` |

Answered by the 2026-08-08 run: **Q65 / Q78** (B13-B16 passed; B17 passed after the comma-only split correction - the Q78 addendum records it) and **Q13** (`qc/05` C14a-j all MATCH). Answered by direct query 2026-08-09: **Q73** (zero NULL-named lines in either setting - R55 and S6 stay as the refresh check) and the two audit follow-ups now registered as **Q80** (lab name case-fold, value-neutral) and **Q81** (CSD latent NULL path, unreachable this cut).

---

## A4. Not questions - things to tell downstream users

These belong in the data dictionary. They are settled; they just have to be said.

| Row | What to say |
|---|---|
| Q58 | For every `LAB*` and `BP`, `Unknown` is no longer a data-quality signal. It mixes a few percent with an unusable baseline record and about 39% who were simply tested later. `Present` is the only positive statement. |
| Q60 | `PRIOR_NHA_ADT` is broader than its name. Any NHA plus a second drug sets it, whether or not that drug is an ADT. An NHA with chemotherapy counts. |
| Q38, Q52 | Both A1 rows above also belong here once confirmed - the pre-milestone index lines and the coarse index dates. |

---

## A5. What the checks cannot tell you

Not questions, and not fixable by running anything. Read them before treating a
PASS as coverage.

- `qc/00_coverage.R` proves a decision is **named** by a check. It cannot prove
  the check is right. Four checks passed it while testing the wrong thing.
- The harness proves `SPEC.csv` carries the 190 delivered columns in order, each
  with a definition. It cannot prove a definition still **matches** the code.
  That drifted once already, on the BMI band. Change a derivation and its
  `SPEC.csv` row in the same commit.
- Three things cannot be built until the first run supplies a baseline: a
  short-build tolerance (nothing rejects even an empty cohort before the
  write any more - V26 catches it after), source column **types** in the
  input contract, and fail-closed allow-lists for the exact-match
  categoricals like `GLEASONSCORE`.

---

## Status

First full run completed 2026-08-08: the build wrote 515,406 rows, all twelve
preflight B-gates passed (B17 after the comma-only correction, Q78 addendum),
the column contract check passed (V27 exact name and order, V21 no struck-out
variable), `qc/05` reported 35 of 37 MATCH - the two DIFFERs were a
numeric-vs-string comparison artefact in the checks themselves, since fixed,
and a direct SQL diff of both columns found zero disagreeing rows - and
`qc/07` captured the column types - `qc/qc_column_types.csv` is awaiting review and commit (Q70). Still
unrun: the V-gates (`validation/03`), the null sweep (`03b`), `qc/01`-`04`,
`qc/06`, `qc/08`-`09` and the sizing queries (`validation/05`). Decisions those
would evidence still read PENDING - `DEVIATIONS.md` holds the per-row state,
and is the only place that count is kept.

---

# Part B. How to run the build

### Two copies, and what each one holds

The production copy is `docs/` and `code/`. Everything that CHECKS the build -
the release gates, the QC pack, the offline harness, the contracts - stays in
the build repository.

| | Production copy | Build repository |
|---|---|---|
| Holds | `docs/`, `code/` | all of it, including `validation/` and `qc/` |
| Can | run the build | run the build, and verify what it produced |
| Cannot | verify anything | - |

So read this section twice: once for what runs where you are, once for what has
to happen before the delivered table is trustworthy.

**The build does not read `validation/` or `qc/`,** and it no longer checks
anything itself: the cohort code only creates. Every check - the twelve
preflight B-gates, the input contract, the release gates, the QC pack -
lives in `validation/` and `qc/`. The one contract the build keeps is the
190-column allowlist inside `code/modules/06_assemble.R`, because selecting
against it is part of creating the table. The production copy will build
correctly. It will not tell you whether the source was fit to build from, or
whether the result is right.

One leftover to expect: on success the build prints *"This table is LIVE -
run the output validation now"*. That means
`Rscript validation/03_output_validation.R`, in the build repository. It is
not in the production copy.

**If you want the checks alongside the code,** six files are enough for the
mandatory preflight and all three fail-closed gates, and none of them needs
the rest of `validation/`:

```
validation/00_connect.R
validation/01_preflight.R
validation/00_column_contract.csv
validation/03_output_validation.R
validation/03b_null_sweep.R
validation/04_column_contract_check.R
```

Those are the executable release scripts. The matching `.sql` files are the
canonical reviewed statements of the same checks - take them too if the
reviewer wants to read SQL, but nothing needs them to run.

### Names to substitute

| Token | Value |
|---|---|
| `${catalog}` | `hive_metastore` |
| `${src}` | `clnprw_flatiron_pano_pros_use` (source tables only) |
| `${schema}` | `osk02156` (the personal OUTPUT schema, pinned in `00_setup.R`) |
| `${ads}` | `rwdp_pros_pano_2026m06` |

These are text substitutions, not SQL parameters - `:param` binds values, not
object names. In a notebook where `${...}` still resolves, set the widgets.
Anywhere else, find and replace.

Run every command from the root of whichever copy holds the file.

---

### Before the build - from the build repository

The build itself checks nothing, so these run FIRST, in this order. Steps 1
and 2 need no database. Step 3 does, and it is mandatory:

| # | Command | Stop if |
|---|---|---|
| 1 | `Rscript validation/02_offline_build_check.R` | Anything other than `PASS`. Renders all 43 stages against a simulated Spark backend, so it catches a bad column reference, a broken lazy chain, an R helper leaking into SQL, and any drift between the generated files, `SPEC.csv` and the column contract. No database needed. |
| 2 | `Rscript qc/00_coverage.R` | Anything other than `PASS`. Every decision that changes output must be named by a check and carry an approver. |
| 3 | `Rscript validation/01_preflight.R` | Anything other than `PASS`. MANDATORY - the input contract, twelve B-gates and C10, written to `qcr_contract_r`, `qcr_preflight_r`, `qcr_hrr_excluded_r`, `qcr_c10_labs_r`. A failure means do not build. The canonical SQL adds sections A, C and D; its B7b always compares the frozen 19 where R uses the active panel. |

For a non-default HRR panel, set `RDAP_HRR_PANEL` before step 3 AND before
the build - the preflight, the build and every check below read it to aim at
the same suffixed table.

---

### The build - from the production copy

**4. The build.** Only after steps 1-3 pass.

```
Rscript code/prostate_rdap_202606.R
```

Writes 42 stage tables, then `${schema}.${ads}`, then a run manifest to
`RUN_MANIFEST.txt`.

Things to know:

- **No manifest means the run did not finish.** The driver deletes any previous
  one before it starts, so a stale file cannot look current.
- **The build runs no gates and nothing guards the write.** A build from a
  source that never saw step 3 - or an empty build - replaces the live table.
  The V26 cohort counts in the output validation catch an empty or collapsed
  cohort straight after the build, not before (Q27).
- **The table is LIVE the moment the build finishes** (Q27). There is no
  staging copy and no publish step. Until the gates below have run, the
  delivered table is unvalidated and consumers can already read it.
- For a non-default HRR panel, `RDAP_HRR_PANEL` makes the build write to its
  own table name, so it cannot land on the governed one (Q05).

---

### After the build - from the build repository

**Release gates - all three must pass.** Fail-closed. A failure means drop or
rebuild the table.

| # | Command | Passes when |
|---|---|---|
| 5 | `Rscript validation/03_output_validation.R` | Every row of `qcr_vgates_r` reads PASS. |
| 6 | `Rscript validation/03b_null_sweep.R` | No FAIL and no REVIEW row in `qcr_nullsweep_r` - the program exits nonzero on either. Nine columns are WAIVED by name. |
| 7 | `Rscript validation/04_column_contract_check.R` | 190 columns, same names (compared lower-cased, as Spark resolves them), same order. With no argument it checks the table the current `RDAP_HRR_PANEL` builds; pass a table name to override. |

**QC pack.** Not fail-closed. These produce numbers somebody has to read.

| # | Command | What it gives you |
|---|---|---|
| 8 | `Rscript qc/01_variable_profile.R` | Null rate and cardinality, 190 columns x 7 cohorts. |
| 9 | `Rscript qc/02_code_label_agreement.R` | All 25 label/code pairs, both directions. |
| 10 | `Rscript qc/03_cross_variable_rules.R` | 63 consistency rules, R01-R57, in `qcr_rules_r`. |
| 11 | `Rscript qc/04_cohort_attrition.R` | The waterfall from source to each cohort. |
| 12 | `Rscript qc/05_independent_rederivation.R` | 37 checks that rebuild variables from source in hand-written SQL and compare. A difference means one of the two is wrong. |
| 13 | `Rscript qc/06_golden_patients.R` | End-to-end trace for a handful of patients. **Someone has to read these.** |
| 14 | `Rscript qc/07_type_contract.R` | First run *captures* types to `qc/qc_column_types.csv`. Review it, commit it, re-run - then it *checks* them. Nothing is pinned until you do (Q70). |
| 15 | `Rscript qc/08_death_date_formats.R` | Sizes the Q66 exposure: death dates that fall to NULL. |
| 16 | `Rscript qc/09_vitals_domain.R` | Sizes the Q67 and Q68 rulings. |
| 17 | `Rscript validation/05_sizing.R` | S1-S6, the counts sections 2 and 4 are waiting on. |
| 18 | `Rscript validation/04_open_questions.R` | The rows that close on a query with no judgement call. |
| 19 | `Rscript validation/06_register_counts.R` | The Q66-Q69 counts. Q66/Q67/Q69 close on zero; Q68 sizes only. |

The database-side checks write small `qcr_*` tables, fetch at most a one-row
verdict, and print what to read. Exceptions: steps 1-2 run offline, step 7
reads the column names directly, and `qc/05` / `qc/07` fetch their
comparison rows and write a CSV each for the pack. The
matching `.sql` files in the repository are the canonical, reviewed
definitions the R programs were translated from; they are not needed to run
anything.

---

### After the run

1. Keep `RUN_MANIFEST.txt`, the preflight and gate output from steps 3 and
   5-7, and the QC pack from steps 8-19. That set is the release record.
2. Fill the **QC evidence** line in `DEVIATIONS.md` for every decision the run
   actually evidenced. It reads `PENDING` until then, which is the honest
   default - a blank would read as "not applicable".
3. Answer what the run answers: sections 2 and 4 name the query for each.
4. `Rscript validation/make_traceability.R` to refresh the commit column, then
   commit. It cannot see the commit containing its own output, so re-run it
   once more after that if a decision settled in the same commit.
5. Tell downstream users the three things in section 3. That belongs in the
   data dictionary, not only here.

### Regenerating the generated files

Three files are generated, and the offline harness regenerates and diffs them,
so a hand edit fails the build check. Edit the source, then regenerate:

| File | Command |
|---|---|
| `validation/03b_null_sweep.sql` | `Rscript validation/make_null_sweep.R` |
| `qc/01_variable_profile.sql`, `qc/02_code_label_agreement.sql` | `Rscript qc/make_qc_sql.R` |

Both read `validation/00_column_contract.csv`. Change a column there and both
must be regenerated.
