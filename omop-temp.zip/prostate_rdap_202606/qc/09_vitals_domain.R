# =============================================================================
# QC 09. VITALS VALUE DOMAINS IN R - RUN IN DATABRICKS, NOTHING FETCHED
# =============================================================================
#   Rscript qc/09_vitals_domain.R                 (after a build, repo root)
#
# Same queries as qc/09_vitals_domain.sql, written as dplyr. Two rulings of
# 2026-08-08 moved in opposite directions; both need a number rather than an
# assumption:
#   Q67  BP tightened to the spec: "a positive integer", so a positive but
#        fractional reading is Unknown, not Present. Q09a counts what the
#        integrality test moves.
#   Q68  Weight/height loosened to the spec: a record qualifies on
#        "TESTRESULTCLEANED is not null" and nothing else - no sign test.
#        Q09b counts the non-positive values that admits, Q09c shows what
#        they do downstream.
#
# Read Q09b first. If it returns zero, the Q68 ruling is value-neutral and
# the division guards on BMI/BSA are purely defensive.
#
# Read the results in the SQL editor:
#   qcr_q09a_r  BP readings per arm; n_positive_non_integral = 0 closes Q67.
#   qcr_q09b_r  zero or negative height and weight - the Q68 numbers.
#   qcr_q09c_r  what reached the delivered table, and what BMI/BSA did
#               with it.
#   qcr_q09d_r  plausibility, report-only - not a ruling, no code enforces it.
#
# OVERLAP: Q09a and Q09b also run as qcr_q67_bp_r and qcr_q68_hw_r in
# validation/06_register_counts.R - same queries, same numbers. They are
# repeated here as qcr_q09a_r / qcr_q09b_r so this file is complete on its
# own.
# =============================================================================

if (!exists("con")) {
  message("no open connection - sourcing validation/00_connect.R")
  source("validation/00_connect.R")
}
stopifnot(exists("con"), exists("personal_schema"), exists("output_table"),
          exists("source_schema"), exists("refresh"))

ads  <- dplyr::tbl(con, dbplyr::in_schema(personal_schema, output_table))
src_ <- function(tb) dplyr::tbl(con, dbplyr::in_schema(
          source_schema, paste0(tb, "_", refresh)))

# =============================================================================
# Q09a. Q67 - BP readings that are positive but not integral
# =============================================================================
# These rows are Unknown rather than Present and lose their BPSYS/BPDIA, as
# the spec's Unknown clause instructs. Blood pressure is recorded in whole
# millimetres of mercury in practice, so zero is the expected answer; review
# a non-zero answer before anyone reads a BP frequency table.
#
# The test is on the cast value: '120.0' casts to 120.0, which equals its own
# round, so a decimal point in the text does not by itself disqualify a row.
message("writing qcr_q09a_r")
createInPersonalSchema(
  src_("t_vitals") %>%
    dplyr::filter(tolower(test) %in% c("systolic blood pressure",
                                       "diastolic blood pressure")) %>%
    dplyr::mutate(v = !!safe_num(testresult)) %>%
    dplyr::group_by(arm = tolower(test)) %>%
    dplyr::summarise(
      n_rows         = dplyr::n(),
      n_patients     = dplyr::n_distinct(patientid),
      n_uncastable   = sum(dplyr::case_when(is.na(v) ~ 1L, TRUE ~ 0L),
                           na.rm = TRUE),
      n_non_positive = sum(dplyr::case_when(v <= 0 ~ 1L, TRUE ~ 0L),
                           na.rm = TRUE),
      n_positive_non_integral =
        sum(dplyr::case_when(v > 0 & v != round(v, 0L) ~ 1L, TRUE ~ 0L),
            na.rm = TRUE),
      .groups = "drop") %>%
    dplyr::arrange(arm),
  "qcr_q09a_r", replace = TRUE)

# =============================================================================
# Q09b. Q68 - height and weight records that are not positive
# =============================================================================
# Read n_zero and n_negative. Those are the values Q68 admits: the spec's
# clause is "TESTRESULTCLEANED is not null" and says nothing about sign.
# n_rows is every height/weight record, not only the non-positive ones - it
# is the denominator, not the finding.
message("writing qcr_q09b_r")
createInPersonalSchema(
  src_("t_vitals") %>%
    dplyr::filter((tolower(test) == "body height" &
                     testunitscleaned == "cm") |
                  (tolower(test) == "body weight" &
                     testunitscleaned == "kg")) %>%
    dplyr::group_by(measure = tolower(test), unit = testunitscleaned) %>%
    dplyr::summarise(
      n_rows     = dplyr::n(),
      n_patients = dplyr::n_distinct(patientid),
      n_zero     = sum(dplyr::case_when(testresultcleaned == 0 ~ 1L,
                                        TRUE ~ 0L), na.rm = TRUE),
      n_negative = sum(dplyr::case_when(testresultcleaned < 0 ~ 1L,
                                        TRUE ~ 0L), na.rm = TRUE),
      min_val    = min(testresultcleaned, na.rm = TRUE),
      max_val    = max(testresultcleaned, na.rm = TRUE),
      .groups = "drop") %>%
    dplyr::arrange(measure, unit),
  "qcr_q09b_r", replace = TRUE)

# =============================================================================
# Q09c. Q68 - what reaches the delivered table, and what BMI/BSA did with it
# =============================================================================
# The division guards on BMI and BSA are not part of the Q68 ruling: that
# ruling is about which vitals records qualify. The guards exist because the
# spec's own BMI formula divides by HEIGHT, and a zero height is a
# DIVIDE_BY_ZERO under ANSI - a build failure, not a value. Under legacy
# semantics the same expression yields NULL and BMIGR1 reads 'Missing', so
# the guard delivers exactly what the spec's formula delivers and only
# removes the crash. Same reasoning as the PSABL guard ruled under Q59.
#
# This confirms that claim on real rows rather than asserting it.
message("writing qcr_q09c_r")
createInPersonalSchema(
  ads %>%
    dplyr::mutate(shape = dplyr::case_when(
      is.na(height) & is.na(weight) ~ "1 neither recorded",
      is.na(height)                 ~ "2 weight only",
      is.na(weight)                 ~ "3 height only",
      height <= 0 | weight <= 0     ~ "4 NON-POSITIVE - admitted by Q68",
      TRUE                          ~ "5 both positive")) %>%
    dplyr::group_by(shape) %>%
    dplyr::summarise(
      n_rows           = dplyr::n(),
      n_patients       = dplyr::n_distinct(patid),
      n_bmi_null       = sum(dplyr::case_when(is.na(bmi) ~ 1L, TRUE ~ 0L),
                             na.rm = TRUE),
      n_bsa_null       = sum(dplyr::case_when(is.na(bsa) ~ 1L, TRUE ~ 0L),
                             na.rm = TRUE),
      n_bmigr1_missing = sum(dplyr::case_when(bmigr1 == "Missing" ~ 1L,
                                              TRUE ~ 0L), na.rm = TRUE),
      # NaN survives IS NULL and poisons any downstream mean, so it is
      # counted separately. A non-zero figure here means a guard was missed.
      # is.nan() has no Spark translation in dbplyr, so ISNAN goes in raw.
      n_bmi_nan        = sum(dplyr::case_when(sql("ISNAN(bmi)") ~ 1L,
                                              TRUE ~ 0L), na.rm = TRUE),
      n_bsa_nan        = sum(dplyr::case_when(sql("ISNAN(bsa)") ~ 1L,
                                              TRUE ~ 0L), na.rm = TRUE),
      min_height       = round(min(height, na.rm = TRUE), 1),
      min_weight       = round(min(weight, na.rm = TRUE), 1),
      .groups = "drop") %>%
    dplyr::arrange(shape),
  "qcr_q09c_r", replace = TRUE)

# =============================================================================
# Q09d. Plausibility, report-only - not a ruling, and no code enforces it
# =============================================================================
# Nothing in the spec or the build bounds these beyond the conditions above,
# so an extreme but positive value propagates into WEIGHT, HEIGHT, BMI and
# BSA unchallenged. This is recorded as a known gap rather than fixed,
# because a plausibility range is a clinical judgement nobody has made yet.
# The ranges below are deliberately wide - they are meant to catch unit
# errors and data entry slips, not to define a normal adult.
out_of_range <- function(flag, col, lo, hi) {
  s <- rlang::sym(col)
  ads %>%
    dplyr::filter(!is.na(!!s) & (!!s < !!lo | !!s > !!hi)) %>%
    dplyr::summarise(n_rows     = dplyr::n(),
                     n_patients = dplyr::n_distinct(patid),
                     min_val    = round(min(!!s, na.rm = TRUE), 1),
                     max_val    = round(max(!!s, na.rm = TRUE), 1)) %>%
    dplyr::transmute(flag = !!flag, n_rows, n_patients, min_val, max_val)
}

message("writing qcr_q09d_r")
createInPersonalSchema(
  Reduce(dplyr::union_all, list(
    out_of_range("height outside 50-250 cm",      "height",  50, 250),
    out_of_range("weight outside 20-400 kg",      "weight",  20, 400),
    out_of_range("bmi outside 10-100",            "bmi",     10, 100),
    out_of_range("systolic outside 50-300 mmHg",  "bpsys",   50, 300),
    out_of_range("diastolic outside 20-200 mmHg", "bpdia",   20, 200),
    ads %>%
      dplyr::filter(!is.na(bpsys) & !is.na(bpdia) & bpdia >= bpsys) %>%
      dplyr::summarise(n_rows     = dplyr::n(),
                       n_patients = dplyr::n_distinct(patid)) %>%
      dplyr::transmute(flag = "diastolic >= systolic", n_rows, n_patients,
                       min_val = NA_real_, max_val = NA_real_)
  )),
  "qcr_q09d_r", replace = TRUE)

if (exists("qcr_stamp")) qcr_stamp("qc09_vitals_domain")

message("DONE - nothing was fetched. Read in the SQL editor:")
for (t in c("qcr_q09a_r", "qcr_q09b_r", "qcr_q09c_r", "qcr_q09d_r"))
  message("  SELECT * FROM ", personal_schema, ".", t)
