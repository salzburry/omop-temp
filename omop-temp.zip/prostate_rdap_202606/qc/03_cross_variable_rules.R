# =============================================================================
# QC 03. CROSS-VARIABLE CONSISTENCY IN R - RUN IN DATABRICKS, NOTHING FETCHED
# =============================================================================
#   Rscript qc/03_cross_variable_rules.R           (after a build, repo root)
#
# Same rules as qc/03_cross_variable_rules.sql, written as dplyr. Each rule
# recomputes a delivered value from other delivered values, then counts the
# rows where the two disagree. It reads the ADS and nothing else. Every rule
# runs inside Databricks; the result lands in the personal schema and nothing
# comes back to this session.
#
# This catches what the release gates cannot: a value that is legal on its
# own but wrong next to its inputs. A join that doubles a patient's rows
# leaves every column legal. So does an AGE built from a birthyear a later
# join overwrote.
#
# Read the result in the SQL editor:
#   qcr_rules_r    one row per rule: rule, class, what, checked, failed,
#                  pct, status - same columns as the SQL's final SELECT.
#                  class GATE   - failed must be 0. Any count is a defect.
#                  class REVIEW - report only. Record the number; look again
#                                 if it moves between cuts.
#
# Rule numbers are stable. Append, never renumber, so packs stay comparable.
#
# The SQL's NULL rules carry over exactly:
#   SUM(CASE WHEN c THEN 1 ELSE 0 END) -> sum(case_when(c ~ 1L, TRUE ~ 0L))
#       A NULL condition lands on the ELSE, so it is never counted.
#   `a IS DISTINCT FROM b`  ->  coalesce(a != b, TRUE) & !(is.na(a) & is.na(b))
#       True when the values differ, or one side is NULL and the other is not.
#   SQL WHERE drops a NULL condition; dplyr::filter does the same.
# =============================================================================

if (!exists("con")) {
  message("no open connection - sourcing validation/00_connect.R")
  source("validation/00_connect.R")
}
stopifnot(exists("con"), exists("personal_schema"), exists("output_table"),
          exists("source_schema"), exists("refresh"))

ads <- dplyr::tbl(con, dbplyr::in_schema(personal_schema, output_table))

# One rule row. checked = COUNT(*) of tb after its own filter; failed = the
# rows where `bad` holds. The ELSE 0 branch means a NULL condition is never
# counted, same as the SQL's SUM(CASE WHEN ... THEN 1 ELSE 0 END).
rule_n <- function(id, cls, what, tb, bad) {
  bad <- rlang::enquo(bad)
  tb %>% dplyr::summarise(
      n_chk = dplyr::n(),
      n_bad = sum(dplyr::case_when(!!bad ~ 1L, TRUE ~ 0L), na.rm = TRUE)) %>%
    dplyr::transmute(rule = !!id, class = !!cls, what = !!what,
                     checked = as.integer(n_chk), failed = as.integer(n_bad))
}

# Same, but both counts are SUM(CASE WHEN ...): `chk` picks the applicable
# rows, `bad` the violations.
rule_s <- function(id, cls, what, tb, chk, bad) {
  chk <- rlang::enquo(chk); bad <- rlang::enquo(bad)
  tb %>% dplyr::summarise(
      n_chk = sum(dplyr::case_when(!!chk ~ 1L, TRUE ~ 0L), na.rm = TRUE),
      n_bad = sum(dplyr::case_when(!!bad ~ 1L, TRUE ~ 0L), na.rm = TRUE)) %>%
    dplyr::transmute(rule = !!id, class = !!cls, what = !!what,
                     checked = as.integer(n_chk), failed = as.integer(n_bad))
}

# a IS DISTINCT FROM b, as an expression. enexpr, not ensym, because some
# rules compare against an expression (year(mcrpcdd), a literal). Each side
# is wrapped in its own parens so a NOT on either side stays inside the
# comparison when the SQL is parsed.
isd <- function(a, b) {
  a <- rlang::call2("(", rlang::enexpr(a))
  b <- rlang::call2("(", rlang::enexpr(b))
  rlang::expr(coalesce(!!a != !!b, TRUE) & !(is.na(!!a) & is.na(!!b)))
}

# The ten analytes reshaped long so the flag/value/date coherence rules are
# written once instead of ten times. LABPLA's date column is LABPLAVDT, not
# LABPLADT - the spec names it that way and the build reproduces it verbatim,
# so it is spelled out here rather than derived from a pattern.
lab_one <- function(analyte, flag, val, dt) {
  flag <- rlang::ensym(flag); val <- rlang::ensym(val); dt <- rlang::ensym(dt)
  ads %>% dplyr::transmute(patid, cohort, indexdt, analyte = !!analyte,
                           flag = !!flag, val = as.numeric(!!val),
                           dt = as.Date(!!dt))
}
lab_long <- Reduce(dplyr::union_all, list(
  lab_one("LABNEU", labneu, labneuv, labneudt),
  lab_one("LABPLA", labpla, labplav, labplavdt),
  lab_one("LABHEM", labhem, labhemv, labhemdt),
  lab_one("LABCRE", labcre, labcrev, labcredt),
  lab_one("LABBIL", labbil, labbilv, labbildt),
  lab_one("LABAST", labast, labastv, labastdt),
  lab_one("LABALT", labalt, labaltv, labaltdt),
  lab_one("LABALP", labalp, labalpv, labalpdt),
  lab_one("LABALB", labalb, labalbv, labalbdt),
  lab_one("LABLYM", lablym, lablymv, lablymdt)))

rules <- list(

  # ---- grain ----------------------------------------------------------------
  # R01: a fan-out silently multiplies every count in every downstream table,
  # and leaves all 190 columns individually legal, so nothing else in the QC
  # pack would notice.
  ads %>% dplyr::summarise(
      n_chk = dplyr::n(),
      n_bad = dplyr::n() - dplyr::n_distinct(paste(patid, cohort, sep = "|"))) %>%
    dplyr::transmute(
      rule = "R01", class = "GATE",
      what = "one row per (patid, cohort) - a case-variant fan-out shows here  (Q72)",
      checked = as.integer(n_chk), failed = as.integer(n_bad)),

  rule_n("R02", "GATE", "indexdt is identical within (patid, cohort)",
         ads %>% dplyr::group_by(patid, cohort) %>%
           dplyr::summarise(n_dt = dplyr::n_distinct(indexdt), .groups = "drop"),
         bad = n_dt > 1L),

  # ---- dates and derived years ----------------------------------------------
  rule_n("R03", "GATE", "indexyr = YEAR(indexdt)",
         ads %>% dplyr::filter(!is.na(indexdt) & !is.na(indexyr)),
         bad = indexyr != year(indexdt)),

  rule_n("R04", "GATE", "indexdt lies within [minindex, maxindex]",
         ads %>% dplyr::filter(!is.na(indexdt)),
         bad = indexdt < minindex | indexdt > maxindex),

  # R05: IS DISTINCT FROM, not != . With != a populated date carrying a NULL
  # year yields NULL, which is never counted - the exact defect this rule
  # exists to catch.
  rule_n("R05", "GATE",
         "mcrpcddyr / mhspcddyr / mpcddyr / inityr each = YEAR(their date)  (Q09)",
         ads,
         bad = (!is.na(mcrpcdd) & !!isd(mcrpcddyr, year(mcrpcdd))) |
               (!is.na(mhspcdd) & !!isd(mhspcddyr, year(mhspcdd))) |
               (!is.na(mpcdd)   & !!isd(mpcddyr,   year(mpcdd)))   |
               (!is.na(init)    & !!isd(inityr,    year(init)))),

  # R06: both milestones are GREATEST(metastatic diagnosis, <milestone>), so
  # neither can precede the metastatic diagnosis date it was built from.
  rule_n("R06", "GATE", "mcrpcdd >= mpcdd and mhspcdd >= mpcdd", ads,
         bad = (!is.na(mcrpcdd) & !is.na(mpcdd) & mcrpcdd < mpcdd) |
               (!is.na(mhspcdd) & !is.na(mpcdd) & mhspcdd < mpcdd)),

  # R07: a patient reaching mCRPC before mHSPC is a source-data ordering
  # problem, not a build problem - REVIEW, not GATE.
  rule_s("R07", "REVIEW", "mcrpcdd >= mhspcdd where both are present", ads,
         chk = !is.na(mcrpcdd) & !is.na(mhspcdd),
         bad = !is.na(mcrpcdd) & !is.na(mhspcdd) & mcrpcdd < mhspcdd),

  # ---- demographics ---------------------------------------------------------
  rule_n("R08", "GATE", "age = indexyr - birthyear",
         ads %>% dplyr::filter(!is.na(age) & !is.na(birthyear) & !is.na(indexyr)),
         bad = age != indexyr - birthyear),

  rule_n("R09", "REVIEW", "age is between 18 and 120",
         ads %>% dplyr::filter(!is.na(age)),
         bad = age < 18L | age > 120L),

  # R10: prostate cancer, but there is no sex column in the ADS, so the
  # closest available check is that every age sits in the band AGEGR1 claims.
  # 'Unknown' is the approved label for a null or negative age (Q74), so it
  # is a violation only when AGE >= 0 - a real band failure. Counting every
  # 'Unknown' beside a non-null age would fail a build doing exactly what
  # Q74 approves.
  # A null AGE must band as 'Unknown' (Q74), so null ages stay in scope; the
  # first limb catches one banded anywhere else.
  rule_n("R10", "GATE", "agegr1 band contains age; null age is Unknown (Q74)",
         ads %>% dplyr::filter(!is.na(agegr1)),
         bad = (is.na(age)          & agegr1 != "Unknown")     |
               (agegr1 == "0-18"    & !between(age, 0L, 18L))  |
               (agegr1 == "19-34"   & !between(age, 19L, 34L)) |
               (agegr1 == "35-49"   & !between(age, 35L, 49L)) |
               (agegr1 == "50-64"   & !between(age, 50L, 64L)) |
               (agegr1 == "65-74"   & !between(age, 65L, 74L)) |
               (agegr1 == "75-84"   & !between(age, 75L, 84L)) |
               (agegr1 == ">=85"    & !(age >= 85L))           |
               (agegr1 == "Unknown" & age >= 0L)),

  # ---- follow-up and death --------------------------------------------------
  rule_n("R11", "GATE", "dthfl = 1 exactly when dthdt is present",
         ads %>% dplyr::filter(!is.na(dthfl)),
         bad = (dthfl == 1L) != (!is.na(dthdt))),

  # R12: spec errata E1 reads inverted; the build floors FUED at the index
  # date. This proves the corrected direction is in the delivered table.
  rule_n("R12", "GATE",
         "fued >= indexdt  (Q45, errata E1 - the CORRECTED direction)",
         ads %>% dplyr::filter(!is.na(fued) & !is.na(indexdt)),
         bad = fued < indexdt),

  rule_n("R13", "GATE", "fudur = DATEDIFF(fued, indexdt) + 1",
         ads %>% dplyr::filter(!is.na(fudur) & !is.na(fued) & !is.na(indexdt)),
         bad = fudur != datediff(fued, indexdt) + 1L),

  rule_n("R14", "GATE", "dth_before_fued = 1 exactly when dthdt < fued",
         ads %>% dplyr::filter(!is.na(dth_before_fued)) %>%
           dplyr::mutate(expect = dplyr::case_when(
             !is.na(dthdt) & !is.na(fued) & dthdt < fued ~ 1L, TRUE ~ 0L)),
         bad = dth_before_fued != expect),

  # R15: register Q57. DTHFUFL's only null rule is "no death date". The spec
  # defines Values "0 = No; 1 = Yes" with "else 0" - there is no third state,
  # so a NULL for any other reason is a defect.
  rule_n("R15", "GATE",
         "dthfufl is NULL exactly when there is no death date  (Q57)", ads,
         bad = is.na(dthfufl) != is.na(death_dt_preliminary)),

  rule_s("R15b", "GATE", "dthfufl domain is {0,1} - the spec Values list  (Q57)",
         ads,
         chk = !is.na(dthfufl),
         bad = !is.na(dthfufl) & !(dthfufl %in% c(0L, 1L))),

  rule_s("R16", "GATE",
         "dthfufl = 1 exactly when DATEDIFF(death_prelim, fu_end_prelim) <= 120  (Q57)",
         ads %>% dplyr::mutate(expect = dplyr::case_when(
           datediff(death_dt_preliminary, fu_enddt_preliminary) <= 120L ~ 1L,
           TRUE ~ 0L)),
         chk = !is.na(dthfufl),
         bad = !is.na(dthfufl) & dthfufl != expect),

  rule_n("R17", "GATE",
         "id3mosfu = 1 exactly when DATEDIFF(maxindex, indexdt) >= 91",
         ads %>% dplyr::filter(!is.na(id3mosfu) & !is.na(indexdt) &
                               !is.na(maxindex)) %>%
           dplyr::mutate(expect = dplyr::case_when(
             datediff(maxindex, indexdt) >= 91L ~ 1L, TRUE ~ 0L)),
         bad = id3mosfu != expect),

  # ---- outcomes -------------------------------------------------------------
  # R18: OS recomputed exactly as 6.Outcomes defines it, including the
  # DTH_BEFORE_FUED exclusion. A 1e-6 tolerance covers double rounding only.
  rule_s("R18", "GATE",
         "os = (DATEDIFF(event_dt, indexdt)+1)/30.4375, from DTHDT not DEATH_DT_prelim  (Q47)",
         ads %>% dplyr::mutate(event_dt = dplyr::case_when(
           dthfl == 1L ~ dthdt, TRUE ~ fued)),
         chk = !is.na(os),
         bad = !is.na(os) &
               abs(os - (datediff(event_dt, indexdt) + 1L) / 30.4375) > 1e-6),

  rule_s("R18b", "GATE", "os is POPULATED whenever dth_before_fued = 0", ads,
         chk = dth_before_fued == 0L,
         bad = dth_before_fued == 0L & is.na(os)),

  rule_s("R19", "GATE", "os is NULL whenever dth_before_fued = 1", ads,
         chk = dth_before_fued == 1L,
         bad = dth_before_fued == 1L & !is.na(os)),

  # R20-R22: cohort applicability. The spec restricts three outcome blocks by
  # cohort, and each restriction is a place a case_when branch can be dropped
  # without any individual value looking wrong.
  rule_s("R20", "GATE",
         "eligpfs / pfsfl / pfsdt / pfs are all NULL in cohorts 1-2", ads,
         chk = cohortn %in% c(1L, 2L),
         bad = cohortn %in% c(1L, 2L) &
               (!is.na(eligpfs) | !is.na(pfsfl) |
                !is.na(pfsdt) | !is.na(pfs))),

  rule_s("R21", "GATE", "ttnt is NULL in cohorts 1, 2 and 7", ads,
         chk = cohortn %in% c(1L, 2L, 7L),
         bad = cohortn %in% c(1L, 2L, 7L) & !is.na(ttnt)),

  rule_s("R22", "GATE", "vis120 is NULL in cohorts 1-2", ads,
         chk = cohortn %in% c(1L, 2L),
         bad = cohortn %in% c(1L, 2L) & !is.na(vis120)),

  # R23: PFSDT is the event date only; it is never set to a censoring date.
  # So it may be null while PFS is populated, but it must never precede index.
  rule_s("R23", "GATE", "pfsdt >= indexdt where present", ads,
         chk = !is.na(pfsdt),
         bad = !is.na(pfsdt) & pfsdt < indexdt),

  # R24: COALESCE before comparing - within eligpfs = 1 the spec leaves no
  # branch that returns a NULL flag, so a NULL pfsfl is itself a defect.
  # Written as `(pfsfl = 1) <> ...` the comparison yields NULL and the row
  # escapes counting.
  rule_s("R24", "GATE",
         "pfsfl = 1 exactly when pfsdt is present, within eligpfs = 1", ads,
         chk = eligpfs == 1L,
         bad = eligpfs == 1L &
               !!isd(coalesce(pfsfl == 1L, FALSE), !is.na(pfsdt))),

  rule_s("R24b", "GATE", "pfsfl is never NULL within eligpfs = 1", ads,
         chk = eligpfs == 1L,
         bad = eligpfs == 1L & is.na(pfsfl)),

  # R25/R26: register Q59, the PSABL > 0 guard. Recomputed with the guard in
  # place, so it confirms the guard is doing what Q59 concluded rather than
  # assuming it. R27 reports how many rows the guard touches on each cut.
  rule_n("R25", "GATE",
         "psa50_6mo = Y exactly when psabl > 0 and decline >= 50%  (Q59; missing input -> N per Q35)",
         ads %>% dplyr::filter(!is.na(psa50_6mo)) %>%
           dplyr::mutate(expect = dplyr::case_when(
             !is.na(psa6mo) & !is.na(psa_index) & psa_index > 0 &
               (psa6mo - psa_index) / psa_index <= -0.5 ~ "Y",
             TRUE ~ "N")),
         bad = psa50_6mo != expect),

  rule_n("R26", "GATE",
         "psa50_12mo = Y exactly when psabl > 0 and decline >= 50%  (Q59; missing input -> N per Q35)",
         ads %>% dplyr::filter(!is.na(psa50_12mo)) %>%
           dplyr::mutate(expect = dplyr::case_when(
             !is.na(psa12mo) & !is.na(psa_index) & psa_index > 0 &
               (psa12mo - psa_index) / psa_index <= -0.5 ~ "Y",
             TRUE ~ "N")),
         bad = psa50_12mo != expect),

  rule_s("R27", "REVIEW",
         "psa_index (PSABL) <= 0 - the rows the Q59 guard forces to N", ads,
         chk = !is.na(psa_index),
         bad = psa_index <= 0),

  # ---- vitals ---------------------------------------------------------------
  rule_s("R28", "GATE", "bmi = weight / (height/100)^2", ads,
         chk = !is.na(bmi),
         bad = !is.na(bmi) & !is.na(weight) & !is.na(height) &
               abs(bmi - weight / (height / 100)^2) > 1e-6),

  # R29: Q68 admits non-positive height and weight readings. Keep this test
  # in step with the production BMI guard, which is `height <> 0` and nothing
  # else - asserting height > 0 AND weight > 0 here would fail every row
  # with a negative reading that production accepts.
  rule_n("R29", "GATE",
         "bmi is present exactly when height and weight are known and height is not zero  (Q68)",
         ads,
         bad = (!is.na(bmi)) !=
               (!is.na(weight) & !is.na(height) & height != 0)),

  # R56: the spec bands every BMI below 18.5 as Underweight, with no lower
  # bound, so a negative BMI bands as Underweight, never 'Missing'. 'Missing'
  # means BMI could not be computed, and nothing else.
  rule_s("R56", "GATE",
         "every non-null bmi below 18.5 is banded Underweight  (Q68)", ads,
         chk = !is.na(bmi),
         bad = !is.na(bmi) & bmi < 18.5 &
               (bmigr1 != "Underweight" | bmigr1n != 1L)),

  rule_n("R30", "GATE",
         "bp = Present exactly when bpsys, bpdia and bpdt are all present",
         ads %>% dplyr::filter(!is.na(bp)),
         bad = (bp == "Present") !=
               (!is.na(bpsys) & !is.na(bpdia) & !is.na(bpdt))),

  rule_s("R31", "GATE", "bpdt <= indexdt  (BP is a PRE_INT baseline variable)",
         ads,
         chk = !is.na(bpdt),
         bad = !is.na(bpdt) & bpdt > indexdt),

  rule_s("R32", "REVIEW", "bpsys > bpdia where both present", ads,
         chk = !is.na(bpsys) & !is.na(bpdia),
         bad = !is.na(bpsys) & !is.na(bpdia) & bpsys <= bpdia),

  # ---- labs -----------------------------------------------------------------
  rule_n("R33", "GATE", "lab flag = Present exactly when its value is populated",
         lab_long %>% dplyr::filter(!is.na(flag)),
         bad = (flag == "Present") != (!is.na(val))),

  rule_n("R34", "GATE",
         "lab value and lab date are populated together  (Q12 - LAB*DT is a DATE, not a value)",
         lab_long,
         bad = (!is.na(val)) != (!is.na(dt))),

  # R35: register Q58 moved only the Missing test; the value window is
  # unchanged. A lab date after index means the wrong filter was removed.
  rule_s("R35", "GATE",
         "lab date <= indexdt  (Q58 moved the Missing test, NOT the value)",
         lab_long,
         chk = !is.na(dt),
         bad = !is.na(dt) & dt > indexdt),

  rule_s("R36", "GATE", "lab value > 0 where Present  (the spec Present criterion)",
         lab_long,
         chk = !is.na(val),
         bad = !is.na(val) & val <= 0),

  rule_n("R37", "GATE", "lab flag is one of Present / Unknown / Missing",
         lab_long %>% dplyr::filter(!is.na(flag)),
         bad = !(flag %in% c("Present", "Unknown", "Missing"))),

  # ---- lines of therapy -----------------------------------------------------
  # R38: covers both settings, not the four mCRPC lines alone. LOTnED feeds
  # VIS120 and the follow-up end, so a reversed pair is not cosmetic.
  rule_n("R38", "GATE", "lotNsd <= lotNed within every line, both settings", ads,
         bad = (!is.na(lot1sd_mcrpc) & !is.na(lot1ed_mcrpc) & lot1sd_mcrpc > lot1ed_mcrpc) |
               (!is.na(lot2sd_mcrpc) & !is.na(lot2ed_mcrpc) & lot2sd_mcrpc > lot2ed_mcrpc) |
               (!is.na(lot3sd_mcrpc) & !is.na(lot3ed_mcrpc) & lot3sd_mcrpc > lot3ed_mcrpc) |
               (!is.na(lot4sd_mcrpc) & !is.na(lot4ed_mcrpc) & lot4sd_mcrpc > lot4ed_mcrpc) |
               (!is.na(lot1sd_mhspc) & !is.na(lot1ed_mhspc) & lot1sd_mhspc > lot1ed_mhspc) |
               (!is.na(lot2sd_mhspc) & !is.na(lot2ed_mhspc) & lot2sd_mhspc > lot2ed_mhspc)),

  # R39: strictly increasing, so an equal pair is a violation too: two lines
  # sharing a start date is exactly what NEW_LOT_N is non-deterministic on.
  # Gate B1 stops that at source; this rule proves it from the extract.
  rule_n("R39", "GATE",
         "line start dates strictly increasing by line number, both settings", ads,
         bad = (!is.na(lot2sd_mcrpc) & !is.na(lot1sd_mcrpc) & lot2sd_mcrpc <= lot1sd_mcrpc) |
               (!is.na(lot3sd_mcrpc) & !is.na(lot2sd_mcrpc) & lot3sd_mcrpc <= lot2sd_mcrpc) |
               (!is.na(lot4sd_mcrpc) & !is.na(lot3sd_mcrpc) & lot4sd_mcrpc <= lot3sd_mcrpc) |
               (!is.na(lot2sd_mhspc) & !is.na(lot1sd_mhspc) & lot2sd_mhspc <= lot1sd_mhspc)),

  # R40/R41: line existence is tested on the start date, not the name. Q73
  # accepts a line that exists with a null LINENAME, so testing the name
  # columns would read an unnamed line 1 followed by a named line 2 as a gap
  # and fail behaviour the register approves.
  rule_n("R40", "GATE",
         "no gaps: line N exists implies line N-1 exists (mCRPC)  (Q73)", ads,
         bad = (!is.na(lot2sd_mcrpc) & is.na(lot1sd_mcrpc)) |
               (!is.na(lot3sd_mcrpc) & is.na(lot2sd_mcrpc)) |
               (!is.na(lot4sd_mcrpc) & is.na(lot3sd_mcrpc))),

  rule_n("R41", "GATE", "mHSPC line 2 exists implies line 1 exists  (Q73)", ads,
         bad = !is.na(lot2sd_mhspc) & is.na(lot1sd_mhspc)),

  # R42/R43: the ADS displays the first LEAST(count, 4 or 2) lines, so the
  # displayed total must EQUAL that - below it, a delivered line was dropped.
  # Line existence is the START DATE, not the name: under Q73 a line can
  # exist with a NULL LINENAME.
  rule_s("R42", "GATE", "displayed mCRPC lines = LEAST(lotn, 4)  (Q73)",
         ads,
         chk = !is.na(lotn),
         bad = !is.na(lotn) &
               (dplyr::case_when(!is.na(lot1sd_mcrpc) ~ 1L, TRUE ~ 0L) +
                dplyr::case_when(!is.na(lot2sd_mcrpc) ~ 1L, TRUE ~ 0L) +
                dplyr::case_when(!is.na(lot3sd_mcrpc) ~ 1L, TRUE ~ 0L) +
                dplyr::case_when(!is.na(lot4sd_mcrpc) ~ 1L, TRUE ~ 0L))
               != pmin(lotn, 4L, na.rm = TRUE)),

  rule_s("R43", "GATE",
         "displayed mHSPC lines = LEAST(lotn_mhspc, 2)  (Q06, Q73)", ads,
         chk = !is.na(lotn_mhspc),
         bad = !is.na(lotn_mhspc) &
               (dplyr::case_when(!is.na(lot1sd_mhspc) ~ 1L, TRUE ~ 0L) +
                dplyr::case_when(!is.na(lot2sd_mhspc) ~ 1L, TRUE ~ 0L))
               != pmin(lotn_mhspc, 2L, na.rm = TRUE)),

  # ---- cohort identity ------------------------------------------------------
  # R44: register Q11/Q19 and errata E12. Cohorts 3-7 are line-of-therapy
  # cohorts, so every patient in them is treated by construction. An
  # "Untreated" label there means the treated-status join lost rows.
  rule_s("R44", "GATE", "cohorts 3-7 are all Treated  (Q11/Q19, errata E12)",
         ads,
         chk = between(cohortn, 3L, 7L),
         bad = between(cohortn, 3L, 7L) & !str_like(cohortu, "Treated%")),

  rule_n("R45", "GATE", "cohortu setting matches the cohort setting", ads,
         bad = (cohortn %in% c(1L, 3L) & !str_like(cohortu, "%mHSPC")) |
               (cohortn %in% c(2L, 4L, 5L, 6L, 7L) &
                !str_like(cohortu, "%mCRPC"))),

  # R46: the second term charges one violation when any of the seven cohorts
  # is absent entirely.
  ads %>% dplyr::summarise(
      n_chk = dplyr::n(),
      n_bad = sum(dplyr::case_when(!between(cohortn, 1L, 7L) ~ 1L, TRUE ~ 0L),
                  na.rm = TRUE) +
              dplyr::case_when(dplyr::n_distinct(cohortn) != 7L ~ 1L,
                               TRUE ~ 0L)) %>%
    dplyr::transmute(
      rule = "R46", class = "GATE",
      what = "cohortn is 1..7 and every one of the seven is present",
      checked = as.integer(n_chk), failed = as.integer(n_bad)),

  # R47: the 99 residual sentinels (register Q50). Only COHORTUN 99 is
  # documented unreachable, so only it gates. AGEGR1N / REGION1N / PRACTICN /
  # STAGEN 99 are reachable by design - a missing birthyear, a state in no
  # census region, no practice record, no GROUPSTAGE recorded. Gating all
  # five would fail the run on STAGEN for every patient without a recorded
  # stage. R47b reports the reachable four.
  rule_n("R47", "GATE",
         "cohortun = 99 is never reached  (Q50 - documented unreachable)", ads,
         bad = cohortun == 99L),

  rule_n("R47b", "REVIEW",
         "reachable 99 sentinels: agegr1n / region1n / practicn / stagen  (Q50, Q31, Q32)",
         ads,
         bad = agegr1n == 99L | region1n == 99L |
               practicn == 99L | stagen == 99L),

  # ---- ECOG -----------------------------------------------------------------
  # R48: register Q23 - six categories, ECOGN 1..6, with unknown and missing
  # combined into a single level. A seven-category split is the regression
  # this rule exists to catch.
  rule_n("R48", "GATE",
         "ecog is one of 0,1,2,3,4,Unknown/Missing and ecogn is 1..6  (Q23, Q71)",
         ads,
         bad = !(ecog %in% c("0", "1", "2", "3", "4", "Unknown/Missing")) |
               !between(ecogn, 1L, 6L)),

  rule_n("R49", "GATE",
         "ecog is never NULL - absence is the Unknown/Missing level  (Q23)",
         ads,
         bad = is.na(ecog) | is.na(ecogn)),

  # R55: Q73 - a line that exists with a null LINENAME lands in the same
  # place as a line that does not exist: null name, category 17 "No
  # treatment". In cohorts 3-7 the index line exists by construction, so its
  # own category can never legitimately be "No treatment". Any count here is
  # the gap Q73 describes.
  rule_s("R55", "REVIEW",
         'treated cohorts: the index line is not "No treatment"  (Q73)', ads,
         chk = between(cohortn, 3L, 7L),
         bad = (cohortn == 3L & lot1cat_mhspc == "No treatment") |
               (cohortn == 4L & lot1cat_mcrpc == "No treatment") |
               (cohortn == 5L & lot2cat_mcrpc == "No treatment") |
               (cohortn == 6L & lot3cat_mcrpc == "No treatment") |
               (cohortn == 7L & lot4cat_mcrpc == "No treatment")),

  # R51: register Q33 ruling - dates derived from source records are not
  # clamped to MAXINDEX. REVIEW, not GATE: a non-zero count is expected and
  # is a property of the source, not a defect. It is reported so the
  # delivered consequence of the ruling is visible rather than assumed.
  rule_n("R51", "REVIEW",
         "delivered dates after MAXINDEX - accepted, not clamped  (Q33)", ads,
         bad = fued > maxindex | dthdt > maxindex | psma_scandt > maxindex),

  # R52: Q36 - a line with no end date scores VIS120 = 0, not NULL - the
  # same missing-input-becomes-a-negative-result convention as Q35. R52
  # checks the domain; R52b proves the no-end-date case directly, on the
  # index line for each treated cohort.
  rule_s("R52", "GATE",
         "vis120 is 0 or 1, never NULL, in the treated cohorts  (Q36)", ads,
         chk = between(cohortn, 3L, 7L),
         bad = between(cohortn, 3L, 7L) &
               (is.na(vis120) | !(vis120 %in% c(0L, 1L)))),

  rule_s("R52b", "GATE", "no index-line end date implies vis120 = 0  (Q36)",
         ads %>% dplyr::mutate(no_ed =
           (cohortn == 3L & is.na(lot1ed_mhspc)) |
           (cohortn == 4L & is.na(lot1ed_mcrpc)) |
           (cohortn == 5L & is.na(lot2ed_mcrpc)) |
           (cohortn == 6L & is.na(lot3ed_mcrpc)) |
           (cohortn == 7L & is.na(lot4ed_mcrpc))),
         chk = no_ed,
         bad = no_ed & !!isd(vis120, 0L)),

  # R53: register Q48 ruling - the delivered COHORT labels are the exact
  # strings chosen for the study. A label that drifts breaks every
  # downstream table keyed on it, and nothing else in the pack pins the
  # literal text.
  rule_n("R53", "GATE",
         "cohort labels are exactly the seven agreed strings  (Q48)", ads,
         bad = !(cohort %in% c("Overall mHSPC", "Overall mCRPC",
                               "L1+ treated mHSPC", "L1+ treated mCRPC",
                               "L2+ treated mCRPC", "L3+ treated mCRPC",
                               "L4+ treated mCRPC"))),

  # R54: register Q69 ruling - the unit filter compares trimmed values. If
  # the trim were lost, LABHEM would read Missing for the entire study and
  # LABHEMV would be wholly NULL. failed = every row then, else 0.
  ads %>% dplyr::summarise(
      n_chk = dplyr::n(),
      n_present = sum(dplyr::case_when(labhem == "Present" ~ 1L, TRUE ~ 0L),
                      na.rm = TRUE)) %>%
    dplyr::transmute(
      rule = "R54", class = "GATE",
      what = "labhem is not uniformly Missing - the unit filter matches  (Q69)",
      checked = as.integer(n_chk),
      failed  = as.integer(dplyr::case_when(n_present == 0L ~ n_chk,
                                            TRUE ~ 0L))),

  # ---- biomarkers -----------------------------------------------------------
  # R50: register Q29/Q30 - HRR and BRCA share one winning date per patient
  # by construction, but no biomarker date is delivered, so the shared-date
  # design is not observable from the ADS and cannot be asserted here; a
  # null-together comparison would also be vacuous, since biomarker_status
  # ends in a case_when TRUE branch and neither column is ever NULL. R50 and
  # R50b test what the extract can prove.
  rule_n("R50", "GATE",
         "hrr_index and brca_index are never NULL  (a dropped join would show here)",
         ads,
         bad = is.na(hrr_index) | is.na(brca_index) |
               is.na(hrr_indexn) | is.na(brca_indexn)),

  # R50b: the observable consequence of the shared date: BRCA1/2 sit inside
  # every HRR panel option, so a BRCA-positive patient must be HRR-positive.
  # Mirrors output-validation V2c deliberately - V2c gates the release, this
  # one lets a partner holding only the extract reach the same verdict.
  rule_s("R50b", "GATE",
         "brca positive implies hrr positive  (Q29/Q37, mirrors V2c)", ads,
         chk = brca_index == "Positive",
         bad = brca_index == "Positive" & !!isd(hrr_index, "Positive")),

  # R57: sizes Q74 - negative ages delivered as 'Unknown'. R10 passes these
  # deliberately, so this is the count of what the approval covers.
  rule_n("R57", "REVIEW", "negative age delivered as Unknown  (Q74 sizing)",
         ads %>% dplyr::filter(!is.na(age)),
         bad = age < 0L & agegr1 == "Unknown")
)

message("writing qcr_rules_r (", length(rules), " rules)")
createInPersonalSchema(
  Reduce(dplyr::union_all, rules) %>%
    dplyr::mutate(
      pct = round(100.0 * failed / dplyr::na_if(checked, 0L), 4),
      status = dplyr::case_when(class == "REVIEW" ~ "REVIEW",
                                failed == 0L      ~ "PASS",
                                TRUE              ~ "FAIL")),
  "qcr_rules_r", replace = TRUE)

if (exists("qcr_stamp")) qcr_stamp("qc03_cross_variable_rules")

message("DONE - nothing was fetched. Read in the SQL editor:")
message("  SELECT * FROM ", personal_schema, ".qcr_rules_r",
        " ORDER BY CASE WHEN class = 'GATE' AND failed > 0 THEN 0",
        " WHEN failed > 0 THEN 1 ELSE 2 END, rule")
