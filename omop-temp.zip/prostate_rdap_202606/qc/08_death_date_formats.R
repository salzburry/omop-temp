# =============================================================================
# QC 08. DEATH-DATE FORMATS IN R - RUN IN DATABRICKS, NOTHING FETCHED
# =============================================================================
#   Rscript qc/08_death_date_formats.R            (after a build, repo root)
#
# Same queries as qc/08_death_date_formats.sql, written as dplyr. Register
# Q66 (ruled 2026-08-08): 5B.ClinChars r90 describes exactly two DATEOFDEATH
# shapes - month-and-year and year-only - and gives no rule for anything
# else. The build implements the two documented cases and lets everything
# else fall to NULL: spec-literal, ruled deliberately. The cost: a populated
# death date that becomes NULL turns a dead patient into a censored one.
# DTHFL reads 0, OS switches from the death date to FUED, and PFS loses its
# death event. These queries measure that exposure.
#
# Read the results in the SQL editor:
#   qcr_q08a_r  the length distribution over the whole mortality source -
#               a reading, not the closure test (validation/06's oracle is).
#               A 10 is a full YYYY-MM-DD - no imputation needed, the fix is
#               a third branch casting it directly. Anything else is
#               malformed - raise it with the data provider.
#   qcr_q08b_r  the cost, in patients. Anything here is a patient the source
#               says died and the ADS says did not.
#   qcr_q08c_r  the same population's delivered outcome columns, so the
#               effect on OS and PFS is visible rather than inferred.
#   qcr_q08d_r  right length, wrong content - the silent CAST failures the
#               length checks cannot see.
#
# SCOPE: Q08a/Q08d scan the whole mortality source (readings). Q08b/Q08c
# join the delivered table. The closure oracle is validation/06's
# qcr_q66_deaths_r; Q08b is its wrong-length slice. Nonzero Q08d beside a
# zero oracle = malformed rows outside the cohorts.
# =============================================================================

if (!exists("con")) {
  message("no open connection - sourcing validation/00_connect.R")
  source("validation/00_connect.R")
}
stopifnot(exists("con"), exists("personal_schema"), exists("output_table"),
          exists("source_schema"), exists("refresh"))

ads  <- dplyr::tbl(con, dbplyr::in_schema(personal_schema, output_table))
src_ <- function(tb) dplyr::tbl(con, dbplyr::in_schema(
          source_schema, paste0(tb, "_", refresh)))

# =============================================================================
# Q08a. What lengths actually occur?
# =============================================================================
# Runs against the source, so it is valid before a build as well as after.
message("writing qcr_q08a_r")
createInPersonalSchema(
  src_("t_mortality_v2") %>%
    dplyr::mutate(
      n_chars = nchar(dateofdeath),
      shape = dplyr::case_when(
        is.na(dateofdeath) ~ "absent",
        nchar(dateofdeath) == 7L ~
          "YYYY-MM  - spec case 1, imputed to the 15th",
        nchar(dateofdeath) == 4L ~
          "YYYY     - spec case 2, imputed to Jul-15 / Dec-31",
        nchar(dateofdeath) == 10L ~
          "YYYY-MM-DD - NOT in the spec; currently DISCARDED",
        TRUE ~ "UNEXPECTED - malformed; currently DISCARDED")) %>%
    dplyr::group_by(n_chars, shape) %>%
    dplyr::summarise(
      n_rows      = dplyr::n(),
      n_patients  = dplyr::n_distinct(patientid),
      example_min = min(dateofdeath, na.rm = TRUE),
      example_max = max(dateofdeath, na.rm = TRUE),
      .groups = "drop") %>%
    dplyr::arrange(dplyr::desc(n_rows)),
  "qcr_q08a_r", replace = TRUE)

# =============================================================================
# Q08b. Patients the source says died and the ADS says did not
# =============================================================================
# This is the number the ruling asked for. Every row here is a silent
# censoring: a populated dateofdeath that the imputation could not use, so
# DEATH_DT_preliminary is NULL, DTHDT is NULL and DTHFL reads 0.
#
# The oracle's wrong-length slice: ADS-joined, so it reads zero whenever
# validation/06's qcr_q66_deaths_r does. A count above zero is a defect
# with a known cause and fix; its size sets urgency.
message("writing qcr_q08b_r")
createInPersonalSchema(
  # src_dod, not dateofdeath: the ADS has its own dateofdeath column, and an
  # unrenamed join would suffix both.
  ads %>%
    dplyr::inner_join(src_("t_mortality_v2") %>%
                        dplyr::select(patientid, src_dod = dateofdeath),
                      by = c("patid" = "patientid")) %>%
    dplyr::filter(!is.na(src_dod) &
                  !(nchar(src_dod) %in% c(4L, 7L))) %>%
    dplyr::group_by(cohort) %>%
    dplyr::summarise(
      n_rows_affected     = dplyr::n(),
      n_patients_affected = dplyr::n_distinct(patid),
      min_len             = min(nchar(src_dod), na.rm = TRUE),
      max_len             = max(nchar(src_dod), na.rm = TRUE),
      # what the ADS currently says about these patients
      n_reading_alive     = sum(dplyr::case_when(dthfl == 0L ~ 1L, TRUE ~ 0L),
                                na.rm = TRUE),
      n_dthdt_null        = sum(dplyr::case_when(is.na(dthdt) ~ 1L, TRUE ~ 0L),
                                na.rm = TRUE),
      .groups = "drop") %>%
    dplyr::arrange(cohort),
  "qcr_q08b_r", replace = TRUE)

# =============================================================================
# Q08c. What it does to the delivered outcomes
# =============================================================================
# The same population, with the columns the silent censoring actually moves.
# Read OS: it was computed from FUED rather than from a death date, so it is
# the follow-up duration and not survival. Twenty rows is enough to see the
# shape; drop the head(20) if Q08b returns a large number.
message("writing qcr_q08c_r")
createInPersonalSchema(
  ads %>%
    dplyr::inner_join(src_("t_mortality_v2") %>%
                        dplyr::select(patientid, src_dod = dateofdeath),
                      by = c("patid" = "patientid")) %>%
    dplyr::filter(!is.na(src_dod) &
                  !(nchar(src_dod) %in% c(4L, 7L))) %>%
    dplyr::transmute(patid, cohort,
                     source_dateofdeath = src_dod,
                     n_chars = nchar(src_dod),
                     death_dt_preliminary, dthdt, dthfl, dthfufl,
                     fued, os, pfsfl, pfsdt) %>%
    dplyr::arrange(patid, cohort) %>%
    head(20),
  "qcr_q08c_r", replace = TRUE)

# =============================================================================
# Q08d. The other silent-conversion risk: right length, wrong content
# =============================================================================
# A 7-character value is CONCAT'd with '-15' and cast to DATE. If the value
# is seven characters but not YYYY-MM - e.g. '2020-1 ' or '2020/03' - the
# build's TRY_CAST turns it into a silent NULL, which is exactly the
# censoring this file sizes. The length checks
# above cannot see this, because the length is right and only the content is
# wrong. Same for the 4-character branch.
#
# RLIKE and TRY_CAST(... AS DATE) have no dplyr translation (safe_num/safe_int
# cover DOUBLE and INT only), so those predicates go in as raw sql() - the
# same route 00_setup takes for its RLIKE gates.
message("writing qcr_q08d_r")
createInPersonalSchema(
  Reduce(dplyr::union_all, list(
    src_("t_mortality_v2") %>%
      dplyr::filter(nchar(dateofdeath) == 7L) %>%
      dplyr::filter(sql("NOT dateofdeath RLIKE '^[0-9]{4}-[0-9]{2}$'")) %>%
      dplyr::summarise(n_rows = dplyr::n(),
                       n_patients = dplyr::n_distinct(patientid)) %>%
      dplyr::transmute(problem = "malformed 7-char (not YYYY-MM)",
                       n_rows, n_patients),
    src_("t_mortality_v2") %>%
      dplyr::filter(nchar(dateofdeath) == 4L) %>%
      dplyr::filter(sql("NOT dateofdeath RLIKE '^[0-9]{4}$'")) %>%
      dplyr::summarise(n_rows = dplyr::n(),
                       n_patients = dplyr::n_distinct(patientid)) %>%
      dplyr::transmute(problem = "malformed 4-char (not YYYY)",
                       n_rows, n_patients),
    # The imputed month must also be a real one. '2020-13' is seven
    # characters, matches the pattern, and CONCAT('2020-13', '-15') is not a
    # date.
    src_("t_mortality_v2") %>%
      dplyr::filter(nchar(dateofdeath) == 7L) %>%
      dplyr::filter(sql("dateofdeath RLIKE '^[0-9]{4}-[0-9]{2}$'")) %>%
      dplyr::filter(sql("TRY_CAST(CONCAT(dateofdeath, '-15') AS DATE) IS NULL")) %>%
      dplyr::summarise(n_rows = dplyr::n(),
                       n_patients = dplyr::n_distinct(patientid)) %>%
      dplyr::transmute(problem = "7-char with an impossible month",
                       n_rows, n_patients),
    # The 4-character branch's exact-conversion arm, kept for structural
    # symmetry with the 7-character one: on Databricks every regex-valid
    # four-digit year concatenates to a castable date, so this should always
    # read zero - a nonzero here is itself a finding.
    src_("t_mortality_v2") %>%
      dplyr::filter(nchar(dateofdeath) == 4L) %>%
      dplyr::filter(sql("dateofdeath RLIKE '^[0-9]{4}$'")) %>%
      dplyr::filter(sql("TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE) IS NULL")) %>%
      dplyr::summarise(n_rows = dplyr::n(),
                       n_patients = dplyr::n_distinct(patientid)) %>%
      dplyr::transmute(problem = "4-char with an impossible year",
                       n_rows, n_patients)
  )),
  "qcr_q08d_r", replace = TRUE)

if (exists("qcr_stamp")) qcr_stamp("qc08_death_date_formats")

message("DONE - nothing was fetched. Read in the SQL editor:")
for (t in c("qcr_q08a_r", "qcr_q08b_r", "qcr_q08c_r", "qcr_q08d_r"))
  message("  SELECT * FROM ", personal_schema, ".", t)
