# =============================================================================
# QC 06. GOLDEN PATIENTS IN R - END-TO-END TRACE, RUN IN DATABRICKS, NO FETCH
# =============================================================================
#   Rscript qc/06_golden_patients.R               (after a build, repo root)
#
# Same trace as qc/06_golden_patients.sql, written as dplyr. Counts show a
# rule holds across the table; they cannot tell a clinician whether the
# numbers describe a real patient correctly. This picks a few patients whose
# profiles hit the hardest decisions and puts their delivered row next to the
# source records behind it. Sit down with a clinician for an hour.
#
# Patients are picked by profile, never at random, so a re-run after a
# refresh traces the same kind of patient:
#   P1  in all seven cohorts            - the grain and the cohort joins
#   P2  died, DTHFUFL = 0               - Q57, the follow-up flag rule
#   P3  PSABL = 0                       - Q59, the PSA50 guard
#   P4  hemoglobin Unknown, no value    - Q58, touches ~39% of the ADS
#   P5  HRR positive, BRCA negative     - Q29/Q30, the biomarker collision rules
#   P6  ECOG present in a treated cohort- Q56, the [-30,+7] window
#   P7  four mCRPC lines                - the LOT block at full depth
#   P8  untreated mCRPC                 - Q11/Q19, errata E12
#
# One table per SQL statement, in file order. Read them in the SQL editor:
#   qcr_golden_01_r  STEP 1: the picked patients (profile, patid)
#   qcr_golden_02_r  STEP 2: their delivered ADS rows, all 190 columns
#   qcr_golden_03_r  milestones and staging
#   qcr_golden_04_r  lines of therapy, with the DERIVED position
#   qcr_golden_05_r  labs, the ten analytes only
#   qcr_golden_06_r  baseline ECOG (treated cohorts)
#   qcr_golden_07_r  general ECOG
#   qcr_golden_08_r  biomarkers
#   qcr_golden_09_r  PSA
#   qcr_golden_10_r  death
#   qcr_golden_11_r  follow-up sources
#
# The SQL's RUN ORDER - run STEP 1, copy the eight patids, paste them into
# STEP 2 and STEP 3 - disappears here: qcr_golden_01_r is materialized first
# and every later query reads the patids straight back from it. Same
# patients, no paste, still nothing fetched into this session.
# =============================================================================

if (!exists("con")) {
  message("no open connection - sourcing validation/00_connect.R")
  source("validation/00_connect.R")
}
stopifnot(exists("con"), exists("personal_schema"), exists("output_table"),
          exists("source_schema"), exists("refresh"))

ads  <- dplyr::tbl(con, dbplyr::in_schema(personal_schema, output_table))
src_ <- function(tb) dplyr::tbl(con, dbplyr::in_schema(
          source_schema, paste0(tb, "_", refresh)))

# =============================================================================
# STEP 1. Pick the patients
# =============================================================================
# rn = 1 ordered by patid makes each pick deterministic, same as the SQL's
# ROW_NUMBER() OVER (ORDER BY patid).
pick <- function(tb, profile) {
  tb %>% dbplyr::window_order(patid) %>%
    dplyr::mutate(rn = dplyr::row_number()) %>%
    dplyr::transmute(profile = !!profile, patid, rn)
}

profiles <- Reduce(dplyr::union_all, list(

  # P1 in all seven cohorts - the grain and the cohort joins
  ads %>% dplyr::group_by(patid) %>%
    dplyr::summarise(k = dplyr::n_distinct(cohortn), .groups = "drop") %>%
    dplyr::filter(k == 7L) %>%
    pick("P1 in all seven cohorts"),

  # P2 died, dthfufl = 0 - Q57, the follow-up flag rule
  ads %>% dplyr::filter(dthfl == 1L & dthfufl == 0L) %>%
    pick("P2 died, dthfufl = 0  (Q57)"),

  # P3 psabl = 0 - Q59, the PSA50 guard
  ads %>% dplyr::filter(psa_index == 0) %>%
    pick("P3 psabl = 0  (Q59)"),

  # P4 - under Q58 this reads Unknown rather than Missing. 'Unknown' covers
  # two populations - a patient tested only after index, and a patient with a
  # pre-index record that fails the Present criteria (wrong unit, non-positive
  # value, no testdate). The ADS cannot tell them apart, so neither can this
  # predicate. Use the lab block (qcr_golden_05_r) to see which of the two
  # this patient is - that is the point of the source trace.
  ads %>% dplyr::filter(labhem == "Unknown" & is.na(labhemv)) %>%
    pick("P4 hemoglobin Unknown, no baseline value  (Q58)"),

  # P5 HRR positive, BRCA negative - Q29/Q30, the biomarker collision rules
  ads %>% dplyr::filter(hrr_indexn == 1L & brca_indexn == 2L) %>%
    pick("P5 HRR positive, BRCA negative  (Q29/Q30)"),

  # P6 ECOG present in a treated cohort - Q56, the [-30,+7] window
  ads %>% dplyr::filter(cohortn >= 3L & cohortn <= 7L &
                        ecog != "Unknown/Missing") %>%
    pick("P6 ECOG present in a treated cohort  (Q56)"),

  # P7 four mCRPC lines - the LOT block at full depth
  ads %>% dplyr::filter(!is.na(lot4_mcrpc)) %>%
    pick("P7 four mCRPC lines"),

  # P8 untreated mCRPC - Q11/Q19, errata E12
  ads %>% dplyr::filter(cohortu == "Untreated mCRPC") %>%
    pick("P8 untreated mCRPC  (Q11/Q19, errata E12)")
))

message("writing qcr_golden_01_r")
createInPersonalSchema(
  profiles %>% dplyr::filter(rn == 1L) %>%
    dplyr::select(profile, patid) %>%
    dplyr::arrange(profile),
  "qcr_golden_01_r", replace = TRUE)

# A profile returning no row is itself a finding. P8 empty would mean no
# patient is ever labelled Untreated mCRPC, which is the exact defect errata
# E12 describes in the spec's own COHORTU pseudo-code. P5 empty would mean the
# HRR and BRCA calls never disagree, which would make one of them redundant.

# The materialized pick doubles as the SQL's paste step: every block below
# reads the patids back from qcr_golden_01_r.
golden_ids <- dplyr::tbl(con,
                dbplyr::in_schema(personal_schema, "qcr_golden_01_r")) %>%
  dplyr::select(patid)

for_gold <- function(tb) {
  dplyr::semi_join(tb, golden_ids, by = c("patientid" = "patid"))
}

# =============================================================================
# STEP 2. The delivered rows, all 190 columns
# =============================================================================
# Read across: this is what ships.
message("writing qcr_golden_02_r")
createInPersonalSchema(
  ads %>% dplyr::semi_join(golden_ids, by = "patid") %>%
    dplyr::arrange(patid, cohortn),
  "qcr_golden_02_r", replace = TRUE)

# =============================================================================
# STEP 3. The source records behind those rows
# =============================================================================
# One block per source table, same patids. Read each block against the
# delivered row above and confirm the derivation by eye.
#
# WHAT TO CHECK IN EACH BLOCK
#   milestones  MHSPCDD / MCRPCDD are GREATEST(metdx, hspcdate / crpcdate).
#               Confirm the delivered date is the later of the two, not the
#               earlier, and that INDEXDT equals it for cohorts 1-2.
#   lines       NEW_LOT_N is derived - it restarts at 1 within each setting,
#               ordered by start date, and is not the source LINENUMBER. For
#               cohorts 3-7, INDEXDT must equal the start date of the line at
#               that derived position.
#   labs        LAB<x>V is the qualifying record closest to index, ties broken
#               by the analyte's own rule. The flag is Present / Unknown /
#               Missing; under Q58 a post-index-only record gives Unknown.
#   ecog        Cohorts 1-2 anchor on the milestone; cohorts 3-7 on the line
#               start, matched on line number and start date, then bounded to
#               [INDEX-30, INDEX+7]. Closest to index wins, then highest value.
#   biomarker   One winning date per patient, chosen over all biomarker tests
#               before either gene set is applied - that is why HRR and BRCA
#               always share a date (Q29/Q30).
#   psa         PSA_INDEX is the earliest ScoreSerial in [INDEX-14, INDEX],
#               taking the maximum if several land on that earliest day.

# ---- milestones and staging -------------------------------------------------
message("writing qcr_golden_03_r")
createInPersonalSchema(
  src_("t_enh_prostate") %>% for_gold() %>%
    dplyr::select(patientid, metastaticdiagnosisdate, hspcdate, crpcdate,
                  diagnosisdate, groupstage, gleasonscore) %>%
    dplyr::arrange(patientid),
  "qcr_golden_03_r", replace = TRUE)

# ---- lines of therapy, with the DERIVED position ----------------------------
message("writing qcr_golden_04_r")
createInPersonalSchema(
  src_("t_enh_prostate_lot") %>% for_gold() %>%
    dplyr::select(patientid, linesetting, linenumber, linename,
                  startdate, enddate) %>%
    dbplyr::window_order(startdate) %>%
    dplyr::group_by(patientid, linesetting) %>%
    dplyr::mutate(new_lot_n = dplyr::row_number()) %>%
    dplyr::ungroup() %>%
    dplyr::arrange(patientid, linesetting, startdate),
  "qcr_golden_04_r", replace = TRUE)

# ---- labs, the ten analytes only --------------------------------------------
message("writing qcr_golden_05_r")
createInPersonalSchema(
  src_("t_lab") %>% for_gold() %>%
    dplyr::filter(tolower(testbasename) %in%
                  c("neutrophils", "platelets", "hemoglobin",
                    "creatinine", "bilirubin",
                    "aspartate aminotransferase",
                    "alanine aminotransferase",
                    "alkaline phosphatase", "albumin", "lymphocytes")) %>%
    dplyr::transmute(patientid, testbasename, labcomponent, testdate,
                     resultdate,
                     derived_labdate = pmax(testdate, resultdate,
                                            na.rm = TRUE),
                     testresultcleaned, testunitscleaned) %>%
    dplyr::arrange(patientid, testbasename, derived_labdate),
  "qcr_golden_05_r", replace = TRUE)

# ---- baseline ECOG (treated cohorts) ----------------------------------------
message("writing qcr_golden_06_r")
createInPersonalSchema(
  src_("t_enh_prostate_bsln_ecog") %>% for_gold() %>%
    dplyr::select(patientid, linenumber, linestartdate, ecogdate,
                  ecogvalue) %>%
    dplyr::arrange(patientid, linestartdate, ecogdate),
  "qcr_golden_06_r", replace = TRUE)

# ---- general ECOG -----------------------------------------------------------
message("writing qcr_golden_07_r")
createInPersonalSchema(
  src_("t_ecog") %>% for_gold() %>%
    dplyr::select(patientid, ecogdate, ecogvalue) %>%
    dplyr::arrange(patientid, ecogdate),
  "qcr_golden_07_r", replace = TRUE)

# ---- biomarkers -------------------------------------------------------------
# Column names per validation/00_input_contract.csv: BIOMARKERNAME (not
# genename) and BIOMARKERSTATUS. There is no test-type column on this table,
# which is why register Q03 hard-codes HRR_INDEX_TEST and BRCA_INDEX_TEST to
# 'Unknown'.
message("writing qcr_golden_08_r")
createInPersonalSchema(
  src_("t_enh_prostate_biomarker") %>% for_gold() %>%
    dplyr::transmute(patientid, biomarkername, specimencollecteddate,
                     resultdate,
                     derived_biomarker_dt = pmax(specimencollecteddate,
                                                 resultdate, na.rm = TRUE),
                     biomarkerstatus) %>%
    dplyr::arrange(patientid, derived_biomarker_dt),
  "qcr_golden_08_r", replace = TRUE)

# ---- PSA --------------------------------------------------------------------
message("writing qcr_golden_09_r")
createInPersonalSchema(
  src_("t_enh_prostate_psa") %>% for_gold() %>%
    dplyr::select(patientid, resultdate, scoreserial) %>%
    dplyr::arrange(patientid, resultdate),
  "qcr_golden_09_r", replace = TRUE)

# ---- death ------------------------------------------------------------------
# dateofdeath is month- or year-level. Confirm the imputation the build
# applied (5B.ClinChars rows 90-93) by comparing DATEOFDEATH,
# DEATH_DT_preliminary and DTHDT on the delivered row.
message("writing qcr_golden_10_r")
createInPersonalSchema(
  src_("t_mortality_v2") %>% for_gold() %>%
    dplyr::transmute(patientid, dateofdeath,
                     granularity_chars = nchar(dateofdeath)),
  "qcr_golden_10_r", replace = TRUE)

# ---- follow-up sources ------------------------------------------------------
# FU_ENDDT_preliminary is the latest of exactly four sources: last visit, last
# telemedicine, last line end, last oral end (5B.ClinChars row 89). Unlike the
# 202603 cut, 202606 does not fold in alpha/beta emitters or Provenge, so
# follow-up ends can differ between cuts without being defects.
message("writing qcr_golden_11_r")
createInPersonalSchema(
  Reduce(dplyr::union_all, list(
    src_("t_visit") %>% for_gold() %>%
      dplyr::group_by(patientid) %>%
      dplyr::summarise(last_dt = max(visitdate, na.rm = TRUE),
                       .groups = "drop") %>%
      dplyr::transmute(src = "1 visit", patientid, last_dt),
    src_("t_telemedicine") %>% for_gold() %>%
      dplyr::group_by(patientid) %>%
      dplyr::summarise(last_dt = max(visitdate, na.rm = TRUE),
                       .groups = "drop") %>%
      dplyr::transmute(src = "2 telemedicine", patientid, last_dt),
    src_("t_enh_prostate_lot") %>% for_gold() %>%
      dplyr::group_by(patientid) %>%
      dplyr::summarise(last_dt = max(enddate, na.rm = TRUE),
                       .groups = "drop") %>%
      dplyr::transmute(src = "3 line end", patientid, last_dt),
    # Production drops oral rows whose end date is year-granular
    # (5B.ClinChars r89) and ignores null ends. Without those filters this
    # block reports a later date than the build used, and the trace looks
    # wrong when it is not.
    src_("t_enh_prostate_orals") %>% for_gold() %>%
      dplyr::filter(!is.na(enddate) &
                    tolower(coalesce(startdategranularity, "")) != "year") %>%
      dplyr::group_by(patientid) %>%
      dplyr::summarise(last_dt = max(enddate, na.rm = TRUE),
                       .groups = "drop") %>%
      dplyr::transmute(src = "4 oral end", patientid, last_dt)
  )) %>%
    dplyr::arrange(patientid, src),
  "qcr_golden_11_r", replace = TRUE)

if (exists("qcr_stamp")) qcr_stamp("qc06_golden_patients")

message("DONE - nothing was fetched. Read in the SQL editor:")
for (t in sprintf("qcr_golden_%02d_r", 1:11))
  message("  SELECT * FROM ", personal_schema, ".", t)
