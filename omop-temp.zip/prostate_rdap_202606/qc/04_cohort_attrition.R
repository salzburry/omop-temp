# =============================================================================
# QC 04. COHORT ATTRITION WATERFALL IN R - RUN IN DATABRICKS, NOTHING FETCHED
# =============================================================================
#   Rscript qc/04_cohort_attrition.R              (after a build, repo root)
#
# Same waterfall as qc/04_cohort_attrition.sql, written as dplyr. Every step
# runs inside Databricks and lands in the personal schema with
# createInPersonalSchema - the build's own write path. Nothing is fetched.
#
# Read the results in the SQL editor:
#   qcr_attrition_r       the waterfall. Read n_patients down each cohort
#                         block; every drop should have a stated cause in
#                         `step`. The last two rows of each block must agree:
#                         `eligible at source` and `delivered in ADS`.
#                         pct_of_previous exposes an unintended near-total
#                         filter - a step that removes 99% is either wrong or
#                         belongs in the release note.
#   qcr_attrition_gate_r  the one gate: eligible at source must equal
#                         delivered rows, per cohort. Every row must read
#                         PASS. There is no filter between the two - a
#                         difference means rows were lost or duplicated
#                         inside the build.
#
# The SQL runs as two statements and re-derives its ms/lot CTEs in each; here
# the shared derivations are built once and both outputs read them.
# =============================================================================

if (!exists("con")) {
  message("no open connection - sourcing validation/00_connect.R")
  source("validation/00_connect.R")
}
stopifnot(exists("con"), exists("personal_schema"), exists("output_table"),
          exists("source_schema"), exists("refresh"))

ads  <- dplyr::tbl(con, dbplyr::in_schema(personal_schema, output_table))
src_ <- function(tb) dplyr::tbl(con, dbplyr::in_schema(
          source_schema, paste0(tb, "_", refresh)))

IDX_LO <- as.Date("2011-01-01")
IDX_HI <- as.Date("2026-04-30")

# ---- shared derivations -----------------------------------------------------
# GREATEST skips NULLs in Spark; pmax(na.rm = TRUE) renders exactly that.
ms <- src_("t_enh_prostate") %>%
  dplyr::transmute(
    patientid, metastaticdiagnosisdate, hspcdate, crpcdate,
    mhspcdd = pmax(metastaticdiagnosisdate, hspcdate, na.rm = TRUE),
    mcrpcdd = pmax(metastaticdiagnosisdate, crpcdate, na.rm = TRUE))

# NEW_LOT_N is derived: it restarts at 1 within each setting, ordered by start
# date, and is not the source LINENUMBER. That difference is why register Q06
# and Q52 exist. The window here reproduces the build's exactly.
lot <- src_("t_enh_prostate_lot") %>%
  dplyr::filter(linesetting %in% c("mHSPC", "mCRPC")) %>%
  dplyr::select(patientid, linesetting, startdate) %>%
  dbplyr::window_order(startdate) %>%
  dplyr::group_by(patientid, linesetting) %>%
  dplyr::mutate(new_lot_n = dplyr::row_number()) %>%
  dplyr::ungroup()

# One waterfall row: the distinct patients surviving a step.
src_step <- function(tb, cohort, step_no, step) {
  tb %>% dplyr::summarise(n_patients = dplyr::n_distinct(patientid)) %>%
    dplyr::transmute(cohort = !!cohort, step_no = !!step_no, step = !!step,
                     n_patients)
}
ads_step <- function(tb, cohort, step_no, step) {
  tb %>% dplyr::summarise(n_patients = dplyr::n_distinct(patid)) %>%
    dplyr::transmute(cohort = !!cohort, step_no = !!step_no, step = !!step,
                     n_patients)
}

# Cohort label for a line at a derived position (cohorts 3-7). A NULL
# condition lands on the ELSE, never on NULL - same as the SQL CASE.
lot_label <- function(tb) {
  tb %>% dplyr::mutate(cohort = dplyr::case_when(
    linesetting == "mHSPC" ~ "3 L1+ mHSPC",
    new_lot_n == 1L        ~ "4 L1+ mCRPC",
    new_lot_n == 2L        ~ "5 L2+ mCRPC",
    new_lot_n == 3L        ~ "6 L3+ mCRPC",
    TRUE                   ~ "7 L4+ mCRPC"))
}
lot_step <- function(tb, step_no, step) {
  tb %>% dplyr::group_by(cohort) %>%
    dplyr::summarise(n_patients = dplyr::n_distinct(patientid),
                     .groups = "drop") %>%
    dplyr::transmute(cohort, step_no = !!step_no, step = !!step, n_patients)
}

# Lines at an eligible position in an eligible setting.
lot_in_scope <- lot %>% dplyr::filter(
  (linesetting == "mHSPC" & new_lot_n == 1L) |
  (linesetting == "mCRPC" & new_lot_n >= 1L & new_lot_n <= 4L))

# ... whose start is inside the window and whose patient's own milestone is
# inside the window too - 'eligible at source' for cohorts 3-7, and the
# expected side of the gate below.
lot_elig <- lot_in_scope %>%
  dplyr::inner_join(ms %>% dplyr::select(patientid, mhspcdd, mcrpcdd),
                    by = "patientid") %>%
  dplyr::filter(startdate >= !!IDX_LO & startdate <= !!IDX_HI) %>%
  dplyr::filter(
    (linesetting == "mHSPC" & mhspcdd >= !!IDX_LO & mhspcdd <= !!IDX_HI) |
    (linesetting == "mCRPC" & mcrpcdd >= !!IDX_LO & mcrpcdd <= !!IDX_HI))

# ---- the waterfall ----------------------------------------------------------
steps <- list(

  # ---- shared starting point ----
  src_step(ms, "ALL", 0L, "patients in t_enh_prostate"),
  src_step(ms %>% dplyr::filter(!is.na(metastaticdiagnosisdate)),
           "ALL", 1L, "has a metastatic diagnosis date"),

  # ---- cohort 1, Overall mHSPC ----
  src_step(ms %>% dplyr::filter(!is.na(mhspcdd)),
           "1 Overall mHSPC", 2L, "has an mHSPC milestone (metdx or hspcdate)"),
  src_step(ms %>% dplyr::filter(mhspcdd >= !!IDX_LO & mhspcdd <= !!IDX_HI),
           "1 Overall mHSPC", 3L, "milestone within [2011-01-01, 2026-04-30]"),
  src_step(ms %>% dplyr::filter(mhspcdd >= !!IDX_LO & mhspcdd <= !!IDX_HI),
           "1 Overall mHSPC", 4L, "eligible at source"),
  ads_step(ads %>% dplyr::filter(cohortn == 1L),
           "1 Overall mHSPC", 5L, "delivered in ADS"),

  # ---- cohort 2, Overall mCRPC ----
  src_step(ms %>% dplyr::filter(!is.na(mcrpcdd)),
           "2 Overall mCRPC", 2L, "has an mCRPC milestone (metdx or crpcdate)"),
  src_step(ms %>% dplyr::filter(mcrpcdd >= !!IDX_LO & mcrpcdd <= !!IDX_HI),
           "2 Overall mCRPC", 3L, "milestone within [2011-01-01, 2026-04-30]"),
  src_step(ms %>% dplyr::filter(mcrpcdd >= !!IDX_LO & mcrpcdd <= !!IDX_HI),
           "2 Overall mCRPC", 4L, "eligible at source"),
  ads_step(ads %>% dplyr::filter(cohortn == 2L),
           "2 Overall mCRPC", 5L, "delivered in ADS"),

  # ---- cohorts 3-7, the line-of-therapy cohorts ----
  lot_step(lot_in_scope %>% lot_label(),
           2L, "has a line at this position in this setting"),
  lot_step(lot_in_scope %>%
             dplyr::filter(startdate >= !!IDX_LO & startdate <= !!IDX_HI) %>%
             lot_label(),
           3L, "line start within [2011-01-01, 2026-04-30]"),
  lot_step(lot_elig %>% lot_label(), 4L, "eligible at source"),
  ads %>% dplyr::filter(cohortn >= 3L & cohortn <= 7L) %>%
    dplyr::mutate(cohort = dplyr::case_when(
      cohortn == 3L ~ "3 L1+ mHSPC",
      cohortn == 4L ~ "4 L1+ mCRPC",
      cohortn == 5L ~ "5 L2+ mCRPC",
      cohortn == 6L ~ "6 L3+ mCRPC",
      TRUE          ~ "7 L4+ mCRPC")) %>%
    dplyr::group_by(cohort) %>%
    dplyr::summarise(n_patients = dplyr::n_distinct(patid),
                     .groups = "drop") %>%
    dplyr::transmute(cohort, step_no = 5L, step = "delivered in ADS",
                     n_patients)
)

waterfall <- Reduce(dplyr::union_all, steps) %>%
  dplyr::group_by(cohort) %>%
  dbplyr::window_order(step_no) %>%
  dplyr::mutate(prev_n = dplyr::lag(n_patients)) %>%
  dplyr::ungroup() %>%
  dplyr::transmute(cohort, step_no, step, n_patients,
                   pct_of_previous =
                     round(100 * n_patients / dplyr::na_if(prev_n, 0L), 1)) %>%
  dplyr::arrange(cohort, step_no)

message("writing qcr_attrition_r (", length(steps), " union branches)")
createInPersonalSchema(waterfall, "qcr_attrition_r", replace = TRUE)

# =============================================================================
# THE ONE GATE IN THIS FILE: source eligibility must equal delivered rows
# =============================================================================
# There is no filter between "eligible at source" and the ADS. If these
# differ, rows were lost or duplicated inside the build.
expected <- Reduce(dplyr::union_all, list(
  ms %>% dplyr::filter(mhspcdd >= !!IDX_LO & mhspcdd <= !!IDX_HI) %>%
    dplyr::summarise(n_expected = dplyr::n_distinct(patientid)) %>%
    dplyr::transmute(cohortn = 1L, n_expected),
  ms %>% dplyr::filter(mcrpcdd >= !!IDX_LO & mcrpcdd <= !!IDX_HI) %>%
    dplyr::summarise(n_expected = dplyr::n_distinct(patientid)) %>%
    dplyr::transmute(cohortn = 2L, n_expected),
  lot_elig %>%
    dplyr::mutate(cohortn = dplyr::case_when(
      linesetting == "mHSPC" ~ 3L,
      new_lot_n == 1L        ~ 4L,
      new_lot_n == 2L        ~ 5L,
      new_lot_n == 3L        ~ 6L,
      TRUE                   ~ 7L)) %>%
    dplyr::group_by(cohortn) %>%
    dplyr::summarise(n_expected = dplyr::n_distinct(patientid),
                     .groups = "drop")))

delivered <- ads %>% dplyr::group_by(cohortn) %>%
  dplyr::summarise(n_delivered = dplyr::n_distinct(patid),
                   n_rows      = dplyr::n(), .groups = "drop")

# full_join merges the key: cohortn reads COALESCE(expected, delivered), so a
# cohort present on one side only still shows its number, where the SQL's
# e.cohortn reads NULL for a delivered-only cohort. Same rows either way.
gate <- dplyr::full_join(expected, delivered, by = "cohortn") %>%
  dplyr::transmute(
    cohortn, n_expected, n_delivered, n_rows,
    diff_patients = n_delivered - n_expected,
    extra_rows_beyond_one_per_patient = n_rows - n_delivered,
    status = dplyr::case_when(
      n_delivered == n_expected & n_rows == n_delivered ~ "PASS",
      TRUE ~ "FAIL")) %>%
  dplyr::arrange(cohortn)

message("writing qcr_attrition_gate_r")
createInPersonalSchema(gate, "qcr_attrition_gate_r", replace = TRUE)

if (exists("qcr_stamp")) qcr_stamp("qc04_cohort_attrition")

message("DONE - nothing was fetched. Read in the SQL editor:")
for (t in c("qcr_attrition_r", "qcr_attrition_gate_r"))
  message("  SELECT * FROM ", personal_schema, ".", t)
