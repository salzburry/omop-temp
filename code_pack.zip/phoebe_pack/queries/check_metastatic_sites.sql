-- ============================================================================
-- check_metastatic_sites.sql
--
-- PART A (Optum)    : does the curated site table exist, what is its vocabulary,
--                     rough upper bound among lung-coded patients. Smoke test.
-- PART B (Flatiron) : the SAME question via raw ICD, inside the ACTUAL 2L
--                     docetaxel cohort with an index date. Attrition funnel and
--                     eligible N -- a real feasibility answer, not a smoke test.
--
-- Run Part B first if you only have time for one: it answers what was asked.
--
-- SCOPE: a deployment SMOKE TEST for Optum's curated metastatic-site table --
-- is it there, what is the vocabulary, and a rough upper bound among lung-coded
-- patients. It is NOT Phoebe's feasibility answer: no 2L docetaxel cohort, no
-- index date, no NSCLC/advanced restriction, no lung-primary attribution. Q4 mixes
-- metastatic prevalence, stage mix, capture and missingness -- read it as an
-- upper bound, not a fill rate. Runtime is unverified.
--
-- Run in the Databricks SQL editor against:
--   hive_metastore.clnprw_optum_mc_full_use   (tables *_2025q4)
--
-- This is a FEASIBILITY CHECK, not the extraction. It answers "is it there and
-- how full is it". It does NOT build the 2L docetaxel cohort, attribute sites to
-- the lung primary, or apply an index date. nsclc_lot.R builds the cohort and
-- lines; nsclc_mets_stage.R does site attribution and staging.
--
-- Two things that will bite if forgotten:
--   * ICD codes are stored WITHOUT the decimal point: match 'C34%', never 'C34.%'.
--   * t_diagnosis mixes ICD10, ICD9 and SNOMED in one column. C34 is ICD-10 lung;
--     ICD-9 lung is 162. Q3 counts both so the denominator is not silently ICD-10-only.
-- ============================================================================

-- ############################################################################
-- PART A — OPTUM.  Deployment smoke test for the curated metastatic-site table.
-- ############################################################################

USE hive_metastore.clnprw_optum_mc_full_use;

-- ---------------------------------------------------------------------------
-- Q1. Is the table there, and how big is it?  (whole deployment, all cancers)
-- ---------------------------------------------------------------------------
SELECT COUNT(*)              AS n_rows,
       COUNT(DISTINCT ptid)  AS n_patients,
       MIN(note_date)        AS earliest_note,
       MAX(note_date)        AS latest_note
FROM   t_onc_metastatic_location_2025q4;

-- ---------------------------------------------------------------------------
-- Q2. The site vocabulary, with the negation flag.  This is the "what body
--     part" answer.  'absent' means the note said NO metastasis at that site --
--     information ICD can never carry.  Expect ~12 values from the earlier
--     sample; anything new here must be mapped before counting sites.
-- ---------------------------------------------------------------------------
SELECT metastasis_location,
       mets_qualifier,
       COUNT(*)             AS n_rows,
       COUNT(DISTINCT ptid) AS n_patients
FROM   t_onc_metastatic_location_2025q4
GROUP  BY metastasis_location, mets_qualifier
ORDER  BY n_patients DESC;

-- ---------------------------------------------------------------------------
-- Q3. THE DENOMINATOR: lung-cancer patients who are eligible for the enriched
--     oncology layer at all.  Every t_onc_* table is note-derived and exists only
--     for patients with HAS_NOTES = 'Y', so a lung patient without notes can
--     never have a row here -- that is not missingness, it is the gate.
-- ---------------------------------------------------------------------------
WITH lung AS (
  SELECT DISTINCT ptid
  FROM   t_diagnosis_2025q4
  WHERE  (diagnosis_cd_type = 'ICD10' AND diagnosis_cd LIKE 'C34%')
      OR (diagnosis_cd_type = 'ICD9'  AND diagnosis_cd RLIKE '^162[2-9]')   -- 162.2-162.9 lung; 162.0 is trachea
)
SELECT p.has_notes,
       COUNT(*) AS n_lung_patients
FROM   lung l
JOIN   t_patient_2025q4 p ON p.ptid = l.ptid
GROUP  BY p.has_notes;

-- ---------------------------------------------------------------------------
-- Q4. THE ANSWER: of notes-eligible lung patients, how many have at least one
--     POSITIVE ('actual') metastatic-site row, and how many distinct sites?
--     This is the fill rate for the covariate.  Report it alongside Q3's
--     HAS_NOTES='Y' count -- that is the right denominator.
-- ---------------------------------------------------------------------------
WITH lung AS (
  SELECT DISTINCT ptid
  FROM   t_diagnosis_2025q4
  WHERE  (diagnosis_cd_type = 'ICD10' AND diagnosis_cd LIKE 'C34%')
      OR (diagnosis_cd_type = 'ICD9'  AND diagnosis_cd RLIKE '^162[2-9]')   -- 162.2-162.9 lung; 162.0 is trachea
),
eligible AS (
  SELECT l.ptid
  FROM   lung l
  JOIN   t_patient_2025q4 p ON p.ptid = l.ptid
  WHERE  p.has_notes = 'Y'
),
sites AS (
  SELECT ptid,
         COUNT(DISTINCT metastasis_location) AS n_sites
  FROM   t_onc_metastatic_location_2025q4
  WHERE  mets_qualifier = 'actual'          -- POSITIVES ONLY: 'absent' is a negation
    AND  metastasis_location IS NOT NULL AND TRIM(metastasis_location) <> ''
  GROUP  BY ptid
)
SELECT COUNT(*)                                        AS n_eligible_lung,
       COUNT(s.ptid)                                   AS n_with_any_site,
       ROUND(100.0 * COUNT(s.ptid) / NULLIF(COUNT(*), 0), 1) AS pct_with_any_site,   -- upper bound, not fill rate
       ROUND(AVG(s.n_sites), 2)                        AS mean_sites_among_positive,
       SUM(CASE WHEN s.n_sites >= 3 THEN 1 ELSE 0 END) AS n_with_3plus_sites
FROM   eligible e
LEFT   JOIN sites s ON s.ptid = e.ptid;

-- ---------------------------------------------------------------------------
-- Q5. Which sites, among lung patients specifically.  Compare against Q2: if the
--     lung distribution is dominated by bone / brain / liver / adrenal / pleura
--     it is behaving like NSCLC; if it looks like the all-cancer mix, the lung
--     filter is not biting.  Also shows the current/history split.
-- ---------------------------------------------------------------------------
WITH lung AS (
  SELECT DISTINCT ptid
  FROM   t_diagnosis_2025q4
  WHERE  (diagnosis_cd_type = 'ICD10' AND diagnosis_cd LIKE 'C34%')
      OR (diagnosis_cd_type = 'ICD9'  AND diagnosis_cd RLIKE '^162[2-9]')   -- 162.2-162.9 lung; 162.0 is trachea
)
SELECT m.metastasis_location,
       m.mets_temporal_status,
       COUNT(DISTINCT m.ptid) AS n_lung_patients
FROM   t_onc_metastatic_location_2025q4 m
JOIN   lung l ON l.ptid = m.ptid
WHERE  m.mets_qualifier = 'actual'
GROUP  BY m.metastasis_location, m.mets_temporal_status
ORDER  BY n_lung_patients DESC;

-- ============================================================================
-- HOW TO READ THE RESULT
--   Q3 HAS_NOTES='Y' count  = the most lung patients this field can EVER cover.
--   Q4 pct_with_any_site    = the fill rate. This is the number Phoebe needs.
--   Q5                      = whether the vocabulary is NSCLC-shaped.
--
-- What this does NOT tell you, and must not be read as:
--   * whether a site belongs to the lung primary vs. a second cancer (~70% of
--     staging rows carry no tumour key -- nsclc_mets_stage.R handles attribution)
--   * anything about the 2L docetaxel cohort or any index date
--   * nodal or local spread: this table is DISTANT sites only, by vendor definition
-- ============================================================================


-- ############################################################################
-- PART B — FLATIRON.  Metastatic sites from ICD, in the ACTUAL 2L cohort.
--
-- Flatiron has no curated metastatic-site field, but it does carry raw ICD in
-- t_diagnosis_2026m01 (DiagnosisCode / DiagnosisCodeSystem / DiagnosisDescription
-- — the dictionary's own example row is "Secondary malignant neoplasm of bone
-- and bone marrow"). So the site question IS answerable here, as a proxy.
--
-- Unlike Part A this is NOT a smoke test. Flatiron ships t_lineoftherapy_2026m01
-- with LineNumber and LineName, so the 2L docetaxel cohort and its index date can
-- be built directly — which makes B3–B5 a real feasibility answer: attrition
-- funnel, eligible N, and pre-index site availability per patient.
--
-- Schema: hive_metastore.clnprw_flatiron_nsclc_use   (tables *_2026m01)
--
-- THE TRAP THAT MATTERS: Flatiron stores ICD codes WITH the decimal point
-- ('198.5', 'C79.51'); Optum stores them WITHOUT ('1985', 'C7951'). The same
-- codelist needs different matching on each side. Everything below uses the
-- decimal form. DiagnosisCodeSystem is 'ICD-10-CM' / 'ICD-9-CM' (not 'ICD10').
-- ############################################################################

USE hive_metastore.clnprw_flatiron_nsclc_use;

-- ---------------------------------------------------------------------------
-- B1. Do NOT assume the LineName literal. Find how docetaxel is actually
--     spelled, and whether it appears alone (monotherapy) or in combinations.
--     Everything downstream depends on this string, so look before filtering.
-- ---------------------------------------------------------------------------
SELECT LineName,
       LineNumber,
       COUNT(DISTINCT PatientID) AS n_patients
FROM   t_lineoftherapy_2026m01
WHERE  EnhancedCohort = 'AdvancedNSCLC'
  AND  UPPER(LineName) LIKE '%DOCETAXEL%'
GROUP  BY LineName, LineNumber
ORDER  BY n_patients DESC;

-- ---------------------------------------------------------------------------
-- B2. The secondary-neoplasm vocabulary actually present, with descriptions.
--     Confirms the codes exist and are populated before any cohort filter, and
--     shows which site codes this dataset really uses.
-- ---------------------------------------------------------------------------
SELECT DiagnosisCodeSystem,
       DiagnosisCode,
       MIN(DiagnosisDescription) AS example_description,
       COUNT(*)                  AS n_rows,
       COUNT(DISTINCT PatientID) AS n_patients
FROM   t_diagnosis_2026m01
WHERE  (DiagnosisCodeSystem = 'ICD-10-CM' AND (DiagnosisCode LIKE 'C77%' OR
                                               DiagnosisCode LIKE 'C78%' OR
                                               DiagnosisCode LIKE 'C79%' OR
                                               DiagnosisCode LIKE 'C7B%'))
    OR (DiagnosisCodeSystem = 'ICD-9-CM'  AND (DiagnosisCode LIKE '196%' OR
                                               DiagnosisCode LIKE '197%' OR
                                               DiagnosisCode LIKE '198%'))
GROUP  BY DiagnosisCodeSystem, DiagnosisCode
ORDER  BY n_patients DESC;

-- ---------------------------------------------------------------------------
-- B3. THE ATTRITION FUNNEL.  One row, each step a strict subset of the last.
--     This is the number Phoebe asked for. Adjust the LineName predicate to
--     whatever B1 shows before trusting the last three steps.
-- ---------------------------------------------------------------------------
WITH adv AS (
  SELECT DISTINCT PatientID, AdvancedDiagnosisDate
  FROM   t_enh_advancednsclc_2026m01
),
lot2 AS (          -- 2L segments in the advanced setting
  SELECT PatientID, MIN(StartDate) AS index_date
  FROM   t_lineoftherapy_2026m01
  WHERE  EnhancedCohort = 'AdvancedNSCLC'
    AND  LineNumber = 2
  GROUP  BY PatientID
),
lot2_doce AS (     -- 2L whose line NAME is docetaxel alone => monotherapy
  SELECT PatientID, MIN(StartDate) AS index_date
  FROM   t_lineoftherapy_2026m01
  WHERE  EnhancedCohort = 'AdvancedNSCLC'
    AND  LineNumber = 2
    AND  UPPER(TRIM(LineName)) = 'DOCETAXEL'     -- confirm against B1
  GROUP  BY PatientID
)
SELECT (SELECT COUNT(*)              FROM adv)                       AS s1_advanced_nsclc,
       (SELECT COUNT(*)              FROM lot2)                      AS s2_any_2L,
       (SELECT COUNT(*)              FROM lot2_doce)                 AS s3_2L_docetaxel_mono,
       (SELECT COUNT(*)              FROM lot2_doce d
                                     JOIN adv a ON a.PatientID = d.PatientID
                                    WHERE d.index_date >= a.AdvancedDiagnosisDate)
                                                                     AS s4_index_after_adv_dx;

-- ---------------------------------------------------------------------------
-- B4. SITE AVAILABILITY IN THE COHORT, pre-index, collapsed to canonical
--     compartments. Bone = C79.51 + C79.52 + 198.5 counted ONCE, which is what
--     "number of metastatic sites" means; counting raw codes would inflate it.
--     Sites are counted only from records STRICTLY BEFORE the index date.
-- ---------------------------------------------------------------------------
WITH lot2_doce AS (
  SELECT PatientID, MIN(StartDate) AS index_date
  FROM   t_lineoftherapy_2026m01
  WHERE  EnhancedCohort = 'AdvancedNSCLC'
    AND  LineNumber = 2
    AND  UPPER(TRIM(LineName)) = 'DOCETAXEL'
  GROUP  BY PatientID
),
dx AS (
  SELECT d.PatientID,
         CASE
           WHEN d.DiagnosisCode LIKE 'C79.5%' OR d.DiagnosisCode LIKE '198.5%' THEN 'bone'
           WHEN d.DiagnosisCode LIKE 'C78.7%' OR d.DiagnosisCode LIKE '197.7%' THEN 'liver'
           WHEN d.DiagnosisCode LIKE 'C79.3%' OR d.DiagnosisCode LIKE '198.3%'
             OR d.DiagnosisCode LIKE 'C79.4%' OR d.DiagnosisCode LIKE '198.4%' THEN 'brain_cns'
           WHEN d.DiagnosisCode LIKE 'C78.0%' OR d.DiagnosisCode LIKE '197.0%' THEN 'lung'
           WHEN d.DiagnosisCode LIKE 'C78.2%' OR d.DiagnosisCode LIKE '197.2%' THEN 'pleura'
           WHEN d.DiagnosisCode LIKE 'C79.7%' OR d.DiagnosisCode LIKE '198.7%' THEN 'adrenal'
           WHEN d.DiagnosisCode LIKE 'C78.6%' OR d.DiagnosisCode LIKE '197.6%' THEN 'peritoneum'
           WHEN d.DiagnosisCode LIKE 'C77%'   OR d.DiagnosisCode LIKE '196%'   THEN 'lymph_node'
           WHEN d.DiagnosisCode LIKE 'C79.9%' OR d.DiagnosisCode LIKE '199.0%' THEN NULL  -- site unspecified: not a site
           WHEN d.DiagnosisCode LIKE 'C78%'   OR d.DiagnosisCode LIKE 'C79%'
             OR d.DiagnosisCode LIKE '197%'   OR d.DiagnosisCode LIKE '198%'   THEN 'other_organ'
           ELSE NULL
         END AS site_group,
         d.DiagnosisDate
  FROM   t_diagnosis_2026m01 d
  JOIN   lot2_doce c ON c.PatientID = d.PatientID
  WHERE  d.DiagnosisDate < c.index_date          -- STRICTLY pre-index: no leakage
),
per_pt AS (
  SELECT c.PatientID,
         COUNT(DISTINCT dx.site_group) AS n_met_sites   -- NULL site_group not counted
  FROM   lot2_doce c
  LEFT   JOIN dx ON dx.PatientID = c.PatientID
  GROUP  BY c.PatientID
)
SELECT COUNT(*)                                                   AS n_cohort,
       SUM(CASE WHEN n_met_sites > 0 THEN 1 ELSE 0 END)           AS n_with_any_site,
       ROUND(100.0 * SUM(CASE WHEN n_met_sites > 0 THEN 1 ELSE 0 END)
             / NULLIF(COUNT(*), 0), 1)                            AS pct_with_any_site,
       ROUND(AVG(n_met_sites), 2)                                 AS mean_sites_all,
       SUM(CASE WHEN n_met_sites >= 3 THEN 1 ELSE 0 END)          AS n_with_3plus
FROM   per_pt;

-- ---------------------------------------------------------------------------
-- B5. Which compartments, in the cohort. Sanity check: an advanced-NSCLC 2L
--     population should be dominated by bone, brain, liver, lung, pleura,
--     adrenal. If lymph_node dominates, the C77 codes are pulling in regional
--     nodal disease rather than distant spread -- note that Optum's curated
--     table EXCLUDES nodal involvement by definition, so including C77 here
--     would make the two sources non-comparable. Decide before counting.
-- ---------------------------------------------------------------------------
WITH lot2_doce AS (
  SELECT PatientID, MIN(StartDate) AS index_date
  FROM   t_lineoftherapy_2026m01
  WHERE  EnhancedCohort = 'AdvancedNSCLC'
    AND  LineNumber = 2
    AND  UPPER(TRIM(LineName)) = 'DOCETAXEL'
  GROUP  BY PatientID
)
SELECT CASE
         WHEN d.DiagnosisCode LIKE 'C79.5%' OR d.DiagnosisCode LIKE '198.5%' THEN 'bone'
         WHEN d.DiagnosisCode LIKE 'C78.7%' OR d.DiagnosisCode LIKE '197.7%' THEN 'liver'
         WHEN d.DiagnosisCode LIKE 'C79.3%' OR d.DiagnosisCode LIKE '198.3%'
           OR d.DiagnosisCode LIKE 'C79.4%' OR d.DiagnosisCode LIKE '198.4%' THEN 'brain_cns'
         WHEN d.DiagnosisCode LIKE 'C78.0%' OR d.DiagnosisCode LIKE '197.0%' THEN 'lung'
         WHEN d.DiagnosisCode LIKE 'C78.2%' OR d.DiagnosisCode LIKE '197.2%' THEN 'pleura'
         WHEN d.DiagnosisCode LIKE 'C79.7%' OR d.DiagnosisCode LIKE '198.7%' THEN 'adrenal'
         WHEN d.DiagnosisCode LIKE 'C78.6%' OR d.DiagnosisCode LIKE '197.6%' THEN 'peritoneum'
         WHEN d.DiagnosisCode LIKE 'C77%'   OR d.DiagnosisCode LIKE '196%'   THEN 'lymph_node'
         ELSE 'other_or_unspecified'
       END                        AS site_group,
       COUNT(DISTINCT d.PatientID) AS n_patients
FROM   t_diagnosis_2026m01 d
JOIN   lot2_doce c ON c.PatientID = d.PatientID
WHERE  d.DiagnosisDate < c.index_date
  AND  ((d.DiagnosisCodeSystem = 'ICD-10-CM' AND (d.DiagnosisCode LIKE 'C77%' OR
                                                  d.DiagnosisCode LIKE 'C78%' OR
                                                  d.DiagnosisCode LIKE 'C79%'))
    OR  (d.DiagnosisCodeSystem = 'ICD-9-CM'  AND (d.DiagnosisCode LIKE '196%' OR
                                                  d.DiagnosisCode LIKE '197%' OR
                                                  d.DiagnosisCode LIKE '198%')))
GROUP  BY 1
ORDER  BY n_patients DESC;

-- ############################################################################
-- READING PART B
--   B3 s3 = the eligible 2L docetaxel-monotherapy N. This is Phoebe's number.
--   B4 pct_with_any_site = how many of them have ANY pre-index site coded.
--   B5 = whether the compartment mix looks like advanced NSCLC.
--
-- WHAT IT STILL CANNOT TELL YOU
--   * Absence of a code is not absence of disease. ICD cannot express "no liver
--     metastasis", so a 0 mixes true absence with uncoded disease. This is the
--     one thing Optum's curated mets_qualifier='absent' adds and no ICD proxy
--     can replicate.
--   * No current-vs-history distinction: a site coded once is coded forever.
--   * LineName = 'DOCETAXEL' is Flatiron's own line naming, not our monotherapy
--     predicate. nsclc_lot.R derives monotherapy from the drug episodes; expect
--     the two to disagree and report the disagreement rather than picking one.
--   * Nodal (C77 / 196) is INCLUDED above but is EXCLUDED from Optum's curated
--     table by vendor definition. For a like-for-like comparison, drop it.
-- ############################################################################
