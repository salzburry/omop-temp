# METHODS — engine limitations, provenance, and what has never been run

This file holds the material that used to live as long comment essays inside
`R/nsclc_lot.R` and `R/nsclc_mets_stage.R`. It was moved here rather than deleted:
the substance is load-bearing for the SAP and for anyone reading a number out of
either engine, but it is documentation, not an explanation of the code beneath it.

The code retains only comments that state a **reason, an invariant, or a safety
condition** — the things a reader cannot recover from the code itself.

**Status.** The offline suites run and pass — `audit_defect_tests.R` 21/21, `nm_selftest()` 23/23,
`nl_run_regression()` 35/35. What has **never** run is any query against a warehouse: no
study-specific cohort, feasibility funnel, or engine execution against Flatiron or Optum.

Passages below written before the suites existed say "nothing has been executed". Read that as
**nothing has been executed against the warehouse** — it was accurate when written and the
warehouse half is still true.

---

## 1. `nsclc_lot.R` — purpose and provenance

nsclc_lot.R - Dual line-of-therapy derivation for advanced NSCLC in Optum MC

  LOT-A : Optum's native t_onc_line_of_therapy (IV + procedure-coded only)
  LOT-B : Flatiron's advNSCLC LOT rules replicated on Optum source data

Cohort target: 2L docetaxel MONOTHERAPY, advanced NSCLC. Endpoint rwOS.

Companion files (paths relative to nsclc/Aug_30_2026/):
  extracted_text/lot_ruleset.txt   <- the 27 rules; [Rn] == LOT-nn
  METHODS.md                       <- this file: gaps G1..G14, limits
  response/drug_code_list.csv      <- the drug universe, read at runtime
  tests/lot_regression_cases.csv   <- the 35 fixtures
  ../tests/lot_regression_cases.csv                          <- the 35 fixtures
  ../../optum_mc_reference/precedent/rdq1_cohort1.R          <- the pattern followed

Style follows the RDQ 317023 precedent: dbplyr over ODBC to Databricks, no
Spark. Episodes are pulled lazily then collected per patient; the LOT rules run
in R because they are sequential/stateful and do not express well in SQL.

---------------------------------------------------------------------------
STATUS OF THIS FILE - read before using it
---------------------------------------------------------------------------
1. LOT-B IS NOT A FAITHFUL REPLICATION OF FLATIRON. It is a specification plus
   a set of PRE-SPECIFIED DECISIONS. The adversarial synthetic test
   (METHODS.md) established that 8 of 35 probe patients
   cannot have the cohort-inclusion decision reproduced from the Flatiron
   document at all. Every substituted decision is declared in NL_DECISIONS, is
   READ BY THE CODE (not merely commented), and is swept, so that a patient
   whose answer depends on one is flagged indeterminate, not answered silently.

2. THE STRUCTURAL FINDING THAT DRIVES THE ENGINE. The document states exactly
   ONE affirmative line-advancement mechanism: [R18], the >120-day gap.
   [R13]-[R17] and [R21]-[R23] are all NON-advancement exceptions. Corollary,
   adjudicated on case MNT-07:

      THE LINE NUMBER IS A STATE THAT PERSISTS ABSENT A STATED TRIGGER,
      NOT ONE THAT INCREMENTS ABSENT A STATED EXEMPTION.

   A FAILED maintenance test leaves the line number UNCHANGED.
   nl_flag_maintenance() cannot write to `line` and asserts that it did not.

3. THIS FILE RUNS OFFLINE; IT HAS NEVER TOUCHED THE WAREHOUSE. The engine
   parses, and nl_run_regression() passes all 35 fixtures alongside
   audit_defect_tests.R (21/21) and nm_selftest() (23/23). What has NOT
   happened is any query: no connection, no cohort, no count. So every claim
   about DEPLOYMENT behaviour below is still unverified, and a passing
   synthetic suite says nothing about the data. Note also that 11 of the 25
   registered decisions are exercised by no fixture, so the suite covers the
   fixtures that exist, not the decision space. Any line tagged
   # UNVERIFIED depends on an Optum column or value set not confirmed by a
   live DESCRIBE.

4. NO NDC CODE IS WRITTEN IN THIS FILE, BY DESIGN. NDCs are harvested from the
   deployment by nl_harvest_ndc() and frozen into the CSV by a human.

5. WHAT CHANGED IN THIS REVISION (defect review; every item closes a SILENT
   failure path, none re-specifies a rule):
   a. The sweep is FACTORIAL over the seven determinative decisions
      (G1,G2,G4,G5,G6,G7,G11 = 192 cells). A marginal sweep called GAP-03 and
      MI-03 determinate: no single perturbation flips them, a PAIR does.
   b. D_G7 is genuinely readable - EXCL rows are pulled from the source, the
      filter moved into nl_lot_b(), the no-excluded guard rail made conditional.
   c. R21 collapse runs over the WHOLE LINE, not the 28-day naming window; a
      substitution is by definition mid-line, so it never once fired before.
   d. R23 renaming requires an actual SWITCH (background stopped) in-window; it
      used to fire on additions and delete the rest of the regimen name.
   e. R16's 49-day test is the PAIR's continuation span (adjudicated MNT-07
      arithmetic), not each agent's own last episode.
   f. is_oral is a normalised route predicate, not `route == "oral"`; R19 had
      stopped firing for every real Optum route string.
   g. De-duplication is WITHIN data_source; the day-level collapse moved into
      nl_lot_b() under D_G8, so the narrow build cannot lose an administration
      to a same-day note row.
   h. A post-28-day drug arriving ALONGSIDE a continuing regimen is an addition
      (declared decision D_G1B), not a replacement, so D_G6 is reachable.
   i. R7/R8 adjuvant blocks are scoped to "the given eligible therapy", which
      is what makes MI-07's index-date flip reproducible.
   j. Indeterminacy is enforced in the PIPELINE (three-state cohort_status),
      not only in the test harness.
   k. A sweep branch that ERRORS is fatal; it used to be laundered into "the
      patient is indeterminate".

---

## 2. `nsclc_lot.R` — known-incomplete

10. RUN

---- 0. pre-flight, no database needed -------------------------------------
drugs <- nl_drugs()
nl_assert_drug_list(drugs)               # stem/role lint; names the CSV fixes
nl_assert_rule_version(drugs)            # D_G12
str(nl_role_index(drugs))
nl_run_regression()                      # <- run this FIRST, before any data

---- 1. the deployment -----------------------------------------------------
con <- mc_connect()

# one-time: populate the CSV's code placeholders from the data. Writes a
# SIDECAR (drug_code_list_harvested.csv); a human diffs it and freezes it.
# No NDC is ever written into this source file.
ndc <- nl_harvest_ndc(con, drugs); jc <- nl_harvest_jcodes(con, drugs)
harvested <- nl_populate_codes(drugs, ndc, jc)

# index_dates must come from an advanced-NSCLC date derivation Optum does not
# ship (R5 / decision D_INDEX_DATE). RUN BOTH DEFINITIONS - MI-07 shows a
# 21-day surrogate shift flipping docetaxel from 2L to 1L.
eps_n <- nl_episodes(con, drugs, ptids = cohort_ptids, build = "narrow")
eps_w <- nl_episodes(con, drugs, ptids = cohort_ptids, build = "wide")
nl_route_audit(eps_n)                    # freeze the observed route value set

---- 2. lines, monotherapy, indeterminacy ----------------------------------
idx    <- nl_role_index(drugs)
lotb_n <- nl_lot_b(eps_n, index_dates, drugs, activity_last = act, death_date = dth, idx = idx)
lotb_w <- nl_lot_b(eps_w, index_dates, drugs, activity_last = act, death_date = dth, idx = idx)
mono   <- nl_monotherapy_two_build(nl_monotherapy(lotb_n, drugs),
                                   nl_monotherapy(lotb_w, drugs))

# The sweep is ~200 pipeline evaluations per patient (192 factorial cells plus
# the one-at-a-time decisions), so run it on the CANDIDATE set - patients with
# any docetaxel episode - not on the full denominator.
cand <- unique(eps_n$ptid[eps_n$drug_canon == NL_TARGET])
sens <- nl_sensitivity_table(eps_n, index_dates, drugs, ptids = cand)

cohort <- nl_cohort_2l(mono, sens)
nl_cohort_tables(cohort)                 # cohort_status: in / indeterminate / out

---- 3. the comparison -----------------------------------------------------
lota <- nl_lot_a(con, ptids = cohort_ptids)   # DESCRIBE the table first
cmp  <- nl_compare(lota, cohort); nl_compare_tables(cmp)

---- 4. ship with the numbers ----------------------------------------------
readr::write_csv(nl_decision_register(), "lot_b_decision_register.csv")

KNOWN-INCOMPLETE - what cannot be resolved without Flatiron, and what has
never been run against a warehouse. Read this before quoting a single number.

A. THIS IS NOT A REPLICATION. It is "the Flatiron specification plus declared
   pre-specified decisions". 8 of the 35 adversarial probe patients cannot
   have the cohort-inclusion decision reproduced from the document at all.
   nl_decision_register() must ship WITH the results, and the SAP must say so
   in those words.

B. QUESTIONS THAT ONLY FLATIRON CAN ANSWER (each is a live NL_DECISIONS entry
   that changes at least one patient's answer):
     G1  Does a line advance when a genuinely new drug is started outside the
         28-day window with no >120-day gap and no R21/R22/R23 exception? The
         document states no such rule. THIS IS WHAT MAKES DOCETAXEL "2L" FOR
         THE MODAL PATIENT; it is an inference by contraposition on R23, and
         it is load-bearing for essentially the entire cohort. Reported once,
         as a cohort-level caveat, never as a per-patient flag.
     G1' (D_G1B) And when the previous regimen KEEPS RUNNING alongside the new
         agent - addition or new line? R22 is the only addition rule stated
         and it names bevacizumab alone.
     G2  R18 (>120d gap advances) vs R13/R17 (maintenance never advances) when
         both fire literally. No precedence is stated.
     G3  Is switch maintenance (an agent that was NOT in the induction
         combination) maintenance at all? Verifiable against real Flatiron
         LineOfTherapy output - DO THAT before shipping.
     G4  Is the gap date2 - date1, or the count of intervening days?
     G5  Does R19's oral-gap exemption need both endpoints oral, either, or is
         it inapplicable in a source with no structured/abstracted distinction?
     G6  Does a post-28-day addition retro-name the regimen? This is the field
         the RWDAP selector keys on.
     G7  The automatic-LOT-exclusion drug-category mapping is unpublished. Our
         supportive-care list SUBSTITUTES for it and does not replicate it.
     G8  How are maintenance episodes counted (same-day rows; maximum span)?
     G9  Which exact date is "when the other drugs are dropped" (R16)?
     G10 What is "longest duration within the line" (R21), and what breaks an
         exact tie? SA-07 has NO determinable Flatiron regimen name under any
         reading.
     G11 Are the 28-day windows inclusive at the boundary?
     G12 Which rule version was the RWDAP cut built on - and what was the gap
         threshold BEFORE 6/30/20? It is not stated anywhere, so cuts with
         index dates before 2020-06-30 CANNOT be reproduced at all.
     G13 How is "clinical study drug" treated?
     G14 Is non-NSCLC-directed therapy excluded from advNSCLC lines?
     F-Q3 What is "the start of the patient's structured activity"?

C. STRUCTURALLY NON-REPLICABLE IN OPTUM, whatever Flatiron answers:
   * R3/R10/R11/R12/R25 - all five abstracted-oral rules have NO Optum input.
     Oral-terminated line END DATES are wrong by construction, in a known
     direction (order/fill dates instead of chart-confirmed stop dates).
   * "Clinical study drug" (G13) is invisible: lines Flatiron holds at the
     same number WILL advance in LOT-B. Report as a sized blind spot, never
     as a count. NO fixture exercises it.
   * Death is month-precision in Optum (varchar(6)); Flatiron generalizes a
     KNOWN exact date to end-of-month. These are not the same object, and it
     is first-order for rwOS, not just for R24 line ends.
   * The index date (R5) is abstractor-confirmed in Flatiron and a surrogate
     here. MI-07 is asserted in both arms precisely because the surrogate
     flips docetaxel from 2L to 1L, one-sidedly (a late surrogate converts
     straddling 1L courses into adjuvant courses).

D. WHAT THE TEST SUITE STILL CANNOT SEE. nl_run_regression() prints this, and
   it is not cosmetic: D_G8, D_G8B, D_G9, D_R14_FAILED_TEST, D_G13 and D_G14
   are declared and readable but NO fixture can flip them, and the suite
   contains no probe for same-day duplicate episodes, month/year-granularity
   oral spans, or the R24/death interaction. At least five further synthetic
   patients are required before the suite is adequate. An unexercised decision
   is an untested decision.

E. UNVERIFIED AGAINST THE DEPLOYMENT (every one of these must be confirmed by
   a live DESCRIBE before the primary run):
   * t_onc_line_of_therapy and every column nl_lot_a() names - the table is
     not in the reference varlist at all.
   * t_onc_medications.route - the value set drives is_oral, which drives R19.
   * t_administrations.ADMIN_DATE nullability (the precedent's order_date
     fallback) and the absence of a cancellation flag for R2's "non-canceled
     order".
   * the mesna row IS fixed (match_stems = "MESNA|MESNEX"); the
     ingredient-name fallback and the lint message stay as a guard against a
     future non-literal stem, not as a description of a live defect.

F. THE SUITES RUN AND PASS; NO QUERY HAS BEEN ISSUED. The engine parses and
   all 35 fixtures pass, so the analytically-derived expectations have since
   been confirmed by execution. What remains unrun is the warehouse: no
   connection, no data, no count. Expect to fix
   things, and trust no number from this file until it passes.

---

## 3. `nsclc_mets_stage.R` — purpose and provenance

nsclc_mets_stage.R - Metastatic SITE and STAGE (TNM) from Optum Enriched
                     Oncology, for the advanced-NSCLC prognostic score.

Cohort target: 2L docetaxel MONOTHERAPY, advanced NSCLC. Endpoint rwOS.
Drops in alongside nsclc_lot.R; namespace is nm_ / NM_ so nothing collides.

---------------------------------------------------------------------------
WHY THIS FILE EXISTS
---------------------------------------------------------------------------
The statistician asked whether Optum can supply (a) WHICH BODY PART the
metastasis is in and (b) the STAGE, neither of which the Flatiron advNSCLC
RWDAP can give. From this project's own candidate_variable_inventory.csv:

  * "Number of metastatic sites"  advN=2 - the HIGHEST-evidence metastasis
    variable in the inventory - is in Flatiron only a "Feasible if confirmed
    - raw" ICD proxy (count t_diagnosis C78/C79), NOT a curated field.
  * Bone (advN=1), Liver (advN=1), Brain/CNS, Lung/contralateral, Pleural,
    Adrenal, Abdominal - all "Feasible if confirmed - raw" ICD proxies only.
  * "M stage / distant metastasis extent"  - "Not feasible - no field".
    Inventory wording: "no M-stage field; group stage gives broad stage; raw
    secondary-neoplasm ICD gives only a coarse metastasis indicator (not
    M0/M1a/b/c)".
  * "T stage" and "N stage" - "Not feasible - no field", inventory wording
    "advanced cohort: group stage only, no TNM".

Optum Enriched Oncology carries t_onc_metastatic_location (a controlled SITE
vocabulary with an actual/absent qualifier), t_onc_tnm (separate T, N and M
columns with subdivisions) and t_onc_stage (AJCC group). Those are structural
capabilities the Flatiron cut does not have. nm_compare_to_flatiron() states
the gain in code so it is auditable rather than asserted.

---------------------------------------------------------------------------
THE ONE GUARD THAT MATTERS MOST
---------------------------------------------------------------------------
t_onc_metastatic_location has mets_qualifier IN ('actual','absent'), and
'absent' means THE NOTE NEGATED METASTASIS AT THAT SITE. A row's existence is
NOT a positive. Every extraction path in this file goes through
nm_mets_rows(), which requires mets_qualifier == 'actual' and asserts it; the
negated rows are returned SEPARATELY by nm_mets_absent() because a documented
negation is information, and it is exactly what an ICD proxy cannot give -
ICD has no "no liver metastasis" code. The R-side API boundary is guarded too
(nm_mets_summary() and nm_mets_source_agreement() refuse any frame that is
not positives-only), because that is where the plausible mistake happens.

---------------------------------------------------------------------------
EVIDENCE BASE FOR EVERY VALUE NAMED IN THIS FILE
---------------------------------------------------------------------------
Schema (columns, types):
  ../../optum_mc_reference/rdq_query_outputs/varlist.txt
    - RESULT 8: t_onc_neoplasm_histology has BOTH neoplasm_type varchar(25)
      AND histology varchar(65). They are different columns and this file
      reads both (see nm_lung_neo_keys).
Observed values (live 2025q4 queries, quoted not assumed):
  ../../optum_mc_reference/rdq_query_outputs/"diagnosis and metastatic.txt"
    - metastasis_location observed: bone, liver, lung, brain, peritoneum,
      pleura, chest, thyroid, intra-abdominal organs, vertebral column, rib,
      pancreas.  (A SAMPLE. It is NOT the closed vocabulary - run
      nm_vocab_scan() before trusting any mapping.)
    - mets_qualifier: actual / absent.  mets_temporal_status: current /
      history.
    - metastasis_dx_date is MOSTLY NULL and mixed-format ('20140314' exact,
      '2009mmdd' incomplete). note_date is the reliable anchor.
    - t_diagnosis.diagnosis_cd_type is multi-vocabulary at row level:
      ICD10 + ICD9 + SNOMEDCT in the same column. ICD codes carry NO decimals.
      ICD-9 codes are VARIABLE LENGTH in the sample (56400, 5651, 0919),
      which is why the lung test below matches the 3-character root.
  ../../optum_mc_reference/rdq_query_outputs/biomarker_tnm_queries.txt
    - t distribution: null,2,3,1c,1,1b,1a,4,3a,2a,4a,x,3b,2b,4b,2c,is,a,0,
      3c,1mi,4d,4c,2d,1mic,1b1,1b2,3d,1a1,2a2,2a1,1a2
    - n distribution: null,0,1,x,2,1a,3,2b,2a,1b,2c,1mi,1c,3a,3b,3c,4
    - m distribution: null,0,x,1,1b,1a,1c        <- M1a/M1b/M1c EXIST.
    - stage_prefix: null (19.4M), clinical (1.25M), pathological (0.59M)
    - stage: AJCC groups PLUS free text ("advanced","early stage","limited
      stage","extensive stage","end stage canc...","unknown","x"), bare
      suffixes a/b/c/d, Ann-Arbor-like ie/iae/iie/iiae, and leaked m0..m7.
  ../../optum_mc_reference/rdq_query_outputs/"proc and neoplasm.txt"
    - neoplasm_type top-40 distribution FOR THIS DEPLOYMENT:
        null 63,475,323 (rank 1)   mammary 34,232,179   skin 15,700,989
        prostatic 14,750,936       lung 13,275,346 (rank 5)   colon 10,499,263
      So (i) the lung value is the BARE ANATOMICAL TERM 'lung' - histology
      words such as "NSCLC" or "non-small cell" are NOT neoplasm_type values,
      they belong in the separate `histology` column; and (ii) neoplasm_type
      is NULL on the plurality of rows, which is an attrition on top of the
      orphan-key loss. See KNOWN LIMITS K.
Precedent (same deployment, colon feasibility):
  ../../optum_mc_reference/precedent/rdq1_cohort1.R          (mode A / mode C)
  ../../optum_mc_reference/precedent/RDQ_317023_cohort_feasibility.md
    - ~70% of t_onc_tnm / t_onc_stage rows have a NULL neoplasm_histology_key.
    - the single-primary test reads ICD from t_diagnosis, NOT neoplasm_type,
      because the EO guide warns neoplasm_type over-fragments one real cancer.

---------------------------------------------------------------------------
STATUS - read before using any number out of this file
---------------------------------------------------------------------------
THIS FILE PARSES. NOTHING IN IT HAS BEEN RUN AGAINST THE WAREHOUSE. No query
here has ever been issued, no count has ever been produced. nm_vocab_scan()
MUST be run first: every mapping below is keyed on a value SAMPLE, and a
vocabulary value that this file has never seen must not be silently dropped -
which is why the unmapped-value report is a return value, not a warning.

---

## 4. `nsclc_mets_stage.R` — known limits

13. KNOWN LIMITS - state these in the feasibility answer, not in a footnote

A. THE HAS_NOTES GATE. Every t_onc_* table is derived from physician notes. A
   patient without notes has NO metastasis row and NO staging row, and that is
   NOT the same as having no metastases and no stage. nm_population_funnel()
   sizes it. Any site flag for such a patient is UNOBSERVED - which is why
   nm_mets_summary() returns NA, not FALSE, for a patient with no record, and
   why n_met_sites is NA rather than 0. Whoever fills those NAs with zeros
   downstream will bias the score toward "less metastatic = worse-documented",
   and the direction of that bias is the same direction as the outcome. The
   same rule is why m1_any is NA, not FALSE, for a patient with no staging
   record at all.

B. metastasis_dx_date IS MOSTLY UNUSABLE. Observed: mostly null; where
   populated, mixed formats ('20140314' exact, '2009mmdd' with
   dx_date_type='incomplete'). note_date is the anchor everywhere in this
   file; the dx date is used only when dx_date_type='exact' AND the string is
   a CALENDAR-VALID yyyymmdd, and only to move a date EARLIER. The calendar
   check is not pedantry: a zero-filled partial ('20090000', '20140300') is
   eight digits, and Databricks SQL warehouses run ANSI mode ON by default,
   where to_date() on such a string ABORTS THE QUERY. The file uses
   try_to_date() as well. Consequence: for most patients the metastasis date
   is the date it was WRITTEN DOWN, not the date it was diagnosed. For a
   pre-index window that is usually harmless (both are before index); for
   anything time-to-event it is not, and this file must not be used to derive
   time-to-metastasis.

C. THE ORPHAN-KEY PROBLEM IS THE LARGEST SINGLE UNCERTAINTY ON THE STAGING
   SIDE. ~70% of t_onc_tnm and t_onc_stage rows carry a NULL
   neoplasm_histology_key (precedent finding; the share in
   t_onc_metastatic_location has NOT been measured -
   nm_vocab_scan()$mets_key_null does it). Mode A drops all of them and
   therefore UNDER-COUNTS stage and sites, possibly severely. Mode C recovers
   them for single-lung-primary patients, at the cost of assuming the orphan
   row belongs to the lung cancer. Neither is right. Report both
   (nm_orphan_impact()) and say which the primary analysis used. Mode C's
   reach also depends on two codelist judgements, both reported by
   nm_orphan_impact(): C80 is NOT treated as a competing primary
   (D_C80_PRIMARY - it names no site and is routine in this cohort), and the
   ICD-9 other-primary test now covers 200-209 as well as 140-195 so that a
   lymphoma disqualifies whichever vocabulary it billed in.

D. NO COUNT MAY BE ASSERTED BEFORE nm_vocab_scan() HAS BEEN RUN. NM_SITE_MAP
   is keyed on TWELVE values seen in a 28-row sample. The real vocabulary is
   unknown. Until the scan is read:
     * n_met_sites is a count over an incompletely mapped vocabulary. Each
       distinct unmapped value counts as its own site (D_UNMAPPED_SITE) and
       n_unmapped_sites says how much of the count came from them, so the
       count is not silently deflated - but the SITE FLAGS for those values do
       not exist;
     * met_adrenal may be structurally always-FALSE, because no 'adrenal'
       value has ever been observed - the pattern is speculative and fires
       only if such a value exists;
     * $unmapped (computed over the FULL input, before any index window - an
       in-window-only report could be empty for a badly incomplete mapping)
       being empty is the ONLY evidence that the mapping is complete.
   Same for staging: nm_stage_parse() is keyed on a 52-row stage distribution,
   m_suffix has never been dumped at all (so the second leg of
   D_M_SUBCATEGORY is unverified), and t_prefix / n_prefix / m_prefix have
   never been dumped either although D_TNM_PREFIX filters on them.

E. WHAT THE SITE TABLE STILL DOES NOT GIVE, and must not be claimed:
     * LATERALITY. metastasis_location = 'lung' does not say contralateral.
       The inventory variable is "Lung/contralateral metastasis"; what this
       file delivers is lung metastasis, full stop. t_onc_neoplasm_histology
       has a `direction` column, but it describes the NEOPLASM, not the
       metastasis, and it is not read here.
     * LESION COUNT or SIZE. There is no such column, so M1b (single
       extrathoracic lesion) vs M1c (multiple) is available ONLY when the m /
       m_suffix column says so - it cannot be reconstructed from site rows.
     * 'chest' is anatomically ambiguous and is deliberately not forced into
       pleura or lung (D_CHEST_SITE). It is grouped with the intrathoracic
       flags and it DOES add a compartment to n_met_sites, so a patient
       documented as 'lung', 'pleura' and 'chest' scores 3 for what may be one
       intrathoracic compartment.

F. t_onc_stage.stage IS CONTAMINATED, and knowing by how much is part of the
   answer. Observed non-AJCC content: 'advanced' (11,511), 'early stage'
   (85,300), 'limited stage' (75,512), 'extensive stage' (94,369) - the last
   two are SCLC vocabulary appearing in a lung cohort - plus leaked m0..m7,
   bare a/b/c/d, Ann-Arbor-like ie/iae/iie/iiae, a '5', and 'unknown'/'x'.
   nm_stage_tnm()$freetext counts them. None becomes an AJCC group
   (D_STAGE_FREETEXT), and the parser anchors the WHOLE string against the
   AJCC suffix grammar so that an unseen token cannot manufacture a stage by
   starting with an 'i' or a digit ('is' is carcinoma in situ, not stage I).
   Because ~267k of these rows parse to ajcc_group = NA, the at_diagnosis
   selector ranks informativeness ahead of date
   (D_STAGE_AT_DX_INFORMATIVE); n_nonajcc_stage_records_skipped and
   n_uninformative_records_skipped report how often that mattered.

G. stage_prefix IS NULL ON ~91% OF ROWS (19,376,075 null vs 1,248,072 clinical
   and 585,713 pathological, observed). So clinical vs pathological staging
   cannot be separated for most patients. Not filtered; carried
   (D_STAGE_PREFIX). Whether null is informative is an open question for
   Optum. Note this is the STAGE-BASIS prefix, a different column from the
   per-axis descriptors t_prefix/n_prefix/m_prefix used by D_TNM_PREFIX.

H. SNOMEDCT IS NOT DECODED, AND THE TWO ICD VOCABULARIES ARE NOT SYMMETRIC BY
   ACCIDENT. t_diagnosis.diagnosis_cd_type carries ICD10, ICD9 and SNOMEDCT at
   row level. The proxy here handles ICD10 and ICD9 - deliberately aligned
   compartment by compartment (ovary, kidney/urinary, other digestive, skin),
   and lint-checked by nm_icd_list_lint(), because a patient's compartment
   must not depend on which vocabulary a site happened to bill in. NO SNOMED
   concept id is written anywhere in this file, because no verified crosswalk
   exists in this repo and inventing one would be fabrication.
   nm_icd_vocab_scan() reports the SNOMEDCT share so the blind spot is sized.
   This also makes mode C's single-primary test mildly OPTIMISTIC: a second
   primary recorded only in SNOMED would not disqualify the patient.

I. THE TUMOUR PROBES. The ANATOMICAL probe is confirmed for this deployment:
   "proc and neoplasm.txt" shows neoplasm_type = 'lung' with 13,275,346 rows,
   so the vocabulary value is the bare anatomical term and NM_LUNG_NEO_SUBSTR
   is 'LUNG' / 'BRONCH'. The HISTOLOGY probe (NM_LUNG_HIST_SUBSTR) is NOT
   confirmed - the histology vocabulary has never been dumped - and it is
   load-bearing, because it is what recovers the neoplasm_type-NULL rows.
   Run nm_neoplasm_type_scan() FIRST and confirm or replace both probes; they
   decide which tumour every stage and every metastasis row is attached to.

J. THIS FILE HAS BEEN PARSED AND ITS OFFLINE SELF-TEST PASSES. IT HAS NEVER
   BEEN RUN AGAINST THE WAREHOUSE. Not one query in it has been issued; not
   one count exists. nm_selftest() exercises the parsers on the tokens the
   observed distributions contain and proves the R-side reducers survive zero
   rows - which is the most likely first-run outcome - but the SQL is written
   against a schema confirmed by DESCRIBE (varlist.txt) and value
   distributions confirmed by live queries, and no join here has ever returned
   a row. dbplyr translation errors, mode-C join blow-ups and the behaviour of
   the CASE-based ICD read are all still ahead. Run the validation path
   (section 12) before anything else, and treat the first numbers out of it as
   debugging output, not as feasibility findings.

K. neoplasm_type IS NULL ON THE PLURALITY OF t_onc_neoplasm_histology ROWS -
   63,475,323, larger than any named value including 'lung' ("proc and
   neoplasm.txt"). A SQL LIKE on a NULL column is NULL, i.e. the row is
   dropped, so an anatomy-only probe silently loses every one of those rows.
   That is a SECOND attrition, independent of and stacked on top of the ~70%
   orphan-key loss in item C. nm_lung_neo_keys() therefore ORs the histology
   column, and nm_population_funnel() reports the anatomy-only step and the
   anatomy-OR-histology step separately so the size of the recovery is
   visible. A row with BOTH columns null is unreachable by any probe;
   nm_neoplasm_type_scan()$neoplasm_type_null counts those.

L. THERE IS NO AJCC EDITION FIELD, AND THE EDITIONS DISAGREE. AJCC 7 lung M1b
   = ANY distant metastasis; AJCC 8 (2017+) M1b = a SINGLE extrathoracic
   lesion and M1c = multiple. Pooling them mixes two definitions in the one
   variable this file advertises as the structural gain over Flatiron. There
   is no edition column in t_onc_tnm, so note_date is used as a PROXY
   (NM_AJCC8_FROM) and pre-2017/undated records are collapsed to M1_NOS by
   default (D_AJCC_EDITION), with m1_edition_era carried so the collapse is
   auditable. THE SAME PROBLEM APPLIES TO T AND IS NOT CORRECTED: the T1a/b/c
   size cut-offs and the T3/T4 definitions also changed in AJCC 8, so t_cat is
   comparable across eras only at the coarse 1/2/3/4 level, and not even
   reliably there. State this before anyone models t_cat as a single scale.

M. ONLY first_mets_date AND THE FLAGS DERIVED FROM IT ARE INDEX-SAFE.
   nm_mets_sites() aggregates the whole record and nm_mets_summary() applies
   the index window afterwards, on first_mets_date alone. A global minimum is
   <= index iff some record is, so the site flags and n_met_sites are correct.
   The columns suffixed _ever (last_mets_date_ever, n_records_ever,
   n_exact_dated_ever, any_history_ever, n_sources_ever) are computed over
   POST-INDEX records too. n_sources_ever in particular looks like an
   evidence-strength covariate and is not one: using it at baseline leaks
   follow-up into a model whose endpoint is rwOS. The suffix is the warning.

N. THE ICD PROXY IS OUR CODELIST, NOT FLATIRON'S. nm_icd_mets_proxy() is a
   stand-in for the "raw ICD proxy" the inventory describes; it is not a
   reproduction of any Flatiron artefact, and its gaps would flatter the
   Optum side, so it is written to be at least as generous as the enriched
   read wherever the codes exist. Three specifics:
     * ICD-9 199.1 is NOT included - 199 is "malignant neoplasm without
       specification of site" and 199.1 is routinely used for a PRIMARY of
       unknown site. Including it would manufacture metastasis positives.
     * Site-less secondary codes (C79.9, C79.89, 199.0) go to
       `unspecified_site`, which is NOT an anatomical compartment: counting
       them as one would inflate the ICD side's implied site count.
     * The agreement table scores ONLY the compartments whose definition is
       1:1 on both sides (NM_AGREEMENT_GROUPS). 'other_organ' is thyroid on
       the enriched side and mediastinum/genital/respiratory-NOS on the ICD
       side; 'abdominal_organ' is 'intra-abdominal organs' vs bowel and
       kidney. Those rows are returned in $not_comparable rather than dropped
       or presented as an Optum win.
   Both sides are restricted to the SAME population (nm_comparison_pts()),
   which is required, not optional: an ungated ICD read answers for every
   breast, prostate and colon patient in the deployment.

---

## 5. Regression fixture column provenance

`tests/lot_regression_cases.csv` labels every result column by provenance, because the bare
`expect_*` names did not say *whose* expectation they were:

| Column | Meaning |
|---|---|
| `author_expect_lot_flat` | what the case author predicted Flatiron would return |
| `solver_lot_flat` | what the independent blind solver returned |
| `adjudicated_lot_flat` / `adjudication_verdict` | the adjudicated answer where the two disagreed, and the verdict that settled it |
| `oracle_lot_flat` | **the oracle** — the adjudicated value where one exists, else the agreed value |
| `solver_lot_a` / `solver_lot_b` | LOT-A, and a prediction of what a *naive* Optum rebuild would return |

The legacy `expect_lot_flat` / `expect_lot_a` / `expect_lot_b` / `expect_mono_flat` names ship as
**aliases** of `oracle_lot_flat` / `solver_lot_a` / `solver_lot_b` / `mono_flat`.
`nl_run_regression()` reads the provenance names and hard-stops on alias drift, so the two can
never quietly diverge.

`NL_TIER1_ORACLE` is transcribed from §6 of `response/METHODS.md`.
