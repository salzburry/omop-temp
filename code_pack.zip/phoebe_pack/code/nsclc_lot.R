# ============================================================================
# nsclc_lot.R - Dual line-of-therapy derivation for advanced NSCLC in Optum MC
#
#   LOT-A : Optum's native t_onc_line_of_therapy (IV + procedure-coded only)
#   LOT-B : Flatiron's advNSCLC LOT rules, re-implemented on Optum source data
#
# Cohort target: 2L docetaxel MONOTHERAPY, advanced NSCLC. Endpoint rwOS.
#
# LOT-B IS NOT A REPLICATION. The transcribed ruleset is silent at 14 points; the
# decisions substituting for that silence are registered in NL_DECISIONS below and
# must be cited as decisions, never as Flatiron rules.
#
# NOTHING IN THIS FILE HAS BEEN RUN AGAINST THE WAREHOUSE.
#
# Rules ../extracted_text/lot_ruleset.txt  ([Rn] == LOT-nn)
# Gaps  ../METHODS.md
# Drugs ../response/drug_code_list.csv     Fixtures ../tests/lot_regression_cases.csv
# Limitations, provenance and open questions: ../METHODS.md
# ============================================================================

suppressPackageStartupMessages({
  library(DBI); library(odbc); library(dplyr); library(dbplyr)
  library(stringr); library(tidyr); library(readr); library(purrr)
})

`%||%` <- function(a, b) if (is.null(a)) b else a
isTRUE_vec <- function(x) !is.na(x) & x

# ============================================================================
# 0. CONFIG
# ============================================================================

MC_CATALOG <- "hive_metastore"
MC_SCHEMA  <- "clnprw_optum_mc_full_use"
MC_CUT     <- "2025q4"

# Project root. These paths were relative to the CURRENT WORKING DIRECTORY, so
# sourcing this file from anywhere but R/ silently failed to find the drug list
# and the fixtures. Resolve against an explicit root instead: NL_ROOT if set,
# else the directory containing this file's parent (.../Aug_30_2026).
NL_ROOT <- local({
  looks_right <- function(d)
    !is.na(d) && nzchar(d) && dir.exists(file.path(d, "response")) &&
    dir.exists(file.path(d, "tests"))
  cands <- character(0)
  e <- Sys.getenv("NL_ROOT", "")
  if (nzchar(e)) cands <- c(cands, e)
  # source()d from a tempfile resolves ofile into the temp dir, so a derived
  # root is a CANDIDATE to be validated, never the answer.
  f <- tryCatch(sys.frame(1)$ofile, error = function(e) NULL)
  if (!is.null(f) && nzchar(f)) cands <- c(cands, dirname(dirname(normalizePath(f, mustWork = FALSE))))
  # walk up from the working directory
  d <- normalizePath(getwd(), mustWork = FALSE)
  for (i in 1:5) { cands <- c(cands, d); d <- dirname(d) }
  hit <- Filter(looks_right, cands)
  if (!length(hit))
    stop("NL_ROOT: cannot locate the Aug_30_2026 root (needs response/ and tests/ ",
         "beneath it). Set NL_ROOT explicitly. Tried: ", paste(unique(cands), collapse = ", "))
  normalizePath(hit[1], mustWork = FALSE)
})
NL_DRUG_CSV  <- file.path(NL_ROOT, "response", "drug_code_list.csv")
NL_CASES_CSV <- file.path(NL_ROOT, "tests", "lot_regression_cases.csv")

NL_TARGET <- "DOCETAXEL"   # canonical ingredient of the cohort-defining agent

# ---- Flatiron LOT parameters. Every value is quoted from the rule spec. ----
# These are TRANSCRIBED RULES, not decisions. Changing any of them changes the
# definition of a line - do not tune them. Everything that is NOT in this list
# but is nonetheless needed to run the algorithm lives in NL_DECISIONS.
NL <- list(
  index_preallowance_days = 14,   # R6/R8/R27: 1L may start up to 14d BEFORE index
  regimen_window_days     = 28,   # R9:  line = first episode + other drugs within 28d
  switch_window_days      = 28,   # R23: targeted/IO switch inside 28d does not advance
  oral_overlap_days       = 3,    # R10: permitted overlap; earlier agent backdated
  gap_days                = 120,  # R18: gap > 120d advances the line
  maint_episodes_r13      = 2,    # R13: pembro/atezo/pemetrexed/erlotinib/cemiplimab/bev
  maint_episodes_r15      = 3,    # R15: nivolumab (+ hyaluronidase-nvhy)
  maint_days_r16          = 49,   # R16: nivo+ipi continued >= 49d after others dropped
  maint_1l_only           = TRUE  # R17: maintenance only in 1L; never advances the line
)

# Optum LOT-A parameters, for reference only (EO user guide 4.6.1). Not used by LOT-B.
NL_A <- list(regimen_window_days = 30, gap_days = 90, any_switch_ends_line = TRUE)

# ============================================================================
# 0b. NL_DECISIONS - the substituted decisions, declared
#
# One entry per place where the Flatiron document is SILENT and the algorithm
# still has to do something. Fields:
#   gap         G-number from METHODS.md sec 5 (or the F-Q
#               number from 03_..._design.md sec 1.3), i.e. the question that
#               must go to Flatiron
#   question    the decision, stated as a question
#   value       the branch pre-specified and run as PRIMARY
#   alternative the branch(es) swept but never run as primary
#   sweep       "factorial" (swept JOINTLY with the other determinative
#               decisions, because an answer can be over-determined by a PAIR -
#               see GAP-03), "one_at_a_time", or FALSE (note says why)
#   cases       the probe patients that turn on it
#   exercised   TRUE if some fixture can actually flip an answer through it.
#               FALSE = declared and readable but UNPROBED: a testing gap, not
#               evidence of safety.
#
# THESE ARE NOT FLATIRON RULES. Every one must be listed as a pre-specified
# decision in the SAP, and every patient whose answer flips must be reported as
# indeterminate, not as a number. Read with nl_dec(), never from the comment.
# ============================================================================

NL_DECISIONS <- list(

  D_G1_OUT_OF_WINDOW_NEW_DRUG = list(
    gap      = "G1",
    question = paste("A NEW eligible antineoplastic starts on day D > 28 of line N, the PRIOR",
                     "REGIMEN HAS STOPPED, no gap exceeds 120 days and no R21/R22/R23 exception",
                     "applies. Does the line advance? The document states no such rule."),
    value = "advance", alternative = "persist", sweep = "factorial", exercised = TRUE,
    cases = c("GAP-02","MNT-03","MNT-05","MI-03","MNT-01","MNT-07","MI-02","MI-04"),
    note  = paste("THE rule that makes docetaxel '2L'. Obtained by contraposition on R23 and by",
                  "exhausting the enumerated exceptions - an inference, not a rule. LOAD-BEARING",
                  "FOR ESSENTIALLY THE WHOLE COHORT, so it is reported once as a cohort-level",
                  "caveat and per-patient indeterminacy is judged on the gaps OTHER than G1.")
  ),

  D_MISSING_INDEX_DATE = list(
    gap = "F-Q", value = "stop", alternative = "warn",
    sweep = "none", exercised = FALSE, cases = "LEAK-02",
    question = "What happens to a patient who has episodes but no index date?",
    basis = paste("Previously a bare inner_join dropped them with no signal at all. A cohort",
                  "whose denominator changes silently cannot support an attrition funnel, which",
                  "is the deliverable Phoebe asked for. Default 'stop' because a missing index",
                  "date in a cohort keyed ON the index date is a construction error, not a",
                  "tolerable missingness pattern; 'warn' exists for exploratory reruns."),
    settled_by = "Analytics: fix the index-date construction, do not relax this."
  ),
  D_G1B_CONTINUATION_HORIZON = list(
    gap = "G1", value = "28", alternative = "56",
    sweep = "one_at_a_time", exercised = FALSE, cases = "LEAK-01",
    question = paste("How far past the candidate date may we look to decide the prior regimen",
                     "'continues'?"),
    basis = paste("The document states no rule. Any UNBOUNDED lookahead is temporal leakage:",
                  "a rechallenge at end of follow-up would change the line number assigned",
                  "years earlier, so cohort membership would depend on post-index data. 28 days",
                  "matches the R6 regimen window, the same horizon the document uses to decide",
                  "what belongs to one regimen. 56 days is the sensitivity arm."),
    settled_by = "Flatiron: how is regimen continuation evaluated at an out-of-window new drug?"
  ),
  D_G1B_POST28_ADDITION = list(
    gap      = "G1",
    question = paste("Same as G1 except the EXISTING regimen CONTINUES alongside the new agent",
                     "(docetaxel + ramucirumab from day 35). Addition to the running line, or a",
                     "new line? R22 is the only stated addition rule and it names bevacizumab."),
    value = "persist", alternative = "advance", sweep = "one_at_a_time", exercised = TRUE,
    cases = c("MI-03","MI-06","SA-04","SA-06"),
    note  = paste("Separating 'added to' from 'replaced by' is what makes D_G6 reachable: under a",
                  "blanket G1='advance' every post-28 addition opened a new line. 'persist'",
                  "follows the MNT-07 principle and reproduces the adjudicated MI-03 answer (2L).")
  ),

  D_G2_GAP_VS_MAINTENANCE = list(
    gap      = "G2",
    question = "A 1L maintenance phase is interrupted by a >120-day hold then resumed. R18 and R13/R17 both fire literally. Which wins?",
    value = "R18_wins", alternative = "maintenance_immune", sweep = "factorial", exercised = TRUE,
    cases = c("MNT-04","GAP-01","GAP-03","MNT-02"),
    note  = paste("R19 proves Flatiron writes gap exemptions explicitly when it wants one and",
                  "wrote none for maintenance - suggestive, not stated. The 'are we in a",
                  "maintenance phase' test (nl_in_maint_phase) is itself part of this decision:",
                  "it is the maintenance test (R13/R15/R16 thresholds, G3/G8/G8B) restricted to",
                  "1L episodes on or before the pre-gap date, so drug identity alone never",
                  "suppresses an R18 gap.")
  ),

  D_G3_SWITCH_MAINTENANCE = list(
    gap      = "G3",
    question = "Is a maintenance-eligible agent introduced after 1L that was NOT part of the 1L combination treated as maintenance under R13/R15?",
    value = "require_prior_combination", alternative = "allow_switch_maintenance",
    sweep = "one_at_a_time", exercised = TRUE, cases = c("MNT-05"),
    note  = paste("R13/R15 condition maintenance on prior membership in the induction combination;",
                  "R14 shows Flatiron writes an explicit no-combination route when it means one.",
                  "Under the literal reading JMEN-style switch maintenance is not maintenance and",
                  "docetaxel is 3L. VERIFIABLE against real Flatiron LineOfTherapy output - do it.")
  ),
  D_G3B_SWITCH_MAINT_HORIZON = list(
    gap      = "G3",
    question = "How far past the switch date may the G3 pre-check look to see whether the R13 (>=2) / R15 (>=3) episode threshold is reached?",
    value = "84", alternative = "56", sweep = "one_at_a_time", exercised = TRUE, cases = c("MNT-05"),
    note  = paste("Days. Same reasoning as D_G1B_CONTINUATION_HORIZON: the pre-check must be a function",
                  "of the past and a fixed horizon, never of end-of-follow-up. 84 = four q21d cycles,",
                  "enough for R15's third q28d dose; 56 is the tighter bound.")
  ),

  D_G4_GAP_ARITHMETIC = list(
    gap      = "G4",
    question = "Is the R18 gap date2 - date1, or the count of days strictly between episodes?",
    value = "date_difference", alternative = "intervening_days", sweep = "factorial",
    exercised = TRUE, cases = c("GAP-01","GAP-02","GAP-03","GAP-05","GAP-06"),
    note  = paste("R18 fixes the strictness ('more than 120') but never the unit; five probes sit",
                  "within a day of the cliff. GAP-03 proves the sweep must be factorial: G4 alone",
                  "does not move it because G1 re-advances at the same date - only the PAIR",
                  "{G4=intervening_days, G1=persist} leaves docetaxel without a line.")
  ),

  D_G5_ORAL_GAP_SCOPE = list(
    gap      = "G5",
    question = paste("R19 exempts a >120d gap 'in structured oral drug episodes'. Both endpoints",
                     "oral, either, or not at all? Optum has no structured-vs-abstracted oral",
                     "distinction, so applying it to every oral over-suppresses advancement."),
    value = "both_endpoints_oral", alternative = c("either_endpoint_oral", "no_oral_exemption"),
    sweep = "factorial", exercised = TRUE, cases = c("GAP-07","ORAL1L-03"),
    note  = paste("R18's 'between any two sequential drug episodes' shows the bounded phrasing was",
                  "available and was not used in R19. The 'no_oral_exemption' branch DISCARDS a",
                  "transcribed rule; it is swept as a bound, and ORAL1L-03 may depend on it.")
  ),

  D_G6_POST28_ADDITION_NAMING = list(
    gap      = "G6",
    question = paste("When a non-advancing addition occurs (R22, or any agent starting after day",
                     "28), is the regimen name recomputed or frozen at the 28-day window? R22",
                     "settles advancement and is silent on naming; R9's exceptions are unenumerated."),
    value = "freeze_at_window", alternative = "retro_name", sweep = "factorial", exercised = TRUE,
    cases = c("SA-04","MI-03","MI-06"),
    note  = paste("This is the field the RWDAP selector lot2 == 'Docetaxel' keys on, so THE",
                  "MONOTHERAPY PREDICATE FOLLOWS THIS DECISION (nl_monotherapy / nl_target_answer):",
                  "under retro_name it is evaluated on the recomputed regimen. Every patient with a",
                  "post-28d addition is flagged and the cohort reported with and without them.")
  ),

  D_G7_SUPPORTIVE_EXCLUSION = list(
    gap      = "G7",
    question = paste("Flatiron's 'drug category mapping that leads to automatic LOT exclusion' is",
                     "unpublished (visible only as the 30 JUN 2023 megestrol removal). Do we apply",
                     "our own supportive-care exclusion list?"),
    value = "apply_excl_list", alternative = "no_exclusion_list", sweep = "factorial",
    exercised = TRUE, cases = c("MI-01"),
    note  = paste("The list is the EXCL:supportive rows of drug_code_list.csv: corticosteroids,",
                  "5-HT3/NK1 antagonists, G-CSF, ESAs, bisphosphonates/denosumab, megestrol,",
                  "rescue agents. Dexamethasone is the hard one - it IS an antineoplastic",
                  "elsewhere. The excluded drugs are PULLED FROM THE SOURCE on purpose",
                  "(nl_pull_stems) so the exclusion is an auditable filter the sweep can switch",
                  "off, not an invisible omission from the query. SAP MUST STATE that this",
                  "substitutes for an unpublished Flatiron mapping and does not replicate it.")
  ),

  D_G8_MAINT_EPISODE_COUNT = list(
    gap      = "G8",
    question = "Do two administrations on the same calendar day count as one maintenance episode or two?",
    value = "distinct_calendar_days", alternative = "row_count", sweep = "one_at_a_time",
    exercised = FALSE, cases = c("GAP-01","MNT-04","MNT-01"),
    note  = paste("Decides the R13 >=2 and R15 >=3 thresholds; Optum's source union inflates row",
                  "counts. The day-level collapse is performed inside nl_lot_b() UNDER THIS",
                  "DECISION (it used to be hard-coded in nl_prepare_episodes(), making 'row_count'",
                  "unreachable). NOT EXERCISED: every fixture has at most one row per drug-day.")
  ),

  D_G8B_MAINT_MAX_SPAN = list(
    gap      = "G8",
    question = "Is there a maximum interval within which the required maintenance episodes must fall, and does an interruption end the phase?",
    value = Inf, alternative = 120, sweep = "one_at_a_time", exercised = FALSE, cases = c("MNT-04"),
    note  = paste("Days. Inf = no span constraint (nothing in the document imposes one). NOT",
                  "EXERCISED: MNT-04's two continued episodes fall 21 and 42 days after the drop.")
  ),

  D_G9_R16_DROP_ANCHOR = list(
    gap      = "G9",
    question = "R16's 49-day clock runs from when the other drugs are 'dropped'. From which date exactly?",
    value = "last_episode_of_dropped", alternative = "day_after_last_episode",
    sweep = "one_at_a_time", exercised = FALSE, cases = c("MNT-07"),
    note  = paste("A third candidate - 'the first omitted scheduled cycle' - is NOT implementable",
                  "in Optum (no scheduled-cycle artefact); recorded as a non-replicable branch.",
                  "NOT EXERCISED: MNT-07 fails at 42 days and would fail at 41.")
  ),

  D_G10_R21_DURATION = list(
    gap      = "G10",
    question = "Define R21's 'longest duration within the line': first-to-last span, episode count, or days covered?",
    value = "first_to_last_span", alternative = c("episode_count", "days_covered"),
    sweep = "one_at_a_time", exercised = TRUE, cases = c("SA-01","SA-02","SA-07"),
    note  = paste("Affects the regimen NAME only, never the line number. Reachable only because",
                  "the R21 collapse now runs over the whole line - a substitution always lands",
                  "outside the 28-day naming window.")
  ),

  D_G10B_R21_TIEBREAK = list(
    gap      = "G10",
    question = "What is the tiebreak when two substituted agents are exactly equal on 'duration'?",
    value = "indeterminate", alternative = "alphabetical", sweep = "one_at_a_time",
    exercised = TRUE, cases = c("SA-07"),
    note  = paste("'indeterminate' emits regimen = NA with reason G10-exact-tie. SA-07 (a 3-cycle/",
                  "3-cycle platinum swap) has NO determinable Flatiron regimen name under any",
                  "reading of 'duration'. The naming indeterminacy MUST NOT leak into the line",
                  "number - asserted in the regression suite.")
  ),

  D_G11_WINDOW_BOUNDARY = list(
    gap      = "G11",
    question = "Is 'within 28 days' (R9) inclusive of day 28, and is R23's 'first 28 days' the same window? The figures give the convention only for the 14-day index window.",
    value = "inclusive", alternative = "exclusive", sweep = "factorial", exercised = TRUE,
    cases = c("MI-06","SA-05","SA-06"),
    note  = paste("MI-06 sits exactly on day 28; SA-05 (27) and SA-06 (29) bracket the cliff.",
                  "Cohort membership can turn on a payer-authorisation date moving two days.",
                  "Day-28 additions are reported as their own row.")
  ),

  D_R14_FAILED_TEST = list(
    gap      = "R14",
    question = "A durvalumab introduction >28 days into 1L that then FAILS the R14 monotherapy test (chemo still running) - advance, or persist? R14 states the passing case only.",
    value = "persist", alternative = "advance", sweep = "one_at_a_time", exercised = FALSE,
    cases = c("MNT-03"),
    note  = paste("'persist' follows the MNT-07 principle. Under 'advance' the deferral is granted",
                  "only when nothing else continues past the introduction, i.e. when R14 can still",
                  "succeed. NOT EXERCISED: MNT-03's durvalumab is monotherapy from day one.")
  ),

  D_G12_RULE_VERSION = list(
    gap      = "G12",
    question = "Which LOT rule version was the RWDAP Flatiron cut built on, and what was the R18 gap threshold before 6/30/20?",
    value = "2026-08-28", alternative = c("2025-11-25", "2023-07-28"), sweep = FALSE,
    exercised = FALSE, cases = c("GAP-03","MNT-06","SA-02","ORAL1L-03","MNT-03"),
    note  = paste("Read by nl_assert_rule_version(): the R23 switch list and the R21 amivantamab",
                  "pair in the CSV are valid only for this version. THE PRE-6/30/20 GAP THRESHOLD",
                  "IS NOT STATED ANYWHERE, so cuts indexed before 2020-06-30 cannot be reproduced.")
  ),

  D_G13_CLINICAL_STUDY_DRUG = list(
    gap      = "G13",
    question = "How is 'clinical study drug' (an R23 list entry) treated for line initiation, advancement, naming and line end?",
    value = "unobservable_no_surrogate", alternative = "impute_from_trial_participation_flag",
    sweep = FALSE, exercised = FALSE, cases = character(0),
    note  = paste("Optum records dispensed/administered products, not blinded agents. Lines",
                  "Flatiron holds at the same number WILL advance in LOT-B. Report as a sized",
                  "blind spot, never as a count. NO FIXTURE EXERCISES THIS.",
                  "CONSEQUENCE FOR THE CODE LIST: [R23] names 43 entries; drug_code_list.csv",
                  "ships 42 SW:R23 rows because 'clinical study drug' has no ascertainable",
                  "stem and must never be matched. Nothing in this file may assert a 43-row",
                  "SW:R23 count - the shortfall is this decision, not a missing row.")
  ),

  D_G14_SECOND_PRIMARY = list(
    gap      = "G14",
    question = "Is non-NSCLC-directed antineoplastic therapy excluded from advNSCLC lines? The document is entirely silent.",
    value = "not_implemented", alternative = character(0), sweep = FALSE,
    exercised = FALSE, cases = character(0),
    note  = paste("NOT IMPLEMENTED - decision required. Nothing in this file creates a",
                  "MULTI_CANCER_FLAG column and nothing restricts episodes to lung-attributed",
                  "therapy: every antineoplastic episode enters the line algorithm whatever",
                  "cancer it was directed at. Candidate designs once the SME decides, NEITHER of",
                  "which exists in code: (a) flag-only sensitivity, (b) restrict to",
                  "lung-attributed episodes. No override is accepted until one is built.")
  ),

  # ---- decisions that are not G-numbered but are equally substituted ----

  D_EPISODE_SOURCE_BUILD = list(
    gap      = "R1/R2 Optum note (05_... sec 4.1-4.2)",
    question = "Which t_onc_medications data_source values constitute a Flatiron 'order or administration recorded in the EHR'?",
    value = "narrow", alternative = "wide", sweep = FALSE, exercised = TRUE,
    cases = c("ORAL1L-02","MI-04","GAP-03"),
    note  = paste("narrow = data_source in {rx_adm, rx_presc, proc} AND action in {administered,",
                  "prescribed, started}; wide = all six sources. narrow is PRIMARY, wide is a named",
                  "sensitivity and NEVER the primary; a patient whose monotherapy flips between",
                  "them is 'monotherapy-fragile' and is counted. Handled by the explicit two-build",
                  "design, not the sweep. Only three fixtures diverge: ORAL1L-02 (line), MI-04",
                  "(monotherapy), GAP-03 (advancement MECHANISM at an unchanged line number).")
  ),

  D_LOT03_ORAL_SPAN = list(
    gap      = "R3/R10/R11/R12/R25 (all non-replicable)",
    question = "Optum has no abstracted oral start/stop spans. What stands in for R3's 'any day within the abstracted span'?",
    value = "orders_and_fills_only", alternative = "construct_days_supply_window", sweep = FALSE,
    exercised = FALSE, cases = c("ORAL1L-01","ORAL1L-06","ORAL1L-07","GAP-07"),
    note  = paste("Primary uses order/prescription dates as episodes and constructs NO exposure",
                  "window - exactly the behaviour R25 overrides, so oral-terminated line END DATES",
                  "differ systematically. R10's 3-day overlap and R11/R12's granularity rules have",
                  "no Optum input and are not implemented.")
  ),

  D_STRUCTURED_ACTIVITY_START = list(
    gap      = "F-Q3",
    question = "'Start of the patient's structured activity' (R6) is never defined by Flatiron.",
    value = "min_structured_record", alternative = "t_patient.FIRST_MONTH_ACTIVE", sweep = FALSE,
    exercised = FALSE, cases = c("GAP-01"),
    note  = paste("min over t_encounter/t_diagnosis/t_observation/t_administrations.",
                  "FIRST_MONTH_ACTIVE is varchar(6) - month precision - so it cannot reproduce a",
                  "day-level rule. Supplied to nl_lot_b() as a column; if absent the gate is",
                  "SKIPPED and the run is flagged.")
  ),

  D_R18_READING = list(
    gap      = "GAP-04 finding (05_... sec 1)",
    question = "R18's prose is pooled-sequential; its figure annotation is phrased last-to-last between two named drugs. Which governs?",
    value = "pooled_sequential", alternative = "figure_last_to_last", sweep = FALSE,
    exercised = TRUE, cases = c("GAP-04"),
    note  = paste("RESOLVED IN FAVOUR OF THE PROSE - a guard rail, not a live decision. On a",
                  "platinum doublet with a dropped platinum the figure reading MANUFACTURES A",
                  "SPURIOUS 2L AND DEMOTES DOCETAXEL TO 3L, silently shrinking the cohort.",
                  "nl_pooled_gaps() refuses any other value; nl_r18_reading_diagnostic() sizes the",
                  "delta for the methods paper and is never on the primary path.")
  ),

  D_INDEX_DATE = list(
    gap      = "F-Q / R5",
    question = "Optum ships no abstracted advanced-diagnosis date (R5). What is the index date?",
    value = "IX-mets", alternative = "IX-icd", sweep = FALSE, exercised = TRUE,
    cases = c("MI-07","GAP-05","GAP-06"),
    note  = paste("IX-mets = t_onc_metastatic_location.metastasis_dx_date (+ staging); IX-icd =",
                  "first structured ICD-10 secondary-neoplasm code. BOTH ARE RUN (swept by running",
                  "the pipeline twice, not per patient). The single largest LOT-B risk: every",
                  "window in R6/R7/R8/R20 is measured from it and the colon precedent documents",
                  "~70% orphan neoplasm_histology_key. MI-07 flips docetaxel 2L -> 1L on a 21-day",
                  "surrogate shift and the suite ASSERTS BOTH ARMS. index_date is an INPUT here.")
  )
)

# ---- decision accessors. All engine code reads decisions through these. ----

# Normalise a decision value to ONE plain unnamed character scalar. Every
# identical(<accessor>(...), "literal") branch in the engine depends on this:
# a named scalar, a factor, a one-element list or a numeric would all compare
# FALSE against the literal and SILENTLY DISABLE the rule. Validation and the
# returned value must therefore be the same object.
nl_dec_scalar <- function(v, what) {
  u <- unlist(v, use.names = FALSE)
  if (is.factor(u)) u <- as.character(u)
  if (is.null(u) || !is.atomic(u) || length(u) != 1L)
    stop(what, " must be a single value, got ", if (is.null(u)) "NULL" else
         paste0(class(v)[1], " of length ", length(u)))
  unname(as.character(u))
}

# Return the value in force for decision `id`, honouring an override list `ov`.
# Always a plain character scalar, on both the override and the default path.
nl_dec <- function(id, ov = list()) {
  if (!is.character(id) || length(id) != 1L) stop("nl_dec(): id must be one string")
  if (!id %in% names(NL_DECISIONS)) stop("nl_dec(): unknown decision id '", id, "'")
  if (length(ov) && id %in% names(ov)) {
    v <- nl_dec_scalar(ov[[id]], paste0("nl_dec(): override for '", id, "'"))
    # An unregistered value (a typo, a renamed level) must stop, not fall
    # through every branch and look like the rule being correctly off.
    allowed <- unique(as.character(c(NL_DECISIONS[[id]]$value, NL_DECISIONS[[id]]$alternative)))
    if (!v %in% allowed)
      stop("nl_dec(): override for '", id, "' is '", v,
           "', not one of: ", paste(allowed, collapse = ", "))
    return(v)
  }
  nl_dec_scalar(NL_DECISIONS[[id]]$value, paste0("nl_dec(): registered value for '", id, "'"))
}

# Numeric accessor. Decisions are registered as character (the register is a
# character matrix in the sweep), so a numeric decision is stored as a string and
# converted here rather than at each call site.
nl_dec_num <- function(id, ov = list()) {
  v <- suppressWarnings(as.numeric(nl_dec(id, ov)))    # nl_dec() is always a character scalar
  # Inf is a LEGITIMATE registered value -- D_G8B_MAINT_MAX_SPAN defaults to it,
  # meaning "no span limit". Reject only a value that is not a number.
  if (length(v) != 1L || is.na(v))
    stop("nl_dec_num(): decision '", id, "' is not numeric: '",
         paste(nl_dec(id, ov), collapse = "/"), "'")
  v
}

# The gap number a decision substitutes for, e.g. "G4". Used for provenance tags.
nl_dec_gap <- function(id) {
  if (!id %in% names(NL_DECISIONS)) stop("nl_dec_gap(): unknown decision id '", id, "'")
  NL_DECISIONS[[id]]$gap
}

# The alternative branch(es), as a character/numeric vector.
nl_dec_alt <- function(id) {
  if (!id %in% names(NL_DECISIONS)) stop("nl_dec_alt(): unknown decision id '", id, "'")
  NL_DECISIONS[[id]]$alternative
}

nl_dec_sweep <- function(id) {
  s <- NL_DECISIONS[[id]]$sweep
  if (is.null(s) || identical(s, FALSE)) "none" else as.character(s)
}

# The determinative decisions, swept JOINTLY (2*2*2*3*2*2*2 = 192 cells).
nl_factorial_ids <- function()
  names(NL_DECISIONS)[vapply(names(NL_DECISIONS), function(i) identical(nl_dec_sweep(i), "factorial"), logical(1))]

# The remaining swept decisions, perturbed one at a time.
nl_one_at_a_time_ids <- function()
  names(NL_DECISIONS)[vapply(names(NL_DECISIONS), function(i) identical(nl_dec_sweep(i), "one_at_a_time"), logical(1))]

nl_sweep_ids <- function() c(nl_factorial_ids(), nl_one_at_a_time_ids())

# Human-readable declaration table. Paste this into the SAP appendix verbatim.
nl_decision_register <- function() {
  tibble::tibble(
    decision_id = names(NL_DECISIONS),
    gap         = vapply(NL_DECISIONS, function(d) as.character(d$gap), character(1)),
    value       = vapply(NL_DECISIONS, function(d) paste(as.character(d$value), collapse = " / "), character(1)),
    alternative = vapply(NL_DECISIONS, function(d) paste(as.character(d$alternative), collapse = " / "), character(1)),
    swept       = vapply(names(NL_DECISIONS), nl_dec_sweep, character(1)),
    exercised_by_suite = vapply(NL_DECISIONS, function(d) isTRUE(d$exercised), logical(1)),
    probe_cases = vapply(NL_DECISIONS, function(d) paste(d$cases, collapse = ","), character(1)),
    question    = vapply(NL_DECISIONS, function(d) d$question, character(1))
  )
}

# ============================================================================
# 1. CONNECTION HELPERS  (identical contract to the precedent)
# ============================================================================

mc_connect <- function(dsn = Sys.getenv("DATABRICKS_DSN", "RWDE"),
                       pwd = Sys.getenv("DATABRICKS_PWD", ""),
                       timeout = 120, bigint = "numeric", ...) {
  if (!nzchar(pwd)) stop("DATABRICKS_PWD is not set.")
  DBI::dbConnect(odbc::odbc(), dsn = dsn, pwd = pwd, timeout = timeout, bigint = bigint, ...)
}

# Databricks returns EHR tables UPPERCASE and t_onc_* lowercase; normalise both.
mc_tbl <- function(con, name) {
  dplyr::tbl(con, dbplyr::in_catalog(MC_CATALOG, MC_SCHEMA,
                                     paste0("t_", name, "_", MC_CUT))) |>
    dplyr::rename_with(tolower)
}

n_ptid <- function(tb) tb |> summarise(n = n_distinct(ptid)) |> pull(n) |> as.integer()

# ============================================================================
# 2. THE DRUG UNIVERSE
#
# Flatiron never publishes its eligible-antineoplastic list (G7 / F-Q1), so we
# supply our own. The CSV is the single source of truth; edit it, not this file.
# hcpcs_jcode / ndc_codes / verified_in_data ship EMPTY on purpose - they are
# populated from the data by nl_harvest_*() into a SIDECAR, eyeballed and then
# frozen by a human, and are NEVER hand-authored. NO NDC APPEARS IN THIS FILE.
# nl_assert_drug_list() says so out loud whenever either column is non-empty,
# because nothing downstream can tell a frozen harvest from a hand-typed code
# and a hand-typed code is the "looks implemented and matches nothing" defect
# 04 SS1 rejects. The columns are kept (not dropped) so that the harvest has a
# declared destination and 04 SS4.1's column list stays true.
#
# lot_role is PIPE-DELIMITED and its tokens are the ones actually present in
# drug_code_list.csv:
#   ELIGIBLE | EXCL:supportive | SW:R23 | ADD:R22
#   MAINT:R13-2ep | MAINT:R14-mono | MAINT:R15-3ep | MAINT:R16-pair49d
#   SUB:R21-platinum | SUB:R21-taxane | SUB:R21-biosimilar | SUB:R21-amivantamab
# Because the delimiter is "|" - a regex alternation - every match against
# lot_role in this file is a TOKEN-SET test, never a regex.
#
# `route` is the same pipe-delimited encoding, sorted case-insensitively, over
# the CLOSED token set below (04 SS2.1). It used to be free text - both
# "IV / oral" and "oral / IV", both "IV / SC" and "SC / IV", plus a singleton
# "IV only" - and route is a mandatory gate on mitomycin and the branch key for
# R19, so an ordering variant could silently switch the oral branch off.
#
# `ord` is the MATCH RESOLUTION ORDER (04 SS2.2): lower wins, so a record is
# assigned to exactly one ingredient. It is required, not optional: without it a
# single "Opdivo Qvantig" record matches both the SC nivolumab row (R15, >=3
# episodes) and the bare nivolumab row, which decides whether docetaxel is 2L or
# 3L. nl_canon() reads it as the primary key, stem length only as the tiebreak.
# ============================================================================

# Closed route vocabulary. Anything else is a CSV authoring error.
NL_ROUTE_TOKENS <- c("IV", "SC", "IM", "TD", "oral", "topical")

NL_ROLE_ELIGIBLE   <- "ELIGIBLE"
NL_ROLE_EXCLUDE    <- "EXCL:supportive"
NL_ROLE_SWITCH_R23 <- "SW:R23"
NL_ROLE_ADD_R22    <- "ADD:R22"
NL_ROLE_MAINT_R13  <- "MAINT:R13-2ep"
NL_ROLE_MAINT_R14  <- "MAINT:R14-mono"
NL_ROLE_MAINT_R15  <- "MAINT:R15-3ep"
NL_ROLE_MAINT_R16  <- "MAINT:R16-pair49d"
NL_ROLE_SUB_PREFIX <- "SUB:R21-"

# Split a pipe-delimited cell into a trimmed, non-empty character vector.
nl_split_pipe <- function(x) {
  if (length(x) != 1L || is.na(x) || !nzchar(x)) return(character(0))
  str_split(x, "\\|")[[1]] |> str_trim() |> (\(v) v[nzchar(v)])()
}

# A stem is usable only if it is a plain literal. drug_code_list.csv contains at
# least one authored escape hatch ("word-boundary: RLIKE ...") which is a NOTE to
# the SQL author, not a stem; silently LIKE-ing it would match nothing and
# silently LOSING it would drop a drug (mesna, an EXCL:supportive row - a lost
# exclusion CONTAMINATES the cohort), so we surface it AND fall back to the
# ingredient name so the drug is never silently lost. The CSV still needs the
# real fix - match_stems = "MESNA|MESNEX" - because the fallback cannot know the
# brand name.
nl_stem_is_literal <- function(s) {
  !is.na(s) & nzchar(s) & !str_detect(s, "RLIKE|\\\\b|:") & str_detect(s, "^[A-Za-z0-9 ()+/,.'-]+$")
}

# Usable stems for one row, with the ingredient-name fallback. Returns a list of
# character vectors, parallel to `drugs`.
nl_usable_stems <- function(drugs) {
  purrr::map2(drugs$match_stems, drugs$ingredient_u, function(ms, ing) {
    s <- toupper(nl_split_pipe(ms))
    s <- s[nl_stem_is_literal(s)]
    if (!length(s)) toupper(ing) else s
  })
}

nl_drugs <- function(path = NL_DRUG_CSV) {
  if (!file.exists(path)) stop("drug_code_list.csv not found at: ", path)
  d <- readr::read_csv(path, show_col_types = FALSE, progress = FALSE)
  # `ord` is REQUIRED. It is the match resolution order (04 SS2.2) and it decides
  # whether an SC IO record gets R13's >=2 or R15's >=3 maintenance threshold -
  # i.e. whether docetaxel is 2L or 3L - so it may not live only in prose.
  req <- c("ingredient", "route", "match_stems", "not_stems", "lot_role", "ord")
  miss <- setdiff(req, names(d))
  if (length(miss)) stop("drug_code_list.csv missing columns: ", paste(miss, collapse = ", "))
  d$ord <- suppressWarnings(as.integer(d$ord))
  if (any(is.na(d$ord)))
    stop("drug_code_list.csv has non-integer/blank ord for: ",
         paste(d$ingredient[is.na(d$ord)], collapse = ", "))
  d <- d |> mutate(ingredient_u = toupper(str_trim(ingredient)))
  if (any(duplicated(d$ingredient_u)))
    stop("drug_code_list.csv has duplicate ingredients: ",
         paste(unique(d$ingredient_u[duplicated(d$ingredient_u)]), collapse = ", "))
  d
}

# Long (ingredient, role) table.
nl_roles <- function(drugs) {
  drugs |>
    select(ingredient_u, lot_role) |>
    mutate(role = map(lot_role, nl_split_pipe)) |>
    select(-lot_role) |>
    tidyr::unnest(role)
}

nl_ing_with_role <- function(drugs, role) {
  r <- nl_roles(drugs)
  sort(unique(r$ingredient_u[r$role == role]))
}

# Ingredients carrying ANY role whose prefix matches, e.g. "MAINT:" or "SUB:R21-".
nl_ing_with_role_prefix <- function(drugs, prefix) {
  r <- nl_roles(drugs)
  sort(unique(r$ingredient_u[startsWith(r$role, prefix)]))
}

# Substitution families, as a named list role -> ingredients (R21).
nl_sub_families <- function(drugs) {
  r <- nl_roles(drugs) |> filter(startsWith(role, NL_ROLE_SUB_PREFIX))
  if (!nrow(r)) return(list())
  split(r$ingredient_u, r$role)
}

# ---- THE ROLE INDEX -------------------------------------------------------
# Computed ONCE and threaded through the engine. The previous version called
# nl_roles() - a mutate + tidyr::unnest over all 124 CSV rows - from inside the
# innermost per-date loop of the line assigner, which the sweep then re-ran ~200
# times per patient. Everything below takes `idx`, not `drugs`.
nl_role_index <- function(drugs) {
  r   <- nl_roles(drugs)
  get <- function(role) sort(unique(r$ingredient_u[r$role == role]))
  fam <- nl_sub_families(drugs)
  list(
    eligible   = get(NL_ROLE_ELIGIBLE),
    exclude    = get(NL_ROLE_EXCLUDE),
    sw_r23     = get(NL_ROLE_SWITCH_R23),
    add_r22    = get(NL_ROLE_ADD_R22),
    maint_r13  = get(NL_ROLE_MAINT_R13),
    maint_r14  = get(NL_ROLE_MAINT_R14),
    maint_r15  = get(NL_ROLE_MAINT_R15),
    maint_r16  = get(NL_ROLE_MAINT_R16),
    maint_all  = sort(unique(r$ingredient_u[startsWith(r$role, "MAINT:")])),
    sub_families = fam,
    route_tbl  = stats::setNames(tolower(drugs$route), drugs$ingredient_u),
    all_roles  = sort(unique(r$role))
  )
}

nl_drug_lint <- function(drugs) {
  stems_raw <- lapply(drugs$match_stems, function(x) toupper(nl_split_pipe(x)))
  bad <- vapply(stems_raw, function(s) paste(s[!nl_stem_is_literal(s)], collapse = " ; "), character(1))
  usable_n <- vapply(stems_raw, function(s) sum(nl_stem_is_literal(s)), integer(1))
  r <- nl_roles(drugs)
  known <- c(NL_ROLE_ELIGIBLE, NL_ROLE_EXCLUDE, NL_ROLE_SWITCH_R23, NL_ROLE_ADD_R22,
             NL_ROLE_MAINT_R13, NL_ROLE_MAINT_R14, NL_ROLE_MAINT_R15, NL_ROLE_MAINT_R16)
  unknown <- setdiff(unique(r$role), c(known, unique(r$role[startsWith(r$role, NL_ROLE_SUB_PREFIX)])))
  roles_of <- vapply(drugs$lot_role, function(x) paste(nl_split_pipe(x), collapse = ","), character(1))
  # Route must be the closed, canonically ordered vocabulary. A stray token or
  # an out-of-order pair silently disables the R19 oral branch for that drug.
  rt_tok <- lapply(drugs$route, nl_split_pipe)
  rt_bad <- vapply(seq_along(rt_tok), function(i) {
    tk <- rt_tok[[i]]
    if (!length(tk)) return("empty")
    unk <- setdiff(tk, NL_ROUTE_TOKENS)
    if (length(unk)) return(paste("unknown token(s):", paste(unk, collapse = " ")))
    if (!identical(tk, tk[order(tolower(tk))])) return("tokens not in canonical order")
    ""
  }, character(1))
  # ndc_codes / verified_in_data are harvest-only. A non-empty value in the
  # curated CSV means someone hand-filled them, which is the exact failure mode
  # (a code list that looks implemented and matches nothing) 04 SS1 rejects.
  hand <- character(0)
  for (cl in c("ndc_codes", "verified_in_data")) {
    v <- drugs[[cl]] %||% NULL
    if (!is.null(v) && any(!is.na(v) & nzchar(as.character(v))))
      hand <- c(hand, cl)
  }
  list(
    bad_routes        = tibble::tibble(ingredient_u = drugs$ingredient_u,
                                       route = drugs$route, why = rt_bad)[nzchar(rt_bad), ],
    hand_filled_codes = hand,
    non_literal_stems = tibble::tibble(ingredient_u = drugs$ingredient_u, bad = bad,
                                       usable_stems = usable_n)[nzchar(bad), ],
    stem_fallback_used = tibble::tibble(ingredient_u = drugs$ingredient_u,
                                        roles = roles_of)[usable_n == 0L, ],
    unknown_roles     = unknown,
    no_role           = tibble::tibble(ingredient_u = drugs$ingredient_u)[!nzchar(roles_of), ],
    eligible_n        = length(nl_ing_with_role(drugs, NL_ROLE_ELIGIBLE)),
    excluded_n        = length(nl_ing_with_role(drugs, NL_ROLE_EXCLUDE))
  )
}

# Loud, actionable pre-flight check. Called by nl_run_regression() and required
# before any production run. It does NOT stop on the ingredient-name fallback
# (that would deadlock the whole build on one supportive-care row); it stops only
# when a row is genuinely unmatchable.
nl_assert_drug_list <- function(drugs) {
  l <- nl_drug_lint(drugs)
  if (nrow(l$stem_fallback_used)) {
    message("drug lint: ", nrow(l$stem_fallback_used),
            " ingredient(s) have NO usable literal match_stem and fell back to the ",
            "ingredient name (brand synonyms are LOST until the CSV is fixed): ",
            paste(l$stem_fallback_used$ingredient_u, collapse = ", "))
    message("  FIX IN drug_code_list.csv, e.g. mesna: match_stems = 'MESNA|MESNEX' ",
            "and move the word-boundary caveat into the notes column.")
  }
  if (nrow(l$non_literal_stems))
    message("drug lint: ", nrow(l$non_literal_stems),
            " ingredient(s) carry a non-literal match_stem that was skipped: ",
            paste(l$non_literal_stems$ingredient_u, collapse = ", "))
  if (length(l$unknown_roles))
    message("drug lint: unknown lot_role token(s): ", paste(l$unknown_roles, collapse = ", "))
  # Not fatal: a human IS allowed to freeze a reviewed nl_populate_codes()
  # sidecar back into the CSV. It is loud because nothing downstream can tell a
  # frozen harvest from a hand-typed code, and a hand-typed code never matches.
  if (length(l$hand_filled_codes))
    message("drug lint: column(s) ", paste(l$hand_filled_codes, collapse = ", "),
            " are non-empty in drug_code_list.csv. These are populated ONLY by a ",
            "reviewed nl_populate_codes() sidecar frozen from this deployment, ",
            "never by hand. Confirm the provenance before trusting any code match.")
  if (nrow(l$bad_routes))
    stop("drug_code_list.csv route is not the closed vocabulary (",
         paste(NL_ROUTE_TOKENS, collapse = "|"), "), pipe-delimited and sorted: ",
         paste(paste0(l$bad_routes$ingredient_u, " [", l$bad_routes$route, "] ",
                      l$bad_routes$why), collapse = "; "))
  dead <- drugs$ingredient_u[vapply(nl_usable_stems(drugs), function(s) !length(s), logical(1))]
  if (length(dead))
    stop("drug_code_list.csv rows with no usable stem AND no usable ingredient name: ",
         paste(dead, collapse = ", "))
  invisible(l)
}

# Stems for a role, as a character vector, usable stems only.
nl_stems <- function(drugs, role) {
  keep <- vapply(drugs$lot_role, function(x) role %in% nl_split_pipe(x), logical(1))
  unique(unlist(nl_usable_stems(drugs)[keep]))
}

nl_eligible_stems <- function(drugs) nl_stems(drugs, NL_ROLE_ELIGIBLE)
nl_exclude_stems  <- function(drugs) nl_stems(drugs, NL_ROLE_EXCLUDE)

# The stems the SOURCE PULL must use. The supportive-care drugs are pulled ON
# PURPOSE: D_G7 is a declared decision, so its filter must be an auditable step
# in the pipeline, not an invisible omission from the SQL. (Previously the pull
# used the eligible stems alone - 89 ingredients, disjoint from the 35
# EXCL:supportive rows - so D_G7 dropped zero rows in production while the test
# harness exercised a code path production could not reach.)
nl_pull_stems <- function(drugs) unique(c(nl_eligible_stems(drugs), nl_exclude_stems(drugs)))

# SQL LIKE predicate over one column (precedent pattern).
nl_like_any <- function(col, substrs) {
  substrs <- substrs[!is.na(substrs) & nzchar(substrs)]
  if (!length(substrs)) return("(1 = 0)")
  terms <- paste0("UPPER(", col, ") LIKE '%", toupper(gsub("'", "''", substrs)), "%'")
  paste0("(", paste(terms, collapse = " OR "), ")")
}

# ---- canonicalisation: raw drug string -> ingredient, honouring not_stems ----
# LOWEST ord wins; longest matched stem breaks a tie within an ord. not_stems
# VETO the match, which is what stops "nab-paclitaxel" from canonicalising to
# paclitaxel (R21 taxane pair) and stops the precedent's "-lumab/-limab" false
# friends (dupilumab, sarilumab, ...).
#
# ord is the primary key BECAUSE stem length is not a resolution rule: it is an
# accident of spelling. 04 SS2.2 fixes the order (10 = co-formulations, ADCs and
# liposomal forms before their parent ingredient; 20 = named bevacizumab
# biosimilars before the unlisted-suffix catch-all; 30 = everything else), and
# this is the only place it is applied.
nl_canon <- function(drug_strings, drugs) {
  stems <- nl_usable_stems(drugs)
  nots  <- lapply(drugs$not_stems, function(x) toupper(nl_split_pipe(x)))
  ing   <- drugs$ingredient_u
  ord   <- as.integer(drugs$ord)

  key <- toupper(str_trim(as.character(drug_strings)))
  u   <- unique(key)
  res <- vapply(u, function(s) {
    if (is.na(s) || !nzchar(s)) return(NA_character_)
    best <- NA_character_; best_ord <- NA_integer_; best_len <- -1L
    for (i in seq_along(ing)) {
      st <- stems[[i]]
      if (!length(st)) next
      hit <- st[vapply(st, function(x) grepl(x, s, fixed = TRUE), logical(1))]
      if (!length(hit)) next
      nt <- nots[[i]]
      if (length(nt) && any(vapply(nt, function(x) grepl(x, s, fixed = TRUE), logical(1)))) next
      ml <- max(nchar(hit))
      better <- is.na(best_ord) || ord[i] < best_ord ||
        (ord[i] == best_ord && ml > best_len)
      if (better) { best_ord <- ord[i]; best_len <- ml; best <- ing[i] }
    }
    best
  }, character(1), USE.NAMES = FALSE)

  res[match(key, u)]
}

# ============================================================================
# 3. CODE HARVEST - fills the CSV placeholders FROM THE DATA
#
# NDC codes are product/package specific, run to thousands per ingredient and
# change over time. They are never authored by hand, and none is written into
# this source file. This harvests what the deployment actually contains so a
# human can eyeball and freeze the mapping into the CSV.
# ============================================================================

nl_harvest_ndc <- function(con, drugs) {
  stems <- nl_pull_stems(drugs)
  pull_one <- function(tbl_name) {
    mc_tbl(con, tbl_name) |>
      filter(sql(paste(nl_like_any("generic_desc", stems), "OR",
                       nl_like_any("drug_name",    stems)))) |>
      group_by(generic_desc, drug_name, ndc) |>
      summarise(n_rows = n(), n_pts = n_distinct(ptid), .groups = "drop") |>
      mutate(src = tbl_name) |>
      collect()
  }
  bind_rows(pull_one("administrations"), pull_one("prescription")) |> arrange(desc(n_pts))
}

# HCPCS/J-code inventory, by scanning PROC_DESC free text. Confirms codes rather
# than assuming them - the deployment carries ~3.6B procedure rows with unmapped
# proc_code_type, so do NOT filter on that column (precedent finding).
nl_harvest_jcodes <- function(con, drugs) {
  stems <- nl_pull_stems(drugs)
  mc_tbl(con, "procedure") |>
    filter(sql(nl_like_any("proc_desc", stems))) |>
    group_by(proc_code, proc_code_type, proc_desc) |>
    summarise(n_rows = n(), n_pts = n_distinct(ptid), .groups = "drop") |>
    collect() |>
    arrange(desc(n_pts))
}

# Writes a SIDECAR by default. The curated ndc_codes / hcpcs_jcode /
# verified_in_data columns in drug_code_list.csv are frozen by a human, and a
# second harvest against a different cut used to overwrite them in place with no
# backup and no diff. Overwriting the curated file now requires overwrite = TRUE.
nl_populate_codes <- function(drugs, ndc_tbl, jcode_tbl,
                              path = sub("\\.csv$", "_harvested.csv", NL_DRUG_CSV),
                              overwrite = FALSE) {
  if (!overwrite && identical(normalizePath(path, mustWork = FALSE),
                              normalizePath(NL_DRUG_CSV, mustWork = FALSE)))
    stop("refusing to overwrite the curated drug_code_list.csv; pass overwrite = TRUE ",
         "only after a human has reviewed the harvested sidecar")
  match_rows <- function(stems, nots_str, tbl, code_col, text_cols) {
    nots  <- toupper(nl_split_pipe(nots_str))
    if (!length(stems) || !nrow(tbl)) return(NA_character_)
    hay <- toupper(do.call(paste, c(as.list(tbl[text_cols]), sep = " ")))
    hit <- Reduce(`|`, lapply(stems, function(s) str_detect(hay, fixed(s))))
    if (length(nots))
      hit <- hit & !Reduce(`|`, lapply(nots, function(s) str_detect(hay, fixed(s))))
    codes <- unique(tbl[[code_col]][hit & !is.na(tbl[[code_col]])])
    if (!length(codes)) NA_character_ else paste(sort(codes), collapse = ";")
  }
  stems_l <- nl_usable_stems(drugs)
  out <- drugs
  out$ndc_codes   <- vapply(seq_len(nrow(drugs)), function(i)
    match_rows(stems_l[[i]], drugs$not_stems[i], ndc_tbl, "ndc", c("generic_desc", "drug_name")),
    character(1))
  out$hcpcs_jcode <- vapply(seq_len(nrow(drugs)), function(i)
    match_rows(stems_l[[i]], drugs$not_stems[i], jcode_tbl, "proc_code", c("proc_desc")),
    character(1))
  out$verified_in_data <- ifelse(is.na(out$ndc_codes) & is.na(out$hcpcs_jcode), "NOT-FOUND", "found")
  gained <- sum(out$verified_in_data == "found" &
                  (is.na(drugs$ndc_codes %||% NA) & is.na(drugs$hcpcs_jcode %||% NA)))
  lost   <- sum(out$verified_in_data == "NOT-FOUND" &
                  !(is.na(drugs$ndc_codes %||% NA) & is.na(drugs$hcpcs_jcode %||% NA)))
  out <- out |> select(-ingredient_u)
  readr::write_csv(out, path)
  message("codes written to ", path,
          " | not found for ", sum(out$verified_in_data == "NOT-FOUND"), " of ", nrow(out),
          " drugs | gained codes: ", gained, " | LOST codes: ", lost,
          if (lost) "  <- inspect before freezing" else "")
  out
}

# G12 is a real decision with a real consequence: the R23 switch list and the
# R21 amivantamab pair in the CSV are only correct for one rule version.
nl_assert_rule_version <- function(drugs, ov = list()) {
  v <- nl_dec("D_G12_RULE_VERSION", ov)
  amiv <- nl_ing_with_role(drugs, NL_ROLE_ELIGIBLE)
  has_amiv <- any(grepl("AMIVANTAMAB", amiv, fixed = TRUE))
  if (identical(v, "2026-08-28") && !has_amiv)
    stop("D_G12_RULE_VERSION = 2026-08-28 requires the amivantamab R21 pair in drug_code_list.csv")
  if (!identical(v, "2026-08-28") && has_amiv)
    warning("drug_code_list.csv carries the 08/28/2026 amivantamab R21 pair but ",
            "D_G12_RULE_VERSION = ", v, " - the two must match the Flatiron cut.")
  message("LOT rule version in force (decision D_G12_RULE_VERSION / gap ",
          nl_dec_gap("D_G12_RULE_VERSION"), "): ", v)
  invisible(v)
}

# ============================================================================
# 4. EPISODE LAYER  (R1/R2/R3)
#
# Flatiron: an episode = an administration or a NON-CANCELLED ORDER; for
# abstracted orals, any day within the abstracted span (R3 - NO OPTUM ANALOGUE).
#
# Optum's closest analogue is t_onc_medications, because it is the ONLY source
# that unions oral + note-mentioned drugs - which is exactly what Optum's own
# LOT-A cannot see. It inherits the t_onc_* population gate (cancer dx +
# physician notes available), which is what makes LOT-A and LOT-B share a
# denominator. Building LOT-B on the raw structured tables instead would run it
# on a LARGER population than LOT-A and confound rule differences with
# population differences - so those are a sensitivity only.
#
# Source gating is decision D_EPISODE_SOURCE_BUILD, not a Flatiron rule.
# Restricting by ACTION alone is not enough: case MI-04 - a stale reconciled
# outside-record row reading "Pt on erlotinib" (action='is on',
# data_source='provider_notes') - flips monotherapy to FALSE and renames the
# 2L regimen. Same contamination in ORAL1L-02 and GAP-03.
#
# NOTE ON DE-DUPLICATION. Rows are de-duplicated WITHIN data_source only
# (ptid, drug_canon, ep_date, data_source). Collapsing to one row per drug-day
# before the build is chosen let a same-day provider_notes or claims copy win
# the distinct() and DELETE the genuine administration from the narrow build -
# a silent, order-dependent loss that moves line starts and therefore gaps. The
# day-level collapse happens later, inside nl_lot_b(), under D_G8.
# ============================================================================

NL_EPISODE_ACTIONS      <- c("administered", "prescribed", "started")
NL_EPISODE_SOURCES      <- c("rx_adm", "rx_presc", "proc")            # narrow / primary
NL_EPISODE_SOURCES_WIDE <- c(NL_EPISODE_SOURCES, "provider_notes", "clm_rx", "clm_med_serv")
NL_EPISODE_ACTIONS_WIDE <- c(NL_EPISODE_ACTIONS, "filled", "is on")
# Priority used only to make the day-level collapse deterministic: an EHR
# administration outranks a claim, which outranks a note mention.
NL_SOURCE_PRIORITY <- c("rx_adm", "proc", "rx_presc", "clm_med_serv", "clm_rx", "provider_notes")

nl_build_spec <- function(build = c("narrow", "wide")) {
  build <- match.arg(build)
  if (build == "narrow")
    list(build = "narrow", sources = NL_EPISODE_SOURCES,      actions = NL_EPISODE_ACTIONS)
  else
    list(build = "wide",   sources = NL_EPISODE_SOURCES_WIDE, actions = NL_EPISODE_ACTIONS_WIDE)
}

nl_episodes <- function(con, drugs, ptids = NULL,
                        build = nl_dec("D_EPISODE_SOURCE_BUILD"),
                        include_structured = FALSE) {
  spec  <- nl_build_spec(build)
  stems <- nl_pull_stems(drugs)     # eligible UNION supportive - see nl_pull_stems

  onc <- mc_tbl(con, "onc_medications") |>
    filter(sql(paste(nl_like_any("generic_desc", stems), "OR",
                     nl_like_any("drug_name",    stems)))) |>
    filter(tolower(action) %in% spec$actions, tolower(data_source) %in% spec$sources) |>
    select(ptid, drug = generic_desc, drug_name, ep_date = action_date,
           route, data_source) |>
    mutate(src = "onc_medications")
  if (!is.null(ptids)) onc <- onc |> filter(ptid %in% ptids)

  eps <- collect(onc)

  if (include_structured) {
    # SENSITIVITY ONLY - breaks the shared denominator with LOT-A (see above).
    # t_administrations is anchored on order_date because ADMIN_DATE is
    # frequently null (precedent finding).                            # UNVERIFIED
    adm <- mc_tbl(con, "administrations") |>
      filter(sql(paste(nl_like_any("generic_desc", stems), "OR",
                       nl_like_any("drug_name",    stems)))) |>
      mutate(ep_date = coalesce(order_date, admin_date)) |>
      select(ptid, drug = generic_desc, drug_name, ep_date, route) |>
      mutate(data_source = "rx_adm", src = "administrations")
    rx <- mc_tbl(con, "prescription") |>
      filter(sql(paste(nl_like_any("generic_desc", stems), "OR",
                       nl_like_any("drug_name",    stems)))) |>
      select(ptid, drug = generic_desc, drug_name, ep_date = rxdate, route) |>
      mutate(data_source = "rx_presc", src = "prescription")
    if (!is.null(ptids)) { adm <- adm |> filter(ptid %in% ptids); rx <- rx |> filter(ptid %in% ptids) }
    eps <- bind_rows(eps, collect(adm), collect(rx))
  }

  eps |>
    filter(!is.na(ep_date)) |>
    mutate(ep_date = as.Date(ep_date), build = spec$build) |>
    nl_prepare_episodes(drugs)
}

# ---- route normalisation ---------------------------------------------------
# is_oral used to be `tolower(route) == "oral"` on a coalesce() that PREFERRED
# the episode's own free-text route. t_onc_medications.route is varchar(30) free
# text ("PO", "Oral Tablet", "ORAL;IV", "IV premed"), so in production the test
# was FALSE for every oral TKI, R19's oral gap exemption never fired, >120-day
# holidays in an oral 1L advanced the line, and docetaxel was demoted from 2L to
# 3L - patients silently leaving the cohort. The regression suite could not see
# it because the fixtures write the literal string "oral".
#
# Rule now: an explicit oral token in the EPISODE route wins; an explicit
# non-oral token in the episode route wins next (so etoposide "IV|oral" given
# IV is not called oral); otherwise fall back to the curated per-ingredient
# route from drug_code_list.csv, where "IV|oral" counts as oral-capable. The
# curated side is now the canonical NL_ROUTE_TOKENS encoding, so the fallback no
# longer depends on which order a human happened to type the two routes in.
# BEFORE THE PRIMARY RUN: DESCRIBE t_onc_medications.route, inventory the
# observed value set (nl_route_audit) and freeze it.        # UNVERIFIED
nl_route_is_oral <- function(x) {
  x <- toupper(dplyr::coalesce(as.character(x), ""))
  grepl("(^|[^A-Z])(ORAL|PO|P\\.O\\.|BY MOUTH|PER OS|SUBLINGUAL|BUCCAL)([^A-Z]|$)", x)
}
nl_route_is_nonoral <- function(x) {
  x <- toupper(dplyr::coalesce(as.character(x), ""))
  grepl("(^|[^A-Z])(IV|INTRAVENOUS|INFUSION|SC|SUBCUT[A-Z]*|IM|INTRAMUSCULAR|INJECT[A-Z]*|TOPICAL|TD|TRANSDERMAL)([^A-Z]|$)", x)
}
nl_route_audit <- function(eps) {
  eps |> count(route_raw, is_oral, sort = TRUE)
}

# Canonicalise, normalise route, dedupe WITHIN data_source. It deliberately does
# NOT apply the D_G7 exclusion and does NOT collapse to one row per drug-day:
# both of those are decision-dependent and now live in nl_lot_b(), so that
# nl_decision_sensitivity() can actually turn them on and off.
nl_prepare_episodes <- function(eps, drugs) {
  need <- c("ptid", "drug", "ep_date")
  miss <- setdiff(need, names(eps))
  if (length(miss)) stop("nl_prepare_episodes(): missing columns ", paste(miss, collapse = ", "))
  if (!"route"       %in% names(eps)) eps$route       <- NA_character_
  if (!"data_source" %in% names(eps)) eps$data_source <- NA_character_
  if (!"build"       %in% names(eps)) eps$build       <- NA_character_
  if (!"drug_name"   %in% names(eps)) eps$drug_name   <- NA_character_

  # Canonicalise on generic_desc + drug_name together, so a brand-only string
  # still resolves. An already-canonical drug_canon (the regression fixtures
  # supply one) is kept as-is rather than round-tripped through the stems.
  eps$ep_date <- as.Date(eps$ep_date)
  hay  <- paste(dplyr::coalesce(eps$drug, ""), dplyr::coalesce(eps$drug_name, ""))
  cano <- nl_canon(hay, drugs)
  if ("drug_canon" %in% names(eps)) {
    keep <- !is.na(eps$drug_canon) & eps$drug_canon %in% drugs$ingredient_u
    cano[keep] <- eps$drug_canon[keep]
  }
  eps$drug_canon <- cano

  unmapped <- sum(is.na(eps$drug_canon))
  if (unmapped) message("nl_prepare_episodes(): ", unmapped,
                        " rows did not map to any ingredient and were dropped")
  eps <- eps |> filter(!is.na(drug_canon), !is.na(ep_date))
  if (!nrow(eps)) { eps$route_raw <- character(0); eps$is_oral <- logical(0); return(eps) }

  rt <- tibble::tibble(drug_canon = drugs$ingredient_u, route_tbl = tolower(drugs$route))
  eps <- eps |> left_join(rt, by = "drug_canon")
  eps$route_raw <- eps$route
  ep_oral    <- nl_route_is_oral(eps$route_raw)
  ep_nonoral <- nl_route_is_nonoral(eps$route_raw)
  tbl_oral   <- nl_route_is_oral(eps$route_tbl)
  eps$is_oral <- ifelse(ep_oral, TRUE, ifelse(ep_nonoral, FALSE, tbl_oral))
  n_conflict <- sum(!is.na(eps$route_raw) & nzchar(dplyr::coalesce(eps$route_raw, "")) &
                      (ep_oral | ep_nonoral) & (ep_oral != tbl_oral))
  if (n_conflict)
    message("nl_prepare_episodes(): ", n_conflict, " episode(s) whose source route disagrees ",
            "with drug_code_list.csv route (episode route wins; audit with nl_route_audit())")
  n_unknown <- sum(!ep_oral & !ep_nonoral)
  if (n_unknown)
    message("nl_prepare_episodes(): ", n_unknown, " episode(s) with an unrecognised route ",
            "string fell back to the curated per-ingredient route")

  eps |>
    select(-route_tbl) |>
    distinct(ptid, drug_canon, ep_date, data_source, .keep_all = TRUE) |>
    arrange(ptid, ep_date, drug_canon)
}

# A regimen / drug set is stored as ingredients joined by "+". Test membership on
# the SET, never with a substring match - "DOCETAXEL" must not be found inside a
# longer ingredient name, and a set predicate is what section 4 of the
# adversarial report actually specifies.
nl_set_split <- function(x) {
  if (length(x) != 1L || is.na(x) || !nzchar(x)) return(character(0))
  str_trim(str_split(x, "\\+")[[1]])
}
nl_set_has <- function(x, ing) ing %in% nl_set_split(x)

# Merge comma-separated decision-provenance tags into one sorted, deduped string.
nl_join_decs <- function(v) {
  tk <- unlist(strsplit(paste(stats::na.omit(v), collapse = ","), ",", fixed = TRUE))
  tk <- str_trim(tk); tk <- tk[nzchar(tk)]
  paste(sort(unique(tk)), collapse = ",")
}

# GUARD RAIL: no EXCL ingredient may reach a regimen - but ONLY when D_G7 says
# the exclusion is in force. The unconditional version made the decision's own
# alternative branch impossible to run: the sweep set G7 = no_exclusion_list and
# the guard rail then stopped the pipeline.
nl_assert_no_excluded <- function(eps, idx, ov = list(), where = "") {
  if (!identical(nl_dec("D_G7_SUPPORTIVE_EXCLUSION", ov), "apply_excl_list")) return(invisible(TRUE))
  bad <- intersect(unique(eps$drug_canon), idx$exclude)
  if (length(bad))
    stop("GUARD RAIL FAILED", if (nzchar(where)) paste0(" (", where, ")") else "",
         ": excluded (EXCL:supportive) ingredient entered the episode set: ",
         paste(bad, collapse = ", "))
  invisible(TRUE)
}

# ============================================================================
# 5. LOT-B  -  Flatiron rules, applied per patient
# ============================================================================

# ---- R18 arithmetic (G4) ---------------------------------------------------
nl_gap_len <- function(d1, d2, ov = list()) {
  raw <- as.numeric(as.Date(d2) - as.Date(d1))
  switch(nl_dec("D_G4_GAP_ARITHMETIC", ov),
         date_difference  = raw,
         intervening_days = raw - 1,
         stop("D_G4_GAP_ARITHMETIC: unhandled value"))
}
nl_gap_exceeds <- function(len) is.finite(len) & len > NL$gap_days

# ---- 28-day boundary (G11) -------------------------------------------------
# TRUE if `days` is inside a window of `w` days measured from the line start.
nl_in_window <- function(days, w = NL$regimen_window_days, ov = list()) {
  switch(nl_dec("D_G11_WINDOW_BOUNDARY", ov),
         inclusive = days <= w,
         exclusive = days <  w,
         stop("D_G11_WINDOW_BOUNDARY: unhandled value"))
}

# ---- R18 pooled-sequential gap series --------------------------------------
# GUARD RAIL. R18's prose is pooled-sequential: "looking across all drugs...
# between any two SEQUENTIAL drug episodes". Its figure annotation reads
# last-episode-of-B to last-episode-of-A. We resolve in favour of the prose.
# The consequence of getting this wrong is large and DIRECTIONAL: on a platinum
# doublet with a dropped platinum - one of the commonest patterns preceding 2L
# docetaxel - the figure reading manufactures a spurious 2L and demotes
# docetaxel to 3L, silently shrinking the cohort (case GAP-04).
nl_assert_r18_reading <- function(ov = list()) {
  if (!identical(nl_dec("D_R18_READING", ov), "pooled_sequential"))
    stop("GUARD RAIL: the LOT-B engine refuses to run under D_R18_READING = ",
         nl_dec("D_R18_READING", ov),
         ". R18's prose is pooled-sequential; the figure annotation's ",
         "last-episode-of-B-to-last-episode-of-A reading MANUFACTURES A SPURIOUS 2L ",
         "on a dropped-platinum doublet and DEMOTES DOCETAXEL TO 3L, silently ",
         "shrinking the cohort (case GAP-04). Use nl_r18_reading_diagnostic() if ",
         "you want to quantify the delta; it is never on the primary path.")
  invisible(TRUE)
}

# The gap series actually consumed by nl_assign_lines_one(): gaps[i] is the gap
# between sorted distinct episode date i and i+1. (This function used to be
# defined and never called, which meant an auditor reading it was auditing dead
# code while the loop inlined its own arithmetic.)
nl_pooled_gaps <- function(ep_dates, ov = list()) {
  nl_assert_r18_reading(ov)
  d <- sort(unique(as.Date(ep_dates)))
  if (length(d) < 2) return(numeric(0))
  vapply(seq_len(length(d) - 1L), function(i) nl_gap_len(d[i], d[i + 1L], ov), numeric(1))
}

# NEVER on the primary path. Quantifies the delta the figure reading would
# introduce, for the methods write-up only.
nl_r18_reading_diagnostic <- function(eps, ov = list()) {
  d <- sort(unique(eps$ep_date))
  pooled <- if (length(d) > 1)
    vapply(seq_len(length(d) - 1L), function(i) nl_gap_len(d[i], d[i + 1L], ov), numeric(1)) else numeric(0)
  last_by_drug <- eps |> group_by(drug_canon) |> summarise(last_ep = max(ep_date), .groups = "drop") |>
    arrange(last_ep) |> pull(last_ep)
  figure <- if (length(last_by_drug) > 1)
    vapply(seq_len(length(last_by_drug) - 1L),
           function(i) nl_gap_len(last_by_drug[i], last_by_drug[i + 1L], ov), numeric(1)) else numeric(0)
  list(pooled_max = if (length(pooled)) max(pooled) else NA_real_,
       figure_max = if (length(figure)) max(figure) else NA_real_,
       pooled_advances = sum(nl_gap_exceeds(pooled)),
       figure_advances = sum(nl_gap_exceeds(figure)),
       would_differ    = sum(nl_gap_exceeds(pooled)) != sum(nl_gap_exceeds(figure)))
}

# ---- R19 oral gap exemption (G5) -------------------------------------------
nl_gap_oral_exempt <- function(oral_prev, oral_now, ov = list()) {
  switch(nl_dec("D_G5_ORAL_GAP_SCOPE", ov),
         both_endpoints_oral  = isTRUE(oral_prev) && isTRUE(oral_now),
         either_endpoint_oral = isTRUE(oral_prev) || isTRUE(oral_now),
         no_oral_exemption    = FALSE,
         stop("D_G5_ORAL_GAP_SCOPE: unhandled value"))
}

# ---- R21 / R22 / R23 non-advancing changes ---------------------------------
# R21 substitutions carry NO day window ("no day window stated"), so a family
# partner never advances the line however late it appears. R22's bevacizumab
# addition likewise carries no window.
nl_non_advancing_change <- function(line_drugs_seen, new_drug, idx, days_since_start, ov = list()) {
  if (new_drug %in% idx$add_r22 && length(line_drugs_seen))
    return(list(non_advancing = TRUE, rule = "R22"))
  for (fam in idx$sub_families) {
    if (new_drug %in% fam && any(setdiff(fam, new_drug) %in% line_drugs_seen))
      return(list(non_advancing = TRUE, rule = "R21"))
  }
  if (new_drug %in% idx$sw_r23 && nl_in_window(days_since_start, NL$switch_window_days, ov))
    return(list(non_advancing = TRUE, rule = "R23"))
  if (nl_in_window(days_since_start, NL$regimen_window_days, ov))
    return(list(non_advancing = TRUE, rule = "R9"))
  list(non_advancing = FALSE, rule = NA_character_)
}

# ---- maintenance-eligible introductions that must NOT trigger G1 ------------
# R13/R15/R16 condition maintenance on prior membership in the induction
# combination, so a maintenance-eligible drug satisfying them is ALREADY in the
# line's drug set and can never look like a new drug. The only introductions
# that reach here are:
#   * durvalumab, for which R14 explicitly provides a no-combination route; and
#   * under the G3 alternative, any R13/R15-eligible switch-maintenance agent.
# In either case the introduction is deferred to nl_flag_maintenance(), and the
# line number is NOT advanced regardless of whether the maintenance test then
# passes (MNT-07 principle).
#
# Returns list(defer, gap): `gap` is the provenance tag to record, and is NA for
# the R14 branch because R14 is a TRANSCRIBED RULE, not a substituted decision.
# (The previous version stamped every deferral with G3, corrupting dec_applied
# for R14 patients.)
nl_maint_defers_advance <- function(new_drug, line, idx, ov = list(), eps = NULL, dt = NULL) {
  if (!isTRUE(NL$maint_1l_only) || line != 1L) return(list(defer = FALSE, gap = NA_character_))
  if (new_drug %in% idx$maint_r14) {
    if (identical(nl_dec("D_R14_FAILED_TEST", ov), "advance") &&
        !is.null(eps) && !is.null(dt)) {
      # Local pre-check of the R14 monotherapy condition: if anything other than
      # the R14 agent still has an episode on or after this date, R14 cannot
      # succeed and this branch says the line advances.
      # Bounded, for the same reason as D_G1B_CONTINUATION_HORIZON: an unbounded
      # scan to end of follow-up would let a much later episode decide the line
      # assigned here, which is the temporal leakage this engine no longer
      # permits anywhere. Same registered horizon so the two cannot diverge.
      h_r14  <- dt + nl_dec_num("D_G1B_CONTINUATION_HORIZON", ov)
      others <- eps$drug_canon[eps$ep_date >= dt & eps$ep_date <= h_r14 &
                               !eps$drug_canon %in% idx$maint_r14]
      if (length(others)) return(list(defer = FALSE, gap = "R14"))
    }
    return(list(defer = TRUE, gap = NA_character_))          # R14, explicit rule
  }
  # G3 alternative: allow an agent that was never in the 1L combination to be
  # read as switch maintenance. It must still MEET THE EPISODE THRESHOLD the
  # rule it is claiming states -- R13 >= 2, R15 >= 3. Deferring on drug identity
  # alone let ONE pembrolizumab episode hold the line open and turn docetaxel
  # from 3L into 2L while the real maintenance test failed and is_maint stayed
  # FALSE: the branch asserted maintenance that the maintenance test rejects.
  if (identical(nl_dec("D_G3_SWITCH_MAINTENANCE", ov), "allow_switch_maintenance") &&
      new_drug %in% c(idx$maint_r13, idx$maint_r15)) {
    thr <- if (new_drug %in% idx$maint_r15) NL$maint_episodes_r15 else NL$maint_episodes_r13
    # Maintenance counting is forward-looking by construction, so the scan
    # must be FINITE: the G8B span (Inf by default) alone is not a bound.
    # Counted through nl_maint_count() so D_G8_MAINT_EPISODE_COUNT applies here
    # exactly as in nl_maint_test().
    h      <- dt + min(nl_dec_num("D_G8B_MAINT_MAX_SPAN", ov),
                       nl_dec_num("D_G3B_SWITCH_MAINT_HORIZON", ov))
    in_win <- eps$drug_canon == new_drug & eps$ep_date >= dt & eps$ep_date <= h
    n_ep   <- nl_maint_count(eps$ep_date[in_win], ov)
    if (n_ep >= thr)
      return(list(defer = TRUE, gap = nl_dec_gap("D_G3_SWITCH_MAINTENANCE")))
  }
  list(defer = FALSE, gap = NA_character_)
}

# ---- G2 local test: are we inside a 1L maintenance phase right now? ----
# Declared as part of D_G2_GAP_VS_MAINTENANCE, not as a Flatiron rule. The
# phase is confirmed by the REAL maintenance test (R13/R15 thresholds, R16
# duration, G3/G8/G8B) over the 1L episodes up to the pre-gap date `prev`
# only: past-only, so a later resumption cannot certify the phase it follows.
nl_in_maint_phase <- function(eps, line_start, prev, line, idx, ov = list()) {
  if (!isTRUE(NL$maint_1l_only) || line != 1L) return(FALSE)
  e1 <- eps[eps$ep_date >= line_start & eps$ep_date <= prev, c("drug_canon", "ep_date"), drop = FALSE]
  if (!nrow(e1)) return(FALSE)
  any(vapply(nl_maint_specs(idx), function(sp)
    isTRUE(nl_maint_test(e1, sp$set, sp$mode, sp$thr, sp$id, idx, ov)$pass), logical(1)))
}

# ---- Stage 2: R20 pre-index prune, then R7/R8 adjuvant ----------------------
# ORDER MATTERS: R20 runs BEFORE R7/R8.
#
# R7 scoping fix: the adjuvant candidate is the gap-compliant block OF THE GIVEN
# ELIGIBLE THERAPY - the regimen that starts the series (its first episode plus
# other agents inside the 28-day regimen window) - not every episode the
# 120-day chain happens to reach. Taking the unrestricted chain let a later,
# unrelated course (docetaxel 99 days after the doublet, MI-07) extend the block
# past index + 14d, criterion #2 then failed, and the adjuvant branch could
# never fire. With the block scoped to the index course, MI-07 reproduces its
# documented behaviour: 2L under the abstracted index date, 1L under the
# +21-day structured surrogate - which is the whole point of that probe.
nl_prune_and_anchor <- function(eps, index_date, ov = list()) {
  out <- list(eps = eps, dropped_adjuvant = 0L, note = NA_character_)
  if (!nrow(eps)) return(out)
  index_date <- as.Date(index_date)
  lo <- index_date - NL$index_preallowance_days
  hi <- index_date + NL$index_preallowance_days

  # --- R20: the gap rule also applies to pre-index episodes; episodes prior to
  #     the gap are DISCARDED, then the start-of-1L rule is applied thereafter.
  pre_dates <- sort(unique(eps$ep_date[eps$ep_date < index_date]))
  if (length(pre_dates) > 1) {
    g   <- vapply(seq_len(length(pre_dates) - 1L),
                  function(i) nl_gap_len(pre_dates[i], pre_dates[i + 1L], ov), numeric(1))
    big <- which(nl_gap_exceeds(g))
    if (length(big)) {
      keep_from <- pre_dates[max(big) + 1L]
      eps <- eps |> filter(ep_date >= keep_from)
      out$note <- paste0("R20 pre-index prune from ", keep_from)
    }
  }
  if (!nrow(eps)) { out$eps <- eps; return(out) }

  # --- R7/R8. Criterion #1 first episode earlier than index - 14d;
  #     criterion #2 last episode OF THAT THERAPY earlier than index + 14d.
  blk_start <- min(eps$ep_date)
  fe        <- tapply(as.numeric(eps$ep_date), eps$drug_canon, min)   # names kept
  course    <- names(fe)[nl_in_window(fe - as.numeric(blk_start),
                                      NL$regimen_window_days, ov)]
  chain <- sort(unique(eps$ep_date[eps$drug_canon %in% course]))
  blk_end <- chain[length(chain)]
  if (length(chain) > 1) {
    g   <- vapply(seq_len(length(chain) - 1L),
                  function(i) nl_gap_len(chain[i], chain[i + 1L], ov), numeric(1))
    cut <- which(nl_gap_exceeds(g))
    if (length(cut)) blk_end <- chain[cut[1]]
  }

  if (blk_start < lo && blk_end < hi) {
    # ADJUVANT: the whole index course is curative-intent, not a line in the
    # advanced setting. The SUBSEQUENT therapy is 1L.
    n0  <- nrow(eps)
    eps <- eps |> filter(ep_date > blk_end)
    out$dropped_adjuvant <- n0 - nrow(eps)
    out$note <- paste(stats::na.omit(c(out$note,
                                       paste0("R7 adjuvant block ", blk_start, "..", blk_end,
                                              " (", paste(sort(course), collapse = "+"), ") discarded"))),
                      collapse = "; ")
    if (!nrow(eps)) out$note <- paste(out$note, "| all-adjuvant, no advanced-setting line")
  } else {
    # NOT adjuvant. R8 example #2: an episode before index-14d that belongs to a
    # non-adjuvant course is DISCARDED for line-start purposes, not used to
    # start the line.
    eps <- eps |> filter(ep_date >= lo)
  }
  out$eps <- eps
  out
}

# ---- Core per-patient line assignment --------------------------------------
# PRINCIPLE (adversarial test, case MNT-07): the line number is a STATE THAT
# PERSISTS ABSENT A STATED TRIGGER, not one that increments absent a stated
# exemption. A failed maintenance test does NOT create a new line. Only R18
# (>120d gap) affirmatively advances a line in the documented ruleset.
# Everything else that advances here does so under a DECLARED DECISION and is
# tagged with its gap number.
#
#   eps        : data frame for ONE patient - ptid, drug_canon, ep_date, is_oral
#   index_date : advanced-NSCLC diagnosis date (R5; itself decision D_INDEX_DATE)
#   idx        : nl_role_index(drugs), computed once by the caller
#   activity_start : optional; R6 "start of structured activity"
#                    (decision D_STRUCTURED_ACTIVITY_START). NULL => gate skipped.
nl_assign_lines_one <- function(eps, index_date, idx, ov = list(), activity_start = NULL) {
  need <- c("ptid", "drug_canon", "ep_date")
  miss <- setdiff(need, names(eps))
  if (length(miss)) stop("nl_assign_lines_one(): missing columns ", paste(miss, collapse = ", "))
  if (!"is_oral" %in% names(eps)) eps$is_oral <- FALSE
  nl_assert_r18_reading(ov)     # GUARD RAIL - pooled-sequential R18 only
  empty <- eps[0, , drop = FALSE]
  empty$line <- integer(0); empty$advance_reason <- character(0)
  empty$dec_applied <- character(0); empty$anchor_note <- character(0)
  if (!nrow(eps)) return(empty)

  eps <- eps |> filter(!is.na(ep_date)) |> arrange(ep_date, drug_canon)
  if (!nrow(eps)) return(empty)

  # R6: 1L must start after the start of structured activity. Undefined by
  # Flatiron (F-Q3) and imprecise in Optum; if not supplied, the gate is skipped
  # and that is recorded rather than silently assumed satisfied.
  if (!is.null(activity_start) && !is.na(activity_start)) {
    eps <- eps |> filter(ep_date >= as.Date(activity_start))
    act_note <- paste0("R6 structured-activity gate at ", as.Date(activity_start),
                       " (decision D_STRUCTURED_ACTIVITY_START / F-Q3)")
  } else {
    act_note <- "R6 structured-activity gate SKIPPED - no start supplied (F-Q3)"
  }
  if (!nrow(eps)) return(empty)

  anc <- nl_prune_and_anchor(eps, index_date, ov)
  eps <- anc$eps
  if (!nrow(eps)) return(empty)

  dates <- sort(unique(eps$ep_date))
  gaps  <- nl_pooled_gaps(dates, ov)     # R18, pooled-sequential (guard rail inside)
  line       <- 1L
  line_start <- dates[1]
  line_drugs <- character(0)

  line_of_date    <- integer(length(dates))
  reason_of_date  <- rep(NA_character_, length(dates))
  dec_of_date     <- rep("",            length(dates))

  for (i in seq_along(dates)) {
    dt        <- dates[i]
    today     <- eps |> filter(ep_date == dt)
    drugs_now <- sort(unique(today$drug_canon))
    oral_now  <- nrow(today) > 0 && all(today$is_oral, na.rm = TRUE)
    decs      <- character(0)
    advance   <- FALSE
    reason    <- NA_character_

    if (i > 1L) {
      prev      <- dates[i - 1L]
      prev_rows <- eps |> filter(ep_date == prev)
      oral_prev <- nrow(prev_rows) > 0 && all(prev_rows$is_oral, na.rm = TRUE)
      drugs_prev<- sort(unique(prev_rows$drug_canon))

      gap  <- gaps[i - 1L]
      decs <- c(decs, nl_dec_gap("D_G4_GAP_ARITHMETIC"))

      if (nl_gap_exceeds(gap)) {
        if (nl_gap_oral_exempt(oral_prev, oral_now, ov)) {                 # R19
          decs <- c(decs, nl_dec_gap("D_G5_ORAL_GAP_SCOPE"))
        } else if (nl_in_maint_phase(eps, line_start, prev, line, idx, ov)) {
          # G2: R18 and R13/R17 both fire literally; nothing states which wins.
          decs <- c(decs, nl_dec_gap("D_G2_GAP_VS_MAINTENANCE"))
          if (identical(nl_dec("D_G2_GAP_VS_MAINTENANCE", ov), "R18_wins")) {
            advance <- TRUE; reason <- "R18-gap-in-maintenance(G2)"
          }
        } else {
          advance <- TRUE; reason <- "R18-gap"
        }
      }

      if (!advance) {
        # New eligible drugs that are not covered by R9/R21/R22/R23.
        new_drugs <- setdiff(drugs_now, line_drugs)
        dsl <- as.numeric(dt - line_start)
        if (length(new_drugs)) {
          unexplained <- character(0)
          for (nd in new_drugs) {
            na_res <- nl_non_advancing_change(line_drugs, nd, idx, dsl, ov)
            if (isTRUE(na_res$non_advancing)) next
            df <- nl_maint_defers_advance(nd, line, idx, ov, eps = eps, dt = dt)
            if (isTRUE(df$defer)) {
              if (!is.na(df$gap)) decs <- c(decs, df$gap)
              next
            }
            unexplained <- c(unexplained, nd)
          }
          if (length(unexplained)) {
            # THE DOCUMENT STATES NO RULE HERE. Two declared decisions, split by
            # whether the running regimen CONTINUES past this date:
            #   * it continues  -> this is an ADDITION (D_G1B); naming is D_G6
            #   * it has stopped -> this is a REPLACEMENT (D_G1)
            # TEMPORAL LEAKAGE FIX. This previously read
            #   any(eps$drug_canon %in% line_drugs & eps$ep_date >= dt)
            # i.e. it scanned the patient's episodes to the END OF FOLLOW-UP.
            # A rechallenge months later therefore reached back and changed the
            # line number assigned at `dt` -- an earlier docetaxel flipped 2L to
            # 1L purely because of a future carboplatin episode. That makes
            # cohort membership depend on data that did not exist at the index
            # date, which is leakage into an rwOS model, not just an oddity.
            # The clinical question here is only whether the running regimen is
            # STILL RUNNING at `dt`, which is answerable inside the regimen
            # window. Bounded, so the decision is a function of the past and a
            # fixed horizon only.
            horizon   <- dt + nl_dec_num("D_G1B_CONTINUATION_HORIZON", ov)
            continues <- any(eps$drug_canon %in% line_drugs &
                             eps$ep_date >= dt & eps$ep_date <= horizon)
            decs <- c(decs, nl_dec_gap("D_G1_OUT_OF_WINDOW_NEW_DRUG"))
            if (continues) {
              if (identical(nl_dec("D_G1B_POST28_ADDITION", ov), "advance")) {
                advance <- TRUE
                reason  <- paste0("G1B-post28-addition(", paste(unexplained, collapse = "+"), ")")
              }
            } else if (identical(nl_dec("D_G1_OUT_OF_WINDOW_NEW_DRUG", ov), "advance")) {
              advance <- TRUE
              reason  <- paste0("G1-new-drug-out-of-window(", paste(unexplained, collapse = "+"), ")")
            }
          }
        }
      }

      if (advance) {
        line       <- line + 1L
        line_start <- dt
        line_drugs <- character(0)
      }
    }

    line_drugs <- union(line_drugs, drugs_now)
    line_of_date[i]   <- line
    reason_of_date[i] <- reason
    dec_of_date[i]    <- paste(unique(decs), collapse = ",")
  }

  idx_row <- match(eps$ep_date, dates)
  eps$line           <- line_of_date[idx_row]
  eps$advance_reason <- reason_of_date[idx_row]
  eps$dec_applied    <- dec_of_date[idx_row]
  eps$anchor_note    <- paste(stats::na.omit(c(anc$note, act_note)), collapse = " | ")
  eps
}

# ============================================================================
# 5b. MAINTENANCE  (R13, R14, R15, R16, R17)
#
# Maintenance applies in 1L ONLY and NEVER advances the line number. It is
# therefore applied AFTER line assignment, it cannot write to `line`, and it
# asserts that it did not.
#
# A FAILED maintenance test leaves the line number unchanged. That is MNT-07,
# the highest-value single test in the suite: a naive implementation reads
# "fails the 49-day test" as "therefore a new line", returns 3L, and silently
# drops a cohort member. The adjudicated answer is 2L.
#
# The four rules, encoded from drug_code_list.csv lot_role flags:
#   MAINT:R13-2ep     >= 2 continued episodes after a combination drop
#   MAINT:R14-mono    durvalumab monotherapy after any 1L regimen, NO threshold
#   MAINT:R15-3ep     >= 3 continued episodes  (note: 3, not 2 - code literally)
#   MAINT:R16-pair49d nivo + ipi continuing >= 49 DAYS from the drop anchor
# ============================================================================

# Episode count for the maintenance thresholds (G8). Reachable only because the
# day-level collapse in nl_lot_b() is itself conditional on this decision.
nl_maint_count <- function(dates, ov = list()) {
  switch(nl_dec("D_G8_MAINT_EPISODE_COUNT", ov),
         distinct_calendar_days = length(unique(dates)),
         row_count              = length(dates),
         stop("D_G8_MAINT_EPISODE_COUNT: unhandled value"))
}

# The four rule specs, shared by nl_flag_maintenance() and the G2 phase test
# so the two cannot diverge.
nl_maint_specs <- function(idx) list(
  list(set = idx$maint_r13, mode = "episodes",      thr = NL$maint_episodes_r13, id = "R13"),
  list(set = idx$maint_r14, mode = "mono",          thr = NA_integer_,           id = "R14"),
  list(set = idx$maint_r15, mode = "episodes",      thr = NL$maint_episodes_r15, id = "R15"),
  list(set = idx$maint_r16, mode = "duration_pair", thr = NL$maint_days_r16,     id = "R16")
)

# The R16 drop anchor (G9).
nl_drop_anchor <- function(last_ep_of_dropped, ov = list()) {
  switch(nl_dec("D_G9_R16_DROP_ANCHOR", ov),
         last_episode_of_dropped = as.Date(last_ep_of_dropped),
         day_after_last_episode  = as.Date(last_ep_of_dropped) + 1,
         stop("D_G9_R16_DROP_ANCHOR: unhandled value"))
}

# Evaluate ONE maintenance rule against ONE patient's 1L episodes.
#   e1        : 1L episodes for one patient (drug_canon, ep_date)
#   eligible  : the rule's maintenance-eligible ingredient set
#   mode      : "episodes" (R13/R15) | "duration_pair" (R16) | "mono" (R14)
#   threshold : >=n episodes, or >=n days for duration_pair
nl_maint_test <- function(e1, eligible, mode, threshold, rule_id, idx, ov = list()) {
  fail <- function(why) list(pass = FALSE, rule = rule_id, why = why,
                             anchor = as.Date(NA), start = as.Date(NA), end = as.Date(NA),
                             ing = character(0))
  if (!nrow(e1)) return(fail("no 1L episodes"))
  present  <- sort(unique(e1$drug_canon))
  cands    <- intersect(present, eligible)
  if (!length(cands)) return(fail("no eligible agent in 1L"))
  others   <- setdiff(present, eligible)
  if (!length(others)) return(fail("no non-maintenance partner in 1L (nothing to drop)"))

  anchor_raw <- max(e1$ep_date[e1$drug_canon %in% others])
  anchor     <- if (identical(mode, "duration_pair")) nl_drop_anchor(anchor_raw, ov) else anchor_raw

  # "used in combination ... for LONGER THAN ONE DAY" (R13/R15/R16).
  # R14 has no combination clause at all, so it is not tested here.
  if (!identical(mode, "mono")) {
    combo_start <- min(e1$ep_date)
    if (as.numeric(anchor_raw - combo_start) <= 1)
      return(fail("combination not used for longer than one day"))
    # G3: R13/R15/R16 condition maintenance on prior membership in the induction
    # combination. R14 shows Flatiron writes an explicit no-combination route
    # when it means one.
    if (identical(nl_dec("D_G3_SWITCH_MAINTENANCE", ov), "require_prior_combination")) {
      cands <- cands[vapply(cands, function(cd) min(e1$ep_date[e1$drug_canon == cd]) <= anchor_raw,
                            logical(1))]
      if (!length(cands)) return(fail("eligible agent was not in the induction combination (G3 literal reading)"))
    }
  }

  after      <- e1 |> filter(ep_date > anchor)
  if (!nrow(after)) return(fail("nothing continued after the drop"))
  cont_other <- setdiff(sort(unique(after$drug_canon)), eligible)
  if (length(cont_other))
    return(fail(paste0("other drugs continued after the drop: ", paste(cont_other, collapse = "+"))))

  # G8B: optional maximum span for the required episodes.
  max_span <- nl_dec_num("D_G8B_MAINT_MAX_SPAN", ov)
  if (is.finite(max_span))
    after <- after |> filter(as.numeric(ep_date - anchor) <= max_span)
  if (!nrow(after)) return(fail("no continued episodes within the G8B span"))

  if (identical(mode, "episodes")) {
    ok <- cands[vapply(cands, function(cd)
      nl_maint_count(after$ep_date[after$drug_canon == cd], ov) >= threshold, logical(1))]
    if (!length(ok))
      return(fail(paste0("no eligible agent reached ", threshold, " continued episodes")))
    return(list(pass = TRUE, rule = rule_id, why = NA_character_, anchor = anchor,
                start = min(after$ep_date), end = max(after$ep_date),
                ing = sort(unique(after$drug_canon))))
  }

  if (identical(mode, "mono")) {
    # R14: durvalumab monotherapy introduced after any 1L regimen. NO threshold.
    if (!all(after$drug_canon %in% eligible))
      return(fail("continuation is not monotherapy in the eligible agent"))
    if (length(unique(after$drug_canon)) != 1L)
      return(fail("more than one eligible agent continued - not monotherapy"))
    return(list(pass = TRUE, rule = rule_id, why = NA_character_, anchor = anchor,
                start = min(after$ep_date), end = max(after$ep_date),
                ing = sort(unique(after$drug_canon))))
  }

  if (identical(mode, "duration_pair")) {
    # R16: nivo (or nivo-hyal) AND ipi "continued for at least 49 days after the
    # other drugs are dropped". This is the PAIR's continuation span - the
    # adjudicated MNT-07 arithmetic is 2022-04-04 -> 2022-05-16 = 42 days,
    # "narrowly failed", not min(42, 21) = 21, which is what taking each agent's
    # own last episode would give on a q2w nivolumab / q6w ipilimumab schedule.
    nivo <- intersect(idx$maint_r15, present)
    ipi  <- setdiff(intersect(eligible, present), nivo)
    if (!length(nivo) || !length(ipi)) return(fail("R16 needs both a nivolumab agent and ipilimumab in 1L"))
    last_n <- suppressWarnings(max(after$ep_date[after$drug_canon %in% nivo]))
    last_i <- suppressWarnings(max(after$ep_date[after$drug_canon %in% ipi]))
    if (!is.finite(as.numeric(last_n)) || !is.finite(as.numeric(last_i)))
      return(fail("nivolumab or ipilimumab did not continue past the drop"))
    dur <- as.numeric(max(last_n, last_i) - anchor)
    if (dur < threshold)
      return(fail(sprintf(paste("R16 pair continued only %.0f days after the drop anchor %s,",
                                "threshold %d - LINE NUMBER UNCHANGED (persist-absent-trigger)"),
                          dur, format(anchor), threshold)))
    return(list(pass = TRUE, rule = rule_id, why = NA_character_, anchor = anchor,
                start = min(after$ep_date), end = max(after$ep_date),
                ing = sort(unique(after$drug_canon))))
  }

  fail("unhandled maintenance mode")
}

# Flag maintenance across a lined episode frame. Line numbers are NEVER touched.
nl_flag_maintenance <- function(eps_lined, idx, ov = list()) {
  need <- c("ptid", "line", "drug_canon", "ep_date")
  miss <- setdiff(need, names(eps_lined))
  if (length(miss)) stop("nl_flag_maintenance(): missing columns ", paste(miss, collapse = ", "))
  if (!nrow(eps_lined)) {
    eps_lined$is_maint    <- logical(0)
    eps_lined$maint_rule  <- character(0)
    eps_lined$maint_fail  <- character(0)
    return(eps_lined)
  }

  line_before <- eps_lined$line           # GUARD RAIL - see assertion below

  spec <- nl_maint_specs(idx)

  eps_lined$is_maint   <- FALSE
  eps_lined$maint_rule <- NA_character_
  eps_lined$maint_fail <- NA_character_

  for (pt in unique(eps_lined$ptid)) {
    sel <- eps_lined$ptid == pt & eps_lined$line == 1L      # R17: 1L ONLY
    if (!any(sel)) next
    e1 <- eps_lined[sel, c("drug_canon", "ep_date"), drop = FALSE]

    results <- lapply(spec, function(s)
      nl_maint_test(e1, s$set, s$mode, s$thr, s$id, idx, ov))
    passed  <- Filter(function(r) isTRUE(r$pass), results)

    if (length(passed)) {
      # R16 is the most specific (a named pair), then R15, R14, R13.
      ord <- c("R16" = 1, "R15" = 2, "R14" = 3, "R13" = 4)
      r   <- passed[[which.min(ord[vapply(passed, function(x) x$rule, character(1))])]]
      mark <- sel & eps_lined$ep_date > r$anchor & eps_lined$drug_canon %in% r$ing
      eps_lined$is_maint[mark]   <- TRUE
      eps_lined$maint_rule[mark] <- r$rule
    } else {
      # Record WHY each rule failed. This is diagnostic only. It must not, and
      # cannot, change the line number.
      why <- vapply(results, function(r) paste0(r$rule, ": ", r$why), character(1))
      why <- why[!grepl("no eligible agent in 1L", why, fixed = TRUE)]
      if (length(why)) eps_lined$maint_fail[sel] <- paste(why, collapse = " | ")
    }
  }

  # GUARD RAIL: maintenance never advances - or retards - the line number.
  stopifnot(identical(eps_lined$line, line_before))
  eps_lined
}

# ============================================================================
# 5c. LINE SUMMARY AND REGIMEN NAMING  (R9, R21, R22, R23, R24, R26)
# ============================================================================

# R21 "longest duration within the line" (G10), with the exact-tie fork (G10B).
nl_r21_pick <- function(fam_present, line_eps, ov = list()) {
  meas <- vapply(fam_present, function(ing) {
    d <- line_eps$ep_date[line_eps$drug_canon == ing]
    if (!length(d)) return(NA_real_)
    switch(nl_dec("D_G10_R21_DURATION", ov),
           first_to_last_span = as.numeric(max(d) - min(d)),
           episode_count      = as.numeric(length(unique(d))),
           days_covered       = as.numeric(length(unique(d))),   # no dose-span data in Optum
           stop("D_G10_R21_DURATION: unhandled value"))
  }, numeric(1))
  if (all(is.na(meas))) return(list(keep = NA_character_, tie = TRUE))
  top <- fam_present[which(meas == max(meas, na.rm = TRUE))]
  if (length(top) > 1L) {
    if (identical(nl_dec("D_G10B_R21_TIEBREAK", ov), "alphabetical"))
      return(list(keep = sort(top)[1], tie = TRUE))
    return(list(keep = NA_character_, tie = TRUE))   # indeterminate: G10 exact tie
  }
  list(keep = top, tie = FALSE)
}

# Name one line. Returns the regimen string and the naming provenance.
#
# TWO CORRECTIONS FROM THE DEFECT REVIEW:
#  * R21 is applied over the WHOLE LINE. A substitution is by definition a
#    mid-line swap (SA-01 cisplatin on day 63, SA-02 nab-paclitaxel on day 63,
#    SA-07 cisplatin on day 63), so restricting the family test to the 28-day
#    naming window meant nl_r21_pick() was never called, D_G10/D_G10B were dead
#    code, and the substituted-in agent fell through to the G6 "addition" path -
#    producing the self-contradictory name Carboplatin+Cisplatin+Pemetrexed that
#    R21 exists to forbid.
#  * R23 renames only on an actual SWITCH: the candidate must start after the
#    line start, inside the switch window, and the pre-existing background must
#    have stopped at or before it. The old test fired on ADDITIONS too and then
#    DELETED every other agent from the name - the modal "carbo+pem on day 0,
#    pembrolizumab added on day 21 once PD-L1 returns" line was named
#    'PEMBROLIZUMAB' and the platinum doublet vanished from the regimen string.
nl_name_line <- function(line_eps, idx, ov = list()) {
  ls  <- min(line_eps$ep_date)
  dsl <- as.numeric(line_eps$ep_date - ls)
  win <- line_eps[nl_in_window(dsl, NL$regimen_window_days, ov), , drop = FALSE]
  win_set <- sort(unique(win$drug_canon))
  ing  <- win_set
  decs <- nl_dec_gap("D_G11_WINDOW_BOUNDARY")
  rule <- "R9"

  line_ings  <- sort(unique(line_eps$drug_canon))
  # numeric (days since epoch) throughout, so vapply's type contract is exact
  first_seen <- vapply(line_ings, function(x) as.numeric(min(line_eps$ep_date[line_eps$drug_canon == x])), numeric(1))
  last_seen  <- vapply(line_ings, function(x) as.numeric(max(line_eps$ep_date[line_eps$drug_canon == x])), numeric(1))
  names(first_seen) <- line_ings; names(last_seen) <- line_ings

  # R23: a genuine switch, inside the switch window, to a listed targeted/IO
  # agent renames the regimen to that agent and does not advance the line.
  cand <- ing[ing %in% idx$sw_r23]
  cand <- cand[vapply(cand, function(x) {
    if (first_seen[[x]] <= as.numeric(ls)) return(FALSE)
    if (!nl_in_window(first_seen[[x]] - as.numeric(ls), NL$switch_window_days, ov)) return(FALSE)
    bg <- setdiff(line_ings, x)
    !length(bg) || max(last_seen[bg]) <= first_seen[[x]]
  }, logical(1))]

  collapsed <- character(0)
  if (length(cand)) {
    ing <- sort(cand); rule <- "R23"
  } else {
    # R21: collapse each substitution family to the longest-duration member (G10),
    # measured over the whole line.
    for (fam in idx$sub_families) {
      fp <- intersect(line_ings, fam)
      if (length(fp) > 1L && length(intersect(ing, fam))) {
        pick <- nl_r21_pick(fp, line_eps, ov)
        decs <- c(decs, nl_dec_gap("D_G10_R21_DURATION"))
        if (pick$tie) decs <- c(decs, nl_dec_gap("D_G10B_R21_TIEBREAK"))
        if (is.na(pick$keep)) {
          return(list(regimen = NA_character_, rule = "R21-tie",
                      dec = paste(unique(c(decs, "G10-exact-tie")), collapse = ","),
                      n_drugs = NA_integer_, drug_set = paste(win_set, collapse = "+"),
                      post28 = character(0), day28 = character(0), tie = TRUE))
        }
        ing <- sort(union(setdiff(ing, fp), pick$keep))
        collapsed <- union(collapsed, fp)
        rule <- "R21"
      }
    }
  }

  # Additions after the regimen window (G6). R22 settles ADVANCEMENT and is
  # silent on NAMING; R9's "unless otherwise noted" exceptions are unenumerated.
  # A member of a collapsed R21 family is a SUBSTITUTION, not an addition, and
  # must not be double-counted here.
  post <- setdiff(setdiff(line_ings, win_set), collapsed)
  if (length(post)) {
    decs <- c(decs, nl_dec_gap("D_G6_POST28_ADDITION_NAMING"))
    if (identical(nl_dec("D_G6_POST28_ADDITION_NAMING", ov), "retro_name"))
      ing <- sort(union(ing, post))
  }
  # Agents joining EXACTLY on day 28 - reported as their own row (G11). MI-06
  # sits exactly here, and the boundary decides its cohort membership.
  day28 <- line_ings[(first_seen - as.numeric(ls)) == NL$regimen_window_days]
  day28 <- sort(unique(stats::na.omit(day28)))

  list(regimen = paste(ing, collapse = "+"), rule = rule,
       dec = paste(unique(decs), collapse = ","), n_drugs = length(ing),
       drug_set = paste(win_set, collapse = "+"),
       post28 = post, day28 = day28, tie = FALSE)
}

# One row per (ptid, line). R26 makes lines CONTIGUOUS BY CONSTRUCTION: the end
# date is the day before the next line's start, even when a >120-day gap caused
# the advancement. LOT-A does not do this (its dates are administration-bounded),
# so line durations are NOT comparable between the two without this step.
nl_summarise_lines <- function(eps_lined, idx, ov = list(),
                               activity_last = NULL, death_date = NULL) {
  if (!nrow(eps_lined)) return(tibble::tibble())
  nl_assert_no_excluded(eps_lined, idx, ov, "nl_summarise_lines")

  parts <- eps_lined |> group_by(ptid, line) |> group_split()
  out <- purrr::map_dfr(parts, function(le) {
    nm <- nl_name_line(le, idx, ov)
    tibble::tibble(
      ptid            = le$ptid[1],
      line            = le$line[1],
      line_start      = min(le$ep_date),
      last_episode    = max(le$ep_date),
      regimen         = nm$regimen,
      naming_rule     = nm$rule,
      drug_set_window = nm$drug_set,
      n_drugs         = nm$n_drugs,
      post28_added    = paste(nm$post28, collapse = "+"),
      day28_added     = paste(nm$day28,  collapse = "+"),
      regimen_indeterminate = isTRUE(is.na(nm$regimen)),
      has_maint       = any(le$is_maint %||% FALSE, na.rm = TRUE),
      maint_rule      = { mr <- unique(stats::na.omit(le$maint_rule %||% NA_character_))
                          if (length(mr)) paste(mr, collapse = ",") else NA_character_ },
      maint_fail      = { mf <- unique(stats::na.omit(le$maint_fail %||% NA_character_))
                          if (length(mf)) mf[1] else NA_character_ },
      advance_reason  = { ar <- unique(stats::na.omit(le$advance_reason))
                          if (length(ar)) ar[1] else NA_character_ },
      dec_applied     = nl_join_decs(c(le$dec_applied, nm$dec)),
      anchor_note     = le$anchor_note[1]
    )
  }) |> arrange(ptid, line)

  # R26 / R24 line end.
  out <- out |>
    group_by(ptid) |>
    arrange(line, .by_group = TRUE) |>
    mutate(next_start = dplyr::lead(line_start),
           line_end   = dplyr::if_else(!is.na(next_start), next_start - 1, as.Date(NA)),
           end_rule   = dplyr::if_else(!is.na(next_start), "R26", NA_character_)) |>
    ungroup() |> select(-next_start)

  # R24: terminal line. Death is generalized to the LAST DAY OF THE MONTH in
  # Flatiron; Optum's t_patient.DATE_OF_DEATH is varchar(6) and never knew the
  # day, so the two conventions are NOT the same object. State the imputation.
  al <- if (is.null(activity_last)) tibble::tibble(ptid = character(0), activity_last = as.Date(character(0))) else activity_last
  dd <- if (is.null(death_date))    tibble::tibble(ptid = character(0), death_date    = as.Date(character(0))) else death_date
  out <- out |>
    left_join(al, by = "ptid") |> left_join(dd, by = "ptid") |>
    mutate(
      term = is.na(line_end),
      line_end = dplyr::case_when(
        !term ~ line_end,
        term & !is.na(death_date) & !is.na(activity_last) ~ pmin(death_date, activity_last),
        term & !is.na(death_date)                          ~ death_date,
        term & !is.na(activity_last)                       ~ activity_last,
        TRUE ~ last_episode),
      end_rule = dplyr::case_when(
        !term ~ end_rule,
        term & !is.na(death_date)    ~ "R24-death-or-activity",
        term & !is.na(activity_last) ~ "R24-activity",
        TRUE ~ "R24-PROXY(last episode; no activity feed supplied)")
    ) |>
    select(-term)
  out
}

# ---- the full LOT-B pipeline ----------------------------------------------
# index_dates : tibble(ptid, index_date)  [and optionally activity_start]
# `episodes`  : output of nl_prepare_episodes() - canonicalised, route-resolved,
#               NOT G7-filtered and NOT collapsed to one row per drug-day. Both
#               of those steps happen HERE, because both are decision-dependent
#               and the sweep has to be able to change them.
nl_lot_b <- function(episodes, index_dates, drugs, ov = list(),
                     activity_last = NULL, death_date = NULL, idx = NULL) {
  stopifnot(is.data.frame(episodes), is.data.frame(index_dates))
  if (!all(c("ptid", "index_date") %in% names(index_dates)))
    stop("index_dates must have columns ptid, index_date")
  if (any(duplicated(index_dates$ptid)))
    stop("index_dates must be one row per ptid")
  if (is.null(idx)) idx <- nl_role_index(drugs)

  # D_G7: the supportive-care exclusion, applied HERE so that the declared
  # alternative ("no_exclusion_list") is actually runnable.
  if (identical(nl_dec("D_G7_SUPPORTIVE_EXCLUSION", ov), "apply_excl_list") && length(idx$exclude)) {
    n0 <- nrow(episodes)
    episodes <- episodes |> filter(!drug_canon %in% idx$exclude)
    if (n0 - nrow(episodes) > 0 && !isTRUE(getOption("nl.quiet", FALSE)))
      message("D_G7 (gap ", nl_dec_gap("D_G7_SUPPORTIVE_EXCLUSION"), "): dropped ",
              n0 - nrow(episodes), " supportive-care rows")
  }
  nl_assert_no_excluded(episodes, idx, ov, "nl_lot_b input")

  # D_G8: collapse to one row per drug-day, deterministically preferring the
  # highest-priority source. Under "row_count" the rows are kept so that the
  # maintenance thresholds can count them.
  if (identical(nl_dec("D_G8_MAINT_EPISODE_COUNT", ov), "distinct_calendar_days") && nrow(episodes)) {
    episodes <- episodes |>
      mutate(.src_rank = match(dplyr::coalesce(data_source, ""), NL_SOURCE_PRIORITY)) |>
      mutate(.src_rank = dplyr::coalesce(.src_rank, length(NL_SOURCE_PRIORITY) + 1L)) |>
      arrange(ptid, ep_date, drug_canon, .src_rank) |>
      distinct(ptid, drug_canon, ep_date, .keep_all = TRUE) |>
      select(-.src_rank)
  }

  # POPULATION INTEGRITY. This was a bare inner_join, so any patient with
  # episodes but no index-date row VANISHED with no error and no warning -- the
  # denominator changed silently between the episode table and the cohort. An
  # attrition funnel built downstream would never show them, because they were
  # gone before the first funnel step. Missing index dates are a data problem to
  # be surfaced, never absorbed.
  lost <- setdiff(unique(episodes$ptid), unique(index_dates$ptid))
  if (length(lost)) {
    msg <- paste0("nl_lot_b(): ", length(lost),
                  " patient(s) have episodes but no index date and would be dropped ",
                  "silently by the join: ", paste(utils::head(lost, 10), collapse = ", "),
                  if (length(lost) > 10) ", ..." else "")
    if (identical(nl_dec("D_MISSING_INDEX_DATE", ov), "stop")) stop(msg) else warning(msg)
  }
  j <- episodes |> inner_join(index_dates, by = "ptid")
  attr(j, "dropped_no_index_date") <- lost
  if (!nrow(j)) return(list(episodes = j, lines = tibble::tibble(),
                            dropped_no_index_date = lost))

  lined <- j |>
    group_split(ptid) |>
    purrr::map_dfr(function(p) {
      as_start <- if ("activity_start" %in% names(p)) p$activity_start[1] else NULL
      nl_assign_lines_one(p, p$index_date[1], idx, ov, activity_start = as_start)
    })
  if (!nrow(lined)) return(list(episodes = lined, lines = tibble::tibble()))

  lined <- nl_flag_maintenance(lined, idx, ov)
  lines <- nl_summarise_lines(lined, idx, ov, activity_last, death_date)
  list(episodes = lined, lines = lines)
}

# ============================================================================
# 5d. DECISION SENSITIVITY SWEEP
#
# This is what makes the Tier-2 indeterminacy sentinels testable, and it is what
# the cohort builder reads before it emits a number.
#
# THE SWEEP IS FACTORIAL over the determinative decisions. A one-at-a-time sweep
# is not sound here because an answer can be OVER-DETERMINED: GAP-03's docetaxel
# line is 2L under D_G4 = date_difference (a 121-day gap fires R18) AND under
# D_G4 = intervening_days (120 days, R18 silent, but D_G1 then advances on the
# new drug). Neither single perturbation changes the answer; the PAIR
# {G4 = intervening_days, G1 = persist} leaves docetaxel with no line at all.
# A marginal sweep reports that patient as determinate - the exact silent answer
# the design exists to prevent.
#
# Two summaries come out of the grid, and they answer different questions:
#   indeterminate_by : the union of the gap numbers in the SUBSET-MINIMAL
#                      combinations that change THIS patient's answer relative to
#                      the primary settings. This is the indeterminacy claim.
#   pivotal_by       : every decision that changes the answer somewhere in the
#                      grid, holding the others fixed at any setting. This is a
#                      wider diagnostic - it catches a decision that is only
#                      load-bearing jointly (MI-06's D_G6 matters only once the
#                      day-28 boundary is read as exclusive).
#
# D_G1 IS LOAD-BEARING FOR ESSENTIALLY EVERY PATIENT (it is what makes docetaxel
# "2L" at all), so per-patient indeterminacy is judged on the gaps OTHER than G1,
# and G1 is reported once, as a cohort-level caveat. See nl_cohort_2l().
# ============================================================================

# Tier-2 assertion. `want` must be in the MINIMAL flip set (indeterminate_by);
# `pivotal_only` need only be in pivotal_by. Returns the failure strings.
nl_tier2_check <- function(sw, want, pivotal_only = NULL, an = list(line = NA, regimen = NA)) {
  spl <- function(x) { z <- str_trim(str_split(dplyr::coalesce(x, ""), ",")[[1]]); z[nzchar(z)] }
  if (!isTRUE(sw$indeterminate))
    return(paste0("SILENT ANSWER: engine returned line=", an$line, " regimen='", an$regimen,
                  "' without flagging indeterminacy. Expected the pre-specified decision(s) ",
                  paste(c(want, pivotal_only), collapse = "/"), " to be load-bearing."))
  fails <- character(0)
  missing_g <- setdiff(want, spl(sw$indeterminate_by))
  if (length(missing_g))
    fails <- c(fails, paste0("flagged indeterminate by {", sw$indeterminate_by, "} (pivotal {",
                             sw$pivotal_by, "}) but the expected gap(s) {",
                             paste(missing_g, collapse = ","), "} are not in the minimal flip set"))
  missing_p <- setdiff(pivotal_only, spl(sw$pivotal_by))
  if (length(missing_p))
    fails <- c(fails, paste0("pivotal {", sw$pivotal_by, "} lacks the expected jointly-load-bearing gap(s) {",
                             paste(missing_p, collapse = ","), "}"))
  fails
}

nl_target_answer <- function(res, target = NL_TARGET, ov = list()) {
  ln <- res$lines
  blank <- list(line = NA_integer_, regimen = NA_character_, mono = NA,
                maint_1l = NA, maint_rule_1l = NA_character_)
  if (!nrow(ln)) return(blank)
  l1 <- ln |> filter(line == 1L)
  m_flag <- if (nrow(l1)) isTRUE(l1$has_maint[1]) else FALSE
  m_rule <- if (nrow(l1)) l1$maint_rule[1] else NA_character_
  hit <- ln |> filter(vapply(drug_set_window, nl_set_has, logical(1), target))
  if (!nrow(hit)) { blank$maint_1l <- m_flag; blank$maint_rule_1l <- m_rule; return(blank) }
  hit <- hit |> arrange(line) |> slice(1)
  # The monotherapy predicate FOLLOWS D_G6: under retro_name the recomputed
  # regimen is the object the RWDAP selector would see, so it is the object the
  # predicate must be evaluated on. Otherwise the naming decision could move the
  # regimen string while leaving cohort membership untouched.
  mono <- if (identical(nl_dec("D_G6_POST28_ADDITION_NAMING", ov), "retro_name"))
    identical(nl_set_split(hit$regimen), target)
  else
    identical(nl_set_split(hit$drug_set_window), target)
  list(line = as.integer(hit$line), regimen = hit$regimen, mono = mono,
       maint_1l = m_flag, maint_rule_1l = m_rule)
}

nl_answer_key <- function(a)
  paste(ifelse(is.na(a$line), "NA", a$line),
        ifelse(is.na(a$regimen), "NA", a$regimen),
        ifelse(is.na(a$mono), "NA", a$mono),
        ifelse(is.na(a$maint_1l), "NA", a$maint_1l),
        ifelse(is.na(a$maint_rule_1l), "NA", a$maint_rule_1l), sep = "\r")

nl_decision_sensitivity <- function(episodes, index_dates, drugs, target = NL_TARGET,
                                    base_ov = list(), idx = NULL,
                                    factorial_ids = nl_factorial_ids(),
                                    one_at_a_time_ids = nl_one_at_a_time_ids(),
                                    max_cells = 512L) {
  if (is.null(idx)) idx <- nl_role_index(drugs)
  # ~200 pipeline evaluations per patient: suppress the per-cell progress
  # messages, restoring the caller's setting on exit.
  old_quiet <- getOption("nl.quiet", FALSE)
  options(nl.quiet = TRUE); on.exit(options(nl.quiet = old_quiet), add = TRUE)

  run <- function(ov, label) {
    a <- tryCatch(nl_target_answer(nl_lot_b(episodes, index_dates, drugs, ov, idx = idx), target, ov),
                  error = function(e) e)
    # A branch that ERRORS is a broken sweep, not evidence of indeterminacy. The
    # previous version mapped the condition onto an NA answer, which necessarily
    # differed from the base answer and was then recorded as a flip - so a
    # mistyped decision value or a switch() falling through to stop() made a
    # Tier-2 sentinel PASS.
    if (inherits(a, "condition"))
      stop("decision sweep FAILED in branch [", label, "]: ", conditionMessage(a),
           " - fix the branch; a crashing alternative must never be reported as indeterminacy",
           call. = FALSE)
    a
  }

  base_res <- nl_lot_b(episodes, index_dates, drugs, base_ov, idx = idx)
  base     <- nl_target_answer(base_res, target, base_ov)
  base_key <- nl_answer_key(base)

  # ---- the factorial grid ----
  prim <- vapply(factorial_ids, function(i) as.character(nl_dec(i, base_ov)), character(1))
  lv   <- lapply(factorial_ids, function(i)
    unique(c(as.character(nl_dec(i, base_ov)), as.character(nl_dec_alt(i)))))
  names(lv) <- factorial_ids
  n_cells <- prod(vapply(lv, length, integer(1)))
  if (n_cells > max_cells)
    stop("nl_decision_sensitivity(): the factorial grid is ", n_cells, " cells (> max_cells = ",
         max_cells, "). Reduce factorial_ids, or raise max_cells deliberately.")
  grid <- expand.grid(lv, stringsAsFactors = FALSE, KEEP.OUT.ATTRS = FALSE)
  gm   <- as.matrix(grid)                     # always a named character matrix

  keys <- character(nrow(gm))
  for (i in seq_len(nrow(gm))) {
    ov <- base_ov
    for (id in factorial_ids) ov[[id]] <- gm[i, id]
    keys[i] <- nl_answer_key(run(ov, paste(factorial_ids, gm[i, ], sep = "=", collapse = "; ")))
  }
  n_eval <- nrow(gm)

  diff_ids  <- function(i) factorial_ids[gm[i, factorial_ids] != prim]
  flip_rows <- which(keys != base_key)
  flip_sets <- unique(lapply(flip_rows, diff_ids))
  # subset-minimal flipping combinations: C flips and no proper subset of C does
  minimal <- Filter(function(s) !any(vapply(flip_sets, function(q)
    length(q) < length(s) && all(q %in% s), logical(1))), flip_sets)

  # pivotal: any decision that changes the answer between two cells that differ
  # only in that decision.
  pivotal <- character(0)
  for (id in factorial_ids) {
    others <- setdiff(factorial_ids, id)
    grp <- if (length(others)) do.call(paste, c(as.list(as.data.frame(gm[, others, drop = FALSE])),
                                                sep = "\r")) else rep("x", nrow(gm))
    sp  <- split(keys, grp)
    if (any(vapply(sp, function(k) length(unique(k)) > 1L, logical(1)))) pivotal <- c(pivotal, id)
  }

  # ---- one-at-a-time decisions (maintenance thresholds, R21 naming, ...) ----
  detail <- list()
  for (id in one_at_a_time_ids) {
    for (alt in nl_dec_alt(id)) {
      ov <- base_ov; ov[[id]] <- alt
      a <- run(ov, paste0(id, "=", alt)); n_eval <- n_eval + 1L
      if (!identical(nl_answer_key(a), base_key)) {
        pivotal <- c(pivotal, id)
        minimal <- c(minimal, list(id))
        detail[[length(detail) + 1L]] <- tibble::tibble(
          decision_id = id, gap = nl_dec_gap(id), alternative = as.character(alt),
          line = a$line, regimen = a$regimen, mono = a$mono)
      }
    }
  }
  for (s in minimal) {
    if (!length(s)) next
    detail[[length(detail) + 1L]] <- tibble::tibble(
      decision_id = paste(s, collapse = " + "),
      gap = paste(sort(unique(vapply(s, nl_dec_gap, character(1)))), collapse = ","),
      alternative = "(minimal flipping combination)",
      line = NA_integer_, regimen = NA_character_, mono = NA)
  }

  gaps_of <- function(ids) sort(unique(vapply(ids, nl_dec_gap, character(1))))
  indeterminate_by <- gaps_of(unlist(minimal))
  pivotal_by       <- gaps_of(unique(pivotal))

  # A regimen that is NA BY DECISION (the G10 exact tie) is itself indeterminacy,
  # even though it does not flip the target tuple: SA-07 has no determinable 1L
  # regimen name under ANY reading of "duration". The naming indeterminacy must
  # NOT leak into the line number - that is asserted separately in the suite.
  naming_indet <- nrow(base_res$lines) > 0 &&
    any(base_res$lines$regimen_indeterminate, na.rm = TRUE)
  target_naming_indet <- nrow(base_res$lines) > 0 &&
    any(base_res$lines$regimen_indeterminate &
          vapply(base_res$lines$drug_set_window, nl_set_has, logical(1), target), na.rm = TRUE)
  if (naming_indet) {
    indeterminate_by <- sort(unique(c(indeterminate_by, "G10")))
    pivotal_by       <- sort(unique(c(pivotal_by, "G10")))
  }

  min_size <- if (length(minimal)) min(vapply(minimal, length, integer(1))) else NA_integer_
  smallest <- if (length(minimal))
    paste(vapply(Filter(function(s) length(s) == min_size, minimal),
                 function(s) paste(s, collapse = " + "), character(1)), collapse = " | ") else NA_character_

  list(base = base,
       indeterminate = length(minimal) > 0 || naming_indet,
       indeterminate_by = paste(indeterminate_by, collapse = ","),
       pivotal_by       = paste(pivotal_by, collapse = ","),
       minimal_flip     = smallest,
       naming_indeterminate = naming_indet,
       target_regimen_indeterminate = target_naming_indet,
       n_cells = n_cells, n_evaluated = n_eval,
       detail = if (length(detail)) dplyr::bind_rows(detail) else tibble::tibble())
}

# Per-patient sweep for a whole cohort. ~200 pipeline evaluations per patient, so
# run it on the candidate set (patients with any target-agent episode), not on
# the full denominator, and consider a reduced factorial_ids for a first pass.
nl_sensitivity_table <- function(episodes, index_dates, drugs, target = NL_TARGET,
                                 ptids = NULL, ...) {
  idx <- nl_role_index(drugs)
  pts <- ptids %||% unique(index_dates$ptid)
  purrr::map_dfr(pts, function(p) {
    s <- nl_decision_sensitivity(episodes |> filter(ptid == p),
                                 index_dates |> filter(ptid == p),
                                 drugs, target, idx = idx, ...)
    tibble::tibble(ptid = p,
                   indeterminate = s$indeterminate,
                   indeterminate_by = s$indeterminate_by,
                   pivotal_by = s$pivotal_by,
                   minimal_flip = s$minimal_flip,
                   naming_indeterminate = s$naming_indeterminate,
                   target_regimen_indeterminate = s$target_regimen_indeterminate)
  })
}

# Indeterminacy that is NOT the cohort-wide G1 caveat.
nl_local_indeterminacy <- function(indeterminate_by) {
  vapply(indeterminate_by, function(z) {
    g <- str_trim(str_split(dplyr::coalesce(z, ""), ",")[[1]])
    length(setdiff(g[nzchar(g)], "G1")) > 0
  }, logical(1), USE.NAMES = FALSE)
}

# ============================================================================
# 6. LOT-A  -  Optum's native table
#
# MUST be collapsed first: DRUGS is same-day drugs, so the same regimen appears
# on multiple rows with a REPEATED lot number (EO guide 4.6.2, divergence D8).
# Failing to collapse silently corrupts every count.
#
# LOT-A IS UNUSABLE AS THE LINE-ASSIGNMENT METHOD FOR THIS COHORT. It is an
# independent comparator only, and it must NEVER be used to adjudicate
# monotherapy (case MI-02: LOT-A reports a clean `Docetaxel` 2L line for a
# patient who actually received the REVEL doublet, and nothing in a LOT-A-only
# pipeline can detect it).
#
# EVERY COLUMN NAMED BELOW IS UNVERIFIED. t_onc_line_of_therapy is not among the
# 14 tables in optum_mc_reference/rdq_query_outputs/varlist.txt, so cancer_type,
# lot, initiation, last_administration, regimen_name, drugs and lot_censored
# have NOT been confirmed against a live DESCRIBE. Run
#   DESCRIBE hive_metastore.clnprw_optum_mc_full_use.t_onc_line_of_therapy_2025q4
# before any LOT-A number is reported.                              # UNVERIFIED
# ============================================================================

nl_lot_a <- function(con, cancer_type_regex = "LUNG", ptids = NULL) {
  t <- mc_tbl(con, "onc_line_of_therapy") |>
    filter(sql(nl_like_any("cancer_type", cancer_type_regex)))
  if (!is.null(ptids)) t <- t |> filter(ptid %in% ptids)
  raw <- collect(t)

  # D12: LOT is Character(2). Check for non-numeric sentinels BEFORE casting.
  bad <- unique(raw$lot[is.na(suppressWarnings(as.integer(raw$lot))) & !is.na(raw$lot)])
  if (length(bad)) warning("LOT-A: non-numeric LOT values dropped: ", paste(bad, collapse = ", "))

  # NA-safe aggregates: min()/max() with na.rm on an all-NA group returns
  # Inf/-Inf with a warning and poisons index_delta and the index_shift
  # quantiles downstream.
  safe_min <- function(x) if (all(is.na(x))) as.Date(NA) else min(x, na.rm = TRUE)
  safe_max <- function(x) if (all(is.na(x))) as.Date(NA) else max(x, na.rm = TRUE)

  raw |>
    mutate(lot_num = suppressWarnings(as.integer(lot))) |>
    filter(!is.na(lot_num)) |>
    mutate(initiation = as.Date(initiation), last_administration = as.Date(last_administration)) |>
    group_by(ptid, cancer_type, lot_num) |>
    summarise(initiation = safe_min(initiation),
              last_admin = safe_max(last_administration),
              regimens   = paste(sort(unique(regimen_name)), collapse = " | "),
              drugs_seen = paste(sort(unique(drugs)), collapse = " | "),
              censored   = any(lot_censored == "Y", na.rm = TRUE),
              n_rows     = n(), .groups = "drop") |>
    arrange(ptid, lot_num)
}

# ============================================================================
# 7. MONOTHERAPY
#
# Phoebe's `lot2 == 'Docetaxel'` works in Flatiron because the regimen string is
# a curated R9 artefact computed over an EHR-only episode set with an
# undocumented supportive-care exclusion applied upstream. THREE OF THOSE FOUR
# PROPERTIES ARE ABSENT IN OPTUM. So this is NOT a string equality test. It is a
# SET PREDICATE over an EXPLICITLY CONSTRUCTED EPISODE SET, per section 4 of the
# adversarial report:
#
#   1. Episode set (primary): t_onc_medications restricted to
#      data_source in {rx_adm, rx_presc, proc} and
#      action in {administered, prescribed, started}.
#      Excludes provider_notes, clm_rx, clm_med_serv.
#   2. Second build over ALL data_source values, as a NAMED SENSITIVITY,
#      never as the primary.
#   3. Drug universe: the explicit versioned antineoplastic list, PLUS the
#      explicit supportive-care exclusion list (decision D_G7).
#   4. Predicate: the set of distinct eligible ingredients with an episode in
#      [t0, t0 + 28d] per R9 equals {DOCETAXEL}. Day 28 INCLUSIVE (D_G11);
#      day-28 additions are reported as their own row. UNDER D_G6 = retro_name
#      the predicate moves to the recomputed regimen, because that is the field
#      the selector would read.
#   5. Post-28-day additions do NOT retro-name the line by default (D_G6); every
#      such patient is flagged and the cohort is reported with and without them.
#   6. A "monotherapy-fragile" count: patients whose status flips between
#      builds 1 and 2.
# ============================================================================

nl_monotherapy <- function(lot_b, drugs, target = NL_TARGET, ov = list()) {
  ln <- lot_b$lines
  if (!nrow(ln)) return(tibble::tibble())
  retro <- identical(nl_dec("D_G6_POST28_ADDITION_NAMING", ov), "retro_name")
  ln |>
    filter(vapply(drug_set_window, nl_set_has, logical(1), target)) |>
    group_by(ptid) |>
    arrange(line, .by_group = TRUE) |>
    slice(1) |>
    ungroup() |>
    transmute(
      ptid, line, t0 = line_start, line_end, regimen, naming_rule,
      drug_set = drug_set_window,
      n_drugs_window = vapply(drug_set_window, function(z) length(nl_set_split(z)), integer(1)),
      # THE PREDICATE - a SET EQUALITY, not a string match. This is the whole
      # point of section 4: Phoebe's lot2 == 'Docetaxel' does not port.
      monotherapy = if (retro)
        vapply(regimen, function(z) identical(nl_set_split(z), target), logical(1))
      else
        vapply(drug_set_window, function(z) identical(nl_set_split(z), target), logical(1)),
      day28_addition  = nzchar(dplyr::coalesce(day28_added, "")),
      post28_addition = nzchar(dplyr::coalesce(post28_added, "")),
      post28_agents   = post28_added,
      regimen_indeterminate, has_maint, maint_rule, maint_fail,
      advance_reason, dec_applied, build = "unset"
    )
}

# The two-build design. `prim` and `sens` are nl_monotherapy() outputs from the
# narrow and wide episode builds respectively.
nl_monotherapy_two_build <- function(prim, sens) {
  stopifnot(is.data.frame(prim), is.data.frame(sens))
  p <- prim |> mutate(build = "narrow")
  s <- sens |> mutate(build = "wide") |>
    select(ptid, line_wide = line, drug_set_wide = drug_set, mono_wide = monotherapy)
  out <- p |>
    full_join(s, by = "ptid") |>
    mutate(
      mono_narrow = monotherapy,
      # MONOTHERAPY-FRAGILE: status differs between the primary and sensitivity
      # builds. On the 35-case probe set the divergent fixtures are ORAL1L-02
      # (line number), MI-04 (monotherapy) and GAP-03 (advancement mechanism at
      # an unchanged line number). These patients must be COUNTED AND REPORTED,
      # never quietly resolved to whichever build the pipeline happened to run.
      mono_fragile = !is.na(mono_narrow) & !is.na(mono_wide) & (mono_narrow != mono_wide),
      seen_only_in = dplyr::case_when(is.na(mono_wide)   ~ "narrow only",
                                      is.na(mono_narrow) ~ "wide only",
                                      TRUE               ~ "both"),
      line_fragile = !is.na(line) & !is.na(line_wide) & (line != line_wide)
    )
  # GUARD RAIL: the cohort table is one row per patient.
  stopifnot(!any(duplicated(out$ptid)))
  out
}

# The pre-registered cohort. One row per ptid, enforced.
#
# COHORT MEMBERSHIP IS THREE-STATE. The file's contract is that a patient whose
# answer flips under a sweep is reported as indeterminate, not as a number, and
# that contract has to be enforced HERE, in the pipeline that produces the
# count - not only in the test harness. `cohort_status` is one of:
#   "in"            - 2L, monotherapy, no naming tie, no local indeterminacy
#   "indeterminate" - would be "in" but the answer turns on a substituted
#                     decision other than the cohort-wide G1 caveat
#   "out"           - not a 2L target-monotherapy line
# G1 is excluded from the local test on purpose: D_G1 = "persist" demotes every
# G1-advanced patient, i.e. essentially the whole cohort, so it is a
# COHORT-LEVEL caveat reported once in the SAP, not a per-patient flag. The
# G1-only stratum is still counted separately (indeterminate_g1_only).
nl_cohort_2l <- function(mono_two_build, sens = NULL, target = NL_TARGET) {
  out <- mono_two_build
  if (!is.null(sens)) {
    m <- match(out$ptid, sens$ptid)
    out$indeterminate      <- sens$indeterminate[m]
    out$indeterminate_by   <- sens$indeterminate_by[m]
    out$pivotal_by         <- sens$pivotal_by[m]
    out$minimal_flip       <- sens$minimal_flip[m]
  } else {
    warning("nl_cohort_2l(): no sensitivity table supplied - every qualifying patient is ",
            "reported as cohort_status = 'unswept', NEVER as a member. Run ",
            "nl_sensitivity_table() and pass it in; the indeterminacy gate is not optional.")
    out$indeterminate    <- NA
    out$indeterminate_by <- NA_character_
    out$pivotal_by       <- NA_character_
    out$minimal_flip     <- NA_character_
  }
  out <- out |>
    mutate(
      indeterminate_local   = dplyr::if_else(is.na(indeterminate), NA,
                                             nl_local_indeterminacy(indeterminate_by)),
      indeterminate_g1_only = isTRUE_vec(indeterminate) & !isTRUE_vec(indeterminate_local),
      qualifies = !is.na(line) & line == 2L & isTRUE_vec(mono_narrow),
      cohort_status = dplyr::case_when(
        !qualifies ~ "out",
        is.na(indeterminate) ~ "unswept",
        isTRUE_vec(regimen_indeterminate) | isTRUE_vec(indeterminate_local) ~ "indeterminate",
        TRUE ~ "in"),
      in_cohort_primary = cohort_status == "in",
      # kept for the methods delta only - NEVER the headline number
      in_cohort_primary_ignoring_indeterminacy = qualifies & !isTRUE_vec(regimen_indeterminate),
      # section 4 item 5: report the cohort with and without post-28d additions
      in_cohort_primary_excl_post28 = in_cohort_primary &
        !isTRUE_vec(post28_addition) & !isTRUE_vec(day28_addition),
      in_cohort_sensitivity = !is.na(line_wide) & line_wide == 2L & isTRUE_vec(mono_wide)
    ) |>
    select(-qualifies)
  stopifnot(!any(duplicated(out$ptid)))
  out
}

nl_cohort_tables <- function(cohort) {
  list(
    status  = cohort |> count(cohort_status),
    why     = cohort |> filter(cohort_status == "indeterminate") |> count(indeterminate_by, sort = TRUE),
    g1_only = cohort |> summarise(n_g1_only_caveat = sum(isTRUE_vec(indeterminate_g1_only))),
    post28  = cohort |> summarise(with_post28 = sum(isTRUE_vec(in_cohort_primary)),
                                  excl_post28 = sum(isTRUE_vec(in_cohort_primary_excl_post28))),
    fragile = cohort |> summarise(mono_fragile = sum(isTRUE_vec(mono_fragile)),
                                  line_fragile = sum(isTRUE_vec(line_fragile)))
  )
}

# ============================================================================
# 8. THE COMPARISON
# ============================================================================

nl_compare <- function(lot_a, cohort, target = NL_TARGET) {
  tgt <- tolower(target)
  a <- lot_a |>
    filter(str_detect(tolower(dplyr::coalesce(drugs_seen, "")), fixed(tgt)) |
           str_detect(tolower(dplyr::coalesce(regimens,   "")), fixed(tgt))) |>
    group_by(ptid) |> arrange(lot_num, .by_group = TRUE) |> slice(1) |> ungroup() |>
    transmute(ptid, line_a = lot_num, index_a = initiation, drugs_a = drugs_seen,
              regimen_a = regimens,
              # LOT-A MUST NEVER ADJUDICATE MONOTHERAPY (MI-02). Computed here
              # only so the false-positive rate can be reported.
              mono_a_UNSAFE = !str_detect(tolower(dplyr::coalesce(drugs_seen, "")), "[,+|]"))
  b <- cohort |>
    transmute(ptid, line_b = line, index_b = t0, mono_b = mono_narrow,
              cohort_status, in_cohort_b = in_cohort_primary,
              mono_fragile, indeterminate, indeterminate_local, indeterminate_by,
              minimal_flip, dec_applied)
  full_join(a, b, by = "ptid") |>
    mutate(
      seen_by     = case_when(is.na(line_a) & !is.na(line_b) ~ "LOT-B only",
                              !is.na(line_a) & is.na(line_b) ~ "LOT-A only",
                              TRUE ~ "both"),
      line_agree  = !is.na(line_a) & !is.na(line_b) & line_a == line_b,
      line_delta  = line_a - line_b,
      index_delta = as.numeric(index_b - index_a),
      in_2l_a     = !is.na(line_a) & line_a == 2,
      # consumes the pre-computed, indeterminacy-honouring flag rather than
      # re-deriving membership and silently dropping the guard
      in_2l_b     = isTRUE_vec(in_cohort_b),
      in_2l_b_indeterminate = !is.na(cohort_status) & cohort_status == "indeterminate",
      # T6 discordance taxonomy, coarse assignment. Refine with the mechanism
      # signatures in 03_..._design.md sec 3.1 before reporting.
      mechanism   = case_when(
        seen_by == "LOT-B only"                    ~ "M1 oral/invisible to LOT-A",
        !is.na(line_delta) & line_delta > 0        ~ "M2/M3/M4 LOT-A over-numbers (adjuvant / maintenance / substitution)",
        !is.na(line_delta) & line_delta < 0        ~ "M1 LOT-A under-numbers (oral 1L)",
        isTRUE_vec(mono_fragile)                   ~ "M7 monotherapy fragile to source breadth",
        TRUE                                       ~ "concordant")
    )
}

nl_compare_tables <- function(cmp) {
  list(
    seen_by     = cmp |> count(seen_by),
    line_xtab   = cmp |> filter(seen_by == "both") |> count(line_a, line_b),
    mechanism   = cmp |> count(mechanism),
    cohort_2l   = cmp |> summarise(only_a = sum(in_2l_a & !in_2l_b, na.rm = TRUE),
                                   only_b = sum(in_2l_b & !in_2l_a, na.rm = TRUE),
                                   both   = sum(in_2l_a & in_2l_b, na.rm = TRUE),
                                   b_indeterminate = sum(isTRUE_vec(in_2l_b_indeterminate))),
    fragile     = cmp |> summarise(mono_fragile  = sum(isTRUE_vec(mono_fragile)),
                                   indeterminate_local = sum(isTRUE_vec(indeterminate_local))),
    index_shift = cmp |> filter(seen_by == "both") |>
                    summarise(median_delta = median(index_delta, na.rm = TRUE),
                              p10 = quantile(index_delta, .1, na.rm = TRUE),
                              p90 = quantile(index_delta, .9, na.rm = TRUE)),
    blind_spots = tibble::tibble(
      item = c("clinical study drug", "second primary / concurrent cancer"),
      decision = c(nl_dec("D_G13_CLINICAL_STUDY_DRUG"), nl_dec("D_G14_SECOND_PRIMARY")),
      gap = c(nl_dec_gap("D_G13_CLINICAL_STUDY_DRUG"), nl_dec_gap("D_G14_SECOND_PRIMARY")),
      note = c("Report as a sized blind spot, never as a count. No probe case exercises it.",
               paste("NOT IMPLEMENTED - decision required: no MULTI_CANCER_FLAG, no lung-attributed",
                     "filter, nothing measured. No probe case exercises it.")))
  )
}

# ============================================================================
# 9. REGRESSION SUITE
#
# The 35 adversarial fixtures, run end to end against the real engine.
#
# THE ORACLE IS NOT solver_lot_b. LOT-B here is not naive, so solver_lot_b is a
# CONTRAST column: for SA-01 it says 3 (a build missing the R21 cis/carbo
# substitution) where the adjudicated answer is 2. Same for GAP-06 and ORAL1L-06.
# Tier 1 asserts against NL_TIER1_ORACLE, the ADJUDICATED table. Where the CSV
# and the report disagree the report wins, the disagreement is printed, and each
# override carries a `why`.
#
# tolerated_gaps is the other half of a Tier-1 oracle: a determinate oracle may
# not depend on a substituted decision. G1 is tolerated everywhere because it is
# load-bearing for the whole cohort by construction; GAP-01/MNT-02 tolerate G2
# and ORAL1L-03 tolerates G5, each documented at the fixture.
#
# Column provenance (author_expect / solver / adjudicated / oracle) and the
# legacy alias contract: ../METHODS.md.
# ---------------------------------------------------------------------------

# Tier 1 - determinate oracles. line = the line the FIRST docetaxel block lands
# on; mono = the adjudicated Flatiron monotherapy status; extra_line = a second
# docetaxel line where the case produces one; line*_end = an asserted line end.
NL_TIER1_ORACLE <- list(
  "ORAL1L-04" = list(line = 2L, mono = TRUE),
  "GAP-01"    = list(line = 2L, mono = TRUE, tolerated_gaps = c("G1", "G2"),
                     why = "R18 fires inside a pemetrexed maintenance phase (G2 engaged, not decisive alone)"),
  "GAP-04"    = list(line = 2L, mono = TRUE, line1_end = as.Date("2018-12-02")),
  "GAP-05"    = list(line = 2L, mono = TRUE),
  "GAP-06"    = list(line = 1L, mono = TRUE,
                     why = "CSV solver_lot_b = 3 predicts a naive rebuild that misses R7/R20; adjudicated answer is 1L (adjuvant course)"),
  "ORAL1L-01" = list(line = 2L, mono = TRUE),
  "ORAL1L-03" = list(line = 2L, mono = TRUE, tolerated_gaps = c("G1", "G5"),
                     why = "the 170-day alectinib holiday is exempt under R19; only the no_oral_exemption branch flips it"),
  "ORAL1L-05" = list(line = 2L, mono = TRUE),
  "ORAL1L-06" = list(line = 3L, mono = TRUE,
                     why = "CSV solver_lot_b = 1 predicts a build with no oral episodes at all"),
  "ORAL1L-07" = list(line = 2L, mono = TRUE),
  "ORAL1L-02" = list(line = 1L, mono = TRUE,
                     why = "CSV oracle_lot_flat = NOT-DETERMINED; under the NARROW build the note-only erlotinib is not an episode, so docetaxel is 1L. This is asserted as a property of the declared episode build, not as a Flatiron answer."),
  "MNT-01"    = list(line = 2L, mono = TRUE),
  "MNT-02"    = list(line = 2L, mono = TRUE, tolerated_gaps = c("G1", "G2"),
                     why = "the 141-day gap that advances the line falls inside the bev+atezo maintenance phase"),
  "MNT-06"    = list(line = 3L, mono = TRUE),
  "MNT-07"    = list(line = 2L, mono = TRUE,
                     why = paste("CSV solver_lot_b = 3 predicts a naive rebuild that opens a new line at the chemo",
                                 "drop; R16 narrowly fails (42 < 49 days) and a failed maintenance test leaves the",
                                 "line number UNCHANGED, so docetaxel is 2L. CSV ruleset_insufficient = TRUE records",
                                 "the documented G9 drop-anchor ambiguity, which is non-flipping here (41-43 days",
                                 "under every anchor); the answer is asserted at the registered anchor.")),
  "SA-01"     = list(line = 2L, mono = TRUE,
                     why = "CSV solver_lot_b = 3 predicts a build that misses the R21 carbo/cis substitution"),
  "SA-02"     = list(line = 2L, mono = TRUE),
  "SA-03"     = list(line = 2L, mono = TRUE),
  "SA-05"     = list(line = 2L, mono = FALSE),
  "SA-06"     = list(line = 2L, mono = TRUE,
                     why = "CSV mono_flat = not-determined; under the NARROW build the day-29 ramucirumab is claims-only and absent, so the window set is {DOCETAXEL}"),
  "MI-02"     = list(line = 2L, mono = FALSE),
  "MI-04"     = list(line = 2L, mono = TRUE,
                     why = "CSV mono_flat = not-determined; narrow build excludes the note-only erlotinib (the wide build is the Tier-3 contrast)"),
  "MI-05"     = list(line = 2L, mono = TRUE, extra_line = 3L,
                     line2_end = as.Date("2021-07-25"),
                     why = paste("CSV solver_lot_b is a prose cell ('2 for the first docetaxel block; 3 for the",
                                 "re-challenge ...') that the parser reads as one number; the first docetaxel",
                                 "block is 2L and the 158-day R18 re-challenge is the asserted extra_line = 3L."))
)

# Tier 1b - INDEX-DATE ARMS. MI-07 was previously in no tier at all: it fell to
# the "REPORT" branch and was asserted against nothing, although it is the only
# probe of D_INDEX_DATE, which this file calls the single largest LOT-B risk.
# It is run twice, once per index-date definition, and the FLIP is the assertion.
NL_TIER1B_INDEX_ARMS <- list(
  "MI-07" = list(
    arms = list(list(label = "IX-abstracted (Flatiron)", index_date = as.Date("2017-10-05"), line = 2L),
                list(label = "IX-icd surrogate (+21d)",  index_date = as.Date("2017-10-26"), line = 1L)),
    mono = TRUE,
    why  = paste("A 21-day-late structured surrogate index turns a straddling 1L doublet into",
                 "an R7 adjuvant course and demotes docetaxel from 2L to 1L. The patient is in",
                 "the Flatiron cohort and would be LOST by the replication."))
)

# Tier 2 - indeterminacy sentinels. These MUST NOT return a silent answer: the
# engine must flag the case indeterminate, naming the gap(s) it turns on, and
# the build FAILS if the implementation quietly picks a branch.
#
# `want` is asserted with all(want %in% indeterminate_by) - the MINIMAL flip
# set only, so a fixture flagged for the wrong reason cannot pass because G1
# (pivotal for essentially every patient) happens to be in pivotal_by. A gap
# that is load-bearing only jointly is declared in `pivotal_only` and asserted
# against pivotal_by (MI-06's G6 decides the name once the day-28 boundary is
# read as exclusive). A gap the fixture cannot exercise is recorded in
# `not_exercisable` with the reason, printed, and NOT asserted.
NL_TIER2_SENTINELS <- list(
  "GAP-02" = list(want = c("G1"),
                  not_exercisable = c("G4" = "the gap is EXACTLY 120 days, which is non-advancing under both readings (120 and 119), so the arithmetic decision cannot flip this patient")),
  "GAP-03" = list(want = c("G4"),
                  note = "only the PAIR {G4=intervening_days, G1=persist} flips it - the case that proves the sweep must be factorial"),
  "GAP-07" = list(want = c("G5")),
  "MNT-03" = list(want = c("G1")),
  "MNT-04" = list(want = c("G2"),
                  not_exercisable = c("G8" = "the two continued pembrolizumab episodes are 21 and 42 days after the drop and are one row per day, so neither the counting unit nor a 120-day span constraint can change the R13 verdict")),
  "MNT-05" = list(want = c("G3")),
  "SA-04"  = list(want = c("G6")),
  "MI-03"  = list(want = c("G6"),
                  not_exercisable = c("G11" = "ramucirumab arrives on day 35, nowhere near the 28-day boundary")),
  "MI-06"  = list(want = c("G11"), pivotal_only = c("G6"),
                  note = "G11 flips the answer on its own (day 28 exactly); G6 is pivotal inside the exclusive-boundary branch"),
  "SA-07"  = list(want = c("G10")),
  "MI-01"  = list(want = c("G7"))
)

# Tier 3 - source-build divergence pairs, with the field that MUST diverge.
# Reduced to the fixtures that genuinely have wide-only episodes that change the
# LOT-B answer. MI-01's wide-only rows are all EXCL:supportive and are removed
# by D_G7 in both builds; MNT-04's only wide-only row is a prednisone
# prescription (also EXCL); GAP-07's and SA-06's wide-only rows change nothing.
# Asserting divergence for those four would fire spuriously and misdiagnose the
# cause as "the source restriction is not being applied".
NL_TIER3_PAIRS <- list(
  "ORAL1L-02" = "line",           # note-only erlotinib: 1L narrow vs 2L wide
  "MI-04"     = "mono",           # note-only erlotinib on the 2L start date
  "GAP-03"    = "advance_reason"  # same line number, different MECHANISM
)

# Tier 4 - LOT-A discordance fixtures, grouped by the section-3 mechanism.
NL_TIER4_MECHANISMS <- list(
  "oral under-numbering"       = c("ORAL1L-01","ORAL1L-03","ORAL1L-06","ORAL1L-07","GAP-07"),
  "maintenance over-numbering" = c("MNT-01","MNT-02","MNT-03","MNT-04","MNT-07"),
  "adjuvant over-numbering"    = c("GAP-05","GAP-06"),
  "LOT-A false positives"      = c("GAP-06","MNT-05"),
  "administration-only / date bias" = c("SA-01","MI-02","GAP-04")
)

# ---- fixture parsing -------------------------------------------------------
# The timeline column is semi-structured free text:
#   "<date(s)> | <drug(s)> | <route> | <provenance>"
# It is parsed CONSERVATIVELY. Anything that does not parse marks the case
# `unparsed`, and for a TIERED case an unparsed line is a FAILURE, never a
# silent thinning of the episode set.

NL_FIXTURE_NONDRUG <- c("advanced nsclc", "last confirmed activity", "last patient-level",
                        "no antineoplastic", "radiotherapy", "regimen window closes",
                        "structured icd", "immunotherapy discontinued", "plan to begin",
                        "prednisone taper", "first structured", "restaging",
                        "fusion reported", "drug holiday", "surveillance", "interval")

# Provenance -> data_source. Returns NA for a string it does not recognise, and
# the caller then REPORTS the line instead of dropping it. The old version
# returned the literal "unknown", which is in neither the narrow nor the wide
# source list, so unrecognised rows vanished from the primary build with no
# record: MNT-02's ten "as above" continuation rows disappeared, the R13
# bevacizumab+atezolizumab maintenance phase the case exists to test was erased,
# and the fixture still PASSED because a 372-day gap coincidentally reproduced
# the line number.
nl_fix_provenance <- function(p) {
  p <- tolower(dplyr::coalesce(p, ""))
  if (grepl("^as above", str_trim(p))) return(NA_character_)   # caller inherits
  if (grepl("claims medical", p)) return("clm_med_serv")
  if (grepl("claims", p) && grepl("rx|pharmac|fill", p)) return("clm_rx")
  if (grepl("note-mention|note mention|provider note", p)) return("provider_notes")
  if (grepl("prescription|medication order|prescription order", p)) return("rx_presc")
  if (grepl("administration|administered|admin", p)) return("rx_adm")
  if (grepl("procedure-coded|j9|j2|proc", p)) return("proc")
  if (grepl("abstracted-oral span", p)) return("abstracted_oral")
  NA_character_
}
nl_fix_is_as_above <- function(p) grepl("^as above", tolower(str_trim(dplyr::coalesce(p, ""))))

# Expand a date cell. Returns a list(dates, reconstructed).
nl_fix_dates <- function(cell) {
  cell <- str_trim(cell)
  iso  <- "\\d{4}-\\d{2}-\\d{2}"
  if (grepl(paste0("^", iso, "$"), cell)) return(list(dates = as.Date(cell), recon = 0L))
  m <- str_match(cell, paste0("^(", iso, ")\\s+to\\s+(", iso, ")$"))
  if (!is.na(m[1, 1])) return(list(dates = c(as.Date(m[1, 2]), as.Date(m[1, 3])), recon = 0L))
  toks <- str_extract_all(cell, iso)[[1]]
  if (length(toks) >= 2 && grepl("monthly through", cell)) {
    # "d1, d2, d3, ... monthly through dN": keep the explicit dates and fill the
    # ellipsis at 28-day spacing up to dN. FIXTURE-PARSER RECONSTRUCTION - the
    # fixture does not enumerate the intervening orders. COUNTED, not silent.
    explicit <- as.Date(toks[-length(toks)])
    last     <- as.Date(toks[length(toks)])
    from     <- max(explicit)
    filled   <- if (from < last) seq(from = from, to = last, by = 28) else from
    out <- sort(unique(c(explicit, filled, last)))
    return(list(dates = out, recon = length(setdiff(out, c(explicit, last)))))
  }
  if (length(toks)) return(list(dates = sort(unique(as.Date(toks))), recon = 0L))
  list(dates = as.Date(character(0)), recon = 0L)
}

nl_fix_is_span <- function(cell)
  grepl("^\\d{4}-\\d{2}-\\d{2}\\s+to\\s+\\d{4}-\\d{2}-\\d{2}$", str_trim(cell))

# Pull "N further episodes (d1, d2, ...)" out of a drug cell, carrying the year.
nl_fix_extra_dates <- function(drug_cell, anchor_year) {
  m <- str_match(drug_cell, "further episodes\\s*\\(([^)]*)\\)")
  if (is.na(m[1, 1])) return(as.Date(character(0)))
  toks <- str_split(m[1, 2], ",")[[1]] |> str_trim()
  yr <- anchor_year; out <- as.Date(character(0))
  for (tk in toks) {
    if (grepl("^\\d{4}-\\d{2}-\\d{2}$", tk)) { yr <- substr(tk, 1, 4); out <- c(out, as.Date(tk)) }
    else if (grepl("^\\d{2}-\\d{2}$", tk))    { out <- c(out, as.Date(paste0(yr, "-", tk))) }
  }
  sort(unique(out[!is.na(out)]))
}

nl_parse_timeline <- function(txt, drugs) {
  bad <- character(0); rows <- list(); recon <- 0L
  activity <- as.Date(NA); prev_src <- NA_character_
  for (raw in str_split(dplyr::coalesce(txt, ""), "\n")[[1]]) {
    ln <- str_trim(raw)
    if (!nzchar(ln)) next
    f <- str_split(ln, "\\|")[[1]] |> str_trim()
    drug_cell <- if (length(f) >= 2) f[2] else ln
    dl <- tolower(drug_cell)

    # COMMENTARY / NON-DRUG LINES ARE SKIPPED FIRST. They used to hit the
    # "fewer than 4 fields" branch and be counted as unparsed, which made the
    # unparsed counter useless as a failure signal.
    if (startsWith(ln, "(") || startsWith(ln, "'") ||
        startsWith(drug_cell, "(") || startsWith(drug_cell, "'") ||
        any(vapply(NL_FIXTURE_NONDRUG, function(k) grepl(k, dl, fixed = TRUE), logical(1)))) {
      if (length(f) >= 4 && grepl("last confirmed activity|last patient-level", dl)) {
        act <- nl_fix_dates(f[1])$dates
        if (length(act)) activity <- max(act)
      }
      next
    }
    if (length(f) < 4) { bad <- c(bad, ln); next }

    date_cell <- f[1]; route_cell <- tolower(f[3]); prov_cell <- f[4]
    src <- nl_fix_provenance(prov_cell)
    if (is.na(src) && nl_fix_is_as_above(prov_cell)) src <- prev_src   # continuation
    if (is.na(src)) { bad <- c(bad, ln); next }
    if (!nl_fix_is_as_above(prov_cell)) prev_src <- src

    yr    <- str_extract(date_cell, "\\d{4}")
    extra <- nl_fix_extra_dates(drug_cell, yr)

    # strip parentheticals BEFORE splitting on "+", then split on "+" and "/"
    clean <- gsub("\\([^)]*\\)", " ", drug_cell)
    clean <- gsub("further episodes.*$", " ", clean)
    parts <- unlist(str_split(unlist(str_split(clean, ";")), "\\+|/"))
    parts <- str_trim(parts); parts <- parts[nzchar(parts)]
    ings  <- unique(stats::na.omit(nl_canon(parts, drugs)))
    if (!length(ings)) { bad <- c(bad, ln); next }

    if (nl_fix_is_span(date_cell)) {
      se <- nl_fix_dates(date_cell)$dates
      # D_LOT03_ORAL_SPAN: Optum has NO abstracted spans. If the fixture says the
      # span was accompanied by prescriptions, synthesise 28-day order episodes
      # across it AND KEEP THE SPAN'S TERMINAL DATE (dropping it shortened the
      # reconstructed line and lengthened the following gap by up to 27 days,
      # which is enough to move a near-threshold case across the R18 cliff);
      # otherwise drop the span row, which is what the primary decision says.
      if (grepl("prescription", tolower(prov_cell))) {
        dts <- sort(unique(c(seq(from = se[1], to = se[2], by = 28), se[2])))
        recon <- recon + length(dts)
        src <- "rx_presc"
      } else next
    } else {
      dd  <- nl_fix_dates(date_cell)
      recon <- recon + dd$recon
      dts <- sort(unique(c(dd$dates, extra)))
    }
    if (!length(dts) || any(is.na(dts))) { bad <- c(bad, ln); next }

    for (ig in ings) for (dv in dts)
      rows[[length(rows) + 1L]] <- tibble::tibble(
        drug = ig, drug_canon = ig, ep_date = as.Date(dv, origin = "1970-01-01"),
        route = route_cell, data_source = src)
  }
  eps <- if (length(rows)) dplyr::bind_rows(rows) else
    tibble::tibble(drug = character(0), drug_canon = character(0),
                   ep_date = as.Date(character(0)), route = character(0),
                   data_source = character(0))
  list(eps = eps, unparsed = bad, reconstructed = recon, activity_last = activity)
}

nl_parse_expect <- function(x, prefer = c("restricted", "all-source")) {
  prefer <- match.arg(prefer)
  x <- dplyr::coalesce(as.character(x), "")
  cl <- str_trim(str_split(x, ";")[[1]]); cl <- cl[nzchar(cl)]
  if (!length(cl)) return(list(value = NA_integer_, notdet = TRUE, raw = x))
  key <- if (prefer == "restricted") "restrict|rx_adm|narrow|R1\\]-OPTUM" else "all-source|all data_source|naive|naively|wide"
  pick <- cl[grepl(key, cl, ignore.case = TRUE)]
  chosen <- if (length(pick)) pick[1] else cl[1]
  if (grepl("NOT-DET", toupper(chosen))) return(list(value = NA_integer_, notdet = TRUE, raw = x))
  v <- suppressWarnings(as.integer(str_extract(chosen, "\\d+")))
  list(value = v, notdet = is.na(v), raw = x)
}

nl_parse_index_date <- function(x) {
  d <- str_extract(dplyr::coalesce(as.character(x), ""), "\\d{4}-\\d{2}-\\d{2}")
  if (is.na(d)) as.Date(NA) else as.Date(d)
}

# ---- the harness -----------------------------------------------------------
# Compare every adjudicated CSV field against the hard-coded oracle, not just
# the deliberately naive solver_lot_b column. One row per contradiction; `why`
# is the oracle entry's documented reason, NA when it has none.
nl_fixture_disagreements <- function(cs, oracle = NL_TIER1_ORACLE) {
  dis <- list()
  for (cid in names(oracle)) {
    o <- oracle[[cid]]; k <- match(cid, cs$case_id)
    if (is.na(k)) next
    add <- function(field, csv_val, oracle_val)
      dis[[length(dis) + 1L]] <<- tibble::tibble(
        case_id = cid, field = field, csv = as.character(csv_val),
        oracle = as.character(oracle_val), why = o$why %||% NA_character_)
    fb <- nl_parse_expect(cs$solver_lot_b[k])$value
    if (!is.na(fb) && !identical(as.integer(fb), o$line)) add("solver_lot_b (naive contrast)", cs$solver_lot_b[k], o$line)
    ff <- nl_parse_expect(cs$oracle_lot_flat[k])$value
    if (is.na(ff) || !identical(as.integer(ff), o$line)) add("oracle_lot_flat (CSV oracle)", cs$oracle_lot_flat[k], o$line)
    if ("author_expect_lot_flat" %in% names(cs)) {
      fa <- nl_parse_expect(cs$author_expect_lot_flat[k])$value
      if (is.na(fa) || !identical(as.integer(fa), o$line))
        add("author_expect_lot_flat (case-author expectation, NOT an oracle)",
            cs$author_expect_lot_flat[k], o$line)
    }
    mf <- tolower(str_trim(dplyr::coalesce(as.character(cs$mono_flat[k]), "")))
    mo <- if (isTRUE(o$mono)) "yes" else "no"
    if (!identical(mf, mo)) add("mono_flat", cs$mono_flat[k], mo)
    if (isTRUE(as.logical(cs$ruleset_insufficient[k])))
      add("ruleset_insufficient", "TRUE", "asserted as a determinate Tier-1 oracle")
  }
  if (length(dis)) dplyr::bind_rows(dis) else
    tibble::tibble(case_id = character(0), field = character(0), csv = character(0),
                   oracle = character(0), why = character(0))
}

# strict = TRUE stops on the first failing tier; FALSE returns the full frame so
# the whole suite can be triaged at once.
# RETURNS (invisibly) a LIST: cases, tier4, fixture_disagreements, coverage.
nl_run_regression <- function(path = NL_CASES_CSV, drugs = nl_drugs(),
                              target = NL_TARGET, strict = TRUE, verbose = TRUE) {
  if (!file.exists(path)) stop("regression fixture not found at: ", path)
  cs <- readr::read_csv(path, show_col_types = FALSE, progress = FALSE)
  # The PROVENANCE-NAMED columns are the required ones. The bare expect_* names
  # are ambiguous about whose expectation they carry, so they are read only
  # through the alias guard below and never on their own.
  req <- c("case_id","tier","advanced_dx_date","timeline",
           "oracle_lot_flat","solver_lot_a","solver_lot_b","mono_flat",
           "ruleset_insufficient")
  miss <- setdiff(req, names(cs))
  if (length(miss)) stop("fixture missing columns: ", paste(miss, collapse = ", "))

  # ALIAS GUARD. The fixture still ships the legacy expect_* names as aliases of
  # the provenance columns. If a future edit changes one and not the other, an
  # assertion silently starts reading a different value, so drift is fatal here.
  alias <- c(expect_lot_flat = "oracle_lot_flat", expect_lot_a = "solver_lot_a",
             expect_lot_b = "solver_lot_b", expect_mono_flat = "mono_flat")
  for (a in names(alias)) {
    if (!a %in% names(cs)) next
    lhs <- as.character(cs[[a]]); rhs <- as.character(cs[[alias[[a]]]])
    bad <- which(!identical(lhs, rhs) & (dplyr::coalesce(lhs, "") != dplyr::coalesce(rhs, "")))
    if (length(bad))
      stop("fixture column ", a, " has drifted from ", alias[[a]], " for: ",
           paste(cs$case_id[bad], collapse = ", "),
           " - resolve which is authoritative before running any assertion.")
  }

  nl_assert_drug_list(drugs)
  idx <- nl_role_index(drugs)

  # COVERAGE GUARD: no fixture may be silently untiered. MI-07 used to fall into
  # a "REPORT" branch and be asserted against nothing at all.
  tiered <- c(names(NL_TIER1_ORACLE), names(NL_TIER2_SENTINELS), names(NL_TIER1B_INDEX_ARMS))
  untiered <- setdiff(cs$case_id, tiered)
  if (length(untiered))
    stop("fixture(s) in no tier - they would be asserted against nothing: ",
         paste(untiered, collapse = ", "))
  orphan <- setdiff(tiered, cs$case_id)
  if (length(orphan))
    stop("oracle/sentinel entries with no fixture row: ", paste(orphan, collapse = ", "))

  res <- list()
  for (i in seq_len(nrow(cs))) {
    cid  <- cs$case_id[i]
    tier <- str_trim(dplyr::coalesce(cs$tier[i], ""))
    if (!nzchar(tier)) tier <- if (cid %in% names(NL_TIER1B_INDEX_ARMS)) "Tier 1b" else "Tier 0"
    idxd <- nl_parse_index_date(cs$advanced_dx_date[i])
    pt   <- nl_parse_timeline(cs$timeline[i], drugs)

    row <- tibble::tibble(
      case_id = cid, tier = tier, index_date = idxd,
      n_eps_parsed = nrow(pt$eps), n_unparsed = length(pt$unparsed),
      n_reconstructed = pt$reconstructed,
      unparsed_first = if (length(pt$unparsed)) pt$unparsed[1] else NA_character_,
      oracle_line = NA_integer_, oracle_mono = NA,
      got_line_narrow = NA_integer_, got_line_wide = NA_integer_,
      got_regimen = NA_character_, got_mono_narrow = NA, got_mono_wide = NA,
      indeterminate = NA, indeterminate_by = NA_character_, pivotal_by = NA_character_,
      minimal_flip = NA_character_,
      csv_flat = as.character(cs$oracle_lot_flat[i]),
      csv_lot_a = as.character(cs$solver_lot_a[i]),
      csv_lot_b_naive = as.character(cs$solver_lot_b[i]),
      status = "SKIP", detail = NA_character_
    )

    if (is.na(idxd)) {
      row$status <- "FAIL"; row$detail <- "no parseable advanced_dx_date"
      res[[cid]] <- row; next
    }
    if (!nrow(pt$eps)) {
      row$status <- "FAIL"; row$detail <- "timeline produced no episodes"
      res[[cid]] <- row; next
    }
    if (row$n_unparsed > 0) {
      # An unparsed line is a SILENTLY DELETED EPISODE. For a tiered case that is
      # a failure, not a footnote: a fixture can otherwise PASS because the
      # decisive episode was dropped (MNT-02).
      row$status <- "FAIL"
      row$detail <- paste0(row$n_unparsed, " timeline line(s) unparsed - first: ",
                           row$unparsed_first)
      res[[cid]] <- row; next
    }

    ep_all <- pt$eps |> mutate(ptid = cid) |> nl_prepare_episodes(drugs)
    stray <- setdiff(unique(ep_all$data_source), NL_EPISODE_SOURCES_WIDE)
    if (length(stray)) {
      row$status <- "FAIL"
      row$detail <- paste0("episode(s) with a data_source outside the declared builds: ",
                           paste(stray, collapse = ", "))
      res[[cid]] <- row; next
    }
    ix <- tibble::tibble(ptid = cid, index_date = idxd)
    al <- tibble::tibble(ptid = cid, activity_last = pt$activity_last)

    # The two declared builds. `wide` is the DECLARED wide source set, not
    # "everything that happened to parse".
    narrow <- ep_all |> filter(data_source %in% NL_EPISODE_SOURCES)
    wide   <- ep_all |> filter(data_source %in% NL_EPISODE_SOURCES_WIDE)

    err  <- NA_character_
    rb_n <- tryCatch(nl_lot_b(narrow, ix, drugs, list(), activity_last = al, idx = idx),
                     error = function(e) { err <<- paste("narrow build error:", conditionMessage(e)); NULL })
    # The wide build's error was previously swallowed whole. Tier 3 then read the
    # resulting NA answer as DIVERGENCE between narrow and wide, so an execution
    # failure was indistinguishable from a real source-set disagreement -- and
    # the suite could report PASS with a stage that never ran. Capture it.
    err_w <- NA_character_
    rb_w <- tryCatch(nl_lot_b(wide,   ix, drugs, list(), activity_last = al, idx = idx),
                     error = function(e) { err_w <<- paste("wide build error:",
                                                           conditionMessage(e)); NULL })
    if (!is.na(err_w)) { row$status <- "ERROR"; row$detail <- err_w
                         res[[cid]] <- row; next }
    if (is.null(rb_n)) { row$status <- "ERROR"; row$detail <- err; res[[cid]] <- row; next }

    an <- nl_target_answer(rb_n, target)
    aw <- if (is.null(rb_w)) list(line = NA_integer_, regimen = NA_character_, mono = NA)
          else nl_target_answer(rb_w, target)
    sw <- nl_decision_sensitivity(narrow, ix, drugs, target, idx = idx)

    row$got_line_narrow <- an$line; row$got_line_wide <- aw$line
    row$got_regimen     <- an$regimen
    row$got_mono_narrow <- an$mono;  row$got_mono_wide <- aw$mono
    row$indeterminate   <- sw$indeterminate
    row$indeterminate_by<- sw$indeterminate_by
    row$pivotal_by      <- sw$pivotal_by
    row$minimal_flip    <- sw$minimal_flip

    fails <- character(0)

    # ---- TIER 1: exact line number, regimen string, monotherapy, line ends ---
    if (cid %in% names(NL_TIER1_ORACLE)) {
      o <- NL_TIER1_ORACLE[[cid]]
      row$oracle_line <- o$line; row$oracle_mono <- o$mono
      if (!identical(an$line, o$line))
        fails <- c(fails, sprintf("line: expected %s, got %s", o$line, an$line))
      if (isTRUE(o$mono)) {
        if (!identical(an$regimen, target))
          fails <- c(fails, sprintf("regimen: expected '%s', got '%s'", target, an$regimen))
      } else {
        if (is.na(an$regimen) || identical(an$regimen, target))
          fails <- c(fails, sprintf("regimen: expected a multi-agent regimen containing %s, got '%s'",
                                    target, an$regimen))
      }
      if (!identical(an$mono, o$mono))
        fails <- c(fails, sprintf("monotherapy: expected %s, got %s", o$mono, an$mono))

      # asserted line end dates (R26). NOT asserted where the timeline had to be
      # reconstructed by the parser - the dates would be the parser's, not the
      # fixture's.
      chk_end <- function(l, want, lbl) {
        if (is.null(want)) return(character(0))
        if (row$n_reconstructed > 0)
          return(paste0("R26 ", lbl, " end NOT asserted: ", row$n_reconstructed,
                        " reconstructed episode date(s) in this fixture"))
        got <- rb_n$lines$line_end[rb_n$lines$line == l]
        if (!length(got) || !identical(as.Date(got[1]), want))
          return(sprintf("R26 %s end: expected %s, got %s", lbl, want,
                         if (length(got)) as.character(got[1]) else "NA"))
        character(0)
      }
      e1 <- chk_end(1L, o$line1_end, "1L"); e2 <- chk_end(2L, o$line2_end, "2L")
      fails <- c(fails, e1[!grepl("NOT asserted", e1)], e2[!grepl("NOT asserted", e2)])

      if (!is.null(o$extra_line) && nrow(rb_n$lines)) {
        hits <- rb_n$lines$line[vapply(rb_n$lines$drug_set_window, nl_set_has, logical(1), target)]
        if (!(o$extra_line %in% hits))
          fails <- c(fails, sprintf("expected a second %s line at %s; got lines %s",
                                    target, o$extra_line, paste(hits, collapse = ",")))
      }

      # ---- Tier-1 NEGATIVE assertion on indeterminacy ----------------------
      # A determinate oracle must not depend on a substituted decision, beyond
      # the declared tolerances (always G1, the cohort-wide caveat; plus the
      # per-case `tolerated_gaps`). Without this the indeterminacy machinery is
      # unfalsifiable: an implementation that flags every patient indeterminate
      # would pass all 35 fixtures.
      tol <- o$tolerated_gaps %||% "G1"
      got_g <- str_trim(str_split(dplyr::coalesce(sw$indeterminate_by, ""), ",")[[1]])
      got_g <- got_g[nzchar(got_g)]
      extra_g <- setdiff(got_g, tol)
      if (length(extra_g))
        fails <- c(fails, paste0("Tier 1 case is indeterminate by {", paste(extra_g, collapse = ","),
                                 "} beyond its declared tolerance {", paste(tol, collapse = ","),
                                 "} - minimal flipping combination: ", sw$minimal_flip))
      row$status <- if (length(fails)) "FAIL" else "PASS"
    }

    # ---- TIER 1b: index-date arms (MI-07) -----------------------------------
    else if (cid %in% names(NL_TIER1B_INDEX_ARMS)) {
      o <- NL_TIER1B_INDEX_ARMS[[cid]]
      lines_seen <- integer(0)
      for (arm in o$arms) {
        rb <- nl_lot_b(narrow, tibble::tibble(ptid = cid, index_date = arm$index_date),
                       drugs, list(), activity_last = al, idx = idx)
        a  <- nl_target_answer(rb, target)
        lines_seen <- c(lines_seen, if (is.na(a$line)) NA_integer_ else a$line)
        if (!identical(a$line, arm$line))
          fails <- c(fails, sprintf("index arm '%s' (%s): expected line %s, got %s",
                                    arm$label, arm$index_date, arm$line, a$line))
        if (!identical(a$mono, o$mono))
          fails <- c(fails, sprintf("index arm '%s': expected monotherapy %s, got %s",
                                    arm$label, o$mono, a$mono))
      }
      if (length(unique(stats::na.omit(lines_seen))) < 2L)
        fails <- c(fails, paste("the two index-date definitions did NOT change the line number;",
                                "D_INDEX_DATE is the largest declared risk in this file and this",
                                "is the only fixture that probes it"))
      row$oracle_line <- o$arms[[1]]$line; row$oracle_mono <- o$mono
      row$status <- if (length(fails)) "FAIL" else "PASS"
    }

    # ---- TIER 2: must flag indeterminate, not answer silently ---------------
    else if (cid %in% names(NL_TIER2_SENTINELS)) {
      spec <- NL_TIER2_SENTINELS[[cid]]
      fails <- c(fails, nl_tier2_check(sw, spec$want, spec$pivotal_only, an))
      # SA-07: naming indeterminacy must NOT leak into the line number.
      if (identical(cid, "SA-07")) {
        if (!identical(an$line, 2L))
          fails <- c(fails, sprintf("SA-07: line must remain 2 despite the R21 naming tie; got %s", an$line))
        l1 <- rb_n$lines$regimen_indeterminate[rb_n$lines$line == 1L]
        if (!length(l1) || !isTRUE(l1[1]))
          fails <- c(fails, "SA-07: 1L regimen name must be NA with reason G10-exact-tie")
      }
      row$status <- if (length(fails)) "FAIL" else "PASS"
    }

    # ---- TIER 3: the two builds must diverge, on the DOCUMENTED field -------
    if (cid %in% names(NL_TIER3_PAIRS)) {
      wide_only <- sum(!ep_all$data_source %in% NL_EPISODE_SOURCES)
      if (wide_only == 0L) {
        fails <- c(fails, paste0("TIER 3: fixture has no wide-only episodes - it is not a ",
                                 "source-divergence pair and should not be listed"))
      } else {
        fld <- NL_TIER3_PAIRS[[cid]]
        reason_of <- function(r) {
          if (is.null(r) || !nrow(r$lines)) return(NA_character_)
          h <- r$lines |> filter(vapply(drug_set_window, nl_set_has, logical(1), target)) |>
            arrange(line) |> slice(1)
          if (!nrow(h)) NA_character_ else h$advance_reason[1]
        }
        div <- switch(fld,
          line    = !identical(an$line, aw$line),
          mono    = !identical(an$mono, aw$mono) || !identical(an$regimen, aw$regimen),
          advance_reason = !identical(reason_of(rb_n), reason_of(rb_w)),
          any     = !identical(an$line, aw$line) || !identical(an$regimen, aw$regimen) ||
                    !identical(an$mono, aw$mono),
          stop("unknown Tier-3 divergence field: ", fld))
        if (!div)
          fails <- c(fails, paste0("TIER 3: builds did not diverge on '", fld,
                                   "' (narrow line ", an$line, " / wide ", aw$line,
                                   ", narrow mono ", an$mono, " / wide ", aw$mono,
                                   ", narrow reason '", reason_of(rb_n),
                                   "' / wide '", reason_of(rb_w), "'; ",
                                   wide_only, " wide-only episode(s)) - the source ",
                                   "restriction is not being applied"))
      }
      row$status <- if (length(fails)) "FAIL" else row$status
    }

    if (length(fails)) row$detail <- paste(fails, collapse = " || ")
    res[[cid]] <- row
  }

  out <- dplyr::bind_rows(res)

  # ---- TIER 4: LOT-A discordance fixtures. Not unit tests of LOT-B; inputs to
  #      the method-comparison table, grouped by mechanism.
  t4 <- purrr::imap_dfr(NL_TIER4_MECHANISMS, function(ids, mech) {
    out |> filter(case_id %in% ids) |>
      transmute(mechanism = mech, case_id,
                lot_a = vapply(csv_lot_a, function(z) nl_parse_expect(z)$value, integer(1)),
                lot_b = got_line_narrow,
                discordant = !is.na(lot_a) & !is.na(lot_b) & lot_a != lot_b)
  })

  # ---- fixture-vs-report disagreements ------------------------------------
  # Every contradiction must carry a `why` in the oracle; an undocumented one
  # fails the strict run (a contradicted CSV is otherwise invisible).
  disagree <- nl_fixture_disagreements(cs)
  undoc    <- if (nrow(disagree)) disagree[is.na(disagree$why), , drop = FALSE] else disagree

  coverage <- tibble::tibble(
    decision_id = names(NL_DECISIONS),
    gap = vapply(NL_DECISIONS, function(d) as.character(d$gap), character(1)),
    swept = vapply(names(NL_DECISIONS), nl_dec_sweep, character(1)),
    exercised_by_suite = vapply(NL_DECISIONS, function(d) isTRUE(d$exercised), logical(1)))

  if (verbose) {
    message("\n==== LOT-B regression, ", nrow(out), " fixtures ====")
    print(out |> count(tier, status))
    bad <- out |> filter(status %in% c("FAIL", "ERROR"))
    if (nrow(bad)) { message("\n---- failures ----"); print(as.data.frame(bad[, c("case_id","tier","status","detail")])) }
    rc <- out |> filter(n_reconstructed > 0)
    if (nrow(rc)) {
      message("\n---- fixtures whose timeline the parser RECONSTRUCTED (invented dates) ----")
      print(as.data.frame(rc[, c("case_id", "n_reconstructed")]))
      message("(line END dates are not asserted for these; the dates are the parser's)")
    }
    message("\n---- indeterminacy per fixture ----")
    print(as.data.frame(out[, c("case_id","indeterminate","indeterminate_by","pivotal_by","minimal_flip")]))
    if (nrow(disagree)) {
      message("\n---- fixture CSV disagrees with the adjudicated report oracle ----")
      message("(solver_lot_b predicts a NAIVE rebuild; this engine is not naive. Every other ",
              "row is an explicit override of an adjudicated CSV field - read `why`.)")
      print(as.data.frame(disagree))
    }
    ne <- purrr::imap(NL_TIER2_SENTINELS, function(s, cid)
      if (length(s$not_exercisable)) paste0(cid, ": ", paste(names(s$not_exercisable), "-",
                                                            unname(s$not_exercisable), collapse = " ; ")) else NULL)
    ne <- unlist(Filter(Negate(is.null), ne))
    if (length(ne)) {
      message("\n---- sentinel gaps this suite CANNOT exercise (declared, not asserted) ----")
      for (z in ne) message("  ", z)
    }
    message("\n---- Tier 4: LOT-A discordance by mechanism ----")
    print(t4 |> group_by(mechanism) |> summarise(n = n(), discordant = sum(discordant, na.rm = TRUE), .groups = "drop"))
    message("\n---- decision register in force ----")
    print(as.data.frame(nl_decision_register()[, c("decision_id","gap","value","alternative","swept","exercised_by_suite")]))
    unex <- coverage$decision_id[!coverage$exercised_by_suite]
    message("\nDECISIONS DECLARED BUT NOT EXERCISED BY ANY FIXTURE: ",
            paste(unex, collapse = ", "))
    message("COVERAGE GAPS IN THE SUITE ITSELF (05_... sec 6): no case exercises ",
            "clinical study drug (G13), second primary (G14 - NOT IMPLEMENTED: no flag, no filter), month- or year-granularity ",
            "oral spans (R11/R12), same-day duplicate episodes (G8), the R16 anchor (G9), ",
            "the R14 failed-test fork, or the R24 line-end/death interaction against ",
            "Optum's month-only DATE_OF_DEATH - which matters for rwOS, not just line ends. ",
            "At least five further synthetic patients are needed before the suite is adequate.")
  }

  nfail <- sum(out$status %in% c("FAIL", "ERROR", "SKIP"))
  if (nrow(undoc) && strict)
    stop("regression: ", nrow(undoc), " fixture-vs-oracle disagreement(s) with no `why`: ",
         paste(unique(paste0(undoc$case_id, ":", undoc$field)), collapse = ", "),
         " - document them in NL_TIER1_ORACLE or correct the CSV")
  if (nfail && strict) stop("regression FAILED for ", nfail, " case(s) - see the table above")
  invisible(list(cases = out, tier4 = t4, fixture_disagreements = disagree, coverage = coverage))
}

# ============================================================================
# Known limits, provenance, and what has never been run: ../METHODS.md
# ============================================================================
