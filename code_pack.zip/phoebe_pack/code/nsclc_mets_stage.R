# ============================================================================
# nsclc_mets_stage.R - Metastatic SITE and STAGE (TNM) from Optum Enriched
#                      Oncology, for the advanced-NSCLC prognostic score.
#
# Answers "which body part, and what stage" - variables the Flatiron advNSCLC
# data product does not carry at all. Namespace nm_ / NM_; drops in alongside
# nsclc_lot.R.
#
# THE GUARD THAT MATTERS MOST: t_onc_metastatic_location.mets_qualifier is
# 'actual' or 'absent', and 'absent' means THE NOTE NEGATED METASTASIS AT THAT
# SITE. A row's existence is NOT a positive. Every extraction path goes through
# nm_mets_rows(), which requires mets_qualifier == 'actual' and asserts it.
#
# NOTHING IN THIS FILE HAS BEEN RUN AGAINST THE WAREHOUSE. nm_vocab_scan() must
# run first: every mapping is keyed on a value SAMPLE, not a closed vocabulary.
#
# Limitations, provenance and open questions: ../METHODS.md
# ============================================================================

suppressPackageStartupMessages({
  library(DBI); library(odbc); library(dplyr); library(dbplyr)
})

`%||%` <- function(a, b) if (is.null(a)) b else a

# ============================================================================
# 0. CONFIG
# ============================================================================

# Identical to nsclc_lot.R and to the precedent. Restated (not sourced) so this
# file stands alone; if both files are source()d the definitions are the same
# object, so load order does not matter.
MC_CATALOG <- "hive_metastore"
MC_SCHEMA  <- "clnprw_optum_mc_full_use"
MC_CUT     <- "2025q4"

# Data-cut ceiling. Rows after this are not trustworthy as "observed by the
# cut"; the sample contains note_date values into 2025-12, which is why an
# explicit ceiling exists rather than "whatever is in the table".
NM_STUDY_END <- as.Date("2025-12-31")

# Every t_onc_* table requires the patient to have physician notes. This is not
# a filter we chose - it is what the enriched-oncology layer is built from - but
# it IS a cohort restriction and must be reported as one (see KNOWN LIMITS).
NM_REQUIRE_NOTES <- TRUE

# AJCC 8th edition took effect for cases diagnosed from 2017-01-01. There is NO
# staging-edition column in t_onc_tnm (varlist.txt RESULT 9 lists 18 columns,
# none of them an edition), so note_date is the only available proxy and it is
# a proxy, not the edition. See D_AJCC_EDITION and KNOWN LIMITS L.
NM_AJCC8_FROM <- as.Date("2017-01-01")

# ---- Lung-primary identification -------------------------------------------
# ICD-10 (stored WITHOUT decimals in Optum): C34 = malignant neoplasm of
# bronchus and lung. C33 (trachea) is NOT lung and is not included.
NM_LUNG_ICD10_3   <- c("C34")
# ICD-9 lung primary: the 3-character root 162 = malignant neoplasm of trachea,
# bronchus and lung. Matched at 3 characters because ICD-9 codes are variable
# length in this deployment and a bare '162' is real in problem lists. 162.0 is
# TRACHEA and is carved out of the lung leg by NM_TRACHEA_ICD9 - but see the
# comment in nm_single_lung_primary(): the carve-out must ALSO be excluded from
# the other-primary test, or a trachea code silently disqualifies the patient
# from mode C.
NM_LUNG_ICD9_3    <- c("162")
NM_TRACHEA_ICD9   <- c("1620")
# Secondary / metastatic ICD-10 3-char roots. A secondary code is NOT another
# primary, so it must not disqualify a single-primary patient.
NM_SECONDARY_ICD10_3 <- c("C77", "C78", "C79", "C7B")
# ICD-9 secondary neoplasm roots (196/197/198) and 199 (unspecified site).
# WIRED: used by nm_single_lung_primary()'s other-primary filter, so the
# exclusion is expressed by the constant rather than implied by a range bound.
NM_SECONDARY_ICD9_PFX <- c("196", "197", "198", "199")
# C80.0 (disseminated malignant neoplasm, unspecified) and C80.1 (malignant
# primary neoplasm, unspecified) name NO competing primary site and are routine
# in advanced metastatic patients - i.e. exactly this cohort. Treated as NOT a
# competing primary by default (D_C80_PRIMARY). C97 (multiple independent
# primaries) genuinely IS competing and stays disqualifying.
NM_UNSPECIFIED_ICD10_3 <- c("C80")
# ICD-9 other-primary ranges, as 3-character string bounds. 140-195 = solid
# primaries; 200-209 = lymphoma/leukaemia/neuroendocrine, included so the ICD-9
# leg covers the same disease space as the ICD-10 leg (which disqualifies on
# C81-C96 and C7A by construction). 196-199 are excluded via
# NM_SECONDARY_ICD9_PFX.
NM_OTHER_PRIMARY_ICD9_RANGES <- list(c("140", "195"), c("200", "209"))

# Substring probes used to find the LUNG tumour rows in
# t_onc_neoplasm_histology. TWO columns are probed, because they hold different
# things (varlist.txt RESULT 8):
#   neoplasm_type varchar(25) - the ANATOMICAL term. Confirmed for this
#     deployment in "proc and neoplasm.txt": the value is the bare word 'lung'
#     (13,275,346 rows). So 'LUNG' and 'BRONCH' are the only sensible probes
#     here; histology words would match nothing.
#   histology varchar(65) - the HISTOLOGY term. The lung-specific histology
#     vocabulary of this deployment has NOT been dumped, so the strings below
#     are UNVERIFIED probes and nm_neoplasm_type_scan() exists to confirm or
#     replace them.
NM_LUNG_NEO_SUBSTR  <- c("LUNG", "BRONCH")
NM_LUNG_HIST_SUBSTR <- c("NON-SMALL CELL", "NON SMALL CELL", "NSCLC",
                         "BRONCHOGENIC", "BRONCHIOLOALVEOLAR")

# ============================================================================
# 0b. NM_DECISIONS - every point where WE choose and the data does not settle it
#
# Same contract as NL_DECISIONS in nsclc_lot.R. Fields:
#   question    the choice, stated as a question
#   value       the branch pre-specified and run as PRIMARY
#   alternative the branch(es) available as a sensitivity
#   basis       why the primary branch was chosen (or: that it is arbitrary)
#   settled_by  what evidence WOULD settle it (a scan, Optum, or an SME)
#   wired       TRUE  = the engine reads this through nm_dec(), so editing
#                       `value` here CHANGES THE RESULT
#               FALSE = the choice is hard-coded in the function named in
#                       `basis`; editing `value` here changes NOTHING. Printed
#                       by nm_decision_register() so the SAP appendix cannot
#                       claim a switch that does not exist.
#
# Engine code reads wired decisions through nm_dec(), never from the comment.
# Anything here belongs in the SAP as a pre-specified decision.
# ============================================================================

NM_DECISIONS <- list(

  D_METS_QUALIFIER = list(
    question = paste("mets_qualifier is actual/absent. Which rows are a positive metastasis?"),
    value = "actual_only", alternative = "any_row", wired = TRUE,
    basis = paste("'absent' is a NEGATED mention - the note said there is no metastasis at that",
                  "site. Counting row existence would invent metastases wholesale. This is not",
                  "really a judgement call, it is a correctness requirement; it is registered as a",
                  "decision only so that the alternative is named and provably not taken."),
    settled_by = "Optum EO data dictionary (already unambiguous); nm_vocab_scan() confirms the value set."
  ),

  D_METS_TEMPORAL = list(
    question = paste("mets_temporal_status is current/history. Does a 'history' row count as",
                     "metastatic disease at that site?"),
    value = "current_and_history", alternative = c("current_only", "history_only"), wired = TRUE,
    basis = paste("Metastatic status in advanced NSCLC is ABSORBING for prognostic purposes - a",
                  "site documented as historical was still involved. Excluding 'history' would",
                  "undercount exactly the patients furthest along, which is the direction that",
                  "biases a prognostic score. Retained but TAGGED, so the sensitivity is one",
                  "filter away. Read by nm_mets_rows(), and by nm_orphan_impact() through the",
                  "same function so the two cannot diverge."),
    settled_by = "SME (Epi) sign-off; nm_vocab_scan() sizes how many rows are 'history'."
  ),

  D_TIMING_ANCHOR = list(
    question = "Which date is the metastasis date - note_date or metastasis_dx_date?",
    value = "note_date_with_exact_refinement", alternative = c("note_date_only", "dx_date_only"),
    wired = FALSE,
    basis = paste("HARD-CODED in NM_EXACT_DXDATE_SQL / nm_mets_rows(). metastasis_dx_date is",
                  "mostly NULL and mixed-format ('2009mmdd' with dx_date_type='incomplete'), so",
                  "it cannot be the anchor. note_date always exists. The exact-typed dx date is",
                  "used ONLY as a BACKWARD refinement (it can move the date earlier, never",
                  "later), because a note dated 2017 recording a 2014 biopsy-proven bone met is",
                  "genuine 2014 information."),
    settled_by = "Nothing further - the date-quality facts are observed in the live 2025q4 sample."
  ),

  D_DX_DATE_PARSE = list(
    question = "Can metastasis_dx_date be parsed when metastasis_dx_date_type = 'exact'?",
    value = "require_calendar_valid_and_exact_and_try_to_date", alternative = "trust_dx_date_type",
    wired = FALSE,
    basis = paste("HARD-CODED in NM_EXACT_DXDATE_SQL. dx_date_type is doing real work, but the",
                  "parse is belt-and-braces THREE times over: type='exact', AND a CALENDAR-VALID",
                  "8-digit regex (not merely 8 digits - a zero-filled partial such as '20090000'",
                  "or '20140300' passes ^[0-9]{8}$ and would reach the parser), AND try_to_date()",
                  "rather than to_date(). Databricks SQL warehouses run ANSI mode ON by default,",
                  "where to_date() on an unparseable string ABORTS THE QUERY instead of returning",
                  "NULL; try_to_date() returns NULL. A mistyped partial therefore yields NULL,",
                  "not a wrong date and not a failed run."),
    settled_by = "nm_vocab_scan()$dx_date_type - it counts rows that are 'exact' and 8-digit but calendar-invalid."
  ),

  D_ORPHAN_KEY_MODE = list(
    question = paste("~70% of t_onc_tnm / t_onc_stage rows (and an unknown share of",
                     "t_onc_metastatic_location rows) have a NULL neoplasm_histology_key. Do",
                     "those orphan rows get attributed to the lung primary?"),
    value = "A", alternative = "C", wired = TRUE,
    basis = paste("Mode A (keyed rows only) is the production default from the colon precedent:",
                  "it cannot attribute another primary's stage to the lung cancer. It WILL",
                  "under-count. Mode C additionally claims orphan rows for single-lung-primary",
                  "patients, which is what the Optum EO guide 4.3 recommends. Run",
                  "nm_orphan_impact() and report BOTH; do not pick on vibes. Every reader",
                  "(nm_lung_attributed) DEFAULTS its mode from this entry, so editing it here",
                  "really does switch the run."),
    settled_by = "nm_orphan_impact() sizes it; Optum can confirm why the key is null so often."
  ),

  D_C80_PRIMARY = list(
    question = "Is an ICD-10 C80 code (unspecified primary / disseminated malignancy) a COMPETING primary?",
    value = "not_a_competing_primary", alternative = "treat_c80_as_primary", wired = TRUE,
    basis = paste("C80.0 and C80.1 name no site. They are routine in advanced metastatic",
                  "patients, i.e. in exactly this cohort. Treating them as a second primary",
                  "would remove those patients from nm_single_lung_primary() and therefore",
                  "delete their orphan rows from mode C - deflating the very measurement that",
                  "decides D_ORPHAN_KEY_MODE, in the direction that makes mode A look cheap.",
                  "C97 (multiple independent primaries) stays disqualifying."),
    settled_by = "nm_orphan_impact() reports mode C both ways; SME (Epi) to confirm."
  ),

  D_PREINDEX_WINDOW = list(
    question = "Over what window before the 2L index are metastatic sites counted?",
    value = "all_history_up_to_index", alternative = c("365", "180", "90"), wired = TRUE,
    basis = paste("Metastatic involvement is absorbing, so a fixed lookback would drop sites",
                  "documented at advanced diagnosis for a patient whose 2L index is two years",
                  "later - i.e. it would systematically undercount the longest survivors.",
                  "nm_mets_summary(lookback_days=) overrides; when the argument is NULL the",
                  "value here is what runs, and a numeric string here is read as days."),
    settled_by = "SME (Epi). The inventory itself flags 'define window' for every ICD-proxy row."
  ),

  D_INDEX_DAY_INCLUSIVE = list(
    question = "Does a metastasis documented ON the index date count as pre-index?",
    value = "inclusive", alternative = "strictly_before", wired = TRUE,
    basis = paste("Baseline work-up is routinely noted on the day therapy starts. Excluding the",
                  "index day drops real baseline disease. The cost is that a site first found on",
                  "the index day is treated as known at index, which is a mild optimism about",
                  "what the clinician knew."),
    settled_by = "SME (Epi)."
  ),

  D_NSITES_UNIT = list(
    question = paste("n_met_sites counts DISTINCT what - raw metastasis_location values, or",
                     "canonical anatomical groups?"),
    value = "canonical_group", alternative = "raw_location_value", wired = TRUE,
    basis = paste("'bone', 'rib' and 'vertebral column' are three observed values for one",
                  "anatomical compartment; counting raw values would score that patient 3 and a",
                  "patient with plain 'bone' 1. The published variable is 'number of metastatic",
                  "ORGANS / sites' (Shang2021 HR 1.563; Sun2026 HR 1.76), which is a compartment",
                  "count. NOTE the interaction with D_UNMAPPED_SITE: an UNMAPPED value is its",
                  "own counting unit even under canonical_group, so distinct unseen sites are",
                  "not silently merged into one."),
    settled_by = "SME (Epi) against the source publications' own site definitions."
  ),

  D_UNMAPPED_SITE = list(
    question = "What happens to a metastasis_location value this file has never seen?",
    value = "count_each_in_n_sites_and_report", alternative = "drop_and_report", wired = FALSE,
    basis = paste("HARD-CODED in nm_mets_summary()'s site_unit construction. A documented site",
                  "is a site. Dropping it silently would undercount n_met_sites - the",
                  "highest-evidence variable here - by exactly the amount nobody would notice,",
                  "and collapsing all unmapped values into ONE compartment would undercount it",
                  "by nearly as much. Each distinct unmapped value is therefore its own counting",
                  "unit ('unmapped_other:<raw value>'), it is reported in $unmapped, and",
                  "n_unmapped_sites says how much of n_met_sites came from unmapped values.",
                  "The met_unmapped_other FLAG remains a single flag."),
    settled_by = "nm_vocab_scan(); every unmapped value should be mapped before the primary run."
  ),

  D_CHEST_SITE = list(
    question = "Observed value 'chest' - which compartment is it?",
    value = "other_unclassified", alternative = c("pleura", "lung"), wired = FALSE,
    basis = paste("HARD-CODED in NM_SITE_MAP. 'chest' is anatomically ambiguous (chest wall,",
                  "thoracic cavity, or a loose synonym for intrathoracic). Forcing it into",
                  "pleura or lung would manufacture a specific site flag out of a vague word. It",
                  "counts as a site - so a patient documented as 'lung', 'pleura' and 'chest'",
                  "scores n_met_sites = 3 for what may be one intrathoracic compartment. It is",
                  "grouped with the intrathoracic flags (NM_INTRATHORACIC_GROUPS) and reported",
                  "separately."),
    settled_by = "Optum EO curation rules for the site vocabulary."
  ),

  D_VISCERAL_DEF = list(
    question = "Which compartments are 'visceral' for a LUNG primary?",
    value = "extrathoracic_organ_parenchyma",
    alternative = c("include_lung_as_visceral", "include_pleura_as_visceral"), wired = FALSE,
    basis = paste("HARD-CODED in NM_VISCERAL_GROUPS / NM_NONVISCERAL_GROUPS /",
                  "NM_INTRATHORACIC_GROUPS. For a lung primary, lung and pleura are the SAME",
                  "AJCC M1a category (separate nodule in a contralateral lobe; pleural or",
                  "pericardial nodules/effusion) and are intrathoracic-only disease - the",
                  "best-prognosis metastatic subgroup. Putting lung in 'visceral' and pleura in",
                  "'non-visceral', as an unthinking generic definition does, splits one",
                  "prognostic group across both levels of the covariate. So: visceral = liver,",
                  "adrenal, peritoneum and other EXTRATHORACIC solid-organ parenchyma;",
                  "non-visceral = bone and lymph node; intrathoracic = lung, pleura and the",
                  "ambiguous 'chest', flagged on their own."),
    settled_by = "SME (Epi) / the specific publication the score is benchmarked against."
  ),

  D_BRAIN_IS_VISCERAL = list(
    question = "Does brain/CNS count inside the visceral flag?",
    value = "no_separate_cns_flag", alternative = "yes_visceral_includes_cns", wired = FALSE,
    basis = paste("HARD-CODED in NM_CNS_GROUPS. Brain metastasis is carried as its own covariate",
                  "in the inventory (advN row 'Brain/CNS metastasis'; a REVEL exclusion",
                  "criterion and a LUME-Lung 1 stratification factor). Folding it into",
                  "'visceral' would collinearly hide the variable the literature models."),
    settled_by = "SME (Epi)."
  ),

  D_STAGE_BASIS = list(
    question = paste("Stage for the model: stage AT DIAGNOSIS (earliest record) or EVER-STAGED",
                     "up to index (highest recorded)? The precedent leaves this open."),
    value = "at_diagnosis", alternative = "ever_pre_index", wired = TRUE,
    basis = paste("DEFAULT IS at_diagnosis, and this is the more defensible of the two: (i) it",
                  "is the same object as the Flatiron data-product field ('Stage at initial dx",
                  "... not re-staged at 2L'), so the Optum and Flatiron analyses stay",
                  "comparable; (ii) 'ever-staged up to index' takes a maximum over a number of",
                  "records that is itself a function of how much care the patient received, so",
                  "sicker-documented patients stage higher for documentation reasons - an",
                  "informative-observation bias straight into a prognostic score. ever_pre_index",
                  "is exposed as a first-class mode and should be reported as a sensitivity."),
    settled_by = "SME (Epi) + a run of both modes; nm_stage_at_index() returns either."
  ),

  D_STAGE_AT_DX_INFORMATIVE = list(
    question = paste("Under basis='at_diagnosis', does the EARLIEST record win even when it",
                     "carries no stage at all?"),
    value = "earliest_informative_record", alternative = "earliest_record_informative_or_not",
    wired = TRUE,
    basis = paste("A t_onc_tnm row can carry only a stage_prefix (null leads every one of the",
                  "observed t/n/m distributions), and t_onc_stage carries ~267k free-text rows",
                  "('early stage' 85,300; 'extensive stage' 94,369; 'limited stage' 75,512;",
                  "'advanced' 11,511) that correctly parse to ajcc_group = NA. Ordering by date",
                  "FIRST would let such a record win and BLANK a patient who has a fully",
                  "populated record a month later and still pre-index - turning a documented M1c",
                  "into m1_any = FALSE, which is worse than missing. So informativeness is",
                  "ranked ahead of date, 'at diagnosis' means the earliest record that actually",
                  "carries a numeric category (a TxNxMx row is uninformative, exactly like an",
                  "empty one), and n_uninformative_records_skipped reports the size of",
                  "the effect. The selected record's own date is returned as tnm_note_date /",
                  "stage_note_date so the gap is auditable."),
    settled_by = "SME (Epi); the skipped-record counts size it."
  ),

  D_TNM_PREFIX = list(
    question = paste("t_prefix / n_prefix / m_prefix carry the AJCC descriptor (c, p, and",
                     "critically y = post-neoadjuvant restaging and r = recurrence). Do y/r",
                     "records count as a DIAGNOSIS stage?"),
    value = "exclude_y_r_from_at_diagnosis", alternative = "keep_all_flagged", wired = TRUE,
    basis = paste("In a 2L docetaxel cohort every patient is post-1L therapy, so y-prefixed",
                  "restaging records are exactly the ones likely to be present. A ycT0N0M0",
                  "restaging note is not a diagnosis stage and must not win the at_diagnosis",
                  "tiebreak. Excluded from the at_diagnosis SELECTION only; the records are",
                  "still returned in $tnm, still counted, and has_y_or_r_prefix is reported per",
                  "patient. UNVERIFIED: the *_prefix vocabulary of this deployment has never",
                  "been dumped - nm_vocab_scan() now dumps it. Until then this filter fires on",
                  "whatever letters are actually there."),
    settled_by = "nm_vocab_scan()$t_prefix / $n_prefix / $m_prefix."
  ),

  D_STAGE_TIEBREAK = list(
    question = "Two staging records tie on informativeness and date. Which one wins?",
    value = "most_complete_then_pathological_then_first_source",
    alternative = "arbitrary_first_row", wired = FALSE,
    basis = paste("HARD-CODED in nm_stage_reduce()'s order() calls. Deterministic and stated:",
                  "prefer the record with the most of {t,n,m} carrying a NUMERIC (0-4) category",
                  "('x', 'is' and unparsed tokens do not count; nm_tnm_n_informative()), then",
                  "stage_prefix='pathological' over 'clinical' over NULL, then sourceid",
                  "ascending. The last leg is arbitrary but REPRODUCIBLE, which the unstated",
                  "alternative is not."),
    settled_by = "Nothing - it is a tie. Reproducibility is the only property available."
  ),

  D_STAGE_FREETEXT = list(
    question = paste("t_onc_stage.stage contains free text ('advanced','limited stage',",
                     "'extensive stage','early stage','end stage canc...'), bare suffixes",
                     "a/b/c/d, Ann-Arbor-like ie/iae/iie/iiae, leaked m0..m7 and a '5'. Do any",
                     "of these become an AJCC group?"),
    value = "classify_and_exclude", alternative = "map_advanced_to_stage_4", wired = FALSE,
    basis = paste("HARD-CODED in nm_stage_parse(). None of them is an AJCC group. They are",
                  "CLASSIFIED (so the contamination is measurable) and excluded from",
                  "ajcc_group. Mapping 'advanced' to IV would be inventing a stage; 'limited /",
                  "extensive stage' is SCLC vocabulary and its presence in a lung cohort is",
                  "itself a signal worth reporting. The parser ANCHORS the whole string against",
                  "the AJCC suffix grammar, so an unseen token cannot manufacture a stage by",
                  "starting with an i or a digit."),
    settled_by = "Optum - the mixed source vocabularies feeding one column are undocumented here."
  ),

  D_STAGE_PREFIX = list(
    question = "Filter staging records to clinical or pathological only?",
    value = "no_filter_keep_prefix", alternative = c("clinical_only", "pathological_only"),
    wired = FALSE,
    basis = paste("HARD-CODED (there is simply no such filter). stage_prefix is NULL on 19.4M of",
                  "21.2M t_onc_tnm rows (observed). Filtering on it would discard ~91% of the",
                  "staging data. It is CARRIED on every returned row instead, so a",
                  "prefix-restricted sensitivity is one filter away. Same open question the",
                  "colon precedent flagged and did not close."),
    settled_by = "Optum: why is stage_prefix null so often, and is null informative?"
  ),

  D_M_SUBCATEGORY = list(
    question = "Where does M1a/M1b/M1c come from - the m column or m_suffix?",
    value = "m_column_then_m_suffix", alternative = "m_column_only", wired = FALSE,
    basis = paste("HARD-CODED in nm_m1_subcategory(). The observed m distribution already",
                  "carries 1a/1b/1c in the m column itself, so that is the primary read.",
                  "m_suffix is consulted ONLY when m is bare '1', and only when it matches",
                  "^[abc]$ - the m_suffix VOCABULARY HAS NEVER BEEN DUMPED, so anything else",
                  "leaves m1_subcategory = 'M1_NOS' and keeps the raw suffix visible rather",
                  "than guessing."),
    settled_by = "nm_vocab_scan()$m_suffix - run it before relying on the m_suffix leg at all."
  ),

  D_AJCC_EDITION = list(
    question = paste("M1b means different things in AJCC 7 and AJCC 8, and there is no edition",
                     "column. Do pre-2017 M1b/M1c records enter the M1 subcategory variable?"),
    value = "collapse_pre_ajcc8_to_M1_NOS", alternative = "pool_all_eras", wired = TRUE,
    basis = paste("In AJCC 7 (in force for notes up to ~2016) lung M1b = ANY distant metastasis,",
                  "i.e. 7th-ed M1b spans 8th-ed M1b + M1c. In AJCC 8 (2017+) M1b = a SINGLE",
                  "extrathoracic lesion in a single organ and M1c = multiple. Pooling the two",
                  "eras mixes 'any distant met' with 'single extrathoracic lesion' and corrupts",
                  "the M1b-vs-M1c gradient, which is the specific structural gain this file",
                  "offers over Flatiron. t_onc_tnm has no edition field, so note_date is used as",
                  "a PROXY (NM_AJCC8_FROM) and pre-2017 records are collapsed to M1_NOS with the",
                  "raw m still visible. A record with a missing note_date is treated as unknown",
                  "era and collapsed too. m1_edition_era is returned alongside so the collapse",
                  "is auditable. The same caveat applies to t_cat (T1a/b/c size cut-offs and the",
                  "T3/T4 definitions also changed in AJCC 8) - it is NOT corrected there, only",
                  "stated (KNOWN LIMITS L)."),
    settled_by = "Optum - is there an edition field anywhere in the EO layer? Otherwise SME (Epi)."
  ),

  D_ICD_FALLBACK = list(
    question = paste("Should the ICD proxy (the Flatiron-equivalent read) be used to FILL IN",
                     "sites for patients with no enriched-oncology metastasis row?"),
    value = "report_separately_never_merge", alternative = "union_into_primary", wired = FALSE,
    basis = paste("HARD-CODED (there is no merge path in this file). The two are different",
                  "measurements: the EO site is a curated, negatable assertion; the ICD code is",
                  "a billing artefact with no negation and no 'absent'. Unioning them makes a",
                  "variable whose meaning depends on which source happened to fire, and destroys",
                  "the very comparison this file is for. nm_icd_mets_proxy() is a SEPARATE",
                  "return, used for agreement analysis, and it takes a REQUIRED population",
                  "argument so the two sides are computed on the same patients."),
    settled_by = "SME (Epi) - but the agreement table should be produced first, either way."
  ),

  D_ICD_SNOMED = list(
    question = paste("t_diagnosis.diagnosis_cd_type carries ICD10, ICD9 AND SNOMEDCT in one",
                     "column. What happens to the SNOMEDCT rows?"),
    value = "excluded_and_counted", alternative = "map_via_crosswalk", wired = FALSE,
    basis = paste("HARD-CODED (no SNOMED branch exists). NO SNOMED CT concept id is written in",
                  "this file, because no verified SNOMED->site crosswalk exists in this repo and",
                  "inventing one would be fabrication. The SNOMEDCT rows are COUNTED by",
                  "nm_icd_vocab_scan() and reported as an unmeasured share, not silently",
                  "discarded."),
    settled_by = "A licensed SNOMED CT crosswalk, or Optum confirming the SNOMED share is trivial."
  )
)

# ---- decision accessors. All WIRED code below reads decisions through these. ----

# Normalise to ONE plain unnamed character scalar: a named scalar, factor,
# one-element list or numeric would compare FALSE in every
# identical(nm_dec(...), "literal") branch and silently disable the rule.
# Validation and the returned value are the same object.
nm_dec_scalar <- function(v, what) {
  u <- unlist(v, use.names = FALSE)
  if (is.factor(u)) u <- as.character(u)
  if (is.null(u) || !is.atomic(u) || length(u) != 1L)
    stop(what, " must be a single value, got ", if (is.null(u)) "NULL" else
         paste0(class(v)[1], " of length ", length(u)))
  unname(as.character(u))
}

nm_dec <- function(id, ov = list()) {
  if (!is.character(id) || length(id) != 1L) stop("nm_dec(): id must be one string")
  if (!id %in% names(NM_DECISIONS)) stop("nm_dec(): unknown decision id '", id, "'")
  if (length(ov) && id %in% names(ov)) {
    v <- nm_dec_scalar(ov[[id]], paste0("nm_dec(): override for '", id, "'"))
    # An unregistered value is a typo that would silently disable a rule.
    allowed <- unique(as.character(c(NM_DECISIONS[[id]]$value, NM_DECISIONS[[id]]$alternative)))
    if (!v %in% allowed)
      stop("nm_dec(): override for '", id, "' is '", v,
           "', not one of: ", paste(allowed, collapse = ", "))
    return(v)
  }
  nm_dec_scalar(NM_DECISIONS[[id]]$value, paste0("nm_dec(): registered value for '", id, "'"))
}

nm_dec_alt <- function(id) {
  if (!id %in% names(NM_DECISIONS)) stop("nm_dec_alt(): unknown decision id '", id, "'")
  NM_DECISIONS[[id]]$alternative
}

nm_dec_wired <- function(id) {
  if (!id %in% names(NM_DECISIONS)) stop("nm_dec_wired(): unknown decision id '", id, "'")
  isTRUE(NM_DECISIONS[[id]]$wired)
}

# Human-readable declaration table. Paste into the SAP appendix verbatim. The
# `wired` column is not decoration: a FALSE row is a choice that CANNOT be
# flipped by editing the register, and saying so is the difference between a
# pre-specified decision and a comment.
nm_decision_register <- function() {
  ids <- names(NM_DECISIONS)
  data.frame(
    decision_id = ids,
    wired       = vapply(ids, nm_dec_wired, logical(1), USE.NAMES = FALSE),
    value       = vapply(ids, function(i) paste(as.character(nm_dec(i)), collapse = " / "),
                         character(1), USE.NAMES = FALSE),
    alternative = vapply(ids, function(i) paste(as.character(nm_dec_alt(i)), collapse = " / "),
                         character(1), USE.NAMES = FALSE),
    question    = vapply(NM_DECISIONS, function(d) d$question, character(1), USE.NAMES = FALSE),
    basis       = vapply(NM_DECISIONS, function(d) d$basis, character(1), USE.NAMES = FALSE),
    settled_by  = vapply(NM_DECISIONS, function(d) d$settled_by, character(1), USE.NAMES = FALSE),
    stringsAsFactors = FALSE, row.names = NULL)
}

# ============================================================================
# 1. CONNECTION HELPERS  (identical contract to nsclc_lot.R and the precedent)
# ============================================================================

mc_connect <- function(dsn = Sys.getenv("DATABRICKS_DSN", "RWDE"),
                       pwd = Sys.getenv("DATABRICKS_PWD", ""),
                       timeout = 120, bigint = "numeric", ...) {
  if (!nzchar(pwd)) stop("DATABRICKS_PWD is not set.")
  DBI::dbConnect(odbc::odbc(), dsn = dsn, pwd = pwd, timeout = timeout, bigint = bigint, ...)
}

# Databricks returns EHR tables UPPERCASE and t_onc_* lowercase; normalise both.
mc_tbl <- function(con, name) {
  dplyr::tbl(con, dbplyr::in_catalog(MC_CATALOG, MC_SCHEMA,
                                     paste0("t_", name, "_", MC_CUT))) |>
    dplyr::rename_with(tolower)
}

n_ptid <- function(tb) tb |> dplyr::summarise(n = dplyr::n_distinct(ptid)) |> dplyr::pull(n) |> as.integer()

# Build an OR of LIKE '%...%' checks as raw SQL (Databricks can't push a regex-OR).
# Same helper as the precedent's rdq1_like_any(). FAILS CLOSED: an empty
# substring vector returns a predicate that matches NOTHING. The naive version
# returns LIKE '%%', which matches every non-null row - a filter that silently
# becomes "everything" is the worst failure mode available here.
nm_like_any <- function(col, substrs) {
  if (!length(substrs)) return("(1 = 0)")
  terms <- paste0("UPPER(", col, ") LIKE '%", toupper(gsub("'", "''", substrs)), "%'")
  paste0("(", paste(terms, collapse = " OR "), ")")
}

# ============================================================================
# 2. THE SITE VOCABULARY
#
# NM_SITE_MAP keys are ONLY the values actually OBSERVED in the live 2025q4
# sample. Nothing else is asserted to exist. NM_SITE_PATTERNS is applied ONLY to
# values that are NOT in the map, so a compartment such as adrenal - which the
# inventory wants ("Adrenal metastasis", ICD C79.7 proxy in Flatiron) but which
# does NOT appear in the observed sample - materialises as a flag if and only if
# the deployment really contains such a value. This file does not claim the
# string 'adrenal gland' exists; it claims that IF a value containing 'adrenal'
# is present, here is where it goes. Everything matching neither lands in the
# unmapped report and is still counted as a site, EACH DISTINCT VALUE SEPARATELY
# (D_UNMAPPED_SITE).
# ============================================================================

NM_SITE_MAP <- c(
  "bone"                  = "bone",
  "vertebral column"      = "bone",
  "rib"                   = "bone",
  "liver"                 = "liver",
  "brain"                 = "brain_cns",
  "lung"                  = "lung",
  "pleura"                = "pleura",
  "peritoneum"            = "peritoneum",
  "intra-abdominal organs" = "abdominal_organ",
  "pancreas"              = "abdominal_organ",
  "thyroid"               = "other_organ",
  "chest"                 = "other_unclassified"   # D_CHEST_SITE
)

# Applied to UNMAPPED values only, in order; first hit wins. Patterns, not
# values - none of these strings is claimed to be in the vocabulary.
NM_SITE_PATTERNS <- list(
  list(pattern = "adrenal",                                       group = "adrenal"),
  list(pattern = "brain|cerebr|mening|nervous|spinal|cns",         group = "brain_cns"),
  list(pattern = "bone|osseous|vertebr|rib|skelet|marrow",         group = "bone"),
  list(pattern = "liver|hepat",                                    group = "liver"),
  list(pattern = "lung|pulmonar",                                  group = "lung"),
  list(pattern = "pleur",                                          group = "pleura"),
  list(pattern = "periton|omentum",                                group = "peritoneum"),
  list(pattern = "lymph|node",                                     group = "lymph_node"),
  list(pattern = "kidney|renal|spleen|pancrea|stomach|gastric|bowel|intestin|colon|abdom|adnex",
       group = "abdominal_organ")
)

# The canonical compartments. Flag columns are generated from this vector, so
# adding a compartment here is the only edit needed.
# NOTE: "unspecified_site" is an ICD-SIDE-ONLY bucket (C79.9 and friends carry
# no body part). No enriched value maps to it, so met_unspecified_site is
# structurally FALSE on the enriched read; it exists so that the ICD codelists
# have somewhere honest to put site-less codes instead of counting them as an
# anatomical compartment.
NM_SITE_GROUPS <- c("bone", "liver", "brain_cns", "lung", "pleura", "adrenal",
                    "peritoneum", "abdominal_organ", "lymph_node", "other_organ",
                    "unspecified_site", "other_unclassified", "unmapped_other")

# D_VISCERAL_DEF / D_BRAIN_IS_VISCERAL. For a LUNG primary, lung and pleural
# metastases are the same AJCC M1a category and are intrathoracic-only disease -
# they are NOT put on opposite sides of a visceral/non-visceral split.
NM_VISCERAL_GROUPS     <- c("liver", "adrenal", "peritoneum", "abdominal_organ",
                            "other_organ")
NM_NONVISCERAL_GROUPS  <- c("bone", "lymph_node")
NM_INTRATHORACIC_GROUPS <- c("lung", "pleura", "other_unclassified")
NM_CNS_GROUPS          <- c("brain_cns")

# Map one vector of raw metastasis_location values to canonical compartments.
# Returns NA for anything unmapped; the caller decides what NA means (it means
# 'unmapped_other', counted and reported - never dropped, never merged with
# other unmapped values for the purpose of counting sites).
nm_site_group <- function(x) {
  raw <- tolower(trimws(as.character(x)))
  out <- rep(NA_character_, length(raw))
  hit <- !is.na(raw) & nzchar(raw)
  out[hit] <- unname(NM_SITE_MAP[raw[hit]])
  for (p in NM_SITE_PATTERNS) {
    todo <- hit & is.na(out) & grepl(p$pattern, raw)
    out[todo] <- p$group
  }
  out
}

# Lint: does every mapped target actually exist in NM_SITE_GROUPS? A typo here
# would create a flag column nobody reads.
nm_site_map_lint <- function() {
  tgt <- unique(c(unname(NM_SITE_MAP), vapply(NM_SITE_PATTERNS, function(p) p$group, character(1))))
  bad <- setdiff(tgt, NM_SITE_GROUPS)
  if (length(bad)) stop("nm_site_map_lint(): mapping targets not in NM_SITE_GROUPS: ",
                        paste(bad, collapse = ", "))
  vis <- c(NM_VISCERAL_GROUPS, NM_NONVISCERAL_GROUPS, NM_INTRATHORACIC_GROUPS, NM_CNS_GROUPS)
  bad2 <- setdiff(vis, NM_SITE_GROUPS)
  if (length(bad2)) stop("nm_site_map_lint(): visceral/intrathoracic/CNS groups not in ",
                         "NM_SITE_GROUPS: ", paste(bad2, collapse = ", "))
  # The four clinical groupings must be disjoint, or a patient counts twice.
  ovl <- c(intersect(NM_VISCERAL_GROUPS, NM_NONVISCERAL_GROUPS),
           intersect(NM_VISCERAL_GROUPS, NM_INTRATHORACIC_GROUPS),
           intersect(NM_NONVISCERAL_GROUPS, NM_INTRATHORACIC_GROUPS),
           intersect(NM_CNS_GROUPS, c(NM_VISCERAL_GROUPS, NM_NONVISCERAL_GROUPS,
                                      NM_INTRATHORACIC_GROUPS)))
  if (length(ovl)) stop("nm_site_map_lint(): overlapping clinical groupings: ",
                        paste(unique(ovl), collapse = ", "))
  invisible(TRUE)
}

# ============================================================================
# 3. ICD FALLBACK CODELISTS - the Flatiron-equivalent read, for COMPARISON ONLY
#
# This is what the inventory calls "Raw ICD proxy (uncertain)": count/flag
# t_diagnosis secondary-neoplasm codes. It exists here so the Optum enriched
# read can be scored AGAINST it (D_ICD_FALLBACK: report separately, never
# merge). Codes are stored WITHOUT decimals in Optum, so every entry below is
# decimal-free and is matched as a PREFIX, which is why C7951/C7952 are written
# out rather than relying on 'C79'.
#
# THE TWO VOCABULARIES MUST DEFINE THE SAME COMPARTMENTS THE SAME WAY. A
# patient's compartment must not depend on whether the site happened to bill in
# ICD-9 or ICD-10, and diagnosis_cd_type is multi-vocabulary AT ROW LEVEL - that
# is the whole reason both lists exist. nm_icd_list_lint() enforces key parity;
# ovary (C796x / 1986), kidney+urinary (C790x/C791x / 1980,1981), other
# digestive (C788 / 1978) and skin (C792 / 1982) are aligned deliberately.
#
# WHAT IS DELIBERATELY NOT HERE:
#   * ICD-9 199.1 ("malignant neoplasm without specification of site") is NOT a
#     secondary-neoplasm code - it is routinely used for a PRIMARY of unknown
#     site. Including it would manufacture metastasis positives.
#   * site-less secondary codes (C79.9, C79.89, 199.0) go to `unspecified_site`,
#     which is NOT an anatomical compartment and is excluded from the
#     compartment count and from the agreement table.
#   * SNOMEDCT has NO codelist - see D_ICD_SNOMED - and nm_icd_vocab_scan()
#     reports how much of the metastasis signal is therefore unmeasured.
# ============================================================================

NM_ICD10_SITE <- list(
  bone            = c("C7951", "C7952", "C7B03"),
  liver           = c("C787", "C7B02"),
  brain_cns       = c("C7931", "C7932", "C7940", "C7949"),
  lung            = c("C7800", "C7801", "C7802"),
  pleura          = c("C782"),
  adrenal         = c("C7970", "C7971", "C7972"),
  peritoneum      = c("C786", "C7B04"),
  abdominal_organ = c("C784", "C785", "C788", "C7960", "C7961", "C7962",
                      "C7900", "C7901", "C7902", "C7911", "C7919"),
  lymph_node      = c("C77", "C7B01"),
  other_organ     = c("C781", "C7830", "C7839", "C792", "C7981", "C7982",
                      "C7B1", "C7B8"),
  unspecified_site = c("C799", "C7989", "C7B00", "C7B09")
)

NM_ICD9_SITE <- list(
  bone            = c("1985"),
  liver           = c("1977"),
  brain_cns       = c("1983", "1984"),
  lung            = c("1970"),
  pleura          = c("1972"),
  adrenal         = c("1987"),
  peritoneum      = c("1976"),
  abdominal_organ = c("1974", "1975", "1978", "1980", "1981", "1986"),
  lymph_node      = c("196"),
  other_organ     = c("1971", "1973", "1982", "19882", "19889"),
  unspecified_site = c("1990")
)

# Prefix match as raw SQL. `LIKE 'C787%'` because a code may be more specific
# than the list entry and Optum strips decimals. FAILS CLOSED on an empty
# vector: the naive version returns LIKE '%', which matches every row, and the
# lists below are explicitly designed to be extended.
nm_code_prefix_sql <- function(col, prefixes) {
  if (!length(prefixes)) return("(1 = 0)")
  terms <- paste0(col, " LIKE '", gsub("'", "''", prefixes), "%'")
  paste0("(", paste(terms, collapse = " OR "), ")")
}

# Both vocabularies must cover the same compartments, and every enriched
# compartment except the two "we do not know what this is" buckets must have an
# ICD definition on both sides - otherwise the agreement table compares a
# compartment against nothing and reports the gap as an Optum win.
nm_icd_list_lint <- function() {
  if (!identical(sort(names(NM_ICD10_SITE)), sort(names(NM_ICD9_SITE))))
    stop("nm_icd_list_lint(): NM_ICD10_SITE and NM_ICD9_SITE define different compartments: ",
         paste(union(setdiff(names(NM_ICD10_SITE), names(NM_ICD9_SITE)),
                     setdiff(names(NM_ICD9_SITE), names(NM_ICD10_SITE))), collapse = ", "))
  need <- setdiff(NM_SITE_GROUPS, c("other_unclassified", "unmapped_other"))
  miss <- setdiff(need, names(NM_ICD10_SITE))
  if (length(miss)) stop("nm_icd_list_lint(): compartments with no ICD codelist: ",
                         paste(miss, collapse = ", "))
  extra <- setdiff(names(NM_ICD10_SITE), NM_SITE_GROUPS)
  if (length(extra)) stop("nm_icd_list_lint(): ICD compartments not in NM_SITE_GROUPS: ",
                          paste(extra, collapse = ", "))
  invisible(TRUE)
}

# The compartments whose definition is 1:1 on BOTH sides, i.e. the only ones
# whose enriched-vs-ICD agreement is interpretable. Everything else (thyroid vs
# mediastinum vs genital in 'other_organ'; 'intra-abdominal organs' vs bowel and
# kidney in 'abdominal_organ'; the two unknown buckets; the site-less ICD codes)
# is bucketed differently by the two sources and is reported separately rather
# than dropped.
NM_AGREEMENT_GROUPS <- c("bone", "liver", "brain_cns", "lung", "pleura",
                         "adrenal", "peritoneum", "lymph_node")

# ============================================================================
# 4. POPULATION GATE AND LUNG-PRIMARY ATTRIBUTION (mode A / mode C)
# ============================================================================

# HAS_NOTES gate. Every t_onc_* table is built from physician notes, so a
# patient without notes contributes no enriched row AT ALL - they are not
# "metastasis-free", they are unobserved. This gate makes that explicit rather
# than letting a silent inner join do it.
nm_note_pts <- function(con) {
  p <- mc_tbl(con, "patient")
  if (NM_REQUIRE_NOTES) p <- p |> dplyr::filter(has_notes == "Y")
  p |> dplyr::distinct(ptid)
}

# Enriched-Oncology membership: a patient "has EO" if they appear in the EO
# neoplasm table. t_patient carries no EO flag (the precedent established that
# idn_indicator is the Integrated Delivery Network flag, unrelated).
nm_eo_member_pts <- function(con)
  mc_tbl(con, "onc_neoplasm_histology") |> dplyr::distinct(ptid)

# LUNG tumour keys + their patient. Ties stage and metastasis rows to the LUNG
# cancer, not to another primary. Carries ptid so the join is on
# (ptid, neoplasm_histology_key) - the shared key - never on the key alone.
# neoplasm_qualifier == 'actual' for the same reason mets_qualifier is filtered:
# a negated neoplasm mention is not a tumour.
#
# BOTH columns are probed. neoplasm_type holds the anatomical term ('lung',
# 13,275,346 rows in this deployment) and histology holds the histology term;
# a row whose neoplasm_type is NULL - the plurality, 63,475,323 rows - can still
# be recognised by its histology. That OR is not a nicety: without it the lung
# cohort loses every neoplasm_type-NULL row, which is a second attrition on top
# of the orphan-key loss (KNOWN LIMITS K).
nm_lung_neo_keys <- function(con)
  mc_tbl(con, "onc_neoplasm_histology") |>
    dplyr::filter(dbplyr::sql(paste0("(", nm_like_any("neoplasm_type", NM_LUNG_NEO_SUBSTR),
                                     " OR ", nm_like_any("histology", NM_LUNG_HIST_SUBSTR), ")")),
                  neoplasm_qualifier == "actual") |>
    dplyr::distinct(ptid, neoplasm_histology_key)

# Single-lung-primary patients - who may claim orphan (null-key) rows in mode C.
# Optum EO guide 4.3: an orphan record can be attributed to the one cancer of a
# single-primary patient. Per the precedent, the single-primary test reads ICD
# from t_diagnosis, NOT neoplasm_type, because the EO manual warns neoplasm_type
# over-fragments one real cancer into several rows.
#
# Single lung primary = a lung primary code AND no other PRIMARY cancer code.
#   * Secondary/metastatic codes do NOT disqualify - they are the metastases of
#     the lung cancer itself.
#   * C80 does not disqualify either (D_C80_PRIMARY): it names no site and is
#     routine in this cohort. Pass c80_as_primary = TRUE for the sensitivity.
#   * The ICD-9 leg covers 140-195 AND 200-209, so it disqualifies the same
#     disease space as the ICD-10 leg (which disqualifies C81-C96 and C7A by
#     construction). This matters: nm_stage_parse() carries an `ann_arbor_like`
#     class precisely because LYMPHOMA staging records are observed in
#     t_onc_stage, so a lymphoma patient's orphan rows are a live hazard for
#     mode C - and it would be absurd for the answer to depend on whether the
#     lymphoma billed in ICD-9 or ICD-10.
#   * The 162 root (lung) is excluded from the other-primary test at the SAME
#     granularity it is included in the lung test, including the trachea
#     carve-out 1620. Otherwise a bare '162' or a trachea code would fail to
#     make the patient a lung primary AND simultaneously count as a competing
#     primary - disqualifying them from mode C twice over.
#   * SNOMEDCT is not read (D_ICD_SNOMED), which makes mode C slightly
#     OPTIMISTIC: a second primary recorded only in SNOMED would not disqualify.
#     Sized by nm_icd_vocab_scan().
nm_single_lung_primary <- function(con, c80_as_primary = NULL, ov = list()) {
  c80 <- c80_as_primary %||% identical(nm_dec("D_C80_PRIMARY", ov), "treat_c80_as_primary")

  dx <- mc_tbl(con, "diagnosis") |>
    dplyr::filter(diag_date <= NM_STUDY_END,
                  diagnosis_cd_type %in% c("ICD10", "ICD9"))

  lung10 <- dx |>
    dplyr::filter(diagnosis_cd_type == "ICD10",
                  substr(diagnosis_cd, 1, 3) %in% NM_LUNG_ICD10_3) |>
    dplyr::distinct(ptid)
  # 3-character root, minus trachea. A bare '162' counts as lung.
  lung9 <- dx |>
    dplyr::filter(diagnosis_cd_type == "ICD9",
                  substr(diagnosis_cd, 1, 3) %in% NM_LUNG_ICD9_3,
                  !(substr(diagnosis_cd, 1, 4) %in% NM_TRACHEA_ICD9)) |>
    dplyr::distinct(ptid)
  lung <- dplyr::union(lung10, lung9)

  # Another PRIMARY: ICD-10 C-code that is neither lung, nor secondary, nor
  # (by default) an unspecified-site C80.
  excl10 <- c(NM_LUNG_ICD10_3, NM_SECONDARY_ICD10_3,
              if (!c80) NM_UNSPECIFIED_ICD10_3 else character(0))
  other10 <- dx |>
    dplyr::filter(diagnosis_cd_type == "ICD10",
                  substr(diagnosis_cd, 1, 1) == "C",
                  !(substr(diagnosis_cd, 1, 3) %in% excl10)) |>
    dplyr::distinct(ptid)

  # ICD-9: the union of the declared ranges, minus the secondary roots and minus
  # the whole 162 lung/trachea root.
  rng <- paste(vapply(NM_OTHER_PRIMARY_ICD9_RANGES, function(r)
    paste0("(substr(diagnosis_cd, 1, 3) >= '", r[1], "' AND substr(diagnosis_cd, 1, 3) <= '",
           r[2], "')"), character(1)), collapse = " OR ")
  other9 <- dx |>
    dplyr::filter(diagnosis_cd_type == "ICD9",
                  dbplyr::sql(paste0("(", rng, ")")),
                  !(substr(diagnosis_cd, 1, 3) %in% NM_SECONDARY_ICD9_PFX),
                  !(substr(diagnosis_cd, 1, 3) %in% NM_LUNG_ICD9_3)) |>
    dplyr::distinct(ptid)

  other <- dplyr::union(other10, other9)
  dplyr::anti_join(lung, other, by = "ptid")
}

# Restrict any enriched-onc table carrying (ptid, neoplasm_histology_key) to the
# patient's LUNG tumour(s), per mode. Used identically for
# t_onc_metastatic_location, t_onc_tnm and t_onc_stage so all three are
# attributed the same way - a mets site and the stage it implies must not be
# tied to the primary by different rules.
#   "A" (default, production): key-linked rows only. Orphans dropped. Safest;
#       UNDER-counts, by roughly the orphan share (~70% in t_onc_tnm).
#   "C": mode A PLUS orphan (null-key) rows for single-lung-primary patients.
# The default is READ FROM THE REGISTER (D_ORPHAN_KEY_MODE), so editing that
# entry actually switches the run instead of silently producing mode-A numbers
# under a mode-C label.
nm_lung_attributed <- function(con, tbl, mode = NULL, ov = list(), c80_as_primary = NULL) {
  mode <- match.arg(mode %||% nm_dec("D_ORPHAN_KEY_MODE", ov), c("A", "C"))
  keyed <- dplyr::semi_join(tbl, nm_lung_neo_keys(con), by = c("ptid", "neoplasm_histology_key"))
  if (mode == "A") return(keyed)
  orphan <- tbl |>
    dplyr::filter(is.na(neoplasm_histology_key) | neoplasm_histology_key == "") |>
    dplyr::semi_join(nm_single_lung_primary(con, c80_as_primary = c80_as_primary, ov = ov),
                     by = "ptid")
  dplyr::union_all(keyed, orphan)
}

# The population on which the enriched read and the ICD proxy are BOTH defined:
# has notes -> in EO -> has a lung tumour key. Anything compared across the two
# sources must be restricted to this set, or the ICD side silently answers for
# the whole deployment (breast, prostate, colon and all).
nm_comparison_pts <- function(con)
  nm_note_pts(con) |>
    dplyr::semi_join(nm_eo_member_pts(con), by = "ptid") |>
    dplyr::semi_join(nm_lung_neo_keys(con), by = "ptid")

# ============================================================================
# 5. nm_mets_sites() - WHICH BODY PART
# ============================================================================

# Calendar-valid 8-digit yyyymmdd. NOT merely ^[0-9]{8}$: the observed partials
# are spelled '2009mmdd' with dx_date_type='incomplete', and the sibling
# encoding of the same partial - zero-filled, '20090000' or '20140300' - is
# eight digits and would sail through a format-only guard into the parser.
NM_DXDATE_CAL_REGEX <- "^(19|20)[0-9]{2}(0[1-9]|1[0-2])(0[1-9]|[12][0-9]|3[01])$"

# The exact-date refinement, as raw SQL. THREE conditions, not one:
#   metastasis_dx_date_type = 'exact'        (the flag Optum provides)
#   AND a CALENDAR-VALID yyyymmdd            (D_DX_DATE_PARSE)
#   AND try_to_date(), not to_date()         (Databricks SQL warehouses run ANSI
#                                             mode ON by default, where to_date()
#                                             on an unparseable string ABORTS THE
#                                             QUERY rather than returning NULL)
# NEVER assume this string parses - and never let the assumption take the whole
# extraction down with it.
NM_EXACT_DXDATE_SQL <- paste0(
  "CASE WHEN metastasis_dx_date_type = 'exact'",
  " AND metastasis_dx_date RLIKE '", NM_DXDATE_CAL_REGEX, "'",
  " THEN try_to_date(metastasis_dx_date, 'yyyyMMdd') ELSE NULL END")

# D_METS_TEMPORAL as a pure filter, on a lazy tbl or a local frame, so the
# self-test can prove each registered value keeps exactly the rows it names.
nm_temporal_filter <- function(tb, temporal) {
  switch(temporal,
    current_and_history = tb,
    current_only        = tb |> dplyr::filter(mets_temporal_status == "current"),
    history_only        = tb |> dplyr::filter(mets_temporal_status == "history"),
    stop("nm_mets_rows(): unhandled D_METS_TEMPORAL value '", temporal, "'"))
}

# Shared row-level reader for t_onc_metastatic_location. `qualifier` is an
# argument with NO default so that no call site can accidentally omit it and
# pick up every row - which is how one silently invents metastases.
nm_mets_rows <- function(con, qualifier, mode = NULL, ov = list()) {
  if (!is.character(qualifier) || length(qualifier) != 1L)
    stop("nm_mets_rows(): qualifier must be exactly one of 'actual' or 'absent'")
  if (!qualifier %in% c("actual", "absent"))
    stop("nm_mets_rows(): qualifier must be 'actual' or 'absent', got '", qualifier, "'")
  # THE GUARD. If someone ever changes D_METS_QUALIFIER to 'any_row', this stops
  # the run rather than quietly producing positives out of negated mentions.
  if (!identical(nm_dec("D_METS_QUALIFIER", ov), "actual_only"))
    stop("nm_mets_rows(): D_METS_QUALIFIER is not 'actual_only'. Row existence is NOT a ",
         "positive metastasis - mets_qualifier='absent' means the note NEGATED it. Refusing to run.")

  # THREE registered values, not two. A binary keep_history flag made
  # 'history_only' execute the CURRENT-only filter -- the alternative did the
  # exact opposite of its name, so any sensitivity analysis run under it would
  # have reported the current-only result under a history-only label.
  temporal <- nm_dec("D_METS_TEMPORAL", ov)

  tb <- mc_tbl(con, "onc_metastatic_location") |>
    dplyr::filter(note_date <= NM_STUDY_END, mets_qualifier == qualifier)
  tb <- nm_temporal_filter(tb, temporal)

  nm_lung_attributed(con, tb, mode = mode, ov = ov) |>
    dplyr::mutate(mets_exact_date = dbplyr::sql(NM_EXACT_DXDATE_SQL)) |>
    # D_TIMING_ANCHOR: note_date is the anchor. The exact-typed dx date refines
    # it BACKWARD only. A dx date AFTER the note that records it is not a
    # refinement, it is a data error, so it is ignored rather than trusted.
    dplyr::mutate(mets_date = dplyr::if_else(!is.na(mets_exact_date) & mets_exact_date <= note_date,
                                             mets_exact_date, note_date))
}

# COLLECTED 'actual' rows for nm_mets_summary(records=). nm_mets_rows() is a lazy
# query and stays lazy (nm_mets_sites / nm_mets_absent pipe it further); the
# summary needs a local data.frame with mets_qualifier carried through.
nm_mets_records <- function(con, mode = NULL, ov = list())
  dplyr::collect(nm_mets_rows(con, qualifier = "actual", mode = mode, ov = ov))

# THE core answer to "which body part". One row per (ptid, metastasis_location)
# with the earliest reliable date.
#
# Columns returned:
#   ptid, metastasis_location (raw controlled-vocabulary value), site_group
#   (canonical compartment; NA = unmapped), first_mets_date (earliest reliable
#   date), and then the EVER-columns:
#     last_mets_date_ever, n_records_ever, n_exact_dated_ever, any_history_ever,
#     n_sources_ever
#   The _ever suffix is not decoration. This function aggregates the WHOLE
#   record, and nm_mets_summary() applies the index window afterwards on
#   first_mets_date alone. first_mets_date and every flag derived from it are
#   index-safe (a global minimum is <= index iff some record is). The _ever
#   columns are NOT: they see post-index records, so using n_sources_ever as an
#   "evidence strength" baseline covariate leaks follow-up into a model whose
#   endpoint is rwOS. See KNOWN LIMITS M.
#
# `mode` is the orphan-key mode; NULL takes D_ORPHAN_KEY_MODE from the register.
nm_mets_sites <- function(con, mode = NULL, ov = list(), collect = TRUE) {
  q <- nm_mets_rows(con, qualifier = "actual", mode = mode, ov = ov) |>
    dplyr::group_by(ptid, metastasis_location) |>
    dplyr::summarise(first_mets_date     = min(mets_date, na.rm = TRUE),
                     last_mets_date_ever = max(mets_date, na.rm = TRUE),
                     n_records_ever      = dplyr::n(),
                     n_exact_dated_ever  = sum(as.integer(!is.na(mets_exact_date)), na.rm = TRUE),
                     any_history_ever    = max(as.integer(mets_temporal_status == "history"),
                                               na.rm = TRUE),
                     n_sources_ever      = dplyr::n_distinct(sourceid),
                     .groups = "drop")
  if (!collect) return(q)
  out <- dplyr::collect(q)
  out$site_group       <- nm_site_group(out$metastasis_location)
  out$any_history_ever <- out$any_history_ever > 0
  out$mets_qualifier   <- rep("actual", nrow(out))
  out
}

# THE NEGATIVE EVIDENCE. Sites the note explicitly said were NOT involved.
# This is not an inverse of nm_mets_sites() and must never be treated as one -
# a patient can have an 'absent' liver row in 2019 and an 'actual' liver row in
# 2021. It is returned separately so that:
#   (a) "documented no brain metastasis" can be distinguished from "nobody
#       looked", which is the single most useful thing here and is IMPOSSIBLE
#       in an ICD proxy - there is no ICD code for the absence of a metastasis;
#   (b) a site that is 'absent' at every mention can be reported as
#       screened-negative rather than missing.
nm_mets_absent <- function(con, mode = NULL, ov = list(), collect = TRUE) {
  q <- nm_mets_rows(con, qualifier = "absent", mode = mode, ov = ov) |>
    dplyr::group_by(ptid, metastasis_location) |>
    dplyr::summarise(first_absent_date     = min(mets_date, na.rm = TRUE),
                     last_absent_date_ever = max(mets_date, na.rm = TRUE),
                     n_records_ever        = dplyr::n(),
                     n_sources_ever        = dplyr::n_distinct(sourceid),
                     .groups = "drop")
  if (!collect) return(q)
  out <- dplyr::collect(q)
  out$site_group     <- nm_site_group(out$metastasis_location)
  out$mets_qualifier <- rep("absent", nrow(out))
  out
}

# Reconcile positive and negative evidence. Returns a LIST of TWO frames,
# because the two levels are genuinely different objects and mixing them is how
# a documented metastasis turns into a documented absence:
#
#   $by_location   one row per (ptid, metastasis_location) - the raw curated
#                  vocabulary value, which is what the note actually said.
#   $by_compartment one row per (ptid, site_group) - the analysis unit used
#                  everywhere else in this file (D_NSITES_UNIT). NM_SITE_MAP
#                  folds 'bone', 'rib' and 'vertebral column' into one
#                  compartment, so a patient with an 'actual' bone row and an
#                  'absent' rib row MUST come out of the compartment view as
#                  positive, once - not as one positive plus one
#                  screened-negative for the same compartment.
#
# Three-state encoding, in both frames: "positive" / "screened_negative" /
# (absent from the frame entirely = unobserved, and therefore NOT returned - a
# missing row is not a negative and this function never manufactures one).
# In both frames a positive anywhere in the record outranks a negative: mets do
# not resolve.
nm_mets_evidence <- function(sites, absent) {
  stopifnot(is.data.frame(sites), is.data.frame(absent))
  pos <- sites[, c("ptid", "metastasis_location", "site_group", "first_mets_date"),
               drop = FALSE]
  names(pos)[4] <- "evidence_date"
  pos$status <- rep("positive", nrow(pos))
  neg <- absent[, c("ptid", "metastasis_location", "site_group", "first_absent_date"),
                drop = FALSE]
  names(neg)[4] <- "evidence_date"
  neg$status <- rep("screened_negative", nrow(neg))
  both <- rbind(pos, neg)
  both$site_group[is.na(both$site_group)] <- "unmapped_other"
  rank <- match(both$status, c("positive", "screened_negative"))

  kloc <- paste(both$ptid, both$metastasis_location, sep = "\r")
  o1 <- order(kloc, rank, both$evidence_date)
  b1 <- both[o1, , drop = FALSE]
  by_location <- b1[!duplicated(paste(b1$ptid, b1$metastasis_location, sep = "\r")), , drop = FALSE]

  kgrp <- paste(both$ptid, both$site_group, sep = "\r")
  o2 <- order(kgrp, rank, both$evidence_date)
  b2 <- both[o2, , drop = FALSE]
  by_compartment <- b2[!duplicated(paste(b2$ptid, b2$site_group, sep = "\r")), , drop = FALSE]

  list(by_location = by_location, by_compartment = by_compartment)
}

# ============================================================================
# 6. nm_mets_summary() - THE MODELLING VARIABLES
# ============================================================================

# sites        : the tibble from nm_mets_sites() - POSITIVES ONLY. The frame is
#                checked for its provenance stamp, because nm_mets_evidence()'s
#                output has the same column names plus 'status' and passing it
#                here would count screened-NEGATIVE sites as metastases.
# index_dates  : data.frame(ptid, index_date) - the 2L docetaxel index from
#                nsclc_lot.R. NULL means "no index restriction" (diagnostic use
#                only; never for the model).
# lookback_days: NULL = take D_PREINDEX_WINDOW from the register (default: all
#                history up to index). A single non-negative whole number of
#                days overrides it, and then REQUIRES index_dates.
# records      : COLLECTED row-level 'actual' rows (nm_mets_records(); a lazy
#                nm_mets_rows() query is rejected) carrying ptid,
#                metastasis_location, mets_date, mets_qualifier. Needed only for
#                a finite lookback; rows other than 'actual' are dropped so a
#                negated mention can never refresh a positive.
#
# Returns a LIST, not a frame, because the unmapped-value report is a
# first-class output and must not be a warning nobody reads:
#   $summary   one row per patient in index_dates: n_met_sites, n_unmapped_sites,
#              the site flags, and the visceral / non-visceral / intrathoracic /
#              CNS groupings. ALL of these are NA when blank_location_only is
#              TRUE (records exist but name no site) or any_mets_record is FALSE.
#   $unmapped  one row per unseen metastasis_location value in the WHOLE input,
#              with counts. This is the mapping-completeness evidence, and it is
#              deliberately computed BEFORE the index window - otherwise an
#              empty report would be consistent with a badly incomplete mapping
#              whose unseen values all happened to fall after index. IF THIS IS
#              NON-EMPTY, THE MAPPING IS INCOMPLETE. Extend NM_SITE_MAP.
#   $unmapped_in_window  the subset that actually contributed to n_met_sites
#   $window    what was actually applied, echoed back for the SAP
nm_mets_summary <- function(sites, index_dates = NULL, lookback_days = NULL, ov = list(),
                            records = NULL) {
  stopifnot(is.data.frame(sites))
  nm_site_map_lint()
  # PROVENANCE FIRST. The query layer guards mets_qualifier on all four read
  # paths; this is the R-side boundary where the plausible mistake actually
  # happens, and it is checked BEFORE the column check so that an evidence frame
  # is rejected for what it IS rather than for a column it happens to lack.
  if ("status" %in% names(sites))
    stop("nm_mets_summary(): `sites` carries a `status` column, i.e. it looks like ",
         "nm_mets_evidence() output, which contains screened_negative rows. Pass ",
         "nm_mets_sites() output.")
  if (!"mets_qualifier" %in% names(sites) || !all(sites$mets_qualifier == "actual"))
    stop("nm_mets_summary(): sites must be nm_mets_sites() output ",
         "(mets_qualifier == 'actual' on every row).")
  req <- c("ptid", "metastasis_location", "site_group", "first_mets_date")
  if (!all(req %in% names(sites)))
    stop("nm_mets_summary(): sites must come from nm_mets_sites(); missing ",
         paste(setdiff(req, names(sites)), collapse = ", "))

  s <- sites
  s$first_mets_date <- as.Date(s$first_mets_date)

  # ---- unmapped report over the FULL input (mapping-completeness evidence) ---
  nm_unmapped_tab <- function(d) {
    um <- d[which(is.na(d$site_group)), , drop = FALSE]
    if (!nrow(um))
      return(data.frame(metastasis_location = character(0), n_records = integer(0),
                        n_patients = integer(0), stringsAsFactors = FALSE))
    agg <- aggregate(list(n_records = um$metastasis_location),
                     by = list(metastasis_location = um$metastasis_location), FUN = length)
    pat <- aggregate(list(n_patients = um$ptid),
                     by = list(metastasis_location = um$metastasis_location),
                     FUN = function(z) length(unique(z)))
    merge(agg, pat, by = "metastasis_location")
  }
  unmapped_all <- nm_unmapped_tab(s)

  # Blank/NA locations are excluded from the site COUNT (a row that names no
  # site is not a site) but must still be reported: they are mapping-quality
  # evidence, and previously an NA location was invisible in both places -- it
  # inflated n_met_sites and never appeared in the unmapped table.
  .bl <- is.na(s$metastasis_location) | !nzchar(trimws(as.character(s$metastasis_location)))
  blank_location <- data.frame(
    n_records  = sum(.bl),
    n_patients = length(unique(s$ptid[.bl])),
    stringsAsFactors = FALSE)

  # ---- pre-index window -----------------------------------------------------
  inclusive <- identical(nm_dec("D_INDEX_DAY_INCLUSIVE", ov), "inclusive")
  lb <- lookback_days
  if (is.null(lb)) {
    d <- nm_dec("D_PREINDEX_WINDOW", ov)
    lb <- if (identical(d, "all_history_up_to_index")) NULL else suppressWarnings(as.integer(d))
    if (!is.null(lb) && is.na(lb))
      stop("nm_mets_summary(): D_PREINDEX_WINDOW '", d, "' is not a day count")
  }
  if (!is.null(lb)) {
    # A malformed window must not be coerced: -180 looks back into follow-up,
    # a vector recycles, "abc"/NA/TRUE become NA and silently drop every site.
    if (!is.numeric(lb) || length(lb) != 1L || is.na(lb) || !is.finite(lb) ||
        lb < 0 || lb != trunc(lb))
      stop("nm_mets_summary(): lookback_days must be NULL or a single non-negative ",
           "finite whole number of days, got ", deparse(lookback_days))
    lb <- as.integer(lb)
  }
  if (is.null(index_dates) && !is.null(lb))
    stop("nm_mets_summary(): a finite lookback_days needs index_dates - there is no ",
         "index to look back from; pass index_dates or use lookback_days = NULL")
  if (!is.null(records) && !is.data.frame(records))
    stop("nm_mets_summary(): `records` must be a collected data.frame; nm_mets_rows() ",
         "returns a lazy query - pass nm_mets_records(con, ...) or ",
         "dplyr::collect(nm_mets_rows(con, 'actual', ...))")
  if (!is.null(index_dates)) {
    if (!all(c("ptid", "index_date") %in% names(index_dates)))
      stop("nm_mets_summary(): index_dates must have columns ptid, index_date")
    if (any(duplicated(index_dates$ptid)))
      stop("nm_mets_summary(): index_dates must be one row per ptid")
    idx <- data.frame(ptid = index_dates$ptid,
                      index_date = as.Date(index_dates$index_date),
                      stringsAsFactors = FALSE)
    s <- merge(s, idx, by = "ptid", all.x = FALSE)
    # which(): a raw logical subset would insert an all-NA phantom row for any
    # NA date instead of dropping it, and that row would then reach the unmapped
    # report - the one place this file treats as evidence about the mapping.
    s <- s[which(if (inclusive) s$first_mets_date <= s$index_date
                 else s$first_mets_date < s$index_date), , drop = FALSE]
    if (!is.null(lb)) {
      # LOOKBACK ANCHOR. A finite window must be judged on the most recent
      # PRE-INDEX record, never on first_mets_date: a site documented in 2015 and
      # again a month before index would otherwise be excluded by a 180-day
      # lookback because its FIRST occurrence is old, i.e. the site is present
      # and the count says it is not.
      #
      # nm_mets_sites() aggregates row-level dates away, so the per-site frame
      # cannot answer this on its own -- pass `records`, the COLLECTED
      # nm_mets_records() output, which carries mets_date. last_mets_date_ever
      # is NOT a substitute: it sees post-index records and would leak
      # follow-up into a covariate for an rwOS model.
      src <- if (!is.null(records)) records else if ("mets_date" %in% names(s)) s else NULL
      if (is.null(src))
        stop("nm_mets_summary(): a finite lookback needs row-level dates. Pass ",
             "records = nm_mets_records(...) alongside sites = nm_mets_sites(...), ",
             "or set D_PREINDEX_WINDOW to 'all_history_up_to_index'.")
      stopifnot(is.data.frame(src))
      need <- c("ptid", "metastasis_location", "mets_date", "mets_qualifier")
      if (!all(need %in% names(src)))
        stop("nm_mets_summary(): `records` must carry ",
             paste(need, collapse = ", "), "; missing ",
             paste(setdiff(need, names(src)), collapse = ", "))
      # Only an 'actual' row may refresh a site: an 'absent' row is a NEGATED
      # mention and must never count as a recent positive.
      src <- src[which(as.character(src$mets_qualifier) == "actual"), , drop = FALSE]
      rec <- data.frame(ptid = as.character(src$ptid),
                        metastasis_location = as.character(src$metastasis_location),
                        mets_date = as.Date(src$mets_date), stringsAsFactors = FALSE)
      rec <- merge(rec, idx, by = "ptid", all.x = FALSE)
      elig <- if (inclusive) rec$mets_date <= rec$index_date else rec$mets_date < rec$index_date
      rec  <- rec[which(elig), , drop = FALSE]
      key  <- paste(rec$ptid, rec$metastasis_location, sep = "\r")
      lastpre <- tapply(as.numeric(rec$mets_date), key, max, na.rm = TRUE)
      skey <- paste(s$ptid, s$metastasis_location, sep = "\r")
      s$.last_pre <- as.Date(unname(lastpre[skey]), origin = "1970-01-01")
      s <- s[which(!is.na(s$.last_pre) &
                   s$.last_pre >= (s$index_date - as.integer(lb))), , drop = FALSE]
      s$.last_pre <- NULL
    }
    pts <- idx$ptid
  } else {
    pts <- unique(s$ptid)
  }
  unmapped_win <- nm_unmapped_tab(s)

  # ---- counting unit (D_UNMAPPED_SITE x D_NSITES_UNIT) ----------------------
  # EACH DISTINCT unmapped value is its own counting unit. Collapsing them all
  # into one 'unmapped_other' compartment would score a patient with 'ovary',
  # 'skin' and 'soft tissue' as ONE site - undercounting n_met_sites, the
  # advN=2 variable, in exactly the patients with the most disseminated disease.
  # The FLAG met_unmapped_other stays a single flag; only the count is split.
  # A MISSING location is not a metastatic site. Previously NA and "" each
  # became their own counted unit ("unmapped_other:NA", "unmapped_other:"), so a
  # row that says nothing incremented n_met_sites -- the advN=2 covariate -- and
  # the NA never appeared in the unmapped report either, so it was invisible
  # both ways. Drop blanks from the count and report them as their own quantity.
  loc_raw   <- trimws(as.character(s$metastasis_location))
  s$.blank  <- is.na(s$metastasis_location) | !nzchar(loc_raw)
  s$site_unit <- ifelse(s$.blank, NA_character_,
                 ifelse(is.na(s$site_group),
                        paste0("unmapped_other:", loc_raw),
                        s$site_group))
  # Capture the unmapped mask BEFORE overwriting site_group, or the test below
  # reads "unmapped_other" rather than NA and can never fire.
  s$.unmapped <- !s$.blank & is.na(s$site_group)
  s$site_group[s$.unmapped] <- "unmapped_other"
  s$site_group[s$.blank]    <- NA_character_

  # ---- per-patient assembly -------------------------------------------------
  out <- data.frame(ptid = pts, stringsAsFactors = FALSE)
  # raw_location mode must apply the same blank rule, or the two units disagree
  # on whether a missing location is a site.
  by_unit <- if (identical(nm_dec("D_NSITES_UNIT", ov), "canonical_group"))
    s$site_unit else ifelse(s$.blank, NA_character_, loc_raw)

  # n_met_sites: the advN=2 variable. Distinct compartments, pre-index.
  cnt <- tapply(by_unit, s$ptid, function(z) length(unique(z[!is.na(z)])))
  out$n_met_sites <- as.integer(cnt[out$ptid])
  # A patient in index_dates with NO qualifying enriched row gets 0 ONLY if they
  # are EO-observed; otherwise 0 is indistinguishable from unobserved. That
  # distinction is the caller's to make (nm_eo_member_pts / nm_note_pts), so
  # this column is left NA and a separate flag says the patient had no row.
  out$any_mets_record <- out$ptid %in% s$ptid
  out$n_met_sites[!out$any_mets_record] <- NA_integer_
  # A patient whose ONLY qualifying rows carry no usable location has an
  # UNKNOWN site count, not zero. Reporting 0 here would say "no metastatic
  # sites" on the strength of records that name none -- the same false-negative
  # as unknown-M becoming not-M1, on the same covariate. Flagged so the caller
  # can see why it is NA.
  usable <- tapply(!s$.blank, s$ptid, any)
  out$blank_location_only <- out$any_mets_record & !as.logical(usable[out$ptid])
  out$n_met_sites[out$blank_location_only] <- NA_integer_
  # NOT EVALUABLE for any site or compartment flag: no record, or records that
  # name no site. FALSE would assert "confirmed absent" from records that say
  # nothing (unknown != absent, the n_met_sites principle).
  not_eval <- !out$any_mets_record | out$blank_location_only
  # How much of n_met_sites came from values the mapping has never seen. Key on
  # site_group, not on the unit string: in raw_location mode by_unit holds the
  # raw value and never carries the "unmapped_other:" prefix, so this counter
  # was structurally 0 in that mode however many unmapped sites there were.
  um <- ifelse(s$.unmapped, by_unit, NA_character_)
  ucnt <- tapply(um, s$ptid, function(z) length(unique(z[!is.na(z)])))
  out$n_unmapped_sites <- as.integer(ucnt[out$ptid])
  out$n_unmapped_sites[not_eval] <- NA_integer_

  for (g in NM_SITE_GROUPS) {
    has <- unique(s$ptid[s$site_group == g])
    v <- out$ptid %in% has
    v[not_eval] <- NA
    out[[paste0("met_", g)]] <- v
  }

  grp_of <- split(s$site_group, s$ptid)
  anyg <- function(pt, groups) {
    z <- grp_of[[pt]]
    if (is.null(z) || all(is.na(z))) return(NA)     # blank-only rows carry site_group NA
    any(z %in% groups)
  }
  out$visceral_any      <- vapply(out$ptid, anyg, logical(1), groups = NM_VISCERAL_GROUPS)
  out$nonvisceral_any   <- vapply(out$ptid, anyg, logical(1), groups = NM_NONVISCERAL_GROUPS)
  out$intrathoracic_any <- vapply(out$ptid, anyg, logical(1), groups = NM_INTRATHORACIC_GROUPS)
  out$cns_involved      <- vapply(out$ptid, anyg, logical(1), groups = NM_CNS_GROUPS)
  # 'unmapped_other' is deliberately in NO clinical grouping, so a patient whose
  # only site is unmapped is visceral=FALSE, nonvisceral=FALSE,
  # intrathoracic=FALSE. That is not a bug, it is the honest answer, and this
  # flag names it so the analyst can see how many there are.
  out$visceral_unclassifiable <- vapply(out$ptid, anyg, logical(1),
                                        groups = c("unmapped_other"))
  out$nonvisceral_only <- out$nonvisceral_any & !out$visceral_any &
                          !out$intrathoracic_any & !out$cns_involved
  out$nonvisceral_only[not_eval] <- NA        # `NA & FALSE` is FALSE; never leak a FALSE
  # Intrathoracic-ONLY disease (M1a-like): the best-prognosis metastatic
  # subgroup, and the reason lung and pleura are not split across the visceral
  # dichotomy (D_VISCERAL_DEF).
  out$intrathoracic_only <- out$intrathoracic_any & !out$visceral_any &
                            !out$nonvisceral_any & !out$cns_involved
  out$intrathoracic_only[not_eval] <- NA

  sites_str <- vapply(out$ptid, function(pt) {
    z <- grp_of[[pt]]
    if (is.null(z) || all(is.na(z))) NA_character_ else
      paste(sort(unique(z[!is.na(z)])), collapse = "|")
  }, character(1))
  out$site_groups <- unname(sites_str)

  list(summary            = out,
       unmapped           = unmapped_all,
       blank_location     = blank_location,
       unmapped_in_window = unmapped_win,
       window   = list(unit          = nm_dec("D_NSITES_UNIT", ov),
                       lookback_days = lb %||% "all_history_up_to_index",
                       index_day     = nm_dec("D_INDEX_DAY_INCLUSIVE", ov),
                       temporal      = nm_dec("D_METS_TEMPORAL", ov),
                       orphan_mode   = "see nm_mets_sites(mode=)"))
}

# ============================================================================
# 7. nm_stage_tnm() - STAGE
# ============================================================================

# t_onc_tnm stores TNM as BARE values ('3','1','4a','x'), NOT 'T3'/'N1'. So the
# category is the FIRST CHARACTER. Observed t values include 'is' (in situ) and
# a bare 'a' (208,022 rows) which is not a T category at all - it is returned as
# a category of its own rather than coerced into something numeric.
NM_TNM_NUMERIC <- c("0", "1", "2", "3", "4")

nm_tnm_cat <- function(x) {
  v <- tolower(trimws(as.character(x)))
  v[is.na(v) | !nzchar(v)] <- NA_character_
  first <- substr(v, 1, 1)
  first[is.na(v)] <- NA_character_
  # 'is' -> carcinoma in situ, kept as 'is' not as 'i'.
  first[!is.na(v) & v == "is"] <- "is"
  first
}

nm_tnm_cat_class <- function(cat) {
  ifelse(is.na(cat), "missing",
    ifelse(cat %in% NM_TNM_NUMERIC, "numeric",
      ifelse(cat == "x", "unknown_x",
        ifelse(cat == "is", "in_situ", "unrecognised"))))
}

# How many of {t,n,m} carry a CLINICALLY USABLE (numeric 0-4) category. 'x',
# 'is' and unparsed tokens are kept as categories by nm_tnm_cat() but say
# nothing about stage, so a TxNxMx row must rank as uninformative (D_STAGE_
# AT_DX_INFORMATIVE) and lose the D_STAGE_TIEBREAK, never win on its date.
nm_tnm_n_informative <- function(t_cat, n_cat, m_cat)
  as.integer(t_cat %in% NM_TNM_NUMERIC) + as.integer(n_cat %in% NM_TNM_NUMERIC) +
  as.integer(m_cat %in% NM_TNM_NUMERIC)

# The AJCC descriptor prefix, from t_prefix / n_prefix / m_prefix (varchar(2),
# varlist.txt RESULT 9 cols 9, 12, 15). c = clinical, p = pathological,
# y = POST-NEOADJUVANT RESTAGING (ycT/ypT), r = recurrence. In a 2L cohort the
# y records are exactly the ones likely to be present, and a ycT0N0M0 restaging
# note is not a diagnosis stage. UNVERIFIED: the vocabulary of these three
# columns has never been dumped - nm_vocab_scan() now dumps it.
nm_tnm_descriptor <- function(t_prefix, n_prefix, m_prefix) {
  cl <- function(z) {
    z <- tolower(trimws(as.character(z)))
    z[is.na(z)] <- ""
    z
  }
  paste0(cl(t_prefix), cl(n_prefix), cl(m_prefix))
}

# M1 subcategory. D_M_SUBCATEGORY: the m column's own subdivision first
# (observed values 1a/1b/1c), m_suffix only when m is bare '1' AND the suffix
# matches ^[abc]$. The m_suffix vocabulary has NEVER been dumped, so anything
# else yields 'M1_NOS' and leaves the raw suffix visible.
#
# D_AJCC_EDITION: M1b is NOT one construct across editions. AJCC 7 lung M1b =
# ANY distant metastasis (so 7th-ed M1b spans 8th-ed M1b + M1c); AJCC 8 M1b = a
# SINGLE extrathoracic lesion, M1c = multiple. There is no edition column in
# t_onc_tnm, so note_date is used as a proxy and pre-2017 (and undated) records
# are collapsed to M1_NOS by default. Returns BOTH the subcategory and the era,
# so the collapse is auditable rather than invisible.
#
# THIS IS THE VARIABLE FLATIRON CANNOT MAKE. The inventory row "M stage /
# distant metastasis extent" reads: "no M-stage field; group stage gives broad
# stage; raw secondary-neoplasm ICD gives only a coarse metastasis indicator
# (not M0/M1a/b/c)". M1a (contralateral lung / pleural or pericardial) vs M1b
# (single extrathoracic) vs M1c (multiple extrathoracic) is a real prognostic
# gradient in NSCLC, and it is here - for the AJCC-8-era records.
nm_m1_subcategory <- function(m, m_suffix, note_date = NULL, ov = list()) {
  mv <- tolower(trimws(as.character(m)))
  sf <- tolower(trimws(as.character(m_suffix)))
  sf[is.na(sf)] <- ""
  out <- rep(NA_character_, length(mv))
  is_m1 <- !is.na(mv) & nzchar(mv) & substr(mv, 1, 1) == "1"
  out[is_m1] <- "M1_NOS"
  sub_in_m <- is_m1 & grepl("^1[abc]$", mv)
  out[sub_in_m] <- paste0("M1", substr(mv[sub_in_m], 2, 2))
  sub_in_sfx <- is_m1 & mv == "1" & grepl("^[abc]$", sf)
  out[sub_in_sfx] <- paste0("M1", sf[sub_in_sfx])

  nd <- if (is.null(note_date)) rep(as.Date(NA), length(mv)) else as.Date(note_date)
  era <- ifelse(is.na(nd), "unknown_era",
                ifelse(nd >= NM_AJCC8_FROM, "ajcc8_era", "pre_ajcc8"))
  if (identical(nm_dec("D_AJCC_EDITION", ov), "collapse_pre_ajcc8_to_M1_NOS")) {
    coll <- !is.na(out) & era != "ajcc8_era"
    out[coll] <- "M1_NOS"
  }
  data.frame(m1_subcategory = out, m1_edition_era = era, stringsAsFactors = FALSE)
}

# ---- t_onc_stage.stage free-text classification (D_STAGE_FREETEXT) ---------
# Observed contamination, all of it real: descriptive strings, bare a/b/c/d,
# Ann-Arbor-like ie/iae/iie/iiae (lymphoma vocabulary), leaked m0..m7, a '5'
# (AJCC has no stage 5), 'unknown' and 'x'.
NM_STAGE_DESCRIPTIVE <- c("advanced", "early stage", "limited stage",
                          "extensive stage", "end stage")

# The AJCC group-suffix grammar, as a remainder pattern: nothing, or a letter
# a/b/c/d optionally followed by 1 or 2 (IIIA, IB1, 1a2 ...). The whole string
# is anchored against it. Without the anchor, ANY unseen token beginning with i
# or a digit manufactures a stage - 'is' would become stage 1, '2 of 3 nodes'
# would become stage 2 - which is the precise failure D_STAGE_FREETEXT exists to
# prevent, and the parser is keyed on a 52-row distribution.
NM_STAGE_SUFFIX_RE <- "^([abcd][12]?)?$"

# Returns a data.frame(stage_group, stage_class) - stage_group is the AJCC
# number as character or NA; stage_class says WHY it is NA, so the
# contamination is measurable.
nm_stage_parse <- function(x) {
  s <- tolower(trimws(as.character(x)))
  n <- length(s)
  grp <- rep(NA_character_, n)
  cls <- rep("unmapped", n)

  blank <- is.na(s) | !nzchar(s)
  cls[blank] <- "missing"

  live <- !blank
  # unknown / x
  hit <- live & s %in% c("unknown", "x")
  cls[hit] <- "unknown"; live <- live & !hit
  # carcinoma in situ. Handled BEFORE the roman loop, which would otherwise read
  # the leading 'i'. nm_tnm_cat() special-cases the same token for the T column,
  # so the file already knows it exists in this curation stream.
  hit <- live & s == "is"
  cls[hit] <- "in_situ"; live <- live & !hit
  # leaked M codes (m0..m7 observed)
  hit <- live & grepl("^m[0-9]+$", s)
  cls[hit] <- "m_code_leak"; live <- live & !hit
  # descriptive free text
  hit <- live & Reduce(`|`, lapply(NM_STAGE_DESCRIPTIVE, function(p) grepl(p, s, fixed = TRUE)))
  cls[hit] <- "descriptive"; live <- live & !hit
  # bare suffix letters
  hit <- live & grepl("^[abcd]$", s)
  cls[hit] <- "orphan_suffix"; live <- live & !hit
  # arabic AJCC 0-4, WHOLE STRING anchored (0, 0a, 1a1, 2c, 3b, 4c ...)
  hit <- live & grepl(paste0("^[0-4]", substr(NM_STAGE_SUFFIX_RE, 2, nchar(NM_STAGE_SUFFIX_RE))), s)
  grp[hit] <- substr(s[hit], 1, 1); cls[hit] <- "ajcc_arabic"; live <- live & !hit
  # a leading digit outside 0-4 ('5' observed) - AJCC has no such group
  hit <- live & grepl("^[5-9]", s)
  cls[hit] <- "out_of_range_numeric"; live <- live & !hit
  # a leading 0-4 that failed the suffix grammar: numeric-looking, not a stage
  hit <- live & grepl("^[0-9]", s)
  cls[hit] <- "unmapped"; live <- live & !hit
  # roman. iv before iii before ii before i. A remainder containing 'e' is
  # Ann-Arbor-style (I-E, II-AE) - lymphoma staging, not AJCC lung. A remainder
  # that is neither is left UNMAPPED with grp = NA; it never becomes a stage.
  rom <- c("iv" = "4", "iii" = "3", "ii" = "2", "i" = "1")
  for (r in names(rom)) {
    hit <- live & substr(s, 1, nchar(r)) == r
    if (!any(hit)) next
    idx <- which(hit)
    rest <- substr(s[idx], nchar(r) + 1L, nchar(s[idx]))
    ann <- grepl("e", rest)
    ok  <- grepl(NM_STAGE_SUFFIX_RE, rest)
    grp[idx[ok & !ann]] <- rom[[r]]
    cls[idx[ok & !ann]] <- "ajcc_roman"
    cls[idx[ann]]       <- "ann_arbor_like"
    cls[idx[!ok & !ann]] <- "unmapped"
    live[idx] <- FALSE
  }
  data.frame(stage_group = grp, stage_class = cls, stringsAsFactors = FALSE)
}

# THE stage reader. Both staging tables, both tied to the lung primary by the
# same mode. Returns a LIST of record-level frames plus a per-patient roll-up:
#   $tnm         one row per t_onc_tnm record: t/n/m raw + category + class,
#                m1_subcategory + m1_edition_era, tnm_descriptor (c/p/y/r),
#                stage_prefix (carried, never filtered)
#   $stage       one row per t_onc_stage record: raw stage, ajcc group, class
#   $per_patient one row per patient, EVER-basis, unrestricted by index - a
#                convenience/diagnostic view. FOR THE MODEL USE
#                nm_stage_at_index(), which applies D_STAGE_BASIS.
#   $freetext    counts by stage_class, i.e. how contaminated t_onc_stage is
nm_stage_tnm <- function(con, mode = NULL, ov = list(), collect = TRUE) {

  # `n` must be renamed - it collides with dplyr::n(). Same fix as the precedent.
  tnm_q <- nm_lung_attributed(con,
             mc_tbl(con, "onc_tnm") |> dplyr::filter(note_date <= NM_STUDY_END),
             mode = mode, ov = ov) |>
    dplyr::rename(n_val = n) |>
    dplyr::select(ptid, note_date, neoplasm_histology_key, stage_prefix,
                  t_prefix, t, t_suffix, n_prefix, n_val, n_suffix,
                  m_prefix, m, m_suffix, sourceid)

  stg_q <- nm_lung_attributed(con,
             mc_tbl(con, "onc_stage") |> dplyr::filter(note_date <= NM_STUDY_END),
             mode = mode, ov = ov) |>
    dplyr::select(ptid, note_date, neoplasm_histology_key, stage_prefix, stage, sourceid)

  if (!collect) return(list(tnm = tnm_q, stage = stg_q))

  tnm <- as.data.frame(dplyr::collect(tnm_q), stringsAsFactors = FALSE)
  stg <- as.data.frame(dplyr::collect(stg_q), stringsAsFactors = FALSE)

  tnm$note_date <- as.Date(tnm$note_date)
  tnm$t_cat <- nm_tnm_cat(tnm$t)
  tnm$n_cat <- nm_tnm_cat(tnm$n_val)
  tnm$m_cat <- nm_tnm_cat(tnm$m)
  tnm$t_class <- nm_tnm_cat_class(tnm$t_cat)
  tnm$n_class <- nm_tnm_cat_class(tnm$n_cat)
  tnm$m_class <- nm_tnm_cat_class(tnm$m_cat)
  m1 <- nm_m1_subcategory(tnm$m, tnm$m_suffix, tnm$note_date, ov = ov)
  tnm$m1_subcategory <- m1$m1_subcategory
  tnm$m1_edition_era <- m1$m1_edition_era
  tnm$tnm_descriptor <- nm_tnm_descriptor(tnm$t_prefix, tnm$n_prefix, tnm$m_prefix)
  # D_STAGE_TIEBREAK inputs, computed once.
  tnm$n_populated <- nm_tnm_n_informative(tnm$t_cat, tnm$n_cat, tnm$m_cat)
  tnm$prefix_rank <- match(tolower(trimws(as.character(tnm$stage_prefix))),
                           c("pathological", "clinical"))
  tnm$prefix_rank[is.na(tnm$prefix_rank)] <- 3L

  p <- nm_stage_parse(stg$stage)
  stg$ajcc_group <- p$stage_group
  stg$stage_class <- p$stage_class
  stg$note_date <- as.Date(stg$note_date)
  stg$prefix_rank <- match(tolower(trimws(as.character(stg$stage_prefix))),
                           c("pathological", "clinical"))
  stg$prefix_rank[is.na(stg$prefix_rank)] <- 3L

  ft <- as.data.frame(table(stage_class = stg$stage_class), stringsAsFactors = FALSE)
  names(ft)[2] <- "n_records"

  list(tnm = tnm, stage = stg, freetext = ft,
       per_patient = nm_stage_reduce(tnm, stg, index_dates = NULL,
                                     basis = "ever_pre_index", ov = ov))
}

# ============================================================================
# 8. nm_stage_at_index() - EVER-STAGED vs STAGE-AT-DIAGNOSIS
#
# The precedent leaves this open. BOTH are exposed here as first-class modes.
# THE DEFAULT IS "at_diagnosis" and the reason is written out in
# NM_DECISIONS$D_STAGE_BASIS: it is the same object as the Flatiron field (so
# the two analyses stay comparable), and the alternative takes a maximum over a
# record count that is itself driven by how much care the patient received,
# which walks an informative-observation bias into a prognostic score.
#
# BOTH BASES RETURN THE SAME COLUMNS. That is enforced structurally by
# nm_ensure_cols() rather than left to the two branches to remember, because a
# SAP table built against one schema breaking on the other is a silly way to
# lose a day.
# ============================================================================

# Add any missing columns as NA so two code paths cannot return different
# schemas. Works on zero-row frames.
nm_ensure_cols <- function(d, cols) {
  for (cl in cols) if (!cl %in% names(d)) d[[cl]] <- rep(NA, nrow(d))
  d
}

# Collapse a per-patient set of *_class values to one string, dropping the
# uninformative "missing". Used by the ever-basis so the class columns are
# CARRIED rather than nulled - the comment in the ever branch used to promise
# this and the code used to do the opposite.
nm_collapse_class <- function(pt, cls) {
  res <- tapply(cls, pt, function(z) {
    z <- z[!is.na(z) & z != "missing"]
    if (!length(z)) return("missing")
    paste(sort(unique(z)), collapse = "|")
  })
  res
}

# Ever-basis category per patient: the maximum NUMERIC category where the
# patient has any; otherwise the observed non-numeric value(s) ('x', 'is', a
# bare 'a'), collapsed. Carrying the non-numerics matters: nulling them made
# has_tnm and nm_stage_basis_impact() a function of the BASIS rather than of the
# data, and 'x' alone is 282,999 T rows / 959,588 N rows / 1,066,031 M rows in
# the observed distribution.
nm_ever_cat <- function(pt, cat) {
  tapply(cat, pt, function(z) {
    z <- z[!is.na(z)]
    if (!length(z)) return(NA_character_)
    num <- z[z %in% NM_TNM_NUMERIC]
    if (length(num)) return(as.character(max(as.integer(num))))
    paste(sort(unique(z)), collapse = "|")
  })
}

# Internal reducer shared by nm_stage_tnm()$per_patient and nm_stage_at_index().
nm_stage_reduce <- function(tnm, stg, index_dates = NULL,
                            basis = c("at_diagnosis", "ever_pre_index"), ov = list()) {
  basis <- match.arg(basis)
  stopifnot(is.data.frame(tnm), is.data.frame(stg))
  tnm <- nm_ensure_cols(as.data.frame(tnm, stringsAsFactors = FALSE),
                        c("ptid", "note_date", "t_cat", "n_cat", "m_cat", "t_class",
                          "n_class", "m_class", "m1_subcategory", "m1_edition_era",
                          "stage_prefix", "prefix_rank", "n_populated", "sourceid",
                          "tnm_descriptor"))
  # Recomputed at the point of use so a frame assembled by another route is
  # scored by the same informativeness rule as nm_stage_tnm() output.
  tnm$n_populated <- nm_tnm_n_informative(tnm$t_cat, tnm$n_cat, tnm$m_cat)
  stg <- nm_ensure_cols(as.data.frame(stg, stringsAsFactors = FALSE),
                        c("ptid", "note_date", "stage", "ajcc_group", "stage_class",
                          "stage_prefix", "prefix_rank", "sourceid"))

  if (!is.null(index_dates)) {
    if (!all(c("ptid", "index_date") %in% names(index_dates)))
      stop("nm_stage_reduce(): index_dates must have columns ptid, index_date")
    if (any(duplicated(index_dates$ptid)))
      stop("nm_stage_reduce(): index_dates must be one row per ptid")
    idx <- data.frame(ptid = index_dates$ptid,
                      index_date = as.Date(index_dates$index_date), stringsAsFactors = FALSE)
    tnm <- merge(tnm, idx, by = "ptid")
    stg <- merge(stg, idx, by = "ptid")
    tnm <- tnm[which(tnm$note_date <= tnm$index_date), , drop = FALSE]
    stg <- stg[which(stg$note_date <= stg$index_date), , drop = FALSE]
    pts <- idx$ptid
  } else {
    pts <- unique(c(tnm$ptid, stg$ptid))
  }

  # rep(): a length-1 `basis` recycled against a length-0 `pts` is an ERROR in
  # data.frame(), and zero rows is the single most likely first-run outcome
  # (mode A drops the orphan rows, and NM_LUNG_NEO_SUBSTR is a probe).
  out <- data.frame(ptid = pts, stage_basis = rep(basis, length(pts)),
                    stringsAsFactors = FALSE)

  # D_TNM_PREFIX: y (post-neoadjuvant restaging) and r (recurrence) records are
  # excluded from the at_diagnosis SELECTION, never from the data.
  yr <- !is.na(tnm$tnm_descriptor) & grepl("[yr]", tnm$tnm_descriptor)
  yr_pts <- unique(tnm$ptid[yr])
  excl_yr <- identical(nm_dec("D_TNM_PREFIX", ov), "exclude_y_r_from_at_diagnosis")

  if (basis == "at_diagnosis") {
    # D_STAGE_AT_DX_INFORMATIVE: informativeness is ranked AHEAD of date, so an
    # empty TNM row or an 'advanced' free-text row cannot blank a patient who
    # has a real record a month later and still pre-index. Ties are then broken
    # by D_STAGE_TIEBREAK: most of {t,n,m} populated, pathological > clinical >
    # null, sourceid ascending.
    inform_first <- identical(nm_dec("D_STAGE_AT_DX_INFORMATIVE", ov),
                              "earliest_informative_record")
    pool <- if (excl_yr) tnm[which(!yr), , drop = FALSE] else tnm
    if (nrow(pool)) {
      o <- if (inform_first)
        order(pool$ptid, pool$n_populated == 0L, pool$note_date,
              -pool$n_populated, pool$prefix_rank, as.character(pool$sourceid))
      else
        order(pool$ptid, pool$note_date, -pool$n_populated,
              pool$prefix_rank, as.character(pool$sourceid))
      pp <- pool[o, , drop = FALSE]
      tsel <- pp[!duplicated(pp$ptid), , drop = FALSE]
    } else {
      tsel <- pool
    }
    tsel$n_uninformative_records_skipped <- rep(0L, nrow(tsel))
    if (nrow(tsel)) {
      sel_date <- stats::setNames(tsel$note_date, tsel$ptid)
      unin <- pool[which(pool$n_populated == 0L), , drop = FALSE]
      if (nrow(unin)) {
        keep <- unin$note_date < sel_date[unin$ptid]
        keep[is.na(keep)] <- FALSE
        if (any(keep)) {
          sk <- table(unin$ptid[keep])
          v <- as.integer(sk[tsel$ptid]); v[is.na(v)] <- 0L
          tsel$n_uninformative_records_skipped <- v
        }
      }
    }

    if (nrow(stg)) {
      # A record with a real AJCC group outranks a contaminated one, whatever
      # the dates - otherwise 'advanced' would blank a real stage.
      o <- if (inform_first)
        order(stg$ptid, is.na(stg$ajcc_group), stg$note_date, stg$prefix_rank,
              as.character(stg$sourceid))
      else
        order(stg$ptid, stg$note_date, is.na(stg$ajcc_group), stg$prefix_rank,
              as.character(stg$sourceid))
      ss0 <- stg[o, , drop = FALSE]
      ssel <- ss0[!duplicated(ss0$ptid), , drop = FALSE]
    } else {
      ssel <- stg
    }
    ssel$n_nonajcc_stage_records_skipped <- rep(0L, nrow(ssel))
    if (nrow(ssel)) {
      sel_date <- stats::setNames(ssel$note_date, ssel$ptid)
      unin <- stg[which(is.na(stg$ajcc_group)), , drop = FALSE]
      if (nrow(unin)) {
        keep <- unin$note_date < sel_date[unin$ptid]
        keep[is.na(keep)] <- FALSE
        if (any(keep)) {
          sk <- table(unin$ptid[keep])
          v <- as.integer(sk[ssel$ptid]); v[is.na(v)] <- 0L
          ssel$n_nonajcc_stage_records_skipped <- v
        }
      }
    }

  } else {
    # ever_pre_index: the HIGHEST category recorded on or before index, with the
    # non-numeric categories carried rather than dropped (nm_ever_cat).
    tsel <- data.frame(ptid = unique(tnm$ptid), stringsAsFactors = FALSE)
    if (nrow(tnm) && nrow(tsel)) {
      mt <- nm_ever_cat(tnm$ptid, tnm$t_cat)
      mn <- nm_ever_cat(tnm$ptid, tnm$n_cat)
      mm <- nm_ever_cat(tnm$ptid, tnm$m_cat)
      tsel$t_cat <- unname(mt[tsel$ptid])
      tsel$n_cat <- unname(mn[tsel$ptid])
      tsel$m_cat <- unname(mm[tsel$ptid])
      ct <- nm_collapse_class(tnm$ptid, tnm$t_class)
      cn <- nm_collapse_class(tnm$ptid, tnm$n_class)
      cm <- nm_collapse_class(tnm$ptid, tnm$m_class)
      tsel$t_class <- unname(ct[tsel$ptid])
      tsel$n_class <- unname(cn[tsel$ptid])
      tsel$m_class <- unname(cm[tsel$ptid])
      # M1 subcategory on the ever-basis = the most advanced M1x seen. The
      # subcategories have already been collapsed to M1_NOS for pre-AJCC8
      # records (D_AJCC_EDITION), so this maximum is taken within the 8th-ed
      # gradient rather than across two incompatible definitions.
      lev <- c("M1_NOS", "M1a", "M1b", "M1c")
      rk <- match(tnm$m1_subcategory, lev)
      keep <- !is.na(rk)
      if (any(keep)) {
        best <- tapply(rk[keep], tnm$ptid[keep], max)
        tsel$m1_subcategory <- lev[unname(best[tsel$ptid])]
      } else {
        tsel$m1_subcategory <- rep(NA_character_, nrow(tsel))
      }
      ce <- nm_collapse_class(tnm$ptid, tnm$m1_edition_era)
      tsel$m1_edition_era <- unname(ce[tsel$ptid])
      # stage_prefix is record-level; on an ever-basis it does not belong to one
      # record, so it is reported as the best prefix seen, not silently dropped.
      bp <- tapply(tnm$prefix_rank, tnm$ptid, min)
      tsel$stage_prefix <- c("pathological", "clinical", NA_character_)[unname(bp[tsel$ptid])]
      tsel$note_date <- as.Date(unname(tapply(as.integer(tnm$note_date), tnm$ptid, max)[tsel$ptid]),
                                origin = "1970-01-01")
      tsel$tnm_descriptor <- unname(nm_collapse_class(tnm$ptid, tnm$tnm_descriptor)[tsel$ptid])
    }

    ssel <- data.frame(ptid = unique(stg$ptid), stringsAsFactors = FALSE)
    if (nrow(stg) && nrow(ssel)) {
      g <- stg$ajcc_group; keep <- !is.na(g)
      if (any(keep)) {
        mg <- tapply(as.integer(g[keep]), stg$ptid[keep], max)
        ssel$ajcc_group <- as.character(unname(mg[ssel$ptid]))
      } else {
        ssel$ajcc_group <- rep(NA_character_, nrow(ssel))
      }
      # Keep the D_STAGE_FREETEXT classification instead of overwriting it with
      # a constant - the contamination is the point.
      ssel$stage_class <- unname(nm_collapse_class(stg$ptid, stg$stage_class)[ssel$ptid])
      ssel$stage <- unname(tapply(as.character(stg$stage), stg$ptid,
                                  function(z) paste(sort(unique(z[!is.na(z)])),
                                                    collapse = "|"))[ssel$ptid])
      ssel$note_date <- as.Date(unname(tapply(as.integer(stg$note_date), stg$ptid,
                                              max)[ssel$ptid]), origin = "1970-01-01")
      bp <- tapply(stg$prefix_rank, stg$ptid, min)
      ssel$stage_prefix <- c("pathological", "clinical", NA_character_)[unname(bp[ssel$ptid])]
    }
  }

  tcols <- c("ptid", "t_cat", "n_cat", "m_cat", "t_class", "n_class", "m_class",
             "m1_subcategory", "m1_edition_era", "stage_prefix", "tnm_descriptor",
             "note_date", "n_uninformative_records_skipped")
  tsel <- nm_ensure_cols(tsel, tcols)
  tt <- tsel[, tcols, drop = FALSE]
  names(tt)[names(tt) == "note_date"]    <- "tnm_note_date"
  names(tt)[names(tt) == "stage_prefix"] <- "tnm_stage_prefix"

  scols <- c("ptid", "stage", "ajcc_group", "stage_class", "note_date", "stage_prefix",
             "n_nonajcc_stage_records_skipped")
  ssel <- nm_ensure_cols(ssel, scols)
  ss <- ssel[, scols, drop = FALSE]
  names(ss)[names(ss) == "stage"]        <- "stage_raw"
  names(ss)[names(ss) == "note_date"]    <- "stage_note_date"
  names(ss)[names(ss) == "stage_prefix"] <- "group_stage_prefix"

  out <- merge(out, tt, by = "ptid", all.x = TRUE)
  out <- merge(out, ss, by = "ptid", all.x = TRUE)

  # RECORD EXISTENCE, not category presence. Deriving has_tnm from the reduced
  # category made it mean 'a numeric category exists' on one basis and 'a record
  # exists' on the other, and inflated nm_stage_basis_impact() with patients who
  # do not actually disagree.
  out$n_tnm_records   <- as.integer(table(tnm$ptid)[out$ptid]); out$n_tnm_records[is.na(out$n_tnm_records)] <- 0L
  out$n_stage_records <- as.integer(table(stg$ptid)[out$ptid]); out$n_stage_records[is.na(out$n_stage_records)] <- 0L
  out$has_tnm   <- out$n_tnm_records > 0L
  out$has_group <- !is.na(out$ajcc_group)
  out$has_y_or_r_prefix <- out$ptid %in% yr_pts
  # M1 by ANY route: an explicit M1 category, or an AJCC group of 4. Reported as
  # a separate column, never overwriting m_cat - the two are different evidence.
  # NA (not FALSE) when there is no staging evidence at all: asserting "not M1"
  # about a patient nobody staged is a false negative straight into the score.
  # TRUE  : positive M1 evidence by either route.
  # FALSE : positive evidence of NOT-M1 -- an M category that is present and is
  #         not 1, or an AJCC group that is present and is not 4.
  # NA    : no INFORMATIVE evidence either way.
  # The NA guard previously fired only when a patient had NO staging record at
  # all, so T2 N1 with M MISSING and no group stage returned FALSE: a record
  # existed, therefore "not M1" -- asserting the absence of metastatic disease
  # from a record that is silent about it. Unknown M is unknown, and it must not
  # become a false negative on the advN=2 covariate.
  # INFORMATIVE means a recognised numeric category. nm_tnm_cat() KEEPS 'x' as
  # a category (it is not NA), so both n_populated and this predicate test
  # %in% NM_TNM_NUMERIC explicitly: 'x' (assessment not possible), 'is', a bare
  # suffix and any unparsed token all mean UNKNOWN, never "not M1".
  m_inf <- !is.na(out$m_cat)        & out$m_cat      %in% NM_TNM_NUMERIC
  g_inf <- !is.na(out$ajcc_group)   & out$ajcc_group %in% NM_TNM_NUMERIC
  m1_pos <- (m_inf & out$m_cat == "1") | (g_inf & out$ajcc_group == "4")
  m1_neg <- (m_inf & out$m_cat != "1") | (g_inf & out$ajcc_group != "4")
  m1 <- ifelse(m1_pos, TRUE, ifelse(m1_neg, FALSE, NA))
  out$m1_any <- m1
  out$stage_basis_note <- rep(if (basis == "at_diagnosis")
    "earliest INFORMATIVE staging record on/before index (D_STAGE_BASIS default)" else
    "highest category recorded on/before index (D_STAGE_BASIS alternative)", nrow(out))
  out
}

# Public entry point. `basis` defaults to the value in force in NM_DECISIONS
# (D_STAGE_BASIS = "at_diagnosis"), so the default is READ FROM THE REGISTER,
# not hard-coded in a second place where the two could drift apart.
nm_stage_at_index <- function(stage_obj, index_dates, basis = NULL, ov = list()) {
  if (!is.list(stage_obj) || !all(c("tnm", "stage") %in% names(stage_obj)))
    stop("nm_stage_at_index(): stage_obj must come from nm_stage_tnm(collect = TRUE)")
  if (!is.data.frame(stage_obj$tnm))
    stop("nm_stage_at_index(): stage_obj$tnm is lazy; call nm_stage_tnm(collect = TRUE)")
  b <- basis %||% nm_dec("D_STAGE_BASIS", ov)
  nm_stage_reduce(stage_obj$tnm, stage_obj$stage, index_dates = index_dates, basis = b, ov = ov)
}

# Report BOTH bases side by side. This is the deliverable for the open question,
# not a sensitivity afterthought: if the two disagree for a material share of
# patients, the choice is doing work and must be pre-specified in the SAP.
# differ_* counts are restricted to patients with a record on the relevant side,
# so a patient the two bases merely OBSERVE differently is not counted as a
# staging disagreement.
nm_stage_basis_impact <- function(stage_obj, index_dates, ov = list()) {
  a <- nm_stage_at_index(stage_obj, index_dates, basis = "at_diagnosis", ov = ov)
  e <- nm_stage_at_index(stage_obj, index_dates, basis = "ever_pre_index", ov = ov)
  keep <- c("ptid", "t_cat", "n_cat", "m_cat", "ajcc_group", "m1_subcategory",
            "has_tnm", "has_group")
  m <- merge(a[, keep, drop = FALSE], e[, keep, drop = FALSE],
             by = "ptid", suffixes = c("_at_dx", "_ever"))
  ne <- function(x, y) !((is.na(x) & is.na(y)) | (!is.na(x) & !is.na(y) & x == y))
  has_t <- m$has_tnm_at_dx | m$has_tnm_ever
  has_g <- m$has_group_at_dx | m$has_group_ever
  data.frame(
    n_patients          = nrow(m),
    n_with_tnm_record   = sum(has_t),
    n_with_stage_group  = sum(has_g),
    differ_t            = sum(ne(m$t_cat_at_dx, m$t_cat_ever) & has_t),
    differ_n            = sum(ne(m$n_cat_at_dx, m$n_cat_ever) & has_t),
    differ_m            = sum(ne(m$m_cat_at_dx, m$m_cat_ever) & has_t),
    differ_ajcc_group   = sum(ne(m$ajcc_group_at_dx, m$ajcc_group_ever) & has_g),
    differ_m1_subcat    = sum(ne(m$m1_subcategory_at_dx, m$m1_subcategory_ever) & has_t),
    stringsAsFactors = FALSE)
}

# ============================================================================
# 9. nm_icd_mets_proxy() - the Flatiron-equivalent read, for AGREEMENT ONLY
#
# D_ICD_FALLBACK: this is NEVER unioned into the enriched result. It exists so
# the gain can be measured: how many patients have an enriched SITE that the ICD
# proxy misses, how many the reverse, and how often the two disagree on the
# compartment.
#
# `pts` IS REQUIRED, and that is the whole point. The enriched side is
# lung-attributed through nm_lung_attributed(); an ICD side that scanned the
# whole deployment would answer for every breast, prostate and colon patient who
# ever carried a C78 code, and `icd_only` would be dominated by patients who are
# not in the cohort and do not have lung cancer. Pass nm_comparison_pts(con), or
# the actual 2L docetaxel index frame. There is no default.
#
# Handles ICD10 AND ICD9 (both present at row level) in ONE pass with a CASE
# expression, rather than ten filtered copies of t_diagnosis unioned together.
# SNOMEDCT rows are NOT decoded (D_ICD_SNOMED) and their volume is reported by
# nm_icd_vocab_scan() as an explicitly unmeasured share.
# ============================================================================

# CASE expression mapping a diagnosis row to a compartment; NULL when it is not
# a secondary-neoplasm code this file can decode. First matching WHEN wins; the
# prefix sets are disjoint by construction and nm_icd_list_lint() guards the
# structure.
nm_icd_site_case_sql <- function() {
  whens <- vapply(names(NM_ICD10_SITE), function(g) {
    p10 <- nm_code_prefix_sql("diagnosis_cd", NM_ICD10_SITE[[g]])
    p9  <- nm_code_prefix_sql("diagnosis_cd", NM_ICD9_SITE[[g]])
    paste0("WHEN ((diagnosis_cd_type = 'ICD10' AND ", p10, ")",
           " OR (diagnosis_cd_type = 'ICD9' AND ", p9, ")) THEN '", g, "'")
  }, character(1), USE.NAMES = FALSE)
  paste("CASE", paste(whens, collapse = " "), "ELSE NULL END")
}

nm_icd_mets_proxy <- function(con, pts, index_dates = NULL, collect = TRUE, ov = list()) {
  nm_icd_list_lint()
  if (missing(pts) || is.null(pts))
    stop("nm_icd_mets_proxy(): `pts` is required - a lazy tbl or data.frame of ptid. ",
         "An ungated ICD read answers for the whole deployment and makes the agreement ",
         "table uninterpretable. Use nm_comparison_pts(con).")

  dx <- mc_tbl(con, "diagnosis") |>
    dplyr::semi_join(pts, by = "ptid") |>
    dplyr::filter(diag_date <= NM_STUDY_END)

  q <- dx |>
    dplyr::mutate(icd_site_group = dbplyr::sql(nm_icd_site_case_sql())) |>
    dplyr::filter(!is.na(icd_site_group)) |>
    dplyr::group_by(ptid, icd_site_group) |>
    dplyr::summarise(first_icd_date = min(diag_date, na.rm = TRUE),
                     n_records = dplyr::n(), .groups = "drop")
  if (!collect) return(q)
  out <- as.data.frame(dplyr::collect(q), stringsAsFactors = FALSE)
  out$first_icd_date <- as.Date(out$first_icd_date)

  # Same pre-index window as the enriched side (D_INDEX_DAY_INCLUSIVE), so the
  # two sides are not comparing a lifetime of billing against a pre-index
  # curated read.
  if (!is.null(index_dates)) {
    if (!all(c("ptid", "index_date") %in% names(index_dates)))
      stop("nm_icd_mets_proxy(): index_dates must have columns ptid, index_date")
    idx <- data.frame(ptid = index_dates$ptid,
                      index_date = as.Date(index_dates$index_date), stringsAsFactors = FALSE)
    out <- merge(out, idx, by = "ptid", all.x = FALSE)
    inclusive <- identical(nm_dec("D_INDEX_DAY_INCLUSIVE", ov), "inclusive")
    out <- out[which(if (inclusive) out$first_icd_date <= out$index_date
                     else out$first_icd_date < out$index_date), , drop = FALSE]
  }
  out
}

# Agreement between the enriched site read and the ICD proxy, per compartment.
# This is the table that turns "Optum is better" from an assertion into a number,
# so it is fenced three ways:
#   1. `pts` is REQUIRED and BOTH sides are restricted to it. A setdiff between
#      two populations is not an agreement statistic.
#   2. `sites` must be positives-only nm_mets_sites() output. Passing
#      nm_mets_evidence() output would count SCREENED-NEGATIVE sites as enriched
#      positives, in the one table meant to show what the curated read adds.
#   3. Only the compartments whose anatomic definition is 1:1 on both sides
#      (NM_AGREEMENT_GROUPS) are scored. 'other_organ' is thyroid on the
#      enriched side and mediastinum/genital/respiratory-NOS on the ICD side;
#      'abdominal_organ' is 'intra-abdominal organs' vs bowel and kidney;
#      'unspecified_site' has no anatomy at all. Those rows are returned in
#      $not_comparable, NOT dropped and NOT presented as a win.
nm_mets_source_agreement <- function(sites, icd, pts) {
  stopifnot(is.data.frame(sites), is.data.frame(icd))
  if (missing(pts) || is.null(pts))
    stop("nm_mets_source_agreement(): `pts` is required - the population BOTH sides ",
         "were computed on (nm_comparison_pts() collected, or the index frame's ptids).")
  if ("status" %in% names(sites))
    stop("nm_mets_source_agreement(): `sites` carries a `status` column, i.e. it looks ",
         "like nm_mets_evidence() output, which contains screened_negative rows.")
  if (!"mets_qualifier" %in% names(sites) || !all(sites$mets_qualifier == "actual"))
    stop("nm_mets_source_agreement(): sites must be nm_mets_sites() output ",
         "(mets_qualifier == 'actual' on every row).")
  pt <- if (is.data.frame(pts)) unique(as.character(pts$ptid)) else unique(as.character(pts))

  s <- sites[which(sites$ptid %in% pt), , drop = FALSE]
  i <- icd[which(icd$ptid %in% pt), , drop = FALSE]
  s$site_group[is.na(s$site_group)] <- "unmapped_other"

  one <- function(g) {
    a <- unique(s$ptid[s$site_group == g])
    b <- unique(i$ptid[i$icd_site_group == g])
    data.frame(site_group = g,
               enriched_only = length(setdiff(a, b)),
               both          = length(intersect(a, b)),
               icd_only      = length(setdiff(b, a)),
               stringsAsFactors = FALSE)
  }
  all_groups <- sort(unique(c(s$site_group, i$icd_site_group)))
  comparable <- all_groups[all_groups %in% NM_AGREEMENT_GROUPS]
  residual   <- setdiff(all_groups, NM_AGREEMENT_GROUPS)

  list(
    comparable = if (length(comparable)) do.call(rbind, lapply(comparable, one)) else
      data.frame(site_group = character(0), enriched_only = integer(0),
                 both = integer(0), icd_only = integer(0), stringsAsFactors = FALSE),
    not_comparable = if (length(residual)) do.call(rbind, lapply(residual, one)) else
      data.frame(site_group = character(0), enriched_only = integer(0),
                 both = integer(0), icd_only = integer(0), stringsAsFactors = FALSE),
    note = paste("$not_comparable rows are NOT an agreement statistic: the two sources",
                 "bucket those compartments differently (see NM_AGREEMENT_GROUPS)."),
    population = list(n_patients = length(pt))
  )
}

# ============================================================================
# 10. nm_compare_to_flatiron() - the gain, in code
#
# Every flatiron_status string below is QUOTED from
# ../candidate_variable_inventory.csv (columns `feasibility` and
# `flatiron_availability`). Nothing here is a characterisation of Flatiron that
# this project has not already written down and reviewed.
# ============================================================================

nm_compare_to_flatiron <- function() {
  r <- function(variable, advn, flatiron_status, flatiron_detail, optum_source, optum_fn, gain)
    data.frame(variable = variable, advN_prognostic = advn,
               flatiron_status = flatiron_status, flatiron_detail = flatiron_detail,
               optum_source = optum_source, optum_function = optum_fn, gain = gain,
               stringsAsFactors = FALSE)

  rbind(
    r("Number of metastatic sites", 2L,
      "Feasible if confirmed - raw",
      "count of t_diagnosis secondary-neoplasm codes (C78-C79); no RWDAP field; imperfect",
      "t_onc_metastatic_location.metastasis_location (controlled site vocabulary)",
      "nm_mets_summary()$summary$n_met_sites",
      paste("CURATED site assertion with an actual/absent qualifier, instead of a billing-code",
            "count. Highest-evidence metastasis variable in the inventory (Shang2021 HR 1.563;",
            "Sun2026 HR 1.76) and it is the one that most needs to stop being a proxy.")),

    r("Bone metastasis", 1L,
      "Feasible if confirmed - raw", "t_diagnosis C79.5; no RWDAP field; imperfect",
      "metastasis_location IN ('bone','vertebral column','rib') [observed]",
      "nm_mets_summary()$summary$met_bone",
      "Curated site + explicit negation; three observed vocabulary values roll into one compartment."),

    r("Liver metastasis", 1L,
      "Feasible if confirmed - raw", "t_diagnosis C78.7; no RWDAP field; imperfect",
      "metastasis_location = 'liver' [observed]",
      "nm_mets_summary()$summary$met_liver",
      "Curated site + explicit negation."),

    r("Brain/CNS metastasis", 0L,
      "Feasible if confirmed - raw", "t_diagnosis C79.31; no RWDAP field; imperfect",
      "metastasis_location = 'brain' [observed] + CNS patterns",
      "nm_mets_summary()$summary$met_brain_cns / $cns_involved",
      paste("Curated site AND documented ABSENCE. 'No brain metastasis' is a REVEL exclusion",
            "criterion and a LUME-Lung 1 stratification factor; ICD cannot express it.")),

    r("Lung/contralateral metastasis", 0L,
      "Feasible if confirmed - raw", "t_diagnosis; no RWDAP field; imperfect",
      "metastasis_location = 'lung' [observed]",
      "nm_mets_summary()$summary$met_lung / $intrathoracic_only",
      paste("Curated site. NOTE: laterality is NOT in t_onc_metastatic_location, so",
            "'contralateral' is NOT resolved - see KNOWN LIMITS E.")),

    r("Pleural metastasis / effusion", 0L,
      "Feasible if confirmed - raw", "t_diagnosis (C78.2/J91); no RWDAP field; imperfect",
      "metastasis_location = 'pleura' [observed]",
      "nm_mets_summary()$summary$met_pleura",
      "Curated pleural METASTASIS, separable from effusion - the inventory flags that the ICD proxy conflates the two."),

    r("Adrenal metastasis", 0L,
      "Feasible if confirmed - raw", "t_diagnosis C79.7; no RWDAP field; imperfect",
      "metastasis_location matching 'adrenal' - NOT OBSERVED in the value sample",
      "nm_mets_summary()$summary$met_adrenal",
      "CONDITIONAL GAIN. The flag exists only if nm_vocab_scan() shows such a value; do not promise it first."),

    r("M stage / distant metastasis extent", 1L,
      "Not feasible - no field",
      "no M-stage field; group stage gives broad stage; raw ICD gives only a coarse indicator (not M0/M1a/b/c)",
      "t_onc_tnm.m (observed values 0, 1, 1a, 1b, 1c, x) + m_suffix",
      "nm_stage_tnm()$tnm$m_cat and $m1_subcategory (+ $m1_edition_era)",
      paste("STRUCTURAL GAIN. A formal M category, and M1a vs M1b vs M1c - precisely the",
            "distinction the inventory records as impossible in Flatiron. QUALIFIED: the",
            "M1b/M1c contrast is only one construct for AJCC-8-era records, and there is no",
            "edition column, so pre-2017 records are collapsed to M1_NOS (D_AJCC_EDITION).")),

    r("T stage", 1L,
      "Not feasible - no field", "advanced cohort: group stage only, no TNM",
      "t_onc_tnm.t (bare values; first character is the category)",
      "nm_stage_tnm()$tnm$t_cat",
      paste("STRUCTURAL GAIN. Flatiron's advanced cohort has no TNM at all. Same edition",
            "caveat: T1a/b/c cut-offs and the T3/T4 definitions changed in AJCC 8 and are NOT",
            "corrected here, only stated (KNOWN LIMITS L).")),

    r("N stage / nodal status", 1L,
      "Not feasible - no field", "advanced cohort: group stage only, no TNM",
      "t_onc_tnm.n (renamed n_val; first character is the category)",
      "nm_stage_tnm()$tnm$n_cat",
      "STRUCTURAL GAIN. Same."),

    r("Overall stage (TNM group)", 2L,
      "Feasible - data product",
      "stage = initial GROUP stage (not per-TNM substage; not stage-at-index)",
      "t_onc_stage.stage (AJCC group, with documented free-text contamination)",
      "nm_stage_at_index()$ajcc_group",
      paste("NO NET GAIN on the group itself - Flatiron already has it and Flatiron's is",
            "abstracted, which is likely CLEANER than a column that also contains 'advanced',",
            "'limited stage' and leaked m-codes. The Optum gain is that stage-AT-INDEX becomes",
            "expressible at all (D_STAGE_BASIS), which Flatiron's field is not.")),

    r("Documented ABSENCE of metastasis at a site", NA_integer_,
      "Not feasible - no field", "no ICD code expresses a negative finding",
      "t_onc_metastatic_location.mets_qualifier = 'absent'",
      "nm_mets_absent() / nm_mets_evidence()$by_compartment",
      paste("STRUCTURAL GAIN, and the one most easily overlooked: it separates",
            "'screened, negative' from 'nobody looked'. An ICD-proxy variable cannot tell",
            "those apart, so its zeros are a mixture."))
  )
}

# ============================================================================
# 11. VALIDATION HELPERS - run these BEFORE trusting any mapping or any count
# ============================================================================

# Dump the observed vocabularies with counts. NOTHING in this file should be
# believed until this has been run and its output eyeballed: every mapping above
# is keyed on a value SAMPLE, a distribution screenshot, or (for the *_prefix
# and m_suffix columns) on nothing at all.
#   nm_vocab_scan(mc_connect())
nm_vocab_scan <- function(con, n = 300) {
  ml  <- mc_tbl(con, "onc_metastatic_location")
  tnm <- mc_tbl(con, "onc_tnm")
  stg <- mc_tbl(con, "onc_stage")
  list(
    # The site vocabulary crossed with qualifier and temporal status. Read the
    # 'absent' share here - it is the size of the trap this file guards against.
    metastasis_location = ml |>
      dplyr::count(metastasis_location, mets_qualifier, mets_temporal_status, sort = TRUE) |>
      head(n) |> dplyr::collect(),
    # How usable is metastasis_dx_date really? Expect mostly null. The row that
    # matters is dx_date_type = 'exact' with dx_date_8digit = TRUE and
    # dx_date_calendar_ok = FALSE: a zero-filled partial such as '20090000',
    # which a format-only guard would have handed to the date parser.
    dx_date_type = ml |>
      dplyr::mutate(dx_date_8digit = dbplyr::sql("metastasis_dx_date RLIKE '^[0-9]{8}$'"),
                    dx_date_calendar_ok = dbplyr::sql(
                      paste0("metastasis_dx_date RLIKE '", NM_DXDATE_CAL_REGEX, "'"))) |>
      dplyr::count(metastasis_dx_date_type, dx_date_8digit, dx_date_calendar_ok, sort = TRUE) |>
      head(n) |> dplyr::collect(),
    # Orphan-key share, per table. Drives D_ORPHAN_KEY_MODE.
    mets_key_null = ml |>
      dplyr::mutate(key_null = is.na(neoplasm_histology_key) | neoplasm_histology_key == "") |>
      dplyr::count(key_null) |> dplyr::collect(),
    t = tnm |> dplyr::count(t, sort = TRUE) |> head(n) |> dplyr::collect(),
    n = tnm |> dplyr::rename(n_val = n) |> dplyr::count(n_val, sort = TRUE) |>
      head(n) |> dplyr::collect(),
    m = tnm |> dplyr::count(m, sort = TRUE) |> head(n) |> dplyr::collect(),
    # m_suffix has NEVER been dumped. D_M_SUBCATEGORY's second leg is unverified
    # until this returns.
    m_suffix = tnm |> dplyr::count(m, m_suffix, sort = TRUE) |> head(n) |> dplyr::collect(),
    t_suffix = tnm |> dplyr::count(t_suffix, sort = TRUE) |> head(n) |> dplyr::collect(),
    n_suffix = tnm |> dplyr::count(n_suffix, sort = TRUE) |> head(n) |> dplyr::collect(),
    # The AJCC DESCRIPTOR columns. These decide whether a record is a diagnosis
    # stage or a post-neoadjuvant restaging (y) or a recurrence (r), which in a
    # 2L cohort is not a rare corner. D_TNM_PREFIX filters on them and their
    # vocabulary has never been dumped - so dump it.
    t_prefix = tnm |> dplyr::count(t_prefix, sort = TRUE) |> head(n) |> dplyr::collect(),
    n_prefix = tnm |> dplyr::count(n_prefix, sort = TRUE) |> head(n) |> dplyr::collect(),
    m_prefix = tnm |> dplyr::count(m_prefix, sort = TRUE) |> head(n) |> dplyr::collect(),
    stage_prefix_tnm = tnm |> dplyr::count(stage_prefix, sort = TRUE) |> dplyr::collect(),
    stage = stg |> dplyr::count(stage, sort = TRUE) |> head(n) |> dplyr::collect(),
    stage_prefix = stg |> dplyr::count(stage_prefix, sort = TRUE) |> dplyr::collect()
  )
}

# Confirm the tumour-identification probes. These decide which tumour every
# stage and every metastasis row is attached to, so if they are wrong every
# number this file can produce is wrong.
#
# What is already known for this deployment ("proc and neoplasm.txt"):
# neoplasm_type = 'lung' has 13,275,346 rows and neoplasm_type IS NULL has
# 63,475,323 - the largest single value. So the anatomical probe is the bare
# word 'lung', and the NULL rows can only be recovered through `histology`.
# $neoplasm_type_null sizes that loss; $matched_by_lung_substrings shows what
# the two probes actually catch.
nm_neoplasm_type_scan <- function(con, n = 300) {
  nh <- mc_tbl(con, "onc_neoplasm_histology")
  all_types <- nh |>
    dplyr::count(neoplasm_type, neoplasm_qualifier, sort = TRUE) |> head(n) |> dplyr::collect()
  type_null <- nh |>
    dplyr::mutate(type_null = is.na(neoplasm_type) | neoplasm_type == "",
                  hist_null = is.na(histology) | histology == "") |>
    dplyr::count(type_null, hist_null) |> dplyr::collect()
  matched <- nh |>
    dplyr::filter(dbplyr::sql(nm_like_any("neoplasm_type", NM_LUNG_NEO_SUBSTR))) |>
    dplyr::count(neoplasm_type, sort = TRUE) |> head(n) |> dplyr::collect()
  matched_hist <- nh |>
    dplyr::filter(dbplyr::sql(nm_like_any("histology", NM_LUNG_HIST_SUBSTR))) |>
    dplyr::count(histology, sort = TRUE) |> head(n) |> dplyr::collect()
  hist_all <- nh |>
    dplyr::count(histology, sort = TRUE) |> head(n) |> dplyr::collect()
  list(all_neoplasm_types = all_types,
       neoplasm_type_null = type_null,
       matched_by_lung_substrings = matched,
       all_histology = hist_all,
       matched_by_histology_substrings = matched_hist)
}

# How much of t_diagnosis is in a vocabulary this file cannot decode? Sizes
# D_ICD_SNOMED honestly instead of pretending SNOMEDCT rows do not exist.
nm_icd_vocab_scan <- function(con) {
  mc_tbl(con, "diagnosis") |>
    dplyr::filter(diag_date <= NM_STUDY_END) |>
    dplyr::count(diagnosis_cd_type, sort = TRUE) |> dplyr::collect()
}

# Mode A vs mode C, for all three enriched tables. Mirrors the precedent's
# rdq1_stage_mode_impact(). REPORT ALL COLUMNS - mode A is the production
# default precisely because it is conservative, and the size of what it drops is
# a study limitation that has to be stated, not a parameter to tune until the
# number looks better.
#
# The metastatic-location branch goes through nm_mets_rows(), NOT through an
# inline re-filter of the table, so the orphan sizing and the production
# extraction count the same rows under every D_METS_TEMPORAL setting.
# mode_C_c80_strict repeats mode C with C80 treated as a competing primary
# (D_C80_PRIMARY's alternative), because that codelist choice moves the
# single-primary set and therefore moves the number that decides
# D_ORPHAN_KEY_MODE.
nm_orphan_impact <- function(con, ov = list(), fast = TRUE) {
  cmp <- function(x) if (fast) dplyr::compute(x) else x
  ov_strict <- ov; ov_strict[["D_C80_PRIMARY"]] <- "treat_c80_as_primary"
  base <- cmp(nm_note_pts(con) |> dplyr::semi_join(nm_eo_member_pts(con), by = "ptid"))

  one <- function(label, f) {
    a  <- cmp(f("A", ov)        |> dplyr::semi_join(base, by = "ptid"))
    cc <- cmp(f("C", ov)        |> dplyr::semi_join(base, by = "ptid"))
    cs <- cmp(f("C", ov_strict) |> dplyr::semi_join(base, by = "ptid"))
    n_a <- n_ptid(a); n_c <- n_ptid(cc); n_s <- n_ptid(cs)
    data.frame(table_name = label, mode_A_keyed_only = n_a,
               mode_C_plus_orphans = n_c, added_by_orphans = n_c - n_a,
               mode_C_c80_strict = n_s, lost_to_c80_rule = n_c - n_s,
               stringsAsFactors = FALSE)
  }

  rbind(
    one("t_onc_metastatic_location (actual only, via nm_mets_rows)",
        function(md, o) nm_mets_rows(con, "actual", mode = md, ov = o)),
    one("t_onc_tnm",
        function(md, o) nm_lung_attributed(con,
          mc_tbl(con, "onc_tnm") |> dplyr::filter(note_date <= NM_STUDY_END),
          mode = md, ov = o)),
    one("t_onc_stage",
        function(md, o) nm_lung_attributed(con,
          mc_tbl(con, "onc_stage") |> dplyr::filter(note_date <= NM_STUDY_END),
          mode = md, ov = o))
  )
}

# Population funnel for these variables specifically. The HAS_NOTES gate and EO
# membership are not incidental - they define who can have a site or a stage at
# all, and a patient who cannot is UNOBSERVED, not negative. The lung step is
# split so the neoplasm_type-NULL attrition (KNOWN LIMITS K) is visible: the
# anatomical probe alone versus the anatomical OR histology probe.
nm_population_funnel <- function(con, fast = TRUE) {
  cmp <- function(x) if (fast) dplyr::compute(x) else x
  all_pt <- cmp(mc_tbl(con, "patient") |> dplyr::distinct(ptid))
  notes  <- cmp(nm_note_pts(con))
  eo     <- cmp(notes |> dplyr::semi_join(nm_eo_member_pts(con), by = "ptid"))
  neo_type_only <- cmp(eo |> dplyr::semi_join(
    mc_tbl(con, "onc_neoplasm_histology") |>
      dplyr::filter(dbplyr::sql(nm_like_any("neoplasm_type", NM_LUNG_NEO_SUBSTR)),
                    neoplasm_qualifier == "actual") |>
      dplyr::distinct(ptid), by = "ptid"))
  lung   <- cmp(eo |> dplyr::semi_join(nm_lung_neo_keys(con), by = "ptid"))
  mets   <- cmp(lung |> dplyr::semi_join(
    nm_mets_rows(con, "actual", mode = "A"), by = "ptid"))
  stage  <- cmp(lung |> dplyr::semi_join(
    nm_lung_attributed(con, mc_tbl(con, "onc_tnm") |>
      dplyr::filter(note_date <= NM_STUDY_END), mode = "A"), by = "ptid"))
  data.frame(
    step = c("all patients", "has_notes = Y", "+ EO record",
             "+ lung neoplasm_type only", "+ lung neoplasm_type OR histology",
             "+ >=1 actual mets row (mode A)", "+ >=1 TNM row (mode A)"),
    n = c(n_ptid(all_pt), n_ptid(notes), n_ptid(eo), n_ptid(neo_type_only),
          n_ptid(lung), n_ptid(mets), n_ptid(stage)),
    stringsAsFactors = FALSE)
}

# ---------------------------------------------------------------------------
# Offline self-test. No connection, no warehouse. It checks the two things that
# can be checked without data: (i) the parsers behave on the tokens the observed
# distributions actually contain, and (ii) NOTHING IN THE R-SIDE REDUCERS DIES
# ON ZERO ROWS. Zero rows is the single most likely first-run outcome - mode A
# drops the orphan rows, and the tumour probes are probes - and meeting it with
# a stack trace instead of an empty frame wastes the run.
# ---------------------------------------------------------------------------
# Exact check count: a deleted chk() must not look like a smaller passing run.
NM_SELFTEST_EXPECTED <- 26L
nm_selftest <- function() {
  chk <- function(name, expr) {
    ok <- tryCatch({ force(expr); TRUE }, error = function(e) structure(FALSE, msg = conditionMessage(e)))
    data.frame(check = name, pass = isTRUE(ok),
               detail = if (isTRUE(ok)) "" else attr(ok, "msg") %||% "failed",
               stringsAsFactors = FALSE)
  }
  eq <- function(a, b) if (!identical(a, b)) stop("expected ", paste(b, collapse = ","),
                                                  " got ", paste(a, collapse = ",")) else TRUE

  empty_sites <- data.frame(ptid = character(0), metastasis_location = character(0),
                            site_group = character(0), first_mets_date = as.Date(character(0)),
                            mets_qualifier = character(0), stringsAsFactors = FALSE)
  empty_absent <- data.frame(ptid = character(0), metastasis_location = character(0),
                             site_group = character(0), first_absent_date = as.Date(character(0)),
                             mets_qualifier = character(0), stringsAsFactors = FALSE)
  sites1 <- data.frame(ptid = c("P1", "P1", "P1"),
                       metastasis_location = c("bone", "soft tissue", "skin"),
                       first_mets_date = as.Date(c("2020-01-01", "2020-02-01", "2020-03-01")),
                       mets_qualifier = rep("actual", 3), stringsAsFactors = FALSE)
  sites1$site_group <- nm_site_group(sites1$metastasis_location)
  absent1 <- data.frame(ptid = "P1", metastasis_location = "rib",
                        site_group = nm_site_group("rib"),
                        first_absent_date = as.Date("2020-04-01"),
                        mets_qualifier = "absent", stringsAsFactors = FALSE)
  empty_tnm <- data.frame(ptid = character(0), note_date = as.Date(character(0)),
                          stringsAsFactors = FALSE)
  empty_stg <- empty_tnm
  temporal2 <- data.frame(ptid = c("P1", "P1"), mets_temporal_status = c("current", "history"),
                          stringsAsFactors = FALSE)

  rbind(
    chk("nm_site_map_lint", nm_site_map_lint()),
    chk("nm_icd_list_lint", nm_icd_list_lint()),
    chk("nm_like_any fails closed", eq(nm_like_any("x", character(0)), "(1 = 0)")),
    chk("nm_code_prefix_sql fails closed", eq(nm_code_prefix_sql("x", NULL), "(1 = 0)")),
    chk("stage 'is' is not stage 1", eq(nm_stage_parse("is")$stage_class, "in_situ")),
    chk("stage 'iiia' parses", eq(nm_stage_parse("iiia")$stage_group, "3")),
    chk("stage 'iiae' is ann-arbor", eq(nm_stage_parse("iiae")$stage_class, "ann_arbor_like")),
    chk("stage 'advanced' is not IV", eq(nm_stage_parse("advanced")$stage_group, NA_character_)),
    chk("stage '2 of 3 nodes' is not stage 2",
        eq(nm_stage_parse("2 of 3 nodes")$stage_group, NA_character_)),
    chk("stage '5' is out of range", eq(nm_stage_parse("5")$stage_class, "out_of_range_numeric")),
    chk("M1c parses (ajcc8 era)",
        eq(nm_m1_subcategory("1c", "", as.Date("2020-01-01"))$m1_subcategory, "M1c")),
    chk("M1b collapses pre-2017",
        eq(nm_m1_subcategory("1b", "", as.Date("2014-01-01"))$m1_subcategory, "M1_NOS")),
    chk("m suffix leg", eq(nm_m1_subcategory("1", "b", as.Date("2020-01-01"))$m1_subcategory, "M1b")),
    chk("unmapped sites counted separately",
        eq(nm_mets_summary(sites1)$summary$n_met_sites, 3L)),
    chk("unmapped sites reported",
        eq(nrow(nm_mets_summary(sites1)$unmapped), 2L)),
    chk("compartment evidence is one row per compartment",
        eq(nrow(nm_mets_evidence(sites1, absent1)$by_compartment[
              nm_mets_evidence(sites1, absent1)$by_compartment$site_group == "bone", ]), 1L)),
    chk("bone stays positive against an absent rib",
        eq(nm_mets_evidence(sites1, absent1)$by_compartment$status[
             nm_mets_evidence(sites1, absent1)$by_compartment$site_group == "bone"], "positive")),
    chk("nm_mets_evidence on zero rows", nm_mets_evidence(empty_sites, empty_absent)),
    chk("nm_mets_summary on zero rows", nm_mets_summary(empty_sites)),
    chk("nm_mets_summary rejects evidence frames",
        tryCatch({ nm_mets_summary(nm_mets_evidence(sites1, absent1)$by_location); stop("no guard") },
                 error = function(e) if (grepl("status", conditionMessage(e))) TRUE else
                   stop(conditionMessage(e)))),
    chk("nm_stage_reduce zero rows at_diagnosis",
        nm_stage_reduce(empty_tnm, empty_stg, NULL, "at_diagnosis")),
    chk("nm_stage_reduce zero rows ever",
        nm_stage_reduce(empty_tnm, empty_stg, NULL, "ever_pre_index")),
    chk("both bases return the same columns",
        eq(names(nm_stage_reduce(empty_tnm, empty_stg, NULL, "at_diagnosis")),
           names(nm_stage_reduce(empty_tnm, empty_stg, NULL, "ever_pre_index")))),
    # every registered D_METS_TEMPORAL value keeps exactly the statuses it names
    chk("D_METS_TEMPORAL current_and_history", eq(nm_temporal_filter(temporal2, "current_and_history")$mets_temporal_status,
                                                  c("current", "history"))),
    chk("D_METS_TEMPORAL current_only", eq(nm_temporal_filter(temporal2, "current_only")$mets_temporal_status, "current")),
    chk("D_METS_TEMPORAL history_only", eq(nm_temporal_filter(temporal2, "history_only")$mets_temporal_status, "history"))
  )
}

# ============================================================================
# 12. RUN BLOCK
#
# `Rscript nsclc_mets_stage.R` runs the OFFLINE SELF-TEST and then the
# VALIDATION path only - the vocabulary scans, the tumour probes, the orphan
# sizing and the population funnel - because no derived variable in this file
# may be believed before those have been read by a human. It deliberately does
# NOT build the modelling variables: nm_mets_summary() and nm_stage_at_index()
# need index_dates from nsclc_lot.R's 2L docetaxel selection, which is a
# separate, reviewed step. It also does NOT run nm_icd_mets_proxy(), which now
# requires an explicit population.
#
# When source()d instead, this block does nothing (sys.nframe() is 0 only as the
# top-level script). Set NM_SCAN_ROWS to change the head() depth.
# ============================================================================

if (sys.nframe() == 0L && !interactive()) {
  cat("\n== Offline self-test (parsers + zero-row reducers) ==\n")
  st <- nm_selftest()
  print(st, row.names = FALSE)
  if (nrow(st) != NM_SELFTEST_EXPECTED || !all(st$pass))
    stop("nm_selftest(): ", sum(!st$pass), " check(s) failed / ", nrow(st), " of ",
         NM_SELFTEST_EXPECTED, " ran - fix before querying.")

  cat("\n== NM_DECISIONS (paste into the SAP appendix) ==\n")
  print(nm_decision_register()[, c("decision_id", "wired", "value", "alternative")],
        row.names = FALSE)
  cat("\nwired = FALSE means the choice is hard-coded in the named function:",
      "\nediting NM_DECISIONS will NOT change it.\n")

  cat("\n== Flatiron vs Optum, per variable ==\n")
  print(nm_compare_to_flatiron()[, c("variable", "advN_prognostic", "flatiron_status",
                                     "optum_function")], row.names = FALSE)

  con <- mc_connect()
  nrow_scan <- as.integer(Sys.getenv("NM_SCAN_ROWS", "300"))

  cat("\n== Population funnel ==\n")
  print(nm_population_funnel(con), row.names = FALSE)

  cat("\n== Orphan-key impact (mode A vs mode C, and the C80 rule) ==\n")
  print(nm_orphan_impact(con), row.names = FALSE)

  cat("\n== tumour probes (CONFIRM NM_LUNG_NEO_SUBSTR / NM_LUNG_HIST_SUBSTR FIRST) ==\n")
  nts <- nm_neoplasm_type_scan(con, n = nrow_scan)
  for (k in names(nts)) {
    cat("\n-- ", k, " --\n", sep = "")
    print(head(nts[[k]], 40), row.names = FALSE)
  }

  cat("\n== Vocabulary scan ==\n")
  vs <- nm_vocab_scan(con, n = nrow_scan)
  for (k in names(vs)) {
    cat("\n-- ", k, " --\n", sep = "")
    print(head(vs[[k]], 40), row.names = FALSE)
  }

  cat("\n== t_diagnosis code vocabularies (SNOMEDCT share is UNDECODED here) ==\n")
  print(nm_icd_vocab_scan(con), row.names = FALSE)

  cat("\nRun complete. Nothing above is a study result - it is the evidence needed\n",
      "to decide whether the mappings in this file are correct.\n", sep = "")
}

# ============================================================================
# Known limits, provenance, and what has never been run: ../METHODS.md
# ============================================================================
