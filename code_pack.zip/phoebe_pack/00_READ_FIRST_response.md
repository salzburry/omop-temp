# Response — the 18 covariates, and Optum feasibility

> **Status.** Offline tests pass. **No study-specific cohort, feasibility-funnel or engine query
> has run** against Flatiron or Optum, so no sample size can be stated. Interim response, not the
> completed feasibility deliverable — the eligible sample size and per-variable availability in the
> 2L docetaxel cohort are still to be produced. Nothing below is SME-signed.

## 1. The 18 covariates — sound set, three changes

**Eight carry real evidence.** Counting publications where a factor was prognostic *and*
multivariable-significant for OS *and* in an advanced/metastatic cohort (`advN`):

| advN | Covariate |
|---|---|
| 6 · 5 · 4 | Sex · ECOG · Histology |
| 3 · 3 | Age · Albumin |
| 2 · 2 · 2 | Overall stage · Race · ALP |

The other ten sit at ≤ 1. Keep them — but as **prediction inputs, not evidence-tier prognostic
factors**. The slide shouldn't read as evidence-ranked.

**Reclassify one.** *Smoking status* — 24 publications, every advanced-setting multivariable
estimate null. That is weak evidence for a *prognostic* claim, but weak univariable evidence alone
is not grounds to exclude a prespecified covariate; treat it as a descriptive / candidate variable
pending the statistician's prespecified review rather than dropping it outright.

**Add three.**

| Add | Why |
|---|---|
| **Number of metastatic sites** | Evidence equal to stage and race; **not** captured by initial overall stage. In REVEL's own baseline table. Flatiron has no metastasis field — only a raw ICD proxy. |
| **Neutrophil count** | Stronger evidence than NLR, which currently absorbs it. The ratio hides the better signal. |
| **Time since prior line of therapy** (<9 vs ≥9 mo) | A REVEL baseline field; one of only two factors MV-significant in the REVEL refractory analysis. **Unresolved** — its anchor (start vs end of prior line) and calculation are not yet specified, and it may be `time_1l_to_index` at a different cut. Specify before adopting. |

**Fix four parameterisations.**

- **Stage means the wrong thing.** Flatiron holds stage at *initial* diagnosis, not restaged at
  the 2L index — so it reads as de-novo vs recurrent. A coefficient fitted on it will not
  transfer to a trial's entry stage. Label it that way or drop it.
- **ECOG** — don't collapse 2/3/4, and keep Unknown separate from Missing, until the distribution
  is seen. The numeric codebook is asserted from a spec we don't hold; a one-position offset
  would silently reclassify every ECOG 1 patient.
- **Race** — both supporting results are the Asian/Other-vs-White contrast, not White-vs-rest.
- **PD-L1** — currently blends two time-attribution methods, making the variable
  patient-dependent. Pick one as primary.

**One thing to decide before fitting.** Eight of the ten strongest covariates are collected in
REVEL- and LUME-style trials under eligibility restrictions that truncate their range — how much
prognostic signal survives is an empirical question, not a foregone conclusion: LUME-Lung 1 enrolled **one** PS-2 patient of
1314, so in-trial ECOG is effectively binary; stage is 100% IV in REVEL; the organ-function labs
are range-truncated by screening gates, so RWD-fitted slopes will be steeper than what survives
in-trial. This bounds what covariate adjustment can deliver.

## 2. Optum — not answerable yet

No cohort count, attrition funnel or completeness table exists, because no study query has run.

**Metastatic sites: Optum has a curated field; Flatiron has only an ICD proxy — but it *is* a
proxy, and the same one exists in Optum.** This is the clearest source difference, stated precisely:

| | Flatiron | Optum |
|---|---|---|
| Curated field | **None** among the 226 delivered columns (the `met*` columns are the MET oncogene). | `t_onc_metastatic_location` — a note-derived site vocabulary (Enriched Oncology) |
| ICD proxy | **Yes** — raw `Diagnosis` table, ICD-10 C77–C79 / ICD-9 196–198. The dictionary's own example row is *"Secondary malignant neoplasm of bone"*. Never queried. | **Yes** — `t_diagnosis`, same codes. |
| Values seen | — (raw table never queried) | curated: bone, liver, lung, brain, pleura, peritoneum, chest, rib, vertebral column, pancreas, thyroid, intra-abdominal organs |
| Negation | Impossible in ICD | Curated layer only: `mets_qualifier = absent` — the note said **no** metastasis at that site |
| M substaging | None | `t_onc_tnm` (a separate table): M1a / M1b / M1c present in live distributions |

So the honest comparison is **ICD proxy on both sources, with Optum adding a curated layer on top**.
One codelist serves both — the engine already carries it — with one trap: Flatiron stores codes
*with* the decimal (`198.5`), Optum *without* (`C349`). The ICD proxy gives site presence with
reasonable granularity (bone, liver, brain, adrenal, pleura, lung, peritoneum, nodes); what it
cannot give is negation, a current-vs-history distinction, or coding completeness.

Four caveats travel with that yes. It is **distant sites only** — the vendor excludes local and
nodal invasion, so the count won't match a definition that includes nodal spread; rule on that
before counting. It is **notes-gated** (Enriched Oncology, physician notes required). The values
above are a deployment-wide sample and say **nothing about fill rate for lung patients** — that is
the first query to run. And in the *TNM* table ~70% of rows carry no tumour key; the metastatic-location table's key
completeness is unmeasured — attributing a site to the lung primary rather than a second cancer
is the largest single uncertainty on either source.

Four further findings that change the approach:

1. **ECOG is vendor-documented** (an earlier assessment wrongly called it unavailable). One
   `DISTINCT obs_type` scan would confirm the literal — and covers BMI, BP, smoking and alcohol
   at the same time. It would **not** establish fill rate for a lung cohort, which is the number
   that decides usability.
2. **A second lab source exists** (`t_clm_lab_results`), never considered. Albumin, ALP and
   haemoglobin are reopened, not settled.
3. **`LOT = 2` is not a safe cohort filter.** Optum's line table is procedure-only, so oral-TKI
   1L is invisible and a true-2L docetaxel patient is numbered LOT 1. LOT numbers also repeat
   within a patient, inflating any naive count. Define 2L explicitly.
4. **The blocker is ~50 missing lookup value lists**, not missing tables. All 52 deployed tables
   are documented, but the lists defining membership sit in a vendor workbook we don't hold —
   leaving 30+ variables with a known container and no writable `WHERE` clause. Requesting it has
   the longest lead time.

**Gates, in order** — no sample-size claim before these: confirm access, schema, the notes gate
and docetaxel identifiers → define 2L and monotherapy explicitly → attrition funnel →
docetaxel-exposed / 2L / monotherapy / eligible / complete-case counts reported separately →
profile availability and completeness for all 18 plus the three additions → compare derived LOT
against the vendor table by failure mechanism.

**Worth deciding early:** protocol 308769 §4 names **Flatiron only** and its limitations are
written entirely around Flatiron, yet roughly half this effort targets Optum. Whether Optum is
admissible is a question for the protocol owner, and cheaper to answer now than after the
covariate work is funded.

---

*Backing files:* `prognostic_variable_identification.csv` (Part 1) ·
`variable_presence_matrix.csv` (Part 2) · `../../optum_mc_reference/verified/` (52-table Optum
catalogue) · `../sql/check_metastatic_sites.sql` — Part A an Optum smoke test, **Part B the real
Flatiron feasibility query**: 2L docetaxel cohort, index date, attrition funnel, eligible N and
pre-index site availability from ICD ·
`../R/nsclc_lot.R` (cohort and lines), `../R/nsclc_mets_stage.R` (sites and stage), `../tests/`,
`../METHODS.md`. Longer working documents
were removed as intermediate; they remain in git history.
