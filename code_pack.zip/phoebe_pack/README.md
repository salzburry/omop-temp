# Phoebe's two asks — the pack

**Read `00_READ_FIRST_response.md`.** Everything else here is what backs it.

| | |
|---|---|
| `00_READ_FIRST_response.md` | The answer. Part 1 the 18 covariates, Part 2 Optum feasibility. ~1 page. |
| `queries/check_metastatic_sites.sql` | **Part B is the one to run.** Flatiron, real 2L docetaxel cohort with an index date: attrition funnel, eligible N, pre-index metastatic sites from ICD. Part A is an Optum smoke test. Neither has been run — no warehouse credentials. |
| `evidence/prognostic_variable_identification.csv` | Every candidate variable with its evidence count (`advN`). Backs Part 1. |
| `evidence/variable_presence_matrix.csv` | What we have actually *observed* on each source vs. only documented. Backs Part 2. |
| `evidence/optum_52_table_catalogue.md` | The 52 tables in the Optum deployment, read from the vendor PDFs. |
| `evidence/optum_table_inventory.csv` | Per-table columns and vocabularies. |
| `code/` | The LOT and metastasis/stage engines, the drug list they read, and their known limits. |

## The two answers in three lines

1. **The 18 are a sound set.** Eight carry real evidence (advN ≥ 2); the rest are prediction
   inputs, not evidence-tier. Add metastatic-site count and neutrophils; specify the
   time-since-prior-line anchor before adding it; reclassify smoking as descriptive.
   Fix four parameterisations — stage, ECOG, race, PD-L1.
2. **Optum feasibility is not yet answerable** — no study-specific query has run, so there is no
   eligible N. Run `queries/` Part B first: it produces the funnel and the N on Flatiron.
3. **Metastatic sites:** an ICD proxy exists on **both** sources; Optum adds a curated layer with
   negation (`mets_qualifier = 'absent'`) that ICD can never express.

## Two things that will bite

- **ICD decimals differ by source.** Flatiron stores `198.5` / `C79.51`; Optum stores `1985` /
  `C7951`. One codelist, two matching rules.
- **Nothing here is SME-signed.** `SME_decision` is empty on all 154 inventory rows — the 18, the
  proposed additions, and every candidate.
