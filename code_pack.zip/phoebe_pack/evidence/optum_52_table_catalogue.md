# Optum Market Clarity — the complete deployment table catalogue (verified)

**Source.** `source_pdfs/optum data location.pdf`, pages 1–5, read as rendered images.
Databricks Catalog Explorer → `hive_metastore` → `clnprw_optum_mc_full_use`, filtered to `2025q4`.
The page header states **52 tables**. All 52 are listed below; the five screenshots overlap and
together cover the list with no gap.

**Why this file exists.** Two prior errors both trace to not having read this page:

1. The OCR text in `extracted_text/optum_data_location.txt` mangles table names
   (`t_cln1_rx`, `t_clrn_lab_results`, `t_onc_evaluation_systern`, `t_n/p_sqs_fqm`) and its
   header OCRs ambiguously as "52" or "82". Read from the image it is unambiguously **52**.
2. `rdq_query_outputs/varlist.txt` is a **14-table** `DESCRIBE` sample, not the catalogue.
   Concluding a capability is absent because it is missing from those 14 is invalid — they are
   14 of 52.

---

## The 52 tables

### Enriched Oncology — note-derived, `HAS_NOTES='Y'` patients only (20)

| Table | Bears on |
|---|---|
| `t_onc_biomarker_2025q4` | PD-L1, EGFR, ALK and the rest of the panel |
| `t_onc_characteristic_2025q4` | tumour characteristics |
| `t_onc_evaluation_system_2025q4` | evaluation/scoring systems |
| `t_onc_grade_2025q4` | tumour grade |
| `t_onc_histology_seer_2025q4` | SEER-coded histology |
| `t_onc_line_of_therapy_2025q4` | **LOT-A**, the native Optum line assignment |
| `t_onc_lymph_node_2025q4` | nodal involvement |
| `t_onc_margin_2025q4` | surgical margins |
| `t_onc_medications_2025q4` | **LOT-B** input |
| `t_onc_metastatic_location_2025q4` | **metastatic site and count** |
| `t_onc_neoplasm_histology_2025q4` | histology, neoplasm type |
| `t_onc_problem_2025q4` | oncology problem list |
| `t_onc_progression_2025q4` | **progression** |
| `t_onc_stage_2025q4` | AJCC group stage |
| `t_onc_tnm_2025q4` | **T, N, M with subdivisions** |
| `t_onc_treatment_response_2025q4` | **response to prior/1L therapy** |
| `t_onc_tumor_size_2025q4` | **tumour size** |

### Structured EHR (14)

`t_administrations` · `t_biomarker` · `t_carearea` · `t_contraindications` · `t_diagnosis` ·
`t_drug_rat` · `t_enc_provider` · `t_encounter` · `t_immunization` · `t_lab` · `t_microbiology` ·
`t_observation` · `t_prescription` · `t_procedure`

### Legacy mention-based NLP (4)

`t_nlp_measure` · `t_nlp_sds` · `t_nlp_sds_fam` · `t_nlp_targeted`

### Claims (9)

`t_clm_co_enrollment` · `t_clm_derived_enrollment` · `t_clm_inpat_confinement` ·
`t_clm_lab_results` · `t_clm_med_diagnosis` · `t_clm_med_procedure` · `t_clm_med_services` ·
`t_clm_member_detail` · `t_clm_provider` · `t_clm_rx`

### Patient / administrative (8)

`t_insurance` · `t_pat_obs_time` · `t_patient` · `t_patrep` · `t_provider` · `t_vis_rel` ·
`t_visit`

---

## Tables that appear in NO response document

These were never considered when covariate feasibility was assessed, and several are directly
relevant to variables we had written off:

| Table | Why it matters |
|---|---|
| **`t_onc_tumor_size_2025q4`** | Tumour size. `01`/`07` both call tumour diameter and blSLD unavailable in **either** source and name blSLD "the score's hard ceiling". That conclusion must be re-tested. Tumour size is not identical to a RECIST sum of longest diameters, but it is not nothing. |
| **`t_onc_treatment_response_2025q4`** | Response to prior/1L therapy — advN = 1, collected in **both** REVEL and LUME-Lung 1. `02` §7 records its Flatiron fields as undocumented and says Optum "has nothing". A dedicated table exists. |
| **`t_onc_progression_2025q4`** | Progression — bears on time-to-progression intervals and the `time_1l_to_index` family. |
| **`t_observation_2025q4`** | The Optum dictionary states measurements should use **observation first**, NLP measure second. This is the primary ECOG candidate and the likely home of vitals and BMI. |
| **`t_nlp_measure_2025q4`** | The dictionary names ECOG explicitly: *"captures scales and scores for disease such as ECOG, EDSS and GCS"*. |
| `t_onc_evaluation_system_2025q4` | Scoring systems — a second performance-status candidate. |
| `t_onc_grade_2025q4`, `t_onc_histology_seer_2025q4`, `t_onc_characteristic_2025q4`, `t_onc_margin_2025q4`, `t_onc_problem_2025q4` | Unexamined oncology detail. |
| `t_visit`, `t_encounter`, `t_pat_obs_time` | Observation-time denominators, needed for any missingness or follow-up analysis. |

---

## What this does and does not establish

**Does:** these 52 tables exist in the deployment we have access to. That is tier-B evidence —
the field/table is confirmed present.

**Does not:** say anything about column names, fill rates, vocabularies, or whether any given
analyte or measurement is populated for lung patients. No query behind this file has been run.
`t_onc_tumor_size` existing does not mean it holds a RECIST sum of diameters, and
`t_nlp_measure` existing does not mean ECOG is populated at usable rates for our cohort.

Every `t_onc_*` table carries the `HAS_NOTES='Y'` cohort restriction, which is a real
selection, not a filter we chose.
