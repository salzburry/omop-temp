#!/usr/bin/env Rscript
# Real-data frequencies for the shapes the LOT rules turn on.
#
#   # list the counts this will run; no connection, touches nothing
#   Rscript run_lot_audit_counts.R
#
#   # run them
#   DATABRICKS_PWD=... DOMINO_USER_NAME=usr00000 OBJECT_PREFIX=ndmm_ \
#     INPUT_COHORT_TABLE=ndmm_NDMM_COHORT \
#     AUDIT_EXECUTE=TRUE Rscript run_lot_audit_counts.R
#
# Read-only. Every statement is a SELECT; nothing is written to the warehouse.
# Results print as a table and land in out/lot_audit_counts.csv.
#
# Any synthetic figure quoted under `expect` is a shape, not a prevalence. The
# numbers this script produces against a finished build are the quotable ones.
#
# AUDIT_TABLE picks which line table to count. It defaults to LOT_LONG, which is
# line assignment on its own; LOT_LONG_FINAL additionally applies the line
# criteria, so counting it mixes assignment behaviour with cohort exclusions.
# Run both only if that comparison is what you want.

.script_dir <- local({
  a <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  # Rscript renders a space in a path as ~+~, so a folder with one in its name
  # resolves to nothing without this.
  if (length(a)) dirname(normalizePath(gsub("~+~", " ", sub("^--file=", "", a[1]),
                                            fixed = TRUE))) else getwd()
})
LOT_ROOT <- normalizePath(file.path(.script_dir, "..", "..", "lot", "engine"), mustWork = TRUE)
out_dir  <- file.path(.script_dir, "out")
env_flag <- function(nm) identical(toupper(trimws(Sys.getenv(nm, unset = ""))), "TRUE")

# One entry per count. `sql` is a glue template over the table names below.
# `expect` says what the number should look like, so a wildly different one is
# noticeable rather than silently accepted.
AUDIT_COUNTS <- list(
  # 1. Regimen agents with no supply inside their own line.
  #
  #    04_lot1_base.R and 10_lot2_5_base.R cut the regimen window at
  #    REGIMEN_CUTOFF_DT, so a line stops collecting drugs at the transplant
  #    that ended it. This count checks that against claims: an agent named in
  #    LOT_BASE_MEDS whose supply does not reach inside the line.
  #
  #    TWO shapes, split rather than added, because they are different
  #    questions. "No episode STARTS inside the line" and "the agent is not
  #    covered inside the line at all" differ, and only the second is
  #    stranding. An agent whose episode began before the line and runs into it
  #    was given during the line. The build gathers a regimen only from
  #    episodes starting at or after the line start, so shape b should be
  #    empty. A shape b row points at the criteria layer moving line ends, not
  #    at the regimen window.
  list(id = "regimen-agent-begins-after-line-end",
       what = "Lines naming a regimen agent that has no supply episode starting inside the line, split by whether it was covered at all",
       expect = "both shapes should be empty",
       sql = "
      WITH exploded AS (
        SELECT l.PATID, l.LOT_NUM, l.LOT_START_DT, l.LOT_BASE_END_DT,
               explode(split(l.LOT_BASE_MEDS, ' ')) AS MED_ABBR
        FROM {t$long} l
        WHERE coalesce(trim(l.LOT_BASE_MEDS), '') <> ''
      ),
      offending AS (
        SELECT DISTINCT e.PATID, e.LOT_NUM, e.MED_ABBR,
               CASE WHEN EXISTS (SELECT 1 FROM {t$map} m
                                 WHERE m.PATID = e.PATID
                                   AND m.MAP_MED_TYPE = e.MED_ABBR
                                   AND m.MAP_START_DT <= e.LOT_BASE_END_DT
                                   AND m.MAP_END_DT   >= e.LOT_START_DT)
                    THEN 'b. covered by an episode that began before the line'
                    ELSE 'a. no cover inside the line at all - stranded'
               END AS SHAPE
        FROM exploded e
        WHERE e.MED_ABBR <> ''
          AND NOT EXISTS (SELECT 1 FROM {t$map} m
                          WHERE m.PATID = e.PATID
                            AND m.MAP_MED_TYPE = e.MED_ABBR
                            AND m.MAP_START_DT BETWEEN e.LOT_START_DT
                                                   AND e.LOT_BASE_END_DT)
      )
      SELECT SHAPE,
             count(*)                                   AS N_AGENT_LINE_PAIRS,
             count(DISTINCT concat_ws('|', PATID, LOT_NUM)) AS N_LINES,
             count(DISTINCT PATID)                       AS N_PATIENTS
      FROM offending GROUP BY 1 ORDER BY 1"),

  # 1b. Processed autologous transplants that sit inside no line at all.
  #
  #     Counted from the transplants, not from the lines. auto_cand refuses a
  #     transplant a line of its own when it lands within sct_tandem_days of the
  #     one before it AND the earlier transplant was inside its line's window.
  #     Without that second condition a pair no line ever held would leave the
  #     later transplant owned by nothing, and LOT_LONG clamps the AUTO columns
  #     to the span, so it would not show on the published row either.
  #
  #     Shape b is the one to read. Shape c - a transplant trailing the last
  #     line once max_lot is used up - is a reconciliation number, not a defect,
  #     so it is reported separately.
  list(id = "transplant-belonging-to-no-line",
       what = "Processed autologous transplants inside no line, split by whether a line was still available",
       expect = "shape b should be empty; shape c is a reconciliation number",
       sql = "
      WITH unowned AS (
        SELECT x.PATID, x.TX_DT,
               (SELECT count(*) FROM {t$long} c WHERE c.PATID = x.PATID) AS N_LINES,
               (SELECT max(c.LOT_BASE_END_DT) FROM {t$long} c WHERE c.PATID = x.PATID) AS LAST_END
        FROM {t$auto} x
        WHERE EXISTS (SELECT 1 FROM {t$long} c WHERE c.PATID = x.PATID)
          AND x.TX_DT >= (SELECT min(c.LOT_START_DT) FROM {t$long} c
                           WHERE c.PATID = x.PATID)
          AND NOT EXISTS (SELECT 1 FROM {t$long} l
                           WHERE l.PATID = x.PATID
                             AND x.TX_DT BETWEEN l.LOT_START_DT AND l.LOT_BASE_END_DT)
      )
      SELECT CASE WHEN TX_DT <= LAST_END THEN 'a. in a gap between two lines'
                  WHEN N_LINES < {max_lot} THEN 'b. after the last line, with lines still available - THE ONE TO WATCH'
                  ELSE 'c. after the last line at the cap - a reconciliation number, not a defect'
             END                     AS SHAPE,
             count(*)                AS N_TRANSPLANTS,
             count(DISTINCT PATID)   AS N_PATIENTS
      FROM unowned GROUP BY 1 ORDER BY 1"),

  # 1c. The same population, counted from the PAIRS.
  #
  #     A tandem whose first transplant sits outside its line's window is a pair
  #     no line ever held. This bounds how many patients the ownership condition
  #     in auto_cand can decide.
  #
  #     The gap alone does not make a pair a tandem. 05b_lot1_sct.R also
  #     requires that nothing happens strictly between the two transplants - no
  #     non-steroid medication starting, no allogeneic transplant, no CAR-T. A
  #     pair with something in between is not a planned tandem, so counting it
  #     here would over-state the population. The condition is the engine's
  #     own, spliced from the same three sources tandem_interrupt_events_sql()
  #     reads.
  list(id = "tandem-pair-whose-first-transplant-is-out-of-window",
       what = "Uninterrupted AUTO pairs within sct_tandem_days whose earlier transplant fell outside its line's window",
       expect = "bounds the patients the ownership condition decides. On 600 synthetic patients: 5 pairs at LOT1, 4 of them out of window",
       sql = "
      WITH paired AS (
        SELECT PATID, TX_DT,
               lag(TX_DT) OVER (PARTITION BY PATID ORDER BY TX_DT) AS PREV_TX_DT
        FROM {t$auto}
      ),
      interrupts AS (
        SELECT PATID, MAP_START_DT AS dt FROM {t$map}
        WHERE MAP_MED_CLASS <> 'STEROID'
        UNION ALL
        SELECT PATID, TX_DT AS dt FROM {t$allo}
        WHERE SCT_TYPE IN ('ALLO', 'CART')
      ),
      uninterrupted AS (
        SELECT p.*
        FROM paired p
        WHERE p.PREV_TX_DT IS NOT NULL
          AND NOT EXISTS (SELECT 1 FROM interrupts x
                          WHERE x.PATID = p.PATID
                            AND x.dt > p.PREV_TX_DT
                            AND x.dt < p.TX_DT)
      ),
      owning AS (
        SELECT p.PATID, p.TX_DT, p.PREV_TX_DT, l.LOT_NUM,
               l.LOT_START_DT, l.LOT_START_TYPE
        FROM uninterrupted p
        INNER JOIN {t$long} l
          ON l.PATID = p.PATID
         AND p.PREV_TX_DT BETWEEN l.LOT_START_DT AND l.LOT_BASE_END_DT
        WHERE datediff(p.TX_DT, p.PREV_TX_DT) <= {tandem_days}
      )
      SELECT LOT_NUM,
             count(*)              AS N_PAIRS,
             count(DISTINCT PATID) AS N_PATIENTS,
             sum(CASE WHEN PREV_TX_DT > date_add(LOT_START_DT,
                   CASE LOT_START_TYPE WHEN 'SCT_ALLO' THEN 0
                                       WHEN 'CART' THEN {cart_days} - 1
                                       WHEN 'MED' THEN CASE WHEN LOT_NUM = 1
                                              THEN {lot1_window} - 1
                                              ELSE {lotn_window} - 1 END
                                       ELSE {lotn_window} - 1 END)
                  THEN 1 ELSE 0 END) AS N_FIRST_OUT_OF_WINDOW
      FROM owning GROUP BY LOT_NUM ORDER BY LOT_NUM"),

  # 1d. Post-run-out transplants that the guard treats as tandem partners.
  #
  #     Two places read the tandem rule: auto_cand, which decides whether an
  #     AUTO opens the next line, and the two post-run-out guards, which decide
  #     whether a run-out counts as a confirmed discontinuation. Both carry the
  #     ownership condition. If they disagreed, a guard would decline to confirm
  #     a run-out on account of a tandem the next-line gate had ruled was not
  #     one, and the line would run on and absorb the transplant instead of
  #     ending and letting the next line open on it.
  #
  #     The shape counted: a transplant after a line's run-out, within
  #     sct_tandem_days of the one before it, where THAT earlier transplant fell
  #     outside the line's window.
  #
  #     RUN-OUT, not the line's final end. They are different dates in both
  #     directions - an add-med or a death ends a line before its regimen runs
  #     out, and an unconfirmed run-out leaves the line censored at the end of
  #     observation long after it - and only the run-out is what the guard is
  #     about.
  #
  #     LOT_LONG carries no run-out column, so it is rebuilt here the way
  #     discon_per_med and discon_raw build it: per regimen agent, chain the
  #     agent's episodes forward from the line start and stop at the one after
  #     a confirmed gap - MAP_DISCON_FLG sits on the episode BEFORE the gap, so
  #     the lag is what tells an episode it is a restart - then take the last
  #     cover reached across the agents. Without the discon break the proxy
  #     lands on the last refill however long the patient has been off the drug,
  #     which is far too late.
  #
  #     Three differences from the engine's run-out remain, so this is a shape
  #     count and not a verdict: the engine's chain also breaks at a non-regimen
  #     drug starting in a gap, it caps the run-out at OBS_END_DT, and a
  #     permissible substitute's cover counts toward it and is not in
  #     LOT_BASE_MEDS.
  list(id = "runout-unconfirmed-by-a-tandem-no-line-held",
       what = "Post-run-out AUTOs the guard could excuse as tandem partners of an out-of-window transplant",
       expect = "the population the guard and auto_cand have to agree about. On 600 synthetic patients: 5 at LOT1",
       sql = "
      WITH paired AS (
        SELECT PATID, TX_DT,
               lag(TX_DT) OVER (PARTITION BY PATID ORDER BY TX_DT) AS PREV_TX_DT
        FROM {t$auto}
      ),
      named AS (
        SELECT l.PATID, l.LOT_NUM, l.LOT_START_DT, l.LOT_BASE_END_DT,
               l.LOT_START_TYPE,
               explode(split(l.LOT_BASE_MEDS, ' ')) AS MED_ABBR
        FROM {t$long} l
        WHERE coalesce(trim(l.LOT_BASE_MEDS), '') <> ''
      ),
      ep AS (
        SELECT e.PATID, e.LOT_NUM, e.LOT_START_DT, e.LOT_BASE_END_DT,
               e.LOT_START_TYPE, e.MED_ABBR, m.MAP_START_DT, m.MAP_END_DT,
               coalesce(lag(m.MAP_DISCON_FLG)
                          OVER (PARTITION BY e.PATID, e.LOT_NUM, e.MED_ABBR
                                ORDER BY m.MAP_START_DT), 0) AS PREV_DISCON
        FROM named e
        INNER JOIN {t$map} m
          ON m.PATID = e.PATID
         AND m.MAP_MED_TYPE = e.MED_ABBR
         AND m.MAP_START_DT >= e.LOT_START_DT
        WHERE e.MED_ABBR <> ''
      ),
      reached AS (
        SELECT ep.*,
               sum(PREV_DISCON) OVER (PARTITION BY PATID, LOT_NUM, MED_ABBR
                                      ORDER BY MAP_START_DT
                                      ROWS BETWEEN UNBOUNDED PRECEDING
                                               AND CURRENT ROW) AS BROKEN_BY_HERE
        FROM ep
      ),
      per_med AS (
        SELECT PATID, LOT_NUM, LOT_START_DT, LOT_BASE_END_DT, LOT_START_TYPE,
               MED_ABBR, max(MAP_END_DT) AS MED_END_DT
        FROM reached WHERE BROKEN_BY_HERE = 0
        GROUP BY 1, 2, 3, 4, 5, 6
      ),
      runout AS (
        SELECT PATID, LOT_NUM, LOT_START_DT, LOT_BASE_END_DT, LOT_START_TYPE,
               max(MED_END_DT) AS RUNOUT_DT
        FROM per_med GROUP BY 1, 2, 3, 4, 5
      )
      SELECT r.LOT_NUM,
             count(*)                AS N_TRANSPLANTS,
             count(DISTINCT r.PATID) AS N_PATIENTS
      FROM paired p
      INNER JOIN runout r ON r.PATID = p.PATID
      WHERE p.PREV_TX_DT IS NOT NULL
        -- after this line's regimen ran out, which is the date the guard was
        -- deciding about
        AND p.TX_DT >  r.RUNOUT_DT
        AND datediff(p.TX_DT, p.PREV_TX_DT) <= {tandem_days}
        -- the earlier transplant belongs to this line...
        AND p.PREV_TX_DT BETWEEN r.LOT_START_DT AND r.LOT_BASE_END_DT
        -- ...but fell outside its window, so no line ever held the pair
        AND p.PREV_TX_DT > date_add(r.LOT_START_DT,
              CASE r.LOT_START_TYPE WHEN 'SCT_ALLO' THEN 0
                                    WHEN 'CART' THEN {cart_days} - 1
                                    ELSE CASE WHEN r.LOT_NUM = 1
                                              THEN {lot1_window} - 1
                                              ELSE {lotn_window} - 1 END END)
      GROUP BY r.LOT_NUM ORDER BY r.LOT_NUM"),

  # 1e. NOT a defect - the size of the 90-day threshold, which nothing has
  #     ever measured. A break in supply of even one day starts a new episode.
  #     The 90 days is a separate question: did the patient STOP? Only a drug
  #     that comes back after a confirmed stop is released to open a new line;
  #     under 90 days it stays blocked by the previous line's regimen.
  #
  #     So a difference of days in when a refill was picked up decides whether
  #     a patient gets an extra line. That is the rule as designed. What is not
  #     known is how many patients sit close enough to the threshold for a
  #     delayed pickup or a pharmacy switch to move them across it, which is
  #     what this bands.
  #
  #     Restricted to a return that the release rule can actually decide: the
  #     drug has to be in the regimen of the line RUNNING WHEN IT COMES BACK,
  #     because that is the regimen med_cand excludes it from. Any line's
  #     regimen was too wide - a drug that was in LOT1 and returns during LOT3,
  #     with LOT3's regimen not naming it, is not blocked by anything and its
  #     gap decides nothing. Counting those in made the bands either side of 90
  #     look busier than the decision they describe.
  list(id = "return-gap-around-the-90-day-threshold",
       what = "OPEN QUESTION: how close returning drugs sit to the 90-day line that frees them to open a new LOT",
       expect = "no target. Read the two bands either side of 90.",
       sql = "
      WITH gaps AS (
        SELECT m.PATID, m.MAP_MED_TYPE,
               lead(m.MAP_START_DT) OVER (PARTITION BY m.PATID, m.MAP_MED_TYPE
                                          ORDER BY m.MAP_START_DT) AS RETURN_DT,
               datediff(lead(m.MAP_START_DT) OVER (PARTITION BY m.PATID, m.MAP_MED_TYPE
                                                   ORDER BY m.MAP_START_DT),
                        m.MAP_END_DT) AS GAP_DAYS
        FROM {t$map} m
      ),
      -- The line the return would be judged against: the latest one that had
      -- started by the day the drug came back. max_by rather than a correlated
      -- subquery, which Spark will not run unless it is an aggregate.
      judged_against AS (
        SELECT g.PATID, g.MAP_MED_TYPE, g.GAP_DAYS,
               max_by(l.LOT_BASE_MEDS, l.LOT_START_DT) AS PREV_REGIMEN
        FROM gaps g
        INNER JOIN {t$long} l
          ON l.PATID = g.PATID AND l.LOT_START_DT <= g.RETURN_DT
        WHERE g.GAP_DAYS IS NOT NULL
        GROUP BY g.PATID, g.MAP_MED_TYPE, g.GAP_DAYS, g.RETURN_DT
      )
      SELECT CASE WHEN j.GAP_DAYS <  30 THEN 'a. under 30 days'
                  WHEN j.GAP_DAYS <  76 THEN 'b. 30 to 75'
                  WHEN j.GAP_DAYS <  83 THEN 'c. 76 to 82 - within 2 weeks under'
                  WHEN j.GAP_DAYS <  90 THEN 'd. 83 to 89 - within 1 week under'
                  WHEN j.GAP_DAYS <  97 THEN 'e. 90 to 96 - within 1 week over'
                  WHEN j.GAP_DAYS < 104 THEN 'f. 97 to 103 - within 2 weeks over'
                  WHEN j.GAP_DAYS < 181 THEN 'g. 104 to 180'
                  ELSE                       'h. over 180 days' END AS RETURN_GAP,
             CASE WHEN j.GAP_DAYS >= {discon_days} THEN 'released - may open a LOT'
                  ELSE 'still blocked by the previous regimen' END AS EFFECT,
             count(*)                    AS N_RETURNS,
             count(DISTINCT j.PATID)     AS N_PATIENTS
      FROM judged_against j
      WHERE array_contains(split(coalesce(j.PREV_REGIMEN, ''), ' '), j.MAP_MED_TYPE)
      GROUP BY 1, 2
      ORDER BY 1"),

  # 2. Not a defect - an open study-team question about how long a
  #    regimen-less transplant line should run. Reported so the decision is
  #    made against real durations rather than a synthetic guess.
  list(id = "empty-regimen-transplant-line-durations",
       what = "OPEN QUESTION, not a defect: how long transplant lines with no regimen run",
       expect = "synthetic: 605/685 ASCT lines empty, mean 506.9d vs 110.5d with a regimen",
       sql = "
      SELECT l.LOT_START_TYPE,
             CASE WHEN l.LOT_MED_CNT = 0 THEN 'empty regimen' ELSE 'has regimen' END AS REGIMEN,
             count(*)                                   AS N_LINES,
             round(avg(l.LOT_BASE_LENGTH), 1)           AS MEAN_LENGTH_DAYS,
             percentile_approx(l.LOT_BASE_LENGTH, 0.5)  AS MEDIAN_LENGTH_DAYS,
             percentile_approx(l.LOT_BASE_LENGTH, 0.75) AS P75_LENGTH_DAYS
      FROM {t$long} l
      GROUP BY 1, 2
      ORDER BY 1, 2"),

  # 3. Treatment outside every line, split by cause. The unpartitioned total is
  #    meaningless: leftover supply deliberately does not carry into a new line,
  #    an ALLO line is one day by design, and therapy past LOT5 is the cap. Only
  #    the residual bucket is a question.
  list(id = "outside-line-days-by-cause",
       what = "Non-steroid agent-DAYS owned by no line, partitioned by cause",
       expect = "no target. Only the gap-between-LOTs bucket is a question; the rest are by design",
       sql = "
      WITH bounds AS (
        SELECT PATID, min(LOT_START_DT) AS FIRST_START,
               max(LOT_BASE_END_DT)     AS LAST_END,
               max(LOT_NUM)             AS MAX_LOT
        FROM {t$long} GROUP BY PATID
      ),
      drug_days AS (
        SELECT m.PATID, m.MAP_MED_TYPE, m.MAP_CNT,
               explode(sequence(m.MAP_START_DT, m.MAP_END_DT, interval 1 day)) AS SUPPLY_DT
        FROM {t$map} m
        WHERE m.MAP_MED_CLASS <> 'STEROID'
          AND m.MAP_START_DT IS NOT NULL AND m.MAP_END_DT IS NOT NULL
          AND m.MAP_END_DT >= m.MAP_START_DT
      ),
      orphan AS (
        SELECT d.*, b.FIRST_START, b.LAST_END, b.MAX_LOT
        FROM drug_days d
        LEFT JOIN bounds b ON b.PATID = d.PATID
        WHERE NOT EXISTS (SELECT 1 FROM {t$long} l
                          WHERE l.PATID = d.PATID
                            AND d.SUPPLY_DT BETWEEN l.LOT_START_DT AND l.LOT_BASE_END_DT)
      ),
      total AS (SELECT count(*) AS N_ALL_AGENT_DAYS FROM drug_days)
      SELECT CASE
               WHEN FIRST_START IS NULL             THEN 'patient has no LOT'
               WHEN SUPPLY_DT <  FIRST_START        THEN 'before LOT1'
               WHEN MAX_LOT = 5 AND SUPPLY_DT > LAST_END THEN 'past the LOT5 cap'
               WHEN SUPPLY_DT >  LAST_END           THEN 'after the last observed LOT'
               ELSE 'gap between LOTs'
             END                                     AS CAUSE,
             count(*)                                AS N_ORPHAN_AGENT_DAYS,
             round(100.0 * count(*) / max(N_ALL_AGENT_DAYS), 2) AS PCT_OF_ALL_AGENT_DAYS,
             count(DISTINCT PATID)                   AS N_PATIENTS,
             count(DISTINCT concat_ws('|', cast(PATID AS string), MAP_MED_TYPE,
                                      cast(MAP_CNT AS string))) AS N_EPISODES
      FROM orphan CROSS JOIN total
      GROUP BY 1
      ORDER BY 2 DESC"),

  # 5. In-window CAR-T is deliberately not a boundary and IS kept in LOT1_SCT.
  #    The question is only whether the final deliverable can see it.
  list(id = "in-window-cart-not-in-final-table",
       what = "Patients with a CAR-T inside LOT1's induction window, invisible in LOT_LONG",
       expect = "an output-surface question, not a boundary error",
       sql = "
      WITH lot1 AS (
        SELECT PATID, LOT_START_DT AS LOT1_START_DT
        FROM {t$long} WHERE LOT_NUM = 1
      ),
      in_window AS (
        SELECT s.PATID
        FROM {t$sct} s
        INNER JOIN lot1 l ON l.PATID = s.PATID
        WHERE s.FIRST_CART_DT IS NOT NULL
          AND s.FIRST_CART_DT BETWEEN l.LOT1_START_DT
                                  AND date_add(l.LOT1_START_DT, {lot1_window - 1})
      ),
      cart_line AS (
        SELECT DISTINCT PATID FROM {t$long} WHERE LOT_START_TYPE = 'CART'
      )
      SELECT count(*)                                                  AS N_PATIENTS_IN_WINDOW_CART,
             sum(CASE WHEN c.PATID IS NOT NULL THEN 1 ELSE 0 END)      AS N_ALSO_WITH_A_CART_LINE_LATER
      FROM in_window i LEFT JOIN cart_line c ON c.PATID = i.PATID"),

  # Context for the Q1 duration tab. Not a finding on its own.
  list(id = "line-length-by-start-type",
       what = "Line duration by line number and start type - context for the Q1 tab",
       expect = "no target. This is the distribution the counts above bear on",
       sql = "
      SELECT l.LOT_NUM, l.LOT_START_TYPE,
             count(*)                                   AS N_LINES,
             round(avg(l.LOT_BASE_LENGTH), 1)           AS MEAN_LENGTH_DAYS,
             percentile_approx(l.LOT_BASE_LENGTH, 0.5)  AS MEDIAN_LENGTH_DAYS,
             percentile_approx(l.LOT_BASE_LENGTH, 0.75) AS P75_LENGTH_DAYS
      FROM {t$long} l
      GROUP BY 1, 2
      ORDER BY 1, 2"),

  # 7. The same stranded agents, split by line number and by what ended the
  #    line, because only some paths can strand one: ALLO at every line, CAR-T
  #    at LOT2-5 only (LOT1's induction exemption closes that one), and AUTO
  #    nowhere, since the in-LOT AUTO window is the regimen window. A count
  #    landing on SCT_AUTO, or on a LOT1 SCT_CART, contradicts that and is the
  #    finding.
  list(id = "post-end-regimen-by-line-and-end-reason",
       what = "Lines naming a regimen agent with no supply cover inside the line at all, by LOT and end reason",
       expect = "possible on SCT_ALLO at any line and SCT_CART at LOT2+; anything else is the finding",
       sql = "
      WITH exploded AS (
        SELECT l.PATID, l.LOT_NUM, l.LOT_START_DT, l.LOT_BASE_END_DT,
               l.LOT_BASE_END_REASON,
               explode(split(l.LOT_BASE_MEDS, ' ')) AS MED_ABBR
        FROM {t$long} l
        WHERE coalesce(trim(l.LOT_BASE_MEDS), '') <> ''
      ),
      offending AS (
        SELECT DISTINCT e.PATID, e.LOT_NUM, e.LOT_BASE_END_REASON, e.MED_ABBR
        FROM exploded e
        WHERE e.MED_ABBR <> ''
          -- No cover inside the line at all, not merely no episode STARTING in
          -- it. Count 1 splits the two; here only the stranded shape is wanted,
          -- because this table is read as which paths strand an agent.
          AND NOT EXISTS (SELECT 1 FROM {t$map} m
                          WHERE m.PATID = e.PATID
                            AND m.MAP_MED_TYPE = e.MED_ABBR
                            AND m.MAP_START_DT <= e.LOT_BASE_END_DT
                            AND m.MAP_END_DT   >= e.LOT_START_DT)
      )
      SELECT LOT_NUM, LOT_BASE_END_REASON,
             count(*)                                        AS N_AGENT_LINE_PAIRS,
             count(DISTINCT concat_ws('|', PATID, LOT_NUM))  AS N_LINES,
             count(DISTINCT PATID)                           AS N_PATIENTS
      FROM offending
      GROUP BY 1, 2
      ORDER BY 1, 2"),

  # 8. The consequence that is not cosmetic: the same agent counted in a line it
  #    post-dates AND opening a later line. This is the number the decision turns
  #    on, because it is the one that moves a line count rather than a string.
  list(id = "post-end-agent-also-starts-a-later-line",
       what = "Stranded regimen agents that also appear in a LATER line's regimen for the same patient",
       expect = "no target. This is double attribution: one agent counted in two lines",
       sql = "
      WITH exploded AS (
        SELECT l.PATID, l.LOT_NUM, l.LOT_START_DT, l.LOT_BASE_END_DT,
               explode(split(l.LOT_BASE_MEDS, ' ')) AS MED_ABBR
        FROM {t$long} l
        WHERE coalesce(trim(l.LOT_BASE_MEDS), '') <> ''
      ),
      stranded AS (
        SELECT DISTINCT e.PATID, e.LOT_NUM, e.MED_ABBR
        FROM exploded e
        WHERE e.MED_ABBR <> ''
          -- Cover, not a start date, for the same reason as the count above.
          AND NOT EXISTS (SELECT 1 FROM {t$map} m
                          WHERE m.PATID = e.PATID
                            AND m.MAP_MED_TYPE = e.MED_ABBR
                            AND m.MAP_START_DT <= e.LOT_BASE_END_DT
                            AND m.MAP_END_DT   >= e.LOT_START_DT)
      )
      SELECT s.LOT_NUM                                       AS STRANDED_IN_LOT,
             count(*)                                        AS N_AGENT_LINE_PAIRS,
             count(DISTINCT concat_ws('|', s.PATID, s.LOT_NUM)) AS N_LINES,
             count(DISTINCT s.PATID)                         AS N_PATIENTS
      FROM stranded s
      INNER JOIN exploded later
              ON later.PATID = s.PATID
             AND later.LOT_NUM > s.LOT_NUM
             AND later.MED_ABBR = s.MED_ABBR
      GROUP BY 1
      ORDER BY 1"),

  # 9. The second-order half of the same fix. Bounding regimen MEMBERSHIP is not
  #    enough on its own: discon_per_med chains a base agent's own later episodes
  #    forward from the line's START with no upper bound, so a refill after the
  #    transplant still pushes RAW_DISCON_DT past it. Counted separately because
  #    it survives the membership fix and needs its own cutoff.
  list(id = "runout-extends-past-the-transplant-end",
       what = "Lines ended by a transplant whose regimen was still covered after that end",
       expect = "no target. These are the lines where bounding regimen membership alone is not enough",
       # Off map_stacked, not off a run-out column. LOT_LONG carries no
       # run-out: LOT_BASE_RUNOUT_DT lives on the per-line *_BASE tables and
       # stops there, and only LOT_BASE_DISCON_DT is projected.
       #
       # DISCON_DT is not a substitute for it. That is the CONFIRMED
       # discontinuation, and a line ended by a transplant usually has none, so
       # reading it answers zero for a reason unrelated to the question. The
       # question is about the line's own cover, so it comes from the episodes:
       # the last cover end among the agents the line names, over episodes that
       # had started by the time it ended.
       sql = "
      WITH ended_by_tx AS (
        SELECT l.PATID, l.LOT_NUM, l.LOT_BASE_END_DT, l.LOT_BASE_END_REASON,
               explode(split(l.LOT_BASE_MEDS, ' ')) AS MED_ABBR
        FROM {t$long} l
        WHERE l.LOT_BASE_END_REASON IN ('SCT_AUTO', 'SCT_ALLO', 'SCT_CART')
          AND coalesce(trim(l.LOT_BASE_MEDS), '') <> ''
      ),
      cover AS (
        SELECT e.PATID, e.LOT_NUM, e.LOT_BASE_END_DT, e.LOT_BASE_END_REASON,
               max(m.MAP_END_DT) AS LAST_COVER_DT
        FROM ended_by_tx e
        INNER JOIN {t$map} m
          ON m.PATID = e.PATID
         AND m.MAP_MED_TYPE = e.MED_ABBR
         AND m.MAP_START_DT <= e.LOT_BASE_END_DT
        WHERE e.MED_ABBR <> ''
        GROUP BY 1, 2, 3, 4
      )
      SELECT LOT_NUM, LOT_BASE_END_REASON,
             count(*)                AS N_LINES,
             count(DISTINCT PATID)   AS N_PATIENTS,
             percentile_approx(datediff(LAST_COVER_DT, LOT_BASE_END_DT), 0.5)
                                     AS MEDIAN_DAYS_PAST_END,
             max(datediff(LAST_COVER_DT, LOT_BASE_END_DT))
                                     AS MAX_DAYS_PAST_END
      FROM cover
      WHERE LAST_COVER_DT > LOT_BASE_END_DT
      GROUP BY 1, 2
      ORDER BY 1, 2")
)

report_plan <- function() {
  cat("\nReal-data frequencies for the shapes the LOT rules turn on.\n\n")
  cat("Read-only: every statement is a SELECT. Nothing is written to the warehouse.\n\n")
  for (a in AUDIT_COUNTS) {
    cat("  ", a$id, "\n    ", a$what, "\n    ", a$expect, "\n", sep = "")
  }
  # The trailer says what happens NEXT, so it has to know whether this is the
  # dry run. Printed unconditionally it told an operator who had already set
  # AUDIT_EXECUTE to set it - which reads as the flag not having been picked
  # up, and sends them after the wrong thing when the next line is an error.
  cat("\n", length(AUDIT_COUNTS), " counts.", sep = "")
  if (env_flag("AUDIT_EXECUTE")) {
    cat(" Running them now.\n\n")
  } else {
    cat(" Set AUDIT_EXECUTE=TRUE to run them.\n")
    cat("Needs DATABRICKS_PWD, DOMINO_USER_NAME (or PROJECT_WORK_SCHEMA),\n")
    cat("OBJECT_PREFIX and INPUT_COHORT_TABLE.\n\n")
  }
}

main <- function() {
  report_plan()
  if (!env_flag("AUDIT_EXECUTE")) return(invisible(0L))

  library(DBI); library(odbc); library(glue)
  source(file.path(LOT_ROOT, "R", "load_inputs.R"))
  load_pipeline_inputs(LOT_ROOT, "config.csv")
  for (f in c("config_lot.R", "db_utils_lot.R")) source(file.path(LOT_ROOT, "R", f))

  # cfg_defaults, not lot_config(). config_lot.R defines cfg_defaults when it is
  # sourced; lot_config() reads the config that set_lot_config() installs, and
  # that has not happened yet - it happens below, once the schema and prefix
  # this script is given have been folded in. Calling it here stopped the whole
  # execute path on its own guard, which is why only the plan ever printed.
  cfg <- get("cfg_defaults", envir = globalenv())
  schema <- trimws(Sys.getenv("PROJECT_WORK_SCHEMA",
             unset = Sys.getenv("DOMINO_USER_NAME",
             unset = Sys.getenv("DOMINO_STARTING_USERNAME", unset = ""))))
  if (!nzchar(schema))
    stop("No work schema. Set DOMINO_USER_NAME to the schema the build wrote into, ",
         "or PROJECT_WORK_SCHEMA to override.", call. = FALSE)
  cfg$work_schema <- schema

  pfx <- trimws(Sys.getenv("OBJECT_PREFIX", unset = ""))
  if (!nzchar(pfx))
    stop("No OBJECT_PREFIX. It names the run's tables, so without it this would ",
         "count whatever unprefixed tables happen to exist.", call. = FALSE)
  if (!grepl("^[A-Za-z][A-Za-z0-9_]*_$", pfx))
    stop("OBJECT_PREFIX '", pfx, "' should be a name ending in '_'.", call. = FALSE)
  cfg$object_prefix <- pfx

  cohort <- trimws(Sys.getenv("INPUT_COHORT_TABLE", unset = ""))
  if (!nzchar(cohort))
    stop("No INPUT_COHORT_TABLE. The death-date count reads the cohort for its ",
         "observation window. Give the whole name including the prefix, e.g. ",
         pfx, "NDMM_COHORT.", call. = FALSE)

  set_lot_config(cfg)
  dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)
  stop_if_blank(cfg$pwd, "DATABRICKS_PWD environment variable is not set.")

  # Which line table to count. LOT_LONG_FINAL is the study deliverable, with the
  # line criteria applied; LOT_LONG is what the engine built before them.
  which_tbl <- trimws(Sys.getenv("AUDIT_TABLE", unset = "LOT_LONG"))
  if (!which_tbl %in% c("LOT_LONG_FINAL", "LOT_LONG"))
    stop("AUDIT_TABLE must be LOT_LONG_FINAL or LOT_LONG.", call. = FALSE)

  # OBS_END_DT is not persisted - it is chosen at build time from ENDDATE or
  # ENDDATE_CE. Match whichever the run used, or the death filter will disagree
  # with the build's own idea of when observation stopped.
  obs_col <- if (isTRUE(cfg$censor_at_disenrollment)) "ENDDATE_CE" else "ENDDATE"

  lot1_window <- cfg$induction_window_days
  # Named locally so the new AUDIT_COUNTS templates read the settings the run
  # used rather than restating them - a count that hard-codes 180 or 45 stops
  # sizing the build the moment a contract deviation moves either.
  lotn_window <- cfg$lot_n_induction_window_days
  cart_days   <- cfg$cart_consolidation_days
  tandem_days <- cfg$sct_tandem_days
  max_lot     <- cfg$max_lot
  discon_days <- cfg$map_discon_gap_days
  t <- list(long   = lot_out(which_tbl),
            map    = lot_out("MAP_STACKED"),
            sct    = lot_out("LOT1_SCT"),
            auto   = lot_out("TX_AUTO_DATES"),
            # The interrupting events a tandem has to be free of, alongside a
            # non-steroid medication start. Same three sources as
            # tandem_interrupt_events_sql().
            allo   = lot_out("TX_ALLO_CART_DATES"),
            cohort = wrk(cohort))

  cat("Counting against:\n")
  for (nm in names(t)) cat("  ", nm, ": ", t[[nm]], "\n", sep = "")
  cat("  observation column: ", obs_col, "\n\n", sep = "")

  # Substitution reciprocity is a codelist question, not a warehouse one:
  # permissible_subs is loaded from CSV into a session view and is not persisted,
  # so it is checked here against the file the build would read. A one-way pair
  # is not automatically wrong - some are deliberately directional - but the set
  # should be reviewed rather than assumed symmetric.
  subs_csv <- file.path(cfg$codelist_dir, "permissible_subs.csv")
  cat("== substitution-reciprocity\n")
  if (!file.exists(subs_csv)) {
    cat("   SKIPPED: no permissible_subs.csv at ", subs_csv, "\n\n", sep = "")
  } else {
    ps <- utils::read.csv(subs_csv, stringsAsFactors = FALSE)
    key <- paste(ps$original_med, ps$substitute_med)
    rev <- paste(ps$substitute_med, ps$original_med)
    one_way <- ps[!(key %in% rev), c("original_med", "substitute_med")]
    cat("   ", nrow(ps), " pairs, ", nrow(one_way), " present in one direction only\n", sep = "")
    if (nrow(one_way)) print(head(one_way, 20), row.names = FALSE)
    cat("\n")
  }

  con <- DBI::dbConnect(odbc::odbc(), dsn = cfg$dsn, pwd = cfg$pwd, timeout = 120)
  on.exit(try(DBI::dbDisconnect(con), silent = TRUE), add = TRUE)

  rows <- list()
  failed <- 0L
  for (a in AUDIT_COUNTS) {
    cat("== ", a$id, "\n", sep = "")
    cat("   ", a$what, "\n", sep = "")
    sql <- glue(a$sql, .open = "{", .close = "}")
    res <- tryCatch(DBI::dbGetQuery(con, sql), error = function(e) e)
    if (inherits(res, "error")) {
      failed <- failed + 1L
      cat("   FAILED: ", conditionMessage(res), "\n\n", sep = "")
      next
    }
    print(res, row.names = FALSE)
    cat("   (", a$expect, ")\n\n", sep = "")
    # Long format, one row per cell. The counts return different columns from
    # each other, so writing them as separate CSV tables into one file produced
    # repeated headers and a file nothing could read.
    if (nrow(res)) {
      for (i in seq_len(nrow(res))) for (nm in names(res)) {
        rows[[length(rows) + 1L]] <- data.frame(
          finding = a$id, row = i, metric = nm,
          value = as.character(res[[nm]][i]),
          stringsAsFactors = FALSE)
      }
    }
  }

  csv <- file.path(out_dir, "lot_audit_counts.csv")
  utils::write.csv(do.call(rbind, rows), csv, row.names = FALSE)
  cat("Wrote ", csv, "\n", sep = "")
  if (failed) {
    cat(failed, " count(s) failed - see the messages above.\n", sep = "")
    return(invisible(1L))
  }
  invisible(0L)
}

if (!interactive()) quit(status = main())
