# Demo run sheet

Everything here has been run end to end and produces the output described. Commands are given
exactly as you type them, from the **repository root** unless a block says otherwise.

**Subject: `products/oncology/prostate/202606`.** It is the only pack where every gate has something
real to check. Do not demo `oc/202606` — see "If OC comes up" at the end.

---

## 0.0 Preflight — get on the right commit, and prove it

**The work is on `main`.** It was merged there on 2026-08-03 (PR #359, #360). An earlier version of
this section told you to check out a branch instead; that was true when written and is now the
opposite of correct — a presenter who follows it leaves the reviewed default branch for no reason.

```bash
git checkout main && git pull
git rev-parse --short HEAD                                  # the commit you are about to demo
git status --porcelain | grep -v '\.venv'                   # must print NOTHING
```

Then confirm you are at the tip, not a stale local copy:

```bash
test "$(git rev-parse HEAD)" = "$(git rev-parse origin/main)" \
  && echo "in sync" || echo "STALE — pull before demoing"
```

Say the short SHA out loud when you open. It is the difference between "here is a demo" and "here
is exactly what you can go and check".

**Why a clean tree matters for the numbers below.** A modified checkout cannot produce a
release-bindable deployment tree, so `demo.py` correctly demotes the two packaging steps from scored
gates to reports and you get `11/13` instead of `13/13`. That is the tool being honest, not a
failure — but it will read as one in front of an audience.

---

## 0. The sentence to open with

Say this before running anything. It is the difference between the audience seeing a system work and
seeing a system that is missing a dataset.

> This framework turns an **approved RWB program specification** into an RWP-owned executable data
> product. RWP owns the contract, the semantic mapping and the configuration; Data Engineering owns
> the shared engine that executes them.
> For today's prostate demonstration, **reconstructed specification tabs stand in for the final
> workbook** — and you'll see the gate refuse release precisely because that provenance is still
> pending. Then I'll build an actual dataset from it.

And the line that makes the rest cohere:

> Almost everything you're about to see is this system **refusing** something, and naming why.

And the sentence that states the boundary, if it is the only one they remember:

> **Data Engineering industrializes the product. It does not define the product.**

---

## 1. The walkthrough — 16 steps, ~40 seconds

```bash
python3 platform/tools/demo.py products/oncology/prostate/202606
```

Read-only. Nothing is written to the pack, nothing is approved, no vendor data is read. Ends on
`13/13 gate step(s) passed` — say **"13 scored technical checks passed; the product release is
still BLOCKED"**. Sixteen steps are shown; three are reports whose exit code is information, not
a verdict, so they are not scored. `13/13` is not "the product passed".

### The four moments to slow down for

| step | what happens | what to say |
|---|---|---|
| **4** | the AI slicer **REFUSES** the pack — its extraction registration is `status: pending`, unsigned | *The refusal names the missing human act and the file it lands in: "an instruction in the task is not an approval mechanism" — the tool refuses its operator. When a named person signs the extraction record, the same command produces the slice; until then the refusal IS the demonstration.* |
| **8** | a PASS that prints real defects and says *"a PASS here is 'nothing unreadable', NOT 'nothing wrong'"* | *The tool tells you the scope of its own green light.* |
| **13** | Gate 6: **BLOCKED**, three derived reasons | *There is no releasable flag. It's derived from Gates 1–4, so it can't be set.* |
| **14** | deployment tree: an allowlisted file set, `commit … tree … evidence …` (the tool prints the current count — don't quote a number, it moves with every tool added) | *Production sees an allowlist, not the repo minus a few globs. The audit bundle is written outside the runtime tree.* |

### Numbers to have ready

200 spec rows from 6 sources · 202 contract records · the lint's own invariant list (its
docstring is the count — it has grown past every number written here) · 199 of 200 spec items in
the contract · 38/38 config blocks claimed · 5 pack test suites · 0 packs releasable.

The tracked-file count is deliberately NOT written here — it changed three times in two days and
went stale in two documents. Derive it when you need it:

```bash
python3 platform/tools/repo_hygiene.py --check    # prints the live count
```

---

## 2. Spec → code, for one variable

This answers "does the specification actually reach the executing code?" Four artifacts, one chain.
Run the blocks in order.

**The record** — what the contract says, bound to the spec text by a digest:

```bash
python3 - <<'PY'
import sys; sys.path.insert(0, 'platform/tools')
import contract_lint as cl
t = cl.read('products/oncology/prostate/202606/handoff/FUNCTIONAL_CONTRACT.md')
for b in cl.records(t):
    if b.startswith('variable_id: AGEGR1N'):
        for line in b.splitlines():
            if line.split(':')[0] in ('variable_id', 'spec_refs', 'spec_digest',
                                      'required_rule', 'implementation_refs'):
                print(line)
        break
PY
```

```
variable_id: AGEGR1N
spec_refs: [demographics:11]
spec_digest: bf1852114593
required_rule: Numeric code for AGEGR1:<br>1=0-18<br>2=19-34<br>3=35-49<br>4=50-64<br>5=65-74<br>6=75-84<br>7=>=85
implementation_refs: [variables/demographics.yaml#/age_bands, engine:_bands_case]
```

**The config** — the reviewed bands the record points at:

```bash
sed -n '/^age_bands:/,/^$/p' products/oncology/prostate/202606/variables/demographics.yaml
```

**The generated SQL** — compiled from that config by the engine function the record names:

```bash
cd platform && python3 -c "
import sys, yaml; sys.path.insert(0,'.')
from engine.stages.demographics import _bands_case
d = yaml.safe_load(open('../products/oncology/prostate/202606/variables/demographics.yaml'))
print(_bands_case(d['age_bands'], 'age', 'code'))
"; cd ..
```

```
CASE WHEN age >= 0 AND age <= 18 THEN 1 WHEN age >= 19 AND age <= 34 THEN 2 ... ELSE 99 END
```

**The point:** the spec row, the record, the config and the SQL are four separate artifacts, and the
record binds itself to the spec text by hash (`spec_digest`) and to the code by name
(`engine:_bands_case`). Retyping the spec text breaks the digest and CI fails.

### The obvious hostile question — "so the AI just reads the spec and writes what it likes?"

Answer it by running the drafting tool live. It refuses, and it names the human act that would
unblock it:

```bash
printf 'variable_id: PROBE\n' > /tmp/d.yaml
python3 platform/tools/contract_record.py /tmp/d.yaml \
  --product products/oncology/oc/202606 --item study_period:18 --allow-partial
```

**Note the pack: oc/202606, not prostate/202606.** The two packs refuse DIFFERENTLY, which is
the demonstration: prostate/202606 HAS a registered extraction but it is `status: pending` and
unsigned, so the refusal names the missing approval fields; oc/202606 has never registered one
at all, so the refusal names the missing registration. No pack's extraction is currently
approved — every slice request refuses, each stating its own missing human act.

```
products/oncology/oc/202606: REFUSING to supply spec evidence — the sanitized extraction is
not approved for AI use:
  no `material_type: ai_extraction` in source_refs.yaml — AI reads the SANITIZED
  `spec_pipeline/out/extracted.json`, not the stand-in it is derived from, and that artifact
  must be registered and approved in its own right. The classification on the input says
  nothing about the file AI opens.
  `required_rule` is the specification's own words, so it is lifted ONLY from a derived
  artifact somebody has signed. Registering and approving it is a HUMAN act recorded in
  products/oncology/oc/202606/source_refs.yaml — see governance/WORKFLOW.md "Eligibility".
  An instruction in the task is not an approval mechanism.
  The block, with the derivation fields already computed:
    python3 platform/tools/source_manifest.py --register-ai-extraction products/oncology/oc/202606
```

**The point:** AI drafting is permitted by a *signed artifact*, not by a prompt. `ai_readable` asks
whether the sanitized extraction is registered, classified, approved by a named person, still the
run that approval was given over, and still under the redaction policy it was given under — and every
one of those fails closed. Say plainly that this refusal is **new as of this session**: `spec_slice`
asked that question and `contract_record --item` did not, so the same artifact was refused by one
tool and served by the other. That is the honest version of "we find our own gaps", and it is more
convincing than a clean sheet.

**Then show the other half**, so it reads as a gate rather than a wall:

```bash
python3 platform/tools/spec_slice.py products/oncology/prostate/202606 --domain demographics | head -20
```

Same tool, same question — and today this ALSO refuses, printing the exact block a named person
would commit into `products/oncology/prostate/202606/source_refs.yaml` to change the answer. The
approval binds to the artifact's sha256, the extraction fingerprint and the redaction policy, so
editing the artifact or re-extracting revokes it. If someone has signed it by the time you demo,
the same command produces the drafting context instead — check which world you are in BEFORE the
demo (`python3 platform/tools/spec_slice.py … --domain demographics | head -3`) and narrate the
one on screen.

---

## 3. Build an actual dataset

**Set this up before the meeting — the install takes a few minutes.**

```bash
python3 -m venv .venv
.venv/bin/pip install --upgrade pip setuptools wheel    # PyPI setuptools, NOT the OS one
.venv/bin/pip install pyspark pyyaml
```

> **The directory must be called `.venv`.** A PySpark install contains five files whose kinds the
> containment rule refuses — `.html` licence files and archives — and `repo_hygiene.py` walks the
> working tree, not just the git index, because "gitignored is still on disk". `.venv`, `venv` and
> `build` are on its skip list; a venv called anything else turns **step 1 of this demo red** with
> five false findings. Verified both ways.

> The `setuptools` upgrade is not optional on Debian/Ubuntu. PySpark ships an sdist and the
> distro-patched `install_lib` rejects it with `AttributeError: install_layout`. In a venv with
> setuptools from PyPI it installs first time. Needs Java 17 or 21 on `PATH`.

Then:

```bash
.venv/bin/python platform/tools/local_smoke.py products/oncology/prostate/202606 2>/dev/null
```

Takes about six minutes. `2>/dev/null` suppresses Spark's progress bars, which otherwise bury the
output. It ends with:

```
### ADS BUILT — synthetic sources, local Spark, NO cluster ###
rows     : 4
columns  : 187
cohorts  : 4 populated of 7 configured -> ['L1+ treated mCRPC', 'L1+ treated mHSPC', …]

patientid | index_date | cohort | cohortn | cohortu | stage | stagen | data_product_id | spec_version | data_refresh
p1 | 2020-01-01 | Overall mHSPC | 1 | Treated mHSPC | CHECK | 99 | prostate_mcrpc_rwdp | 202606 | synthetic

first 30 columns:
  patientid, index_date, advanceddiagnosisdate, age, agegrl, agegrln, …
```

**Say the caveat yourself, before anyone asks:** these are **synthetic source tables**, not real
Panoramic data. Same shared engine and the same SCIENTIFIC configuration — with **synthetic run
bindings**: the tool overrides `refresh`, `source_schema` and `output_schema` to `synthetic`, which
is why `data_refresh` reads `synthetic` and not a cut. It is not "the same config" in full, and the
delivery half is exactly the half Gate 3 governs. What it proves is that the configuration assembles
into an executing 187-column ADS — not that any clinical number is right. Say
**"seven cohort definitions are configured; this fixture populates four"**, never "a 7-cohort ADS":
the config defines C1–C7 and the synthetic rows only reach 1–4.

**On the `stage=CHECK/99` cell.** The fixture supplies a delivered-STYLE sub-stage (the pack's own
first configured stage token plus `B1` — `IB1` for prostate). The config matches stage values with
`from_prefixes`, which is exact `IN`, so `IB1` falls through to the QC catch-all instead of
collapsing to `I`. That IS `G-STAGE-PREFIX`, visible in the output. It was not always: while the
fixture filled the column with a generic `"1"`, the same `CHECK/99` proved only that the fallthrough
works, and citing it as the prefix gap was wrong.

If you are short on time, run this **before** the meeting and show the tail of the output.

### The follow-up: "if only the config is edited, what stops a config edit breaking it?"

This is the question the whole "edit the spec, not the code" claim rests on, and until this session
the answer was worse than it looked. Rename one block in `variables/demographics.yaml` **and** in the
record that claims it:

| check | before | after |
|---|---|---|
| `contract_binding --check` | 0 issues | **refuses** — *"the engine never reads `age_bandz`"* |
| `validate.check` | PASSED | PASSED (unchanged — see below) |
| `finalize --check` | "every stated summary matches the evidence" | unchanged |
| variables the engine emits | **153 → 151** | — |

`AGEGR1` and `AGEGR1N` silently stopped being produced, and every gate stayed green, because the
binder only checked that a name resolves between the *contract* and the *config* — nobody checked
that the *engine* was listening for it. It now derives, by AST from the engine's own source, which
blocks each pack role is actually read for, and refuses any block that isn't one.

Worth saying out loud: `validate.check` still passes on that edit. It answers "can this config run",
not "does the engine consume it", and splitting those is deliberate — but the binder is what makes
the config-only claim safe, and the binder is what CI runs.

```bash
python3 platform/tools/dry_run.py   products/oncology/prostate/202606
python3 platform/tools/worksheet.py products/oncology/prostate/202606
```

**`dry_run`** makes both approval claims on a *copy* and reports what answers back: 3 blockers today,
**8 latent** — blockers that exist only once the claim is made, and would otherwise surface during the
approval itself. One of them is 13 unaccounted specification-QC findings; that number was 8 until
five of them were found to be unreadable by the linter, which is exactly the kind of thing this
catches early.

**`worksheet`** orders the remaining work: 62 records are waiting on a decision, and answering the
top one (`OUTCOME-COHORT-MAP`) unblocks **19** of them. The top four unblock 44.

Show `dry_run` if you show only one. "Here are 8 problems that are invisible today and would have
surfaced in the approval meeting" is the sharper story.

---

## 5. Questions you will get

**"Where's the real data?"**
There isn't any here — no warehouse connection in this environment. The build above uses synthetic
sources through the production entrypoint. On Databricks the same engine and config point at real
Panoramic tables (`products/oncology/prostate/202606/DEV_SMOKE.md`).

**"So nothing is finished?"**
Nothing is releasable, and that is the framework working, not incompleteness. The gates require an
approved workbook, a profile of the live feed, and two human signatures — none of which exist yet.

**Be precise about what is proved.** `platform/tests/test_governance.py` drives a fully-evidenced
pack to `releasable → True, blockers: []` — that is **Gates 1–4 reaching a clearing verdict**, and
it is genuinely proved. It is *not* the release path. Promotion to the public views is a further
step and it requires a named Gate 6 approval of the specific build: a prod run stages a candidate and
stops, a person signs that `build_id` and manifest digest, and a promotion run publishes those exact
bytes without rebuilding.

If asked, say plainly what is and is not established. The promotion path exists and its refusals are
tested — bytes gone, already promoted, Gates 1–4 not passed, no approval binding this build — but
**it has never run on a cluster**, and no prostate build has ever been promoted because prostate has
not passed Gates 1–4. "The path is built and untested on real infrastructure" is a better answer than
either "it cannot complete" (no longer true) or an unqualified "proved" that one question takes
apart.

**"Can the AI just write the contract?"**
It drafts records; humans approve them. And it is not permitted to read whatever it likes: the
derived artifact it reads needs its own signature, bound to those exact bytes. TODAY no pack's
extraction is approved — prostate/202606's registration is `status: pending` and unsigned — so
step 4 REFUSES, naming the missing approval. **Run step 4 before the demo and narrate what is
actually on screen**: the refusal while unsigned, the slice if someone has signed it since. This
paragraph has flipped twice already; the tool's output, not this file, is the truth.

**"How long for a new tumour?"**
Don't guess a number. Say the multi-tumour claim is ARCHITECTURAL — nothing hardcodes a tumour
name, packs are discovered by shape — and be exact about the evidence: two packs are configured
and exercised end-to-end (prostate 202606; OC 202606, split as below), the other registry entries
are earlier-stage scaffolds, and the 13-tumour variable inventory is reference material, not
implemented products.

---

## 6. Honest boundaries — state these rather than be caught by them

- **No real data, no cluster.** Synthetic build only.
- **No pack is releasable.** By design; every one is blocked on human approvals and live evidence.
- **The engine's stage tests had never run until 2026-08-02.** PySpark was believed unbuildable in
  the dev sandbox, so `test_stages_spark.py` and `test_smoke_spark.py` printed "SKIP" and exited 0
  for months. They now pass (26 tests + 2), and the two failures found on the first real run were
  defects in the tests, not the engine. **CI now runs them** in a dedicated `spark` job (JDK 17 +
  PySpark), added the same day — the sentence here said it did not, which was true when written and
  wrong within hours.
- **OC 202606 is split.** See below.
- **`validation: not_run` on every governed contract record** — 207 across the two live packs
  (202 prostate 202606 + 5 oc 202606) — because that axis requires a build against real data. (A
  larger figure counts the parked test fixture and the sandbox draft too; those are not products
  and do not belong in a demo number.)

---

## If OC comes up

Do not put it on screen. If asked, say it plainly:

OC's governed pack holds **5 records against 360 spec items**, with 33 config blocks that no record
claims. The real drafting work — **295 records covering all 360 items**, with a QC findings file —
lives in `sandbox/experiments/ovarian_202606_contract_draft`, outside the gates. They are two halves
of one product and no tool can currently see both, so `contract_binding` reports OC's config as
"behaviour nobody required" when the requirement exists in a directory it does not look at.

That is a real design gap, it is recorded, and it is the first thing to fix after the handover.
Saying so is a much better answer than either directory's numbers.

---

## Pointers

- `HANDOVER.md` — the goal, grounded status of every layer, roadmap, open governance items
- `governance/WORKFLOW.md` — the six gates in full, and the AI eligibility rule
- `docs/ENGINEERING.md` — the rules that are expensive to get wrong
