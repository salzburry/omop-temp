"""ONE ROW PER KEY, chosen the same way every time — the other half of `same_date_conflict`.

`clinical._refuse_same_date_conflict` already owns the SELECTOR paths: a windowed panel or lab
value that finds two records on one date can be told to refuse. It does not cover the seven places
that call `dropDuplicates(["patientid"])` on a source ASSUMED to be one row per patient:

    clinical.py  1225, 1265, 1299, 1493      "enhanced = one row per patient"
    treatment.py  273                        one row per patient per line
    proc.py        49                        the platinum spine

`dropDuplicates` keeps an ARBITRARY row of each group. When the assumption holds that is harmless,
and when it does not the build silently publishes whichever row the physical layout happened to put
first — a value chosen by partitioning, file order and shuffle, not by a rule anybody approved. The
same query can return a different patient's ECOG on a re-run, and nothing anywhere says so.

WHAT THIS DOES INSTEAD, in the order the review asked for:

  1. COLLAPSE EXACT DUPLICATES. Two byte-identical rows carry no disagreement, so removing one
     loses nothing. This is lossless and needs no policy.
  2. PICK BY A TOTAL ORDER. Whatever survives step 1 DISAGREES in at least one column, so ordering
     by the caller's rule and then by every remaining column, ascending, by name, is a total order
     over distinct rows. A total order makes the pick a function of the DATA — identical for any
     row permutation, any partition count, any Spark version.
  3. SAY THE ASSUMPTION OUT LOUD. `assert_one_row_per_key` counts the keys that needed step 2 and
     refuses. It costs an action, so it belongs in a preflight run once per source, not inline in
     a per-cohort stage — but the build stays deterministic either way, which is the point: the
     check tells you the grain is wrong, and step 2 means you do not get a DIFFERENT wrong answer
     each time while you find out.

WHY DETERMINISM IS NOT CORRECTNESS, and this module does not pretend otherwise. Picking the same
row every time is not the same as picking the RIGHT row. Which row is right is a specification
question — `same_date_conflict`, `record_selection: lowest|highest|worst|best`, a priority list —
and where a pack states one, the caller passes it as `order_by` and this honours it. Where the pack
states nothing, this makes the arbitrary pick STABLE and detectable rather than silent and moving.
That distinction is the whole reason the docstring of the older helper says a deterministic tie
"does not make it RIGHT".
"""
from __future__ import annotations


def _total_order(F, df, keys, order_by):
    """The caller's ordering, then every remaining column ascending by name.

    The tail is what makes it TOTAL. `order_by` alone is a partial order — two records on the same
    date tie under `date desc` and the tie is then broken by whatever the physical plan yields. The
    remaining columns cannot all tie, because step 1 removed the rows that are equal everywhere.
    """
    named = {str(c) for c in keys}
    for c in order_by:
        # A Column object stringifies to its expression; a plain name to itself. Either way the
        # point is only to avoid ordering by the same column twice.
        named.add(str(c).replace("DESC", "").replace("ASC", "").strip("' ").strip())
    # `asc_nulls_first` to match struct comparison, which is how the no-rule path above picks. The
    # two must not disagree about a tie, or the same data would yield two answers depending on
    # whether a caller happened to state a rule.
    tail = [F.col(c).asc_nulls_first() for c in sorted(df.columns) if c not in named]
    return list(order_by) + tail


def one_row_per_key(F, df, keys, *, order_by=()):
    """Exactly one row per `keys`, chosen by a total order. No action; returns a DataFrame.

    A drop-in for `dropDuplicates(keys)` that cannot return a different answer on a re-run.

    TWO PATHS, AND THE CHEAP ONE IS THE DEFAULT — measured, after the expensive one broke a build.
    The first version always used `row_number()` over a window. That is a full sort inside every
    key group, and the seven call sites run once per cohort: on prostate's seven-cohort union it
    pushed the shared local JVM over its heap and the production-union smoke died. Isolated it
    passed, which is exactly how a resource regression hides.

    With no caller-supplied rule, "first row under an ascending order over every column" is
    `min(struct(all columns))` — Spark compares structs field by field, so the answer is identical,
    but a `min` aggregate combines map-side instead of sorting each group. Same row, no sort.

    The window path is kept for the case it is actually needed: a caller-stated rule (`lowest`,
    `highest`, a priority list) can be descending, and `min` over a struct cannot express that.

    NO `distinct()` in either path, and that is a correctness argument rather than a saving.
    Ordering by every column means two byte-identical rows tie EXACTLY, so whichever is picked the
    emitted row has the same content. `conflicting_keys` DOES collapse first, because it asks the
    different question of whether a repeat is redundancy or disagreement.
    """
    keys = [keys] if isinstance(keys, str) else list(keys)
    rest = [c for c in df.columns if c not in set(keys)]
    if not rest:
        return df.dropDuplicates(keys)      # nothing but the key: every row in a group is identical

    if not order_by:
        # NULLS SORT FIRST here, because that is what struct comparison does, and the window path
        # below is aligned to it deliberately so the two paths cannot disagree about a tie.
        picked = (df.groupBy(*keys)
                    .agg(F.min(F.struct(*[F.col(c) for c in sorted(rest)])).alias("_s")))
        return picked.select(*keys, *[F.col(f"_s.{c}").alias(c) for c in sorted(rest)])

    from pyspark.sql import Window
    w = Window.partitionBy(*keys).orderBy(*_total_order(F, df, keys, order_by))
    return (df.withColumn("_rn", F.row_number().over(w))
              .filter(F.col("_rn") == 1)
              .drop("_rn"))


def conflicting_keys(F, df, keys):
    """(number of keys carrying more than one DISTINCT row, number of rows in them). One action.

    Counted AFTER the exact-duplicate collapse, because a source that repeats a row verbatim has a
    redundancy problem and a source that repeats it with a different value has a GRAIN problem, and
    only the second one changes what gets published.
    """
    keys = [keys] if isinstance(keys, str) else list(keys)
    g = df.distinct().groupBy(*keys).agg(F.count(F.lit(1)).alias("_n")).filter(F.col("_n") > 1)
    row = g.agg(F.count(F.lit(1)).alias("k"), F.coalesce(F.sum("_n"), F.lit(0)).alias("r")).collect()[0]
    return int(row["k"]), int(row["r"])


def assert_one_row_per_key(F, df, keys, name, policy="refuse"):
    """Refuse a source whose grain is not what the build assumes. Costs one action.

    `policy` mirrors `same_date_conflict`: `refuse` raises, `deterministic` permits the stable pick
    and says nothing. There is deliberately no `ignore`: the two honest answers are "stop" and
    "proceed on a rule I have written down", and a third that means "proceed and do not tell me"
    is how the arbitrary pick became invisible in the first place.
    """
    if str(policy) != "refuse":
        return None
    k, r = conflicting_keys(F, df, keys)
    if k:
        raise ValueError(
            f"{name}: {k} key(s) over {tuple(keys)} carry {r} rows that DISAGREE — this source is "
            f"read as one row per key, so one of each group would be published and the others "
            f"dropped by physical row order. Fix the source, or state the rule that chooses "
            f"between them (`record_selection` / `same_date_conflict`) so the choice is the "
            f"specification's and not the file layout's.")
    return None


def source_grain_report(F, src, cfg) -> dict:
    """Every declared source grain, checked against the LOADED sources. Counts only, no values.

    {role: {"unique_by": [...], "rows": int, "duplicate_keys": int, "duplicate_rows": int,
            "passed": bool}}                                    — the declaration held or it did not
    {role: {"unique_by": [...], "skipped": why}}                — could not be checked, and says why

    The three-way split is the point, and it is the same split the availability states draw: a
    declaration that HELD, a declaration that FAILED, and a declaration NOBODY CHECKED must never
    collapse into one green. `skipped` covers a role the run did not load and a declared column the
    delivered frame does not carry — both are honest "not checked", never a pass.

    Counts only, deliberately: a sample of offending keys would put patient ids into a report that
    travels into manifests and chat, and the profiler just spent a change making exactly that class
    of leak impossible. The keys are recomputable on the governed platform by whoever holds the
    data: `grain.conflicting_keys(F, df, unique_by)`.

    An expansion ratio needs no separate metric: duplicate_rows / rows IS the join-inflation bound
    a one-row-per-key consumer would suffer, and the review's "a join-expansion ratio above 1 is
    not automatically wrong for event data" is exactly why only DECLARED grains are checked —
    event-shaped sources simply declare nothing until a person states their true key.
    """
    try:                                     # package import (the build)
        from . import validate as _v
    except ImportError:                      # engine/ on sys.path (validate.py CLI, test_blocks)
        import validate as _v
    declared, errors = _v.source_grain(cfg)
    out = {}
    for role, cols in sorted(declared.items()):
        df = src.get(role)
        if df is None:
            out[role] = {"unique_by": cols, "skipped": "source not loaded in this run"}
            continue
        missing = [c for c in cols if c not in df.columns]
        if missing:
            out[role] = {"unique_by": cols,
                         "skipped": f"declared unique_by column(s) absent from the delivered "
                                    f"table: {', '.join(missing)}"}
            continue
        rows = df.count()
        dup = (df.groupBy(*cols).count().where(F.col("count") > 1)
                 .agg(F.count(F.lit(1)).alias("k"), F.sum(F.col("count")).alias("r"))
                 .collect()[0])
        dup_keys = int(dup["k"] or 0)
        dup_rows = int(dup["r"] or 0)
        out[role] = {"unique_by": cols, "rows": int(rows), "duplicate_keys": dup_keys,
                     "duplicate_rows": dup_rows, "passed": dup_keys == 0}
    if errors:
        out["_declaration_errors"] = list(errors)
    return out


def source_grain_gate(report: dict) -> dict:
    """{passed, failures, unchecked} over a source_grain_report — the manifest-shaped verdict.

    A DECLARED grain that could not be checked FAILS. The first version listed unchecked entries
    but passed anyway, and an external review named the hole: declare a grain on a key column the
    delivery does not carry, and the gate reports green with the claim never tested. A pack that
    declares a grain has made a claim; "the run could not look" refuses, and the entry still
    appears under `unchecked` so the reason is readable next to the failure.
    """
    failures, unchecked = [], []
    for role, r in sorted(report.items()):
        if role == "_declaration_errors":
            failures.extend(report[role])
            continue
        if "skipped" in r:
            unchecked.append(f"{role}: {r['skipped']}")
            failures.append(f"{role}: declared grain could not be checked ({r['skipped']}) — a "
                            f"declaration the run cannot test must fail, not report itself and "
                            f"pass")
        elif not r.get("passed"):
            failures.append(f"{role}: {r['duplicate_keys']} key group(s) carry {r['duplicate_rows']} "
                            f"rows against declared grain ({', '.join(r['unique_by'])}) — a "
                            f"one-row-per-key consumer would take an arbitrary row from each")
    return {"passed": not failures, "failures": failures, "unchecked": unchecked}

