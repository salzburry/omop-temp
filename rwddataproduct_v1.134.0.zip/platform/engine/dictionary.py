"""Data dictionary generation — the consumer-facing variable spec, per audience.

Generalises the legacy build_dictionary audience model (internal / sales / customer) to NEUTRAL
audiences: `internal` / `partner` / `customer` — **`partner` replaces the customer-specific
"sales"**. Built from the master catalog (metadata/catalog.yaml), filtered by tumor
applicability + per-variable `pii`/`audiences` flags, and projected to the audience's columns.

Pure-Python: build_dictionary() + render_markdown(). Observed-value / %-patients statistics are an
optional `stats` input (computed from the ADS on a cluster) — keyed by variable code.

    python engine/dictionary.py <catalog.yaml> --audience partner [--tumor mcrpc]
"""
from __future__ import annotations

import sys

try:
    from .config import load_yaml
except ImportError:
    from config import load_yaml

# Neutral audience contract (override via dictionary/audiences.yaml). `partner` = the old "sales".
DEFAULT_AUDIENCES = {
    "internal": {"columns": ["category", "code", "label", "applies_to"], "drop_pii": False},
    "partner":  {"columns": ["category", "label"], "drop_pii": True},
    "customer": {"columns": ["category", "label", "applies_to"], "drop_pii": True},
}


def load_audiences(path=None) -> dict:
    if path is None:
        return dict(DEFAULT_AUDIENCES)
    return load_yaml(path).get("audiences", DEFAULT_AUDIENCES)


def _applies(var: dict, tumor) -> bool:
    a = var.get("applies_to", "all")
    return a == "all" or tumor is None or tumor in a


def build_dictionary(catalog: dict, audience="internal", tumor=None, audiences=None, stats=None,
                     columns=None) -> dict:
    """Build the dictionary structure for one audience (+ optional tumor filter + ADS stats).

    `columns` (the ACTUAL built-ADS columns, passed by the runner) restricts the dictionary to what is
    genuinely emitted — mirroring dashboard.build_manifest — so a catalog-applicable but feed-absent
    OPTIONAL variable (an absent PSA-at-diagnosis pass-through, or a conmed flag whose source lacks the
    drug-name column) is NOT advertised. Without it the dictionary is catalog-applicability based (the
    static/test view).
    """
    aud = audiences or DEFAULT_AUDIENCES
    if audience not in aud:
        raise KeyError(f"unknown audience '{audience}'; have {sorted(aud)}")
    spec = aud[audience]
    cols, drop_pii = spec["columns"], spec.get("drop_pii", False)
    allowed = {c.lower() for c in columns} if columns is not None else None

    rows = []
    for v in catalog.get("variables", []):
        if not _applies(v, tumor):
            continue
        # `line_template` rows (lotN / lotNsd / …) document the per-line family COMPACTLY (one row each,
        # the N standing for the line number). They are exempt from the actual-column filter — their
        # concrete lot{i}* columns are what land in the ADS — so the dictionary still describes the family.
        if (allowed is not None and not v.get("line_template")
                and str(v.get("code")).lower() not in allowed):                # not emitted in this ADS
            continue
        if drop_pii and v.get("pii"):                      # PII never ships to partner/customer
            continue
        if audience not in v.get("audiences", list(aud)):  # per-variable audience restriction
            continue
        row = {c: v.get(c) for c in cols}
        if stats and v.get("code") in stats:               # observed values / % patients, if given
            row.update(stats[v["code"]])
        rows.append(row)

    cats = sorted({r.get("category") for r in rows if r.get("category")})
    return {"audience": audience, "tumor": tumor, "columns": cols,
            "summary": {"n_variables": len(rows), "categories": cats},
            "variables": rows}


def _cell(value):
    """Flatten a catalog value into one dictionary cell: a list (e.g. applies_to: [oc, ec]) becomes a
    comma-joined string, None becomes empty, scalars pass through. Keeps markdown tidy and lets
    openpyxl serialize the cell (it rejects list values)."""
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        return ", ".join(str(x) for x in value)
    return value


def render_markdown(d: dict) -> str:
    from collections import defaultdict
    head = f"# Data dictionary — audience: {d['audience']}"
    if d.get("tumor"):
        head += f" — tumor: {d['tumor']}"
    lines = [head, "",
             f"**Variables:** {d['summary']['n_variables']}  |  "
             f"**Categories:** {', '.join(d['summary']['categories'])}", ""]
    show = [c for c in d["columns"] if c != "category"]
    by_cat = defaultdict(list)
    for r in d["variables"]:
        by_cat[r.get("category", "")].append(r)
    for cat in sorted(by_cat):
        lines += [f"## {cat}", "", "| " + " | ".join(show) + " |",
                  "|" + "|".join(["---"] * len(show)) + "|"]
        for r in by_cat[cat]:
            lines.append("| " + " | ".join(str(_cell(r.get(c))) for c in show) + " |")
        lines.append("")
    return "\n".join(lines)


def render_xlsx(d: dict, path: str) -> str:
    """Write the dictionary to an .xlsx (Summary + Variables sheets). Needs openpyxl.

    Same content as render_markdown — the styled stakeholder format the legacy build_dictionary
    produced, but driven by the catalog + neutral audiences.
    """
    from openpyxl import Workbook
    from openpyxl.styles import Font

    wb = Workbook()
    s = wb.active
    s.title = "Summary"
    s.append(["Data dictionary", d["audience"] + (f" / {d['tumor']}" if d.get("tumor") else "")])
    s.append(["Variables", d["summary"]["n_variables"]])
    s.append(["Categories", ", ".join(d["summary"]["categories"])])
    s["A1"].font = Font(bold=True)

    v = wb.create_sheet("Variables")
    v.append(list(d["columns"]))
    for c in v[1]:
        c.font = Font(bold=True)
    for r in d["variables"]:
        v.append([_cell(r.get(c)) for c in d["columns"]])
    wb.save(path)
    return path


def main(argv):
    if len(argv) < 2:
        print("usage: python engine/dictionary.py <catalog.yaml> [--audience X] [--tumor Y] [--xlsx out.xlsx]")
        return 2
    catalog = load_yaml(argv[1])
    audience = argv[argv.index("--audience") + 1] if "--audience" in argv else "internal"
    tumor = argv[argv.index("--tumor") + 1] if "--tumor" in argv else None
    d = build_dictionary(catalog, audience=audience, tumor=tumor)
    if "--xlsx" in argv:
        print("wrote " + render_xlsx(d, argv[argv.index("--xlsx") + 1]))
    else:
        print(render_markdown(d))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
