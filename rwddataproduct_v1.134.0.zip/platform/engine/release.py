"""Publish a CONSISTENT (ADS + TFLs) release: an ATOMIC pointer, and views for compatibility.

Each BUILD writes IMMUTABLE versioned tables ({final}__{refresh}__{build_id}[ __tfl_{tid}]) — the
build_id (a git SHA or run timestamp) makes a same-refresh rerun a NEW physical table, never an
overwrite of the table a live view already points at.

TWO SURFACES, AND ONLY ONE OF THEM IS ATOMIC.

  {final}__release   ONE ROW, resolved through by a consumer that needs the whole set at once. It is
                     written by a single Delta `INSERT OVERWRITE` — one transaction — so a reader
                     sees the whole previous release or the whole new one and never a mixture. This
                     is the commit anchor: the release is published when the pointer says so.

  {final}, {final}__tfl_{tid}   VIEWS, swapped one statement at a time because Databricks has no
                     transaction across DDL. TFLs first and the ADS last bounds it — a consumer
                     anchored on the ADS view sees the previous release until the last statement —
                     but a consumer reading a TFL view directly can still catch this build's TFL
                     beside the previous build's ADS. They remain because they are what everything
                     already reads; removing them would break consumers to fix a race they may not
                     have.

The pointer was described here as future work for as long as the race was described as a caveat.
`products/OPERATIONS.md` told consumers to anchor on the ADS view, which is a convention asking
readers to be careful rather than a guarantee that they need not be.

Pure Python: naming, the SQL, and the pointer record. The runner executes it on Spark.
"""
from __future__ import annotations

import hashlib


def versioned_ads(final: str, refresh: str, build_id: str) -> str:
    return f"{final}__{refresh}__{build_id}"


def versioned_tfl(final: str, refresh: str, build_id: str, tid: str) -> str:
    return f"{final}__{refresh}__{build_id}__tfl_{tid}"


def public_tfl(final: str, tid: str) -> str:
    return f"{final}__tfl_{tid}"


def staging_ads(final: str, build_id: str) -> str:
    """The pre-publish staging table, scoped to ONE run.

    It was `final + "__staging"` in the notebook — one name shared by every run of the product. A
    validate-only run deliberately KEEPS its staging tables so they can be inspected, and the next run
    overwrote them, so the manifest pointing at that evidence was build-scoped while the evidence was
    not; two runs at once (a retry, a manual run beside the schedule) also raced for the table. It
    belongs here beside `versioned_ads` because this file owns what a release's tables are called.
    """
    return f"{final}__staging__{build_id}"


def staging_tfl(final: str, build_id: str, tid: str) -> str:
    return f"{staging_ads(final, build_id)}__tfl_{tid}"


def view_swap_sql(public: str, versioned: str) -> str:
    """SQL to point the stable public name at a versioned table — non-destructive + idempotent.

    CREATE OR REPLACE VIEW atomically replaces the view definition. (One-time migration: if a public
    name currently exists as a TABLE from a pre-pointer deployment it must be dropped once so the view
    can take the name — the runner preflights this; a brand-new product has no such table.)
    """
    return f"CREATE OR REPLACE VIEW {public} AS SELECT * FROM {versioned}"


def stale_public_tfls(existing_public, final: str, current_ids) -> list:
    """Public TFL view names that EXIST but are NOT in the current release (a spec dropped the TFL) —
    their views would keep serving the PREVIOUS build's data. The runner records these as `retired_tfls`
    so the ledger is honest; it never auto-drops a consumer-readable view. `existing_public` is the set
    of public TFL view names currently in the schema (e.g. from SHOW TABLES). Pure set difference."""
    current = {public_tfl(final, tid) for tid in (current_ids or [])}
    return sorted(n for n in (existing_public or []) if n not in current)


def swap_plan(final: str, refresh: str, build_id: str, tfl_ids) -> list:
    """Ordered (public, versioned, sql) view swaps — TFLs FIRST, the ADS LAST (the commit anchor)."""
    pairs = [(public_tfl(final, tid), versioned_tfl(final, refresh, build_id, tid))
             for tid in (tfl_ids or [])]
    pairs.append((final, versioned_ads(final, refresh, build_id)))      # ADS view swapped last
    return [(pub, ver, view_swap_sql(pub, ver)) for pub, ver in pairs]


def candidate_probe_statements(table: str) -> tuple:
    """(history_sql, detail_sql) — the two commands that observe ONE staged table's identity.

    THE APPROVAL COVERED A NAME. `promotion_blockers` asked whether a table CALLED
    `ads__staging__<build_id>` exists, and the manifest the approver signed recorded no physical fact
    about it at all — so a candidate whose bytes had been replaced under the same name promoted
    cleanly, wearing an approval of the bytes that used to be there. `build_id` embeds the job run id,
    which makes that unlikely by accident; it does not make it checked, and "unlikely" is not the
    property a release gate is for.

    TWO STANDALONE COMMANDS, NOT ONE SELECT. The first version of this wrapped them —
    `SELECT (SELECT MAX(version) FROM (DESCRIBE HISTORY t))` — and `DESCRIBE HISTORY` and
    `DESCRIBE DETAIL` are Databricks COMMANDS, not relations a subquery may read. The whole probe
    would have raised on a cluster; the runner caught it, recorded no identity, and carried on to
    print approval instructions for a candidate that could never be promoted. That is the shape of
    every defect this file exists to prevent, written into the check itself, and nothing offline
    could see it because nothing offline executes SQL.

    `LIMIT 1` on the history rather than `MAX(version)`: the command returns newest-first, and the
    aggregate was the thing that needed the illegal subquery.
    """
    return (f"DESCRIBE HISTORY {table} LIMIT 1", f"DESCRIBE DETAIL {table}")


def count_at_version_sql(table: str, delta_version) -> str:
    """Rows AT the version just observed — not "now", which is a different question.

    Counting the live table leaves a gap: the history says version 7, the count runs, and a write
    between them counts version 8's rows against version 7's identity. Reading the version closes it,
    and it is the same statement the promotion materialise uses, for the same reason.
    """
    return f"SELECT COUNT(*) AS row_count FROM {table} VERSION AS OF {int(delta_version)}"


def candidate_row(table: str, history, detail, row_count) -> dict:
    """One assembled observation from the two command outputs. The runner passes what Spark returned.

    `DESCRIBE DETAIL` names its columns `id`, `location`, `format`, `numFiles`, `sizeInBytes`;
    `DESCRIBE HISTORY` names the newest entry's `version`. Reading them HERE means the runner does no
    schema knowledge of its own and a change to either command is one edit.
    """
    h = dict(history or {})
    d = dict(detail or {})
    return {"table_name": table,
            "table_id": str(d.get("id") or "").strip() or None,
            "location": str(d.get("location") or "").strip() or None,
            "table_format": str(d.get("format") or "").strip() or None,
            "delta_version": _as_int(h.get("version")),
            "row_count": _as_int(row_count),
            "num_files": _as_int(d.get("numFiles")),
            "size_bytes": _as_int(d.get("sizeInBytes"))}


def input_lineage_row(fqn: str, history, detail) -> dict:
    """One INPUT's identity from the same two commands the candidate probe runs.

    The manifest recorded source NAMES and the git commit — which pins the code and not the data:
    the same checkout and refresh id read whatever the table held that day, so two runs of one
    "reproducible" build could consume different records with nothing recording that they had.
    id + version is the same identity the promotion refuses on, pointed at the INPUTS: `VERSION AS
    OF delta_version` on this table_id re-reads the exact bytes this build read.

    No row_count, deliberately — counting every input on every run is a cost decision the identity
    does not need; the id+version pair already names the bytes. And a NON-Delta input is a caller
    problem, not this function's: it collapses what the commands returned, and the caller records
    an error entry for a table the commands refused (fail-closed: an input with no recordable
    lineage is named in the manifest, never silently absent).
    """
    h = dict(history or {})
    d = dict(detail or {})
    return {"fqn": fqn,
            "table_id": str(d.get("id") or "").strip() or None,
            "table_format": str(d.get("format") or "").strip() or None,
            # the STORAGE location, same as the output identity pins it: a name re-pointed at a
            # different path is a different table however its id and version read
            "location": str(d.get("location") or "").strip() or None,
            "delta_version": _as_int(h.get("version")),
            "last_commit_at": str(h.get("timestamp") or "").strip() or None}


# THE FIELDS THAT DECIDE WHETHER TWO OBSERVATIONS ARE THE SAME TABLE AT THE SAME POINT.
#
# `table_id` is Delta's own UUID for the table and it is why a version alone is not enough: DROP the
# staging table, CREATE it again and write the same number of rows, and the replacement can carry the
# same version with a different transaction log behind it. `VERSION AS OF` would then resolve against
# a table nobody approved and every numeric check would agree. The id changes on a recreate and does
# not change on a write, which is exactly the distinction the version cannot draw.
#
# `num_files` and `size_bytes` are recorded and NOT compared: an OPTIMIZE or a vacuum rewrites files
# and changes both without changing a single row, and a gate that refused that would be routed around
# within a month. The version moves for those too, which is the point — somebody did write to an
# approved candidate, and a release is exactly where that should be noticed.
#
# `location` IS compared: table_id alone rides the catalog entry, and a drop/recreate that reuses a
# name can wear a fresh id while the comparison only notices if the id was recorded — the storage
# path is the half of the identity the catalog cannot silently re-point (an external review's
# rebind probe is what put it here).
IDENTITY_FIELDS = ("table_id", "location", "delta_version", "row_count")


def candidate_identity(observations) -> dict:
    """{table: {table_id, location, delta_version, row_count, …}} from the runner's assembled rows.

    Normalised HERE so the manifest, the comparison and any later report read one shape. The runner
    hands back whatever its SQL layer produced — Row objects, dicts, decimals — and every one of those
    compares unequal to an int loaded back out of YAML.
    """
    out = {}
    for row in observations or []:
        d = dict(row) if not isinstance(row, dict) else row
        name = str(d.get("table_name") or "").strip()
        if not name:
            continue
        out[name] = {"table_id": d.get("table_id") or None,
                     "location": d.get("location") or None,
                     "table_format": d.get("table_format") or None,
                     "delta_version": _as_int(d.get("delta_version")),
                     "row_count": _as_int(d.get("row_count")),
                     "num_files": _as_int(d.get("num_files")),
                     "size_bytes": _as_int(d.get("size_bytes"))}
    return out


def _as_int(v):
    """An observed number as a plain int, or None. Decimal, str and Row values all arrive here."""
    if v is None:
        return None
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def identity_blockers(approved, observed, expected=None) -> list:
    """[why the staged bytes are not the ones that were approved]. Empty means they are.

    THE SET FIRST, THEN THE VALUES, and the set check is the one that was missing. `expected` is every
    staging table this promotion will read. The first version iterated the RECORDED keys only, so a
    candidate whose ADS probe succeeded and whose TFL probe failed was signed with the ADS alone —
    and promotion then pinned the ADS, verified the ADS, and published the TFL from whatever was in
    staging at that moment, unpinned and unverified, with no message anywhere. Partial evidence read
    as complete evidence because the missing part was missing from both sides of the comparison.

    So the invariant is stated and enforced: expected == recorded == observed. Anything else refuses.

    FAIL-CLOSED ON ABSENCE, in every direction. An approved candidate with no recorded identity is a
    manifest written before this existed — it cannot be checked and must say so rather than pass; an
    observation that came back empty is a probe that did not run, which is not evidence that nothing
    moved. "Unstated" is not "unchanged", and a release gate is where that distinction is load-bearing.
    """
    approved, observed = approved or {}, observed or {}
    if not approved:
        return ["the approved candidate manifest records no physical identity for its staged tables, "
                "so nothing can say whether the bytes are the ones that were approved. Rebuild and "
                "have the new candidate approved — a manifest from before this check existed cannot "
                "be verified after the fact."]
    why = []
    if expected is not None:
        want = set(expected)
        unrecorded = sorted(want - set(approved))
        unobserved = sorted(want - set(observed))
        extra = sorted(set(approved) - want)
        if unrecorded:
            why.append(f"the approved candidate records no identity for {', '.join(unrecorded)}, "
                       f"which this promotion would publish. A candidate is approved whole or not at "
                       f"all — publishing the part that was measured and the part that was not is "
                       f"how unapproved bytes reach production under a valid signature.")
        if unobserved:
            why.append(f"this run observed no identity for {', '.join(unobserved)} — the probe did "
                       f"not run, which is not the same as nothing having changed.")
        if extra:
            why.append(f"the approved candidate records {', '.join(extra)}, which this promotion "
                       f"does not publish. The signed set and the published set differ.")
    for table in sorted(approved):
        was, now = approved[table] or {}, observed.get(table)
        if now is None:
            why.append(f"{table}: the approval records its identity and this run observed none — the "
                       f"probe did not run, which is not the same as nothing having changed")
            continue
        for field in IDENTITY_FIELDS:
            a, b = was.get(field), now.get(field)
            if a is None or b is None:
                why.append(f"{table}: {field} is unrecorded "
                           f"({'approval' if a is None else 'observation'} side), so this candidate "
                           f"cannot be verified")
            elif a != b:
                why.append(f"{table}: {field} was {a!r} when this candidate was approved and is "
                           f"{b!r} now — this is not the table, at the point, that anybody signed")
    return why


def materialise_sql(versioned: str, staging: str, delta_version=None, build_id=None) -> str:
    """SQL to make the IMMUTABLE versioned table from the staged bytes a candidate was approved over.

    `CREATE TABLE ... AS SELECT *` and deliberately not `OR REPLACE`: the versioned name is the
    permanent identity of one build, so a statement that could overwrite it would let a second
    promotion of the same build_id rewrite bytes a consumer view may already be serving. Existence is
    checked before this runs (`promotion_blockers`); this makes the engine refuse it as well, because
    a precondition and the statement it protects should not be able to disagree.

    `VERSION AS OF` WHEN THE CANDIDATE IS PINNED, and this is not redundant with the refusal above it.
    `promotion_blockers` reads the table's version, and then this statement reads the table — two
    reads with a gap between them, and a write landing in that gap publishes bytes the check just
    approved of and nobody signed. Time-travel closes it: the statement names the version that was
    approved, so what gets published cannot be anything else, whatever happened in between.

    THERE IS NO UNPINNED FORM. It used to fall back to reading the live table when no version was
    supplied, which meant a table missing from a partial identity record was published from whatever
    staging held at that moment — the fallback WAS the hole, sitting one `.get()` away from the check
    that was supposed to close it. A caller with no version has not established what it is publishing,
    and that is a programming error rather than a governance state: `identity_blockers` refuses the
    governance state long before this, so reaching here without a version cannot happen legitimately.
    """
    if delta_version is None:
        raise ValueError(
            f"refusing to materialise {versioned} from {staging} with no approved Delta version. "
            f"An unpinned read publishes whatever staging holds now, which is the defect the "
            f"candidate identity exists to prevent.")
    # THE BUILD TAG. Reconcile confirms an existing versioned table by count — and a same-count
    # table is not the same bytes. The tag names which promotion made it, so a resume trusts only
    # its own work (same table property Delta persists across readers).
    # `USING DELTA`, STATED — not inherited from `spark.sql.sources.default`. Every identity this
    # module later asks of the versioned table (DESCRIBE HISTORY, DESCRIBE DETAIL, the journaled
    # output identity a resume re-probes) is a Delta-only answer; a workspace whose default format
    # is anything else would materialise a table the promotion cannot account for. Running this
    # against open-source Spark (parquet default) is what surfaced it.
    props = f" TBLPROPERTIES ('rwdp_build_id' = {_sql_str(str(build_id))})" if build_id else ""
    return (f"CREATE TABLE {versioned} USING DELTA{props} AS SELECT * FROM {staging} "
            f"VERSION AS OF {int(delta_version)}")


def promotion_blockers(final: str, refresh: str, build_id: str, tfl_ids, existing,
                       approved_identity=None, observed_identity=None, resuming=()) -> list:
    """[why this approved candidate may not be promoted] — the PHYSICAL half of Gate 6.

    `publish_approval_errors` answers "does a named person's approval bind this build_id and this
    manifest digest". That is the paperwork, and it is necessary; it says nothing about whether the
    bytes that approval describes are still on the cluster. Promotion is the one step in this
    framework that publishes something it did not just build, so what it publishes has to be checked
    rather than assumed.

    `existing` is the set of table names the output schema currently holds — from `SHOW TABLES`, which
    the runner has and this module must not.

    Three refusals, and they fail in different directions:

      staging GONE       the approved bytes no longer exist. Rebuilding would mint a new build_id and
                         a new manifest digest, so it would not be the approved candidate — it would
                         be a different product wearing an approval. There is no safe automatic
                         recovery: build again and have the new candidate approved.
      versioned PRESENT  this build was already promoted BY SOMETHING ELSE. The versioned table is
                         immutable and a public view may already serve it, so re-materialising would
                         rewrite published bytes. A table THIS promotion's own journal records and
                         `reconcile` has verified is passed in `resuming` and is not this refusal —
                         it is a completed step of the run being continued.
      identity MOVED     a table with the right NAME holds bytes that are not the approved ones.
                         This is the refusal the first two cannot make: both are questions about
                         which names exist, and a candidate is not a name. `approved_identity` is
                         what the signed manifest recorded; `observed_identity` is what this run just
                         probed. Passing neither is itself refused — see `identity_blockers`.
    """
    have = set(existing or [])
    # A VERSIONED TABLE THIS PROMOTION ITSELF MADE IS NOT SOMEBODY ELSE'S RELEASE. `resuming` comes
    # from `reconcile` — the durable journal's tables, confirmed to hold the approved row count — and
    # a blanket "already promoted" refusal over them is what made an interrupted promotion
    # unrecoverable: the retry was refused for having got half way, and the operator was told to drop
    # tables a public view might already serve.
    mine = set(resuming or ())
    pairs = promotion_pairs(final, refresh, build_id, tfl_ids)
    missing, already = [], []
    for ver, stg in pairs:
        if ver in have and ver not in mine:
            already.append(ver)
        elif stg not in have:
            missing.append(stg)
    # THE EXPECTED SET IS DERIVED FROM THE PLAN, not passed in. It is exactly the staging tables this
    # promotion will read, so a candidate signed over a different set — one table short, one table
    # extra — is refused rather than partially honoured.
    why = list(identity_blockers(approved_identity, observed_identity, {stg for _v, stg in pairs}))
    if missing:
        why.append(
            f"the approved candidate's staged bytes are gone: {', '.join(sorted(missing)[:4])}. "
            f"Promotion publishes what was approved; it does not rebuild. A fresh build mints a new "
            f"build_id and a new manifest digest, so it is a different candidate and needs its own "
            f"approval.")
    if already:
        why.append(
            f"build {build_id} is already promoted: {', '.join(sorted(already)[:4])} exists. A "
            f"versioned table is immutable and a public view may already serve it.")
    return why


def promotion_pairs(final: str, refresh: str, build_id: str, tfl_ids):
    """[(versioned, staging)] for the ADS and each TFL — the one place the pairing is stated.

    PUBLIC because the runner needs the exact identifiers too: to ask whether each one exists, and to
    probe each staged table's identity. It used to rebuild those name lists itself, which is how the
    existence check came to compare fully qualified names against bare ones.
    """
    pairs = [(versioned_tfl(final, refresh, build_id, tid), staging_tfl(final, build_id, tid))
             for tid in (tfl_ids or [])]
    pairs.append((versioned_ads(final, refresh, build_id), staging_ads(final, build_id)))
    return pairs


def promotion_plan(final: str, refresh: str, build_id: str, tfl_ids, approved_identity=None,
                   done=()) -> list:
    """Ordered (step, target, source, sql) to publish an already-built, already-approved candidate.

    MATERIALISE EVERYTHING, THEN SWAP. Every versioned table is created before any public view moves,
    so a failure part-way through leaves the public names on the previous release rather than half
    of this one. Within the swap the existing order holds — TFLs first, the ADS last as the commit
    anchor — for the same reason it holds in a build-and-publish run.

    This is the step that lets an approval survive. A rerun mints a new `build_id`, which moves the
    manifest digest, which is why an approval of build A could never be satisfied by a later run B:
    the only way to honour it is to publish A's bytes without rebuilding, which is what this plans.

    EACH READ IS PINNED TO THE APPROVED VERSION when `approved_identity` carries one. The blockers
    ran before this; a write landing between the check and the statement would otherwise be published
    with the check's blessing, which is the classic gap between asking and acting. Naming the version
    in the statement removes the gap rather than narrowing it.

    `done` NAMES VERSIONED TABLES A PREVIOUS ATTEMPT ALREADY MADE AND THIS ONE VERIFIED — from
    `reconcile`, never from a guess. Skipping them is what makes a resume possible at all:
    `CREATE TABLE ... AS SELECT` fails on an existing name, so without this a crashed promotion could
    only be retried by dropping tables a public view might already serve.
    """
    pinned = {t: (v or {}).get("delta_version") for t, v in (approved_identity or {}).items()}
    finished = set(done or ())
    steps = [("materialise", ver, stg, materialise_sql(ver, stg, pinned.get(stg),
                                                        build_id=build_id))
             for ver, stg in promotion_pairs(final, refresh, build_id, tfl_ids)
             if ver not in finished]
    # THE SWAPS ARE NEVER SKIPPED. `CREATE OR REPLACE VIEW` is idempotent, and re-pointing a view at
    # the table it already serves costs nothing — while working out which views a crashed run had
    # reached would be a second, fallible answer to a question the statement answers for free.
    steps += [("swap", pub, ver, sql)
              for pub, ver, sql in swap_plan(final, refresh, build_id, tfl_ids)]
    return steps


# ---------------------------------------------------------------------------------------------
# WHICH RELEASE THIS PROMOTION EXPECTS TO REPLACE.
#
# Nothing bound a promotion to the state of the world it was approved against. Build A is staged and
# signed; build B is built, approved and published while A waits; A is then promoted and moves every
# public view BACKWARDS onto older data, with every check passing — A's bytes are exactly the bytes
# A's approver signed. The approval was never wrong; it was never about the release it would replace.
#
# So the candidate run records what the public views point at NOW, before the digest is taken, and
# promotion re-reads and refuses a difference. That is a compare-and-set, and it needs no clock and no
# ordering between build ids: it catches a newer release, a rollback somebody did by hand, and a view
# repointed at another product's table, all as the same event — "this is not the release I was
# approved to replace".
def view_target(view_text) -> str:
    """The versioned table a public view serves, read from its `View Text`. "" when unreadable.

    THE INVERSE OF `view_swap_sql`, which is why it lives here: this module writes
    `CREATE OR REPLACE VIEW p AS SELECT * FROM v`, so it is the module that may read it back. A parse
    living anywhere else would be a second opinion about a statement it does not own.
    """
    text = " ".join(str(view_text or "").split())
    marker = " FROM "
    at = text.upper().rfind(marker)
    if at < 0:
        return ""
    return text[at + len(marker):].strip().rstrip(";").strip()


def observed_release(view_texts) -> dict:
    """{public view: versioned table} from {public view: its View Text}. Absent view -> None.

    None is a REAL VALUE here and not a gap: a product with no release yet has no view, and "there is
    nothing to replace" is a state a candidate can legitimately be approved against. Conflating it
    with "unknown" is what would let the first promotion of a product be refused forever.
    """
    return {pub: (view_target(txt) or None) for pub, txt in (view_texts or {}).items()}


def supersedes_blockers(expected, observed) -> list:
    """[why the release this promotion would replace is not the one it was approved against]."""
    expected, observed = dict(expected or {}), dict(observed or {})
    if not expected:
        return ["the approved candidate does not record which release it supersedes, so nothing can "
                "say whether the public views have moved since it was approved. Rebuild and have "
                "the new candidate approved."]
    why = []
    for pub in sorted(set(expected) | set(observed)):
        was, now = expected.get(pub, "(not recorded)"), observed.get(pub)
        if was != now:
            why.append(
                f"{pub} served {was or 'nothing (no release yet)'} when this candidate was approved "
                f"and serves {now or 'nothing'} now. Promoting would replace a release this approval "
                f"was not about — possibly moving consumers BACKWARDS onto older data. A deliberate "
                f"rollback is its own approved operation, not a side effect of a late promotion.")
    return why


# ---------------------------------------------------------------------------------------------
# ONE PROMOTION PER PRODUCT AT A TIME.
#
# Two promotions of the same product interleaving their view swaps can leave the public set mixed:
# A's TFL beside B's ADS, each run believing it published a consistent release. The swap order
# (TFLs, then the ADS as the commit anchor) bounds what a CONSUMER sees within one run; it says
# nothing about two runs.
#
# The mutex is a table CREATE. The metastore refuses a name that exists — verified against Delta,
# not assumed — so exactly one caller wins, and the loser sees a refusal naming who holds it. It is
# deliberately not a lease with a timeout: an expiring lock would let a second promotion start while
# a slow first one is mid-swap, which is the failure it exists to prevent. A stale lock is a person's
# decision, and the row says whose.
LOCK_SUFFIX = "__promotion_lock"


def promotion_lock(final: str) -> str:
    """The lock table for one product. Keyed on the public ADS name — the product's own identity."""
    return f"{final}{LOCK_SUFFIX}"


def _sql_str(value) -> str:
    return "'" + str(value if value is not None else "").replace("'", "''") + "'"


def acquire_lock_sql(final: str, build_id: str, actor: str, at: str, attempt_id: str = "") -> str:
    """SQL that succeeds for exactly one caller. `CREATE TABLE` on an existing name is refused.

    `USING DELTA`, stated: the takeover (`takeover_lock_sql`) is a compare-and-set that rides
    Delta's transactional UPDATE — a lock table created in a workspace whose default format is
    anything else would refuse the UPDATE, or worse, not serialise it.
    """
    return (f"CREATE TABLE {promotion_lock(final)} USING DELTA AS SELECT "
            f"{_sql_str(build_id)} AS build_id, {_sql_str(actor)} AS actor, "
            f"{_sql_str(at)} AS acquired_at, {_sql_str(attempt_id)} AS attempt_id")


def release_lock_sql(final: str) -> str:
    return f"DROP TABLE IF EXISTS {promotion_lock(final)}"


def takeover_lock_sql(final: str, build_id: str, old_attempt: str, new_attempt: str,
                      actor: str, at: str) -> str:
    """The COMPARE-AND-SET that consumes a resume token — one Delta UPDATE, one transaction.

    `lock_blockers` accepting `resume_promotion=<old attempt>` used to be the whole takeover, and
    the lock row kept the DEAD attempt's id — so the same token authorised every invocation that
    presented it, and an external review ran two takeovers of one dead attempt concurrently. The
    predicate here is the compare (build AND the old attempt) and the SET installs the new attempt;
    concurrent takeovers serialize on the Delta commit and the loser matches ZERO rows, which the
    runner must treat as losing, never as done.
    """
    return (f"UPDATE {promotion_lock(final)} SET attempt_id = {_sql_str(new_attempt)}, "
            f"actor = {_sql_str(actor)}, acquired_at = {_sql_str(at)} "
            f"WHERE build_id = {_sql_str(build_id)} AND attempt_id = {_sql_str(old_attempt)}")


LOCK_FIELDS = ("build_id", "actor", "acquired_at", "attempt_id")


def lock_row_errors(rows) -> list:
    """[why the lock TABLE's contents are not a usable lock]. [] only for exactly one complete row.

    The runner read `rows[0]` and an empty table read as "no holder" — but an existing lock table
    with zero rows, two rows, or a row missing its attempt is not an absent lock, it is a MALFORMED
    one, and every malformed shape here has an interleaving story. Fail closed: a person inspects
    and repairs the lock table; this run does not guess which row is real.
    """
    rows = list(rows or [])
    if not rows:
        return ["the promotion lock table exists and holds NO row — an empty lock is not an "
                "absent lock, it is a malformed one. Inspect and drop it deliberately."]
    if len(rows) > 1:
        return [f"the promotion lock table holds {len(rows)} rows — a lock with two holders "
                f"serialises nothing. Inspect and repair it; this run will not pick a row."]
    row = dict(rows[0])
    missing = [f for f in LOCK_FIELDS if not str(row.get(f) or "").strip()]
    if missing:
        return [f"the promotion lock row is incomplete ({', '.join(missing)} unset) — a lock "
                f"whose holder cannot be named cannot be reasoned about. Inspect and repair it."]
    return []


def lock_blockers(holder, build_id: str, attempt_id: str = "", resume_attempt: str = "") -> list:
    """[why this run may not proceed under the lock that exists]. [] when it is this run's own.

    EVERY INVOCATION IS AN ATTEMPT with its own id, and the lock records whose attempt holds it.
    Same build id is NOT the same attempt: `lock_blockers` used to wave through any holder wearing
    this build's id, so once a first invocation had journalled, a live concurrent duplicate of the
    same build read as "a crashed attempt" and the two interleaved — an external review's
    concurrency probe demonstrated exactly that. A foreign attempt of the SAME build blocks unless
    the operator explicitly takes it over by naming its attempt id (the `resume_promotion` job
    parameter) — and naming it only AUTHORISES the compare-and-set (`takeover_lock_sql`); it is the
    CAS, not this predicate, that consumes the token, so a second presenter of the same token
    matches zero rows and loses.
    """
    if holder is None:
        return []                                     # no lock table at all
    if not holder:
        return ["the promotion lock exists with an empty holder row — a malformed lock, not an "
                "absent one. Inspect and repair it; this run will not treat it as free."]
    if str(holder.get("build_id") or "") != str(build_id):
        return [f"another promotion of this product holds the lock: build "
                f"{holder.get('build_id')!r}, taken by "
                f"{holder.get('actor') or 'an unrecorded actor'} at "
                f"{holder.get('acquired_at') or 'an unrecorded time'}. Two promotions interleaving "
                f"their view swaps can leave the public set mixed — one product's TFL beside "
                f"another's ADS. Wait for it, or if it has died, drop "
                f"{promotion_lock('<the public ADS name>')} deliberately after checking that "
                f"run's promotion_state.yaml."]
    held_attempt = str(holder.get("attempt_id") or "")
    if held_attempt and attempt_id and held_attempt == str(attempt_id):
        return []                                     # this invocation's own lock, re-checked
    if held_attempt and str(resume_attempt or "") == held_attempt:
        return []                                     # explicit, inspected takeover of that attempt
    return [f"a promotion of THIS build already holds the lock (attempt "
            f"{held_attempt or 'unrecorded'!r}, taken by "
            f"{holder.get('actor') or 'an unrecorded actor'} at "
            f"{holder.get('acquired_at') or 'an unrecorded time'}). Same build id is not the same "
            f"attempt: if that run is live, wait; if you have inspected its journal and it is "
            f"dead, re-run with resume_promotion={held_attempt or '<attempt_id>'} to take it over "
            f"deliberately. This run will not infer a death from a build id."]


# ---------------------------------------------------------------------------------------------
# THE DURABLE PROMOTION JOURNAL.
#
# Promotion was: materialise every table, swap every view, write the receipt — three side effects
# with nothing recorded between them. Every gap is a state a retry could not tell from the others:
#
#   some versioned tables made and one failed        -> retry refuses, "already promoted"
#   every table made, some views swapped, one failed -> the public set is half this release
#   every view swapped, the receipt write failed     -> live, with no record that it is
#
# and the operator's instruction in all three was "drop the versioned tables by hand", which is
# wrong in the second and third: a view may already point at one.
#
# So intent is written BEFORE the first side effect and each completed stage is recorded. A retry
# reads the journal and continues rather than starting or refusing. The states are ordered and a
# promotion only ever moves forward along them.
# `pointed` sits after the views because the POINTER is the commit anchor: the release is
# published when the one-row pointer says so, and the receipt follows it.
PROMOTION_STATES = ("prepared", "materialised", "views_switched", "pointed", "receipted")


def promotion_intent(final: str, refresh: str, build_id: str, tfl_ids, *,
                     candidate_sha256: str, approved_identity=None, attempt_id: str = "") -> dict:
    """The record persisted BEFORE anything is created. Pure data; the runner writes it.

    It carries what a resuming run needs and cannot re-derive safely: which build, which approved
    candidate bytes, the identity those bytes were signed with, and the exact set of tables and views
    this promotion owns. That last part is what separates "a versioned table I made and did not
    finish" from "a versioned table belonging to somebody else's release" — the distinction the
    old blanket "already promoted" refusal could not draw, and the reason a partial failure had no
    safe recovery.
    """
    return {"state": PROMOTION_STATES[0],
            # THE JOURNAL PROTOCOL VERSION. 2 = outputs carry full physical identities and a
            # pending marker precedes every CREATE. `reconcile` refuses AUTOMATIC recovery of any
            # journal below 2: the older protocols confirmed a table by count and a mutable
            # property, which is the comparison a same-count impostor already passed.
            "protocol": 2,
            "public": final, "refresh": refresh, "build_id": build_id,
            "attempt_id": str(attempt_id or ""),
            "tfl_ids": sorted(tfl_ids or []),
            "candidate_manifest_sha256": candidate_sha256,
            "candidate_identity": dict(approved_identity or {}),
            "tables": [{"versioned": v, "staging": s}
                       for v, s in promotion_pairs(final, refresh, build_id, tfl_ids)],
            "views": {pub: ver for pub, ver, _sql in swap_plan(final, refresh, build_id, tfl_ids)}}


def advance(journal: dict, state: str) -> dict:
    """The journal moved to `state`. FORWARD ONLY — a stage cannot be un-completed by a later write.

    A retry that re-ran an already-recorded stage and then wrote its own (earlier) state would walk
    the journal backwards, and the next retry would redo work the first one had finished. Ordering
    is the whole value of a state machine; letting any writer set any value discards it.
    """
    if state not in PROMOTION_STATES:
        raise ValueError(f"{state!r} is not a promotion state: {PROMOTION_STATES}")
    now = dict(journal or {})
    have = now.get("state")
    if have in PROMOTION_STATES and PROMOTION_STATES.index(have) > PROMOTION_STATES.index(state):
        return now
    now["state"] = state
    return now


def journal_blockers(journal, build_id: str, candidate_sha256: str) -> list:
    """Why a journal found on disk does NOT describe the promotion about to run. [] when it does.

    An empty journal is not a blocker — that is a first attempt. A journal for a DIFFERENT build or
    a different approved digest is: resuming it would finish somebody else's promotion under this
    run's approval, which is the failure the resume path could most easily introduce.
    """
    if not journal:
        return []
    why = []
    if str(journal.get("build_id") or "") != str(build_id):
        why.append(f"the promotion journal here is for build {journal.get('build_id')!r}, not "
                   f"{build_id!r} — resuming it would finish a different promotion")
    if str(journal.get("candidate_manifest_sha256") or "") != str(candidate_sha256):
        why.append("the promotion journal was written against a different candidate manifest digest "
                   "— the approved bytes are not the ones this journal describes")
    if journal.get("state") not in PROMOTION_STATES:
        why.append(f"the promotion journal's state {journal.get('state')!r} is not one of "
                   f"{PROMOTION_STATES} — it cannot be resumed and must be inspected by a person")
    # RECEIPTED IS TERMINAL. A completed promotion classified as "resumable" is the replay an
    # external review demonstrated: rerun approved promotion A after B has published, the resume
    # skips the supersedes comparison (past views_switched that comparison would refuse its own
    # work), re-emits every swap and rewrites the pointer — consumers roll BACKWARDS onto A with
    # every check passing. A rerun of a receipted promotion verifies the receipt and exits
    # `already_promoted`; it never issues SQL.
    if journal.get("state") == PROMOTION_STATES[-1]:
        why.append("this promotion is COMPLETE (state 'receipted') — a receipted journal is "
                   "TERMINAL, never resumable. Verify its published receipt and stop; re-running "
                   "the swaps would republish an old release over whatever is live now.")
    return why


def rollback_blockers(journal, pointer_rows) -> list:
    """Why RESUMING this journal would move the public release backwards. [] when it cannot.

    The supersedes comparison protects a FIRST attempt; a resume past `views_switched` skips it
    (past that point the observed state is this run's own work). What that skip could not see: a
    NEWER release published between this attempt's crash and its resume. The pointer is the commit
    anchor, so it is the authority — a pointer naming a different build than this journal means
    finishing this resume republishes an old release over a newer one. Refuse; the crashed attempt
    is dead and a person cleans it up.
    """
    if not journal:
        return []
    rows = list(pointer_rows or [])
    if not rows:
        return []                                     # nothing published through the pointer yet
    if len(rows) > 1:
        return [f"the release pointer holds {len(rows)} rows — a consumer resolving through it "
                f"gets an ambiguous answer, and a resume that trusted row zero would trust "
                f"whichever row an interleaved writer happened to leave first. Repair the pointer "
                f"before anything resumes."]
    row = dict(rows[0])
    ptr_build = str(row.get("build_id") or "")
    if ptr_build and ptr_build != str(journal.get("build_id") or ""):
        return [f"the release pointer names build {ptr_build!r} (published at "
                f"{row.get('published_at') or 'an unrecorded time'}), not this journal's "
                f"{journal.get('build_id')!r} — a newer release was published after this attempt "
                f"stalled, and resuming would move consumers BACKWARDS onto older data. This "
                f"attempt is dead; clean up its partial work instead of finishing it."]
    return []


def candidate_binding_blockers(cand, *, spec_version, refresh, output_fqn,
                               config_identity=None, require_release_grade=False) -> list:
    """Why the RUNTIME configuration is not the one this candidate was built under. [] when it is.

    The promotion job resolves the public name, the refresh and the spec version from the CURRENT
    config; the approval signed a manifest built under the config of ITS day — and nothing compared
    the two. A candidate built and approved under one spec version promoted cleanly after the pack
    moved to another: every versioned name, the pointer and the receipt wearing the new config
    around the old bytes, and the receipt validating because each field was filled from the same
    (wrong) place. An external review demonstrated it with a 202606 candidate under a 202612
    config. The candidate manifest already records what it was built from; this compares each
    recorded binding against the runtime's, and a candidate that recorded nothing is refused
    rather than waved through — an unstated binding is not a matching one.

    `config_identity` is {digest name: value} computed from the runtime pack (the science digest
    and the delivery digest, `product_gates.config_bundle_sha256` / `delivery_sha256`); the same
    pair recorded at build time catches the edit a spec version cannot: the same version's config
    changed between the approval and the promotion.
    """
    why = []
    for field, now in (("spec_version", str(spec_version)), ("refresh", str(refresh)),
                       ("output_table", str(output_fqn))):
        was = str(cand.get(field) or "")
        if not was:
            why.append(f"the candidate manifest records no {field} — it cannot be bound to the "
                       f"runtime configuration, so it does not promote")
        elif was != now:
            why.append(f"the candidate was built with {field}={was!r} and the runtime config says "
                       f"{now!r} — the configuration changed after the approval, and promoting "
                       f"would publish the old bytes under the new config's name")
    for digest, now in sorted((config_identity or {}).items()):
        was = str((cand.get("config_identity") or {}).get(digest) or "")
        if not was:
            why.append(f"the candidate manifest records no config_identity.{digest} — it predates "
                       f"the config freeze. Rebuild so the approval binds the configuration; an "
                       f"unrecorded binding is not a matching one")
        elif was != str(now):
            why.append(f"the pack's {digest} is {str(now)[:12]}… now and the candidate was built "
                       f"under {was[:12]}… — the configuration changed after the approval. "
                       f"Re-approve under the current config, or restore the config the approval "
                       f"covered")
    # A GOVERNED PROMOTION PUBLISHES ONLY RELEASE-GRADE CANDIDATES. `run_mode` is the candidate's
    # own record of how it was built; a dev-mode build (waived gates, no golden reference, dev
    # bindings) used to be indistinguishable from a release-grade one in its bytes, so a prod
    # promotion could publish it with every remaining check passing. Absence refuses — a candidate
    # that cannot say which mode built it predates the freeze and is rebuilt, not assumed.
    if require_release_grade:
        mode = cand.get("run_mode") or {}
        if mode.get("release_grade") is not True or str(mode.get("env") or "") != "prod":
            why.append(f"a governed promotion requires a candidate built RELEASE-GRADE, and this "
                       f"one records run_mode={mode or 'nothing'} — a dev-mode build is not made "
                       f"releasable by the environment it is promoted from. Rebuild in prod with "
                       f"the gates passing, re-approve, then promote.")
    return why


def reconcile(journal, existing, row_counts=None, properties=None, observed_outputs=None):
    """(done, blockers) — which of THIS promotion's versioned tables are already correctly made.

    IDEMPOTENCE, WITHOUT DROPPING ANYTHING. `CREATE TABLE ... AS SELECT` is not repeatable, so a
    resume has to know which targets already exist; and an existing target is only safe to skip if it
    holds what was approved. Three cases, and the third is the one the old code could not express:

      absent                  -> still to do
      present, right count    -> done. Skip it; do not drop and remake bytes a view may serve.
      present, wrong count    -> a partial or foreign write. REFUSED, and the message differs by
                                 state, because whether it is safe to drop depends on whether a
                                 public view has been pointed at it yet.

    `row_counts` is {table: rows} for the versioned tables that exist — the runner counts them, this
    decides. A target that exists with no count offered is refused rather than assumed good.

    `properties` is {table: {k: v}} of Delta TBLPROPERTIES. A same-name, same-count table is not
    the same bytes: the `rwdp_build_id` tag written at materialisation is what confirms a table as
    THIS promotion's own work. When properties are offered (the runner always offers them), a
    table without this promotion's tag is refused however right its count looks.
    """
    journal = journal or {}
    have, counts = set(existing or []), dict(row_counts or {})
    approved = journal.get("candidate_identity") or {}
    swapped = PROMOTION_STATES.index(journal.get("state") or PROMOTION_STATES[0]) >= \
        PROMOTION_STATES.index("views_switched")
    done, why = [], []
    # THE PROTOCOL GATE. A journal below protocol 2 recorded no (or partial) output identities,
    # and its recovery path confirmed tables by count plus a mutable property — the exact
    # comparison an external review's same-count impostor passed. Automatic recovery of such a
    # journal is refused outright: a person inspects the partial work and cleans it up. (No
    # protocol-1 promotion has ever run outside a test; this refusal costs nobody a real resume.)
    if journal and int(journal.get("protocol") or 0) < 2:
        return [], [f"this promotion journal records protocol {journal.get('protocol') or 'none'} "
                    f"— before output identities were journaled — and its recovery path could "
                    f"only compare counts and mutable properties, which a same-count impostor "
                    f"passes. Automatic recovery is refused; inspect the partial work named in "
                    f"the journal and clean it up deliberately."]
    for pair in journal.get("tables") or []:
        ver, stg = pair.get("versioned"), pair.get("staging")
        if ver not in have:
            continue
        want = (approved.get(stg) or {}).get("row_count")
        got = counts.get(ver)
        tag = ((properties or {}).get(ver) or {}).get("rwdp_build_id")
        if properties is not None and tag != str(journal.get("build_id") or ""):
            why.append(f"{ver} exists but carries rwdp_build_id={tag!r}, not this promotion's "
                       f"{journal.get('build_id')!r} — a same-name, same-count table is not the "
                       f"same bytes, and an untagged one is not this promotion's work")
        elif want is None:
            why.append(f"{ver} exists and the journal records no approved row count for {stg}, so "
                       f"it cannot be confirmed as this promotion's work")
        elif got is None:
            why.append(f"{ver} exists and was not counted, so it cannot be confirmed as this "
                       f"promotion's work — an unverified table is not a completed step")
        elif got != want:
            why.append(
                f"{ver} exists with {got} row(s) and the approved candidate recorded {want}. This is "
                f"a partial write from an interrupted promotion. " +
                ("A public view may already point at it — do NOT drop it; investigate before "
                 "retrying." if swapped else
                 "No public view points at it yet, so it is safe to drop and let the retry remake "
                 "it."))
        else:
            done.append(ver)
    # THE OUTPUT'S OWN IDENTITY. Count plus a mutable table property was the whole comparison —
    # an external review's probe passed a same-count impostor wearing the expected property.
    # `outputs` carries what materialisation actually observed; a table that disagrees is not the
    # one this promotion made, whatever its count and tag say. Under protocol 2 there is NO
    # fallback and NO partial identity: an existing target with a missing or incomplete recorded
    # identity, or an incomplete OBSERVED one, is refused — a field skipped is a field an
    # impostor does not have to match, which an external review demonstrated with a
    # table_id-only journal entry.
    recorded = journal.get("outputs") or {}
    if journal and done and observed_outputs is None:
        return [], why + [f"existing target(s) {sorted(done)} were not re-probed for identity — "
                          f"under protocol 2 a count alone confirms nothing; the caller must "
                          f"observe {{table_id, location, delta_version, schema_digest}} for "
                          f"every existing target"]
    if journal and observed_outputs is not None:
        for ver in list(done):
            was, now = recorded.get(ver), (observed_outputs or {}).get(ver)
            if not was or not was.get("table_id"):
                why.append(f"{ver} exists and the journal holds intent but no materialised "
                           f"identity for it — the interruption landed inside its CREATE, and "
                           f"count plus property cannot say whose bytes these are. " +
                           ("A public view may already point at it — do NOT drop it; investigate "
                            "before retrying." if swapped else
                            "No public view points at it yet; inspect and drop it deliberately, "
                            "then retry."))
                done.remove(ver)
                continue
            if not now:
                why.append(f"{ver} was journaled with its identity at materialisation and this "
                           f"resume observed none — an unprobed table is not a completed step")
                done.remove(ver)
                continue
            for field in ("table_id", "location", "delta_version", "schema_digest"):
                a, b = was.get(field), now.get(field)
                if a is None or b is None:
                    why.append(f"{ver}: {field} is {'unrecorded' if a is None else 'unobserved'} "
                               f"— a partial identity is a field an impostor does not have to "
                               f"match, so it confirms nothing")
                    if ver in done:
                        done.remove(ver)
                elif a != b:
                    why.append(f"{ver}: {field} was {a!r} when this promotion materialised it and "
                               f"is {b!r} now — this is not the table this promotion made")
                    if ver in done:
                        done.remove(ver)
    return sorted(done), why


def schema_digest(schema_fields) -> str:
    """A stable digest of (name, type) pairs — the cheap half of content identity.

    `schema_fields` is any iterable of (name, dtype) pairs (the runner hands in
    `df.dtypes` or a DESCRIBE result). Order-insensitive: column order is a projection detail,
    and a digest that moved on SELECT reordering would refuse tables nothing changed.
    """
    joined = ";".join(f"{str(n).lower()}:{str(t).lower()}"
                      for n, t in sorted((str(n), str(t)) for n, t in (schema_fields or [])))
    return hashlib.sha256(joined.encode("utf-8")).hexdigest()[:16]


def output_identity_row(probe_row, schema_fields=None) -> dict:
    """One journaled output's identity, from the runner's probe of a versioned table it just made."""
    d = dict(probe_row) if not isinstance(probe_row, dict) else dict(probe_row)
    return {"table_id": d.get("table_id") or None,
            "location": d.get("location") or None,
            "delta_version": _as_int(d.get("delta_version")),
            "row_count": _as_int(d.get("row_count")),
            "schema_digest": schema_digest(schema_fields) if schema_fields is not None else None}


# ---------------------------------------------------------------------------------------------
# THE ATOMIC RELEASE POINTER.
#
# Swapping the public views is N separate DDL statements and Databricks has no transaction across
# them. TFLs-first-ADS-last bounds the damage — a consumer anchored on the ADS view sees the previous
# release until the last statement — but a consumer reading a TFL view directly can see this build's
# TFL beside the previous build's ADS. `products/OPERATIONS.md` has told consumers to anchor on the
# ADS view for exactly this reason, which is a convention asking readers to be careful rather than a
# guarantee that they need not be.
#
# ONE ROW, ONE WRITE, ONE TRANSACTION. A Delta `INSERT OVERWRITE` of a single-row table is one commit:
# verified against Delta rather than assumed, by reading the pointer's own version history and finding
# that every version holds a COMPLETE release set and none holds a partial one. A consumer that
# resolves the set through this table sees either the whole previous release or the whole new one.
#
# THE VIEWS REMAIN, and are still swapped. They are the compatibility surface for everything already
# reading them, and removing them would break consumers to fix a race they may not have. The pointer
# is written LAST — after every view — so it keeps one commit-anchor concept: the release is published
# when the pointer says so, and `published_at` follows it.
POINTER_SUFFIX = "__release"


def release_pointer_table(final: str) -> str:
    """The one-row pointer a consumer resolves the release set through."""
    return f"{final}{POINTER_SUFFIX}"


def pointer_create_sql(final: str) -> str:
    """Create the pointer if it does not exist. Idempotent, and separate from the write on purpose.

    `CREATE OR REPLACE TABLE ... AS SELECT` would have done both in one statement and this catalog
    refuses it — `UNSUPPORTED_FEATURE.TABLE_OPERATION`, found by running it. Splitting one-time setup
    from the atomic transition is better anyway: the statement that publishes a release should do
    nothing but publish it.
    """
    return (f"CREATE TABLE IF NOT EXISTS {release_pointer_table(final)} ("
            f"public STRING, version STRING, build_id STRING, spec_version STRING, "
            f"ads STRING, tfls STRING, published_at STRING) USING DELTA")


POINTER_FIELDS = ("public", "version", "build_id", "spec_version", "ads", "tfls", "published_at")


def pointer_schema_errors(dtypes) -> list:
    """[why an EXISTING pointer table cannot carry this module's release rows]. [] when it can.

    `pointer_create_sql` is `IF NOT EXISTS`, so a pointer table that already exists with another
    shape — created by hand, or by an older schema — is silently kept, and the failure surfaces
    inside the publishing `INSERT OVERWRITE` with the views already moved. Verified in the
    preflight instead, where a refusal is still free. Column NAMES, exactly and in order (the
    write is positional), AND every TYPE a string: a pointer with the right names over an
    incompatible type passed the name check and failed inside the publishing write — after every
    public view had already moved. `dtypes` is Spark's `[(name, type)]`.
    """
    pairs = [(str(n), str(t).lower()) for n, t in (dtypes or [])]
    got = [n for n, _t in pairs]
    if got != list(POINTER_FIELDS):
        return [f"the release pointer table's columns are {got}, not {list(POINTER_FIELDS)} — an "
                f"existing table of another shape is kept by CREATE IF NOT EXISTS, and the "
                f"positional INSERT would corrupt what consumers resolve through. Inspect it; if "
                f"it is not a release pointer, move it; never publish through it."]
    bad_types = [(n, t) for n, t in pairs if t != "string"]
    if bad_types:
        return [f"the release pointer table's column types are wrong: "
                f"{', '.join(f'{n} is {t}' for n, t in bad_types)} — every pointer column is "
                f"STRING, and a compatible-looking name over another type fails inside the "
                f"publishing write, after the views have moved. Inspect and repair it."]
    return []


def pointer_preflight_sql(final: str) -> str:
    """A write-authority probe that changes nothing — run BEFORE the first view swap.

    Pointer creation used to happen after the swaps, so a pointer permission, schema or
    object-type error surfaced with the public views already moved — the release half-published
    with its commit anchor unwritable. A DELETE whose predicate matches no row mutates nothing
    but is authorised like any write, so it fails here, before anything public has moved,
    exactly when a refusal is still free.
    """
    return f"DELETE FROM {release_pointer_table(final)} WHERE build_id = ''"


def pointer_write_sql(final: str, refresh: str, build_id: str, tfl_ids, *,
                      spec_version=None, published_at=None) -> str:
    """ONE statement that publishes the whole release set atomically.

    Built from `release_pointer` so the table and the manifest cannot describe different releases —
    the same failure, one artifact apart, that every other check in this module exists to prevent.
    `tfls` is JSON with sorted keys: a consumer parses one column instead of joining, and sorting
    makes the statement reproducible for a byte comparison.
    """
    import json
    ptr = release_pointer(final, refresh, build_id, tfl_ids, spec_version=spec_version)
    return (f"INSERT OVERWRITE TABLE {release_pointer_table(final)} SELECT "
            f"{_sql_str(ptr['public'])} AS public, {_sql_str(ptr['version'])} AS version, "
            f"{_sql_str(ptr['build_id'])} AS build_id, "
            f"{_sql_str(ptr['spec_version'])} AS spec_version, "
            f"{_sql_str(ptr['ads'])} AS ads, "
            f"{_sql_str(json.dumps(ptr['tfls'], sort_keys=True))} AS tfls, "
            f"{_sql_str(published_at)} AS published_at")


def pointer_read_sql(final: str) -> str:
    """What a CONSUMER runs to learn the current release set. Stated here so the docs cannot drift."""
    return (f"SELECT ads, tfls, build_id, published_at FROM {release_pointer_table(final)}")


def pointer_blockers(rows, final: str, refresh: str, build_id: str, tfl_ids,
                     spec_version=None, published_at=None) -> list:
    """[why the pointer does not name this release]. Read back AFTER the write, before the receipt.

    A pointer that says something else is worse than no pointer: it is the one place a consumer is
    being told to trust over the views. Checked rather than assumed, and checked against the same
    `release_pointer` the write was built from.
    """
    import json
    rows = list(rows or [])
    if len(rows) != 1:
        return [f"{release_pointer_table(final)} holds {len(rows)} row(s); a release pointer is one "
                f"row, and any other count means a consumer resolving through it gets no answer or "
                f"an ambiguous one"]
    got = dict(rows[0])
    want = release_pointer(final, refresh, build_id, tfl_ids, spec_version=spec_version)
    why = []
    if spec_version is not None:
        want["spec_version"] = str(spec_version)
    if published_at is not None:
        want["published_at"] = str(published_at)
    checked = ("public", "version", "build_id", "ads") + \
        (("spec_version",) if spec_version is not None else ()) + \
        (("published_at",) if published_at is not None else ())
    for field in checked:
        if str(got.get(field) or "") != str(want.get(field) or ""):
            why.append(f"the release pointer's {field} is {got.get(field)!r}, not {want[field]!r}")
    try:
        if json.loads(got.get("tfls") or "{}") != want["tfls"]:
            why.append(f"the release pointer's tfls are {got.get('tfls')!r}, not {want['tfls']!r}")
    except ValueError:
        why.append(f"the release pointer's tfls column is not JSON: {got.get('tfls')!r}")
    return why


def release_pointer(final: str, refresh: str, build_id: str, tfl_ids, *,
                    manifest=None, spec_version=None) -> dict:
    """The consistent release set for this build — recorded in the manifest as the durable pointer."""
    return {"public": final, "version": refresh, "build_id": build_id, "spec_version": spec_version,
            "ads": versioned_ads(final, refresh, build_id),
            "tfls": {tid: versioned_tfl(final, refresh, build_id, tid) for tid in (tfl_ids or [])},
            "views": {pub: ver for pub, ver, _ in swap_plan(final, refresh, build_id, tfl_ids)},
            "manifest": manifest}
