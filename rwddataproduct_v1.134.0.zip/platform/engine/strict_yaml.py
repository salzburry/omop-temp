"""ONE strict YAML loader for governed files — a duplicate key is a refusal, never a silent winner.

PyYAML's SafeLoader is last-wins on duplicate mapping keys: a file carrying two `approved_by:`
lines loads cleanly with the SECOND value silently replacing the first. In an approval record that
is the difference between who signed and who appears to have signed — reproduced by the external
review against a governed YAML, accepted without a murmur. Every reader of a governed file loads
through this module so the refusal cannot fork per caller.

`strict_load` is a drop-in for `yaml.safe_load`: same scalar resolution (dates stay dates,
impossible dates still raise ValueError — `product_gates.read_yaml` depends on exactly that), same
return shapes. The ONLY added behavior is the duplicate-key refusal, raised as
`yaml.YAMLError` so every existing `except yaml.YAMLError` handler already catches it.

stdlib + PyYAML only.
"""
import yaml


class DuplicateKey(yaml.YAMLError):
    """A mapping stated the same key twice — two claims for one slot, one silently discarded."""


class _StrictLoader(yaml.SafeLoader):
    pass


def _mapping(loader, node, deep=False):
    seen = set()
    for key_node, _v in node.value:
        key = loader.construct_object(key_node, deep=deep)
        try:
            hashable = key
            if hashable in seen:
                raise DuplicateKey(
                    f"duplicate key {key!r} (line {key_node.start_mark.line + 1}) — the second "
                    f"value would silently replace the first, and in a governed file that is a "
                    f"forged slot, not a convenience")
            seen.add(hashable)
        except TypeError:
            pass                                     # unhashable key: let SafeLoader report it
    return yaml.SafeLoader.construct_mapping(loader, node, deep=deep)


_StrictLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _mapping)


def strict_load(stream):
    """yaml.safe_load, but a duplicate mapping key raises DuplicateKey (a yaml.YAMLError)."""
    return yaml.load(stream, Loader=_StrictLoader)


def strict_load_path(path):
    """`strict_load` over a FILE, decoded as utf-8.

    Three tools had each written this same adapter — `citation_register._load`,
    `portfolio_status._load` and `capability_registry._strict_load`, byte-identical. Reading the
    bytes is part of "load a governed file", so it belongs with the loader that owns the refusal,
    and a per-caller copy is how one of them comes to open a governed file in the machine's default
    code page. This repository keeps a whole test for that failure on the Windows runner.
    """
    from pathlib import Path                                            # noqa: PLC0415
    return strict_load(Path(path).read_text(encoding="utf-8"))
