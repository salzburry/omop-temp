"""Orchestrator: build a tumor's ADS from its config. Locked, tumor-agnostic code.

Mirrors the top-level flow of the R script — for each cohort, build index -> demographics ->
clinical -> treatment -> outcomes, assemble, then union all cohorts into one ADS. Stage modules
are imported lazily so this module imports without pyspark (config tests don't need Spark).

    from engine.config import load_config
    from engine.build_ads import build, write_ads
    cfg = load_config(".../config/data_product.yaml", overrides={"run.refresh": "2026q2"})
    ads = build(spark, cfg)
    write_ads(ads, cfg)
"""
from __future__ import annotations


def build(spark, cfg, pins=None, telemetry=None):
    """Build and return the unioned ADS DataFrame for all configured cohorts (loads sources, then
    delegates to build_from_sources — the unit-testable core)."""
    from .stages import sources               # lazy: only needed when actually running on Spark
    return build_from_sources(sources.load(spark, cfg, pins), cfg, telemetry=telemetry)


def build_from_sources(src, cfg, telemetry=None):
    """The union path over PRE-LOADED sources: per-cohort stages -> unionByName -> derived cohorts.
    build() = sources.load + this; splitting it out lets a Spark smoke exercise the EXACT production
    union/derived-cohort path on synthetic source DataFrames (not just per-cohort stages).

    `telemetry` (an engine.telemetry.StageTelemetry, default None) records a per-stage join
    aggregate against each cohort's index frame. record() queues a plan and returns None — it
    cannot alter a frame, and with the default None this function is byte-for-byte the path it
    always was: no extra Spark action, no extra plan, R parity untouched."""
    from pyspark.sql import functions as F, Window
    from .stages import (index, demographics, clinical, treatment, outcomes, assemble, lot, proc,
                         ads_derived)

    # THE CORE'S OWN FLOOR. The production path already refuses a missing required column at
    # preflight, and the stage helpers' `if col in columns` guards exist as belt-and-braces on top
    # of that — their own comments say so. But an SIT that called THIS function directly proved the
    # braces alone hold nothing: dropping a required column a GUARDED path reads produced an ADS
    # with the affected variables silently absent, no refusal anywhere. Every direct caller —
    # tests, notebooks, local smokes — was one schema drift away from silent variable loss. One
    # schema pass over the frames in hand (no Spark action) closes it; roles absent from `src`
    # entirely still fail loudly at first read, and which absences are LEGITIMATE is availability
    # policy (engine.validate), not this function's call.
    from . import validate as _validate
    _required = _validate.required_columns(cfg)
    # A role can be MISSING, not just thin: the first version of this floor checked columns only
    # when a frame existed (`if _df is None: continue`), so a direct caller that omitted a
    # scientifically required source built an incomplete ADS with no refusal — the exact gap the
    # silent-omission class. Which absences are LEGITIMATE is availability policy: a role whose
    # reads are optional or when_absent-degradable never appears in required_columns at all.
    _absent = sorted(set(_required) - set(src))
    if _absent:
        raise ValueError(
            f"BUILD REFUSED — required source role(s) not supplied: {', '.join(_absent)}. "
            f"Each carries required stage reads (validate.required_columns); building without "
            f"them would emit an ADS with their variables silently absent. Supply the frames, "
            f"or make the absence a POLICY (optional read / when_absent) rather than an "
            f"omission by this caller.")
    _missing = []
    for _role, _cols in sorted(_required.items()):
        _have = {c.lower() for c in src[_role].columns}
        _missing += [f"{_role}.{c}" for c in sorted(set(_cols)) if c.lower() not in _have]
    if _missing:
        raise ValueError(
            f"BUILD REFUSED — required column(s) absent from the loaded sources: "
            f"{', '.join(_missing)}. The config requires them (validate.required_columns); "
            f"building without them would silently drop the variables they feed. Run preflight "
            f"against the cut, or fix the frames this caller assembled.")

    # Treated = a line of therapy in the cohort's RELEVANT setting, using the SAME LOT model as the
    # index/treatment stages (line_setting + exclude_settings + line_number_col) but NO maintenance
    # filter (treated is maintenance-independent). Derived PER COHORT off the cohort's line_setting so a
    # dual-setting product gets per-setting treated/untreated COHORTU (Treated/Untreated mCRPC vs mHSPC);
    # single-setting tumors fall back to the global lot.line_setting (one flag, unchanged result).
    ads = None
    for cohort in cfg.cohorts:
        treated = (lot.normalized(src, cohort.get("line_setting", cfg.lot_line_setting),
                                  exclude_settings=cfg.lot_exclude_settings,
                                  line_number_col=cfg.lot_line_number_col,
                                  maintenance_column=cfg.lot_maintenance_column)
                   .select("patientid").distinct().withColumn("treat_flag", F.lit(1)))
        cid = cohort.get("id") or str(cohort.get("cohortn"))
        idx = index.build(src, cfg, cohort)     # index_lot_cohort()
        dem = demographics.build(src, idx, cfg)  # demographics_variable_addn()
        # clinical takes the collector too: the closest-panel families inside it queue per-item
        # SELECTION plans (candidate rows, same-date ties, non-null outputs) under the cohort label
        clin = clinical.build(src, idx, cfg, telemetry=telemetry, cohort=cid)  # clin_char_master()
        trt = treatment.build(src, idx, cfg, cohort, telemetry=telemetry)   # trt_var_creation() (cohort -> prior-taxane)
        out = outcomes.build(src, idx, clin, trt, cfg, cohort, telemetry=telemetry)  # outcomes_tbl_var() (cohort -> line N)
        cohort_ads = assemble.build(idx, dem, clin, trt, out, cfg, cohort, treated)  # overall_ads_creation()
        ps = proc.build(F, src, idx, cfg, cohort)        # OC platinum-sensitivity (2L+ line cohorts)
        if ps is not None:
            cohort_ads = cohort_ads.join(ps, ["patientid", "index_date"], "left")
        # Cross-stage derivations (outcomes.ads_derived): applied AFTER assemble+proc, when every
        # stage's columns sit on one frame — landmark flags (EFS24-style), intervals between
        # columns different stages emitted, and general expressions. Per cohort, so a derivation
        # may read cohort-shaped columns (this line's dates) like any other consumer.
        cohort_ads = ads_derived.build(F, cohort_ads, cfg)
        if telemetry is not None:
            # Every stage boundary this loop owns, in build order. The final frame is recorded
            # AFTER proc+ads_derived — the shape the union actually takes downstream.
            for stage, frame in (("index", idx), ("demographics", dem), ("clinical", clin),
                                 ("treatment", trt), ("outcomes", out),
                                 ("cohort_ads", cohort_ads)):
                telemetry.record(F, idx, frame, cid, stage)
        ads = cohort_ads if ads is None else ads.unionByName(cohort_ads, allowMissingColumns=True)

    if ads is not None:
        ads = _apply_derived_cohorts(ads, cfg, F, Window)   # OC PROC = 2L+ platinum-Resistant split
    return ads


def _apply_derived_cohorts(ads, cfg, F, Window):
    """Append each configured derived cohort: the rows of its `from` cohorts (resolved to cohortn)
    that match the `where` SQL predicate, relabeled with the derived cohort's `cohort`/`cohortn`.

    A derived cohort SPLITS rows out of existing cohorts rather than indexing new patients — e.g. OC's
    PROC (`from: [lot2, lot3, lot4, lot5]`, `where: "plat_sen_v1 = 'Resistant'"`, cohortn 9). With
    `pick: first` only the EARLIEST qualifying line per patient is kept (by index_date) — so PROC is
    "index at FIRST platinum resistance", one row per patient, not every resistant line. Generic
    (reusable for any tumor). == engine-r/build_ads.R::apply_derived_cohorts.
    """
    id_to_n = {c["id"]: c["cohortn"] for c in cfg.cohorts}
    for dc in (cfg.raw.get("derived_cohorts") or []):
        from_ns = [id_to_n[i] for i in dc["from"] if i in id_to_n]
        sub = ads.filter(F.col("cohortn").isin(from_ns)).filter(F.expr(dc["where"]))
        if dc.get("pick") == "first":
            w = Window.partitionBy("patientid").orderBy(F.col("index_date").asc())
            sub = sub.withColumn("_rn", F.row_number().over(w)).filter(F.col("_rn") == 1).drop("_rn")
        sub = sub.withColumn("cohort", F.lit(dc["label"])).withColumn("cohortn", F.lit(dc["cohortn"]))
        ads = ads.unionByName(sub, allowMissingColumns=True)
    return ads


def write_ads(ads, cfg) -> str:
    """Persist the ADS to {output_schema}.{output_table}. Returns the table FQN."""
    (ads.write
        .mode(cfg.write_mode)
        .option("overwriteSchema", "true")
        .saveAsTable(cfg.output_fqn))
    return cfg.output_fqn
