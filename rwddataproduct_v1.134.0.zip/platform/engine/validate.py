#!/usr/bin/env python3
"""Validate the prostate RWDP config + codelists before a build. Pure Python (no Spark).

Two entry points:
  * problems(cfg, strict=...) -> list[str]   collect issues (lint / tests)
  * check(cfg, strict=True)                  raise RuntimeError on the first build run

`strict=True` (the default for check) treats unfilled REPLACE_ME placeholders as errors, so the
Databricks job fails fast with an actionable message instead of resolving tables like
`REPLACE_ME.t_enh_prostate_REPLACE_ME`.

CLI (lint mode, placeholders allowed):
    python engine/validate.py config/data_product.yaml
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from config import load_config            # noqa: E402
from codelists import compile_case        # noqa: E402
import vocabularies                       # noqa: E402
# Registries the validator checks against — imported (not duplicated) so validation can't drift from
# what the engine actually resolves. clinical.py's module level is PySpark-free (pyspark is imported
# inside each stage function), so this is a cheap, side-effect-free import.
from stages.clinical import (BMI_FORMULAS, BSA_FORMULAS, CLOSEST_PANELS,   # noqa: E402
                            DEATH_CONFLICT_POLICIES, FOLLOWUP_FILTERS, FOLLOWUP_SOURCES,
                            selection_errors, value_matcher_errors)
from stages.ads_derived import ads_derived_errors, emitted as ads_derived_emitted   # noqa: E402

# The scaffold marker, checked as a SUBSTRING: a config value like `rwdp_REPLACE_ME_202606` is still
# unfilled even though it does not equal the marker. Deliberately NOT product_gates.unstated(), which
# asks a different question — "is this human-entered approval field an answer?" — with token/exact
# semantics, so that `NA-2026-01` stays a valid document id. Two predicates, one marker; do not merge
# them, and do not add a second spelling of the marker.
PLACEHOLDER = "REPLACE_ME"
REQUIRED_RUN_KEYS = ["refresh", "source_schema", "output_schema", "output_table"]
# Pack ROLES (file stems) the shared engine requires — tumor-agnostic (pack_id is just a label).
EXPECTED_ROLES = {"demographics", "clinical", "treatment", "outcomes"}
# Source mappings the shared engine genuinely REQUIRES (index/LOT/demographics/follow-up+death).
# Everything else is OPTIONAL — a tumor declares only the sources it has, so heme/COTA products
# without provenge/alphabet/vitals still validate. The engine + preflight handle declared-only.
REQUIRED_SOURCES = {"enhanced", "lot", "demographics", "mortality"}
KNOWN_VENDORS = {"flatiron", "cota"}
KNOWN_TUMOR_CLASSES = {"solid", "heme"}
# Mortality conflict-resolution policies are IMPORTED above, not restated. This was a set declared
# here with "keep in sync with engine/stages/clinical.py" above it — a hand-sync, two lines under an
# import from that very module and directly above a comment explaining why BMI/BSA are derived rather
# than copied. Two ways it broke: a policy added here only made the validator ACCEPT a config the
# engine then refuses mid-build (clinical.py raises on an unknown policy), and a policy added there
# only made the validator refuse one the engine supports. Worse, clinical.py's is a TUPLE whose
# element 0 is the default conflict resolution — order carries meaning that a set cannot hold, so
# reordering it silently changed which death date is selected (feeding OS, TTNT, PFS and follow-up
# duration) with no config edit and nothing to notice.
# Named BMI/BSA formula methods config may select (vitals.bmi_method / bsa_method) — DERIVED from the
# engine registries above, so a method added/removed in the engine is automatically valid/invalid here.
BMI_METHODS = set(BMI_FORMULAS)
BSA_METHODS = set(BSA_FORMULAS)
# Logical source names the NAMES-LIST form of follow_up_sources may restrict the default set to —
# DERIVED from the engine's FOLLOWUP_SOURCES so a source added/removed there stays in sync here.
FOLLOWUP_SOURCE_NAMES = {t[0] for t in FOLLOWUP_SOURCES}
# Banded lists that need exactly one `when: fallthrough` row, else out-of-range values become
# null instead of the intended catch-all (e.g. age "Unknown"/8). (pack ROLE, key-path).
BANDED_LISTS = [
    ("demographics", ("age_bands",)),
    ("clinical", ("vitals", "bmi_bands")),
    ("treatment", ("lot_count_bands",)),
]
# The per-source column table that used to live HERE as a static dict (lot, demographics,
# baseline_ecog, the follow-up feeds, mortality) now lives with the stages that read those
# columns — each stage module's `reads(cfg)` declares them, and `stage_reads` below composes.
# A validator describing the stages from the outside is how eight role-level reads came to
# match no declaration at all (an external review counted them); the stage that dereferences
# a column is the one place that knows it does.


def stage_reads(cfg):
    """(every typed source read the stages declare, [errors]) — THE canonical dependency list.

    Composes each stage module's `reads(cfg)`. A stage whose declaration RAISES on a malformed
    pack is reported by name, never suppressed: the previous composition ran every block under a
    broad suppressor, so a malformed pack silently required nothing — preflight green over a
    config the build would refuse.
    """
    from stages import clinical as _cl, demographics as _dm, lot as _lo   # noqa: PLC0415
    from stages import outcomes as _oc, proc as _pr, sources as _so, treatment as _tr  # noqa: PLC0415
    out, errors = [], []
    for mod in (_so, _lo, _dm, _cl, _tr, _oc, _pr):
        try:
            recs = mod.reads(cfg)
        except Exception as e:                        # noqa: BLE001 — surfaced, not swallowed
            errors.append(f"{mod.__name__}.reads(): {e}")
            continue
        for r in recs:
            # A read with no role is a declaration about nothing — a dict-form follow_up_sources
            # entry missing `source` produced one, and the None role crashed the compiled
            # contract with an unattributed TypeError two modules away (an adversarial review
            # reproduced it). Dropped HERE with the stage named; the module's other reads stand.
            if not r.get("role"):
                errors.append(f"{mod.__name__}.reads(): a read at {r.get('where')!r} declares "
                              f"no role — the config entry it describes is missing its source")
                continue
            out.append(r)
    return out, errors


def _broken_pack_ok():
    """One bad pack file must yield ONE message, not thirty.

    problems() reports the load failure itself, once. Every per-pack check runs
    under this so a broken YAML skips that check instead of killing the scan."""
    from contextlib import suppress
    return suppress(Exception)


def problems(cfg, strict: bool = False) -> list[str]:
    out: list[str] = []

    # --- run / output -----------------------------------------------------
    for k in REQUIRED_RUN_KEYS:
        if not cfg.run.get(k):
            out.append(f"run.{k} is missing or empty")
        elif strict and PLACEHOLDER in str(cfg.run.get(k)):
            out.append(f"run.{k} = '{cfg.run.get(k)}' still contains the '{PLACEHOLDER}' "
                       f"placeholder — set a real value before running (prod values like "
                       f"'{PLACEHOLDER}_prod_source' are NOT real schemas)")

    # --- study window -----------------------------------------------------
    # Presence was the only check, so the template's shipped 2013-01-01 / 2025-12-31 passed as a real
    # answer for every product that copied it — a scientific decision from the SPEC, inherited. The
    # window is now REPLACE_ME in the template, and the placeholder has to be refused the same way
    # `run.*` placeholders are or the trap just changes shape.
    #
    # Deliberately NOT a date-format check here: `bad_date` is the one date predicate and it lives in
    # platform/tools, which the engine must not import. Adding a second ISO regex to this file is the
    # duplication this repo keeps paying for; a window that is present and not a placeholder but
    # misspelled is a real remaining gap, and one predicate in one place is how it should be closed.
    for k in ("index_start", "index_end"):
        if not cfg.study.get(k):
            out.append(f"study.{k} is missing")
        elif strict and PLACEHOLDER in str(cfg.study.get(k)):
            out.append(f"study.{k} = '{cfg.study.get(k)}' still contains the '{PLACEHOLDER}' "
                       f"placeholder — the study window comes from this product's specification, "
                       f"never from the template")

    # The temporal field model (engine.config): the split fields are OPTIONAL and default along a
    # stated chain, but two names for one fact must not disagree, and the fields must order as
    # the concepts do — observation cannot end before enrollment closes, and nothing is observed
    # past the delivery's cut. String comparison is sound for ISO dates, the only form the study
    # window is written in.
    st = cfg.study
    for alias, legacy in (("index_period_start", "index_start"), ("index_period_end", "index_end")):
        if st.get(alias) and st.get(legacy) and str(st[alias]) != str(st[legacy]):
            out.append(f"study.{alias} = '{st[alias]}' but study.{legacy} = '{st[legacy]}' — two "
                       f"names for the enrollment bound disagreeing; state one, or make them equal")
    # The ordering checks compare the EFFECTIVE values (through the default chains), not only
    # the literally-stated keys: a pack stating only data_cutoff earlier than index_end would
    # otherwise pass while its effective observation_end — which id3mosfu reads — violates the
    # invariant through the fallback (an adversarial review caught the stated-keys-only shape).
    from config import data_cutoff as _dc, index_period_end as _ipe, observation_end as _oe
    if _oe(st) and _ipe(st) and str(_oe(st)) < str(_ipe(st)):
        out.append(f"effective study.observation_end '{_oe(st)}' precedes the enrollment close "
                   f"'{_ipe(st)}' — observation cannot end before the last patient enters "
                   f"(mind the default chain: an unstated field falls back)")
    if _dc(st) and _oe(st) and str(_dc(st)) < str(_oe(st)):
        out.append(f"effective study.data_cutoff '{_dc(st)}' precedes effective observation_end "
                   f"'{_oe(st)}' — nothing is observed past the delivery's cut")

    # --- variable-pack placeholders ---------------------------------------
    # `variables_scaffold.py` emits parameter SKELETONS whose every value is the ONE placeholder
    # marker, meant to be filled from the approved workbook after a human copies a skeleton into
    # variables/. Only run.* and study.* were scanned, so a half-filled skeleton — bands copied,
    # window forgotten — would have built with the marker as a literal band label. Strict mode
    # (the build) refuses the marker ANYWHERE in a pack; lint mode keeps allowing it, the same
    # split every other placeholder check here has.
    if strict:
        def _holes(node, path):
            if isinstance(node, dict):
                for k, v in node.items():
                    yield from _holes(v, f"{path}.{k}")
            elif isinstance(node, list):
                for i, v in enumerate(node):
                    yield from _holes(v, f"{path}[{i}]")
            elif isinstance(node, str) and PLACEHOLDER in node:
                yield path
        with _broken_pack_ok():
            for role in sorted(cfg.roles()):
                for where in _holes(cfg.pack(role), f"variables/{role}"):
                    out.append(f"{where} still contains the '{PLACEHOLDER}' placeholder — every "
                               f"scaffolded parameter value comes from the approved workbook "
                               f"before a build may run")

    # --- source availability ----------------------------------------------
    out.extend(availability_problems(cfg, strict=strict))
    # --- source grain declarations ----------------------------------------
    # Shape errors only: whether the DATA honours a declared grain is a Spark question answered by
    # `grain.source_grain_report` against a delivery, never by config lint.
    out.extend(source_grain(cfg)[1])

    # --- cohorts ----------------------------------------------------------
    if not cfg.cohorts:
        out.append("cohorts is empty")
    ids, ns = set(), set()
    for c in cfg.cohorts:
        for f in ("id", "label", "cohortn", "index"):
            if f not in c:
                out.append(f"cohort {c.get('id', '?')} missing '{f}'")
        if c.get("id") in ids:
            out.append(f"duplicate cohort id '{c.get('id')}'")
        ids.add(c.get("id"))
        if c.get("cohortn") in ns:
            out.append(f"duplicate cohortn {c.get('cohortn')}")
        ns.add(c.get("cohortn"))
        idx = c.get("index")
        if idx and idx != "lot_start_date" and idx not in cfg.index_dates:
            out.append(f"cohort {c.get('id')} index '{idx}' not in index_dates and != lot_start_date")
        m = c.get("maintenance")
        if m is not None and not isinstance(m, bool):
            out.append(f"cohort {c.get('id')} maintenance must be true/false, got {m!r}")

    # --- LOT model (config-driven line numbering; defaults reproduce prostate) -------------
    ln = (cfg.raw.get("lot") or {}).get("line_number")
    if ln is not None and ln not in ("new_lot_n", "linenumber"):
        out.append(f"lot.line_number '{ln}' must be 'new_lot_n' or 'linenumber'")

    # --- sources (only the core set is required; the rest are optional per tumor) ----------
    if not cfg.sources:
        out.append("sources is empty")
    else:
        for missing in sorted(REQUIRED_SOURCES - set(cfg.sources)):
            out.append(f"sources is missing required mapping '{missing}'")

    # --- data format / formats overlay (EDM | Panoramic …) --------------------
    fmts = cfg.raw.get("formats") or {}
    if cfg.data_format != "EDM" and cfg.data_format not in fmts:
        out.append(f"data_format '{cfg.data_format}' has no `formats.{cfg.data_format}` overlay — "
                   "it would silently run on the base (EDM) sources")
    for fname, fblk in fmts.items():
        if not isinstance(fblk, dict):
            out.append(f"formats.{fname} must be a mapping")
            continue
        avail = {**(cfg.raw.get("sources") or {}), **(fblk.get("sources") or {})}
        for s in (fblk.get("rename") or {}):
            if s not in avail:
                out.append(f"formats.{fname}.rename references undeclared source '{s}'")

    # --- source_union (optional multi-schema union: EC = Flatiron EDM ∪ Dostar registry) --------
    u = cfg.source_union
    if u is not None:
        members = u.get("members") or []
        if not members:
            out.append("source_union.members is empty")
        for i, m in enumerate(members):
            for f in ("schema", "flag"):
                if not (isinstance(m, dict) and m.get(f)):
                    out.append(f"source_union.members[{i}] missing '{f}'")
            if strict and isinstance(m, dict) and PLACEHOLDER in str(m.get("schema")):
                out.append(f"source_union.members[{i}].schema '{m.get('schema')}' still "
                           f"contains the '{PLACEHOLDER}' placeholder")

    # --- vendor / tumor class --------------------------------------------
    if cfg.vendor not in KNOWN_VENDORS and not cfg.source_layout:
        out.append(f"vendor '{cfg.vendor}' is unknown and no run.source_layout override is set "
                   f"(known vendors: {sorted(KNOWN_VENDORS)})")
    if cfg.tumor_class not in KNOWN_TUMOR_CLASSES:
        out.append(f"tumor_class '{cfg.tumor_class}' not one of {sorted(KNOWN_TUMOR_CLASSES)}")

    # the index-date source must itself be a declared source
    if cfg.index_dates.get("advanced_diagnosis_date") and cfg.index_source not in cfg.sources:
        out.append(f"index source '{cfg.index_source}' "
                   f"(index_dates.advanced_diagnosis_date.source) is not a declared source")

    # line_outcomes without visit_sources: vis120 is then NULL for every patient, and nothing else
    # says so. Absent must be a decision, never an oversight — either name the encounter sources,
    # or write `visit_sources: []` to state this product has no encounter feed. An external review
    # caught mCRC declaring visit AND telemed tables while emitting vis120=0 for everyone because
    # this key was simply missing.
    with _broken_pack_ok():
        lo = cfg.pack("outcomes").get("line_outcomes")
        if lo is not None and "visit_sources" not in lo:
            declared = sorted(s for s in cfg.sources if s in ("visit", "telemed"))
            out.append("outcomes.line_outcomes has no `visit_sources` — vis120/trtdis will be "
                       "NULL (unknown) for every line patient. Name the encounter sources"
                       + (f" (this pack declares: {', '.join(declared)})" if declared else "")
                       + ", or set `visit_sources: []` to record that no encounter feed exists.")
    # THE STAGE DECLARATIONS MUST BE READABLE. required_columns/referenced_sources compose from
    # stage_reads and simply skip a stage whose declaration raises — so this is where a
    # malformed pack is SAID, once, by the owning stage's name (a malformed visit_sources entry,
    # a broken clinical block). The old composition suppressed these wholesale: preflight green
    # over a config the build would refuse.
    _reads, read_errors = stage_reads(cfg)
    out += read_errors

    # A per-model index source the LOADER does not honour is refused, not ignored. The loader
    # materializes every index_dates model on cfg.index_source; the validator used to honour a
    # per-rule `source:` — preflight requiring columns on one table while the loader looked at
    # another. No pack uses the key; until the loader implements it, writing it is an error.
    for model, rule in sorted((cfg.index_dates or {}).items()):
        if isinstance(rule, dict) and rule.get("source", cfg.index_source) != cfg.index_source:
            out.append(f"index.{model}.source: '{rule['source']}' — the loader materializes "
                       f"every index model on the index source ('{cfg.index_source}') and does "
                       f"not honour a per-model source. Refused rather than ignored: a key one "
                       f"tool honours and another skips is two answers to one question.")

    # match_on.category_source may only name what the build actually reads. The category
    # aggregate is built from drug_episode; a codelist pointing its category check at another
    # role would validate a table the build never reads while the build keeps reading
    # drug_episode — the check would be about nothing.
    with _broken_pack_ok():
        cs = (cfg.codelist("treatment_categories") or {}).get("match_on", {}).get("category_source")
        if cs and cs != "drug_episode":
            out.append(f"treatment_categories.match_on.category_source: '{cs}' — the per-line "
                       f"category is aggregated from drug_episode and the build reads no other "
                       f"role for it. A vocabulary check pointed elsewhere checks a table the "
                       f"build does not read.")

    # A NAMES-LIST follow_up_sources entry naming an UNDECLARED source is dead config: the
    # default set degrades gracefully when a pack simply lacks a feed, but a list that
    # explicitly RESTRICTS to a feed the pack does not declare leaves fu_enddt with fewer
    # contributors than the config claims, with nothing saying so.
    with _broken_pack_ok():
        fus = cfg.pack("clinical").get("death_date_imputation", {}).get("follow_up_sources")
        if fus and not isinstance(fus[0], dict):
            for name in fus:
                if str(name) not in cfg.sources:
                    out.append(f"follow_up_sources names '{name}', which sources: does not "
                               f"declare — restricting the follow-up set to an absent feed "
                               f"contributes nothing and looks configured.")

    # --- variable packs (by role / file stem) ----------------------------
    try:
        roles = cfg.roles()
        for missing in sorted(EXPECTED_ROLES - roles):
            out.append(f"variable pack for role '{missing}' not found "
                       f"(expected variables/{missing}.yaml)")
    except Exception as e:  # noqa: BLE001 - surface any load/parse error as a problem
        out.append(f"failed to load variable packs: {e}")

    # --- banded lists need a catch-all -----------------------------------
    out += _bands_problems(cfg)

    # --- clinical categoricals (grade/histology/…): each needs name/column/groups -----------
    with _broken_pack_ok():
        clin_pack = cfg.pack("clinical")
        # clinical.staging.source (when set) must be a declared source — else `stage` is silently
        # dropped at runtime (the stage uses src.get(...)). No source -> the index source.
        ss = (clin_pack.get("staging") or {}).get("source")
        if ss and ss not in cfg.sources:
            out.append(f"clinical.staging.source '{ss}' is not a declared source")
        for i, cat in enumerate(clin_pack.get("categoricals") or []):
            for f in ("name", "column", "groups"):
                if not cat.get(f):
                    out.append(f"clinical.categoricals[{i}] missing '{f}'")
            # An explicit source must be a declared source — a typo (source: enhnaced) would
            # otherwise lint clean, be skipped by required_columns()/preflight, and silently omit
            # the variable at runtime. (No source -> the index source, validated above.)
            cs = cat.get("source")
            if cs and cs not in cfg.sources:
                out.append(f"clinical.categoricals[{i}].source '{cs}' is not a declared source")
            # A WINDOWED categorical is a different question from an unwindowed one — the value at
            # index, not the patient's latest value ever — and the window needs a date to be
            # measured from. `window_days` without `date_column` is the silent case: the engine
            # cannot apply the window, and the nearest thing it could do (fall back to the
            # unwindowed pick) would answer the other question while the config says this one.
            wd = cat.get("window_days")
            if wd is not None:
                if not cat.get("date_column"):
                    out.append(f"clinical.categoricals[{i}] sets window_days without date_column — "
                               f"there is no date for the window to be measured from, and the "
                               f"value AT INDEX is not the patient's latest value")
                if not (isinstance(wd, (list, tuple)) and len(wd) == 2
                        and all(x is None or isinstance(x, int) for x in wd)):
                    out.append(f"clinical.categoricals[{i}].window_days must be [lo, hi] day offsets "
                               f"(either may be null for open-ended), got {wd!r}")
            # THE TWO CHECKS THE PANEL LOOP RUNS AND THIS ONE DID NOT. A generic categorical was
            # held to presence of name/column/groups and a declared source, and nothing else — so
            # an unregistered matcher operator or an unregistered `pick` reached the engine from a
            # categorical while the identical mistake in a panel was refused at lint time. Same
            # config shape, two answers, and the weaker one was the default path.
            out += [f"clinical.categoricals[{i}] {e}" for e in value_matcher_errors(cat.get("groups"))]
            out += [f"clinical.categoricals[{i}] {e}" for e in selection_errors(cat)]
            # THE MAPPING FORM, seen through. `pick: {method: priority}` is legal config that the
            # engine unwraps at runtime; comparing the raw value to the string "priority" missed it,
            # so the refusal below could be escaped by spelling the same thing the other way.
            pk = cat.get("pick")
            pk = pk.get("method", pk) if isinstance(pk, dict) else pk
            # A KEY THE SELECTOR CANNOT CONSUME IS REFUSED, not ignored. `same_date_conflict` is
            # resolved per (patient, index, DATE), so a categorical with no `date_column` has no
            # date for two records to conflict on and the unwindowed path cannot honour it. It used
            # to validate and do nothing — the shape this whole option exists to remove.
            if cat.get("same_date_conflict") is not None and not cat.get("date_column"):
                out.append(f"clinical.categoricals[{i}] sets same_date_conflict without "
                           f"date_column — the rule resolves two records dated the SAME DAY, and "
                           f"with no date column there is no such comparison to make")
            # `priority` ranks across ALL in-window rows and is meaningless without a window: with
            # one row per patient there is nothing to rank against.
            if pk == "priority" and wd is None:
                out.append(f"clinical.categoricals[{i}] picks 'priority' without window_days — "
                           f"priority ranks the rows inside a window, and there is no window")
        # closest-to-index panels (biomarkers / labs): block + each panel item need their fields
        for blk_key in CLOSEST_PANELS:
            blk = clin_pack.get(blk_key)
            if not blk:
                continue
            # `date_column` is required only under the DEFAULT date basis. A block selecting
            # `later_of` names `columns:` instead, and demanding both would make the new basis
            # unusable while looking like a completeness check.
            needed = ["source", "name_column", "value_column", "panel"]
            basis = blk.get("date_basis") or "column"
            if (basis.get("method") if isinstance(basis, dict) else basis) == "column":
                needed.insert(3, "date_column")
            for f in needed:
                if not blk.get(f):
                    out.append(f"clinical.{blk_key} missing '{f}'")
            # Named selection vocabulary, refused by the registry that owns it — never guessed.
            out += [f"clinical.{blk_key} {e}" for e in selection_errors(blk)]
            for i, item in enumerate(blk.get("panel") or []):
                out += [f"clinical.{blk_key}.panel[{i}] {e}" for e in selection_errors(None, item)]
                out += [f"clinical.{blk_key}.panel[{i}] {e}"
                        for e in value_matcher_errors(item.get("groups"))]
                if not item.get("name"):
                    out.append(f"clinical.{blk_key}.panel[{i}] missing 'name'")
                if not item.get("match") and not item.get("match_any"):   # scalar match OR a multi-name set
                    out.append(f"clinical.{blk_key}.panel[{i}] needs 'match' or 'match_any'")
                if not item.get("groups") and not item.get("bands"):
                    out.append(f"clinical.{blk_key}.panel[{i}] needs 'groups' or 'bands'")
            if blk.get("source") and blk["source"] not in cfg.sources:
                out.append(f"clinical.{blk_key}.source '{blk['source']}' is not a declared source")
            # `emit_date` is a switch, and a truthy non-bool (`emit_date: "no"`) would turn the
            # column ON while reading as off. The column it adds is published, so a silent
            # misreading here changes the delivered schema.
            ed = blk.get("emit_date")
            if ed is not None and not isinstance(ed, bool):
                out.append(f"clinical.{blk_key}.emit_date must be true or false, got {ed!r}")

        # --- comorbidity index: a weighted sum of DISTINCT conditions over a lookback -----------
        cci = clin_pack.get("comorbidity_index")
        if cci:
            for f in ("source", "name", "code_column", "conditions"):
                if not cci.get(f):
                    out.append(f"clinical.comorbidity_index missing '{f}'")
            if cci.get("source") and cci["source"] not in cfg.sources:
                out.append(f"clinical.comorbidity_index.source '{cci['source']}' is not a "
                           f"declared source")
            # The lookback is what makes it BASELINE comorbidity. Without a date column there is no
            # window, so the score would silently be computed over the patient's whole record —
            # including diagnoses made after index, which is the confounder measuring the outcome.
            if cci.get("window_days") and not cci.get("date_column"):
                out.append("clinical.comorbidity_index sets window_days without date_column — the "
                           "lookback cannot be applied, and a score over the whole record counts "
                           "diagnoses made AFTER index")
            wd = cci.get("window_days")
            if not wd:
                out.append("clinical.comorbidity_index has no window_days — baseline comorbidity is "
                           "defined by its pre-index lookback, and without one this scores every "
                           "diagnosis ever recorded, including post-index")
            elif not (isinstance(wd, (list, tuple)) and len(wd) == 2
                      and all(isinstance(x, int) and not isinstance(x, bool) for x in wd)):
                # Truthiness was the only test, so `[30, 90]`, `["a", "b"]` and a bare `True` all
                # passed. BOTH bounds are required and both must be integers: an open-ended
                # comorbidity lookback is not a lookback, and a non-integer reaches Spark as a
                # malformed `date_add`.
                out.append(f"clinical.comorbidity_index.window_days must be two integer day offsets "
                           f"[lo, hi] — neither may be null, because an open-ended lookback is not a "
                           f"lookback; got {wd!r}")
            else:
                lo, hi = wd
                if lo > hi:
                    out.append(f"clinical.comorbidity_index.window_days is reversed ({lo} > {hi}) — "
                               f"the window selects no rows, and every patient scores 0")
                if hi > 0 and not cci.get("post_index_days_reviewed"):
                    # THE ONE THAT PRODUCES A PLAUSIBLE WRONG NUMBER. A window ending after index
                    # counts diagnoses recorded AFTER the anchor, so a covariate meant to describe
                    # the patient at baseline has partly measured the outcome. Refused unless the
                    # pack says in as many words that the choice was reviewed — some claims designs
                    # do allow a short post-index tail for coding lag, and that is a decision, not a
                    # default.
                    out.append(f"clinical.comorbidity_index.window_days ends {hi} days AFTER index — "
                               f"baseline comorbidity measured past the anchor has partly measured "
                               f"the outcome. If a post-index tail is intended (coding lag), state "
                               f"`post_index_days_reviewed: <who/why>` beside it.")
            # HIERARCHY MUST BE ACYCLIC. A cycle, or a condition superseding itself, would make the
            # score depend on evaluation order — and self-supersession zeroes the winner by its own
            # presence, so the condition can never contribute.
            edges = {c.get("name"): set(c.get("supersedes") or [])
                     for c in cci.get("conditions") or [] if c.get("name")}
            for nm, losers in edges.items():
                if nm in losers:
                    out.append(f"clinical.comorbidity_index: condition '{nm}' supersedes itself — "
                               f"its own presence would zero it, so it can never contribute")
            # A CYCLE IS A NODE ON ITS OWN CURRENT PATH — not a node seen twice anywhere in the walk.
            #
            # The first version kept ONE `path` set for the whole traversal from each start and never
            # removed anything from it, so a converging DAG read as cyclic: with A→B, A→C, B→D and
            # C→D, D is reached down the C branch, added to `path`, and then reached again down the B
            # branch — reported as a cycle in a hierarchy that has none. That is a valid Charlson
            # shape (two severe conditions both superseding one mild one), and the validator refused
            # it. A check that rejects correct configurations gets deleted, which costs the cycles
            # it does catch.
            #
            # Colour-marked DFS instead: GREY = on the current path, BLACK = finished. Recursion is
            # explicit so a deep hierarchy cannot blow the stack.
            grey, black, seen_cycle = set(), set(), set()
            for start in edges:
                if start in black:
                    continue
                stack = [(start, iter(sorted(e for e in edges.get(start, ()) if e in edges)))]
                grey.add(start)
                while stack:
                    node, children = stack[-1]
                    nxt = next(children, None)
                    if nxt is None:
                        grey.discard(node)
                        black.add(node)
                        stack.pop()
                        continue
                    if nxt in grey:                       # a back edge — a real cycle
                        if nxt not in seen_cycle:
                            seen_cycle.add(nxt)
                            out.append(f"clinical.comorbidity_index: the supersedes hierarchy has a "
                                       f"cycle through '{nxt}' — the score would depend on the order "
                                       f"the conditions happen to be listed in")
                        continue
                    if nxt in black:                      # already fully explored — a diamond, fine
                        continue
                    grey.add(nxt)
                    stack.append((nxt, iter(sorted(e for e in edges.get(nxt, ()) if e in edges))))
            names = set()
            for i, c in enumerate(cci.get("conditions") or []):
                where = f"clinical.comorbidity_index.conditions[{i}]"
                nm = c.get("name")
                if not nm:
                    out.append(f"{where} missing 'name'")
                elif nm in names:
                    # Duplicate names make `supersedes` ambiguous and double-count silently.
                    out.append(f"{where} repeats the condition name '{nm}'")
                else:
                    names.add(nm)
                if c.get("weight") is None:
                    out.append(f"{where} has no 'weight' — the weight is the algorithm's, and a "
                               f"default of 1 would silently flatten a weighted index")
                elif not isinstance(c.get("weight"), (int, float)) or isinstance(c["weight"], bool):
                    out.append(f"{where}.weight must be a number, got {c['weight']!r}")
                ops = [k for k in c if k not in ("name", "weight", "supersedes")]
                if len(ops) != 1:
                    out.append(f"{where} needs exactly one match operator, got {sorted(ops)}")
            # A `supersedes` naming a condition that is not in the list does nothing, and reads
            # exactly like a hierarchy that is being applied.
            for i, c in enumerate(cci.get("conditions") or []):
                for s in c.get("supersedes") or []:
                    if s not in names:
                        out.append(f"clinical.comorbidity_index.conditions[{i}] supersedes "
                                   f"'{s}', which is not a condition in this list — the hierarchy "
                                   f"reads as applied and does nothing")

    # --- mortality conflict-resolution policy ----------------------------
    with _broken_pack_ok():
        imp = cfg.pack("clinical").get("death_date_imputation", {})
        cr = imp.get("conflict_resolution")
        if cr is not None and cr not in DEATH_CONFLICT_POLICIES:
            out.append("clinical.death_date_imputation.conflict_resolution "
                       f"'{cr}' not one of {sorted(DEATH_CONFLICT_POLICIES)}")

    # --- BMI/BSA formula methods (named, resolved from the engine registries) --------------------
    with _broken_pack_ok():
        vit = cfg.pack("clinical").get("vitals")
        if vit:
            # Legacy decorative keys the engine no longer reads -> flag so they can't silently mislead.
            for legacy in ("bmi_formula", "bsa_formula"):
                if legacy in vit:
                    out.append(f"clinical.vitals.{legacy} is a legacy decorative key the engine no longer "
                               f"reads — replace it with {legacy.split('_')[0]}_method: <name>")
            bm = vit.get("bmi_method")                 # required + non-empty string when vitals is on
            if not (isinstance(bm, str) and bm):
                out.append("clinical.vitals.bmi_method is required (a non-empty method name) when vitals "
                           f"is configured; one of {sorted(BMI_METHODS)}")
            elif bm not in BMI_METHODS:
                out.append(f"clinical.vitals.bmi_method '{bm}' not one of {sorted(BMI_METHODS)}")
            bs = vit.get("bsa_method")                 # optional; if present must be a known method
            if bs is not None and (not isinstance(bs, str) or bs not in BSA_METHODS):
                out.append(f"clinical.vitals.bsa_method '{bs}' not one of {sorted(BSA_METHODS)}")

    # --- follow_up_sources: strict per-entry structure so a typo fails lint, not Spark --------------
    # Two forms mirror the engine: a DICT list (full override) or a NAMES list (restrict the engine
    # default set to these logical sources). BOTH are validated — an unchecked typo in either silently
    # yields empty follow-up, which nulls out fu_enddt for every patient.
    with _broken_pack_ok():
        fus = cfg.pack("clinical").get("death_date_imputation", {}).get("follow_up_sources")
        if fus and isinstance(fus[0], dict):
            aliases = []
            for i, s in enumerate(fus):
                if not isinstance(s, dict):
                    out.append(f"death_date_imputation.follow_up_sources[{i}] must be a mapping")
                    continue
                srcn = s.get("source")
                if not (isinstance(srcn, str) and srcn):
                    out.append(f"follow_up_sources[{i}] missing 'source'")
                # NB: an entry pointing at an UNDECLARED source is NOT flagged — the engine gracefully
                # skips absent sources (a heme product declares fewer; see test_optional_source_not_required).
                if not (isinstance(s.get("date_column"), str) and s.get("date_column")):
                    out.append(f"follow_up_sources[{i}] missing 'date_column'")
                al = s.get("alias", f"last_{srcn}date" if srcn else None)
                if al is not None and not isinstance(al, str):
                    out.append(f"follow_up_sources[{i}].alias must be a string")
                else:
                    aliases.append(al)
                # the LOT activity date is referenced BY NAME downstream (death-date reconciliation), so
                # its alias is not freely configurable.
                if srcn == "lot" and al != "last_lotenddate":
                    out.append(f"follow_up_sources[{i}] (lot) must use alias 'last_lotenddate' — the "
                               "death-date reconciliation depends on that exact name")
                # filter_method must be a NON-EMPTY STRING naming a FOLLOWUP_FILTERS entry. Type-check
                # FIRST: a non-string such as `filter_method: []` raises an unhashable-key TypeError
                # in `fm not in FOLLOWUP_FILTERS`, which the outer except would swallow, letting a malformed
                # value pass lint.
                fm = s.get("filter_method")
                if fm is not None:
                    if not (isinstance(fm, str) and fm):
                        out.append(f"follow_up_sources[{i}].filter_method must be a non-empty string "
                                   f"naming a registry filter, got {fm!r}")
                    elif fm not in FOLLOWUP_FILTERS:
                        out.append(f"follow_up_sources[{i}].filter_method '{fm}' not one of "
                                   f"{sorted(FOLLOWUP_FILTERS)}")
                    if s.get("filter") is not None:   # the named filter_method WINS; raw 'filter' is dropped
                        out.append(f"follow_up_sources[{i}] sets both 'filter' and 'filter_method' — the "
                                   "named filter_method wins and 'filter' is silently ignored; keep one")
            dups = sorted({a for a in aliases if a is not None and aliases.count(a) > 1})
            if dups:
                out.append(f"follow_up_sources has duplicate aliases: {dups}")
        elif fus:
            # NAMES-list form: each entry restricts the engine default set to a KNOWN logical source.
            # An unknown name matches nothing -> empty follow-up, so flag it (the dict-form skip-undeclared
            # rule does NOT apply here: these names select FROM the fixed engine set, they don't add sources).
            for i, name in enumerate(fus):
                if not (isinstance(name, str) and name in FOLLOWUP_SOURCE_NAMES):
                    out.append(f"follow_up_sources[{i}] '{name}' is not a known follow-up source "
                               f"(one of {sorted(FOLLOWUP_SOURCE_NAMES)}); a typo silently yields "
                               "empty follow-up")

    # --- treatment prior-taxane (optional pre-mCRPC line source) ---------
    with _broken_pack_ok():
        pt = cfg.pack("treatment").get("prior_taxane") or {}
        pre = pt.get("pre_mcrpc_source")
        if pre and pre not in cfg.sources:
            out.append(f"treatment.prior_taxane.pre_mcrpc_source '{pre}' is not a declared source")

    # --- outcomes progression / PFS (optional) ---------------------------
    with _broken_pack_ok():
        pcfg = cfg.pack("outcomes").get("progression")
        if pcfg:
            if pcfg.get("source") and pcfg["source"] not in cfg.sources:
                out.append(f"outcomes.progression.source '{pcfg['source']}' is not a declared source")
            for f in ("source", "date_column", "evidence_columns", "pseudoprogression_column"):
                if not pcfg.get(f):
                    out.append(f"outcomes.progression missing '{f}'")

    # --- outcomes platinum_sensitivity / PROC (optional: OC) -------------
    with _broken_pack_ok():
        psc = cfg.pack("outcomes").get("platinum_sensitivity")
        if psc:
            if psc.get("source") and psc["source"] not in cfg.sources:
                out.append(f"outcomes.platinum_sensitivity.source '{psc['source']}' is not a declared source")
            for f in ("source", "line_number_column", "name_column", "start_column", "end_column",
                      "platinum_agents"):
                if not psc.get(f):
                    out.append(f"outcomes.platinum_sensitivity missing '{f}'")

    # --- outcomes ads_derived (optional: cross-stage landmarks/intervals/expressions) ----
    with _broken_pack_ok():
        out += [f"outcomes.{e}" for e in
                ads_derived_errors(cfg.pack("outcomes").get("ads_derived"))]

    # --- derived cohorts (optional: OC PROC split) -----------------------
    with _broken_pack_ok():
        ids = {c.get("id") for c in cfg.cohorts}
        base_ns = {c.get("cohortn") for c in cfg.cohorts}
        for dc in (cfg.raw.get("derived_cohorts") or []):
            for f in ("id", "cohortn", "label", "from", "where"):
                if not dc.get(f):
                    out.append(f"derived_cohorts entry missing '{f}'")
            for frm in (dc.get("from") or []):
                if frm not in ids:
                    out.append(f"derived_cohorts '{dc.get('id')}' from-cohort '{frm}' is not a declared cohort")
            if dc.get("cohortn") in base_ns:
                out.append(f"derived_cohorts '{dc.get('id')}' cohortn {dc.get('cohortn')} collides with a base cohort")

    # --- clinical surgery sub-block (optional: OC) -----------------------
    with _broken_pack_ok():
        scfg = cfg.pack("clinical").get("surgery")
        if scfg:
            for s in (scfg.get("source"), scfg.get("line_source", "lot")):
                if s and s not in cfg.sources:
                    out.append(f"clinical.surgery source '{s}' is not a declared source")
            for f in ("source", "surgery_flag_column", "surgery_date_column", "line_start_column",
                      "line_end_column", "pcs_label", "ics_label", "none_label"):
                if not scfg.get(f):
                    out.append(f"clinical.surgery missing '{f}'")

    # --- declared coding systems ------------------------------------------
    out += _vocabulary_problems(cfg)

    # --- treatment codelist ----------------------------------------------
    out += _codelist_problems(cfg)

    return out


def _vocabulary_problems(cfg) -> list[str]:
    """The `vocabularies:` block itself: every entry names a declared source, a column and a system.

    Absent means absent. A pack that declares nothing is not asserting its columns are text, and
    nothing here or in `_codelist_problems` refuses it — the engine behaves exactly as it did before
    this block existed. The value of declaring is that a CONTRADICTION becomes reportable; the cost
    of not declaring is that it stays invisible, which is the state every pack was already in.
    """
    out: list[str] = []
    seen = {}
    for i, v in enumerate(cfg.vocabularies):
        where = f"vocabularies[{i}]"
        source = str(v.get("source") or "").strip()
        column = str(v.get("column") or "").strip()
        if not source:
            out.append(f"{where}: no source named")
        elif source not in cfg.sources:
            out.append(f"{where}: source '{source}' is not declared in sources: "
                       f"{sorted(cfg.sources)}")
        if not column:
            out.append(f"{where}: no column named")
        for why in vocabularies.system_errors(v.get("system")):
            out.append(f"{where}: {why}")
        key = (source.lower(), column.lower())
        if source and column:
            if key in seen:
                # Last-wins on a duplicate would silently pick one of two contradictory answers to
                # "what does this column carry" — the question the block exists to settle.
                out.append(f"{where}: {source}.{column} already declared at {seen[key]} — one "
                           f"column carries one coding system")
            else:
                seen[key] = where
    return out


def _bands_problems(cfg) -> list[str]:
    out: list[str] = []
    for role, path in BANDED_LISTS:
        try:
            node = cfg.pack(role)
        except Exception:           # missing pack reported by the roles check
            continue
        for key in path:
            node = node.get(key) if isinstance(node, dict) else None
        if not isinstance(node, list):
            continue
        n = sum(1 for b in node if isinstance(b, dict) and b.get("when") == "fallthrough")
        if n != 1:
            out.append(f"{role}.{'.'.join(path)} needs exactly one 'when: fallthrough' "
                       f"catch-all band, found {n}")
        out += _band_coverage_problems(f"{role}.{'.'.join(path)}", node)
    return out


def _band_coverage_problems(where, node) -> list[str]:
    """Gaps and overlaps between numeric bands — the two ways a legal band list is clinically wrong.

    The fallthrough check above asks whether UNMATCHED input has a defined answer. It cannot see the
    two failures that matter more, because both produce a perfectly legal list:

      GAP       `18-64` then `70-79` leaves 65-69 matching nothing, so every 65-to-69-year-old
                lands in the catch-all and is reported as Unknown. The counts still add up. The
                distribution still looks plausible. An entire age group is silently mislabelled.
      OVERLAP   `18-64` alongside `60-74` means a 62-year-old matches both, and the compiled CASE
                takes the FIRST matching WHEN — so the answer depends on the order the bands happen
                to sit in the YAML, which nobody reviews as semantics.

    Both were silent: an adversarial config planted each and `_bands_problems` returned nothing.

    ONLY CLOSED INTEGER BANDS ARE CHAINED. A band needs both `min` and `max`, both integers, to
    take part: `75+` (min only) legitimately ends the chain, and BMI bands are written `min: 18.5,
    max: 24.9` where the arithmetic gap to 25.0 is conventional rather than a defect. Bands this
    cannot read are COUNTED AND REPORTED rather than passed over, because "no gap found" over a
    list this only half understood is the absence-reads-as-clean failure again.
    """
    bands = [b for b in node if isinstance(b, dict) and b.get("when") != "fallthrough"]
    closed, unread = [], 0
    for b in bands:
        lo, hi = b.get("min"), b.get("max")
        if isinstance(lo, int) and isinstance(hi, int) and not isinstance(lo, bool):
            closed.append((lo, hi, str(b.get("label") or b.get("code") or "?")))
        else:
            unread += 1
    out = []
    closed.sort()
    for (lo, hi, lab), (lo2, hi2, lab2) in zip(closed, closed[1:]):
        if hi >= lo2:
            out.append(f"{where}: bands '{lab}' [{lo}-{hi}] and '{lab2}' [{lo2}-{hi2}] OVERLAP — a "
                       f"value in [{lo2}-{min(hi, hi2)}] matches both, and the compiled CASE takes "
                       f"whichever is written first, so the answer depends on YAML order")
        elif hi + 1 < lo2:
            out.append(f"{where}: GAP between '{lab}' [{lo}-{hi}] and '{lab2}' [{lo2}-{hi2}] — "
                       f"[{hi + 1}-{lo2 - 1}] matches no band and falls to the catch-all, so that "
                       f"whole range is reported as the fallthrough value, not as its own group")
    # Reported only when something was actually checked; a list of purely open-ended bands is not a
    # finding, it is a list this check has nothing to say about.
    if out and unread:
        out.append(f"{where}: {unread} band(s) are not closed integer ranges and were NOT checked "
                   f"for gaps or overlaps — this report is partial")
    return out


def _codelist_problems(cfg) -> list[str]:
    out: list[str] = []
    try:
        cl = cfg.codelist("treatment_categories")
    except Exception as e:  # noqa: BLE001
        return [f"failed to load treatment_categories codelist: {e}"]

    cats = cl.get("categories") or []
    if not cats:
        return ["treatment_categories has no categories"]

    codes = []
    catchalls = []
    for i, c in enumerate(cats):
        for f in ("code", "label", "match"):
            if f not in c:
                out.append(f"treatment category #{i} missing '{f}'")
        codes.append(c.get("code"))
        if c.get("match") == {"always": True}:
            catchalls.append(i)
    dup = {x for x in codes if codes.count(x) > 1}
    if dup:
        out.append(f"treatment category codes not unique: {sorted(dup)}")
    if len(catchalls) != 1:
        out.append(f"treatment_categories needs exactly one always-true catch-all, found {len(catchalls)}")
    elif catchalls[0] != len(cats) - 1:
        out.append("the always-true catch-all must be the LAST category (case_when order)")

    out += _operator_vocabulary_problems(cfg, cl)

    try:
        compile_case(cl)   # exercises the match DSL compiler on every entry
    except Exception as e:  # noqa: BLE001
        out.append(f"treatment_categories failed to compile: {e}")
    return out


# Which match operators read the NAME column, and which read a CODE column. Split here rather than
# inside the compiler because this is a question about the DSL's surface, not about its SQL.
NAME_OPERATORS = ("equals", "like_any", "regexp", "is_null")
CATEGORY_OPERATORS = ("category_equals",)


def _operator_vocabulary_problems(cfg, cl) -> list[str]:
    """Refuse a name-based operator against a column the pack DECLARED as coded.

    This is the whole reason the declaration exists. `like_any: ["%bevacizumab%"]` against an NDC
    column is valid SQL over a real column that matches nothing: every line falls to the catch-all
    category, the build succeeds, and the numbers are wrong with no error anywhere. Nothing else in
    the framework can see it — a preflight column check passes (the column exists), the compiler
    passes (the operator is real), and a golden built from the same wrong config agrees with itself.

    ONLY fires on a positive contradiction. An undeclared column yields None from `system_for` and
    is left alone: this must not become a rule that every pack has to satisfy before it can run.
    """
    mo = cl.get("match_on") or {}
    name_col = mo.get("name_column", "linename")
    cat_col = mo.get("drug_category_column", "detaileddrugcategory")
    # Where those columns live. Defaults are what the treatment stage actually reads — linename off
    # `lot`, the drug category off `drug_episode` — and are overridable for a feed that differs.
    name_src = mo.get("source", "lot")
    cat_src = mo.get("category_source", "drug_episode")

    out: list[str] = []
    checked = ((name_col, name_src, NAME_OPERATORS, "name"),
               (cat_col, cat_src, CATEGORY_OPERATORS, "drug-category"))

    def _ops(match, found):
        if not isinstance(match, dict):
            return
        for op, val in match.items():
            if op in ("all_of", "any_of"):
                for sub in (val or []):
                    _ops(sub, found)
            else:
                found.add(op)

    used = set()
    for c in cats_of(cl):
        _ops(c.get("match"), used)

    for column, source, operators, what in checked:
        system = cfg.system_for(source, column)
        if system is None or not vocabularies.is_coded(system):
            continue
        hit = sorted(used & set(operators))
        if hit:
            out.append(
                f"treatment_categories matches the {what} column {source}.{column} with "
                f"{hit} — but this pack declares it as {system}, a coding system. A LIKE or "
                f"equality against a code column matches nothing and sends every line to the "
                f"catch-all category without an error. Use code_in / code_prefix_any, or correct "
                f"the vocabularies declaration if the column really carries text.")
    return out


def cats_of(cl) -> list:
    """The codelist's categories, defensively — callers here run before the shape checks pass."""
    return [c for c in (cl.get("categories") or []) if isinstance(c, dict)]


def check(cfg, strict: bool = True) -> None:
    """Raise RuntimeError listing all problems, or return None if the config is clean."""
    probs = problems(cfg, strict=strict)
    if probs:
        raise RuntimeError("config validation failed:\n  - " + "\n  - ".join(probs))


# Config keys whose STRING value names a logical source role. One definition, engine-side, because
# the engine is what SKIPS when the role is missing — platform/tools/source_requirements.py imports
# this rather than keeping a second list that would drift.
SOURCE_ROLE_KEYS = ("source", "line_source")

# The three states a source dependency may declare, under a pack's optional `source_availability:`
# block. The default for any role a config block reads is REQUIRED — because the alternative default
# is what a live mCRC trial hit: the spec required HER2, the engine supported it, the delivery never
# carried it, and the output quietly became null. Absence of a declaration must mean "blocks", never
# "shrugs".
#
#   required                the role must be declared in `sources:` and delivered; a read of an
#                           undeclared role BLOCKS a strict build with "source decision required"
#   optional                the dependent output may legitimately be absent for a cut; the matrix
#                           and evidence say so instead of the column just not appearing
#   unavailable_by_design   the specification asks for something this delivery cannot supply. That
#                           is a DISPOSITION, not a shrug, so it requires a reason and a decision_id
#                           — the human trail an auditor follows from the absent output back to who
#                           accepted its absence.
AVAILABILITY_STATES = ("required", "optional", "unavailable_by_design")


def referenced_sources(cfg) -> dict:
    """{role: [where, ...]} for every logical source a config block or index model READS.

    Walked over the COMPOSED config — cfg.pack(role) dicts and the index_dates models — not over
    files, because this is the representation the build actually consumes and the engine may not
    import the tools layer. `source_requirements.py` walks the same keys over the files for
    per-block provenance; findings key on THIS answer so the two views cannot disagree about what
    is referenced.
    """
    out: dict = {}

    def _add(role, where):
        if isinstance(role, str) and role.strip():
            out.setdefault(role.strip(), []).append(where)

    def _walk(node, where):
        if isinstance(node, dict):
            for k, v in node.items():
                if k in SOURCE_ROLE_KEYS and isinstance(v, str):
                    _add(v, where)
                else:
                    _walk(v, where)
        elif isinstance(node, list):
            for item in node:
                _walk(item, where)

    # (the index_dates models are NOT walked here — stages/sources.py declares them as reads,
    # and the reads union below carries them; a second addition made every index role appear
    # referenced twice with identical where strings)
    with _broken_pack_ok():
        for role in sorted(cfg.roles()):
            for key, blk in (cfg.pack(role) or {}).items():
                _walk(blk, f"variables/{role}.yaml#/{key}")
    # ...and every REQUIRED stage-declared read. The generic walk sees config keys; the stages
    # see what the engine actually dereferences — visit_sources bare-name entries, the LOT and
    # mortality hard reads, the index-model columns. Engine-guarded reads (required=False) stay
    # out: they degrade by design and marking them referenced would make every guarded feature
    # an availability blocker. The walk is KEPT as a belt: a config key a stage forgets to
    # declare still surfaces here, and a conformance test holds the two views together.
    reads, _errors = stage_reads(cfg)
    for r in reads:
        if r["required"]:
            _add(r["role"], r["where"])
    return out


def source_availability(cfg) -> tuple:
    """(normalized {role: {state, reason, decision_id}}, [error, ...]) from `source_availability:`.

    Malformed entries are ERRORS, not defaults: an availability block someone wrote and this
    silently ignored would read as a recorded disposition while recording nothing.
    """
    raw = (cfg.raw.get("source_availability") or {}) if isinstance(cfg.raw, dict) else {}
    norm, errors = {}, []
    if not isinstance(raw, dict):
        return {}, [f"source_availability must be a mapping of role -> state, got {type(raw).__name__}"]
    for role, val in raw.items():
        if isinstance(val, str):
            entry = {"state": val.strip(), "reason": None, "decision_id": None}
        elif isinstance(val, dict):
            entry = {"state": str(val.get("state") or "").strip(),
                     "reason": (str(val["reason"]).strip() if val.get("reason") else None),
                     "decision_id": (str(val["decision_id"]).strip() if val.get("decision_id") else None)}
        else:
            errors.append(f"source_availability.{role}: expected a state or a mapping, got "
                          f"{type(val).__name__}")
            continue
        if entry["state"] not in AVAILABILITY_STATES:
            errors.append(f"source_availability.{role}: state {entry['state']!r} is not one of "
                          f"{', '.join(AVAILABILITY_STATES)}")
            continue
        if entry["state"] == "unavailable_by_design" and not (entry["reason"] and entry["decision_id"]):
            errors.append(f"source_availability.{role}: unavailable_by_design is a DISPOSITION and "
                          f"needs both a reason and a decision_id — without them it is a shrug "
                          f"wearing a disposition's name")
            continue
        norm[role] = entry
    return norm, errors


def source_grain(cfg) -> tuple:
    """(normalized {role: [unique_by col, ...]}, [error, ...]) from a pack's `source_grain:` block.

    EXPECTED GRAIN IS A DELIVERY FACT A PERSON DECLARES, not a constant this engine knows. The same
    logical role is one-row-per-patient in one vendor's layout and patient-per-event in another's,
    and an engine-side table of "known" grains would be this code guessing clinical facts — the
    thing every guessed value in this repository eventually paid for. So the pack declares it
    (verify-vs-source, like every other delivery fact), this validates the declaration's SHAPE, and
    `grain.source_grain_report` checks the declaration against the delivered rows.

    A role may be declared here only if the config knows it at all — in `sources:` or referenced by
    a block. A grain for a role nothing supplies or reads is a declaration about nothing.
    """
    raw = (cfg.raw.get("source_grain") or {}) if isinstance(cfg.raw, dict) else {}
    norm, errors = {}, []
    if not isinstance(raw, dict):
        return {}, [f"source_grain must be a mapping of role -> [column, ...], got {type(raw).__name__}"]
    known = set(cfg.sources) | set(referenced_sources(cfg))
    for role, cols in raw.items():
        if not (isinstance(cols, list) and cols and all(isinstance(c, str) and c.strip() for c in cols)):
            errors.append(f"source_grain.{role}: expected a non-empty list of column names, got "
                          f"{cols!r}")
            continue
        if role not in known:
            errors.append(f"source_grain.{role}: no sources: entry declares this role and no config "
                          f"block reads it — a grain declared about nothing")
            continue
        norm[role] = [c.strip() for c in cols]
    return norm, errors


def availability_problems(cfg, strict: bool = False) -> list:
    """The availability findings, shared verbatim by problems() and source_requirements.py.

    Always problems (lint and strict alike):
      * a malformed declaration — written and unenforceable is worse than absent;
      * a role marked unavailable_by_design that IS declared in sources: — a stale disposition
        tells an auditor an absence was accepted while the table quietly ships;
      * a declaration for a role nothing reads and sources: does not declare — dead text.

    Strict only (the build path): a role a block READS that sources: does not declare and no
    declaration excuses — the silent-null shape, refused with the decision named.
    """
    avail, errors = source_availability(cfg)
    out = list(errors)
    referenced = referenced_sources(cfg)
    for role, entry in avail.items():
        if entry["state"] == "unavailable_by_design" and role in cfg.sources:
            out.append(f"source_availability.{role} says unavailable_by_design but sources: "
                       f"declares '{cfg.sources[role]}' — a stale disposition; remove one side")
        if role not in referenced and role not in cfg.sources:
            out.append(f"source_availability.{role}: no config block reads this role and sources: "
                       f"does not declare it — a disposition of nothing")
    if strict:
        for role, wheres in sorted(referenced.items()):
            state = (avail.get(role) or {}).get("state", "required")
            if role not in cfg.sources and state == "required":
                out.append(f"role '{role}' is read by {', '.join(wheres[:3])}"
                           f"{' ...' if len(wheres) > 3 else ''} and delivered by no sources: entry "
                           f"— the dependent output would quietly be null. BLOCKED — source "
                           f"decision required: declare the source, or record "
                           f"source_availability.{role} as optional or unavailable_by_design "
                           f"(with reason and decision_id).")
    return out


def required_columns(cfg) -> dict:
    """Per-source required columns for the sources this tumor DECLARES — composed from the
    stages' own typed reads (stage_reads), plus the declared grain keys, which are a cross-stage
    claim and stay here.

    A read's COLUMNS bind whenever its role is declared; its `required` flag governs the
    availability model (referenced_sources), never the columns — an engine-guarded feature that
    degrades without its table still demands its columns of a table that IS declared.
    Composition errors are NOT suppressed here: problems() reports them, and a pack whose
    declarations cannot be read simply requires what the readable stages state.
    """
    req: dict = {}

    def _need(source, cols):
        if source not in cfg.sources:
            return
        req.setdefault(source, ["patientid"])
        for c in cols:
            if c and c not in req[source]:
                req[source].append(c)

    reads, _errors = stage_reads(cfg)
    for r in reads:
        _need(r["role"], r["columns"])

    # DECLARED GRAIN KEYS ARE REQUIRED COLUMNS. A grain declared on a column the delivery lacks
    # used to surface only at the grain gate; preflight now refuses it before any build, on the
    # same table, by name — an external review asked for exactly this.
    with _broken_pack_ok():
        for role, keys in (cfg.raw.get("source_grain") or {}).items():
            if isinstance(keys, list):
                _need(role, [str(k) for k in keys])
    return req


def emitted_variables(cfg) -> set:
    """The label-level variable codes a tumor's packs emit (excluding the parallel -n code columns,
    which the catalog documents via their label, like stage/stagen). Covers demographics / ECOG / BMI /
    staging / categoricals / biomarker+lab panels / passthrough / surgery / min_avail / cohort
    provenance / outcomes `emits`. Used to assert the master catalog documents every emitted variable
    per tumor (cross-tumor completeness — tests/test_catalog.py)."""
    # always emitted: cohort/cohortu/stamps by assemble, advanceddiagnosisdate (setting diagnosis anchor)
    # by the index stage. Enumerating it here makes the catalog-completeness test cover it too.
    em: set = {"cohort", "cohortu", "data_product_id", "data_refresh", "spec_version", "advanceddiagnosisdate"}
    with _broken_pack_ok():
        dem = cfg.pack("demographics")
        for block, name in (("age_bands", "agegrl"), ("regions", "regionl"), ("race_map", "race"),
                            ("ethnicity_map", "eth")):
            if dem.get(block):
                em.add(name)
        if dem.get("age_bands"):
            em.add("age")
        # SOURCE-aware: practic/ses are emitted only when their (optional) source is declared — so the
        # guard matches what the stage actually emits, not what a pack block merely mentions (e.g. a
        # heme scaffold may carry a ses block but no ses source).
        if dem.get("practice_map") and "practice" in cfg.sources:
            em.add("practic")
        if dem.get("ses") and "ses" in cfg.sources:
            em.add("ses")
    with _broken_pack_ok():
        clin = cfg.pack("clinical")
        em.add("ecog")                                  # always emitted (baseline_ecog or Missing)
        if clin.get("vitals") and "vitals" in cfg.sources:
            em.add("bmi")
            if clin["vitals"].get("bsa_method") or clin["vitals"].get("bsa_formula"):  # method (new) or legacy
                em.add("bsa")
        if clin.get("staging"):
            em.add("stage")
        for c in clin.get("categoricals") or []:
            em.add(c.get("name"))
        for blk in CLOSEST_PANELS:
            _b = clin.get(blk) or {}
            for it in _b.get("panel") or []:
                em.add(it.get("name"))
                # `emit_date` adds the winning record's date as <name>dt. Registered here or the
                # published-surface check reports a column the engine really does produce as a leak.
                if _b.get("emit_date"):
                    em.add(str(it.get("name")) + "dt")
        cci = clin.get("comorbidity_index") or {}
        if cci.get("name") and cci.get("conditions"):
            em.add(cci["name"])
            if cci.get("bands"):
                em.update({cci["name"] + "gr", cci["name"] + "grn"})
        pt = clin.get("passthrough") or {}
        for c in pt.get("columns") or []:
            em.add(c.get("as", c.get("column")))
        for f in pt.get("flags") or []:
            em.add(f.get("name"))
        s = clin.get("surgery")
        if s:
            em |= {"issurg", "surg", "neoadj", "tt_first_tx_diag"}
            if s.get("size_column"):
                em.add(s["size_column"])
        for it in (clin.get("metastatic_sites") or {}).get("sites") or []:
            em.add(it.get("name"))                          # hepatic_met / lung_met / … presence flags
        for it in (clin.get("lab_values") or {}).get("panel") or []:
            nm = it.get("name")
            if nm:
                em |= {nm, nm + "v", nm + "dt"}             # present flag + numeric value + date (all cataloged)
        psa = clin.get("psa_timepoints") or {}
        for p in psa.get("points") or []:
            em.add(p.get("name"))                           # psa_index / psa6mo / psa12mo
        for pt in (psa.get("response") or {}).get("points") or []:
            em.add(pt.get("psa50")); em.add(pt.get("undetectable"))   # psa50_6mo / psal6mo / …
        for it in (clin.get("durations") or {}).get("items") or []:
            em.add(it.get("name"))                          # generic durations (if a tumor configures them)
        for it in clin.get("derived") or []:
            em.add(it.get("name"))                          # INDEXYR / INITYR / MCRPCDDYR / PINDDUR / FUDUR / …
        mcw = clin.get("mcrpc_window")                      # mCRPC index-window flag + MCRPCDD date
        if mcw:
            em.add(mcw.get("flag_as", "mcrpc")); em.add(mcw.get("date_as", "mcrpcdd"))
        if clin.get("min_avail_date"):
            em |= {"minavaildate", "basedur"}
    with _broken_pack_ok():
        trt = cfg.pack("treatment")
        from .stages import treatment as _t                 # per-line lot{i}* family (template-documented)
        em |= set(_t.emitted_line_columns(cfg))
        for fl in (trt.get("prior_treatments") or {}).get("flags") or []:
            em.add(fl.get("name"))                          # prior_pluvicto / prior_parp / …
        for fl in (trt.get("conmed_exposures") or {}).get("flags") or []:
            em.add(fl.get("name"))                          # conmed_bp / conmed_csf / conmed_steroid
        pt = trt.get("prior_taxane") or {}                  # cohort-aware prior-taxane flags
        if pt:
            em.add("prior_tax_mcrpc")                       # always emitted when prior_taxane is configured
            if pt.get("pre_mcrpc_source") in cfg.sources:   # optional: only when pre-mCRPC source declared
                em.add("prior_tax_pre_mcrpc")
        slc = trt.get("setting_line_columns") or {}         # lot{i}{sd|name}_{setting} per setting
        for s in slc.get("settings") or []:
            for i in range(1, int(slc.get("lines", 2)) + 1):
                for a in slc.get("attributes", ["sd", "name"]):
                    em.add(f"lot{i}{a}_{str(s).lower()}")
    with _broken_pack_ok():
        out_pack = cfg.pack("outcomes")
        em |= set(out_pack.get("emits") or [])
        # cross-stage derivations (EFS24-style landmarks / intervals / expressions)
        em |= ads_derived_emitted(out_pack.get("ads_derived"))
    em.discard(None)
    return em


def optional_columns(cfg) -> dict:
    """Configured columns the build reads OPTIONALLY (emit-if-present): the engine skips the
    dependent output gracefully when they are absent, so they are NOT in required_columns() and
    never fail preflight. Reported (present/absent) so a schema-evidence run shows EVERY
    configured column — an absent optional column is ALLOWED, but silently omitting it from the
    evidence would hide, e.g., a missing passthrough that drops its output. Composed from the
    same typed stage reads as required_columns, so the two views cannot disagree about which
    stage reads what. Returns {source: [col, ...]}.
    """
    opt: dict = {}
    reads, _errors = stage_reads(cfg)
    req = required_columns(cfg)
    for r in reads:
        if r["role"] not in cfg.sources:
            continue
        for c in r["optional_columns"]:
            # A column some OTHER read requires of the same role is required, full stop —
            # reporting it optional too made the evidence claim both (prostate's mcrpc_window
            # columns are index-model `of` columns, so they are hard-required on the index
            # source; an adversarial review caught the contradiction).
            if c and c not in (req.get(r["role"]) or []) \
                    and c not in opt.setdefault(r["role"], []):
                opt[r["role"]].append(c)
    return opt


def preflight_report(cfg, table_reader, member_schema=None) -> dict:
    """Structured table/column validation — the READABLE form of preflight(). For every DECLARED source it
    resolves the table FQN(s) and records, per column, whether it is present in the delivered schema
    (honouring the vendor rename overlay). Config-driven: tables come from `sources:`, REQUIRED columns from
    required_columns(cfg), OPTIONAL configured columns from optional_columns(cfg).

    This is a BUILD-PREFLIGHT check: `ok` gates only on readability + REQUIRED columns (exactly what the
    build needs to run). It does NOT prove data types are correct, values match the expected vocabulary,
    grain/joins/windows hold, or that a column is the clinically intended source — those need the value
    profiler + targeted checks + RWP review before a source is 'verified'.

    `member_schema` scopes the report to ONE source_union member. Without it, `source_fqns()` returns
    every declared member's table, so a report LABELLED as member A's evidence actually inspected A and
    B: both members' reports covered the same tables, one member's restricted output carried the
    other's physical identifiers, and A's evidence could fail because B was unavailable. Pass it for a
    member run; omit it for a single-schema pack or a deliberate whole-union preflight.

    `table_reader(fqn)` returns either a list of column names OR a {name: type} dict (pass the latter —
    `{f.name: f.dataType.simpleString() for f in spark.table(fqn).schema.fields}` — to capture observed
    types); it raises if the table is unreadable. Pure data (no Spark import here). Returns:
      {"ok": bool, "sources": {name: {"ok": bool, "tables": [{fqn, readable, present:{col:bool},
       missing:[...], optional_present:{col:bool}, types:{col:type}}]}}}
    """
    req = required_columns(cfg)
    opt = optional_columns(cfg)
    sources: dict = {}
    ok = True
    for name in sorted(cfg.sources):
        # Under a non-EDM data format, columns arrive with PHYSICAL names that source load renames to the
        # required LOGICAL names — so a required logical column is satisfied by its physical name too.
        phys_for = {lo.lower(): ph.lower() for ph, lo in (cfg.source_renames.get(name) or {}).items()}
        need = req.get(name, ["patientid"])
        opt_need = opt.get(name, [])
        tables, src_ok = [], True
        fqns = [cfg.table_in(name, member_schema)] if member_schema else cfg.source_fqns(name)
        for fqn in fqns:                         # 1 normally; one per member schema under a union
            t = {"fqn": fqn, "readable": True, "present": {}, "missing": [],
                 "optional_present": {}, "types": {}}
            try:
                raw = table_reader(fqn)
            except Exception as e:  # noqa: BLE001 - any read failure is a preflight problem
                t["readable"] = False
                t["error"] = str(e)
                src_ok = False
                tables.append(t)
                continue
            if isinstance(raw, dict):            # {name: type} -> capture observed types (keyed lowercase)
                t["types"] = {str(c).lower(): str(ty) for c, ty in raw.items()}
                cols = set(t["types"])
            else:
                cols = {str(c).lower() for c in raw}

            def _has(col):
                cl = col.lower()
                return cl in cols or phys_for.get(cl) in cols

            for c in need:                       # required: a miss fails the source (build can't run)
                present = _has(c)
                t["present"][c] = present
                if not present:
                    t["missing"].append(c)
                    src_ok = False
            for c in opt_need:                   # optional: recorded present/absent, never fails
                t["optional_present"][c] = _has(c)
            tables.append(t)
        sources[name] = {"ok": src_ok, "tables": tables}
        ok = ok and src_ok
    return {"ok": ok, "sources": sources}


def preflight_report_md(report: dict) -> str:
    """Render preflight_report() as a stakeholder markdown report: a summary table plus a per-source detail
    listing every column checked (required + optional) with its observed type. Names WHICH columns were
    checked so an auditor doesn't need the source to reconstruct the evidence."""
    head = ("✅ every BUILD-REQUIRED table & column is present in the cut" if report["ok"]
            else "❌ mismatches below — the config's physical names do not all match the delivered cut")
    lines = ["# Schema validation — configured tables & columns vs the delivered cut", "",
             f"**Result:** {head}", "",
             "_Scope: a BUILD-PREFLIGHT check. It confirms the tables read and the columns the build "
             "REQUIRES exist (and records optional configured columns + observed types). It does NOT "
             "establish data types are correct, value vocabularies, grain / joins / duplicates / windows, "
             "or that a column is the clinically intended source — those need the value profiler + targeted "
             "checks + RWP review before a source is marked `verified`._", "",
             "| Source | Table (FQN) | Readable | Required present | Missing | Optional present |",
             "|---|---|---|---|---|---|"]
    for name, s in report["sources"].items():
        for t in s["tables"]:
            readable = "✅" if t["readable"] else f"❌ {t.get('error', '')}"
            n = len(t["present"])
            npresent = sum(1 for v in t["present"].values() if v)
            missing = ", ".join(f"`{c}`" for c in t["missing"]) if t["missing"] else "—"
            opt = t.get("optional_present") or {}
            optstr = ", ".join(f"`{c}`{'✅' if v else '➖'}" for c, v in opt.items()) if opt else "—"
            lines.append(f"| {name} | `{t['fqn']}` | {readable} | {npresent}/{n} | {missing} | {optstr} |")

    lines += ["", "## Columns checked (per source)"]
    for name, s in report["sources"].items():
        for t in s["tables"]:
            lines += ["", f"### {name} — `{t['fqn']}`", ""]
            if not t["readable"]:
                lines.append(f"- ❌ unreadable: {t.get('error', '')}")
                continue
            types = t.get("types") or {}

            def _typ(c):
                ty = types.get(c.lower())
                return f" — `{ty}`" if ty else ""

            for c, present in t["present"].items():
                lines.append(f"- {'✅' if present else '❌'} required `{c}`{_typ(c)}")
            for c, present in (t.get("optional_present") or {}).items():
                lines.append(f"- {'✅' if present else '➖ absent (allowed)'} optional `{c}`{_typ(c)}")
    return "\n".join(lines) + "\n"


def preflight_evidence(cfg, report: dict, generated_at=None, git_commit=None) -> dict:
    """Wrap preflight_report() with run provenance into a machine-readable evidence object — the stable
    input for a draft reconciliation/prepopulation step, and an auditable record of exactly what was
    checked. Establishes `schema_presence` (passed_live / failed_live), NOT `source: verified` — a green
    presence check is one input to source verification, not the whole evidence package. Pure data; the
    runner supplies generated_at + git_commit (this module imports no clock/git)."""
    return {
        "kind": "schema_preflight",
        "schema_presence": "passed_live" if report["ok"] else "failed_live",
        "data_product_id": cfg.data_product_id,
        "spec_version": cfg.spec_version,
        "data_refresh": cfg.refresh,
        "source_schema": cfg.source_schema,
        "data_format": cfg.data_format,
        "git_commit": git_commit,
        "generated_at": generated_at,
        "ok": report["ok"],
        "sources": report["sources"],
    }


def preflight(spark, cfg, _table_reader=None) -> bool:
    """Spark preflight: every DECLARED source TABLE resolves and has its required COLUMNS. Run on the
    cluster before build() so a missing table/column fails fast with a clear list instead of deep inside a
    Spark stage. Delegates to preflight_report(); raises on any mismatch. `_table_reader(fqn) -> list[col]`
    is injectable for unit tests; by default it reads `spark.table(fqn).columns`."""
    read = _table_reader or (lambda fqn: spark.table(fqn).columns)
    rep = preflight_report(cfg, read)
    if not rep["ok"]:
        problems: list[str] = []
        for name, s in rep["sources"].items():
            for t in s["tables"]:
                if not t["readable"]:
                    problems.append(f"source '{name}' table {t['fqn']} not readable: {t.get('error')}")
                for c in t["missing"]:
                    problems.append(f"source '{name}' table {t['fqn']} missing column '{c}'")
        raise RuntimeError("source preflight failed:\n  - " + "\n  - ".join(problems))
    return True


def main(argv):
    if len(argv) != 2:
        print("usage: python engine/validate.py <path-to-data_product.yaml>")
        return 2
    cfg = load_config(argv[1])
    probs = problems(cfg, strict=False)   # lint mode: REPLACE_ME placeholders allowed
    if probs:
        print(f"{len(probs)} problem(s):")
        for p in probs:
            print(f"  - {p}")
        return 1
    print("config OK (lint mode — REPLACE_ME placeholders allowed)")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
