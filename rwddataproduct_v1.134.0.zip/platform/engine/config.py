"""Config loader for a tumor RWDP. Pure Python (stdlib + PyYAML) — no Spark.

Loads config/data_product.yaml, applies dotted-key overrides (so a Databricks job can pass
`run.refresh=2026q2` with no code change), and resolves what the locked, tumor-agnostic engine
needs: vendor-aware source table names, the cohort list, and the referenced variable/codelist packs.
"""
from __future__ import annotations

from pathlib import Path
import copy
try:                    # works whether config is imported as engine.config or as top-level config
    from . import vendors
except ImportError:
    import vendors


try:                    # same dual-import shape as `vendors` above
    from .strict_yaml import strict_load
except ImportError:
    from strict_yaml import strict_load


def load_yaml(path) -> dict:
    # STRICT: a duplicate key in an executable config is two claims for one slot with the second
    # silently winning — refused, never resolved by position.
    with open(path, encoding="utf-8") as fh:      # explicit UTF-8 so YAML with non-ASCII loads on Windows (cp1252)
        return strict_load(fh)


# Everything under products/ that is SHARED across packs and read at RUN TIME. The ONE definition.
#
# These were five path literals inside `run_rwdp.py`, and `deploy_tree.py` reproduced its own idea of
# them by walking `products/_reporting` — which caught three of the five and missed
# `metadata/catalog.yaml` entirely. The deployment tree therefore packaged a product that could pass
# every gate, build its ADS, and then fail dictionary and dashboard generation, which a governed run
# REQUIRES, so it could never publish. Nothing went red: the runner's list, the builder's walk and the
# test's inventory were three separate descriptions of one set, and all three were internally
# consistent.
#
# It lives here because `config.py` already owns where a product's files are (`product_dir`), it is
# stdlib+yaml so the packaging tool can import it, and a KeyError from `shared_asset` names the whole
# set — so adding a shared asset is one edit that both the runner and the deployment tree pick up.
SHARED_ASSETS = {
    "registry":       "registry.yaml",
    "catalog":        "metadata/catalog.yaml",
    "audiences":      "_reporting/dictionary/audiences.yaml",
    "dashboard_vars": "_reporting/dashboard/dashboard_vars.yaml",
    "tfl_specs":      "_reporting/tfl/tfl_specs.yaml",
}


def shared_asset(products_root, name):
    """Path to a shared product asset by NAME. An unknown name raises KeyError naming the known set,
    because a typo that resolved to a plausible path would fail at read time inside a try/except that
    records the failure as a deliverable problem."""
    from pathlib import Path
    if name not in SHARED_ASSETS:
        raise KeyError(f"unknown shared product asset {name!r} — known: {sorted(SHARED_ASSETS)}")
    return Path(products_root).joinpath(*SHARED_ASSETS[name].split("/"))


def product_dir(products_root, slug, spec_version=None, registry=None):
    """Resolve a product's SPEC-VERSIONED pack dir: `<products_root>/<family>/<slug>/<spec_version>/`
    (which holds config/, variables/, codelists/, source_refs.yaml). Every product keeps one folder per
    spec version, so v1 and v2 coexist as independently buildable + diffable + auditable contracts.

    `spec_version` defaults to the registry's `current_spec_version` for that slug. Pass an explicit one
    (e.g. a superseded version like '202603') to target it — but it must be a version the registry
    actually DECLARES for the slug (`current_spec_version` + `lineage[].spec_version`); an unknown
    explicit version is treated as a typo and raises `KeyError` (naming the known set) rather than
    silently resolving to a missing dir that 404s deep in the load. Family comes from the registry
    (default 'oncology')."""
    from pathlib import Path
    products_root = Path(products_root)
    reg = registry if registry is not None else load_yaml(str(products_root / "registry.yaml"))
    entry = next((t for t in (reg.get("tumors") or []) if t.get("slug") == slug), {}) or {}
    family = entry.get("family", "oncology")
    sv = spec_version if spec_version is not None else entry.get("current_spec_version")
    if not sv:
        raise KeyError(f"slug '{slug}': no spec_version given and no current_spec_version in registry")
    # An EXPLICIT version must be one the registry declares for this slug — fail a typo'd '202609'
    # loudly here (with the known set) instead of building a path that 404s deep in the load. The
    # None default is exempt: it IS the current version by construction. A 'YYYYMM' scaffold
    # placeholder is not a real version, so it never constrains.
    if spec_version is not None:
        known = {entry.get("current_spec_version")} | {
            str(v.get("spec_version")) for v in (entry.get("lineage") or []) if v.get("spec_version")}
        known = {k for k in known if k and k != "YYYYMM"}
        if known and str(sv) not in known:
            raise KeyError(
                f"slug '{slug}': spec_version '{sv}' is not declared in the registry "
                f"(known: {sorted(known)}) — add a lineage row or fix the typo.")
    return products_root / family / slug / str(sv)


def product_config(products_root, slug, spec_version=None, registry=None):
    """The `config/data_product.yaml` for a product's (current or given) spec version (see product_dir)."""
    return product_dir(products_root, slug, spec_version, registry) / "config" / "data_product.yaml"


def _set_dotted(d: dict, dotted_key: str, value):
    """Set value at a dotted path, e.g. 'run.refresh' -> d['run']['refresh']."""
    parts = dotted_key.split(".")
    node = d
    for p in parts[:-1]:
        node = node.setdefault(p, {})
    node[parts[-1]] = value


# --- the temporal field model -----------------------------------------------------------------
# `study.index_end` has been carrying THREE meanings: the enrollment-window close (index.py's
# cohort filter), the end of potential observation (id3mosfu, pfudur), and a date-sanity bound
# (the EDA temporal check) — an external review named the conflation. The model splits them,
# ADDITIVELY: a pack states only what differs, and every unstated field falls back along this
# chain so no existing pack's semantics move until a HUMAN writes the new key in config.
#
#   index_period_start/end  the enrollment window ([index_start, index_end] today)
#   observation_end         end of potential follow-up capture (defaults: data_cutoff, index_end)
#   data_cutoff             the delivery's cut date (defaults: observation_end, index_end)
#
# Pure functions over the study dict, because the R engine and the EDA tool read the same chain
# and a second spelling of the defaults is a second answer. The Config properties delegate.

def index_period_start(study: dict):
    return study.get("index_period_start") or study.get("index_start")


def index_period_end(study: dict):
    return study.get("index_period_end") or study.get("index_end")


def observation_end(study: dict):
    return study.get("observation_end") or study.get("data_cutoff") or study.get("index_end")


def data_cutoff(study: dict):
    return study.get("data_cutoff") or study.get("observation_end") or study.get("index_end")


class Config:
    """Resolved view over data_product.yaml. Attribute access for the common knobs,
    plus helpers the engine uses (table resolution, cohort lookup, pack access)."""

    def __init__(self, raw: dict, root: Path):
        self.raw = raw
        self.root = root
        self.run = raw.get("run", {})
        self.study = raw.get("study", {})
        self.cohorts = raw.get("cohorts", [])
        # Data format (Flatiron EDM | Panoramic …). Selects a per-format overlay over the base
        # `sources` map + table-name layout + column renames, so the SAME engine + variable logic runs
        # on either delivery. EDM is the default; a `formats:` block declares the alternatives. The
        # engine only ever sees the logical/EDM column names (Panoramic renames apply at source load).
        self.data_format = delivery_bindings(raw)["data_format"]
        self._format_block = (raw.get("formats") or {}).get(self.data_format, {})
        self.sources = {**raw.get("sources", {}), **(self._format_block.get("sources") or {})}
        self.index_dates = raw.get("index_dates", {})
        self.treatment_status = raw.get("treatment_status", {})
        self.vendor = raw.get("vendor", "flatiron")        # flatiron | cota | …
        self.tumor_class = raw.get("tumor_class", "solid")  # solid | heme
        # Adapter-compiled physical tables (see bind_sources). Empty = no adapter claim, and
        # every resolution below behaves exactly as it always has.
        self._bound_sources = {}
        self.adapter_binding = None
        # Lazily-loaded packs/codelists (loaded on first access).
        self._packs = None
        self._packs_by_role = None
        self._codelists = None

    # --- study window (see the temporal field model above) ----------------
    @property
    def index_period_start(self):
        return index_period_start(self.study)

    @property
    def index_period_end(self):
        return index_period_end(self.study)

    @property
    def observation_end(self):
        return observation_end(self.study)

    @property
    def data_cutoff(self):
        return data_cutoff(self.study)

    # --- run/output -------------------------------------------------------
    @property
    def refresh(self) -> str:
        return self.run["refresh"]

    @property
    def source_schema(self) -> str:
        return self.run["source_schema"]

    @property
    def output_schema(self) -> str:
        return self.run["output_schema"]

    @property
    def output_table(self) -> str:
        return self.run["output_table"]

    @property
    def data_product_id(self) -> str:
        """Stable product identifier (e.g. prostate_mcrpc_rwdp) — stamped on every ADS row so a row
        self-identifies its product, alongside spec_version + data_refresh. Build-level provenance
        (engine_version / git_commit / build_id) lives in the manifest, keyed by these stamps."""
        return str(self.raw.get("data_product_id", ""))

    @property
    def output_fqn(self) -> str:
        return f"{self.output_schema}.{self.output_table}"

    @property
    def write_mode(self) -> str:
        return self.run.get("write_mode", "overwrite")

    @property
    def version(self) -> str:
        """Full product version with {snapshot} filled from the refresh (e.g. 202606.2026q1) — a
        human-readable spec+cut label for logs/QC reports. The audit STAMP is `spec_version`, not this."""
        return str(self.raw.get("version", "")).replace("{snapshot}", str(self.refresh))

    @property
    def spec_version(self) -> str:
        """The contract version alone (CalVer YYYYMM, e.g. 202606) — `version` with the data-refresh
        snapshot stripped. THIS is what stamps ADS rows + manifests and what
        registry.current_spec_version tracks; the data cut is carried separately as `data_refresh`, so
        the two axes never duplicate. (template 202606.{snapshot} -> spec_version 202606.)"""
        return str(self.raw.get("version", "")).split("{snapshot}")[0].rstrip("._-/ ")

    @property
    def source_layout(self):
        """Vendor table-name template override: the active data format's, else a run-level override.

        Through `delivery_bindings` so the gate that HASHES it and the engine that RESOLVES tables
        with it cannot come to read different keys — the template decides every physical table name.
        """
        return delivery_bindings(self.raw)["source_layout"]

    @property
    def source_renames(self):
        """Per-source column renames {source: {physical: logical}} for the active data format, applied
        at source load so the engine always sees the logical/EDM column names. Empty for EDM."""
        return self._format_block.get("rename") or {}

    @property
    def source_union(self):
        """Optional multi-schema union: read each declared source from EVERY member schema, tag it
        with a `discriminator` column, and union the members. None = single schema (run.source_schema).
        EC uses this for Flatiron EDM ∪ Dostarlimab registry (db = EDM/DOS)."""
        return self.raw.get("source_union")

    @property
    def lot_line_setting(self):
        """LOT line-setting filter for new_lot_n (e.g. mCRPC for prostate). None = no filter."""
        return self.raw.get("lot", {}).get("line_setting")

    @property
    def lot_exclude_settings(self):
        """Line settings to DROP before numbering (e.g. EC drops 'ADVANCED'). [] = drop none."""
        return self.raw.get("lot", {}).get("exclude_settings") or []

    @property
    def lot_line_number_col(self):
        """How a cohort's 'line N' is identified: 'new_lot_n' (a derived row_number over the
        kept lines — the default; prostate/NSCLC) or 'linenumber' (the raw LOT line number;
        OC/EC index off raw linenumber + the maintenance flag)."""
        return self.raw.get("lot", {}).get("line_number", "new_lot_n")

    @property
    def lot_maintenance_column(self):
        """Column carrying the maintenance flag (OC/EC: ismaintenancetherapy). Only consulted when
        a cohort sets `maintenance:`; tumors without maintenance lines (prostate/NSCLC) never do."""
        return self.raw.get("lot", {}).get("maintenance_column", "ismaintenancetherapy")

    @property
    def vocabularies(self) -> list:
        """Declared coding system per matched column: [{source, column, system, version?}].

        Empty means NOTHING is declared, which is NOT the same as "everything is text" — see
        engine/vocabularies.py. `validate` only refuses an operator where a declaration positively
        contradicts it, so an undeclared pack behaves exactly as it did before this existed; a pack
        that declares gets the refusal.
        """
        return [v for v in (self.raw.get("vocabularies") or []) if isinstance(v, dict)]

    def system_for(self, source, column):
        """The declared coding system for (source, column), or None when nothing declares it.

        None is the honest answer for undeclared and must not be read as `text`: the caller decides
        what to do with unanswered, and every caller here treats it as "no refusal available",
        never as "safe".
        """
        want = (str(source or "").strip().lower(), str(column or "").strip().lower())
        for v in self.vocabularies:
            if (str(v.get("source") or "").strip().lower(),
                    str(v.get("column") or "").strip().lower()) == want:
                return str(v.get("system") or "").strip()
        return None

    @property
    def index_source(self):
        """Logical source the 'overall' index date is built from. Default 'enhanced'; heme tumors
        index off 'diagnosis' (set index_dates.advanced_diagnosis_date.source)."""
        return self.index_dates.get("advanced_diagnosis_date", {}).get("source", "enhanced")

    # --- sources ----------------------------------------------------------
    def bind_sources(self, bindings: dict, digest: str = None, dataset: str = None):
        """Make the REVIEWED ADAPTER the loader's source of truth for these roles.

        `table()` and everything built on it return the adapter's physical tables verbatim for
        bound roles, so the engine consumes the compiled adapter rather than a parallel map —
        the gap an external adversarial campaign named: an adapter could say `mc.rx_claims`
        while execution read `t_drugepisode`, and the two claims were never reconciled.
        `run_rwdp` performs that reconciliation BEFORE calling this (a disagreement between the
        adapter and this config's own resolution refuses the run), and records `adapter_binding`
        in the candidate manifest so the binding is part of the run's identity.
        """
        self._bound_sources = {str(k): str(v) for k, v in (bindings or {}).items()}
        self.adapter_binding = {"digest": digest, "dataset": dataset,
                                "roles": sorted(self._bound_sources)}

    def table(self, name: str) -> str:
        """Resolve a logical source name to a physical table, vendor-aware.

        An adapter-bound role (see bind_sources) resolves to the adapter's table VERBATIM.
        Otherwise Flatiron -> `{schema}.{stem}_{refresh}`; other vendors via engine/vendors.py
        (or a `run.source_layout` override). Mirrors the R `in_schema(dbname, paste0(...))`.
        """
        if name in self._bound_sources:
            return self._bound_sources[name]
        if name not in self.sources:
            raise KeyError(f"unknown source '{name}'. Known: {sorted(self.sources)}")
        return vendors.resolve(self.vendor, self.source_layout,
                               self.source_schema, self.sources[name], self.refresh)

    def table_in(self, name: str, schema: str) -> str:
        """Resolve a source to a physical table in a SPECIFIC schema (for multi-schema unions)."""
        if name in self._bound_sources:
            # a per-schema resolution would silently bypass the reviewed binding; run_rwdp
            # refuses the adapter+source_union combination up front, this is the backstop
            raise KeyError(f"'{name}' is adapter-bound to ONE physical table; per-schema "
                           f"resolution would bypass the reviewed binding")
        if name not in self.sources:
            raise KeyError(f"unknown source '{name}'. Known: {sorted(self.sources)}")
        return vendors.resolve(self.vendor, self.source_layout, schema, self.sources[name], self.refresh)

    def source_fqns(self, name: str) -> list:
        """Every physical table a source resolves to: one normally, or one per `source_union` member
        schema. Preflight checks all of them, so a missing member table fails fast."""
        u = self.source_union
        if u:
            return [self.table_in(name, m["schema"]) for m in u.get("members", [])]
        return [self.table(name)]

    def all_tables(self) -> dict:
        return {name: self.table(name) for name in self.sources}

    # --- cohorts ----------------------------------------------------------
    def cohort(self, cohort_id: str) -> dict:
        for c in self.cohorts:
            if c["id"] == cohort_id:
                return c
        raise KeyError(f"unknown cohort '{cohort_id}'")

    # --- variable packs / codelists --------------------------------------
    def packs(self) -> dict:
        """{pack_id: pack_dict} for every variables/*.yaml referenced in config."""
        if self._packs is None:
            self._packs = {}
            for rel in self.raw.get("variables", []):
                pack = load_yaml(self.root / rel)
                self._packs[pack["pack_id"]] = pack
        return self._packs

    def _packs_by_role_map(self) -> dict:
        if self._packs_by_role is None:
            self._packs_by_role = {Path(rel).stem: load_yaml(self.root / rel)
                                   for rel in self.raw.get("variables", [])}
        return self._packs_by_role

    def pack(self, role: str) -> dict:
        """Variable pack by ROLE — the file stem (demographics / clinical / treatment / outcomes).

        This keeps the shared engine tumor-agnostic: stages look up by role, so `pack_id` is just
        a label and each tumor names its packs however it likes.
        """
        packs = self._packs_by_role_map()
        if role not in packs:
            raise KeyError(f"no variable pack for role '{role}'; have {sorted(packs)}")
        return packs[role]

    def roles(self) -> set:
        """The set of pack roles (file stems) this product provides."""
        return set(self._packs_by_role_map())

    def codelist(self, key: str) -> dict:
        """Load a referenced codelist by its config key (e.g. 'treatment_categories')."""
        if self._codelists is None:
            self._codelists = {}
        if key not in self._codelists:
            rel = self.raw.get("codelists", {})[key]
            self._codelists[key] = load_yaml(self.root / rel)
        return self._codelists[key]


# THE ENVIRONMENT HALF OF A PACK'S CONFIG, and the file it lives in.
#
# `run:` (which cut, which schemas, which table, how to write) and `deliverables:` are DEPLOYMENT
# facts. They say nothing about what the product means, they change per environment and per refresh,
# and they are set by whoever operates the job — not by whoever approves the science.
#
# They are kept OUT of `data_product.yaml`, which would put them inside `config_bundle_sha256` —
# the digest a Gate 4 approval binds to. Changing only
# `run.output_schema` moves that digest, so pointing the job at a different schema INVALIDATES an
# RWP approval of the scientific configuration. Two different questions, two different owners, one
# hash.
#
# Splitting them also makes the promotion path expressible: a candidate is approved once and then
# promoted, and a per-run binding belongs with the run rather than with the approval.
PIPELINE = "pipeline.yaml"

# ...and the ones inside `run:` that decide WHICH PHYSICAL DATA IS READ, as against where output is
# written. The split above moved all six `run:` keys outside `config_bundle_sha256`, which was the
# point — a different output schema must not invalidate an RWP approval of the SCIENCE. It also,
# silently, moved these three outside what GATE 3 evidence pins, which was not: a source verdict
# measured on schema A, cut 2026m06, format EDM went on matching after the job was pointed at
# schema B under a column-renaming overlay, because sha256(data_product.yaml) had not moved.
#
# Two gates, two subjects. Gate 4 asks "is this the science I approved"; Gate 3 asks "is this the
# delivery I measured". `product_gates.delivery_sha256` is the second one.
DELIVERY_KEYS = ("refresh", "source_schema", "data_format", "source_layout")
DEFAULT_FORMAT = "EDM"

# ...and the two that have NO default, so leaving them unstated names no delivery at all. A Gate 3
# verdict is an approval record ABOUT a delivery; `source_check --complete` refuses a pack that has
# not been pointed at one. `data_format` defaults to EDM and `source_layout` to the vendor's
# template, both of which are answers.
DELIVERY_REQUIRED = ("refresh", "source_schema")


def delivery_keys(raw: dict) -> tuple:
    """The DELIVERY_KEYS this product actually resolves tables with.

    Under `source_union` the member schemas come from `source_union.members` and `run.source_schema`
    is unused — the build runner prints exactly that. Applying the flat list to a union pack was one
    wrong list causing two opposite faults: it made the pack populate an irrelevant field to satisfy
    Gate 3 (a false blocker — endometrial's own config says "unused under source_union below"), and
    it HASHED that field, so editing a value the engine ignores invalidated source evidence that was
    still true (a false invalidation).

    Derived from `DELIVERY_KEYS` by subtraction, never by a second list: the keys a gate REQUIRES and
    the keys it HASHES have to be the same set, or a pack passes one and fails the other.
    """
    union = bool(raw.get("source_union"))
    return tuple(k for k in DELIVERY_KEYS if not (union and k == "source_schema"))


def delivery_required(raw: dict) -> tuple:
    """The delivery bindings this product must state before its evidence means anything."""
    applies = delivery_keys(raw)
    return tuple(k for k in DELIVERY_REQUIRED if k in applies)


def delivery_bindings(raw: dict) -> dict:
    """{key: value} for DELIVERY_KEYS, resolved exactly as Config resolves them.

    Takes the MERGED raw mapping rather than a Config, because a pack whose bindings are still
    REPLACE_ME — or absent — must still produce an answer: `Config.refresh` raises KeyError, and a
    digest that cannot be computed for an unbound pack would make Gate 3 unusable before the pack
    is pointed at anything. Config reads `data_format` and `source_layout` through here so their
    fallback chains have one definition; the other two it exposes as strict properties, which is
    right for RUNNING and wrong for HASHING.

    `source_layout` is here because it is the TABLE-NAME TEMPLATE — `{schema}.t_{stem}_{refresh}` is
    a documented per-product override, and changing it renames every physical table this check
    looked at while `refresh`, `source_schema`, `data_format` and the root config all stay put. It
    resolves from the active format's block first, then `run:`, exactly as `Config.source_layout`
    does, so a format overlay that carries its own layout is not read as the vendor default.
    """
    run = raw.get("run") or {}
    fmt = run.get("data_format") or raw.get("data_format") or DEFAULT_FORMAT
    block = ((raw.get("formats") or {}).get(fmt) or {})
    every = {"refresh": run.get("refresh"),
             "source_schema": run.get("source_schema"),
             "data_format": fmt,
             "source_layout": block.get("source_layout") or run.get("source_layout")}
    # Only the keys this product resolves tables with — see `delivery_keys`. A union's unused
    # `run.source_schema` must not reach the digest, or a field the engine ignores can invalidate
    # evidence that is still true.
    return {k: every[k] for k in delivery_keys(raw)}


def merged_raw(path, overrides: dict | None = None) -> dict:
    """The two config files merged into one mapping — the ONE merge.

    Factored out of `load_config` so a gate can ask what a pack STATES without constructing a
    Config, which validates and resolves for RUNNING. A second merge in a gate would be free to
    disagree with the build about which file supplies `data_format`.
    """
    path = Path(path)
    raw = copy.deepcopy(load_yaml(path))
    pipeline = path.parent / PIPELINE
    if pipeline.exists():
        env = load_yaml(pipeline) or {}
        if not isinstance(env, dict):
            raise ValueError(f"{pipeline}: must be a mapping, got {type(env).__name__}")
        both = [k for k in env if k in raw]
        if both:
            raise ValueError(
                f"{', '.join(sorted(both))} defined in BOTH {path.name} and {PIPELINE} — the "
                f"environment half belongs in exactly one of them, and preferring either silently "
                f"would decide where the product writes without anybody reading it.")
        raw.update(env)
    for k, v in (overrides or {}).items():
        if v is None or v == "":
            continue
        _set_dotted(raw, k, v)
    return raw


def load_config(path, overrides: dict | None = None) -> Config:
    """Load a Config from data_product.yaml, merging `config/pipeline.yaml` when present.

    `overrides` is a flat dict of dotted keys, e.g. {"run.refresh": "2026q2"}; empty-string
    values are ignored so a job can pass through blanks harmlessly.

    The environment half may live in EITHER file, and a key present in BOTH is refused rather than
    resolved by precedence: two files disagreeing about `output_schema` is a question about which
    table the product writes to, and silently preferring one would let a run land in an unreviewed
    schema. Packs keeping `run:` in `data_product.yaml` still load unchanged.
    """
    path = Path(path)
    raw = merged_raw(path, overrides)
    # Product root is the folder that contains config/ (one level up from the yaml).
    root = path.resolve().parent.parent
    return Config(raw, root)
