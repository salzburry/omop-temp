"""Stage: load source tables. Ports the block of `tbl(con, in_schema(...))` reads.

Loads ONLY the sources the tumor declares (cfg.sources), with columns lower-cased. Table names
are vendor-resolved via cfg.table(name), so the snapshot AND the vendor (Flatiron / COTA / …) are
config, not code. Robust to tumors that omit `enhanced` or use an N-column advanced-diagnosis rule.

When `source_union` is configured, each source is read from EVERY member schema, tagged with the
`discriminator` column, and unioned — the engine equivalent of the EC `union_func` (Flatiron EDM ∪
Dostarlimab registry, db = EDM/DOS).
"""
from __future__ import annotations


def _union_members(spark, cfg, name, union, F, pins=None):
    """Read `name` from each union member schema, tag with the discriminator flag, and unionByName.

    `allowMissingColumns=True` so a registry table with a slightly different column set still unions
    (the engine then sees the superset). Mirrors EC's `edm %>% mutate(db='EDM') %>% union_all(dos…)`.
    """
    from functools import reduce
    disc = union.get("discriminator", "db")
    parts = [_read(spark, cfg.table_in(name, m["schema"]), pins).withColumn(disc, F.lit(m["flag"]))
             for m in union.get("members", [])]
    if not parts:
        raise ValueError(f"source_union for '{name}' has no members")
    return reduce(lambda a, b: a.unionByName(b, allowMissingColumns=True), parts)


def _read(spark, fqn, pins):
    """The one table-read. A pin is what the manifest RECORDED for this fqn; reading anything else
    lets a concurrent writer slip a newer version under a lazily-evaluated plan while the ledger
    still claims the probed one — recorded-but-not-used lineage. No pin = current.

    A pin may be a bare delta version (the original shape, kept for the synthetic suites) or the
    full lineage entry {delta_version, table_id, location, ...}. With the full entry the read also
    VERIFIES TABLE IDENTITY: version N of a dropped-and-recreated table belongs to a different
    Delta log, so a name+version pin could describe table A while the read returned table B — the
    manifest lying by way of a rename. Identity mismatch is a refusal, not a note.

    The check is a verify-READ-verify sandwich on {table_id, location}: the name is verified
    before the read AND after the DataFrame resolves, because a name is mutable and a concurrent
    DROP/CREATE or re-point between the DESCRIBE and the read would bind the plan to a different
    table than the one just verified. Unity Catalog forbids path reads on managed tables, so the
    location cannot be read directly — instead it is held as identity: the recorded location must
    be the location the name resolves to on both sides of the read."""
    if not (pins and fqn in pins):
        return spark.table(fqn)
    pin = pins[fqn]
    if not isinstance(pin, dict):
        return spark.read.option("versionAsOf", str(pin)).table(fqn)

    def _verify(moment):
        want_id, want_loc = pin.get("table_id"), pin.get("location")
        if not (want_id or want_loc):
            return
        got = spark.sql(f"DESCRIBE DETAIL {fqn}").collect()[0].asDict()
        if want_id and str(got.get("id")) != str(want_id):
            raise RuntimeError(
                f"SOURCE IDENTITY MISMATCH ({moment}) — {fqn} is Delta table id {got.get('id')} "
                f"but the probed lineage recorded {want_id}. The table was dropped and recreated "
                f"(or the name re-pointed) after the probe; version {pin.get('delta_version')} of "
                f"the current table is NOT the bytes the manifest describes. Re-run so the probe "
                f"and the read see one table.")
        if want_loc and str(got.get("location")) != str(want_loc):
            raise RuntimeError(
                f"SOURCE LOCATION MISMATCH ({moment}) — {fqn} stores its data at "
                f"{got.get('location')} but the probed lineage recorded {want_loc}. The name now "
                f"resolves to a different Delta location than the one the manifest describes; "
                f"this read would bind to bytes the probe never saw. Re-run so the probe and the "
                f"read see one table.")

    _verify("before read")
    df = spark.read.option("versionAsOf", str(pin["delta_version"])).table(fqn)
    _verify("after read")
    return df


def reads(cfg):
    """The loader's own read: every index_dates model is materialized on the INDEX SOURCE from its
    `of` columns, so ALL of them are required there — a typo'd `of` column would otherwise be
    silently skipped and the model built from whatever happens to be present. A per-model
    `source:` naming a DIFFERENT source is refused by validate.problems(): this loader
    materializes on cfg.index_source only, and a key the validator honoured while the loader
    ignored it was two answers to one question (an external review found exactly that split)."""
    from . import read
    out = []
    for key, rule in (cfg.index_dates or {}).items():
        if isinstance(rule, dict):
            out.append(read(rule.get("source", cfg.index_source),
                            ["patientid"] + [str(c) for c in (rule.get("of") or [])],
                            f"index.{key}"))
    return out


def load(spark, cfg, pins=None) -> dict:
    from pyspark.sql import functions as F

    union = cfg.source_union
    src = {}
    for name in cfg.sources:                      # declared sources only
        df = (_union_members(spark, cfg, name, union, F, pins) if union
              else _read(spark, cfg.table(name), pins))
        for col in df.columns:                    # lower-case all columns (R: rename_with(tolower))
            if col != col.lower():
                df = df.withColumnRenamed(col, col.lower())
        # Per-format column renames (e.g. Panoramic physical -> logical/EDM names) so the engine always
        # sees the logical names. Applied after lower-casing; absent columns are a no-op. Empty for EDM.
        for phys, logical in (cfg.source_renames.get(name) or {}).items():
            p, lo = phys.lower(), logical.lower()
            if p in df.columns and p != lo:
                df = df.withColumnRenamed(p, lo)
        src[name] = df

    # Materialize each index_dates model as a column on the configured INDEX SOURCE (default
    # 'enhanced'; heme sets advanced_diagnosis_date.source: diagnosis). Column name = the model key
    # with underscores removed, so `advanced_diagnosis_date` -> advanceddiagnosisdate (unchanged). A
    # dual-setting product adds e.g. hspc_diagnosis_date / crpc_diagnosis_date so each overall cohort
    # can index off ITS setting's diagnosis date. Materialized only where the rule's columns exist.
    isrc = cfg.index_source
    if isrc in src:
        for key, rule in (cfg.index_dates or {}).items():
            if not isinstance(rule, dict):
                continue
            of = [c.lower() for c in rule.get("of", [])]
            present = [c for c in of if c in src[isrc].columns]
            if not present:
                continue
            # max over the present inputs; greatest needs >=2 args, so a single present column IS the max.
            expr = (F.greatest(*[F.col(c) for c in present])
                    if rule.get("method", "max") == "max" and len(present) > 1
                    else F.col(present[0]))
            src[isrc] = src[isrc].withColumn(key.replace("_", ""), expr)
    return src
