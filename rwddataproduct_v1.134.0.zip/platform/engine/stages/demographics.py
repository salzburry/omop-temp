"""Stage: demographics. Ports demographics_variable_addn().

Age banding and the region/race/ethnicity/practice mappings are read from
variables/demographics.yaml and compiled to Spark SQL CASE expressions, so the bands and
crosswalks are reviewed config — not buried in engine code.
"""
from __future__ import annotations


def _q(s: str) -> str:
    return "'" + str(s).replace("'", "''") + "'"


def _bands_case(bands, value_expr, key="label"):
    """CASE over numeric bands with min/max[/_excl] bounds and a fallthrough row."""
    whens = []
    for b in bands:
        out = _q(b[key]) if key == "label" else str(b[key])
        if "when" in b and b["when"] == "fallthrough":
            continue
        conds = []
        if "eq" in b:
            conds.append(f"{value_expr} = {b['eq']}")
        if "ge" in b:
            conds.append(f"{value_expr} >= {b['ge']}")
        if "min" in b:
            conds.append(f"{value_expr} >= {b['min']}")
        if "max" in b:
            conds.append(f"{value_expr} <= {b['max']}")
        if "max_excl" in b:
            conds.append(f"{value_expr} < {b['max_excl']}")
        if conds:
            whens.append(f"WHEN {' AND '.join(conds)} THEN {out}")
    default = next((b for b in bands if b.get("when") == "fallthrough"), None)
    tail = f" ELSE {_q(default[key]) if key == 'label' else default[key]}" if default else ""
    return "CASE " + " ".join(whens) + tail + " END"


def _map_case(rows, value_expr, key="label"):
    """CASE over a source-value -> reported-value crosswalk (race/ethnicity/practice)."""
    whens = []
    for r in rows:
        out = _q(r[key]) if key == "label" else str(r[key])
        if "from" in r:
            vals = ", ".join(_q(str(v).lower()) for v in r["from"])
            whens.append(f"WHEN LOWER({value_expr}) IN ({vals}) THEN {out}")
    default = next((r for r in rows if r.get("when") == "fallthrough"), None)
    tail = f" ELSE {_q(default[key]) if key == 'label' else default[key]}" if default else ""
    return "CASE " + " ".join(whens) + tail + " END"


def _region_case(rows, col, key="label"):
    """CASE over state -> region (state IN [...]), with state_is_null -> Missing and fallthrough."""
    whens, missing, default = [], None, None
    for r in rows:
        out = _q(r[key]) if key == "label" else str(r[key])
        if r.get("when") == "state_is_null":
            missing = out
        elif r.get("when") == "fallthrough":
            default = out
        elif "states" in r:
            vals = ", ".join(_q(s) for s in r["states"])
            whens.append(f"WHEN {col} IN ({vals}) THEN {out}")
    pre = f"WHEN {col} IS NULL THEN {missing} " if missing is not None else ""
    tail = f" ELSE {default}" if default is not None else ""
    return "CASE " + pre + " ".join(whens) + tail + " END"


def reads(cfg):
    """The demographics table read (hard), plus the two engine-guarded joins an external review
    found in NO report: `practice` (practic/practicn) and `ses`. Their absence is a degrade the
    build performs silently, so it is DECLARED here with what it does."""
    from . import read
    if "demographics" not in cfg.roles():     # a slim pack configures nothing here — a fact,
        return []                             # not a malformation (test fixtures, new tumours)
    out = [read("demographics", ["patientid", "birthyear", "race", "ethnicity", "state"],
                "demographics.build")]
    dem = cfg.pack("demographics")
    if dem.get("practice_map"):
        out.append(read("practice", ["patientid", "practicetype"], "demographics.practice_map",
                        required=False,
                        when_absent="practic/practicn are not emitted — the configured practice "
                                    "mapping quietly produces nothing"))
    ses = dem.get("ses") or {}
    if ses.get("source_column"):
        out.append(read("ses", ["patientid", ses["source_column"]], "demographics.ses",
                        required=False,
                        when_absent="the ses column is not emitted — the configured source "
                                    "column quietly produces nothing"))
    return out


def build(src, idx, cfg):
    from pyspark.sql import functions as F

    dem_cfg = cfg.pack("demographics")
    df = idx.select("patientid", "index_date").join(src["demographics"], "patientid", "left")

    if "ses" in src:                                   # SES table (optional)
        df = df.join(src["ses"], "patientid", "left")
    if "practice" in src:                              # practice type aggregated per patient
        agg = (src["practice"].groupBy("patientid")
               .agg(F.expr("concat_ws(',', sort_array(collect_set(upper(practicetype))))")
                    .alias("practicetype_agg")))
        df = df.join(agg, "patientid", "left")

    df = (df.withColumn("year_index", F.year("index_date"))
            .withColumn("age", F.col("year_index") - F.col("birthyear").cast("int")))

    df = (df
          .withColumn("agegrl", F.expr(_bands_case(dem_cfg["age_bands"], "age", "label")))
          .withColumn("agegrln", F.expr(_bands_case(dem_cfg["age_bands"], "age", "code")))
          .withColumn("race", F.expr(_map_case(dem_cfg["race_map"], "race", "label")))
          .withColumn("racen", F.expr(_map_case(dem_cfg["race_map"], "race", "code")))
          .withColumn("eth", F.expr(_map_case(dem_cfg["ethnicity_map"], "ethnicity", "label")))
          .withColumn("ethn", F.expr(_map_case(dem_cfg["ethnicity_map"], "ethnicity", "code")))
          .withColumn("regionl", F.expr(_region_case(dem_cfg["regions"], "state", "label")))
          .withColumn("regionln", F.expr(_region_case(dem_cfg["regions"], "state", "code"))))

    keep = ["patientid", "index_date", "age", "agegrl", "agegrln", "race", "racen",
            "eth", "ethn", "regionl", "regionln"]
    if "practice" in src:
        df = (df.withColumn("practic", F.expr(_map_case(dem_cfg["practice_map"], "practicetype_agg", "label")))
                .withColumn("practicn", F.expr(_map_case(dem_cfg["practice_map"], "practicetype_agg", "code"))))
        keep += ["practic", "practicn"]
    ses = dem_cfg.get("ses", {})
    if ses.get("source_column") and "ses" in src:    # need the ses SOURCE joined, not just the config —
        df = df.withColumn("ses", F.expr(            # else a config with ses.source_column but no ses
            f"coalesce(cast({ses['source_column']} as string), "   # source (e.g. DLBCL) would F.expr an
            f"{_q(ses.get('missing_label', 'Missing'))})"))        # absent column and crash mid-stage.
        keep.append("ses")
    return df.select(*keep)
