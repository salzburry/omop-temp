"""Stage: normalized line-of-therapy table. The single source of `new_lot_n`.

Derives `new_lot_n` once and reuses it for indexing and treatment, so stages can't drift.
`linename` is lower-cased here. Everything is CONFIG-DRIVEN and backward-compatible — the defaults
reproduce the prostate behaviour exactly:

  * line_setting      keep only rows where `linesetting` == it (prostate: mCRPC). None = keep all.
  * exclude_settings  drop rows whose `linesetting` is in this list (EC: ['ADVANCED']). [] = drop none.
  * maintenance       None (default) = no maintenance filter; True/False = keep only
                      `maintenance_column` == 'True'/'False' (OC/EC index off the maintenance flag).
  * line_number_col   'new_lot_n' (default) = a derived row_number over the kept lines (prostate);
                      'linenumber' = use the raw LOT `linenumber` as the line key (OC/EC).

Tumors without these columns (e.g. heme, or a LOT table with no `linesetting`/maintenance flag) are
unaffected: a filter is applied ONLY when the column is present, so it can never empty the table.
"""
from __future__ import annotations

from . import read


def uses_line_setting(cfg) -> bool:
    """A product uses a line-setting model when the GLOBAL lot.line_setting is set OR ANY cohort
    declares its own — the stages resolve `cohort.line_setting` first and fall back to the global,
    so both `lot.linesetting` and the treatment stage's per-line episode aggregation gate on this
    combined answer (a cohort-setting product with no global would otherwise pass preflight while
    the runtime filters on a column nobody required)."""
    return bool(cfg.lot_line_setting or
                any(c.get("line_setting") is not None for c in cfg.cohorts))


def reads(cfg):
    """The LOT table read — hard (`src[\"lot\"]` at first use; index, treatment and the per-line
    outcomes all key off it). `linesetting` only under a line-setting model; the maintenance
    column only when a cohort filters on it."""
    cols = ["patientid", "linename", "startdate", "enddate", "linenumber"]
    if uses_line_setting(cfg):
        cols.append("linesetting")
    if any(c.get("maintenance") is not None for c in cfg.cohorts) and cfg.lot_maintenance_column:
        cols.append(cfg.lot_maintenance_column)
    return [read("lot", cols, "lot.normalized")]


def normalized(src, line_setting=None, exclude_settings=None, maintenance=None,
               line_number_col="new_lot_n", maintenance_column="ismaintenancetherapy"):
    """Relevant LOT rows with `linename` lower-cased and `new_lot_n` set. See module docstring."""
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window

    lot = src["lot"].withColumn("linename", F.lower(F.col("linename")))
    cols = set(lot.columns)
    if line_setting is not None and "linesetting" in cols:
        lot = lot.filter(F.col("linesetting") == line_setting)
    if exclude_settings and "linesetting" in cols:
        lot = lot.filter(~F.col("linesetting").isin(list(exclude_settings)))
    if maintenance is not None and maintenance_column in cols:
        lot = lot.filter(F.col(maintenance_column) == ("True" if maintenance else "False"))

    if line_number_col == "linenumber":
        # OC/EC: a "line N" cohort means the raw LOT line N (combined with the maintenance filter).
        return lot.withColumn("new_lot_n", F.col("linenumber"))
    # Default (prostate/NSCLC): derive new_lot_n as a row_number over the kept lines. Deterministic
    # ordering — ties on startdate would otherwise make new_lot_n nondeterministic across runs.
    w = Window.partitionBy("patientid").orderBy(
        F.col("startdate").asc(), F.col("linenumber").asc(),
        F.col("enddate").asc_nulls_last(), F.col("linename").asc_nulls_last())
    return lot.withColumn("new_lot_n", F.row_number().over(w))
