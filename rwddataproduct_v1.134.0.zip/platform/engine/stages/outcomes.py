"""Stage: outcomes. Ports outcomes_tbl_var().

Follow-up gate (id3mosfu), visit-recency window (vis120) and the months conversion come from
variables/outcomes.yaml. OS / TTD / TTNT / treatment-discontinuation are assembled from the
clinical (dthdt/dthfl/fued) and treatment (per-line lot dates, lotn) tables.

The R keys the line outcomes off a global `coh_flag` with hardcoded lot1/lot2/lot3 branches; the
behaviour is REGULAR in the line number N, so this engine takes N from the cohort (cohort.lot_number)
and parameterises one implementation — same logic for prostate lot1-3 and OC/EC lot1-5. The per-row
CASE expressions are pure SQL-string builders (_trtdis_sql / _ttntfl_sql / _ttnt_sql / _ttd_sql) so
they are unit-tested and proven byte-identical to engine-r/stages.R in tests/test_r_parity.py.

The line outcomes (vis120/trtdis/ttd/ttntfl/ttnt) are OPTIONAL: a tumor enables them with a
`line_outcomes:` block in outcomes.yaml. Without it (or without `trt`), only id3mosfu (+ optional OS)
is emitted — so existing products are unaffected.

Guards against the clinical stage not emitting the death/follow-up anchors OS needs — failing with a
clear message instead of a cryptic Spark "unresolved column" error.
"""
from __future__ import annotations

from .treatment import line_cols          # single source of truth for the per-line column names


def _trtdis_sql(n: int) -> str:
    """trtdis flag for line cohort N: discontinued if a later line started, or death on this line,
    or the patient was still active >=window after line end (vis120). Caller gates on id3mosfu==1
    AND lot{n}sd present. (R: case_when(lotn>N | (lotn==N & !is.na(dthdt)) | vis120==1 ~ 1, ~ 0).)

    The NULL arm: when vis120 is NULL (no visit sources configured — see _vis120), a patient not
    provable as discontinued by lines or death is UNKNOWN, not 0. An external review caught the
    old shape: with no encounter feed the flag claimed "not discontinued" for every such patient."""
    return (f"CASE WHEN lotn > {n} OR (lotn = {n} AND dthdt IS NOT NULL) OR vis120 = 1 "
            f"THEN 1 WHEN vis120 IS NULL THEN NULL ELSE 0 END")


def _ttntfl_sql(n: int) -> str:
    """ttntfl (had a next-treatment event) for line cohort N: a later line started, or death.
    Caller gates on id3mosfu==1. (R: case_when(lotn>N | dthfl==1 ~ 1, ~ 0).)"""
    return f"CASE WHEN lotn > {n} OR dthfl = 1 THEN 1 ELSE 0 END"


def _ttd_sql(n: int, dpm, maint=False) -> str:
    """ttd (time to discontinuation, months) for line cohort N = datediff(lot{n}ed, index)/dpm — the
    line's LAST-ACTIVITY date (loted), the column treatment.line_cols(n, maint)['lastdate'] emits.
    For a MAINTENANCE cohort it keys off the maintenance line's lastdate (lot{n}med). No +1 (matches
    the R). Caller gates on id3mosfu==1 and ttd_from_line."""
    return f"datediff({line_cols(n, maint)['lastdate']}, index_date)/{dpm}"


def _ttnt_sql(n: int, dpm, has_next: bool) -> str:
    """ttnt (time to next treatment, months) for line cohort N. Event -> to the earlier of the NEXT
    line's start (line_cols(n+1)['start']) and death; censored -> to follow-up end. (R: ttntfl==1 ->
    (datediff(pmin(lot{n+1}sd, dthdt))+1)/dpm; ttntfl==0 -> (datediff(fued)+1)/dpm; else 0.) Spark
    least() skips nulls == pmin na.rm. When the next line column is absent the next date is death."""
    nxt = f"least({line_cols(n + 1)['start']}, dthdt)" if has_next else "dthdt"
    return (f"CASE WHEN ttntfl = 1 THEN (datediff({nxt}, index_date)+1)/{dpm} "
            f"WHEN ttntfl = 0 THEN (datediff(fued, index_date)+1)/{dpm} ELSE 0 END")


def _tsstfl_sql(n: int) -> str:
    """tsstfl (had a 2nd-subsequent-treatment event) for line cohort N: TWO later lines started
    (lotn > N+1), or death. Caller gates on id3mosfu. Mirrors _ttntfl_sql but to line N+2 (TSST = time
    to 2nd subsequent treatment). Byte-identical to engine-r/cases.R::tsstfl_sql (parity-tested)."""
    return f"CASE WHEN lotn > {n + 1} OR dthfl = 1 THEN 1 ELSE 0 END"


def _tsst_sql(n: int, dpm, has_n2: bool) -> str:
    """tsst (time to 2nd subsequent treatment, months) for line cohort N. Event -> to the earlier of the
    N+2 line's start and death; censored -> follow-up end. Mirrors _ttnt_sql but to line N+2. When the
    N+2 column is absent the next date is death. Byte-identical to engine-r/cases.R::tsst_sql."""
    nxt = f"least({line_cols(n + 2)['start']}, dthdt)" if has_n2 else "dthdt"
    return (f"CASE WHEN tsstfl = 1 THEN (datediff({nxt}, index_date)+1)/{dpm} "
            f"WHEN tsstfl = 0 THEN (datediff(fued, index_date)+1)/{dpm} ELSE 0 END")


def _progression_pred(evidence_cols, pseudo_col, yes="Yes", no="No") -> str:
    """A progression EVENT row: ANY evidence flag == yes AND NOT pseudo-progression. (R RW-PFS:
    (isradiographicevidence | ispathologicevidence | …) == 'Yes' AND ispseudoprogressionmentioned ==
    'No'.) Mirrored in engine-r/cases.R::progression_pred and proven byte-identical in test_r_parity."""
    ev = " OR ".join(f"{c} = '{yes}'" for c in evidence_cols)
    return f"({ev}) AND {pseudo_col} = '{no}'"


def _rwpfs_gate(pcfg, clinic_raw) -> str:
    """The rwPFS eligibility predicate that drives BOTH ELIGPFS and the PFS family (flag/date/months):
    >=3 months follow-up (id3mosfu) AND — when `eligibility_requires_censor` is set and a RAW clinic-note
    column exists — a clinic note strictly AFTER index. Using the raw clinic-note date (not the
    fued-coalesced censor) means a patient with only a fued fallback is NOT eligible, which also prevents a
    pre-index censor producing a negative interval. Default (no censor refinement) -> id3mosfu only, so
    OC/EC stay byte-identical. Mirrored inline in engine-r/stages.R::outcomes_build."""
    if pcfg.get("eligibility_requires_censor") and clinic_raw:
        return f"id3mosfu = 1 AND {clinic_raw} > index_date"
    return "id3mosfu = 1"


def _progression(F, Window, idx, prog_df, pcfg, telemetry=None, cohort=None):
    """First and second qualifying progression dates per (patientid, index_date) -> _prog1 / _prog2.

    A qualifying record matches _progression_pred AND has progressiondate > index (progression AFTER
    the cohort's index line). Same-day duplicate evidence rows are collapsed to ONE event (distinct
    dates) before ranking earliest-first — otherwise two records on the same progressiondate would
    fill BOTH _prog1 and _prog2 and PFS2 would double-count a single progression. Returns base
    (patientid, index_date) left-joined to the 1st and 2nd DISTINCT dates (null when none).
    """
    date_col = pcfg["date_column"]
    excl = int(pcfg.get("exclusion_days", 0))            # progression must be > index + excl days — the
                                                         # rwPFS exclusion window that associates a
                                                         # progression with the INDEX line, not the prior
                                                         # one (prostate: 14). 0 = > index (OC/EC default).
    pred = _progression_pred(pcfg["evidence_columns"], pcfg["pseudoprogression_column"],
                             pcfg.get("yes_value", "Yes"), pcfg.get("no_value", "No"))
    base = idx.select("patientid", "index_date")
    cutoff = F.expr(f"date_add(index_date, {excl})") if excl else F.col("index_date")
    ev = (base.join(prog_df, "patientid", "inner")
          .filter(F.col(date_col) > cutoff)
          .filter(F.expr(pred))
          .select("patientid", "index_date", date_col)
          .distinct())                                   # one row per distinct progression date
    if telemetry is not None:
        # candidates are DISTINCT qualifying event dates (deliberately collapsed above), so
        # tied_same_date_keys is 0 by construction here; the numbers that matter are how many
        # events competed and how many keys got a first progression at all
        telemetry.record_selection(F, ev, ("patientid", "index_date"), date_col,
                                   cohort, "progression", "progression")
    w = Window.partitionBy("patientid", "index_date").orderBy(F.col(date_col).asc())
    ranked = ev.withColumn("_pr", F.row_number().over(w))
    out = base
    for rn, alias in ((1, "_prog1"), (2, "_prog2")):
        d = (ranked.filter(F.col("_pr") == rn)
             .select("patientid", "index_date", F.col(date_col).alias(alias)))
        out = out.join(d, ["patientid", "index_date"], "left")
    if telemetry is not None:
        # non_null of the FIRST date over every index key: "how many patients have a qualifying
        # progression at all" (_prog2 is derivative and not separately counted)
        telemetry.record_selection_outputs(F, out, [("progression", "_prog1")],
                                           cohort, "progression")
    return out


def reads(cfg):
    """The outcomes reads: each visit_sources entry's own date column (through the ONE parser
    below), and the progression family's date/pseudoprogression/evidence columns plus its censor
    source. A malformed visit_sources entry raises here — validate surfaces it as a problem
    instead of silently requiring nothing."""
    from . import read
    if "outcomes" not in cfg.roles():
        return []
    out_cfg = cfg.pack("outcomes")
    out = []
    lo = out_cfg.get("line_outcomes")
    if lo:
        for s, vdate in visit_source_pairs(lo):
            out.append(read(s, ["patientid", vdate], "outcomes.line_outcomes.visit_sources",
                            when_absent="named in visit_sources — the build REFUSES when the "
                                        "feed is not loaded (a partial encounter count would "
                                        "silently understate vis120)"))
    pcfg = out_cfg.get("progression")
    if pcfg:
        out.append(read(pcfg.get("source"),
                        ["patientid", pcfg.get("date_column"),
                         pcfg.get("pseudoprogression_column")]
                        + list(pcfg.get("evidence_columns") or []),
                        "outcomes.progression"))
        cc = pcfg.get("censor")
        if cc:
            out.append(read(cc.get("source"), ["patientid", cc.get("date_column")],
                            "outcomes.progression.censor"))
    return out


def visit_source_pairs(lo):
    """[(source, date_column)] from line_outcomes.visit_sources — THE one reader of that key.

    Two entry shapes: a bare source name, whose encounter date is `visit_date_column` (default
    `visitdate`), or `{source: telemed, date_column: telemeddate}` for a feed whose date column
    is named differently. Any other shape refuses: a feed whose date the build cannot read would
    contribute nothing to vis120 while looking configured.

    Shared with validate.required_columns, so the date column each entry names is REQUIRED of its
    source at preflight — one parser, or the preflight and the build would disagree about what a
    config asks for.
    """
    default = lo.get("visit_date_column", "visitdate")
    entries = lo.get("visit_sources") or []
    if isinstance(entries, str):
        # a scalar (`visit_sources: visit`) would iterate CHARACTER BY CHARACTER here while the
        # R engine reads it as one source — same config, two engines, two answers. Refused.
        raise ValueError(f"line_outcomes.visit_sources must be a list, got the scalar "
                         f"{entries!r} — write `visit_sources: [{entries}]`")
    pairs = []
    for entry in entries:
        if isinstance(entry, dict):
            if not entry.get("source"):
                raise ValueError(f"line_outcomes.visit_sources: a mapping entry must name "
                                 f"`source` (got {entry!r})")
            pairs.append((str(entry["source"]), str(entry.get("date_column") or default)))
        else:
            pairs.append((str(entry), default))
    return pairs


def _vis120(F, base_end, src, lo, win, end_col):
    """vis120 / lastvisitdate for a line cohort. vis120 = 1 if the patient has any visit/telemed
    encounter on/after (line end + win) days, else 0; lastvisitdate = the latest such encounter.
    (R filters encounters to >= DATE_ADD(lot{n}ed, 120), takes the max, flags presence.)

    base_end: (patientid, index_date, <end_col>) for this cohort. Returns (patientid, index_date,
    vis120, lastvisitdate).

    THE ABSENT-FEED ANSWER IS NULL, NOT 0. With no visit sources configured, "had no qualifying
    encounter" is not a fact anyone established — an external review caught mCRC getting vis120=0
    for every line patient because its config never wired `visit_sources`, and 0 fed trtdis as
    "not discontinued". Unconfigured -> NULL (unknown). A CONFIGURED source missing from the
    loaded frames is a different state and refuses: the config claims a feed the build does not
    have, and silently computing over the remainder would understate encounters.
    """
    keys = ["patientid", "index_date"]
    pairs = visit_source_pairs(lo)
    missing = [s for s, _d in pairs if s not in src]
    if missing:
        raise ValueError(f"line_outcomes.visit_sources names source(s) not loaded: "
                         f"{', '.join(missing)} — vis120 computed over a partial encounter feed "
                         f"would silently undercount; fix the config or the source load")
    if not pairs:
        return (base_end.select(*keys).withColumn("vis120", F.lit(None).cast("int"))
                .withColumn("lastvisitdate", F.lit(None).cast("date")))
    enc = None
    for s, vdate in pairs:                            # union the encounter dates across sources
        e = src[s].select("patientid", F.col(vdate).alias("_vd"))
        enc = e if enc is None else enc.unionByName(e)
    qualifying = (base_end.join(enc, "patientid", "left")
                  .filter(F.col("_vd") >= F.expr(f"date_add({end_col}, {win})"))
                  .groupBy(*keys).agg(F.max("_vd").alias("lastvisitdate")))
    return (base_end.select(*keys).join(qualifying, keys, "left")
            .withColumn("vis120", F.when(F.col("lastvisitdate").isNotNull(), F.lit(1))
                        .otherwise(F.lit(0))))


def build(src, idx, clin, trt, cfg, cohort=None, telemetry=None):
    from pyspark.sql import functions as F, Window

    # cohort LABEL for the opt-in telemetry rows only — nothing below branches on it
    _cid = (cohort or {}).get("id") or str((cohort or {}).get("cohortn"))
    out_cfg = cfg.pack("outcomes")
    min_fu = out_cfg["min_followup_days"]
    dpm = out_cfg["days_per_month"]
    # OBSERVATION END, not the enrollment close. id3mosfu asks "could this patient have been
    # observed >= min_fu days" — a fact about how far follow-up capture extends.
    # cfg.observation_end falls back to study.index_end until a pack states the distinct field,
    # so nothing moves until a human writes the config (the endpoint definition is RWB's).
    end = F.lit(cfg.observation_end).cast("date")
    keys = ["patientid", "index_date"]
    base = idx.select(*keys)

    # id3mosfu: >= ~3 months of potential follow-up (observation_end - index_date >= min_fu days).
    out = base.withColumn(
        "id3mosfu",
        F.when(F.datediff(end, F.col("index_date")) >= min_fu, F.lit(1)).otherwise(F.lit(0)))

    # Death/follow-up anchors (dthfl/dthdt/fued) feed BOTH OS and the line outcomes — join once.
    anchors = [c for c in ("dthfl", "dthdt", "fued")
               if clin is not None and c in clin.columns]
    if anchors:
        out = out.join(clin.select(*keys, *anchors), keys, "left")

    # OS is optional: omit `overall_survival` from outcomes.yaml to skip it. When present it needs the
    # clinical death/follow-up anchors (clinical.follow_up_and_death). Guard with a clear message.
    os_cfg = out_cfg.get("overall_survival")
    if os_cfg:
        required = [os_cfg["event_flag"], os_cfg["death_anchor"], os_cfg["censor_anchor"]]
        missing = [c for c in required if clin is None or c not in clin.columns]
        if missing:
            raise RuntimeError(
                f"outcomes.build: clinical stage did not emit the OS anchor column(s) {missing}. "
                "They come from clinical.follow_up_and_death — ensure it runs, or remove "
                "`overall_survival` from variables/outcomes.yaml to skip OS.")
        out = out.withColumn("os", F.expr(
            f"CASE WHEN id3mosfu = 0 THEN NULL "
            f"WHEN id3mosfu = 1 AND {os_cfg['event_flag']} = 1 "
            f"  THEN (datediff({os_cfg['death_anchor']}, index_date)+1)/{dpm} "
            f"WHEN id3mosfu = 1 AND {os_cfg['event_flag']} = 0 "
            f"  THEN (datediff({os_cfg['censor_anchor']}, index_date)+1)/{dpm} "
            f"ELSE NULL END"))

    emitted = ["id3mosfu"] + (["os"] if os_cfg else [])

    # Line-cohort outcomes (vis120 / trtdis / ttd / ttntfl / ttnt). Optional + config-gated; needs
    # the treatment per-line frame. The overall cohort (no lot_number) gets vis120=0 and the rest
    # null, exactly like the R's `coh_flag == "overall"` branches.
    lo = out_cfg.get("line_outcomes")
    if lo and trt is not None:
        win = out_cfg["visit_recency_days"]
        ln = (cohort or {}).get("lot_number")
        maint = bool((cohort or {}).get("maintenance"))     # a lot{N}m cohort keys off the maint line
        if ln is not None:
            # Bring this line's treatment columns (lotn, this line's start/lastdate, next line start
            # for ttnt) using the SAME names treatment.line_cols emits — so they always resolve. For a
            # MAINTENANCE cohort, "this line" is the maintenance line (lot{N}m*: start/lastdate); the
            # NEXT treatment is still the next regimen's (non-maintenance) start.
            cur, nxt = line_cols(ln, maint), line_cols(ln + 1)
            nxt2 = line_cols(ln + 2)
            last_col, start_col = cur["lastdate"], cur["start"]
            has_next = nxt["start"] in trt.columns
            has_n2 = nxt2["start"] in trt.columns
            want = (["lotn", start_col, last_col] + ([nxt["start"]] if has_next else [])
                    + ([nxt2["start"]] if (lo.get("tsst") and has_n2) else []))
            tcols = [c for c in want if c in trt.columns]
            out = out.join(trt.select(*keys, *tcols), keys, "left")
            # vis120 keys off this line's LAST-ACTIVITY date (loted == lastdate); join it, then the
            # line CASEs (which read vis120).
            vis = _vis120(F, out.select(*keys, last_col), src, lo, win, last_col)
            out = out.join(vis, keys, "left")
            gate = f"id3mosfu = 1 AND {start_col} IS NOT NULL"   # trtdis defined only for started line
            out = out.withColumn("trtdis", F.expr(
                f"CASE WHEN {gate} THEN ({_trtdis_sql(ln)}) ELSE NULL END"))
            out = out.withColumn("ttntfl", F.expr(
                f"CASE WHEN id3mosfu = 1 THEN ({_ttntfl_sql(ln)}) ELSE NULL END"))
            out = out.withColumn("ttnt", F.expr(
                f"CASE WHEN id3mosfu = 1 THEN ({_ttnt_sql(ln, dpm, has_next)}) ELSE NULL END"))
            if ln >= int(lo.get("ttd_from_line", 1)):           # R: ttd reported for 2L+ only
                out = out.withColumn("ttd", F.expr(
                    f"CASE WHEN id3mosfu = 1 THEN ({_ttd_sql(ln, dpm, maint)}) ELSE NULL END"))
            else:
                out = out.withColumn("ttd", F.lit(None).cast("double"))
            if lo.get("tsst"):                       # time to 2nd subsequent treatment (TSST)
                out = out.withColumn("tsstfl", F.expr(
                    f"CASE WHEN id3mosfu = 1 THEN ({_tsstfl_sql(ln)}) ELSE NULL END"))
                out = out.withColumn("tsst", F.expr(
                    f"CASE WHEN id3mosfu = 1 THEN ({_tsst_sql(ln, dpm, has_n2)}) ELSE NULL END"))
        else:
            # NOT APPLICABLE IS NULL, LIKE ITS SIBLINGS. A cohort with no line endpoint has no
            # window for vis120 to count in; every other line outcome answers that with NULL, and
            # this one wrote 0 — "no qualifying encounter", a fact nobody established. An external
            # review caught the inconsistency; one question, one answer.
            out = (out.withColumn("vis120", F.lit(None).cast("int"))
                   .withColumn("lastvisitdate", F.lit(None).cast("date")))
            for c in ("trtdis", "ttntfl"):
                out = out.withColumn(c, F.lit(None).cast("int"))
            for c in ("ttd", "ttnt"):
                out = out.withColumn(c, F.lit(None).cast("double"))
            if lo.get("tsst"):
                out = (out.withColumn("tsstfl", F.lit(None).cast("int"))
                       .withColumn("tsst", F.lit(None).cast("double")))
        emitted += ["vis120", "lastvisitdate", "trtdis", "ttd", "ttntfl", "ttnt"]
        if lo.get("tsst"):
            emitted += ["tsstfl", "tsst"]

    # Real-world PFS / PFS2 (progression family). Optional: needs a `progression:` block AND its
    # declared source. Event = the earlier of the first qualifying progression and death; censored at
    # follow-up end; gated on id3mosfu. PFS2 uses the SECOND progression. Cohort-correct via index_date
    # (progressiondate > index + exclusion_days). Two optional, config-gated prostate refinements leave
    # OC/EC byte-identical: `eligibility_flag` emits an explicit rwPFS-eligibility column, and
    # `line_cohorts_only` restricts the family to the LINE cohorts — the overall cohort (no lot_number)
    # gets a NULL family so the per-cohort union stays column-aligned.
    pcfg = out_cfg.get("progression")
    if pcfg and pcfg.get("source") in src:
        miss = [c for c in ("dthdt", "fued") if c not in out.columns]
        if miss:
            raise RuntimeError(
                f"outcomes.build: progression PFS needs clinical anchor(s) {miss} (from "
                "clinical.follow_up_and_death) — or remove `progression` from variables/outcomes.yaml.")
        is_line = (cohort or {}).get("lot_number") is not None
        suppress = bool(pcfg.get("line_cohorts_only")) and not is_line

        # rwPFS censor: emit the RAW last clinic-note date (NULL when the patient has no clinic note) and
        # censor the interval at coalesce(clinic-note, fued) so everyone stays censorable. Keeping the raw
        # date SEPARATE from the fued fallback is what lets ELIGPFS require a clinic note AFTER index — a
        # patient with only a fued date is NOT eligible (and so can never yield a pre-index censor).
        censor_anchor, ccfg, clinic_raw = "fued", pcfg.get("censor"), None
        if ccfg and ccfg.get("source") in src:
            cas, cdate = ccfg.get("as", "lastclinicnotedate"), ccfg["date_column"]
            agg = F.min if ccfg.get("aggregate") == "min" else F.max
            censor_df = src[ccfg["source"]].groupBy("patientid").agg(agg(F.col(cdate)).alias(cas))
            out = (out.join(censor_df, "patientid", "left")                  # cas = RAW clinic-note date
                   .withColumn("_censor", F.coalesce(F.col(cas), F.col("fued"))))  # censor anchor (fallback)
            censor_anchor, clinic_raw = "_censor", cas
            emitted.append(cas)

        # rwPFS GATE: >=3mo follow-up AND (when eligibility_requires_censor) a clinic note AFTER index. The
        # SAME gate drives ELIGPFS *and* the PFS family, so an ineligible patient is NULL throughout — no
        # stray event a TFL miscounts, no negative interval from a pre-index censor. Default (OC/EC) is the
        # id3mosfu-only gate, so those tumors stay byte-identical.
        gate = _rwpfs_gate(pcfg, clinic_raw)

        eflag = pcfg.get("eligibility_flag")               # prostate ELIGPFS (rwPFS eligibility)
        if eflag:                                          # 1 eligible / 0 ineligible line cohort; NULL overall
            out = out.withColumn(eflag, F.expr(
                f"CASE WHEN {gate} THEN 1 ELSE 0 END" if is_line else "CAST(NULL AS INT)"))
            emitted.append(eflag)
        out = out.join(_progression(F, Window, idx, src[pcfg["source"]], pcfg,
                                    telemetry=telemetry, cohort=_cid), keys, "left")
        for fl, dt, mo, prog in (("pfsfl", "pfsdt", "pfs", "_prog1"),
                                 ("pfs2fl", "pfs2dt", "pfs2", "_prog2")):
            if mo == "pfs2" and not pcfg.get("pfs2"):
                continue
            if suppress:                                   # overall cohort -> NULL family (column-aligned)
                out = (out.withColumn(fl, F.lit(None).cast("int"))
                       .withColumn(dt, F.lit(None).cast("date"))
                       .withColumn(mo, F.lit(None).cast("double")))
            else:
                # flag/date/months all gated on the rwPFS `gate` (== ELIGPFS) so an ineligible patient is
                # NULL throughout — never a stray event flag/date a downstream TFL might miscount.
                out = (out.withColumn("_evt", F.expr(f"least({prog}, dthdt)"))     # progression OR death
                       .withColumn(fl, F.expr(f"CASE WHEN {gate} AND _evt IS NOT NULL THEN 1 "
                                              f"WHEN {gate} THEN 0 ELSE NULL END"))
                       .withColumn(dt, F.expr(f"CASE WHEN {gate} THEN coalesce(_evt, {censor_anchor}) "
                                              "ELSE NULL END"))   # censor: clinic-note (fued fallback)
                       .withColumn(mo, F.expr(f"CASE WHEN {gate} THEN "
                                              f"(datediff({dt}, index_date)+1)/{dpm} ELSE NULL END"))
                       .drop("_evt"))
            emitted += [fl, dt, mo]
        out = out.drop("_prog1", "_prog2", "_censor")

    return out.select(*keys, *emitted)
