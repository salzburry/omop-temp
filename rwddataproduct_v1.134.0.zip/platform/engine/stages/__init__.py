"""PySpark stages for the prostate ADS. Each module ports one R function group.

These import pyspark and only run on a Spark session (Databricks). They are imported lazily
by engine.build_ads.build(), so importing the engine package does not require pyspark.

Each stage also declares WHAT IT READS: a module-level `reads(cfg)` returning typed records
built by `read()` below. An external review named the architecture defect this closes — the
dependency knowledge lived in `validate.required_columns` (a validator describing stages from
the outside) while the stages read whatever they read, and eight role-level reads matched no
declaration at all. The stage that dereferences a column is the one place that KNOWS it does,
so the declaration lives beside the code and `validate` composes, never re-derives.
`read()` is pure and imports no pyspark, so declaring costs a config walk, not a session.
"""


def read(role, columns, where, required=True, optional=(), when_absent=None):
    """One typed source read: the stage at `where` reads `columns` of logical `role`.

    required=True  the config asks for this read by name — an undeclared role is a BLOCKED
                   availability finding on the build path (the silent-null shape, refused).
    required=False an engine-guarded read: the stage tests `role in src` and degrades as
                   `when_absent` states. Visible in every report, never silently absent.
    optional       columns the stage reads emit-if-present (the graceful contract) — reported
                   by schema evidence, never demanded by preflight.
    """
    if required is False and not when_absent:
        raise ValueError(f"read({role!r}, where={where!r}): an engine-guarded read must state "
                         f"`when_absent` — what the build does without it is the fact a "
                         f"reviewer accepts, and an unstated one is a silence")
    return {"role": role, "columns": [c for c in columns if c],
            "optional_columns": [c for c in optional if c],
            "required": bool(required), "where": where, "when_absent": when_absent}
