"""Engine version — the SemVer of the locked, shared RWDP build engine.

Read from the sibling `platform/VERSION` file (the single source of truth) so a bump is a one-line,
reviewed diff. This is the ENGINE version (behaviour of the shared code), distinct from a product's
`spec_version` (the YAML contract, CalVer YYYYMM) and `data_refresh` (the data cut). The three axes are
documented in `governance/VERSIONING.md`.

`1.0.0` is the FIRST formally-declared engine version: before this the locked engine had no version
file. SemVer from here — MAJOR for a breaking engine change (an ADS a product can't reproduce by just
re-pinning), MINOR for backward-compatible additions, PATCH for fixes.
"""
from __future__ import annotations

from pathlib import Path

VERSION_FILE = Path(__file__).resolve().parents[1] / "VERSION"   # platform/VERSION


def engine_version() -> str:
    """The declared engine SemVer (e.g. '1.0.0'), read from platform/VERSION."""
    return VERSION_FILE.read_text(encoding="utf-8").strip()


ENGINE_VERSION = engine_version()
