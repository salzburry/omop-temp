"""Compile the treatment-category codelist into Spark SQL CASE expressions. Pure Python.

The R script classified each line of therapy with a 17-way `case_when` (lotcat / lotcatn).
That logic now lives in codelists/treatment_categories.yaml. This module turns the ordered
list into two Spark SQL CASE expressions — one for the label, one for the numeric code —
preserving first-match-wins. The engine wraps them with F.expr(); the strings are also
trivially unit-testable without Spark.
"""
from __future__ import annotations

# This module is imported BOTH ways: as `engine.codelists` (stages/*.py, tests) and as bare
# `codelists` with engine/ on sys.path (validate.py, the R parity harness). The registry it needs
# has to resolve under either, and a bare `import vocabularies` only works under the second.
try:                                     # package import
    from . import vocabularies
except ImportError:                      # engine/ on sys.path
    import vocabularies


# The DSL's vocabulary, and the ONE place its names are written down. Every other named thing a
# config selects — bmi_method, bsa_method, filter_method, the death-conflict policy — already comes
# from a registry the validator imports, so an unknown value is refused with the valid ones listed.
# These operators were the exception: a bare "unknown match operator: 'x'", which tells an analyst
# authoring a codelist nothing about what they may write instead, and nothing outside this file could
# enumerate them without copying the if/elif chain below.
#
# The descriptions are for the catalog (`platform/tools/blocks.py`); the KEYS are what compile_match
# accepts, and test_codelists asserts the two sets are identical by reading the dispatch back out of
# this module's own syntax tree. Add an operator below and to the chain, or the test says so.
MATCH_OPERATORS = {
    "equals":         "the name column equals this value (case-insensitive)",
    "like_any":       "the name column is LIKE any pattern in this list (case-insensitive, % wildcards)",
    "regexp":         "the name column matches this regular expression",
    "category_equals": "the drug-category column equals this value (case-insensitive)",
    "is_null":        "true where the name column IS NULL; `false` makes it match nothing",
    "code_in":        "the CODE column is any code in this list, compared under the declared "
                      "coding system's normalisation (C18.9 matches C189)",
    "code_prefix_any": "the CODE column starts with any prefix in this list — only for a "
                       "hierarchical system, where a prefix IS a generalisation (C18, L01XC)",
    "all_of":         "every nested match must hold (AND)",
    "any_of":         "at least one nested match must hold (OR)",
    "always":         "unconditionally true — the terminal fallthrough; `false` matches nothing",
}


def sql_str(s: str) -> str:
    """A Spark SQL string literal — the ONE quoter, and it escapes BACKSLASHES as well as quotes.

    The backslash half is not decorative. Spark parses escape sequences inside a string literal, and
    an UNRECOGNISED one loses its backslash silently: `SELECT '\\d'` returns the string `d`. So a
    codelist carrying `regexp: '\\d+'` compiled to `LOWER(linename) REGEXP 'd+'` — a pattern matching
    a literal letter d, matching nothing anyone intended, with no error at compile or run time. That
    is the fail-open shape this repository keeps finding: the operator is real, the config is
    plausible, the SQL is valid, and the answer is wrong.

    Verified against Spark 4.2.0 rather than reasoned about: `'\\d'` selects `d`, `'\\\\d'` selects
    `\\d`, and `v REGEXP '\\d'` returned zero rows over data containing digits.

    Changing this changes NO existing pack's SQL — no label, code, pattern or crosswalk value in any
    `codelists/` or `variables/` file contains a backslash — and `test_r_parity` + the golden suites
    prove it. It closes the hazard before the first pack writes one.

    Backslashes FIRST, then quotes: the quote-doubling introduces no backslashes, so the two are
    independent, but doing it the other way round would double an escape backslash the first pass
    had just written.

    `stages/clinical.py` imports this as its `_q` — the SAME function object, so a value map and a
    codelist cannot come to quote a pattern differently. `engine-r/` must define it twice (cases.R
    and codelists.R are each `source()`d ALONE by their parity harnesses, so neither can call the
    other); `test_r_parity` compares all three against a hostile string set.
    """
    return "'" + str(s).replace("\\", "\\\\").replace("'", "''") + "'"


_sql_str = sql_str          # the name this module's own compilers were written against


def normalised_code_sql(code_col: str, system: str) -> str:
    """SQL that puts the CODE COLUMN into the same form `vocabularies.normalise` puts a literal.

    Both sides of a code comparison must be normalised or the comparison is a coin toss on how the
    feed happens to punctuate: a code set written `C18.9` misses a column delivering `C189`, and the
    miss is silent. So the literals are normalised in Python (at compile time) and the column is
    normalised in SQL (at run time) by the SAME declared rule — `strip_chars` drives both.

    Mirrored character-for-character by engine-r/codelists.R::.normalised_code_sql.
    """
    expr = f"UPPER(TRIM({code_col}))"
    for ch in vocabularies.strip_chars(system):
        expr = f"REPLACE({expr}, {_sql_str(ch)}, '')"
    return expr


# Operators whose value is a LIST of alternatives. A bare string here is the highest-consequence
# YAML slip in this file, because the two engines disagree about what it means instead of failing:
#
#     code_prefix_any: I21          # scalar — meant [I21]
#
# Python iterates a string CHARACTER BY CHARACTER, compiling `LIKE 'i%' OR LIKE '2%' OR LIKE '1%'`,
# which matches most ICD codes beginning with I. R's `vapply` over a length-1 character vector
# compiles the single prefix `I21`, which is what the author meant. Same config, two different
# cohorts, nothing red — the exact silent-wrong-answer shape the code operators were added to avoid.
# Refused in BOTH engines, with the same sentence, so the slip is a build failure rather than a
# divergence.
LIST_OPERATORS = ("code_in", "code_prefix_any", "like_any", "all_of", "any_of")


def sequence_error(field, val):
    """Why `field`'s value is not a list of alternatives, or None. THE one such predicate.

    A bare string where a list is expected is not a style question. Python iterates it
    CHARACTER-BY-CHARACTER, so `from_equals_ci: positive` compiles to

        LOWER(col) IN ('p','o','s','i','t','i','v','e')

    — a predicate that matches nothing the author meant and still runs. R treats the same scalar as
    one value and builds the intended predicate, so the two engines silently disagree. This was
    fixed for the codelist operators and left in place everywhere else; keying the check on the
    FIELD NAME rather than on one call site is what stops that from happening again.
    """
    if isinstance(val, (str, bytes)) or not isinstance(val, (list, tuple)):
        return (f"{field}: {val!r} is not a list. Write `{field}: [{val!r}]` — a bare value here is "
                f"read character-by-character by the Python engine and as one whole value by R, so "
                f"the two engines would build different cohorts from the same config without "
                f"failing.")
    return None


def list_operator_error(op, val):
    """Why this operator's value is not a list of alternatives, or None."""
    return sequence_error(op, val) if op in LIST_OPERATORS else None


def compile_match(match: dict, name_col: str, cat_col: str,
                  code_col: str | None = None, code_system: str | None = None) -> str:
    """Compile one match dict into a SQL boolean predicate.

    Name comparisons are case-insensitive (LOWER(col)), matching the R `tolower(...)`/`LOWER(...)`.
    Code comparisons go through `normalised_code_sql` instead — see there for why.
    """
    if not isinstance(match, dict) or len(match) != 1:
        raise ValueError(f"each match needs exactly one operator, got: {match!r}")
    (op, val), = match.items()
    why = list_operator_error(op, val)
    if why:
        raise ValueError(why)
    name = f"LOWER({name_col})"
    cat = f"LOWER({cat_col})"

    if op in ("code_in", "code_prefix_any"):
        # Refuse at COMPILE time, where the message can name the fix. A code operator with no
        # column, or under an undeclared system, would otherwise compile to a comparison against
        # whatever the defaults happened to be — which is the silent-wrong-answer shape again.
        if not code_col:
            raise ValueError(f"{op} needs match_on.code_column — nothing says which column carries "
                             f"the codes")
        for why in vocabularies.system_errors(code_system):
            raise ValueError(f"{op}: match_on.code_system {why}")
        if not vocabularies.is_coded(code_system):
            raise ValueError(f"{op} against match_on.code_system: {code_system} — that is the "
                             f"declaration for a column carrying names, so use equals/like_any")
        norm = normalised_code_sql(code_col, code_system)
        if op == "code_in":
            if not val:
                raise ValueError("code_in needs at least one code")
            codes = [_sql_str(vocabularies.normalise(code_system, c)) for c in val]
            return f"{norm} IN (" + ", ".join(codes) + ")"
        for why in vocabularies.prefix_errors(code_system):
            raise ValueError(f"code_prefix_any: {why}")
        if not val:
            raise ValueError("code_prefix_any needs at least one prefix")
        prefixes = [vocabularies.normalise(code_system, p) for p in val]
        return "(" + " OR ".join(f"{norm} LIKE {_sql_str(p + '%')}" for p in prefixes) + ")"

    if op == "equals":
        return f"{name} = {_sql_str(str(val).lower())}"
    if op == "like_any":
        return "(" + " OR ".join(f"{name} LIKE {_sql_str(str(p).lower())}" for p in val) + ")"
    if op == "regexp":
        return f"{name} REGEXP {_sql_str(val)}"
    if op == "category_equals":
        return f"{cat} = {_sql_str(str(val).lower())}"
    if op == "is_null":
        return f"{name_col} IS NULL" if val else "FALSE"
    if op == "all_of":
        return "(" + " AND ".join(compile_match(m, name_col, cat_col, code_col, code_system)
                                  for m in val) + ")"
    if op == "any_of":
        return "(" + " OR ".join(compile_match(m, name_col, cat_col, code_col, code_system)
                                 for m in val) + ")"
    if op == "always":
        return "TRUE" if val else "FALSE"
    raise ValueError(f"unknown match operator {op!r}; valid: {sorted(MATCH_OPERATORS)}")


def compile_case(codelist: dict) -> tuple[str, str]:
    """Return (label_case_sql, code_case_sql) for a treatment_categories codelist.

    Order of `categories` is the CASE WHEN order, so first match wins — same as case_when.
    """
    mo = codelist.get("match_on", {}) or {}
    name_col = mo.get("name_column", "linename")
    cat_col = mo.get("drug_category_column", "detaileddrugcategory")
    # The code column and ITS system live on the codelist, so compile_case stays a pure function of
    # the codelist — which is what the R parity harness serialises. `validate` separately cross-checks
    # this declaration against the pack's `vocabularies:` block, so the codelist's assumption and the
    # feed's reality are two statements that must agree rather than one repeated.
    code_col = mo.get("code_column")
    code_system = mo.get("code_system")
    cats = codelist["categories"]
    if not cats:
        raise ValueError("treatment_categories has no categories")

    label_whens, code_whens = [], []
    for c in cats:
        pred = compile_match(c["match"], name_col, cat_col, code_col, code_system)
        label_whens.append(f"WHEN {pred} THEN {_sql_str(c['label'])}")
        code_whens.append(f"WHEN {pred} THEN {int(c['code'])}")

    label_sql = "CASE " + " ".join(label_whens) + " END"
    code_sql = "CASE " + " ".join(code_whens) + " END"
    return label_sql, code_sql
