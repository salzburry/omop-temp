"""Semantic QC for a built ADS — the layer the schema preflight can't cover.

Run AFTER build, before publishing. Reports the distributions reviewers asked for: date-castability,
mortality granularity + duplicate-conflict counts, unmapped stage ('CHECK'), unmatched treatment
(the catch-all rate), null-rates, and row/cohort counts.

`qc_spec(cfg)` is the pure-Python plan (unit-tested). `run_qc(spark, ads, cfg)` executes it on a
Spark DataFrame (cluster only). Nothing here writes data; it returns a report dict.
"""
from __future__ import annotations

# Sentinel labels the engine emits (a high rate of either is a data-quality smell): the treatment
# line-category catch-all and the staging fallthrough. Both are DERIVED from the EXACT config location
# the engine compiles from, so QC checks the label the engine actually emits and can't drift. When a
# tumor declares neither, the derivation returns None and QC SKIPS that check — it never substitutes a
# hardcoded guess, which could silently mismatch the emitted label and let a bad build pass.


def _catchall_label(cfg):
    """Label of the catch-all (`match: {always: true}`) row of the treatment LINE-CATEGORY codelist —
    the codelist the treatment pack NAMES (`line_category_codelist`) and the engine compiles into the
    per-line `lot{i}cat`. Not "the first codelist that happens to carry an always-row": a tumor with a
    second codelist (e.g. biomarkers) whose always-row has a different label must not hijack this.
    Returns None when no line-category codelist is declared (QC then skips the catch-all check)."""
    try:
        clname = (cfg.pack("treatment") or {}).get("line_category_codelist")
        if not clname:
            return None
        for cat in cfg.codelist(clname).get("categories", []):
            if (cat.get("match") or {}).get("always"):
                return cat.get("label")
    except Exception:  # noqa: BLE001 - no treatment pack / codelist -> skip the check, don't guess
        return None
    return None


def _stage_check_label(cfg):
    """Label of the staging fallthrough group (`when: fallthrough` in clinical.staging), or None when
    the tumor declares no staging (QC then skips the unmapped-stage check rather than guessing 'CHECK')."""
    try:
        for g in (cfg.pack("clinical").get("staging") or {}).get("groups") or []:
            if g.get("when") == "fallthrough":
                return g.get("label")
    except Exception:  # noqa: BLE001 - no clinical pack / staging -> skip the check, don't guess
        return None
    return None


def qc_spec(cfg) -> dict:
    """The QC plan, derived from config so it adapts per tumor. Pure data, no Spark."""
    max_lines = 6
    try:
        max_lines = int(cfg.pack("treatment").get("max_lines", 6))
    except Exception:  # noqa: BLE001 - treatment pack optional for the plan
        pass
    return {
        "cohort_columns": ["cohort", "cohortn", "cohortu", "cohortun"],
        # categorical columns to show distributions for (only those present are used at runtime)
        "categorical": ["cohort", "agegrl", "regionl", "race", "eth", "ecog", "stage",
                        *[f"lot{i}cat" for i in range(1, max_lines + 1)]],
        # rate-of-sentinel checks
        "treatment_catchall": {"columns": [f"lot{i}cat" for i in range(1, max_lines + 1)],
                               "label": _catchall_label(cfg)},
        "stage_check": {"column": "stage", "label": _stage_check_label(cfg)},
        # date columns to test castability (logical -> the ADS column name)
        "date_columns": ["index_date", "dthdt", "fued", "advanceddiagnosisdate"],
    }


def run_qc(spark, ads, cfg) -> dict:
    """Compute the QC report for a built ADS DataFrame. Spark-side (cluster only).

    TWO ACTIONS, NOT THIRTEEN, and the shape is the point rather than the saving. Every number
    below except the cohort breakdown is a `sum(when(...))` over ONE scan of the same frame: the
    row count, every column's null count, the catch-all hits and their eligible denominators, the
    unmapped-stage count, and both halves of every date-castability ratio.

    It used to issue them separately — `ads.count()`, then a null-rate select, then a
    `filter().count()` per line column, then a stage filter, then TWO counts per date column. On a
    six-line pack with four date columns that is thirteen passes over one table to answer one
    question about it, and an external review measured roughly eighteen actions in this function.
    Each pass re-reads the ADS, and on a wide Delta table that is the dominant cost of QC.

    The cohort breakdown stays a separate `groupBy`, because it returns one row per cohort rather
    than one number, and folding a variable-cardinality result into a scalar aggregation would mean
    pivoting on values only known at runtime.
    """
    from pyspark.sql import functions as F

    spec = qc_spec(cfg)
    cols = set(ads.columns)
    report = {"version": cfg.version, "refresh": cfg.refresh}

    exprs = [F.count(F.lit(1)).alias("_n")]

    # NULL COUNTS, not rates: a rate needs the denominator, and the denominator is `_n` in this same
    # row. Summing here and dividing in Python keeps it to one pass and makes the division auditable.
    for c in ads.columns:
        exprs.append(F.sum(F.when(F.col(c).isNull(), 1).otherwise(0)).alias(f"null_{c}"))

    cat = spec["treatment_catchall"]
    catchall_cols = ([c for c in cat["columns"] if c in cols]
                     if cat.get("label") is not None else [])
    for c in catchall_cols:
        exprs.append(F.sum(F.when(F.col(c) == cat["label"], 1).otherwise(0)).alias(f"h_{c}"))
        # OVER ELIGIBLE ROWS, NOT OVER THE ADS. A patient with no third line has a NULL `lot3cat`,
        # so dividing line-3 catch-alls by every patient made the rate FALL as the untreated share
        # ROSE — the opposite of the taxonomy-gap signal `max_catchall_rate` is worded for.
        exprs.append(F.sum(F.when(F.col(c).isNotNull(), 1).otherwise(0)).alias(f"e_{c}"))

    sc = spec["stage_check"]
    stage_col = sc["column"] if (sc.get("label") is not None and sc["column"] in cols) else None
    if stage_col:
        exprs.append(F.sum(F.when(F.col(stage_col) == sc["label"], 1).otherwise(0)).alias("_stage"))

    date_cols = [c for c in spec["date_columns"] if c in cols]
    for c in date_cols:
        exprs.append(F.sum(F.when(F.col(c).isNotNull(), 1).otherwise(0)).alias(f"dnn_{c}"))
        exprs.append(F.sum(F.when(F.col(c).isNotNull() &
                                  F.to_date(F.col(c).cast("string")).isNull(), 1)
                           .otherwise(0)).alias(f"dbad_{c}"))

    row = ads.agg(*exprs).collect()[0]                                   # ACTION 1
    n = int(row["_n"] or 0)
    report["n_rows"] = n

    if "cohort" in cols:
        report["cohorts"] = {r["cohort"]: r["n"] for r in                # ACTION 2
                             ads.groupBy("cohort").agg(F.count(F.lit(1)).alias("n")).collect()}

    if n:
        rates = {c: round(int(row[f"null_{c}"] or 0) / n, 4) for c in ads.columns}
        report["null_rate"] = {c: v for c, v in rates.items() if v}

    if catchall_cols:
        tr, elig = {}, {}
        for c in catchall_cols:
            e = int(row[f"e_{c}"] or 0)
            elig[c] = e
            # None, not 0.0: a line nobody reached has no catch-all RATE, and 0.0 would read as
            # "we classified them all correctly".
            tr[c] = round(int(row[f"h_{c}"] or 0) / e, 4) if e else None
        report["catchall_rate"] = tr
        report["catchall_eligible"] = elig          # the denominator, so the rate can be audited
        report["catchall_label"] = cat["label"]

    if stage_col and n:
        report["stage_check_rate"] = round(int(row["_stage"] or 0) / n, 4)
        report["stage_check_label"] = sc["label"]

    dc = {}
    for c in date_cols:
        d, bad = int(row[f"dnn_{c}"] or 0), int(row[f"dbad_{c}"] or 0)
        if d and bad:
            dc[c] = round(bad / d, 4)
    if dc:
        report["uncastable_date_rate"] = dc

    return report


# The column the LOT preflight asks about. Here rather than in the offline SQL generator because
# the EXECUTING check and the paste-ready SQL must ask the same question of the same column.
LOT_SETTING_COLUMN = "linesetting"


def source_expectations(cfg) -> dict:
    """{topic: {source, column, expected, declared_in}} — the value strings the derivations branch on.

    Read from the config, never from prose, so the check compares against what the build will
    actually do. A value the feed spells differently does not fail a build — it silently matches
    nothing and the column comes back empty or Unknown; these are the checks that find that BEFORE
    a person is reduced to reading DISTINCT results out of a SQL editor. `source_preflight.py`
    renders the same expectations as paste-ready SQL for the no-cluster day; this is the one
    derivation both read.
    """
    out = {}
    clin = cfg.pack("clinical")
    bio = clin.get("biomarkers") or {}
    if bio.get("panel") and bio.get("name_column"):
        out["biomarker_names"] = {
            "source": "biomarkers", "column": str(bio["name_column"]),
            "expected": sorted({m for p in bio["panel"] for m in (p.get("match_any") or [])}),
            "declared_in": "variables/clinical.yaml#/biomarkers panel[].match_any"}
    lv = clin.get("lab_values") or {}
    if lv.get("panel") and lv.get("name_column"):
        out["lab_names"] = {
            "source": "lab", "column": str(lv["name_column"]),
            "expected": sorted({str(p.get("match")) for p in lv["panel"] if p.get("match")}),
            "declared_in": "variables/clinical.yaml#/lab_values panel[].match"}
    settings = sorted({str(c.get("line_setting")) for c in (cfg.cohorts or [])
                       if c.get("line_setting")})
    if settings:
        out["line_settings"] = {
            "source": "lot", "column": LOT_SETTING_COLUMN, "expected": settings,
            "declared_in": "config/data_product.yaml#/cohorts[].line_setting"}
    return out


def _distinct_lower(spark, cfg, source, column, pins=None):
    """The DISTINCT lower-cased values of one column across every table a source resolves to.

    Reads through `sources._read`, honouring the SAME pins the build uses — source QC inspecting a
    version the build never reads was the recorded-but-not-inspected half of the snapshot rule."""
    from functools import reduce

    from pyspark.sql import functions as F
    from .stages import sources as _sources
    frames = [_sources._read(spark, f, pins) for f in cfg.source_fqns(source)]
    df = reduce(lambda a, b: a.unionByName(b, allowMissingColumns=True), frames)
    cols = {c.lower(): c for c in df.columns}
    for phys, logical in (cfg.source_renames.get(source) or {}).items():
        if phys.lower() in cols:
            cols[logical.lower()] = cols.pop(phys.lower())
    if column.lower() not in cols:
        raise KeyError(f"{source} carries no column {column!r}")
    return {str(r[0]).strip().lower()
            for r in df.select(F.col(cols[column.lower()])).distinct().collect()
            if r[0] is not None}


def run_source_qc(spark, cfg, pins=None) -> dict:
    """Pre-build QC on raw sources: mortality granularity, duplicate-conflict counts, and the
    VOCABULARY the derivations branch on (`source_expectations`) checked against what the feed
    actually spells. Verdict material only: the missing values named here are the CONFIG's own
    strings; what the feed holds beyond them is a count, never a value."""
    from pyspark.sql import functions as F

    report = {}
    vocab = {}
    for topic, exp in source_expectations(cfg).items():
        entry = {"declared_in": exp["declared_in"], "expected": len(exp["expected"])}
        try:
            observed = _distinct_lower(spark, cfg, exp["source"], exp["column"], pins=pins)
            wanted = {e.lower(): e for e in exp["expected"]}
            entry["missing_expected"] = sorted(wanted[k] for k in wanted if k not in observed)
            entry["found"] = len(wanted) - len(entry["missing_expected"])
            entry["unexpected_count"] = len(observed - set(wanted))
        except Exception as e:  # noqa: BLE001 — a diagnostic may not die of what it diagnoses
            entry["error"] = str(e)
        vocab[topic] = entry
    if vocab:
        report["vocabulary"] = vocab
    try:
        from functools import reduce
        # Read mortality the SAME way sources.load does — union all member schemas (so it works under a
        # source_union where run.source_schema is unused), lower-case, then apply any format renames —
        # so the engine sees the same rows the build will, not a placeholder-schema lookup via cfg.table.
        from .stages import sources as _sources
        mort = reduce(lambda a, b: a.unionByName(b, allowMissingColumns=True),
                      [_sources._read(spark, f, pins) for f in cfg.source_fqns("mortality")])
        for c in mort.columns:
            if c != c.lower():
                mort = mort.withColumnRenamed(c, c.lower())
        for phys, logical in (cfg.source_renames.get("mortality") or {}).items():
            p, lo = phys.lower(), logical.lower()
            if p in mort.columns and p != lo:
                mort = mort.withColumnRenamed(p, lo)
        dod = F.col("dateofdeath").cast("string")
        report["mortality_granularity"] = {
            str(r["len"]): r["n"] for r in
            mort.groupBy(F.length(dod).alias("len")).agg(F.count(F.lit(1)).alias("n")).collect()}
        dups = (mort.groupBy("patientid").agg(F.countDistinct("dateofdeath").alias("d"))
                    .filter(F.col("d") > 1).count())
        report["patients_with_conflicting_death_dates"] = dups
    except Exception as e:  # noqa: BLE001
        report["mortality_qc_error"] = str(e)
    return report


def source_qc_evidence(cfg, report: dict, gate: dict, generated_at=None, git_commit=None) -> dict:
    """Wrap run_source_qc() + its gate into a machine-readable evidence object — the stable input
    `source_check --preflight` folds into a pack's committed verdict report. Verdict material only:
    the values named are the CONFIG's own strings; everything vendor-observed is a count. Pure data;
    the runner supplies generated_at + git_commit (this module imports no clock/git)."""
    return {
        "kind": "source_qc",
        "result": "passed_live" if gate.get("passed") else "failed_live",
        "data_product_id": cfg.data_product_id,
        "spec_version": cfg.spec_version,
        "data_refresh": cfg.refresh,
        "source_schema": cfg.source_schema,
        "git_commit": git_commit,
        "generated_at": generated_at,
        "report": report,
        "gate": gate,
    }


# --- QC gate: turn a run_qc() report into a pass/fail decision (pure Python) -----------------
DEFAULT_THRESHOLDS = {
    "min_rows": 1,                 # the ADS must not be empty
    "max_catchall_rate": 0.50,     # >50% of lines hitting "Any other therapy" = taxonomy gap
    "max_stage_check_rate": 0.05,  # >5% stage == 'CHECK' = unmapped staging values
    "max_uncastable_date_rate": 0.01,  # date columns should be ~fully castable
}


def qc_thresholds(cfg) -> dict:
    """Merge the framework defaults with an optional per-tumor `qc:` block in config."""
    t = dict(DEFAULT_THRESHOLDS)
    t.update((cfg.raw.get("qc") or {}).get("thresholds", {}) if cfg is not None else {})
    return t


def qc_gate(report: dict, thresholds: dict | None = None) -> dict:
    """Evaluate a run_qc() report against thresholds. Returns {passed, failures}. Pure data."""
    t = thresholds or DEFAULT_THRESHOLDS
    failures = []
    if report.get("n_rows", 0) < t["min_rows"]:
        failures.append(f"n_rows {report.get('n_rows', 0)} < min_rows {t['min_rows']}")
    for col, rate in (report.get("catchall_rate") or {}).items():
        if rate is not None and rate > t["max_catchall_rate"]:
            failures.append(f"{col} catch-all rate {rate} > {t['max_catchall_rate']}")
    scr = report.get("stage_check_rate")
    if scr is not None and scr > t["max_stage_check_rate"]:
        lbl = report.get("stage_check_label") or "unmapped-stage"   # the derived fallthrough label, not 'CHECK'
        failures.append(f"stage {lbl!r} rate {scr} > {t['max_stage_check_rate']}")
    for col, rate in (report.get("uncastable_date_rate") or {}).items():
        if rate > t["max_uncastable_date_rate"]:
            failures.append(f"{col} uncastable-date rate {rate} > {t['max_uncastable_date_rate']}")
    return {"passed": not failures, "failures": failures}


def source_qc_gate(source_report: dict, thresholds: dict | None = None) -> dict:
    """Gate the PRE-BUILD source QC (run_source_qc). Fails on an unreadable mortality source, or on
    more than `max_death_conflicts` patients with conflicting death dates (None = don't gate on it,
    since the engine dedupes deterministically — but a real read error always fails)."""
    t = {"max_death_conflicts": None, "max_missing_expected": 0, **(thresholds or {})}
    failures = []
    if source_report.get("mortality_qc_error"):
        failures.append("mortality source not readable: " + source_report["mortality_qc_error"])
    mc = source_report.get("patients_with_conflicting_death_dates")
    if t["max_death_conflicts"] is not None and mc is not None and mc > t["max_death_conflicts"]:
        failures.append(f"{mc} patients with conflicting death dates > {t['max_death_conflicts']}")
    # VOCABULARY, fail-closed by default: a configured value the feed does not spell is a derivation
    # that will silently match nothing — empty column, not error — so it stops the build here, where
    # the fix is one config edit, rather than surfacing as an inexplicable Unknown downstream. An
    # unreadable expectation is a failure outright, like the mortality read error above.
    for topic, entry in sorted((source_report.get("vocabulary") or {}).items()):
        if entry.get("error"):
            failures.append(f"{topic}: expectation not checkable — {entry['error']}")
            continue
        missing = entry.get("missing_expected") or []
        if t["max_missing_expected"] is not None and len(missing) > t["max_missing_expected"]:
            failures.append(f"{topic}: {len(missing)} configured value(s) the feed does not spell "
                            f"({', '.join(missing[:6])}{'…' if len(missing) > 6 else ''}) — see "
                            f"{entry.get('declared_in')}")
    return {"passed": not failures, "failures": failures}
