"""PATIENT-LEVEL differential: did the same patients get the same values?

`golden.py` compares a new ADS against an approved reference on aggregates — row counts, cohort
counts, categorical counts, endpoint quantiles. Every one of those is INVARIANT UNDER A PERMUTATION
OF PATIENTS. Swap two patients' ECOG and the distribution is byte-identical; move a hundred
patients between stage groups and re-balance, and the counts still reconcile. An external review
put it exactly: "Two builds could retain the same aggregate counts while assigning incorrect values
to different patients."

So this pairs on the OUTPUT KEY and asks per patient.

    differential_spec(cfg)                        the plan. Pure data, no Spark.
    run_differential(spark, new, ref, cfg)        executes it. Cluster only.
    differential_gate(report, spec)               pass/fail. Pure data.

WHAT IT ADDS OVER AGGREGATES, and each one answers a question counts cannot:

  PAIRING            matched / only-in-new / only-in-ref. Inclusion and exclusion flips are
                     invisible in a total that happens to land in the same place: 40 patients in
                     and 40 out is a row-count delta of zero.
  TRANSITIONS        `ref value -> new value` with a count, for the pairs that CHANGED. The count
                     tells you how many moved; the matrix tells you where they went, which is what
                     distinguishes a re-mapped codelist from a genuine data refresh.
  PERCENTAGE POINTS, BY COHORT. `golden` reports the relative change of a count, pooled over the
                     product. A category going 10% -> 12% of a cohort is +2 POINTS; as a count
                     delta on a growing cohort it can read as +20% or as 0%, depending on the
                     denominator. And pooling hides the case that matters — a shift confined to
                     one cohort, cancelled by the opposite shift in another.
  NULL RATES         a join that silently drops to null changes no category count at all: the rows
                     leave the distribution instead of moving within it.
  NEW / DROPPED LEVELS a value that appears for the first time, or stops appearing. `summarise_diff`
                     already carries both sides, but a level arriving with `ref: 0` reads as a
                     count row rather than as the schema-level event it is.

THE APPROVED-DELTA LEDGER, and the one rule that makes it safe. A refresh is SUPPOSED to change
things, so a differential with no way to say "yes, that one" is a report everyone learns to skip.
`golden.approved_deltas` in config names the changes a person has already accepted. This module
READS that ledger and never writes it — the same rule `approval_baseline.yaml` carries, for the
same reason: a judge that can write its own exemption list is a check that can green itself.

DELIBERATELY NOT A REPLACEMENT FOR `golden.py`. Quantile and mean drift over an endpoint is a real
signal this does not compute, and the two answer different questions. This is the half that was
missing.
"""
from __future__ import annotations

from .output_contract import OUTPUT_KEY

# The pairing key IS the output key, imported rather than respelled. A second definition here would
# eventually disagree with the contract that enforces it, and the disagreement would decide which
# patients count as "the same patient" — silently.
PAIR_KEY = OUTPUT_KEY


def _declared(cfg, key, default):
    if cfg is None:
        return default
    try:
        return (cfg.raw.get("golden") or {}).get(key, default)
    except Exception:  # noqa: BLE001 - a config with no raw mapping declares nothing
        return default


def differential_spec(cfg) -> dict:
    """The plan: which columns are compared per patient, and which changes are pre-accepted."""
    return {
        "key": list(PAIR_KEY),
        # Columns to pair on. Empty means "every shared column", which is the honest default: a
        # differential that compared a hand-picked list would be silent about the column nobody
        # thought to add to it.
        "columns": list(_declared(cfg, "differential_columns", []) or []),
        "approved_deltas": list(_declared(cfg, "approved_deltas", []) or []),
        "max_transitions": int(_declared(cfg, "max_transitions_reported", 25)),
    }


def _shared_value_columns(new_cols, ref_cols, key, declared):
    """Columns present on BOTH sides and not part of the key."""
    shared = [c for c in new_cols if c in set(ref_cols) and c not in set(key)]
    if declared:
        want = set(declared)
        return [c for c in shared if c in want], sorted(want - set(shared))
    return shared, []


def run_differential(spark, new, ref, cfg=None) -> dict:
    """Pair a new ADS against a reference on the output key and report what moved.

    Returns a report dict; writes nothing.
    """
    from pyspark.sql import functions as F

    spec = differential_spec(cfg)
    key = [c for c in spec["key"] if c in new.columns and c in ref.columns]
    report = {"key": key, "compared": {}, "skipped": {}}
    if len(key) != len(spec["key"]):
        # NOT a skip that passes. Without the full key the pairing is not patient-level at all, and
        # a partial key would pair one patient's row against another's and call the difference a
        # change. Everything below is refused rather than approximated.
        report["skipped"]["pairing"] = (
            f"the output key {tuple(spec['key'])} is not present on both tables (usable: "
            f"{tuple(key)}) — patient-level pairing is impossible, and a partial key would pair "
            f"different patients and report the difference as a change")
        return report

    cols, missing = _shared_value_columns(new.columns, ref.columns, key, spec["columns"])
    report["compared"]["columns"] = len(cols)
    if missing:
        report["skipped"]["columns"] = missing
    # SCHEMA DELTA, because a comparison over shared columns cannot see a column that stopped
    # existing: a variable dropped from the new ADS simply paired on nothing and the report
    # stayed clean. Recorded on both sides; the gate fails reference-only losses.
    _new_cols, _ref_cols = set(new.columns), set(ref.columns)
    report["schema"] = {
        "new_only": sorted(c for c in _new_cols - _ref_cols if c not in set(key)),
        "ref_only": sorted(c for c in _ref_cols - _new_cols if c not in set(key)),
    }
    # KEY UNIQUENESS ON BOTH SIDES, before the join: pairing on a non-unique key multiplies
    # pairs, and a duplicated REFERENCE key corrupts every downstream count while looking like
    # a perfectly ordinary comparison.
    report["key_duplicates"] = {}
    for side, df in (("new", new), ("ref", ref)):
        dup = (df.groupBy(*key).count().filter(F.col("count") > 1).count())
        report["key_duplicates"][side] = int(dup)

    n = new.select(*key, *cols)
    r = ref.select(*key, *cols)
    # A MARKER COLUMN ON EACH SIDE, because presence cannot be inferred from the values: a patient
    # whose every compared value is null is still a patient, and `coalesce(...) IS NOT NULL` would
    # report them as absent from a build that contains them.
    n = n.select(*key, *[F.col(c).alias(f"n_{c}") for c in cols]).withColumn("_in_new", F.lit(True))
    r = r.select(*key, *[F.col(c).alias(f"r_{c}") for c in cols]).withColumn("_in_ref", F.lit(True))
    # A FULL OUTER JOIN, so the patients on one side only are part of the answer rather than
    # filtered out of it. An inner join here would make inclusion flips invisible, which is the
    # defect this module exists for.
    j = n.join(r, key, "full_outer").cache()

    pair = j.agg(
        F.sum(F.when(F.col("_in_new").isNotNull() & F.col("_in_ref").isNotNull(), 1).otherwise(0)).alias("matched"),
        F.sum(F.when(F.col("_in_ref").isNull(), 1).otherwise(0)).alias("only_new"),
        F.sum(F.when(F.col("_in_new").isNull(), 1).otherwise(0)).alias("only_ref"),
    ).collect()[0]
    report["paired"] = {"matched": int(pair["matched"]), "only_new": int(pair["only_new"]),
                        "only_ref": int(pair["only_ref"])}

    matched = j.filter(F.col("_in_new").isNotNull() & F.col("_in_ref").isNotNull())

    # ONE SCAN for every column's changed-pair count and both null counts. `<=>` is null-safe
    # equality: without it every null-to-null pair counts as a change and the report is noise.
    if cols:
        exprs = []
        for c in cols:
            exprs.append(F.sum(F.when(~F.col(f"n_{c}").eqNullSafe(F.col(f"r_{c}")), 1)
                               .otherwise(0)).alias(f"chg_{c}"))
            exprs.append(F.sum(F.when(F.col(f"n_{c}").isNull(), 1).otherwise(0)).alias(f"nn_{c}"))
            exprs.append(F.sum(F.when(F.col(f"r_{c}").isNull(), 1).otherwise(0)).alias(f"rn_{c}"))
        exprs.append(F.count(F.lit(1)).alias("_m"))
        row = matched.agg(*exprs).collect()[0]
        m = int(row["_m"]) or 0
        report["changed"] = {c: int(row[f"chg_{c}"] or 0) for c in cols
                             if int(row[f"chg_{c}"] or 0)}
        report["null_rate"] = {}
        for c in cols:
            nn, rn = int(row[f"nn_{c}"] or 0), int(row[f"rn_{c}"] or 0)
            if m and (nn or rn):
                report["null_rate"][c] = {"new": round(nn / m, 4), "ref": round(rn / m, 4),
                                          "delta": round((nn - rn) / m, 4)}
        report["matched_rows"] = m

    j.unpersist()
    return report


def transitions(spark, new, ref, column, cfg=None, limit=25) -> dict:
    """`ref value -> new value`: counts for the pairs of ONE column that changed.

    Separate from `run_differential` and one column at a time, deliberately. A transition matrix is
    a groupBy per column, so folding every column into the main pass would multiply its cost by the
    width of the ADS to answer a question a reader asks about two or three columns at most.
    """
    from pyspark.sql import functions as F
    spec = differential_spec(cfg)
    key = [c for c in spec["key"] if c in new.columns and c in ref.columns]
    if len(key) != len(spec["key"]) or column not in new.columns or column not in ref.columns:
        return {"column": column, "skipped": "column or output key missing on one side"}
    n = new.select(*key, F.col(column).alias("_n"))
    r = ref.select(*key, F.col(column).alias("_r"))
    j = n.join(r, key, "inner").filter(~F.col("_n").eqNullSafe(F.col("_r")))
    rows = (j.groupBy("_r", "_n").agg(F.count(F.lit(1)).alias("k"))
             .orderBy(F.col("k").desc(), F.col("_r").asc_nulls_first(), F.col("_n").asc_nulls_first())
             .limit(int(limit) + 1).collect())
    out = {f"{row['_r']} -> {row['_n']}": int(row["k"]) for row in rows[:int(limit)]}
    return {"column": column, "transitions": out,
            # NEVER a silent truncation. "the top 25" and "all of them" are different claims.
            "truncated": len(rows) > int(limit)}


def cohort_percentage_points(spark, new, ref, column, cohort_col="cohort", cfg=None) -> dict:
    """{cohort: {level: {new_pct, ref_pct, delta_pp}}} — proportions WITHIN each cohort.

    Points, not the relative change of a count, and per cohort rather than pooled. Both choices are
    the difference between a number a clinician can read and one that moves with the denominator.
    """
    from pyspark.sql import functions as F
    if any(c not in new.columns or c not in ref.columns for c in (column, cohort_col)):
        return {"column": column, "skipped": f"{column!r} or {cohort_col!r} missing on one side"}

    def _shares(df):
        g = df.groupBy(cohort_col, column).agg(F.count(F.lit(1)).alias("k"))
        tot = df.groupBy(cohort_col).agg(F.count(F.lit(1)).alias("t"))
        return {(row[cohort_col], str(row[column])): (row["k"] / row["t"]) if row["t"] else None
                for row in g.join(tot, cohort_col).collect()}

    ns, rs = _shares(new), _shares(ref)
    out = {}
    for coh, lvl in sorted(set(ns) | set(rs), key=lambda x: (str(x[0]), str(x[1]))):
        a, b = ns.get((coh, lvl)), rs.get((coh, lvl))
        out.setdefault(str(coh), {})[lvl] = {
            "new_pct": None if a is None else round(100 * a, 2),
            "ref_pct": None if b is None else round(100 * b, 2),
            # A level absent from one side is 0% there, not None: "it did not occur" is a
            # measurement, and treating it as unknown would hide exactly the level that appeared.
            "delta_pp": round(100 * ((a or 0.0) - (b or 0.0)), 2),
            "new_level": b is None,
            "dropped_level": a is None,
        }
    return {"column": column, "by_cohort": out}


def differential_gate(report: dict, spec: dict | None = None) -> dict:
    """{passed, failures, unapproved, skipped}. Pure data.

    A change is a FAILURE unless the approved-delta ledger names it. That is the right default for
    a refresh comparison: the reviewer's job is to accept changes one at a time, and a gate whose
    default is "probably fine" moves that job to nobody.
    """
    spec = spec or {}
    failures, unapproved = [], []
    # STRUCTURED APPROVALS. A bare column name approved ANY change to that column FOREVER —
    # an approval that outlives what it was given for. An entry is
    # a dict naming the column, the reason, the approver, the date, and an expiry; a bare
    # string is refused as a failure, and an expired approval stops approving. `expires` is
    # compared as an ISO date string against `spec["as_of"]` (the caller's run date) — the
    # comparison is skipped, visibly, when the caller states no as_of.
    # `as_of` defaults to TODAY: expiry was inactive on the real job path
    # because nothing injected the run date — an approval that never expires is the unbounded
    # approval this structure exists to end. Tests pin behaviour by passing as_of explicitly.
    from datetime import date as _date                                     # noqa: PLC0415

    def _not_iso(label, v):
        try:
            _date.fromisoformat(str(v))
            return None
        except ValueError:
            return f"{label} {v!r} is not a real ISO date (YYYY-MM-DD)"

    approved, caps = {}, {}
    as_of = str(spec.get("as_of") or _date.today().isoformat())
    bad_as_of = _not_iso("as_of", as_of)
    if bad_as_of:
        # a malformed run date makes every string comparison below meaningless — refuse it
        # rather than letting "31/12/2026" order arbitrarily against real ISO dates
        failures.append(bad_as_of)
    for entry in spec.get("approved_deltas") or ():
        if not isinstance(entry, dict):
            failures.append(f"approved_deltas entry {entry!r} is a bare name — a name approves "
                            f"any change forever; state column, reason, approved_by, "
                            f"approval_date and expires")
            continue
        need = [f for f in ("column", "reason", "approved_by", "approval_date", "expires")
                if not str(entry.get(f) or "").strip()]
        if need:
            failures.append(f"approved_deltas entry for {entry.get('column')!r} leaves "
                            f"{', '.join(need)} unstated — an approval is bounded or it is "
                            f"not an approval")
            continue
        col = str(entry["column"])
        # DATES THAT PARSE, not strings that compare: "2026-13-99" and "31/12/2026" both
        # string-compare against as_of and land wherever the characters happen to sort, so a
        # malformed expiry could keep approving forever. And an approval DATED IN THE FUTURE
        # has not been given yet — accepting it lets a record approve changes before its
        # approver's stated act.
        bad = (_not_iso(f"the approval for `{col}`: approval_date", entry["approval_date"])
               or _not_iso(f"the approval for `{col}`: expires", entry["expires"]))
        if bad:
            failures.append(bad)
            continue
        if not bad_as_of and str(entry["approval_date"]) > as_of:
            failures.append(f"the approval for `{col}` is dated {entry['approval_date']}, "
                            f"after the run date {as_of} — an approval dated in the future "
                            f"has not been given yet")
            continue
        # QUANTITATIVELY bounded, not just temporally: "changes to this column are approved"
        # with no magnitude approved a hundred thousand changed patients as readily as three.
        # The ceilings must also BE numbers in range — a nonnumeric ceiling used to raise an
        # uncontrolled ValueError at enforcement, and a rate above 1 can never bound anything.
        cap_rows, cap_rate = entry.get("max_changed_rows"), entry.get("max_changed_rate")
        if cap_rows is None and cap_rate is None:
            failures.append(f"the approval for `{col}` states no magnitude — "
                            f"declare max_changed_rows and/or max_changed_rate; an approval "
                            f"without a ceiling approves any size of change")
            continue
        try:
            cap_rows = None if cap_rows is None else int(cap_rows)
            cap_rate = None if cap_rate is None else float(cap_rate)
        except (TypeError, ValueError):
            failures.append(f"the approval for `{col}` has a nonnumeric ceiling "
                            f"(max_changed_rows={entry.get('max_changed_rows')!r}, "
                            f"max_changed_rate={entry.get('max_changed_rate')!r})")
            continue
        if any(isinstance(entry.get(k), bool) for k in ("max_changed_rows", "max_changed_rate")):
            failures.append(f"the approval for `{col}` states a boolean ceiling — "
                            f"true is not a magnitude")
            continue
        if (cap_rows is not None and cap_rows < 0) or \
                (cap_rate is not None and not 0 <= cap_rate <= 1):
            failures.append(f"the approval for `{col}` states an out-of-range ceiling — "
                            f"rows must be >= 0 and rate within [0, 1]")
            continue
        if str(entry["expires"]) < as_of:
            failures.append(f"the approval for `{col}` expired {entry['expires']} "
                            f"— its change is unapproved again until a person renews it")
            continue
        if col in approved:
            # two entries for one column is two different ceilings; last-wins would silently
            # pick whichever the YAML happened to order second
            failures.append(f"`{col}` is approved twice with possibly different bounds — "
                            f"keep exactly one entry per column")
            approved.pop(col)
            caps.pop(col, None)
            continue
        approved[col] = entry
        caps[col] = (cap_rows, cap_rate)

    if "pairing" in (report.get("skipped") or {}):
        return {"passed": False, "failures": [report["skipped"]["pairing"]],
                "unapproved": [], "skipped": report.get("skipped", {})}

    # SCHEMA AND KEY EVIDENCE FIRST — a corrupted pairing makes every later number noise.
    for side, dup in sorted((report.get("key_duplicates") or {}).items()):
        if dup:
            failures.append(f"the {side} table carries {dup} duplicated output key(s) — "
                            f"pairing on a non-unique key multiplies pairs and corrupts every "
                            f"count below")
    sch = report.get("schema") or {}
    for c in sch.get("ref_only") or []:
        # DELETION IS NOT A VALUE CHANGE. An approval bounding value changes (even to zero
        # rows) must not silently cover the column vanishing — a removal is approved only
        # when the entry SAYS removal, because losing a column changes every row at once.
        if c not in approved or not approved[c].get("removal"):
            failures.append(f"column `{c}` exists in the reference and is ABSENT from the new "
                            f"build — schema loss a shared-column comparison cannot see; "
                            f"an approved_deltas entry covers removal only when it states "
                            f"`removal: true`, or restore the column")
    for c in sch.get("new_only") or []:
        if c not in approved:
            unapproved.append(f"new column `{c}` (additive; name it in approved_deltas once a "
                              f"person accepts it)")
    if (report.get("skipped") or {}).get("columns"):
        failures.append(f"declared differential column(s) missing from one side, so their "
                        f"comparison never ran: {report['skipped']['columns']}")

    p = report.get("paired") or {}
    if p.get("only_ref"):
        failures.append(f"{p['only_ref']} patient(s) in the reference are absent from the new "
                        f"build — an exclusion flip, which a matching row TOTAL would hide")
    if p.get("only_new"):
        failures.append(f"{p['only_new']} patient(s) in the new build are absent from the "
                        f"reference — an inclusion flip")

    for col, k in sorted((report.get("changed") or {}).items()):
        m = report.get("matched_rows") or 0
        if col in approved:
            # the approval's CEILING is enforced, not just its existence: a change larger than
            # what the approver bounded is unapproved again, at its actual size
            cap_rows, cap_rate = caps[col]           # validated numbers, parsed once above
            if cap_rows is not None and k > cap_rows:
                failures.append(f"`{col}`: {k} changed patient(s) exceeds the approved ceiling "
                                f"of {cap_rows} — the approval covered a smaller change")
            elif cap_rate is not None and m and (k / m) > cap_rate:
                failures.append(f"`{col}`: {round(k / m, 4)} of matched patients changed, over "
                                f"the approved rate ceiling {cap_rate}")
            continue
        pct = f" ({round(100 * k / m, 2)}% of matched)" if m else ""
        unapproved.append(f"{col}: {k} paired patient(s) hold a different value{pct}")

    for col, d in sorted((report.get("null_rate") or {}).items()):
        if col in approved or not d.get("delta"):
            continue
        unapproved.append(f"{col}: null rate moved {d['ref']} -> {d['new']} "
                          f"({'+' if d['delta'] > 0 else ''}{d['delta']}) — rows leaving a "
                          f"distribution do not show up as a category change")

    return {"passed": not failures and not unapproved, "failures": failures,
            "unapproved": unapproved, "skipped": report.get("skipped", {})}
