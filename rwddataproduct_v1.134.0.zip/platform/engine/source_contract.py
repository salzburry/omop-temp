"""The compiled source contract: one typed answer per logical role, for every consumer.

An external review named the architectural hole this closes. The dependency walker
(`validate.referenced_sources`) sees roles a config names under `source:`/`line_source:` keys —
but the ENGINE also reads roles no config key names: `baseline_ecog`, `vitals`, the follow-up
sources, `visit_sources` entries, the LOT table itself. Those lived in `REQUIRED_COLUMNS` and in
per-feature hooks inside `required_columns()`, which is exactly why they never appeared in the
role-shaped reports: two walkers, two answers.

This module does not add a third walker. It COMPILES the existing owners into one record per
role, and consumers read the compiled record:

    availability          required | optional | unavailable_by_design (source_availability)
    declared / physical   the `sources:` entry, when one exists
    referenced_by_config  a config block names it (referenced_sources)
    engine_reads          the engine's own table or a feature hook requires/reads it
    required_columns      what preflight demands (required_columns — INCLUDING grain keys)
    optional_columns      configured optional reads (optional_columns)
    renames               the per-format physical->logical column overlay
    grain                 the declared unique key, when the pack makes that claim
    when_absent           what the build DOES if the role is missing — named, per family

`when_absent` is the honesty column: "the build fails at first read" and "the feature quietly
switches off" are different facts, and a reviewer deciding whether an absence is acceptable needs
to know which one they are accepting.

Pure data over cfg. No Spark, no filesystem beyond what cfg already loaded.
"""
from __future__ import annotations

from .validate import (required_columns, optional_columns, referenced_sources,
                       source_availability, source_grain, stage_reads)

_DEFAULT_ABSENT = "the build fails at first read (and the required-column floor names the role)"


def compiled(cfg) -> dict:
    """{"roles": {role: record}, "problems": [...]} — the one composition, from the owners.

    `when_absent` and the engine-guarded roles come from the STAGES' OWN typed reads
    (validate.stage_reads): the stage that performs an `if role in src` guard declares what
    absence does, so this module no longer keeps a hand-maintained registry beside the code it
    described — the registry and the guards could drift, and the guarded-role supplement below
    was a hardcoded set doing exactly that.
    """
    req = required_columns(cfg)
    opt = optional_columns(cfg)
    referenced = set(referenced_sources(cfg))
    avail, avail_problems = source_availability(cfg)
    grain, grain_problems = source_grain(cfg)
    reads, read_problems = stage_reads(cfg)
    # WHEN_ABSENT PRECEDENCE: a role with ANY required read hard-fails (or carries the required
    # read's own stated refusal) — a guarded read's degrade text must never claim its slot. An
    # adversarial review caught the first composition doing exactly that: the follow-up feeds'
    # "contributes nothing" text landed on lot/visit/telemed, whose absence actually refuses,
    # and the governed matrix told a reviewer a hard failure was a graceful degrade.
    required_roles = {r["role"] for r in reads if r["required"]}
    when_absent = {}
    for r in reads:                                   # explicit texts on REQUIRED reads first
        if r["required"] and r["when_absent"] and r["role"] not in when_absent:
            when_absent[r["role"]] = r["when_absent"]
    for r in reads:                                   # guarded texts only for guarded-only roles
        if not r["required"] and r["role"] not in required_roles \
                and r["role"] not in when_absent:
            when_absent[r["role"]] = r["when_absent"]
    guarded = {r["role"] for r in reads if not r["required"]}
    roles = sorted(set(cfg.sources) | referenced | set(req) | set(opt) | set(grain)
                   | set(avail) | guarded)
    out = {}
    for role in roles:
        declared = role in cfg.sources
        rec = {
            "declared": declared,
            "physical": cfg.sources.get(role),
            "referenced_by_config": role in referenced,
            "engine_reads": role in req or role in opt or role in guarded,
            "availability": dict(avail.get(role) or {"state": "required"}),
            "required_columns": sorted(req.get(role) or []),
            "optional_columns": sorted(opt.get(role) or []),
            "renames": dict(cfg.source_renames.get(role) or {}),
            "grain": list(grain.get(role) or []),
            "when_absent": when_absent.get(role, _DEFAULT_ABSENT),
        }
        # An ENGINE-GUARDED role nobody declared and no config references: visible as optional
        # with its degrade named, never a required/BLOCKED finding — the review's exact ask.
        if not declared and role not in referenced and role in guarded \
                and role not in avail:
            rec["availability"] = {"state": "optional",
                                   "reason": "engine-guarded feature — see when_absent"}
        out[role] = rec
    return {"roles": out,
            "problems": list(avail_problems) + list(grain_problems) + list(read_problems)}
