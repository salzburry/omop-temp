"""TFL (Tables, Figures, Listings) generation from a built ADS.

TFL specs (tfl/tfl_specs.yaml) describe the standard deliverables — Table 1 demographics by cohort,
treatment distribution, OS summary, patient listings — each referencing master-catalog variable
codes. `load_specs()` / `tfl_plan()` / `tfl_variables()` are pure-Python (which TFLs are producible
from a given ADS, and the catalog cross-check). `generate()` is the Spark/pandas producer
(cluster-only; review-only here).
"""
from __future__ import annotations

try:
    from .config import load_yaml
except ImportError:
    from config import load_yaml


def load_specs(path) -> dict:
    return load_yaml(path)


def tfl_variables(tfl: dict) -> list:
    """The catalog variable codes a single TFL references (for cross-checks)."""
    out = []
    for key in ("by", "time_to_event", "event"):
        if tfl.get(key):
            out.append(tfl[key])
    out += list(tfl.get("summarise", []) or [])
    out += list(tfl.get("columns", []) or [])
    out += list(tfl.get("where_columns", []) or [])    # columns the `where` SQL references
    return out


def tfl_required_vars(tfl: dict) -> list:
    """The HARD-required columns — those whose absence makes generate() ERROR (a `where`) or SKIP a
    figure (its `time_to_event`/`event`). `summarise` and listing `columns` are BEST-EFFORT (generate
    drops absent ones), so they're NOT required for producibility. This is what the TFL QC gate keys on,
    so a core table isn't failed just because an optional cross-tumor summarise column (e.g. OC `surg`)
    is absent for this product."""
    out = []
    for key in ("by", "time_to_event", "event"):
        if tfl.get(key):
            out.append(tfl[key])
    out += list(tfl.get("where_columns", []) or [])
    return out


def tfl_plan(specs: dict, available_columns, *, hard: bool = False) -> dict:
    """{tfl_id: [missing variables]} — an empty list means the TFL is producible from these columns.

    `hard=True` checks only the HARD-required columns (`tfl_required_vars`: a TFL is producible if it
    won't error/skip) — used by the QC gate. `hard=False` (default) checks ALL referenced variables
    (`tfl_variables`) for completeness reporting. Treats catalog `lotcat` as satisfiable by any per-line
    `lot<i>cat` the ADS emits.
    """
    vars_fn = tfl_required_vars if hard else tfl_variables
    avail = set(available_columns)
    plan = {}
    for t in specs["tfls"]:
        missing = []
        for v in vars_fn(t):
            if v in avail:
                continue
            if v == "lotcat" and any(c.startswith("lot") and c.endswith("cat") for c in avail):
                continue
            missing.append(v)
        plan[t["id"]] = missing
    return plan


def tfl_qc(specs: dict, plan: dict, *, generated=None, generated_at=None) -> dict:
    """The TFL QC gate result (governance/schemas/tfl_qc.schema.json). `plan` is tfl_plan() output
    ({id: missing_columns}). Skip semantics (doc §D): a NOT-applicable TFL -> ok; an applicable
    REQUIRED TFL that isn't produced -> failure; an applicable OPTIONAL one -> warning. The gate
    passes iff no TFL is `failure`. A spec may set `required: false` (default true) and `applicable:
    false` (default true); a missing plan entry is treated as not-producible.

    `generated` (optional) is the SET of TFL ids generate() ACTUALLY emitted. When given, a TFL is
    `produced` only if it is BOTH column-producible AND in `generated` — so a required TFL that
    generate() silently skipped (a table whose summarise columns were all absent, a listing with no
    kept columns) is a real `failure`, not a false `ok`. Pass it AFTER generate() for the real gate;
    omit it (pre-generate) to gate on column-producibility alone.
    """
    from datetime import datetime, timezone
    rows = []
    for t in specs.get("tfls", []):
        tid = t["id"]
        applicable = bool(t.get("applicable", True))
        required = bool(t.get("required", True))
        missing = plan.get(tid)
        producible = applicable and missing is not None and len(missing) == 0
        emitted = generated is None or tid in generated         # actually generated (if we know)
        produced = producible and emitted
        if not applicable:
            status, reason = "ok", "not applicable to this product"
        elif produced:
            status, reason = "ok", ""
        elif not producible:
            _r = f"not producible (missing: {sorted(missing or ['<unplanned>'])})"
            status, reason = ("failure", "required but " + _r) if required else ("warning", "optional, " + _r)
        else:   # column-producible but generate() emitted nothing for it
            _r = "column-producible but generate() emitted nothing (no rows / no kept columns)"
            status, reason = ("failure", "required: " + _r) if required else ("warning", "optional: " + _r)
        rows.append({"id": tid, "kind": t.get("kind"), "applicable": applicable,
                     "required": required, "produced": produced, "status": status, "reason": reason})
    return {"passed": all(r["status"] != "failure" for r in rows),
            "generated_at": generated_at or datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "tfls": rows}


def generate(spark, ads, specs, outdir=None) -> dict:
    """Produce each TFL from the ADS. Spark-side (cluster only). Returns {tfl_id: DataFrame}.

    - table:   count + denominator + percent by the `by` column, per `summarise` variable.
    - listing: the requested columns, one row per patient/index.
    - figure:  the product-limit (Kaplan-Meier) step table per cohort (time, n_at_risk, events,
               survival) via _km when an event flag is set; otherwise a per-cohort survival summary.
               Rendering the curve itself (e.g. lifelines/matplotlib) is the remaining client step.
    """
    from pyspark.sql import functions as F
    from functools import reduce

    out = {}
    cols = set(ads.columns)
    for t in specs["tfls"]:
        kind = t.get("kind")
        by = t.get("by")

        if kind == "table" and by in cols:
            # Resolve which summarise columns this ADS actually has (lotcat may map to lot1cat) and
            # confirm any `where`-referenced columns exist — BEFORE applying `where`. A TFL whose columns
            # aren't in this ADS (e.g. the OC-only platinum table on a prostate ADS) is simply skipped,
            # so its `where` can never error on an unresolved column.
            present = []
            for v in t.get("summarise", []):
                col = "lot1cat" if (v == "lotcat" and "lotcat" not in cols and "lot1cat" in cols) else v
                if col in cols:
                    present.append((v, col))
            if not present or any(c not in cols for c in (t.get("where_columns") or [])):
                continue
            # Optional TFL-level `where` (e.g. plat_sen_v1 IS NOT NULL) — applied BEFORE grouping so
            # structural-null rows (cohorts where the variable doesn't apply) don't skew the denominator.
            tdf = ads.filter(F.expr(t["where"])) if t.get("where") else ads
            denom = tdf.groupBy(by).agg(F.count(F.lit(1)).alias("denom"))
            frames = []
            for v, col in present:
                frames.append(
                    tdf.groupBy(by, col).agg(F.count(F.lit(1)).alias("n"))
                    .join(denom, by)
                    .withColumn("pct", F.round(100.0 * F.col("n") / F.col("denom"), 1))
                    .withColumn("variable", F.lit(v))
                    .withColumnRenamed(col, "value")
                    .select(by, "variable", "value", "n", "denom", "pct"))
            if frames:
                out[t["id"]] = reduce(lambda a, b: a.unionByName(b), frames)

        elif kind == "listing":
            keep = [c for c in t.get("columns", []) if c in cols]
            if keep:
                out[t["id"]] = ads.select(*keep)

        elif kind == "figure":
            tte, ev = t.get("time_to_event"), t.get("event")
            if tte in cols:
                grp = [by] if by in cols else []
                if ev and ev in cols:
                    out[t["id"]] = _km(ads, grp, tte, ev)          # product-limit KM step table
                else:                                              # no event flag -> survival summary
                    out[t["id"]] = (ads.filter(F.col(tte).isNotNull()).groupBy(*grp)
                                    .agg(F.count(F.lit(1)).alias("n"),
                                         F.expr(f"percentile_approx({tte}, 0.5)").alias("median"),
                                         F.round(F.avg(tte), 2).alias("mean")))
    return out


def _km(ads, grp, time, event):
    """Kaplan-Meier (product-limit) step table per group: time, n_at_risk, events, survival."""
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window

    sub = (ads.select(*grp, F.col(time).alias("t"), F.col(event).cast("int").alias("e"))
           .filter("t is not null"))
    agg = sub.groupBy(*grp, "t").agg(F.sum("e").alias("events"), F.count(F.lit(1)).alias("c"))
    risk = Window.partitionBy(*grp).orderBy(F.col("t").desc()).rowsBetween(
        Window.unboundedPreceding, Window.currentRow)
    agg = agg.withColumn("n_at_risk", F.sum("c").over(risk))           # subjects with time >= t
    surv = Window.partitionBy(*grp).orderBy(F.col("t").asc()).rowsBetween(
        Window.unboundedPreceding, Window.currentRow)
    agg = agg.withColumn("survival",
                         F.exp(F.sum(F.log(1 - F.col("events") / F.col("n_at_risk"))).over(surv)))
    return agg.select(*grp, F.col("t").alias("time"), "n_at_risk", "events",
                      F.round("survival", 4).alias("survival")).orderBy(*grp, "time")
