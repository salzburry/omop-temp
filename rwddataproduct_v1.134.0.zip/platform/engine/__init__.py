"""Prostate mCRPC RWDP engine.

Locked, config-driven code. Behaviour lives in config/, variables/ and codelists/ —
not here. The config layer (config.py, codelists.py) is pure Python and unit-tested;
the Spark stages (stages/) import pyspark lazily so this package imports without Spark.
"""
