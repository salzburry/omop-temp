"""Vendor adapters — resolve a logical source to a physical table per data vendor.

Tumors come from different vendors with different table layouts: Flatiron (solid tumors:
NSCLC/SCLC/mCRC/OC/EC/mCRPC) and COTA (heme: DLBCL, CLL, MDS). The engine stays vendor-agnostic;
the config's `vendor:` selects a layout template, and `run.source_layout:` can override it for a
vendor whose naming differs. Pure Python (no Spark) — easily unit-tested.

Template placeholders: {schema} {stem} {refresh}. Add a vendor here (or set source_layout in
config) when a new data source lands — no engine change elsewhere.
"""
from __future__ import annotations

DEFAULT_LAYOUTS = {
    # Flatiron: t_enh_<x>, t_demographics, … suffixed by the refresh cut. (Confirmed: prostate.)
    "flatiron": "{schema}.{stem}_{refresh}",
    # COTA heme curated datasets. verify-vs-source: confirm COTA's exact table layout; this is the
    # documented default and is overridable per product via run.source_layout.
    "cota": "{schema}.{stem}_{refresh}",
}


def layout_for(vendor: str, override: str | None = None) -> str:
    if override:
        return override
    if vendor not in DEFAULT_LAYOUTS:
        raise KeyError(
            f"no source layout for vendor '{vendor}'. Add it to engine/vendors.DEFAULT_LAYOUTS "
            f"or set run.source_layout in the config. Known: {sorted(DEFAULT_LAYOUTS)}")
    return DEFAULT_LAYOUTS[vendor]


def resolve(vendor: str, override: str | None, schema: str, stem: str, refresh: str) -> str:
    """Physical table name for (vendor, schema, stem, refresh)."""
    return layout_for(vendor, override).format(schema=schema, stem=stem, refresh=refresh)
