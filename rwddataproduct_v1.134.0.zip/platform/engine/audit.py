"""Consolidated release record — the immutable per-build evidence bundle (migration doc §F / §H step 4).

Pure Python (no Spark). After a publish, the runner copies a `releases/<family>/<product>/<spec_version>/
<refresh>/<build_id>/` bundle from the refresh manifest:

  release.json        the consolidated record (the manifest, schema = governance/schemas/release.schema.json)
  audit_report.md     a human-readable summary of that record
  source_qc.json      } the split QC artifacts, pulled out of the manifest so each is independently
  ads_qc.json         } readable / diffable
  golden.json         }
  tfl_qc.json         the TFL QC gate result (engine.tfl.tfl_qc — schema = governance/schemas/tfl_qc.schema.json)

`build_bundle()` returns the {filename: obj} mapping (unit-testable); `write_bundle()` writes it to a dir.
"""
from __future__ import annotations

import json
from pathlib import Path


def release_record(manifest: dict) -> dict:
    """The release.json content. Today this IS the manifest (already the consolidated record); kept as a
    distinct function so the release copy can diverge from the in-git manifest later without callers changing."""
    return dict(manifest)


def audit_report_md(manifest: dict) -> str:
    """A human-readable Markdown summary of a release record — the at-a-glance audit page."""
    m = manifest
    rel = m.get("release") or {}
    qc = m.get("qc") or {}
    gold = m.get("golden") or {}
    L = [
        f"# Release audit — {m.get('tumor', '?')} {m.get('spec_version', '?')} / {m.get('refresh', '?')}",
        "",
        f"- **Status:** {m.get('status', '?')}",
        f"- **Published at:** {m.get('published_at') or '(not published)'}",
        f"- **Data product:** {m.get('data_product_id', '?')}",
        f"- **Engine version:** {m.get('engine_version', '?')}",
        f"- **Git commit:** {m.get('git_commit') or '(none)'}",
        f"- **Build id:** {rel.get('build_id', '(none)')}",
        f"- **Output table:** {m.get('output_table', '?')}",
        f"- **Published ADS (versioned):** {rel.get('ads', '(none)')}",
        "",
        "## Counts",
        f"- total rows: {(m.get('counts') or {}).get('total_rows', '?')}",
        "",
        "## Gates",
        f"- QC: {'PASS' if qc.get('passed') else 'FAIL/none'}",
        f"- golden: {gold.get('reference', 'none')}",
        f"- TFL promotion: {'PASS' if (m.get('tfl_promotion') or {}).get('passed') else 'n/a'}",
    ]
    so = m.get("sign_off") or {}
    if so:
        L += ["", "## Sign-off", f"- released by: {so.get('released_by', '(unsigned)')}",
              f"- qc reviewed by: {so.get('qc_by', '(none)')}"]
    return "\n".join(L) + "\n"


def build_bundle(manifest: dict, tfl_qc: dict | None = None) -> dict:
    """The {filename: object} evidence bundle. Splits the QC artifacts out of the manifest so each is
    independently readable; `tfl_qc` is the engine.tfl.tfl_qc() result (optional)."""
    bundle = {
        "release.json": release_record(manifest),
        "audit_report.md": audit_report_md(manifest),
        "source_qc.json": manifest.get("source_qc") or {},
        "ads_qc.json": manifest.get("qc") or {},
        "golden.json": manifest.get("golden") or {},
    }
    if tfl_qc is not None:
        bundle["tfl_qc.json"] = tfl_qc
    return bundle


def write_bundle(manifest: dict, dest_dir, tfl_qc: dict | None = None) -> list:
    """Write the evidence bundle into dest_dir (the releases/.../<build_id>/ path). Returns written paths."""
    dest = Path(dest_dir)
    dest.mkdir(parents=True, exist_ok=True)
    written = []
    for name, obj in build_bundle(manifest, tfl_qc).items():
        p = dest / name
        if name.endswith(".md"):
            p.write_text(obj, encoding="utf-8")
        else:
            p.write_text(json.dumps(obj, indent=2, default=str), encoding="utf-8")
        written.append(str(p))
    return written
