# Functional contract — <tumour> <YYYYMM>

One row per output variable: what is REQUIRED (the spec's own words, machine-carried), the
drafter's interpretation (judgment fields), where the value comes from, and the evidence-fed
status axes. Records are written through `platform/tools/contract_record.py` — never by pasting
rows — and validated by `platform/tools/contract_lint.py`, whose invariants are the contract's
actual schema.

This file ships EMPTY on purpose: an empty contract is a true statement about a pack whose
drafting has not started, and the drafting tool appends the record table on the first
`--apply`. Replace `<tumour> <YYYYMM>` above when copying the template; everything else in this
file is the drafter's to write through the tool.
