# Engine gaps — approved requirements the build does not yet meet

One row per gap, with a stable ID. A contract record cites these by `gap_ids: [ID]`, and the shared lint
(`platform/tools/contract_lint.py`, I2) fails any citation of an ID that is not indexed here.

A gap is not a decision. The requirement is settled; the build has not caught up, or the delivered feed
cannot supply it. Invariant I9 exists for the second case: an `approved` requirement whose
implementation is `not_derivable` MUST name its gap, so an unbuildable requirement can never vanish
silently.

IDs are `G-<SHORT-NAME>` for engine work, or `B<n>` for a blocker on the delivered data.

A row says WHAT IS NOT MET, in the contract's own words — the requirement, not a task title. "ECOG
window is [-30,+7] but the engine applies [-30,0]" is a gap; "fix ECOG" is a ticket. Whether it is
closed by configuration or by engine work, who owns it and when it lands are all things that change;
the unmet requirement is what a contract record cites and what has to stay stable.

Every live register heads its key column `Gap ID` — keep that spelling. Gap IDs are read positionally
from the first cell, so a renamed header parses today and is the kind of divergence this repository
has been bitten by three times.

| Gap ID | What is not met |
|---|---|
