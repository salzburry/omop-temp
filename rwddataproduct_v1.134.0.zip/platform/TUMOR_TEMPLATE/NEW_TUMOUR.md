# Starting a new tumour

Copy this folder to `products/<family>/<slug>/<YYYYMM>/`, drop the specification in
`prog_spec/`, and make the edits below. Nothing else is needed to reach Gate 1.

A folder of documents is NOT a pack. Discovery is by shape: a directory becomes a pack when it carries
`source_refs.yaml`, `handoff/MATURITY.yaml`, `handoff/FUNCTIONAL_CONTRACT.md`,
`spec_pipeline/pipeline.conf` or `config/data_product.yaml`. Until one of those exists the gates do not
look at it — which is why dropping the spec in on its own does nothing, and why CI never has to be
edited to pick a new tumour up.

## The edits, in order

**1. `source_refs.yaml`** — replace `product`, `spec_version`, `path_or_link`, `document_id`,
`classified_by`, `classified_date`, and choose the `ai_classification`.

For a pack's FIRST registration, `platform/tools/source_refs_init.py` writes the file for you —
composing `product` and `spec_version` from the registry and the pack path, and validating against
the schema before it writes:

```bash
python3 platform/tools/source_refs_init.py products/<family>/<slug>/<YYYYMM> \
    --ai-classification <sponsor_ai_eligible|vendor_restricted|restricted_derived> \
    --classified-by "<your name>" --classified-date <YYYY-MM-DD>
```

It has NO default for those three, refuses a team name or a placeholder, and refuses to overwrite
an existing registration. The three it demands are the three no tool may infer; everything else it
knows. Note it also refuses a pack still sitting at the literal `YYYYMM` directory: a registration
records WHICH cut it governs, and the schema pins `spec_version` to six digits.

The classification is the AI boundary and is required at EVERY status. It follows the CONTENT's
provenance, never the folder: a sponsor-authored specification is `sponsor_ai_eligible`; anything
vendor-originated or vendor-derived is not, and an internally written document that quotes vendor
material inherits the restricted classification. See `governance/WORKFLOW.md` §"Eligibility".

If the approved workbook is not in hand, leave `status: pending`, say why in `why_provisional`, and
set `path_or_link` to a `TBD …` note or a link. A path that names somewhere in the repo must resolve —
Gate 1 checks that at every status, so a mistyped filename is caught at registration rather than
surfacing later as a pipeline fault.

**2. `spec_pipeline/pipeline.conf`** — set `TUMOR` to the slug and `SPEC_SOURCE_ID` to the
`material_id` the extractor should read. It names a material, never a path: that indirection is what
lets the spec folder move without touching the pipeline.

**3. `handoff/FUNCTIONAL_CONTRACT.md`** — replace `<tumour> <YYYYMM>` in the title. The file ships
empty on purpose (an empty contract is a true statement about a pack whose drafting has not
started); the record table itself is appended by `contract_record.py --apply`, never by hand.

**3. `handoff/MATURITY.yaml`** — leave both axes at `not_started` until the evidence exists. It is a
CLAIM, and each level is granted on the evidence named beside it.

**4. `governance/tumour_registry.yaml`** — add the slug to `families`. Without it the pipeline's
FOREIGN_TABLE scan resolves no tumour family and SILENTLY self-disables (the only trace is a NOTE
inside `SPEC_FINDINGS.txt`) — the scan that catches a copy-pasted row from another tumour's
workbook is exactly the one a new pack needs most.

**5. `products/activation.yaml` + the bundle** — add the pack's activation block
(`schedule_enabled: false`, plus `can_view` and `cluster_policy_id`), then regenerate the product
bundle: `python3 platform/tools/bundle_products.py`. Skipping either is three sequential CI
failures discovered one at a time.

**6. `products/registry.yaml`** — LAST, and as `status: scaffold`.

```yaml
- { code: <code>, name: "<Name>", slug: <slug>, vendor: <vendor>, tumor_class: <class>,
    status: scaffold, current_spec_version: "<YYYYMM>" }
```

The registry entry is checked against `config/data_product.yaml` IMMEDIATELY — the same commit
must set the config's `version:` to the pack's version and replace the `vendor:` and
`tumor_class:` placeholders, or `test_registry` fails on the mismatch. "Leave the config until
the contract exists" applies to the VARIABLES, never to those three identity fields.

The registry is what `engine.config.product_dir()` resolves for every DEFAULT product lookup, so an
entry is a claim that the pack can be built. Adding it early, or as `status: active`, points every
default lookup at a pack with no `config/data_product.yaml` — which does not fail once, it fails in
every suite that loads the default product, and each failure names the missing config file rather than
the registry line that caused it. Deleting a pack while the registry still called it current took 10 of
20 platform suites down and read as ten unrelated defects.

`product_gates --check-maturity` now refuses an `active` entry whose pack is not buildable, so the
error names the registry line. Promote to `active` only after the contract, the config and the pack's
own tests pass.

**Adding a new VERSION of an existing tumour** is the same rule: leave the old `current_spec_version`
alone, build the new pack alongside it, and move `current_spec_version` in the final promotion change
— never at the start.

## Then

```bash
python3 platform/tools/source_manifest.py <pack> --check      # Gate 1
bash platform/tools/run_spec_pipeline.sh <pack>               # extract → lint → coverage → scaffold
```

Gate 1 is pure Python and runs anywhere. `run_spec_pipeline.sh` is the ONLY bash in the workflow —
on a machine without it run `python3 platform/tools/run_spec_pipeline.py <pack>` — the `.sh`
is a one-line wrapper around exactly that. Or use the bash Git for Windows ships
(`& "C:\Program Files\Git\bin\bash.exe" platform/tools/run_spec_pipeline.sh <pack>`) or run the
same six calls by hand. `sandbox/new_tumour_start/START_HERE.md` §4 lists them in order, with the
PowerShell form.

Add `--check` only later, to ask whether those artifacts are still current: it regenerates into a temp
directory and byte-compares, writing nothing into the pack, so it is not how the first run is done.

The pipeline writes seven generated artifacts to `spec_pipeline/out/`. `SCAFFOLDED_RECORDS.md` holds
one record per specification row — that is the contract's shape (lint I16), not a starting point to be
grouped into families afterwards.

**Before the workbook conversation, read the reference shelf** —
`governance/reference/variable_inventory/INVENTORY.yaml` holds, in one file, a cross-tumour
master (`master:` — the core variables every tumour defines, with named parameter SLOTS such as
age bands and index convention) and a literature-derived overlay per tumour, each variable
carrying its engine coverage inline. It is `status: reference_only` — a drafting AID, never
a specification: it tells you what published RWD studies of this tumour typically define, so the
workbook discussion starts from a checklist instead of a blank page. A variable enters THIS product
only when RWB's approved workbook states it, and slot values come from that workbook into
`config/`, never from the shelf's examples. Its README says the rest.

Two tools turn the shelf into work you do not redo:

```bash
python3 platform/tools/inventory_coverage.py                # which engine family covers what;
                                                            #   the engine_gap list = scoping
python3 platform/tools/variables_scaffold.py <pack>         # parameter SKELETONS into
                                                            #   spec_pipeline/out/variables_scaffold/
```

The coverage map (`governance/reference/variable_inventory/COVERAGE.md`) says, per inventory
variable, whether an existing engine family computes it, existing config patterns express it, or
engine work is needed — so scoping the new tumour is a lookup. The scaffold emits the config
SHAPES for the families this tumour's overlay instantiates, every value the `REPLACE_ME` marker:
fill each from the approved workbook, copy into `variables/`, and note the build REFUSES any pack
value still carrying the marker — a half-filled skeleton cannot run.

**Register and approve the sanitized extraction before any drafting** — this step gates the whole
of Gate 2, including fully hand-written records: `spec_slice.py` and `contract_record.py` refuse to
supply spec evidence until the pack's `ai_extraction` artifact is registered
(`python3 platform/tools/source_manifest.py --register-ai-extraction <pack>` prints the block to
paste into `source_refs.yaml`) and a HUMAN sets its `status: reviewed` with their name and date.
The five `TODO` fields in the printed block are that person's to answer — the pack is deliberately
RED until they do. `sandbox/new_tumour_start/START_HERE.md` §4b walks the same step.

`config/`, `variables/` and `codelists/` are the Gate 4 half of the pack. They ship here so the shape
is visible: the root config is full of `REPLACE_ME`, and `variables/`/`codelists/` carry real seeded
values because a config of pure placeholders cannot be linted or executed. Leave all of it until the
contract exists. `MATURITY.yaml` saying `configuration: not_started` is what makes that honest.

## Gate 2's human loop — the instruments, so nobody hand-edits a register

Drafting fills `DECISIONS.md` with questions. Getting them ANSWERED is a loop with a tool at each
step, and every one of them exists because the delivery this framework was measured against did the
step by hand:

```bash
python3 platform/tools/precedents.py --for <pack>          # what other products hit before you start
python3 platform/tools/decision_report.py <pack>           # the questions, ranked by what each unblocks
python3 platform/tools/decision_packet.py <pack> --out q.html   # one page per question, for the answerer
python3 platform/tools/decision_record.py <pack> --forms   # one YAML answer form per OPEN decision
# ...the answerer types answer / answered_by / answer_date into the form, commits it...
python3 platform/tools/decision_record.py <pack> --apply   # transcribes the wave, prints the worklist
```

Send the packet, not the repository: the person answering decides, they do not edit markdown. The
filled forms stay committed — the register row indexes an answer, the form attests it.

## Gates 3–6

Gate 2 is where most of the work is, so this file used to stop there — and a new pack was left to
find the rest by reading tools. One row per remaining gate: the artifact it produces, the command
that produces it, the fields only a person can fill, and what closes it.

| Gate | Artifact | Command | Human fields | Closes when |
|---|---|---|---|---|
| **3** — source readiness | `handoff/SOURCE_VERDICTS.md` (or `SOURCE_VERDICTS.<member>.md` per union member) | **first** set the delivery bindings in `config/pipeline.yaml` (`run.refresh`, `run.source_schema` — unless a `source_union` names the member schemas — plus `run.data_format` / `run.source_layout` where they apply), then run the profile and schema check against **those same values**, then `source_check.py <pack> --profile <profile.tsv> --schema-validation <SCHEMA_VALIDATION.json> --complete --out handoff/SOURCE_VERDICTS.md` | `reviewed_by`, `review_date` in the generated front matter | every contract record's `source_mapping` is `human_confirmed` and its `dictionary_check` / `live_schema_check` / `data_profile_check` are off `not_run`. The profile and schema report are written OUTSIDE the checkout — `--out-dir` is required and refused inside it |
| **4** — executable configuration | the active config graph + `handoff/CONFIGURATION_APPROVAL.yaml` | author it (`platform/README.md` §"Add a tumor"), then `contract_binding.py <pack> --check` | `approved_by`, `approval_date`, `technically_reviewed_by`, both digests — copy `CONFIGURATION_APPROVAL.example.yaml` | the binder passes, every graph file is off `status: scaffold`, and the form's digests match the graph and the contract |
| **5** — validation | per-record `acceptance` + `status.validation`; at run level the refresh manifest's `qc`, `golden`, `source_qc`, `deliverables` | the pack's own tests (`product_gates.py --list-tests`), then a build | `status.validation` per record; the reviewer named at Gate 6 as `validated_by` | every approved record is `passed_test` or `passed_live`, or names a gap in `handoff/ENGINE_GAPS.md`. There is no separate Gate 5 form — the human exit is recorded on the Gate 6 approval, because a validation record with no build attached is a claim about nothing in particular |
| **6** — release | `handoff/RELEASE_APPROVAL.yaml` | a prod run stops before the swap and prints the two identifiers; a promotion run (`promote_build_id`) then publishes THOSE bytes, building nothing | `approved_by`, `approval_date`, `validated_by`, `validation_date`, `approved_build_id`, `approved_manifest_sha256` — copy `RELEASE_APPROVAL.example.yaml` | the promotion run completes: it verifies the approval names this build id + candidate-manifest digest, materialises the staged bytes and swaps the views. The operation EXISTS and is exercised against real Delta in CI; what is unproven is production SIT — no promotion has run on a Databricks cluster. See `products/OPERATIONS.md` §"Gate 6" |

**The delivery bindings come first, and they are not a governed edit.** A `--complete` verdict is an
approval record ABOUT a delivery, so the pack has to name one: with `refresh: REPLACE_ME` the tool
refuses, because there is nothing for the gate to hold constant afterwards. `config/pipeline.yaml`
sits OUTSIDE `config_bundle_sha256`, so filling it in needs no Gate 4 re-approval — that separation
is exactly what the environment split bought. Set it once, and run all three tools
(`run_product_profile.py`, `run_product_schema_check.py`, `source_check.py`) against those values:
the profile stamps what it measured, and the verdict refuses a profile from another cut or schema.
The same bindings are what a production run is later held to — an override that points the job at a
different delivery makes the run unpublishable, because the Gate 3 evidence covers the committed one.

Two more things about Gate 3 worth knowing before you start it, because both cost a day if you find
them late. The verdict generator implements the **data-profiler** evidence route; a vendor whose policy
declares the documentation route can be registered but has no verdict generator yet
(`governance/vendor_policy.yaml` decides which route applies, and fails closed on an unknown vendor).
And the profile is the only Gate 3 artifact that touches vendor data — nothing it produces may enter
the checkout.

Delete this file once the pack is set up.
