# R mirror of engine/vocabularies.py — the SAME coding-system registry and the SAME normalisation,
# so a code set written once means the same thing under both engines. Parity is enforced by
# platform/tests/test_r_parity.py, which compares this registry and `normalise` against the Python
# side over a hostile string set.
#
# See engine/vocabularies.py for what each field means and why. In particular: `strip_chars` is a
# CHARACTER STRIP and nothing more, which is not enough for NDC's 10- vs 11-digit forms — write an
# NDC code set in the form the feed delivers.

TEXT <- "text"

CODING_SYSTEMS <- list(
  text     = list(strip_chars = "",  hierarchical = FALSE),
  icd10cm  = list(strip_chars = ".", hierarchical = TRUE),
  icd9cm   = list(strip_chars = ".", hierarchical = TRUE),
  icdo3    = list(strip_chars = ".", hierarchical = TRUE),
  snomed   = list(strip_chars = "",  hierarchical = FALSE),
  rxnorm   = list(strip_chars = "",  hierarchical = FALSE),
  ndc      = list(strip_chars = "-", hierarchical = FALSE),
  atc      = list(strip_chars = "",  hierarchical = TRUE),
  hcpcs    = list(strip_chars = "",  hierarchical = FALSE),
  cpt      = list(strip_chars = "",  hierarchical = FALSE),
  loinc    = list(strip_chars = "",  hierarchical = FALSE)
)

SYSTEMS <- sort(names(CODING_SYSTEMS))
CODED <- setdiff(SYSTEMS, TEXT)

known <- function(system) as.character(system) %in% names(CODING_SYSTEMS)

is_coded <- function(system) known(system) && as.character(system) != TEXT

hierarchical <- function(system) {
  if (!known(system)) return(FALSE)
  isTRUE(CODING_SYSTEMS[[as.character(system)]][["hierarchical"]])
}

strip_chars <- function(system) {
  if (!known(system)) return("")
  as.character(CODING_SYSTEMS[[as.character(system)]][["strip_chars"]])
}

# Mirrors engine/vocabularies.py::normalise — trim, upper-case, then remove each declared character.
# `fixed = TRUE` throughout: a stripped character like "." is a literal, never a regex metacharacter.
normalise <- function(system, code) {
  out <- toupper(trimws(as.character(if (is.null(code)) "" else code)))
  chars <- strsplit(strip_chars(system), "")[[1]]
  for (ch in chars) out <- gsub(ch, "", out, fixed = TRUE)
  out
}
