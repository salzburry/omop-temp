# R mirror of engine/vendors.py — resolve a logical source to a physical table per data vendor.
#
# Tumors come from different vendors with different table layouts: Flatiron (solid tumors) and COTA
# (heme: DLBCL, CLL, MDS). The engine stays vendor-agnostic; the config's `vendor:` selects a layout
# template and `run.source_layout:` can override it. Pure (no IO) — parity with the Python version is
# enforced by tests/test_r_parity.py (via cfg_all_tables across both vendors).
#
# Template placeholders: {schema} {stem} {refresh}.

DEFAULT_LAYOUTS <- list(
  # Flatiron: <stem> suffixed by the refresh cut. (Confirmed: prostate.)
  flatiron = "{schema}.{stem}_{refresh}",
  # COTA heme curated datasets. verify-vs-source: confirm COTA's exact layout; overridable per
  # product via run.source_layout.
  cota     = "{schema}.{stem}_{refresh}"
)

layout_for <- function(vendor, override = NULL) {
  # Python: `if override:` — a non-empty override wins; None/"" falls through to the vendor default.
  if (!is.null(override) && length(override) == 1L && nzchar(override)) return(override)
  if (is.null(DEFAULT_LAYOUTS[[vendor]]))
    stop(sprintf(paste0("no source layout for vendor '%s'. Add it to vendors.R DEFAULT_LAYOUTS ",
                        "or set run.source_layout in the config. Known: %s"),
                 vendor, paste(sort(names(DEFAULT_LAYOUTS)), collapse = ", ")))
  DEFAULT_LAYOUTS[[vendor]]
}

# Physical table name for (vendor, schema, stem, refresh). Mirrors Python str.format on the template.
vendors_resolve <- function(vendor, override, schema, stem, refresh) {
  tmpl <- layout_for(vendor, override)
  tmpl <- gsub("{schema}",  as.character(schema),  tmpl, fixed = TRUE)
  tmpl <- gsub("{stem}",    as.character(stem),    tmpl, fixed = TRUE)
  tmpl <- gsub("{refresh}", as.character(refresh), tmpl, fixed = TRUE)
  tmpl
}
