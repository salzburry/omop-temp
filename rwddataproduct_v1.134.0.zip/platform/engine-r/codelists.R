# R mirror of engine/codelists.py — compiles the SAME treatment-category codelist to the SAME
# Spark SQL CASE strings, so the R and PySpark engines agree on the (most complex) shared logic.
# Parity with the Python version is enforced by platform/tests/test_r_parity.py.

# Load order: source("vocabularies.R") BEFORE this file. The code operators need the ONE
# coding-system registry (strip_chars / hierarchical), and duplicating an eleven-entry table here —
# the way .sql_str is duplicated in cases.R — would be a real drift hazard rather than a two-line
# one. run_rwdp.R sources it first, and the parity harness does the same.
#
# Mirrors engine/codelists.py::sql_str — see there for why BACKSLASHES are escaped as well as
# quotes, and cases.R::.q for why this exists twice on the R side.
.sql_str <- function(s) paste0("'", gsub("'", "''", gsub("\\", "\\\\", as.character(s), fixed = TRUE),
                                          fixed = TRUE), "'")

# Mirrors engine/codelists.py::normalised_code_sql — both sides of a code comparison are put into
# the same form by the SAME declared rule, or the comparison depends on how the feed punctuates.
.normalised_code_sql <- function(code_col, system) {
  expr <- sprintf("UPPER(TRIM(%s))", code_col)
  for (ch in strsplit(strip_chars(system), "")[[1]])
    expr <- sprintf("REPLACE(%s, %s, '')", expr, .sql_str(ch))
  expr
}

# == codelists.py LIST_OPERATORS. A bare string where a list belongs is the one YAML slip the two
# engines read DIFFERENTLY instead of failing: `code_prefix_any: I21` compiles here to the single
# prefix I21 and in Python to `LIKE 'i%' OR LIKE '2%' OR LIKE '1%'`, because Python iterates a string
# character by character. Same config, two cohorts, nothing red. Refused on both sides.
LIST_OPERATORS <- c("code_in", "code_prefix_any", "like_any", "all_of", "any_of")

# == codelists.py SEQUENCE_FIELDS. The same slip in the CLINICAL fields, which the operator-only
# check never covered: `from_equals_ci: positive` compiles in Python to
# `LOWER(col) IN ('p','o','s','i','t','i','v','e')` and here to `IN ('positive')`.
SEQUENCE_FIELDS <- c("from_prefixes", "from_equals_ci", "from_startswith_ci", "from_contains_ci",
                     "from_regex", "match_any", "priority", "units")

# == codelists.py sequence_error. Keyed on the FIELD, so a new list-valued field is covered by
# naming it above rather than by remembering every call site that iterates it.
sequence_error <- function(field, val) {
  if (is.list(val)) return(NULL)
  # A YAML sequence reaches R as a list or as an atomic vector; a SCALAR reaches it as length 1 and
  # not a list. `[I21]` parses to a list, so length-1 atomic here is the scalar slip.
  if (length(val) > 1L) return(NULL)
  sprintf(paste0("%s: '%s' is not a list. Write `%s: [%s]` — a bare value here is read ",
                 "character-by-character by the Python engine and as one whole value by R, so the ",
                 "two engines would build different cohorts from the same config without failing."),
          field, as.character(val), field, as.character(val))
}

list_operator_error <- function(op, val) {
  if (!(op %in% LIST_OPERATORS)) return(NULL)
  sequence_error(op, val)
}

compile_match <- function(match, name_col, cat_col, code_col = NULL, code_system = NULL) {
  if (!is.list(match) || length(match) != 1L)
    stop("each match needs exactly one operator")
  op <- names(match)[1]
  val <- match[[1]]
  why <- list_operator_error(op, val)
  if (!is.null(why)) stop(why)
  name <- sprintf("LOWER(%s)", name_col)
  cat  <- sprintf("LOWER(%s)", cat_col)

  if (op %in% c("code_in", "code_prefix_any")) {
    if (is.null(code_col) || !nzchar(as.character(code_col)))
      stop(sprintf("%s needs match_on.code_column", op))
    if (!known(code_system)) stop(sprintf("%s: unknown coding system", op))
    if (!is_coded(code_system))
      stop(sprintf("%s against match_on.code_system: %s", op, as.character(code_system)))
    norm <- .normalised_code_sql(code_col, code_system)
    if (op == "code_in") {
      if (length(val) == 0) stop("code_in needs at least one code")
      codes <- vapply(val, function(c) .sql_str(normalise(code_system, c)), "")
      return(sprintf("%s IN (%s)", norm, paste(codes, collapse = ", ")))
    }
    if (!hierarchical(code_system))
      stop(sprintf("code_prefix_any: %s identifiers are not hierarchical", code_system))
    if (length(val) == 0) stop("code_prefix_any needs at least one prefix")
    pre <- vapply(val, function(p) .sql_str(paste0(normalise(code_system, p), "%")), "")
    return(paste0("(", paste(sprintf("%s LIKE %s", norm, pre), collapse = " OR "), ")"))
  }

  if (op == "equals")
    return(sprintf("%s = %s", name, .sql_str(tolower(as.character(val)))))
  if (op == "like_any")
    return(paste0("(", paste(sprintf("%s LIKE %s", name, .sql_str(tolower(as.character(val)))),
                             collapse = " OR "), ")"))
  if (op == "regexp")
    return(sprintf("%s REGEXP %s", name, .sql_str(val)))
  if (op == "category_equals")
    return(sprintf("%s = %s", cat, .sql_str(tolower(as.character(val)))))
  if (op == "is_null")
    return(if (isTRUE(val)) sprintf("%s IS NULL", name_col) else "FALSE")
  if (op == "all_of")
    return(paste0("(", paste(vapply(val, compile_match, "", name_col, cat_col, code_col, code_system),
                             collapse = " AND "), ")"))
  if (op == "any_of")
    return(paste0("(", paste(vapply(val, compile_match, "", name_col, cat_col, code_col, code_system),
                             collapse = " OR "), ")"))
  if (op == "always")
    return(if (isTRUE(val)) "TRUE" else "FALSE")
  stop(sprintf("unknown match operator: %s", op))
}

compile_case <- function(codelist) {
  mo <- codelist[["match_on"]]
  name_col <- if (!is.null(mo[["name_column"]])) mo[["name_column"]] else "linename"
  cat_col  <- if (!is.null(mo[["drug_category_column"]])) mo[["drug_category_column"]] else "detaileddrugcategory"
  code_col <- mo[["code_column"]]
  code_system <- mo[["code_system"]]
  cats <- codelist[["categories"]]
  if (length(cats) == 0) stop("treatment_categories has no categories")

  label_whens <- character(0)
  code_whens <- character(0)
  for (c in cats) {
    pred <- compile_match(c[["match"]], name_col, cat_col, code_col, code_system)
    label_whens <- c(label_whens, sprintf("WHEN %s THEN %s", pred, .sql_str(c[["label"]])))
    code_whens  <- c(code_whens,  sprintf("WHEN %s THEN %s", pred, as.character(as.integer(c[["code"]]))))
  }
  list(label = paste0("CASE ", paste(label_whens, collapse = " "), " END"),
       code  = paste0("CASE ", paste(code_whens,  collapse = " "), " END"))
}
