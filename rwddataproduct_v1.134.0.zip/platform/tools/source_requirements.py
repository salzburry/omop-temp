#!/usr/bin/env python3
"""The source-requirement matrix — what each logical source must supply, and who says so.

    python3 platform/tools/source_requirements.py <pack>                 # the matrix, for a person
    python3 platform/tools/source_requirements.py <pack> --format json   # the same rows, for a tool
    python3 platform/tools/source_requirements.py <pack> --check         # non-zero on an undeclared role

GENERATED, NEVER MAINTAINED. Every fact here is read from an artifact that already owns it:

    logical role, physical stem     the pack's `sources:` map          (engine.config)
    required / optional columns     the engine's own derivation        (engine.validate.required_columns)
    which config blocks read a role the composed config graph          (contract_binding.governed_blocks)
    which VARIABLES need the role   contract records' implementation_refs -> those blocks
    the source_mapping status       each record's own status axis      (handoff/FUNCTIONAL_CONTRACT.md)

A hand-maintained copy of any of these would be the second implementation this repository keeps
refusing to have: right today, silently wrong after the first edit to the real one. An external
review asked for exactly this shape — "extend required_columns() into one structured source
contract used by all preflight and profiling tools rather than adding a parallel registry."

WHAT THE MATRIX SAYS that no single artifact said before:

  * the chain requirement -> block -> role -> physical stem -> required columns, in one row, per
    role — the question "which variables die if this table is missing" had no single answer;
  * a role a governed block READS that the pack never DECLARES. `sources.load` cannot load it,
    the engine skips the dependent output, and (per an external review of a live trial) the result
    quietly becomes null — the HER2 shape. That is a finding here, and `--check` refuses on it.

WHAT IT DOES NOT SAY, on purpose:

  * a GRAIN nobody declared. The pack's `source_grain:` block is the owner — a delivery fact RWP
    declares and `engine.grain.source_grain_report` checks against the rows — and a role without a
    declaration renders `(not declared)` rather than a guess.
  * whether a delivered table SEMANTICALLY satisfies a requirement. Schema presence is Gate 3's
    machine half; meaning is RWP's half. This matrix is the worklist for that review, not the review.

Read-only. stdlib + the repo's own tools; no Spark, no vendor data, no model.
"""
import argparse
import json
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)
sys.path.insert(0, os.path.join(ROOT, "platform"))

import contract_binding as cb                                        # noqa: E402
import contract_lint as cl                                           # noqa: E402
from engine.config import load_config                                # noqa: E402
from engine import validate as ev                                    # noqa: E402
from engine import source_contract                                   # noqa: E402

# The role-key vocabulary and the availability model are the ENGINE's — it is what skips when a
# role is missing — so both are imported, never restated. This file's own walk exists only to add
# per-FILE provenance (`variables/clinical.yaml#/biomarkers`) to roles the engine already knows.
ROLE_KEYS = ev.SOURCE_ROLE_KEYS


def _roles_in(value, out):
    """Every logical-role reference inside one governed block's parsed value, recursively."""
    if isinstance(value, dict):
        for k, v in value.items():
            if k in ROLE_KEYS and isinstance(v, str) and v.strip():
                out.add(v.strip())
            else:
                _roles_in(v, out)
    elif isinstance(value, list):
        for item in value:
            _roles_in(item, out)


def block_roles(product):
    """{`<file>#/<key>`: {role, ...}} for every governed block that names at least one role."""
    unreadable = {}
    blocks = cb.governed_blocks(product, cb.pack_yaml(product), unreadable)
    out = {}
    for ref, value in blocks.items():
        roles = set()
        _roles_in(value, roles)
        if roles:
            out[ref] = roles
    return out, unreadable


def record_claims(product):
    """{config ref: [(variable_id, source_mapping status), ...]} from the functional contract.

    Absent contract -> {} and the caller says so. An empty answer must not read as "no variable
    needs any source"; it means the requirement side has not been written yet.
    """
    path = os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(path):
        return None
    out = {}
    for block in cl.records(cl.read(path)):
        vid = (cl._scalar(block, "variable_id") or "").strip()
        status = cl._inline(block, "status") or ""
        m = re.search(r"source_mapping:\s*([A-Za-z_]+)", status)
        mapping = m.group(1) if m else "unstated"
        for ref in cl._list(block, "implementation_refs") or []:
            ref = ref.strip()
            if "#/" in ref:
                out.setdefault(ref, []).append((vid, mapping))
    return out


def matrix(product):
    """The rows, one per logical role, plus the findings that make `--check` refuse.

    Returns (rows, findings). Rows cover every role the pack DECLARES and every role a governed
    block READS — the union, because each side alone hides the other's defect: a declared role no
    block reads is dead config, and a read role never declared is the silent-null path.
    """
    cfg = load_config(os.path.join(product, "config", "data_product.yaml"))
    declared = dict(cfg.sources)                       # role -> physical stem
    roles_by_block, unreadable = block_roles(product)
    claims = record_claims(product)                    # None when no contract exists yet

    # ONE COMPILED CONTRACT, not five owner calls repeated here. `source_contract.compiled` is
    # the composition every consumer reads — an external review found the alternative: two
    # walkers, two answers, and the engine-guarded roles (baseline_ecog, vitals, the follow-up
    # sources) appearing in neither. Availability findings still come from the same function a
    # strict build runs, so this report and the build cannot disagree.
    sc = source_contract.compiled(cfg)["roles"]
    read_roles = {r for r, rec in sc.items() if rec["referenced_by_config"]}
    for roles in roles_by_block.values():
        read_roles |= roles
    avail, _ = ev.source_availability(cfg)             # for the (default) marker only

    findings = [f"config file will not parse: {rel} ({why})" for rel, why in unreadable.items()]
    findings += ev.availability_problems(cfg, strict=True)
    rows = []
    engine_only = {r for r, rec in sc.items()
                   if rec["engine_reads"] and not rec["declared"]
                   and not rec["referenced_by_config"]}
    for role in sorted(set(declared) | read_roles | engine_only):
        blocks = sorted(ref for ref, roles in roles_by_block.items() if role in roles)
        variables, statuses = [], set()
        for ref in blocks:
            for vid, mapping in (claims or {}).get(ref, []):
                variables.append(vid)
                statuses.add(mapping)
        rec = sc.get(role) or {}
        entry = rec.get("availability") or {}
        state = entry.get("state") or "required"
        row = {
            "role": role,
            "declared": role in declared,
            "availability": state + ("" if role in avail else " (default)"),
            "availability_reason": entry.get("reason"),
            "availability_decision": entry.get("decision_id"),
            "physical_stem": declared.get(role),
            "required_columns": rec.get("required_columns") or [],
            "optional_columns": rec.get("optional_columns") or [],
            "read_by_blocks": blocks,
            "required_by_variables": sorted(set(variables)),
            # worst-first, so one glance says how settled this role's mappings are. `unstated` is
            # listed, not hidden: a record with no source_mapping axis is a record nobody has judged.
            "source_mapping_statuses": sorted(statuses),
            # ALIVE NOW, and still never guessed: the pack's own `source_grain:` declaration is
            # the owner this column waited for. Absent declaration stays visibly absent.
            "expected_grain": (f"unique by ({', '.join(rec['grain'])})" if rec.get("grain")
                               else "(not declared)"),
            # what the build DOES if this role is missing — the honesty column the review asked
            # for: "fails at first read" and "feature switches off" are different acceptances
            "when_absent": rec.get("when_absent", ""),
        }
        rows.append(row)
    return rows, findings, claims is not None


def render(product, rows, findings, has_contract):
    W = 100
    line = "─" * W
    out = [line, f"  SOURCE-REQUIREMENT MATRIX — {os.path.relpath(product, ROOT)}", line,
           "  Generated from the pack's config, the engine's required_columns(), and the",
           "  functional contract. Nothing here is hand-maintained; regenerate, never edit.", ""]
    if not has_contract:
        out += ["  NO handoff/FUNCTIONAL_CONTRACT.md — `required by` is empty because the",
                "  requirement side has not been written, NOT because no variable needs these", ""]
    for r in rows:
        head = f"  {r['role']:<16} -> {r['physical_stem'] or '*** UNDECLARED ***'}"
        out.append(head)
        if r["required_columns"]:
            out.append(f"      required   {', '.join(r['required_columns'])}")
        if r["optional_columns"]:
            out.append(f"      optional   {', '.join(r['optional_columns'])}")
        if r["read_by_blocks"]:
            out.append(f"      read by    {', '.join(r['read_by_blocks'])}")
        if r["required_by_variables"]:
            out.append(f"      required by {len(r['required_by_variables'])} variable(s): "
                       + ", ".join(r["required_by_variables"][:8])
                       + (" ..." if len(r["required_by_variables"]) > 8 else ""))
        if r["source_mapping_statuses"]:
            out.append(f"      mapping    {', '.join(r['source_mapping_statuses'])}")
        out.append(f"      available  {r['availability']}"
                   + (f" — {r['availability_reason']} ({r['availability_decision']})"
                      if r.get("availability_reason") else ""))
        out.append(f"      grain      {r['expected_grain']}")
        out.append("")
    if findings:
        out += [line, f"  {len(findings)} finding(s):", ""]
        out += [f"   ! {f}" for f in findings]
        out.append("")
    return "\n".join(out)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("pack", help="e.g. products/oncology/prostate/202606")
    ap.add_argument("--format", choices=("text", "json"), default="text")
    ap.add_argument("--check", action="store_true",
                    help="exit non-zero on any finding — an undeclared-but-read role, or an "
                         "unparseable config file. The matrix itself is informational; these are not.")
    a = ap.parse_args(argv)
    product = os.path.abspath(a.pack)
    if not os.path.isfile(os.path.join(product, "config", "data_product.yaml")):
        sys.exit(f"{a.pack}: no config/data_product.yaml — the matrix is derived from the config "
                 f"graph, so a pack without one has nothing to derive from.")
    rows, findings, has_contract = matrix(product)
    if a.format == "json":
        print(json.dumps({"pack": os.path.relpath(product, ROOT), "has_contract": has_contract,
                          "rows": rows, "findings": findings}, indent=2))
    else:
        print(render(product, rows, findings, has_contract))
    return 1 if (a.check and findings) else 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
