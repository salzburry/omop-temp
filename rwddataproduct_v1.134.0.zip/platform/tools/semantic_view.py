#!/usr/bin/env python3
"""The tumour's semantic view — one conceptual layer, per-dataset implementations, ruled pooling.

    python3 platform/tools/semantic_view.py products/oncology/prostate/202606
    python3 platform/tools/semantic_view.py <pack> --format json
    python3 platform/tools/semantic_view.py <pack> --pooling rwpfs flatiron optum_mc

WHY THIS EXISTS. "Define a tumour-specific semantic view (cohorts + key variables + derivation
rules); each dataset gets its own implementation; everyone designs against the same spec." The
pack already IS that: the contract carries the variables and their derivations, the source
contract carries the implementation, the registry carries the vendor. This tool assembles the
view — and adds the one axis the pitch leaves out, which decides whether the idea is safe:
CROSS-DATASET EQUIVALENCE. Two implementations of one variable are not automatically the same
construct (EHR-documented progression vs claims-proxied progression), and a layer that maps
both to one name without saying so manufactures false comparability.

So pooling is FAIL-CLOSED: a (variable, source, source) pair has the state a ruling in
governance/EQUIVALENCE_RULINGS.yaml gives it, and NO ruling means NOT ESTABLISHED — do not
pool, route the question to RWB/RWP. Rulings are a named person's dated act; this tool reads
them and never writes one, exactly as the naming registry treats its rulings.
"""
import argparse
import json
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import contract_lint as cl                                                  # noqa: E402
import product_gates as pg                                                  # noqa: E402
from spec_extract import repo_relative                                      # noqa: E402

RULINGS = os.path.join(ROOT, "governance", "EQUIVALENCE_RULINGS.yaml")
VOCAB = ("same_construct", "accepted_proxy", "not_comparable")
# decision_id REQUIRED: the reasoning and its authentication surface live in the decisions
# register — an equivalence ruling floating free of it is a scientific position with no record
# of how it was reached.
NEED = ("variable", "source_a", "source_b", "ruling", "ruled_by", "ruling_date", "decision_id")


def rulings(path=RULINGS):
    """(accepted rulings, problems). Every refusal is a PROBLEM, never a silent not-count —
    a malformed ruling that quietly stopped counting would un-rule a pair nobody re-asked."""
    doc, err = pg.read_yaml(path)
    if err:
        return [], [f"{repo_relative(path)}: {err}"]
    good, problems = [], []
    for i, r in enumerate((doc or {}).get("rulings") or []):
        where = f"ruling[{i}]"
        missing = [f for f in NEED if not str(r.get(f) or "").strip()]
        if missing:
            problems.append(f"{where}: leaves {', '.join(missing)} unstated — a ruling names "
                            f"the variable, both sources, the word, the person and the date")
            continue
        if r["ruling"] not in VOCAB:
            problems.append(f"{where}: ruling {r['ruling']!r} is not in the vocabulary "
                            f"{VOCAB} — an invented word is not a ruling")
            continue
        why = pg.not_a_person(r["ruled_by"])
        if why:
            problems.append(f"{where}: ruled_by {r['ruled_by']!r}: {why}")
            continue
        why = pg.bad_date(r["ruling_date"])
        if why:
            problems.append(f"{where}: ruling_date {r['ruling_date']!r}: {why}")
            continue
        if r["ruling"] == "accepted_proxy" and not str(r.get("note") or "").strip():
            problems.append(f"{where}: accepted_proxy with no note — a proxy without its "
                            f"documented divergence is a same_construct claim wearing a hedge")
            continue
        # ONE ruling per (variable, pair): with duplicates, file order decided which won —
        # a silent arbitration nobody performed
        pair_id = (str(r["variable"]).lower(),
                   frozenset({str(r["source_a"]).lower(), str(r["source_b"]).lower()}))
        if any((str(g["variable"]).lower(),
                frozenset({str(g["source_a"]).lower(), str(g["source_b"]).lower()}))
               == pair_id for g in good):
            problems.append(f"{where}: duplicates an earlier ruling for `{r['variable']}` "
                            f"across {sorted(pair_id[1])} — two rulings on one pair is a "
                            f"conflict a person resolves, not an ordering the file decides")
            continue
        good.append(r)
    return good, problems


def pooling(variable, source_a, source_b, ruled=None):
    """The pair's state. A recorded ruling, or NOT ESTABLISHED — never a verdict of this tool's
    own. Order-insensitive: (flatiron, optum) and (optum, flatiron) are one question."""
    if ruled is None:
        ruled, _p = rulings()
    want = {str(source_a).lower(), str(source_b).lower()}
    v = str(variable).lower()
    for r in ruled:
        if (str(r["variable"]).lower() == v
                and {str(r["source_a"]).lower(), str(r["source_b"]).lower()} == want):
            return dict(r, state=r["ruling"])
    return {"state": "not_established", "variable": v,
            "sources": sorted(want),
            "question": f"Is `{v}` the same construct in {sorted(want)[0]} and "
                        f"{sorted(want)[1]}? Do not pool until RWP/RWB record the ruling in "
                        f"governance/EQUIVALENCE_RULINGS.yaml."}


def implementations(pack):
    """{dataset: source_status} — the datasets that implement this pack. The registry's vendor
    is the first; a SECOND arrives as a typed adapter set (config/source_adapters.yaml, its
    `dataset:` label) — which is exactly when the equivalence axis below goes live."""
    import source_adapter as sa                                             # noqa: PLC0415
    import source_manifest as sm                                            # noqa: PLC0415
    entry = pg.registry_entry(ROOT, repo_relative(pack)) or {}
    vendor = str(entry.get("vendor") or "unregistered").lower()
    impls = {vendor: {"source_status": sm.source_status(pack) or "unregistered"}}
    ad = sa.check(pack)
    if ad.get("state") == "checked" and ad.get("dataset"):
        ds = str(ad["dataset"]).lower()
        impls.setdefault(ds, {})["source_status"] = (
            "adapter with problems — fix before trusting" if ad["problems"]
            else "typed adapter declared")
    return impls


def view(pack):
    """The semantic view: every contract variable with its derivation, implementations, and
    equivalence posture. Absence is stated — a record with no derivation says so."""
    contract = os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(contract):
        sys.exit(f"no contract at {repo_relative(contract)} — a semantic view without the "
                 f"contract would be a list of names, which is not a semantic layer")
    impls = implementations(pack)
    ruled, problems = rulings()
    rows = []
    for block in cl.records(cl.read(contract)):
        vid = (cl._scalar(block, "variable_id") or "").strip()
        if not vid:
            continue
        out = cl._inline(block, "output")
        name = (cl._kv(out, "physical_name") or "").lower()
        pairs = []
        vendors = sorted(impls)
        for i, a in enumerate(vendors):
            for b in vendors[i + 1:]:
                pairs.append(pooling(name or vid.lower(), a, b, ruled))
        rows.append({
            "variable_id": vid,
            "name": name or "(no physical_name stated)",
            "type": cl._kv(out, "type") or "?",
            "name_status": cl._kv(out, "name_status") or "?",
            "derivation": (cl._scalar(block, "derivation")
                           or cl._inline(block, "derivation") or "").strip()
                          or "(the record states no derivation)",
            "implementations": impls,
            "equivalence": pairs,      # empty with one dataset — nothing to pool is not a pass
        })
    open_pairs = [p for r in rows for p in r["equivalence"] if p["state"] == "not_established"]
    return {"pack": repo_relative(pack), "implementations": impls,
            "variables": rows, "ruling_problems": problems,
            "open_equivalence_questions": len(open_pairs)}


def render(v):
    L = ["=" * 96,
         f"  SEMANTIC VIEW — {v['pack']}",
         f"  implementations: " + ", ".join(f"{k} ({d['source_status']})"
                                            for k, d in sorted(v["implementations"].items())),
         "=" * 96, ""]
    if v["ruling_problems"]:
        L += ["  RULING PROBLEMS (fix the file before trusting any pooling state):"]
        L += [f"    - {p}" for p in v["ruling_problems"]] + [""]
    for r in v["variables"]:
        L.append(f"  {r['variable_id']:<28} {r['name']:<24} {r['type']:<10} "
                 f"name_status: {r['name_status']}")
        L.append(f"      {r['derivation'][:150]}")
        for p in r["equivalence"]:
            if p["state"] == "not_established":
                L.append(f"      POOLING NOT ESTABLISHED across {p['sources']} — "
                         f"{p['question']}")
            else:
                L.append(f"      {p['state']} across [{p['source_a']}, {p['source_b']}] "
                         f"({p['ruled_by']}, {p['ruling_date']})")
    n2 = sum(1 for r in v["variables"] if len(r["implementations"]) > 1)
    L += ["", f"  {len(v['variables'])} variable(s); "
              f"{len(v['implementations'])} implementation(s); "
              f"{v['open_equivalence_questions']} open equivalence question(s)"
              + ("" if n2 else " (one dataset today — the axis activates with the second)"),
          "=" * 96]
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack")
    ap.add_argument("--format", choices=("text", "json"), default="text")
    ap.add_argument("--pooling", nargs=3, metavar=("VARIABLE", "SOURCE_A", "SOURCE_B"),
                    help="the ruled state (or NOT ESTABLISHED) for one variable across two "
                         "datasets")
    a = ap.parse_args(argv)
    if a.pooling:
        print(json.dumps(pooling(*a.pooling), indent=2, sort_keys=True))
        return 0
    v = view(a.pack)
    print(json.dumps(v, indent=2, sort_keys=True) if a.format == "json" else render(v))
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
