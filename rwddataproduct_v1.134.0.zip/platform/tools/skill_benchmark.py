#!/usr/bin/env python3
"""Does the drafting skill raise the questions an SME raised? — measured, not asserted.

    python3 platform/tools/skill_benchmark.py --build <pack> --fixture DIR --key FILE
    python3 platform/tools/skill_benchmark.py --score RAISED.yaml --key FILE
    python3 platform/tools/skill_benchmark.py --holdout-new HOLDOUT.yaml   # an INDEPENDENT key
    python3 platform/tools/skill_benchmark.py --seal HOLDOUT.yaml          # before any run

WHICH KEY DECIDES WHAT THE NUMBER MEANS. `--build` derives the key from the pack's OWN decision
register — the same programme whose drafting is being scored — so a number from it measures
AGREEMENT WITH THAT REGISTER and cannot measure independent recall, because the register is where
the questions came from. Every key now records `independence:` so a reader does not have to know
that. A HOLDOUT key is the other kind: an independent reviewer's questions, sealed before any run.
`--score` refuses an unsealed holdout key rather than scoring it with a caveat, because a number
printed with a warning gets quoted without one. No holdout key exists in this repository today.

THE CLAIM THIS EXISTS TO SETTLE. A reviewer who knows the tumour and reads the specification
independently will notice that a follow-up endpoint names one cap source and needs three, or that a
biomarker window states an interval and no date basis. The skill's four detectors — VERIFY_MARKER,
PLACEHOLDER, TRUNCATED, NO_TERMINAL_ELSE — are properties of the STRING: they fire when the spec's
author left a typographic trace. A rule that reads as a complete sentence and is under-determined for
the concept produces no trace at all.

So "the skill matches SME level" is a recall claim, and nobody has measured it. THIS DOES NOT MEASURE
IT EITHER, and the name of the output says so: it is ROW-OVERLAP SCREENING COVERAGE. Read the matching
paragraph below before quoting any number from it.

TWO PACKS ARE NOT TWO SPECIFICATIONS. Prostate 202606 and the 202607 fixture extract to
byte-identical rows — `extraction_digest` is the same on both — so running this against each measures
two decision REGISTERS over one specification and demonstrates nothing about a second spec, a refresh
or another tumour. That was quoted as a second-pack result; it was not one. The digest is written into
every key so the question can be asked instead of assumed.

THE ANSWER KEY IS ALREADY WRITTEN. `handoff/DECISIONS.md` on a drafted pack is a list of questions
accountable people raised against a real specification — the exact output an SME review produces. The
records citing each decision carry `spec_refs`, so every decision resolves to a set of spec rows
without anyone hand-labelling anything.

MATCHED ON ROWS, NEVER ON WORDING — AND THAT INFLATES THE NUMBER. A run "found" a decision if it
raised a question against a row that decision concerns. Comparing question TEXT would score
paraphrase, so rows are the only mechanical option, and a run that flags the right row for a
different reason has still stopped someone drafting a confident answer over an open question.

But it cannot tell that apart from detection, and the difference is not small. `MAXINDEX-DATE`
("4/31/2026 is not a real date") and `MAXINDEX-TUMOUR` ("this SCLC lag text is inside a prostate
spec") cite the same row; one IMPOSSIBLE_DATE finding credits both, and only the first was found.
An independent reviewer caught this being quoted as an SME-match score, and they were right.

So the result is a RANGE. The upper bound is the permissive count; the lower charges every group of
decisions sharing one finding on one row to a single detection. Every credit is printed with the
finding kind that produced it, so a reader can audit the ones that look thin instead of trusting the
total.

WHAT IT DOES NOT MEASURE. Precision is reported but not scored: a run that flags all 202 rows scores
perfect recall and is useless, so read both numbers. And a decision this harness cannot reach is
reported as UNREACHABLE rather than counted as a miss — an unciteable decision is a defect in the
key, and silently scoring it against the run would understate the skill for the register's fault.

THE DENOMINATOR IS COMPUTED, NEVER DECLARED. Reachability was a FIELD on the key — `bool(rows)` on a
built key, and a boolean the reviewer typed on a holdout one. Both are the party being measured
setting the denominator of its own score, and the built form was not even checking what it claimed:
a decision citing `clinical:9999`, a row no specification has ever had, counted as reachable and sat
in the denominator where no run could ever find it. `reachability()` now derives it by resolving
every cited row against the pack's extraction, and `--score` refuses a key whose pack has no
extraction rather than believing the key's own references.

THE KEY NEVER LIVES INSIDE THE FIXTURE, and `--build` refuses to write it there. The subject of a
benchmark reads the fixture; a key inside it measures whether the reader looked next door.

stdlib only (plus PyYAML).
"""
import argparse
import hashlib
import json
import os
import shutil
import sys
from pathlib import Path

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import contract_lint as cl                                                      # noqa: E402
import product_gates                                                            # noqa: E402
from spec_extract import repo_relative                                          # noqa: E402


def _extraction_rows(pack):
    """The pack's extracted specification rows, or None when it has no extraction.

    None and [] are DIFFERENT ANSWERS and every caller here depends on the difference: no extraction
    means nothing can be checked, an empty one means the specification contains no rows. Collapsing
    them is how an absence comes to read as a clean result.
    """
    # RESOLVED AGAINST THE REPO, not the process's working directory. A key records `pack` as a
    # repo-relative path — correctly, so the key is portable — and this joined it to the cwd. Run
    # from anywhere but the repo root (CI runs the suites from `platform/`) and the file was simply
    # not found, so the fixture-drift comparison returned "" and `key_errors` reported NOTHING: a
    # key scored against a specification that had moved underneath it, passing quietly. An absence
    # read as a clean result, and the exact failure this digest exists to make impossible.
    path = os.path.join(pack, "spec_pipeline", "out", "extracted.json")
    if not os.path.isabs(pack) and not os.path.exists(path):
        path = os.path.join(ROOT, pack, "spec_pipeline", "out", "extracted.json")
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as fh:
        return json.load(fh).get("rows") or []


def extraction_digest(pack):
    """sha256 over the pack's extracted specification ROWS, or "" when it has no extraction.

    THE KEY IS AN OPINION ABOUT ONE SPECIFICATION, and nothing recorded which. A decision is open
    because the spec of the day did not answer something; re-extract the workbook, have the answer
    appear, and the key still demands the question — so the run is marked wrong for correctly NOT
    raising it. That is the same failure `spec_digest` already prevents on a contract record, one
    artifact over, and the fix is the same: bind the judgment to the bytes it was made against.

    ROWS ONLY, deliberately. The `extraction` block carries the extractor version and target path,
    which move for reasons that are not the specification changing.
    """
    rows = _extraction_rows(pack)
    if rows is None:
        return ""
    return hashlib.sha256(json.dumps(rows, sort_keys=True).encode("utf-8")).hexdigest()


def spec_row_ids(pack):
    """Every `domain:row` id the pack's specification actually contains, or None with no extraction.

    THE SET A ROW REFERENCE IS CHECKED AGAINST. A key's `rows:` used to be believed: `reachable` was
    `bool(rows)`, so citing `clinical:9999` — a row no specification has ever had — made a decision
    reachable and put it in the denominator, where the run could never find it. On a holdout key the
    reviewer typed `reachable` themselves, which is worse: the party being measured setting the
    denominator of its own score.
    """
    rows = _extraction_rows(pack)
    if rows is None:
        return None
    return {str(r.get("item_id")) for r in rows if isinstance(r, dict) and r.get("item_id")}


# WHERE THE KEY'S OPINION CAME FROM, and what a score against it can therefore mean.
#
# `--build` derives the key from the pack's OWN `handoff/DECISIONS.md`. Those questions were raised
# by accountable people against a real specification, which is what makes the key worth having — and
# they were raised by the SAME PROGRAMME whose drafting the skill is meant to match. A score against
# it measures agreement with that register. It cannot measure whether an INDEPENDENT reviewer, who
# has never seen the register, would raise the same questions, because the register is where the
# questions came from. Every key now says which kind it is instead of leaving the reader to assume.
INDEPENDENCE = ("derived_from_own_register", "holdout_sme")
OWN_REGISTER_NOTE = (
    "this key came from the pack's OWN decision register — the same programme whose drafting is "
    "being scored. It measures agreement with that register, never independent SME recall")
HOLDOUT_NOTE = (
    "an INDEPENDENT reviewer's questions, sealed before any run was scored"
)
MARK = "REPLACE_ME"

HOLDOUT_TEMPLATE = f"""\
# A HOLDOUT KEY — an INDEPENDENT reviewer's questions, recorded before any run is scored.
#
# WHY THIS FILE IS NOT WRITTEN BY --build. A key built from a pack's own DECISIONS.md holds
# questions raised by the same programme whose drafting is being measured. Scoring against it
# answers "does the skill agree with this register", which is worth knowing and is not the claim
# anybody wants to make. The claim people want is "does the skill raise what an independent
# reviewer would raise", and only a reviewer who has never seen that register can answer it.
#
# HOW TO USE IT, in this order — the order is the whole point:
#   1. Give the reviewer the FIXTURE and nothing else. Not the register, not the contract, not this
#      file with anything in it.
#   2. They record their questions below, each against the specification rows it concerns.
#   3. Seal it: `--seal <this file>` writes `sealed_sha256` over the WHOLE key — reviewer, date,
#      pack, fixture digest and questions alike — and refuses to reseal.
#   4. ONLY THEN run the skill and score against it.
#
# A key sealed after the run it scores measures nothing: the answers could have been fitted to the
# run, and no reader can tell whether they were. `--score` refuses an unsealed holdout key rather
# than scoring it with a caveat, because a number with a caveat gets quoted without one.
#
# WHAT YOU WRITE, AND WHAT YOU MAY NOT. Fill the questions and the rows they concern. You do NOT
# declare whether a question is reachable, or whether its id leaked into the fixture — both are
# COMPUTED at scoring time, and both decide the DENOMINATOR of the score. A reviewer who could set
# them could drop every question the run got wrong and report perfect coverage over what was left.
#
# Every {MARK} is a person's to fill. NO AI MAY WRITE THE QUESTIONS OR THE REVIEWER'S NAME: the
# independence of the reviewer IS the measurement, and a generated holdout key measures the
# generator against itself.
independence: holdout_sme
pack: {MARK}                    # the pack the fixture was built from
fixture_digest: {MARK}          # `--digest <pack>` — the extraction rows the reviewer actually read.
                                # COMPARED at scoring time against the pack above: a key scored
                                # against a fixture built from a different specification is measuring
                                # a different exercise, and the field was previously never read.
sme: {MARK}                     # a NAMED person, not a team
reviewed_date: {MARK}           # YYYY-MM-DD — when they read it
shown: {MARK}                   # exactly what they were given, in one line
sealed_sha256: {MARK}           # written by --seal, AFTER the questions and BEFORE any run

decisions:
  {MARK}:                       # an id the reviewer chooses, e.g. SME-FUED-CAP
    question: {MARK}
    # `rows` is CHECKED against the pack's extraction. A row the specification does not contain
    # cannot be flagged by any run, so that question is reported UNREACHABLE and left OUT of the
    # denominator rather than scored against the run.
    rows: [{MARK}]              # e.g. [clinical:70, outcomes:12]
"""


def holdout_digest(doc):
    """sha256 over the WHOLE key in canonical form, minus the seal field itself.

    THE FIRST VERSION SEALED ONLY `decisions:`, which left the identity of the exercise unsealed:
    the pack, the fixture digest, the reviewer's name, the date and what they were shown could all
    be edited after the seal without disturbing it. A holdout key is a claim about WHO read WHAT and
    WHEN as much as about which questions they raised, so the seal covers all of it. Nothing is
    excluded but `sealed_sha256`, which cannot cover itself.
    """
    # Through `protocol_record._canonical`, the repository's ONE canonical form for a digested
    # subtree: mappings sorted, scalars stringified and whitespace-collapsed, list order preserved.
    # Sealing only `decisions:` meant every value was a string; sealing the whole key brings in the
    # YAML-parsed `reviewed_date`, which is a `datetime.date` and not JSON-serialisable. Writing a
    # second canonicaliser here is how two freeze digests come to disagree about the same document.
    import protocol_record                                                   # noqa: PLC0415
    payload = protocol_record._canonical(
        {k: v for k, v in (doc or {}).items() if k != "sealed_sha256"})
    blob = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def key_errors(doc, path):
    """[why this key may not be scored against], or [].

    A key derived from the pack's own register needs nothing beyond what --build writes. A HOLDOUT
    key carries a claim — that an independent person wrote these questions before seeing any run —
    and every part of that claim is checkable except the honesty of the person sealing it.
    """
    out = []
    mode = str(doc.get("independence") or "")
    if mode not in INDEPENDENCE:
        out.append(f"{path}: independence {mode or '(unstated)'!r} is not one of "
                   f"{list(INDEPENDENCE)} — a key that does not say where its opinion came from "
                   f"cannot be quoted, because the sentence a reader writes depends on it")
        return out
    if mode != "holdout_sme":
        return out

    decisions = doc.get("decisions")
    if not isinstance(decisions, dict) or not decisions:
        out.append(f"{path}: a holdout key with no decisions scores every run perfectly")
        return out
    for where in product_gates.marker_paths(doc, MARK):
        out.append(f"{path}: `{where}` still holds {MARK} — a holdout key is one person's reading, "
                   f"and a marker in it is the scaffold speaking in their place")
    why = product_gates.not_a_person(doc.get("sme"))
    if why:
        out.append(f"{path}: sme — {why}")
    bad = product_gates.bad_date(doc.get("reviewed_date"))
    if bad:
        out.append(f"{path}: reviewed_date {bad}")
    sealed = str(doc.get("sealed_sha256") or "")
    live = holdout_digest(doc)
    if product_gates.unstated(sealed):
        out.append(f"{path}: NOT SEALED. A holdout key sealed after the run it scores measures "
                   f"nothing — the questions could have been fitted to the run and no reader can "
                   f"tell. Seal it with --seal BEFORE running the skill.")
    elif sealed != live:
        out.append(f"{path}: sealed against {sealed[:12]}… and the key now hashes to "
                   f"{live[:12]}…. A holdout key is edited before it is sealed, never after — "
                   f"re-run the review, or restore what was sealed.")

    # THE FIXTURE THE REVIEWER ACTUALLY READ. The template records `fixture_digest` and the scorer
    # read `extraction_digest`, so the field was written, sealed, and never once compared: a key
    # could be scored against a fixture built from a different specification entirely and nothing
    # would say so. The two names are now one name, and it must match the pack it claims.
    want = str(doc.get("fixture_digest") or "")
    pack = str(doc.get("pack") or "")
    if pg_unstated(want):
        out.append(f"{path}: no fixture_digest — nothing ties these questions to the specification "
                   f"the reviewer was shown")
    elif not pack:
        out.append(f"{path}: fixture_digest {want[:12]}… names no `pack`, so it is bound to "
                   f"nothing — there is no specification to compare it against")
    else:
        # AN ABSENT DIGEST IS NOT A MATCHING ONE. `extraction_digest` returns "" for a pack that
        # does not exist or has no extraction, and `if now and …` read that as nothing to check —
        # so a key naming a nonexistent pack passed the one check that binds it to a
        # specification. The seal held; what it was a seal OF had gone.
        now = extraction_digest(pack)
        if not now:
            out.append(f"{path}: pack {pack!r} has no extraction to compare against, so the sealed "
                       f"fixture_digest cannot be checked. A key bound to a specification nobody "
                       f"can produce is not a holdout")
        elif want != now:
            out.append(f"{path}: reviewed a fixture extracting to {want[:12]}… and {pack} now "
                       f"extracts to {now[:12]}…. The specification moved after the review, so "
                       f"questions it has since ANSWERED would be scored against the run as misses.")

    # THE DENOMINATOR IS NOT THE REVIEWER'S TO SET. `reachable` and `leaked` both remove a question
    # from the set `score()` divides by, and both are COMPUTED — reachability from whether the cited
    # rows exist in the pack's extraction, leakage from `leaks()` against the fixture. A key that
    # carried either as a WRITTEN value could drop every question the run got wrong and report
    # perfect coverage over what was left: the one number this harness exists to produce, set by the
    # party being measured.
    #
    # `reachable` used to be REQUIRED here, as a boolean the reviewer typed. That was the defect
    # stated backwards — the check demanded the claim rather than refusing it.
    for did, v in sorted((doc.get("decisions") or {}).items()):
        if not isinstance(v, dict):
            out.append(f"{path}: decision {did!r} is not a mapping")
            continue
        for field, how in (("leaked", "against the fixture by `leaks()`"),
                           ("reachable", "from whether the cited rows exist in the extraction")):
            if field in v:
                out.append(f"{path}: decision {did!r} carries `{field}`, which is COMPUTED {how} at "
                           f"score time, never declared. It removes the question from the "
                           f"denominator, so declaring it lets the key's author set their own score")
        if not isinstance(v.get("rows"), list) or not v.get("rows"):
            out.append(f"{path}: decision {did!r} cites no `rows` — a question with no rows in the "
                       f"fixture cannot be found by any run, and counting it is scoring a run "
                       f"against something it was never shown")
    return out


# WHY A DECISION IS NOT SCORED. Both are gaps in the KEY, never faults of the run, so both are
# reported and neither counts as a miss.
NO_ROWS = "no record cites it"
NO_SUCH_ROW = "cites no row the specification contains"


def reachability(key, rows_present):
    """{decision_id: why it cannot be reached} — absent from the mapping means reachable.

    COMPUTED, never read off the key. `rows_present` is `spec_row_ids(pack)`; passing None is not
    allowed, because "the extraction is missing" is a reason to refuse to score rather than a reason
    to believe the key's own rows.
    """
    if rows_present is None:
        raise ValueError("reachability needs the specification's row ids — a key whose pack has no "
                         "extraction cannot have its row references checked, and believing them "
                         "instead is what put unfindable questions in the denominator")
    out = {}
    for did, v in (key or {}).items():
        rows = (v or {}).get("rows") or []
        if not rows:
            out[did] = NO_ROWS
        elif not (_expand(rows) & rows_present):
            out[did] = NO_SUCH_ROW
    return out


def pg_unstated(v):
    """`product_gates.unstated`, imported lazily so this module stays importable stdlib-only."""
    return product_gates.unstated(v)


def answer_key(pack):
    """{decision_id: {question, rows}} for every OPEN decision in a drafted pack.

    Built from the CONTRACT, not from the register's prose. `DECISIONS.md`'s Evidence column is free
    text — "(dataprep 6, clinical 20, outcomes 2/4)" — and parsing it would be a guess about a human's
    formatting. The records that CITE a decision already carry machine-checkable `spec_refs`, and that
    citation is itself governed by I2 and I11, so the mapping is maintained by the gates rather than
    by this file.
    """
    dec_text = cl.read(os.path.join(pack, "handoff", "DECISIONS.md"))
    rows_by_id = cl.decision_rows(dec_text)
    status = cl.decision_status(dec_text)
    open_ids = {d for d, s in status.items() if s == "OPEN"}

    cited = {}
    contract = os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    for block in cl.records(cl.read(contract)):
        refs = [r for r in (cl._list(block, "spec_refs") or []) if r and r != cl.NO_SPEC_ROW]
        for d in (cl._list(block, "decision_ids") or []):
            if d in open_ids and refs:
                cited.setdefault(d, set()).update(refs)

    key = {}
    for d in sorted(open_ids):
        # NO `reachable` FIELD. Whether a decision can be found by row is decided by `reachability()`
        # against the pack's extraction at score time — a decision no record cites, or one citing a
        # row the specification does not contain, is a gap in the KEY and is reported rather than
        # scored against the run. Writing it here would have made the denominator a stored claim,
        # editable afterwards by anyone holding the file.
        key[d] = {"question": (cl.cell(rows_by_id.get(d, {}), "Question") or "").strip(),
                  "rows": sorted(cited.get(d, ()))}
    return key


def _expand(refs):
    """`clinical:17-46` -> every row it spans, so a range and a single row compare on equal terms.

    Through `contract_lint`'s own expander: a second reading of a citation is how two files come to
    disagree about what `clinical:17-46` covers, and I16 already depends on that one answer.
    """
    out = set()
    for ref in refs or []:
        m = cl.SPEC_REF_RE.match(str(ref).strip())
        if not m:
            continue
        lo, hi = int(m.group(2)), int(m.group(3) or m.group(2))
        out.update(f"{m.group(1)}:{n}" for n in range(lo, hi + 1))
    return out


def score(raised, key, rows_present):
    """(summary, [per-decision]) — coverage over the decisions this key can reach.

    `rows_present` is `spec_row_ids(pack)` — the row ids the specification actually contains. It is
    REQUIRED, because the set it produces IS the denominator: reachability used to be a field on the
    key, so a decision citing a row no specification has ever had counted as reachable and sat in
    the denominator where no run could ever find it, and on a holdout key the reviewer typed the
    field themselves.
    """
    # ROW -> WHY IT WAS FLAGGED. The reason is carried through scoring so a credit can be AUDITED.
    # Row-level matching cannot tell "this row was flagged for THIS question" from "this row was
    # flagged for something else"; recording the reason does not fix that and does make it visible,
    # which is the difference between a number that can be checked and one that must be trusted.
    flagged, why_flagged = set(), {}
    for item in raised or []:
        rows = _expand(item.get("rows") if isinstance(item, dict) else [item])
        flagged |= rows
        kind = (item or {}).get("kind") if isinstance(item, dict) else None
        for r in rows:
            why_flagged.setdefault(r, set()).add(kind or "unstated")

    unreachable = reachability(key, rows_present)
    per, found, credited = [], 0, {}
    reachable = [d for d, v in key.items() if d not in unreachable and not v.get("leaked")]
    for d in sorted(key):
        v = key[d]
        if d in unreachable:
            per.append((d, "UNREACHABLE", [unreachable[d]]))
            continue
        if v.get("leaked"):
            per.append((d, "LEAKED", list(v["leaked"])[:2]))
            continue
        hits = sorted(_expand(v["rows"]) & flagged)
        found += bool(hits)
        shown = [f"{h} [{','.join(sorted(why_flagged.get(h, {'unstated'})))}]" for h in hits[:2]]
        per.append((d, "found" if hits else "MISSED", shown))
        for h in hits:
            credited.setdefault((h, frozenset(why_flagged.get(h, ()))), []).append(d)

    # PRECISION IS REPORTED, NEVER SCORED. A run that flags every row scores perfect recall and has
    # said nothing; a reader who sees only the recall figure would call that a pass.
    key_rows = set()
    for v in key.values():
        key_rows |= _expand(v["rows"])
    shared = sorted({tuple(sorted(ds)) for ds in credited.values() if len(ds) > 1})
    # THE FLOOR IS A CONSTRAINT PROBLEM, NOT A SUBTRACTION. Each group of decisions sharing one
    # finding on one row contains at most ONE real detection — but the groups OVERLAP, and
    # subtracting `len(g)-1` per group charges a decision twice for appearing in two of them.
    # `BIOMARKER-WINDOW` sits in two groups on this pack and could honestly be the real detection in
    # both, so the naive floor understates as badly as the row-matching ceiling overstates.
    #
    # Exact instead: the largest set of found decisions with at most one from each group. Brute
    # force over the decisions that appear in a group — a handful, and an approximation here would
    # be a third number nobody could check.
    grouped = sorted({d for g in shared for d in g})
    free = found - len(grouped)
    best = 0
    for mask in range(1 << len(grouped)):
        pick = {grouped[i] for i in range(len(grouped)) if mask >> i & 1}
        if len(pick) > best and all(len(pick & set(g)) <= 1 for g in shared):
            best = len(pick)
    strict = free + best
    return {"reachable": len(reachable), "found": found,
            "recall": round(found / len(reachable), 3) if reachable else None,
            "unreachable": len(unreachable),
            # SPLIT, because they are different defects with different owners. A decision no record
            # cites is a gap in the REGISTER; one citing a row the specification does not contain is
            # a wrong reference in the KEY, and only the second means somebody typed a row number
            # that never existed. Reported as one figure, the second hid inside the first.
            "unreachable_uncited": sum(1 for w in unreachable.values() if w == NO_ROWS),
            "unreachable_bad_rows": sum(1 for w in unreachable.values() if w == NO_SUCH_ROW),
            "leaked": sum(1 for d, v in key.items() if d not in unreachable and v.get("leaked")),
            "rows_flagged": len(flagged),
            "rows_flagged_outside_key": len(flagged - key_rows),
            # CROSS-CREDIT, made countable. One finding on one row cannot be the detection of two
            # different questions — `MAXINDEX-DATE` ("4/31/2026 is not a date") and `MAXINDEX-TUMOUR`
            # ("this SCLC lag text is in a prostate spec") share a row, and a single IMPOSSIBLE_DATE
            # credits both. The second credit is an artefact of matching by row.
            "shared_credit": shared,
            # A RANGE, NOT A POINT. Row matching cannot tell "flagged for THIS question" from
            # "flagged for something else on the same row", so a single figure is an upper bound
            # wearing the clothes of a measurement. The lower bound charges every shared credit to
            # one decision and calls the rest artefacts; the truth is between, and quoting the top
            # of the range as an SME-match score is the specific overstatement to avoid.
            "recall_strict": round(strict / len(reachable), 3) if reachable else None,
            "found_strict": strict}, per


# The pack files a DRAFTED pack accumulates, all of which discuss the decisions. Emptied rather than
# deleted: a missing register and an empty one are different states to every tool that reads them,
# and the point is a pack at the START of drafting, not a broken one.
DRAFTING_OUTPUT = ("handoff/FUNCTIONAL_CONTRACT.md", "handoff/DECISIONS.md",
                   "handoff/SPEC_QC_FINDINGS.md", "handoff/ENGINE_GAPS.md",
                   "handoff/RWB_QUESTIONS.md")
NARRATIVE = ("TEST_RUN.md", "DEV_SMOKE.md")


def build(pack, fixture, key_path):
    """A copy of the pack as it stood BEFORE anyone drafted into it, with the key written outside.

    THE FIRST VERSION SUBTRACTED THE DECISIONS AND ALL 21 SURVIVED ANYWAY. A drafted pack does not
    hold its questions in one place: the ids sit in `decision_ids`, and the QUESTIONS are woven
    through record `notes` ("drug_episode is not yet in the list and no study-end cap"), through
    `RWB_QUESTIONS.md`, `ENGINE_GAPS.md`, `SPEC_QC_FINDINGS.md` and the pack's own run write-ups.
    Removing the ids leaves the reasoning, which is the part that gives the answer away.

    So the fixture is not a drafted pack with holes punched in it — it is the pack at the state a
    first draft actually starts from: the specification, its extraction, the config, and empty
    registers. That is both leak-free and the honest scenario, because it is the job the skill is
    for. What survives is exactly what a drafter is given.

    The strip is VERIFIED, not assumed: `leaks()` re-reads the fixture and refuses to hand back a
    benchmark whose answers are inside its own fixture.
    """
    key_abs, fix_abs = os.path.abspath(key_path), os.path.abspath(fixture)
    if key_abs.startswith(fix_abs + os.sep):
        raise SystemExit(
            f"--key must not be inside --fixture. The run reads the fixture, so a key inside it "
            f"measures whether the reader opened the answers rather than whether it found them. "
            f"Put it beside the fixture, not in it.")
    key = answer_key(pack)
    if os.path.exists(fixture):
        raise SystemExit(f"{fixture} exists — name a fresh directory rather than merging into one.")
    shutil.copytree(pack, fixture, ignore=shutil.ignore_patterns("__pycache__"))

    for rel in DRAFTING_OUTPUT:
        path = os.path.join(fixture, *rel.split("/"))
        if not os.path.exists(path):
            continue
        # The HEADER survives — the first markdown table header and everything above it. A register
        # with no header is malformed, and the lint would report the fixture rather than the run.
        lines = cl.read(path).splitlines()
        head = next((i for i, l in enumerate(lines) if l.lstrip().startswith("|---")), None)
        kept = lines[:head + 1] if head is not None else lines[:1]
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write("\n".join(kept) + "\n")
    for rel in NARRATIVE:
        path = os.path.join(fixture, rel)
        if os.path.exists(path):
            os.remove(path)

    # WHAT STILL LEAKS IS EXCLUDED FROM THE SCORE, NOT DELETED FROM THE PACK.
    #
    # Two of these were not predictable and both are legitimate: `handoff/WORKFLOW.md` names CODE-ALIGN
    # in prose, and `variables/clinical.yaml` — the CONFIG — carries FUED-DEFINITION beside the rule
    # it blocks. The config is material a drafter is supposed to read, so stripping it would change
    # the scenario into one nobody works in, and refusing outright would make the tool unusable on
    # the only pack that has a real answer key.
    #
    # Finding a decision whose id the run could simply read proves nothing about noticing the
    # question, so those are dropped from the denominator and reported — the same treatment as a
    # decision no record cites. A benchmark that quietly counted them would flatter the skill.
    for d, files in leaks(fixture, key).items():
        key[d]["leaked"] = sorted(files)

    import yaml
    with open(key_path, "w", encoding="utf-8", newline="\n") as fh:
        yaml.safe_dump({"pack": repo_relative(os.path.abspath(pack), ROOT),
                        # SAYS WHAT IT IS. Without this a reader has no way to know the key came
                        # from the register the skill is being scored against, and "41% SME recall"
                        # is the sentence that gets written.
                        "independence": "derived_from_own_register",
                        "extraction_digest": extraction_digest(pack),
                        "decisions": key}, fh, sort_keys=True, allow_unicode=True)
    return key


def leaks(fixture, key):
    """{decision_id: {file}} for any decision id still readable inside the fixture. Empty is the pass.

    Checked over EVERY text file, not the ones that were stripped: the first strip cleaned the two
    files it knew about and the ids were in four others plus the pack's own write-ups. A cleaner that
    checks only what it cleaned always reports success.
    """
    import pathlib
    out = {}
    for path in pathlib.Path(fixture).rglob("*"):
        if not path.is_file() or path.suffix.lower() not in (".md", ".yaml", ".yml", ".json", ".txt"):
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        for d in key:
            if d in text:
                out.setdefault(d, set()).add(str(path.relative_to(fixture)))
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("--build", metavar="PACK", help="a drafted pack to derive the answer key from")
    ap.add_argument("--fixture", help="directory to write the stripped copy to (with --build)")
    # NOT `required`: --holdout-new, --seal and --digest have no key to name, and demanding a
    # throwaway path for them teaches people to pass /dev/null to a benchmark tool.
    ap.add_argument("--key", help="the answer key: written by --build, read by --score")
    ap.add_argument("--score", metavar="RAISED",
                    help="YAML `raised: [{rows: [clinical:70], question: ...}]` — what a run raised")
    ap.add_argument("--baseline", metavar="FIXTURE",
                    help="write the DETERMINISTIC baseline for a fixture: every row the spec lint "
                         "already marks. The floor any model-assisted run has to beat, and the "
                         "number to quote beside a run's — a run scoring 0.6 has added nothing if "
                         "the lint alone scores 0.6")
    ap.add_argument("--holdout-new", metavar="PATH",
                    help="scaffold a blank HOLDOUT key — an independent reviewer's questions, to "
                         "be filled by that person and sealed before any run is scored")
    ap.add_argument("--seal", metavar="PATH",
                    help="write `sealed_sha256` over a holdout key's `decisions:`. Refuses to "
                         "reseal a key that already carries one")
    ap.add_argument("--digest", metavar="PACK",
                    help="print a pack's extraction digest — what a holdout key records as the "
                         "specification its reviewer actually read")
    ap.add_argument("--unsettled-only", action="store_true",
                    help="with --baseline: count only the four UNSETTLED kinds — the rows that mean "
                         "`the spec does not contain the answer`. Without it, EVERY finding counts, "
                         "which is what a drafter is actually shown")
    a = ap.parse_args(argv)
    import yaml

    if a.digest:
        print(extraction_digest(a.digest))
        return 0

    if a.holdout_new:
        if os.path.exists(a.holdout_new):
            print(f"REFUSED — {a.holdout_new} exists. A holdout key is filled once and sealed; "
                  f"regenerating it discards the reading it recorded.", file=sys.stderr)
            return 1
        os.makedirs(os.path.dirname(os.path.abspath(a.holdout_new)), exist_ok=True)
        with open(a.holdout_new, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(HOLDOUT_TEMPLATE)
        print(f"wrote {a.holdout_new}")
        print("Give the REVIEWER the fixture and nothing else. They fill the questions; then "
              f"--seal {a.holdout_new}; only then run the skill and score.")
        return 0

    if a.seal:
        doc, err = product_gates.read_yaml(a.seal)
        if err or not isinstance(doc, dict):
            print(f"REFUSED — {err or 'not a mapping'}", file=sys.stderr)
            return 1
        if str(doc.get("independence") or "") != "holdout_sme":
            print("REFUSED — --seal is for a holdout key; a key built from a register needs no "
                  "seal, because nothing about it was written after a run", file=sys.stderr)
            return 1
        if not product_gates.unstated(doc.get("sealed_sha256")):
            print(f"REFUSED — {a.seal} is already sealed. A holdout key is edited before it is "
                  f"sealed, never after: reseal it and the seal proves nothing.", file=sys.stderr)
            return 1
        decisions = doc.get("decisions")
        if not isinstance(decisions, dict) or not decisions:
            print("REFUSED — no `decisions:` to seal", file=sys.stderr)
            return 1
        left = product_gates.marker_paths(doc, MARK)
        left = [w for w in left if not w.startswith("sealed_sha256")]
        if left:
            print("REFUSED — the key still holds markers at: " + ", ".join(left) +
                  "\n  Seal a reading, not a scaffold.", file=sys.stderr)
            return 1
        # The digest covers the WHOLE key, so it must be computed from the document as it will be
        # ON DISK once the seal line is written — with `sealed_sha256` excluded, which is what
        # `holdout_digest` does. Sealing only `decisions:` left the reviewer, the date, the pack and
        # the fixture identity free to change afterwards.
        digest = holdout_digest(doc)
        text = Path(a.seal).read_text(encoding="utf-8")
        Path(a.seal).write_text(text.replace(f"sealed_sha256: {MARK}",
                                             f"sealed_sha256: {digest}"), encoding="utf-8")
        # VERIFIED STRUCTURALLY, NOT ASSUMED FROM THE REPLACE. The edit is textual on purpose — the
        # template's comments are what tell the reviewer what they may and may not write, and a
        # yaml.safe_dump round-trip would delete every one of them. But a text replace that matches
        # nothing succeeds silently: reformat the marker line, or seal a key someone hand-wrote
        # without it, and this printed "sealed …" over a file it had not changed. So the file is
        # re-read as YAML and the seal must be there, and be the digest, or nothing was sealed.
        after, err = product_gates.read_yaml(a.seal)
        if err or not isinstance(after, dict) or str(after.get("sealed_sha256") or "") != digest:
            print(f"REFUSED — {a.seal} still does not carry `sealed_sha256: {digest}` "
                  f"({err or 'the seal line was not written'}). The key is UNSEALED; add the line "
                  f"by hand, or rewrite the key from --holdout-new and re-enter the reading.",
                  file=sys.stderr)
            return 1
        if holdout_digest(after) != digest:
            print(f"REFUSED — writing the seal changed what the key hashes to. Nothing but "
                  f"`sealed_sha256` may differ between the sealed and unsealed file; {a.seal} is "
                  f"not sealed.", file=sys.stderr)
            return 1
        print(f"sealed {a.seal} at {digest}")
        print("Only now run the skill and score against it.")
        return 0

    if a.baseline:
        if not a.key:
            ap.error("--baseline needs --key (where to write it)")
        # HAND-ROLLED THREE TIMES IN ONE SITTING, which is the signal it belongs here. Reproducing a
        # published number should not require anybody to rewrite the extraction from `lint.json`, and
        # the two variants below are not interchangeable — quoting one while meaning the other moved
        # this pack's score by 18 points.
        import json as _json
        with open(os.path.join(a.baseline, "spec_pipeline", "out", "lint.json"),
                  encoding="utf-8") as fh:
            findings = _json.load(fh)["findings"]
        rows = sorted({f["item_id"] for f in findings if f.get("item_id")
                       and (not a.unsettled_only or f.get("kind") in cl.UNSETTLED)})
        kinds = {}
        for f in findings:
            if f.get("item_id"):
                kinds.setdefault(f["item_id"], set()).add(f.get("kind") or "unstated")
        out = {"raised": [{"rows": [r], "kind": ",".join(sorted(kinds.get(r, ()))),
                           "question": "the spec lint already marks this row"} for r in rows]}
        with open(a.key, "w", encoding="utf-8", newline="\n") as fh:
            yaml.safe_dump(out, fh, sort_keys=False, allow_unicode=True)
        print(f"{len(rows)} row(s) marked by the lint "
              f"({'UNSETTLED only' if a.unsettled_only else 'every finding kind'}) -> {a.key}")
        return 0

    if a.build:
        if not a.fixture or not a.key:
            ap.error("--build needs --fixture and --key")
        key = build(a.build, a.fixture, a.key)
        rows_present = spec_row_ids(a.build)
        if rows_present is None:
            print(f"{a.build} has no extraction, so no row reference in the key can be checked "
                  f"against a specification. Run the spec pipeline before building a key.",
                  file=sys.stderr)
            return 1
        blocked = reachability(key, rows_present)
        print(f"fixture  {a.fixture}")
        print(f"key      {a.key}   {len(key)} open decision(s), "
              f"{len(key) - len(blocked)} reachable by spec row")
        print(f"\nRun the skill over every row of the fixture and record what it raises as\n"
              f"  raised:\n"
              f"    - rows: [clinical:70]\n"
              f"      question: the window is stated and the date basis is not\n"
              f"then: skill_benchmark.py --score raised.yaml --key {a.key}")
        return 0

    if not a.score:
        ap.error("one of --build, --score, --baseline, --holdout-new, --seal or --digest")
    if not a.key:
        ap.error("--score needs --key")
    # Through `product_gates.read_yaml`, the one reader: a malformed key or a raised-file whose root
    # is a string rather than a list is a REPORT, not a traceback out of a benchmark.
    key_doc, err = product_gates.read_yaml(a.key)
    if err or not isinstance(key_doc, dict) or "decisions" not in key_doc:
        raise SystemExit(f"{a.key}: not an answer key ({err or 'no `decisions`'})")
    # REFUSED, NOT CAVEATED. An unsealed holdout key could have been fitted to the run it scores,
    # and a number printed with a warning gets quoted without one.
    problems = key_errors(key_doc, a.key)
    if problems:
        for e in problems:
            print(f"  REFUSED {e}", file=sys.stderr)
        return 1
    mode = str(key_doc.get("independence") or "")
    key = key_doc["decisions"]
    # THE KEY IS AN OPINION ABOUT ONE SPECIFICATION, and until now nothing recorded which. A
    # re-extraction that ANSWERS a question leaves the key still demanding it, so the run is scored
    # wrong for correctly staying silent — the score drifts downward as the specification improves,
    # which is the exact opposite of what it is for. Reported, not fatal: an older key is still
    # informative if the reader knows it is old, and refusing outright would strand every key written
    # before this field existed.
    was = str(key_doc.get("extraction_digest") or key_doc.get("fixture_digest") or "")
    now = extraction_digest(str(key_doc.get("pack") or ""))
    stale = bool(was and now and was != now)
    if not was:
        stale_note = ("this key records no extraction digest, so nothing can say whether the "
                      "specification has moved under it")
    elif stale:
        stale_note = (f"STALE KEY — it was written against extraction {was[:12]}… and "
                      f"{key_doc.get('pack')} now extracts to {now[:12]}…. Questions the specification "
                      "has since ANSWERED are still in the key, and the run is marked wrong for not "
                      "raising them. Rebuild the key before quoting this number.")
    else:
        stale_note = ""
    # A SEPARATE NAME, because the same one was reused: `doc` was the key and then became the raised
    # run, so the holdout banner below printed the REVIEWER'S NAME out of the file the run produced.
    raised_doc, err = product_gates.read_yaml(a.score)
    if err or not isinstance(raised_doc, dict):
        raise SystemExit(f"{a.score}: {err or 'expected a mapping with a `raised:` key'}")
    raised = raised_doc.get("raised")
    if not isinstance(raised, list):
        raise SystemExit(f"{a.score}: expected `raised:` to be a list of questions, got "
                         f"{type(raised).__name__} — see --build's instructions for the shape")
    # THE DENOMINATOR NEEDS THE SPECIFICATION, so a key whose pack has no extraction is refused
    # rather than scored against its own unverified row references. Believing them is precisely the
    # failure this replaced: `reachable` was a field, and a row the spec never had counted.
    rows_present = spec_row_ids(str(key_doc.get("pack") or ""))
    if rows_present is None:
        print(f"  REFUSED {a.key}: pack {key_doc.get('pack')!r} has no extraction, so no row "
              f"reference in this key can be checked against a specification. Reachability decides "
              f"the denominator and is not the key's to assert.", file=sys.stderr)
        return 1
    summary, per = score(raised, key, rows_present)

    print("=" * 78)
    # NOT "SME-RECALL". The match is by affected ROW, so a finding of any kind on any row a decision
    # concerns scores that decision — which is coverage of the rows an SME's questions touched, not
    # recall of the questions. Naming it recall is what let "9/22 = 41% SME recall" be quoted, and
    # the number cannot support that sentence.
    print("  ROW-OVERLAP SCREENING COVERAGE — how much of what accountable people asked about")
    print("  was flagged, matched by affected specification row rather than by question")
    print("=" * 78)
    if mode == "holdout_sme":
        print(f"  KEY: holdout — {HOLDOUT_NOTE}")
        print(f"       reviewer {key_doc.get('sme')} on {key_doc.get('reviewed_date')}; "
              f"shown: {key_doc.get('shown')}")
    else:
        print(f"  KEY: {OWN_REGISTER_NOTE}.")
    print("-" * 78)
    if stale_note:
        print(f"  !! {stale_note}")
        print("-" * 78)
    for d, verdict, hits in per:
        mark = {"found": "ok  ", "MISSED": "MISS",
                "UNREACHABLE": "  - ", "LEAKED": "  ~ "}[verdict]
        print(f"  {mark} {d:26} {', '.join(hits) if hits else ''}")
    print("-" * 78)
    print(f"  coverage  {summary['found_strict']}-{summary['found']}/{summary['reachable']} = "
          f"{summary['recall_strict']}-{summary['recall']}")
    print("            the RANGE is the honest form: the upper bound credits a decision whenever a")
    print("            row it concerns was flagged, for any reason; the lower charges every shared")
    print("            credit to one decision. NEITHER is a recall figure — no step here compares")
    print("            what was asked to what the decision asks, so a row flagged for an unrelated")
    print("            reason scores. Quote it as screening coverage, and audit the credits above.")
    if summary["unreachable_uncited"]:
        print(f"  {summary['unreachable_uncited']} decision(s) no record cites — a gap in the "
              f"register, not scored against the run")
    if summary["unreachable_bad_rows"]:
        print(f"  {summary['unreachable_bad_rows']} decision(s) citing rows this specification does "
              f"not contain — a wrong reference in the KEY. No run can flag a row that is not "
              f"there, so they are not scored either; fix the key rather than reading past this")
    if summary["leaked"]:
        print(f"  {summary['leaked']} decision(s) whose id is readable in the fixture (config or "
              f"pack prose) — finding those proves nothing, so they are not scored either")
    print(f"  rows flagged {summary['rows_flagged']}, of which "
          f"{summary['rows_flagged_outside_key']} outside the key")
    for group in summary["shared_credit"]:
        print(f"  CROSS-CREDIT  {' and '.join(group)} share ONE finding on one row — at most one "
              f"of them was actually detected")
    print("\n  Read BOTH numbers. Flagging every row scores perfect recall and says nothing.")
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
