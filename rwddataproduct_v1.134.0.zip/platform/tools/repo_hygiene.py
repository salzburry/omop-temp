#!/usr/bin/env python3
"""What may never be COMMITTED — the containment boundary of the repository itself.

    python3 platform/tools/repo_hygiene.py --check       # CI: exit 1 on any finding
    python3 platform/tools/repo_hygiene.py               # report, exit 0
    python3 platform/tools/repo_hygiene.py --history --check   # ...and what history still carries

`deploy_tree.py` answers "what may production see". This answers the stricter question underneath it:
what may exist in the checkout at all. They are different sets — a handoff draft belongs in the repo
and not in a workspace.

WHAT IT REFUSES:

  scanned / exported DOCUMENTS
      The physical forms source material arrives in: a specification exported to PDF, a vendor data
      dictionary, a  page, a mail or deck export, an archive of any of them. Link the
      document from `source_refs.yaml`; do not carry it. Restricted material in the checkout is
      readable by anything with filesystem access, which is a wider audience than "whoever reads the
      repository".

  SPREADSHEETS THAT ARE NOT REGISTERED SPECIFICATIONS
      `.xlsx` is the one document format a pack legitimately holds, because the program-spec WORKBOOK
      is a governed extraction input the pipeline PARSES. So it is allowed by REGISTRATION, not by
      extension: a workbook named in some pack's `source_refs.yaml` as `program_spec` or
      `extraction_input` is fine, and any other is refused. Extension alone would equally admit a
      vendor data dictionary, a patient-level extract or a profile — all of them spreadsheets.

  whole-repo transfer snapshots
      A second, frozen copy of the repository inside the repository: a governed config that answers to
      no gate and no review.

  UNOWNED FILES in a pack's handoff/ directory
      handoff/ is the ledger the stakeholder surfaces are computed from, and it is a CLOSED set —
      every file in it is written, read or fenced by a named tool (`HANDOFF_FILES` /
      `HANDOFF_SUBDIRS`). An unowned file there is where two versions of the truth start.

  CHECKOUT PATHS in text (`MACHINE_PATHS`)
      An absolute path makes a `--check` comparison mean "regenerated on this machine, in this
      directory" instead of "current" — it passes locally and fails on every other checkout.
      `test_spec_pipeline` enforces the same list over generated artifacts, importing it from here, so
      the narrow scope cannot drift laxer than the broad one.

TRACKED, PRESENT **and** REACHABLE. `restricted_files` reads the git INDEX, which is the question for a commit;
`.gitignore` says nothing about what is already tracked and `git add -f` overrides it. But an ignored
file is still on disk and still readable by an indexing tool, a local process or an agent with
checkout access — so `present_files` walks the working tree for the same kinds. docs/ENGINEERING.md states this
about profiler output already: ".gitignore stops a commit, not a read".

And `history_files` reads what is reachable from ANY REF, because deleting a file from the tree does
not delete it from the repository: a file removed from the index stays retrievable by `git show`
from any clone. Removing a file is a commit; removing it from history is a rewrite, and only the
second makes "this material is not in this repository" true. This mode re-derives that, and FAILS
CLOSED on a shallow clone, where one commit of examined history would report a false all-clear.

STDLIB ONLY, like `contract_lint`. It runs before anything else is known to work, and a hygiene gate
that needs PyYAML installed is a gate with a prerequisite.
"""
import argparse
import fnmatch
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from spec_extract import repo_root as checkout_root, repo_relative  # noqa: E402

# (glob matched against the BASENAME, why it may not be here). Basename rather than path, because the
# directory is what moves: a rename or a nesting level should not re-admit a file kind.
NEVER_COMMITTED = (
    ("*.pdf",  "an exported document — the form specifications and vendor data dictionaries "
               "arrive in. Link it from source_refs.yaml instead."),
    ("*.doc",  "an exported document; see *.pdf."),
    ("*.docx", "an exported document; see *.pdf."),
    ("*.ppt",  "an exported deck; see *.pdf."),
    ("*.pptx", "an exported deck; see *.pdf."),
    ("*.msg",  "an exported mail item — correspondence is not a governed source material."),
    ("*.eml",  "an exported mail item; see *.msg."),
    # An image of a page is the same document in a different container, so the list cannot stop at
    # document extensions. `.html` covers a saved documentation page; the archive globs below cover
    # any of these inside a container.
    ("*.png",  "a screen or page image. A specification is the document, not a picture "
               "of one; a diagram belongs in the markdown that explains it, as text or mermaid."),
    ("*.jpg",  "a screen or page image; see *.png."),
    ("*.jpeg", "a screen or page image; see *.png."),
    ("*.tif",  "a scanned page; see *.png."),
    ("*.tiff", "a scanned page; see *.png."),
    ("*.bmp",  "a screen or page image; see *.png."),
    ("*.webp", "a screen or page image; see *.png."),
    ("*.html", "a saved web page — the shape a vendor documentation portal is captured in. A "
               "generated report belongs in the restricted output directory, not the checkout."),
    ("*.htm",  "a saved web page; see *.html."),
    ("*.zip",  "an archive. Whatever is inside it is not reviewable in a diff, which is the whole "
               "point of putting it in one."),
    ("*.tar",  "an archive; see *.zip."),
    ("*.gz",   "an archive; see *.zip."),
    ("*.7z",   "an archive; see *.zip."),
    ("*.rar",  "an archive; see *.zip."),
    ("repo_snapshot.txt", "a whole-repo transfer snapshot: a second, frozen copy of the repository "
                          "inside the repository, answering to no gate."),
    ("repo_export.txt",   "a whole-repo transfer snapshot; see repo_snapshot.txt."),
    ("*_export.txt",      "a whole-repo transfer snapshot; see repo_snapshot.txt."),
)

# Spreadsheets are refused by DEFAULT and permitted by REGISTRATION — see `registered_workbooks`. A
# blanket `*.xlsx` allowance existed because one ovarian workbook is a governed extraction input, and
# it equally admitted a vendor data dictionary, a patient-level extract, a saved profile or a copied
# schema listing, all of which are spreadsheets and none of which may be here.
SPREADSHEETS = ("*.xlsx", "*.xlsm", "*.xls")
SPREADSHEET_WHY = ("a spreadsheet that no pack registers. The program-spec WORKBOOK is a governed "
                   "extraction input and is allowed; anything else with the same extension — a vendor "
                   "data dictionary, an extract, a saved profile — is not. Register it in a pack's "
                   "source_refs.yaml as program_spec or extraction_input, or keep it out.")
PRODUCTION_SPREADSHEET_WHY = (
    "a spreadsheet that is not a REVIEWED specification input. A checkout may hold a draft workbook "
    "or a reconstruction being exercised against the pipeline; a shipped artifact may not, or 'only "
    "approved specifications reach production' is a sentence nothing enforces. Move it to "
    "status: reviewed with its approval record — and, for an extraction_input, its attestation — or "
    "keep it out of the package.")

# A pack's handoff/ directory is a CLOSED SET: every file in it is an artifact a named tool
# writes, reads or fences — the register, the generated ranked view, the contract, the gap index,
# the findings, the answer forms, the pack tests. Anything else is sprawl: a scratch note, a
# second copy, a saved page, and sprawl is where a stakeholder finds two files that disagree.
# A NEW artifact kind is admitted by extending this tuple in the same commit as its owning tool,
# which keeps "do we need all these files" answerable by reading one list.
HANDOFF_FILES = ("DECISIONS.md", "ENGINE_GAPS.md", "FUNCTIONAL_CONTRACT.md", "RWB_QUESTIONS.md",
                 "SPEC_QC_FINDINGS.md", "WORKFLOW.md", "LEGACY_SOURCES.yaml", "MATURITY.yaml",
                 "spec_dispositions.yaml",
                 # the gate evidence itself — dry_run demands these exact names in handoff/, so a
                 # closed set without them would refuse the first pack to actually reach Gate 3/4/6
                 "SOURCE_VERDICTS.md", "CONTRACT_APPROVAL.yaml", "CONFIGURATION_APPROVAL.yaml",
                 "RELEASE_APPROVAL.yaml",
                 # the template ships inert examples of the approval files; a verbatim copy of
                 # TUMOR_TEMPLATE must commit clean or the bootstrap fails at its first push
                 "CONTRACT_APPROVAL.example.yaml", "CONFIGURATION_APPROVAL.example.yaml",
                 "RELEASE_APPROVAL.example.yaml")
HANDOFF_SUBDIRS = {"decision_answers": (".yaml",), "tests": (".py",)}


def _handoff_named(name):
    """True when a top-level handoff file is allowlisted — by exact name, or as a per-member
    verdict report (`SOURCE_VERDICTS.<member>.md`, one per union member, same owner as the pack
    report)."""
    return (name in HANDOFF_FILES
            or (name.startswith("SOURCE_VERDICTS.") and name.endswith(".md")))
HANDOFF_WHY = ("not a handoff artifact any tool owns. handoff/ is a closed set (HANDOFF_FILES / "
               "HANDOFF_SUBDIRS in repo_hygiene.py): the register, the generated question view, "
               "the contract, the gap index, the QC findings, the workflow instantiation, the "
               "maturity and legacy records, the answer forms (*.yaml) and the pack tests (*.py). "
               "A new artifact kind is admitted by extending the allowlist in the same commit as "
               "the tool that owns it — an unowned file is where two versions of the truth start.")

# Directories whose contents are unreviewed model output. They are gitignored, so the INDEX check is
# blind to them, and gitignored is exactly the state in which a file is still on disk and still
# readable by an agent with checkout access. Matched against the PATH, not the basename.
NEVER_PRESENT_DIRS = ("/.claude/skills/", )
NEVER_PRESENT_DIR_MARK = "-workspace/"

# Substrings that mean "this text names SOMEBODY'S MACHINE", wherever they appear. `/github/workspace`
# is the CI checkout root, which is just as machine-specific as a home directory. Matched after
# lower-casing and after `\` is folded to `/`, so `C:/Users/...`, `c:\users\...` and `/USERS/` are the
# same finding — a case-sensitive list on a case-insensitive filesystem is a check with a spelling.
MACHINE_PATHS = ("/home/", "/users/", "c:/users/", "/github/workspace")

# Forbidden ON TOP of those in a GENERATED artifact, where ANY absolute path is a leak: a bare drive
# letter. The distinction is the FILE, not the marker — `C:\Program Files\Git\bin\bash.exe` is a
# standard install location and appears in three Windows run instructions, so it is prose in a README
# and a defect in a file that gets byte-compared by `--check`. Splitting the scan and not the list is
# what keeps the narrow scope from quietly drifting laxer than the broad one.
GENERATED_ONLY = ("c:/",)

# Extensions read for MACHINE_PATHS. Governed documents and generated artifacts, AND the source that
# writes them: a hardcoded `/home/someone/` in a `.py`, `.R` or `.sh` is the same defect one step
# earlier, and leaving those out meant the CI step's claim ("nothing machine-specific is committed")
# was broader than what it looked at. Not "everything not binary" — the scan is a substring match, and
# widening it without a reason produces noise that gets silenced with an ignore list, which is how a
# check dies.
TEXT_SUFFIXES = (".md", ".yaml", ".yml", ".json", ".txt", ".conf", ".tsv", ".csv",
                 ".py", ".r", ".sh", ".ps1", ".sql", ".cfg", ".ini", ".toml")

# THE ONE EXEMPTION, and it is structural rather than a convenience: this module declares the markers,
# so it contains them. `source_manifest.redact_vendor_prose` hit the same shape — its notice named the
# markers it had removed, so the scanner found them again and the pack went from 30 breaches to 40.
# There the answer was to name none; here the declaration has to be legible, so the declaring file is
# skipped BY PATH. Anything else that trips the check is a real finding, including this file's tests.
DECLARES_MARKERS = "platform/tools/repo_hygiene.py"


class NotAGitCheckout(Exception):
    """Raised rather than returning "no findings" — see `tracked`."""


def tracked(root):
    """Every path git has in the index, repo-relative with forward slashes.

    `git ls-files` and not a directory walk, on purpose. The question is what is COMMITTED; a walk
    would report build output, virtualenvs and a downloaded PDF sitting in the working copy that
    `.gitignore` already handles, and the noise is what gets a check switched off.

    FAIL-CLOSED: no git, no answer. An empty list from a failed subprocess reports a clean repository,
    which is the one result this must never invent — same reason `boundary_markers` refuses to treat a
    missing policy file as zero markers.
    """
    try:
        out = subprocess.run(["git", "-C", root, "ls-files", "-z"],
                             capture_output=True, check=True).stdout.decode("utf-8", "replace")
    except (OSError, subprocess.CalledProcessError) as exc:
        raise NotAGitCheckout(
            f"cannot list the git index of {root} ({exc}) — repo hygiene is a question about what is "
            f"tracked, and a checkout that cannot be read has not been shown clean") from exc
    return sorted(p.replace(os.sep, "/") for p in out.split("\0") if p)


def is_shallow(root):
    """Is this checkout missing history? `git rev-parse --is-shallow-repository` is authoritative.

    It matters because `actions/checkout@v4` clones with `fetch-depth: 1` by DEFAULT. A history scan
    over one commit finds nothing and prints the same "none refused" line as a scan over ten years,
    so without this the CI step would be decorative from the day it was added.
    """
    try:
        out = subprocess.run(["git", "-C", root, "rev-parse", "--is-shallow-repository"],
                             capture_output=True, check=True).stdout.decode().strip()
    except (OSError, subprocess.CalledProcessError) as exc:
        raise NotAGitCheckout(f"cannot ask {root} whether it is shallow ({exc})") from exc
    return out == "true"


def history_paths(root):
    """Every path that any BLOB reachable from any ref has ever been stored under.

    Reachable-from-a-ref is the right question because it is exactly what a clone copies: an object
    no ref reaches is already unreachable to whoever clones this, and will go on the next `gc`.

    TWO SOURCES, UNIONED, because neither is complete alone:

      * `rev-list --objects` walks every reachable object, but prints each OBJECT once — and git
        deduplicates by content, so two paths holding identical bytes yield ONE line naming ONE of
        them. A refused file whose content happens to coincide with a permitted one would be missed,
        and an empty placeholder or a one-line stub is exactly where that collides.
      * `log --name-only` walks every path any commit touched, which has no such blind spot, but
        shows nothing for a merge unless asked — so an evil merge introducing a path is invisible.

    Their union has neither gap. It is two cheap subprocesses over a repository this size, and the
    alternative is being subtly wrong in the one direction that matters: reporting clean.

    Blobs only, from the object walk. `rev-list --objects` names trees as well, and a directory
    called `reports.html` is not a saved web page — classifying one as a finding would put noise into
    the check that most needs believing. Diff paths are files by construction.

    FAIL-CLOSED twice over: a shallow checkout REFUSES rather than reporting on the sliver it holds,
    and an unreadable git raises, for the same reason `tracked` does.
    """
    if is_shallow(root):
        raise NotAGitCheckout(
            f"{root} is a SHALLOW clone — its history is truncated, so scanning it would report on a "
            f"fraction of the repository and print the same 'none refused' line as a full scan. "
            f"Fetch the whole history first (actions/checkout: `fetch-depth: 0`).")
    try:
        rev = subprocess.run(["git", "-C", root, "rev-list", "--objects", "--all"],
                             capture_output=True, check=True).stdout
        meta = subprocess.run(
            ["git", "-C", root, "cat-file", "--batch-check=%(objecttype) %(rest)"],
            input=rev, capture_output=True, check=True).stdout.decode("utf-8", "replace")
        touched = subprocess.run(
            ["git", "-C", root, "log", "--all", "--pretty=format:", "--name-only", "--no-renames"],
            capture_output=True, check=True).stdout.decode("utf-8", "replace")
    except (OSError, subprocess.CalledProcessError) as exc:
        raise NotAGitCheckout(
            f"cannot walk the history of {root} ({exc}) — an unreadable history has not been shown "
            f"clean") from exc
    out = set()
    for line in meta.splitlines():
        kind, _, rest = line.partition(" ")
        if kind == "blob" and rest.strip():
            out.add(rest.strip().replace(os.sep, "/"))
    out |= {l.strip().replace(os.sep, "/") for l in touched.splitlines() if l.strip()}
    return sorted(out)


def history_files(root):
    """[(path, why)] for restricted material still reachable in history.

    The SAME `restricted_files` the index check uses, over a different set of paths — the rule may not
    fork. A second list of refused extensions for history would agree on the day it was written and
    diverge at the first addition to either, which is the failure mode docs/ENGINEERING.md opens with.

    Spreadsheets resolve against the registrations in the CURRENT tree, which is the only registry
    there is: a workbook some pack registers today is legitimately in history too, and one nothing
    registers is a finding worth seeing whether it is in the index or merely retrievable from it.

    Which is why a BARE repository is REFUSED rather than scanned. `_registered` walks `products/`
    on disk, and a bare repo has no working tree — so every registration lookup comes back empty and
    the registered program-spec workbook is reported as "a spreadsheet that no pack registers". That
    is not fail-closed, it is a FALSE finding: the tool would be saying the workbook is unregistered
    when the truth is that it could not look. Verifying a mirror is a real thing to want; do it by
    cloning the mirror normally and pointing this at the checkout.
    """
    if subprocess.run(["git", "-C", root, "rev-parse", "--is-bare-repository"],
                      capture_output=True).stdout.decode().strip() == "true":
        raise NotAGitCheckout(
            f"{root} is a BARE repository. The spreadsheet rule resolves against the registrations "
            f"in products/*/source_refs.yaml, which only exist in a working tree — scanning here "
            f"would report every registered program-spec workbook as unregistered. Clone it "
            f"normally and point --history at the checkout.")
    return restricted_files(root, history_paths(root))


def _registered(root):
    """{repo-relative path: (material_type, status)} for every registered specification INPUT.

    Read with a LINE SCAN, not a YAML parser, because this module is stdlib-only and runs first — a
    hygiene gate that needs PyYAML installed to answer "is there a vendor data dictionary in your
    repository" is a gate with a prerequisite. Gate 1 is what checks a registration is well-formed and
    still hashes; this only asks what kind it claims to be and what status it claims to hold.
    """
    out = {}
    for dirpath, dirnames, filenames in os.walk(os.path.join(root, "products")):
        dirnames[:] = [d for d in dirnames if d not in (".git", "__pycache__")]
        if "source_refs.yaml" not in filenames:
            continue
        try:
            with open(os.path.join(dirpath, "source_refs.yaml"), encoding="utf-8") as fh:
                text = fh.read()
        except OSError:
            continue
        kind = path = status = None
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.startswith("- "):                       # a new material starts
                kind = path = status = None
                stripped = stripped[2:].strip()
            if stripped.startswith("material_type:"):
                kind = stripped.split(":", 1)[1].strip().strip('"\'')
            elif stripped.startswith("path_or_link:"):
                path = stripped.split(":", 1)[1].strip().strip('"\'')
            elif stripped.startswith("status:"):
                status = stripped.split(":", 1)[1].split("#")[0].strip().strip('"\'')
            if kind in ("program_spec", "extraction_input") and path:
                out[path.replace(os.sep, "/").lstrip("./")] = (kind, status)
                path = None
    return out


def registered_workbooks(root):
    """Paths some pack registers as a specification input, at ANY status.

    The CHECKOUT rule: a spreadsheet is here legitimately if a pack says what it is. A draft workbook
    under review, a reconstruction being exercised against the pipeline, an approved one — all belong
    in a development repository, and refusing them would refuse the work.
    """
    return set(_registered(root))


def production_eligible_workbooks(root):
    """...and the STRICTER set, for anything leaving the repository.

    A different question, and it was being answered with the checkout rule. `registered` admits a
    spreadsheet at `status: pending` — which is the ovarian workbook's actual state: a RECONSTRUCTION
    generated from `workbook_src/`, registered `extraction_input`, recorded in its own manifest as
    something that "must not be read as the June 2026 specification". Shipping that under a claim that
    only approved specifications reach production would make the claim false.

    So production-bound means REVIEWED: an approved `program_spec`, or an `extraction_input` that is
    reviewed AND attested — Gate 1 requires `attested_by` / `attestation_date` /
    `attested_against_sha256` at that status, which is the record of a person having compared the copy
    to the document it stands in for.

    It returns an empty set today, and that is the honest answer rather than a defect: no pack has a
    reviewed specification input yet.
    """
    return {p for p, (_k, s) in _registered(root).items() if s == "reviewed"}


def restricted_files(root, paths=None, production=False):
    """[(path, why)] for every path whose NAME — or, for a spreadsheet, whose lack of a registration —
    says it may not be here.

    `paths` is repo-relative; `root` is only read for the registration lookup, so a caller checking a
    list of tree paths may pass "" as it always could.

    `production=True` applies `production_eligible_workbooks` instead: a checkout may hold a draft or
    reconstructed workbook and a shipped artifact may not, and answering both with one rule is how
    "only approved specifications reach production" became a sentence nothing enforced.
    """
    paths = tracked(root) if paths is None else paths
    allowed = ((production_eligible_workbooks(root) if production else registered_workbooks(root))
               if root else set())
    why_not = PRODUCTION_SPREADSHEET_WHY if production else SPREADSHEET_WHY
    out = []
    for rel in paths:
        base = os.path.basename(rel).lower()
        hit = next((why for pattern, why in NEVER_COMMITTED if fnmatch.fnmatch(base, pattern)), None)
        if hit is None and any(fnmatch.fnmatch(base, p) for p in SPREADSHEETS) and \
                rel.replace(os.sep, "/") not in allowed:
            hit = why_not
        if hit is not None:
            out.append((rel, hit))
    return out


def handoff_errors(root, paths=None):
    """[(path, why)] for every COMMITTED file inside a pack's handoff/ that the allowlist does not
    name. The index, not the working tree: sprawl is a question about what lands in the ledger,
    and __pycache__ or an editor's scratch file is .gitignore's problem, not this one's."""
    paths = tracked(root) if paths is None else paths
    out = []
    for rel in paths:
        parts = rel.replace(os.sep, "/").split("/")
        if not (rel.startswith("products/") and "handoff" in parts):
            continue
        inside = parts[parts.index("handoff") + 1:]
        if len(inside) == 1 and _handoff_named(inside[0]):
            continue
        if len(inside) == 2 and inside[0] in HANDOFF_SUBDIRS and \
                inside[1].lower().endswith(HANDOFF_SUBDIRS[inside[0]]):
            continue
        out.append((rel, HANDOFF_WHY))
    return out


def present_files(root):
    """[(path, why)] for restricted material sitting in the WORKING TREE, tracked or not.

    `.gitignore` is not containment. An ignored file is on disk and readable by an indexing tool, a
    local process or an agent with checkout access — the audience that matters for restricted source
    material is "anything that can open a file", not "anyone who reads the repository". Eval
    workspaces are the case in point: gitignored by design, and they quote whatever the model was
    shown.

    `build/`, virtualenvs and caches are skipped because they are generated and already understood;
    `.git` because its contents are history, which this cannot fix and must not report as a finding.
    """
    skip = {".git", "__pycache__", ".venv", "venv", "build", "node_modules", ".pytest_cache"}
    found, out = [], []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in skip]
        rel_dir = repo_relative(dirpath, root)
        rel_dir = "" if rel_dir == "." else rel_dir + "/"
        if NEVER_PRESENT_DIR_MARK in f"/{rel_dir}" and \
                any(d in f"/{rel_dir}" for d in NEVER_PRESENT_DIRS):
            dirnames[:] = []
            out.append((rel_dir, "unreviewed model output. It is gitignored, which keeps it out of a "
                                 "commit and does nothing about the file being on disk and readable. "
                                 "Such output quotes whatever the model was shown, including "
                                 "paths and passages from restricted source material."))
            continue
        found += [rel_dir + f for f in filenames]
    return out + restricted_files(root, found)


def machine_paths_in(root, paths=None, markers=MACHINE_PATHS):
    """[(path, marker)] for every text file in PATHS that names a filesystem outside the repository.

    `markers` widens to `MACHINE_PATHS + GENERATED_ONLY` for the generated-artifact scan; see the
    comment on `GENERATED_ONLY` for why that is a difference of scope and not of policy.
    """
    out = []
    for rel in (tracked(root) if paths is None else paths):
        if rel == DECLARES_MARKERS or not rel.lower().endswith(TEXT_SUFFIXES):
            continue
        try:
            with open(os.path.join(root, rel), encoding="utf-8", errors="replace") as fh:
                text = fh.read()
        except OSError:
            continue
        # NORMALISED before matching: lower-cased, and `\` folded to `/`. `C:/Users/x`, `c:\users\x`
        # and `/USERS/x` are one defect, and a case-sensitive substring list turned it into three,
        # only one of which was caught.
        low = text.lower().replace("\\", "/")
        out += [(rel, m) for m in markers if m in low]
    return out


def errors(root):
    """Every finding as a printable line. Empty means the checkout is clean.

    Three questions, and they are not the same one: what is COMMITTED, what is PRESENT, and what NAMES
    a machine. The middle one is the reason `--check` is not simply a lint over `git ls-files`.
    """
    paths = tracked(root)
    present = {rel for rel, _why in restricted_files(root, paths)}
    return ([f"{rel}: {why}" for rel, why in restricted_files(root, paths)] +
            [f"{rel}: {why}" for rel, why in handoff_errors(root, paths)] +
            [f"{rel}: {why} (untracked, but on disk — .gitignore is not containment)"
             for rel, why in present_files(root) if rel not in present] +
            [f"{rel}: names a checkout path ({marker!r}) — a generated or documented absolute path "
             f"is true on one machine only" for rel, marker in machine_paths_in(root, paths)])


def history_errors(root):
    """Every historical finding as a printable line, deduplicated by PATH.

    One path is one finding however many revisions of it exist: a document committed, edited and
    deleted is one document to remove, and printing it six times buries the other five paths.
    """
    return [f"{rel}: {why} — still reachable in history, so every clone carries it and `git show` "
            f"reconstructs it. Removing it from the tree did not remove it from the repository."
            for rel, why in history_files(root)]


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--root", default=None, help="checkout to inspect (default: the one this lives in)")
    ap.add_argument("--check", action="store_true", help="exit 1 if anything is found")
    ap.add_argument("--history", action="store_true",
                    help="scan what is REACHABLE FROM ANY REF instead of what is in the index — "
                         "deleting a file from the tree does not delete it from the repository")
    a = ap.parse_args(argv)

    root = a.root or checkout_root(os.path.abspath(__file__))
    if not root:
        sys.exit("no checkout found around this tool — pass --root")
    try:
        found = history_errors(root) if a.history else errors(root)
    except NotAGitCheckout as exc:
        sys.exit(str(exc))
    for line in found:
        print(line)
    if not found:
        print(f"ok  repo hygiene: {len(history_paths(root))} paths in history, none refused"
              if a.history else
              f"ok  repo hygiene: {len(tracked(root))} tracked files, none refused")
    return 1 if (found and a.check) else 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
