#!/usr/bin/env python3
"""Who counts as a stated PERSON, and what counts as stated at all — stdlib only, on purpose.

These rules began life in `product_gates`, which imports PyYAML and the engine configuration. Then
`contract_scaffold` — a documented stdlib-only tool on the spec-pipeline bootstrap path — needed
`not_a_person`, and importing it dragged YAML into a pipeline whose whole promise is that it runs
on a bare Python install (`python3 -S` reproduces the break an external review reported). The rules
themselves need nothing but `re`, so they live here and `product_gates` re-exports them: one owner,
two import paths, zero new dependencies on the bootstrap side.
"""
import re

# A placeholder is not an answer — ONE definition, for every gate that asks whether a field is filled
# in. Gate 1 rejected nine placeholder spellings while Gate 2 rejected only TODO, so `approved_by:
# TBD` was refused registering a source and accepted approving a contract. Two gates disagreeing
# about what counts as stated is the same class of defect as two parsers disagreeing about a row.
# Distinctive tokens: matched as a token followed by a NON-word character or end of string, because
# exact-match alone let `TBD — owner to follow` and `PENDING confirmation` through as answers.
PLACEHOLDERS_PREFIX = ("TODO", "TBD", "REPLACE_ME", "XXX", "PENDING")
# Short or ambiguous ones: EXACT match only. Prefix-matching `NA` flagged `NA-2026-01`, a perfectly
# plausible document_id, as a placeholder — a gate that refuses real answers is as broken as one that
# accepts fake ones, and this half is the one nobody notices until an approval is blocked.
PLACEHOLDERS_EXACT = frozenset({"NA", "N/A", "NONE", "-", "?", "--", "..."})
_PLACEHOLDER_RE = re.compile(r"^(?:%s)(?:\W.*)?$" % "|".join(PLACEHOLDERS_PREFIX), re.I | re.S)


def unstated(value):
    """True when a field is blank or a placeholder standing in for an answer nobody has given."""
    v = str(value or "").strip()
    return (not v
            or v.upper().rstrip(".") in PLACEHOLDERS_EXACT
            or bool(_PLACEHOLDER_RE.match(v)))


def marker_paths(node, mark="REPLACE_ME", _at=()):
    """Every dotted path in a loaded record whose value still carries a scaffold MARKER.

    WHY THE WHOLE TREE AND NOT A FIELD LIST. Both work-object records claimed in their own headers to
    refuse a marker once a person had signed the record, and both checked a REMEMBERED list of
    fields. `request_record` checked four human fields plus two nested ones; `protocol_record`
    checked two. So an `answered` request could carry `title: REPLACE_ME` and a scaffold `question:`
    — the two things a reader quotes — and a `registered` protocol could carry a scaffold title,
    while the tools reported them clean. A field list is a copy of the template that ages
    independently of it: every field added to a TEMPLATE has to be remembered here, and the failure
    of remembering is silent.

    Walking the loaded document has no list to fall behind. It reports PATHS rather than a count, so
    the message names the field to fill rather than sending someone to hunt.

    Keys are checked too: a scaffold that left a placeholder key behind is the same defect wearing a
    different hat.
    """
    out = []
    if isinstance(node, dict):
        for k in node:
            if mark in str(k):
                out.append(".".join((*_at, str(k))) + " (key)")
            out.extend(marker_paths(node[k], mark, (*_at, str(k))))
    elif isinstance(node, (list, tuple)):
        for i, v in enumerate(node):
            out.extend(marker_paths(v, mark, (*_at, f"[{i}]")))
    elif mark in str(node):
        out.append(".".join(_at) or "(root)")
    return out


# Language a specification author leaves behind when a value is NOT settled — the ONE classifier,
# after two narrower copies each missed the other's spellings: the disposition guard caught
# `confirm`/`TBD` but not `[verify]`, `to be verified` or `unverified`, and six live rows carrying
# exactly those slipped through as settled `control` dispositions. `\bverify\b` covers the
# bracketed `[verify]` convention; `to be verified` is spelled out because `verified` alone is a
# POSITIVE statement this must not match.
UNSETTLED_MARKER = re.compile(
    r"\bTBD\b|\bconfirm\b|\bverify\b|\bunverified\b|\bto be verified\b", re.I)


# Teams, functions and organisations that appeared in fields asking for a PERSON. Declared rather than
# pattern-guessed for the same reason `PLACEHOLDERS_EXACT` is: the set is small, known, and each entry
# is a value somebody actually wrote.
NOT_A_PERSON = frozenset({"RWP", "RWB", "RWDE", "GSK", "EPI", "BIOSTATS", "PROGRAM",
                          "IMPLEMENTATION", "TEAM", "THE TEAM", "DATA SCIENCE", "ENGINEERING",
                          # organisational nouns — as TOKENS these mark a group, whoever it is:
                          # `RWB team` and `QC dept` recorded a wave nobody can be asked about
                          "GROUP", "DEPT", "DEPARTMENT", "COMMITTEE", "BOARD", "STAFF", "OFFICE"})


def not_a_person(value):
    """Why this is not a person's name, or None when it might be.

    "A name, not a team" was stated twice in `source_refs.schema.json` and enforced NOWHERE, so every
    material in every pack recorded `classified_by: RWP` — a function, not a human. The field exists
    because a classification is one person's judgment about what AI may read: a verdict attributed to
    a team is one nobody can be asked about, and there is no way to tell a considered call from a
    value pasted in to make CI go green.

    IT CANNOT VERIFY A PERSON EXISTS and does not pretend to. It refuses the two shapes that are
    demonstrably not one: a declared team name, and a single ALL-CAPS ALPHABETIC token, which is what
    an acronym looks like and what a name does not. `Onkar Kshirsagar` passes; so would a made-up
    name, and catching that is a reviewer's job, not a parser's.

    Narrow on purpose. A check that guessed at name shapes would refuse `Ng`, `de Vries`, `O'Brien`
    or any name outside its author's alphabet. INITIALS are allowed — `J.S.` is a weak person
    reference but a real one, and the specifications' own QC columns are initialled, so refusing the
    dotted form would refuse the convention the source documents use. The `.isalpha()` test is what
    separates `RWP` from `J.S.`
    """
    v = str(value or "").strip()
    if not v or unstated(v):
        return None                       # `unstated` already reports this, and twice is one defect
    # WORD-level, not value-level: `RWB` was refused while `RWB team` and `the RWB group` passed —
    # padding a team name with more team was enough to get a wave recorded. Any word that is itself
    # a declared team/function marker makes the whole value a group, whatever surrounds it.
    words = {w.strip(".,;:()[]").upper() for w in v.split()}
    if v.upper() in NOT_A_PERSON or (words & NOT_A_PERSON):
        return (f"{v!r} is a team, not a person. This field records WHOSE judgment this was — a "
                f"verdict attributed to a function is one nobody can be asked about.")
    if " " not in v and v.isalpha() and v == v.upper():
        return (f"{v!r} looks like an acronym rather than a name. Record the person who made the "
                f"call; initials (`J.S.`) are accepted, a function is not.")
    return None
