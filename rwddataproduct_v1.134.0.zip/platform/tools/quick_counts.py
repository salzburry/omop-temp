#!/usr/bin/env python3
"""The exploration lane — counts-only feasibility queries that RECORD every definition they assume.

    python3 platform/tools/quick_counts.py <pack> --frame <tsv> --by region1 \\
        --where "cohort=C2" --log-dir ~/rwdp-quick-counts
    python3 platform/tools/quick_counts.py <pack> --synthetic 60 --by cohort --log-dir ~/qc
    python3 platform/tools/quick_counts.py <pack> --intake ~/rwdp-quick-counts

WHY THIS EXISTS. Feasibility sizing ("is this cohort even big enough to bother") does not need
six gates — it needs a fast count. What it must NOT do is silently invent definitions: every
column a query touches either resolves against the cross-pack naming registry (the pack defined
it, or the engine emits it) or is an ASSUMPTION, and an assumption is demand evidence the
decision loop should see. So the lane runs on three rules, all fail-closed:

  1. COUNTS ONLY. The output is totals and group sizes — never a row, never an id. Groups below
     the small-cell floor are pooled and reported as suppressed, the same floor the profiler
     applies (a PLACEHOLDER for the approved organisational threshold — data_profiler.R:43).
  2. ASSUMPTIONS ARE LOGGED OR THE QUERY DOES NOT RUN. A query touching a name no contract and
     no engine stage carries must state what it means by it (--assume name="meaning") and carry
     a --log-dir OUTSIDE the checkout; the assumption lands in the intake ledger. Refusing to
     count is the design: an unlogged assumption is a silent definition, which is the failure
     this lane exists to prevent.
  3. NOTHING HERE IS EVIDENCE. Every output is stamped `lane: exploration`. `--intake`
     summarises the ledger — which names people keep assuming, how often, with what meanings —
     as DEMAND for the decision loop; a person phrases the question (answer-decisions owns that
     path) and this tool writes nothing under any pack's handoff/.

The frame the counts run over is wherever the data is allowed to be — this tool prints counts
and stores none of the frame. `--synthetic` builds a deterministic fake frame for the shape.
"""
import argparse
import json
import os
import re
import sys
from datetime import datetime, timezone

TOOLS = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, TOOLS)

import naming_registry                                                      # noqa: E402
import pack_run                                                             # noqa: E402
from spec_extract import repo_relative                                      # noqa: E402

MIN_CELL = 11          # small-cell floor — keep in step with data_profiler.R `min_cell`
LEDGER = "assumptions.jsonl"
BANNER = ("NON-EVIDENCE GRADE — exploration lane. Counts carry no approved definition unless "
          "the name resolves to the registry; nothing here is a verdict, and nothing here "
          "reaches a gate.")


def parse_where(clauses):
    """[(column, op, value)] from "col=value" / "col!=value" — anything else is refused, because
    a clause this lane cannot parse is a definition it would otherwise silently drop."""
    out = []
    for c in clauses or []:
        m = re.fullmatch(r"\s*([A-Za-z_][A-Za-z0-9_]*)\s*(!?=)\s*(.*?)\s*", c)
        if not m:
            sys.exit(f"cannot parse --where {c!r} — the lane takes `col=value` or `col!=value`; "
                     f"anything richer is a definition that belongs in a pack, not a flag")
        out.append((m.group(1).lower(), m.group(2), m.group(3)))
    return out


def resolve(names, registry=None):
    """{name: {"resolution": defined|assumption, ...}} — every touched column against the
    cross-pack registry. A near-miss on a registered name is NAMED in the result so the
    recommendation ("the standard spelling already exists") rides with the count."""
    reg = naming_registry.registry() if registry is None else registry
    out = {}
    for n in sorted({n.lower() for n in names}):
        rec = reg.get(n)
        if rec is not None:
            out[n] = {"resolution": "defined", "engine": rec["engine"],
                      "packs": sorted(rec["packs"])}
            continue
        near = sorted(k for k in reg if naming_registry._near(n, k))
        out[n] = {"resolution": "assumption",
                  "near": near,
                  "note": (f"no contract and no engine stage carries `{n}`"
                           + (f"; the registry carries {', '.join(near)} — is one of those the "
                              f"standard spelling?" if near else ""))}
    return out


def counts(rows, by=None, where=()):
    """total + per-group sizes over an iterable of dict rows, small cells pooled. Pure: the
    caller owns where the rows came from; this function never sees more than it counts."""
    total = 0
    groups = {}
    for r in rows:
        keep = True
        for col, op, val in where:
            have = str(r.get(col, "")).strip()
            keep = (have == val) if op == "=" else (have != val)
            if not keep:
                break
        if not keep:
            continue
        total += 1
        if by:
            groups[str(r.get(by, "")).strip() or "(empty)"] = \
                groups.get(str(r.get(by, "")).strip() or "(empty)", 0) + 1
    shown = {k: v for k, v in groups.items() if v >= MIN_CELL}
    supp = {k: v for k, v in groups.items() if v < MIN_CELL}
    # COMPLEMENTARY SUPPRESSION. With exactly one group under the floor, the exact total minus
    # the exact shown groups recovers the hidden cell by subtraction — the floor protects
    # nothing. So a lone suppressed cell drags the SMALLEST shown group into the pool with it:
    # subtraction then yields only the pooled pair's sum, never an individual cell.
    if len(supp) == 1 and shown:
        k = min(shown, key=lambda g: (shown[g], g))
        supp[k] = shown.pop(k)
    pooled = sum(supp.values())
    out = {"total": total if total >= MIN_CELL or total == 0 else f"<{MIN_CELL}"}
    if by:
        out["by"] = {"column": by, "groups": dict(sorted(shown.items())),
                     "suppressed_values": len(supp),
                     "suppressed_rows": pooled if pooled >= MIN_CELL or pooled == 0
                     else f"<{MIN_CELL}"}
    return out


def read_frame(path):
    with open(path, encoding="utf-8") as fh:
        hdr = [h.strip().lower() for h in fh.readline().rstrip("\n").split("\t")]
        for line in fh:
            if not line.strip():                   # a blank line is not a row of anything
                continue
            yield dict(zip(hdr, line.rstrip("\n").split("\t")))


def synthetic(n, columns):
    """A deterministic fake frame — three cycling values per named column, for the SHAPE only."""
    for i in range(n):
        yield {c: f"v{(i + j) % 3 + 1}" for j, c in enumerate(sorted(columns))}


def log_assumptions(log_dir, pack, resolved, meanings, asked, asked_by=""):
    """Append the assumed definitions to the intake ledger, outside the checkout. Assumptions
    with no stated meaning are refused: "I assumed something" is not demand evidence — and in
    the participation pilot, neither is an anonymous one: --asked-by names WHO needs the
    definition, so the docket can weigh demand by asker, and a team name is refused the same
    way it is refused everywhere else in this repository."""
    assumed = [n for n, r in resolved.items() if r["resolution"] == "assumption"]
    if not assumed:
        return 0
    if asked_by:
        import product_gates as pg                     # noqa: PLC0415
        why = pg.not_a_person(asked_by)
        if why:
            sys.exit(f"--asked-by {asked_by!r}: {why}. Demand is attributed to a person, "
                     f"not a team — the pilot's askers are named.")
    if not log_dir:
        sys.exit("ASSUMPTIONS UNLOGGED — this query touches "
                 + ", ".join(f"`{n}`" for n in assumed)
                 + ", which no contract and no engine stage defines. Pass --log-dir (outside "
                   "the checkout) so the assumed definitions land in the intake ledger, and "
                   "--assume name=\"what you mean by it\" for each. The exploration lane "
                   "records what it had to assume, or it does not run.")
    missing = [n for n in assumed if n not in meanings]
    if missing:
        sys.exit("UNSTATED ASSUMPTION — say what you mean: "
                 + " ".join(f'--assume {n}="…"' for n in missing))
    root = pack_run.restricted_dir(log_dir, what="the assumption intake ledger")
    os.makedirs(root, exist_ok=True)
    with open(os.path.join(root, LEDGER), "a", encoding="utf-8") as fh:
        for n in assumed:
            fh.write(json.dumps({"name": n, "meaning": meanings[n],
                                 "pack": repo_relative(pack), "asked": asked,
                                 "asked_by": asked_by,
                                 "near": resolved[n].get("near", []),
                                 "at": datetime.now(timezone.utc).isoformat(timespec="seconds")},
                                sort_keys=True) + "\n")
    return len(assumed)


def intake(log_dir):
    """The demand summary: which names sessions keep assuming, how often, with what meanings.
    A report a person routes into the decision loop — this tool never phrases the question."""
    path = os.path.join(os.path.realpath(os.path.expanduser(log_dir)), LEDGER)
    if not os.path.exists(path):
        return {"ledger": path, "entries": 0, "names": {}}
    by_name = {}
    n = 0
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            e = json.loads(line)
            n += 1
            d = by_name.setdefault(e["name"], {"sessions": 0, "meanings": [], "packs": set(),
                                               "near": set(), "askers": set()})
            d["sessions"] += 1
            if e["meaning"] not in d["meanings"]:
                d["meanings"].append(e["meaning"])
            d["packs"].add(e["pack"])
            d["near"].update(e.get("near", []))
            d["askers"].add(e.get("asked_by") or "(unattributed)")
    for d in by_name.values():
        d["packs"] = sorted(d["packs"])
        d["near"] = sorted(d["near"])
        d["askers"] = sorted(d["askers"])
    return {"ledger": path, "entries": n,
            "names": dict(sorted(by_name.items(), key=lambda kv: -kv[1]["sessions"])),
            "note": "route the recurring names into the decision loop (answer-decisions owns "
                    "the path) — a name assumed twice with two meanings is the naming failure "
                    "arriving on schedule"}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack", nargs="?")
    ap.add_argument("--frame", help="TSV to count over (wherever the data is allowed to live)")
    ap.add_argument("--synthetic", type=int, help="deterministic fake frame of N rows instead")
    ap.add_argument("--by", help="group the count by this column")
    ap.add_argument("--where", action="append", help="col=value / col!=value (repeatable)")
    ap.add_argument("--assume", action="append", default=[],
                    help='name="meaning" for every column the registry does not carry')
    ap.add_argument("--log-dir", help="intake ledger dir, outside the checkout")
    ap.add_argument("--asked-by", default="",
                    help="who is asking (a person's name, never a team) — attributed on every "
                         "logged assumption so the docket can weigh demand by asker")
    ap.add_argument("--intake", metavar="LOG_DIR",
                    help="summarise the assumption ledger instead of counting")
    a = ap.parse_args(argv)

    if a.intake:
        print(json.dumps(intake(a.intake), indent=2))
        return 0
    if not a.pack:
        sys.exit("a pack is required — resolution runs against its registry entries")
    if bool(a.frame) == bool(a.synthetic):
        sys.exit("exactly one of --frame / --synthetic says what to count")

    where = parse_where(a.where)
    touched = [c for c, _o, _v in where] + ([a.by.lower()] if a.by else [])
    if not touched:
        sys.exit("nothing to resolve — name at least one column via --by or --where")
    meanings = {}
    for s in a.assume:
        m = re.fullmatch(r'\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*"?(.+?)"?\s*', s)
        if not m:
            sys.exit(f'cannot parse --assume {s!r} — the form is name="meaning"')
        meanings[m.group(1).lower()] = m.group(2)
    resolved = resolve(touched)
    asked = {"by": a.by, "where": a.where or []}
    logged = log_assumptions(a.log_dir, a.pack, resolved, meanings, asked, a.asked_by)

    rows = synthetic(a.synthetic, touched) if a.synthetic else read_frame(a.frame)
    result = {"lane": "exploration", "banner": BANNER, "pack": repo_relative(a.pack),
              "asked": asked, "resolution": resolved,
              "assumptions_logged": logged,
              "counts": counts(rows, by=(a.by.lower() if a.by else None), where=where)}
    if a.synthetic:
        result["frame"] = f"SYNTHETIC ({a.synthetic} deterministic rows) — the shape, not facts"
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
