#!/usr/bin/env python3
"""The record a REQUEST leaves behind — what was asked, what was answered, and when it goes stale.

    python3 platform/tools/request_record.py --new req-2026-001   # scaffold the record
    python3 platform/tools/request_record.py --check              # lint every registered request

WHAT A REQUEST PRODUCES, AND WHY IT NEEDS A RECORD AT ALL. A data product's output is a governed
table, and what makes it trustworthy later is the receipt: a manifest binding a build to the config,
the source and the approval it ran under. A request's output is a number, a table or a slide — and
the equivalent question is asked of it just as often, usually months later and usually by someone
who was not there: *which release did this number come from, and was that release approved at the
time?* Without a record the honest answer is "nobody knows", and the number keeps circulating.

So the record carries what the number cannot: the question in the requester's words, how the answer
was derived, who asked and who answered, and — through the registry — exactly which release it read.

STALENESS IS THE RECEIPT ANALOGUE, and it is the reason this is a governed record rather than a
note. A product's receipt is checked against the build it claims; a request's answer is checked
against the RELEASE it cited, and that release does not stand still:

  * the cited spec_version is `superseded` in the product's lineage — the answer came from a cut
    that a later one replaced. The answer was not wrong; it is no longer current, and a record still
    claiming `status: answered` is asserting that it is.
  * the cited pack stopped being releasable — an approval regressed underneath the citation.
    `source_manifest.citation_errors` owns that half and is not restated here.

Neither makes the old answer false, and this tool never says it does. What it refuses is a record
that goes on presenting a superseded answer as the current one: move it to `status: superseded`
(a person's act, recording that they know), or re-answer it against the current cut.

WHAT THIS TOOL WILL NOT DO. `requested_by`, `analyst`, the dates, and any status beyond `open` are
human acts — the same rule `source_refs_init.py` follows for a Gate 1 classification. `--new`
writes the marker; a person answers it; `--check` refuses a record that claims to be answered while
a marker is still standing in for the person who answered it.
"""
from __future__ import annotations

import argparse
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import product_gates as pg       # noqa: E402
import source_manifest as sm     # noqa: E402

WORK = "work"
RECORD = "REQUEST.yaml"
MARK = "REPLACE_ME"
# `open` is the only status a tool may write. Everything past it records that a person did something.
STATUSES = ("open", "answered", "superseded", "withdrawn")
ANSWERED = ("answered", "superseded")
# Fields a person fills. Refused as placeholders on any record claiming to be answered.
HUMAN_FIELDS = ("requested_by", "requested_date", "analyst", "answered_date")

TEMPLATE = f"""\
# A REQUEST — work that reads an already-released product and creates no new governed table.
#
# It owes `provenance` instead of Gates 1-6 (governance/WORKFLOW.md, "Which gates apply"). The
# citation itself lives in products/registry.yaml under `work:`, not here: one fact, one place.
# This record carries what the citation cannot — the question, the derivation and the answer.
#
# Every {MARK} below is a person's to fill. `--check` refuses a record claiming `answered` while any
# of them is still standing in for the person who answered it.
request_id: {{rid}}
title: "{MARK}"

# The ask, in the REQUESTER's words rather than the analyst's restatement of it. The two drift, and
# when they do it is the restatement that turns out to have answered a different question.
question: >
  {MARK}

requested_by: {MARK}          # a NAMED person, not a team
requested_date: {MARK}        # YYYY-MM-DD
analyst: {MARK}               # who derived the answer, BY NAME
answered_date: {MARK}         # YYYY-MM-DD

# open -> answered by a person, and later -> superseded when the cited release is replaced.
status: open

# HOW the answer was computed, in enough detail to re-run: a notebook, a query file, a tool
# invocation. A description of the method is not a derivation; a path or a link is.
derivation:
  method: {MARK}              # e.g. notebook | sql | tool
  reference: {MARK}           # path or link to the thing that was actually executed

# WHAT was concluded. `summary` is the sentence that will be quoted; write it as it should be
# quoted, because it will be.
#
# `kind` decides how tightly the answer must be pinned to the data it came from, and it is stated
# rather than guessed: no parser can tell "1234 patients" from a sentence that merely contains a
# number, and a heuristic that tried would be wrong in the direction that matters.
#   quantitative  the answer IS a number, or a set of them. It is only true of one build.
#   descriptive   the answer describes the specification or the method and does not report a count.
result:
  kind: {MARK}                # quantitative | descriptive
  summary: >
    {MARK}

# Does the answer leave the group? An external answer is the one most likely to outlive its cut.
disclosure: {MARK}            # internal | external
"""

# An answer that reports a NUMBER, or that leaves the group, is only true of the exact build it was
# computed on. `cites_release` must then pin that build — `build_id` and/or `manifest_sha256` — and
# not merely the pack, because "prostate 202606" names a specification, and two cuts of it give two
# different counts. A descriptive, internal answer may cite the pack: it describes what the
# specification SAYS, which does not move with the data.
RESULT_KINDS = ("quantitative", "descriptive")


def record_path(rid, root=None):
    return os.path.join(root or REPO, WORK, str(rid), RECORD)


def _requests(root):
    """Registered work objects of kind `request`. The registry is the index; the folder is not."""
    return [w for w in pg.work_entries(root) if str(w.get("kind") or "") == "request"]


def superseded_citations(root, entry):
    """[(product, spec_version, why)] for every citation whose release a later cut replaced.

    Read off the product's own `lineage:` in the registry, which already records `status:
    superseded` and `supersedes:` — the fact exists, nothing new is stored to answer this.
    """
    reg, err = pg.read_yaml(os.path.join(root, "products", "registry.yaml"))
    if err:
        return []
    out = []
    for c in (entry.get("cites_release") or []):
        if not isinstance(c, dict):
            continue
        slug, ver = str(c.get("product") or ""), str(c.get("spec_version") or "")
        for t_ in (reg.get("tumors") or []):
            if not isinstance(t_, dict) or str(t_.get("slug") or "") != slug:
                continue
            for lin in (t_.get("lineage") or []):
                if not isinstance(lin, dict) or str(lin.get("spec_version") or "") != ver:
                    continue
                if str(lin.get("status") or "") == "superseded":
                    later = [str(l.get("spec_version")) for l in (t_.get("lineage") or [])
                             if isinstance(l, dict) and str(l.get("supersedes") or "") == ver]
                    out.append((slug, ver, "replaced by " + (", ".join(later) or "a later cut")))
    return out


def record_errors(root, entry):
    """[why this request's record is not usable], or []."""
    rid = str(entry.get("id") or "")
    path = record_path(rid, root)
    rel = os.path.relpath(path, root)
    if not os.path.exists(path):
        return [f"{rid}: no record at {rel} — a registered request with no record is a citation "
                f"nobody can read; scaffold it with --new {rid}"]
    doc, err = pg.read_yaml(path)
    if err:
        return [f"{rel}: {err}"]
    out = []
    if str(doc.get("request_id") or "") != rid:
        out.append(f"{rel}: request_id {doc.get('request_id')!r} does not match the registry id "
                   f"{rid!r} — the record and its registration must name the same object")
    status = str(doc.get("status") or "")
    if status not in STATUSES:
        out.append(f"{rel}: status {status!r} is not one of {list(STATUSES)}")

    if status in ANSWERED:
        # EVERY marker, not a remembered list of fields. The header has always said a record cannot
        # claim to be answered while carrying one; the check read four human fields plus two nested
        # ones, so `title: REPLACE_ME` and a scaffold `question:` — the two things a reader
        # QUOTES — passed as answered. A field list is a copy of the template that ages on its own.
        for where in pg.marker_paths(doc, MARK):
            out.append(f"{rel}: status is {status!r} and `{where}` still holds {MARK}. Every field "
                       f"in an answered record is somebody's answer; a marker there is the scaffold "
                       f"speaking in their place.")
        # Only now do the human fields have to be answers. An `open` request legitimately has an
        # analyst and an answer date it does not yet know.
        for f in HUMAN_FIELDS:
            v = doc.get(f)
            if pg.unstated(v) or MARK in str(v):
                out.append(f"{rel}: status is {status!r} but {f} is still {str(v)!r} — a record "
                           f"cannot claim to be answered while a marker stands in for the person "
                           f"who answered it")
            # ...and the two that name PEOPLE have to name one. The scaffold's own comment says "a
            # NAMED person, not a team" beside `requested_by`, and nothing enforced it, so
            # `analyst: RWP` answered "who is accountable for this result" with a function. Same
            # `not_a_person` every gate uses; the dates fall through it untouched.
            elif f.endswith("_by") or f == "analyst":
                bad = pg.not_a_person(v)
                if bad:
                    out.append(f"{rel}: `{f}`: {bad}")
        for f in ("requested_date", "answered_date"):
            if not pg.unstated(doc.get(f)) and pg.bad_date(doc.get(f)):
                out.append(f"{rel}: {f} {doc.get(f)!r} is not a YYYY-MM-DD date")
        for path_ in (("derivation", "reference"), ("result", "summary")):
            node = doc
            for k in path_:
                node = (node or {}).get(k) if isinstance(node, dict) else None
            if pg.unstated(node) or MARK in str(node):
                out.append(f"{rel}: status is {status!r} but {'.'.join(path_)} is unfilled — an "
                           f"answer with no derivation cannot be re-run, and one with no summary "
                           f"is not an answer")
        if str(doc.get("disclosure") or "") not in ("internal", "external"):
            out.append(f"{rel}: disclosure {doc.get('disclosure')!r} must be internal or external")

        # THE DERIVATION'S METHOD, which was never checked. `reference` was required and `method`
        # was not, so an answered record could carry a path with nothing saying what was run over
        # it — and a record with no `derivation` key at all passed, because the walk below returned
        # None and only `reference` was inspected.
        deriv = doc.get("derivation")
        if not isinstance(deriv, dict):
            out.append(f"{rel}: status is {status!r} with no `derivation:` block — an answer whose "
                       f"computation is unrecorded cannot be re-run or checked")
        elif pg.unstated(deriv.get("method")) or MARK in str(deriv.get("method")):
            out.append(f"{rel}: status is {status!r} but derivation.method is "
                       f"{deriv.get('method')!r} — a reference without a method says where the "
                       f"work lives, not what was run")

        # BUILD IDENTITY, for the answers that are only true of one build.
        kind = str((doc.get("result") or {}).get("kind") or "") if \
            isinstance(doc.get("result"), dict) else ""
        if kind not in RESULT_KINDS:
            out.append(f"{rel}: result.kind {kind or '(unstated)'!r} must be one of "
                       f"{list(RESULT_KINDS)} — whether the answer is a NUMBER decides how tightly "
                       f"it must be pinned, and it is stated rather than guessed")
        external = str(doc.get("disclosure") or "") == "external"
        if kind == "quantitative" or external:
            why = ("reports a number" if kind == "quantitative" else "leaves the group")
            cites = [c for c in (entry.get("cites_release") or []) if isinstance(c, dict)]
            unpinned = [c for c in cites
                        if not (str(c.get("build_id") or "").strip()
                                or str(c.get("manifest_sha256") or "").strip())]
            if not cites:
                out.append(f"{rel}: status is {status!r} and the answer {why}, but the registry "
                           f"entry cites no release at all — there is nothing to say which data "
                           f"produced it")
            for c in unpinned:
                out.append(f"{rel}: the answer {why}, and it cites {c.get('product')} "
                           f"{c.get('spec_version')} at PACK level. A specification is not a cut: "
                           f"two builds of it give two different answers. Pin `build_id` and/or "
                           f"`manifest_sha256` on the citation in products/registry.yaml.")

    # THE STALENESS RULE. Not "the old answer was wrong" — "this record still presents it as
    # current". `superseded` and `withdrawn` already say a person knows.
    stale = superseded_citations(root, entry)
    if stale and status == "answered":
        for slug, ver, why in stale:
            out.append(f"{rel}: answers against {slug} {ver}, which is superseded ({why}). Set "
                       f"status: superseded to record that this is known, or re-answer against the "
                       f"current cut — an answered record asserts the answer is still current.")
    return out


def check(root=None):
    """[(request_id, [errors])] for every registered request."""
    root = root or REPO
    return [(str(w.get("id") or "?"), record_errors(root, w) + sm.citation_errors(root, w))
            for w in _requests(root)]


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--new", metavar="ID", help="scaffold work/<ID>/REQUEST.yaml")
    ap.add_argument("--check", action="store_true", help="exit non-zero on any error")
    a = ap.parse_args(argv)

    # `is not None`, not truthiness: `--new ""` is a request to scaffold that must be REFUSED, and
    # under a truthiness test it fell through and silently ran the checker instead — a flag quietly
    # becoming a different command is how a script reports success for work it never did.
    if a.new is not None:
        rid = a.new.strip()
        if not rid or "/" in rid or os.path.sep in rid:
            print(f"REFUSED — {a.new!r} is not a usable request id", file=sys.stderr)
            return 1
        path = record_path(rid)
        if os.path.exists(path):
            print(f"REFUSED — {os.path.relpath(path, REPO)} already exists; a record is not "
                  f"regenerated, it is edited", file=sys.stderr)
            return 1
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8", newline="") as fh:
            fh.write(TEMPLATE.format(rid=rid))
        print(f"wrote {os.path.relpath(path, REPO)}")
        print(f"Now: answer every {MARK}, and register the request in products/registry.yaml under "
              f"`work:` with the release it reads — the citation lives there, not in the record.")
        return 0

    rows = check()
    if not rows:
        print("no requests registered (products/registry.yaml has no `work:` entry of kind request)")
        return 0
    bad = 0
    for rid, errs in rows:
        bad += len(errs)
        print(f"{rid:<30} " + ("OK" if not errs else f"{len(errs)} error(s)"))
        for e in errs:
            print(f"    {e}")
    print(f"\n{len(rows)} request(s); {bad} error(s)")
    return 1 if (a.check and bad) else 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
