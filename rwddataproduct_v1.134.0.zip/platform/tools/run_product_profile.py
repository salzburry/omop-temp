#!/usr/bin/env python3
"""Run the shared profiler over ANY pack's configured sources — one runner for every tumour.

    python3 platform/tools/run_product_profile.py products/oncology/prostate/202606 \
        --out-dir $HOME/restricted/prostate-202606

Why this exists rather than a wrapper per tumour. The profiler and the facts reporter are shared, but
the one-command entry point was `products/oncology/prostate/202606/profile/run_prostate_profile.py`,
which resolved its config with `product_config(root, "prostate")` — through the REGISTRY. Two
consequences:

  * Version coupling. The registry names ONE current spec version per tumour. That wrapper lives in
    the 202606 pack, but `products/registry.yaml` decides which pack it loads. A prostate 202607 pack
    already exists; the day the registry's `current_spec_version` becomes 202607, the runner stored
    under 202606 starts profiling the 202607 config while still presenting itself as the 202606
    runner. This runner takes the PACK PATH and reads the `config/data_product.yaml` beside it, so
    what it profiles is what you pointed it at.

  * Duplication. HNSCC, GIST, SCLC and DLBCL would each need their own copy, which is exactly the
    per-tumour duplication that moving data_profiler.R and profile_facts.py into the platform removed.

Restricted output. The profile carries top values and date min/max per column with no small-cell
floor, so a `count:1` entry is one patient — IHD under GSK R&D policy §9. `.gitignore` stops a
commit, not a read, so `--out-dir` is REQUIRED and is refused if it resolves inside the checkout.

Source-union packs. A profile covers ONE member schema, because `DC_SCHEMA` is per-run. Pass
`--member <schema>` to profile one, or `--all-members` to iterate every declared member. Each member
writes to its OWN directory (`<out-dir>/<product_id>/<schema>/<cut>/`) so a second member's run
cannot overwrite the first's evidence — the cut-only path they shared before.

stdlib + PyYAML; shells out to Rscript exactly once per member.
"""
import argparse
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from spec_extract import repo_relative                                  # noqa: E402
# The pack/cut/member/output questions are shared with run_product_schema_check.py — see pack_run.
import pack_run                                                      # noqa: E402
from pack_run import pack_config, union_members                      # noqa: E402

DEFAULT_PROFILER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data_profiler.R")


def resolve_tables(cfg):
    """The cut-suffixed physical table name for every configured source, so DC_TABLES scopes the
    profiler to EXACTLY this pack's sources rather than every table in the schema.

    `cfg.table()`, NOT `cfg.source_fqns()`. pack_config() has already pinned run.source_schema to
    the ONE member this invocation profiles, and table() honours it; source_fqns() deliberately
    ignores it and fans out to every union member (that is what preflight wants — fail fast on any
    member's missing table — and is exactly wrong here). With the Flatiron layout the fan-out is
    invisible, because `{schema}.{stem}_{refresh}` differs only in the schema that gets stripped
    off, so the members dedup to the same bare names. It stops being invisible the moment a product
    sets a run.source_layout that puts the schema INSIDE the table name (the template exposes
    {schema}, so `pre_{schema}_{stem}_{refresh}` is a legal layout): member A's run would then carry
    member B's physical table names and look for them in A's schema. One run, one member.
    """
    return sorted({cfg.table(s).split(".")[-1] for s in cfg.sources})


def main(argv=None):
    ap = argparse.ArgumentParser(description="Profile one product pack's configured sources.")
    ap.add_argument("pack", help="e.g. products/oncology/prostate/202606")
    ap.add_argument("--out-dir", help="restricted output ROOT, outside the checkout (required to run)")
    ap.add_argument("--cut", default=os.environ.get("DC_CUT"), help="delivered refresh, e.g. 2026m06")
    ap.add_argument("--schema", default=os.environ.get("DC_SCHEMA"), help="delivered source schema")
    ap.add_argument("--member", help="source_union member schema to profile (one run = one member)")
    ap.add_argument("--all-members", action="store_true", help="iterate every declared union member")
    ap.add_argument("--sample-n", default=os.environ.get("DC_SAMPLE_N", "2000"),
                    help="rows per table; 0 = exact (default 2000, screening)")
    ap.add_argument("--print-tables", action="store_true",
                    help="print the derived DC_TABLES and exit — reads no data, needs no R")
    ap.add_argument("--inventory-only", action="store_true",
                    help="confirm the tables and columns EXIST without reading a single data row. "
                         "The documented first step of Gate 3: run this before any profile, because "
                         "it proves the configured stems resolve against the delivered cut while "
                         "touching no patient data")
    ap.add_argument("--local-dir",
                    help="profile .csv/.parquet extracts from this directory instead of Databricks "
                         "(DC_SOURCE_MODE=local) — for a synthetic dry run of the whole path")
    a = ap.parse_args(argv)

    pack = os.path.abspath(a.pack)
    pack_run.config_path(pack)          # is this a pack at all? checked before anything else
    pack_run.require_cut(a.cut)
    # Which schemas this invocation will profile. For a non-union pack that is the single --schema.
    # --print-tables needs no real schema: it reads no data and only shows the derived table names.
    targets = pack_run.targets(pack, a, allow_unset=a.print_tables)

    if a.print_tables:
        # A union pack with no --member has no single schema to resolve in. Use the FIRST declared
        # member rather than a placeholder: under a layout that puts the schema inside the table name
        # a placeholder would print literal "SCHEMA" strings — silently wrong output for exactly the
        # case member scoping exists to handle. Say which member is being shown.
        schema = targets[0]
        if not schema:
            members = union_members(pack)
            schema = members[0] if members else "SCHEMA"
            if members:
                print(f"# tables as resolved in member '{schema}' — pass --member to pick another",
                      file=sys.stderr)
        print(",".join(resolve_tables(pack_config(pack, a.cut, schema))))
        return 0

    if not a.out_dir:
        sys.exit("--out-dir is REQUIRED and must be outside the checkout.\n"
                 "The profile carries top values and date ranges per column — IHD under R&D policy\n"
                 "§9 — so it must not be written into the repository working tree.\n"
                 "e.g. --out-dir $HOME/restricted/"
                 + "-".join(pack.replace(os.sep, "/").rsplit("/", 2)[-2:]))
    root = pack_run.restricted_dir(a.out_dir, what="profile output")

    # DOES THIS PRODUCT USE THE PROFILER AT ALL? The last gate before anything reads delivered data,
    # and deliberately AFTER the argument guards: it went first, and an unregistered fixture pack then
    # refused HERE instead of at `--out-dir is inside the checkout`, masking the guard this repo treats
    # as inviolable. One guard hiding another, for the fourth time; the ordering is the fix.
    #
    # The route is declared per vendor in governance/vendor_policy.yaml — one vendor's terms make a
    # profile the only way to establish that a column exists, another's may not — and
    # `product_gates.evidence_route` is the one answer. It fails CLOSED: an unknown vendor or an
    # unreadable policy refuses rather than defaulting to "run", because reading patient-level data is
    # not something to do on the grounds that nobody said not to. `--local-dir` is exempt: it profiles
    # synthetic fixtures and is already refused as Gate 3 evidence.
    import product_gates as _pg                                      # noqa: E402
    if not a.local_dir:
        _root = _pg.repo_root()
        _rel = repo_relative(pack, _root)
        _route, _why = _pg.evidence_route(_root, _rel)
        if _route != "data_profile":
            sys.exit(f"{_rel}: schema evidence for this product is {_route or 'UNDECLARED'} "
                     f"({_why}), not a data profile — refusing to read delivered data.\n"
                     f"  If that is wrong, change it where it is stated: {_pg.VENDOR_POLICY} for the "
                     f"vendor, or `evidence_route:` on the product's registry entry for one delivery "
                     f"under different terms. Do not pass a flag to get past this.")

    profiler = os.environ.get("DC_PROFILER") or DEFAULT_PROFILER
    if not os.path.exists(profiler):
        sys.exit(f"shared profiler not found at {profiler}")

    rc = 0
    for schema in targets:
        cfg = pack_config(pack, a.cut, schema)
        product_id = pack_run.product_id(cfg, pack)
        tables = resolve_tables(cfg)
        # No cut here: data_profiler.R appends it (`run_dir <- file.path(out_dir, cut_filter)`), so
        # the final location is <root>/<product_id>/<schema>/<cut>/ — passing it twice doubled it.
        # The isolation that matters is <schema>: the profiler's own default is <out>/<cut>/, so two
        # members of one union at the same cut wrote to the SAME file and the second overwrote the
        # first — two deliveries with one surviving piece of evidence and nothing recording it.
        out_dir = pack_run.evidence_dir(root, product_id, schema)
        env = {**os.environ,
               "DC_SCHEMA": schema, "DC_CUT": a.cut, "DC_TABLES": ",".join(tables),
               "DC_CATALOG": os.environ.get("DC_CATALOG", "hive_metastore"),
               "DC_SAMPLE_N": str(a.sample_n),
               "DC_OUT_DIR": out_dir,
               "DC_PRODUCT_ID": product_id}
        if a.inventory_only:
            env["DC_INVENTORY_ONLY"] = "1"
        if a.local_dir:
            env["DC_SOURCE_MODE"] = "local"
            env["DC_LOCAL_DIR"] = os.path.realpath(os.path.expanduser(a.local_dir))
        label = f"{product_id} · {schema} · {a.cut}"
        mode = ("INVENTORY ONLY — no data rows are read" if a.inventory_only
                else f"sample_n={a.sample_n}")
        print(f"Profiling {len(tables)} configured sources for {label} ({mode})\n"
              f"  -> {out_dir}")
        rc |= subprocess.run(["Rscript", profiler], env=env).returncode
    return rc


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
