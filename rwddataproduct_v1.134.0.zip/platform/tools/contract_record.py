#!/usr/bin/env python3
"""A structured record in, the canonical contract row out — with the round-trip proved.

A drafting model must not assemble the markdown row itself: put every field in
`TABLE_COLUMNS` order, escape any literal `|`, fold embedded newlines, and produce exactly the right
number of cells. Four mechanical rules, applied by hand, in a file where ONE unescaped pipe shifts
every later field into the wrong key — and where each shifted cell is still individually well-formed,
so no invariant sees it. At one record that is a nuisance; at a portfolio of several hundred per
product it is a defect generator, and the reviewer who reads the diff cannot reliably catch it.

So the model writes what it actually knows — field names and values — and this does the mechanics:

    python3 platform/tools/contract_record.py draft.yaml            # -> the row on stdout
    python3 platform/tools/contract_record.py draft.yaml --product products/oncology/oc/202606

`draft.yaml` is a mapping of contract field -> value; several records go under a `records:` key.
Values may be plain strings already in the contract's inline notation, or real YAML structures — `source: {kind: vendor, inputs:
{...}}` works either way, because `contract_lint.inline` serializes them to the same text.

WHAT IT PROVES, every time, which is the point of doing this in code:

  * every key is a real contract field (an unknown one is an error, never dropped silently)
  * the row has exactly `len(TABLE_COLUMNS)` cells, checked with the lint's own splitter
  * every field ROUND-TRIPS: re-parsed out of the rendered row it is byte-identical to what went in

That last check is what makes this trustworthy rather than merely convenient. A renderer nobody
verifies is a second notation; this one is compared against the reader on every invocation.

With `--product` it also runs the record through the real invariants, so a draft that would fail
Gate 2 says so here rather than after it is pasted into a governed file.
"""
import argparse
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import contract_lint as cl                                          # noqa: E402
import product_gates as pg                                          # noqa: E402

# The status values a DRAFT may start at — an ALLOWLIST, per axis. Everything else on these axes
# records a HUMAN transition backed by evidence: somebody read the data dictionary, somebody compared
# the live schema, somebody accepted the profile. `contract_lint` accepts any value in its vocabulary
# on a structurally complete record, so on a mature pack a model could set `requirement: approved` and
# nothing would object; the skill has said "never write these" since its first version, which made the
# rule a sentence in a prompt.
#
# IT WAS A BLACKLIST — `HUMAN_ONLY`, naming the seven values a drafter may not set. That fails OPEN on
# the one event most likely to happen: `contract_lint` gaining an eighth. `FINE_SOURCE_AXES` was itself
# added after the coarse `source` axis, and `data_profile_check: reviewed` after that; each time, a
# blacklist would have kept passing while a new human verdict became assertable by a drafter, and
# nothing would have gone red. An allowlist refuses an unrecognised value by default, and
# `test_contract_lint` asserts every value in every vocabulary is on exactly one side of this line —
# so adding one to the lint fails a test until somebody decides which it is.
#
# Keyed by the status axis so the message can name what the value would be CLAIMING. The vocabularies
# themselves stay in `contract_lint`; this says which subset a machine may author, and the test holds
# the two together. `implementation` is deliberately absent: it is a fact about the code, checkable by
# reading it, not a verdict anyone signs.
DRAFTABLE = {
    "requirement":        {"draft", "decision_required"},
    "source":             {"unverified", "dictionary_only", "unavailable"},
    "source_mapping":     {"proposed"},
    "dictionary_check":   {"not_run", "failed", "not_available"},
    "live_schema_check":  {"not_run", "failed"},
    "data_profile_check": {"not_run", "issue_open"},
    "validation":         {"not_run", "failed", "passed_test", "passed_synthetic"},
}

# THE STATUS OF A NEW RECORD, injected rather than accepted. The allowlist above was the second
# attempt and is still the wrong shape: `failed`, `passed_test`, `issue_open`, `dictionary_only` are
# all inside it, and all four are EVIDENCE CLAIMS — statements that a check ran and came back a
# certain way. A drafter has no basis for any of them. It has read a specification row; it has not run
# a test, opened a dictionary or looked at a profile.
#
# So a NEW record does not carry `status` at all, and this is what it gets. A REVISION keeps whatever
# the existing record holds, because moving a status is an evidence transition somebody else makes.
# That leaves the model with no reason to reason about status, which is the point: the safest field is
# the one nobody has to be trusted with.
INITIAL_STATUS = {"requirement": "draft", "source": "unverified",
                  "implementation": "not_implemented", "validation": "not_run"}


def _status_map(record):
    """The record's `status` as a dict, whichever notation it is written in, or None when absent."""
    status = record.get("status")
    if isinstance(status, str):
        # the inline notation the contract stores: `{requirement: draft, source: unverified, ...}`
        return {k.strip(): v.strip() for k, v in
                (p.split(":", 1) for p in status.strip("{} ").split(",") if ":" in p)}
    return status if isinstance(status, dict) else None


def _record_table_end(text):
    """Byte offset just past the last row of the FIRST record table, or None when there is none.

    The record table is the one whose header names `variable_id` — the packs carry other tables
    (registers, findings) that must not receive record rows."""
    offset, in_table = 0, False
    end = None
    for line in text.splitlines(keepends=True):
        stripped = line.strip()
        if not in_table:
            # The header row NAMES variable_id in its first cell — prose tables that merely mention
            # the word (the pack preamble's "where to look" table does) must not be mistaken for it.
            if re.match(r"\|\s*variable_id\s*\|", stripped):
                in_table = True
                end = offset + len(line.rstrip("\n").rstrip("\r"))
        else:
            if stripped.startswith("|"):
                end = offset + len(line.rstrip("\n").rstrip("\r"))
            else:
                break
        offset += len(line)
    return end


def upsert(text, records):
    """The contract text with each record REPLACED where its variable_id exists, appended where not.

    IDEMPOTENT by construction: the second run finds the row it wrote and replaces it with itself, so
    `upsert(upsert(t, r), r) == upsert(t, r)`. That property is the whole reason this is a function
    and not a paste — a drafter who runs the command twice, or re-runs it after fixing an unrelated
    field, must not end up with two rows for one variable. Two rows fail I1, but only after they are
    already in a governed file that somebody has to hand-repair.

    ONE DEFINITION for two callers. `--product` stages this into a temp copy and runs the real lint
    over it; `--apply` writes the same bytes to the real contract. If those were separate code the
    check would eventually be validating a different edit from the one performed — which is the most
    expensive possible bug in a tool whose entire promise is "what passed is what was written".

    REPLACE, don't append, when the id already exists. Appending was right for a new record and wrong
    for the revision case the skill explicitly supports: the copy then held two records with one
    variable_id, so a valid replacement failed I1 as a duplicate and the tool refused the thing it
    was built to check.
    """
    ids = [str(r.get("variable_id", "")).strip() for r in records]
    existing = {}
    for line in text.splitlines():
        m = re.match(r"\|\s*([A-Za-z0-9_]+)\s*\|", line)
        if m and m.group(1) in ids:
            existing[m.group(1)] = line
    for rec, vid in zip(records, ids):
        if vid in existing:
            text = text.replace(existing[vid], cl.render_row(rec))
    fresh = [r for r, v in zip(records, ids) if v not in existing]
    if fresh:
        # INTO the existing record table, not a new one per call. Appending a fresh table each run
        # left a pack drafted one --item at a time holding 36 one-row tables with 36 repeated
        # headers — parseable (records() reads every table) but not the "rows of one markdown
        # table" the docs promise, and unreadable as a document. New rows join the first table
        # whose header names variable_id; only a contract with no record table yet gets one.
        end = _record_table_end(text)
        rows = "\n".join(cl.render_row(r) for r in fresh)
        if end is None:
            text += "\n" + cl.render_table(fresh)
        else:
            text = text[:end] + "\n" + rows + text[end:]
    return text


def requirement_changes(record, existing_block):
    """{field: (was, now)} for the parts of the REQUIREMENT this revision moves. Empty = a tidy-up.

    The question being answered is narrow and it decides whether a human's approval still applies:
    does this revision change WHAT THE VARIABLE IS? If it does, `requirement: approved` and
    `validation: passed_live` on the existing record are claims about text that is being replaced,
    and carrying them forward silently transfers a signature onto words nobody signed.

    `contract_lint.REQUIREMENT_FIELDS` is the definition, not a list repeated here — it already
    exists as I17's "fields that carry the rule's own answer", which is the same question asked for
    a different reason. `spec_digest` is added because the SPECIFICATION can move underneath an
    otherwise identical judgment, and that is a requirement change the judgment fields cannot show.

    DELIBERATELY NOT every field. `notes`, `implementation_refs` and `output.physical_name` change
    for editorial and plumbing reasons, and a rule that reopened approval for a typo would be
    routed around within a week — which costs more than the narrow rule it replaced.
    """
    if not existing_block:
        return {}
    out = {}
    for field in sorted(cl.REQUIREMENT_FIELDS | {"spec_digest"}):
        if field not in record:
            continue                       # not restated by this revision, so not moved by it
        was = (cl._scalar(existing_block, field) or "").strip()
        # NORMALISED THE WAY THE RENDERER NORMALISES, not `str()`. A judgment file may write a value
        # as real YAML or in the contract's inline notation — REFERENCE.md says so explicitly — and
        # `render_row` puts both through `inline()` before they become a cell. Comparing `str()`
        # against the stored cell therefore compared a Python repr with the contract's own notation:
        # `{'same_day': 'n/a'}` against `{same_day: n/a}`. Identical values, reported as a changed
        # requirement, resetting an approval nobody asked to reset — and only for drafters who used
        # the YAML form, so it would have looked like an intermittent fault in the tool.
        now = str(cl.inline(record[field])).strip()
        # `was != now`, NOT `was and was != now`. The guard was there to stop a field the existing
        # record never carried from counting as a change — but it also swallowed the direction that
        # matters most: BLANK BECOMING POPULATED. A record approved while its `missing` cell was
        # empty says "unstated"; a revision that fills it in states a rule the approver never saw,
        # and the old condition was false, so `requirement: approved` and `validation: passed_live`
        # rode across onto meaning nobody signed. Silent, and in the direction of more approval.
        #
        # The case the guard was protecting is already handled above: a field this revision does not
        # restate is skipped by the `field not in record` continue, so reaching here means the
        # drafter supplied the field explicitly. Blank -> value is then a statement, not an absence.
        if was != now:
            out[field] = (was, now)
    return out


def apply_status(record, current=None, dec_open=None, reopen=None):
    """(record with `status` settled, [problems]) — the tool owns the field, not the drafter.

    Three cases, and none of them is "the model chose":

      * the drafter supplied none and there is no existing record -> INITIAL_STATUS;
      * the drafter supplied none and a record EXISTS            -> keep what the record holds,
        because a status transition is an evidence decision made elsewhere;
      * the drafter supplied one                                 -> refuse it, and say which.

    Refusing rather than silently overwriting: a drafter that wrote a status meant something by it, and
    quietly replacing the value would hide a disagreement about what the record claims. The message is
    the useful half.

    Then TWO DERIVATIONS on top of the settled value, because "keep what it holds" is wrong in two
    specific ways that no drafter could work around:

    `decision_required` (dec_open). A new record citing an OPEN decision got `requirement: draft`
    from INITIAL_STATUS and was then rejected by I11, which requires `decision_required` for exactly
    that record. Supplying it instead hit the refusal above. NO VALID INPUT SATISFIED BOTH — the
    single most common shape this tool exists to produce could not be produced. It is derived, from
    `contract_lint.blocking_decisions`, which is the same function I11 checks with; the drafter
    still writes nothing, and the two ends cannot drift because there is only one of them.

    `reopen`. A REVISION keeping the existing status is right when the record is being tidied and
    catastrophically wrong when its REQUIREMENT changed: `requirement: approved, validation:
    passed_live` then survives on a record whose rule now says something else, and the claim "a human
    approved this" silently transfers to text that human never read. So a caller that detects a
    material change passes the reason, and the human-signed axes fall back to INITIAL_STATUS while
    everything else is kept. Fail-closed: re-approval is cheap, an unnoticed stale approval is the
    failure this whole framework exists to prevent.
    """
    given = _status_map(record)
    if given is not None:
        return record, [
            f"status is not yours to write. A draft gets {INITIAL_STATUS} and a revision keeps the "
            f"status the existing record already holds — moving it is an evidence transition an "
            f"accountable person makes in the governed file, under the review CODEOWNERS routes. "
            f"Remove `status` from the draft."]
    settled = dict(current) if current else dict(INITIAL_STATUS)
    dids = record.get("decision_ids") or []
    if isinstance(dids, str):
        dids = [d.strip() for d in dids.strip("[] ").split(",") if d.strip()]
    blocking = cl.blocking_decisions([str(d).strip() for d in dids], dec_open) if dec_open else []
    # ONE DIRECTION ONLY. An open decision forces `decision_required`; a record already at `approved`
    # with no open decision is left alone, because moving it OFF that value is the evidence
    # transition this function refuses on the drafter's behalf.
    newly_blocked = bool(blocking) and settled.get("requirement") != "decision_required"

    # ...AND THE DOWNSTREAM AXES COME BACK WITH IT. Moving `requirement` to `decision_required` while
    # leaving `validation: passed_live` produces a record I12 REFUSES — a value validated against a
    # rule whose requirement is no longer settled — and the drafter had no legal way to fix it,
    # because the whole field is the tool's. So the tool produced a state the lint rejects, which is
    # the same class of dead end as the one this function was written to close.
    #
    # It is the same reset a material requirement change performs, and for the same reason: the
    # evidence describes a requirement that no longer stands. Sharing the rule rather than adding a
    # second one means "what does an unsettled requirement invalidate" has one answer.
    #
    # TRANSITION ONLY. A record already `decision_required` on the same open decision is being tidied,
    # not reopened, so re-running the command does not keep resetting evidence.
    if (reopen or newly_blocked) and current:
        settled.update(INITIAL_STATUS)
    if blocking:
        settled["requirement"] = "decision_required"
    out = {**record, "status": "{" + ", ".join(f"{k}: {v}" for k, v in settled.items()) + "}"}
    return out, []


def human_only_errors(record):
    """[problems] for any status value a DRAFT may not start at. Empty for an ordinary draft.

    Note what this is NOT. `--actor human` does not make these legal because a flag cannot establish
    who is running a process — the same caller that would misreport the value also passes the flag.
    What governs a human transition is that it lands in `FUNCTIONAL_CONTRACT.md`, which CODEOWNERS
    routes for review; this refuses the shape by default so that reaching it takes a deliberate act
    somebody has to name.
    """
    status = record.get("status")
    if isinstance(status, str):
        # the inline notation the contract stores: `{requirement: draft, source: unverified, ...}`
        status = {k.strip(): v.strip() for k, v in
                  (p.split(":", 1) for p in status.strip("{} ").split(",") if ":" in p)}
    if not isinstance(status, dict):
        return []
    out = []
    for axis, allowed in DRAFTABLE.items():
        value = str(status.get(axis, "")).strip()
        if value and value not in allowed:
            out.append(f"status.{axis}: {value} is not a value a DRAFT may start at "
                       f"({', '.join(sorted(allowed))}). It records a human transition backed by "
                       f"evidence, or it is not a value this axis takes at all. Draft at the initial "
                       f"value and let the accountable person move it, in the governed file, under "
                       f"the review CODEOWNERS routes.")
    return out


# The coarse axis's mechanical expansion. `unverified` states no evidence on any of the four finer
# questions, so its translation is exactly the four no-evidence values — nothing is claimed that the
# coarse word did not already claim. Any OTHER coarse value is a human's assertion and is NOT
# translated: re-stating `verified` in four words would put evidence claims in each of them.
FINE_DEFAULTS = {"source_mapping": "proposed", "dictionary_check": "not_run",
                 "live_schema_check": "not_run", "data_profile_check": "not_run"}
AXIS_ORDER = ("requirement", "source", "source_mapping", "dictionary_check", "live_schema_check",
              "data_profile_check", "implementation", "validation")
# What --apply-verdicts may write, and ALL it may write. requirement / implementation / validation
# are human or build transitions; dictionary_check and data_profile_check have no committed evidence
# producer yet, so a script setting them would be asserting evidence with nothing behind it.
VERDICT_WRITABLE = ("live_schema_check", "source_mapping")


def _render_status(st):
    ordered = [k for k in AXIS_ORDER if k in st] + [k for k in st if k not in AXIS_ORDER]
    return "{" + ", ".join(f"{k}: {st[k]}" for k in ordered) + "}"


def apply_verdicts(product, union_member=None):
    """(changes, notes, errors, new_text) — settle what the evidence settles, name what it cannot.

    The half of WORKFLOW.md §7 no tool performed: "scripts set … `live_schema_check` from their own
    evidence". Three writes, each from a committed artifact and none from a flag:

      * coarse -> fine migration: `source: unverified` becomes the four finer axes at their
        no-evidence values — a pure vocabulary translation. Any other coarse value is a human's
        claim and is reported for the human to re-state, never translated.
      * `live_schema_check` from the verdict report's GENERATED `live_schema_verdicts:` block
        (source_check owns the derivation; this consumes the producer surface, never the rendered
        tables). `passed` and `failed` both land — evidence is applied in whichever direction it
        points. `inconclusive` and `record_defect` set nothing and are named.
      * `source_mapping: human_confirmed` transcribed from the hand-typed, rationale-bearing
        `confirmed_mappings:` block — the accepted_collisions pattern. The block is the judgment;
        this moves it into the contract. A confirmation already recorded is never revoked by its
        absence from a later block.

    Everything else on `status` is untouchable from here by construction (`VERDICT_WRITABLE`), and
    rows not named change by zero bytes. All-or-nothing: any defect and nothing is written.
    """
    import source_check
    contract = os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(contract):
        return [], [], [f"{product} has no handoff/FUNCTIONAL_CONTRACT.md"], None
    text = cl.read(contract)
    verdicts = source_check.live_schema_verdicts(product, union_member)
    confirmed = source_check.confirmed_mappings(product, union_member)

    changes, notes, errors = [], [], []
    want = {}
    seen = set()
    for block in cl.records(text):
        vid = (cl._scalar(block, "variable_id") or "").strip()
        seen.add(vid)
        st = _status_map({"status": cl._inline(block, "status")})
        if st is None:
            errors.append(f"{vid}: status is not readable — fix the record before applying verdicts")
            continue
        new = dict(st)
        acts = []
        if "source" in new:
            if new["source"] == "unverified":
                del new["source"]
                new.update(FINE_DEFAULTS)
                acts.append("migrated coarse `source: unverified` to the four finer axes")
            else:
                notes.append(f"{vid}: carries coarse `source: {new['source']}` — a human's claim; "
                             f"re-state it in the finer axes by hand (WORKFLOW.md §7)")
                continue
        if all(k in new for k in FINE_DEFAULTS):
            v = verdicts.get(vid)
            if v in ("passed", "failed") and new["live_schema_check"] != v:
                new["live_schema_check"] = v
                acts.append(f"live_schema_check: {v} (from the verdict report)")
            elif v == "record_defect":
                notes.append(f"{vid}: the verdict report found a defect in the record's own source "
                             f"shape — nothing well-formed to verify; fix the record")
            elif v == "inconclusive":
                notes.append(f"{vid}: the profile could not speak to every column — inconclusive, "
                             f"left at {new['live_schema_check']}")
            if vid in confirmed and new.get("source_mapping") != "human_confirmed":
                new["source_mapping"] = "human_confirmed"
                acts.append("source_mapping: human_confirmed (from the confirmed_mappings block)")
        if acts:
            want[vid] = _render_status(new)
            changes.append((vid, "; ".join(acts)))
    for vid in sorted(set(verdicts) - seen):
        notes.append(f"{vid}: the verdict report names it but the contract has no such record")
    if errors:
        return [], notes, errors, None
    if not want:
        return [], notes, [], None

    seg = cl.TABLE_COLUMNS.index("status") + 1
    lines = text.splitlines(keepends=True)
    applied = set()
    for i, line in enumerate(lines):
        if not line.startswith("|"):
            continue
        # `(?<!\\)\|` — the split every reader of this table uses. A cell may hold an ESCAPED pipe
        # (`\|`), and a naive split would shift every cell after it by one, landing the status in a
        # neighbouring column. The escaped pipe stays inside its segment, so the join restores it.
        parts = re.split(r"(?<!\\)\|", line.rstrip("\n"))
        first = (parts[1] if len(parts) > 1 else "").strip()
        if first not in want:
            continue
        if len(parts) - 2 != len(cl.TABLE_COLUMNS):
            errors.append(f"{first}: its row has {len(parts) - 2} cells, not "
                          f"{len(cl.TABLE_COLUMNS)} — not rewritten")
            continue
        parts[seg] = f" {want[first]} "
        lines[i] = "|".join(parts) + "\n"
        applied.add(first)
    missing = set(want) - applied
    if missing:
        errors.append(f"row(s) {sorted(missing)} were parsed as records but not found as table "
                      f"rows — nothing should be written")
    if errors:
        return [], notes, errors, None
    new_text = "".join(lines)
    # the round-trip: what the gates will read is exactly what was decided here
    for block in cl.records(new_text):
        vid = (cl._scalar(block, "variable_id") or "").strip()
        if vid in want:
            got = _render_status(_status_map({"status": cl._inline(block, "status")}) or {})
            if got != want[vid]:
                return [], notes, [f"{vid}: rewrote status but read back {got!r}, wanted "
                                   f"{want[vid]!r} — nothing was written"], None
    return changes, notes, [], new_text


def row_for(record, allow_partial=False):
    """(row, [problems]) — the canonical row, and anything wrong with it.

    COMPLETE BY DEFAULT. The first version compared only the keys the caller supplied, so a record
    missing half the canonical fields rendered to empty cells and reported nothing — a governed draft
    silently short of the schema, which the real I6 would have caught but only when `--product` was
    passed, and that flag was documented as optional. A partial record is not a successful default.

    `allow_partial` exists for renderer testing, where the point is one field's escaping rather than a
    whole record. It is not for drafting.
    """
    row = cl.render_row(record)                       # raises on an unknown field
    cells = re.split(r"(?<!\\)\|", row.strip())[1:-1]
    problems = []
    if not allow_partial:
        missing = [k for k in cl.TABLE_COLUMNS if not str(record.get(k, "")).strip()]
        if missing:
            problems.append(f"incomplete: no value for {', '.join(missing)} — every canonical field "
                            f"is answered or the record is not one. `n/a` and `[]` are answers; "
                            f"absent is not")
    if len(cells) != len(cl.TABLE_COLUMNS):
        problems.append(f"rendered {len(cells)} cells for {len(cl.TABLE_COLUMNS)} columns")

    # THE round-trip. Re-read the row through the same parser every gate uses, and compare field by
    # field against what the caller supplied. A renderer checked only by eye is a second notation.
    back = list(cl.records(cl.render_table([record])))
    if len(back) != 1:
        problems.append(f"the rendered table re-parsed as {len(back)} records, not 1")
        return row, problems
    parsed = {ln.split(":", 1)[0]: ln.split(":", 1)[1].strip()
              for ln in back[0].splitlines() if ":" in ln}
    for key, value in record.items():
        want = cl.pipe(cl.inline(value))              # folded and escaped, as the cell will hold it
        want = cl._unpipe(want).strip()               # ...and unescaped again, as a reader sees it
        got = parsed.get(key, "")
        if want and got != want:
            problems.append(f"{key} did not round-trip: wrote {want!r}, read back {got!r}")
    return row, problems


def merge_evidence(record, product, item_id=None):
    """(record with the spec's own fields filled in, [problems]) — the scaffold supplies the evidence.

    THE INTERFACE CHANGE THIS EXISTS FOR. `spec_refs`, `spec_digest` and `required_rule` are established
    by the spec pipeline, and the skill has always said so: "pass them through, never author them". But
    the tool accepted the whole record from the model, so that rule was a sentence in a prompt. A model
    that retypes a digit of the digest fails I15 with a message about hashing; one that tidies
    `required_rule` into better English replaces the spec's exact words with a paraphrase and nothing
    fails at all — the record reads well and no longer says what RWB wrote.

    So the drafter supplies JUDGMENT only, names the row, and this fills the rest in from
    `contract_scaffold.evidence_for`. Supplying a machine-owned field is an ERROR rather than an
    override: an override is how the rule comes back to being advisory.
    """
    import contract_scaffold as cs                                    # noqa: E402
    supplied = [k for k in cs.MACHINE_OWNED if k in record]
    if item_id is None:
        # No --item: the caller is passing evidence through by hand. LEGAL ONLY for a pack with no
        # extraction, and `main` enforces that — a generic no-item path was a bypass straight around
        # this whole function, since `--product` alone let a drafter hand-write `required_rule` and
        # only a wrong DIGEST would have been caught.
        return record, []
    if supplied:
        return record, [f"machine-owned field(s) {', '.join(supplied)} supplied alongside --item "
                        f"{item_id} — these come from the spec, not from the drafter. Remove them; "
                        f"the tool fills them in from the extraction."]
    try:
        evidence = cs.evidence_for(product, item_id)
    except (KeyError, OSError) as exc:
        return record, [str(exc)]
    # A REDACTED ROW MAY NOT BE DRAFTED HERE AT ALL. The cell reproduced vendor documentation and was
    # removed from the artifact AI reads; the rule survives only in the pack's restricted reference
    # material. The slice already SAYS so, and saying so is a prompt instruction — a model can still
    # produce a complete-looking judgment over the row and pass every invariant, because
    # `VENDOR_REDACTED` is deliberately not in I17's unsettled set (it means the spec DOES settle
    # this, elsewhere). Refusing here is the mechanical half.
    if any("VENDOR DOCUMENTATION REDACTED" in str(v) for v in evidence.values()) \
            or "VENDOR_REDACTED" in " ".join(evidence.get("_lint_flags") or []):
        return record, [
            f"{item_id} carries VENDOR_REDACTED: its rule reproduced vendor documentation and is not "
            f"in this artifact. No drafted record may be rendered from it. An authorized human must "
            f"review the restricted reference material and maintain this record separately."]
    # EVIDENCE LAST, so it wins. The guard above is the control — a machine-owned field in the draft
    # is an error and never reaches here — and this is defence in depth behind it: if that guard is
    # ever loosened, the failure mode becomes "the drafter's value is ignored" rather than "the
    # drafter's paraphrase silently replaces the spec's words", and only one of those is survivable.
    merged = dict(record)
    merged.update({k: v for k, v in evidence.items() if not k.startswith("_")})
    return merged, []


def load(path):
    """The draft, as a list of record mappings.

    Through `product_gates.read_yaml` — the ONE reader of a governed YAML file — not a local
    `yaml.safe_load`. The repo's own guard caught this file doing the latter, and the reason is worth
    stating: PyYAML raises a plain ValueError from inside its date constructor on something like
    `classified_date: 2026-13-45`, so a per-caller `except yaml.YAMLError` reports a defect in the
    input as a crash of the tool. A drafting model's output is exactly where malformed YAML arrives.

    `read_yaml` requires a MAPPING root, which is why several records go under a `records:` key rather
    than as a bare list — one accepted shape, and the one the shared reader already guarantees.
    """
    doc, err = pg.read_yaml(path)
    if err:
        raise SystemExit(f"{path}: {err}")
    if "records" in doc:
        recs = doc["records"]
        if not isinstance(recs, list) or not all(isinstance(d, dict) for d in recs):
            raise SystemExit(f"{path}: `records:` must be a list of field mappings")
        return recs
    return [doc]


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("draft", nargs="?",
                    help="YAML mapping of contract field -> value; several under a `records:` key. "
                         "Not used with --apply-verdicts.")
    ap.add_argument("--apply-verdicts", action="store_true",
                    help="settle each record's evidence-fed status axes from the pack's committed "
                         "verdict report: migrate `source: unverified` to the finer axes, set "
                         "live_schema_check from the generated live_schema_verdicts block, and "
                         "transcribe hand-typed confirmed_mappings into source_mapping. Writes "
                         "nothing else, and nothing at all on any defect.")
    ap.add_argument("--union-member", help="with --apply-verdicts: read SOURCE_VERDICTS.<member>.md")
    ap.add_argument("--product", help="the pack. REQUIRED for drafting — see --format-only.")
    ap.add_argument("--item", help="the spec row this record is drafted from, `<domain>:<row>`. The "
                                   "spec's own fields (spec_refs, spec_digest, required_rule) are then "
                                   "filled in from the extraction and REFUSED in the draft.")
    ap.add_argument("--legacy-no-extraction", action="store_true",
                    help="the pack has no spec_pipeline extraction, so the evidence fields must be "
                         "passed through by hand. Refused when an extraction exists.")
    # `--actor` IS GONE. It declared who was authoring and could not establish it — the same caller
    # that would misreport it also passed it — so it read as an authorization check while being a
    # string. With status owned by the tool there is nothing for it to gate: a draft cannot write a
    # status at all, and moving one is done in the governed file under review.
    ap.add_argument("--format-only", action="store_true",
                    help="render and round-trip WITHOUT a pack: no invariants, no evidence merge. For "
                         "renderer testing and for a pack with no extraction. Not for governed "
                         "drafting — I8, I15, I17 and every pack-specific rule are skipped.")
    ap.add_argument("--table", action="store_true", help="emit a full table with header, not bare rows")
    ap.add_argument("--json", action="store_true", help="emit {row, problems} as JSON")
    ap.add_argument("--allow-partial", action="store_true",
                    help="renderer testing only: skip the completeness check. Not for drafting.")
    ap.add_argument("--apply", action="store_true",
                    help="write the record into <product>/handoff/FUNCTIONAL_CONTRACT.md, replacing "
                         "the row with this variable_id if one is there. Idempotent, atomic, and "
                         "refused unless the staged lint above passed. WITHOUT it the tool only "
                         "prints — which was the whole interface, and left the last step of a "
                         "governed edit to copy-and-paste.")
    a = ap.parse_args(argv)
    if a.apply_verdicts:
        if not a.product:
            ap.error("--apply-verdicts needs --product: the verdicts live in the pack.")
        if a.draft:
            ap.error("--apply-verdicts takes no draft: it reads the pack's own verdict report.")
        changes, notes, errors, new_text = apply_verdicts(a.product, a.union_member)
        for vid, act in changes:
            print(f"settle   {vid}: {act}")
        for n in notes:
            print(f"left     {n}")
        if errors:
            print(f"\nREFUSED — nothing was written. {len(errors)} defect(s):", file=sys.stderr)
            for e in errors:
                print(f"  {e}", file=sys.stderr)
            return 1
        if not changes:
            print("nothing to settle — the axes already say what the evidence says.")
            return 0
        path = os.path.join(a.product, "handoff", "FUNCTIONAL_CONTRACT.md")
        with open(path, "w", encoding="utf-8", newline="") as fh:
            fh.write(new_text)
        print(f"\nwrote {len(changes)} status change(s) into {path}")
        print("Next: re-run source_check so the report's contract sha256 matches the contract it "
              "now describes,\nthen a person sets reviewed_by/review_date in the report.")
        return 0
    if not a.draft:
        ap.error("a draft file is required (or --apply-verdicts).")
    if a.apply and not a.product:
        ap.error("--apply needs --product: there is no contract to write into without a pack.")

    # `--product` WAS OPTIONAL, AND THE SKILL DOCUMENTED IT IN BRACKETS. Completeness and the
    # round-trip run without it, which is what made that look sufficient — but I8 (do the cited rows
    # exist), I15 (does the digest still match), I17 (is an unsettled row answered), the decision and
    # gap reference checks and every other pack-specific invariant need the pack. A drafter following
    # the documented command got a clean-looking record that no gate had seen. So the pack is now the
    # default and its absence is a deliberate, named choice.
    if not a.product and not a.format_only:
        ap.error("--product is required for drafting: without it the record is only checked for shape, "
                 "and I8/I15/I17 — the invariants that catch a hallucinated citation, a stale digest "
                 "and an answered-but-unsettled row — never run. Pass --format-only to render without "
                 "a pack and accept that.")
    if a.item and not a.product:
        ap.error("--item needs --product: the spec evidence comes from that pack's extraction.")
    # --item IS REQUIRED WHENEVER THE PACK CAN SUPPLY EVIDENCE. Making it optional left the entire
    # machine-owned-field boundary opt-in: `--product` alone accepted a hand-written `spec_refs`,
    # `spec_digest` and `required_rule`, and only a wrong digest would have failed. A paraphrased
    # `required_rule` — the failure this interface exists to stop — passed silently.
    if a.product and not a.item and not a.legacy_no_extraction:
        if os.path.exists(os.path.join(a.product, "spec_pipeline", "out", "extracted.json")):
            ap.error("--item is required for a pack with an extraction: it is what supplies "
                     "spec_refs, spec_digest and required_rule from the spec instead of accepting "
                     "them from the drafter. Pass --item <domain:row>. "
                     "--legacy-no-extraction is the named opt-out, and is only honest for a pack "
                     "that genuinely has none.")
    if a.legacy_no_extraction and a.product and \
            os.path.exists(os.path.join(a.product, "spec_pipeline", "out", "extracted.json")):
        ap.error("--legacy-no-extraction was passed for a pack that HAS an extraction — the flag says "
                 "the evidence cannot be supplied, and here it can. Use --item.")

    records = load(a.draft)
    if a.item and len(records) != 1:
        raise SystemExit(f"--item names ONE spec row; this draft holds {len(records)} records. "
                         f"One record per spec row (I16) — run them separately.")
    # THE REFUSAL FIRST, before any work — a drafter who wrote a status is told so immediately rather
    # than after the evidence merge, and long before anything is rendered: a refusal after the row is
    # printed is no refusal at all, because a printed row gets pasted.
    for i, rec in enumerate(records):
        if _status_map(rec) is not None:
            _, bad = apply_status(rec)
            raise SystemExit(f"{a.draft}[{i}]: " + "; ".join(bad))

    if a.product:
        merged = []
        for i, rec in enumerate(records):
            import contract_scaffold as cs                                          # noqa: E402
            try:
                rec, bad = merge_evidence(rec, a.product, a.item)
            except cs.NotApprovedForAI as exc:
                # NOT folded into `bad`. A problem list is a report the caller reads and may act on;
                # this is a refusal, and the difference has to survive to the exit code. Raised from
                # `contract_scaffold.ai_gate`, which is where the spec's words are lifted — see there
                # for why the check is not in this function.
                raise SystemExit(str(exc))
            if bad:
                raise SystemExit(f"{a.draft}[{i}]: " + "; ".join(bad))
            merged.append(rec)
        records = merged

    # STATUS AFTER THE MERGE, because two of the three things that settle it are only knowable here.
    # `spec_digest` arrives from `--item` in the merge above, and it is how a REQUIREMENT CHANGE is
    # detected when the spec moved under an unchanged judgment; the pack's decision register is what
    # says whether a cited decision is open. Settling before the merge could see neither, which is
    # why a record citing an open decision was unproducible and a revision kept a stale approval.
    dec_open = {}
    if a.product:
        dec_path = os.path.join(a.product, "handoff", "DECISIONS.md")
        if os.path.exists(dec_path):
            dec_open = cl.decision_status(cl.read(dec_path))
    settled = []
    for i, rec in enumerate(records):
        current, existing = None, None
        contract = os.path.join(a.product or "", "handoff", "FUNCTIONAL_CONTRACT.md")
        if a.product and rec.get("variable_id") and os.path.exists(contract):
            # `cl.records` takes the TEXT, and this passed it the PATH — so it parsed a filename as a
            # contract, yielded nothing, and `existing` was None for every record that has ever
            # existed. The consequence is the exact opposite of what this promises: a REVISION did not
            # keep the status the record holds, it got INITIAL_STATUS. Revising a record at
            # `requirement: approved, implementation: implemented` silently rewrote it to `draft` /
            # `not_implemented` — a human evidence claim erased by a tool that says moving one is not
            # the drafter's to do.
            #
            # It hid behind a second bug: `records()` yields BLOCK TEXT, so `r.get(...)` would have
            # raised AttributeError — but the generator was empty, so the line never ran. Two errors
            # that cancel to a silent wrong answer, and the revision test asserts rc == 0 and
            # no-duplication, so it passed against both.
            existing = next((r for r in cl.records(cl.read(contract))
                             if (cl._scalar(r, "variable_id") or "").strip()
                             == str(rec["variable_id"]).strip()), None)
            current = _status_map({"status": cl._inline(existing, "status")}) if existing else None
        moved = requirement_changes(rec, existing)
        rec, bad = apply_status(rec, current, dec_open=dec_open, reopen=bool(moved))
        if bad:
            raise SystemExit(f"{a.draft}[{i}]: " + "; ".join(bad))
        # SAID OUT LOUD, always. Resetting an approval quietly is the same defect as keeping a stale
        # one: in both cases the record's status stops matching what anybody believes about it.
        if moved and current and any(current.get(k) != v for k, v in INITIAL_STATUS.items()):
            print(f"  REOPENED [{rec.get('variable_id')}] the requirement changed "
                  f"({', '.join(sorted(moved))}), so the evidence statuses this record held "
                  f"({', '.join(f'{k}: {v}' for k, v in current.items())}) describe text that is "
                  f"being replaced. They are back at {INITIAL_STATUS} and must be re-established.",
                  file=sys.stderr)
        settled.append(rec)
    records = settled
    rows, problems = [], []
    for i, rec in enumerate(records):
        try:
            row, bad = row_for(rec, a.allow_partial)
        except ValueError as exc:                     # an unknown field: name it and stop
            raise SystemExit(f"{a.draft}[{i}]: {exc}")
        rows.append(row)
        problems += [f"[{rec.get('variable_id', i)}] {b}" for b in bad]

    if a.product:
        # The real invariants, on a throwaway copy of the pack — so `--product` answers "would this
        # pass Gate 2 HERE", not "is it well-formed anywhere".
        import shutil
        import tempfile
        ids = [str(r.get("variable_id", "")).strip() for r in records]
        dupes = sorted({i for i in ids if i and ids.count(i) > 1})
        if dupes:
            raise SystemExit(f"{a.draft}: variable_id {', '.join(dupes)} appears more than once in "
                             f"this draft — one record per variable_id")
        if not os.path.exists(os.path.join(a.product, "handoff", "FUNCTIONAL_CONTRACT.md")):
            raise SystemExit(
                f"{a.product} has no handoff/FUNCTIONAL_CONTRACT.md — nothing to draft into. The "
                f"contract file is the drafter's to create, once, before the first record: write a "
                f"short header naming the product and what the file is (a sibling pack's opening "
                f"lines show the shape), commit nothing else into it, and re-run — the record "
                f"table itself is appended by this tool.")
        tmp = tempfile.mkdtemp()
        dst = os.path.join(tmp, os.path.basename(os.path.abspath(a.product)))
        shutil.copytree(a.product, dst)
        contract = os.path.join(dst, "handoff", "FUNCTIONAL_CONTRACT.md")
        with open(contract, encoding="utf-8") as fh:
            text = fh.read()
        with open(contract, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(upsert(text, records))
        errors, _ = cl.run(dst)
        shutil.rmtree(tmp, ignore_errors=True)
        problems += [e for e in errors if any(f"[{v}]" in e for v in ids if v)]

        # --apply: THE SAME BYTES, into the real file. The step this replaced was "copy the printed
        # row and paste it into FUNCTIONAL_CONTRACT.md", and a governed artifact maintained by
        # copy-paste fails in ways no invariant can see: a row pasted twice, pasted into the wrong
        # table, pasted with the terminal's line wrap in it, or a REVISION appended beside the record
        # it was meant to replace. Every one of those is a defect in the contract created by the
        # process for putting a validated record into it.
        #
        # Ordered so the write cannot happen unless the check passed: `problems` above is the real
        # lint over the staged copy, and a non-empty list stops here. Nothing is written on a pack
        # whose invariants the record would break.
        if a.apply:
            if problems:
                raise SystemExit(
                    f"--apply refused: this record does not pass Gate 2's invariants in {a.product}. "
                    f"Nothing was written.\n  " + "\n  ".join(f"PROBLEM {p}" for p in problems))
            real = os.path.join(a.product, "handoff", "FUNCTIONAL_CONTRACT.md")
            with open(real, encoding="utf-8") as fh:
                before = fh.read()
            after = upsert(before, records)
            # ATOMIC: write a sibling temp file and replace. A contract half-written by an interrupted
            # process is worse than one not written at all — the second is obvious and recoverable.
            fd, staging = tempfile.mkstemp(dir=os.path.dirname(real), suffix=".tmp")
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
                fh.write(after)
            os.replace(staging, real)
            print(f"  APPLIED  {', '.join(v for v in ids if v)} -> {real}"
                  + ("  (no change — already present in exactly this form)"
                     if after == before else ""), file=sys.stderr)

    if a.json:
        print(json.dumps({"rows": rows, "problems": problems}, indent=1))
    else:
        sys.stdout.write(cl.render_table(records) if a.table else "\n".join(rows) + "\n")
        for p in problems:
            print(f"  PROBLEM {p}", file=sys.stderr)
    return 1 if problems else 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
