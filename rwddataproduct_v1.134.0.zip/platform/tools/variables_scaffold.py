#!/usr/bin/env python3
"""Emit parameter skeletons for a pack's config, from the master inventory's slots.

    python3 platform/tools/variables_scaffold.py <pack>            # write the skeletons
    python3 platform/tools/variables_scaffold.py <pack> --check    # byte-compare, exit 1 on drift

WHAT THIS IS. The `master:` section of governance/reference/variable_inventory/INVENTORY.yaml defines the
cross-tumour core variables with named parameter SLOTS; the tumour's overlay in the same file says which of them this tumour's
published literature instantiates. This tool turns that into the config shapes the engine actually
reads — an `age_bands` list, a `baseline_ecog` block, an `overall_survival` block — with EVERY
value the ONE placeholder marker (`REPLACE_ME`), so a person copies a skeleton into the file that
governs it and fills it FROM THE APPROVED WORKBOOK. The machine produces the shape; the human stays
the author of every value, and `engine/validate.py` (strict mode, i.e. the build) refuses any pack
value still carrying the marker — a half-filled skeleton cannot build.

EACH SKELETON NAMES ITS OWN DESTINATION, because not every parameter family lives under
`variables/`. INDEX_DATE (`study`, `index_dates`, `cohorts`) and COHORT_ELIGIBILITY (`lot`,
`treatment_status`) parameterise the pack's ROOT `config/data_product.yaml` — INDEX_DATE alone is
30 of the 509 overlay variables, more than any other family. Emitting either as a `variables/`
block would have produced a skeleton that cannot be pasted anywhere the engine reads.

AND TWO FAMILIES ARE MOSTLY NOT CONFIG AT ALL. COHORT_ELIGIBILITY's confirmation rule (histology,
IHC, model-assisted selection) and SEX's `applicability` both describe the DELIVERED POPULATION,
governed at Gate 1 and Gate 3 — there is no config value for either, and their skeletons say so
before the first key rather than letting someone hunt for the slot.

WHAT THIS IS NOT. Not a configuration, and not a specification: the skeletons land in
`spec_pipeline/out/variables_scaffold/` (generated space), never in `variables/` or `config/`, and
nothing here authorises a variable into the product — the inventory is `reference_only` and the
workbook is the only specification. Blocks are emitted only for master entries the tumour's overlay
instantiates, so an MDS scaffold does not grow a line-outcomes block its literature never described.

Output is DETERMINISTIC (no timestamps), so `--check` is a byte-compare — the same generated-
artifact discipline every other `out/` artifact carries.
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
REPO = TOOLS.parent.parent
INVENTORY = REPO / "governance" / "reference" / "variable_inventory" / "INVENTORY.yaml"
OUT_DIR = os.path.join("spec_pipeline", "out", "variables_scaffold")
MARK = "REPLACE_ME"
# pack slug -> overlay stem, where they differ. Absent = same word.
SLUG_TO_OVERLAY = {"oc": "ovarian"}

HEADER = """\
# GENERATED PARAMETER SKELETON — variables_scaffold.py. Not a configuration, not a specification.
# Copy a block into {dest} and replace EVERY `{mark}` with the value the approved
# workbook states. The build (engine/validate.py, strict) refuses any pack value still carrying
# `{mark}`, so a half-filled skeleton cannot run. Scaffolded for the master entries the
# {slug} overlay instantiates: {masters}.
# NOT SCAFFOLDED (this tumour instantiates them, but no skeleton family exists yet — author these
# blocks by hand from the reference packs): {uncovered}.
# NOT EXPRESSIBLE IN CONFIG AT ALL — the engine has no family to configure, so there is nothing to
# author by hand either; these need ENGINE work first (see COVERAGE.md's engine_gap list, which IS
# the engineering backlog): {gaps}.
"""

# The master families a skeleton block exists for. Everything else an overlay instantiates is
# NAMED in the header as un-scaffolded — a skeleton that stays silent about what it does not
# cover reads as complete, which an external review called the overstatement it is.
SCAFFOLDED_MASTERS = frozenset({"AGE", "AGEGR1", "RACE_ETHNICITY", "PRACTICE_SETTING", "REGION",
                                "ECOG_PS", "SMOKING_STATUS", "DATA_CONTINUITY", "BMI_BSA",
                                "LAB_VALUES", "OS", "RWTTD", "TTNT", "RWPFS", "LINE_OF_THERAPY",
                                "INDEX_DATE", "COHORT_ELIGIBILITY", "SEX", "DEATH_DATE",
                                "INSURANCE_PAYER", "RW_RESPONSE",
                                "COMORBIDITY_INDEX"})


def _overlay(slug):
    stem = SLUG_TO_OVERLAY.get(slug, slug)
    # STRICT: a duplicate key in the inventory would load last-wins and scaffold from a shelf the
    # file never was.
    sys.path.insert(0, str(TOOLS.parent))
    from engine.strict_yaml import strict_load
    doc = strict_load(INVENTORY.read_text(encoding="utf-8"))
    entry = (doc.get("tumours") or {}).get(stem)
    if entry is None:
        raise SystemExit(f"no inventory overlay for tumour '{slug}' ({INVENTORY} tumours.{stem}) "
                         f"— add the overlay (governance/reference/variable_inventory/README.md) "
                         f"before scaffolding")
    return entry


def instantiated_masters(slug) -> set:
    return {v["master"] for v in _overlay(slug).get("variables", []) if v.get("master")}


def engine_gap_masters(doc=None) -> set:
    """Master families the engine cannot express AT ALL — `engine_gap` in every overlay that
    instantiates them.

    THE DISTINCTION THIS DRAWS is between "nobody has written a skeleton yet" and "there is nothing
    to write a skeleton for", and the header conflated them: it told a reader to author the missing
    blocks BY HAND FROM THE REFERENCE PACKS. For RW_RESPONSE that instruction cannot be followed —
    no reference pack states a response block, because no engine code reads one (`psa_timepoints`
    covers PSA thresholds and nothing else). Someone following it would author a block, paste it
    into `variables/`, watch it lint clean and pass every gate, and never get the variable: the
    exact contract-and-config-agree-while-the-engine-reads-neither failure this repo has already
    paid for once.

    Read across ALL tumours, not the pack's own overlay: whether the ENGINE has a family is a
    property of the engine, and a family one tumour marks `config_expressible` is expressible for
    every tumour. Derived from the inventory's own `coverage.class`, so adding the engine family
    and re-classing the entries is what retires the warning — there is no second list to remember.

    EVERY overlay, not any: a family classed `engine_gap` for one tumour and `engine_family` for
    another HAS an engine family, and reading "any gap" would strip its skeleton from every tumour
    that can use it. No such mixed family exists in the inventory today, which is exactly why the
    two readings are indistinguishable here and the test passes a synthetic `doc` to tell them
    apart — over the live file a wrong reading would look identical to a right one.
    """
    if doc is None:
        sys.path.insert(0, str(TOOLS.parent))
        from engine.strict_yaml import strict_load
        doc = strict_load(INVENTORY.read_text(encoding="utf-8"))
    classes = {}
    for entry in (doc.get("tumours") or {}).values():
        for v in entry.get("variables") or []:
            if isinstance(v.get("master"), str):
                classes.setdefault(v["master"], set()).add((v.get("coverage") or {}).get("class"))
    return {m for m, seen in classes.items() if seen == {"engine_gap"}}


# ---------------------------------------------------------------------------------------------
# The skeleton blocks, keyed by the master entry that earns them. Shapes mirror the engine's
# real config families (see the prostate/OC packs and engine/stages/*.py); values are the marker.
# ---------------------------------------------------------------------------------------------

# The ROOT config, `config/data_product.yaml` — not `variables/`. Read off engine/stages/index.py
# and engine/validate.py rather than off a pack, because a pack shows one tumour's answer and the
# engine states the contract: `validate` requires id/label/cohortn/index on every cohort and refuses
# an `index` that is neither `lot_start_date` nor a key of `index_dates`; `sources.py` materialises
# each index_dates model onto the index source as the key with underscores removed; `index.py`
# splits on the PRESENCE of `lot_number`, which is why the two cohort shapes below are separate.
ROOT_BLOCKS = {
    "INDEX_DATE": """\
# INDEX_DATE — master slot `convention`: which event anchors the cohort. THE MOST CONSEQUENTIAL
# PARAMETER IN THE PACK. Every eligibility window, every baseline window and every time-to-event
# endpoint is measured from it, so a wrong answer here is wrong in every downstream variable at
# once and none of them looks wrong on its own.
#
# Three blocks, all in the pack's ROOT config/data_product.yaml.

# 1. The index WINDOW. Patients enter only if their index date falls inside it.
#    Optional split fields when the dates genuinely differ (each defaults to index_end):
#    observation_end (id3mosfu's follow-up horizon) and data_cutoff (the delivery's cut, the
#    EDA date-sanity bound). Stating them is a study decision — RWB owns the endpoint meaning.
study:
  index_start: {m}            # YYYY-MM-DD
  index_end: {m}              # YYYY-MM-DD — the study close, NOT the data cut

# 2. The date MODELS. Each key becomes a column on the index source, named as the key with
#    underscores REMOVED (`advanced_diagnosis_date` -> advanceddiagnosisdate), built from `of:`.
#    `method: max` takes the greatest of the columns present — that is the only method the engine
#    implements, and with one present column the column IS the max. Name a model per index
#    convention the workbook defines; a dual-setting product (one tumour, two disease states)
#    needs one model per setting so each cohort anchors on its own date.
index_dates:
  {m}:                        # the model NAME, referenced by cohorts[].index / .diag below
    method: max
    of: [{m}]                 # column(s) on the index source
    # `source:` is ONLY read for a model literally named advanced_diagnosis_date, where it names
    # which declared source carries these columns (default: `enhanced`). Uncomment it there, and
    # nowhere else — on any other model key the engine never reads it.
    # source: {m}

# 3. The COHORTS. id / label / cohortn / index are REQUIRED on every one — validate refuses a
#    cohort missing any of them, a duplicate id or cohortn, and an `index` that is neither
#    `lot_start_date` nor a key you defined above.
#
#    THE PRESENCE OF `lot_number` IS THE SWITCH, not a naming convention: without it the engine
#    builds a diagnosis-anchored cohort, with it a line-anchored one. The two shapes are listed
#    separately because they read different keys.
cohorts:
  # (a) diagnosis-anchored — no lot_number. index_date IS the named model's date.
  - id: {m}
    cohortn: {m}              # the published COHORTN code
    label: {m}
    index: {m}                # a key of index_dates above
  # (b) line-anchored — index_date is the start of line N. `index: lot_start_date` is the engine's
  #     own literal and is NOT a model you define. `diag:` names the model whose date must ALSO
  #     fall in the study window: the spec gates a line cohort on BOTH. It defaults to
  #     `advanced_diagnosis_date`, so a pack whose model is named anything else MUST state it —
  #     otherwise patients are silently gated on a column that does not exist for them.
  - id: {m}
    cohortn: {m}
    label: {m}
    index: lot_start_date
    lot_number: {m}           # integer line number
    diag: {m}                 # a key of index_dates above
    # line_setting: {m}       # per-cohort disease setting; omit to inherit lot.line_setting
    # maintenance: {m}        # true/false only — omit unless the workbook states a maintenance rule
""",
    "COHORT_ELIGIBILITY": """\
# COHORT_ELIGIBILITY — master slot `confirmation`: what confirms membership, and which
# presentations are excluded.
#
# READ THIS BEFORE LOOKING FOR SOMEWHERE TO PUT THE CONFIRMATION RULE. There is nowhere, and that
# is not an omission. "Histologically confirmed", "IHC-confirmed", "CLL vs SLL designation",
# "model-assisted cohort selection with abstractor confirmation" — every one of those describes how
# the VENDOR built the delivery you were given. No engine code re-derives them and no config value
# states them: the pack receives a population that has already been confirmed. They are governed at
# Gate 1 (the registered source says which population it is) and Gate 3 (the source mapping says
# which delivered table carries it). So a workbook row stating a confirmation rule becomes a
# CONTRACT RECORD citing that row, with `source:` naming the delivered table — not a config block.
#
# What IS configurable is who survives from that delivered population into each cohort. Two blocks
# in the ROOT config/data_product.yaml, plus `cohorts:` itself (scaffolded under INDEX_DATE).

# 1. The LINE MODEL — which LOT rows count, before lines are numbered. Every line cohort's
#    membership follows from it, which is why it is eligibility and not merely treatment detail.
lot:
  line_setting: {m}           # keep only rows in this disease setting; omit for no filter
  exclude_settings: [{m}]     # settings DROPPED before numbering; omit or [] to drop none
  # `line_number` decides what "line N" MEANS, and the two readings give different cohorts:
  #   new_lot_n  - a row_number over the rows kept AFTER the filters above (the engine default)
  #   linenumber - the vendor's own raw line number, unaffected by those filters
  # They agree only when nothing was filtered out. A product that excludes a setting and then
  # indexes on `linenumber` is numbering lines it deliberately dropped. The engine accepts these
  # two spellings and no others.
  line_number: {m}            # new_lot_n | linenumber
  # Consulted ONLY when a cohort sets `maintenance:`. Omit the key entirely for a tumour with no
  # maintenance lines, rather than naming a column the feed does not carry.
  maintenance_column: {m}

# 2. TREATED vs UNTREATED (COHORTU / COHORTUN). "Treated" is derived from EVIDENCE — a patient with
#    at least one LOT row — never from a config flag. What config states is the label and code that
#    evidence publishes as. A dual-setting product keys them per setting under `by_setting`, so each
#    setting gets its own pair; a single-setting tumour states the four keys flat instead.
treatment_status:
  by_setting:
    {m}:                      # the cohort's line_setting, LOWER-CASED — that is the lookup key
      treated_label: {m}
      untreated_label: {m}
      treated_code: {m}
      untreated_code: {m}
""",
}

DEM_BLOCKS = {
    "AGEGR1": """\
# AGE / AGEGR1 — master slot `bands`: the eligibility floor and band edges. EVERY value is the
# marker — codes, labels, bounds AND the fallthrough row's code/label are workbook facts; a
# skeleton that pre-filled any of them would be authoring the parameter it exists to ask for.
age_bands:
  - {{ code: {m}, label: {m}, min: {m}, max: {m} }}
  - {{ when: fallthrough, label: {m}, code: {m} }}
""",
    "RACE_ETHNICITY": """\
# RACE_ETHNICITY — master slot `collapse`: the category scheme, unknown level included.
race_map:
  - {{ from: [{m}], label: {m}, code: {m} }}
  - {{ when: fallthrough, label: {m}, code: {m} }}
ethnicity_map:
  - {{ from: [{m}], label: {m}, code: {m} }}
  - {{ when: fallthrough, label: {m}, code: {m} }}
""",
    "PRACTICE_SETTING": """\
# PRACTICE_SETTING — community vs academic mapping (emitted only when a `practice` source exists).
practice_map:
  - {{ from: [{m}], label: {m}, code: {m} }}
  - {{ when: fallthrough, label: {m}, code: {m} }}
""",
    "REGION": """\
# REGION — master slot `region_map`: the state-to-region crosswalk.
regions:
  - {{ code: {m}, label: {m}, states: [{m}] }}
  - {{ when: fallthrough, label: {m}, code: {m} }}
""",
}

# `clinical.categoricals` is ONE list, and more than one master family contributes items to it.
# They are held here as ITEMS rather than as whole blocks because two families each emitting their
# own `categoricals:` key would produce a duplicate mapping key — which `strict_load` refuses, so
# the generated skeleton would not even parse. No tumour instantiates two of these today; the one
# that does would have found out by way of an unusable file.
CATEGORICAL_HEAD = """\
# clinical.categoricals — ONE list, one item per characteristic. Each maps a source column's values
# to a published label + code via the same CASE compiler `stage` uses.
categoricals:
"""

CATEGORICAL_ITEMS = {
    "SMOKING_STATUS": """\
  # SMOKING_STATUS — master slot `classification`. Unwindowed: the patient's smoking status is a
  # standing fact, so `pick` resolves multiple records by date, not by distance from index.
  - name: {m}
    column: {m}
    date_column: {m}          # omit if the source carries one row per patient
    pick: {m}                 # latest | earliest
    groups:
      - {{ from_equals_ci: [{m}], label: {m}, code: {m} }}
      - {{ when: missing, label: {m}, code: {m} }}
      - {{ when: fallthrough, label: {m}, code: {m} }}
""",
    "INSURANCE_PAYER": """\
  # INSURANCE_PAYER — master slot `window`: the window around index in which payer is read.
  #
  # WINDOWED, AND THAT IS THE WHOLE POINT. The payer that matters is the one IN FORCE AT INDEX; a
  # patient who switches to Medicare eighteen months later was still commercial for the line this
  # row describes. `window_days` makes the pick index-anchored — and therefore per cohort, so a
  # patient indexed twice can legitimately carry two different payers.
  #
  # Stating `window_days` without `date_column` is refused rather than ignored: with no date the
  # engine could only fall back to the patient's latest coverage ever, which is a different
  # variable wearing this one's name.
  - name: {m}
    column: {m}
    source: {m}               # the coverage/enrollment source; omit to read the index source
    date_column: {m}          # REQUIRED whenever window_days is set
    window_days: [{m}, {m}]   # day offsets from index; either may be null for open-ended
    pick: {m}                 # nearest (default) | earliest | latest | priority
    groups:                   # one row per published payer category, plus the terminal fallthrough
      - {{ from_equals_ci: [{m}], label: {m}, code: {m} }}
      - {{ when: fallthrough, label: {m}, code: {m} }}
""",
}

CLIN_BLOCKS = {
    "ECOG_PS": """\
# ECOG_PS — master slot `window`: the lookback/lookahead around index, the date tie-break, and
# the delivered-value -> published-code map. `tie_break` is the ENGINE's exact vocabulary
# (earliest_date | latest_date) — the worst-grade rank then breaks a same-date tie, always.
baseline_ecog:
  window_days: [{m}, {m}]
  tie_break: {m}              # earliest_date | latest_date — which same-gap DATE wins
  missing_label: {m}
  missing_code: {m}
  value_codes:                # delivered ecog value -> published ecogn code, one line per value
    "{m}": {m}
""",
    "DATA_CONTINUITY": """\
# DATA_CONTINUITY — the observability floor (minavaildate / basedur). Each source names ITS date
# column — the engine reads `{{source, date_column}}` mappings, never bare source names.
min_avail_date:
  base_columns: [{m}]
  sources:
    - {{ source: {m}, date_column: {m} }}
""",
    "BMI_BSA": """\
# BMI_BSA — master slots `pairing` + `methods` + `bands`. The formula is a NAMED registry
# method (engine/stages/clinical.py BMI_FORMULAS / BSA_FORMULAS) — never restated here.
vitals:
  height_test: {m}
  weight_test: {m}
  bmi_method: {m}
  bmi_bands:
    - {{ code: {m}, label: {m}, min: {m}, max_excl: {m} }}
    - {{ when: fallthrough, label: {m}, code: {m} }}
""",
    "SEX": """\
# SEX — master slot `applicability`: whether this tumour restricts the cohort by sex.
#
# NO DEDICATED FAMILY, AND IT DOES NOT NEED ONE. Sex is carried through from the index source as a
# structured column, which `passthrough` exists to do: `column` is the delivered name, `as` is what
# the ADS publishes it as. The engine SKIPS any listed column the source does not carry, so a name
# that is wrong by one character is not an error — the variable simply never appears. Confirm the
# delivered name against the data profile, not against another tumour's pack.
#
# `applicability` is not a config value either. A tumour that restricts by sex (prostate) does so
# because the DELIVERED POPULATION is already restricted — the same Gate 1/Gate 3 fact
# COHORT_ELIGIBILITY describes, not a filter this pack applies.
passthrough:
  columns:
    - {{ column: {m}, as: {m} }}
    # `optional: true` on a feed-dependent column additionally tells strict preflight not to
    # hard-require it, so a cut lacking the column still builds. Sex is normally NOT optional —
    # add the flag only where the workbook says the column may be absent.
    # - {{ column: {m}, as: {m}, optional: true }}
""",
    "DEATH_DATE": """\
# DEATH_DATE — master slot `composite_sources`: which sources the composite death date draws on,
# and the GRANULARITY delivered. Granularity is the whole reason this block exists: the composite
# arrives as a full date for some patients, YYYY-MM for others and YYYY for the rest, and every
# one of them has to become a single date before OS can be computed.
death_date_imputation:
  # Imputation. These are the values a partial date BECOMES, and they are workbook facts — the
  # engine has no default that is safe to inherit, because the choice shifts every OS in months.
  month_level_day: {m}          # YYYY-MM -> this day of that month
  year_level_monthday: {m}      # YYYY    -> this MM-DD of that year
  # A year-only death in the SAME year as an index on/after the month above would impute to a date
  # BEFORE the index — a negative OS. This later MM-DD is what such a row uses instead. Omit it and
  # the ordinary year_level_monthday applies, which is the negative-OS case.
  year_level_late_monthday: {m}
  # When a patient has more than one mortality row, WHICH ONE SURVIVES — chosen after imputation,
  # per patientid+index_date. A data-quality policy, stated here so it is a reviewed choice rather
  # than engine behaviour nobody saw. The engine accepts these three names and no others:
  #   most_specific_then_earliest  finest granularity (full > YYYY-MM > YYYY), then earliest
  #   earliest                     earliest imputed date, finest granularity as tiebreak
  #   latest                       latest imputed date, finest granularity as tiebreak
  conflict_resolution: {m}
  death_followup_window_days: {m}   # dthfufl: death within this many days of follow-up end -> 1
  # The activity sources whose greatest date IS follow-up end (fu_enddt). Declared here so the
  # candidate set and its date columns are a reviewed artifact rather than an engine default.
  # An entry naming a source the pack does not declare is SKIPPED, not refused — so a typo here
  # silently shortens follow-up for every patient instead of failing.
  # The `lot` entry's alias is NOT free: the death-date reconciliation looks it up by that exact
  # name, and the validator refuses any other.
  follow_up_sources:
    - {{ source: {m}, date_column: {m}, alias: {m} }}
    - {{ source: lot, date_column: {m}, alias: last_lotenddate }}
""",
    "COMORBIDITY_INDEX": """\
# COMORBIDITY_INDEX — master slots `algorithm` (Quan Charlson, NCI/Klabunde, Elixhauser) and
# `lookback` (commonly 12 months).
#
# THE ENGINE SHIPS NO CODE SETS AND NO WEIGHTS, and that is deliberate. Each of those algorithms
# has ICD-9 and ICD-10 variants, published revisions and disease-specific adaptations; an engine
# carrying one would be choosing the algorithm for every product silently, and the choice would sit
# outside the approval meant to cover it. So the conditions, their codes and their weights come
# from the workbook into this block, where Gate 4 covers them like any other parameter.
#
# THE SUM IS OVER DISTINCT CONDITIONS, NOT ROWS. A patient coded five times for myocardial
# infarction scores it once — the engine takes each condition's presence over the window, then
# weights. Nothing you write here can turn that into a row count.
comorbidity_index:
  source: {m}                 # the coded-diagnosis source
  code_column: {m}
  code_system: {m}            # a coding system the vocabularies registry declares (e.g. icd10cm);
                              # codes are normalised on BOTH sides before comparison
  date_column: {m}
  # THE LOOKBACK IS WHAT MAKES THIS BASELINE. Without it the score counts diagnoses recorded AFTER
  # index — a covariate that has partly measured the outcome. Both bounds are day offsets and
  # negative means before index; the validator refuses the block if this is missing.
  window_days: [{m}, {m}]
  name: {m}                   # the published score column
  conditions:
    # One entry per condition the algorithm scores. Exactly one match operator each —
    # `code_prefix_any` for ICD chapters, `code_in` for an explicit list.
    - {{ name: {m}, weight: {m}, code_prefix_any: [{m}] }}
    # HIERARCHY IS YOURS TO STATE. Charlson-type indices do not count both mild and severe liver
    # disease, or both "any tumour" and "metastatic solid tumour" — the severe member supersedes
    # the mild one. Omit `supersedes` and the score is inflated for exactly the sickest patients.
    - {{ name: {m}, weight: {m}, code_prefix_any: [{m}], supersedes: [{m}] }}
  # Optional: publish the score banded as well, as <name>gr / <name>grn.
  bands:
    - {{ code: {m}, label: {m}, max: {m} }}
    - {{ code: {m}, label: {m}, min: {m} }}
""",
    "RW_RESPONSE": """\
# RW_RESPONSE — master slot `assessment_basis`: what the response call is anchored on in this
# tumour (imaging interpretation, Lugano PET, IMWG lab criteria, GCIG CA-125).
#
# BEST RESPONSE OVER A WINDOW, which is the closest-to-index panel with the rows RANKED by your
# category order rather than by distance from index. `pick: priority` is that ranking — the same
# one that rolls a multi-gene panel up to its worst-case status, read the other way round.
#
# WHAT THIS DOES NOT DO: per-LINE response. "Best confirmed response for line 2" needs the
# assessment joined to the line that was running, and no config expresses that — the DLBCL and
# myeloma entries stay `engine_gap` in COVERAGE.md for exactly this reason. A window is not a line:
# if two lines start inside your window, this returns one answer across both.
response:
  source: {m}
  name_column: {m}            # the column naming the assessment type
  value_column: {m}           # the column carrying the response category
  date_column: {m}
  window_days: [{m}, {m}]     # day offsets from index; either may be null for open-ended
  # The assessment DATE, published as <name>dt. Worth setting for response specifically: with a
  # priority pick the winning row is NOT the nearest one, so nothing downstream can work out when
  # the best response happened. Off by default (biomarkers and labs do not set it).
  emit_date: true
  panel:
    - name: {m}
      match: {m}              # the assessment-type value this item selects
      pick: priority          # rank the in-window rows by `priority` below, best first
      # THE ORDER IS THE DEFINITION OF "BEST" and it is a workbook fact, not a convention. State
      # every label, including the terminal one — a category missing from this list ranks LAST,
      # so an omission quietly makes that response the worst possible outcome.
      priority: [{m}]
      groups:                 # delivered value -> published label + code
        - {{ from_equals_ci: [{m}], label: {m}, code: {m} }}
        - {{ when: fallthrough, label: {m}, code: {m} }}
""",
    "LAB_VALUES": """\
# LAB_VALUES — master slots `panel` + `window`: closest-to-index value panel (flag + value + date).
lab_values:
  source: {m}
  name_column: {m}
  value_column: {m}
  date_column: {m}
  unit_column: {m}
  window_days: [{m}, {m}]
  panel:
    - {{ name: {m}, match: {m}, units: [{m}] }}
""",
}

OUT_BLOCKS = {
    "OS": """\
# OS — master slots `index_anchor` + `censoring`. (DEATH_DATE has its own block, in
# variables/clinical.yaml: this one names the anchors, that one resolves partial dates.) The three anchors name ENGINE
# columns from clinical.follow_up_and_death (the reference packs state dthfl / dthdt / fued) —
# still markers, because copying a reference is a decision this skeleton must not make. The
# follow-up GATE is engine-fixed: the OS case gates on id3mosfu, derived from min_followup_days;
# it is not a config key, and this skeleton emits no control the engine does not read.
min_followup_days: {m}
days_per_month: {m}
overall_survival:
  event_flag: {m}
  death_anchor: {m}
  censor_anchor: {m}
""",
    "LINE_TTE": """\
# RWTTD / TTNT — master slots `discontinuation_rule` + `event_definition`: the line-cohort
# time-to-event family (vis120 / trtdis / ttd / ttntfl / ttnt). `visit_recency_days` is the
# vis120 window and REQUIRED beside line_outcomes — the engine reads it the moment the block
# is present.
visit_recency_days: {m}
line_outcomes:
  visit_sources: [{m}]
  visit_date_column: {m}
  ttd_from_line: {m}
""",
    "RWPFS": """\
# RWPFS — master slots `index_anchor` + `event_definition`: clinician-anchored progression.
progression:
  source: {m}
  date_column: {m}
  evidence_columns: [{m}]
  pseudoprogression_column: {m}
  yes_value: {m}
  no_value: {m}
  exclusion_days: {m}
""",
}

TRT_NOTE = """\
# LINE_OF_THERAPY — master slot `line_rules`. The line model lives in the ROOT config
# (`lot:` — setting filter, exclusions, line-number column, maintenance) and the per-line category
# labels in codelists/treatment_categories.yaml; this pack carries line counts and prior-therapy
# flags. Reference: products/oncology/prostate/202606/variables/treatment.yaml. Every value you
# copy from the reference is that TUMOUR'S answer, not a default — replace it from the workbook.
"""


def _doc(dest, slug, masters, blocks, uncovered, gaps, extra=""):
    body = "".join(blocks)
    masters_txt = ", ".join(sorted(masters)) or "(none)"
    head = HEADER.format(dest=dest, mark=MARK, slug=slug, masters=masters_txt,
                         uncovered=", ".join(sorted(uncovered)) or "(none)",
                         gaps=", ".join(sorted(gaps)) or "(none)")
    return head + extra + (body.format(m=MARK) if body else "")


def render(pack: str) -> dict:
    """{relative filename: content} for this pack — pure, deterministic."""
    slug = Path(pack).resolve().parent.name
    inst = instantiated_masters(slug)
    # Three buckets, not two: scaffolded, un-scaffolded-but-authorable, and engine-blocked. The
    # third used to be reported as the second, telling a reader to hand-author a block no engine
    # reads.
    gaps = (inst - SCAFFOLDED_MASTERS) & engine_gap_masters()
    uncovered = inst - SCAFFOLDED_MASTERS - gaps
    files = {}
    # The ROOT config skeleton, emitted only when the overlay instantiates INDEX_DATE. Named
    # `data_product.yaml` after the file it is pasted into, like every other skeleton here.
    root = [k for k in ("INDEX_DATE", "COHORT_ELIGIBILITY") if k in inst]
    if root:
        files["data_product.yaml"] = _doc("config/data_product.yaml", slug, set(root),
                                          [ROOT_BLOCKS[k] for k in root], uncovered, gaps)
    dem = [DEM_BLOCKS[k] for k in ("AGEGR1", "RACE_ETHNICITY", "PRACTICE_SETTING", "REGION")
           if k in inst or (k == "AGEGR1" and "AGE" in inst)]
    files["demographics.yaml"] = _doc("variables/demographics.yaml", slug, inst & {"AGE", "AGEGR1",
                                      "RACE_ETHNICITY", "PRACTICE_SETTING", "REGION"}, dem,
                                      uncovered, gaps)
    clin = [CLIN_BLOCKS[k] for k in ("ECOG_PS", "SEX", "DATA_CONTINUITY", "BMI_BSA",
                                     "LAB_VALUES", "COMORBIDITY_INDEX", "RW_RESPONSE",
                                     "DEATH_DATE") if k in inst]
    # ...then ONE `categoricals:` key carrying every contributing family's item. Emitting a key per
    # family would be a duplicate mapping key the strict loader refuses.
    cat_items = [CATEGORICAL_ITEMS[k] for k in ("SMOKING_STATUS", "INSURANCE_PAYER") if k in inst]
    if cat_items:
        clin.append(CATEGORICAL_HEAD + "".join(cat_items))
    files["clinical.yaml"] = _doc("variables/clinical.yaml", slug,
                                  inst & {"ECOG_PS", "SEX", "SMOKING_STATUS", "DATA_CONTINUITY",
                                          "BMI_BSA", "LAB_VALUES", "DEATH_DATE",
                                          "INSURANCE_PAYER", "RW_RESPONSE",
                                          "COMORBIDITY_INDEX"}, clin, uncovered, gaps)
    outs = [OUT_BLOCKS["OS"]] if "OS" in inst else []
    if inst & {"RWTTD", "TTNT"}:                     # both ride the line_outcomes family
        outs.append(OUT_BLOCKS["LINE_TTE"])
    if "RWPFS" in inst:
        outs.append(OUT_BLOCKS["RWPFS"])
    files["outcomes.yaml"] = _doc("variables/outcomes.yaml", slug, inst & {"OS", "RWTTD", "RWPFS", "TTNT"},
                                  outs, uncovered, gaps)
    files["treatment.yaml"] = _doc(
        "variables/treatment.yaml", slug, inst & {"LINE_OF_THERAPY"}, [], uncovered, gaps,
        extra=TRT_NOTE if "LINE_OF_THERAPY" in inst else "")
    return files


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("product", help="path to a product pack (products/<family>/<slug>/<YYYYMM>)")
    ap.add_argument("--check", action="store_true",
                    help="regenerate and byte-compare against spec_pipeline/out/variables_scaffold/"
                         " — exit 1 on drift, writing nothing")
    a = ap.parse_args(argv)
    files = render(a.product)
    out_root = os.path.join(a.product, OUT_DIR)
    if a.check:
        # NEVER GENERATED is not DRIFT. The skeletons are an optional drafting aid; a pack that
        # has not asked for them has nothing to be stale, and reporting "missing" there made the
        # check permanently red for every pack — which is why nothing ran it. An EXISTING
        # directory, though, is a claim of currency, and byte-compares like every out/ artifact.
        if not os.path.isdir(out_root):
            print(f"never generated — {os.path.join(a.product, OUT_DIR)} does not exist; "
                  f"nothing to be stale. Generate with: "
                  f"python3 platform/tools/variables_scaffold.py {a.product}")
            return 0
        drift = []
        for name, want in files.items():
            path = os.path.join(out_root, name)
            have = (open(path, encoding="utf-8").read() if os.path.exists(path) else None)
            if have != want:
                drift.append(name)
        if drift:
            print("DRIFT — regenerate with: python3 platform/tools/variables_scaffold.py "
                  f"{a.product}")
            for name in drift:
                print(f"  stale/missing: {os.path.join(OUT_DIR, name)}")
            return 1
        print(f"current — {len(files)} skeleton(s) match")
        return 0
    os.makedirs(out_root, exist_ok=True)
    for name, content in sorted(files.items()):
        with open(os.path.join(out_root, name), "w", encoding="utf-8", newline="") as fh:
            fh.write(content)
        print(f"  wrote {os.path.join(OUT_DIR, name)}")
    # Each skeleton carries its own destination in its header, so the closing line must not name one
    # — `data_product.yaml` is pasted into `config/`, not `variables/`, and a blanket instruction to
    # copy everything into `variables/` would put the cohort model where nothing reads it.
    print(f"Fill every {MARK} from the approved workbook, then copy each block into the file its "
          f"header names ({a.product}/). The build refuses any pack value still carrying {MARK}.")
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
