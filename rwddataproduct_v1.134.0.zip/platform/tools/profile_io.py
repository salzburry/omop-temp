#!/usr/bin/env python3
"""The one reader of a `data_profiler.R` profile TSV.

Several tools consumed this format and each parsed it themselves: `source_check.py` (Gate 3 verdicts)
and the shared `platform/tools/profile_facts.py` (the restricted detailed report), plus a
`source_metadata.py` that has since been removed for want of any governed consumer. Each redefined the
cut-suffix regex and the table_base rule; only `profile_facts` validated the values. So the weakest
reader set the floor for what the repo would accept as "a profile", and a malformed file could pass
Gate 3 while failing the report that a person actually reads.

TWO outputs are justified — a restricted detailed report and a sanitized verdict. Two parsers were
not. This is the parser; the renderers stay where they are.

It fails closed and loudly, because a profile is the evidence a mapping gets approved on: a file of
unknown shape must not be quietly interpreted.

    from profile_io import load, table_base, CUT
    tables, cuts = load("profile_2026m06.tsv")     # {table_base: {column: row}}, {"2026m06"}

stdlib only.
"""
import csv
import math
import re
import sys

# The snapshot suffix on a physical table name. One definition: three copies of this had already
# drifted in spelling (`(?:...)` vs `(...)`), and a regex that disagrees about what a cut looks like
# is a regex that disagrees about which table a row belongs to.
CUT = re.compile(r"_(20\d{2}(m\d{2}|q\d|\d{2})?)$")
IDENTITY = ["table", "table_base", "column"]
MEASURES = ["kind", "sampled", "n_rows", "n_rows_total", "pct_missing", "distinct",
            "date_min", "date_max", "top_values"]
REQUIRED = IDENTITY + MEASURES
# What the file says it was measured FROM, repeated on every row by the profiler. Not in REQUIRED:
# a profile produced before these existed still loads, and `provenance()` reports None so the caller
# decides whether anonymous evidence is acceptable (source_check refuses it; the detailed report
# does not care). Where they ARE present they must be constant — see load().
PROVENANCE = ["profile_product_id", "profile_schema", "profile_cut", "profile_source_mode",
              "profile_mode"]
# The one profile_mode that is a COMPLETE schema listing. The profiler also emits
# `new-columns-only` (only columns absent from a baseline inventory) and `inventory-only` (no column
# measurement at all); its HTML report calls the first "a partial profile … must not be used as a
# temporal-drift input", but the TSV carried no such statement, so the file a machine reads could not
# tell the two apart. `--complete` is the assertion that every column is listed; a partial run cannot
# support it however honestly it was made.
FULL_PROFILE = "full"
BOOLS = {"TRUE", "FALSE", "T", "F", "1", "0", "YES", "NO"}
TRUE = {"TRUE", "T", "1", "YES"}


def table_base(row):
    """The cut-stripped base table name — `table_base` when the profiler gave one, else the suffix
    stripped from `table`."""
    return (row.get("table_base") or "").strip() or CUT.sub("", (row.get("table") or "").strip())


def num(x):
    """Float or None. Shared because the renderers parse the same measure columns the loader
    validates, and two answers to 'is this a number' is one too many."""
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def load(path, allow_multiple_cuts=False):
    """({table_base: {column: row}}, {cut, ...}) with every row validated.

    Raises SystemExit with a line number on anything malformed. The validation is the strict version
    that `profile_facts.py` already applied; adopting it here means Gate 3 can no longer accept a file
    the detailed report would reject.

    A MIXED-CUT file is rejected by default. Only `profile_facts` checked for that, so a TSV holding
    one table from 2026m05 and another from 2026m06 was one evidence set to Gate 3 and to the
    metadata builder — two deliveries answering as one, with nothing saying so. A caller that
    genuinely wants several has to say `allow_multiple_cuts=True`.
    """
    with open(path, newline="", encoding="utf-8") as fh:
        rd = csv.DictReader(fh, delimiter="\t")
        hdr = rd.fieldnames or []
        missing = [c for c in REQUIRED if c not in hdr]
        if missing:
            sys.exit(f"ERROR: {path} is not a data_profiler.R profile — missing column(s) "
                     f"{', '.join(missing)}. Regenerate it with the current profiler (full "
                     f"contract). Fail closed rather than read a file of unknown shape.")
        tables, dups, cuts, seen_ci = {}, [], set(), set()
        prov_seen = {c: set() for c in PROVENANCE if c in hdr}
        for i, row in enumerate(rd, start=2):                 # header is line 1
            # Identity is repeated per row, so it can disagree per row. Concatenating two runs'
            # output produces a file that is structurally fine and provenance-wise meaningless;
            # collect the distinct values and reject more than one below.
            for c in prov_seen:
                prov_seen[c].add((row.get(c) or "").strip())
            if (row.get("sampled") or "").strip().upper() not in BOOLS:
                sys.exit(f"ERROR line {i}: sampled={row.get('sampled')!r} is not a boolean.")
            nr, nt = num(row.get("n_rows")), num(row.get("n_rows_total"))
            for name, v in (("n_rows", nr), ("n_rows_total", nt)):
                if v is None or not math.isfinite(v) or v < 0 or v != int(v):
                    sys.exit(f"ERROR line {i}: {name}={row.get(name)!r} must be a non-negative "
                             f"whole number.")
            if nr > nt:
                sys.exit(f"ERROR line {i}: n_rows ({nr:g}) > n_rows_total ({nt:g}).")
            pmraw = (row.get("pct_missing") or "").strip()
            # A zero-row table legitimately has no missingness: the profiler writes NA as empty.
            if not (nr == 0 and pmraw == ""):
                pm = num(pmraw)
                if pm is None or not math.isfinite(pm) or pm < 0 or pm > 100:
                    sys.exit(f"ERROR line {i}: pct_missing={pmraw!r} must be a number in 0..100.")
            m = CUT.search((row.get("table") or "").strip())
            if m:
                cuts.add(m.group(1))
            tb, col = table_base(row), (row.get("column") or "").strip()
            if not tb or not col:
                continue
            # Case-INSENSITIVELY: the loader kept `BirthYear` and `birthyear` as two rows and every
            # consumer then lowercased, collapsing them into one silently. Spark identifiers are
            # case-insensitive, so two spellings of one column is a malformed profile, not two
            # columns — and "the" measurement for it would be whichever row happened to land last.
            key = (tb.lower(), col.lower())
            if key in seen_ci:
                dups.append(f"{tb}.{col}")
            seen_ci.add(key)
            tables.setdefault(tb, {})[col] = row
        if dups:
            sys.exit("ERROR: duplicate (table,column) rows (merged / multi-cut TSV?):\n  "
                     + "\n  ".join(sorted(set(dups))))
        if not tables:
            sys.exit(f"ERROR: {path} has no table/column rows — empty or malformed profile.")
        if len(cuts) > 1 and not allow_multiple_cuts:
            sys.exit(f"ERROR: {path} mixes cuts {sorted(cuts)} — profile one cut at a time, or "
                     f"two deliveries answer as one evidence set with nothing recording it.")
        for c, vals in sorted(prov_seen.items()):
            if len(vals) > 1:
                sys.exit(f"ERROR: {path} carries {len(vals)} different values for {c} "
                         f"({', '.join(sorted(repr(v) for v in vals))}). One profile describes ONE "
                         f"run; a file mixing runs cannot be evidence for either of them.")
        return tables, cuts


def provenance(tables):
    """What a loaded profile says it was measured from, or None per field where it does not say.

    {"product_id": ..., "schema": ..., "cut": ..., "source_mode": ..., "mode": ...}

    load() has already proven each is constant, so any row answers for the file. Fields are None for
    a profile written before the profiler stamped identity — the caller decides what to do about
    that, because the answer differs: Gate 3 must refuse to accept anonymous evidence, while the
    detailed human report is perfectly usable without it.
    """
    row = next(iter(next(iter(tables.values())).values())) if tables else {}
    out = {}
    for col, key in zip(PROVENANCE, ("product_id", "schema", "cut", "source_mode", "mode")):
        v = (row.get(col) or "").strip()
        out[key] = v if v and v.upper() != "NA" else None
    return out
