#!/usr/bin/env python3
"""Lift the VALUE ENUMERATIONS a specification states, as CANDIDATE EVIDENCE for the executable YAML.

This output is NOT executable configuration and no engine reads it. It is the machine-checkable record
of what the specification literally says, so that RWP's approved `variables/` YAML can be compared
against the source instead of trusted. Promotion to executable YAML is a human act, because it requires
deciding the things the spec does not state: numeric codes, fallthrough behaviour, operators, ranges,
source mappings and output names.

This is the one part of the contract-to-YAML step that can be generated rather than written, and the
reason is worth stating precisely.

The contract SUMMARIZES: `derivation: "STATE→region map (codes 1-5, PR→Other region)"`. The YAML
ENUMERATES: fifty-two state codes. Generating the YAML from the contract is impossible — the codes are
not in it. But they ARE in the specification row, verbatim, and that row is already extracted with its
original Excel coordinates. So the enumeration can be lifted from the source rather than retyped.

That matters because retyping is where this repo's worst defect came from: an unanchored find/replace
turned the state code `DE` into the word `Implementation` inside a list of two-letter codes, and it
survived review because it still read like prose.

What it does NOT generate, and must not: windows, tie-breaks, record selection, source mappings,
operators. Those are the contract's judgment fields, they are not enumerations, and on prostate 202607
twenty-eight of the fifty-three records are still blocked on an RWB decision. This tool lifts values;
it decides nothing.

Two shapes are recognised, both unambiguous:

  membership   `if STATE in ('ME' 'VT' ...) then ='Northeast'; else if ...`   -> labelled value lists
  numeric map  `1 = Positive, 2 = Negative, 3 = VUS`                          -> code/label pairs

Read from the DEFINITION cell first, and from the VALUES cell when the definition yields nothing. The
Values column is where RWB writes the enumeration outright — `1='Yes'<br>0='No';<br>missing` — and it
went unread, so a variable whose codes were stated in the one column named for them produced no
candidate and the comparison against the approved YAML said nothing about it. Definition wins where
both state codes: it carries the branch labels and the missing-value branch, and a Values cell read
over the top of it would replace a rule with a summary of one.

A Values cell is taken only when EVERY segment of it is accounted for — as a code pair, or as a bare
`missing`/`null`/`.` recorded as `missing_permitted`. One unaccounted segment yields nothing, and the
segments are quoted in the finding.

Anything else is REPORTED, not guessed. A half-parsed enumeration is worse than none: it looks complete.
Every run states its coverage, in the file as well as the console: `unparsed` rows were NOT CHECKED,
which a list made otherwise of matches does not say on its own.

    python3 platform/tools/spec_codelists.py <extracted.json> [--out FILE]

stdlib only.
"""
import argparse
import json
import os
import re
import sys

# `in ('ME' 'VT' 'NH') then ='Northeast'` — quoted tokens, then the label the branch assigns.
MEMBERSHIP = re.compile(
    r"in\s*\(\s*((?:'[^']+'[\s,]*)+)\)\s*then\s*=?\s*'([^']+)'", re.I)
# `1 = Positive, 2 = Negative` / `1=IHC | 2=FISH` — a code, an equals, a label up to the next separator.
NUMERIC_MAP = re.compile(
    r"(?<![\d.])(\d{1,2})\s*=\s*'?([A-Za-z0-9><=][^,;|<]{0,40}?)'?\s*(?=[,;|]|<br>|$)")
TOKEN = re.compile(r"'([^']+)'")
# `else if STATE is missing then ='Missing'` — a branch with a PREDICATE instead of a member list. The
# first version dropped these entirely, so the generated REGION1 had five branches where the spec states
# six, and the omission was invisible because what remained looked complete.
PREDICATE = re.compile(r"(?:else\s+)?if\s+(\w+)\s+is\s+(missing|null)\s*then\s*=?\s*'([^']+)'", re.I)


def membership_lists(text):
    """Branches of an if/else-if chain, in the order the spec writes them.

    Each is either a MEMBER list or a PREDICATE. Both are branches of one rule and dropping either
    misrepresents the rule — a chain with the missing-value branch removed reads as complete.
    """
    out = []
    for values, label in MEMBERSHIP.findall(text):
        toks = TOKEN.findall(values)
        if toks:
            out.append({"label": label.strip(), "members": toks})
    for col, kind, label in PREDICATE.findall(text):
        out.append({"label": label.strip(), "predicate": f"{col.lower()}_is_{kind.lower()}"})
    return out


def numeric_map(text):
    """[(code, label)] for a `1 = X, 2 = Y` map, requiring the codes to run contiguously.

    The completeness test is the point: a partial map parsed from a truncated row would produce a
    codelist that silently drops categories.

    The run may start at 0 or at 1. It was 1-only, which refused every `1='Yes' 0='No'` flag in the
    specification — the most common enumeration RWB writes — as if it were truncated. Contiguity is
    what catches truncation; where the run starts is a convention, and this spec uses both.
    """
    pairs = [(int(c), l.strip()) for c, l in NUMERIC_MAP.findall(text)]
    seen, out = set(), []
    for code, label in pairs:
        if code not in seen:
            seen.add(code)
            out.append((code, label))
    out.sort()
    if len(out) < 2:
        return []
    start = out[0][0]
    if start not in (0, 1) or [c for c, _ in out] != list(range(start, start + len(out))):
        return []
    return out


# A Values cell segment that states missing is PERMITTED rather than naming a code: `missing`, `null`,
# or SAS's `.`. It is not a code and must not be given one, but dropping it makes a two-value flag out
# of a three-state field.
BARE_MISSING = re.compile(r"^\s*(?:missing|null|\.)\s*$", re.I)
# One segment of a Values cell: a code, an equals, and the rest of the segment as its label. Anchored
# at both ends, because the segment has already been cut out — a global regex with lookaheads has to
# guess where a label stops, and that guess is what a label containing the terminator defeats.
VALUE_PAIR = re.compile(r"^\s*(\d{1,2})\s*=\s*'?(.+?)'?\s*$")
# The separators RWB uses, most distinctive first. ONE style per cell, chosen by what the cell
# contains: prostate writes `1='Yes'<br>0='No';` and ovarian writes `• 1=Northeast • 2=Midwest •`.
# Splitting on all of them at once destroys `• 1=<150,000/uL •`, where the comma is inside a label —
# and splitting on none of them leaves a global regex guessing where each label ends.
VALUE_SEPARATORS = ("•", "|", ";", ",")


def values_cell(cell):
    """({pairs, missing_stated}, unaccounted) for a Values cell that enumerates codes.

    The Values column is where RWB writes the enumeration outright — `1='Yes'<br>0='No';<br>missing` —
    and it was never read: only the Definition cell was. So a variable whose codes are stated in the
    one column named for them produced no candidate at all, and the comparison against the approved
    YAML said nothing about it either way.

    Every segment must be accounted for — as a code pair, or as a bare missing token. A cell that is
    two-thirds parseable yields NOTHING, with the unaccounted segments returned so the finding can
    quote them: an enumeration missing a category looks exactly like a complete one, which is the
    failure this whole tool is arranged against.

    That rule is what makes the per-segment reading safe, and it earns its keep on the real workbooks:

      `1=Yes, 0=No, missing (header shows 1=Yes, 0=missing)`   the spec contradicts itself; the
                                                               trailing segments do not parse, so
                                                               nothing is lifted and the text is quoted
      `• 1 = Overall OC: Index at Init • Diag • 2 = ...`        a label CONTAINS the separator, so
                                                               `Diag` is left over and the cell is
                                                               refused rather than half-read
      `• 'Present' • 'Unknown' • (and numeric 1=Present, ...)`  a string enumeration with a
                                                               parenthesised numeric one; reading
                                                               either would be choosing for the reader
    """
    # Excel cells carry hard line breaks, and a segment quoted back with one in it wraps mid-token in
    # the console and mid-value in the YAML. Collapsing whitespace changes no code and no label.
    cell = re.sub(r"\s+", " ", cell or "").strip()
    if not cell:
        return None, []
    sep = next((c for c in VALUE_SEPARATORS if c in cell), None)
    if sep is None:
        return None, []

    pairs, missing_stated, unaccounted = [], False, []
    for seg in cell.split(sep):
        # A cell mixes separator styles at its edges — `1='Yes'|0='No';|missing` splits on `|` and
        # leaves the `;` clinging to a label. Stripping the OTHER separators from a segment's ends is
        # safe in a way splitting on them is not: it cannot cut a label in half.
        seg = seg.strip().strip("".join(VALUE_SEPARATORS)).strip()
        if not seg:
            continue
        if BARE_MISSING.match(seg):
            missing_stated = True
            continue
        m = VALUE_PAIR.match(seg)
        if m:
            pairs.append((int(m.group(1)), m.group(2).strip()))
        else:
            unaccounted.append(seg.strip()[:60])
    if not pairs:
        return None, []                     # not an enumeration; `Date`, `Numeric`, prose
    if unaccounted:
        return None, unaccounted

    # Contiguity, the same completeness test the definition path uses: a run may start at 0 or 1 and
    # may not skip. First spelling of a repeated code wins, which is how `1=Yes` beside a later
    # restatement of the same code stays one entry rather than two.
    seen, out = set(), []
    for code, label in pairs:
        if code not in seen:
            seen.add(code)
            out.append((code, label))
    out.sort()
    start_ = out[0][0]
    if len(out) < 2 or start_ not in (0, 1) or \
            [c for c, _ in out] != list(range(start_, start_ + len(out))):
        return None, [f"codes {sorted(c for c, _ in out)} are not a complete run from 0 or 1"]
    return {"pairs": out, "missing_stated": missing_stated}, []


def extract(rows):
    found, skipped = [], []
    for r in rows:
        if not r.get("domain"):
            continue
        text = (r.get("fields", {}).get("definition") or "").replace("<br>", "|")
        vals = (r.get("fields", {}).get("values") or "").replace("<br>", "|")
        if not (text or vals):
            continue
        mem = membership_lists(text)
        num = numeric_map(text)
        # DEFINITION first, VALUES only as a fallback. Where both state codes the definition is the
        # richer source — it carries the branch labels and the missing-value branch — and reading the
        # Values cell over the top of it would replace a rule with a summary of one.
        cell, unaccounted = (None, []) if (mem or num) else values_cell(vals)
        if mem:
            found.append({"item_id": r["item_id"], "variable": r["variable"], "kind": "membership",
                          "hash": r["content_hash"], "values": mem, "from": "definition"})
        elif num:
            found.append({"item_id": r["item_id"], "variable": r["variable"], "kind": "numeric_map",
                          "hash": r["content_hash"], "values": num, "from": "definition"})
        elif cell:
            found.append({"item_id": r["item_id"], "variable": r["variable"], "kind": "numeric_map",
                          "hash": r["content_hash"], "values": cell["pairs"], "from": "values",
                          "missing_stated": cell["missing_stated"]})
        else:
            # Looks enumerated but did not parse cleanly — say so rather than emitting a partial list.
            # WHICH trigger fired is part of the finding: "does not match a recognised shape" is true
            # of every row here and tells the next reader nothing about where to look. A row caught by
            # the membership trigger has an `in (...)` the MEMBERSHIP pattern would not take; a row
            # caught by the code trigger has an `N = label` the NUMERIC_MAP pattern would not take.
            # Those are different repairs to this parser.
            # BOTH cells. Scanning only the definition left a row whose Values cell plainly tries
            # to enumerate — `'Present' • 'Unknown' • (and numeric 1=Present, …)` — reported nowhere
            # at all, which reads as "nothing to see" rather than "not checked".
            both = text + " " + vals
            saw = [name for name, pat in (
                ("membership `in (…)`", r"\bin\s*\("),
                ("numeric `N = label`", r"\d\s*=\s*[A-Za-z]"),
                # A Values cell that is a bare list of codes — `1,2,3` — with the labels only in the
                # definition. Nothing to lift, but the row IS an enumeration and a reader comparing
                # this file against the approved YAML has to know it was not covered.
                ("a bare code list with no labels", r"^\s*\d+(?:\s*,\s*\d+)+\s*$"))
                   if re.search(pat, both, re.M)]
            if unaccounted:
                # The sharpest case: the Values cell DOES enumerate, and one segment of it could not
                # be accounted for. Quote the segments, because "not checked" that names what to look
                # at is a task, and "not checked" on its own is a shrug.
                skipped.append({"item_id": r["item_id"], "variable": r["variable"],
                                "why": "the Values cell enumerates codes but these segment(s) are "
                                       "unaccounted for, and a code list that drops them would be "
                                       "partial: " + " · ".join(unaccounted),
                                "values_cell": re.sub(r"\s+", " ", vals).strip()})
            elif saw:
                skipped.append({"item_id": r["item_id"], "variable": r["variable"],
                                "why": "looks like an enumeration (" + " and ".join(saw) +
                                       ") but does not match a recognised shape",
                                "values_cell": re.sub(r"\s+", " ", vals).strip()})
    return found, skipped


def coverage(rows, found, skipped):
    """What the run looked at, so a clean list cannot be read as a complete one.

    `unparsed` rows sit in a report otherwise made of matches, and a reader comparing this against the
    approved YAML sees a list of agreements and one line that is not obviously a hole. It is a hole:
    the row was NOT checked, which is not the same as checked-and-clean, and nothing downstream
    distinguishes them. So the count is stated as its own fact rather than left to be inferred from a
    list somebody has to notice is shorter than it should be.
    """
    considered = len(found) + len(skipped)
    return {"rows_read": len(rows), "considered": considered,
            "lifted": len(found), "unparsed": len(skipped)}


def provenance(product, source):
    """Where these candidates came from, and whether anyone approved it — read from source_refs.yaml
    rather than asserted. Stating "the approved specification" unconditionally would be false for
    every pack whose registered input is a stand-in rather than the approved workbook."""
    lines = [f"# source: {source}"]
    if not product:
        return lines
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import source_manifest
        spec = source_manifest.authoritative(product) or {}
        src_id = source_manifest.pipeline_source_id(product)
        lines = [f"# extracted from: {source}"]
        if src_id:
            lines.append(f"# source material: {src_id} (source_refs.yaml)")
        lines.append(f"# authoritative document: {spec.get('document_id', 'not recorded')} "
                     f"— status {spec.get('status', 'not recorded')}")
        lines.append(f"# source approval: {source_manifest.source_status(product) or 'not recorded'}")
    except Exception as exc:                                        # noqa: BLE001
        lines.append(f"# source approval: could not be read ({exc.__class__.__name__})")
    return lines


def to_yaml(found, skipped, source, product=None):
    L = ["# GENERATED by platform/tools/spec_codelists.py.",
         "# Do not hand-edit: regenerate. Every block names the spec row it was lifted from, so any",
         "# value here can be walked back to the original Excel coordinates.",
         "#",
         "# CANDIDATE EVIDENCE — not executable configuration. No engine reads this file. It records what",
         "# the specification literally states so the approved variables/ YAML can be COMPARED against the",
         "# source. Promotion is a human act: numeric codes for membership branches, fallthrough",
         "# behaviour, operators, source mappings and output names are NOT stated here because the spec",
         "# does not state them.",
         "#"] + provenance(product, source) + [""]
    # Coverage in the FILE, not only on the console. The console line is seen by whoever ran the
    # tool; the comparison against the approved YAML is done against this file, often by somebody
    # else, later, and a list of matches with no denominator reads as a complete one.
    L.append("coverage:")
    L.append(f"  lifted: {len(found)}")
    L.append(f"  unparsed: {len(skipped)}    # produced no candidate — NOT checked, "
             f"which is not the same as clean")
    L.append("")
    L.append("unparsed:" if skipped else "unparsed: []")
    for s in skipped:
        L.append(f"  - spec_ref: {s['item_id']}")
        L.append(f"    variable: {json.dumps(s['variable'])}")
        L.append(f"    why: {json.dumps(s['why'])}")
        # The Values cell verbatim. A row nothing could be lifted from still has to be compared
        # against the approved YAML, and this is what a person compares it to — without it the entry
        # says only that somebody should go and open the workbook.
        if s.get("values_cell"):
            L.append(f"    values_cell: {json.dumps(s['values_cell'])}")
    L.append("")
    L.append("enumerations:" if found else "enumerations: {}")
    for f in found:
        L.append(f"\n  # {f['item_id']}  ({f['variable']})   content hash {f['hash']}")
        L.append(f"  {f['variable'].lower()}:")
        L.append(f"    spec_ref: {f['item_id']}")
        L.append(f"    kind: {f['kind']}")
        # WHICH cell it came from. A candidate lifted from the Definition carries the rule; one lifted
        # from the Values column carries only the code list, and a reader checking an operator or a
        # window against it would be checking against a cell that never stated one.
        L.append(f"    lifted_from: {f.get('from', 'definition')}")
        if f.get("missing_stated"):
            # The Values cell listed `missing` beside the codes. NOT given a code — the spec does not
            # state one — but recorded, because a flag that permits missing and one that does not are
            # different fields and the code pairs alone cannot tell them apart.
            L.append("    missing_permitted: stated_by_the_spec")
        L.append("    values:")
        if f["kind"] == "membership":
            for br in f["values"]:
                if "members" in br:
                    members = ", ".join(f'"{m}"' for m in br["members"])
                    L.append(f'      - {{ label: "{br["label"]}", members: [{members}] }}')
                else:
                    L.append(f'      - {{ label: "{br["label"]}", predicate: {br["predicate"]} }}')
            # NO numeric codes. The spec states the branch ORDER, not a code per branch — REGION1N says
            # only "Numeric of REGION1". Numbering them here would be a plausible convention invented by
            # a parser and then indistinguishable from a stated requirement.
            L.append("    numeric_codes: not_stated_by_the_spec")
        else:
            for code, label in f["values"]:
                L.append(f'      - {{ code: {code}, label: "{label}" }}')
            L.append("    numeric_codes: stated_by_the_spec")
    return "\n".join(L) + "\n"


def main(argv):
    ap = argparse.ArgumentParser(description="Lift value enumerations from an extracted spec.")
    ap.add_argument("extracted")
    ap.add_argument("--out")
    ap.add_argument("--product", help="pack dir, so the header can state the source's REAL approval "
                                      "status instead of claiming the spec was approved")
    a = ap.parse_args(argv)
    # The pack directory is the natural thing to hand this, because every OTHER tool in the pipeline
    # takes one. It takes the extraction FILE, and argparse's answer to a directory is whatever
    # `open()` raises — `IsADirectoryError` on Linux, `PermissionError` on Windows — neither of which
    # names the argument or says what would have been right.
    if os.path.isdir(a.extracted):
        cand = os.path.join(a.extracted, "spec_pipeline", "out", "extracted.json")
        sys.exit(f"{a.extracted} is a directory. This tool takes the extraction FILE, not the pack.\n"
                 f"  {sys.argv[0]} {cand if os.path.exists(cand) else '<pack>/spec_pipeline/out/extracted.json'}"
                 f" --product {a.extracted}" +
                 ("" if os.path.exists(cand) else
                  f"\n\n{cand} does not exist yet — run run_spec_pipeline.py on the pack first."))
    with open(a.extracted, encoding="utf-8") as fh:
        data = json.load(fh)
    found, skipped = extract(data["rows"])
    cov = coverage(data["rows"], found, skipped)

    print(f"enumerations lifted   {len(found)}")
    for f in found:
        if f["kind"] == "membership":
            n = sum(len(b.get("members", [1])) for b in f["values"])
            shape = f"{len(f['values'])} branch(es), {n} value(s)"
        else:
            shape = f"{len(f['values'])} code(s)"
        print(f"   {f['item_id']:<18} {f['variable'][:20]:<20} {f['kind']:<12} {shape}")
    if skipped:
        print(f"\nlooked enumerated, NOT lifted   {len(skipped)}")
        for s in skipped[:10]:
            print(f"   {s['item_id']:<18} {s['variable'][:20]:<20} {s['why']}")
        print("   A partial enumeration is worse than none — these need a person, not a better regex.")

    # The coverage line goes LAST, under whichever list ran long, because it is the sentence that says
    # how to read the ones above it.
    print(f"\ncoverage: {cov['rows_read']} spec row(s) read · {cov['considered']} looked enumerated · "
          f"{cov['lifted']} lifted · {cov['unparsed']} NOT CHECKED")
    if cov["unparsed"]:
        print(f"   {cov['unparsed']} row(s) produced no candidate, so comparing this file against the "
              f"approved YAML says nothing about them either way.")

    if a.out:
        with open(a.out, "w", encoding="utf-8") as fh:
            fh.write(to_yaml(found, skipped, data["extraction"]["target"], a.product))
        print(f"\n-> {a.out}")
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
