#!/usr/bin/env python3
"""The cross-pack variable-name registry: one shelf of what things are called, and the drift gate.

    python3 platform/tools/naming_registry.py                # the registry + the unruled docket
    python3 platform/tools/naming_registry.py --format json

WHY THIS EXISTS. Specifications are written by different people, and two of them will name one
concept two ways — `agegrp` here, `age_group` there. Nothing refused that: the engine-owned
column names are standard by construction, but pack-authored names (passthroughs, derived items,
panel flags) were convention only, and the first sweep of this tool found live drift the
convention had already let through (a pack's `region1`/`region1n` beside the engine's
`regionl`/`regionln` — digit one against letter el).

WHAT IT DOES. Compiles every pack's contract `output` axis (physical_name / name_status, through
contract_lint's own parsers) plus the engine's emitted names into one registry, then flags
NEAR-MISSES: two names close enough to be one concept spelled twice, that are NOT twins under
the repo's own suffix grammar (label/code `x`/`xn`, date `xdt`, year `xyr`, flag `xfl`,
duration `xdur`, type/diagnosis-date `xtype`/`xdd`, banded `xgr1`/`xgrl`(+`n`), and per-setting
`x_<setting>` variants — those are the standard WORKING, never drift).

WHAT IT NEVER DOES. It never decides that two names are the same concept, and it never renames
anything. A flagged pair is a QUESTION, and the answer is a human ruling recorded in
governance/NAMING_RULINGS.yaml — signed, dated, one of a closed vocabulary:

    rulings:
      - {a: agegrp, b: age_group, ruling: use_existing,     # the new name yields to the standard
         standard: age_group, decision_id: NAME-1, ruled_by: A Person, ruling_date: 2026-01-01}
        # ruling vocabulary: use_existing | distinct_concepts | alias_accepted

A pair with no ruling is OPEN WORK the docket reports; a ruling that is not a named person's
dated act does not count. A ruling on a pair covers the pair's twin families too (ruling on
(cohort, cohortu) also settles (cohortn, cohortun)) — one question, one answer, not four.

stdlib + the repo's own readers. AI drafts questions from this docket; it records no ruling.
"""
import argparse
import glob
import json
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)
sys.path.insert(0, os.path.join(ROOT, "platform"))
sys.path.insert(0, os.path.join(ROOT, "platform", "engine"))

import contract_lint as cl                                             # noqa: E402

RULINGS_PATH = os.path.join(ROOT, "governance", "NAMING_RULINGS.yaml")
RULING_KINDS = ("use_existing", "distinct_concepts", "alias_accepted")

# One-step twin suffixes: `x` and `x<suffix>` are the SAME concept's conventional variants.
# Single-step on purpose — `agegr1` and `agegrl` both band age, but neither is the other plus a
# twin suffix, and they are exactly the digit/letter drift this tool exists to catch.
TWIN_SUFFIXES = ("n", "dt", "yr", "fl", "dur", "type", "dd", "ddyr")
_BANDED = re.compile(r"(gr\d+n?|grln?)$")


def _twin(a: str, b: str) -> bool:
    """True when one name is the other plus one conventional suffix (order-free)."""
    a, b = a.replace("_", ""), b.replace("_", "")
    if len(a) > len(b):
        a, b = b, a
    if not b.startswith(a):
        return False
    rest = b[len(a):]
    return rest in TWIN_SUFFIXES or bool(_BANDED.fullmatch(rest))


def _strip_twin(name: str) -> str:
    """One twin-strip step, for ruling inheritance (cohortn -> cohort)."""
    n = name.replace("_", "")
    m = _BANDED.search(n)
    if m:
        return n[: m.start()]
    for s in sorted(TWIN_SUFFIXES, key=len, reverse=True):
        if n.endswith(s) and len(n) > len(s):
            return n[: -len(s)]
    return n


def _near(a: str, b: str) -> bool:
    """Two names close enough to be one concept spelled twice — and not convention twins.

    Shared leading TOKENS are dropped first so a family prefix cannot manufacture closeness
    (`prior_abiraterone` / `prior_arpi` compare `abiraterone` vs `arpi`: distinct) while a
    per-setting suffix cannot hide it (`lot1sd_mcrpc` / `lot1sd_mhspc` compare the settings:
    distinct). What remains flags on normalized equality (`agegrp` vs `age_grp`) or a common
    prefix of >= 4 characters covering >= 60% of the shorter remainder.
    """
    if a == b or _twin(a, b):
        return False
    ta, tb = a.split("_"), b.split("_")
    i = 0
    while i < min(len(ta), len(tb)) and ta[i] == tb[i]:
        i += 1
    ra, rb = "".join(ta[i:]), "".join(tb[i:])
    if not ra or not rb:                       # one is the other's token prefix outright
        ra, rb = a.replace("_", ""), b.replace("_", "")
    if ra == rb:
        return True
    if _twin(ra, rb):
        return False
    j = 0
    while j < min(len(ra), len(rb)) and ra[j] == rb[j]:
        j += 1
    return j >= 4 and j / min(len(ra), len(rb)) >= 0.6


def registry(root=ROOT) -> dict:
    """{name: {"packs": {pack: name_status}, "engine": bool, "variable_ids": [...]}} over every
    versioned pack's contract output axis plus the engine's own emitted names."""
    from config import load_config                                     # noqa: PLC0415
    import validate as ev                                              # noqa: PLC0415
    out: dict = {}
    for p in sorted(glob.glob(os.path.join(root, "products", "oncology", "*", "*",
                                           "config", "data_product.yaml"))):
        from spec_extract import repo_relative                         # noqa: PLC0415
        pack = repo_relative(os.path.dirname(os.path.dirname(p)), root)
        try:
            cfg = load_config(p)
            for n in ev.emitted_variables(cfg):
                rec = out.setdefault(str(n).lower(), {"packs": {}, "engine": False,
                                                      "variable_ids": [], "types": {}})
                rec["engine"] = True
        except Exception:                     # noqa: BLE001 — a broken pack owns its own lint
            pass
        cmd = os.path.join(os.path.dirname(os.path.dirname(p)), "handoff",
                           "FUNCTIONAL_CONTRACT.md")
        if not os.path.exists(cmd):
            continue
        for block in cl.records(cl.read(cmd)):
            body = cl._inline(block, "output")
            name = cl._kv(body, "physical_name")
            if not name or name.lower() in ("n/a", "tbd", "none"):
                continue
            rec = out.setdefault(name.lower(), {"packs": {}, "engine": False,
                                                "variable_ids": [], "types": {}})
            rec["packs"][pack] = cl._kv(body, "name_status") or "?"
            vid = cl._scalar(block, "variable_id")
            if vid and vid not in rec["variable_ids"]:
                rec["variable_ids"].append(vid)
            # the declared FORMAT rides with the name: `agegrp` character in one spec and
            # numeric in another is the same standardization failure one field over
            declared = (cl._kv(body, "type") or "").strip().lower()
            if declared and declared not in ("n/a", "tbd"):
                rec["types"].setdefault(declared, []).append(pack)
    return out


def rulings(path=RULINGS_PATH):
    """([valid ruling], [problem]) — a ruling that is not a named person's dated act of the
    closed vocabulary does not count, and SAYS so rather than quietly not counting."""
    from product_gates import bad_date, not_a_person, read_yaml, unstated   # noqa: PLC0415
    if not os.path.exists(path):
        return [], []
    doc, err = read_yaml(path)              # the ONE governed-YAML reader: a parse failure is a
    if err:                                 # finding, never a traceback out of a gate
        return [], [f"NAMING_RULINGS.yaml: {err}"]
    doc = doc or {}
    good, problems = [], []
    for i, r in enumerate(doc.get("rulings") or []):
        tag = f"NAMING_RULINGS.yaml rulings[{i}]"
        if not isinstance(r, dict) or not r.get("a") or not r.get("b"):
            problems.append(f"{tag}: must be a mapping naming both `a` and `b`")
            continue
        if r.get("ruling") not in RULING_KINDS:
            problems.append(f"{tag}: ruling {r.get('ruling')!r} is not one of "
                            f"{', '.join(RULING_KINDS)}")
            continue
        for field, check in (("ruled_by", not_a_person), ("ruling_date", bad_date)):
            v = r.get(field)
            why = "is not set" if unstated(v) else check(v)
            if why:
                problems.append(f"{tag}: {field} {why} — a ruling is a named person's dated "
                                f"act, or it is not a ruling")
                break
        else:
            good.append(r)
    return good, problems


def docket(root=ROOT) -> dict:
    """{"open": [pair-finding], "ruled": n, "ruling_problems": [...]} — the near-miss pairs no
    valid ruling covers. A ruling covers its pair AND the pair's one-step twin families."""
    reg = registry(root)
    good, ruling_problems = rulings()
    covered = set()
    for r in good:
        covered.add(frozenset((str(r["a"]).lower(), str(r["b"]).lower())))
        covered.add(frozenset((_strip_twin(str(r["a"]).lower()),
                               _strip_twin(str(r["b"]).lower()))))
    names = sorted(reg)
    authored = [n for n in names if not reg[n]["engine"]]
    open_pairs, ruled = [], 0
    seen = set()
    for a in authored:
        for b in names:
            if a == b or not _near(a, b):
                continue
            key = frozenset((a, b))
            if key in seen:
                continue
            seen.add(key)
            if key in covered or frozenset((_strip_twin(a), _strip_twin(b))) in covered:
                ruled += 1
                continue
            open_pairs.append({
                "a": a, "b": b,
                "a_where": sorted(reg[a]["packs"]) + (["engine"] if reg[a]["engine"] else []),
                "b_where": sorted(reg[b]["packs"]) + (["engine"] if reg[b]["engine"] else []),
                "question": f"are '{a}' and '{b}' one concept spelled twice? If so, which "
                            f"spelling is the standard — record `use_existing` naming it; if "
                            f"they are genuinely different things, record `distinct_concepts`."})
    # SAME NAME, CONFLICTING DECLARED TYPES — the format half of the same failure: one spec
    # writes the concept as character labels, another as numeric codes, under one name. No
    # ruling file for these: the fix is a contract revision on whichever record is wrong, so
    # each stays open until the records agree.
    type_conflicts = []
    for n in sorted(reg):
        types = reg[n].get("types") or {}
        if len(types) > 1:
            spellings = "; ".join(f"{ty} in {', '.join(sorted(set(pk)))}"
                                  for ty, pk in sorted(types.items()))
            type_conflicts.append({
                "name": n, "types": {ty: sorted(set(pk)) for ty, pk in types.items()},
                "question": f"'{n}' is declared with conflicting formats ({spellings}) — which "
                            f"is the standard? Revise the divergent record(s); a code twin "
                            f"(`{n}n`) is the convention when both a label and a code are "
                            f"needed."})
    return {"open": sorted(open_pairs, key=lambda f: (f["a"], f["b"])),
            "type_conflicts": type_conflicts,
            "ruled": ruled, "ruling_problems": ruling_problems}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("--format", choices=("text", "json"), default="text")
    a = ap.parse_args(argv)
    reg = registry()
    d = docket()
    if a.format == "json":
        print(json.dumps({"registry_size": len(reg), **d}, indent=1, sort_keys=True))
    else:
        engine_n = sum(1 for r in reg.values() if r["engine"])
        print(f"NAMING REGISTRY — {len(reg)} names ({engine_n} engine-owned), "
              f"{d['ruled']} pair(s) ruled, {len(d['open'])} OPEN")
        for p in d["ruling_problems"]:
            print(f"  RULING PROBLEM: {p}")
        for f in d["open"]:
            print(f"  {f['a']:<24} ~ {f['b']:<24} "
                  f"[{','.join(f['a_where'][:2])} vs {','.join(f['b_where'][:2])}]")
        for c in d["type_conflicts"]:
            print(f"  TYPE CONFLICT: {c['name']} — "
                  + "; ".join(f"{ty} ({', '.join(pk)})" for ty, pk in sorted(c["types"].items())))
        if d["open"]:
            print("\nEach pair is a QUESTION for RWP/RWB — record the answer in "
                  "governance/NAMING_RULINGS.yaml (named person, real date). No tool and no "
                  "AI session rules on it.")
    return 1 if d["ruling_problems"] else 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
