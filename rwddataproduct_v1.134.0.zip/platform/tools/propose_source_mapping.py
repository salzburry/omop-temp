#!/usr/bin/env python3
"""Mapping-candidate EVIDENCE for the source gaps a pack has — never a mapping decision.

    python3 platform/tools/propose_source_mapping.py <pack> --profile <profile.tsv>
    python3 platform/tools/propose_source_mapping.py <pack> --profile <p.tsv> --format json
    python3 platform/tools/propose_source_mapping.py <pack> --profile <p.tsv> \\
        --validate biomarkers=t_enh_biomarker            # exit non-zero on any blocker

This is the counting part of the mapping copilot. It lists the gaps, ranks candidates, and shows
every count — required-column coverage, name tokens, grain keys — so a reviewer checks evidence,
not a score. The workflow it serves: AI ranks -> deterministic checks -> RWP reviews and applies.

What a name MEANS is out of scope by design. `DateOfDeath` vs day-level `DEATH_DT` is a person's
decision, routed through the decisions register — never inferred here or by any model.

The evidence is the sanitized profile TSV, nothing else. No vendor tables, no workbooks, no
Spark. And it WRITES NOTHING: `--patch` prints a commented block; pasting it into `sources:` is
a person's reviewed edit, held to account by the existing validators.

stdlib + the repo's own readers.
"""
import argparse
import json
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)
sys.path.insert(0, os.path.join(ROOT, "platform"))

import profile_io                                                     # noqa: E402
import source_requirements as sr                                      # noqa: E402
from engine.config import load_config                                 # noqa: E402
from engine import validate as ev                                     # noqa: E402


def _tokens(name):
    """Lower-cased tokens of a table/role name, splitting snake, camel and digits' edges — the
    same boundaries `spec_lint._names_family` learned from the Enhanced_* miss."""
    s = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", str(name))
    s = re.sub(r"(?<=[A-Z])(?=[A-Z][a-z])", " ", s)
    return [t for t in re.split(r"[^a-zA-Z0-9]+", s.lower()) if t and t not in ("t", "enh")]


def needed_columns(product, role):
    """Column names the blocks READING `role` say they will consume — evidence for a role that has
    no `sources:` entry yet, where `engine.validate.required_columns` is rightly silent (it
    preflights DECLARED sources and must not speculate).

    Collected from the config graph's own words: any `*column*`-keyed string and any `of:` list
    inside a block that references the role, plus `patientid`, which every join needs. Generic on
    purpose — a per-block-shape reader would be one more copy of engine knowledge.
    """
    roles_by_block, _ = sr.block_roles(product)
    blocks = sr.cb.governed_blocks(product, sr.cb.pack_yaml(product))
    cols = {"patientid"}

    def _walk(node):
        if isinstance(node, dict):
            for k, v in node.items():
                if isinstance(v, str) and "column" in k and v.strip():
                    cols.add(v.strip())
                elif k == "of" and isinstance(v, list):
                    cols.update(x for x in v if isinstance(x, str) and x.strip())
                else:
                    _walk(v)
        elif isinstance(node, list):
            for item in node:
                _walk(item)

    for ref, roles in roles_by_block.items():
        if role in roles:
            _walk(blocks.get(ref))
    return sorted(cols)


def gaps(product, profile_tables):
    """The mapping WORK: roles whose physical side is missing or unevidenced.

    Two shapes, from the artifacts that already own them:
      * a role the config READS with no `sources:` entry and no excusing availability state —
        the matrix's own BLOCKED finding, restated as work rather than as a refusal;
      * a declared role whose stem matches NO table in the delivered profile — declared and
        undelivered, which schema preflight would catch on-cluster and this catches from evidence.
    """
    rows, _, _ = sr.matrix(product)
    out = []
    for r in rows:
        # the row's OWN availability, from the compiled source contract — the engine-guarded
        # optional roles (visit, baseline_ecog, ...) carry `optional` there, and a lookup that
        # defaulted them to `required` raised every one of them as mapping work
        state = (r["availability"] or "required").split(" ")[0]
        if not r["declared"]:
            if state == "required":
                # the engine's required_columns is silent for an undeclared role (it preflights
                # DECLARED sources), so the bar unions TWO owners: the reading blocks' own
                # column names (config words) and the STAGE-DECLARED read columns
                # (validate.stage_reads) — the engine-known columns like mortality's
                # dateofdeath that appear in no config key. The adversarial benchmark found the
                # gap: with a patientid-only bar, a near-miss decoy tied the truth table on
                # evidence and the recommendation rested on name overlap alone.
                cfg = load_config(os.path.join(product, "config", "data_product.yaml"))
                reads, read_errs = ev.stage_reads(cfg)
                if read_errs:
                    # a stage whose declaration cannot be read would silently SHRINK this bar —
                    # absence reading as a lower evidence requirement, the exact fail-open the
                    # bar exists to prevent. No bar means no proposal.
                    sys.exit("DECLARATIONS UNREADABLE — the evidence bar cannot be composed: "
                             + "; ".join(read_errs))
                declared_cols = {c for rd in reads if rd["role"] == r["role"]
                                 for c in rd["columns"]}
                out.append({"role": r["role"], "kind": "undeclared",
                            "required_columns": sorted(
                                set(needed_columns(product, r["role"])) | declared_cols),
                            "required_by": r["required_by_variables"]})
            continue
        stem = (r["physical_stem"] or "").lower()
        # Exact stem, or the stem plus a cut suffix (`t_lab` matches `t_lab_2026m06`). NOT free
        # substring: `t_lab` used to count as delivered because `t_labs_legacy` existed — an
        # external review named the confusion class.
        if profile_tables and not any(stem == t or t.startswith(stem + "_")
                                      for t in profile_tables):
            out.append({"role": r["role"], "kind": "declared_but_undelivered",
                        "stem": r["physical_stem"],
                        "required_columns": r["required_columns"],
                        "required_by": r["required_by_variables"]})
    return out


def candidates(gap, tables, grain_decl, top=3):
    """Top candidates for one gap, ranked by COUNTED evidence, blockers stated.

    The score is (required columns covered, token overlap) — arithmetic a reviewer can recheck
    from the lines printed beside it. A candidate missing ANY required column carries a blocker
    and can never be recommended; the best it can be is "candidate, blocked", which is the
    `do_not_map` shape the review asked for instead of a silent closest-name pick.
    """
    need = [c.lower() for c in gap.get("required_columns") or []]
    role_toks = set(_tokens(gap["role"]) + _tokens(gap.get("stem") or ""))
    key = [c.lower() for c in grain_decl.get(gap["role"], [])]
    scored = []
    for tbl, cols in sorted(tables.items()):
        have = {c.lower() for c in cols}
        covered = [c for c in need if c in have]
        missing = [c for c in need if c not in have]
        # PREFIX tokens, not equal tokens — the same rule `spec_lint._names_family` uses, for the
        # same measured reason: `telemed` and `telemedicine` share no equal token and are the same
        # word. Three characters minimum so `t`/`x` junk cannot manufacture overlap.
        tbl_toks = set(_tokens(tbl))
        overlap = sorted({t for t in role_toks if len(t) >= 3 and any(
            (t.startswith(u) or u.startswith(t)) and len(u) >= 3 for u in tbl_toks)})
        evidence = []
        if covered:
            evidence.append(f"carries {len(covered)}/{len(need)} required column(s): "
                            f"{', '.join(covered)}")
        if overlap:
            evidence.append(f"name shares token(s) with the role: {', '.join(overlap)}")
        blockers = []
        if missing:
            blockers.append(f"required column(s) absent: {', '.join(missing)}")
        if key:
            key_missing = [c for c in key if c not in have]
            if key_missing:
                blockers.append(f"declared grain key column(s) absent: {', '.join(key_missing)}")
            else:
                evidence.append(f"carries the declared grain key ({', '.join(key)})")
        # `patientid` alone is not evidence — every clinical table carries it, so counting it
        # would promote junk candidates on any gap and hide the true no-evidence case behind
        # "every candidate carries a blocker". A candidate must show something DISCRIMINATING:
        # a required column beyond the join key, a name-token overlap, or the declared grain key.
        discriminating = ([c for c in covered if c != "patientid"] or overlap
                          or (key and not [c for c in key if c not in have]))
        if not evidence or not discriminating:
            continue                       # a table with nothing FOR it is noise, not a candidate
        scored.append({"table": tbl, "covered": len(covered), "of": len(need),
                       "token_overlap": len(overlap), "evidence": evidence, "blockers": blockers})
    scored.sort(key=lambda c: (-c["covered"], -c["token_overlap"], c["table"]))
    return scored if top is None else scored[:top]


def proposal(product, profile_path, top=3):
    """The full packet: gaps, ranked candidates, and a recommendation THIS TOOL may make.

    `map_candidate` is emitted ONLY when exactly one candidate exists with zero blockers — the
    mechanical case the review allowed ("a uniquely matched physical rename"). Everything else is
    `do_not_map` with `next_action` naming who decides. Two clean candidates is an AMBIGUITY, and
    picking the higher score would be the silent-closest-name failure with extra steps.
    """
    tables, cuts = _tables_and_cuts(product, profile_path)
    cfg = load_config(os.path.join(product, "config", "data_product.yaml"))
    grain_decl, _ = ev.source_grain(cfg)
    table_cols = {t: set(cols) for t, cols in tables.items()}
    out = {"pack": os.path.relpath(os.path.abspath(product), ROOT),
           "profile": os.path.basename(profile_path), "cuts": sorted(cuts), "gaps": []}
    for gap in gaps(os.path.abspath(product), set(table_cols)):
        # The RECOMMENDATION is decided on the FULL candidate list; `top` truncates only what is
        # DISPLAYED. An external review caught the earlier order: `--top 1` hid a second clean
        # candidate and turned an ambiguity into a false "exactly one" — the silent-closest-name
        # failure this tool exists to refuse, reachable through its own display flag.
        full = candidates(gap, table_cols, grain_decl, top=None)
        cands = full[:top]
        clean = [c for c in full if not c["blockers"]]
        if len(clean) == 1 and len(full) >= 1:
            rec, why = "map_candidate", (f"exactly one delivered table carries every required "
                                         f"column: {clean[0]['table']}. A person still applies it.")
        elif len(clean) > 1:
            rec, why = "do_not_map", (f"{len(clean)} tables each carry every required column — "
                                      f"an ambiguity is a decision, not a ranking")
        elif cands:
            rec, why = "do_not_map", "every candidate carries a blocker"
        else:
            rec, why = "do_not_map", ("no delivered table shows any evidence for this role — "
                                      "confirm source availability with RWDE, or record "
                                      "source_availability as unavailable_by_design with a "
                                      "decision_id")
        out["gaps"].append({**gap, "candidates": cands, "recommendation": rec,
                            # the recommended table comes from the FULL clean list, never from
                            # the displayed truncation — a consumer re-deriving it from
                            # `candidates` inherits the display flag's blind spot (the exact
                            # top=1 defect an external review already caught once)
                            "proposed": clean[0]["table"] if rec == "map_candidate" else None,
                            "why": why,
                            "next_action": ("RWP reviews the evidence and applies the mapping by "
                                            "hand" if rec == "map_candidate" else
                                            "RWP/RWDE decision — semantic equivalence is never "
                                            "this tool's call")})
    return out


def _tables_and_cuts(product, path):
    """Load the evidence — a MAPPING_EVIDENCE.json (preferred for AI sessions) or a profiler TSV
    (the governed-platform route). The JSON route VERIFIES ITS BINDING before a single candidate
    is ranked; an external review named what the unbound TSV allowed: a prostate, old-cut, or
    partial profile silently driving an mCRC proposal.
    """
    if path.lower().endswith(".json"):
        with open(path, encoding="utf-8") as fh:
            evd = json.load(fh)
        base = os.path.basename(path)
        # Version 1.0 evidence carried whatever the operator TYPED as its binding — the defect
        # the derived binding closes. Older files are refused, not grandfathered. 1.2 only ADDS
        # column_types beside 1.1's shape, so both derived-binding versions read the same here.
        if evd.get("mapping_evidence_version") not in ("1.1", "1.2"):
            sys.exit(f"EVIDENCE REFUSED — {base} is mapping_evidence_version "
                     f"{evd.get('mapping_evidence_version')!r}, and this tool requires a "
                     f"derived-binding version ('1.1'/'1.2'). Regenerate it with the current "
                     f"mapping_evidence.py.")
        cfg = load_config(os.path.join(product, "config", "data_product.yaml"))
        if evd.get("product") != cfg.data_product_id:
            sys.exit(f"EVIDENCE BINDING MISMATCH — {base} was produced for "
                     f"product {evd.get('product')!r} and this pack is {cfg.data_product_id!r}. "
                     f"A proposal from another product's delivery is evidence about nothing.")
        if evd.get("profile_mode") != "full":
            sys.exit(f"EVIDENCE REFUSED — profile_mode is {evd.get('profile_mode')!r}, not "
                     f"'full'. A candidate absent from a partial profile is not absent from the "
                     f"delivery, and absence is half of every conclusion this tool draws.")
        if evd.get("source_mode") == "synthetic":
            sys.exit("EVIDENCE REFUSED — source_mode is 'synthetic'. Fixture-derived evidence "
                     "must never drive a mapping proposal about a delivery.")
        # The HUMAN act the file exists to record. mapping_evidence.py writes
        # `requires_human_review`; a person who confirms the file carries names and kinds only
        # edits state to `reviewed` and signs. Until then the file is a candidate for review,
        # not evidence — and a signature that is not a person's name is not a signature.
        from product_gates import bad_date, not_a_person, unstated          # noqa: PLC0415
        rev = evd.get("ai_eligibility") or {}
        if rev.get("state") != "reviewed":
            sys.exit(f"EVIDENCE REFUSED — {base} is ai_eligibility state "
                     f"{rev.get('state')!r}, not 'reviewed'. A person reads the file, confirms "
                     f"it carries names and kinds only, edits state to 'reviewed' and signs "
                     f"reviewed_by / review_date. This tool does not proceed on an unreviewed "
                     f"file, and no AI session performs the review.")
        for field, checkfn in (("reviewed_by", not_a_person), ("review_date", bad_date)):
            value = rev.get(field)
            why = "is not set" if unstated(value) else checkfn(value)
            if why:
                sys.exit(f"EVIDENCE REFUSED — {base} ai_eligibility.{field}: {why}. The review "
                         f"is a named person's act on a date, or it did not happen.")
        if not evd.get("tables"):
            sys.exit(f"EVIDENCE REFUSED — {base} lists no tables. Empty evidence would make "
                     f"every role look undeliverable, which is a conclusion, not an absence.")
        # THE DETACHED HALF OF THE APPROVAL. The in-file `reviewed` block above records the
        # human read, but an in-file state is mutable: the table list can be edited after the
        # review while the state text stands. The registration in source_refs.yaml binds the
        # approval to the EXACT BYTES and to the parent profile — evidence that drifted from
        # its registered digest is not the evidence the person reviewed.
        import hashlib                                                      # noqa: PLC0415
        import source_manifest as sm                                        # noqa: PLC0415
        reg = sm.ai_mapping_evidence(product)
        if reg is None:
            sys.exit(f"EVIDENCE NOT REGISTERED — {base} carries an in-file review but no "
                     f"`ai_mapping_evidence` material in source_refs.yaml. A person registers "
                     f"the file (sha256, parent_profile_sha256, approved_by, approval_date) — "
                     f"the in-file state alone is mutable and does not cross the AI boundary.")
        missing = [f for f in sm.AI_MAPPING_EVIDENCE_FIELDS if sm.field_unstated(reg, f)]
        if missing:
            sys.exit(f"EVIDENCE REFUSED — the ai_mapping_evidence registration leaves "
                     f"{', '.join(missing)} unstated. Every field is a way the approval could "
                     f"otherwise outlive what it was given over.")
        with open(path, "rb") as fh:
            actual = hashlib.sha256(fh.read()).hexdigest()
        if actual != reg.get("sha256"):
            sys.exit(f"EVIDENCE DRIFTED — {base} hashes {actual[:16]}… but the registered "
                     f"approval covers {str(reg.get('sha256'))[:16]}…. The file changed after "
                     f"a person approved it. Re-review and re-register, or restore the bytes.")
        if evd.get("profile_sha256") != reg.get("parent_profile_sha256"):
            sys.exit(f"EVIDENCE REFUSED — the file derives from profile "
                     f"{str(evd.get('profile_sha256'))[:16]}… but the registration names "
                     f"parent {str(reg.get('parent_profile_sha256'))[:16]}…. The approval and "
                     f"the derivation disagree about which delivery this evidence describes.")
        reg_name = os.path.basename(str(reg.get("path_or_link") or ""))
        if reg_name and reg_name != base:
            sys.exit(f"EVIDENCE REFUSED — the registration names {reg_name!r} and this run "
                     f"opened {base!r}. Matching bytes under a different name is a copy the "
                     f"approval never named; register the file actually in use.")
        # column_types RIDE ALONG rather than being discarded:
        # the candidate output can then show a physical type beside each proposed column, so
        # the person applying a mapping sees `character` where the engine expects a date —
        # still names and kinds only, never values, and never a verdict.
        types = evd.get("column_types") or {}
        tables = {tbl: {col: {"kind": kind,
                              **({"type": (types.get(tbl) or {}).get(col)}
                                 if (types.get(tbl) or {}).get(col) else {})}
                        for col, kind in cols.items()}
                  for tbl, cols in evd["tables"].items()}
        return tables, set(evd.get("cuts") or [])
    return profile_io.load(path)


def validate_mapping(product, profile_path, pairs):
    """Deterministic blockers for role=table pairs a person is CONSIDERING. Exit material.

    The checks are presence-shaped on purpose — table delivered, required columns present, declared
    grain key present. 'The column means what the requirement means' is not checkable here and is
    not claimed; passing this gate earns a mapping the right to be REVIEWED, not applied.
    """
    tables, _ = _tables_and_cuts(product, profile_path)
    cfg = load_config(os.path.join(product, "config", "data_product.yaml"))
    req = ev.required_columns(cfg)
    grain_decl, _ = ev.source_grain(cfg)
    problems = []
    for role, tbl in pairs:
        # The evidence bar comes from what the config actually READS for this role. An external
        # review caught the earlier lookup: an UNKNOWN role had an empty required set, so any
        # existing table validated it. A role neither declared nor read by any block has no bar
        # to validate against, and "no bar" must refuse, never pass.
        if role not in cfg.sources and role not in set(ev.referenced_sources(cfg)):
            problems.append(f"{role}={tbl}: unknown role — declared by no config and read by no "
                            f"block, so there is nothing to validate this mapping against")
            continue
        need = req.get(role) or needed_columns(product, role)
        cols = {c.lower() for c in tables.get(tbl, {})}
        if not cols:
            problems.append(f"{role}={tbl}: table not in the delivered profile "
                            f"({len(tables)} table(s) profiled)")
            continue
        missing = [c for c in need if c.lower() not in cols]
        if missing:
            problems.append(f"{role}={tbl}: required column(s) absent: {', '.join(missing)}")
        key_missing = [c for c in grain_decl.get(role, []) if c.lower() not in cols]
        if key_missing:
            problems.append(f"{role}={tbl}: declared grain key column(s) absent: "
                            f"{', '.join(key_missing)}")
    return problems


def render(doc):
    L = [f"MAPPING EVIDENCE — {doc['pack']}  ·  profile {doc['profile']} (cut {', '.join(doc['cuts'])})",
         "Evidence and blockers only. Nothing below is a mapping; applying one is a person's",
         "reviewed edit to `sources:`, and semantic equivalence is RWP/RWB's question.", ""]
    if not doc["gaps"]:
        L.append("no mapping gaps: every required role is declared, and every declared stem "
                 "matches a profiled table")
    for g in doc["gaps"]:
        L.append(f"  {g['role']}  [{g['kind']}]"
                 + (f"  needed by: {', '.join(g['required_by'][:6])}" if g.get("required_by") else ""))
        for c in g["candidates"]:
            L.append(f"      candidate {c['table']}   ({c['covered']}/{c['of']} required columns)")
            for e in c["evidence"]:
                L.append(f"          + {e}")
            for b in c["blockers"]:
                L.append(f"          ! {b}")
        L.append(f"      recommendation: {g['recommendation']} — {g['why']}")
        L.append(f"      next: {g['next_action']}")
        L.append("")
    return "\n".join(L)


def patch(doc):
    """The commented proposal block for the map_candidate gaps — paste-and-review, never applied."""
    lines = ["# PROPOSED source mappings — evidence-backed candidates, NOT applied.",
             "# Move a line into `sources:` only after reviewing the evidence above it;",
             "# the validators then hold it to account (source_requirements --check, preflight,",
             "# source_grain). Semantic fit is RWP's judgment, recorded where mappings are approved."]
    any_ = False
    for g in doc["gaps"]:
        if g["recommendation"] == "map_candidate":
            # the proposal's OWN answer — re-deriving from the displayed candidates inherits the
            # display truncation's blind spot (the same defect twice: --top 1 hid the second
            # clean candidate once, and score_pack's copy of this line raised StopIteration)
            c = next((c for c in g["candidates"] if c["table"] == g["proposed"]), None)
            note = f"    # {c['covered']}/{c['of']} required columns present" if c else ""
            lines.append(f"#   {g['role']}: {g['proposed']}{note}")
            any_ = True
    if not any_:
        lines.append("#   (no gap reached map_candidate — nothing is mechanically proposable)")
    return "\n".join(lines)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("pack")
    ap.add_argument("--profile", required=True,
                    help="the evidence: a MAPPING_EVIDENCE.json (mapping_evidence.py; binding-"
                         "verified, the route an AI session uses after a person clears the file) "
                         "or a data_profiler.R TSV (the governed-platform route — the TSV itself "
                         "is restricted material and must not be pasted into an AI interface)")
    ap.add_argument("--format", choices=("text", "json"), default="text")
    ap.add_argument("--patch", action="store_true",
                    help="also print the commented proposal block for map_candidate gaps")
    ap.add_argument("--validate", action="append", default=[], metavar="ROLE=TABLE",
                    help="deterministic blockers for a mapping a person is considering; exit "
                         "non-zero on any. Passing earns review, never application")
    ap.add_argument("--top", type=int, default=3)
    a = ap.parse_args(argv)
    product = os.path.abspath(a.pack)
    if a.validate:
        pairs = []
        for v in a.validate:
            if "=" not in v:
                sys.exit(f"--validate takes ROLE=TABLE, got {v!r}")
            role, tbl = v.split("=", 1)
            pairs.append((role.strip(), tbl.strip()))
        problems = validate_mapping(product, a.profile, pairs)
        for p_ in problems:
            print(f"  ! {p_}")
        if not problems:
            print(f"{len(pairs)} mapping(s): no deterministic blocker. This earns a review, not "
                  f"an application — semantic fit is still a person's call.")
        return 1 if problems else 0
    doc = proposal(product, a.profile, top=a.top)
    if a.format == "json":
        print(json.dumps(doc, indent=2))
    else:
        print(render(doc))
        if a.patch:
            print(patch(doc))
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
