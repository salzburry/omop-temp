#!/usr/bin/env python3
"""Where one product stands, in the plainest language the evidence allows.

    python3 platform/tools/status.py                                    # every pack, one line each
    python3 platform/tools/status.py products/oncology/prostate/202606  # one pack, in full

FOR THE PERSON WHO IS NOT GOING TO RUN THE OTHER TOOLS. A manager asking "is this ready", a
methodology owner asking "what is waiting on me", someone taking the product over. The six gate tools
each answer their own gate correctly and none of them answers "where is this, and who owes what
next" — assembling that meant running five commands and knowing how to read all five.

WHAT IT ADDS, AND THE ONLY THING IT ADDS, IS THE OWNER AND THE NEXT ACTION. Every gate state, count
and blocker below comes from the tool that owns it: `product_gates.maturity` / `evidence_route`,
`source_manifest.releasable` / `source_status`, `contract_lint.open_decisions`, `finalize.facts`,
and `dry_run.latent` for what is waiting behind the claim. This file re-derives nothing — for the
reason `worksheet` and `demo` re-derive nothing: a status page that recounted anything would be a
second implementation of whichever tool owns that count, and the failure mode is that it eventually
reports a product to be in better shape than it is. That is the one failure a status page must not
have.

Per-gate attribution is by `releasable()`'s own "Gate N:" prefixes PLUS a direct call to each gate's
error function — never by matching message text. `releasable()` reports half its findings under an
`evidence:` prefix carrying no gate number, so the prefixes alone are not the whole list, and an
earlier draft that keyed on them showed Gates 2 and 4 DONE on a pack with neither approval form. An
earlier draft still sorted them by substring, which is a classifier over another module's wording.
Anything the aggregate reports that no per-gate call produced is held against every approval gate
rather than dropped.

WHO ACTS is the exception, and it is defined ONCE, in `OWNER` below. No module owns the gate→role map
today; `governance/WORKFLOW.md` states it in prose, and this is the machine-readable form of exactly
that prose. If the two ever disagree, WORKFLOW.md governs.

READ-ONLY. It writes nothing, reads no vendor data, and contacts nothing.

stdlib only (plus PyYAML, through the tools it calls).
"""
import argparse
import os
import sys
import textwrap

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)
from spec_extract import repo_relative                                  # noqa: E402

import contract_lint    # noqa: E402
import dry_run          # noqa: E402
import finalize         # noqa: E402
import product_gates    # noqa: E402
import source_manifest  # noqa: E402
import worksheet        # noqa: E402 — ONE owner of the disposition counts

# WHO ACTS NEXT AT EACH GATE — the machine-readable form of governance/WORKFLOW.md's role prose, in
# one place. Roles, never names: a person leaves and the gate does not change hands.
OWNER = {1: "RWB (supplies the approved specification) · RWP (registers and checks it)",
         2: "RWP (drafts and QCs) · RWB/methodology (answers the decisions, approves requirements)",
         # "DATA ENGINEERING" WAS INVENTED HERE. WORKFLOW.md's Gate 3 actors are "authorized human
         # maps · validated scripts check · RWP reviews", and the governance vocabulary names RWDE —
         # never a generic engineering function. The label mattered: it read as though choosing which
         # column supplies a clinical concept were an engineering task, when it is the judgement Gate
         # 3 exists to record. Source mapping, the executable configuration, preflight failures and
         # engine gaps are RWP/RWDE work.
         3: "RWDE (supplies schema + profile) · RWP (confirms the mapping is the intended concept)",
         4: "RWP (authors and approves) · RWDE (technical review)",
         5: "RWP (runs it) · QC reviewer (reviews this build's evidence)",
         6: "a named release approver, against one build id and one manifest digest"}

WIDTH = 96


def _rel(root, pack):
    """The pack path as the gates name it — root-relative, forward slashes."""
    return repo_relative(os.path.abspath(pack), os.path.abspath(root))


def _unattributed_note(unattributed):
    """An evidence blocker no per-gate owner claimed — reported, never dropped.

    `maturity_errors` is the aggregate; the per-gate functions below are its named parts. If the
    aggregate grows a part they do not cover, that finding belongs to SOME gate and this tool does
    not know which. Reporting it against every approval gate is the fail-closed answer; dropping it
    would let a new check be invisible here from the day it is added.
    """
    if not unattributed:
        return []
    return [f"{len(unattributed)} evidence blocker(s) stand against this pack's claims that no "
            f"per-gate check accounted for — first: {unattributed[0][:110]}"]


def measures(root, pack):
    """[(measure, position)] — the stakeholder view, in the order a reader asks the questions.

    The evidence was distributed across six registers and a contract, which is defensible for the
    people doing the work and useless to anyone deciding whether to rely on the product. The failure
    it invites is specific: "202 records" and "coverage complete" read as progress toward a released
    product, and neither is a statement about correctness or approval.

    So DISPOSITIONED, DRAFTED, APPROVED and VALIDATED are separate rows and always shown together. A
    pack can have every specification item dispositioned, 202 records drafted and 0 of them approved
    — which is exactly this one — and a page that reported only the first would be true and
    misleading.

    Every number comes from the module that owns it. Nothing is counted here.
    """
    rel = _rel(root, pack)
    st = record_states(pack)
    ready, why = source_manifest.releasable(root, rel)
    passed = sum(1 for _n, _t, state, _b in gates(root, pack) if state == "done")

    rows = [("Gates passed", f"{passed}/6")]
    if st is None:
        rows.append(("Requirements captured", "no contract drafted"))
        return rows
    n = st["records"]
    # `{n}/{n}` WAS A COUNT DIVIDED BY ITSELF. It read as coverage — "202 of 202 requirements
    # captured" — and could not be anything but 100%, on any pack, forever, including one where the
    # specification had 500 rows and somebody had drafted two. The row that LOOKED like the coverage
    # answer was the only row on the page incapable of reporting a shortfall.
    #
    # The real numbers are two different concepts and `worksheet.model` already owns one of them:
    # how much of the SPECIFICATION has been dispositioned, and separately how many RECORDS exist.
    # Prostate has 200 spec items, all dispositioned, and 202 records — two of which cite no row.
    m = worksheet.model(pack) or {}
    items = m.get("items")
    if items:
        rows.append(("Specification items dispositioned",
                     f"{items - (m.get('undispositioned') or 0)}/{items}"))
        rows.append(("Contract records drafted", str(n)))
        # COUNTED DIRECTLY, not as `records - mapped`. Those are two different populations — records
        # on one side, SPEC ITEMS on the other — and subtracting across them reported 3 for prostate
        # where 2 records actually cite no row. The third was an item dispositioned as context, which
        # is not a record at all. A number assembled from two denominators is not a count of anything.
        no_row = sum(
            1 for b in contract_lint.records(contract_lint.read(
                os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md")))
            if not [r for r in (contract_lint._list(b, "spec_refs") or [])
                    if r and r != contract_lint.NO_SPEC_ROW])
        if no_row:
            rows.append(("Records citing no specification row", str(no_row)))
    else:
        # NO EXTRACTION IS NOT ZERO COVERAGE, and it is not full coverage either. Saying so beats
        # printing a ratio whose denominator nobody has.
        rows.append(("Specification items dispositioned",
                     "unknown — this pack has no extraction to measure against"))
        rows.append(("Contract records drafted", str(n)))
    rows += [
        ("Requirements approved", f"{st['requirement'].get('approved', 0)}/{n}"),
        ("Requirements blocked on a decision",
         f"{st['requirement'].get('decision_required', 0)}/{n}"),
        ("Validation completed (live)", f"{st['validated_live']}/{n}"),
        ("Vendor-sourced records without Gate 3 evidence", f"{st['unverified_sources']}/{n}"),
    ]
    dec = os.path.join(pack, "handoff", "DECISIONS.md")
    if os.path.exists(dec):
        with open(dec, encoding="utf-8") as fh:
            text = fh.read()
        st_map = contract_lint.decision_status(text)
        rows.append(("Open decisions", str(sum(1 for v in st_map.values() if v == "OPEN"))))
    qc = os.path.join(pack, "handoff", "SPEC_QC_FINDINGS.md")
    if os.path.exists(qc):
        with open(qc, encoding="utf-8") as fh:
            rows.append(("Open specification-QC findings",
                         str(sum(1 for v in contract_lint.decision_status(fh.read()).values()
                                 if v == "OPEN"))))
    rows.append(("Gate 1-4 reasons still open", str(len(why)) if not ready else "0 — cleared"))
    # DELIBERATELY ABSENT: CI status. This tool reads a checkout and cannot know what a runner did;
    # a row saying "passing" because nothing here contradicts it is the one number on this page a
    # reader would most reasonably trust and least be able to check.
    return rows


def record_states(pack):
    """{axis value: count} over the contract's records, and `None` when there is no contract.

    THE one counter over the four status axes. Gate 5 parsed them inline here, and the stakeholder
    measures need the same numbers — a second pass would be two answers to "how many records are
    approved", which is the single most quotable figure this repository produces.

    Absent rather than zero when no contract exists: a pack with nothing to count and a pack whose
    every record is unapproved are different states, and merging them is what the rest of this
    framework spends its machinery refusing.
    """
    contract = os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(contract):
        return None
    with open(contract, encoding="utf-8") as fh:
        ctext = fh.read()
    blocks = list(contract_lint.records(ctext))

    def axis(b, name):
        return contract_lint._kv(contract_lint._inline(b, "status"), name) or ""

    out = {"records": len(blocks)}
    for name, vocab in (("requirement", contract_lint.REQ), ("source", contract_lint.SRC),
                        ("implementation", contract_lint.IMPL), ("validation", contract_lint.VAL)):
        counts = {v: 0 for v in sorted(vocab)}
        for b in blocks:
            v = axis(b, name)
            # The coarse `source` axis is OPTIONAL — a record migrated to the four finer axes
            # (WORKFLOW.md §7) simply does not carry it, and counting its absence as a value would
            # rebuild the absent-counter-read-as-zero defect one row down.
            if v or name != "source":
                counts[v] = counts.get(v, 0) + 1
        out[name] = counts
    # The Gate 3 question has ONE owner (`unverified_sources`, which reads coarse and fine alike).
    # This page used to count the literal `source: unverified` bucket, which a migration to the
    # finer axes would silently drop to 0/202 — an unverified pack reading as fully verified.
    out["unverified_sources"] = len(contract_lint.unverified_sources(ctext))
    # Validation is RANKED, not nominal: `passed_live` implies `passed_test`, and a count of the
    # literal word would report a record validated against live data as not validated against a test.
    out["validated_live"] = sum(
        1 for b in blocks
        if contract_lint.VALIDATION_RANK.get(axis(b, "validation") or "not_run", 0) >= 2)
    out["validated_any"] = sum(
        1 for b in blocks
        if contract_lint.VALIDATION_RANK.get(axis(b, "validation") or "not_run", 0) >= 1)
    return out


def demonstrated(root, pack):
    """[(label, reached, why)] — the four different things this product could be showing.

    "It runs" is four claims wearing one word, and the distance between them is the entire subject
    of this repository:

      framework demonstration    the governance tools ran over the pack's own files. Establishes
                                 that the framework describes the work. Says NOTHING about data.
      synthetic execution        the engine produced values from inputs somebody made up. Proves the
                                 code runs end to end. Proves nothing about the real feed.
      live execution             the engine produced values from the registered source and a human
                                 validated them. This is the first rung that is about the DATA.
      governed production release a named person approved one build id against one manifest digest.

    A walkthrough that ends "all steps completed" lets a viewer take the first for the fourth, and
    that is the specific way a demonstration becomes a false claim. So all four are always printed,
    with the ones NOT reached shown as not reached — the gap is the finding, not a blank.

    NOT A LADDER. Each is answered from its own evidence, so a pack validated live without a
    synthetic run reports exactly that instead of being credited with a run nobody made. Every
    answer comes from the module that owns it; nothing here decides anything.
    """
    st = record_states(pack)
    v = st or {}
    syn = (v.get("validation") or {}).get("passed_synthetic", 0)
    live = v.get("validated_live", 0)
    g6 = next((s for n, _t, s, _b in gates(root, pack) if n == 6), "not started")
    n = v.get("records")
    return [
        ("Framework demonstration", True,
         "the governance tools ran over this pack" if st is None else
         f"the governance tools ran over this pack's {n} record(s)"),
        ("Synthetic execution", syn > 0,
         f"{syn} record(s) validated against synthetic inputs" if syn else
         "no record is validated against synthetic inputs"),
        ("Live execution", live > 0,
         f"{live}/{n} record(s) validated against the registered live source" if live else
         "no record is validated against live data — nothing here is a statement about the feed"),
        # NEVER `yes` FROM A CHECKOUT. The wording was corrected to say publication is not verifiable
        # here, and the tick beside it was left as `g6 == "done"` — so the line still read as an
        # achieved governed production release while its own sentence said the opposite. A reader
        # takes the mark, not the caveat, which is why the mark is the thing that had to change.
        #
        # `g6 == "done"` means an approval FORM names a build id and a manifest digest. That is a
        # fact about a file in this repository. Whether those bytes were published is a fact about a
        # cluster run, recorded in the promotion receipt beside the candidate manifest, and nothing
        # in a checkout has ever seen one. So the claim is False and the reason distinguishes the two
        # states — an approval with no publication is a real and different position from neither.
        ("Governed production release", False,
         "Gate 6's approval is recorded, and publication is NOT verifiable from a checkout — the "
         "promotion receipt lives beside the candidate manifest on the cluster" if g6 == "done" else
         f"Gate 6 is {g6} — no build has been approved and published"),
    ]


def results(root, pack):
    """One machine-readable result per gate — the single answer to "has this gate passed".

    A gate's position was spread across the contract, the coverage report, the decision register, the
    QC register, the engine-gap register and an approval form, and answering "has Gate 2 passed"
    meant reading six files and holding the vocabulary of each. That is how a status comes to be
    maintained by hand, and a hand-maintained status is the thing the six gates exist to replace.

    Every field is DERIVED here and stored nowhere. There is deliberately no writer: an artifact
    carrying `evaluated_at` cannot be byte-compared by a `--check`, and a generated file that drifts
    every run trains people to ignore drift. It goes to stdout, and a consumer captures it.

    `approval` names the FORM each gate requires and who signed it — read from the form, never
    asserted. `inputs` carries the digests that already exist, from the modules that own them; a
    single invented `input_digest` over a set of files nobody hashes together would be a number that
    looks like evidence and is not.
    """
    import datetime
    rel = _rel(root, pack)
    forms = {2: product_gates.CONTRACT_APPROVAL, 4: product_gates.CONFIGURATION_APPROVAL,
             6: product_gates.RELEASE_APPROVAL}
    contract = os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    inputs = {}
    if os.path.exists(contract):
        inputs["contract_sha256"] = product_gates.sha256(contract)
    try:
        inputs["config_bundle_sha256"] = product_gates.config_bundle_sha256(pack)
    except Exception:                                                       # noqa: BLE001
        pass                       # a pack with no config graph yet states no config digest

    out = []
    for n, title, state, blockers in gates(root, pack):
        approval = {"required": n in forms, "form": forms.get(n), "approved_by": None}
        if n in forms:
            doc, err = product_gates.read_yaml(os.path.join(pack, *forms[n].split("/")))
            if not err and isinstance(doc, dict):
                who = str(doc.get("approved_by") or "").strip()
                # An unstated or placeholder name is NOT an approver. `unstated` is the one
                # definition of that, so a form filled with `TBD` cannot read as signed.
                approval["approved_by"] = None if product_gates.unstated(who) else who
        out.append({
            "gate": n, "name": title.lower(), "product": rel,
            "status": state,
            "evaluated_at": datetime.date.today().isoformat(),
            "inputs": inputs,
            "blockers": list(blockers),
            "approval": approval,
        })
    return out


def gates(root, pack):
    """[(n, title, state, [blocker]), …] for the six gates — every field from its owner.

    `state` is one of: done · in progress · not started · blocked · cannot complete. It is DERIVED
    from the same maturity claims and error lists the gates themselves read, never stored: a status
    field somebody edits is the thing this repository spends most of its machinery refusing.
    """
    rel = _rel(root, pack)
    m = product_gates.maturity(pack)
    ready, why = source_manifest.releasable(root, rel)
    out = []

    # PER-GATE ATTRIBUTION COMES FROM `releasable()`'s OWN LABELS, which are already prefixed
    # "Gate N:". An earlier version called two of `maturity_errors`' five sub-checks by hand and then
    # sorted the results between gates by substring — inventing a classifier over another module's
    # message text, which would have mis-filed the first message anyone reworded and silently dropped
    # the three checks it never called. The latent blockers below are NOT split per gate for the same
    # reason: `dry_run` owns that question whole.

    # DONE IS THE GATE'S OWN VERDICT, NOT A SECOND READING OF THE CLAIM. For Gates 1, 2 and 4 that is
    # exactly "`releasable()` reports no reason for this gate" — the same list that supplies the
    # blockers. An earlier version re-read each maturity axis here and compared it to a string, and
    # got Gate 1 wrong in the only way that matters: `source_status()` returns `approved`, the
    # comparison was against `reviewed`, and so a pack whose specification really had been approved
    # would have shown "in progress" forever. It went unnoticed because every pack today is blocked at
    # Gate 1 — the positive path existed in no test and on no pack, which is this repository's most
    # familiar defect wearing new clothes.
    # ...AND THE "Gate N:" PREFIXES ARE ONLY HALF THE LIST. `releasable()` adds every
    # `maturity_errors` finding under an `evidence:` prefix, which carries no gate number: the two
    # approval records, the scaffold rule, the output decisions, the Gate 3 vendor evidence, the
    # decision provenance. Keying `done` off the prefixes alone meant that writing
    # `contract: approved` / `configuration: approved` made the two "not approved" lines disappear
    # while all ten evidence blockers stood — and Gates 2 and 4 reported DONE on a pack carrying
    # NEITHER approval form. A status page that shows a gate complete because someone typed a word is
    # worse than no status page.
    #
    # Attribution is by ASKING THE OWNER, never by matching message text: `contract_approval_errors`
    # is Gate 2's by construction (it already folds in the spec-QC and decision-provenance checks),
    # `configuration_approval_errors` + `output_decision_errors` are Gate 4's.
    ev2 = product_gates.contract_approval_errors(pack, rel, m)
    ev4 = (product_gates.configuration_approval_errors(pack, rel, m)
           + product_gates.output_decision_errors(pack, rel, m))
    # ...and anything `maturity_errors` reports that NONE of those produced is UNATTRIBUTED, so it
    # holds every approval-bearing gate back. That is the drift guard: add a seventh check to
    # `maturity_errors` and this reports it rather than quietly leaving it out of both gates, which
    # is precisely how the bug above would come back.
    unattributed = [e for e in product_gates.maturity_errors(root, rel) if e not in set(ev2 + ev4)]

    def _state(n, started, extra):
        if not [w for w in why if w.startswith(f"Gate {n}")] and not extra and not unattributed:
            return "done"
        return "in progress" if started else "not started"

    # GATE 1 — the source materials.
    src = source_manifest.source_status(pack)
    out.append((1, "Approved inputs", _state(1, src is not None, []),
                [w for w in why if w.startswith("Gate 1")]))

    # GATE 2 — requirements. What a real approval attempt would hit is LATENT and reported as such
    # below, not folded in here as though it were already known.
    c = m.get("contract", "not_started")
    out.append((2, "Requirements and decisions", _state(2, c != "not_started", ev2),
                [w for w in why if w.startswith("Gate 2")] + ev2 + _unattributed_note(unattributed)))

    # GATE 3 — source readiness. `releasable()` carries no "Gate 3:" reason, because Gate 3's evidence
    # is required BY Gate 4 rather than claimed on its own axis. So its two conditions are read from
    # the functions Gate 4 uses for exactly this: every vendor-sourced record has Gate 3 evidence
    # (`unverified_sources`), and the evidence claimed is backed by an artifact
    # (`verdict_evidence_errors`). Not a third definition — the same two calls, asked earlier.
    route, route_why = product_gates.evidence_route(root, rel)
    contract_md = os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    g3 = []
    if not route:
        g3.append(f"evidence route undecided: {route_why}")
    if not os.path.exists(contract_md):
        g3.append("no contract yet — Gate 3 confirms the mapping a contract record proposes")
    else:
        with open(contract_md, encoding="utf-8") as fh:
            ctext = fh.read()
        unver = contract_lint.unverified_sources(ctext)
        if unver:
            shown = ", ".join(f"{v} ({w})" for v, w in unver[:2])
            g3.append(f"{len(unver)} vendor-sourced record(s) have no Gate 3 evidence — {shown}"
                      + (f" and {len(unver) - 2} more" if len(unver) > 2 else ""))
        ev = product_gates.verdict_evidence_errors(rel, pack, contract_md)
        if ev:
            # Their text is quoted VERBATIM — a finding reworded by a second tool is a finding two
            # tools describe differently. It is phrased for Gate 4 ("configuration:approved but…")
            # because that is where it fires, so the framing goes here, above it, in this tool's own
            # words rather than inside theirs.
            g3.append("the checks below are what Gate 4 will require OF Gate 3, quoted as Gate 4 "
                      "states them:")
            # ...and the conditional rides EVERY element, because a JSON consumer sees an array of
            # strings with no header hierarchy — a bare "configuration:approved but…" line read as
            # a current fact on a pack whose configuration is not_started.
            g3 += [f"(when claimed) {e}" for e in ev]
    out.append((3, "Source and delivery readiness",
                "done" if not g3 else ("in progress" if os.path.exists(contract_md) else
                                       "not started"),
                g3))

    # GATE 4 — executable configuration.
    cfg = m.get("configuration", "not_started")
    out.append((4, "Executable configuration", _state(4, cfg != "not_started", ev4),
                [w for w in why if w.startswith("Gate 4")] + ev4 + _unattributed_note(unattributed)))

    # GATE 5 — validation, DERIVED from the per-record axis rather than asserted. `VALIDATION_RANK` is
    # contract_lint's own ordering (not_run/failed 0 · passed_test 1 · passed_live 2) and is imported,
    # not restated. Only records whose REQUIREMENT is approved are counted: a draft requirement has
    # nothing settled to validate against, so demanding evidence for it would report work that does
    # not exist yet.
    #
    # `records` is ABSENT, not zero, when no contract has been drafted — a pack with nothing to
    # validate and a pack whose every record failed are different states, and `.get(k, 0)` would merge
    # them into the same "0 records" the rest of this framework exists to refuse.
    f = finalize.facts(pack)
    g5, state5 = [], "not started"
    if f.get("records") is None:
        g5 = ["no contract yet — there are no requirements to validate"]
    else:
        with open(contract_md, encoding="utf-8") as fh:
            blocks = list(contract_lint.records(fh.read()))
        approved = [b for b in blocks
                    if contract_lint._kv(contract_lint._inline(b, "status"), "requirement")
                    == "approved"]
        ranks = [contract_lint.VALIDATION_RANK.get(
            contract_lint._kv(contract_lint._inline(b, "status"), "validation") or "not_run", 0)
            for b in approved]
        live = sum(1 for r in ranks if r >= 2)
        tested = sum(1 for r in ranks if r >= 1)
        if not approved:
            state5 = "not started"
            g5 = [f"no record has an approved requirement yet ({len(blocks)} record(s) drafted) — "
                  f"Gate 5 validates settled requirements, and none is settled"]
        elif live == len(approved):
            state5 = "done"
        else:
            state5 = "in progress"
            g5 = [f"{live}/{len(approved)} approved record(s) report validation:passed_live "
                  f"({tested} reach passed_test or better) — the rest are not_run, failed, or "
                  f"validated only against the test/synthetic build"]
    out.append((5, "Validation", state5, g5))

    # GATE 6 — release. Gates 1-4 must pass before the question is even asked.
    #
    # The line here used to say promotion was NOT IMPLEMENTED, and it was right: a rerun mints a new
    # build_id, which moves the manifest digest, so an approval of build A could never be satisfied
    # by a later run B and Gate 6 could refuse a release but never grant one. `release.promotion_plan`
    # is that path — it publishes A's staged bytes without rebuilding — so the sentence would now be
    # false. What remains is what it always was: a person approving one build id and one manifest
    # digest, which no tool may do.
    # GATE 6 COULD NOT REACH `done`, AND ITS BLOCKER LIST COULD NOT REACH EMPTY. The state was
    # hardcoded to blocked/awaiting and the closing sentence was appended unconditionally — so a
    # product that had genuinely been approved and promoted would be reported as unreleased, forever,
    # by the one page a manager reads. Every other gate on this gate's own page can go green.
    #
    # `publish_approval_errors` OWNS the question and is asked, not re-implemented. It takes the
    # build id and manifest digest because the approval binds to a CUT, not to the pack — the same
    # configuration over next month's delivery is a different product. Those two values exist only
    # once a build has run, and a checkout does not have them, so the form's OWN statement of them is
    # what is checked here: a complete, signed approval naming some build and some manifest.
    #
    # That is the most a checkout can honestly say, and the wording says exactly that much. Whether
    # those bytes were actually published happened on a cluster, and this tool has never seen it.
    g6 = ["Gates 1-4 are not all passed, so no build may be released "
          f"({len(why)} reason(s) above)"] if not ready else []
    # GATE 5 IS A PRECONDITION, and it was not one. `ready` is Gates 1-4 only, so a pack whose
    # requirements were approved and whose validation had never run could reach Gate 6 `done` on the
    # strength of a signed form — a released product with no validation evidence, reported as
    # released by the page a manager reads. Release is a decision ABOUT a validated build; the axis
    # that says whether it was validated cannot be optional.
    if state5 != "done":
        g6.append(f"Gate 5 is {state5} — a release approves a VALIDATED build, and this one's "
                  "validation evidence is not complete")
    signed = source_manifest.publish_approval_errors(root, rel, build_id=None, manifest_sha256=None)
    # Only the form-shape findings: the two run-specific comparisons cannot be made from a checkout,
    # and treating "the runner supplied no value" as a blocker would make `done` unreachable again.
    g6 += [e for e in signed if "the runner supplied no value" not in e]
    if not g6:
        out.append((6, "Release", "done",
                    ["the approval names a build id and a manifest digest; whether THOSE bytes were "
                     "published is a fact about the cluster run, not about this checkout"]))
    else:
        out.append((6, "Release", "blocked" if not ready else "awaiting a named approval",
                    g6 + ["a build run stages the candidate and stops; promotion publishes THOSE "
                          "bytes against handoff/RELEASE_APPROVAL.yaml naming that build_id and "
                          "manifest digest. See products/OPERATIONS.md §\"Gate 6\"."]))
    return out


def next_action(root, pack):
    """(gate, who, what) — the first gate that is not done, and the single most useful thing to do.

    "First not done" rather than a priority ranking: the gates are SEQUENTIAL by construction, so the
    earliest open one is the one whose evidence everything after it depends on. Ranking them would
    invent an ordering the framework does not have.
    """
    for n, title, state, blockers in gates(root, pack):
        if state == "done":
            continue
        if n == 2 and blockers:
            open_ds = contract_lint.open_decisions(pack)
            if open_ds:
                return (2, OWNER[2], f"answer the open decisions ({len(open_ds)} open) — run "
                                     f"`decision_packet.py {pack}` and send the packet to the "
                                     f"methodology owner")
        return (n, OWNER[n], blockers[0] if blockers else f"complete Gate {n}: {title}")
    return (None, "—", "every gate is done")


def render(root, pack):
    reg = product_gates.registry_entry(root, pack if os.path.isabs(pack) else _rel(root, pack)) or {}
    m = product_gates.maturity(pack)
    f = finalize.facts(pack)
    L = []
    L.append("=" * WIDTH)
    L.append(f"  {reg.get('name', os.path.basename(pack))}  —  {_rel(root, pack)}")
    L.append("=" * WIDTH)
    L.append(f"  vendor {reg.get('vendor', '—')} · registry status {reg.get('status', '—')} · "
             f"claims: source {source_manifest.source_status(pack) or '—'}, "
             f"contract {m.get('contract', '—')}, configuration {m.get('configuration', '—')}")
    if f.get("records") is None:
        L.append("  no contract drafted yet — nothing has been traced from a specification")
    else:
        # "traced" and "dispositioned" read as near-synonyms and carry different denominators —
        # traced means a record CITES the item; dispositioned (the coverage line) means the item is
        # ACCOUNTED FOR by record or register. Say which this is, so the two lines stop looking
        # like one number disagreeing with itself.
        L.append(f"  {f['records']} contract record(s) over {f['domains']} domain(s); "
                 f"{f['mapped']}/{f['items']} specification item(s) cited by a record "
                 f"(the coverage line below counts items ACCOUNTED FOR — citation or register)")
    L.append("")
    # THE SUMMARY BEFORE THE DETAIL. A reader deciding whether to rely on this product should not
    # have to read six gate sections to learn that nothing is approved. `measures` owns every number
    # here; this loop only lays them out, so the rendered page and `--json` cannot disagree.
    L.append("-" * WIDTH)
    L.append(" WHERE THIS PRODUCT STANDS")
    L.append("-" * WIDTH)
    for label, value in measures(root, pack):
        L.append(f"   {label:<44} {value}")
    L.append("")
    # WHAT THIS PRODUCT IS AND IS NOT SHOWING. The measures above are numbers; these four are the
    # claims a reader will make out of them, and three of the four are usually false.
    L.append("-" * WIDTH)
    L.append(" WHAT HAS ACTUALLY BEEN DEMONSTRATED")
    L.append("-" * WIDTH)
    for label, reached, why in demonstrated(root, pack):
        L.append(f"   [{'yes' if reached else ' no'}]  {label:<30} {why}")
    L.append("")
    for n, title, state, blockers in gates(root, pack):
        L.append("-" * WIDTH)
        L.append(f" GATE {n} · {title.upper()}     [{state}]")
        L.append("-" * WIDTH)
        L.append(f"   who      {OWNER[n]}")
        if not blockers:
            L.append("   waiting on nothing")
        for b in blockers[:5]:
            # WRAPPED, never truncated: the blockers are worded to be actionable, and a sentence
            # cut mid-word at the terminal edge sent readers to --json for the words this view
            # exists to show.
            first, *rest = textwrap.wrap(b, WIDTH - 6, break_long_words=False) or [b]
            L.append(f"   ·  {first}")
            L += [f"      {ln}" for ln in rest]
        if len(blockers) > 5:
            L.append(f"   ·  …and {len(blockers) - 5} more — "
                     f"run `dry_run.py {_rel(root, pack)}` for the full list")
        L.append("")
    # WHAT IS WAITING BEHIND THE CLAIM. A gate that fires only on a claim is invisible until somebody
    # makes it, so the list above is not the whole distance. `dry_run.latent` owns that subtraction —
    # blockers-if-approved minus blockers-today — and it is called, not re-derived: a second opinion
    # about what blocks a release is the one thing this file must not be.
    # ROOT-RELATIVE, like every other gate call — `latent` stages a copy and refuses an absolute path.
    _cur, new, err = dry_run.latent(_rel(root, pack), root)
    L.append("-" * WIDTH)
    L.append(" NOT YET COUNTED ABOVE · what appears only once this pack CLAIMS approval")
    L.append("-" * WIDTH)
    if err:
        L.append(f"   could not be simulated: {err}")
    elif not new:
        L.append("   nothing — the blockers above are the whole Gate 1-4 distance")
    else:
        L.append(f"   {len(new)} latent blocker(s). These are not new problems; they are problems")
        L.append("   nobody has been told about, because no gate asks until the claim is made.")
        for b in sorted(new)[:4]:
            first, *rest = textwrap.wrap(b, WIDTH - 6, break_long_words=False) or [b]
            L.append(f"   ·  {first}")
            L += [f"      {ln}" for ln in rest]
        if len(new) > 4:
            L.append(f"   ·  …and {len(new) - 4} more — "
                     f"run `dry_run.py {_rel(root, pack)}` for all of them")
    L.append("")
    n, who, what = next_action(root, pack)
    L.append("=" * WIDTH)
    L.append("  THE NEXT THING TO DO" + (f"  (Gate {n})" if n else ""))
    L.append("=" * WIDTH)
    L.append(f"   who   {who}")
    for i in range(0, len(what), WIDTH - 9):
        L.append(f"   {'what ' if i == 0 else '     '}  {what[i:i + WIDTH - 9]}")
    L.append("")
    L.append("   No tool here approves anything, answers a decision, or promotes a build. Those are")
    L.append("   human acts recorded in the pack's own files.")
    return "\n".join(L)


def one_line(root, pack):
    n, _who, _what = next_action(root, pack)
    # NOT "RELEASE-READY". `releasable()` answers Gates 1-4 for the PACK — it says nothing about a
    # data cut's validation or about a named approval of a specific build, and the rest of this
    # repository is careful to say so. Labelling it release-ready in the one view a manager reads
    # would reintroduce, in the friendliest possible place, exactly the overstatement everything
    # else here removes.
    ready, why = source_manifest.releasable(root, _rel(root, pack))
    # A PROGRESS column, because "blocked at Gate 1" rendered identically for a 202-record pack
    # and an empty scaffold — the one board a manager reads could not tell work from nothing.
    st = record_states(pack)
    progress = f"{st['records']} record(s) drafted" if st else "no contract yet"
    return (f"  {_rel(root, pack):<42} "
            f"{'GATES 1-4 READY' if ready else 'blocked at Gate ' + str(n) if n else 'blocked':<22}"
            f"{len(why)} open Gate 1-4 reason(s)   {progress}")


def main(argv=None):
    ap = argparse.ArgumentParser(description="Where a product stands, and who acts next.")
    ap.add_argument("product", nargs="?", help="pack path; omit for every pack, one line each")
    ap.add_argument("--json", action="store_true",
                    help="one machine-readable result per gate, plus the stakeholder measures. "
                         "Written to stdout and to no file: a result carrying `evaluated_at` cannot "
                         "be byte-compared by a --check, and a generated file that drifts every run "
                         "teaches people to ignore drift")
    a = ap.parse_args(argv)
    if a.json:
        import json as _json
        if not a.product:
            raise SystemExit("--json takes one pack")
        print(_json.dumps({"product": _rel(ROOT, a.product),
                           "gates": results(ROOT, a.product),
                           "measures": dict(measures(ROOT, a.product)),
                           "demonstrated": [{"claim": c, "reached": r, "evidence": w}
                                            for c, r, w in demonstrated(ROOT, a.product)],
                           "records": record_states(a.product)}, indent=1))
        return 0
    if a.product:
        if not os.path.isdir(a.product):
            raise SystemExit(f"not a pack: {a.product}")
        print(render(ROOT, a.product))
        return 0
    print("=" * WIDTH)
    print("  EVERY GOVERNED PRODUCT")
    print("=" * WIDTH)
    for p in product_gates.products(ROOT):
        try:
            print(one_line(ROOT, os.path.join(ROOT, p)))
        except Exception as e:                                    # noqa: BLE001
            # NAMED, never skipped: a pack this tool cannot read is a finding about that pack, and a
            # status page that quietly omitted it would report fewer problems than exist.
            print(f"  {p:<42} COULD NOT BE READ: {e}")
    print("")
    print("  python3 platform/tools/status.py <pack>   for one product in full")
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    raise SystemExit(main())
