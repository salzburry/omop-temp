#!/usr/bin/env python3
"""The compounding metric: how much of a pack's question load has candidate precedent elsewhere.

    python3 platform/tools/precedent_metric.py                 # every pack
    python3 platform/tools/precedent_metric.py --format json

WHY THIS EXISTS. The platform scales because answered questions compound — a ruling recorded
for one tumour is precedent every later pack inherits. That claim needs a NUMBER: for each
pack, how many of its register's decisions have a resolved decision in another pack close
enough to be a candidate answer? Rising candidate coverage across tumours is the arithmetic of
scalability; flat coverage says the packs are not actually sharing questions.

WHAT THE NUMBER IS AND IS NOT, precisely: a candidate match is TOKEN OVERLAP between question
texts — mechanical closeness, not meaning. Whether a prior ruling truly covers a new pack's
question is a HUMAN call (the same rule as naming and equivalence: semantic sameness is never
the tool's verdict). So every match is phrased as a question with its evidence, the metric is
labelled CANDIDATE coverage, and nothing here marks any decision answered.
"""
import argparse
import json
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import knowledge_graph as kg                                                # noqa: E402

# Words that appear in nearly every decision question and therefore prove nothing about
# closeness. Small and boring on purpose — a clever list would be a semantic judgment.
_STOP = {"the", "a", "an", "is", "are", "was", "of", "to", "for", "and", "or", "in", "on",
         "does", "do", "which", "what", "how", "with", "at", "by", "be", "it", "its", "this",
         "that", "should", "must", "may", "we", "confirm", "keep", "not", "no", "if", "then"}
_MIN_OVERLAP = 0.4     # Jaccard over content words — candidates only; a person decides


def _tokens(text):
    return {w for w in re.findall(r"[a-z0-9_]{3,}", str(text).lower())} - _STOP


def _registers():
    """{pack: {decision_id: {question, status, answer}}} over every real pack.

    An ADAPTER over `knowledge_graph.build()`, which already walks every register through the
    shared column vocabulary — a second glob-and-parse here was the register-reader duplication
    contract_lint's own comments warn about, and it lacked the graph's fail-closed refusal of a
    malformed precedents store."""
    out = {}
    for node in kg.build(ROOT):
        out.setdefault(node["pack"], {})[node["id"]] = {
            "question": node["question"],
            "status": node["status"] or "OPEN",
            "answer": node["answer"],
        }
    return out


def metric(registers=None):
    """Per pack: total decisions, resolved, and CANDIDATE-precedent matches from other packs'
    RESOLVED decisions. Every match carries its evidence and a question — never a verdict."""
    regs = _registers() if registers is None else registers
    report = []
    for pack, decisions in sorted(regs.items()):
        matches = []
        for did, d in sorted(decisions.items()):
            toks = _tokens(d["question"])
            if not toks:
                continue
            for other, othdec in regs.items():
                if other == pack:
                    continue
                for odid, od in othdec.items():
                    if od["status"] != "RESOLVED" or not od["answer"]:
                        continue
                    otoks = _tokens(od["question"])
                    if not otoks:
                        continue
                    j = len(toks & otoks) / len(toks | otoks)
                    if did.split("-")[0] == odid.split("-")[0] or j >= _MIN_OVERLAP:
                        matches.append({
                            "decision": did, "candidate": odid, "candidate_pack": other,
                            "overlap": round(j, 2),
                            "question": f"Does {other}'s resolved {odid} cover {pack}'s "
                                        f"{did}? Mechanical closeness {round(j, 2)} — a "
                                        f"person reads both and decides; nothing is "
                                        f"inherited until they do."})
        with_candidates = len({m["decision"] for m in matches})
        total = len(decisions)
        report.append({
            "pack": pack, "decisions": total,
            "resolved": sum(1 for d in decisions.values() if d["status"] == "RESOLVED"),
            "open": sum(1 for d in decisions.values() if d["status"] == "OPEN"),
            "with_precedent_candidates": with_candidates,
            "candidate_coverage": round(with_candidates / total, 2) if total else None,
            "candidates": matches,
        })
    return report


def render(report):
    L = ["=" * 92, "  PRECEDENT CANDIDATES — mechanical closeness; a person confirms every "
                   "match before it counts", "=" * 92, ""]
    for r in report:
        cov = "—" if r["candidate_coverage"] is None else f"{int(r['candidate_coverage']*100)}%"
        L.append(f"  {r['pack']:<44} {r['decisions']:>3} decision(s) · {r['open']:>3} open · "
                 f"{r['resolved']} resolved · candidate coverage {cov}")
        for m in r["candidates"][:6]:
            L.append(f"      {m['decision']:<22} ~ {m['candidate']} in {m['candidate_pack']} "
                     f"(overlap {m['overlap']})")
        if len(r["candidates"]) > 6:
            L.append(f"      ... and {len(r['candidates']) - 6} more candidate pair(s)")
    L += ["", "  The number to grow: candidate coverage on each NEW pack. Rising coverage is "
             "compounding working;", "  every confirmed inheritance is one question nobody "
             "pays for twice.", "=" * 92]
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--format", choices=("text", "json"), default="text")
    a = ap.parse_args(argv)
    r = metric()
    print(json.dumps(r, indent=2, sort_keys=True) if a.format == "json" else render(r))
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
