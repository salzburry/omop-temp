#!/usr/bin/env python3
"""Validate the inventory's inline coverage and render COVERAGE.md — the new-tumour scoping lookup.

    python3 platform/tools/inventory_coverage.py            # validate + write COVERAGE.md
    python3 platform/tools/inventory_coverage.py --check    # validate + byte-compare, exit 1 on drift

governance/reference/variable_inventory/INVENTORY.yaml carries every variable's engine coverage
INLINE (`coverage: {class, via}`) — one of engine_family (an existing engine family computes it),
config_expressible (existing config patterns cover it, no new engine code), upstream_required (the
engine configures it, but only over a table the VENDOR derives — the platform does not build it) or
engine_gap (new engine work, with what is missing named). The classification living ON the variable is what makes
drift structurally impossible: there is no second file to fall out of sync. This tool is what keeps
the map honest anyway:

  * SHAPE: every variable classified, class from the declared enum, non-empty `via` — an
    unexplained classification is an opinion, and `via` is what the next team checks the claim
    against.
  * RENDER: COVERAGE.md (generated, deterministic) — the per-tumour counts and the full engine_gap
    list, which IS the engineering backlog a new tumour might fund.

Like every generated artifact here, COVERAGE.md is byte-compared by --check; INVENTORY.yaml is the
hand-maintained owner and the Markdown is its view.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
REPO = TOOLS.parent.parent
INV = REPO / "governance" / "reference" / "variable_inventory"
# FOUR classes, because three could not tell "the engine computes this" from "the engine
# configures a table the vendor already computed". An external review caught LINE_OF_THERAPY sitting
# in `engine_family`: `stages/lot.py` takes an already-derived `lot` table and filters, renumbers and
# lower-cases it — it does NOT derive lines from drug episodes with combination windows, gaps and
# maintenance attribution, which is what the master entry describes. Counting that as engine coverage
# reads as a capability the platform does not have, and the difference is exactly what a new tumour
# needs to know: whether the vendor must deliver the derived table.
CLASSES = ("engine_family", "config_expressible", "upstream_required", "engine_gap")


def load():
    # STRICT: a duplicate tumour or variable key would load last-wins, and half a shelf would
    # silently vanish from the coverage map it feeds.
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from engine.strict_yaml import strict_load
    return strict_load((INV / "INVENTORY.yaml").read_text(encoding="utf-8"))


def coverage_errors(doc) -> list:
    out = []
    if doc.get("status") != "reference_only":
        out.append("INVENTORY.yaml must say status: reference_only — an inventory that reads as "
                   "approved is a specification wearing a survey's name")
    declared = set((doc.get("classes") or {}))
    if declared != set(CLASSES):
        out.append(f"INVENTORY.yaml classes {sorted(declared)} != {sorted(CLASSES)}")
    for slug, entry in sorted((doc.get("tumours") or {}).items()):
        for v in entry.get("variables", []):
            name = v.get("name") or "?"
            c = v.get("coverage")
            if not isinstance(c, dict) or c.get("class") not in CLASSES:
                out.append(f"{slug}.{name}: coverage.class must be one of {CLASSES}")
            elif not str(c.get("via") or "").strip():
                out.append(f"{slug}.{name}: empty coverage.via — an unexplained classification is "
                           f"an opinion, and via is what the claim is checked against")
    return out


def render_md(doc) -> str:
    tumours = doc.get("tumours") or {}
    lines = [
        "# Engine coverage of the variable inventory",
        "",
        "**GENERATED from INVENTORY.yaml by `platform/tools/inventory_coverage.py` — edit the",
        "inline `coverage:` on each variable, then regenerate. `--check` refuses a stale copy.",
        "`reference_only`, like the inventory it summarises.**",
        "",
        "Classes: **engine_family** — an existing engine family computes it (config names the",
        "parameters); **config_expressible** — existing config patterns cover it, no new engine",
        "code; **upstream_required** — the engine configures it, but only over a table the VENDOR",
        "derives, so the platform does not build the variable and a delivery lacking that table",
        "cannot produce it; **engine_gap** — new engine work is needed, and `via` names what is",
        "missing.",
        "",
        "| tumour | variables | engine_family | config_expressible | upstream_required | engine_gap |",
        "|---|---|---|---|---|---|",
    ]
    totals = {c: 0 for c in CLASSES}
    for slug in sorted(tumours):
        counts = {c: 0 for c in CLASSES}
        for v in tumours[slug].get("variables", []):
            counts[v["coverage"]["class"]] += 1
            totals[v["coverage"]["class"]] += 1
        n = sum(counts.values())
        lines.append(f"| {slug} | {n} | {counts['engine_family']} | "
                     f"{counts['config_expressible']} | {counts['upstream_required']} | "
                     f"{counts['engine_gap']} |")
    n = sum(totals.values())
    lines.append(f"| **all** | **{n}** | **{totals['engine_family']}** | "
                 f"**{totals['config_expressible']}** | **{totals['upstream_required']}** | "
                 f"**{totals['engine_gap']}** |")
    lines += [
        "",
        "## The engine gaps — the backlog a new tumour might fund",
        "",
        "Every variable below needs engine work before ANY tumour can configure it. Recurring",
        "themes (a score family, a transfusion-burden family, a radiotherapy-course model, dose",
        "modelling, lab-criteria response engines) each serve several tumours at once.",
        "",
    ]
    for slug in sorted(tumours):
        gaps = [(v["name"], v["coverage"]["via"]) for v in tumours[slug].get("variables", [])
                if v["coverage"]["class"] == "engine_gap"]
        if not gaps:
            continue
        lines.append(f"### {slug}")
        lines.append("")
        for name, via in sorted(gaps):
            lines.append(f"- **{name}** — {via}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true",
                    help="validate and byte-compare COVERAGE.md; exit 1 on any problem or drift")
    a = ap.parse_args(argv)
    doc = load()
    errors = coverage_errors(doc)
    if errors:
        for e in errors:
            print(f"  FAIL {e}")
        return 1
    want = render_md(doc)
    md = INV / "COVERAGE.md"
    if a.check:
        have = md.read_text(encoding="utf-8") if md.exists() else None
        if have != want:
            print("DRIFT — COVERAGE.md is stale; regenerate with: "
                  "python3 platform/tools/inventory_coverage.py")
            return 1
        print("current — coverage validates and COVERAGE.md matches")
        return 0
    md.write_text(want, encoding="utf-8")
    total = sum(len(t.get("variables", [])) for t in (doc.get("tumours") or {}).values())
    print(f"OK — {total} variables classified; wrote {md}")
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
