#!/usr/bin/env python3
"""Shared plumbing for the pack-driven, cross-tumour evidence runners.

Two tools produce Gate 3 / build-preflight evidence against a delivered cut — `run_product_profile.py`
(value profile, via DBI/ODBC) and `run_product_schema_check.py` (live schema + observed types, via
Spark). Different runtimes, different evidence, but the same four questions up front: which pack, which
cut, which member schema, and where may the output be written. Each answering those itself is how the
copies drift — and the drift is not cosmetic, because these are the answers that decide whether a piece
of evidence is attributed to the right delivery.

So the answers live here once:

  * `pack_config`  — load the config BESIDE the pack, never the registry's current version for the
                     tumour. A tool stored in the 202606 pack must not start reading 202607 the day the
                     registry moves.
  * `restricted_dir` — an output root outside the checkout. Both tools emit vendor-derived material
                     (top values and date ranges; physical identifiers and observed types), and
                     `.gitignore` stops a commit, not a read by an indexing tool or any local process.
  * `targets`      — which schemas this invocation covers. One run covers ONE member; the union is
                     iterated, never merged.
  * `evidence_dir` — `<root>/<product_id>/<schema>/<cut>/`. Per product AND per member, so a second
                     member's run cannot overwrite the first's evidence.

stdlib + PyYAML.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from product_gates import union_members                              # noqa: E402 — ONE member parser
from spec_extract import inside_checkout                             # noqa: E402 — ONE containment test
from engine.config import load_config                                # noqa: E402
from engine.validate import PLACEHOLDER                              # noqa: E402 — ONE marker

TOOLS = os.path.dirname(os.path.abspath(__file__))
CHECKOUT = os.path.dirname(os.path.dirname(TOOLS))


def config_path(pack):
    """The pack's config, or exit saying it is not a pack. Checked FIRST by every caller: telling
    someone to set --out-dir for a directory that holds no config sends them to fix the wrong thing."""
    path = os.path.join(pack, "config", "data_product.yaml")
    if not os.path.exists(path):
        sys.exit(f"{pack}: no config/data_product.yaml — not a product pack")
    return path


def pack_config(pack, cut, schema):
    """The config BESIDE the pack, with the cut and member schema pinned onto it."""
    return load_config(config_path(pack),
                       overrides={"run.refresh": cut, "run.source_schema": schema})


def product_id(cfg, pack):
    return str(cfg.raw.get("data_product_id") or os.path.basename(pack.rstrip(os.sep)))


def restricted_dir(out_dir, what="evidence"):
    """An absolute output root that is NOT inside the checkout."""
    resolved = os.path.realpath(os.path.expanduser(out_dir))
    if inside_checkout(resolved, CHECKOUT):
        sys.exit(f"--out-dir {resolved} is inside the checkout at {CHECKOUT}.\n"
                 f"Restricted {what} must live outside the repository: .gitignore prevents a\n"
                 "commit, not a read by an indexing tool, an agent search, or any local process.")
    return resolved


def targets(pack, a, allow_unset=False):
    """The schemas this invocation covers, after validating the member arguments.

    `a` is the parsed argparse namespace; it must carry .member, .all_members and .schema. One profile
    or schema report covers ONE member — a union is iterated, never merged, because one run cannot
    speak for a schema it did not read.
    """
    members = union_members(pack)
    if a.all_members and not members:
        sys.exit(f"{pack} declares no source_union — drop --all-members")
    if a.member and members and a.member not in members:
        sys.exit(f"--member {a.member!r} is not declared by this pack. Declared: {', '.join(members)}")
    if members and not (a.member or a.all_members or allow_unset):
        sys.exit(f"{pack} declares a source_union over {len(members)} members "
                 f"({', '.join(members)}).\nOne run covers ONE member. Pass --member <schema>, or "
                 f"--all-members to do each in turn.")
    out = members if a.all_members else [a.member] if a.member else [a.schema]
    if not allow_unset and not all(t and PLACEHOLDER not in str(t) for t in out):
        sys.exit("set --schema (or DC_SCHEMA) to the delivered source schema")
    return out


def require_cut(cut):
    if not cut or PLACEHOLDER in str(cut):
        sys.exit("set --cut (or DC_CUT) to the delivered refresh, e.g. --cut 2026m06")
    return cut


def evidence_dir(root, pid, schema, cut=None):
    """`<root>/<product_id>/<schema>[/<cut>]`.

    The profiler appends the cut itself, so it passes cut=None and lets R make the leaf; the schema
    checker writes directly and passes the cut. Either way the final location is the same shape, which
    is what lets Gate 4 find both pieces of evidence for one member without a second convention.
    """
    parts = [root, pid, schema] + ([cut] if cut else [])
    d = os.path.join(*parts)
    os.makedirs(d, exist_ok=True)
    return d
