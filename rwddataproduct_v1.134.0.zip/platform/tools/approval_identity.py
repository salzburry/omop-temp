#!/usr/bin/env python3
"""Is any approval in this repository bound to something a person actually signed?

    python3 platform/tools/approval_identity.py            # every governed approval, with its state
    python3 platform/tools/approval_identity.py --check     # exit 1 on what is enforceable TODAY

WHAT WAS MISSING. Every human attribution here is a free-text string: `approved_by`,
`classified_by`, `attested_by`, `validated_by`, `answered_by`, `confirmed_by`. The only check that
touches identity is `person_rules.not_a_person`, whose own docstring says it "CANNOT VERIFY A PERSON
EXISTS and does not pretend to" — it refuses a declared team word and a bare ALL-CAPS acronym.
`approved_by: asdf` with `validated_by: root` satisfies every gate including separation of duties,
because the two strings differ. `governance/APPROVAL_IDENTITY.md` designs the full fix — approval
bound to an authenticated pull-request review — and that design is still not implemented, because
its first step is branch protection, which is a repository-admin act and not a code change.

WHAT `--check` FAILS ON: a malformed signer registry; a forge or automation key registered where
only a person's key belongs; a refresh manifest claiming `released` whose `sign_off.qc_by` /
`released_by` names a function rather than a person (`engine/refresh.py` requires those fields and
can only check them for PRESENCE — the engine may not import `platform/tools`, so the predicate is
applied here instead of copied there); and ANY APPROVAL NO SIGNATURE SUPPORTS that is not recorded
in `governance/approval_baseline.yaml`.

THE BASELINE IS WHY THAT LAST ONE CAN EXIST. Every approval already in this repository predates the
mechanism, no check applied later turns an unsigned commit into a signed one, and a check that went
red on all of them from its first commit would be switched off the same day — after which nothing
would be enforced at all. The baseline records those, keyed on (file, field, who, COMMIT), so the
check is a live rule about new work rather than a verdict on history. Keying on the commit is what
stops it becoming a permanent exemption: re-make one of those approvals and its identity changes,
so it drops out of the baseline and back under the rule. The tool PRINTS the baseline and never
writes it — a judge that could write its own exemption list is a check that can green itself.

WHAT THIS DOES. It enumerates APPROVALS, not files. For each one it finds the commit whose diff
wrote that approval — `git log -G` over the line asserting it, so an unrelated edit elsewhere in
the document does not re-date it — and asks whether that commit carries a signature by a key
`governance/allowed_signers.yaml` registers as `person_review`, and whether that signer IS the
person the approval names.

WHICH FIELD IS THE APPROVAL IS DECLARED PER SURFACE, and that is not cosmetic. A Gate 2 form
records `approved_by` and `spec_qc_reviewed_by`; a Gate 4 form records `approved_by` and
`technically_reviewed_by`. Those are different acts by different people. An earlier version walked
every `*_by` field and treated all of them as approvers, so the QC reviewer's signature
authenticated the approval — the same defect as signing for somebody else, with the two names one
line apart. The other actors are still read and reported, as people who acted and did not approve.

WHAT IT STILL CANNOT DO. A signature says "this signer wrote this line in this commit". It does not
say the signer intended it as an approval, and it does not make the approval correct. Per-approval
immutable events (the design in `governance/APPROVAL_IDENTITY.md`) would say more; `git log -G`
says this much, precisely.

An earlier version claimed the identity comparison in this docstring and never made it: it checked
only that the signing key was registered, so a signature by ANY registered person authenticated an
approval attributed to somebody else. That is the defect class this repository keeps finding — a
header describing a check that does not exist — committed in the tool written to catch it.

WHAT IT DELIBERATELY REFUSES TO COUNT. This repository's history holds 32 signed commits, all of
them GitHub MERGE commits on the forge's own key. They are exactly the shape that makes a wrong fix
tempting: register that key, and 32 signatures verify while authenticating nothing. A forge
signature attests that a merge happened, on a key available to anyone with write access, applied by
the same web-merge operation whether or not a human read the diff. `allowed_signers.yaml` therefore
records what each key ATTESTS, and only `person_review` may support an approval.

WHAT IT CANNOT DO, AND SAYS SO. It cannot authenticate approvals that already exist: every commit
touching `governance/**` and every `source_refs.yaml` is unsigned, and no check applied afterwards
changes that. Those approvals must be re-made under signature or stay unauthenticated. The report
prints the numbers apart — keys registered, approvals authenticated, approvals baselined, approvals
neither — because they need different actions and a single number would hide which is the blocker.

...and it names the surfaces holding NO FILE. Most of them do: no pack has reached Gate 2, 3, 4 or
6 and `work/` does not exist. Printing only the files that exist would report a coverage number
over surfaces that are not covered but simply absent — an absence read as a clean result, which is
the defect this repository has had to fix in five other tools.

READ-ONLY. It signs nothing, registers nothing, and writes nothing. Nothing automated may add an
entry to `allowed_signers.yaml`: registering a key on somebody's behalf forges the exact act the
mechanism exists to prove.
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

from product_gates import not_a_person, read_yaml, unstated             # noqa: E402
from contract_lint import APPROVER_COLUMNS, cell, decision_rows          # noqa: E402
from spec_extract import repo_relative                                   # noqa: E402

REGISTRY = os.path.join("governance", "allowed_signers.yaml")
# The one kind of key that may stand behind a person's approval.
PERSON_REVIEW = "person_review"

# THE FILES THAT CARRY A GOVERNED HUMAN ATTRIBUTION, AND WHICH FIELD ON EACH IS THE APPROVAL.
#
# Matched by SHAPE rather than by a hand list of packs: any pack that grows an approval form is
# covered the day it lands, which a remembered list would not be. Most of these patterns match
# nothing today — that is reported, not hidden.
#
# THE THIRD COLUMN IS THE FIX FOR THE DEFECT THIS TOOL WAS WRITTEN TO CATCH, ONE LEVEL DOWN. The
# first version walked EVERY `*_by` field in the document and called all of them approvers. But an
# approval form records several different acts by several different people: Gate 2's
# `spec_qc_reviewed_by` performed the specification QC, Gate 4's `technically_reviewed_by` reviewed
# the configuration, and neither of them APPROVED anything — `approved_by` did. Under the walk, a
# signature by the technical reviewer authenticated a file whose approver was somebody else, which
# is precisely "a signature by one registered person says nothing about a name somebody else typed"
# with the names one row apart. So the approving field is NAMED per surface, and only it is matched
# against the signer. The other actors are still read, and reported as present-but-not-authenticated
# rather than silently promoted or silently dropped.
#
# `()` means the surface is a MARKDOWN TABLE and the approving cell is `contract_lint`'s
# APPROVER_COLUMNS — one vocabulary for "who approved this row", shared with every gate that reads
# those registers.
APPROVAL_GLOBS = (
    ("products/*/*/*/source_refs.yaml", "Gate 1 registration and classification",
     ("classified_by", "approved_by")),
    ("products/*/*/*/handoff/CONTRACT_APPROVAL.yaml", "Gate 2 contract approval", ("approved_by",)),
    ("products/*/*/*/handoff/CONFIGURATION_APPROVAL.yaml", "Gate 4 configuration approval",
     ("approved_by",)),
    # `validated_by` IS an approval here and not a supporting actor: Gate 5's human exit is recorded
    # on this form, and it is a distinct accountable act from the release approval beside it.
    ("products/*/*/*/handoff/RELEASE_APPROVAL.yaml", "Gate 6 release approval",
     ("approved_by", "validated_by")),
    ("products/*/*/*/handoff/SOURCE_VERDICTS.md", "Gate 3 source verdicts", ()),
    ("products/*/*/*/handoff/DECISIONS.md", "the decision register", ()),
    ("work/*/REQUEST.yaml", "an answered request", ("answered_by",)),
    ("work/*/PROTOCOL.yaml", "a registered protocol", ("registered_by",)),
    # INVENTORY.yaml, not CITATIONS.yaml. `provenance.basis: workbook_confirmed` — the claim that a
    # named person read the approved workbook — hangs off the INVENTORY variables; CITATIONS.yaml
    # holds verification ROUTES and carries no `confirmed_by`. Watching the wrong file meant the one
    # surface here that actually asserts a human act was not being watched at all.
    ("governance/reference/variable_inventory/INVENTORY.yaml", "a workbook confirmation",
     ("confirmed_by",)),
    ("refreshes/*/*/*/*.yaml", "a refresh QC and release sign-off", ("qc_by", "released_by")),
)

# WHERE THE APPROVALS THAT PREDATE THE MECHANISM ARE RECORDED. Grandfathering is by the exact
# (file, field, who, commit) an approval was made in — never by file or by surface — so re-making an
# approval in a NEW commit takes it out of the baseline and back under the check. See `--baseline`.
BASELINE = os.path.join("governance", "approval_baseline.yaml")

# THE REFRESH SIGN-OFF, held to `not_a_person` HERE because it cannot be held to it where it is
# required. `engine/refresh.py` demands `sign_off.qc_by`, `sign_off.released_by` and their dates
# before a manifest may read `released`, and checks them for PRESENCE only — so `qc_by: RWP`
# releases a refresh on a function's authority. The engine cannot call `not_a_person`:
# `engine/validate.py` states outright that the engine must not import `platform/tools`, and
# copying the predicate in is the duplication this repository keeps paying for (two rules, one
# question, drifting apart). A tool reads the same manifests in CI, so the predicate stays in one
# place and the field still gets held to it.
SIGN_OFF_PEOPLE = ("qc_by", "released_by")


def registry(root=REPO):
    doc, err = read_yaml(os.path.join(root, REGISTRY))
    if err:
        return {}, [f"{REGISTRY}: {err}"]
    return (doc or {}), []


def ineligible_keys(doc):
    """{key_id: why} for every key the registry records as unable to support an approval."""
    return {str(k.get("key_id")): str(k.get("why") or k.get("attests") or "recorded ineligible")
            for k in (doc.get("known_ineligible") or []) if isinstance(k, dict)}


def person_keys(doc):
    """{key_id: identity} for every key registered as attesting a PERSON's own review.

    `known_ineligible` is ENFORCED here, not merely documented. It used to be prose that no code
    read: relabelling the forge key `person_review` in `signers:` made it a valid approval key, and
    a test of mine asserted exactly that as if it were the correct behaviour. A registry that
    records why a key cannot support an approval, and then accepts it when somebody types a
    different word next to it, documents the rule instead of applying it.
    """
    bad = ineligible_keys(doc)
    return {str(s.get("key_id")): str(s.get("identity") or "")
            for s in (doc.get("signers") or [])
            if isinstance(s, dict) and str(s.get("attests")) == PERSON_REVIEW
            and str(s.get("key_id")) not in bad}


def _git(root, *args):
    r = subprocess.run(["git", "-C", root, *args], capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    return r.stdout.strip() if r.returncode == 0 else ""


def approval_files(root=REPO):
    """[(path, what it governs, approving fields)] — every file on disk carrying an attribution."""
    return [(rel, what, fields) for _, what, fields, files in surfaces(root) for rel in files]


def surfaces(root=REPO):
    """[(pattern, what it governs, approving fields, [files])] — INCLUDING patterns matching nothing.

    A surface with no files on disk is the report's most misleading state, and it is the state most
    of these are in: no pack has reached Gate 2, 3, 4 or 6, and `work/` does not exist. Returning
    only the matches would print a coverage count over a repository whose Gate 6 release approval is
    not covered but simply ABSENT — an absence read as a clean result, which is the defect this
    repository has had to fix in five other tools. The caller gets the empty lists and has to say so.

    No count is written down here on purpose: a number in a comment is a claim that goes stale
    silently. `render` counts what it finds.
    """
    import glob
    return [(pattern, what, fields,
             [repo_relative(p, root) for p in sorted(glob.glob(os.path.join(root, pattern)))])
            for pattern, what, fields in APPROVAL_GLOBS]


def shallow(root=REPO):
    """Is this checkout missing its history? A SHALLOW clone cannot answer this tool's question.

    `git log -G` walks commits. On a `--depth 1` clone there is exactly one, and git treats it as a
    root — every line in the tree reads as an addition in that commit — so EVERY approval binds to
    HEAD and the answer looks perfectly ordinary. Two consequences, and the second is the serious
    one: the baseline stops matching (noisy but safe), and if HEAD happens to carry a `person_review`
    signature then every approval in the repository reports as AUTHENTICATED BY THAT SIGNER. A
    forgery of exactly the act this tool exists to prevent, reachable by cloning with `--depth 1`.

    So the depth is checked and the tool refuses rather than computing a confident wrong answer.
    This is not a portability nicety: CI's Windows job checks out at the default depth 1, and would
    have run the whole suite against that answer.
    """
    return _git(root, "rev-parse", "--is-shallow-repository").strip().lower() == "true"


SHALLOW_WHY = ("this checkout is a SHALLOW clone, so no commit can be identified as the one that "
               "wrote this approval — on a one-commit history every line reads as written by HEAD. "
               "Clone with full history (`git fetch --unshallow`) before trusting any answer here")


def approval_commit(root, rel, pattern):
    """(sha, signature status, key, signer) for the commit that last WROTE this approval, or None.

    THE UNIT IS THE APPROVAL, NOT THE FILE, and that distinction is the whole point of this
    function. `git log -1 -- <path>` finds the last commit that touched the file for ANY reason —
    so a typo fix in a note, signed by anyone, "authenticated" every approval in the document,
    including ones written years earlier by other people in unsigned commits. The signature that
    can stand behind `approved_by: X` is the one on the commit whose diff wrote `approved_by: X`.

    `-G` searches the DIFF TEXT with a regex, so this asks git the exact question: which commits
    touching this file changed a line asserting this approval? The most recent one is the commit
    that put the value in its current form — a later removal would mean the value is not in the
    file, and this is only ever called for values that are.

    It cannot separate an addition from a reformatting of the same line, and does not claim to: both
    are "the commit that last wrote this assertion", which is what a signature would be attesting.

    `%G?` is git's own verdict: G good, B bad, U good-with-unknown-trust, X expired, Y expired key,
    R revoked, E cannot check, N none. Anything other than G/U is not a signature this may rely on,
    and `E` — the state every signed commit in this repository is in — means git could not check it.
    """
    line = _git(root, "log", "-1", "--pretty=%H|%G?|%GK|%GS", f"-G{pattern}", "--", rel)
    if not line:
        return None
    sha, status, key, signer = (line.split("|") + ["", "", ""])[:4]
    return {"sha": sha, "status": status, "key": key, "signer": signer}


def sign_off_errors(root=REPO):
    """Refresh manifests whose release sign-off names a function rather than a person.

    Only manifests that actually claim `released` are held to it: a manifest still building has an
    empty `sign_off` block by design, and refusing that would refuse the template.
    """
    import glob
    out = []
    for p in sorted(glob.glob(os.path.join(root, "refreshes", "*", "*", "*", "*.yaml"))):
        doc, err = read_yaml(p)
        rel = repo_relative(p, root)
        if err:
            out.append(f"{rel}: {err}")
            continue
        if not isinstance(doc, dict) or str(doc.get("status") or "") != "released":
            continue
        for f in SIGN_OFF_PEOPLE:
            v = ((doc.get("sign_off") or {}) if isinstance(doc.get("sign_off"), dict) else {}).get(f)
            why = not_a_person(v)
            if why:
                out.append(f"{rel}: `sign_off.{f}`: {why}")
    return out


def _walk_by_fields(node, out):
    """{field name: {values}} for every `*_by` field anywhere in a loaded YAML document.

    KEYED ON THE FIELD, because which field a name sits in is what says WHICH ACT it performed.
    The first version discarded the field and returned a flat set of names, which is how a
    specification QC reviewer and a contract approver became interchangeable.
    """
    if isinstance(node, dict):
        for k, v in node.items():
            if str(k).endswith("_by") and isinstance(v, (str, int, float)):
                got = str(v).strip()
                if got and not unstated(got):
                    out.setdefault(str(k), set()).add(got)
            else:
                _walk_by_fields(v, out)
    elif isinstance(node, (list, tuple)):
        for v in node:
            _walk_by_fields(v, out)


def actors_in(path):
    """({field: {people}}, ok) — everyone a governed file names, and WHICH ACT each performed.

    Without this the tool compared nothing: it checked that the signing key was registered and
    called the file authenticated, so a signature by ANY registered person authenticated an
    approval attributed to somebody else entirely. The docstring claimed the comparison; the code
    never made it. Reading the named actors is what makes "your signature authenticates YOUR typed
    name" true rather than merely stated.

    `ok` is False when the file could not be read at all — distinct from a file that reads cleanly
    and names nobody, because only the second is a finding about the approval.

    A markdown register comes back under the pseudo-field `decision:<id>`, so a decision row is an
    approval in its own right and binds to the commit that wrote THAT row.
    """
    if path.endswith((".yaml", ".yml")):
        doc, err = read_yaml(path)
        if err:
            return {}, False
        found = {}
        _walk_by_fields(doc, found)
        return found, True
    if path.endswith(".md"):
        import re
        try:
            text = open(path, encoding="utf-8", errors="replace").read()
        except OSError:
            return {}, False
        found = {}
        for did, row in decision_rows(text).items():
            got = re.sub(r"[*`_]", "", str(cell(row, *APPROVER_COLUMNS, default="") or "")).strip()
            if got and not unstated(got):
                found.setdefault(f"decision:{did}", set()).add(got)
        return found, True
    return {}, False


def _is_approving(field, declared):
    """Is this field the APPROVING act on its surface? `()` declares a markdown approver column."""
    return field.startswith("decision:") if not declared else field in declared


def _acts(root=REPO):
    """([approvals], [(file, field, who) that are NOT approvals]) — ONE walk of the surfaces.

    Both halves come out of the same read because they are the same reading, split by one predicate:
    which field on this surface carries the approval. Two loops over `approval_files` would open
    every governed file twice and, worse, could come to disagree about which field is which — the
    two callers would then report a person as an approver in one place and a supporting actor in
    the other, with nothing to say which was right.
    """
    import re
    approved, others = [], []
    for rel, what, fields in approval_files(root):
        found, ok = actors_in(os.path.join(root, rel))
        if not ok:
            approved.append({"file": rel, "governs": what, "field": None, "who": None,
                             "pattern": None, "unreadable": True})
            continue
        for field, people in sorted(found.items()):
            for who in sorted(people):
                if not _is_approving(field, fields):
                    others.append((rel, field, who))
                    continue
                # The assertion as it appears in the file, as a diff regex. YAML may quote the
                # value, so the quote is optional; a markdown row carries the decision id and the
                # approver on the SAME line, which is what makes a per-row bind possible at all.
                pattern = (rf"{re.escape(field.split(':', 1)[1])}.*{re.escape(who)}"
                           if field.startswith("decision:")
                           else rf"{re.escape(field)}:\s*[\"']?{re.escape(who)}")
                approved.append({"file": rel, "governs": what, "field": field, "who": who,
                                 "pattern": pattern, "unreadable": False})
    return approved, others


def approvals(root=REPO):
    """[{file, governs, field, who, pattern}] — ONE ENTRY PER APPROVAL, and a `pattern` that
    identifies the line asserting it so a signature can be bound to that line's commit.

    Only the fields each surface declares as APPROVING are here. The others are real acts by real
    people and come back from `other_actors`, never counted as approvals.
    """
    return _acts(root)[0]


def other_actors(root=REPO):
    """[(file, field, who)] — people a governed file names who did NOT approve it.

    Reported rather than dropped. `spec_qc_reviewed_by` performed the specification QC and
    `technically_reviewed_by` reviewed the configuration; both are accountable acts, neither is the
    approval, and a reader who sees only the approvers would think the file named one person. The
    previous version made the opposite error and treated them all as approvers.
    """
    return _acts(root)[1]


def audit(root=REPO):
    """[{file, governs, field, who, commit, authenticated, why}] — one row per APPROVAL."""
    doc, errs = registry(root)
    keys = person_keys(doc)
    bad_keys = ineligible_keys(doc)
    is_shallow = shallow(root)
    rows = []
    for a in approvals(root):
        row = dict(a)
        row["authenticated"] = False
        if a["unreadable"]:
            row["commit"], row["why"] = None, "this file could not be read — nothing to bind"
            rows.append(row)
            continue
        # CHECKED ONCE, BEFORE ANY SIGNATURE IS BELIEVED. See `shallow`: on a depth-1 clone every
        # approval binds to HEAD, and a signed HEAD would authenticate all of them at once.
        if is_shallow:
            row["commit"], row["why"], row["shallow"] = None, SHALLOW_WHY, True
            rows.append(row)
            continue
        c = approval_commit(root, a["file"], a["pattern"])
        row["commit"] = c
        if c is None:
            row["why"] = ("no commit's diff wrote this approval — it is uncommitted, or the value "
                          "reached the file some way `git log -G` cannot see")
            rows.append(row)
            continue
        if c["status"] not in ("G", "U"):
            row["why"] = {"N": "the commit that wrote it is UNSIGNED",
                          "E": "the commit carries a signature git cannot verify (no key "
                               "registered)",
                          "B": "the commit's signature is BAD",
                          "X": "the signing key had expired",
                          "Y": "the signature was made by an expired key",
                          "R": "the signing key was revoked"}.get(
                              c["status"], f"signature status {c['status']}")
            rows.append(row)
            continue
        if c["key"] not in keys:
            row["why"] = (f"signed by key {c['key']}, which {REGISTRY} does not register as "
                          f"{PERSON_REVIEW}")
            if c["key"] in bad_keys:
                row["why"] = (f"signed by key {c['key']}, which {REGISTRY} records as INELIGIBLE "
                              f"to support an approval: {bad_keys[c['key']]}")
            rows.append(row)
            continue
        # ...AND THE SIGNATURE MUST BE THIS APPROVER'S OWN. A signature by one registered person
        # says nothing about a name somebody else typed — including a name in the same file, one
        # field away, recording a different act.
        signer = keys[c["key"]]
        if signer != a["who"]:
            row["why"] = (f"signed by {signer}, but this approval is attributed to {a['who']} — a "
                          f"signature authenticates the signer's OWN typed name, never somebody "
                          f"else's")
            rows.append(row)
            continue
        row["authenticated"] = True
        row["why"] = f"signed by {signer}, who is the person it is attributed to"
        rows.append(row)
    return rows, errs


def _key(row):
    """The identity of ONE approval, as the baseline records it. Not the file — a file grows new
    approvals, and grandfathering a file would grandfather every one it ever gains."""
    return (row["file"], row.get("field") or "", row.get("who") or "",
            (row.get("commit") or {}).get("sha") or "")


def baseline(root=REPO):
    """({identity: why}, [errors]) — the approvals recorded as predating the mechanism.

    KEYED ON THE COMMIT as well as the name, and that is what keeps it from becoming a permanent
    exemption. Re-make an approval — edit the value, or write it again in a new commit — and its
    identity changes, so it drops out of the baseline and back under `--check`. A baseline keyed on
    the file would have exempted a Gate 6 release approval added tomorrow to a file whose Gate 1
    classification was grandfathered today.
    """
    path = os.path.join(root, BASELINE)
    if not os.path.exists(path):
        return {}, []
    doc, err = read_yaml(path)
    if err:
        return {}, [f"{BASELINE}: {err}"]
    out, errs = {}, []
    for i, e in enumerate(((doc or {}).get("baselined") or [])):
        if not isinstance(e, dict):
            errs.append(f"{BASELINE}[{i}]: not a mapping")
            continue
        missing = [f for f in ("file", "field", "who", "commit") if not str(e.get(f) or "").strip()]
        if missing:
            errs.append(f"{BASELINE}[{i}]: no {', '.join(missing)} — an entry that does not name "
                        f"exactly one approval in exactly one commit exempts more than it should")
            continue
        out[(str(e["file"]), str(e["field"]), str(e["who"]), str(e["commit"]))] = \
            str(e.get("why") or "recorded as predating the mechanism")
    return out, errs


def render(rows, doc, errs, root=REPO):
    keys = person_keys(doc)
    known, base_errs = baseline(root)
    signed = [r for r in rows if r["authenticated"]]
    grandfathered = [r for r in rows if not r["authenticated"] and _key(r) in known]
    live = [r for r in rows if not r["authenticated"] and _key(r) not in known]
    L = ["APPROVAL IDENTITY — is any approval bound to something a person signed?", ""]
    for e in list(errs) + base_errs:
        L.append(f"  !! {e}")
    L += [f"  registered `{PERSON_REVIEW}` keys: {len(keys)}",
          f"  governed approvals:               {len(rows)}",
          f"  authenticated:                    {len(signed)}",
          f"  baselined (predate the mechanism):{len(grandfathered):>3}",
          f"  unauthenticated and NOT baselined:{len(live):>3}",
          ""]
    if any(r.get("shallow") for r in rows):
        L += ["  THIS CHECKOUT IS SHALLOW, and nothing below is an answer about signatures.",
              "  `git log -G` needs history: on a one-commit clone every approval binds to HEAD, so",
              "  a signed HEAD would report every approval in the repository as authenticated by",
              "  that signer. Run `git fetch --unshallow` and try again.", ""]
    if not keys:
        L += ["  NO KEY IS REGISTERED, so no signature could authenticate anything even if one",
              "  existed. Registering a key is a person's act and a five-minute one; nothing here",
              "  may do it, because registering a key on somebody's behalf forges the identity the",
              "  mechanism exists to prove.", ""]
    unsigned = [r for r in rows if r["commit"] and r["commit"]["status"] == "N"]
    if unsigned:
        L += [f"  {len(unsigned)} of {len(rows)} approval(s) were written by an UNSIGNED commit.",
              "  This cannot be fixed after the fact: no check applied later turns an unsigned",
              "  commit into a signed one. Those approvals are re-made under signature or they",
              "  stay what they are.", ""]
    for r in rows:
        mark = "ok  " if r["authenticated"] else ("base" if _key(r) in known else "    ")
        where = f"{r['field']}={r['who']}" if r.get("field") else "(unreadable)"
        sha = (r.get("commit") or {}).get("sha") or ""
        L.append(f"  {mark}{r['file']}  {where}")
        L.append(f"      {r['governs']} @ {sha[:12] or '—'} — {r['why']}")
    # THE FILES THAT EXIST AND ASSERT NOTHING. The unit here is the APPROVAL, so a governed file
    # naming nobody contributes no row — and would simply vanish from a report that only counts
    # approvals, which is the same absence-reads-as-clean failure this tool was written around. An
    # empty approver column is a decision register nobody has signed off, not a surface that does
    # not exist, and the two are different things to do something about.
    silent = sorted({rel for rel, _w, _f in approval_files(root)} - {r["file"] for r in rows})
    if silent:
        L += ["", f"  {len(silent)} governed file(s) exist and assert NO approval at all — every",
              "  approver field or column in them is empty. Not covered above, and not evidence:"]
        for rel in silent:
            L.append(f"      {rel}")
    # THE OTHER PEOPLE THESE FILES NAME. They performed real acts — specification QC, technical
    # review — and none of them is the approval. Listed so a reader is not left thinking the file
    # names one person, and listed APART so nothing here reads as authenticated.
    others = other_actors(root)
    if others:
        L += ["", f"  {len(others)} other recorded actor(s) — real acts, none of them the approval,",
              "  and no signature above authenticates any of them:"]
        for rel, field, who in others:
            L.append(f"      {rel}  {field}={who}")
    # THE SURFACES THAT MATCHED NOTHING, said out loud. Without this the count above reads as the
    # whole governed surface when most of it is simply not built yet, and "0 unauthenticated Gate 6
    # release approvals" would mean "no pack has ever released" while looking like "all clear".
    empty = [(p, w) for p, w, _f, files in surfaces(root) if not files]
    if empty:
        L += ["", f"  {len(empty)} of {len(APPROVAL_GLOBS)} governed surface(s) hold NO FILE. Nothing",
              "  above covers them, and nothing above is evidence about them either:"]
        for pattern, what in empty:
            L.append(f"      {pattern}")
            L.append(f"          {what} — no pack or work item has reached it")
    L += ["",
          "  NOTHING HERE IS AN APPROVAL, and a `person_review` signature is not one either: it",
          "  proves WHO wrote the value, never that the value is right. It closes the gap between",
          "  a typed name and an accountable one, which is the whole of what it claims."]
    return "\n".join(L)


def baseline_text(rows):
    """The TEXT of a baseline recording every unauthenticated approval that exists RIGHT NOW.

    RETURNS IT; NEVER WRITES IT, and that is not fastidiousness. This tool is what CI runs to judge
    approvals, and a judge that can write its own exemption list is a check that can green itself:
    one `--write-baseline` step in a workflow file and every unauthenticated approval in the
    repository is grandfathered forever, silently, with the job still passing. `--print-baseline`
    sends this to stdout and a PERSON redirects it, which is a visible act in a diff.

    Written once, at the moment the mechanism lands — everything already in the repository predates
    it, and no check applied afterwards turns an unsigned commit into a signed one. Every approval
    made after that is new work and is held to the mechanism.

    THIS RECORDS NO APPROVAL AND GRANTS NONE. Each entry says "this approval is unauthenticated and
    was made before the mechanism existed", which is the opposite of an approval, and every field
    in it is read out of git rather than typed by anyone.
    """
    lines = [
        "# APPROVALS THAT PREDATE THE IDENTITY MECHANISM — grandfathered, and nothing more.",
        "#",
        "# Every entry here is an approval NOBODY'S SIGNATURE SUPPORTS. This file does not approve,",
        "# authenticate or excuse any of them; it records that they were made before there was a",
        "# mechanism to bind them, so `--check` can fail on NEW unsupported approvals without going",
        "# red on all of history from its first commit — a check that did that would be switched off",
        "# the same day, and then nothing would be enforced at all.",
        "#",
        "# KEYED ON THE COMMIT, not on the file. Re-make one of these approvals and its identity",
        "# changes: it drops out of this list and back under the check. A baseline keyed on the file",
        "# would exempt every approval that file ever gains.",
        "#",
        "# GENERATED, from git, by:",
        "#     python3 platform/tools/approval_identity.py --print-baseline > "
        "governance/approval_baseline.yaml",
        "#",
        "# The tool PRINTS this and never writes it. A judge that could write its own exemption list",
        "# is a check that can green itself — one generate step in a workflow and every",
        "# unauthenticated approval is grandfathered forever with the job still passing. Redirecting",
        "# it is a person's act and shows up in a diff.",
        "#",
        "# Adding an entry by hand exempts a NEW approval from the only check that binds it to a",
        "# person. If you are about to do that, the approval needs a signature instead.",
        "baselined:",
    ]
    for r in sorted(rows, key=_key):
        f, field, who, sha = _key(r)
        if not sha:
            continue
        lines.append(f"  - {{ file: {f}, field: {field!r}, who: {who!r}, commit: {sha},")
        lines.append(f"      why: {r['why']!r} }}")
    return "\n".join(lines) + "\n"


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true",
                    help="exit 1 on any NEW approval no signature supports, on a malformed signer "
                         "registry, and on a released refresh signed off by a function")
    ap.add_argument("--print-baseline", action="store_true",
                    help=f"print a {BASELINE} recording every unauthenticated approval that exists "
                         f"now as predating the mechanism. Redirect it yourself — this tool writes "
                         f"nothing, because a judge that could write its own exemption list is a "
                         f"check that can green itself")
    a = ap.parse_args(argv)
    doc, errs = registry()
    rows, _ = audit()
    if a.print_baseline:
        sys.stdout.write(baseline_text(rows))
        return 0
    print(render(rows, doc, errs))
    if not a.check:
        return 0
    # WHAT `--check` HOLDS. The registry must be well-formed and no key may be registered under an
    # attestation that cannot support an approval; a released refresh may not be signed off by a
    # function; and — the part this gained — NO NEW APPROVAL may exist that no signature supports.
    #
    # "New" means not in `governance/approval_baseline.yaml`, which is keyed on (file, field, who,
    # commit). Everything already here predates the mechanism and no check applied later turns an
    # unsigned commit into a signed one, so failing on all of it from the first commit would get
    # the check switched off the same day and enforce nothing. Failing on what is added AFTER is a
    # live rule about new work rather than a verdict on history — and because the key includes the
    # commit, re-making a baselined approval brings it back under the rule.
    known, base_errs = baseline()
    bad = list(errs) + base_errs + sign_off_errors()
    # A SHALLOW CHECKOUT IS ITS OWN FAILURE, reported once. Left to fall through, it would print one
    # "not in the baseline" line per approval — a page of wrong diagnoses for one cause, and a
    # reader would go looking for approvals nobody had made.
    if any(r.get("shallow") for r in rows):
        bad.append(f"{SHALLOW_WHY}. {len(rows)} approval(s) could not be checked at all.")
        rows = []
    for r in rows:
        if r["authenticated"] or _key(r) in known:
            continue
        where = f"{r['field']}={r['who']}" if r.get("field") else "(unreadable)"
        bad.append(f"{r['file']}: {where} — {r['why']}. This approval is not in {BASELINE}, so it "
                   f"was made after the mechanism existed and must carry a `{PERSON_REVIEW}` "
                   f"signature by the person it names.")
    ineligible = ineligible_keys(doc)
    for s in (doc.get("signers") or []):
        if isinstance(s, dict) and str(s.get("key_id")) in ineligible:
            bad.append(f"{REGISTRY}: {s.get('key_id')!r} is in `known_ineligible:` "
                       f"({ineligible[str(s.get('key_id'))]}) and may not appear in `signers:` "
                       f"under ANY attestation — relabelling a key does not change what it proves")
        if not isinstance(s, dict):
            bad.append(f"{REGISTRY}: a signer entry is not a mapping")
            continue
        if str(s.get("attests")) != PERSON_REVIEW:
            bad.append(f"{REGISTRY}: {s.get('key_id')!r} is registered `{s.get('attests')}` — only "
                       f"`{PERSON_REVIEW}` belongs in `signers:`; a forge or automation key goes in "
                       f"`known_ineligible:` so nobody registers it by mistake")
        for f in ("key_id", "identity", "registered_date", "registered_by"):
            if not str(s.get(f) or "").strip():
                bad.append(f"{REGISTRY}: a signer entry has no {f}")
    for e in bad:
        print(f"  FAIL {e}", file=sys.stderr)
    return 1 if bad else 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
