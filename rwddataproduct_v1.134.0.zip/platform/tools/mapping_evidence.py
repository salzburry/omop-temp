#!/usr/bin/env python3
"""The AI-safe half of a profile: names and kinds, bound to what produced them.

    python3 platform/tools/mapping_evidence.py <profile.tsv> --out MAPPING_EVIDENCE.json

WHY THIS FILE EXISTS. An external review found a contradiction this closes: the mapping skill
handed AI the profiler TSV as "sanitized", while the profiler classifies its own output as NOT
AI-eligible (counts, dates and top values are individual-level evidence) and WORKFLOW.md agrees.
Both sides were right about their own file. The fix is a THIRD file with a fixed schema that
carries only what the mapping copilot actually reads — table names, column names, and the
profiler's own kind vocabulary — and carries its binding on its face: which pack, which schema,
which cut, which mode, and the sha256 of the exact TSV it came from.

THE BINDING IS DERIVED, NEVER TYPED. The first version took product, schema and both modes as
command-line arguments — so the "binding" the consumer verifies was whatever the operator typed,
and a mistyped `--product` re-bound a real profile to the wrong pack with every byte intact. The
profiler stamps its own identity on every row (`profile_product_id`, `profile_schema`,
`profile_cut`, `profile_source_mode`, `profile_mode`; `profile_io.load` proves them constant),
so this tool now reads the binding from the profile and refuses one that does not carry it.
An anonymous profile is not evidence — the same rule Gate 3's `source_check` applies.

`source_mode` follows the same Gate 3 precedent (`source_check.py`): only a `dbi` profile
measured a live feed, so `dbi` -> `delivered` and `local` -> `synthetic` — files someone wrote
are fixture evidence whoever wrote them. The verbatim profiler value is recorded alongside.

WHAT NEVER ENTERS IT: row counts, distinct counts, missing rates, date ranges, top values, or any
free text from the profile. The tool builds the dict from an explicit allowlist; there is no
row passthrough that a new TSV column could ride in on.

STILL NOT AUTOMATICALLY AI-ELIGIBLE. Physical table and column names are vendor-derived
identifiers; WORKFLOW.md admits identifiers after a human vouches for the artifact. The file
states `ai_eligibility: requires_human_review`, and the REVIEW IS RECORDED IN THE FILE: the
person who confirms it carries names and kinds only edits `state` to `reviewed` and signs
`reviewed_by` / `review_date`. `propose_source_mapping` refuses evidence still awaiting that act.
This tool never writes `reviewed` — that is the human's edit, like every approval in this repo.

Run this where the profiler ran — the TSV is restricted material and stays there.
"""
import argparse
import hashlib
import json
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, TOOLS)

import profile_io                                                      # noqa: E402

EVIDENCE_VERSION = "1.2"    # 1.2 adds column_types (schema-level type names beside the kinds)
# The profiler's closed kind vocabulary (data_profiler.R assigns exactly these three). A value
# outside it means the file is not a real profile, and an unrecognised kind must not ride into an
# AI-readable artifact on the assumption it is harmless.
KINDS = ("categorical", "date", "numeric")
# profile_source_mode -> the evidence-level claim. Gate 3's source_check refuses everything but
# `dbi` as "files someone wrote by hand"; mapping evidence draws the same line.
SOURCE_MODES = {"dbi": "delivered", "local": "synthetic"}


def _typename(value, tbl, col):
    """The profiler's schema type as ONE identifier-shaped token, or a refusal. Empty is fine
    (an older profile without the column); anything else must look like a type NAME."""
    v = (value or "").strip()
    if v and not re.fullmatch(r"[A-Za-z][A-Za-z0-9_.]{0,31}", v):
        sys.exit(f"PROFILE REFUSED — {tbl}.{col} carries a type value that is not a bare type "
                 f"name ({v!r}). A free-text value must not ride into an AI-readable file.")
    return v


def build(profile_path):
    """The evidence dict — allowlisted fields only, every binding read from the profile itself."""
    tables, cuts = profile_io.load(profile_path)
    prov = profile_io.provenance(tables)
    missing = sorted(k for k, v in prov.items() if not v)
    if missing:
        sys.exit(f"PROFILE REFUSED — {os.path.basename(profile_path)} carries no embedded "
                 f"provenance for: {', '.join(missing)}. The evidence binding is read from the "
                 f"profile, never typed; re-run data_profiler.R (current version stamps identity "
                 f"on every row). Anonymous evidence is not evidence.")
    if prov["mode"] != profile_io.FULL_PROFILE:
        sys.exit(f"PROFILE REFUSED — profile_mode is {prov['mode']!r}, not "
                 f"'{profile_io.FULL_PROFILE}'. A candidate absent from a partial profile is not "
                 f"absent from the delivery, so a partial profile cannot supply mapping evidence.")
    if prov["source_mode"] not in SOURCE_MODES:
        sys.exit(f"PROFILE REFUSED — profile_source_mode {prov['source_mode']!r} is not one of "
                 f"{', '.join(sorted(SOURCE_MODES))}. An unrecognised mode cannot be classified "
                 f"as delivery or fixture evidence, and unclassifiable refuses.")
    if cuts and prov["cut"] not in cuts:
        sys.exit(f"PROFILE REFUSED — the profiler says cut {prov['cut']!r} but the table names "
                 f"carry {', '.join(sorted(cuts))}. A profile disagreeing with itself about which "
                 f"delivery it measured is evidence for neither.")
    bad_kinds = sorted({(row.get("kind") or "").strip() or "(blank)"
                        for cols in tables.values() for row in cols.values()
                        if (row.get("kind") or "").strip() not in KINDS})
    if bad_kinds:
        sys.exit(f"PROFILE REFUSED — kind value(s) outside the profiler's vocabulary "
                 f"({', '.join(KINDS)}): {', '.join(bad_kinds)}. An unrecognised kind must not "
                 f"ride into an AI-readable file unexamined.")
    with open(profile_path, "rb") as fh:
        digest = hashlib.sha256(fh.read()).hexdigest()
    return {
        "mapping_evidence_version": EVIDENCE_VERSION,
        "product": prov["product_id"],
        "source_schema": prov["schema"],
        "cut": prov["cut"],
        "cuts": sorted(cuts) or [prov["cut"]],
        "profile_mode": prov["mode"],
        "source_mode": SOURCE_MODES[prov["source_mode"]],
        "profile_source_mode": prov["source_mode"],
        "profile_sha256": digest,
        "ai_eligibility": {
            "state": "requires_human_review",
            "note": "table and column names are vendor-derived identifiers. A person reads this "
                    "file, confirms it carries names and kinds only, then edits state to "
                    "'reviewed' and signs reviewed_by / review_date (YYYY-MM-DD). The proposal "
                    "tool refuses the file until then. The profile TSV itself remains restricted "
                    "and never crosses.",
        },
        "tables": {tbl: {col: (row.get("kind") or "").strip()
                         for col, row in sorted(cols.items())}
                   for tbl, cols in sorted(tables.items())},
        # Schema-level TYPE NAMES (the profiler's own `type` column: character/numeric/Date...),
        # beside the kinds. Depth an external review asked for, held inside the boundary: a type
        # name is schema fact, not a measurement — counts, ranges and values still never enter.
        # `_typename` enforces the SHAPE (one identifier-like token) rather than enumerating R
        # classes: a value that is not a bare type name — free text, a delimiter, a pasted
        # sample — is refused, because a passthrough field is how a new TSV column would ride
        # into an AI-readable file unexamined.
        "column_types": {tbl: {col: _typename(row.get("type"), tbl, col)
                               for col, row in sorted(cols.items())}
                         for tbl, cols in sorted(tables.items())},
    }


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("profile", help="the data_profiler.R TSV (restricted; stays where it is)")
    ap.add_argument("--out", required=True, help="where to write MAPPING_EVIDENCE.json")
    a = ap.parse_args(argv)
    doc = build(a.profile)
    with open(a.out, "w", encoding="utf-8") as fh:
        json.dump(doc, fh, indent=1, sort_keys=True)
    print(f"wrote {a.out}: product {doc['product']}, schema {doc['source_schema']}, cut "
          f"{doc['cut']}, {len(doc['tables'])} table(s), profile sha {doc['profile_sha256'][:16]}")
    print("ai_eligibility: requires_human_review — a person confirms names-and-kinds-only, then "
          "edits state to 'reviewed' and signs reviewed_by / review_date in the file.")
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
