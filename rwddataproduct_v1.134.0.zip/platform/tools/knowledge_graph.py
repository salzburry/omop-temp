#!/usr/bin/env python3
"""The programme's decision memory, as a LIVE VIEW over the files that own it — never a store.

The question this answers: "have we decided something like this before, anywhere, and what?" The
answers already exist — every pack's `handoff/DECISIONS.md` holds its rulings with approver and
date, the contracts hold what cites them, `governance/precedents.yaml` holds the human-confirmed
cross-product pairings. What was missing was one place to ASK. This computes that place on demand,
by walking the owning artifacts through their one readers (`contract_lint`, `precedents`), and
holds nothing itself: there is no output file, no cache, no copy that can go stale or drift from
a register. A committed knowledge base would be a second implementation of every register it
summarised, wrong within a week, and read as current — the exact defect the generated-view rule
(`RWB_QUESTIONS.md` + `--check`) exists to prevent, without even the `--check`.

Three verbs:

    python3 platform/tools/knowledge_graph.py --query biomarker window     # search everything
    python3 platform/tools/knowledge_graph.py --decision FUED-DEFINITION   # one question's card
    python3 platform/tools/knowledge_graph.py --suggest                    # unrecorded twins

`--suggest` is the advisory half: pairs of decisions in DIFFERENT packs whose question+evidence
wording overlaps enough to look like one question, that no precedent entry yet pairs. It proposes;
it records nothing — pairing two registers' spellings of one question is a person's judgment, and
`precedents.py --add` is its write path. Token overlap only, no model: a suggester that cannot
explain its match ("these eleven words") is one nobody can review.

Reuse stays governed end to end: a hit here is EVIDENCE to show an answerer, never an approval to
adopt. The answer text is printed with its provenance (pack, approver, date) precisely so nobody
retypes it as their own.

stdlib only. Read-only by construction — this module contains no write call.
"""
import argparse
import glob
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from product_gates import bad_date                            # noqa: E402
from contract_lint import (decision_answer, decision_approval_date,      # noqa: E402
                           decision_approver, decision_evidence, decision_question,
                           decision_rows, decision_status, read, records, _list, _scalar)
from spec_extract import repo_relative, repo_root                        # noqa: E402
import precedents as precedents_store                                    # noqa: E402

ROOT = repo_root(os.path.abspath(__file__))


def packs(root=ROOT):
    """Every product pack keeping a decision register — live packs only, never fixtures."""
    hits = glob.glob(os.path.join(root, "products", "*", "*", "*", "handoff", "DECISIONS.md"))
    # `repo_relative`, not hand-rolled relpath+replace: POSIX ids on every OS (Windows \ broke pack
    # identity), and no ValueError when checkout and path sit on different Windows drives.
    return sorted(repo_relative(os.path.dirname(os.path.dirname(p)), root) for p in hits)


def build(root=ROOT):
    """The graph, computed fresh: one node per decision across every pack, with its citing
    records, its precedent pairings, and the register's own words — by pointer semantics, read at
    call time through the same accessors every gate uses."""
    entries, errs = precedents_store.load(root)
    if errs:
        # Fail-closed, exactly like `precedents.py --check` on the same file. Swallowing the error
        # turned a malformed store into an EMPTY one: recorded pairs re-surfaced as "unrecorded"
        # suggestions and every card silently dropped its precedent line — confident output built
        # on a file that did not parse.
        raise SystemExit("governance/precedents.yaml is unreadable — the graph will not pretend "
                         "it is empty:\n  " + "\n  ".join(errs))
    paired = {}                                     # (pack, decision id) -> precedent entry id
    for e in entries or []:
        for c in (e.get("seen_in") or []):
            paired[(c.get("pack"), c.get("decision"))] = e.get("id")

    nodes = []
    for pack in packs(root):
        text = read(os.path.join(root, pack, "handoff", "DECISIONS.md"))
        rows, status = decision_rows(text), decision_status(text)
        cites = {}
        contract = os.path.join(root, pack, "handoff", "FUNCTIONAL_CONTRACT.md")
        if os.path.exists(contract):
            for block in records(read(contract)):
                vid = _scalar(block, "variable_id") or "?"
                for did in (_list(block, "decision_ids") or []):
                    cites.setdefault(did, []).append(vid)
        for did, row in sorted(rows.items()):
            nodes.append({
                "pack": pack, "id": did,
                "status": str(status.get(did, "")).strip().upper(),
                "question": decision_question(row).strip(),
                "evidence": decision_evidence(row).strip(),
                "answer": decision_answer(row).strip(),
                "approved_by": decision_approver(row).strip(),
                "approval_date": decision_approval_date(row).strip(),
                "cited_by": sorted(cites.get(did, [])),
                "precedent": paired.get((pack, did), ""),
            })
    return nodes


# --- search -----------------------------------------------------------------------------------
STOP = frozenset("a an and are as at be both by each for from has have if in is it neither no not "
                 "of on or same that the them then these this those to two very vs was which "
                 "with".split())


def tokens(text):
    return {t for t in re.findall(r"[a-z0-9]+", (text or "").lower())
            if len(t) > 2 and t not in STOP}


def _anchor(tok):
    """Whether a token can carry a match on its own: content-length words, or numbers long enough
    to be a constant rather than a count — and never a year, which two unrelated questions share
    for merely being contemporaries."""
    if tok.isdigit():
        return len(tok) >= 4 and not re.fullmatch(r"(19|20)\d\d", tok)
    return len(tok) >= 4


def ruled(node):
    """Whether this node carries a RULING — `RESOLVED` **and** signed.

    STATUS ALONE WAS THE TEST, AND STATUS ALONE IS A CLAIM WITH NOBODY BEHIND IT. Prostate's
    register carries STUDY-WINDOW and MAXINDEX as RESOLVED with the approver and approval-date
    columns both blank; an external review found them ranked ahead of open questions and rendered
    as "RESOLVED — approver unstated", which is an unaccountable row presented as reusable
    knowledge. `query()` sorts rulings first precisely so a reader can skim from the top, so the
    predicate that decides what goes on top has to mean something.

    A ruling therefore needs all three: the status, a NAMED approver, and a well-formed approval
    date. `bad_date` is the repository's one date predicate — imported, never a second regex.

    A resolved-but-unsigned row is NOT filtered out: it stays searchable and stays in the results,
    because knowing another pack has already answered your question is real value. It is ranked
    with the open questions and labelled an unverified resolution, which is what it is. Turning it
    into a citable ruling is a signature away, and that signature is a person's to give.
    """
    if node["status"] != "RESOLVED":
        return False
    return bool(node["approved_by"]) and not bad_date(node["approval_date"])


def resolved_unsigned(node):
    """RESOLVED, but with no named approver or no usable date — an answer, not yet a ruling."""
    return node["status"] == "RESOLVED" and not ruled(node)


def query(nodes, terms):
    """Nodes matching every term (case-insensitive substring over question+evidence+answer+id) —
    RULINGS FIRST, then within each half ranked by how much of the node the terms cover. Substring,
    not tokens: a searcher types fragments ('biomark'), and a search that misses a fragment match
    teaches people not to ask.

    Resolved-before-open is deliberate ordering, not filtering: open decisions stay in the results
    (finding that another pack is ASKING your question is real value), but a reader skims from the
    top, and an open question ranked above a ruling by mere term frequency is how a pending question
    gets read — and reused — as settled."""
    wants = [t.lower() for t in terms if t.strip()]
    hits = []
    for n in nodes:
        hay = " ".join((n["id"], n["question"], n["evidence"], n["answer"])).lower()
        if all(w in hay for w in wants):
            hits.append((sum(hay.count(w) for w in wants), n))
    return [n for _, n in sorted(hits, key=lambda x: (not ruled(x[1]), -x[0],
                                                      x[1]["pack"], x[1]["id"]))]


def suggest(nodes):
    """[(anchors, node, node)] — same-question candidates across DIFFERENT packs that no precedent
    entry pairs yet, matched on RARE SHARED ANCHORS: tokens appearing in at most two decisions
    across the whole corpus. Calibrated by MEASURING the live registers, and the measurement threw
    the first design out: plain token overlap scored the two ground-truth twins (the pairs a human
    already recorded in precedents.yaml) at 0.19 and 0.01 — below the non-pair noise floor — while
    each twin shares a rare anchor no noise pair does ('follow' for the follow-up-end pair, '4375'
    for the days-per-month constant). Two registers phrase one question with almost disjoint
    vocabulary; what survives rephrasing is the rare term of art or the constant itself. Rarity,
    not volume, is the signal. Weak anchors survive too — which is why every match PRINTS its
    anchors: a suggester that shows its evidence is one a person can dismiss in seconds, and the
    recording judgment stays entirely with `precedents.py --add`."""
    df = {}
    per = {}
    for n in nodes:
        per[(n["pack"], n["id"])] = tokens(n["question"] + " " + n["evidence"])
        for t in per[(n["pack"], n["id"])]:
            df[t] = df.get(t, 0) + 1
    out = []
    for i, a in enumerate(nodes):
        ta = per[(a["pack"], a["id"])]
        for b in nodes[i + 1:]:
            if a["pack"] == b["pack"]:
                continue
            if a["precedent"] and a["precedent"] == b["precedent"]:
                continue                            # already recorded as one question
            tb = per[(b["pack"], b["id"])]
            anchors = sorted(t for t in (ta & tb) if df[t] <= 2 and _anchor(t))
            if anchors:
                out.append((anchors, a, b))
    return sorted(out, key=lambda x: (-len(x[0]), x[1]["pack"], x[1]["id"]))


# --- rendering --------------------------------------------------------------------------------
# JSON-LD @context: every node key mapped to an IRI, so the export is RDF-ready for any graph
# stack (a triple store, a LinkML/OWL consumer, a graph database) WITHOUT this repo taking a
# modeling-toolchain dependency. The vocabulary is ours — these are governance terms, and mapping
# them onto a public ontology would be a claim of equivalence nobody has reviewed. A test holds
# this context to exactly the node keys, so the export cannot silently drop a field.
CONTEXT = {
    "@vocab": "urn:rwdp:vocab#",
    "pack": "urn:rwdp:vocab#pack", "id": "@id", "status": "urn:rwdp:vocab#status",
    "question": "urn:rwdp:vocab#question", "evidence": "urn:rwdp:vocab#evidence",
    "answer": "urn:rwdp:vocab#answer", "approved_by": "urn:rwdp:vocab#approvedBy",
    "approval_date": "urn:rwdp:vocab#approvalDate", "cited_by": {"@id": "urn:rwdp:vocab#citedByRecord", "@type": "@id"},
    "precedent": {"@id": "urn:rwdp:vocab#precedentEntry", "@type": "@id"},
}


def jsonld(nodes):
    """The graph as JSON-LD — plain JSON with an @context, which is the entire interop story:
    any RDF/graph consumer can ingest it, and this repo ships no new dependency to produce it.
    Node identity is pack-scoped (one decision id may exist in several packs)."""
    graph = []
    for n in nodes:
        e = dict(n)
        e["@type"] = "Decision"
        e["id"] = f"urn:rwdp:{n['pack']}#{n['id']}"
        e["cited_by"] = [f"urn:rwdp:{n['pack']}#record/{v}" for v in n["cited_by"]]
        if n["precedent"]:
            e["precedent"] = f"urn:rwdp:governance/precedents.yaml#{n['precedent']}"
        graph.append(e)
    return {"@context": CONTEXT, "@graph": graph}


def _ruling_label(n):
    """The unmissable half of a card: whether this hit IS a ruling, or merely a question.

    A hit here is evidence to show an answerer, and the failure mode is specific: an OPEN decision
    printed with the same one-word tag as the resolved ones beside it reads as precedent, and gets
    retyped as one. So every card states which it is IN WORDS, never by a tag a reader must already
    know the vocabulary of. RESOLVED carries its approver and date in the label — provenance is what
    makes a ruling citable — and a resolved row whose register names nobody says so rather than
    implying an attribution that was never recorded. Everything that is not RESOLVED (OPEN, but also
    WITHDRAWN, SUPERSEDED, a blank status) is 'no ruling', fail-closed."""
    if ruled(n):
        return f"RESOLVED — ruled by {n['approved_by']} on {n['approval_date']}"
    if resolved_unsigned(n):
        # Named for what it is. "RESOLVED — approver unstated" put the word RESOLVED first and let
        # the qualifier trail, which is how it came to be read as a ruling with a paperwork gap
        # rather than as an answer nobody has signed.
        missing = ("no approver named" if not n["approved_by"]
                   else f"approval date {n['approval_date']!r} is not a date")
        return (f"UNVERIFIED RESOLUTION — {missing}; an answer, not a citable ruling. "
                f"Reuse it as evidence to show an answerer, never as precedent")
    return f"{n['status'] or 'NO STATUS'} — no ruling; a question, not a precedent"


def _card(n):
    lines = [f"{n['pack']}  {n['id']}  [{_ruling_label(n)}]",
             f"  Q: {n['question']}"]
    if n["evidence"]:
        lines.append(f"  evidence: {n['evidence'][:200]}")
    if n["status"] != "OPEN" and n["answer"]:
        # approver + date live in the header label now, so the answer line stays the answer
        lines.append(f"  answer: {n['answer'][:300]}")
    if n["cited_by"]:
        lines.append(f"  cited by: {', '.join(n['cited_by'][:10])}"
                     + (" …" if len(n["cited_by"]) > 10 else ""))
    if n["precedent"]:
        lines.append(f"  precedent: {n['precedent']} (governance/precedents.yaml)")
    return "\n".join(lines)


def main(argv):
    ap = argparse.ArgumentParser(description="Search the programme's decisions, live, with provenance.")
    ap.add_argument("--query", nargs="+", metavar="TERM",
                    help="terms that must ALL appear in a decision's id/question/evidence/answer")
    ap.add_argument("--decision", metavar="ID", help="every pack's card for this decision id")
    ap.add_argument("--suggest", action="store_true",
                    help="cross-pack same-question candidates no precedent entry pairs yet")
    ap.add_argument("--json", action="store_true", help="machine-readable output")
    ap.add_argument("--jsonld", action="store_true",
                    help="the WHOLE graph as JSON-LD on stdout — RDF-ready for external graph "
                         "tools; still computed live, still holding nothing")
    a = ap.parse_args(argv)
    if not (a.query or a.decision or a.suggest or a.jsonld):
        ap.error("one of --query / --decision / --suggest / --jsonld")
    if a.query is not None and not [t for t in a.query if t.strip()]:
        # every-term-matches is vacuously true of NO terms — an empty query would print the whole
        # corpus with a confident "N decision(s) for query ''" banner
        ap.error("--query needs at least one non-blank term")

    nodes = build()
    if a.jsonld:
        print(json.dumps(jsonld(nodes), indent=1, ensure_ascii=False))
        return 0
    if a.decision:
        # rulings first here too — one decision id may exist in several packs with mixed statuses,
        # and the tally below promises the ruled ones lead
        hits = sorted((n for n in nodes if n["id"] == a.decision),
                      key=lambda n: (not ruled(n), n["pack"]))
        label = f"decision {a.decision!r}"
    elif a.query:
        hits = query(nodes, a.query)
        label = f"query {' '.join(a.query)!r}"
    else:
        pairs = suggest(nodes)
        if a.json:
            print(json.dumps([{"anchors": an,
                               "a": {k: x[k] for k in ("pack", "id", "question")},
                               "b": {k: y[k] for k in ("pack", "id", "question")}}
                              for an, x, y in pairs], indent=1))
            return 0
        if not pairs:
            print(f"0 unrecorded same-question candidates across {len(nodes)} decision(s) — "
                  f"anything already paired in governance/precedents.yaml is excluded by design.")
            return 0
        print(f"{len(pairs)} candidate pair(s) — EVIDENCE for a person, recorded (or rejected) "
              f"through `precedents.py --add`, never here:\n")
        for an, x, y in pairs:
            print(f"  shared: {', '.join(an)}")
            print(f"        {x['pack']}  {x['id']}: {x['question'][:96]}")
            print(f"        {y['pack']}  {y['id']}: {y['question'][:96]}\n")
        return 0

    if a.json:
        print(json.dumps(hits, indent=1))
        return 0
    if not hits:
        print(f"no decision matches {label} across {len(nodes)} decision(s) in "
              f"{len(packs())} pack(s). Absence here is absence from the REGISTERS — "
              f"a question never raised, not a question answered elsewhere.")
        return 0          # absence is a successful, structured answer; nonzero now ALWAYS means failure
    # The tally states the split up front, so a page of results cannot read as "N precedents" when
    # most of it is pending questions.
    n_ruled = sum(1 for n in hits if ruled(n))
    print(f"{len(hits)} decision(s) for {label} — {n_ruled} with a ruling (listed first), "
          f"{len(hits) - n_ruled} with no ruling yet:\n")
    for n in hits:
        print(_card(n) + "\n")
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
