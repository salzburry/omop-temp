#!/usr/bin/env python3
"""Scaffold functional-contract records from an extracted RWB specification.

Fills every field a machine can know for certain, and marks the rest TODO. The point is to make the
judgment work visible and small: after this runs, what remains is exactly the set of decisions a person
(or an AI drafting under review) actually has to make — not the mechanical assembly around them.

What the scaffold fills:
  variable_id      the variable name as the spec writes it
  spec_refs        the citation, using the label THIS product's contract already uses
  spec_digest      a hash of the cited row's CONTENT, so an in-place edit to the rule later cannot
                   slip past the record that was written from it
  required_rule    the spec's own Definition cell, VERBATIM — rewrite as a requirement, do not
                   paraphrase away detail
  notes            the spec's Additional Notes, verbatim, plus any deterministic lint findings

What it deliberately leaves TODO — each needs judgment, not lookup:
  source           only a human confirms a column is the RIGHT column (needs the vendor dictionary)
  grain/anchor/window/record_selection/tie_break/missing/units/depends_on
  derivation       the executable rule, as opposed to the spec's prose
  output/publish   naming and downstream surfaces are governed decisions
  acceptance       a worked example with real values

Coverage is computed against the existing contract, so re-running after new records are written shows
only what is still outstanding.

    python3 platform/tools/contract_scaffold.py <extracted.json> --product <product-dir> [--out FILE]
    python3 platform/tools/contract_scaffold.py <extracted.json> --product <dir> --summary

stdlib only.
"""
import argparse
import json
import os
import re
import sys

from contract_lint import (NA, TABLE_COLUMNS, open_decisions, pipe, read,
                           records, spec_digest, spec_ref_rows)
import person_rules                                          # noqa: E402 — stdlib only
from person_rules import not_a_person                        # noqa: E402 — stdlib only
from spec_extract import (CONTEXT_RE, is_context,   # noqa: F401 — CONTEXT_RE re-exported
                          repo_relative, requirement_rows, unmapped_columns)

TODO = "TODO"

# `is_context` moved DOWN to spec_extract, which owns the row shape it reads (`pre_header`, `variable`,
# `cells`) — the extractor needs it too, to keep its POSITIONAL warning off banner rows, and importing
# upward from spec_extract into this module would be a cycle. Imported rather than re-stated: a second
# copy would agree today and diverge on the first change to what counts as a banner, and the two sides
# of that disagreement are "this row needs a contract record" and "this row does not".


def declared_dispositions(product_dir):
    """Explicit dispositions for items no record cites — handoff/spec_dispositions.yaml.

    Without this, "handled somewhere other than a per-variable record" and "overlooked" are
    indistinguishable in the coverage report. Each entry must name where the item IS handled, so the
    claim can be checked rather than taken on trust.
    """
    path = os.path.join(product_dir, "handoff", "spec_dispositions.yaml")
    if not os.path.exists(path):
        return {}
    out, cur = {}, None
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            if line.lstrip().startswith("#"):
                continue
            m = re.match(r'\s*"([^"]+)":\s*$', line)
            if m:
                cur = m.group(1)
                out[cur] = {}
                continue
            m = re.match(r"\s+(disposition|handled_by|note|duplicate_of|decision_id|approved_by):"
                         r"\s*(.+?)\s*$", line)
            if m and cur:
                out[cur][m.group(1)] = m.group(2).strip().strip('"')
    return out


# What each disposition must PROVE. Without this the register accepts any word, and "excluded" — the
# one disposition that removes a requirement from the product — was the easiest to write and the least
# evidenced. Two ovarian rows were dispositioned `excluded` while their own text said they had been
# raised as open questions; that made coverage read complete over an unresolved choice.
DISPOSITION_EVIDENCE = {
    "control":           ["handled_by"],
    "codelist":          ["handled_by"],
    "population":        ["handled_by"],
    "context":           ["handled_by"],
    "duplicate":         ["handled_by", "duplicate_of"],
    "decision_required": ["handled_by", "decision_id"],
    "excluded":          ["handled_by", "approved_by"],
}


def extraction_integrity(data, lint, tabs):
    """Reasons to doubt that the extractor READ the specification, as opposed to defects IN it.

    The distinction is what keeps `coverage_complete` meaningful. An impossible date is a defect in
    RWB's document: it can be fully captured, cited by a record and answered by a decision, so it must
    not block coverage. A requirement sheet whose Definition column never resolved is different —
    coverage would count items whose text the extractor never located, and report 100%.

    Everything here is already computed; this only decides which facts are disqualifying.
    """
    out = []
    e = data.get("extraction", {})
    # Requirement sheets only. An ambiguity on a change log or a review-decision tab is not a reason
    # coverage over the specification is incomplete.
    scanned = {r["tab"] for r in requirement_rows(data, tabs)}
    for c in e.get("columns_ambiguous") or []:
        if c.get("tab") not in scanned:
            continue
        out.append(f"{c['tab']}: two visible columns resolve to `{c['field']}` — kept column "
                   f"{c['kept_column']} '{c['kept_header']}', ignored column {c['other_column']} "
                   f"'{c['other_header']}'. Which is the requirement is a person's call, not the "
                   f"column order's")
    for u in e.get("columns_unresolved") or []:
        out.append(f"{u['tab']}: header names no {', '.join(u['missing'])} column — those fields fall "
                   f"back to a positional guess, which is the defect this resolver exists to remove")
    # The transcription-shape halves that mean text was demonstrably NOT read. A skipped `|` line and
    # a row whose width disagrees with its header are content absent or misread in the extraction, so
    # coverage over them is coverage over a hole. ROW_GAPs stay out: hidden workbook rows are
    # legitimate, and the lint already reports each gap for a person to settle.
    for src in e.get("sources") or []:
        shape = src.get("shape") or {}
        if src.get("tab") not in scanned:
            continue
        for sk in shape.get("skipped_lines") or []:
            out.append(f"{src.get('file')} line {sk.get('line')}: a `|` line the extractor read as "
                       f"neither row, header nor separator — the text is absent from the extraction, "
                       f"so coverage cannot be complete over it: {sk.get('text', '')[:100]}")
        for wm in shape.get("width_mismatches") or []:
            out.append(f"{src.get('file')} row {wm.get('row')}: {wm.get('cells')} cells against a "
                       f"{wm.get('header_cells')}-cell header — fields after the mismatch are "
                       f"misread, so what was captured for this row is not what the sheet says")
    if tabs:
        out.append(f"scanned only {len(tabs)} tab(s) via the TABS override — coverage over part of the "
                   f"specification is not coverage")
    seen = {}
    for r in data.get("rows", []):
        if r.get("domain"):
            seen.setdefault(r["item_id"], 0)
            seen[r["item_id"]] += 1
    dupes = sorted(k for k, v in seen.items() if v > 1)
    if dupes:
        out.append(f"duplicate item_id(s) {dupes[:5]} — two sheets map to one domain with overlapping "
                   f"row numbers, so citations resolve to more than one row")
    highs = [f for f in (lint or []) if f.get("kind") == "WORKBOOK_STRUCTURE"
             and f.get("severity") == "HIGH"]
    for f in highs:
        out.append(f"{f['tab']}: {f['detail'][:150]}")
    return out


# The one behavioural leak every simulated programmer journey shared: requirement rows all became
# decisions, but "plumbing" rows whose own cells said "confirm with epi" / "confirm sources" / "TBD"
# were dispositioned control and closed alone. A confirm cell is a question wherever it sits.
# The marker is person_rules' — the ONE classifier of unsettled language, not a local spelling list.
_CONFIRM_MARKER = person_rules.UNSETTLED_MARKER

# Dispositions that CLAIM the item is settled. `context` is exempt on purpose: a banner row that
# says "confirm all values with epi" is an instruction about other rows, not an open question of
# its own — and `decision_required` is the escape hatch this check points at.
_SETTLED_DISPOSITIONS = ("control", "codelist", "population", "duplicate", "excluded")


def validate_dispositions(product_dir, declared, known_items, cited=None, row_text=None):
    """Errors in the disposition register. A disposition is a governance CLAIM; each one must name the
    evidence for itself, and the item it is about must exist.

    `cited` is contract_citations()' map. A declared disposition for a row a contract record CITES is
    an error, not a tie-break: coverage precedence lets the citing record win as `mapped` before the
    declaration is consulted, so the entry becomes dead text that still reads as an account of the
    row. Two answers to "how is this item handled" is the contradiction this register exists to
    prevent — one of them must go."""
    errors = []
    opens = open_decisions(product_dir)
    for item, entry in sorted(declared.items()):
        if cited:
            label, _, row = item.partition(":")
            recs = cited.get((label, int(row))) if row.isdigit() else None
            if recs:
                errors.append(f"{item}: SHADOWED — contract record(s) {', '.join(recs)} cite this "
                              f"row, so coverage counts it 'mapped' and this declaration is dead "
                              f"text; delete the entry (the record owns the row) or drop the "
                              f"record's citation if the declaration is the truth")
        d = entry.get("disposition", "")
        if d not in DISPOSITION_EVIDENCE:
            errors.append(f"{item}: disposition '{d}' is not one of {sorted(DISPOSITION_EVIDENCE)}")
            continue
        for field in DISPOSITION_EVIDENCE[d]:
            if not entry.get(field):
                errors.append(f"{item}: disposition '{d}' requires `{field}`")
            elif field == "approved_by" and not_a_person(entry.get(field)):
                # The same rule Gate 1 and the decision register enforce. This register accepted
                # `approved_by: RWP` — a function, not a person — while every sibling refused it.
                errors.append(f"{item}: `approved_by`: {not_a_person(entry.get(field))}")
        if known_items and item not in known_items:
            errors.append(f"{item}: no such spec item — the register names a row the extraction "
                          f"does not contain")
        tgt = entry.get("duplicate_of")
        if tgt and known_items and tgt not in known_items:
            errors.append(f"{item}: duplicate_of '{tgt}' is not a spec item")
        did = entry.get("decision_id")
        if did and did not in opens:
            errors.append(f"{item}: decision_id '{did}' is not an OPEN decision — a resolved question "
                          f"no longer justifies leaving the item undispositioned")
        if (d in _SETTLED_DISPOSITIONS and not did and row_text
                and _CONFIRM_MARKER.search(row_text.get(item, ""))):
            marker = _CONFIRM_MARKER.search(row_text[item]).group(0)
            errors.append(f"{item}: dispositioned '{d}' but the spec row itself says {marker!r} — "
                          f"a confirm/TBD cell is a question wherever it sits. Disposition it "
                          f"decision_required (or add the decision_id that answers it); a register "
                          f"entry may not close a question the specification is still asking")
    return errors


def contract_citations(contract_path):
    """Which (tab,row) each contract record cites — so coverage can name the covering record, not just
    assert that something covers it. Returns (cited_map, labels) where cited_map[(tab,row)] = [ids]."""
    cited, labels = {}, set()
    if not os.path.exists(contract_path):
        return cited, labels
    # Through the lint's `records()`, never a second regex over the file. A local ```yaml scan
    # would not see a contract stored as a markdown table: every record would read as uncited and
    # coverage would report 0% while the lint reported 100%.
    for block in records(read(contract_path)):
        vm = re.search(r"(?m)^variable_id:\s*(\S+)", block)
        sm = re.search(r"(?m)^spec_refs:\s*\[([^\]]*)\]", block)
        if not (vm and sm):
            continue
        for tok in sm.group(1).split(","):
            # Through the shared expander. This carried its own copy of SPEC_REF_RE and its own range
            # loop — a second answer to "what does clinical:17-46 span", free to drift from the lint's.
            for label, n in spec_ref_rows(tok):
                labels.add(label)
                cited.setdefault((label, n), []).append(vm.group(1))
    return cited, labels


def _definition_and_notes(row):
    """The spec's Definition and Additional Notes cells, verbatim, by NAME not position.

    The fallback exists only for a tab the extractor could not resolve a header for; it is the old
    length heuristic, which picked the `Label` cell instead of `Definition` on 148 of 200 prostate
    rows. Keep it as a last resort, not a default.
    """
    f = row.get("fields") or {}
    if f:
        return f.get("definition", "").strip(), f.get("notes", "").strip()
    cells = row["cells"]
    definition = next((c for c in cells[1:] if len(c) > 25), "")
    return definition, (cells[-1] if len(cells) > 3 and cells[-1] != definition else "")


# Spec columns with no home among the 21 contract keys: the dictionary label, the declared value set,
# the spec's own time-period token, the codelist group, the section banner. They ARE requirements, so
# dropping them loses information — but each needs judgment to land in a field (`Values` is sometimes a
# type and sometimes an enumeration), so they are carried verbatim ALONGSIDE the record rather than
# guessed into it. See governance/SPEC_DOMAINS.md.
CARRIED_COLUMNS = [("section", "Section"), ("time_period", "Time Period"), ("label", "Label"),
                   ("values", "Values / codes"), ("codelist_group", "Code list group"),
                   ("source", "Source, as the spec states it")]


def carried_columns(row):
    """The spec's own cells a drafter must see beside the record — mapped extras AND the workbook's
    unmapped margin columns (Origin / Evidence / Status and their kin). The margin columns are where
    a spec says "confirm with epi" or "struck through — keep or drop?", and until they rode along
    here they surfaced only in slices: a drafter working from the scaffold alone never saw them."""
    f = row.get("fields") or {}
    out = [(lab, f[k].strip()) for k, lab in CARRIED_COLUMNS
           if f.get(k, "").strip() and f[k].strip().upper() not in ("N/A", "NA")]
    out += [(lab, val) for lab, val in unmapped_columns(row)
            if val.strip() and val.strip().upper() not in ("N/A", "NA")]
    return out


# The fields the SPEC establishes and a drafter passes through. Not judgment: `spec_refs` is the
# citation, `spec_digest` binds the record to the cited text, `required_rule` is the spec's own
# Definition cell. The skill has always said these are machine-owned — and then handed the whole record
# to the model to type, so "do not rewrite the evidence" was a sentence in a prompt rather than a
# property of the tool. `evidence_for` makes it the tool's job.
MACHINE_OWNED = ("spec_refs", "spec_digest", "required_rule")


class NotApprovedForAI(Exception):
    """The pack's sanitized extraction is not approved for AI use, so its text may not be lifted."""


def ai_gate(product_dir):
    """RAISE unless a named person has approved this pack's sanitized extraction for AI use.

    `source_manifest.ai_readable` is the ONE answer to "may AI read this pack", and until now
    `spec_slice` was the only tool that asked it. That left TWO DOORS ONTO ONE DECISION: the slicer
    refused prostate/202606 — `status: pending`, no `approved_by`, no `approval_date` — while

        contract_record.py draft.yaml --product products/oncology/prostate/202606 --item study_period:18

    returned the specification's own sentence, `Earliest available data through INDEX, inclusive.`,
    with its digest. Same artifact, same question, opposite answers; and the second door is the one
    the drafting skill actually uses.

    So the gate moves to where the WORDS are lifted rather than to the CLI that asks for them. This
    file's own comment above `MACHINE_OWNED` records why that placement matters: the rule that a
    drafter passes evidence through was "a sentence in a prompt rather than a property of the tool"
    for three versions. A refusal in `main` would be the same sentence again, one layer out.

    NOT applied to `scaffold()` or `coverage_report()`, deliberately and for different reasons:

      * `coverage_report` emits DISPOSITIONS and hashes — a verdict, which
        `governance/WORKFLOW.md` §"Eligibility" allows across the boundary — never a Definition cell.
      * `scaffold()` runs during `run_spec_pipeline`, which BUILDS the extraction that an
        `ai_extraction` approval is registered against. Gating it would make a pack unbootstrappable:
        no scaffold without an approval, no approval without an artifact to approve. Its output is a
        committed pack artifact under Gate 1, not an on-demand read. That containment is weaker, and
        `products/oncology/oc/202606/spec_pipeline/out/SCAFFOLDED_RECORDS.md` is 3198 lines of exactly
        this text sitting in the checkout — an honest residual, recorded rather than papered over.
    """
    # LAZY, so this module keeps its stdlib-only import surface: `source_manifest` needs PyYAML and
    # this file parses `spec_dispositions.yaml` without it. `contract_record.merge_evidence` imports
    # this module the same way and for the same reason.
    import source_manifest as sm                                                        # noqa: E402
    readable, why_not = sm.ai_readable(product_dir)
    if not readable:
        raise NotApprovedForAI(
            f"{product_dir}: REFUSING to supply spec evidence — the sanitized extraction is not "
            f"approved for AI use:\n"
            + "\n".join(f"  {w}" for w in why_not[:6])
            + (f"\n  ... and {len(why_not) - 6} more" if len(why_not) > 6 else "")
            + f"\n  `required_rule` is the specification's own words, so it is lifted ONLY from a "
              f"derived artifact somebody has signed. Registering and approving it is a HUMAN act "
              f"recorded in {product_dir}/source_refs.yaml — see governance/WORKFLOW.md "
              f"\"Eligibility\". An instruction in the task is not an approval mechanism.\n"
              f"  The block, with the derivation fields already computed:\n"
              f"    python3 platform/tools/source_manifest.py --register-ai-extraction {product_dir}")


def evidence_for(product_dir, item_id, data=None, lint_findings=None, tabs=None):
    """The MACHINE_OWNED fields for ONE spec row, plus the lint flags and carried columns for it.

    Reuses `requirement_rows`, `_definition_and_notes` and `contract_lint.spec_digest` — the same three
    the scaffold uses — rather than re-deriving any of them. A second digest implementation here would
    emit a value the lint recomputes differently, and every record drafted through this path would fail
    I15 for a reason nobody could see.

    Unlike `scaffold()` this does NOT skip a row that the contract already cites or that carries a
    disposition: revising an existing record is exactly when the evidence must be re-supplied unchanged.

    GATED FIRST, before `data` is even consulted, so a caller that pre-loads the extraction and passes
    it in cannot route around the check by having already opened the file.
    """
    ai_gate(product_dir)
    if data is None:
        with open(os.path.join(product_dir, "spec_pipeline", "out", "extracted.json"),
                  encoding="utf-8") as fh:
            data = json.load(fh)
    lint_by_item = {}
    for f in (lint_findings or []):
        lint_by_item.setdefault(f["item_id"], []).append(f"{f['kind']}: {f['detail']}")

    for row in requirement_rows(data, tabs):
        label = row.get("domain") or row["tab"]
        if f"{label}:{row['row']}" != item_id and row["item_id"] != item_id:
            continue
        definition, notes = _definition_and_notes(row)
        return {
            "spec_refs": [f"{label}:{row['row']}"],
            "spec_digest": spec_digest([f"{label}:{row['row']}"],
                                       {label: {row["row"]: row.get("content_hash", "")}}) or NA,
            "required_rule": definition or TODO,
            "_variable": row.get("variable") or "",
            "_notes": notes or "",
            "_lint_flags": lint_by_item.get(row["item_id"], []),
            "_spec_columns": carried_columns(row),
        }
    known = sorted({f"{r.get('domain') or r['tab']}:{r['row']}" for r in requirement_rows(data, tabs)})
    raise KeyError(f"{item_id} is not a requirement row in this pack's extraction. "
                   f"{len(known)} rows exist; the first few are {', '.join(known[:5])}. "
                   f"An item id is `<domain>:<row>` — the canonical DOMAIN, never the workbook tab "
                   f"label, which differs per product.")


def scaffold(data, product_dir, lint_findings=None, tabs=None):
    contract = os.path.join(product_dir, "handoff", "FUNCTIONAL_CONTRACT.md")
    cited, _ = contract_citations(contract)
    lint_by_item = {}
    for f in (lint_findings or []):
        lint_by_item.setdefault(f["item_id"], []).append(f"{f['kind']}: {f['detail']}")

    declared = declared_dispositions(product_dir)
    records, covered, context, accounted, unnamed = [], 0, 0, 0, 0
    for row in requirement_rows(data, tabs):
        # The domain IS the citation label (governance/SPEC_DOMAINS.md). A row without one comes
        # from a sheet absent from the shared map — cite it by sheet label and let the extractor's
        # UNMAPPED warning be the signal.
        label = row.get("domain") or row["tab"]
        if (label, row["row"]) in cited:
            covered += 1
            continue
        # An item with a recorded disposition is already accounted for. Scaffolding it anyway would hand
        # back a "needs judgment" record for a judgment that has been made and written down.
        if f"{label}:{row['row']}" in declared:
            accounted += 1
            continue
        var = row["variable"]
        if is_context(row):
            context += 1
            continue
        if not var:
            # Substantive text, no variable name. There is nothing to name a record after, and guessing
            # one would invent a requirement — so it is counted, reported, and left undispositioned.
            unnamed += 1
            continue
        definition, notes = _definition_and_notes(row)
        # Keyed by item_id — the canonical `<domain>:<row>` the lint itself emits. Rebuilding the key
        # from tab+row produced `5B. ClinChars:89`, which never matched `clinical:89`, so no scaffold
        # record ever carried a lint warning and every COVERAGE lint cell was blank.
        flags = lint_by_item.get(row["item_id"], [])
        records.append({
            "variable_id": re.sub(r"[^A-Za-z0-9_]", "_", var.split("<br>")[0].strip())[:40].upper(),
            "spec_refs": [f"{label}:{row['row']}"],
            # Bound to the row's CONTENT, not just its number, so a later in-place edit to the rule
            # cannot slip past the record written from it (I15). Computed by the LINT's function, not
            # a second implementation of the same idea — a scaffold that hashed it its own way would
            # emit a digest the lint recomputes differently, and every fresh record would fail I15.
            "spec_digest": spec_digest([f"{label}:{row['row']}"],
                                       {label: {row["row"]: row.get("content_hash", "")}}) or NA,
            "required_rule": definition or TODO,
            "source": TODO, "grain": TODO, "anchor": TODO, "window": TODO,
            "record_selection": TODO, "tie_break": TODO, "derivation": TODO,
            "cohort_applicability": TODO, "missing": TODO, "units": TODO, "depends_on": TODO,
            "output": TODO, "publish": TODO, "acceptance": TODO,
            "status": {"requirement": "draft", "source": "unverified",
                       "implementation": "not_implemented", "validation": "not_run"},
            "decision_ids": [], "gap_ids": [],
            "notes": notes or "",
            "lint_flags": flags,
            "spec_columns": carried_columns(row),
        })
    return {"scaffold": {
        # Copied from the extraction, not recomputed — see spec_extract.extraction_fingerprint.
        "fingerprint": (data.get("extraction") or {}).get("fingerprint", ""),
        "product": repo_relative(product_dir), "spec_rows": data["extraction"]["row_count"],
        "already_covered": covered, "dispositioned": accounted, "context_rows": context,
        "unnamed_rows": unnamed, "scaffolded": len(records)}, "records": records}


# The canonical key order from FUNCTIONAL_CONTRACT.md section B. Order is not cosmetic: the contract is
# read side by side across records, so a stable order is what makes a diff legible.
# Derived, not restated. This was a hand-maintained copy of contract_lint.CANON with `variable_id`
# prepended — identical to it today, which is precisely when a duplicate is invisible. The field set
# and its order now have one home: the module whose invariants check them.
CANON_ORDER = list(TABLE_COLUMNS[:-1])          # everything but the trailing implementation_refs

# JUDGMENT FIELDS — everything a DRAFTER answers, which is CANON_ORDER minus what the machine owns.
#
# `contract_record.py` refuses a draft carrying any of these, and rightly: `spec_refs`, `spec_digest`
# and `required_rule` come from the extraction, and `status` is an evidence transition an accountable
# person makes in the governed file. But the scaffold EMITS all four, so the generated starting point
# had to be hand-stripped before the tool that consumes it would accept it — once per record, by every
# analyst, on every pack. Two artifacts that are each individually right and cannot be used together.
JUDGMENT_FIELDS = tuple(k for k in CANON_ORDER
                        if k not in MACHINE_OWNED and k not in ("variable_id", "status"))

# Inline dicts, because the CI lint parses these three positionally on one line; a multi-line version
# parses as absent and the record silently fails I6.
INLINE_DEFAULTS = {
    "status": "{requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}",
    "output": "{physical_name: TODO, target_published_name: TODO, name_status: undecided, "
              "type: TODO, nullable: TODO, codes: n/a, role: TODO}",
    "publish": "{ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}",
}


def judgment_stub(variable_id):
    """The starting point a DRAFTER edits — and the exact shape `contract_record --item` accepts.

    ONE default policy. The rule "every judgment field starts at TODO, the list fields at [], and the
    three inline dicts at their parsed-positionally form" was written twice already: once building the
    scaffold record and once again per cell in `to_contract_records`. A third copy in a new
    serialization is how those two would have started disagreeing about what an unanswered field looks
    like — and an unanswered field that renders differently in two places is exactly the thing I15 and
    I17 exist to notice.

    It omits the four fields `contract_record` refuses (`MACHINE_OWNED` + `status`). That omission IS
    the fix: the tool fills those in from the extraction, so a stub that carried them was a file the
    consuming tool would not take without an edit nobody should have to make.

    Returned as text rather than a dict, because it is meant to be saved and edited. `variable_id`
    leads, as it does in the contract.
    """
    lines = [f"variable_id: {variable_id}"]
    for key in JUDGMENT_FIELDS:
        if key in INLINE_DEFAULTS:
            lines.append(f"{key}: {INLINE_DEFAULTS[key]}")
        elif key in ("decision_ids", "gap_ids"):
            lines.append(f"{key}: []")
        else:
            lines.append(f"{key}: {TODO}")
    # implementation_refs LAST, and outside the loop, because it is outside CANON_ORDER —
    # `CANON_ORDER = TABLE_COLUMNS[:-1]` drops it, and the drafter still has to answer it. `[none]`
    # rather than `[]` or TODO: I19 refuses both, because nothing-implements-this-yet is an ANSWER
    # and this field must not let an answer and an unanswered question look alike.
    lines.append("implementation_refs: [none]")
    return "\n".join(lines) + "\n"


def _scalar(v):
    """Render a value for the contract. Quote anything a YAML parser would misread."""
    if isinstance(v, list):
        return "[" + ", ".join(str(x) for x in v) + "]"
    s = str(v).replace("\n", " ").strip()
    if not s:
        return TODO            # an empty value fails the lint's presence check (I6)
    if s.startswith("{") or s.startswith("["):
        return s
    if any(c in s for c in ':#"') or s != s.strip():
        return '"' + s.replace('"', "'") + '"'
    return s


def to_contract_records(records):
    """Emit scaffolded records as rows of the canonical record TABLE, ready to paste.

    This is the pipeline's hand-off format, and it must be the format the contract actually stores.
    It emitted fenced ```yaml blocks after the contract moved to a markdown table, so the scaffold
    produced the one shape `contract_lint.records()` treats as legacy — and worse, a fenced block
    pasted UNDER a table is not read at all, because the table wins. `mixed_format_error` reports
    that rather than losing it silently, but a hand-off format whose output the lint objects to is
    friction the pipeline exists to remove.

    Two parts, deliberately separated:

      * the TABLE — one row per record, paste-ready into `handoff/FUNCTIONAL_CONTRACT.md`
      * the ROW NOTES below it — duplicate-name warnings, the deterministic lint's findings, and the
        spec row's other columns verbatim

    The notes are scaffold GUIDANCE, not contract content: they tell the drafter what to look at and
    have no place in a governed file. Interleaving them with the records, as the fenced form did,
    invited them to be pasted in along with the record.
    """
    out, seen, notes = [], {}, []
    for r in records:
        vid = r["variable_id"]
        seen[vid] = seen.get(vid, 0) + 1
        dup_note = ""
        if seen[vid] > 1:
            # I1 requires a unique variable_id. The spec repeating a name across rows is normal; the
            # judgment (distinct variables, or the same one stated twice) belongs to a person, so
            # suffix it and make the choice explicit rather than silently colliding.
            r = dict(r, variable_id=f"{vid}__{seen[vid]}")
            dup_note = (f"\n> DUPLICATE NAME: the spec uses `{vid}` on more than one row. Suffixed to keep "
                        f"variable_id unique (lint I1). Decide whether these are genuinely distinct "
                        f"variables needing distinct names, or the same variable stated twice — in "
                        f"which case one row is a `duplicate` disposition, not a second citation on "
                        f"one record (lint I16).\n")
        cells = []
        for k in TABLE_COLUMNS:
            if k == "implementation_refs":
                # Nothing implements a scaffold yet. `[none]` is what contract_binding expects on a
                # not_implemented record; TODO here would fail it the moment the record is pasted.
                cells.append(pipe(_scalar(r.get(k, "[none]"))))
            elif k in INLINE_DEFAULTS and (k not in r or r[k] == TODO):
                cells.append(pipe(INLINE_DEFAULTS[k]))
            elif k == "status" and isinstance(r.get(k), dict):
                s = r[k]
                cells.append(pipe("{requirement: %s, source: %s, implementation: %s, validation: %s}"
                                  % (s.get("requirement", "draft"), s.get("source", "unverified"),
                                     s.get("implementation", "not_implemented"),
                                     s.get("validation", "not_run"))))
            else:
                cells.append(pipe(_scalar(r.get(k, TODO))))
        out.append("| " + " | ".join(cells) + " |")

        flags = r.get("lint_flags") or []
        cols = r.get("spec_columns") or []
        if dup_note or flags or cols:
            body = [f"#### {r['variable_id']}"]
            if dup_note:
                body.append(dup_note.strip())
            if cols:
                body.append("> Also on this spec row, verbatim — decide where each belongs:\n"
                            + "\n".join(f">   - {lab}: {val}" for lab, val in cols))
            if flags:
                body.append("> Deterministic lint flagged this row:\n"
                            + "\n".join(f">   - {x}" for x in flags))
            notes.append("\n".join(body))

    header = ("| " + " | ".join(TABLE_COLUMNS) + " |\n"
              + "|" + "|".join("---" for _ in TABLE_COLUMNS) + "|")
    table = "\n".join([header] + out) if out else ""
    if not notes:
        return table
    return (table + "\n\n## Row notes — SCAFFOLD GUIDANCE, do not paste into the contract\n\n"
            + "\n\n".join(notes) + "\n")


def coverage_report(data, product_dir, lint_findings=None, tabs=None):
    """Every extracted spec item with its disposition. This is the Gate 2 completeness evidence: it makes
    silent omission visible, which is the one failure review cannot catch (there is nothing to review)."""
    contract = os.path.join(product_dir, "handoff", "FUNCTIONAL_CONTRACT.md")
    cited, _ = contract_citations(contract)
    flagged = {f["item_id"] for f in (lint_findings or [])}
    declared = declared_dispositions(product_dir)

    rows, counts = [], {}
    for row in requirement_rows(data, tabs):
        # The domain IS the citation label (governance/SPEC_DOMAINS.md). A row without one comes
        # from a sheet absent from the shared map — cite it by sheet label and let the extractor's
        # UNMAPPED warning be the signal.
        label = row.get("domain") or row["tab"]
        item = f"{label}:{row['row']}"
        recs = cited.get((label, row["row"]), [])
        var = row["variable"]
        handled = ""
        if recs:
            disp = "mapped"
        elif item in declared:
            disp = declared[item].get("disposition", "declared")
            handled = declared[item].get("handled_by", "")
        elif is_context(row):
            disp = "context"
        else:
            disp = "UNDISPOSITIONED"
        counts[disp] = counts.get(disp, 0) + 1
        rows.append({"item": item, "tab": label, "row": row["row"], "variable": var[:34],
                     "disposition": disp, "records": recs, "handled_by": handled,
                     "hash": row["content_hash"],
                     "flags": "yes" if row["item_id"] in flagged else ""})
    return rows, counts


def write_coverage_md(rows, counts, data, product_dir, path):
    tot = len(rows)
    src = data["extraction"]["sources"]
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("# Spec coverage — every specification item and its disposition\n\n")
        fh.write("GENERATED by `platform/tools/contract_scaffold.py --coverage`. Do not hand-edit; regenerate.\n\n")
        fh.write("This is the Gate 2 completeness evidence (`governance/WORKFLOW.md` section 8). Every extracted\n"
                 "spec item resolves to exactly one disposition. `UNDISPOSITIONED` is the only failing state —\n"
                 "`decision_required` items are *intentionally* unresolved and still count as accounted for.\n\n")
        fh.write(f"**{tot} items** — " + " · ".join(f"{k} {v}" for k, v in sorted(counts.items())) + "\n\n")
        fh.write("| source | rows | sha256 |\n|---|---|---|\n")
        for s in src:
            fh.write(f"| `{s['file']}` | {s['rows']} | `{s['sha256']}` |\n")
        fh.write("\n## Items\n\n| spec item | variable | disposition | covered by | lint | content hash |\n")
        fh.write("|---|---|---|---|---|---|\n")
        for r in rows:
            by = ", ".join(f"`{x}`" for x in r["records"]) or (r.get("handled_by") or "—")
            mark = "**UNDISPOSITIONED**" if r["disposition"] == "UNDISPOSITIONED" else r["disposition"]
            fh.write(f"| `{r['item']}` | {r['variable']} | {mark} | {by[:88]} | {r['flags']} | `{r['hash']}` |\n")


def main(argv):
    ap = argparse.ArgumentParser(description="Scaffold contract records from an extracted spec.")
    ap.add_argument("extracted")
    ap.add_argument("--product", required=True, help="product dir, e.g. products/oncology/prostate/202606")
    ap.add_argument("--lint", help="optional spec_lint.py --format json output, folded into lint_flags")
    ap.add_argument("--out")
    ap.add_argument("--summary", action="store_true", help="print coverage only")
    ap.add_argument("--records", metavar="FILE",
                    help="write scaffolded records as rows of the canonical contract TABLE — the "
                         "form the contract stores and the lint reads. (This said `fenced yaml "
                         "blocks`, which is the legacy form the reader ignores when a table exists.)")
    ap.add_argument("--coverage", metavar="FILE", help="write the full coverage report (markdown) here")
    ap.add_argument("--strict", action="store_true",
                    help="Gate 2: exit non-zero when any item is UNDISPOSITIONED. Reporting a number "
                         "and exiting 0 makes coverage an observation, not a control.")
    ap.add_argument("--tabs", help="OVERRIDE the tabs to cover; normally omitted — the default is every "
                                   "sheet mapped in governance/spec_sheet_map.yaml")
    a = ap.parse_args(argv)

    with open(a.extracted, encoding="utf-8") as fh:
        data = json.load(fh)
    lint = None
    if a.lint:
        with open(a.lint, encoding="utf-8") as fh:
            payload = json.load(fh)
        # spec_lint emits {findings, applicability}; a bare list is the older shape.
        lint = payload["findings"] if isinstance(payload, dict) else payload

    tabs = a.tabs.split(",") if a.tabs else None
    unclassified = data["extraction"].get("unclassified_tabs") or []
    out = scaffold(data, a.product, lint, tabs)
    s = out["scaffold"]
    print(f"spec rows            {s['spec_rows']:>5}")
    print(f"  already in contract{s['already_covered']:>5}")
    print(f"  dispositioned      {s['dispositioned']:>5}   <- recorded in handoff/spec_dispositions.yaml")
    print(f"  context/banner     {s['context_rows']:>5}")
    if s["unnamed_rows"]:
        print(f"  UNNAMED            {s['unnamed_rows']:>5}   <- substantive text, no variable name; "
              f"classify by hand")
    print(f"  SCAFFOLDED         {s['scaffolded']:>5}   <- records needing judgment")
    if a.records:
        with open(a.records, "w", encoding="utf-8") as fh:
            fh.write("# Scaffolded contract records — GENERATED, needs judgment\n\n"
                     "Every judgment field is `TODO`. These are NOT contract records until a person "
                     "fills them in and an accountable owner approves; paste into "
                     "`handoff/FUNCTIONAL_CONTRACT.md` only after that.\n\n"
                     "Rows of the canonical record TABLE — the format the contract stores and the "
                     "lint reads.\n\n"
                     "**Do not assemble a row by hand.** `contract_record.py` renders it: the escaping, "
                     "the column order and the three single-line inline dicts are its job, and a row "
                     "typed by hand is the one place a `|` or a line break silently changes what the "
                     "record says. Take a starting point from the drafting slice — which prints the "
                     "judgment fields ALONE, because this file's records carry `spec_refs`, "
                     "`spec_digest`, `required_rule` and `status`, and the renderer refuses all four "
                     "as coming from the extraction rather than from a drafter:\n\n"
                     "```\n"
                     "python3 platform/tools/spec_slice.py <pack> --domain <domain> --item <domain>:<row>\n"
                     "python3 platform/tools/contract_record.py <file> --product <pack> --item <domain>:<row>\n"
                     "```\n\n"
                     "The rows below are for READING — what the record will look like, and which "
                     "fields are still `TODO`.\n\n"
                     "**Row notes below the table are scaffold guidance — do not paste them.**\n\n"
                     "**Filling these in needs no AI.** Every key is already here and every rule is "
                     "enforced by plain Python, so a person can complete these by hand and prove it "
                     "— by hand means answering the fields, not typing the table row:\n\n"
                     "| what | where |\n|---|---|\n"
                     "| every invariant it currently defines, and the error messages | "
                     "`platform/tools/contract_lint.py` |\n"
                     "| what each `status` axis means and who may set it | "
                     "`governance/WORKFLOW.md` section 7 |\n"
                     "| what each field is answering, with a worked example | "
                     "`.claude/skills/draft-contract-record/SKILL.md` — readable as plain markdown, "
                     "whether or not you invoke it as a skill |\n\n"
                     "The skill only speeds up the drafting. It is not in the path of the pipeline, "
                     "the lint, or any gate.\n\n---\n\n")
            fh.write(to_contract_records(out["records"]))
        print(f"\ncontract-ready records -> {a.records}  ({len(out['records'])} record(s))")

    declared = declared_dispositions(a.product)
    known = {r["item_id"] for r in data["rows"] if r.get("domain")}
    cited_rows, _ = contract_citations(os.path.join(a.product, "handoff", "FUNCTIONAL_CONTRACT.md"))
    row_text = {r["item_id"]: r.get("text") or " ".join(str(c) for c in r.get("cells") or [])
                for r in data["rows"] if r.get("item_id")}
    dis_errors = validate_dispositions(a.product, declared, known, cited=cited_rows,
                                       row_text=row_text)
    if dis_errors:
        print(f"\n{len(dis_errors)} disposition register error(s):")
        for e in dis_errors:
            print(f"   {e}")

    if a.coverage:
        rows, counts = coverage_report(data, a.product, lint, tabs)
        write_coverage_md(rows, counts, data, a.product, a.coverage)
        bad = counts.get("UNDISPOSITIONED", 0)
        print(f"\ncoverage report -> {a.coverage}")
        print("   " + " · ".join(f"{k} {v}" for k, v in sorted(counts.items())))
        if bad:
            print(f"   {bad} item(s) UNDISPOSITIONED — every spec item must be mapped, classified or excluded")
            if a.strict:
                return 1

    # Disposition-register integrity fails the ROUTINE run, not only --strict: a shadowed entry
    # (double-accounting a row a record cites) or an unattested excluded/waived disposition could
    # ride invisibly for the whole drafting phase when only release runs used --strict (red-team
    # N6). Coverage COMPLETENESS stays strict-only — incompleteness is a state, double-accounting
    # is a defect.
    if dis_errors:
        return 1
    if a.strict and unclassified:
        print(f"\nSTRICT: {len(unclassified)} unclassified sheet(s) — {', '.join(unclassified)}. Coverage "
              f"cannot be complete over sheets that were never scanned.")
        return 1
    if a.strict:
        integrity = extraction_integrity(data, lint, tabs)
        if integrity:
            print(f"\nSTRICT: {len(integrity)} extraction-integrity failure(s) — coverage counts items "
                  f"the extractor may not have read correctly:")
            for e in integrity:
                print(f"   {e}")
            return 1

    if not a.summary:
        text = json.dumps(out, indent=1)
        if a.out:
            with open(a.out, "w", encoding="utf-8") as fh:
                fh.write(text)
            print(f"\nwrote {a.out}")
        else:
            sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
