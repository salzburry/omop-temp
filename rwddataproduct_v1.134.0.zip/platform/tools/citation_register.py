#!/usr/bin/env python3
"""Every citation the reference shelf uses, how it was checked, and what it is NOT bound to.

    python3 platform/tools/citation_register.py            # validate + write CITATIONS.md
    python3 platform/tools/citation_register.py --check     # validate + byte-compare, exit 1 on drift

WHY THIS EXISTS. `INVENTORY.yaml` hangs a LIST of citation strings off each of its 509 variables,
and how those citations were checked lived in README prose plus per-tumour `caveats`. Two of those
caveats read "a few citations carry journal/volume/page identity without a PMID or DOI" — true, and
useless, because they never said which. A reader weighing the shelf could not separate a citation
resolved against PubMed from one harvested off a search-results page, and the ones with the weakest
provenance were the hardest to find.

`CITATIONS.yaml` gives each citation ONE record carrying its identifier, the route by which it was
checked and the pass that checked it. This tool holds the two files together:

  * every citation string used in the inventory has exactly one record, and every record is used —
    an unregistered citation and an orphan record are both drift;
  * the recorded identifier actually occurs in the citation text, so a record cannot claim a PMID
    the string does not carry;
  * `route`, `pass` and `identifier.kind` come from the declared vocabularies;
  * a citation with no resolvable identifier MUST carry `identifier_route_unavailable`, and one
    that carries that route must have no PMID or DOI — the two halves cannot disagree;
  * the per-tumour caveats and the records agree about which citations are weak: a tumour whose
    caveat names a citation must actually use it, and every citation the records mark
    unconfirmed must be named in the caveat of some tumour that uses it;
  * records naming one identifier agree about how that work was checked, so a reader landing on
    either spelling gets the same answer about the same paper.

IDENTIFIERS ARE NOT PAPERS, AND THE RENDERING SAYS SO. Normalising case and trailing punctuation
takes 281 records to 246 identifiers, which is a real correction — a reader taking 281 for the
breadth of the evidence reads a number 14% too large. It is not the end of the correction. A paper
cited once by PMID and once by DOI is two identifiers whose strings share no characters, and the
only way to know they are one work is to resolve one and read back the other. So 246 is an UPPER
BOUND, `same_work:` records that lookup as the human act it is, and CITATIONS.md prints both the
ceiling and how many equivalences have actually been established — today, none.

WHAT IT REPORTS RATHER THAN FIXES. `supports:` binds a citation to the CLAIM it supports rather than
to the variable that happens to list it. It is empty on every record, and CITATIONS.md says so with
the count. An AI must not fill it in: deciding which paper supports which clause IS the judgement the
binding exists to record, and inventing it would make the shelf look better-evidenced while
destroying the one signal that says otherwise. The same goes for `common_sources:` — which databases
carry a concept — which no citation covers on any of the 509 variables.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
REPO = TOOLS.parent.parent
PLATFORM = TOOLS.parent
INV_DIR = REPO / "governance" / "reference" / "variable_inventory"
REGISTER = INV_DIR / "CITATIONS.yaml"
INVENTORY = INV_DIR / "INVENTORY.yaml"
RENDER = INV_DIR / "CITATIONS.md"

KINDS = ("pmid", "doi", "arxiv", "pmcid", "journal_locator", "in_house")

# The register block declaring that two identifiers in DIFFERENT schemes name one paper. See
# `work_merges` for why it is declared and not computed, and `same_work_errors` for what it must
# carry to be believed.
SAME_WORK = "same_work"

# WHERE A SHELF ENTRY'S CONTENT CAME FROM — a different axis from where its CITATIONS came from.
#
# A route grades a citation: was this paper's identity resolved. A BASIS grades the ENTRY: is this
# definition a reading of published literature, a concept the house has drafted against, or a
# statement the approved workbook actually makes. Every entry on this shelf is one of the first two,
# and the shelf is `reference_only` for exactly that reason. Nothing said which, per entry.
#
# THE PROMOTION IS A HUMAN ACT AND AN AI MUST NEVER PERFORM IT. `workbook_confirmed` asserts that a
# named person read the approved workbook and found it says this. That is the same class of claim as
# a Gate 1 classification or a Gate 4 approval: a value nobody typed is a value nobody made. The
# fields below are what make the claim checkable, and their absence is what keeps a generated entry
# out of the tier.
BASIS = ("literature_inferred", "in_house_drafting", "workbook_confirmed")
BASIS_MEANING = {
    "literature_inferred": "read off published RWD methodology and tumour literature. What studies "
                           "of this tumour typically define — never what any workbook states",
    "in_house_drafting": "stated on a live pack's COMMITTED drafting surfaces (spec-pipeline output "
                         "and hand-typed contract records). Provisional discovery metadata: what "
                         "the house has drafted against, not what anyone signed",
    "workbook_confirmed": "a NAMED person read the approved workbook and recorded that it states "
                          "this. The only basis that carries any authority, and the only one an AI "
                          "may not write",
}
# Routes weakest-last; the rendering orders its sections by this tuple, so a new route added to the
# vocabulary lands in the report in the position its author chose rather than alphabetically.
ROUTE_ORDER = ("pubmed_or_publisher", "web_search_result", "identifier_route_unavailable",
               "in_house_drafting_surface")
IDENTIFIED = re.compile(r"PMID\s*:?\s*\d{6,9}|DOI\s*:?\s*10\.\d{4,}/|\b10\.\d{4,}/|arXiv:|PMC\d+")


def _load(path: Path):
    """Through `strict_yaml`, which owns both the duplicate-key refusal AND the utf-8 read."""
    sys.path.insert(0, str(PLATFORM))
    from engine.strict_yaml import strict_load_path                     # noqa: PLC0415
    return strict_load_path(path)


def uses(inv=None) -> dict:
    """{citation text -> {tumour slugs that cite it}}. `_master` for the cross-tumour core."""
    inv = inv if inv is not None else _load(INVENTORY)
    out = {}
    for slug, t in (inv.get("tumours") or {}).items():
        for v in t.get("variables") or []:
            for c in v.get("citations") or []:
                out.setdefault(c, set()).add(slug)
    for m in inv.get("master") or []:
        for c in m.get("citations") or []:
            out.setdefault(c, set()).add("_master")
    return out


def _ident(rec_or_ident) -> tuple:
    """(kind, value) for a record or a bare identifier mapping, normalised.

    A DOI is case-insensitive by specification and a PMID is a number; trailing punctuation is
    typing. Anything that survives that is a genuinely different identifier.
    """
    ident = rec_or_ident.get("identifier") if "identifier" in rec_or_ident else rec_or_ident
    ident = ident or {}
    return (str(ident.get("kind") or ""),
            str(ident.get("value") or "").strip().rstrip(".,;").lower())


def work_merges(reg) -> dict:
    """{identifier: canonical identifier} from the register's DECLARED `same_work:` equivalences.

    THE LIMIT OF NORMALISATION, AND WHY THE MERGE IS DECLARED RATHER THAN COMPUTED. Spelling is
    mechanical: `PMID 29756355` and `PMID: 29756355` are the same string once punctuation and case
    are stripped, and no judgment is involved. Two DIFFERENT identifier SCHEMES naming one paper is
    not mechanical at all — `10.1111/1475-6773.13011` and `29756355` share no characters, and the
    only way to know they are one work is to resolve one of them and read what comes back. That is a
    lookup against an external service, and nothing in this repository may assert its result
    unattributed.

    So the equivalence is a RECORDED HUMAN ACT: a `same_work:` group naming the identifiers, who
    established it, when, and how. `same_work_errors` holds every part of that to the same rules an
    approval is held to. The block is empty today, which is the true state, and `render_md` says so
    rather than printing a work count that quietly assumes no such duplicate exists.

    Union-find, so a group of three merges to one canonical identifier however it is written, and
    two groups sharing an identifier become one work rather than disagreeing about which is
    canonical.
    """
    parent = {}

    def find(x):
        parent.setdefault(x, x)
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for group in (reg.get(SAME_WORK) or []):
        idents = [_ident(i) for i in (group or {}).get("identifiers") or [] if isinstance(i, dict)]
        idents = [i for i in idents if i[1]]
        for other in idents[1:]:
            a, b = find(idents[0]), find(other)
            if a != b:
                # The SMALLER key wins, so the canonical identifier does not depend on the order
                # groups happen to be written in — two registers with the same content must
                # canonicalise the same way or their work counts disagree.
                parent[max(a, b)] = min(a, b)
    return {k: find(k) for k in parent}


def work_key(rec, merges=None) -> tuple:
    """The WORK a citation record points at — its identifier, merged through `same_work:`.

    "281 distinct citations" counted STRINGS, and the strings are not distinct works: 17 identifiers
    appear under more than one spelling, so 281 records cover 246 identifiers. `Curtis MD et al.
    2018, Health Serv Res, PMID 29756355` and `Curtis 2018, Health Serv Res, PMID: 29756355` are one
    paper written five ways. A reader taking 281 for the breadth of the evidence is reading a number
    14% too large, and a claim binding keyed on the string would bind twice to one work.

    246 is an UPPER BOUND on the works, not the works. Normalising spelling cannot merge a paper
    cited once by PMID and once by DOI — see `work_merges` — so pass `merges` wherever the number
    is going to be read as evidence breadth.
    """
    key = _ident(rec)
    return (merges or {}).get(key, key)


def basis_of(variable) -> str:
    """The basis of one shelf entry — its own `provenance.basis` when it carries one, else derived.

    DERIVED BY DEFAULT so that 509 entries do not need 509 hand-typed blocks to answer a question
    their citations already answer: an `in-house:` citation means the concept came off a pack's
    drafting surfaces, anything else means it came off the literature. A `provenance:` block is
    therefore only ever written to record the PROMOTION, which is the one transition a person has to
    make by hand.
    """
    prov = variable.get("provenance")
    if isinstance(prov, dict) and prov.get("basis"):
        return str(prov["basis"])
    cits = variable.get("citations") or []
    if cits and all(str(c).startswith("in-house:") for c in cits):
        return "in_house_drafting"
    return "literature_inferred"


def _claim_digest(entry) -> str:
    """sha256 over WHAT a shelf entry claims, in the repository's one canonical form.

    `workbook_confirmed` says "a named person read the approved workbook and it states THIS". The
    workbook half was pinned by `workbook_sha256` and the THIS half by nothing: the definition
    could be rewritten after the confirmation and the confirmation survived the change it was
    about. Digesting the entry's own content is what makes it revocable — the same rule
    `attested_against_sha256` applies to a stand-in one layer up.

    `protocol_record._canonical`, not a second normaliser: reflowing a sentence must not read as a
    changed claim, and re-deciding that here is how two answers to one question start.
    """
    import hashlib
    import json as _json
    import sys as _sys
    _sys.path.insert(0, str(TOOLS))
    from protocol_record import _canonical                          # noqa: PLC0415
    payload = {k: _canonical(entry.get(k)) for k in ("name", "definition_sketch", "coverage")}
    blob = _json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def provenance_errors(inv, root=REPO) -> list:
    """[why a `provenance:` block may not be believed], or [].

    Only `workbook_confirmed` is checked hard, because it is the only basis that CLAIMS anything.
    The other two are derivable from the citations and carry no authority, so a block stating one is
    a label, not an assertion.
    """
    out = []
    for slug, t in sorted((inv.get("tumours") or {}).items()):
        for v in t.get("variables") or []:
            name = f"{slug}.{v.get('name', '?')}"
            prov = v.get("provenance")
            if prov is None:
                continue
            if not isinstance(prov, dict):
                out.append(f"{name}: provenance must be a mapping")
                continue
            basis = str(prov.get("basis") or "")
            if basis not in BASIS:
                out.append(f"{name}: provenance.basis {basis or '(unstated)'!r} not in {list(BASIS)}")
                continue
            if basis != "workbook_confirmed":
                continue
            sys.path.insert(0, str(TOOLS))
            import product_gates as pg                                  # noqa: PLC0415
            import source_manifest as sm                                # noqa: PLC0415
            why = pg.not_a_person(prov.get("confirmed_by"))
            if pg.unstated(prov.get("confirmed_by")) or why:
                out.append(f"{name}: workbook_confirmed with confirmed_by "
                           f"{prov.get('confirmed_by')!r} — {why or 'unstated'}. This tier says a "
                           f"PERSON read the workbook; a value nobody typed is a claim nobody made")
            bad = pg.bad_date(prov.get("confirmed_date"))
            if bad:
                out.append(f"{name}: workbook_confirmed and confirmed_date {bad}")
            ref = str(prov.get("workbook") or "")
            pack, _, mid = ref.partition("#")
            if not pack or not mid:
                out.append(f"{name}: workbook {ref!r} must be `<pack path>#<material_id>` — the "
                           f"confirmation is against a REGISTERED source or it is against a memory")
                continue
            # A GOVERNED PACK, not any directory that happens to exist. `is_dir()` accepted a
            # `source_refs.yaml` sitting anywhere in the tree — including one outside the set Gate 1
            # walks — so a confirmation could cite a registration no gate would ever inspect.
            if pack not in set(pg.products(str(root))):
                out.append(f"{name}: workbook names pack {pack!r}, which is not a governed product "
                           f"pack. A confirmation cites a registration Gate 1 walks, or it cites a "
                           f"file nobody checks")
                continue
            found = {str(m.get("material_id")): m for m in (sm.materials(str(root / pack)) or [])}
            if mid not in found:
                out.append(f"{name}: {pack} registers no material {mid!r} — Gate 1 has to know the "
                           f"document before a shelf entry can claim it says something")
                continue

            # REGISTERED IS NOT REVIEWED, and the first version of this check confused them. It
            # asked only that the id resolve to SOME material, and prostate's `program_spec` is
            # `status: pending`, `sha256: null`, `path_or_link: "TBD — the approved 202606 workbook"`.
            # So the one promotion that says "a person read the approved workbook and it states
            # this" could be recorded against a workbook nobody has, which is worse than having no
            # tier at all: it launders an absence into the strongest claim on the shelf.
            mat = found[mid]
            if str(mat.get("material_type") or "") != sm.PROGRAM_SPEC:
                out.append(f"{name}: {mid!r} is material_type "
                           f"{mat.get('material_type')!r}, not {sm.PROGRAM_SPEC} — an extraction or "
                           f"a supplemental file is not the approved specification")
            if str(mat.get("status") or "") != sm.REVIEWED:
                out.append(f"{name}: {pack}#{mid} is `status: "
                           f"{mat.get('status') or 'unstated'}`, not `{sm.REVIEWED}`. A confirmation "
                           f"against an unreviewed workbook asserts what nobody has approved — this "
                           f"is Gate 1's job and the shelf may not route around it")
            src_sha = str(mat.get("sha256") or "")
            if pg.unstated(src_sha):
                out.append(f"{name}: {pack}#{mid} records no sha256, so the confirmation names a "
                           f"document whose BYTES nobody can identify")
            # ...and the confirmation names the bytes it was made against, so re-issuing the
            # workbook revokes it exactly as a changed extraction revokes a Gate 1 signature.
            claimed = str(prov.get("workbook_sha256") or "")
            if pg.unstated(claimed):
                out.append(f"{name}: workbook_confirmed with no workbook_sha256 — a confirmation "
                           f"that does not name the bytes it read survives the document being "
                           f"replaced, which is the whole reason digests exist here")
            elif src_sha and claimed != src_sha:
                out.append(f"{name}: confirmed against workbook_sha256 {claimed[:12]}… and "
                           f"{pack}#{mid} now records {src_sha[:12]}… — the workbook moved under "
                           f"the confirmation. Re-read it, or restore what was confirmed.")
            # ...AND THOSE BYTES ARE THE BYTES ON DISK. Every comparison above is string-to-string:
            # the digest in `source_refs.yaml` against the digest in `INVENTORY.yaml`. Both are
            # typed. A pack could declare `sha256: bbbb…` for a file that hashes to anything at
            # all, repeat the same string in the provenance block, and this check passed — the
            # strongest tier on the shelf resting on two copies of one unverified claim. Gate 1
            # already hashes the file; this delegates to it rather than adding a second
            # implementation of "these bytes are those bytes" that could drift from it.
            # BY INDEX, because that is how Gate 1 names a material. Filtering on the material_id
            # matched nothing — the errors read `source_materials[0]` — so the first version of
            # this check silently passed everything, including the mismatch it was written to
            # catch. A filter that never matches is a check that never runs.
            _mats = sm.materials(str(root / pack)) or []
            _i = next((i for i, m in enumerate(_mats)
                       if str(m.get("material_id")) == mid), None)
            _tag = f"source_materials[{_i}]"
            gate1 = [e for e in sm.check(str(root), pack) if _tag in e]
            if gate1:
                out.append(f"{name}: {pack}#{mid} does not pass Gate 1, so its digest is a claim "
                           f"nobody verified: {gate1[0]}")
            # ...and the confirmation is bound to THIS entry's content. Without it the tier says "a
            # person read the workbook and it states THIS" with no THIS: the definition could be
            # rewritten afterwards and the confirmation would survive the change it was about.
            live = _claim_digest(v)
            bound = str(prov.get("confirmed_claim_sha256") or "")
            if pg.unstated(bound):
                out.append(f"{name}: workbook_confirmed with no `confirmed_claim_sha256` — the "
                           f"confirmation names the workbook but not WHAT was confirmed, so the "
                           f"definition can change underneath it and the claim survives. Record "
                           f"{live[:12]}… for this entry as it stands.")
            elif bound != live:
                out.append(f"{name}: confirmed_claim_sha256 {bound[:12]}… but this entry now "
                           f"digests to {live[:12]}… — the definition moved after it was "
                           f"confirmed. Re-read the workbook, or restore what was confirmed.")
            if pg.unstated(prov.get("locator")):
                out.append(f"{name}: workbook_confirmed with no `locator` — WHERE in the workbook "
                           f"it says this (sheet and row) is what makes the claim checkable by "
                           f"somebody other than its author")
    return out


# A claim binding is an EDGE, not a flag: which claim, where in the work, and saying what. The field
# was checked only for being a list, so a human filling it in had no shape to fill and no way to
# record that a work CONTRADICTS a claim — which is the most valuable thing a binding can say.
SUPPORT_RELATIONS = ("supports", "contradicts", "context")


def _support_errors(edge, where) -> list:
    """[why this claim binding cannot be believed]. Empty until a person writes one — the shape has
    to exist BEFORE anybody starts, or the first ten will be written three different ways."""
    out = []
    if not isinstance(edge, dict):
        return [f"{where}: a binding is a mapping {{claim, locator, relation, reviewed_by, "
                f"reviewed_date}} — a bare string cannot say WHERE in the work, or saying what"]
    if not str(edge.get("claim") or "").strip():
        out.append(f"{where}: no `claim` — which sentence of the entry this work bears on")
    if not str(edge.get("locator") or "").strip():
        out.append(f"{where}: no `locator` — where IN the work (section, table, page). Without it "
                   f"the binding is as uncheckable as the variable-level list it replaces")
    rel = str(edge.get("relation") or "")
    if rel not in SUPPORT_RELATIONS:
        out.append(f"{where}: relation {rel or '(unstated)'!r} not in {list(SUPPORT_RELATIONS)} — "
                   f"a work that CONTRADICTS a claim is the most valuable binding there is, and an "
                   f"unstated relation silently reads as support")
    sys.path.insert(0, str(TOOLS))
    import product_gates as pg                                          # noqa: PLC0415
    why = pg.not_a_person(edge.get("reviewed_by"))
    if pg.unstated(edge.get("reviewed_by")) or why:
        out.append(f"{where}: reviewed_by — {why or 'unstated'}. A binding is one person's reading")
    bad = pg.bad_date(edge.get("reviewed_date"))
    if bad:
        out.append(f"{where}: reviewed_date {bad}")
    return out


def same_work_errors(reg, registered) -> list:
    """[why a declared work equivalence cannot be believed]. `registered` is every identifier the
    register actually holds.

    HELD TO WHAT AN APPROVAL IS HELD TO, because it does the same kind of work: it merges two
    records into one work, which changes the count a reader takes for the breadth of the evidence
    and would let one claim binding stand for two. `established_by` is a named person and
    `established_date` a usable date, for the same reason `reviewed_by` is on a claim binding — the
    equivalence is one person's lookup, and an unattributed one is a guess with a citation's clothes
    on.
    """
    sys.path.insert(0, str(TOOLS))
    import product_gates as pg                                          # noqa: PLC0415
    out = []
    groups = reg.get(SAME_WORK)
    if groups is None:
        return [f"CITATIONS.yaml has no `{SAME_WORK}:` block — write `{SAME_WORK}: []` rather than "
                f"omitting it. An absent block and an empty one read the same to a parser and not "
                f"to a person: only the second says nobody has found a cross-scheme duplicate."]
    if not isinstance(groups, list):
        return [f"`{SAME_WORK}:` must be a list of equivalence groups"]
    seen = {}
    for i, g in enumerate(groups):
        where = f"{SAME_WORK}[{i}]"
        if not isinstance(g, dict):
            out.append(f"{where}: not a mapping")
            continue
        idents = [_ident(x) for x in (g.get("identifiers") or []) if isinstance(x, dict)]
        idents = [x for x in idents if x[1]]
        if len(set(idents)) < 2:
            out.append(f"{where}: names {len(set(idents))} identifier(s) — an equivalence needs two "
                       f"or more, or it merges nothing and only looks like evidence")
        if len({k for k, _v in idents}) < 2:
            out.append(f"{where}: every identifier is a {sorted({k for k, _ in idents})} — two "
                       f"spellings of ONE scheme are already merged by normalisation. This block is "
                       f"for a paper cited under DIFFERENT schemes, which normalisation cannot see")
        for ident in idents:
            if ident not in registered:
                out.append(f"{where}: {ident[0]}:{ident[1]} is not in this register — an "
                           f"equivalence to a work nothing cites merges nothing and cannot be "
                           f"checked against anything")
            if ident in seen and seen[ident] != i:
                out.append(f"{where}: {ident[0]}:{ident[1]} is also in {SAME_WORK}[{seen[ident]}]. "
                           f"They are unioned into one work, which is almost certainly what was "
                           f"meant — write it as one group so the register says so")
            seen.setdefault(ident, i)
        why = pg.not_a_person(g.get("established_by"))
        if pg.unstated(g.get("established_by")) or why:
            out.append(f"{where}: established_by — {why or 'unstated'}. Resolving two identifiers "
                       f"to one paper is a lookup somebody performed; an unattributed one is a "
                       f"guess")
        bad = pg.bad_date(g.get("established_date"))
        if bad:
            out.append(f"{where}: established_date {bad}")
        if not str(g.get("how") or "").strip():
            out.append(f"{where}: no `how` — which identifier was resolved, against what, and what "
                       f"came back. Without it the next reader cannot repeat the check")
    return out


def register_errors(reg, inv) -> list:
    out = []
    if reg.get("status") != "reference_only":
        out.append("CITATIONS.yaml must say status: reference_only — a citation register that reads "
                   "as approved evidence is the overstatement it exists to prevent")
    routes = set(reg.get("routes") or {})
    passes = set(reg.get("passes") or {})
    if routes != set(ROUTE_ORDER):
        out.append(f"declared routes {sorted(routes)} != {sorted(ROUTE_ORDER)}")

    used = uses(inv)
    records = reg.get("citations") or []
    by_text = {}
    for rec in records:
        text = rec.get("text")
        if not isinstance(text, str) or not text.strip():
            out.append("a citation record has no text")
            continue
        if text in by_text:
            out.append(f"{text!r}: two records for one citation")
        by_text[text] = rec

        ident = rec.get("identifier") or {}
        kind, value = ident.get("kind"), str(ident.get("value") or "")
        if kind not in KINDS:
            out.append(f"{text!r}: identifier.kind {kind!r} not in {list(KINDS)}")
        if not value or value not in text:
            out.append(f"{text!r}: recorded identifier {value!r} does not occur in the citation — a "
                       f"record cannot claim an identifier the string does not carry")
        route = rec.get("route")
        if route not in routes:
            out.append(f"{text!r}: route {route!r} not in the declared vocabulary")
        if rec.get("pass") not in passes:
            out.append(f"{text!r}: pass {rec.get('pass')!r} not in the declared vocabulary")
        if not isinstance(rec.get("author_list_confirmed"), bool):
            out.append(f"{text!r}: author_list_confirmed must be a boolean")

        # The two halves of "no identifier could be resolved" must agree, or the register can say a
        # citation was resolved against PubMed while carrying no identifier to resolve.
        resolvable = bool(IDENTIFIED.search(text))
        if route == "identifier_route_unavailable" and resolvable:
            out.append(f"{text!r}: marked identifier_route_unavailable but carries a PMID/DOI")
        if not resolvable and route not in ("identifier_route_unavailable", "in_house_drafting_surface"):
            out.append(f"{text!r}: no PMID or DOI in the text, so the route must be "
                       f"identifier_route_unavailable, not {route!r}")

        sup = rec.get("supports")
        if not isinstance(sup, list):
            out.append(f"{text!r}: supports must be a list (empty until a HUMAN binds the claim)")
        for i, edge in enumerate(sup or []):
            out += _support_errors(edge, f"{text!r} supports[{i}]")

    out += same_work_errors(reg, {_ident(r) for r in by_text.values() if _ident(r)[1]})

    # ONE WORK, ONE SET OF FACTS. Two records for one identifier may not disagree about how that
    # work was checked — a reader landing on either spelling would get a different answer about the
    # same paper, and whichever they hit first would look authoritative. Grouped through the
    # DECLARED equivalences too: a paper cited by PMID in one record and by DOI in another is one
    # work the moment somebody establishes that, and its two records must then agree as well.
    merges = work_merges(reg)
    by_work = {}
    for text, rec in sorted(by_text.items()):
        key = work_key(rec, merges)
        if not key[1]:
            continue
        by_work.setdefault(key, []).append((text, rec))
    for key, group in sorted(by_work.items()):
        if len(group) < 2:
            continue
        facts = {(r.get("route"), r.get("pass"), r.get("author_list_confirmed"))
                 for _, r in group}
        if len(facts) > 1:
            out.append(f"{key[0]}:{key[1]} is recorded {len(group)} times with DIFFERENT "
                       f"verification facts ({sorted(facts)}) — one work cannot have been checked "
                       f"two ways. Spellings: " + "; ".join(t for t, _ in group))

    missing = sorted(set(used) - set(by_text))
    for t in missing:
        out.append(f"{t!r}: used in INVENTORY.yaml with no record in CITATIONS.yaml")
    for t in sorted(set(by_text) - set(used)):
        out.append(f"{t!r}: registered and cited by nothing — an orphan record")

    # --- the caveats and the records tell the same story -----------------------------------------
    caveat_text = {slug: " ".join(t.get("caveats") or [])
                   for slug, t in (inv.get("tumours") or {}).items()}
    for text, rec in sorted(by_text.items()):
        weak = []
        if rec.get("author_list_confirmed") is False:
            weak.append("an unconfirmed author list")
        if rec.get("route") == "identifier_route_unavailable":
            weak.append("no resolvable identifier")
        if not weak:
            continue
        ident = str((rec.get("identifier") or {}).get("value") or "")
        tumours = used.get(text, set())
        if not any(ident and ident in caveat_text.get(s, "") for s in tumours):
            out.append(f"{text!r}: recorded with {' and '.join(weak)}, and no tumour that cites it "
                       f"names it in `caveats` — the exception must be visible where the variables "
                       f"are READ, not only in the register. A caveat that says \"a few\" does not "
                       f"name it")
    return out


def render_md(reg, inv) -> str:
    used = uses(inv)
    records = {r["text"]: r for r in reg.get("citations") or []}
    by_route = {}
    for text, rec in records.items():
        by_route.setdefault(rec["route"], []).append(text)

    merges = work_merges(reg)
    idents = {_ident(r) for r in records.values() if _ident(r)[1]}
    n_works = len({work_key(r, merges) for r in records.values() if _ident(r)[1]})
    n_vars = sum(len(t.get("variables") or []) for t in (inv.get("tumours") or {}).values())
    n_uses = sum(len(v.get("citations") or [])
                 for t in (inv.get("tumours") or {}).values() for v in t.get("variables") or [])
    bound = sum(1 for r in records.values() if r.get("supports"))

    lines = [
        "# Citations on the reference shelf — how each one was checked",
        "",
        "**GENERATED from `CITATIONS.yaml` by `platform/tools/citation_register.py` — edit the",
        "register, then regenerate. `--check` refuses a stale copy.**",
        "",
        f"{len(records)} citation RECORDS covering **{n_works} distinct identifiers**, cited "
        f"{n_uses} times across {n_vars} variables.",
        "",
        (f"The two numbers differ because {len(records) - n_works} records are a second spelling of "
         f"a work already registered — `Curtis MD et al. 2018, … PMID 29756355` and `Curtis 2018, "
         f"… PMID: 29756355` are one paper. **Read {n_works}, not {len(records)}, as the breadth of "
         f"the evidence**; the record count is a count of strings. Records sharing one identifier "
         f"must agree about how that work was checked, and the register refuses them if they do "
         f"not." if len(records) != n_works else
         "Every record is a distinct identifier — none is registered under two spellings."),
        "",
        # THE UPPER BOUND, SAID OUT LOUD. Normalisation merges spellings of ONE identifier; it
        # cannot see that a PMID and a DOI name one paper, because the two strings share no
        # characters and only a lookup can tell. Printing the identifier count as a WORK count
        # would hand a reader a de-duplicated-looking number that is still an upper bound — the
        # same over-reading, one level down, that replacing 281 with 246 was meant to stop.
        (f"**Identifiers, not works: {n_works} is an upper bound on the papers.** They span "
         f"{', '.join(sorted({k for k, _ in idents}))}, and a paper cited once by PMID and once by "
         f"DOI is two of them — the strings share no characters, so nothing mechanical can merge "
         f"them. `same_work:` records that equivalence when a person resolves one identifier and "
         f"reads back the other; **{len(reg.get(SAME_WORK) or [])} such groups are recorded**, so "
         f"the paper count is {n_works} or fewer and nobody has checked which."),
        "",
        "**No human has verified any of these.** `route` records how an AUTOMATED pass checked the",
        "citation; nothing here is an approval, and nothing here is evidence that a cited paper says",
        "what the entry using it says. What it gives a reader is the ability to weigh a citation",
        "before relying on it — the weakest routes are listed in full below, by name, which is what",
        "the per-tumour caveats could not do when they said \"a few\".",
        "",
        "| route | citations | what it means |",
        "|---|---|---|",
    ]
    for route in ROUTE_ORDER:
        lines.append(f"| `{route}` | {len(by_route.get(route, []))} | "
                     f"{(reg.get('routes') or {}).get(route, '').strip()} |")

    lines += [
        "",
        "## The claim binding is empty, and that is the finding",
        "",
        f"`supports:` binds a citation to the CLAIM it supports rather than to the variable that",
        f"lists it — an EDGE carrying `{{claim, locator, relation, reviewed_by, reviewed_date}}`,",
        f"where `relation` is one of {', '.join('`' + r + '`' for r in SUPPORT_RELATIONS)} so that a",
        f"work CONTRADICTING a claim can be recorded, which is the most valuable binding there is.",
        f"**{bound} of {len(records)} records carry one.** Until a person fills them in, a",
        "citation list on a variable means only \"these works are relevant to this entry\" — not that",
        "any particular sentence in the entry is sourced to any particular one of them.",
        "",
        "An AI must not fill this in. Choosing which paper supports which clause IS the judgement the",
        "binding exists to record; inventing it would make the shelf look better-evidenced than it is",
        "while destroying the one signal that says otherwise.",
        "",
        "**`common_sources:` on every variable carries no citation at all** — which databases carry a",
        f"concept is stated on all {n_vars} variables and supported by none of the {n_uses} citation",
        "uses.",
        "",
    ]

    for route in ROUTE_ORDER:
        texts = sorted(by_route.get(route, []))
        if route == "pubmed_or_publisher" or not texts:
            continue                       # the strongest route is a count, not a wall of text
        lines += [f"## `{route}` — {len(texts)} citation(s)", "",
                  (reg.get("routes") or {}).get(route, "").strip(), ""]
        for t in texts:
            who = ", ".join(sorted(s for s in used.get(t, set())))
            lines.append(f"- {t} — cited by {who}")
        lines.append("")

    weak = sorted(t for t, r in records.items() if r.get("author_list_confirmed") is False)
    lines += ["## Recorded without a confirmed author list", "",
              "The harvesting pass surfaced title, journal and identifier only. The work is",
              "identified; who wrote it was not confirmed.", ""]
    for t in weak:
        lines.append(f"- {t} — cited by {', '.join(sorted(used.get(t, set())))}")

    # --- basis -----------------------------------------------------------------------------------
    basis_counts = {}
    for slug, t in sorted((inv.get("tumours") or {}).items()):
        for v in t.get("variables") or []:
            b = basis_of(v)
            basis_counts.setdefault(slug, {}).setdefault(b, 0)
            basis_counts[slug][b] += 1
    totals = {b: sum(c.get(b, 0) for c in basis_counts.values()) for b in BASIS}
    lines += ["## What each entry IS — basis, not citation route", "",
              "A route grades a CITATION: was this paper's identity resolved. A basis grades the",
              "ENTRY: is this definition a reading of the literature, a concept the house has",
              "drafted against, or a statement the approved workbook actually makes.", ""]
    for b in BASIS:
        lines.append(f"- **`{b}`** — {totals.get(b, 0)} entries. {BASIS_MEANING[b]}")
    lines += ["",
              f"**{totals.get('workbook_confirmed', 0)} of "
              f"{sum(totals.values())} entries are `workbook_confirmed`.** The promotion is a human "
              "act: a named person, a date, and a workbook registered at Gate 1 as "
              "`<pack>#<material_id>`. `citation_register.py` refuses the claim without all three, "
              "and an AI must never write it — the whole content of the tier is that a person read "
              "the document.", ""]

    lines += ["", "## Per tumour", "",
              "How many of each tumour's citation uses run through each route. A tumour reading high",
              "in a weak column is not wrong — it is a tumour whose shelf entries deserve more",
              "scrutiny before a workbook is drafted against them.", "",
              "| tumour | variables | citation uses | " +
              " | ".join(f"`{r}`" for r in ROUTE_ORDER) + " |",
              "|---|---|---|" + "---|" * len(ROUTE_ORDER)]
    for slug in sorted((inv.get("tumours") or {})):
        vs = (inv["tumours"][slug].get("variables") or [])
        counts = {r: 0 for r in ROUTE_ORDER}
        total = 0
        for v in vs:
            for c in v.get("citations") or []:
                total += 1
                rec = records.get(c)
                if rec:
                    counts[rec["route"]] += 1
        lines.append(f"| {slug} | {len(vs)} | {total} | " +
                     " | ".join(str(counts[r]) for r in ROUTE_ORDER) + " |")
    return "\n".join(lines).rstrip() + "\n"


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true",
                    help="validate and byte-compare CITATIONS.md; exit 1 on any problem or drift")
    a = ap.parse_args(argv)
    reg, inv = _load(REGISTER), _load(INVENTORY)
    errors = register_errors(reg, inv) + provenance_errors(inv)
    if errors:
        for e in errors:
            print(f"  FAIL {e}")
        return 1
    want = render_md(reg, inv)
    if a.check:
        have = RENDER.read_text(encoding="utf-8") if RENDER.exists() else None
        if have != want:
            print("DRIFT — CITATIONS.md is stale; regenerate with: "
                  "python3 platform/tools/citation_register.py")
            return 1
        print(f"current — {len(reg['citations'])} citations registered and CITATIONS.md matches")
        return 0
    RENDER.write_text(want, encoding="utf-8")
    print(f"OK — {len(reg['citations'])} citations registered; wrote {RENDER}")
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
