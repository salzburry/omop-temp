#!/usr/bin/env python3
"""How big is the query plan this pack builds, and how does it grow per cohort?

    python3 platform/tools/plan_size.py <pack>              # the whole pack
    python3 platform/tools/plan_size.py <pack> --scale      # 1, 2, 4, … cohorts, to show the growth
    python3 platform/tools/plan_size.py <pack> --json

WHY THIS EXISTS. A review proposed rebuilding the per-cohort treatment work as one reusable
patient-line dimension, on the reasoning that `build_ads` repeats LOT work per cohort and is
therefore the build hotspot. Before restructuring the core of the engine, the reasoning was
measured — and it did not survive contact.

    lot.normalized is called 40 times in a 7-cohort prostate build, for 3 DISTINCT frames.
    Memoising it to those 3: plan UNCHANGED at 54,377 nodes.

A Spark logical plan is a TREE, not a DAG. Handing the same DataFrame object to two parents embeds
the whole subtree twice regardless, so de-duplicating in Python de-duplicates nothing in the plan.
The 40 calls are real and worth removing on their own terms, but they are not where the size is.

WHERE THE SIZE ACTUALLY IS, measured on prostate:

    cohorts   plan nodes   per cohort
       1          2,954       2,954
       2          5,910       2,955
       4         25,226       6,306
       7         54,377       7,768

Each cohort embeds a COMPLETE copy of the stage pipeline and the copies are then unioned, so the
plan is O(cohorts × pipeline). Line cohorts (L2+, L3+, L4+) cost about 2.5× an overall cohort
because they carry more treatment and outcome work. Nothing about LOT reuse changes that shape;
only building the cohorts as ONE frame — a spine keyed by (patientid, index_date, cohort_id), with
the stages applied once across it — would.

WHY A 22MB PLAN MATTERS EVEN THOUGH IT IS "JUST" A PLAN. Adaptive execution renders the physical
plan to a string on every plan update to post it to the SQL listener. On a local driver that is
where the JVM died — `OutOfMemoryError` inside `StringConcat.toString`, not in any operator. On a
cluster it is driver memory and compile time rather than a crash, but it is the same cost.

THIS TOOL DOES NOT PROPOSE THE REDESIGN. It gives whoever takes it on the before-number, on their
own pack, so "we made the build cheaper" is a measurement rather than a belief. Re-run it after.

Cluster or a local PySpark; writes nothing.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
PLATFORM = os.path.dirname(TOOLS)
REPO = os.path.dirname(PLATFORM)
sys.path.insert(0, PLATFORM)
sys.path.insert(0, TOOLS)

# A plan cap would truncate the very thing being measured. Raised for the measurement only, on the
# session this tool is given, and never written to a pack's configuration.
UNCAPPED = "200000000"


def plan_nodes(ads, spark=None):
    """(characters, nodes) of the ANALYZED plan.

    The analyzed plan rather than the physical one: it is the shape the author controls, it does
    not move with adaptive re-planning, and it is what grows when a stage is duplicated per cohort.
    """
    if spark is not None:
        spark.conf.set("spark.sql.maxPlanStringLength", UNCAPPED)
    text = ads._jdf.queryExecution().analyzed().treeString()
    return len(text), text.count("\n")


def measure(pack, cohort_counts=None, session=None, root=REPO):
    """[{cohorts, chars, nodes, per_cohort}] — one row per cohort count measured."""
    from engine.config import load_config
    from engine import build_ads
    sys.path.insert(0, os.path.join(PLATFORM, "tests", "fixtures"))
    import synthetic_sources

    spark = session or synthetic_sources.session("plan-size")
    spark.conf.set("spark.sql.maxPlanStringLength", UNCAPPED)

    # THE EXACT PACK SUPPLIED, not registry-current-by-slug: resolving the slug through
    # product_config measured whichever spec version the products tree surfaces — with
    # prostate/202603 and /202606 both on disk, the caller could name one and measure the
    # other, and nothing would say so.
    cfg0 = load_config(os.path.join(root, pack, "config", "data_product.yaml"),
                       overrides={"run.refresh": "v", "run.source_schema": "s",
                                  "run.output_schema": "o"})
    every = list(cfg0.cohorts)
    counts = cohort_counts or [len(every)]

    out = []
    for n in counts:
        if n > len(every):
            continue
        cfg = load_config(os.path.join(root, pack, "config", "data_product.yaml"),
                          overrides={"run.refresh": "v", "run.source_schema": "s",
                                     "run.output_schema": "o"})
        cfg.cohorts = every[:n]
        ads = build_ads.build_from_sources(synthetic_sources.sources(spark, cfg), cfg)
        chars, nodes = plan_nodes(ads, spark)
        out.append({"cohorts": n, "chars": chars, "nodes": nodes,
                    "per_cohort": round(nodes / n) if n else None})
    return out


def render(pack, rows):
    L = [f"# Query plan size — {pack}", "",
         "The ANALYZED plan, on synthetic sources. Shape, not data volume: this is what the author",
         "controls, and what grows when a stage is duplicated per cohort.", "",
         "| cohorts | plan nodes | characters | nodes per cohort |", "|---:|---:|---:|---:|"]
    for r in rows:
        L.append(f"| {r['cohorts']} | {r['nodes']:,} | {r['chars']:,} | {r['per_cohort']:,} |")
    if len(rows) > 1:
        first, last = rows[0], rows[-1]
        growth = (last["per_cohort"] / first["per_cohort"]) if first["per_cohort"] else 0
        L += ["", f"Per-cohort cost grew {growth:.1f}x between {first['cohorts']} and "
                  f"{last['cohorts']} cohorts. Superlinear growth means later cohorts are not "
                  f"copies of the first — on prostate the line cohorts (L2+, L3+, L4+) carry more "
                  f"treatment and outcome work than the overall ones."]
    L += ["", "A plan this size is not free: adaptive execution renders the physical plan to a",
          "string on every update, which is where a local driver runs out of heap and where a",
          "cluster spends driver memory and compile time.", "",
          "**De-duplicating `lot.normalized` does NOT reduce this** — measured, on prostate: 40",
          "calls collapse to 3 distinct frames and the plan is unchanged at 54,377 nodes. A Spark",
          "plan is a tree, so handing one DataFrame to two parents embeds the subtree twice.",
          "Only building the cohorts as ONE frame changes the shape."]
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("product", help="path to a product pack")
    ap.add_argument("--scale", action="store_true",
                    help="measure at 1, 2, 4, … cohorts to show how the plan grows")
    ap.add_argument("--json", action="store_true", help="machine-readable, to STDOUT")
    a = ap.parse_args(argv)

    pack = os.path.relpath(os.path.abspath(a.product), REPO)
    if not os.path.isdir(os.path.join(REPO, pack)):
        sys.exit(f"{a.product}: not a product pack directory")
    counts = [1, 2, 4, 7] if a.scale else None
    rows = measure(pack, counts)
    print(json.dumps({"product": pack, "measurements": rows}, indent=2) if a.json
          else render(pack, rows))
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
