#!/usr/bin/env python3
"""One rule, three ways: the specification's words, the interpretation, and the YAML that runs.

    python3 platform/tools/rule_review.py <pack>                    # every rule
    python3 platform/tools/rule_review.py <pack> --variable MCRPCDD # one

WHY THIS EXISTS. Approving a configuration currently means reading YAML. That asks the person who
owns the CLINICAL question — is this the rule RWB asked for — to answer it in the notation of the
people who own the EXECUTION. The predictable result is that the approval becomes a formality: the
reviewer cannot check what they are signing, so they sign that somebody else checked it.

The three sides already exist and were never put next to each other:

  the spec's words   `required_rule`, lifted verbatim from the cited row and machine-owned, so the
                     column here cannot be a paraphrase somebody tidied
  the interpretation the judgment fields — population, source, anchor, window, selection, tie-break,
                     missing, output — which is exactly what a reviewer needs, in the contract's
                     field names rather than a reviewer's vocabulary
  what runs          the config blocks `implementation_refs` names, resolved to their actual YAML

DERIVES NOTHING, and that is the whole discipline. Every value is read from the record or from the
config; this module supplies ORDER and LABELS. A rendering that computed anything would be a second
answer to what the rule is, sitting next to the record in a document designed to be trusted — and it
would be the one with the friendlier wording.

WHAT IT CANNOT SHOW, IT SAYS. A record whose `implementation_refs` are `[none]` has no executable
side yet; a ref that resolves to no block is reported as unresolved. Neither is drawn as blank,
because a blank column in a review document reads as "nothing to check here".

stdlib only (plus PyYAML, through the tools it calls).
"""
import argparse
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import contract_binding                                                     # noqa: E402
import contract_lint as cl                                                  # noqa: E402
import product_gates as pg                                                  # noqa: E402
from spec_extract import repo_relative                                      # noqa: E402

# THE REVIEWER'S QUESTIONS, in the order they are asked, against the contract field that answers each.
# The left column is a person's wording and the right is the schema's; keeping both is the point, so
# that a reviewer reads a question and an author can still see which field to fix.
#
# `derivation` is deliberately NOT in this list — it is the rule itself and is shown as the headline
# rather than as one attribute among eight. `units` and `depends_on` are absent for the opposite
# reason: they matter to the build and not to the clinical question this view exists to settle.
REVIEW_ORDER = (
    ("Applicable population", "cohort_applicability"),
    ("Source table and field", "source"),
    ("Anchor date", "anchor"),
    ("Window", "window"),
    ("Which records qualify", "record_selection"),
    ("Precedence and tie-breaking", "tie_break"),
    ("Missing / no-record behaviour", "missing"),
    ("Resulting output", "output"),
)

# The ninth question — "what are the categories, and what code does each get" — has no contract field
# because the contract deliberately does not carry value lists: `derivation` NAMES the rule and the
# YAML CARRIES the values, so the fifty states live in one place. It is therefore read from the
# config block instead, and is the one row of this view that comes from the executable side.
VALUE_SET_KEYS = ("bands", "codes", "codelist", "groups", "categories", "values", "mapping")


def _field(block, name):
    """A record field as text, whichever notation it is written in. Empty string when absent."""
    return ((cl._scalar(block, name) or cl._inline(block, name) or "")).strip()


def _value_sets(fragment):
    """[(key, fragment)] for the parts of a config block that DEFINE CATEGORIES, or [].

    A reviewer asking "which Gleason scores map to which band" is asking about `bands`; the rest of
    the block — column names, output aliases — answers a different question and burying the one in
    the other is what makes a config review feel like reading code.
    """
    out = []
    if isinstance(fragment, dict):
        for key in VALUE_SET_KEYS:
            if key in fragment:
                out.append((key, fragment[key]))
        for value in fragment.values():          # one level down: `columns: [{as: x, bands: [...]}]`
            if isinstance(value, list):
                for item in value:
                    if isinstance(item, dict):
                        for key in VALUE_SET_KEYS:
                            if key in item:
                                out.append((f"{item.get('as') or item.get('column') or key}.{key}",
                                            item[key]))
    return out


def chain(pack, variable=None):
    """[{variable_id, spec, interpreted, executable, unresolved}] — one entry per contract record.

    `governed_blocks` is CALLED, not reimplemented: it already resolves `<file>#/<key>` against the
    pack's active config graph and is what the binder checks with, so this view cannot come to a
    different opinion about which YAML a record runs as.
    """
    contract = os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(contract):
        return []
    blocks = contract_binding.governed_blocks(pack, pg.pack_yaml(pack))

    out = []
    for block in cl.records(cl.read(contract)):
        vid = (cl._scalar(block, "variable_id") or "").strip()
        if not vid or (variable and vid != variable):
            continue
        refs = [r for r in (cl._list(block, "implementation_refs") or []) if r and r != "none"]
        executable, unresolved = [], []
        for ref in refs:
            if "#/" not in ref:
                executable.append((ref, None))       # `engine:symbol` — named, not a YAML block
            elif ref in blocks:
                executable.append((ref, blocks[ref]))
            else:
                unresolved.append(ref)
        out.append({
            "variable_id": vid,
            "spec": {"refs": cl._list(block, "spec_refs") or [],
                     "rule": _field(block, "required_rule"),
                     "digest": _field(block, "spec_digest")},
            "derivation": _field(block, "derivation"),
            "interpreted": [(label, _field(block, field)) for label, field in REVIEW_ORDER],
            "executable": executable,
            "unresolved": unresolved,
            "status": _field(block, "status"),
            "decisions": cl._list(block, "decision_ids") or [],
        })
    return out


def value_sets(entry):
    """[(where, key, fragment)] — the category definitions across this rule's config blocks."""
    out = []
    for ref, fragment in entry["executable"]:
        for key, sub in _value_sets(fragment):
            out.append((ref, key, sub))
    return out


# CONFIG KEYS THAT SHARE A NAME WITH A CONTRACT FIELD. This is where a side-by-side view is most
# dangerous, and the danger is specific rather than theoretical: prostate's ECOG record states
# `tie_break: {equidistant: prior, same_day: worst_grade}` and the block it names states
# `tie_break: earliest_date`. Those are different statements. Printed in adjacent columns they read
# as a match, because a reader scanning two columns for the same word finds it in both.
#
# So the overlap is CALLED OUT rather than left to be noticed. This asserts nothing about whether the
# two agree — comparing them is a judgement about what the rule means, which is the reviewer's whole
# job and precisely what this view must not do on their behalf.
COMPARABLE = ("tie_break", "window", "record_selection", "missing")


def overlaps(entry, record=None):
    """[(field, what the record says, where, what the config says)] where both state the same key.

    Matched on the CONTRACT FIELD NAME, which `REVIEW_ORDER` already pairs with its reviewer label —
    so the pairing is the one this module already publishes rather than a second guess made by
    substring. A config key counts when it is the field, or the field with a suffix: `window_days`
    is the block's statement of `window`.
    """
    by_field = {field: value for (_label, field), (_l2, value)
                in zip(REVIEW_ORDER, entry["interpreted"])}
    out = []
    for ref, fragment in entry["executable"]:
        if not isinstance(fragment, dict):
            continue
        for field in COMPARABLE:
            for key in fragment:
                if key == field or key.startswith(field + "_"):
                    out.append((field, by_field.get(field, ""), f"{ref} -> {key}", fragment[key]))
    return out


def _yaml_lines(fragment, cap, indent, full=False):
    """`fragment` as indented YAML lines, with a VISIBLE marker when the tail was withheld.

    The caps were silent. This report is what a reviewer reads to decide whether the YAML matches
    the rule, and a value list that stopped at twelve lines looked exactly like a value list that
    HAS twelve lines — so a fifty-code enumeration was approved on its first dozen entries, with
    nothing on screen to suggest there was more. The marker names the count and the flag, matching
    the wording `demo.py` already uses for the same problem.
    """
    import yaml
    lines = yaml.safe_dump(fragment, sort_keys=False, allow_unicode=True).splitlines()
    if full or len(lines) <= cap:
        return [f"{indent}{line}" for line in lines]
    return ([f"{indent}{line}" for line in lines[:cap]]
            + [f"{indent}… {len(lines) - cap} more line(s) NOT SHOWN — re-run with --full"])


def render(pack, entries, full=False):
    """The chain as plain text. Markdown-free: this is read in a terminal, and the page is elsewhere."""
    W = 96
    L = [f"REVIEW CHAIN — {repo_relative(os.path.abspath(pack), ROOT)}",
         "the specification's words, what they were read to mean, and the YAML that runs", ""]
    for e in entries:
        L.append("=" * W)
        L.append(f"  {e['variable_id']}    {e['status']}")
        L.append("=" * W)
        L.append(f"  THE SPECIFICATION SAYS   {', '.join(e['spec']['refs']) or 'no cited row'}")
        for line in _wrap(e["spec"]["rule"] or "(the record carries no rule text)", W - 6):
            L.append(f"      {line}")
        if e["decisions"]:
            L.append(f"      blocked on: {', '.join(e['decisions'])}")
        L.append("")
        L.append("  IT WAS READ TO MEAN")
        for line in _wrap(e["derivation"] or "(no derivation stated)", W - 6):
            L.append(f"      {line}")
        L.append("")
        for label, value in e["interpreted"]:
            shown = value or "—"
            first, *rest = _wrap(shown, W - 34) or ["—"]
            L.append(f"      {label:<30} {first}")
            for line in rest:
                L.append(f"      {'':<30} {line}")
        L.append("")
        L.append("  WHAT RUNS")
        if not e["executable"] and not e["unresolved"]:
            # ABSENT, NOT EMPTY. A rule nothing implements yet is a normal and honest state; drawing
            # it as a blank column would read as "checked, nothing to see".
            L.append("      nothing implements this rule yet (implementation_refs: [none])")
        for ref, fragment in e["executable"]:
            if fragment is None:
                L.append(f"      {ref}   — an engine symbol, not a config block")
                continue
            L.append(f"      {ref}")
            L += _yaml_lines(fragment, 14, "          ", full)
        for ref in e["unresolved"]:
            L.append(f"      {ref}   — NAMED BY THE RECORD AND NOT FOUND in the active config graph")
        both = overlaps(e)
        if both:
            L.append("")
            L.append("  THE RECORD AND THE CONFIG BOTH STATE THESE — COMPARE THEM YOURSELF")
            L.append("      Nothing here checks that they agree. On this pack there is at least one")
            L.append("      rule where they do not, and adjacent columns are exactly how that is missed.")
            for field, said, where, runs in both:
                L.append(f"      {field}")
                L.append(f"          the record  {said or '—'}")
                L.append(f"          {where}")
                L += _yaml_lines(runs, 6, "              ", full)
        sets = value_sets(e)
        if sets:
            L.append("")
            L.append("  CATEGORIES AND CODES")
            for ref, key, sub in sets:
                L.append(f"      {key}  ({ref})")
                L += _yaml_lines(sub, 12, "          ", full)
        L.append("")
    return "\n".join(L)


def _wrap(text, width):
    words, line, out = str(text).split(), "", []
    for w in words:
        if len(line) + len(w) + 1 > width and line:
            out.append(line)
            line = w
        else:
            line = f"{line} {w}".strip()
    if line:
        out.append(line)
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("product")
    ap.add_argument("--variable", help="one variable_id, rather than every rule in the contract")
    ap.add_argument("--full", action="store_true",
                    help="show every line of each YAML fragment. Without it the long ones are "
                         "capped and the cut is marked; a capped value list is not one a reviewer "
                         "has seen in full")
    a = ap.parse_args(argv)
    if not os.path.isdir(a.product):
        raise SystemExit(f"not a pack: {a.product}")
    entries = chain(a.product, a.variable)
    if not entries:
        raise SystemExit(f"{a.product}: no contract record"
                         + (f" for {a.variable}" if a.variable else " — nothing to review"))
    print(render(a.product, entries, a.full))
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
