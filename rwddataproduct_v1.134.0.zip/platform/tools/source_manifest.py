#!/usr/bin/env python3
"""Gate 1: is this pack's specification APPROVED, and does the file still match the approval?

`governance/WORKFLOW.md` describes a Gate 1 approval record — filename, revision, checksum, approver,
approval date. `source_refs.yaml` already names each pack's source materials, so the approval record
belongs ON the material it is about; a second file would state the same document in different words and
then go stale. A material at `status: reviewed` carries the approval fields; `pending` /
`reference_only` need only say what the material is and why it is not approved.

Before this, the workflow described an approval gate and nothing enforced one, which is how a pack can
reach a complete contract on a source nobody approved. All three packs are in exactly that state now.

This checks the two things a machine can check, and refuses to check the one it cannot:

  * a REVIEWED material must name a file that exists whose sha256 still matches — so silently swapping
    the workbook under an approved contract is caught
  * a pack may not claim `contract: approved` in MATURITY.yaml with no reviewed source

Whether the named document is the one RWB actually approved is a human fact. This asserts only that the
claim is recorded, complete, and still true of the bytes on disk.

    python3 platform/tools/source_manifest.py <product-dir> [--check]
    python3 platform/tools/source_manifest.py --all --check
"""
import argparse
import os
import re
import sys


sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from spec_extract import repo_relative                                  # noqa: E402
from product_gates import (approval_record_errors, bad_date, maturity,          # noqa: E402
                           maturity_errors, not_a_person, products, read_yaml,  # noqa: E402
                           repo_root, sha256, unstated, work_entries,           # noqa: E402
                           work_errors,                                         # noqa: E402
                           RELEASE_APPROVAL, RELEASE_APPROVAL_FIELDS)           # noqa: E402
from engine.config import delivery_bindings                                     # noqa: E402 — ONE delivery vocabulary

SOURCE_REFS = "source_refs.yaml"
PIPELINE_CONF = os.path.join("spec_pipeline", "pipeline.conf")
REVIEWED = "reviewed"
PROGRAM_SPEC = "program_spec"
EXTRACTION_INPUT = "extraction_input"
SUPPORTING = "supporting"
# The whole vocabulary, mirrored by governance/schemas/source_refs.schema.json and held equal to it by
# a parity test. The gate required material_type to be NON-EMPTY but never checked it was one of these,
# so the schema refused a bad value in CI while a standalone Gate 1 run accepted it — and reported the
# consequences instead of the cause: putting a PATH on the material_type line produced "0 materials of
# material_type:program_spec" plus "which is material_type:<path>", two indirect errors for one typo.
# The SANITIZED, DERIVED artifact AI actually reads: `spec_pipeline/out/extracted.json`.
#
# Until this existed, eligibility was read off the classification attached to the UNSANITIZED input —
# and on both prostate packs that classification said `sponsor_ai_eligible` about a stand-in that
# demonstrably contains vendor prose. Three different claims were in play at once: the material is
# eligible, the material's content is restricted, and the derivation is sanitized. Only the third is
# true of the file AI opens, and nothing recorded it.
#
# So the derived artifact is registered in its OWN right, with its own classification, its own
# approver, and a binding to the derivation that produced it. Nothing about the raw stand-in
# changes — its fidelity is what `attested_against_sha256` protects — and its classification stops
# being what grants AI access to anything.
AI_EXTRACTION = "ai_extraction"
# The SECOND sanitized derivation AI may read: a MAPPING_EVIDENCE.json (table/column names and
# kinds only, profiler-derived). Its in-file `ai_eligibility: reviewed` block records the human
# read, but an in-file state is MUTABLE — the table list can change after the review while the
# state text stands. Registering the file here as a material binds the approval to the EXACT
# BYTES (`sha256`) and to the profile it derives from (`parent_profile_sha256`), the same
# detached-approval shape ai_extraction uses. propose_source_mapping refuses an evidence file
# that is not registered, or whose bytes have drifted from the registered digest.
AI_MAPPING_EVIDENCE = "ai_mapping_evidence"
MATERIAL_TYPES = (PROGRAM_SPEC, EXTRACTION_INPUT, SUPPORTING, AI_EXTRACTION,
                  AI_MAPPING_EVIDENCE)
AI_MAPPING_EVIDENCE_FIELDS = ["sha256", "approval_date", "approved_by",
                              "parent_profile_sha256"]
# What an `ai_extraction` must state beyond the fields every material carries. Each one is a way the
# approval could otherwise outlive what it was given over:
#   extraction_fingerprint  the run this approval is about — re-extract and the approval is stale
#   redaction_policy_sha256 the marker list the redactor ran under — weaken it and fewer cells are
#                           removed, so the approval no longer describes this file
#   approved_by/date        who decided this sanitized artifact may be read by AI. NOT the same person
#                           or act as classifying the source, which is why it is not `classified_by`
#   sha256                  the BYTES approved. Without it the record named a run and a policy but no
#                           file: `extracted.json` could be hand-edited — a row's `required_rule`
#                           rewritten, a record added — and every check still passed, because
#                           `extraction.fingerprint` sits INSIDE the file it is supposed to identify
#                           and the vendor-prose scan only sees marker text. Reusing the field name
#                           every other material's approval uses, and the check in `check()` that
#                           already verifies it against `path_or_link`, rather than a second
#                           `artifact_sha256` that would agree today and diverge at the first fix.
#   redacted_cells/rows     what the approver was SHOWN. Documented as bound and checked only when
#                           present, which made the human-facing summary optional: deleting both
#                           fields skipped the comparison and still left a readable artifact. The
#                           sha256 protects the file either way, so this was never a content bypass —
#                           it made the sentence a person actually reads unfalsifiable, which is the
#                           half of an approval that carries the judgment.
AI_EXTRACTION_APPROVAL_FIELDS = ["sha256", "approval_date", "approved_by",
                                 "redacted_cells", "redacted_rows"]
# ...and what `ai_readable` demands on top, which it checks ITSELF rather than trusting that Gate 1
# ran: the two fields that say WHICH derivation and WHICH policy this approval was given over.
AI_EXTRACTION_FIELDS = AI_EXTRACTION_APPROVAL_FIELDS + ["extraction_fingerprint",
                                                       "redaction_policy_sha256"]
# The integer fields among them. A COUNT OF ZERO IS AN ANSWER, and `unstated` is the right test for a
# string and the wrong one for an integer: `str(0 or "")` is `""`, so it reads the commonest correct
# case — a pack with no vendor prose to remove — as an unanswered question and refuses it.
COUNT_FIELDS = ("redacted_cells", "redacted_rows")


def field_unstated(material, field):
    """True when `field` is absent or a placeholder — the ONE predicate Gate 1 and `ai_readable` ask.

    Two callers needing the same answer is how this repo's duplications start; `classification_errors`
    exists for exactly that reason. A count answered by PRESENCE in one and by truthiness in the other
    is a pack that registers clean and slices refused, or the reverse.
    """
    if field in COUNT_FIELDS:
        return material.get(field) is None
    return unstated(material.get(field))
# What a REVIEWED material must state. A pending one needs only enough to say what it is and why it is
# not approved — demanding an approver for a scan nobody signed is a field people fill in with "n/a".
APPROVAL_FIELDS = ["document_id", "revision", "sha256", "approval_date", "approved_by"]
# WORKFLOW.md Gate 1 names more than the approval record for the AUTHORITATIVE document: the data
# refresh it specifies, its AI-eligibility classification, and RWB's own specification-QC reference
# ("RWB's own QC pass must be complete before handover"). The schema could not record any of them, so
# a pack could reach `status: reviewed` with the policy half of Gate 1 simply unstated. Required only
# of the program_spec: a stand-in inherits the classification of what it stands in for, and
# attests to fidelity instead (ATTESTATION_FIELDS).
POLICY_FIELDS = ["data_refresh", "rwb_qc_reference"]
# ...except the classification, which is required of EVERY material at EVERY status.
#
# It was required only of a REVIEWED program_spec, and no pack has a reviewed material — so the field
# that decides the AI boundary was, in practice, required nowhere, and every material in the repo
# carries no statement about whether AI may read it. That is the one question in Gate 1 that must not
# be unstated, because the framework's primary AI function (drafting contract records from the spec)
# turns on the answer.
#
# Required at `pending` too, unlike every other Gate 1 field. Those record a REVIEW that has not
# happened yet — demanding an approver for a scan nobody signed is a field people fill in with "n/a".
# The classification is not a review finding: it is knowable the moment the material is registered,
# because it follows from who authored the content. A material can be unapproved indefinitely; it is
# never unclassified.
#
# It is a HUMAN act of authority and must not be inferred — not from the filename, not from the
# folder, not from the `role` prose in this same file. That is the whole reason it is a recorded
# field rather than a derived one, and why AI must not fill it in on a human's behalf.
AI_CLASSIFICATION = "ai_classification"
AI_CLASSES = ("sponsor_ai_eligible", "vendor_restricted", "restricted_derived")
# The ONE class AI may read. Named rather than spelled `AI_CLASSES[0]`, because a tuple position is
# not a meaning: reordering that tuple would silently move which class is eligible.
AI_ELIGIBLE = "sponsor_ai_eligible"
# ...and WHO performed that act, and when. The verdict was recorded without its author, which is the
# one shape this repo refuses everywhere else: CONTRACT_APPROVAL.yaml names an approver and a date,
# a Gate 3 verdict names the profile it read, a reviewed material names who approved it. A
# classification is a person's judgment about what AI may read, and without an attribution there is
# nobody to ask when the judgment is questioned and no way to tell a considered call from a value
# somebody pasted in to make CI go green.
#
# The date matters as much as the name. A material's provenance can change — a workbook revised to
# quote a vendor dictionary, a stand-in re-cut from a delivered extract — and a classification
# made before that change was made about a different document. `classified_date` is what lets a
# reviewer see the judgment predates the thing it is supposed to cover.
#
# Required wherever the classification is: every material, every status. Naming yourself costs
# nothing at the moment you decide, and is unrecoverable a year later.
CLASSIFICATION_FIELDS = ["classified_by", "classified_date"]
# A DERIVATIVE approved as `reviewed` needs one thing more than the document it stands in for.
# Approving the workbook says "this is the specification"; it says nothing about whether a
# stand-in of it is faithful. That is a separate human act — someone read both and confirmed
# they match — and until it is recorded, an approved-looking stand-in is an unchecked copy
# carrying the authority of a document nobody compared it against.
ATTESTATION_FIELDS = ["attested_by", "attestation_date", "attested_against_sha256"]
# The `_by` fields `classification_errors` ALREADY holds to `not_a_person`. Named here so the
# suffix-driven check below does not report the same team name twice for one field — two messages
# for one defect is the I9/I13 shape this file has had to unpick before.
PERSON_CHECKED_ELSEWHERE = frozenset(CLASSIFICATION_FIELDS) | {"approved_by"}
PENDING_FIELDS = ["why_provisional"]
NOT_ON_DISK = ("http://", "https://", "TBD")
# A material the checkout cannot hash for itself. `NOT_ON_DISK` lumps these with `TBD`, which is how
# both the existence check AND the digest check came to be skipped for them together: a `reviewed`
# material at an https link with a sha256 nobody ever compared to the bytes at that URL passed Gate 1
# and reached `approved`. The recorded digest looked exactly like the ones the tool verifies.
#
# Nothing in `platform/` fetches a URL — there is no urllib, requests or curl anywhere in the tree —
# so this checkout cannot close the gap by hashing. What it CAN do is refuse to let an unverified
# remote digest wear the authority of a verified one, and name what would settle it.
REMOTE_PREFIXES = ("http://", "https://")
# What a person records after fetching the bytes themselves. `observed_sha256` is the digest THEY
# got; the tool compares it to the recorded one, so a mismatch is caught even though the fetch was
# not performed here. `--verify-remote` prints the digest to record; it never writes the block,
# because attesting that you fetched something is a human act like every other one in this file.
REMOTE_VERIFICATION_FIELDS = ["verified_by", "verified_date", "observed_sha256", "fetched_from"]


class Unreadable(Exception):
    """source_refs.yaml exists but will not parse. A GATE, not a crash — see check()."""


def load(path):
    """The parsed file, None when absent, or Unreadable when it will not parse.

    `classified_date: 2026-13-45` came out of Gate 1 as a bare ValueError traceback from inside the
    YAML constructor — a governance tool reporting a defect in a governed file as a crash, naming
    neither. The catch itself is `product_gates.read_yaml`, shared with Gate 2: PyYAML raises a plain
    ValueError rather than a YAMLError for an impossible ISO date, and one module getting that subtle
    catch right while the other narrows it is precisely how one gate keeps crashing.
    """
    if not os.path.exists(path):
        return None
    doc, unreadable = read_yaml(path)
    if unreadable:
        raise Unreadable(unreadable)
    return doc


def materials(product):
    doc = load(os.path.join(product, SOURCE_REFS))
    return doc.get("source_materials") or [] if doc else None


def authoritative(product):
    """The pack's program_spec material, or None. Exactly one is required (checked below)."""
    for m in materials(product) or []:
        if m.get("material_type") == PROGRAM_SPEC:
            return m
    return None


def source_status(product):
    """`approved` once the AUTHORITATIVE specification is reviewed, else `provisional`; None when the
    pack states nothing.

    Derived, never stored: a pack's source status IS the status of its program specification. Reading
    "any reviewed material" would let a reviewed methodology note or a supplemental file make the pack
    look source-approved while the specification itself was still pending.
    """
    if materials(product) is None:
        return None
    spec = authoritative(product)
    return "approved" if spec and spec.get("status") == REVIEWED else "provisional"


def pipeline_source_id(product):
    """SPEC_SOURCE_ID from pipeline.conf, or None when the pack has no pipeline."""
    path = os.path.join(product, PIPELINE_CONF)
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            m = re.match(r"^\s*SPEC_SOURCE_ID\s*=\s*[\"']?([a-z0-9_]+)[\"']?", line)
            if m:
                return m.group(1)
    return None


def pipeline_material(product):
    """The registered material SPEC_SOURCE_ID names, or None when it cannot be established.

    None means the question is UNANSWERED — no pipeline.conf, no source_refs.yaml, or an id naming
    nothing registered — never "fine". A caller deciding what AI may read must treat all three the
    same way it treats an explicit refusal; that is why this returns None rather than a default.

    `resolve` above answers a different question (which PATH to extract) and exits on failure, which
    is right for the extractor and wrong for a reader that needs to report rather than die.
    """
    sid = pipeline_source_id(product)
    if not sid:
        return None
    return next((m for m in (materials(product) or []) if m.get("material_id") == sid), None)


AI_BOUNDARY = os.path.join("governance", "ai_boundary.yaml")
_MARKERS = None


def boundary_markers():
    """The governed list of vendor-DOCUMENTATION markers, lower-cased. Cached; [] if the file is gone.

    Declared in `governance/ai_boundary.yaml` rather than written here, because which phrases mean
    "this is the vendor's prose" is a governance judgment that will grow, and a list in shared code is
    a policy nobody can see. That file also carries the reason each entry exists.
    """
    global _MARKERS
    if _MARKERS is None:
        path = os.path.join(repo_root(), AI_BOUNDARY)
        doc, err = read_yaml(path)
        markers = [str(m.get("marker", "")).strip().lower()
                   for m in ((doc or {}).get("documentation_markers") or [])
                   if str(m.get("marker", "")).strip()]
        # FAIL-CLOSED. The first version returned [] when the file was missing or unreadable, and an
        # empty marker list produces zero findings — so DELETING THE POLICY made every pack report
        # clean. That is a security check whose off switch is `rm`, written in the same change that
        # argued eligibility must fail closed. A boundary that cannot be read has not been satisfied.
        if err or not markers:
            raise Unreadable(
                f"{AI_BOUNDARY}: {err or 'declares no documentation_markers'} — the vendor-content "
                f"boundary cannot be checked without it, and an unreadable policy is not a passing "
                f"one. Restore the file or state its markers.")
        _MARKERS = markers
    return _MARKERS


def ai_extraction(product):
    """The pack's registered `ai_extraction` material, or None."""
    return next((m for m in (materials(product) or [])
                 if m.get("material_type") == AI_EXTRACTION), None)


def ai_mapping_evidence(product):
    """The pack's registered `ai_mapping_evidence` material, or None."""
    return next((m for m in (materials(product) or [])
                 if m.get("material_type") == AI_MAPPING_EVIDENCE), None)


def ai_readable(product):
    """(may AI read this pack's extraction, [why not]) — the ONE answer the slicer asks.

    It must NOT ask `ai_eligible(pipeline_material(product))`: the classification on the RAW
    stand-in. That is the wrong artifact. AI opens `spec_pipeline/out/extracted.json`, which is
    DERIVED and sanitized; the stand-in it comes from legitimately contains the vendor prose the
    redactor removes, and a classification saying otherwise was a recorded fact contradicting its own
    subject.

    Everything here is a way an approval could outlive what it was given over, and every one fails
    CLOSED — an unregistered artifact is not an approved one:

      * the artifact must be REGISTERED, classified AI-eligible, and APPROVED by a named person;
      * its `status` must be `reviewed`. A signed approval sitting on a material recorded `pending`
        with a `why_provisional` saying the review has not happened is two statements about one
        artifact, and a pack keeps whichever one the reader reaches first;
      * its `path_or_link` must name the artifact THIS FUNCTION and `spec_slice` actually open. The
        field was written by the registration helper and read by nothing, so the record could point
        anywhere — including at a clean decoy — while the gate checked the canonical file;
      * its `sha256` must match those bytes. `extraction_fingerprint` lives INSIDE `extracted.json`,
        so editing a row's `required_rule` and leaving the fingerprint alone passed every check; the
        vendor-prose scan only sees marker text, and a rewritten rule contains none;
      * its `extraction_fingerprint` must match the extraction on disk, so re-running the pipeline
        invalidates the approval rather than inheriting it;
      * its `redaction_policy_sha256` must match `governance/ai_boundary.yaml` as it now stands,
        so weakening the marker list revokes the approval instead of silently redacting less;
      * its recorded redaction COUNTS must match what the artifact records, so a record cannot
        understate what was removed to a person reading it;
      * NO ancestor in its `derived_from` chain may be `vendor_restricted`, and the chain must
        terminate. Checking the immediate parent only meant one more registered link — stand-in
        -> tidied stand-in -> extraction — moved a restricted document out of view;
      * and the file must still contain no vendor prose, which is the property being approved.
    """
    art = ai_extraction(product)
    if art is None:
        return False, [
            f"no `material_type: {AI_EXTRACTION}` in {SOURCE_REFS} — AI reads the SANITIZED "
            f"`spec_pipeline/out/extracted.json`, not the stand-in it is derived from, and that "
            f"artifact must be registered and approved in its own right. The classification on the "
            f"input says nothing about the file AI opens."]
    why = [f"{AI_EXTRACTION} '{art.get('material_id')}': {e}" for e in classification_errors(art)]
    if art.get(AI_CLASSIFICATION) != AI_ELIGIBLE:
        why.append(f"{AI_EXTRACTION} is classified {art.get(AI_CLASSIFICATION)!r}, not {AI_ELIGIBLE!r}")
    if art.get("status") != REVIEWED:
        why.append(f"{AI_EXTRACTION} is status:{art.get('status')!r}, not {REVIEWED!r} — a signed "
                   f"approval on a material the same record calls provisional is two statements "
                   f"about one artifact")
    for field in AI_EXTRACTION_FIELDS:
        if field_unstated(art, field):
            why.append(f"{AI_EXTRACTION} does not state `{field}` — an unstated field is an "
                       f"unanswered question, not a default")
    if not unstated(art.get("approval_date")) and bad_date(art.get("approval_date")):
        why.append(f"{AI_EXTRACTION} approval_date {bad_date(art.get('approval_date'))}")

    # THE ARTIFACT, taken from the record rather than assumed. `path_or_link` must RESOLVE to the file
    # this function reads and `spec_slice` opens — `AI_READABLE[0]`, so the canonical path has one
    # spelling and it is the one the reader uses.
    #
    # Compared RESOLVED, not as a string. Materials record repo-root-relative paths, which is what
    # `check()` joins against the root; but a pack under test lives outside any checkout, where
    # `repo_root()` is None and a relative form names nothing. Comparing realpaths makes the check say
    # what it means — "the record names the file we read" — instead of "the record spells the path the
    # way this machine would".
    out = os.path.join(product, AI_READABLE[0])
    registered = str(art.get("path_or_link") or "").strip()
    root = repo_root()
    want = repo_relative(out, root) if root else os.path.abspath(out)
    cand = registered if os.path.isabs(registered) else os.path.join(root or product, registered)
    if not registered or os.path.realpath(cand) != os.path.realpath(out):
        why.append(f"{AI_EXTRACTION} registers path_or_link {registered!r}, but the artifact AI opens "
                   f"is {want} — an approval that names a different file than the one read is an "
                   f"approval of nothing")
    if not os.path.exists(out):
        why.append(f"{AI_EXTRACTION} is registered but {out} does not exist")
        return False, why
    # ...and the BYTES. The one check that catches a hand-edited artifact: the fingerprint is a value
    # inside the file, so it survives any edit that leaves it alone.
    recorded = str(art.get("sha256") or "")
    if not unstated(recorded):
        actual = sha256(out)
        if actual != recorded:
            why.append(f"{AI_EXTRACTION} was approved over bytes {recorded[:16]}… but {want} "
                       f"hashes to {actual[:16]}… — the artifact was edited after the approval")
    import json as _json
    try:
        with open(out, encoding="utf-8") as fh:
            data = _json.load(fh)
    except (OSError, ValueError) as exc:
        return False, why + [f"{AI_EXTRACTION} is registered but the artifact will not parse: {exc}"]
    extraction = data.get("extraction") or {}
    got_fp = str(extraction.get("fingerprint") or "")
    if not unstated(art.get("extraction_fingerprint")) and \
            str(art["extraction_fingerprint"]).strip() != got_fp:
        why.append(f"{AI_EXTRACTION} was approved over extraction {art['extraction_fingerprint']} but "
                   f"the artifact on disk is {got_fp or '(unstated)'} — the pipeline was re-run after "
                   f"the approval, so nobody has looked at these bytes")
    got_pol = str((extraction.get("redaction") or {}).get("policy_sha256") or "")
    try:
        want_pol = redaction_policy_sha256()
    except Unreadable as exc:
        return False, why + [f"the vendor-documentation policy cannot be read ({exc}), so this "
                             f"artifact cannot be shown free of it"]
    if not unstated(art.get("redaction_policy_sha256")):
        if str(art["redaction_policy_sha256"]).strip() != got_pol:
            why.append(f"{AI_EXTRACTION} was approved under redaction policy "
                       f"{str(art['redaction_policy_sha256'])[:12]} but the artifact records "
                       f"{got_pol[:12] or '(none)'}")
        elif got_pol != want_pol:
            why.append(f"the artifact was redacted under policy {got_pol[:12]} and "
                       f"{AI_BOUNDARY} now digests to {want_pol[:12]} — the marker list changed, so "
                       f"re-run the pipeline and re-approve rather than inheriting the old decision")
    # ...and the COUNTS the record shows a person. Derived, so a record cannot understate what was
    # removed: "3 cells across 2 rows" beside an artifact that redacted forty is a reviewer reading a
    # summary of a different file, and the summary is the part they read.
    red = extraction.get("redaction") or {}
    for field, key in (("redacted_cells", "cells_redacted"), ("redacted_rows", "rows_redacted")):
        if art.get(field) is None:
            continue                                  # already reported above as unstated
        if int(art.get(field) or 0) != int(red.get(key) or 0):
            why.append(f"{AI_EXTRACTION} records {field}: {art.get(field)} but the artifact redacted "
                       f"{red.get(key)} — the record describes a different run")

    # DEFENCE IN DEPTH ON THE INPUT. Redaction removes vendor DOCUMENTATION CITATIONS; it cannot turn
    # a wholly vendor-authored document into a sponsor-authored one. A delivered data dictionary
    # contains no `Per Knowledge Center` markers precisely because it IS the knowledge centre — so a
    # `vendor_restricted` input must not become readable by being extracted, however clean the marker
    # scan comes back. The human approving the derived artifact would presumably refuse; this makes it
    # not depend on presumably.
    #
    # THE WHOLE ANCESTRY, not the immediate parent. `check()` permits an `ai_extraction` to derive
    # from any material in the pack — the chain is workbook -> stand-in -> extraction and that
    # exception is deliberate — so one more registered link (a tidied copy of a restricted document)
    # put a `vendor_restricted` ancestor one step out of view while every individual link looked
    # legal. A missing or cyclic link is a REFUSAL too: an unresolvable chain is an unanswered
    # question about where the content came from, and `seen` is what stops a cycle from hanging the
    # gate that is supposed to report it.
    by_id = {m.get("material_id"): m for m in (materials(product) or []) if m.get("material_id")}
    seen, node, chain = set(), art, []
    while True:
        parent_id = str(node.get("derived_from") or "").strip()
        if not parent_id:
            break
        chain.append(parent_id)
        if parent_id in seen:
            why.append(f"{AI_EXTRACTION}'s derived_from chain cycles at '{parent_id}' "
                       f"({' -> '.join(chain)}) — a provenance chain that loops names no origin")
            break
        seen.add(parent_id)
        node = by_id.get(parent_id)
        if node is None:
            why.append(f"{AI_EXTRACTION} derives (via {' -> '.join(chain)}) from '{parent_id}', "
                       f"which is not a material in this pack — the chain leaves the record")
            break
        # EVERY ancestor must be AI-ELIGIBLE, not merely "not vendor_restricted". The rule was written
        # against the case in front of it and let `restricted_derived` through — the class for output
        # DERIVED from vendor data, a profile or a schema report, which the framework's posture puts
        # outside AI's reach just as firmly. Stating the rule as a positive is what makes it hold for
        # the next class somebody adds: an ancestor is eligible or the chain is refused.
        klass = str(node.get(AI_CLASSIFICATION) or "").strip()
        if klass != AI_ELIGIBLE:
            why.append(f"{AI_EXTRACTION} derives (via {' -> '.join(chain)}) from '{parent_id}', "
                       f"which is classified {klass or '(unstated)'!r} and not {AI_ELIGIBLE!r} — "
                       f"redaction removes vendor CITATIONS and cannot make vendor-authored or "
                       f"vendor-derived content sponsor-authored")
            break

    # ...and the property actually being approved: no vendor prose in the file AI opens.
    #
    # `Unreadable` is a REFUSAL, not a crash. `boundary_markers` fails closed when the policy is gone,
    # and the caller here is the gate that decides whether AI may read anything — so a policy that
    # cannot be read means the artifact cannot be shown clean, which is exactly a "no".
    try:
        with open(out, encoding="utf-8") as fh:
            hits = vendor_prose(fh.read())
    except Unreadable as exc:
        return False, why + [f"the vendor-documentation policy cannot be read ({exc}), so this "
                             f"artifact cannot be shown free of it"]
    if hits:
        why.append(f"{AI_EXTRACTION} reproduces vendor documentation in {len(hits)} place(s) — "
                   f"whatever was approved, it was not this file")
    return (not why), why


def ai_extraction_block(product):
    """The `ai_extraction` registration for this pack, with every MACHINE-KNOWABLE field filled and
    every human field left as `TODO`, ready to paste into `source_refs.yaml` and sign.

    It prints rather than writes, and the FIVE fields it leaves TODO are the reason. `classified_by`,
    `classified_date`, `approved_by`, `approval_date` — and `ai_classification` itself, which this used
    to emit as `sponsor_ai_eligible`. That was the tool making the judgment and leaving a human to
    countersign it: everything around it said the classification is a human act of authority that must
    never be inferred, while the helper inferred it, and the reviewer pasting the block would be
    signing under an answer already filled in. The one thing a registration helper must not do is
    answer the question it exists to pose.

    Gate 1 refuses an unstated classification at every status, so pasting this block leaves the pack
    red until a person answers. That is not friction to be designed away — it is what an unclassified
    material IS, and the fix is the human act, not a default.

    So: the tool computes the path, the artifact hash, the fingerprint, the policy digest and the
    counts, because getting those right by hand is error-prone and they are pure derivation. The
    judgment and the signature are the person's.
    """
    import json as _json
    out = os.path.join(product, "spec_pipeline", "out", "extracted.json")
    if not os.path.exists(out):
        return None, f"{out} does not exist — run run_spec_pipeline.py first"
    with open(out, encoding="utf-8") as fh:
        extraction = (_json.load(fh).get("extraction") or {})
    red = extraction.get("redaction") or {}
    if "policy_sha256" not in red:
        # A machine-knowable field must never come out as TODO: `unstated` refuses it, so the block
        # would be unregisterable and the operator would be hunting a field the tool could compute.
        return None, (f"{out} carries no `extraction.redaction` record — it predates the redactor. "
                      f"Re-run: python3 platform/tools/run_spec_pipeline.py {product}")
    parent = pipeline_material(product) or {}
    # Repo-root-relative like every other material's path — absolute only when the pack is outside a
    # checkout, which is a test fixture and never a governed pack.
    root = repo_root()
    rel = repo_relative(out, root) if root else os.path.abspath(out)
    return (f"""  - material_id: sanitized_extraction
    material_type: {AI_EXTRACTION}
    role: >
      The sanitized, deterministic extraction of {parent.get('material_id', '?')} — the ONLY artifact
      of this pack AI is permitted to read. {red.get('cells_redacted', 0)} cell(s) across
      {red.get('rows_redacted', 0)} row(s) were removed as reproduced vendor documentation.
    status: pending              # -> reviewed when the TODOs below are answered; `ai_readable`
    why_provisional: >           #    refuses anything else, and Gate 1 then verifies the sha256
      Awaiting the human review that classifies and approves this derived artifact for AI use.
    path_or_link: {rel}
    sha256: {sha256(out)}
    derived_from: {parent.get('material_id', 'TODO')}
    extraction_fingerprint: {extraction.get('fingerprint', 'TODO')}
    redaction_policy_sha256: {red.get('policy_sha256', 'TODO')}
    redacted_cells: {red.get('cells_redacted', 0)}
    redacted_rows: {red.get('rows_redacted', 0)}
    ai_classification: TODO      # sponsor_ai_eligible | vendor_restricted | restricted_derived
    classified_by: TODO          # the person judging this DERIVED artifact readable by AI
    classified_date: TODO        # YYYY-MM-DD — the schema and Gate 1 both refuse a TODO here,
    #                              which is the point: the pack stays RED until a person answers.
    # UNCOMMENT and sign these two at review time — while pending they stay ABSENT, because an
    # approval field holding a placeholder is an approval-shaped lie the schema rightly refuses:
    # approved_by:                # the person approving it for AI use. May be the classifier.
    # approval_date:              # YYYY-MM-DD
""", None)


def redaction_policy_sha256():
    """sha256 of the governed marker policy the redactor ran under.

    An approval of the sanitized extraction is an approval of what the redactor REMOVED, and what it
    removes is decided by `governance/ai_boundary.yaml`. Without pinning it, weakening the marker list
    would silently reduce what is redacted while the human approval — given under the old policy —
    stayed in force. Recorded in the artifact, checked at Gate 1: the same shape as `spec_digest` and
    `config_bundle_sha256`, a derived value bound to what it was derived from.
    """
    path = os.path.join(repo_root(), AI_BOUNDARY)
    if not os.path.exists(path):
        # FAIL-CLOSED, like `boundary_markers`. A policy that is gone cannot be the policy an approval
        # was given under, and returning "" would make the recorded digest simply not match — which is
        # the right answer, said clearly, instead of a FileNotFoundError out of a governance gate.
        raise Unreadable(f"{AI_BOUNDARY} does not exist — the vendor-documentation policy an "
                         f"ai_extraction approval is given under cannot be read")
    return sha256(path)


def vendor_prose(text, context=90):
    """[(marker, excerpt)] where TEXT reproduces vendor documentation, or [] when it does not.

    THE scanner. It looks for the ACT OF CITING a vendor document, never for a vendor's name, table or
    column — see `governance/ai_boundary.yaml` for why that distinction is the whole design. A scan
    for `Flatiron` would fire on every `source: {kind: vendor, ...}` mapping in the repository and on
    sponsor sentences like "From Flatiron, we receive the earliest date of evidence", which are
    verdicts about the feed and cross the boundary by design.

    Substring, case-insensitive, on purpose: this is a boundary check, and a marker split across a
    line break or wrapped in punctuation must still count. It will occasionally flag a sentence that
    merely mentions a marker phrase — that is the safe direction, and the answer is to reword the
    sentence or, if the phrase is genuinely fine, to say so where a human can see it.
    """
    low = (text or "").lower()
    out = []
    for marker in boundary_markers():
        start = 0
        while True:
            i = low.find(marker, start)
            if i < 0:
                break
            excerpt = " ".join(text[max(0, i - 10):i + context].split())
            out.append((marker, excerpt))
            start = i + len(marker)
    return out


# NO SQUARE BRACKETS. `spec_lint.PLACEHOLDER_RE` matches `[A-Za-z][^]]{6,}` inside brackets — the
# `[Overall mHSPC cohort]` shape — so a bracketed notice was read as prose-where-a-rule-belongs and
# I17 then failed three correct records with "the specification does not settle this". It does settle
# it; this artifact merely may not carry it. Those are different facts and the lint has to be able to
# tell them apart, so the notice is bracket-free and carries its own kind instead.
REDACTED = "<<VENDOR DOCUMENTATION REDACTED"


def redact_vendor_prose(text, where=""):
    """(text with any vendor-documentation cell replaced by a notice, [markers found]).

    The counterpart of `vendor_prose`, and deliberately beside it: detection and removal must share
    one definition of what a marker is, or the extractor would redact one set of things while the
    boundary check refuses a different set, and a pack would be simultaneously sanitized and blocked.

    WHY THIS EXISTS RATHER THAN A HUMAN REWORDING THE SOURCE. The quotations are in the sponsor's
    STAND-IN of RWB's specification, and RWB's specification is what quotes the vendor. Rewording
    the stand-in would make it unfaithful to the approved document — which is precisely what
    `ATTESTATION_FIELDS` (`attested_against_sha256`) exist to prevent. So the stand-in is left
    exactly as it is, and the DERIVED, AI-readable artifact is sanitized instead.

    WHOLE CELL, not the matched phrase. Where a rule ends and a quotation begins is a reading of the
    prose, and guessing it is the failure this framework is built against; removing the surrounding
    sentence only would leave a drafter the vendor's rule with its attribution stripped, which is
    worse than either extreme. Removing the cell is the fail-closed direction, and it is recoverable:
    the original is in the pack's `prog_spec/`, where a human may read it.

    IT MUST NOT READ AS SILENCE. An empty cell is indistinguishable from a specification that says
    nothing, and this repo names that as the one mistake nobody downstream can catch — so the notice
    says what was removed, which markers fired, and where the text still is.
    """
    found = sorted({m for m, _e in vendor_prose(text)})
    if not found:
        return text, []
    # THE NOTICE NAMES NO MARKER. Listing which markers fired reproduced the marker strings inside the
    # artifact, so `vendor_prose` found them again and the pack went from 30 breaches to 40 — the
    # redaction failing the check it exists to satisfy. Nothing that lands in an AI-readable file may
    # contain a marker, and that includes this function's own output and any field it sets. The
    # governed list stays in `governance/ai_boundary.yaml`; the count is what the artifact records.
    return (f"{REDACTED}" + (f" @ {where}" if where else "")
            + f", {len(found)} marker(s)>> This cell reproduced vendor documentation, so it is not "
              "carried into an AI-readable artifact. It is NOT absent from the specification: an "
              "AUTHORIZED HUMAN must review the restricted reference material, which is unchanged. "
              "No drafted record may be rendered from this row.", found)


def classification_errors(material):
    """Why this material's CLASSIFICATION RECORD is not a valid one, or [] when it is.

    A classification is a human act of authority, and an act of authority nobody signed is not one.
    `ai_eligible` below answers "does the string say eligible"; this answers "is there a classification
    here at all" — a recognised class, an author, and a real date.

    Split out because two callers need the same answer and were giving different ones: Gate 1
    required `classified_by` and `classified_date` on every material, while the first version of the
    slicer's eligibility check compared the class string alone. A material carrying
    `ai_classification: sponsor_ai_eligible` and nothing else was refused by Gate 1 and accepted by the
    tool that decides what AI reads — the gate and the thing the gate exists to govern disagreeing.

    Deliberately NOT the whole of Gate 1: an unapproved, still-pending material is the normal state
    during Gate 2 drafting, and requiring approval here would block the drafting the framework is for.
    This validates the classification record and nothing else.
    """
    if not material:
        return ["no such material"]
    errors = []
    klass = str(material.get(AI_CLASSIFICATION) or "").strip()
    if unstated(klass) or not klass:
        errors.append(f"requires `{AI_CLASSIFICATION}` ({' | '.join(AI_CLASSES)}) — a human act of "
                      f"authority that decides whether AI may read this material; never inferred "
                      f"from its name, folder or role. Unclassified is unanswered, not eligible")
    elif klass not in AI_CLASSES:
        errors.append(f"{AI_CLASSIFICATION} '{klass}' is not one of {', '.join(AI_CLASSES)} — an "
                      f"unrecognised value is not a classification, and this field decides what AI "
                      f"may read")
    for field in CLASSIFICATION_FIELDS:
        value = material.get(field)
        if unstated(value):
            errors.append(f"requires `{field}` — `{AI_CLASSIFICATION}` is one person's judgment "
                          f"about what AI may read, and a verdict with no author is one nobody can "
                          f"be asked about. The date is what shows the judgment was made about THIS "
                          f"revision of the material rather than an earlier one")
        elif field.endswith("_date") and bad_date(value):
            errors.append(f"`{field}` {bad_date(value)}")
        elif not field.endswith("_date") and not_a_person(value):
            errors.append(f"`{field}`: {not_a_person(value)}")
    # ...and the APPROVER, held to the same rule. `classified_by` and `approved_by` are two different
    # human acts — who judged what this material is, and who accepted it — and a gate that checked one
    # attribution and not the other would refuse `RWP` on the first line and accept it on the next.
    if not_a_person(material.get("approved_by")):
        errors.append(f"`approved_by`: {not_a_person(material.get('approved_by'))}")
    return errors


def ai_eligible(material):
    """Whether AI may read this material's CONTENT. Fail-closed on None and on a blank class.

    THE predicate. `governance/WORKFLOW.md` §"Eligibility" defines the policy; this is the one place
    the recorded field is compared against it, so a second caller cannot come to a different answer
    about the same material. Eligibility follows the recorded classification and nothing else — not
    the folder, not the title, not a task instruction.

    A VALID classification record is a precondition: `sponsor_ai_eligible` with no author and no date
    is a string somebody typed, not a decision anybody made, and the whole point of the field is that
    it records a human act.
    """
    if not material or classification_errors(material):
        return False
    return str(material.get(AI_CLASSIFICATION) or "").strip() == AI_ELIGIBLE


SHA_LINE = re.compile(r"^(\s*)sha256\s*:\s*(.*?)\s*$")
MATERIAL_LINE = re.compile(r"^\s*-\s+material_id\s*:\s*(\S+)\s*$")
PATH_LINE = re.compile(r"^(\s*)path_or_link\s*:")


def record_digest(product, material_id):
    """Write the sha256 of a material's file into its own record. Returns (message, changed).

    A 64-character hex string transcribed by eye is a reliable source of error — this repo took two
    typos in one sitting, from a person reading a digest off one window and typing it into another.
    The value is mechanical and the file is right there, so nobody should be producing it by hand.

    It writes ONLY into an unstated field. A record that already carries a digest and now hashes to
    something else means the file changed under a recorded approval, and quietly re-pointing the
    approval at the new bytes is the failure this field exists to catch — `ai_readable` and Gate 1
    both verify it. So that case is REFUSED and described, and what to do about it is a person's call:
    re-approve the new bytes, or find out why the file moved.

    Line-targeted rather than a YAML round-trip. Rewriting the document would reflow every comment in
    it, and those comments are the `why_provisional` prose the gates are read alongside.
    """
    path = os.path.join(product, SOURCE_REFS)
    if not os.path.exists(path):
        return f"{path} does not exist", False
    mat = next((m for m in materials(product) or []
                if m.get("material_id") == material_id), None)
    if mat is None:
        known = [m.get("material_id") for m in materials(product) or []]
        return (f"{path}: no source material '{material_id}' — registered: "
                f"{', '.join(k for k in known if k) or '(none)'}"), False

    target = str(mat.get("path_or_link") or "").strip()
    if unstated(target):
        return (f"{material_id}: path_or_link is unstated, so there is no file to hash. Register the "
                f"document first — a digest of nothing is not evidence."), False
    root = repo_root()
    cand = target if os.path.isabs(target) else os.path.join(root or product, target)
    if not os.path.exists(cand):
        return f"{material_id}: path_or_link points at {target!r}, which does not exist", False
    if os.path.isdir(cand):
        return (f"{material_id}: path_or_link is a directory ({target}). A digest identifies BYTES; "
                f"a folder's contents can change with none of them recorded."), False

    actual = sha256(cand)
    recorded = str(mat.get("sha256") or "")
    if not unstated(recorded):
        if recorded.strip() == actual:
            return f"{material_id}: sha256 already recorded and still matches {actual[:16]}…", False
        return (f"{material_id}: REFUSED. The record says {recorded[:16]}… and {target} hashes to "
                f"{actual[:16]}… — the file changed under a recorded approval. Overwriting the digest "
                f"would re-point that approval at bytes nobody has looked at. Re-approve the new "
                f"document, or find out why the registered file moved."), False

    # Locate this material's block, and the line to change inside it.
    with open(path, encoding="utf-8") as fh:
        lines = fh.readlines()

    def material_at(i):
        m = MATERIAL_LINE.match(lines[i])
        return m.group(1) if m else None

    start = next((i for i in range(len(lines)) if material_at(i) == material_id), None)
    if start is None:
        return f"{path}: could not locate the `- material_id: {material_id}` line to edit", False
    # The block ends at the next material, or at the first line that is not part of the list — a
    # top-level key like `notes:` follows the materials in every pack's file.
    end = next((i for i in range(start + 1, len(lines))
                if material_at(i) is not None
                or (lines[i].strip() and not lines[i][:1].isspace())), len(lines))

    for i in range(start, end):
        m = SHA_LINE.match(lines[i])
        if m:
            lines[i] = f"{m.group(1)}sha256: {actual}\n"
            break
    else:
        # After `path_or_link`, so the bytes and the digest of them read together. Its indentation is
        # this record's; the `- material_id` line's is two shallower because of the dash.
        anchor = next((i for i in range(start, end) if PATH_LINE.match(lines[i])), None)
        if anchor is None:
            anchor, indent = start, " " * (len(lines[start]) - len(lines[start].lstrip()) + 2)
        else:
            indent = PATH_LINE.match(lines[anchor]).group(1)
        lines.insert(anchor + 1, f"{indent}sha256: {actual}\n")
    with open(path, "w", encoding="utf-8") as fh:
        fh.writelines(lines)
    return f"{material_id}: sha256 {actual} recorded from {target}", True


def resolve(product, material_id):
    """The repo-relative path the extractor should read for `material_id`.

    Exits with an instruction rather than a traceback when it is not registered: this is the first
    thing a new tumour hits, and "KeyError" tells someone onboarding nothing about what to do.
    """
    mats = materials(product)
    for m in mats or []:
        if m.get("material_id") == material_id:
            return str(m.get("path_or_link", ""))
    where = os.path.join(product, SOURCE_REFS)
    if mats is None:
        sys.exit(f"{where} does not exist.\n"
                 f"  The spec pipeline reads the material named by SPEC_SOURCE_ID in "
                 f"spec_pipeline/pipeline.conf, so the source has to be registered before it can be "
                 f"extracted.\n"
                 f"  Copy platform/TUMOR_TEMPLATE/source_refs.yaml into this pack and fill it in.")
    known = [m.get("material_id") for m in mats if m.get("material_id")]
    sys.exit(f"{where}: no source material '{material_id}'.\n"
             f"  pipeline.conf sets SPEC_SOURCE_ID={material_id}; registered material_ids are: "
             f"{', '.join(known) or '(none)'}.\n"
             f"  Either add that material or point SPEC_SOURCE_ID at one of the above.")




def stale_digests(root, rel):
    """Materials whose RECORDED sha256 no longer describes the file, at ANY status.

    `check()` compares the digest only at `status: reviewed` — correct for whether the pack passes
    Gate 1, and the reason a stale digest at any earlier status is invisible. That gap is not
    theoretical: bumping EXTRACTOR_VERSION regenerates every extraction, and prostate's registered
    `ai_extraction` went on recording the bytes of the previous extractor with nothing saying so.

    Recording a digest at `pending` is not nothing — it is what a reviewer will later approve
    AGAINST. If the artifact has moved on, that reviewer signs a hash describing bytes they did not
    read. Reported here rather than raised: at `pending` no claim rests on it yet, so this is a
    record to refresh, not a gate to fail. Refreshing it is a person's act — `record_digest` refuses
    to re-point a recorded value, deliberately.
    """
    out = []
    for m in materials(os.path.join(root, rel)) or []:
        recorded = str(m.get("sha256") or "")
        target = str(m.get("path_or_link") or "").strip()
        if unstated(recorded) or unstated(target) or "://" in target:
            continue
        full = target if os.path.isabs(target) else os.path.join(root, target)
        if not os.path.isfile(full):
            continue
        actual = sha256(full)
        if actual != recorded.strip():
            out.append((str(m.get("material_id") or "?"), recorded.strip(), actual, target))
    return out

def check(root, rel):
    """Errors for one pack. An absent source_refs.yaml is an error only once the pack claims a contract."""
    product = os.path.join(root, rel)
    try:
        mats = materials(product)
    except Unreadable as e:
        return [f"{rel}: {SOURCE_REFS} is not readable YAML ({e}) — Gate 1 cannot tell what this "
                f"pack's source is, which is refused, not skipped"]
    contract = maturity(product)["contract"]
    errors = []

    if mats is None:
        if contract != "not_started":
            errors.append(f"{rel}: no {SOURCE_REFS} — a pack with a contract must record what "
                          f"specification it was written from")
        return errors
    if not mats:
        errors.append(f"{rel}: {SOURCE_REFS} lists no source_materials")
        return errors

    # Exactly one authoritative specification. Zero means nothing decides the pack's source status;
    # more than one means two documents both claim to be the specification.
    specs = [m for m in mats if m.get("material_type") == PROGRAM_SPEC]
    if len(specs) != 1:
        errors.append(f"{rel}: {len(specs)} materials of material_type:{PROGRAM_SPEC} — a pack has "
                      f"exactly one authoritative specification")

    ids = [m.get("material_id") for m in mats]
    for dup in sorted({i for i in ids if i and ids.count(i) > 1}):
        errors.append(f"{rel}: duplicate material_id '{dup}'")

    for i, m in enumerate(mats):
        where = f"{rel}: source_materials[{i}]"
        status = m.get("status", "")
        if not m.get("material_id"):
            errors.append(f"{where}: requires `material_id`")
        mtype = m.get("material_type")
        if not mtype:
            errors.append(f"{where}: requires `material_type`")
        elif mtype not in MATERIAL_TYPES:
            errors.append(f"{where}: material_type {mtype!r} is not one of "
                          f"{', '.join(MATERIAL_TYPES)} — say what KIND of material this is. A path "
                          f"belongs on `path_or_link`.")
        # A derivative must name what it derives from, and that must be a material in this pack.
        derived = m.get("derived_from")
        if m.get("material_type") == EXTRACTION_INPUT and not derived:
            errors.append(f"{where}: material_type:{EXTRACTION_INPUT} requires `derived_from` — a "
                          f"stand-in is not the specification just because it is self-consistent")
        if m.get("material_type") == AI_EXTRACTION and not derived:
            errors.append(f"{where}: material_type:{AI_EXTRACTION} requires `derived_from` — the "
                          f"sanitized artifact is only meaningful as a derivation OF something")
        # A derivative must come from the AUTHORITATIVE document, not from any registered material.
        # Pointing at another derivative, or at supporting material, builds a chain whose far end
        # nobody approved while every individual link looks legal.
        #
        # ONE EXCEPTION, and it is the whole point of `ai_extraction`: the sanitized artifact derives
        # from what the PIPELINE READ, which is normally the stand-in rather than the workbook.
        # workbook -> stand-in -> sanitized extraction is a two-step chain in which every link is
        # registered and the last one carries its own approval, so the rule that forbids chains would
        # here forbid the only shape this material can legally have.
        if m.get("material_type") == AI_EXTRACTION:
            if derived and derived not in ids:
                errors.append(f"{where}: derived_from '{derived}' is not a material_id in this pack")
        elif derived and specs and derived != specs[0].get("material_id"):
            errors.append(f"{where}: derived_from '{derived}' is not the authoritative program_spec "
                          f"'{specs[0].get('material_id')}' — a derivative stands in for THAT document "
                          f"or it stands in for nothing")
        elif derived and derived not in ids:
            errors.append(f"{where}: derived_from '{derived}' is not a material_id in this pack")
        # A REVIEWED `ai_extraction` is held to a DIFFERENT approval record, because it is not a
        # document. `document_id` and `revision` identify a revision somebody issued; a machine
        # derivation has neither, and its identity is `extraction_fingerprint` +
        # `redaction_policy_sha256`, which it states already. Demanding them would be two fields for
        # one fact and would get filled in with whatever made CI go green. What it keeps is the half
        # that makes an approval falsifiable: the bytes, the approver, the date.
        if status == REVIEWED:
            required = (AI_EXTRACTION_APPROVAL_FIELDS if mtype == AI_EXTRACTION
                        else AI_MAPPING_EVIDENCE_FIELDS if mtype == AI_MAPPING_EVIDENCE
                        else APPROVAL_FIELDS)
        else:
            required = PENDING_FIELDS
        # The classification record — class, author, date — through the SHARED validator, which
        # `spec_slice` also calls before it will assemble a slice. These were two checks: Gate 1
        # required the author and date here, and the slicer compared the class string alone, so a
        # material with a class and no signature was refused by the gate and accepted by the tool the
        # gate exists to govern.
        errors += [f"{where}: {e}" for e in classification_errors(m)]
        # ...and NOT of an `ai_extraction`, which also has a parent. Attestation answers "did a person
        # read both and confirm the copy is faithful" — a human judgment about a human stand-in.
        # A deterministic derivation answers it mechanically: `extraction_fingerprint` covers the run,
        # and `run_spec_pipeline --check` regenerates the artifact and byte-compares it in CI. Asking
        # for `attested_by` here would be asking someone to sign as the attester of a file no
        # person typed, which is a signature that means nothing and looks like one that does.
        if status == REVIEWED and derived and mtype != AI_EXTRACTION:
            required = required + ATTESTATION_FIELDS
        if status == REVIEWED and m.get("material_type") == PROGRAM_SPEC:
            required = required + POLICY_FIELDS
        for field in required:
            if field_unstated(m, field):
                why = ""
                if field in ATTESTATION_FIELDS:
                    why = (" — a reviewed derivative must record who checked it against the "
                           "authoritative document, and when")
                elif field in POLICY_FIELDS:
                    why = (" — WORKFLOW.md Gate 1 requires it of the authoritative document "
                           "(the data refresh it governs, and RWB's own QC reference)")
                errors.append(f"{where}: status:{status} requires `{field}`{why}")
            # ...and a PERSON where the field names one. `classification_errors` held
            # `classified_by` and `approved_by` to `not_a_person`; `attested_by` — the one field
            # whose whole subject is "a human read both documents and confirmed the copy" — was
            # checked for PRESENCE only, so `attested_by: RWP` satisfied the attestation that a
            # function cannot make. Keyed on the `_by` SUFFIX, the convention `product_gates`
            # already uses for its approval forms, so a field added later is covered when it lands
            # rather than when somebody remembers this loop.
            elif field.endswith("_by") and field not in PERSON_CHECKED_ELSEWHERE:
                why = not_a_person(m.get(field))
                if why:
                    errors.append(f"{where}: `{field}`: {why}")
        # Dates that are dates. The JSON schema patterns catch this for a schema-validated file, but
        # Gate 1 is the tool that decides whether a material is approved and must not depend on
        # another check having run — and it is the same bad_date every other gate uses, so an
        # approval date cannot mean one thing here and another at Gate 2.
        #
        # `not unstated(...)` because the loop above already reported an unstated one, and bad_date
        # calls a placeholder "not set" too — so a blank `classified_date` produced TWO messages for
        # one defect, the same shape as the I9/I13 duplication. This only stayed hidden for
        # approval_date because no pack is `reviewed`, so that field is never required.
        for field in ("approval_date", "attestation_date", "classified_date"):
            if field in required and m.get(field) and not unstated(m.get(field)):
                why = bad_date(m.get(field))
                if why:
                    errors.append(f"{where}: {field} {why}")

        # ...and PIN that attestation to the revision it was made against. Without this the workbook
        # can be revised under a stand-in that still reads `reviewed`: the attestation would
        # survive the thing it attested to, which is the failure `sha256` exists to prevent one level
        # up. Same reasoning as contract_sha256 in a Gate 3 verdict.
        if status == REVIEWED and derived:
            parent = next((x for x in mats if x.get("material_id") == derived), None)
            got = str(m.get("attested_against_sha256") or "")
            want = str(parent.get("sha256") or "") if parent else ""
            if got and want and got != want:
                errors.append(f"{where}: attested_against_sha256 does not match "
                              f"'{derived}'.sha256 — this stand-in was checked against a "
                              f"different revision of the workbook than the one now approved")

        # The checksum is the whole point of an approval record: it makes "this is the approved
        # document" falsifiable. A path that no longer hashes to the recorded value is a different
        # document. Only a reviewed material carries one — presence of the rest is test_governance's job.
        local = str(m.get("path_or_link", ""))
        # `TBD — the sponsor's document store link to follow` is exempted from hashing because it is not on disk. That is
        # right for a PENDING material and wrong for a reviewed one: it let a pack claim its
        # authoritative specification was approved while naming no retrievable document at all.
        if status == REVIEWED and (unstated(local) or local.strip().upper().startswith("TBD")):
            errors.append(f"{where}: status:{REVIEWED} but path_or_link is {local.strip()!r} — an "
                          f"approved material must name the stable location of the exact document "
                          f"approved. A material still awaiting its link stays `pending`.")
        # EXISTENCE is checked at EVERY status, not only `reviewed`. A pending material legitimately
        # has no local file — `TBD — the sponsor's document store link to follow` is the normal case, and NOT_ON_DISK exempts
        # it. But once a material names a path IN the repo, that path either resolves or the pack is
        # pointing at nothing: Gate 1 said OK on a mistyped workbook filename, and the failure only
        # surfaced later out of run_spec_pipeline.sh, which reads as a pipeline fault rather than a
        # registration one. "Gate 1 passed" has to mean the registered material is findable.
        # A REMOTE MATERIAL CANNOT BE HASHED HERE, so a `reviewed` one has to carry somebody's
        # record of having hashed it. Without that, `sha256` is a number of unknown provenance
        # sitting in the field the gate trusts.
        if local and local.startswith(REMOTE_PREFIXES) and status == REVIEWED:
            recorded = str(m.get("sha256") or "")
            ver = m.get("digest_verification")
            if not recorded:
                errors.append(f"{where}: status is {REVIEWED} at a remote link with no sha256 — "
                              f"nothing identifies which bytes were reviewed, and the link may "
                              f"serve different ones tomorrow")
            elif not isinstance(ver, dict):
                errors.append(f"{where}: sha256 {recorded[:16]}… is recorded for a REMOTE link and "
                              f"nothing in this checkout can fetch it, so no step has ever compared "
                              f"that digest to the bytes at '{local}'. Add `digest_verification: "
                              f"{{{', '.join(REMOTE_VERIFICATION_FIELDS)}}}` recording who fetched "
                              f"it and what they got — `--verify-remote` prints the digest.")
            else:
                for f in REMOTE_VERIFICATION_FIELDS:
                    if unstated(ver.get(f)):
                        errors.append(f"{where}: digest_verification.{f} is unstated — a "
                                      f"verification nobody signed, dated, or sourced is not one")
                why = not_a_person(ver.get("verified_by"))
                if why:
                    errors.append(f"{where}: digest_verification.verified_by — {why}")
                bad = bad_date(ver.get("verified_date"))
                if bad:
                    errors.append(f"{where}: digest_verification.verified_date {bad}")
                obs = str(ver.get("observed_sha256") or "")
                if obs and obs != recorded:
                    errors.append(f"{where}: digest_verification.observed_sha256 {obs[:16]}… does "
                                  f"NOT match the recorded sha256 {recorded[:16]}… — the bytes "
                                  f"fetched are not the bytes this record claims")
        if local and not local.startswith(NOT_ON_DISK):
            full = local if os.path.isabs(local) else os.path.join(root, local)
            # str(): an all-digit checksum is a YAML integer, and an int compares unequal to every hash
            # while reading as falsy — the check would skip the one file it most needs to look at.
            recorded = str(m.get("sha256") or "") if status == REVIEWED else ""
            if not os.path.exists(full):
                errors.append(f"{where}: path_or_link '{local}' names a path in the repo that does "
                              f"not exist. Register the real location, or — if the document is not "
                              f"in the repo yet — say so with a `TBD …` / link value.")
            elif recorded:
                actual = sha256(full)
                if actual != recorded:
                    errors.append(f"{where}: sha256 MISMATCH — the record says {recorded[:16]}… but "
                                  f"the file hashes to {actual[:16]}…; the source changed under the "
                                  f"contract")

    # The extractor's input must BE one of these materials. Otherwise pipeline.conf names one file and
    # the approval record names another, and nothing proves the bytes that produced extracted.json are
    # the bytes anyone approved.
    src_id = pipeline_source_id(product)
    if src_id is None and os.path.exists(os.path.join(product, PIPELINE_CONF)):
        errors.append(f"{rel}: {PIPELINE_CONF} sets no SPEC_SOURCE_ID — the pipeline's input must name "
                      f"a material in {SOURCE_REFS}, not restate a path")
    elif src_id:
        if src_id not in ids:
            errors.append(f"{rel}: {PIPELINE_CONF} extracts SPEC_SOURCE_ID='{src_id}', which is not a "
                          f"material_id in {SOURCE_REFS} (known: {[i for i in ids if i]})")
        else:
            src = next(m for m in mats if m.get("material_id") == src_id)
            # Only the specification, or something registered as standing in for it, may be the
            # pipeline's input. A methodology note or vendor reference is context — extracting one
            # would produce a contract traceable to a document that is not the requirement.
            if src.get("material_type") not in (PROGRAM_SPEC, EXTRACTION_INPUT):
                errors.append(f"{rel}: {PIPELINE_CONF} extracts '{src_id}', which is "
                              f"material_type:{src.get('material_type')} — only {PROGRAM_SPEC} or "
                              f"{EXTRACTION_INPUT} may be the specification the contract is written from")
            local = resolve(product, src_id)
            if local and not local.startswith(NOT_ON_DISK) and not os.path.exists(
                    os.path.join(root, local)):
                errors.append(f"{rel}: the pipeline's source '{src_id}' points at '{local}', which "
                              f"does not exist")

    if contract == "approved":
        if source_status(product) != "approved":
            errors.append(f"{rel}: MATURITY.yaml claims contract:approved but no source material is "
                          f"'{REVIEWED}' — a requirement cannot be approved against a specification "
                          f"that is not")
        # ...and the approved DOCUMENT is not enough. With every record at decision_required — a
        # legitimate Gate 2 end state — no per-record check fires, so a pack could claim approval on
        # an approved workbook while the stand-in the pipeline actually reads was never checked
        # against it.
        unverified = unreviewed_input(product)
        if unverified:
            errors.append(f"{rel}: MATURITY.yaml claims contract:approved but the material the "
                          f"pipeline extracts ('{unverified.get('material_id')}') is "
                          f"status:{unverified.get('status')} — the contract was written from that "
                          f"material, so it must be reviewed too")
    errors += approved_records_on_a_provisional_source(product, rel)
    return errors


def unreviewed_input(product):
    """The pipeline's material when it is NOT itself reviewed, else None.

    `source_status` follows the authoritative document, which is right for "is the specification
    approved" — but the contract is written from whatever the pipeline READS. With an approved workbook
    registered and a pending stand-in extracted, the pack could say "workbook A was approved"
    while every record was drafted from a copy nobody checked against A. Approving records requires
    BOTH: the document approved, and the thing actually read verified against it.
    """
    src_id = pipeline_source_id(product)
    if not src_id:
        return None
    src = next((m for m in materials(product) or [] if m.get("material_id") == src_id), None)
    return src if src and src.get("status") != REVIEWED else None


def approved_records_on_a_provisional_source(product, rel):
    """No individual record may be `requirement: approved` while the specification — or the material
    the pipeline actually read — is not reviewed.

    The pack-level check above is not enough: prostate 202606 held 52 records at
    `requirement: approved` on a source with a TBD link, no revision, no checksum and no approver,
    while MATURITY.yaml sat at coverage_complete — so the pack-level rule never fired. Approving a
    requirement is a statement about the specification, and it cannot outrank the specification's own
    status. `source: unverified` is fine here: that is the VENDOR mapping, settled later at Gate 3.
    """
    contract_md = os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(contract_md):
        return []
    unverified = unreviewed_input(product)
    if source_status(product) == "approved" and not unverified:
        return []
    why = (f"the material the pipeline extracts ('{unverified.get('material_id')}') is "
           f"status:{unverified.get('status')}, so nothing records that it faithfully represents the "
           f"approved document" if unverified and source_status(product) == "approved"
           else f"a source that is not '{REVIEWED}'")
    from contract_lint import records, read, _inline, _kv                      # noqa: PLC0415
    approved = []
    for block in records(read(contract_md)):
        if _kv(_inline(block, "status"), "requirement") == "approved":
            m = re.search(r"(?m)^variable_id:\s*(\S+)", block)
            approved.append(m.group(1) if m else "?")
    if not approved:
        return []
    shown = ", ".join(approved[:6]) + (f", …+{len(approved) - 6}" if len(approved) > 6 else "")
    return [f"{rel}: {len(approved)} record(s) at requirement:approved but {why} ({shown}). Review the "
            f"material in {SOURCE_REFS}, or hold the records at draft / decision_required."]


# The files an AI-eligible pack exposes, relative to the pack. The spec stand-in and the contract
# are what a slice is built FROM; the scaffold and findings are pipeline output over the same text.
# Not a whole-tree walk: a vendor document parked under `Reference/` is a real problem and a DIFFERENT
# one, reported separately below, because the answer to it is "move the file" rather than "reword it".
AI_READABLE = (os.path.join("spec_pipeline", "out", "extracted.json"),
               os.path.join("spec_pipeline", "out", "scaffold.json"),
               # `lint.json` WAS MISSING, AND `spec_slice` OPENS IT ON EVERY RUN. The slicer requires
               # all three pipeline payloads and reads the findings out of this one into the drafting
               # slice — so the boundary list, whose whole purpose is to enumerate what AI may open,
               # did not name a file AI opened every time. A scan over this tuple therefore reported
               # a clean boundary while never looking at it.
               #
               # This is the shape of the risk generally: the list is a SCANNING TARGET, and a
               # scanning target that is narrower than actual reads under-reports by construction.
               # `test_governance` now holds it to what the slicer imports.
               os.path.join("spec_pipeline", "out", "lint.json"),
               os.path.join("handoff", "FUNCTIONAL_CONTRACT.md"),
               os.path.join("handoff", "DECISIONS.md"),
               os.path.join("handoff", "ENGINE_GAPS.md"),
               os.path.join("handoff", "SPEC_QC_FINDINGS.md"))


def boundary_report(product):
    """[(file, marker, excerpt)] for every AI-readable file in a pack whose material is AI-ELIGIBLE.

    The whole extent, which a slice cannot show: `spec_slice` refuses on what one domain happens to
    touch, so a marker in a domain nobody has sliced yet stays invisible until someone tries. This is
    what a human sanitising a pack works from.

    Scoped to eligible packs on purpose. A `vendor_restricted` material is SUPPOSED to contain vendor
    prose; reporting it there would be reporting the classification working.
    """
    # Scoped to packs that CLAIM the artifact is AI-readable. Keyed off the derived artifact's own
    # classification, not the input's: reporting breaches in a pack whose `ai_extraction` says
    # `vendor_restricted` would be reporting the classification working, and keying off the input
    # meant this ran on packs whose AI-readable file nobody had approved at all.
    art = ai_extraction(product)
    if art is None or not ai_eligible(art):
        return []
    out = []
    for rel in AI_READABLE:
        path = os.path.join(product, rel)
        if not os.path.exists(path):
            continue
        try:
            with open(path, encoding="utf-8") as fh:
                text = fh.read()
        except OSError:
            continue
        out += [(rel.replace(os.sep, "/"), m, e) for m, e in vendor_prose(text)]
    return out


def delivery_drift(committed_raw, effective_raw):
    """[why this RUN reads a delivery the release evidence does not cover] — empty when it matches.

    THE OVERRIDE THAT OUTRAN THE APPROVAL. Gate 3 evidence is bound to the committed delivery, and
    `evidence_verdict` proves the recorded verdict describes this DEPLOYMENT — the commit, the tree
    digest, the evidence bytes, the pack entry. None of that is a statement about the RUN. The build
    job takes `refresh` and `source_schema` as widgets and hands them to `load_config` as overrides,
    so a job parameterised at cut 2026m07 / schema B could read a verdict derived for 2026m06 /
    schema A, pass every binding above, and reach the release phase with no human ever having
    confirmed a mapping against the data it actually read. Structural preflight proves the tables
    and columns EXIST; it cannot prove anybody looked at them.

    `output_schema` is deliberately not compared — it decides where rows land, not what was read,
    and it is the one binding an operator is expected to move per environment.

    A pure function of the two mappings, because the notebook that calls it cannot be executed in
    CI. The decision lives here beside `releasable` and `evidence_verdict`, which answer the same
    question and must not drift.
    """
    committed, effective = delivery_bindings(committed_raw), delivery_bindings(effective_raw)
    out = []
    for key in sorted(committed):
        was, now = committed.get(key), effective.get(key)
        if str(was or "") == str(now or ""):
            continue
        out.append(f"run.{key}: this run reads {now if now not in (None, '') else '(unset)'!r} but "
                   f"the deployed pack states {was if was not in (None, '') else '(unset)'!r}, and "
                   f"the Gate 3 verdict was derived from the deployed pack. Source evidence for one "
                   f"delivery is not evidence for another — build and stage if you like, but this "
                   f"run may not publish.")
    return out


# Implementation states that block release: the record itself says the executable is short of the
# requirement. See the comment inside `releasable` for why `not_derivable` is not here.
IMPL_RELEASE_SHORT = ("engine_gap", "config_gap", "partial", "not_implemented")


def releasable(root, rel):
    """(may this pack publish to production, [why not]) — DERIVED, never a stored flag.

    `run_rwdp.py` read `status == "active"` from the registry as its release gate, and
    `products/registry.yaml` says in as many words that `active` means "this is the current, supported
    pack" and "does NOT assert live validation". Prostate is `active` today at
    `contract: coverage_complete, configuration: draft` on a pending stand-in. A pack-currency
    flag was deciding what may reach the public views.

    Nothing new is recorded to fix that. Every input already exists as evidence:

      Gate 1  the authoritative specification is REVIEWED, and the manifest validates
      Gate 2  `contract: approved` — the requirements are signed off
      Gate 4  `configuration: approved` — the executable YAML is signed off
      Gate 3  carried transitively: `product_gates.maturity_errors` refuses `configuration: approved`
              while any vendor-sourced record lacks Gate 3 evidence, and checks the verdict reports

    It lives HERE rather than in `product_gates` because Gate 1 is half the answer and
    `product_gates` must never import back from this module. This module already imports it, so this
    is the one place both halves are visible at once.
    """
    product = os.path.join(root, rel)
    why = []
    if source_status(product) != "approved":
        why.append(f"Gate 1: source is {source_status(product) or 'unregistered'}, not approved")
    why += [f"Gate 1: {e}" for e in check(root, rel)]
    m = maturity(product)
    if m["contract"] != "approved":
        why.append(f"Gate 2: contract is {m['contract']}, not approved")
    if m["configuration"] != "approved":
        why.append(f"Gate 4: configuration is {m['configuration']}, not approved")
    why += [f"evidence: {e}" for e in maturity_errors(root, rel)]
    # THE EXECUTABLE MUST MATCH THE REQUIREMENT, not merely parse. An external review found
    # prostate labelled `active` while its own register said the executable diverges from the RWB
    # requirement across nine areas — and nothing between the label and release read that
    # register. A record claiming implementation short of the requirement (engine_gap, config_gap,
    # partial, not_implemented) is a divergence someone has NAMED; releasing over it would publish
    # a product its own contract says is not built yet. Counted from the records' own
    # `implementation` axis — no new field, no judgment call here. `not_derivable` is deliberately
    # NOT in the set even though contract_lint.IMPL_SHORTFALL carries it: that set answers "must
    # this record name a gap", and an approved requirement the FEED cannot supply is a source fact
    # settled at Gate 3 (I9) — not a claim that the executable falls short.
    #
    # Read through contract_lint's OWN parsers. Records are `key: value` block text, not
    # standalone YAML documents: on prostate, 152 of 202 fail a generic `yaml.safe_load` (prose
    # fields carry colons and quotes), and the first version of this check skipped those with
    # `continue` — a release gate that evaluated a quarter of the register and reported the sample
    # as the whole. It counted 33 shortfalls; the register states 145. Every record is accounted
    # for now, and one whose implementation axis cannot be read BLOCKS: at a release gate,
    # unreadable is a refusal, never a skip.
    contract_md = os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")
    if os.path.exists(contract_md):                       # no contract -> Gate 2 already blocks
        import contract_lint as _cl                      # noqa: PLC0415 — tools import lazily
        short, unreadable, found = [], [], 0
        for rec in _cl.records(_cl.read(contract_md)):
            found += 1
            impl = _cl._kv(_cl._inline(rec, "status"), "implementation")
            vid = _cl._scalar(rec, "variable_id") or f"record[{found}]"
            if impl not in _cl.IMPL:
                unreadable.append(f"{vid} ({impl or 'no readable status.implementation'})")
            elif impl in IMPL_RELEASE_SHORT:
                short.append(vid)
        if unreadable:
            why.append(f"implementation: {len(unreadable)} of {found} record(s) carry no readable "
                       f"implementation axis — a release gate must evaluate every record, and one "
                       f"it cannot read is refused, not skipped — e.g. "
                       f"{', '.join(unreadable[:5])}{' ...' if len(unreadable) > 5 else ''}")
        if short:
            why.append(f"implementation: {len(short)} of {found} record(s) state the executable "
                       f"falls short of the requirement "
                       f"(engine_gap/config_gap/partial/not_implemented) — "
                       f"e.g. {', '.join(short[:5])}{' ...' if len(short) > 5 else ''}")
    return (not why), why


def promoted_receipt_errors(root, slug, ver, build_id):
    """[why no committed receipt shows this build was PUBLISHED], or [].

    THE DIFFERENCE BETWEEN ELIGIBLE AND DONE. `publishable` answers "may this be promoted", which
    is the only question available at promote time. A citation is read afterwards, and the thing it
    has to establish is different: that the build ran, the public views swapped, and the refresh
    ledger recorded it. A candidate that satisfied every gate and was never promoted answers the
    first question and not the second.

    MATCHED ON CONTENT, NOT PATH, and that distinction is the whole reliability of this check.
    `refresh.manifest_path` puts the registry CODE in the path (`mcrpc`), while a citation names the
    tumour SLUG (`prostate`) — so globbing the slug would match no file, find no receipt, and, if
    written the obvious way, report "no receipt" for every citation or silently pass. Reading each
    manifest and comparing its own `tumor`/`spec_version` avoids depending on a naming coincidence.

    It deliberately does NOT re-verify the cited `manifest_sha256` against the ledger copy:
    promotion mutates `status`, `published_at` and `sign_off`, so the published file's digest
    necessarily differs from the candidate digest the approver signed. `release.build_id` is the
    sound pin; comparing digests here would refuse every genuine receipt.
    """
    import glob as _glob
    if not build_id:
        return []                      # a manifest_sha256 alone pins no build to look for
    found = []
    for p in sorted(_glob.glob(os.path.join(root, "refreshes", "*", "*", "*", "*.yaml"))):
        doc, err = read_yaml(p)
        if err or not isinstance(doc, dict):
            continue
        if str(doc.get("tumor") or "") != str(slug) or \
                str(doc.get("spec_version") or "") != str(ver):
            continue
        rel = doc.get("release") or {}
        if str((rel or {}).get("build_id") or "") != str(build_id):
            continue
        found.append((repo_relative(p, root), doc))
    if not found:
        return [f"no committed refresh receipt records build {build_id!r} as published for "
                f"{slug}/{ver}. Passing the gates is permission to promote; a citation says the "
                f"numbers CAME FROM a published cut, and nothing in `refreshes/` records one"]
    # THROUGH THE OWNING VALIDATOR, not a shorter list of the same questions. This checked three
    # fields — `status: released`, a non-blank `published_at`, `tfl_promotion.passed` — and called
    # that a receipt. `engine/refresh.py::validate_manifest` is what actually decides whether a
    # manifest may read `released`: it also requires the counts, the git commit, the release
    # pointer, the source lineage and BOTH sign-offs (Gate 5's reviewer as well as the releaser).
    # Re-asking three of its questions here was a second, weaker implementation of one rule — the
    # duplication this repository keeps paying for — and it would have accepted a manifest the
    # release path itself refuses to write.
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from engine.refresh import validate_manifest                            # noqa: PLC0415
    why = []
    for rel_path, doc in found:
        # GUARDED, because this now runs the release validator over arbitrary COMMITTED YAML.
        # `validate_manifest` assumes the shapes its own writer produces — a list-shaped
        # `source_lineage`, for instance, raises AttributeError rather than returning a finding.
        # An exception here would abort the citation check instead of refusing the citation, which
        # turns a malformed receipt into a crash rather than a verdict.
        try:
            bad = list(validate_manifest(doc))
        except Exception as exc:                    # noqa: BLE001 — malformed IS the finding
            bad = [f"the manifest is malformed and could not be validated "
                   f"({type(exc).__name__}: {exc})"]
        if bad:
            why.append(f"{rel_path} names build {build_id} but is not a valid released manifest: "
                       f"{'; '.join(bad[:4])}")
    # ANY complete receipt is enough; an incomplete one beside it is not a refusal of the good one.
    return [] if len(why) < len(found) else why


def citation_errors(root, entry):
    """[why this work object may not cite what it cites] — the WHOLE safety story for the light path.

    A `request` owes one gate instead of six, and the reason that is safe rather than merely cheap is
    that it INHERITS an approval someone else made. So the citation has to be checked, not recorded:
    every `cites_release` entry must name a pack that exists and that `releasable()` says may publish.
    An unreleasable citation makes the request unapproved too — the inheritance is only worth what
    the thing inherited from is worth, and this is where that is enforced instead of assumed.

    Two strengths, and the caller gets to see which one it bought:
      * `{product, spec_version}`               -> `releasable`: Gates 1-4 on the PACK
      * `+ {build_id, manifest_sha256}`         -> `publishable`: those, AND Gate 6 for THAT build,
                                                  AND a committed receipt that it was PUBLISHED

    Pack-level is the honest default. A build id pins which cut produced the numbers, and a request
    that reports numbers should carry one; a request that describes the specification need not.

    Lives here beside `releasable` for the reason that function gives: Gate 1 is half the answer, and
    `product_gates` must never import back from this module.
    """
    out = []
    cites = entry.get("cites_release") or []
    for i, c in enumerate(cites):
        where = f"{entry.get('id') or '?'} cites_release[{i}]"
        if not isinstance(c, dict):
            out.append(f"{where}: not a mapping")
            continue
        slug = str(c.get("product") or "").strip()
        ver = str(c.get("spec_version") or "").strip()
        if not slug or not ver:
            out.append(f"{where}: needs both `product` (a tumour slug) and `spec_version`")
            continue
        rel = os.path.join("products", str(c.get("family") or "oncology"), slug, ver)
        if not os.path.isdir(os.path.join(root, rel)):
            out.append(f"{where}: {rel} does not exist — a citation must name a real pack")
            continue
        build_id, man = c.get("build_id"), c.get("manifest_sha256")
        if build_id or man:
            ok, why = publishable(root, rel, build_id, man)
            # ...AND IT WAS ACTUALLY PUBLISHED. `publishable` is a forward-looking PERMISSION —
            # Gates 1-4 plus Gate 6 for that build — which is the right question at promote time,
            # when no receipt can exist yet. It is the wrong question of a citation: an answer
            # citing a build was computed on a cut that ran and went live, and "was eligible to be
            # promoted" is satisfied by a candidate that never was. Pinning a build IS the claim
            # that the numbers came from that published cut, so the receipt is required with it.
            why = list(why) + promoted_receipt_errors(root, slug, ver, build_id)
            ok = not why
            level = f"build {build_id}"
        else:
            ok, why = releasable(root, rel)
            level = "pack"
        if not ok:
            out += [f"{where}: {rel} ({level}) is not citable — {w}" for w in why]
    return out


def publish_approval_errors(root, rel, build_id, manifest_sha256):
    """[why this BUILD may not be promoted to the public views] — Gate 6, bound to the run.

    `releasable()` above answers "may this PACK publish", from Gates 1-4. That is a statement about
    artifacts that sit still: a specification, a contract, a configuration graph. It is not, and
    cannot be, a statement about a CUT — these patients, these counts, this QC result — because the
    same approved configuration over next month's delivery produces a different product.

    WORKFLOW.md Gate 6 requires a named final approval. The runner never asked for one: it confirmed
    Gates 1-4, built, ran QC, swapped the public views, and sign-off was promoted to the ledger
    AFTERWARDS. So a person with production credentials could move the public product on a
    technically clean run no accountable person had looked at. Everything else in this repository is
    built to make that impossible; this was the hole.

    The two-phase flow this enables, which is the point:

        build + QC + golden + deliverables
              -> immutable versioned table and a candidate manifest, public views UNTOUCHED
              -> a person reads that manifest and signs `handoff/RELEASE_APPROVAL.yaml`
              -> a promotion run finds the approval naming THIS build and swaps

    FAIL-CLOSED at every step: no file, an unstated field, a placeholder, a date that is not a date,
    or a build id that does not match all refuse. `approved_manifest_sha256` is separate from
    `approved_build_id` because a build id says WHICH run and the manifest digest says WHAT THE
    APPROVER SAW — pinning only the first approves a number, not an output.
    """
    why = []
    product = os.path.join(root, rel)
    form = os.path.join(product, *RELEASE_APPROVAL.split("/"))
    if not os.path.exists(form):
        return [f"Gate 6: no {RELEASE_APPROVAL} — WORKFLOW.md requires a NAMED final approval before "
                f"the public views move. Build and stage first, then approve the candidate manifest "
                f"this run wrote, then promote."]
    # The who/when/placeholder/date reasoning is `approval_record_errors`' — Gate 2 and Gate 4 use the
    # same one, and a second copy here would diverge at the first fix applied to either.
    why += [f"Gate 6: {e}" for e in approval_record_errors(
        product, rel, RELEASE_APPROVAL, "release", RELEASE_APPROVAL_FIELDS, (),
        ("approval_date", "validation_date"))]
    doc, err = read_yaml(form)
    if err:
        return why + [f"Gate 6: {RELEASE_APPROVAL} does not parse: {err}"]
    # THE RUN-SPECIFIC HALF, which no shared reader can do: it compares against values that exist only
    # once the build has run.
    for field, actual, what in (("approved_build_id", build_id, "this build"),
                                ("approved_manifest_sha256", manifest_sha256, "this manifest")):
        stated = str(doc.get(field, "") or "").strip()
        if not stated or unstated(stated):
            why.append(f"Gate 6: {field} is unstated — the approval does not say which run it covers")
        elif not actual:
            why.append(f"Gate 6: {field} is stated but the runner supplied no value for {what} — "
                       f"an unverifiable binding is not a binding")
        elif stated != str(actual).strip():
            why.append(f"Gate 6: {field} approves {stated!r} and this run is {str(actual).strip()!r} "
                       f"— the approval covers a DIFFERENT {what.split()[-1]}. Approve this one or "
                       f"promote the one that was approved.")
    # SEPARATION OF DUTIES, the half a committed form CAN enforce. `validated_by` is Gate 5's
    # reviewer of the evidence and `approved_by` is Gate 6's releaser; one person wearing both
    # names is a review nobody independent performed. This does not authenticate either name —
    # governance/APPROVAL_IDENTITY.md is explicit that a typed name is attribution, not
    # authorization, until protected review events exist — but a form that cannot even NAME two
    # people has not tried.
    _approver = str(doc.get("approved_by") or "").strip()
    _validator = str(doc.get("validated_by") or "").strip()
    if _approver and _validator and _approver.lower() == _validator.lower():
        why.append(f"Gate 6: approved_by and validated_by are the same person ({_approver!r}) — "
                   f"the release approver may not also be Gate 5's evidence reviewer. Two named "
                   f"people, or no release.")
    return why


def publishable(root, rel, build_id=None, manifest_sha256=None):
    """(may THIS BUILD move the public views, [why not]) — `releasable` AND a Gate 6 approval.

    One-way, like every other derived answer here: Gate 6 cannot rescue a pack that fails Gates 1-4,
    and passing Gates 1-4 does not promote anything on its own.
    """
    ready, why = releasable(root, rel)
    why = list(why)
    if ready:
        why += publish_approval_errors(root, rel, build_id, manifest_sha256)
    return (not why), why


# The RECORDED form of the answer above, for the one environment that cannot compute it. Named here,
# beside `releasable`, because it is the same question — `deploy_tree.py` writes the file and
# `run_rwdp.py` reads it, and a filename spelled in two places is a deployment that writes evidence
# nothing reads.
RELEASE_EVIDENCE = "RELEASE_EVIDENCE.yaml"


def evidence_verdict(path, rel, git_commit, tree_sha256=None, evidence_sha256=None):
    """(may this pack publish, [why not]) from a RECORDED evaluation — `releasable` for a tree that
    cannot re-derive it.

    A production deployment is deliberately NOT a checkout: `deploy_tree.py` omits the specification
    stand-ins, and Gate 1 requires any material naming a repo path to exist and still hash to its
    recorded sha256. Evaluate `releasable()` inside the deployed tree and every pack is permanently
    blocked by the absence of the very file the packaging exists to keep out. So the evaluation happens
    at BUILD time against the full repository and is written down.

    Writing it down is the dangerous part, and this is the function that makes it safe. A stored
    verdict is exactly the `release_ready: true` field this repo rejected once already; what makes this
    one different is that it is refused unless it demonstrates it describes THIS deployment:

      * the commit must match, in both directions — an unstated `git_commit` on either side is not a
        match, so a job run without one cannot publish off any evidence file at all;
      * the TREE must match. The commit binding alone compares two strings and says nothing about the
        bytes: a tree built from a dirty checkout and stamped with a clean approved SHA satisfied it,
        as did editing the generated tree after its evidence was written. `deploy_tree.tree_digest`
        records a sha256 over every deployed path and its content; the caller recomputes it and passes
        it here. An evidence file with no `tree_sha256`, or a caller that computed none, is refused —
        a binding that can be omitted is not one;
      * the pack must have an entry — a pack absent from the evaluation was not evaluated, which is
        not the same as evaluated and cleared;
      * `releasable` must be literally `true` — not truthy, because `1` and `"yes"` are what a
        hand-edit looks like;
      * `releasable: true` carrying blockers is a CONTRADICTION and is refused. Nothing generates that
        shape; only an edit does, and it is the precise edit someone makes to unblock a release.

    Every failure returns False. There is no path through here that publishes on a file it could not
    fully understand.
    """
    doc, err = read_yaml(path)
    if err:
        return False, [f"{os.path.basename(path)}: {err} — release evidence that will not parse is "
                       f"not a permission"]
    want = str(git_commit or "").strip()
    got = str(doc.get("git_commit") or "").strip()
    if not want or not got or got != want:
        return False, [f"{os.path.basename(path)} was built at commit {got[:12] or '(unstated)'} but "
                       f"this run passes git_commit={want[:12] or '(unstated)'} — release evidence "
                       f"must match the deployed code"]
    # THE EVIDENCE FILE CANNOT AUTHORIZE ITSELF. `tree_sha256` necessarily excludes this file — a
    # digest cannot cover the bytes it sits in — so the one artifact that GRANTS permission was the one
    # nothing protected: flipping `releasable` to `true` and emptying `blockers` changed no covered
    # file, and every check here passed. The digest therefore arrives OUT OF BAND, from the job
    # parameter the deploying pipeline sets out of `deploy_tree`'s output.
    #
    # It is not a signature and does not prove who built the tree; it makes a hand edit require
    # repairing three mutually-referencing digests at once. An attested CI-built artifact is the real
    # anchor, and this is defence in depth beneath it.
    want_ev = str(evidence_sha256 or "").strip()
    got_ev = sha256(path)
    if not want_ev or got_ev != want_ev:
        return False, [f"{os.path.basename(path)} digests to {got_ev[:12]} but this run passes "
                       f"release_evidence_sha256={want_ev[:12] or '(unstated)'} — the file that grants "
                       f"the release is not the one the deployment published. It is excluded from "
                       f"tree_sha256 by construction, so this is the only thing that covers it."]
    want_tree = str(tree_sha256 or "").strip()
    got_tree = str(doc.get("tree_sha256") or "").strip()
    if not want_tree or not got_tree or got_tree != want_tree:
        return False, [f"{os.path.basename(path)} records tree_sha256 "
                       f"{got_tree[:12] or '(unstated)'} but the deployed tree digests to "
                       f"{want_tree[:12] or '(uncomputed)'} — the evidence does not describe these "
                       f"bytes"]
    entries = doc.get("products")
    if not isinstance(entries, dict):
        return False, [f"{os.path.basename(path)} states no `products:` mapping"]
    entry = entries.get(rel)
    if not isinstance(entry, dict):
        return False, [f"{os.path.basename(path)} carries no entry for {rel} — this pack was not part "
                       f"of the evaluated deployment"]
    blockers = entry.get("blockers")
    blockers = [str(b) for b in blockers] if isinstance(blockers, list) else []
    if entry.get("releasable") is not True:
        return False, blockers or [f"{rel} is recorded as not releasable, with no reason given"]
    if blockers:
        return False, [f"{os.path.basename(path)} records {rel} as releasable AND lists blockers — "
                       f"nothing generates that; refusing"] + blockers
    return True, []


def remote_materials(product):
    """[(material_id, url)] for every material registered at an http(s) link."""
    return [(str(m.get("material_id") or "?"), str(m.get("path_or_link") or ""))
            for m in (materials(product) or [])
            if str(m.get("path_or_link") or "").startswith(REMOTE_PREFIXES)]


def verify_remote(product, opener=None):
    """[(material_id, url, observed_sha256 | None, note)] — what each remote link serves NOW.

    THE ONLY STEP IN THIS FILE THAT LEAVES THE MACHINE, which is why it is a separate verb rather
    than part of `--check`: a gate that silently made outbound requests to a sponsor's host every
    time CI ran would be doing something nobody asked for, from an environment nobody reviewed.
    It is also why it WRITES NOTHING. Printing the digest is a fact; recording that you fetched and
    compared it is an attestation, and attestations are typed by the person making them.

    `urllib` is imported inside the function on purpose: `platform/` has no fetch primitive anywhere
    else, and a module-level import would put one on the import path of every governance tool.
    """
    import hashlib                                                       # noqa: PLC0415
    import urllib.error                                                  # noqa: PLC0415
    import urllib.request                                                # noqa: PLC0415
    open_url = opener or (lambda u: urllib.request.urlopen(u, timeout=30))
    out = []
    for mid, url in remote_materials(product):
        try:
            with open_url(url) as fh:
                digest = hashlib.sha256(fh.read()).hexdigest()
            out.append((mid, url, digest, "fetched"))
        except Exception as exc:                     # noqa: BLE001 - a report, never a traceback
            out.append((mid, url, None, f"NOT FETCHED — {type(exc).__name__}: {exc}"))
    return out


def main(argv):
    ap = argparse.ArgumentParser(description="Gate 1: check each pack's source approval record.")
    ap.add_argument("product", nargs="?")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--check", action="store_true", help="exit non-zero on any error")
    ap.add_argument("--list-releasable", action="store_true",
                    help="packs whose evidence permits publishing to production. DERIVED from Gates "
                         "1-4; there is no releasable flag to set.")
    ap.add_argument("--why-blocked", action="store_true",
                    help="with --list-releasable, print what each pack is waiting on instead")
    ap.add_argument("--verify-remote", metavar="PACK",
                    help="FETCH every remote material this pack registers and print the sha256 of "
                         "what the URL actually serves, for a person to record in "
                         "`digest_verification`. Makes NETWORK REQUESTS and writes nothing")
    # "the four signature fields" was wrong twice over: there are FIVE, and the first of them is not
    # a signature. `ai_classification` is the judgment the whole AI boundary rests on, and counting
    # it among the signatures reads as though the classification were already made and only needed
    # countersigning — the exact impression `ai_extraction_block` was changed to stop giving.
    ap.add_argument("--register-ai-extraction", metavar="PACK",
                    help="print the `ai_extraction` registration block for PACK: the derivation "
                         "fields (path, sha256, fingerprint, redaction policy, counts) computed, "
                         "and five left TODO for a person — the ai_classification itself, who "
                         "classified it and when, and the two approval fields. Writes nothing.")
    ap.add_argument("--ai-boundary", action="store_true",
                    help="report where an AI-ELIGIBLE pack's readable files reproduce vendor "
                         "documentation — the check spec_slice enforces, over the whole pack")
    ap.add_argument("--record-digest", metavar="MATERIAL_ID",
                    help="compute the sha256 of that material's file and write it into its record. "
                         "Only fills an UNSTATED digest; a recorded one that no longer matches is "
                         "reported and left alone, because that is a file that changed under an "
                         "approval")
    ap.add_argument("--resolve", metavar="MATERIAL_ID",
                    help="print the registered path for a material; how the spec pipeline finds its "
                         "input without restating it")
    a = ap.parse_args(argv)

    if a.verify_remote:
        product = a.verify_remote
        rows = verify_remote(product)
        if not rows:
            print(f"{product}: registers no remote material — nothing to fetch. Every material is "
                  f"on disk, where `--check` hashes it directly.")
            return 0
        recorded = {str(m.get("material_id")): str(m.get("sha256") or "")
                    for m in (materials(product) or [])}
        bad = 0
        for mid, url, digest, note in rows:
            print(f"  {mid}")
            print(f"      {url}")
            if digest is None:
                print(f"      {note}")
                bad += 1
                continue
            was = recorded.get(mid, "")
            verdict = ("matches the recorded sha256" if was and digest == was else
                       "DIFFERS from the recorded sha256" if was else "no sha256 recorded yet")
            if was and digest != was:
                bad += 1
            print(f"      observed sha256: {digest}")
            print(f"      {verdict}" + (f" ({was})" if was and digest != was else ""))
        print(f"\n{len(rows)} remote material(s) fetched. NOTHING WAS WRITTEN — record the digest "
              f"yourself under `digest_verification` with your name and the date; a fetch this tool "
              f"performed is not an attestation you made.")
        return 1 if bad else 0

    if a.register_ai_extraction:
        block, err = ai_extraction_block(a.register_ai_extraction)
        if err:
            sys.exit(err)
        print("# Paste as a NEW LIST ITEM inside `source_materials:` — matching that list's\n"
              "# indentation, NOT at the end of the file: text appended after the last top-level\n"
              "# key silently attaches to the wrong key and the material never registers, while\n"
              "# every check stays green because to them it simply does not exist. Confirm with\n"
              "# `--check`: the pack must go RED (unstated classification) — an OK right after\n"
              "# pasting means the paste did not land.\n"
              "# Then answer the TODOs.\n"
              "# They are the human act: WHAT this derived artifact is classified as, who judged it\n"
              "# so, who approves it for AI use, and when. A tool filling them in would be deciding\n"
              "# AI access on a person's behalf — the classification most of all, which this helper\n"
              "# is never pre-filled — a reviewer states it rather than countersigning it.\n"
              "#\n"
              "# Gate 1 refuses an unstated classification at every status, so the pack is RED from\n"
              "# the moment this is pasted until a person answers. That is what an unclassified\n"
              "# material is. Then set `status: reviewed` — `ai_readable` refuses anything else, and\n"
              "# Gate 1 verifies the recorded sha256 against the artifact from that point on.\n")
        print(block, end="")
        return 0

    root = repo_root()
    if a.record_digest:
        if not a.product:
            sys.exit("--record-digest needs a product directory")
        msg, changed = record_digest(os.path.abspath(a.product), a.record_digest)
        print(msg)
        # Non-zero when nothing was written, so a script cannot read "already recorded and matching"
        # and "REFUSED, the file changed" as the same successful outcome.
        return 0 if changed else 1
    if a.resolve:
        if not a.product:
            sys.exit("--resolve needs a product directory")
        print(resolve(os.path.abspath(a.product), a.resolve))
        return 0
    if a.list_releasable:
        rels = products(root) if a.all or not a.product else [
            repo_relative(os.path.abspath(a.product), root)]
        ok = 0
        for rel in rels:
            can, why = releasable(root, rel)
            if can:
                ok += 1
                print(rel if not a.why_blocked else f"{rel:<40} RELEASABLE")
            elif a.why_blocked:
                print(f"{rel:<40} BLOCKED")
                for w in why[:4]:
                    print(f"    {w}")
                if len(why) > 4:
                    print(f"    ... and {len(why) - 4} more")
        if a.why_blocked:
            print(f"\n{ok}/{len(rels)} pack(s) releasable")
        return 0

    if a.ai_boundary:
        try:
            boundary_markers()
        except Unreadable as exc:
            sys.exit(str(exc))
        rels = products(root) if a.all or not a.product else [
            repo_relative(os.path.abspath(a.product), root)]
        total = 0
        for rel in rels:
            hits = boundary_report(os.path.join(root, rel))
            total += len(hits)
            by_file = {}
            for f, m, e in hits:
                by_file.setdefault(f, []).append((m, e))
            print(f"{rel:<40} {len(hits) or 'clean'}"
                  + (" vendor-documentation quotation(s)" if hits else ""))
            for f, found in sorted(by_file.items()):
                print(f"    {f}  ({len(found)})")
                for m, e in found[:2]:
                    print(f"      [{m}] …{e}…")
                if len(found) > 2:
                    print(f"      ... and {len(found) - 2} more in this file")
        print(f"\n{total} quotation(s). Each is a contradiction between a material recorded "
              f"{AI_ELIGIBLE!r} and its own content;\nresolve by rewording to the sponsor's "
              f"conclusion plus a restricted-evidence reference, or by reclassifying.")
        return 1 if (total and a.check) else 0

    rels = products(root) if a.all or not a.product else [
        repo_relative(os.path.abspath(a.product), root)]

    errors, shown = [], 0
    for rel in rels:
        product = os.path.join(root, rel)
        status = source_status(product)
        contract = maturity(product)["contract"]
        if status is None and contract == "not_started":
            continue                                    # nothing claimed, nothing to check
        shown += 1
        errs = check(root, rel)
        errors += errs
        # STALE-DIGEST is printed beside OK, never folded into it. It is not a Gate 1 error at a
        # pre-review status, and it must not read as a clean pack either: the record names bytes the
        # file no longer has, and the person who eventually reviews it would otherwise sign a hash
        # over something they did not read.
        stale = stale_digests(root, rel)
        print(f"{rel:<40} source:{status or 'NONE':<12} contract:{contract:<15}"
              + ("  OK" if not errs else f"  {len(errs)} error(s)")
              + (f"  [{len(stale)} STALE DIGEST]" if stale else ""))
        for mid, rec, act, tgt in stale:
            print(f"    ! {mid}: records sha256 {rec[:16]}… and {tgt} now hashes to {act[:16]}… — "
                  f"the record describes bytes this file no longer has. A person must re-record it "
                  f"before this material is reviewed; `--record-digest` refuses to re-point one.")
        for e in errs:
            print(f"    {e}")

    # WORK OBJECTS that are not products. A request owes provenance instead of Gates 1-4, and this
    # is where that obligation is actually checked — the shape of the `work:` block, then whether
    # each cited release is genuinely citable. Reported in the SAME run as Gate 1 because it is the
    # same question asked of a lighter object: is what this rests on approved?
    work = work_entries(root)
    if work and (a.all or not a.product):
        werrs = work_errors(root)
        for w in work:
            cerrs = citation_errors(root, w)
            werrs += cerrs
            cites = len(w.get("cites_release") or [])
            print(f"{str(w.get('id') or '?'):<40} kind:{str(w.get('kind') or 'NONE'):<11} "
                  f"cites:{cites:<4}" + ("  OK" if not cerrs else f"  {len(cerrs)} error(s)"))
            for e in cerrs:
                print(f"    {e}")
        errors += werrs
        for e in (e for e in werrs if e.startswith("registry work[")):
            print(f"    {e}")
        print(f"{len(work)} work object(s) beyond products")

    print(f"\n{shown} pack(s) with something to check; {len(errors)} error(s)")
    return 1 if (a.check and errors) else 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
