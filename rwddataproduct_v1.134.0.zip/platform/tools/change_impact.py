#!/usr/bin/env python3
"""One specification row changed. WHAT has to be re-checked? — deterministically.

    python3 platform/tools/change_impact.py <pack> clinical:12 [demographics:7 ...]
    python3 platform/tools/change_impact.py <pack> --changed-file handoff/CHANGED_ROWS.txt
    python3 platform/tools/change_impact.py <pack> clinical:12 --json

THE FAILURE THIS PREVENTS. A revised workbook moves eleven rows. Somebody re-drafts the eleven
contract records, the lint is clean, the artifacts regenerate, and the pack ships — while a golden
case that cited one of those rows was never re-run, and a config block two records away from the
change still holds the old number. The chain from "a row moved" to "these things are now
unverified" exists in the repository, in five separate files, and has never been walked in one
direction by anything.

So this walks it, and the order is the point:

    specification row
      -> contract record(s) citing it              (spec_refs)
      -> config block(s) those records implement   (implementation_refs)
      -> capabilities reading those config files   (capabilities.yaml config_keys)
      -> published output column(s)                (output.physical_name)
      -> goldens and source checks that must rerun (fixtures citing the row)

EVERY LINK IS READ FROM THE THING ITSELF, never re-derived. The records come from
`contract_lint`, the governed blocks from `contract_binding` — the same set the binder holds a
contract to — and the capabilities from the registry `capability_registry` validates. A private
walk of `variables/*.yaml` here would eventually disagree with the binder, and the disagreement
would silently shrink the impact set, which is the one direction a change-impact report must never
be wrong in.

IT REPORTS REACH, NOT RISK. Nothing here decides whether a change is safe. It answers the narrower
and checkable question of what the change TOUCHES, so that "we re-ran everything affected" is a
statement somebody can verify instead of recall.

AND A ROW NOTHING CITES IS A FINDING, not an empty result. If a moved row reaches no record, either
the row is not implemented or the citation is missing — both are answers a person needs, and both
look identical to "no impact" in a report that prints nothing.

stdlib only. Writes nothing: output goes to stdout, `--json` too.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import contract_binding as cb                                            # noqa: E402
import contract_lint as cl                                              # noqa: E402
from spec_extract import repo_relative                                   # noqa: E402


def _rows_for(ref):
    """Expand a spec_ref into the row ids it covers. `clinical:70-77` covers clinical:71.

    Through `contract_binding.spec_ref_rows`, which the enumeration comparison already uses — a
    second range parser here would eventually disagree about whether a family record covers a row,
    and the impact set would shrink without anyone noticing.
    """
    return {f"{domain}:{n}" for domain, n in cb.spec_ref_rows(ref)}


def records_citing(pack, rows):
    """[{variable_id, spec_refs, blocks, column, requirement}] for records citing any of `rows`."""
    path = os.path.join(REPO, pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(path):
        return []
    want, out = set(rows), []
    for block in cl.records(cl.read(path)):
        refs = cl._list(block, "spec_refs") or []
        covered = set()
        for r in refs:
            covered |= _rows_for(r)
        hit = sorted(covered & want)
        if not hit:
            continue
        out.append({
            "variable_id": cl._scalar(block, "variable_id") or "?",
            "rows": hit,
            "blocks": sorted(r for r in (cl._list(block, "implementation_refs") or [])
                             if "#/" in r),
            "column": cl._kv(cl._inline(block, "output"), "physical_name") or "",
            "requirement": cl._kv(cl._inline(block, "status"), "requirement") or "",
        })
    return out


def capabilities_for(blocks):
    """{capability id: [config file]} for capabilities whose `config_keys` name a changed file.

    Keyed on the FILE rather than the block, because `config_keys` are file-and-section names
    (`data_product.cohorts`), not JSON pointers. That makes this deliberately WIDER than the block
    set: a capability reading a file one of whose blocks moved is in scope. For a report whose job
    is "what must be re-checked", over-inclusion is the safe direction and under-inclusion is the
    defect.
    """
    try:
        import capability_registry as cr
        doc = cr.load()
    except Exception:  # noqa: BLE001 - no registry / unreadable -> report nothing rather than guess
        return {}, "the capability registry could not be read"
    files = {b.split("#/", 1)[0] for b in blocks}
    stems = {os.path.splitext(os.path.basename(f))[0] for f in files}
    out = {}
    for cap in (doc.get("capabilities") or []):
        keys = cap.get("config_keys") or []
        touched = sorted({k for k in keys if str(k).split(".", 1)[0] in stems})
        if touched:
            out[cap.get("id", "?")] = touched
    return out, None


def goldens_citing(rows):
    """{fixture path: [case id]} for golden cases whose `spec_ref` names a changed row.

    A golden is the only artifact that states an EXPECTED clinical value, so a moved row it cites
    is the strongest possible "re-run this": the expectation may now be wrong, and nothing else in
    the repository would say so.
    """
    import re
    want, out = set(rows), {}
    fixtures = os.path.join(REPO, "platform", "tests", "fixtures")
    if not os.path.isdir(fixtures):
        return out
    for name in sorted(os.listdir(fixtures)):
        if not name.endswith((".yaml", ".yml")) or "golden" not in name:
            continue
        path = os.path.join(fixtures, name)
        try:
            text = open(path, encoding="utf-8").read()
        except OSError:
            continue
        hits, case = [], None
        for line in text.splitlines():
            m = re.match(r"\s*-\s*id:\s*(\S+)", line)
            if m:
                case = m.group(1)
            sm = re.search(r"spec_ref:\s*(\S+)", line)
            if sm and case:
                for row in _rows_for(sm.group(1).strip("'\"")):
                    if row in want:
                        hits.append(case)
        if hits:
            out[repo_relative(path, REPO)] = sorted(set(hits))
    return out


def impact(pack, rows):
    """The whole chain for `rows`, as data."""
    rows = sorted({r.strip() for r in rows if r.strip()})
    recs = records_citing(pack, rows)
    blocks = sorted({b for r in recs for b in r["blocks"]})
    columns = sorted({r["column"] for r in recs if r["column"]})
    caps, cap_note = capabilities_for(blocks)

    product = os.path.join(REPO, pack)
    governed = set()
    try:
        governed = set(cb.governed_blocks(product, cb.pack_yaml(product)))
    except Exception:  # noqa: BLE001 - unreadable cover -> report the blocks unqualified
        pass
    cited = {r for rec in recs for r in rec["rows"]}
    return {
        "product": pack,
        "rows": rows,
        # THE FINDING, not an empty result: a moved row nothing cites is either unimplemented or
        # missing its citation, and both look like "no impact" in a report that prints nothing.
        "rows_no_record_cites": [r for r in rows if r not in cited],
        "records": recs,
        "blocks": blocks,
        # A block a record names that the BUILD does not read is a separate defect, surfaced here
        # rather than silently included in the impact set.
        "blocks_not_governed": sorted(b for b in blocks if governed and b not in governed),
        "output_columns": columns,
        "capabilities": caps,
        "capability_note": cap_note,
        "goldens_to_rerun": goldens_citing(rows),
    }


def render(pack, rows):
    d = impact(pack, rows)
    L = [f"# Change impact — {pack}", "",
         f"**{len(d['rows'])} specification row(s):** " + ", ".join(f"`{r}`" for r in d["rows"]), "",
         "What the change TOUCHES. It does not say whether the change is safe — it says what is now",
         "unverified, so 'we re-ran everything affected' can be checked instead of recalled.", ""]

    if d["rows_no_record_cites"]:
        L += ["> **" + ", ".join(f"`{r}`" for r in d["rows_no_record_cites"]) +
              "** — NO contract record cites this row. Either it is not implemented, or a citation",
              "> is missing. Both are answers; neither is 'no impact'.", ""]

    if not d["records"]:
        L += ["No contract record cites any of these rows, so nothing below can be derived.", ""]
        return "\n".join(L)

    L += [f"## records — {len(d['records'])}", "",
          "| variable | rows | requirement | published column |", "|---|---|---|---|"]
    for r in d["records"]:
        L.append(f"| `{r['variable_id']}` | {', '.join(r['rows'])} | {r['requirement'] or '—'} | "
                 f"{r['column'] or '—'} |")

    L += ["", f"## config blocks — {len(d['blocks'])}", ""]
    L += [f"  - `{b}`" for b in d["blocks"]] or ["  (none — these records implement nothing)"]
    if d["blocks_not_governed"]:
        L += ["", "**Named by a record but NOT read by the build:** " +
              ", ".join(f"`{b}`" for b in d["blocks_not_governed"])]

    if d["capability_note"]:
        L += ["", f"## capabilities — NOT DETERMINED ({d['capability_note']})"]
    else:
        L += ["", f"## capabilities — {len(d['capabilities'])}", "",
              "Matched on the config FILE, so this is deliberately wider than the block list: for a",
              '"what must be re-checked" report, over-inclusion is the safe direction.', ""]
        for cid, keys in sorted(d["capabilities"].items()):
            L.append(f"  - `{cid}` — {', '.join(keys)}")

    L += ["", f"## published output columns — {len(d['output_columns'])}", ""]
    L += ["  " + (", ".join(f"`{c}`" for c in d["output_columns"]) or "(none)")]

    L += ["", "## goldens to re-run", ""]
    if d["goldens_to_rerun"]:
        L += ["A golden is the only artifact stating an EXPECTED clinical value, so a moved row it",
              "cites may have invalidated the expectation itself.", ""]
        for path, cases in sorted(d["goldens_to_rerun"].items()):
            L.append(f"  - `{path}` — {', '.join(cases)}")
    else:
        L += ["  No golden case cites these rows. That is not reassurance: it may mean the rows",
              "  are untested rather than unaffected."]
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("product", help="path to a product pack")
    ap.add_argument("rows", nargs="*", help="changed specification rows, e.g. clinical:12")
    ap.add_argument("--changed-file", help="a file of changed rows, one per line")
    ap.add_argument("--json", action="store_true", help="machine-readable, to STDOUT")
    a = ap.parse_args(argv)

    rows = list(a.rows)
    if a.changed_file:
        with open(a.changed_file, encoding="utf-8") as fh:
            rows += [ln.strip() for ln in fh if ln.strip() and not ln.startswith("#")]
    if not rows:
        sys.exit("no changed rows given — pass them as arguments or via --changed-file")

    pack = repo_relative(os.path.abspath(a.product), REPO)
    if not os.path.isdir(os.path.join(REPO, pack)):
        sys.exit(f"{a.product}: not a product pack directory")
    print(json.dumps(impact(pack, rows), indent=2) if a.json else render(pack, rows))
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
