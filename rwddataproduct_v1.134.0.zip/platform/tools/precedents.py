#!/usr/bin/env python3
"""Questions that have come up before, and where they were answered.

    python3 platform/tools/precedents.py            # the store, with each citation's LIVE status
    python3 platform/tools/precedents.py --check    # CI: every citation still resolves

ADVISORY, and deliberately powerless. It reads `governance/precedents.yaml`, which no gate reads and
which cannot make a pack releasable, resolve a decision or approve a record. Its whole job is to stop
the next product re-arguing a question from scratch without knowing other packs have settled it.

IT STORES NO ANSWERS. Each entry cites (pack, decision id); the question wording, the status and the
agreed answer are read from that pack's `handoff/DECISIONS.md` at display time, through
`contract_lint.decision_rows` — the ONE reader of that table. A copied answer would be a second copy
of a governed fact, agreeing today and free to diverge the moment somebody edits one side. A pointer
cannot go stale; it can only stop resolving, which `--check` turns red.

stdlib only (plus PyYAML, via product_gates.read_yaml).
"""
import argparse
import collections
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)
from spec_extract import repo_relative                                  # noqa: E402

from contract_lint import (decision_answer, decision_approval_date,      # noqa: E402
                           decision_approver, decision_rows, decision_status, read)
from product_gates import products, read_yaml, registry_entry  # noqa: E402

STORE = os.path.join("governance", "precedents.yaml")
MIN_SIGHTINGS = 2  # one sighting is a decision, not a precedent
MIN_TUMOURS = 2    # ...and one TUMOUR repeating itself is not recurrence, see source_key_precedents


def _slug(pack):
    """The tumour a pack belongs to, or "" when the path does not name one.

    A pack lives at products/<family>/[<grouping>/…]<slug>/<version> and is discovered by SHAPE at
    any depth (`product_gates.products`), so the tumour is the segment ABOVE the version — not a
    fixed offset. `parts[2]` answered the GROUPING level for a pack one level deeper, which merges
    two tumours into one: `products/oncology/gu/prostate/…` and `products/oncology/gu/bladder/…`
    would corroborate each other, and nothing would say so.

    A path that is not under `products/` has NO tumour, and "" is the fail-closed answer rather than
    whatever segment sits at that offset. `platform/tests/fixtures/prostate_202607` is a parked spec
    revision the store used to cite; read positionally it answered `fixtures`, which turned seven
    single-tumour entries into corroborated ones — evidence manufactured by moving a directory.

    That was only half the problem, and `errors()` closes the other half: it no longer counts as a
    SIGHTING either. A directory the tests own is not evidence that a real programme hit a question,
    however carefully a human read it, and it was satisfying the two-sighting floor for seven of the
    nine entries this store used to hold. Those seven are gone; the decisions they cited are still
    in prostate/202606's own register, which is where a question one pack has asked belongs.
    """
    parts = [p for p in (pack or "").replace(os.sep, "/").strip("/").split("/") if p]
    if len(parts) < 4 or parts[0] != "products":
        return ""
    return parts[-2]


def tumours(entry):
    """The distinct TUMOURS an entry has been seen in — not the packs.

    Two revisions of one tumour re-raising a question is one programme's specification being read
    twice, which is much weaker evidence that a DIFFERENT tumour will hit it than two tumours
    hitting it independently.

    The two halves of this store treat that differently, ON PURPOSE, and the difference is worth
    keeping straight. The source-key half REFUSES single-tumour recurrence outright: `psa` and
    `provenge` appear in two prostate configs because the second was written from the first, which
    is not evidence of anything. The decision half KEEPS it and LABELS it — `reach` is an axis, not
    a filter — because a human had to read two registers and judge that two differently-worded
    decisions are one question, and that judgment is itself evidence worth a reader's attention
    before a second tumour corroborates it. What is not acceptable is showing both kinds as though
    they were equally proven.

    Today no entry is single-tumour, because the only thing that made one was a test fixture and
    `errors()` now refuses those. A real two-revision recurrence — prostate 202603 and 202606 both
    arguing one question out — would still be recorded, and still labelled `single_tumour`.
    """
    return {_slug(s.get("pack")) for s in (entry.get("seen_in") or []) if _slug(s.get("pack"))}


def corroboration(entry):
    """A label stating how far an entry's evidence actually reaches."""
    t = sorted(tumours(entry))
    if len(t) >= MIN_TUMOURS:
        return f"corroborated across {len(t)} tumours: {', '.join(t)}"
    return f"{len(t)} tumour so far ({', '.join(t) or 'none'}) — not yet corroborated"


# --- strength: TWO AXES, reported separately ------------------------------------------------------
# Conflating them is how an advisory store starts reading as a rulebook — and the single tier this
# replaces DID conflate them. `single_tumour` short-circuited the grade, so an entry answered and
# signed inside one programme rendered identically to one still open inside one programme: the
# reader was handed the weaker fact and the stronger one was computed and thrown away.
#
# REACH is how far the evidence travels. One tumour raising a question twice is one programme's
# specification read twice; two tumours hitting it independently is recurrence. `corroboration()`
# is the same axis in prose, naming the tumours.
#
# AUTHORITY is what stands behind the ANSWERS. All-open is a shared question; answered-but-unsigned
# is a shared answer with nobody accountable for it; answered-and-signed is precedent in the sense
# the word implies. An external review named the unsigned-resolution problem in the knowledge graph;
# it is the same problem here, one layer up.
#
# THEY ARE INDEPENDENT, and that is why they are two values and not one. A signed answer inside one
# programme has full authority and no reach. A question open across three tumours has full reach and
# no authority. Neither fact substitutes for the other, and both print on every entry, always.
#
# Both are COMPUTED from the live registers, never stored. A hand-typed grade would be a claim about
# someone else's register, free to say `ruling` about a row with an empty approver column — the exact
# shape of the defect this grades.
#
# `ruled` is imported from knowledge_graph rather than re-derived: one definition of "signed", in one
# place, or the two surfaces disagree about the same row.
REACH = (
    ("multi_tumour", "seen in two or more DIFFERENT tumours' programmes — the only reach that is "
                     "evidence a further tumour will hit the same question"),
    ("single_tumour", "seen only within ONE tumour's programme, however well answered. One "
                      "specification read twice is not evidence that a different tumour will hit "
                      "it"),
)
AUTHORITY = (
    ("ruling", "answered and SIGNED in every pack that hit it — the only grade that is authority "
               "rather than evidence"),
    ("answer", "answered everywhere it was hit, but at least one answer carries no named approver "
               "or no usable approval date — reusable as evidence to show an answerer, never as a "
               "ruling"),
    ("partial", "answered in some packs and still open in others — the answer exists, and whether "
                "it settled the question is not established"),
    ("question", "open everywhere it has been seen — a question you should expect, with no answer "
                 "behind it yet"),
    ("unresolvable", "at least one citation no longer resolves to a decision in its register"),
)
REACH_NAMES = tuple(name for name, _ in REACH)
AUTHORITY_NAMES = tuple(name for name, _ in AUTHORITY)

Strength = collections.namedtuple("Strength", "reach authority")


def reach(entry):
    """How far this entry's evidence travels, as a token. `corroboration()` says the same in prose."""
    return "multi_tumour" if len(tumours(entry)) >= MIN_TUMOURS else "single_tumour"


def authority(entry, root=ROOT, cache=None):
    """What stands behind this entry's ANSWERS, computed from the live registers.

    Reach is deliberately NOT consulted here. Whether two tumours hit a question and whether the
    answers were signed are separate observations, and a grader that let one silence the other is
    what this replaced.

    `unresolvable` still wins over the rest, and for a different reason: an entry pointing at a
    decision that no longer exists cannot be graded on the answers it claims to have at all.
    """
    sys.path.insert(0, TOOLS)
    from knowledge_graph import ruled                                   # noqa: PLC0415
    cache = {} if cache is None else cache

    states = []
    for s in (entry.get("seen_in") or []):
        pack, did = s.get("pack"), s.get("decision")
        if not pack or not did or not os.path.isdir(os.path.join(root, pack)):
            return "unresolvable"
        if pack not in cache:
            cache[pack] = register(root, pack)
        rows, status = cache[pack]
        if did not in rows:
            return "unresolvable"
        row = rows[did]
        states.append({"status": str(status.get(did, "")).strip().upper(),
                       "approved_by": decision_approver(row).strip(),
                       "approval_date": decision_approval_date(row).strip()})

    resolved = [n for n in states if n["status"] == "RESOLVED"]
    if not resolved:
        return "question"
    if len(resolved) < len(states):
        return "partial"
    return "ruling" if all(ruled(n) for n in resolved) else "answer"


def strength(entry, root=ROOT, cache=None):
    """(reach, authority) — both axes, never collapsed into one."""
    return Strength(reach(entry), authority(entry, root, cache))


def _by_strength(entry, root=ROOT, cache=None):
    """Reach first, then authority, then alphabetical. A reader works down the list, so what is
    actually settled belongs at the top of it — and what merely LOOKS settled must not sit there.

    REACH leads because the list answers one question — "will THIS tumour hit it" — and that is the
    axis which speaks to it: a signed answer inside somebody else's single programme is authority
    about a question this product may never face.

    A broken citation sinks below both axes rather than being ranked on them. `--check` refuses a
    store containing one, so this only ever fires on a store already known to be red; ranking it on
    an authority it cannot have would put it above sound entries on reach alone.
    """
    s = strength(entry, root, cache)
    broken = 1 if s.authority == "unresolvable" else 0
    return (broken,
            REACH_NAMES.index(s.reach) if s.reach in REACH_NAMES else len(REACH_NAMES),
            AUTHORITY_NAMES.index(s.authority) if s.authority in AUTHORITY_NAMES
            else len(AUTHORITY_NAMES),
            entry.get("id", ""))


def _vendor(root, pack):
    """The pack's vendor, from the registry. None when it has no entry — and None means PROPOSE
    NOTHING. A source key is only evidence within a delivery: Flatiron's packs all declare
    `practice`, `ses`, `telemed` and `vitals`, and neither COTA pack declares any of them, so
    guessing a vendor would propose four tables that do not exist."""
    return (registry_entry(root, pack) or {}).get("vendor")


def _declared(root, pack):
    """The source keys a pack's config declares. Empty when there is no config, or it cannot be
    read — which makes every key a proposal, the safe direction for an advisory tool."""
    doc, err = read_yaml(os.path.join(root, pack, "config", "data_product.yaml"))
    src = (doc or {}).get("sources") if not err and isinstance(doc, dict) else None
    return set(src) if isinstance(src, dict) else set()


def source_key_precedents(root=ROOT):
    """{vendor: {source key: {tumour slug: [packs]}}} — DERIVED, and deliberately not stored.

    The decision half of this store exists because nothing mechanical can pair `FUED-DEFINITION`
    with `OC-FU-END-DEFINITION`; that pairing is the whole content of the YAML. Here the opposite
    holds: `demographics` in prostate's config and `demographics` in ovarian's are the SAME STRING,
    so recurrence is computable exactly and writing it down by hand would be a second copy of
    something already in the configs — stale the first time a pack adds a source.

    THE VENDOR EVIDENCE IS CONFOUNDED, and whoever changes this scoping should know it. Every
    Flatiron entry in the registry is `tumor_class: solid` and every COTA entry is `heme`, so the
    observation this scoping rests on — all four Flatiron packs declare `practice`, `ses`, `telemed`
    and `vitals`, neither COTA pack declares any — is equally consistent with "source keys do not
    cross VENDORS" and with "source keys do not cross SOLID/HEME". The data cannot separate them,
    and scoping on vendor may be right for the wrong reason.
    Do NOT add tumour-class scoping on top: it would double the machinery on a hypothesis with no
    supporting evidence, and `practice` would then be withheld from COTA for two reasons where at
    most one is real. The first Flatiron heme product, or COTA solid product, settles it — check
    then rather than assuming the answer is vendor. test_precedents.py carries a tripwire that fires
    on the first such pack.

    WHAT THIS DOES NOT CARRY: the physical table names. They are not stable even within one vendor
    (`t_demographics` in prostate, `t_meg_demographics` in ovarian; mortality differs in all three
    Flatiron packs), and confirming that a physical table is the RIGHT one needs a profile and a
    human at Gate 3. Proposing one would be guessing precisely what the framework refuses to guess.
    What carries across a vendor's tumours is WHICH SOURCES A PACK NEEDS, not what they are called.
    """
    out = {}
    for pack in sorted(products(root)):
        vendor = _vendor(root, pack)
        if not vendor:
            continue
        slug = _slug(pack)
        for key in _declared(root, pack):
            out.setdefault(vendor, {}).setdefault(key, {}).setdefault(slug, []).append(pack)
    return out


def source_key_proposals(pack, root=ROOT):
    """(vendor, [(key, {slug: [packs]})]) — keys this pack does not declare that OTHER TUMOURS on
    the same vendor do.

    Counted in distinct TUMOURS, not packs, and that is the lesson the decision half taught: two
    revisions of one tumour repeating themselves is the same specification being re-read, not
    evidence of anything general. Counting packs would propose `psa` and `provenge` — declared by
    prostate 202603 and 202606 — to an endometrial analyst.
    """
    vendor = _vendor(root, pack)
    if not vendor:
        return None, []
    mine = _declared(root, pack)
    slug = _slug(pack)
    todo = []
    # NOT named `tumours`: that is a module-level function now, and shadowing it here would leave
    # any later call in this scope reaching for a dict.
    for key, by_tumour in source_key_precedents(root).get(vendor, {}).items():
        if key in mine:
            continue
        others = {s: ps for s, ps in by_tumour.items() if s != slug}
        if len(others) >= MIN_TUMOURS:
            todo.append((key, others))
    return vendor, sorted(todo)


def version_drift(pack, root=ROOT):
    """{source key: [other packs]} — keys ANOTHER VERSION OF THIS TUMOUR declares and this one does not.

    A DIFFERENT QUESTION from precedent, and reported apart from it. Precedent asks what other
    TUMOURS have needed; this asks what this product's own other versions declare. The proposals
    above deliberately exclude the pack's own tumour — that exclusion is what stops `psa` and
    `provenge` being offered to an endometrial analyst — but on prostate/202606 it also hid the most
    actionable fact available: 202603 declares `ecog` and 202606 does not.

    Reported in ONE direction only, the absent one. A version that ADDS sources is the ordinary
    shape of a new spec revision (202606 adds five), so listing those would bury the one line worth
    reading under four that are not.

    It deliberately does NOT decide which version is earlier. Ordering CalVer folders looks safe
    until a pack is named `YYYYMM`, and the answer would then be asserted rather than observed —
    the packs are named in the output and a person can see which is which. Nor does it say whether
    the difference is a deliberate removal or a regression: the tool cannot tell, and only one of
    those is fine.
    """
    slug, mine, out = _slug(pack), _declared(root, pack), {}
    for other in sorted(products(root)):
        if other == pack or _slug(other) != slug:
            continue
        for key in sorted(_declared(root, other) - mine):
            out.setdefault(key, []).append(other)
    return out


def load(root=ROOT):
    """(entries, errors). A malformed store is an empty one — never a partial one."""
    doc, err = read_yaml(os.path.join(root, STORE))
    if err:
        return [], [f"{STORE}: {err}"]
    entries = doc.get("precedents") or []
    if not isinstance(entries, list):
        return [], [f"{STORE}: `precedents` must be a list"]
    return entries, []


def register(root, pack):
    """(decision rows, statuses) for a pack — through the ONE reader of that table."""
    text = read(os.path.join(root, pack, "handoff", "DECISIONS.md"))
    return decision_rows(text), decision_status(text)


def errors(root=ROOT):
    """Everything wrong with the store, as a list of sentences.

    A citation that no longer resolves is the failure this exists to catch: a decision id gets
    renamed, or a pack is restructured, and the store quietly starts pointing at nothing while still
    printing a confident-looking precedent.
    """
    entries, out = load(root)
    seen_ids = set()
    cache = {}
    for i, e in enumerate(entries):
        where = f"{STORE}[{i}]"
        pid = e.get("id")
        if not pid:
            out.append(f"{where}: no `id`")
            continue
        if pid in seen_ids:
            out.append(f"{where}: duplicate id {pid!r}")
        seen_ids.add(pid)
        if not (e.get("question") or "").strip():
            out.append(f"{pid}: no `question`")
        # A stored strength would be a CLAIM about someone else's register — free to say `ruling`
        # about a row whose approver column is empty, which is exactly the defect the tier grades.
        # The tier is computed from the live registers or it is worthless.
        for banned in ("strength", "tier", "authority", "reach"):
            if banned in e:
                out.append(f"{pid}: carries `{banned}` — reach and authority are COMPUTED from the "
                           f"live registers, never stored. A stored one is a claim about a register "
                           f"this file does not own, and it is the grade's whole job to catch that")

        sightings = e.get("seen_in") or []
        # A FIXTURE IS NOT EVIDENCE. `platform/tests/fixtures/prostate_202607` is a parked spec
        # revision the test suite owns, and it was satisfying the two-sighting floor: seven of the
        # nine entries this store used to hold rested on one real prostate pack plus that fixture.
        # Stopping it counting as a second TUMOUR was half the fix — it still counted as a second
        # SIGHTING, so the floor was met by a directory whose purpose is to be edited by tests.
        #
        # `products()` is the ONE definition of a governed pack, and it is the same function every
        # gate discovers packs with. A second rule here — "under products/", say — would let the two
        # disagree, and the disagreement would show up as a precedent nothing else considered real.
        governed = set(products(root))
        for s in sightings:
            if isinstance(s, dict) and s.get("pack") and s["pack"] not in governed:
                out.append(f"{pid}: cites {s['pack']}, which is not a governed product pack. A "
                           f"precedent is evidence that REAL programmes hit a question; a fixture "
                           f"or sandbox copy is a file the tests own, and it satisfied the "
                           f"{MIN_SIGHTINGS}-sighting floor without any product having asked.")
        # DISTINCT (pack, decision) PAIRS, or the two-sighting floor is satisfiable by writing one
        # sighting twice. The floor exists to mean "more than one pack hit this"; a duplicate is one
        # pack hit once, recorded twice, and it would read as corroboration in every rendering.
        pairs = [(s.get("pack"), s.get("decision")) for s in sightings if isinstance(s, dict)]
        dupes = sorted({p for p in pairs if pairs.count(p) > 1})
        for pack, did in dupes:
            out.append(f"{pid}: cites {pack} {did} more than once — the {MIN_SIGHTINGS}-sighting "
                       f"floor means more than one PACK hit this question, and a repeated pair is "
                       f"one pack recorded twice")
        # COUNTED ON GOVERNED PACKS, so the ungoverned-citation error above is not the only thing
        # standing between a fixture and the floor. Reported as two errors on purpose: one says the
        # citation does not belong, the other says what the entry has left without it.
        gov_pairs = {p for p in pairs if p[0] in governed}
        if len(set(pairs)) < MIN_SIGHTINGS <= len(sightings):
            out.append(f"{pid}: {len(sightings)} sighting(s) but only {len(set(pairs))} distinct "
                       f"(pack, decision) pair(s)")
        if len(gov_pairs) < MIN_SIGHTINGS:
            out.append(f"{pid}: {len(gov_pairs)} sighting(s) in governed product packs — a "
                       f"precedent needs at least {MIN_SIGHTINGS}. One pack asking a question is a "
                       f"decision, and it belongs in that pack's own register, not here.")
        for s in sightings:
            pack, did = s.get("pack"), s.get("decision")
            if not pack or not did:
                out.append(f"{pid}: a sighting is missing `pack` or `decision`")
                continue
            if not os.path.isdir(os.path.join(root, pack)):
                out.append(f"{pid}: cites pack {pack}, which does not exist")
                continue
            if pack not in cache:
                cache[pack] = register(root, pack)
            rows, _ = cache[pack]
            if did not in rows:
                out.append(f"{pid}: cites {pack} decision {did!r}, which is not in its register")
    return out


def render(root=ROOT):
    entries, bad = load(root)
    lines = []
    if bad:
        lines += bad + [""]
    lines.append(f"{len(entries)} precedent(s) — questions seen on more than one pack.")
    lines.append("ADVISORY: no gate reads this. Statuses below are read live from each register.")
    lines.append("")
    cache = {}
    tiers = {e.get("id"): strength(e, root, cache) for e in entries}
    lines.append("  TWO AXES, computed from the live registers and never stored. They are")
    lines.append("  independent: neither one substitutes for the other.")
    lines.append("")
    for axis, table, pick in (("REACH — how far the evidence travels", REACH, lambda s: s.reach),
                              ("AUTHORITY — what stands behind the answers", AUTHORITY,
                               lambda s: s.authority)):
        lines.append(f"    {axis}:")
        for name, meaning in table:
            n = sum(1 for v in tiers.values() if pick(v) == name)
            lines.append(f"      {name:14} {n:>2}  {meaning}")
        lines.append("")
    if not any(v.authority == "ruling" for v in tiers.values()):
        lines.append("      NONE of these is a ruling. Every answer they rest on is either open or")
        lines.append("      unsigned, so they are questions to expect and evidence to show an")
        lines.append("      answerer — never authority to cite.")
    lines.append("")
    for e in sorted(entries, key=lambda x: _by_strength(x, root, cache)):
        sightings = e.get("seen_in") or []
        s = tiers.get(e.get("id"))
        lines.append(f"  {e.get('id', '?')}")
        lines.append(f"      [reach: {s.reach if s else '?'}] [authority: {s.authority if s else '?'}]")
        lines.append(f"      {corroboration(e)}")
        lines.append(f"      {' '.join((e.get('question') or '').split())}")
        for s in sightings:
            pack, did = s.get("pack", "?"), s.get("decision", "?")
            if pack not in cache and os.path.isdir(os.path.join(root, pack)):
                cache[pack] = register(root, pack)
            rows, status = cache.get(pack, ({}, {}))
            if did not in rows:
                lines.append(f"      !! {pack}  {did}  — DOES NOT RESOLVE")
                continue
            answer = decision_answer(rows[did]) or ""
            lines.append(f"      {status.get(did, '?'):9} {pack}  {did}")
            if status.get(did) == "RESOLVED" and answer.strip():
                lines.append(f"                → {' '.join(answer.split())[:150]}")
        lines.append("")
    return "\n".join(lines)


def propose(pack, root=ROOT):
    """The precedents not yet recorded against `pack` — questions to expect, in its own words later.

    "Not yet recorded" means this pack does not appear in the entry's `seen_in`, and NOTHING CLEVERER.
    No matching of the pack's own decision wording against the store's: two registers phrase the same
    question differently on purpose (`PRACTICE-MISSING-CODE` vs `PRACTICE-NO-RECORD`), so any matcher
    good enough to pair those is also good enough to pair two questions that merely sound alike.

    The error it can make is therefore proposing something the pack has already argued out — which
    costs a reader ten seconds — rather than staying silent about something it has not, which would
    make the store actively misleading. It over-proposes, on purpose, and a person closes the loop by
    adding the sighting.
    """
    entries, bad = load(root)
    covered, todo = [], []
    for e in entries:
        packs = {s.get("pack") for s in (e.get("seen_in") or [])}
        (covered if pack in packs else todo).append(e)
    return covered, todo, bad


def _drift_lines(pack, root):
    """The version-drift section. Its own block, because it answers a different question from
    everything above it and running the two together would read as one list of proposals.

    A pack that declares NOTHING is handled apart from one that has diverged, because NOT STARTED
    and REGRESSED are different states and only one of them is a defect. prostate/202607 has no
    `config/` at all (`configuration: not_started`), so every key its siblings declare counted as
    drift: twenty-one entries, sixteen of them already listed as proposals immediately above, under
    a heading that told the reader the tool could not distinguish a removal from a regression — when
    nothing had been removed. Forty lines to say "there is no config yet".
    """
    drift = version_drift(pack, root)
    if not drift:
        return []
    L = ["", "  " + "-" * 74,
         "  VERSION DRIFT — this tumour's OTHER versions, not a precedent",
         "  " + "-" * 74]

    if not _declared(root, pack):
        _, proposed = source_key_proposals(pack, root)
        already = {k for k, _ in proposed}
        # Only what the checklist above does NOT already carry. On a pack with no config the two
        # lists otherwise overlap almost entirely, and the part worth reading is the remainder:
        # the sources only this product has ever needed, which no other tumour will propose.
        extra = {k: v for k, v in drift.items() if k not in already}
        L += ["  This pack declares no sources at all, so nothing has DRIFTED — there is no",
              "  config/ for anything to have drifted from. Not started and regressed are",
              "  different states, and only one of them is a defect.", ""]
        if not extra:
            L.append("  Every source its other versions declare is already in the checklist above.")
            return L
        L += [f"  Its other versions declare {len(drift)} key(s); {len(drift) - len(extra)} are already in that",
              f"  checklist. The remaining {len(extra)} are sources only THIS product has ever needed,",
              "  which no other tumour would propose:", ""]
        for key, packs in sorted(extra.items()):
            L.append(f"    ! {key:18} {', '.join(packs)}")
        return L

    L += [f"  {len(drift)} source key(s) another version of this product declares and this one does",
          "  not:", ""]
    for key, packs in sorted(drift.items()):
        L.append(f"    ! {key:18} {', '.join(packs)}")
    L += ["",
          "  This is NOT precedent — precedent is what OTHER tumours needed, and the proposals",
          "  above exclude this tumour on purpose. It is reported because that exclusion also hid",
          "  the most actionable thing here. The tool does not say which version came first, and",
          "  cannot tell a deliberate removal from a regression. Only one of those is fine."]
    return L


def render_proposals(pack, root=ROOT):
    covered, todo, bad = propose(pack, root)
    cache = {}
    L = list(bad) + ([""] if bad else [])
    L.append(f"PRECEDENTS FOR {pack}")
    L.append("")
    todo = sorted(todo, key=lambda x: _by_strength(x, root, cache))
    strong = [e for e in todo if len(tumours(e)) >= MIN_TUMOURS]
    if todo:
        L.append(f"  {len(todo)} question(s) other packs have raised that are not yet recorded here:")
        L.append(f"      {len(strong)} corroborated across two or more tumours,")
        L.append(f"      {len(todo) - len(strong)} raised by one tumour so far — weaker evidence that")
        L.append("        THIS tumour will hit it, and listed second for that reason.")
    else:
        L.append("  Nothing to propose — every precedent in the store already cites this pack.")
    L.append(f"  {len(covered)} already recorded against this pack.")
    L.append("")
    # The preamble explains the list below it. Printed over an EMPTY list — which is exactly what
    # the pack that seeded the store gets — it was four paragraphs introducing nothing.
    if todo:
        L.append("  These are QUESTIONS TO EXPECT — not answers to copy. Each one was settled (or is")
        L.append("  still open) against a different tumour's specification, and the ANSWER is almost")
        L.append("  always different; what carries over is that the question needs asking, and that")
        L.append("  somebody has already worked out what makes it hard.")
        L.append("")
    for e in todo:
        s = strength(e, root, cache)
        L.append(f"  ☐ {e.get('id', '?')}")
        L.append(f"      [reach: {s.reach}] [authority: {s.authority}]  {corroboration(e)}")
        L.append(f"      {' '.join((e.get('question') or '').split())}")
        for s in (e.get("seen_in") or []):
            p, did = s.get("pack", "?"), s.get("decision", "?")
            if p not in cache and os.path.isdir(os.path.join(root, p)):
                cache[p] = register(root, p)
            _, status = cache.get(p, ({}, {}))
            L.append(f"        seen: {p}  {did}  [{status.get(did, '?')}]")
        L.append("")
    if covered:
        L.append("  Already recorded against this pack:")
        for e in covered:
            L.append(f"    ☑ {e.get('id', '?')}")
        L.append("")
    if todo:
        L.append("  Nothing here is an approval, and nothing here resolves anything. Raising one of")
        L.append("  these in the pack's own handoff/DECISIONS.md, in that specification's own terms,")
        L.append("  is the human step — then add the sighting so the next product sees it too.")

    vendor, keys = source_key_proposals(pack, root)
    L.append("")
    L.append("  " + "-" * 74)
    L.append("  SOURCE KEYS — derived from the configs, not stored")
    L.append("  " + "-" * 74)
    if not vendor:
        L.append("  This pack has no registry entry, so its vendor is unknown and nothing is")
        L.append("  proposed. A source key is only evidence within one vendor's delivery.")
        return "\n".join(L + _drift_lines(pack, root))
    if not keys:
        # "You have everything" and "there is not enough evidence yet" are different answers, and
        # only one of them is reassuring. With two COTA packs in the repo, any COTA pack has exactly
        # one other tumour to compare against — never the two a precedent needs — so a bare "you
        # already declare everything" would read as a clean bill of health where nothing was checked.
        slug = _slug(pack)
        peers = {s for k in source_key_precedents(root).get(vendor, {}).values() for s in k} - {slug}
        if len(peers) < MIN_TUMOURS:
            L.append(f"  Vendor {vendor}: only {len(peers)} other tumour(s) here to compare against"
                     f" ({', '.join(sorted(peers)) or 'none'}).")
            L.append(f"  A source-key precedent needs {MIN_TUMOURS}, so nothing is proposed — that is")
            L.append("  a lack of evidence, not a clean bill of health.")
        else:
            L.append(f"  Vendor {vendor}: this pack already declares every source key that two or")
            L.append(f"  more other {vendor} tumours declare.")
        return "\n".join(L + _drift_lines(pack, root))
    L.append(f"  {len(keys)} source key(s) that 2+ other {vendor} tumours declare and this pack")
    L.append("  does not. Sources a product of this kind has needed before:")
    L.append("")
    for key, others in keys:
        who = ", ".join(f"{s} ({len(ps)})" for s, ps in sorted(others.items()))
        L.append(f"    ☐ {key:18} {who}")
    L.append("")
    L.append("  The PHYSICAL TABLE for each is deliberately not proposed. It is not stable even")
    L.append("  within a vendor, and confirming one is the right table needs a profile and a human")
    L.append("  at Gate 3 — exactly the judgment this framework refuses to guess.")
    return "\n".join(L + _drift_lines(pack, root))


ID_SHAPE = re.compile(r"^[a-z][a-z0-9]*(?:-[a-z0-9]+)+$")   # kebab-case, at least two words


def add_sighting(entry_id, sightings, question=None, root=ROOT):
    """(what changed, errors, new store text or None) — append to the store WITHOUT rewriting it.

    The store went stale because appending meant hand-editing YAML: seven of nine entries read
    "prostate, prostate" while the ovarian register answered the same questions under its own ids.
    This is the write side, under the store's own rules rather than around them:

      * every citation is validated through the SAME live path `--check` walks — the pack's
        register is read and the decision id must resolve — so a typo cannot enter as a pointer
        that never resolved;
      * a NEW entry (`question` given) requires TWO OR MORE sightings in one act: one sighting is
        a decision, not a precedent, and MIN_SIGHTINGS is not this function's to relax;
      * an EXISTING entry takes one validated sighting; a (pack, decision) it already cites is
        refused, not doubled;
      * the edit is comment-preserving TEXT insertion, never a yaml.dump round-trip — the store's
        comments are its governance content, and a serializer would delete every one of them.

    The result must still load and pass the store's own `errors()` before it is returned; anything
    less returns nothing.
    """
    path = os.path.join(root, STORE)
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    entries, load_errs = load(root)
    if load_errs:
        return [], load_errs, None
    by_id = {e.get("id"): e for e in entries}

    problems = []
    for pack, decision in sightings:
        reg_path = os.path.join(root, pack, "handoff", "DECISIONS.md")
        if not os.path.exists(reg_path):
            problems.append(f"{pack} keeps no handoff/DECISIONS.md — a citation must point at a "
                            f"register that exists")
            continue
        rows, _status = register(root, pack)
        if decision not in rows:
            problems.append(f"{pack} has no decision {decision!r} — a pointer that never resolved "
                            f"is worse than none. Check the id against that register.")

    if question is not None:                                        # a NEW entry
        if entry_id in by_id:
            problems.append(f"{entry_id!r} already exists — add sightings to it with --key instead")
        if not ID_SHAPE.match(entry_id or ""):
            problems.append(f"{entry_id!r} is not a kebab-case question id (see the store's ENTRY "
                            f"REQUIREMENTS: it names the QUESTION, never a tumour or a variable)")
        if len(set(sightings)) < MIN_SIGHTINGS:
            problems.append(f"a new entry needs {MIN_SIGHTINGS}+ distinct (pack, decision) "
                            f"citations in one act — one sighting is a decision, not a precedent")
        if problems:
            return [], problems, None
        lines = [f"  - id: {entry_id}",
                 "    question: >"]
        lines += [f"      {l}" for l in _wrap_text(question)]
        lines.append("    seen_in:")
        lines += [f"      - {{ pack: {p}, decision: {d} }}" for p, d in sightings]
        new_text = text.rstrip("\n") + "\n\n" + "\n".join(lines) + "\n"
        changed = [f"new entry {entry_id} with {len(sightings)} sighting(s)"]
    else:                                                           # ONE sighting on an EXISTING one
        entry = by_id.get(entry_id)
        if entry is None:
            problems.append(f"no entry {entry_id!r} in the store — create one with --new, which "
                            f"needs {MIN_SIGHTINGS}+ citations")
        elif len(sightings) != 1:
            problems.append("--key takes exactly one --pack/--decision pair per run")
        else:
            pack, decision = sightings[0]
            cited = {(s.get("pack"), s.get("decision")) for s in (entry.get("seen_in") or [])}
            if (pack, decision) in cited:
                problems.append(f"{entry_id} already cites ({pack}, {decision}) — nothing to add")
        if problems:
            return [], problems, None
        pack, decision = sightings[0]
        m = re.search(rf"(?ms)^(\s*)- id:\s*{re.escape(entry_id)}\s*$.*?^\s*seen_in:\s*\n"
                      rf"((?:\s*- \{{[^\n]*\}}\n)+)", text)
        if not m:
            return [], [f"could not locate {entry_id}'s seen_in block as text — the store's layout "
                        f"changed; add the citation by hand"], None
        block = m.group(2)
        last = block.rstrip("\n").splitlines()[-1]
        indent = last[:len(last) - len(last.lstrip())]
        new_line = f"{indent}- {{ pack: {pack}, decision: {decision} }}\n"
        new_text = text[:m.end(2)] + new_line + text[m.end(2):]
        changed = [f"{entry_id} + ({pack}, {decision})"]

    # the result must still be a store: parse it and run the SAME checks --check runs
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        trial = os.path.join(tmp, "root")
        os.makedirs(os.path.join(trial, os.path.dirname(STORE)))
        with open(os.path.join(trial, STORE), "w", encoding="utf-8", newline="\n") as fh:
            fh.write(new_text)
        doc, err = read_yaml(os.path.join(trial, STORE))
        if err:
            return [], [f"the edit would leave the store unparseable ({err}) — nothing written"], None
        # citations resolve against the REAL root; only the store text is the trial's
        before = {e.get("id"): len(e.get("seen_in") or []) for e in entries}
        after = {e.get("id"): len(e.get("seen_in") or []) for e in (doc.get("precedents") or [])}
        grew = [k for k in after if after.get(k, 0) > before.get(k, 0)] + \
               [k for k in after if k not in before]
        if sorted(set(grew)) != [entry_id]:
            return [], [f"the edit would change {sorted(set(grew)) or 'nothing'} instead of exactly "
                        f"{entry_id} — nothing written"], None
    return changed, [], new_text


def _wrap_text(question):
    import textwrap
    return textwrap.wrap(" ".join(str(question or "").split()), width=94)


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true", help="exit non-zero if any citation is broken")
    ap.add_argument("--for", dest="pack", metavar="PACK",
                    help="propose the precedents not yet recorded against this pack")
    ap.add_argument("--add", action="store_true",
                    help="append to the store: --key <entry> with one --pack/--decision pair, or "
                         "--new <id> --question '...' with two or more pairs. Citations are "
                         "validated live; comments are preserved; the store stays powerless.")
    ap.add_argument("--key", metavar="ENTRY", help="with --add: the existing entry to extend")
    ap.add_argument("--new", dest="new_id", metavar="ID",
                    help="with --add: a new kebab-case question id")
    ap.add_argument("--question", help="with --add --new: the question, in general terms")
    ap.add_argument("--pack", dest="packs", action="append", default=[], metavar="PACK")
    ap.add_argument("--decision", dest="decisions", action="append", default=[], metavar="ID")
    a = ap.parse_args(argv)

    if a.add:
        if bool(a.key) == bool(a.new_id):
            ap.error("--add needs exactly one of --key / --new")
        if a.new_id and not a.question:
            ap.error("--new needs --question")
        if len(a.packs) != len(a.decisions) or not a.packs:
            ap.error("--pack and --decision come in pairs, at least one pair")
        sightings = [(repo_relative(os.path.abspath(p), ROOT), d)
                     for p, d in zip(a.packs, a.decisions)]
        changed, problems, new_text = add_sighting(
            a.key or a.new_id, sightings, a.question if a.new_id else None)
        if problems:
            for e in problems:
                print(f"  FAIL {e}", file=sys.stderr)
            return 1
        with open(os.path.join(ROOT, STORE), "w", encoding="utf-8", newline="\n") as fh:
            fh.write(new_text)
        for c in changed:
            print(f"  wrote {c}")
        return 0

    if a.pack:
        pack = repo_relative(os.path.abspath(a.pack), ROOT)
        if not os.path.isdir(os.path.join(ROOT, pack)):
            sys.exit(f"{a.pack}: not a directory")
        print(render_proposals(pack))
        return 0

    if a.check:
        bad = errors()
        for e in bad:
            print(e)
        entries, _ = load()
        print(f"\n{len(entries)} precedent(s); {len(bad)} error(s)")
        return 1 if bad else 0

    print(render())
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
