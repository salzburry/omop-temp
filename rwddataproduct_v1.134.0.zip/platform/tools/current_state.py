#!/usr/bin/env python3
"""What is TRUE of this repository right now, asked of the validators rather than remembered.

    python3 platform/tools/current_state.py            # write governance/CURRENT_STATE.md
    python3 platform/tools/current_state.py --check     # byte-compare it; exit 1 on drift

WHY THIS EXISTS. `HANDOVER.md` carried the numbers by hand, and a seventh external review found
four of them contradicting the code: the retired single authority ladder, "answerable families"
after `portfolio_status` stopped emitting them, "281 distinct citations" when the register
canonicalises 281 records to 246 works, and "0 signed rulings" after `signed` ceased to exist in
any vocabulary. Every one was true when written.

Correcting those four by hand was treating the symptom. A number typed into prose is a copy of a
fact, agreeing on the day it is written and free to diverge forever after — the same defect the
generated-view rule already removed from `RWB_QUESTIONS.md`, `CAPABILITIES.md` and `PORTFOLIO.md`,
and the reason those are generated with a `--check` byte-compare rather than maintained.

So the counts live here, computed on demand from the OWNING readers, and prose points at them
instead of restating them. A figure that moves changes this file, CI notices the drift, and nobody
has to remember which paragraph mentioned it.

WHAT IT IS NOT. Not a dashboard and not a new knowledge surface — the sixth review's warning
against "more surfaces or narrative tooling" is right, and this adds no surface. It composes
`approval_identity`, `capability_registry`, `citation_register`, `precedents`, `knowledge_graph`
and `product_gates`; it holds nothing, decides nothing, and grades nothing. Every number it prints
is one of those tools' own answer to its own question.

THE ZEROES ARE THE POINT. Most of what this reports is 0 — 0 registered signing keys, 0
authenticated approvals, 0 attributed rulings, 0 workbook-confirmed shelf entries. Each is a place
where only a person can write, and printing them is the whole value: a report that omitted its
zeroes would read as a system with nothing outstanding.

READ-ONLY except for the one file it generates.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
REPO = TOOLS.parent.parent
RENDER = REPO / "governance" / "CURRENT_STATE.md"
sys.path.insert(0, str(TOOLS))


def _approvals():
    import approval_identity as ai
    doc, _ = ai.registry(str(REPO))
    rows, _ = ai.audit(str(REPO))
    known, _ = ai.baseline(str(REPO))
    surfaces = ai.surfaces(str(REPO))
    return {"person_review keys registered": len(ai.person_keys(doc)),
            "governed approvals on disk": len(rows),
            "…authenticated by a signature": sum(1 for r in rows if r["authenticated"]),
            # SPLIT from the line above, because "not authenticated" and "not authenticated AND
            # grandfathered" are the difference between a check that is enforcing and one that has
            # exempted everything it would have caught.
            "…baselined as predating the mechanism":
                sum(1 for r in rows if not r["authenticated"] and ai._key(r) in known),
            "…neither — `--check` fails on these":
                sum(1 for r in rows if not r["authenticated"] and ai._key(r) not in known),
            "governed surfaces holding no file": sum(1 for _p, _w, _f, f in surfaces if not f)}


def _capabilities():
    import capability_registry as cr
    caps = cr.load().get("capabilities") or []
    out = {"capabilities registered": len(caps)}
    for state in cr.VERIFICATION:
        n = sum(1 for c in caps
                if state in ((c.get("verification") or {}).get("python"),
                             (c.get("verification") or {}).get("r")))
        if n:
            out[f"…with an engine at `{state}`"] = n
    return out


def _citations():
    import citation_register as cite
    reg = cite._load(cite.REGISTER)
    cits = reg.get("citations") or []
    merges = cite.work_merges(reg)
    routes = {}
    for c in cits:
        routes[str(c.get("route"))] = routes.get(str(c.get("route")), 0) + 1
    out = {"citation records": len(cits),
           # IDENTIFIERS, NOT PAPERS. Normalisation merges spellings of one identifier; it cannot
           # merge a paper cited once by PMID and once by DOI. `same_work:` records that when a
           # person establishes it — the count of groups is printed so the ceiling is visible.
           "…distinct identifiers (spellings merged)":
               len({cite.work_key(c, merges) for c in cits if cite._ident(c)[1]}),
           "…declared cross-scheme work equivalences": len(reg.get(cite.SAME_WORK) or [])}
    for r, n in sorted(routes.items()):
        out[f"…route `{r}`"] = n
    return out


def _decisions():
    import knowledge_graph as kg
    nodes = kg.build(str(REPO))
    return {"packs keeping a decision register": len(kg.packs(str(REPO))),
            "decisions recorded": len(nodes),
            "…RESOLVED": sum(1 for n in nodes if n.get("status") == "RESOLVED"),
            "…RESOLVED with a named approver AND a usable date": sum(1 for n in nodes if kg.ruled(n)),
            "…cited by at least one contract record": sum(1 for n in nodes if n.get("cited_by"))}


def _precedents():
    """Both axes, counted separately — because they ARE separate. A single line per grade would
    reintroduce the collapse the store just removed: `single_tumour` used to hide whatever authority
    an entry had, and a report that counts one combined tier per entry hides it again."""
    import precedents as store
    entries, _ = store.load(str(REPO))
    cache = {}
    graded = [store.strength(e, str(REPO), cache) for e in entries]
    out = {"precedent entries": len(entries)}
    for axis, names, pick in (("reach", store.REACH_NAMES, lambda s: s.reach),
                              ("authority", store.AUTHORITY_NAMES, lambda s: s.authority)):
        for name in names:
            out[f"…{axis} `{name}`"] = sum(1 for s in graded if pick(s) == name)
    return out


def _shelf():
    import citation_register as cite
    inv = cite._load(cite.INVENTORY)
    n = conf = 0
    for t in (inv.get("tumours") or {}).values():
        for v in t.get("variables") or []:
            n += 1
            if str(((v.get("provenance") or {}) or {}).get("basis") or "") == "workbook_confirmed":
                conf += 1
    return {"shelf variables": n, "…`workbook_confirmed` by a named person": conf}


SECTIONS = (
    ("Approver identity", _approvals,
     "`approval_identity.py`. The unit is the APPROVAL, bound to the commit whose diff wrote it. "
     "Registering a key is a person's own act and re-signing history is not possible at all, which "
     "is why these are separate numbers: they need different actions, and one figure would hide "
     "which is the blocker. Baselined approvals predate the mechanism and are grandfathered by "
     "(file, field, who, commit) — re-make one and it comes back under the check."),
    ("Decisions", _decisions,
     "`knowledge_graph.py`. A decision becomes citable precedent when it carries BOTH a named "
     "approver and a usable date."),
    ("Precedent store", _precedents,
     "`precedents.py`. Two independent axes — how far the evidence REACHES and what AUTHORITY "
     "stands behind the answers — both computed from the live registers, never stored. Only "
     "governed product packs count as sightings; a test fixture is not evidence."),
    ("Engine capabilities", _capabilities,
     "`capability_registry.py`. `component_parity` compares what the two engines COMPILE or "
     "COMPUTE; `stage_conformance` would compare stage OUTPUT and no harness can support it yet."),
    ("Reference shelf", _shelf,
     "`citation_register.py`. `workbook_confirmed` is the only basis that claims anything, and it "
     "now requires Gate 1 to pass on the bytes."),
    ("Citations", _citations,
     "`citation_register.py`. Records and works differ because one work cited in two spellings is "
     "one work."),
)


def render(root=REPO) -> str:
    L = ["# Current state — GENERATED, do not edit",
         "",
         "Every number here is computed on demand by the tool that owns the question; this file is",
         "written by `platform/tools/current_state.py` and byte-compared in CI. Prose elsewhere",
         "should POINT HERE rather than restate a figure, because a number copied into a paragraph",
         "is true on the day it is written and free to drift afterwards — which is exactly what an",
         "external review found in `HANDOVER.md`, in four places at once.",
         "",
         "Most of what follows is zero. Each zero is a place where only a person can write, and",
         "printing them is the point: a report that omitted its zeroes would read as a system with",
         "nothing outstanding.",
         ""]
    for title, fn, note in SECTIONS:
        L += [f"## {title}", "", note, "", "| what | count |", "|---|---:|"]
        try:
            for k, v in fn().items():
                L.append(f"| {k} | {v} |")
        except Exception as exc:                     # noqa: BLE001 — a broken reader is a finding
            L.append(f"| **could not be computed** | {type(exc).__name__}: {exc} |")
        L.append("")
    L += ["---", "",
          "Nothing in this file is an approval, and no count here is evidence that a value is",
          "correct. These are counts of RECORDS, and a record says who claimed something, never",
          "that the claim is true.", ""]
    return "\n".join(L)


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true",
                    help="byte-compare governance/CURRENT_STATE.md; exit 1 on drift")
    a = ap.parse_args(argv)
    want = render()
    if a.check:
        have = RENDER.read_text(encoding="utf-8") if RENDER.exists() else None
        if have != want:
            print(f"DRIFT — {RENDER.relative_to(REPO)} is stale; regenerate with: "
                  f"python3 platform/tools/current_state.py", file=sys.stderr)
            return 1
        print(f"current — {RENDER.relative_to(REPO)} matches what the validators report")
        return 0
    RENDER.parent.mkdir(parents=True, exist_ok=True)
    RENDER.write_text(want, encoding="utf-8")
    print(f"wrote {RENDER.relative_to(REPO)}")
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
