#!/usr/bin/env python3
"""The tools' own console encoding.

Every tool here prints `—`, `·`, `→` or `∪` somewhere: in a heading, a findings table, a set-union in
an error message. Python encodes stdout with the platform's preferred encoding, which on Windows is a
code page — cp1252 by default — and a character it cannot represent raises `UnicodeEncodeError` from
inside the `print`. The traceback names the character and the write, and nothing about the task, so it
reads as a broken tool rather than a console setting.

It surfaces on redirection especially: an interactive Windows terminal may negotiate UTF-8, while
`python tool.py > out.txt` takes the code page and fails on the first em dash.

`PYTHONIOENCODING=utf-8` fixes it and is what the runbooks said to set. That is a fix the operator has
to remember, per shell, before the first redirect, and whose absence appears as a crash in an unrelated
step — so the tools take it on themselves instead. This runs after interpreter startup and therefore
overrides `PYTHONIOENCODING` as well: these tools emit UTF-8, and setting the variable is no longer
something the runbooks ask for.

Called from each tool's `__main__` block, not at import: reconfiguring the process's streams is a thing
a program does to itself, and a library that did it to its importer would reach into a caller — a test
runner capturing output, or a notebook — that never asked.

    from console import use_utf8
    use_utf8()

platform/tests/test_governance.py holds every tool with an entry point to calling it.
"""
import sys


def use_utf8():
    """Make stdout and stderr encode UTF-8, wherever the streams support being reconfigured.

    Silent when they do not. A stream can be a pipe wrapper, a pytest capture object or an already-
    detached handle, and none of those is a reason for a tool to refuse to run — the tool's job is its
    own, and this is a display concern. `errors="replace"` on top: an undisplayable character should
    cost one glyph, not the report it appears in.
    """
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError, OSError):
            pass


def run(argv, *, binary=False, **kw):
    """Run a child process and decode its output as UTF-8. THE one place this module calls subprocess.

    `use_utf8` above fixed one half of the pipe: what a tool WRITES. `subprocess.run(..., text=True)`
    is the other half, and it decodes with `locale.getpreferredencoding()` — a Windows code page. So
    teaching every tool to emit UTF-8 while every parent read cp1252 was worse than either end being
    consistent: an em dash from a child arrives as mojibake, and some byte sequences raise
    `UnicodeDecodeError` in a parent that was only trying to read a subprocess.

    Pinning `encoding=` at each call site fixed the symptom and left the shape — eighteen sites, each
    free to be written the next way. Both sides of the pipe belong to one decision, so it lives here.

    `binary=True` for output that is NOT text: `git ls-files -z` is NUL-separated and a decode would
    corrupt a filename that is not valid UTF-8, which is exactly the filename worth catching. Those
    callers decode deliberately, with their own error policy.

    Nothing here builds a path. Cross-drive path arithmetic is `spec_extract.repo_relative`'s job and
    the reason it exists; a helper that also normalised paths would be a second answer to that.
    """
    import os
    import subprocess
    kw.setdefault("capture_output", True)
    # BOTH ENDS OF THE PIPE, which is the whole point of this function and was half-done. Setting
    # `encoding="utf-8"` decides how the PARENT DECODES; it does nothing about how the CHILD ENCODES,
    # and a Python child on Windows writes with `locale.getpreferredencoding()` — a code page. So a
    # child emitting cp1252 was being read as UTF-8: an em dash arrives as mojibake, and some byte
    # sequences are not valid UTF-8 at all.
    #
    # `PYTHONIOENCODING` is what fixes the child, and it was already being passed — by hand, at ONE
    # call site in `demo.py`, which is exactly the shape this module exists to remove. The knowledge
    # existed and was not shared, so every other caller had the bug.
    #
    # Merged into the caller's `env` rather than replacing it, and the caller still wins: a test that
    # deliberately hands a child a different encoding is testing something real.
    env = dict(kw.get("env") or os.environ)
    env.setdefault("PYTHONIOENCODING", "utf-8")
    kw["env"] = env
    if binary:
        return subprocess.run(argv, **kw)
    kw.setdefault("text", True)
    kw.setdefault("encoding", "utf-8")
    kw.setdefault("errors", "replace")
    return subprocess.run(argv, **kw)
