#!/usr/bin/env python3
"""The one page an executive reads — every pack, six gates, and what one signature buys.

    python3 platform/tools/executive_page.py --out ~/rwdp-views/executive.html

WHY THIS EXISTS. The per-pack surfaces already exist (`status.py`, `render_html.py flow`,
`decision_packet.py`) and `products/PORTFOLIO.md` says what the registry declares — but nobody
reading at portfolio altitude should need eleven pages to learn two facts: where each product
stands, and which human answers buy the most progress. This page derives BOTH from the owners:
`status.gates` / `status.next_action` say gate state and who acts next (their verdicts, not a
re-reading), and `decision_report.blast_radius` says how many contract records each open
decision blocks — the leverage column, sorted so the highest-leverage signature is the first
row a decision-owner sees.

It ADDS no judgement and writes nothing into the repository: `repo_hygiene` refuses a committed
*.html, so --out is required and refused inside the checkout, the same guard the other rendered
pages use. Packs that are still the copied template are listed as exactly that.
"""
import argparse
import html
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import decision_report                                                      # noqa: E402
import pack_run                                                             # noqa: E402
import portfolio_status                                                     # noqa: E402
import status as status_tool                                                # noqa: E402

STATE_ORDER = ("done", "in progress", "blocked", "not started", "cannot complete")


def facts():
    """One dict per REAL pack (registry-backed, not the template), from the owning tools, plus
    the cross-pack leverage table. Every number here is traceable to the tool that owns it."""
    packs, leverage = [], []
    for row in portfolio_status.facts():
        if not row["pack_exists"] or row["placeholder"]:
            continue
        pack = os.path.join(ROOT, "products", "oncology", row["slug"], row["version"])
        if not os.path.isdir(pack):
            continue
        g = status_tool.gates(ROOT, pack)
        n, who, what = status_tool.next_action(ROOT, pack)
        blocks, table, idle, dstatus = decision_report.blast_radius(pack)
        open_ds = [d for d, s in dstatus.items() if s == "OPEN"]
        packs.append({
            "slug": row["slug"], "name": row["name"], "version": row["version"],
            "registry_status": row["status"],
            "gates": [{"n": gn, "title": t, "state": st, "blockers": len(b)}
                      for gn, t, st, b in g],
            "next": {"gate": n, "who": who, "what": what},
            "decisions_open": len(open_ds),
        })
        for did, vids in blocks.items():
            owner = (table.get(did, {}).get("Owner") or "—").strip()
            leverage.append({"pack": row["slug"], "decision": did, "owner": owner,
                             "unblocks": len(vids), "variables": sorted(vids)})
    leverage.sort(key=lambda r: (-r["unblocks"], r["pack"], r["decision"]))
    return {"packs": packs, "leverage": leverage}


_CSS = """
:root{--bg:#fbfaf8;--ink:#22211f;--mut:#6d6a63;--line:#e2ded6;--card:#ffffff;
--done:#2e6e46;--prog:#8a6a1f;--block:#9c3a2e;--none:#8d8a82;--acc:#1f4e6e}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--bg:#191816;--ink:#e8e5df;
--mut:#a09c93;--line:#37342f;--card:#211f1c;--done:#6fbf8f;--prog:#d0a84a;--block:#e07a6a;
--none:#807d75;--acc:#7fb3d5}}
:root[data-theme="dark"]{--bg:#191816;--ink:#e8e5df;--mut:#a09c93;--line:#37342f;--card:#211f1c;
--done:#6fbf8f;--prog:#d0a84a;--block:#e07a6a;--none:#807d75;--acc:#7fb3d5}
body{background:var(--bg);color:var(--ink);font:15px/1.55 system-ui,sans-serif;margin:0;
padding:2rem clamp(1rem,4vw,3rem)}
h1{font-size:1.5rem;margin:0 0 .25rem}h2{font-size:1.1rem;margin:2rem 0 .75rem}
.sub{color:var(--mut);margin:0 0 1.5rem}
.pack{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:1rem 1.25rem;
margin:0 0 1rem}
.pack h3{margin:0 0 .5rem;font-size:1rem}
.gates{display:flex;gap:.5rem;flex-wrap:wrap;margin:.5rem 0}
.gate{border:1px solid var(--line);border-radius:6px;padding:.25rem .6rem;font-size:.82rem}
.g-done{color:var(--done);border-color:var(--done)}
.g-in.progress,.g-prog{color:var(--prog);border-color:var(--prog)}
.g-blocked,.g-cannot{color:var(--block);border-color:var(--block)}
.g-none{color:var(--none)}
.next{color:var(--mut);font-size:.9rem}
.next b{color:var(--ink)}
table{border-collapse:collapse;width:100%;font-size:.9rem}
th,td{text-align:left;padding:.45rem .7rem;border-bottom:1px solid var(--line)}
th{color:var(--mut);font-weight:600}
td.n{font-variant-numeric:tabular-nums;text-align:right}
.lede{color:var(--acc)}
.tablewrap{overflow-x:auto}
.foot{color:var(--mut);font-size:.82rem;margin-top:2rem;border-top:1px solid var(--line);
padding-top:1rem}
"""


def _gate_cls(state):
    return {"done": "g-done", "in progress": "g-prog", "blocked": "g-blocked",
            "cannot complete": "g-cannot"}.get(state, "g-none")


def build_html(f):
    e = html.escape
    L = [f"<title>RWD portfolio — the executive page</title><style>{_CSS}</style>",
         "<h1>Where every product stands, and what one signature buys</h1>",
         "<p class='sub'>Derived from the gate tools and the decisions registers — nothing here "
         "is typed, judged, or new. Per-pack depth: <code>status.py &lt;pack&gt;</code>; the "
         "open questions travel via <code>decision_packet.py</code>.</p>"]
    for p in f["packs"]:
        L.append(f"<div class='pack'><h3>{e(p['name'])} <span class='sub'>({e(p['slug'])} · "
                 f"{e(p['version'])} · registry: {e(p['registry_status'])})</span></h3>")
        L.append("<div class='gates'>")
        for g in p["gates"]:
            L.append(f"<span class='gate {_gate_cls(g['state'])}'>G{g['n']} {e(g['title'])} — "
                     f"{e(g['state'])}</span>")
        L.append("</div>")
        nxt = p["next"]
        L.append(f"<p class='next'>{p['decisions_open']} open decision(s) · next: "
                 f"<b>{e(nxt['who'])}</b> — {e(nxt['what'])}</p></div>")
    L.append("<h2>Leverage — open decisions by how much one answer unblocks</h2>")
    if not f["leverage"]:
        L.append("<p class='sub'>No open decision currently blocks a contract record.</p>")
    else:
        L.append("<div class='tablewrap'><table><tr><th>decision</th><th>pack</th>"
                 "<th>owner</th><th class='n'>records unblocked</th></tr>")
        for r in f["leverage"][:15]:
            L.append(f"<tr><td class='lede'>{e(r['decision'])}</td><td>{e(r['pack'])}</td>"
                     f"<td>{e(r['owner'])}</td><td class='n'>{r['unblocks']}</td></tr>")
        L.append("</table></div>")
        dropped = len(f["leverage"]) - 15
        if dropped > 0:
            L.append(f"<p class='sub'>{dropped} lower-leverage decision(s) not shown — the full "
                     f"ranking is <code>decision_report.py &lt;pack&gt;</code>.</p>")
    L.append("<p class='foot'>Generated by <code>platform/tools/executive_page.py</code>. "
             "Gate states are the gate tools' own verdicts; a gate shows done only when its "
             "owner reports no blocker. This page never claims an approval — approvals are "
             "committed file edits by named people.</p>")
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--out", help="write the page here — required, refused inside the checkout")
    ap.add_argument("--json", action="store_true", help="print the facts instead of a page")
    a = ap.parse_args(argv)
    f = facts()
    if a.json:
        import json
        print(json.dumps(f, indent=2, sort_keys=True))
        return 0
    if not a.out:
        sys.exit("--out is required (and must be outside the checkout — repo_hygiene refuses a "
                 "committed *.html)")
    # expanduser BEFORE abspath: an unexpanded '~/exec.html' arriving via argv would otherwise
    # become '<cwd>/~/exec.html', which no later expansion can repair
    wanted = os.path.expanduser(a.out)
    out_dir = pack_run.restricted_dir(os.path.dirname(os.path.abspath(wanted)),
                                      what="the rendered page")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, os.path.basename(wanted))
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(build_html(f))
    print(f"OK — {len(f['packs'])} pack(s), {len(f['leverage'])} leverage row(s); wrote {out}")
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
