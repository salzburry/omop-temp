#!/usr/bin/env python3
"""Record a human's answer to a decision — the write side the register never had.

    python3 platform/tools/decision_record.py <pack> --forms            # emit one form per OPEN decision
    python3 platform/tools/decision_record.py <pack> --apply [FORM...]  # transcribe filled forms

THE PROBLEM THIS EXISTS FOR. Answering a decision was a hand edit of a markdown table: find the row,
type the answer into the right cell, flip the status, and — since the register gained `Approved by`
and `Approval date` — remember two more cells, in a table other tools parse by column name. On the
delivery this framework was built from, that clerical loop consumed more commits than the product's
build code, and roughly one commit in four existed to correct an earlier one.

HOW AN ANSWER ARRIVES. `--forms` writes one YAML form per OPEN decision into
`handoff/decision_answers/`. A human types `answer`, `answered_by` and `answer_date` into the form BY
HAND and commits it — the same convention as `CONTRACT_APPROVAL.yaml`, and for the same reason: there
is no `--by` flag here and never will be, because the caller that would misreport a value is the same
caller that would pass the flag. `--apply` then transcribes the committed forms into DECISIONS.md.
The tool contributes exactly one mechanical fact of its own: the form carries `question_sha256`, the
hash of the question it was issued for, so an answer can never be transcribed onto a question that
changed after the answerer read it.

WHAT IT REFUSES, and each refusal is the point:
  * a blank or placeholder `answer`, `answered_by` or `answer_date` on a RESOLVED form — an answer
    nobody is recorded as having given is what this tool exists to end;
  * `answered_by` that names a team — the register's approver is a person (`not_a_person`);
  * a stale `question_sha256` — the question moved after the form was issued; re-issue the form;
  * a form for a row that is already settled — a recorded answer is never overwritten; add a new
    decision row and supersede the old one (`status: SUPERSEDED`, `superseded_by: <ID>`);
  * a `|` in the answer — the register is a markdown table and its readers split on pipes;
  * any defect in ANY form of the wave — the register is rewritten once, entirely, or not at all.

The filled forms STAY in the pack after `--apply`. They are the attestation trail: the register cell
is an index of the answer, the committed form is the answer as the person typed it, and a later edit
to either one is a visible diff. Re-applying a wave is therefore expected and idempotent — a form
whose content already matches its row is reported and skipped.

AFTER AN ANSWER LANDS the loop continues without this tool: `contract_lint` I11 immediately names
every record that cites the now-settled decision and still says `decision_required` — `--apply`
prints that worklist (from `decision_report.blast_radius`, the tool that owns it) so the next act is
in front of whoever ran it.

Needs PyYAML (the forms are YAML, like every other hand-typed record here).
"""
import argparse
import hashlib
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)
from spec_extract import repo_relative                                  # noqa: E402

import yaml                                                              # noqa: E402
import contract_lint                                                     # noqa: E402
import decision_report                                                   # noqa: E402
from contract_lint import (ANSWER_COLUMNS, APPROVAL_DATE_COLUMNS,        # noqa: E402
                           APPROVER_COLUMNS, DECISION_STATUSES, cell,
                           decision_evidence, decision_question, decision_rows,
                           decision_status)
from product_gates import bad_date, not_a_person, read_yaml, unstated    # noqa: E402

DECISIONS = os.path.join("handoff", "DECISIONS.md")
FORMS_DIR = os.path.join("handoff", "decision_answers")


def _blankish(value):
    """`unstated`, plus the register's own em/en-dash convention for "nothing here"."""
    return unstated(value) or str(value or "").strip() in {"—", "–"}


def _atomic_write(path, text):
    """Replace `path` with `text` in one step: unique temp file, fsync, `os.replace`.

    `open(path, "w")` TRUNCATES before it writes, so a fault mid-write leaves the register a
    fragment of itself — an external review's fault injection turned a 7,751-byte register into
    25 bytes. The temp file lands in the SAME directory (os.replace requires one filesystem) and
    carries a UNIQUE name (`mkstemp`) — a fixed `.tmp` name gave two concurrent writers one
    staging file to interleave in, which the review also flagged. The rename is atomic on every
    platform Python supports: readers see the whole old text or the whole new one, never a torn
    write.
    """
    import tempfile
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(os.path.abspath(path)) or ".",
                               prefix=os.path.basename(path) + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
            fh.write(text)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise

# What a form settles a question TO. RESOLVED is an answer and demands who/when; the other two are
# retractions — one says the question went away, the other that a different row now governs — and
# demanding a signature on a retraction is what `unaccountable_resolutions` deliberately does not do.
FORM_STATUSES = tuple(sorted(DECISION_STATUSES - {"OPEN"}))


def question_sha256(row):
    """The hash binding a form to the question it was issued for.

    Over question AND evidence: the evidence cell is part of what the answerer read — two conflicting
    spec values, a config default — and an evidence edit can flip which answer is right while the
    question's wording stays identical.
    """
    basis = (decision_question(row) or "").strip() + "\n" + (decision_evidence(row) or "").strip()
    return hashlib.sha256(basis.encode("utf-8")).hexdigest()


def citing_records_sha256(pack, did, root=ROOT):
    """The hash freezing the CITING RECORDS' requirement fields under an open question.

    `question_sha256` pins what was ASKED; this pins what it was asked ABOUT. Between issuing a
    form and transcribing its answer, the requirement fields of the records citing the decision
    must not move: the answerer judged those records as they stood, and an answer recorded onto
    silently reworded requirements is an answer to a different situation wearing the same id.
    This is the decision-blocked freeze — the contract stays hand-editable, but a hand edit under
    an OPEN question invalidates the outstanding form loudly instead of being transcribed over.

    Over each citing record's REQUIREMENT_FIELDS lines (contract_lint owns that partition), in
    sorted order. A pack with no contract, or a question no record cites, returns the SENTINEL
    `no-citing-records` rather than the hash of the empty string: the two states — "these exact
    requirement fields were frozen" and "nothing cites this question" — used to wear the same
    64-hex costume, so a form binding an answer to nothing looked exactly like one binding it to
    something. An external review flagged the disguise; the sentinel makes the vacuous freeze say
    so in the committed artifact.
    """
    contract = os.path.join(root, pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    parts = []
    if os.path.exists(contract):
        for block in contract_lint.records(contract_lint.read(contract)):
            if did not in (contract_lint._list(block, "decision_ids") or []):
                continue
            vid = contract_lint._scalar(block, "variable_id") or ""
            fields = [f"{k}: {contract_lint._scalar(block, k) or ''}"
                      for k in sorted(contract_lint.REQUIREMENT_FIELDS)]
            parts.append(vid + "\n" + "\n".join(fields))
    if not parts:
        return "no-citing-records"
    return hashlib.sha256("\x1f".join(sorted(parts)).encode("utf-8")).hexdigest()


def duplicate_keys(path):
    """Keys a form states twice. YAML last-wins would silently discard half an attestation — on
    the one artifact whose whole job is recording exactly what the person typed."""
    try:
        with open(path, encoding="utf-8") as fh:
            node = yaml.compose(fh)
    except yaml.YAMLError:
        return []                                    # unreadable is its own, earlier refusal
    dupes = []

    def walk(n):
        if isinstance(n, yaml.MappingNode):
            seen = set()
            for k, v in n.value:
                if isinstance(k, yaml.ScalarNode):
                    if k.value in seen:
                        dupes.append(k.value)
                    seen.add(k.value)
                walk(v)
        elif isinstance(n, yaml.SequenceNode):
            for c in n.value:
                walk(c)

    if node is not None:
        walk(node)
    return dupes


def write_forms(pack, root=ROOT, out_dir=None):
    """Emit one form per OPEN decision. Returns ([written], [skipped-existing], note-or-None).

    An EXISTING form is never overwritten, whatever it contains: a form on disk may be half-typed by
    the person answering it, and "regenerate the stubs" must never be able to destroy an answer.
    Stale forms are retired by deleting them, which is a visible act in a diff.
    """
    path = os.path.join(root, pack, DECISIONS)
    if not os.path.exists(path):
        return [], [], f"{pack} keeps no {DECISIONS} — there is no register to answer."
    text = contract_lint.read(path)
    reg_bad = contract_lint.decision_register_errors(text, pack)
    if reg_bad:
        return [], [], (f"the register itself does not parse as a governed table — a form issued "
                        f"off a duplicated or malformed row would answer the wrong question. Fix "
                        f"these first:\n  " + "\n  ".join(reg_bad))
    rows, status = decision_rows(text), decision_status(text)
    if not rows:
        return [], [], f"{pack}'s decisions register holds no readable rows."

    # A FORM IS ONLY AS GOOD AS THE QUESTION ON IT. An OPEN row whose Question, Evidence or Owner
    # is blank or a placeholder would issue a form asking a person to attest an answer to nothing —
    # and the attestation machinery downstream would bind their signature to that nothing. Refused
    # for the whole wave: the register is repaired first, then the forms are issued.
    hollow = []
    for did, row in sorted(rows.items()):
        if str(status.get(did, "OPEN")).strip().upper() != "OPEN":
            continue
        for label, value in (("Question", decision_question(row)),
                             ("Evidence", decision_evidence(row)),
                             ("Owner", cell(row, "Owner", default=""))):
            if _blankish(value):
                hollow.append(f"{did}: {label} is blank or a placeholder")
    if hollow:
        return [], [], (f"{pack}'s register has OPEN rows a form cannot be issued for — an answer "
                        f"would attest to nothing. Fill these cells first:\n  "
                        + "\n  ".join(hollow))

    dest = out_dir or os.path.join(root, pack, FORMS_DIR)
    os.makedirs(dest, exist_ok=True)
    written, kept = [], []
    for did, row in sorted(rows.items()):
        if str(status.get(did, "OPEN")).strip().upper() != "OPEN":
            continue
        target = os.path.join(dest, f"{did}.yaml")
        if os.path.exists(target):
            kept.append(target)
            continue
        body = yaml.safe_dump(
            {"decision_id": did,
             "pack": pack,
             "question": (decision_question(row) or "").strip(),
             "evidence": (decision_evidence(row) or "").strip(),
             "question_sha256": question_sha256(row),
             "records_sha256": citing_records_sha256(pack, did, root),
             "answer": "",
             "answered_by": "",
             "answer_date": "",
             "status": "RESOLVED",
             "superseded_by": ""},
            sort_keys=False, allow_unicode=True, width=98, default_flow_style=False)
        head = (
            "# Decision answer form — fill BY HAND, then commit.\n"
            "#   answer        what was decided, in full sentences (no `|` — this lands in a table)\n"
            "#   answered_by   the PERSON who decided (a name, never a team)\n"
            "#   answer_date   YYYY-MM-DD\n"
            "#   status        RESOLVED, or WITHDRAWN / SUPERSEDED (then name superseded_by)\n"
            "# question / evidence / question_sha256 are the question as issued, and records_sha256\n"
            "# freezes the citing records' requirement fields while it is open — edit none of them.\n"
            f"# Record it:  python3 platform/tools/decision_record.py {pack} --apply\n")
        _atomic_write(target, head + body)
        written.append(target)
    return written, kept, None


# --------------------------------------------------------------------------- applying
def _column_segment(header_line, *names):
    """The pipe-segment index of the first of `names` present in this header, or None.

    Resolved the way `cell` resolves — case- and spacing-insensitively — so the writer cannot
    disagree with the reader about which column is which.
    """
    cols = [re.sub(r"\s+", " ", c).strip().lower() for c in header_line.strip().strip("|").split("|")]
    for n in names:
        want = re.sub(r"\s+", " ", n).strip().lower()
        if want in cols:
            return cols.index(want) + 1              # +1: segment 0 is the text left of the first |
    return None


def _one_line(value):
    """A form value as a table cell: internal whitespace (including newlines) collapsed to spaces.

    The words are the answerer's, untouched; only the line structure changes, because a markdown
    table row IS one line. Pipes are refused before this is reached.
    """
    return " ".join(str(value or "").split())


def form_errors(form, path, register_rows, register_status, records_sha=None,
                expected_pack=None):
    """[why this form cannot be recorded] — every check fail-closed, all of them reported at once.

    `records_sha` is {decision_id: citing_records_sha256(...)} computed by the caller against the
    contract as it stands NOW. When supplied, every form must carry a matching `records_sha256` —
    a missing field reads as a form that predates (or hand-dropped) the freeze, and fail-closed
    means it is re-issued, not waved through."""
    rel = path
    errors = []
    if not isinstance(form, dict):
        return [f"{rel}: not a YAML mapping — was the form hand-edited into another shape?"]
    did = str(form.get("decision_id") or "").strip()
    if not did:
        return [f"{rel}: carries no decision_id"]
    row = register_rows.get(did)
    if row is None:
        return [f"{rel}: {did} is not in the register — was the row renamed after the form was issued?"]

    # The DISPLAYED question must be the HASHED question. The stored hash pins the register's
    # wording; without re-hashing the form's own question/evidence text, a form could show the
    # answerer altered clinical wording while carrying the original hash — and apply cleanly.
    shown = ((str(form.get("question") or "").strip()) + "\n"
             + (str(form.get("evidence") or "").strip()))
    if hashlib.sha256(shown.encode("utf-8")).hexdigest() != \
            str(form.get("question_sha256") or "").strip():
        errors.append(f"{rel}: {did} the form's DISPLAYED question/evidence does not hash to its "
                      f"own question_sha256 — the wording shown to the answerer was edited after "
                      f"issue. Delete the form and re-issue with --forms.")
    fpack = str(form.get("pack") or "").strip()
    if expected_pack and not fpack:
        errors.append(f"{rel}: {did} the form names no pack — deleting `pack:` was enough to make "
                      f"a form portable between registers, and a form answers exactly the register "
                      f"it was issued from. Re-issue it (--forms).")
    elif fpack and expected_pack and fpack != expected_pack:
        errors.append(f"{rel}: {did} the form names pack {fpack!r} but is being applied to "
                      f"{expected_pack!r} — a form answers exactly the register it was issued from.")
    stem = os.path.splitext(os.path.basename(path))[0]
    if stem != did:
        errors.append(f"{rel}: filename {stem!r} does not match its decision_id {did!r} — one form "
                      f"per decision, named for it, so a directory listing IS the answered set.")
    # An answer must answer SOMETHING. A form whose displayed question or evidence is blank (or the
    # register's own `—`) binds a signature to nothing — the hash checks above cannot catch it,
    # because a blank question hashes as consistently as a real one.
    for label in ("question", "evidence"):
        if _blankish(form.get(label)):
            errors.append(f"{rel}: {did} `{label}` is blank or a placeholder — an attestation over "
                          f"an empty {label} binds the answer to nothing. Repair the register row "
                          f"and re-issue the form (--forms).")
    want = question_sha256(row)
    got = str(form.get("question_sha256") or "").strip()
    if got != want:
        errors.append(f"{rel}: {did} question_sha256 is {got[:12] or '(blank)'}… but the register's "
                      f"question now hashes to {want[:12]}… — the question changed after this form "
                      f"was issued. Delete the form and re-issue it (--forms); the answer may no "
                      f"longer answer what is being asked.")

    # Only while the row is still OPEN — that is the freeze's whole window. After the answer lands,
    # the unblocked records are SUPPOSED to change (the worklist exists to change them), and a
    # re-applied wave must stay idempotent over that legitimate movement.
    if records_sha is not None and str(register_status.get(did, "OPEN")).strip().upper() == "OPEN":
        rec_want = records_sha.get(did, "")
        rec_got = str(form.get("records_sha256") or "").strip()
        if not rec_got:
            errors.append(f"{rel}: {did} carries no records_sha256 — the form predates (or lost) "
                          f"the citing-records freeze. Delete it and re-issue with --forms so the "
                          f"answer is given against the records as they now stand.")
        elif rec_got != rec_want:
            errors.append(f"{rel}: {did} records_sha256 is {rec_got[:12]}… but the citing records' "
                          f"requirement fields now hash to {rec_want[:12]}… — a record this "
                          f"question gates changed after the form was issued. Re-read those "
                          f"records, delete the form and re-issue (--forms); the answer may have "
                          f"been judged against requirements that no longer say the same thing.")

    st = str(form.get("status") or "").strip().upper()
    if st not in FORM_STATUSES:
        errors.append(f"{rel}: {did} status {st or '(blank)'!r} is not one of {FORM_STATUSES} — a "
                      f"form settles a question; leaving it OPEN is not a recordable act.")
        return errors

    answer = str(form.get("answer") or "")
    if len(answer) > 4000:
        errors.append(f"{rel}: {did} answer is {len(answer)} characters — a register cell is a "
                      f"ruling, not a document. State the decision; detail belongs in the "
                      f"artifacts the ruling governs.")
    if "|" in answer:
        errors.append(f"{rel}: {did} answer contains `|` — the register is a markdown table and its "
                      f"readers split on pipes. Rephrase (e.g. 'or' / a semicolon).")
    if st == "RESOLVED":
        for field in ("answer", "answered_by", "answer_date"):
            if unstated(form.get(field)):
                errors.append(f"{rel}: {did} `{field}` is blank or a placeholder — an answer nobody "
                              f"is recorded as having given is not recordable. Type it into the "
                              f"form; there is no flag for it.")
        why = not_a_person(form.get("answered_by")) if not unstated(form.get("answered_by")) else None
        if why:
            errors.append(f"{rel}: {did} answered_by: {why}")
        bad = bad_date(form.get("answer_date")) if not unstated(form.get("answer_date")) else None
        if bad:
            errors.append(f"{rel}: {did} answer_date {bad}")
    if st == "SUPERSEDED":
        sid = str(form.get("superseded_by") or "").strip()
        if not sid:
            errors.append(f"{rel}: {did} is SUPERSEDED by nothing — name the decision that now "
                          f"governs in `superseded_by`.")
        elif sid == did:
            errors.append(f"{rel}: {did} cannot supersede itself.")
        elif sid not in register_rows:
            errors.append(f"{rel}: {did} superseded_by {sid} is not in the register — add the new "
                          f"decision row first, then retire this one.")

    current = str(register_status.get(did, "OPEN")).strip().upper()
    if current != "OPEN" and errors == [] and not _already_recorded(form, row):
        errors.append(f"{rel}: {did} is already {current} in the register and this form says "
                      f"something different. A recorded answer is never overwritten: add a NEW "
                      f"decision row for the revised question, then record this one as "
                      f"status: SUPERSEDED / superseded_by: <new ID>.")
    return errors


def _cell_values(form):
    """{column-role: text} this form would put in the row, exactly as the writer will."""
    st = str(form.get("status") or "").strip().upper()
    answer = _one_line(form.get("answer"))
    if st == "SUPERSEDED":
        sid = str(form.get("superseded_by") or "").strip()
        pointer = f"Superseded by {sid}."
        answer = f"{answer} {pointer}" if answer and pointer not in answer else (answer or pointer)
    return {"answer": answer,
            "approver": _one_line(form.get("answered_by")),
            "date": _one_line(form.get("answer_date")),
            "status": st}


def _already_recorded(form, row):
    """True when the row already says exactly what this form says — the idempotent re-apply.

    Status through the SAME normaliser every other reader uses (`_status_text` strips markdown):
    comparing the raw cell made a hand-bolded `**RESOLVED**` unequal to the form's RESOLVED, so
    the idempotent path was lost and the user was confidently told to SUPERSEDE an identical
    answer — a factually false refusal."""
    from contract_lint import _status_text
    want = _cell_values(form)
    return (_status_text(cell(row, "Status")) == want["status"]
            and cell(row, *ANSWER_COLUMNS).strip() == want["answer"]
            and cell(row, *APPROVER_COLUMNS).strip() == want["approver"]
            and cell(row, *APPROVAL_DATE_COLUMNS).strip() == want["date"])


def apply_forms(pack, form_paths=None, root=ROOT):
    """(applied ids, skipped-as-recorded ids, errors, new register text or None).

    All-or-nothing by construction: every form is validated against the register BEFORE a single row
    changes, and the register is returned rewritten only when the error list is empty. Rows not named
    by a form are byte-identical in the result — the rewrite substitutes cells, it does not reformat.
    """
    reg_path = os.path.join(root, pack, DECISIONS)
    if not os.path.exists(reg_path):
        return [], [], [f"{pack} keeps no {DECISIONS}"], None
    text = contract_lint.read(reg_path)
    # A WELL-FORMED REGISTER, before any row means anything. `decision_rows` keys by id, so a
    # duplicated id resolves last-wins — contract_lint reports the duplicate, but this tool used
    # to accept the register anyway and rewrite whichever row the keying kept. Refuse the wave:
    # a register with two rows for one question has no row an answer can safely land in.
    reg_bad = contract_lint.decision_register_errors(text, pack)
    if reg_bad:
        return [], [], [f"the register itself does not parse as a governed table — fix it before "
                        f"any answer lands:"] + reg_bad, None
    rows, status = decision_rows(text), decision_status(text)

    if form_paths is None:
        dirp = os.path.join(root, pack, FORMS_DIR)
        form_paths = sorted(
            os.path.join(dirp, f) for f in os.listdir(dirp)
            if f.endswith(".yaml")) if os.path.isdir(dirp) else []
    if not form_paths:
        return [], [], [f"no answer forms found — write them with --forms, or pass files to --apply"], None

    rsha = {did: citing_records_sha256(pack, did, root) for did in rows}
    errors, todo, skipped = [], [], []
    for path in form_paths:
        form, unreadable = read_yaml(path)
        for k in duplicate_keys(path):
            errors.append(f"{path}: states `{k}` twice — YAML keeps only the last, which would "
                          f"silently discard half an attestation. Keep exactly one.")
        if unreadable:
            hint = (" — an UNQUOTED impossible date (answer_date: 2026-02-30) fails YAML itself "
                    "before any field check runs; quote it or fix the date"
                    if "out of range" in str(unreadable) else "")
            errors.append(f"{path}: unreadable YAML ({unreadable}){hint}")
            continue
        errs = form_errors(form, path, rows, status, records_sha=rsha, expected_pack=pack)
        if errs:
            errors.extend(errs)
        elif _already_recorded(form, rows[str(form.get("decision_id")).strip()]):
            skipped.append(str(form.get("decision_id")).strip())
        else:
            todo.append(form)
    if errors:
        return [], skipped, errors, None
    if not todo:
        return [], skipped, [], None

    lines = text.splitlines(keepends=True)
    hdr_idx = next((i for i, l in enumerate(lines)
                    if l.startswith("|") and re.search(contract_lint.id_column_re(), l)), None)
    if hdr_idx is None:
        return [], skipped, [f"{pack}/{DECISIONS}: no `| ID | …` header — the register is not a "
                             f"table this tool can write into"], None
    header = lines[hdr_idx]
    seg = {"answer": _column_segment(header, *ANSWER_COLUMNS),
           "approver": _column_segment(header, *APPROVER_COLUMNS),
           "date": _column_segment(header, *APPROVAL_DATE_COLUMNS),
           "status": _column_segment(header, "Status")}
    for role, names in (("answer", ANSWER_COLUMNS), ("approver", APPROVER_COLUMNS),
                        ("date", APPROVAL_DATE_COLUMNS), ("status", ("Status",))):
        if seg[role] is None:
            errors.append(f"{pack}/{DECISIONS}: the register has no `{names[0]}` column, so an "
                          f"answer has nowhere to land. Extend the header (accepted spellings: "
                          f"{', '.join(names)}) — the template's is canonical.")
    if errors:
        return [], skipped, errors, None

    applied = []
    by_id = {str(f["decision_id"]).strip(): f for f in todo}
    for i, line in enumerate(lines):
        if not line.startswith("|"):
            continue
        first = line.strip().strip("|").split("|")[0].strip()
        form = by_id.get(first)
        if not form:
            continue
        parts = line.rstrip("\n").split("|")
        want = _cell_values(form)
        for role, value in (("answer", want["answer"]), ("approver", want["approver"]),
                            ("date", want["date"]), ("status", want["status"])):
            if value or role == "status":
                parts[seg[role]] = f" {value} "
        lines[i] = "|".join(parts) + "\n"
        applied.append(first)
    missing = sorted(set(by_id) - set(applied))
    if missing:
        return [], skipped, [f"{pack}/{DECISIONS}: row(s) {missing} vanished between validation and "
                             f"rewrite — nothing was written"], None
    return applied, skipped, [], "".join(lines)


def signed_rulings(pack, root=ROOT):
    """The decision ids `check_bindings` will actually EXAMINE — RESOLVED with a named approver.

    Named separately because the check's own OK line covered zero of them on both live packs and
    read as "every signed ruling matches its committed form". Every one of the repository's
    RESOLVED rows is unsigned, so the loop body never ran; the sentence was true and meant nothing.
    A count is what tells those two states apart.
    """
    reg_path = os.path.join(root, pack, DECISIONS)
    if not os.path.exists(reg_path):
        return []
    from contract_lint import read
    text = read(reg_path)
    rows, status = decision_rows(text), decision_status(text)
    return [d for d in sorted(rows)
            if status.get(d) == "RESOLVED" and cell(rows[d], *APPROVER_COLUMNS).strip()]


def check_bindings(pack, root=ROOT):
    """[errors] — the OTHER half of the attestation loop.

    `--apply` guards the OPEN→RESOLVED transition; nothing guarded the RESOLVED ruling afterwards:
    the answer cell — the governed scientific fact — could be rewritten by hand and every gate
    stayed green (red-team finding N1). So: every RESOLVED row with a NAMED approver must be
    indexed to its committed form, the form's question_sha256 must still match the question as it
    stands, and the row must say exactly what the form says. A row that drifted from its form is a
    ruling bound to nothing. Unsigned RESOLVED rows stay the maturity path's finding
    (product_gates/dry_run flag them at contract:approved) — reporting them twice is one defect."""
    reg_path = os.path.join(root, pack, DECISIONS)
    if not os.path.exists(reg_path):
        return []
    from contract_lint import read
    text = read(reg_path)
    rows, status = decision_rows(text), decision_status(text)
    errors = []
    for did in sorted(rows):
        if status.get(did) != "RESOLVED":
            continue
        row = rows[did]
        approver = cell(row, *APPROVER_COLUMNS).strip()
        if not approver:
            continue
        rel = f"{FORMS_DIR}/{did}.yaml".replace(os.sep, "/")
        path = os.path.join(root, pack, FORMS_DIR, f"{did}.yaml")
        if not os.path.exists(path):
            errors.append(f"{did}: RESOLVED and signed ({approver}) but {rel} is not committed — "
                          f"the ruling is indexed to no attestation, so a hand edit to the answer "
                          f"cell would be invisible")
            continue
        form, unreadable = read_yaml(path)
        if unreadable:
            errors.append(f"{did}: {rel} is unreadable ({unreadable}) — an attestation that "
                          f"cannot be read binds nothing")
            continue
        if str(form.get("question_sha256") or "").strip() != question_sha256(row):
            errors.append(f"{did}: the register's question/evidence no longer hash to the form's "
                          f"question_sha256 — the question moved after it was answered; the "
                          f"answer may no longer answer what is asked")
        # ...and the form's OWN displayed wording must still hash to its stored hash. After
        # recording, an editor could reword the shown question/evidence while keeping the old
        # hash — the register comparison above stays green because the REGISTER did not move,
        # and the attestation then shows wording nobody answered.
        _shown = ((str(form.get("question") or "").strip()) + "\n"
                  + (str(form.get("evidence") or "").strip()))
        if hashlib.sha256(_shown.encode("utf-8")).hexdigest() != \
                str(form.get("question_sha256") or "").strip():
            errors.append(f"{did}: {rel} displays question/evidence that do not hash to its own "
                          f"question_sha256 — the attestation's shown wording was edited after "
                          f"recording, so the form no longer shows what was answered")
        if not _already_recorded(form, row):
            errors.append(f"{did}: the register row does not say what {rel} says — answer, "
                          f"approver, date or status drifted after recording; a recorded ruling "
                          f"changes only by SUPERSEDE, never by edit")
    return errors


def open_question(pack, id_, question, owner, root, evidence=None):
    """Append one OPEN row to the register — the write side of RAISING a question.

    Every simulated drafting journey hand-typed 16-22 long register rows and asked for exactly
    this; only downstream lints caught a broken pipe. Mirrors the answer-side tooling in shape but
    not in authority: it writes NO approver, NO date, NO resolution — Status is OPEN, always.
    Answering stays where it was: a hand-typed committed form, transcribed by --apply.

    REFUSED means NOTHING WAS WRITTEN — like --apply, all validation happens on an in-memory
    candidate and the file is replaced once, atomically, only after the candidate parses. The
    first version wrote first and validated after, so a refusal could leave the row it refused;
    an external review reproduced exactly that against a malformed register.

    `evidence` is required: a question raised on nothing points its answerer at nothing, and the
    live case that motivated it (a register row with Evidence `—` and an empty blast radius)
    binds an attestation to no citable content. A `tab:row` citation, a repo-relative path, or a
    named finding all serve; emptiness does not.
    """
    path = os.path.join(root, pack, DECISIONS)
    if not os.path.exists(path):
        sys.exit(f"{pack} has no {DECISIONS} — copy the template's register first; this tool "
                 f"appends questions, it does not create the file that explains them")
    if not re.fullmatch(r"[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)*", id_):
        sys.exit(f"{id_!r} is not a decision id — UPPERCASE words joined by dashes (OC9-MAXINDEX, "
                 f"DPM-CONST), so records can cite it and I2 can hold the citation")
    if not (question or "").strip():
        sys.exit("--question is required: a register row without a question is a placeholder "
                 "nobody can answer")
    if _blankish(owner):
        sys.exit("--owner is blank or a placeholder: a question put to nobody is a question "
                 "nobody will answer — name the function or person it goes to")
    if not (evidence or "").strip():
        sys.exit("--evidence is required: name what the answerer should look at — a `tab:row` "
                 "citation, a finding id, or a repo-relative path. A question raised on nothing "
                 "binds its eventual answer to nothing")
    # ...and it must NAME something this repository can check, not merely look like a citation.
    # `--evidence x` passed the presence check; then `not_a_real_tab:999999` and imaginary finding
    # ids passed the SHAPE check — syntactic validation binds the answer to nothing. Three forms,
    # each resolved as far as the checkout can resolve it:
    #   * a finding id (CAPS-AND-DASHES) must exist in the pack's SPEC_QC register;
    #   * a `tab:row` citation's tab must exist in the pack's sanitized extraction WHEN one is
    #     committed (a pack whose extraction is still pending cites the workbook the repo cannot
    #     read — the citation form is accepted there, stated as far as it can be checked);
    #   * a repo path must exist.
    ev = str(evidence).strip().strip("`")            # `tab:row` — the register's code-format wrap
    looks_finding = bool(re.fullmatch(r"[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)+", ev))
    is_path = os.path.exists(os.path.join(root, ev.replace("\\", "/")))
    cite = re.match(r"^([\w][\w .-]*?)\s*:\s*\S", ev)
    if looks_finding:
        qc_path = os.path.join(root, pack, "handoff", "SPEC_QC_FINDINGS.md")
        qc_ids = set()
        if os.path.exists(qc_path):
            qc_ids = set(re.findall(r"(?m)^\|\s*([A-Z][A-Z0-9-]+)\s*\|",
                                    open(qc_path, encoding="utf-8").read()))
        if ev not in qc_ids:
            sys.exit(f"--evidence {ev!r} looks like a finding id and the pack's "
                     f"SPEC_QC_FINDINGS.md does not carry it — an imaginary finding binds the "
                     f"answer to nothing. Cite a real finding, a tab:row, or a repo path")
    elif cite and not is_path:
        extracted = os.path.join(root, pack, "spec_pipeline", "out", "extracted.json")
        if os.path.exists(extracted):
            import json as _json
            try:
                _rows = _json.load(open(extracted, encoding="utf-8")).get("rows") or []
                _tabs = {str(r.get("tab") or "").strip().lower()
                         for r in _rows if isinstance(r, dict)} - {""}
            except Exception:                        # noqa: BLE001 — unreadable extraction
                _tabs = set()                        # cannot vouch; the citation stands unchecked
            if _tabs and cite.group(1).strip().lower() not in _tabs:
                sys.exit(f"--evidence {ev!r} cites tab {cite.group(1)!r} and the pack's "
                         f"sanitized extraction has no such tab — a citation into a document "
                         f"that does not say it binds the answer to nothing. Real tabs: "
                         f"{', '.join(sorted(_tabs))}")
    elif not (cite or is_path):
        sys.exit(f"--evidence {ev!r} names nothing checkable: not a `tab:row`-style citation, not "
                 f"a finding id (CAPS-AND-DASHES), and not a path that exists in this repository. "
                 f"Point the answerer at the thing itself")
    cells = {"id": id_, "question": question, "owner": owner, "evidence": evidence}
    for field, val in cells.items():
        if "|" in val:
            sys.exit(f"the {field} contains a pipe, which breaks the register table — rephrase")
        if any(ch in val for ch in "\r\n") or any(ord(ch) < 32 for ch in val if ch != "\t"):
            sys.exit(f"the {field} contains a line break or control character — a register row "
                     f"is ONE line; rephrase as a single sentence (the answer form has room "
                     f"for detail)")
    text = open(path, encoding="utf-8", newline="").read()
    if id_ in contract_lint.decision_ids(text):
        sys.exit(f"{id_} is already in the register — one row per question; edit the existing row "
                 f"only through the answer machinery")
    # The register must be WELL-FORMED before the append, or the refusal blames the wrong text.
    errs = contract_lint.decision_register_errors(text, os.path.basename(pack))
    if errs:
        for e in errs:
            print(f"  {e}", file=sys.stderr)
        sys.exit(f"REFUSED — nothing was written. {pack}/{DECISIONS} does not parse as it "
                 f"stands; fix the register before raising a new question in it")
    lines = text.split("\n")
    last_row = max((i for i, ln in enumerate(lines) if ln.strip().startswith("|")), default=None)
    if last_row is None:
        sys.exit(f"REFUSED — nothing was written. {pack}/{DECISIONS} has no table; restore the "
                 f"register's header row first")
    lines.insert(last_row + 1,
                 f"| {id_} | {question.strip()} | {evidence.strip()} | {owner.strip()} "
                 f"| — |  |  | OPEN |")
    candidate = "\n".join(lines)
    errs = contract_lint.decision_register_errors(candidate, os.path.basename(pack))
    if errs or id_ not in contract_lint.decision_ids(candidate):
        for e in errs:
            print(f"  {e}", file=sys.stderr)
        sys.exit(f"REFUSED — nothing was written. The appended row would not parse back; "
                 f"rephrase the question as one plain sentence")
    _atomic_write(path, candidate)
    print(f"OPEN     {id_} -> {pack}/{DECISIONS} (owner {owner.strip()})")
    print("Cite it from the blocked record(s): decision_ids: [" + id_ + "]")
    return 0


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack", help="the pack directory (repo-root-relative)")
    ap.add_argument("--forms", action="store_true",
                    help=f"emit one YAML answer form per OPEN decision into {FORMS_DIR}/")
    ap.add_argument("--apply", nargs="*", metavar="FORM",
                    help=f"transcribe filled forms (default: every .yaml in {FORMS_DIR}/)")
    ap.add_argument("--check", action="store_true",
                    help="CI: every signed RESOLVED row must match its committed form")
    ap.add_argument("--open", metavar="ID",
                    help="append an OPEN question row to DECISIONS.md (with --question / --owner). "
                         "Raising a question is the drafter's act; answering it is not — the row "
                         "is written with empty approver fields and Status OPEN, always")
    ap.add_argument("--question", help="the question text for --open")
    ap.add_argument("--evidence", help="what the answerer should look at (required with --open): "
                                       "a `tab:row` citation, a finding id, or a repo path")
    ap.add_argument("--owner", default="RWB", help="who the question is put to (default RWB)")
    a = ap.parse_args(argv)
    pack = repo_relative(os.path.abspath(a.pack), ROOT)
    if not os.path.isdir(os.path.join(ROOT, pack)):
        sys.exit(f"{a.pack}: not a directory")
    if sum((a.forms, a.apply is not None, a.check, a.open is not None)) != 1:
        sys.exit("choose exactly one of --forms / --apply / --check / --open")

    if a.open is not None:
        return open_question(pack, a.open, a.question, a.owner, root=ROOT, evidence=a.evidence)

    if a.check:
        bad = check_bindings(pack, root=ROOT)
        for e in bad:
            print(f"  {e}", file=sys.stderr)
        # A COUNT, NOT A VERDICT. Zero signed rulings is the state of every register in this
        # repository, and "every signed ruling matches" over zero of them is an absence wearing a
        # pass. Say how many were examined, and when that is none, say what it does not prove.
        examined = signed_rulings(pack, root=ROOT)
        if not bad and not examined:
            print(f"NOTHING CHECKED — {pack} has no RESOLVED decision with a named approver, so no "
                  f"ruling was bound to a committed form. This does not say the register is "
                  f"sound; it says there is nothing here this check can hold.")
            return 0
        print(f"OK — all {len(examined)} signed ruling(s) match their committed form" if not bad else
              f"{len(bad)} ruling(s) not bound to their attestation", file=sys.stderr if bad else sys.stdout)
        return 1 if bad else 0

    if a.forms:
        written, kept, note = write_forms(pack, root=ROOT)
        if note:
            sys.exit(note)
        for p in written:
            print(f"wrote    {repo_relative(p, ROOT)}")
        for p in kept:
            print(f"kept     {repo_relative(p, ROOT)}  (existing form, not overwritten)")
        if not written and not kept:
            print("no OPEN decisions — nothing to answer.")
        else:
            print(f"\nFill answer / answered_by / answer_date BY HAND, commit, then:\n"
                  f"  python3 platform/tools/decision_record.py {pack} --apply")
        return 0

    # blast radius BEFORE the write: these are the records each answer is about to unblock.
    blocking, _t, _i, _s = decision_report.blast_radius(os.path.join(ROOT, pack))
    applied, skipped, errors, new_text = apply_forms(pack, a.apply or None, root=ROOT)
    for id_ in skipped:
        print(f"already recorded  {id_}")
    if errors:
        print(f"\nREFUSED — nothing was written. {len(errors)} defect(s):", file=sys.stderr)
        for e in errors:
            print(f"  {e}", file=sys.stderr)
        return 1
    if not applied:
        print("nothing to record.")
        return 0
    _atomic_write(os.path.join(ROOT, pack, DECISIONS), new_text)
    print(f"\nrecorded {len(applied)} answer(s) into {pack}/{DECISIONS}:")
    for id_ in applied:
        print(f"  {id_}")
    worklist = {id_: blocking.get(id_, []) for id_ in applied if blocking.get(id_)}
    if worklist:
        print("\nTHE ANSWERS NOW HAVE TO BE WRITTEN IN. These records cite the settled decisions and "
              "still say decision_required —\ncontract_lint I11 names them until each is re-dispositioned:")
        for id_, vids in sorted(worklist.items(), key=lambda kv: -len(kv[1])):
            print(f"  {id_}  →  {len(vids)} record(s): {', '.join(sorted(vids))}")
        print(f"\n  python3 platform/tools/contract_lint.py {pack}")
    print("\nKeep the filled forms committed — they are the attestation the register row indexes.")
    # Unconditionally, because no matcher can pair FUED-DEFINITION with OC-FU-END-DEFINITION — the
    # judgment that two registers ask one question is a person's, made while the answer is fresh.
    print("If any settled question also exists on another pack, record the precedent now:\n"
          "  python3 platform/tools/precedents.py --add --key <entry> "
          f"--pack {pack} --decision <ID>")
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
