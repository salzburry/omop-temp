#!/usr/bin/env python3
"""Does the executable YAML implement the contract, and does the contract account for the YAML?

This is a TRACEABILITY binder, and the distinction matters: it proves a record NAMES real config and
that no governed config is unaccounted for. It does not prove the config MEANS what the record says —
that an `engine:` symbol exists is not evidence it implements this variable. `--enumerations` narrows
that for value lists and `--parameters` for the window, the record selection and the source table.
What is left to a person reading both sides is everything neither can read: a derivation, a
cohort restriction, and any window stated as prose rather than as an offset pair or a duration —
`--parameters` COUNTS those rather than passing over them, so the residue is visible.

CI runs it (`--check`) for packs `product_gates.py --list-buildable` reports, and fails on unaccounted
binding issues, enumeration differences and parameter contradictions alike.

It is a separate tool because it is the first thing that reads BOTH sides. `contract_lint` is
stdlib-only on purpose — every product's test wrapper runs it standalone — and the executable side is
YAML that needs a real parser. Folding this in would put PyYAML behind the lint every product runs.

A record names where it is implemented, as a flat list:

    implementation_refs: [variables/demographics.yaml#/age_bands, engine:numeric_bands]

  <pack-relative path>#/<top-level key>   a governed config block
  engine:<symbol>                         a shared-engine function that does the work
  none                                    nothing implements it yet (must be a shortfall status)

Both directions matter, and they fail differently:

  contract -> implementation   a record claiming `implemented` that names a config block which does
                               not exist. The requirement points at nothing.
  implementation -> contract   a governed config block no record claims. That is behaviour in the
                               build that no approved requirement asked for — the direction nobody
                               checks, because the build works.

    python3 platform/tools/contract_binding.py <product-dir> [--cover variables/demographics.yaml]
"""
import argparse
import ast
import json
import os
import re
import sys


sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from spec_extract import repo_relative                                  # noqa: E402
from product_gates import pack_yaml, read_yaml, registry_entry                    # noqa: E402
from contract_lint import (OUTPUT_DECISIONS, _inline, _kv, _list, _scalar,   # noqa: E402
                           decision_rows, decision_status, open_decisions,      # noqa: E402
                           published_surface, records, read, spec_ref_rows)     # noqa: E402

# Keys that describe the pack rather than govern behaviour — never a requirement's implementation.
PACK_META = {"pack_id", "name", "description", "owner", "version", "status", "notes",
             "data_product_id", "codelist_id", "vendor", "tumor_class", "request_type"}

# Keys that wire the BUILD rather than derive a variable: which packs load, which tables are read,
# which refresh runs. No single requirement implements them, and demanding a record claim them would
# push people to attach them arbitrarily to whichever variable came first. They are governed
# elsewhere — `sources` per record in each record's own `source:` mapping (Gate 3), `run` by the
# release manifest — so they are listed here rather than silently skipped.
BUILD_WIRING = {"run", "sources", "variables", "codelists"}
NONE = "none"
# Implementation states that produce something, and so must say where.
PRODUCES = {"implemented", "partial"}
ENGINE = "engine:"


def contract_records(product):
    """[(variable_id, implementation state, [refs])] for every record in the pack."""
    path = os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")
    out = []
    for block in records(read(path)):
        vid = re.search(r"(?m)^variable_id:\s*(\S+)", block).group(1)
        out.append((vid, _kv(_inline(block, "status"), "implementation"),
                    _list(block, "implementation_refs")))
    return out


def output_names(product):
    """Every physical name the contract says the product emits.

    `physical_name` is sometimes compound — the ELIGPFS record emits "eligpfs / lastclinicnotedate" —
    so it is split. Reading only the variable_id would call both of those unaccounted for.
    """
    text = read(os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md"))
    names = set()
    for value in re.findall(r"physical_name:\s*\"?([^,\"]+)\"?,", text):
        names.update(n.strip().lower() for n in value.split("/") if n.strip())
    return names


def governed_blocks(product, files, unreadable_files=None):
    """{`<file>#/<key>`} for every block the build reads from the named files.

    `unreadable_files` collects `{rel: why}` for a composed file that will not parse. Folding those
    into the block map instead made the binder report "governed by the build but claimed by no
    contract record" — telling an author to write a contract record for a file that does not parse,
    which is the wrong thing to fix.
    """
    unreadable_files = {} if unreadable_files is None else unreadable_files
    out = {}
    for rel in files:
        path = os.path.join(product, rel)
        if not os.path.exists(path):
            continue
        # Through the SHARED reader: a variables file whose root is a list PARSES fine and then
        # died here with `TypeError: list indices must be integers` — a traceback out of a CI gate,
        # the same defect fixed in the approval gates while this one kept its own safe_load.
        doc, unreadable = read_yaml(path)
        if unreadable:
            unreadable_files[rel] = unreadable
            continue
        for key in doc:
            if key not in PACK_META and key not in BUILD_WIRING:
                out[f"{rel}#/{key}"] = doc[key]
    return out


def raised_as_questions(product):
    """Config refs named by an OPEN decision.

    A block nobody claims is not automatically wrong — it may be a question already raised. The
    disposition register makes the same distinction for spec items: "not handled by a record" and
    "overlooked" must stop looking identical. A closed or absent decision stops covering it, so the
    block comes back as a finding the moment the question is answered.
    """
    path = os.path.join(product, "handoff", "DECISIONS.md")
    if not os.path.exists(path):
        return {}
    text = read(path)
    status = decision_status(text)
    out = {}
    for did, row in decision_rows(text).items():
        if status.get(did) != "OPEN":
            continue
        joined = " ".join(row.values())
        for ref in re.findall(r"[\w/]+\.ya?ml#/\w+", joined):
            out[ref] = did
        # ...and a published NAME, in backticks, for `published_name_errors`. Same rule and the same
        # reason as the config refs above — a name nobody can find is not automatically wrong if the
        # question has been raised — so it reads from the same register and the same OPEN filter.
        # Backticks required: an ordinary word in a question would silently exempt a real variable.
        for name in re.findall(r"`([A-Za-z_][\w]*)`", joined):
            out.setdefault(name.upper(), did)
    return out


# The catalog documents a coded variable by its LABEL column and not its parallel `-n` code column —
# `stage`/`stagen`, `race`/`racen`. `engine.validate.emitted_variables` states the same convention in
# its docstring, which is where this was learned; stated as a rule here so a check can apply it rather
# than a reader remember it. Four prostate/202606 records (RACEN, PRACTICN, COHORTN, COHORTUN) are
# correct and would otherwise be reported.
CODE_COLUMN_SUFFIX = "n"


def _products_root(product):
    """The `products/` root a pack sits under — `<root>/<family>/<slug>/<spec_version>`.

    Three levels up, not a search for a directory called `products`: a pack copied into a tmpdir for
    a test keeps its shape and loses its name, and `product_gates.products()` discovers packs by that
    same SHAPE for the same reason.
    """
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(product))))


def catalog_codes(products_root):
    """{lowercased variable code} the shared catalog documents, or None if it cannot be read.

    THE ORACLE MATTERS AND THE OBVIOUS ONE IS WRONG. The first attempt compared published records
    against `engine.validate.emitted_variables`, which returned 153 codes against a built ADS of 187
    columns and reported 92 of 171 published records as unemitted. It is a catalog-COMPLETENESS
    helper — its own docstring says it excludes the parallel `-n` columns — not a column manifest, and
    a check built on it accuses records that are perfectly correct.

    `products/metadata/catalog.yaml` is the governed manifest: `test_catalog` already holds it against
    the engine per tumour, so a name the catalog does not carry is a name no reviewer has seen either.
    Its path comes from `engine.config.SHARED_ASSETS`, never a literal.

    None, not an empty set, when it cannot be read — an unreadable catalog must not report every
    published record as undocumented.
    """
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from engine.config import shared_asset                                          # noqa: E402
    doc, err = read_yaml(str(shared_asset(products_root, "catalog")))
    if err or not isinstance(doc, dict) or not isinstance(doc.get("variables"), list):
        return None
    return {str(e["code"]).strip().lower(): e
            for e in doc["variables"] if isinstance(e, dict) and e.get("code")}


def tumour_code(product):
    """The catalog's tumour code for the product owning `product`, or None if it cannot be resolved.

    Through `product_gates.registry_entry`, which owns the family/slug match. None means UNRESOLVED,
    and every caller must treat that as "cannot check" rather than "matches everything".
    """
    root = os.path.dirname(_products_root(product))
    rel = repo_relative(os.path.abspath(product), root)
    entry = registry_entry(root, rel) or {}
    return entry.get("code") or None


def published_name_errors(product, products_root, codes=None):
    """[problems] where a record CLAIMS a settled published name the catalog does not document.

    THE THIRD THING A CONTRACT RECORD CAN LIE ABOUT. `contract_binding` proves a record names real
    config and that the engine reads it. Neither says the product ends up with the COLUMN the record
    promises: `DATES__ALL_TABLES_` is `role: published`, `name_status: aligned`,
    `implementation: implemented`, and its `required_rule` is "Programmer should pick one set of date
    variables consistently" — a note to a programmer, published as a date column.

    NARROW ON PURPOSE, and every exemption is the record's own honest statement rather than a
    tolerance this check invents:

      role != published        it is not a column anybody receives
      implementation != implemented   the engine is not claimed to build it — `engine_gap`,
                                      `config_gap`, `partial` and `not_implemented`
                                      are all true answers
      name_status != aligned   the record already says the name is unsettled, which is the honest
                               state for a name still under discussion and must not be punished
      an OPEN decision names it the same accounting `raised_as_questions` gives an unclaimed config
                               block: raised and numbered is not the same as overlooked

    Everything left is a record asserting all three at once — built, published, name settled — over a
    name no catalogued variable carries. On prostate/202606 that is three records, and each is a
    different defect: a programmer instruction modelled as a column, a preliminary intermediate
    modelled as published, and one whose own notes name the emission gap it claims to be past.
    """
    if codes is None:
        codes = catalog_codes(products_root)
    if codes is None:
        return ["cannot read the shared variable catalog — published names are unchecked, not passing"]
    # WHICH TUMOUR'S VOCABULARY. The catalog is CROSS-TUMOUR and says so per entry: 30 codes are
    # `applies_to: all`, 91 `['mcrpc']`, 24 `['oc']`, 19 `['ec']`. Asking only whether a code exists
    # ANYWHERE would let an ovarian-only entry satisfy a prostate record's published name — which
    # never fires wrongly on the shipped packs, and is exactly how that stays invisible.
    tumour = tumour_code(product)
    if tumour is None:
        return [f"{product}: no registry entry, so the catalog's per-tumour `applies_to` cannot be "
                f"applied — published names are unchecked, not passing"]
    raised = raised_as_questions(product)
    contract = os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(contract):
        # No contract means no record claims a published name, so nothing binds — vacuously clean
        # HERE. The absence itself is Gate 2's finding (contract not_started), already reported by
        # status/gates; a traceback from this tool was the only thing this branch used to add.
        return []
    text = read(contract)
    out = []
    for block in records(text):
        vid = (_scalar(block, "variable_id") or "").strip()
        output = _inline(block, "output") or ""
        if (_kv(output, "role") or "").strip() != "published":
            continue
        if (_kv(_inline(block, "status"), "implementation") or "").strip() != "implemented":
            continue
        if (_kv(output, "name_status") or "").strip() != "aligned":
            continue
        if vid.upper() in raised:
            continue
        m = re.search(r'physical_name:\s*"?([^,"]+)"?', output)
        names = [n.strip().lower() for n in (m.group(1) if m else "").split("/")
                 if n.strip() and n.strip().lower() != NONE and n.strip().lower() != "n/a"]
        if not names:
            out.append(f"[{vid}] published and implemented with no physical_name")
            continue
        # EVERY name, not any. `physical_name` is sometimes compound — the ELIGPFS record emits
        # "eligpfs / lastclinicnotedate" — and `any` let one catalogued sibling carry an uncatalogued
        # one through. A code column is documented through its LABEL: `racen` through `race`.
        sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        from engine.dictionary import _applies                                      # noqa: E402

        def _known(n):
            e = codes.get(n)
            return bool(e is not None and _applies(e, tumour)) or (
                n.endswith(CODE_COLUMN_SUFFIX) and codes.get(n[:-1]) is not None
                and _applies(codes[n[:-1]], tumour))
        unknown = [n for n in names if not _known(n)]
        if not unknown:
            continue
        names = unknown
        out.append(f"[{vid}] output.physical_name {'/'.join(names)} is published, implemented and "
                   f"name_status:aligned, but no variable in the shared catalog carries that code — "
                   f"the product does not ship a column by that name, so the record promises "
                   f"something nobody receives. Correct the name, the role or the implementation "
                   f"status, or raise a decision naming `{vid}`")
    return out


def engine_symbols():
    """Function names the shared engine defines, so `engine:` refs name something real.

    Located from THIS TOOL, not from the product: the engine is where the tool lives, and walking up
    from the product found nothing when the pack sat outside a checkout — which reported every engine
    ref as broken. A check that fails when it cannot see is worse than one that says so.
    """
    engine = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "engine")
    if not os.path.isdir(engine):
        return None
    out = set()
    for dirpath, _dirs, files in os.walk(engine):
        for fn in files:
            if fn.endswith(".py"):
                with open(os.path.join(dirpath, fn), encoding="utf-8") as fh:
                    out.update(re.findall(r"(?m)^\s*def\s+(\w+)", fh.read()))
    return out


def _engine_dir():
    """The shared engine, located from THIS TOOL — same reason as `engine_symbols`, or None."""
    d = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "engine")
    return d if os.path.isdir(d) else None


def _pack_role(node):
    """The role, if `node` is exactly `<x>.pack("role")` — optionally `... or {}`. Else None."""
    if isinstance(node, ast.BoolOp) and isinstance(node.op, ast.Or):
        node = node.values[0]
    return (node.args[0].value
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
            and node.func.attr == "pack" and len(node.args) == 1
            and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str)
            else None)


def _reads_key(node):
    """(object read from, key node), if `node` is `obj["k"]` or `obj.get("k", ...)`. Else (None, None)."""
    if isinstance(node, ast.Subscript):
        return node.value, node.slice
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) \
            and node.func.attr == "get" and node.args:
        return node.func.value, node.args[0]
    return None, None


def engine_config_keys():
    """{role: {top-level block names}} the shared engine actually READS, or None if it cannot look.

    THE GAP THIS CLOSES. Renaming `age_bands` to `age_bandz` in `variables/demographics.yaml` AND in
    the record that claims it satisfies everything: the binder sees a record naming a block that
    exists and a block claimed by a record, `validate.check` passes, `finalize --check` reports every
    summary matching its evidence — and `emitted_variables` quietly drops from 153 to 151, because
    AGEGR1 and AGEGR1N are produced by an engine that reads `age_bands` and nothing else. A
    config-only edit deleted two published variables with every gate green.

    That is the cost of the property the framework is FOR: if specs are edited and code is not, then
    nothing else is watching the config. `contract_binding` checks that a name RESOLVES on both
    sides; this checks the third side, that the engine is listening for it.

    DERIVED BY AST from the engine's own source, never a hand-kept list — a list is a fourth place to
    forget, and it would drift silently in the safe-looking direction (a stale entry keeps accepting a
    block nothing reads). Two access shapes, both real in this engine:

        dem = cfg.pack("demographics"); dem["age_bands"]      # alias, then subscript or .get
        for blk in ("biomarkers", "labs"): clin.get(blk)      # loop over a tuple of names

    The second is why this is an AST walk and not a regex: a scan for string constants next to
    `.get(` reported `biomarkers` and `labs` as blocks nothing reads, on three packs that use them.
    A check whose false positives land on real packs gets switched off.

    Returns None — not an empty dict — when the engine directory is unreadable, so a caller can tell
    "nothing reads any config" from "I could not look". `engine_symbols` returns None for the same
    reason and `errors()` treats both the same way.
    """
    engine = _engine_dir()
    if engine is None:
        return None
    out, consts = {}, {}
    trees = []
    for dirpath, dirs, files in os.walk(engine):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for fn in sorted(files):
            if not fn.endswith(".py"):
                continue
            with open(os.path.join(dirpath, fn), encoding="utf-8") as fh:
                tree = ast.parse(fh.read(), fn)
            trees.append(tree)
            consts.update(_module_string_tuples(tree))
    for tree in trees:
        for scope in ast.walk(tree):
            if isinstance(scope, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Module)):
                _scope_keys(scope, out, consts)
    return out


def _module_string_tuples(tree):
    """{NAME: {string constants}} for every module-level `NAME = ("a", "b")` in one file.

    THE LOOP LIST STOPPED BEING A LITERAL. `for blk in ("biomarkers", "labs"):` was spelled in six
    places — this stage, three checks in validate, the dashboard and the R engine — so it was named
    once as `clinical.CLOSEST_PANELS` and imported. That is the right change and it broke this
    probe silently in the safe-looking direction: `node.iter` became an `ast.Name`, the tuple
    branch below stopped matching, and `labs` and `response` became keys "the engine never reads".
    A pack declaring either would have been told its block is unread — a false positive landing on
    a real pack, which this function's own docstring calls the way a check gets switched off.

    Collected across ALL engine files before any scope is walked, because the constant is defined
    in `stages/clinical.py` and consumed in `validate.py` and `dashboard.py`. Only literal tuples
    of strings: anything computed stays invisible rather than being guessed at.
    """
    found = {}
    for node in tree.body:
        if not (isinstance(node, ast.Assign) and len(node.targets) == 1
                and isinstance(node.targets[0], ast.Name)):
            continue
        if isinstance(node.value, (ast.Tuple, ast.List, ast.Set)):
            vals = {e.value for e in node.value.elts
                    if isinstance(e, ast.Constant) and isinstance(e.value, str)}
            if vals and len(vals) == len(node.value.elts):
                found[node.targets[0].id] = vals
    return found


def _iter_string_constants(node, consts):
    """The string constants a `for ... in <node>` iterates, or an empty set when it cannot be read.

    Three shapes, all real in this engine: a literal tuple/list/set; a module constant NAME bound to
    one; and `NAME + ("extra",)`, which `validate.required_columns` uses to loop the panel blocks
    PLUS `lab_values`. The concatenation matters — without it, naming the constant would have left
    that one loop unreadable and re-created the false positive one line later.
    """
    if isinstance(node, (ast.Tuple, ast.List, ast.Set)):
        vals = {e.value for e in node.elts
                if isinstance(e, ast.Constant) and isinstance(e.value, str)}
        return vals if len(vals) == len(node.elts) else set()
    if isinstance(node, ast.Name):
        return set(consts.get(node.id) or ())
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        left = _iter_string_constants(node.left, consts)
        right = _iter_string_constants(node.right, consts)
        return (left | right) if (left and right) else set()
    return set()


def _scope_keys(scope, out, consts=None):
    """Accumulate {role: {key}} for one function or module scope."""
    consts = consts or {}
    aliases, loops = {}, {}
    for node in ast.walk(scope):
        # `dem = cfg.pack("demographics")` — bind the NAME to the role. Only an exact `.pack()` call:
        # `pt = cfg.pack("treatment").get("prior_taxane")` binds a SUB-block, and treating its keys as
        # top-level blocks would accept `prior_taxane`'s own fields as governed blocks.
        if isinstance(node, ast.Assign) and len(node.targets) == 1 \
                and isinstance(node.targets[0], ast.Name):
            role = _pack_role(node.value)
            if role:
                aliases[node.targets[0].id] = role
        # `for blk in ("biomarkers", "labs"):` — the loop variable stands for each constant.
        if isinstance(node, (ast.For, ast.AsyncFor)) and isinstance(node.target, ast.Name):
            names = _iter_string_constants(node.iter, consts)
            if names:
                loops.setdefault(node.target.id, set()).update(names)
    for node in ast.walk(scope):
        obj, key = _reads_key(node)
        if key is None:
            continue
        role = _pack_role(obj) or (aliases.get(obj.id) if isinstance(obj, ast.Name) else None)
        if not role:
            continue
        if isinstance(key, ast.Constant) and isinstance(key.value, str):
            out.setdefault(role, set()).add(key.value)
        elif isinstance(key, ast.Name) and key.id in loops:
            out.setdefault(role, set()).update(loops[key.id])


def unread_config_blocks(product):
    """[(file, role, key or None, why)] for every governed block in the pack the engine never reads.

    PACK_META is this module's own definition rather than a restatement: those keys (`pack_id`,
    `owner`, `version`…) describe the pack and are correctly read by nobody.

    A file this cannot PARSE is reported, never skipped. The first version of this function unpacked
    `read_yaml` — which returns `(doc, error)` — into a single name, so `isinstance(doc, dict)` was
    False for every file and it returned an empty list: a clean result over nothing examined, which is
    the failure this whole check exists to catch, committed inside the check itself. It survived a
    manual run on seven real packs and was caught by the mutation test one step later.
    """
    reads = engine_config_keys()
    if reads is None:
        return []                       # cannot see the engine — `errors()` says so once, not per key
    out = []
    vardir = os.path.join(product, "variables")
    if not os.path.isdir(vardir):
        return out
    for fn in sorted(os.listdir(vardir)):
        if not fn.endswith((".yaml", ".yml")):
            continue
        role = os.path.splitext(fn)[0]
        doc, err = read_yaml(os.path.join(product, "variables", fn))
        if err or not isinstance(doc, dict):
            out.append((f"variables/{fn}", role, None,
                        err or "does not parse to a mapping, so its blocks cannot be checked "
                               "against the engine"))
            continue
        known = reads.get(role)
        if not known:
            # A WHOLE FILE nobody consumes, which is a bigger finding than one stale key and reads
            # nothing like it. `cfg.pack(role)` is keyed on the file STEM, so `variables/demo.yaml`
            # loads and then no stage ever asks for it.
            blocks = [k for k in sorted(doc) if k not in PACK_META]
            if blocks:
                out.append((f"variables/{fn}", role, None,
                            f"no stage reads a '{role}' pack at all, so none of its "
                            f"{len(blocks)} block(s) run — `cfg.pack()` is keyed on the FILE STEM, "
                            f"and the engine asks for {', '.join(sorted(reads)) or '(nothing)'}"))
            continue
        for key in sorted(doc):
            if key in PACK_META or key in known:
                continue
            out.append((f"variables/{fn}", role, key,
                        f"the engine never reads `{key}` off the '{role}' pack — whatever it "
                        f"configures does not run. A block the engine ignores is a requirement that "
                        f"silently produces nothing, and renaming one in the config and the record "
                        f"together satisfies every other check here"))
    return out


def spec_coverage(product):
    """(is the specification fully accounted for, a phrase saying how far it got).

    ONLY A CONTRACT THAT COVERS ITS SPECIFICATION CAN SAY "NOBODY REQUIRED THIS".

    The unclaimed-block message below concludes that a governed config block is either unclaimed or
    "behaviour nobody required". The second half is an assertion about the WHOLE requirement set, and
    it holds only when the contract has actually read the whole specification. On oc/202606 it did
    not: 9 of 360 specification items are in the contract and 299 have never been examined, and the
    tool reported 34 blocks as behaviour nobody required — while 295 drafted records for that same
    product sat in a sandbox the tool cannot see. Someone acting on that would have deleted config
    that IS required.

    The fix is not to teach this tool where drafts live. It is to stop it drawing a conclusion its
    evidence cannot support: with 299 rows unexamined, "nobody required it" is unknowable no matter
    where the drafting happens.

    Counts come from `contract_scaffold.coverage_report`, the PRODUCER — never from parsing the
    rendered COVERAGE.md, for the reason `finalize` gives at length.

    FAIL-CLOSED: an extraction that cannot be read returns False. Unable to prove coverage is
    complete is the same answer as knowing it is not, because both forbid the stronger sentence.
    """
    ej = os.path.join(product, "spec_pipeline", "out", "extracted.json")
    lj = os.path.join(product, "spec_pipeline", "out", "lint.json")
    if not os.path.exists(ej):
        return False, "no captured specification, so its coverage is unknown"
    try:
        import contract_scaffold as cs
        with open(ej, encoding="utf-8") as fh:
            data = json.load(fh)
        lint = None
        if os.path.exists(lj):
            with open(lj, encoding="utf-8") as fh:
                payload = json.load(fh)
            lint = payload["findings"] if isinstance(payload, dict) else payload
        rows, counts = cs.coverage_report(data, product, lint)
    except Exception as exc:                       # noqa: BLE001 — any failure means "cannot prove"
        return False, f"a coverage report that could not be produced ({type(exc).__name__})"
    undispositioned = counts.get("UNDISPOSITIONED", 0)
    if not undispositioned:
        return True, ""
    return False, (f"{counts.get('mapped', 0)} of {len(rows)} specification item(s), with "
                   f"{undispositioned} never examined")


def published_surface_errors(product, cfg=None, notes=None):
    """[problems] where the ADS the contract PUBLISHES and the columns the engine EMITS disagree.

    THE FOURTH SIDE. `contract_binding` proves a record names real config; `published_name_errors`
    proves a settled name is one the catalog documents. Neither asks the plainest question of all:
    is the column in the product? `assemble.build` returns `ads.distinct()` with no final select, so
    the ADS is whatever the stages left on the frame — helper columns included — while the contract
    states, 202 times, exactly which columns it publishes and in what order. The list exists on both
    sides and nothing has ever compared them.

    TWO DIRECTIONS, and they are different defects:

      LEAKED   emitted, and no record publishes it. `treat_flag`, `f_death`, `dth_before_fued` are
               internal working columns; shipping them is the G-ADS-WHITELIST defect.
      MISSING  the contract promises a published column the build does not produce. Only counted
               when the record CLAIMS `implementation: implemented` — `engine_gap`, `config_gap`,
               `partial` and `not_implemented` are honest answers and are already carried as gaps.

    PROVENANCE STAMPS ARE NOT LEAKS, and the list of them is imported from the stage that adds them
    rather than respelled here — a second copy is how a fourth stamp would be reported as a leak.

    ACCOUNTED WHILE AN OUTPUT DECISION IS OPEN, the same allowance `raised_as_questions` gives an
    unclaimed config block. NAME-ALIGN is exactly this question — its own text says "the final ADS
    must be an approved ordered column whitelist" — so while it is open the divergence is raised and
    numbered, not overlooked. Once it resolves, every remaining difference is a defect.
    """
    notes = [] if notes is None else notes
    contract = os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(contract):
        return []
    text = read(contract)
    surface = published_surface(text)
    declared = {r["physical_name"] for r in surface if r["physical_name"]}
    nameless = [r["variable_id"] for r in surface if not r["physical_name"]]

    if cfg is None:
        root_cfg = os.path.join(product, "config", "data_product.yaml")
        # NO CONFIG AT ALL is not a failure — it is a pack that has done Gate 2 and not Gate 4, which
        # is prostate/202607 today. There is no build to compare a published surface against, and
        # reporting that as an error made `worksheet` print it in place of the section's own "nothing
        # was examined" line. A config that EXISTS and will not load is the opposite: something is
        # there and cannot be read, and that must fail closed.
        if not os.path.exists(root_cfg):
            return []
        try:
            from engine.config import load_config
            cfg = load_config(root_cfg, overrides={"run.refresh": "x", "run.source_schema": "x",
                                                   "run.output_schema": "x"})
        except Exception as e:                                    # noqa: BLE001
            return [f"cannot load the config to compare the published surface ({e}) — the ADS is "
                    f"unchecked against the contract, not passing"]
    try:
        from engine.stages.assemble import PROVENANCE_STAMPS
        from engine.validate import emitted_variables
        emitted = {str(v).lower() for v in emitted_variables(cfg)} - set(PROVENANCE_STAMPS)
    except Exception as e:                                        # noqa: BLE001
        return [f"cannot derive the emitted columns ({e}) — the ADS is unchecked, not passing"]

    impl = {}
    for block in records(text):
        nm = (_kv(_inline(block, "output"), "physical_name") or "").strip().lower()
        if nm:
            impl[nm] = _kv(_inline(block, "status"), "implementation")

    out = [f"{v}: role: published but the record states no physical_name — a published column with "
           f"no name" for v in nameless]
    open_output = [d for d in open_decisions(product) if d in OUTPUT_DECISIONS]
    leaked = sorted(emitted - declared)
    missing = sorted(n for n in (declared - emitted) if impl.get(n) == "implemented")
    if open_output and (leaked or missing):
        # ACCOUNTED, not clean and not an error — the same standing `raised_as_questions` gives an
        # unclaimed config block. Returned through `notes` so it is VISIBLE on every --check without
        # failing CI over a divergence a numbered, open decision already owns. A silent "0 issues"
        # here would be the worse answer: the whole point is that this was invisible.
        notes.append(f"published surface: {len(leaked)} emitted column(s) no record publishes and "
                     f"{len(missing)} implemented-and-published column(s) the build does not "
                     f"produce — ACCOUNTED to open output decision(s) "
                     f"{', '.join(sorted(open_output))}, which own this exact question. They become "
                     f"errors when it resolves.")
        # The NAMES, not just the counts. A count tells a reader there is work; the names are what
        # they act on, and they are what lets a test assert that a provenance stamp is not among
        # them — an assertion over the count alone passes whether or not the stamps are excluded.
        if leaked:
            notes.append(f"  emitted, unpublished: {', '.join(leaked[:12])}"
                         + (f" …+{len(leaked) - 12}" if len(leaked) > 12 else ""))
        if missing:
            notes.append(f"  published, not built: {', '.join(missing[:12])}"
                         + (f" …+{len(missing) - 12}" if len(missing) > 12 else ""))
        return out
    out += [f"published surface: {n} is emitted but no record publishes it — an internal column in "
            f"the delivered ADS" for n in leaked]
    out += [f"published surface: {n} is published and claims implementation: implemented, but the "
            f"build does not produce it" for n in missing]
    return out


def leaked_surface(product):
    """The emitted-but-unpublished column set, or None when there is nothing to compare (no
    contract or no config — a pack state, not a failure)."""
    contract = os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")
    root_cfg = os.path.join(product, "config", "data_product.yaml")
    if not (os.path.exists(contract) and os.path.exists(root_cfg)):
        return None
    text = read(contract)
    declared = {r["physical_name"] for r in published_surface(text) if r["physical_name"]}
    from engine.config import load_config
    from engine.stages.assemble import PROVENANCE_STAMPS
    from engine.validate import emitted_variables
    cfg = load_config(root_cfg, overrides={"run.refresh": "x", "run.source_schema": "x",
                                           "run.output_schema": "x"})
    emitted = {str(v).lower() for v in emitted_variables(cfg)} - set(PROVENANCE_STAMPS)
    return emitted - declared


def surface_ratchet(product, base, root):
    """[errors] — leaked columns that are NEW since `base` (red-team N2).

    The open-output-decision allowance above accounts for the divergence the decision was RAISED
    over — but those decisions stay open for the whole Gate-2 lifetime, so the allowance also hid
    any column that started leaking afterwards. A ratchet is a claim about CHANGE, so like the
    legacy allowlist it is checked against the base revision: the standing leak stays accounted,
    a NEW leak fails even while the decisions are open."""
    rel = repo_relative(os.path.abspath(product), root)
    now = leaked_surface(product)
    if now is None:
        return []
    import subprocess
    import tempfile
    with tempfile.TemporaryDirectory(prefix="rwdp_surface_") as td:
        wt = os.path.join(td, "base")
        r = subprocess.run(["git", "-C", root, "worktree", "add", "--detach", wt, base],
                           capture_output=True, text=True, encoding="utf-8")
        if r.returncode != 0:
            return [f"cannot materialise base revision {base!r} ({(r.stderr or '').strip()}) — "
                    f"the surface ratchet has no baseline, which is refused, not skipped"]
        try:
            was = leaked_surface(os.path.join(wt, rel))
        finally:
            subprocess.run(["git", "-C", root, "worktree", "remove", "--force", wt],
                           capture_output=True)
    if was is None:
        was = set()                       # the pack is new since base: every leak is new
    new = sorted(now - was)
    return [f"{rel}: {n} newly leaks since {base} — emitted and published by no record; the open "
            f"output decisions account for the standing divergence they were raised over, never "
            f"for a column that started leaking while they were open" for n in new]


def check(product, files):
    """(errors, stats). Errors are unresolvable refs and unclaimed blocks; stats are the coverage."""
    # No contract, nothing to bind: pre-Gate 2 packs crashed every caller of this (render_html's
    # flow page, demo's step 9, the --check CLI) with a raw FileNotFoundError. Absence of the
    # contract is Gate 2's finding, reported by status/gates; HERE it is vacuous, not a traceback.
    if not os.path.exists(os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")):
        return [], {"records": 0, "produces": 0, "annotated": 0, "claimed": 0, "blocks": 0}
    errors = []
    # A config naming an input the pack does not have is a defect in exactly the traceability this
    # tool checks — and governed_blocks() skips a missing file, so without this the effect of a
    # config pointing at a deleted or renamed pack is that its blocks quietly stop being governed.
    for rel in files:
        if not os.path.exists(os.path.join(product, rel)):
            errors.append(f"config/data_product.yaml composes {rel}, which does not exist in this "
                          f"pack — the build would read nothing for it")
    # THE FOURTH SIDE: is the column actually in the product? Reported here so a `--check` run shows
    # it without a second command; accounted while an output decision owns the question.
    surface_notes = []
    errors += published_surface_errors(product, notes=surface_notes)
    unreadable_files = {}
    blocks = governed_blocks(product, files, unreadable_files)
    for rel, why in sorted(unreadable_files.items()):
        errors.append(f"config/data_product.yaml composes {rel}, which is not readable YAML ({why}) "
                      f"— the build cannot read it and nothing it defines can be governed")
    claimed = set()
    symbols = engine_symbols()
    if symbols is None:
        errors.append("cannot locate platform/engine — engine refs are unchecked, not passing")
        symbols = set()
    else:
        # THE THIRD SIDE. The two loops below check that a name resolves between the CONTRACT and the
        # CONFIG; rename a block in both and they are satisfied while the engine, which reads the old
        # name, silently stops producing the variable. See `engine_config_keys`.
        for rel, _role, key, why in unread_config_blocks(product):
            errors.append(f"{rel}{'#/' + key if key else ''}: {why}")
    # THE FOURTH SIDE: the column a reader actually receives. `products_root` is derived from the
    # pack rather than passed, because every caller has the pack and none of them has the root.
    errors += published_name_errors(product, _products_root(product))
    recs = contract_records(product)
    annotated = [r for r in recs if r[2] is not None]
    # A producing record with no refs at all is the silent case: it passes because some OTHER record
    # happens to claim the same block, or because the work is engine-only and nothing is left
    # unclaimed to expose it. Optional for a draft record; required once it says it produces output.
    for vid, impl, refs in recs:
        if impl in PRODUCES and refs is None:
            errors.append(f"[{vid}] implementation:{impl} but no implementation_refs — a record that "
                          f"produces output must name where, or say [{NONE}] with a gap")

    for vid, impl, refs in annotated:
        if refs == [NONE]:
            if impl in PRODUCES:
                errors.append(f"[{vid}] implementation:{impl} but implementation_refs: [{NONE}] — "
                              f"something produces it, so something must be named")
            continue
        for ref in refs:
            if ref.startswith(ENGINE):
                sym = ref[len(ENGINE):]
                if symbols and sym not in symbols:
                    errors.append(f"[{vid}] engine ref '{sym}' is not a function the shared engine "
                                  f"defines — the requirement points at nothing")
                continue
            if "#/" not in ref:
                errors.append(f"[{vid}] '{ref}' is not `<path>#/<key>` or `{ENGINE}<symbol>`")
                continue
            rel, key = ref.split("#/", 1)
            if not os.path.exists(os.path.join(product, rel)):
                errors.append(f"[{vid}] '{ref}' names {rel}, which this pack does not have")
            elif rel not in files:
                # The file is THERE but the active config does not compose it. Before the binder
                # followed the config graph this could not arise — every YAML under variables/ and
                # codelists/ was in scope — and reporting it as "a block it does not define" would
                # send someone to look for a key that is very probably right where they left it.
                errors.append(f"[{vid}] '{ref}' names {rel}, which exists but is NOT composed by "
                              f"config/data_product.yaml — the build never reads it, so the "
                              f"requirement points at nothing that runs")
            elif ref not in blocks:
                errors.append(f"[{vid}] '{ref}' names a block {rel} does not define")
            else:
                claimed.add(ref)

    # A block that is a flat list of names — an emission manifest — is claimed by the records that
    # produce those names, not by one arbitrary record. Checking each entry against the contract's
    # outputs is stronger than exempting the key: it catches a build emitting something no record
    # requires, which is the same failure one level down.
    emitted = output_names(product)
    for ref, value in list(blocks.items()):
        if isinstance(value, list) and value and all(isinstance(v, str) for v in value):
            missing = [v for v in value if v.lower() not in emitted]
            if missing:
                errors.append(f"{ref}: emits {missing}, which no contract record names as an output")
            else:
                claimed.add(ref)

    # The direction nobody checks: config that governs the build with no requirement behind it.
    questioned = raised_as_questions(product)
    covered, of_items = spec_coverage(product)
    open_q = 0
    for ref in sorted(blocks):
        if ref in claimed:
            continue
        if ref in questioned:
            open_q += 1                      # accounted for by an OPEN decision, not by a record
            continue
        errors.append(f"{ref}: governed by the build but claimed by no contract record — either a "
                      f"record must name it, or it is behaviour nobody required"
                      if covered else
                      f"{ref}: governed by the build but claimed by no contract record. This "
                      f"contract accounts for {of_items} — so whether anything REQUIRES this block "
                      f"is not established here: the requirement may sit in a specification row "
                      f"nobody has drafted yet. Finish coverage before concluding it is unrequired.")

    produces = [r for r in recs if r[1] in PRODUCES]
    return errors, {"surface_notes": surface_notes,
                    "records": len(recs), "produces": len(produces), "annotated": len(annotated),
                    "blocks": len(blocks), "claimed": len(claimed), "questioned": open_q}


def flatten_values(value):
    """What a config block STATES: labels, code->label pairs, and bare members.

    Config blocks are not one shape: `age_bands` is a list of {code,label}, `regions` carries a
    `states` list per branch, `staging` uses `from_prefixes`. Comparing SHAPES would need a per-block
    reader; comparing the set of things a block names does not.

    Bare members matter most and were the omission: `states: [ME, VT, PR]` yielded NOTHING, so the
    state membership lists — the highest-volume values in the pack, and the ones the DE/'Implementation'
    corruption landed in — were never compared at all.
    """
    # A bare string is a MEMBER only inside a list. `when: fallthrough` and `predicate: state_is_null`
    # are scalar settings — reporting them as values the spec failed to state is noise, and noise is
    # what stops people reading the report.
    labels, pairs, members = set(), {}, set()

    def walk(v):
        if isinstance(v, dict):
            label = v.get("label") if isinstance(v.get("label"), str) else None
            if label:
                labels.add(label.strip().lower())
                if v.get("code") is not None:
                    pairs[str(v["code"])] = label.strip().lower()
            for k, x in v.items():
                if k not in ("label", "code"):
                    walk(x)
        elif isinstance(v, list):
            for x in v:
                if isinstance(x, str):
                    members.add(x.strip().lower())   # a membership IS a list of values
                else:
                    walk(x)

    walk(value)
    return labels, pairs, members


# ---------------------------------------------------------------------------------------------
# THE OTHER HALF OF A RECORD. `compare_enumerations` reads value LISTS. A window, a record-selection
# rule and a source table are not lists, and until this they were the part the module docstring
# handed back to "a person reading both sides" — which is to say, to nobody, every time.
#
# The two sides are declared to be governed SEPARATELY and on purpose: `BUILD_WIRING` excludes the
# `sources:` map from the binder because "sources [are governed] per record in each record's own
# `source:` mapping (Gate 3)". Two authorities over one table stem, and no check that they agree.
# t_enh_prostate_progression / t_enh_prostate_prog_scled and t_enh_prostate_lab / t_lab are both in
# this pack's history as corrections — the config was fixed against the Hive inventory, and nothing
# would have said if the contract had kept the old name.
#
# THE DIRECTION OF BITE, and the reason this is not a second enumeration comparison: the contract is
# the APPROVED statement of the requirement, so a config block that contradicts it is the finding.
# Where the contract is SILENT — `window: n/a`, or prose this cannot read — there is nothing to
# contradict, and no finding is emitted. Absence is never treated as disagreement.
# ---------------------------------------------------------------------------------------------

# The ONLY two window shapes this reads. A contract `window:` is free text and mostly IS free text:
# "rows 47/48 declare Time Period LOT_ECOG, defined at study_period:20", ">= line-end + 120",
# "[-30, +7] (row 74 pins this explicitly)". Reading every integer out of that would compare 47, 48,
# 20 and 74 against a config window — spec row numbers presented as day offsets. So two shapes that
# cannot be anything else, and everything else counted as UNREAD and reported as such.
OFFSET_PAIR = re.compile(r"\[\s*([+-]?\d+)\s*,\s*([+-]?\d+)\s*\]")
DURATION = re.compile(r"(?<![\w.])(\d+)\s*-?\s*(?:day|days|month|months|week|weeks|year|years)\b",
                      re.IGNORECASE)

# Config keys that hold a duration or an offset. The block's own top-level key counts, because a
# ref like `variables/outcomes.yaml#/visit_recency_days` IS the parameter — its value is the bare
# integer 120 and there is no inner key to read it from.
DURATION_KEY = re.compile(r"(?:^|_)(?:days|months|weeks|years)$|^window(?:_days)?$")

# Config keys that hold a record-selection direction — THREE spellings, because the packs use three
# (`baseline_ecog.tie_break`, `psa_timepoints.points[].pick`, `lab_values.panel[].tiebreak`). Reading
# one name would silently pass the other two.
SELECTOR_KEYS = ("tie_break", "tiebreak", "pick")

# Direction words, and what each one CONTRADICTS. Only opposites — `closest` is deliberately absent
# because nothing in this vocabulary is its opposite, so a record selecting "closest to index" makes
# no claim this check can refute.
#
# `prior` is here because leaving it out let a real flip through. The ECOG record does not use the
# word `earliest` at all — it says `record_selection: closest`, `tie_break: {equidistant: prior}` —
# so with `prior` unlisted, turning the config's `tie_break: earliest_date` into `latest_date`
# produced no finding: the vocabulary had nothing to contradict. That is the failure mode a
# word-list check has, and the only defence is that the list is derived from what the records
# actually say rather than from what reads like a complete set.
OPPOSITE = {"earliest": {"latest", "last"}, "latest": {"earliest", "first", "prior"},
            "first": {"latest", "last"}, "last": {"earliest", "first", "prior"},
            "prior": {"latest", "last"},
            "highest": {"lowest", "min"}, "lowest": {"highest", "max"},
            "max": {"min", "lowest"}, "min": {"max", "highest"}}

# `n/a` is an ANSWER — "this record has no window" — and so are these. Distinguishing them from an
# unanswered field is the whole point: a stated `n/a` is silence with a person behind it.
# `unknown` earns its place from the OC contract: INDEXDT carries
# `physical_stem: unknown, columns: {n/a: n/a}`, which is a record saying the source is not mapped
# yet, not a record naming a table called `unknown`. Reading it as a name reported an unmapped
# source as a missing table, which sends someone to fix the `sources:` map instead of the mapping.
NOT_STATED = {"", "n/a", "na", "none", "tbd", "todo", "unknown", "-"}


def _stated(value):
    return value is not None and str(value).strip().strip('"').lower() not in NOT_STATED


def _window_numbers(text):
    """(the offsets/durations the window field states, whether anything in it went unread)."""
    body = str(text or "")
    nums, read_spans = set(), []
    for m in OFFSET_PAIR.finditer(body):
        nums.update({int(m.group(1)), int(m.group(2))})
        read_spans.append(m.span())
    for m in DURATION.finditer(body):
        nums.add(int(m.group(1)))
        read_spans.append(m.span())
    # Anything OUTSIDE the spans this understood, that still looks like a number, is unread text.
    rest = body
    for lo, hi in sorted(read_spans, reverse=True):
        rest = rest[:lo] + " " * (hi - lo) + rest[hi:]
    return nums, bool(re.search(r"\d", rest))


def _config_numbers(node, key=None):
    """Every integer the block states under a key that NAMES a duration or an offset."""
    out = set()
    if isinstance(node, dict):
        for k, v in node.items():
            out |= _config_numbers(v, str(k))
    elif isinstance(node, list):
        for v in node:                       # a list INHERITS its key: `window_days: [-30, 7]`
            out |= _config_numbers(v, key)
    elif isinstance(node, bool):
        pass                                 # `tsst: true` is not a duration; bool is an int subclass
    elif isinstance(node, int) and key and DURATION_KEY.search(key):
        out.add(node)
    return out


def _config_selectors(node, key=None):
    """Every direction word the block states under a selection key."""
    out = set()
    if isinstance(node, dict):
        for k, v in node.items():
            out |= _config_selectors(v, str(k))
    elif isinstance(node, list):
        for v in node:
            out |= _config_selectors(v, key)
    elif isinstance(node, str) and key in SELECTOR_KEYS:
        out |= {w for w in re.split(r"[^a-z]+", node.lower()) if w in OPPOSITE}
    return out


def declared_stems(product):
    """({physical stem -> the logical source name the build resolves it under}, why not readable).

    The second half is not decoration. With an absent or unparsable `config/data_product.yaml` the
    map is empty, and an empty map makes EVERY stem in the contract look undeclared — thirty
    findings, each pointing at a real table, for one missing file. The caller reports the one cause
    instead.
    """
    path = os.path.join(product, "config", "data_product.yaml")
    doc, unreadable = read_yaml(path)
    if unreadable or not isinstance(doc, dict):
        return {}, unreadable or f"{repo_relative(path)} is not a mapping"
    if not isinstance(doc.get("sources"), dict):
        return {}, f"{repo_relative(path)} declares no `sources:` map"
    return ({str(v).strip(): str(k) for k, v in doc["sources"].items()
             if isinstance(v, (str, int))}, None)


def compare_parameters(product, blocks):
    """Contract-stated window / selection / source table vs the config that implements them.

    Three checks, each one a POSITIVE contradiction — a record that states nothing readable produces
    no finding, and the count of those is reported instead so the silence is visible rather than
    mistaken for agreement.

      source     `source.physical_stem` names a table the pack's `sources:` map does not declare.
                 The build reads the map; the requirement names the stem; a mismatch means the build
                 reads a table the approved requirement did not name.
      window     the offsets and durations the record states appear in NONE of the config blocks it
                 binds to. Many-to-one is normal (a record binds several blocks), so the number has
                 to be found in at least one of them, not in each.
      selection  the config states the OPPOSITE direction to the record and not the record's own.
                 Both present is not a contradiction: `lab_values` legitimately carries `lowest` for
                 five analytes and `highest` for five more, which is exactly what its record says.

    THE ALLOWANCE IS PER AXIS, not per record, and there is exactly one: a record whose REQUIREMENT
    is `decision_required` has its window and selection skipped, because a requirement the record
    itself calls unsettled has nothing settled for the config to contradict.

    Its SOURCE STEM is still checked even then: a stem nothing resolves is not a disagreement about
    a requirement, it is a table the build cannot open, and no open question about the derivation
    makes it readable. Skipping the whole record over an unrelated decision id was how the first
    version of this checked 3 of the pack's 9 stems and reported a clean result.
    """
    path = os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(path):
        return [], {"records": 0}
    stems, no_map = declared_stems(product)
    out, seen_stems, unread, checked, undecided, unbound, seen = [], {}, 0, 0, 0, 0, 0

    for block in records(read(path)):
        seen += 1
        vid = _scalar(block, "variable_id") or "?"
        refs = [r for r in (_list(block, "implementation_refs") or []) if "#/" in r and r in blocks]
        if not refs:
            # Nothing this record says can be compared to config, because it names none. Counted,
            # because 202 records and 56 comparisons is a ratio a reader should be told rather than
            # have to work out from two numbers that look like they cover everything.
            unbound += 1

        stem = _kv(_inline(block, "source"), "physical_stem")
        if _stated(stem):
            seen_stems.setdefault(str(stem).strip().strip('"'), []).append(vid)

        # ...and from here down, only the requirement axis, with ONE allowance: the record declaring
        # its own requirement unsettled.
        #
        # An OPEN DECISION NAMING THE BLOCK DELIBERATELY DOES NOT SILENCE THIS, and that is the same
        # call `compare_enumerations` makes one function below — "a decision naming this config
        # pointer covers its LABEL/CODE alignment, and only that. Skipping the whole ref here is what
        # let an open decision hide a rogue member." A window is data in the same way a member is.
        # Concretely: NAME-ALIGN, a decision about PUBLISHED NAMES, names
        # `variables/outcomes.yaml#/visit_recency_days` in its row, and silencing on that hid a
        # 120 -> 90 change to the visit-recency window — a question about what a column is called
        # covering an answer about how many days it counts.
        #
        # Nor does a decision id on the record: most records here carry one, usually about names or
        # cohort mapping, and honouring any of them dropped a third of the comparisons.
        if _kv(_inline(block, "status"), "requirement") == "decision_required":
            undecided += 1
            continue

        window = _scalar(block, "window")
        if _stated(window) and refs:
            nums, had_unread = _window_numbers(window)
            if nums:
                checked += 1
                have = set()
                for ref in refs:
                    have |= _config_numbers(blocks[ref], ref.split("#/", 1)[1])
                missing = sorted(n for n in nums if n not in have)
                if missing:
                    out.append(f"{vid}: the record's window states {missing}, and none of the "
                               f"config it binds to holds it — {sorted(refs)} state "
                               f"{sorted(have) or 'no duration or offset at all'}")
            elif had_unread:
                unread += 1

        selection = " ".join(str(v) for v in (_scalar(block, "record_selection"),
                                              _inline(block, "tie_break") or
                                              _scalar(block, "tie_break")) if _stated(v)).lower()
        wanted = {w for w in re.split(r"[^a-z]+", selection) if w in OPPOSITE}
        if wanted and refs:
            checked += 1
            have = set()
            for ref in refs:
                have |= _config_selectors(blocks[ref], ref.split("#/", 1)[1])
            for w in sorted(wanted):
                clash = sorted(OPPOSITE[w] & have)
                if clash and w not in have:
                    out.append(f"{vid}: the record selects '{w}' and the config it binds to selects "
                               f"{clash} and never '{w}' — {sorted(refs)}")

    if no_map and seen_stems:
        # ONE finding for one cause. Comparing every stem against an empty map would report each
        # real table as undeclared and send someone to add thirty entries that already exist.
        out.append(f"{len(seen_stems)} record-named source stem(s) could not be checked: {no_map}")
    elif not no_map:
        for stem, vids in sorted(seen_stems.items()):
            if stem not in stems:
                out.append(f"{stem}: named as physical_stem by {len(vids)} record(s) "
                           f"({', '.join(sorted(vids)[:4])}) and declared by no entry in this pack's "
                           f"`sources:` map — the build cannot read a table nothing resolves")

    return out, {"stems": 0 if no_map else len(seen_stems), "compared": checked, "records": seen,
                 "unread_windows": unread, "undecided": undecided, "unbound": unbound}


def enumerations_read(product):
    """What the spec-enumeration artifact actually YIELDED — {present, parsed, enumerations}.

    THREE STATES, AND ONLY ONE OF THEM WAS DISTINGUISHED. `compare_enumerations` returned `[]` for
    a missing file, an EMPTY file, an unparsable file and a file with the wrong root key alike, and
    the caller printed "0 difference(s) needing a person" — the agreement wording — for the last
    three. An external review found the missing-file case; emptying the file is worse, because the
    banner that names the missing artifact never fires and the run reads as a clean comparison.

    `read_yaml` returns `(None, err)` on a parse failure, so `(… or {})` collapsed a traceback into
    silence. Reported here instead: `parsed` is False when the file exists and yields no mapping,
    which is a different fact from an empty mapping and needs a different sentence.
    """
    path = os.path.join(product, "spec_pipeline", "out", "ENUMERATION_CANDIDATES.yaml")
    if not os.path.exists(path):
        return {"path": path, "present": False, "parsed": False, "enumerations": {}}
    doc, err = read_yaml(path)
    if err or not isinstance(doc, dict):
        return {"path": path, "present": True, "parsed": False, "enumerations": {}}
    return {"path": path, "present": True, "parsed": True,
            "enumerations": doc.get("enumerations") or {}}


def compare_enumerations(product, blocks):
    """Spec-stated enumerations vs the approved YAML that implements them.

    The candidates artifact records what the SPECIFICATION literally enumerates; the config holds what
    the build actually applies. Neither is authority over the other: a value in the spec and not in the
    YAML may be unimplemented, and a value in the YAML and not in the spec is behaviour someone added.
    BOTH are reported, and neither side is edited — the choice is a person's.

    An intentional difference is accounted for the same way an unclaimed block is: by an OPEN decision
    naming the config ref. That is what stops "we decided that" and "nobody noticed" looking alike.
    """
    cand = enumerations_read(product)["enumerations"]
    if not cand:
        return []

    # Which record cites the spec row, and therefore which config block should hold its values. Ranges
    # are EXPANDED: a family record citing `clinical:70-77` covers clinical:71, and keying on the
    # literal string would have reported the row as bound to nothing.
    by_ref = {}
    for block in records(read(os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md"))):
        declared = _list(block, "implementation_refs") or []
        impls = {i for i in declared if "#/" in i}
        # A record that declares NOTHING implements it — `[none]` plus a gap — has accounted for the
        # row. The *_TEST assay maps are exactly that: the spec enumerates them, no source field can
        # produce them, and the gap says so. Reporting "no record binds this" would be false.
        if declared == [NONE] and _list(block, "gap_ids"):
            for ref in _list(block, "spec_refs") or []:
                for domain, n in spec_ref_rows(ref):
                    by_ref.setdefault(f"{domain}:{n}", set()).add(NONE)
        if not impls:
            continue
        for ref in _list(block, "spec_refs") or []:
            for domain, n in spec_ref_rows(ref):
                by_ref.setdefault(f"{domain}:{n}", set()).update(impls)

    questioned = raised_as_questions(product)
    # An OPEN decision that NAMES the enumeration accounts for its differences too. CODE-ALIGN asks
    # RWB to confirm the demographics `99` fallback codes, which is exactly the difference the
    # comparison finds — reporting it again as unaccounted would be the register and the tool
    # disagreeing about a question already asked.
    open_text = " ".join(
        " ".join(row.values()) for did, row in decision_rows(
            read(os.path.join(product, "handoff", "DECISIONS.md"))
            if os.path.exists(os.path.join(product, "handoff", "DECISIONS.md")) else "").items()
        if decision_status(read(os.path.join(product, "handoff", "DECISIONS.md"))).get(did) == "OPEN"
    ).lower() if os.path.exists(os.path.join(product, "handoff", "DECISIONS.md")) else ""

    out = []
    for name, spec in sorted(cand.items()):
        # An open decision on an enumeration silences its LABEL and CODE differences — that is what
        # CODE-ALIGN is about. It never silences MEMBER differences: membership is data, and a rogue
        # value inside a list is precisely the corruption this repo has already had once, when an
        # unanchored replace turned the state code DE into the word "Implementation".
        # An OPEN decision accounts for this enumeration only if it names it EXPLICITLY: the
        # enumeration id as a whole word, its spec_ref, or the config pointer. A bare substring made
        # short names — sex, race, stage, response — match any unrelated question containing the word.
        asked = (re.search(rf"\b{re.escape(name.lower())}\b", open_text) is not None
                 or str(spec.get("spec_ref", "")).lower() in open_text)
        values = [v for v in (spec.get("values") or []) if isinstance(v, dict)]
        spec_labels = {str(v["label"]).strip().lower() for v in values if v.get("label")}
        spec_pairs = {str(v["code"]): str(v["label"]).strip().lower()
                      for v in values if v.get("code") is not None and v.get("label")}
        spec_members = {m.strip().lower() for v in values for m in (v.get("members") or [])}

        targets = by_ref.get(spec.get("spec_ref"), set())
        if targets == {NONE}:
            continue                          # declared not derivable, with a gap recording why
        targets = {r for r in targets if r != NONE}
        if not targets:
            out.append(f"{name} ({spec['spec_ref']}): the spec enumerates {len(values)} value(s) and "
                       f"no record binds that row to config")
            continue
        for ref in sorted(targets):
            if ref not in blocks:
                continue                      # not among the covered files
            # A decision naming this config pointer covers its LABEL/CODE alignment, and only that.
            # Skipping the whole ref here is what let an open decision hide a rogue member.
            ref_asked = asked or ref in questioned
            y_labels, y_pairs, y_members = flatten_values(blocks[ref])
            # TWO DIFFERENT FINDINGS, which read as one.
            #
            # A block that enumerates something ELSE is a disagreement: two lists, and somebody has to
            # say which is right. A block that enumerates NOTHING is not a disagreement at all — it is
            # a rule or a scalar, `min_followup_days: 90`, and the spec's codes are not in it because
            # there is nowhere in it for them to be. The second is answered by deciding where the
            # values belong, or that the field publishes no codes; the first by reading two lists.
            #
            # Reported separately because emitting one "the YAML does not state these" line for both
            # sends a reader to compare a codelist against an integer. The three published flags on
            # prostate — VIS120, ELIGPFS, PFSFL — are all the second kind.
            if not (y_labels or y_pairs or y_members):
                if not ref_asked:
                    out.append(f"{name} ({spec['spec_ref']}) vs {ref}: the spec enumerates "
                               f"{len(values)} value(s); that config block enumerates NOTHING — it "
                               f"holds the rule, not a code list. Either the values belong somewhere "
                               f"else, or this field publishes no codes; both are a decision, not a "
                               f"value-by-value comparison.")
                continue
            for kind, only_spec, only_yaml in (
                    ("label", spec_labels - y_labels, y_labels - spec_labels if spec_labels else set()),
                    ("member", spec_members - y_members,
                     y_members - spec_members if spec_members else set())):
                if ref_asked and kind == "label":
                    continue
                if only_spec:
                    out.append(f"{name} ({spec['spec_ref']}) vs {ref}: spec states {kind}(s) "
                               f"{sorted(only_spec)[:8]} the approved YAML does not")
                if only_yaml:
                    out.append(f"{name} ({spec['spec_ref']}) vs {ref}: the approved YAML adds {kind}(s) "
                               f"{sorted(only_yaml)[:8]} the spec does not state — an addition needs an "
                               f"approved requirement or decision behind it")
            # A code re-pointed at a different label is the difference labels alone cannot see:
            # 1=Positive 2=Negative 3=VUS and 1=Positive 3=Negative 2=VUS have identical label sets.
            if not ref_asked and spec_pairs:
                regraded = sorted(f"{c}: spec={l}, yaml={y_pairs[c]}"
                                  for c, l in spec_pairs.items() if c in y_pairs and y_pairs[c] != l)
                if regraded:
                    out.append(f"{name} ({spec['spec_ref']}) vs {ref}: code(s) mapped to a different "
                               f"label — {regraded[:6]}")
                missing = sorted(f"{c}={l}" for c, l in spec_pairs.items() if c not in y_pairs)
                if missing:
                    out.append(f"{name} ({spec['spec_ref']}) vs {ref}: the spec states code(s) "
                               f"{missing[:6]} the approved YAML does not assign")
                added = sorted(f"{c}={l}" for c, l in y_pairs.items() if c not in spec_pairs)
                if added:
                    out.append(f"{name} ({spec['spec_ref']}) vs {ref}: the approved YAML assigns "
                               f"code(s) {added[:6]} the spec does not state")
    return out


def promote(product, blocks):
    """CANDIDATE VALUES the spec states, shaped for the config block the contract binds them to.

    Not paste-ready executable YAML, and calling it that would overstate it: the engine's own key for
    a membership list is `states`, not the neutral `members` emitted here, and the block still needs
    the codes and fallthrough the spec never states. It carries the VALUES so nobody retypes them.

    This is the mechanical half of contract -> config. Every value here was lifted from the spec row
    the record cites, so nobody retypes fifty-two state codes — retyping is how `DE` became the word
    `Implementation` in this repo. What the spec does NOT state is emitted as a named gap rather than
    invented: numeric codes for membership branches, fallthrough behaviour, missing-value codes,
    operators, source mappings and output names are judgment, and a generator that guessed them would
    guess silently.

    It proposes; it never writes into `variables/`. A block that already exists carries decisions a
    person made — prostate's `code: 99 Unknown (fallthrough)` is not in the spec and is the subject of
    an open decision — and overwriting it would erase the judgment this whole pipeline exists to
    protect. Existing blocks are reported as a comparison instead (`--enumerations`).
    """
    path = os.path.join(product, "spec_pipeline", "out", "ENUMERATION_CANDIDATES.yaml")
    if not os.path.exists(path):
        return []
    cand = (read_yaml(path)[0] or {}).get("enumerations") or {}
    by_ref = {}
    for block in records(read(os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md"))):
        impls = {i for i in (_list(block, "implementation_refs") or []) if "#/" in i}
        for ref in (_list(block, "spec_refs") or []) if impls else []:
            for domain, n in spec_ref_rows(ref):
                by_ref.setdefault(f"{domain}:{n}", set()).update(impls)

    out = []
    for name, spec in sorted(cand.items()):
        targets = sorted(by_ref.get(spec.get("spec_ref"), set()))
        values = [v for v in (spec.get("values") or []) if isinstance(v, dict)]
        if not targets or not values:
            continue
        if len(targets) > 1:
            out.append(f"# {name}  <-  {spec['spec_ref']}\n"
                       f"#   MULTIPLE TARGETS {targets} — a person chooses which block these values "
                       f"belong to; picking the first would be a silent decision")
            continue
        target = targets[0]
        exists = target in blocks
        lines = [f"# {name}  <-  {spec['spec_ref']}  ->  {target}",
                 f"#   {'ALREADY PRESENT — compare, do not paste over it' if exists else 'NOT YET IN THE PACK — paste and fill the gaps below'}"]
        gaps = []
        if spec.get("numeric_codes") == "not_stated_by_the_spec":
            gaps.append("numeric codes for each branch")
        # A `Missing` predicate is not a terminal else: a value that is present but matches no branch
        # still has undefined behaviour, so the gap is named whether or not a predicate exists.
        gaps.append("behaviour for a value that matches no branch (terminal fallthrough)")
        gaps.append("the engine's own key names for this block (e.g. `states`, not `members`)")
        for g in gaps:
            lines.append(f"#   NOT STATED BY THE SPEC, you must decide: {g}")
        key = target.split("#/", 1)[1]
        lines.append(f"{key}:")
        for v in values:
            item = {}
            if v.get("code") is not None:
                item["code"] = v["code"]
            item["label"] = v.get("label", "")
            if v.get("members"):
                item["members"] = v["members"]
            if v.get("predicate"):
                item["when"] = v["predicate"]
            body = ", ".join(f"{k}: {json.dumps(x) if isinstance(x, (list, str)) else x}"
                             for k, x in item.items())
            lines.append(f"  - {{{body}}}")
        out.append("\n".join(lines))
    return out


def main(argv):
    ap = argparse.ArgumentParser(description="Bind contract records to the executable YAML they are implemented in.")
    ap.add_argument("product")
    ap.add_argument("--cover", action="append", default=[],
                    help="pack-relative YAML whose blocks must each be claimed (repeatable). "
                         "Default: every executable YAML in the pack.")
    ap.add_argument("--check", action="store_true", help="exit non-zero on any error")
    # NOT "emit the executable YAML", which is what this said and what `promote()`'s own docstring
    # spends a paragraph denying: the engine's key for a membership list is `states`, not the neutral
    # `members` emitted here, and the block still lacks the codes and fallthrough the spec never
    # states. Someone reading the old help would paste the output and find it does not run — and the
    # more expensive reading is the other one, that a block which looks executable has been checked.
    ap.add_argument("--promote", action="store_true",
                    help="print CANDIDATE VALUES the spec states, shaped toward the config block "
                         "each is bound to, for a person to finish. NOT runnable YAML: the key "
                         "names are neutral and the codes, fallthrough and missing-value handling "
                         "the spec does not state are emitted as named gaps, never guessed. Writes "
                         "nothing — an existing block holds decisions a person made.")
    ap.add_argument("--enumerations", action="store_true",
                    help="also compare spec-stated value lists against the approved YAML (reports "
                         "differences for a person; never edits either side)")
    ap.add_argument("--parameters", action="store_true",
                    help="also compare the record-stated window, record selection and source table "
                         "against the config that implements them (the non-enumeration half)")
    ap.add_argument("--surface-base", metavar="REV",
                    help="ratchet: fail on emitted-but-unpublished columns NEW since REV — the "
                         "open-output-decision allowance covers the standing divergence, never "
                         "growth")
    a = ap.parse_args(argv)

    product = os.path.abspath(a.product)
    if a.surface_base:
        root = os.path.dirname(_products_root(product))
        bad = surface_ratchet(product, a.surface_base, root)
        for e in bad:
            print(f"  {e}")
        if bad:
            print(f"{len(bad)} new published-surface leak(s) since {a.surface_base}")
            return 1
        # "OK" WHEN THERE WAS NO SURFACE TO RATCHET is the same absence-as-clean shape one flag
        # over: `leaked_surface` returns None for a pack with no contract OR no config, and the
        # caller printed "no new leak" — indistinguishable from a pack whose surface genuinely did
        # not grow. Say which it was.
        #
        # NOT-STARTED AND BROKEN ARE DIFFERENT, and only one of them is a defect. A pack with no
        # contract has not begun drafting — a legitimate pre-Gate-2 state that ten scaffold packs
        # are in, reported loudly by the binding check itself and not this one's business. A pack
        # that HAS a contract and no config is a contract governing nothing, which nothing else
        # catches, so that one fails.
        now = leaked_surface(product)
        if now is None:
            has_contract = os.path.exists(os.path.join(product, "handoff",
                                                       "FUNCTIONAL_CONTRACT.md"))
            has_config = os.path.exists(os.path.join(product, "config", "data_product.yaml"))
            if has_contract and not has_config:
                print(f"NOTHING RATCHETED — {os.path.basename(product)} states a contract and has "
                      f"no config/data_product.yaml, so its published surface cannot be computed "
                      f"and no leak COULD be detected since {a.surface_base}. A contract that "
                      f"governs no configuration is the defect, not the ratchet.")
                return 1
            print(f"nothing ratcheted — {os.path.basename(product)} has no contract yet, so it "
                  f"publishes no surface a leak could appear in. Drafting has not started; that is "
                  f"Gate 2's finding, not this ratchet's.")
            return 0
        print(f"OK — no new published-surface leak since {a.surface_base} "
              f"({len(now)} published column(s) compared)")
        return 0
    cover = a.cover or pack_yaml(product)
    errors, s = check(product, cover)

    # NO CONTRACT IS NOT AN EMPTY ONE. `check` returns a vacuous zero for a pre-Gate-2 pack, on
    # purpose — the absence is Gate 2's finding, not a traceback here — but printing that zero
    # through the ordinary summary reads as "this pack has no config to govern", and mcrc has 26
    # governed blocks and no records to claim them. Two different states, one line of output.
    no_contract = None
    if not os.path.exists(os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")):
        _blocks = len(governed_blocks(product, cover))
        print(f"{os.path.basename(product)}: no handoff/FUNCTIONAL_CONTRACT.md — drafting has not "
              f"started, so there is nothing to bind AGAINST. This is not a clean binding: the pack "
              f"composes {_blocks} governed config block(s), and no "
              f"record claims any of them. Gate 2 owns that; see `product_gates.py --report`.")
        # ...AND THE EXIT CODE NOW AGREES WITH THAT SENTENCE. It did not. The paragraph above was
        # added precisely because "no contract" and "a clean binding" are different states, and then
        # the run returned 0 anyway — so `demo.py`, which reads the exit code, printed
        # "PASS — the contract and the config are bound" for a pack with 26 governed blocks and no
        # contract at all. A message that says one thing while the status says another is the worse
        # half of a silent pass: it reassures the reader that somebody looked.
        no_contract = (f"binding: {product} has no handoff/FUNCTIONAL_CONTRACT.md, so no record "
                       f"claims any of its {_blocks} governed config block(s) — nothing was bound, "
                       f"and nothing could be")
        # ...and then carry on, rather than returning here. Someone who asked for `--promote` asked
        # about the proposal, and answering with a sentence about the contract leaves them without
        # the thing they ran the command for.
    else:
        print(f"{os.path.basename(product)}: {s['records']} record(s), {s['produces']} of which "
              f"produce output; {s['annotated']} carry implementation_refs")
        print(f"covered config: {s['claimed']}/{s['blocks']} governed block(s) claimed by a record"
              + (f", {s['questioned']} raised as an OPEN decision" if s.get("questioned") else ""))
    for _n in s.get("surface_notes") or []:
        print(f"  {_n}")
    for e in errors:
        print(f"  {e}")
    diffs = []
    # EVERY REQUESTED COMPARISON THAT COMPARED NOTHING, so `--check` can refuse to call it a pass.
    # The exit expression read `errors or diffs` — both empty when there was nothing to compare —
    # so a pack with no contract, no extraction or a broken artifact exited 0 under the flag CI
    # reads as proof. An absence reported as a clean result is the failure this repository has
    # fixed in four other tools; this was the fifth.
    vacuous = []
    if no_contract:
        vacuous.append(no_contract)
    if a.enumerations:
        diffs = compare_enumerations(product, governed_blocks(product, cover))
        # Same distinction the parameter block below draws, for the same reason: this compares the
        # spec's enumerations against the config, and returns nothing at all when the extraction has
        # never been generated. "0 difference(s)" for a pack whose spec nothing has read is silence
        # printed as agreement.
        er = enumerations_read(product)
        rel = repo_relative(er["path"])
        if not er["present"]:
            vacuous.append(f"enumerations: {rel} does not exist")
            print(f"\nenumerations: NOTHING COMPARED — {rel} does not exist, so no "
                  f"spec enumeration has been read for this pack. Generate it with the spec "
                  f"pipeline (a registered source is the precondition).")
        elif not er["parsed"]:
            # WORSE THAN ABSENT, and it used to print as agreement. An unparsable or wrong-rooted
            # artifact means the file is THERE, so the missing-file banner never fires, and the
            # comparison silently ran over nothing.
            vacuous.append(f"enumerations: {rel} does not parse to a mapping")
            print(f"\nenumerations: NOTHING COMPARED — {rel} exists but does not parse to a "
                  f"mapping, so no enumeration was read from it. This is not agreement; it is a "
                  f"broken artifact wearing agreement's number.")
        elif not er["enumerations"]:
            vacuous.append(f"enumerations: {rel} holds no `enumerations:` entries")
            print(f"\nenumerations: NOTHING COMPARED — {rel} parses but holds no `enumerations:` "
                  f"entries, so this pack's spec enumerates nothing that could be compared.")
        else:
            print(f"\nenumerations: {len(diffs)} difference(s) needing a person "
                  f"({len(er['enumerations'])} spec enumeration(s) read)")
        for d in diffs:
            print(f"  {d}")
    if a.parameters:
        pdiffs, pstats = compare_parameters(product,
                                            governed_blocks(product, a.cover or pack_yaml(product)))
        diffs += pdiffs
        # A ZERO THAT COMPARED NOTHING IS NOT A PASS, and must not print like one. OC's contract is
        # five records, every one `decision_required` and every one binding `[none]` — so "0
        # contradictions" over 33 governed config blocks is the absence-reported-as-a-clean-result
        # shape, not agreement. Say which it is before the number.
        if not pstats.get("records"):
            vacuous.append("parameters: the pack states no contract records")
            print("\nparameters: NOTHING COMPARED — this pack states no contract records at all, "
                  "so it states no window, no record selection and no source table for the config "
                  "to be checked against.")
        elif not (pstats.get("compared") or pstats.get("stems")):
            vacuous.append(f"parameters: none of {pstats['records']} record(s) bound a comparable "
                           f"window, selection or source stem")
            print(f"\nparameters: NOTHING COMPARED — of {pstats['records']} record(s), "
                  f"{pstats.get('unbound', 0)} bind no config block and "
                  f"{pstats.get('undecided', 0)} declare `requirement: decision_required`, and no "
                  f"record names a source stem. This pack's window, selection and source table are "
                  f"unchecked, not agreed.")
        else:
            print(f"\nparameters: {len(pdiffs)} contradiction(s) needing a person "
                  f"({pstats.get('compared', 0)} window/selection field(s) compared, "
                  f"{pstats.get('stems', 0)} source stem(s) checked)")
        if pstats.get("records"):
            print(f"  not compared: {pstats.get('undecided', 0)} record(s) declare the requirement "
                  f"undecided, {pstats.get('unbound', 0)} bind no config block, and "
                  f"{pstats.get('unread_windows', 0)} window(s) are prose this does not read — "
                  f"those stay a person's to compare")
        for d in pdiffs:
            print(f"  {d}")
    if a.promote:
        props = promote(product, governed_blocks(product, cover))
        print(f"\n--- CANDIDATE VALUES from the spec, for a person to shape ({len(props)} block(s)) "
              f"---------------------------------")
        # AN EMPTY PROPOSAL HAS TWO CAUSES AND THEY NEED DIFFERENT ACTIONS. `promote` reads the
        # spec's own enumerations out of ENUMERATION_CANDIDATES.yaml and returns [] when the file is
        # not there, which is the state of every pack whose source is not registered yet — so
        # "0 block(s)" alone tells someone their spec enumerates nothing, when in fact nothing has
        # read their spec. Name the missing artifact and the command that makes it.
        if not props:
            cands = os.path.join(product, "spec_pipeline", "out", "ENUMERATION_CANDIDATES.yaml")
            if not os.path.exists(cands):
                print(f"  nothing to propose: {repo_relative(cands)} does not exist, so no spec "
                      f"enumeration has been read for this pack. That artifact comes from the spec "
                      f"pipeline, which needs a REGISTERED source — see the pack's prog_spec/"
                      f"README.md, then: platform/tools/run_spec_pipeline.sh {a.product}")
            else:
                print("  nothing to propose: the extraction holds no enumeration bound by a record "
                      "to a single config block. `--enumerations` reports the ones already present.")
        for block in props:
            print(block + "\n")
    print(f"\n{len(errors) + len(diffs)} unaccounted issue(s)")
    # A COMPARISON THAT COMPARED NOTHING IS NOT A PASS. Reported before the exit so the reason is on
    # the same screen as the number, and folded into `--check` so CI cannot read silence as proof.
    if vacuous:
        print("\nNOTHING WAS COMPARED — this run proves nothing about this pack:")
        for v in vacuous:
            print(f"  ! {v}")
        print("  `0 issue(s)` above counts differences among the things that WERE compared, and "
              "nothing was. Fix the named artifact, or run without the flag that asked for a "
              "comparison this pack cannot yet support.")
    return 1 if (a.check and (errors or diffs or vacuous)) else 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
