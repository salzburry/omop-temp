#!/usr/bin/env python3
"""Build ANY configured product's ADS on a local Spark, on synthetic sources, and print it.

    python3 platform/tools/local_smoke.py products/oncology/prostate/202606
    python3 platform/tools/local_smoke.py <pack> --evidence-out ~/rwdp-views/build.json

    pip install pyspark pyyaml     # a local in-process Spark; needs Java 17 or 21 on PATH

Proves the shared engine assembles that product end-to-end — sources → LOT → index → demographics →
clinical → treatment → outcomes → assemble → cohort union — with no cluster and no vendor data. The
real run is the SAME shared engine and the SAME SCIENTIFIC configuration pointed at delivered tables
through the Databricks bundle — with the real delivery bindings, not the synthetic ones below. The
run half is exactly the half Gate 3 governs, so "the same configuration" is true of the science and
false of the delivery.

TAKES A PACK. This was `tools/smoke_prostate.py` with `SLUG = "prostate"` written into it, at the
repository root, outside `platform/tools/` where every other tool lives. A tumour name in shared code
is a latent failure for the next product, and a demo that only ever runs one of them is a demo of one
of them.

AND IT IMPORTS ITS FIXTURES rather than carrying them. The old file said in its own docstring that
the synthetic-source builders were "copied verbatim" from the smoke suite; by the time anyone
compared, `_synth_src` was 37 lines here against 48 there. So the thing being shown on a screen was
built from a dataset CI does not test. One definition now lives in
`platform/tests/fixtures/synthetic_sources.py` and both callers read it.

SYNTHETIC IS A DEVELOPMENT AID, NOT EVIDENCE. Nothing this prints is Gate 3 or Gate 5 evidence: the
rows are fabricated here, and `--evidence-out` writes a build SUMMARY for the flow page, which
labels it synthetic on its face.
"""
import argparse
import json
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, os.path.join(ROOT, "platform"))
sys.path.insert(0, os.path.join(ROOT, "platform", "tests", "fixtures"))
sys.path.insert(0, TOOLS)
import console                                                    # noqa: E402
from spec_extract import repo_relative                                  # noqa: E402

import pack_run                                                      # noqa: E402 — ONE outside-the-checkout guard

# Enough of a delivery to resolve table names; nothing is read from them, since the frames are built
# in memory. Named here so the run does not depend on a pack having been pointed at a real cut.
SYNTHETIC_RUN = {"run.refresh": "synthetic", "run.source_schema": "synthetic",
                 "run.output_schema": "synthetic"}


def build(pack, telemetry=None):
    """(cfg, ads) for `pack` on synthetic sources, through the production entry point."""
    import synthetic_sources
    from engine import build_ads
    from engine.config import load_config
    cfg = load_config(os.path.join(pack, "config", "data_product.yaml"), overrides=SYNTHETIC_RUN)
    spark = synthetic_sources.session("local-smoke")
    return cfg, build_ads.build_from_sources(synthetic_sources.sources(spark, cfg), cfg,
                                             telemetry=telemetry)


def summarise(cfg, ads):
    """The build, as plain data. ONE Spark action — `count()`, `distinct().collect()` and
    `limit().collect()` each re-ran the whole cohort-union plan, three times over."""
    cols = list(ads.columns)
    rows = ads.collect()
    show = [c for c in ("patientid", "index_date", "cohort", "cohortn", "cohortu", "stage",
                        "stagen", "data_product_id", "spec_version", "data_refresh") if c in cols]
    from pyspark.sql import SparkSession
    return {"rows": len(rows), "columns": len(cols), "column_list": cols,
            "cohorts_configured": [c["id"] for c in cfg.cohorts],
            "cohorts": sorted({r["cohort"] for r in rows if r["cohort"]}),
            "sample_cols": show, "sample": [[str(r[c]) for c in show] for r in rows[:8]],
            "spark": SparkSession.getActiveSession().version}


def binding(pack):
    """What this build WAS — so a page cannot describe someone else's build as this pack's.

    A summary alone says "4 rows, 187 columns" and nothing about whose. Attached to the wrong pack,
    an older commit, a changed configuration or — worst — a REAL-data run, the page would still
    caption it "the same configuration above, on SYNTHETIC sources". `render_html` refuses on any
    mismatch, so the caption is a checked claim rather than a sentence.

    `source_mode` is stated by the PRODUCER, and only this tool produces it: nothing else can write
    `synthetic` truthfully, and a page that accepted an unstated mode would accept a live build.
    """
    import product_gates as pg
    rel = repo_relative(pack, ROOT)
    git = console.run(["git", "-C", ROOT, "rev-parse", "HEAD"])
    dirty = console.run(["git", "-C", ROOT, "status", "--porcelain"])
    return {"pack": rel,
            "source_mode": "synthetic",
            "git_commit": (git.stdout.strip() if git.returncode == 0 else "unstated"),
            # A dirty tree means the digests below describe files nobody can retrieve by commit.
            "git_clean": bool(git.returncode == 0 and not dirty.stdout.strip()),
            "platform_version": open(os.path.join(ROOT, "platform", "VERSION"),
                                     encoding="utf-8").read().strip(),
            "science_digest": pg.config_bundle_sha256(pack),
            # THE COMMITTED DELIVERY, AND WHAT THE RUN ACTUALLY USED — two different things, and
            # calling one by the other's name is the whole problem this field had.
            #
            # `delivery_sha256(pack)` reads the pack as committed, where prostate still says
            # `refresh: REPLACE_ME`. The synthetic run does not use that: it overrides refresh,
            # source_schema and output_schema to `synthetic`. Recording only the committed digest
            # and letting the page caption the build "the same configuration above" made a true
            # statement about the SCIENCE stand in for a false one about the DELIVERY.
            #
            # Both are recorded. The renderer checks the committed one (that is what "this page is
            # drawn from the same checkout" means) and captions the effective one honestly.
            "committed_delivery_digest": pg.delivery_sha256(pack),
            "effective_run_bindings": {k.split(".", 1)[1]: v for k, v in SYNTHETIC_RUN.items()}}


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack", help="the pack directory")
    ap.add_argument("--evidence-out", help="write the build summary here, for "
                                           "`render_html.py flow --evidence`. Refused inside the "
                                           "checkout, like every other generated report.")
    ap.add_argument("--stage-telemetry", action="store_true",
                    help="print per-stage join telemetry (engine.telemetry): index vs stage-output "
                         "patient counts and per-patient fan-out, per cohort. Evidence a person "
                         "reads, never a verdict; costs one extra Spark action. Synthetic rows, so "
                         "the NUMBERS mean nothing here — what this shows locally is the SHAPE of "
                         "what the same flag records in a governed run's manifest.")
    a = ap.parse_args(argv)
    pack = os.path.abspath(a.pack)
    if not os.path.exists(os.path.join(pack, "config", "data_product.yaml")):
        sys.exit(f"{a.pack}: no config/data_product.yaml — not a product pack")
    try:
        import pyspark                                              # noqa: F401
    except ImportError:
        sys.exit("pyspark not installed — run:  pip install pyspark pyyaml   "
                 "(needs Java 17 or 21 on PATH)")

    collector = None
    if a.stage_telemetry:
        from engine.telemetry import StageTelemetry
        collector = StageTelemetry()
    cfg, ads = build(pack, telemetry=collector)
    s = summarise(cfg, ads)
    print("=" * 72)
    print(f"product : {cfg.raw.get('name')}   spec {cfg.spec_version}")
    print(f"vendor  : {cfg.raw.get('vendor')} / {cfg.raw.get('tumor_class')}")
    print(f"cohorts : {len(s['cohorts_configured'])} configured -> {s['cohorts_configured']}")
    print(f"sources : {sorted(cfg.sources)}")
    print("=" * 72)
    print("\n### ADS BUILT — synthetic sources, local Spark, NO cluster ###")
    print(f"rows     : {s['rows']}")
    print(f"columns  : {s['columns']}")
    # CONFIGURED and POPULATED are different numbers and the difference is the point: a cohort with
    # no synthetic patient produces no row, and reporting only the first would overstate the build.
    print(f"cohorts  : {len(s['cohorts'])} populated of {len(s['cohorts_configured'])} configured "
          f"-> {s['cohorts']}")
    if s["sample"]:
        print("\n" + " | ".join(s["sample_cols"]))
        for row in s["sample"][:6]:
            print(" | ".join(row))
    print(f"\nfirst 30 columns:\n  {', '.join(s['column_list'][:30])}")
    print("\nSynthetic sources. This proves the configuration assembles and executes; it says "
          "nothing about delivered data and is not evidence at any gate.")

    if collector is not None:
        rep = collector.report()
        print("\n### STAGE TELEMETRY — synthetic counts; the shape, not the facts ###")
        hdr = ("cohort", "stage", "idx_pts", "matched", "unmatched", "outside", "rows_out",
               "max/pt")
        keys = ("cohort", "stage", "index_patients", "matched_patients",
                "unmatched_index_patients", "patients_outside_index", "rows_out",
                "max_rows_per_index_patient")
        widths = [max(len(h), *(len(str(r[k])) for r in rep["stages"])) if rep["stages"]
                  else len(h) for h, k in zip(hdr, keys)]
        print("  " + "  ".join(h.ljust(w) for h, w in zip(hdr, widths)))
        for r in rep["stages"]:
            print("  " + "  ".join(str(r[k]).ljust(w) for k, w in zip(keys, widths)))
        if rep["selections"]:
            print("\n  selections (closest-panel families; other pick families not yet measured):")
            shdr = ("cohort", "block", "item", "cand", "pts", "ties", "tie_rows", "non_null",
                    "rows")
            skeys = ("cohort", "block", "item", "candidate_rows", "patients_with_candidates",
                     "tied_same_date_keys", "tied_rows", "non_null_outputs", "output_rows")
            sw = [max(len(h), *(len(str(r.get(k, ""))) for r in rep["selections"]))
                  for h, k in zip(shdr, skeys)]
            print("  " + "  ".join(h.ljust(w) for h, w in zip(shdr, sw)))
            for r in rep["selections"]:
                print("  " + "  ".join(str(r.get(k, "")).ljust(w) for k, w in zip(skeys, sw)))
        for line in rep["skipped"]:
            print(f"  SKIPPED: {line}")
        for line in rep["observations"]:
            print(f"  OBSERVATION: {line}")

    if a.evidence_out:
        out = os.path.join(
            pack_run.restricted_dir(os.path.dirname(os.path.abspath(a.evidence_out)),
                                    what="report"),
            os.path.basename(a.evidence_out))
        os.makedirs(os.path.dirname(out), exist_ok=True)
        with open(out, "w", encoding="utf-8") as fh:
            json.dump({**binding(pack), "gate5": s}, fh, indent=1)
        print(f"\nevidence -> {out}")
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
