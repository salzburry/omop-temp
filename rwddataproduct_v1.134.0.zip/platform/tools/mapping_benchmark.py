#!/usr/bin/env python3
"""Benchmark the mapping copilot against packs whose answers are already known.

    python3 platform/tools/mapping_benchmark.py                          # every benchmarkable pack
    python3 platform/tools/mapping_benchmark.py --pack products/oncology/prostate/202606
    python3 platform/tools/mapping_benchmark.py --format json

Method: leave-one-out over a pack's approved `sources:` map. Remove one declared, referenced
role from a throwaway copy. Hand the copilot a profile built from the same synthetic schemas the
smoke uses. Score its ranking against the mapping the pack really ships: top-1, top-3, and the
unsafe rate.

Limits: the synthetic schemas come partly from `required_columns`, so the true table carrying
its own columns is by construction. What is really measured is DISCRIMINATION — picking the
right table out of all delivered tables, not a wrong one or a tie.

Two layers, kept apart on purpose. ENGINEERING (scored here): table selection from schema
evidence; the ground truth is a fact. CLINICAL (never scored, by anything): whether a column
MEANS the requirement has no mechanical ground truth — RWP approval is what makes a mapping
right. The report emits zero clinical numbers.

UNSAFE is the number to watch: the copilot said `map_candidate` and named the WRONG table.
Abstaining costs review time; confident wrongness costs a mismapped product. Never sum the two.

Spark required. No vendor data, no network, no model.
"""
import argparse
import json
import os
import shutil
import sys
import tempfile

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)
sys.path.insert(0, os.path.join(ROOT, "platform"))
sys.path.insert(0, os.path.join(ROOT, "platform", "tests", "fixtures"))

import propose_source_mapping as psm                                  # noqa: E402
from engine.config import load_config                                 # noqa: E402
from engine import validate as ev                                     # noqa: E402

CUT = "2026m06"
import profile_io                                                     # noqa: E402

HDR = "\t".join(profile_io.REQUIRED)      # the TSV vocabulary has ONE owner

# The measured baseline, held as FLOORS. `unsafe` failing the run was necessary but not
# sufficient: a copilot that abstained on every role would report 0 unsafe and pass — 100%
# abstention scores as perfect safety while delivering nothing (an external review named the
# hole). So a benchmarked pack also fails when discrimination falls below what the ranking
# demonstrably achieves today, or when abstention grows past what it demonstrably needs.
# Raising a floor when the ranking improves is routine; LOWERING one is accepting a regression
# and needs the same scrutiny as any other governed change.
FLOORS = {
    # Measured UNDER the near-miss decoys (the default run). The stage-declared evidence bars
    # raised the numbers past the undecoyed baseline: the engine-known columns (mortality's
    # dateofdeath, demographics' birthyear...) let the truth table out-rank its own shadow on
    # evidence instead of resting on name overlap.
    "products/oncology/prostate/202606": {"top1": 11, "top3": 14, "abstain_max": 8},
    "products/oncology/oc/202606": {"top1": 12, "top3": 12, "abstain_max": 8},
}


def synthetic_profile(cfg, out_path):
    """A profile TSV over the pack's synthetic sources — the schemas the smoke build already runs.

    Read from the REAL fixture frames rather than re-deriving column lists, so this cannot drift
    from what `test_smoke_spark` builds against. Counts are constants: the copilot reads names and
    columns, and inventing distributions here would imply evidence the fixture does not carry.
    """
    import synthetic_sources
    spark = synthetic_sources.session("mapping-benchmark")
    src = synthetic_sources.sources(spark, cfg)
    lines = [HDR]
    for role, df in sorted(src.items()):
        stem = cfg.sources[role]
        for col in df.columns:
            lines.append(f"{stem}_{CUT}\t{stem}\t{col}\tcategorical\tFALSE\t1\t1\t0.0\t1\t\t\t")
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    return out_path


def with_decoys(profile_path, cfg, out_path):
    """The profile plus one NEAR-MISS decoy table per declared role: the truth table's schema
    minus one required column, plus a noise column, under a name sharing the truth's stem.

    An external review asked for adversarial pressure: a ranking measured only against tables
    that differ honestly can pass while being one suffix away from proposing a wrong one. A
    decoy can never be a CLEAN candidate (a required column is missing by construction), so
    `map_candidate` naming one is impossible without a copilot regression — and if one is ever
    proposed, the run counts it unsafe and fails. What decoys do stress is the RANKING: they
    share the stem's name tokens, so truth must out-rank its own shadow on evidence, not name.
    """
    import profile_io
    tables, _cuts = profile_io.load(profile_path)
    req = ev.required_columns(cfg)
    with open(profile_path, encoding="utf-8") as fh:
        lines = fh.read().rstrip("\n").split("\n")
    # rows follow the INPUT's own header, not this module's 12-column HDR: a profile carrying
    # the provenance/type columns would otherwise gain short rows whose blank provenance values
    # break load()'s constancy check — the decoy writer must not assume one header shape.
    header = lines[0].split("\t")
    base = {"kind": "categorical", "sampled": "FALSE", "n_rows": "1", "n_rows_total": "1",
            "pct_missing": "0.0", "distinct": "1"}
    sample = next(iter(next(iter(tables.values())).values()))       # provenance is file-constant
    skipped = []
    for role, stem in sorted(cfg.sources.items()):
        cols = {c.lower() for c in tables.get(stem, {})}
        if not cols:
            skipped.append(f"{role} (stem {stem} not in the profile)")
            continue
        drop = next((c for c in sorted(req.get(role) or []) if c != "patientid"
                     and c in cols), None)
        if drop is None:
            # No near-miss is constructible (only patientid is required): a full clone would be
            # a CLEAN candidate — a forced, unwinnable ambiguity, not adversarial pressure. A
            # benchmark cell that can never succeed teaches people to ignore the benchmark.
            skipped.append(f"{role} (no droppable required column)")
            continue
        for col in sorted(cols - {drop} | {"shadownote"}):
            row = {"table": f"{stem}_shadow_{CUT}", "table_base": f"{stem}_shadow", "column": col,
                   **base}
            lines.append("\t".join(str(row.get(h, sample.get(h) or "")) if h not in
                                    ("date_min", "date_max", "top_values") else ""
                                    for h in header))
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    if skipped:   # a bounded decoy set must SAY what it did not cover
        print(f"decoys: no near-miss constructed for {', '.join(skipped)}")
    return out_path


def benchmarkable_roles(product):
    """Declared roles some config block actually READS — removing any other produces no gap, so
    only these can be scored. The skipped remainder is reported, never silently dropped."""
    cfg = load_config(os.path.join(product, "config", "data_product.yaml"))
    referenced = set(ev.referenced_sources(cfg))
    return (sorted(r for r in cfg.sources if r in referenced),
            sorted(r for r in cfg.sources if r not in referenced))


def _strip_role(pack_dir, role):
    """A throwaway copy of the pack with one `sources:` line removed — the leave-one-out blind."""
    import re
    cfgp = os.path.join(pack_dir, "config", "data_product.yaml")
    with open(cfgp, encoding="utf-8") as fh:
        text = fh.read()
    stripped, n = re.subn(rf"^\s+{re.escape(role)}:\s+\S+.*\n", "", text, count=1, flags=re.M)
    if n != 1:
        raise SystemExit(f"could not blind role {role!r} in {cfgp} — the leave-one-out edit must "
                         f"remove exactly one line, and guessing is worse than stopping")
    with open(cfgp, "w", encoding="utf-8") as fh:
        fh.write(stripped)


def score_pack(product, tmp, profile=None, adversarial=True):
    """Score one pack. `profile` overrides the synthetic profile (the frozen holdout route: a
    COMMITTED snapshot that cannot drift when required_columns or the fixtures change, so the
    evidence the ranking is scored on is independent of the code being scored). `adversarial`
    appends the near-miss decoys — on by default, because the un-decoyed number flatters."""
    cfg = load_config(os.path.join(product, "config", "data_product.yaml"))
    truth = dict(cfg.sources)
    roles, skipped = benchmarkable_roles(product)
    profile = profile or synthetic_profile(cfg, os.path.join(tmp, "profile.tsv"))
    if adversarial:
        profile = with_decoys(profile, cfg, os.path.join(tmp, "profile_decoyed.tsv"))
    rows = []
    for role in roles:
        blind = os.path.join(tmp, f"blind_{role}")
        shutil.copytree(product, blind)
        _strip_role(blind, role)
        doc = psm.proposal(blind, profile)
        gap = next((g for g in doc["gaps"] if g["role"] == role), None)
        if gap is None:
            rows.append({"role": role, "truth": truth[role], "outcome": "no_gap_raised",
                         "rank": None, "recommendation": None, "proposed": None})
            continue
        cand_tables = [c["table"] for c in gap["candidates"]]
        rank = cand_tables.index(truth[role]) + 1 if truth[role] in cand_tables else None
        # the proposal's own answer — re-deriving it from the DISPLAYED candidates raised
        # StopIteration the first time a degraded ranking pushed the clean table off the page
        proposed = gap.get("proposed")
        rows.append({"role": role, "truth": truth[role],
                     "outcome": ("unsafe" if proposed and proposed != truth[role] else
                                 "top1" if rank == 1 else
                                 "top3" if rank and rank <= 3 else
                                 "missed"),
                     "rank": rank, "recommendation": gap["recommendation"],
                     "proposed": proposed})
    n = len(rows)
    return {"pack": os.path.relpath(product, ROOT),
            "engineering": {
                "scored_roles": n,
                "skipped_roles": skipped,
                "top1": sum(1 for r in rows if r["rank"] == 1),
                "top3": sum(1 for r in rows if r["rank"] and r["rank"] <= 3),
                "unsafe": sum(1 for r in rows if r["outcome"] == "unsafe"),
                "abstained": sum(1 for r in rows if r["recommendation"] == "do_not_map"),
                "rows": rows},
            "clinical": {
                "scored": None,
                "why": "semantic equivalence has no mechanical ground truth; these mappings are "
                       "clinically right because RWP approved them against a specification, and "
                       "no benchmark may re-derive or re-litigate that. Decisions of this kind "
                       "route to RWP/RWB through the decisions register."}}


def render(results):
    L = ["MAPPING-COPILOT BENCHMARK — leave-one-out over approved `sources:` maps", ""]
    for res in results:
        e = res["engineering"]
        n = e["scored_roles"] or 1
        L.append(f"  {res['pack']}")
        L.append(f"    ENGINEERING LAYER (scored): table discrimination from schema evidence")
        L.append(f"        roles scored     {e['scored_roles']}")
        L.append(f"        top-1 accuracy   {e['top1']}/{e['scored_roles']}  ({100 * e['top1'] // n}%)")
        L.append(f"        top-3 recall     {e['top3']}/{e['scored_roles']}  ({100 * e['top3'] // n}%)")
        L.append(f"        UNSAFE proposals {e['unsafe']}   <- map_candidate naming the WRONG table; "
                 f"the number that must stay 0")
        L.append(f"        abstained        {e['abstained']}   (do_not_map on a mappable role — "
                 f"costs review time, never correctness)")
        if e["skipped_roles"]:
            L.append(f"        not benchmarkable: {', '.join(e['skipped_roles'])} — declared but "
                     f"read by no block, so blinding them raises no gap")
        for r in e["rows"]:
            mark = {"top1": "ok ", "top3": "~  ", "unsafe": "!! ", "missed": "-- ",
                    "no_gap_raised": "?? "}[r["outcome"]]
            L.append(f"        {mark} {r['role']:<16} truth {r['truth']:<28} "
                     f"rank {r['rank'] or '-'}  rec {r['recommendation'] or '-'}")
        L.append(f"    CLINICAL LAYER (never scored): {res['clinical']['why']}")
        L.append("")
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("--pack", action="append", default=[],
                    help="pack(s) to benchmark; default: prostate + oc 202606, the packs with "
                         "approved mappings and synthetic schemas")
    ap.add_argument("--format", choices=("text", "json"), default="text")
    ap.add_argument("--holdout", action="store_true",
                    help="score prostate against the COMMITTED frozen profile snapshot "
                         "(tests/fixtures/holdout_profile_prostate_202606.tsv) instead of a "
                         "profile derived at run time — evidence independent of the code scored")
    ap.add_argument("--no-adversarial", action="store_true",
                    help="omit the near-miss decoy tables (the flattering number; for comparison)")
    a = ap.parse_args(argv)
    packs = a.pack or ["products/oncology/prostate/202606", "products/oncology/oc/202606"]
    holdout = os.path.join(os.path.dirname(TOOLS), "tests", "fixtures",
                           "holdout_profile_prostate_202606.tsv")
    results = []
    for pack in packs:
        product = os.path.abspath(pack)
        tmp = tempfile.mkdtemp(prefix="mapping_benchmark_")
        try:
            frozen = holdout if (a.holdout and pack.endswith("prostate/202606")) else None
            if a.holdout and frozen is None:
                continue                              # holdout mode scores only its pack
            # the holdout run is scored WITHOUT decoys: decoys are derived from the current
            # required_columns — the code under test — and layering them onto the frozen
            # evidence would hand the independence claim right back
            results.append(score_pack(product, tmp, profile=frozen,
                                      adversarial=not a.no_adversarial and not a.holdout))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    if not results:
        print("FAIL no pack was scored — --holdout scores only prostate/202606, and the "
              "--pack list named no such pack. An empty report must not read as a pass.")
        return 1
    if a.format == "json":
        print(json.dumps(results, indent=2))
    else:
        print(render(results))
    # Exit material. An unsafe proposal is the one outcome that must always fail — the copilot
    # doing the thing the whole workflow exists to prevent. For packs with a recorded baseline,
    # a discrimination floor or the abstention cap failing is exit material too: without them a
    # ranking regression that abstains on everything would read as perfectly safe.
    for line in floor_failures(results):
        print(f"FAIL {line}")
    return 1 if floor_failures(results) else 0


def floor_failures(results):
    out = []
    for r in results:
        e = r["engineering"]
        pack = str(r["pack"]).replace(os.sep, "/")
        if e["unsafe"]:
            out.append(f"{pack}: {e['unsafe']} unsafe proposal(s) — must stay 0")
        floors = FLOORS.get(pack)
        if not floors:
            continue
        if e["top1"] < floors["top1"]:
            out.append(f"{pack}: top-1 {e['top1']} fell below the recorded floor {floors['top1']}")
        if e["top3"] < floors["top3"]:
            out.append(f"{pack}: top-3 {e['top3']} fell below the recorded floor {floors['top3']}")
        if e["abstained"] > floors["abstain_max"]:
            out.append(f"{pack}: abstained on {e['abstained']} role(s), cap {floors['abstain_max']} "
                       f"— total abstention must never read as a pass")
    return out


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
