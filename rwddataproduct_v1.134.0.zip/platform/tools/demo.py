#!/usr/bin/env python3
"""The end-to-end walkthrough — one pack's governed lifecycle, run against the real tools.

    python3 platform/tools/demo.py                     # the packs you can walk, and how
    python3 platform/tools/demo.py <pack>              # walk one, gate by gate
    python3 platform/tools/demo.py <pack> --full       # don't truncate the tool output

It ORCHESTRATES; it DERIVES NOTHING. Every count, status and verdict printed below is some
tool's own stdout, captured verbatim. This file owns the ORDER and the narration and not one
governed fact — which is the whole design constraint, because a walkthrough that recomputed a
number would be a second implementation of whichever tool owns it, agreeing today and
eventually printing a greener answer than CI does. The one thing it counts is its own exit
codes.

READ-ONLY. Every command is a `--check` or a report; the deployment tree is built into a temp
directory and removed on the way out. Nothing under the pack is written, no approval is
granted, no maturity level moves, no vendor data is read.

WHAT THIS IS NOT: a build. Turning config into an ADS needs PySpark and a warehouse, so the
engine is exercised by `platform/tests/` (and the spark suites when PySpark is present), never
here. What this shows is the part a successor has to trust before a build is worth running —
that the specification, the contract, the config and the release decision are bound to each
other, and that the gates refuse when they are not.

A non-zero exit on a GATE step is this PACK failing that gate, not the walkthrough breaking.
Today every pack is blocked at Gate 1 (no approved workbook has been supplied), so the honest
end state of this demo is BLOCKED, with the reasons named. Watching it refuse is the point:
`--list-releasable` derives the release decision from Gates 1-4 and there is no flag to set.

stdlib only.
"""
import argparse
import os
import shutil
import sys
import tempfile
import textwrap

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))

sys.path.insert(0, TOOLS)
import console                                                    # noqa: E402
from spec_extract import repo_relative                                  # noqa: E402
import deploy_tree      # noqa: E402  — the ONE reader of the checkout's git state
import product_gates    # noqa: E402  — the ONE discoverer of packs; never glob products/*/*/*
import source_manifest  # noqa: E402  — the ONE reader of a pack's registered materials
import run_spec_pipeline  # noqa: E402  — for its exit codes ONLY; the pipeline runs as a subprocess

# A step's kind decides how its exit code is READ, and nothing else.
GATE = "gate"    # must exit 0. Non-zero = this pack does not pass that gate.
SHOWS = "shows"  # a report or a deliberate refusal. The exit code is information, not a verdict.

# Not an exit code — no process returns it. A step reports this when there was NOTHING TO RUN, which
# is not the same as having run and succeeded. A pack shipping no test suite of its own was scored
# PASS on Gate 5 by an earlier version of this file: an absent suite reported as passing evidence, in
# a walkthrough whose whole subject is gates that fail closed. Zero tests is zero evidence.
NO_EVIDENCE = -1

# WHAT THE PROCESS EXIT CODE MEANS. Distinct values because the three interesting answers are not
# ordered on one axis: a walkthrough can execute perfectly against a pack that has proved nothing
# (EXIT_INCOMPLETE), and that is a completely different message from a pack whose gate actually bit
# (EXIT_GATE_FAILED). Collapsing them into 0/1 is what let "6/6 gate steps passed" stand as the
# summary of a pack blocked at Gate 1.
EXIT_READY = 0          # every gate evaluated, every one passed, nothing outstanding
EXIT_INCOMPLETE = 2     # the tools ran; the PACK has not reached the end of the gates
EXIT_GATE_FAILED = 1    # a gate was evaluated and this pack failed it

# WHICH PACKS A GATE APPLIES TO — asked of `product_gates`, which owns the question, rather than by
# looking for a directory here. Every one of these tools is run by CI over a DISCOVERY LIST, never
# over every pack (see docs/ENGINEERING.md's sweep: finalize and source_check over --list-contracts), and run
# outside its list a gate passes VACUOUSLY.
#
# That is not hypothetical. prostate/202607 has no config/ at all, and scored a clean 13/13 here
# because contract_binding reported "covered config: 0/0 governed block(s)" and exited 0 — reading,
# in a handover walkthrough, as identically complete to 202606. The endometrial seed has no
# source_refs.yaml and Gate 1 answered "0 pack(s) with something to check; 0 error(s)". A gate with
# nothing to look at must say so, not say OK.
#
# PICK THE LIST THAT MEANS "HAS THE ARTIFACT", NOT "IS FINISHED". The binding step keys on
# --list-configs, not the stricter --list-buildable, and the difference is not cosmetic: oc HAS
# config and its binding genuinely FAILS, so keying on --list-buildable (which excludes oc) would
# have converted a real defect into "no evidence" — hiding exactly what this walkthrough exists to
# surface. Suppressing a failure is a worse bug than the vacuous pass it was meant to fix.
APPLIES = {
    "materials":  "registers no source materials (no source_refs.yaml)",
    "pipelines":  "has no spec_pipeline/pipeline.conf, so there is no extraction to verify",
    "contracts":  "has no handoff/FUNCTIONAL_CONTRACT.md",
    "decisions":  "keeps no decisions register",
    "configs":    "has no executable config/ for a contract record to be bound to",
}
_LISTS = {}


def _ai_readable(pack):
    """Has somebody signed this pack's sanitized extraction? Through `source_manifest.ai_readable`,
    the ONE answer to that question — the walkthrough must not have a second opinion about it."""
    return source_manifest.ai_readable(os.path.join(ROOT, pack))[0]


def applicable(pack, which):
    """Is `which` gate meaningful for this pack? Answered by the tool that owns the list.

    `materials` is source_manifest's question, not product_gates' — a pack is Gate-1-checkable when
    it registers materials, and `materials()` is the ONE reader of that file.

    A TUPLE means EVERY named list must hold. Gate 4 is the reason: binding is a statement ABOUT two
    artifacts, and a pack with config and no contract satisfied `configs` alone — so the gate ran,
    found nothing to bind, and rendered as PASS beside the NONEs of every other unreached gate. A
    relation needs both of its sides present before asking whether they agree.
    """
    if isinstance(which, tuple):
        return all(applicable(pack, w) for w in which)
    if which == "materials":
        return bool(source_manifest.materials(os.path.join(ROOT, pack)))
    if which not in _LISTS:
        _, out = run([sys.executable, os.path.join(TOOLS, "product_gates.py"), f"--list-{which}"])
        _LISTS[which] = set(out.split())
    return pack in _LISTS[which]


WIDTH = 96
TRUNCATE = 14  # lines of tool output per step before summarising; --full shows everything


def rule(ch="─"):
    return ch * WIDTH


def steps(pack, domain, dirty):
    """The lifecycle, in the order a person walks it.

    CI runs most of these too, in a different order (hygiene and the product tests first, so
    the cheapest containment check and the pack's own suite fail before anything slower is
    known to work). This order is the STORY — registration, then what may be read, then the
    contract, then the config, then the release decision — because a walkthrough is for
    someone learning what the gates are for, not for failing fast.

    `dirty` demotes the two packaging steps from GATE to SHOWS. A modified checkout cannot
    produce a release-bindable tree, so --check-tree correctly refuses the one built with
    --allow-dirty — and scoring that as the PACK failing Gate 6 would blame the pack for the
    state of somebody's working copy. On a clean checkout, which is the only state a release
    is packaged from, both are gates again.
    """
    py = sys.executable
    T = lambda name: os.path.join(TOOLS, name)  # noqa: E731

    return [
        dict(kind=GATE, gate="Containment", title="what may never be committed",
             proves="no scanned document, vendor extract or machine path is in the git index — "
                    "the boundary of the checkout itself, and the first thing CI runs",
             argv=[py, T("repo_hygiene.py"), "--check"]),

        dict(kind=GATE, gate="Gate 1", title="the source materials are registered", applies="materials",
             proves="every material is classified and, if any is approved, it still hashes to "
                    "the bytes the record names — so a workbook cannot be swapped under a "
                    "signed contract",
             argv=[py, T("source_manifest.py"), pack, "--check"]),

        dict(kind=SHOWS, gate="Gate 1", title="the AI boundary, over the whole pack", applies="materials",
             proves="where an AI-eligible pack's readable files reproduce vendor documentation. "
                    "The boundary follows the CONTENT's classification, never the folder",
             argv=[py, T("source_manifest.py"), pack, "--ai-boundary"]),

        # TITLE DERIVED, NOT ASSERTED. This said "…and the slicer refuses to read it" — true of every
        # pack in the repository on the day it was written, and false for prostate/202606 the moment
        # somebody signed its extraction. The walkthrough then narrated a refusal over a printed
        # slice, which is the one thing a demonstration of a governance framework may not do. It now
        # asks `ai_readable` and says which state this pack is in; both are the gate working.
        dict(kind=SHOWS, gate="Gate 1",
             title=("…and the slicer refuses to read it" if not _ai_readable(pack)
                    else "…and the slicer reads it, because somebody signed it"),
             applies="materials",
             proves=("THE MOMENT TO WATCH. What AI may read is the sanitized extraction, and it "
                     "needs its own signature. A non-zero here is the gate working, not a fault"
                     if not _ai_readable(pack) else
                     "THE MOMENT TO WATCH — this pack's sanitized extraction IS signed, so the "
                     "slice is produced. The permission came from a named person against these "
                     "bytes, not from asking; run this on a pack nobody has signed to see the "
                     "refusal"),
             argv=[py, T("spec_slice.py"), pack, "--domain", domain]),

        # `--require-generated` because without it this gate printed PASS on a pack that has
        # generated NOTHING. Measured on mCRC, which is on `--list-pipelines` and has no artifacts:
        # every neighbouring gate correctly said NONE and this one said "PASS — the generated
        # artifacts are current", about seven files that do not exist. The flag gives that state its
        # own exit code, and `no_evidence_exit` renders it as NO EVIDENCE rather than as a failing
        # gate: a pack that has generated nothing has not failed, it has not yet claimed anything.
        dict(kind=GATE, gate="Gate 2", title="the generated artifacts are current", applies="pipelines",
             proves="regenerating the spec pipeline into a temp dir produces byte-identical "
                    "artifacts — nobody hand-edited a generated file",
             no_evidence_exit=run_spec_pipeline.NOTHING_GENERATED,
             argv=[py, T("run_spec_pipeline.py"), pack, "--check", "--require-generated"]),

        dict(kind=GATE, gate="Gate 2", title="every contract record holds its invariants", applies="contracts",
             proves="the record vocabulary, the spec digests binding each record to the text it "
                    "cites, and the reference checks across all three registers",
             argv=[py, T("contract_lint.py"), pack]),

        dict(kind=GATE, gate="Gate 2", title="the open-question list is current", applies="decisions",
             proves="the ranked decision report still matches the decisions register — an open "
                    "question cannot go missing from the summary a human reads",
             argv=[py, T("decision_report.py"), pack, "--check"]),

        dict(kind=GATE, gate="Gate 3", title="every source declaration is readable", applies="contracts",
             proves="the half of Gate 3 that needs no vendor material: no unknown kind, no "
                    "contradictory shape. Confirming a column is the RIGHT column needs a "
                    "profile and a human",
             note="A PASS here is 'nothing unreadable', NOT 'nothing wrong'. --structure-only "
                  "deliberately tolerates an existing backlog — the not_a_column rows above are "
                  "real contract defects it is letting through so the check can protect a new "
                  "tumour today. Drop --structure-only, with a profile, for the full verdict.",
             argv=[py, T("source_check.py"), pack, "--structure-only", "--check"]),

        dict(kind=GATE, gate="Gate 4", title="the contract and the config are bound",
             applies=("contracts", "configs"),
             proves="every governed block of executable YAML is claimed by a contract record, "
                    "and every record says where it is implemented",
             argv=[py, T("contract_binding.py"), pack, "--check"]),

        dict(kind=GATE, gate="Gate 5", title="the pack's own test suite",
             proves="the tests this pack ships for itself, discovered through the registry — "
                    "not a fixed path",
             argv=None, expand="tests"),

        dict(kind=GATE, gate="—", title="the pack's claims match its evidence", applies="contracts",
             proves="every gate above checks an artifact; this one checks the SENTENCES the "
                    "pack writes about its artifacts — scope, counts, maturity note",
             argv=[py, T("finalize.py"), pack, "--check"]),

        dict(kind=GATE, gate="—", title="no maturity claim outruns its evidence",
             proves="a declared level is granted on the evidence named beside it, across every "
                    "discovered pack",
             argv=[py, T("product_gates.py"), "--check-maturity"]),

        dict(kind=SHOWS, gate="Gate 6", title="may this pack publish?",
             proves="DERIVED from Gates 1-4 — there is no releasable flag to set. If it says "
                    "BLOCKED, the reasons below are the PACK-LEVEL blockers that must close before a "
                    "release-grade build may even be considered — not the whole remaining "
                    "distance. Gate 5 validation against real data, a Gate 6 approval of the "
                    "specific build, and the promotion path itself all sit beyond them",
             argv=[py, T("source_manifest.py"), pack, "--list-releasable", "--why-blocked"]),

        dict(kind=SHOWS if dirty else GATE, gate="Gate 6", title="build the deployment tree",
             proves="an ALLOWLIST, not the repository minus a few globs: the runtime, the bundle "
                    "and each pack's active config graph. The stand-ins, spec folders and "
                    "reference material are not copied because they are not on the list",
             note=("YOUR CHECKOUT IS MODIFIED, so a release-bindable tree was refused and this "
                   "one was built --allow-dirty: it carries no commit stamp and the runtime will "
                   "not publish off it. Commit and re-run to see the bindable path."
                   if dirty else None),
             argv=None, expand="deploy"),

        dict(kind=SHOWS if dirty else GATE, gate="Gate 6", title="check the tree that would ship",
             proves="re-walks the BUILT tree — repo_hygiene reads the git index and a generated "
                    "tree has no .git, so without this the shipped artifact is checked by nothing",
             note=("Refusing the unstamped tree from the previous step is the CORRECT answer, not "
                   "this pack failing Gate 6 — which is why it is not scored as one here."
                   if dirty else None),
             argv=None, expand="check_tree"),

        dict(kind=GATE, gate="Gate 6", title="nothing is scheduled",
             proves="activation is governed: `schedule_enabled: true` REQUIRES that the pack be "
                    "releasable, so a job cannot be switched on ahead of its evidence",
             argv=[py, T("bundle_products.py"), "--check"]),
    ]


def run(argv):
    """One tool call, from the repo root. Returns (exit code, combined output).

    cwd is ROOT for every step because the gate tools emit repo-root-relative pack paths and
    `products()` derives its root from the CWD — a walkthrough run from platform/ would print
    paths that do not resolve and could discover nothing at all.
    """
    # No `env=` here any more. This call site was the ONE that knew a Python child has to be told to
    # emit UTF-8, and it knew it privately — `console.run` now does it for every caller, which is the
    # only reason the other seventeen were not carrying the same bug on Windows.
    r = console.run(argv, cwd=ROOT)
    return r.returncode, (r.stdout or "") + (r.stderr or "")


def emit(text, full):
    """Print a tool's output, indented, truncated unless --full."""
    lines = [ln.rstrip() for ln in text.rstrip().splitlines()]
    if not lines:
        print("     (no output)")
        return
    shown = lines if full else lines[:TRUNCATE]
    for ln in shown:
        print(f"     {ln}")
    if len(lines) > len(shown):
        print(f"     … {len(lines) - len(shown)} more line(s) — re-run with --full")


def do_tests(pack, full):
    """The pack's own suites, discovered rather than listed here.

    Filtered from --list-tests by path prefix so this walks ONE pack; taking the whole list
    would run the portfolio's tests and report them as this pack's evidence.
    """
    code, out = run([sys.executable, os.path.join(TOOLS, "product_gates.py"), "--list-tests"])
    if code:
        return code, out
    own = [t for t in out.split() if t.startswith(pack.rstrip("/") + "/")]
    if not own:
        return NO_EVIDENCE, (f"{pack} ships no test suite of its own.\n"
                             f"Nothing ran, so nothing was proved — this is not a pass.")
    lines, worst = [], 0
    for t in own:
        c, o = run([sys.executable, t])
        worst = worst or c
        lines.append(f"{'PASS' if c == 0 else 'FAIL'}  {t}")
        if c:
            lines.append(o.rstrip())
    return worst, "\n".join(lines)


def do_deploy(pack, tmp, full, dirty=False):
    """Build the tree the workspace would receive, outside the checkout.

    Tries a RELEASE-BINDABLE build first. A modified checkout is refused for one — the commit stamp
    would name a tree that never existed — so on a dirty working copy this retries with
    --allow-dirty and says so: that tree carries no commit stamp and the runtime refuses to publish
    off its evidence, which is exactly the property worth showing.

    THE RETRY IS CONDITIONED ON THE CHECKOUT STATE, not on the exit code. Retrying on ANY non-zero
    would mean that on a CLEAN checkout a genuine packaging failure — a forbidden file reaching the
    allowlist, an unreadable config graph — is silently retried under weaker rules and narrated as
    "your working copy is modified". A walkthrough that explains a real failure as somebody's local
    edits is worse than one that simply fails. `walk` asks `deploy_tree.git_state` once and passes
    the answer to `steps`; this takes the same answer rather than inferring it from an exit code.
    """
    base = [sys.executable, os.path.join(TOOLS, "deploy_tree.py"),
            "--out", os.path.join(tmp, "tree"), "--evidence-out", os.path.join(tmp, "evidence"),
            "--product", pack]
    code, out = run(base)
    if code and dirty:
        code, retried = run(base + ["--allow-dirty"])
        out = (out.rstrip() + "\n\n  ↑ the checkout is modified, so a release-bindable tree was "
               "refused. Rebuilt with --allow-dirty: that tree carries NO commit stamp and the "
               "runtime will not publish off it.\n\n" + retried)
    return code, out


def do_check_tree(tmp, full):
    built = os.path.join(tmp, "tree")
    if not os.path.isdir(built):
        return 1, "(the tree was not built — the previous step did not produce one)"
    return run([sys.executable, os.path.join(TOOLS, "deploy_tree.py"), "--check-tree", built])


def walk(pack, domain, full):
    tmp = tempfile.mkdtemp(prefix="rwdp-demo-")
    # Asked ONCE, through the tool that owns the question, so the two packaging steps and the
    # banner cannot disagree about what state the checkout was in.
    _, modified = deploy_tree.git_state(ROOT)
    plan = steps(pack, domain, bool(modified))
    results = []

    print()
    print(rule("═"))
    print(f"  RWDP END-TO-END WALKTHROUGH — {pack}")
    print(rule("═"))
    print("  Runs the real governance tools and shows what each one says. Read-only: nothing")
    print("  under the pack is written, no approval is granted, no vendor data is read.")
    print(f"  Scratch (removed on exit): {tmp}")
    print()

    try:
        for i, st in enumerate(plan, 1):
            print(rule())
            print(f" [{i}/{len(plan)}]  {st['gate']} · {st['title'].upper()}")
            print(rule())
            for line in _wrap(f"proves   {st['proves']}", 3):
                print(line)

            skip = st.get("applies") and not applicable(pack, st["applies"])
            if skip:
                # Deliberately BEFORE the command runs. Running it anyway and relabelling the
                # result would still print a tool saying OK, and the reader would believe it.
                print("   run      (not run — this gate does not apply to this pack yet)")
                print()
                code = NO_EVIDENCE
                # For a multi-list gate, name the side that is actually missing rather than both.
                _lists = st["applies"] if isinstance(st["applies"], tuple) else (st["applies"],)
                _absent = [w for w in _lists if not applicable(pack, w)]
                out = "\n".join(
                    f"{pack} {APPLIES[w]}.\nIt is not on `product_gates --list-{w}`, so this gate "
                    f"has nothing to read. Nothing ran, so nothing was proved." for w in _absent)
            elif st.get("expand") == "tests":
                print("   run      python3 platform/tools/product_gates.py --list-tests   "
                      "# then each one")
                code, out = do_tests(pack, full)
            elif st.get("expand") == "deploy":
                print(f"   run      python3 platform/tools/deploy_tree.py --out DIR "
                      f"--evidence-out DIR \\\n              --product {pack}")
                code, out = do_deploy(pack, tmp, full, bool(modified))
            elif st.get("expand") == "check_tree":
                print("   run      python3 platform/tools/deploy_tree.py --check-tree DIR")
                code, out = do_check_tree(tmp, full)
            else:
                shown = " ".join(["python3"] + [_short(a) for a in st["argv"][1:]])
                print(f"   run      {shown}")
                code, out = run(st["argv"])
                # A tool may distinguish "I could not prove this" from "this failed". Only the
                # exit code is read — demo.py does not parse a tool's output, and must not start.
                if st.get("no_evidence_exit") is not None and code == st["no_evidence_exit"]:
                    code = NO_EVIDENCE

            print()
            emit(out, full)
            print()
            if st.get("note"):
                for line in _wrap(f"note     {st['note']}", 3):
                    print(line)
            print(f"   → {_verdict(st['kind'], code)}")
            print()
            results.append((st, code))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    return summarise(pack, results)


def _verdict(kind, code):
    if code == NO_EVIDENCE:
        return "NO EVIDENCE — nothing to run, so nothing was proved. Not a pass."
    if kind is GATE:
        return "PASS" if code == 0 else f"FAILS THIS GATE (exit {code})"
    return "shown" if code == 0 else f"REFUSED (exit {code}) — the gate biting, as designed"


def _short(arg):
    """Tool paths back to their repo-relative form, so a printed command is copy-pasteable."""
    return os.path.relpath(arg, ROOT) if arg.startswith(ROOT) else arg


def _wrap(text, indent):
    """Wrap the `proves` prose, hanging the continuation under the label column."""
    return textwrap.wrap(text, width=WIDTH - indent,
                         initial_indent=" " * indent,
                         subsequent_indent=" " * (indent + 9))


def summarise(pack, results):
    gates = [(s, c) for s, c in results if s["kind"] is GATE]
    silent = [(s, c) for s, c in gates if c == NO_EVIDENCE]
    failed = [(s, c) for s, c in gates if c not in (0, NO_EVIDENCE)]

    print(rule("═"))
    print("  SUMMARY")
    print(rule("═"))
    for st, code in results:
        if code == NO_EVIDENCE:
            mark = "NONE "
        elif st["kind"] is GATE:
            mark = "PASS " if code == 0 else "FAIL "
        else:
            mark = "shown" if code == 0 else "REFUS"
        print(f"   {mark}  {st['gate']:<12} {st['title']}")
    print()
    # THREE NUMBERS, NEVER ONE. A single tally here read as a verdict on the PRODUCT, and on a pack
    # like mCRC it said "6/6 gate step(s) passed" on the same screen as five controls with no
    # evidence, no contract records, no test suite, no execution and a refused publication. The
    # denominator excluding un-evidenced steps is right for "did the tools run" and wrong for
    # "is this ready", and one line cannot carry both questions. So each is asked and answered
    # separately, and the readiness line comes from `status.next_action` — evidence, not a restatement.
    import status
    scored = len(gates) - len(silent)
    blocked_at, _who, _what = status.next_action(ROOT, pack)
    readiness = f"BLOCKED AT GATE {blocked_at}" if blocked_at else "GATES 1-6 COMPLETE"
    for label, value, means in (
            ("Framework controls", f"{scored - len(failed)} passed, {len(failed)} failed",
             "did the governance tools execute"),
            ("Evidence coverage", f"{scored}/{len(gates)} control(s) evaluated",
             f"{len(silent)} had nothing to run"),
            ("Product readiness", readiness,
             "what this pack may actually claim")):
        print(f"   {label:<21}{value:<30}— {means}")
    print()
    print(f"   for {pack}")
    if silent:
        print(f"   {len(silent)} step(s) had NO EVIDENCE to offer — nothing ran, nothing was proved:")
        for st, _ in silent:
            print(f"       · {st['gate']} — {st['title']}")
    print()

    # WHAT THE WALKTHROUGH ENDING WELL DOES AND DOES NOT MEAN. Every step above can pass and the
    # product still be four steps from a released number, because "the governance tools ran" and
    # "the engine produced validated values from the real feed" are different claims. A viewer who
    # watched a green summary and took it for the second would not be careless; they would be
    # reading the only thing this file printed. `status.demonstrated` owns the distinction and is
    # asked, not restated — the bullets below it are hardcoded because they are true of THIS
    # WALKTHROUGH by construction; these four are about the PRODUCT and must come from evidence.
    import status
    print(rule())
    print("  WHAT HAS ACTUALLY BEEN DEMONSTRATED FOR THIS PRODUCT")
    print(rule())
    for label, reached, why in status.demonstrated(ROOT, pack):
        print(f"   [{'yes' if reached else ' no'}]  {label:<30} {why}")
    print()

    print(rule())
    print("  WHAT YOU DID NOT JUST SEE")
    print(rule())
    print("   · A BUILD. Turning this config into an ADS needs PySpark and a warehouse; the")
    print("     engine is covered by platform/tests/, not by this walkthrough.")
    print("   · AN APPROVAL. Nothing here signs anything. Gate 1's `reviewed`, the Gate 2, 4")
    print("     and 6 approval forms and a decision's RESOLVED are human acts, and no tool in")
    print("     this repository may perform them. Each ships as a `.example.yaml` in")
    print("     platform/TUMOR_TEMPLATE/handoff/ — copy it when a real approval happens.")
    print("   · VENDOR DATA. Every step above reads the repository only. Profiles and schema")
    print("     reports are the live-evidence half of Gate 3 and are written outside the")
    print("     checkout by run_product_profile.py / run_product_schema_check.py.")
    print()
    print(rule())
    print("  WHERE TO GO NEXT")
    print(rule())
    print("   HANDOVER.md            the goal, the grounded status of every layer, the roadmap")
    print("   governance/WORKFLOW.md the six gates in full, and the eligibility rule")
    print("   docs/ENGINEERING.md              the rules that are expensive to get wrong")
    print()
    # FOUR OUTCOMES, NOT TWO. `1 if failed else 0` collapsed "the tools all ran and this pack is
    # ready" into the same zero as "the tools all ran and this pack has no contract, no records and
    # no execution" — which is how a demo of a scaffold reads as a demo of a product. An orchestrator
    # or a CI job reading the exit code could not tell them apart, and neither could a viewer.
    if failed:
        return EXIT_GATE_FAILED
    if blocked_at:
        return EXIT_INCOMPLETE
    return EXIT_READY


def catalogue():
    """No pack named: show the ones that exist and the command for each.

    Deliberately not a default pack. Picking 'the most advanced one' would be a ranking this
    file invented, and hardcoding a slug would put one tumour's name into shared code — the
    failure this repository has paid for more than once.
    """
    packs = sorted(product_gates.products(ROOT))
    print()
    print(rule("═"))
    print("  RWDP END-TO-END WALKTHROUGH")
    print(rule("═"))
    print("  Walks one pack through the governed lifecycle, running the real tools.")
    print("  Name a pack:")
    print()
    code, out = run([sys.executable, os.path.join(TOOLS, "product_gates.py"), "--report"])
    for ln in out.rstrip().splitlines():
        print(f"     {ln}")
    print()
    print("  For example:")
    for p in packs:
        print(f"     python3 platform/tools/demo.py {p}")
    print()
    return 0


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack", nargs="?", help="the pack directory to walk (repo-root-relative)")
    ap.add_argument("--full", action="store_true", help="do not truncate any tool's output")
    ap.add_argument("--domain", default="demographics",
                    help="the drafting unit the slicer step asks for; the slicer names the "
                         "pack's own domains if this is not one of them (default: demographics)")
    a = ap.parse_args(argv)

    if not a.pack:
        return catalogue()

    pack = repo_relative(os.path.abspath(a.pack), ROOT)
    if not os.path.isdir(os.path.join(ROOT, pack)):
        sys.exit(f"{a.pack}: not a directory. Run with no argument to list the packs.")
    return walk(pack, a.domain, a.full)


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
