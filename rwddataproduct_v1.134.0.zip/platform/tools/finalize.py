#!/usr/bin/env python3
"""Finalization check — a pack's stated SUMMARY must agree with the evidence it summarizes.

Every other gate checks an artifact against a rule. Nothing checked the sentences packs write ABOUT
their artifacts, and those sentences are where a finished-looking pack goes wrong.

This is not hypothetical. `sandbox/experiments/ovarian_202606_contract_draft` is a frozen 295-record
run whose every individual record was plausible and whose summary was not:

  * the contract header said "Scope: `demographics` only … the other five domains are extracted,
    scanned and covered but not yet drafted", over records citing all six domains
  * MATURITY.yaml claimed "295 mapped + 47 dispositions + 18 context, 0 undispositioned" while the
    generated COVERAGE.md reported 360 items, UNDISPOSITIONED 342, context 18

(The note's "all 15 invariants" was NOT one of them, though this file claimed it was until the
invariant registry was corrected: 17 ids are enumerated, I7 is RETIRED and I9 is FOLDED INTO I13, so
15 fire and the note was right. The finding was a false positive produced by comparing against a
registry that counted tombstones.)

Those are ASSEMBLY failures. Drafting produced the records; nothing brought the header, scope, counts
and maturity claim back into agreement with them, and no check could see the disagreement because a
claim in prose is not an artifact anyone validates.

WHAT THIS DOES NOT DO. It does not rewrite the claims. MATURITY.yaml is a human CLAIM about a pack,
deliberately — "raising one here without that evidence is the thing this file exists to make visible"
— and a generator that quietly rewrote it would destroy exactly that. This derives the facts, reads
the claims, and reports every disagreement. A person edits the sentence.

DERIVED, NEVER RE-IMPLEMENTED. Each fact comes from the tool that already owns it:
`contract_lint.records` for the contract, `contract_scaffold.coverage_report` for dispositions,
`contract_lint.INVARIANTS` for the invariant count. In particular the coverage counts come from the
PRODUCER, not from parsing the rendered COVERAGE.md — a second reader of that table is precisely the
"two definitions of one concept" this repo keeps paying for.
"""
import argparse
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import contract_lint as cl                                          # noqa: E402
import contract_scaffold as cs                                      # noqa: E402
import product_gates as pg                                          # noqa: E402
import source_check as sc                                           # noqa: E402

# Written-out numbers seen in real pack prose. Deliberately small: a claim spelled in a way this does
# not recognise is REPORTED as unverifiable rather than silently passed, so the list can stay short.
WORDS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8,
         "nine": 9, "ten": 10, "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14,
         "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19, "twenty": 20}

NUM = r"(\d+|" + "|".join(WORDS) + r")"

# Each claim shape maps to a fact key. Ordered longest-first where two could match the same text, so
# "0 undispositioned" is never also read as a bare count.
CLAIMS = (
    (rf"{NUM}\s+undispositioned",                     "undispositioned"),
    (rf"{NUM}\s+records?\b",                          "records"),
    (rf"{NUM}\s+(?:spec\s+)?items?\b",                "items"),
    (rf"{NUM}\s+mapped\b",                            "mapped"),
    (rf"{NUM}\s+dispositions?\b",                     "dispositioned"),
    (rf"{NUM}\s+context\b",                           "context"),
    (rf"all\s+{NUM}\s+invariants?",                   "invariants"),
    (rf"all\s+{NUM}\s+domains?",                      "domains"),
)


def _n(token):
    return int(token) if token.isdigit() else WORDS[token.lower()]


def facts(product_dir):
    """What the pack actually contains, each number from the tool that owns it."""
    out = {"invariants": len(cl.INVARIANTS)}

    contract = os.path.join(product_dir, "handoff", "FUNCTIONAL_CONTRACT.md")
    if os.path.exists(contract):
        with open(contract, encoding="utf-8") as fh:
            text = fh.read()
        blocks = list(cl.records(text))
        out["records"] = len(blocks)
        by = {}
        for b in blocks:
            # DISTINCT records per domain: a record citing three clinical rows is one clinical
            # record, which is what a section heading counts.
            for dom in {r.split(":")[0].strip() for r in (cl._list(b, "spec_refs") or []) if ":" in r}:
                by[dom] = by.get(dom, 0) + 1
        out["by_domain"] = by
        out["domain_set"] = set(by)
        out["domains"] = len(by)
        # The pre-config source backlog. `pending_mapping` records carry no gap — requiring one broke
        # the new-pack path and duplicated a state that is already explicit — so this is where the
        # count stays visible instead. A pack that quietly accumulates them is a pack whose source
        # mapping was never finished, and nothing else would say so.
        out["pending_mapping"] = sum(1 for b in blocks if cl.source_kind(b) == cl.PENDING_MAPPING)
        out["no_spec_row"] = sum(
            1 for b in blocks
            if not [r for r in (cl._list(b, "spec_refs") or []) if r and r != cl.NO_SPEC_ROW])
        out["_cited_ids"] = {i for b in blocks
                             for i in cl.spec_ref_ids(cl._list(b, "spec_refs") or [])}

    ex = os.path.join(product_dir, "spec_pipeline", "out", "extracted.json")
    lj = os.path.join(product_dir, "spec_pipeline", "out", "lint.json")
    if os.path.exists(ex):
        with open(ex, encoding="utf-8") as fh:
            data = json.load(fh)
        lint = None
        if os.path.exists(lj):
            with open(lj, encoding="utf-8") as fh:
                payload = json.load(fh)
            lint = payload["findings"] if isinstance(payload, dict) else payload
        rows, counts = cs.coverage_report(data, product_dir, lint)
        out["items"] = len(rows)
        # DISTINCT extraction rows some record cites — the header's "of those, cited by a record".
        # Intersected with the extraction's own ids so a hallucinated citation cannot inflate it
        # (I8 reports it; this must not count it).
        have = {f"{r['domain']}:{r['row']}" for r in data.get("rows", []) if r.get("domain")}
        if "_cited_ids" in out:
            out["rows_cited"] = len(out["_cited_ids"] & have)
        out["undispositioned"] = counts.get("UNDISPOSITIONED", 0)
        out["mapped"] = counts.get("mapped", 0)
        out["context"] = counts.get("context", 0)
        # Everything the pack explicitly dispositioned, whatever word the register used for it.
        out["dispositioned"] = sum(v for k, v in counts.items()
                                   if k not in ("mapped", "context", "UNDISPOSITIONED"))
    out.pop("_cited_ids", None)
    return out


FACTS_BEGIN = "<!-- GENERATED FACTS — written by `finalize.py --write-facts`; `--check` refuses a stale one. Do not hand-edit. -->"
FACTS_END = "<!-- END GENERATED FACTS -->"


def facts_block(product_dir, known=None):
    """The header's numbers as a GENERATED table — derived, never retyped.

    The flagship contract's header claimed "Every number here is re-derived by finalize.py --check"
    over a hand-typed table no check covered. This makes the sentence true the only honest way
    round: the numbers a header states about its own pack are written by the tool that derives
    them, fenced so `--check` can regenerate and byte-compare, and a hand edit inside the fence is
    a reported defect rather than a plausible new fact.
    """
    k = known if known is not None else facts(product_dir)
    rows = [("specification rows extracted", k.get("items")),
            ("rows cited by a record", k.get("rows_cited")),
            ("rows dispositioned without a record", k.get("dispositioned")),
            ("records in this table", k.get("records")),
            ("records citing no specification row", k.get("no_spec_row")),
            ("distinct domains cited", k.get("domains")),
            ("records with no chosen source (pending_mapping)", k.get("pending_mapping"))]
    body = "\n".join(f"| {label} | **{value}** |" for label, value in rows if value is not None)
    return f"{FACTS_BEGIN}\n| | |\n|---|---|\n{body}\n{FACTS_END}"


def facts_block_errors(product_dir, known):
    """[why the generated block no longer states the facts]. Absent block, no error — a pack is not
    forced to carry one; a pack that DOES carries current numbers or goes red."""
    header = contract_header(product_dir)
    if FACTS_BEGIN.split(" — ")[0] not in header:
        return []
    m = re.search(r"(?s)<!-- GENERATED FACTS.*?" + re.escape(FACTS_END), header)
    if not m:
        return ["FUNCTIONAL_CONTRACT.md: a GENERATED FACTS opening marker with no end marker — "
                "the fence is broken, so what is generated and what is hand-typed cannot be told "
                "apart. Re-run --write-facts."]
    if m.group(0) != facts_block(product_dir, known):
        return ["FUNCTIONAL_CONTRACT.md: the GENERATED FACTS block does not match the pack — a "
                "record was added, a disposition changed, or a number in the fence was hand-edited. "
                "Run `finalize.py <pack> --write-facts`."]
    return []


def write_facts(product_dir):
    """(what changed, errors, new contract text or None). Arithmetic only, and only in two places.

    Rewrites the GENERATED FACTS fence (inserting one after the title line if the header has none)
    and the `## \\`domain\\` — N records` section headings — the exact strings `facts_block_errors`
    and `section_errors` check, so the writer and the checkers cannot disagree about what current
    means. It touches nothing else: MATURITY.yaml is a human CLAIM by design, scope sentences are
    prose a person meant, and a generator that rewrote either would destroy what the check exists
    to make visible.

    REFUSED for a sandbox pack: the frozen specimen is kept precisely because its stale claims
    demonstrate the failure; regenerating them would destroy the thing it exists to be.
    """
    from spec_extract import repo_relative
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    rel = repo_relative(os.path.abspath(product_dir), root)
    if rel.replace("\\", "/").split("/")[0] == "sandbox":
        return [], [f"{rel} is a sandbox specimen — its claims are frozen evidence, and rewriting "
                    f"them destroys what it exists to demonstrate"], None
    path = os.path.join(product_dir, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(path):
        return [], [f"{product_dir} has no handoff/FUNCTIONAL_CONTRACT.md"], None
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    known = facts(product_dir)
    changed = []

    block = facts_block(product_dir, known)
    m = re.search(r"(?s)<!-- GENERATED FACTS.*?" + re.escape(FACTS_END), text)
    if m:
        if m.group(0) != block:
            text = text.replace(m.group(0), block, 1)
            changed.append("GENERATED FACTS block refreshed")
    else:
        lines = text.splitlines(keepends=True)
        lines.insert(1, "\n" + block + "\n")
        text = "".join(lines)
        changed.append("GENERATED FACTS block inserted after the title")

    by = known.get("by_domain") or {}
    def _heading(m2):
        dom, stated = m2.group(1), int(m2.group(2))
        actual = by.get(dom, 0)
        if stated != actual:
            changed.append(f"section '{dom}' heading: {stated} -> {actual} records")
        plural = "record" if actual == 1 else "records"
        return f"## `{dom}` — {actual} {plural}"
    text = re.sub(r"^##\s+`([a-z_]+)`\s+—\s+(\d+)\s+records?", _heading, text, flags=re.M)
    return changed, [], text


def contract_header(product_dir):
    """Everything BEFORE the first record — where a pack describes what its contract covers.

    Reading the whole file would pick numbers out of the records themselves.
    """
    path = os.path.join(product_dir, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(path):
        return ""
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    cut = min([i for i in (text.find("| variable_id"), text.find("```yaml")) if i >= 0] or [len(text)])
    return text[:cut]


def claim_text(product_dir):
    """Where a pack states its TOTALS. Deliberately only MATURITY's note.

    Totals were originally also read out of the contract header, and every hit on a real pack was a
    false positive: "26 records are carried unchanged from the previous contract" and
    "## `clinical` — 96 records" are a sub-count and a per-domain heading, both correct, neither a
    claim about the pack's size. A checker that cries wolf on correct prose gets switched off, and
    then it is not protecting the one claim that WAS stale — 202607's note saying "53 records" for a
    199-record pack.

    So totals are read where a pack states totals, and the header's own claims are checked by shape
    instead: `scope_errors` for what it says it covers, `section_errors` for its per-domain counts.
    """
    parts = []
    path = os.path.join(product_dir, "handoff", "MATURITY.yaml")
    if os.path.exists(path):
        # `read_yaml` returns (doc, error) — the parse failure is a gate RESULT, not a traceback.
        # Unpacking it as a bare dict is how the first version of this silently skipped every
        # MATURITY note it was written to check: `isinstance(tuple, dict)` is False, so the file was
        # read, discarded and reported as clean. A checker that passes on a file it never read is
        # worse than no checker, so an unreadable file is surfaced rather than skipped.
        mat, err = pg.read_yaml(path)
        if err:
            parts.append(("MATURITY.yaml", f"UNREADABLE: {err}"))
        elif mat.get("note"):
            parts.append(("MATURITY.yaml note", str(mat["note"])))

    return parts


def scope_errors(product_dir, known):
    """A header claiming a NARROWER scope than the records actually cover.

    This is the failure that reads as finished: "Scope: `demographics` only" above records citing six
    domains. Only a narrowing claim is an error — a header naming no scope is not making one.
    """
    have = known.get("domain_set")
    if have is None:
        return []
    errors = []
    for m in re.finditer(r"Scope:\s*`?([a-z_]+)`?\s+only", contract_header(product_dir)):
        extra = sorted(have - {m.group(1)})
        if extra:
            errors.append(f"FUNCTIONAL_CONTRACT.md header: claims scope '{m.group(1)}' only, but "
                          f"records also cite {', '.join(extra)}")
    return errors


def section_errors(product_dir, known):
    """A per-domain section heading whose record count no longer matches the records under it.

    `## \\`clinical\\` — 96 records` is the contract's own running total per domain, and it drifts the
    moment a record is added without the heading being touched. Counted as DISTINCT records citing the
    domain, not as citations: a record citing three clinical rows is one clinical record.
    """
    by = known.get("by_domain")
    if by is None:
        return []
    path = os.path.join(product_dir, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as fh:
        text = fh.read()

    errors = []
    for dom, stated in re.findall(r"^##\s+`([a-z_]+)`\s+—\s+(\d+)\s+records?", text, re.M):
        actual = by.get(dom, 0)
        if int(stated) != actual:
            errors.append(f"FUNCTIONAL_CONTRACT.md: section '{dom}' is headed {stated} records but "
                          f"{actual} record(s) cite it")
    return errors


def source_keys(text):
    """`{variable_id: {logical source names}}`, read by the parser that already owns the field.

    This was a regex over the `source:` cell, which is precisely what `source_check.parse_sources`
    exists to prevent — its own docstring says a caller holding the file "asks this parser instead of
    writing another set of regexes against the same field", and I wrote the second set anyway. The
    regex read `(\\w+):\\s*\\{` out of the text after `inputs:`, so a quoted key, a key with a hyphen,
    a `source:` written as an indented block, or any change to the nesting would have silently
    returned NOTHING — and a source check that finds no keys reports no errors, which is
    indistinguishable from a pack that passed.
    """
    return {vid: {s for grp in groups for s in grp.get("sources", [])}
            for vid, _kind, _stem, groups, _deps in sc.parse_sources(text)}


def source_errors(product_dir):
    """A logical source a record names that the pack's config does not declare.

    `psmapet` in prostate/202606 and `psma_pet` in prostate/202607 are the same vendor table spelled
    two ways, and neither pack declares either. That is what an invented alias costs: nothing can tell
    whether two records mean one source or two, and the next drafter invents a third spelling.

    TWO CONDITIONS, and both matter:

    * a pack with NO config declares nothing, so nothing is expected to resolve. Requiring resolution
      there would fail every new tumour by construction — the workflow authors the contract BEFORE
      config exists, on purpose.
    * once a pack DOES declare sources, a key outside that set is an unresolved question, and the
      record must say so by naming a decision or a gap. This is I17's shape applied one layer down:
      not "you may not have an open question", but "an open question must be visible as one".

    Both live cases already satisfy it, which is why this can be fail-closed today: prostate/202606's
    five records over `psmapet` and `drug_episode_or_medicationorder_or_medicationadmin` (a disjunction,
    not an alias) all cite gap `G-PSMA-BP-CSF`, and oc/202606's two `unknown` records both cite a
    decision. They flagged themselves honestly; the check makes that obligatory rather than optional.
    """
    cfg = os.path.join(product_dir, "config", "data_product.yaml")
    contract = os.path.join(product_dir, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(cfg) or not os.path.exists(contract):
        return []
    doc, err = pg.read_yaml(cfg)
    if err:
        return [f"config/data_product.yaml is unreadable, so no source key can be checked: {err}"]

    # A config that exists but declares NO sources is not the same thing as a pack with no config.
    # Returning quietly on it would let a pack past by deleting its `sources:` block, which is the
    # cheapest possible way to silence this check.
    if "sources" not in doc:
        return ["config/data_product.yaml declares no `sources:` block, so no record's logical "
                "source can be resolved — a pack with config must declare what it reads"]
    # Through the SHARED resolver, exactly as spec_slice does. The engine merges the base `sources:`
    # with the ACTIVE delivery-format overlay, and `source_check.load_product_config` is the loader
    # the build, the schema validator and profile_facts all call. Reading `doc["sources"]` gave the
    # same answer on today's packs and a staler one on the first pack with an overlay — so a source
    # declared only under `formats:<data_format>:sources` would be reported here as undeclared, and
    # this check would fail a pack whose config is correct. The slicer was fixed for this in #342;
    # finalize kept the raw read, which is the same two-answers-to-one-question shape one file over.
    _cfg = sc.load_product_config(product_dir)
    declared = set(_cfg.sources) if _cfg is not None else set(doc["sources"] or {})

    with open(contract, encoding="utf-8") as fh:
        text = fh.read()

    errors = []
    by_record = source_keys(text)
    for b in cl.records(text):
        vid = cl._scalar(b, "variable_id")
        undeclared = sorted(by_record.get(vid, set()) - declared)
        if undeclared and not (cl._list(b, "decision_ids") or cl._list(b, "gap_ids")):
            errors.append(f"[{vid}] names logical source(s) {', '.join(undeclared)} that "
                          f"config/data_product.yaml does not declare, and cites no decision or gap "
                          f"— an unresolved mapping must be visible as one")
    return errors


def claim_errors(product_dir):
    """Every recognised numeric claim, checked against the derived fact."""
    if not os.path.exists(os.path.join(product_dir, "handoff", "FUNCTIONAL_CONTRACT.md")):
        # The THIRD fail-open shape this tool has had to close: with no contract at all, every
        # claim regex matched nothing and the tool printed "OK — every stated summary matches the
        # evidence" over a pack with no summary and no evidence. Absence refuses; it does not pass.
        return [f"{product_dir}: no handoff/FUNCTIONAL_CONTRACT.md — there is no stated summary "
                f"to verify, and OK here would be a check passing because it saw nothing"]
    known = facts(product_dir)
    errors = []
    for where, text in claim_text(product_dir):
        # An UNREADABLE file is a FAILURE, not a body of text to pattern-match. Running the claim
        # regexes over the parser's error message and finding no number in it reported
        # "OK — every stated summary matches the evidence", exit 0, on a pack whose summary this
        # could not read. That is the second fail-open in this tool and the exact class it exists to
        # prevent: a check that passes because it saw nothing, on a file it could not open.
        if text.startswith("UNREADABLE:"):
            errors.append(f"{where}: {text[len('UNREADABLE:'):].strip()} — the stated summary cannot "
                          f"be read, so it cannot be checked")
            continue
        flat = re.sub(r"\s+", " ", text)
        for pattern, key in CLAIMS:
            for m in re.finditer(pattern, flat, re.I):
                if key not in known:
                    continue                      # the evidence for this fact is not in the pack
                stated, actual = _n(m.group(1)), known[key]
                if stated != actual:
                    errors.append(f"{where}: says '{m.group(0)}' but the pack has {actual} {key}")
    return (errors + scope_errors(product_dir, known) + section_errors(product_dir, known)
            + source_errors(product_dir) + facts_block_errors(product_dir, known))


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("product", help="path to a product pack")
    ap.add_argument("--check", action="store_true", help="exit non-zero on any disagreement")
    ap.add_argument("--write-facts", action="store_true",
                    help="rewrite the contract header's GENERATED FACTS fence and the per-domain "
                         "section headings from the derived facts. Arithmetic only; refuses a "
                         "sandbox specimen; touches no claim a human owns.")
    a = ap.parse_args(argv)

    if a.write_facts:
        changed, errors, new_text = write_facts(a.product)
        if errors:
            for e in errors:
                print(f"  FAIL {e}", file=sys.stderr)
            return 1
        if not changed:
            print("facts are current — nothing rewritten.")
            return 0
        with open(os.path.join(a.product, "handoff", "FUNCTIONAL_CONTRACT.md"), "w",
                  encoding="utf-8", newline="") as fh:
            fh.write(new_text)
        for c in changed:
            print(f"  wrote {c}")
        return 0

    known = facts(a.product)
    errors = claim_errors(a.product)

    print(f"{a.product}")
    for k in ("records", "domains", "items", "mapped", "dispositioned", "context",
              "undispositioned", "pending_mapping", "invariants"):
        if k in known:
            print(f"   {k:<16} {known[k]}"
                  + ("   <- source registry not yet authored for these"
                     if k == "pending_mapping" and known[k] else ""))
    if errors:
        print(f"\n{len(errors)} claim(s) disagree with the evidence:")
        for e in errors:
            print(f"  FAIL {e}")
    else:
        print("\nOK — every stated summary matches the evidence")
    return 1 if (errors and a.check) else 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
