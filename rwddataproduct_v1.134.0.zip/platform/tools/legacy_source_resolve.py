#!/usr/bin/env python3
"""Resolve LEGACY multi-source contract records into the structured shape, from profile evidence.

A legacy record names several tables in one string and leaves which column belongs to which of them
to be SEARCHED for:

    source: {logical_table: "mortality + follow-up-end", physical_stem: t_mortality_v2,
             columns: {death: dthdt, fu_end: fued}}

The structured shape STATES it, which is what Gate 3 can verify per column:

    source: {kind: vendor, inputs: {t_mortality_v2: {death: dthdt, fu_end: fued}}}

The answer is not a judgment — a profile of the delivered cut says which table each column is in. This
reads that profile through `profile_io.load` (the one fail-closed reader) and rewrites only what the
evidence settles unambiguously.

FAILS CLOSED, both directions. A column found in NO profiled table, or in MORE THAN ONE, leaves the
record exactly as it was and is reported. Guessing here would write a mapping that looks verified and
was not, which is the failure the whole Gate 3 apparatus exists to prevent.

The profile is VENDOR-DERIVED and RESTRICTED: it is read from a path the caller supplies — the
profiler rig's `--out-dir` at Gate 3 — never from anything inside the checkout. Only table and column
NAMES cross into the contract; no counts, no top values, no dates.

    python3 platform/tools/legacy_source_resolve.py <pack> --profile <profile.tsv> [--write]

`--write` also removes every resolved variable from handoff/LEGACY_SOURCES.yaml, which is the only
direction that file is allowed to move.

stdlib only.
"""
import argparse
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from contract_lint import _source_field, read, records          # noqa: E402
from profile_io import load                                     # noqa: E402

# `a + b` in logical_table is what MAKES a record legacy: one entry standing for several tables.
LEGACY_JOIN = re.compile(r"\+")


def column_index(tables):
    """{column name -> {table_base}} — the whole of what this tool takes from the profile."""
    index = {}
    for base, columns in tables.items():
        for col in columns:
            index.setdefault(col.strip().lower(), set()).add(base)
    return index


def legacy_records(text):
    """(variable_id, source_body) for every record still on the multi-source legacy shape."""
    out = []
    for block in records(text):
        vid = re.search(r"(?m)^variable_id:\s*(\S+)", block)
        body = re.search(r"(?m)^source:\s*(\{.*\})\s*$", block)
        if not (vid and body):
            continue
        if _source_field(block, "kind"):
            continue                                    # already structured
        if LEGACY_JOIN.search(_source_field(block, "logical_table") or ""):
            out.append((vid.group(1), body.group(1)))
    return out


def source_columns(body):
    """The `columns: {alias: name, ...}` map, verbatim."""
    m = re.search(r"columns:\s*\{([^}]*)\}", body)
    if not m:
        return {}
    pairs = {}
    for tok in m.group(1).split(","):
        if ":" in tok:
            alias, name = tok.split(":", 1)
            pairs[alias.strip()] = name.strip().strip('"')
    return pairs


def resolve(vid, body, index):
    """(structured source, []) when the profile settles every column; (None, reasons) otherwise."""
    cols = source_columns(body)
    if not cols:
        return None, [f"{vid}: legacy shape with no `columns:` map to resolve"]
    by_table, reasons = {}, []
    for alias, name in cols.items():
        hits = index.get(name.lower(), set())
        if len(hits) == 1:
            by_table.setdefault(next(iter(hits)), {})[alias] = name
        elif not hits:
            reasons.append(f"{vid}: column `{name}` is in NO profiled table — either the name is "
                           f"wrong or the table was not profiled; not guessing")
        else:
            reasons.append(f"{vid}: column `{name}` is in {len(hits)} profiled tables "
                           f"({', '.join(sorted(hits))}) — which one this record means is a person's "
                           f"call, not the profile's")
    if reasons:
        return None, reasons
    inner = ", ".join(f"{t}: {{" + ", ".join(f"{a}: {c}" for a, c in sorted(cs.items())) + "}"
                      for t, cs in sorted(by_table.items()))
    return "{kind: vendor, inputs: {" + inner + "}}", []


def shrink_allowlist(path, resolved):
    """Remove every resolved variable from LEGACY_SOURCES.yaml. Only ever removes."""
    if not os.path.exists(path) or not resolved:
        return 0
    kept, dropped = [], 0
    for line in read(path).splitlines(True):
        m = re.match(r"\s*-\s*(\S+)\s*$", line)
        if m and m.group(1) in resolved:
            dropped += 1
            continue
        kept.append(line)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("".join(kept))
    return dropped


def profile_inside_checkout(path):
    """True when the profile sits in the repo — which it must never do.

    `.gitignore` stops a commit, not a read by an indexing tool or any local process, so the rule is
    that restricted output is not in the tree at all. Refusing the path is what keeps someone from
    resolving mappings against a committed copy of the delivered schema and calling the result Gate 3 evidence.
    """
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # .../platform -> checkout
    root = os.path.dirname(root) if os.path.basename(root) == "platform" else root
    try:
        return os.path.commonpath([os.path.abspath(path), root]) == root
    except ValueError:                       # different drives on Windows — cannot be inside
        return False


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack")
    ap.add_argument("--profile", required=True,
                    help="a data_profiler.R profile TSV, from the rig's --out-dir. Never a path "
                         "inside the checkout: the profile is restricted vendor-derived output.")
    ap.add_argument("--write", action="store_true",
                    help="apply the resolutions and shrink LEGACY_SOURCES.yaml (default: report only)")
    a = ap.parse_args(argv)

    if profile_inside_checkout(a.profile):
        sys.exit(f"{a.profile} is inside the checkout. A profile is restricted vendor-derived "
                 f"output and never enters it — point --profile at the rig's --out-dir. "
                 f"(A committed copy or fixture is not Gate 3 evidence.)")

    tables, _ = load(a.profile)
    index = column_index(tables)
    contract = os.path.join(a.pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    text = read(contract)

    resolved, blocked = {}, []
    for vid, body in legacy_records(text):
        new, reasons = resolve(vid, body, index)
        if new:
            resolved[vid] = (body, new)
        else:
            blocked.extend(reasons)

    print(f"{os.path.basename(a.pack)}: {len(resolved) + len(set(r.split(':')[0] for r in blocked))} "
          f"legacy record(s) — {len(resolved)} resolved from the profile, "
          f"{len(set(r.split(':')[0] for r in blocked))} left as they are")
    for vid, (_, new) in sorted(resolved.items()):
        print(f"   {vid:<28} -> {new}")
    for r in blocked:
        print(f"   BLOCKED {r}")

    if a.write and resolved:
        for _, (old, new) in resolved.items():
            # Replace the exact source body, so a record whose text differs by a byte is not touched.
            assert text.count(old) >= 1, "the source body to replace is not in the contract"
            text = text.replace(old, new, 1)
        with open(contract, "w", encoding="utf-8") as fh:
            fh.write(text)
        n = shrink_allowlist(os.path.join(a.pack, "handoff", "LEGACY_SOURCES.yaml"), set(resolved))
        print(f"\nwrote {contract}; removed {n} entry/entries from LEGACY_SOURCES.yaml")
    elif a.write:
        print("\nnothing the profile settles unambiguously — nothing written")
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
