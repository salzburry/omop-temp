#!/usr/bin/env python3
"""Which config blocks does the WORKBOOK actually stand behind? — block by block.

    python3 platform/tools/config_propose.py <pack>
    python3 platform/tools/config_propose.py <pack> --json

THE FAILURE THIS PREVENTS. A scaffold pack ships with executable YAML that was INFERRED from
published practice — mCRC has 26 governed blocks and not one approved workbook requirement behind
any of them. After a drafting session that config still looks exactly the same: same files, same
keys, same clean lint. The difference between "the workbook confirmed this" and "somebody guessed
this and nothing has contradicted it yet" is invisible in the artifact, and the second reads as the
first to anyone who was not in the room. Demonstrating a scaffold as generated output is then an
easy mistake to make honestly, which is the kind worth engineering against.

So every governed block is classified by WHAT STANDS BEHIND IT, and the classes are named so that
none of them can be misread as approval:

    confirmed    a contract record binds this block AND cites specification rows. The workbook
                 reached this block. It does NOT mean the values are right — that is Gate 4.
    changed      a record binds it and the BINDER's OWN comparators find a positive contradiction
                 with it — a window number, a record-selection direction, an enumerated code. A
                 person reconciles; this only says the two disagree. MECHANICAL ONLY: it cannot see
                 two records sharing one block with contradictory rules, because judging that means
                 comparing derivations for meaning. That is reported under `shared blocks` instead.
    unresolved   a record binds it but the requirement is undecided, or it cites no spec row.
                 Bound to a question, not to an answer.
    unsupported  NO record binds it. Whatever this block says came from somewhere other than the
                 approved specification. For a scaffold pack that is every block, and saying so in
                 one line is the entire point of this tool.

AND THE OTHER DIRECTION, which a block-keyed report would silently drop: a record that binds NO
block is a requirement nothing implements. Both lists have to be present or "100% confirmed" can be
true of a config that covers a third of the specification.

IT PROPOSES NOTHING AND WRITES NOTHING. `contract_binding --promote` already emits candidate VALUES
for a person to shape; this answers the different question of which blocks have a workbook behind
them at all. Neither writes into `variables/`: an existing block holds decisions somebody made.

DELIBERATELY NOT A COMMITTED ARTIFACT. Output goes to stdout, and `--json` too. This is a snapshot
of a moving negotiation between a contract and a config — it changes with every record drafted —
so a committed copy would be a stale claim wearing a generated file's clothes, which is what
`status.py` refuses to write its own JSON for. Redirect it if you want the day's record.

stdlib only (plus what contract_lint and contract_binding already need).
"""
from __future__ import annotations

import argparse
import json
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import contract_binding as cb                                            # noqa: E402
import contract_lint as cl                                              # noqa: E402
from spec_extract import repo_relative                                   # noqa: E402

CONFIRMED, CHANGED, UNRESOLVED, UNSUPPORTED = (
    "confirmed", "changed", "unresolved", "unsupported")
# Worst first. A reader works down the list, and what nothing stands behind is the finding.
ORDER = (UNSUPPORTED, UNRESOLVED, CHANGED, CONFIRMED)
MEANING = {
    UNSUPPORTED: "no contract record binds it — nothing from the approved specification reached "
                 "this block",
    UNRESOLVED: "bound to a record whose requirement is undecided, or which cites no specification "
                "row",
    CHANGED: "the contract's stated window, selection or enumeration contradicts this block — "
             "mechanical comparison only, so a person reconciles",
    CONFIRMED: "a record binds it and cites specification rows. NOT an approval: Gate 4 decides "
               "whether the values are right",
}
# A record whose `requirement` is any of these is a question, not an answer.
UNDECIDED = ("decision_required", "upstream_required", "blocked")


def _record_status(block):
    """The `requirement:` word out of a record's `status:` mapping, or "" — through contract_lint's
    reader, never a second parse of the same line."""
    raw = cl._scalar(block, "status") or ""
    for part in str(raw).strip("{} ").split(","):
        k, _, v = part.partition(":")
        if k.strip() == "requirement":
            return v.strip()
    return ""


def records_by_block(pack):
    """({block ref: [record]}, [records binding nothing]).

    A record may name several blocks and a block may be claimed by several records; both are
    normal, and flattening either to "the" record would pick one arbitrarily.
    """
    path = os.path.join(REPO, pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(path):
        return {}, []
    by_block, unbound = {}, []
    for block in cl.records(cl.read(path)):
        refs = [r for r in (cl._list(block, "implementation_refs") or []) if "#/" in r]
        rec = {"variable_id": cl._scalar(block, "variable_id") or "?",
               "spec_refs": [r for r in (cl._list(block, "spec_refs") or [])
                             if r and r != cl.NO_SPEC_ROW],
               "requirement": _record_status(block)}
        if not refs:
            unbound.append(rec)
            continue
        for ref in refs:
            by_block.setdefault(ref, []).append(rec)
    return by_block, unbound


def contradicted_blocks(pack, blocks=None):
    """({block ref: [finding]}, {records, compared, findings}) — the blocks the BINDER's own
    comparators name in a positive contradiction.

    THE STATE THIS FEEDS WAS UNREACHABLE. `classify` took a `contradictions` argument, `report`
    called it without one, and no other caller passed it — so `changed` could never be produced,
    while the legend and the counts table advertised it. `changed: 0` then read as "checked, none
    found" when the truth was "never checked", which is the absence-reported-as-a-clean-result
    failure this repository has now closed in six other tools. An external review caught it.

    WHY THE BINDER'S COMPARATORS AND NOT A NEW ONE. `contract_binding.compare_parameters` and
    `compare_enumerations` already answer "does the contract state something this config does not
    hold" — window offsets and durations, record-selection direction, enumerated labels and codes.
    A second implementation here would eventually disagree with `check`, and the disagreement would
    be silent. Same reason the block set comes from `governed_blocks` rather than a private walk.

    HOW A BLOCK IS NAMED. Both comparators return prose for a person, but every finding that
    concerns a block renders that block's ref VERBATIM (`… vs variables/x.yaml#/k: …`), so each
    known ref is tested for membership in the finding string. That is a closed set of exact strings,
    not a parse of the prose. A finding naming no block — a source stem nothing resolves, a spec row
    no record binds — contributes nothing, which is right: neither is a claim about a config block.

    WHAT IT CANNOT SEE, and the reason `shared blocks` exists: two records binding ONE block with
    contradictory rules. Judging that means comparing derivations for meaning, which is a person's
    reading. This finds only what the comparators can state mechanically.

    THE DENOMINATOR COMES BACK WITH IT. `changed: 0` over a contract nothing compared is silence
    wearing agreement's number, so the caller is given what was actually compared.
    """
    product = os.path.join(REPO, pack)
    if not os.path.exists(os.path.join(product, "handoff", "FUNCTIONAL_CONTRACT.md")):
        return {}, {"records": 0, "compared": 0, "findings": 0}
    if blocks is None:
        blocks = cb.governed_blocks(product, cb.pack_yaml(product))
    found, stats = cb.compare_parameters(product, blocks)
    found = list(found) + list(cb.compare_enumerations(product, blocks))
    hits = {ref: named for ref in blocks if (named := [f for f in found if ref in f])}
    return hits, {"records": stats.get("records", 0), "compared": stats.get("compared", 0),
                  "findings": len(found)}


def classify(pack, contradictions=None):
    """[{block, state, why, records, spec_refs}] for every block the BUILD reads.

    Keyed on `contract_binding.governed_blocks` — the same set the binder holds a contract to — so
    a block this report calls unsupported is exactly a block the binder says nothing claims. A
    private walk of `variables/*.yaml` here would eventually disagree with it, and the disagreement
    would be invisible.

    `contradictions=None` means COMPUTE them, which is what every real caller wants; a passed
    iterable overrides, and an EMPTY one is honoured as "none" rather than falling back to a scan —
    a test that means to suppress the scan must be able to.
    """
    product = os.path.join(REPO, pack)
    cover = cb.pack_yaml(product)
    block_map = cb.governed_blocks(product, cover)
    blocks = sorted(block_map)
    by_block, _unbound = records_by_block(pack)
    if contradictions is None:
        contradicted = contradicted_blocks(pack, block_map)[0]
    elif isinstance(contradictions, dict):
        contradicted = contradictions            # {ref: [finding]} — keeps the finding text
    else:
        contradicted = {r: [] for r in contradictions}

    out = []
    for ref in blocks:
        recs = by_block.get(ref, [])
        spec_refs = sorted({s for r in recs for s in r["spec_refs"]})
        if not recs:
            state, why = UNSUPPORTED, MEANING[UNSUPPORTED]
        elif ref in contradicted:
            # NAME THE CONTRADICTION, not the class. "a record disagrees with this block" sends a
            # reader back to re-derive what the comparator already worked out and printed.
            state = CHANGED
            why = contradicted[ref][0] if contradicted[ref] else MEANING[CHANGED]
        elif not spec_refs:
            state, why = UNRESOLVED, ("bound by "
                                      f"{', '.join(r['variable_id'] for r in recs)}, which cite no "
                                      f"specification row")
        elif all(r["requirement"] in UNDECIDED for r in recs):
            state, why = UNRESOLVED, (f"every record binding it "
                                      f"({', '.join(r['variable_id'] for r in recs)}) declares "
                                      f"`requirement: {recs[0]['requirement']}`")
        else:
            state, why = CONFIRMED, MEANING[CONFIRMED]
        out.append({"block": ref, "state": state, "why": why,
                    "records": [r["variable_id"] for r in recs], "spec_refs": spec_refs})
    return out


def report(pack):
    hits, scan = contradicted_blocks(pack)
    rows = classify(pack, contradictions=hits)
    _by_block, unbound = records_by_block(pack)
    counts = {s: sum(1 for r in rows if r["state"] == s) for s in ORDER}
    return {"product": pack, "blocks": rows, "counts": counts, "contradiction_scan": scan,
            "records_binding_nothing": [r["variable_id"] for r in unbound]}


def render(pack):
    d = report(pack)
    rows, counts = d["blocks"], d["counts"]
    total = len(rows)
    L = [f"# Configuration provenance — {pack}", "",
         "**What stands behind each executable config block.** Generated, read-only, and it",
         "approves nothing: `confirmed` means the workbook reached a block, never that its values",
         "are right. Gate 4 decides that.", ""]
    if not total:
        L.append("This pack composes no governed config block.")
        return "\n".join(L)

    has_contract = os.path.exists(os.path.join(REPO, pack, "handoff", "FUNCTIONAL_CONTRACT.md"))
    if not has_contract:
        L += [f"> **There is no contract.** All {total} block(s) below are `unsupported`, and that",
              "> is not a defect in them — drafting has not started. Every value in this pack came",
              "> from somewhere other than an approved specification. Nothing here may be shown as",
              "> generated from a workbook.", ""]

    L += ["| state | blocks | what it means |", "|---|---:|---|"]
    for s in ORDER:
        L.append(f"| `{s}` | {counts.get(s, 0)} | {MEANING[s]} |")
    L += ["", f"{total} governed block(s)."]

    # THE DENOMINATOR UNDER `changed`. A zero that compared nothing is silence wearing agreement's
    # number — and until an external review caught it, `changed` was not computed at all, so the 0
    # in that row was the strongest possible form of this defect.
    scan = d["contradiction_scan"]
    if scan.get("records"):
        L += ["", f"`changed` is decided by the binder's own comparators — "
                  f"{scan['compared']} parameter comparison(s) over {scan['records']} contract "
                  f"record(s), yielding {scan['findings']} finding(s). It sees window numbers, "
                  f"selection direction and enumerated codes; it CANNOT see two records sharing a "
                  f"block with contradictory rules (see `shared blocks`)."]
    elif has_contract:
        L += ["", "> **`changed` compared nothing.** This pack has a contract, but none of its "
                  "records states a window, selection or enumeration a config block could "
                  "contradict. `changed: 0` here is silence, not agreement."]

    # FAN-OUT. A block bound by many records is not a defect — 30 of prostate's 38 are shared, and
    # `lab_values` answers to 30 requirements — so flagging sharing as suspicious would be a finding
    # everyone learns to ignore. What nothing said is the CONSEQUENCE: one block can hold one rule,
    # so editing a shared block changes every requirement bound to it at once, and a record whose
    # rule disagrees with its block-mates is silently the one not implemented.
    #
    # Detecting that disagreement mechanically would need to compare derivations for MEANING, which
    # is a person's reading — `LOT1CAT` and `LOT2CAT` legitimately differ in wording while sharing
    # one codelist. So this reports the blast radius and names the records; it does not judge them.
    fan = sorted(((len(r["records"]), r) for r in rows if len(r["records"]) > 1), reverse=True,
                 key=lambda x: (x[0], x[1]["block"]))
    if fan:
        L += ["",
              f"## shared blocks — {len(fan)}", "",
              "One block holds ONE rule. Each of these answers to several requirements at once, so",
              "a change to it moves all of them, and a record whose rule disagrees with its",
              "block-mates is the one silently not implemented. Not a defect — a review target,",
              "and the largest ones first.", "",
              "| block | requirements | records |", "|---|---:|---|"]
        for n, r in fan:
            names = ", ".join(r["records"][:8]) + (" …" if len(r["records"]) > 8 else "")
            L.append(f"| `{r['block']}` | {n} | {names} |")
    if d["records_binding_nothing"]:
        L += ["",
              f"**{len(d['records_binding_nothing'])} contract record(s) bind no config block** — "
              "requirements nothing implements. A block-keyed report that omitted these could show "
              "every block confirmed while the config covered a third of the specification:", ""]
        for v in d["records_binding_nothing"][:40]:
            L.append(f"  - `{v}`")
        if len(d["records_binding_nothing"]) > 40:
            L.append(f"  - …and {len(d['records_binding_nothing']) - 40} more")

    for s in ORDER:
        picked = [r for r in rows if r["state"] == s]
        if not picked:
            continue
        L += ["", f"## {s} — {len(picked)}", "", "| block | records | specification rows |",
              "|---|---|---|"]
        for r in picked:
            L.append(f"| `{r['block']}` | {', '.join(r['records']) or '—'} | "
                     f"{', '.join(r['spec_refs']) or '—'} |")
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("product", help="path to a product pack")
    ap.add_argument("--json", action="store_true",
                    help="machine-readable, to STDOUT and no file — this is a snapshot of a moving "
                         "negotiation, so a committed copy would be a stale claim")
    a = ap.parse_args(argv)
    pack = repo_relative(os.path.abspath(a.product), REPO)
    if not os.path.isdir(os.path.join(REPO, pack)):
        sys.exit(f"{a.product}: not a product pack directory")
    print(json.dumps(report(pack), indent=2) if a.json else render(pack))
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
