#!/usr/bin/env python3
"""Functional-contract lint — the anti-drift guard for any product's FUNCTIONAL_CONTRACT.md.

The contract is one canonical record per SPECIFICATION ROW (`governance/WORKFLOW.md` section 8). A
record may be drafted over several rows while a pack is still `contract: draft` — that is how `LAB`
came to cite 30 — but a pack cannot claim `coverage_complete` or above that way (I16). Per-specification-item accounting also lives in the coverage report; I16 is
what makes the contract agree with it rather than stand beside it. This lint keeps the contract from
drifting back into the contradictory prose it replaced. It enforces these schema invariants:

  I1  every variable_id appears exactly once (no duplicate/contradictory records)
  I2  every decision_id exists in DECISIONS.md; every gap_id exists in the ENGINE_GAPS gap-ID index
  I3  only approved enum values in status.* / publish.* / output.role / output.name_status
  I4  every `published` record carries physical_name, type, nullable
  I5  dashboard: configured  =>  the variable is listed in dashboard_vars.yaml (absent file => none allowed)
  I6  every record is complete — it carries the FULL canonical key set (section B), so a record can
      never silently drop to a partial copy of the contract (irrelevant keys are `n/a`, never omitted)
  I7  RETIRED — it was status-blind and duplicated I11, which asks the same question correctly.
      A RESOLVED decision id may stay on an approved record: it is the trace of what settled it
  I8  every `<domain>:<row>` spec_ref resolves to a row actually captured from the approved spec
      (section C tells RWDE to walk back to the source row — a dangling ref breaks that).
      Domains are the shared citation vocabulary in governance/SPEC_DOMAINS.md
  I12 the status axes must be CONSISTENT with each other, not merely legal on their own. A record
      cannot be validated further than it is built, or built further than its requirement is settled
  I13 an implementation that falls short — config_gap, engine_gap, partial, not_derivable — must name
      the gap. Without one the shortfall is real, tracked nowhere, and invisible in the build
  I11 a record is `decision_required` IF AND ONLY IF it cites an OPEN requirement-level decision.
      This is what closes the loop: mark a decision RESOLVED in DECISIONS.md and CI immediately names
      every record that now needs its answer written in — and a record blocked on nothing is caught too
  I10 an APPROVED requirement carries no `TODO`. The scaffold emits TODO for every field needing
      judgment; flipping only the status would approve a requirement nobody has written
  I14 a pack claiming `contract: approved` in MATURITY.yaml has no record still being written, and no
      decision-blocked record claiming to be built. This is the workflow's Gate 2 exit — every
      requirement approved or explicitly blocked by a named decision, and a blocked one not implemented
  I16 a pack claiming `contract: coverage_complete` or above has no record spanning more than one
      specification row.
      A family record is a LIST — ten analytes, eight sites, twelve therapy categories — and a list is
      where the next tumour's new member goes missing: it lands inside the record's prose and inside a
      config list item, and neither this lint nor `contract_binding` (which iterates TOP-LEVEL config
      blocks) has anything to go red about. Judged per PACK like I14, not per record: a contract
      cannot be complete row by row while one record answers thirty rows at once. Below
      `coverage_complete` a pack is still being drafted and grouping is ordinary work
  I15 every record is bound to the TEXT it was written from, not merely to row numbers. RWB editing a
      rule IN PLACE is invisible to every other check — the row still exists, the citation resolves,
      coverage still maps it — so `spec_digest` moves and the record must be re-read
  I17 a record over a spec row the deterministic lint judged UNSETTLED — the spec author's own
      `[verify]` marker, prose where a rule should be, a definition cut off, conditions with no
      terminal else — must stay visibly unresolved: a TODO on a REQUIREMENT field (REQUIREMENT_FIELDS
      — not the source or naming axis), or a decision that records where the answer came from. This
      is the only invariant aimed at a PLAUSIBLE requirement answer filled into a row the
      specification leaves unsettled. Others catch other forms of invention — I3 an invented enum
      value, I8 a fabricated citation, I2 a decision or gap id that does not exist, I15 a record no
      longer matching its source text — but each of those has a wrong SHAPE to detect. This one
      catches a value that is wrong only in FACT.
      A fabricated `age >= 18` over a row whose text says "no age operator/threshold is
      present in the source documents" is complete, correctly typed, properly cited and its digest
      matches — every other check here passes on it. The gap is widest exactly where review is
      thinnest: a cheaper or weaker model drafting hundreds of records unattended. `spec_lint`
      already computes which rows are unsettled, with no model involved, so judgment the drafter may
      not have becomes a property the lint checks
  I9  an APPROVED requirement that is not derivable must name a gap. The combination is legitimate —
      RWB can require something the feed cannot supply — but it must never sit silently: without a
      gap_id the variable simply vanishes from the build with nothing recording why.
      FOLDED INTO I13, which had the same trigger: `not_derivable` is one of the shortfall states,
      so every record I9 could name produced two failures for one defect. I13 owns the emission
      and carries this reasoning in its own message for the approved case
  I18 `source.kind: pending_mapping` — the state every new tumour starts in, where the requirement is
      stated but no mapping is settled — must carry the spec's own identifiers verbatim, and can
      never be approved, source-verified or implemented. It requires NO gap: a gap is an APPROVED
      requirement the build or feed cannot satisfy, which arrives after the contract exists, and the
      starter pack ships no ENGINE_GAPS.md — so demanding one made I2 fail on every genuinely new
      product. What closes the state is a human settling this concept's mapping, and Gate 4
      (product_gates) refuses approval while any mapping is open. Without a legal value here
      the drafting rule could only say what NOT to write, and drafters filled the gap with an invented
      alias — which is indistinguishable from a real mapping once config arrives
  I19 `implementation_refs` is ANSWERED on every record: `[none]` when nothing implements it yet, or
      the references when something does. The column being present is not the field being answered,
      and a blank cell or a `TODO` must not read the same as "nothing yet, deliberately"
  I20 every inline `{...}` cell is STRUCTURALLY well formed — its braces balance. Every other check
      in this file reads a field by scanning for its token, so a cell can be malformed and still
      answer each question correctly. It was: 77 records on prostate/202606 and 34 on 202607 carried
      `codes: {Present: "", role: published}` — one dropped `}`, which puts `role` INSIDE the codes
      map. `_kv` found `role: published` anyway, so all nineteen other invariants passed over a
      third of the pack while `output.role` did not structurally exist. Finding a token is not
      proving a structure, and this is the one invariant that asks the second question
  I21 every OPEN decision is REFERENCED somewhere in the contract — the reverse of I2. I2 keeps a
      cited id defined; nothing kept a defined-and-OPEN question visible from the contract, so a
      question could silently vanish from the record set (or never be wired in) while the register
      still showed it OPEN — invisible to every drafter, who reads the contract, not the register.
      Content-based on purpose, not decision_ids-based: an OPEN question may legitimately be
      carried by a notes cell rather than a citation — a decision gating config-only additions has
      no records of those variables to cite it — and forcing a decision_ids citation would drag
      unrelated records to decision_required via I11. Zero OPEN decisions passes vacuously; the
      parser floors above already refuse a register the parser stopped reading. Judged from
      `coverage_complete` UP, like I16: below it a pack is still being drafted and a question
      legitimately precedes the records that will cite it — punishing an early question would teach
      drafters to raise questions late, the exact wrong lesson. This invariant absorbs the check a
      pack-local test (test_decision_refs.py) enforced for one product only — the pack that lacked
      the copy carried OPEN decisions unguarded, which is the one-owner rule's argument made by
      counterexample
  I22 `required_rule` IS the cited row's Definition cell, verbatim after cell folding — not a
      paraphrase of it. I15 binds the record to the row's TEXT, but nothing bound the record's own
      statement of the rule to that text: a record could carry a compressed or "improved" reading
      with a perfectly matching digest, and the rule cell is the one thing every reader takes as
      the requirement. `contract_record --item` writes the cell verbatim precisely so drafting
      cannot paraphrase; this invariant is what keeps it verbatim afterwards, when the table is
      edited by hand. Measured before it was written: 198 of 202 live records were already
      byte-identical under folding, and one of the two real divergences (VIS120) was a compressed
      reading nobody approved — the exact defect class. Compared only for single-row citations
      (a multi-row family record's rule is I16's business to split); a row whose Definition cell
      is empty is skipped — there is nothing to be faithful to, and a TODO there is I10/I17's.
      The interpretation belongs in `derivation` and `notes`; the requirement cell quotes the spec,
      typos and all — a corrected typo is a SPEC_QC finding, not a rewritten rule
  I23 worked arithmetic in the `acceptance` example must actually compute. The example is the one
      place a record shows its rule producing a number, and everyone downstream reads it as
      evidence — yet nothing checked the division, and a wrong worked example sailed through five
      simulated drafting runs untouched. Checked only for the unambiguous shape `a / b = c` over
      SIGNED decimal literals (a date like 4/31/2027 has no `=` and never matches; `1e3/2` is
      refused a mid-number match by the boundary guard); a zero denominator is an error, not a
      skip; comparison is in Decimal at the example's own precision, tolerating one unit in its
      last decimal place so a floor and a round both pass and a real error does not
  I24 every `depends_on` entry RESOLVES — and resolving is not enough. The field is a
      cross-reference, and a cross-reference that names nothing is prose wearing a field's
      clothes: five simulated journeys wrote `depends_on: [INDEXDT]`-style entries no tool ever
      read, and a typo there would lint clean forever. An entry must be another record's
      variable_id, a variable the extraction names, the literal `none`, or `engine:<stage>` for a
      dependency on an engine intermediate (the stage must exist under platform/engine/stages
      when the engine tree is present) — the namespace makes "this is plumbing, not a record" an
      explicit claim instead of a floating name. A record depending on ITSELF is refused, and
      record-to-record cycles are refused as a pack-level check: mutually dependent records
      describe no build order while each edge looks fine alone

The invariants are product-agnostic and live here ONCE. A product's own
`handoff/tests/test_functional_contract.py` supplies its directory and its parser floors — nothing
else. A copy per product would be every invariant free to drift once per product.

    python3 platform/tools/contract_lint.py <product-dir>

stdlib only.
"""
import argparse
import ast
import decimal
import hashlib
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from spec_extract import repo_root as checkout_root       # noqa: E402 — stdlib only

# --- controlled vocabularies (must match FUNCTIONAL_CONTRACT.md section B) ---
REQ = {"approved", "draft", "decision_required"}
SRC = {"verified", "dictionary_only", "unverified", "unavailable"}
IMPL = {"implemented", "partial", "config_gap", "engine_gap", "not_implemented", "not_derivable"}
# governance/WORKFLOW.md section 7 is the naming authority. `passed_synthetic` is kept as a legacy
# spelling of `passed_test` so an older contract still parses; new records should use passed_test.
VAL = {"not_run", "passed_test", "passed_live", "failed", "passed_synthetic"}

# The finer source axes WORKFLOW.md section 7 defines. A product adopts them at Gate 3; until then it
# may carry the coarse `source` axis. The lint must accept BOTH, or the documented escape hatch only
# opens one way and a record written exactly as the workflow instructs fails.
FINE_SOURCE_AXES = {
    "source_mapping":     {"proposed", "human_confirmed"},
    # `not_available` states a fact about the FEED, not a verdict on the column: no data dictionary
    # was supplied. Without it, requiring `passed` from a document that does not exist made these
    # axes unadoptable and pushed a product back to the coarse axis — the conflation they undo.
    "dictionary_check":   {"not_run", "passed", "failed", "not_available"},
    "live_schema_check":  {"not_run", "passed", "failed"},
    "data_profile_check": {"not_run", "reviewed", "issue_open", "accepted"},
}
ROLE = {"published", "internal", "metadata", "excluded"}
NAMEST = {"aligned", "undecided"}
PUB = {"configured", "required", "proposed", "excluded", "undecided"}
# Decisions that govern OUTPUT (physical name / codes), NOT the requirement — may sit beside `approved`.
OUTPUT_DECISIONS = {"NAME-ALIGN", "CODE-ALIGN"}

# The canonical key set from section B, minus `variable_id` (its presence is what makes a block a record).
# I6 requires EVERY one of these on EVERY record: the contract is the single source of truth, so no record
# may silently drop to a partial copy (irrelevant keys are `n/a`/`[]`, never omitted). status/output/publish/
# decision_ids/gap_ids get stronger structural checks below; the rest are presence-only here.

# Derived from the enumeration in this module's own docstring, which is where the invariants are
# declared. Restating the count in prose is how a stale "all N invariants" claim reached a pack note
# after I16 and I17 landed — a claim nothing could check because nothing owned the number.
def _active_invariants(doc):
    """The invariants this module INDEPENDENTLY EMITS, read from its own enumeration above.

    The enumeration is a registry of every id ever issued, and two of them no longer fire: I7 is
    RETIRED, and I9 is FOLDED INTO I13 — its trigger is a strict subset of I13's, so I13 owns the
    emission and merely explains the approved case in its own message.

    That last one is why this parses BLOCKS rather than lines: a folded id can be NAMED inside
    another invariant's explanatory text, so scanning for any I<number> pattern would count it as active.
    `test_finalize` anchors the emission at the START of the message and asserts this set equals it
    exactly.
    """
    blocks, cur = {}, None
    for line in (doc or "").splitlines():
        m = re.match(r"^  (I\d+)\s+(.*)$", line)
        if m:
            cur = m.group(1)
            blocks[cur] = [m.group(2)]
        elif cur and line.startswith("      "):
            blocks[cur].append(line.strip())
        elif line.strip():
            cur = None
    active = [k for k, v in blocks.items()
              if not v[0].startswith("RETIRED") and not any("FOLDED INTO" in x for x in v)]
    return tuple(sorted(active, key=lambda i: int(i[1:])))


INVARIANTS = _active_invariants(__doc__)

# I23's arithmetic shape: signed decimal / signed decimal = signed decimal, nothing looser.
# Boundary-hardened after external reviews' probes: BOTH signs are captured in BOTH spellings —
# `-181/30.4375 = -5.95` must compute against -181, `181/-30.4375 = 99.99` must not parse
# unsigned, and `+1/2 = 9` used to fall outside the pattern entirely and go unjudged, which is a
# fail-open for exactly the cells this check exists to judge. The leading guard still refuses to
# start a match mid-number (`1e3/2 = 999` must not match as `3/2 = 999`), and a slash without an
# `=` after the divisor (a calendar date, mg/m2) still never matches.
_ACCEPT_ARITH = re.compile(
    r"(?<![\w.+-])([+-]?\d+(?:\.\d+)?)\s*/\s*([+-]?\d+(?:\.\d+)?)\s*=\s*([+-]?\d+(?:\.\d+)?)(?![\w.])")

CANON = ("spec_refs", "spec_digest", "required_rule", "source", "grain", "anchor", "window", "record_selection",
         "tie_break", "derivation", "cohort_applicability", "missing", "units", "depends_on",
         "output", "status", "decision_ids", "gap_ids", "publish", "acceptance", "notes")

# I17's escape hatch is FIELD-SPECIFIC: a record over an UNSETTLED spec row must leave the REQUIREMENT
# visibly open — a TODO on a field that carries the rule's own answer, or a decision/gap. These are
# those fields. The lint findings name the ROW and the KIND (spec_lint scans whole-row text and emits
# neither a spec column nor a contract field), so this is as field-specific as the deterministic
# evidence allows: the requirement's ANSWER must be left open, not that the finding named `derivation`
# in particular. A TODO on a field OUTSIDE this set — `output: {physical_name: TODO}` (the spec being
# silent on the PHYSICAL NAME, which is routine and legitimate) or a `source:` mapping still open (the
# SOURCE axis, which this invariant's header states is SEPARATE from the requirement) — does not
# excuse a confidently invented `record_selection`/`derivation`. Letting any TODO anywhere satisfy
# I17 was the fail-open: the lint flags the row, the drafter answers the behaviour anyway, and one
# unrelated TODO made it pass.
REQUIREMENT_FIELDS = frozenset({"required_rule", "grain", "anchor", "window", "record_selection",
                                "tie_break", "derivation", "cohort_applicability", "missing", "units"})
# `acceptance` is deliberately NOT here. It is the worked EXAMPLE (input -> expected output), not the
# scientific answer that PLACEHOLDER / TRUNCATED / NO_TERMINAL_ELSE flagged as missing — and every
# scaffold starts it at TODO. Counting it as the escape reopened the hole one level down: a record
# could answer `required_rule`, `window` and `derivation` confidently over an UNSETTLED row and leave
# only `acceptance: TODO`, and I17 passed. A missing example is a drafting-maturity fact; it does not
# say the requirement is unresolved. Move it and I17 asks for a TODO on a field that actually carries
# the rule's answer, a decision, or a gap.
# The rest of CANON — identity/citation (`spec_refs`, `spec_digest`), the source-mapping axis
# (`source`), cross-references (`depends_on`), physical naming (`output`), the status axes (`status`),
# the pointer lists (`decision_ids`, `gap_ids`), the publish flag (`publish`), the worked example
# (`acceptance`) and prose (`notes`). A TODO here is real work left to do, but it is not the
# REQUIREMENT being left open. Derived, so a field added to CANON lands here by default and the
# partition test below fails until it is placed on purpose — an unclassified field must not silently
# become a valid I17 escape or silently stop being one.
NON_REQUIREMENT_FIELDS = frozenset(CANON) - REQUIREMENT_FIELDS

ID_RE = re.compile(r"^[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)*$")      # STUDY-WINDOW, MAXINDEX, OS-ID3MOSFU
GAP_RE = re.compile(r"^(?:B[0-9]+|G-[A-Z0-9-]+)$")          # B1, B2, B3, G-ECOG, G-RWPFS
SPEC_REF_RE = re.compile(r"^([0-9A-Za-z._]+):(\d+)(?:-(\d+))?$")   # demographics:9 | clinical:17-46
TODO_RE = re.compile(r"\bTODO\b")


def spec_ref_rows(ref):
    """`clinical:17-46` -> [("clinical", 17), ..., ("clinical", 46)]. `()` when it is not a citation.

    THE one expansion of a spec_ref. `SPEC_REF_RE` was shared, but the loop that turns a matched range
    into rows was written out FIVE times — twice in `contract_binding`, once in
    `contract_scaffold.contract_citations` (which carried its own copy of the regex too), once in
    `spec_digest`, once in the I8 lint — and `spec_slice` matched citations with `split(":")`, which
    sees `clinical:17-46` as neither row 17 nor row 46 and silently matches nothing.

    That is the exact shape this repo keeps paying for: six readings of one concept, agreeing on
    `clinical:17` and disagreeing on a range, on either side of "is this row already covered". The
    slicer's version made a record citing a range invisible to `current_records`, so an audit was told
    a row had no record and a drafter could write a second one for a row already mapped.

    `[none]` is not a citation and is not this function's business — callers test `NO_SPEC_ROW` first.
    """
    m = SPEC_REF_RE.match((ref or "").strip())
    if not m:
        return ()
    lo, hi = int(m.group(2)), int(m.group(3) or m.group(2))
    return tuple((m.group(1), n) for n in range(lo, hi + 1))


def spec_ref_ids(refs):
    """Every `<domain>:<row>` id a record's spec_refs covers, ranges expanded, as a set."""
    return {f"{d}:{n}" for ref in refs or [] if ref != NO_SPEC_ROW
            for d, n in spec_ref_rows(ref)}


def todo_fields(block):
    """Which keys in a record still hold TODO, including inside the required inline dicts."""
    out = []
    for line in block.splitlines():
        if not TODO_RE.search(line):
            continue
        key = line.split(":", 1)[0].strip()
        for inner in re.findall(r"([a-z_]+):\s*TODO", line):
            out.append(inner if inner != key else key)
        if not re.search(r"[a-z_]+:\s*TODO", line):
            out.append(key or "?")
    return sorted(set(out)) or ["a field"]


def _todo_toplevel(block):
    """The set of TOP-LEVEL record keys whose line carries a TODO — the fields left unwritten.

    Two differences from `todo_fields`, both required by I17. It reports the TOP-LEVEL key even for an
    inline dict — `output: {physical_name: TODO}` is `output`, not `physical_name` — because I17 asks
    which CANON field is left open, not which inner member. And it returns an EMPTY set on a record
    with no TODO, so it works as a predicate: `todo_fields` returns `['a field']` when there are none
    and is therefore always truthy, which is exactly why the I17 comment forbids using it here.
    """
    return {line.split(":", 1)[0].strip() for line in block.splitlines() if TODO_RE.search(line)}

# I12. Each rung requires the one below it. Every axis can be individually legal while the combination
# is impossible: `requirement: draft` with `validation: passed_live` says a rule nobody approved was
# validated against real data. The lint checked each axis alone, so that passed.
VALIDATION_RANK = {"not_run": 0, "failed": 0, "passed_test": 1, "passed_synthetic": 1, "passed_live": 2}
IMPL_BUILT = {"implemented", "partial"}          # anything else has not produced output to validate
# Implementations that fall SHORT of the requirement, and so must name what is missing.
IMPL_SHORTFALL = {"config_gap", "engine_gap", "partial", "not_derivable"}

# The one non-citation spec_refs value. An engine or config addition genuinely has no spec row; writing
# prose in spec_refs to say so put an unvalidatable string in the field meant for validatable ones.
NO_SPEC_ROW = "none"
# What a record with nothing to bind to carries, so the field is never blank and never a fake hash.
NA = "n/a"

# Parser-sanity floors. A silent parser regression looks identical to "the file got smaller", so each
# product states what it actually has. Used only when a pack declares none: a NEW product legitimately
# starts with almost nothing, and a floor it cannot meet is a floor people learn to ignore.
DEFAULT_FLOORS = {"decisions": 1, "gaps": 1, "records": 1}

FLOORS_RE = re.compile(r"^FLOORS\s*=\s*(\{[^}]*\})", re.M)


def pack_floors(product_dir):
    """The floors a pack DECLARES, or None when it declares none.

    The declaration lives in `handoff/tests/test_functional_contract.py`, which is where each pack
    already states what it actually has. Read from there rather than restated, because the CLI having
    its own answer made the floor two facts that disagreed — and it failed in both directions at once:

      * `contract_lint.py products/oncology/oc/202606` reported `parsed only 0 gap IDs (floor 1)` on a
        pack that declares `gaps: 0` and whose own test passes. ENGINE_GAPS.md says in its first line
        that it is empty because no contract is approved and no build binds to one. A pack that CANNOT
        meet a floor is the exact thing this comment warns produces a floor people learn to ignore.
      * the same CLI on prostate 202606 applied `records: 1` where the pack declares `40`, so a parser
        regression dropping 39 records would have passed. That is the dangerous half, and it was
        silent.

    Parsed as a literal, not imported: the wrapper manipulates sys.path and imports this module, and
    reading a number should not run a test file.
    """
    path = os.path.join(product_dir, "handoff", "tests", "test_functional_contract.py")
    if not os.path.exists(path):
        return None
    m = FLOORS_RE.search(read(path))
    if not m:
        return None
    try:
        declared = ast.literal_eval(m.group(1))
    except (ValueError, SyntaxError):
        return None
    return declared if isinstance(declared, dict) else None


def read(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def _read_if(path):
    return read(path) if os.path.exists(path) else ""


def table_first_cells(text, keep):
    """First-column cell of every markdown table row whose first cell matches `keep`."""
    out = []
    for line in text.splitlines():
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if cells and keep(cells[0]):
            out.append(cells[0])
    return out


def decision_ids(text):
    """Every decision id the register DEFINES — the set I2 checks a record's citations against.

    No length floor. It carried `len(c) >= 5` while `decision_rows` and `decision_register_errors`
    dropped theirs, so the three readers of "what is a decision id" disagreed below five characters —
    and the disagreement was not a silent one, it was two invariants contradicting each other on the
    same row: I2 reported `D-1` as an undefined decision while I11, reading the same table through
    `decision_rows`, saw it OPEN and demanded the record be `decision_required`. Latent only because
    today's packs spell ids long; the first tumour to number its decisions `D-1, D-2` hits it on day
    one. ID_RE already rejects separator rows and the header is excluded by name.
    """
    return set(table_first_cells(text, lambda c: ID_RE.match(c) and c != "ID"))


def _register_rows(text, id_column="ID"):
    """(pipe rows, the `| <id_column> | … |` header row or None) — what a register table LOOKS like.

    One definition. product_gates grew a second, `(?m)^`-anchored copy to tell an empty QC register
    from a headerless one, and two answers to "is this a register?" is how one gate decides a file
    has a table while another decides it does not.

    `id_column` because `ENGINE_GAPS.md` heads its key column `Gap ID`, not `ID`. Hardcoding `ID`
    meant this reader found no header there and `decision_rows` returned nothing — so the gap index
    grew its own `split("|")`, a FOURTH parser for the one register shape. One argument is cheaper
    than a parser, and cheaper again than the divergence between them.
    """
    rows = [l for l in text.splitlines() if l.startswith("|")]
    return rows, next((r for r in rows if re.search(id_column_re(id_column), r)), None)


def has_register(text):
    """True when `text` carries a register table with the canonical `| ID | … |` header.

    Distinct from "the register is empty": a header with no rows beneath it is a STATEMENT that
    someone looked and found nothing, which is exactly what an absent header cannot say.
    """
    return _register_rows(text)[1] is not None


def id_column_re(id_column="ID"):
    """The header pattern for a register keyed by `id_column`. One place, so the reader and anything
    checking a header cannot disagree about what counts as one."""
    return r"\|\s*" + re.escape(id_column) + r"\s*\|"


def decision_rows(text, id_column="ID"):
    """{decision id: {column: cell}} from DECISIONS.md, keyed by the table's OWN header names.

    Columns are located by NAME, not by position — the products already spell their middle columns
    differently ("Conflict / evidence" vs "Evidence"), and counting columns would silently read the
    wrong one. This is the single reader for that table: `decision_status` below, the scaffold's
    open-decision check and the question report all derive from it, so a change to how the table is
    read cannot leave one of them behind.
    """
    rows, hdr = _register_rows(text, id_column)
    if not hdr:
        return {}
    cols = [c.strip() for c in hdr.strip().strip("|").split("|")]
    out = {}
    for r in rows:
        c = [x.strip() for x in r.strip().strip("|").split("|")]
        # No length floor: `D-1` is a legal id under ID_RE, and a 5-char minimum silently
        # dropped it from the register. Separators fail ID_RE; the header is excluded by name.
        if c[0] != id_column and ID_RE.match(c[0]):
            out[c[0]] = dict(zip(cols, c))
    return out


def cell(row, *names, default=""):
    """A register cell looked up by column name, case- and spacing-insensitively.

    `decision_rows` keys by the table's OWN header text, so every caller doing `row.get("Status")`
    was matching exactly — and a product spelling it `status` or `Status ` would have read as a
    blank cell, which the gates treat as an unanswered question. The columns are prose written by
    hand in markdown; the lookup has to tolerate that, and it must tolerate it the same way
    everywhere. Several `names` are tried in order, for a column with more than one accepted
    spelling. `default=None` distinguishes an ABSENT column from a blank cell — a distinction the
    gates need, because one means "this register cannot answer" and the other means "nobody did".
    """
    norm = {re.sub(r"\s+", " ", str(k or "")).strip().lower(): v for k, v in row.items()}
    for n in names:
        v = norm.get(re.sub(r"\s+", " ", n).strip().lower())
        if v is not None:
            return v
    return default


# The statuses a register may use. Anything else is a typo, and a typo currently reads as "not open"
# — which is the fail-open direction: `OPNE` or a blank cell silently stops blocking.
DECISION_STATUSES = {"OPEN", "RESOLVED", "WITHDRAWN", "SUPERSEDED"}

# THE ACCEPTED SPELLINGS OF EACH REGISTER COLUMN, most-canonical first.
#
# The registers are hand-written markdown and the products already disagree: the answer column is
# `Approved answer` in prostate/202606 and `Resolution` in prostate/202607 and oc/202606; the
# evidence column is `Conflict / evidence` in one and `Evidence` in the others. `decision_rows` keys
# by the table's OWN header text, which is what lets a register be read at all — but every caller
# then has to know the synonyms, and the one that did knew only two of the three.
#
# The cost was silent and exact: the cross-product question harvester read `("Approved answer",
# "Answer")`, so
# oc/202606's RESOLVED `OC-PSOC-SHEET` — which carries a real answer under `Resolution` — came back
# as the empty string. A question was answered and the learning store recorded nothing, with no
# error. One of only three resolved decisions in the repository, lost to a spelling.
#
# So the vocabulary lives HERE, beside the reader that owns the tables, and every caller imports it.
# A caller keeping its own list is a caller that will know a subset — which is not a different bug
# from the one above, it is the same one waiting for the next product to spell it a fourth way.
ANSWER_COLUMNS = ("Approved answer", "Resolution", "Answer", "Decision")
EVIDENCE_COLUMNS = ("Conflict / evidence", "Evidence", "Conflict", "Basis")
QUESTION_COLUMNS = ("Question", "Issue", "Ask")
OWNER_COLUMNS = ("Owner", "Owned by", "Accountable")
# WHO answered, and WHEN. `Owner` is not either of those — it names who the question is ADDRESSED to
# while it is open, and it stays the same whether or not anybody has replied. Every other approval in
# this framework binds to a person and a date; a resolved decision was the one that did not, so the
# register could carry a settled scientific answer with nothing recording who settled it.
APPROVER_COLUMNS = ("Approved by", "Answered by", "Decided by", "Resolved by")
APPROVAL_DATE_COLUMNS = ("Approval date", "Answered date", "Decision date", "Resolved date")


def decision_answer(row, default=""):
    """The recorded answer, whichever accepted spelling this register uses."""
    return cell(row, *ANSWER_COLUMNS, default=default)


def decision_evidence(row, default=""):
    """The evidence/conflict text, whichever accepted spelling this register uses."""
    return cell(row, *EVIDENCE_COLUMNS, default=default)


def decision_question(row, default=""):
    return cell(row, *QUESTION_COLUMNS, default=default)


def decision_owner(row, default=""):
    return cell(row, *OWNER_COLUMNS, default=default)


def decision_approver(row, default=""):
    return cell(row, *APPROVER_COLUMNS, default=default)


def decision_approval_date(row, default=""):
    return cell(row, *APPROVAL_DATE_COLUMNS, default=default)


def _status_text(raw):
    """A Status cell, normalised. Registers bold their statuses (`**open**` — SPEC_QC_FINDINGS
    already does), and `**OPEN**` != `OPEN` meant a bolded register read as having nothing open."""
    return re.sub(r"[*`_~]", "", str(raw or "")).strip().upper()


def decision_status(text):
    """{decision id: STATUS}. Empty when the table carries no Status column."""
    return {d: _status_text(cell(row, "Status")) for d, row in decision_rows(text).items()
            if cell(row, "Status", default=None) is not None}


def register_errors(text, rel, label, required_columns, allowed_statuses):
    """Defects in a REGISTER itself, not in what it says — for any `| ID | … |` table.

    Every one of these reads as "nothing open" when unchecked, which is the fail-open direction: a
    blank cell, a misspelling, or a second row for the same id silently stops a finding or a decision
    from blocking a gate. The register is what Gate 2 and Gate 4 consult, so it has to be well-formed
    before its contents mean anything.

    Parameterised because DECISIONS.md and SPEC_QC_FINDINGS.md are the same shape with different
    vocabularies, and only the decision register was being checked. The QC register — the one whose
    header-only form is read as "QC was performed and found nothing" — could carry the wrong columns
    entirely, or two rows for one id where the last silently wins, and pass.
    """
    rows, hdr = _register_rows(text)
    if hdr is None:
        return []                                   # no register at all is a different check's job
    cols = [c.strip().lower() for c in hdr.strip().strip("|").split("|")]
    errors = []
    for want in required_columns:
        if want.strip().lower() not in cols:
            errors.append(f"{rel}: {label} has no {want} column, so its rows cannot be read as "
                          f"accounted or open. Keep the canonical header from "
                          f"TUMOR_TEMPLATE/handoff/{'SPEC_QC_FINDINGS.md' if 'QC' in label else 'DECISIONS.md'}.")
    if errors:
        return errors                               # the columns decide what every row below means

    seen = {}
    for r in rows:
        c = [x.strip() for x in r.strip().strip("|").split("|")]
        if not c or c[0] == "ID" or not ID_RE.match(c[0]):
            continue
        seen.setdefault(c[0], []).append(r)
    for rid, occurrences in sorted(seen.items()):
        if len(occurrences) > 1:
            errors.append(f"{rel}: {label} '{rid}' appears {len(occurrences)} times — the reader keys "
                          f"by id, so the LAST row silently wins and the others vanish (an `open` row "
                          f"followed by a resolved one simply disappears)")
    for rid, row in sorted(decision_rows(text).items()):
        raw = cell(row, "Status", default=None)
        # ABSENT column vs BLANK cell. A register may carry a SECOND table with narrower columns (the
        # QC one does — delivery-format losses), and the reader zips every row against the FIRST
        # header, so those rows arrive with no Status KEY at all. Both block, but "add a Status
        # column" and "fill in this row's Status" send an author to different places.
        if raw is None:
            errors.append(f"{rel}: {label} row '{rid}' sits under a table with no Status column, so "
                          f"whether it is accounted for cannot be read. Add rows to the canonical "
                          f"table rather than a second one with its own columns.")
            continue
        st = _status_text(raw)
        if not st:
            errors.append(f"{rel}: {label} '{rid}' has a blank Status — an unanswered status is not "
                          f"a resolved one")
        elif st not in allowed_statuses:
            errors.append(f"{rel}: {label} '{rid}' Status '{st}' is not one of "
                          f"{sorted(allowed_statuses)} — an unrecognised status reads as 'not open' "
                          f"and silently stops blocking")
    return errors


def decision_register_errors(text, rel):
    return register_errors(text, rel, "decision register", ("Status",), DECISION_STATUSES)


def open_decisions(product_dir):
    """Ids of a pack's OPEN decisions, sorted; [] when it declares none.

    Lives here because this module owns the decision register (`decision_rows` / `decision_status`).
    It had two identical definitions — one in contract_scaffold for checking a `decision_required`
    disposition, one in product_gates for blocking `contract: approved` — and while both delegated to
    decision_status after the last round's fix, two functions of the same name and purpose is how the
    next divergence starts. Callers that want membership tests work on a list unchanged.
    """
    path = os.path.join(product_dir, "handoff", "DECISIONS.md")
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as fh:
        return sorted(d for d, st in decision_status(fh.read()).items() if st == "OPEN")


def blocking_decisions(decision_ids_cited, dec_open):
    """The cited decisions that make a record `decision_required` — I11's left-hand side, once.

    Two things need this answer and they must not be able to differ. The LINT asks it to check a
    record's status (I11); the DRAFTING TOOL asks it to SETTLE that status, because a drafter who
    supplied `decision_required` is refused and a drafter who supplied nothing got `draft` — so a new
    record citing an open decision could not be produced at all. No valid input satisfied both ends.

    Closing that by teaching `contract_record` the rule separately would put the same sentence in two
    files, and the failure mode is not that they disagree loudly — it is that the drafting tool
    settles a status the lint then rejects, which reads to a drafter as the tool being broken.

    `OUTPUT_DECISIONS` are excluded because they are about naming and codelists at the output layer,
    not about what the requirement IS: a record does not stop being answerable because its column
    header is unsettled.

    `dec_open` is `decision_status(...)` — {id: STATUS}. An id it does not know is treated as OPEN:
    a decision the register never defined is not evidence that nothing is blocked.
    """
    return [d for d in decision_ids_cited
            if dec_open.get(d, "OPEN") == "OPEN" and d not in OUTPUT_DECISIONS]


def gap_ids(text):
    return set(table_first_cells(text, lambda c: GAP_RE.match(c)))


def dashboard_vars(path):
    """Lower-case physical variable codes listed in the shared dashboard layout's `variables: [...]`."""
    if not os.path.exists(path):
        return None
    names = set()
    for m in re.finditer(r"variables:\s*\[([^\]]*)\]", read(path)):
        for tok in m.group(1).split(","):
            tok = tok.strip()
            if tok:
                names.add(tok.lower())
    return names


def spec_rows(product_dir):
    """{domain: {row number: content hash}} from the spec pipeline's extraction.

    Read from `spec_pipeline/out/extracted.json` rather than from the spec files directly, because that
    is the one place both readers agree: the approved .xlsx and the registered markdown produce the
    same item ids. Resolving I8 against the extraction also means the lint needs no per-product map of
    domain -> filename, which is the last thing that made this lint product-specific.

    The row's CONTENT hash comes along because row numbers alone cannot answer the question that
    matters: whether the text a record was written from still says the same thing (I15).
    """
    path = os.path.join(product_dir, "spec_pipeline", "out", "extracted.json")
    if not os.path.exists(path):
        return None
    out = {}
    with open(path, encoding="utf-8") as fh:
        data = json.load(fh)
    for row in data.get("rows", []):
        if row.get("domain"):
            out.setdefault(row["domain"], {})[row["row"]] = row.get("content_hash", "")
    return out


# Lint findings that mean THE SPECIFICATION DOES NOT CONTAIN THE ANSWER — as opposed to defects in how
# it is written, which a careful reader may still resolve. Only these are load-bearing for I17: making
# every finding fatal would put 230 of ovarian's 299 rows permanently out of reach, and a rule a pack
# cannot satisfy is one people learn to route around.
UNSETTLED = {
    "VERIFY_MARKER",     # RWB themselves marked the rule unconfirmed
    "PLACEHOLDER",       # prose sitting where a rule should be
    "TRUNCATED",         # the definition is cut off — the text is not all there
    "NO_TERMINAL_ELSE",  # conditions with no fallback: what the default is was never stated
}


def unsettled_rows(product_dir):
    """{item_id: sorted kinds} for spec rows the deterministic lint judged unsettled, or None.

    The machine already knows which rows a record MUST NOT answer confidently — `spec_lint` computes
    these with no model involved, and they land in `spec_pipeline/out/lint.json`. Reading them here is
    what lets I17 catch an invented value, which no other invariant can: a fabricated `age >= 18` is
    well-formed, complete, correctly typed and properly cited. Every structural check passes. It is
    simply not what the specification says.

    That gap matters most exactly where human review is thinnest — a weaker or cheaper model drafting
    hundreds of records unattended. Judgment the model may not have becomes a property the lint checks.
    """
    path = os.path.join(product_dir, "spec_pipeline", "out", "lint.json")
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as fh:
        payload = json.load(fh)
    # spec_lint emits {findings, applicability}; a bare list is the older shape.
    findings = payload["findings"] if isinstance(payload, dict) else payload
    out = {}
    for f in findings:
        if f.get("kind") in UNSETTLED and f.get("item_id"):
            out.setdefault(f["item_id"], set()).add(f["kind"])
    return {k: sorted(v) for k, v in out.items()}


def spec_definitions(product_dir):
    """{(domain, row): the row's Definition cell} from the extraction — I22's comparison basis.

    A sibling of `spec_rows` over the same file rather than a second key inside it, because
    `spec_rows`' {domain: {row: hash}} shape is what `spec_digest` hashes and every caller of that
    contract would have to unlearn a wider one."""
    path = os.path.join(product_dir, "spec_pipeline", "out", "extracted.json")
    if not os.path.exists(path):
        return {}
    with open(path, encoding="utf-8") as fh:
        data = json.load(fh)
    return {(r["domain"], r["row"]): (r.get("fields") or {}).get("definition", "")
            for r in data.get("rows", []) if r.get("domain")}


def spec_variables(product_dir):
    """{(domain, row): the row's variable name} from the extraction — the cross-revision matcher's
    second axis. spec_extract's own docstring states the recipe this feeds: matching items across
    revisions needs domain + variable name + content hash + coordinates TOGETHER, with ambiguous
    matches reviewed by a person — a hash survives movement but not an in-cell edit, and a name
    legitimately recurs, so neither alone is an identity."""
    path = os.path.join(product_dir, "spec_pipeline", "out", "extracted.json")
    if not os.path.exists(path):
        return {}
    with open(path, encoding="utf-8") as fh:
        data = json.load(fh)
    return {(r["domain"], r["row"]): (r.get("variable") or "").strip()
            for r in data.get("rows", []) if r.get("domain")}


def _fold_cell(s):
    """The documented cell folding, and nothing more: an enclosing quote pair is YAML dress, `\\|`
    is how a pipe is written inside a table cell, and whitespace runs collapse because a table cell
    cannot hold a real newline. `<br>` is the specification's own line break and is KEPT — both
    sides carry it, so it must match."""
    s = s.strip()
    if len(s) >= 2 and s[0] == '"' and s[-1] == '"':
        s = s[1:-1]
    return re.sub(r"\s+", " ", s.replace("\\|", "|").strip())


def spec_digest(refs, srows):
    """The digest of everything a record cites, or None when it cannot be computed.

    Over `item_id + content_hash` for every cited row in citation order, so it moves when RWB edits a
    rule IN PLACE — the case row numbers cannot see. `spec_refs: [none]` records cite nothing and carry
    `n/a`.
    """
    if refs == [NO_SPEC_ROW]:
        return NA
    parts = []
    for ref in refs:
        rows = spec_ref_rows(ref)
        if not rows:
            return None
        for domain, n in rows:
            if domain not in (srows or {}) or n not in srows[domain]:
                return None
            parts.append(f"{domain}:{n}={srows[domain][n]}")
    if not parts:
        return None
    return hashlib.sha256("\x1f".join(parts).encode("utf-8")).hexdigest()[:12]


# The contract's storage format is a markdown TABLE — one row per specification row, so it reads
# line for line against the Excel tab it was written from and a reviewer can edit it in place. A cell
# cannot hold a literal `|` (that would end the cell) so writers escape it; `_unpipe` is the one place
# that is undone. `<br>` is left ALONE: the specification's own stand-in uses it for a line break
# inside a cell, and `required_rule` carries the spec's Definition verbatim.
PIPE = "\\|"


def _unpipe(cell_text):
    return cell_text.replace(PIPE, "|").strip()


# The columns of the canonical record table, in order. Derived from CANON so the table cannot come to
# disagree with the field set every invariant checks — contract_scaffold kept its own copy of this
# list, identical today, which is the shape of defect this repo keeps paying for.
# `implementation_refs` trails CANON for POSITION, not for optionality — I19 requires it on every
# record. Kept last because that is
# where every governed table already has it and moving a column rewrites every pack. (a not-implemented
# record carries `[none]`) while contract_binding does the moment a record claims to produce output.
TABLE_COLUMNS = ("variable_id",) + CANON + ("implementation_refs",)


def pipe(value):
    """Render a value INTO a markdown table cell — the writer counterpart to `_unpipe`.

    Lives beside its inverse on purpose. An escape rule split across two modules is one that drifts:
    a writer that stopped escaping `|`, or started escaping it differently, would produce rows this
    file's own splitter reads as extra columns — silently shifting every field after the offending
    one into the wrong key, which no invariant could detect because each cell is individually valid.

    A cell is one line by construction, so an embedded newline is folded to a space rather than
    breaking the row into two.
    """
    return re.sub(r"\s*\n\s*", " ", str(value)).replace("|", PIPE).strip()


def inline(value):
    """A field VALUE in the contract's own inline notation. Lists as `[a, b]`, maps as `{k: v}`.

    The counterpart to `_inline` / `_list`, beside them for the same reason `pipe` sits beside
    `_unpipe`: a writer and reader of one notation that live apart are two notations waiting to
    disagree. Scalars pass through untouched — a record's text is the author's, not this function's.
    """
    if isinstance(value, dict):
        return "{" + ", ".join(f"{k}: {inline(v)}" for k, v in value.items()) + "}"
    if isinstance(value, (list, tuple)):
        return "[" + ", ".join(inline(v) for v in value) + "]"
    if value is None:
        return ""
    if isinstance(value, bool):
        # YAML parses `nullable: true` to a Python bool, and `str(True)` is "True" — which is not what
        # the contract writes, so the rendered row would differ from what the author typed and the
        # round-trip check would (correctly) refuse it. The contract's notation is lower-case.
        return "true" if value else "false"
    return str(value)


def render_row(record):
    """One record mapping -> the canonical markdown table row. THE writer.

    Field ORDER, pipe ESCAPING, newline FOLDING and cell COUNT are mechanical, and getting them
    wrong is invisible: a single unescaped `|` shifts every later field into the wrong key. So no
    drafter writes a row by hand — `contract_record.py` renders it through here.

    Unknown keys are an ERROR rather than dropped: a field the table has no column for is either a
    typo or a schema change, and silently discarding it loses the answer it carried.
    """
    unknown = [k for k in record if k not in TABLE_COLUMNS]
    if unknown:
        raise ValueError(f"not contract fields: {', '.join(sorted(unknown))} — "
                         f"the canonical columns are {', '.join(TABLE_COLUMNS)}")
    return "| " + " | ".join(pipe(inline(record.get(k, ""))) for k in TABLE_COLUMNS) + " |"


def render_table(records):
    """A complete record table — header, separator, rows — from mappings."""
    head = "| " + " | ".join(TABLE_COLUMNS) + " |"
    sep = "|" + "|".join(["---"] * len(TABLE_COLUMNS)) + "|"
    return "\n".join([head, sep] + [render_row(r) for r in records]) + "\n"


def _table_blocks(text):
    """Yield one normalized `key: value` block per row of the canonical record table.

    Returning BLOCK TEXT rather than a dict is what kept this change to one function: every invariant
    below, and every other tool that reads a contract, already speaks that shape through
    `_scalar` / `_inline` / `_list`. A dict would have meant rewriting all of them, and two record
    readers is the failure this repo keeps paying for.
    """
    header, idx = None, {}
    for line in text.splitlines():
        if not line.lstrip().startswith("|"):
            header = None                       # a blank line or prose ends the table
            continue
        cells = [c for c in re.split(r"(?<!\\)\|", line.strip())[1:-1]]
        names = [_unpipe(c).lower() for c in cells]
        if header is None:
            # A table is THE record table only if it names variable_id — the packs carry other tables
            # (decision registers, artifact keys) and a positional guess would read those as records.
            if "variable_id" not in names:
                continue
            header, idx = names, {n: i for i, n in enumerate(names)}
            continue
        if all(set(_unpipe(c)) <= set("-: ") for c in cells):
            continue                            # the |---|---| separator row
        vid = _unpipe(cells[idx["variable_id"]]) if idx["variable_id"] < len(cells) else ""
        if not vid:
            continue
        yield "\n".join(f"{name}: {_unpipe(cells[i])}"
                        for name, i in idx.items() if i < len(cells) and _unpipe(cells[i]))


def table_shape_errors(text):
    """Why the record table's SHAPE is wrong, or [] when it is right.

    `_table_blocks` maps cells to names positionally against the header and guards `i < len(cells)`,
    so both mistakes are silent: a row with too FEW cells loses its trailing fields — they read as
    absent, which for `notes` or `implementation_refs` is indistinguishable from "nothing to say" —
    and a row with too MANY has the extras dropped, because no header name points at them.

    Neither is hypothetical for a hand-edited table: forgetting one `|`, or writing a literal `|`
    inside a cell without escaping it, produces exactly these. The guard is one comparison, and it is
    the difference between a mis-authored row failing and a mis-authored row being read wrong.

    The header must also BE `TABLE_COLUMNS`. A pack whose table stops at `notes` is a second contract
    schema — every reader has to know which one it is looking at, and the field that is absent is
    absent by accident rather than by a decision anyone recorded.
    """
    errors, header, lineno = [], None, 0
    for line in text.splitlines():
        lineno += 1
        if not line.lstrip().startswith("|"):
            header = None
            continue
        cells = [c for c in re.split(r"(?<!\\)\|", line.strip())[1:-1]]
        names = [_unpipe(c).lower() for c in cells]
        if header is None:
            if "variable_id" not in names:
                continue
            header = names
            if tuple(names) != TABLE_COLUMNS:
                missing = [c for c in TABLE_COLUMNS if c not in names]
                extra = [c for c in names if c not in TABLE_COLUMNS]
                errors.append(
                    f"line {lineno}: the record table header is not the canonical one"
                    + (f" — missing {', '.join(missing)}" if missing else "")
                    + (f" — unknown column(s) {', '.join(extra)}" if extra else "")
                    + (" — same columns, different order" if not missing and not extra else "")
                    + ". One table shape, or every reader has to know which pack it is reading.")
            continue
        if all(set(_unpipe(c)) <= set("-: ") for c in cells):
            continue
        if len(cells) != len(header):
            vid = _unpipe(cells[0]) if cells else "?"
            what = ("trailing fields would read as absent" if len(cells) < len(header)
                    else "the extra cell(s) would be dropped, naming no column")
            errors.append(
                f"line {lineno}: record '{vid}' has {len(cells)} cells against a {len(header)}-column "
                f"header — {what}. A literal `|` inside a cell must be written `\\|`.")
    return errors


def records(text):
    """Yield each contract record as `key: value` block text, whatever the file stores it as.

    THE one reader. Both storage formats resolve here so that no caller has to know which it is
    looking at: the markdown record table (current), and the fenced ```yaml block (what the contract
    used before the table, still emitted by nothing but still readable, so an older pack or a pasted
    draft is never silently seen as an empty contract).
    """
    seen_any = False
    for block in _table_blocks(text):
        seen_any = True
        yield block
    if seen_any:
        return
    yield from _fenced_blocks(text)


def _fenced_blocks(text):
    for block in re.findall(r"```yaml\n(.*?)```", text, re.DOTALL):
        if re.search(r"(?m)^variable_id:\s*\S", block):
            yield block


def mixed_format_error(text, rel):
    """The table WINS in `records()`, so a fenced record in a table contract is invisible.

    That is the one way this file can lose a requirement without anything going red: someone pastes a
    fenced record — a hand-written draft, or one carried over from a pack still stored that way —
    under the table, every check keeps passing, and the variable is simply not in the contract.
    (The scaffold itself emits table rows now, which is what removed the commonest source of this.)
    Silence is the danger, so say it.
    """
    fenced = [re.search(r"(?m)^variable_id:\s*(\S+)", b).group(1) for b in _fenced_blocks(text)]
    if fenced and any(True for _ in _table_blocks(text)):
        return [f"{rel} stores records BOTH as a table and as fenced yaml block(s) "
                f"({', '.join(fenced[:5])}{'…' if len(fenced) > 5 else ''}). The table wins, so those "
                f"block(s) are in the file and NOT in the contract. Move them into the table."]
    return []


def _inline(block, key):
    """The inline-dict body for `key: {...}` on one line (greedy to the last brace on that line)."""
    m = re.search(r"(?m)^" + re.escape(key) + r":\s*\{(.*)\}\s*$", block)
    return m.group(1) if m else None


def _scalar(block, key):
    """A plain `key: value` line, or None when the key is absent."""
    m = re.search(r"(?m)^" + re.escape(key) + r":\s*(\S.*?)\s*$", block)
    return m.group(1) if m else None


def _list(block, key):
    m = re.search(r"(?m)^" + re.escape(key) + r":\s*\[([^\]]*)\]", block)
    if not m:
        return None
    return [t.strip() for t in m.group(1).split(",") if t.strip()]


# WHAT MAKES A RECORD PART OF THE PUBLISHED ADS. Both halves, because they answer different
# questions: `output.role` is what KIND of column it is, `publish.ads` is whether the ADS is
# configured to carry it. A record can be `role: published` with `publish.ads: undecided` — a column
# somebody intends to publish and has not yet agreed to emit — and shipping that as though it were
# settled is the direction this whole surface exists to stop.
PUBLISHED_ROLE = "published"
PUBLISHED_ADS = "configured"


def published_surface(text):
    """The ADS the CONTRACT says this product publishes: [{physical_name, published_name, type,
    nullable, variable_id}], in the contract's own record order.

    THE LIST ALREADY EXISTS — nothing consumes it. Every record carries `output: {physical_name,
    target_published_name, type, nullable, role}` and `publish: {ads: …}`, so "which columns does the
    approved product contain, in what order" is a fact the contract states 202 times. Meanwhile
    `assemble.build` returns `ads.distinct()` with no column selection at all, so what the ADS
    actually contains is whatever the stages happened to leave on the frame — helper columns
    (`treat_flag`, `f_death`, `dth_before_fued`) included. G-ADS-WHITELIST is that gap, and the fix
    it names is exactly this list plus a schema assertion.

    ORDER IS THE CONTRACT'S ORDER. Records are written in specification order, so it is the one
    ordering with a provenance; sorting alphabetically here would invent a different published
    layout every time a variable is renamed.

    A record missing `physical_name` is SKIPPED and reported by the caller rather than silently
    dropped — a published column with no name is a defect in the record, not a column that does not
    exist.
    """
    out = []
    for block in records(text):
        o, p = _inline(block, "output"), _inline(block, "publish")
        if _kv(o, "role") != PUBLISHED_ROLE or _kv(p, "ads") != PUBLISHED_ADS:
            continue
        out.append({"variable_id": (_scalar(block, "variable_id") or "").strip(),
                    "physical_name": (_kv(o, "physical_name") or "").strip().lower(),
                    "published_name": (_kv(o, "target_published_name") or "").strip(),
                    "type": _kv(o, "type"),
                    "nullable": _kv(o, "nullable")})
    return out


def _kv(body, key):
    """One field out of an inline `{a: x, b: y}` body — the value up to the next comma or brace.

    IT USED TO STOP AT THE FIRST NON-LETTER. `([A-Za-z_]+)` read `physical_name: lot1sd_mhspc` as
    `lot`, and `codes: n/a` as `n`. Every caller so far happens to read a controlled vocabulary WORD
    — role, name_status, requirement, implementation, validation, the publish surfaces — so the
    truncation never bit; it was waiting for the first caller to read a NAME, which is exactly what
    the published-surface derivation does. Widening only to digits would have fixed the name and left
    `n/a` broken, which is the fix that looks complete and is not.

    Anchored with a word boundary so `name:` cannot be matched inside `physical_name:` — without it,
    asking for `name` returns the physical name, and the two are different fields.
    """
    if body is None:
        return None
    m = re.search(r"(?:^|[,{]|\s)" + re.escape(key) + r":\s*([^,}]+)", body)
    return m.group(1).strip() if m else None


def _has(block, key):
    m = re.search(r"(?m)^" + re.escape(key) + r":\s*(.+?)\s*$", block)
    return bool(m and m.group(1).strip() and m.group(1).strip() != ">")


# A `physical_stem` that names no vendor table: a constant, a build parameter, an engine-derived
# value. Defined here because two tools need the same answer to "is this record vendor-sourced?" —
# `source_check.py` imports it rather than keeping a second copy that can drift.
NOT_VENDOR = re.compile(r"^\(|^n/a$", re.I)


def _source_field(block, key):
    """A TOP-LEVEL `source.<key>` value, verbatim.

    Top-level matters: searching the whole inline body would make a record whose `columns:` map
    contains a key named `kind` — `columns: {kind: derived}` — read as `source.kind: derived`, which
    would take it out of Gate 3 and Gate 4 entirely. Hence the depth tracking below;
    `_kv` is no use here either, since it stops at the first non-word character and turns `n/a` into
    `n`, which then reads as a vendor table.
    """
    body, depth, start = _inline(block, "source") or "", 0, 0
    for i, ch in enumerate(body + ","):
        if ch in "{[":
            depth += 1
        elif ch in "}]":
            depth -= 1
        elif ch == "," and depth == 0:
            item = body[start:i].strip()
            start = i + 1
            k, _, v = item.partition(":")
            if k.strip() == key:
                return v.strip().strip('"\'')
    return ""


def physical_stem(block):
    return _source_field(block, "physical_stem")


def spec_identifiers(block):
    """The identifiers a `pending_mapping` record copies VERBATIM from the specification.

    `_source_field` returns the top-level value as text; for a list that text is `[a, b]`. Split here
    rather than in the invariant so the one reader of this field is beside the one reader of every
    other `source.<key>`.
    """
    raw = _source_field(block, "spec_identifiers").strip()
    if raw.startswith("[") and raw.endswith("]"):
        raw = raw[1:-1]
    return [t.strip().strip('"\'') for t in raw.split(",") if t.strip()]


# What a record's source IS, as five mutually exclusive kinds. The structured shape states it
# outright; the legacy shape encoded it as a sentinel in `logical_table`, which is why reading the
# stem with `_kv` once turned `n/a` into a table called `n`.
# `pending_mapping` is the SIXTH: a record whose scientific requirement is fully stated but whose
# LOGICAL SOURCE ALIAS cannot exist yet, because the pack has no `config/` to declare one. Every new
# tumour starts there, and until this existed the skill could only say what NOT to write — invent no
# alias — while offering no value the parser accepts. Drafters filled the gap with `TODO`, a physical
# table name, or an invented alias, and the last of those is indistinguishable from a real mapping.
#
# STRUCTURED, not a scalar `TODO`. A bare sentinel would be a second non-structured source form beside
# the inline mapping every other kind uses, and two shapes for one field is how a reader comes to
# accept one and refuse the other.
#
# It keeps the two axes apart. A requirement RWB has fully specified does not become
# `decision_required` merely because RWP has not yet chosen its alias — that is a configuration task,
# not an open scientific question, and conflating them buries the rows that genuinely need RWB.
PENDING_MAPPING = "pending_mapping"
SOURCE_KINDS = {"vendor", "derived", "parameter", "constant", "unavailable", PENDING_MAPPING}
LEGACY_KIND = {"(derived)": "derived", "(constant)": "constant",
               "(build_parameter)": "parameter", "(parameter)": "parameter",
               "(unavailable)": "unavailable"}


def source_kind(block):
    """`vendor` · `derived` · `parameter` · `constant` · `unavailable` · `invalid`, from either shape.

    An explicit `kind:` that is not one of the five is `invalid`, NOT a fallthrough. Falling through
    to the legacy sentinels meant `kind: vndor` found no `logical_table`, defaulted to `constant`,
    and the record silently left both Gate 3 and Gate 4 — a typo in the single most important field
    turned a vendor mapping into one nobody had to evidence.

    This is the shallow question — WHICH kind — and it is all the gates need, so it stays stdlib.
    The deep parse of a vendor record's per-source inputs needs real YAML and lives in
    `source_check.py`; that is two depths of one question, not two answers to it.
    """
    declared = _source_field(block, "kind")
    if declared:
        return declared if declared in SOURCE_KINDS else "invalid"
    logical = _source_field(block, "logical_table")
    stem = physical_stem(block)
    for value in (logical, stem):
        if value.lower() in LEGACY_KIND:
            return LEGACY_KIND[value.lower()]
    # Legacy records used several sentinel spellings; anything else naming a source is vendor.
    for value in (stem, logical):
        if value and not NOT_VENDOR.match(value):
            return "vendor"
    return "constant"


def vendor_sourced(block):
    """Does this record read a vendor table at all? `invalid` counts as vendor: a record whose kind
    cannot be read must be held to the STRICTER requirement, never excused by its own defect."""
    return source_kind(block) in ("vendor", "invalid")


def unverified_sources(text):
    """[(variable_id, why)] for each VENDOR-SOURCED record whose source is not yet Gate 3 evidence.

    Gate 4 (`configuration: approved`) must not close over a mapping nobody checked. That was
    enforced by counting the literal string `source: unverified` in the file, which is a text scan of
    a structured field: it reads a status inside a comment, it cannot see the four finer axes at all,
    and rewriting `unverified` as `dictionary_only` silences it while proving nothing. This reads the
    axes the lint already defines, which is also where the vocabulary is allowed to change.

    A record whose `physical_stem` is a sentinel — `(constant)`, `(build_parameter)`, `n/a` — names no
    vendor column, so vendor-source verification does not apply to it and it is not reported.
    """
    out = []
    for block in records(text):
        vid = _scalar(block, "variable_id") or "?"
        if source_kind(block) == PENDING_MAPPING:
            # A RECORD WITH NO SOURCE AT ALL, which is exactly what Gate 4 may not close over — and
            # `vendor_sourced` below skips it, because `pending_mapping` is not `vendor`. So the one
            # state whose source is most open was the one state this check could not see.
            #
            # It is reported HERE rather than as its own Gate 4 loop because this function IS the
            # question "which records are not ready for configuration approval on source grounds";
            # a second loop beside it would be a second answer, with its own truncation, its own
            # wording and its own eventual disagreement. `pending_mapping` is legal at Gate 2 (see
            # I18) precisely because this is where it comes due.
            out.append((vid, f"source.kind:{PENDING_MAPPING} — no source has been chosen yet, so "
                             f"there is no mapping for the configuration to express"))
            continue
        if not vendor_sourced(block):
            continue
        st = _inline(block, "status")
        coarse = _kv(st, "source")
        if coarse is not None:
            # `unavailable` is a declared gap — there is no mapping to have verified, and I10/I11
            # already require it to name the gap. Everything else on the COARSE axis is insufficient
            # here, including `verified`: WORKFLOW.md section 7 says the finer axes are adopted at
            # Gate 3, and Gate 4 is after Gate 3. Accepting a single `verified` at the point of
            # configuration approval would let one word stand for the four separate questions the
            # axes exist to separate — a column can be in the dictionary, absent from this delivery,
            # and still be the wrong column for the concept.
            if coarse != "unavailable":
                out.append((vid, f"status.source:{coarse} — Gate 4 needs the four finer axes"))
            elif not (_list(block, "gap_ids") or []):
                # `unavailable` is an exception because a declared gap has no mapping to verify. The
                # word alone declares nothing: without a gap id it is just an unevidenced record
                # wearing the one label that skips the evidence check.
                out.append((vid, "status.source:unavailable but gap_ids is empty — an exception "
                                 "from the evidence check has to name the gap it is an exception for"))
            continue
        fine = {k: _kv(st, k) for k in FINE_SOURCE_AXES}
        bad = []
        if fine["source_mapping"] != "human_confirmed":
            bad.append(f"source_mapping:{fine['source_mapping']}")
        if fine["live_schema_check"] != "passed":
            bad.append(f"live_schema_check:{fine['live_schema_check']}")
        # A missing dictionary must not block a mapping the DATA has already evidenced. It cannot
        # excuse one it has not, because the two checks that read the actual delivery are required
        # below regardless — the corroboration `not_available` needs is the SAME condition Gate 4
        # already imposes on every record, so stating it twice was a branch that could never fire.
        # `failed` still blocks: that is a verdict, not an absent document.
        if fine["dictionary_check"] not in ("passed", "not_available"):
            bad.append(f"dictionary_check:{fine['dictionary_check']}")
        # `reviewed` means a person read the report; `accepted` means they judged the evidence
        # sufficient for THIS mapping. Gate 4 approves an implementation, so it needs the judgment,
        # not merely the reading. (`not_available` above deliberately settles for `reviewed` too —
        # there it is one of two corroborating checks, not the approval itself.)
        if fine["data_profile_check"] != "accepted":
            bad.append(f"data_profile_check:{fine['data_profile_check']} (Gate 4 needs `accepted`)")
        if bad:
            out.append((vid, ", ".join(bad)))
    return out


def run(product_dir, floors=None):
    """Lint one product's contract. Returns (errors, record_count).

    `floors` explicit wins (the pack's own wrapper passes its FLOORS straight in). Otherwise the pack's
    DECLARED floors are read from that same wrapper, so the CLI and the test judge one pack by one
    standard. DEFAULT_FLOORS applies only to a pack that declares nothing at all.
    """
    floors = dict(DEFAULT_FLOORS, **(floors if floors is not None else (pack_floors(product_dir) or {})))
    handoff = os.path.join(product_dir, "handoff")
    contract = os.path.join(handoff, "FUNCTIONAL_CONTRACT.md")
    # The dashboard layout is SHARED (panel membership for all products), not product-local. Its schema
    # is `panels: [{variables: [lower_case_code, ...]}]` — lower-case physical codes, not `name:` entries.
    #
    # Found from the CHECKOUT, not by hopping three levels up from the pack. Three hops assumes the
    # pack sits at exactly products/<area>/<tumour>/<version>; nest it one level deeper and the hop
    # lands elsewhere, the shared file is "not found", and I5 reports that as a CONTRACT violation —
    # so a directory move became a record defect. `repo_root` walks up for a marker instead.
    _root = checkout_root(product_dir)
    dash_path = (os.path.join(_root, "products", "_reporting", "dashboard", "dashboard_vars.yaml")
                 if _root else os.path.normpath(
                     os.path.join(product_dir, "..", "..", "..", "_reporting",
                                  "dashboard", "dashboard_vars.yaml")))
    errors = []
    if not os.path.exists(contract):
        return [f"no FUNCTIONAL_CONTRACT.md at {contract}"], 0

    # A product may legitimately have a contract before it has raised its first decision or gap. Missing
    # files parse as empty, which leaves I2 to report any id the contract cites as undefined — the right
    # answer, and a clearer one than a traceback.
    dec_text = _read_if(os.path.join(handoff, "DECISIONS.md"))
    decs = decision_ids(dec_text)
    dec_open = decision_status(dec_text)
    gaps = gap_ids(_read_if(os.path.join(handoff, "ENGINE_GAPS.md")))
    dash = dashboard_vars(dash_path)
    srows = spec_rows(product_dir)
    if srows is None:
        errors.append("I8 no spec_pipeline/out/extracted.json — run platform/tools/run_spec_pipeline.sh "
                      "so spec_refs can be resolved against the captured spec")
        srows = {}
    sdefs = spec_definitions(product_dir)
    # I24's resolvable universe, gathered before the record loop: every record id (a cross-reference
    # may point forward), every variable name the extraction carries, and the engine's stage names.
    # The stages directory is looked up from this file so a deployed handoff (tools without engine)
    # skips the stage-name half rather than failing every engine: reference it cannot see.
    _all_vids = {(_scalar(b, "variable_id") or "").strip() for b in records(read(contract))}
    _svar_names = set((spec_variables(product_dir) or {}).values())
    _stages_dir = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                "..", "engine", "stages"))
    _engine_stages = ({f[:-3] for f in os.listdir(_stages_dir)
                       if f.endswith(".py") and f != "__init__.py"}
                      if os.path.isdir(_stages_dir) else None)
    _dep_edges = {}                       # record -> records it depends on, for I24's cycle check
    # Fail closed: lint.json ships from the same pipeline run as extracted.json, so one without the
    # other is a half-written out/. Skipping I17 silently there would turn the invention guard off
    # exactly when the evidence directory is already known to be untrustworthy.
    unsettled = unsettled_rows(product_dir)
    if unsettled is None:
        if os.path.exists(os.path.join(product_dir, "spec_pipeline", "out", "extracted.json")):
            errors.append("I17 no spec_pipeline/out/lint.json beside extracted.json — regenerate with "
                          "run_spec_pipeline so unsettled spec rows can be checked")
        unsettled = {}
    # The register must be WELL-FORMED before its contents mean anything: a blank, bolded, misspelt
    # or duplicated status would each read as "not open", which is the fail-open direction for
    # every gate that consults it.
    errors += decision_register_errors(dec_text, os.path.basename(product_dir))
    errors += mixed_format_error(read(contract), "FUNCTIONAL_CONTRACT.md")
    # Beside the other structural check on the same text, and BEFORE the invariants: every one of
    # them reads fields the table maps positionally, so a row whose width disagrees with the header
    # is a row whose fields they are reading off by one — or not at all.
    errors += [f"FUNCTIONAL_CONTRACT.md {e}" for e in table_shape_errors(read(contract))]
    if len(decs) < floors["decisions"]:
        errors.append(f"parsed only {len(decs)} decision IDs from DECISIONS.md "
                      f"(floor {floors['decisions']}) — parser/table changed")
    if len(gaps) < floors["gaps"]:
        errors.append(f"parsed only {len(gaps)} gap IDs from ENGINE_GAPS.md "
                      f"(floor {floors['gaps']}) — gap-ID index changed")

    seen = {}
    requirements = {}          # variable_id -> requirement axis, for the I14 pack-level check
    unwritten = {}             # decision_required records still holding TODO (I14)
    built_while_blocked = []   # (variable_id, implementation) for decision-blocked builds (I14)
    grouped = []               # (variable_id, rows cited, refs) for records spanning >1 row (I16)
    n = 0
    for block in records(read(contract)):
        n += 1
        vid = re.search(r"(?m)^variable_id:\s*(\S+)", block).group(1)
        tag = f"[{vid}]"

        # I1 uniqueness
        if vid in seen:
            errors.append(f"{tag} I1 duplicate variable_id (also at record #{seen[vid]})")
        seen[vid] = n

        # I6 completeness — the record carries the FULL canonical key set (no partial copies)
        for key in CANON:
            if not _has(block, key):
                errors.append(f"{tag} I6 missing/empty canonical field `{key}`")
        st = _inline(block, "status")
        out = _inline(block, "output")
        pub = _inline(block, "publish")
        for key, body in (("status", st), ("output", out), ("publish", pub)):
            if body is None:
                errors.append(f"{tag} I6 missing inline `{key}: {{...}}`")

        # I3 status enums
        req = _kv(st, "requirement")
        requirements[vid] = req
        checks = [("requirement", req, REQ),
                  ("implementation", _kv(st, "implementation"), IMPL),
                  ("validation", _kv(st, "validation"), VAL)]
        coarse = _kv(st, "source")
        fine = {k: _kv(st, k) for k in FINE_SOURCE_AXES}
        if coarse is not None:
            checks.append(("source", coarse, SRC))
        elif all(v is not None for v in fine.values()):
            checks.extend((k, fine[k], FINE_SOURCE_AXES[k]) for k in FINE_SOURCE_AXES)
        else:
            missing = sorted(k for k, v in fine.items() if v is None)
            errors.append(f"{tag} I6 status needs either the coarse `source` axis or all four of "
                          f"{sorted(FINE_SOURCE_AXES)} — missing {missing}")
        for name, val, allowed in checks:
            if val is None:
                errors.append(f"{tag} I6 status.{name} missing")
            elif val not in allowed:
                errors.append(f"{tag} I3 status.{name}='{val}' not in {sorted(allowed)}")

        # THIS record's output role, read BEFORE anything consults it. The I13 unavailable-source
        # check below used `role` six lines before this assignment: on the FIRST record it raised
        # UnboundLocalError, and on any later one it silently reused the PREVIOUS record's role — so
        # a published record with an unavailable source and no decision passed the gate whenever the
        # record above it happened to be `excluded`. Order-dependent, and green.
        role = _kv(out, "role")
        namest = _kv(out, "name_status")

        # I3 the source kind itself. Five legal values; anything else is a typo that would otherwise
        # reclassify the record into one nobody has to evidence.
        skind = source_kind(block)
        if skind == "invalid":
            errors.append(f"{tag} I3 source.kind='{_source_field(block, 'kind')}' not in "
                          f"{sorted(SOURCE_KINDS)}")
        # I19 `implementation_refs` must be ANSWERED, not merely present. #344 made the column
        # structurally required, but the value stayed outside CANON, so the binder asked for it only
        # when `implementation` was `implemented` or `partial` — and a `not_implemented` record could
        # leave the canonical cell blank and pass. "The column exists" and "the field is answered"
        # are the distinction every other evidence field in this file is built on.
        if not (_list(block, "implementation_refs") or []):
            errors.append(f"{tag} I19 implementation_refs is not a list "
                          f"(`{_scalar(block, 'implementation_refs') or '(blank)'}`) — write "
                          f"`[none]` when nothing implements this record yet. A blank cell or a TODO "
                          f"is an unanswered question; `[none]` is an ANSWER, and this field must not "
                          f"let the two look alike")

        # I20 the inline cells are STRUCTURALLY well formed, not merely answerable. Checked over the
        # same four fields the rest of this file reads through `_inline`, because an unterminated map
        # swallows whatever follows it and every token-scanning check keeps returning the right
        # answer. Balanced braces is the cheapest property that would have caught it; a real parser
        # for this notation is the better fix and a bigger one.
        for _field in ("source", "output", "status", "publish"):
            _cell = _inline(block, _field) or ""
            if _cell and _cell.count("{") != _cell.count("}"):
                errors.append(
                    f"{tag} I20 `{_field}` is not well formed — {_cell.count('{')} `{{` and "
                    f"{_cell.count('}')} `}}`. An unterminated map swallows the fields after it: "
                    f"every other check here finds a field by scanning for its token, so this cell "
                    f"can answer all of them while the field is structurally inside another map")

        # I23 the worked example computes — see the docstring. Only the unambiguous `a / b = c`
        # shape is arithmetic; everything else in the cell is prose and stays unjudged. Decimal,
        # not float: the comparison is at the example's own precision and must not inherit binary
        # rounding. A zero denominator is not skipped — `1/0 = 7` is not prose, it is arithmetic
        # that cannot be right, and skipping it accepted exactly that.
        _acc = _scalar(block, "acceptance") or ""
        for _num, _den, _res in _ACCEPT_ARITH.findall(_acc):
            _d = decimal.Decimal(_den)
            if _d == 0:
                errors.append(
                    f"{tag} I23 acceptance example divides by zero — `{_num}/{_den} = {_res}` "
                    f"is not a computable example; fix the operands or drop the computation")
                continue
            _digits = len(_res.split(".")[1]) if "." in _res else 0
            _true = decimal.Decimal(_num) / _d
            # EXACT at the example's own precision: the stated result must BE the true value
            # rounded (half-up, the default convention) to the digits it displays — or truncated
            # (ages, whole months), but ONLY when the cell SAYS so ("floor"/"trunc"): accepting
            # either silently meant `2/3 = 0` and `2/3 = 1` both passed, so a wrong one passed
            # half the time, which an external review called the ambiguity it is. A ±1-unit
            # tolerance before that accepted `1/3 = 1` — off by triple — which is not a check.
            _q = decimal.Decimal(10) ** -_digits
            _rounded = _true.quantize(_q, rounding=decimal.ROUND_HALF_UP)
            _floored = _true.quantize(_q, rounding=decimal.ROUND_DOWN)
            _stated = decimal.Decimal(_res)
            _says_floor = bool(re.search(r"floor|trunc", _acc, re.I))
            if _stated == _rounded or (_stated == _floored and _says_floor):
                pass
            elif _stated == _floored:
                errors.append(
                    f"{tag} I23 acceptance example {_num}/{_den} = {_res} is the TRUNCATED value "
                    f"(rounded is {_rounded}) and the cell does not say so — write the convention "
                    f"into the example ('floored'/'truncated'), or state the rounded value. An "
                    f"example that could be either convention verifies neither")
            else:
                errors.append(
                    f"{tag} I23 acceptance arithmetic is wrong — {_num}/{_den} is "
                    f"{_true:.{_digits + 2}f}, the example says {_res} (neither the rounded value "
                    f"nor a stated truncation at {_digits} decimal place(s)). A worked example is "
                    f"read as evidence downstream; fix the number or drop the computation")

        # I24 every depends_on entry resolves — see the docstring for the four legal targets.
        # A record depending on ITSELF resolves and is still wrong; record-to-record edges are
        # collected here and judged for cycles after the loop, when every record has been read.
        for _dep in (_list(block, "depends_on") or []):
            _dep = _dep.strip()
            if not _dep or _dep.lower() in ("none", "n/a", "na") or _dep == "TODO":
                continue
            if _dep == vid:
                errors.append(
                    f"{tag} I24 depends_on '{_dep}' is the record itself — a self-dependency "
                    f"resolves and still describes nothing; cite the upstream it actually "
                    f"rides on, or `none`")
                continue
            if _dep.startswith("engine:"):
                _stage = _dep[len("engine:"):].strip()
                if not _stage or (_engine_stages is not None and _stage not in _engine_stages):
                    errors.append(
                        f"{tag} I24 depends_on '{_dep}' names no engine stage "
                        f"(has: {sorted(_engine_stages or [])}) — an engine dependency cites the "
                        f"stage that builds it, platform/engine/stages/<stage>.py")
                continue
            if _dep not in _all_vids and _dep not in _svar_names:
                errors.append(
                    f"{tag} I24 depends_on '{_dep}' resolves to nothing — not a record's "
                    f"variable_id, not a variable the extraction names. A cross-reference that "
                    f"names nothing is prose in a field's clothes; cite the record or spec "
                    f"variable this rides on, `engine:<stage>` for an engine intermediate, or "
                    f"`none`")
            elif _dep in _all_vids:
                _dep_edges.setdefault(vid, set()).add(_dep)

        # I18 `pending_mapping` is the pre-config state, and every one of its conditions is a thing
        # that stops it becoming a permanent excuse: it must carry the spec's identifiers VERBATIM
        # so the mapping can be finished by someone who never saw the workbook, and it can never
        # be approved, verified or implemented.
        if skind == PENDING_MAPPING:
            # THE PACK'S REGISTRY IS NOT THIS RECORD'S MAPPING, and treating it as one made the
            # state unreachable: the old condition was a pack-level "declares a `sources:` block"
            # test, and `TUMOR_TEMPLATE` ships a `sources:` block full of REPLACE_ME — so the
            # starter pack the skill points every new tumour at counted as HAVING a registry from
            # its first commit, and `pending_mapping` was illegal in the one place it was designed
            # for. A new concept in a mature pack was worse still: the honest state for a variable
            # nobody has mapped yet could not be written at all, so the drafter's only legal moves
            # were to invent a source or to omit the record.
            #
            # What actually closes this state is a HUMAN CONFIRMING THIS CONCEPT'S MAPPING, which
            # is a per-record fact, and the record already carries it — `source: unverified`, which
            # the conditions below require. So the deadline moves to where it belongs: Gate 4 is
            # what may not be approved while any mapping is open (product_gates), because a
            # configuration cannot express a contract whose sources are undecided. Gate 2 is about
            # what the requirement IS, and a requirement is fully stateable before its source is.
            # Nothing is loosened overall — `pending_mapping` still cannot be approved, verified or
            # implemented, and is now counted rather than merely forbidden.
            idents = spec_identifiers(block)
            if not idents:
                errors.append(f"{tag} I18 source.kind={PENDING_MAPPING} requires "
                              f"`spec_identifiers: [...]` — the identifiers the SPEC names, copied "
                              f"exactly. Without them the mapping cannot be finished by anyone who "
                              f"did not read the workbook, and the record states no source at all")
            # TODO_RE, not product_gates.unstated: this module is stdlib-only on purpose (every
            # product's test wrapper runs it standalone), and TODO_RE is already its placeholder
            # vocabulary. A second placeholder set here is precisely the divergence docs/ENGINEERING.md records
            # source_manifest paying for.
            for ident in idents:
                if TODO_RE.search(ident):
                    errors.append(f"{tag} I18 spec_identifiers holds the placeholder '{ident}' — a "
                                  f"placeholder is not an identifier the spec names")
            # NO GAP IS REQUIRED, and requiring one broke the official new-product path outright.
            # The starter pack ships no ENGINE_GAPS.md — a gap is an APPROVED requirement the build or
            # feed cannot satisfy, which is Gate 4 material that arrives after the contract exists. So
            # the sequence was: new pack has no registry -> the skill says use pending_mapping -> I18
            # demands a gap -> no gap register exists -> the id resolves to nothing -> I2 fails. Every
            # genuinely new product, regardless of tumour.
            #
            # It was also redundant. `pending_mapping` is ALREADY explicit, countable, illegal once a
            # registry exists, and barred from approval, verification and implementation. That state
            # IS the backlog; a gap restating it is a second record of one fact, and this file's whole
            # argument is against those. A gap stays available for a genuinely broader implementation
            # problem — it is simply not the way "no source registry yet" gets recorded.
            if _kv(st, "requirement") == "approved":
                errors.append(f"{tag} I18 source.kind={PENDING_MAPPING} cannot be "
                              f"`requirement: approved` — approving a record whose source is "
                              f"undecided approves a rule nobody can execute")
            if _kv(st, "source") != "unverified":
                errors.append(f"{tag} I18 source.kind={PENDING_MAPPING} must be "
                              f"`source: unverified` (is '{_kv(st, 'source')}') — there is no source "
                              f"to have verified")
            if _kv(st, "implementation") not in ("not_implemented", "config_gap"):
                errors.append(f"{tag} I18 source.kind={PENDING_MAPPING} cannot be "
                              f"`implementation: {_kv(st, 'implementation')}` — a record with no "
                              f"logical source cannot have been built from one")

        # I13 extends to the source axis: `unavailable` is an exception from evidence, and an
        # exception has to name what it is an exception for.
        if skind == "unavailable":
            impl_now = _kv(st, "implementation")
            if not (_list(block, "gap_ids") or []):
                errors.append(f"{tag} I13 source.kind:unavailable but gap_ids is empty — a source "
                              f"the feed cannot supply is a gap, and a gap naming nothing is invisible")
            # A gap id alone was not enough: the record could still claim the implementation exists
            # and publish it. If the SOURCE cannot be supplied, the implementation cannot be whole.
            if impl_now in IMPL_BUILT:
                errors.append(f"{tag} I13 source.kind:unavailable but implementation:{impl_now} — "
                              f"a value whose source the feed does not supply cannot be built; use "
                              f"not_derivable / not_implemented / config_gap / engine_gap")
            # The release treatment has to be stated. Publishing an intentionally null indicator can
            # be a legitimate design, so this does not force exclusion — it forces a CHOICE, made
            # either by excluding the output or by naming the decision that approved publishing it.
            if role != "excluded" and not (_list(block, "decision_ids") or []):
                errors.append(f"{tag} I13 source.kind:unavailable with output.role:{role} — a value "
                              f"the feed cannot supply must either be excluded from the output or "
                              f"cite the decision that approved publishing it anyway")

        # I3 output.role / name_status
        if role is None or role not in ROLE:
            errors.append(f"{tag} I3 output.role='{role}' not in {sorted(ROLE)}")
        if namest is not None and namest not in NAMEST:
            errors.append(f"{tag} I3 output.name_status='{namest}' not in {sorted(NAMEST)}")

        # I3 publish enums
        for field in ("ads", "dictionary", "dashboard", "tfl"):
            v = _kv(pub, field)
            if v is None:
                errors.append(f"{tag} I6 publish.{field} missing")
            elif v not in PUB:
                errors.append(f"{tag} I3 publish.{field}='{v}' not in {sorted(PUB)}")

        # I4 published records carry physical_name / type / nullable
        if role == "published" and out is not None:
            pn = re.search(r"physical_name:\s*(.+?),\s*target_published_name:", out)
            ty = re.search(r"(?:^|,)\s*type:\s*(.+?),\s*nullable:", out)
            nu = re.search(r"nullable:\s*(.+?)\s*,", out)
            if not (pn and pn.group(1).strip() and pn.group(1).strip() != "n/a"):
                errors.append(f"{tag} I4 published record has no usable physical_name")
            if not (ty and ty.group(1).strip()):
                errors.append(f"{tag} I4 published record has no type")
            if not (nu and nu.group(1).strip()):
                errors.append(f"{tag} I4 published record has no nullable")

        # I2 + I7 decisions
        dids = _list(block, "decision_ids")
        if dids is None:
            errors.append(f"{tag} I6 missing decision_ids: [...]")
            dids = []
        for d in dids:
            if d not in decs:
                errors.append(f"{tag} I2 decision_id '{d}' not defined in DECISIONS.md")
        # I7 removed: it rejected ANY requirement-level decision id on an approved record without
        # looking at the decision's STATUS, so keeping `FUED-DEFINITION` as the audit trace of what
        # settled the requirement was a lint error — the only way to pass was to delete the link
        # between the requirement and the decision that answered it. I11 below already asks the
        # status-aware question (a non-decision_required record must cite no OPEN requirement
        # decision), so resolved ids now stay for provenance and one rule owns decision state.

        # I15 the record is bound to the TEXT it was written from, not just to row numbers.
        #
        # RWB editing a rule in place is invisible to every other check: the row still exists, the
        # citation still resolves, coverage still maps it. Flipping ECOG's same-day tie-break from
        # `highest` to `lowest` left the contract saying "worst (highest) grade" with all fourteen
        # other invariants passing. The digest moves when the cited text moves, so the record has to be
        # re-read by a person and the new value written in deliberately.
        # Absence is the generic I6 presence check's business; reporting it here too would be two
        # messages for one fact. I15 speaks only when a digest exists and no longer matches.
        recorded = _scalar(block, "spec_digest")
        current = spec_digest(_list(block, "spec_refs") or [], srows)
        if recorded and current and recorded != current:
            errors.append(f"{tag} I15 spec_digest {recorded} but the cited spec rows now hash to "
                          f"{current} — the source text changed under this record. Re-read the cited "
                          f"rows, update the record, then set spec_digest: {current}")

        # I8 spec_refs walk back to a real captured row. Only `domain:row` (and `domain:row-row`) forms
        # are checkable — prose refs like "5C.TreatVars (config addition)" are skipped, not failed.
        refs = _list(block, "spec_refs") or []
        if refs == [NO_SPEC_ROW]:
            # A variable with no specification row is an ADDITION beyond what RWB asked for. That is
            # allowed, but it must never be silent: something has to record why it exists, which means a
            # requirement-level decision or a gap. NAME-ALIGN/CODE-ALIGN govern the output, not this.
            governed = [d for d in (_list(block, "decision_ids") or []) if d not in OUTPUT_DECISIONS]
            if not (governed or _list(block, "gap_ids")):
                errors.append(f"{tag} I8 spec_refs: [{NO_SPEC_ROW}] — a variable with no spec row must "
                              f"name the decision or gap that records why it exists")
        # I16 counts here rather than re-walking spec_refs afterwards: one parse of a citation, not two
        # that could come to disagree about what `clinical:17-46` spans.
        cited_rows = 0
        for ref in refs:
            if ref == NO_SPEC_ROW:
                continue
            rows = spec_ref_rows(ref)
            if not rows:
                # Skipping an unparseable ref made I8 optional: any citation could evade validation by
                # not looking like one. A note about scope belongs in `notes`, not in spec_refs.
                errors.append(f"{tag} I8 spec_ref '{ref}' is not a `<domain>:<row>` citation — a note "
                              f"about scope belongs in `notes`, not in spec_refs")
                continue
            # What the citation CLAIMS, counted before the domain check: a record spanning rows the
            # extraction does not carry is still a record spanning rows.
            cited_rows += len(rows)
            domain = rows[0][0]
            if domain not in srows:
                errors.append(f"{tag} I8 spec_ref '{ref}' names domain '{domain}', which the extraction "
                              f"does not carry (has: {sorted(srows)}) — see governance/SPEC_DOMAINS.md")
                continue
            # Every row in a range, not just the endpoints: a range whose ends exist can still span
            # rows that do not, and those rows are then cited by nothing while looking covered.
            gaps_in_range = [n for _, n in rows if n not in srows[domain]]
            if gaps_in_range:
                shown = ", ".join(str(n) for n in gaps_in_range[:6])
                errors.append(f"{tag} I8 spec_ref '{ref}' -> row(s) {shown}"
                              f"{' ...' if len(gaps_in_range) > 6 else ''} not captured from the spec")
        if cited_rows > 1:
            grouped.append((vid, cited_rows, list(refs)))   # judged at contract:approved only — see I16

        # I22 the rule cell quotes the cited row, verbatim under folding — see the docstring for the
        # measurement (198/202 already identical) and for why single-row citations only.
        if len(refs) == 1 and refs[0] != NO_SPEC_ROW:
            single = spec_ref_rows(refs[0])
            if len(single) == 1:
                spec_def = sdefs.get(single[0], "")
                rule = _scalar(block, "required_rule") or ""
                if spec_def.strip() and rule and rule != "TODO" \
                        and _fold_cell(rule) != _fold_cell(spec_def):
                    errors.append(f"{tag} I22 required_rule is not the cited row's Definition cell — "
                                  f"the record says\n        {rule[:200]}\n      and {refs[0]} says\n"
                                  f"        {spec_def[:200]}\n      The requirement cell quotes the "
                                  f"spec verbatim (typos and all); the interpretation belongs in "
                                  f"derivation/notes, and a spec defect in SPEC_QC_FINDINGS.md")

        # I17 a record over a spec row the deterministic lint judged UNSETTLED must stay visibly
        # unresolved. This is the only invariant that can catch an INVENTED value: a fabricated
        # `age >= 18` over a row whose own text says "no age operator/threshold is present in the
        # source documents" satisfies every other check — complete, correctly typed, properly cited,
        # digest intact. Nothing else here reads what the spec actually failed to say.
        #
        # Two escapes, because a flagged row is not permanently unanswerable. A record still being
        # written leaves the REQUIREMENT open — a TODO on a requirement field; a record whose question
        # was PUT TO RWB AND ANSWERED cites the decision that records the answer, open or resolved.
        # What the invariant refuses is the third case — confident, complete, and citing nothing that
        # explains where the answer came from.
        #
        # FIELD-SPECIFIC, via `_todo_toplevel` ∩ REQUIREMENT_FIELDS — not `TODO_RE.search(block)`. Any
        # A TODO ANYWHERE would satisfy this: `output: {physical_name: TODO}` (the spec silent on
        # the physical NAME — routine) or a `source:` mapping still open (a SEPARATE axis) would then
        # excuse an invented `record_selection`/`derivation` over a row the lint flagged UNSETTLED.
        # `_todo_toplevel`, not `todo_fields`: the latter returns ["a field"] when there are none and
        # is always truthy, which as a predicate silently disables the check — the trap this comment
        # has always named. `_todo_toplevel` reports top-level keys and is empty when nothing is TODO.
        if unsettled and req != "decision_required":
            flagged = sorted({k for r in refs for k in unsettled.get(r, [])})
            open_on_requirement = _todo_toplevel(block) & REQUIREMENT_FIELDS
            if flagged and not open_on_requirement \
                    and not (_list(block, "decision_ids") or _list(block, "gap_ids")):
                errors.append(
                    f"{tag} I17 cites spec row(s) the lint flagged {', '.join(flagged)} — the "
                    f"specification does not settle this — but the record answers the REQUIREMENT "
                    f"confidently: no TODO on a requirement field, no decision. A TODO only on the "
                    f"source or naming axis does not count — those are separate from the requirement. "
                    f"Raise a decision, or keep the unresolved requirement field TODO. See "
                    f"spec_pipeline/out/SPEC_FINDINGS.txt")

        # I9 is not emitted here. Its trigger — requirement:approved + implementation:not_derivable
        # with no gap_id — is a STRICT SUBSET of I13's, because `not_derivable` is in IMPL_SHORTFALL:
        # every record I9 could name, I13 named too, so the one defect produced two failures and a
        # reader had to work out they were the same record. I13 owns the emission and says the
        # approved-specific part in its own message; the reasoning is kept in the header.

        # I12 cross-axis consistency. Validation cannot outrun implementation, and implementation cannot
        # outrun the requirement — a record validated on live data whose rule is still draft is claiming
        # evidence for something nobody has agreed.
        impl = _kv(st, "implementation")
        val = _kv(st, "validation")
        if req == "decision_required" and impl in IMPL_BUILT:
            built_while_blocked.append((vid, impl))     # judged at contract:approved only — see I14

        rank = VALIDATION_RANK.get(val, 0)
        if rank > 0:
            if impl not in IMPL_BUILT:
                errors.append(f"{tag} I12 validation:{val} but implementation:{impl} — nothing was built "
                              f"to validate")
            if req != "approved":
                errors.append(f"{tag} I12 validation:{val} but requirement:{req} — a rule that is not "
                              f"approved cannot have been validated against it")
        if rank == 2 and coarse is not None and coarse == "unverified":
            errors.append(f"{tag} I12 validation:passed_live but status.source:unverified — live "
                          f"validation implies the source mapping was confirmed")

        # I13 a shortfall must name its gap — including the I9 case, which is one of these.
        if impl in IMPL_SHORTFALL and not _list(block, "gap_ids"):
            errors.append(f"{tag} I13 implementation:{impl} but no gap_id — the build falls short of the "
                          f"requirement and nothing records what is missing"
                          + (" (I9: an APPROVED requirement stays approved when the feed cannot supply "
                             "it — RWB asked for it and that is a source gap, not grounds to "
                             "un-approve — but it must never sit silently, or the variable simply "
                             "vanishes from the build with nothing saying why)"
                             if req == "approved" and impl == "not_derivable" else ""))

        # I11 the decision loop. A record blocked on nothing has no recorded reason to be blocked; a
        # record left blocked after its decision RESOLVED is work nobody has been handed. Both states
        # look fine in isolation and only show up by comparing the two files.
        open_req = blocking_decisions(dids, dec_open)
        if req == "decision_required" and not open_req:
            resolved = [d for d in dids if dec_open.get(d, "OPEN") != "OPEN"]
            errors.append(f"{tag} I11 requirement:decision_required but cites no OPEN requirement-level "
                          + (f"decision — {resolved} now RESOLVED, so write the answer into the record "
                             f"and move it off decision_required" if resolved else
                             "decision — nothing records what it is blocked on"))
        elif req != "decision_required" and open_req:
            errors.append(f"{tag} I11 cites OPEN requirement-level decision(s) {open_req} but is "
                          f"requirement:{req} — a record blocked on an open question is decision_required")

        # I10 approving a record means the judgment fields have been made, not just the status flipped.
        # The scaffold hands back TODO in every field a person still owes; an approved record holding
        # one means the requirement was approved before it was written.
        # Matching whole lines only missed every TODO inside an inline dict — and status/output/publish
        # are REQUIRED to be inline dicts, so `output: {physical_name: TODO, type: TODO}` sailed past
        # the one check meant to stop an unwritten record being approved.
        if req == "decision_required" and TODO_RE.search(block):
            unwritten[vid] = block
        if req == "approved" and TODO_RE.search(block):
            errors.append(f"{tag} I10 requirement:approved but {', '.join(todo_fields(block))} "
                          f"still TODO")

        # I2 gaps
        gids = _list(block, "gap_ids")
        if gids is None:
            errors.append(f"{tag} I6 missing gap_ids: [...]")
            gids = []
        for g in gids:
            if g not in gaps:
                errors.append(f"{tag} I2 gap_id '{g}' not in the ENGINE_GAPS gap-ID index")

        # I5 dashboard:configured must appear in the SHARED dashboard layout (compare the lower-case
        # physical code, since the layout lists physical codes — e.g. id3mosfu — not UPPER contract ids).
        if _kv(pub, "dashboard") == "configured":
            pn_m = re.search(r"physical_name:\s*(.+?),\s*target_published_name:", out or "")
            code = (pn_m.group(1).strip().strip('"').split("/")[0].split()[0].lower()
                    if pn_m else vid.lower())
            if dash is None:
                errors.append(f"{tag} I5 dashboard:configured but the shared dashboard_vars.yaml was not found")
            elif code not in dash:
                errors.append(f"{tag} I5 dashboard:configured but '{code}' is not in the shared dashboard_vars.yaml")

    # I14 a pack claiming `contract: approved` must have no record still being written.
    #
    # The maturity ladder's top rung was the one nothing checked. `coverage_complete` is enforced by
    # `--strict` (every spec item resolves), and Gate 1 refuses `approved` on an unapproved source —
    # but nothing looked at the records, so a pack could claim the workflow's Gate 2 exit ("every
    # requirement is approved or explicitly blocked by a named decision") with half its records still
    # draft. Vacuous today: no pack claims the level yet. It is the first pack that claims it that
    # this is for.
    from product_gates import CONTRACT_LEVELS, maturity                    # noqa: PLC0415
    contract_level = maturity(product_dir)["contract"]

    # I16 one record per specification row, judged from `coverage_complete` UP.
    #
    # Not at `approved`, which is where it was first written and where it did nothing: no pack claims
    # that level, so the rule was a promise rather than a control. `coverage_complete` is the claim
    # that every specification item resolves — and a contract cannot be complete row by row while a
    # record answers thirty rows at once. That is the level where the two statements have to agree.
    #
    # Below it a pack is still being drafted, and grouping while drafting is ordinary work.
    #
    # Why the shape matters at all: a family record is a LIST — ten analytes, eight metastasis sites,
    # twelve therapy categories. When the next tumour's specification adds an eleventh analyte it
    # lands inside the record's prose and inside a config list item, and every check stays green.
    # `contract_binding` iterates TOP-LEVEL config blocks, so a new member of `lab_values.panel:` is
    # not an unclaimed block; I15's digest moves only for rows the record already cites; coverage
    # reads `mapped` the moment anyone widens the range. The only thing between that addition and the
    # build is a person noticing. Splitting the CONFIGURATION the same way completes the control;
    # this invariant is the contract half of it.
    if CONTRACT_LEVELS.index(contract_level) >= CONTRACT_LEVELS.index("coverage_complete"):
        for vid, cited_rows, refs in grouped:
            errors.append(f"[{vid}] I16 one record over {cited_rows} specification rows "
                          f"({', '.join(refs)}) — at contract:{contract_level} every record cites "
                          f"exactly one row (WORKFLOW.md section 8). Split it: one record per row, "
                          f"each with its own rule, tie-break, units and approval")
        # I21 the reverse of I2, content-based and judged from coverage_complete up — the docstring
        # holds why substring rather than decision_ids, and why not below this level.
        contract_text = read(contract)
        for did in sorted(d for d, st in dec_open.items() if st == "OPEN"):
            if did not in contract_text:
                errors.append(f"I21 OPEN decision '{did}' is referenced nowhere in "
                              f"FUNCTIONAL_CONTRACT.md — a record should cite it in decision_ids "
                              f"(or name in its notes why the question exists), or the question is "
                              f"idle: answer, withdraw or supersede it through decision_record.py. "
                              f"An OPEN question the contract does not carry is invisible to every "
                              f"drafter")

    if contract_level == "approved":
        unsettled = sorted(v for v, r in requirements.items()
                           if r not in ("approved", "decision_required"))
        if unsettled:
            errors.append(f"I14 MATURITY.yaml claims contract:approved but {len(unsettled)} record(s) "
                          f"are still being written ({', '.join(unsettled[:6])}"
                          f"{'…' if len(unsettled) > 6 else ''}) — Gate 2 closes when every requirement "
                          f"is approved or explicitly blocked by a named decision")
        # `decision_required` is a legitimate end state at Gate 2, but it means "one thing is open",
        # not "most of this was never drafted". Without this a record could be blocked on a single
        # question with its rule, grain, anchor, window and derivation all still TODO, and I10 would
        # not look because I10 only reads approved records.
        for vid, block in unwritten.items():
            errors.append(f"[{vid}] I14 requirement:decision_required with "
                          f"{', '.join(todo_fields(block))} still TODO — at contract:approved the "
                          f"settled part of every record must be written, with only the blocked "
                          f"aspect naming its decision")
        # The compensating control for what Gate 2 permits. `contract: approved` is NOT refused
        # outright while a decision is open: WORKFLOW.md line 173 closes the gate when every
        # requirement is "approved OR explicitly blocked by a named decision". What makes that
        # permission safe is line 262 — "RWDE
        # implements only approved requirements; blocked or decision-gated records are not
        # implemented." Nothing enforced that half. A record could exit Gate 2 saying in one breath
        # that its rule is unanswered and that it is built, and the pack would still be `approved`.
        #
        # Judged HERE and not per-record on purpose. Before Gate 2 closes, a build standing ahead of an
        # open decision is ordinary development — the config is authored while the contract is under
        # review, and prostate/202606 carries 13 such records today, honestly. It is the claim that the
        # contract is FINISHED that makes the combination a contradiction, so that is where it bites.
        for vid, impl in built_while_blocked:
            errors.append(f"[{vid}] I14 requirement:decision_required but implementation:{impl} — at "
                          f"contract:approved a decision-gated record is not implemented (WORKFLOW.md "
                          f"Gate 5). Answer the decision, or drop the build to not_implemented")

    # I24's cycle half, judged once every record has been read: two records depending on each
    # other describe no build order, and the resolvable-name check alone would bless both.
    # Iterative DFS over the record->record edges; each cycle is reported once, at its
    # lexicographically first member, with the loop spelled out.
    _seen_cycles = set()
    for _start in sorted(_dep_edges):
        _stack, _path, _on_path = [(_start, iter(sorted(_dep_edges.get(_start, ()))))], [_start], {_start}
        while _stack:
            _node, _it = _stack[-1]
            _next = next(_it, None)
            if _next is None:
                _stack.pop(); _path.pop(); _on_path.discard(_node)
                continue
            if _next in _on_path:
                _cycle = _path[_path.index(_next):] + [_next]
                _key = frozenset(_cycle)
                if _key not in _seen_cycles:
                    _seen_cycles.add(_key)
                    errors.append(
                        f"[{min(_cycle)}] I24 depends_on cycle: {' -> '.join(_cycle)} — records "
                        f"that depend on each other describe no build order; break the loop by "
                        f"citing the true upstream (a spec variable or engine:<stage>)")
            elif _next in _dep_edges:
                _stack.append((_next, iter(sorted(_dep_edges[_next]))))
                _path.append(_next); _on_path.add(_next)

    if n < floors["records"]:
        errors.append(f"parsed {n} variable records from FUNCTIONAL_CONTRACT.md "
                      f"(floor {floors['records']}) — parser or file changed")
    return errors, n


def main(product_dir, floors=None):
    errors, count = run(product_dir, floors)
    print(f"parsed {count} variable records from {product_dir}")
    for e in errors:
        print(f"  FAIL {e}")
    if errors:
        print(f"\n{len(errors)} violation(s)")
        return 1
    print(f"\nOK — {count} records, all {len(INVARIANTS)} invariants pass")
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    # argparse like every other tool — `--help` used to be treated as a pack directory and linted
    # ("parsed 0 variable records from .../--help"), the one CLI here that answered help with a FAIL.
    _ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    _ap.add_argument("product", help="path to a product pack (holds handoff/FUNCTIONAL_CONTRACT.md)")
    _a = _ap.parse_args()
    sys.exit(main(os.path.abspath(_a.product)))
