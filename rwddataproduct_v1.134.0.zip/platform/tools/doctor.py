#!/usr/bin/env python3
"""Can this machine run this package, and what can it not do?

    python3 platform/tools/doctor.py            # every check, and what each missing thing costs
    python3 platform/tools/doctor.py --quiet     # only what is wrong

WHY THIS EXISTS. The first thing a colleague does with a clone is run something, and the first way
this repository fails a stranger is not a bug — it is a missing dependency, an unwritable output
directory or a console code page, each of which surfaces as a traceback several steps into a tool
that had nothing to do with it. `pip install -r requirements.txt` failing is legible; `openpyxl`
missing is a stack trace from inside a dictionary renderer.

TWO KINDS OF FINDING, and conflating them is what makes an environment check useless:

  REQUIRED   nothing works without it. The exit code is non-zero and the demo will not run.
  OPTIONAL   something specific does not work. PySpark's absence is not a defect — the engine
             stages are one of five things this package does — but "optional" printed alone tells
             you nothing, so each says WHICH capability you do not have.

DERIVES THE REQUIREMENT LIST FROM requirements.txt rather than restating it. A second list here
would agree on the day it was written and drift the first time a dependency moved, and it would
drift in the direction of reporting green.

stdlib only, deliberately: a dependency check that cannot run without its dependencies is a joke
somebody has to debug at the worst possible moment.
"""
import argparse
import os
import re
import shutil
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import console                                                             # noqa: E402

OK, MISSING, LIMITED = "ok", "MISSING", "limited"

# The floor the code is written against, and the reason, so raising it is a decision rather than a
# drift. 3.9 is what the syntax needs; CI runs 3.11 and the runbooks say 3.11.
MIN_PYTHON = (3, 9)

# WHAT AN OPTIONAL PIECE BUYS, in the terms of this repository's own steps. "PySpark: not installed"
# is a fact nobody can act on; "you cannot run the engine stages" is the same fact as a decision.
OPTIONAL = (
    ("pyspark", "import", "run the engine stage suites or build an ADS off-cluster",
     'pip install "pyspark>=3.5"'),
    ("Rscript", "exe", "parse-check the R engine, run R<->Python parity, or run the data profiler",
     "install R (r-base-core)"),
    ("databricks", "exe", "deploy or run the Asset Bundle",
     "https://docs.databricks.com/en/dev-tools/cli/index.html"),
)


def requirements(path=None):
    """[(distribution, import name)] from requirements.txt — the file pip is pointed at, not a copy.

    The import name is not the distribution name for every package here, and guessing it by
    lowercasing is how a check reports a missing dependency that is installed. Only the ones that
    differ are listed; everything else imports under its own name.
    """
    other_name = {"pyyaml": "yaml"}
    path = path or os.path.join(ROOT, "platform", "requirements.txt")
    out = []
    if not os.path.exists(path):
        return out
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.split("#")[0].strip()
            if not line:
                continue
            dist = re.split(r"[<>=!~\[]", line)[0].strip()
            if dist:
                out.append((dist, other_name.get(dist.lower(), dist.replace("-", "_"))))
    return out


def _importable(name):
    import importlib.util
    try:
        return importlib.util.find_spec(name) is not None
    except (ImportError, ValueError):
        return False


def checks(out_dir=None):
    """[(status, subject, detail, what to do)] — every check, in the order a reader needs them.

    ORDERED BY WHAT BLOCKS WHAT. The interpreter before the packages it imports, the packages before
    the checkout that uses them, the checkout before the output directory the tools write to. A
    report that leads with a console code page while Python is too old has buried the answer.
    """
    rows = []

    have = sys.version_info[:3]
    rows.append((OK if have >= MIN_PYTHON else MISSING, "Python",
                 f"{'.'.join(map(str, have))} at {sys.executable}",
                 "" if have >= MIN_PYTHON
                 else f"this package needs {'.'.join(map(str, MIN_PYTHON))} or newer"))

    wanted = requirements()
    if not wanted:
        rows.append((MISSING, "requirements.txt", "not found beside platform/",
                     "this checkout is incomplete — re-clone it"))
    for dist, module in wanted:
        rows.append((OK if _importable(module) else MISSING, dist,
                     f"import {module}", "" if _importable(module)
                     else "pip install -r platform/requirements.txt"))

    # THE CHECKOUT ITSELF. Several tools read git state — the deployment tree refuses to bind a
    # release to a dirty or unresolvable HEAD — so "is this a git repository at all" is a question
    # the walkthrough's answer depends on, and a downloaded zip is a real way to arrive here.
    rows.append((OK if shutil.which("git") else MISSING, "git", "on PATH",
                 "" if shutil.which("git") else "install git — the packaging steps read HEAD"))
    if shutil.which("git"):
        code, head = _git("rev-parse", "--short", "HEAD")
        rows.append((OK if code == 0 else LIMITED, "git HEAD", head or "not a git repository",
                     "" if code == 0 else
                     "the packaging steps report instead of scoring — clone rather than download"))

    # WHERE RESTRICTED OUTPUT GOES. `pack_run.restricted_dir` REFUSES a path inside the checkout, and
    # that refusal is a control rather than an inconvenience: a profile or a schema report in the
    # tree is readable by every indexing tool and agent on the machine. So the question is not "can
    # I write" but "do I have somewhere outside the repository to write to".
    target = out_dir or os.path.join(os.path.expanduser("~"), "rwdp-out")
    rows.append(_safely(_writable, "output directory", target))

    rows.append(_safely(_console, "console encoding"))

    for name, kind, capability, fix in OPTIONAL:
        present = _importable(name) if kind == "import" else bool(shutil.which(name))
        rows.append((OK if present else LIMITED, name,
                     "installed" if present else f"absent — you cannot {capability}",
                     "" if present else fix))
    return rows


def _safely(check, subject, *args):
    """Run one check; turn any explosion into a ROW rather than a traceback.

    A DIAGNOSTIC MAY NOT DIE OF THE THING IT DIAGNOSES. The output-directory check imported a module
    that imports yaml, so on a machine with no PyYAML this tool exited with an ImportError traceback
    having printed nothing — the person is told nothing, least of all that PyYAML is what is missing.
    That specific import is gone; this makes the class of failure impossible rather than that one
    instance of it, because the next check somebody adds will reach for something too.

    Reported as MISSING, not swallowed: a check that could not run has not passed.
    """
    try:
        return check(*args)
    except Exception as err:                                  # noqa: BLE001 — deliberate, see above
        return (MISSING, subject, f"the check itself failed: {type(err).__name__}: {err}",
                "this is a defect in doctor.py — report it with the line above")


def _git(*args):
    if not shutil.which("git"):
        return 1, ""
    p = console.run(["git", "-C", ROOT] + list(args), capture_output=True)
    return p.returncode, (p.stdout or "").strip()


def _writable(target):
    """Whether restricted output has somewhere to go — CREATING NOTHING on the way to the answer.

    A first version called `os.makedirs` and left the directory behind, including one inside the
    checkout while it was busy deciding that directory was not allowed. A check with a side effect is
    not a check: run it twice and the second run is answering a question about the first.

    So it walks UP to the nearest existing ancestor and probes there. That is the same question — a
    path is creatable exactly when some ancestor of it is writable — asked without making anything.
    """
    # `spec_extract.inside_checkout`, NOT `pack_run.restricted_dir`. Same predicate, same owner — but
    # `pack_run` imports product_gates and engine.config, both of which import yaml, so asking it
    # crashed this tool with an ImportError on a machine with no PyYAML. That is the exact machine
    # this tool exists to diagnose, and it died before printing the row that says PyYAML is missing.
    from spec_extract import inside_checkout
    resolved = os.path.realpath(os.path.expanduser(target))
    if inside_checkout(resolved, ROOT):
        return (MISSING, "output directory", f"{resolved} is inside the checkout",
                "choose a directory outside the repository — restricted output may not be committed")
    exists = resolved
    while not os.path.isdir(exists):
        parent = os.path.dirname(exists)
        if parent == exists:                         # walked off the top of the filesystem
            return (MISSING, "output directory", f"{resolved} has no existing parent",
                    "pass --out-dir a path whose parent exists")
        exists = parent
    if not os.access(exists, os.W_OK):
        return (MISSING, "output directory", f"{resolved} is not writable ({exists} is read-only)",
                "pass --out-dir somewhere you can write")
    note = "" if exists == resolved else f" (will be created under {exists})"
    return (OK, "output directory", f"{resolved} is writable and outside the checkout{note}", "")


def _console():
    """Whether this console can DISPLAY what the tools print, after they have configured it.

    `console.use_utf8()` has already run by the time this is reached from `__main__`, so what is
    measured is the state a tool actually prints into — not the interpreter's default, which is what
    a check written the obvious way would report and which the tools override.

    LIMITED, never MISSING. `errors="replace"` means an undisplayable character costs one glyph, not
    the report; a code page is a display concern and refusing to run over one would be theatre.
    """
    enc = getattr(sys.stdout, "encoding", None) or "unknown"
    sample = "— · «»"
    try:
        sample.encode(enc)
    except (UnicodeEncodeError, LookupError):
        return (LIMITED, "console encoding", f"{enc} cannot show {sample!r} — glyphs are replaced",
                "on Windows: chcp 65001, or read the tools' --out files instead of the terminal")
    return (OK, "console encoding", f"{enc} shows every character the tools print", "")


def report(rows, quiet=False):
    """The rows as text. Returns the number of REQUIRED failures — the thing the exit code is."""
    bad = [r for r in rows if r[0] == MISSING]
    limited = [r for r in rows if r[0] == LIMITED]
    width = max([len(r[1]) for r in rows] + [10])
    lines = []
    if not quiet:
        lines.append(f"environment for {ROOT}")
        lines.append("")
        for status, subject, detail, _fix in rows:
            mark = {OK: "  ok ", MISSING: "  !! ", LIMITED: "  -- "}[status]
            lines.append(f"{mark}{subject:<{width}}  {detail}")
        lines.append("")
    if bad:
        lines.append(f"{len(bad)} REQUIRED thing(s) missing — the demo will not run:")
        for _s, subject, detail, fix in bad:
            lines.append(f"   {subject}: {detail}")
            if fix:
                lines.append(f"      -> {fix}")
    if limited and not quiet:
        lines.append(f"{len(limited)} optional thing(s) absent. Everything else still runs:")
        for _s, subject, detail, fix in limited:
            lines.append(f"   {subject}: {detail}")
            if fix:
                lines.append(f"      -> {fix}")
    if not bad:
        lines.append("")
        lines.append("READY. Next: python3 platform/tools/demo.py products/oncology/prostate/202606")
    print("\n".join(lines))
    return len(bad)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("--out-dir", help="where restricted output would go (default ~/rwdp-out). "
                                      "Checked for being writable and OUTSIDE the checkout.")
    ap.add_argument("--quiet", action="store_true", help="print only what is wrong")
    a = ap.parse_args(argv)
    return 1 if report(checks(a.out_dir), a.quiet) else 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
