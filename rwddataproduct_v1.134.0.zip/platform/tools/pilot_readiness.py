#!/usr/bin/env python3
"""Can this pack be piloted today, and what exactly is safe to run? — one read-only answer.

    python3 platform/tools/pilot_readiness.py <pack>
    python3 platform/tools/pilot_readiness.py <pack> --json

WHY THIS EXISTS. Answering "are we ready to run this tomorrow" meant running six tools and holding
their outputs in your head: `doctor.py` for the machine, `status.py` for the gates,
`run_spec_pipeline.py --check` for the extraction, `source_manifest.py --check` for the
registration, a look in `config/pipeline.yaml` for the runtime bindings, and a memory of whether
anybody had run the smoke. Nobody does that under time pressure at 9am, so the question got
answered from impression instead — and an impression of readiness is exactly what a governance
framework exists to replace.

IT COMPOSES; IT DOES NOT RE-CHECK. Every fact here is read from the tool that owns it — `doctor`
for the environment, `status` for the gates, `run_spec_pipeline.ARTIFACTS` for what an extraction
consists of, `placeholders.RUNTIME_BINDINGS` for which keys are supplied per run. A second
implementation of any of them would be a second answer to one question, which is the failure this
repository keeps paying for. When one of those tools changes, this report changes with it.

IT GRANTS NOTHING AND WRITES NOTHING. It cannot approve, register, or mark anything ready; a green
line here means "the precondition holds", never "you may proceed". The gates decide that, and they
are unmoved by this file. `--json` goes to stdout and to no file, for the same reason `status.py`
refuses to write its own: a report carrying today's date cannot be byte-compared by a `--check`, so
a written one would rot into a stale claim that looks generated.

WHAT IT DELIBERATELY CANNOT TELL YOU. Whether the local smoke has been run: its evidence is written
OUTSIDE the checkout on purpose, so nothing in here can see it. That is reported as unknown rather
than guessed — see `_smoke`.

stdlib only (plus what the tools it composes already need).
"""
from __future__ import annotations

import argparse
import json
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import doctor                                                            # noqa: E402
import status as status_tool                                             # noqa: E402
from placeholders import RUNTIME_BINDINGS                                # noqa: E402
from run_spec_pipeline import ARTIFACTS                                  # noqa: E402
from spec_extract import repo_relative                                   # noqa: E402

# The three states a line can be in. `UNKNOWN` is not a soft `NO`: it means this report cannot see
# the answer, and collapsing it into either of the others is how an absence comes to read as a
# result — the defect this repository has had to fix in six other tools.
OK, NO, UNKNOWN = "ok", "NO", "unknown"
MARK = {OK: "[ok ]", NO: "[NO ]", UNKNOWN: "[ ? ]"}

# Where the extraction lands, relative to a pack. `variables_scaffold/` sits in the SAME directory
# and is a different kind of thing entirely — inventory-derived parameter skeletons that need no
# workbook — so the presence of `spec_pipeline/out/` proves nothing on its own. This report asks
# for the seven artifacts by name.
OUT_DIR = os.path.join("spec_pipeline", "out")


def _environment(out_dir=None):
    """Through `doctor.checks`, which owns the question of what this machine can run."""
    rows = []
    for state, subject, detail, fix in doctor.checks(out_dir):
        mark = {doctor.OK: OK, doctor.MISSING: NO, doctor.LIMITED: UNKNOWN}.get(state, UNKNOWN)
        rows.append((mark, subject, detail if mark == OK else f"{detail}{'  -> ' + fix if fix else ''}"))
    return rows


def _registration(pack):
    """Is the workbook registered, and does the registration name its BYTES?

    Two separate facts, reported separately. `source_refs.yaml` existing means somebody registered
    something; a recorded digest means the registration is bound to content rather than to a path,
    which is what survives the workbook being replaced in place.
    """
    sys.path.insert(0, TOOLS)
    import product_gates as pg                                           # noqa: PLC0415
    path = os.path.join(REPO, pack, "source_refs.yaml")
    if not os.path.exists(path):
        return [(NO, "source registered", "no source_refs.yaml — Gate 1 has not begun. Nothing can "
                                          "be extracted, because nothing has been approved to read")]
    doc, err = pg.read_yaml(path)
    if err:
        return [(NO, "source registered", f"source_refs.yaml does not parse: {err}")]
    mats = (doc or {}).get("source_materials") or []
    rows = [(OK, "source registered", f"{len(mats)} material(s) in source_refs.yaml")]
    for m in mats if isinstance(mats, list) else []:
        if not isinstance(m, dict):
            continue
        mid = str(m.get("material_id") or "?")
        loc = str(m.get("path_or_link") or "")
        digest = str(m.get("sha256") or "")
        st = str(m.get("status") or "?")
        # A LOCATION IS SOMETHING THAT RESOLVES, not a string that is non-empty. The first version
        # compared `== "TBD"` and passed prostate's `path_or_link`, which reads
        # "TBD — the approved 202606 Panoramic program-specification workbook (Excel): …": a
        # description of the document somebody INTENDS to register, reported as a location. A
        # placeholder with an explanation after it is still a placeholder, and the explanation is
        # exactly what makes it read like a real answer.
        placeholder = pg.unstated(loc) or loc.strip().upper().startswith("TBD")
        looks_local = "://" not in loc and (loc.startswith("products/") or os.sep in loc)
        if placeholder:
            rows.append((NO, f"  {mid} location",
                         f"path_or_link is a placeholder ({loc[:60]}…) — the registration points at "
                         f"nothing. Re-run source_refs_init.py with --path-or-link"))
        elif looks_local and not os.path.exists(os.path.join(REPO, loc)):
            rows.append((NO, f"  {mid} location",
                         f"{loc} does not exist — the registration names a file that is not here"))
        else:
            rows.append((OK, f"  {mid} location", loc))
        rows.append((OK if digest else NO, f"  {mid} digest",
                     f"{digest[:16]}…" if digest else
                     "no sha256 — run source_manifest.py --record-digest, or the registration "
                     "names a filename rather than its content"))
        rows.append((OK if st == "reviewed" else UNKNOWN, f"  {mid} status",
                     st if st == "reviewed" else
                     f"{st} — a technical pilot can proceed, but everything produced from it stays "
                     f"PROVISIONAL until a person reviews and approves the material"))
    return rows


def _extraction(pack):
    """The SEVEN artifacts, by name. `spec_pipeline/out/` existing is not the question.

    That directory also holds `variables_scaffold/`, which is generated from the master inventory
    and needs no workbook at all. A reader who checked for the directory would see a pack with no
    approved specification reporting an extraction.
    """
    out = os.path.join(REPO, pack, OUT_DIR)
    have = [a for a in ARTIFACTS if os.path.exists(os.path.join(out, a))]
    missing = [a for a in ARTIFACTS if a not in have]
    if not have:
        note = "no extraction has been run"
        if os.path.isdir(out):
            note += (f" — {OUT_DIR}/ exists but holds none of the seven artifacts (it carries "
                     f"inventory-derived scaffolding, which is not an extraction)")
        return [(NO, "extraction", note)]
    if missing:
        return [(NO, "extraction",
                 f"{len(have)}/{len(ARTIFACTS)} artifacts present; MISSING {', '.join(missing)}. A "
                 f"partial extraction is not a traceable one — re-run run_spec_pipeline.py")]
    return [(OK, "extraction", f"all {len(ARTIFACTS)} artifacts present"),
            (UNKNOWN, "  extraction current",
             "not verified here — run `run_spec_pipeline.py <pack> --check`, which regenerates into "
             "a temp directory and byte-compares. It is the only thing that proves these files "
             "still match the workbook, and it is too slow to run from a status report")]


def _bindings(pack):
    """Are the per-run bindings still placeholders? Keys from `placeholders.RUNTIME_BINDINGS`."""
    sys.path.insert(0, TOOLS)
    import product_gates as pg                                           # noqa: PLC0415
    path = os.path.join(REPO, pack, "config", "pipeline.yaml")
    if not os.path.exists(path):
        return [(UNKNOWN, "runtime bindings", "no config/pipeline.yaml")]
    doc, err = pg.read_yaml(path)
    if err:
        return [(NO, "runtime bindings", f"config/pipeline.yaml does not parse: {err}")]
    run = ((doc or {}).get("run") or {}) if isinstance((doc or {}).get("run"), dict) else {}
    unset = [k for k in RUNTIME_BINDINGS if pg.unstated(run.get(k))]
    if unset:
        return [(NO, "runtime bindings",
                 f"{', '.join(unset)} still unset — supply them on the command line "
                 f"(--var …), never by committing a value. This pack cannot read real data as-is")]
    return [(OK, "runtime bindings", ", ".join(f"{k}={run.get(k)}" for k in RUNTIME_BINDINGS))]


def _smoke(pack):
    """Deliberately UNKNOWN, and the reason is the point.

    `local_smoke.py --evidence-out` refuses to write inside the checkout, so its evidence is
    somewhere this report cannot see by construction. Reporting `NO` would be a false negative on
    every machine that has run it; reporting `ok` would be a claim about something unobserved. The
    honest third answer is the one that keeps the other two meaning what they say.
    """
    return [(UNKNOWN, "synthetic smoke",
             "not visible from inside the checkout — local_smoke.py writes its evidence OUTSIDE it "
             "on purpose. Run `local_smoke.py <pack> --evidence-out <dir>` and read that file")]


def _gates(pack):
    """Through `status.results`, the owner of gate state. EVERY blocker, verbatim.

    The first version showed `blockers[0]`. Gate 6 carries three, so two thirds of the reasons a
    release was blocked did not appear — and a reader who cleared the one shown would come back to
    a gate that had not moved. Re-wording them is the other half of the same mistake: two tools
    describing one condition differently, and the friendlier wording is the one that gets quoted.
    """
    rows = []
    for r in status_tool.results(REPO, pack):
        st = str(r.get("status") or "?")
        blockers = [str(b) for b in (r.get("blockers") or [])]
        rows.append((OK if st == "passed" else NO, f"gate {r.get('gate')} {r.get('name')}",
                     st if not blockers else f"{st} — {blockers[0]}"))
        for extra in blockers[1:]:
            rows.append((NO, "", extra))
    return rows


def report(pack, out_dir=None):
    """[(section, [(state, subject, detail)])] — everything, in the order it blocks."""
    return [("ENVIRONMENT — can this machine run it", _environment(out_dir)),
            ("SOURCE REGISTRATION — is there an approved workbook", _registration(pack)),
            ("EXTRACTION — is there a traceable specification", _extraction(pack)),
            ("RUNTIME BINDINGS — can it be pointed at data", _bindings(pack)),
            ("EXECUTION EVIDENCE — has it been run", _smoke(pack)),
            ("GATES — what the framework says", _gates(pack))]


def render(pack, out_dir=None):
    secs = report(pack, out_dir)
    blocked = [(s, subj, d) for _t, rows in secs for s, subj, d in rows if s == NO]
    unknown = [(s, subj, d) for _t, rows in secs for s, subj, d in rows if s == UNKNOWN]
    L = ["=" * 96,
         f"  PILOT READINESS — {pack}",
         "=" * 96,
         "  Read-only. Nothing here approves anything, and a green line means the precondition",
         "  holds — never that you may proceed. The gates decide that.",
         ""]
    for title, rows in secs:
        L.append(f"  {title}")
        L.append("  " + "-" * 92)
        for state, subject, detail in rows:
            L.append(f"   {MARK[state]} {subject:34} {detail}")
        L.append("")
    L += ["  " + "-" * 92, "  WHAT THIS ADDS UP TO", "  " + "-" * 92]
    if blocked:
        L.append(f"  {len(blocked)} blocking condition(s). In order:")
        for _s, subject, detail in blocked:
            # A continuation row (a gate's second and third blocker) carries no subject of its own.
            L.append(f"      {subject}: {detail}" if subject else f"        {detail}")
    else:
        L.append("  No blocking condition this report can see.")
    if unknown:
        L.append(f"  {len(unknown)} thing(s) this report CANNOT see. They are not passes:")
        for _s, subject, _d in unknown:
            L.append(f"      {subject}")
    L += ["",
          "  WHAT MUST NOT BE RUN from a pilot, whatever the lines above say: any publish or",
          "  promotion job, and any run whose output schema is shared or public. A pilot writes to a",
          "  scratch schema it owns, or it is not a pilot."]
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("product", help="path to a product pack")
    ap.add_argument("--out-dir", help="where restricted output would go (passed to doctor)")
    ap.add_argument("--json", action="store_true",
                    help="machine-readable, to STDOUT and no file — a report carrying today's "
                         "state cannot be byte-compared, so a written one would rot into a claim")
    a = ap.parse_args(argv)
    pack = repo_relative(os.path.abspath(a.product), REPO)
    if not os.path.isdir(os.path.join(REPO, pack)):
        sys.exit(f"{a.product}: not a product pack directory")
    if a.json:
        print(json.dumps({"product": pack,
                          "sections": [{"section": t,
                                        "rows": [{"state": s, "subject": subj, "detail": d}
                                                 for s, subj, d in rows]}
                                       for t, rows in report(pack, a.out_dir)]},
                         indent=2))
        return 0
    print(render(pack, a.out_dir))
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
