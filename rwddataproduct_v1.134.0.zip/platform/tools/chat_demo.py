#!/usr/bin/env python3
"""A chat page over the read-only tools — router by default, end-to-end assistant when keyed.

    python3 platform/tools/chat_demo.py                # serve http://127.0.0.1:8377
    python3 platform/tools/chat_demo.py --once "where do we stand"
    ANTHROPIC_API_KEY=... python3 platform/tools/chat_demo.py     # assistant mode (needs
                                                                  # `pip install anthropic`)

TWO MODES, ONE BOUNDARY. Without a key the page is a ROUTER: a fixed intent table maps a typed
question to one READ-ONLY tool invocation and shows the tool's own output with the command
printed underneath. With ANTHROPIC_API_KEY set (and the `anthropic` package installed) it is
the end-to-end ASSISTANT CHAT_JOURNEY.md anticipated: a Claude model converses freely, but its
ONLY reach into this repository is the same six read-only tools the router exposes — the model
holds no shell, no filesystem, no write path, and every command it triggers is printed under
its reply so the audience can see the front end is not the source. The permission boundary the
second-harness warning demands is therefore structural and small: six argv arrays, validated
here, all read-only.

In BOTH modes anything shaped like an approval, an answer, or a ruling gets the standing
refusal before any model is consulted: those are committed file edits by named people, and no
chat surface performs them.

Demo-safe by construction: binds 127.0.0.1 only; user text never reaches a shell (argv arrays,
no shell=True); the counts tool is pinned to --synthetic (a web page must never point the
exploration lane at a real frame); the page itself lives in this string, so no *.html is ever
committed (repo_hygiene refuses those on purpose).
"""
import argparse
import glob
import json
import os
import re
import subprocess
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

from spec_extract import repo_relative                                      # noqa: E402

REFUSAL = ("This surface reads; it never records. Approvals, decision answers, source verdicts "
           "and naming rulings are committed file edits by a NAMED PERSON — the forms in "
           "handoff/decision_answers/, the approval YAMLs, governance/NAMING_RULINGS.yaml. The "
           "chat's job is to make that human act tiny and exactly located, not to perform it.")
REFUSE_RE = re.compile(r"\b(approve[ds]?|sign(?:\s|-)?off|sign\b|record (the )?(answer|decision|"
                       r"ruling|verdict)|the answer is|mark .{0,20}(resolved|approved|passed)|"
                       r"set .{0,20}status)\b", re.I)


def packs():
    """[(slug, repo-relative pack)] — the LATEST version of every real pack; the template and
    superseded cuts stay out (an older cut answering a demo question would be its own bug)."""
    latest = {}
    for p in sorted(glob.glob(os.path.join(ROOT, "products", "oncology", "*", "*",
                                           "config", "data_product.yaml"))):
        d = os.path.dirname(os.path.dirname(p))
        slug, version = os.path.basename(os.path.dirname(d)), os.path.basename(d)
        if version != "YYYYMM" and version >= latest.get(slug, ("", ""))[0]:
            latest[slug] = (version, repo_relative(d, ROOT))
    return [(s, pv[1]) for s, pv in sorted(latest.items())]


def _pack_for(text):
    found = [(s, p) for s, p in packs() if re.search(rf"\b{re.escape(s)}\b", text, re.I)]
    if found:
        return found[0][1]
    default = [p for s, p in packs() if s == "prostate"] or [p for _s, p in packs()]
    return default[0] if default else None


# The intent table IS the product surface: one row per question the demo answers, each mapping
# to exactly one read-only invocation. Order matters — first match wins.
def _routes(text):
    pack = _pack_for(text)
    up = re.findall(r"\b[A-Z][A-Z0-9_]{2,}\b", text)
    by = re.search(r"\bby\s+([a-z][a-z0-9_]*)\b", text)
    return (
        (r"receipt|where did .*(number|value|come)|provenance",
         "the receipt — one variable's whole chain",
         ["receipt.py", pack, "--variable", up[0] if up else "FUDUR"]),
        (r"leverage|executive|portfolio|steering|one page|signature",
         "the leverage table — what one signature buys", ["executive_page.py", "--json"]),
        (r"what do you need|questions|ask (rwb|rwp)|decision",
         "open decisions ranked by blast radius", ["decision_report.py", pack]),
        (r"where do(es)? .*stand|status|blocking|gates",
         "the six gates, and who acts next", ["status.py"] + ([pack] if pack and re.search(
             r"\b(" + "|".join(re.escape(s) for s, _p in packs()) + r")\b", text, re.I)
             else [])),
        (r"already exist|variable .*called|naming|agegrp",
         "the cross-pack naming registry and its open docket", ["naming_registry.py"]),
        (r"semantic|equivalen|pool|conceptual layer",
         "the semantic view — variables, implementations, ruled pooling",
         ["semantic_view.py", pack]),
        (r"big enough|feasib|count|how many",
         "the exploration lane, on a SYNTHETIC frame (the shape, never facts)",
         ["quick_counts.py", pack, "--synthetic", "60",
          "--by", by.group(1) if by else "cohort"]),
    )


def route(text):
    """(title, argv) for the matched intent; (None, None) refusal; ("menu", None) no match."""
    if REFUSE_RE.search(text):
        return None, None
    for pattern, title, argv in _routes(text):
        if re.search(pattern, text, re.I):
            return title, [a for a in argv if a]
    return "menu", None


def _menu():
    lines = ["I answer these (each runs one read-only tool and shows you the command):", ""]
    for _p, title, argv in _routes("prostate"):
        lines.append(f"  · {title}   —  {argv[0]}")
    lines += ["", "Say a pack name (prostate, oc, mcrc) to aim at it; uppercase a variable id "
              "for its receipt (e.g. \"receipt for FUDUR\").", "", REFUSAL]
    return "\n".join(lines)


def _leverage_text(raw):
    f = json.loads(raw)
    L = []
    for p in f["packs"]:
        states = " · ".join(f"G{g['n']} {g['state']}" for g in p["gates"])
        L += [f"{p['name']} ({p['slug']} {p['version']}): {states}",
              f"    {p['decisions_open']} open decision(s) · next: {p['next']['who']}", ""]
    L.append("Leverage — records one answer unblocks:")
    for r in f["leverage"][:8]:
        L.append(f"    {r['decision']:<24} {r['pack']:<10} {r['owner']:<12} {r['unblocks']}")
    L.append("\nFull page: python3 platform/tools/executive_page.py --out ~/exec.html")
    return "\n".join(L)


def answer(text):
    """{you, title, ran, out} — the tool's own words, with the command that produced them."""
    title, argv = route(text)
    if title is None:
        return {"you": text, "title": "refused", "ran": "(nothing — by design)", "out": REFUSAL}
    if argv is None:
        return {"you": text, "title": "what this demo answers", "ran": "(menu)", "out": _menu()}
    return {"you": text, "title": title,
            "ran": "python3 platform/tools/" + " ".join(argv), "out": _run_argv(argv)}


# ---------------------------------------------------------------- assistant mode (end to end)
DEFAULT_MODEL = "claude-opus-5"
MAX_TURNS = 6                       # tool-use loop cap per question — a runaway loop backstop
_OUT_CAP = 12000                    # chars of tool output the model sees per call

# The model's ENTIRE reach into this repository. Adding a tool here is a boundary decision:
# read-only argv arrays only, every argument validated below, never a write flag.
ASSISTANT_TOOLS = (
    {"name": "product_status",
     "description": "Where a product stands: the six gates, blockers, and who acts next. "
                    "Omit slug for the one-line portfolio view.",
     "input_schema": {"type": "object", "properties": {
         "slug": {"type": "string", "description": "pack slug, e.g. prostate, oc, mcrc"}},
         "additionalProperties": False}},
    {"name": "variable_receipt",
     "description": "One output variable's whole provenance: spec words, contract record, "
                    "decisions (quoted from the register), config refs, name, build. Refuses "
                    "unknown variable_ids by listing the real ones.",
     "input_schema": {"type": "object", "properties": {
         "slug": {"type": "string"},
         "variable_id": {"type": "string", "description": "e.g. FUDUR, MININDEX"}},
         "required": ["slug", "variable_id"], "additionalProperties": False}},
    {"name": "open_decisions",
     "description": "The pack's open decisions ranked by blast radius — what each answer "
                    "unblocks, and who owes it.",
     "input_schema": {"type": "object", "properties": {"slug": {"type": "string"}},
                      "required": ["slug"], "additionalProperties": False}},
    {"name": "naming_registry",
     "description": "The cross-pack variable-name registry and its open docket: every name, "
                    "where it lives, near-miss pairs awaiting a human ruling, format conflicts.",
     "input_schema": {"type": "object", "properties": {}, "additionalProperties": False}},
    {"name": "synthetic_counts",
     "description": "The exploration lane on a SYNTHETIC frame — demonstrates the counts-only "
                    "shape and the assumption-refusal; never real data.",
     "input_schema": {"type": "object", "properties": {
         "slug": {"type": "string"},
         "by": {"type": "string", "description": "column to group by, e.g. cohort"}},
         "required": ["slug", "by"], "additionalProperties": False}},
    {"name": "portfolio_leverage",
     "description": "Every pack's six gates plus the leverage table: which open decisions "
                    "unblock the most contract records.",
     "input_schema": {"type": "object", "properties": {}, "additionalProperties": False}},
)

SYSTEM_PROMPT = (
    "You are the chat front end over a governed real-world-data product platform. Your ONLY "
    "source of facts is the read-only tools; call them rather than recalling, quote their "
    "numbers exactly, and never state a count, status, or date they did not print. The "
    "commands you run are shown to the user under your reply, so your text should interpret "
    "and summarise, not restate output verbatim at length.\n\n"
    "Hard rules, none negotiable:\n"
    "- You cannot approve, answer a decision, rule on naming, or change any status. If asked, "
    "refuse with: approvals, decision answers and rulings are committed file edits by a NAMED "
    "PERSON (the forms in handoff/decision_answers/, governance/NAMING_RULINGS.yaml); your "
    "job is to point at the exact file, never to type the values.\n"
    "- Never present a flagged pair, a proposed mapping, or a gate blocker as decided — those "
    "are questions for humans, and you say whose.\n"
    "- All tool output is counts and governed metadata; there is no patient-level data on "
    "this surface, and you never speculate about individuals.\n"
    "- Keep replies short and plain. If a question is outside the six tools, say what this "
    "surface can answer instead of guessing."
)


def _slug_pack(inp):
    named = {s: p for s, p in packs()}
    slug = inp.get("slug") or "prostate"
    if slug not in named:
        raise ValueError(f"unknown pack slug {slug!r} — real packs: {', '.join(sorted(named))}")
    return named[slug]


def _tool_argv(name, inp):
    """The validated argv for one assistant tool call — or ValueError, returned to the model
    as an error result. The allowlist IS this function: no other shape reaches a subprocess."""
    if name == "product_status":
        return ["status.py"] + ([_slug_pack(inp)] if inp.get("slug") else [])
    if name == "variable_receipt":
        vid = str(inp.get("variable_id") or "")
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{1,40}", vid):
            raise ValueError(f"variable_id {vid!r} is not a bare identifier")
        return ["receipt.py", _slug_pack(inp), "--variable", vid.upper()]
    if name == "open_decisions":
        return ["decision_report.py", _slug_pack(inp)]
    if name == "naming_registry":
        return ["naming_registry.py"]
    if name == "synthetic_counts":
        by = str(inp.get("by") or "")
        if not re.fullmatch(r"[a-z][a-z0-9_]{0,40}", by):
            raise ValueError(f"by {by!r} is not a bare lowercase column name")
        return ["quick_counts.py", _slug_pack(inp), "--synthetic", "60", "--by", by]
    if name == "portfolio_leverage":
        return ["executive_page.py", "--json"]
    raise ValueError(f"no such tool {name!r}")


def _run_argv(argv):
    r = subprocess.run([sys.executable, os.path.join(TOOLS, argv[0])] + argv[1:],
                       capture_output=True, encoding="utf-8", cwd=ROOT, timeout=300)
    out = (r.stdout + r.stderr).strip() or f"(exit {r.returncode}, no output)"
    if argv[0] == "executive_page.py" and r.returncode == 0:
        out = _leverage_text(r.stdout)
    if r.returncode != 0:
        # a structured failure state, so a refusal is never presented as an ordinary answer
        out = f"[TOOL EXITED {r.returncode} — the text below is a refusal or error]\n{out}"
    if len(out) > _OUT_CAP:
        out = out[:_OUT_CAP] + f"\n... [truncated at {_OUT_CAP} chars — run the command "
        out += "yourself for the rest]"
    return out


def assistant_ready():
    if not os.environ.get("ANTHROPIC_API_KEY"):
        return False
    try:
        import anthropic                              # noqa: F401,PLC0415 — optional, demo-only
        return True
    except ImportError:
        return False


# ------------------------------------------------ the KEYLESS backend: the claude CLI itself
# Anywhere Claude Code is installed and logged in, `claude -p` answers on the user's existing
# seat — no key is ever provisioned, and the tool allowlist is enforced by Claude Code's OWN
# permission engine (the first harness), not re-implemented here. The six read-only operations
# are served to the child session as REAL TYPED MCP TOOLS (--mcp-serve below), which is the
# durable form of the boundary: the child holds NO Bash, NO shell, and no prefix-
# shaped allow rule — there is no command string for a suffix to ride on. The BOUNDARY:
#   * the only allowed tools are mcp__rwdp__* — each call arrives as typed JSON and funnels
#     through the same validated `_tool_argv` allowlist the API backend uses;
#   * Bash, Read, Grep, Glob, WebFetch and WebSearch are disallowed outright, and the child
#     runs in an empty throwaway sandbox directory besides;
#   * any tool_use OUTSIDE mcp__rwdp__* is FLAGGED in the reply, never silently absorbed;
#   * the child still inherits this process's environment — run the demo in a shell holding
#     no cloud or API credentials (the startup caveat says so).
MCP_SERVER_NAME = "rwdp"
CLI_DISALLOWED = "Bash,Read,Grep,Glob,WebFetch,WebSearch"
CLI_TOOL_HELP = (
    f"You have EXACTLY six tools (the `{MCP_SERVER_NAME}` server), all read-only:\n"
    + "\n".join(f"  {t['name']}: {t['description']}" for t in ASSISTANT_TOOLS)
    + "\nNo shell, no file access, no web. Nothing else is approved.")


def mcp_serve():
    """The six tools as a minimal MCP stdio server: newline-delimited JSON-RPC, three methods.
    Typed inputs in, text out — every call still crosses `_tool_argv`, the one allowlist."""
    import io                                         # noqa: PLC0415
    stdin = io.TextIOWrapper(sys.stdin.buffer, encoding="utf-8")
    stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", line_buffering=True)

    def send(obj):
        stdout.write(json.dumps(obj) + "\n")

    for line in stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except ValueError:
            continue
        rid, method = req.get("id"), req.get("method")
        if method == "initialize":
            send({"jsonrpc": "2.0", "id": rid, "result": {
                "protocolVersion": (req.get("params") or {}).get("protocolVersion",
                                                                 "2024-11-05"),
                "capabilities": {"tools": {}},
                "serverInfo": {"name": MCP_SERVER_NAME, "version": "1.0"}}})
        elif method == "tools/list":
            send({"jsonrpc": "2.0", "id": rid, "result": {"tools": [
                {"name": t["name"], "description": t["description"],
                 "inputSchema": t["input_schema"]} for t in ASSISTANT_TOOLS]}})
        elif method == "tools/call":
            p = req.get("params") or {}
            try:
                text = _run_argv(_tool_argv(p.get("name"), p.get("arguments") or {}))
                err = False
            except (ValueError, subprocess.TimeoutExpired) as e:
                text, err = str(e), True
            send({"jsonrpc": "2.0", "id": rid,
                  "result": {"content": [{"type": "text", "text": text}], "isError": err}})
        elif rid is not None:
            send({"jsonrpc": "2.0", "id": rid,
                  "error": {"code": -32601, "message": f"no such method {method!r}"}})
    # detach so the underlying buffers outlive these wrappers (the wrapper's GC would close
    # them — harmless on real stdio at process exit, fatal to a test reading its BytesIO back)
    stdout.flush()
    stdin.detach()
    stdout.detach()
    return 0


def cli_ready():
    import shutil                                     # noqa: PLC0415
    return shutil.which("claude") is not None


def tool_entry(name, input_json):
    """The --tool entry point the CLI backend's model is allowed to call. Same allowlist, same
    validation, same refusals as the API backend — one boundary, two front ends."""
    argv = _tool_argv(name, json.loads(input_json or "{}"))
    print(_run_argv(argv))
    return 0


def cli_answer(text, history, model=None):
    """The keyless end-to-end turn: `claude -p` converses on the operator's own seat; its only
    reach is the --tool entry point; the commands it ran are read back from the stream."""
    import tempfile                                   # noqa: PLC0415
    transcript = "".join(f"[{m.get('role')}] {str(m.get('content'))[:2000]}\n"
                         for m in (history or [])[-12:]
                         if m.get("role") in ("user", "assistant"))
    prompt = (f"Conversation so far:\n{transcript}\n[user] {text}" if transcript else text)
    with tempfile.TemporaryDirectory(prefix="chat_demo_sandbox_") as sandbox:
        mcp_cfg = os.path.join(sandbox, "mcp.json")
        with open(mcp_cfg, "w", encoding="utf-8") as fh:
            json.dump({"mcpServers": {MCP_SERVER_NAME: {
                "command": sys.executable,
                "args": [os.path.join(TOOLS, "chat_demo.py"), "--mcp-serve"]}}}, fh)
        argv = ["claude", "-p", prompt, "--output-format", "stream-json", "--verbose",
                "--mcp-config", mcp_cfg, "--strict-mcp-config",
                "--allowedTools", f"mcp__{MCP_SERVER_NAME}__*",
                "--disallowedTools", CLI_DISALLOWED,
                "--append-system-prompt", SYSTEM_PROMPT + "\n\n" + CLI_TOOL_HELP]
        if model:
            argv += ["--model", model]
        r = subprocess.run(argv, capture_output=True, encoding="utf-8", cwd=sandbox,
                           timeout=600)
    ran, offshape, out = [], [], ""
    for line in (r.stdout or "").splitlines():
        try:
            e = json.loads(line)
        except ValueError:
            continue
        if e.get("type") == "assistant":
            for b in (e.get("message") or {}).get("content") or []:
                if b.get("type") != "tool_use":
                    continue
                # EVERY tool use is recorded, whatever its name — an invisible tool call is
                # exactly the honesty failure this display exists to prevent
                name = str(b.get("name") or "")
                label = (f"{name.split('__')[-1]}({json.dumps(b.get('input') or {})})"
                         if name.startswith(f"mcp__{MCP_SERVER_NAME}__") else f"[{name}]")
                ran.append(label)
                # ToolSearch is the harness's OWN loader for deferred MCP tool schemas —
                # read-only machinery with no reach, not a boundary crossing
                if not name.startswith(f"mcp__{MCP_SERVER_NAME}__") and name != "ToolSearch":
                    offshape.append(label)
        elif e.get("type") == "result":
            out = str(e.get("result") or "")
    if not out:
        out = (r.stderr or "").strip() or f"(claude CLI exit {r.returncode}, no result)"
    if offshape:
        out += ("\n\nBOUNDARY NOTE — the session invoked something outside the expected "
                "command shape (shown above). Treat this reply with suspicion and report it: "
                + " ; ".join(offshape))
    return {"you": text, "title": "assistant (claude CLI — no key)",
            "ran": " ; ".join(ran) or "(no tool needed)", "out": out}


def llm_answer(text, history, model=None):
    """The end-to-end turn: Claude converses; its only reach is the six read-only tools; every
    command it triggered is returned for display under the reply."""
    import anthropic                                  # noqa: PLC0415 — optional, demo-only
    client = anthropic.Anthropic()
    model = model or DEFAULT_MODEL
    msgs = [{"role": m.get("role"), "content": str(m.get("content"))[:4000]}
            for m in (history or [])[-20:] if m.get("role") in ("user", "assistant")]
    msgs.append({"role": "user", "content": text})
    ran = []
    for _ in range(MAX_TURNS):
        resp = client.messages.create(model=model, max_tokens=16000, system=SYSTEM_PROMPT,
                                      tools=list(ASSISTANT_TOOLS), messages=msgs)
        if resp.stop_reason == "refusal":
            return {"you": text, "title": "assistant (declined)", "ran": "(model refusal)",
                    "out": "The model declined this request."}
        calls = [b for b in resp.content if b.type == "tool_use"]
        if not calls:
            out = "\n".join(b.text for b in resp.content if b.type == "text").strip()
            return {"you": text, "title": "assistant", "out": out or "(no text)",
                    "ran": " ; ".join("python3 platform/tools/" + " ".join(a) for a in ran)
                           or "(no tool needed)"}
        msgs.append({"role": "assistant", "content": resp.content})
        results = []
        for c in calls:
            try:
                argv = _tool_argv(c.name, dict(c.input))
                ran.append(argv)
                results.append({"type": "tool_result", "tool_use_id": c.id,
                                "content": _run_argv(argv)})
            except (ValueError, subprocess.TimeoutExpired) as e:
                results.append({"type": "tool_result", "tool_use_id": c.id,
                                "content": f"{e}", "is_error": True})
        msgs.append({"role": "user", "content": results})
    return {"you": text, "title": "assistant (stopped)", "out":
            f"Stopped after {MAX_TURNS} tool rounds — ask a narrower question.",
            "ran": " ; ".join("python3 platform/tools/" + " ".join(a) for a in ran)}


PAGE = """<!doctype html><meta charset="utf-8">
<title>RWD data products — ask the governed layer</title>
<style>
:root{--bg:#fbfaf8;--ink:#22211f;--mut:#6d6a63;--line:#e2ded6;--me:#1f4e6e;--card:#ffffff}
@media (prefers-color-scheme: dark){:root{--bg:#191816;--ink:#e8e5df;--mut:#a09c93;
--line:#37342f;--me:#7fb3d5;--card:#211f1c}}
body{background:var(--bg);color:var(--ink);font:15px/1.5 system-ui,sans-serif;margin:0;
display:flex;flex-direction:column;height:100vh}
header{padding:.9rem 1.25rem;border-bottom:1px solid var(--line)}
header b{font-size:1.05rem}header p{margin:.2rem 0 0;color:var(--mut);font-size:.82rem}
#log{flex:1;overflow-y:auto;padding:1rem 1.25rem;display:flex;flex-direction:column;gap:.8rem}
.me{align-self:flex-end;background:var(--me);color:#fff;border-radius:12px 12px 2px 12px;
padding:.5rem .9rem;max-width:70%}
.bot{align-self:flex-start;background:var(--card);border:1px solid var(--line);
border-radius:12px 12px 12px 2px;padding:.7rem .9rem;max-width:92%}
.bot .t{font-weight:600;margin:0 0 .35rem}
.bot pre{margin:0;white-space:pre-wrap;overflow-x:auto;font:12.5px/1.45 ui-monospace,monospace}
.bot .ran{color:var(--mut);font-size:.75rem;margin:.5rem 0 0;font-family:ui-monospace,monospace}
#chips{padding:.4rem 1.25rem;display:flex;gap:.4rem;flex-wrap:wrap;border-top:1px solid var(--line)}
#chips button{background:var(--card);color:var(--ink);border:1px solid var(--line);
border-radius:999px;padding:.3rem .8rem;font-size:.8rem;cursor:pointer}
form{display:flex;gap:.5rem;padding:.7rem 1.25rem 1rem}
input{flex:1;background:var(--card);color:var(--ink);border:1px solid var(--line);
border-radius:8px;padding:.55rem .8rem;font-size:.95rem}
form button{background:var(--me);color:#fff;border:0;border-radius:8px;padding:.55rem 1.1rem;
cursor:pointer}
</style>
<header><b>Ask the governed layer</b>
<p>__MODE__ Every fact comes from a read-only tool, with the command printed under the reply.
This surface reads; it never records — approvals stay committed file edits by named people.</p>
</header>
<div id="log"></div>
<div id="chips"></div>
<form id="f"><input id="q" placeholder="e.g. where does prostate stand" autocomplete="off">
<button>Ask</button></form>
<script>
const CHIPS=["where does prostate stand","what do you need from me","receipt for FUDUR",
"what one signature buys","does agegrp already exist","is the C2 cohort big enough by cohort"];
const log=document.getElementById("log"),f=document.getElementById("f"),
q=document.getElementById("q"),chips=document.getElementById("chips");
CHIPS.forEach(c=>{const b=document.createElement("button");b.textContent=c;
b.onclick=()=>{q.value=c;f.requestSubmit();};chips.appendChild(b);});
function bubble(cls,html){const d=document.createElement("div");d.className=cls;
d.append(...html);log.appendChild(d);log.scrollTop=log.scrollHeight;return d;}
const hist=[];
f.onsubmit=async e=>{e.preventDefault();const text=q.value.trim();if(!text)return;q.value="";
const m=document.createElement("span");m.textContent=text;bubble("me",[m]);
const wait=document.createElement("pre");wait.textContent="running…";
const wb=bubble("bot",[wait]);
const r=await fetch("/ask",{method:"POST",body:JSON.stringify({q:text,history:hist})});
const a=await r.json();wb.remove();
hist.push({role:"user",content:text},{role:"assistant",content:a.out});
const t=document.createElement("p");t.className="t";t.textContent=a.title;
const pre=document.createElement("pre");pre.textContent=a.out;
const ran=document.createElement("p");ran.className="ran";ran.textContent="$ "+a.ran;
bubble("bot",[t,pre,ran]);};
</script>"""


class _Handler(BaseHTTPRequestHandler):
    backend = "router"                             # set by main() after the readiness checks
    model = None

    def log_message(self, *a):                     # keep the demo terminal quiet
        pass

    def _send(self, body, ctype):
        data = body.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        mode = {
            "api": f"ASSISTANT MODE (API, {self.model or DEFAULT_MODEL}) — Claude converses; "
                   f"its only reach is six read-only tools.",
            "cli": "ASSISTANT MODE (claude CLI, no key) — Claude Code answers on your own "
                   "seat; its only reach is six read-only tools.",
            "router": "ROUTER MODE (no model) — fixed intents; log in to Claude Code (or set "
                      "ANTHROPIC_API_KEY) for the conversational assistant.",
        }[self.backend]
        self._send(PAGE.replace("__MODE__", mode), "text/html")

    def _foreign(self):
        """True when the request did not come from this page: a browser on any OTHER site can
        fire a no-preflight POST at 127.0.0.1 and, in assistant mode, drive the operator's own
        seat with an attacker-chosen prompt. The Host header pins DNS-rebinding; the Origin
        header, when a browser sends one, must be this server itself (curl sends none)."""
        port = self.server.server_port
        ok_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
        if (self.headers.get("Host") or "") not in ok_hosts:
            return True
        origin = self.headers.get("Origin")
        return bool(origin) and origin not in {f"http://{h}" for h in ok_hosts}

    def do_POST(self):
        text = ""
        try:
            if self._foreign():
                self.send_response(403)
                self.end_headers()
                return
            n = int(self.headers.get("Content-Length") or 0)
            if n > 65536:
                self.send_response(413)
                self.end_headers()
                return
            body = json.loads(self.rfile.read(n) or b"{}")
            if not isinstance(body, dict):
                body = {}
            text = str(body.get("q") or "")[:500]
            # the standing refusal outranks EVERY backend — approval-shaped text never reaches
            # a model, exactly as it never reaches a tool
            if self.backend != "router" and route(text) != (None, None):
                fn = llm_answer if self.backend == "api" else cli_answer
                self._send(json.dumps(fn(text, body.get("history"), self.model)),
                           "application/json")
            else:
                self._send(json.dumps(answer(text)), "application/json")
        except Exception as e:                     # noqa: BLE001 — the page reports, it never dies
            self._send(json.dumps({"you": text, "title": "error", "ran": "(failed)",
                                   "out": f"{type(e).__name__}: {e}"}), "application/json")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--once", help="answer one question on stdout via the ROUTER, no server")
    ap.add_argument("--ask", help="answer one question via the ASSISTANT backend")
    ap.add_argument("--backend", choices=("auto", "api", "cli", "router"), default="auto",
                    help="auto = API key if present, else the claude CLI, else the router")
    ap.add_argument("--model", help=f"assistant model override (API default {DEFAULT_MODEL}; "
                                    f"CLI default = your Claude Code default)")
    ap.add_argument("--tool", help="(internal) run one allowlisted read-only tool by name")
    ap.add_argument("--input", default="{}", help="(internal) JSON input for --tool")
    ap.add_argument("--mcp-serve", action="store_true",
                    help="(internal) serve the six read-only tools as typed MCP tools over "
                         "stdio — what the cli backend's child session connects to")
    ap.add_argument("--port", type=int, default=8377)
    a = ap.parse_args(argv)
    if a.mcp_serve:
        return mcp_serve()
    if a.tool:
        return tool_entry(a.tool, a.input)
    backend = a.backend
    if backend == "auto":
        # cli is NEVER auto-selected: its Bash allow rule is prefix-shaped and the child
        # inherits the environment, so it is an explicit, eyes-open choice.
        backend = "api" if assistant_ready() else "router"
    elif backend == "api" and not assistant_ready():
        sys.exit("the api backend needs ANTHROPIC_API_KEY set and `pip install anthropic`")
    elif backend == "cli" and not cli_ready():
        sys.exit("the cli backend needs the `claude` CLI on PATH, logged in")
    if backend == "cli":
        print("cli backend: the child session holds six typed MCP tools and NO shell — but it "
              "inherits this environment, so run the demo in a shell holding no cloud, "
              "GitHub, Databricks, or API credentials.")
    if a.once:
        r = answer(a.once)
        print(f"[{r['title']}]  $ {r['ran']}\n\n{r['out']}")
        return 0
    if a.ask:
        if backend == "router" or route(a.ask) == (None, None):
            r = answer(a.ask)
        else:
            r = (llm_answer if backend == "api" else cli_answer)(a.ask, [], a.model)
        print(f"[{r['title']}]  $ {r['ran']}\n\n{r['out']}")
        return 0
    _Handler.backend = backend
    _Handler.model = a.model
    srv = ThreadingHTTPServer(("127.0.0.1", a.port), _Handler)
    label = {"api": f"ASSISTANT/API ({a.model or DEFAULT_MODEL})",
             "cli": "ASSISTANT/claude CLI (no key)",
             "router": "ROUTER (fixed intents)"}[backend]
    print(f"demo chat on http://127.0.0.1:{a.port}  ·  {label}  (Ctrl-C stops; localhost only)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
