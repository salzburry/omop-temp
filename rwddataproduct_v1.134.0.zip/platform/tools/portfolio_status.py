#!/usr/bin/env python3
"""Where every product in the portfolio actually stands — rendered, never typed.

    python3 platform/tools/portfolio_status.py            # validate + write products/PORTFOLIO.md
    python3 platform/tools/portfolio_status.py --check     # validate + byte-compare, exit 1 on drift

WHY THIS EXISTS. The root README carried a hand-typed portfolio table under the sentence "Status
mirrors products/registry.yaml (test-enforced)". No test enforced it, and six of its eight rows said
`planned` for products the registry had moved to `scaffold`. A status table maintained by hand is a
second copy of somebody else's fact, and this one had been wrong long enough that the claim of
enforcement was itself the most misleading line on the page.

WHAT IT DERIVES, AND FROM WHOM. Nothing here is a judgement:

  * `products/registry.yaml` owns the declared status and the current spec version;
  * the FILESYSTEM owns whether a pack exists, and which governed files it carries;
  * `governance/reference/variable_inventory/INVENTORY.yaml` owns whether a tumour has a reference
    overlay at all, and which master families it instantiates;
  * `platform/capabilities.yaml` owns whether each master family has a checked capability at all —
    reported as a DRIFT finding when one does not, never as a per-tumour score.

The DRIFT column is the only thing this tool adds, and it is arithmetic over those four: a declared
status the disk does not support, a spec version with no pack behind it, an overlay for a tumour the
registry does not carry, or a registry tumour with no overlay. Drift is REPORTED, not fixed — the
registry and the shelf are hand-maintained on purpose, and a tool that edited them to agree with
each other would destroy the evidence that they disagreed.

`PLACEHOLDER_VERSION` is what a copied template still carries. A pack at `<slug>/YYYYMM/` is the
template, not a product, and counting it as one is how a portfolio comes to look further along than
it is.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
REPO = TOOLS.parent.parent
PLATFORM = TOOLS.parent
REGISTRY = REPO / "products" / "registry.yaml"
RENDER = REPO / "products" / "PORTFOLIO.md"

PLACEHOLDER_VERSION = "YYYYMM"
DEFAULT_FAMILY = "oncology"
# Governed files that mark how far a pack has been taken. Presence only — each one's CONTENT is
# checked by the tool that owns it (source_manifest, product_gates, contract_lint), and re-reading
# them here would be a second opinion about somebody else's gate.
MILESTONES = (("source_refs.yaml", "sources registered"),
              ("handoff/MATURITY.yaml", "maturity declared"),
              ("handoff/FUNCTIONAL_CONTRACT.md", "contract drafted"))


def _load(path: Path):
    """Through `strict_yaml`, which owns both the duplicate-key refusal AND the utf-8 read."""
    sys.path.insert(0, str(PLATFORM))
    from engine.strict_yaml import strict_load_path                     # noqa: PLC0415
    return strict_load_path(path)


def _overlay_stem(slug: str) -> str:
    sys.path.insert(0, str(TOOLS))
    from variables_scaffold import SLUG_TO_OVERLAY
    return SLUG_TO_OVERLAY.get(slug, slug)


def pack_dir(entry) -> Path:
    fam = entry.get("family") or DEFAULT_FAMILY
    return REPO / "products" / fam / str(entry.get("slug")) / str(entry.get("current_spec_version"))


def facts() -> list:
    """One row per registry tumour, plus one per inventory overlay the registry does not carry."""
    reg = _load(REGISTRY)
    inv = _load(REPO / "governance" / "reference" / "variable_inventory" / "INVENTORY.yaml")
    caps = _load(PLATFORM / "capabilities.yaml")
    answered = {c["master"] for c in caps.get("capabilities") or []}
    overlays = inv.get("tumours") or {}

    # BY COVERAGE CLASS, not by "answerable". The first version counted a family answerable whenever
    # ANY capability named that master, so upstream-required LOT counted as engine reach and a
    # generic RW_RESPONSE capability made the family answerable for a tumour whose per-line response
    # is still an engine gap. Every row read `answerable == families`, which is a column that cannot
    # be wrong and therefore says nothing. Counting VARIABLES by the class the inventory assigns
    # them says what a new tumour actually needs to fund.
    def counts(stem):
        vs = overlays[stem].get("variables") or []
        masters = {v["master"] for v in vs if v.get("master")}
        by_class = {}
        for v in vs:
            c = (v.get("coverage") or {}).get("class") or "?"
            by_class[c] = by_class.get(c, 0) + 1
        return {"families": len(masters),
                "families_with_capability": len(masters & answered),
                "variables": len(vs),
                "native": by_class.get("engine_family", 0),
                "configurable": by_class.get("config_expressible", 0),
                "upstream": by_class.get("upstream_required", 0),
                "gaps": by_class.get("engine_gap", 0)}

    rows, seen_overlays = [], set()
    for entry in reg.get("tumors") or []:
        slug = str(entry.get("slug"))
        stem = _overlay_stem(slug)
        seen_overlays.add(stem)
        d = pack_dir(entry)
        version = str(entry.get("current_spec_version") or "")
        row = {
            "slug": slug,
            "name": entry.get("name") or slug,
            "vendor": entry.get("vendor") or "",
            "status": entry.get("status") or "",
            "version": version,
            "pack_exists": (d / "config" / "data_product.yaml").exists(),
            "placeholder": version == PLACEHOLDER_VERSION,
            "milestones": [label for rel, label in MILESTONES if (d / rel).exists()],
            "overlay": stem if stem in overlays else None,
            "families": 0, "families_with_capability": 0, "variables": 0,
            "native": 0, "configurable": 0, "upstream": 0, "gaps": 0,
            "drift": [],
        }
        if row["overlay"]:
            row.update(counts(stem))
        rows.append(row)

    for stem in sorted(set(overlays) - seen_overlays):
        row = {"slug": stem, "name": stem, "vendor": "", "status": "not in the registry",
               "version": "", "pack_exists": False, "placeholder": False, "milestones": [],
               "overlay": stem,
               "drift": ["a reference overlay exists but no product is registered — the shelf is "
                         "ahead of the portfolio"]}
        row.update(counts(stem))
        rows.append(row)

    for row in rows:
        if row["status"] == "not in the registry":
            continue
        if not row["overlay"]:
            row["drift"].append("registered with no reference overlay — a new pack here starts from "
                                "nothing")
        if row["placeholder"]:
            row["drift"].append(f"spec version is the template placeholder `{PLACEHOLDER_VERSION}`, "
                                f"so the pack on disk is the copied template, not a product")
        elif not row["pack_exists"]:
            row["drift"].append(f"registry names spec version `{row['version']}` and no pack exists "
                                f"at that path")
        if row["status"] == "active" and "maturity declared" not in row["milestones"]:
            row["drift"].append("declared `active` with no handoff/MATURITY.yaml — CI applies gates "
                                "from that claim, so an undeclared pack is not held to them")
    return rows


def render_md(rows) -> str:
    lines = [
        "# Portfolio — declared status, and what is behind it",
        "",
        "**GENERATED by `platform/tools/portfolio_status.py` — do not edit. `--check` refuses a",
        "stale copy.** The root README used to carry this table by hand under the words \"status",
        "mirrors registry.yaml (test-enforced)\"; nothing enforced it, and six rows said `planned`",
        "for products the registry had already moved to `scaffold`.",
        "",
        "`products/registry.yaml` owns **status** and **spec version**. The filesystem owns",
        "**pack** and **milestones**. The variable inventory owns **vars** — the size of that",
        "tumour's reference overlay — and the four coverage classes those variables carry:",
        "**native** (an engine family computes it), **config** (existing config patterns cover it,",
        "no new engine code), **upstream** (the VENDOR must deliver a derived table, or the variable",
        "cannot be produced however the pack is configured) and **gaps** (engine work needed).",
        "**Drift** is the only derived column: it is reported, never repaired.",
        "",
        "| product | vendor | status | spec | pack | milestones | vars | native | config | upstream | gaps |",
        "|---|---|---|---|---|---|---|---|---|---|---|",
    ]
    for r in sorted(rows, key=lambda r: (r["status"] != "active", r["slug"])):
        pack = "yes" if r["pack_exists"] else "—"
        if r["placeholder"]:
            pack = "template"
        ms = ", ".join(r["milestones"]) or "—"
        n = (lambda k: f"{r[k]}" if r["overlay"] else "—")
        lines.append(f"| **{r['name']}** (`{r['slug']}`) | {r['vendor'] or '—'} | {r['status']} | "
                     f"`{r['version'] or '—'}` | {pack} | {ms} | {n('variables')} | "
                     f"{n('native')} | {n('configurable')} | {n('upstream')} | {n('gaps')} |")

    drifting = [r for r in rows if r["drift"]]
    lines += ["", "## Drift", ""]
    if not drifting:
        lines.append("Every declared status is supported by what is on disk.")
    else:
        lines.append("What the registry, the filesystem and the reference shelf disagree about. "
                     "Each line is a fact, not a task — closing one is a decision somebody owns.")
        lines.append("")
        for r in sorted(drifting, key=lambda r: r["slug"]):
            lines.append(f"### {r['name']} (`{r['slug']}`)")
            lines.append("")
            for d in r["drift"]:
                lines.append(f"- {d}")
            lines.append("")
    lines += [
        "## What this table does NOT say",
        "",
        "**These are coverage CLASSES, not readiness.** `native` and `config` say the engine could",
        "produce the variable once a pack is configured — not that any pack is. A tumour with zero",
        "gaps still needs an approved workbook, a registered source, a drafted contract and six",
        "gates. Per-product readiness is `platform/tools/status.py <pack>`, which reads the gates.",
        "",
        "**`upstream` is the column a new tumour should read first.** Those variables cannot be",
        "produced however the pack is configured unless the VENDOR delivers a derived table — it is",
        "a delivery requirement, not engineering work, and it is invisible in a count that reports",
        "engine reach. An earlier version of this table carried an `answerable` column that counted",
        "a family as answered whenever any capability named its master; upstream-required",
        "LINE_OF_THERAPY counted as engine reach, a generic RW_RESPONSE capability answered for a",
        "tumour whose per-line response is still a gap, and every row read `answerable == families`.",
        "A column that cannot come out wrong is a column that says nothing.",
        "",
        "The per-variable detail — which entry falls in which class, and what each gap needs — is in",
        "`governance/reference/variable_inventory/COVERAGE.md`.",
    ]
    return "\n".join(lines).rstrip() + "\n"


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true",
                    help="validate and byte-compare PORTFOLIO.md; exit 1 on drift in the rendering")
    a = ap.parse_args(argv)
    rows = facts()
    want = render_md(rows)
    if a.check:
        have = RENDER.read_text(encoding="utf-8") if RENDER.exists() else None
        if have != want:
            print("DRIFT — PORTFOLIO.md is stale; regenerate with: "
                  "python3 platform/tools/portfolio_status.py")
            return 1
        n = sum(len(r["drift"]) for r in rows)
        print(f"current — {len(rows)} products rendered, {n} drift finding(s) reported")
        return 0
    RENDER.write_text(want, encoding="utf-8")
    n = sum(len(r["drift"]) for r in rows)
    print(f"OK — {len(rows)} products; {n} drift finding(s); wrote {RENDER}")
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
