#!/usr/bin/env python3
"""One drafting unit's context, and nothing else.

A pack's pipeline output is written whole, and a drafter working one domain needs a fraction of it.
Handing over the whole file is expensive, and — the part that matters more — it puts every other
domain's answers in front of someone whose job is to read the specification rather than the
neighbours. No token figure is written down here: three of them drifted apart inside a single commit,
and the CLI reports the measured size of what it actually produced.

So this emits, for ONE domain (optionally one variable):

  * the spec rows of that domain, with the fields already resolved by name
  * the deterministic lint findings for exactly those rows
  * the scaffold's starting point for each, where one exists
  * a COMPACT decision index — ids and questions, so an existing decision is reused rather than
    re-raised under a new name
  * the pack's declared config source keys, or an explicit statement that none exist yet
  * a few same-domain records for STYLE

Two things it deliberately does NOT do:

**It does not re-derive anything.** Domains come from `extracted.json`'s own `domain` field, records
through `contract_lint.records`, decisions through `contract_lint.decision_status`. A second reader of
any of those is the duplication this repo keeps paying for.

**It does not hand over neighbouring records as answers.** They are capped, and labelled as style. The
skill's rule is to read two or three nearby records for how a record is worded and never for what it
says — a slice that shipped forty of them would be teaching the opposite, and copying a neighbour's
window or tie-break is exactly how one tumour's answer becomes another's default.

It writes to stdout by default.

**It ENFORCES AI eligibility.** The material `spec_pipeline/pipeline.conf` names in `SPEC_SOURCE_ID`
is resolved through `source_refs.yaml`, and a slice is produced only when that material's recorded
`ai_classification` is `sponsor_ai_eligible`. An earlier version documented the opposite — that
eligibility was "the caller's obligation" — while the drafting skill named this tool as the AI's
starting context. Those two statements together are a fail-open: a pack whose extraction input is
`vendor_restricted` produced a slice that looked exactly like an eligible one.

There is deliberately NO override flag. `governance/WORKFLOW.md` §"Eligibility" is explicit that a
task instruction is not an approval mechanism, so a `--yes-really` here would be precisely the
mechanism that section refuses. Reclassifying the material is a human act recorded in the pack.
"""
import argparse
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import console                                                    # noqa: E402
from spec_extract import repo_relative                                  # noqa: E402

import contract_lint as cl                                          # noqa: E402
import contract_scaffold as cs                                      # noqa: E402
import product_gates as pg                                          # noqa: E402
import source_check as sc                                           # noqa: E402
import source_manifest as sm                                        # noqa: E402
import spec_extract as sx                                           # noqa: E402

# `cells` repeats what `fields` and `text` already carry, and `header` repeats per row. Dropping them
# is most of the compression that is not domain filtering. What `cells` alone carried — the columns no
# canonical field claims — is extracted into `spec_columns_unmapped` BEFORE this drops them.
DROP = ("cells", "header", "pre_header")

# Zero, not three. Nearby records were included whole under a "style only" label, so the isolation was
# a sentence in a prompt rather than a property of the document: every neighbour's window, tie-break,
# source and acceptance was on the page, and the instruction not to use them is the weakest kind of
# control there is. Opt in with --style-records N and they arrive REDACTED to their shape.
STYLE_CAP = 0

# The keys whose VALUES are another variable's answer. Redaction keeps the key, the punctuation and
# the container shape — which is all "how a record is worded" ever needed — and drops the content.
ANSWER_BEARING = ("spec_refs", "spec_digest", "required_rule", "source", "grain", "anchor", "window",
                  "record_selection", "tie_break", "derivation", "cohort_applicability", "missing",
                  "units", "depends_on", "output", "decision_ids", "gap_ids", "acceptance", "notes")

# Every artifact must state the shape it promises. A file that parses is not a file that carries what
# the caller reads out of it, and `.get(k) or []` turned an absent key into a confident empty answer.
REQUIRED_KEYS = {"extracted.json": ("extraction", "rows"),
                 "lint.json": ("findings", "applicability"),
                 "scaffold.json": ("records",)}


def _read_json(path):
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def _payload(out, name, product_dir):
    """One artifact, refused unless it is a mapping carrying the keys its readers index.

    Presence was already checked; presence is not enough. `{}` is valid JSON, and
    `payload.get("findings") or []` read it as a clean lint — zero deterministic findings, rendered as
    a specification with nothing wrong with it. `scaffold.json` had the same hole. An EMPTY findings
    list is a legitimate answer; an ABSENT findings key is a file that never answered.
    """
    payload = _read_json(os.path.join(out, name))
    missing = [k for k in REQUIRED_KEYS[name] if not isinstance(payload, dict) or k not in payload]
    if missing:
        kind = "a mapping" if isinstance(payload, dict) else f"a {type(payload).__name__}"
        raise SystemExit(
            f"{product_dir}: spec_pipeline/out/{name} is {kind} missing {', '.join(missing)} — an "
            f"empty list is an answer, an absent key is not, and reading one as the other is how a "
            f"malformed artifact renders as a clean slice. Regenerate: "
            f"python3 platform/tools/run_spec_pipeline.py {product_dir}")
    return payload


def _redact(block):
    """A record reduced to its shape: keys, punctuation, container form, no answers.

    `source: {kind: constant}` becomes `source: {kind: …}`; `grain: [cohortn]` becomes `grain: [… ×1]`;
    a quoted rule keeps its quotes and loses its text. What survives is the formatting convention a
    drafter is looking at these for. What does not survive is the other variable's answer.
    """
    out = []
    for line in block.splitlines():
        key, sep, value = line.partition(":")
        if not sep or key.strip() not in ANSWER_BEARING:
            out.append(line)
            continue
        v = value.strip()
        if v.startswith("[") and v.endswith("]"):
            n = len([t for t in v[1:-1].split(",") if t.strip()])
            shape = f"[… ×{n}]" if n else "[]"
        elif v.startswith("{") and v.endswith("}"):
            # Keep the controlled-dictionary KEYS — they are the structure — and drop their values.
            inner = ", ".join(f"{p.partition(':')[0].strip()}: …"
                              for p in v[1:-1].split(",") if p.strip())
            shape = "{" + inner + "}"
        elif v.startswith('"'):
            shape = '"…"'
        else:
            shape = "…"
        out.append(f"{key}:{' ' if value.startswith(' ') else ''}{shape}")
    return "\n".join(out)


def _artifacts_current(product_dir):
    """(ok, what it said) for "were these artifacts produced from the source as it is NOW".

    THE shared drift check — `run_spec_pipeline.main(<pack> --check)`, the same one CI runs — called,
    not reimplemented. It regenerates every artifact into a temp dir and byte-compares, so it catches
    the two things the extraction fingerprint structurally cannot:

      * the SOURCE changed and nothing was regenerated. All three stored artifacts still agree with
        each other perfectly, because they are all equally out of date.
      * the LINT or SCAFFOLD logic changed and the artifacts were not regenerated. The extraction is
        untouched, so the copied fingerprint still matches, while `lint.json` is missing a check that
        was added since — a drafter is handed "no findings" from a scan that never ran the new rule.

    The fingerprint proves the three files agree with EACH OTHER. Only this proves they agree with the
    world. Both are needed: this one costs a second and needs the source readable, and the fingerprint
    still catches a half-regenerated `out/` instantly.
    """
    import subprocess

    # As a SUBPROCESS, not by importing main(): `run_spec_pipeline` spawns the five stage tools as
    # child processes, and `contextlib.redirect_stdout` only rebinds Python's own sys.stdout — the
    # children write to the inherited fd, so an in-process call printed the whole extraction log into
    # the middle of the slice. This is still one implementation, invoked; the alternative was a second
    # copy of the comparison here.
    tool = os.path.join(os.path.dirname(os.path.abspath(__file__)), "run_spec_pipeline.py")
    try:
        r = console.run([sys.executable, tool, product_dir, "--check"], timeout=600)
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        # NOT BaseException: that swallowed KeyboardInterrupt and SystemExit, so a Ctrl-C during the
        # one-second preflight was reported as a failed currentness check rather than stopping.
        return False, f"the currentness check could not run: {exc!r}"
    # The VERDICT, not the generation log. `--check` narrates every stage to stdout on its way to a
    # one-line answer, and quoting all of it buried the reason under 300 words about temp dirs.
    said = " ".join((r.stderr + " " + r.stdout).split())
    for marker in ("NOT GENERATED:", "MISSING:", "DRIFT:"):
        if marker in said:
            said = said[said.index(marker):]
            break
    for end in ("Regenerate with run_spec_pipeline.", "Run without --check first."):
        if end in said:
            said = said[:said.index(end) + len(end)]
            break
    return r.returncode == 0, said[:400]


def slice_pack(product_dir, domain, variable=None, style_cap=STYLE_CAP, items=None,
               verify_current=True):
    """Everything one drafting unit needs, keyed by section. Raises on a domain the pack lacks."""
    # A negative cap reached `[:style_cap]` and became a Python slice-from-the-end: `-1` returned
    # FIFTEEN style records instead of none. Refused rather than clamped — silently reinterpreting a
    # caller's number is how a cap stops meaning what it says.
    if style_cap < 0:
        raise SystemExit(f"--style-records must be >= 0, got {style_cap}")

    out = os.path.join(product_dir, "spec_pipeline", "out")

    # All THREE, not just the extraction. `lint.json` carries the findings that tell a drafter the
    # specification does not contain an answer — the evidence I17 exists to enforce — and
    # `scaffold.json` carries the machine-established refs and digest the drafter passes through
    # rather than authors. Treating them as optional produced a clean-looking slice with both
    # protections silently absent, which is the failure this whole tool is supposed to prevent.
    missing = [f for f in ("extracted.json", "lint.json", "scaffold.json")
               if not os.path.exists(os.path.join(out, f))]
    if missing:
        # "REFUSING to slice" is not decoration: CI loops this tool over every pack with a
        # pipeline.conf and distinguishes a legitimate refusal from a broken tool BY THAT PHRASE
        # (`case "$out" in *"REFUSING to slice"*`). This message is the refusal a brand-new pack
        # meets first — it acquires a pipeline.conf when the pack is created and an extraction only
        # after a person registers the workbook — and without the phrase it read as an unexpected
        # non-zero exit and failed the job for a state that is correct.
        raise SystemExit(f"{product_dir}: REFUSING to slice — spec_pipeline/out is missing "
                         f"{', '.join(missing)}, and a slice without them silently drops the lint "
                         f"findings and the scaffold's established fields. Register the source, "
                         f"then run: python3 platform/tools/run_spec_pipeline.py {product_dir}")

    # BEFORE anything is READ out of the pack, and after the presence check, which only stats.
    # Order matters both ways: a brand-new pack with an empty `out/` deserves "run the pipeline",
    # not a lecture about classification, and no byte of specification text may be read before
    # eligibility is established. Checking that a file EXISTS reads none of it.
    #
    # Through source_manifest's own predicate — the module that owns Gate 1's material vocabulary —
    # so the slicer cannot come to a different answer about one material than Gate 1 does.
    # `source_refs.yaml` that will not parse is a GATE, not a crash. `classified_date: 2026-13-99`
    # unquoted makes PyYAML raise from inside its date constructor, and an uncaught Unreadable here
    # reported a defect in a governed file as a traceback naming neither the file nor the field —
    # the exact shape source_manifest.load was written to stop, one caller further out.
    try:
        material = sm.pipeline_material(product_dir)
    except sm.Unreadable as exc:
        raise SystemExit(f"{product_dir}: REFUSING to slice — source_refs.yaml will not parse "
                         f"({exc}), so the material's classification cannot be read. Eligibility "
                         f"unread is eligibility unproven.")
    # FULL Gate 1, not just the selected material's classification. The slicer validated one
    # material's class, author and date and nothing else — so a pack with two authoritative
    # specifications, a duplicate material_id, a `derived_from` chain whose far end nobody approved,
    # or a SPEC_SOURCE_ID naming a supporting document rather than a specification, still produced a
    # slice as long as the material it happened to select looked eligible. Governed packs are covered
    # by CI's separate Gate 1 step; the sandbox is outside product discovery and gets no such pass,
    # which is exactly where a new tumour is being drafted.
    #
    # Through `source_manifest.check` — the Gate 1 authority — never by restating its rules here.
    # (root, rel) as source_manifest's own CLI computes them — the `path_or_link` values inside
    # source_refs.yaml are REPO-relative, so splitting the pack path at its parent instead resolved
    # every registered document against the wrong base and reported all three live packs as naming
    # files that do not exist.
    _root = pg.repo_root()
    gate1 = sm.check(_root, repo_relative(os.path.abspath(product_dir), _root))
    if gate1:
        raise SystemExit(
            f"{product_dir}: REFUSING to slice — Gate 1 rejects this pack's source manifest:\n"
            + "\n".join(f"  {e}" for e in gate1[:6])
            + (f"\n  ... and {len(gate1) - 6} more" if len(gate1) > 6 else "")
            + "\n  Eligibility is a claim ABOUT the registered materials; a manifest that does not "
              "validate cannot support it.")

    # ELIGIBILITY IS ASKED OF THE ARTIFACT AI OPENS, not of the input it came from.
    #
    # This asked `ai_eligible(material)` — the classification on the RAW stand-in. That is the
    # wrong subject: a slice is assembled from `spec_pipeline/out/extracted.json`, which is DERIVED
    # and sanitized, while the stand-in it comes from legitimately reproduces the vendor prose
    # the redactor removes. On both prostate packs the recorded class said `sponsor_ai_eligible` about
    # a document that demonstrably contained vendor documentation — a claim contradicting its own
    # subject, and the thing that granted access.
    #
    # `sm.ai_readable` asks instead whether the DERIVED artifact is registered, classified, approved by
    # a named person, still the extraction that approval was given over, still under the redaction
    # policy it was given under, and still free of vendor prose. Every one of those fails closed.
    readable, why_not = sm.ai_readable(product_dir)
    if not readable:
        raise SystemExit(
            f"{product_dir}: REFUSING to slice — the sanitized extraction is not approved for AI use:\n"
            + "\n".join(f"  {w}" for w in why_not[:6])
            + (f"\n  ... and {len(why_not) - 6} more" if len(why_not) > 6 else "")
            + f"\n  A slice reproduces the specification's text, so it is built ONLY from a derived "
              f"artifact somebody has signed. Registering and approving it is a HUMAN act recorded in "
              f"{product_dir}/source_refs.yaml — see governance/WORKFLOW.md \"Eligibility\". An "
              f"instruction in the task is not an approval mechanism.\n"
              f"  The block, with the derivation fields already computed:\n"
              f"    python3 platform/tools/source_manifest.py --register-ai-extraction {product_dir}")

    # Presence, then eligibility, then CURRENTNESS, then read. The slice's users infer from it that
    # what they are reading is the specification as it stands; without this the tool only ever
    # promised that its three artifacts agreed with one another.
    if verify_current:
        ok, said = _artifacts_current(product_dir)
        if not ok:
            raise SystemExit(
                f"{product_dir}: REFUSING to slice — the committed pipeline artifacts are not current "
                f"for the source as it stands.\n  {said}\n"
                f"  The extraction fingerprint proves the three artifacts agree with EACH OTHER; it "
                f"cannot see a source that changed with nothing regenerated, or a lint rule added "
                f"since they were written. Regenerate: python3 platform/tools/run_spec_pipeline.py "
                f"{product_dir}")

    data = _payload(out, "extracted.json", product_dir)

    known = sorted({r.get("domain") for r in data["rows"] if r.get("domain")})
    if domain not in known:
        raise SystemExit(f"{product_dir}: no domain '{domain}'. This pack has: {', '.join(known)}")

    rows = [r for r in data["rows"] if r.get("domain") == domain]
    if variable:
        rows = [r for r in rows if (r.get("variable") or "").strip() == variable]
        if not rows:
            raise SystemExit(f"{product_dir}: no row in '{domain}' names variable '{variable}'")
        # A name is not an identifier. Clinical and treatment sheets carry paired and repeated
        # variable names — per-line families, a categorical beside its numeric counterpart — so a
        # `--variable` that matches several rows is ambiguous, and silently slicing all of them is a
        # drafting unit nobody chose. Name the item ids and let the caller pick.
        if len(rows) > 1:
            raise SystemExit(
                f"{product_dir}: --variable '{variable}' matches {len(rows)} rows in '{domain}' "
                f"({', '.join(r['item_id'] for r in rows[:6])}"
                f"{', …' if len(rows) > 6 else ''}). Select one with --item, repeat --item for "
                f"several, or give --item a range.")
    if items:
        want = set()
        for tok in items:
            rc = cl.spec_ref_rows(tok)
            if not rc:
                raise SystemExit(f"{product_dir}: --item '{tok}' is not a `<domain>:<row>` or "
                                 f"`<domain>:<lo>-<hi>` citation")
            want |= {f"{d}:{n}" for d, n in rc}
        chosen = [r for r in rows if r["item_id"] in want]
        # ONE message, whether the selector missed everything or only part. Two branches meant a
        # selector naming three rows of which none existed explained itself differently from one
        # naming three of which two did, and the second is the case that matters more.
        missing = sorted(want - {r["item_id"] for r in chosen})
        if missing:
            span = f"{rows[0]['item_id']}..{rows[-1]['item_id']}" if rows else "(no rows)"
            raise SystemExit(f"{product_dir}: {', '.join(missing)} "
                             f"{'is' if len(missing) == 1 else 'are'} not in domain '{domain}', "
                             f"which spans {span} — a selector that silently drops what it names is "
                             f"worse than no selector")
        rows = chosen
    ids = {r["item_id"] for r in rows}

    # `spec_lint` emits {fingerprint, findings, applicability}. A bare-list shape
    # as "legacy" is now refused by `_payload`: no pack carries it, and an artifact that cannot state
    # its applicability or its run is exactly the artifact this batch stopped trusting.
    payload = _payload(out, "lint.json", product_dir)
    all_findings = findings = payload["findings"]

    # `applicability` is why zero findings means something. `spec_lint` emits it precisely so a reader
    # can tell "the check ran and found nothing" from "the check never ran" — an unrecognised tumour
    # family, no table-shaped source refs — and the slice dropped it, handing a drafter a clean sheet
    # that might have been an unexamined one.
    applicability = payload["applicability"]

    # `spec_lint` keys WORKBOOK_STRUCTURE findings to a SHEET, not a row: `<tab>:(sheet)` for formula
    # cells with no cached value, hidden rows, partial merges, validations, comments. Those exist
    # precisely to surface requirements Excel is hiding, so they belong in the slice of every domain
    # drawn from that sheet — and filtering by row id dropped them, while the orphan check below then
    # read them as a mismatched run and refused to slice at all. Latent only because the current packs
    # happen to have none; a real .xlsx with one hidden row would have hit it.
    sheets = {r["tab"] for r in rows}
    findings = [f for f in findings
                if f.get("item_id") in ids
                or (str(f.get("item_id", "")).endswith(":(sheet)") and f.get("tab") in sheets)]

    scaffold = _payload(out, "scaffold.json", product_dir)
    all_starts = scaffold["records"]
    starts = [r for r in all_starts if any(x in ids for x in (r.get("spec_refs") or []))]

    # The three files must describe ONE run — checked on the extraction FINGERPRINT, which is a hash
    # over the source bytes and every row's content_hash.
    #
    # The previous version compared item ids, and `<domain>:<row>` is a COORDINATE, not an identity.
    # When RWB edits the text of a rule in place, the id does not move: extraction rerun, lint and
    # scaffold left behind, every cited id still resolves, and an id-set comparison sees one coherent
    # run while the findings describe the previous wording of the rule. `contract_lint.spec_digest`
    # exists for exactly this reason on the contract side; this is the same argument one file earlier.
    fps = {"extracted.json": (data.get("extraction") or {}).get("fingerprint", ""),
           "lint.json": payload.get("fingerprint", ""),
           "scaffold.json": (scaffold.get("scaffold") or {}).get("fingerprint", "")}
    blank = [k for k, v in fps.items() if not v]
    if blank:
        raise SystemExit(f"{product_dir}: {', '.join(blank)} carries no extraction fingerprint — "
                         f"written before the pipeline stamped one, so it cannot prove which run it "
                         f"came from. Regenerate: python3 platform/tools/run_spec_pipeline.py "
                         f"{product_dir}")
    if len(set(fps.values())) != 1:
        raise SystemExit(f"{product_dir}: the three pipeline artifacts are from DIFFERENT runs "
                         f"({', '.join(f'{k}={v}' for k, v in sorted(fps.items()))}) — the findings "
                         f"and scaffold describe a different version of the spec than the rows do. "
                         f"Regenerate: python3 platform/tools/run_spec_pipeline.py {product_dir}")

    # Kept alongside the fingerprint: a citation naming no extracted row is a defect the fingerprint
    # cannot see, because a hand-edited lint.json agreeing on the stamp can still cite a row that was
    # never extracted. Sheet ids and file ids are legitimate subjects and are not orphans —
    # `(sheet)` carries workbook-structure findings, `(file)` the transcription-shape ones
    # (SKIPPED_LINE / ROW_GAP), whose subject is the source file rather than any row in it.
    all_ids = ({r["item_id"] for r in data["rows"]} |
               {f'{r["tab"]}:(sheet)' for r in data["rows"]} |
               {f'{r["tab"]}:(file)' for r in data["rows"]})
    orphan = ({f.get("item_id") for f in all_findings} |
              {x for r in all_starts for x in (r.get("spec_refs") or [])}) - all_ids
    if orphan:
        raise SystemExit(f"{product_dir}: lint.json/scaffold.json cite {len(orphan)} item(s) absent "
                         f"from extracted.json (e.g. {sorted(orphan)[:3]}) — the pipeline output is "
                         f"from more than one run. Regenerate: python3 platform/tools/run_spec_pipeline.py {product_dir}")

    # The decision index is ids + questions only. A drafter needs to know an id EXISTS and roughly
    # what it asks, so the same question is not raised twice under two names; it does not need the
    # evidence, owner and resolution columns to decide that.
    reg = os.path.join(product_dir, "handoff", "DECISIONS.md")
    decisions = []
    if os.path.exists(reg):
        with open(reg, encoding="utf-8") as fh:
            text = fh.read()
        status = cl.decision_status(text)
        for did, row in cl.decision_rows(text).items():
            q = " ".join((cl.cell(row, "question") or "").split())
            decisions.append({"id": did, "status": status.get(did, ""), "question": q[:160]})


    # FOUR states, not two. "no config yet" is the legitimate pre-config case a new tumour is in;
    # a config that exists but is unreadable, or declares no sources, is a defect — and rendering
    # either as "no declared sources yet" would hand a drafter the new-tumour licence to leave the
    # mapping unresolved on a pack that has no such excuse. `finalize` draws the same distinction.
    cfg = os.path.join(product_dir, "config", "data_product.yaml")
    sources, config_state = [], "absent"
    if os.path.exists(cfg):
        doc, err = pg.read_yaml(cfg)
        if err:
            raise SystemExit(f"{product_dir}: config/data_product.yaml is unreadable ({err}) — a "
                             f"slice cannot state which logical sources are declared")
        if "sources" not in doc:
            config_state = "no_sources_block"
        else:
            # Through the SHARED resolver, not this file's own read of the raw mapping. The engine
            # merges the base `sources:` with the ACTIVE delivery-format overlay, and
            # `source_check.load_product_config` is the one loader the build, the schema validator and
            # profile_facts all call — its docstring says so in as many words. Reading the raw YAML
            # gave the same answer on today's packs and a staler one on the first pack with an
            # overlay, which is this repo's cardinal failure exactly.
            cfg = sc.load_product_config(product_dir)
            sources = sorted(cfg.sources if cfg is not None else (doc["sources"] or {}))
            config_state = "declared"

    # NEAREST by row, not the first three in the domain. The previous version took whichever records
    # came first, so a clinical variable at row 140 was shown examples from rows 2-4 and the word
    # "nearby" was simply untrue. Distance is measured against the sliced rows themselves.
    # The records that ALREADY cite these rows, in full and unredacted. These are the subject of the
    # work — revising one, or auditing whether it still matches the spec — not a neighbour's answer
    # leaking in. Their absence is what made the "audit whether the contract still matches the spec"
    # use case the skill advertises impossible to actually perform: a domain audit saw three nearby
    # records and none of the ones under review, and a drafting run could recreate a row that had
    # been deliberately dispositioned elsewhere.
    style, current = [], []
    contract = os.path.join(product_dir, "handoff", "FUNCTIONAL_CONTRACT.md")
    if os.path.exists(contract):
        with open(contract, encoding="utf-8") as fh:
            ctext = fh.read()
        target = [r["row"] for r in rows]
        near = []
        for b in cl.records(ctext):
            refs = cl._list(b, "spec_refs") or []
            # Through the shared expander. Matching the raw strings against `ids` saw `clinical:17-46`
            # as neither row 17 nor row 46, so a record citing a RANGE was invisible here: the audit
            # was told the row had no record, and a drafter could write a second one for a row already
            # mapped. `contract_scaffold` expanded ranges all along, so the slice's own coverage
            # section said `mapped` while this section showed nothing — the two halves of one page
            # disagreeing.
            covered = cl.spec_ref_ids(refs)
            if covered & ids:
                current.append(b)
                continue                       # the record under review is never also a style example
            here = [n for d, n in
                    (rc for r in refs for rc in cl.spec_ref_rows(r)) if d == domain]
            if here:
                near.append((min(abs(h - t) for h in here for t in target), b))
        style = [_redact(b) for _, b in sorted(near, key=lambda x: x[0])[:style_cap]]

    # Each selected row's DISPOSITION, from the producer. `contract_scaffold.coverage_report` is the
    # one thing that decides whether a row is mapped, declared, context or undispositioned; parsing
    # the rendered COVERAGE.md would be a second answer to that, free to disagree with the first.
    cov_rows, _ = cs.coverage_report(data, product_dir, all_findings)
    coverage = [c for c in cov_rows if c["item"] in ids]

    # ...and the SAME index for the other two registers, which the slice carried nothing about.
    #
    # A drafter working a domain in isolation could see that a decision already existed and could not
    # see that the defect was already a QC finding or the shortfall already a gap — so two agents
    # working two domains would each raise the same finding under a different id, in exactly the
    # register nobody deduplicates afterwards. Read through `cl.decision_rows`, the ONE reader of an
    # `| ID | … |` register (docs/ENGINEERING.md): all three files are that shape.
    #
    # RELEVANT ones, not the whole register. The QC register carries a `Spec ref`, so relevance is the
    # rows in this slice; gaps carry none, so relevance is being cited by a record already citing those
    # rows. Handing over both registers whole would put every other domain's answers in front of the
    # drafter, which is the thing the slice exists to prevent.
    cited_ids = set()
    for block in current:
        for line in block.splitlines():
            if line.startswith(("decision_ids:", "gap_ids:")):
                cited_ids |= {t.strip(" []") for t in line.split(":", 1)[1].split(",") if t.strip(" []")}

    # THE QC REGISTER CITES BY TAB LABEL, not by canonical domain — `5B.ClinVars:89`, not
    # `clinical:89`. Every other citation in the framework is by domain, precisely because tab labels
    # differ per product and per revision. Rather than restate that mapping here, resolve it through
    # `spec_extract.shared_sheet_map`, which OWNS it: a second tab->domain table would be the exact
    # duplicate this repo keeps paying for, and it would be wrong for the first product whose sheets
    # are named differently. A label the map does not know simply does not match, which is the
    # fail-quiet direction — it hides a finding rather than inventing a link to one.
    # Punctuation- and space-insensitive, because the register is hand-written: it says `3.DataPrep`
    # where the map says `3.data prep`, and those are the same sheet. It is NOT fuzzy beyond that —
    # `5B.ClinVars` against the map's `5B. ClinChars` are different words, and quietly linking them
    # would attach a finding to a row nobody said it was about.
    # THE PACK'S OWN EXTRACTION FIRST. Every row carries both its `tab` and its `domain`, so this
    # workbook's real mapping is already recorded — and it is better evidence than the repo-wide map,
    # which lists the labels seen so far across products rather than the ones in front of us. The
    # shared map fills in sheets that carry no requirement rows.
    sheet_to_domain = {re.sub(r"[^a-z0-9]", "", k): v
                       for k, v in sx.shared_sheet_map()["sheets"].items()}
    sheet_to_domain.update({re.sub(r"[^a-z0-9]", "", r["tab"].lower()): r["domain"]
                            for r in data["rows"] if r.get("tab") and r.get("domain")})
    domains_known = set(sheet_to_domain.values())
    unresolved_refs = set()

    def _canonical(ref):
        """Every `<label>:<row>` in a register cell as `<domain>:<row>`. A label neither the map nor
        the domain vocabulary knows is RECORDED as unresolved rather than passed through: passing it
        through makes it a citation that can never match anything, which reads as "no finding here"."""
        out = set()
        for m in re.finditer(r"([A-Za-z0-9_. ]+):(\d+)", ref):
            raw, row = m.group(1).strip(), m.group(2)
            key = re.sub(r"[^a-z0-9]", "", raw.lower())
            domain = sheet_to_domain.get(key) or (raw.lower() if raw.lower() in domains_known else None)
            if domain is None:
                unresolved_refs.add(f"{raw}:{row}")
                continue
            out.add(f"{domain}:{row}")
        return out

    def _index(filename, text_columns, ref_column=None, id_column="ID"):
        path = os.path.join(product_dir, "handoff", filename)
        if not os.path.exists(path):
            return []
        with open(path, encoding="utf-8") as fh:
            text = fh.read()
        status = cl.decision_status(text)
        legal = cl.gap_ids(text) if id_column == "Gap ID" else None
        out = []
        for rid, row in cl.decision_rows(text, id_column).items():
            if legal is not None and rid not in legal:
                continue
            refs = " ".join((cl.cell(row, ref_column) or "").split()) if ref_column else ""
            # Through the SHARED expander as well as the label resolver, so a register citing a RANGE
            # (`clinical:17-46`) matches the rows inside it. `_canonical` handles the tab-label form
            # the registers were written in; `spec_ref_ids` is the one expander the lint already uses,
            # and matching raw strings was what made a ranged citation invisible everywhere else.
            canonical = _canonical(refs) | cl.spec_ref_ids(re.findall(r"[a-z_]+:[\d-]+", refs))
            if not (rid in cited_ids or (canonical & ids)):
                continue
            summary = next((" ".join((cl.cell(row, c) or "").split())
                            for c in text_columns if (cl.cell(row, c) or "").strip()), "")
            out.append({"id": rid, "status": status.get(rid, ""), "spec_ref": refs,
                        "summary": summary[:160]})
        return out

    qc_findings = _index("SPEC_QC_FINDINGS.md", ("defect", "what was lost", "impact"), "spec ref")

    # Through the SHARED reader, keyed by the column `ENGINE_GAPS.md` actually uses. This was a local
    # `split("|")` because `_register_rows` hardcoded `ID` and the gap index heads its column
    # `Gap ID` — a fourth parser for one register shape. The reader takes the column name now.
    # `contract_lint.gap_ids` stays the OWNER of what counts as a gap id and decides membership.
    gaps = _index("ENGINE_GAPS.md", ("section · row it labels", "gap", "description"),
                  id_column="Gap ID")

    out_slice = {"product": product_dir, "domain": domain, "variable": variable,
            "material": {"id": (material or {}).get("material_id", ""),
                         "ai_classification": (material or {}).get(sm.AI_CLASSIFICATION, ""),
                         "status": (material or {}).get("status", "")},
            "fingerprint": fps["extracted.json"],
            "rows": [dict({k: v for k, v in r.items() if k not in DROP},
                          spec_columns_unmapped=sx.unmapped_columns(r)) for r in rows],
            "findings": findings, "applicability": applicability,
            "scaffold": starts, "decisions": decisions,
            "qc_findings": qc_findings, "gaps": gaps,
            "unresolved_register_refs": sorted(unresolved_refs),
            "current_records": current, "coverage": coverage,
            "sources": sources, "config_state": config_state, "style": style,
            "domains_available": known}

    # LAST, on the assembled slice. The classification says a human judged this material AI-eligible;
    # this asks whether its CONTENT agrees, which is the question `governance/WORKFLOW.md` actually
    # poses — eligibility follows the content's provenance, never the folder or the recorded field
    # alone. Until now the two could disagree silently, and on both prostate packs they do.
    #
    # Fail-closed, and there is no override for the same reason the classification has none: a task
    # instruction is not an approval mechanism. The fix is to sanitize the sentence — state the
    # sponsor's conclusion and cite the restricted evidence by reference — or to reclassify the
    # material, and both are human acts recorded in the pack.
    try:
        breach = boundary_errors(out_slice)
    except sm.Unreadable as exc:
        # A governance file that will not load is a GATE, not a crash — the same rule this tool
        # already applies to source_refs.yaml one check earlier.
        raise SystemExit(f"{product_dir}: REFUSING to slice — {exc}")
    if breach:
        where = "\n".join(f"  {w}: [{m}] …{e}…" for w, m, e in breach[:5])
        raise SystemExit(
            f"{product_dir}: REFUSING to slice — this slice reproduces VENDOR DOCUMENTATION, while "
            f"the material it came from is recorded {sm.AI_ELIGIBLE!r}.\n{where}"
            + (f"\n  ... and {len(breach) - 5} more" if len(breach) > 5 else "")
            + "\n  Those two recorded facts contradict each other. Eligibility follows the CONTENT "
              "(governance/WORKFLOW.md \"Eligibility\"): an internally authored document that quotes "
              "vendor documentation inherits the restricted classification.\n"
              "  Resolve it as a human: replace the quotation with the sponsor's own conclusion and a "
              "reference to the restricted evidence, or reclassify the material. Vendor TABLE and "
              "COLUMN names are not the problem and are not what this checks — see "
              "governance/ai_boundary.yaml.")
    return out_slice


def gate1_states(s):
    """The three separate things "Gate 1" names, each answered from the module that owns it.

    A slice only EXISTS if the sanitized extraction is approved for AI use, which makes it very easy
    for a reader — human or model — to take the document in front of them as proof that Gate 1
    passed. On every pack today it has not, and the two remaining questions are the ones that matter
    most to anybody relying on the output:

      AI access to the sanitized extraction   a named person approved THIS derived artifact
      the authoritative workbook              is the approved specification registered at all
      the extraction basis                    were these rows extracted FROM that workbook, or from
                                              a stand-in nobody has attested matches it

    The third is the one a single verdict hides completely. A stand-in can be internally consistent,
    lint clean and fully traced, and still state a rule less precisely than the approved workbook —
    so "the spec says nothing about X" means something different depending on this line.

    Every answer comes from `source_manifest`: `ai_readable` for the first, `authoritative` for the
    second, `pipeline_source_id` for which material the artifacts were actually built from. Nothing
    here re-derives a status, and nothing here decides anything.
    """
    product = s["product"]
    ok, _why = sm.ai_readable(product)
    spec = sm.authoritative(product) or {}
    basis_id = sm.pipeline_source_id(product)
    basis = next((m for m in sm.materials(product) or [] if m.get("material_id") == basis_id), {})
    is_workbook = basis.get("material_type") == sm.PROGRAM_SPEC
    attested = str(basis.get("attested_against_sha256") or "").strip()

    rows = [
        ("AI access to the sanitized extraction",
         "approved" if ok else "NOT approved",
         "a named person approved this derived artifact, over these exact bytes"),
        ("The authoritative workbook",
         "registered and reviewed" if spec.get("status") == sm.REVIEWED else "PENDING",
         str(spec.get("why_provisional") or "").strip().split("\n")[0][:110]
         or "no approved specification is registered for this pack"),
        ("The extraction basis",
         f"the approved workbook (`{basis_id}`)" if is_workbook else
         f"an UNATTESTED stand-in (`{basis_id}`)" if not attested else
         f"a stand-in attested against the workbook (`{basis_id}`)",
         "the rows below were extracted from this material, not necessarily from the "
         "approved specification"),
    ]
    closed = ok and spec.get("status") == sm.REVIEWED and is_workbook
    L = ["\n## GATE 1 — three states, not one verdict\n",
         "Producing this slice does NOT mean Gate 1 passed. Report these separately.\n",
         "| | State | |", "|---|---|---|"]
    L += [f"| {what} | **{state}** | {why} |" for what, state, why in rows]
    L.append(f"\n**Gate 1 overall: {'closed' if closed else 'NOT closed'}.** "
             + ("" if closed else "An AI-readable provisional extraction is not an approved "
                                 "authoritative specification."))
    return L


def render(s):
    """The slice as one readable document. Markdown, not JSON: it is read, not parsed."""
    L = [f"# Drafting slice — `{s['product']}` · domain `{s['domain']}`"]
    m = s["material"]
    L.append(f"\nSource material `{m['id']}` · ai_classification `{m['ai_classification']}` · "
             f"material status `{m['status']}` · extraction fingerprint `{s['fingerprint']}`")
    if s["variable"]:
        L.append(f"\nNarrowed to variable **{s['variable']}**.")

    # GATE 1, AS THREE STATES — because a reader of a successful slice will otherwise conclude it
    # passed, and on every pack today it has not. The slice REFUSES unless the sanitized extraction
    # is approved for AI use, and that refusal is about ONE derived artifact. It says nothing about
    # whether the authoritative workbook has been registered, and nothing about whether the bytes
    # this extraction was built from are that workbook or an unattested stand-in for it. Reporting
    # "Gate 1 ✓" over the top of those two open questions is the single most consequential
    # overstatement this document can make: everything downstream is drafted from the answer.
    for line in gate1_states(s):
        L.append(line)
    L.append(f"\nThis is the STARTING context for this drafting unit. Other domains of this pack "
             f"({', '.join(d for d in s['domains_available'] if d != s['domain']) or 'none'}) are "
             f"deliberately absent — read the specification, not the neighbours.")
    L.append("\n**It is not necessarily sufficient.** A variable here can depend on something defined "
             "elsewhere — an index date, a cohort, a follow-up endpoint, a treatment-line rule. If the "
             "record you draft names a `depends_on` or an anchor whose DEFINITION is not in this "
             "slice, say so and ask for that domain; do not reconstruct it from the name.")

    # Sheet-level findings first: they describe the WORKBOOK, so they qualify every row below and a
    # reader needs them before the rows, not buried under one of them. Grouping findings by row id
    # alone kept these out of the rendered document even after they reached the data.
    sheet_level = [f for f in s["findings"] if str(f["item_id"]).endswith(":(sheet)")]
    if sheet_level:
        L.append("\n## Workbook-structure findings — these qualify EVERY row below\n")
        L.append("Excel can hide a requirement. Treat an affected cell as unread, not as empty.\n")
        for f in sheet_level:
            L.append(f"- ⚠ **{f['kind']}** ({f['severity']}) on `{f['tab']}`: {f['detail']}")

    # A check that did not RUN is not a check that passed. `spec_lint` emits `applicability` so those
    # two can be told apart, and rendering only the findings silently merged them.
    notapplied = {k: v for k, v in s["applicability"].items()
                  if k != "reasons" and v != "applied"}
    if notapplied:
        L.append("\n## Lint checks that did NOT run\n")
        L.append("Zero findings from these means nobody looked, not that there is nothing to find.\n")
        for k, v in sorted(notapplied.items()):
            L.append(f"- **{k}**: {v}")
        for r in s["applicability"].get("reasons") or []:
            L.append(f"  - {r}")

    L.append(f"\n## Spec rows — {len(s['rows'])}\n")
    flagged = {}
    for f in s["findings"]:
        if str(f["item_id"]).endswith(":(sheet)"):
            continue
        flagged.setdefault(f["item_id"], []).append(f)
    disp = {c["item"]: c for c in s["coverage"]}
    for r in s["rows"]:
        L.append(f"### `{r['item_id']}` — {r.get('variable') or '(no variable named)'}")
        L.append(f"tab `{r['tab']}` row {r['row']} · content hash `{r['content_hash']}`\n")
        d = disp.get(r["item_id"])
        if d:
            cited = ", ".join(f"`{x}`" for x in d["records"]) or "—"
            L.append(f"- **disposition**: `{d['disposition']}`"
                     + (f" · cited by {cited}" if d["records"] else "")
                     + (f" · handled_by {d['handled_by']}" if d["handled_by"] else ""))
        for k, v in (r.get("fields") or {}).items():
            if str(v).strip():
                L.append(f"- **{k}**: {' '.join(str(v).split())}")
        # Columns this workbook carries that no canonical field claims — `Origin`, `Status`, `Owner`,
        # `Evidence` on the ovarian sheets. They were preserved in the extraction all along and
        # reached no reader, so a row marked `first-pass [verify]` or `ADDITIVE (not in prior spec)`
        # read as a settled requirement.
        for label, value in (r.get("spec_columns_unmapped") or []):
            L.append(f"- **{label}** *(unmapped column)*: {value}")
        for f in flagged.get(r["item_id"], []):
            L.append(f"- ⚠ **{f['kind']}** ({f['severity']}): {f['detail']}")
        L.append("")

    if s["current_records"]:
        L.append(f"## Records already citing these rows — {len(s['current_records'])}\n")
        L.append("These are the records UNDER REVIEW, in full. Revise them; do not duplicate them. If "
                 "a row above is already `mapped`, drafting a second record for it is the error this "
                 "section exists to prevent.\n")
        for b in s["current_records"]:
            L.append("```")
            L.append(b)
            L.append("```")

    if s["scaffold"]:
        L.append(f"## Starting points — {len(s['scaffold'])}\n")
        L.append("Save one of these, answer the `TODO`s, and render it:\n")
        L.append("```")
        L.append(f"python3 platform/tools/contract_record.py <file> --product {s['product']} "
                 f"--item <domain>:<row>")
        L.append("```\n")
        # THE SHAPE THE CONSUMING TOOL ACCEPTS, not the scaffold record.
        #
        # This was a raw dump of `scaffold.json`, whose records carry `spec_refs`, `spec_digest`,
        # `required_rule` and `status` — and `contract_record` REFUSES a draft containing any of them,
        # because they come from the extraction rather than from a drafter. So the generated starting
        # point had to be hand-stripped before the tool that consumes it would take it, once per
        # record, by every analyst. Two artifacts each individually right and unusable together.
        #
        # `contract_scaffold.judgment_stub` is the one definition of what a drafter answers. The
        # machine-owned fields are absent because the tool fills them in — which is also why this
        # sits directly under the spec rows above: the rule the record must state is printed there,
        # and a stub read away from its row is a record authored without reading the specification.
        L.append("```yaml")
        for r in s["scaffold"]:
            L.append(cs.judgment_stub(r.get("variable_id", "TODO")).rstrip())
            L.append("---")
        L.append("```\n")
        # The machine-established evidence stays VISIBLE, so a reader can see what the tool will fill
        # in and check it against the row — it just is not in the file they edit.
        L.append("<details><summary>what the tool fills in from the extraction</summary>\n")
        L.append("```json")
        L.append(json.dumps([{k: v for k, v in r.items() if k in cs.MACHINE_OWNED or
                              k in ("variable_id", "lint_flags", "spec_columns")}
                             for r in s["scaffold"]], indent=1, ensure_ascii=False))
        L.append("```\n</details>\n")

    L.append(f"## Decision index — {len(s['decisions'])} in this pack\n")
    L.append("Reuse an existing id before raising a new one; two ids for one question is how a "
             "register stops being readable.\n")
    for d in s["decisions"]:
        L.append(f"- `{d['id']}` [{d['status']}] {d['question']}")
    if not s["decisions"]:
        L.append("- (none)")

    L.append(f"\n## QC findings on these rows — {len(s['qc_findings'])}\n")
    L.append("Defects in RWB's document that someone has already recorded for the rows you are "
             "drafting. Reuse the id; do not raise the same defect a second time.\n")
    for f in s["qc_findings"]:
        L.append(f"- `{f['id']}` [{f['status']}] {f['spec_ref']} — {f['summary']}")
    if not s["qc_findings"]:
        L.append("- (none recorded against these rows)")

    L.append(f"\n## Gaps cited by the records on these rows — {len(s['gaps'])}\n")
    L.append("Shortfalls between the requirement and the executable. `gap_ids` on a record must name "
             "one of these; a new gap is a new id in `handoff/ENGINE_GAPS.md`.\n")
    for g in s["gaps"]:
        L.append(f"- `{g['id']}` [{g['status']}] {g['summary']}")
    if not s["gaps"]:
        L.append("- (none cited by the records on these rows)")

    if s.get("unresolved_register_refs"):
        L.append(f"\n## Register citations that resolve nowhere — "
                 f"{len(s['unresolved_register_refs'])}\n")
        L.append("These `Spec ref` cells in `handoff/SPEC_QC_FINDINGS.md` name a sheet this pack's "
                 "extraction does not contain, so the finding cannot be matched to a row and does not "
                 "appear above. That is a defect in the REGISTER, not in the specification — record "
                 "it and let a human repoint the citation; do not guess which row was meant.\n")
        for r in s["unresolved_register_refs"]:
            L.append(f"- `{r}`")

    L.append("\n## Logical source keys\n")
    if s["config_state"] == "declared":
        L.append("Config declares these, and `source.inputs` keys must be among them:\n")
        L.append("  " + " · ".join(f"`{x}`" for x in s["sources"]))
    elif s["config_state"] == "no_sources_block":
        L.append("**This pack HAS a config but it declares no `sources:` block.** That is a defect in "
                 "the pack, not the pre-config state of a new tumour — do not treat it as licence to "
                 "leave a mapping unresolved. Raise it.")
    else:
        L.append("**This pack has no declared sources yet.** Do not coin a logical alias, and do NOT "
                 "raise a decision or a gap for it: write `source: {kind: pending_mapping, "
                 "spec_identifiers: [...]}` carrying the spec's own identifiers verbatim. That state "
                 "IS the backlog — it is countable and barred from approval (I18). A gap is an "
                 "APPROVED requirement the build cannot satisfy, which is a different thing and "
                 "arrives later; demanding one here made I2 fail on every new product. And the "
                 "missing registry does not make the record `decision_required`: the requirement axis "
                 "and the source-mapping axis are separate.")

    if s["style"]:
        L.append(f"\n## {len(s['style'])} nearby record(s) — REDACTED SKELETONS\n")
        L.append("Field order, container shape and punctuation only. Every answer-bearing value has "
                 "been replaced with `…` before you saw it, so a neighbour's window, tie-break or "
                 "source cannot become a default for yours — this is a property of the document, not "
                 "an instruction you are being asked to follow.\n")
        for b in s["style"]:
            L.append("```")
            L.append(b)
            L.append("```")
    return "\n".join(L) + "\n"


def boundary_errors(s):
    """Where THIS slice reproduces vendor documentation, as [(where, marker, excerpt)].

    Scans the assembled slice rather than the pack, because the slice is what AI actually receives —
    a vendor file elsewhere in the tree is a separate (real) problem, but it is not this one. Each
    section is scanned under its own label so the message names a spec row or a record, which is what
    makes the fix a ten-minute edit instead of a search.

    `source` mappings are deliberately NOT scanned differently from anything else: the markers name
    vendor DOCUMENTS, never vendor tables, so `Enhanced_MetProstate` passes through untouched. See
    `governance/ai_boundary.yaml` — that distinction is the whole reason this is not a vendor-name
    scan, which would refuse every slice in the repository.
    """
    found = []
    for r in s["rows"]:
        text = " ".join([str(r.get("variable") or "")]
                        + [str(v) for v in (r.get("fields") or {}).values()]
                        + [v for _, v in (r.get("spec_columns_unmapped") or [])])
        found += [(f"spec row {r['item_id']}", m, e) for m, e in sm.vendor_prose(text)]
    for b in s["current_records"]:
        vid = next((ln.split(":", 1)[1].strip() for ln in b.splitlines()
                    if ln.startswith("variable_id:")), "?")
        found += [(f"contract record {vid}", m, e) for m, e in sm.vendor_prose(b)]
    for r in s["scaffold"]:
        found += [(f"scaffold {r.get('variable_id', '?')}", m, e)
                  for m, e in sm.vendor_prose(json.dumps(r, ensure_ascii=False))]
    return found


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("product", help="path to a product pack")
    ap.add_argument("--domain", required=True, help="one of the pack's spec domains")
    ap.add_argument("--variable", help="narrow to a single variable within that domain; refused when "
                                       "the name matches more than one row")
    ap.add_argument("--item", action="append", dest="items", metavar="DOMAIN:ROW",
                    help="narrow to one spec item (clinical:61) or a range (clinical:61-108); "
                         "repeatable. Parsed by the same expander the contract lint uses.")
    ap.add_argument("--style-records", type=int, default=STYLE_CAP,
                    help=f"nearby records to include as REDACTED skeletons (default {STYLE_CAP}; "
                         f"their answer-bearing values are replaced with '…' either way)")
    ap.add_argument("--out", help="write here instead of stdout")
    ap.add_argument("--json", action="store_true", help="emit the slice as JSON rather than markdown")
    a = ap.parse_args(argv)

    s = slice_pack(a.product, a.domain, a.variable, a.style_records, a.items)
    text = json.dumps(s, indent=1, ensure_ascii=False) if a.json else render(s)
    if a.out:
        with open(a.out, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
        whole = os.path.getsize(os.path.join(a.product, "spec_pipeline", "out", "extracted.json"))
        print(f"{a.out}  ~{len(text) // 4 // 1000 or 1}k tokens "
              f"(extracted.json whole is ~{whole // 4 // 1000}k)", file=sys.stderr)
    else:
        sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
