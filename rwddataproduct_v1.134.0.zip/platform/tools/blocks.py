#!/usr/bin/env python3
"""What a pack's config may NAME — the engine's vocabulary, printed.

    python3 platform/tools/blocks.py            # every named thing config can select
    python3 platform/tools/blocks.py --check    # CI: every registry still resolves

The engine is reusable blocks assembled by config: a formula is chosen by NAME from a registry, a
codelist is built from a fixed set of match operators, a follow-up source is named rather than
spelled out. That is what makes adding a tumour mostly configuration — and it is discoverable only
by reading engine source, which is the honest answer to "how would a first-time analyst know which
function to put in the config?" today. This prints it instead.

DERIVED, NEVER RESTATED. Every name below is imported from the module that owns it, so a formula
added to the engine appears here on the next run and one removed disappears. A hand-written list
would be a second copy of the engine's vocabulary — right on the day it was typed, and wrong from
the first edit after, which is worse than no list because a stale catalogue is still believed.

WHAT IT IS NOT: a substitute for `validate.py`. This says what MAY be named; the validator says
whether THIS pack named it correctly, and refuses an unknown value with the valid ones listed. Read
this to author, run that to check.

stdlib only.
"""
import argparse
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
PLATFORM = os.path.dirname(TOOLS)
sys.path.insert(0, os.path.join(PLATFORM, "engine"))

# Imported from the modules that OWN these, exactly as validate.py imports them — the whole design
# is that this file holds no vocabulary of its own. clinical.py's module level is PySpark-free
# (pyspark is imported inside each stage function), so this stays a cheap, side-effect-free import.
from codelists import MATCH_OPERATORS  # noqa: E402
from stages.clinical import (BMI_FORMULAS, BSA_FORMULAS, DATE_BASIS,              # noqa: E402
                             DEATH_CONFLICT_POLICIES, FOLLOWUP_FILTERS,           # noqa: E402
                             FOLLOWUP_SOURCES, RECORD_PICK, TIE_BREAK,            # noqa: E402
                             VALUE_MATCHERS)                                      # noqa: E402
import validate  # noqa: E402

WIDTH = 94


def sections():
    """(title, config key, what it is, {name: description}) — one per selectable vocabulary.

    The `config key` is the whole point: a list of valid names is not much use without the field
    that takes them. Ordered as an analyst meets them, not alphabetically.
    """
    return [
        ("MATCH OPERATORS", "codelists/*.yaml -> categories[].match",
         "How a codelist row decides whether a treatment belongs to a category. Exactly one "
         "operator per match; first matching category wins, so the last row is normally `always`.",
         dict(MATCH_OPERATORS)),

        ("VALUE MATCHERS", "config -> ...groups[].from_*",
         "How a group claims a raw value. Order is fixed by the compiler, not by the file: "
         "`when: missing` first, then exact, then the LONGEST matching prefix, then substring, then "
         "regex, then `when: fallthrough` — most specific to most general, so a group that claims a "
         "value exactly is never beaten by one that merely matches its shape. An unrecognised "
         "`from_*` key is refused, not ignored.",
         dict(VALUE_MATCHERS)),

        ("RECORD DATE BASIS", "config -> clinical.<panel>.date_basis",
         "Which date a record is measured by. `later_of` is what a feed shipping two candidate "
         "dates and no single one needs — a config edit rather than an engine change.",
         dict(DATE_BASIS)),

        ("RECORD PICK", "config -> clinical.<panel>[.panel[]].pick",
         "Which row of a long table represents the patient, once the window has been applied. "
         "Statable per panel or per item; an item overrides its block.",
         dict(RECORD_PICK)),

        ("RECORD TIE-BREAK", "config -> clinical.<panel>[.panel[]].tie_break",
         "Which record wins when two are equally near the anchor, or fall on the same date.",
         dict(TIE_BREAK)),

        ("BMI METHOD", "config -> clinical.vitals.bmi_method",
         "Named body-mass-index formula. Config names it; the engine holds the arithmetic, so no "
         "pack carries a formula string.",
         {k: "the registered formula" for k in BMI_FORMULAS}),

        ("BSA METHOD", "config -> clinical.vitals.bsa_method",
         "Named body-surface-area formula. Omit the key entirely and no BSA column is emitted.",
         {k: "the registered formula" for k in BSA_FORMULAS}),

        ("FOLLOW-UP ROW FILTER", "config -> ...follow_up_sources[].filter_method",
         "Named predicate restricting which rows of a follow-up source count. Named rather than "
         "raw SQL so two engines can agree on it.",
         {k: "the registered predicate" for k in FOLLOWUP_FILTERS}),

        ("FOLLOW-UP SOURCES", "config -> ...follow_up_sources (names list)",
         "The activity sources whose latest date can end follow-up. A pack may restrict the "
         "default set to the sources its vendor actually delivers.",
         {t[0]: f"date column `{t[1]}`" for t in FOLLOWUP_SOURCES}),

        ("DEATH CONFLICT POLICY", "config -> ...death_date_imputation conflict rule",
         "Which death date wins when sources disagree. ORDER CARRIES MEANING — the first is the "
         "default, and reordering the registry changes which date feeds OS, TTNT and PFS.",
         {p: ("the default" if i == 0 else "") for i, p in enumerate(DEATH_CONFLICT_POLICIES)}),

        ("VENDORS", "products/registry.yaml -> vendor",
         "Who delivers the data. Decides the Gate 3 evidence route via governance/vendor_policy.yaml.",
         {v: "" for v in sorted(validate.KNOWN_VENDORS)}),

        ("TUMOUR CLASSES", "products/registry.yaml -> tumor_class",
         "Solid or heme. Not a cosmetic label: heme packs legitimately declare fewer sources.",
         {c: "" for c in sorted(validate.KNOWN_TUMOR_CLASSES)}),

        ("REQUIRED SOURCES", "config -> sources",
         "The source keys the shared engine genuinely requires. Everything else is optional — a "
         "pack declares only what its vendor delivers.",
         {s: "" for s in sorted(validate.REQUIRED_SOURCES)}),

        ("VARIABLE PACK ROLES", "config -> variables (file stems)",
         "The variable files the engine expects a pack to carry.",
         {r: "" for r in sorted(validate.EXPECTED_ROLES)}),
    ]


def render():
    L = ["", "=" * WIDTH,
         "  WHAT A PACK'S CONFIG MAY NAME",
         "=" * WIDTH,
         "  Every name below is imported from the engine module that owns it — nothing here is",
         "  written down twice. `validate.py` refuses an unknown value and lists these same names,",
         "  so authoring and checking cannot disagree.", ""]
    for title, key, blurb, items in sections():
        L.append("-" * WIDTH)
        L.append(f" {title}")
        L.append(f"   {key}")
        L.append("-" * WIDTH)
        for line in _wrap(blurb, 3):
            L.append(line)
        L.append("")
        if not items:
            L.append("     (none registered)")
        width = max((len(k) for k in items), default=0)
        for name, desc in items.items():
            L.append(f"     {name:<{width}}   {desc}".rstrip())
        L.append("")
    L.append("-" * WIDTH)
    L.append("  A NAME IS NOT A DECISION. Choosing between these is judgment the specification has")
    L.append("  to settle — which BMI formula, which sources end follow-up, which death date wins.")
    L.append("  The engine offers the options; it does not know which one your product means.")
    L.append("")
    return "\n".join(L)


def _wrap(text, indent):
    import textwrap
    return textwrap.wrap(text, width=WIDTH - indent, initial_indent=" " * indent,
                         subsequent_indent=" " * indent)


def errors():
    """Everything that would make the catalogue lie. Empty is the healthy answer.

    A registry that has gone empty is the failure worth catching: the section still prints, with no
    names under it, and reads as "the engine offers nothing here" rather than as a broken import.
    """
    out = []
    for title, key, _, items in sections():
        if not items:
            out.append(f"{title} ({key}): no names registered — the engine offers nothing to select")
    return out


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true", help="exit non-zero if a registry is empty")
    a = ap.parse_args(argv)
    if a.check:
        bad = errors()
        for e in bad:
            print(e)
        print(f"{len(sections())} vocabulary section(s); {len(bad)} error(s)")
        return 1 if bad else 0
    print(render())
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
