#!/usr/bin/env python3
"""One command, one folder: every read-only page, ready for any static host.

    python3 platform/tools/publish_site.py --out ~/rwdp-site
    python3 platform/tools/publish_site.py --out ~/rwdp-site --serve   # local preview

WHY THIS EXISTS. The read surfaces already exist — the executive page, each pack's flow page,
each pack's question packet — but they are local files a specialist generates one at a time,
which makes them "a tool the RWD team has" rather than "a surface the organization reads".
This tool regenerates ALL of them into one out-of-checkout directory with an index, so hosting
becomes an IT act (point any static server at the folder), not an engineering one.

What the folder deliberately is: STATIC AND READ-ONLY. The pages accept no input, perform no
approvals, and say so; every page carries the commit it was generated from, so a stale copy is
detectable rather than quietly authoritative. A pack that cannot produce a page (no contract
yet, no register yet) appears on the index as an ABSENCE WITH ITS REASON — a missing link that
looks like a hosting glitch is how a blocked pack starts reading as a healthy one.

Regenerate on every push (or on a schedule); the folder is disposable and rebuilt whole.
"""
import argparse
import html
import os
import subprocess
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import pack_run                                                             # noqa: E402
from chat_demo import packs                                                 # noqa: E402


def _run(argv, out_path):
    r = subprocess.run([sys.executable, os.path.join(TOOLS, argv[0])] + argv[1:]
                       + ["--out", out_path],
                       capture_output=True, encoding="utf-8", cwd=ROOT, timeout=600)
    if r.returncode != 0 or not os.path.exists(out_path):
        return (r.stdout + r.stderr).strip().splitlines()[-1:] or ["no output"]
    return None


def _commit():
    r = subprocess.run(["git", "rev-parse", "--short", "HEAD"], capture_output=True,
                       encoding="utf-8", cwd=ROOT, timeout=60)
    return (r.stdout or "").strip() or "uncommitted"


def build(out_dir, only=None):
    """Generate every page into `out_dir`. Returns the index model: what exists, what could
    not be generated and why — absence is content, never a dead link."""
    os.makedirs(out_dir, exist_ok=True)
    commit = _commit()
    entries, problems = [], []

    err = _run(["executive_page.py"], os.path.join(out_dir, "executive.html"))
    if err:
        problems.append(f"executive page: {'; '.join(err)}")
    else:
        entries.append(("executive.html", "Executive page",
                        "every pack's six gates, next owner, and the decision-leverage table"))

    for slug, pack in packs():
        if only and slug not in only:
            continue
        for tool, suffix, label, desc in (
                (["render_html.py", "flow", pack], "flow", "status",
                 "the six gates and what blocks each"),
                (["decision_packet.py", pack], "questions", "open questions",
                 "one page per open decision, for the person who must answer it")):
            name = f"{slug}_{suffix}.html"
            err = _run(tool, os.path.join(out_dir, name))
            if err:
                problems.append(f"{slug} {label}: {'; '.join(err)}")
            else:
                entries.append((name, f"{slug} — {label}", desc))

    e = html.escape
    L = ["<meta charset='utf-8'><title>RWD data products — read-only surfaces</title>",
         "<style>body{font:16px/1.55 system-ui;max-width:52rem;margin:2rem auto;padding:0 1rem;"
         "color:#22211f;background:#fbfaf8}h1{font-size:1.4rem}li{margin:.45rem 0}"
         ".why{color:#6d6a63;font-size:.9rem}.abs{color:#9c3a2e}.foot{color:#6d6a63;"
         "font-size:.82rem;border-top:1px solid #e2ded6;margin-top:2rem;padding-top:1rem}"
         "</style>",
         "<h1>RWD data products — read-only surfaces</h1>",
         "<p class='why'>Generated pages, regenerated whole from the repository. Nothing here "
         "accepts input or performs an approval — approvals are committed file edits by named "
         "people.</p><ul>"]
    for name, title, desc in entries:
        L.append(f"<li><a href='{e(name)}'>{e(title)}</a> <span class='why'>— {e(desc)}"
                 f"</span></li>")
    L.append("</ul>")
    if problems:
        L.append("<h1>Not generated, and why</h1><ul>")
        L += [f"<li class='abs'>{e(p)}</li>" for p in problems]
        L.append("</ul>")
    L.append(f"<p class='foot'>commit {e(commit)} · regenerate with "
             f"<code>python3 platform/tools/publish_site.py --out &lt;dir&gt;</code></p>")
    with open(os.path.join(out_dir, "index.html"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(L))
    return {"pages": [n for n, _t, _d in entries], "problems": problems, "commit": commit}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--out", required=True,
                    help="site directory — required, refused inside the checkout")
    ap.add_argument("--packs", help="comma-separated slugs (default: every real pack)")
    ap.add_argument("--serve", action="store_true", help="serve the folder locally after build")
    ap.add_argument("--port", type=int, default=8399)
    a = ap.parse_args(argv)
    out = pack_run.restricted_dir(a.out, what="the published site")
    r = build(out, only=set(a.packs.split(",")) if a.packs else None)
    print(f"OK — {len(r['pages'])} page(s) + index at {out} (commit {r['commit']}); "
          f"{len(r['problems'])} absence(s) listed on the index")
    if a.serve:
        import functools                              # noqa: PLC0415
        from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer  # noqa: PLC0415
        h = functools.partial(SimpleHTTPRequestHandler, directory=out)
        print(f"serving http://127.0.0.1:{a.port} (Ctrl-C stops; localhost only)")
        try:
            ThreadingHTTPServer(("127.0.0.1", a.port), h).serve_forever()
        except KeyboardInterrupt:
            pass
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
