#!/usr/bin/env python3
"""One output, its whole provenance, on one page — the receipt an ad-hoc query cannot print.

    python3 platform/tools/receipt.py products/oncology/prostate/202606 --variable ID3MOSFU
    python3 platform/tools/receipt.py <pack> --variable <VARIABLE_ID> --json

WHY THIS EXISTS. Every number this platform publishes is the end of a chain a person can audit:
the specification's words, the contract record that interpreted them, the decisions a named human
answered, the YAML that runs, the name the output carries, and the build that produced the cut.
Each link already has an owner (`rule_review`, the decisions register, `contract_binding`,
`naming_registry`, the refresh ledger) — this tool ASSEMBLES them for one variable and adds
nothing. It judges nothing: every cell is quoted from the artifact that owns it, and ABSENCE IS
PRINTED AS ABSENCE — a missing decision row, an unresolved config ref, or a ledger with no build
is a line on the receipt, never a blank.

The deep views stay where they are: `rule_review.py <pack> --variable X` shows the rule three
ways in full; `decision_packet.py` carries the open questions to their owners. The receipt is the
one-page summary a stakeholder holds while asking "where did this number come from".
"""
import argparse
import json
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)

import contract_lint as cl                                                  # noqa: E402
import decision_report                                                      # noqa: E402
import naming_registry                                                      # noqa: E402
import product_gates as pg                                                  # noqa: E402
import rule_review                                                          # noqa: E402
from spec_extract import repo_relative                                      # noqa: E402


def _blank_dash(text):
    """The register writes an em dash for "no value yet" — that is absence, not an answer."""
    text = (text or "").strip().strip("*").strip()
    return "" if text in ("—", "-") else text


def _decisions(pack, cited):
    """One row per decision the record cites, from the register that owns them. A cited id the
    register does not carry is a finding, not a silent drop.

    Every cell is read through `contract_lint`'s shared column vocabulary — the registers already
    spell the answer column three ways (`Approved answer` / `Resolution` / …), and a private
    column list here rendered oc's recorded answers as ABSENT, which on a receipt whose whole
    pitch is "absence printed as absence" is the worst possible inversion."""
    _blocks, table, _idle, status = decision_report.blast_radius(pack)
    out = []
    for did in cited:
        row = table.get(did)
        if row is None:
            out.append({"decision": did, "in_register": False,
                        "note": "cited by the contract record but NOT in the decisions register — "
                                "one of the two is wrong, and a person must say which"})
            continue
        out.append({
            "decision": did, "in_register": True, "status": status.get(did, "OPEN"),
            "question": _blank_dash(cl.decision_question(row)),
            "owner": _blank_dash(cl.cell(row, *cl.OWNER_COLUMNS)),
            "approved_answer": _blank_dash(cl.decision_answer(row)),
            "approved_by": _blank_dash(cl.cell(row, *cl.APPROVER_COLUMNS)),
            "approval_date": _blank_dash(cl.cell(row, *cl.APPROVAL_DATE_COLUMNS)),
        })
    return out


def _naming(entry):
    """Where the output's physical name lives, per the cross-pack registry. `physical_name` is
    read from the record's own output field; a record that has not stated one gets that said."""
    output_text = dict(entry["interpreted"]).get("Resulting output", "")
    m = re.search(r"physical_name:\s*([A-Za-z][A-Za-z0-9_]*)", output_text)
    if not m:
        return {"physical_name": None,
                "note": "the record's output field states no physical_name yet"}
    name = m.group(1).lower()
    rec = naming_registry.registry().get(name)
    if rec is None:
        return {"physical_name": name,
                "note": "not in the naming registry — no other pack and no engine stage carries "
                        "this name"}
    return {"physical_name": name, "engine_emits_it": rec["engine"],
            "packs": dict(rec["packs"]), "variable_ids": list(rec["variable_ids"])}


def _build(pack):
    """The refresh ledger's word on whether any governed build exists for this pack — and the
    latest manifest's identity when one does. No manifest is a STATEMENT, not an empty section."""
    rel = repo_relative(pack)
    ledger = os.path.join(ROOT, "refreshes", *rel.split("/")[1:])
    entries = sorted(f for f in os.listdir(ledger)) if os.path.isdir(ledger) else []
    entries = [f for f in entries if f.endswith(".yaml")]
    if not entries:
        return {"recorded": False, "ledger": repo_relative(ledger),
                "note": "NO BUILD RECORDED — this receipt covers definition provenance only; a "
                        "governed run adds the manifest here (engine version, digests, data cut)"}
    m, err = pg.read_yaml(os.path.join(ledger, entries[-1]))
    if err:
        return {"recorded": False, "ledger": repo_relative(ledger),
                "note": f"MANIFEST UNREADABLE — {entries[-1]}: {err}. A ledger entry that "
                        f"cannot be read is a finding, not an empty section"}
    return {"recorded": True, "refresh": entries[-1][:-5],
            "manifests_in_ledger": len(entries),
            "engine_version": m.get("engine_version"),
            "git_commit": m.get("git_commit"),
            "built_at": m.get("built_at"),
            "status": m.get("status"),
            "output_table": m.get("output_table")}


def receipt(pack, variable):
    """The assembled chain for one variable, every section from its owner. Refuses an unknown
    variable by NAMING the contract's real ids — a wrong guess must not print an empty receipt."""
    entries = rule_review.chain(pack, variable)
    if not entries:
        known = [e["variable_id"] for e in rule_review.chain(pack)]
        if not known:
            sys.exit(f"no contract at {pack}/handoff/FUNCTIONAL_CONTRACT.md — nothing has been "
                     f"traced from a specification, so there is no chain to print")
        sys.exit(f"`{variable}` is not a variable_id in this pack's contract "
                 f"({len(known)} record(s): {', '.join(sorted(known))})")
    e = entries[0]
    return {
        "pack": repo_relative(pack),
        "variable_id": e["variable_id"],
        "specification": e["spec"],
        "contract": {"derivation": e["derivation"], "status": e["status"],
                     "interpreted": [(label, text) for label, text in e["interpreted"] if text]},
        "decisions": _decisions(pack, e["decisions"]),
        "config": {"resolved": [ref for ref, _f in e["executable"]],
                   "unresolved": list(e["unresolved"])},
        "naming": _naming(e),
        "build": _build(pack),
    }


def _wrap(text, indent="      "):
    """rule_review owns the word-wrapper; this only adds the receipt's indent."""
    return [indent + line for line in rule_review._wrap(text, 92 - len(indent))]


def render(r):
    L = ["=" * 92, f"  RECEIPT — {r['variable_id']}  ·  {r['pack']}", "=" * 92]
    s = r["specification"]
    L += ["", "  1. SPECIFICATION"]
    L += [f"      cited: {', '.join(s['refs']) or '— (no spec_refs on the record)'}"]
    if s["digest"]:
        L += [f"      digest: {s['digest']}"]
    L += _wrap(f"“{s['rule']}”") if s["rule"] else ["      (the record quotes no required_rule)"]
    L += ["", "  2. CONTRACT RECORD"]
    L += _wrap(f"derivation: {r['contract']['derivation'] or '—'}")
    if r["contract"]["status"]:
        L += [f"      status: {r['contract']['status']}"]
    for label, text in r["contract"]["interpreted"]:
        L += _wrap(f"{label}: {text}")
    L += ["", "  3. DECISIONS (from the register — quoted, never judged here)"]
    if not r["decisions"]:
        L += ["      the record cites no decisions"]
    for d in r["decisions"]:
        if not d["in_register"]:
            L += _wrap(f"{d['decision']}: {d['note']}")
            continue
        L += [f"      {d['decision']} — {d['status']} · owner {d.get('owner') or '—'}"]
        L += _wrap(d.get("question", ""), indent="          ")
        if d.get("approved_answer"):
            L += _wrap(f"answer ({d.get('approved_by') or 'UNATTRIBUTED'}, "
                       f"{d.get('approval_date') or 'UNDATED'}): {d['approved_answer']}",
                       indent="          ")
    L += ["", "  4. EXECUTABLE CONFIG (rule_review.py shows each block in full, three ways)"]
    for ref in r["config"]["resolved"]:
        L += [f"      {ref}"]
    for ref in r["config"]["unresolved"]:
        L += [f"      {ref}  — UNRESOLVED: named by the record, not found in the active config"]
    if not (r["config"]["resolved"] or r["config"]["unresolved"]):
        L += ["      the record names no implementation refs"]
    n = r["naming"]
    L += ["", "  5. NAME"]
    if n.get("note"):
        L += _wrap(f"{n.get('physical_name') or '—'}: {n['note']}")
    else:
        packs = ", ".join(f"{p} ({st})" for p, st in sorted(n["packs"].items())) or "no pack"
        L += _wrap(f"{n['physical_name']} — engine emits it: "
                   f"{'yes' if n['engine_emits_it'] else 'no'}; contracts: {packs}")
    b = r["build"]
    L += ["", "  6. BUILD"]
    if not b["recorded"]:
        L += _wrap(b["note"])
    else:
        L += [f"      refresh {b['refresh']} · engine {b['engine_version']} · "
              f"commit {b['git_commit'] or '—'} · {b['built_at']}",
              f"      manifest status: {b['status']} · output: {b['output_table'] or '—'} · "
              f"{b['manifests_in_ledger']} manifest(s) in the ledger"]
    L += ["", "=" * 92]
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack")
    ap.add_argument("--variable", required=True, help="one variable_id from the pack's contract")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    r = receipt(a.pack, a.variable)
    print(json.dumps(r, indent=2, sort_keys=True) if a.json else render(r))
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main())
