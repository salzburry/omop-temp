#!/usr/bin/env python3
"""What a new spec revision ACTUALLY changed — and which records can carry forward.

    python3 platform/tools/spec_diff.py <old pack> <new pack>

WHY THIS EXISTS. prostate/202607 holds 200 spec rows and prostate/202606 holds 200; 196 of them are
BYTE-IDENTICAL and none changed. It is the same specification one revision later. It was nonetheless
re-extracted from scratch, re-drafted into 199 records, and its 22 decisions were raised under new
ids — only 6 ids are shared, and NEITHER of the two answers 202606 had settled carried across. The
questions recurred, the answers did not, and the only thing bridging the two versions is a
hand-curated store where seven of nine entries read "prostate, prostate".

That is the cost of having no reuse: a revision that changed nothing cost a full re-draft.

THE PROOF IS ALREADY IN THE RECORD. `spec_digest` is a digest over `item_id + content_hash` for
every cited row — it binds a record to the specification TEXT, not to a row number, which is exactly
why I15 catches an edit made in place. So the question "may this record carry forward" is already
answerable with evidence: recompute the record's digest against the NEW extraction and see whether
it still matches. Nothing here re-derives that; `contract_lint.spec_digest` is the one definition and
this calls it.

THREE ANSWERS, and the distinction between the last two is the point:

  CARRIES AS-IS        the digest recomputes identical — the cited text is unchanged
  CARRIES, NEW REF     the cited text still exists but has MOVED to a different row number, so the
                       record needs `spec_refs` updated and nothing else. Rows shift whenever a
                       revision inserts anything above them, and a tool that called this "changed"
                       would send a person to re-read text that is word-for-word the same.
  RE-DRAFT             the cited text changed, or is gone

FAIL-CLOSED: anything whose digest cannot be computed is RE-DRAFT, never carried. A record wrongly
carried forward is a requirement nobody re-read, asserting a rule the specification may no longer
make — which is worse than re-reading one that did not need it.

AND WHETHER THE SPECIFICATION'S OWN DEFECTS WERE FIXED. The old pack's SPEC_QC_FINDINGS.md names
rows RWB was asked to correct. A new revision either changed those rows or it did not, and that is
checkable the same way carrying is: by CONTENT, not by row number. Every open finding is reported as
"cited text unchanged — the defect is still there" or "cited text changed/gone — review the new
text, then set the finding corrected or waived". A revision can be nominally new and fix nothing;
this section is what says so before anyone re-drafts against the same defects.

BY DEFAULT IT WRITES NOTHING and it carries nothing. `--carry-plan <dir>` is the one deliberate
exception: it writes DRAFT JUDGMENTS — the drafter-owned fields of each carrying record, with no
status and no spec fields — plus the exact `contract_record.py --item` command per record, into a
directory OUTSIDE both packs. Running those commands is still the human act, and each one passes
the full drafting path: every invariant, the AI gate, the redaction refusals. Nothing is ever
written into either pack by this tool.

stdlib plus PyYAML (the judgment files are YAML, like every draft).
"""
import argparse
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(TOOLS))
sys.path.insert(0, TOOLS)
from spec_extract import repo_relative                                  # noqa: E402

import contract_lint as cl   # noqa: E402

WIDTH = 94
CONTRACT = os.path.join("handoff", "FUNCTIONAL_CONTRACT.md")

AS_IS = "carries as-is"
NEW_REF = "carries, needs a new spec_refs"
REDRAFT = "re-draft"


def _rows(pack, root):
    """{domain: {row: content hash}} for a pack, or None when it has no extraction."""
    return cl.spec_rows(os.path.join(root, pack))


def spec_delta(old, new, root=ROOT):
    """(counts, note) comparing two extractions by CONTENT, not by row number.

    Keyed on the content hash within a domain, because a row number is a position and a position
    moves for reasons that have nothing to do with the text.
    """
    a, b = _rows(old, root), _rows(new, root)
    if a is None or b is None:
        missing = old if a is None else new
        return None, (f"{missing} has no spec_pipeline/out/extracted.json — there is nothing to "
                      f"compare, so nothing was compared.")
    ha = {(d, h) for d, rows in a.items() for h in rows.values()}
    hb = {(d, h) for d, rows in b.items() for h in rows.values()}
    return {"old_rows": sum(len(r) for r in a.values()),
            "new_rows": sum(len(r) for r in b.values()),
            "unchanged": len(ha & hb), "removed": len(ha - hb), "added": len(hb - ha)}, None


def carry(old, new, root=ROOT):
    """[(variable_id, verdict, detail)] for every record in the OLD pack.

    The verdict is derived from `contract_lint.spec_digest` recomputed against the NEW extraction —
    the same function I15 uses, on the same inputs, differing only in which extraction it is handed.
    """
    old_dir, new_dir = os.path.join(root, old), os.path.join(root, new)
    new_srows, old_srows = cl.spec_rows(new_dir), cl.spec_rows(old_dir)
    if new_srows is None or old_srows is None:
        return None
    old_vars, new_vars = cl.spec_variables(old_dir), cl.spec_variables(new_dir)
    # content hash -> the row numbers holding it in the NEW extraction, for the moved-row case
    moved = {}
    for domain, rows in new_srows.items():
        for n, h in rows.items():
            moved.setdefault((domain, h), []).append(n)

    out = []
    for block in cl.records(cl.read(os.path.join(old_dir, CONTRACT))):
        vid = (cl._scalar(block, "variable_id") or "?").strip()
        refs = cl._list(block, "spec_refs") or []
        recorded = cl._scalar(block, "spec_digest")
        if not refs or refs == [cl.NO_SPEC_ROW] or not recorded or recorded == cl.NA:
            out.append((vid, REDRAFT, "cites no spec row, or carries no digest to check"))
            continue
        current = cl.spec_digest(refs, new_srows)
        if current and recorded == current:
            out.append((vid, AS_IS, ""))
            continue
        # Did the cited TEXT survive at a different row number? Look each cited row's OLD content
        # hash up in the new extraction. Only when every cited row moved intact is this a rename.
        cited, found = [], []
        for ref in refs:
            for domain, n in (cl.spec_ref_rows(ref) or []):
                h = (old_srows.get(domain) or {}).get(n)
                cited.append((domain, n, h))
                found.append(moved.get((domain, h), []) if h else [])
        if cited and all(f for f in found):
            where = ", ".join(f"{d}:{n}->{'/'.join(str(x) for x in f)}"
                              for (d, n, _h), f in zip(cited, found))
            out.append((vid, NEW_REF, where))
            continue
        # The text did NOT survive intact — the record is RE-DRAFT, fail-closed, always. What the
        # matcher adds is WHERE to re-read: spec_extract's own recipe (domain + variable name +
        # content hash + coordinates, ambiguity to a person). A same-name row in the same domain is
        # the likely successor of an in-place edit; naming it turns "re-draft blind" into "re-read
        # here", and naming several turns silence into a person's choice. It never turns a changed
        # row into a carry — a name is not an identity, and the re-read is the point.
        successor = ""
        if len(cited) == 1:
            domain, n, _h = cited[0]
            name = old_vars.get((domain, n), "")
            if name:
                cands = sorted(nn for (dd, nn), v in new_vars.items()
                               if dd == domain and v == name)
                if len(cands) == 1:
                    successor = (f"; likely successor {domain}:{cands[0]} (same variable name "
                                 f"{name!r}) — re-read the new text there, then draft with "
                                 f"--item {domain}:{cands[0]}")
                elif cands:
                    successor = (f"; AMBIGUOUS successors {', '.join(f'{domain}:{c}' for c in cands)} "
                                 f"(variable name {name!r} appears on each) — a person chooses; "
                                 f"the matcher does not guess")
        if current:
            out.append((vid, REDRAFT, f"cited text changed — digest {recorded} is now {current}"
                                      + successor))
        else:
            out.append((vid, REDRAFT, "a cited row is absent from the new extraction" + successor))
    return out


# The refs a finding cites, as written in its `Spec ref` cell — backticked `tab:row` tokens,
# expanded through the ONE expansion (`spec_ref_rows`), so a range cites every row it covers.
_FINDING_REF = re.compile(r"`([a-z_]+:\d+(?:-\d+)?)`")

STILL_THERE = "still there"
CHANGED = "changed — review"
UNCHECKABLE = "uncheckable"


def findings_check(old, new, root=ROOT):
    """([(finding id, verdict, detail)], note) — did the new revision fix what was reported?

    Content-based, like `carry`: a cited row's OLD text is looked up ANYWHERE in the new extraction's
    same domain, so a row that merely moved cannot read as corrected. Fail-closed the other way too:
    a finding whose refs cannot be parsed or whose cited rows are not in the OLD extraction is
    UNCHECKABLE, never silently dropped — a defect this cannot see is not a defect that went away.
    """
    reg_path = os.path.join(root, old, "handoff", "SPEC_QC_FINDINGS.md")
    if not os.path.exists(reg_path):
        return None, f"{old} keeps no handoff/SPEC_QC_FINDINGS.md — no findings to check."
    rows = cl.decision_rows(cl.read(reg_path))
    open_ids = {fid: row for fid, row in rows.items()
                if cl._status_text(cl.cell(row, "Status")) == "OPEN"}
    if not open_ids:
        return [], None
    old_srows, new_srows = cl.spec_rows(os.path.join(root, old)), cl.spec_rows(os.path.join(root, new))
    if old_srows is None or new_srows is None:
        which = old if old_srows is None else new
        return None, f"{which} has no extraction — the findings cannot be checked against it."

    out = []
    for fid, row in sorted(open_ids.items()):
        cited = [(d, n) for tok in _FINDING_REF.findall(cl.cell(row, "Spec ref"))
                 for d, n in cl.spec_ref_rows(tok)]
        if not cited:
            out.append((fid, UNCHECKABLE, "its Spec ref cell carries no `tab:row` citation"))
            continue
        survived, moved_away, unknown = [], [], []
        for d, n in cited:
            h = (old_srows.get(d) or {}).get(n)
            if not h:
                unknown.append(f"{d}:{n}")
            elif h in (new_srows.get(d) or {}).values():
                where = sorted(m for m, hh in (new_srows.get(d) or {}).items() if hh == h)
                survived.append(f"{d}:{n}" + ("" if n in where else f"->{'/'.join(map(str, where))}"))
            else:
                moved_away.append(f"{d}:{n}")
        if unknown:
            out.append((fid, UNCHECKABLE,
                        f"cited row(s) {', '.join(unknown)} are not in the old extraction — the "
                        f"citation itself needs correcting before this can be tracked"))
        elif not moved_away:
            out.append((fid, STILL_THERE,
                        f"cited text unchanged in the new revision ({', '.join(survived)})"))
        else:
            what = f"changed/gone: {', '.join(moved_away)}"
            if survived:
                what += f"; unchanged: {', '.join(survived)}"
            out.append((fid, CHANGED, what))
    return out, None


# What a carried judgment may CARRY. Everything the drafter owns; nothing the machine or a human
# transition owns. `status` is absent so contract_record injects INITIAL_STATUS — an approval never
# carries by omission — and the MACHINE_OWNED spec fields are absent so they are re-supplied from
# the NEW extraction via --item, which is the entire evidentiary point of re-drafting against it.
CARRIED_FIELDS = tuple(k for k in cl.TABLE_COLUMNS
                       if k not in ("spec_refs", "spec_digest", "required_rule", "status"))


def carry_plan(old, new, out_dir, root=ROOT):
    """(written, commands, by_hand, excluded, note) — the re-draft turned into a checklist.

    One judgment YAML per record whose text provably survives (AS_IS or NEW_REF), holding ONLY the
    drafter-owned fields, plus `carry_commands.txt` — the exact `contract_record.py` invocation per
    record, with `--item` pointing at the row in the NEW pack (moved rows already re-mapped by
    `carry`). Records citing several spec rows get no command — `--item` names one row — and are
    listed for a person instead of guessed at. RE-DRAFT records are excluded with their reason:
    carrying one would assert a judgment over text that changed, which is the failure this whole
    tool exists to prevent.

    The plan is written OUTSIDE both packs (out_dir is the caller's), and running the commands is
    still the human act: each one passes the full drafting path — every invariant, the AI gate, the
    redaction refusals — exactly as a hand-written draft would. Decision ids travel with the
    judgment; their register rows do not, so a carried record citing an unported decision fails I2
    until the register is brought across. That is correct: the citation is the reminder.
    """
    verdicts = carry(old, new, root)
    if verdicts is None:
        return [], [], [], [], "one of the packs has no extraction — nothing was planned."
    text = cl.read(os.path.join(root, old, CONTRACT))
    blocks = {}
    for block in cl.records(text):
        fields = {ln.split(":", 1)[0].strip(): ln.split(":", 1)[1].strip()
                  for ln in block.splitlines() if ":" in ln}
        blocks[fields.get("variable_id", "?")] = fields

    # old (domain, row) -> new rows carrying the same text, for re-pointing --item
    old_srows, new_srows = cl.spec_rows(os.path.join(root, old)), cl.spec_rows(os.path.join(root, new))
    moved = {}
    for domain, rows in (new_srows or {}).items():
        for n, h in rows.items():
            moved.setdefault((domain, h), []).append(n)

    import yaml
    os.makedirs(out_dir, exist_ok=True)
    written, commands, by_hand, excluded = [], [], [], []
    for vid, verdict, detail in verdicts:
        if verdict == REDRAFT:
            excluded.append((vid, detail))
            continue
        fields = blocks.get(vid) or {}
        judgment = {k: fields[k] for k in CARRIED_FIELDS if k in fields}
        path = os.path.join(out_dir, f"{vid}.yaml")
        head = (f"# Carried judgment — {vid}, from {old} (verdict: {verdict}).\n"
                f"# Drafter-owned fields only: no status (the tool injects the initial one), no\n"
                f"# spec fields (re-supplied from {new}'s extraction by --item).\n")
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(head + yaml.safe_dump(judgment, sort_keys=False, allow_unicode=True,
                                           width=100, default_flow_style=False))
        written.append(path)

        cited = [(d, n) for ref in (cl._list("spec_refs: " + fields.get("spec_refs", "[]"),
                                             "spec_refs") or [])
                 for d, n in cl.spec_ref_rows(ref)]
        targets = []
        for d, n in cited:
            h = (old_srows.get(d) or {}).get(n)
            targets.extend((d, m) for m in moved.get((d, h), []) if h)
        targets = sorted(set(targets))
        if len(targets) == 1:
            d, n = targets[0]
            commands.append(f"python3 platform/tools/contract_record.py {path} "
                            f"--product {new} --item {d}:{n} --apply")
        else:
            by_hand.append((vid, f"cites {len(cited)} spec row(s) resolving to "
                                 f"{len(targets)} target(s) — --item names one row, so a person "
                                 f"chooses"))
    if written:
        with open(os.path.join(out_dir, "carry_commands.txt"), "w", encoding="utf-8",
                  newline="\n") as fh:
            fh.write(f"# {len(commands)} record(s) carry mechanically; {len(by_hand)} need a "
                     f"person; {len(excluded)} are RE-DRAFT and are not here.\n")
            fh.write("\n".join(commands) + "\n")
            for vid, why in by_hand:
                fh.write(f"# BY HAND  {vid}: {why}\n")
            for vid, why in excluded:
                fh.write(f"# RE-DRAFT {vid}: {why}\n")
    return written, commands, by_hand, excluded, None


def carried_decisions(old, new, root=ROOT):
    """{decision id: (status, answer, [variable ids])} for decisions cited by records that carry.

    A settled answer attached to a requirement whose text did not change is the thing most worth
    not re-arguing — and it is precisely what was lost between 202606 and 202607.
    """
    verdicts = carry(old, new, root) or []
    keep = {vid for vid, v, _d in verdicts if v in (AS_IS, NEW_REF)}
    text = cl.read(os.path.join(root, old, "handoff", "DECISIONS.md"))
    rows, status = cl.decision_rows(text), cl.decision_status(text)
    out = {}
    for block in cl.records(cl.read(os.path.join(root, old, CONTRACT))):
        vid = (cl._scalar(block, "variable_id") or "").strip()
        if vid not in keep:
            continue
        for did in (cl._list(block, "decision_ids") or []):
            if did not in rows:
                continue
            entry = out.setdefault(did, [status.get(did, ""), cl.decision_answer(rows[did]) or "", []])
            entry[2].append(vid)
    return {d: (s, a, sorted(v)) for d, (s, a, v) in out.items()}


def render(old, new, root=ROOT):
    L = ["", "=" * WIDTH, f"  SPEC REVISION DIFF — {old}  ->  {new}", "=" * WIDTH]
    delta, note = spec_delta(old, new, root)
    if note:
        return "\n".join(L + ["", f"  {note}", ""])

    L += ["", f"  spec rows      {delta['old_rows']} -> {delta['new_rows']}",
          f"  unchanged      {delta['unchanged']}",
          f"  removed        {delta['removed']}",
          f"  added          {delta['added']}", ""]

    verdicts = carry(old, new, root)
    if verdicts is None:
        return "\n".join(L + ["  one of the packs has no extraction — records were not assessed.", ""])
    counts = {AS_IS: 0, NEW_REF: 0, REDRAFT: 0}
    for _v, verdict, _d in verdicts:
        counts[verdict] += 1
    L += ["-" * WIDTH, f"  {len(verdicts)} record(s) in {old}", "-" * WIDTH,
          f"     {counts[AS_IS]:4d}  {AS_IS}",
          f"     {counts[NEW_REF]:4d}  {NEW_REF}",
          f"     {counts[REDRAFT]:4d}  {REDRAFT}", ""]

    if counts[NEW_REF]:
        L.append("  MOVED — same text, different row. Update spec_refs; the digest is unchanged:")
        for vid, verdict, detail in verdicts:
            if verdict == NEW_REF:
                L.append(f"     {vid:22s} {detail}")
        L.append("")
    if counts[REDRAFT]:
        L.append("  RE-DRAFT — a person must re-read the specification for these:")
        for vid, verdict, detail in verdicts[:400]:
            if verdict == REDRAFT:
                L.append(f"     {vid:22s} {detail}")
        L.append("")

    dec = carried_decisions(old, new, root)
    settled = {d: v for d, v in dec.items() if str(v[0]).strip().upper() == "RESOLVED"}
    L += ["-" * WIDTH, f"  {len(dec)} decision(s) attach to records that carry — "
                       f"{len(settled)} of them already ANSWERED", "-" * WIDTH]
    if not dec:
        L.append("     None. Either nothing carries, or the carrying records cite no decision.")
    for did, (status, answer, vids) in sorted(settled.items()):
        L.append(f"     {did}  [{status}]  blocks {len(vids)} carried record(s)")
        L += _wrap(answer, 9, cap=4)
    still = {d: v for d, v in dec.items() if d not in settled}
    if still:
        L.append("")
        L.append(f"     still open, and they will be asked again unless carried: "
                 f"{', '.join(sorted(still))}")
    checks, fnote = findings_check(old, new, root)
    L += ["-" * WIDTH, f"  DID THE REVISION FIX WHAT WAS REPORTED?  ({old}'s open spec-QC findings)",
          "-" * WIDTH]
    if fnote:
        L.append(f"     {fnote}")
    elif not checks:
        L.append("     No open findings — nothing was awaiting correction.")
    else:
        for fid, verdict, detail in checks:
            L.append(f"     {fid:8s} {verdict:18s} {detail}")
        still = sum(1 for _f, v, _d in checks if v == STILL_THERE)
        if still:
            L.append("")
            L.append(f"     {still} defect(s) reported to RWB are UNCHANGED in the new revision. "
                     f"Re-drafting against")
            L.append("     them re-inherits them; return the findings register before adopting the "
                     "revision.")
        fixed = [f for f, v, _d in checks if v == CHANGED]
        if fixed:
            L.append("")
            L.append(f"     Review the new text for {', '.join(fixed)}, then set each finding "
                     f"`corrected` (or")
            L.append("     `waived`) in SPEC_QC_FINDINGS.md — the register is the record RWB's "
                     "round-trip closed.")
    L += ["", "-" * WIDTH,
          "  Nothing was written. A record carries because its spec_digest still matches the new",
          "  extraction — that is evidence, not an assumption — but moving it is a human act.", ""]
    return "\n".join(L)


def _wrap(text, indent, cap=4):
    import textwrap
    body = " ".join(str(text or "").split())
    if not body:
        return []
    return textwrap.wrap(body, width=WIDTH - indent, initial_indent=" " * indent,
                         subsequent_indent=" " * indent)[:cap]


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("old", help="the pack the records were drafted in")
    ap.add_argument("new", help="the pack the new specification landed in")
    ap.add_argument("--carry-plan", metavar="DIR",
                    help="write one judgment YAML per carrying record plus carry_commands.txt into "
                         "DIR (outside both packs). Refused inside either pack: the plan is an "
                         "input to drafting, not a pack artifact.")
    a = ap.parse_args(argv)
    if os.path.normpath(a.old) == os.path.normpath(a.new):
        sys.exit(f"{a.old}: old and new are the SAME pack — a pack diffed against itself "
                 f"reports every record carried and every defect unchanged, which reads "
                 f"as a verdict about a revision that was never compared. Name two packs.")
    packs = []
    for p in (a.old, a.new):
        rel = repo_relative(os.path.abspath(p), ROOT)
        if not os.path.isdir(os.path.join(ROOT, rel)):
            sys.exit(f"{p}: not a directory")
        packs.append(rel)
    print(render(*packs))
    if a.carry_plan:
        dest = os.path.realpath(a.carry_plan)
        for rel in packs:
            base = os.path.realpath(os.path.join(ROOT, rel))
            if dest == base or dest.startswith(base + os.sep):
                sys.exit(f"--carry-plan {a.carry_plan} is inside {rel} — the plan is an input to "
                         f"drafting, not a pack artifact. Point it somewhere outside both packs.")
        written, commands, by_hand, excluded, note = carry_plan(packs[0], packs[1], dest)
        if note:
            sys.exit(note)
        print(f"carry plan: {len(written)} judgment(s) in {a.carry_plan} — "
              f"{len(commands)} mechanical, {len(by_hand)} need a person, "
              f"{len(excluded)} RE-DRAFT (excluded). See carry_commands.txt.")
    return 0


if __name__ == "__main__":
    from console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
