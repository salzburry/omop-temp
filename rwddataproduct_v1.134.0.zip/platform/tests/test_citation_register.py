"""Citations carry a STRENGTH, and this pins that the shelf says what each one's is.

Before the register, `INVENTORY.yaml` hung a list of citation strings off each variable and the
README described in prose how they had been checked. The exceptions lived in per-tumour `caveats`,
and two of those said "a few citations carry journal/volume/page identity without a PMID or DOI" —
true, and unusable, because they never said which. A reader could not tell a citation resolved
against PubMed from one harvested off a search-results page.

`CITATIONS.yaml` gives each citation one record: identifier, the route it was checked by, the pass
that checked it, and whether the author list was confirmed. What is pinned here is that the two
files cannot drift, that a record cannot claim an identifier its citation does not carry, that the
weak ones stay NAMED where the variables are read, and — the point of the whole exercise — that the
claim binding is reported as empty rather than quietly implied to be full.

NO PYTEST FIXTURES AND NO `parametrize`, and that is not a style preference. CI runs every suite as
a SCRIPT, so a test taking a fixture argument cannot be CALLED outside pytest — the file would
import, define its tests, run none of them and exit 0. That is a green step protecting nothing, and
this suite shipped that way for one commit until
`test_spec_pipeline.test_every_suite_actually_runs_the_way_ci_invokes_it` caught it. Cases that
would be `parametrize` are loops that name the case they failed on.

Run: python3 tests/test_citation_register.py (or pytest).
"""
import copy
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))

import citation_register as cr  # noqa: E402


_CACHE = []


def live():
    """The register and the inventory, loaded once per process."""
    if not _CACHE:
        _CACHE.append((cr._load(cr.REGISTER), cr._load(cr.INVENTORY)))
    return _CACHE[0]


def test_the_live_register_validates():
    reg, inv = live()
    assert cr.register_errors(reg, inv) == []


def test_the_rendering_is_current():
    assert cr.main(["--check"]) == 0, \
        "CITATIONS.md is stale — regenerate: python3 platform/tools/citation_register.py"


def test_every_citation_the_shelf_uses_has_exactly_one_record():
    reg, inv = live()
    used = set(cr.uses(inv))
    recorded = [r["text"] for r in reg["citations"]]
    assert used == set(recorded), \
        f"unregistered: {sorted(used - set(recorded))[:3]}; orphans: {sorted(set(recorded) - used)[:3]}"
    assert len(recorded) == len(set(recorded)), "duplicate records"


def test_an_unregistered_citation_is_refused():
    reg, inv = live()
    reg = copy.deepcopy(reg)
    reg["citations"] = [r for r in reg["citations"] if "Griffith" not in r["text"]]
    errs = cr.register_errors(reg, inv)
    assert any("with no record in CITATIONS.yaml" in e for e in errs), errs


def test_an_orphan_record_is_refused():
    reg, inv = live()
    reg = copy.deepcopy(reg)
    reg["citations"].append({"text": "Nobody A et al. 2099, J Nothing, PMID 999999",
                             "identifier": {"kind": "pmid", "value": "999999"},
                             "route": "pubmed_or_publisher", "pass": "literature_2026_08_13",
                             "author_list_confirmed": True, "supports": []})
    errs = cr.register_errors(reg, inv)
    assert any("an orphan record" in e for e in errs), errs


def test_a_record_cannot_claim_an_identifier_its_citation_does_not_carry():
    """The defect that would make the register worse than no register: a PMID recorded beside a
    citation that never had one, which a reader would then treat as resolvable."""
    reg, inv = live()
    reg = copy.deepcopy(reg)
    reg["citations"][0]["identifier"] = {"kind": "pmid", "value": "12345678"}
    errs = cr.register_errors(reg, inv)
    assert any("does not occur in the citation" in e for e in errs), errs


def test_the_two_halves_of_no_identifier_must_agree():
    """`identifier_route_unavailable` on a citation carrying a DOI, or a PubMed route on one
    carrying nothing to resolve — either way the register would be describing a different string."""
    reg, inv = live()
    reg = copy.deepcopy(reg)
    doi = next(r for r in reg["citations"] if r["identifier"]["kind"] == "doi")
    doi["route"] = "identifier_route_unavailable"
    errs = cr.register_errors(reg, inv)
    assert any("but carries a PMID/DOI" in e for e in errs), errs

    reg2 = copy.deepcopy(live()[0])
    loc = next(r for r in reg2["citations"] if r["route"] == "identifier_route_unavailable")
    loc["route"] = "pubmed_or_publisher"
    errs = cr.register_errors(reg2, inv)
    assert any("must be identifier_route_unavailable" in e for e in errs), errs


OUT_OF_VOCABULARY = [
    ("route", "hearsay", "not in the declared vocabulary"),
    ("pass", "someone_told_me", "not in the declared vocabulary"),
    ("author_list_confirmed", "yes", "must be a boolean"),
    ("supports", "the definition", "supports must be a list"),
]


def test_a_field_outside_its_vocabulary_is_refused():
    _, inv = live()
    for field, value, needle in OUT_OF_VOCABULARY:
        reg = copy.deepcopy(live()[0])
        reg["citations"][0][field] = value
        errs = cr.register_errors(reg, inv)
        assert any(needle in e for e in errs), (field, needle, errs)


def test_records_are_counted_as_IDENTIFIERS_not_as_strings():
    """"281 distinct citations" counted STRINGS. 17 identifiers appear under more than one spelling,
    so 281 records cover 246 identifiers — a reader taking 281 for the breadth of the evidence reads
    a number 14% too large, and a claim binding keyed on the string would bind twice to one paper."""
    reg, inv = live()
    works = {cr.work_key(r) for r in reg["citations"] if cr._ident(r)[1]}
    assert len(works) < len(reg["citations"]), "no duplicate works — this test has lost its subject"
    md = (REPO / "governance" / "reference" / "variable_inventory" / "CITATIONS.md") \
        .read_text(encoding="utf-8")
    assert f"**{len(works)} distinct identifiers**" in md
    assert f"Read {len(works)}, not {len(reg['citations'])}" in md
    # ...and normalisation is what makes them one work: case and trailing punctuation are typing.
    assert cr.work_key({"identifier": {"kind": "pmid", "value": "29756355"}}) == \
        cr.work_key({"identifier": {"kind": "pmid", "value": "29756355."}})
    assert cr.work_key({"identifier": {"kind": "doi", "value": "10.1056/NEJMoa0912217"}}) == \
        cr.work_key({"identifier": {"kind": "doi", "value": "10.1056/nejmoa0912217"}})


def test_the_identifier_count_is_reported_as_an_UPPER_BOUND_on_the_papers():
    """NORMALISATION CANNOT MERGE SCHEMES, and printing its result as a work count is the same
    over-reading, one level down, that replacing 281 with 246 was meant to stop.

    `PMID 29756355` and `PMID: 29756355` are one string once case and punctuation go. `29756355`
    and `10.1111/1475-6773.13011` share no characters and can be one paper, and only resolving one
    of them tells you. So the rendering must say ceiling, and must print how many equivalences have
    actually been established rather than implying none exist.
    """
    reg, _inv = live()
    md = (REPO / "governance" / "reference" / "variable_inventory" / "CITATIONS.md") \
        .read_text(encoding="utf-8")
    assert "upper bound on the papers" in md, md[:900]
    assert f"**{len(reg.get(cr.SAME_WORK) or [])} such groups are recorded**" in md
    assert "distinct works" not in md, "the rendering still calls an identifier count a work count"


def test_a_declared_cross_scheme_equivalence_merges_two_records_into_one_work():
    """The affordance has to WORK, not merely validate. A group naming a PMID and a DOI for one
    paper must take the work count down by one and put both records under one key."""
    reg, _inv = live()
    reg = copy.deepcopy(reg)
    a, b = None, None
    for r in reg["citations"]:
        kind, _v = cr._ident(r)
        if kind == "pmid" and a is None:
            a = cr._ident(r)
        elif kind == "doi" and b is None:
            b = cr._ident(r)
    assert a and b, "need one pmid and one doi record — this test has lost its subject"

    before = len({cr.work_key(r) for r in reg["citations"] if cr._ident(r)[1]})
    reg[cr.SAME_WORK] = [{"identifiers": [{"kind": a[0], "value": a[1]},
                                          {"kind": b[0], "value": b[1]}],
                          "established_by": "J. Roe", "established_date": "2026-08-16",
                          "how": "resolved the DOI on doi.org; it returns the record indexed "
                                 "under that PMID"}]
    merges = cr.work_merges(reg)
    after = len({cr.work_key(r, merges) for r in reg["citations"] if cr._ident(r)[1]})
    assert after == before - 1, (before, after)
    assert cr.work_key({"identifier": {"kind": a[0], "value": a[1]}}, merges) == \
        cr.work_key({"identifier": {"kind": b[0], "value": b[1]}}, merges)
    assert cr.same_work_errors(reg, {cr._ident(r) for r in reg["citations"]}) == []


def test_a_work_equivalence_is_held_to_what_an_approval_is_held_to():
    """A group merges two records into one work — it changes the number a reader takes for the
    breadth of the evidence, and would let one claim binding stand for two. So it needs a named
    person, a usable date, a repeatable `how`, and identifiers this register actually holds."""
    reg, _inv = live()
    registered = {cr._ident(r) for r in reg["citations"] if cr._ident(r)[1]}
    pmid = next(i for i in registered if i[0] == "pmid")
    doi = next(i for i in registered if i[0] == "doi")
    ok = {"identifiers": [{"kind": pmid[0], "value": pmid[1]}, {"kind": doi[0], "value": doi[1]}],
          "established_by": "J. Roe", "established_date": "2026-08-16", "how": "resolved on doi.org"}
    assert cr.same_work_errors(dict(reg, **{cr.SAME_WORK: [ok]}), registered) == []

    for field, value, fragment in (("established_by", "RWP", "team, not a person"),
                                   ("established_by", None, "unstated"),
                                   ("established_date", "soon", "not an ISO date"),
                                   ("how", "", "no `how`")):
        bad = dict(ok)
        bad[field] = value
        errs = cr.same_work_errors(dict(reg, **{cr.SAME_WORK: [bad]}), registered)
        assert any(fragment in e for e in errs), (field, value, errs)

    # ...one identifier merges nothing; two of the SAME scheme are already merged by normalisation;
    # an identifier nothing cites cannot be checked against anything.
    one = dict(ok, identifiers=[{"kind": pmid[0], "value": pmid[1]}])
    assert any("needs two or more" in e
               for e in cr.same_work_errors(dict(reg, **{cr.SAME_WORK: [one]}), registered))
    same = dict(ok, identifiers=[{"kind": "pmid", "value": pmid[1]},
                                 {"kind": "pmid", "value": "99999999"}])
    assert any("already merged by normalisation" in e
               for e in cr.same_work_errors(dict(reg, **{cr.SAME_WORK: [same]}), registered))
    ghost = dict(ok, identifiers=[{"kind": pmid[0], "value": pmid[1]},
                                  {"kind": "doi", "value": "10.9999/not-here"}])
    assert any("is not in this register" in e
               for e in cr.same_work_errors(dict(reg, **{cr.SAME_WORK: [ghost]}), registered))

    # An ABSENT block is not an empty one: only the second says nobody has looked.
    without = {k: v for k, v in reg.items() if k != cr.SAME_WORK}
    assert any("write `same_work: []`" in e for e in cr.same_work_errors(without, registered))


def test_the_live_register_declares_the_block_and_it_is_empty():
    """What is true today. If somebody establishes an equivalence this should be updated
    deliberately rather than quietly satisfied — and no AI may write one."""
    reg, _inv = live()
    assert reg.get(cr.SAME_WORK) == [], reg.get(cr.SAME_WORK)
    text = (REPO / "governance" / "reference" / "variable_inventory" / "CITATIONS.yaml") \
        .read_text(encoding="utf-8")
    assert "NO AI MAY WRITE ONE" in text


def test_two_spellings_of_one_work_may_not_disagree_about_how_it_was_checked():
    """Whichever spelling a reader lands on would look authoritative, and they would get different
    answers about the same paper."""
    reg, inv = live()
    reg = copy.deepcopy(reg)
    key = None
    for r in reg["citations"]:
        k = cr.work_key(r)
        if sum(1 for o in reg["citations"] if cr.work_key(o) == k) > 1:
            key = k
            break
    assert key, "no duplicated identifier — this test has lost its subject"
    dupes = [r for r in reg["citations"] if cr.work_key(r) == key]
    dupes[0]["route"] = ("web_search_result" if dupes[0]["route"] != "web_search_result"
                         else "pubmed_or_publisher")
    errs = cr.register_errors(reg, inv)
    assert any("DIFFERENT verification facts" in e for e in errs), errs


def test_a_claim_binding_has_a_SHAPE_before_anybody_starts_filling_it():
    """`supports:` was checked only for being a list, so the first person to write one would have
    had no shape to write and no way to record that a work CONTRADICTS a claim — which is the most
    valuable binding there is."""
    reg, inv = live()
    reg = copy.deepcopy(reg)
    good = {"claim": "the ECOG window is read around index", "locator": "Methods, p.3",
            "relation": "supports", "reviewed_by": "T. Test", "reviewed_date": "2026-08-15"}
    reg["citations"][0]["supports"] = [good]
    assert cr.register_errors(reg, inv) == [], cr.register_errors(reg, inv)

    for drop, needle in (("claim", "no `claim`"), ("locator", "no `locator`"),
                         ("relation", "not in"), ("reviewed_by", "reviewed_by"),
                         ("reviewed_date", "reviewed_date")):
        broken = copy.deepcopy(live()[0])
        broken["citations"][0]["supports"] = [{k: v for k, v in good.items() if k != drop}]
        errs = cr.register_errors(broken, inv)
        assert any(needle in e for e in errs), (drop, errs)

    # A bare string cannot say where in the work, or saying what.
    broken = copy.deepcopy(live()[0])
    broken["citations"][0]["supports"] = ["Griffith 2019 says so"]
    assert any("a binding is a mapping" in e for e in cr.register_errors(broken, inv))

    # CONTRADICTS is expressible, and an unstated relation is not silently support.
    assert "contradicts" in cr.SUPPORT_RELATIONS


def test_a_weak_citation_must_be_named_where_the_variables_are_read():
    """A caveat that says "a few" is what this replaces. The register knowing an exception is not
    enough — someone reading the tumour's entries must see it there."""
    reg, inv = live()
    inv = copy.deepcopy(inv)
    inv["tumours"]["mds"]["caveats"] = ["A few citations are weaker than the rest."]
    errs = cr.register_errors(reg, inv)
    assert any("does not name it" in e for e in errs), errs
    assert any("Malcovati" in e for e in errs), errs


def test_promoting_a_citation_to_a_stronger_route_without_the_caveat_is_refused():
    """The symmetric mistake: quietly upgrading a route so the caveat requirement stops firing."""
    reg, inv = live()
    reg = copy.deepcopy(reg)
    for r in reg["citations"]:
        if r["author_list_confirmed"] is False:
            r["author_list_confirmed"] = True
    # now nothing is flagged; the register would read as though every author list was confirmed
    assert cr.register_errors(reg, inv) == []
    md = cr.render_md(reg, inv)
    assert "## Recorded without a confirmed author list\n\nThe harvesting pass" in md
    live_md = (REPO / "governance" / "reference" / "variable_inventory" / "CITATIONS.md") \
        .read_text(encoding="utf-8")
    assert "PMID 24373733" in live_md, \
        "the nine unconfirmed citations must be NAMED in the rendering, not counted"


def test_the_claim_binding_is_empty_and_the_rendering_says_so():
    """The finding, not an omission. If someone binds claims, this assertion should be updated
    deliberately — it must never pass by the rendering going quiet about the count."""
    reg, _ = live()
    bound = [r["text"] for r in reg["citations"] if r.get("supports")]
    assert bound == [], f"claims are now bound — update this test and the register header: {bound}"
    md = (REPO / "governance" / "reference" / "variable_inventory" / "CITATIONS.md") \
        .read_text(encoding="utf-8")
    assert f"**0 of {len(reg['citations'])} records carry one.**" in md
    assert "An AI must not fill this in" in md


def test_the_rendering_refuses_to_read_as_verification():
    md = (REPO / "governance" / "reference" / "variable_inventory" / "CITATIONS.md") \
        .read_text(encoding="utf-8")
    assert "No human has verified any of these" in md
    assert "not an approval" in md or "nothing here is an approval" in md


def test_common_sources_carries_no_citation():
    """Stated on all 509 variables and supported by none of the citations. The rendering says it;
    this is the fact it says."""
    _, inv = live()
    n = sum(1 for t in inv["tumours"].values() for v in t["variables"] if v.get("common_sources"))
    assert n == sum(len(t["variables"]) for t in inv["tumours"].values())
    md = (REPO / "governance" / "reference" / "variable_inventory" / "CITATIONS.md") \
        .read_text(encoding="utf-8")
    assert "carries no citation at all" in md


# --- basis: what an entry IS, and the one promotion an AI may never make ------------------------

def test_the_basis_is_derived_from_the_citations_when_no_block_says_otherwise():
    """509 entries do not need 509 hand-typed blocks to answer a question the citations answer. A
    `provenance:` block is only ever written to record the PROMOTION."""
    assert cr.basis_of({"citations": ["Griffith SD et al. 2019, PMID 31140124"]}) \
        == "literature_inferred"
    assert cr.basis_of({"citations": ["in-house: prostate 202606 programme specification"]}) \
        == "in_house_drafting"
    # mixed citations are NOT in-house: one literature paper means the concept did not come solely
    # off a pack's drafting surfaces
    assert cr.basis_of({"citations": ["in-house: prostate 202606", "PMID 31140124"]}) \
        == "literature_inferred"
    assert cr.basis_of({"citations": [], "provenance": {"basis": "workbook_confirmed"}}) \
        == "workbook_confirmed"


def test_no_entry_is_workbook_confirmed_today():
    """The state of the shelf, stated. If a person confirms entries this assertion should be
    updated deliberately — never satisfied by the counting going quiet."""
    _, inv = live()
    confirmed = [f"{slug}.{v['name']}" for slug, t in inv["tumours"].items()
                 for v in t["variables"] if cr.basis_of(v) == "workbook_confirmed"]
    assert confirmed == [], confirmed
    md = (REPO / "governance" / "reference" / "variable_inventory" / "CITATIONS.md") \
        .read_text(encoding="utf-8")
    assert "**0 of 509 entries are `workbook_confirmed`.**" in md
    assert "an AI must never write it" in md


def _inv_with(prov):
    _, inv = live()
    inv = copy.deepcopy(inv)
    inv["tumours"]["mcrc"]["variables"][0]["provenance"] = prov
    return inv


# A confirmation names a REVIEWED program_spec and the exact bytes it read. No pack in this
# repository has a reviewed material — that is the true state, and the tests must not create one in
# a live pack to get green. So the accepted example is built in a THROWAWAY tree, which is also the
# only place the repo's fixture person may appear.
WHO = "T. Test"


def _reviewed_pack():
    """A temp pack whose program_spec is reviewed and digested, and the confirmation that cites it.

    REAL BYTES, REAL DIGEST. The first version of this fixture declared `sha256: "b"*64` against
    `path_or_link: vault://…` — a digest of nothing, for a file that does not exist — and the
    accepted-example test passed. That is the defect it was meant to demonstrate the absence of:
    every comparison in `provenance_errors` was string-to-string, so the strongest tier on the
    shelf rested on two copies of one unverified claim. The confirmation now cites a file that
    exists and hashes to what the pack declares.
    """
    import hashlib
    import tempfile
    import yaml as _yaml
    root = Path(tempfile.mkdtemp())
    pack = "products/oncology/testis/202608"
    (root / pack).mkdir(parents=True)
    body = b"the approved testis 202608 program specification"
    (root / pack / "workbook.xlsx").write_bytes(body)
    digest = hashlib.sha256(body).hexdigest()
    (root / pack / "source_refs.yaml").write_text(_yaml.safe_dump({
        "product": "testis", "spec_version": "202608",
        "source_materials": [{
            "material_id": "program_spec", "material_type": "program_spec",
            "path_or_link": f"{pack}/workbook.xlsx",
            "role": "the authoritative RWB program specification",
            "status": "reviewed", "sha256": digest,
            # GATE 1 CLEAN, in full. The confirmation now delegates verification to Gate 1, so an
            # accepted example that skipped Gate 1's own required fields would be asserting that a
            # half-registered workbook can be confirmed — the thing this tier exists to refuse.
            "document_id": "RWB-TESTIS-202608", "revision": "1.0",
            "data_refresh": "202608", "rwb_qc_reference": "RWB QC pass 2026-08-01",
            "ai_classification": "sponsor_ai_eligible",
            "classified_by": WHO, "classified_date": "2026-08-01",
            "approved_by": WHO, "approval_date": "2026-08-02",
        }]}), encoding="utf-8")
    inv_entry = copy.deepcopy(live()[1]["tumours"]["mcrc"]["variables"][0])
    confirmation = {"basis": "workbook_confirmed", "confirmed_by": WHO,
                    "confirmed_date": "2026-08-15",
                    "workbook": f"{pack}#program_spec", "workbook_sha256": digest,
                    "confirmed_claim_sha256": cr._claim_digest(inv_entry),
                    "locator": "studypop, row 18"}
    return root, confirmation


def test_a_confirmation_is_revoked_when_the_definition_moves_under_it():
    """`workbook_confirmed` says a person read the workbook and it states THIS. The workbook half
    was pinned by `workbook_sha256`; the THIS half by nothing, so the definition could be rewritten
    afterwards and the confirmation survived the change it was about."""
    import shutil
    root, confirmation = _reviewed_pack()
    try:
        inv = _inv_with(confirmation)
        assert cr.provenance_errors(inv, root=root) == []
        # ...rewrite the claim the confirmation was made about.
        inv["tumours"]["mcrc"]["variables"][0]["definition_sketch"] = "something else entirely"
        errs = cr.provenance_errors(inv, root=root)
        assert any("the definition moved after it was" in e for e in errs), errs
        # ...and an absent binding is refused rather than treated as nothing to check.
        inv2 = _inv_with({k: v for k, v in confirmation.items()
                          if k != "confirmed_claim_sha256"})
        assert any("no `confirmed_claim_sha256`" in e
                   for e in cr.provenance_errors(inv2, root=root))
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_confirmation_whose_declared_digest_is_not_the_files_digest_is_refused():
    """THE STRING-TO-STRING HOLE. `source_refs.yaml` declared a digest and `INVENTORY.yaml`
    repeated it; both are typed, and nothing hashed the file. A pack could declare any digest at
    all for a real file and this passed."""
    import shutil
    root, confirmation = _reviewed_pack()
    try:
        import yaml as _yaml
        p = root / "products/oncology/testis/202608/source_refs.yaml"
        doc = _yaml.safe_load(p.read_text(encoding="utf-8"))
        doc["source_materials"][0]["sha256"] = "b" * 64          # a digest of nothing
        p.write_text(_yaml.safe_dump(doc), encoding="utf-8")
        bad = dict(confirmation, workbook_sha256="b" * 64)       # …repeated in the shelf entry
        errs = cr.provenance_errors(_inv_with(bad), root=root)
        assert any("does not pass Gate 1" in e for e in errs), errs
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_well_formed_confirmation_is_accepted():
    """The promotion has to be POSSIBLE, or the tier is theatre and people route around it."""
    import shutil
    root, confirmation = _reviewed_pack()
    try:
        assert cr.provenance_errors(_inv_with(confirmation), root=root) == [], \
            cr.provenance_errors(_inv_with(confirmation), root=root)
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_confirmation_against_an_UNREVIEWED_workbook_is_refused():
    """THE DEFECT THE SIXTH REVIEW FOUND, and it is the worst one the shelf could have: the check
    asked only that the material id resolve to SOME registered material, and prostate's
    `program_spec` is `status: pending`, `sha256: null`, `path_or_link: "TBD — the approved
    workbook"`. So the one promotion meaning "a person read the approved workbook and it states
    this" could be recorded against a workbook nobody has — laundering an absence into the
    strongest claim on the shelf."""
    errs = cr.provenance_errors(_inv_with({
        "basis": "workbook_confirmed", "confirmed_by": WHO, "confirmed_date": "2026-08-15",
        "workbook": "products/oncology/prostate/202606#program_spec",
        "workbook_sha256": "c" * 64, "locator": "studypop, row 18"}))
    assert any("is `status: pending`, not `reviewed`" in e for e in errs), errs
    assert any("records no sha256" in e for e in errs), errs


def test_a_confirmation_must_name_the_bytes_the_locator_and_a_program_spec():
    import shutil
    root, confirmation = _reviewed_pack()
    try:
        for drop, needle in (("workbook_sha256", "no workbook_sha256"),
                             ("locator", "no `locator`")):
            broken = {k: v for k, v in confirmation.items() if k != drop}
            errs = cr.provenance_errors(_inv_with(broken), root=root)
            assert any(needle in e for e in errs), (drop, errs)
        # ...and a workbook that has MOVED since the confirmation revokes it, exactly as a changed
        # extraction revokes a Gate 1 signature.
        moved = dict(confirmation, workbook_sha256="d" * 64)
        errs = cr.provenance_errors(_inv_with(moved), root=root)
        assert any("moved under the confirmation" in e for e in errs), errs
    finally:
        shutil.rmtree(root, ignore_errors=True)


BROKEN_CONFIRMATIONS = [
    # (field to break, value, the message that must fire) — the pack path cases are checked against
    # the LIVE tree, where those packs really do or do not exist, so the message is the right one
    # rather than a coincidental "does not exist" from a temp root.
    ("confirmed_by", "RWP", "is a team, not a person", "temp"),
    ("confirmed_by", "", "unstated", "temp"),
    ("confirmed_date", "soon", "confirmed_date", "temp"),
    ("workbook", "program_spec", "must be `<pack path>#<material_id>`", "temp"),
    # The message is now precise about WHY: `is_dir()` accepted any directory in the tree, so a
    # confirmation could cite a source_refs.yaml outside the set Gate 1 walks.
    ("workbook", "products/oncology/nope/202606#program_spec",
     "is not a governed product pack", "live"),
    ("workbook", "products/oncology/prostate/202606#not_registered",
     "registers no material", "live"),
]


def test_a_confirmation_missing_its_evidence_is_refused():
    """Every part of "a person read the approved workbook and it says this" is checkable except the
    person's honesty, and each part is checked."""
    import shutil
    root, confirmation = _reviewed_pack()
    try:
        for field, value, needle, where in BROKEN_CONFIRMATIONS:
            kwargs = {} if where == "live" else {"root": root}
            errs = cr.provenance_errors(_inv_with({**confirmation, field: value}), **kwargs)
            assert any(needle in e for e in errs), (field, value, needle, errs)
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_the_weaker_bases_are_labels_and_are_not_checked_hard():
    """They carry no authority and are derivable from the citations, so demanding evidence for them
    would be friction with nothing behind it."""
    for basis in ("literature_inferred", "in_house_drafting"):
        assert cr.provenance_errors(_inv_with({"basis": basis})) == []


def test_a_basis_outside_the_vocabulary_is_refused():
    errs = cr.provenance_errors(_inv_with({"basis": "someone_said_so"}))
    assert any("not in" in e for e in errs), errs


if __name__ == "__main__":
    # CI RUNS EVERY SUITE AS A SCRIPT — see the module docstring. Without this block the file runs
    # no tests and exits 0.
    bad = 0
    for _name, _fn in sorted(globals().items()):
        if _name.startswith("test_") and callable(_fn):
            try:
                _fn()
                print(f"  ok  {_name}")
            except Exception as _e:                  # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {_name}: {_e}")
    sys.exit(1 if bad else 0)
