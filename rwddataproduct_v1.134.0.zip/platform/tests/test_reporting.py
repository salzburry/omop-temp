"""Tests for the reporting layer: data-dictionary generation (per audience) and QC reports.
Pure Python (no Spark). Run: python3 test_reporting.py (or pytest).
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))
PRODUCTS = FRAMEWORK.parent / "products"

from engine.config import load_yaml          # noqa: E402
from engine import dictionary as dct, qc_report   # noqa: E402

CATALOG = PRODUCTS / "metadata" / "catalog.yaml"
AUDIENCES = PRODUCTS / "_reporting" / "dictionary" / "audiences.yaml"


def _catalog():
    return load_yaml(CATALOG)


def test_audiences_are_neutral_no_sales():
    aud = dct.load_audiences(AUDIENCES)
    assert set(aud) == {"internal", "partner", "customer"}   # 'partner' replaces 'sales'
    assert "sales" not in aud


def test_internal_shows_codes():
    d = dct.build_dictionary(_catalog(), audience="internal")
    assert "code" in d["columns"] and d["summary"]["n_variables"] > 0


def test_partner_drops_codes_and_pii():
    aud = dct.load_audiences(AUDIENCES)
    cat = _catalog()
    cat["variables"].append({"code": "ssn", "category": "Demographics", "label": "SSN",
                             "applies_to": "all", "pii": True})
    d_int = dct.build_dictionary(cat, audience="internal", audiences=aud)
    d_par = dct.build_dictionary(cat, audience="partner", audiences=aud)
    assert "code" not in d_par["columns"]                                  # partner: label-level
    assert "ssn" in {r.get("code") for r in d_int["variables"]}            # internal keeps PII row
    assert "SSN" not in {r.get("label") for r in d_par["variables"]}       # partner drops PII


def test_tumor_filter():
    cat = _catalog()
    cat["variables"].append({"code": "figo", "category": "Staging", "label": "FIGO stage",
                             "applies_to": ["oc", "ec"]})
    codes_mcrpc = {r["code"] for r in dct.build_dictionary(cat, tumor="mcrpc")["variables"]}
    codes_oc = {r["code"] for r in dct.build_dictionary(cat, tumor="oc")["variables"]}
    assert "figo" not in codes_mcrpc and "figo" in codes_oc


def test_columns_filter_excludes_unemitted_optional_vars():
    # Emit-aware dictionary (parity with dashboard.build_manifest): an optional, catalog-applicable
    # variable absent from the ACTUAL ADS columns is NOT advertised, so the delivered dictionary can't
    # promise a column the cut didn't produce (e.g. a feed-absent psadiag_crpc / conmed flag).
    cat = {"variables": [
        {"code": "age",          "category": "Demographics", "label": "Age",     "applies_to": "all"},
        {"code": "psadiag_crpc", "category": "Clinical",     "label": "PSA CRPC", "applies_to": "all"}]}
    all_codes = {r["code"] for r in dct.build_dictionary(cat)["variables"]}
    emitted = {r["code"] for r in dct.build_dictionary(cat, columns=["age", "cohort"])["variables"]}
    assert all_codes == {"age", "psadiag_crpc"}            # catalog-only view advertises both
    assert emitted == {"age"}                              # emit-aware view drops the absent optional var


def test_list_applies_to_renders_as_string():
    # applies_to can be a list (e.g. PFS is [oc, ec]); the renderer must flatten it, not emit "['oc'...".
    cat = {"variables": [{"code": "pfs", "category": "Outcomes", "label": "PFS",
                          "applies_to": ["oc", "ec"]}]}
    md = dct.render_markdown(dct.build_dictionary(cat, audience="internal"))
    assert "oc, ec" in md and "['oc'" not in md


def test_render_markdown_groups_by_category():
    md = dct.render_markdown(dct.build_dictionary(_catalog(), audience="internal"))
    assert md.startswith("# Data dictionary") and "## Demographics" in md and "## Outcomes" in md


def test_real_pii_var_dropped_for_partner():
    cat = _catalog()                       # catalog now flags dthdt (date of death) pii: true
    internal_codes = {r.get("code") for r in dct.build_dictionary(cat, audience="internal")["variables"]}
    partner_labels = {r.get("label") for r in dct.build_dictionary(cat, audience="partner")["variables"]}
    assert "dthdt" in internal_codes                              # internal keeps PII
    assert "Date of death (imputed)" not in partner_labels        # partner drops it


def test_render_xlsx():
    try:
        import openpyxl
    except Exception:
        return                              # openpyxl optional — skip if absent
    import os, tempfile
    d = dct.build_dictionary(_catalog(), audience="internal")
    path = os.path.join(tempfile.mkdtemp(), "dict.xlsx")
    dct.render_xlsx(d, path)
    wb = openpyxl.load_workbook(path)
    assert set(wb.sheetnames) == {"Summary", "Variables"}
    assert wb["Variables"].max_row == d["summary"]["n_variables"] + 1   # header + one row per var


def test_qc_report_pass():
    report = {"n_rows": 100, "cohorts": {"Overall mCRPC": 100},
              "catchall_rate": {"lot1cat": 0.1}, "stage_check_rate": 0.0}
    md = qc_report.render(report, {"passed": True, "failures": []}, golden={"reference": "none"},
                          manifest={"tumor": "mcrpc", "refresh": "2026q1",
                                    "spec_version": "1.0.2026q1", "output_table": "out.x"})
    assert "QC report — mcrpc 2026q1" in md and "QC gate: PASS" in md and "Overall mCRPC" in md


def test_qc_report_fail_lists_failures():
    md = qc_report.render({"n_rows": 0}, {"passed": False, "failures": ["n_rows 0 < min_rows 1"]})
    assert "QC gate: FAIL" in md and "min_rows" in md


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
