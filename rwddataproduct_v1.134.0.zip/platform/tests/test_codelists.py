"""The codelist DSL's vocabulary must be one list, not two.

`MATCH_OPERATORS` exists so that an unknown operator is refused with the valid ones named, and so
`platform/tools/blocks.py` can tell an analyst what they may write. Both of those make it a SECOND
place the operator names appear — the first being the if/elif chain in `compile_match` — and two
lists of one vocabulary is the failure this repository keeps paying for: they agree the day they are
written, and the divergence is silent. An operator added to the chain but not the dict is missing
from the catalog and from every error message; one added to the dict but not the chain is advertised
to analysts and then rejected at build time.

So the agreement is not assumed, it is CHECKED, by reading the dispatch back out of the module's own
syntax tree. That is a test-side derivation — a check, never a second implementation anything runs.

Run: python3 tests/test_codelists.py (or pytest).
"""
import ast
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK / "engine"))

import codelists  # noqa: E402


def _dispatched_operators():
    """Every operator compile_match branches on, read from the source itself.

    Both dispatch shapes, because the function uses both: `op == "like_any"` for the branches that
    differ, and `op in ("code_in", "code_prefix_any")` for the pair that shares a preamble. Probing
    only `==` silently under-reported the second pair — and an AST probe that misses a branch turns
    the drift test it feeds into a test that cannot fail for the operators it cannot see.
    """
    tree = ast.parse((FRAMEWORK / "engine" / "codelists.py").read_text(encoding="utf-8"))
    fn = next(n for n in ast.walk(tree)
              if isinstance(n, ast.FunctionDef) and n.name == "compile_match")
    found = set()
    for node in ast.walk(fn):
        if not isinstance(node, ast.Compare) or not isinstance(node.left, ast.Name):
            continue
        if node.left.id != "op":
            continue
        op_node, c = node.ops[0], node.comparators[0]
        if isinstance(op_node, ast.Eq) and isinstance(c, ast.Constant) and isinstance(c.value, str):
            found.add(c.value)
        elif isinstance(op_node, ast.In) and isinstance(c, (ast.Tuple, ast.List)):
            found |= {e.value for e in c.elts
                      if isinstance(e, ast.Constant) and isinstance(e.value, str)}
    return found


def test_the_registry_lists_exactly_what_the_dispatch_accepts():
    dispatched = _dispatched_operators()
    assert dispatched, "found no `op == \"...\"` branches — the AST probe has stopped working"
    declared = set(codelists.MATCH_OPERATORS)
    assert declared == dispatched, (
        f"MATCH_OPERATORS and compile_match disagree.\n"
        f"    declared but not dispatched (advertised, then rejected at build): "
        f"{sorted(declared - dispatched)}\n"
        f"    dispatched but not declared (works, but no analyst can discover it): "
        f"{sorted(dispatched - declared)}")


def test_every_declared_operator_actually_compiles():
    """The dict is what the catalog prints. An entry that raises would be advice to write something
    the engine refuses."""
    sample = {"equals": "abc", "like_any": ["%a%"], "regexp": "^a", "category_equals": "x",
              "is_null": True, "all_of": [{"equals": "a"}], "any_of": [{"equals": "a"}],
              "code_in": ["C18.9"], "code_prefix_any": ["C18"],
              "always": True}
    # Spelled out because this fires BEFORE the drift test alphabetically, so on a newly-declared
    # operator it is the first thing anyone reads — and "add a sample here" alone reads as a test
    # chore rather than as the question actually worth asking.
    missing, extra = set(codelists.MATCH_OPERATORS) - set(sample), set(sample) - set(codelists.MATCH_OPERATORS)
    assert not missing, (
        f"MATCH_OPERATORS declares {sorted(missing)} with no sample here. Either the engine "
        f"implements it — add a sample value — or it does not, in which case the registry is "
        f"advertising an operator that will be rejected at build time, and the entry should go.")
    assert not extra, f"this test samples {sorted(extra)}, which the registry no longer declares"
    # The code operators need a code column and its system; the name operators ignore both, so one
    # call shape exercises every declared operator without a special case per family.
    for op, val in sample.items():
        sql = codelists.compile_match({op: val}, "linename", "detaileddrugcategory",
                                      "diagnosiscode", "icd10cm")
        assert isinstance(sql, str) and sql, f"{op} compiled to nothing"


def test_an_unknown_operator_names_the_valid_ones():
    """The whole point of the registry: the error has to be actionable for someone authoring YAML."""
    try:
        codelists.compile_match({"lke_any": ["%x%"]}, "linename", "detaileddrugcategory")
    except ValueError as e:
        msg = str(e)
    else:
        raise AssertionError("an unknown operator was accepted")
    assert "lke_any" in msg, "the error does not name the offending operator"
    for op in codelists.MATCH_OPERATORS:
        assert op in msg, f"the error does not offer {op!r} as an alternative"


def test_a_match_still_needs_exactly_one_operator():
    """Unchanged behaviour, asserted because the registry edit sits next to it."""
    for bad in ({}, {"equals": "a", "always": True}, "equals", None):
        try:
            codelists.compile_match(bad, "linename", "detaileddrugcategory")
        except ValueError:
            continue
        raise AssertionError(f"{bad!r} was accepted as a match")


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
