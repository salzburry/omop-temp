# This file exists for pytest's module NAMING, not for imports. Nothing imports `tests`.
#
# With `--import-mode=importlib` (pytest.ini — required, or the products' same-named contract tests
# collide), pytest names a test module after its path relative to the rootdir. Without this file that
# is `platform.tests.test_governance`, so pytest imports the parent `platform` — and because the
# standard library's `platform` is a plain module with no `__path__`, pytest treats it as needing
# re-import and REPLACES sys.modules["platform"] with this repo's platform/ directory. Every later
# `import platform` in the process then gets a directory: jsonschema -> attrs -> `platform
# .python_implementation()` fails with AttributeError, and the failure lands on whichever test happened
# to import it first.
#
# With this file, pytest resolves the package root to platform/ and the module is named
# `tests.test_governance` — no `platform` parent, nothing to overwrite. CI is unaffected either way:
# it runs each suite as a script.
#
# test_governance.test_no_test_dir_shadows_the_stdlib_platform_module keeps this true for new dirs.
