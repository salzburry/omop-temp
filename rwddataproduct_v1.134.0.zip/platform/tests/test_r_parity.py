"""Cross-engine parity: the R codelist compiler must emit byte-identical Spark SQL to Python.

The R and PySpark engines share the SAME config/YAML (so the R-proficient team can read and
validate the logic). The hardest, highest-value shared logic is the treatment-category compiler —
the 17-way line-of-therapy classifier (`lotcat`). This test proves `engine-r/codelists.R` and
`engine/codelists.py` turn the SAME parsed codelist into the SAME `CASE ... END` strings for every
real tumor codelist (prostate / oc / endometrial / dlbcl) plus a synthetic fixture that exercises
the remaining operators (`any_of`) and the single-quote escaping path.

How it works (no R YAML/JSON package required — neither installs offline):
  1. Python loads the codelist YAML -> dict, and computes engine.codelists.compile_case(dict).
  2. The dict is serialised to an R `list(...)` literal (we control the exact structure, so the
     test isolates the COMPILER logic from the YAML parser).
  3. A generated R script `source()`s engine-r/codelists.R and cat()s compile_case(...)$label / $code.
  4. We assert the R output equals the Python output, character for character.

Run: python3 tests/test_r_parity.py   (skips cleanly if Rscript is not on PATH)
Also runs under pytest (module is skipped when Rscript is unavailable).
"""
import datetime
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent          # _framework/
PRODUCTS = FRAMEWORK.parent / "products"                                  # products/
R_DIR = FRAMEWORK / "engine-r"
R_CODELISTS = R_DIR / "codelists.R"
R_VOCAB = R_DIR / "vocabularies.R"
R_VENDORS = R_DIR / "vendors.R"
R_CONFIG = R_DIR / "config.R"
sys.path.insert(0, str(FRAMEWORK))

from engine.config import load_yaml, load_config   # noqa: E402
from engine.config import product_config, product_dir  # noqa: E402
from engine import codelists                        # noqa: E402
from engine.stages.demographics import _bands_case, _map_case, _region_case   # noqa: E402
from engine.stages.clinical import _num_bands_case, _stage_case, _band_value_expr   # noqa: E402
from engine.stages.treatment import _lot_bands_case                           # noqa: E402

R_CASES = R_DIR / "cases.R"

RSCRIPT = shutil.which("Rscript")
TUMORS = ["prostate", "oc", "endometrial", "dlbcl", "mds"]
SPLIT = "\n@@@RWDP_SPLIT@@@\n"

# Skip the whole module under pytest when R is absent (CI runners without R still pass).
try:
    import pytest
    pytestmark = pytest.mark.skipif(RSCRIPT is None, reason="Rscript not available")
except ImportError:                          # pragma: no cover - pytest optional
    pytest = None


# A synthetic codelist covering the operators the real files don't (any_of) and the single-quote
# escaping path (apostrophe in both a label and a matched value).
SYNTHETIC = {
    "match_on": {"name_column": "ln", "drug_category_column": "dc"},
    "categories": [
        {"code": 1, "label": "Women's PARP or platinum",
         "match": {"any_of": [{"like_any": ["%olaparib%"]},
                              {"equals": "carbo'platin"}]}},
        {"code": 2, "label": "Catch all", "match": {"always": True}},
    ],
}

# The CODE operators, which normalise both sides of the comparison under a declared coding system.
# Three systems on purpose: one that strips a dot (icd10cm), one that strips a hyphen (ndc, whose
# literals must come out normalised in the IN list) and a hierarchical prefix. If the two engines
# ever disagree about strip_chars, this is where a code set written once starts meaning two things.
SYNTHETIC_CODES = {
    "match_on": {"name_column": "ln", "drug_category_column": "dc",
                 "code_column": "dx", "code_system": "icd10cm"},
    "categories": [
        {"code": 1, "label": "Colon", "match": {"code_prefix_any": ["C18", "C19"]}},
        {"code": 2, "label": "Exact", "match": {"code_in": ["C18.9", "C209", "c20.0"]}},
        {"code": 3, "label": "Mixed",
         "match": {"any_of": [{"code_in": ["C21.1"]}, {"like_any": ["%bevacizumab%"]}]}},
        {"code": 4, "label": "Catch all", "match": {"always": True}},
    ],
}

SYNTHETIC_NDC = {
    "match_on": {"name_column": "ln", "drug_category_column": "dc",
                 "code_column": "ndccode", "code_system": "ndc"},
    "categories": [
        {"code": 1, "label": "Bev", "match": {"code_in": ["0069-0187-01", "00690018701"]}},
        {"code": 2, "label": "Catch all", "match": {"always": True}},
    ],
}


def to_r_literal(obj) -> str:
    """Serialise a Python config value to an R literal (list/character/logical/numeric/NULL).

    bool must be checked before int (bool is a subclass of int in Python). Python dict -> named
    R list with backtick-quoted names; Python list -> unnamed R list (uniform, so as.character()
    / iteration behave the same as the Python dict/list the engine consumes).
    """
    if obj is None:
        return "NULL"
    if isinstance(obj, bool):
        return "TRUE" if obj else "FALSE"
    if isinstance(obj, int):
        return str(obj)
    if isinstance(obj, float):
        return repr(obj)
    if isinstance(obj, (datetime.date, datetime.datetime)):
        return '"' + obj.isoformat() + '"'
    if isinstance(obj, str):
        return '"' + obj.replace("\\", "\\\\").replace('"', '\\"') + '"'
    if isinstance(obj, dict):
        return "list(" + ", ".join(f"`{k}` = {to_r_literal(v)}" for k, v in obj.items()) + ")"
    if isinstance(obj, (list, tuple)):
        return "list(" + ", ".join(to_r_literal(v) for v in obj) + ")"
    raise TypeError(f"cannot serialise {type(obj)!r} to an R literal")


def r_compile_case(codelist: dict):
    """Run engine-r/codelists.R::compile_case on `codelist` via Rscript; return (label, code)."""
    script = (
        # vocabularies.R FIRST: codelists.R's code operators read the one coding-system registry
        # rather than duplicating an eleven-entry table, so it is sourced the same way run_rwdp.R
        # sources it. The load order is part of what this harness is checking.
        f'source({to_r_literal(str(R_VOCAB))})\n'
        f'source({to_r_literal(str(R_CODELISTS))})\n'
        f'cl <- {to_r_literal(codelist)}\n'
        f'res <- compile_case(cl)\n'
        f'cat(res$label); cat({to_r_literal(SPLIT)}); cat(res$code)\n'
    )
    with tempfile.NamedTemporaryFile("w", suffix=".R", delete=False) as fh:
        fh.write(script)
        path = fh.name
    try:
        proc = subprocess.run([RSCRIPT, path], capture_output=True, text=True, encoding="utf-8")
    finally:
        Path(path).unlink(missing_ok=True)
    assert proc.returncode == 0, f"Rscript failed:\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}"
    out = proc.stdout
    assert SPLIT in out, f"R output missing split marker:\n{out!r}\nSTDERR:\n{proc.stderr}"
    label, code = out.split(SPLIT, 1)
    return label, code


def _assert_parity(codelist: dict, label: str):
    py_label, py_code = codelists.compile_case(codelist)
    r_label, r_code = r_compile_case(codelist)
    assert r_label == py_label, (
        f"{label}: label CASE differs\nPYTHON: {py_label}\nR     : {r_label}")
    assert r_code == py_code, (
        f"{label}: code CASE differs\nPYTHON: {py_code}\nR     : {r_code}")
    # Sanity: the compiled SQL is well-formed and first-match-wins ordering is preserved.
    assert py_label.startswith("CASE ") and py_label.endswith(" END")
    assert py_code.startswith("CASE ") and py_code.endswith(" END")


def _tumor_codelist(tumor: str) -> dict:
    return load_yaml(str(product_dir(PRODUCTS, tumor) / "codelists" / "treatment_categories.yaml"))


def test_r_codelists_file_exists():
    assert R_CODELISTS.exists(), f"missing R engine codelist compiler: {R_CODELISTS}"


def test_parity_prostate():
    _assert_parity(_tumor_codelist("prostate"), "prostate")


def test_parity_oc():
    _assert_parity(_tumor_codelist("oc"), "oc")


def test_parity_endometrial():
    _assert_parity(_tumor_codelist("endometrial"), "endometrial")


def test_parity_dlbcl():
    _assert_parity(_tumor_codelist("dlbcl"), "dlbcl")


def test_parity_mds():
    _assert_parity(_tumor_codelist("mds"), "mds")


def test_parity_synthetic_code_operators():
    """A code set is authored once and read by both engines. Divergence in how either normalises
    the column or the literals is a silent wrong answer, not a formatting difference."""
    _assert_parity(SYNTHETIC_CODES, "synthetic-codes")
    _assert_parity(SYNTHETIC_NDC, "synthetic-ndc")
    label, _ = codelists.compile_case(SYNTHETIC_CODES)
    assert "REPLACE(UPPER(TRIM(dx)), '.', '')" in label, \
        "the code column is compared unnormalised — a feed spelling C189 would miss C18.9"
    assert "'C189'" in label and "'C200'" in label, \
        "the code LITERALS are not normalised, so only one side of the comparison was"
    ndc_label, _ = codelists.compile_case(SYNTHETIC_NDC)
    assert "'0069018701'" in ndc_label and "'00690018701'" in ndc_label, \
        "the two NDC forms must BOTH survive — they are not interconvertible, so a code set " \
        "naming both must keep both"


def test_parity_synthetic_anyof_and_escaping():
    # any_of + apostrophe escaping in both the label and the matched value.
    _assert_parity(SYNTHETIC, "synthetic")
    py_label, _ = codelists.compile_case(SYNTHETIC)
    assert "'Women''s PARP or platinum'" in py_label   # label single-quote doubled
    py_predicate = codelists.compile_match(SYNTHETIC["categories"][0]["match"], "ln", "dc")
    assert "'carbo''platin'" in py_predicate           # value single-quote doubled
    assert py_predicate.startswith("(") and " OR " in py_predicate   # any_of -> OR


# ---------------------------------------------------------------------------
# Config + vendor resolution parity: engine-r/{vendors,config}.R must resolve the SAME parsed config
# to the SAME table FQNs / index source / lot setting / version as engine/{vendors,config}.py — for
# BOTH vendors (flatiron solid + cota heme). This validates the vendor-aware engine end to end.
# ---------------------------------------------------------------------------
# Concrete run params so the resolved FQNs are real (not REPLACE_ME).
_RUN_OVERRIDES = {"run.refresh": "2026q1", "run.source_schema": "prod_src",
                  "run.output_schema": "prod_out"}


def _py_resolution_lines(cfg) -> str:
    """The resolved-config report the R script must reproduce, line for line."""
    def nn(v):
        return "<NULL>" if v is None else str(v)
    lines = [
        f"vendor={cfg.vendor}",
        f"tumor_class={cfg.tumor_class}",
        f"index_source={cfg.index_source}",
        f"lot_line_setting={nn(cfg.lot_line_setting)}",
        f"lot_line_number={cfg.lot_line_number_col}",
        f"source_layout={nn(cfg.source_layout)}",
        f"output_fqn={cfg.output_fqn}",
        f"data_product_id={cfg.data_product_id}",   # row provenance stamp — must match R
        f"version={cfg.version}",
        f"spec_version={cfg.spec_version}",   # CalVer contract stamp — must match R (guards the stamp axis)
        f"write_mode={cfg.write_mode}",
    ]
    tabs = cfg.all_tables()
    lines += [f"table.{nm}={tabs[nm]}" for nm in sorted(tabs)]
    return "\n".join(lines) + "\n"


def _r_resolution_lines(raw: dict) -> str:
    """Run engine-r/{vendors,config}.R on the SAME parsed raw config; return the resolved report."""
    script = (
        f'source({to_r_literal(str(R_VENDORS))})\n'
        f'source({to_r_literal(str(R_CONFIG))})\n'
        f'raw <- {to_r_literal(raw)}\n'
        f'cfg <- make_config(raw)\n'
        f'emit <- function(k, v) {{ if (is.null(v) || length(v) == 0) v <- "<NULL>"; '
        f'cat(k, "=", as.character(v), "\\n", sep = "") }}\n'
        f'emit("vendor", cfg_vendor(cfg))\n'
        f'emit("tumor_class", cfg_tumor_class(cfg))\n'
        f'emit("index_source", cfg_index_source(cfg))\n'
        f'emit("lot_line_setting", cfg_lot_line_setting(cfg))\n'
        f'emit("lot_line_number", cfg_lot_line_number_col(cfg))\n'
        f'emit("source_layout", cfg_source_layout(cfg))\n'
        f'emit("output_fqn", cfg_output_fqn(cfg))\n'
        f'emit("data_product_id", cfg_data_product_id(cfg))\n'
        f'emit("version", cfg_version(cfg))\n'
        f'emit("spec_version", cfg_spec_version(cfg))\n'
        f'emit("write_mode", cfg_write_mode(cfg))\n'
        f'tabs <- cfg_all_tables(cfg)\n'
        f'for (nm in sort(names(tabs))) cat("table.", nm, "=", tabs[[nm]], "\\n", sep = "")\n'
    )
    with tempfile.NamedTemporaryFile("w", suffix=".R", delete=False) as fh:
        fh.write(script)
        path = fh.name
    try:
        proc = subprocess.run([RSCRIPT, path], capture_output=True, text=True, encoding="utf-8")
    finally:
        Path(path).unlink(missing_ok=True)
    assert proc.returncode == 0, f"Rscript failed:\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}"
    return proc.stdout


def _assert_config_parity(cfg, label: str):
    want = _py_resolution_lines(cfg)
    got = _r_resolution_lines(cfg.raw)
    assert got == want, (
        f"{label}: config/vendor resolution differs\n--- PYTHON ---\n{want}\n--- R ---\n{got}")


def _tumor_cfg(tumor: str, extra=None):
    ov = dict(_RUN_OVERRIDES)
    if extra:
        ov.update(extra)
    return load_config(product_config(PRODUCTS, tumor), overrides=ov)


def test_config_parity_prostate_flatiron():
    _assert_config_parity(_tumor_cfg("prostate"), "prostate")


def test_config_parity_oc_flatiron():
    _assert_config_parity(_tumor_cfg("oc"), "oc")


def test_config_parity_endometrial_flatiron():
    _assert_config_parity(_tumor_cfg("endometrial"), "endometrial")


def test_config_parity_dlbcl_cota():
    cfg = _tumor_cfg("dlbcl")
    assert cfg.vendor == "cota" and cfg.tumor_class == "heme"     # the heme/COTA path
    assert cfg.index_source == "diagnosis"                         # heme indexes off diagnosis
    assert cfg.lot_line_setting is None                            # no mCRPC-style setting
    _assert_config_parity(cfg, "dlbcl")


def test_config_parity_mds_cota():
    cfg = _tumor_cfg("mds")
    assert cfg.vendor == "cota" and cfg.tumor_class == "heme"     # MDS = the second heme/COTA product
    assert cfg.index_source == "diagnosis"                         # heme indexes off diagnosis
    assert cfg.lot_line_setting is None                            # no mCRPC-style setting
    _assert_config_parity(cfg, "mds")


def test_config_parity_source_layout_override():
    # The run.source_layout override branch of layout_for must match across engines.
    cfg = _tumor_cfg("prostate",
                     {"run.source_layout": "{schema}.custom_{stem}__{refresh}"})
    assert cfg.source_layout == "{schema}.custom_{stem}__{refresh}"
    assert cfg.table("enhanced") == "prod_src.custom_t_enh_prostate__2026q1"
    _assert_config_parity(cfg, "prostate+source_layout")


# ---------------------------------------------------------------------------
# Stage CASE-compiler parity: engine-r/cases.R must compile the SAME reviewed config (age bands,
# region/race/ethnicity/practice crosswalks, BMI bands, stage groups, line-count bands) to the SAME
# Spark SQL CASE strings as engine/stages/*.py — for BOTH the label CASE and the numeric-code CASE.
# ---------------------------------------------------------------------------
_DEM = load_yaml(str(product_dir(PRODUCTS, "prostate") / "variables" / "demographics.yaml"))
_CLIN = load_yaml(str(product_dir(PRODUCTS, "prostate") / "variables" / "clinical.yaml"))
_TRT = load_yaml(str(product_dir(PRODUCTS, "prostate") / "variables" / "treatment.yaml"))


def _r_case(func: str, *args) -> str:
    """source cases.R and cat func(<args>) with args serialised to R literals; return stdout."""
    arglits = ", ".join(to_r_literal(a) for a in args)
    # vocabularies.R + codelists.R FIRST, the order run_rwdp.R uses. `cases.R` reads
    # SEQUENCE_FIELDS/sequence_error from codelists.R, so sourcing cases.R alone exercised a load
    # order production never uses — and would pass while the real runner failed, or the reverse.
    script = (f'source({to_r_literal(str(R_VOCAB))})\n'
              f'source({to_r_literal(str(R_CODELISTS))})\n'
              f'source({to_r_literal(str(R_CASES))})\ncat({func}({arglits}))\n')
    with tempfile.NamedTemporaryFile("w", suffix=".R", delete=False) as fh:
        fh.write(script)
        path = fh.name
    try:
        proc = subprocess.run([RSCRIPT, path], capture_output=True, text=True, encoding="utf-8")
    finally:
        Path(path).unlink(missing_ok=True)
    assert proc.returncode == 0, f"Rscript failed:\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}"
    return proc.stdout


def _assert_case_parity(py_fn, r_fn: str, data, expr: str, label: str):
    """py_fn(data, expr, key) must equal cases.R::r_fn(data, expr, key) for key in {label, code}."""
    for key in ("label", "code"):
        py = py_fn(data, expr, key=key)
        r = _r_case(r_fn, data, expr, key)
        assert r == py, f"{label} (key={key}) differs\nPYTHON: {py}\nR     : {r}"
        assert py.startswith("CASE ") and py.endswith(" END")


def test_case_parity_age_bands():
    _assert_case_parity(_bands_case, "bands_case", _DEM["age_bands"], "age", "age_bands")


def test_case_parity_region():
    _assert_case_parity(_region_case, "region_case", _DEM["regions"], "state", "regions")


def test_case_parity_race_eth_practice_maps():
    _assert_case_parity(_map_case, "map_case", _DEM["race_map"], "race", "race_map")
    _assert_case_parity(_map_case, "map_case", _DEM["ethnicity_map"], "ethnicity", "ethnicity_map")
    _assert_case_parity(_map_case, "map_case", _DEM["practice_map"], "practicetype", "practice_map")


def test_case_parity_bmi_bands():
    _assert_case_parity(_num_bands_case, "num_bands_case",
                        _CLIN["vitals"]["bmi_bands"], "bmi", "bmi_bands")


def test_case_parity_stage_groups():
    _assert_case_parity(_stage_case, "stage_case",
                        _CLIN["staging"]["groups"], "groupstage", "stage_groups")


def test_case_parity_new_value_matchers():
    """The operators no live pack uses YET — so nothing else would compare them.

    `from_startswith_ci`, `from_contains_ci` and `when: missing` were added to close G-STAGE-PREFIX,
    G-BIOMARKER-NEG and G-STAGE-MISSING. Parity over the REAL configs cannot see them: those files
    use only the two original operators, so both engines would agree by both doing nothing. This
    fixture exercises every branch, including the two that decide WHEN order — longest prefix first
    across groups, and the missing marker ahead of every text test.
    """
    groups = [
        {"when": "missing", "label": "Unknown", "code": 5},
        {"label": "Exact", "code": 1, "from_equals_ci": ["IV"]},
        {"label": "Short", "code": 2, "from_startswith_ci": ["II"]},
        {"label": "Long", "code": 3, "from_startswith_ci": ["IIIA", "IIB"]},
        {"label": "Sub", "code": 4, "from_contains_ci": ["occult"]},
        {"when": "fallthrough", "label": "CHECK", "code": 99},
    ]
    _assert_case_parity(_stage_case, "stage_case", groups, "groupstage", "new_matchers")

    sql = _stage_case(groups, "groupstage", "label")
    # missing first, longest prefix before shorter, contains after prefixes, fallthrough last.
    assert sql.index("IS NULL") < sql.index("LOWER(groupstage) IN"), "missing is not tested first"
    assert sql.index("'iiia%'") < sql.index("'ii%'"), "a shorter prefix is tested before a longer one"
    assert sql.index("'iib%'") < sql.index("'ii%'"), "a shorter prefix is tested before a longer one"
    assert sql.index("'ii%'") < sql.index("%occult%"), "contains is tested before prefix"
    assert sql.rstrip().endswith("ELSE 'CHECK' END")


def test_case_parity_regex_matcher():
    """`from_regex` — the escape hatch, and the operator most able to differ between engines.

    Every other matcher's payload is a plain value both engines quote the same way by accident. A
    regex is a program, carried through a YAML reader, an R/Python string literal and a Spark string
    literal before java.util.regex sees it — four layers, each with its own escaping. This asserts
    the two engines emit the same bytes for patterns that exercise all four.
    """
    groups = [
        {"label": "Gleason7", "code": 7,
         # anchored, whitespace-tolerant: the case `from_equals_ci` cannot cover without
         # enumerating every spelling the feed happens to use.
         "from_regex": [r"^\s*[34]\s*\+\s*[34]\s*=\s*7\s*$"]},
        {"label": "Insensitive", "code": 1, "from_regex": [r"(?i)^mutation\s+negative$"]},
        # a quote and a backslash in one pattern — the two escapes interacting
        {"label": "Hostile", "code": 2, "from_regex": [r"o'brien\\path"]},
        {"when": "fallthrough", "label": "CHECK", "code": 99},
    ]
    _assert_case_parity(_stage_case, "stage_case", groups, "groupstage", "regex_matcher")

    sql = _stage_case(groups, "groupstage", "label")
    # The COLUMN is not wrapped in LOWER() and the PATTERN is not lowercased — case-folding a regex
    # inverts \D \S \W \B, so `(?i)` is the only correct way to ask for insensitivity.
    assert "WHEN groupstage REGEXP " in sql, sql
    assert "(?i)^mutation" in sql, "the pattern was altered on its way into the SQL"
    # Backslashes are DOUBLED for the Spark literal (see codelists.sql_str) — verified against
    # Spark 4.2.0, where '\\s' in a literal is the string "s" and the pattern silently dies.
    assert r"'^\\s*[34]\\s*" in sql, sql
    assert r"o''brien\\\\path" in sql, "quote and backslash escapes did not compose"


def test_sql_literal_quoter_parity():
    """Python's ONE quoter against R's ONE quoter, over strings built to break escaping.

    There used to be TWO R copies — `cases.R::.q` and `codelists.R::.sql_str` — defended as an R
    constraint: each file was `source()`d alone by its own harness. The constraint was circular. The
    files stood alone because the harness sourced them alone, and the harness sourced them alone
    because they stood alone; meanwhile `codelists.R` already required `vocabularies.R`, so "every
    file is self-contained" was not true of the R engine anyway. `run_rwdp.R` has always loaded
    vocabularies -> codelists -> cases in that order, which is what this harness now does.

    Comparing two definitions is a MITIGATION for having two. One definition is the fix, and this
    test now asserts that too: `cases.R` may not define its own quoter again.
    """
    assert not re.search(r"^\s*\.q\s*<-\s*function", R_CASES.read_text(encoding="utf-8"), re.M), \
        "cases.R defines its own SQL quoter again — it must call codelists.R::.sql_str, or a band " \
        "label and a codelist can come to disagree about what a backslash means"

    hostile = [
        r"\d+",                       # the case that motivated the fix: Spark eats a lone backslash
        r"^\s*[34]\s*\+\s*[34]$",
        "o'brien",                    # a quote alone
        r"back\\slash",               # an already-doubled backslash must not be mangled further
        r"quote'and\backslash",       # both, adjacent
        "plain",
        "",
    ]
    for s in hostile:
        py = codelists.sql_str(s)
        # Sourced in run_rwdp.R's order, and cases.R is included so the call site that USES the
        # quoter is loaded by the same script that exercises it.
        script = (f'source({to_r_literal(str(R_VOCAB))})\n'
                  f'source({to_r_literal(str(R_CODELISTS))})\n'
                  f'source({to_r_literal(str(R_CASES))})\n'
                  f'cat(.sql_str({to_r_literal(s)}))\n')
        with tempfile.NamedTemporaryFile("w", suffix=".R", delete=False) as fh:
            fh.write(script)
            path = fh.name
        try:
            proc = subprocess.run([RSCRIPT, path], capture_output=True, text=True, encoding="utf-8")
        finally:
            Path(path).unlink(missing_ok=True)
        assert proc.returncode == 0, f"Rscript failed for {s!r}:\n{proc.stderr}"
        assert proc.stdout == py, (
            f"R .sql_str differs on {s!r}\nPYTHON: {py}\nR     : {proc.stdout}")

    # And the Python half is ONE function object, not two that agree — the assertion docs/ENGINEERING.md
    # prefers over any number of tests that they produce equal strings.
    from engine.stages import clinical
    assert clinical._q is codelists.sql_str, (
        "stages/clinical.py has its own string quoter again — it must import codelists.sql_str, or "
        "a value map and a codelist can come to disagree about what a backslash means")


def test_case_parity_clinical_categoricals():
    # Every value->group block (categoricals + biomarker/lab panel items) reuses stage_case — prove
    # the actual EC + OC config blocks compile byte-identically in both engines.
    for tumor in ("endometrial", "oc"):
        clin = load_yaml(str(product_dir(PRODUCTS, tumor) / "variables" / "clinical.yaml"))
        for cat in clin.get("categoricals", []):
            _assert_case_parity(_stage_case, "stage_case", cat["groups"], cat["column"],
                                f"{tumor}_{cat['name']}")
        for blk_key in ("biomarkers", "labs"):
            blk = clin.get(blk_key) or {}
            for item in blk.get("panel", []):
                if item.get("bands"):           # numeric lab band -> num_bands_case on the cast expr
                    num_col = _band_value_expr(blk["value_column"], item, blk)   # try_cast(... AS DOUBLE)
                    _assert_case_parity(_num_bands_case, "num_bands_case", item["bands"],
                                        num_col, f"{tumor}_{blk_key}_{item['name']}")
                else:                           # categorical -> stage_case
                    _assert_case_parity(_stage_case, "stage_case", item["groups"], blk["value_column"],
                                        f"{tumor}_{blk_key}_{item['name']}")


def test_case_parity_lot_count_bands():
    _assert_case_parity(_lot_bands_case, "lot_bands_case",
                        _TRT["lot_count_bands"], "lotn", "lot_count_bands")


def test_parity_outcome_sql_builders():
    # The per-line time-to-event CASE builders (vis120-gated trtdis/ttd/ttntfl/ttnt) must compile
    # byte-identically in both engines for every line number — so the outcomes inline SQL is parity-
    # proven, not just the codelist/stage compilers. dpm matches the prostate outcomes.yaml.
    from engine.stages.outcomes import (_trtdis_sql, _ttntfl_sql, _ttd_sql, _ttnt_sql,  # noqa: E402
                                        _tsstfl_sql, _tsst_sql)
    dpm = 30.4375
    for n in (1, 2, 3, 5):
        assert _r_case("trtdis_sql", n) == _trtdis_sql(n), f"trtdis_sql({n})"
        assert _r_case("ttntfl_sql", n) == _ttntfl_sql(n), f"ttntfl_sql({n})"
        assert _r_case("tsstfl_sql", n) == _tsstfl_sql(n), f"tsstfl_sql({n})"   # 2nd subsequent treatment
        for maint in (False, True):          # ttd keys off lot{n}ed / lot{n}med per cohort
            assert _r_case("ttd_sql", n, dpm, maint) == _ttd_sql(n, dpm, maint), f"ttd_sql({n},{maint})"
        for has_next in (True, False):
            assert _r_case("ttnt_sql", n, dpm, has_next) == _ttnt_sql(n, dpm, has_next), \
                f"ttnt_sql({n},{has_next})"
            assert _r_case("tsst_sql", n, dpm, has_next) == _tsst_sql(n, dpm, has_next), \
                f"tsst_sql({n},{has_next})"


def test_parity_line_cols():
    # The per-line column-name scheme (lot{i}* / lot{i}m*) is the producer/consumer contract between
    # treatment (producer) and outcomes (consumer). Prove it's byte-identical across engines so the
    # maintenance variants can't drift — e.g. before OC/EC enable line_outcomes on maintenance cohorts.
    from engine.stages.treatment import line_cols   # noqa: E402
    for i in (1, 2, 3):
        for maint in (False, True):
            c = line_cols(i, maint)
            py = "|".join([c["name"], c["start"], c["end"], c["lastdate"], c["dur"], c["cat"], c["catn"]])
            assert _r_case("line_cols_canon", i, maint) == py, f"line_cols({i},{maint})"


def test_parity_taxane_pred():
    # The prior-taxane line-name predicate must compile identically in both engines.
    from engine.stages.treatment import _taxane_pred   # noqa: E402
    for likes in (["%docetaxel%", "%cabazitaxel%"], ["%PACLITAXEL%"]):
        assert _r_case("taxane_pred", likes) == _taxane_pred(likes), f"taxane_pred({likes})"


def test_parity_progression_pred():
    # The real-world-PFS progression-event predicate must compile identically in both engines.
    from engine.stages.outcomes import _progression_pred   # noqa: E402
    for ev in (["isradiographicevidence", "ispathologicevidence", "isclinicalassessmentonly",
                "istumormarkerevidence", "ismixedresponse"], ["isradiographicevidence"]):
        pseudo = "ispseudoprogressionmentioned"
        assert (_r_case("progression_pred", ev, pseudo, "Yes", "No")
                == _progression_pred(ev, pseudo, "Yes", "No")), f"progression_pred({ev})"


def test_parity_platinum_pred():
    # The platinum-agent line-name predicate must compile identically in both engines.
    from engine.stages.proc import _platinum_pred   # noqa: E402
    for agents in (["%carboplatin%", "%cisplatin%", "%oxaliplatin%"], ["%CARBOplatin%"]):
        assert _r_case("platinum_pred", agents, "linename") == _platinum_pred(agents, "linename")


def test_parity_sensitivity_case():
    # The PFI -> Sensitive/Resistant CASE must compile identically in both engines.
    from engine.stages.proc import _sensitivity_case   # noqa: E402
    for thr in (6, 3):
        assert _r_case("sensitivity_case", thr, "pfi") == _sensitivity_case(thr, "pfi")


def test_parity_ads_derived_interval_and_landmark():
    """The cross-stage derivation compilers (outcomes.ads_derived) — no live pack uses them YET,
    so like the new value matchers they get a fixture, including a hostile apostrophe label and
    both the single-event and gated-multi-event shapes of the landmark's least()."""
    from engine.stages.ads_derived import interval_expr, landmark_case   # noqa: E402
    assert _r_case("interval_expr", "metdate", "crpc_date", "months", 30.4375) == \
        interval_expr("metdate", "crpc_date", "months", 30.4375)
    assert _r_case("interval_expr", "lot1ed", "lot2sd", "days", 30.4375) == \
        interval_expr("lot1ed", "lot2sd", "days", 30.4375)
    labels = {"achieved": {"label": "Event-free at 24 months", "code": 1},
              "failed": {"label": "Event before 24 months (O'Brien's criterion)", "code": 2},
              "not_evaluable": {"label": "Not evaluable", "code": 3}}
    for events in ([{"date": "dthdt"}],
                   [{"date": "pfsdt", "when": "pfsfl = 1"}, {"date": "dthdt"}]):
        for key in ("label", "code"):
            py = landmark_case("index_date", 730, events, "fued", labels, key=key)
            r = _r_case("landmark_case", "index_date", 730, events, "fued", labels, key)
            assert r == py, f"landmark_case (key={key}) differs\nPYTHON: {py}\nR     : {r}"
            assert py.startswith("CASE WHEN index_date IS NULL THEN NULL") and py.endswith(" END")
    # WHEN order is the semantics: failed (event inside horizon) must be decided before achieved
    # (censor reaches horizon), or an event-and-long-follow-up patient reads as achieved.
    sql = landmark_case("index_date", 730, [{"date": "dthdt"}], "fued", labels)
    assert sql.index("O''Brien") < sql.index("Event-free at 24 months"), sql


def _r_case_field(func, field, *args):
    """source cases.R and cat func(<args>)$field (for builders that return a named list)."""
    arglits = ", ".join(to_r_literal(a) for a in args)
    script = (f'source({to_r_literal(str(R_VOCAB))})\n'
              f'source({to_r_literal(str(R_CODELISTS))})\n'
              f'source({to_r_literal(str(R_CASES))})\ncat({func}({arglits})${field})\n')
    with tempfile.NamedTemporaryFile("w", suffix=".R", delete=False) as fh:
        fh.write(script)
        path = fh.name
    try:
        proc = subprocess.run([RSCRIPT, path], capture_output=True, text=True, encoding="utf-8")
    finally:
        Path(path).unlink(missing_ok=True)
    assert proc.returncode == 0, f"Rscript failed:\nSTDERR:\n{proc.stderr}"
    return proc.stdout


def test_parity_presence_flag_sql():
    # The presence-flag CASE (e.g. EC radiation_flag) must compile identically in both engines.
    from engine.stages.clinical import _presence_flag_sql   # noqa: E402
    fl = {"from": "radiationtherapydate", "absent": "No/unknown", "present": "Yes"}
    assert _r_case("presence_flag_sql", fl) == _presence_flag_sql(fl)


def test_parity_surgery_sql():
    # The OC surgery CASEs (issurg/surg/surgn/neoadj) must compile identically in both engines.
    from engine.stages.clinical import _surgery_sql   # noqa: E402
    scfg = {"surgery_flag_column": "issurgery", "surgery_date_column": "surgerydate",
            "yes_value": "Yes", "no_value": "No", "pcs_label": "Primary cytoreductive surgery (PCS)",
            "ics_label": "Interval cytoreductive surgery (ICS)", "none_label": "No Surgery"}
    py = _surgery_sql(scfg)
    for field in ("issurg", "surg", "surgn", "neoadj"):
        assert _r_case_field("surgery_sql", field, scfg) == py[field], f"surgery_sql${field}"


def test_parity_closest_panel_block_names():
    """The two engines must agree on WHICH config blocks are closest-to-index panels.

    The list used to be a literal `("biomarkers", "labs")` spelled in six places across both
    engines. It is now `clinical.CLOSEST_PANELS` on the Python side — but R cannot import a Python
    constant, so it necessarily spells its own copy, and a copy is exactly what this repository
    keeps paying for. A family added to one engine and not the other produces a column in one
    engine's output and not the other's, which no byte-comparison of compiled CASE strings would
    ever surface: the block simply is not reached.

    Read out of the R SOURCE rather than restated here, for the same reason — and by parsing the
    text rather than by running Rscript, so this holds even where R is not installed. The names are
    what must agree; nothing about them needs an R session to evaluate.
    """
    from engine.stages.clinical import CLOSEST_PANELS
    src = (FRAMEWORK / "engine-r" / "stages.R").read_text(encoding="utf-8")
    m = re.search(r"(?m)^CLOSEST_PANELS\s*<-\s*c\(([^)]*)\)", src)
    assert m, "engine-r/stages.R no longer defines CLOSEST_PANELS at the top level"
    r_names = tuple(re.findall(r'"([^"]+)"', m.group(1)))
    assert r_names == tuple(CLOSEST_PANELS), \
        f"engine-r/stages.R CLOSEST_PANELS is {r_names}, python has {tuple(CLOSEST_PANELS)}"
    # ...and the R loop actually uses it, rather than keeping a literal beside a now-unused constant.
    assert re.search(r"for \(blk_key in CLOSEST_PANELS\)", src), \
        "the R panel loop no longer iterates CLOSEST_PANELS — the constant is decorative"


def test_parity_selection_defaults_and_resolution():
    """THE TWO ENGINES MUST RESOLVE `pick` AND `tie_break` THE SAME WAY, and for two families they
    did not — an external review found both, and this suite could not have.

      tie_break  R had no default and fell through to DESCENDING date; Python defaults to `prior`
                 (ascending). Two coverage records equidistant either side of index resolved to the
                 later one in R and the earlier one in Python — a different payer, from the same
                 config, with nothing red anywhere.
      pick       R read only the legacy `aggregate: priority` spelling. A block written
                 `pick: priority`, which is exactly what the generated response scaffold emits,
                 ranked by priority in Python and by nearest-to-index in R. For best-response that
                 is the difference between "best over the window" and "whatever fell nearest index".

    Neither was reachable by comparing compiled CASE strings or block-name lists, which is all the
    rest of this file does — the divergence is in the ORDER BY, not in the SELECT. So the resolver
    itself is compared: the defaults, item-over-block precedence, and the legacy-spelling
    allowance, evaluated in R and checked against the Python function.
    """
    if RSCRIPT is None:
        return
    from engine.stages.clinical import DEFAULT_SELECTION, _selection_spec
    cases = [
        ({}, {}, "pick", "nearest"),                       # the defaults, which is where it broke
        ({}, {}, "tie_break", "prior"),
        ({}, {}, "date_basis", "column"),
        ({"pick": "latest"}, {}, "pick", "latest"),        # block-level
        ({"pick": "latest"}, {"pick": "earliest"}, "pick", "earliest"),   # item beats block
        ({}, {"aggregate": "priority"}, "pick", "priority"),              # legacy spelling
        ({"tie_break": "prior"}, {}, "tie_break", "prior"),
    ]
    script = ['source("%s")' % R_DIR.joinpath("stages.R").as_posix().replace('"', '\\"'),
              'out <- c()']
    for blk, item, key, _ in cases:
        script.append(f"out <- c(out, as.character(selection_spec({to_r_literal(blk)}, "
                      f"{to_r_literal(item)}, {to_r_literal(key)})))")
    script.append('cat(paste(out, collapse=","))')
    with tempfile.NamedTemporaryFile("w", suffix=".R", delete=False) as fh:
        fh.write("\n".join(script) + "\n")
        path = fh.name
    try:
        proc = subprocess.run([RSCRIPT, path], capture_output=True, text=True, encoding="utf-8")
    finally:
        Path(path).unlink(missing_ok=True)
    assert proc.returncode == 0, f"Rscript failed:\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}"
    got = proc.stdout.strip().split(",")
    assert len(got) == len(cases), (got, len(cases))
    for (blk, item, key, expect), r_val in zip(cases, got):
        py = str(_selection_spec(blk, item, key))
        assert py == expect, f"python _selection_spec({blk}, {item}, {key}) = {py}, expected {expect}"
        assert r_val == expect, \
            f"R selection_spec({blk}, {item}, {key}) = {r_val!r}, python gives {py!r}"
    # ...and the default TABLES are the same object's worth of values, not merely agreeing here.
    r_defaults = _r_defaults()
    assert r_defaults == {k: str(v) for k, v in DEFAULT_SELECTION.items()}, \
        f"engine-r SELECTION_DEFAULTS {r_defaults} != python {DEFAULT_SELECTION}"


def _run_r(lines):
    """Run an R snippet against engine-r/ and return its stdout, or fail with R's own message."""
    # `%||%` lives in build_ads.R / config.R, which the real runner sources first. stages.R uses it,
    # so a snippet that sources only stages.R dies on a missing operator rather than on the thing
    # under test.
    # cases.R too: `stage_case` lives there, and a harness that cannot reach the STAGE compiler
    # can only test helpers — which is exactly how an R helper that no stage path called passed as
    # covered.
    script = ['`%||%` <- function(a, b) if (is.null(a)) b else a',
              'source("%s")' % R_DIR.joinpath("vocabularies.R").as_posix().replace('"', '\\"'),
              'source("%s")' % R_DIR.joinpath("codelists.R").as_posix().replace('"', '\\"'),
              'source("%s")' % R_DIR.joinpath("cases.R").as_posix().replace('"', '\\"'),
              'source("%s")' % R_DIR.joinpath("stages.R").as_posix().replace('"', '\\"')] + lines
    with tempfile.NamedTemporaryFile("w", suffix=".R", delete=False) as fh:
        fh.write("\n".join(script) + "\n")
        path = fh.name
    try:
        proc = subprocess.run([RSCRIPT, path], capture_output=True, text=True, encoding="utf-8")
    finally:
        Path(path).unlink(missing_ok=True)
    assert proc.returncode == 0, f"Rscript failed:\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}"
    return proc.stdout.strip()


def test_parity_a_scalar_where_a_list_belongs_is_refused_by_BOTH_engines():
    """THE ONE YAML SLIP THE ENGINES READ DIFFERENTLY INSTEAD OF FAILING.

        code_prefix_any: I21        # meant [I21]

    Python iterates a string CHARACTER BY CHARACTER and compiled `LIKE 'i%' OR LIKE '2%' OR LIKE
    '1%'` — which matches most ICD codes beginning with I. R's vapply over a length-1 vector
    compiled the single prefix I21, which is what the author meant. Same config, two cohorts, and
    nothing anywhere went red: an external review found it by reading both compilers.

    Refusing on BOTH sides is the fix, because either engine alone silently answering is the
    failure. The list form must still compile identically, or the refusal would just be a new way
    to break working packs.
    """
    if RSCRIPT is None:
        return
    from engine.codelists import compile_match, LIST_OPERATORS, list_operator_error
    cases = [("code_prefix_any", "I21"), ("code_in", "C18.9"), ("like_any", "%olaparib%")]
    assert {"code_in", "code_prefix_any", "like_any"} <= set(LIST_OPERATORS)

    for op, scalar in cases:
        # Python refuses...
        try:
            compile_match({op: scalar}, "ln", "dc", "dx", "icd10cm")
            raise AssertionError(f"python compiled a scalar {op}")
        except ValueError as exc:
            assert "is not a list" in str(exc), exc
        assert list_operator_error(op, scalar)
        assert list_operator_error(op, [scalar]) is None

    # ...and so does R, on the same three operators.
    probe = []
    for op, scalar in cases:
        probe.append(f'm <- list(); m[["{op}"]] <- "{scalar}"; '
                     f'cat(class(tryCatch(compile_match(m, "ln", "dc", "dx", "icd10cm"), '
                     f'error = function(e) e))[1], "\n")')
    out = _run_r(probe).split()
    assert all(cls in ("simpleError", "error") for cls in out), \
        f"R accepted a scalar where a list belongs: {out}"

    # THE LIST FORM STILL COMPILES, AND IDENTICALLY. Refusing the scalar is only safe if the
    # correct spelling is untouched.
    for op, scalar in cases:
        py = compile_match({op: [scalar]}, "ln", "dc", "dx", "icd10cm")
        r = _run_r([f'm <- list(); m[["{op}"]] <- list("{scalar}"); '
                    f'cat(compile_match(m, "ln", "dc", "dx", "icd10cm"))'])
        assert py == r, f"{op}: python {py!r} != R {r!r}"


def test_parity_scalar_refused_in_clinical_fields_not_only_codelist_operators():
    """THE SAME SLIP, IN THE FIELDS THE OPERATOR CHECK NEVER COVERED.

    `list_operator_error` was keyed on the five CODELIST operators, so the clinical fields kept the
    defect it was written to remove. `from_equals_ci: positive` compiled in Python to

        LOWER(col) IN ('p','o','s','i','t','i','v','e')

    — SQL that runs, returns the wrong cohort, and matches nothing R builds from the same config.
    Keying the predicate on the FIELD NAME is what makes the fix general instead of per-call-site,
    so this asserts the shared list AND that both engines refuse every field in it.
    """
    if RSCRIPT is None:
        return
    from engine.codelists import sequence_error
    from engine.stages.clinical import SEQUENCE_FIELDS

    scalars = {"from_equals_ci": "positive", "match_any": "BRCA1",
               "units": "mg/dL", "priority": "CR"}
    assert set(scalars) <= set(SEQUENCE_FIELDS), SEQUENCE_FIELDS

    for field, scalar in scalars.items():
        assert sequence_error(field, scalar), f"python accepted scalar {field}"
        assert sequence_error(field, [scalar]) is None, f"python refused a valid list {field}"

    # ...and R refuses the same fields, and accepts the same list form. Divergence here is the
    # whole defect, so agreeing on the REFUSAL matters as much as agreeing on the output.
    probe = [f'cat(is.null(sequence_error("{f}", "{s}")), "")' for f, s in scalars.items()]
    probe += [f'cat(is.null(sequence_error("{f}", list("{s}"))), "")' for f, s in scalars.items()]
    out = _run_r(probe).split()
    n = len(scalars)
    assert out[:n] == ["FALSE"] * n, f"R accepted a scalar clinical field: {out[:n]}"
    assert out[n:] == ["TRUE"] * n, f"R refused a valid list: {out[n:]}"


def test_parity_scalar_is_refused_by_the_RUNTIME_path_not_only_the_helper():
    """THE GAP THE EIGHTH REVIEW NAMED. R had `sequence_error` and never called it from the stage
    compiler — the codelist path refused a scalar and the stage path did not. So Python refused and
    R compiled and published, from one config. The parity test that "covered" this called the
    helper directly, which is why a shared helper only one engine invoked looked shared.

    This drives `_stage_case` / `stage_case` — the functions the engines actually run.
    """
    if RSCRIPT is None:
        return
    from engine.stages.clinical import _stage_case, SEQUENCE_FIELDS
    assert "from_regex" in SEQUENCE_FIELDS, "from_regex is iterated and must be a sequence field"

    for field, scalar in (("from_equals_ci", "positive"), ("from_regex", "^C")):
        groups = [{"label": "x", "code": 1, field: scalar}]
        try:
            _stage_case(groups, "col", "label")
            raise AssertionError(f"python compiled a scalar {field} through the stage path")
        except ValueError as exc:
            assert "is not a list" in str(exc), exc
        r = _run_r([f'cat(class(tryCatch(stage_case(list(list(label="x", code=1L, '
                    f'{field}="{scalar}")), "col"), error = function(e) e))[1])'])
        assert r.strip() in ("simpleError", "error"), f"R compiled a scalar {field}: {r!r}"

    # ...and the LIST form still compiles identically through both stage paths.
    py = _stage_case([{"label": "x", "code": 1, "from_equals_ci": ["positive"]}], "col", "label")
    r = _run_r(['cat(stage_case(list(list(label="x", code=1L, '
                'from_equals_ci=list("positive"))), "col"))'])
    assert py == r, f"python {py!r} != R {r!r}"


def test_parity_supersedes_closure_and_weight_cast():
    """CCI DIVERGED IN BOTH HALVES, and only Python was fixed last round.

      hierarchy  R applied the edges one at a time, so a winner zeroed its loser and then read that
                 ZEROED flag when deciding the loser's own losers. With severe -> moderate -> mild
                 all present, `mild` survived: R scored 4 where Python scored 3, and reordering the
                 YAML changed the answer.
      weights    R cast the total `as int` unconditionally, so a condition weighted 1.5 scored 1
                 here and 1.5 in Python.

    Both engines now name the two decisions as functions, and this compares the functions rather
    than a reader comparing two files.
    """
    if RSCRIPT is None:
        return
    from engine.stages.clinical import supersedes_closure, weights_are_integral

    chains = [
        {"severe": ["moderate"], "moderate": ["mild"]},                  # the reported defect
        {"a": ["b", "c"], "b": ["d"], "c": ["d"]},                       # a converging DAG
        {"solo": ["only"]},
    ]
    for supersedes in chains:
        py = {w: sorted(l) for w, l in supersedes_closure(supersedes).items()}
        lines = [f'cl <- supersedes_closure({to_r_literal({k: list(v) for k, v in supersedes.items()})})',
                 'cat(paste(vapply(sort(names(cl)), function(n) '
                 'paste0(n, "=", paste(sort(cl[[n]]), collapse="|")), ""), collapse=";"))']
        r = _run_r(lines)
        expect = ";".join(f"{n}={'|'.join(py[n])}" for n in sorted(py))
        assert r == expect, f"closure {supersedes}: R {r!r} != python {expect!r}"

    # The reported number, spelled out: severe(3) + moderate(2) + mild(1), all present.
    closed = supersedes_closure({"severe": ["moderate"], "moderate": ["mild"]})
    assert closed["severe"] == {"moderate", "mild"}, \
        "severe must close over mild — this is the 4-vs-3 divergence"

    for weights, integral in [([1, 2, 3], True), ([1, 1.5], False), ([2.0, 3.0], True)]:
        assert weights_are_integral(weights) is integral
        r = _run_r([f'cat(tolower(as.character(weights_are_integral({to_r_literal(weights)}))))'])
        assert r == str(integral).lower(), f"weights {weights}: R {r!r} != python {integral}"


def test_parity_record_date_basis_is_used_by_both_engines():
    """R DEFINED `date_basis` AND NEVER USED IT. The panel loop read `date_column` for the window,
    the gap, the ordering and the emitted date, so a pack configuring
    `date_basis: {method: later_of, columns: [collected, resulted]}` either failed in R for want of
    a `date_column`, or — with both keys present — windowed and ranked on a DIFFERENT date from
    Python and selected a different row.

    The resolver defaults were already compared; the EXECUTION was not, which is exactly the gap
    the workflow header admits ("mirrored by convention"). This compares the date expression each
    engine actually windows on.
    """
    if RSCRIPT is None:
        return
    cases = [
        ({"date_column": "resultdate"}, "resultdate"),
        ({"date_basis": {"method": "column"}, "date_column": "resultdate"}, "resultdate"),
        ({"date_basis": {"method": "later_of", "columns": ["collected", "resulted"]}},
         "greatest(collected, resulted)"),
        ({"date_basis": {"method": "earlier_of", "columns": ["collected", "resulted"]}},
         "least(collected, resulted)"),
    ]
    for blk, expect in cases:
        r = _run_r([f'cat(record_date_sql({to_r_literal(blk)}))'])
        assert r == expect, f"R record_date_sql({blk}) = {r!r}, expected {expect!r}"

    # ...and the R panel loop must WINDOW on that expression, not on date_column. Read off the
    # source, because a loop that computes `_rdate` and then filters on something else would pass
    # every check above.
    src = (R_DIR / "stages.R").read_text(encoding="utf-8")
    loop = src[src.index("for (blk_key in CLOSEST_PANELS)"):]
    loop = loop[:loop.index("clinical_metastatic_sites")] if "clinical_metastatic_sites" in loop else loop
    assert 'record_date_sql(blk)' in loop, "the panel loop no longer materialises the record date"
    assert 'date_col <- "_rdate"' in loop, "the panel loop must window on the materialised date"


def _r_defaults():
    """engine-r/stages.R's SELECTION_DEFAULTS, read out of the source."""
    src = (R_DIR / "stages.R").read_text(encoding="utf-8")
    m = re.search(r"(?m)^SELECTION_DEFAULTS\s*<-\s*list\(([^)]*)\)", src)
    assert m, "engine-r/stages.R no longer defines SELECTION_DEFAULTS"
    return dict(re.findall(r'(\w+)\s*=\s*"([^"]+)"', m.group(1)))


if __name__ == "__main__":
    if RSCRIPT is None:
        print("SKIP test_r_parity: Rscript not on PATH "
              "(R<->Python codelist parity is verified where R is available).")
        sys.exit(0)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
