"""A record may only be carried forward on evidence — never on resemblance.

`platform/tools/spec_diff.py` answers "what did this spec revision actually change, and what can
carry". The answer is worth having because prostate 202606 -> 202607 changed NOTHING (199 of 200
rows byte-identical) and was re-drafted in full. It is also the answer with the worst failure mode
in the framework: a record wrongly carried forward is a requirement nobody re-read, still asserting
a rule the specification may no longer make, with a digest that says somebody checked.

So every test here pushes in the same direction — that carrying is hard and re-drafting is the
default:

  * a record with no digest, or whose cited row vanished, must be RE-DRAFT and never carried;
  * a pack with no extraction must REFUSE, not report zero changes;
  * the verdict must come from `contract_lint.spec_digest`, not a second implementation.

Run: python3 tests/test_spec_diff.py (or pytest).
"""
import ast
import os
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
TOOLS = FRAMEWORK / "tools"
REPO = FRAMEWORK.parent
sys.path.insert(0, str(TOOLS))

import contract_lint as cl   # noqa: E402
import product_gates         # noqa: E402
import spec_diff             # noqa: E402

A = "products/oncology/prostate/202606"
B = "platform/tests/fixtures/prostate_202607"


def _extracted(pack):
    return os.path.exists(os.path.join(str(REPO), pack, "spec_pipeline", "out", "extracted.json"))


def test_the_two_revisions_this_was_written_for_still_look_the_same():
    """The premise. If a future revision genuinely changes the spec these numbers move, and the
    test should be re-read rather than relaxed — it is here to keep the fixture honest, not to
    freeze the packs."""
    assert _extracted(A) and _extracted(B), "both prostate packs need an extraction"
    delta, note = spec_diff.spec_delta(A, B, str(REPO))
    assert note is None, note
    assert delta["unchanged"] > 0.9 * delta["old_rows"], \
        f"the revisions diverged: {delta} — re-read this test rather than loosening it"


def test_an_unchanged_specification_carries_its_records():
    """The whole point. 202607 re-drafted what 202606 had already settled."""
    verdicts = spec_diff.carry(A, B, str(REPO))
    assert verdicts, "no records were assessed"
    carried = [v for v in verdicts if v[1] in (spec_diff.AS_IS, spec_diff.NEW_REF)]
    assert len(carried) > 0.9 * len(verdicts), \
        f"only {len(carried)} of {len(verdicts)} carried across an unchanged specification"


def test_a_different_specification_carries_nothing():
    """FAIL-CLOSED, and the direction that matters. Ovarian's spec shares no row with prostate's,
    so every prostate record must be re-drafted — a tool that carried any of them would be
    asserting a prostate rule over an ovarian specification."""
    oc = "products/oncology/oc/202606"
    if not _extracted(oc):
        return
    verdicts = spec_diff.carry(A, oc, str(REPO))
    assert verdicts
    carried = [v for v in verdicts if v[1] != spec_diff.REDRAFT]
    assert not carried, f"{len(carried)} record(s) carried onto a different tumour's spec: {carried[:3]}"


def test_a_record_with_no_digest_is_never_carried():
    """A digest is the evidence. Without one there is nothing to check, and 'nothing to check' is
    RE-DRAFT — the same rule the rest of this codebase applies to an absent counter."""
    verdicts = {v: (verdict, detail) for v, verdict, detail in spec_diff.carry(A, B, str(REPO))}
    for block in cl.records(cl.read(os.path.join(str(REPO), A, spec_diff.CONTRACT))):
        vid = (cl._scalar(block, "variable_id") or "").strip()
        digest = cl._scalar(block, "spec_digest")
        refs = cl._list(block, "spec_refs") or []
        if digest and digest != cl.NA and refs and refs != [cl.NO_SPEC_ROW]:
            continue
        assert verdicts.get(vid, ("",))[0] == spec_diff.REDRAFT, \
            f"{vid} has no checkable digest but was not marked re-draft"


def test_a_pack_with_no_extraction_refuses_rather_than_reporting_no_changes():
    """`unchanged: 0, added: 0` and "there is no extraction" are opposite answers. The second
    rendered as the first would report a revision that changed nothing."""
    without = [p for p in sorted(product_gates.products(str(REPO))) if not _extracted(p)]
    assert without, "every pack has an extraction — this test would prove nothing"
    delta, note = spec_diff.spec_delta(A, without[0], str(REPO))
    assert delta is None and note and "nothing was compared" in note, note
    assert spec_diff.carry(A, without[0], str(REPO)) is None
    text = spec_diff.render(A, without[0], str(REPO))
    assert "nothing was compared" in text
    assert "carries as-is" not in text, "an unreadable pack rendered as a carry-forward report"


def test_the_verdict_is_the_lints_digest_and_not_a_second_one():
    """`spec_digest` is what I15 uses to catch an edit made in place. Recomputing it differently
    here would mean the lint and the carry-forward could disagree about whether the same text
    changed."""
    assert spec_diff.cl is cl
    tree = ast.parse((TOOLS / "spec_diff.py").read_text(encoding="utf-8"))
    called = {n.func.attr for n in ast.walk(tree)
              if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)}
    assert "spec_digest" in called and "spec_rows" in called
    assert "sha256" not in called and "md5" not in called, "spec_diff hashes something itself"


def test_it_writes_nothing():
    import hashlib
    def snap():
        out = {}
        for pack in (A, B):
            for rel in (spec_diff.CONTRACT, os.path.join("spec_pipeline", "out", "extracted.json"),
                        os.path.join("handoff", "DECISIONS.md")):
                p = Path(str(REPO)) / pack / rel
                if p.exists():
                    out[str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()
        return out
    before = snap()
    spec_diff.render(A, B, str(REPO))
    spec_diff.carried_decisions(A, B, str(REPO))
    assert snap() == before, "spec_diff modified a pack"


def test_it_is_not_deployed_to_production():
    import deploy_tree
    assert not any("spec_diff" in str(f) for f in deploy_tree.ROOT_FILES)


def _revision_pair(tmp, new_tab_lines, cited_row_domain="outcomes"):
    """Two packs holding the same tab, extracted for real, differing only in the NEW one's rows.

    Built through `spec_extract` rather than by hand-writing an `extracted.json`, because the whole
    question is what happens to ROW NUMBERS when a revision inserts something — and a hand-written
    fixture is a fixture where somebody chose the row numbers to make the test pass.
    """
    import subprocess

    OLD = ["Variable\tDefinition\tValues",
           "OS\tOverall survival from index\tDays",
           "PFS\tProgression-free survival\tDays",
           "ORR\tObjective response rate\t1=Yes 0=No"]

    def build(name, lines):
        pack = Path(tmp) / name
        spec = pack / "spec"
        out = pack / "spec_pipeline" / "out"
        spec.mkdir(parents=True)
        out.mkdir(parents=True)
        (pack / "handoff").mkdir()
        (spec / "6.Outcomes.tsv").write_text("\n".join(lines) + "\n", encoding="utf-8")
        r = subprocess.run([sys.executable, str(TOOLS / "spec_extract.py"), str(spec),
                            "--out", str(out / "extracted.json")], capture_output=True, text=True, encoding="utf-8")
        assert r.returncode == 0, r.stderr[-400:]
        return pack

    old_pack, new_pack = build("old", OLD), build("new", new_tab_lines)

    # The record cites the row PFS occupies in the OLD extraction, with the digest computed from it —
    # exactly what a drafter's record carries.
    old_rows = cl.spec_rows(str(old_pack))
    pfs_row = next(n for n, _h in old_rows[cited_row_domain].items()
                   if _h == _hash_of(str(old_pack), "PFS"))
    ref = f"{cited_row_domain}:{pfs_row}"
    digest = cl.spec_digest([ref], old_rows)
    assert digest, "the fixture's own digest would not compute"
    (old_pack / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
        "```yaml\nvariable_id: PFS\n"
        f"spec_refs: [{ref}]\n"
        f"spec_digest: {digest}\n"
        "decision_ids: [PFS-WINDOW]\n"
        "status: {requirement: draft, source: unverified, implementation: implemented, "
        "validation: not_run}\n```\n", encoding="utf-8")
    (old_pack / "handoff" / "DECISIONS.md").write_text(
        "| ID | Question | Conflict / evidence | Owner | Approved answer | Status |\n"
        "|---|---|---|---|---|---|\n"
        "| PFS-WINDOW | Which progression date? | first after index | RWB | **the first** | RESOLVED |\n",
        encoding="utf-8")
    return f"{Path(tmp).name}/old", f"{Path(tmp).name}/new", str(Path(tmp).parent), ref


def _hash_of(pack, variable):
    import json
    with open(os.path.join(pack, "spec_pipeline", "out", "extracted.json"), encoding="utf-8") as fh:
        for row in json.load(fh)["rows"]:
            if str(row.get("variable", "")).strip() == variable:
                return row["content_hash"]
    raise AssertionError(f"{variable} not in {pack}")


def test_a_row_inserted_above_a_citation_is_a_NEW_REF_not_a_re_draft():
    """The verdict the two real revisions never exercised, and the one the tool exists for.

    RWB inserting anything above a cited row shifts every later coordinate. The text is word-for-word
    the same; only the number moved. A tool that called that "changed" would send a person to re-read
    a rule nobody touched — which is the cost this whole comparison is trying to avoid, arriving by a
    different route.
    """
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        inserted = ["Variable\tDefinition\tValues",
                    "AGE\tAge at index\tYears",            # <- new row, above PFS
                    "OS\tOverall survival from index\tDays",
                    "PFS\tProgression-free survival\tDays",
                    "ORR\tObjective response rate\t1=Yes 0=No"]
        old, new, root, ref = _revision_pair(tmp, inserted)
        verdicts = spec_diff.carry(old, new, root)
        assert verdicts, "no records were assessed"
        vid, verdict, detail = verdicts[0]
        assert vid == "PFS", verdicts
        assert verdict == spec_diff.NEW_REF, \
            (f"an inserted row above the citation produced {verdict!r}. The text did not change; "
             f"only its coordinate did, and re-drafting it is the cost this tool removes. {detail}")
        assert "->" in detail, f"the new coordinate must be stated, not just the verdict: {detail}"

        # The settled answer travels with it. That is the thing 202606 -> 202607 lost.
        kept = spec_diff.carried_decisions(old, new, root)
        assert "PFS-WINDOW" in kept, kept


def test_an_edit_in_place_is_a_re_draft_however_still_the_row_number_is():
    """The case row numbers cannot see, and the reason the digest is over TEXT.

    The citation still resolves, the coordinate is unchanged, and the rule now says something else.
    Anything keyed on position reports this as untouched.
    """
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        edited = ["Variable\tDefinition\tValues",
                  "OS\tOverall survival from index\tDays",
                  "PFS\tProgression-free survival, censored at last visit\tDays",   # <- same row
                  "ORR\tObjective response rate\t1=Yes 0=No"]
        old, new, root, _ref = _revision_pair(tmp, edited)
        vid, verdict, detail = spec_diff.carry(old, new, root)[0]
        assert (vid, verdict) == ("PFS", spec_diff.REDRAFT), (vid, verdict, detail)
        assert "cited text changed" in detail, detail
        # the matcher names WHERE to re-read (same domain, same variable name — spec_extract's own
        # recipe) without turning the change into a carry
        assert "likely successor" in detail and "'PFS'" in detail, detail
        assert "--item" in detail, detail
        assert not spec_diff.carried_decisions(old, new, root), \
            "a decision must not carry on a requirement whose text changed"


def test_the_successor_pointer_never_guesses_between_two_same_name_rows():
    """The recipe's own boundary: a variable name legitimately recurs, so two candidate rows are a
    person's choice, and a renamed row is nobody's successor — the pointer appears only when the
    match is unique, and the verdict is RE-DRAFT in every branch."""
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        twice = ["Variable\tDefinition\tValues",
                 "OS\tOverall survival from index\tDays",
                 "PFS\tProgression-free survival, censored at last visit\tDays",
                 "PFS\tProgression-free survival, sensitivity variant\tDays",
                 "ORR\tObjective response rate\t1=Yes 0=No"]
        old, new, root, _ref = _revision_pair(tmp, twice)
        vid, verdict, detail = spec_diff.carry(old, new, root)[0]
        assert (vid, verdict) == ("PFS", spec_diff.REDRAFT), (vid, verdict, detail)
        assert "AMBIGUOUS successors" in detail and "a person chooses" in detail, detail
        assert "likely successor" not in detail, detail
    with tempfile.TemporaryDirectory() as tmp:
        renamed = ["Variable\tDefinition\tValues",
                   "OS\tOverall survival from index\tDays",
                   "RWPFS\tProgression-free survival, real-world\tDays",
                   "ORR\tObjective response rate\t1=Yes 0=No"]
        old, new, root, _ref = _revision_pair(tmp, renamed)
        vid, verdict, detail = spec_diff.carry(old, new, root)[0]
        assert (vid, verdict) == ("PFS", spec_diff.REDRAFT), (vid, verdict, detail)
        assert "successor" not in detail, detail


def test_a_deleted_row_is_a_re_draft_and_says_the_row_is_gone():
    """Fail-closed on absence. 'The row it cited is not there' is not a reason to carry anything."""
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        deleted = ["Variable\tDefinition\tValues",
                   "OS\tOverall survival from index\tDays",
                   "ORR\tObjective response rate\t1=Yes 0=No"]        # PFS removed entirely
        old, new, root, _ref = _revision_pair(tmp, deleted)
        vid, verdict, detail = spec_diff.carry(old, new, root)[0]
        assert (vid, verdict) == ("PFS", spec_diff.REDRAFT), (vid, verdict, detail)
        assert "changed" in detail or "absent" in detail, detail


def test_a_revision_that_changes_nothing_carries_and_says_so():
    """The control. Without it the three tests above pass on a tool that re-drafts everything."""
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        same = ["Variable\tDefinition\tValues",
                "OS\tOverall survival from index\tDays",
                "PFS\tProgression-free survival\tDays",
                "ORR\tObjective response rate\t1=Yes 0=No"]
        old, new, root, _ref = _revision_pair(tmp, same)
        vid, verdict, _d = spec_diff.carry(old, new, root)[0]
        assert (vid, verdict) == ("PFS", spec_diff.AS_IS)
        delta, note = spec_diff.spec_delta(old, new, root)
        assert note is None and delta["removed"] == 0 and delta["added"] == 0, delta




def test_a_revision_that_fixes_nothing_is_said_to_fix_nothing():
    """The 202607 revision changed one row and none of the 13 reported defects. The findings check
    must say exactly that — a revision adopted without this answer re-inherits every defect, and a
    re-draft against it re-reports them under new IDs, which is the loop this exists to end."""
    checks, note = spec_diff.findings_check(A, B, str(REPO))
    assert note is None, note
    assert checks, "the live pack's open findings vanished — this test would prove nothing"
    verdicts = {v for _f, v, _d in checks}
    assert verdicts == {spec_diff.STILL_THERE}, \
        f"a no-change revision reported something other than 'still there': {verdicts}"
    page = spec_diff.render(A, B, str(REPO))
    assert "UNCHANGED in the new revision" in page and "SQ-01" in page


def test_a_corrected_row_is_reported_for_review_and_closure():
    """When the cited text really changes, the verdict flips to review-and-close — and ONLY for the
    finding whose row moved, so one correction cannot read as a clean bill for the register."""
    import json
    import shutil
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        newpack = os.path.join(tmp, "corrected_rev")
        shutil.copytree(os.path.join(str(REPO), B), newpack,
                        ignore=shutil.ignore_patterns("__pycache__", "reference"))
        ext = os.path.join(newpack, "spec_pipeline", "out", "extracted.json")
        with open(ext, encoding="utf-8") as fh:
            data = json.load(fh)
        hit = 0
        for row in data["rows"]:
            # SQ-01 cites study_period:13 — the impossible 4/31/2026 literal
            if row.get("domain") == "study_period" and row.get("row") == 13:
                row["content_hash"] = "corrected-" + row.get("content_hash", "")
                hit += 1
        assert hit == 1, f"study_period:13 matched {hit} rows — the fixture moved under this test"
        with open(ext, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
        checks, note = spec_diff.findings_check(A, newpack, str(REPO))
        assert note is None, note
        by_id = {f: (v, d) for f, v, d in checks}
        assert by_id["SQ-01"][0] == spec_diff.CHANGED, by_id["SQ-01"]
        # every finding citing OTHER rows still reads as uncorrected
        others = {f: v for f, (v, _d) in by_id.items() if f != "SQ-01"}
        assert set(others.values()) == {spec_diff.STILL_THERE}, others


def test_a_cited_row_that_merely_moved_is_still_the_same_defect():
    """Rows shift whenever a revision inserts anything above them. A checker that looked the row
    number up would report the shifted defect as "changed — review", and a person would close a
    finding the revision never touched. Content is looked up ANYWHERE in the domain, exactly like
    `carry` — asserted here by moving SQ-01's cited text to a different row number."""
    import json
    import shutil
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        newpack = os.path.join(tmp, "shifted_rev")
        shutil.copytree(os.path.join(str(REPO), B), newpack,
                        ignore=shutil.ignore_patterns("__pycache__", "reference"))
        ext = os.path.join(newpack, "spec_pipeline", "out", "extracted.json")
        with open(ext, encoding="utf-8") as fh:
            data = json.load(fh)
        row13 = next(r for r in data["rows"]
                     if r.get("domain") == "study_period" and r.get("row") == 13)
        moved = dict(row13, row=99)
        row13["content_hash"] = "something-else-now-lives-at-13"
        data["rows"].append(moved)
        with open(ext, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
        checks, note = spec_diff.findings_check(A, newpack, str(REPO))
        assert note is None, note
        by_id = {f: (v, d) for f, v, d in checks}
        verdict, detail = by_id["SQ-01"]
        assert verdict == spec_diff.STILL_THERE, \
            f"a moved row read as corrected: {verdict} {detail}"
        assert "->99" in detail, f"the new location is not named: {detail}"


def test_a_finding_this_cannot_see_is_never_reported_as_gone():
    """Fail-closed: an unparsable citation or a cited row absent from the OLD extraction is
    UNCHECKABLE — named, not dropped. A defect the checker cannot find is not a defect that went
    away; it is a citation that needs fixing before the round-trip can be tracked."""
    import shutil
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        oldpack = os.path.join(tmp, "oldpack")
        shutil.copytree(os.path.join(str(REPO), A), oldpack,
                        ignore=shutil.ignore_patterns("__pycache__", "reference"))
        reg = os.path.join(oldpack, "handoff", "SPEC_QC_FINDINGS.md")
        with open(reg, encoding="utf-8") as fh:
            text = fh.read()
        rows = [l for l in text.splitlines() if l.startswith("| SQ-01 |")]
        assert len(rows) == 1
        text += ("\n| SQ-XA | `clinical:9999` | cites a row the extraction never held | n/a | — | "
                 "**open** |\n| SQ-XB | no citation at all | prose without a ref | n/a | — | "
                 "**open** |\n")
        with open(reg, "w", encoding="utf-8") as fh:
            fh.write(text)
        checks, note = spec_diff.findings_check(oldpack, B, str(REPO))
        assert note is None, note
        by_id = {f: v for f, v, _d in checks}
        assert by_id["SQ-XA"] == spec_diff.UNCHECKABLE
        assert by_id["SQ-XB"] == spec_diff.UNCHECKABLE


def test_the_carry_plan_is_the_redraft_turned_into_a_checklist():
    """202606 -> 202607: 199 of 200 rows identical, and the revision was nonetheless re-drafted in
    full. The plan makes the alternative mechanical: one judgment per carrying record — DRAFTER
    fields only — plus the exact command per record. What may not carry is as load-bearing as what
    may: no status (an approval never travels by omission), no spec fields (re-supplied from the
    NEW extraction by --item), RE-DRAFT records excluded by name, multi-target citations handed to
    a person rather than guessed."""
    import subprocess
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        written, commands, by_hand, excluded, note = spec_diff.carry_plan(A, B, tmp, str(REPO))
        assert note is None
        assert len(written) >= 190 and len(commands) >= 190, (len(written), len(commands))
        gone = {vid for vid, _w in excluded}
        assert gone == {"PRIOR_TAX", "CONMED"}, \
            f"the fail-closed exclusions moved: {gone} — re-read before loosening"
        assert {vid for vid, _w in by_hand} == {"DTHFL", "DTHFL__2"}, by_hand
        for path in written[:20] + [p for p in written if "AGE" in p][:1]:
            body = Path(path).read_text(encoding="utf-8")
            for banned in ("\nstatus:", "\nspec_refs:", "\nspec_digest:", "\nrequired_rule:"):
                assert banned not in body, f"{path} carries {banned.strip()} — not the drafter's"
        manifest = Path(tmp, "carry_commands.txt").read_text(encoding="utf-8")
        assert f"--product {B} --item " in manifest and "--apply" in manifest
        assert "RE-DRAFT PRIOR_TAX" in manifest and "BY HAND  DTHFL" in manifest
    # ...and the plan is refused INSIDE a pack: it is an input to drafting, not a pack artifact.
    # Exercised against a COPY, never the live pack — this is a test of a guard, and a guard test
    # pointed at the real repository is a test that damages it on exactly the day the guard breaks.
    import shutil
    with tempfile.TemporaryDirectory() as tmp:
        copy = os.path.join(tmp, "oldpack")
        shutil.copytree(os.path.join(str(REPO), A), copy,
                        ignore=shutil.ignore_patterns("__pycache__", "reference"))
        r = subprocess.run([sys.executable, str(TOOLS / "spec_diff.py"), copy, B,
                            "--carry-plan", os.path.join(copy, "handoff", "plan")],
                           capture_output=True, text=True, encoding="utf-8", errors="replace",
                           cwd=str(REPO))
        assert r.returncode != 0 and "not a pack artifact" in (r.stdout + r.stderr)
        assert not os.path.exists(os.path.join(copy, "handoff", "plan"))


def test_a_carried_judgment_drafts_through_the_full_governed_path():
    """The plan's output is an INPUT to contract_record, not a bypass of it: the emitted command runs
    the whole drafting path — AI gate, every invariant, evidence merged from the NEW extraction. One
    record is driven end-to-end here; if the judgment shape and the tool's expectations drift, this
    is what goes red."""
    import subprocess
    import tempfile
    sys.path.insert(0, str(FRAMEWORK / "tests"))
    sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))
    import _packs
    from test_spec_slice import _approved
    new_pack = _approved(_packs.PARKED)          # a signed copy — the gate passes honestly
    with tempfile.TemporaryDirectory() as tmp:
        written, commands, _bh, _ex, note = spec_diff.carry_plan(A, str(new_pack), tmp, str(REPO))
        assert note is None
        cmd = next(c for c in commands if f"{os.sep}AGE.yaml" in c or "/AGE.yaml" in c)
        argv = cmd.split()[1:]                   # drop `python3`
        argv[0] = str(REPO / argv[0])            # the tool path, repo-relative in the plan
        r = subprocess.run([sys.executable] + argv, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", cwd=str(REPO))
        assert r.returncode == 0, r.stdout + r.stderr
        text = cl.read(os.path.join(str(new_pack), "handoff", "FUNCTIONAL_CONTRACT.md"))
        block = next(b for b in cl.records(text)
                     if (cl._scalar(b, "variable_id") or "").strip() == "AGE")
        # the spec fields came from the NEW extraction — the digest proves it (I15's own check)
        refs = cl._list(block, "spec_refs")
        assert refs and refs != [cl.NO_SPEC_ROW]
        srows = cl.spec_rows(str(new_pack))
        assert cl._scalar(block, "spec_digest") == cl.spec_digest(refs, srows), \
            "the carried record's digest does not match the new extraction it was drafted against"


if __name__ == "__main__":
    os.chdir(FRAMEWORK)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
