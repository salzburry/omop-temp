"""The Domino app is a WINDOW, never a hand — pinned here, not just promised in its docstring.

Run: python3 tests/test_app_serve.py (or pytest).

Tests monkeypatch by hand (save/patch/try/finally) rather than via the pytest fixture, so the
direct `python3 tests/test_app_serve.py` runner keeps working — it calls each test with no args.
"""
import subprocess
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(REPO / "app"))

import serve    # noqa: E402

# The suite runs on a DEV checkout, which is legitimately dirty mid-change — and the portal now
# refuses a dirty tree per request (an edited checkout under a clean footer proves nothing). The
# refusal itself is under test below; every other test simulates a clean tree so the page
# assertions exercise the pages.
_REAL_DIRTY, serve._dirty = serve._dirty, (lambda: [])

PACK = "products/oncology/prostate/202606"


def test_every_surface_serves_and_the_allowlist_is_the_repo():
    assert PACK in serve.packs()
    status, body = serve.index()
    assert status == 200 and PACK.encode() in body
    # the index is a stakeholder board: plain-language labels, and each pack's standing in
    # status.py's OWN words — the app never composes a second, flattering summary
    for label in (b"where this stands", b"every rule, three ways", b"what to prepare",
                  b"questions awaiting an answer"):
        assert label in body, label
    assert serve._standings().get(PACK, "").encode() in body
    assert serve._standings()[PACK], "the board must show a live standing, not a blank"
    # the two stakeholder acts lead; reviewer views sit behind a "deeper" line — a workflow, not
    # a menu of equal things
    assert body.index(b"questions awaiting an answer") < body.index(b"deeper:")
    assert body.index(b"deeper:") < body.index(b"every rule, three ways")
    # a board titled "where everything stands" shows EVERY pack status.py reports — the ones with
    # no handoff/ carry their standing and say why there is nothing to click, instead of vanishing
    assert b"products/oncology/dlbcl/YYYYMM" in body and b"no handoff yet" in body
    status, body = serve.page("flow", PACK)
    assert status == 200 and len(body) > 5000
    assert b"serving commit" in body, \
        "the provenance footer must ride GENERATED pages, not only the index"
    status, body = serve.questions(PACK)
    assert status == 200 and len(body) > 2000 and b"serving commit" in body
    status, body = serve.knowledge("fued")
    assert status == 200 and b"FUED-DEFINITION" in body
    # a query term is data, never a flag — `--suggest` and `--decision X` must not change verbs
    status, body = serve.knowledge("--suggest")
    assert status == 200 and b"candidate pair" not in body, \
        "a query term reached the CLI as a flag"
    status, body = serve.knowledge("--decision FUED-DEFINITION")
    assert (b"for query" in body or b"matches query" in body) and b"for decision" not in body, \
        "a query term reached the CLI as a flag"
    # a pack is served because the repository holds it, never because a URL names it
    for bad in ("products/../etc", "products/oncology/prostate/999999", "/etc/passwd", ""):
        status, _ = serve.page("flow", bad)
        assert status == 404, bad
    status, _ = serve.page("edit", PACK)
    assert status == 404, "only render_html's own views are served"


def test_the_app_writes_nothing_into_the_checkout_and_stamps_its_provenance():
    import os
    assert not str(serve.TMP).startswith(str(REPO)), \
        "rendered pages must land OUTSIDE the tree — the restricted-output rule"
    _, body = serve.index()
    assert b"read-only" in body and serve.commit().encode() in body, \
        "every page carries the served commit — what is on screen is what is merged"
    # the module performs no governed act: the only tools it may invoke are the read-only four
    src = (REPO / "app" / "serve.py").read_text(encoding="utf-8")
    for forbidden in ("--apply", "--forms", "--write", "--record-digest", "run_spec_pipeline"):
        assert forbidden not in src, f"the window grew a hand: {forbidden}"
    assert os.access(str(REPO / "app.sh"), os.X_OK), "Domino runs app.sh; it must be executable"


def test_a_failed_status_tool_is_said_out_loud_never_blank_standings():
    # status.py exiting nonzero must NOT render a plausible board with blank standings — blank
    # reads as "no news is good news". The index says the wording out loud, banner AND every row.
    real = serve._tool
    def failing(args):
        if args[0] == "status.py":
            return subprocess.CompletedProcess(args, 2, stdout="products/oncology/prostate/202606"
                                               "   half a row printed before dying", stderr="boom")
        return real(args)
    serve._tool = failing
    try:
        assert serve._standings() is None, \
            "a nonzero status.py is a failure, not standings — partial stdout must be discarded"
        status, body = serve.index()
    finally:
        serve._tool = real
    assert status == 200
    phrase = serve.STATUS_FAILED.encode("utf-8")
    assert b"status unavailable" in body and b"will not guess" in body
    assert body.count(phrase) >= 1 + len(serve.packs()), \
        "the failure wording must ride the banner AND every pack row"
    assert PACK.encode() in body and b"page?view=flow" in body, \
        "the board still lists served packs — the links still work during a status outage"
    assert b"half a row printed" not in body, "partial stdout from a dead tool is a guess"


class _FakeProc:
    """A Popen stand-in with real byte streams — the bounded reader is exercised for real."""
    def __init__(self, out=b"", err=b"", hang=False):
        import io
        self.stdout, self.stderr = io.BytesIO(out), io.BytesIO(err)
        self._hang, self.killed, self.wait_timeout = hang, False, None

    def wait(self, timeout=None):
        self.wait_timeout = timeout
        if self._hang and not self.killed:
            raise subprocess.TimeoutExpired(cmd="x", timeout=timeout)
        return -9 if self.killed else 0

    def kill(self):
        self.killed = True


def test_status_that_exits_zero_with_nothing_readable_is_also_a_failure():
    """The nonzero-exit branch was closed; exit ZERO with empty or reshaped output still parsed to
    zero standings and rendered every pack blank — which reads as "all quiet", the same disguise.
    No rows parsed is a failure, whatever the exit code said."""
    real = serve._tool
    for stdout in ("", "   \n\n", "unexpected banner\nno product rows here\n"):
        serve._tool = (lambda args, _o=stdout:
                       subprocess.CompletedProcess(args, 0, stdout=_o, stderr="")
                       if args[0] == "status.py" else real(args))
        try:
            assert serve._standings() is None, f"blank standings from {stdout!r} read as a board"
            status, body = serve.index()
        finally:
            serve._tool = real
        assert status == 200 and b"status unavailable" in body, \
            "an unreadable status must say so, not render a quiet board"


def test_a_hung_tool_is_killed_and_the_500_names_it():
    # no timeout meant one hung tool held a request (and its thread) forever
    serve._proven()                                 # resolve provenance before Popen is patched
    real, real_commit = serve.subprocess.Popen, serve.commit
    serve.subprocess.Popen = lambda *a, **k: _FakeProc(hang=True)
    serve.commit = lambda: serve.COMMIT             # the per-request HEAD check must not hang too
    try:
        status, body = serve.suggest()
    finally:
        serve.subprocess.Popen, serve.commit = real, real_commit
    assert status == 500
    assert b"timed out" in body and b"knowledge_graph.py" in body, \
        "the timeout page must say WHICH tool timed out"


def test_tool_output_is_capped_in_memory_and_the_timeout_is_actually_passed():
    """`capture_output=True` collected a child's WHOLE stream before slicing — an external review
    measured ~200 MiB of peak RSS for a 64 MiB child to return 256 KiB. The reader is now
    incremental into capped buffers, so what _tool ever holds is bounded, and a runaway stream
    kills the child rather than draining it forever."""
    real = serve.subprocess.Popen
    procs = []
    def fake(*a, **k):
        p = _FakeProc(out=b"x" * (serve.TOOL_CAP + 4096), err=b"y" * (serve.TOOL_CAP + 4096))
        procs.append(p)
        return p
    serve.subprocess.Popen = fake
    try:
        r = serve._tool(["status.py"])
    finally:
        serve.subprocess.Popen = real
    assert procs and procs[0].wait_timeout == serve.TOOL_TIMEOUT, \
        "_tool must pass the timeout to the child wait"
    assert len(r.stdout) <= serve.TOOL_CAP and len(r.stderr) <= serve.TOOL_CAP, \
        "captured streams must be capped — a runaway tool must not balloon a response"
    assert r.stdout and r.stderr, "the caps must keep content, not drop the streams"
    # a stream past the runaway ceiling kills the child instead of draining it forever
    real2 = serve.subprocess.Popen
    big = _FakeProc(out=b"z" * (serve.TOOL_CAP * 64 + 65536 * 2))
    serve.subprocess.Popen = lambda *a, **k: big
    try:
        serve._tool(["status.py"])
    finally:
        serve.subprocess.Popen = real2
    assert big.killed, "a runaway stream must kill the child, not drain it to EOF"


def test_pack_discovery_is_the_index_not_the_filesystem():
    """Git does not track directories: an untracked (or ignored) products/.../handoff directory
    used to read as a pack, appear on the board, and serve under the clean commit footer — an
    external review planted exactly that. Discovery now lists the INDEX, so a directory on disk
    that git does not hold founds nothing."""
    import tempfile as _tf
    planted = Path(serve.ROOT) / "products" / "oncology" / "zz_planted" / "202606" / "handoff"
    assert not planted.exists(), "leftover fixture from an earlier run — clean it first"
    planted.mkdir(parents=True)
    try:
        (planted / "DECISIONS.md").write_text("| ID |\n", encoding="utf-8")
        assert "products/oncology/zz_planted/202606" not in serve.packs(), \
            "an untracked directory founded a pack — discovery is reading the filesystem"
    finally:
        import shutil as _sh
        _sh.rmtree(planted.parent.parent, ignore_errors=True)
    # ...and the discovery still finds every real, tracked pack
    assert PACK in serve.packs()


def test_error_pages_carry_the_tools_message_but_no_checkout_root_path():
    real = serve._tool
    def failing(args):
        return subprocess.CompletedProcess(
            args, 1, stdout="",
            stderr=f'File "{serve.ROOT}/platform/tools/knowledge_graph.py", line 7: boom')
    serve._tool = failing
    try:
        status, body = serve.knowledge("anything")
    finally:
        serve._tool = real
    assert status == 500
    assert serve.ROOT.encode() not in body, "error pages must not disclose where the checkout lives"
    assert b"boom" in body and b"platform/tools/knowledge_graph.py" in body, \
        "the tool's own message survives the scrub"


def test_unknown_provenance_is_a_refusal_on_every_route():
    # a governance window must tie every page to a merged commit; 'unknown' stamped in a footer
    # reads as a working page — so unknown is a 503, not a footer value
    saved = serve.COMMIT, serve.VERSION
    try:
        serve.COMMIT, serve.VERSION = "unknown", "1.0.0"
        for status, body in (serve.index(), serve.page("flow", PACK), serve.questions(PACK),
                             serve.knowledge("fued"), serve.suggest()):
            assert status == 503
            assert b"cannot prove what is being served" in body
        serve.COMMIT, serve.VERSION = "abc1234", "unknown"    # either axis unknown refuses
        status, body = serve.index()
        assert status == 503 and b"cannot prove what is being served" in body
    finally:
        serve.COMMIT, serve.VERSION = saved


def test_an_edited_checkout_or_a_moved_head_is_a_refusal_on_every_route():
    """The footer stamps a COMMIT and the pages render from the FILES. An external review edited
    the checkout under the running app and every page kept serving under the clean footer —
    stored content the stamped commit never contained. Provenance is now verified PER REQUEST:
    a dirty tree refuses, and a HEAD that moved since startup refuses (the operator restarts to
    serve the new commit honestly)."""
    assert isinstance(_REAL_DIRTY(), list), "_dirty must always answer with a list of paths"
    serve._proven()                                     # pin the startup identity first
    saved_commit = serve.commit
    try:
        serve._dirty = lambda: [" M products/oncology/prostate/202606/handoff/DECISIONS.md"]
        for status, body in (serve.index(), serve.page("flow", PACK), serve.knowledge("fued")):
            assert status == 503, "an edited checkout kept serving under a clean footer"
            assert b"cannot prove what is being served" in body
        serve._dirty = lambda: []
        serve.commit = lambda: "f00dfeed"               # HEAD moved under the running app
        assert serve.COMMIT != "f00dfeed"
        status, body = serve.index()
        assert status == 503 and b"cannot prove what is being served" in body
    finally:
        serve._dirty, serve.commit = (lambda: []), saved_commit


def test_the_index_advertises_no_suggest_link_but_the_route_still_serves():
    _, body = serve.index()
    assert b"suggest" not in body.lower(), \
        "the front page must not advertise /suggest — its precision is indefensible there"
    status, body = serve.suggest()
    assert status == 200 and b"serving commit" in body, "the un-advertised route still serves"


def test_frame_is_minimal_but_accessible():
    b = serve._frame("a title", "<h1>x</h1>")
    assert b.startswith(b"<!doctype html><html lang='en'>"), "doctype and lang, for screen readers"
    assert b"name='viewport'" in b and b"width=device-width" in b, "usable on a phone"
    assert b"<main><h1>x</h1></main>" in b, "content wrapped so headings outline a document"
    assert b.rstrip().endswith(b"</html>")
    _, body = serve.index()
    assert b"<label for='q'>" in body and b"id='q'" in body, "the search input has a real label"


def test_a_repository_path_is_data_on_the_board_never_markup():
    """Pack paths reach the index from the filesystem, and an external review demonstrated stored
    markup injection through the one interpolation that trusted them. A pack directory named
    `<script>…` must render as its own strange name — escaped — never execute."""
    hostile = "products/oncology/<script>alert(1)</script>/202606"
    real = serve.packs
    serve.packs = lambda: [*real(), hostile]
    try:
        status, body = serve.index()
    finally:
        serve.packs = real
    assert status == 200
    assert b"<script>alert(1)</script>" not in body, "the pack path rendered as live markup"
    assert b"&lt;script&gt;" in body, "the hostile name must still be VISIBLE, escaped"


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
