"""The semantic view may present and ask; pooling is a human ruling or it is NOT ESTABLISHED.

Two implementations of one variable are not automatically one construct — EHR-documented
progression and claims-proxied progression share a name and not a meaning. The properties worth
pinning: an unruled pair always says do-not-pool as a QUESTION (never a verdict word), the
rulings file's refusal rules (a team is not a person, TBD is not a date, an invented word is
not a ruling, a proxy without its documented divergence is refused), and the real tree compiles
with the registry vendor as its one implementation.

Run: python3 tests/test_semantic_view.py (or pytest). Pure — no Spark.
"""
import json
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))
sys.path.insert(0, str(FRAMEWORK / "engine"))

import semantic_view as sv   # noqa: E402

PACK = str(FRAMEWORK.parent / "products" / "oncology" / "prostate" / "202606")


def test_a_ruling_is_a_named_persons_dated_act_in_a_closed_vocabulary():
    with tempfile.TemporaryDirectory() as tmp:
        p = Path(tmp) / "EQUIVALENCE_RULINGS.yaml"
        p.write_text(json.dumps({"rulings": [
            {"variable": "rwpfs", "source_a": "flatiron", "source_b": "optum_mc",
             "ruling": "accepted_proxy", "note": "claims progression lags EHR by one cycle",
             "decision_id": "EQ-1", "ruled_by": "T. Test", "ruling_date": "2026-08-19"},
            {"variable": "os", "source_a": "flatiron", "source_b": "optum_mc",
             "ruling": "same_construct", "decision_id": "EQ-2", "ruled_by": "RWP", "ruling_date": "2026-08-19"},
            {"variable": "os2", "source_a": "a", "source_b": "b",
             "ruling": "same_construct", "decision_id": "EQ-3", "ruled_by": "T. Test", "ruling_date": "TBD"},
            {"variable": "os3", "source_a": "a", "source_b": "b",
             "ruling": "probably_fine", "decision_id": "EQ-4", "ruled_by": "T. Test", "ruling_date": "2026-08-19"},
            {"variable": "os4", "source_a": "a", "source_b": "b",
             "ruling": "accepted_proxy", "decision_id": "EQ-5", "ruled_by": "T. Test", "ruling_date": "2026-08-19"},
            {"ruling": "same_construct"},
        ]}), encoding="utf-8")
        good, problems = sv.rulings(str(p))
        assert [r["variable"] for r in good] == ["rwpfs"], good
        assert len(problems) == 5, problems
        assert any("team" in pr for pr in problems), problems
        assert any("ruling_date" in pr for pr in problems), problems
        assert any("probably_fine" in pr for pr in problems), problems
        assert any("no note" in pr for pr in problems), problems
        assert any("unstated" in pr for pr in problems), problems


def test_an_unruled_pair_is_not_established_and_phrased_as_a_question():
    """Fail-closed, order-insensitive, and never a verdict: the default state carries a '?'
    question routing to RWP/RWB, and no verdict word appears anywhere in it."""
    p = sv.pooling("rwpfs", "optum_mc", "flatiron", ruled=[])
    assert p["state"] == "not_established"
    assert "?" in p["question"] and "Do not pool" in p["question"]
    assert not any(w in json.dumps(p) for w in ("approved", "verified", "passed"))
    ruled = [{"variable": "RWPFS", "source_a": "Flatiron", "source_b": "OPTUM_MC",
              "ruling": "not_comparable", "ruled_by": "T. Test", "ruling_date": "2026-08-19"}]
    q = sv.pooling("rwpfs", "optum_mc", "flatiron", ruled=ruled)
    assert q["state"] == "not_comparable", "case and order must not lose a recorded ruling"


def test_the_real_tree_compiles_one_implementation_and_no_verdicts():
    """Prostate's view: every contract record appears with a derivation line, the registry's
    vendor is the single implementation, the live rulings file has no problems, and with one
    dataset the equivalence axis is explicitly dormant — not silently passing."""
    v = sv.view(PACK)
    assert len(v["variables"]) > 100, "the contract's records fell out of the view"
    assert list(v["implementations"]) == ["flatiron"], v["implementations"]
    assert v["ruling_problems"] == [], v["ruling_problems"]
    assert v["open_equivalence_questions"] == 0
    assert all(r["derivation"] for r in v["variables"])
    text = sv.render(v)
    assert "one dataset today — the axis activates with the second" in text
    good, problems = sv.rulings()
    assert problems == [] and good == [], "the live rulings file must start empty and clean"


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
