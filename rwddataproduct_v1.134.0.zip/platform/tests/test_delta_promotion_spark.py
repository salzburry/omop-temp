"""THE PROMOTION SQL, EXECUTED. Against real Delta tables, on a real Spark session.

    python3 tests/test_delta_promotion_spark.py      # skips cleanly without pyspark + delta-spark

WHY THIS FILE EXISTS. Everything else about Gate 6's physical half is pure Python: `release.py` emits
strings and compares dicts, and 758 offline tests agree with it. Three defects survived all of them,
and every one was invisible for the same reason — nothing executed the SQL:

  * the probe wrapped `DESCRIBE HISTORY` and `DESCRIBE DETAIL` in a `SELECT` subquery. They are
    COMMANDS, not relations. The whole check would have raised on first contact with a cluster.
  * the existence check compared bare table names against fully qualified ones, so it would have
    reported every staged table missing and refused every candidate.
  * `DESCRIBE DETAIL`'s column names — `id`, `location`, `format`, `numFiles`, `sizeInBytes` — were
    read from documentation, and a reader that names the wrong column returns None for every field.

A string-comparison test cannot see any of those. This runs the statements.

WHAT IT PROVES AND WHAT IT DOES NOT. It proves the SQL parses, the columns exist, `VERSION AS OF`
resolves, and every refusal fires on real state. It runs on OPEN-SOURCE Delta with a local
Hive-style catalog — so it does NOT prove Unity Catalog behaviour, three-level namespaces,
permissions, or anything about a Databricks cluster. That gap is real and stated in
products/OPERATIONS.md; what closes here is the part that was never executed at all.

SKIPS ARE ANNOUNCED, NOT SILENT. `platform/tests/test_stages_spark.py` spent months looking green
while running nothing, and the lesson is written into its docstring. This prints what it skipped and
why, and the CI job that owns it asserts both imports before running it.
"""
import os
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))
sys.path.insert(0, str(FRAMEWORK / "tools"))   # console, for the entry point's encoding

from engine import release as rel                                             # noqa: E402

try:
    from pyspark.sql import SparkSession
    import delta                                                              # noqa: F401
    HAVE = True
except Exception:                          # pyspark or delta-spark missing -> announce and skip
    SparkSession, HAVE = None, False

# The Delta package the session pulls. Pinned rather than floated: Delta is compiled against a
# specific Spark Catalyst API and a mismatch fails with `NoSuchMethodError` from inside a write —
# which reads as a broken test rather than a version pair nobody chose. Spark 4.0 <-> Delta 4.0.
DELTA_PACKAGE = "io.delta:delta-spark_2.13:4.0.0"

FINAL = "promo.ads"          # a synthetic two-level name: this exercises the SQL, not a product
BUILD = "b0001"
REFRESH = "2026q1"


def _session(warehouse):
    os.environ.setdefault("SPARK_LOCAL_IP", "127.0.0.1")
    s = (SparkSession.builder.appName("delta-promotion")
         .master("local[2]")
         .config("spark.jars.packages", DELTA_PACKAGE)
         .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
         .config("spark.sql.catalog.spark_catalog",
                 "org.apache.spark.sql.delta.catalog.DeltaCatalog")
         .config("spark.sql.warehouse.dir", warehouse)
         .config("spark.ui.enabled", "false")
         # The console progress bar redraws with carriage returns, so it OVERWRITES the
         # scenario lines below in any captured log — seven "ok" lines arrive as two.
         # A CI log nobody can read is how a suite's coverage becomes a matter of trust.
         .config("spark.ui.showConsoleProgress", "false")
         .getOrCreate())
    s.sparkContext.setLogLevel("ERROR")
    return s


def _probe(spark, tables):
    """The runner's probe, assembled here from the SAME engine statements the runner uses.

    Deliberately NOT a copy of `run_rwdp._probe_candidate_tables`: that function is unimportable
    (the notebook needs `dbutils`), and re-implementing its LOOP while calling the same three engine
    functions is the closest a test can get without pretending. What is under test is the SQL and the
    predicates, and both come from `release.py`.
    """
    rows = []
    for t in tables:
        hist_sql, detail_sql = rel.candidate_probe_statements(t)
        hist = spark.sql(hist_sql).collect()[0].asDict()
        detail = spark.sql(detail_sql).collect()[0].asDict()
        n = spark.sql(rel.count_at_version_sql(t, hist["version"])).collect()[0]["row_count"]
        rows.append(rel.candidate_row(t, hist, detail, n))
    return rel.candidate_identity(rows)


def _stage(spark, name, n, mode="overwrite"):
    spark.range(n).toDF("id").write.format("delta").mode(mode).saveAsTable(name)


def _translate(err):
    """A mismatched Spark/Delta pair, said in words. Returns None when that is not what happened.

    Delta is compiled against a specific Spark Catalyst API and the wrong combination raises
    `NoSuchMethodError` naming a Scala signature — from the FIRST statement, which is a
    `CREATE DATABASE`, so it reads as this suite being broken rather than as a version pair nobody
    chose. That is the failure mode this repository keeps having to fix in its own tools, and it is
    worth translating in the one place a stranger meets Spark.

    TRANSLATED, NEVER SWALLOWED. A mismatch is a defect in whoever pinned the pair; a suite that went
    quiet on it would let CI report success having executed no SQL, which is the entire reason this
    file exists.
    """
    text = f"{err}"
    if "NoSuchMethodError" not in text and "NoClassDefFound" not in text:
        return None
    import pyspark
    return RuntimeError(
        f"Spark and Delta are an incompatible pair: pyspark {pyspark.__version__} with "
        f"{DELTA_PACKAGE}. Delta is compiled against one Catalyst API, and this is what a mismatch "
        f"looks like from the inside — a Scala signature and nothing about versions. Pin them "
        f"together; the CI job installs pyspark==4.0.1 with delta-spark==4.0.0.\n  {text[:200]}")


def _views(spark, final, tfl_ids):
    """{public view: the versioned table it serves}. The runner's observer, through the same parse.

    Reads `View Text` from `DESCRIBE EXTENDED` and hands it to `release.view_target`, which owns the
    parse because `release.view_swap_sql` writes the statement being read back.
    """
    out = {}
    for pub in [final] + [rel.public_tfl(final, t) for t in (tfl_ids or [])]:
        text = None
        if spark.catalog.tableExists(pub):
            text = next((r["data_type"] for r in spark.sql(f"DESCRIBE EXTENDED {pub}").collect()
                         if (r["col_name"] or "").strip() == "View Text"), None)
        out[pub] = text
    return rel.observed_release(out)


def _existing(spark, pairs):
    """The runner's existence check: each EXACT identifier, BOTH sides of every pair.

    Only the staging side, and the "already promoted" refusal has nothing to fire on — which is what
    the runner did, and what running this against real Delta found on its first pass.
    """
    return {t for pair in pairs for t in pair if spark.catalog.tableExists(t)}


def run(spark):
    stg_ads = rel.staging_ads(FINAL, BUILD)
    stg_tfl = rel.staging_tfl(FINAL, BUILD, "t1")
    pairs = rel.promotion_pairs(FINAL, REFRESH, BUILD, ["t1"])
    checks = 0

    # ---------------------------------------------------------------------------------------------
    # 1. THE PROBE RETURNS WHAT THE ENGINE CLAIMS IT RETURNS.
    # ---------------------------------------------------------------------------------------------
    _stage(spark, stg_ads, 40)
    _stage(spark, stg_tfl, 4)
    approved = _probe(spark, [stg_ads, stg_tfl])
    for t, want in ((stg_ads, 40), (stg_tfl, 4)):
        got = approved[t]
        assert got["delta_version"] == 0, f"{t}: version {got['delta_version']}"
        assert got["row_count"] == want, f"{t}: {got['row_count']} rows, wanted {want}"
        # THE FIELDS THAT WERE READ FROM DOCUMENTATION. A reader naming the wrong column returns
        # None for every one of them and every comparison downstream becomes vacuously equal.
        assert got["table_id"], f"{t}: DESCRIBE DETAIL returned no id — the column name is wrong"
        assert got["location"] and got["table_format"] == "delta", got
        assert got["num_files"] and got["size_bytes"], got
    checks += 1
    print(f"ok  the probe reads Delta's id, version, count, format, files and size")

    # ---------------------------------------------------------------------------------------------
    # 2. AN UNTOUCHED CANDIDATE PROMOTES, and the pinned read publishes the approved rows.
    # ---------------------------------------------------------------------------------------------
    observed = _probe(spark, [stg_ads, stg_tfl])
    why = rel.promotion_blockers(FINAL, REFRESH, BUILD, ["t1"], _existing(spark, pairs),
                                 approved, observed)
    assert why == [], f"an untouched candidate was refused: {why}"
    for step, target, _src, sql in rel.promotion_plan(FINAL, REFRESH, BUILD, ["t1"], approved):
        spark.sql(sql)
    assert spark.table(rel.versioned_ads(FINAL, REFRESH, BUILD)).count() == 40
    assert spark.table(FINAL).count() == 40, "the public view does not serve the release"
    checks += 1
    print("ok  an untouched candidate materialises pinned and the public views swap")

    # ---------------------------------------------------------------------------------------------
    # 3. ALREADY PROMOTED. The versioned table is immutable and a view may already serve it.
    # ---------------------------------------------------------------------------------------------
    again = rel.promotion_blockers(FINAL, REFRESH, BUILD, ["t1"], _existing(spark, pairs),
                                   approved, observed)
    assert any("already promoted" in w for w in again), again
    checks += 1
    print("ok  a second promotion of the same build is refused")

    # ---------------------------------------------------------------------------------------------
    # 4. SOMEBODY WROTE TO THE APPROVED CANDIDATE — the forced partial failure.
    #
    # And then the part only a real Delta run can show: had the refusal been bypassed, the PINNED
    # read still publishes the approved rows. That is the TOCTOU guarantee, and until now it was an
    # argument about a string.
    # ---------------------------------------------------------------------------------------------
    b2 = "b0002"
    stg2 = rel.staging_ads(FINAL, b2)
    pairs2 = rel.promotion_pairs(FINAL, REFRESH, b2, [])
    _stage(spark, stg2, 40)
    approved2 = _probe(spark, [stg2])
    _stage(spark, stg2, 99)                                   # the write nobody approved
    observed2 = _probe(spark, [stg2])
    moved = rel.promotion_blockers(FINAL, REFRESH, b2, [], _existing(spark, pairs2),
                                   approved2, observed2)
    assert any("delta_version" in w and "anybody signed" in w for w in moved), moved
    assert observed2[stg2]["row_count"] == 99 and approved2[stg2]["row_count"] == 40

    pinned = rel.materialise_sql("promo.pinned_proof", stg2, approved2[stg2]["delta_version"])
    spark.sql(pinned)
    assert spark.table("promo.pinned_proof").count() == 40, \
        ("VERSION AS OF published the CURRENT staging rows, not the approved ones — the pin does "
         "not hold and every promotion is exposed to a write between the check and the statement")
    checks += 1
    print("ok  a write after approval is refused, and the pinned read still yields 40 not 99")

    # ---------------------------------------------------------------------------------------------
    # 5. DROP AND RECREATE. Same version, same row count, different table — the case a version
    #    alone cannot see, and the reason `table_id` is compared.
    # ---------------------------------------------------------------------------------------------
    b3 = "b0003"
    stg3 = rel.staging_ads(FINAL, b3)
    _stage(spark, stg3, 7)
    approved3 = _probe(spark, [stg3])
    spark.sql(f"DROP TABLE {stg3}")
    _stage(spark, stg3, 7)                                    # same rows, fresh transaction log
    observed3 = _probe(spark, [stg3])
    assert observed3[stg3]["delta_version"] == approved3[stg3]["delta_version"], \
        "the recreate did not reproduce the version — this scenario proves nothing"
    assert observed3[stg3]["row_count"] == approved3[stg3]["row_count"]
    assert observed3[stg3]["table_id"] != approved3[stg3]["table_id"], \
        "Delta reused the table id across a drop+recreate — the identity field is not doing its job"
    recreated = rel.promotion_blockers(FINAL, REFRESH, b3, [],
                                       _existing(spark, rel.promotion_pairs(FINAL, REFRESH, b3, [])),
                                       approved3, observed3)
    assert any("table_id" in w for w in recreated), recreated
    checks += 1
    print("ok  a drop+recreate at the same version and row count is refused on table_id")

    # ---------------------------------------------------------------------------------------------
    # 6. A PARTIAL IDENTITY. The candidate was signed over the ADS and this promotion publishes a
    #    TFL too — the seam that published unmeasured bytes under a valid signature.
    # ---------------------------------------------------------------------------------------------
    b4 = "b0004"
    stg4_ads, stg4_tfl = rel.staging_ads(FINAL, b4), rel.staging_tfl(FINAL, b4, "t1")
    _stage(spark, stg4_ads, 12)
    _stage(spark, stg4_tfl, 3)
    half = _probe(spark, [stg4_ads])                          # the TFL never measured
    pairs4 = rel.promotion_pairs(FINAL, REFRESH, b4, ["t1"])
    partial = rel.promotion_blockers(FINAL, REFRESH, b4, ["t1"], _existing(spark, pairs4),
                                     half, _probe(spark, [stg4_ads, stg4_tfl]))
    assert any(stg4_tfl in w and "records no identity" in w for w in partial), partial
    checks += 1
    print("ok  a candidate signed over part of its tables is refused")

    # ---------------------------------------------------------------------------------------------
    # 7. THE ROW-COUNT VERIFICATION THE RUNNER DOES AFTER MATERIALISING, before any view swaps.
    # ---------------------------------------------------------------------------------------------
    b5 = "b0005"
    stg5 = rel.staging_ads(FINAL, b5)
    _stage(spark, stg5, 21)
    approved5 = _probe(spark, [stg5])
    ver5 = rel.versioned_ads(FINAL, REFRESH, b5)
    spark.sql(rel.materialise_sql(ver5, stg5, approved5[stg5]["delta_version"]))
    assert spark.table(ver5).count() == approved5[stg5]["row_count"] == 21
    checks += 1
    print("ok  the materialised table carries the approved row count")

    # ---------------------------------------------------------------------------------------------
    # 8. A PROMOTION INTERRUPTED MID-FLIGHT, RESUMED — the state machine, against real tables.
    #
    # Crash after the TFL versioned table is made and before the ADS. Offline this is a set
    # comparison; here the table genuinely exists, `CREATE TABLE ... AS SELECT` genuinely refuses to
    # remake it, and the resume genuinely has to skip it and finish. That last part is the whole
    # claim: before the journal, a retry was refused for having got half way.
    # ---------------------------------------------------------------------------------------------
    b6 = "b0006"
    s6_ads, s6_tfl = rel.staging_ads(FINAL, b6), rel.staging_tfl(FINAL, b6, "t1")
    v6_ads, v6_tfl = rel.versioned_ads(FINAL, REFRESH, b6), rel.versioned_tfl(FINAL, REFRESH, b6, "t1")
    pairs6 = rel.promotion_pairs(FINAL, REFRESH, b6, ["t1"])
    _stage(spark, s6_ads, 31)
    _stage(spark, s6_tfl, 5)
    approved6 = _probe(spark, [s6_ads, s6_tfl])
    journal = rel.promotion_intent(FINAL, REFRESH, b6, ["t1"],
                                   candidate_sha256="sha-of-the-candidate",
                                   approved_identity=approved6)

    # The crash: run the FIRST materialise only, then stop.
    first = rel.promotion_plan(FINAL, REFRESH, b6, ["t1"], approved6)[0]
    assert first[1] == v6_tfl, f"the plan's first materialise moved: {first[1]}"
    spark.sql(first[3])
    assert spark.catalog.tableExists(v6_tfl) and not spark.catalog.tableExists(v6_ads)

    # Without the journal, the retry is refused — the state this replaces.
    blind = rel.promotion_blockers(FINAL, REFRESH, b6, ["t1"], _existing(spark, pairs6),
                                   approved6, _probe(spark, [s6_ads, s6_tfl]))
    assert any("already promoted" in w for w in blind), blind

    # With it, the made table is recognised as this promotion's own completed work and skipped.
    # THE OUTPUT'S OWN IDENTITY rides the journal: count plus a mutable property was refutable by
    # a same-count impostor, so materialisation records what it made and the resume re-probes it —
    # here against real Delta, real `dtypes`, and a real DESCRIBE DETAIL row.
    journal["outputs"] = {v6_tfl: rel.output_identity_row(_probe(spark, [v6_tfl])[v6_tfl],
                                                          spark.table(v6_tfl).dtypes)}
    counts = {v: spark.table(v).count()
              for v, _s in pairs6 if spark.catalog.tableExists(v)}
    obs6 = {v6_tfl: rel.output_identity_row(_probe(spark, [v6_tfl])[v6_tfl],
                                            spark.table(v6_tfl).dtypes)}
    resuming, partial = rel.reconcile(journal, _existing(spark, pairs6), counts,
                                      observed_outputs=obs6)
    assert resuming == [v6_tfl] and partial == [], (resuming, partial)
    # ...and a same-count table wearing a different Delta identity is NOT a completed step.
    gone, why6 = rel.reconcile(journal, _existing(spark, pairs6), counts,
                               observed_outputs={v6_tfl: dict(obs6[v6_tfl],
                                                              table_id="impostor")})
    assert gone == [] and any("not the table this promotion made" in w for w in why6), (gone, why6)
    assert rel.promotion_blockers(FINAL, REFRESH, b6, ["t1"], _existing(spark, pairs6),
                                  approved6, _probe(spark, [s6_ads, s6_tfl]), resuming) == []
    for _step, _target, _src, sql in rel.promotion_plan(FINAL, REFRESH, b6, ["t1"],
                                                        approved6, resuming):
        spark.sql(sql)
    assert spark.table(v6_ads).count() == 31 and spark.table(v6_tfl).count() == 5
    assert spark.table(FINAL).count() == 31, "the resumed promotion did not reach the public view"
    checks += 1
    print("ok  a promotion interrupted after one table resumes and completes")

    # ---------------------------------------------------------------------------------------------
    # 9. A PARTIAL WRITE OF OUR OWN, on a real table. The journal says this target is ours; the rows
    #    say it is not what was approved. Refused, with advice that depends on whether a view points
    #    at it — which is the operator-facing half of what the journal buys.
    # ---------------------------------------------------------------------------------------------
    b7 = "b0007"
    s7 = rel.staging_ads(FINAL, b7)
    v7 = rel.versioned_ads(FINAL, REFRESH, b7)
    _stage(spark, s7, 15)
    approved7 = _probe(spark, [s7])
    j7 = rel.promotion_intent(FINAL, REFRESH, b7, [], candidate_sha256="x",
                              approved_identity=approved7)
    spark.range(9).toDF("id").write.format("delta").saveAsTable(v7)     # the truncated write
    _done, why7 = rel.reconcile(j7, _existing(spark, rel.promotion_pairs(FINAL, REFRESH, b7, [])),
                                {v7: spark.table(v7).count()})
    assert why7 and "9 row(s)" in why7[0] and "recorded 15" in why7[0], why7
    assert "safe to drop" in why7[0], "no view points at it yet and the advice does not say so"
    checks += 1
    print("ok  a partial write from an interrupted attempt is refused, with state-aware advice")

    # ---------------------------------------------------------------------------------------------
    # 10. THE LOCK IS A REAL MUTEX. `CREATE TABLE` on a name that exists is refused BY THE METASTORE.
    #     That is the whole basis of serialising promotions per product, and it was an assumption
    #     until this ran: a catalog that answered `CREATE OR REPLACE` semantics would hand the lock
    #     to whoever asked last and the refusal below would never fire.
    # ---------------------------------------------------------------------------------------------
    lock = rel.promotion_lock(FINAL)
    spark.sql(f"DROP TABLE IF EXISTS {lock}")
    spark.sql(rel.acquire_lock_sql(FINAL, "b0008", "first-runner", "2026-08-06T12:00:00Z",
                                   attempt_id="attempt-8"))
    try:
        spark.sql(rel.acquire_lock_sql(FINAL, "b0009", "second-runner", "2026-08-06T12:00:01Z",
                                       attempt_id="attempt-9"))
        raise AssertionError(
            "a second promotion took the lock while the first held it — the metastore did not "
            "refuse the CREATE, so nothing serialises two promotions of one product")
    except Exception as err:
        if isinstance(err, AssertionError):
            raise
        assert "ALREADY_EXISTS" in f"{err}" or "already exists" in f"{err}".lower(), err
    holder = spark.table(lock).collect()[0].asDict()
    assert holder["build_id"] == "b0008" and holder["actor"] == "first-runner", holder
    assert holder["attempt_id"] == "attempt-8", holder
    assert rel.lock_blockers(holder, "b0009"), "a foreign lock was not reported"
    # SAME BUILD IS NOT THE SAME ATTEMPT. This invocation re-checks its own lock and passes; a
    # concurrent duplicate wearing the same build id blocks until an operator NAMES the held
    # attempt — inspection as an argument, never inferred from a build id.
    assert rel.lock_blockers(holder, "b0008", attempt_id="attempt-8") == [], \
        "an invocation could not re-check its own lock"
    dup = rel.lock_blockers(holder, "b0008", attempt_id="attempt-9")
    assert dup and "resume_promotion=attempt-8" in dup[0], dup
    assert rel.lock_blockers(holder, "b0008", attempt_id="attempt-9",
                             resume_attempt="attempt-8") == [], \
        "the explicit, inspected takeover was refused"
    spark.sql(rel.release_lock_sql(FINAL))
    assert not spark.catalog.tableExists(lock)
    checks += 1
    print("ok  the promotion lock is a real mutex; a duplicate attempt of one build is blocked")

    # ---------------------------------------------------------------------------------------------
    # 11. A LATE PROMOTION CANNOT MOVE THE PUBLIC VIEWS BACKWARDS. Scenario 2 left `FINAL` serving
    #     build b0001; scenario 8 moved it to b0006. A candidate approved against b0001 arriving now
    #     would take consumers back to older data with every other check passing.
    # ---------------------------------------------------------------------------------------------
    live = _views(spark, FINAL, ["t1"])
    assert live[FINAL] == rel.versioned_ads(FINAL, REFRESH, "b0006"), \
        f"the fixture's public view is not where scenario 8 left it: {live}"
    stale = {FINAL: rel.versioned_ads(FINAL, REFRESH, BUILD),
             rel.public_tfl(FINAL, "t1"): live[rel.public_tfl(FINAL, "t1")]}
    moved = rel.supersedes_blockers(stale, live)
    assert moved and "BACKWARDS" in moved[0], moved
    assert rel.supersedes_blockers(live, live) == [], \
        "a candidate approved against the CURRENT release was refused"
    checks += 1
    print("ok  a candidate approved against an older release is refused, read from live views")

    # ---------------------------------------------------------------------------------------------
    # 12. THE RELEASE POINTER IS ONE TRANSACTION. This is the claim the whole pointer rests on, and
    #     it is not assertable offline: a string test can show one statement, not that the statement
    #     is one commit.
    #
    #     DELTA'S OWN HISTORY IS THE PROOF. Publish two releases through the pointer, then read every
    #     version of it. If a write were not atomic there would be a version holding a partial set —
    #     the new ADS beside the old TFLs, or no row at all. Every version holds ONE complete
    #     release, so no reader can ever have seen a mixture.
    # ---------------------------------------------------------------------------------------------
    import json
    ptr = rel.release_pointer_table(FINAL)
    spark.sql(f"DROP TABLE IF EXISTS {ptr}")
    spark.sql(rel.pointer_create_sql(FINAL))
    # THE SHAPE, VERIFIED THE WAY THE RUNNER VERIFIES IT: `IF NOT EXISTS` keeps an existing table
    # of any schema, and the publishing INSERT is positional — the preflight refuses a pointer
    # whose columns are not exactly this module's (names AND types), while a refusal is still free.
    assert rel.pointer_schema_errors(spark.table(ptr).dtypes) == []
    assert rel.pointer_schema_errors([("ads", "string"), ("tfls", "string")]), \
        "a hand-made pointer of another shape was accepted"
    assert rel.pointer_schema_errors([(n, "int" if n == "build_id" else t)
                                      for n, t in spark.table(ptr).dtypes]), \
        "right names over a wrong TYPE was accepted — it fails inside the publishing write"
    # THE WRITE-AUTHORITY PREFLIGHT, on real Delta: authorised like any write, and it must leave
    # the pointer exactly as it found it — the whole point is a refusal that costs nothing.
    spark.sql(rel.pointer_preflight_sql(FINAL))
    assert spark.table(ptr).count() == 0, "the preflight DELETE changed the pointer"
    for build in ("b0001", "b0006"):
        spark.sql(rel.pointer_write_sql(FINAL, REFRESH, build, ["t1"],
                                        spec_version="202606", published_at=f"at-{build}"))

    live = [r.asDict() for r in spark.table(ptr).collect()]
    assert rel.pointer_blockers(live, FINAL, REFRESH, "b0006", ["t1"]) == [], live
    assert json.loads(live[0]["tfls"]) == {"t1": rel.versioned_tfl(FINAL, REFRESH, "b0006", "t1")}

    history = [r.asDict() for r in spark.sql(f"DESCRIBE HISTORY {ptr}").collect()]
    writes = sorted(h["version"] for h in history if str(h["operation"]).upper() != "CREATE TABLE")
    assert len(writes) == 2, f"two releases produced {len(writes)} commit(s): {history}"
    for v, build in zip(writes, ("b0001", "b0006")):
        at = [r.asDict() for r in spark.sql(f"SELECT * FROM {ptr} VERSION AS OF {v}").collect()]
        assert len(at) == 1, f"version {v} of the pointer holds {len(at)} row(s) — a reader at that " \
                             f"instant would get no answer or an ambiguous one"
        # EVERY VERSION IS A WHOLE RELEASE. The ADS and the TFL move together or not at all, which is
        # exactly what the view swaps cannot promise.
        assert at[0]["ads"] == rel.versioned_ads(FINAL, REFRESH, build), (v, at)
        assert json.loads(at[0]["tfls"]) == {"t1": rel.versioned_tfl(FINAL, REFRESH, build, "t1")}, \
            f"version {v} pairs {build}'s ADS with another build's TFLs — the write was not atomic"
    checks += 1
    print("ok  every version of the release pointer holds one COMPLETE release set")

    # ---------------------------------------------------------------------------------------------
    # 13. AND IT IS REACHABLE THE WAY A CONSUMER IS TOLD TO REACH IT. `pointer_read_sql` is the
    #     statement the documentation gives; running it is what stops the docs drifting from the SQL.
    # ---------------------------------------------------------------------------------------------
    consumed = spark.sql(rel.pointer_read_sql(FINAL)).collect()[0].asDict()
    assert consumed["build_id"] == "b0006" and consumed["published_at"] == "at-b0006", consumed
    assert spark.table(consumed["ads"]).count() == 31, "the pointer names an ADS a consumer cannot read"
    for _tid, tbl in json.loads(consumed["tfls"]).items():
        assert spark.catalog.tableExists(tbl), f"the pointer names a TFL that does not exist: {tbl}"
    checks += 1
    print("ok  a consumer resolves the whole set through the pointer and every table it names exists")

    # ---------------------------------------------------------------------------------------------
    # 14. INPUT LINEAGE PINS THE BYTES A BUILD READ — a later write moves the table, and
    #     `VERSION AS OF` on the recorded version still returns exactly what was read.
    # ---------------------------------------------------------------------------------------------
    src = "promo.lineage_input"
    spark.sql(f"DROP TABLE IF EXISTS {src}")
    _stage(spark, src, 7)
    h_sql, d_sql = rel.candidate_probe_statements(src)
    pinned = rel.input_lineage_row(src, spark.sql(h_sql).collect()[0].asDict(),
                                   spark.sql(d_sql).collect()[0].asDict())
    assert pinned["table_id"] and pinned["delta_version"] == 0 and pinned["last_commit_at"], pinned
    assert pinned["table_format"] == "delta", pinned
    spark.sql(f"INSERT INTO {src} VALUES (999)")
    now_n = spark.table(src).count()
    then_n = spark.sql(
        f"SELECT count(*) AS n FROM {src} VERSION AS OF {pinned['delta_version']}").collect()[0]["n"]
    assert now_n == 8 and then_n == 7, (now_n, then_n)
    # ...and the id survives the write (a write is not a recreate), which is what makes the pair
    # (table_id, delta_version) a durable name for the bytes rather than a lucky counter.
    re_probe = rel.input_lineage_row(src, spark.sql(h_sql).collect()[0].asDict(),
                                     spark.sql(d_sql).collect()[0].asDict())
    assert re_probe["table_id"] == pinned["table_id"] and re_probe["delta_version"] == 1, re_probe
    checks += 1
    print("ok  input lineage re-reads the exact bytes a build read, after the table moved on")

    # ---------------------------------------------------------------------------------------------
    # 15. THE REPLAY. Publish A, publish B, rerun A — and prove B remains untouched. The fixture IS
    #     that history: scenario 2 published b0001, scenario 8 published b0006, and the pointer
    #     (scenario 12) names b0006. A rerun of b0001 arrives holding a `receipted` journal; the old
    #     resume path classified it resumable, skipped the supersedes comparison (past
    #     `views_switched` it would refuse its own work), re-emitted every swap and rewrote the
    #     pointer — consumers rolled BACKWARDS onto A with every check passing.
    # ---------------------------------------------------------------------------------------------
    journal_a = rel.promotion_intent(FINAL, REFRESH, BUILD, ["t1"],
                                     candidate_sha256="sha-of-a", attempt_id="a-attempt")
    for state in rel.PROMOTION_STATES[1:]:
        journal_a = rel.advance(journal_a, state)
    # first gate: receipted is TERMINAL — the runner's only legal response is verify-the-receipt
    # and exit `already_promoted`, never SQL.
    terminal = rel.journal_blockers(journal_a, BUILD, "sha-of-a")
    assert terminal and any("TERMINAL" in w for w in terminal), terminal
    # second gate: even a NON-terminal stall of A (crashed at views_switched, journal never
    # reached receipted) is refused, because the pointer — the commit anchor — names B now.
    stalled_a = dict(journal_a, state="views_switched")
    ptr_rows = [r.asDict() for r in spark.table(rel.release_pointer_table(FINAL)).collect()]
    back = rel.rollback_blockers(stalled_a, ptr_rows)
    assert back and "BACKWARDS" in back[0] and "b0006" in back[0], back
    # ...while b0006's own recovery is untouched by the guard, and B remains live throughout:
    assert rel.rollback_blockers(dict(stalled_a, build_id="b0006"), ptr_rows) == []
    assert _views(spark, FINAL, ["t1"])[FINAL] == rel.versioned_ads(FINAL, REFRESH, "b0006")
    assert spark.sql(rel.pointer_read_sql(FINAL)).collect()[0]["build_id"] == "b0006", \
        "the rerun of A moved the pointer — B did not remain untouched"
    checks += 1
    print("ok  a rerun of a published promotion is refused twice over, and the newer release holds")

    # ---------------------------------------------------------------------------------------------
    # 16. THE TAKEOVER IS A COMPARE-AND-SET, and one token admits ONE winner. Naming a dead attempt
    #     in `resume_promotion` used to be the whole takeover while the lock row kept the dead
    #     attempt's id — so every presenter of the token passed, concurrently. The takeover is now a
    #     Delta UPDATE whose predicate is (build AND old attempt): takeovers serialize on the Delta
    #     commit, the loser matches ZERO rows, and the runner's read-back refuses a row that does
    #     not wear ITS attempt id.
    # ---------------------------------------------------------------------------------------------
    lock = rel.promotion_lock(FINAL)
    spark.sql(f"DROP TABLE IF EXISTS {lock}")
    spark.sql(rel.acquire_lock_sql(FINAL, "b0010", "crashed-runner", "2026-08-13T09:00:00Z",
                                   attempt_id="attempt-dead"))
    for contender in ("attempt-n1", "attempt-n2"):
        # both presenters were authorised the same way the runner authorises them
        held = spark.table(lock).collect()[0].asDict()
        assert rel.lock_blockers(held, "b0010", attempt_id=contender,
                                 resume_attempt="attempt-dead") == [] or contender == "attempt-n2"
        spark.sql(rel.takeover_lock_sql(FINAL, "b0010", "attempt-dead", contender,
                                        contender, "2026-08-13T09:01:00Z"))
        rows = [r.asDict() for r in spark.table(lock).collect()]
        assert rel.lock_row_errors(rows) == [], rows
        if contender == "attempt-n1":
            assert rows[0]["attempt_id"] == "attempt-n1", \
                f"the first takeover did not install its attempt: {rows[0]}"
        else:
            # the second UPDATE matched zero rows — the token was consumed by the first commit —
            # and this is exactly the read-back on which the runner refuses ("the takeover LOST")
            assert rows[0]["attempt_id"] == "attempt-n1", \
                f"one resume token admitted two takeovers: {rows[0]}"
    # and a lock table someone emptied by hand is MALFORMED, never free — on real Delta, not a dict
    spark.sql(f"DELETE FROM {lock}")
    hollow = rel.lock_row_errors([r.asDict() for r in spark.table(lock).collect()])
    assert hollow and "NO row" in hollow[0], hollow
    spark.sql(rel.release_lock_sql(FINAL))
    checks += 1
    print("ok  one resume token admits exactly one takeover, and an emptied lock is refused")

    assert checks == 16, f"only {checks} scenario(s) ran — this suite proved less than it claims"
    return checks


def test_the_promotion_sql_runs_against_real_delta():
    if not HAVE:
        print("SKIP — pyspark and/or delta-spark are not installed. The promotion SQL is NOT "
              "verified by this run; see the `spark` CI job, which refuses to proceed without them.")
        return
    with tempfile.TemporaryDirectory() as warehouse:
        spark = _session(os.path.join(warehouse, "wh"))
        try:
            spark.sql("CREATE DATABASE IF NOT EXISTS promo")
            n = run(spark)
            print(f"\n{n} promotion scenario(s) executed against real Delta tables")
        except Exception as err:
            raise (_translate(err) or err) from err
        finally:
            spark.stop()


if __name__ == "__main__":
    from console import use_utf8   # noqa: E402
    use_utf8()
    test_the_promotion_sql_runs_against_real_delta()
    print("OK")
