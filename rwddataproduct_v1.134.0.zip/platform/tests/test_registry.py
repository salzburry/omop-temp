"""Registry-driven checks. Every ACTIVE tumor in registry.yaml must have a config that lints clean.

This grows automatically: adding a tumor to the registry + a valid config pack is covered here
with no test change. Pure Python (no Spark). Run: python3 test_registry.py (or pytest).
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent      # _framework/ (the shared engine lives here)
sys.path.insert(0, str(FRAMEWORK))
PRODUCTS = FRAMEWORK.parent / "products"                              # products/

from engine.config import load_yaml, load_config        # noqa: E402
from engine.config import product_config, product_dir  # noqa: E402
from engine import validate                              # noqa: E402

REGISTRY = PRODUCTS / "registry.yaml"
VALID_STATUS = {"active", "scaffold", "planned"}


def _tumors():
    return load_yaml(REGISTRY)["tumors"]


def test_registry_well_formed():
    slugs = set()
    for t in _tumors():
        for k in ("code", "name", "slug", "status", "vendor", "tumor_class"):
            assert k in t, f"registry entry missing '{k}': {t}"
        assert t["status"] in VALID_STATUS, f"bad status {t['status']!r} in {t}"
        assert t["vendor"] in {"flatiron", "cota"}, f"bad vendor in {t}"
        assert t["tumor_class"] in {"solid", "heme"}, f"bad tumor_class in {t}"
        assert t["slug"] not in slugs, f"duplicate slug: {t['slug']}"
        slugs.add(t["slug"])


def test_cota_tumors_are_heme():
    # COTA is the heme vendor (DLBCL/CLL/MDS); Flatiron is solid. Catch a mis-tagged entry.
    for t in _tumors():
        if t["vendor"] == "cota":
            assert t["tumor_class"] == "heme", f"COTA tumor not heme: {t}"


def test_active_tumors_have_a_config():
    for t in _tumors():
        if t["status"] != "active":
            continue
        cfg_path = product_config(PRODUCTS, t["slug"])
        assert cfg_path.exists(), f"active tumor '{t['code']}' has no config at {cfg_path}"


def test_tumors_with_config_lint_clean():
    # Any tumor that has a config pack (active OR scaffold) must lint clean — so scaffolds in
    # progress (OC, EC, …) are validated too, not just production tumors.
    checked = 0
    for t in _tumors():
        if "current_spec_version" not in t:        # planned tumors have no config pack yet
            continue
        cfg_path = product_config(PRODUCTS, t["slug"])
        if not cfg_path.exists():
            continue
        probs = validate.problems(load_config(cfg_path), strict=False)
        assert probs == [], f"{t['code']} config problems: {probs}"
        checked += 1
    assert checked >= 1, "no tumor configs found to validate"


def test_registry_status_matches_config_status():
    # registry.yaml is the authority for product status; each tumor's config must MIRROR it, so a
    # reader/automation never sees "registry active, config scaffold" (or vice versa).
    for t in _tumors():
        if "current_spec_version" not in t:        # planned tumors have no config pack yet
            continue
        cfg_path = product_config(PRODUCTS, t["slug"])
        if not cfg_path.exists():
            continue
        cstatus = load_yaml(cfg_path).get("status")
        assert cstatus == t["status"], \
            f"{t['code']}: registry status '{t['status']}' != config status '{cstatus}'"


def test_no_two_packs_share_an_output_table():
    """Every release name — staging, versioned tables, views, the __release pointer, the promotion
    lock — derives from run.output_table, correctly parameterized per product. But nothing checked
    two packs don't DECLARE the same table: a copy-pasted pipeline.yaml pointed at another
    product's table would publish over its views with every other guard passing."""
    seen = {}
    for t in _tumors():
        if "current_spec_version" not in t:
            continue
        cfg = load_config(product_config(PRODUCTS, t["slug"]))
        table = (cfg.raw.get("run") or {}).get("output_table")
        if not table or "REPLACE_ME" in str(table):
            continue
        assert table not in seen, \
            f"{t['code']} and {seen[table]} both declare run.output_table {table!r} — one " \
            f"product's release would silently publish over the other's views"
        seen[table] = t["code"]


def test_registry_lineage_matches_config():
    # A version / output-table bump must update BOTH the tumor config AND the registry lineage, so a
    # CalVer bump (e.g. 202606 -> 202607) or table rename cannot drift silently. Guards the
    # `current_spec_version` / `current_output_table` / lineage block for any tumor that declares them.
    for t in _tumors():
        if "current_spec_version" not in t:
            continue
        cfg = load_config(product_config(PRODUCTS, t["slug"]))
        spec = cfg.spec_version                              # CalVer contract (drops the .snapshot cut)
        # config version <-> registry current_spec_version <-> the spec-version FOLDER must agree (all
        # products, incl. scaffolds — their YYYYMM placeholder must match end to end).
        assert spec == t["current_spec_version"], \
            f"{t['code']}: config spec {spec} != registry current_spec_version {t['current_spec_version']}"
        # The output-table + lineage block is declared by ACTIVE products (a real contract); scaffolds
        # carry only current_spec_version (for folder resolution), so check the rest only when present.
        if "current_output_table" in t:
            assert t["current_output_table"] == (cfg.raw.get("run") or {}).get("output_table"), \
                f"{t['code']}: registry output table {t['current_output_table']} != config run.output_table"
        if t.get("lineage"):
            cur = [ln for ln in t["lineage"] if ln.get("spec_version") == t["current_spec_version"]]
            assert cur and cur[0].get("status") == "active", \
                f"{t['code']}: current_spec_version {t['current_spec_version']} has no active lineage entry"


def test_active_product_packs_are_not_scaffold():
    # Status discipline through the stack: an ACTIVE product must not compose scaffold variable packs
    # (otherwise the product reads "active" while its spec packs still say "scaffold").
    for t in _tumors():
        if t["status"] != "active":
            continue
        root = product_dir(PRODUCTS, t["slug"])
        raw = load_yaml(root / "config" / "data_product.yaml")
        rels = list(raw.get("variables") or []) + list((raw.get("codelists") or {}).values())
        for rel in rels:
            pack = load_yaml(root / rel)
            assert pack.get("status") != "scaffold", \
                f"{t['code']} is active but composes scaffold pack/codelist '{rel}'"


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
