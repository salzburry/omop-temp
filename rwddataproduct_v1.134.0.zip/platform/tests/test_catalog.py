"""Cross-tumor consistency: the master catalog is well-formed, its tumor codes match the registry,
and every dashboard variable resolves to a catalog code. Pure Python (no Spark).
Run: python3 test_catalog.py (or pytest).
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))
PRODUCTS = FRAMEWORK.parent / "products"

from engine.config import load_yaml   # noqa: E402
from engine.config import product_config, product_dir  # noqa: E402

CATALOG = PRODUCTS / "metadata" / "catalog.yaml"
REGISTRY = PRODUCTS / "registry.yaml"
DASHBOARD = PRODUCTS / "_reporting" / "dashboard" / "dashboard_vars.yaml"


def _catalog():
    return load_yaml(CATALOG)


def test_catalog_well_formed():
    codes = set()
    for v in _catalog()["variables"]:
        for k in ("code", "category", "label", "applies_to"):
            assert k in v, f"catalog variable missing '{k}': {v}"
        assert v["code"] not in codes, f"duplicate catalog code: {v['code']}"
        codes.add(v["code"])


def test_applies_to_codes_are_registered():
    reg = {t["code"] for t in load_yaml(REGISTRY)["tumors"]}
    cat = _catalog()
    assert set(cat["tumor_codes"]) <= reg, \
        f"catalog tumor_codes not in registry: {set(cat['tumor_codes']) - reg}"
    # ...and the mirror holds BOTH ways — the file says "mirror ../registry.yaml" and nothing
    # enforced it, so a new tumour registered but absent here had every `applies_to: [<code>]`
    # refused as unknown, three CI failures away from the registry line that caused it.
    assert reg <= set(cat["tumor_codes"]), \
        f"registry tumors missing from catalog tumor_codes: {reg - set(cat['tumor_codes'])}"
    for v in cat["variables"]:
        a = v["applies_to"]
        if a == "all":
            continue
        bad = set(a) - reg
        assert not bad, f"variable '{v['code']}' applies_to unknown tumor(s): {bad}"


def test_dashboard_variables_resolve_to_catalog():
    catalog_codes = {v["code"] for v in _catalog()["variables"]}
    dash = load_yaml(DASHBOARD)
    for panel in dash["panels"]:
        for var in panel["variables"]:
            assert var in catalog_codes, \
                f"dashboard panel '{panel['id']}' references unknown variable '{var}'"


def test_catalog_documents_every_emitted_variable():
    # Every config-driven variable a tumor emits must be in the master catalog, so the data dictionary
    # is complete. Guards against adding a categorical/panel/passthrough/outcome without cataloging it.
    from engine.config import load_config
    from engine.validate import emitted_variables
    from engine.dictionary import _applies
    cat = _catalog()["variables"]

    def _expand_line_template(code, maxl, maint):
        # A `lotN<suffix>` row documents EXACTLY its own per-line columns: lot{i}<suffix> per line (+ the
        # lot{i}m<suffix> maintenance variant), matching treatment.line_cols. Expanding per-suffix (not a
        # blanket "any template -> all line columns") means a NEW per-line field added to line_cols without
        # its own lotN<suffix> catalog row stays UNCATALOGED -> CI fails. (suffix: lotN->'', lotNsd->'sd'.)
        suffix = code[len("lotN"):]
        cols = set()
        for i in range(1, maxl + 1):
            cols.add(f"lot{i}{suffix}")
            if maint:
                cols.add(f"lot{i}m{suffix}")
        return cols

    # REGISTRY-DRIVEN: every tumor that has a current_spec_version AND a pack folder on disk — so a NEW
    # tumor (GIST, MDS, NSCLC …) is covered automatically the moment it gets a real pack, with no edit
    # to this test. For each, check EVERY on-disk spec version (current + superseded + scaffold), so a
    # superseded-but-buildable contract (e.g. prostate 202603) can't drift uncataloged either.
    checked = 0
    for t in load_yaml(REGISTRY)["tumors"]:
        slug, tcode = t.get("slug"), t.get("code")
        if not (slug and tcode and t.get("current_spec_version")):
            continue                                               # planned tumor, no pack yet
        pack_root = product_dir(PRODUCTS, slug).parent
        if not pack_root.exists():
            continue                                               # registered but no folder on disk yet
        for sv in sorted(d.name for d in pack_root.iterdir()
                         if (d / "config" / "data_product.yaml").exists()):
            cfg = load_config(product_config(PRODUCTS, slug, spec_version=sv))
            try:
                maxl = int((cfg.pack("treatment") or {}).get("max_lines", 0))
            except Exception:                                      # noqa: BLE001 - tumor without a treatment pack
                maxl = 0
            maint = any(c.get("maintenance") is not None for c in cfg.cohorts)
            cataloged = set()
            for v in cat:
                if not _applies(v, tcode):
                    continue
                if v.get("line_template"):
                    cataloged |= _expand_line_template(v["code"], maxl, maint)
                else:
                    cataloged.add(v["code"])
            missing = emitted_variables(cfg) - cataloged
            assert not missing, f"{slug}/{sv}: emitted but uncataloged for '{tcode}': {sorted(missing)}"
            checked += 1
    # the loop actually ran (prostate 202603+202606 + oc/ec/dlbcl scaffolds = >=5 (slug,version) packs)
    assert checked >= 5, f"catalog-completeness covered only {checked} (slug,version) packs — expected >=5"


def test_catalog_ledger_fields_well_formed():
    # Go-forward ledger (governance/VERSIONING.md): a variable MAY carry introduced_in / deprecated_in
    # ({code: "YYYYMM"}) + status. Absence = pre-ledger (NOT an error — the backfill rule). This test
    # only validates the FORM of ledger fields that ARE present, so a new tag can't be malformed.
    import re
    codes = {t["code"] for t in load_yaml(REGISTRY)["tumors"]}
    STATUS = {"implemented", "planned", "deprecated"}
    tagged = 0
    for v in _catalog()["variables"]:
        for field in ("introduced_in", "deprecated_in"):
            if field in v:
                tagged += 1
                assert isinstance(v[field], dict) and v[field], f"{v['code']}.{field} must be a non-empty map"
                for code, ver in v[field].items():
                    assert code in codes, f"{v['code']}.{field}: unknown tumor code '{code}'"
                    assert re.match(r"^\d{6}$", str(ver)), f"{v['code']}.{field}[{code}]: '{ver}' not YYYYMM"
        if "status" in v:
            assert v["status"] in STATUS, f"{v['code']}.status '{v['status']}' not in {sorted(STATUS)}"
    assert tagged >= 1, "expected at least one go-forward introduced_in tag (e.g. tsst @ 202606)"


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
