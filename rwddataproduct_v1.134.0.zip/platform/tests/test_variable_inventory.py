"""The variable inventory is a REFERENCE SHELF, and this pins what keeps it one.

governance/reference/variable_inventory/INVENTORY.yaml is ONE file holding the cross-tumour master
(definitions with parameter SLOTS), the 13 tumour overlays (literature-derived inventories whose
core variables instantiate master entries via `master:`), and each variable's engine coverage
inline. Two properties are load-bearing and are pinned here:

  * it can never quietly become a specification — the file says `status: reference_only` and
    carries the drafting-AID note verbatim, because the moment a reader can mistake this shelf for
    an approved workbook, it is doing the harm the note exists to prevent;
  * every claim is traceable — each variable cites published literature in a verifiable form
    (PMID / DOI / arXiv / PMCID, or journal volume:pages where the per-tumour caveats say why),
    every `master:` reference resolves to a real master entry, and every variable carries a
    coverage class with a checkable `via`, so "leverage the core and tweak the parameters" is a
    mechanical step rather than a hope.

Run: python3 tests/test_variable_inventory.py (or pytest).
"""
import re
import sys
from pathlib import Path

import yaml

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
INV = REPO / "governance" / "reference" / "variable_inventory"

CATEGORIES = {"eligibility_index", "demographics", "staging_histology", "biomarkers",
              "treatment", "outcomes", "comorbidity_labs"}
NOTE_PHRASE = "drafting AID, never a specification"
# a citation is verifiable IN FORM: a literature identifier, journal volume(:issue):pages, or an
# `in-house:` reference naming the pack whose drafting surfaces state the concept. SHAPE ONLY —
# this proves a citation is checkable, never that the cited work exists or says what the entry
# says (an offline test cannot resolve PubMed); the integration pass's verification note in the
# README is the existence claim, and it names its own limits. The shapes are tightened to what a
# real identifier looks like: a PMID is 6-9 digits (`PMID 0` is not a paper), a DOI has a
# registrant and a suffix (`10.` alone names nothing).
CITATION = re.compile(r"PMID\s*:?\s*\d{6,9}|DOI\s*:?\s*10\.\d{4,}/\S|\b10\.\d{4,}/\S|PMCID|arXiv:"
                      r"|\d+\(\d+\):\d+|\d+:\d+-\d+|^in-house: \S+ \d{6}")
PORTFOLIO = {"ovarian", "endometrial", "prostate", "nsclc", "sclc", "mcrc", "dlbcl", "cll",
             "gist", "hnscc", "multiple_myeloma", "myelofibrosis", "mds"}


def _doc():
    doc = yaml.safe_load((INV / "INVENTORY.yaml").read_text(encoding="utf-8"))
    assert isinstance(doc, dict) and doc, "INVENTORY.yaml is not a mapping"
    return doc


def test_the_shelf_exists_and_names_the_portfolio():
    assert (INV / "INVENTORY.yaml").exists(), "the inventory is gone"
    assert (INV / "README.md").exists(), "the shelf has no README saying what it is NOT"
    doc = _doc()
    assert PORTFOLIO <= set(doc.get("tumours") or {}), \
        f"portfolio tumours missing: {sorted(PORTFOLIO - set(doc.get('tumours') or {}))}"


def test_the_shelf_declares_itself_reference_only_with_the_note_verbatim():
    doc = _doc()
    assert doc.get("status") == "reference_only", \
        f"status={doc.get('status')!r} — this shelf must never read as approved"
    assert NOTE_PHRASE in str(doc.get("note") or ""), \
        "the drafting-AID note is missing or reworded"
    assert "approved workbook" in str(doc.get("note") or ""), \
        "the note must say where a variable's authority actually comes from"


def test_the_master_defines_slots_and_the_categories_hold():
    doc = _doc()
    names = [v["name"] for v in doc["master"]]
    assert len(names) == len(set(names)), "duplicate master names"
    for core in ("INDEX_DATE", "AGE", "AGEGR1", "LINE_OF_THERAPY", "DEATH_DATE", "OS", "RWPFS",
                 "RWTTD", "TTNT", "ECOG_PS", "COMORBIDITY_INDEX"):
        assert core in names, f"the master lost its {core} entry"
    for v in doc["master"]:
        assert v.get("category") in CATEGORIES, (v["name"], v.get("category"))
        assert str(v.get("definition_sketch") or "").strip(), v["name"]
        assert isinstance(v.get("parameter_slots"), dict), \
            f"{v['name']}: parameter_slots is the whole point of a master entry"
        for slot, spec in v["parameter_slots"].items():
            assert str((spec or {}).get("description") or "").strip(), \
                f"{v['name']}.{slot}: a slot without a description cannot be filled deliberately"
        assert v.get("citations"), f"{v['name']}: an unsourced master entry is an opinion"
        for c in v["citations"]:
            assert CITATION.search(str(c)), (v["name"], c)
    # the worked example of the slot mechanism stays honest about what it is
    agegr = next(v for v in doc["master"] if v["name"] == "AGEGR1")
    bands = agegr["parameter_slots"]["bands"].get("example_values") or {}
    assert bands and all("illustrative" in str(k) for k in bands), \
        "AGEGR1 example bands must be MARKED illustrative — they are not literature-derived"


def test_every_tumour_variable_is_shaped_cited_classified_and_master_refs_resolve():
    doc = _doc()
    master_names = {v["name"] for v in doc["master"]}
    for slug, entry in sorted(doc["tumours"].items()):
        assert str(entry.get("tumour") or "").strip(), slug
        variables = entry.get("variables")
        assert isinstance(variables, list) and len(variables) >= 20, \
            f"{slug}: an inventory this thin is not a starting point"
        seen, mapped = set(), set()
        for v in variables:
            name = v.get("name")
            assert name and name not in seen, (slug, name)
            seen.add(name)
            assert v.get("category") in CATEGORIES, (slug, name, v.get("category"))
            assert str(v.get("definition_sketch") or "").strip(), (slug, name)
            assert str(v.get("common_sources") or "").strip(), (slug, name)
            cits = v.get("citations")
            assert isinstance(cits, list) and cits, (slug, name)
            for c in cits:
                assert CITATION.search(str(c)), (slug, name, c)
            if "master" in v:
                assert v["master"] in master_names, \
                    (f"{slug}: {name} instantiates {v['master']!r}, which the master section "
                     f"does not define — the leverage link is broken")
                mapped.add(v["master"])
        # the design claim: every tumour STARTS from the core rather than re-deriving it
        for required in ("INDEX_DATE", "OS"):
            assert required in mapped, \
                f"{slug}: no variable instantiates the master {required} entry"


def test_the_inline_coverage_validates_and_the_rendered_map_is_current():
    """Every variable carries {class, via} inline, the enum has no dead value, COVERAGE.md is the
    current rendering, and the validator has teeth — a bad class is refused, not absorbed."""
    sys.path.insert(0, str(FRAMEWORK / "tools"))
    import inventory_coverage as ic
    doc = _doc()
    assert ic.coverage_errors(doc) == []
    md = INV / "COVERAGE.md"
    assert md.exists() and md.read_text(encoding="utf-8") == ic.render_md(doc), \
        "COVERAGE.md is stale — regenerate with: python3 platform/tools/inventory_coverage.py"
    classes = [v["coverage"]["class"] for t in doc["tumours"].values()
               for v in t["variables"]]
    for cls in ic.CLASSES:
        assert cls in classes, f"no variable classified {cls} — the enum has a dead value"
    broken = yaml.safe_load(yaml.safe_dump(doc))
    broken["tumours"]["gist"]["variables"][0]["coverage"] = {"class": "magic", "via": "x"}
    why = ic.coverage_errors(broken)
    assert any("coverage.class" in e for e in why), why


def test_the_shelf_quotes_no_vendor_documentation():
    """Published literature is allowed here; reproduced vendor documentation is not, and the
    governed marker list (governance/ai_boundary.yaml) is the test — the same phrases that make
    pack content vendor-derived make shelf content vendor-derived."""
    boundary = yaml.safe_load((REPO / "governance" / "ai_boundary.yaml")
                              .read_text(encoding="utf-8"))
    markers = [str(m.get("marker") or "").lower()
               for m in (boundary.get("documentation_markers") or [])]
    assert markers, "the marker list is empty — this test would pass vacuously"
    for path in (INV / "INVENTORY.yaml", INV / "README.md", INV / "COVERAGE.md"):
        text = path.read_text(encoding="utf-8").lower()
        for marker in markers:
            assert marker not in text, (path.name, marker)


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
