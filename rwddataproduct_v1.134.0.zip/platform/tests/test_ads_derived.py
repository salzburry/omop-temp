"""Pure-Python tests for the cross-stage derivation family (outcomes.ads_derived). No Spark.
Run: python3 tests/test_ads_derived.py (or pytest). The DataFrame application path is Spark — see
test_stages_spark.py::test_ads_derived_landmark_interval_and_skip.
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))

from engine.stages.ads_derived import (ads_derived_errors, emitted, interval_expr,   # noqa: E402
                                       landmark_case, landmark_event_expr)

LABELS = {"achieved": {"label": "Event-free at 24 months", "code": 1},
          "failed": {"label": "Event before 24 months", "code": 2},
          "not_evaluable": {"label": "Not evaluable", "code": 3}}


def test_interval_expr_months_and_days():
    assert interval_expr("metdate", "crpc_date") == "(datediff(crpc_date, metdate))/30.4375"
    assert interval_expr("lot1ed", "lot2sd", "days") == "datediff(lot2sd, lot1ed)"


def test_landmark_event_expr_single_gated_and_least():
    assert landmark_event_expr([{"date": "dthdt"}]) == "dthdt"
    assert landmark_event_expr([{"date": "pfsdt", "when": "pfsfl = 1"}, {"date": "dthdt"}]) == \
        "least(CASE WHEN pfsfl = 1 THEN pfsdt END, dthdt)"


def test_landmark_case_states_in_the_load_bearing_order():
    sql = landmark_case("index_date", 730, [{"date": "dthdt"}], "fued", LABELS)
    assert sql == ("CASE WHEN index_date IS NULL THEN NULL "
                   "WHEN (dthdt) IS NOT NULL AND (dthdt) <= date_add(index_date, 730) "
                   "THEN 'Event before 24 months' "
                   "WHEN fued >= date_add(index_date, 730) THEN 'Event-free at 24 months' "
                   "ELSE 'Not evaluable' END")
    # FAILED before ACHIEVED: an event inside the horizon fails whatever the follow-up looks like,
    # and event-free with short follow-up is the third state — not achievement.
    assert sql.index("Event before") < sql.index("Event-free"), sql
    ncase = landmark_case("index_date", 730, [{"date": "dthdt"}], "fued", LABELS, key="code")
    assert "THEN 2 " in ncase and "THEN 1 " in ncase and ncase.endswith("ELSE 3 END")
    # a label with an apostrophe must not break the statement
    hostile = dict(LABELS, failed={"label": "O'Brien failed", "code": 2})
    assert "'O''Brien failed'" in landmark_case("index_date", 90, [{"date": "d"}], "f", hostile)


def test_emitted_names():
    items = [{"name": "efs24", "landmark": {}, "requires": ["x"]},
             {"name": "ttcrpc", "interval": {"from": "a", "to": "b"}, "requires": ["a", "b"],
              "bands": [{"label": "Short", "code": 1, "max": 12}]},
             {"name": "indexyr2", "expr": "year(index_date)", "requires": ["index_date"]}]
    assert emitted(items) == {"efs24", "ttcrpc", "ttcrpcgr", "indexyr2"}
    assert emitted(None) == set()


def test_errors_refuse_the_shapes_that_silently_do_nothing():
    ok = [{"name": "efs24", "requires": ["index_date", "dthdt", "fued"],
           "landmark": {"anchor": "index_date", "horizon_days": 730,
                        "events": [{"date": "dthdt"}], "censor": {"date": "fued"},
                        "labels": LABELS}},
          {"name": "ttcrpc", "requires": ["metdate", "crpc_date"],
           "interval": {"from": "metdate", "to": "crpc_date", "unit": "months"}}]
    assert ads_derived_errors(ok) == []
    assert ads_derived_errors(None) == []

    def one(item):
        return ads_derived_errors([item])

    assert any("missing 'name'" in e for e in one({"requires": ["a"], "expr": "1"}))
    assert any("exactly one of" in e for e in one({"name": "x", "requires": ["a"]}))
    assert any("exactly one of" in e for e in one(
        {"name": "x", "requires": ["a"], "expr": "1", "interval": {"from": "a", "to": "b"}}))
    # requires is MANDATORY: an unstated input list is a derivation that silently never runs
    assert any("requires" in e for e in one({"name": "x", "expr": "1"}))
    assert any("requires" in e for e in one({"name": "x", "expr": "1", "requires": []}))
    assert any("duplicates" in e for e in ads_derived_errors(
        [dict(ok[1]), dict(ok[1])]))
    assert any("bands" in e for e in one({"name": "x", "requires": ["a"], "expr": "1",
                                          "bands": [{"label": "L", "code": 1}]}))
    assert any("interval.unit" in e for e in one(
        {"name": "x", "requires": ["a", "b"],
         "interval": {"from": "a", "to": "b", "unit": "weeks"}}))
    lm = {"anchor": "index_date", "horizon_days": 0, "events": [{"date": "d"}],
          "censor": {"date": "f"}, "labels": LABELS}
    assert any("horizon_days" in e for e in one(
        {"name": "x", "requires": ["a"], "landmark": lm}))
    assert any("labels.not_evaluable" in e for e in one(
        {"name": "x", "requires": ["a"],
         "landmark": dict(lm, horizon_days=730,
                          labels={"achieved": {"label": "A", "code": 1},
                                  "failed": {"label": "F", "code": 2},
                                  "not_evaluable": {"label": "N"}})}))


def test_validate_wires_emitted_and_errors():
    """emitted_variables and problems() must SEE the block — a family the validator cannot see is
    one a catalog-completeness check can never cover."""
    import types
    items = [{"name": "efs24", "requires": ["index_date"],
              "landmark": {"anchor": "index_date", "horizon_days": 730,
                           "events": [{"date": "dthdt"}], "censor": {"date": "fued"},
                           "labels": LABELS}}]
    sys.path.insert(0, str(FRAMEWORK / "engine"))
    import validate                                    # noqa: E402
    cfg = types.SimpleNamespace(pack=lambda role: {"ads_derived": items} if role == "outcomes"
                                else (_ for _ in ()).throw(KeyError(role)))
    assert "efs24" in validate.emitted_variables(cfg)
    bad = validate.ads_derived_errors([{"name": "x"}])
    assert bad and any("exactly one of" in e for e in bad)


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
