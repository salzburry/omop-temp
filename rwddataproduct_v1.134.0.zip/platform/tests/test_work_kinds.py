"""Gate weight follows the AUTHORITY CREATED, not the work done — and provenance has teeth.

The framework was built around one object: a tumour's spec version, which creates a table other
people trust. Six gates is right for that. It is wrong for a one-off analysis over an ALREADY
released product, which creates no new authority — and the observable consequence of getting it
wrong is not that such work is over-governed, it is that it happens entirely outside governance.

So a `request` owes one obligation instead of six. Everything here exists to stop that from being
an exemption:

  * a kind that owes provenance must SAY what it reads — an empty `cites_release` is refused;
  * what it cites must be genuinely citable — `releasable()`, the same derived answer that decides
    whether a pack may publish at all, not a flag anyone can set;
  * an unknown `kind:` owes EVERYTHING, so a typo is never the cheap way past five gates.

And the compatibility promise, tested as hard as the rest: with no `work:` block, nothing changes.

Run: python3 tests/test_work_kinds.py (or pytest).
"""
import shutil
import sys
import tempfile
from pathlib import Path

import yaml

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))

import product_gates as pg        # noqa: E402
import source_manifest as sm      # noqa: E402


def _root(work=None, tumors=None):
    """A throwaway repo root carrying a registry and one pack directory."""
    root = Path(tempfile.mkdtemp())
    (root / "products" / "oncology" / "testis" / "202608" / "config").mkdir(parents=True)
    reg = {"tumors": tumors if tumors is not None else
           [{"code": "testis", "name": "Testis", "slug": "testis", "vendor": "flatiron",
             "tumor_class": "solid", "status": "scaffold"}]}
    if work is not None:
        reg["work"] = work
    (root / "products" / "registry.yaml").write_text(yaml.safe_dump(reg), encoding="utf-8")
    return root


def test_the_kinds_and_their_gates_are_one_table():
    """One place says who owes what. Every kind's gates must be real gates."""
    assert set(pg.KIND_GATES) == set(pg.KINDS)
    for kind, gates in pg.KIND_GATES.items():
        assert gates, f"{kind} owes nothing at all — that is not a governed object"
        assert set(gates) <= set(pg.GATES), (kind, sorted(set(gates) - set(pg.GATES)))
    # the shape of the claim: a product owes strictly more than a request
    assert set(pg.KIND_GATES["request"]) < set(pg.KIND_GATES["product"] + ("provenance",))
    assert len(pg.KIND_GATES["product"]) == 6, "the six gates are the product ladder"
    assert "provenance" not in pg.KIND_GATES["product"], \
        "a product registers its own source; it does not inherit one"
    for light in ("request", "protocol"):
        assert "provenance" in pg.KIND_GATES[light], light
        assert "source" not in pg.KIND_GATES[light], \
            f"{light} would re-register a source that is already registered"


def test_an_unknown_kind_owes_everything():
    """Fail-closed on the one axis where a default decides how much scrutiny something gets."""
    for bogus in ("", "reqeust", None, "Product", "analysis"):
        assert pg.gates_for(bogus) == pg.KIND_GATES["product"], bogus


def test_no_work_block_changes_nothing():
    """The compatibility promise. This is the state the repository is in today."""
    root = _root()
    try:
        assert pg.work_entries(str(root)) == []
        assert pg.work_errors(str(root)) == []
    finally:
        shutil.rmtree(root, ignore_errors=True)
    # ...and against the REAL registry, which is what CI actually runs over
    assert pg.work_errors(str(REPO)) == [], "the live registry's work block does not validate"


def test_a_kind_that_owes_provenance_must_cite_something():
    """An empty citation list is the exact state this path exists to prevent: work that inherits an
    approval it never named."""
    root = _root(work=[{"id": "req-001", "kind": "request", "title": "t"}])
    try:
        bad = pg.work_errors(str(root))
        assert any("cites no release" in e for e in bad), bad
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_the_work_block_shape_is_validated():
    root = _root(work=[
        {"kind": "request", "cites_release": [{}]},                       # no id
        {"id": "a", "cites_release": [{}]},                               # no kind
        {"id": "b", "kind": "analysis", "cites_release": [{}]},           # unknown kind
        {"id": "testis", "kind": "request", "cites_release": [{}]},       # collides with a slug
        {"id": "c", "kind": "product"},                                   # belongs in tumors:
        "not a mapping",
    ])
    try:
        bad = pg.work_errors(str(root))
        for want in ("no id", "no kind", "not one of", "already a tumour slug",
                     "belongs in `tumors:`", "not a mapping"):
            assert any(want in e for e in bad), (want, bad)
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_duplicate_id_is_refused():
    root = _root(work=[{"id": "d", "kind": "request", "cites_release": [{}]},
                       {"id": "d", "kind": "protocol", "cites_release": [{}]}])
    try:
        assert any("declared twice" in e for e in pg.work_errors(str(root)))
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_kind_for_resolves_products_first():
    """One name, one object — a `work:` entry cannot rename what a tumour slug already means."""
    root = _root(work=[{"id": "req-1", "kind": "request", "cites_release": [{}]}])
    try:
        assert pg.kind_for(str(root), "testis") == "product"
        assert pg.kind_for(str(root), "req-1") == "request"
        assert pg.kind_for(str(root), "nobody") is None
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_citation_must_name_a_real_pack():
    root = _root(work=[{"id": "r", "kind": "request",
                        "cites_release": [{"product": "ghost", "spec_version": "202608"}]}])
    try:
        bad = sm.citation_errors(str(root), {"id": "r", "cites_release":
                                             [{"product": "ghost", "spec_version": "202608"}]})
        assert any("does not exist" in e for e in bad), bad
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_citation_needs_both_the_product_and_the_version():
    for c in ({"product": "testis"}, {"spec_version": "202608"}, {}):
        bad = sm.citation_errors(str(REPO), {"id": "r", "cites_release": [c]})
        assert any("needs both" in e for e in bad), (c, bad)
    bad = sm.citation_errors(str(REPO), {"id": "r", "cites_release": ["nope"]})
    assert any("not a mapping" in e for e in bad), bad


def test_citing_an_unreleasable_pack_is_refused_and_says_why():
    """THE POINT. The light path is an INHERITANCE, so it is only worth what it inherits from.

    Every pack in this repository is unreleasable today — no program_spec is approved anywhere — so
    a citation of the most advanced pack must still be refused, and the reason must be the pack's
    own blockers rather than a generic message.
    """
    entry = {"id": "req-x", "cites_release":
             [{"product": "prostate", "spec_version": "202606"}]}
    bad = sm.citation_errors(str(REPO), entry)
    assert bad, "citing a pack with a pending source was accepted"
    assert all("not citable" in e for e in bad), bad
    assert any("Gate 1" in e for e in bad), \
        "the refusal does not carry the pack's own reason — it must, or nobody can act on it"
    # and it is `releasable` that decided, not a second opinion
    _, why = sm.releasable(str(REPO), "products/oncology/prostate/202606")
    assert why and all(any(w in e for e in bad) for w in why[:1])


def test_pinning_a_build_asks_the_stronger_question():
    """Pack-level asks Gates 1-4; naming a build additionally asks Gate 6 for THAT build."""
    base = {"product": "prostate", "spec_version": "202606"}
    pack_level = sm.citation_errors(str(REPO), {"id": "r", "cites_release": [base]})
    build_level = sm.citation_errors(
        str(REPO), {"id": "r", "cites_release": [dict(base, build_id="b1",
                                                      manifest_sha256="0" * 64)]})
    assert any("(pack)" in e for e in pack_level), pack_level
    assert any("(build b1)" in e for e in build_level), build_level
    assert len(build_level) >= len(pack_level), \
        "pinning a build asked FEWER questions than not pinning one"


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
