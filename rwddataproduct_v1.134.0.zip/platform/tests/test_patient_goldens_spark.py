"""Row-level clinical goldens: hand-computed patients, EXACT expected outputs, real stages.

The existing checks prove the build RUNS (smoke) and that each stage behaves on its own frame
(stages). What nothing proved is the composed answer for a person: given THIS patient, the ADS says
exactly THIS. Distribution- and count-level checks pass while a divisor, a boundary or a band edge
is wrong for every row in the same direction — "internally consistent, clinically wrong".

Every expectation here is computed BY HAND from the governed config and written down with its
arithmetic, BEFORE looking at what the code prints. The golden pins the settled derivations:

  * study-window membership, inclusive at the start boundary (2011-01-01 IS in, 2010-12-31 is not)
  * index_date = the cohort's configured diagnosis date (overall mCRPC: advanceddiagnosisdate)
  * AGE = year(index_date) - birthyear     (2011 - 1950 = 61; 2020 - 1940 = 80)
  * AGEGRLN from config age_bands          (61 -> 50-64 = code 4; 80 -> 75-84 = code 6)
  * DTHFL = 1 iff a death date exists      (full-granularity dateofdeath; no imputation involved)

DELIBERATELY NOT GOLDENED: the FUED family and the OS/TTNT durations — their requirement is
decision-blocked (FUED-DEFINITION et al. in the pack's register), and a golden over an unsettled
rule would freeze one reading of an open question as "expected". They join this file the day their
decisions land, with the arithmetic shown like everything else.

Skips cleanly without PySpark; the `spark` CI job runs it and refuses a broken install.
"""
import sys
from datetime import date
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))
sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))

try:
    import pyspark  # noqa: F401
    HAVE = True
except Exception:  # noqa: BLE001
    HAVE = False

import synthetic_sources  # noqa: E402

CONFIG = str(FRAMEWORK.parent / "products" / "oncology" / "prostate" / "202606"
             / "config" / "data_product.yaml")

# The golden patients. One row here = one hand-computed expectation block below.
#   gp1: index ON the window start (inclusive), dies later that year        -> in, dthfl 1
#   gp2: mid-window index, alive                                            -> in, dthfl 0
#   gp3: diagnosed one day BEFORE the window                                -> excluded entirely
#   gp4/gp5 EXECUTE two settled records' own `acceptance` cells (FUNCTIONAL_CONTRACT.md) — the
#   worked examples every record carries, run against the composed stages instead of only read:
#     MCRPCDD   gp4: met=2021-02-01, crpc=2022-06-01 -> greatest = 2022-06-01
#               gp5: met=2019-05-01, crpc=NULL       -> the NULL operand drops out -> 2019-05-01
#     PSA_INDEX gp4: 12.0 at index-8d and 15.0 ON index day -> 12.0 (earliest in [-14, 0])
#               gp5: 8.0 and 9.0 BOTH at index-3d           -> 9.0  (same_day -> max)
#   As further decisions settle, their records' acceptance examples land here the same way.
GOLDEN = {
    "gp1": {"adv": date(2011, 1, 1), "birthyear": "1950", "death": "2011-06-15",
            "age": 61, "band": 4, "dthfl": 1},
    "gp2": {"adv": date(2020, 6, 1), "birthyear": "1940", "death": None,
            "age": 80, "band": 6, "dthfl": 0},
    "gp3": {"adv": date(2010, 12, 31)},
    "gp4": {"adv": date(2021, 2, 1), "birthyear": "1955", "death": None,
            "age": 66, "band": 5, "dthfl": 0,                      # 2021 - 1955 = 66 -> 65-74 = 5
            "met": date(2021, 2, 1), "crpc": date(2022, 6, 1), "mcrpcdd": date(2022, 6, 1),
            "psa": [(date(2021, 1, 24), "12.0"), (date(2021, 2, 1), "15.0")], "psa_index": 12.0},
    "gp5": {"adv": date(2019, 5, 1), "birthyear": "1940", "death": None,
            "age": 79, "band": 6, "dthfl": 0,                      # 2019 - 1940 = 79 -> 75-84 = 6
            "met": date(2019, 5, 1), "crpc": None, "mcrpcdd": date(2019, 5, 1),
            "psa": [(date(2019, 4, 28), "8.0"), (date(2019, 4, 28), "9.0")], "psa_index": 9.0},
}


def _with_goldens(s, cfg):
    """The synthetic base (schema-correct for every declared source), with the golden patients'
    rows unioned onto the three tables their derivations read. The base rows keep their own
    patient ids, so asserting on gp* rows is asserting on hand-authored data only."""
    from pyspark.sql import functions as F
    src = dict(synthetic_sources.sources(s, cfg))
    aug = synthetic_sources.augment

    enh = s.createDataFrame(
        [(pid, g["adv"], g.get("met"), g.get("crpc")) for pid, g in GOLDEN.items()],
        ["patientid", "advanceddiagnosisdate", "metastaticdiagnosisdate", "crpcdate"])
    enh = aug(enh, [c for c in src["enhanced"].columns
                    if c not in ("advanceddiagnosisdate", "metastaticdiagnosisdate", "crpcdate")],
              date(2011, 1, 1))
    src["enhanced"] = src["enhanced"].unionByName(
        enh.select(src["enhanced"].columns), allowMissingColumns=True)

    psa_rows = [(pid, d, v) for pid, g in GOLDEN.items() for d, v in g.get("psa", [])]
    if psa_rows and "psa" in src:
        psa = s.createDataFrame(psa_rows, ["patientid", "resultdate", "scoreserial"])
        psa = aug(psa, [c for c in src["psa"].columns
                        if c not in ("resultdate", "scoreserial")], date(2011, 1, 1))
        src["psa"] = src["psa"].unionByName(psa.select(src["psa"].columns),
                                            allowMissingColumns=True)

    dem = s.createDataFrame(
        [(pid, g["birthyear"]) for pid, g in GOLDEN.items() if "birthyear" in g],
        ["patientid", "birthyear"])
    dem = aug(dem, [c for c in src["demographics"].columns if c != "birthyear"], date(2011, 1, 1))
    src["demographics"] = src["demographics"].unionByName(
        dem.select(src["demographics"].columns), allowMissingColumns=True)

    dead = [(pid, g["death"]) for pid, g in GOLDEN.items() if g.get("death")]
    if dead:
        mort = s.createDataFrame(dead, ["patientid", "dateofdeath"])
        mort = aug(mort, [c for c in src["mortality"].columns if c != "dateofdeath"],
                   date(2011, 6, 15))
        src["mortality"] = src["mortality"].unionByName(
            mort.select(src["mortality"].columns), allowMissingColumns=True)
    # the golden patients have NO LOT lines — treated is not what this file goldens
    _ = F
    return src


def test_hand_computed_patients_come_out_exactly_as_computed():
    if not HAVE:
        print("SKIP — pyspark is not installed. The patient goldens are NOT verified by this run; "
              "see the `spark` CI job, which refuses to proceed without it.")
        return
    from pyspark.sql import functions as F

    from engine.config import load_config
    from engine.stages import clinical as clin_stage
    from engine.stages import demographics as dem_stage
    from engine.stages import index as index_stage
    from engine.stages import lot as lot_stage
    from engine.stages import outcomes as out_stage
    from engine.stages import treatment as trt_stage
    from engine.stages import assemble as asm_stage

    s = synthetic_sources.session("goldens")
    cfg = load_config(CONFIG)
    cohort = next(c for c in cfg.cohorts if c["id"] == "overall_mcrpc")
    src = _with_goldens(s, cfg)

    treated = (lot_stage.normalized(src, cohort.get("line_setting", cfg.lot_line_setting),
                                    exclude_settings=cfg.lot_exclude_settings,
                                    line_number_col=cfg.lot_line_number_col,
                                    maintenance_column=cfg.lot_maintenance_column)
               .select("patientid").distinct().withColumn("treat_flag", F.lit(1)))
    idx = index_stage.build(src, cfg, cohort)
    dem = dem_stage.build(src, idx, cfg)
    clin = clin_stage.build(src, idx, cfg)
    trt = trt_stage.build(src, idx, cfg, cohort)
    out = out_stage.build(src, idx, clin, trt, cfg, cohort)
    ads = asm_stage.build(idx, dem, clin, trt, out, cfg, cohort, treated)

    rows = {r["patientid"]: r.asDict()
            for r in ads.filter(F.col("patientid").startswith("gp")).collect()}

    # gp3: 2010-12-31 is one day before index_start 2011-01-01 — the window is a closed interval
    # and the boundary is exact. An off-by-one here moves every cohort by a day of history.
    assert "gp3" not in rows, "a patient diagnosed before the study window entered the cohort"
    assert set(rows) == {"gp1", "gp2", "gp4", "gp5"}, sorted(rows)

    for pid in ("gp1", "gp2", "gp4", "gp5"):
        g, r = GOLDEN[pid], rows[pid]
        low = {k.lower(): v for k, v in r.items()}
        assert low["index_date"] == g["adv"], (pid, low["index_date"], g["adv"])
        # AGE = year(index) - birthyear, from the config's own formula — shown in GOLDEN's comments
        assert low["age"] == g["age"], (pid, "age", low["age"], g["age"])
        assert int(low["agegrln"]) == g["band"], (pid, "agegrln", low["agegrln"], g["band"])
        assert int(low["dthfl"]) == g["dthfl"], (pid, "dthfl", low["dthfl"], g["dthfl"])

    # gp1 sits ON the inclusive start boundary — asserted separately so a boundary regression names
    # itself instead of surfacing as "gp1 vanished".
    assert rows["gp1"]["index_date"] == date(2011, 1, 1)

    # gp4/gp5: the MCRPCDD and PSA_INDEX acceptance cells, executed. Asserted on the clinical
    # frame — the composed chain those columns travel through — with the arithmetic in GOLDEN's
    # comments taken from the records' own acceptance examples, never from what the code printed.
    crows = {r["patientid"]: {k.lower(): v for k, v in r.asDict().items()}
             for r in clin.filter(F.col("patientid").isin("gp4", "gp5")).collect()}
    assert set(crows) == {"gp4", "gp5"}, sorted(crows)
    for pid in ("gp4", "gp5"):
        g, c = GOLDEN[pid], crows[pid]
        assert c["mcrpcdd"] == g["mcrpcdd"], (pid, "mcrpcdd", c["mcrpcdd"], g["mcrpcdd"])
        assert c["psa_index"] is not None and float(c["psa_index"]) == g["psa_index"], \
            (pid, "psa_index", c["psa_index"], g["psa_index"])
    print("ok  5 hand-computed patients: boundary membership, index, age, band, death flag, and "
          "the MCRPCDD/PSA_INDEX acceptance examples — exact")


if __name__ == "__main__":
    test_hand_computed_patients_come_out_exactly_as_computed()
    print("OK")
