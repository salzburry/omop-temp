"""The decision memory is a live view with provenance — and its suggester is measured, not hoped.

Run: python3 tests/test_knowledge_graph.py (or pytest).
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))

import knowledge_graph as kg    # noqa: E402


def test_the_graph_is_a_view_with_provenance_never_a_store():
    """Every node carries the register's own words plus WHERE they came from; nothing is cached,
    and the module writes nothing — a knowledge base that could drift from a register would be a
    second implementation of every register it summarised."""
    src = (FRAMEWORK / "tools" / "knowledge_graph.py").read_text(encoding="utf-8")
    assert 'open(' not in src.replace("with open(", "").replace("open(path, encoding", ""), \
        "an unexpected file handle appeared — this module must stay read-only"
    nodes = kg.build()
    assert len(nodes) >= 20, "the live registers hold more decisions than this"
    fued = next(n for n in nodes if n["id"] == "FUED-DEFINITION")
    assert fued["pack"].endswith("prostate/202606") and fued["status"] == "OPEN"
    assert "OS" in fued["cited_by"], "the contract's citations must ride the node"
    assert fued["precedent"] == "follow-up-end-definition", \
        "the human-recorded pairing in governance/precedents.yaml must resolve onto the node"
    # A RULING NEEDS A SIGNATURE, and this assertion used to accept anything: `approval_date is not
    # None` is TRUE for the empty string, so a row with no approver and no date passed on the second
    # branch of an `or`. Both live RESOLVED rows are exactly that, and an external review found them
    # ranked above open questions and rendered as rulings.
    resolved = [n for n in nodes if n["status"] == "RESOLVED" and n["answer"]]
    assert resolved, "no resolved decision in the live registers — this test would prove nothing"
    for n in resolved:
        signed = bool(n["approved_by"]) and bool(n["approval_date"])
        assert kg.ruled(n) == signed, \
            f"{n['id']}: ruled() says {kg.ruled(n)} for approver={n['approved_by']!r} " \
            f"date={n['approval_date']!r}"
        if not signed:
            # It stays searchable and stays in the results — it is just not a ruling, and the label
            # leads with that rather than with the word RESOLVED.
            assert kg.resolved_unsigned(n)
            assert kg._ruling_label(n).startswith("UNVERIFIED RESOLUTION"), kg._ruling_label(n)
    # ...and an unsigned resolution must NOT outrank an open question, which is the ordering the
    # ruled-first sort exists to control.
    unsigned = [n for n in resolved if not kg.ruled(n)]
    if unsigned:
        opens = [n for n in nodes if n["status"] == "OPEN"]
        assert opens, "no open decision to compare ranking against"
        ranked = kg.query(unsigned[:1] + opens[:1], [])
        assert not kg.ruled(ranked[0]), "an unsigned resolution was sorted into the rulings half"


def test_query_needs_every_term_and_absence_means_never_raised():
    nodes = kg.build()
    hits = kg.query(nodes, ["fued"])
    assert any(n["id"] == "FUED-DEFINITION" for n in hits)
    assert kg.query(nodes, ["fued", "zebra"]) == [], "every term must match, not any"


def test_the_suggester_finds_both_ground_truth_twins_by_their_anchors():
    """The calibration that rewrote the design: the two pairs a human already recorded in
    precedents.yaml scored 0.19 and 0.01 on plain token overlap — below the noise floor — while
    each shares a rare anchor no noise pair does. Simulate them UNRECORDED (clear the pairing on
    the live nodes) and the suggester must find both, naming the anchor it matched on."""
    nodes = kg.build()
    for n in nodes:
        n["precedent"] = ""
    pairs = {tuple(sorted((x["id"], y["id"]))): anchors for anchors, x, y in kg.suggest(nodes)}
    fued = pairs.get(("FUED-DEFINITION", "OC-FU-END-DEFINITION"))
    assert fued and "follow" in fued, pairs.keys()
    days = pairs.get(("OC-DAYS-PER-MONTH-LANDMARKS", "TT-INTERVAL-FORMULA"))
    assert days and "4375" in days, pairs.keys()


def test_recorded_pairs_are_excluded_and_anchors_reject_years_and_filler():
    nodes = kg.build()
    ids = {tuple(sorted((x["id"], y["id"]))) for _a, x, y in kg.suggest(nodes)}
    assert ("FUED-DEFINITION", "OC-FU-END-DEFINITION") not in ids, \
        "a pair the store already records must not be re-suggested"
    assert kg._anchor("4375") and kg._anchor("follow")
    assert not kg._anchor("2026"), "a year is two questions being contemporaries, not one question"
    assert not kg._anchor("day"), "short filler cannot carry a match alone"
    assert "them" not in kg.tokens("keep them all"), "filler words are stopped before df counting"


def test_jsonld_export_covers_every_node_key_and_stays_pack_scoped():
    """The interop export cannot silently drop a field: the @context is held to exactly the node
    keys. Identity is pack-scoped because one decision id legitimately exists in several packs."""
    import json
    nodes = kg.build()
    doc = kg.jsonld(nodes)
    json.dumps(doc)                                    # serialisable, no cycles
    assert set(kg.CONTEXT) - {"@vocab"} == set(nodes[0]), \
        "a node key without a context mapping (or a mapping without a key) — realign CONTEXT"
    ids = [e["id"] for e in doc["@graph"]]
    assert len(ids) == len(set(ids)), "two decisions collapsed onto one IRI"
    fued = [e for e in doc["@graph"] if e["id"].endswith("prostate/202606#FUED-DEFINITION")]
    assert fued and fued[0]["@type"] == "Decision" and fued[0]["cited_by"], fued


def test_empty_query_and_broken_store_are_refused_not_served():
    """An empty query matched everything (all-terms over no terms is vacuously true), and a
    malformed precedents.yaml was swallowed into an EMPTY store — recorded pairs re-surfaced as
    'unrecorded' and every card dropped its precedent line. Both now refuse loudly."""
    try:
        kg.main(["--query", "   "])
        raise AssertionError("an all-blank --query was accepted")
    except SystemExit as e:
        assert e.code not in (0, None)
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        pack = Path(tmp) / "products" / "oncology" / "x" / "202606" / "handoff"
        pack.mkdir(parents=True)
        (pack / "DECISIONS.md").write_text(
            "| ID | Question | Owner | Status |\n|---|---|---|---|\n| A-B | q | RWB | OPEN |\n",
            encoding="utf-8")
        (Path(tmp) / "governance").mkdir()
        (Path(tmp) / "governance" / "precedents.yaml").write_text(
            "precedents: [unclosed", encoding="utf-8")
        try:
            kg.build(root=tmp)
            raise AssertionError("a malformed store was swallowed")
        except SystemExit as e:
            assert "will not pretend it is empty" in str(e)


def test_query_labels_rulings_and_lists_resolved_before_open():
    """An OPEN decision printed with the same one-word tag as the ruling beside it reads as
    precedent, and gets retyped as one. Open decisions are deliberately NOT hidden — finding that
    another pack is ASKING your question is real value — so every hit says IN WORDS whether it is a
    ruling or a question, and rulings list first regardless of term-frequency rank."""
    def node(i, status, question, who="", date=""):
        return {"pack": f"products/oncology/x/20260{i}", "id": f"D-{i}", "status": status,
                "question": question, "evidence": "",
                "answer": "ans" if status == "RESOLVED" else "",
                "approved_by": who, "approval_date": date, "cited_by": [], "precedent": ""}
    open_loud = node(1, "OPEN", "zebra zebra zebra zebra")
    ruled_quiet = node(2, "RESOLVED", "zebra", who="A. Person", date="2026-01-01")
    withdrawn = node(3, "WITHDRAWN", "zebra zebra")
    # ORDERING: the ruling outranks a louder OPEN match; within the no-ruling half, coverage still
    # ranks (synthetic nodes, so the rule is pinned independent of what the live registers say today)
    got = [n["id"] for n in kg.query([open_loud, ruled_quiet, withdrawn], ["zebra"])]
    assert got == ["D-2", "D-1", "D-3"], got
    # LABELS: a ruling carries approver + date (what makes it citable); everything that is not
    # RESOLVED — OPEN, WITHDRAWN, a blank status — is "no ruling", fail-closed; and a resolved row
    # naming nobody says so instead of implying an attribution the register never recorded
    assert kg._ruling_label(ruled_quiet) == "RESOLVED — ruled by A. Person on 2026-01-01"
    assert kg._ruling_label(open_loud) == "OPEN — no ruling; a question, not a precedent"
    assert kg._ruling_label(withdrawn) == "WITHDRAWN — no ruling; a question, not a precedent"
    # RESOLVED WITHOUT A SIGNATURE IS NOT A RULING — not by the label, and not by the predicate.
    unsigned = node(4, "RESOLVED", "zebra")
    assert not kg.ruled(unsigned) and kg.resolved_unsigned(unsigned)
    assert kg._ruling_label(unsigned).startswith("UNVERIFIED RESOLUTION — no approver named")
    # ...an approver with a malformed date is refused the same way: a date nobody can order by
    # cannot establish which of two rulings came first.
    baddate = node(6, "RESOLVED", "zebra", who="A. Person", date="soon")
    assert not kg.ruled(baddate), "a ruling was accepted with an unparseable approval date"
    assert "is not a date" in kg._ruling_label(baddate)
    # ...and an unsigned resolution ranks with the questions, not above them.
    assert kg.query([unsigned, open_loud], ["zebra"])[0]["id"] == "D-1"
    assert "no ruling" in kg._ruling_label(node(5, "", "zebra")), "unstated status must not read as ruled"
    # AND THE RENDERED PAGE, over the live registers. THE REPOSITORY CURRENTLY HAS NO SIGNED
    # RULINGS AT ALL: both RESOLVED rows (STUDY-WINDOW, MAXINDEX) have blank approver and date
    # columns, so the tally reads 0. That is the honest state and the test states it — before the
    # signature gate, this same query rendered them as `[RESOLVED — approver unstated]` above the
    # open questions, which is the finding.
    import contextlib
    import io
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        assert kg.main(["--query", "window"]) == 0
    out = buf.getvalue()
    assert "with a ruling (listed first)" in out, "the tally must state the split up front"
    assert "[OPEN — no ruling; a question, not a precedent]" in out, out
    live = kg.build()
    signed = [n for n in live if kg.ruled(n)]
    if signed:
        assert "[RESOLVED — ruled by " in out or all("window" not in n["question"].lower()
                                                     for n in signed)
        if "[RESOLVED — ruled by " in out:
            assert out.rindex("[RESOLVED — ruled by ") < out.index("[OPEN — "), \
                "a ruling printed below an open question — resolved hits must list first"
    else:
        assert "0 with a ruling" in out, out
        assert "[RESOLVED — " not in out, \
            "a row rendered as a ruling while no decision in the repository carries a signature"


def test_the_routing_index_names_only_surfaces_that_exist():
    """governance/INDEX.yaml is addresses, not answers — and a route to a tool or skill that does
    not exist is worse than no route, because it reads as one."""
    import re
    import yaml
    doc = yaml.safe_load((FRAMEWORK.parent / "governance" / "INDEX.yaml").read_text(encoding="utf-8"))
    routes = doc.get("routes") or []
    assert len(routes) >= 10
    for r in routes:
        assert r.get("question") and r.get("owner") and r.get("command"), r
        for tool in re.findall(r"platform/tools/(\w+)\.py", r["command"]):
            assert (FRAMEWORK / "tools" / f"{tool}.py").exists(), (r["owner"], tool)
        if str(r["owner"]).startswith("skill:"):
            name = r["owner"].split(":", 1)[1]
            assert (FRAMEWORK.parent / ".claude" / "skills" / name / "SKILL.md").exists(), name
    owners = {str(r["owner"]) for r in routes}
    assert "human" in owners, "the index must route the human-only questions to a human, by name"


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
