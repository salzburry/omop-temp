"""Registry-driven Spark smoke test: build the ADS for EVERY configured tumor on tiny synthetic
data. This is the multi-tumor execution coverage the pure-Python lint can't give — it exercises
optional sources (OC/EC drop alphabet/provenge), the index-SOURCE shape (DLBCL indexes off
diagnosis), and the config-driven LOT line-setting.

Spark-only -> skips without pyspark (the pure-Python CI runner). Has been run locally on a real
Spark (pyspark in a venv); install pyspark to execute it, or it skips.
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))
sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))
PRODUCTS = FRAMEWORK.parent / "products"

# The synthetic frames and the local session live in ONE place, because they had two: a copy in
# `tools/smoke_prostate.py` that had already DIVERGED from this file, so the standalone demo built
# a different dataset than the one this suite proves.
import synthetic_sources                                                          # noqa: E402
_augment, _synth_src = synthetic_sources.augment, synthetic_sources.sources

try:
    from pyspark.sql import SparkSession
except Exception:
    SparkSession = None

# Stage modules are import-safe without pyspark OR pyyaml. engine.config needs pyyaml, so it is
# imported LAZILY inside the test — this file reaches the pyspark skip even when neither is present.
from engine.stages import (index as index_stage, demographics as dem_stage,         # noqa: E402
                           clinical as clin_stage, treatment as trt_stage,
                           outcomes as out_stage, assemble as asm_stage, lot as lot_stage)

try:
    import pytest
    pytestmark = pytest.mark.skipif(SparkSession is None, reason="pyspark not installed")
except Exception:
    pytest = None

GOOD = {"run.refresh": "v", "run.source_schema": "s", "run.output_schema": "o"}
_SPARK = None


def _spark():
    global _SPARK
    if _SPARK is None:
        _SPARK = synthetic_sources.session("smoke")
    return _SPARK


def _build_all_cohorts(cfg):
    from pyspark.sql import functions as F
    s = _spark()
    src = _synth_src(s, cfg)
    total = 0
    for cohort in cfg.cohorts:
        # treated derived PER COHORT off its line_setting (== build_ads.py), so the dual-setting mHSPC
        # path (treated/untreated mHSPC) is actually exercised, not just the global mCRPC setting.
        treated = (lot_stage.normalized(src, cohort.get("line_setting", cfg.lot_line_setting),
                                        exclude_settings=cfg.lot_exclude_settings,
                                        line_number_col=cfg.lot_line_number_col,
                                        maintenance_column=cfg.lot_maintenance_column)
                   .select("patientid").distinct().withColumn("treat_flag", F.lit(1)))
        idx = index_stage.build(src, cfg, cohort)
        dem = dem_stage.build(src, idx, cfg)
        clin = clin_stage.build(src, idx, cfg)
        trt = trt_stage.build(src, idx, cfg, cohort)
        out = out_stage.build(src, idx, clin, trt, cfg, cohort)
        ads = asm_stage.build(idx, dem, clin, trt, out, cfg, cohort, treated)
        assert "cohort" in ads.columns and "spec_version" in ads.columns
        n = ads.count()
        # EVERY configured cohort must carry ROWS, not merely build. An SIT found what
        # "builds without error" could not: OC/EC/DLBCL's maintenance and 2L+ cohorts and mCRC's
        # later lines all built structurally and were EMPTY on this fixture — zero row-level
        # coverage of the line-cohort code paths, and nothing said so. The fixture now mints one
        # patient per configured line cohort, so emptiness here is a real regression: either the
        # fixture stopped minting the patient, or an engine change stopped indexing them.
        assert n > 0, (f"{cfg.data_product_id} cohort {cohort.get('id') or cohort['cohortn']} "
                       f"built EMPTY on synthetic sources — the line-cohort path this cohort "
                       f"configures has no row-level coverage")
        total += n
    return total


def test_smoke_every_configured_tumor():
    if SparkSession is None:
        return
    from engine.config import load_yaml, load_config, product_config   # deferred: needs pyyaml
    configured, built, broken = [], [], []
    for t in load_yaml(PRODUCTS / "registry.yaml")["tumors"]:
        # A registry entry with no `current_spec_version` is a PLANNED product — nsclc, sclc, mcrc,
        # hnscc, gist and cll are all listed and none has a pack. `product_config` RAISES on those
        # rather than returning a path that does not exist, so a broken-config check here never got
        # the chance to run and the whole suite died on the first one. Skipping them here, by name,
        # keeps the reason legible instead of wrapping the call in a bare except. They are the ONLY
        # products this test may skip: everything the registry declares a spec version for is owed a
        # build below.
        if not t.get("current_spec_version"):
            continue
        slug = t["slug"]
        configured.append(slug)
        # A CONFIGURED product whose config is missing or unloadable is a FAILURE, never a skip. The
        # first version `continue`d past a missing config and asserted `>= 2` built — so a registry
        # entry could silently fall out of the only multi-tumour execution coverage there is, and the
        # suite would stay green on whichever two survived. Fail-closed: name every product that
        # cannot be built, and demand the built set EQUAL the configured set.
        cfg_path = product_config(PRODUCTS, slug)
        if not cfg_path.exists():
            broken.append(f"{slug}: no config at {cfg_path}")
            continue
        try:
            cfg = load_config(cfg_path, overrides=GOOD)
        except Exception as e:                                             # noqa: BLE001
            broken.append(f"{slug}: config failed to load — {e.__class__.__name__}: {e}")
            continue
        _build_all_cohorts(cfg)        # end-to-end build must not error for any tumor
        built.append(slug)
    assert not broken, (
        "registry-configured product(s) whose config cannot be loaded — a configured product that "
        "silently skips this smoke has NO multi-tumour execution coverage at all:\n  "
        + "\n  ".join(broken))
    assert built == configured, (
        f"built set != configured set: the registry configures {configured} and this run built "
        f"{built} — every product the registry declares a spec version for must build here")
    assert len(built) >= 2, f"registry no longer configures two tumours — got {built}"


def test_smoke_prostate_production_union_path():
    # Exercise the REAL production entrypoint (build_ads.build_from_sources -> per-cohort stages,
    # unionByName, derived cohorts) on synthetic prostate sources — not the per-cohort loop. Asserts the
    # 7-cohort dual-setting ADS unions and carries BOTH per-setting COHORTU labels.
    if SparkSession is None:
        return
    from engine.config import load_config, product_config
    from engine import build_ads
    cfg = load_config(product_config(PRODUCTS, "prostate"), overrides=GOOD)
    ads = build_ads.build_from_sources(_synth_src(_spark(), cfg), cfg)
    assert {"cohort", "cohortu", "spec_version"} <= set(ads.columns)
    us = {r["cohortu"] for r in ads.select("cohortu").distinct().collect() if r["cohortu"]}
    assert any("mHSPC" in u for u in us) and any("mCRPC" in u for u in us), us  # both settings present


def test_the_build_core_refuses_a_missing_required_column_itself():
    """SIT finding F2, closed at the source. The production path refuses a missing required column
    at preflight, and the stage helpers' `if col in columns` guards are belt-and-braces on top —
    but a caller of `build_from_sources` DIRECTLY (tests, notebooks, local smokes) used to get an
    ADS with the affected variables silently absent. The core now carries its own floor: it
    refuses before any Spark action, naming role.column. Both directions: the same frames WITH the
    column build (every other test in this file), and the refusal happens at call time — no
    half-built plan to clean up."""
    if SparkSession is None:
        return
    from engine.config import load_config, product_config
    from engine.validate import required_columns
    from engine import build_ads
    cfg = load_config(product_config(PRODUCTS, "oc"), overrides=GOOD)
    src = _synth_src(_spark(), cfg)
    role = cfg.index_source
    col = sorted(set(required_columns(cfg)[role]) - {"patientid"})[0]
    broken = dict(src)
    broken[role] = src[role].drop(col)
    try:
        build_ads.build_from_sources(broken, cfg)
    except ValueError as e:
        assert f"{role}.{col}" in str(e) and "BUILD REFUSED" in str(e), e
    else:
        raise AssertionError(f"dropping required {role}.{col} did not refuse the build")


if __name__ == "__main__":
    if SparkSession is None:
        print("SKIP: pyspark not installed — run on a Spark runtime.")
        sys.exit(0)
    test_smoke_every_configured_tumor()
    print("ok  test_smoke_every_configured_tumor")
    test_smoke_prostate_production_union_path()
    print("ok  test_smoke_prostate_production_union_path")
    test_the_build_core_refuses_a_missing_required_column_itself()
    print("ok  test_the_build_core_refuses_a_missing_required_column_itself")
