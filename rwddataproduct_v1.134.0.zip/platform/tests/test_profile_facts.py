"""The validation/rejection contract of the SHARED profile-facts reporter — platform code, so its
suite lives with the platform.

These checks are pack-independent: every one runs against a synthetic TSV and asserts what
`profile_facts.load` (which IS `profile_io.load`) accepts, refuses, and labels. They lived inside
the prostate pack's handoff tests first — the residency defect the audit named: archive that pack
and the platform silently loses its only profile_io-validation suite. The four checks that
genuinely need a pack's real config (CLI runs against configured table stems) stayed behind as the
pack's live smoke, in `products/.../handoff/tests/test_profile_facts.py`.

Run: python3 tests/test_profile_facts.py (or pytest).
"""
import importlib.util
import pathlib
import os
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
TOOLS = FRAMEWORK / "tools"
sys.path.insert(0, str(TOOLS))

import profile_io                                                            # noqa: E402

_spec = importlib.util.spec_from_file_location("profile_facts", str(TOOLS / "profile_facts.py"))
pf = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(pf)

COLS = ["table", "table_base", "column", "kind", "sampled", "n_rows", "n_rows_total",
        "pct_missing", "distinct", "date_min", "date_max", "top_values"]
assert COLS == list(profile_io.REQUIRED), "the restated header drifted from its owner"
HDR = "\t".join(COLS) + "\n"


def row(tbl, col, sampled="FALSE", nr="100", nt="100", pm="0.5", tv="10:a|5:b", kind="categorical"):
    # CUT lives in profile_io, which OWNS the snapshot-suffix definition.
    return "\t".join([tbl, profile_io.CUT.sub("", tbl), col, kind, sampled, nr, nt, pm,
                      "3", "", "", tv]) + "\n"


def test_the_cut_suffix_defaults_agree_across_the_two_engines():
    """profile_io.CUT (the Python reader) and data_profiler.R's default cut_regex (the R writer)
    are two spellings of one rule — the exact drift profile_io's own docstring says it exists to
    end, continued across the language boundary. The mechanisms stay separate (the R default is
    per-product overridable), so this pins the DEFAULTS against a shared family list."""
    import re as _re
    r_src = (pathlib.Path(__file__).resolve().parent.parent / "tools"
             / "data_profiler.R").read_text(encoding="utf-8")
    m = _re.search(r'cut_regex\s+=\s+"([^"]+)"', r_src)
    assert m, "data_profiler.R lost its default cut_regex"
    r_cut = _re.compile(m.group(1).replace("\\\\", "\\"))
    for name, is_cut in (("t_x_2026m06", True), ("t_x_2026q1", True), ("t_x_202606", True),
                         ("t_x_2026", True), ("t_x_final", False), ("t_x", False)):
        assert bool(profile_io.CUT.search(name)) == is_cut, (name, "python")
        assert bool(r_cut.search(name)) == is_cut, (name, "r")


def tmp_tsv(body, header=HDR):
    p = os.path.join(tempfile.mkdtemp(), "profile_2026m06.tsv")
    open(p, "w", encoding="utf-8").write(header + body)
    return p


def _refuses(fn):
    try:
        fn()
        return False
    except SystemExit:
        return True


def test_load_ok_and_cut_detection():
    tables, cuts = pf.load(tmp_tsv(row("t_x_2026m06", "c1")))
    assert "t_x" in tables and cuts == {"2026m06"}


def test_missing_identity_column_rejected():
    hdr = HDR.replace("\ttable_base", "")
    assert _refuses(lambda: pf.load(tmp_tsv(
        "t_x_2026m06\tc\tcategorical\tFALSE\t1\t1\t0\t1\t\t\t\n", hdr)))


def test_missing_required_column_rejected():
    hdr = HDR.replace("\tsampled", "")
    assert _refuses(lambda: pf.load(tmp_tsv(
        "t_x_2026m06\tt_x\tc\tcategorical\t1\t1\t0\t1\t\t\t\n", hdr)))


def test_non_boolean_sampled_rejected():
    assert _refuses(lambda: pf.load(tmp_tsv(row("t_x_2026m06", "c", sampled="MAYBE"))))


def test_non_numeric_n_rows_rejected():
    assert _refuses(lambda: pf.load(tmp_tsv(row("t_x_2026m06", "c", nr="abc"))))


def test_n_rows_over_total_rejected():
    assert _refuses(lambda: pf.load(tmp_tsv(row("t_x_2026m06", "c", nr="200", nt="100"))))


def test_pct_missing_out_of_range_rejected():
    assert _refuses(lambda: pf.load(tmp_tsv(row("t_x_2026m06", "c", pm="150"))))


def test_zero_row_table_with_blank_pct_missing_loads():
    tables, _ = pf.load(tmp_tsv(row("t_x_2026m06", "c", nr="0", nt="0", pm="")))  # profiler NA -> ""
    assert "t_x" in tables


def test_nan_and_inf_counts_rejected():
    assert _refuses(lambda: pf.load(tmp_tsv(row("t_x_2026m06", "c", nr="nan"))))
    assert _refuses(lambda: pf.load(tmp_tsv(row("t_x_2026m06", "c", nt="inf"))))


def test_non_integer_n_rows_rejected():
    assert _refuses(lambda: pf.load(tmp_tsv(row("t_x_2026m06", "c", nr="12.5"))))


def test_duplicate_table_column_rejected():
    assert _refuses(lambda: pf.load(tmp_tsv(row("t_x_2026m06", "c1") + row("t_x_2026m06", "c1"))))


def test_empty_profile_rejected():
    assert _refuses(lambda: pf.load(tmp_tsv("")))


def test_coverage_exact_when_not_sampled():
    tables, _ = pf.load(tmp_tsv(row("t_x_2026m06", "c", sampled="FALSE")))
    assert pf.sampling_status(tables).startswith("EXACT")


def test_coverage_sampled_via_flag():
    tables, _ = pf.load(tmp_tsv(row("t_x_2026m06", "c", sampled="TRUE")))
    assert pf.sampling_status(tables).startswith("SAMPLED")


def test_coverage_sampled_via_count_mismatch():
    tables, _ = pf.load(tmp_tsv(row("t_x_2026m06", "c", sampled="FALSE", nr="50", nt="100")))
    assert pf.sampling_status(tables).startswith("SAMPLED")


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
