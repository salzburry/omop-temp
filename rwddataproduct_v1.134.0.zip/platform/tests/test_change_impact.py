"""One spec row moved — what is now unverified?

A revised workbook moves eleven rows. The records get re-drafted, the lint is clean, the artifacts
regenerate, and the pack ships — while a golden case citing one of those rows was never re-run.
The chain from "a row moved" to "these things are unverified" exists in five separate files and
nothing has ever walked it in one direction.

Four properties keep the walk honest:

  * A ROW NOTHING CITES IS A FINDING. It means either unimplemented or a missing citation, and both
    look exactly like "no impact" in a report that prints nothing.
  * RANGES EXPAND. A family record citing `clinical:70-77` covers `clinical:71`; keying on the
    literal string would drop the record from the impact set.
  * EVERY LINK IS READ FROM THE THING ITSELF. The records from contract_lint, the governed blocks
    from contract_binding, the capabilities from the registry. A private walk would shrink the
    impact set silently, and that is the one direction this must never be wrong in.
  * IT WRITES NOTHING.

Run: python3 platform/tests/test_change_impact.py  (or pytest). No Spark.
"""
import ast
import os
import shutil
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
TOOLS = FRAMEWORK / "tools"
REPO = FRAMEWORK.parent
sys.path.insert(0, str(TOOLS))

import change_impact as ci        # noqa: E402
import contract_binding as cb     # noqa: E402

PACK = "products/oncology/prostate/202606"


def test_it_writes_nothing():
    """A report that can write is one that can be pointed at its own conclusion."""
    tree = ast.parse((TOOLS / "change_impact.py").read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = getattr(node.func, "id", "") or getattr(node.func, "attr", "")
        assert name not in ("safe_dump", "dump", "mkdir", "makedirs", "write_text", "writelines",
                            "remove", "rename", "rmtree"), f"{name}() in a read-only report"
        if name == "open":
            mode = ""
            if len(node.args) > 1 and isinstance(node.args[1], ast.Constant):
                mode = str(node.args[1].value)
            assert not (set(mode) & set("wax+")), f"open(mode={mode!r}) writes"


def test_the_chain_resolves_end_to_end_on_a_live_pack():
    """record -> config block -> capability -> published column, for a row that has all four. If
    this ever comes back empty the walk has stopped reading the pack."""
    d = ci.impact(PACK, ["clinical:2"])
    assert [r["variable_id"] for r in d["records"]] == ["MCRPCDD"], d["records"]
    assert d["blocks"] == ["variables/clinical.yaml#/mcrpc_window"], d["blocks"]
    assert d["output_columns"] == ["mcrpcdd"], d["output_columns"]
    assert d["capabilities"], "no capability matched a changed clinical config file"
    assert d["capability_note"] is None, d["capability_note"]
    assert not d["rows_no_record_cites"]


def test_a_row_no_record_cites_is_reported_as_a_finding():
    """The case that must not print as a clean report. `clinical:99999` cannot be implemented."""
    d = ci.impact(PACK, ["clinical:99999"])
    assert d["rows_no_record_cites"] == ["clinical:99999"], d
    text = ci.render(PACK, ["clinical:99999"])
    assert "NO contract record cites this row" in text
    assert "neither is 'no impact'" in text


def test_a_range_citation_is_expanded_not_matched_literally():
    """A family record citing `clinical:70-77` covers clinical:71. Keying on the literal string
    would drop it from the impact set — the silent-shrink direction."""
    assert "clinical:71" in ci._rows_for("clinical:70-77")
    assert ci._rows_for("clinical:12") == {"clinical:12"}
    # ...and it is the BINDER's expander, not a second one written here.
    assert ci._rows_for.__doc__ and "spec_ref_rows" in ci._rows_for.__doc__
    assert set(ci._rows_for("clinical:70-77")) == {f"clinical:{n}" for n in range(70, 78)}


def test_the_governed_block_set_comes_from_the_binder():
    """A block a record names that the BUILD does not read is a separate defect, surfaced rather
    than folded into the impact set."""
    d = ci.impact(PACK, ["clinical:2"])
    governed = set(cb.governed_blocks(os.path.join(str(REPO), PACK),
                                      cb.pack_yaml(os.path.join(str(REPO), PACK))))
    assert d["blocks"][0] in governed, "the live example is not governed — test would be vacuous"
    assert d["blocks_not_governed"] == []


def test_a_golden_citing_a_changed_row_is_named_for_rerun():
    """A golden states an EXPECTED clinical value, so a moved row it cites may have invalidated the
    expectation. Asserted on a synthetic fixture rather than on whatever the repo happens to hold,
    so a change to the real goldens cannot make this vacuous."""
    d = Path(tempfile.mkdtemp())
    try:
        fx = d / "platform" / "tests" / "fixtures"
        fx.mkdir(parents=True)
        (fx / "x_goldens.yaml").write_text(
            "goldens:\n"
            "  - id: gx01\n    spec_ref: clinical:2\n    expect: 3\n"
            "  - id: gx02\n    spec_ref: clinical:900\n    expect: 4\n", encoding="utf-8")
        saved, ci.REPO = ci.REPO, str(d)
        try:
            hits = ci.goldens_citing(["clinical:2"])
        finally:
            ci.REPO = saved
        assert list(hits.values()) == [["gx01"]], hits
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_no_golden_citing_the_row_is_not_reported_as_reassurance():
    """"Nothing to re-run" and "nothing tests this" are different facts."""
    text = ci.render(PACK, ["clinical:2"])
    if "No golden case cites these rows" in text:
        assert "untested rather than unaffected" in text


def test_capabilities_are_matched_wider_than_the_blocks_on_purpose():
    """`config_keys` name a file and section, not a JSON pointer, so the match is per FILE. For a
    "what must be re-checked" report over-inclusion is the safe direction, and the report says so
    rather than leaving a reader to assume precision it does not have."""
    caps, note = ci.capabilities_for(["variables/clinical.yaml#/mcrpc_window"])
    assert note is None and caps
    assert all(k.split(".", 1)[0] == "clinical" for keys in caps.values() for k in keys), caps
    assert "wider than the block list" in ci.render(PACK, ["clinical:2"])


def test_an_unreadable_registry_reports_not_determined_rather_than_zero():
    """A capability count of 0 because nothing matched, and 0 because the registry could not be
    read, are different answers. The second must never print as the first."""
    import capability_registry as cr
    saved = cr.load
    try:
        cr.load = lambda: (_ for _ in ()).throw(RuntimeError("boom"))
        caps, note = ci.capabilities_for(["variables/clinical.yaml#/x"])
        assert caps == {} and note, (caps, note)
    finally:
        cr.load = saved


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
