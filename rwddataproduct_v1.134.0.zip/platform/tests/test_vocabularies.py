"""The coding-system registry, and the two claims that make it worth having.

`engine/vocabularies.py` exists because every matching operator in this engine was written against
curated TEXT. Point a pack at a feed whose drug column is NDC and `like_any: ["%bevacizumab%"]`
matches nothing: valid SQL, plausible config, every patient in the catch-all category, no error.
The registry is what lets a pack DECLARE the difference so a gate can refuse it.

Two properties are load-bearing and pinned here:

  * the registry means the same thing under both engines — a code set is authored once and read by
    the PySpark and R builds, so `normalise` disagreeing between them is a silent wrong answer, not
    a style difference;
  * the checks say what they do NOT prove. `code_errors` is a SHAPE check; `C99.9` is shaped like
    ICD-10-CM and is not a code. A test suite that let that read as membership would be endorsing
    the overclaim.

Run: python3 tests/test_vocabularies.py (or pytest).
"""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))

from engine import vocabularies as v   # noqa: E402

RSCRIPT = shutil.which("Rscript")
R_VOCAB = FRAMEWORK / "engine-r" / "vocabularies.R"

# Hostile on purpose: punctuation the strip removes, punctuation it must not, case, whitespace,
# empties, and the NDC pair the module explicitly declines to reconcile.
CASES = [
    ("icd10cm", "C18.9"), ("icd10cm", " c18.9 "), ("icd10cm", "C189"), ("icd10cm", "c1.8.9"),
    ("icd9cm", "153.9"), ("icdo3", "8140/3"), ("icdo3", "C18.9"),
    ("ndc", "0069-0187-01"), ("ndc", "00690018701"), ("ndc", "--"),
    ("atc", "L01XC02"), ("loinc", "2160-0"), ("rxnorm", "3002"), ("snomed", "73211009"),
    ("hcpcs", "J9035"), ("cpt", "96413"),
    ("text", "Bevacizumab"), ("text", ""), ("text", "  spaced  "), ("text", "FOLFOX/BEV"),
]


def test_text_is_a_declaration_and_absence_is_not():
    """The distinction the whole design rests on: `text` is an ANSWER; blank is not."""
    assert v.known(v.TEXT) and not v.is_coded(v.TEXT)
    assert v.system_errors(v.TEXT) == []
    for absent in ("", None, "   "):
        assert v.system_errors(absent), f"{absent!r} was accepted as a declaration"
        assert not v.is_coded(absent)
    # an unknown system is refused with the valid ones listed, never absorbed
    bad = v.system_errors("icd11")
    assert bad and "icd10cm" in bad[0], bad
    assert not v.is_coded("icd11"), "an unknown system must not read as coded either"
    assert set(v.CODED) == set(v.SYSTEMS) - {v.TEXT}


def test_a_prefix_is_refused_where_it_is_not_a_generalisation():
    """`C18` is every colon neoplasm. An RxNorm 'prefix' is codes sharing leading digits."""
    for system in ("icd10cm", "icd9cm", "icdo3", "atc"):
        assert v.prefix_errors(system) == [], system
    for system in ("rxnorm", "snomed", "ndc", "loinc", "cpt", "hcpcs"):
        why = v.prefix_errors(system)
        assert why and "hierarchical" in why[0], (system, why)
    assert v.prefix_errors("nonsense"), "an unknown system must not be prefix-matchable"


def test_the_shape_check_is_a_shape_check():
    assert v.code_errors("icd10cm", "C18.9") == []
    assert v.code_errors("loinc", "bevacizumab"), "a drug name passed as a LOINC code"
    assert v.code_errors("icd10cm", "") , "an empty code was accepted"
    # ...and the overclaim it must NOT make: a well-shaped code that no release contains
    assert v.code_errors("icd10cm", "C99.9") == [], \
        "the shape check started asserting membership — that is a codeset's job, and this test " \
        "exists so the docstring's limit stays true"
    # text declares no shape, so any abstracted value is legitimate
    assert v.code_errors("text", "FOLFOX + bevacizumab") == []


def test_ndc_ten_and_eleven_digit_forms_are_not_silently_reconciled():
    """The module says character-stripping is not enough here. If that ever stops being true the
    claim in the docstring is wrong, and a code set written in one form would half-match a feed
    written in the other — the exact silent miss this registry exists to prevent."""
    assert v.normalise("ndc", "0069-0187-01") != v.normalise("ndc", "00690018701")


def test_the_r_mirror_agrees_character_for_character():
    """A code set is authored once and read by both engines. Divergence here is a wrong answer."""
    if not RSCRIPT:
        import pytest
        pytest.skip("Rscript not on PATH")
    lines = ["source(%r)" % str(R_VOCAB)]
    for system, code in CASES:
        lines.append(f'cat(sprintf("%s|%s\\n", {system!r}, normalise({system!r}, {code!r})))')
    for system in v.SYSTEMS:
        lines.append(f'cat(sprintf("H|%s|%s|%s\\n", {system!r}, hierarchical({system!r}), '
                     f'strip_chars({system!r})))')
    lines.append('cat(sprintf("SYSTEMS|%s\\n", paste(SYSTEMS, collapse=",")))')
    lines.append('cat(sprintf("CODED|%s\\n", paste(CODED, collapse=",")))')

    with tempfile.TemporaryDirectory() as tmp:
        script = Path(tmp, "parity.R")
        script.write_text("\n".join(lines), encoding="utf-8")
        # encoding="utf-8" beside text=True: the child emits utf-8, and `text=True` alone decodes
        # with the machine's code page — cp1252 under a Windows CI runner, where a stripped
        # character or a code carrying a non-ASCII byte would arrive as mojibake or raise.
        out = subprocess.run([RSCRIPT, str(script)], capture_output=True, text=True,
                             encoding="utf-8", check=True)

    want = [f"{s}|{v.normalise(s, c)}" for s, c in CASES]
    want += [f"H|{s}|{'TRUE' if v.hierarchical(s) else 'FALSE'}|{v.strip_chars(s)}"
             for s in v.SYSTEMS]
    want.append("SYSTEMS|" + ",".join(v.SYSTEMS))
    want.append("CODED|" + ",".join(v.CODED))
    got = out.stdout.splitlines()
    assert got == want, ("R and Python disagree about the coding-system registry:\n"
                         + "\n".join(f"  R={g!r}  py={w!r}" for g, w in zip(got, want) if g != w))


def test_the_two_registries_declare_the_same_systems():
    """Not just the same answers on the cases above — the same MEMBERSHIP, so a system added on one
    side and forgotten on the other is caught rather than waiting for a case to exercise it."""
    if not RSCRIPT:
        import pytest
        pytest.skip("Rscript not on PATH")
    r_src = R_VOCAB.read_text(encoding="utf-8")
    for system in v.SYSTEMS:
        assert f"{system} " in r_src or f"{system}=" in r_src or f"  {system}" in r_src, \
            f"{system} is declared in Python and missing from the R mirror"


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
