"""Stage telemetry must count exactly, cost nothing by default, and never become a verdict.

The three properties, each with its failure mode named:

  * EXACT COUNTS. A telemetry block that miscounts is worse than none — its numbers travel into a
    manifest people read. Proved on a hand-built expansion (one patient fanning out, one index
    patient dropped, one stray patient outside the index) where every number is checkable by eye.
  * COUNTS ONLY. No patient id may appear anywhere in the serialised report — the same rule
    grain.py and the profiler hold, for the same reason: this block travels into manifests and
    chat.
  * EVIDENCE, NOT A VERDICT. The report carries no `passed` key and `stage_telemetry` must never
    join refresh.CANDIDATE_VERDICTS — expansion and loss are design questions until a pack states
    a reviewed bound, and a threshold invented by telemetry is one nobody approved.

Run: python3 platform/tests/test_telemetry.py (or pytest). Spark parts skip without pyspark; the
verdict-shape pin runs regardless.
"""
import json
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))

from engine import telemetry, refresh                            # noqa: E402

try:
    from pyspark.sql import SparkSession
except Exception:
    SparkSession = None

try:
    import pytest
except Exception:
    pytest = None

_SPARK = None


def _spark():
    """The SHARED session (same discipline as test_grain: a second builder would hand its settings
    to every later Spark suite through getOrCreate)."""
    global _SPARK
    if _SPARK is None:
        sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))
        import synthetic_sources
        _SPARK = synthetic_sources.session("telemetry")
    return _SPARK


def _F():
    from pyspark.sql import functions as F
    return F


def _skip_without_spark():
    if SparkSession is None:
        if pytest is not None and "pytest" in sys.modules:
            pytest.skip("pyspark not installed")
        print("SKIP (pyspark absent)")
        return True
    return False


def test_the_counts_are_exact_on_a_known_expansion():
    """idx = {p1, p2}; stage emits p1 three times, nothing for p2, and p3 whom the index does not
    know. Every reported number is checkable by eye — and no patient id survives serialisation."""
    if _skip_without_spark():
        return
    spark = _spark()
    idx = spark.createDataFrame([("p1", "2020-01-01"), ("p2", "2020-01-01")],
                                "patientid string, index_date string")
    stage = spark.createDataFrame([("p1", 1), ("p1", 2), ("p1", 3), ("p3", 4)],
                                  "patientid string, v int")
    t = telemetry.StageTelemetry()
    t.record(_F(), idx, stage, "c1", "clinical")
    rep = t.report()
    assert rep["stages"] == [{
        "cohort": "c1", "stage": "clinical",
        "index_patients": 2, "matched_patients": 1, "unmatched_index_patients": 1,
        "patients_outside_index": 1, "rows_out": 4, "max_rows_per_index_patient": 3,
    }], rep["stages"]
    flat = json.dumps(rep)
    assert "p1" not in flat and "p2" not in flat and "p3" not in flat, \
        "a patient id reached a report that travels into manifests and chat"


def test_a_clean_stage_raises_no_observation_and_a_dirty_one_names_both():
    """Both directions. A 1:1 stage must be silent — an observation that fires on every clean run
    is a finding everyone learns to ignore. The dirty stage must name loss AND leakage in words."""
    if _skip_without_spark():
        return
    spark = _spark()
    idx = spark.createDataFrame([("p1",), ("p2",)], "patientid string")
    clean = spark.createDataFrame([("p1", 1), ("p2", 1)], "patientid string, v int")
    dirty = spark.createDataFrame([("p1", 1), ("p9", 1)], "patientid string, v int")
    t = telemetry.StageTelemetry()
    t.record(_F(), idx, clean, "c1", "demographics")
    t.record(_F(), idx, dirty, "c1", "outcomes")
    rep = t.report()
    obs = rep["observations"]
    assert not any("demographics" in o for o in obs), obs
    assert any("outcomes" in o and "NO row" in o for o in obs), obs
    assert any("outcomes" in o and "index does not carry" in o for o in obs), obs
    # recording order is the report order — stamped in the rows, not inherited from Spark
    assert [r["stage"] for r in rep["stages"]] == ["demographics", "outcomes"]


def test_an_unmeasurable_frame_is_skipped_and_said():
    """The three-answer rule: a frame with no patientid is SKIPPED AND NAMED — silently absent
    would read as 'measured, nothing notable'. And recording after report() refuses instead of
    silently dropping the late stage."""
    if _skip_without_spark():
        return
    spark = _spark()
    idx = spark.createDataFrame([("p1",)], "patientid string")
    nameless = spark.createDataFrame([(1,)], "v int")
    t = telemetry.StageTelemetry()
    t.record(_F(), idx, nameless, "c1", "proc")
    rep = t.report()
    assert rep["stages"] == [] and rep["skipped"] == ["c1/proc: no patientid column to join on"], rep
    try:
        t.record(_F(), idx, idx, "c1", "late")
    except RuntimeError as e:
        assert "already reported" in str(e)
    else:
        raise AssertionError("recording after report() did not refuse")


def test_the_report_is_evidence_and_can_never_be_read_as_a_verdict():
    """Pure, runs without Spark. `passed` absent from the report shape, and stage_telemetry pinned
    OUT of CANDIDATE_VERDICTS — adding it there would make un-thresholded numbers gate a release."""
    rep = telemetry.StageTelemetry().report()
    assert "passed" not in rep, rep
    assert set(rep) == {"stages", "selections", "skipped", "observations"}, rep
    assert "stage_telemetry" not in [k for k, _, _ in refresh.CANDIDATE_VERDICTS], \
        "stage telemetry became a verdict — no one approved a threshold for it"


def test_selection_counts_are_exact_and_candidate_and_output_metrics_merge():
    """One item, hand-countable: three candidates for p1, two of them tied on one date; the block
    then emits a value for p1 and a null for p2. The report must carry ONE row for the item with
    all six numbers — a reader should never have to join two lists to see one selection."""
    if _skip_without_spark():
        return
    spark = _spark()
    rows = spark.createDataFrame(
        [("p1", "2020-01-01", "2019-12-20", "Positive"),
         ("p1", "2020-01-01", "2019-12-20", "Negative"),      # same-date tie
         ("p1", "2020-01-01", "2019-11-01", "Positive")],
        "patientid string, index_date string, biomarkerdate string, status string")
    out = spark.createDataFrame([("p1", "2020-01-01", "Positive"), ("p2", "2020-01-01", None)],
                                "patientid string, index_date string, her2 string")
    t = telemetry.StageTelemetry()
    t.record_selection(_F(), rows, ("patientid", "index_date"), "biomarkerdate",
                       "c1", "biomarkers", "her2")
    t.record_selection_outputs(_F(), out, [("her2", "her2")], "c1", "biomarkers")
    rep = t.report()
    assert rep["selections"] == [{
        "cohort": "c1", "block": "biomarkers", "item": "her2",
        "candidate_rows": 3, "patients_with_candidates": 1,
        "tied_same_date_keys": 1, "tied_rows": 2,
        "non_null_outputs": 1, "output_rows": 2,
    }], rep["selections"]
    assert any("same-date tie" in o for o in rep["observations"]), rep["observations"]
    flat = json.dumps(rep)
    assert "p1" not in flat and "p2" not in flat, "a patient id reached the selection report"


def test_a_name_that_matches_nothing_is_named_and_a_clean_item_is_silent():
    """Both directions of the observation the selection telemetry exists for: zero candidates =
    the emitted column is all-missing and the report says so in words; an untied, matching item
    raises nothing (an observation firing on every clean run teaches people to skim)."""
    if _skip_without_spark():
        return
    spark = _spark()
    schema = "patientid string, index_date string, d string"
    none = spark.createDataFrame([], schema)
    clean = spark.createDataFrame([("p1", "2020-01-01", "2019-12-20")], schema)
    t = telemetry.StageTelemetry()
    t.record_selection(_F(), none, ("patientid", "index_date"), "d", "c1", "biomarkers", "folr1")
    t.record_selection(_F(), clean, ("patientid", "index_date"), "d", "c1", "biomarkers", "brca")
    rep = t.report()
    by_item = {s["item"]: s for s in rep["selections"]}
    assert by_item["folr1"]["candidate_rows"] == 0
    assert any("folr1" in o and "all-missing" in o for o in rep["observations"]), rep["observations"]
    assert not any("brca" in o for o in rep["observations"]), rep["observations"]


def test_a_dateless_pick_counts_key_multiplicity_as_ties():
    """A per-patient categorical with no date column has nothing but the value order to decide
    between rows — so a patient with two candidates IS a tie, and the collector must say so
    without a date to group on."""
    if _skip_without_spark():
        return
    spark = _spark()
    rows = spark.createDataFrame([("p1", "IIIA"), ("p1", "IV"), ("p2", "II")],
                                 "patientid string, groupstage string")
    t = telemetry.StageTelemetry()
    t.record_selection(_F(), rows, ("patientid",), None, "c1", "staging", "stage")
    s = t.report()["selections"]
    assert s == [{"cohort": "c1", "block": "staging", "item": "stage",
                  "candidate_rows": 3, "patients_with_candidates": 2,
                  "tied_same_date_keys": 1, "tied_rows": 2}], s


def test_the_psa_helper_records_per_point_and_its_output_is_unchanged():
    """The prostate-only family, proven at the helper (no pack builds it in this suite): one plan
    per configured point on the point's own windowed rows, one outputs plan for all points — and
    the emitted frame is row-identical with the collector attached."""
    if _skip_without_spark():
        return
    from pyspark.sql import Window
    from engine.stages import clinical
    spark = _spark()
    idx = spark.createDataFrame([("p1", "2020-01-01"), ("p2", "2020-01-01")],
                                "patientid string, index_date string")
    src = spark.createDataFrame(
        [("p1", "4.2", "2020-01-03"), ("p1", "3.1", "2020-01-05"), ("p2", "x", "2020-01-02")],
        "patientid string, psavalue string, psadate string")   # p2's value fails the cast -> no candidate
    blk = {"value_column": "psavalue", "date_column": "psadate",
           "points": [{"name": "psabl", "window_days": [-30, 30]}]}
    F = _F()
    t = telemetry.StageTelemetry()
    with_t = clinical._psa_timepoints(F, Window, src, blk, idx, telemetry=t, cohort="c1")
    without = clinical._psa_timepoints(F, Window, src, blk, idx)
    assert sorted(map(tuple, with_t.collect())) == sorted(map(tuple, without.collect())), \
        "attaching telemetry changed the PSA frame"
    s = t.report()["selections"]
    assert [(r["block"], r["item"]) for r in s] == [("psa_timepoints", "psabl")], s
    assert s[0]["candidate_rows"] == 2 and s[0]["patients_with_candidates"] == 1, s
    assert s[0]["non_null_outputs"] == 1 and s[0]["output_rows"] == 2, s


def test_the_panel_helper_records_in_place_and_its_output_is_unchanged():
    """The wiring, at the helper that owns the pick. Instrumented IN _closest_panel, not re-derived
    beside it — so this asserts the telemetry saw the helper's own candidate frame (the tie it
    reports is the tie the pick resolved) AND that the emitted panel is row-identical with the
    collector attached."""
    if _skip_without_spark():
        return
    from pyspark.sql import Window
    from engine.stages import clinical
    spark = _spark()
    idx = spark.createDataFrame([("p1", "2020-01-01"), ("p2", "2020-01-01")],
                                "patientid string, index_date string")
    src = spark.createDataFrame(
        [("p1", "HER2", "Positive", "2019-12-20"),
         ("p1", "HER2", "Negative", "2019-12-20"),     # same-date tie, resolved by rule
         ("p2", "FISH", "Positive", "2019-12-20")],    # wrong name: no candidate for p2
        "patientid string, biomarkername string, biomarkerstatus string, biomarkerdate string")
    blk = {"name_column": "biomarkername", "value_column": "biomarkerstatus",
           "date_column": "biomarkerdate", "window_days": [None, 14],
           "panel": [{"name": "her2", "match": "HER2",
                      "groups": [{"code": 1, "label": "Positive", "from_equals_ci": ["Positive"]},
                                 {"code": 2, "label": "Negative", "from_equals_ci": ["Negative"]},
                                 {"code": 3, "label": "Unknown", "when": "fallthrough"}]}]}
    F = _F()
    t = telemetry.StageTelemetry()
    with_t = clinical._closest_panel(F, Window, src, blk, idx,
                                     telemetry=t, cohort="c1", label="biomarkers")
    without = clinical._closest_panel(F, Window, src, blk, idx)
    key = lambda r: (r["patientid"], r["index_date"])                       # noqa: E731
    assert sorted(map(tuple, with_t.collect()), key=lambda x: x[0]) == \
        sorted(map(tuple, without.collect()), key=lambda x: x[0]), \
        "attaching telemetry changed the panel's emitted rows"
    s = t.report()["selections"]
    assert [(r["block"], r["item"]) for r in s] == [("biomarkers", "her2")], s
    assert s[0]["candidate_rows"] == 2 and s[0]["tied_same_date_keys"] == 1, s
    assert s[0]["non_null_outputs"] == 1 and s[0]["output_rows"] == 2, s


def test_the_build_records_every_stage_of_every_cohort_and_changes_nothing():
    """Integration on a real pack (OC) through the production entry point: six frames per cohort in
    build order, and the ADS out of a telemetered build is the ADS — same columns, same rows."""
    if _skip_without_spark():
        return
    sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))
    import synthetic_sources
    from engine import build_ads
    from engine.config import load_config, product_config
    overrides = {"run.refresh": "t", "run.source_schema": "t", "run.output_schema": "t"}
    cfg = load_config(product_config(FRAMEWORK.parent / "products", "oc"), overrides=overrides)
    src = synthetic_sources.sources(_spark(), cfg)
    t = telemetry.StageTelemetry()
    ads = build_ads.build_from_sources(src, cfg, telemetry=t)
    rep = t.report()
    stages = ("index", "demographics", "clinical", "treatment", "outcomes", "cohort_ads")
    expected = [(c["id"], s) for c in cfg.cohorts for s in stages]
    assert [(r["cohort"], r["stage"]) for r in rep["stages"]] == expected, \
        "a stage boundary fell out of telemetry, or order no longer follows the build"
    # the SELECTION layer rode the same build: every cohort carries OC's biomarker panel items in
    # config order, each row already holding BOTH candidate and output metrics (merged, not two
    # half-rows a reader has to join)
    panel = [i["name"] for i in cfg.pack("clinical")["biomarkers"]["panel"]]
    for c in cfg.cohorts:
        got = [s["item"] for s in rep["selections"]
               if s["cohort"] == c["id"] and s["block"] == "biomarkers"]
        assert got == panel, (c["id"], got, panel)
    # ... and so did the OTHER instrumented families this pack configures. This set is the claim
    # "every pick family reports"; a family silently falling out of telemetry fails here.
    blocks = {s["block"] for s in rep["selections"]}
    assert {"biomarkers", "labs", "staging", "categoricals", "baseline_ecog", "vitals",
            "treatment_lines"} <= blocks, blocks
    assert all("candidate_rows" in s or "non_null_outputs" in s for s in rep["selections"]), \
        rep["selections"][:2]
    # NO plain rebuild here. The changes-nothing property is held where it is cheap: the panel
    # helper test compares collected rows with and without a collector, and record() returns None
    # so build code cannot consume a telemetry value. Rebuilding the whole OC union a second time
    # just to re-prove it pushed the shared 3g sweep driver into OutOfMemoryError late in the run
    # (sweep41) — a full extra build for a property two other tests already pin.
    # every cohort_ads row-count in the report equals the frame the union actually took
    per_cohort = {r["cohort"]: r["rows_out"] for r in rep["stages"] if r["stage"] == "cohort_ads"}
    from pyspark.sql import functions as F
    # derived cohorts (OC PROC) duplicate rows AFTER the loop, so compare pre-derived cohorts only
    base = {c["id"]: c["cohortn"] for c in cfg.cohorts}
    got = {n: c for n, c in ((r["cohortn"], r["n"]) for r in
           ads.groupBy("cohortn").agg(F.count(F.lit(1)).alias("n")).collect())}
    for cid, n in base.items():
        assert per_cohort[cid] == got.get(n, 0), \
            (cid, per_cohort[cid], got.get(n, 0), "telemetry disagrees with the built ADS")


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
