"""The mCRC golden matrix: enforce its SHAPE now, its clinical answers only once they exist.

WHY A TEST OVER AN EMPTY FIXTURE IS NOT A GREEN STEP PROTECTING NOTHING. Two different things live
in `fixtures/mcrc_goldens.yaml`, and only one of them needs a workbook:

  * THE CASE MATRIX — that every way an mCRC build goes wrong while looking plausible has a case,
    that the boundary pair really straddles one line, that the same-date pair really collides, that
    ids are distinct. All of that is checkable today and is checked here, hard.
  * THE EXPECTED OUTPUTS — what the specification requires for each case. Those need the approved
    workbook, and mCRC has none. They stay `REPLACE_ME`, and this file asserts they are STILL
    unfilled rather than pretending otherwise.

That last assertion is the load-bearing one, and it is written to fail LOUDLY the day somebody
fills the matrix in — because on that day the clinical assertions below must start running, and a
test that quietly kept passing over filled-in goldens would be the worst outcome available: a
green suite over expectations nobody ever executed.

NO AI MAY FILL THESE IN. An expectation is a claim about what an approved specification requires;
computing one from the config would test the engine against a guess and report it as a clinical
golden. `test_no_expectation_was_derived_from_the_config` is the guard, not the honour system.

Run: python3 platform/tests/test_mcrc_goldens.py  (or pytest). Needs no PySpark: nothing here
executes a build, because there is nothing approved to build.
"""
import os
import re
import sys
from datetime import date
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))

import yaml  # noqa: E402

MATRIX = FRAMEWORK / "tests" / "fixtures" / "mcrc_goldens.yaml"
MARK = "REPLACE_ME"
FILLABLE = ("working", "spec_ref", "expect")


def _load():
    return yaml.safe_load(MATRIX.read_text(encoding="utf-8"))


def test_the_line_attribution_case_is_recorded_as_an_engine_gap_and_the_gap_is_real():
    """mg10 CANNOT be answered by filling YAML, and the matrix has to say so.

    An external review named this: "the current LOT capability normalizes a vendor-provided LOT
    table; it does not construct treatment lines from raw drug episodes. If the workbook requires
    FOLFOX/bevacizumab → bevacizumab maintenance → FOLFIRI attribution, that is an engine gap, not
    a YAML-generation task."

    Verified rather than repeated. `lot.normalized` reads `src["lot"]` — the vendor's own line
    table — filters it and row-numbers what survives, so every line boundary was decided before the
    engine saw the data. `treatment.py` does read `drug_episode`, but only to aggregate drugs onto
    lines that already exist. Episodes decorate lines; they never define them.

    The risk this guards is specific and expensive: mg10 looks like a config question, so a
    drafting session could spend a day on `variables/treatment.yaml` and produce something that
    lints, composes, and cannot possibly implement a maintenance rule.

    THE TRIPWIRE'S LIMIT, stated because a check whose reach is unclear gets over-trusted: it
    detects the gap CLOSING only if the capability is built inside `lot.py`. A new module that
    derived lines elsewhere would not trip it. What it does guarantee is that the recorded finding
    cannot silently become false where it was measured.
    """
    d = _load()
    gaps = d.get("engine_gaps") or {}
    gap = gaps.get("line_construction_from_drug_episodes")
    assert gap, f"the line-attribution engine gap is not recorded: {sorted(gaps)}"
    assert "mg10" in (gap.get("blocks") or []), gap
    for word in ("does not CONSTRUCT", "decorate"):
        assert word in gap["finding"], gap["finding"]
    assert "not a `variables/*.yaml` edit" in gap["consequence"]

    # ...and the finding must still be TRUE of the code it names.
    lot_src = (FRAMEWORK / "engine" / "stages" / "lot.py").read_text(encoding="utf-8")
    assert 'src["lot"]' in lot_src, "lot.normalized no longer reads the vendor LOT table"
    code = "\n".join(ln.split("#", 1)[0] for ln in lot_src.splitlines())
    assert "drug_episode" not in code, (
        "lot.py now reads drug_episode — line construction from episodes may exist. If it does, "
        "the engine_gaps entry in mcrc_goldens.yaml is stale and mg10 may no longer be blocked.")

    trt = (FRAMEWORK / "engine" / "stages" / "treatment.py").read_text(encoding="utf-8")
    assert "drug_episode" in trt, "treatment.py no longer reads drug_episode — the finding's " \
                                  "second half (episodes decorate lines) is unverifiable"


def test_the_matrix_parses_and_names_the_pack_it_is_about():
    d = _load()
    assert d["pack"] == "products/oncology/mcrc/202606"
    assert (REPO / d["pack"]).is_dir(), f"{d['pack']} does not exist"
    assert d["goldens"], "no cases"


def test_every_case_has_a_distinct_id_and_a_declared_hazard():
    """A case with no hazard is a patient somebody found interesting. The hazard is what makes the
    matrix auditable for COVERAGE rather than counted for volume."""
    d = _load()
    ids = [g["id"] for g in d["goldens"]]
    assert len(ids) == len(set(ids)), f"duplicate case id: {ids}"
    declared = set(d["hazard_classes"])
    for g in d["goldens"]:
        assert g.get("hazard") in declared, f"{g['id']}: hazard {g.get('hazard')!r} is not declared"
        assert str(g.get("shape") or "").strip(), f"{g['id']}: no shape — nothing to build"


def test_every_declared_hazard_class_has_at_least_one_case():
    """A class declared and never exercised is a coverage claim with nothing behind it — the
    failure mode this repository keeps finding in its own reports."""
    d = _load()
    used = {g["hazard"] for g in d["goldens"]}
    missing = sorted(set(d["hazard_classes"]) - used)
    assert not missing, f"declared hazard class(es) with no case: {missing}"


def test_the_boundary_cases_straddle_the_configured_window():
    """A boundary pair that does not sit either side of the line tests nothing. Read from the
    pack's OWN config, so that moving the window moves this test with it — a hard-coded date here
    would keep passing after the window changed, which is when it matters most."""
    d = _load()
    cfg = yaml.safe_load((REPO / d["pack"] / "config" / "data_product.yaml")
                         .read_text(encoding="utf-8"))
    study = cfg["study"]
    start, end = str(study["index_start"]), str(study["index_end"])

    shapes = " ".join(g["shape"] for g in d["goldens"] if g["hazard"] == "boundary")
    assert start in shapes, f"no boundary case sits on index_start {start}"
    assert end in shapes, f"no boundary case sits on index_end {end}"

    # ...and one case must sit strictly OUTSIDE, or "inclusive" is never actually tested.
    y, m, dd = (int(x) for x in start.split("-"))
    before = date(y, m, dd).toordinal() - 1
    assert date.fromordinal(before).isoformat() in shapes, \
        f"no case sits one day before index_start ({date.fromordinal(before)}) — an inclusive " \
        f"boundary read as exclusive would shift the whole cohort and nothing here would notice"


def test_the_expectations_are_still_unfilled_and_that_is_reported_honestly():
    """WHAT IS TRUE TODAY. mCRC has no approved workbook, so no expectation can exist yet.

    THIS ASSERTION IS SUPPOSED TO FAIL EVENTUALLY, and the failure is the point: on the day a
    person fills these in, this test must go red so the clinical assertions get wired up in the
    same change. A file that kept passing over filled goldens would be a green suite over
    expectations nobody ever executed — strictly worse than having no goldens at all.

    When it fires: run these cases against the composed stages the way
    test_patient_goldens_spark.py does, assert `expect` exactly, and delete this test.
    """
    d = _load()
    # KEYED ON `expect`, NOT ON "any field still blank". The first version used `any(...)` over
    # (working, spec_ref, expect), so a case with a REAL expected value and a blank `spec_ref` was
    # still counted unfilled and the tripwire stayed silent — a mutation test filled one in and
    # this test passed. An expectation is the thing that must be executed the moment it exists;
    # the other two fields make it auditable, and they are checked below once it does.
    answered = [g["id"] for g in d["goldens"] if str(g.get("expect")).strip() != MARK]
    assert not answered, (
        f"{len(answered)} case(s) now carry an expectation ({answered}). Good — now EXECUTE them: "
        f"build the patients, run the stages the way test_patient_goldens_spark.py does, assert "
        f"`expect` exactly, and delete this test. Until that happens the matrix is a claim nobody "
        f"checks, which is worse than no matrix at all.")
    assert d["status"] == "unfilled", \
        f"status says {d['status']!r} while every expectation is {MARK}"


def test_an_answered_case_carries_its_working_and_its_citation():
    """An expectation without arithmetic cannot be audited, and one without a specification row
    cannot be traced. Vacuous today by construction — it becomes the live check the moment the
    tripwire above fires, which is why it is written now rather than remembered later."""
    d = _load()
    for g in d["goldens"]:
        if str(g.get("expect")).strip() == MARK:
            continue
        for f in FILLABLE:
            assert str(g.get(f)).strip() != MARK, (
                f"{g['id']} states an expectation but leaves `{f}` as {MARK} — an answer nobody "
                f"can check against the workbook it supposedly came from")


def test_no_expectation_was_derived_from_the_config():
    """The guard, not the honour system.

    A value computed from `data_product.yaml` and written in as `expect` would test the engine
    against the pack's own inferred guesses and report the result as a clinical golden. That is the
    "internally consistent, clinically wrong" failure the goldens exist to catch, one level up.

    Enforced structurally: an expectation must cite a SPECIFICATION row, and mCRC has no extracted
    specification, so no `spec_ref` here can be legitimate yet.
    """
    d = _load()
    out = REPO / d["pack"] / "spec_pipeline" / "out" / "extracted.json"
    for g in d["goldens"]:
        ref = str(g.get("spec_ref") or "").strip()
        if ref == MARK:
            continue
        assert out.exists(), (
            f"{g['id']} cites specification row {ref!r}, but {d['pack']} has no extraction — "
            f"there is no specification for that row to be IN. An expectation with a fabricated "
            f"citation is worse than an empty one: it reads as traced.")
        assert re.match(r"^[a-z_]+:\d+(-\d+)?$", ref), f"{g['id']}: {ref!r} is not a spec row ref"


def test_the_matrix_is_reachable_from_the_pack_a_person_will_be_holding():
    """A fixture nobody is pointed at is a fixture nobody fills in. The pack's own runbook must
    name it, or on test day it will not exist as far as anyone is concerned."""
    readme = (REPO / "products" / "oncology" / "mcrc" / "202606" / "prog_spec"
              / "README.md").read_text(encoding="utf-8")
    assert "mcrc_goldens.yaml" in readme, \
        "the mCRC runbook does not mention the golden matrix — it will not be found on the day"


if __name__ == "__main__":
    os.chdir(FRAMEWORK)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
