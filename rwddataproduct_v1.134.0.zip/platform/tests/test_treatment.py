"""Pure-Python tests for the treatment stage's SQL helpers (no Spark).

Pins the taxane line-name predicate used by the prior-taxane flags (prior_tax_mcrpc /
prior_tax_pre_mcrpc) against the reference R (prostate_rdap.R: LOWER(linename) LIKE '%docetaxel%'
OR LOWER(linename) LIKE '%cabazitaxel%'). Cross-engine equality is proven in
tests/test_r_parity.py::test_parity_taxane_pred; here we lock the Python contract.
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))

from engine.stages.treatment import _taxane_pred, line_cols   # noqa: E402


def test_taxane_pred_ors_lowercased_likes():
    assert _taxane_pred(["%docetaxel%", "%cabazitaxel%"]) == (
        "lower(linename) LIKE '%docetaxel%' OR lower(linename) LIKE '%cabazitaxel%'")


def test_taxane_pred_lowercases_patterns():
    # patterns are lower-cased so the predicate matches the lower(linename) it compares against.
    assert _taxane_pred(["%PACLITAXEL%"]) == "lower(linename) LIKE '%paclitaxel%'"


def test_line_cols_scheme_and_maintenance_variants():
    # the per-line column scheme (shared with outcomes) is stable; maintenance variants add the 'm'.
    assert line_cols(1) == {"name": "lot1", "start": "lot1sd", "end": "lot1ld",
                            "lastdate": "lot1ed", "dur": "lot1dur", "cat": "lot1cat", "catn": "lot1catn"}
    assert line_cols(1, maint=True) == {"name": "lot1m", "start": "lot1msd", "end": "lot1mld",
                                        "lastdate": "lot1med", "dur": "lot1mdur",
                                        "cat": "lot1mcat", "catn": "lot1mcatn"}


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
