"""The current-state report is computed, and the prose does not re-copy it.

A number typed into a paragraph is a copy of a fact: true on the day it is written and free to
diverge afterwards. A seventh external review found four such copies in `HANDOVER.md` contradicting
the code at once. Correcting them by hand fixed the four; this fixes the mechanism.

Run: python3 platform/tests/test_current_state.py  (or pytest)
"""
import re
import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent.parent
TOOLS = REPO / "platform" / "tools"
RENDER = REPO / "governance" / "CURRENT_STATE.md"
sys.path.insert(0, str(TOOLS))

import current_state as cs                                        # noqa: E402


def test_the_committed_report_matches_what_the_validators_say():
    """The byte-compare rule every other generated view lives under. A stale generated file is
    worse than no file: it is a number nobody is maintaining, presented as current."""
    assert RENDER.exists(), f"{RENDER} has not been generated"
    assert RENDER.read_text(encoding="utf-8") == cs.render(), \
        "CURRENT_STATE.md is stale — regenerate with python3 platform/tools/current_state.py"


def test_check_exits_nonzero_on_drift():
    """Proven by mutation, not by trusting the compare: the guard has to FAIL on a stale file, or
    it is a check that reports clean because it never looked."""
    original = RENDER.read_text(encoding="utf-8")
    try:
        RENDER.write_text(original + "\n<!-- drift -->\n", encoding="utf-8")
        r = subprocess.run([sys.executable, str(TOOLS / "current_state.py"), "--check"],
                           capture_output=True, text=True, encoding="utf-8")
        assert r.returncode == 1, r.stdout + r.stderr
        assert "DRIFT" in (r.stdout + r.stderr)
    finally:
        RENDER.write_text(original, encoding="utf-8")
    r = subprocess.run([sys.executable, str(TOOLS / "current_state.py"), "--check"],
                       capture_output=True, text=True, encoding="utf-8")
    assert r.returncode == 0, r.stdout + r.stderr


def test_every_section_resolves_rather_than_reporting_an_error_row():
    """A reader cannot tell a zero from a reader that crashed unless the report says which. If a
    section cannot be computed the row says so — and no section may be in that state today."""
    text = RENDER.read_text(encoding="utf-8")
    assert "could not be computed" not in text, text
    for title, _fn, _note in cs.SECTIONS:
        assert f"## {title}" in text, title


def test_the_zeroes_are_printed_rather_than_omitted():
    """Most of what this reports is 0, and each is a place only a person can write. A report that
    dropped its zeroes would read as a system with nothing outstanding."""
    text = RENDER.read_text(encoding="utf-8")
    assert "| person_review keys registered | 0 |" in text
    assert "| …authenticated by a signature | 0 |" in text
    assert re.search(r"\| …RESOLVED with a named approver AND a usable date \| 0 \|", text)


def test_the_handover_points_at_the_report_instead_of_restating_its_counts():
    """THE DEFECT THIS EXISTS TO PREVENT. `HANDOVER.md` carried the citation counts by hand and
    they drifted. Prose may describe what is counted; it may not carry the count."""
    hand = (REPO / "HANDOVER.md").read_text(encoding="utf-8")
    assert "governance/CURRENT_STATE.md" in hand, \
        "HANDOVER does not point at the generated report"
    # The specific figures that had drifted must not be back in the prose.
    for stale in ("281 distinct citations", "242 PubMed/publisher",
                  "answerable families", "0 signed rulings"):
        assert stale not in hand, f"HANDOVER restates {stale!r}, which is generated"


def test_the_report_says_it_is_not_an_approval():
    """Counts of RECORDS. A record says who claimed something, never that the claim is true — the
    same sentence every other surface in this repository has to carry."""
    text = RENDER.read_text(encoding="utf-8")
    assert "Nothing in this file is an approval" in text
    assert "never" in text and "that the claim is true" in text


def test_the_tool_writes_only_the_file_it_generates():
    """A status tool that could write elsewhere would be a status tool that could change the thing
    it reports on."""
    import ast
    tree = ast.parse((TOOLS / "current_state.py").read_text(encoding="utf-8"))
    writes = [n for n in ast.walk(tree)
              if isinstance(n, ast.Call)
              and getattr(n.func, "attr", "") in ("write_text", "write_bytes", "mkdir")]
    for call in writes:
        target = getattr(call.func, "value", None)
        assert getattr(target, "id", "") == "RENDER" or \
            getattr(getattr(target, "value", None), "id", "") == "RENDER", \
            "current_state.py writes somewhere other than RENDER"


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
