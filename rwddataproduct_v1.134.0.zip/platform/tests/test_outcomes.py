"""Pure-Python tests for the outcomes SQL builders (no Spark).

Locks the exact Spark-SQL the per-line time-to-event variables compile to, against the reference R
(prostate_rdap.R outcomes_tbl_var). The byte-for-byte cross-engine equality is proven separately in
tests/test_r_parity.py::test_parity_outcome_sql_builders; here we pin the Python contract itself.
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))

from engine.stages.outcomes import (_trtdis_sql, _ttntfl_sql, _ttd_sql, _ttnt_sql,   # noqa: E402
                                     _progression_pred)
from engine.stages import treatment, outcomes                                      # noqa: E402

DPM = 30.4375


def test_progression_pred():
    # a progression EVENT = any evidence flag == 'Yes' AND not pseudo-progression.
    assert _progression_pred(["isradiographicevidence", "ispathologicevidence"],
                             "ispseudoprogressionmentioned") == (
        "(isradiographicevidence = 'Yes' OR ispathologicevidence = 'Yes') "
        "AND ispseudoprogressionmentioned = 'No'")


def test_rwpfs_gate_requires_clinic_note_after_index():
    # Default (no censor refinement) -> id3mosfu only, so OC/EC stay byte-identical.
    assert outcomes._rwpfs_gate({}, None) == "id3mosfu = 1"
    assert outcomes._rwpfs_gate({"eligibility_requires_censor": True}, None) == "id3mosfu = 1"
    # Prostate: ELIGPFS *and* the PFS family also require a RAW clinic note AFTER index — a fued-only
    # patient (raw clinic note NULL) can't satisfy it, so they're ineligible (no negative-interval censor).
    assert (outcomes._rwpfs_gate({"eligibility_requires_censor": True}, "lastclinicnotedate")
            == "id3mosfu = 1 AND lastclinicnotedate > index_date")


def test_treatment_outcomes_line_column_contract():
    # The outcomes line stage must reference the SAME per-line column names treatment.build() emits.
    # Both go through treatment.line_cols, so a rename can't silently desync them (this is the pure
    # guard the Spark smoke test would otherwise be the only thing to catch).
    assert treatment.line_cols(2) == {
        "name": "lot2", "start": "lot2sd", "end": "lot2ld", "lastdate": "lot2ed",
        "dur": "lot2dur", "cat": "lot2cat", "catn": "lot2catn"}
    # ttd / vis120 key off the line LAST-ACTIVITY date (loted); ttnt off the NEXT line's start.
    assert treatment.line_cols(2)["lastdate"] in outcomes._ttd_sql(2, DPM)        # lot2ed
    assert treatment.line_cols(3)["start"] in outcomes._ttnt_sql(2, DPM, True)    # lot3sd
    # end (enddate) and lastdate (loted) are DISTINCT columns — the bug was outcomes reading a name
    # treatment didn't emit; assert they differ so a future merge can't collapse them.
    assert treatment.line_cols(2)["end"] != treatment.line_cols(2)["lastdate"]


def test_trtdis_sql():
    # discontinued if a later line started, or death on this line, or still active (vis120).
    # The NULL arm: with no visit feed vis120 is NULL, and a patient not provable by lines or
    # death is UNKNOWN — the old ELSE 0 claimed "not discontinued" for every such patient.
    assert _trtdis_sql(2) == (
        "CASE WHEN lotn > 2 OR (lotn = 2 AND dthdt IS NOT NULL) OR vis120 = 1 "
        "THEN 1 WHEN vis120 IS NULL THEN NULL ELSE 0 END")


def test_ttntfl_sql():
    assert _ttntfl_sql(1) == "CASE WHEN lotn > 1 OR dthfl = 1 THEN 1 ELSE 0 END"


def test_ttd_sql_no_plus_one():
    # ttd has NO +1 (matches the R datediff(lotNed, index_date)/dpm).
    assert _ttd_sql(3, DPM) == "datediff(lot3ed, index_date)/30.4375"


def test_ttnt_sql_has_next_uses_least_of_nextline_and_death():
    # event -> earlier of next-line start and death (Spark least skips nulls == pmin na.rm); +1.
    assert _ttnt_sql(2, DPM, True) == (
        "CASE WHEN ttntfl = 1 THEN (datediff(least(lot3sd, dthdt), index_date)+1)/30.4375 "
        "WHEN ttntfl = 0 THEN (datediff(fued, index_date)+1)/30.4375 ELSE 0 END")


def test_ttnt_sql_no_next_line_falls_back_to_death():
    # last modelled line: no lot{n+1}sd column -> next-event date is death alone.
    assert _ttnt_sql(5, DPM, False) == (
        "CASE WHEN ttntfl = 1 THEN (datediff(dthdt, index_date)+1)/30.4375 "
        "WHEN ttntfl = 0 THEN (datediff(fued, index_date)+1)/30.4375 ELSE 0 END")


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
