"""A change to the executable YAML must be nameable, and a cosmetic one must be silent.

`platform/tools/config_diff.py` exists because a byte digest says THAT the config moved and never
WHAT moved — so "a comment gained a word" and "the cohort window narrowed by a year" were the same
red hash. Every test here is one of the ways the answer could be wrong: a cosmetic edit reported
(the checker cries wolf and gets switched off), a dropped derivation reported as a mere change, a
precedence reorder invisible because the items are byte-identical, a codelist edit reported without
the codes, or an unreachable base reading as "no change" — the one thing this must never say by
accident.

Run: python3 tests/test_config_diff.py (or pytest).
"""
import os
import subprocess
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
TOOLS = FRAMEWORK / "tools"
REPO = FRAMEWORK.parent
sys.path.insert(0, str(TOOLS))

import config_diff  # noqa: E402

BASE_CONFIG = """\
study:
  index_start: 2011-01-01
  window_days: -30
cohorts:
  - {cohort: C1, line_setting: mHSPC}
  - {cohort: C2, line_setting: mCRPC}
"""

BASE_VARS = """\
# a comment that will move
lot:
  divisor: 30.4375
  categories:
    - {name: NHA, precedence: 1}
    - {name: Taxane, precedence: 2}
outcomes:
  os_gate: id3mosfu
"""

BASE_CODES = """\
ecog:
  - "0"
  - "1"
  - "2"
"""


def _sh(root, *args):
    r = subprocess.run(["git", "-C", str(root), *args], capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    assert r.returncode == 0, (args, r.stdout, r.stderr)
    return r.stdout


def _repo():
    """A throwaway git repo holding one pack's executable surface, committed as the base."""
    tmp = tempfile.mkdtemp(prefix="cfgdiff_")
    pack = Path(tmp, "products", "oncology", "test", "202606")
    (pack / "config").mkdir(parents=True)
    (pack / "variables").mkdir()
    (pack / "codelists").mkdir()
    (pack / "config" / "data_product.yaml").write_text(BASE_CONFIG, encoding="utf-8")
    (pack / "variables" / "treatment.yaml").write_text(BASE_VARS, encoding="utf-8")
    (pack / "codelists" / "ecog.yaml").write_text(BASE_CODES, encoding="utf-8")
    _sh(tmp, "init", "-q")
    _sh(tmp, "add", "-A")
    _sh(tmp, "-c", "user.email=t@t", "-c", "user.name=t", "commit", "-qm", "base")
    return tmp, "products/oncology/test/202606"


def test_a_cosmetic_edit_is_silent_and_a_semantic_one_is_named():
    """The load-bearing distinction. A checker that reports moved comments gets switched off, and
    then it is not protecting the window change it was built for."""
    root, pack = _repo()
    p = Path(root, pack)
    # cosmetic: comment moved, key order swapped, quoting style changed — the STRUCTURE is equal
    (p / "variables" / "treatment.yaml").write_text(
        "lot:\n  categories:\n    - {name: NHA, precedence: 1}\n"
        "    - {name: Taxane, precedence: 2}\n  divisor: 30.4375\n"
        "# a comment that moved here\noutcomes:\n  os_gate: 'id3mosfu'\n", encoding="utf-8")
    assert config_diff.diff_pack(pack, "HEAD", root=root) == {}, \
        "a comment/key-order/quoting edit produced findings — the checker cries wolf"

    # semantic: window narrowed, a derivation key dropped, a cohort added
    (p / "config" / "data_product.yaml").write_text(
        BASE_CONFIG.replace("window_days: -30", "window_days: -365")
        + "  - {cohort: C3, line_setting: nmCRPC}\n", encoding="utf-8")
    (p / "variables" / "treatment.yaml").write_text(
        BASE_VARS.replace("outcomes:\n  os_gate: id3mosfu\n", ""), encoding="utf-8")
    out = config_diff.diff_pack(pack, "HEAD", root=root)
    flat = [(k, path) for v in out.values() for k, path, _d in v]
    assert ("changed", "/study/window_days") in flat, flat
    detail = next(d for v in out.values() for k, path, d in v if path == "/study/window_days")
    assert "-30" in detail and "-365" in detail, \
        f"the change does not show old -> new: {detail}"
    assert ("dropped", "/outcomes/os_gate") in flat, \
        "a dropped derivation key is not named as DROPPED"
    assert any(k == "added" and "C3" in path for k, path in flat), flat


def test_a_precedence_reorder_over_identical_items_is_its_own_finding():
    """Every item byte-identical, order swapped — a line diff shows two moved lines and a byte
    digest shows 'changed'; only a keyed comparison can say 'same rules, different precedence'."""
    root, pack = _repo()
    p = Path(root, pack)
    (p / "variables" / "treatment.yaml").write_text(
        BASE_VARS.replace(
            "    - {name: NHA, precedence: 1}\n    - {name: Taxane, precedence: 2}",
            "    - {name: Taxane, precedence: 2}\n    - {name: NHA, precedence: 1}"),
        encoding="utf-8")
    out = config_diff.diff_pack(pack, "HEAD", root=root)
    findings = out.get(f"{pack}/variables/treatment.yaml") or []
    assert [(k, p_) for k, p_, _d in findings] == [("reordered", "/lot/categories")], findings
    assert "NHA" in findings[0][2] and "Taxane" in findings[0][2]


def test_a_codelist_edit_names_the_codes_and_a_dropped_file_names_the_loss():
    root, pack = _repo()
    p = Path(root, pack)
    (p / "codelists" / "ecog.yaml").write_text('ecog:\n  - "0"\n  - "1"\n  - "3"\n',
                                               encoding="utf-8")
    os.remove(p / "variables" / "treatment.yaml")
    out = config_diff.diff_pack(pack, "HEAD", root=root)
    code_findings = out[f"{pack}/codelists/ecog.yaml"]
    assert code_findings[0][0] == "list_changed" and "-1: 2" in code_findings[0][2] \
        and "+1: 3" in code_findings[0][2], code_findings
    gone = out[f"{pack}/variables/treatment.yaml"]
    assert gone[0][0] == "dropped" and "entire file" in gone[0][1], gone


def test_an_unreachable_base_is_an_error_and_never_reads_as_no_change():
    """The fail-open this tool must not have: `git show` failing quietly would make every diff
    empty, and an empty report is exactly what a clean pack prints."""
    root, pack = _repo()
    try:
        config_diff.diff_pack(pack, "0000000000000000000000000000000000000000", root=root)
        raise AssertionError("an unreachable base did not raise")
    except RuntimeError as e:
        assert "base revision" in str(e) or "ls-tree" in str(e)


def test_the_ci_workflow_runs_it_base_to_head():
    """The differ in a drawer explains nothing. The workflow must invoke it with the same BASE
    resolution the version guard uses — advisory output, but produced on every PR."""
    wf = (REPO / ".github" / "workflows" / "rwdp-ci.yml").read_text(encoding="utf-8")
    assert "config_diff.py --all --base" in wf, \
        "CI no longer produces the semantic config diff on PRs"


if __name__ == "__main__":
    for name, fn in sorted({k: v for k, v in globals().items()
                            if k.startswith("test_") and callable(v)}.items()):
        fn()
        print(f"ok  {name.replace('test_', '').replace('_', ' ')}")
    print("OK")
