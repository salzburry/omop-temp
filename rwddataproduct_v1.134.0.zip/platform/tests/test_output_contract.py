"""The ADS output contract: is what we built the SHAPE we promised?

An external review found that the QC gate could pass a duplicated, incomplete or nearly empty
product — it checked four rates and never checked what the rows ARE. These tests hold the fix to
four properties:

  * THE KEY CHECK CATCHES WHAT `distinct()` CANNOT. A full-row distinct collapses rows identical in
    every column. Two rows for one patient/cohort/index that DISAGREE survive it untouched, which
    is exactly what a bad join or a non-deterministic tie-break produces. There is a Spark test
    below that builds that pair and proves `distinct()` keeps both.
  * DERIVED CHECKS CANNOT BE OPTED OUT OF BY SILENCE. The output key and cohort completeness need
    nothing declared, so a pack that declares nothing still gets them.
  * AN UNCONFIGURED CHECK IS NOT A PASS. No pack declares a `qc:` block today, so a gate that
    returned a bare `passed: True` over zero rules would install the absence-reads-as-clean failure
    at the last step before publish.
  * NULL IS NOT AN OUT-OF-VOCABULARY VALUE. A patient with no third line has a null `lot3cat`;
    counting that as a violation would fire hardest on the packs with the least treatment data.

Run: python3 platform/tests/test_output_contract.py  (or pytest). The Spark tests skip without
pyspark; the pure-data ones always run.
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))

from engine.config import load_config, product_config          # noqa: E402
from engine import output_contract as oc                       # noqa: E402

CONFIG = product_config(FRAMEWORK.parent / "products", "prostate")

try:
    from pyspark.sql import SparkSession
except Exception:
    SparkSession = None

try:
    import pytest
    _needs_spark = pytest.mark.skipif(SparkSession is None, reason="pyspark not installed")
except Exception:
    pytest = None

    def _needs_spark(fn):
        return fn

_SPARK = None


def _spark():
    """THE SHARED SESSION, and never a second builder.

    The first version of this file built its own `SparkSession.builder…getOrCreate()`. Because
    `getOrCreate` returns the session that already exists — and this suite sorts before
    `test_smoke_spark` — every later Spark suite in the run inherited MY settings, which omitted
    `spark.sql.autoBroadcastJoinThreshold: -1`. That setting is not a preference: the shared
    helper's own docstring records that the 7-cohort production-union build dies with
    `OutOfMemoryError: Java heap space` deserialising broadcast hash relations without it. The
    prostate union smoke duly OOM'd, three suites away from the file that caused it.

    So the session comes from the one place that owns it, which is the same rule the fixture module
    was created to enforce.
    """
    global _SPARK
    if _SPARK is None:
        sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))
        import synthetic_sources
        _SPARK = synthetic_sources.session("output-contract")
    return _SPARK


# One clean row per (patientid, cohortn, index_date). Every other frame in this file is this one
# bent in a single specific way, so a failure names the bend.
#
# THE SCHEMA IS EXPLICIT, not inferred. Half of these frames carry an all-null column on purpose —
# a patient who never reached a line, a survivor with no death date — and inference cannot type a
# column it has only seen nulls in. Spelling the schema also keeps the dates a real DateType, so
# `start > end` is a date comparison rather than a lexicographic accident that happens to agree.
_FIELDS = (("patientid", "string"), ("cohortn", "int"), ("index_date", "date"),
           ("cohort", "string"), ("lot1cat", "string"), ("dthdt", "date"),
           ("dth_flag", "int"), ("os_months", "double"))
COLS = [n for n, _ in _FIELDS]


def _d(s):
    """'2020-01-01' -> date, and None straight through."""
    import datetime
    return None if s is None else datetime.date(*(int(p) for p in s.split("-")))


CLEAN = [("p1", 1, _d("2020-01-01"), "Overall mHSPC", "Any other therapy", _d("2021-01-01"), 1, 12.0),
         ("p2", 1, _d("2020-02-01"), "Overall mHSPC", "Any other therapy", None, 0, 6.0)]


def _row_at(pid, when, coh="Overall mHSPC", cn=1):
    """One clean row for `pid` indexed on `when` — the shape the membership check needs."""
    return (pid, cn, _d(when), coh, "Any other therapy", None, 0, 1.0)


def _df(rows, fields=_FIELDS):
    schema = ", ".join(f"{n} {t}" for n, t in fields)
    return _spark().createDataFrame(rows, schema)


# --------------------------------------------------------------------------- pure data


def test_the_plan_derives_cohorts_and_vocabulary_from_config():
    """DERIVED means the config already stated the answer. If this ever comes back empty on the
    reference tumour, the checks that rest on it have quietly become vacuous."""
    spec = oc.contract_spec(load_config(CONFIG))
    assert spec["key"] == ["patientid", "cohortn", "index_date"]
    labels = [c["label"] for c in spec["cohorts_expected"]]
    assert "Overall mHSPC" in labels and len(labels) == 7, labels
    # The line-category codelist compiles into lot{i}cat, so its labels ARE that column's vocabulary.
    assert "Any other therapy" in spec["vocabulary"]["lot1cat"]
    assert "lotcat" in spec["vocabulary"], "the cohort-indexed alias is left unconstrained"
    assert "CHECK" in spec["vocabulary"]["stage"]
    # ...and DECLARED means nobody has written it down yet. prostate has no `qc:` block.
    assert spec["null_limits"] == {} and spec["date_order"] == []
    assert spec["strict"] is False


def test_a_pack_declaring_no_codelist_constrains_nothing_rather_than_everything():
    """None and empty are different facts. Collapsing them makes the vocabulary check compare a
    column against {} and report every value in it as a violation."""
    cfg = load_config(CONFIG)
    cfg.pack("treatment")["line_category_codelist"] = None
    spec = oc.contract_spec(cfg)
    assert "lot1cat" not in spec["vocabulary"]
    assert oc._codelist_labels(cfg, "no_such_codelist") is None


def test_an_unkeyable_ads_fails_and_is_never_reported_as_unchecked():
    """The most broken possible output must not leave by the quietest possible path."""
    g = oc.output_contract_gate({"key_missing_columns": ["cohortn"], "duplicate_keys": None})
    assert g["passed"] is False
    assert "cannot be keyed" in g["failures"][0], g["failures"]


def test_duplicate_keys_fail_and_the_message_names_what_distinct_cannot_do():
    g = oc.output_contract_gate({"key_missing_columns": [], "duplicate_keys": 3,
                                 "duplicate_key_rows": 7, "key": oc.OUTPUT_KEY})
    assert g["passed"] is False
    msg = g["failures"][0]
    assert "3 output key(s)" in msg and "7 rows" in msg
    assert "do not collapse" in msg or "does not collapse" in msg, msg


def test_a_missing_cohort_fails_and_an_empty_one_must_be_declared_not_discovered():
    g = oc.output_contract_gate({"key_missing_columns": [], "duplicate_keys": 0,
                                 "cohorts_missing": ["L4+ treated mCRPC"]})
    assert g["passed"] is False
    assert "allow_empty_cohorts" in g["failures"][0]


def test_an_unconfigured_check_is_reported_and_never_counted_as_a_pass():
    """No pack declares a `qc:` block. A gate that returned a bare pass over zero rules would put
    the absence-reads-as-a-clean-result failure at the last step before publish."""
    g = oc.output_contract_gate({"key_missing_columns": [], "duplicate_keys": 0, "compared": {}})
    assert g["passed"] is True, "derived checks passed, so the build is not blocked"
    joined = " ".join(g["unconfigured"])
    for check in ("null_limits", "flag_date_pairs", "date_order", "nonnegative", "vocabulary"):
        assert check in joined, check
    assert "NOTHING COMPARED" in joined and "silence, not agreement" in joined


def test_strict_turns_an_unconfigured_check_into_a_failure():
    """A pack that has done the declaring gets to insist the declaring stays done."""
    r = {"key_missing_columns": [], "duplicate_keys": 0, "compared": {}, "strict": True}
    assert oc.output_contract_gate(r)["passed"] is False
    r["strict"] = False
    assert oc.output_contract_gate(r)["passed"] is True


def test_the_publish_surface_is_a_privacy_floor_and_a_strict_whitelist():
    """G6's second half, gate-level (pure): a never_publish column present fails in EVERY mode;
    in strict mode an undeclared whitelist is itself the failure, an extra column is an
    internal helper about to ship, a missing one an incomplete surface, and order is part of
    what was approved. A clean strict report with a declared, matching whitelist passes."""
    base = {"key_missing_columns": [], "duplicate_keys": 0,
            "compared": {"null_limits": 1}, "violations": {}, "strict": False}
    r = dict(base, publish={"declared": False, "never_publish_present": ["dob"]})
    g = oc.output_contract_gate(r)
    assert g["passed"] is False and any("privacy floor" in f for f in g["failures"])
    r = dict(base, strict=True, publish={"declared": False})
    assert any("no publish whitelist declared" in f
               for f in oc.output_contract_gate(r)["failures"])
    r = dict(base, strict=True,
             publish={"declared": True, "extra": ["helper_col"], "missing": ["os"],
                      "order_differs": True})
    fails = oc.output_contract_gate(r)["failures"]
    assert any("internal helper about to ship" in f for f in fails)
    assert any("absent from the ADS" in f for f in fails)
    assert any("order" in f for f in fails)
    # a clean declared whitelist contributes NO publish failure (other strict machinery may
    # still flag unconfigured families on this minimal report — not this test's subject)
    r = dict(base, strict=True,
             publish={"declared": True, "extra": [], "missing": [], "order_differs": False})
    fails = oc.output_contract_gate(r)["failures"]
    assert not any(("whitelist" in f) or ("privacy" in f) for f in fails), fails


@_needs_spark
def test_the_publish_report_reads_the_real_frame_case_insensitively():
    """The report half over a built frame: declared whitelist compared against the actual
    columns (case-insensitive, order-aware), never_publish intersected — schema only."""
    names = [n for n, _t in _FIELDS]
    cfg = load_config(CONFIG)
    cfg.raw["qc"] = {"publish_columns": [n.upper() for n in names],
                     "never_publish": ["SSN", names[-1]]}
    rep = oc.run_output_contract(_spark(), _df(CLEAN), cfg)
    p = rep["publish"]
    assert p["declared"] and p["extra"] == [] and p["missing"] == []
    assert p["order_differs"] is False
    assert p["never_publish_present"] == [names[-1].lower()], p


def test_a_null_limit_is_judged_as_a_rate_not_as_a_count():
    """A column with a declared allowance of 0.2 must not fail for holding one null."""
    r = {"key_missing_columns": [], "duplicate_keys": 0, "compared": {"null_limits": 1},
         "null_limits": {"dthdt": 0.5}, "null_rate": {"dthdt": 0.4}, "violations": {}}
    assert oc.output_contract_gate(r)["passed"] is True
    r["null_rate"] = {"dthdt": 0.6}
    g = oc.output_contract_gate(r)
    assert g["passed"] is False and "null rate 0.6 > declared limit 0.5" in g["failures"][0]


# --------------------------------------------------------------------------- Spark


@_needs_spark
def test_two_disagreeing_rows_survive_distinct_and_the_key_check_catches_them():
    """THE HEADLINE. This is the gap the review found, reproduced end to end.

    Two rows for one patient, one cohort, one index date, differing in ONE column. `distinct()`
    keeps both — it only collapses rows identical everywhere — so `assemble.build`'s final
    `.distinct()` passes them straight through, and one of the two is wrong.
    """
    rows = list(CLEAN) + [("p1", 1, _d("2020-01-01"), "Overall mHSPC", "Any other therapy",
                           _d("2021-01-01"), 1, 99.0)]        # same key, different os_months
    df = _df(rows)
    assert df.distinct().count() == 3, "distinct() collapsed a DISAGREEING row — premise is wrong"

    rep = oc.run_output_contract(_spark(), df, load_config(CONFIG))
    assert rep["duplicate_keys"] == 1, rep
    assert rep["duplicate_key_rows"] == 2, rep
    assert oc.output_contract_gate(rep)["passed"] is False


@_needs_spark
def test_a_clean_frame_passes_the_derived_checks():
    """The control. Without it, every assertion above could be satisfied by a check that always
    fails, and nothing here would notice.

    THIS TEST WAS TOO WEAK AND AN EXTERNAL REVIEW FOUND WHAT IT MISSED. It declared
    `allow_empty_cohorts` and then asserted only that no failure containing "key" appeared — which
    filtered out precisely the cohort failures the declaration was supposed to suppress. So it
    passed while `allow_empty_cohorts` was parsed and never read. A control that filters out the
    thing it is controlling for is not a control.
    """
    cfg = load_config(CONFIG)
    cfg.raw["qc"] = {"allow_empty_cohorts": [c["label"] for c in cfg.cohorts[1:]]}
    rep = oc.run_output_contract(_spark(), _df(CLEAN), cfg)
    assert rep["duplicate_keys"] == 0, rep
    assert rep["n_rows"] == 2
    # The declaration must actually DO something: six cohorts absent, all six excused.
    assert rep["cohorts_missing"] == [], rep["cohorts_missing"]
    assert len(rep["cohorts_allowed_empty"]) == 6, rep["cohorts_allowed_empty"]
    g = oc.output_contract_gate(rep)
    assert g["failures"] == [], g["failures"]


@_needs_spark
def test_a_cohort_the_build_was_told_to_produce_and_did_not_is_a_failure():
    rep = oc.run_output_contract(_spark(), _df(CLEAN), load_config(CONFIG))
    assert "L4+ treated mCRPC" in rep["cohorts_missing"], rep["cohorts_missing"]
    assert oc.output_contract_gate(rep)["passed"] is False


@_needs_spark
def test_an_ads_with_no_cohort_column_fails_rather_than_reporting_unconfigured():
    """THE FAIL-OPEN AN EXTERNAL REVIEW FOUND. A missing `cohort` column was routed to `skipped`,
    which surfaces as `unconfigured` — and `unconfigured` does not fail unless a pack opted into
    strict. So the most broken shape available left by the quietest path."""
    fields = tuple((n, t) for n, t in _FIELDS if n != "cohort")
    rows = [(r[0], r[1], r[2], r[4], r[5], r[6], r[7]) for r in CLEAN]
    rep = oc.run_output_contract(_spark(), _df(rows, fields), load_config(CONFIG))
    assert rep.get("cohort_column_missing") is True, rep
    assert "cohorts" not in (rep.get("skipped") or {}), rep["skipped"]
    g = oc.output_contract_gate(rep)
    assert g["passed"] is False
    assert any("no `cohort` column" in f for f in g["failures"]), g["failures"]


@_needs_spark
def test_allow_empty_cohorts_naming_an_unknown_cohort_is_reported():
    """A typo there exempts nothing — or exempts a cohort that has since been renamed, which is the
    same defect arriving later and quieter."""
    cfg = load_config(CONFIG)
    cfg.raw["qc"] = {"allow_empty_cohorts": ["No Such Cohort"]}
    rep = oc.run_output_contract(_spark(), _df(CLEAN), cfg)
    assert rep["allow_empty_unknown"] == ["No Such Cohort"], rep
    assert any("no config entry declares" in f for f in oc.output_contract_gate(rep)["failures"])


@_needs_spark
def test_one_patient_twice_in_one_cohort_fails_even_though_the_output_key_is_unique():
    """THE NARROWER QUESTION THE OUTPUT KEY CANNOT ASK. Two rows for one patient in one cohort with
    DIFFERENT index dates: the output key (patientid, cohortn, index_date) is perfectly unique, and
    the patient is counted twice in every rate and denominator computed over cohort membership."""
    rows = [_row_at("p1", "2020-01-01"), _row_at("p1", "2021-06-01")]
    rep = oc.run_output_contract(_spark(), _df(rows), load_config(CONFIG))
    assert rep["duplicate_keys"] == 0, "premise: the OUTPUT key is unique here"
    assert rep["duplicate_membership"] == 1, rep
    assert rep["duplicate_membership_rows"] == 2, rep
    g = oc.output_contract_gate(rep)
    assert g["passed"] is False
    assert any("appear more than once in one cohort" in f for f in g["failures"]), g["failures"]


@_needs_spark
def test_a_cohort_label_no_config_entry_declares_is_a_failure():
    rows = [("p1", 9, _d("2020-01-01"), "Invented Cohort", None, None, 0, 1.0)]
    rep = oc.run_output_contract(_spark(), _df(rows), load_config(CONFIG))
    assert rep["cohorts_unexpected"] == ["Invented Cohort"], rep
    assert any("no config entry declares" in f for f in oc.output_contract_gate(rep)["failures"])


@_needs_spark
def test_an_out_of_vocabulary_category_is_caught_and_a_null_one_is_not():
    """Two halves of one rule. A value the approved codelist does not enumerate is a defect; a
    patient who never reached that line is not."""
    rows = [("p1", 1, _d("2020-01-01"), "Overall mHSPC", "Fabricated Regimen", None, 0, 1.0),
            ("p2", 1, _d("2020-02-01"), "Overall mHSPC", None, None, 0, 1.0)]
    rep = oc.run_output_contract(_spark(), _df(rows), load_config(CONFIG))
    assert rep["violations"].get("vocab__lot1cat") == 1, rep["violations"]
    assert any("codelist does not enumerate" in f for f in oc.output_contract_gate(rep)["failures"])


@_needs_spark
def test_declared_row_level_rules_are_enforced_in_one_scan():
    """date order, negative durations and both directions of flag/date agreement."""
    cfg = load_config(CONFIG)
    cfg.raw["qc"] = {"date_order": [{"start": "index_date", "end": "dthdt"}],
                     "nonnegative": ["os_months"],
                     "flag_date_pairs": [{"flag": "dth_flag", "date": "dthdt"}]}
    rows = [("p1", 1, _d("2020-01-01"), "Overall mHSPC", None, _d("2019-01-01"), 1, 5.0),  # death precedes index
            ("p2", 1, _d("2020-02-01"), "Overall mHSPC", None, None, 1, -3.0),         # flag set, no date; negative
            ("p3", 1, _d("2020-03-01"), "Overall mHSPC", None, _d("2021-01-01"), 0, 5.0)]  # date, no flag
    rep = oc.run_output_contract(_spark(), _df(rows), cfg)
    v = rep["violations"]
    assert v.get("dateorder__index_date__dthdt") == 1, v
    assert v.get("negative__os_months") == 1, v
    assert v.get("flagnodate__dth_flag__dthdt") == 1, v
    assert v.get("datenoflag__dth_flag__dthdt") == 1, v
    assert rep["compared"]["date_order"] == 1 and rep["compared"]["nonnegative"] == 1
    assert oc.output_contract_gate(rep)["passed"] is False


@_needs_spark
def test_a_declared_rule_naming_a_column_the_ads_lacks_is_reported_not_silently_dropped():
    cfg = load_config(CONFIG)
    cfg.raw["qc"] = {"nonnegative": ["no_such_column"]}
    rep = oc.run_output_contract(_spark(), _df(CLEAN), cfg)
    assert rep["compared"]["nonnegative"] == 0
    assert rep["skipped"]["nonnegative"] == ["no_such_column"], rep["skipped"]
    assert any("nonnegative" in u for u in oc.output_contract_gate(rep)["unconfigured"])


@_needs_spark
def test_the_catchall_rate_is_taken_over_eligible_rows_not_over_the_whole_ads():
    """The denominator fix. Three patients, ONE of whom reached this line and landed in the
    catch-all: the rate is 1/1, not 1/3. Dividing by every patient in the study made the rate fall
    as the untreated share rose, which is the opposite of the signal the threshold is worded for."""
    from engine import qc as qc_mod
    # `lot2cat` is carried and entirely null: a line the product emits and nobody in this frame
    # reached. That is the case the None branch exists for.
    fields = _FIELDS + (("lot2cat", "string"),)
    rows = [("p1", 1, _d("2020-01-01"), "Overall mHSPC", "Any other therapy", None, 0, 1.0, None),
            ("p2", 1, _d("2020-02-01"), "Overall mHSPC", None, None, 0, 1.0, None),
            ("p3", 1, _d("2020-03-01"), "Overall mHSPC", None, None, 0, 1.0, None)]
    rep = qc_mod.run_qc(_spark(), _df(rows, fields), load_config(CONFIG))
    # One of three patients reached line 1, and landed in the catch-all: 1/1, not 1/3.
    assert rep["catchall_eligible"]["lot1cat"] == 1, rep["catchall_eligible"]
    assert rep["catchall_rate"]["lot1cat"] == 1.0, rep["catchall_rate"]
    # A line nobody reached has NO rate — reporting 0.0 would read as "all classified correctly".
    assert rep["catchall_eligible"]["lot2cat"] == 0, rep["catchall_eligible"]
    assert rep["catchall_rate"]["lot2cat"] is None, rep["catchall_rate"]
    # A column the ADS does not carry at all is absent from both, not reported as a clean zero.
    assert "lot3cat" not in rep["catchall_rate"], rep["catchall_rate"]


# CI RUNS EVERY SUITE AS A SCRIPT, so this block is not a convenience — a file without it
# contributes zero tests and exits 0, which reads as a pass. The Spark-backed tests are named
# explicitly rather than sniffed, because a decorator that is a pytest mark under pytest and a
# no-op without it cannot be introspected the same way in both worlds, and guessing wrong here
# means silently running nothing.
SPARK_TESTS = (
    "test_one_patient_twice_in_one_cohort_fails_even_though_the_output_key_is_unique",
    "test_allow_empty_cohorts_naming_an_unknown_cohort_is_reported",
    "test_an_ads_with_no_cohort_column_fails_rather_than_reporting_unconfigured",
    "test_two_disagreeing_rows_survive_distinct_and_the_key_check_catches_them",
    "test_a_clean_frame_passes_the_derived_checks",
    "test_a_cohort_the_build_was_told_to_produce_and_did_not_is_a_failure",
    "test_a_cohort_label_no_config_entry_declares_is_a_failure",
    "test_an_out_of_vocabulary_category_is_caught_and_a_null_one_is_not",
    "test_declared_row_level_rules_are_enforced_in_one_scan",
    "test_a_declared_rule_naming_a_column_the_ads_lacks_is_reported_not_silently_dropped",
    "test_the_catchall_rate_is_taken_over_eligible_rows_not_over_the_whole_ads",
)

if __name__ == "__main__":
    fns = [(k, v) for k, v in sorted(globals().items()) if k.startswith("test_")]
    assert {n for n, _ in fns} >= set(SPARK_TESTS), "SPARK_TESTS names a test that no longer exists"
    ran = skipped = 0
    for name, fn in fns:
        if name in SPARK_TESTS and SparkSession is None:
            print(f"SKIP {name}: pyspark not installed")
            skipped += 1
            continue
        fn()
        ran += 1
        print(f"ok  {name}")
    print(f"\n{ran} tests passed, {skipped} skipped")
