"""One search across six surfaces, and every hit carries what it is ALLOWED to settle.

The repository holds decisions, precedents, contract records, the variable inventory, the citation
register and the capability registry — six kinds of knowledge about the same subjects, six readers,
six places to remember. In a grep they all look alike, and that is the hazard: the inventory is
`reference_only` because it authorises nothing into any product, and a `reference_only` line ranked
above a signed ruling is how a drafting aid gets read as a specification.

What is pinned here: every surface is searched; every hit carries a DOMAIN (what kind of authority
it could ever have) and a STATE (how far that authority has been taken within its domain); the
ordering follows those two facets rather than term frequency; the state is computed from the
record's live state rather than assumed from the surface; a surface its own validator refuses is
EXCLUDED rather than silently ranked; and the "nothing here is an approval" banner cannot be
dropped — including on a search that finds nothing.

The two facets replaced one flat ladder, which had ranked engine-wiring evidence above an unsigned
methodology answer as though they were degrees of one thing. They are different KINDS: RWDE
capability evidence cannot settle an RWP methodology question at any state.

NO PYTEST FIXTURES AND NO `parametrize`, and that is not a style preference. CI runs every suite as
a SCRIPT, so a test taking a fixture argument cannot be CALLED outside pytest — the file would
import, define its tests, run none of them and exit 0. That is a green step protecting nothing, and
this suite shipped that way for one commit until
`test_spec_pipeline.test_every_suite_actually_runs_the_way_ci_invokes_it` caught it. Cases that
would be `parametrize` are loops that name the case they failed on, and `capsys` is a
`redirect_stdout`.

Run: python3 tests/test_knowledge_search.py (or pytest).
"""
import contextlib
import io
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))

import knowledge_search as ks  # noqa: E402


_CACHE = []


def broad():
    """A term every surface carries. `date` appears in registers, records, shelf entries,
    capabilities and citation titles alike. Computed once per process."""
    if not _CACHE:
        _CACHE.append(ks.search(["date"]))
    return _CACHE[0]


# Each surface searched in its OWN vocabulary — that is what proves it is reachable. One term across
# all six would only prove the term is common. Citation records hold a bibliographic string and
# nothing else, so they share no prose word with the other five.
SURFACE_PROBES = [
    ("decision", "date"), ("precedent", "follow-up"), ("contract_record", "date"),
    ("capability", "date"), ("inventory", "date"), ("citation", "2019"),
]


def test_every_surface_is_reachable():
    """A federated search that silently stops covering a surface is worse than no search: the
    reader believes they asked everywhere."""
    for kind, term in SURFACE_PROBES:
        hits = ks.search([term], kinds=[kind])
        assert hits, f"{kind} returned nothing for {term!r}"
        assert {h["kind"] for h in hits} == {kind}


def test_the_default_search_covers_every_declared_surface():
    """The finder table and the declared kinds cannot fall out of step — a kind with no finder
    would raise, and a finder with no kind would never run."""
    assert set(ks.FINDERS) == set(ks.KINDS)


def test_every_hit_carries_a_declared_domain_and_state():
    hits = broad()
    assert hits
    for h in hits:
        assert h["domain"] in ks.DOMAIN_RANK, h
        # PER DOMAIN. A state is only meaningful beside the domain that defines it.
        assert ks.state_error(h["domain"], h["state"]) is None, h


def test_a_state_may_not_be_borrowed_from_another_domain():
    """THE DEFECT THE SEVENTH REVIEW NAMED, made structurally impossible.

    One shared ladder let a surface reach for the strongest-sounding word without holding what it
    named: `signed` was defined as "a named person and a usable date stand behind it", and
    `_contract_records` awarded it from the bare string `requirement: approved` — reading no
    approver, no date, and importing nothing that could read one. Per-domain vocabularies mean the
    word does not exist to borrow.
    """
    assert ks.state_error("product_ruling", "attributed") is None
    assert ks.state_error("implementation_evidence", "component_parity") is None
    # ...and every cross-domain borrow is refused.
    for domain, alien in (("product_ruling", "component_parity"),
                          ("implementation_evidence", "attributed"),
                          ("provenance", "reference_only"),
                          ("literature", "source_verified")):
        assert ks.state_error(domain, alien), f"{domain} accepted {alien}"
    # `signed` is gone from every vocabulary — it is the word that spread.
    assert "signed" not in {n for ladder in ks.STATES.values() for n, _ in ladder}


def test_search_validates_itself_rather_than_trusting_the_caller():
    """Fail-closed has to be a property of the API, not a convention of one CLI wrapper.

    `skip` was computed only in `main`, so every programmatic caller of `search()` got hits from
    surfaces that had passed no validator, ranked identically to validated ones.
    """
    import inspect
    src = inspect.getsource(ks.search)
    assert "surface_errors" in src, "search() must validate when the caller has not"
    assert "state_error" in src, "search() must refuse a hit whose state is not its domain's"


def test_results_are_ordered_by_domain_then_state_within_that_domain():
    """THE POINT OF THE TOOL. Term frequency would put a wordy inventory entry above a ruling."""
    ranks = [(ks.DOMAIN_RANK[h["domain"]],
              ks.STATE_RANK[h["domain"]][h["state"]]) for h in broad()]
    assert ranks == sorted(ranks), "results are not in domain-then-state order"


def test_the_inventory_can_never_outrank_a_decision():
    """The shelf authorises nothing, in any state — which is the DOMAIN's job to say, not the
    state's. Its states now record how far a claim was checked; none of them is authority."""
    assert ks.DOMAIN_RANK["literature"] > ks.DOMAIN_RANK["product_ruling"]
    for h in broad():
        if h["kind"] == "inventory":
            assert h["domain"] == "literature"
            assert ks.state_error("literature", h["state"]) is None, h


def test_implementation_evidence_is_a_DIFFERENT_KIND_not_a_weaker_ruling():
    """THE DESIGN DEFECT THE SIXTH REVIEW NAMED. One flat ladder put `checked_claim` above an
    unsigned methodology answer, as though a well-tested engine wiring could settle what a variable
    should MEAN. RWDE capability evidence and an RWP methodology ruling are different kinds of
    authority; ranking them on one scale invites exactly the substitution the gates forbid."""
    assert "implementation_evidence" in ks.DOMAIN_RANK and "product_ruling" in ks.DOMAIN_RANK
    for h in broad():
        if h["kind"] == "capability":
            assert h["domain"] == "implementation_evidence"
    out = ks.render(["date"], broad())
    assert "never settles a methodology" in out
    assert "different KINDS of authority, not degrees of one" in out


def test_a_capability_carries_its_per_engine_verification_into_the_result():
    """A `declared only` R side must not read the same as one a conformance test compares — that
    equivalence is what let the comorbidity divergence sit unnoticed."""
    hits = ks.search(["comorbidity"], kinds=["capability"])
    assert hits
    assert any("verified py=" in h["detail"] for h in hits), hits[0]["detail"]


def test_a_surface_its_own_validator_refuses_is_EXCLUDED_not_ranked():
    """FAIL CLOSED. A capability hit was reported as a checked claim without anyone calling
    `registry_errors` — the search asserted for free the very thing the registry exists to check."""
    import capability_registry as cr
    real = cr.registry_errors
    try:
        cr.registry_errors = lambda *a, **k: ["planted: the registry does not validate"]
        bad = ks.surface_errors()
        assert "capability" in bad, bad
        hits = ks.search(["comorbidity"], skip=set(bad))
        assert not any(h["kind"] == "capability" for h in hits), \
            "an unvalidated surface was still ranked"
        out = ks.render(["comorbidity"], hits, unusable=bad)
        assert "capability EXCLUDED" in out and "planted" in out
    finally:
        cr.registry_errors = real
    assert "capability" not in ks.surface_errors(), "the live surfaces must validate"


def test_the_live_surfaces_all_validate():
    """If one stops, the search says so rather than quietly ranking it — and this says so here."""
    assert ks.surface_errors() == {}, ks.surface_errors()


def test_a_citation_is_provenance_and_ranks_last():
    """A citation record says how a claim was CHECKED, never what it says. It must not read as an
    answer to the question asked."""
    assert ks.DOMAIN[-1][0] == "provenance"
    for h in broad():
        if h["kind"] == "citation":
            assert h["domain"] == "provenance"


def test_authority_is_computed_from_the_record_not_assumed_from_the_surface():
    """Two records in the same file, two authorities. A surface-level assumption would give the
    decision register one tier for everything it holds."""
    import knowledge_graph as kg
    nodes = kg.build(ks.ROOT)
    assert nodes, "no decision nodes — this test has lost its subject"
    resolved = [n for n in nodes if n["status"] == "RESOLVED"]
    assert resolved, "no RESOLVED decisions — this test has lost its subject"
    # The live repository holds zero SIGNED rulings; every resolved row is an unverified resolution,
    # and the search must say so rather than promoting it.
    hits = ks.search(["study", "window"], kinds=["decision"])
    for h in hits:
        assert h["state"] != "signed", \
            f"{h['id']} ranked as signed; no decision in this repository is"


def test_a_decision_required_record_is_an_open_question_not_a_resolution():
    hits = ks.search(["follow-up"], kinds=["contract_record"])
    assert hits
    for h in hits:
        if "requirement:decision_required" in h["detail"]:
            assert h["state"] == "open", h


def test_capabilities_carry_their_limits_into_the_result():
    """A capability that ships no code sets, or that answers a window rather than a line, has to
    say so where somebody is deciding whether to rely on it."""
    hits = ks.search(["comorbidity"], kinds=["capability"])
    assert hits and hits[0]["domain"] == "implementation_evidence"
    assert "LIMITS" in hits[0]["detail"] and "NO code sets" in hits[0]["detail"]


def test_restricting_to_a_surface_returns_only_that_surface():
    hits = ks.search(["date"], kinds=["capability"])
    assert hits and {h["kind"] for h in hits} == {"capability"}


def test_the_banner_survives_an_empty_result():
    """A search that finds nothing is exactly when a reader is most likely to go and reuse
    something they half-remember."""
    terms = ["zzqqxx-no-such-term"]
    hits = ks.search(terms)
    assert hits == []
    out = ks.render(terms, hits)
    assert "NOTHING BELOW IS AN APPROVAL" in out
    assert "not the same as" in out


def test_the_banner_states_that_a_ruling_binds_only_its_own_pack():
    out = ks.render(["date"], broad())
    assert "was decided for the pack it" in out
    assert "a new" in out and "decision that a person makes" in out


def test_json_output_carries_the_authority_ladder():
    import json
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        assert ks.main(["--json", "comorbidity"]) == 0
    doc = json.loads(buf.getvalue())
    assert doc["domain_order"] == [n for n, _ in ks.DOMAIN]
    # PER DOMAIN, matching the ranking. A flat list would tell a JSON consumer the old story —
    # that these states are one scale — which is the story the code no longer tells.
    assert doc["state_order"] == {d: [n for n, _ in ladder] for d, ladder in ks.STATES.items()}
    assert set(doc["state_order"]) == set(ks.DOMAIN_RANK)
    assert doc["hits"] and all("domain" in h and "state" in h for h in doc["hits"])
    for h in doc["hits"]:
        assert h["state"] in doc["state_order"][h["domain"]], h


def test_the_tool_writes_nothing():
    """Read-only by construction: a search that mutated a register while answering a question would
    be the worst possible place for a write."""
    src = (FRAMEWORK / "tools" / "knowledge_search.py").read_text(encoding="utf-8")
    for forbidden in ("open(", ".write(", "write_text", "os.remove", "shutil"):
        assert forbidden not in src, f"knowledge_search.py contains {forbidden}"


if __name__ == "__main__":
    # CI RUNS EVERY SUITE AS A SCRIPT — see the module docstring. Without this block the file runs
    # no tests and exits 0.
    bad = 0
    for _name, _fn in sorted(globals().items()):
        if _name.startswith("test_") and callable(_fn):
            try:
                _fn()
                print(f"  ok  {_name}")
            except Exception as _e:                  # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {_name}: {_e}")
    sys.exit(1 if bad else 0)
