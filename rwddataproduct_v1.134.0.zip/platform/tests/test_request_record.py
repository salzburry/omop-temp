"""A request's answer outlives the cut it came from — this is what stops it circulating unlabelled.

A data product's receipt binds a build to the config, source and approval it ran under, so the
question "where did this table come from" has an answer months later. A request produces a number,
a table or a slide, and gets asked the SAME question just as often, usually by someone who was not
there. `work/<id>/REQUEST.yaml` is that record.

The rule worth testing hardest is staleness, because it is the one that is easy to get wrong in
either direction:

  * too weak — a superseded citation is a note nobody reads, and last year's number goes on being
    quoted as current;
  * too strong — calling the old answer WRONG. It was not. It was computed correctly against a cut
    that has since been replaced.

So the refusal is narrow and says exactly that: a record may not go on claiming `status: answered`
against a superseded release. `superseded` and `withdrawn` are both accepted, because both record
that a person knows.

Run: python3 tests/test_request_record.py (or pytest).
"""
import shutil
import sys
import tempfile
from pathlib import Path

import yaml

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))

import request_record as rr      # noqa: E402

WHO = "T. Test"          # the repo's fixture person — never written into a real record
ANSWERED = {
    "request_id": "req-1", "title": "t", "question": "how many?",
    "requested_by": WHO, "requested_date": "2026-08-01",
    "analyst": WHO, "answered_date": "2026-08-14",
    "status": "answered",
    "derivation": {"method": "sql", "reference": "work/req-1/count.sql"},
    # DESCRIPTIVE + INTERNAL is the only combination a PACK-level citation satisfies, so the shared
    # fixture is that one and the quantitative/external cases below opt in explicitly. A fixture
    # that reported a count while citing a specification would have been the defect, in the file
    # that exists to catch it.
    "result": {"kind": "descriptive", "summary": "the window is stated in the specification"},
    "disclosure": "internal",
}

# A build-level citation: what a number, or an answer that leaves the group, has to name.
PINNED = [{"product": "testis", "spec_version": "202608",
           "build_id": "b-2026-08-16", "manifest_sha256": "c" * 64}]
PACK_ONLY = [{"product": "testis", "spec_version": "202608"}]


def _root(record=None, lineage=None, cites=None, rid="req-1"):
    """A throwaway repo root: one tumour (optionally with lineage), one registered request."""
    root = Path(tempfile.mkdtemp())
    (root / "products" / "oncology" / "testis" / "202608").mkdir(parents=True)
    t = {"code": "testis", "slug": "testis", "name": "Testis", "vendor": "flatiron",
         "tumor_class": "solid", "status": "scaffold"}
    if lineage:
        t["lineage"] = lineage
    reg = {"tumors": [t], "work": [{
        "id": rid, "kind": "request", "title": "t",
        "cites_release": cites if cites is not None
        else [{"product": "testis", "spec_version": "202608"}]}]}
    (root / "products" / "registry.yaml").write_text(yaml.safe_dump(reg), encoding="utf-8")
    if record is not None:
        p = root / "work" / rid
        p.mkdir(parents=True)
        (p / "REQUEST.yaml").write_text(yaml.safe_dump(record), encoding="utf-8")
    return root


def _entry(root, rid="req-1"):
    return next(w for w in yaml.safe_load(
        (root / "products" / "registry.yaml").read_text(encoding="utf-8"))["work"]
        if w["id"] == rid)


def _errs(root, rid="req-1"):
    return rr.record_errors(str(root), _entry(root, rid))


def _with(**over):
    d = {k: (dict(v) if isinstance(v, dict) else v) for k, v in ANSWERED.items()}
    d.update(over)
    return d


def test_a_registered_request_with_no_record_is_refused():
    """A citation nobody can read is not provenance."""
    root = _root(record=None)
    try:
        bad = _errs(root)
        assert any("no record at" in e for e in bad), bad
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_an_open_request_may_carry_markers():
    """An open request legitimately does not know its analyst or its answer yet. Requiring those
    up front is how a record stops being written at the time it is cheapest to write."""
    root = _root(record={"request_id": "req-1", "status": "open",
                         "requested_by": rr.MARK, "analyst": rr.MARK,
                         "answered_date": rr.MARK, "requested_date": rr.MARK})
    try:
        assert _errs(root) == []
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_an_answered_record_may_not_carry_a_marker_where_a_person_belongs():
    for field in rr.HUMAN_FIELDS:
        root = _root(record=_with(**{field: rr.MARK}))
        try:
            bad = _errs(root)
            assert any(field in e and "marker stands in" in e for e in bad), (field, bad)
        finally:
            shutil.rmtree(root, ignore_errors=True)


def test_an_answered_record_may_not_carry_a_marker_ANYWHERE():
    """THE FIELDS NOBODY REMEMBERED. The check read four human fields plus two nested ones, so an
    answered record could carry `title: REPLACE_ME` and a scaffold `question:` — the two things a
    reader quotes — and report clean. A remembered list is a copy of the template that ages on its
    own; the sweep walks the loaded record and has no list to fall behind."""
    for field in ("title", "question"):
        root = _root(record=_with(**{field: rr.MARK}))
        try:
            bad = _errs(root)
            assert any(f"`{field}` still holds" in e for e in bad), (field, bad)
            assert any("scaffold speaking in their place" in e for e in bad), (field, bad)
        finally:
            shutil.rmtree(root, ignore_errors=True)


def test_the_marker_sweep_reaches_nested_and_listed_values():
    root = _root(record=_with(derivation={"method": rr.MARK, "reference": "work/x.sql"}))
    try:
        assert any("`derivation.method` still holds" in e for e in _errs(root)), _errs(root)
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_an_open_record_is_not_swept():
    """The sweep applies once a person has signed the record. An open request is ALL markers, and
    refusing it would stop the record being written when it is cheapest to write."""
    root = _root(record={"request_id": "req-1", "status": "open", "title": rr.MARK,
                         "question": rr.MARK, "derivation": {"method": rr.MARK}})
    try:
        assert _errs(root) == []
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_an_answer_needs_a_rerunnable_derivation_and_a_quotable_summary():
    root = _root(record=_with(derivation={"method": "sql", "reference": rr.MARK}))
    try:
        assert any("derivation.reference" in e for e in _errs(root)), _errs(root)
    finally:
        shutil.rmtree(root, ignore_errors=True)
    root = _root(record=_with(result={"summary": rr.MARK}))
    try:
        assert any("result.summary" in e for e in _errs(root)), _errs(root)
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_number_may_not_cite_a_specification():
    """A COUNT IS ONLY TRUE OF ONE BUILD. "prostate 202606" names a specification; two cuts of it
    give two different counts, and the record would look equally correct against either."""
    root = _root(record=_with(result={"kind": "quantitative", "summary": "1234 patients"}),
                 cites=PACK_ONLY)
    try:
        bad = _errs(root)
        assert any("at PACK level" in e and "reports a number" in e for e in bad), bad
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_an_external_answer_may_not_cite_a_specification():
    """The answer most likely to outlive its cut is the one that left the group."""
    root = _root(record=_with(disclosure="external"), cites=PACK_ONLY)
    try:
        bad = _errs(root)
        assert any("at PACK level" in e and "leaves the group" in e for e in bad), bad
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_pinned_build_satisfies_both():
    for over, cites in ((dict(result={"kind": "quantitative", "summary": "1234 patients"}), PINNED),
                        (dict(disclosure="external"), PINNED)):
        root = _root(record=_with(**over), cites=cites)
        try:
            assert _errs(root) == [], _errs(root)
        finally:
            shutil.rmtree(root, ignore_errors=True)


def test_a_descriptive_internal_answer_may_cite_the_pack():
    """Not everything needs a build. An answer about what the SPECIFICATION says does not move with
    the data, and requiring a cut for it would make the rule noise people route around."""
    root = _root(record=_with(), cites=PACK_ONLY)
    try:
        assert _errs(root) == [], _errs(root)
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_the_answer_kind_is_stated_not_guessed():
    """No parser can tell "1234 patients" from a sentence that merely contains a number, and a
    heuristic would be wrong in the direction that matters — silently letting a count cite a spec."""
    root = _root(record=_with(result={"summary": "1234 patients"}), cites=PINNED)
    try:
        assert any("result.kind" in e for e in _errs(root)), _errs(root)
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_reference_without_a_method_is_not_a_derivation():
    """`reference` was required and `method` was not, so an answered record could carry a path with
    nothing saying what was run over it — and one with NO derivation block at all passed, because
    the walk returned None and only `reference` was inspected."""
    root = _root(record=_with(derivation={"reference": "work/req-1/count.sql"}), cites=PACK_ONLY)
    try:
        assert any("derivation.method" in e for e in _errs(root)), _errs(root)
    finally:
        shutil.rmtree(root, ignore_errors=True)
    rec = _with()
    del rec["derivation"]
    root = _root(record=rec, cites=PACK_ONLY)
    try:
        assert any("no `derivation:` block" in e for e in _errs(root)), _errs(root)
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_dates_and_enums_are_checked_on_an_answered_record():
    root = _root(record=_with(answered_date="14/08/2026"))
    try:
        assert any("not a YYYY-MM-DD" in e for e in _errs(root)), _errs(root)
    finally:
        shutil.rmtree(root, ignore_errors=True)
    root = _root(record=_with(disclosure="maybe"))
    try:
        assert any("internal or external" in e for e in _errs(root)), _errs(root)
    finally:
        shutil.rmtree(root, ignore_errors=True)
    root = _root(record=_with(status="finished"))
    try:
        assert any("is not one of" in e for e in _errs(root)), _errs(root)
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_the_record_and_its_registration_must_name_the_same_object():
    root = _root(record=_with(request_id="something-else"))
    try:
        assert any("does not match the registry id" in e for e in _errs(root)), _errs(root)
    finally:
        shutil.rmtree(root, ignore_errors=True)


LINEAGE = [{"spec_version": "202603", "status": "superseded"},
           {"spec_version": "202608", "supersedes": "202603", "status": "active"}]


def test_an_answer_against_a_superseded_cut_may_not_still_claim_to_be_current():
    """THE POINT. Narrow on purpose: the refusal names the two ways out and calls neither a
    correction, because the answer was right when it was given."""
    root = _root(record=_with(), lineage=LINEAGE,
                 cites=[{"product": "testis", "spec_version": "202603"}])
    try:
        bad = _errs(root)
        assert any("is superseded" in e for e in bad), bad
        assert any("replaced by 202608" in e for e in bad), bad
        assert any("status: superseded" in e and "re-answer" in e for e in bad), bad
        assert not any("wrong" in e.lower() or "incorrect" in e.lower() for e in bad), \
            "the refusal calls the old answer wrong — it was correct against the cut it cited"
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_recording_that_the_supersession_is_known_clears_it():
    for status in ("superseded", "withdrawn"):
        root = _root(record=_with(status=status), lineage=LINEAGE,
                     cites=[{"product": "testis", "spec_version": "202603"}])
        try:
            assert not any("is superseded" in e for e in _errs(root)), status
        finally:
            shutil.rmtree(root, ignore_errors=True)


def test_an_answer_against_the_current_cut_is_not_stale():
    root = _root(record=_with(), lineage=LINEAGE,
                 cites=[{"product": "testis", "spec_version": "202608"}])
    try:
        assert _errs(root) == [], _errs(root)
        assert rr.superseded_citations(str(root), _entry(root)) == []
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_new_scaffolds_markers_and_refuses_to_regenerate():
    root = Path(tempfile.mkdtemp())
    old = rr.REPO
    rr.REPO = str(root)
    try:
        assert rr.main(["--new", "req-9"]) == 0
        path = root / "work" / "req-9" / rr.RECORD
        text = path.read_text(encoding="utf-8")
        assert text.count(rr.MARK) >= 8, "the scaffold pre-filled something a person owns"
        doc = yaml.safe_load(text)
        assert doc["request_id"] == "req-9"
        assert doc["status"] == "open", "a scaffold may only ever write the status nobody signed"
        assert rr.main(["--new", "req-9"]) == 1, "a second run regenerated a record"
        assert path.read_text(encoding="utf-8") == text
        for bad in ("", "a/b", "."):
            if bad in (".",):      # a lone dot is a directory name, caught by the exists check
                continue
            assert rr.main(["--new", bad]) == 1, bad
    finally:
        rr.REPO = old
        shutil.rmtree(root, ignore_errors=True)


def test_the_live_repository_registers_no_request_and_the_check_is_quiet():
    """Nothing invented. The tool reports the real state rather than a demo one."""
    assert rr.check(str(REPO)) == []
    assert not (REPO / "work").exists(), \
        "a work/ directory exists but no request is registered — one of the two is wrong"


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
