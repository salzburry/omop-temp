"""The benchmark must measure, and the clinical layer must stay unscored.

Two failure modes a benchmark can have, and the tests aim at both:

  * IT FLATTERS — a harness that reports 100% whatever the copilot does is decoration. Proved by
    degrading the copilot (candidates reversed) and watching the numbers move.
  * IT OVERREACHES — a number appearing under "clinical" would be quoted as one. The separation of
    the engineering layer (scored) from the clinical layer (constitutionally unscored) was an
    explicit user instruction, and the structure is pinned here.

The UNSAFE count doubles as a regression gate: on packs whose mappings people approved, a copilot
change that starts confidently proposing wrong tables must fail this suite, because that is the
copilot doing the thing the whole recommend->validate->approve workflow exists to prevent.

Run: python3 tests/test_mapping_benchmark.py (or pytest). Spark parts skip without pyspark; the
pure parts run regardless.
"""
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))

import mapping_benchmark as mb   # noqa: E402

try:
    from pyspark.sql import SparkSession
except Exception:                                    # pragma: no cover - env without pyspark
    SparkSession = None

PROSTATE = str(REPO / "products" / "oncology" / "prostate" / "202606")

_RESULT = None


def _result():
    """One scored run, shared — score_pack copies the pack and runs the copilot 13 times, and
    doing that per test would triple a cost the assertions do not need repeated."""
    global _RESULT
    if _RESULT is None:
        tmp = tempfile.mkdtemp(prefix="mb_test_")
        try:
            _RESULT = mb.score_pack(PROSTATE, tmp)
        finally:
            import shutil
            shutil.rmtree(tmp, ignore_errors=True)
    return _RESULT


def test_the_engineering_layer_scores_and_the_unsafe_count_is_zero():
    """The regression gate. Prostate's mappings are approved; a copilot that map_candidates a
    WRONG table for any of them has become the silent-closest-name picker with a confidence label,
    and this failing is the benchmark doing its job — never 'fix' it by relaxing the assertion."""
    if SparkSession is None:
        print("SKIP (pyspark absent)")
        return
    e = _result()["engineering"]
    assert e["scored_roles"] >= 10, e["scored_roles"]
    assert e["unsafe"] == 0, [r for r in e["rows"] if r["outcome"] == "unsafe"]
    # measured floors, generous on purpose: these fail on collapse, not on a percent of drift
    assert e["top3"] >= e["scored_roles"] // 2, (e["top3"], e["scored_roles"])
    assert e["top1"] >= 1, "the copilot cannot place a single known mapping first"
    # skipped roles are named, never silently dropped from the denominator. `ses` stays skipped
    # (an engine-guarded degrade, deliberately not availability-required); `demographics` used
    # to sit here too and is now SCORED — the typed dependency model made the hard read visible,
    # so blinding it raises a real gap. Both directions pinned.
    assert "ses" in e["skipped_roles"], e["skipped_roles"]
    assert "demographics" not in e["skipped_roles"], \
        "the demographics hard read fell back out of the availability model"


def test_the_clinical_layer_carries_no_score_by_construction():
    """An explicit user instruction, held structurally: `clinical.scored` is None, the reason names
    who owns the question, and no numeric appears anywhere under the clinical key."""
    if SparkSession is None:
        print("SKIP (pyspark absent)")
        return
    c = _result()["clinical"]
    assert c["scored"] is None
    assert "RWP" in c["why"] and "no mechanical ground truth" in c["why"]
    import json
    flat = json.dumps(c)
    assert not any(ch.isdigit() for ch in flat), \
        f"a number under the clinical layer will be quoted as a score: {flat}"


def test_a_degraded_copilot_degrades_the_numbers():
    """A benchmark the subject cannot fail is decoration. Reverse the candidate ranking and top-1
    must fall; unsafe may rise — and the assertion is only that the numbers MOVED, because the
    property under test is sensitivity, not any particular wrongness."""
    if SparkSession is None:
        print("SKIP (pyspark absent)")
        return
    import propose_source_mapping as psm
    baseline = _result()["engineering"]
    real = psm.candidates

    def reversed_candidates(gap, tables, grain_decl, top=3):
        out = real(gap, tables, grain_decl, top=9999)
        out.reverse()
        return out[:top]

    psm.candidates = reversed_candidates
    try:
        tmp = tempfile.mkdtemp(prefix="mb_degraded_")
        try:
            degraded = mb.score_pack(PROSTATE, tmp)["engineering"]
        finally:
            import shutil
            shutil.rmtree(tmp, ignore_errors=True)
    finally:
        psm.candidates = real
    assert degraded["top1"] < baseline["top1"], (degraded["top1"], baseline["top1"])


def test_total_abstention_and_floor_collapse_are_exit_material():
    """The hole an external review named: unsafe==0 was the ONLY exit criterion, so a copilot
    that abstained on every role passed with a perfect safety score while delivering nothing.
    Pure, both directions: today's measured numbers raise nothing; total abstention and a top-1
    collapse each fail by name; a pack with no recorded baseline still fails on unsafe and only
    on unsafe (a floor cannot be invented for it)."""
    def result(pack, top1, top3, abstained, unsafe):
        return {"pack": pack, "engineering": {"top1": top1, "top3": top3,
                                              "abstained": abstained, "unsafe": unsafe}}
    healthy = result("products/oncology/prostate/202606", 11, 14, 8, 0)
    assert mb.floor_failures([healthy]) == [], mb.floor_failures([healthy])
    collapsed = result("products/oncology/prostate/202606", 0, 0, 13, 0)
    why = mb.floor_failures([collapsed])
    assert any("abstention must never read as a pass" in w for w in why), why
    assert any("top-1" in w for w in why) and any("top-3" in w for w in why), why
    unknown = result("products/oncology/newpack/202607", 0, 0, 20, 1)
    why = mb.floor_failures([unknown])
    assert len(why) == 1 and "unsafe" in why[0], why


def test_the_frozen_holdout_scores_clean():
    """The committed snapshot (fixtures/holdout_profile_prostate_202606.tsv) is evidence the
    ranking cannot reshape: the live synthetic profile is derived through required_columns —
    partly the same machinery being scored — so a code change can move the evidence and the
    score together. The frozen bytes cannot drift. The floor here is deliberately the SAFETY
    one only: unsafe stays 0 and the copilot still places most truths first, whatever the live
    profile machinery does.

    NO Spark guard, deliberately: with an explicit profile= the scoring path is pure
    (synthetic_profile, the only Spark consumer, is bypassed), so this runs — and must run —
    in the pure CI job too. Decoys OFF: they are derived from the current required_columns,
    the code under test, and layering them onto frozen evidence hands the independence claim
    right back."""
    holdout = FRAMEWORK / "tests" / "fixtures" / "holdout_profile_prostate_202606.tsv"
    assert holdout.exists(), "the frozen holdout fixture is gone — regenerate and re-commit it"
    tmp = tempfile.mkdtemp(prefix="mb_holdout_")
    try:
        e = mb.score_pack(PROSTATE, tmp, profile=str(holdout),
                          adversarial=False)["engineering"]
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    assert e["unsafe"] == 0, [r for r in e["rows"] if r["outcome"] == "unsafe"]
    assert e["top1"] >= e["scored_roles"] // 2, (e["top1"], e["scored_roles"])


def test_the_blind_refuses_to_guess():
    """`_strip_role` must remove exactly one line or stop — a blind that silently removed nothing
    would benchmark the copilot against a pack that still declares the answer."""
    tmp = tempfile.mkdtemp(prefix="mb_strip_")
    try:
        import shutil
        pack = Path(tmp) / "pack"
        (pack / "config").mkdir(parents=True)
        (pack / "config" / "data_product.yaml").write_text(
            "sources:\n  enhanced: t_x\n", encoding="utf-8")
        mb._strip_role(str(pack), "enhanced")
        assert "enhanced" not in (pack / "config" / "data_product.yaml").read_text(encoding="utf-8")
        try:
            mb._strip_role(str(pack), "nosuch")
        except SystemExit as e:
            assert "exactly one line" in str(e)
        else:
            raise AssertionError("stripping an absent role did not stop")
        shutil.rmtree(tmp, ignore_errors=True)
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
