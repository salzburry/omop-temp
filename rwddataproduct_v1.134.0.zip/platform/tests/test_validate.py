"""Tests for the config/codelist validator. Run: python tests/test_validate.py (or pytest).

Pure Python (no Spark): exercises problems()/check() on the real config and on deliberately
broken copies (unfilled placeholder, duplicate code, misplaced catch-all).
"""
import copy
import json
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent   # _framework/ (the shared engine lives here)
sys.path.insert(0, str(FRAMEWORK))

from engine.config import load_config   # noqa: E402
from engine.config import product_config  # noqa: E402
from engine import validate                      # noqa: E402

CONFIG = product_config(FRAMEWORK.parent / "products", "prostate")   # reference tumor
GOOD = {"run.refresh": "2026q1", "run.source_schema": "rwd", "run.output_schema": "out"}


def test_real_config_lints_clean():
    # Lint mode (placeholders allowed) on the shipped config must be clean.
    assert validate.problems(load_config(CONFIG), strict=False) == []


def test_every_versioned_pack_lints_clean():
    # CI lints EVERY spec-version pack (incl. superseded like prostate 202603) via the same glob. A
    # validator change a historical pack can't satisfy must fail HERE, not only in CI — this guards the
    # regression where the bmi_formula->bmi_method migration once broke 202603's lint.
    products = FRAMEWORK.parent / "products"
    packs = sorted(products.glob("oncology/*/*/config/data_product.yaml"))
    assert packs, "no versioned packs found"
    failures = {str(p.relative_to(products)).replace("/config/data_product.yaml", ""): probs
                for p in packs if (probs := validate.problems(load_config(str(p)), strict=False))}
    assert not failures, f"versioned packs failing lint: {failures}"


def test_filled_config_passes_strict():
    cfg = load_config(CONFIG, overrides=GOOD)
    assert validate.problems(cfg, strict=True) == []
    validate.check(cfg)            # must not raise


def test_placeholder_fails_strict():
    cfg = load_config(CONFIG)      # run.* still REPLACE_ME
    probs = validate.problems(cfg, strict=True)
    assert any("REPLACE_ME" in p for p in probs)


def test_prod_placeholder_substring_fails_strict():
    # A non-exact prod placeholder (REPLACE_ME_prod_source) must STILL fail strict validation.
    cfg = load_config(CONFIG, overrides={**GOOD, "run.source_schema": "REPLACE_ME_prod_source"})
    assert any("REPLACE_ME_prod_source" in p and "source_schema" in p
               for p in validate.problems(cfg, strict=True))
    # lint mode (placeholders allowed) must NOT flag it
    assert not any("source_schema" in p for p in validate.problems(cfg, strict=False))
    try:
        validate.check(cfg)
    except RuntimeError as e:
        assert "REPLACE_ME" in str(e)
    else:
        raise AssertionError("check() should have raised on REPLACE_ME")


def _cfg_with_codelist(cats):
    """Build a Config whose treatment_categories codelist is replaced in-memory."""
    cfg = load_config(CONFIG, overrides=GOOD)
    cl = copy.deepcopy(cfg.codelist("treatment_categories"))
    cl["categories"] = cats
    cfg._codelists["treatment_categories"] = cl   # override the cached codelist
    return cfg


def test_missing_required_source_detected():
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.sources.pop("mortality")                # a REQUIRED-core source
    probs = validate.problems(cfg)
    assert any("missing required mapping 'mortality'" in p for p in probs)


def test_optional_source_not_required():
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.sources.pop("alphabet")                 # optional (prostate-only) — must NOT be flagged
    assert validate.problems(cfg) == []


def test_index_source_must_be_declared():
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.index_dates["advanced_diagnosis_date"]["source"] = "not_a_source"
    assert any("index source 'not_a_source'" in p for p in validate.problems(cfg))


def test_linesetting_required_only_with_line_setting():
    cfg = load_config(CONFIG, overrides=GOOD)                       # prostate: lot.line_setting mCRPC
    assert "linesetting" in validate.required_columns(cfg)["lot"]
    cfg.raw.pop("lot", None)                                        # clear the GLOBAL setting...
    for c in cfg.cohorts:
        c.pop("line_setting", None)                                # ...AND every cohort's (heme-like: none)
    assert "linesetting" not in validate.required_columns(cfg)["lot"]


def test_lot_line_number_validation():
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.raw.setdefault("lot", {})["line_number"] = "bogus"
    assert any("lot.line_number 'bogus'" in p for p in validate.problems(cfg))


def test_cohort_maintenance_must_be_bool():
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.cohorts[1]["maintenance"] = "yes"                            # not a bool
    assert any("maintenance must be true/false" in p for p in validate.problems(cfg))


def test_maintenance_cohort_requires_flag_column():
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.cohorts[1]["maintenance"] = True                            # a cohort now filters on the flag
    assert "ismaintenancetherapy" in validate.required_columns(cfg)["lot"]
    cfg2 = load_config(CONFIG, overrides=GOOD)                       # no maintenance cohort (prostate)
    assert "ismaintenancetherapy" not in validate.required_columns(cfg2)["lot"]


def test_oc_config_lints_clean():
    OC = product_config(FRAMEWORK.parent / "products", "oc")   # maintenance cohorts + linenumber model
    assert validate.problems(load_config(OC), strict=False) == []


def test_ec_config_lints_clean():
    EC = product_config(FRAMEWORK.parent / "products", "endometrial")  # source_union + maintenance
    assert validate.problems(load_config(EC), strict=False) == []


def test_min_avail_date_required_columns():
    # EVERY configured min_avail_date column is preflighted on its (declared) source — no silent skip.
    OC = product_config(FRAMEWORK.parent / "products", "oc")
    oc = load_config(OC)
    req = validate.required_columns(oc)
    assert "episodedate" in req.get("drug_episode", [])
    assert "visitdate" in req.get("visit", [])
    assert "testdate" in req.get("lab", [])                      # lab date column required, not skipped
    assert "diagnosisdate" in req.get(oc.index_source, [])       # base column
    EC = product_config(FRAMEWORK.parent / "products", "endometrial")
    ec = load_config(EC)
    assert "advanceddiagnosisdate" in validate.required_columns(ec).get(ec.index_source, [])


def test_passthrough_required_columns():
    # passthrough columns + flag source columns are preflighted on the index source.
    pc = load_config(CONFIG)                                       # prostate gleason/PSA pass-through
    assert "gleasonscore" in validate.required_columns(pc).get(pc.index_source, [])
    EC = product_config(FRAMEWORK.parent / "products", "endometrial")
    ec = load_config(EC)                                           # EC radiation pass-through + flag
    ecreq = validate.required_columns(ec).get(ec.index_source, [])
    assert "radiationtype" in ecreq and "radiationtherapydate" in ecreq


def test_preflight_report_confirms_present_and_flags_missing():
    # preflight_report() is the readable schema-validation form of preflight(): per source table, which
    # required columns are present in the (fixture) delivered schema. Config-driven — columns come from
    # required_columns(), tables from sources: — so it validates exactly what the build reads.
    cfg = load_config(CONFIG, overrides=GOOD)
    req = validate.required_columns(cfg)
    fqn_cols, drop = {}, None
    for name in cfg.sources:
        cols = list(req.get(name, ["patientid"]))
        for fqn in cfg.source_fqns(name):
            fqn_cols[fqn] = cols
            if drop is None and cols:
                drop = (name, fqn, cols[0])
    assert drop, "no required columns found"
    # every configured column present -> ok
    assert validate.preflight_report(cfg, lambda fqn: list(fqn_cols[fqn]))["ok"]
    # drop one required column -> flagged as missing, report not ok, surfaced in the markdown
    tname, tfqn, tcol = drop
    bad = validate.preflight_report(cfg, lambda fqn: [c for c in fqn_cols[fqn] if not (fqn == tfqn and c == tcol)])
    assert not bad["ok"]
    assert tcol in bad["sources"][tname]["tables"][0]["missing"]
    md = validate.preflight_report_md(bad)
    assert tcol in md and "❌" in md
    # an unreadable table (wrong stem) is flagged, not swallowed
    unreadable = validate.preflight_report(cfg, lambda fqn: (_ for _ in ()).throw(RuntimeError("no such table")))
    assert not unreadable["ok"]
    assert any(not t["readable"] for s in unreadable["sources"].values() for t in s["tables"])


def test_preflight_report_records_optional_columns_and_observed_types():
    # Optional configured columns (conmed drugname/episodedate; PSA-diagnosis passthroughs) are REPORTED
    # present/absent — never fatal — so the evidence shows EVERY configured column, not only hard-required
    # ones. A dict reader (name->type) captures observed types.
    cfg = load_config(CONFIG, overrides=GOOD)
    opt = validate.optional_columns(cfg)
    # PSA-at-diagnosis passthroughs are `optional: true` — genuinely feed-dependent, never fatal. They must
    # be reported (present/absent) so a schema-evidence run shows every configured column.
    assert "enhanced" in opt and "psainitialdiagnosis" in opt["enhanced"], \
        "optional:true passthrough columns must be reported as optional"
    req = validate.required_columns(cfg)

    def _reader(include_psa):
        def reader(fqn):
            cols = {}
            for name in cfg.sources:
                if fqn in cfg.source_fqns(name):
                    for c in req.get(name, ["patientid"]):
                        cols[c] = "string"
                    if name == "enhanced" and include_psa:
                        cols["psainitialdiagnosis"] = "double"   # present optional, typed
            return cols
        return reader

    # optional PRESENT: reported present, observed type captured.
    rep = validate.preflight_report(cfg, _reader(include_psa=True))
    assert rep["ok"]
    enh = rep["sources"]["enhanced"]["tables"][0]
    assert enh["optional_present"].get("psainitialdiagnosis") is True
    assert enh["types"].get("psainitialdiagnosis") == "double"   # observed type from the dict reader

    # optional ABSENT: still ok (optional never fails), but recorded absent so the evidence shows it.
    rep2 = validate.preflight_report(cfg, _reader(include_psa=False))
    assert rep2["ok"], "an absent OPTIONAL column must not fail the report"
    assert rep2["sources"]["enhanced"]["tables"][0]["optional_present"].get("psainitialdiagnosis") is False

    md = validate.preflight_report_md(rep2)
    assert "BUILD-REQUIRED" in md and "Optional present" in md and "psainitialdiagnosis" in md


def test_conmed_name_column_required_when_flags_configured():
    # conmed_bp/csf/steroid are configured, so drugname is REQUIRED — its absence would silently drop all
    # three published conmed outputs. required_columns must include it, and preflight must FAIL when absent.
    cfg = load_config(CONFIG, overrides=GOOD)
    assert cfg.pack("treatment")["conmed_exposures"]["flags"]                 # prostate configures them
    assert "drugname" in validate.required_columns(cfg)["drug_episode"]
    # preflight fails loudly when drugname is missing (not a silent drop).
    req = validate.required_columns(cfg)
    fqn_cols = {fqn: [c for c in req.get(name, ["patientid"]) if c != "drugname"]
                for name in cfg.sources for fqn in cfg.source_fqns(name)}
    rep = validate.preflight_report(cfg, lambda fqn: fqn_cols[fqn])
    assert not rep["ok"] and "drugname" in rep["sources"]["drug_episode"]["tables"][0]["missing"]
    # remove the flags -> drugname is no longer required (nothing else reads it).
    cfg2 = load_config(CONFIG, overrides=GOOD)
    cfg2.pack("treatment")["conmed_exposures"]["flags"] = []
    assert "drugname" not in validate.required_columns(cfg2).get("drug_episode", [])


def test_conmed_date_column_conditional_on_window():
    # Isolate conmed as the only episodedate driver (drop line_outcomes + use a codelist without
    # category_equals) so the window toggle is observable.
    cfg = _cfg_with_codelist([{"code": 1, "label": "A", "match": {"equals": "a"}},
                              {"code": 16, "label": "Any other therapy", "match": {"always": True}}])
    cfg.pack("outcomes").pop("line_outcomes", None)
    ce = cfg.pack("treatment")["conmed_exposures"]
    ce["window_days"] = [None, None]                    # any-time -> date NOT read -> optional
    assert "episodedate" not in validate.required_columns(cfg).get("drug_episode", [])
    assert "episodedate" in validate.optional_columns(cfg).get("drug_episode", [])
    ce["window_days"] = [-30, 0]                         # a real window reads the date -> REQUIRED
    assert "episodedate" in validate.required_columns(cfg)["drug_episode"], \
        "a windowed conmed exposure must require its date column (else it silently evaluates over all time)"


def test_preflight_evidence_envelope_has_provenance_and_presence_status():
    cfg = load_config(CONFIG, overrides=GOOD)
    req = validate.required_columns(cfg)
    fqn_cols = {fqn: list(req.get(name, ["patientid"]))
                for name in cfg.sources for fqn in cfg.source_fqns(name)}
    rep = validate.preflight_report(cfg, lambda fqn: fqn_cols[fqn])
    ev = validate.preflight_evidence(cfg, rep, generated_at="2026-07-22T00:00:00+00:00", git_commit="abc123")
    assert ev["schema_presence"] == "passed_live" and ev["ok"] is True   # presence status, NOT source-verified
    assert ev["data_product_id"] == cfg.data_product_id and ev["spec_version"] == cfg.spec_version
    assert ev["data_refresh"] == cfg.refresh and ev["source_schema"] == cfg.source_schema
    assert ev["git_commit"] == "abc123" and ev["generated_at"].startswith("2026")
    json.dumps(ev)   # must be JSON-serializable (machine-readable evidence)


def test_preflight_honors_panoramic_renames():
    # Under a non-EDM format, a required LOGICAL column is satisfied by its PHYSICAL name (renamed at
    # load); without the rename overlay the same physical-only table fails preflight.
    from engine.config import Config
    from pathlib import Path
    raw = {"run": {"source_schema": "s", "refresh": "r", "data_format": "Panoramic"},
           "vendor": "flatiron", "sources": {"enhanced": "enh"},
           "index_dates": {"advanced_diagnosis_date": {"of": ["linename"]}},   # force 'linename' required
           "formats": {"Panoramic": {"rename": {"enhanced": {"RegimenName": "linename"}}}}}
    reader = lambda fqn: ["patientid", "RegimenName"]                          # physical, no 'linename'
    assert validate.preflight(None, Config(raw, Path(".")), _table_reader=reader) is True
    try:
        validate.preflight(None, Config({**raw, "formats": {}}, Path(".")), _table_reader=reader)
        assert False, "preflight should fail when the physical column is not renamed to the logical one"
    except RuntimeError as e:
        assert "linename" in str(e)


def test_data_format_without_overlay_flagged():
    cfg = load_config(CONFIG, overrides={**GOOD, "run.data_format": "Panoramic"})   # no formats.Panoramic
    assert any("no `formats.Panoramic` overlay" in p for p in validate.problems(cfg))


def test_formats_rename_undeclared_source_flagged():
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.raw["formats"] = {"Panoramic": {"rename": {"nosuchsource": {"a": "b"}}}}
    assert any("references undeclared source 'nosuchsource'" in p for p in validate.problems(cfg))


def test_source_union_member_validation():
    cfg = load_config(CONFIG, overrides=GOOD)                       # prostate + a broken union
    cfg.raw["source_union"] = {"discriminator": "db", "members": [{"flag": "X"}]}  # member missing schema
    assert any("source_union.members[0] missing 'schema'" in p for p in validate.problems(cfg))


def test_clinical_categorical_missing_field_flagged():
    cfg = load_config(CONFIG, overrides=GOOD)
    clin = cfg.pack("clinical")                                     # cached dict (same object)
    clin["categoricals"] = [{"name": "grade", "column": "grade"}]   # missing 'groups'
    assert any("clinical.categoricals[0] missing 'groups'" in p for p in validate.problems(cfg))


def test_clinical_categorical_source_must_be_declared():
    # A typo'd explicit source must fail validation (else it lint-clean-skips the variable at runtime).
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.pack("clinical")["categoricals"] = [
        {"name": "grade", "column": "grade", "source": "enhnaced",   # typo of 'enhanced'
         "groups": [{"code": 1, "label": "G1", "from_equals_ci": ["g1"]}]}]
    assert any("categoricals[0].source 'enhnaced' is not a declared source"
               in p for p in validate.problems(cfg))


def test_windowed_categorical_needs_a_date_and_a_well_formed_window():
    """`window_days` turns a categorical into "the value AT INDEX". Both refusals here exist because
    the alternative is answering the OTHER question while the config says this one.

    Without `date_column` the engine has no date to measure the window from. The nearest thing it
    could do is fall back to the unwindowed pick — the patient's latest value ever — which is a
    different variable wearing the same name. And `pick: priority` ranks the rows INSIDE a window;
    with one row per patient there is nothing to rank, so a priority pick with no window is a
    setting that silently does nothing.
    """
    groups = [{"code": 1, "label": "Commercial", "from_equals_ci": ["commercial"]}]
    def problems(cat):
        cfg = load_config(CONFIG, overrides=GOOD)
        cfg.pack("clinical")["categoricals"] = [dict({"name": "payer", "column": "payertype",
                                                      "groups": groups}, **cat)]
        return validate.problems(cfg)

    assert any("window_days without date_column" in p
               for p in problems({"window_days": [-90, 30]}))
    assert any("window_days must be [lo, hi]" in p
               for p in problems({"date_column": "coveragedate", "window_days": [-90]}))
    assert any("window_days must be [lo, hi]" in p
               for p in problems({"date_column": "coveragedate", "window_days": "[-90, 30]"}))
    assert any("picks 'priority' without window_days" in p
               for p in problems({"date_column": "coveragedate", "pick": "priority"}))
    # ...and the well-formed windowed shape raises none of them. An open-ended bound is legal.
    for wd in ([-90, 30], [None, 0], [-365, None]):
        bad = [p for p in problems({"date_column": "coveragedate", "window_days": wd})
               if "categoricals" in p]
        assert not bad, (wd, bad)


def test_comorbidity_index_refuses_the_ways_it_can_be_quietly_wrong():
    """Every refusal here is a config that RUNS and produces a plausible number.

    No lookback is the worst of them: baseline comorbidity is defined by its pre-index window, and
    without one the score counts diagnoses made AFTER index — a confounder that has partly measured
    the outcome. It scores, it looks reasonable, and it is the wrong variable.

    A missing weight would default to 1 and silently flatten a weighted index into a count of
    conditions. A repeated condition name makes `supersedes` ambiguous and double-counts. A
    `supersedes` naming a condition that is not in the list reads on the page as a hierarchy being
    applied and does nothing at all.
    """
    base = {"source": "diagnosis", "name": "cci", "code_column": "dxcode",
            "code_system": "icd10cm", "date_column": "dxdate", "window_days": [-365, -1],
            "conditions": [{"name": "mi", "weight": 1, "code_prefix_any": ["I21"]}]}

    def problems(**over):
        cfg = load_config(CONFIG, overrides=GOOD)
        cfg.pack("clinical")["comorbidity_index"] = dict(base, **over)
        return [p for p in validate.problems(cfg) if "comorbidity_index" in p]

    assert not problems(), problems()
    assert any("no window_days" in p for p in problems(window_days=None))
    assert any("window_days without date_column" in p for p in problems(date_column=None))
    assert any("has no 'weight'" in p
               for p in problems(conditions=[{"name": "mi", "code_prefix_any": ["I21"]}]))
    assert any("repeats the condition name" in p for p in problems(conditions=[
        {"name": "mi", "weight": 1, "code_prefix_any": ["I21"]},
        {"name": "mi", "weight": 2, "code_prefix_any": ["I22"]}]))
    assert any("is not a condition in this list" in p for p in problems(conditions=[
        {"name": "liver_severe", "weight": 3, "code_prefix_any": ["K72"],
         "supersedes": ["liver_mild"]}]))
    assert any("needs exactly one match operator" in p for p in problems(conditions=[
        {"name": "mi", "weight": 1, "code_prefix_any": ["I21"], "code_in": ["I21.0"]}]))
    assert any("is not a declared source" in p for p in problems(source="diagnoses"))

    # --- the window, which an external review found accepted almost anything --------------------
    # Truthiness was the only test, so every one of these passed and produced a plausible score.
    assert any("ends 30 days AFTER index" in p for p in problems(window_days=[-365, 30])), \
        "a window running past index was accepted — the covariate has measured the outcome"
    assert any("ends 90 days AFTER index" in p for p in problems(window_days=[30, 90]))
    assert any("is reversed" in p for p in problems(window_days=[-1, -365]))
    for bad in ([-365], [-365, None], "[-365, -1]", True, [-365, "x"]):
        assert any("must be two integer day offsets" in p for p in problems(window_days=bad)), bad
    # ...and a post-index tail IS allowed when the pack says the choice was reviewed, because coding
    # lag is a real claims-design decision. It must be stated, not defaulted.
    assert not [p for p in problems(window_days=[-365, 30],
                                    post_index_days_reviewed="claims lag, RWB 2026-02")
                if "AFTER index" in p]

    # --- the hierarchy, which must not depend on the order the YAML happens to list ---------------
    chain = [{"name": "mild", "weight": 1, "code_prefix_any": ["K70"]},
             {"name": "moderate", "weight": 2, "code_prefix_any": ["K71"], "supersedes": ["mild"]},
             {"name": "severe", "weight": 3, "code_prefix_any": ["K72"], "supersedes": ["moderate"]}]
    assert not [p for p in problems(conditions=chain) if "cycle" in p or "supersedes itself" in p]
    assert any("supersedes itself" in p for p in problems(conditions=[
        {"name": "a", "weight": 1, "code_prefix_any": ["A"], "supersedes": ["a"]}]))
    assert any("cycle" in p for p in problems(conditions=[
        {"name": "a", "weight": 1, "code_prefix_any": ["A"], "supersedes": ["b"]},
        {"name": "b", "weight": 1, "code_prefix_any": ["B"], "supersedes": ["a"]}]))


def test_clinical_staging_source_must_be_declared():
    # A staging source typo must fail validation, else `stage` silently disappears from the ADS.
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.pack("clinical")["staging"] = {"source": "nosuchsource",
                                       "groups": [{"code": 1, "label": "I", "from_prefixes": ["I"]}]}
    assert any("clinical.staging.source 'nosuchsource' is not a declared source"
               in p for p in validate.problems(cfg))


def test_vitals_formula_methods_validated():
    # BMI/BSA formulas are NAMED and resolved from a fixed engine registry; the shipped config uses valid
    # names and lints clean. The validator method sets are DERIVED from the engine registries.
    cfg = load_config(CONFIG, overrides=GOOD)
    assert not any("bmi_method" in p or "bsa_method" in p for p in validate.problems(cfg))
    assert validate.BMI_METHODS == set(validate.BMI_FORMULAS)      # derived, not duplicated
    assert validate.BSA_METHODS == set(validate.BSA_FORMULAS)
    assert "mosteller" not in validate.BSA_METHODS                 # dropped (YAGNI) — re-add on request
    # unknown method names are rejected
    vit = cfg.pack("clinical")["vitals"]                           # cached dict (same object)
    vit["bmi_method"], vit["bsa_method"] = "eyeball", "guess"
    probs = validate.problems(cfg)
    assert any("clinical.vitals.bmi_method 'eyeball'" in p for p in probs)
    assert any("clinical.vitals.bsa_method 'guess'" in p for p in probs)


def test_bmi_method_required_when_vitals_configured():
    # bmi_method must be a non-empty string when vitals is on — null / empty / wrong-type / missing all
    # fail (this is the Python/R null-divergence class the engines now also default identically).
    for bad in (None, "", [], {}):
        cfg = load_config(CONFIG, overrides=GOOD)
        cfg.pack("clinical")["vitals"]["bmi_method"] = bad
        assert any("bmi_method is required" in p for p in validate.problems(cfg)), bad
    cfg = load_config(CONFIG, overrides=GOOD)
    del cfg.pack("clinical")["vitals"]["bmi_method"]
    assert any("bmi_method is required" in p for p in validate.problems(cfg))


def test_legacy_bmi_bsa_formula_keys_flagged():
    # The decorative bmi_formula/bsa_formula strings the engine no longer reads must be flagged so an old
    # config editing them (with no effect) can't pass silently.
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.pack("clinical")["vitals"]["bsa_formula"] = "0.007184 * height^0.725 * weight^0.425"
    assert any("bsa_formula is a legacy decorative key" in p for p in validate.problems(cfg))


def test_follow_up_sources_structural_validation():
    # The shipped dict-form follow_up_sources lints clean; the LOT alias is pinned and filter_method is
    # validated against the engine FOLLOWUP_FILTERS registry.
    assert not any("follow_up_sources" in p
                   for p in validate.problems(load_config(CONFIG, overrides=GOOD)))
    cfg = load_config(CONFIG, overrides=GOOD)
    for s in cfg.pack("clinical")["death_date_imputation"]["follow_up_sources"]:
        if s.get("source") == "lot":
            s["alias"] = "last_lot"
    assert any("must use alias 'last_lotenddate'" in p for p in validate.problems(cfg))
    cfg2 = load_config(CONFIG, overrides=GOOD)
    for s in cfg2.pack("clinical")["death_date_imputation"]["follow_up_sources"]:
        if s.get("source") == "orals":
            s["filter_method"] = "nope"
    assert any("filter_method 'nope'" in p for p in validate.problems(cfg2))


def test_follow_up_sources_filter_method_type_and_conflict():
    # A non-string filter_method (e.g. an empty list) raises an unhashable-key TypeError that
    # the outer except swallowed, so the malformed config passed lint. It must now be flagged.
    cfg = load_config(CONFIG, overrides=GOOD)
    for s in cfg.pack("clinical")["death_date_imputation"]["follow_up_sources"]:
        if s.get("source") == "orals":
            s["filter_method"] = []
    assert any("filter_method must be a non-empty string" in p for p in validate.problems(cfg))
    # Setting BOTH a raw 'filter' and a 'filter_method' is ambiguous (the named method wins, the raw
    # filter is silently dropped) -> flagged.
    cfg2 = load_config(CONFIG, overrides=GOOD)
    for s in cfg2.pack("clinical")["death_date_imputation"]["follow_up_sources"]:
        if s.get("source") == "orals":
            s["filter"] = "enddate IS NOT NULL"          # filter_method valid_oral_end already present
    assert any("both 'filter' and 'filter_method'" in p for p in validate.problems(cfg2))


def test_follow_up_sources_names_list_form_validated():
    # The NAMES-list form (restrict the engine default set) must be validated too: a valid list lints
    # clean, but a typo'd source name (which silently yields empty follow-up at runtime) fails lint.
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.pack("clinical")["death_date_imputation"]["follow_up_sources"] = ["visit", "lot"]
    assert not any("follow_up_sources" in p for p in validate.problems(cfg))
    cfg2 = load_config(CONFIG, overrides=GOOD)
    cfg2.pack("clinical")["death_date_imputation"]["follow_up_sources"] = ["visti", "lot"]   # typo
    assert any("'visti' is not a known follow-up source" in p for p in validate.problems(cfg2))


def test_prior_taxane_pre_mcrpc_source_validated_and_preflighted():
    # A typo'd pre_mcrpc_source must fail validation, not silently skip prior_tax_pre_mcrpc...
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.pack("treatment")["prior_taxane"]["pre_mcrpc_source"] = "not_a_source"
    assert any("pre_mcrpc_source 'not_a_source' is not a declared source"
               in p for p in validate.problems(cfg))
    # ...and when declared, its linename/startdate are added to the preflight contract.
    cfg2 = load_config(CONFIG, overrides=GOOD)
    cfg2.pack("treatment")["prior_taxane"]["pre_mcrpc_source"] = "ses"   # a declared source
    assert {"linename", "startdate"} <= set(validate.required_columns(cfg2)["ses"])


def test_drug_episode_columns_required_only_with_line_outcomes():
    # Prostate has line_outcomes -> drug_episode (declared) must expose linenumber/episodedate, so a
    # missing column is caught up front instead of silently falling back to enddate (which would
    # shift vis120/TTD/TTNT).
    cfg = load_config(CONFIG, overrides=GOOD)
    assert cfg.pack("outcomes").get("line_outcomes")                     # prostate enables it
    assert {"linenumber", "episodedate"} <= set(validate.required_columns(cfg)["drug_episode"])
    # episodedate has TWO independent drivers now (line_outcomes AND the B1 category aggregate), so the
    # base case must strip BOTH: no line_outcomes AND a codelist that doesn't use category_equals.
    cfg2 = _cfg_with_codelist([{"code": 1, "label": "A", "match": {"equals": "a"}},
                               {"code": 16, "label": "Any other therapy", "match": {"always": True}}])
    cfg2.pack("outcomes").pop("line_outcomes", None)
    assert "episodedate" not in set(validate.required_columns(cfg2).get("drug_episode", []))


def test_b1_drug_category_preflight_moved_to_drug_episode():
    # B1: the per-line drug category moved LOT -> drug_episode. Prostate's classifier uses category_equals,
    # so preflight must (a) NOT require detaileddrugcategory on lot, and (b) require linesetting, linenumber,
    # episodedate AND detaileddrugcategory on drug_episode — episodedate because the runtime only builds the
    # per-line aggregate (hence the category) when episodedate is present.
    cfg = load_config(CONFIG, overrides=GOOD)
    req = validate.required_columns(cfg)
    assert "detaileddrugcategory" not in req["lot"]
    assert {"linesetting", "linenumber", "episodedate", "detaileddrugcategory"} <= set(req["drug_episode"])
    # A codelist that never uses category_equals must NOT force detaileddrugcategory onto drug_episode.
    cfg2 = _cfg_with_codelist([{"code": 1, "label": "A", "match": {"equals": "a"}},
                               {"code": 16, "label": "Any other therapy", "match": {"always": True}}])
    assert "detaileddrugcategory" not in set(validate.required_columns(cfg2).get("drug_episode", []))
    # And a missing category column on drug_episode is caught by preflight, not silently NULLed at runtime.
    cols = _complete_cols(cfg)
    cols["drug_episode"].remove("detaileddrugcategory")
    try:
        validate.preflight(None, cfg, _table_reader=_reader_for(cfg, cols))
    except RuntimeError as e:
        assert "detaileddrugcategory" in str(e)
    else:
        raise AssertionError("expected preflight to flag missing detaileddrugcategory on drug_episode")
    # A product with NO line-setting model (no global AND no cohort setting) must NOT be forced to carry
    # linesetting on drug_episode — it aggregates on patient+linenumber. The category is still required.
    cfg3 = load_config(CONFIG, overrides=GOOD)
    cfg3.raw.pop("lot", None)                                        # global lot.line_setting -> None
    for c in cfg3.cohorts:
        c.pop("line_setting", None)                                 # AND strip every cohort's setting
    req3 = validate.required_columns(cfg3)
    assert "linesetting" not in set(req3.get("drug_episode", []))
    assert "linesetting" not in set(req3.get("lot", []))
    assert {"linenumber", "episodedate", "detaileddrugcategory"} <= set(req3.get("drug_episode", []))


def test_linesetting_required_from_cohort_setting_without_global():
    # The runtime resolves cohort.line_setting BEFORE the global fallback, so a product that sets
    # line_setting only on its cohorts (no global lot.line_setting) still uses a setting model — preflight
    # must require linesetting on BOTH lot and drug_episode, not skip it because the global is unset.
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.raw.pop("lot", None)                                         # global lot.line_setting -> None
    assert cfg.lot_line_setting is None
    assert any(c.get("line_setting") for c in cfg.cohorts)          # cohorts still carry mHSPC/mCRPC
    req = validate.required_columns(cfg)
    assert "linesetting" in set(req.get("lot", []))                 # gate now sees the cohort settings
    assert "linesetting" in set(req.get("drug_episode", []))


def test_custom_followup_filter_columns_required():
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.pack("clinical")["death_date_imputation"]["follow_up_sources"] = [
        {"source": "visit", "date_column": "visitdate", "filter_columns": ["visittype"]}]
    req = validate.required_columns(cfg)
    assert "visittype" in req["visit"] and "visitdate" in req["visit"]


def test_death_conflict_policy_validated():
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.pack("clinical")["death_date_imputation"]["conflict_resolution"] = "bogus"
    assert any("conflict_resolution" in p for p in validate.problems(cfg))


def test_age_bands_need_fallthrough():
    cfg = load_config(CONFIG, overrides=GOOD)
    for b in cfg.pack("demographics")["age_bands"]:      # mutate the role-cache the validator reads
        b.pop("when", None)                              # remove the fallthrough marker
    assert any("age_bands needs exactly one" in p for p in validate.problems(cfg))


def test_a_gap_between_bands_is_refused():
    """AN ENTIRE AGE GROUP, SILENTLY RELABELLED. The fallthrough check asks whether unmatched input
    has a defined answer; it cannot see that the gap is INSIDE the intended range. Drop 65-69 and
    every 65-to-69-year-old lands in the catch-all and is reported Unknown — counts still add up,
    the distribution still looks plausible, and nothing was flagged before this check existed."""
    cfg = load_config(CONFIG, overrides=GOOD)
    bands = cfg.pack("demographics")["age_bands"]
    ft = [b for b in bands if b.get("when") == "fallthrough"]
    bands[:] = [{"label": "18-64", "min": 18, "max": 64, "code": 1},
                {"label": "70-79", "min": 70, "max": 79, "code": 2}] + ft
    problems = validate.problems(cfg)
    assert any("GAP" in p and "[65-69]" in p for p in problems), \
        f"a five-year hole in the banding drew no finding: {[p for p in problems if 'age' in p]}"


def test_overlapping_bands_are_refused():
    """The answer must not depend on YAML ORDER. A 62-year-old matching both `18-64` and `60-74`
    gets whichever band is written first — a semantic decision made by a text editor."""
    cfg = load_config(CONFIG, overrides=GOOD)
    bands = cfg.pack("demographics")["age_bands"]
    ft = [b for b in bands if b.get("when") == "fallthrough"]
    bands[:] = [{"label": "18-64", "min": 18, "max": 64, "code": 1},
                {"label": "60-74", "min": 60, "max": 74, "code": 2}] + ft
    assert any("OVERLAP" in p and "[60-64]" in p for p in validate.problems(cfg)), \
        "two bands claiming the same ages drew no finding"


def test_the_band_coverage_check_is_quiet_on_every_committed_pack():
    """A check that fires on the real packs gets relaxed rather than read. All twelve use the same
    contiguous integer banding; this must find nothing in any of them."""
    import sys as _sys
    repo = FRAMEWORK.parent
    _sys.path.insert(0, str(FRAMEWORK / "tools"))
    from product_gates import products                                   # noqa: PLC0415
    checked = 0
    for pack in sorted(products(str(repo))):
        path = repo / pack / "config" / "data_product.yaml"
        if not path.exists():
            continue
        try:
            cfg = load_config(str(path))
        except Exception:                                            # noqa: BLE001
            continue
        checked += 1
        found = [p for p in validate._bands_problems(cfg) if "GAP" in p or "OVERLAP" in p]
        assert not found, f"{pack}: {found}"
    assert checked >= 5, f"only {checked} pack(s) exercised — the test would be weak"


def test_open_ended_and_float_bands_are_not_silently_passed():
    """`75+` legitimately ends the chain and BMI bands are written 18.5/24.9, where the arithmetic
    gap to 25.0 is convention rather than a defect — so neither is chained. What must not happen is
    a clean bill of health over a list this only half read: when it reports anything at all, it
    says how many bands it could not check."""
    out = validate._band_coverage_problems("demographics.age_bands", [
        {"label": "18-64", "min": 18, "max": 64},
        {"label": "70-79", "min": 70, "max": 79},          # a real gap, to make it speak
        {"label": "75+", "min": 75},                        # open-ended: unread
        {"label": "bmi", "min": 18.5, "max": 24.9},         # float: unread
        {"when": "fallthrough", "label": "Unknown"},
    ])
    assert any("GAP" in p for p in out)
    assert any("NOT checked" in p and "2 band(s)" in p for p in out), out

    # ...and with nothing wrong, an unreadable band is not itself a finding.
    assert validate._band_coverage_problems("x", [{"label": "75+", "min": 75}]) == []


def test_duplicate_code_detected():
    cats = [
        {"code": 1, "label": "A", "match": {"equals": "a"}},
        {"code": 1, "label": "B", "match": {"equals": "b"}},
        {"code": 16, "label": "Any other therapy", "match": {"always": True}},
    ]
    assert any("codes not unique" in p for p in validate.problems(_cfg_with_codelist(cats)))


def test_catchall_must_be_last():
    cats = [
        {"code": 16, "label": "Any other therapy", "match": {"always": True}},
        {"code": 1, "label": "A", "match": {"equals": "a"}},
    ]
    assert any("LAST category" in p for p in validate.problems(_cfg_with_codelist(cats)))


def test_missing_catchall_detected():
    cats = [{"code": 1, "label": "A", "match": {"equals": "a"}}]
    assert any("exactly one always-true catch-all" in p
               for p in validate.problems(_cfg_with_codelist(cats)))


def test_required_columns_includes_index_date_of():
    cfg = load_config(CONFIG, overrides=GOOD)
    req = validate.required_columns(cfg)
    # advanceddiagnosisdate is derived, so enhanced must expose its `of` columns
    assert "metastaticdiagnosisdate" in req["enhanced"]
    assert "crpcdate" in req["enhanced"]
    assert "linesetting" in req["lot"]


def _reader_for(cfg, cols_by_source):
    """Build a _table_reader from {source_name: [cols]} keyed by resolved table FQN."""
    fqn_cols = {cfg.table(n): cols for n, cols in cols_by_source.items()}

    def read(fqn):
        if fqn not in fqn_cols:
            raise RuntimeError("table not found")
        return fqn_cols[fqn]
    return read


def _complete_cols(cfg):
    req = validate.required_columns(cfg)
    return {n: list(req.get(n, ["patientid"])) for n in cfg.sources}   # declared sources


def test_preflight_passes_when_complete():
    cfg = load_config(CONFIG, overrides=GOOD)
    assert validate.preflight(None, cfg, _table_reader=_reader_for(cfg, _complete_cols(cfg))) is True


def test_preflight_flags_missing_column():
    cfg = load_config(CONFIG, overrides=GOOD)
    cols = _complete_cols(cfg)
    cols["lot"].remove("linesetting")
    try:
        validate.preflight(None, cfg, _table_reader=_reader_for(cfg, cols))
    except RuntimeError as e:
        assert "linesetting" in str(e)
    else:
        raise AssertionError("expected preflight to flag the missing column")


def test_preflight_flags_unreadable_table():
    cfg = load_config(CONFIG, overrides=GOOD)
    cols = _complete_cols(cfg)
    del cols["mortality"]                       # simulate a missing/unreadable table
    try:
        validate.preflight(None, cfg, _table_reader=_reader_for(cfg, cols))
    except RuntimeError as e:
        assert "mortality" in str(e) and "not readable" in str(e)
    else:
        raise AssertionError("expected preflight to flag the unreadable table")


def test_a_generic_categorical_is_held_to_the_same_checks_as_a_panel():
    """THE ASYMMETRY THE SEVENTH REVIEW NAMED. A categorical was checked for presence of
    name/column/groups and a declared source, and nothing else — so an unregistered matcher
    operator or an unregistered `pick` reached the engine from a categorical while the identical
    mistake in a panel was refused at lint time. Same config shape, two answers, and the weaker
    one was the default path."""
    import sys as _s
    _s.path.insert(0, str(FRAMEWORK))
    from engine.stages.clinical import selection_errors, value_matcher_errors

    # An unregistered `pick` is refused, and the registry is named rather than defaulted to.
    errs = selection_errors({"pick": "whichever"})
    assert errs and "not a registered selection method" in errs[0], errs
    # ...and a registered one passes, so this is not a blanket refusal.
    assert selection_errors({"pick": "latest"}) == []
    # An unregistered matcher operator is refused.
    assert value_matcher_errors([{"label": "x", "from_nonsense": ["a"]}])


def test_the_mapping_form_of_pick_is_seen_through_by_the_validator():
    """`pick: {method: priority}` is legal config the engine unwraps at runtime. Comparing the raw
    value to the string "priority" missed it, so the without-a-window refusal could be escaped by
    spelling the same thing the other way."""
    import sys as _s
    _s.path.insert(0, str(FRAMEWORK))
    from engine.stages.clinical import selection_errors
    # Both spellings validate identically...
    assert selection_errors({"pick": "priority"}) == []
    assert selection_errors({"pick": {"method": "priority"}}) == []
    # ...and both are refused when the method is not registered.
    assert selection_errors({"pick": {"method": "whichever"}})


def test_same_date_conflict_is_a_registered_choice_not_an_accident():
    """Two records on ONE DATE with different values fell through every selector to an ORDER BY
    that never mentioned the value, so the engine returned whichever row the shuffle placed first.
    `tie_break` answers which DATE wins — a different question, and the only one that was asked."""
    import sys as _s
    _s.path.insert(0, str(FRAMEWORK))
    from engine.stages.clinical import (DEFAULT_SELECTION, SAME_DATE_CONFLICT, selection_errors)
    assert set(SAME_DATE_CONFLICT) == {"deterministic", "refuse", "priority", "min", "max"}
    # The default preserves today's behaviour rather than changing every pack's output.
    assert DEFAULT_SELECTION["same_date_conflict"] == "deterministic"
    for name in SAME_DATE_CONFLICT:
        assert selection_errors({"same_date_conflict": name}) == [], name
    assert selection_errors({"same_date_conflict": "whatever"})


def test_the_temporal_field_model_defaults_and_refuses_contradictions():
    """`study.index_end` carried three meanings (enrollment close, observation end, sanity
    bound). The split fields are ADDITIVE: every accessor falls back to index_end so an
    unstated model changes nothing; a stated one must agree with itself. Both directions:
    the default chain, each override, the alias contradiction, and the two ordering refusals."""
    from config import (data_cutoff, index_period_end, index_period_start, observation_end)
    plain = {"index_start": "2013-01-01", "index_end": "2025-12-31"}
    assert index_period_start(plain) == "2013-01-01"
    assert index_period_end(plain) == observation_end(plain) == data_cutoff(plain) == "2025-12-31"
    split = dict(plain, observation_end="2026-06-30", data_cutoff="2026-08-01")
    assert index_period_end(split) == "2025-12-31"
    assert observation_end(split) == "2026-06-30" and data_cutoff(split) == "2026-08-01"
    # stating only the cut: observation defaults to it, not to the enrollment close
    cut_only = dict(plain, data_cutoff="2026-08-01")
    assert observation_end(cut_only) == data_cutoff(cut_only) == "2026-08-01"

    cfg = load_config(CONFIG, overrides=GOOD)
    assert validate.problems(cfg) == []
    cfg.study["index_period_end"] = "2024-01-01"          # disagrees with index_end
    assert any("two \nnames" in p.replace("two ", "two \n", 1) or "disagreeing" in p
               for p in validate.problems(cfg)), validate.problems(cfg)
    del cfg.study["index_period_end"]
    cfg.study["observation_end"] = "2020-01-01"           # before the enrollment close
    assert any("before the last patient enters" in p for p in validate.problems(cfg))
    cfg.study["observation_end"] = "2026-06-30"
    cfg.study["data_cutoff"] = "2026-01-01"               # before observation end
    assert any("past the delivery's cut" in p for p in validate.problems(cfg))
    cfg.study["data_cutoff"] = "2026-08-01"
    assert validate.problems(cfg) == [], validate.problems(cfg)


def test_date_basis_columns_are_required_by_preflight():
    """`_record_date_expr` hard-dereferences `date_basis.columns` to build the later_of/earlier_of
    record date, so a typo there was a runtime AnalysisException from a column preflight had said
    nothing about — the one thing preflight exists to prevent.

    Behavioural now, not a source-text pin: the gathering moved into the clinical stage's own
    typed reads (validate composes them), so the property is asserted on the ANSWER — configure
    a date_basis and its columns appear in required_columns; remove it and they vanish."""
    cfg = load_config(CONFIG, overrides=GOOD)
    blk = cfg.pack("clinical")["biomarkers"]
    blk["date_basis"] = {"method": "later_of", "columns": ["resultdate", "specimendate"]}
    req = validate.required_columns(cfg)[blk["source"]]
    assert "resultdate" in req and "specimendate" in req, req
    del blk["date_basis"]
    req = validate.required_columns(cfg)[blk["source"]]
    assert "specimendate" not in req, "date_basis columns required with no date_basis configured"


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
