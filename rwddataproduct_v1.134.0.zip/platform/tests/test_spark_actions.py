"""How many times does QC read the table? — measured, not asserted.

An external review put a number on it: `run_qc` could trigger roughly eighteen Spark actions and
the golden comparison roughly thirty-four. Those were static control-flow upper bounds, and the
review said so. This measures the real thing, by counting the Spark JOBS a call submits — and the
estimate turned out to be LOW. Measured on the prostate plan (six line columns, four date columns):

    run_qc, at 8304ab4 ............ 26 jobs
    run_qc, fused ................. 4 jobs

Every budget below is a measured number plus headroom, recorded so the next reader can tell a
ceiling from a target.

WHY A BUDGET TEST AND NOT A BENCHMARK. Wall-clock on a `local[1]` fixture measures the container,
not the code, and would be flaky in CI for reasons no one could act on. The number of times a
function scans its input is a property of the code: it does not move with machine load, it is what
actually costs money on a wide Delta table, and a regression in it is a specific mistake someone
made — an extra `.count()` inside a loop — rather than noise.

THE BUDGETS ARE CEILINGS, deliberately loose enough not to fire on an incidental plan change and
tight enough that re-introducing a per-column action would break them. A budget nobody can pass is
switched off; a budget nothing can fail is decoration.

Run: python3 platform/tests/test_spark_actions.py  (or pytest). Spark-only.
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))

from engine import qc, golden, output_contract as oc      # noqa: E402
from engine.config import load_config, product_config     # noqa: E402

CONFIG = product_config(FRAMEWORK.parent / "products", "prostate")

try:
    from pyspark.sql import SparkSession
except Exception:
    SparkSession = None

try:
    import pytest
    pytestmark = pytest.mark.skipif(SparkSession is None, reason="pyspark not installed")
except Exception:
    pytest = None

_SPARK = None
_SEQ = 0


def _spark():
    global _SPARK
    if _SPARK is None:
        sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))
        import synthetic_sources
        _SPARK = synthetic_sources.session("actions")
    return _SPARK


def _jobs(fn):
    """(result, number of Spark jobs the call submitted).

    A job group scopes the count to THIS call, so a lazy frame materialised by an earlier test
    cannot be charged to it. `getJobIdsForGroup` is the tracker's own record of what was
    submitted — no listener, no timing, nothing that varies with the machine.
    """
    global _SEQ
    s = _spark()
    _SEQ += 1
    # A FRESH GROUP ID PER CALL rather than set-then-clear: PySpark 4 removed
    # `SparkContext.clearJobGroup`, and a group left set would charge the next call's jobs to this
    # one. A unique id makes the scoping independent of ever unsetting it.
    group = f"budget-{_SEQ}"
    s.sparkContext.setJobGroup(group, group)
    out = fn()
    return out, len(s.sparkContext.statusTracker().getJobIdsForGroup(group))


SCHEMA = ("patientid string, cohortn int, index_date string, cohort string, stage string, "
          "dthdt string, fued string, advanceddiagnosisdate string, "
          + ", ".join(f"lot{i}cat string" for i in range(1, 7)))
ROWS = [("p1", 1, "2020-01-01", "Overall mHSPC", "CHECK", None, None, None,
         "Any other therapy", None, None, None, None, None),
        ("p2", 1, "2020-02-01", "Overall mHSPC", "I", "2021-01-01", "2021-01-01", "2019-01-01",
         "Docetaxel", "Any other therapy", None, None, None, None)]


def _df():
    return _spark().createDataFrame(ROWS, SCHEMA)


def test_the_counter_itself_counts():
    """A budget test whose counter always returned zero would pass every assertion below while
    measuring nothing. Establish that it moves before trusting it."""
    df = _df()
    _, none = _jobs(lambda: df.select("patientid"))          # lazy — no action
    assert none == 0, none
    _, one = _jobs(lambda: df.count())
    assert one >= 1, one


def test_qc_reads_the_table_a_fixed_number_of_times_not_one_per_column():
    """`run_qc` folds the row count, every column's null count, the catch-all hits and eligible
    denominators, the unmapped-stage count and both halves of every date ratio into ONE scan, plus
    one groupBy for the cohort breakdown.

    The prostate plan here carries six line columns and four date columns. The old shape issued a
    count, a null-rate select, six catch-all filters, a stage filter and eight date counts — so a
    budget in single digits is exactly what distinguishes the two.
    """
    cfg = load_config(CONFIG)
    df = _df()
    rep, jobs = _jobs(lambda: qc.run_qc(_spark(), df, cfg))
    # Measured: 4. Ceiling 8 — well under the 26 this cost before fusing, so a per-column action
    # coming back is caught, while an incidental extra job from a plan change is not a failure.
    assert jobs <= 8, f"run_qc submitted {jobs} jobs — a per-column action has come back"
    # ...and it still answers the questions. A budget met by computing less is not a saving.
    assert rep["n_rows"] == 2
    assert rep["cohorts"] == {"Overall mHSPC": 2}
    assert rep["catchall_rate"]["lot1cat"] == 0.5, rep["catchall_rate"]
    assert rep["catchall_eligible"]["lot1cat"] == 2
    assert rep["stage_check_rate"] == 0.5, rep["stage_check_rate"]
    assert rep["null_rate"]["dthdt"] == 0.5, rep["null_rate"]


def test_the_output_contract_scan_is_bounded_too():
    """Its row-level predicates are one aggregation by construction; the two irreducible extras are
    the duplicate-key groupBy and the cohort distinct."""
    cfg = load_config(CONFIG)
    _, jobs = _jobs(lambda: oc.run_output_contract(_spark(), _df(), cfg))
    assert jobs <= 8, f"run_output_contract submitted {jobs} jobs"   # measured: 6


def test_the_endpoint_summary_is_one_quantile_call_for_every_endpoint():
    """`approxQuantile` takes a LIST of columns and does them in one pass. Called per column, and
    preceded by its own `count()` each time, a three-endpoint product paid nine actions per side."""
    schema = "patientid string, cohort string, os double, pfs double, pfs2 double"
    rows = [("p1", "A", 1.0, 2.0, 3.0), ("p2", "A", 4.0, 5.0, 6.0)]
    df = _spark().createDataFrame(rows, schema)
    from pyspark.sql import functions as F

    def summ_all():
        endpoints = ["os", "pfs", "pfs2"]
        agg = df.agg(*[f(c).alias(f"{k}_{c}") for c in endpoints
                       for k, f in (("n", F.count), ("mean", F.avg))]).collect()[0]
        qs = df.approxQuantile(endpoints, [0.25, 0.5, 0.75], 0.01)
        return agg, qs

    (agg, qs), jobs = _jobs(summ_all)
    # Measured: 4 (approxQuantile submits more than one job for three columns). Per-column, with
    # its own count() each time, this was 9+ per side.
    assert jobs <= 5, f"the fused endpoint summary submitted {jobs} jobs"
    assert len(qs) == 3 and all(len(q) == 3 for q in qs), qs
    assert agg["n_os"] == 2 and agg["mean_os"] == 2.5


def test_an_empty_frame_does_not_break_the_fused_quantiles():
    """The input most likely to reach production by accident. Asking approxQuantile for quantiles
    of nothing returns an empty list per column, and unpacking it positionally is an IndexError."""
    schema = "patientid string, cohort string, os double, pfs double, pfs2 double"
    empty = _spark().createDataFrame([], schema)
    rep = golden.run_golden.__doc__  # noqa: F841 - documented; the call needs tables, not frames
    qs = empty.approxQuantile(["os", "pfs"], [0.25, 0.5, 0.75], 0.01)
    assert all(q == [] for q in qs), qs
    # The guard in golden.summ_all is what turns that into None rather than an exception.
    src = (FRAMEWORK / "engine" / "golden.py").read_text(encoding="utf-8")
    assert "if qs[i] else None" in src, "the empty-quantile guard is gone"


if __name__ == "__main__":
    if SparkSession is None:
        print("SKIP: pyspark not installed — action budgets are a Spark property.")
        sys.exit(0)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
