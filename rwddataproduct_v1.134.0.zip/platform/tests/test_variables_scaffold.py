"""The variables scaffold emits SHAPES, the human authors VALUES, and the build refuses the gap.

Three claims, each pinned: (1) the scaffold renders deterministic parameter skeletons from the
master inventory, only for the families the tumour's overlay instantiates; (2) every scaffolded
value is the ONE placeholder marker the repo already refuses (`REPLACE_ME` — validate.py's own
comment forbids a second spelling); (3) `engine/validate.py` in strict mode (the build) refuses
the marker ANYWHERE in a variables pack, so a half-filled skeleton cannot build.

Run: python3 tests/test_variables_scaffold.py (or pytest).
"""
import copy
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK))
sys.path.insert(0, str(FRAMEWORK / "tools"))
sys.path.insert(0, str(FRAMEWORK / "engine"))

import variables_scaffold as vs                      # noqa: E402

# What the marker becomes when a skeleton is "filled" in a test. Distinct from any real value, so
# `== MARKED` can tell an unfilled slot from a literal the skeleton chose on purpose.
MARKED = "x"


def test_render_is_deterministic_and_marker_only():
    a = vs.render("products/oncology/prostate/202606")
    b = vs.render("products/oncology/prostate/202606")
    assert a == b, "the scaffold must be byte-deterministic — --check is a byte compare"
    assert set(a) == {"demographics.yaml", "clinical.yaml", "treatment.yaml", "outcomes.yaml",
                      "data_product.yaml"}
    # every skeleton names the marker contract and the workbook as the value source
    for name, text in a.items():
        assert "approved" in text and "workbook" in text, name
        assert vs.MARK in text or "instantiates: (none)" in text, name
    # prostate's overlay instantiates the core families, so the load-bearing blocks are present
    assert "age_bands:" in a["demographics.yaml"]
    assert "baseline_ecog:" in a["clinical.yaml"]
    assert "overall_survival:" in a["outcomes.yaml"]
    assert "line_outcomes:" in a["outcomes.yaml"]
    assert "progression:" in a["outcomes.yaml"]
    assert "cohorts:" in a["data_product.yaml"] and "index_dates:" in a["data_product.yaml"]

    # EACH SKELETON NAMES ITS OWN DESTINATION, and the root one must not name `variables/`.
    # INDEX_DATE's parameters are `study` / `index_dates` / `cohorts` in config/data_product.yaml;
    # a header telling someone to paste them into variables/ would put the cohort model where
    # nothing reads it, and the file would lint clean sitting there doing nothing.
    assert "Copy a block into config/data_product.yaml" in a["data_product.yaml"]
    for name in ("demographics.yaml", "clinical.yaml", "outcomes.yaml", "treatment.yaml"):
        assert f"Copy a block into variables/{name}" in a[name], name


def test_blocks_follow_the_overlay_not_a_fixed_list():
    """MDS's literature maps OS but not the line time-to-event family or rwPFS — its scaffold must
    not grow blocks its overlay never earned, or the skeleton smuggles requirements in."""
    mds = vs.render("products/oncology/mds/YYYYMM")
    assert "overall_survival:" in mds["outcomes.yaml"]
    assert "line_outcomes:" not in mds["outcomes.yaml"]
    assert "progression:" not in mds["outcomes.yaml"]
    # oc resolves through the slug->overlay map (the pack slug is `oc`, the overlay is `ovarian`)
    oc = vs.render("products/oncology/oc/202606")
    assert "line_outcomes:" in oc["outcomes.yaml"]


def test_an_unknown_tumour_is_a_refusal_not_an_empty_scaffold():
    try:
        vs.render("products/oncology/no_such_tumour/202606")
        raise AssertionError("a tumour with no overlay produced a scaffold from nothing")
    except SystemExit as err:
        assert "no inventory overlay" in str(err)


def test_strict_validation_refuses_the_marker_anywhere_in_a_pack():
    """The enforcement half: a band label (or any pack value) still carrying REPLACE_ME must fail
    the BUILD's validation, not only run.*/study.* keys — that is what makes 'fill every marker
    from the workbook' a contract instead of advice."""
    from engine.config import load_config, product_config
    import validate
    cfg = load_config(product_config(REPO / "products", "prostate"),
                      overrides={"run.refresh": "2026q1", "run.source_schema": "rwd",
                                 "run.output_schema": "out"})
    assert not [p for p in validate.problems(cfg, strict=True) if validate.PLACEHOLDER in p], \
        "the live prostate pack must be marker-free — this test needs a clean baseline"
    # tamper one pack value the way a half-filled skeleton would look
    packs = cfg._packs_by_role_map()
    packs["demographics"] = dict(packs["demographics"])
    bands = [dict(b) for b in packs["demographics"]["age_bands"]]
    bands[0] = dict(bands[0], label="REPLACE_ME")
    packs["demographics"]["age_bands"] = bands
    why = [p for p in validate.problems(cfg, strict=True) if "REPLACE_ME" in p]
    assert why and any("variables/demographics" in p and "age_bands" in p for p in why), why
    # ...and lint mode still tolerates it, the same split every placeholder check has
    assert not [p for p in validate.problems(cfg, strict=False)
                if "variables/demographics" in p and "REPLACE_ME" in p]


def test_no_engine_gap_family_is_ever_scaffolded_and_the_header_says_which():
    """A SKELETON FOR A FAMILY NO ENGINE READS IS WORSE THAN NO SKELETON.

    It would emit a plausible-looking block; someone fills it from the workbook, pastes it into
    `variables/`, and gets a config that lints clean, is claimed by a contract record, satisfies
    every gate and produces no variable — the contract-and-config-agree-while-the-engine-reads-
    neither failure this repo has already paid for once (REVIEW_BRIEF, "Two sides checked, three
    sides needed"). Worse, the header used to tell readers to author exactly those blocks BY HAND
    FROM THE REFERENCE PACKS, an instruction no reference pack can satisfy.

    RW_RESPONSE was the case that surfaced this and is now the case that shows the rule is not a
    blanket one: `clinical.response` gave 4 of its 6 entries an engine home, so it is scaffolded,
    while DLBCL's and myeloma's per-LINE response stay `engine_gap` and are reported through
    COVERAGE.md. A family is excluded only when the engine can express NONE of it.

    Two claims here. The invariant — no scaffolded family is an engine gap — is derived from the
    inventory's own `coverage.class`, so it cannot drift from a second list, and adding the engine
    family plus re-classing the entries is what retires it. And the header states the gap families
    SEPARATELY, so "not scaffolded" never reads as "go write it yourself".
    """
    gaps = vs.engine_gap_masters()
    # NO WHOLE-FAMILY GAP REMAINS, so this is legitimately empty over the live inventory — every
    # master family the inventory names now has an engine home for at least some of its entries.
    # The synthetic case below is therefore not a nicety: it is the only place the reading of this
    # function is exercised at all, and without it the whole check would pass over nothing.
    assert gaps == set(), (
        f"a family reads as a whole-family engine gap again: {sorted(gaps)}. If that is real, it "
        f"needs a skeleton or an engine family; if it is a mis-classification, fix the inventory.")

    # EVERY overlay, not any — and over the live inventory the two readings are identical, because
    # no family is currently classed differently for different tumours. So the distinction is
    # asserted on a synthetic inventory, where a wrong reading is visible: MIXED has an engine
    # family (one tumour uses it) and must keep its skeleton; PURE has none anywhere.
    synthetic = {"tumours": {
        "a": {"variables": [{"master": "MIXED", "coverage": {"class": "engine_gap"}},
                            {"master": "PURE", "coverage": {"class": "engine_gap"}}]},
        "b": {"variables": [{"master": "MIXED", "coverage": {"class": "engine_family"}},
                            {"master": "PURE", "coverage": {"class": "engine_gap"}}]}}}
    assert vs.engine_gap_masters(synthetic) == {"PURE"}, vs.engine_gap_masters(synthetic)
    overlap = sorted(gaps & set(vs.SCAFFOLDED_MASTERS))
    assert not overlap, (f"scaffolded families the engine cannot express: {overlap}. A skeleton for "
                         f"one emits config nothing reads — remove it, or land the engine family "
                         f"and re-class the inventory entries.")
    # RW_RESPONSE is deliberately NOT here any more, and its absence is the "every overlay, not
    # any" rule doing its job on a real family: `clinical.response` closed 4 of its 6 entries, and
    # the DLBCL and myeloma entries stay `engine_gap` because per-LINE response has no config. A
    # family with an engine home for SOME of its uses is scaffolded, and the header still reports
    # the per-line remainder through COVERAGE.md rather than through this list.
    assert "RW_RESPONSE" not in gaps, \
        "RW_RESPONSE reads as a whole-family gap again — clinical.response covers 4 of its 6 entries"
    assert "RW_RESPONSE" in vs.SCAFFOLDED_MASTERS, "a family with an engine home must be scaffolded"

    # mcrc instantiates all three gap families and three authorable ones, so its header shows the
    # split. Sectioned on the heading rather than on line numbers — the headings wrap.
    text = vs.render("products/oncology/mcrc/202606")["outcomes.yaml"]
    assert "# NOT EXPRESSIBLE IN CONFIG AT ALL" in text, text[:600]
    authorable, engine_blocked = text.split("# NOT EXPRESSIBLE IN CONFIG AT ALL", 1)
    assert "by hand from the reference packs" in authorable, authorable
    for family in sorted(gaps & vs.instantiated_masters("mcrc")):
        assert family in engine_blocked, f"{family} is not named under the engine-gap heading"
        assert family not in authorable, f"{family} is still listed as a block to author by hand"
    # ...and the authorable heading is not left empty of the families that ARE authorable.
    for family in sorted(vs.instantiated_masters("mcrc") - set(vs.SCAFFOLDED_MASTERS) - gaps):
        assert family in authorable, f"{family} is authorable and is not named as such"


def test_the_index_date_skeleton_is_a_shape_the_real_validator_accepts():
    """INDEX_DATE is the largest family in the inventory (30 of 509 overlay variables) and its
    parameters are NOT in `variables/` — `study`, `index_dates` and `cohorts` live in the pack's
    root `config/data_product.yaml`. That makes two ways to get the skeleton wrong that the
    congruence test above cannot see, because it only asks whether a live pack states each key:

      MISSING a key the validator REQUIRES — a skeleton without `cohortn` renders a config that
      `validate` refuses, after someone has filled in every other value.
      A DANGLING reference — `cohorts[].index` must be `lot_start_date` or a key of `index_dates`,
      and the skeleton emits both forms, so a wrong literal would ship as guidance.

    So this runs THE REAL VALIDATOR over the filled skeleton rather than restating its rules. The
    negative half matters as much: each required key is removed in turn and validate must refuse,
    which is what makes the skeleton's keys load-bearing rather than decorative.
    """
    import yaml
    import validate
    from engine.config import load_config, product_config
    cfg = load_config(product_config(REPO / "products", "prostate"),
                      overrides={"run.refresh": "2026q1", "run.source_schema": "rwd",
                                 "run.output_schema": "out"})
    base = validate.problems(cfg, strict=False)
    assert base == [], f"the live prostate pack must validate clean — this test needs it: {base}"

    whole = yaml.safe_load(vs.render("products/oncology/prostate/202606")["data_product.yaml"]
                           .replace(vs.MARK, MARKED))
    # The root skeleton carries two families. This test owns INDEX_DATE's three blocks;
    # COHORT_ELIGIBILITY's `lot` / `treatment_status` are the sibling test's.
    assert set(whole) == {"study", "index_dates", "cohorts", "lot", "treatment_status"}, sorted(whole)
    filled = {k: whole[k] for k in ("study", "index_dates", "cohorts")}

    # FILLING MUST ONLY REPLACE, NEVER ADD. The first version of this wrote `c["id"], c["cohortn"]
    # = ...` unconditionally, which put back exactly the keys the skeleton is being tested for
    # emitting: deleting `cohortn: {m}` from the template still passed. A test that repairs its own
    # subject proves the repair. So every assignment below is guarded on the key already being
    # there, and a hardcoded value the skeleton chose is left alone — that literal is the thing
    # under test.
    model = next(iter(filled["index_dates"]))
    for n, c in enumerate(filled["cohorts"], start=1):
        for key, value in (("id", f"c{n}"), ("cohortn", n), ("label", f"C{n}"),
                           ("lot_number", 1), ("index", model), ("diag", model)):
            if c.get(key) == MARKED:                 # only a marker gets a value
                c[key] = value
    filled["study"] = {k: v for k, v in (("index_start", "2011-01-01"),
                                         ("index_end", "2026-04-30"))
                       if k in filled["study"]}

    def problems_with(doc):
        cfg.study, cfg.index_dates, cfg.cohorts = doc["study"], doc["index_dates"], doc["cohorts"]
        return [p for p in validate.problems(cfg, strict=False) if p not in base]

    assert problems_with(copy.deepcopy(filled)) == [], problems_with(copy.deepcopy(filled))
    # ...and the second cohort really is the LINE shape: `lot_start_date` is the engine's own
    # literal, not a model, and validate accepts it only because index.py branches on lot_number.
    assert filled["cohorts"][1]["index"] == "lot_start_date"
    assert "lot_number" in filled["cohorts"][1] and "lot_number" not in filled["cohorts"][0]

    # NEGATIVE: every key the skeleton emits on a cohort must be one validate would miss.
    for field in ("id", "label", "cohortn", "index"):
        broken = copy.deepcopy(filled)
        del broken["cohorts"][0][field]
        why = problems_with(broken)
        assert any(field in p for p in why), \
            f"removing cohorts[0].{field} was accepted — the skeleton emits a key nothing needs: {why}"
    # ...and a cohort index naming no model is refused, which is why the skeleton says so twice.
    dangling = copy.deepcopy(filled)
    dangling["cohorts"][0]["index"] = "not_a_model"
    assert any("not in index_dates" in p for p in problems_with(dangling)), problems_with(dangling)


def test_the_three_completing_families_are_shapes_the_real_validator_accepts():
    """COHORT_ELIGIBILITY, SEX and DEATH_DATE — the last three families the engine can express.

    Each has a way to be wrong that a live-pack congruence check cannot see, because congruence
    only asks whether SOME pack states a key:

      lot.line_number             two spellings and no others; the engine refuses a third, and the
                                  two give DIFFERENT cohorts whenever a setting was excluded
      conflict_resolution         three policy names and no others; a fourth is accepted by YAML,
                                  refused by the validator, and silently changes every OS if it
                                  were not
      follow_up_sources[lot]      the alias is NOT free — the death-date reconciliation looks up
                                  `last_lotenddate` by that exact string
      passthrough (SEX)           the engine SKIPS a column the source lacks, so a wrong name is
                                  not an error, it is a missing variable

    So the filled skeleton goes through the real validator, and each of those is then broken to
    confirm it is refused rather than absorbed.
    """
    import yaml
    import validate
    from engine.config import load_config, product_config
    cfg = load_config(product_config(REPO / "products", "prostate"),
                      overrides={"run.refresh": "2026q1", "run.source_schema": "rwd",
                                 "run.output_schema": "out"})
    assert validate.problems(cfg, strict=False) == [], "needs a clean live baseline"

    # --- COHORT_ELIGIBILITY: the root `lot` block --------------------------------------------
    root = yaml.safe_load(vs.render("products/oncology/prostate/202606")["data_product.yaml"]
                          .replace(vs.MARK, MARKED))
    assert {"lot", "treatment_status"} <= set(root), sorted(root)
    assert set(root["treatment_status"]["by_setting"][MARKED]) == \
        {"treated_label", "untreated_label", "treated_code", "untreated_code"}, root

    def lot_problems(line_number):
        raw = dict(cfg.raw)
        raw["lot"] = dict(root["lot"], line_number=line_number)
        saved = cfg.raw
        try:
            cfg.raw = raw
            return validate.problems(cfg, strict=False)
        finally:
            cfg.raw = saved

    for good in ("new_lot_n", "linenumber"):
        assert not [p for p in lot_problems(good) if "line_number" in p], good
    bad = [p for p in lot_problems("raw_line") if "line_number" in p]
    assert bad, "lot.line_number accepted a third spelling — the skeleton offers a choice the " \
                "engine does not have"

    # --- DEATH_DATE and SEX: both are clinical-pack blocks -------------------------------------
    # mcrc's overlay instantiates both; prostate's instantiates neither (male-only cohort, and its
    # death dates arrive resolved), so rendering prostate here would assert over nothing.
    clin = yaml.safe_load(vs.render("products/oncology/mcrc/202606")["clinical.yaml"]
                          .replace(vs.MARK, MARKED))
    assert "death_date_imputation" in clin and "passthrough" in clin, sorted(clin)
    imp = clin["death_date_imputation"]
    assert {"month_level_day", "year_level_monthday", "year_level_late_monthday",
            "conflict_resolution", "death_followup_window_days",
            "follow_up_sources"} <= set(imp), sorted(imp)
    # the lot alias is load-bearing, and the skeleton must not invite a different one
    lot_entry = [s for s in imp["follow_up_sources"] if s.get("source") == "lot"]
    assert lot_entry and lot_entry[0]["alias"] == "last_lotenddate", imp["follow_up_sources"]
    # SEX rides passthrough: {column, as}, nothing invented
    assert imp["conflict_resolution"] == MARKED, "the policy must be the marker, not a default"
    assert set(clin["passthrough"]["columns"][0]) == {"column", "as"}, clin["passthrough"]

    def clinical_problems(block):
        packs = cfg._packs_by_role_map()
        before = packs["clinical"]
        try:
            packs["clinical"] = dict(before, death_date_imputation=block)
            return validate.problems(cfg, strict=False)
        finally:
            packs["clinical"] = before

    live_policy = "most_specific_then_earliest"
    ok = dict(imp, conflict_resolution=live_policy,
              follow_up_sources=[{"source": "visit", "date_column": "visitdate",
                                  "alias": "last_visitdate"},
                                 {"source": "lot", "date_column": "enddate",
                                  "alias": "last_lotenddate"}])
    assert not [p for p in clinical_problems(ok) if "death_date_imputation" in p
                or "follow_up_sources" in p], clinical_problems(ok)
    assert [p for p in clinical_problems(dict(ok, conflict_resolution="earliest_wins"))
            if "conflict_resolution" in p], "a fourth policy name was accepted"
    renamed = [dict(s, alias="last_lot") if s["source"] == "lot" else s
               for s in ok["follow_up_sources"]]
    assert [p for p in clinical_problems(dict(ok, follow_up_sources=renamed))
            if "last_lotenddate" in p], "the lot alias was allowed to be renamed"


def test_every_family_the_engine_can_express_has_a_skeleton():
    """THE SET IS CLOSED NOW, AND THIS IS WHAT KEEPS IT CLOSED.

    Every master family in the inventory either has a skeleton (19 of them, 169 of the 509 overlay
    variables) or is an engine gap (3, worth 21). Nothing sits in the middle any more — and the
    middle is precisely where a family would sit silently: the generated header would name it, no
    check would fail, and the next person would find it by reading a comment.

    So the middle is asserted empty. A new master family added to the inventory now arrives with a
    decision attached — write the skeleton, or class its entries `engine_gap` and say what engine
    work is missing — instead of quietly widening the set of things a person has to know.

    This is not "no family may be added without a skeleton". It is "adding one is a visible act".
    """
    every = set()
    for slug in ("prostate", "oc", "mcrc", "mds", "nsclc", "sclc", "dlbcl", "cll", "gist",
                 "hnscc", "endometrial"):
        every |= vs.instantiated_masters(slug)
    stranded = sorted(every - set(vs.SCAFFOLDED_MASTERS) - vs.engine_gap_masters())
    assert not stranded, (
        f"master families with neither a skeleton nor an engine-gap classification: {stranded}. "
        f"Either add a block to variables_scaffold (and a validator test for its shape), or class "
        f"the inventory entries `engine_gap` with `via` naming what the engine is missing. Leaving "
        f"one here means the only place it is reported is a comment in generated output.")
    # ...and the assertion is not vacuous: the families it ranges over are real and non-empty.
    assert len(every) >= 20, f"only {len(every)} master families read — the overlays stopped loading"


def test_the_live_packs_committed_skeletons_are_current():
    """The `--check` an external review found nothing running. Both live packs commit their
    generated skeletons (spec_pipeline/out/variables_scaffold/), and this asserts render() still
    produces those bytes — the same generated-artifact discipline every other out/ artifact
    carries, executed where CI actually runs (this suite)."""
    for pack in ("products/oncology/prostate/202606", "products/oncology/oc/202606"):
        files = vs.render(pack)
        for name, want in files.items():
            path = REPO / pack / "spec_pipeline" / "out" / "variables_scaffold" / name
            assert path.exists(), (f"{pack}: {name} was never generated — run "
                                   f"python3 platform/tools/variables_scaffold.py {pack}")
            assert path.read_text(encoding="utf-8") == want, \
                f"{pack}: {name} is stale — regenerate with variables_scaffold.py"


def test_check_distinguishes_never_generated_from_drift():
    """NEVER GENERATED is not DRIFT: the skeletons are an optional aid, and reporting a pack that
    never asked for them as 'missing' kept the check permanently red — which is why nothing ran
    it. An EXISTING directory is a claim of currency and still byte-compares."""
    import shutil as _sh
    import tempfile as _tf
    # a pack with no scaffold dir: rc 0, saying so
    assert vs.main(["products/oncology/mds/YYYYMM", "--check"]) == 0
    # a generated-then-tampered pack: rc 1
    tmp = Path(_tf.mkdtemp()) / "prostate" / "202606"   # parent name = overlay slug
    tmp.mkdir(parents=True)
    try:
        assert vs.main([str(tmp)]) == 0
        assert vs.main([str(tmp), "--check"]) == 0
        target = tmp / "spec_pipeline" / "out" / "variables_scaffold" / "clinical.yaml"
        target.write_text(target.read_text(encoding="utf-8") + "# tampered\n", encoding="utf-8")
        assert vs.main([str(tmp), "--check"]) == 1
    finally:
        _sh.rmtree(tmp.parent.parent, ignore_errors=True)


def test_filled_skeleton_shapes_are_shapes_the_engine_accepts():
    """An external review filled the skeletons and found the ENGINE refused them: baseline_ecog
    without value_codes, min_avail_date.sources as bare names instead of {source, date_column}
    mappings, line_outcomes without its required visit_recency_days sibling, and a tie_break
    vocabulary (`worst | best | latest`) the engine never accepted. The filled shape is now
    structurally congruent with the live packs' engine-accepted files: every scaffold key path
    must exist in a live pack's corresponding block."""
    import yaml
    filled = {name: yaml.safe_load(text.replace(vs.MARK, "X"))
              for name, text in vs.render("products/oncology/oc/202606").items()}
    assert filled["clinical.yaml"]["baseline_ecog"].get("value_codes"), \
        "the skeleton omits value_codes — the delivered-value map is a workbook fact"
    assert "visit_recency_days" in filled["outcomes.yaml"], \
        "line_outcomes without visit_recency_days is a KeyError at build time"
    mad = filled["clinical.yaml"]["min_avail_date"]
    assert isinstance(mad["sources"][0], dict) and set(mad["sources"][0]) == \
        {"source", "date_column"}, "min_avail_date sources are {source, date_column} mappings"
    assert "earliest_date | latest_date" in vs.CLIN_BLOCKS["ECOG_PS"], \
        "the tie_break guidance must state the engine's exact vocabulary"

    def congruent(node, lives, path):
        """A key path passes when ANY live pack's corresponding block states it — the two packs
        legitimately fill different optional keys of one engine family."""
        out = []
        if isinstance(node, dict):
            refs = [l for l in lives if isinstance(l, dict)]
            if not refs:
                return [f"{path}: mapping vs {[type(l).__name__ for l in lives]}"]
            for k, v in node.items():
                if k == "X":
                    continue                       # a marker used as a KEY (value_codes rows)
                sub = [l[k] for l in refs if k in l]
                if not sub:
                    out.append(f"{path}.{k}: no live pack states this key")
                else:
                    out += congruent(v, sub, f"{path}.{k}")
        elif isinstance(node, list) and node and isinstance(node[0], dict):
            items = [x for l in lives if isinstance(l, list)
                     for x in l if isinstance(x, dict)]
            if items:
                legal = set().union(*[set(x) for x in items])
                for item in node:
                    out += [f"{path}[].{k}: no live item states this key"
                            for k in item if k not in legal]
        return out
    # the reference: BOTH live packs' engine-accepted config files, every block kept. The root
    # config is in the loop too — `data_product.yaml` is a skeleton for `config/data_product.yaml`,
    # so its reference is that file, not a variables/ one.
    problems = []
    for role in ("demographics", "clinical", "outcomes", "data_product"):
        live = {}
        for pack in ("products/oncology/oc/202606", "products/oncology/prostate/202606"):
            sub = "config" if role == "data_product" else "variables"
            doc = yaml.safe_load((REPO / pack / sub / f"{role}.yaml")
                                 .read_text(encoding="utf-8")) or {}
            for k, v in doc.items():
                live.setdefault(k, []).append(v)
        for key, block in (filled.get(f"{role}.yaml") or {}).items():
            if key in live:
                problems += congruent(block, live[key], f"{role}.{key}")
            elif key not in ("regions", "lab_values", "response", "comorbidity_index"):
                # engine-read families no live pack configures yet
                problems.append(f"{role}.{key}: no live pack states this key")
    # verified against the ENGINE reader, not a live pack: `_closest_values_panel` reads
    # blk["window_days"] and item["units"] (engine/stages/clinical.py) — the live packs simply
    # run their panels unwindowed and unit-unrestricted, so the union reference cannot vouch.
    # `lot.exclude_settings` is the same shape: `config.lot_exclude_settings` reads it and
    # `lot.normalized` filters on it (the engine's own comment cites EC dropping 'ADVANCED'), but
    # neither live pack excludes a setting, so the union has nothing to vouch with.
    # ...and the three categorical-item keys the engine reads and no live pack sets:
    # `_categorical_pick` reads date_column + pick, `_categorical_pick_windowed` reads window_days
    # (and the validator refuses window_days without date_column). Neither live pack configures a
    # categorical at all today, so the union reference has nothing to vouch with — the shapes are
    # held instead by test_windowed_categorical_answers_the_value_at_index_not_the_latest_value,
    # which runs them through Spark, and by the validator tests.
    engine_optional = {"clinical.lab_values.window_days", "clinical.lab_values.panel[].units",
                       "data_product.lot.exclude_settings",
                       "clinical.categoricals[].date_column", "clinical.categoricals[].window_days",
                       "clinical.categoricals[].pick"}
    problems = [p for p in problems if p.split(":")[0] not in engine_optional]
    assert problems == [], problems


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
