"""One compiled source contract, and every consumer provably reading it.

The review's finding: the config walker saw `source:`-keyed roles, the engine's own table knew
the implicit ones, and roles like baseline_ecog or visit could be used or silently omitted
without appearing in any report. The contract composes the owners; these tests pin that it
agrees with them, that the engine-guarded roles appear with their absence behaviour stated, and
that the matrix actually CONSUMES it rather than keeping a second walk.

Run: python3 platform/tests/test_source_contract.py (or pytest). Pure — no Spark.
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))
sys.path.insert(0, str(FRAMEWORK / "tools"))

from engine import source_contract, validate as ev                     # noqa: E402
from engine.config import load_config, product_config                  # noqa: E402

PRODUCTS = FRAMEWORK.parent / "products"
GOOD = {"run.refresh": "t", "run.source_schema": "t", "run.output_schema": "t"}


def test_the_contract_agrees_with_the_owners_it_composes():
    """Per-role facts equal the owner functions' answers — composition, not a third opinion."""
    cfg = load_config(product_config(PRODUCTS, "prostate"), overrides=GOOD)
    sc = source_contract.compiled(cfg)["roles"]
    req = ev.required_columns(cfg)
    grain, _ = ev.source_grain(cfg)
    for role, cols in req.items():
        assert sc[role]["required_columns"] == sorted(cols), role
    for role, keys in grain.items():
        assert sc[role]["grain"] == list(keys), role
    for role in cfg.sources:
        assert sc[role]["declared"] and sc[role]["physical"] == cfg.sources[role]


def test_engine_guarded_roles_appear_with_their_absence_named():
    """The review's exact complaint: an undeclared baseline_ecog or visit source appeared in NO
    report. Every engine-guarded family now has a row, optional, with what absence DOES stated —
    and never as a required/BLOCKED finding."""
    cfg = load_config(product_config(PRODUCTS, "oc"), overrides=GOOD)
    sc = source_contract.compiled(cfg)["roles"]
    for role in ("baseline_ecog", "visit", "telemed", "vitals"):
        assert role in sc, f"engine-guarded role {role} missing from the contract"
        rec = sc[role]
        assert rec["when_absent"], role
        if not rec["declared"]:
            assert rec["availability"]["state"] == "optional", (role, rec)


def test_the_matrix_consumes_the_contract_not_a_second_walk():
    """Break the contract and the matrix must break — object-level proof of consumption, the
    same discipline availability_problems carries."""
    import source_requirements as sr
    real = source_contract.compiled
    def boom(cfg):
        raise RuntimeError("contract consumed")
    source_contract.compiled = boom
    try:
        sr.matrix(str(PRODUCTS / "oncology" / "prostate" / "202606"))
    except RuntimeError as e:
        assert "contract consumed" in str(e)
    else:
        raise AssertionError("matrix() no longer reads the compiled source contract")
    finally:
        source_contract.compiled = real


def test_every_referenced_role_is_a_stage_declared_read_on_every_pack():
    """The conformance that keeps the walker and the stages from drifting apart again: for every
    versioned pack, every role the config walk finds is also a role some stage DECLARES reading
    (stage_reads), and no stage's declaration raises. A config key a stage forgets to declare
    fails here, by pack — the known walker gaps (ses, practice, the follow-up feeds,
    the hardcoded drug_episode read, category_source) were exactly this drift, invisible."""
    packs = sorted((PRODUCTS).glob("oncology/*/*/config/data_product.yaml"))
    assert packs
    for p in packs:
        cfg = load_config(str(p))
        reads, errs = ev.stage_reads(cfg)
        assert errs == [], (p, errs)
        uncovered = set(ev.referenced_sources(cfg)) - {r["role"] for r in reads}
        assert not uncovered, f"{p}: config references roles no stage declares: {uncovered}"


def test_required_and_referenced_consume_the_stage_declarations():
    """Object-level proof of consumption, both directions: inject a read through one stage's
    reads() and it must appear in required_columns AND referenced_sources; engine-guarded
    (required=False) reads must reach the availability model as visible-optional, never
    required — the same discipline the matrix-consumption test pins one layer up."""
    from stages import demographics as dm
    from stages import read
    cfg = load_config(product_config(PRODUCTS, "prostate"), overrides=GOOD)
    real = dm.reads
    dm.reads = lambda c: real(c) + [
        read("enhanced", ["injectedcolumn"], "test.injected"),
        read("phantom_feed", ["x"], "test.guarded", required=False, when_absent="degrades")]
    try:
        assert "injectedcolumn" in ev.required_columns(cfg)["enhanced"], \
            "required_columns no longer reads the stage declarations"
        assert "phantom_feed" not in ev.referenced_sources(cfg), \
            "an engine-guarded read leaked into the availability-required set"
        rec = source_contract.compiled(cfg)["roles"]["phantom_feed"]
        assert rec["availability"]["state"] == "optional" and rec["when_absent"] == "degrades"
    finally:
        dm.reads = real


def test_when_absent_tells_the_truth_about_hard_reads():
    """An adversarial review caught the first composition letting the follow-up feeds' degrade
    text claim the slot for roles whose absence actually HARD-FAILS: lot read "contributes
    nothing to follow-up end" while src["lot"] raises at first use, and visit/telemed lost the
    visit_sources refusal. Required reads now own the slot: lot states the hard failure,
    visit_sources roles state the refusal, and a guarded-only role (orals) keeps its degrade."""
    cfg = load_config(product_config(PRODUCTS, "prostate"), overrides=GOOD)
    roles = source_contract.compiled(cfg)["roles"]
    assert "fails at first read" in roles["lot"]["when_absent"], roles["lot"]["when_absent"]
    for role in ("visit", "telemed"):
        assert "REFUSES" in roles[role]["when_absent"], (role, roles[role]["when_absent"])
    assert "contributes nothing to follow-up end" in roles["orals"]["when_absent"], \
        roles["orals"]["when_absent"]


def test_a_sourceless_read_is_dropped_named_and_the_contract_still_compiles():
    """The second confirmed review finding: a dict-form follow_up_sources entry missing `source`
    produced a role-None read, and compiled() crashed with an unattributed TypeError two modules
    away while problems() had the named message. The record is now dropped where it is born,
    the stage is named, and the contract compiles with the problem carried."""
    cfg = load_config(product_config(PRODUCTS, "prostate"), overrides=GOOD)
    cfg.pack("clinical")["death_date_imputation"]["follow_up_sources"] = [
        {"date_column": "visitdate"}]
    reads, errs = ev.stage_reads(cfg)
    assert any("declares no role" in e for e in errs), errs
    assert all(r["role"] for r in reads)
    doc = source_contract.compiled(cfg)                  # must not raise
    assert any("declares no role" in p for p in doc["problems"]), doc["problems"]


def test_a_malformed_stage_declaration_is_said_not_swallowed():
    """The old composition ran under a broad suppressor, so a malformed pack silently required
    nothing — preflight green over a config the build refuses. A declaration that raises must
    surface in problems(), attributed to the owning stage."""
    cfg = load_config(product_config(PRODUCTS, "prostate"), overrides=GOOD)
    lo = cfg.pack("outcomes").setdefault("line_outcomes", {})
    lo["visit_sources"] = [{"date_column": "d"}]
    probs = ev.problems(cfg)
    assert any("outcomes.reads()" in p and "must name `source`" in p for p in probs), probs


def test_implementation_shortfalls_block_release_by_the_records_own_words():
    """The review's finding: prostate sat `active` while its own register said the executable
    diverges from the requirement in nine areas — and nothing between the label and release read
    the register. releasable() counts records whose implementation axis says engine_gap /
    config_gap / partial / not_implemented, and blocks with the count. Both directions: prostate
    (which carries such records) shows the blocker; a contract-less pack shows only the Gate 2
    blocker, never a phantom implementation line.

    The count must cover EVERY record. The first version parsed each record with a generic
    yaml.safe_load and skipped the 152 of prostate's 202 whose prose fields refuse it — a release
    gate evaluating a quarter of the register and reporting the sample as the whole (33 shortfalls
    claimed; the register states 145). So: the blocker names the found total, every record is
    readable, and the shortfall count exceeds what the 50-record sample could ever have seen."""
    import contract_lint as cl
    import source_manifest as sm
    ok, why = sm.releasable(str(FRAMEWORK.parent), "products/oncology/prostate/202606")
    assert not ok
    short = [w for w in why if w.startswith("implementation:") and "falls short" in w]
    assert short, why
    found = len(list(cl.records(cl.read(str(
        FRAMEWORK.parent / "products/oncology/prostate/202606/handoff/FUNCTIONAL_CONTRACT.md")))))
    assert f"of {found} record(s)" in short[0], (short[0], found)
    n = int(short[0].split("implementation: ")[1].split(" of ")[0])
    assert n > 50, f"only {n} shortfalls counted — the gate is sampling the register again"
    assert not any("no readable implementation axis" in w for w in why), \
        "prostate's records are all readable; an unreadable finding here is a parser regression"
    ok2, why2 = sm.releasable(str(FRAMEWORK.parent), "products/oncology/mcrc/202606")
    assert not ok2
    assert not any(w.startswith("implementation:") for w in why2), \
        "a pack with no contract manufactured an implementation blocker"


def test_a_shortfall_hiding_in_a_non_yaml_record_still_blocks_and_unreadable_refuses():
    """The reviewer's exact construction: the ONLY gap sits in a record whose prose fields refuse
    a generic YAML parse (colons mid-sentence, an unbalanced quote). The old code skipped it and
    the pack showed no implementation blocker at all. Three records, three directions: TRICKY
    (non-parseable prose, engine_gap) is counted; BROKEN (no readable status axis) is refused,
    never skipped; CLEAN (implemented) raises nothing."""
    import tempfile
    import source_manifest as sm
    tmp_path = Path(tempfile.mkdtemp(prefix="releasable_"))
    pack = tmp_path / "products" / "fixture" / "202606"
    (pack / "handoff").mkdir(parents=True)
    (pack / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text("""# Fixture contract

```yaml
variable_id: TRICKY
definition: baseline: the value: closest to index [see 4.2], quote "unbalanced
status: {requirement: approved, implementation: engine_gap, validation: not_run, source: verified}
gap_ids: [GAP-1]
```

```yaml
variable_id: BROKEN
status: mangled beyond reading
```

```yaml
variable_id: CLEAN
status: {requirement: approved, implementation: implemented, validation: passed_test, source: verified}
```
""", encoding="utf-8")
    ok, why = sm.releasable(str(tmp_path), str(Path("products") / "fixture" / "202606"))
    assert not ok
    short = [w for w in why if "falls short" in w]
    assert short and "1 of 3" in short[0] and "TRICKY" in short[0], why
    unreadable = [w for w in why if "no readable implementation axis" in w]
    assert unreadable and "1 of 3" in unreadable[0] and "BROKEN" in unreadable[0], why
    assert not any("CLEAN" in w for w in why), "an implemented record raised a blocker"


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
