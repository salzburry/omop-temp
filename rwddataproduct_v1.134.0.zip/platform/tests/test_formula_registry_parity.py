"""Cross-engine parity for the NAMED formula/filter registries (always runs — no Rscript needed).

The BMI/BSA formulas and the follow-up row filters are named in config and resolved from engine
registries. Python (engine/stages/clinical.py) and R (engine-r/stages.R) must expose the SAME method
names AND the SAME compiled expressions, or a config that lints clean in one engine would diverge in the
other. The R codelist-compiler parity lives in test_r_parity.py (needs Rscript); this static check
compares the registry *definitions* directly, so it runs on every CI runner.
"""
import re
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))

from engine.stages.clinical import (   # noqa: E402  (module level is PySpark-free)
    BMI_FORMULAS, BSA_FORMULAS, DEATH_CONFLICT_POLICIES, FOLLOWUP_FILTERS,
    FOLLOWUP_SOURCES, _resolve_formula)

R_STAGES = (FRAMEWORK / "engine-r" / "stages.R").read_text(encoding="utf-8")


def _r_registry(name: str) -> dict:
    """Extract {key: "value"} from an R `NAME <- list( ... )` block (one-line string values)."""
    out, inside = {}, False
    for ln in R_STAGES.splitlines():
        if re.match(rf"^\s*{name}\s*<-\s*list\(", ln):
            inside = True
            continue
        if inside:
            if re.match(r"^\s*\)", ln):
                break
            m = re.match(r'\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*"(.*)"\s*,?\s*(#.*)?$', ln)
            if m:
                out[m.group(1)] = m.group(2)
    return out


def test_bmi_registry_parity():
    r = _r_registry("BMI_FORMULAS")
    assert r, "could not parse R BMI_FORMULAS"
    assert r == dict(BMI_FORMULAS), f"BMI registry drift: R={r} Py={dict(BMI_FORMULAS)}"


def test_bsa_registry_parity():
    r = _r_registry("BSA_FORMULAS")
    assert r, "could not parse R BSA_FORMULAS"
    assert r == dict(BSA_FORMULAS), f"BSA registry drift: R={r} Py={dict(BSA_FORMULAS)}"
    assert "mosteller" not in r, "mosteller was dropped as speculative — re-add to both engines on request"


def test_followup_filter_registry_parity():
    r = _r_registry("FOLLOWUP_FILTERS")
    py = {k: v[0] for k, v in FOLLOWUP_FILTERS.items()}   # Python carries (sql, [columns]); R carries sql
    assert r, "could not parse R FOLLOWUP_FILTERS"
    assert r == py, f"follow-up filter drift: R={r} Py={py}"


def _r_rows(name: str) -> list:
    """The quoted strings of an R `NAME <- c(...)` / `NAME <- list(list(...), ...)` block, as ROWS.

    Per row, not one flat list: `FOLLOWUP_SOURCES`'s orals entry carries a FOURTH quoted string (its
    filter), so flattening shifts every row after it and the comparison misaligns rather than failing
    honestly. A `c(...)` one-liner comes back as a single row.

    Order is not cosmetic for either registry below — both engines take element 0/1 as the DEFAULT, so
    a reordering is a behaviour change that a set-vs-set or dict-vs-dict comparison cannot see.
    """
    rows, inside = [], False
    for ln in R_STAGES.splitlines():
        if not inside and re.match(rf"^\s*{name}\s*<-\s*(c|list)\(", ln):
            found = re.findall(r'"([^"]*)"', ln)
            if found:
                rows.append(found)          # a one-line c(...) vector IS the single row
            # A one-liner closes on its own line. Without this the scan stayed open and swallowed
            # the NEXT registry declared below it, which reads as drift in whichever came second.
            if ln.count("(") == ln.count(")"):
                return rows
            inside = True
            continue
        if inside:
            if re.match(r"^\s*\)", ln):
                break
            found = re.findall(r'"([^"]*)"', ln)
            if found:
                rows.append(found)
    return rows


def test_death_conflict_policy_parity_including_order():
    """The mortality conflict-resolution vocabulary, held equal across BOTH engines AND the validator.

    It was declared three times — a set in engine/validate.py, a tuple in engine/stages/clinical.py,
    a vector in engine-r/stages.R — with "keep in sync" written above one of them. Three ways to
    break: add it to the validator only and a config passes the gate then dies mid-build; add it to
    an engine only and the validator refuses a config that engine supports; REORDER either engine's
    list and the default conflict resolution silently changes, which changes which death date is
    selected and therefore OS, TTNT, PFS and follow-up duration. The set could not even express that
    last one, which is why the validator now imports the tuple instead of restating it.
    """
    rows = _r_rows("DEATH_CONFLICT_POLICIES")
    assert len(rows) == 1, f"expected one c(...) vector, parsed {rows}"
    assert list(DEATH_CONFLICT_POLICIES) == rows[0], \
        f"death-conflict policy drift: Py={list(DEATH_CONFLICT_POLICIES)} R={rows[0]}"

    # ...and the validator accepts exactly what the engine implements — by VALUE, not identity: the
    # repo loads clinical under two module names (stages.clinical and engine.stages.clinical), so the
    # already-deduped BMI_FORMULAS is `==` but not `is` across them too. Equality is the real claim.
    sys.path.insert(0, str(FRAMEWORK / "engine"))
    import validate as _validate
    assert list(_validate.DEATH_CONFLICT_POLICIES) == list(DEATH_CONFLICT_POLICIES), \
        "the validator's accepted policies differ from the ones the engine implements"


def test_followup_source_registry_parity():
    """The follow-up source rows, held equal across engines — membership AND order.

    Same class as the three registries above and unguarded until now: config-driven, positional, and
    duplicated per engine. The fourth element is the row filter, which FOLLOWUP_FILTERS parity
    already covers; the first three (source, date column, alias) are what a drift would silently
    change.
    """
    rows = _r_rows("FOLLOWUP_SOURCES")
    assert rows, "could not parse R FOLLOWUP_SOURCES"
    r = [row[:3] for row in rows]                       # drop each row's filter reference
    py = [list(row[:3]) for row in FOLLOWUP_SOURCES]
    assert r == py, f"follow-up source drift:\n  Py={py}\n  R ={r}"


def test_resolver_rejects_unknown_and_accepts_known():
    for reg, kind, good in ((BMI_FORMULAS, "bmi", "standard"), (BSA_FORMULAS, "bsa", "dubois")):
        try:
            _resolve_formula(reg, "definitely_not_a_method", kind)
            raised = False
        except ValueError:
            raised = True
        assert raised, f"{kind} resolver did not reject an unknown method"
        assert _resolve_formula(reg, good, kind), f"{kind} resolver rejected the known method {good}"


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
