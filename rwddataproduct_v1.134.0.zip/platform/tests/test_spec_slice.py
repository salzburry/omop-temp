"""One drafting unit's context, and nothing else.

A pack's pipeline output is written whole, while a drafter working one domain needs a fraction of
it. No token figure is quoted here: three of them drifted apart within one commit. These hold the two properties that make a slice
worth having: it is materially smaller, and it is HONEST about what it left out.

The second is the one worth testing hardest. A slicer that quietly returns nothing for a domain that
does not exist is worse than no slicer: the drafter sees an empty context, concludes the spec says
nothing, and drafts from imagination — the exact failure the whole framework is built against.

Run: python3 platform/tests/test_spec_slice.py (CI runs these as scripts, not under pytest).
"""
import atexit
import json
import sys
import tempfile
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "platform" / "tools"))

import spec_slice                                                   # noqa: E402

_TMPDIRS = []

PACK = REPO / "products" / "oncology" / "oc" / "202606"


def _slice(pack, *a, **kw):
    """`slice_pack` on a SYNTHETIC pack, whose artifacts cannot be regenerated.

    `verify_current` reruns the real pipeline against the pack's source workbook; a fixture built from
    dicts has no workbook, so the check correctly refuses. Every test that needs the check itself uses
    a live pack — see `test_stale_artifacts_are_refused_even_when_they_agree_with_each_other`, and
    `test_currentness_verification_is_ON_by_default`, which is what stops this wrapper from quietly
    becoming the way the check is never exercised.
    """
    kw.setdefault("verify_current", False)
    return spec_slice.slice_pack(pack, *a, **kw)


def _strip_extraction(pack):
    """Remove any registered `ai_extraction` from a COPY, so `_sign` can register one against it.

    A live pack's approval names the live path and hashes the live bytes — correctly, and that is the
    whole point of the binding. Copied to a tmpdir it therefore refuses, and appending a second block
    beside it would leave the copy carrying two records for one artifact. So the copy starts clean.
    """
    src = Path(pack) / "source_refs.yaml"
    lines = src.read_text(encoding="utf-8").splitlines(True)
    out, dropping = [], False
    for line in lines:
        if line.startswith("  - material_id: sanitized_extraction"):
            dropping = True
            continue
        if dropping and (line.startswith("  - material_id:") or not line.startswith((" ", "\t"))):
            dropping = False
        if not dropping:
            out.append(line)
    src.write_text("".join(out), encoding="utf-8")
    return pack


def _approved(pack):
    """A temp COPY of a live pack with its sanitized extraction registered and signed against the COPY.

    An approval binds to a path and to bytes, so a live pack's approval is only valid where the live
    pack is. A copy needs its own — which is exactly the property `test_the_approval_names_the_BYTES…`
    asserts, and the reason this helper cannot simply inherit one.

    Signing a THROWAWAY COPY is honest: the test states "given an approved artifact, the slice contains
    X", which is what the claim always was. The refusal itself is asserted separately, on a pack nobody
    has signed, by `test_the_refusal_still_works_on_a_pack_nobody_has_signed`.
    """
    import shutil
    import source_manifest as _sm
    d = Path(tempfile.mkdtemp()); _TMPDIRS.append(str(d))
    dst = d / Path(pack).name
    shutil.copytree(pack, dst)
    _sign(dst)
    ok, why = _sm.ai_readable(str(dst))
    assert ok, why
    return str(dst)


def _resign(pack, fingerprint=True):
    """Re-point the fixture's `ai_extraction` at whatever `extracted.json` now says.

    `fingerprint=False` re-points only the BYTES. A test whose property IS a fingerprint disagreement
    needs the hash current — otherwise Gate 1's sha256 check refuses first and the test passes for a
    reason that is not the one it names — while re-pointing the fingerprint too would erase the thing
    under test. Two bindings, and a test may legitimately want one refreshed and not the other.

    A test that MUTATES the extraction — drops its fingerprint, swaps in another run's, edits a row —
    otherwise trips the approval binding first: `ai_readable` refuses because the approval was given
    over a different run, which is correct behaviour and the wrong refusal for the property under
    test. Re-signing isolates the check each test is actually about. Tests that mutate `lint.json` or
    `scaffold.json` need none of this, because the approval is over the extraction.
    """
    import json as _json
    import source_manifest as _sm
    src = Path(pack) / "source_refs.yaml"
    out = Path(pack) / "spec_pipeline" / "out" / "extracted.json"
    fp = str((_json.loads(out.read_text(encoding="utf-8")).get("extraction") or {}).get("fingerprint")
             or "none")
    lines = src.read_text(encoding="utf-8").splitlines(True)
    for i, ln in enumerate(lines):
        if fingerprint and ln.strip().startswith("extraction_fingerprint:"):
            lines[i] = f"    extraction_fingerprint: {fp}\n"
        # ...and the BYTES, which every edit to the artifact changes. Without this the re-sign fixes
        # one binding and leaves the other refusing, so the test still fails for a reason that is not
        # the property under test — the same trap the fingerprint re-point exists to avoid.
        elif ln.strip().startswith("sha256:"):
            lines[i] = f"    sha256: {_sm.sha256(str(out))}\n"
    src.write_text("".join(lines), encoding="utf-8")
    return pack


def _has_pack():
    """Whether the LIVE ovarian pack is present.

    Callers that use this to `return` early are stating that they test the live pack specifically.
    That was every test in this file, which made the whole suite fail-open: move or rename a pack and
    the file still prints twelve `ok` lines while asserting nothing. Core slicer behaviour is tested
    against `_synthetic()` below, which cannot disappear; what remains behind this guard is the small
    set of assertions that are genuinely ABOUT the shipped packs.
    """
    return (PACK / "spec_pipeline" / "out" / "extracted.json").exists()


def _synthetic(rows=None, findings=None, records=None, contract=None, ai_class="sponsor_ai_eligible",
               material_id="spec_doc", applicability=None, classified_by="R. Classifier",
               classified_date="2026-07-27", registers=None, ai_extraction=True,
               ai_extraction_class="sponsor_ai_eligible"):
    """A complete minimal pack built from nothing, so a test does not depend on a shipped product.

    Every artifact is stamped with ONE fingerprint through the real
    `spec_extract.extraction_fingerprint`, so this fixture cannot drift away from what the pipeline
    actually writes — a hand-written constant here would agree today and diverge at the first change
    to the hashing, which is the shape this repo keeps paying for.
    """
    import spec_extract as sx
    d = Path(tempfile.mkdtemp()); _TMPDIRS.append(str(d))
    out = d / "spec_pipeline" / "out"; out.mkdir(parents=True)
    (d / "handoff").mkdir()
    rows = rows if rows is not None else [
        {"tab": "5.Demo", "row": 6, "item_id": "demographics:6", "domain": "demographics",
         "variable": "AGE", "content_hash": "aaaaaaaaaaaa", "text": "AGE",
         "fields": {"variable": "AGE", "definition": "AGE = YEAR(INDEXDT) - birthyear"},
         "header": ["Variable", "Definition", "Status"], "cells": ["AGE", "AGE = ...", "first-pass"]},
    ]
    sources = [{"file": "spec.xlsx", "tab": "(workbook)", "rows": len(rows), "sha256": "0123456789ab"}]
    fp = sx.extraction_fingerprint(sources, rows)
    import source_manifest as _sm
    policy = _sm.redaction_policy_sha256()
    (out / "extracted.json").write_text(json.dumps({
        "extraction": {"extractor_version": "1.2", "target": "spec.xlsx", "sources": sources,
                       "fingerprint": fp, "row_count": len(rows), "tabs": ["5.Demo"],
                       "domains": ["demographics"],
                       # The derivation record an `ai_extraction` approval is bound to. Written from
                       # the REAL policy digest, so the fixture cannot drift from what the extractor
                       # actually stamps.
                       "redaction": {"policy_sha256": policy, "cells_redacted": 0,
                                     "rows_redacted": 0}},
        "rows": rows}), encoding="utf-8")
    (out / "lint.json").write_text(json.dumps({
        "fingerprint": fp, "findings": findings or [],
        "applicability": applicability or {"foreign_table": "applied", "reasons": []}}),
        encoding="utf-8")
    (out / "scaffold.json").write_text(json.dumps({
        "scaffold": {"fingerprint": fp, "product": str(d), "spec_rows": len(rows)},
        "records": records or []}), encoding="utf-8")
    (d / "spec_pipeline" / "pipeline.conf").write_text(
        f"TUMOR=synthetic\nSPEC_SOURCE_ID={material_id}\n", encoding="utf-8")
    # A GATE-1-VALID manifest, not the minimum the eligibility check alone looked at. The slicer now
    # runs the full source-manifest check first, so a fixture that skipped `why_provisional` or
    # `path_or_link` was a fixture asserting behaviour no real pack could reach.
    (d / "spec.xlsx").write_text("fixture", encoding="utf-8")
    mat = (f"source_materials:\n  - material_id: {material_id}\n"
           f"    material_type: program_spec\n    status: pending\n"
           f"    why_provisional: synthetic fixture, never approved\n"
           f"    path_or_link: TBD — synthetic fixture, no document\n")
    if classified_by:
        mat += f"    classified_by: {classified_by}\n"
    if classified_by and classified_date:
        mat += f'    classified_date: "{classified_date}"\n'
    if ai_class is not None:                      # None = the field is ABSENT, not blank
        mat += f"    ai_classification: {ai_class}\n"
    # THE SANITIZED ARTIFACT, registered and approved. Eligibility is asked of the file AI opens, not
    # of the stand-in it came from — so a fixture that omits this models a pack nobody has signed,
    # which is a different test (see the refusal tests below) rather than the default.
    if ai_extraction:
        # `status: reviewed`, because that is what an APPROVED material is. A fixture saying
        # `pending` with a `why_provisional` beside a full signature — the same contradiction the gate
        # now refuses — and the gate accepted it, so the fixture was modelling a state no pack should
        # ever reach. `sha256` is computed over the file the record names: the approval is of BYTES.
        import source_manifest as _sm_fx
        art = str(d / "spec_pipeline" / "out" / "extracted.json")
        mat += (f"  - material_id: sanitized_extraction\n"
                f"    material_type: ai_extraction\n"
                f"    status: reviewed\n"
                f"    path_or_link: {art}\n"
                f"    sha256: {_sm_fx.sha256(art)}\n"
                f"    derived_from: {material_id}\n"
                f"    extraction_fingerprint: {fp}\n"
                f"    redaction_policy_sha256: {policy}\n"
                f"    redacted_cells: 0\n    redacted_rows: 0\n"
                f"    ai_classification: {ai_extraction_class}\n"
                f"    classified_by: R. Classifier\n    classified_date: \"2026-07-27\"\n"
                f"    approved_by: A. Approver\n    approval_date: \"2026-07-28\"\n")
    (d / "source_refs.yaml").write_text(mat, encoding="utf-8")
    if contract:
        (d / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(contract, encoding="utf-8")
    for name, text in (registers or {}).items():
        (d / "handoff" / name).write_text(text, encoding="utf-8")
    return d


def test_a_slice_carries_its_own_domain_and_no_other():
    """The point of slicing, and also its accuracy argument: a neighbour that is not in context
    cannot be copied from."""
    if not _has_pack():
        return
    s = _slice(_approved(PACK), "demographics")
    assert s["rows"], "demographics sliced to nothing"
    assert {r["domain"] for r in s["rows"]} == {"demographics"}, \
        {r["domain"] for r in s["rows"]}
    # and the findings travel with the rows, not with the pack. Sheet-level structure findings
    # ("<tab>:(sheet)") belong to the slice when the TAB is the slice's own — a drafter reading
    # demographics rows must see demographics' merges and stray headers, and must not see
    # another tab's.
    ids = {r["item_id"] for r in s["rows"]}
    tabs = {r["tab"] for r in s["rows"]}
    for f in s["findings"]:
        assert f["item_id"] in ids or (f["item_id"].endswith(":(sheet)")
                                       and f["tab"] in tabs), f
    # Style records are same-domain and CAPPED. Asserted on prostate/202606, which has 16
    # demographics records — oc's contract holds five in total, so the cap never binds there and a
    # test against it would pass with the cap removed.
    big = REPO / "products" / "oncology" / "prostate" / "202606"
    if (big / "spec_pipeline" / "out" / "extracted.json").exists():
        # An EXPLICIT cap, not STYLE_CAP. When the default became 0 this read
        # `len(style) == STYLE_CAP` with both sides zero and a loop body that never ran — a test that
        # passes by asserting nothing, which is the shape it exists to catch elsewhere.
        # Narrowed to ONE variable. Slicing a whole domain leaves no neighbours to show: every record
        # in it cites a selected row, so all of them are `current_records` — under review, in full —
        # and `style` is correctly empty. That is a consequence of separating the two, not a bug.
        b = _slice(_approved(big), "demographics", variable="AGE", style_cap=2)
        assert len(b["style"]) == 2, len(b["style"])
        assert not _slice(_approved(big), "demographics", style_cap=2)["style"], \
            "a whole-domain slice offered its own records under review as style examples"
        assert _slice(_approved(big), "demographics", variable="AGE",
                                     style_cap=0)["style"] == []
        for blk in b["style"]:
            assert "variable_id:" in blk, blk
            assert "spec_refs: [… ×" in blk, ("spec_refs reached a caller unredacted", blk)


def test_an_unknown_domain_fails_loudly_and_names_what_exists():
    """Fail-closed. An empty slice reads exactly like a specification that says nothing, and a
    drafter handed one has no way to tell the difference."""
    if not _has_pack():
        return
    try:
        _slice(_approved(PACK), "haematology")
    except SystemExit as e:
        assert "no domain" in str(e) and "demographics" in str(e), str(e)
    else:
        raise AssertionError("an unknown domain produced a slice instead of an error")

    try:
        _slice(_approved(PACK), "demographics", variable="NO_SUCH_VARIABLE")
    except SystemExit as e:
        assert "NO_SUCH_VARIABLE" in str(e), str(e)
    else:
        raise AssertionError("an unknown variable produced a slice instead of an error")


def test_a_pack_with_no_extraction_says_so_rather_than_slicing_nothing():
    with tempfile.TemporaryDirectory() as tmp:
        try:
            spec_slice.slice_pack(tmp, "demographics")
        except SystemExit as e:
            assert "extracted.json" in str(e), str(e)
        else:
            raise AssertionError("a pack with no pipeline output produced a slice")


def test_the_slice_is_materially_smaller_than_the_whole():
    """The business case, asserted rather than assumed. Not a fixed ratio — the point is an order of
    magnitude on the largest real pack, not a number that breaks when a spec grows."""
    if not _has_pack():
        return
    whole = (PACK / "spec_pipeline" / "out" / "extracted.json").stat().st_size
    rendered = spec_slice.render(_slice(_approved(PACK), "demographics"))
    assert len(rendered) < whole / 5, f"slice {len(rendered)} vs whole {whole} — barely a saving"


def test_the_slice_carries_the_decision_index_so_a_question_is_reused_not_reraised():
    """Two ids for one question is how a register stops being readable, and a drafter who cannot see
    the existing ids has no way to avoid it."""
    if not _has_pack():
        return
    s = _slice(_approved(PACK), "study_period", variable="DAYS_PER_MONTH")
    ids = {d["id"] for d in s["decisions"]}
    assert "OC-DAYS-PER-MONTH-LANDMARKS" in ids, ids
    # ids and questions, NOT the whole register — a compact index is the point
    assert all(set(d) == {"id", "status", "question"} for d in s["decisions"]), s["decisions"][:1]
    assert all(len(d["question"]) <= 160 for d in s["decisions"])


def test_a_pack_with_no_config_is_told_not_to_coin_an_alias():
    """The slice is where the no-config rule is actually delivered. prostate/202607 has no config, so
    its slice must say so rather than leave the drafter to infer a source key."""
    # PARKED at platform/tests/fixtures/: every product now carries a config, so the live tree has
    # no subject for this rule. Reached by path and guarded by "return if the extract is missing",
    # the move would have turned it into a silent skip. Asserted instead.
    p = REPO / "platform" / "tests" / "fixtures" / "prostate_202607"
    assert (p / "spec_pipeline" / "out" / "extracted.json").exists(), \
        f"{p} has no extract — this test needs a no-config pack with one"
    assert not (p / "config").exists(), "202607 grew a config — pick another no-config pack"
    text = spec_slice.render(_slice(_approved(p), "demographics"))
    assert "no declared sources yet" in text, text[-400:]
    assert "Do not coin a logical alias" in text

    # and a pack WITH config gets the keys instead
    if _has_pack():
        text = spec_slice.render(_slice(_approved(PACK), "demographics"))
        assert "`demographics`" in text and "must be among them" in text


def _copy(pack=None):
    """A throwaway copy of a real pack, so evidence can be broken without touching the checkout.

    REGISTERED FOR CLEANUP. Each copy is a whole pack; the first version leaked one per call and
    filled the disk after enough runs, which surfaced as three unrelated tests failing at once.
    """
    import shutil
    src = Path(pack or PACK)
    root = tempfile.mkdtemp()
    _TMPDIRS.append(root)
    dst = Path(root) / "p"
    shutil.copytree(src, dst)
    # SIGNED, like `_approved`. The shipped packs deliberately carry no `ai_extraction` — approving
    # the sanitized artifact is a named person's act — so a bare copy is refused before any of the
    # evidence checks these tests break on purpose can run. Signing a throwaway states the premise
    # ("given an approved artifact, breaking X is refused") instead of testing the approval twice.
    return _sign(dst)


def _sign(pack):
    """Register and approve `pack`'s sanitized extraction, in place. Throwaway copies only.

    Strips any existing registration first. A live pack now ships one, signed against the LIVE path
    and bytes; a copy of it needs its own, and appending beside the inherited record produced a
    duplicate `material_id` that Gate 1 correctly refused.
    """
    import source_manifest as _sm
    _strip_extraction(pack)
    block, err = _sm.ai_extraction_block(str(pack))
    assert not err, err
    # Every TODO the helper prints, plus the status flip. The helper deliberately does NOT pre-fill
    # `ai_classification` — that is the judgment it exists to pose — so signing here means answering
    # it, exactly as a person would.
    signed = (block.replace("ai_classification: TODO", "ai_classification: sponsor_ai_eligible")
                   .replace("classified_by: TODO", "classified_by: T. Test")
                   .replace("classified_date: TODO", 'classified_date: "2026-07-27"')
                   # the approval fields now emit COMMENTED OUT (absent is the honest pending
                   # state) — signing means UNCOMMENTING and filling them, as a person does
                   .replace("# approved_by:", "approved_by: T. Test  #")
                   .replace("# approval_date:", 'approval_date: "2026-07-28"  #')
                   .replace("status: pending", "status: reviewed"))
    signed = "\n".join(l.split("#")[0].rstrip() for l in signed.splitlines()
                       if l.split("#")[0].strip())
    src = Path(pack) / "source_refs.yaml"
    lines = src.read_text(encoding="utf-8").splitlines(True)
    start = next(i for i, l in enumerate(lines) if l.startswith("source_materials:"))
    end = next((i for i in range(start + 1, len(lines))
                if lines[i].strip() and not lines[i].startswith((" ", "\t", "#"))), len(lines))
    lines[end:end] = [signed + "\n"]
    src.write_text("".join(lines), encoding="utf-8")
    return pack


def _cleanup():
    import shutil
    while _TMPDIRS:
        shutil.rmtree(_TMPDIRS.pop(), ignore_errors=True)


atexit.register(_cleanup)


def test_missing_lint_or_scaffold_FAILS_rather_than_slicing_without_them():
    """The evidence that protects against invention is not optional.

    `lint.json` carries the findings that say the specification does not contain an answer — what I17
    enforces — and `scaffold.json` carries the refs and digest the drafter passes through rather than
    authors. Treating them as absent-is-fine produced a clean-looking slice for DAYS_PER_MONTH with
    its PLACEHOLDER flag simply gone: the tool built to prevent invention silently removing the
    anti-invention evidence.
    """
    if not _has_pack():
        return
    for f in ("lint.json", "scaffold.json"):
        d = _copy()
        (d / "spec_pipeline" / "out" / f).unlink()
        try:
            _slice(str(d), "study_period", variable="DAYS_PER_MONTH")
        except SystemExit as e:
            assert f in str(e), str(e)
        else:
            raise AssertionError(f"a slice was produced with {f} missing")


def test_a_bare_list_lint_payload_is_now_REFUSED_not_quietly_accepted():
    """It is not accepted as a legacy shape, and the reason is the point.

    A bare list carries no `applicability` and no `fingerprint`, so it cannot say whether the check
    ran or which extraction it came from. Accepting it means accepting an artifact that cannot answer
    either question — the fail-open this file spent a batch closing. No shipped pack writes it.
    """
    d = _synthetic()
    lj = d / "spec_pipeline" / "out" / "lint.json"
    lj.write_text(json.dumps(json.loads(lj.read_text(encoding="utf-8"))["findings"]), encoding="utf-8")
    try:
        _slice(str(d), "demographics")
    except SystemExit as e:
        assert "is a list missing" in str(e), str(e)
    else:
        raise AssertionError("a lint.json that cannot state its run or applicability was accepted")


def test_an_artifact_that_PARSES_but_lacks_its_keys_is_refused():
    """`{}` is valid JSON. `payload.get("findings") or []` read it as a clean lint — zero findings,
    rendered as a specification with nothing wrong with it — and the same hole was in scaffold.json.
    An EMPTY findings list is an answer; an ABSENT findings key is a file that never answered."""
    for name, keys in (("lint.json", "findings, applicability"), ("scaffold.json", "records")):
        d = _synthetic()
        (d / "spec_pipeline" / "out" / name).write_text("{}", encoding="utf-8")
        try:
            _slice(str(d), "demographics")
        except SystemExit as e:
            assert f"{name} is a mapping missing {keys}" in str(e), str(e)
        else:
            raise AssertionError(f"an empty {name} produced a slice")
    # and the legitimately-empty case still works: keys present, lists empty
    d = _synthetic(findings=[], records=[])
    assert _slice(str(d), "demographics")["findings"] == []


def test_a_slice_is_REFUSED_when_the_material_is_not_ai_eligible():
    """The tool was documented as leaving eligibility "to the caller" while the drafting skill named
    it as the AI's starting context. Together those are a fail-open: a pack whose extraction input is
    vendor_restricted produced a slice indistinguishable from an eligible one."""
    # THE SUBJECT MOVED. Eligibility is now asked of the DERIVED artifact — the sanitized
    # `extracted.json` AI opens — not of the stand-in it came from, because on a pack whose
    # specification quotes vendor documentation the class recorded on the input contradicts its own
    # content. So this asserts the derived artifact's own class, and separately that a vendor-authored
    # INPUT still blocks: redaction removes citations and cannot make a vendor document sponsor-authored.
    for klass in ("vendor_restricted", "restricted_derived"):
        d = _synthetic(ai_extraction_class=klass)
        try:
            _slice(str(d), "demographics")
        except SystemExit as e:
            assert f"classified {klass!r}" in str(e), (klass, str(e))
            assert "not an approval mechanism" in str(e)
        else:
            raise AssertionError(f"an ai_extraction classified {klass!r} produced a slice")

    # An eligible-looking DERIVATION of an ancestor that is not itself eligible. BOTH restricted
    # classes, not just `vendor_restricted`: the rule was written against the case in front of it and
    # let `restricted_derived` — the class for output derived FROM vendor data — walk straight through.
    for klass in ("vendor_restricted", "restricted_derived"):
        d = _synthetic(ai_class=klass)
        try:
            _slice(str(d), "demographics")
        except SystemExit as e:
            assert f"classified {klass!r} and not 'sponsor_ai_eligible'" in str(e), (klass, str(e))
            assert "cannot make vendor-authored or vendor-derived content" in str(e), str(e)
        else:
            raise AssertionError(f"a sanitized derivation of a {klass} input produced a slice")

    # ...and an UNREGISTERED artifact is refused, which is the state every shipped pack is in.
    d = _synthetic(ai_extraction=False)
    try:
        _slice(str(d), "demographics")
    except SystemExit as e:
        assert "material_type: ai_extraction" in str(e), str(e)
        assert "--register-ai-extraction" in str(e), "the refusal does not say how to fix it"
    else:
        raise AssertionError("a pack with no registered ai_extraction produced a slice")
    for klass in ("", None):
        d = _synthetic(ai_class=klass)
        try:
            _slice(str(d), "demographics")
        except SystemExit as e:
            assert "requires `ai_classification`" in str(e), (klass, str(e))
            assert "Gate 1 rejects this pack's source manifest" in str(e), (klass, str(e))
        else:
            raise AssertionError(f"ai_classification={klass!r} produced a slice")
    # an id naming nothing registered is also unanswered, not permitted
    d = _synthetic(material_id="spec_doc")
    (d / "spec_pipeline" / "pipeline.conf").write_text("SPEC_SOURCE_ID=absent\n", encoding="utf-8")
    try:
        _slice(str(d), "demographics")
    except SystemExit as e:
        # Gate 1 owns this one too — SPEC_SOURCE_ID naming nothing registered is a manifest defect,
        # not an eligibility verdict, and it is better reported as the former.
        assert "which is not a material_id in source_refs.yaml" in str(e), str(e)
    else:
        raise AssertionError("an unregistered SPEC_SOURCE_ID produced a slice")


def test_eligibility_is_decided_by_the_SAME_predicate_gate_1_uses():
    """Two definitions of "may AI read this" is the duplication this repo keeps paying for. The
    function object, not its answer today."""
    import source_manifest
    assert spec_slice.sm.ai_eligible is source_manifest.ai_eligible
    assert spec_slice.sm.AI_ELIGIBLE in source_manifest.AI_CLASSES


def test_the_slice_header_states_the_classification_it_relied_on():
    """A slice is evidence about what an AI was given. Stamping the material and its class means the
    document itself says which classification permitted it, rather than that being lost."""
    text = spec_slice.render(_slice(str(_synthetic()), "demographics"))
    assert "ai_classification `sponsor_ai_eligible`" in text, text[:400]
    assert "Source material `spec_doc`" in text


def test_artifacts_from_different_runs_are_refused():
    """A half-regenerated `out/` gives findings keyed to rows that no longer exist, and the slice would
    look complete while citing the previous version of the spec."""
    if not _has_pack():
        return
    d = _copy()
    ex = d / "spec_pipeline" / "out" / "extracted.json"
    data = json.loads(ex.read_text(encoding="utf-8"))
    data["rows"] = [r for r in data["rows"] if r.get("domain") != "outcomes"]
    ex.write_text(json.dumps(data), encoding="utf-8")
    _resign(d, fingerprint=False)     # bytes current, fingerprint untouched — see _resign
    try:
        _slice(str(d), "demographics")
    except SystemExit as e:
        assert "more than one run" in str(e), str(e)
    else:
        raise AssertionError("mismatched pipeline artifacts produced a slice")


def test_an_IN_PLACE_spec_edit_is_caught_though_every_cited_id_still_resolves():
    """THE case the coordinate check could not see, and the reason the fingerprint exists.

    `<domain>:<row>` is a coordinate. When RWB rewords a rule in place the id does not move: rerun the
    extraction, leave lint and scaffold behind, and every id a stale artifact cites still resolves. An
    id-set comparison sees one coherent run while the findings describe the previous wording.
    """
    import spec_extract as sx
    d = _synthetic(findings=[{"item_id": "demographics:6", "kind": "PLACEHOLDER",
                              "severity": "BLOCKER", "tab": "5.Demo", "detail": "TBD"}])
    out = d / "spec_pipeline" / "out"
    data = json.loads((out / "extracted.json").read_text(encoding="utf-8"))
    data["rows"][0]["fields"]["definition"] = "AGE = ..., TOP-CODED AT 89"     # edited IN PLACE
    data["rows"][0]["content_hash"] = "ffffffffffff"
    data["extraction"]["fingerprint"] = sx.extraction_fingerprint(
        data["extraction"]["sources"], data["rows"])
    (out / "extracted.json").write_text(json.dumps(data), encoding="utf-8")
    _resign(d)

    # the old check's premise: nothing the stale artifacts cite has gone missing
    ids = {r["item_id"] for r in data["rows"]} | {f'{r["tab"]}:(sheet)' for r in data["rows"]}
    stale = json.loads((out / "lint.json").read_text(encoding="utf-8"))
    assert not ({f["item_id"] for f in stale["findings"]} - ids), \
        "fixture no longer reproduces the in-place edit — every cited id must still resolve"

    try:
        _slice(str(d), "demographics")
    except SystemExit as e:
        assert "from DIFFERENT runs" in str(e), str(e)
    else:
        raise AssertionError("a stale lint describing the previous wording of a rule was sliced")


def test_an_artifact_with_no_fingerprint_cannot_prove_its_run():
    """Fail-closed on absence. An artifact written before the pipeline stamped one is not "probably
    fine" — it is a file that cannot say which extraction it came from."""
    for name in ("extracted.json", "lint.json", "scaffold.json"):
        d = _synthetic()
        f = d / "spec_pipeline" / "out" / name
        data = json.loads(f.read_text(encoding="utf-8"))
        blk = data["extraction"] if name == "extracted.json" else \
            data["scaffold"] if name == "scaffold.json" else data
        blk.pop("fingerprint")
        f.write_text(json.dumps(data), encoding="utf-8")
        try:
            _slice(_resign(d), "demographics")
        except SystemExit as e:
            # For `extracted.json` the APPROVAL binding catches it first and says so in its own
            # words — an artifact with no fingerprint cannot match the run its approval was given
            # over. Both are fingerprint refusals; neither is the artifact quietly slicing.
            assert ("carries no extraction fingerprint" in str(e)
                    or "extraction_fingerprint" in str(e)), (name, str(e))
        else:
            raise AssertionError(f"{name} without a fingerprint produced a slice")


def test_the_three_artifacts_carry_ONE_fingerprint_from_the_producer():
    """Copied through, never recomputed per tool — a second implementation would agree today and
    diverge at the first change to the hashing."""
    if not _has_pack():
        return
    out = PACK / "spec_pipeline" / "out"
    fps = {json.loads((out / "extracted.json").read_text(encoding="utf-8"))["extraction"]["fingerprint"],
           json.loads((out / "lint.json").read_text(encoding="utf-8"))["fingerprint"],
           json.loads((out / "scaffold.json").read_text(encoding="utf-8"))["scaffold"]["fingerprint"]}
    assert len(fps) == 1 and fps != {""}, fps


def test_workbook_columns_no_canonical_field_claims_still_reach_the_page():
    """`Origin`, `Evidence`, `Status`, `Owner`, `Open decision`, `Panoramic delta` match no
    COLUMN_RULES keyword, so they never enter `fields` and never rendered — while carrying
    `ADDITIVE (not in prior spec)`, `first-pass [verify]`, `DEFER/proposed`. The content was preserved
    in `cells` the whole time and reached no reader, so a row still marked for verification read as a
    settled requirement."""
    d = _synthetic()
    s = _slice(str(d), "demographics")
    assert s["rows"][0]["spec_columns_unmapped"] == [("Status", "first-pass")], \
        s["rows"][0]["spec_columns_unmapped"]
    assert "**Status** *(unmapped column)*: first-pass" in spec_slice.render(s)
    # and it is the extractor's own answer, not a second one computed here
    import spec_extract
    assert spec_slice.sx.unmapped_columns is spec_extract.unmapped_columns
    # a mapped column is NOT repeated as unmapped
    assert not any(lab == "Variable" for lab, _ in s["rows"][0]["spec_columns_unmapped"])


def test_records_already_citing_the_rows_are_carried_in_full():
    """Without these a domain audit saw three nearby records and none of the ones under review, so
    "does the contract still match the spec" could not actually be performed — and a drafting run
    could recreate a row that was already mapped."""
    contract = ("```yaml\nvariable_id: AGE\nspec_refs: [demographics:6]\n"
                "window: \"[index-365, index]\"\nderivation: \"YEAR(INDEXDT) - birthyear\"\n```\n")
    d = _synthetic(contract=contract)
    s = _slice(str(d), "demographics", style_cap=3)
    assert len(s["current_records"]) == 1, s["current_records"]
    assert "[index-365, index]" in s["current_records"][0], "the record under review was redacted"
    assert s["style"] == [], "the record under review was ALSO offered as a style example"
    text = spec_slice.render(s)
    assert "Records already citing these rows — 1" in text
    assert "drafting a second record for it is the error" in text


def test_each_row_carries_its_disposition_from_the_producer():
    """From `contract_scaffold.coverage_report`, never by parsing the rendered COVERAGE.md — a second
    reader of a rendered artifact is free to disagree with the tool that produced it."""
    d = _synthetic()
    s = _slice(str(d), "demographics")
    assert [c["item"] for c in s["coverage"]] == ["demographics:6"], s["coverage"]
    assert s["coverage"][0]["disposition"] == "UNDISPOSITIONED"
    assert "**disposition**: `UNDISPOSITIONED`" in spec_slice.render(s)
    import contract_scaffold
    assert spec_slice.cs.coverage_report is contract_scaffold.coverage_report


def test_style_examples_are_REDACTED_and_off_by_default():
    """The isolation was a sentence in a prompt: whole neighbouring records were on the page, every
    window, tie-break, source and acceptance among them. An instruction not to use them is the
    weakest control there is."""
    assert spec_slice.STYLE_CAP == 0, "style examples must be opt-in, not the default"
    contract = ("```yaml\nvariable_id: AGEGR1\nspec_refs: [demographics:9]\n"
                "source: {kind: table, name: Demographics}\n"
                "window: \"[index-365, index]\"\ntie_break: {equidistant: earliest}\n"
                "derivation: \"SECRET BANDING RULE\"\nacceptance: \"7 bands\"\n"
                "grain: [patientid, cohortn]\n```\n")
    d = _synthetic(contract=contract)
    assert _slice(str(d), "demographics")["style"] == []
    blk = _slice(str(d), "demographics", style_cap=3)["style"][0]
    for leaked in ("SECRET BANDING RULE", "index-365", "earliest", "Demographics", "7 bands",
                   "patientid", "demographics:9"):
        assert leaked not in blk, (leaked, blk)
    # ...while the SHAPE a drafter is looking at these for survives
    assert "source: {kind: …, name: …}" in blk, blk
    assert "grain: [… ×2]" in blk and 'derivation: "…"' in blk, blk
    assert "variable_id: AGEGR1" in blk, blk


def test_a_lint_check_that_did_not_RUN_is_not_reported_as_clean():
    """`spec_lint` emits `applicability` precisely so zero findings can be told from nobody looking.
    The slice dropped it, handing a drafter a clean sheet that might have been an unexamined one."""
    d = _synthetic(applicability={"foreign_table": "not_applicable",
                                  "reasons": ["no table-shaped source refs on this tab"]})
    s = _slice(str(d), "demographics")
    assert s["applicability"]["foreign_table"] == "not_applicable"
    text = spec_slice.render(s)
    assert "Lint checks that did NOT run" in text, text
    assert "nobody looked" in text
    assert "no table-shaped source refs on this tab" in text
    # a fully-applied lint says nothing, rather than adding a reassuring empty section
    assert "did NOT run" not in spec_slice.render(_slice(str(_synthetic()),
                                                                       "demographics"))


def test_stale_artifacts_are_refused_even_when_they_agree_with_each_other():
    """What the fingerprint structurally cannot see.

    Edit `lint.json` and restamp nothing: all three artifacts still carry ONE matching fingerprint,
    because they were all produced by the same extraction — they are equally out of date. The
    fingerprint proves internal agreement; only rerunning the pipeline proves agreement with the
    source as it stands.
    """
    if not _has_pack():
        return
    d = _copy()
    lj = d / "spec_pipeline" / "out" / "lint.json"
    data = json.loads(lj.read_text(encoding="utf-8"))
    data["findings"] = data["findings"][:2]                    # a lint rule that no longer fires
    lj.write_text(json.dumps(data, indent=1), encoding="utf-8")

    # the fingerprint premise: all three still agree, so that check passes
    out = d / "spec_pipeline" / "out"
    fps = {json.loads((out / "extracted.json").read_text(encoding="utf-8"))["extraction"]["fingerprint"],
           json.loads((out / "lint.json").read_text(encoding="utf-8"))["fingerprint"],
           json.loads((out / "scaffold.json").read_text(encoding="utf-8"))["scaffold"]["fingerprint"]}
    assert len(fps) == 1, "fixture no longer reproduces the case — the fingerprints must still agree"
    assert spec_slice.slice_pack(str(d), "demographics", verify_current=False)["findings"] is not None

    try:
        spec_slice.slice_pack(str(d), "demographics")
    except SystemExit as e:
        assert "not current for the source as it stands" in str(e), str(e)
        assert "DRIFT:" in str(e), str(e)
    else:
        raise AssertionError("artifacts that agree with each other but not with the source were used")


def test_currentness_verification_is_ON_by_default():
    """The wrapper the synthetic tests use turns it off. If the default flipped, every one of them
    would keep passing and nothing would notice — so assert the default itself."""
    import inspect
    sig = inspect.signature(spec_slice.slice_pack)
    assert sig.parameters["verify_current"].default is True
    # and it is the shared drift check, not a second comparison written here
    src = inspect.getsource(spec_slice._artifacts_current)
    assert "run_spec_pipeline.py" in src and "--check" in src, src


def test_an_eligible_class_with_no_signature_is_not_a_classification():
    """`ai_classification: sponsor_ai_eligible` and nothing else is a string somebody typed, not a
    decision anybody made. Gate 1 required the author and date all along; the slicer compared the
    class alone, so the gate and the tool the gate governs disagreed about the same material."""
    for by, date, why in ((None, None, "requires `classified_by`"),
                          ("R. Classifier", None, "requires `classified_date`"),
                          ("R. Classifier", "2026-13-99", "not a real calendar date"),
                          ("R. Classifier", "last tuesday", "not an ISO date")):
        d = _synthetic(classified_by=by, classified_date=date)
        try:
            _slice(str(d), "demographics")
        except SystemExit as e:
            assert why in str(e), (by, date, str(e))
        else:
            raise AssertionError(f"classified_by={by!r} classified_date={date!r} produced a slice")

    # ...and a date so malformed that YAML itself refuses is REPORTED, not raised as a traceback
    d = _synthetic()
    refs = d / "source_refs.yaml"
    refs.write_text(refs.read_text(encoding="utf-8").replace('classified_date: "2026-07-27"',
                                             "classified_date: 2026-13-99"), encoding="utf-8")
    try:
        _slice(str(d), "demographics")
    except SystemExit as e:
        assert "will not parse" in str(e) and "unread is eligibility unproven" in str(e), str(e)
    else:
        raise AssertionError("an unparseable source_refs.yaml produced a slice")


def test_gate_1_and_the_slicer_validate_the_classification_with_ONE_function():
    import source_manifest
    assert spec_slice.sm.classification_errors is source_manifest.classification_errors
    # Gate 1 routes through it too — not a second list of the same required fields
    import inspect
    assert "classification_errors(m)" in inspect.getsource(source_manifest.check)


def test_a_record_citing_a_RANGE_is_found_by_current_records():
    """`clinical:17-46` is neither `clinical:17` nor `clinical:46` as a string. Matching raw spec_refs
    against the selected ids made a range record invisible here while `contract_scaffold` — which
    expanded ranges all along — reported the row `mapped`: two halves of one page disagreeing."""
    rows = [{"tab": "6.Clin", "row": n, "item_id": f"clinical:{n}", "domain": "clinical",
             "variable": f"V{n}", "content_hash": f"{n:012d}", "text": "", "fields": {},
             "header": [], "cells": []} for n in (17, 30, 46)]
    contract = "```yaml\nvariable_id: FAMILY\nspec_refs: [clinical:17-46]\n```\n"
    s = _slice(str(_synthetic(rows=rows, contract=contract)), "clinical", items=["clinical:30"])
    assert len(s["current_records"]) == 1, s["current_records"]
    assert s["coverage"][0]["disposition"] == "mapped", s["coverage"]
    assert "FAMILY" in s["current_records"][0]


def test_spec_ref_expansion_has_exactly_one_implementation():
    """It had SIX: twice in contract_binding, once in contract_scaffold (with its own copy of the
    regex), once in spec_digest, once in the I8 lint, and a `split(":")` in the slicer that saw a
    range as neither endpoint."""
    import contract_binding, contract_lint, contract_scaffold
    assert contract_lint.spec_ref_rows("clinical:17-46")[0] == ("clinical", 17)
    assert len(contract_lint.spec_ref_rows("clinical:17-46")) == 30
    assert contract_lint.spec_ref_rows("clinical:17") == (("clinical", 17),)
    assert contract_lint.spec_ref_rows("none") == () and contract_lint.spec_ref_rows("") == ()
    assert contract_lint.spec_ref_ids(["clinical:17-19", "none"]) == \
        {"clinical:17", "clinical:18", "clinical:19"}
    for mod in (contract_binding, contract_scaffold, spec_slice):
        assert mod.spec_ref_rows is contract_lint.spec_ref_rows if hasattr(mod, "spec_ref_rows") \
            else True
    # no module keeps its own range loop any more
    import inspect
    for mod in (contract_binding, contract_scaffold):
        assert "range(int(" not in inspect.getsource(mod), mod.__name__


def test_an_ambiguous_variable_name_is_refused_with_the_item_ids():
    """A name is not an identifier: per-line families repeat names, and silently slicing every match
    is a drafting unit nobody chose."""
    rows = [{"tab": "7.Tx", "row": n, "item_id": f"treatment:{n}", "domain": "treatment",
             "variable": "LOTSTART", "content_hash": f"{n:012d}", "text": "", "fields": {},
             "header": [], "cells": []} for n in (11, 12)]
    try:
        _slice(str(_synthetic(rows=rows)), "treatment", variable="LOTSTART")
    except SystemExit as e:
        assert "matches 2 rows" in str(e) and "treatment:11" in str(e), str(e)
    else:
        raise AssertionError("an ambiguous --variable sliced silently")


def test_item_selectors_use_the_canonical_parser_and_never_drop_what_they_name():
    rows = [{"tab": "6.Clin", "row": n, "item_id": f"clinical:{n}", "domain": "clinical",
             "variable": f"V{n}", "content_hash": f"{n:012d}", "text": "", "fields": {},
             "header": [], "cells": []} for n in (61, 62, 63)]
    d = _synthetic(rows=rows)
    assert [r["item_id"] for r in _slice(str(d), "clinical", items=["clinical:62"])["rows"]] == \
        ["clinical:62"]
    assert len(_slice(str(d), "clinical", items=["clinical:61-63"])["rows"]) == 3
    for bad, why in (("clinical", "not a `<domain>:<row>`"), ("clinical:99", "not in domain")):
        try:
            _slice(str(d), "clinical", items=[bad])
        except SystemExit as e:
            assert why in str(e), (bad, str(e))
        else:
            raise AssertionError(f"--item {bad} was accepted")


def test_a_slice_reproducing_vendor_DOCUMENTATION_is_refused():
    """The classification says a human judged this material eligible. This asks whether its CONTENT
    agrees — which is what governance/WORKFLOW.md actually requires, since eligibility follows the
    content's provenance and not the recorded field alone. Until this existed the two could disagree
    silently, and on both prostate packs they did: 40 quotations each."""
    rows = [{"tab": "6.Clin", "row": 49, "item_id": "clinical:49", "domain": "clinical",
             "variable": "BP", "content_hash": "aaaaaaaaaaaa", "text": "",
             "fields": {"notes": 'Per Knowledge Center, (see Article "Lab and Vitals Tables Variable '
                                 'Detail") TestResultCleaned is provided for select LOINCs when...'},
             "header": [], "cells": []}]
    try:
        _slice(_resign(_synthetic(rows=rows)), "clinical")
        raise AssertionError("a slice reproducing vendor documentation was produced")
    except SystemExit as e:
        # The ARTIFACT-level check now fires first and is the stronger one: it refuses the whole
        # `ai_extraction` rather than one slice of it, so prose in a domain nobody has sliced is
        # caught too. The slice-level scan stays for the other AI_READABLE files.
        assert "vendor documentation" in str(e).lower(), str(e)
    else:
        raise AssertionError("a slice quoting vendor documentation was produced")


def test_vendor_TABLE_NAMES_are_not_the_thing_being_checked():
    """The distinction the whole check turns on. A scan for `Flatiron` or `Enhanced_MetProstate` would
    refuse every slice in the repository, because naming the vendor tables a variable reads is what a
    contract IS — and it would flag `From Flatiron, we receive the earliest date of evidence`, which
    is a sponsor VERDICT about the feed and crosses the boundary by design."""
    rows = [{"tab": "6.Clin", "row": 2, "item_id": "clinical:2", "domain": "clinical",
             "variable": "MET", "content_hash": "bbbbbbbbbbbb", "text": "",
             "fields": {"source": "Enhanced_MetProstate.MetDiagnosisDate",
                        "notes": "From Flatiron, we receive the earliest date of evidence of "
                                 "metastasis to a site. Reads enhanced_mortality for DOD."},
             "header": [], "cells": []}]
    s = _slice(str(_synthetic(rows=rows)), "clinical")
    assert s["rows"], "a legitimate vendor mapping was refused"
    assert spec_slice.boundary_errors(s) == []


def test_the_boundary_scanner_has_one_definition_and_a_governed_list():
    import source_manifest
    assert spec_slice.sm.vendor_prose is source_manifest.vendor_prose
    markers = source_manifest.boundary_markers()
    assert "knowledge center" in markers, markers
    # the governed list, not a literal in shared code — and never a vendor or table name
    assert (REPO / "governance" / "ai_boundary.yaml").exists()
    for forbidden in ("flatiron", "enhanced_", "testresultcleaned"):
        assert not any(forbidden in m for m in markers), (forbidden, markers)


def test_the_boundary_policy_going_missing_is_a_FAILURE_not_a_clean_result():
    """The check's off switch was `rm`. `boundary_markers()` returned [] when the policy file was
    missing or unreadable, and an empty marker list produces zero findings — so deleting
    governance/ai_boundary.yaml made every pack report clean. Written in the same change that argued
    eligibility must fail closed."""
    import shutil
    import source_manifest
    policy = REPO / "governance" / "ai_boundary.yaml"
    if not policy.exists():
        return
    backup = Path(tempfile.mkdtemp()) / "ai_boundary.yaml"
    _TMPDIRS.append(str(backup.parent))
    shutil.copy(policy, backup)
    # Built BEFORE the deletion, so its registration is valid and the DELETION is the only variable.
    d = _synthetic()
    try:
        policy.unlink()
        source_manifest._MARKERS = None                # the cache would otherwise hide the deletion
        try:
            _slice(str(d), "demographics")
        except SystemExit as e:
            # Either refusal is correct and both are fail-closed: the ARTIFACT gate reaches the
            # policy first now, and its message says the artifact cannot be shown free of vendor
            # documentation. What must never happen is a clean slice.
            assert ("boundary cannot be checked without it" in str(e)
                    or "policy cannot be read" in str(e)), str(e)
        else:
            raise AssertionError("a deleted AI-boundary policy produced a slice")
    finally:
        shutil.copy(backup, policy)
        source_manifest._MARKERS = None


def test_the_four_config_states_are_not_collapsed_into_two():
    """"No config yet" is a new tumour's legitimate state. A config that is unreadable, or declares no
    sources, is a DEFECT — rendering either as "no declared sources yet" would hand a drafter the
    new-tumour licence on a pack with no such excuse."""
    if not _has_pack():
        return
    d = _copy()
    (d / "config").mkdir(exist_ok=True)
    (d / "config" / "data_product.yaml").write_text("refresh: 2026m06\n", encoding="utf-8")
    assert _slice(str(d), "demographics")["config_state"] == "no_sources_block"
    assert "is a defect in" in spec_slice.render(_slice(str(d), "demographics"))

    (d / "config" / "data_product.yaml").write_text("- not\n- a mapping\n", encoding="utf-8")
    try:
        _slice(str(d), "demographics")
    except SystemExit as e:
        assert "unreadable" in str(e), str(e)
    else:
        raise AssertionError("an unreadable config was treated as a slice-able state")


def test_style_records_are_the_NEAREST_by_row_not_the_first_three():
    """They were the first three in the domain, so a clinical variable at row 140 was shown examples
    from rows 2-4 and the word "nearby" was untrue."""
    big = REPO / "products" / "oncology" / "prostate" / "202606"
    if not (big / "spec_pipeline" / "out" / "extracted.json").exists():
        return
    s = _slice(_approved(big), "clinical", variable="WEIGHT", style_cap=3)
    target = s["rows"][0]["row"]

    # Measured through `variable_id`, which survives redaction, against the rows the CONTRACT says
    # each of those variables covers. The old version read `spec_refs` straight out of the returned
    # block; those are answer-bearing and are now replaced with their shape before any caller sees
    # them, so reading them back would only have proved the redaction had not happened.
    text = (big / "handoff" / "FUNCTIONAL_CONTRACT.md").read_text(encoding="utf-8")
    where = {}
    for b in spec_slice.cl.records(text):
        vid = next((l.split(":", 1)[1].strip() for l in b.splitlines()
                    if l.startswith("variable_id:")), None)
        rs = [int(r.split(":")[1]) for r in (spec_slice.cl._list(b, "spec_refs") or [])
              if r.startswith("clinical:") and r.split(":")[1].strip().isdigit()]
        if vid and rs:
            where[vid] = rs
    picked = [next(l.split(":", 1)[1].strip() for l in b.splitlines()
                   if l.startswith("variable_id:")) for b in s["style"]]
    assert picked, "no style records were selected"
    rows = [r for v in picked for r in where.get(v, [])]
    assert rows and max(abs(r - target) for r in rows) <= 5, (target, picked, rows)


def test_sheet_level_workbook_findings_reach_the_slice_and_do_not_look_stale():
    """`spec_lint` keys WORKBOOK_STRUCTURE findings to a SHEET — `<tab>:(sheet)` — not to a row.

    Those exist to surface requirements Excel is hiding: formula cells with no cached value, hidden
    rows, partial merges. Filtering findings by ROW id dropped them, and the same-run check then read
    them as citing a row that does not exist and REFUSED TO SLICE AT ALL. Latent only because the
    current packs happen to carry none — the first real .xlsx with one hidden row would have hit it,
    which is precisely the production path.
    """
    if not _has_pack():
        return
    d = _copy()
    lj = d / "spec_pipeline" / "out" / "lint.json"
    payload = json.loads(lj.read_text(encoding="utf-8"))
    tab = json.loads((d / "spec_pipeline" / "out" / "extracted.json").read_text(encoding="utf-8"))
    tab = [r for r in tab["rows"] if r.get("domain") == "demographics"][0]["tab"]
    payload["findings"].append({"item_id": f"{tab}:(sheet)", "tab": tab, "row": 0,
                                "variable": "(sheet)", "kind": "WORKBOOK_STRUCTURE",
                                "detail": "3 formula cell(s) with no cached value",
                                "severity": "HIGH"})
    lj.write_text(json.dumps(payload), encoding="utf-8")

    s = _slice(str(d), "demographics")          # must not raise
    got = [f for f in s["findings"] if f["item_id"].endswith(":(sheet)")]
    assert got, "the sheet-level finding was filtered out of its own sheet's slice"
    assert "WORKBOOK_STRUCTURE" in spec_slice.render(s)

    # and a sheet id for a DIFFERENT sheet must not leak into this domain's slice
    other = _slice(str(d), "study_period")
    assert not [f for f in other["findings"]
                if f["item_id"] == f"{tab}:(sheet)"], "a sheet finding leaked across domains"


def test_a_negative_style_cap_is_refused_not_reinterpreted():
    """`[:style_cap]` turned a negative cap into a slice-from-the-end: -1 returned FIFTEEN style
    records instead of none. Refused rather than clamped — silently reinterpreting a caller's number
    is how a cap stops meaning what it says."""
    big = REPO / "products" / "oncology" / "prostate" / "202606"
    if not (big / "spec_pipeline" / "out" / "extracted.json").exists():
        return
    try:
        _slice(_approved(big), "demographics", style_cap=-1)
    except SystemExit as e:
        assert ">= 0" in str(e), str(e)
    else:
        raise AssertionError("a negative style cap was accepted")


def test_source_keys_come_from_the_shared_config_resolver():
    """The engine merges `sources:` with the ACTIVE delivery-format overlay.
    `source_check.load_product_config` is the loader the build, the schema validator and profile_facts
    all use; a private read of the raw mapping is a second, staler answer that agrees only until the
    first pack with an overlay."""
    big = REPO / "products" / "oncology" / "prostate" / "202606"
    if not (big / "config" / "data_product.yaml").exists():
        return
    import source_check as sc, yaml
    cfg = sc.load_product_config(str(big))
    assert cfg is not None
    assert _slice(_approved(big), "demographics")["sources"] == sorted(cfg.sources)

    # The packs in the repo today have no active overlay, so raw and merged AGREE — which means the
    # assertion above passes either way and proves nothing. Build a pack that HAS one: a source that
    # exists only under `formats:<data_format>:sources` is invisible to a raw read of `sources:` and
    # present through the shared resolver. That is the divergence the reuse exists to prevent.
    d = _copy(big)
    cpath = d / "config" / "data_product.yaml"
    raw = yaml.safe_load(cpath.read_text(encoding="utf-8"))
    fmt = (raw.get("run") or {}).get("data_format") or raw.get("data_format") or "EDM"
    raw.setdefault("formats", {}).setdefault(fmt, {}).setdefault("sources", {})
    raw["formats"][fmt]["sources"]["overlay_only_source"] = "t_overlay_only"
    cpath.write_text(yaml.safe_dump(raw), encoding="utf-8")

    got = _slice(str(d), "demographics")["sources"]
    assert "overlay_only_source" in got, (
        "a source declared only by the active delivery-format overlay is missing — the slice is "
        "reading the raw `sources:` mapping instead of the shared resolver")


def test_the_slice_does_not_re_derive_the_domain():
    """Domains come from `extracted.json`'s own field. Recomputing them from the tab label here would
    be a second mapping free to disagree with the pipeline's — and the tab label is exactly what
    differs per tumour."""
    if not _has_pack():
        return
    data = json.loads((PACK / "spec_pipeline" / "out" / "extracted.json").read_text(encoding="utf-8"))
    expected = [r["item_id"] for r in data["rows"] if r.get("domain") == "outcomes"]
    got = [r["item_id"] for r in _slice(_approved(PACK), "outcomes")["rows"]]
    assert got == expected, "the slice's row set disagrees with the extraction's own domain field"



CONTRACT_WITH_GAP = """# Contract

| variable_id | spec_refs | spec_digest | required_rule | source | grain | anchor | window | record_selection | tie_break | derivation | cohort_applicability | missing | units | depends_on | output | status | decision_ids | gap_ids | publish | acceptance | notes | implementation_refs |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| AGE | [demographics:6] | aaaaaaaaaaaa | AGE rule | {kind: derived} | [patientid] | n/a | n/a | n/a | n/a | n/a | all | n/a | years | [] | {role: published} | {requirement: draft} | [] | [G-AGE-BAND] | {ads: configured} | n/a | n/a | [none] |
"""

QC_REGISTER = """# Spec QC findings

| ID | Spec ref | Defect | Impact | Disposition | Status |
|---|---|---|---|---|---|
| SQ-01 | `5.Demo:6` | birthyear delivered as YEAR only | AGE approximate | return to RWB | **OPEN** |
| SQ-02 | `7.Treatment:40` | another domain entirely | n/a | return to RWB | **OPEN** |
| SQ-03 | `9.NoSuchTab:3` | cites a sheet this workbook does not have | n/a | n/a | **OPEN** |
"""

GAPS_REGISTER = """# Engine gaps

| Gap ID | Section \u00b7 row it labels |
|---|---|
| G-AGE-BAND | Config \u00b7 age band edges not configurable |
| G-UNRELATED | Engine \u00b7 something else entirely |
"""


def test_the_slice_carries_the_QC_and_GAP_indexes_for_ITS_rows_only():
    """The slice carried a decision index and nothing about the other two registers.

    So a drafter working one domain could see that a question was already raised and could NOT see
    that the defect was already a QC finding or the shortfall already a gap — and two agents working
    two domains would each raise the same finding under a different id, in the one register nobody
    deduplicates afterwards.

    Relevance differs per register because the registers differ: QC findings carry a `Spec ref`, so
    they match the rows in this slice; gaps carry none, so they match by being CITED by a record on
    those rows. Handing over either register whole would put every other domain's answers in front of
    the drafter, which is what the slice exists to prevent.
    """
    d = _synthetic(contract=CONTRACT_WITH_GAP,
                   registers={"SPEC_QC_FINDINGS.md": QC_REGISTER, "ENGINE_GAPS.md": GAPS_REGISTER})
    s = _slice(str(d), "demographics")

    assert [f["id"] for f in s["qc_findings"]] == ["SQ-01"], s["qc_findings"]
    assert s["qc_findings"][0]["status"] == "OPEN"
    assert "birthyear" in s["qc_findings"][0]["summary"]

    assert [g["id"] for g in s["gaps"]] == ["G-AGE-BAND"], s["gaps"]
    assert "age band" in s["gaps"][0]["summary"]

    # ...and the rendered slice says both, so this is not a JSON-only feature
    text = spec_slice.render(s)
    assert "SQ-01" in text and "G-AGE-BAND" in text
    assert "SQ-02" not in text and "G-UNRELATED" not in text


def test_a_register_citing_a_sheet_the_pack_does_not_have_is_REPORTED_not_dropped():
    """`SPEC_QC_FINDINGS.md` cites by TAB LABEL while everything else cites by canonical domain, and
    the labels are hand-written. Matching is punctuation-insensitive (`3.DataPrep` is `3.data prep`)
    and no fuzzier than that — `5B.ClinVars` against a workbook's `5B. ClinChars` are different words,
    and linking them would attach a finding to a row nobody said it was about.

    A citation that resolves nowhere must therefore be REPORTED. Dropping it silently makes a recorded
    defect read as "no finding on this row", which is the same failure as not having the index at all.
    Live case: prostate/202606's register carries six such citations.
    """
    d = _synthetic(registers={"SPEC_QC_FINDINGS.md": QC_REGISTER})
    s = _slice(str(d), "demographics")
    assert "9.NoSuchTab:3" in s["unresolved_register_refs"], s["unresolved_register_refs"]
    # a resolvable label is NOT reported as unresolved
    assert not any(r.startswith("5.Demo:") for r in s["unresolved_register_refs"]), \
        s["unresolved_register_refs"]
    assert "resolve nowhere" in spec_slice.render(s)


def test_the_sanitized_extraction_is_governed_SEPARATELY_from_what_it_derives_from():
    """Eligibility was read off the classification of the UNSANITIZED input, and on both prostate
    packs that classification said `sponsor_ai_eligible` about a stand-in that demonstrably
    contained vendor prose. Three claims were live at once — the material is eligible, its content is
    restricted, the derivation is sanitized — and only the third is true of the file AI opens.

    The derived artifact is now registered in its own right, and every field on it is a way an
    approval could otherwise outlive what it was given over.
    """
    import json as _json
    import source_manifest as _sm

    d = _synthetic()
    assert _sm.ai_readable(str(d))[0], _sm.ai_readable(str(d))[1]
    art = _sm.ai_extraction(str(d))
    assert art and art["material_type"] == "ai_extraction"
    assert art["derived_from"] == "spec_doc", "the artifact does not name what it derives from"

    out = d / "spec_pipeline" / "out" / "extracted.json"

    # RE-EXTRACTION REVOKES THE APPROVAL. Nobody has looked at the new bytes.
    data = _json.loads(out.read_text(encoding="utf-8"))
    data["extraction"]["fingerprint"] = "0000deadbeef0000"
    out.write_text(_json.dumps(data), encoding="utf-8")
    ok, why = _sm.ai_readable(str(d))
    assert not ok and any("re-run after the approval" in w for w in why), why
    data["extraction"]["fingerprint"] = art["extraction_fingerprint"]

    # WEAKENING THE MARKER LIST REVOKES IT TOO — otherwise an approval given under a strict policy
    # keeps standing while the redactor removes less.
    data["extraction"]["redaction"]["policy_sha256"] = "0" * 64
    out.write_text(_json.dumps(data), encoding="utf-8")
    ok, why = _sm.ai_readable(str(d))
    assert not ok and any("redaction policy" in w for w in why), why
    data["extraction"]["redaction"]["policy_sha256"] = art["redaction_policy_sha256"]
    out.write_text(_json.dumps(data), encoding="utf-8")
    assert _sm.ai_readable(str(d))[0]

    # ...and the property being approved is CHECKED, not taken on trust: an artifact hand-edited to
    # reintroduce vendor prose is refused even though policy and fingerprint still match.
    data["rows"][0]["text"] = 'Per Knowledge Center, (see Article "X") Y applies.'
    out.write_text(_json.dumps(data), encoding="utf-8")
    _resign(d)
    ok, why = _sm.ai_readable(str(d))
    assert not ok and any("vendor documentation" in w for w in why), why


def test_the_approval_names_the_BYTES_the_FILE_and_a_settled_STATUS():
    """What the record bound before this: a run id and a policy digest, both of them values INSIDE the
    file they were supposed to identify.

    So `extracted.json` could be hand-edited — a `required_rule` rewritten to something the spec never
    said, a record added — and every check passed: the fingerprint was untouched because it is stored,
    and the vendor-prose scan sees marker text only, of which a rewritten rule contains none.
    `path_or_link` was written by the registration helper and read by nothing, so the record could name
    a different file entirely. And the helper emitted `status: pending` with a `why_provisional` saying
    the review had not happened, beside four signature fields saying it had — one artifact, two
    statements, and a pack keeps whichever a reader reaches first.
    """
    import json as _json
    import source_manifest as _sm

    d = _synthetic()
    out = d / "spec_pipeline" / "out" / "extracted.json"
    src = d / "source_refs.yaml"
    assert _sm.ai_readable(str(d))[0], _sm.ai_readable(str(d))[1]

    # THE BYTES. Edit a rule and leave the fingerprint alone — the shape that passed everything.
    data = _json.loads(out.read_text(encoding="utf-8"))
    data["rows"][0]["required_rule"] = "whatever the drafter preferred"
    out.write_text(_json.dumps(data), encoding="utf-8")
    ok, why = _sm.ai_readable(str(d))
    assert not ok and any("edited after the approval" in w for w in why), why
    _resign(d)
    assert _sm.ai_readable(str(d))[0], _sm.ai_readable(str(d))[1]

    def _swap(old, new):
        src.write_text(src.read_text(encoding="utf-8").replace(old, new, 1), encoding="utf-8")

    # THE FILE. A record pointing at a decoy is an approval of nothing.
    (d / "decoy.json").write_text(out.read_text(encoding="utf-8"), encoding="utf-8")
    _swap(f"path_or_link: {out}", f"path_or_link: {d}/decoy.json")
    ok, why = _sm.ai_readable(str(d))
    assert not ok and any("names a different file" in w for w in why), why
    _swap(f"path_or_link: {d}/decoy.json", f"path_or_link: {out}")

    # THE STATUS. A signature on a material the same record calls provisional.
    _swap("status: reviewed", "status: pending\n    why_provisional: not yet")
    ok, why = _sm.ai_readable(str(d))
    assert not ok and any("two statements about one artifact" in w for w in why), why
    _swap("status: pending\n    why_provisional: not yet", "status: reviewed")

    # THE COUNTS a person reads. Understating what was removed is a summary of a different file.
    _swap("redacted_cells: 0", "redacted_cells: 3")
    ok, why = _sm.ai_readable(str(d))
    assert not ok and any("describes a different run" in w for w in why), why
    _swap("redacted_cells: 3", "redacted_cells: 0")
    assert _sm.ai_readable(str(d))[0], _sm.ai_readable(str(d))[1]

    # ...and DELETING them is not how you avoid the comparison. They were checked only when present,
    # so an approval could omit the one sentence a reviewer actually reads and still be accepted.
    # A count of ZERO is an answer and must stay one: `unstated` reads 0 as blank, so requiring these
    # through the ordinary path would refuse the commonest correct case — a pack with nothing to
    # redact — which is why `field_unstated` asks about PRESENCE for a count.
    for field in ("redacted_cells", "redacted_rows"):
        _swap(f"    {field}: 0\n", "")
        ok, why = _sm.ai_readable(str(d))
        assert not ok and any(f"does not state `{field}`" in w for w in why), (field, why)
        src.write_text(src.read_text(encoding="utf-8").replace(
            "    derived_from:", f"    {field}: 0\n    derived_from:", 1), encoding="utf-8")
    assert _sm.ai_readable(str(d))[0], _sm.ai_readable(str(d))[1]


def test_a_restricted_ANCESTOR_is_refused_however_many_links_away():
    """The chain check read the immediate parent only, and `check()` deliberately lets an
    `ai_extraction` derive from any material in the pack (workbook -> stand-in -> extraction is
    the legal shape). So ONE more registered link — a tidied copy of a delivered data dictionary —
    moved a `vendor_restricted` document out of view while every individual link looked correct.

    An unresolvable or cyclic chain is a refusal for the same reason: it is an unanswered question
    about where the content came from, and `unanswered` is never `eligible` anywhere else here.
    """
    import source_manifest as _sm
    d = _synthetic(ai_class="vendor_restricted")     # `spec_doc` is the restricted ancestor
    src = d / "source_refs.yaml"
    text = src.read_text(encoding="utf-8")
    # Insert a clean middle link and re-point the extraction at it: spec_doc <- tidied <- extraction.
    text = text.replace("  - material_id: sanitized_extraction",
                        "  - material_id: tidied\n"
                        "    material_type: extraction_input\n"
                        "    status: pending\n    why_provisional: synthetic\n"
                        "    derived_from: spec_doc\n"
                        "    ai_classification: sponsor_ai_eligible\n"
                        "    classified_by: R. Classifier\n    classified_date: \"2026-07-27\"\n"
                        "  - material_id: sanitized_extraction", 1)
    src.write_text(text.replace("derived_from: spec_doc\n    extraction_fingerprint",
                                "derived_from: tidied\n    extraction_fingerprint", 1),
                   encoding="utf-8")
    ok, why = _sm.ai_readable(str(d))
    assert not ok and any("vendor_restricted" in w and "tidied" in w for w in why), why

    # A chain that names a material the pack does not carry.
    d2 = _synthetic()
    s2 = d2 / "source_refs.yaml"
    s2.write_text(s2.read_text(encoding="utf-8").replace(
        "derived_from: spec_doc\n    extraction_fingerprint",
        "derived_from: nowhere\n    extraction_fingerprint", 1), encoding="utf-8")
    ok, why = _sm.ai_readable(str(d2))
    assert not ok and any("leaves the record" in w for w in why), why


def test_a_signed_extraction_reads_and_a_pending_one_is_refused_with_an_actionable_reason():
    """Both halves, but the readable one on a signed COPY rather than a live pack — because a live pack's
    signed state is not a fixture, it changes.

    An earlier version asserted the LIVE prostate packs were SIGNED and readable. When a provenance scrub
    regenerated the extraction bytes, the human approval that covered the OLD bytes was correctly reset to
    `pending` (AI must not re-assert a human approval over bytes nobody re-reviewed), and the test broke —
    it had pinned the moment rather than the property. `_approved` re-signs a throwaway copy, so the
    readable path is proven without depending on any live pack's status; the refusal is asserted on the
    live packs, which currently register their extraction as pending, and it must stay actionable — the
    tool computes every derivation field and leaves ONLY the five human fields TODO.
    """
    import source_manifest as _sm
    # readable path — on a signed copy, independent of any live pack's current status
    signed = _approved(PACK)
    ok, why = _sm.ai_readable(signed)
    assert ok, why
    art = _sm.ai_extraction(signed)
    for field in ("classified_by", "approved_by"):
        assert not _sm.unstated(art.get(field)), f"{field} is unanswered"
        assert " " in str(art[field]), f"{field}={art[field]!r} is not a person's name"
    # Refusal path, over whichever packs are still UNSIGNED — discovered, not listed. This named
    # three packs and went red the day one of them was approved, which is a maintenance burden
    # disguised as a check: the property is about the refusal, not about any particular pack. A
    # signed pack is now simply skipped, and the guard at the end fails if none is left.
    import product_gates as _pg
    live = [REPO / rel for rel in sorted(_pg.products(str(REPO)))]
    checked = 0
    for pack in live:
        if not (pack / "spec_pipeline" / "out" / "extracted.json").exists():
            continue
        ok, why = _sm.ai_readable(str(pack))
        if ok:
            continue                       # somebody signed this one; it is the other half's subject
        checked += 1
        assert any("ai_extraction" in w for w in why), why
        # ...and the tool can compute everything EXCEPT the five human fields.
        block, err = _sm.ai_extraction_block(str(pack))
        assert not err, err
        for field in ("extraction_fingerprint", "redaction_policy_sha256", "derived_from",
                      "sha256", "redacted_cells", "redacted_rows"):
            line = next(l for l in block.splitlines() if l.strip().startswith(field + ":"))
            assert "TODO" not in line, f"{field} is machine-knowable and came out TODO: {line}"
        for field in ("ai_classification", "classified_by", "classified_date"):
            line = next(l for l in block.splitlines() if l.strip().startswith(field + ":"))
            assert "TODO" in line, f"{field} is a human act and the tool filled it in: {line}"
        # the APPROVAL fields emit commented out: a pending block must not carry them as values
        # (a placeholder approval is schema-illegal and approval-shaped), and signing means
        # uncommenting them by hand
        for field in ("approved_by", "approval_date"):
            assert not any(l.strip().startswith(field + ":") for l in block.splitlines()), \
                f"{field} emitted as a VALUE on a pending block — a placeholder approval"
            assert any(l.strip().startswith(f"# {field}:") for l in block.splitlines()), \
                f"{field} is missing even as the commented signing slot"
    assert checked, "no unsigned pack with an extraction — the refusal half checked nothing"


def test_the_starting_point_is_the_shape_the_drafting_tool_ACCEPTS():
    """The section that removes the hand-strip — and it renders on NO live pack, so it needs this.

    prostate/202606 has every spec row mapped, so `scaffolded: 0` and this section never appears;
    oc/202606 has 299 scaffolded records and its sanitized extraction is unapproved, so the slicer
    refuses it outright. A rendering exercised by neither pack is a rendering nobody has seen, which
    is why the payload here carries an injected scaffold record.

    What it holds: the block a drafter SAVES contains only judgment fields, and the four the tool
    fills in from the extraction are visible but out of that block. Before this, the section was a
    raw `scaffold.json` dump — every record carrying `spec_refs`, `spec_digest`, `required_rule` and
    `status`, all four of which `contract_record` refuses, so the generated starting point had to be
    hand-edited before the tool that consumes it would take it.
    """
    import contract_scaffold as cs
    if not _has_pack():
        return
    s = _slice(_approved(PACK), "demographics")
    s = dict(s, scaffold=[{"variable_id": "TESTVAR",
                           "spec_refs": ["demographics:9"], "spec_digest": "abc123def456",
                           "required_rule": "the rule as the spec states it",
                           "status": {"requirement": "draft"},
                           "source": "TODO", "lint_flags": [], "spec_columns": []}])
    text = spec_slice.render(s)

    assert "## Starting points — 1" in text, text[:400]
    body = text.split("## Starting points")[1]
    saved = body.split("```yaml")[1].split("```")[0]

    # The block the drafter edits carries NO field the tool refuses. Matched as a TOP-LEVEL key:
    # a substring test reports `name_status:` inside the `output` dict, and a check that cries wolf
    # on a legitimate field is one somebody loosens rather than reads.
    keys = {ln.split(":", 1)[0] for ln in saved.splitlines() if ln and not ln.startswith((" ", "-"))}
    # VACUITY GUARD. Reverting this section to the raw `scaffold.json` dump yields indented JSON, so
    # `keys` comes back empty and the loop below passes over nothing — the check would report clean on
    # exactly the regression it exists to catch. Establish that keys were parsed at all first.
    assert {"variable_id", "source", "output", "implementation_refs"} <= keys, \
        f"no top-level keys parsed from the saved block — this check would be vacuous: {sorted(keys)}"
    for field in cs.MACHINE_OWNED:
        assert field not in keys, \
            f"the saved block carries {field}, which contract_record refuses — the hand-strip is back"
    assert "status" not in keys, "the saved block carries `status`, which the tool settles"
    assert "variable_id: TESTVAR" in saved and "implementation_refs: [none]" in saved, saved

    # ...and it is the SAME text `judgment_stub` produces. Rendering it a second way here would be a
    # second definition of what a drafter answers, which is the duplication this section removed.
    assert cs.judgment_stub("TESTVAR").rstrip() in saved

    # The evidence stays READABLE — a drafter must be able to check what the tool will fill in
    # against the row above — it just is not in the file they edit.
    assert "what the tool fills in from the extraction" in body
    assert "abc123def456" in body and "the rule as the spec states it" in body

    # The literal next command, so nothing has to be composed.
    assert "contract_record.py <file> --product" in body and s["product"] in body


def test_the_slice_reports_gate_1_as_three_states_not_one_verdict():
    """A SLICE ONLY EXISTS IF ONE OF THE THREE PASSED, WHICH IS EXACTLY WHY IT MUST NAME ALL THREE.

    The slicer refuses unless the sanitized extraction is approved for AI use. That refusal is about
    ONE derived artifact, and it says nothing about whether the authoritative workbook has been
    registered or whether these rows were extracted from it — but the reader in front of a rendered
    slice has a document that plainly worked, and "Gate 1 ✓" is the summary they will write.

    On every pack today the honest answer is three different states with one open at minimum, and
    the third is the one a single verdict hides completely: a stand-in can be internally consistent,
    lint clean and fully traced, and still state a rule less precisely than the approved workbook.
    Whether "the spec is silent on X" is a finding or an artefact of the stand-in depends on it.

    Asserted against `source_manifest`'s own answers, not against fixed strings, so a pack that
    genuinely closes Gate 1 reports it and this test follows rather than pinning today's state.
    """
    import source_manifest
    pack = _approved(PACK)
    lines = spec_slice.gate1_states({"product": pack})
    body = "\n".join(lines)

    for what in ("AI access to the sanitized extraction", "The authoritative workbook",
                 "The extraction basis"):
        assert what in body, f"the slice does not report `{what}` separately:\n{body}"

    ok, _why = source_manifest.ai_readable(pack)
    spec = source_manifest.authoritative(pack) or {}
    basis_id = source_manifest.pipeline_source_id(pack)
    basis = next((m for m in source_manifest.materials(pack) or []
                  if m.get("material_id") == basis_id), {})
    workbook_backed = basis.get("material_type") == source_manifest.PROGRAM_SPEC
    closed = ok and spec.get("status") == source_manifest.REVIEWED and workbook_backed

    assert ("Gate 1 overall: closed" in body) == closed, \
        f"the overall verdict disagrees with the three states it is drawn from:\n{body}"
    if not workbook_backed:
        assert "stand-in" in body, \
            f"rows extracted from `{basis_id}` are reported as though they came from the workbook"
    if spec.get("status") != source_manifest.REVIEWED:
        assert "PENDING" in body, "an unregistered authoritative workbook reads as registered"

    # ...and it reaches the RENDERED slice, not just this function. A derivation nothing prints is a
    # correct answer nobody sees, which is the same as not having it.
    rendered = spec_slice.render(_slice(pack, "demographics"))
    assert "GATE 1 — three states, not one verdict" in rendered
    assert "Producing this slice does NOT mean Gate 1 passed" in rendered


if __name__ == "__main__":
    import traceback
    failed = 0
    for _name, _fn in sorted(globals().items()):
        if _name.startswith("test_") and callable(_fn):
            try:
                _fn()
                print(f"  ok   {_name}")
            except BaseException:                     # noqa: BLE001
                failed += 1
                print(f"  FAIL {_name}")
                traceback.print_exc()
    print(f"\n{'FAILED' if failed else 'OK'} — {failed} failure(s)")
    sys.exit(1 if failed else 0)
