"""One row per key, chosen the same way every time.

Seven places in the engine call `dropDuplicates(["patientid"])` on a source assumed to be one row
per patient. `dropDuplicates` keeps an ARBITRARY row, so where the assumption is false the build
publishes whichever row the physical layout happened to yield — a value chosen by partitioning and
shuffle rather than by any approved rule, and free to change on a re-run with no diff anywhere.

The properties that matter are the ones a unit test on a fixed frame cannot see, so they are
tested the way the review asked for them:

  * ROW PERMUTATION. The same rows in a different order must produce the same output.
  * REPARTITIONING. One partition or seven must produce the same output.
  * EXACT DUPLICATES ARE LOSSLESS. Byte-identical rows carry no disagreement.
  * THE PACK'S RULE WINS WHERE IT HAS ONE. `order_by` is honoured; the total-order tail only
    breaks ties the rule leaves open.

Run: python3 platform/tests/test_grain.py  (or pytest). Spark-only — skips without pyspark.
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))

from engine import grain                                        # noqa: E402

try:
    from pyspark.sql import SparkSession
except Exception:
    SparkSession = None

try:
    import pytest
    pytestmark = pytest.mark.skipif(SparkSession is None, reason="pyspark not installed")
except Exception:
    pytest = None

_SPARK = None


def _spark():
    """The SHARED session. A second builder here would hand its settings to every later Spark
    suite through `getOrCreate`, which is how the prostate union smoke came to OOM."""
    global _SPARK
    if _SPARK is None:
        sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))
        import synthetic_sources
        _SPARK = synthetic_sources.session("grain")
    return _SPARK


SCHEMA = "patientid string, ecog int, src string"
# p1 DISAGREES with itself: same patient, two different ECOGs. p2 is an EXACT duplicate — the
# lossless case. p3 is clean.
ROWS = [("p1", 0, "a"), ("p1", 2, "b"), ("p2", 1, "c"), ("p2", 1, "c"), ("p3", 3, "d")]


def _F():
    from pyspark.sql import functions as F
    return F


def _out(rows, partitions=1, **kw):
    df = _spark().createDataFrame(rows, SCHEMA).repartition(partitions)
    got = grain.one_row_per_key(_F(), df, ["patientid"], **kw)
    return sorted((r["patientid"], r["ecog"], r["src"]) for r in got.collect())


def test_it_returns_exactly_one_row_per_key():
    got = _out(ROWS)
    assert [r[0] for r in got] == ["p1", "p2", "p3"], got


def test_the_pick_is_identical_under_every_row_permutation():
    """THE PROPERTY `dropDuplicates` DOES NOT HAVE. If this ever fails, the engine's output depends
    on the order rows happen to arrive in, and two runs over one cut can disagree."""
    import itertools
    baseline = _out(ROWS)
    for perm in itertools.islice(itertools.permutations(ROWS), 12):
        assert _out(list(perm)) == baseline, perm


def test_the_pick_is_identical_under_repartitioning():
    """Partition count is an execution detail. If it moves a published value, the value was never
    a function of the data."""
    baseline = _out(ROWS, partitions=1)
    for n in (2, 3, 7):
        assert _out(ROWS, partitions=n) == baseline, n


def test_exact_duplicates_are_collapsed_losslessly():
    """p2 appears twice, byte-identical. Removing one is not a choice between disagreeing rows."""
    got = dict((r[0], r[1]) for r in _out(ROWS))
    assert got["p2"] == 1
    # ...and a frame of nothing BUT exact duplicates loses no information at all.
    only = [("p9", 5, "z")] * 4
    assert _out(only) == [("p9", 5, "z")]


def test_the_packs_own_rule_wins_and_the_tail_only_breaks_what_it_leaves_open():
    """`order_by` is the specification's answer; the total-order tail exists solely to make the
    REMAINING tie deterministic, never to override a stated rule."""
    F = _F()
    hi = dict((r[0], r[1]) for r in _out(ROWS, order_by=[F.col("ecog").desc()]))
    lo = dict((r[0], r[1]) for r in _out(ROWS, order_by=[F.col("ecog").asc()]))
    assert hi["p1"] == 2 and lo["p1"] == 0, (hi, lo)
    # A rule that ties (every row has the same value under it) still yields a stable answer.
    tied = _out(ROWS, order_by=[F.lit(1)])
    assert tied == _out(ROWS, order_by=[F.lit(1)], partitions=5)


def test_the_cheap_path_and_the_window_path_agree_on_every_tie():
    """TWO IMPLEMENTATIONS, ONE ANSWER. With no caller rule the pick is `min(struct(...))`, which
    combines map-side; with a rule it is `row_number()` over a window. The cheap path exists
    because the window version pushed the seven-cohort union build over its heap — but a saving
    that quietly changed which row gets published would be worse than the cost.

    So the window path's tail is `asc_nulls_first`, matching struct comparison, and this asserts
    the two agree — including on NULLs, which is where such a difference would hide.
    """
    F = _F()
    rows = [("p1", None, "b"), ("p1", 2, "a"), ("p2", 4, None), ("p2", 4, "z"), ("p3", None, None)]
    cheap = _out(rows)                            # min(struct(...))
    windowed = _out(rows, order_by=[F.lit(1)])    # a rule that ties everywhere -> tail decides
    assert cheap == windowed, (cheap, windowed)


def test_conflicting_keys_counts_disagreement_and_not_redundancy():
    """A source that repeats a row verbatim has a redundancy problem; one that repeats it with a
    different value has a GRAIN problem. Only the second changes what gets published."""
    df = _spark().createDataFrame(ROWS, SCHEMA)
    k, r = grain.conflicting_keys(_F(), df, ["patientid"])
    assert (k, r) == (1, 2), (k, r)          # p1 only — p2's exact duplicate is not a conflict
    clean = _spark().createDataFrame([("p1", 0, "a"), ("p2", 1, "c")], SCHEMA)
    assert grain.conflicting_keys(_F(), clean, ["patientid"]) == (0, 0)


def test_assert_refuses_a_broken_grain_and_names_what_would_have_happened():
    df = _spark().createDataFrame(ROWS, SCHEMA)
    try:
        grain.assert_one_row_per_key(_F(), df, ["patientid"], "clinical.enhanced")
    except ValueError as exc:
        msg = str(exc)
        assert "clinical.enhanced" in msg and "DISAGREE" in msg
        assert "physical row order" in msg, msg
        assert "record_selection" in msg, "the message does not say how to state the rule"
    else:
        raise AssertionError("a source with two disagreeing rows per key was accepted")
    # `deterministic` is the pack saying it accepts the stable pick; there is deliberately no
    # third option meaning "proceed and do not tell me".
    assert grain.assert_one_row_per_key(_F(), df, ["patientid"], "x", policy="deterministic") is None
    clean = _spark().createDataFrame([("p1", 0, "a")], SCHEMA)
    assert grain.assert_one_row_per_key(_F(), clean, ["patientid"], "x") is None


def test_no_stage_reintroduces_a_bare_dropDuplicates():
    """THE REGRESSION GUARD, and it needs no Spark. Wiring seven call sites is worth nothing if the
    eighth is written next month — `dropDuplicates` is the obvious thing to reach for, and its
    defect is invisible in review because the line reads exactly like a correct one.

    Comments and docstrings may name it: this file and `grain.py` both explain what it does wrong,
    and a guard that forbade the WORD would force those explanations out of the codebase.
    """
    import re
    offenders = []
    for path in sorted((FRAMEWORK / "engine").rglob("*.py")):
        if path.name == "grain.py":
            continue                       # the module whose whole subject this is
        for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            code = line.split("#", 1)[0]
            if "dropDuplicates" in code:
                offenders.append(f"{path.relative_to(FRAMEWORK)}:{n}")
    assert not offenders, (
        f"bare dropDuplicates() at {offenders} — it keeps an ARBITRARY row, so the published value "
        f"is chosen by physical row order. Use grain.one_row_per_key().")


class _GrainCfg:
    """The minimal cfg surface `source_grain` reads: raw + sources + the reference-walk inputs."""
    def __init__(self, raw, sources):
        self.raw = raw
        self.sources = sources
        self.index_dates = {}
        self.index_source = "enhanced"
    def roles(self):
        return set()
    def pack(self, role):
        raise KeyError(role)


def test_a_declared_grain_is_checked_and_the_three_answers_never_collapse():
    """HELD, FAILED, and NOBODY CHECKED are three answers — the same split the availability states
    draw, now for grain. A declaration the run could not check (source not loaded, or a declared
    key column the delivered frame does not carry) lands in `skipped`/`unchecked`, never in a pass.

    Counts only, asserted: the report must carry no patient ids — it travels into manifests and
    chat, and the profiler just spent a change making that leak class impossible.
    """
    F = _F()
    spark = _spark()
    cfg = _GrainCfg(raw={"source_grain": {"demographics": ["patientid"],
                                          "lot": ["patientid", "linenumber"],
                                          "mortality": ["patientid"],
                                          "vitals": ["patientid", "testdate"]}},
                    sources={"demographics": "t_demo", "lot": "t_lot",
                             "mortality": "t_mort", "vitals": "t_vitals"})
    src = {
        # HELD: one row per patient
        "demographics": spark.createDataFrame([("p1", 1950), ("p2", 1960)],
                                              "patientid string, birthyear int"),
        # FAILED: p1's line 1 appears twice
        "lot": spark.createDataFrame([("p1", 1), ("p1", 1), ("p1", 2), ("p2", 1)],
                                     "patientid string, linenumber int"),
        # NOBODY CHECKED (column absent): frame has no testdate
        "vitals": spark.createDataFrame([("p1", 70)], "patientid string, weight int"),
        # mortality: NOBODY CHECKED (not loaded) — absent from src entirely
    }
    report = grain.source_grain_report(F, src, cfg)

    assert report["demographics"]["passed"] is True and report["demographics"]["rows"] == 2
    assert report["lot"]["passed"] is False
    assert (report["lot"]["duplicate_keys"], report["lot"]["duplicate_rows"]) == (1, 2), report["lot"]
    assert "not loaded" in report["mortality"]["skipped"]
    assert "testdate" in report["vitals"]["skipped"]
    # counts only — no patient identifier anywhere in the report
    import json as _json
    assert "p1" not in _json.dumps(report), "a patient id leaked into the grain report"

    gate = grain.source_grain_gate(report)
    assert gate["passed"] is False
    assert any("lot" in f and "1 key group(s) carry 2 rows" in f for f in gate["failures"]), gate
    assert len(gate["unchecked"]) == 2, gate["unchecked"]

    # ...and a DECLARED grain the run could not check FAILS while still naming the reason under
    # `unchecked`. This assertion used to hold the opposite — declared-but-unchecked passed — and
    # an external review named the hole: declare a grain on a column the delivery lacks and the
    # gate reported green with the claim never tested.
    del src["lot"]
    cfg.raw["source_grain"].pop("lot")
    gate2 = grain.source_grain_gate(grain.source_grain_report(F, src, cfg))
    assert gate2["passed"] is False and gate2["unchecked"], gate2
    assert any("could not be checked" in f for f in gate2["failures"]), gate2


def test_a_malformed_grain_declaration_fails_the_gate_not_just_the_lint():
    """A declaration error carried into the report must fail `source_grain_gate` — a run whose
    declaration was unreadable must not read as a run whose declarations all held."""
    F = _F()
    cfg = _GrainCfg(raw={"source_grain": {"demographics": []}},   # empty key list: malformed
                    sources={"demographics": "t_demo"})
    report = grain.source_grain_report(F, {}, cfg)
    assert "_declaration_errors" in report, report
    gate = grain.source_grain_gate(report)
    assert gate["passed"] is False and any("non-empty list" in f for f in gate["failures"]), gate


if __name__ == "__main__":
    if SparkSession is None:
        # The guard above is pure Python and MUST still run — a suite that skips everything on a
        # runner without pyspark, and exits 0, is the shape CI reads as a pass.
        test_no_stage_reintroduces_a_bare_dropDuplicates()
        print("ok  test_no_stage_reintroduces_a_bare_dropDuplicates")
        print("SKIP: pyspark not installed — the Spark properties did not run.")
        sys.exit(0)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
