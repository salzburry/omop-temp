"""Pure-Python tests for the platinum-sensitivity (PROC) compiled builders. No Spark.
Run: python3 test_proc.py (or pytest). The _plat_sen_table windowing path is Spark — see
test_stages_spark.py::test_platinum_sensitivity_classifies_pfi.
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))

from engine.stages.proc import _platinum_pred, _sensitivity_case   # noqa: E402


def test_platinum_pred():
    assert _platinum_pred(["%Carboplatin%", "%cisplatin%"]) == (
        "lower(linename) LIKE '%carboplatin%' OR lower(linename) LIKE '%cisplatin%'")


def test_sensitivity_case():
    assert _sensitivity_case(6) == (
        "CASE WHEN pfi IS NULL THEN NULL WHEN pfi < 6 THEN 'Resistant' ELSE 'Sensitive' END")


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
