"""The receipt, the exploration lane, the executive page, the demo chat — assembly, never judgement.

Four surfaces that make the platform's value visible without adding any authority: `receipt.py`
assembles one variable's whole provenance from the tools that own each link; `quick_counts.py`
runs counts-only feasibility queries that refuse to run rather than leave an assumed definition
unlogged; `executive_page.py` derives the portfolio view and the decision-leverage ranking from
the gate tools' own verdicts; `chat_demo.py` is a chat-shaped ROUTER over the read-only tools —
no model, no judgement, and the standing refusal for anything shaped like an approval. The
properties worth pinning are the refusals and the fail-closed absences — a receipt that printed
blanks, a lane that counted on silent definitions, a page that invented a gate state, or a chat
that performed a human act would each be the trust hole wearing a friendly face.

Run: python3 tests/test_value_surfaces.py (or pytest). Pure — no Spark.
"""
import json
import os
import re
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))
sys.path.insert(0, str(FRAMEWORK / "engine"))

import executive_page                                                       # noqa: E402
import quick_counts as qc                                                   # noqa: E402
import receipt as rc                                                        # noqa: E402

PACK = str(FRAMEWORK.parent / "products" / "oncology" / "prostate" / "202606")


def test_the_receipt_assembles_every_section_from_its_owner():
    """A record that cites a decision shows the register's row verbatim; the ledger with no
    build says NO BUILD RECORDED rather than an empty section; the name section reports where
    the physical name lives. FUDUR cites FUED-DEFINITION, which is OPEN — the receipt must say
    OPEN and must not paint an answer on it."""
    r = rc.receipt(PACK, "FUDUR")
    assert r["variable_id"] == "FUDUR"
    assert r["specification"]["refs"], "the spec citation fell off the receipt"
    ds = {d["decision"]: d for d in r["decisions"]}
    assert "FUED-DEFINITION" in ds and ds["FUED-DEFINITION"]["in_register"]
    assert ds["FUED-DEFINITION"]["status"] == "OPEN"
    assert not ds["FUED-DEFINITION"].get("approved_answer"), \
        "an OPEN decision must carry no answer on the receipt"
    assert r["build"]["recorded"] is False and "NO BUILD RECORDED" in r["build"]["note"]
    assert r["naming"]["physical_name"], r["naming"]
    text = rc.render(r)
    assert "NO BUILD RECORDED" in text and "FUED-DEFINITION" in text


def test_an_unknown_variable_is_refused_by_name_not_printed_empty():
    try:
        rc.receipt(PACK, "NOT_A_VARIABLE")
        raise AssertionError("an unknown variable printed a receipt")
    except SystemExit as e:
        assert "not a variable_id" in str(e)


def test_the_build_section_reads_a_real_manifest_and_says_so_when_it_cannot():
    """The branch whose absence hid a crash: with a manifest in the ledger the receipt reports
    the build identity (read_yaml returns a (doc, error) TUPLE — treating it as a dict raised
    AttributeError on the first real build); an unreadable manifest is a stated finding."""
    old = rc.ROOT
    try:
        with tempfile.TemporaryDirectory() as tmp:
            led = Path(tmp) / "refreshes" / "oncology" / "prostate" / "202606"
            led.mkdir(parents=True)
            (led / "2026q1.yaml").write_text(
                "engine_version: 1.123.0\ngit_commit: abc1234\nbuilt_at: 2026-08-19T00:00:00Z\n"
                "status: qc_pending\noutput_table: cat.sch.ads\n", encoding="utf-8")
            rc.ROOT = tmp
            b = rc._build(PACK)
            assert b["recorded"] is True and b["refresh"] == "2026q1"
            assert b["engine_version"] == "1.123.0" and b["output_table"] == "cat.sch.ads"
            (led / "2026q2.yaml").write_text("a: [broken\n", encoding="utf-8")
            b = rc._build(PACK)
            assert b["recorded"] is False and "MANIFEST UNREADABLE" in b["note"], b
    finally:
        rc.ROOT = old


def test_the_register_is_read_through_the_shared_column_vocabulary():
    """oc's register spells the answer column `Resolution`; a private column list in the
    receipt rendered its recorded answers as ABSENT (presence printed as absence). The receipt
    must agree with contract_lint's shared reader for every decision in the register."""
    import contract_lint as cl
    import decision_report
    oc = str(FRAMEWORK.parent / "products" / "oncology" / "oc" / "202606")
    _b, table, _i, _s = decision_report.blast_radius(oc)
    assert table, "the oc register vanished — this test lost its subject"
    got = {d["decision"]: d for d in rc._decisions(oc, sorted(table))}
    answered = 0
    for did, row in table.items():
        want = rc._blank_dash(cl.decision_answer(row))
        assert got[did]["approved_answer"] == want, (did, got[did], want)
        answered += bool(want)
    assert answered >= 1, "no oc decision carries an answer — the spelling pin proves nothing"


def test_the_lane_counts_pools_small_cells_and_never_emits_a_row():
    """Groups under the floor disappear into a pooled suppressed figure, and a LONE small cell
    drags the smallest shown group into the pool with it — otherwise total minus the shown
    groups recovers the hidden cell exactly, and the floor protects nothing (the review proved
    33 - 30 = 3). The result carries counts only — no key of any input row survives."""
    rows = [{"cohort": "C1", "id": f"p{i}"} for i in range(30)] + \
           [{"cohort": "C2", "id": f"q{i}"} for i in range(3)]
    out = qc.counts(rows, by="cohort")
    assert out["total"] == 33
    assert out["by"]["groups"] == {}, \
        f"a lone suppressed cell is recoverable by subtraction from {out}"
    assert out["by"]["suppressed_values"] == 2
    assert out["by"]["suppressed_rows"] == 33
    assert "p0" not in json.dumps(out) and "id" not in json.dumps(out)
    three = rows + [{"cohort": "C3", "id": f"r{i}"} for i in range(20)]
    out = qc.counts(three, by="cohort")
    assert out["by"]["groups"] == {"C1": 30}, out
    assert out["by"]["suppressed_values"] == 2, \
        "complementary suppression must pool a second group beside the lone small cell"
    assert out["by"]["suppressed_rows"] == 23      # 53-30 recovers only the POOLED PAIR's sum
    where = qc.parse_where(["cohort=C1"])
    assert qc.counts(rows, where=where)["total"] == 30


def test_an_assumption_is_logged_or_the_query_does_not_run():
    """A name no contract and no engine stage carries: refused with no ledger, refused with a
    ledger but no stated meaning, and recorded — name, meaning, pack — when both are given.
    A defined name logs nothing."""
    resolved = qc.resolve(["frobnicate", "regionl"])
    assert resolved["frobnicate"]["resolution"] == "assumption"
    assert resolved["regionl"]["resolution"] == "defined" and resolved["regionl"]["engine"]
    try:
        qc.log_assumptions(None, PACK, resolved, {}, {})
        raise AssertionError("an unlogged assumption ran")
    except SystemExit as e:
        assert "ASSUMPTIONS UNLOGGED" in str(e)
    with tempfile.TemporaryDirectory() as tmp:
        try:
            qc.log_assumptions(tmp, PACK, resolved, {}, {})
            raise AssertionError("an unstated meaning ran")
        except SystemExit as e:
            assert "UNSTATED ASSUMPTION" in str(e)
        n = qc.log_assumptions(tmp, PACK, resolved, {"frobnicate": "days from x to y"}, {})
        assert n == 1
        summary = qc.intake(tmp)
        assert summary["entries"] == 1
        assert summary["names"]["frobnicate"]["meanings"] == ["days from x to y"]
        clean = qc.log_assumptions(tmp, PACK, qc.resolve(["regionl"]), {}, {})
        assert clean == 0, "a defined name must not reach the ledger"


def test_the_floor_matches_the_profiler_and_demand_is_attributed_to_people():
    """Two pins in one: MIN_CELL must equal data_profiler.R's `min_cell` (a Python floor that
    drifted below the R profiler's would leak what the profiler suppresses), and --asked-by
    refuses a team name — demand attribution follows the same named-person doctrine as every
    other attribution here, while an attributed assumption lands in the ledger with its asker."""
    r_src = (FRAMEWORK / "tools" / "data_profiler.R").read_text(encoding="utf-8")
    m = re.search(r"min_cell\s*=\s*(\d+)L", r_src)
    assert m and int(m.group(1)) == qc.MIN_CELL, \
        f"quick_counts.MIN_CELL={qc.MIN_CELL} but data_profiler.R says {m and m.group(1)}"
    resolved = qc.resolve(["frobnicate"])
    with tempfile.TemporaryDirectory() as tmp:
        try:
            qc.log_assumptions(tmp, PACK, resolved, {"frobnicate": "x"}, {}, asked_by="HEOR")
            raise AssertionError("a team name attributed demand")
        except SystemExit as e:
            assert "person" in str(e)
        qc.log_assumptions(tmp, PACK, resolved, {"frobnicate": "x"}, {}, asked_by="P. Pilot")
        summary = qc.intake(tmp)
        assert summary["names"]["frobnicate"]["askers"] == ["P. Pilot"]


def test_a_near_miss_assumption_names_the_standard_spelling():
    reg = {"agegrp": {"engine": True, "packs": {}}}
    r = qc.resolve(["age_grp"], registry=reg)
    assert r["age_grp"]["resolution"] == "assumption"
    assert r["age_grp"]["near"] == ["agegrp"], r


def test_the_executive_page_is_the_owners_verdicts_rearranged():
    """Every real pack appears with six gates in the gate tools' own states; the leverage rows
    match blast_radius exactly (same decisions, same counts); and the page text never invents an
    approval — the words a human must type appear only inside the standing disclaimer."""
    f = executive_page.facts()
    slugs = {p["slug"] for p in f["packs"]}
    assert "prostate" in slugs and "oc" in slugs
    for p in f["packs"]:
        assert len(p["gates"]) == 6, p
        for g in p["gates"]:
            assert g["state"] in ("done", "in progress", "not started", "blocked",
                                  "cannot complete"), g
        assert p["next"]["who"], "the next action lost its owner"
    import decision_report
    blocks, _t, _i, _s = decision_report.blast_radius(
        os.path.join(str(FRAMEWORK.parent), "products", "oncology", "prostate", "202606"))
    mine = {r["decision"]: r["unblocks"] for r in f["leverage"] if r["pack"] == "prostate"}
    assert mine == {d: len(v) for d, v in blocks.items()}, \
        "the leverage column disagrees with blast_radius, which owns it"
    assert f["leverage"] == sorted(f["leverage"], key=lambda r: -r["unblocks"])
    page = executive_page.build_html(f)
    assert "prostate" in page and "records unblocked" in page
    # the earlier form of this guard held a newline in the needle and stripped newlines from
    # the haystack — an assertion that could not fail. The disclaimer must be PRESENT, and the
    # only "approved"-shaped word on the page must live inside it.
    flat = page.replace("\n", " ")
    assert "approvals are committed file edits by named people" in flat
    assert "never claims an approval" in page
    assert flat.count("approval") == 2, \
        f"an approval-shaped word appeared outside the standing disclaimer: {flat.count('approval')}"


def test_the_chat_is_a_router_that_refuses_the_human_acts():
    """Approval-shaped text gets the refusal and runs NOTHING; the known questions route to the
    right read-only tool with the LATEST pack version; the counts intent is pinned to a
    synthetic frame; gibberish gets the menu, not a guess."""
    import chat_demo as cd
    for text in ("please approve the biomarker window", "record the answer as 2011",
                 "sign off on gate 2", "mark FUED-DEFINITION resolved"):
        title, argv = cd.route(text)
        assert title is None and argv is None, f"a human act routed to a tool: {text!r}"
    r = cd.answer("approve it")
    assert "NAMED PERSON" in r["out"] and r["ran"] == "(nothing — by design)"
    title, argv = cd.route("receipt for FUDUR")
    assert argv[0] == "receipt.py" and "FUDUR" in argv and "202606" in argv[1], argv
    _t, argv = cd.route("what one signature buys")
    assert argv == ["executive_page.py", "--json"]
    _t, argv = cd.route("is the cohort big enough by cohort")
    assert argv[0] == "quick_counts.py" and "--synthetic" in argv, \
        "the web surface must never point the lane at a real frame"
    title, argv = cd.route("xyzzy plugh")
    assert title == "menu" and argv is None
    assert "never records" in cd.PAGE
    assert not re.search(r'(src|href)\s*=\s*"http', cd.PAGE), \
        "the demo page must be self-contained — no external scripts or styles"


def test_the_assistant_boundary_is_six_readonly_argv_arrays():
    """Assistant mode gives a model conversation, never reach: every declared tool maps
    through `_tool_argv` to a read-only tool with validated arguments; injection shapes are
    refused as values, not escaped; the counts tool is pinned synthetic; and the system prompt
    carries the refusal doctrine. No key in this environment → assistant_ready() is False and
    the page runs as the router."""
    import chat_demo as cd
    readonly = {"status.py", "receipt.py", "decision_report.py", "naming_registry.py",
                "quick_counts.py", "executive_page.py"}
    sample = {"product_status": {"slug": "prostate"},
              "variable_receipt": {"slug": "prostate", "variable_id": "FUDUR"},
              "open_decisions": {"slug": "oc"},
              "naming_registry": {},
              "synthetic_counts": {"slug": "prostate", "by": "cohort"},
              "portfolio_leverage": {}}
    assert {t["name"] for t in cd.ASSISTANT_TOOLS} == set(sample)
    for name, inp in sample.items():
        argv = cd._tool_argv(name, inp)
        assert argv[0] in readonly, argv
        assert not any(f.startswith("--apply") or f.startswith("--promote") or
                       f.startswith("--record") for f in argv), argv
    assert "--synthetic" in cd._tool_argv("synthetic_counts", sample["synthetic_counts"])
    for name, inp in (("variable_receipt", {"slug": "evil", "variable_id": "FUDUR"}),
                      ("variable_receipt", {"slug": "prostate", "variable_id": "x; rm"}),
                      ("synthetic_counts", {"slug": "prostate", "by": "a;b"}),
                      ("no_such_tool", {})):
        try:
            cd._tool_argv(name, inp)
            raise AssertionError(f"unvalidated shape ran: {name} {inp}")
        except ValueError:
            pass
    assert "NAMED PERSON" in cd.SYSTEM_PROMPT and "counts" in cd.SYSTEM_PROMPT
    if not os.environ.get("ANTHROPIC_API_KEY"):
        assert cd.assistant_ready() is False
    # the CLI backend's containment is STRUCTURAL now: Bash itself is disallowed alongside the
    # read tools (there is no command string for a suffix to ride on), and the MCP server
    # answers the protocol's three methods through the same _tool_argv allowlist — a call to a
    # tool outside the six is a typed error, not an executed command
    for t in ("Bash", "Read", "Grep", "Glob"):
        assert t in cd.CLI_DISALLOWED
    import io as _io
    import contextlib as _cl
    reqs = [{"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}},
            {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
            {"jsonrpc": "2.0", "id": 3, "method": "tools/call",
             "params": {"name": "no_such_tool", "arguments": {}}}]
    fake_in = _io.BytesIO(("\n".join(json.dumps(q) for q in reqs) + "\n").encode("utf-8"))
    fake_out = _io.BytesIO()

    class _Std:
        def __init__(self, buf):
            self.buffer = buf
    real_in, real_out = sys.stdin, sys.stdout
    try:
        sys.stdin, sys.stdout = _Std(fake_in), _Std(fake_out)
        with _cl.redirect_stderr(_io.StringIO()):
            cd.mcp_serve()
    finally:
        sys.stdin, sys.stdout = real_in, real_out
    replies = [json.loads(l) for l in fake_out.getvalue().decode("utf-8").splitlines()]
    assert replies[0]["result"]["serverInfo"]["name"] == cd.MCP_SERVER_NAME
    assert {t["name"] for t in replies[1]["result"]["tools"]} == \
        {t["name"] for t in cd.ASSISTANT_TOOLS}
    assert replies[2]["result"]["isError"] is True
    assert "no such tool" in replies[2]["result"]["content"][0]["text"]


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
