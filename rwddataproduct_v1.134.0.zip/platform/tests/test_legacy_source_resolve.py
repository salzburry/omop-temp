"""The legacy multi-source resolver, against a SYNTHETIC profile.

Synthetic on purpose: a real profile is restricted vendor-derived output and never enters the
checkout, so a test that needed one could not run in CI at all. The fixture carries only what the
resolver actually reads — table_base, table, column — plus the columns `profile_io.load` requires.

What is being held here is the fail-CLOSED half. Resolving the unambiguous case is the easy part and
the part that would be noticed if it broke. The cases that must NOT resolve — a column in two tables,
a column in none — are the ones that turn a guess into an approved mapping, and nothing else in the
repo would catch them.

Run: python3 platform/tests/test_legacy_source_resolve.py
"""
import os
import sys
import tempfile
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "platform" / "tools"))

import legacy_source_resolve as R                                       # noqa: E402
from profile_io import REQUIRED                                         # noqa: E402

# (table_base, column) — `dthdt` is deliberately in TWO tables and `nowhere` in none.
FIXTURE = [("t_mortality_v2", "dthdt"), ("t_mortality_v2", "fued"),
           ("t_death_backup", "dthdt"), ("t_enh_prostate", "metastaticdiagnosisdate"),
           ("t_enh_prostate_lot", "enddate")]


def write_profile(path, rows=FIXTURE):
    """A profile TSV with every column profile_io requires, values only where they are read."""
    header = list(dict.fromkeys(REQUIRED))
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\t".join(header) + "\n")
        for base, col in rows:
            cells = {"table_base": base, "table": f"{base}_2026m06", "column": col,
                     "kind": "categorical", "sampled": "TRUE", "n_rows": "10",
                     "n_rows_total": "10", "pct_missing": "0", "distinct": "3",
                     "date_min": "", "date_max": "", "top_values": ""}
            fh.write("\t".join(cells.get(h, "") for h in header) + "\n")
    return path


def index():
    with tempfile.TemporaryDirectory() as tmp:
        from profile_io import load
        tables, _ = load(write_profile(os.path.join(tmp, "profile_2026m06.tsv")))
        return R.column_index(tables)


LEGACY = ('{logical_table: "mortality + follow-up-end", physical_stem: t_mortality_v2, '
          'columns: {death: dthdt, fu_end: fued}}')


def test_the_index_carries_names_only():
    """Only table and column NAMES may cross out of a profile into a contract. If this ever returned
    counts, ranges or top values, restricted content would be one write away from the checkout."""
    idx = index()
    assert idx["fued"] == {"t_mortality_v2"}
    assert all(isinstance(v, set) and all(isinstance(x, str) for x in v) for v in idx.values())


def test_an_unambiguous_record_resolves_to_the_structured_shape():
    idx = {"dthdt": {"t_mortality_v2"}, "fued": {"t_mortality_v2"}}
    new, reasons = R.resolve("DTHFUFL", LEGACY, idx)
    assert reasons == []
    assert new == "{kind: vendor, inputs: {t_mortality_v2: {death: dthdt, fu_end: fued}}}", new


def test_a_column_in_two_tables_does_not_resolve():
    """The whole point. `dthdt` is in two profiled tables in the fixture, so which one this record
    means is a person's call — and a resolver that picked one would produce a mapping that reads as
    verified and never was."""
    new, reasons = R.resolve("DTHFUFL", LEGACY, index())
    assert new is None
    assert any("2 profiled tables" in r for r in reasons), reasons
    assert "t_death_backup" in reasons[0] and "t_mortality_v2" in reasons[0], reasons


def test_a_column_in_no_table_does_not_resolve():
    body = ('{logical_table: "a + b", physical_stem: t_x, columns: {x: nowhere, y: fued}}')
    new, reasons = R.resolve("X", body, index())
    assert new is None
    assert any("in NO profiled table" in r for r in reasons), reasons


def test_partial_resolution_is_no_resolution():
    """One good column and one ambiguous one must leave the record ENTIRELY alone. Writing the half
    that resolved would produce a record that looks structured and is missing an input."""
    body = '{logical_table: "a + b", physical_stem: t_x, columns: {ok: fued, bad: dthdt}}'
    new, _ = R.resolve("X", body, index())
    assert new is None


def test_a_profile_inside_the_checkout_is_refused():
    """Restricted output never enters the checkout, so a committed copy or fixture is not Gate 3
    evidence and the tool must not accept it as one."""
    assert R.profile_inside_checkout(str(REPO / "anything.tsv"))
    assert R.profile_inside_checkout(str(REPO / "products" / "x" / "profile_2026m06.tsv"))
    assert not R.profile_inside_checkout("/tmp/out/profile_2026m06.tsv")


def test_only_multi_source_legacy_records_are_touched():
    """A record already carrying `kind:`, and a single-table legacy record, are both left alone —
    this tool exists for the ambiguous multi-source shape and nothing else."""
    text = ("| variable_id | source |\n|---|---|\n"
            "| A | {kind: vendor, inputs: {t_a: {x: y}}} |\n"
            "| B | {logical_table: lab, physical_stem: t_lab, columns: {v: testresultcleaned}} |\n"
            "| C | " + LEGACY.replace("|", "\\|") + " |\n")
    assert [v for v, _ in R.legacy_records(text)] == ["C"]


def test_the_allowlist_only_ever_shrinks():
    with tempfile.TemporaryDirectory() as tmp:
        p = Path(tmp, "LEGACY_SOURCES.yaml")
        p.write_text("variables:\n  - DTHFUFL\n  - KEEPME\n", encoding="utf-8")
        dropped = R.shrink_allowlist(str(p), {"DTHFUFL"})
        assert dropped == 1
        assert "KEEPME" in p.read_text(encoding="utf-8") and "DTHFUFL" not in p.read_text(encoding="utf-8")


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except AssertionError as e:
                fails += 1
                print(f"  FAIL {name}: {e}")
    print(f"\n{'OK — 0 failure(s)' if not fails else f'FAILED — {fails} failure(s)'}")
    sys.exit(1 if fails else 0)
