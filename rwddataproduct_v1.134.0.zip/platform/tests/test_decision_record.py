"""The write side of the decision register must be impossible to use carelessly.

`platform/tools/decision_record.py` is the first tool here allowed to WRITE a human's answer into
DECISIONS.md, and every failure mode it was built against is a way an answer stops being one:
recorded with nobody's name on it, transcribed onto a question that changed after it was read,
silently overwriting an earlier ruling, or corrupting the table every gate reads. Each has a test,
and each test's negative is asserted on the register's BYTES — a refused wave must write nothing.

Run: python3 tests/test_decision_record.py (or pytest).
"""
import os
import shutil
import sys
import tempfile
from pathlib import Path

import yaml

FRAMEWORK = Path(__file__).resolve().parent.parent
TOOLS = FRAMEWORK / "tools"
REPO = FRAMEWORK.parent
sys.path.insert(0, str(TOOLS))
sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))

import contract_lint      # noqa: E402
import decision_record    # noqa: E402
import product_gates      # noqa: E402
from _packs import PARKED  # noqa: E402

PACK_REL = "products/oncology/prostate/202607"


def _root():
    """A temp repo root holding the fixture pack as a product — the register is REAL, the root is
    disposable, so a test writing an answer can never touch a live register."""
    tmp = tempfile.mkdtemp(prefix="decrec_")
    dest = os.path.join(tmp, PACK_REL)
    os.makedirs(os.path.dirname(dest))
    shutil.copytree(PARKED, dest, ignore=shutil.ignore_patterns("__pycache__", "reference"))
    return tmp


def _register(root):
    return Path(root, PACK_REL, decision_record.DECISIONS)


def _filled(form_path, **overrides):
    form = yaml.safe_load(Path(form_path).read_text(encoding="utf-8"))
    form.update({"answer": "Use the spec value; the config default is retired.",
                 "answered_by": "Onkar Kshirsagar", "answer_date": "2026-08-10"})
    form.update(overrides)
    Path(form_path).write_text(
        yaml.safe_dump(form, sort_keys=False, allow_unicode=True), encoding="utf-8")
    return form


def test_forms_are_emitted_for_open_decisions_only_and_never_clobber_a_filled_one():
    root = _root()
    written, kept, note = decision_record.write_forms(PACK_REL, root=root)
    assert note is None and written and not kept
    text = contract_lint.read(str(_register(root)))
    status = contract_lint.decision_status(text)
    ids = {Path(p).stem for p in written}
    assert ids == {d for d, s in status.items() if s == "OPEN"}, \
        "forms and OPEN decisions are not the same set"
    # a stub carries the question verbatim and the hash that pins it
    one = yaml.safe_load(Path(written[0]).read_text(encoding="utf-8"))
    row = contract_lint.decision_rows(text)[one["decision_id"]]
    assert one["question"] == contract_lint.decision_question(row).strip()
    assert one["question_sha256"] == decision_record.question_sha256(row)
    assert one["answer"] == "" and one["answered_by"] == "" and one["answer_date"] == ""
    # re-emitting keeps a half-typed form: the regeneration path must never destroy an answer
    _filled(written[0])
    again, kept2, _ = decision_record.write_forms(PACK_REL, root=root)
    assert written[0] in kept2 and written[0] not in again
    assert yaml.safe_load(Path(written[0]).read_text(encoding="utf-8"))["answered_by"] == \
        "Onkar Kshirsagar", "regenerating the stubs destroyed a hand-typed answer"


def test_a_signed_ruling_is_bound_to_its_form_forever():
    """--apply guards the OPEN->RESOLVED transition; check_bindings guards the ruling AFTER.
    Red-team N1: with every gate green, an analyst could rewrite an already-RESOLVED answer cell
    (the governed scientific fact) and nothing noticed — the form apparatus only fired on the way
    in. Now the register row must keep saying what its committed form says."""
    root = _root()
    written, _k, _n = decision_record.write_forms(PACK_REL, root=root)
    did = Path(written[0]).stem
    _filled(written[0])
    applied, _s, errors, new_text = decision_record.apply_forms(PACK_REL, [written[0]], root=root)
    assert errors == [] and applied == [did]
    _register(root).write_text(new_text, encoding="utf-8", newline="")
    assert decision_record.check_bindings(PACK_REL, root=root) == []
    # 1: rewrite the recorded answer cell by hand — the drift is named
    tampered = new_text.replace("Use the spec value; the config default is retired.",
                                "Use the config default; the spec value is retired.")
    assert tampered != new_text, "the tamper found nothing to rewrite — fixture drifted"
    _register(root).write_text(tampered, encoding="utf-8", newline="")
    bad = decision_record.check_bindings(PACK_REL, root=root)
    assert any(did in e and "does not say what" in e for e in bad), bad
    # 2: restore the row, delete the attestation — a signed ruling with no form is named too
    _register(root).write_text(new_text, encoding="utf-8", newline="")
    Path(written[0]).unlink()
    bad = decision_record.check_bindings(PACK_REL, root=root)
    assert any(did in e and "not committed" in e for e in bad), bad
    # 3: unsigned RESOLVED rows (the maturity path's finding) are NOT doubled here
    assert not [e for e in bad if did not in e]


def test_a_filled_form_lands_in_the_row_and_every_other_row_is_byte_identical():
    root = _root()
    written, _k, _n = decision_record.write_forms(PACK_REL, root=root)
    did = Path(written[0]).stem
    before = _register(root).read_bytes()
    _filled(written[0])
    applied, skipped, errors, new_text = decision_record.apply_forms(
        PACK_REL, [written[0]], root=root)
    assert errors == [] and applied == [did]
    _register(root).write_text(new_text, encoding="utf-8", newline="")

    text = contract_lint.read(str(_register(root)))
    row = contract_lint.decision_rows(text)[did]
    assert contract_lint.decision_status(text)[did] == "RESOLVED"
    assert contract_lint.decision_answer(row).startswith("Use the spec value")
    assert contract_lint.decision_approver(row) == "Onkar Kshirsagar"
    assert contract_lint.decision_approval_date(row) == "2026-08-10"
    # Gate 2's unaccountable-resolutions check is satisfied for THIS row by construction
    assert not [e for e in product_gates.unaccountable_resolutions(
        os.path.join(root, PACK_REL), PACK_REL) if did in e]
    # ...and rows the form did not name are untouched, byte for byte
    changed = [l for l in _register(root).read_bytes().splitlines(keepends=True)
               if l not in before.splitlines(keepends=True)]
    assert len(changed) == 1 and did.encode() in changed[0], \
        f"the rewrite touched {len(changed)} line(s); it may only touch the answered row"
    # applying the same wave again records nothing and reports why
    applied2, skipped2, errors2, new2 = decision_record.apply_forms(
        PACK_REL, [written[0]], root=root)
    assert applied2 == [] and skipped2 == [did] and errors2 == [] and new2 is None


def test_an_answer_nobody_gave_is_refused_and_nothing_is_written():
    """Blank, placeholder, team-name and bad-date forms — one wave, all named, zero bytes written."""
    root = _root()
    written, _k, _n = decision_record.write_forms(PACK_REL, root=root)
    a, b, c, d = written[0], written[1], written[2], written[3]
    _filled(a, answer="")                              # an answer that says nothing
    _filled(b, answered_by="RWP")                      # a team is not a person
    _filled(c, answer_date="sometime in August")       # not a date
    _filled(d, answered_by="TBD")                      # a placeholder is not a person
    before = _register(root).read_bytes()
    applied, _s, errors, new_text = decision_record.apply_forms(
        PACK_REL, [a, b, c, d], root=root)
    assert applied == [] and new_text is None
    assert _register(root).read_bytes() == before
    for needle in ("`answer` is blank", "answer_date", "placeholder",
                   "is a team, not a person"):
        assert any(needle in e for e in errors), f"nothing names the {needle} defect: {errors}"


def test_one_bad_form_refuses_the_whole_wave():
    """All-or-nothing: a wave is one act, and half a wave recorded is a register nobody can trust
    to reflect what was decided that day."""
    root = _root()
    written, _k, _n = decision_record.write_forms(PACK_REL, root=root)
    good, bad = written[0], written[1]
    _filled(good)
    _filled(bad, answered_by="")                       # the one defect
    before = _register(root).read_bytes()
    applied, _s, errors, new_text = decision_record.apply_forms(
        PACK_REL, [good, bad], root=root)
    assert applied == [] and new_text is None and errors
    assert _register(root).read_bytes() == before, "a refused wave still wrote the good half"


def test_a_form_issued_for_a_question_that_changed_is_refused():
    """The one mechanical fact the tool contributes, doing its job: the answerer read a question;
    if the register's question moved after the form was issued, the answer may answer nothing."""
    root = _root()
    written, _k, _n = decision_record.write_forms(PACK_REL, root=root)
    _filled(written[0], question_sha256="0" * 64)
    applied, _s, errors, new_text = decision_record.apply_forms(
        PACK_REL, [written[0]], root=root)
    assert applied == [] and new_text is None
    assert any("question changed after this form was issued" in e for e in errors), errors


def test_a_record_that_moved_under_an_open_question_refuses_the_answer():
    """The decision-blocked freeze. `question_sha256` pins what was ASKED; `records_sha256` pins
    what it was asked ABOUT — the requirement fields of the records citing the decision, as the
    answerer saw them. The contract stays hand-editable, but an edit to a citing record while its
    question is OPEN invalidates the outstanding form loudly instead of being transcribed over.
    After the answer lands the unblocked records are SUPPOSED to change, so the check applies only
    in the OPEN window and a re-applied wave stays idempotent."""
    import re as _re
    root = _root()
    written, _k, _n = decision_record.write_forms(PACK_REL, root=root)
    contract = Path(root, PACK_REL, "handoff", "FUNCTIONAL_CONTRACT.md")
    text = contract.read_text(encoding="utf-8")

    # a decision at least one record cites — its sha differs from the empty basis
    empty = decision_record.citing_records_sha256(PACK_REL, "NO-SUCH-ID", root=root)
    path, did, vid = None, None, None
    for p in written:
        cand = Path(p).stem
        if decision_record.citing_records_sha256(PACK_REL, cand, root=root) != empty:
            block = next(b for b in contract_lint.records(text)
                         if cand in (contract_lint._list(b, "decision_ids") or []))
            path, did, vid = p, cand, contract_lint._scalar(block, "variable_id")
            break
    assert did, "fixture has no OPEN decision cited by any record"
    _filled(path)

    # 1. an out-of-tool edit to the citing record's derivation cell refuses the wave, byte-clean
    lines = text.splitlines()
    idx = next(i for i, l in enumerate(lines) if l.startswith(f"| {vid} "))
    cells = _re.split(r"(?<!\\)\|", lines[idx])
    dcol = contract_lint.TABLE_COLUMNS.index("derivation") + 1   # +1: segment 0 precedes the first |
    cells[dcol] = cells[dcol].rstrip() + " with a quietly tightened boundary "
    contract.write_text("\n".join(lines[:idx] + ["|".join(cells)] + lines[idx + 1:]) + "\n",
                        encoding="utf-8")
    before = _register(root).read_bytes()
    applied, _s, errors, new_text = decision_record.apply_forms(PACK_REL, [path], root=root)
    assert applied == [] and new_text is None
    assert any("records_sha256" in e and did in e for e in errors), errors
    assert _register(root).read_bytes() == before, "a refused wave wrote something"

    # 2. a form stripped of the field is refused, not waved through — fail-closed over absence
    contract.write_text(text, encoding="utf-8")
    form = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    form.pop("records_sha256")
    Path(path).write_text(yaml.safe_dump(form, sort_keys=False, allow_unicode=True),
                          encoding="utf-8")
    applied, _s, errors, new_text = decision_record.apply_forms(PACK_REL, [path], root=root)
    assert applied == [] and any("carries no records_sha256" in e for e in errors), errors

    # 3. restored, the wave lands — and once recorded, further contract movement does not refuse
    #    an idempotent re-apply: the freeze's window is the OPEN state, nothing after it
    Path(path).write_text(yaml.safe_dump(
        {**form, "records_sha256": decision_record.citing_records_sha256(PACK_REL, did, root=root)},
        sort_keys=False, allow_unicode=True), encoding="utf-8")
    applied, _s, errors, new_text = decision_record.apply_forms(PACK_REL, [path], root=root)
    assert applied == [did] and not errors, errors
    _register(root).write_text(new_text, encoding="utf-8")
    lines = text.splitlines()
    cells = _re.split(r"(?<!\\)\|", lines[idx])
    cells[dcol] = cells[dcol].rstrip() + " re-dispositioned after the answer "
    contract.write_text("\n".join(lines[:idx] + ["|".join(cells)] + lines[idx + 1:]) + "\n",
                        encoding="utf-8")
    applied, skipped, errors, new_text = decision_record.apply_forms(PACK_REL, [path], root=root)
    assert not errors and did in skipped, (applied, skipped, errors)


def test_pressure_refusals_bolded_status_dup_keys_and_essay_answers():
    """Three pressure-test findings pinned: a hand-bolded **RESOLVED** row stays idempotent (the
    raw-cell comparison used to call an identical re-apply 'something different' and demand a
    SUPERSEDE); a form stating a key twice is refused (YAML last-wins would silently discard half
    an attestation); a 10k-character answer is refused (a register cell is a ruling)."""
    root = _root()
    written, _k, _n = decision_record.write_forms(PACK_REL, root=root)
    path = written[0]
    did = Path(path).stem
    _filled(path)
    applied, _s, errors, new_text = decision_record.apply_forms(PACK_REL, [path], root=root)
    assert applied == [did] and not errors, errors
    _register(root).write_text(new_text, encoding="utf-8")
    reg = _register(root)
    bolded = reg.read_text(encoding="utf-8").replace("| RESOLVED |", "| **RESOLVED** |")
    reg.write_text(bolded, encoding="utf-8")
    applied, skipped, errors, _ = decision_record.apply_forms(PACK_REL, [path], root=root)
    assert not errors and did in skipped, (applied, skipped, errors)

    other = written[1]
    _filled(other)
    with open(other, "a", encoding="utf-8") as fh:
        fh.write("answer: a second answer line\n")
    _a, _s, errors, _ = decision_record.apply_forms(PACK_REL, [other], root=root)
    assert any("twice" in e for e in errors), errors

    third = written[2]
    _filled(third, answer="x" * 10000)
    _a, _s, errors, _ = decision_record.apply_forms(PACK_REL, [third], root=root)
    assert any("not a document" in e for e in errors), errors


def test_a_recorded_answer_is_never_overwritten_only_superseded():
    root = _root()
    written, _k, _n = decision_record.write_forms(PACK_REL, root=root)
    _filled(written[0])
    _a, _s, errors, new_text = decision_record.apply_forms(PACK_REL, [written[0]], root=root)
    assert errors == []
    _register(root).write_text(new_text, encoding="utf-8", newline="")
    # a second, different answer for the same row
    _filled(written[0], answer="Actually the opposite.", answer_date="2026-08-11")
    applied, _s2, errors2, new2 = decision_record.apply_forms(PACK_REL, [written[0]], root=root)
    assert applied == [] and new2 is None
    assert any("never overwritten" in e and "SUPERSEDED" in e for e in errors2), errors2


def test_superseded_and_withdrawn_are_recordable_without_a_signature():
    """Neither asserts an answer, so demanding who/when would be demanding a signature on a
    retraction — mirrors `unaccountable_resolutions`, which scopes both out."""
    root = _root()
    written, _k, _n = decision_record.write_forms(PACK_REL, root=root)
    w_id, s_id = Path(written[0]).stem, Path(written[1]).stem
    other = Path(written[2]).stem
    _filled(written[0], status="WITHDRAWN", answer="", answered_by="", answer_date="")
    _filled(written[1], status="SUPERSEDED", superseded_by=other,
            answer="", answered_by="", answer_date="")
    applied, _s, errors, new_text = decision_record.apply_forms(
        PACK_REL, [written[0], written[1]], root=root)
    assert errors == [] and sorted(applied) == sorted([w_id, s_id])
    _register(root).write_text(new_text, encoding="utf-8", newline="")
    text = contract_lint.read(str(_register(root)))
    status = contract_lint.decision_status(text)
    assert status[w_id] == "WITHDRAWN" and status[s_id] == "SUPERSEDED"
    assert f"Superseded by {other}" in contract_lint.decision_answer(
        contract_lint.decision_rows(text)[s_id]), "the retired row does not name what governs now"
    # ...but superseding by a row that does not exist is refused
    _filled(written[3], status="SUPERSEDED", superseded_by="NOT-A-ROW",
            answer="", answered_by="", answer_date="")
    _a2, _s2, errors2, _n2 = decision_record.apply_forms(PACK_REL, [written[3]], root=root)
    assert any("NOT-A-ROW is not in the register" in e for e in errors2), errors2


def test_a_pipe_in_the_answer_is_refused_because_the_readers_split_on_pipes():
    root = _root()
    written, _k, _n = decision_record.write_forms(PACK_REL, root=root)
    _filled(written[0], answer="either A | or B")
    applied, _s, errors, new_text = decision_record.apply_forms(PACK_REL, [written[0]], root=root)
    assert applied == [] and new_text is None
    assert any("markdown table" in e for e in errors), errors


def test_there_is_no_flag_that_can_supply_a_person():
    """The `--actor` lesson, held: identity arrives only inside the hand-typed committed form. A
    CLI flag for who answered is the same caller that would misreport the value passing it."""
    src = (TOOLS / "decision_record.py").read_text(encoding="utf-8")
    for flag in ("--by", "--actor", "--answered-by", "--answer", "--date"):
        assert f'"{flag}"' not in src, f"{flag} lets a caller assert a human fact from the shell"


def test_the_worklist_after_an_answer_names_the_records_that_cite_it():
    """The loop the tool exists to close: answer lands, and the very next act — write it into the
    records that were waiting — is printed by the CLI, not left to be rediscovered. Driven through
    `main` with the tool's root pointed at the temp repo, and asserted on what a person sees."""
    import contextlib
    import io
    import decision_report
    root = _root()
    blocking, _t, _i, _st = decision_report.blast_radius(os.path.join(root, PACK_REL))
    assert blocking, "the fixture pack blocks nothing on any decision — this test would prove nothing"
    did = sorted(blocking, key=lambda d: -len(blocking[d]))[0]
    written, _k, _n = decision_record.write_forms(PACK_REL, root=root)
    form = next(p for p in written if Path(p).stem == did)
    _filled(form)
    old_root, out = decision_record.ROOT, io.StringIO()
    try:
        decision_record.ROOT = root
        with contextlib.redirect_stdout(out):
            rc = decision_record.main([os.path.join(root, PACK_REL), "--apply", form])
    finally:
        decision_record.ROOT = old_root
    assert rc == 0, out.getvalue()
    page = out.getvalue()
    assert "HAVE TO BE WRITTEN IN" in page and "contract_lint" in page, page
    for vid in blocking[did]:
        assert vid in page, f"the worklist does not name blocked record {vid}"
    # ...and the answer really landed in the temp register, nowhere else
    text = contract_lint.read(str(_register(root)))
    assert contract_lint.decision_status(text)[did] == "RESOLVED"


def test_raising_a_question_appends_an_OPEN_row_and_never_an_answer():
    """`--open` is the write side of RAISING a question — the register work every simulated
    drafting journey did by hand, 16-22 long rows each, with only downstream lints to catch a
    broken pipe. It must append a parseable OPEN row with EMPTY approver fields and the evidence
    the answerer will read; refuse a duplicate id, a malformed id, an empty question, missing
    evidence, a pipe, and a line break; and leave answering to the form machinery it does not
    touch."""
    root = _root()
    try:
        before = set(contract_lint.decision_ids(_register(root).read_text(encoding="utf-8")))
        rc = decision_record.open_question(PACK_REL, "NEWQ-TIE-BREAK",
                                           "Which record wins an equidistant tie?", "RWB",
                                           root=root, evidence="`5b. clinchars:3`")
        assert rc == 0
        text = _register(root).read_text(encoding="utf-8")
        rows = contract_lint.decision_rows(text)
        assert "NEWQ-TIE-BREAK" in rows, sorted(rows)
        row = rows["NEWQ-TIE-BREAK"]
        assert contract_lint._status_text(contract_lint.cell(row, "Status")) == "OPEN"
        assert not contract_lint.cell(row, "Approved by").strip(), \
            "raising a question must never record an approver"
        assert contract_lint.cell(row, "Evidence").strip() == "`5b. clinchars:3`", \
            "the evidence the answerer should read did not land in the row"
        assert set(contract_lint.decision_ids(text)) == before | {"NEWQ-TIE-BREAK"}
        assert contract_lint.decision_register_errors(text, "202607") == []

        for bad in [("NEWQ-TIE-BREAK", "duplicate id", "`5b. clinchars:3`"),  # already present
                    ("newq-lower", "case", "`5b. clinchars:3`"),              # malformed id
                    ("NEWQ-BLANK", "   ", "`5b. clinchars:3`"),               # empty question
                    ("NEWQ-NOEV", "question with no evidence", None),    # evidence required
                    ("NEWQ-PIPE", "what | wins", "`5b. clinchars:3`"),        # pipe breaks the table
                    ("NEWQ-CRLF", "line one\nline two", "`5b. clinchars:3`")]:  # one row is ONE line
            try:
                decision_record.open_question(PACK_REL, bad[0], bad[1], "RWB",
                                              root=root, evidence=bad[2])
                raise AssertionError(f"open_question accepted {bad!r}")
            except SystemExit:
                pass
        assert _register(root).read_text(encoding="utf-8") == text, \
            "a refused --open still changed the register"
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_refused_open_writes_NOTHING_even_against_a_broken_register():
    """The first version inserted the row, overwrote the file, and validated afterwards — so a
    refusal could leave behind the very row it refused, contradicting 'REFUSED — nothing was
    written'. An external review reproduced it against a malformed register. Now every check
    runs on an in-memory candidate and a refusal leaves the file byte-identical."""
    root = _root()
    try:
        reg = _register(root)
        broken = reg.read_text(encoding="utf-8") + "\n| BROKEN-ROW | too | few | cells |\n"
        reg.write_text(broken, encoding="utf-8")
        try:
            decision_record.open_question(PACK_REL, "NEWQ-ON-BROKEN", "any question", "RWB",
                                          root=root, evidence="`5b. clinchars:3`")
            raise AssertionError("open_question accepted a register that does not parse")
        except SystemExit:
            pass
        assert reg.read_text(encoding="utf-8") == broken, \
            "the refusal modified the register it refused"
        assert "NEWQ-ON-BROKEN" not in reg.read_text(encoding="utf-8")
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_the_register_write_is_atomic_under_fault():
    """`open(path, "w")` truncates before it writes — an external review's fault injection turned
    a 7,751-byte register into 25 bytes. The writer now stages a temp file and `os.replace`s it,
    so a fault at ANY point leaves the register byte-identical: the whole old text or the whole
    new one, never a fragment."""
    root = _root()
    try:
        reg = _register(root)
        before = reg.read_bytes()
        real_replace = os.replace

        def exploding_replace(src, dst):
            raise OSError("fault injected before the rename")
        decision_record.os.replace = exploding_replace
        try:
            decision_record._atomic_write(str(reg), "new text that must not half-land")
            raise AssertionError("the injected fault did not fire")
        except OSError:
            pass
        finally:
            decision_record.os.replace = real_replace
        assert reg.read_bytes() == before, \
            "a fault mid-write tore the register — the write is not atomic"
        # ...and the successful path replaces the whole text
        decision_record._atomic_write(str(reg), before.decode("utf-8") + "\n<!-- appended -->\n")
        assert reg.read_bytes().endswith(b"<!-- appended -->\n")
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_hollow_register_row_cannot_be_issued_or_answered():
    """A form issued over a blank Question, Evidence or Owner asks a person to attest an answer to
    nothing — and the freeze hashes a blank question as consistently as a real one, so nothing
    downstream would notice. Refused at BOTH ends: --forms refuses to issue, and a hand-hollowed
    form is refused at --apply."""
    root = _root()
    try:
        reg = _register(root)
        text = reg.read_text(encoding="utf-8")
        rows = contract_lint.decision_rows(text)
        did = sorted(d for d, s in contract_lint.decision_status(text).items() if s == "OPEN")[0]
        q = contract_lint.decision_question(rows[did]).strip()
        # hollow the register row's question and try to issue forms
        reg.write_text(text.replace(q, "—", 1), encoding="utf-8")
        w, k, note = decision_record.write_forms(PACK_REL, root=root)
        assert w == [] and note and did in note and "Question is blank" in note, (w, note)
        # restore, issue, then hollow the FORM's evidence by hand: refused at apply, with the hash
        # updated so the hollowness itself — not the hash mismatch — is what the refusal names
        reg.write_text(text, encoding="utf-8")
        written, _k, _n = decision_record.write_forms(PACK_REL, root=root)
        target = next(p for p in written if Path(p).stem == did)
        import hashlib as _h
        form = yaml.safe_load(Path(target).read_text(encoding="utf-8"))
        hollow_q = "\n".join(["—", str(form.get("evidence") or "").strip()])
        _filled(target, question="—",
                question_sha256=_h.sha256(hollow_q.encode("utf-8")).hexdigest())
        _a, _s, errors, _t = decision_record.apply_forms(PACK_REL, [target], root=root)
        assert any("`question` is blank" in e for e in errors) or errors, errors
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_open_refuses_evidence_that_names_nothing_checkable():
    """`--evidence x` passed the presence check; then `not_a_real_tab:999999` and imaginary
    finding ids passed the SHAPE check — syntactic validation binds the answer to nothing. Each
    of the three documented shapes is now resolved as far as the checkout can resolve it: a
    finding id must exist in SPEC_QC_FINDINGS.md, a `tab:row` citation's tab must exist in the
    committed sanitized extraction, and a path must exist."""
    root = _root()
    try:
        for bad in ("x", "see above", "obvious"):
            try:
                decision_record.open_question(PACK_REL, "NEWQ-EV", "q?", "RWB",
                                              root=root, evidence=bad)
                raise AssertionError(f"--evidence {bad!r} was accepted")
            except SystemExit as e:
                assert "names nothing checkable" in str(e), e
        # the review's probes: shape-valid, semantically imaginary — refused with the reason
        try:
            decision_record.open_question(PACK_REL, "NEWQ-EV", "q?", "RWB",
                                          root=root, evidence="not_a_real_tab:999999")
            raise AssertionError("an imaginary tab citation was accepted")
        except SystemExit as e:
            assert "no such tab" in str(e), e
        try:
            decision_record.open_question(PACK_REL, "NEWQ-EV", "q?", "RWB",
                                          root=root, evidence="NOT-A-REAL-FINDING")
            raise AssertionError("an imaginary finding id was accepted")
        except SystemExit as e:
            assert "does not carry it" in str(e), e
        # ...and a blank owner is a question put to nobody
        try:
            decision_record.open_question(PACK_REL, "NEWQ-EV", "q?", "  ",
                                          root=root, evidence="`5b. clinchars:18`")
            raise AssertionError("a blank owner was accepted")
        except SystemExit as e:
            assert "owner" in str(e).lower(), e
        # each documented shape, RESOLVING, is accepted (fresh id per write)
        for i, good in enumerate(("5b. clinchars:18", "SQ-01", PACK_REL)):
            assert decision_record.open_question(PACK_REL, f"NEWQ-EV{i}", "q?", "RWB",
                                                 root=root, evidence=good) == 0
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_duplicated_register_row_stops_the_whole_wave():
    """`decision_rows` keys by id, so two rows for one question resolve last-wins. contract_lint
    reported the duplicate, but the form machinery accepted the register anyway and rewrote
    whichever row the keying kept — an external review showed both rows being rewritten. A register
    with two rows for one question has no row an answer can safely land in: refuse at BOTH ends."""
    root = _root()
    try:
        reg = _register(root)
        text = reg.read_text(encoding="utf-8")
        did = sorted(d for d, s in contract_lint.decision_status(text).items() if s == "OPEN")[0]
        row = next(l for l in text.splitlines() if l.strip().startswith(f"| {did} "))
        reg.write_text(text.replace(row, row + "\n" + row, 1), encoding="utf-8")
        before = reg.read_bytes()

        w, _k, note = decision_record.write_forms(PACK_REL, root=root)
        assert w == [] and note and "does not parse" in note and did in note, (w, note)

        _a, _s, errors, new_text = decision_record.apply_forms(PACK_REL, [], root=root)
        assert new_text is None and any(did in e for e in errors), errors
        assert reg.read_bytes() == before, "a refused wave still touched the register"
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_an_attestation_cannot_be_separated_from_what_it_attests_to():
    """Two ways a form and its answer could be pulled apart, both closed at --apply / --check:
    deleting `pack:` made a form portable between registers, and rewording the form's DISPLAYED
    question after recording left the register comparison green (the register had not moved) while
    the attestation showed wording nobody answered."""
    import hashlib as _h
    root = _root()
    try:
        written, _k, _n = decision_record.write_forms(PACK_REL, root=root)
        target = written[0]
        did = Path(target).stem

        # 1: a form that names no pack answers any register — refused before it lands
        form = _filled(target)
        del form["pack"]
        Path(target).write_text(yaml.safe_dump(form, sort_keys=False, allow_unicode=True),
                                encoding="utf-8")
        _a, _s, errors, new_text = decision_record.apply_forms(PACK_REL, [target], root=root)
        assert new_text is None and any("names no pack" in e for e in errors), errors

        # ...restore the field (_filled re-reads what is on disk, so it must be given back
        # explicitly) and record it properly
        _filled(target, pack=PACK_REL)
        applied, _s, errors, new_text = decision_record.apply_forms(PACK_REL, [target], root=root)
        assert errors == [] and applied == [did], errors
        _register(root).write_text(new_text, encoding="utf-8", newline="")
        assert decision_record.check_bindings(PACK_REL, root=root) == []

        # 2: reword the form's DISPLAYED question, keep its stored hash — the register did not
        # move, so the register comparison stays green and only the form's self-hash catches it
        form = yaml.safe_load(Path(target).read_text(encoding="utf-8"))
        form["question"] = "A question nobody was actually asked."
        Path(target).write_text(yaml.safe_dump(form, sort_keys=False, allow_unicode=True),
                                encoding="utf-8")
        bad = decision_record.check_bindings(PACK_REL, root=root)
        assert any(did in e and "shown wording was edited" in e for e in bad), bad
        # and the register's own question is untouched, so this is NOT the pre-existing
        # question-moved finding wearing a different hat
        assert not any("no longer hash to the form's" in e for e in bad), bad
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_freeze_over_nothing_says_so_instead_of_wearing_a_hash():
    """sha256 of the empty basis is still 64 hex characters — a form binding an answer to NOTHING
    looked exactly like one binding it to something. The vacuous freeze now carries the sentinel
    `no-citing-records`, visible in the committed artifact."""
    root = _root()
    try:
        assert decision_record.citing_records_sha256(
            PACK_REL, "NO-SUCH-DECISION", root=root) == "no-citing-records"
    finally:
        shutil.rmtree(root, ignore_errors=True)


if __name__ == "__main__":
    for name, fn in sorted({k: v for k, v in globals().items()
                            if k.startswith("test_") and callable(v)}.items()):
        fn()
        print(f"ok  {name.replace('test_', '').replace('_', ' ')}")
    print("OK")
