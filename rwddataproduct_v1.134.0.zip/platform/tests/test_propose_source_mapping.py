"""The mapping copilot may count; it may never choose.

`platform/tools/propose_source_mapping.py` is the deterministic two-thirds of the recommend ->
validate -> human-approve workflow an external review specified. The properties worth tests are
the REFUSAL rules, because they are what separates it from the failure the review named — "much
safer than silently selecting the closest column name":

  * `map_candidate` only when EXACTLY ONE delivered table carries every required column;
  * two clean candidates is an AMBIGUITY -> do_not_map, never a ranking;
  * no evidence at all -> do_not_map with the availability disposition named as the next action;
  * a blocked mapping fails `--validate` with the blocker named, and a clean one still only
    "earns a review, never an application".

Run: python3 tests/test_propose_source_mapping.py (or pytest).
"""
import shutil
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))

import propose_source_mapping as psm   # noqa: E402

CONFIG = """\
data_product_id: g5_fixture
name: "g5 fixture"
owner: RWP
version: "1"
vendor: flatiron
tumor_class: solid
run: {refresh: "R", source_schema: "S", output_schema: "O", output_table: t, write_mode: overwrite}
lot: {line_number: linenumber}
study: {index_start: "2013-01-01", index_end: "2025-12-31"}
index:
  advanced_diagnosis_date: {source: enhanced, of: [diagnosisdate]}
cohorts:
  - {cohortn: 1, cohort: "C1", index: advanced_diagnosis_date}
sources:
  enhanced: t_enh_x
  lot: t_lot_x
source_grain:
  biomarkers: [patientid, biomarkername, biomarkerdate]
variables:
  - variables/clinical.yaml
"""

VARIABLES = """\
biomarkers:
  source: biomarkers
  name_column: biomarkername
  status_column: biomarkerstatus
  date_column: biomarkerdate
  panels:
    - {flag: her2, names: [HER2, ERBB2]}
"""

import profile_io                      # noqa: E402 — the header vocabulary has ONE owner

HDR = "\t".join(profile_io.REQUIRED + profile_io.PROVENANCE + ["type"])


def _tsv(path, tables, product_id="g5_fixture", source_mode="dbi", mode="full"):
    """A profiler-shaped TSV with embedded provenance and type column, as the profiler writes."""
    lines = [HDR]
    for tbl, cols in tables.items():
        for c in cols:
            lines.append(f"{tbl}_2026m06\t{tbl}\t{c}\tcategorical\tFALSE\t100\t100\t0.5\t10\t\t\t"
                         f"\t{product_id}\tsit_schema\t2026m06\t{source_mode}\t{mode}\tcharacter")
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")
    return str(path)


def _fixture(tmp, config=CONFIG):
    pack = Path(tmp) / "pack"
    (pack / "config").mkdir(parents=True)
    (pack / "variables").mkdir()
    (pack / "config" / "data_product.yaml").write_text(config, encoding="utf-8")
    (pack / "variables" / "clinical.yaml").write_text(VARIABLES, encoding="utf-8")
    return str(pack)


BASE_TABLES = {"t_enh_x": ["patientid", "diagnosisdate"], "t_lot_x": ["patientid", "linenumber"]}


def test_exactly_one_clean_candidate_is_the_only_map_candidate():
    """The mechanical case — and its two neighbours, which must both refuse.

    One full match -> map_candidate. Add a SECOND full match -> do_not_map (ambiguity is a
    decision, and ranking two clean candidates by score is the silent-closest-name failure with
    extra steps). Remove the columns -> do_not_map with blockers.
    """
    tmp = tempfile.mkdtemp()
    try:
        pack = _fixture(tmp)
        full = ["patientid", "biomarkername", "biomarkerstatus", "biomarkerdate"]

        one = _tsv(Path(tmp) / "one.tsv", {**BASE_TABLES, "t_enh_biomarker": full,
                                           "t_biomarker_lite": ["patientid", "biomarkername"]})
        doc = psm.proposal(pack, one)
        gap = next(g for g in doc["gaps"] if g["role"] == "biomarkers")
        assert gap["recommendation"] == "map_candidate", gap
        assert "A person still applies it" in gap["why"], gap["why"]
        best = gap["candidates"][0]
        assert best["table"] == "t_enh_biomarker" and not best["blockers"], best
        assert best["covered"] == best["of"] == 4, best
        # the runner-up carries its blocker in the open
        lite = next(c for c in gap["candidates"] if c["table"] == "t_biomarker_lite")
        assert any("absent" in b for b in lite["blockers"]), lite

        two = _tsv(Path(tmp) / "two.tsv", {**BASE_TABLES, "t_enh_biomarker": full,
                                           "t_biomarker_v2": full})
        gap = next(g for g in psm.proposal(pack, two)["gaps"] if g["role"] == "biomarkers")
        assert gap["recommendation"] == "do_not_map", gap
        assert "ambiguity" in gap["why"], gap["why"]

        none = _tsv(Path(tmp) / "none.tsv", dict(BASE_TABLES))
        gap = next(g for g in psm.proposal(pack, none)["gaps"] if g["role"] == "biomarkers")
        assert gap["recommendation"] == "do_not_map", gap
        assert "unavailable_by_design" in gap["why"], \
            "the no-evidence path must point at the availability disposition, not at a shrug"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_the_needed_columns_come_from_the_reading_blocks_own_words():
    """For an UNDECLARED role the engine's required_columns is rightly silent, so the evidence bar
    comes from what the reading block itself names — name/status/date columns and `of:` lists —
    plus patientid. If this returned only patientid, every delivered table would tie at 1/1 and
    the ambiguity refusal would fire on noise."""
    tmp = tempfile.mkdtemp()
    try:
        pack = _fixture(tmp)
        need = psm.needed_columns(pack, "biomarkers")
        assert need == ["biomarkerdate", "biomarkername", "biomarkerstatus", "patientid"], need
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_validate_names_the_blocker_and_a_pass_earns_only_a_review():
    tmp = tempfile.mkdtemp()
    try:
        pack = _fixture(tmp)
        tsv = _tsv(Path(tmp) / "p.tsv",
                   {**BASE_TABLES,
                    "t_enh_biomarker": ["patientid", "biomarkername", "biomarkerstatus",
                                        "biomarkerdate"],
                    "t_biomarker_lite": ["patientid", "biomarkername"]})
        assert psm.validate_mapping(pack, tsv, [("biomarkers", "t_enh_biomarker")]) == []
        bad = psm.validate_mapping(pack, tsv, [("biomarkers", "t_biomarker_lite")])
        assert any("grain key" in b and "biomarkerdate" in b for b in bad), bad
        missing = psm.validate_mapping(pack, tsv, [("biomarkers", "t_nowhere")])
        assert any("not in the delivered profile" in b for b in missing), missing
        # the CLI phrasing is part of the boundary: a pass must say review, never application
        import contextlib
        import io
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = psm.main([pack, "--profile", tsv, "--validate", "biomarkers=t_enh_biomarker"])
        assert rc == 0 and "earns a review, not an application" in buf.getvalue()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_the_patch_is_commented_proposal_text_and_the_tool_writes_nothing():
    """Every emitted mapping line is a comment, and running the tool leaves the pack's bytes
    untouched — the workflow's whole safety is that application is a person's edit."""
    tmp = tempfile.mkdtemp()
    try:
        pack = _fixture(tmp)
        tsv = _tsv(Path(tmp) / "p.tsv",
                   {**BASE_TABLES,
                    "t_enh_biomarker": ["patientid", "biomarkername", "biomarkerstatus",
                                        "biomarkerdate"]})
        before = {p: p.read_bytes() for p in Path(pack).rglob("*") if p.is_file()}
        text = psm.patch(psm.proposal(pack, tsv))
        assert all(line.startswith("#") for line in text.splitlines() if line.strip()), text
        assert "biomarkers: t_enh_biomarker" in text
        after = {p: p.read_bytes() for p in Path(pack).rglob("*") if p.is_file()}
        assert before == after, "the tool modified the pack"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_display_truncation_cannot_manufacture_uniqueness():
    """An external review caught the order: the recommendation was computed AFTER `top` truncated
    the list, so `--top 1` hid the second clean candidate and a genuine ambiguity printed as
    'exactly one'. The recommendation now reads the FULL list; `top` trims only the display."""
    tmp = tempfile.mkdtemp()
    try:
        pack = _fixture(tmp)
        full = ["patientid", "biomarkername", "biomarkerstatus", "biomarkerdate"]
        two = _tsv(Path(tmp) / "two.tsv", {**BASE_TABLES, "t_enh_biomarker": full,
                                           "t_biomarker_v2": full})
        gap = next(g for g in psm.proposal(pack, two, top=1)["gaps"] if g["role"] == "biomarkers")
        assert len(gap["candidates"]) == 1, "top=1 must still truncate the DISPLAY"
        assert gap["recommendation"] == "do_not_map" and "ambiguity" in gap["why"], gap
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_an_unknown_role_cannot_validate():
    """`--validate nosuchrole=t_enh_x` used to PASS: the required-column lookup was empty for an
    unknown role, so any existing table cleared it. No bar must refuse, never pass."""
    tmp = tempfile.mkdtemp()
    try:
        pack = _fixture(tmp)
        tsv = _tsv(Path(tmp) / "p.tsv", dict(BASE_TABLES))
        bad = psm.validate_mapping(pack, tsv, [("nosuchrole", "t_enh_x")])
        assert any("unknown role" in b for b in bad), bad
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_evidence_json_verifies_its_binding_before_ranking_anything():
    """The MAPPING_EVIDENCE route: names and kinds only, binding READ FROM THE PROFILE (an
    external review caught the CLI-typed version: a mistyped --product re-bound a real profile
    to the wrong pack). Wrong product, partial profile, synthetic source, an un-reviewed file,
    an unsigned review, and the old evidence version each refuse by name; a reviewed, matching
    file yields the same gaps the TSV route yields."""
    import json as _json
    tmp = tempfile.mkdtemp()
    try:
        pack = _fixture(tmp)
        tsv = _tsv(Path(tmp) / "p.tsv", dict(BASE_TABLES))
        import mapping_evidence as me
        doc = me.build(tsv)
        assert doc["product"] == "g5_fixture", "product no longer read from the profile"
        assert doc["source_schema"] == "sit_schema" and doc["cut"] == "2026m06"
        assert doc["source_mode"] == "delivered" and doc["profile_source_mode"] == "dbi"
        assert doc["profile_sha256"]
        # schema-level types beside the kinds — names only, still no measurement
        assert doc["column_types"]["t_enh_x"]["patientid"] == "character"
        flat = _json.dumps(doc)
        for banned in ("n_rows", "top_values", "pct_missing", "date_min", "date_max", "distinct"):
            assert banned not in flat, f"profile statistic {banned!r} leaked into the evidence"
        assert doc["ai_eligibility"]["state"] == "requires_human_review"

        evp = Path(tmp) / "MAPPING_EVIDENCE.json"
        evp.write_text(_json.dumps(doc), encoding="utf-8")
        try:
            psm.proposal(pack, str(evp))
        except SystemExit as e:
            assert "not 'reviewed'" in str(e), e
        else:
            raise AssertionError("an un-reviewed evidence file was accepted")

        # ...the human review, as a throwaway fixture records it
        reviewed = dict(doc, ai_eligibility={"state": "reviewed", "reviewed_by": "T. Test",
                                             "review_date": "2026-08-19"})

        # THE DETACHED HALF: an in-file review alone must refuse (the file is mutable after the
        # review), a registration whose sha does not match the bytes must refuse (drift), a
        # registration naming the wrong parent profile must refuse — and the correct
        # registration lets the loop below run.
        import hashlib as _hl

        def _register(sha, parent):
            (Path(pack) / "source_refs.yaml").write_text(
                "source_materials:\n"
                "  - source_id: map_ev\n"
                "    material_type: ai_mapping_evidence\n"
                "    status: reviewed\n"
                "    path_or_link: MAPPING_EVIDENCE.json\n"
                f"    sha256: {sha}\n"
                f"    parent_profile_sha256: {parent}\n"
                "    approved_by: T. Test\n"
                "    approval_date: 2026-08-19\n", encoding="utf-8")

        good_bytes = _json.dumps(reviewed).encode("utf-8")
        good_sha = _hl.sha256(good_bytes).hexdigest()
        evp.write_bytes(good_bytes)
        try:
            psm.proposal(pack, str(evp))
        except SystemExit as e:
            assert "NOT REGISTERED" in str(e), e
        else:
            raise AssertionError("an unregistered evidence file was accepted")
        _register("f" * 64, doc["profile_sha256"])
        try:
            psm.proposal(pack, str(evp))
        except SystemExit as e:
            assert "DRIFTED" in str(e), e
        else:
            raise AssertionError("evidence whose bytes differ from the registration ran")
        _register(good_sha, "e" * 64)
        try:
            psm.proposal(pack, str(evp))
        except SystemExit as e:
            assert "disagree about which delivery" in str(e), e
        else:
            raise AssertionError("a registration naming the wrong parent profile ran")
        _register(good_sha, doc["profile_sha256"])
        for field, value, why in ((None, None, None),
                                  ("reviewed_by", "RWP", "team, not a person"),
                                  ("reviewed_by", None, "is not set"),
                                  ("review_date", "2026-13-45", "not a real calendar date")):
            if field is None:
                evp.write_text(_json.dumps(reviewed), encoding="utf-8")
                assert [g["role"] for g in psm.proposal(pack, str(evp))["gaps"]] == \
                    [g["role"] for g in psm.proposal(pack, tsv)["gaps"]], \
                    "the evidence route and the TSV route disagree about the gaps"
                continue
            bad = dict(reviewed, ai_eligibility=dict(reviewed["ai_eligibility"], **{field: value}))
            evp.write_text(_json.dumps(bad), encoding="utf-8")
            try:
                psm.proposal(pack, str(evp))
            except SystemExit as e:
                assert why in str(e), (field, value, e)
            else:
                raise AssertionError(f"a review with {field}={value!r} was accepted")

        for field, value, why in (("product", "some_other_product", "BINDING MISMATCH"),
                                  ("profile_mode", "sample", "REFUSED"),
                                  ("source_mode", "synthetic", "REFUSED"),
                                  ("mapping_evidence_version", "1.0", "REFUSED"),
                                  ("tables", {}, "no tables")):
            wrong = dict(reviewed, **{field: value})
            evp.write_text(_json.dumps(wrong), encoding="utf-8")
            try:
                psm.proposal(pack, str(evp))
            except SystemExit as e:
                assert why in str(e), (field, e)
            else:
                raise AssertionError(f"evidence with wrong {field} was accepted")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_the_evidence_builder_refuses_what_the_profile_does_not_prove():
    """Fail-closed at BUILD time, before anything exists to hand a person: an anonymous profile
    (no embedded provenance), a partial profile, an unrecognised source mode, and a kind outside
    the profiler's vocabulary each refuse by name. The binding is read, never typed — there is no
    argument left to mistype."""
    import mapping_evidence as me
    tmp = tempfile.mkdtemp()
    try:
        anon = Path(tmp) / "anon.tsv"
        lines = ["table\ttable_base\tcolumn\tkind\tsampled\tn_rows\tn_rows_total\tpct_missing"
                 "\tdistinct\tdate_min\tdate_max\ttop_values",
                 "t_x_2026m06\tt_x\tpatientid\tcategorical\tFALSE\t9\t9\t0\t3\t\t\t"]
        anon.write_text("\n".join(lines) + "\n", encoding="utf-8")
        for path, expect in (
                (str(anon), "no embedded provenance"),
                (_tsv(Path(tmp) / "part.tsv", dict(BASE_TABLES), mode="new-columns-only"),
                 "partial profile"),
                (_tsv(Path(tmp) / "odd.tsv", dict(BASE_TABLES), source_mode="ftp"),
                 "not one of"),
        ):
            try:
                me.build(path)
            except SystemExit as e:
                assert expect in str(e), (path, e)
            else:
                raise AssertionError(f"{path} was accepted")
        # a kind outside the vocabulary
        weird = _tsv(Path(tmp) / "kind.tsv", dict(BASE_TABLES))
        text = Path(weird).read_text(encoding="utf-8").replace("\tcategorical\t", "\tblobby\t", 1)
        Path(weird).write_text(text, encoding="utf-8")
        try:
            me.build(weird)
        except SystemExit as e:
            assert "blobby" in str(e), e
        else:
            raise AssertionError("an unrecognised kind was accepted")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_a_dispositioned_gap_is_not_work():
    """A role excused as optional or unavailable_by_design must not appear as a gap — the
    disposition IS the answer, and re-raising it every run teaches people to skim the list."""
    tmp = tempfile.mkdtemp()
    try:
        cfg = CONFIG + ("source_availability:\n"
                        "  biomarkers: {state: unavailable_by_design, reason: r, decision_id: D-1}\n")
        # remove the grain declaration for the excused role — a grain about an absent source is
        # its own contradiction and not this test's subject
        cfg = cfg.replace("source_grain:\n  biomarkers: [patientid, biomarkername, biomarkerdate]\n", "")
        pack = _fixture(tmp, cfg)
        tsv = _tsv(Path(tmp) / "p.tsv", dict(BASE_TABLES))
        assert [g["role"] for g in psm.proposal(pack, tsv)["gaps"]] == [], \
            "an excused role was raised as mapping work"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
