# The R engine's STAGE DATAFLOW, executed — not parse-checked, not SQL-string-compared: run.
#
# Everything else about cross-engine parity stops short of the dataflow: the r-parity suite
# proves the COMPILED EXPRESSIONS byte-identical, and the CI R step proves the files parse.
# The joins, unions, group-bys and guards — the half where the vis120 NULL semantics and the
# per-source date columns actually live — were mirrored by convention and executed nowhere.
# An external review asked for an R stage fixture before claiming dataflow parity; this is it.
#
# Runs where sparklyr + a Spark home exist:
#   R_STAGE_LIB=<lib with sparklyr>  SPARK_HOME_PY=<pyspark dir>  Rscript tests/test_r_stage_dataflow.R
# Locally the lib is built from GitHub source (CRAN is proxy-blocked here); CI installs the
# posit binary. Without sparklyr it SKIPS loudly and exits 0 — and the runner that wants it as
# evidence must check for the "SKIP" marker, because a skip is not a pass.
suppressWarnings(suppressMessages({
  lib <- Sys.getenv("R_STAGE_LIB")
  if (nzchar(lib)) .libPaths(c(lib, .libPaths()))
  ok_sparklyr <- requireNamespace("sparklyr", quietly = TRUE)
}))
if (!ok_sparklyr) { cat("SKIP (sparklyr absent)\n"); quit(status = 0) }

library(sparklyr)
suppressMessages(library(dplyr))

here <- normalizePath(file.path(dirname(sub("--file=", "", grep("--file=", commandArgs(FALSE), value = TRUE))), ".."))
source(file.path(here, "engine-r", "config.R"))
source(file.path(here, "engine-r", "cases.R"))
source(file.path(here, "engine-r", "stages.R"))

spark_home <- Sys.getenv("SPARK_HOME_PY")
if (!nzchar(spark_home)) { cat("SKIP (SPARK_HOME_PY not set)\n"); quit(status = 0) }
# `version=` makes sparklyr consult its own installed-versions registry (spark_install_find)
# and its probes fail against a pip-installed Spark home; the SPARK_VERSION env var is the
# detection path that works, and the RELEASE marker in the home is its fallback. DERIVED from
# the installed pyspark rather than hardcoded: a fixture declaring
# 4.2.0 while CI installs 4.0.1 — a pinned lie in either direction.
spark_ver <- tryCatch(
  trimws(system2("python3", c("-c", "import pyspark; print(pyspark.__version__)"),
                 stdout = TRUE, stderr = FALSE)[1]),
  error = function(e) "")
if (!nzchar(spark_ver)) { cat("SKIP (pyspark version undetectable)\n"); quit(status = 0) }
Sys.setenv(SPARK_VERSION = spark_ver)
sc <- spark_connect(master = "local[1]", method = "shell", spark_home = spark_home,
                    config = list("sparklyr.shell.driver-memory" = "1g",
                                  "spark.sql.shuffle.partitions" = "1"))

bad <- 0
check <- function(name, expr) {
  r <- tryCatch(expr, error = function(e) e)
  if (isTRUE(r)) { cat("  ok ", name, "\n"); return(invisible()) }
  bad <<- bad + 1
  # r may be a plain FALSE, not a condition — conditionMessage(FALSE) would itself error and
  # abort the suite before later checks ran or the summary printed (an adversarial review
  # caught it): a reporter that crashes on the first failure reports nothing.
  msg <- if (inherits(r, "condition")) conditionMessage(r) else paste("returned", format(r))
  cat("FAIL ", name, ": ", msg, "\n")
}

base_end <- copy_to(sc, data.frame(patientid = "p1",
                                   index_date = as.Date("2020-01-01"),
                                   lot1ed = as.Date("2020-06-01")), "base_end", overwrite = TRUE)
early_visit <- copy_to(sc, data.frame(patientid = "p1", visitdate = as.Date("2020-02-01")),
                       "early_visit", overwrite = TRUE)
telemed <- copy_to(sc, data.frame(patientid = "p1", telemeddate = as.Date("2020-12-01")),
                   "telemed_t", overwrite = TRUE)

# 1. Unconfigured feed -> vis120 NULL (unknown), never 0 — the mCRC defect, in the R dataflow.
check("vis120 unconfigured is NULL", {
  r <- outcomes_vis120(list(), base_end, list(visit_sources = list()), 120, "lot1ed") %>% collect()
  is.na(r$vis120[[1]]) && is.na(r$lastvisitdate[[1]])
})

# 2. A configured source the build did not load REFUSES.
check("vis120 partial feed refuses", {
  r <- tryCatch({ outcomes_vis120(list(), base_end,
                                  list(visit_sources = list("visit")), 120, "lot1ed"); NULL },
                error = function(e) conditionMessage(e))
  !is.null(r) && grepl("not loaded", r)
})

# 3. PER-SOURCE date columns: only telemed (telemeddate) has the qualifying encounter; the
#    mapping-entry shape must read each feed's own column.
check("vis120 per-source date column", {
  lo <- list(visit_sources = list("visit",
                                  list(source = "telemed", date_column = "telemeddate")))
  r <- outcomes_vis120(list(visit = early_visit, telemed = telemed), base_end,
                       lo, 120, "lot1ed") %>% collect()
  r$vis120[[1]] == 1L && r$lastvisitdate[[1]] == as.Date("2020-12-01")
})

# 4. A mapping entry naming no source refuses (== outcomes.py::visit_source_pairs).
check("vis120 sourceless entry refuses", {
  r <- tryCatch({ outcomes_vis120(list(), base_end,
                                  list(visit_sources = list(list(date_column = "d"))),
                                  120, "lot1ed"); NULL },
                error = function(e) conditionMessage(e))
  !is.null(r) && grepl("must name `source`", r)
})

# 4b. A SCALAR visit_sources refuses in R too (Python iterates a scalar per character; both
#     engines now refuse the shape instead of answering differently).
check("vis120 scalar visit_sources refuses", {
  r <- tryCatch({ outcomes_vis120(list(), base_end,
                                  list(visit_sources = "visit"), 120, "lot1ed"); NULL },
                error = function(e) conditionMessage(e))
  !is.null(r) && grepl("must be a list", r)
})

# 5. The temporal accessors + study_tokens (pure, but on the sourced engine, chain == config.py).
check("temporal accessor default chain", {
  cfg <- list(raw = list(study = list(index_start = "2013-01-01", index_end = "2025-12-31")))
  cfg_observation_end(cfg) == "2025-12-31" && cfg_data_cutoff(cfg) == "2025-12-31" &&
    cfg_index_period_end(cfg) == "2025-12-31"
})
check("temporal accessor split fields", {
  cfg <- list(raw = list(study = list(index_start = "2013-01-01", index_end = "2025-12-31",
                                      observation_end = "2026-06-30")))
  cfg_observation_end(cfg) == "2026-06-30" && cfg_index_period_end(cfg) == "2025-12-31" &&
    grepl("date('2026-06-30')", study_tokens("{observation_end}", cfg), fixed = TRUE)
})

spark_disconnect(sc)
cat(if (bad == 0) "\nALL R STAGE DATAFLOW CHECKS PASSED\n" else sprintf("\n%d FAILED\n", bad))
quit(status = if (bad == 0) 0 else 1)
