"""The pilot-readiness report answers one question and may not flatter it.

Three properties, each with a way of quietly breaking:

  * IT GRANTS NOTHING. It cannot approve, register or mark anything ready, and it writes nothing.
    A report that could write is a report that can be pointed at its own conclusion.
  * IT COMPOSES, IT DOES NOT RE-CHECK. Every fact comes from the tool that owns it. A private copy
    of "what an extraction consists of" or "which keys are supplied per run" is a second answer to
    one question, and the two drift in the direction that makes the report look better.
  * UNKNOWN IS NOT A PASS. What it cannot see must say so. The smoke evidence is written outside
    the checkout on purpose; reporting it as `ok` or `NO` would both be claims about something
    unobserved.

Run: python3 platform/tests/test_pilot_readiness.py  (or pytest).
"""
import ast
import os
import shutil
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
TOOLS = FRAMEWORK / "tools"
REPO = FRAMEWORK.parent
sys.path.insert(0, str(TOOLS))

import pilot_readiness as pr      # noqa: E402
import run_spec_pipeline          # noqa: E402
import placeholders               # noqa: E402


def test_it_writes_nothing():
    """A readiness report that can write is one that can be pointed at its own conclusion.

    AST, not a text search: a grep for `open(` is defeated by the word appearing in a docstring,
    and this codebase has now written that guard seven times and had it defeated once.
    """
    tree = ast.parse((TOOLS / "pilot_readiness.py").read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = getattr(node.func, "id", "") or getattr(node.func, "attr", "")
        assert name not in ("safe_dump", "dump", "mkdir", "makedirs", "write_text", "writelines",
                            "remove", "rename", "rmtree", "copy", "copytree"), \
            f"{name}() in a report whose whole claim is that it writes nothing"
        if name == "open":
            mode = ""
            if len(node.args) > 1 and isinstance(node.args[1], ast.Constant):
                mode = str(node.args[1].value)
            for kw in node.keywords:
                if kw.arg == "mode" and isinstance(kw.value, ast.Constant):
                    mode = str(kw.value.value)
            assert not (set(mode) & set("wax+")), f"open(mode={mode!r}) writes"


def test_it_grants_nothing():
    """No approval vocabulary. A report that can print `approved` beside a pack is one somebody
    will eventually screenshot as evidence that it was."""
    src = (TOOLS / "pilot_readiness.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    banned = ("approved", "human_confirmed", "passed_live", "verified", "accepted")
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            low = node.value.lower()
            for word in banned:
                # `approved inputs` is Gate 1's NAME, read from status.py, and "not approved" is a
                # refusal. What may not appear is this file ASSERTING one of these states.
                assert not low.strip().startswith(f"{word} ") or "not " in low, \
                    f"pilot_readiness asserts {word!r}: {node.value[:70]}"


def test_the_extraction_definition_comes_from_the_pipeline():
    """What an extraction CONSISTS OF is `run_spec_pipeline`'s to say. A private list here would
    let the report call a pack extracted while the pipeline disagreed."""
    assert pr.ARTIFACTS is run_spec_pipeline.ARTIFACTS
    assert len(pr.ARTIFACTS) == 7, pr.ARTIFACTS


def test_the_runtime_binding_names_come_from_placeholders():
    """One definition of which keys are supplied per run — the collapse that removed two dead
    copies of this exact tuple is recent enough to be worth holding in place."""
    assert pr.RUNTIME_BINDINGS is placeholders.RUNTIME_BINDINGS


def test_a_placeholder_location_is_not_a_location():
    """THE FALSE PASS THIS SHIPPED WITH. The first version compared `path_or_link == "TBD"`, and
    prostate registers `TBD — the approved 202606 Panoramic program-specification workbook (Excel):
    …`. A placeholder with an explanation after it read as a real location, and the explanation is
    exactly what made it convincing."""
    rows = pr._registration("products/oncology/prostate/202606")
    locs = {subj.strip(): (state, detail) for state, subj, detail in rows
            if subj.strip().endswith("location")}
    assert locs, "no location rows — this test has lost its subject"
    state, detail = locs["program_spec location"]
    assert state == pr.NO, f"a TBD-with-prose location reported as {state}: {detail}"
    assert "placeholder" in detail
    # ...and a real path still passes, or the check would just be refusing everything.
    assert locs["sanitized_extraction location"][0] == pr.OK, locs["sanitized_extraction location"]


def test_a_registered_file_that_is_not_there_is_refused():
    """A registration naming a local path that does not exist is worse than one naming nothing:
    it looks bound to bytes."""
    import yaml
    d = Path(tempfile.mkdtemp())
    try:
        pack = d / "products" / "oncology" / "x" / "202601"
        pack.mkdir(parents=True)
        (pack / "source_refs.yaml").write_text(yaml.safe_dump({"source_materials": [
            {"material_id": "m", "path_or_link": "products/oncology/x/202601/prog_spec/gone.xlsx",
             "sha256": "a" * 64, "status": "reviewed"}]}), encoding="utf-8")
        saved, pr.REPO = pr.REPO, str(d)
        try:
            rows = pr._registration("products/oncology/x/202601")
        finally:
            pr.REPO = saved
        loc = [(s, det) for s, subj, det in rows if subj.strip() == "m location"]
        assert loc and loc[0][0] == pr.NO, rows
        assert "does not exist" in loc[0][1]
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_a_directory_holding_scaffolding_is_not_an_extraction():
    """`spec_pipeline/out/` also holds `variables_scaffold/`, which is generated from the master
    inventory and needs no workbook at all. A report that checked for the DIRECTORY would tell a
    reader that a pack with no approved specification had been extracted."""
    d = Path(tempfile.mkdtemp())
    try:
        pack = d / "products" / "oncology" / "x" / "202601"
        (pack / "spec_pipeline" / "out" / "variables_scaffold").mkdir(parents=True)
        (pack / "spec_pipeline" / "out" / "variables_scaffold" / "clinical.yaml").write_text(
            "variables: []\n", encoding="utf-8")
        saved, pr.REPO = pr.REPO, str(d)
        try:
            rows = pr._extraction("products/oncology/x/202601")
        finally:
            pr.REPO = saved
        assert rows[0][0] == pr.NO, rows
        assert "not an extraction" in rows[0][2], rows[0][2]
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_a_partial_extraction_is_refused_and_names_what_is_missing():
    """Six of seven artifacts is not a traceable specification, and a reader must be told WHICH
    one is absent — "extraction incomplete" sends somebody looking through all seven."""
    d = Path(tempfile.mkdtemp())
    try:
        out = d / "products" / "oncology" / "x" / "202601" / "spec_pipeline" / "out"
        out.mkdir(parents=True)
        for a in run_spec_pipeline.ARTIFACTS[:-1]:
            (out / a).write_text("{}", encoding="utf-8")
        saved, pr.REPO = pr.REPO, str(d)
        try:
            rows = pr._extraction("products/oncology/x/202601")
        finally:
            pr.REPO = saved
        assert rows[0][0] == pr.NO
        assert run_spec_pipeline.ARTIFACTS[-1] in rows[0][2], rows[0][2]
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_what_cannot_be_seen_is_reported_as_unknown_not_as_a_pass():
    """The smoke evidence is written outside the checkout BY DESIGN, so this report cannot see it.
    `ok` would be a claim about something unobserved; `NO` would be a false negative on every
    machine that has run it. The third answer is what keeps the other two meaning anything."""
    rows = pr._smoke("products/oncology/mcrc/202606")
    assert rows and rows[0][0] == pr.UNKNOWN, rows
    assert "outside" in rows[0][2].lower()

    rendered = pr.render("products/oncology/mcrc/202606")
    assert "CANNOT see" in rendered, "unknowns are not separated from blockers in the summary"
    assert "They are not passes" in rendered


def test_the_summary_never_reports_ready_while_anything_blocks():
    """mCRC blocks on registration, extraction and bindings today. If this ever prints an
    unqualified all-clear for that pack, the report has started answering a different question."""
    rendered = pr.render("products/oncology/mcrc/202606")
    assert "blocking condition(s)" in rendered
    assert "No blocking condition" not in rendered, \
        "mCRC reported clear while unregistered — the report is not reading the pack"
    # And the hard stop is unconditional: it prints whatever the lines above say.
    assert "MUST NOT BE RUN" in rendered and "publish or" in rendered


def test_gate_state_and_blockers_come_from_status_verbatim():
    """Re-wording a blocker is how two tools come to describe one condition differently, and the
    friendlier wording is the one that gets quoted."""
    import status as status_tool
    pack = "products/oncology/mcrc/202606"
    owned = {b for r in status_tool.results(str(REPO), pack) for b in (r.get("blockers") or [])}
    shown = " ".join(d for s, _subj, d in pr._gates(pack))
    assert owned, "status reports no blockers for mCRC — this test would be vacuous"
    for b in owned:
        assert b in shown, f"blocker re-worded rather than quoted: {b}"


if __name__ == "__main__":
    os.chdir(FRAMEWORK)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
