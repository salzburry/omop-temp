"""The source-requirement matrix must stay DERIVED, and must refuse the silent-null shape.

`platform/tools/source_requirements.py` answers "which variables die if this table is missing" by
chaining requirement -> contract record -> config block -> logical role -> physical stem -> required
columns. Every link is read from the artifact that owns it, so the two properties worth tests here:

  * the chain is REAL on a live pack — a matrix that renders headers over empty rows would pass a
    smoke test and answer nothing;
  * a role a governed block READS but the pack never DECLARES is a finding and a non-zero exit.
    That is the HER2 shape from a live mCRC trial: the spec required it, the engine supported it,
    the source never carried it, and the result would have quietly become null. Static config can
    catch the config half of that — a read-but-undeclared role — before any build runs.

Run: python3 tests/test_source_requirements.py (or pytest).
"""
import json
import shutil
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))

import source_requirements as sr   # noqa: E402

PROSTATE = str(REPO / "products" / "oncology" / "prostate" / "202606")
MCRC = str(REPO / "products" / "oncology" / "mcrc" / "202606")

FIXTURE_CONFIG = """\
data_product_id: undecl_fixture
name: "undeclared-role fixture"
owner: RWP
version: "1"
vendor: flatiron
tumor_class: solid
run: {refresh: "R", source_schema: "S", output_schema: "O", output_table: t, write_mode: overwrite}
lot: {line_number: linenumber}
study: {index_start: "2013-01-01", index_end: "2025-12-31"}
index:
  advanced_diagnosis_date: {source: enhanced, of: [diagnosisdate]}
cohorts:
  - {cohortn: 1, cohort: "C1", index: advanced_diagnosis_date}
sources:
  enhanced: t_enh_x
  lot: t_lot_x
variables:
  - variables/clinical.yaml
"""

FIXTURE_VARIABLES = """\
biomarkers:
  source: biomarkers
  name_column: biomarkername
  panels:
    - {flag: her2, names: [HER2, ERBB2]}
"""


def _fixture(tmp, variables=FIXTURE_VARIABLES):
    pack = Path(tmp) / "pack"
    (pack / "config").mkdir(parents=True)
    (pack / "variables").mkdir()
    (pack / "config" / "data_product.yaml").write_text(FIXTURE_CONFIG, encoding="utf-8")
    (pack / "variables" / "clinical.yaml").write_text(variables, encoding="utf-8")
    return str(pack)


def test_the_chain_is_real_on_the_worked_example():
    """Requirement -> block -> role -> stem -> columns, asserted on prostate's own artifacts.

    Concrete values, not shapes: the biomarkers role must carry the HRR/BRCA variables its config
    block is claimed by, and the columns the engine's own derivation names. If this goes stale it
    is because one of the OWNING artifacts changed, which is exactly when a derived matrix must
    follow rather than freeze.
    """
    rows, findings, has_contract = sr.matrix(PROSTATE)
    assert has_contract, "prostate lost its functional contract — the chain cannot be exercised"
    assert not findings, f"the worked example has findings: {findings}"
    by_role = {r["role"]: r for r in rows}

    bio = by_role["biomarkers"]
    assert bio["declared"] and bio["physical_stem"], bio
    assert "patientid" in bio["required_columns"], bio["required_columns"]
    assert any("biomarkers" in ref for ref in bio["read_by_blocks"]), bio["read_by_blocks"]
    assert {"BRCA_INDEX", "HRR_INDEX"} <= set(bio["required_by_variables"]), \
        bio["required_by_variables"]
    assert bio["source_mapping_statuses"], "records claim the block but no mapping status surfaced"

    # every DECLARED role appears — a matrix that drops silent rows hides dead config
    import contract_binding  # noqa: F401  (import proves the tool's own deps resolve from tests/)
    from engine.config import load_config
    cfg = load_config(str(Path(PROSTATE) / "config" / "data_product.yaml"))
    assert set(cfg.sources) <= set(by_role), sorted(set(cfg.sources) - set(by_role))


def test_no_contract_reads_as_unwritten_never_as_unneeded():
    """mCRC has config and no contract. `required_by` empty + `has_contract` False must arrive
    TOGETHER: the first without the second is indistinguishable from "no variable needs this",
    which is the absence-reads-as-clean shape, requirement-side."""
    rows, findings, has_contract = sr.matrix(MCRC)
    assert not has_contract
    assert rows, "mCRC declares 14 sources; an empty matrix answered nothing"
    assert all(not r["required_by_variables"] for r in rows)
    text = sr.render(MCRC, rows, findings, has_contract)
    assert "NO handoff/FUNCTIONAL_CONTRACT.md" in text
    assert "NOT because no variable needs these" in text


def test_a_read_but_undeclared_role_is_a_finding_and_a_refusal():
    """The static half of the HER2 shape. A block reads `source: biomarkers`; the pack declares no
    such role; sources.load could never supply it and the dependent output quietly skips. Both
    directions: the defect refuses, and the repaired pack passes — a check that only ever fires is
    as dead as one that never does."""
    tmp = tempfile.mkdtemp()
    try:
        pack = _fixture(tmp)
        rows, findings, _ = sr.matrix(pack)
        assert any("biomarkers" in f and "BLOCKED" in f and "source decision required" in f
                   for f in findings), findings
        # engine-guarded optional roles (visit, baseline_ecog, ...) now appear as rows too — the
        # compiled source contract surfaces them so absence is visible — but the BLOCKED class is
        # only the READ-but-undeclared REQUIRED role
        undeclared = [r for r in rows
                      if not r["declared"] and r["availability"].startswith("required")]
        assert [r["role"] for r in undeclared] == ["biomarkers"], undeclared
        assert undeclared[0]["availability"] == "required (default)", undeclared[0]
        assert sr.main([pack, "--check"]) == 1

        # repaired: declare the role -> clean
        cfgp = Path(pack) / "config" / "data_product.yaml"
        cfgp.write_text(cfgp.read_text(encoding="utf-8").replace(
            "  lot: t_lot_x", "  lot: t_lot_x\n  biomarkers: t_bio_x"), encoding="utf-8")
        rows2, findings2, _ = sr.matrix(pack)
        assert not findings2, findings2
        assert next(r for r in rows2 if r["role"] == "biomarkers")["declared"]
        assert sr.main([pack, "--check"]) == 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_json_output_is_loadable_and_carries_the_same_findings():
    """The machine format is how preflight/profiling tools will consume this; it must not be a
    second computation. Captured via main() so the CLI path is the thing proved."""
    import contextlib
    import io
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = sr.main([PROSTATE, "--format", "json"])
    assert rc == 0
    doc = json.loads(buf.getvalue())
    assert doc["has_contract"] is True and doc["rows"] and doc["findings"] == []
    assert {"role", "declared", "physical_stem", "required_columns",
            "required_by_variables"} <= set(doc["rows"][0])


def test_grain_reads_from_the_packs_own_declaration_and_never_guesses():
    """The owner this column waited for exists now: the pack's `source_grain:` block, validated by
    `engine.validate.source_grain` and checked against delivered rows by
    `engine.grain.source_grain_report`. Three properties:

      * a role WITHOUT a declaration stays visibly `(not declared)` — prostate declares none today,
        so its whole matrix says so;
      * a declared role renders the declared key, verbatim;
      * a declaration for a role the config does not know is a shape error, not a silent drop —
        the same rule availability declarations follow.
    """
    rows, _, _ = sr.matrix(PROSTATE)
    assert all(r["expected_grain"] == "(not declared)" for r in rows), \
        "prostate declares no source_grain yet; a value here means this tool started guessing"

    tmp = tempfile.mkdtemp()
    try:
        pack = _fixture(tmp)
        cfgp = Path(pack) / "config" / "data_product.yaml"
        base = cfgp.read_text(encoding="utf-8")
        cfgp.write_text(base + "source_grain:\n  lot: [patientid, linenumber]\n", encoding="utf-8")
        rows, findings, _ = sr.matrix(pack)
        lot = next(r for r in rows if r["role"] == "lot")
        assert lot["expected_grain"] == "unique by (patientid, linenumber)", lot
        # a declaration about a role the config does not know is refused, not dropped
        cfgp.write_text(base + "source_grain:\n  nosuch: [patientid]\n", encoding="utf-8")
        from engine.config import load_config
        from engine import validate as ev
        _, errs = ev.source_grain(load_config(str(cfgp)))
        assert any("nosuch" in e and "about nothing" in e for e in errs), errs
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_the_three_availability_states_change_the_verdict_not_the_visibility():
    """`required` blocks; `optional` and `unavailable_by_design` excuse — but every state stays a
    VISIBLE row. The one thing no state may do is make the role disappear: an excused absence and a
    role nobody ever thought about must never render identically.

    Also the disposition floor: `unavailable_by_design` without a reason and decision_id is refused
    as malformed — a shrug wearing a disposition's name — and a disposition for a role that IS
    declared is a stale-disposition finding, because it tells an auditor an absence was accepted
    while the table quietly ships.
    """
    tmp = tempfile.mkdtemp()
    try:
        pack = _fixture(tmp)
        cfgp = Path(pack) / "config" / "data_product.yaml"
        base = cfgp.read_text(encoding="utf-8")

        # optional -> no finding, visible row saying so
        cfgp.write_text(base + "source_availability:\n  biomarkers: optional\n", encoding="utf-8")
        rows, findings, _ = sr.matrix(pack)
        assert not findings, findings
        row = next(r for r in rows if r["role"] == "biomarkers")
        assert row["availability"] == "optional" and not row["declared"], row
        assert sr.main([pack, "--check"]) == 0

        # unavailable_by_design WITH the trail -> no finding, and the trail renders
        cfgp.write_text(base + (
            "source_availability:\n"
            "  biomarkers:\n"
            "    state: unavailable_by_design\n"
            "    reason: \"delivery carries no HER2/ERBB2 biomarker rows\"\n"
            "    decision_id: FIX-HER2-01\n"), encoding="utf-8")
        rows, findings, _ = sr.matrix(pack)
        assert not findings, findings
        row = next(r for r in rows if r["role"] == "biomarkers")
        assert row["availability_decision"] == "FIX-HER2-01", row
        text = sr.render(pack, rows, findings, False)
        assert "FIX-HER2-01" in text and "unavailable_by_design" in text

        # ...WITHOUT the trail -> refused as malformed, not defaulted
        cfgp.write_text(base + "source_availability:\n  biomarkers: unavailable_by_design\n",
                        encoding="utf-8")
        _, findings, _ = sr.matrix(pack)
        assert any("needs both a reason and a decision_id" in f for f in findings), findings

        # a disposition over a DECLARED role -> stale-disposition finding
        cfgp.write_text(base.replace("  lot: t_lot_x", "  lot: t_lot_x\n  biomarkers: t_bio_x") + (
            "source_availability:\n"
            "  biomarkers: {state: unavailable_by_design, reason: r, decision_id: D-1}\n"),
            encoding="utf-8")
        _, findings, _ = sr.matrix(pack)
        assert any("stale disposition" in f for f in findings), findings
    finally:
        shutil.rmtree(tmp, ignore_errors=True)



def test_strict_build_validation_blocks_what_the_matrix_blocks():
    """The engine's `problems(strict=True)` and this tool's findings are ONE implementation with two
    callers — asserted by object identity, then by behaviour: a strict build must refuse the same
    HER2 shape the matrix refuses, and lint mode must keep accepting it (discovery is allowed to
    look at a broken pack; a build is not)."""
    from engine import validate as ev
    from engine.config import load_config
    assert sr.ev.availability_problems is ev.availability_problems

    tmp = tempfile.mkdtemp()
    try:
        pack = _fixture(tmp)
        cfg = load_config(str(Path(pack) / "config" / "data_product.yaml"))
        strict = [p for p in ev.problems(cfg, strict=True) if "source decision required" in p]
        assert strict, "a strict build accepted a read-but-undeclared required role"
        lint = [p for p in ev.problems(cfg, strict=False) if "source decision required" in p]
        assert not lint, f"lint mode must not block discovery over availability: {lint}"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    import os
    os.chdir(FRAMEWORK)
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
