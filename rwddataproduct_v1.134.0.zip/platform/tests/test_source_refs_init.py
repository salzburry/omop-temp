"""The Gate 1 registration is composed by a tool and SIGNED by a person — this pins the split.

`platform/tools/source_refs_init.py` exists because everything in a new pack's source_refs.yaml is
derivable except three fields, and those three are the whole point of the file: what AI may read,
who decided that, and when. The tool must therefore be USELESS without a person: no defaults, no
inference, and a refusal for every shape that is demonstrably not a considered human answer.

The failure mode is one-directional and worth naming. A tool that quietly defaulted
`ai_classification`, or accepted `classified_by: RWP`, would produce a file that satisfies the
schema, passes CI, and reads exactly like a considered classification — while nobody has made one.
That is strictly worse than no file at all, because the absence is visible and the forgery is not.

Run: python3 tests/test_source_refs_init.py (or pytest).
"""
import json
import shutil
import sys
import tempfile
from pathlib import Path

import yaml

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))

import source_manifest as sm       # noqa: E402
import source_refs_init as srf     # noqa: E402

PACK = "products/oncology/testis/202608"
# The repo's own fixture person. NEVER a real name, and never written into a real pack.
WHO = "T. Test"
WHEN = "2026-08-14"


def _sandbox():
    """A throwaway root carrying one registry entry and one empty pack."""
    root = Path(tempfile.mkdtemp())
    (root / PACK / "config").mkdir(parents=True)
    (root / PACK / "config" / "data_product.yaml").write_text("data_product_id: t\n",
                                                              encoding="utf-8")
    (root / "products").mkdir(exist_ok=True)
    (root / "products" / "registry.yaml").write_text(
        yaml.safe_dump({"tumors": [{"code": "testis", "name": "Testis", "slug": "testis",
                                    "vendor": "flatiron", "tumor_class": "solid",
                                    "status": "scaffold"}]}), encoding="utf-8")
    return root


def _run(root, *argv):
    old = srf.REPO
    srf.REPO = str(root)
    try:
        return srf.main(list(argv))
    finally:
        srf.REPO = old


def test_none_of_the_three_human_fields_has_a_default():
    """If any of these could be omitted, the tool would supply the judgement it exists to carry.

    Read off the source rather than off a parsed namespace: argparse would happily report
    `default=None`, and None reaching the file as an empty classification is the same forgery in a
    quieter form. The declaration is what this asserts about."""
    src = (FRAMEWORK / "tools" / "source_refs_init.py").read_text(encoding="utf-8")
    for flag in ("--ai-classification", "--classified-by", "--classified-date"):
        i = src.index(f'"{flag}"')
        block = src[i:src.index("help=", i)]
        assert "required=True" in block, f"{flag} is not required — the tool could sign for a person"
        assert "default=" not in block, f"{flag} has a default — that default IS the forged judgement"


def test_it_refuses_every_shape_that_is_not_a_considered_answer():
    """The schema would accept all of these as strings. This is the layer that does not."""
    assert srf.human_errors("vendor_restricted", WHO, WHEN) == []
    for who in ("RWP", "GSK", "TEAM", "TBD", "REPLACE_ME", "", "   "):
        bad = srf.human_errors("vendor_restricted", who, WHEN)
        assert bad and any("classified-by" in e for e in bad), (who, bad)
    for when in ("2026-13-45", "14/08/2026", "August 2026", "2026-8-1", ""):
        bad = srf.human_errors("vendor_restricted", WHO, when)
        assert bad and any("classified-date" in e for e in bad), (when, bad)
    bad = srf.human_errors("probably_fine", WHO, WHEN)
    assert bad and any("ai-classification" in e for e in bad), bad
    # every declared class is accepted — the enum is read off source_manifest, not restated
    for cls in sm.AI_CLASSES:
        assert srf.human_errors(cls, WHO, WHEN) == []


def test_the_written_file_is_schema_valid_and_reads_back_as_one_pending_material():
    root = _sandbox()
    try:
        rc = _run(root, PACK, "--ai-classification", "vendor_restricted",
                  "--classified-by", WHO, "--classified-date", WHEN)
        assert rc == 0
        written = (root / PACK / "source_refs.yaml")
        assert written.exists()
        doc = yaml.safe_load(written.read_text(encoding="utf-8"))

        import jsonschema
        schema = json.loads((REPO / "governance" / "schemas" / "source_refs.schema.json")
                            .read_text(encoding="utf-8"))
        jsonschema.validate(doc, schema)

        mats = sm.materials(str(root / PACK))
        assert len(mats) == 1, mats
        m = mats[0]
        assert m["material_type"] == sm.PROGRAM_SPEC
        assert m["status"] == "pending", "a generated registration must never claim review"
        assert m["ai_classification"] == "vendor_restricted"
        assert m["classified_by"] == WHO and str(m["classified_date"]) == WHEN
        assert str(m.get("why_provisional") or "").strip(), "pending without a reason"
        # the identity comes from the registry and the path, not from an argument
        assert doc["product"] == "testis" and doc["spec_version"] == "202608"
        # and NOTHING that would read as an approval was written
        for field in sm.APPROVAL_FIELDS:
            assert field not in m, f"{field} was written into a pending registration"
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_windows_path_survives_being_written_into_the_registration():
    """THE REGISTRATION NAMED A DIFFERENT FILE, AND NOTHING SAID SO.

    Every value used to be interpolated inside literal double quotes, and a double-quoted YAML
    scalar processes backslash escapes. A Windows path is nothing but backslashes:

        path_or_link: "C:\\temp\\new\\PANO.xlsx"

    reads back as `C:<TAB>emp<NEWLINE>ew<U+2029>ANO.xlsx`. Silently — the document is well-formed,
    the schema validates, `--check` is happy, and the registration points at a file that cannot even
    be typed. `C:\\specs\\...` was the lucky case: `\\s` is not a valid escape, so it failed to parse
    and at least said so. Both are asserted, because a fix for the loud one is not a fix.

    The last two are not paths. They are the other values hand-quoting would break: a name holding
    the YAML key separator, and a version that must stay a string rather than become an integer.
    """
    root = _sandbox()
    try:
        for value in (r"C:\temp\new\PANO.xlsx", r"C:\specs\PANO.xlsx",
                      r"\\share\rwb\PANO 202606 (final).xlsx",
                      "https://example.invalid/a?b=1&c=2#frag"):
            doc = srf.document(PACK, "vendor_restricted", WHO, WHEN, value, root=str(root))
            back = yaml.safe_load(srf.render(doc))
            got = back["source_materials"][0]["path_or_link"]
            assert got == value, f"registered {value!r} and read back {got!r}"

        # ...and the non-path values that hand-quoting breaks the same way.
        doc = srf.document(PACK, "vendor_restricted", "O'Brien, A.", WHEN, "TBD", root=str(root))
        back = yaml.safe_load(srf.render(doc))
        assert back["source_materials"][0]["classified_by"] == "O'Brien, A."
        assert back["spec_version"] == "202608", \
            f"spec_version came back as {back['spec_version']!r} — it must stay a string"
    finally:
        shutil.rmtree(root, ignore_errors=True)

    # A newline is refused rather than folded into a valid-looking multi-line scalar.
    try:
        srf.scalar("a\nb")
    except SystemExit:
        pass
    else:
        raise AssertionError("a value containing a newline was serialized instead of refused")


def test_the_pending_reason_says_which_thing_is_missing():
    """One sentence for two different states told half the callers something false about their pack.

    `why_provisional` said "The workbook has not been supplied to this pack" — correct while
    `--path-or-link` is the `TBD` default, and flatly contradicted by the `path_or_link` three lines
    above it on the day somebody registered a real document. What is provisional in that case is the
    APPROVAL, not the existence of the document.

    A path this machine cannot open still counts as supplied: the workbook routinely sits on a share
    the checkout cannot see, and calling that "not supplied" would print the wrong sentence for the
    commonest real registration there is.
    """
    root = _sandbox()
    try:
        supplied = srf.document(PACK, "vendor_restricted", WHO, WHEN,
                                r"\\rwb-share\specs\PANO.xlsx", root=str(root))
        why = supplied["source_materials"][0]["why_provisional"]
        assert "has not been supplied" not in why, \
            f"a registration naming a document still says the document was not supplied: {why!r}"
        assert "registered at the path above" in why, why

        for placeholder in ("TBD", "TBD — workbook not yet supplied", "todo", "REPLACE_ME", ""):
            pending = srf.document(PACK, "vendor_restricted", WHO, WHEN, placeholder,
                                   root=str(root))
            assert "has not been supplied" in pending["source_materials"][0]["why_provisional"], \
                f"{placeholder!r} is not a document, and the reason must say so"
    finally:
        shutil.rmtree(root, ignore_errors=True)

    # Neither sentence may read as an approval — asserted as the POSITIVE property, that each opens
    # by stating the pack is not approved. A substring hunt for "approved" was the first version and
    # it fired on "nothing attests that it is the document RWB approved", which is that sentence
    # doing its job. A check that cannot tell a reference from a claim is one people learn to skip.
    for doc in (supplied, pending):
        assert doc["source_materials"][0]["why_provisional"].startswith("Not yet approved:"), \
            doc["source_materials"][0]["why_provisional"]


def test_it_will_not_overwrite_an_existing_registration():
    """That file can carry an approval. Regenerating it is how a signature is lost."""
    root = _sandbox()
    try:
        assert _run(root, PACK, "--ai-classification", "sponsor_ai_eligible",
                    "--classified-by", WHO, "--classified-date", WHEN) == 0
        before = (root / PACK / "source_refs.yaml").read_text(encoding="utf-8")
        rc = _run(root, PACK, "--ai-classification", "restricted_derived",
                  "--classified-by", WHO, "--classified-date", WHEN)
        assert rc == 1, "a second run replaced a registration record"
        assert (root / PACK / "source_refs.yaml").read_text(encoding="utf-8") == before
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_placeholder_version_directory_is_refused():
    """A registration answers "which cut does this govern" first. A pack still at the literal
    YYYYMM placeholder has no answer, and the schema's spec_version pattern says so — this turns
    that into a refusal naming the fix instead of a raw validator message.

    It is also why the six packs added without a workbook carry no registration: nobody knows yet
    which spec version they will be."""
    root = _sandbox()
    try:
        (root / "products" / "oncology" / "testis" / "YYYYMM").mkdir(parents=True)
        rc = _run(root, "products/oncology/testis/YYYYMM", "--ai-classification", "vendor_restricted",
                  "--classified-by", WHO, "--classified-date", WHEN)
        assert rc == 1, "a placeholder version directory was registered"
        assert not (root / "products" / "oncology" / "testis" / "YYYYMM" / "source_refs.yaml").exists()
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_an_unregistered_tumour_is_refused_rather_than_invented():
    root = _sandbox()
    try:
        (root / "products" / "oncology" / "ghost" / "202608").mkdir(parents=True)
        try:
            _run(root, "products/oncology/ghost/202608", "--ai-classification", "vendor_restricted",
                 "--classified-by", WHO, "--classified-date", WHEN)
            raise AssertionError("a pack with no registry entry was registered anyway")
        except SystemExit as e:
            assert "registry" in str(e)
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_the_live_packs_are_not_registered_by_a_machine():
    """THE POINT OF ALL OF THE ABOVE. No pack in this repository may carry a source_refs.yaml that
    a generator signed, so the six packs added without an approved workbook carry none at all — and
    every source_refs.yaml that DOES exist names a person this tool would accept."""
    for path in sorted((REPO / "products").rglob("source_refs.yaml")):
        for m in yaml.safe_load(path.read_text(encoding="utf-8")).get("source_materials") or []:
            who = m.get("classified_by")
            assert srf.human_errors(m.get("ai_classification"), who,
                                    str(m.get("classified_date"))) == [], \
                f"{path}: {m.get('material_id')} carries a classification the tool would refuse"
            assert who != WHO, f"{path}: the TEST fixture name reached a real pack"


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
