"""The naming registry may flag and ask; it may never rule.

Specifications are written by different people, and two of them will name one concept two ways
(`agegrp` vs `age_group`). The registry compiles what everything is called, the grammar knows
which nearby names are the CONVENTION working (label/code, date, year, banded, per-setting
twins), and everything else is a QUESTION a human answers in governance/NAMING_RULINGS.yaml.
The properties worth pinning are the refusal rules and the grammar's both-directions behaviour —
a detector that flags the twin families would teach people to ignore it, and one that ruled on
its own findings would be the approval hole this repo exists to close.

Run: python3 tests/test_naming_registry.py (or pytest). Pure — no Spark.
"""
import json
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))
sys.path.insert(0, str(FRAMEWORK / "engine"))

import naming_registry as nr   # noqa: E402


def test_the_twin_grammar_knows_the_convention_and_the_drift():
    """Both directions, on the shapes that matter: conventional twins never flag; the known
    drift shapes always do; a shared family prefix or per-setting suffix cannot manufacture
    closeness between genuinely different concepts."""
    for a, b in (("agegrl", "agegrln"), ("bone_met", "bone_metdt"), ("mhspcdd", "mhspcddyr"),
                 ("lotn", "lotngr1"), ("lotngr1", "lotngr1n"), ("mcrpc", "mcrpctype"),
                 ("dthdt", "dthfl")):
        assert not nr._near(a, b), f"convention twin flagged: {a} ~ {b}"
    for a, b in (("agegr1", "agegrl"),        # digit one vs letter el — live in prostate today
                 ("region1", "regionl"),
                 ("agegrp", "age_grp"),        # normalized-equal, spelled twice
                 ("index_date", "indexdt")):
        assert nr._near(a, b), f"drift not flagged: {a} ~ {b}"
    for a, b in (("prior_abiraterone", "prior_arpi"),      # shared family prefix, distinct drugs
                 ("lot1sd_mcrpc", "lot1sd_mhspc"),          # per-setting variants
                 ("agegrl", "agegrl")):                     # identity
        assert not nr._near(a, b), f"false flag: {a} ~ {b}"


def test_a_ruling_is_a_named_persons_dated_act_or_it_does_not_count():
    """The refusal rules on the rulings file: a team name, a missing date, an unknown ruling
    word, and a pair-less entry each surface as a PROBLEM — never silently not-counting — and a
    proper fixture ruling is accepted."""
    with tempfile.TemporaryDirectory() as tmp:
        p = Path(tmp) / "NAMING_RULINGS.yaml"
        p.write_text(json.dumps({"rulings": [
            {"a": "x", "b": "y", "ruling": "use_existing", "standard": "y",
             "ruled_by": "T. Test", "ruling_date": "2026-08-19"},
            {"a": "p", "b": "q", "ruling": "use_existing", "ruled_by": "RWP",
             "ruling_date": "2026-08-19"},
            {"a": "p2", "b": "q2", "ruling": "use_existing", "ruled_by": "T. Test",
             "ruling_date": "TBD"},
            {"a": "p3", "b": "q3", "ruling": "sounds_fine", "ruled_by": "T. Test",
             "ruling_date": "2026-08-19"},
            {"ruling": "use_existing"},
        ]}), encoding="utf-8")
        good, problems = nr.rulings(str(p))
        assert [r["a"] for r in good] == ["x"], good
        assert len(problems) == 4, problems
        assert any("team" in pr for pr in problems), problems
        assert any("ruling_date" in pr for pr in problems), problems
        assert any("sounds_fine" in pr for pr in problems), problems
        assert any("naming both" in pr for pr in problems), problems


def test_a_ruling_covers_the_pairs_twin_families():
    """One question, one answer: a ruling on (cohort, cohortu) also settles (cohortn,
    cohortun) — the code-twin pair must not reappear as new work."""
    assert nr._strip_twin("cohortn") == "cohort" and nr._strip_twin("cohortun") == "cohortu"
    assert nr._strip_twin("lotngr1n") == "lotn" or nr._strip_twin("lotngr1n") == "lotngr1"


def test_a_name_declared_in_two_formats_is_the_same_failure_one_field_over():
    """Character in one spec, numeric in another, one name: the registry reports the conflict
    with both sides attributed, and a name whose declarations agree reports nothing. Fixture
    packs, because the live tree's baseline is clean and must stay provably so (the real-tree
    test below pins type_conflicts == [])."""
    with tempfile.TemporaryDirectory() as tmp:
        for pack, ty in (("aaa", "character"), ("bbb", "numeric")):
            d = Path(tmp) / "products" / "oncology" / pack / "202606"
            (d / "config").mkdir(parents=True)
            (d / "handoff").mkdir()
            (d / "config" / "data_product.yaml").write_text("name: x\n", encoding="utf-8")
            (d / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(f"""# fixture

```yaml
variable_id: AGEGRP
output: {{physical_name: agegrp, name_status: undecided, type: {ty}, role: published}}
```

```yaml
variable_id: STABLE
output: {{physical_name: stable_thing, name_status: undecided, type: character, role: published}}
```
""", encoding="utf-8")
        d = nr.docket(root=tmp)
        assert len(d["type_conflicts"]) == 1, d["type_conflicts"]
        c = d["type_conflicts"][0]
        assert c["name"] == "agegrp"
        assert set(c["types"]) == {"character", "numeric"}
        assert "?" in c["question"] and "Revise" in c["question"]


def test_the_real_tree_compiles_and_the_known_drift_is_seen():
    """The registry over the live packs: engine names present, the docket runs, no ruling
    problems, and the drift the first sweep found (prostate's region1 vs the engine's regionl)
    is either OPEN work or covered by a recorded ruling — never invisible. And no finding
    carries a verdict: every open pair is phrased as a question."""
    reg = nr.registry()
    assert any(v["engine"] for v in reg.values()), "the engine names fell out of the registry"
    assert "regionl" in reg and reg["regionl"]["engine"]
    d = nr.docket()
    assert d["ruling_problems"] == [], d["ruling_problems"]
    assert d["type_conflicts"] == [], \
        f"the live packs' declared formats diverged: {d['type_conflicts']}"
    pair = {"region1", "regionl"}
    seen_open = any({f["a"], f["b"]} == pair for f in d["open"])
    good, _ = nr.rulings()
    seen_ruled = any({str(r["a"]).lower(), str(r["b"]).lower()} == pair for r in good)
    assert seen_open or seen_ruled, "the known region1/regionl drift is invisible"
    for f in d["open"]:
        assert "?" in f["question"] and "record" in f["question"], f
        assert not any(w in json.dumps(f) for w in ("approved", "verified", "passed")), f


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
