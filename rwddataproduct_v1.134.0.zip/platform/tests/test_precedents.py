"""The precedent store must stay true, stay powerless, and store no answers.

`governance/precedents.yaml` is a reading list: questions more than one pack has had to argue out.
Three properties make it safe to trust, and each has a way of quietly breaking:

  * TRUE — every citation still resolves to a real decision in a real register. Rename a decision id
    and the store keeps printing a confident precedent that points at nothing.
  * POWERLESS — no gate reads it. The moment one does, an advisory file becomes a way to grant
    something, and "a human confirms" stops being true.
  * POINTERS ONLY — it holds no answers of its own. A copied answer is a second copy of a governed
    fact, agreeing on the day it is written and free to diverge forever after.

Run: python3 tests/test_precedents.py (or pytest).
"""
import ast
import contextlib as _ctx
import os
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
TOOLS = FRAMEWORK / "tools"
REPO = FRAMEWORK.parent
sys.path.insert(0, str(TOOLS))
sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))

import _packs             # noqa: E402
import contract_lint      # noqa: E402
import precedents         # noqa: E402
import product_gates      # noqa: E402

# Two real governed packs, used wherever a test builds a synthetic entry. Real ones because the
# citation-resolving tests need registers that exist; the grading tests stand them in front of
# `_fake_registers` and never read the real rows.
P1 = "products/oncology/prostate/202606"
P2 = "products/oncology/oc/202606"


def _entry(*sightings):
    return {"id": "x-y", "question": "q",
            "seen_in": [{"pack": p, "decision": d} for p, d in sightings]}


def test_every_citation_in_the_live_store_resolves():
    """The store as committed, against the registers as committed."""
    bad = precedents.errors(str(REPO))
    assert bad == [], "broken precedent citation(s):\n  " + "\n  ".join(bad)
    entries, _ = precedents.load(str(REPO))
    assert entries, "the store is empty — this test would prove nothing"


def test_a_precedent_needs_more_than_one_sighting_in_governed_packs():
    """One pack asking a question is a decision. A store that accepted one sighting would fill up
    with every question ever asked, and propose all of them to every new product.

    Counted in GOVERNED packs — `product_gates.products()`, the same definition every gate uses.
    Counted in raw sightings, the floor was met for seven entries by a test fixture.
    """
    assert precedents.MIN_SIGHTINGS >= 2
    entries, _ = precedents.load(str(REPO))
    governed = set(product_gates.products(str(REPO)))
    for e in entries:
        packs = {s["pack"] for s in e["seen_in"]}
        assert len(e["seen_in"]) >= precedents.MIN_SIGHTINGS, f"{e['id']}: too few sightings"
        assert packs <= governed, \
            f"{e['id']}: cites {sorted(packs - governed)}, which no gate considers a product pack"
        assert len(packs) >= precedents.MIN_SIGHTINGS, f"{e['id']}: too few governed packs"


def test_a_duplicated_sighting_cannot_satisfy_the_two_sighting_floor():
    """The floor means MORE THAN ONE PACK hit the question. One sighting written twice is one pack
    recorded twice, and it would read as corroboration in every rendering."""
    import tempfile
    import yaml as _yaml
    root = Path(tempfile.mkdtemp())
    (root / "governance").mkdir()
    (root / "governance" / "precedents.yaml").write_text(_yaml.safe_dump({"precedents": [{
        "id": "a-b", "question": "q",
        "seen_in": [{"pack": "products/oncology/prostate/202606", "decision": "FUED-DEFINITION"},
                    {"pack": "products/oncology/prostate/202606", "decision": "FUED-DEFINITION"}]}]}),
        encoding="utf-8")
    try:
        errs = precedents.errors(str(root))
        assert any("more than once" in e for e in errs), errs
        assert any("distinct (pack, decision)" in e for e in errs), errs
    finally:
        import shutil
        shutil.rmtree(root, ignore_errors=True)


def test_the_store_holds_no_answers():
    """Pointers only. `question` is the store's own words; everything else is read live from the
    register. An `answer:` key here would be the second copy this design exists to avoid."""
    entries, _ = precedents.load(str(REPO))
    allowed = {"id", "question", "seen_in"}
    for e in entries:
        extra = set(e) - allowed
        assert not extra, (f"{e['id']} carries {sorted(extra)} — the store holds pointers, not "
                           f"answers; the answer is read from the pack's register at display time")
        for s in e["seen_in"]:
            assert set(s) == {"pack", "decision"}, \
                f"{e['id']}: a sighting carries more than (pack, decision)"


def test_the_answer_shown_comes_from_the_register_not_the_store():
    """Proof the live read is real: a RESOLVED precedent's answer text is nowhere in the store file,
    and does appear in the rendered output.

    A SYNTHETIC store over the REAL registers. Every decision the live store cites is still open, so
    over the live store this test could only ever be vacuous — and it was written to notice that
    rather than to pass quietly. The registers are the repository's own, not fabricated: what is
    synthetic is only which decisions the store points at.
    """
    import shutil
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        root = os.path.join(tmp, "root")
        os.makedirs(os.path.join(root, "governance"))
        for pack in (P1, P2):
            os.makedirs(os.path.join(root, pack, "handoff"))
            shutil.copy(os.path.join(str(REPO), pack, "handoff", "DECISIONS.md"),
                        os.path.join(root, pack, "handoff", "DECISIONS.md"))
        store_path = os.path.join(root, "governance", "precedents.yaml")
        with open(store_path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write("precedents:\n"
                     "  - id: a-resolved-question\n"
                     "    question: q\n"
                     "    seen_in:\n"
                     f"      - {{pack: {P1}, decision: MAXINDEX}}\n"
                     f"      - {{pack: {P2}, decision: OC-PSOC-SHEET}}\n")

        # Both spellings of the answer column are exercised: prostate writes `Approved answer`,
        # oc writes `Resolution`. A reader knowing only one drops the other silently.
        answers = []
        for pack, did in ((P1, "MAXINDEX"), (P2, "OC-PSOC-SHEET")):
            rows, status = precedents.register(root, pack)
            assert status.get(did) == "RESOLVED", f"{pack}:{did} is no longer RESOLVED"
            answer = contract_lint.decision_answer(rows[did])
            assert answer.strip(), f"{pack}:{did} is RESOLVED but reads as blank"
            answers.append(answer)

        store = open(store_path, encoding="utf-8").read()
        rendered = " ".join(precedents.render(root).split())
        for answer in answers:
            probe = " ".join(answer.split())[:40]
            assert probe not in store, "the store contains an answer — it must hold pointers only"
            assert probe in rendered, "the rendered output did not read the live answer"

    # ...and the LIVE store carries no answer text of its own, whatever it cites.
    live = (REPO / "governance" / "precedents.yaml").read_text(encoding="utf-8")
    assert "answer:" not in live and "resolution:" not in live.lower()


def test_decisions_are_read_through_the_one_reader():
    """The same function OBJECT — a private markdown-table parser here is exactly the duplicate
    docs/ENGINEERING.md opens with, and the one that read a Status column positionally."""
    assert precedents.decision_rows is contract_lint.decision_rows
    assert precedents.decision_status is contract_lint.decision_status
    # `cell` used to be asserted here too, and precedents imported it for no other reason: the
    # import existed because the assertion existed, and the assertion proved the import. Both gone.
    # What matters is that the readers precedents ACTUALLY CALLS are the shared ones.
    assert precedents.decision_approver is contract_lint.decision_approver
    assert precedents.decision_answer is contract_lint.decision_answer


def test_proposals_key_on_recorded_sightings_only():
    """Over-propose, never under-propose. A pack cited in `seen_in` is covered; anything else is
    proposed — no matching of question wording, which would eventually pair two questions that
    merely sound alike and declare a pack covered when it is not."""
    entries, _ = precedents.load(str(REPO))
    cited = sorted({s["pack"] for e in entries for s in e["seen_in"]})
    assert cited, "no pack is cited anywhere"

    covered, todo, _ = precedents.propose(cited[0], str(REPO))
    assert covered, f"{cited[0]} is cited in the store but reported as covering nothing"
    assert all(cited[0] in {s["pack"] for s in e["seen_in"]} for e in covered)
    assert all(cited[0] not in {s["pack"] for s in e["seen_in"]} for e in todo)

    # A pack cited nowhere gets every precedent proposed, and none marked covered.
    covered2, todo2, _ = precedents.propose("products/oncology/nonexistent/000000", str(REPO))
    assert covered2 == [] and len(todo2) == len(entries)


def test_evidence_reaching_one_tumour_is_labelled_as_such():
    """One tumour's programme repeating itself is much weaker evidence that a DIFFERENT tumour will
    hit the question, and showing both kinds as one flat list overstates the weaker one.

    SYNTHETIC entries, because no live entry is single-tumour any more: the only thing that made one
    was a test fixture, and citing those is now an error. Asserting over the live store would have
    left `corroboration` free to return one label for everything the day the second kind vanished —
    the same shape as a check that passes because its subject is gone.
    """
    single = _entry((P1, "A"), (P1, "B"))
    multi = _entry((P1, "A"), (P2, "B"))
    assert len(precedents.tumours(single)) < precedents.MIN_TUMOURS
    assert len(precedents.tumours(multi)) >= precedents.MIN_TUMOURS

    label = precedents.corroboration(single)
    assert "not yet corroborated" in label, f"{label!r} overstates single-tumour evidence"
    assert "corroborated across" not in label
    assert "corroborated across" in precedents.corroboration(multi)
    assert precedents.reach(single) == "single_tumour"
    assert precedents.reach(multi) == "multi_tumour"

    # ...and every live entry is labelled by that same function, whichever kind it is.
    entries, _ = precedents.load(str(REPO))
    assert entries
    for e in entries:
        expected = ("corroborated across" if len(precedents.tumours(e)) >= precedents.MIN_TUMOURS
                    else "not yet corroborated")
        assert expected in precedents.corroboration(e), f"{e['id']}: mislabelled reach"


def test_tumours_counts_tumours_not_packs():
    """The whole point: prostate/202606 and prostate/202607 are two packs and ONE tumour."""
    entry = {"seen_in": [{"pack": "products/oncology/prostate/202606", "decision": "A"},
                         {"pack": "products/oncology/prostate/202607", "decision": "B"}]}
    assert precedents.tumours(entry) == {"prostate"}
    entry["seen_in"].append({"pack": "products/oncology/oc/202606", "decision": "C"})
    assert precedents.tumours(entry) == {"prostate", "oc"}

    # ...and a GROUPING level is not a tumour. Packs are found by shape at any depth, so the tumour
    # is the segment above the version. Read at a fixed offset, everything under one grouping level
    # answered `gu` and two tumours corroborated each other.
    grouped = {"seen_in": [{"pack": "products/oncology/gu/prostate/202606", "decision": "A"},
                           {"pack": "products/oncology/gu/bladder/202606", "decision": "B"}]}
    assert precedents.tumours(grouped) == {"prostate", "bladder"}


def test_a_fixture_is_neither_a_tumour_nor_a_sighting():
    """`platform/tests/fixtures/prostate_202607` is a parked spec revision the store used to cite.

    Read positionally it answered `fixtures` — a tumour nothing has ever delivered — and seven
    single-tumour entries became corroborated the moment the directory moved. Refusing it as a
    TUMOUR fixed that and left the SIGHTING count intact, so the same seven still met the
    two-sighting floor on one real prostate pack plus a directory the tests own and rewrite.

    Both halves are closed here. A fixture citation is an error in its own right, AND the floor is
    counted on governed packs, so an entry cannot reach it on fixture evidence even if the first
    check were somehow relaxed. Two independent guards, because the first one was written once
    already and was not enough.
    """
    parked = _packs.PARKED_REL
    assert precedents._slug(parked) == "", f"{parked} resolved to a tumour"
    assert parked not in set(product_gates.products(str(REPO))), \
        "the parked fixture is discoverable as a product pack — this test has lost its subject"

    entry = _entry((P1, "A"), (parked, "B"))
    assert precedents.tumours(entry) == {"prostate"}
    assert precedents.reach(entry) == "single_tumour"

    # The live store must not cite it at all.
    entries, _ = precedents.load(str(REPO))
    assert not any(s["pack"] == parked for e in entries for s in e["seen_in"]), \
        f"the store cites {parked} — a directory the test suite owns is not evidence"

    # ...and a store that did is refused, on both counts.
    import shutil
    import tempfile
    tmp = Path(tempfile.mkdtemp())
    try:
        (tmp / "governance").mkdir()
        (tmp / "governance" / "precedents.yaml").write_text(
            "precedents:\n"
            "  - id: a-b\n"
            "    question: q\n"
            "    seen_in:\n"
            f"      - {{pack: {P1}, decision: FUED-DEFINITION}}\n"
            f"      - {{pack: {parked}, decision: FU-END-DEFINITION}}\n", encoding="utf-8")
        for name in ("products", "platform"):
            (tmp / name).mkdir(exist_ok=True)
        errs = precedents.errors(str(tmp))
        assert any("not a governed product pack" in e for e in errs), errs
        assert any("sighting(s) in governed product packs" in e for e in errs), \
            f"the floor was satisfied by the fixture: {errs}"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_corroborated_precedents_are_listed_first():
    """A reader works down the list, so what two tumours independently hit belongs at the top.

    REACH leads the ordering, and the mixed-reach case is asserted on SYNTHETIC entries: every live
    entry is now multi-tumour, so over the live store a comparator that ignored reach entirely would
    look correct. The live half checks only that the ordering is stable and self-consistent.
    """
    with _fake_registers({P1: {"A": ("OPEN", "", ""), "B": ("OPEN", "", "")},
                          P2: {"C": ("OPEN", "", "")}}):
        single, multi = _entry((P1, "A"), (P1, "B")), _entry((P1, "A"), (P2, "C"))
        single["id"], multi["id"] = "aaa-single", "zzz-multi"
        ordered = sorted([single, multi], key=precedents._by_strength)
        assert [e["id"] for e in ordered] == ["zzz-multi", "aaa-single"], \
            "an uncorroborated entry sorted above a corroborated one, on id alone"

    _, todo, _ = precedents.propose("products/oncology/endometrial/YYYYMM", str(REPO))
    ordered = sorted(todo, key=precedents._by_strength)
    counts = [len(precedents.tumours(e)) >= precedents.MIN_TUMOURS for e in ordered]
    assert counts == sorted(counts, reverse=True), "uncorroborated entries sorted above proven ones"

    rendered = precedents.render_proposals("products/oncology/endometrial/YYYYMM", str(REPO))
    assert "corroborated across" in rendered, "no entry is labelled as corroborated"
    assert f"{len(todo)} corroborated across two or more tumours" in rendered


def test_source_keys_are_derived_and_never_stored():
    """The opposite call to the decision half, and the reason is worth keeping straight.

    `FUED-DEFINITION` and `OC-FU-END-DEFINITION` are the same question in two vocabularies, so a
    human has to say so and the YAML carries that. `demographics` and `demographics` are the same
    STRING, so writing them down would be a second copy of what the configs already say — stale the
    first time a pack adds a source.
    """
    store = (REPO / "governance" / "precedents.yaml").read_text(encoding="utf-8")
    for banned in ("source_keys:", "source_resolutions:", "sources:"):
        assert banned not in store, f"the store hand-lists {banned} — derive it from the configs"

    derived = precedents.source_key_precedents(str(REPO))
    assert derived, "derived nothing — the test would be vacuous"
    assert sum(len(v) for v in derived.values()) >= 10


def test_a_source_key_is_only_evidence_within_its_vendor():
    """Flatiron packs all declare practice/ses/telemed/vitals; neither COTA pack declares any.
    Proposing across that line would propose four tables that do not exist."""
    derived = precedents.source_key_precedents(str(REPO))
    assert {"flatiron", "cota"} <= set(derived), f"expected both vendors, got {sorted(derived)}"
    flat, cota = set(derived["flatiron"]), set(derived["cota"])
    only_flat = flat - cota
    assert only_flat, "the vendors declare identical keys — this test proves nothing"
    for key in only_flat:
        assert key not in cota, f"{key} leaked across the vendor boundary"

    # And end to end: no COTA pack is ever offered a Flatiron-only key.
    for pack in sorted(precedents.products(str(REPO))):
        vendor, keys = precedents.source_key_proposals(pack, str(REPO))
        if vendor == "cota":
            assert not (set(k for k, _ in keys) & only_flat), f"{pack} was offered a flatiron key"


def test_one_tumour_repeating_itself_is_not_a_precedent():
    """prostate 202603 and 202606 both declare `psa`, `provenge` and `alphabet`. That is one
    specification being re-read across two revisions, not evidence any other tumour needs them."""
    derived = precedents.source_key_precedents(str(REPO))
    single = {k for k, tum in derived.get("flatiron", {}).items() if len(tum) == 1}
    assert single, "no single-tumour key exists — this test proves nothing"

    for pack in sorted(precedents.products(str(REPO))):
        slug = pack.replace(os.sep, "/").split("/")[2]
        _, keys = precedents.source_key_proposals(pack, str(REPO))
        for key, others in keys:
            assert len(others) >= precedents.MIN_TUMOURS
            assert slug not in others, f"{pack}: proposed {key} on the strength of its own tumour"
            assert key not in single, f"{pack}: proposed {key}, seen in only one tumour"


def test_an_unknown_vendor_proposes_nothing():
    """Fail closed. A pack with no registry entry has no vendor, and a guess would propose another
    delivery's sources."""
    vendor, keys = precedents.source_key_proposals("products/oncology/nope/000000", str(REPO))
    assert vendor is None and keys == []


def test_a_pack_with_no_registry_entry_contributes_nothing_to_the_derivation():
    """On a SYNTHETIC root, because every pack in this repo happens to be registered.

    That is why this fixture exists rather than an assertion over the live packs: the skip in
    source_key_precedents is unreachable from real data today, so a mutation that defaulted the
    vendor instead of skipping passed every other test here. An unregistered pack folded in under a
    guessed vendor would put its sources into another delivery's evidence, and the first sign would
    be a proposal naming a table that vendor does not deliver.
    """
    import tempfile
    import textwrap
    with tempfile.TemporaryDirectory() as tmp:
        reg = os.path.join(tmp, "products")
        os.makedirs(reg)
        with open(os.path.join(reg, "registry.yaml"), "w", encoding="utf-8") as fh:
            fh.write("tumors:\n  - { code: kn, name: Known, slug: known, vendor: flatiron,\n"
                     "      tumor_class: solid, status: scaffold, current_spec_version: \"202601\" }\n")
        for slug in ("known", "ghost"):
            cfg = os.path.join(reg, "oncology", slug, "202601", "config")
            os.makedirs(cfg)
            with open(os.path.join(cfg, "data_product.yaml"), "w", encoding="utf-8") as fh:
                fh.write(textwrap.dedent(f"""\
                    data_product_id: {slug}_rwdp
                    sources:
                      {slug}_only_key: t_whatever
                      shared_key: t_shared
                    """))

        derived = precedents.source_key_precedents(tmp)
        assert set(derived) == {"flatiron"}, f"an unregistered pack got a vendor: {sorted(derived)}"
        assert set(derived["flatiron"]) == {"known_only_key", "shared_key"}, \
            "the unregistered pack's sources entered the derivation"
        assert "ghost_only_key" not in derived["flatiron"]
        assert "ghost" not in derived["flatiron"]["shared_key"], \
            "the unregistered pack was counted as a tumour sighting"


def test_no_physical_table_name_is_ever_proposed():
    """They are not stable even within a vendor (t_demographics vs t_meg_demographics; mortality
    differs across all three Flatiron packs), and confirming one is Gate 3's job, with a profile and
    a human. Proposing one would guess exactly what the framework refuses to guess."""
    derived = precedents.source_key_precedents(str(REPO))
    for vendor, keys in derived.items():
        for key in keys:
            assert not key.startswith("t_"), f"{vendor}: {key} looks like a physical table name"

    rendered = precedents.render_proposals("products/oncology/endometrial/YYYYMM", str(REPO))
    assert "t_demographics" not in rendered and "t_meg_" not in rendered, \
        "a physical table name reached the proposal output"


def test_version_drift_only_ever_compares_a_tumour_with_itself():
    """It is the complement of the precedent proposals, and the two must not blur: proposals
    exclude this tumour, drift reports ONLY this tumour."""
    seen_any = {}
    for pack in sorted(precedents.products(str(REPO))):
        slug = precedents._slug(pack)
        drift = precedents.version_drift(pack, str(REPO))
        seen_any[pack] = drift
        for key, others in drift.items():
            for other in others:
                assert precedents._slug(other) == slug, \
                    f"{pack}: drift cites {other}, a different tumour — that is precedent, not drift"
                assert other != pack, f"{pack}: drift cites the pack itself"
    assert any(seen_any.values()), "no pack drifts at all — this test would prove nothing"


def test_version_drift_reports_only_keys_this_pack_lacks():
    """One direction. A version that ADDS sources is the ordinary shape of a new spec revision, and
    listing those would bury the line worth reading."""
    for pack in sorted(precedents.products(str(REPO))):
        mine = precedents._declared(str(REPO), pack)
        for key in precedents.version_drift(pack, str(REPO)):
            assert key not in mine, f"{pack}: drift reports {key}, which this pack declares"


def test_a_tumour_with_one_pack_has_no_drift():
    """Nothing to compare against is not a finding."""
    packs = sorted(precedents.products(str(REPO)))
    by_slug = {}
    for p in packs:
        by_slug.setdefault(precedents._slug(p), []).append(p)
    singles = [ps[0] for ps in by_slug.values() if len(ps) == 1]
    assert singles, "every tumour has multiple packs — this test would prove nothing"
    for p in singles:
        assert precedents.version_drift(p, str(REPO)) == {}


def test_drift_is_rendered_apart_from_precedent_and_after_it():
    """Run together they would read as one list of proposals, and one of them is not a proposal."""
    r = precedents.render_proposals("products/oncology/prostate/202606", str(REPO))
    assert "VERSION DRIFT" in r, "the drift section did not render"
    assert "SOURCE KEYS" in r
    assert r.index("SOURCE KEYS") < r.index("VERSION DRIFT"), "drift rendered above the proposals"
    assert "NOT precedent" in r, "the drift section does not say it is not a precedent"


def test_a_pack_with_nothing_to_propose_gets_no_preamble():
    """The pack that seeded the store had four paragraphs introducing an empty list."""
    seeded = precedents.render_proposals("products/oncology/prostate/202606", str(REPO))
    assert "Nothing to propose" in seeded
    assert "QUESTIONS TO EXPECT" not in seeded, "preamble printed over an empty list"

    has_todo = precedents.render_proposals("products/oncology/endometrial/YYYYMM", str(REPO))
    assert "QUESTIONS TO EXPECT" in has_todo, "the preamble vanished where it is needed"


def _drift_kinds():
    """(a pack that has drifted, a pack that never started, the root they live in).

    A MATERIALISED ROOT. The unstarted pack is prostate/202607, which is not a product — it never
    was one (unregistered, never built, never released) and sat in `products/` only so these tests
    had a subject. `_packs` restores it to its product path in a temp copy, alongside the real
    packs, which supply the started side of the same contrast; a root holding only the fixture would
    make every one of these assertions vacuous in the direction that matters.
    """
    root = _packs.materialised_root()
    started = unstarted = None
    for pack in sorted(precedents.products(root)):
        if not precedents.version_drift(pack, root):
            continue
        if precedents._declared(root, pack):
            started = started or pack
        else:
            unstarted = unstarted or pack
    assert started and unstarted, "need a drifted pack AND an unstarted one for these tests"
    return started, unstarted, root


def test_a_pack_that_never_started_is_not_described_as_having_regressed():
    """NOT STARTED and REGRESSED are different states and only one is a defect.

    prostate/202607 has no config/ at all, so every key its siblings declare counted as drift —
    under a heading telling the reader the tool could not distinguish a removal from a regression,
    when nothing had been removed. Same shape as scoring an absent test suite as PASS.
    """
    started, unstarted, root = _drift_kinds()

    r = precedents.render_proposals(unstarted, root)
    assert "nothing has DRIFTED" in r, f"{unstarted}: an unstarted pack is not told so"
    assert "cannot tell a deliberate removal from a regression" not in r, \
        f"{unstarted} has never declared a source and is being described as possibly regressed"

    r2 = precedents.render_proposals(started, root)
    assert "cannot tell a deliberate removal from a regression" in r2
    assert "nothing has DRIFTED" not in r2, f"{started} declares sources and is called unstarted"


def test_the_unstarted_section_reports_only_what_the_checklist_does_not():
    """The two lists otherwise overlap almost entirely — sixteen of twenty-one on prostate/202607.
    What is worth reading is the remainder: sources only this product has ever needed."""
    _, unstarted, root = _drift_kinds()
    drift = precedents.version_drift(unstarted, root)
    _, proposed = precedents.source_key_proposals(unstarted, root)
    already = {k for k, _ in proposed}
    overlap, extra = already & set(drift), set(drift) - already
    assert overlap and extra, "need both an overlap and a remainder for this to prove anything"

    section = precedents.render_proposals(unstarted, root).split("VERSION DRIFT", 1)[1]
    for key in sorted(overlap):
        assert f"! {key} " not in section, f"{key} is listed twice — once as a proposal, once here"
    for key in sorted(extra):
        assert f"! {key} " in section, f"{key} is only in this section and was dropped"


def test_tripwire_vendor_and_tumour_class_are_still_perfectly_correlated():
    """A TRIPWIRE, not a requirement. It is SUPPOSED to fail one day, and the failure is the point.

    The source-key half scopes on vendor, resting on one observation: all four Flatiron packs
    declare practice/ses/telemed/vitals and neither COTA pack declares any. But every Flatiron
    registry entry is `solid` and every COTA entry is `heme`, so that observation fits "does not
    cross vendors" and "does not cross solid/heme" equally well. The data cannot separate them.

    The first Flatiron heme product — or COTA solid product — separates them, and this fires on the
    day it lands. When it does, do not simply delete it: look at whether that pack's sources follow
    its vendor or its tumour class, and scope on whichever it turns out to be. Nothing else in the
    suite would notice, because scoping on the wrong axis is invisible until the axes disagree.
    """
    import yaml
    reg = yaml.safe_load((REPO / "products" / "registry.yaml").read_text(encoding="utf-8"))
    pairs = {}
    for t in reg["tumors"]:
        pairs.setdefault(t.get("vendor"), set()).add(t.get("tumor_class"))
    assert len(pairs) > 1, "only one vendor in the registry — the tripwire cannot arm"

    classes_per_vendor = {v: sorted(c) for v, c in pairs.items()}
    collisions = [v for v, c in pairs.items() if len(c) > 1]
    seen_classes = [c for cs in pairs.values() for c in cs]
    shared = len(seen_classes) != len(set(seen_classes))

    assert not collisions and not shared, (
        "THE CONFOUND IS BROKEN — and that is good news, not a defect.\n"
        f"    vendor -> tumour classes: {classes_per_vendor}\n"
        "    Vendor and tumour class are no longer perfectly correlated, so it is now possible to\n"
        "    tell which axis a pack's source keys actually follow. Check that pack, then scope\n"
        "    source_key_precedents on whichever axis the evidence supports, and delete this test.")


def test_the_tumour_is_derived_in_exactly_one_place():
    """`_slug` is the ONE reader of a tumour out of a pack path, and it had three inline copies.

    All four spelled `split("/")[2]`, all four agreed, and the copies were invisible: fixing the
    offset in `_slug` left `source_key_precedents` grouping by the GROUPING level, so the derived
    half and the labelled half would disagree about which packs are one tumour.

    AST, not a text search. A grep for the pattern is defeated by a comment containing it — this
    codebase has now written that same guard six times and had it defeated once.
    """
    tree = ast.parse((TOOLS / "precedents.py").read_text(encoding="utf-8"))
    offenders = []
    for fn in [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]:
        if fn.name == "_slug":
            continue
        for node in ast.walk(fn):
            # <something>.split(...)[<n>] — indexing straight into a split path.
            if (isinstance(node, ast.Subscript) and isinstance(node.value, ast.Call)
                    and isinstance(node.value.func, ast.Attribute)
                    and node.value.func.attr == "split"):
                offenders.append(f"{fn.name}:{node.lineno}")
    assert not offenders, ("a second derivation of a path segment outside _slug: "
                           + ", ".join(offenders))


def test_no_gate_reads_the_store():
    """POWERLESS is the property, and it is enforced by nobody importing it.

    If a gate ever reads precedents.yaml, an advisory reading list has become a thing that can
    grant — and the "AI proposes, humans approve" boundary quietly moves.
    """
    gates = ["source_manifest.py", "product_gates.py", "contract_lint.py", "contract_binding.py",
             "source_check.py", "finalize.py", "deploy_tree.py", "bundle_products.py",
             "repo_hygiene.py", "contract_scaffold.py", "spec_slice.py"]
    for g in gates:
        src = (TOOLS / g).read_text(encoding="utf-8")
        assert "precedents" not in src, (
            f"{g} mentions precedents — the store is ADVISORY and no gate may read it")


def test_the_store_is_not_deployed_to_production():
    """It is governance prose about how products get built; the runtime has no use for it."""
    import deploy_tree
    assert not any("precedents" in str(f) for f in deploy_tree.ROOT_FILES)


def test_an_answer_is_read_whatever_the_register_spells_the_column():
    """THE REGISTERS DISAGREE, AND A CALLER KNOWING A SUBSET LOSES ANSWERS SILENTLY.

    The answer column is `Approved answer` in prostate/202606 and `Resolution` in prostate/202607
    and oc/202606. This harvester knew ("Approved answer", "Answer") — so oc/202606's RESOLVED
    OC-PSOC-SHEET, which carries a real answer under `Resolution`, came back as the empty string.
    One of only three resolved decisions in the repository, dropped by a spelling, with no error.

    The vocabulary now lives in contract_lint beside the reader that owns the tables. This asserts
    every accepted spelling resolves, and that the store reads a real recorded answer off a pack
    that uses a non-canonical one."""
    import contract_lint as cl
    for spelling in cl.ANSWER_COLUMNS:
        row = {"ID": "D-1", spelling: "the agreed answer"}
        assert cl.decision_answer(row) == "the agreed answer", \
            f"{spelling!r} is declared an accepted answer column but does not resolve"

    # ...and it bites on the real pack that caused it: a RESOLVED decision must not read as blank.
    found = False
    for pack in sorted(product_gates.products(str(REPO))):
        path = os.path.join(str(REPO), pack, "handoff", "DECISIONS.md")
        if not os.path.exists(path):
            continue
        text = cl.read(path)
        rows = cl.decision_rows(text)
        for did, status in cl.decision_status(text).items():
            if str(status).strip().upper() != "RESOLVED":
                continue
            found = True
            assert (cl.decision_answer(rows[did]) or "").strip(), \
                f"{pack}:{did} is RESOLVED but its answer reads as blank — a spelling is unmapped"
    assert found, "no pack has a RESOLVED decision — this test would prove nothing"


def test_the_store_is_appendable_only_under_its_own_rules():
    """The store went stale because appending was hand YAML editing — seven of nine entries read
    one tumour while a second register answered the same questions. `--add` is the write side,
    under the store's rules rather than around them: citations validated live, MIN_SIGHTINGS not
    relaxable, duplicates refused, and the comments — the store's governance content — preserved
    byte for byte."""
    import shutil
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        root = os.path.join(tmp, "root")
        os.makedirs(os.path.join(root, "governance"))
        shutil.copy(os.path.join(str(REPO), "governance", "precedents.yaml"),
                    os.path.join(root, "governance", "precedents.yaml"))
        for pack in (P1, P2):
            os.makedirs(os.path.join(root, pack, "handoff"))
            shutil.copy(os.path.join(str(REPO), pack, "handoff", "DECISIONS.md"),
                        os.path.join(root, pack, "handoff", "DECISIONS.md"))
        store = os.path.join(root, "governance", "precedents.yaml")
        before = open(store, encoding="utf-8").read()
        comments = [l for l in before.splitlines() if l.lstrip().startswith("#")]

        # a citation that does not resolve never enters
        _c, errs, t = precedents.add_sighting(
            "days-per-month-constant", [(P2, "NOT-A-ROW")], root=root)
        assert t is None and any("no decision" in e for e in errs), errs
        # a duplicate is refused, not doubled
        _c, errs, t = precedents.add_sighting(
            "days-per-month-constant", [(P1, "TT-INTERVAL-FORMULA")], root=root)
        assert t is None and any("already cites" in e for e in errs), errs
        # one sighting cannot found a new entry
        _c, errs, t = precedents.add_sighting(
            "some-new-question", [(P2, "OC-PSOC-SHEET")],
            question="Is one enough?", root=root)
        assert t is None and any(str(precedents.MIN_SIGHTINGS) in e for e in errs), errs
        # a non-question id is refused
        _c, errs, t = precedents.add_sighting(
            "PROSTATE", [(P2, "OC-PSOC-SHEET"), (P1, "MAXINDEX")],
            question="Named after a tumour?", root=root)
        assert t is None and any("kebab-case" in e for e in errs), errs

        # a VALID single sighting: one line appears, every comment survives, the store reloads
        changed, errs, t = precedents.add_sighting(
            "days-per-month-constant", [(P2, "OC-PSOC-SHEET")], root=root)
        assert errs == [] and changed, errs
        open(store, "w", encoding="utf-8", newline="\n").write(t)
        after = open(store, encoding="utf-8").read()
        assert [l for l in after.splitlines() if l.lstrip().startswith("#")] == comments, \
            "the append rewrote or dropped a comment — the store's reasoning is content"
        delta = [l for l in after.splitlines() if l not in before.splitlines()]
        assert len(delta) == 1 and "OC-PSOC-SHEET" in delta[0], delta
        entries, load_errs = precedents.load(root)
        assert not load_errs
        entry = next(e for e in entries if e.get("id") == "days-per-month-constant")
        assert {"pack": P2, "decision": "OC-PSOC-SHEET"} in entry["seen_in"]

        # a NEW entry with two citations lands whole and the store still parses
        changed, errs, t = precedents.add_sighting(
            "who-answers-what", [(P2, "OC-PSOC-SHEET"), (P1, "MAXINDEX")],
            question="Which role answers which register, and where is that recorded?", root=root)
        assert errs == [] and changed, errs
        open(store, "w", encoding="utf-8", newline="\n").write(t)
        entries, load_errs = precedents.load(root)
        assert not load_errs
        new = next(e for e in entries if e.get("id") == "who-answers-what")
        assert len(new["seen_in"]) == 2 and new["question"].strip()


def test_recording_an_answer_points_at_the_store_unconditionally():
    """No matcher can pair FUED-DEFINITION with OC-FU-END-DEFINITION; the pairing judgment is a
    person's, made while the answer is fresh. So decision_record prints the --add usage after every
    recorded wave — a pointer, not a guess."""
    src = (REPO / "platform" / "tools" / "decision_record.py").read_text(encoding="utf-8")
    assert "precedents.py --add" in src, "recording an answer no longer points at the store"
    stmt_start = src.rfind("print(", 0, src.index("precedents.py --add"))
    indent = len(src[src.rfind("\n", 0, stmt_start) + 1:stmt_start])
    assert indent == 4, \
        f"the pointer prints at indent {indent} — nested in a branch, so some recorded waves " \
        "never see it; it must print for every one"


# --- strength: two axes --------------------------------------------------------------------------
# Every entry used to render identically whether its citations were signed rulings, unsigned answers
# or still open. `authority` grades what stands behind the answers, `reach` how far the evidence
# travels, and they are INDEPENDENT: the single tier they replace let `single_tumour` short-circuit
# the grade, so a signed answer inside one programme and an open question inside one programme came
# out the same. Both are computed — a stored grade would be a claim about a register this file does
# not own. Mutation-tested against synthetic registers, because over the live store (where nothing
# is signed) a grader that always returned `question` would look correct.

@_ctx.contextmanager
def _fake_registers(mapping):
    """{pack: {decision: (STATUS, approver, date)}} -> a stand-in for the live registers.

    STDLIB, not `monkeypatch`. CI runs every suite as a SCRIPT (`python3 tests/test_*.py`) and
    installs no test runner, so a test taking a pytest fixture is not a test that fails there — it
    is a TypeError that fails the whole job, and every governance step after it is skipped. The
    suite passed under pytest the entire time, which is exactly what made it invisible.
    """
    def register(root, pack):
        rows = {d: {"__": v} for d, v in (mapping.get(pack) or {}).items()}
        status = {d: v[0] for d, v in (mapping.get(pack) or {}).items()}
        return rows, status

    saved = [(precedents, "register", precedents.register),
             (precedents, "decision_approver", precedents.decision_approver),
             (precedents, "decision_approval_date", precedents.decision_approval_date),
             (precedents.os.path, "isdir", precedents.os.path.isdir)]
    precedents.register = register
    precedents.decision_approver = lambda row: list(row.values())[0][1]
    precedents.decision_approval_date = lambda row: list(row.values())[0][2]
    precedents.os.path.isdir = lambda p: True
    try:
        yield
    finally:
        for obj, name, original in saved:
            setattr(obj, name, original)


def test_two_tumours_all_signed_is_a_ruling():
    with _fake_registers({P1: {"A": ("RESOLVED", "R. Owner", "2026-05-01")},
                          P2: {"B": ("RESOLVED", "R. Owner", "2026-05-02")}}):
        assert precedents.strength(_entry((P1, "A"), (P2, "B"))) == ("multi_tumour", "ruling")


def test_one_unsigned_answer_demotes_the_whole_entry():
    """THE DEFECT THIS GRADES. A resolved row with an empty approver column is an answer with
    nobody behind it; one of them in the chain means the precedent is not a ruling."""
    with _fake_registers({P1: {"A": ("RESOLVED", "R. Owner", "2026-05-01")},
                          P2: {"B": ("RESOLVED", "", "")}}):
        assert precedents.authority(_entry((P1, "A"), (P2, "B"))) == "answer"


def test_an_unusable_approval_date_is_not_a_signature():
    """Signed means a named approver AND a well-formed date — `bad_date` via knowledge_graph, not a
    second regex living here."""
    with _fake_registers({P1: {"A": ("RESOLVED", "R. Owner", "soon")},
                          P2: {"B": ("RESOLVED", "R. Owner", "2026-05-02")}}):
        assert precedents.authority(_entry((P1, "A"), (P2, "B"))) == "answer"


def test_some_answered_some_open_is_partial():
    with _fake_registers({P1: {"A": ("RESOLVED", "R. Owner", "2026-05-01")},
                          P2: {"B": ("OPEN", "", "")}}):
        assert precedents.authority(_entry((P1, "A"), (P2, "B"))) == "partial"


def test_open_everywhere_is_a_question():
    with _fake_registers({P1: {"A": ("OPEN", "", "")}, P2: {"B": ("OPEN", "", "")}}):
        assert precedents.authority(_entry((P1, "A"), (P2, "B"))) == "question"


def test_reach_and_authority_are_independent_axes():
    """THE DEFECT THE SPLIT FIXES. The single tier let `single_tumour` short-circuit the grade, so
    an entry answered and SIGNED inside one programme graded identically to one still open inside
    one programme — the stronger fact was computed and thrown away.

    Signing still does not create reach, and reach still does not create authority. Both facts are
    reported, and neither silences the other.
    """
    with _fake_registers({P1: {"A": ("RESOLVED", "R. Owner", "2026-05-01"),
                               "B": ("RESOLVED", "R. Owner", "2026-05-02"),
                               "C": ("OPEN", "", "")},
                          P2: {"D": ("OPEN", "", "")}}):
        signed_one_tumour = precedents.strength(_entry((P1, "A"), (P1, "B")))
        open_one_tumour = precedents.strength(_entry((P1, "A"), (P1, "C")))
        open_two_tumours = precedents.strength(_entry((P1, "C"), (P2, "D")))

    assert signed_one_tumour == ("single_tumour", "ruling")
    assert open_two_tumours == ("multi_tumour", "question")
    assert signed_one_tumour != open_one_tumour, \
        "a signed single-tumour entry grades the same as an unsigned one — the axes are collapsed"
    assert signed_one_tumour.reach == open_one_tumour.reach == "single_tumour"
    assert open_one_tumour.authority == "partial"


def test_a_citation_that_does_not_resolve_beats_every_other_grade():
    """An entry pointing at a decision that no longer exists cannot be graded on answers it claims
    to have — it must not read as `question` (mildly weak) when it is broken."""
    with _fake_registers({P1: {"A": ("RESOLVED", "R. Owner", "2026-05-01")}, P2: {}}):
        assert precedents.authority(_entry((P1, "A"), (P2, "GONE"))) == "unresolvable"
        # ...and it sorts below a sound entry whatever its reach.
        broken = _entry((P1, "A"), (P2, "GONE"))
        sound = _entry((P1, "A"), (P1, "A"))
        broken["id"], sound["id"] = "aaa-broken", "zzz-sound"
        assert [e["id"] for e in sorted([broken, sound], key=precedents._by_strength)] == \
            ["zzz-sound", "aaa-broken"]


def test_the_live_store_has_no_rulings_and_the_rendering_says_so():
    """What is true today: every decision these entries cite is open. If a signature lands, this
    assertion should be updated deliberately rather than quietly satisfied."""
    entries, bad = precedents.load()
    assert not bad
    cache = {}
    graded = {e["id"]: precedents.strength(e, cache=cache) for e in entries}
    assert not any(s.authority == "ruling" for s in graded.values()), graded
    out = precedents.render()
    assert "NONE of these is a ruling" in out
    assert "never authority to cite" in out
    # Both axes print on every entry — the whole point of splitting them.
    for pid in graded:
        assert f"[reach: {graded[pid].reach}] [authority: {graded[pid].authority}]" in out, \
            f"{pid}: the rendering does not carry both axes"


def test_a_hand_typed_grade_is_refused():
    """A stored grade is a claim about a register this file does not own — on EITHER axis."""
    import shutil
    import tempfile
    for banned in ("strength", "tier", "authority", "reach"):
        tmp_path = Path(tempfile.mkdtemp())
        try:
            store = tmp_path / "governance"
            store.mkdir()
            (store / "precedents.yaml").write_text(
                "precedents:\n"
                "  - id: a-b\n"
                "    question: q\n"
                f"    {banned}: ruling\n"
                "    seen_in:\n"
                f"      - {{pack: {P1}, decision: FUED-DEFINITION}}\n"
                f"      - {{pack: {P2}, decision: OC-FU-END-DEFINITION}}\n",
                encoding="utf-8")
            for name in ("products", "platform"):
                (tmp_path / name).mkdir(exist_ok=True)
            errs = precedents.errors(str(tmp_path))
            assert any("COMPUTED from the live" in e and banned in e for e in errs), (banned, errs)
        finally:
            shutil.rmtree(tmp_path, ignore_errors=True)


def test_the_grade_ordering_puts_the_strongest_first_on_both_axes():
    """A reader works down the list. The ordering IS the recommendation."""
    assert precedents.REACH_NAMES == ("multi_tumour", "single_tumour")
    assert precedents.AUTHORITY_NAMES[0] == "ruling"
    assert precedents.AUTHORITY_NAMES[-1] == "unresolvable"
    assert precedents.AUTHORITY_NAMES.index("answer") < precedents.AUTHORITY_NAMES.index("question")
    # The two vocabularies must not share a name: a value that could belong to either axis makes
    # `[reach: X] [authority: X]` ambiguous to read and to grep.
    assert not set(precedents.REACH_NAMES) & set(precedents.AUTHORITY_NAMES)


if __name__ == "__main__":
    os.chdir(FRAMEWORK)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")


