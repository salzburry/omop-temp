"""A protocol is worth what its FREEZE is worth — this is what makes the freeze checkable.

A product's contract is an ongoing reconciliation between a workbook and a configuration. A
protocol's record answers a different question, once: *was this specified before the results were
seen?* An objective added afterwards, an endpoint swapped for the one that reached significance, a
subgroup that appears in the write-up and not the plan — each is invisible in the finished document,
and pre-specification exists to make each visible.

So the tests here are about one property and its two failure directions:

  * too weak — a registered plan can be edited and nothing notices, and the freeze is decoration;
  * too noisy — reflowing a paragraph reads as an amendment, people learn to re-stamp the digest
    without reading, and the freeze is decoration again by a different route.

The digest is therefore over the CANONICAL form of `prespecified:` and nothing else, and amendment
is a first-class path rather than an obstacle: a registered protocol may be amended, never edited.

Run: python3 tests/test_protocol_record.py (or pytest).
"""
import shutil
import sys
import tempfile
from pathlib import Path

import yaml

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))

import protocol_record as pr     # noqa: E402

WHO = "T. Test"
PRE = {
    "objectives": ["compare A vs B"],
    "design": "retrospective cohort",
    "population": "adults at first line",
    "endpoints": {"primary": ["overall survival"], "secondary": ["rwPFS"]},
    "analyses": ["Kaplan-Meier, Cox adjusted for age and ECOG"],
}


def _doc(**over):
    d = {"protocol_id": "prot-1", "title": "t", "status": "registered",
         "registered_by": WHO, "registered_date": "2026-08-01",
         "prespecified": yaml.safe_load(yaml.safe_dump(PRE)), "amendments": []}
    d.update(over)
    d.setdefault("prespecification_sha256", pr.prespecification_digest(d))
    return d


def _root(record=None, work=None, pid="prot-1"):
    root = Path(tempfile.mkdtemp())
    (root / "products" / "oncology" / "testis" / "202608").mkdir(parents=True)
    reg = {"tumors": [{"code": "testis", "slug": "testis", "name": "Testis", "vendor": "flatiron",
                       "tumor_class": "solid", "status": "scaffold"}],
           "work": work if work is not None else [
               {"id": pid, "kind": "protocol", "title": "t",
                "cites_release": [{"product": "testis", "spec_version": "202608"}]}]}
    (root / "products" / "registry.yaml").write_text(yaml.safe_dump(reg), encoding="utf-8")
    if record is not None:
        p = root / pr.rr.WORK / pid
        p.mkdir(parents=True)
        (p / pr.RECORD).write_text(yaml.safe_dump(record), encoding="utf-8")
    return root


def _entry(root, pid="prot-1"):
    reg = yaml.safe_load((root / "products" / "registry.yaml").read_text(encoding="utf-8"))
    return next(w for w in reg["work"] if w["id"] == pid)


def _errs(root, pid="prot-1"):
    return pr.record_errors(str(root), _entry(root, pid))


def test_the_digest_ignores_formatting_and_notices_content():
    """Both directions of the same property, because getting either wrong empties the freeze."""
    base = pr.prespecification_digest({"prespecified": PRE})
    reflowed = yaml.safe_load(yaml.safe_dump(PRE))
    reflowed["design"] = "  retrospective    cohort  "
    reflowed = dict(reversed(list(reflowed.items())))
    assert pr.prespecification_digest({"prespecified": reflowed}) == base, \
        "whitespace or key order moved the digest — people will learn to re-stamp without reading"
    for change in (("objectives", ["compare A vs C"]),
                   ("population", "adults at second line"),
                   ("analyses", ["Kaplan-Meier only"])):
        d = yaml.safe_load(yaml.safe_dump(PRE))
        d[change[0]] = change[1]
        assert pr.prespecification_digest({"prespecified": d}) != base, change[0]
    # and the ORDER of endpoints is part of what was specified
    d = yaml.safe_load(yaml.safe_dump(PRE))
    d["endpoints"]["primary"] = ["rwPFS", "overall survival"]
    assert pr.prespecification_digest({"prespecified": d}) != base


def test_a_dropped_key_cannot_hash_equal_to_one_that_never_had_it():
    """Every pre-specified key is folded in BY NAME, so deleting the secondary endpoints is a
    change rather than a return to some earlier shape."""
    d = yaml.safe_load(yaml.safe_dump(PRE))
    del d["endpoints"]
    assert pr.prespecification_digest({"prespecified": d}) != \
        pr.prespecification_digest({"prespecified": PRE})
    assert pr.prespecification_digest({}) is None, "a missing block must be None, not a digest"


def test_the_frozen_subtree_is_declared_not_discovered():
    """A field added under `prespecified:` but not to PRESPECIFIED would sit OUTSIDE the freeze —
    pre-specified in appearance and editable in fact. The list is the source of truth."""
    d = yaml.safe_load(yaml.safe_dump(PRE))
    before = pr.prespecification_digest({"prespecified": d})
    d["a_new_unlisted_field"] = "anything"
    assert pr.prespecification_digest({"prespecified": d}) == before
    assert set(PRE) <= set(pr.PRESPECIFIED), "the template pre-specifies a key the freeze ignores"


def test_a_draft_may_carry_markers():
    root = _root(record={"protocol_id": "prot-1", "status": "draft",
                         "registered_by": pr.MARK, "registered_date": pr.MARK,
                         "prespecification_sha256": pr.MARK, "prespecified": PRE})
    try:
        assert _errs(root) == [], _errs(root)
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_registered_protocol_may_not_be_registered_by_a_marker():
    for field in pr.HUMAN_FIELDS:
        root = _root(record=_doc(**{field: pr.MARK}))
        try:
            assert any(field in e and "marker" in e for e in _errs(root)), (field, _errs(root))
        finally:
            shutil.rmtree(root, ignore_errors=True)


def test_registration_without_a_digest_is_refused():
    root = _root(record=_doc(prespecification_sha256=pr.MARK))
    try:
        bad = _errs(root)
        assert any("the freeze is the digest" in e for e in bad), bad
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_editing_a_registered_plan_without_an_amendment_is_refused():
    """THE POINT. The plan changed and the record still claims the digest it was registered under."""
    d = _doc()
    d["prespecified"]["endpoints"]["primary"] = ["rwPFS"]     # swapped after registration
    root = _root(record=d)
    try:
        bad = _errs(root)
        assert any("no amendment covers the change" in e for e in bad), bad
        assert any("amended, never edited" in e for e in bad), bad
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_an_amendment_covering_the_change_is_accepted():
    d = _doc()
    d["prespecified"]["endpoints"]["secondary"] = ["rwPFS", "rwTTD"]
    new = pr.prespecification_digest(d)
    d["status"] = "amended"
    d["amendments"] = [{"date": "2026-08-14", "by": WHO, "what_changed": "secondary endpoints",
                        "why": "added rwTTD at the sponsor's request", "covers_digest": new}]
    d["prespecification_sha256"] = new
    root = _root(record=d)
    try:
        assert _errs(root) == [], _errs(root)
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_an_amendment_that_covers_the_change_but_a_stale_top_level_digest_says_so():
    """A distinct, actionable message: the amendment is fine, the header has not caught up."""
    d = _doc()
    registered = d["prespecification_sha256"]
    d["prespecified"]["analyses"] = ["Kaplan-Meier only"]
    new = pr.prespecification_digest(d)
    d["amendments"] = [{"date": "2026-08-14", "by": WHO, "what_changed": "analyses",
                        "why": "simplified", "covers_digest": new}]
    d["prespecification_sha256"] = registered            # not moved forward
    root = _root(record=d)
    try:
        bad = _errs(root)
        assert any("the newest amendment covers" in e for e in bad), bad
        assert not any("no amendment covers" in e for e in bad), bad
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_an_amendment_must_say_who_what_when_and_why():
    for missing in ("date", "by", "what_changed", "why", "covers_digest"):
        a = {"date": "2026-08-14", "by": WHO, "what_changed": "x", "why": "y",
             "covers_digest": "0" * 64}
        a.pop(missing)
        root = _root(record=_doc(amendments=[a]))
        try:
            assert any(f"{missing} is unstated" in e for e in _errs(root)), (missing, _errs(root))
        finally:
            shutil.rmtree(root, ignore_errors=True)


def test_a_protocol_with_nothing_prespecified_has_nothing_to_freeze():
    root = _root(record={"protocol_id": "prot-1", "status": "registered", "registered_by": WHO,
                         "registered_date": "2026-08-01", "prespecification_sha256": "0" * 64})
    try:
        assert any("nothing to freeze" in e for e in _errs(root)), _errs(root)
    finally:
        shutil.rmtree(root, ignore_errors=True)


# --- study drift: a request may not read outside the protocol it runs under --------------------

def _scope_root(req_cites, prot_status="registered", under="prot-1"):
    work = [{"id": "prot-1", "kind": "protocol", "title": "p",
             "cites_release": [{"product": "testis", "spec_version": "202608"}]},
            {"id": "req-1", "kind": "request", "title": "r", "under_protocol": under,
             "cites_release": req_cites}]
    root = _root(record=_doc(status=prot_status) if prot_status != "draft" else
                 {"protocol_id": "prot-1", "status": "draft", "prespecified": PRE},
                 work=work)
    return root


def test_a_request_may_not_read_a_release_its_protocol_never_named():
    root = _scope_root([{"product": "testis", "spec_version": "202603"}])
    try:
        bad = pr.request_scope_errors(str(root))
        assert any("does not cite" in e for e in bad), bad
        assert any("one analysis at a time" in e for e in bad), bad
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_request_reading_exactly_what_the_protocol_cites_is_in_scope():
    root = _scope_root([{"product": "testis", "spec_version": "202608"}])
    try:
        assert pr.request_scope_errors(str(root)) == []
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_running_under_a_draft_protocol_is_refused():
    """Work executed under an unregistered plan is not pre-specified, which is the only thing
    running under a protocol buys."""
    root = _scope_root([{"product": "testis", "spec_version": "202608"}], prot_status="draft")
    try:
        bad = pr.request_scope_errors(str(root))
        assert any("still `draft`" in e for e in bad), bad
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_under_protocol_must_name_a_protocol():
    root = _scope_root([{"product": "testis", "spec_version": "202608"}], under="req-1")
    try:
        assert any("is not a registered protocol" in e for e in pr.request_scope_errors(str(root)))
    finally:
        shutil.rmtree(root, ignore_errors=True)


# --- scope is the BUILD wherever the protocol pins one ------------------------------------------
# `source_manifest.citation_errors` has always known two citation strengths — the pack, and the pack
# plus a build. Scope compared spec versions only, so a request under a protocol written against one
# release could read a different cut of the same specification and pass. Different cut, different
# data, same plan.

def _pinned_root(prot_cites, req_cites, extra_req=None):
    work = [{"id": "prot-1", "kind": "protocol", "title": "p", "cites_release": prot_cites},
            {"id": "req-1", "kind": "request", "title": "r", "under_protocol": "prot-1",
             "cites_release": req_cites}]
    if extra_req is not None:
        work.append({"id": "req-2", "kind": "request", "title": "r2",
                     "under_protocol": "prot-1", "cites_release": extra_req})
    return _root(record=_doc(status="registered"), work=work)


PACK = {"product": "testis", "spec_version": "202608"}
BUILD_A = dict(PACK, build_id="b-aaa", manifest_sha256="a" * 64)
BUILD_B = dict(PACK, build_id="b-bbb", manifest_sha256="b" * 64)


def test_a_protocol_that_names_only_the_pack_permits_any_build():
    """Pre-specification comes BEFORE the cut. A plan registered against a pack it has not read
    pins nothing, and requiring it to would invert the order the whole mechanism depends on."""
    root = _pinned_root([PACK], [BUILD_A])
    try:
        assert pr.request_scope_errors(str(root)) == []
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_request_reading_a_different_build_than_the_protocol_pinned_is_refused():
    root = _pinned_root([BUILD_A], [BUILD_B])
    try:
        bad = pr.request_scope_errors(str(root))
        assert any("different cut of the same specification" in e for e in bad), bad
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_a_request_naming_no_build_under_a_pinned_protocol_is_refused():
    """The quiet version of the same defect: the request could have read any cut, and the record
    does not say which."""
    root = _pinned_root([BUILD_A], [PACK])
    try:
        bad = pr.request_scope_errors(str(root))
        assert any("without naming a build" in e for e in bad), bad
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_the_matching_build_is_in_scope():
    root = _pinned_root([BUILD_A], [dict(BUILD_A)])
    try:
        assert pr.request_scope_errors(str(root)) == []
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_two_requests_reading_two_builds_is_a_finding_no_single_record_can_see():
    """Both requests are individually in scope — the protocol names the pack, and each names a
    build it permits. The study's numbers then came from two deliveries, and nothing said so."""
    root = _pinned_root([PACK], [BUILD_A], extra_req=[BUILD_B])
    try:
        assert pr.request_scope_errors(str(root)) == [], "neither request is out of scope"
        findings = pr.split_build_findings(pr.scope_report(str(root)))
        assert len(findings) == 1, findings
        assert "2 different builds" in findings[0] and "b-aaa" in findings[0]
        assert "b-bbb" in findings[0]
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_one_build_across_every_request_is_not_a_finding():
    root = _pinned_root([PACK], [BUILD_A], extra_req=[dict(BUILD_A)])
    try:
        assert pr.split_build_findings(pr.scope_report(str(root))) == []
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_the_scope_report_answers_what_data_this_study_read():
    """The question no individual record answers. A protocol names packs; each request names a
    build; nothing joined them, so recovering a study's provenance meant opening every request."""
    root = _pinned_root([PACK], [BUILD_A])
    try:
        report = pr.scope_report(str(root))
        slot = report["prot-1"][("testis", "202608")]
        assert slot["pinned"] == [], "the protocol pinned nothing"
        assert slot["read"] == [("b-aaa", "a" * 64)]
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_the_split_build_finding_reaches_check():
    """It has to fail the same command CI runs, not only a function a test can call."""
    root = _pinned_root([PACK], [BUILD_A], extra_req=[BUILD_B])
    try:
        rows = pr.check(str(root))
        scope = dict(rows).get("(scope)") or []
        assert any("different builds" in e for e in scope), rows
    finally:
        shutil.rmtree(root, ignore_errors=True)


# --- markers: EVERY field of a frozen record, not a remembered list -----------------------------

def test_a_registered_protocol_carrying_a_marker_anywhere_is_refused():
    """The module header claimed --check refused this. It checked two fields, so a registered
    protocol could carry a scaffold TITLE and a scaffold objective and report clean."""
    for field, value in (("title", pr.MARK),
                         ("prespecified", dict(PRE, design=pr.MARK))):
        doc = _doc(**{field: value})
        doc["prespecification_sha256"] = pr.prespecification_digest(doc)
        root = _root(record=doc)
        try:
            errs = _errs(root)
            assert any(pr.MARK in e and "scaffold speaking in their place" in e for e in errs), \
                (field, errs)
        finally:
            shutil.rmtree(root, ignore_errors=True)


def test_the_marker_sweep_names_the_field_rather_than_counting():
    doc = _doc(title=pr.MARK)
    root = _root(record=doc)
    try:
        errs = _errs(root)
        assert any("`title` still holds" in e for e in errs), errs
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_new_scaffolds_markers_and_refuses_to_regenerate():
    root = Path(tempfile.mkdtemp())
    old = pr.REPO
    pr.REPO = str(root)
    try:
        assert pr.main(["--new", "prot-9"]) == 0
        text = (root / pr.rr.WORK / "prot-9" / pr.RECORD).read_text(encoding="utf-8")
        assert text.count(pr.MARK) >= 8
        doc = yaml.safe_load(text)
        assert doc["status"] == "draft", "a scaffold may only write the status nobody signed"
        assert doc["amendments"] == []
        assert pr.main(["--new", "prot-9"]) == 1
        assert pr.main(["--new", ""]) == 1
    finally:
        pr.REPO = old
        shutil.rmtree(root, ignore_errors=True)


def test_the_live_repository_registers_no_protocol():
    assert pr.check(str(REPO)) == []


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
