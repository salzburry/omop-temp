"""The `vocabularies:` declaration, and the refusal it buys.

A pack says what each MATCHED column carries — `{source, column, system}` — and the validator turns
a contradiction into a refusal. The contradiction that matters is one nothing else in this framework
can see:

    codelists/treatment_categories.yaml:  like_any: ["%bevacizumab%"]
    the delivered column:                 NDC

Preflight passes (the column exists). The compiler passes (the operator is real). Spark runs. Every
line falls to the always-true catch-all, the build succeeds, and the line-of-therapy categories are
wrong for every patient with no error anywhere — and a golden regenerated from the same config
agrees with itself, so the goldens do not catch it either.

The counterweight, tested just as hard: this must NOT become a rule every pack has to satisfy
before it can run. An undeclared column is UNANSWERED, not text and not coded, and nothing refuses
it — all thirteen live packs declare nothing today and must keep linting clean.

Run: python3 tests/test_vocabulary_config.py (or pytest).
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK))

from engine import validate                       # noqa: E402
from engine import vocabularies as v              # noqa: E402
from engine.config import Config                  # noqa: E402

CODELIST = {
    "match_on": {"name_column": "linename", "drug_category_column": "detaileddrugcategory"},
    "categories": [
        {"code": 1, "label": "Bev", "match": {"like_any": ["%bevacizumab%"]}},
        {"code": 2, "label": "Other", "match": {"always": True}},
    ],
}


def _cfg(vocabularies=None, codelist=None, sources=None):
    raw = {
        "sources": sources if sources is not None else {"lot": "t_lot", "drug_episode": "t_epi"},
        "vocabularies": vocabularies or [],
    }
    cfg = Config(raw, REPO)
    cfg._codelists = {"treatment_categories": codelist or CODELIST}
    return cfg


def _codelist_errors(cfg):
    return validate._operator_vocabulary_problems(cfg, cfg.codelist("treatment_categories"))


def test_declaring_nothing_changes_nothing():
    """The compatibility promise. Every live pack is in this state."""
    assert validate._vocabulary_problems(_cfg()) == []
    assert _codelist_errors(_cfg()) == []
    # ...and an unrelated declaration does not reach this codelist either
    cfg = _cfg([{"source": "lot", "column": "somethingelse", "system": "icd10cm"}])
    assert _codelist_errors(cfg) == []


def test_a_name_operator_against_a_declared_code_column_is_refused():
    cfg = _cfg([{"source": "lot", "column": "linename", "system": "ndc"}])
    bad = _codelist_errors(cfg)
    assert bad and "ndc" in bad[0] and "lot.linename" in bad[0], bad
    assert "catch-all" in bad[0], "the refusal must say what goes WRONG, not just that it is wrong"
    # every name-reading operator, not just the one in the fixture
    for op, val in (("equals", "bev"), ("regexp", ".*bev.*"), ("is_null", True)):
        one = dict(CODELIST, categories=[{"code": 1, "label": "x", "match": {op: val}},
                                         {"code": 2, "label": "y", "match": {"always": True}}])
        assert _codelist_errors(_cfg([{"source": "lot", "column": "linename",
                                       "system": "icd10cm"}], one)), op
    # ...including one buried inside all_of / any_of, which is where a real codelist hides them
    nested = dict(CODELIST, categories=[
        {"code": 1, "label": "x",
         "match": {"all_of": [{"any_of": [{"like_any": ["%bev%"]}]}, {"always": True}]}},
        {"code": 2, "label": "y", "match": {"always": True}}])
    assert _codelist_errors(_cfg([{"source": "lot", "column": "linename", "system": "ndc"}],
                                 nested))


def test_declaring_the_column_as_text_is_an_answer_and_permits_the_match():
    """`text` is the declaration that the column carries names. It must not be refused."""
    cfg = _cfg([{"source": "lot", "column": "linename", "system": "text"}])
    assert _codelist_errors(cfg) == []
    assert validate._vocabulary_problems(cfg) == []


def test_the_drug_category_column_is_checked_on_its_own_source():
    """linename comes off `lot`, the category off `drug_episode` — the same split the treatment
    stage and the required-columns check already make. Declaring one must not implicate the other."""
    catlist = dict(CODELIST, categories=[
        {"code": 1, "label": "x", "match": {"category_equals": "chemo"}},
        {"code": 2, "label": "y", "match": {"always": True}}])
    ok = _cfg([{"source": "lot", "column": "detaileddrugcategory", "system": "atc"}], catlist)
    assert _codelist_errors(ok) == [], "a declaration on the WRONG source fired"
    hit = _cfg([{"source": "drug_episode", "column": "detaileddrugcategory", "system": "atc"}],
               catlist)
    bad = _codelist_errors(hit)
    assert bad and "drug_episode.detaileddrugcategory" in bad[0], bad


def test_the_block_itself_is_validated():
    """An entry that names nothing, or a source the pack does not declare, or an unknown system."""
    assert any("no source named" in e for e in
               validate._vocabulary_problems(_cfg([{"column": "linename", "system": "text"}])))
    assert any("no column named" in e for e in
               validate._vocabulary_problems(_cfg([{"source": "lot", "system": "text"}])))
    bad = validate._vocabulary_problems(
        _cfg([{"source": "nowhere", "column": "c", "system": "text"}]))
    assert any("not declared in sources" in e for e in bad), bad
    bad = validate._vocabulary_problems(
        _cfg([{"source": "lot", "column": "c", "system": "icd11"}]))
    assert any("unknown coding system" in e for e in bad), bad
    # a blank system is refused: `text` is how you say a column carries text
    bad = validate._vocabulary_problems(_cfg([{"source": "lot", "column": "c"}]))
    assert any("no coding system declared" in e for e in bad), bad


def test_one_column_carries_one_system():
    """Two declarations for the same column are two answers to the question the block settles.
    Last-wins would silently pick one — and which one would depend on file order."""
    bad = validate._vocabulary_problems(_cfg([
        {"source": "lot", "column": "linename", "system": "text"},
        {"source": "lot", "column": "LINENAME", "system": "ndc"},
    ]))
    assert any("already declared" in e for e in bad), bad


def test_system_for_answers_none_when_nothing_declares_it():
    """None means unanswered. Every caller must treat it as "no refusal available", never "safe"."""
    cfg = _cfg([{"source": "lot", "column": "linename", "system": "ndc"}])
    assert cfg.system_for("lot", "linename") == "ndc"
    assert cfg.system_for("lot", "LINENAME") == "ndc", "the lookup must be case-insensitive"
    assert cfg.system_for("drug_episode", "linename") is None
    assert cfg.system_for("lot", "undeclared") is None
    assert not v.is_coded(cfg.system_for("lot", "undeclared"))


def test_every_live_pack_still_lints_clean():
    """The compatibility promise, against the real packs rather than a fixture."""
    sys.path.insert(0, str(FRAMEWORK / "tools"))
    import product_gates as pg
    from engine.config import load_config
    checked = 0
    for rel in pg.products(str(REPO)):
        path = REPO / rel / "config" / "data_product.yaml"
        if not path.exists():
            continue
        cfg = load_config(str(path))
        assert validate._vocabulary_problems(cfg) == [], rel
        checked += 1
    assert checked >= 10, f"only {checked} packs checked — this would pass over the portfolio"


if __name__ == "__main__":
    bad = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok  {name}")
            except Exception as e:                   # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {name}: {e}")
    sys.exit(1 if bad else 0)
