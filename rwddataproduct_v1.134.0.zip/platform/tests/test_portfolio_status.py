"""The portfolio table is generated, and this pins why it had to be.

The root README carried it by hand under the sentence "status mirrors registry.yaml
(test-enforced)". Nothing enforced it, and six of its eight rows said `planned` for products the
registry had moved to `scaffold` — a stale copy of somebody else's fact, wearing a claim of
enforcement.

What is pinned here: the rendering is current; DRIFT is reported rather than repaired (a tool that
edited the registry and the shelf into agreement would destroy the evidence that they disagreed);
each drift rule fires on a planted defect; and the README no longer restates a per-product status it
would have to keep in sync by hand.

NO PYTEST FIXTURES, and that is not a style preference. CI runs every suite as a SCRIPT, so a test
that takes a fixture argument cannot be called at all outside pytest — and a suite CI cannot run is
a green step protecting nothing. This file shipped that way once and
`test_spec_pipeline.test_every_suite_actually_runs_the_way_ci_invokes_it` caught it; the plain
helpers below and the runner at the bottom are what that test requires.

Run: python3 tests/test_portfolio_status.py (or pytest).
"""
import contextlib
import copy
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))

import portfolio_status as ps  # noqa: E402

_ROWS = []


def rows():
    """The live facts, computed once per process."""
    if not _ROWS:
        _ROWS.extend(ps.facts())
    return _ROWS


@contextlib.contextmanager
def _loader(mutate):
    """Swap `ps._load` for one that hands back a MUTATED copy, leaving every file alone.

    `monkeypatch` is a pytest fixture like any other, so the swap is done by hand and restored in a
    `finally` — a test that left the loader patched would poison every test after it.
    """
    real = ps._load

    def fake(path):
        doc = copy.deepcopy(real(path))
        mutate(path, doc)
        return doc

    ps._load = fake
    try:
        yield
    finally:
        ps._load = real


def _registry_status(slug, status):
    def mutate(path, doc):
        if path == ps.REGISTRY:
            for t in doc["tumors"]:
                if t["slug"] == slug:
                    t["status"] = status
    return mutate


def test_the_rendering_is_current():
    assert ps.main(["--check"]) == 0, \
        "PORTFOLIO.md is stale — regenerate: python3 platform/tools/portfolio_status.py"


def test_every_registry_product_and_every_overlay_appears():
    """Neither list may be silently dropped: a registered product with no overlay and an overlay
    with no product are both facts a reader needs, and both were invisible before."""
    import yaml
    reg = yaml.safe_load((REPO / "products" / "registry.yaml").read_text(encoding="utf-8"))
    inv = yaml.safe_load(
        (REPO / "governance" / "reference" / "variable_inventory" / "INVENTORY.yaml")
        .read_text(encoding="utf-8"))
    slugs = {str(t["slug"]) for t in reg["tumors"]}
    listed = {r["slug"] for r in rows()}
    assert slugs <= listed, f"registry products missing from the table: {sorted(slugs - listed)}"
    overlays = {r["overlay"] for r in rows() if r["overlay"]}
    assert set(inv["tumours"]) <= overlays, \
        f"reference overlays missing: {sorted(set(inv['tumours']) - overlays)}"


def test_an_overlay_with_no_registered_product_is_reported():
    """The shelf is ahead of the portfolio for two tumours today. If that stops being true the
    assertion should be updated deliberately, not silently satisfied by an empty list."""
    unregistered = {r["slug"] for r in rows() if r["status"] == "not in the registry"}
    assert unregistered == {"multiple_myeloma", "myelofibrosis"}, unregistered
    for r in rows():
        if r["slug"] in unregistered:
            assert any("shelf is ahead" in d for d in r["drift"])


def test_a_template_pack_is_not_counted_as_a_product():
    """`<slug>/YYYYMM/` is the copied template. Counting it as a pack is how a portfolio comes to
    look further along than it is — the drift line is the only thing that says so."""
    tmpl = [r for r in rows() if r["placeholder"]]
    assert tmpl, "no placeholder packs — this test has lost its subject"
    for r in tmpl:
        assert any("template placeholder" in d for d in r["drift"]), r


def test_a_registry_version_with_no_pack_behind_it_is_reported():
    """A spec version nothing on disk supports. Distinct from the template case: this one names a
    real-looking version, which is worse, because it reads as a product that exists."""
    def mutate(path, doc):
        if path == ps.REGISTRY:
            for t in doc["tumors"]:
                if t["slug"] == "mcrc":
                    t["current_spec_version"] = "209912"

    with _loader(mutate):
        row = next(r for r in ps.facts() if r["slug"] == "mcrc")
    assert any("no pack exists at that path" in d for d in row["drift"]), row["drift"]


def test_active_without_a_declared_maturity_is_reported():
    """CI applies gates from the MATURITY claim, so an `active` pack without one is not held to
    them — the one drift line that is about governance rather than about files.

    Both directions: oc DECLARES maturity and must not fire, endometrial's template carries none
    and must. A rule checked in one direction only is a rule that could be inverted unnoticed.
    """
    with _loader(_registry_status("oc", "active")):
        row = next(r for r in ps.facts() if r["slug"] == "oc")
    assert not any("no handoff/MATURITY.yaml" in d for d in row["drift"]), \
        "oc declares maturity — the rule must not fire on it"

    with _loader(_registry_status("endometrial", "active")):
        row = next(r for r in ps.facts() if r["slug"] == "endometrial")
    assert any("no handoff/MATURITY.yaml" in d for d in row["drift"]), row["drift"]


def test_a_registered_product_with_no_reference_overlay_is_reported():
    def mutate(path, doc):
        if path.name == "INVENTORY.yaml":
            doc["tumours"].pop("mcrc", None)

    with _loader(mutate):
        row = next(r for r in ps.facts() if r["slug"] == "mcrc")
    assert any("no reference overlay" in d for d in row["drift"]), row["drift"]


def test_the_loader_swap_is_restored():
    """A patched loader left in place would make every later test read a mutated repository, and
    the failures would look like defects in the tool."""
    real = ps._load
    with _loader(lambda path, doc: None):
        assert ps._load is not real
    assert ps._load is real


def test_drift_is_reported_not_repaired():
    """The registry and the shelf are hand-maintained on purpose. The tool must not write to
    either — the evidence that they disagreed is the finding."""
    before = {p: p.read_bytes() for p in
              (REPO / "products" / "registry.yaml",
               REPO / "governance" / "reference" / "variable_inventory" / "INVENTORY.yaml",
               FRAMEWORK / "capabilities.yaml")}
    ps.facts()
    for p, b in before.items():
        assert p.read_bytes() == b, f"portfolio_status modified {p}"


def test_the_readme_no_longer_restates_per_product_status():
    """The specific defect: a second copy of registry.yaml's status column, maintained by hand."""
    md = (REPO / "README.md").read_text(encoding="utf-8")
    assert "products/PORTFOLIO.md" in md, "the README must point at the generated table"
    assert "| Registry status |" not in md, \
        "the hand-typed status column is back — it is what went stale for six products"


def test_the_counts_are_coverage_classes_not_a_reach_score():
    """The first version carried an `answerable` column that counted a family as answered whenever
    ANY capability named its master. Upstream-required LINE_OF_THERAPY counted as engine reach, a
    generic RW_RESPONSE capability answered for a tumour whose per-line response is still a gap, and
    every row read `answerable == families` — a column that cannot come out wrong."""
    md = (REPO / "products" / "PORTFOLIO.md").read_text(encoding="utf-8")
    assert "| vars | native | config | upstream | gaps |" in md
    assert "answerable" not in md.split("## Drift")[0], "the reach score is back in the table"
    assert "does NOT say" in md
    assert "coverage CLASSES, not readiness" in md
    # `upstream` is the column a new tumour reads first, and it must not read as engineering work.
    assert "delivery requirement, not engineering work" in md


def test_upstream_required_variables_are_counted_apart_from_engine_reach():
    """LINE_OF_THERAPY is the concrete case: the engine configures it and does not build it, so it
    belongs in `upstream`, never in `native`."""
    for r in rows():
        if not r["overlay"]:
            continue
        assert r["variables"] == r["native"] + r["configurable"] + r["upstream"] + r["gaps"], r
    assert any(r["upstream"] for r in rows()), "no upstream_required variables — subject lost"


if __name__ == "__main__":
    # CI RUNS EVERY SUITE AS A SCRIPT. Without this block the file executes its imports, defines its
    # tests, runs none of them and exits 0 — a green step protecting nothing.
    bad = 0
    for _name, _fn in sorted(globals().items()):
        if _name.startswith("test_") and callable(_fn):
            try:
                _fn()
                print(f"  ok  {_name}")
            except Exception as _e:                  # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {_name}: {_e}")
    sys.exit(1 if bad else 0)
