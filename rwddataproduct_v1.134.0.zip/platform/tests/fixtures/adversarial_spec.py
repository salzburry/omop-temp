#!/usr/bin/env python3
"""Build a SYNTHETIC, DELIBERATELY HOSTILE mCRC program specification, for testing the extractor.

    python3 platform/tests/fixtures/adversarial_spec.py <out.xlsx>

WHAT THIS IS, AND WHAT IT IS NOT. Every cell is written here, by hand, in this file. It is not
vendor material, contains no delivered data, and describes no real product: it is a workbook shaped
like an RWB program specification whose only purpose is to be difficult to read correctly. It must
never be registered as a specification for any pack — `test_adversarial_extraction.py` builds it in
a temp directory and deletes it.

WHY IT EXISTS. `spec_extract` documents its own qualification boundary: whitespace is stripped,
formulas yield cached values, the header is the first row with three or more populated cells, and
merges/hidden rows/comments are REPORTED rather than read. Those limits were established against
the prostate template. A specification that is genuinely detailed and complex — branching rules,
section banners, superseded columns, dropdowns, footnotes — exercises them all at once, and the
question worth answering before a new workbook lands is not "does the extractor have limits" but
"when a limit bites, does anything SAY SO".

Each planted row carries its attack id in the `Additional Notes` column, so the test can score what
survived, what was reported, and what vanished without a trace. The three outcomes are different:

    EXTRACTED   the text came through and a reader can see it
    REPORTED    the text was lost or altered, and `workbook_structure`/`spec_lint` says so
    SILENT      the text was lost or altered and nothing anywhere indicates it

Only SILENT is a defect. A documented limit that announces itself is a working control.
"""
from __future__ import annotations

import sys

HEADER = ["Time Period", "Variable", "Label", "Values", "Definition",
          "Additional Notes", "QC Reviewed (Initials + Date)", "Date Modified"]

# (attack id, what it plants, what a correct reader must end up with)
ATTACKS = {
    "A01": "full-width merge spanning MULTIPLE ROWS — a banner shape that swallows whole rows",
    "A02": "partial-width merge across the Definition column",
    "A03": "formula with NO cached value — cell looks empty, is not",
    "A04": "formula WITH a stale cached value — reads as data, is arithmetic nobody re-ran",
    "A05": "hidden row carrying a retired rule",
    "A06": "hidden column headed 'Definition (superseded)', left of the real Definition",
    "A07": "dropdown data-validation list — the enumeration is not in any cell",
    "A08": "cell comment carrying the caveat that changes the rule",
    "A09": "three-cell title row above the real header",
    "A10": "two VISIBLE columns both resolving to `definition`",
    "A11": "en-dash range 18–64 rather than a hyphen",
    "A12": "non-breaking space inside a value list",
    "A13": "impossible calendar date",
    "A14": "if/else-if chain with no terminal else",
    "A15": "explicit [verify] marker left by the spec author",
    "A16": "prose placeholder where a formula belongs",
    "A17": "truncated text, cut off mid-rule",
    "A18": "same variable defined twice, on two tabs, with DIFFERENT rules",
    "A19": "rule that defers to another tab by row number",
    "A20": "enumeration values differing only by case and trailing space",
    "A21": "definition cell genuinely blank",
    "A22": "numeric-looking variable name that is a code, not a number",
    "A23": "multi-line cell whose ELSE branch is on the second line",
    "A24": "unbalanced parentheses in a derivation",
}


def _rows_demographics():
    return [
        # A09: a three-cell title row ABOVE the header. `spec_extract` takes the first row with
        # >=3 populated cells as the header, so this row is a candidate.
        ["mCRC Program Specification", "v0.9 DRAFT", "2026-08-17", None, None, None, None, None],
        HEADER,
        ["BASELINE", "AGE", "Age at index", "Integer",
         "Age in years at index date = year(index) - birthyear", "A21-control", "QC 2026-08-01", ""],
        # A11: en-dash. A band parser splitting on '-' sees one token, not two.
        ["BASELINE", "AGEGR1", "Age group", "1=18–64; 2=65–74; 3=75+",
         "Band AGE into 18–64, 65–74, 75+", "A11", "", ""],
        # A12: NBSP between value and label; A20: case/trailing-space near-duplicates.
        ["BASELINE", "SIDED", "Primary tumour sidedness",
         "1=Left; 2=Right; 3=Unknown; 3=unknown ", "Sidedness of the primary tumour",
         "A12,A20", "", ""],
        # A13 + A14 + A15 in one realistic rule.
        ["BASELINE", "REGION", "Census region",
         "1=Northeast; 2=Midwest; 3=South; 4=West",
         "If state in NE list then 1 else if state in MW list then 2 else if state in S list then 3 "
         "[verify] — mapping frozen as of 4/31/2026",
         "A13,A14,A15", "", ""],
        # A21: the Definition cell is genuinely empty. Must be distinguishable from A03.
        ["BASELINE", "ETHNIC", "Ethnicity", "1=Hispanic; 2=Not Hispanic; 99=Unknown", None,
         "A21", "", ""],
        # A22: a variable name that is entirely digits.
        ["BASELINE", "12345", "Legacy numeric code", "Integer",
         "Retired identifier retained for lineage", "A22", "", ""],
    ]


def _rows_clinical():
    return [
        HEADER,
        # A02 anchor: the merge below covers Values..Definition for this and the next row.
        ["INDEX", "MDIAGDT", "Metastatic diagnosis date", "Date",
         "Earliest metastatic diagnosis date from enhanced table", "A02-anchor", "", ""],
        ["INDEX", "MDIAGTYPE", "Presentation type", None, None, "A02", "", ""],
        # A03: formula, no cached value.
        ["INDEX", "SYNCFL", "Synchronous flag", "0/1", "=IF(B3=B4,1,0)", "A03", "", ""],
        # A04: the formula says 270; `_plant_stale_cache` makes the cache say 180. Somebody
        # widened the lookback and the file was never recalculated.
        ["INDEX", "LOOKBACK", "Lookback days", "Integer", "=90*3", "A04", "", ""],
        # A05: this row is hidden.
        ["INDEX", "MDIAGDT_OLD", "Metastatic diagnosis date (retired)", "Date",
         "Superseded by MDIAGDT — do not implement", "A05", "", ""],
        # A16 + A17.
        ["BIOMARKER", "RAS", "RAS status", "1=Mutant; 2=Wild-type; 99=Unknown",
         "[Apply the standard RAS calling rule] over results in the window (cut off at right edge",
         "A16,A17", "", ""],
        # A23: the ELSE branch is on a second line inside the cell.
        ["BIOMARKER", "MSI", "MSI status", "1=MSI-H; 2=MSS; 99=Unknown",
         "If any MSI-H result in window then 1\nelse if any MSS result then 2\nelse 99",
         "A23", "", ""],
        # A24: unbalanced parentheses.
        ["BIOMARKER", "BRAF", "BRAF V600E status", "1=Mutant; 2=Wild-type; 99=Unknown",
         "If (result contains 'V600E' and testdate <= index + 90 then 1 else 2", "A24", "", ""],
        # A18 (first definition; the second is on Outcomes).
        ["OUTCOME", "OS", "Overall survival", "Months",
         "From index date to death; censor at last activity", "A18-first", "", ""],
        # A19: defers to another tab.
        ["OUTCOME", "TTNT", "Time to next treatment", "Months",
         "See 6. Outcomes row 4 for the censoring rule", "A19", "", ""],
    ]


def _rows_outcomes():
    return [
        HEADER,
        # A18 (second definition — DIFFERENT censoring rule from the Clinical tab).
        ["OUTCOME", "OS", "Overall survival", "Months",
         "From index date to death; censor at end of data availability", "A18-second", "", ""],
        ["OUTCOME", "PFS", "Progression-free survival", "Months",
         "From index to progression or death, whichever first", "control", "", ""],
        ["OUTCOME", "TTNT", "Time to next treatment (censoring)", "Months",
         "Censor at last confirmed activity date", "A19-target", "", ""],
        # A07: a dropdown supplies the enumeration; the cell itself is thin.
        ["OUTCOME", "DTHSRC", "Death source", "(see dropdown)",
         "Source of the death date used", "A07", "", ""],
        # A01 VICTIMS. Real requirement rows, written with real content, which the full-width merge
        # applied in build() then blanks. Merging over EMPTY rows proves nothing — the first version
        # of this fixture did exactly that and the attack scored as harmless.
        ["OUTCOME", "OSCENS12", "OS censored at 12 months", "Months",
         "As OS, administratively censored at index + 365 days", "A01-victim", "", ""],
        ["OUTCOME", "PFSRAS", "PFS by RAS status", "Months",
         "As PFS, stratified by the RAS call at index", "A01-victim", "", ""],
    ]


def _rows_studypop():
    """A02/A10 live here, away from A09. On the Demos tab the title row becomes the header and
    every later attack on that sheet is masked by it — one attack per seam, or a fixture measures
    which attack it happened to order first."""
    return [
        HEADER + ["Derivation (RWB)"],
        ["STUDY", "INCL01", "Inclusion: mCRC diagnosis", "0/1",
         "Metastatic colorectal diagnosis on or after index_start",
         "A10-anchor", "", "", "SHADOW: any colorectal diagnosis, metastatic or not"],
        ["STUDY", "INCL02", "Inclusion: age at index", "0/1",
         "Age >= 18 at index date", "control", "", "", ""],
        ["STUDY", "EXCL01", "Exclusion: prior systemic therapy", "0/1",
         "Any systemic therapy before index date", "control", "", "", ""],
    ]


def build(path):
    """Write the workbook. Every structural attack is applied AFTER the cell values, because a
    merge/hide/validation is a property of the sheet rather than of a value."""
    import openpyxl
    from openpyxl.comments import Comment
    from openpyxl.worksheet.datavalidation import DataValidation

    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    # A09 lives alone. Its title row becomes the header for the whole sheet, so any other attack
    # placed here is masked by it and scores as "caught" for the wrong reason.
    demos = wb.create_sheet("5A. Demos")
    for r in _rows_demographics():
        demos.append(r)

    # A10: two VISIBLE columns both resolving to `definition`, on a sheet whose header IS found.
    pop = wb.create_sheet("4.StudyPop")
    for r in _rows_studypop():
        pop.append(r)

    clin = wb.create_sheet("5B. ClinChars")
    for r in _rows_clinical():
        clin.append(r)
    # A02: partial-width merge over Values..Definition for the MDIAGTYPE row.
    clin.merge_cells(start_row=2, start_column=4, end_row=3, end_column=5)
    # A05: hide the retired row.
    clin.row_dimensions[6].hidden = True
    # A06: a hidden column headed as a superseded Definition, LEFT of the real one.
    clin.insert_cols(5)
    clin.cell(row=1, column=5, value="Definition (superseded)")
    clin.cell(row=2, column=5, value="SUPERSEDED: latest metastatic diagnosis date")
    clin.column_dimensions["E"].hidden = True
    # A08: the caveat lives in a comment.
    clin.cell(row=8, column=6).comment = Comment(
        "Only results from the central lab count. Local-lab results are excluded.", "RWB")

    out = wb.create_sheet("6. Outcomes")
    for r in _rows_outcomes():
        out.append(r)
    # A01: a FULL-WIDTH merge spanning MULTIPLE ROWS. `workbook_structure` reports only merges that
    # are not full width, on the reasoning that a full-width merge is a banner and swallows nothing.
    # A banner is one row; this is five columns wide and three rows tall, and it deletes them.
    out.merge_cells(start_row=6, start_column=1, end_row=8, end_column=8)
    out.cell(row=6, column=1,
             value="SECTION: sensitivity analyses — OS censored at 12 months; PFS by RAS status; "
                   "TTNT excluding maintenance")
    # A07: the dropdown that IS the enumeration.
    dv = DataValidation(type="list", formula1='"EHR,Obituary,SSDI,Linked claims"', allow_blank=True)
    out.add_data_validation(dv)
    dv.add(out["D5"])

    wb.save(path)
    _plant_stale_cache(path)
    return path


def _plant_stale_cache(path, stale="180"):
    """A04 — a formula whose CACHED value disagrees with the formula.

    openpyxl writes formulas with no cached result, so a workbook it saves can only ever produce
    the `formula_no_value` case. A stale cache is the more dangerous one and needs the XML: Excel
    stores `<f>` and `<v>` side by side, and `data_only=True` returns the `<v>` without ever
    looking at the `<f>`. If somebody edits the formula and the file is not recalculated, the
    extractor reports the OLD number as the specification's value, with nothing anywhere to say so.

    Planted on LOOKBACK, whose formula reads `=90*3`. The cache is set to 180 — the answer from
    BEFORE somebody widened the lookback window. The extractor publishes 180; the workbook's own
    arithmetic says 270; nothing anywhere reconciles the two. This is undetectable from the file:
    telling them apart means evaluating the formula, which an extractor that refuses to transform
    anything must not start doing.
    """
    import re as _re
    import shutil
    import zipfile
    src = path + ".tmp"
    shutil.move(path, src)
    with zipfile.ZipFile(src) as zin, zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename.startswith("xl/worksheets/sheet"):
                text = data.decode("utf-8")
                # openpyxl emits `<c r="F5"><f>90*2</f><v /></c>` — a SELF-CLOSING empty `<v/>`,
                # which is what makes `data_only=True` hand back None. Fill it in.
                text = _re.sub(r'(<c r="F5"[^>]*><f>[^<]*</f>)<v\s*/>',
                               rf'\1<v>{stale}</v>', text)
                data = text.encode("utf-8")
            zout.writestr(item, data)
    import os as _os
    _os.remove(src)
    return path


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) != 1:
        sys.exit(__doc__.strip().splitlines()[2].strip())
    print(build(argv[0]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
