"""Materialise a fixture pack as a PRODUCT, in a temp root.

`prostate/202607` was a real second spec revision that never became a product: unregistered, never
built, never released. It lived in `products/` only because several suites need a pack that has a
CONTRACT and NO CONFIG — Gate 2 done, Gate 4 not started — which is the shape a set of fail-closed
rules are about: an empty section over an empty denominator, an unstarted config reported as drift,
and which records carry to a new spec revision.

Keeping it in `products/` made it a fake product that every gate sweep, demo and status page had to
carry and explain. It now lives here, and the suites that need it DISCOVERED as a product copy it
into a temp root — real packs alongside it, because most of those assertions are about a CONTRAST
("some pack has a config and some does not") and a root holding only the fixture would make half of
each one vacuous in the direction that matters.
"""
import atexit
import os
import shutil
import tempfile

FIXTURES = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(os.path.dirname(os.path.dirname(FIXTURES)))

PARKED = os.path.join(FIXTURES, "prostate_202607")
PARKED_REL = "platform/tests/fixtures/prostate_202607"
AS_PRODUCT = "products/oncology/prostate/202607"

_SKIP = shutil.ignore_patterns("__pycache__", "reference")
_ROOT = None


def repo_with_fixture_pack(tmp):
    """A temp repo root: the real `products/` and `governance/`, plus the parked pack.

    The pack is materialised TWICE, and both are load-bearing. `AS_PRODUCT` is what
    `product_gates.products()` has to discover — the whole reason a suite asks for this root.
    `PARKED_REL` is where `governance/precedents.yaml` cites it, and those citations have to resolve
    against this root as well; without it `precedents.load()` reports broken citations here and
    reads as a store that has gone stale.
    """
    root = os.path.join(tmp, "repo")
    for top in ("products", "governance"):
        shutil.copytree(os.path.join(REPO, top), os.path.join(root, top), ignore=_SKIP)
    for rel in (AS_PRODUCT, PARKED_REL):
        shutil.copytree(PARKED, os.path.join(root, *rel.split("/")), ignore=_SKIP)
    return root


def materialised_root():
    """The same root for every caller in a process — the copy is ~6 MB and three suites want it."""
    global _ROOT
    if _ROOT is None:
        tmp = tempfile.mkdtemp(prefix="rwdp-fixture-pack-")
        atexit.register(shutil.rmtree, tmp, ignore_errors=True)
        _ROOT = repo_with_fixture_pack(tmp)
    return _ROOT
