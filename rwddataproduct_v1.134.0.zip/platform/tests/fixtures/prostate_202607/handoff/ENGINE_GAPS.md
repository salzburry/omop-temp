# Engine gaps — approved requirements the build does not yet meet

Empty by design. 202607 has no `config/`, no engine binding and no build, so there is nothing yet that
can fall short of a requirement. Gaps are recorded here as the contract meets an implementation.

A gap is not a decision: a decision means the requirement is unsettled (`DECISIONS.md`), a gap means the
requirement is settled and the build has not caught up.

| Gap | What is not met |
|---|---|
