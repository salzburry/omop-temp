# Specification QC findings — defects in RWB's document

Found while drafting contract records from the 202607 specification. These are defects in the
specification itself, distinct from `DECISIONS.md`, which holds open questions.

**A workaround is not a correction.** Reading `4/31/2026` as `2026-04-30` to unblock a build leaves the
finding open, because re-extracting the source workbook reintroduces it.

Findings caused by the DELIVERY FORMAT rather than by RWB are marked `format`; they close by extracting
the approved workbook, with no RWB round-trip.

| ID | Where | What | Impact | Kind | Status |
|---|---|---|---|---|---|
| SQ-01 | `study_period:13` | `MAXINDEX = 4/31/2026` — April has 30 days, so this is not a real date | The study window's upper bound is unusable as written; every cohort's index range depends on it | RWB | **open** |
| SQ-02 | `study_period:13` note | The note explains the data lag of **"The SCLC panoramic dataset we license"** — SCLC, inside a *prostate* specification | Either the 60-day lag figure does not apply to this feed, or the note is stale. The deterministic scan did not catch this: `FOREIGN_TABLE` matches table stems (`t_*`, `cota_*`), not a tumour named in prose | RWB | **open** |
| SQ-03 | `clinical:17` (each `LAB*` flag row) | The presence rule ends mid-sentence at "Otherwise," — the non-Present branch is cut off | The flag declares three values (`Present` / `Unknown` / `Missing`) but only `Present` is ever assigned by the text | format | **open** |
| SQ-04 | `clinical:46` | `LABLYMDT` is a DATE variable, but its definition is the VALUE rule copied verbatim ("Report testresultcleaned ... take the highest value"). Every other `LAB*DT` row reads "Date associated with `<analyte>V`" | The lymphocyte date rule is unstated; a literal read would emit a value where a date belongs | RWB | **open** |
| SQ-05 | `study_period:30` | The biomarker-date rule is cut off mid-sentence at "If any of the date of specimen received, or date of result is missing," | The missing-date branch is unstated for every biomarker variable | format | **open** |
| SQ-06 | `study_population:12` | COHORTU's mHSPC branch assigns `'Treated mHSPC'` where the parallel mCRPC branch assigns `'Untreated ...'` for the same shape of condition; and only 2 of the 4 declared values are ever assigned | The treated/untreated split is unusable as written | RWB | **open** |
| SQ-07 | `demographics:7` | DTHFUFL's formula `DTHDT-FUED <= 120` contradicts its own note and `study_period:32`, which both say death 120 days **or more before** the end of follow-up | As written the flag fires for nearly every patient | RWB | **open** |
| SQ-08 | `demographics:14` | REGION1's rule has no terminal `else` for a state outside the five lists, and no academic branch at all despite the row's note saying academic centres map to Unknown — `Unknown` is never assigned | Unmapped states fall through to no value; the academic rule is unimplementable as written | RWB | **open** |
| SQ-09 | `demographics:10` | AGEGR1's rule reads `If 0<=AGE<=18 then AGEGR1='0-18', etc` — the remaining bands are replaced by "etc" | Recoverable: row 11's numeric map states all seven bands, so the requirement is complete across the pair | RWB | **open** |
| SQ-10 | `clinical:9` | `INITYR` is defined as `Year(INITYR)` — the variable defined in terms of itself; every sibling row uses `Year(<the date>)`, so the intent is `Year(INIT)` | Self-referential as written | RWB | **open** |
| SQ-11 | `clinical:14` | `TINTCRPCHSPC` divides by **30.4376**; rows 12, 13 and `study_period:25` all use **30.4375** | A single-digit typo that silently shifts one interval variable | RWB | **open** |
| SQ-12 | `clinical:76` | Row 76 carries the variable name `HRR_INDEX_TEST` — already used by row 72 — while its definition reads "Test type associated with **BRCA**" and row 77 names the numeric partner `BRCA_INDEX_TESTN` | Duplicate variable name; one of the two test-type variables has no distinct id | RWB | **open** |
| SQ-13 | `clinical:91-93` vs `clinical:94-96` | `FUED`, `DTHDT` and `DTHFL` are each defined TWICE in the same tab, with different rules — 91 uses six date sources and a death-capping rule, 94 uses two | Two contradictory follow-up-end definitions; every duration and time-to-event variable inherits the choice | RWB | **open** |
| SQ-14 | `clinical:65` | The Gleason category list is cut off mid-item at `"7 (when breakdown ` | The category set is incomplete | format | **open** |
| SQ-15 | `treatment:29`, `:34`, `:35` | Three naming defects in the LOT-category block: row 29 refers to `LOT1CAT_MCSPC` (should be MCRPC), row 34 to `LOT1CAT_HSPC` (should be MHSPC), and row 35 is named `LOT4CATN` where every sibling carries the `_MCRPC` suffix | Cross-references that resolve to nothing; one variable name inconsistent with its family | RWB | **open** |
| SQ-16 | `treatment:41` | The variable is named `PRIOR+ABIRATERONE` — a plus sign where every sibling uses an underscore | Not a legal column name | RWB | **open** |
| SQ-17 | `treatment:24` | The LOT treatment-category list is cut off at "Note: categories will b" | Twelve LOT*CAT variables have no category set | format | **open** |
| SQ-18 | `outcomes:13` | TTD's guard reads `DT_BEFORE_FUED`; the variable is `DTH_BEFORE_FUED` and every sibling row spells it correctly | A guard referencing a non-existent variable | RWB | **open** |
| SQ-19 | `outcomes:14`, `:15`, `:20`, `:21` | Bracketed placeholders — `[Overall cohort]`, `[Overall mHSPC cohort]`, `[1L cohort]` — stand where the C1/C2 formulas belong | Four outcome variables have no rule for the overall cohorts | RWB | **open** |
| SQ-20 | `outcomes:19` | The row's variable is `PFS` but its rule assigns `RWPFS` | The variable named is not the variable defined | RWB | **open** |

