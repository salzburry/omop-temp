# Data Prep (3.Data Prep)

_Source: the "3.Data Prep" tab of the Prostate Panoramic mHSPC/mCRPC data-specification workbook. Recorded verbatim — source typos preserved._

## Table 1 — Sections A & B

Section A ("Population Subset") is a small data-source block: column A holds the red header "Data source" (row 3) with its value "Flatiron Health" (row 4); the wide merged cell holds the population subset name "Prostate Panoramic Dataset". Read as: Data source = Flatiron Health; Population Subset = Prostate Panoramic Dataset.

| Row | Section | Variable | Label | Definition | Additional Notes | QC Reviewed (Initials + Date) |
|---|---|---|---|---|---|---|
| 3 | Section A: Population Subset | Data source |  | Prostate Panoramic Dataset |  |  |
| 4 | Section A: Population Subset | Flatiron Health |  |  |  |  |
| 11 | Section B: Define Study Time Periods | DATAV | Data Version | 20260630 |  |  |
| 12 | Section B: Define Study Time Periods | RAWRWD | RWD Data Source | Flatiron Prostate Panoramic Dataset |  |  |
| 13 | Section B: Define Study Time Periods | MAXINDEX | Max Potential Index Date within Cohort | 4/31/2026 | NOT per patient, but for the whole cohort - all patients will have the same date in the same cohort. This is the end of the data coverage period for this data cut. The SCLC panoramic dataset we license has a 60-day lag. |  |
| 14 | Section B: Define Study Time Periods | MININDEX | Min Potential Index Date within Cohort | 01-Jan-11 | NOT per patient, but for the whole cohort - all patients will have the same date in the same cohort. This is the start of the data coverage period for this data cut. |  |
| 15 | Section B: Define Study Time Periods | STUDY_PD | Full study period | Earliest available data through study_end date [MAXINDEX] | Earliest available data accounting for full patient clinical history |  |
| 16 | Section B: Define Study Time Periods | INDEX | Index date | If COHORTN = 1 ('Overall mHSPC') then INDEX = max(MetastaticDiagnosisDate and HSPCDate),<br><br>If COHORTN = 2 ('Overall mCRPC') then INDEX = max(MetastaticDiagnosisDate and mCRPCDate),<br><br>If COHORTN=3 ('L1+ treated mHSPC') then INDEX = LOT1SD_MHSPC,<br><br>If COHORTN=4 ('L1+ treated mCRPC') then INDEX = LOT1SD_MCRPC,<br><br>If COHORTN=5 ('L2+ treated mCRPC') then INDEX = LOT2SD_MCRPC,<br><br>If COHORTN=6 ('L3+ treated mCRPC') then INDEX = LOT3SD_MCRPC,<br><br>If COHORTN=7 ('L4+ treated mCRPC') then INDEX = LOT4SD_MCRPC | COHORT var defined in 4.StudyPop. |  |
| 17 | Section B: Define Study Time Periods | FU | Follow-up period | INDEX+1 to end of each patient's data availability | Note: need to define end of follow-up utilizing death, last structured activity, etc. |  |
| 18 | Section B: Define Study Time Periods | PRE_INT | Any time prior index date/including index date | Earliest available data through INDEX, inclusive. | Note: patients may have differential available data prior to the index date. |  |
| 19 | Section B: Define Study Time Periods | NEW_LOT_N | Reassigned LOT number indexed to mCRPC | For each patient, assign the earliest LOT for mCRPC and each subsequent LOT as the next number in that setting. | Note: some patients may not have changed line numbers if they have only been treated in the mCRPC or mHSPC setting |  |
| 20 | Section B: Define Study Time Periods | LOT_ECOG | ECOG assessment period | [INDEX - 30 through INDEX + 7] |  |  |

## Table 2 — Section C: Source Data Preparation

> Instruction: Section C should ONLY be used to document decisions to the source data before the analytic file build. If decisions apply to a variable in the analytic file, document in the appropriate variable definition.

| Row | # | Source Table/Variable | Situation Requiring Resolution | Action | Reasoning / Comments | QC Reviewed (Initials + Date) |
|---|---|---|---|---|---|---|
| 25 | 1 | Days to months conversion | Assuming 30.4375 day per month | 3 months = 91 days, 6 months = 183 days, 9 months = 274 days, 12 months = 365 days |  |  |
| 26 | 2 | Dates (all tables) | There are 2 versions of each date, one version is in date timestamp format and the other version is a sas date. For example, diagnosisdate and diagnosisdate_sasdt | Programmer should pick one set of date variables consistently, since each type needs to be handled differently in the SAS programs |  |  |
| 27 | 3 | t_&cohort_lineoftherapy_&date | Check that there are distinct patientid, linenumber, ismaintenancetherapy | If there are duplicates need to alert Flatiron and perhaps manually fix | This was an issue in past |  |
| 28 | 4 | rwPFS | Projects have not used a consistent exclusion window for rwPFS analyses | Per 6 Feb TC with Tirza, Use 14 days exclusion window for every tumor type |  |  |
| 29 | 5 | Labs | For the labs, if there is more than one result on the date closest to index date, which value should we keep – the lowest or the highest? | Per 6 Feb 2025 email from Linda:<br>ALT, AST, ALP, lymphocytes, bilirubin - highest<br>Albumin, neutrophil, platelet, hemoglobin, serum creatinine - lowest |  |  |
| 30 | 6 | Biomarker tests | Biomarker dates to use | Biomarker status will be defined as biomarker tests conducted on or any time prior to index date. Biomarker test date is defined as the later date of specimen received, or date of result in the biomarker tables for a given test. If any of the date of specimen received, or date of result is missing, only the available dates will be used to define the biomarker test date. No imputation will be conducted to missing date variables. Method aligned with the Flatiron article at the time: https://flatironlifesciences.zendesk.com/hc/en-us/articles/360044098571-Tutorial-Assigning-Patient-Level-Biomarker-Status |  |  |
| 31 | 7 | PFS date/death date | X patients had death date before progression date | This is expected in real-world data as accurate death date is not known since "a small number of patient records may include structured activity (e.g. visit records, non-canceled medication orders) after the DateofDeath value. This is typically a data entry error (e.g. a practice may schedule a treatment that the patient is not able to receive or the date of death is incorrect)." No action - treat as limitation.<br><br>https://flatironlifesciences.zendesk.com/hc/en-us/articles/360041924812-Enhanced-Mortality-V2-0-V2-1-Overview-and-Data-Considerations |  |  |
| 32 | 8 | Maximum visit date after death | X patients have visit date greater than death date | Patients with preliminary death date is 120 days or more before the preliminary end of follow-up will be flagged (DTHFUFL). There is a believe that there is something wrong with the data for these patients, i.e. flag these patients and the SAP may wish to exclude from the analysis. |  |  |

## Fidelity notes

- Row numbering anchored to ground truth: the Excel name box reads "A18" = "PRE_INT", fixing PRE_INT at row 18. Working back, the Section B "Variable/Label" header is row 10 and DATAV=11 … FU=17, then PRE_INT=18, NEW_LOT_N=19, LOT_ECOG=20 (consecutive, no gaps). The source rows are misaligned, which initially made DATAV look like row 10; the name-box anchor resolves it to row 11.
- The QC Reviewed (Initials + Date) column is present but empty for every row in both tables.
- Preserved likely source typos/oddities:
 - Row 13 (MAXINDEX) Definition: "4/31/2026" (April has no 31st).
 - Row 13 (MAXINDEX) Additional Notes: "The SCLC panoramic dataset we license…" (says SCLC in a prostate-cancer study; recorded verbatim).
 - Row 16 (INDEX) Definition clause 2: "…and mCRPCDate)" (other tabs use "CRPCDate"); also inconsistent spacing around "=" ("COHORTN = 1"/"= 2" vs "COHORTN=3" … "=7"), recorded as seen.
 - Row 32 (item 8) Action: "There is a believe that there is something wrong…" (believe vs belief), recorded verbatim.
- Row 26 (item 2): "diagnosisdate_sasdt" — the underscore is unclear in the source but read as an underscore consistent with the "_sasdt" SAS-date naming convention; slight uncertainty (could look like a space).
- Row 29 (item 5) uses an en-dash in "which value should we keep – the lowest or the highest?"; the lab lists use hyphens ("… - highest", "… - lowest"). Recorded as seen.
- URLs in rows 30 and 31 render with hyphens (e.g. "360044098571-Tutorial-…", "360041924812-Enhanced-Mortality-V2-0-V2-1-…"); recorded as hyphens.
- Section A does not follow the Variable/Label/Definition schema; it was mapped by grid position (see the note above the table).
- A generic instruction band sits in row 1 ("Instruction: Delete any examples in grey italic text…"), not part of the requested tables; noted here only.
