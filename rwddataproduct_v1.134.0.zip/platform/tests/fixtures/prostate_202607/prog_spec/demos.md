# Demographics (5A. Demos)

_Source: the "5A. Demos" tab of the Prostate Panoramic mHSPC/mCRPC data-specification workbook. Recorded verbatim — source typos preserved._

> [top band, cut off] "…es for all prostate patients - output one analytic dataset from file t_allprostate_pats_2026j30 to be used for other studies"
> _Note to Programmer: Do not use the naming convention 'TimePeriod_Variable', no prefix_

_Note: in this tab the Label and Values columns (sheet columns C–D) are hidden; the content columns are Variable, Definition, Code Lists Group, Additional Notes, QC Reviewed. The QC Reviewed column had no entries in the source._

| Row | Time Period | Variable | Definition | Code Lists Group | Additional Notes | QC Reviewed (Initials + Date) |
|---|---|---|---|---|---|---|
| 6 | N/A | ID3MOSFU | If MAXINDEX minus INDEXDT is greater or equal to 91, then = 1; else 0. | N/A | MAXINDEX defined in Tab3. | |
| 7 | FU | DTHFUFL | If DTHDT-FUED <=120 days then DTHFUFL=1; else 0. | N/A | If preliminary death date is 120 days or more before the preliminary end of follow-up - there is a believe that there is something wrong with the data, i.e. flag these patients and do not use them in as the SAP may wish to exclude from the analysis.<br><br>Very limited/no data should be recorded after patients death, but since we know that death date in RWD is not 100% accurate, we do allow some gap, i.e., 120 days between death and last record.<br><br>Only very small proportion of people will be excluded flagged<br><br>Per 13 March 2025 TC with epidemiologists (Tirza and Huifen), this flag will NOT be used to exclude patients from outcomes analyses (e.g., OS, rwPFS) at this time | |
| 8 | PRE_INT | Processing: variables in demographics | Keep these variables when creating this analytic dataset | N/A | All mCRPC and mHSPC patients are in this patient level table | |
| 9 | INDEX | AGE | YEAR(INDEXDT) - birthyear | N/A | | |
| 10 | INDEX | AGEGR1 | If 0<=AGE<=18 then AGEGR1='0-18', etc | | | |
| 11 | INDEX | AGEGR1N | Numeric code for AGEGR1:<br>1=0-18<br>2=19-34<br>3=35-49<br>4=50-64<br>5=65-74<br>6=75-84<br>7=>=85 | | | |
| 12 | PRE_INT | STAGE | if groupstage from enhanced_metprostate starts with 'IV' then 'IV'<br>else if groupstage starts with 'III' then 'III'<br>else if groupstage starts with 'II' then 'II'<br>else if groupstage starts with 'I' then 'I'<br>else if groupstage starts '0' then '0'<br>else 'Unknown/not documented' | N/A | Only one variable available at initial diagnosis, i.e. will be the same for all index dates | |
| 13 | PRE_INT | STAGEN | Numeric of STAGE | N/A | Only one variable available at initial diagnosis, i.e. will be the same for all index dates | |
| 14 | PRE_INT | REGION1 | STATE from demographics table mapped to REGION<br><br>'if STATE in ('ME' 'VT' 'NH' 'MA' 'RI' 'CT' 'NY' 'PA' 'NJ') then ='Northeast';<br>else if STATE in ('ND' 'SD' 'NE' 'KS' 'MN' 'IA' 'MO' 'WI' 'IL' 'MI' 'IN' 'OH') then ='Midwest';<br>else if STATE in ('TX' 'OK' 'AR' 'LA' 'KY' 'TN' 'MS' 'AL' 'MD' 'DE' 'DC' 'VA' 'WV' 'NC' 'SC' 'GA' 'FL') then ='South';<br>else if STATE in ('CA' 'WA' 'OR' 'NV' 'AZ' 'UT' 'NM' 'CO' 'ID' 'MT' 'WY' 'HI' 'AK') then ='West';<br>else if STATE in ('PR') then ='Other region';<br>else if STATE is missing then ='Missing' | N/A | Use state as reported on the demographics table. Academic centers all set to unknown. | |
| 15 | PRE_INT | REGION1N | Numeric of REGION1 | N/A | | |
| 16 | PRE_INT | RACE | Use RACE variable as in demographics table; recode "Hispanic or Latino" into the 'Other Race'. | N/A | Use race as reported on the demographics table. A separate character values isn't needed since we have RACE from demographics tables | |
| 17 | PRE_INT | RACEN | Numeric of RACE | N/A | Use race as reported on the demographics table. A separate character values isn't needed since we have RACE from demographics tables | |
| 18 | PRE_INT | ETH | If (RACE="Hispanic or Latino" or ETHNICITY="Hispanic or Latino") then ETH ="Hispanic or Latino";<br>else if ETHNICITY="Not Hispanic or Latino" then ETH= "Not Hispanic or Latino"<br>else if ETHNICITY is missing then ="Unknown/Missing"; | N/A | ETHNICITY variable as in flatiron in table demographics;<br>Use RACE as defined in the spec | |
| 19 | PRE_INT | ETHN | Numeric of ETH | | | |
| 20 | PRE_INT/FU | PRACTIC | If patient has any record where PRACTICETYPE is 'ACADEMIC' and patient has no records where PRACTICETYPE is 'COMMUNITY' then ='Academic only';<br><br>else if patient has any record where PRACTICETYPE is 'COMMUNITY' and patient has no records where PRACTICETYPE is 'ACADEMIC' then='Community only';<br><br>else then = 'Both academic and community'; | | | |
| 21 | PRE_INT/FU | PRACTICN | Numeric of PRACTICE | N/A | Practice type Indicates whether the primary treating oncologist's practice is classified as community or academic. Patient's practice type is classified as "Both" if their primary treating oncologists are in both community and academic practices | |
| 22 | PRE_INT/FU | SES | Value from socialdeterminantsofhealth, merge onto patient level data | | | |

## Fidelity notes
- The top banner text is cut off in the source (begins "…es for all prostate patients"). Likely reads "Demographic variables for all prostate patients…" but the leading words are not present.
- Label (col C) and Values (col D) are hidden columns in this tab and are not included.
- QC Reviewed (Initials + Date) column header is present at the far right but contained no entries.
- Row 8 is a processing/instruction row rather than an output variable.
