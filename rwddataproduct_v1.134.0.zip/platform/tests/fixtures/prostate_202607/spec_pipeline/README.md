# `spec_pipeline/` — deterministic spec processing, prostate 202607

The clean-room run of part 1 of the governed workflow: the approved RWB specification in, structured
evidence out. **No AI touches anything here** — it is scripts end to end.

```bash
platform/tools/run_spec_pipeline.sh platform/tests/fixtures/prostate_202607
platform/tools/run_spec_pipeline.sh platform/tests/fixtures/prostate_202607 --check    # CI: fail if stale
platform/tools/run_spec_pipeline.sh platform/tests/fixtures/prostate_202607 --strict   # Gate 2 coverage
```

## What you touch, and what is generated

| | |
|---|---|
| `../Program Specification/` | **the input.** In production the approved `.xlsx`, dropped in as delivered. Today the six spec tabs, because the workbook cannot enter the repo — the pipeline reads either. |
| `pipeline.conf` | **two values**: `TUMOR` and `SPEC_SOURCE`. Sheet→domain mapping and the requirement-bearing sheet list are shared, in `governance/spec_sheet_map.yaml`. |
| `out/` | **generated. Never hand-edit.** A stale `out/` is evidence of nothing, which is what `--check` guards. |

| Artifact | What it is |
|---|---|
| `out/extracted.json` | every spec row with original Excel coordinates, a content hash, and its columns resolved **by header name** |
| `out/SPEC_FINDINGS.txt` | deterministic defect scan of **RWB's document**, ranked HIGH / INFO |
| `out/lint.json` | the same findings plus `applicability`, so "zero findings" can be told apart from "never looked" |
| `out/COVERAGE.md` | every spec item and its disposition — the Gate 2 completeness evidence |
| `out/SCAFFOLDED_RECORDS.md` | contract-ready records with every judgment field `TODO` |
| `out/scaffold.json` | the same, machine-readable |

## Current state

**200 spec items — 199 undispositioned, 1 context.** That is the correct reading for a product with no
contract yet: nothing has been mapped because nothing has been written. `--strict` exits 1 until every
item is mapped, dispositioned or excluded.

The defect scan finds **43 issues in the spec itself — 20 HIGH**: 1 impossible date, 1 foreign (colorectal)
table stem, 10 truncated cells, 8 unbalanced quotes, plus 23 INFO. These are defects in RWB's document,
not in the pipeline; each becomes a `SPEC_QC_FINDINGS` entry (a defect RWB fixes) or a `DECISIONS` entry
(a question only RWB can answer). That classification is a human call.

## Where part 1 stops

The scaffold is **not** a contract. `source`, `derivation`, `window`, `acceptance` and the rest are
judgment, and the shared contract lint rejects an `approved` record that still holds a `TODO` — so the
work cannot be skipped by flipping a status.

## Notes on this folder

The pack holds exactly one copy of the extraction input, `Program Specification/`, and that is the
one `source_refs.yaml` registers as `spec_tabs`. There is no second copy: two copies of the
input is the drift this pipeline exists to prevent, and a reader cannot tell which one a record was
drafted from.

Vendor-derived material — a delivered data dictionary, a Hive inventory, profiler output — is not
kept in the repository at all. `platform/tools/repo_hygiene.py` is what enforces that; the physical
table names this pack's config uses are recorded in the config, which is where a reviewer checks them.
