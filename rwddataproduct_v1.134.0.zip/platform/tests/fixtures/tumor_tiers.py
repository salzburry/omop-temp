"""Three synthetic tumour specifications, small to high complexity, each seeded with traps.

The Q3 fixture (`adversarial_spec.py`) proved the DETECTORS one attack class at a time on one
workbook. This builder asks the scaling question: as a specification grows from a six-variable
single-sheet program to a five-sheet line-of-therapy program, does every planted hazard still
announce itself, and do the CLEAN rows still come through? Three tumours, three tiers:

    bladder   SMALL   1 requirement sheet,  ~6 variables, 3 traps (content-level only)
    rcc       MEDIUM  3 sheets, ~14 variables, 5 traps (content + sheet structure)
    mm        HIGH    5 sheets, ~24 variables, 8 traps (content + structure + header capture)

Every trap uses a phrasing the Q3 suite already proved triggers its detector — this fixture
measures coverage at scale, not new detector classes. Synthetic throughout: no vendor material,
no delivered data, and none of these may ever be registered as any pack's specification.

Each TRAPS entry maps trap id -> (expectation kind, key):
    ("lint", KIND)           a spec_lint finding of that kind must appear
    ("structure", key)       workbook_structure must report that key on the named sheet
    ("loss", VARIABLE)       the row is deleted by its attack AND the deletion is reported
    ("adopted", sheet-domain) a title row captures the MAIN header, and the 1.7 density switch
                             adopts the REAL header beneath it: every row must resolve a NAMED
                             variable AND the adopted row must still be reported for a person
                             to verify the split
"""
import os

from adversarial_spec import HEADER                    # one owner of the eight-column header

TRAPS = {
    "bladder": {
        "b1_impossible_date": ("lint", "IMPOSSIBLE_DATE"),
        "b2_duplicate_variable": ("lint", "DUPLICATE_VARIABLE"),
        "b3_blank_definition": ("lint", "EMPTY_RULE"),
    },
    "rcc": {
        "r1_hidden_row": ("structure", "hidden_rows"),
        "r2_dropdown_enumeration": ("structure", "validation_lists"),
        "r3_cross_tab_duplicate": ("lint", "DUPLICATE_VARIABLE"),
        "r4_no_terminal_else": ("lint", "NO_TERMINAL_ELSE"),
        "r5_unbalanced_parens": ("lint", "UNBALANCED"),
    },
    "mm": {
        "m1_row_swallowing_merge": ("loss", "TTNT2L"),
        "m2_formula_no_cache": ("structure", "formula_no_value"),
        "m3_hidden_superseded_column": ("structure", "shadowing_cols"),
        "m4_comment_caveat": ("structure", "comments"),
        "m5_verify_marker": ("lint", "VERIFY_MARKER"),
        "m6_prose_placeholder": ("lint", "PLACEHOLDER"),
        "m7_deferred_rule": ("lint", "DEFERRED_RULE"),
        "m8_title_row_captures_header": ("adopted", "demographics"),
    },
    # WAVE 2 — three more tumours, VARIED: every trap class below is one wave 1 did not use.
    "mel": {
        "e1_truncated_rule": ("lint", "TRUNCATED"),
        "e2_values_never_assigned": ("lint", "VALUE_COUNT"),
        "e3_impossible_date_slashed": ("lint", "IMPOSSIBLE_DATE"),
    },
    "gastric": {
        "g1_outlier_in_list": ("lint", "OUTLIER_IN_LIST"),
        "g2_constant_typo_twin": ("lint", "CONSTANT_CONFLICT"),
        "g3_short_name_cross_tab": ("lint", "DUPLICATE_VARIABLE"),
        "g4_partial_width_merge": ("structure", "merged"),
        "g5_hidden_sheet": ("structure", "sheet_state"),
        "g6_foreign_header_mid_sheet": ("structure", "header_candidates"),
    },
    "nsclc": {
        "n1_confirm_marker": ("lint", "VERIFY_MARKER"),
        "n2_algorithm_placeholder": ("lint", "PLACEHOLDER"),
        "n3_defers_to_sap": ("lint", "DEFERRED_RULE"),
        "n4_defines_nothing": ("lint", "EMPTY_RULE"),
        "n5_chain_without_else": ("lint", "NO_TERMINAL_ELSE"),
        "n6_formula_no_cache": ("structure", "formula_no_value"),
        "n7_comment_caveat": ("structure", "comments"),
        "n8_hidden_retired_row": ("structure", "hidden_rows"),
    },
}

# Control variables per tier: clean rows that MUST extract with a resolved variable — a suite
# that only checks traps would pass on an extractor that dropped everything.
CONTROLS = {
    "bladder": ("DTHDT", "DTHFL", "FUDUR2"),
    "rcc": ("AGEGR2", "NEPHRECT", "IMDCRISK"),
    "mm": ("MMDIAGDT", "SCTFL", "LOT1SD"),
    "mel": ("MELDIAGDT", "BRESLOW", "OS4"),
    "gastric": ("GDIAGDT", "HER2FL", "MSIFL"),
    "nsclc": ("NDIAGDT", "EGFRFL", "LOT1SD_N"),
}


def _bladder(wb):
    out = wb.create_sheet("6. Outcomes")
    for r in (
        HEADER,
        ["OUTCOME", "DTHDT", "Death date", "Date",
         "Earliest death date across sources", "control", "", ""],
        ["OUTCOME", "DTHFL", "Death flag", "1=Yes; 0=No",
         "1 if DTHDT populated else 0", "control", "", ""],
        # b1: the impossible calendar date, inside an otherwise finished rule.
        ["OUTCOME", "FUED2", "Follow-up end", "Date",
         "Min of death date and study end; study end frozen as of 4/31/2026", "b1", "", ""],
        # b2: OS defined twice on the same sheet with DIFFERENT censoring rules.
        ["OUTCOME", "OS", "Overall survival", "Months",
         "From index date to death; censor at last activity", "b2-first", "", ""],
        ["OUTCOME", "OS", "Overall survival", "Months",
         "From index date to death; censor at end of data availability", "b2-second", "", ""],
        # b3: the row names a requirement and defines NOTHING — no rule AND no value set
        # (EMPTY_RULE deliberately tolerates a blank rule when values are declared).
        ["OUTCOME", "TRTSETTING", "Treatment setting", None, None,
         "b3", "", ""],
        ["OUTCOME", "FUDUR2", "Follow-up duration", "Months",
         "From index date to follow-up end", "control", "", ""],
    ):
        out.append(r)


def _rcc(wb):
    pop = wb.create_sheet("4.StudyPop")
    for r in (
        HEADER,
        ["STUDY", "INCL01", "Inclusion: advanced RCC", "0/1",
         "Advanced or metastatic renal cell diagnosis on or after study start", "control", "", ""],
        ["STUDY", "INCL02", "Inclusion: age at index", "0/1",
         "Age >= 18 at index date", "control", "", ""],
        # r4: an if/else-if chain with no terminal else.
        ["STUDY", "COHORT2", "Treatment cohort", "1=IO+IO; 2=IO+TKI; 3=TKI",
         "If first regimen is dual checkpoint then 1 else if checkpoint plus TKI then 2 "
         "else if TKI alone then 3", "r4", "", ""],
    ):
        pop.append(r)

    clin = wb.create_sheet("5B. ClinChars")
    for r in (
        HEADER,
        ["BASELINE", "AGEGR2", "Age group", "1=18-64; 2=65-74; 3=75+",
         "Band age at index into 18-64, 65-74, 75+", "control", "", ""],
        ["BASELINE", "NEPHRECT", "Prior nephrectomy", "1=Yes; 0=No",
         "Any nephrectomy procedure before index date", "control", "", ""],
        # r5: an unmatched parenthesis in a rule — the class this suite's first run proved
        # SILENT (the lint promised 'quote or bracket' and counted quotes only; fixed since).
        ["BASELINE", "SARCOFL", "Sarcomatoid features", "1=Yes; 0=No; 99=Unknown",
         "If (histology contains 'sarcomatoid' and biopsydate <= index + 30 then 1 else 0",
         "r5", "", ""],
        # r1: this row is hidden by the builder — a retired rule still in the file.
        ["BASELINE", "IMDC_OLD", "IMDC risk (retired)", "1=Fav; 2=Int; 3=Poor",
         "Superseded by IMDCRISK — do not implement", "r1", "", ""],
        ["BASELINE", "IMDCRISK", "IMDC risk group", "1=Favourable; 2=Intermediate; 3=Poor",
         "IMDC criteria over labs and diagnosis timing at index", "control", "", ""],
        # r3, first half: TTD with one censoring rule here...
        ["OUTCOME", "TTD", "Time to treatment discontinuation", "Months",
         "From line start to discontinuation; censor at last activity", "r3-first", "", ""],
    ):
        clin.append(r)
    clin.row_dimensions[5].hidden = True                                   # r1 (IMDC_OLD row)

    out = wb.create_sheet("6. Outcomes")
    for r in (
        HEADER,
        # r3, second half: ...and a DIFFERENT censoring rule here.
        ["OUTCOME", "TTD", "Time to treatment discontinuation", "Months",
         "From line start to discontinuation; censor at data cutoff", "r3-second", "", ""],
        ["OUTCOME", "OS2", "Overall survival", "Months",
         "From index to death from any cause", "control", "", ""],
        # r2: the enumeration lives in a dropdown, not in any cell.
        ["OUTCOME", "PROGSRC", "Progression source", "(see dropdown)",
         "Source of the progression event used", "r2", "", ""],
    ):
        out.append(r)
    from openpyxl.worksheet.datavalidation import DataValidation
    dv = DataValidation(type="list", formula1='"Imaging,Clinical note,Both"', allow_blank=True)
    out.add_data_validation(dv)
    dv.add(out["D4"])


def _mm(wb):
    from openpyxl.comments import Comment

    # m8 lives ALONE on this sheet: the three-cell title row becomes the MAIN header (the Q3
    # fixture proved one-attack-per-seam the hard way). Since 1.7 the density switch adopts the
    # REAL header beneath it, so the trap asserts the heal: named resolution plus the report.
    demos = wb.create_sheet("5A. Demos")
    for r in (
        ["MM Program Specification", "v0.7 DRAFT", "2026-08-12", None, None, None, None, None],
        HEADER,
        ["BASELINE", "AGE2", "Age at index", "Integer",
         "Age in years at index date", "m8-victim", "", ""],
        ["BASELINE", "ISSSTAGE", "ISS stage", "1/2/3",
         "ISS stage at diagnosis from labs", "m8-victim", "", ""],
    ):
        demos.append(r)

    prep = wb.create_sheet("3.DataPrep")
    for r in (
        HEADER,
        ["STUDY", "MININDEX2", "Study start", "Date",
         "01-Jan-2016 per protocol", "control", "", ""],
        ["STUDY", "DATAV2", "Data version", "Text",
         "Vendor delivery identifier stamped on every row", "control", "", ""],
    ):
        prep.append(r)

    clin = wb.create_sheet("5B. ClinChars")
    for r in (
        HEADER,
        ["INDEX", "MMDIAGDT", "MM diagnosis date", "Date",
         "Earliest multiple myeloma diagnosis date", "control", "", ""],
        # m2: a formula with NO cached value — the cell looks empty and is not.
        ["INDEX", "DIAGTOIDX", "Days diagnosis to index", "Integer",
         "=B2-B3", "m2", "", ""],
        ["INDEX", "SCTFL", "Prior stem-cell transplant", "1=Yes; 0=No",
         "Any SCT procedure before index date", "control", "", ""],
        ["BIOMARKER", "FISH1719", "del(17p)/t(4;14) status", "1=Present; 0=Absent; 99=Unknown",
         "Any qualifying FISH result in window", "m4-anchor", "", ""],
    ):
        clin.append(r)
    # m3: a hidden column headed as a superseded Definition, LEFT of the real one.
    clin.insert_cols(5)
    clin.cell(row=1, column=5, value="Definition (superseded)")
    clin.cell(row=2, column=5, value="SUPERSEDED: any myeloma diagnosis code, first or not")
    clin.column_dimensions["E"].hidden = True
    # m4: the caveat that changes the rule lives in a comment.
    clin.cell(row=6, column=6).comment = Comment(
        "Only central-lab FISH counts. Local results are excluded.", "RWB")

    treat = wb.create_sheet("5C. TreatVars")
    for r in (
        HEADER,
        ["TREATMENT", "LOT1SD", "Line 1 start date", "Date",
         "Start date of the first line of therapy", "control", "", ""],
        # m5: the spec author's own [verify] marker, left in a finished-looking rule.
        ["TREATMENT", "LOT1CAT", "Line 1 category", "1=PI; 2=IMiD; 3=Anti-CD38; 4=Other",
         "Categorise line 1 by drug class precedence [verify] pending RWB confirmation",
         "m5", "", ""],
        # m6: prose placeholder where a rule belongs.
        ["TREATMENT", "REFRACT", "Refractory status", "1=Yes; 0=No",
         "[Apply the standard refractoriness rule] over exposure and progression dates",
         "m6", "", ""],
        ["TREATMENT", "LOTN2", "Number of lines", "Integer",
         "Count of qualifying lines of therapy", "control", "", ""],
        # m7: the rule defers to another tab by row number. It lives HERE, away from the m3
        # shadow column — on ClinChars the hidden superseded Definition column captures this
        # row's definition field and the m3 attack masks the m7 trap (one attack per seam).
        ["TREATMENT", "CYTORISK", "Cytogenetic risk", "1=High; 2=Standard; 99=Unknown",
         "See 6. Outcomes row 5 for the qualifying-window rule", "m7", "", ""],
    ):
        treat.append(r)

    out = wb.create_sheet("6. Outcomes")
    for r in (
        HEADER,
        ["OUTCOME", "OS3", "Overall survival", "Months",
         "From index to death from any cause", "control", "", ""],
        ["OUTCOME", "PFS2", "Progression-free survival", "Months",
         "From index to progression or death, whichever first", "control", "", ""],
        ["OUTCOME", "TTNT3", "Time to next treatment", "Months",
         "From line start to next line start", "control", "", ""],
        ["OUTCOME", "CYTOWIN", "Cytogenetic qualifying window", "Days",
         "Results within [-90, +30] of index qualify", "m7-target", "", ""],
        # m1 VICTIMS: real rows with real content that the full-width merge below blanks.
        ["OUTCOME", "TTNT2L", "Time to next treatment, line 2", "Months",
         "As TTNT3 anchored on line 2", "m1-victim", "", ""],
        ["OUTCOME", "PFS2L", "PFS, line 2", "Months",
         "As PFS2 anchored on line 2", "m1-victim", "", ""],
    ):
        out.append(r)
    # m1: a full-width merge three rows tall — the banner shape that swallows whole rows.
    out.merge_cells(start_row=6, start_column=1, end_row=8, end_column=8)
    out.cell(row=6, column=1,
             value="SECTION: line-2 sensitivity analyses — TTNT and PFS re-anchored on line 2")


def _mel(wb):
    out = wb.create_sheet("6. Outcomes")
    for r in (
        HEADER,
        ["INDEX", "MELDIAGDT", "Melanoma diagnosis date", "Date",
         "Earliest cutaneous melanoma diagnosis date", "control", "", ""],
        ["BASELINE", "BRESLOW", "Breslow thickness", "mm",
         "Breslow depth at diagnosis from pathology", "control", "", ""],
        # e1: the rule is cut off mid-sentence, and the capture SAYS so.
        ["BASELINE", "BRAFV600", "BRAF V600 status", "1=Mutant; 2=Wild-type; 99=Unknown",
         "If any V600E or V600K result before index then 1 (cut off at right edge)",
         "e1", "", ""],
        # e2: four QUOTED label values declared, the rule only ever assigns two. VALUE_COUNT's
        # whole vocabulary is quoted label sets (VALUES_RE/ASSIGN_RE) — numbered `1=Label`
        # forms are outside its design on purpose, so the trap speaks its language.
        ["BASELINE", "SITEGRP", "Primary site group",
         "'Cutaneous melanoma'; 'Acral lentiginous'; 'Mucosal primary'; 'Uveal primary'",
         "If primary site is skin then 'Cutaneous melanoma' else 'Acral lentiginous'",
         "e2", "", ""],
        # e3: a slashed date impossible under BOTH readings (month 31 / 31 Nov).
        ["OUTCOME", "FUEND3", "Follow-up end", "Date",
         "Min of death date and 31/11/2026", "e3", "", ""],
        ["OUTCOME", "OS4", "Overall survival", "Months",
         "From index to death from any cause", "control", "", ""],
    ):
        out.append(r)


def _gastric(wb):
    clin = wb.create_sheet("5B. ClinChars")
    for r in (
        HEADER,
        ["INDEX", "GDIAGDT", "Gastric cancer diagnosis date", "Date",
         "Earliest gastric or GEJ diagnosis date", "control", "", ""],
        ["BASELINE", "HER2FL", "HER2 status", "1=Positive; 0=Negative; 99=Unknown",
         "Latest qualifying HER2 result on or before index", "control", "", ""],
        # g1: a find/replace landed a data value in a code list — one long token among states.
        ["BASELINE", "REGION3", "Census region",
         "Northeast states", "Region from state in ('ME', 'VT', 'NH', 'MA', "
         "'gastroesophageal_junction_tumor', 'CT', 'RI')", "g1", "", ""],
        # g2, first half: the authored months divisor...
        ["OUTCOME", "TTDMOS", "Time to discontinuation (months)", "Months",
         "Days from line start to discontinuation divided by 30.4375", "g2-first", "", ""],
        ["BASELINE", "MSIFL", "MSI status", "1=MSI-H; 0=MSS; 99=Unknown",
         "Latest MSI result on or before index", "control", "", ""],
        # g3, first half: a TWO-LETTER name (the class the duplicate check once could not see).
        ["OUTCOME", "OS", "Overall survival", "Months",
         "From index date to death; censor at last visit", "g3-first", "", ""],
    ):
        clin.append(r)
    # g4: a partial-width merge across Values..Definition — reported, nothing deleted.
    clin.merge_cells(start_row=3, start_column=4, end_row=3, end_column=5)

    out = wb.create_sheet("6. Outcomes")
    for r in (
        HEADER,
        # g2, second half: ...and the same constant with a typo in the last digit.
        ["OUTCOME", "PFSMOS", "PFS (months)", "Months",
         "Days from index to progression divided by 30.4376", "g2-second", "", ""],
        # g3, second half: the same two-letter name, a DIFFERENT censoring rule.
        ["OUTCOME", "OS", "Overall survival", "Months",
         "From index date to death; censor at data cutoff", "g3-second", "", ""],
        ["", "", "", "", "", "", "", ""],
        # g6: a SECOND table whose header does NOT repeat the first cell — since 1.7 the reader
        # adopts it (density rule), and the detector still reports it for a person to verify.
        ["Row", "Variable", "Label", "Values", "Definition", "", "", ""],
        ["1", "TTDG", "Time to discontinuation (gastric)", "Months",
         "From line start to discontinuation", "g6-victim", "", ""],
    ):
        out.append(r)

    # g5: a whole requirement sheet somebody hid.
    tv = wb.create_sheet("5C. TreatVars")
    for r in (
        HEADER,
        ["TREATMENT", "LOT1SD_G", "Line 1 start date", "Date",
         "Start date of the first line of therapy", "g5-carrier", "", ""],
    ):
        tv.append(r)
    tv.sheet_state = "hidden"


def _nsclc(wb):
    from openpyxl.comments import Comment

    clin = wb.create_sheet("5B. ClinChars")
    for r in (
        HEADER,
        ["INDEX", "NDIAGDT", "NSCLC diagnosis date", "Date",
         "Earliest advanced NSCLC diagnosis date", "control", "", ""],
        ["BASELINE", "EGFRFL", "EGFR mutation status", "1=Mutant; 2=Wild-type; 99=Unknown",
         "Latest qualifying EGFR result on or before index", "n7-anchor", "", ""],
        # n6: a formula with no cached value — the cell looks empty and is not.
        ["BASELINE", "DIAGTOIDX2", "Days diagnosis to index", "Integer",
         "=B2-B3", "n6", "", ""],
        # n8: this row is hidden — a retired rule still in the file.
        ["BASELINE", "PDL1_OLD", "PD-L1 (retired assay)", "Percent",
         "Superseded by PDL1TPS — do not implement", "n8", "", ""],
        ["BASELINE", "PDL1TPS", "PD-L1 TPS", "Percent",
         "Latest tumour proportion score on or before index", "control", "", ""],
    ):
        clin.append(r)
    clin.row_dimensions[5].hidden = True                                   # n8 (PDL1_OLD row)
    # n7: the caveat that changes the rule lives in a comment.
    clin.cell(row=3, column=6).comment = Comment(
        "Tissue results only. Liquid-biopsy EGFR calls are excluded.", "RWB")

    treat = wb.create_sheet("5C. TreatVars")
    for r in (
        HEADER,
        ["TREATMENT", "LOT1SD_N", "Line 1 start date", "Date",
         "Start date of the first line of therapy", "control", "", ""],
        # n1: the spec author's own confirm marker, this time as prose.
        ["TREATMENT", "LOT1CAT_N", "Line 1 category", "1=IO; 2=Chemo; 3=TKI; 4=Other",
         "Categorise line 1 by drug class precedence — confirm with RWB before coding",
         "n1", "", ""],
        # n2: prose in place of a rule.
        ["TREATMENT", "IOELIG", "IO eligibility", "1=Yes; 0=No",
         "[Apply the standard PD-L1 scoring rule] over assays in the window", "n2", "", ""],
        # n5: an if/else-if chain with no terminal else.
        ["TREATMENT", "THERGRP", "Therapy group", "1=IO mono; 2=IO+chemo; 3=Chemo",
         "If regimen is single-agent checkpoint then 1 else if checkpoint plus platinum "
         "then 2 else if platinum doublet alone then 3", "n5", "", ""],
    ):
        treat.append(r)

    out = wb.create_sheet("6. Outcomes")
    for r in (
        HEADER,
        ["OUTCOME", "OS5", "Overall survival", "Months",
         "From index to death from any cause", "control", "", ""],
        # n3: the whole rule is a pointer at another document.
        ["OUTCOME", "RWPFS2", "Real-world PFS", "Months",
         "As per SAP section 4.2", "n3", "", ""],
        # n4: names a requirement and defines NOTHING — no rule, no value set.
        ["OUTCOME", "TTNT4", "Time to next treatment", None, None, "n4", "", ""],
    ):
        out.append(r)


_BUILDERS = {"bladder": _bladder, "rcc": _rcc, "mm": _mm,
             "mel": _mel, "gastric": _gastric, "nsclc": _nsclc}


def build(slug, path):
    """Write one tier's workbook. Structural attacks are applied inside the per-tumour builder,
    after the cell values, because a merge/hide/validation is a sheet property, not a value."""
    import openpyxl
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    _BUILDERS[slug](wb)
    wb.save(path)
    return path


def main(argv=None):
    import sys
    out = (argv or sys.argv[1:] or ["."])[0]
    for slug in _BUILDERS:
        p = build(slug, os.path.join(out, f"adversarial_{slug}.xlsx"))
        print(f"built {p} ({len(TRAPS[slug])} traps)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
