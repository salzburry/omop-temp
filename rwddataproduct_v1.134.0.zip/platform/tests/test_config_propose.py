"""What stands behind a config block, said out loud, so a scaffold cannot be shown as generated.

The failure this guards is not a crash. A scaffold pack's YAML lints clean, composes, and looks
identical before and after a drafting session — so "the workbook produced this" and "somebody
inferred this and nothing has contradicted it" are the same artifact to a reader. Four properties
keep the report honest:

  * UNSUPPORTED IS THE DEFAULT. A block nothing claims is unsupported, and a pack with no contract
    is entirely unsupported. Any bug that lets a block drift toward `confirmed` flatters exactly
    the pack that most needs the truth.
  * `confirmed` IS NOT APPROVAL. It means the workbook reached the block. Gate 4 decides values.
  * THE BLOCK SET IS THE BINDER'S. A private walk of `variables/*.yaml` would eventually disagree
    with `contract_binding`, and the disagreement would be silent.
  * RECORDS BINDING NOTHING ARE REPORTED. A block-keyed report can show 100% confirmed over a
    config covering a third of the specification.

Run: python3 platform/tests/test_config_propose.py  (or pytest).
"""
import ast
import os
import shutil
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
TOOLS = FRAMEWORK / "tools"
REPO = FRAMEWORK.parent
sys.path.insert(0, str(TOOLS))

import config_propose as cp      # noqa: E402
import contract_binding as cb    # noqa: E402


def test_it_writes_nothing():
    """A provenance report that can write is one that can be pointed at its own conclusion."""
    tree = ast.parse((TOOLS / "config_propose.py").read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = getattr(node.func, "id", "") or getattr(node.func, "attr", "")
        assert name not in ("safe_dump", "dump", "mkdir", "makedirs", "write_text", "writelines",
                            "remove", "rename", "rmtree"), f"{name}() in a read-only report"
        if name == "open":
            mode = ""
            if len(node.args) > 1 and isinstance(node.args[1], ast.Constant):
                mode = str(node.args[1].value)
            assert not (set(mode) & set("wax+")), f"open(mode={mode!r}) writes"


def test_a_pack_with_no_contract_is_entirely_unsupported():
    """mCRC: 26 governed blocks, no FUNCTIONAL_CONTRACT.md, every value inferred from published
    practice. If this ever reports a confirmed block, the report has stopped reading the pack."""
    d = cp.report("products/oncology/mcrc/202606")
    assert d["counts"][cp.UNSUPPORTED] == len(d["blocks"]) > 0, d["counts"]
    assert d["counts"][cp.CONFIRMED] == 0
    text = cp.render("products/oncology/mcrc/202606")
    assert "There is no contract" in text, "the headline finding is not stated"
    assert "may be shown as" in text and "generated from a workbook" in text


def test_confirmed_never_reads_as_approved():
    """The word a screenshot gets taken of. `confirmed` must carry its own limit everywhere it is
    defined, or it will be quoted as a Gate 4 outcome."""
    assert "NOT an approval" in cp.MEANING[cp.CONFIRMED]
    text = cp.render("products/oncology/prostate/202606")
    assert "approves nothing" in text
    for banned in ("approved by", "human_confirmed", "passed_live", "sign-off complete"):
        assert banned not in text.lower(), f"the report asserts {banned!r}"


def test_the_block_set_comes_from_the_binder():
    """The same set `contract_binding` holds a contract to. A second walk of the YAML would drift,
    and a block this called unsupported would stop meaning "the binder says nothing claims it"."""
    pack = "products/oncology/prostate/202606"
    product = os.path.join(str(REPO), pack)
    expected = sorted(cb.governed_blocks(product, cb.pack_yaml(product)))
    assert [r["block"] for r in cp.classify(pack)] == expected
    assert expected, "no governed blocks — this test would be vacuous"


def test_a_bound_block_whose_records_are_all_undecided_is_unresolved():
    """Bound to a QUESTION is not bound to an answer. prostate's `practice_map` is claimed only by
    PRACTIC/PRACTICN, both `requirement: decision_required` — it must not count as confirmed."""
    rows = {r["block"]: r for r in cp.classify("products/oncology/prostate/202606")}
    pm = rows.get("variables/demographics.yaml#/practice_map")
    assert pm, sorted(rows)
    assert pm["state"] == cp.UNRESOLVED, pm
    assert "decision_required" in pm["why"], pm["why"]
    assert pm["records"], "an unresolved block must still name who binds it"


def test_a_live_pack_shows_every_class_it_has_and_the_counts_reconcile():
    """The counts are the summary a reader quotes; they must add up to the blocks."""
    d = cp.report("products/oncology/prostate/202606")
    assert sum(d["counts"].values()) == len(d["blocks"])
    assert d["counts"][cp.CONFIRMED] > 0 and d["counts"][cp.UNRESOLVED] > 0, d["counts"]
    assert set(d["counts"]) == set(cp.ORDER)


def test_records_binding_no_block_are_reported():
    """The other direction, which a block-keyed report drops silently. prostate has requirements
    nothing implements; omitting them lets a config covering part of the spec look complete."""
    d = cp.report("products/oncology/prostate/202606")
    assert d["records_binding_nothing"], "expected unimplemented requirements on this pack"
    text = cp.render("products/oncology/prostate/202606")
    assert "bind no config block" in text
    assert d["records_binding_nothing"][0] in text


def test_a_shared_block_is_reported_as_a_blast_radius_not_as_a_defect():
    """AN ADVERSARIAL PACK FOUND THIS. Two records bound one `age_bands` block with contradictory
    bandings — 18-64/65-74/75+ against 18-49/50-69/70+ — and nothing anywhere said a word:
    `contract_binding.check` returned no finding naming the block, and this tool called it
    `confirmed`. One block holds one rule, so one of those records is silently not implemented.

    It is NOT reported as a defect, and that is deliberate: 30 of prostate's 38 blocks are shared
    and `lab_values` answers to 30 requirements, so a finding keyed on sharing would fire on almost
    every block of every real pack — the "everyone learns to ignore it" failure. Judging which of
    two derivations is contradicted needs to compare them for MEANING, which is a person's reading.
    What the tool owes the reader is the blast radius, largest first.
    """
    text = cp.render("products/oncology/prostate/202606")
    assert "## shared blocks" in text, "sharing is invisible again"
    assert "One block holds ONE rule" in text, "the consequence of sharing is not stated"
    assert "Not a defect" in text, "sharing is being presented as a finding"

    rows = cp.classify("products/oncology/prostate/202606")
    shared = [r for r in rows if len(r["records"]) > 1]
    assert len(shared) > 1, "no shared block on this pack — the test would be vacuous"
    biggest = max(shared, key=lambda r: len(r["records"]))
    assert f"| {len(biggest['records'])} |" in text, "the fan-out count is not shown"
    # ...and sharing must not have become a state, or `confirmed` stops meaning what it says.
    assert {r["state"] for r in shared} <= set(cp.ORDER)
    assert "shared" not in cp.ORDER


def test_changed_is_reachable_through_the_ordinary_cli_path():
    """AN EXTERNAL REVIEW CAUGHT THIS ONE. `classify` took a `contradictions` argument, `report`
    called it without one, and no other caller passed it — so `changed` could NEVER be produced,
    while the legend and the counts table advertised it. `changed: 0` read as "checked, none found"
    when the truth was "never checked": the same absence-reads-as-a-clean-result defect this
    repository has closed in six other tools, shipped in the tool written to expose it.

    A record stating a 180-day window over a block holding 90 must come back `changed` through
    `report()` — the path the CLI actually takes — and the row must quote the comparator's own
    finding, not the generic class text.
    """
    d = Path(tempfile.mkdtemp())
    try:
        pack = d / "products" / "oncology" / "x" / "202601"
        (pack / "handoff").mkdir(parents=True)
        (pack / "variables").mkdir()
        (pack / "config").mkdir()
        (pack / "config" / "data_product.yaml").write_text(
            "data_product_id: x\nvariables:\n  - variables/followup.yaml\n", encoding="utf-8")
        (pack / "variables" / "followup.yaml").write_text(
            "follow_up:\n  window_days: 90\n", encoding="utf-8")
        (pack / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\n"
            "variable_id: FUEND\n"
            "spec_refs: [clinical:12]\n"
            "window: 180 days after index\n"
            "implementation_refs: [variables/followup.yaml#/follow_up]\n"
            "status: {requirement: draft, source_mapping: proposed}\n"
            "```\n", encoding="utf-8")
        saved, cp.REPO = cp.REPO, str(d)
        try:
            rep = cp.report("products/oncology/x/202601")
        finally:
            cp.REPO = saved
        got = {r["block"]: r for r in rep["blocks"]}.get("variables/followup.yaml#/follow_up")
        assert got, sorted(r["block"] for r in rep["blocks"])
        assert got["state"] == cp.CHANGED, got
        assert rep["counts"][cp.CHANGED] == 1, rep["counts"]
        # ...and it must say WHAT disagrees, or a reader re-derives what the comparator printed.
        assert "180" in got["why"] and "90" in got["why"], got["why"]
        assert got["why"] != cp.MEANING[cp.CHANGED], "the generic class text, not the finding"
        assert rep["contradiction_scan"]["findings"] >= 1, rep["contradiction_scan"]
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_a_changed_count_of_zero_carries_what_was_compared():
    """The other half of the same defect. `changed: 0` is only a result if something was compared;
    over a contract nothing compared it is silence wearing agreement's number."""
    d = cp.report("products/oncology/prostate/202606")
    scan = d["contradiction_scan"]
    assert scan["records"] > 0 and scan["compared"] > 0, scan
    text = cp.render("products/oncology/prostate/202606")
    assert f"{scan['compared']} parameter comparison(s)" in text, "the denominator is not shown"
    assert "CANNOT see two records sharing a block" in text, "the limit is not stated"
    # A pack with NO contract must not claim a comparison it never ran.
    m = cp.report("products/oncology/mcrc/202606")
    assert m["contradiction_scan"] == {"records": 0, "compared": 0, "findings": 0}
    assert m["counts"][cp.CHANGED] == 0


def test_the_worst_class_is_listed_first():
    """A reader works down the page. What nothing stands behind is the finding, not a footnote."""
    assert cp.ORDER[0] == cp.UNSUPPORTED and cp.ORDER[-1] == cp.CONFIRMED
    text = cp.render("products/oncology/prostate/202606")
    assert text.index("## unsupported") < text.index("## confirmed")


def test_a_block_claimed_by_a_record_citing_spec_rows_is_confirmed():
    """The positive path, on a synthetic pack — so it is asserted rather than inferred from the
    live one, where a change in prostate's contract would quietly make this vacuous."""
    d = Path(tempfile.mkdtemp())
    try:
        pack = d / "products" / "oncology" / "x" / "202601"
        (pack / "handoff").mkdir(parents=True)
        (pack / "variables").mkdir()
        (pack / "config").mkdir()
        (pack / "config" / "data_product.yaml").write_text(
            "data_product_id: x\nvariables:\n  - variables/demographics.yaml\n", encoding="utf-8")
        (pack / "variables" / "demographics.yaml").write_text(
            "age_bands:\n  - {label: '18-64', min: 18, max: 64}\n", encoding="utf-8")
        (pack / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(
            "```yaml\n"
            "variable_id: AGEGR1\n"
            "spec_refs: [demographics:7]\n"
            "implementation_refs: [variables/demographics.yaml#/age_bands]\n"
            "status: {requirement: draft, source_mapping: proposed}\n"
            "```\n", encoding="utf-8")
        saved, cp.REPO = cp.REPO, str(d)
        try:
            rows = {r["block"]: r for r in cp.classify("products/oncology/x/202601")}
        finally:
            cp.REPO = saved
        got = rows.get("variables/demographics.yaml#/age_bands")
        assert got, sorted(rows)
        assert got["state"] == cp.CONFIRMED, got
        assert got["spec_refs"] == ["demographics:7"], got
        assert got["records"] == ["AGEGR1"], got
    finally:
        shutil.rmtree(d, ignore_errors=True)


if __name__ == "__main__":
    os.chdir(FRAMEWORK)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
