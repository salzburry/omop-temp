"""The capability registry is what turns a coverage CLAIM into a checkable fact, and this pins it.

`INVENTORY.yaml` says a variable's coverage is `engine_family`; `inventory_coverage.py` checks that
the class is in the enum and the `via` sentence is non-empty. Neither reads the engine. An external
review found LINE_OF_THERAPY classed `engine_family` when `stages/lot.py` only normalises a table
the VENDOR derived — a wrong claim that every check in the repository had passed, because every
check was reading the claim rather than the code.

`platform/capabilities.yaml` names, per master family, the config key a pack authors, the Python and
R symbols that read it, the columns it publishes and the tests that exercise it. The properties
below are the ones that make it worth having: every part RESOLVES, and the registry and the
inventory cannot disagree about which classes a family answers. Each is mutation-tested — the live
files pass every check, so a check that had been written backwards would look identical to one
written correctly unless a planted defect proves otherwise.

NO PYTEST FIXTURES AND NO `parametrize`, and that is not a style preference. CI runs every suite as
a SCRIPT, so a test taking a fixture argument cannot be CALLED outside pytest — the file would
import, define its tests, run none of them and exit 0. That is a green step protecting nothing, and
this suite shipped that way for one commit until
`test_spec_pipeline.test_every_suite_actually_runs_the_way_ci_invokes_it` caught it. Cases that
would be `parametrize` are loops that name the case they failed on.

Run: python3 tests/test_capability_registry.py (or pytest).
"""
import copy
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
REPO = FRAMEWORK.parent
sys.path.insert(0, str(FRAMEWORK / "tools"))

import capability_registry as cr  # noqa: E402


_CACHE = []


def live():
    """The registry and the inventory's class map, loaded once per process."""
    if not _CACHE:
        _CACHE.append((cr.load(), cr.inventory_classes()))
    return _CACHE[0]


def _cap(doc, cid):
    for c in doc["capabilities"]:
        if c["id"] == cid:
            return c
    raise AssertionError(f"no capability {cid}")


def test_the_live_registry_resolves():
    doc, inv = live()
    assert cr.registry_errors(doc, inv) == []


def test_every_non_gap_master_family_has_a_capability():
    """The inventory is the demand side: a family it does not class `engine_gap` everywhere is a
    family the platform CLAIMS to answer, and the claim is owed an entry here."""
    doc, inv = live()
    owed = {m for m, cs in inv.items() if {c for c in cs if c in cr.SUPPORTABLE}}
    answered = {c["master"] for c in doc["capabilities"]}
    assert owed <= answered, f"claimed but unresolved: {sorted(owed - answered)}"


def test_a_new_master_family_without_a_capability_is_refused():
    """The check that keeps this file honest as the inventory grows. Adding a family to an overlay
    and classing it `engine_family` must NOT quietly inherit the registry's clean bill."""
    doc, inv = live()
    inv = dict(inv)
    inv["A_BRAND_NEW_FAMILY"] = {"engine_family"}
    errs = cr.registry_errors(doc, inv)
    assert any("A_BRAND_NEW_FAMILY" in e and "no capability answers it" in e for e in errs), errs


def test_a_whole_family_engine_gap_owes_no_capability():
    """The other direction: a family the engine cannot express at all must not be reported as a
    missing capability — that would push someone to write an entry for code that does not exist."""
    doc, inv = live()
    inv = dict(inv)
    inv["A_PURE_GAP_FAMILY"] = {"engine_gap"}
    assert cr.registry_errors(doc, inv) == []


def test_claiming_a_class_the_inventory_never_assigns_is_refused():
    """Drift runs both ways. A capability that claims `engine_family` for a family every overlay
    calls `config_expressible` overstates the platform exactly as the LINE_OF_THERAPY entry did."""
    doc, inv = live()
    doc = copy.deepcopy(doc)
    _cap(doc, "clinical.comorbidity_index")["supports"] = ["engine_family"]
    errs = cr.registry_errors(doc, inv)
    assert any("COMORBIDITY_INDEX" in e and "no inventory variable asks for" in e for e in errs), errs


def test_a_capability_for_a_family_no_overlay_instantiates_is_refused():
    doc, inv = live()
    doc = copy.deepcopy(doc)
    _cap(doc, "clinical.vitals")["master"] = "NOT_A_FAMILY"
    errs = cr.registry_errors(doc, inv)
    assert any("NOT_A_FAMILY" in e for e in errs), errs


def test_engine_gap_cannot_be_claimed_as_a_capability():
    """A gap is the ABSENCE of a capability. An entry claiming to implement one is a contradiction
    the registry must not be able to express."""
    doc, inv = live()
    doc = copy.deepcopy(doc)
    _cap(doc, "clinical.vitals")["supports"] = ["engine_gap"]
    errs = cr.registry_errors(doc, inv)
    assert any("supports" in e and "clinical.vitals" in e for e in errs), errs


UNRESOLVABLE_PARTS = [
    ("python", [{"module": "platform/engine/stages/clinical.py", "symbol": "no_such_symbol"}],
     "does not define 'no_such_symbol'"),
    ("python", [{"module": "platform/engine/stages/nope.py", "symbol": "vitals"}],
     "does not exist"),
    ("r", [{"file": "platform/engine-r/stages.R", "symbol": "clinical_no_such"}],
     "does not define 'clinical_no_such'"),
    ("tests", ["platform/tests/test_stages_spark.py::test_no_such_test"],
     "does not define 'test_no_such_test'"),
    ("tests", ["platform/tests/test_nothing.py::test_x"], "does not exist"),
    ("emits", [], "emits nothing"),
    ("config_keys", [], "no config_keys"),
]


def test_a_part_that_does_not_resolve_is_refused():
    """Every part of a capability, planted broken one at a time. A registry that checked six of the
    seven would look exactly like one that checked all seven."""
    _, inv = live()
    for field, value, needle in UNRESOLVABLE_PARTS:
        doc = copy.deepcopy(live()[0])
        _cap(doc, "clinical.vitals")[field] = value
        errs = cr.registry_errors(doc, inv)
        assert any(needle in e for e in errs), (field, needle, errs)


def test_a_config_key_no_engine_code_reads_is_refused():
    """THE FAILURE THIS REPO HAS ALREADY PAID FOR. A block a pack can author, that lints clean and
    passes every gate, whose variable never appears because no engine code reads the key."""
    doc, inv = live()
    doc = copy.deepcopy(doc)
    _cap(doc, "clinical.vitals")["config_keys"] = ["clinical.height_and_weight_settings"]
    errs = cr.registry_errors(doc, inv)
    assert any("height_and_weight_settings" in e and "no engine code reads" in e for e in errs), errs


def test_a_config_key_with_no_home_is_refused():
    doc, inv = live()
    doc = copy.deepcopy(doc)
    _cap(doc, "clinical.vitals")["config_keys"] = ["nowhere.vitals"]
    errs = cr.registry_errors(doc, inv)
    assert any("no known home" in e for e in errs), errs


def test_upstream_required_must_name_the_table_the_vendor_delivers():
    """The whole content of the class. `upstream_required` without a table name says "someone else
    builds this" and leaves a new tumour no way to check whether their delivery has it."""
    doc, inv = live()
    doc = copy.deepcopy(doc)
    del _cap(doc, "lot.normalized")["upstream_table"]
    errs = cr.registry_errors(doc, inv)
    assert any("names no upstream_table" in e for e in errs), errs


def test_only_upstream_required_capabilities_name_an_upstream_table():
    doc, inv = live()
    doc = copy.deepcopy(doc)
    _cap(doc, "clinical.vitals")["upstream_table"] = "vitals"
    errs = cr.registry_errors(doc, inv)
    assert any("without supporting upstream_required" in e for e in errs), errs


def test_duplicate_capability_ids_are_refused():
    doc, inv = live()
    doc = copy.deepcopy(doc)
    doc["capabilities"].append(copy.deepcopy(_cap(doc, "clinical.vitals")))
    errs = cr.registry_errors(doc, inv)
    assert any("duplicate capability id" in e for e in errs), errs


def test_every_capability_states_how_far_EACH_engine_is_proven():
    """THE CLAIM THAT HID A LIVE DIVERGENCE. The first registry reported a capability resolved when
    a Python symbol and an R symbol both existed, so `clinical.comorbidity_index` read as
    implemented in both while R applied the supersedes hierarchy sequentially and truncated
    fractional weights — 4 where Python returned 3, every registry check green."""
    doc, _ = live()
    for cap in doc["capabilities"]:
        v = cap.get("verification") or {}
        assert set(v) == {"python", "r"}, (cap["id"], v)
        assert v["python"] in cr.VERIFICATION and v["r"] in cr.VERIFICATION, (cap["id"], v)


def test_a_capability_with_no_verification_is_refused():
    doc, inv = live()
    doc = copy.deepcopy(doc)
    del _cap(doc, "clinical.vitals")["verification"]
    errs = cr.registry_errors(doc, inv)
    assert any("must name BOTH engines" in e for e in errs), errs


def test_claiming_conformance_without_a_cross_engine_test_is_refused():
    """A same-language unit test cannot detect a divergence between two languages. A parity state
    must cite the ONE suite that runs both."""
    doc, inv = live()
    doc = copy.deepcopy(doc)
    cap = _cap(doc, "clinical.death_date")          # unit_tested; cites no parity test
    cap["verification"] = {"python": "component_parity", "r": "component_parity"}
    errs = cr.registry_errors(doc, inv)
    assert any("cites no test in" in e and cr.CONFORMANCE_SUITE in e for e in errs), errs


def test_stage_conformance_cannot_be_claimed_by_renaming():
    """THE STATE THAT MUST NOT BE ADOPTED THE WAY ITS PREDECESSOR WAS.

    `cross_engine_conformance` was described as "runs BOTH engines over the same input and
    compares" and claimed by ten capabilities on evidence that compares helper FUNCTIONS — the
    parity suite holds no Spark session and compares no stage output. The state was split so the
    name matches the evidence, and the stronger half is refused outright until a harness exists to
    earn it. Otherwise the same overstatement returns the moment somebody edits a word.
    """
    doc, inv = live()
    doc = copy.deepcopy(doc)
    cap = _cap(doc, "clinical.comorbidity_index")   # DOES cite the parity suite
    cap["verification"] = {"python": "stage_conformance", "r": "stage_conformance"}
    errs = cr.registry_errors(doc, inv)
    assert any("no shared row fixture" in e for e in errs), errs
    # ...and no live entry claims it.
    live_doc, _ = live()
    for c in (live_doc.get("capabilities") or []):
        v = c.get("verification") or {}
        assert "stage_conformance" not in (v.get("python"), v.get("r")), c.get("id")


def test_the_parity_suite_really_does_run_no_stage_output():
    """The premise of the split, asserted rather than assumed. If a Spark session ever appears in
    the parity suite, this test should fail and `stage_conformance` becomes earnable."""
    src = (FRAMEWORK / "tests" / "test_r_parity.py").read_text(encoding="utf-8")
    for marker in ("SparkSession", "createDataFrame"):
        assert marker not in src, (
            f"{marker} appeared in the parity suite — it may now compare stage OUTPUT, so the "
            f"`stage_conformance` refusal in capability_registry.py needs revisiting")


def test_an_r_state_and_an_r_symbol_must_agree():
    doc, inv = live()
    doc = copy.deepcopy(doc)
    cap = _cap(doc, "clinical.vitals")
    cap["verification"] = {"python": "unit_tested", "r": "absent"}
    errs = cr.registry_errors(doc, inv)
    assert any("`absent` but an R symbol is named" in e for e in errs), errs

    doc2 = copy.deepcopy(live()[0])
    cap2 = _cap(doc2, "clinical.vitals")
    cap2["r"] = []
    errs = cr.registry_errors(doc2, inv)
    assert any("with no R symbol named" in e for e in errs), errs


def test_the_comorbidity_capability_cites_the_conformance_test_that_caught_the_divergence():
    """Named specifically: this is the capability the review found wrong in R, and its conformance
    claim rests on the test that compares the closure and the weight cast across the two engines."""
    doc, _ = live()
    cap = _cap(doc, "clinical.comorbidity_index")
    assert cap["verification"] == {"python": "component_parity", "r": "component_parity"}
    assert any("test_parity_supersedes_closure_and_weight_cast" in t for t in cap["tests"]), \
        cap["tests"]


def test_the_rendering_names_how_many_R_sides_no_test_executes():
    """The number is the finding. A registry that stopped printing it would be back to reporting
    22 capabilities as though all 22 were compared."""
    md = (FRAMEWORK / "CAPABILITIES.md").read_text(encoding="utf-8")
    doc, _ = live()
    declared = sum(1 for c in doc["capabilities"] if c["verification"]["r"] == "declared")
    assert f"**{declared} of {len(doc['capabilities'])} capabilities have an R implementation that " \
           f"no test executes**" in md
    assert "Python-verified and R-unverified" in md


def test_an_empty_registry_is_refused_rather_than_vacuously_clean():
    """An absence reported as a clean result. Zero capabilities resolve zero claims perfectly."""
    errs = cr.registry_errors({"capabilities": []}, {"OS": {"engine_family"}})
    assert errs and "vacuously" in errs[0]


def test_the_rendering_is_current():
    """CAPABILITIES.md is generated; a stale copy is drift, exactly like COVERAGE.md."""
    assert cr.main(["--check"]) == 0, \
        "CAPABILITIES.md is stale — regenerate: python3 platform/tools/capability_registry.py"


def test_the_rendering_states_its_own_limits():
    """A registry whose every part resolves reads as PROOF unless it says what it did not check."""
    md = (FRAMEWORK / "CAPABILITIES.md").read_text(encoding="utf-8")
    assert "CHECKED claim, not a verified one" in md
    assert "does not prove" in md.lower() or "Nothing here proves" in md


def test_upstream_required_families_say_so_in_the_rendering():
    md = (FRAMEWORK / "CAPABILITIES.md").read_text(encoding="utf-8")
    assert "UPSTREAM REQUIRED" in md and "`lot`" in md


if __name__ == "__main__":
    # CI RUNS EVERY SUITE AS A SCRIPT — see the module docstring. Without this block the file runs
    # no tests and exits 0.
    bad = 0
    for _name, _fn in sorted(globals().items()):
        if _name.startswith("test_") and callable(_fn):
            try:
                _fn()
                print(f"  ok  {_name}")
            except Exception as _e:                  # noqa: BLE001 - report and continue
                bad += 1
                print(f"FAIL  {_name}: {_e}")
    sys.exit(1 if bad else 0)
