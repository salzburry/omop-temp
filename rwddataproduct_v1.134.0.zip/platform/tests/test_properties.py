"""Properties, not examples — for the pure compilers, where a counterexample is worth finding.

Every other suite here asserts a fixed case: this band list, that codelist, these two rows. A
hand-written example proves the code works on the input its author thought of, which is by
construction the input they were not confused about. These state what must be true for ALL inputs
and let Hypothesis go looking, with shrinking, for the smallest input where it is not.

DELIBERATELY CONFINED TO PURE FUNCTIONS. The review's own wording — "Hypothesis can generate and
shrink counterexamples for pure components" — is the right boundary. Generating Spark frames would
buy a slow, flaky suite whose failures are about the fixture; these run in milliseconds and every
failure is about the logic.

THE PROPERTIES ARE STATED AGAINST AN INDEPENDENT ORACLE, never against the implementation. A
property that re-implements the function it tests is a tautology with a random number generator
attached — the same "check that reads the claim rather than the thing claimed" defect this
repository keeps closing, wearing a fashionable hat.

Skips cleanly without Hypothesis, and `requirements.txt` carries it so CI does not.

Run: python3 platform/tests/test_properties.py  (or pytest).
"""
import os
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))

# HYPOTHESIS'S CACHE LIVES OUTSIDE THE CHECKOUT, and this must run BEFORE the import below.
#
# Left to itself it writes `.hypothesis/` into the working directory, and its unicode tables are
# `.json.gz` — archives. `repo_hygiene` refuses archives found ON DISK, not merely tracked ones,
# because "`.gitignore` is not containment": the rule exists so that restricted material cannot sit
# in a checkout awaiting a `git add -f`. Adding `.hygiene`-style ignores would have satisfied git
# and not the rule, and the rule is right.
#
# So the storage directory moves out of the repository entirely. Nothing is lost: the example
# database is a per-machine cache of shrunk counterexamples, regenerable by definition.
os.environ.setdefault("HYPOTHESIS_STORAGE_DIRECTORY",
                      os.path.join(tempfile.gettempdir(), "rwdp-hypothesis"))

from engine import validate, golden                       # noqa: E402
from engine.codelists import sql_str                      # noqa: E402

try:
    from hypothesis import given, settings, strategies as st, HealthCheck
    HAVE = True
except Exception:                                          # noqa: BLE001
    HAVE = False

try:
    import pytest
    pytestmark = pytest.mark.skipif(not HAVE, reason="hypothesis not installed")
except Exception:
    pytest = None

if not HAVE:                                               # keep the module importable either way
    def given(*a, **k):                                    # noqa: D103
        def deco(fn):
            return fn
        return deco

    def settings(*a, **k):                                 # noqa: D103
        def deco(fn):
            return fn
        return deco

    class _St:
        def __getattr__(self, _):
            return lambda *a, **k: None
    st = _St()
    HealthCheck = None

SETTINGS = dict(max_examples=200, deadline=None)
if HAVE:
    SETTINGS["suppress_health_check"] = [HealthCheck.too_slow]


# --------------------------------------------------------------------------- SQL literal quoting

@settings(**SETTINGS)
@given(st.text(max_size=40))
def test_quoting_is_injective_so_two_values_can_never_become_one(s):
    """THE PROPERTY THAT MATTERS FOR A QUOTER. If two distinct values could compile to the same SQL
    literal, a codelist would silently merge two clinical categories — and no example test would
    find it, because you have to go looking for the collision.

    Stated as: unquoting the result returns exactly the input. An injective encoding is exactly one
    that a decoder can invert, and the decoder here is independent of the encoder.

    THE INVERSE UNDOES BOTH ESCAPES, IN REVERSE ORDER. The first version of this test undid only
    the quote doubling, and Hypothesis immediately produced a single backslash — because `sql_str`
    escapes BACKSLASHES too, and deliberately: Spark drops an unrecognised escape silently, so a
    codelist carrying a `\\d+` pattern would otherwise compile to one matching a literal `d`. The
    encoder was right and this test was wrong, which is still the property doing its job.
    """
    lit = sql_str(s)
    assert lit.startswith("'") and lit.endswith("'"), lit
    # Encoded backslashes-then-quotes, so decode quotes-then-backslashes.
    assert lit[1:-1].replace("''", "'").replace("\\\\", "\\") == s


@settings(**SETTINGS)
@given(st.text(max_size=20), st.text(max_size=20))
def test_distinct_values_compile_to_distinct_literals(a, b):
    """The same property said the other way round, because this is the direction a reader cares
    about and the direction a bug would be reported in."""
    if a != b:
        assert sql_str(a) != sql_str(b)


@settings(**SETTINGS)
@given(st.text(max_size=30))
def test_a_quoted_literal_never_leaves_an_unbalanced_quote(s):
    """A single quote that escapes its literal does not merely corrupt a value; it changes the
    STRUCTURE of the compiled CASE. Every quote inside must be doubled, so the count of quote
    characters in the body is even."""
    body = sql_str(s)[1:-1]
    assert body.count("'") % 2 == 0, (s, body)


# --------------------------------------------------------------------------- band coverage

def _bands(pairs):
    """The node shape the detector actually takes: a LIST of band dicts.

    The first version of this helper wrapped it as `{"bands": [...]}`, so the detector iterated the
    dict's KEYS, found no dicts among them, and returned no findings — every planted gap and
    overlap "passed". A property test against a mis-shaped input is a generator of false
    confidence, which is worse than no property at all.
    """
    return [{"label": f"b{i}", "min": lo, "max": hi} for i, (lo, hi) in enumerate(pairs)]


@settings(**SETTINGS)
@given(st.lists(st.integers(min_value=0, max_value=120), min_size=2, max_size=6, unique=True))
def test_contiguous_bands_are_never_reported_as_a_gap_or_an_overlap(cuts):
    """THE ORACLE IS ARITHMETIC, not the detector. Build bands that are contiguous BY
    CONSTRUCTION — each one starts where the last ended plus one — and no finding may be produced.

    This is the direction that matters most: a band checker that fires on correct configuration is
    one that gets relaxed rather than read, which is how the repository lost two earlier checks.
    """
    cuts = sorted(cuts)
    pairs = [(cuts[i], cuts[i + 1] - 1) for i in range(len(cuts) - 1) if cuts[i] <= cuts[i + 1] - 1]
    if len(pairs) < 2:
        return
    # rebuild contiguously so the property is guaranteed, not hoped for
    fixed, lo = [], pairs[0][0]
    for _, hi in pairs:
        if hi >= lo:
            fixed.append((lo, hi))
            lo = hi + 1
    if len(fixed) < 2:
        return
    assert validate._band_coverage_problems("t", _bands(fixed)) == [], fixed


@settings(**SETTINGS)
@given(st.integers(min_value=0, max_value=60), st.integers(min_value=1, max_value=20),
       st.integers(min_value=2, max_value=15))
def test_a_planted_gap_is_always_found(lo, width, hole):
    """Two bands with a hole between them, of any size and at any position. The detector must find
    every one — a gap check that works for the example in its docstring and not for a hole of 13 is
    worse than none, because it reports as coverage."""
    a_hi = lo + width
    b_lo = a_hi + hole                      # hole >= 2 guarantees a real gap (a_hi + 1 < b_lo)
    probs = validate._band_coverage_problems("t", _bands([(lo, a_hi), (b_lo, b_lo + width)]))
    assert probs, (lo, a_hi, b_lo)
    assert any(str(a_hi + 1) in p for p in probs), probs


@settings(**SETTINGS)
@given(st.integers(min_value=0, max_value=60), st.integers(min_value=2, max_value=20),
       st.integers(min_value=1, max_value=10))
def test_a_planted_overlap_is_always_found(lo, width, back):
    """Two bands that share values. The compiled CASE takes the first matching WHEN, so which band
    wins is decided by YAML order — a semantic decision made by a text editor."""
    a_hi = lo + width
    b_lo = a_hi - min(back, width)          # <= a_hi, so the bands genuinely share a value
    probs = validate._band_coverage_problems("t", _bands([(lo, a_hi), (b_lo, b_lo + width)]))
    assert probs, (lo, a_hi, b_lo)
    assert any("both" in p or "overlap" in p.lower() for p in probs), probs


# --------------------------------------------------------------------------- drift arithmetic

@settings(**SETTINGS)
@given(st.integers(min_value=-10**6, max_value=10**6), st.integers(min_value=-10**6, max_value=10**6))
def test_summarise_diff_deltas_always_reconcile(new, ref):
    """The number a reviewer quotes. `delta` must equal new - ref for every pair, including the
    negatives and the zeroes that an example test tends not to include."""
    out = golden.summarise_diff({"k": new}, {"k": ref})["k"]
    assert out["delta"] == new - ref
    assert out["new"] == new and out["ref"] == ref
    # A percentage against a zero reference is undefined, not zero, not infinity.
    assert (out["pct"] is None) is (ref == 0)


@settings(**SETTINGS)
@given(st.floats(min_value=-1e6, max_value=1e6, allow_nan=False, allow_infinity=False),
       st.floats(min_value=-1e6, max_value=1e6, allow_nan=False, allow_infinity=False))
def test_abs_pct_is_never_negative_and_is_none_only_when_undefined(new, ref):
    """A drift threshold compares against this; a negative would silently pass every ceiling."""
    got = golden._abs_pct(new, ref)
    if ref == 0:
        assert got is None
    else:
        assert got is not None and got >= 0, (new, ref, got)


if __name__ == "__main__":
    if not HAVE:
        print("SKIP: hypothesis not installed — properties did not run.")
        sys.exit(0)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} properties passed")
