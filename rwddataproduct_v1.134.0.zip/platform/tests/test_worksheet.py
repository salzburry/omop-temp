"""The worksheet orders existing work; it must not invent any.

`platform/tools/worksheet.py` is a view over three tools that already own their answers —
`finalize.facts`, `decision_report.blast_radius`, `contract_binding.check`/`.promote`. Its value is
the SEQUENCE (decisions first, because one answer can unblock nineteen records) and the single entry
point, not new logic. Two ways that goes wrong:

  * it recomputes something, becomes a second implementation of whichever tool owns that count, and
    eventually tells an analyst there is less to do than there is;
  * it presents a partial list as a whole one — the first version showed the top eight decisions by
    blast radius and then "…and 10 more" taken from an ALPHABETICAL slice, so four decisions
    appeared twice and the promised remainder was not the remainder.

Run: python3 tests/test_worksheet.py (or pytest).
"""
import ast
import os
import re
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
TOOLS = FRAMEWORK / "tools"
REPO = FRAMEWORK.parent
sys.path.insert(0, str(TOOLS))
sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))

import _packs            # noqa: E402
import contract_binding  # noqa: E402
import decision_report   # noqa: E402
import finalize          # noqa: E402
import product_gates     # noqa: E402
import worksheet         # noqa: E402

# A MATERIALISED ROOT: the real packs, plus prostate/202607 restored to a product path. That pack is
# not a product (unregistered, never built, never released) and no longer lives in `products/`, but
# it is the ONLY pack with a contract and NO config — a zero denominator in sections 2 and 3, which
# is the exact case these tests exist for. Against the real checkout `test_no_section_reports_a_
# clean_result_over_an_empty_denominator` has nothing to check and says so rather than passing.
#
# `worksheet.render(pack)` resolves against a MODULE-level ROOT, so the module is repointed too —
# leaving it would read the pack list from one tree and the packs themselves from another.
ROOT = _packs.materialised_root()
worksheet.ROOT = ROOT


def _packs_with_contract():
    out = [p for p in sorted(product_gates.products(ROOT))
           if os.path.exists(os.path.join(ROOT, p, "handoff", "FUNCTIONAL_CONTRACT.md"))]
    assert out, "no pack has a contract — these tests would prove nothing"
    return out


def test_it_computes_nothing_of_its_own():
    """Every fact comes from a tool that owns it. Asserted as 'opens no file and parses no
    artifact', which is the enforceable form — and checked against the AST, because the module
    legitimately NAMES FUNCTIONAL_CONTRACT.md in the sentence it prints when one is missing."""
    tree = ast.parse((TOOLS / "worksheet.py").read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        fn = node.func
        name = fn.id if isinstance(fn, ast.Name) else (fn.attr if isinstance(fn, ast.Attribute) else "")
        assert name != "open", "worksheet.py calls open() — the owning tool should read it"
        assert name not in ("read_text", "safe_load", "loads", "decision_rows", "records"), \
            f"worksheet.py calls {name}() — that is another tool's job"


def test_it_calls_the_owning_tools_not_copies():
    """Same module objects, so a change in any of them reaches the worksheet."""
    assert worksheet.finalize is finalize
    assert worksheet.decision_report is decision_report
    assert worksheet.contract_binding is contract_binding


def test_the_headline_counts_match_the_tools_that_own_them():
    """The numbers in the banner are the ones an analyst plans around."""
    for pack in _packs_with_contract():
        product = os.path.join(ROOT, pack)
        f = finalize.facts(product)
        _, s = contract_binding.check(product, product_gates.pack_yaml(product))
        text = worksheet.render(pack)
        assert f"{f['records']} contract record(s)" in text, f"{pack}: record count differs"
        assert f"{s['claimed']}/{s['blocks']} governed config block(s)" in text, \
            f"{pack}: claimed/total differs"


def test_the_remainder_is_the_remainder():
    """The bug this file exists for: a rank-ordered head and an alphabetical tail overlapped, so
    four decisions were listed twice under a heading promising the ones NOT shown."""
    for pack in _packs_with_contract():
        text = worksheet.render(pack)
        shown = set(re.findall(r"^\s+\[\s*\d+ record\(s\)\]\s+(\S+)", text, re.M))
        m = re.search(r"…and \d+ more, each blocking fewer: (.+)$", text, re.M)
        rest = {d.strip() for d in m.group(1).split(",")} if m else set()
        assert not (shown & rest), f"{pack}: {sorted(shown & rest)} listed both as top and as more"

        blocking, _, _, _ = decision_report.blast_radius(os.path.join(ROOT, pack))
        if m:
            assert shown | rest == set(blocking), \
                f"{pack}: the two lists together are not every blocking decision"


def test_decisions_are_ranked_by_how_many_records_they_unblock():
    """Doing them in file order is close to the worst possible order — the ranking IS the product."""
    ranked_any = False
    for pack in _packs_with_contract():
        counts = [int(n) for n in re.findall(r"^\s+\[\s*(\d+) record\(s\)\]", worksheet.render(pack), re.M)]
        assert counts == sorted(counts, reverse=True), f"{pack}: decisions are not ranked"
        ranked_any = ranked_any or len(counts) > 1
    assert ranked_any, "no pack has two blocking decisions — the ordering is untested"


def test_a_pack_with_no_contract_is_told_to_start_elsewhere():
    """All-zero counts read as 'nothing to do' rather than 'nothing to read' — the same category
    error as scoring an absent test suite as PASS."""
    without = [p for p in sorted(product_gates.products(ROOT))
               if not os.path.exists(os.path.join(ROOT, p, "handoff", "FUNCTIONAL_CONTRACT.md"))]
    assert without, "every pack has a contract — this test would prove nothing"
    # Caught, because without the guard `render` does not produce a misleading worklist — it dies
    # inside contract_lint trying to read a file that is not there, and a FileNotFoundError three
    # frames down says nothing about the guard whose removal caused it.
    try:
        text = worksheet.render(without[0])
    except Exception as e:
        raise AssertionError(
            f"render({without[0]}) raised {type(e).__name__}: {e}\n"
            f"    A pack with no contract must be answered by the not_started guard, not by "
            f"letting the owning tools fail on a file that does not exist.") from None
    assert "no handoff/FUNCTIONAL_CONTRACT.md" in text
    assert "ANSWER THESE" not in text, "an empty worklist was rendered as though there were work"
    assert "run_spec_pipeline" in text, "it does not say where to start instead"


def test_spec_coverage_is_stated_before_anything_is_ranked():
    """The defect this closes: ovarian's contract holds 9 of 360 spec items with 299
    undispositioned, and the worksheet reported 3 blocking decisions and 33 unclaimed blocks —
    small numbers that read as 'nearly done'. A short list is only good news if the list is
    complete, and these three are complete only over the drafted part of the specification."""
    checked = 0
    for pack in _packs_with_contract():
        f = finalize.facts(os.path.join(ROOT, pack))
        if f.get("items") is None:
            continue
        checked += 1
        text = worksheet.render(pack)
        assert f"{f.get('mapped', 0)} of {f['items']} spec item(s)" in text, \
            f"{pack}: coverage is not stated"
        head = text.split("1. ANSWER THESE")[0]
        assert f"{f['items']} spec item(s)" in head, \
            f"{pack}: coverage appears only AFTER the ranked lists it qualifies"
    assert checked, "no pack reports spec coverage — this test would prove nothing"


def test_undispositioned_rows_are_called_out_and_a_complete_contract_is_not():
    """The warning must fire where it applies and stay silent where it does not, or it becomes
    noise everyone learns to skip."""
    loud = quiet = None
    for pack in _packs_with_contract():
        f = finalize.facts(os.path.join(ROOT, pack))
        if f.get("items") is None:
            continue
        (loud := pack) if f.get("undispositioned") else (quiet := pack)
    assert loud and quiet, "need one pack with undispositioned rows and one without"

    hot = worksheet.render(loud)
    n = finalize.facts(os.path.join(ROOT, loud))["undispositioned"]
    assert "UNDISPOSITIONED" in hot and str(n) in hot, f"{loud}: {n} undispositioned rows unreported"
    assert "not evidence of a small amount of remaining work" in hot, \
        f"{loud}: the short-list caveat is missing"

    cold = worksheet.render(quiet)
    assert "UNDISPOSITIONED" not in cold, f"{quiet} has none, and is being warned anyway"
    assert "not evidence of a small amount of remaining work" not in cold


def test_the_coverage_note_is_not_truncated_mid_sentence():
    """It is wrapped through the same helper that clips a quoted decision question to three lines;
    clipped here it would lose the clause that carries the point."""
    for pack in _packs_with_contract():
        text = worksheet.render(pack)
        if "The three lists below" not in text:
            continue
        note = text.split("The three lists below")[1].split("---")[0]
        assert "remaining work." in note, f"{pack}: the coverage note is cut off"


def test_no_section_reports_a_clean_result_over_an_empty_denominator():
    """THE GENERAL RULE, and the reason this test exists rather than a sixth one-off fix.

    An empty list means one of two opposite things — looked and found nothing, or had nothing to
    look at — and this codebase has now printed the same line for both five times in different
    tools: an absent test suite scored PASS, an unstarted config was called drifted, a pack with no
    contract got a worklist of zeroes, an undrafted specification made a pack look nearly done, and
    section 3 told prostate/202607 that "every governed block is claimed" when the count was 0 of 0.

    So the rule is asserted over every section of every pack: where the denominator is zero, the
    rendered section must carry NOTHING_TO_CHECK. Per-instance fixes were not stopping this.
    """
    checked, exercised = 0, set()
    for pack in _packs_with_contract():
        product = os.path.join(ROOT, pack)
        _, s = contract_binding.check(product, product_gates.pack_yaml(product))
        _, table, _, _ = decision_report.blast_radius(product)
        text = worksheet.render(pack)
        denominators = {
            " 1. ANSWER THESE": len(table),
            " 2. CHECK THESE VALUES": s["blocks"],
            " 3. ACCOUNT FOR THESE": s["blocks"],
        }
        for heading, denom in denominators.items():
            after = text.split(heading, 1)
            assert len(after) == 2, f"{pack}: section {heading!r} did not render"
            # A heading is CLOSED by a rule before its body starts, so the body is the segment
            # between the first and second rules after the heading — not the first, which is the
            # remainder of the heading line itself.
            segments = after[1].split(rule_break(text))
            body = segments[1] if len(segments) > 1 else segments[0]
            if denom:
                continue
            checked += 1
            exercised.add(heading)
            assert worksheet.NOTHING_TO_CHECK in body, (
                f"{pack}: {heading.strip()} has a denominator of 0 and does not say so.\n"
                f"    An empty section over an empty denominator must state that nothing was "
                f"examined, or it reads as a clean result.\n    Got: {body.strip()[:200]!r}")
    assert checked, ("no pack has an empty denominator in any section — this test would pass "
                     "vacuously, which is the very thing it exists to forbid")
    # Which sections were actually exercised at zero, named rather than assumed. Removing section
    # 1's empty-register branch passed this test at first, because no live pack has a contract AND
    # an empty decisions register, so that branch is unreachable from real data — exactly the shape
    # that hid the unregistered-pack fail-open until a synthetic fixture went in.
    assert exercised >= {" 2. CHECK THESE VALUES", " 3. ACCOUNT FOR THESE"}, (
        f"only {sorted(exercised)} were exercised at a zero denominator; the rule is untested for "
        f"the rest")
    # Section 1 is NOT in that set and cannot be: no live pack has a contract and an empty
    # decisions register. It is covered by the synthetic case below instead of being left to a
    # branch nothing reaches — removing it passed this test until that case existed.


def test_an_empty_decisions_register_says_nothing_was_examined():
    """Section 1's zero-denominator branch, which no live pack reaches.

    Every pack with a contract also has decisions in its register, so `len(table) == 0` never
    happens here and deleting the branch changed no output — the same unreachable-from-real-data
    shape that hid the unregistered-pack fail-open in the precedent store. Driven by substituting
    the owning function rather than by building a pack, because the branch depends on exactly one
    input and a fixture would test the fixture.
    """
    pack = _packs_with_contract()[0]
    real = decision_report.blast_radius
    try:
        decision_report.blast_radius = lambda p: ({}, {}, [], {})
        text = worksheet.render(pack)
    finally:
        decision_report.blast_radius = real
    body = text.split(" 1. ANSWER THESE", 1)[1].split(rule_break(text))[1]
    assert worksheet.NOTHING_TO_CHECK in body, (
        f"an empty decisions register renders as a clean result: {body.strip()[:160]!r}")
    assert "No open decision is blocking a record" not in body, \
        "an empty register was reported as 'nothing is blocking', which is the opposite claim"

    # And the same substitution with a NON-empty register must NOT say it.
    try:
        decision_report.blast_radius = lambda p: ({}, {"D-1": {"Question": "q"}}, [], {"D-1": "RESOLVED"})
        text = worksheet.render(pack)
    finally:
        decision_report.blast_radius = real
    body = text.split(" 1. ANSWER THESE", 1)[1].split(rule_break(text))[1]
    assert worksheet.NOTHING_TO_CHECK not in body, \
        "a register with decisions, none blocking, was reported as nothing-to-check"


def test_the_nothing_to_check_marker_actually_distinguishes():
    """The rule above only checks that the marker APPEARS. That is satisfied by any string, so
    softening the constant to 'none found' passed it while destroying the distinction the whole
    thing exists for — the marker's WORDS are the requirement, not its presence."""
    m = worksheet.NOTHING_TO_CHECK.lower()
    assert "nothing to check" in m, f"{worksheet.NOTHING_TO_CHECK!r} no longer says nothing was examined"
    assert "not nothing wrong" in m, (
        f"{worksheet.NOTHING_TO_CHECK!r} no longer denies the clean-result reading, which is the "
        f"half a reader gets wrong")


def rule_break(text):
    """The horizontal rule the renderer uses between sections, taken from the output itself so this
    test does not hardcode a width the tool is free to change."""
    for line in text.splitlines():
        if set(line.strip()) == {"-"} and len(line.strip()) > 40:
            return line
    raise AssertionError("no section rule found in the rendered worksheet")


def test_it_promises_no_source_mapping_or_invented_code():
    """The standing boundary. The worksheet reframes promote(); it must not soften what promote
    refuses, or an analyst reads the worklist as a complete account of the work."""
    text = worksheet.render(_packs_with_contract()[0])
    for phrase in ("Choose a source column", "numeric code", "Resolve a decision"):
        assert phrase in text, f"the worksheet no longer states that it will not {phrase!r}"


def test_it_is_not_deployed_to_production():
    import deploy_tree
    assert not any("worksheet" in str(f) for f in deploy_tree.ROOT_FILES)


if __name__ == "__main__":
    os.chdir(FRAMEWORK)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
