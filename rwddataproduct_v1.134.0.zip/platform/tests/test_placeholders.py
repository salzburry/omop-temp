"""A placeholder is accounted for only when something actually accounts for it.

`platform/tools/placeholders.py` answers "what are all these REPLACE_MEs" with a classification
instead of a count, because a bare `grep -r REPLACE_ME` returns 77 on prostate/202606 and a reader
who stops there concludes the work is unfinished. Three of those are environment bindings the build
refuses to start without; most of the rest sit on questions that are open and numbered.

The failure mode is obvious and one-directional: a tool that excuses too much tells a reader not to
worry about the only thing they should. So every test here pushes toward UNACCOUNTED being the
default, and toward the excuses being narrow and evidenced.

Run: python3 tests/test_placeholders.py (or pytest).
"""
import os
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
TOOLS = FRAMEWORK / "tools"
REPO = FRAMEWORK.parent
sys.path.insert(0, str(TOOLS))

import contract_lint as cl   # noqa: E402
import placeholders as ph    # noqa: E402
import product_gates as pg   # noqa: E402

PACK = "products/oncology/prostate/202606"


def test_the_vocabulary_is_the_frameworks_and_not_a_second_list():
    """`product_gates.PLACEHOLDERS_PREFIX` is the one definition of what a placeholder looks like.
    A private list here would drift the first time either side gained a spelling."""
    assert ph.pg is pg
    src = (TOOLS / "placeholders.py").read_text(encoding="utf-8")
    assert "PLACEHOLDERS_PREFIX" in src, "the scanner no longer takes the vocabulary from the owner"
    for spelling in pg.PLACEHOLDERS_PREFIX:
        assert f'"{spelling}"' not in src.replace("PLACEHOLDERS_PREFIX", ""), \
            f"{spelling} is written out here as well as declared in product_gates"


def test_a_runtime_binding_is_excused_only_where_the_build_would_refuse_it():
    """The three run.* keys are the one class excused as DESIGN rather than as recorded work, so the
    excuse has to be true: engine.validate must actually raise while they are unfilled. If it ever
    stops raising, this stops being a binding and becomes an unfilled field."""
    rows = ph.classify(PACK, str(REPO))
    bindings = [r for r in rows if r[2] == ph.BINDING]
    assert len(bindings) == 3, f"expected exactly the three run.* keys, got {len(bindings)}"
    # They live in the ENVIRONMENT file now. Asserted through `product_gates`, which takes the name
    # from the engine, so this cannot drift into naming a file the loader does not read.
    assert all(r[0].endswith(pg.ENVIRONMENT_YAML) for r in bindings), bindings

    # THE RULE, not today's counts. data_product.yaml happens to contain only those three
    # placeholder lines, so widening the rule to "anything in this file" changes nothing observable
    # and a count-based assertion passes over it. Any OTHER key in the same file must not inherit
    # the excuse — nothing supplies `output_table` at run time, and nothing refuses it unfilled.
    for line in ("  output_table: TODO", "  write_mode: REPLACE_ME", "  vendor: TBD"):
        kind, why = ph._class_of(pg.ENVIRONMENT_YAML, line, {}, set())
        assert kind != ph.BINDING, \
            f"{line.strip()!r} was excused as a runtime binding, but nothing supplies it per run"

    sys.path.insert(0, str(FRAMEWORK))
    from engine.config import load_config, product_config
    from engine import validate
    cfg = load_config(product_config(str(REPO / "products"), "prostate"))
    try:
        validate.check(cfg)
        raise AssertionError("validate no longer refuses an unfilled REPLACE_ME — the 'the build "
                            "would never start' excuse in placeholders.py is now false")
    except RuntimeError as exc:
        assert "REPLACE_ME" in str(exc), exc


def test_citing_a_question_does_not_excuse_a_record_that_is_not_waiting_on_it():
    """BOTH HALVES ARE REQUIRED: a cited decision or gap AND `requirement: decision_required`.

    The first version excused every placeholder on any record citing any id, so a decision about the
    lab selection window excused an empty `type` field on the same row. On prostate/202606 that was
    39 records — a TODO, a citation, and `requirement: draft` — and it took the pack's unaccounted
    count from 49 down to 8, which is the wrong direction for a tool whose only real output is the
    number nobody can explain.

    Asserted against contract_lint, which owns the record, not against the classifier's opinion."""
    rows = ph.classify(PACK, str(REPO))
    blocked, annotated = ph._record_questions(str(REPO / PACK))
    assert blocked, "no record is decision_required — this test would prove nothing"
    assert annotated, "no record merely cites a question — this test would prove nothing"

    lines = cl.read(str(REPO / PACK / "handoff" / "FUNCTIONAL_CONTRACT.md")).splitlines()
    for rel, n, kind, why in rows:
        if not rel.endswith("handoff/FUNCTIONAL_CONTRACT.md"):
            continue
        line = lines[n - 1]
        if not line.strip().startswith("|"):
            continue
        vid = line.split("|")[1].strip()
        if vid in blocked:
            assert kind == ph.BLOCKED, f"{vid} is decision_required but was classed {kind}"
        elif vid in annotated:
            assert kind == ph.UNACCOUNTED, \
                f"{vid} cites {annotated[vid]} but is not waiting on it, yet was excused as {kind}"
            assert "not decision_required" in why, why

    # and the split itself: every record is in at most one of the two maps
    assert not (set(blocked) & set(annotated))


def test_unaccounted_is_the_default_and_it_finds_the_real_ones():
    """The tool must not be an excuse machine. prostate/202606 has records whose fields are TODO and
    which cite NOTHING — DATA_SOURCE alone carries 15 — and all 17 invariants pass over them, so
    nothing else in the framework reports these at all."""
    rows = ph.classify(PACK, str(REPO))
    unaccounted = [r for r in rows if r[2] == ph.UNACCOUNTED]
    assert unaccounted, ("nothing is unaccounted on a pack known to carry unfilled records — the "
                        "classifier has become an excuse machine")
    assert all(r[0].endswith("handoff/FUNCTIONAL_CONTRACT.md") for r in unaccounted), unaccounted

    # ...and an unknown file with a placeholder is unaccounted, not waved through.
    kind, why = ph._class_of("somewhere/new.yaml", "  value: TODO", {}, set())
    assert kind == ph.UNACCOUNTED, (kind, why)


def test_a_skeleton_pack_is_excused_only_until_it_registers_a_source():
    """The narrowest excuse in the tool, and the one most able to rot into a blanket.

    A pack with no `source_refs.yaml` has registered no material, so its config markers cannot be
    filled — there is nothing approved to fill them from. That is a real state (a new tumour's
    skeleton) and worth reporting as blocked rather than as 20 findings nobody can act on. What
    must NOT happen is the excuse surviving registration, or leaking onto a live pack, or onto
    files that are not the config.
    """
    def klass(rel, line, unregistered):
        return ph._class_of(rel, line, {}, set(), {}, unregistered)[0]

    # the skeleton state: excused, and the reason names Gate 1
    kind, why = ph._class_of("config/data_product.yaml", "  method: REPLACE_ME", {}, set(), {}, True)
    assert kind == ph.BLOCKED and "Gate 1" in why, (kind, why)
    assert klass(pg.ENVIRONMENT_YAML, '  output_table: "REPLACE_ME"', True) == ph.BLOCKED

    # ...and the SAME line on a pack that has registered something is a finding again
    assert klass("config/data_product.yaml", "  method: REPLACE_ME", False) == ph.UNACCOUNTED

    # it does not leak past the config — a contract record or an unknown file stays unaccounted
    # even while the pack is unregistered
    assert klass("handoff/FUNCTIONAL_CONTRACT.md", "| X | TODO |", True) == ph.UNACCOUNTED
    assert klass("somewhere/new.yaml", "  value: TODO", True) == ph.UNACCOUNTED

    # and the predicate is the FILE, not a status: prostate has one, so it is never excused
    assert not ph._unregistered(str(REPO), PACK)
    assert all(r[2] != ph.BLOCKED or "pack skeleton" not in r[3]
               for r in ph.classify(PACK, str(REPO)))


def test_a_pending_material_excuses_a_TBD_only_while_it_is_pending():
    """Gate 1's own report is the evidence. With no pending material the same TBD is a finding."""
    kind, _why = ph._class_of("source_refs.yaml", '    path_or_link: "TBD — the workbook"',
                              {}, {"program_spec"})
    assert kind == ph.PENDING
    kind, why = ph._class_of("source_refs.yaml", '    path_or_link: "TBD — the workbook"', {}, set())
    assert kind == ph.UNACCOUNTED, (kind, why)


def test_it_reads_only_and_is_not_deployed():
    import hashlib
    import deploy_tree
    def snap():
        out = {}
        for dp, dn, fns in os.walk(str(REPO / PACK)):
            dn[:] = [d for d in dn if d not in (".git", "__pycache__")]
            for fn in fns:
                p = Path(dp, fn)
                out[str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()
        return out
    before = snap()
    ph.render([PACK], str(REPO))
    assert snap() == before, "placeholders.py modified the pack"
    assert not any("placeholders" in str(f) for f in deploy_tree.ROOT_FILES)


if __name__ == "__main__":
    os.chdir(FRAMEWORK)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
