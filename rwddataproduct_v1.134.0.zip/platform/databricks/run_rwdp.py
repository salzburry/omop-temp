# Databricks notebook source
# MAGIC %md
# MAGIC # RWDP build job — shared, tumor-agnostic
# MAGIC Thin entry point for ANY tumor: read job/widget params, load that tumor's
# MAGIC `config/data_product.yaml` (with overrides), run the locked shared PySpark engine
# MAGIC (`platform/engine`), write `{output_schema}.{output_table}`.
# MAGIC
# MAGIC Behaviour lives in each tumor's `config/`, `variables/`, `codelists/`. Switch tumor by
# MAGIC pointing `config_path` at a different tumor; switch snapshot via `refresh`. No code change.
# MAGIC Deployed via `databricks.yml` (one bundle, `tumor_slug` parameter).

# COMMAND ----------
import os
import sys
from pathlib import Path

# Parameters (Databricks job params / notebook widgets).
dbutils.widgets.text("config_path", "", "Path to a tumor's config/data_product.yaml")    # noqa: F821
dbutils.widgets.text("spec_version", "", "Spec version to build (CalVer e.g. 202603); 'current'/blank = the tumor's registry current_spec_version")  # noqa: F821
dbutils.widgets.text("framework_root", "", "Path to platform/ (engine). Derived if blank")  # noqa: F821
dbutils.widgets.text("refresh", "", "Snapshot suffix (overrides run.refresh)")            # noqa: F821
dbutils.widgets.text("source_schema", "", "Source schema (overrides run.source_schema)")  # noqa: F821
dbutils.widgets.text("output_schema", "", "Output schema (overrides run.output_schema)")  # noqa: F821
dbutils.widgets.text("reference_table", "", "Original ADS to golden-compare (optional)")  # noqa: F821
dbutils.widgets.text("tumor", "", "Tumor FOLDER SLUG (e.g. prostate); resolved to the registry code (mcrpc). Derived from the config folder if blank")  # noqa: F821
dbutils.widgets.text("git_commit", "", "Git SHA of the engine/spec (for the manifest)")  # noqa: F821
dbutils.widgets.text("release_evidence_sha256", "", "sha256 of the deployed RELEASE_EVIDENCE.yaml, printed by deploy_tree.py. Detached because tree_sha256 cannot cover the file it lives in. Defence in depth, NOT a signature: it fails a run whose digest someone else printed, and does not constrain whoever holds the deploy credentials")  # noqa: F821
dbutils.widgets.text("artifact_root", "", "Durable dir for manifest/QC/dictionary/TFL artifacts (e.g. a UC Volume)")  # noqa: F821
dbutils.widgets.text("env", "dev", "Bundle target (dev|prod); prod HARD-FAILS a placeholder artifact_root")  # noqa: F821
dbutils.widgets.text("allow_governed_waiver", "", "Set true to waive the prod/active git_commit+reference_table gates (smoke tests)")  # noqa: F821
dbutils.widgets.text("run_id", "", "Databricks job run id ({{job.run_id}}); joins git_commit into a build_id UNIQUE PER RUN")  # noqa: F821
dbutils.widgets.text("stage_telemetry", "", "Set true to record per-stage join telemetry (index vs stage-output patient counts, per-patient fan-out) into the manifest. EVIDENCE ONLY, never a verdict; costs one extra Spark job. A RUN parameter on purpose: telemetry is engineering, not science, and must not move the pack's config digest")  # noqa: F821
dbutils.widgets.text("eda", "", "Set true to collect the EDA evidence layers (inventory, grain, relationships, date sanity, funnel, output contract) into the manifest and write eda_report.json (sha256-recorded) to the artifact root. EVIDENCE ONLY, never a verdict, counts only, restricted_derived. A RUN parameter for the same reason stage_telemetry is")  # noqa: F821
dbutils.widgets.text("require_published", "", "Set 'true' on a PUBLICATION job: any stop short of a completed publication then FAILS the run instead of exiting green. An orchestrator watching job status can no longer read 'candidate staged, nothing published' as success. Leave blank on build/candidate jobs, where those stops are the job doing its job")  # noqa: F821
dbutils.widgets.text("promote_build_id", "", "PROMOTE an already-approved candidate: publish THAT build's staged bytes and build nothing. Requires handoff/RELEASE_APPROVAL.yaml naming this build_id and its persisted manifest digest")  # noqa: F821
dbutils.widgets.text("resume_promotion", "", "Attempt id of a DEAD promotion of this same build whose lock this run may take over. Every promotion invocation mints its own attempt id; a held lock of the same build_id BLOCKS unless this names the held attempt — 'I inspected that run's journal and it is dead' as an argument, never an inference from a build id")  # noqa: F821

config_path = dbutils.widgets.get("config_path")          # noqa: F821
if not config_path:
    raise ValueError("config_path is required (path to a tumor's config/data_product.yaml).")

# The shared engine lives in platform/ at the repo root (NOT under products/, NOT in the tumor folder).
framework_root = dbutils.widgets.get("framework_root")    # noqa: F821
if not framework_root:
    # config_path = <repo>/products/<family>/<slug>/<spec_version>/config/data_product.yaml -> <repo>/platform
    framework_root = str(Path(config_path).resolve().parents[5] / "platform")
sys.path.insert(0, framework_root)

from engine.config import load_config, load_yaml, merged_raw, shared_asset  # noqa: E402
from engine.validate import check, preflight                           # noqa: E402
from engine.build_ads import build                                    # noqa: E402
from engine.differential import (run_differential, differential_gate,  # noqa: E402
                                 differential_spec)
from engine.output_contract import run_output_contract, output_contract_gate  # noqa: E402
from engine.qc import (run_qc, run_source_qc, qc_gate, source_qc_gate, # noqa: E402
                       qc_thresholds)
from engine.golden import run_golden, golden_gate, golden_thresholds  # noqa: E402
from engine.refresh import build_manifest, candidate_verdict, validate_manifest  # noqa: E402
from engine.qc_report import render as render_qc_report               # noqa: E402
from engine import tfl as tfl_engine, dictionary as dict_engine        # noqa: E402
from engine import release as rel                                      # noqa: E402
from engine import audit                                               # noqa: E402
from engine.config import product_config                              # noqa: E402

# COMMAND ----------
# "One job, any tumor": the bundle builds config_path from --var spec_version, whose default is the
# SENTINEL `current` (not a hard-coded version), so the one default works for every tumor. When the
# constructed config_path doesn't exist, resolve by intent — NEVER silently fall back on an explicit version:
#   - spec_version = current | "" (sentinel)  -> build the tumor's registry current_spec_version
#     (the cross-tumor convenience: --var tumor_slug=oc resolves oc's own current, not prostate's).
#   - spec_version = an EXPLICIT version       -> use that pack; if its folder is MISSING, FAIL LOUD.
#     product_config() -> product_dir() rejects a version the registry doesn't declare (KeyError naming
#     the known set), so a typo like 202605 fails here instead of quietly building current.
# An explicit, EXISTING version short-circuits (the constructed config_path already exists -> used as-is).
spec_version = (dbutils.widgets.get("spec_version") or "").strip()   # noqa: F821
if not Path(config_path).exists():
    products_root = Path(framework_root).parent / "products"
    _slug = dbutils.widgets.get("tumor") or Path(config_path).resolve().parents[2].name   # noqa: F821
    if spec_version.lower() in ("", "current"):
        config_path = str(product_config(products_root, _slug))      # registry current_spec_version
        print(f"(spec_version='{spec_version or 'current'}' -> {_slug} registry current: {config_path})")
    else:
        # Validates the version against the registry lineage (KeyError + known set on a typo); a
        # declared-but-unmaterialized version trips the existence check below. No silent fallback.
        config_path = str(product_config(products_root, _slug, spec_version=spec_version))
        if not Path(config_path).exists():
            raise FileNotFoundError(
                f"spec_version '{spec_version}' for tumor '{_slug}' -> {config_path} does not exist "
                "(it is a registry-declared version but its pack isn't materialized). Create the pack, "
                "or pass spec_version=current to build the registry-current version.")

overrides = {
    "run.refresh": dbutils.widgets.get("refresh"),                # noqa: F821
    "run.source_schema": dbutils.widgets.get("source_schema"),    # noqa: F821
    "run.output_schema": dbutils.widgets.get("output_schema"),    # noqa: F821
}
cfg = load_config(config_path, overrides=overrides)

print(f"Product : {cfg.raw['name']}  version {cfg.version}")
print(f"Engine  : {framework_root}")
print(f"Refresh : {cfg.refresh}")
if cfg.source_union:     # under a union, run.source_schema is unused -> show the real member schemas
    members = ", ".join(f"{m.get('flag')}={m.get('schema')}" for m in cfg.source_union.get("members", []))
    print(f"Sources : source_union [{members}]  ->")
else:
    print(f"Sources : {cfg.source_schema}  ->")
for name in cfg.sources:                      # the ACTUAL fqn(s) — one per member schema under a union
    for fqn in cfg.source_fqns(name):
        print(f"          {name:14s} {fqn}")
print(f"Output  : {cfg.output_fqn}  (mode={cfg.write_mode})")
print(f"Cohorts : {', '.join(c['id'] for c in cfg.cohorts)}")

# COMMAND ----------
import hashlib   # noqa: E402
import json   # noqa: E402
from pyspark.sql import functions as F   # noqa: E402

repo_root = Path(framework_root).parent           # platform/ -> repo root
products_root = repo_root / "products"            # governed products live under products/
tumor_slug = dbutils.widgets.get("tumor") or Path(config_path).resolve().parents[2].name   # noqa: F821  (<slug> above <spec_version>/config/)
# Resolve the registry tumor CODE from the folder slug: the master catalog's applies_to + the manifest
# key on the CODE (e.g. mcrpc), NOT the folder slug (prostate). Using the slug here would make the
# dictionary filter drop every applies_to:[<code>] variable (gleason/psadiag/mcrpc/ttd/…) while still
# reporting success. The folder slug is used only for filesystem paths.
_reg = (load_yaml(str(shared_asset(products_root, "registry"))) or {}).get("tumors", [])
tumor = next((t["code"] for t in _reg if t.get("slug") == tumor_slug), tumor_slug)   # code for catalog/manifest
family = next((t.get("family", "oncology") for t in _reg if t.get("slug") == tumor_slug), "oncology")  # ledger path segment

# build_id — minted ONCE up front, UNIQUE PER RUN: the git SHA (reproducibility) joined to the
# Databricks job run id (or a UTC timestamp when run outside a job). git_commit ALONE is not unique —
# a rerun of the same commit would reuse it and overwrite the live versioned table — so the run id /
# timestamp guarantees a same-commit, same-refresh RERUN mints a NEW versioned table AND a NEW
# (build-scoped) artifact dir, never overwriting a live release or a prior run's evidence.
from datetime import datetime, timezone   # noqa: E402
_sha = (dbutils.widgets.get("git_commit") or "").strip()[:12]   # noqa: F821
_run = (dbutils.widgets.get("run_id") or "").strip()            # noqa: F821  Databricks {{job.run_id}}
# PROMOTION ADOPTS AN EXISTING BUILD RATHER THAN MINTING ONE. That is the whole difference between
# the two tasks: minting is what made an approval unsatisfiable, because a new build_id moves the
# manifest digest and an approval of build A can only ever name A. When `promote_build_id` is set,
# this run IS build A for every downstream name — its staging tables, its artifact dir, its manifest.
promote_build_id = (dbutils.widgets.get("promote_build_id") or "").strip()   # noqa: F821
build_id = promote_build_id or \
    f"{_sha or 'nogit'}_{_run or datetime.now(timezone.utc).strftime('%Y%m%dt%H%M%S')}"

# artifact_root is BUILD-SCOPED (…/<tumor>/<refresh>/<build_id>): each run's manifest/QC/dictionary/
# dashboard/TFL evidence lands in its OWN dir, so a rerun never overwrites a prior run's audit record.
artifact_root = ((dbutils.widgets.get("artifact_root")   # noqa: F821
                  or str(repo_root / "_artifacts" / tumor_slug / cfg.refresh)) + f"/{build_id}")
print(f"Build id: {build_id}  (confirm a real run id, not the literal token; artifacts -> {artifact_root})")
env = (dbutils.widgets.get("env") or "dev").lower()      # noqa: F821

# RELEASABILITY IS DERIVED FROM EVIDENCE, NOT READ FROM A STATUS FIELD. This was
# `governed = env == "prod" and status == "active"`, and `products/registry.yaml` says in as many
# words that `active` means "this is the current, supported pack" and "does NOT assert live
# validation". A pack-currency flag was deciding what may reach the public views: prostate is
# `active` today at `contract: coverage_complete, configuration: draft` on a pending stand-in.
#
# `source_manifest.releasable` is the one answer, over Gates 1-4 — and it needs no new field, because
# every input is already recorded as evidence.
sys.path.insert(0, str(Path(framework_root) / "tools"))
from source_manifest import (RELEASE_EVIDENCE, delivery_drift, evidence_verdict,  # noqa: E402
                             publish_approval_errors, releasable)            # noqa: E402

# The REPO ROOT, from `framework_root` (which IS <repo>/platform) — not by counting `parents[]` off
# config_path. `parents[4]` is <repo>/products, one level short, and `releasable` passes that root to
# Gate 1, which resolves each material's REPO-ROOT-RELATIVE `path_or_link`. So a registered
# `products/oncology/prostate/…/reference/…` resolved to `<repo>/products/products/oncology/…`, and
# the pack would have stayed permanently "not release-ready" no matter how many approvals landed.
#
# It hid because every pack is legitimately blocked at Gate 1 today, so the wrong root changed
# nothing observable. The test below now drives a pack all the way to RELEASABLE through this exact
# calculation — a gate only ever shown to refuse has not been shown to work.
_repo = Path(framework_root).resolve().parent
_rel = str(Path(config_path).resolve().parents[1].relative_to(_repo)).replace("\\", "/")
# THE CONFIGURATION'S OWN IDENTITY, computed ONCE from the pack this run actually reads. Recorded
# into every manifest this run writes, and compared at promotion against what the candidate
# recorded — `spec_version` names a config, these digests pin its BYTES, so a candidate approved
# under one configuration cannot promote after the pack quietly becomes another
# (release.candidate_binding_blockers). The same two digests Gates 3/4 pin, from the same module.
import product_gates as _pg                                          # noqa: E402
_config_identity = {"config_bundle_sha256": _pg.config_bundle_sha256(str(_repo / _rel)),
                    "delivery_sha256": _pg.delivery_sha256(str(_repo / _rel))}
# TWO SOURCES, and which one applies is decided by what is actually on disk.
#
# In a checkout (dev, CI) the full repository is present, so releasability is DERIVED live. In a
# production deployment it cannot be: `deploy_tree.py` deliberately omits the specification
# stand-ins, and Gate 1 requires any material naming a repo path to exist and still hash to its
# recorded sha256 — so a live evaluation inside the deployed tree would report every pack permanently
# blocked by the absence of the very file the packaging exists to exclude.
#
# So the tree carries `RELEASE_EVIDENCE.yaml`, evaluated against the full repo at build time and BOUND
# TO A COMMIT. It is not the `release_ready: true` flag rejected earlier — `evidence_verdict` is what
# makes the difference, and it lives in `source_manifest` beside `releasable` because the two answer
# the same question and must not drift. Every way of failing to prove the file describes THIS
# deployment returns False there; none of that decision is spelled in this notebook, which cannot be
# executed outside Databricks and therefore cannot be tested.
_evidence = _repo / RELEASE_EVIDENCE
if _evidence.exists():
    # The digest is recomputed over the DEPLOYED bytes, here, and compared inside `evidence_verdict`.
    # Recording it at build time and never recalculating it would be a checksum nobody verifies.
    from deploy_tree import tree_digest                              # noqa: E402
    release_ready, release_blockers = evidence_verdict(
        str(_evidence), _rel, dbutils.widgets.get("git_commit"),      # noqa: F821
        tree_sha256=tree_digest(str(_repo)),
        evidence_sha256=dbutils.widgets.get("release_evidence_sha256"))   # noqa: F821
elif env == "prod":
    # NO EVIDENCE FILE IN PROD MEANS THIS IS NOT AN ALLOWLISTED TREE, and that is the only mechanical
    # difference between the two deployment routes. `databricks.yml` syncs the repo root minus three
    # globs, so deploying from a checkout puts the stand-ins and reference material in the
    # workspace — and, because the full repo IS present, a live `releasable()` there would succeed and
    # publish. The allowlist would then be advice rather than a boundary. Refusing here makes the
    # generated tree the only route that can reach the public views; dev keeps live derivation, which
    # is what makes a checkout useful to develop against.
    release_ready, release_blockers = False, [
        f"no {RELEASE_EVIDENCE} — this deployment was not built by deploy_tree.py, so it is a raw "
        f"checkout rather than the allowlisted production tree. Build the tree and deploy that."]
else:
    release_ready, release_blockers = releasable(str(_repo), _rel)

# ...AND THE RUN MUST BE THE DELIVERY THAT VERDICT COVERS. Everything above proves the recorded
# decision describes this DEPLOYMENT — commit, tree digest, evidence bytes, pack entry. None of it
# is a statement about this RUN: `refresh` and `source_schema` arrive as job widgets and are handed
# to `load_config` as overrides above, so a job pointed at another cut or another delivered schema
# read a verdict derived for the committed one and passed every binding. Structural preflight then
# proves the tables and columns EXIST — never that a person confirmed a mapping against them.
#
# Applies to BOTH branches, prod and dev, because the fail-open is in the override, not in the route
# that produced the verdict. The decision is `source_manifest.delivery_drift`; this notebook cannot
# be executed in CI, so it holds none of it.
_drift = delivery_drift(merged_raw(config_path), cfg.raw)
if _drift:
    release_ready, release_blockers = False, _drift + list(release_blockers)
governed = env == "prod" and release_ready               # release-grade run -> the strict gates apply
# THE MODE THIS RUN BUILDS IN, recorded into every manifest it writes. A dev candidate used to be
# indistinguishable from a release-grade one in its own bytes; a governed promotion now refuses a
# candidate whose receipt does not say it was built release-grade (candidate_binding_blockers).
_run_mode = {"env": env, "release_grade": bool(governed)}
if env == "prod" and not release_ready:
    print(f"NOT RELEASE-READY ({_rel}) — this run may build and stage, and may NOT publish:")
    for _b in release_blockers[:6]:
        print(f"    {_b}")

# A placeholder artifact_root is a HARD failure in prod (artifacts/manifests are release evidence);
# a warning in dev. Then ensure the durable dir exists AND is WRITABLE up front: artifact_root holds
# the release ledger (manifest/QC) that records every publish, so a misconfigured-but-non-placeholder
# volume must fail the job NOW (hard in prod, warn in dev) — before we build or swap — rather than
# after the final table is already replaced. A probe write+remove proves writability, not just mkdirs.
if "REPLACE_ME" in artifact_root:
    msg = (f"artifact_root is a placeholder ({artifact_root}) — override --var artifact_root so "
           "refresh artifacts/manifests land in a real Unity Catalog Volume.")
    if env == "prod":
        raise ValueError(f"PROD refusing to run: {msg}")
    print(f"WARNING ({env}): {msg}")
try:
    dbutils.fs.mkdirs(artifact_root)   # noqa: F821
    _probe = f"{artifact_root}/.write_probe"
    dbutils.fs.put(_probe, "ok", True)   # noqa: F821  (raises if the volume isn't writable)
    dbutils.fs.rm(_probe)                 # noqa: F821
except Exception as e:   # noqa: BLE001
    msg = (f"artifact_root {artifact_root} is not writable ({e}) — the release ledger (manifest/QC) "
           "can't be persisted there; fix the path/permissions (override --var artifact_root).")
    if env == "prod":
        raise RuntimeError(f"PROD refusing to run: {msg}")
    print(f"WARNING ({env}): {msg}")

# Governed release gates: an ACTIVE product in PROD must be reproducible (git_commit) AND golden-
# compared (reference_table), else the release ledger can't pin the build or prove it didn't drift.
# Waivable for smoke tests via allow_governed_waiver; dev runs and scaffolds are unaffected.
waiver = (dbutils.widgets.get("allow_governed_waiver") or "").strip().lower() in ("1", "true", "yes")  # noqa: F821

# A WAIVER MAY NOT PUBLISH, and neither may a prod run whose pack is not release-ready.
#
# The waiver is documented as a smoke-test bypass: it drops the git_commit and reference_table
# requirements and turns REQUIRED deliverables optional. Nothing stopped it continuing through build,
# QC, staging and the public view swap — there was no validate-only path anywhere in the runner or
# the bundle (`validate_only`, `no_publish`, `dry_run`: zero occurrences). So the switch for "I am
# only checking the plumbing" could replace what analysts read.
#
# Now it is mechanical rather than procedural: the run EXITS below, before the release phase. Staging
# is written — that is what makes the smoke test worth running — and the versioned release tables, the
# release pointer and the public swap are never reached. This comment said the versioned tables were
# still written, which was true of the version before the exit moved; a stale comment about where a
# release begins is the last thing that should be left lying beside the guard that decides it.
may_publish = not waiver and (env != "prod" or release_ready)
if not may_publish:
    _why = "allow_governed_waiver is set" if waiver else "the pack is not release-ready"
    print(f"VALIDATE-ONLY: {_why} — this run will build, QC and stage, and will NOT swap any public "
          f"view. The current public tables stay on the previous build.")
if governed and not waiver:
    missing = [w for w in ("git_commit", "reference_table")
               if not (dbutils.widgets.get(w) or "").strip()]   # noqa: F821
    if missing:
        raise RuntimeError(
            f"PROD/active refusing to run: {missing} required for a governed release "
            "(git_commit pins reproducibility; reference_table runs the golden gate). "
            "Pass them, or --var allow_governed_waiver=true for a smoke test.")

# Fail fast on a bad config. Then THE SNAPSHOT, before anything reads data: the probe used to sit
# between preflight and source QC, so one run's readers saw different moments — preflight over
# version N, the build over pinned N, source QC over whatever had landed by then. Probe FIRST;
# preflight, source QC, the build and the goldens all consume the same pinned inputs, and the
# pins carry TABLE IDENTITY (id + location), not just a version of whatever now wears the name.
check(cfg)

# INPUT LINEAGE: {source: [{fqn, table_id, delta_version, last_commit_at} | {fqn, error}]}.
# Per-table failures are RECORDED entries, never raises — a non-Delta input is a fact the ledger
# must carry, not a reason to hide the rest.
def _probe_source_lineage(cfg_):
    out = {}
    for _name in sorted(cfg_.sources):
        try:
            _fqns = cfg_.source_fqns(_name)
        except Exception as _e:   # noqa: BLE001
            out[_name] = [{"fqn": f"({_name} unresolved)", "error": str(_e)}]
            continue
        rows = []
        for _fqn in _fqns:
            try:
                _h = spark.sql(f"DESCRIBE HISTORY {_fqn} LIMIT 1").collect()[0].asDict()   # noqa: F821
                _d = spark.sql(f"DESCRIBE DETAIL {_fqn}").collect()[0].asDict()            # noqa: F821
                rows.append(rel.input_lineage_row(_fqn, _h, _d))
            except Exception as _e:   # noqa: BLE001
                rows.append({"fqn": _fqn, "error": str(_e)})
        out[_name] = rows
    return out

src_lineage = _probe_source_lineage(cfg)
_pinned = sum(1 for v in src_lineage.values() for e in v if e.get("table_id"))
_unpinned = sum(1 for v in src_lineage.values() for e in v if e.get("error"))
print(f"Source lineage: {_pinned} table(s) pinned (id+version), {_unpinned} not probe-able")
# FULL ENTRIES as pins, not bare versions: `sources._read` verifies the table id around every
# pinned read, so version N of a dropped-and-recreated table — a different Delta log wearing a
# familiar name — is a refusal, not a silent substitution.
_pins = {e["fqn"]: e for v in src_lineage.values() for e in v
         if e.get("delta_version") is not None}
if env == "prod" and _unpinned:
    raise RuntimeError(
        f"CANDIDATE REFUSED — {_unpinned} source table(s) could not be pinned in a prod run. A "
        f"candidate that could later publish must carry complete input identities; discovering "
        f"the gap at promotion time is after the approver signed it.")

# THE ADAPTER CONTRACT, evaluated-when-present and REVIEWED-OR-REFUSED at runtime — and, when
# it holds, CONSUMED: the compiled bindings become what the loader reads, so the adapter is the
# source of truth rather than a parallel map. A pack with no config/source_adapters.yaml has
# made no claim (the loader binds through cfg.sources as it always has). A pack that HAS
# committed one gets held to it BEFORE preflight touches a single table: problems refuse, an
# unreviewed adapter set refuses (a live run must not proceed on a binding nobody signed), a
# declared schema/cut must match the run's own identity, and a role the adapter and cfg.sources
# resolve DIFFERENTLY refuses the run — two claims about one physical table were the silent
# divergence an external adversarial campaign named (`mc.rx_claims` reviewed, `t_drugepisode`
# read). One truth: a person fixes whichever is wrong.
import source_adapter as _source_adapter                             # noqa: E402
_ad = _source_adapter.check(os.path.dirname(os.path.dirname(config_path)))   # noqa: F821
if _ad.get("state") == "unreadable" or _ad.get("problems"):
    raise SystemExit("SOURCE ADAPTERS REFUSED — the committed adapter contract has problems; "
                     "fix or remove it, a broken claim must not read as no claim:\n  "
                     + "\n  ".join(_ad.get("problems") or ["unreadable"]))
if _ad.get("state") == "checked":
    if not _ad.get("all_reviewed"):
        raise SystemExit("SOURCE ADAPTERS REFUSED — the adapter set is committed but not "
                         "every adapter carries review.status: reviewed. A live run binds "
                         "delivered data through a signed adapter or not at all.")
    for _k, _want, _have in (("schema", _ad.get("schema"), cfg.source_schema),
                             ("cut", _ad.get("cut"), cfg.refresh)):
        if _want and str(_want) != str(_have):
            raise SystemExit(f"SOURCE ADAPTERS REFUSED — the adapter set binds {_k} "
                             f"{_want!r} and this run is {_have!r}; an adapter reviewed "
                             f"against one delivery must not silently govern another.")
    if cfg.source_union:
        raise SystemExit("SOURCE ADAPTERS REFUSED — an adapter set binds ONE delivery and "
                         "this run declares a multi-schema source_union; the two cannot "
                         "both govern which physical tables are read.")
    _plan = _source_adapter.compiled(os.path.dirname(os.path.dirname(config_path)))
    if _plan.get("state") != "compiled":
        raise SystemExit("SOURCE ADAPTERS REFUSED — the set checked clean but did not "
                         "compile:\n  " + "\n  ".join(_plan.get("problems") or ["unknown"]))
    _dis = {r: (t, cfg.table(r)) for r, t in sorted(_plan["bindings"].items())
            if r in cfg.sources and str(t) != str(cfg.table(r))}
    if _dis:
        raise SystemExit("SOURCE ADAPTERS REFUSED — the reviewed adapter and cfg.sources "
                         "resolve the same role to DIFFERENT physical tables; one truth, "
                         "fix whichever is wrong:\n  "
                         + "\n  ".join(f"{r}: adapter {t!r} vs config {c!r}"
                                       for r, (t, c) in _dis.items()))
    cfg.bind_sources(_plan["bindings"], _plan["digest"], _plan["dataset"])
    print(f"source adapters: {len(_plan['bindings'])} reviewed binding(s) for dataset "
          f"{_plan.get('dataset')!r} govern this run (digest {_plan['digest'][:16]})")

from engine.stages import sources as _sources_mod   # noqa: E402
preflight(spark, cfg,   # noqa: F821
          _table_reader=lambda fqn: _sources_mod._read(spark, fqn, _pins).columns)

src_qc = run_source_qc(spark, cfg, pins=_pins)   # noqa: F821
src_gate = source_qc_gate(src_qc, (cfg.raw.get("qc") or {}).get("source_thresholds"))

# DECLARED SOURCE GRAIN, checked against the delivered rows before anything joins on it. Attached
# to the manifest ONLY when the pack declares one: an empty declaration is "no claim", and the
# composite verdict then reports "source grain" as not evaluated rather than inventing a pass.
# A one-row-per-key consumer downstream (`dropDuplicates`, `one_row_per_key`) takes an arbitrary
# row from every duplicated key, so a failed declaration here is the cheap, named version of a
# defect that otherwise surfaces as an unreproducible value in a published column.
from engine import grain as _grain                                   # noqa: E402
from engine import validate as _validate                             # noqa: E402
from pyspark.sql import functions as _F                              # noqa: E402
source_grain = None
if _validate.source_grain(cfg)[0]:
    from engine.stages import sources as _sources                    # noqa: E402
    _grain_report = _grain.source_grain_report(_F, _sources.load(spark, cfg, _pins), cfg)  # noqa: F821
    source_grain = dict(_grain.source_grain_gate(_grain_report), report=_grain_report)
    for _u in source_grain["unchecked"]:
        print(f"source-grain UNCHECKED: {_u}")
    for _f in source_grain["failures"]:
        print(f"source-grain FAILURE: {_f}")
print("Source QC:\n" + json.dumps({**src_qc, "_gate": src_gate}, indent=2, default=str))
# Persist the verdict on BOTH paths. This is the machine-readable end of the loop that used to run
# through a person reading DISTINCT results out of a SQL editor: `source_check --preflight` folds
# this file's verdicts into the pack's committed report — pass/fail and config-owned strings only.
try:
    from engine.qc import source_qc_evidence
    dbutils.fs.put(f"{artifact_root}/source_qc.json",   # noqa: F821
                   json.dumps(source_qc_evidence(
                       cfg, src_qc, src_gate,
                       generated_at=datetime.now(timezone.utc).isoformat(),
                       git_commit=dbutils.widgets.get("git_commit") or None),   # noqa: F821
                       indent=2, default=str), True)
except Exception as e:   # noqa: BLE001
    print(f"(could not persist source-QC verdicts to {artifact_root}: {e})")
if not src_gate["passed"]:
    # Persist the FAILED source-QC as a durable evidence manifest (== the ADS/golden gate-fail path)
    # so a refusal-to-build leaves an audit record, not just a job log. Best-effort: job fails anyway.
    m = build_manifest(cfg, tumor=tumor, family=family, source_lineage=src_lineage, git_commit=dbutils.widgets.get("git_commit") or None,  # noqa: F821
                       source_qc=src_qc, source_qc_gate=src_gate, config_identity=_config_identity,
                       run_mode=_run_mode)
    print("Manifest (SOURCE-QC GATE FAILED):\n" + json.dumps(m, indent=2, default=str))
    try:
        import yaml   # noqa: E402
        dbutils.fs.put(f"{artifact_root}/manifest.yaml",   # noqa: F821
                       yaml.safe_dump(m, sort_keys=False), True)
    except Exception as e:   # noqa: BLE001
        print(f"(could not persist failed source-QC manifest to {artifact_root}: {e})")
    raise RuntimeError(f"Source QC gate FAILED before build: {src_gate['failures']}")

# COMMAND ----------
# Build -> STAGING -> ADS QC + gate (temp-then-swap: a bad refresh never overwrites the final ADS).
final = cfg.output_fqn
# BUILD-SCOPED, and named by `engine.release` like every other release table — see `staging_ads` there
# for why one shared `__staging` name is unsafe. Cleanup after a successful publish still drops them,
# so this does not accumulate on the happy path.
staging = rel.staging_ads(final, build_id)
def _assert_swappable(name):
    """A public name must be FREE or already a VIEW (publish = CREATE OR REPLACE VIEW). A pre-pointer
    deployment may hold it as a TABLE -> fail clearly so an operator migrates it ONCE (we never
    auto-drop a table consumers may read). A missing name / an existing VIEW is a no-op.

    Gate on tableExists (not-found -> nothing to migrate) so a DESCRIBE failure on an object that DOES
    exist (permission denied, metastore outage, bad identifier) PROPAGATES — we never silently treat a
    metadata-read error as 'missing' and defer the real failure to the swap."""
    if not spark.catalog.tableExists(name):   # noqa: F821  not found -> nothing to migrate
        return
    typ = next((r["data_type"] for r in spark.sql(f"DESCRIBE EXTENDED {name}").collect()   # noqa: F821
                if (r["col_name"] or "").strip() == "Type"), "")
    if typ and typ.strip().upper() != "VIEW":
        raise RuntimeError(f"Public name {name} already exists as a {typ.strip()} (pre-pointer "
                           "deployment); the release pointer needs a VIEW. Drop/rename it once, or use "
                           "a clean output schema.")
# Migration guard, fail-FAST (BEFORE the expensive build): the ADS public name must be free or already a
# VIEW. (The public TFL names are guarded once their ids are known, just before the swap — see below.)
_assert_swappable(final)


def _observe_public_views(final_name, tfl_ids):
    """{public view: the versioned table it serves, or None}. ONE observer, both release paths.

    The candidate run records this so the approver signs which release is being replaced; the
    promotion run re-reads it and refuses a difference. Two implementations would be two answers to
    "what is live now", and only one of them would be the one that was signed.

    A view that does not exist yields None — a real state (no release yet), not a gap. Reading its
    `View Text` is the inverse of the `CREATE OR REPLACE VIEW` this release module writes, so
    `release.view_target` owns the parse.
    """
    out = {}
    for pub in [final_name] + [rel.public_tfl(final_name, t) for t in (tfl_ids or [])]:
        text = None
        if spark.catalog.tableExists(pub):                                     # noqa: F821
            text = next((r["data_type"] for r in                                # noqa: F821
                         spark.sql(f"DESCRIBE EXTENDED {pub}").collect()        # noqa: F821
                         if (r["col_name"] or "").strip() == "View Text"), None)
        out[pub] = text
    return rel.observed_release(out)


def _write_journal(path, journal):
    """Persist the promotion journal. THE ONE WRITER, so every state change looks the same.

    `dbutils.fs.put(..., True)` raises on failure rather than returning it — which is what this
    needs: a state change that was not durably recorded has not happened, and continuing past a
    failed journal write would put the run into exactly the undetectable split state the journal
    exists to remove.
    """
    import yaml as _yaml
    dbutils.fs.put(path, _yaml.safe_dump(journal, sort_keys=False), True)   # noqa: F821
    print(f"   journal      {journal.get('state')}")


def _probe_candidate_tables(tables):
    """[assembled identity row] for each table, in order. ONE probe, used by BOTH release paths.

    The candidate run records these into the manifest before it is hashed; the promotion run re-runs
    the same probe and compares. Two implementations of "what a staged table's identity is" would be
    two answers to the question the whole gate turns on, and only one of them would be the one the
    approver signed.

    A FAILURE IS RAISED, NOT LOGGED. The first version caught per-table exceptions and carried on with
    whatever succeeded — so a candidate could be signed with one table measured and another not, and
    promotion then published the unmeasured one from live staging. There is no useful partial answer
    here: either every table this release covers is identified, or the candidate cannot be approved.
    """
    out = []
    for t in tables:
        _hist_sql, _detail_sql = rel.candidate_probe_statements(t)
        _hist = spark.sql(_hist_sql).collect()[0].asDict()        # noqa: F821
        _detail = spark.sql(_detail_sql).collect()[0].asDict()    # noqa: F821
        _n = spark.sql(rel.count_at_version_sql(                  # noqa: F821
            t, _hist["version"])).collect()[0]["row_count"]
        out.append(rel.candidate_row(t, _hist, _detail, _n))
    return out

# COMMAND ----------
# PROMOTION — publish an already-approved candidate, and BUILD NOTHING.
#
# This is the task that lets an approval complete. Every other path here mints a build_id, which moves
# the manifest digest, which is why an approval naming build A was unsatisfiable by any later run: the
# only way to honour it is to publish A's bytes. So this branch sits BEFORE `build()` and exits from
# inside itself — a promotion that could fall through to a build would be the defect it exists to
# remove, wearing the right name.
#
# What it verifies, in order, refusing at the first failure:
#   1. the PERSISTED candidate manifest for this build exists and still hashes to what it hashed then
#   2. a named approval binds THIS build_id and THAT digest        (publish_approval_errors, Gate 6)
#   3. the approved bytes are still staged, and this build is not already promoted
#                                                                  (release.promotion_blockers)
# Only then does it materialise the immutable versioned tables from staging and swap the public views.
_require_published = (dbutils.widgets.get("require_published") or "").strip().lower() \
    in ("true", "1", "yes")   # noqa: F821


def _stop_without_publishing(state, detail=""):
    """A NORMAL exit for a build/candidate job; a FAILURE for a job that promised publication.

    `dbutils.notebook.exit("awaiting_release_approval")` is a normal exit, so an orchestrator
    watching only job status reported SUCCESS while no public view moved. The exit VALUE was always
    machine-readable; nothing obliged the machine to read it. A publication job sets
    require_published=true and every stop short of a completed publication becomes a loud failure —
    candidate jobs keep their green stops, because staging-without-publishing is that job's job.
    """
    if _require_published:
        raise RuntimeError(f"REQUIRE_PUBLISHED is set and this run stopped at '{state}' with no "
                           f"publication. {detail}".rstrip())
    dbutils.notebook.exit(state)   # noqa: F821


if promote_build_id:
    # ONE state machine publishes, in EVERY environment. Refusing dev promotions forced dev onto a
    # second, weaker publish path — the exact fork the review condemned. Authorization is the
    # approval file plus Gates 1-4, not the workspace's name; a dev promotion moves dev views under
    # the same lock, journal and receipt discipline, which is precisely what SIT has to exercise.
    # GATES 1-4, THROUGH THE SAME PREDICATE EVERY OTHER PUBLISH PATH USES. Promotion runs before the
    # build and therefore before the validate-only stop, so it does not inherit that stop — and the
    # first version of this block did not re-assert it. A pack failing Gates 1-4, plus a hand-written
    # RELEASE_APPROVAL.yaml naming a build id, would have published: Gate 6 satisfied, Gates 1-4 never
    # asked. `publish_approval_errors` is Gate 6 ALONE and was never going to catch that.
    if not may_publish:
        raise RuntimeError(
            "PROMOTION REFUSED — this pack may not publish: " +
            ("a governed waiver is set" if waiver else
             f"Gates 1-4 are not all passed ({'; '.join(release_blockers[:3])})") +
            ". An approval of one build does not substitute for the gates the product itself has "
            "not passed.")
    _cand_path = f"{artifact_root}/manifest.yaml"
    try:
        _cand_bytes = dbutils.fs.head(_cand_path, 16 * 1024 * 1024)   # noqa: F821
    except Exception as _e:                                           # noqa: BLE001
        raise RuntimeError(
            f"PROMOTION REFUSED — no candidate manifest at {_cand_path} ({_e.__class__.__name__}). "
            f"Promotion publishes what a build already staged and approved; it does not rebuild. If "
            f"the candidate is gone, build again and have the NEW candidate approved.")
    import yaml   # noqa: E402
    _cand_sha = hashlib.sha256(_cand_bytes.encode("utf-8")).hexdigest()
    print(f"Promoting build {build_id}; candidate manifest sha256 {_cand_sha}")

    _why = publish_approval_errors(str(_repo), _rel, build_id, _cand_sha)
    if _why:
        raise RuntimeError("PROMOTION REFUSED — no approval binds this build:\n  " +
                           "\n  ".join(_why[:8]))
    # THE ACCOUNTABLE NAME, from the form that check just accepted. `validate_manifest` requires
    # `sign_off.released_by` on a released manifest, and the release approver IS that person — taking
    # it from anywhere else (the job's service principal, the git author) would put a name on a
    # governed record that nobody wrote there.
    from engine.strict_yaml import strict_load
    with open(os.path.join(str(_repo), _rel, "handoff", "RELEASE_APPROVAL.yaml"),
              encoding="utf-8") as _fh:
        _approval_doc = strict_load(_fh) or {}       # duplicate keys REFUSE — a second
    _approval_actor = str(_approval_doc.get("approved_by") or "").strip()     # `approved_by:` line
    _validated_by = str(_approval_doc.get("validated_by") or "").strip()      # must never silently
    _validation_date = str(_approval_doc.get("validation_date") or "").strip()  # replace the first
    # The HUMAN's date, from the form the human signed. `released_date` used to copy
    # `published_at`, restating publication time in a field that exists to date the approval —
    # `published_at` already owns the machine's clock, and a receipt whose two dates always agree
    # is one that cannot show an approval that predates its publication.
    _approval_date = str(_approval_doc.get("approval_date") or "").strip()

    # STRICT, AND NEVER EMPTY-AS-ABSENT. The candidate is the subject of a signed approval:
    # a duplicate key loading last-wins would publish a candidate the approver never read, and a
    # zero-byte file parsing to {} would sail through as a manifest that simply lacks fields.
    if not str(_cand_bytes or "").strip():
        raise RuntimeError(
            f"PROMOTION REFUSED — the candidate manifest at {_cand_path} is EMPTY. An empty "
            f"candidate is a malformed one, not a lenient one; rebuild and re-approve.")
    _cand = strict_load(_cand_bytes) or {}
    # THE CONFIG FREEZE. Everything below resolves names — the versioned tables, the pointer, the
    # receipt's spec_version — from the CURRENT config, and the approval signed a candidate built
    # under the config of ITS day. Nothing compared the two, so a candidate built and approved
    # under 202606 promoted cleanly after the pack moved to 202612, the receipt validating because
    # every field was filled from the same wrong place. Refused before anything else is read.
    _unbound = rel.candidate_binding_blockers(_cand, spec_version=str(cfg.spec_version),
                                              refresh=str(cfg.refresh), output_fqn=final,
                                              config_identity=_config_identity,
                                              require_release_grade=governed)
    if _unbound:
        raise RuntimeError(
            "PROMOTION REFUSED — the runtime configuration is not the one this candidate was "
            "approved under:\n  " + "\n  ".join(_unbound))
    _tfl_ids = sorted((_cand.get("release") or {}).get("tfls", {}) or
                      {k[4:]: v for k, v in (_cand.get("artifacts") or {}).items()
                       if k.startswith("tfl_")})
    # EXISTENCE, ASKED OF EACH EXACT IDENTIFIER. `listTables(schema)` returns a bare `.name` per row
    # — `prostate_ads__staging__b9` — and every name this module builds is fully qualified through
    # `cfg.output_fqn` (`catalog.schema.table`). Comparing the two sets matched nothing, so promotion
    # would have reported every staged table missing and refused every candidate. It fails closed,
    # which is why nothing offline noticed: the wrong answer and the safe answer were the same word.
    # BOTH SIDES OF EACH PAIR. The first version took only the staging name, so the "already
    # promoted" refusal — which fires when the VERSIONED table exists — had nothing to fire on: a
    # second promotion of a build whose tables were already published would have re-materialised over
    # them. Found by running it against real Delta; no string test could see which element of a tuple
    # was being read.
    _existing = {t for _pair in rel.promotion_pairs(final, cfg.refresh, build_id, _tfl_ids)
                 for t in _pair if spark.catalog.tableExists(t)}                # noqa: F821
    # RE-PROBE THE STAGED TABLES *NOW*, and compare against what the signed manifest recorded. The
    # existence check above answers "is there a table called this"; a candidate is not a name, and
    # this is the step that asks whether what is behind the name is what somebody signed.
    #
    # DRIVEN BY WHAT THIS PROMOTION WILL PUBLISH, not by what the manifest happens to record. Reading
    # the recorded keys meant a candidate signed with one table missing was re-probed with that table
    # missing too — the gap absent from both sides of the comparison, and the table then published
    # unpinned. `identity_blockers` is given the expected set and refuses any mismatch.
    _pairs = rel.promotion_pairs(final, cfg.refresh, build_id, _tfl_ids)
    _approved_identity = _cand.get("candidate_identity") or {}
    _observed_identity = rel.candidate_identity(
        _probe_candidate_tables([t for _v, t in _pairs]))

    # THE RECEIPT, VALIDATED BEFORE ANYTHING MOVES. The old order could reach its own error state —
    # "PUBLISHED, AND THE RECEIPT IS INVALID" — because validation ran after the view swap. Build
    # the complete prospective released receipt NOW, exactly as the success path will write it, and
    # refuse while nothing public has been touched and no lock is held.
    _prospective = dict(_cand)
    _prospective["status"] = "released"
    _prospective["published_at"] = datetime.now(timezone.utc).isoformat()
    _prospective["release"] = rel.release_pointer(final, cfg.refresh, build_id, _tfl_ids,
                                                  spec_version=str(cfg.spec_version))
    _prospective["tfl_promotion"] = {"passed": True, "promoted": list(_tfl_ids),
                                     "via": "promote_build_id"}
    _prospective["sign_off"] = {**(_cand.get("sign_off") or {}),
                                "released_by": _approval_actor,
                                "released_date": _approval_date,
                                "qc_by": _validated_by, "qc_date": _validation_date}
    _pre_bad = validate_manifest(_prospective)
    if _pre_bad:
        raise RuntimeError(
            "PROMOTION REFUSED — the receipt this promotion would write is invalid, and nothing "
            "public has moved:\n  " + "\n  ".join(_pre_bad) +
            "\nFix the candidate or the approval and re-run; refusing now is the whole point of "
            "validating before the lock.")

    # ONE PROMOTION PER PRODUCT AT A TIME, taken before anything is read that a concurrent run could
    # change under us. Two promotions interleaving their view swaps leave the public set mixed — A's
    # TFL beside B's ADS, each run believing it published a consistent release. The swap order bounds
    # what a consumer sees within ONE run and says nothing about two.
    # THE JOURNAL, READ BEFORE THE LOCK — re-entering a lock is only legitimate for a CRASHED
    # attempt, and the journal is how a crashed attempt is told apart from a live duplicate.
    _journal_path = f"{artifact_root}/promotion_state.yaml"
    try:
        _journal_text = dbutils.fs.head(_journal_path, 4 * 1024 * 1024)       # noqa: F821
    except Exception as _e:                                                    # noqa: BLE001
        # ABSENT is a first attempt — but only genuinely absent. A permission error, a network
        # fault or a misconfigured root read as "no journal" would replay the side effects the
        # journal exists to prevent; anything that is not file-not-found refuses instead.
        _etxt = f"{_e.__class__.__name__}: {_e}"
        if not ("FileNotFound" in _etxt or "does not exist" in _etxt or "NOT_FOUND" in _etxt):
            raise RuntimeError(
                f"PROMOTION REFUSED — {_journal_path} could not be read ({_etxt[:300]}). An "
                f"UNREADABLE journal is not an absent one; treating it as a first attempt could "
                f"replay work it records. Fix the read and re-run.") from _e
        _journal_text = None                          # ABSENT is a first attempt...
    if _journal_text is None:
        _journal = {}
    elif not str(_journal_text).strip():
        # a ZERO-BYTE journal file is a write that started and never finished — malformed, never
        # absent: parsing it to {} would replay side effects the vanished content recorded.
        raise RuntimeError(
            f"PROMOTION REFUSED — {_journal_path} exists and is EMPTY: a journal write started "
            f"and never finished, and what it recorded is gone. A person inspects the partial "
            f"state; this run will not treat a torn journal as a first attempt.")
    else:
        try:
            _journal = strict_load(_journal_text) or {}   # duplicate keys REFUSE — two writers'
        except Exception as _e:                           # interleaved fields must not last-win
            raise RuntimeError(
                f"PROMOTION REFUSED — {_journal_path} exists and will not parse ({_e}). "
                f"...but MALFORMED is not 'no journal': it may describe half-finished public "
                f"work. A person inspects it; this run will not guess.")

    # RECEIPTED IS TERMINAL — decided BEFORE the lock, before any read a rerun could act on. A
    # completed promotion re-run is not a resume: an external review replayed a receipted journal
    # after a NEWER build had published, and the "resume" re-emitted every swap and rewrote the
    # pointer, rolling consumers backwards. A rerun of a completed promotion verifies the receipt
    # it wrote and exits `already_promoted` — a NORMAL exit even under require_published, because
    # the publication this job promised exists; it issues no SQL either way.
    if _journal.get("state") == rel.PROMOTION_STATES[-1]:
        _receipt_path = _journal.get("published_manifest") or f"{artifact_root}/published_manifest.yaml"
        try:
            _receipt_text = dbutils.fs.head(_receipt_path, 16 * 1024 * 1024)   # noqa: F821
            if not str(_receipt_text).strip():
                raise RuntimeError("the receipt file is empty")
            _receipt = strict_load(_receipt_text) or {}
        except Exception as _e:                                                # noqa: BLE001
            raise RuntimeError(
                f"PROMOTION REFUSED — the journal says this promotion is COMPLETE (receipted) but "
                f"its receipt at {_receipt_path} cannot be read ({_e.__class__.__name__}: {_e}). "
                f"A terminal journal with no readable receipt is an inspection case, never a "
                f"resume.")
        if str((_receipt.get("release") or {}).get("build_id") or "") != str(build_id):
            raise RuntimeError(
                f"PROMOTION REFUSED — this promotion is receipted and the receipt names build "
                f"{(_receipt.get('release') or {}).get('build_id')!r}, not {build_id!r}. A "
                f"person inspects the receipt; this run will not republish.")
        _rbad = validate_manifest(_receipt)
        if _rbad:
            raise RuntimeError(
                "PROMOTION REFUSED — this promotion is receipted and its receipt does not "
                "validate:\n  " + "\n  ".join(_rbad) +
                "\nA person inspects the receipt; this run will not republish.")
        # THE AUDIT EVIDENCE, VERIFIED — AND REPAIRED — AT THE TERMINAL. A crash between the
        # receipt and the bundle write used to leave a live release with no evidence bundle, a
        # held lock, and a terminal journal; every retry then exited green ("already_promoted")
        # over the missing evidence, forever. Terminal verification now finishes the two
        # idempotent tail steps the crash interrupted: rebuild the bundle from the verified
        # receipt when the journal does not record it, and release THIS build's own leftover
        # lock. Neither issues promotion SQL; both are exactly what the crashed run would have
        # done next.
        if not _journal.get("audit_bundle"):
            _bundle = audit.build_bundle(
                _receipt, ((_receipt.get("deliverables") or {}).get("tfls") or {}).get("tfl_qc"))
            for _bn, _bo in _bundle.items():
                _body = _bo if isinstance(_bo, str) else json.dumps(_bo, indent=2, default=str)
                dbutils.fs.put(f"{artifact_root}/{_bn}", _body, True)   # noqa: F821
            _journal["audit_bundle"] = sorted(_bundle)
            _write_journal(_journal_path, _journal)
            print(f"   repaired     audit bundle ({len(_bundle)} files) -> {artifact_root}")
        _lock = rel.promotion_lock(final)
        if spark.catalog.tableExists(_lock):                                   # noqa: F821
            _lrows = [r.asDict() for r in spark.table(_lock).collect()]        # noqa: F821
            if len(_lrows) == 1 and str(_lrows[0].get("build_id")) == str(build_id):
                # this COMPLETE promotion's own leftover lock (the crash landed between the
                # bundle and the release) — anything else stays for its owner to deal with
                spark.sql(rel.release_lock_sql(final))   # noqa: F821
                print(f"   released     {_lock} (left behind after completion)")
        print(f"Build {build_id} was already promoted (receipt verified at {_receipt_path}); "
              f"nothing to do and nothing will be re-run.")
        dbutils.notebook.exit("already_promoted")   # noqa: F821

    # ...AND A STALLED RESUME MUST NOT ROLL THE RELEASE BACKWARDS. The supersedes comparison is
    # skipped past `views_switched` (there the observed state is this run's own work), which is
    # exactly where a NEWER release published since the crash became invisible. The pointer is the
    # commit anchor, so it decides: a pointer naming another build kills this resume.
    if _journal and spark.catalog.tableExists(rel.release_pointer_table(final)):   # noqa: F821
        _roll = rel.rollback_blockers(
            _journal, [r.asDict() for r in spark.table(rel.release_pointer_table(final)).collect()])  # noqa: F821
        if _roll:
            raise RuntimeError("PROMOTION REFUSED — " + "\n  ".join(_roll))

    # EVERY INVOCATION IS ITS OWN ATTEMPT. Same build id is NOT the same attempt: a live concurrent
    # duplicate of this build wears the same build_id as a crashed one, and the old lock check could
    # not tell them apart — an external review's concurrency probe interleaved two promotions of ONE
    # build through exactly that gap. The attempt id is minted here, recorded in the lock row, and a
    # held lock of this build now BLOCKS unless the operator names the held attempt in
    # `resume_promotion` — inspection as an argument, never inferred from a build id.
    import uuid   # noqa: E402
    _attempt_id = uuid.uuid4().hex
    _resume_promotion = (dbutils.widgets.get("resume_promotion") or "").strip()   # noqa: F821

    _lock = rel.promotion_lock(final)
    _holder = None
    if spark.catalog.tableExists(_lock):                                       # noqa: F821
        _rows = [r.asDict() for r in spark.table(_lock).collect()]             # noqa: F821
        # ZERO rows, TWO rows, or an incomplete row is a MALFORMED lock, never an absent one —
        # `rows[0]` over an empty table used to read as "no holder" and proceed unserialised.
        _lock_bad = rel.lock_row_errors(_rows)
        if _lock_bad:
            raise RuntimeError("PROMOTION REFUSED — " + "\n  ".join(_lock_bad))
        _holder = _rows[0]
    _held = rel.lock_blockers(_holder, build_id, _attempt_id, _resume_promotion)
    if _held:
        raise RuntimeError("PROMOTION REFUSED — " + "\n  ".join(_held))
    if _holder is None:
        # `CREATE TABLE` on an existing name is refused by the metastore — verified against Delta,
        # not assumed. That refusal IS the mutex; a race between the check above and this statement
        # loses here rather than proceeding, which is the direction a lock has to fail in.
        spark.sql(rel.acquire_lock_sql(final, build_id, _approval_actor,       # noqa: F821
                                       datetime.now(timezone.utc).isoformat(),
                                       attempt_id=_attempt_id))
        print(f"   lock         {_lock}  (attempt {_attempt_id})")
    else:
        # An explicitly-named dead attempt with no journal has nothing to resume — it died before
        # recording intent, so there is no record separating "made nothing" from "made something
        # unaccounted for". That lock is dropped by a person, not taken over by a run.
        if not _journal:
            raise RuntimeError(
                "PROMOTION REFUSED — the lock names a dead attempt of this build and no journal "
                "exists: it died before recording intent, so nothing separates 'did nothing' from "
                "'made something unaccounted for'. Inspect and drop the lock deliberately; this "
                "run will not assume.")
        # THE TAKEOVER IS A COMPARE-AND-SET, and the CAS — not the token — decides. Naming the
        # dead attempt in `resume_promotion` only authorises this UPDATE; its predicate is (build,
        # old attempt) and it installs THIS attempt, so the token is consumed the moment one
        # takeover commits. A second presenter of the same token matches ZERO rows and is refused
        # below — an external review ran two takeovers of one dead attempt through the read-only
        # version of this check.
        spark.sql(rel.takeover_lock_sql(final, build_id, _resume_promotion, _attempt_id,   # noqa: F821
                                        _approval_actor, datetime.now(timezone.utc).isoformat()))
        _now_rows = [r.asDict() for r in spark.table(_lock).collect()]         # noqa: F821
        _lock_bad = rel.lock_row_errors(_now_rows)
        if _lock_bad:
            raise RuntimeError("PROMOTION REFUSED — after takeover: " + "\n  ".join(_lock_bad))
        if str(_now_rows[0].get("attempt_id")) != _attempt_id:
            raise RuntimeError(
                f"PROMOTION REFUSED — the takeover LOST: the lock now belongs to attempt "
                f"{_now_rows[0].get('attempt_id')!r}, not this run's {_attempt_id!r}. Another "
                f"takeover of the same dead attempt committed first; exactly one may win, and it "
                f"was not this one.")
        print(f"   lock         {_lock} (attempt {_attempt_id} took over inspected dead attempt "
              f"{_resume_promotion} via compare-and-set)")

    def _assert_lock_owned():
        """The lock still belongs to THIS attempt — asked before every journal write.

        A journal write is a claim about the promotion's state, and a claim recorded by an attempt
        that no longer holds the lock is another run's history being overwritten. Re-reading one
        row per state change is cheap; the alternative is two interleaved journals wearing one
        file name.
        """
        _r = [x.asDict() for x in spark.table(_lock).collect()]                # noqa: F821
        _own_bad = rel.lock_row_errors(_r)
        if _own_bad or str(_r[0].get("attempt_id")) != _attempt_id \
                or str(_r[0].get("build_id")) != str(build_id):
            raise RuntimeError(
                "PROMOTION HALTED — this attempt no longer holds the lock "
                f"({_own_bad[0] if _own_bad else 'holder is ' + repr(_r[0])}); refusing to write "
                f"the journal over another attempt's work.")

    _stale = rel.journal_blockers(_journal, build_id, _cand_sha)
    if _stale:
        raise RuntimeError("PROMOTION REFUSED — the journal here describes a different promotion:\n  "
                           + "\n  ".join(_stale))
    if _journal:
        print(f"Resuming promotion of {build_id} from state {_journal.get('state')!r}")
    # WHICH VERSIONED TABLES THIS PROMOTION ALREADY MADE, verified against the approved row count —
    # not assumed from the state alone. A table recorded as ours and holding the wrong rows is a
    # partial write and must stop the run; a table recorded as ours and correct is a completed step.
    _made = [v for _v, _s in _pairs for v in (_v,) if v in _existing]
    _counts = {v: spark.table(v).count() for v in _made}                        # noqa: F821
    _props = {v: {r["key"]: r["value"]
                  for r in spark.sql(f"SHOW TBLPROPERTIES {v}").collect()}      # noqa: F821
              for v in _made}
    # THE OUTPUT'S OWN IDENTITY, re-observed. Count plus a mutable table property was the whole
    # resume comparison, and an external review's probe passed a same-count impostor wearing the
    # expected property. Materialisation journals {table_id, location, delta_version, schema_digest}
    # per table (below); a resume re-probes each existing target the same way and `reconcile`
    # refuses any that is not the table this promotion made.
    _obs_outputs = {v: rel.output_identity_row(_row, spark.table(v).dtypes)     # noqa: F821
                    for v, _row in zip(_made, _probe_candidate_tables(_made))}
    _resuming, _partial = (rel.reconcile(_journal, _existing, _counts, _props,
                                         observed_outputs=_obs_outputs)
                           if _journal else ([], []))
    if _partial:
        raise RuntimeError("PROMOTION REFUSED — an interrupted attempt left work that cannot be "
                           "continued automatically:\n  " + "\n  ".join(_partial))

    _phys = rel.promotion_blockers(final, cfg.refresh, build_id, _tfl_ids, _existing,
                                   _approved_identity, _observed_identity, _resuming)
    if _phys:
        raise RuntimeError("PROMOTION REFUSED — the approved bytes are not promotable:\n  " +
                           "\n  ".join(_phys))

    # THE RELEASE THIS CANDIDATE WAS APPROVED TO REPLACE, still the one live. Skipped once this
    # promotion has already swapped views — past that point the observed state IS this run's own
    # work, and comparing it to what the candidate superseded would refuse its own resume.
    if rel.PROMOTION_STATES.index(_journal.get("state") or rel.PROMOTION_STATES[0]) < \
            rel.PROMOTION_STATES.index("views_switched"):
        _now_public = _observe_public_views(final, _tfl_ids)
        # a view already pointing at THIS build's versioned tables is this promotion's own partial
        # work (a crash between swaps) — comparing it against the pre-approval world refused every
        # legitimate resume. Foreign movement still refuses.
        _sup = _cand.get("supersedes") or {}
        # EXACT equality against THIS promotion's own swap plan — `build_id in str(v)` was a
        # substring test, and a foreign table whose name merely CONTAINS the build id (a suffixed
        # backup, another product embedding it) would have read as this promotion's own work.
        _own = {pub: ver for pub, ver, _s in rel.swap_plan(final, cfg.refresh, build_id, _tfl_ids)}
        _now_public = {k: (_sup.get(k) if (v and v == _own.get(k)) else v)
                       for k, v in (_now_public or {}).items()}
        _moved = rel.supersedes_blockers(_cand.get("supersedes"), _now_public)
        if _moved:
            raise RuntimeError(
                "PROMOTION REFUSED — the release moved after this candidate was approved:\n  " +
                "\n  ".join(_moved))

    # INTENT BEFORE THE FIRST SIDE EFFECT. Written now, while nothing has been created: a crash
    # between here and the first `CREATE TABLE` leaves a journal describing work not yet done, which
    # a retry reconciles to "nothing done" and simply performs. The dangerous order is the other one
    # — create first, record after — because then a crash leaves objects nothing accounts for.
    if not _journal:
        _journal = rel.promotion_intent(final, cfg.refresh, build_id, _tfl_ids,
                                        candidate_sha256=_cand_sha,
                                        approved_identity=_approved_identity,
                                        attempt_id=_attempt_id)
        _assert_lock_owned()
        _write_journal(_journal_path, _journal)

    for _pub, _ver, _ in rel.swap_plan(final, cfg.refresh, build_id, _tfl_ids):
        _assert_swappable(_pub)
    # THE POINTER'S WRITABILITY, PROVED BEFORE ANYTHING PUBLIC MOVES. Pointer creation used to
    # happen after the swaps, so a permission, schema or object-type error on the one table
    # consumers anchor on surfaced with the views already moved — half-published, commit anchor
    # unwritable. Create it now (idempotent) and probe write authority with a DELETE whose
    # predicate matches no row: mutates nothing, authorised like any write, fails while a refusal
    # is still free.
    spark.sql(rel.pointer_create_sql(final))                                   # noqa: F821
    # ...and its SHAPE. `IF NOT EXISTS` keeps an existing table of any schema, and the publishing
    # INSERT is positional — a hand-made or older-schema pointer would corrupt what consumers
    # resolve through, discovered mid-publish. Refused here, while a refusal is still free.
    _ptr_shape = rel.pointer_schema_errors(
        spark.table(rel.release_pointer_table(final)).dtypes)                  # noqa: F821
    if _ptr_shape:
        raise RuntimeError("PROMOTION REFUSED — " + "\n  ".join(_ptr_shape))
    # ...AND ITS FORMAT. The pointer's whole claim is one-transaction atomicity, which is Delta's
    # transaction — an existing same-name table in another format would take the INSERT OVERWRITE
    # without the guarantee the consumers were promised. DESCRIBE DETAIL is the same probe every
    # other identity check uses; an unreadable answer refuses like a wrong one.
    try:
        _ptr_fmt = str(spark.sql(f"DESCRIBE DETAIL {rel.release_pointer_table(final)}")   # noqa: F821
                       .collect()[0].asDict().get("format") or "")
    except Exception as _e:                                                    # noqa: BLE001
        raise RuntimeError(
            f"PROMOTION REFUSED — {rel.release_pointer_table(final)} did not answer DESCRIBE "
            f"DETAIL ({_e.__class__.__name__}) — a pointer whose format cannot be read cannot "
            f"promise an atomic publish.")
    if _ptr_fmt.lower() != "delta":
        raise RuntimeError(
            f"PROMOTION REFUSED — {rel.release_pointer_table(final)} is format {_ptr_fmt!r}, not "
            f"Delta. The pointer's one-transaction atomicity IS Delta's transaction; publishing "
            f"through anything else breaks the only promise the pointer exists to make.")
    spark.sql(rel.pointer_preflight_sql(final))                                # noqa: F821
    print(f"   preflight    {rel.release_pointer_table(final)} writable")
    # THE POINTER IS THE AUTHORITY ON WHAT THIS CANDIDATE SUPERSEDES — the view comparison above
    # is the compatibility surface's answer, and a first attempt must also agree with the COMMIT
    # anchor: a pointer already naming an ADS other than the one this candidate was approved to
    # replace means a publish happened that the approval never saw.
    if rel.PROMOTION_STATES.index(_journal.get("state") or rel.PROMOTION_STATES[0]) < \
            rel.PROMOTION_STATES.index("views_switched"):
        _ptr_now = [r.asDict() for r in                                        # noqa: F821
                    spark.table(rel.release_pointer_table(final)).collect()]   # noqa: F821
        _sup_ads = (_cand.get("supersedes") or {}).get(final)
        if len(_ptr_now) > 1:
            raise RuntimeError(
                f"PROMOTION REFUSED — the release pointer holds {len(_ptr_now)} rows; a consumer "
                f"resolving through it gets an ambiguous answer. Repair it before publishing.")
        if _ptr_now and _sup_ads and str(_ptr_now[0].get("ads") or "") != str(_sup_ads):
            raise RuntimeError(
                f"PROMOTION REFUSED — the release pointer serves {_ptr_now[0].get('ads')!r} and "
                f"this candidate was approved to replace {_sup_ads!r}. A release moved through "
                f"the COMMIT ANCHOR after this candidate was approved; re-approve against what "
                f"is actually live.")
        if _ptr_now and not _sup_ads and final in (_cand.get("supersedes") or {}):
            raise RuntimeError(
                f"PROMOTION REFUSED — this candidate was approved when NOTHING was live "
                f"(supersedes records no release) and the pointer now serves "
                f"{_ptr_now[0].get('ads')!r}. A first release was published after this approval; "
                f"re-approve against it.")
    # MATERIALISE EVERY TABLE, THEN SWAP EVERY VIEW. A failure among the tables leaves the public
    # names on the previous release rather than on half of this one.
    _materialised = []
    for _step, _target, _source, _sql in rel.promotion_plan(final, cfg.refresh, build_id, _tfl_ids,
                                                            _approved_identity, _resuming):
        # THE TABLES BEFORE ANY VIEW, and every materialise VERIFIED before the first swap. The
        # checks above are about the source; this is about the result, and it is the only one that
        # can catch a `VERSION AS OF` resolving to something other than what was approved. Ordering
        # matters: the plan puts every materialise ahead of every swap, so this loop reaches its
        # verification while the public names still serve the previous release.
        if _step == "swap" and _materialised:
            for _ver, _stg in _materialised:
                _want = (_approved_identity.get(_stg) or {}).get("row_count")
                _got = spark.table(_ver).count()   # noqa: F821
                if _want is not None and _got != _want:
                    raise RuntimeError(
                        f"PROMOTION ABORTED BEFORE PUBLISHING — {_ver} holds {_got} row(s) and the "
                        f"approved candidate recorded {_want}. No public view has been swapped, so "
                        f"the previous release is still being served. The journal records this "
                        f"attempt at `prepared`, so a retry will report the partial table and say "
                        f"whether it is safe to drop.")
                print(f"   verified     {_ver}  {_got} row(s)")
            _materialised = []
            # EVERY TABLE MADE AND VERIFIED. Recorded before the first view moves, because that is
            # the boundary where the advice to an operator changes: up to here a partial table is
            # safe to drop, and past here a public view may point at one.
            _journal = rel.advance(_journal, "materialised")
            _assert_lock_owned()
            _write_journal(_journal_path, _journal)
        if _step == "materialise":
            # THE STAGED SOURCE, RE-PROBED AT THE MOMENT IT IS READ. The batch identity check above
            # ran once, before the lock and the journal; each CTAS here runs minutes later, and a
            # write landing in that gap would be published wearing the batch check's blessing. The
            # statement pins `VERSION AS OF`, which fixes WHICH bytes are read — this re-probe is
            # what confirms those bytes still belong to the table that was approved (a
            # drop-and-recreate serves version N from a different Delta log under the same name).
            _now_stg = rel.candidate_identity(_probe_candidate_tables([_source]))
            _shift = rel.identity_blockers({_source: _approved_identity.get(_source) or {}},
                                           _now_stg, expected=[_source])
            if _shift:
                raise RuntimeError(
                    "PROMOTION ABORTED BEFORE PUBLISHING — the staged table moved between the "
                    "identity check and its materialisation:\n  " + "\n  ".join(_shift) +
                    "\nNo public view has been swapped; the previous release is still being served.")
            # INTENT BEFORE THE CREATE. A crash INSIDE the CTAS used to leave a target the journal
            # never mentioned, and the resume fell back to count-plus-property — the exact
            # comparison a same-count impostor already passed. The pending marker makes `reconcile`
            # refuse an identity-less target instead of adopting it.
            _journal.setdefault("outputs", {})[_target] = {"pending": True}
            _assert_lock_owned()
            _write_journal(_journal_path, _journal)
        print(f"   {_step:<12} {_target}")
        # THE FENCE. A displaced writer (its lock taken over while it slept) must lose BEFORE its
        # next side effect, not merely before its next journal write — between its last ownership
        # check and this statement, its CTAS or swap would otherwise land interleaved with the
        # new owner's. Re-asking one row per statement is the cheapest fence this catalog offers.
        _assert_lock_owned()
        spark.sql(_sql)   # noqa: F821
        if _step == "materialise":
            _materialised.append((_target, _source))
            # THE OUTPUT'S IDENTITY, JOURNALED THE MOMENT IT EXISTS. A resume used to confirm a
            # target by row count plus a mutable table property — a same-count impostor wearing the
            # expected property passed an external review's probe. What materialisation just made is
            # recorded as {table_id, location, delta_version, schema_digest}; `reconcile` refuses a
            # later table that disagrees, whatever its count and tag say.
            _journal.setdefault("outputs", {})[_target] = rel.output_identity_row(
                _probe_candidate_tables([_target])[0], spark.table(_target).dtypes)  # noqa: F821
            _assert_lock_owned()
            _write_journal(_journal_path, _journal)
    _journal = rel.advance(_journal, "views_switched")
    _assert_lock_owned()
    _write_journal(_journal_path, _journal)

    # RETIRED TFL VIEWS, NAMED — a spec that stops producing a TFL leaves its old public view
    # serving the PREVIOUS build's data forever. `stale_public_tfls` existed for exactly this and
    # nothing called it (an external review found the dead code); it now feeds the receipt's
    # `retired_tfls` so the ledger says which views a person must retire. Never auto-dropped: the
    # engine does not delete a consumer-readable view.
    _schema, _tbl = final.rsplit(".", 1)
    _existing_tfl_views = [f"{_schema}.{r['tableName']}" for r in                # noqa: F821
                           spark.sql(f"SHOW TABLES IN {_schema}").collect()      # noqa: F821
                           if str(r["tableName"]).startswith(f"{_tbl}__tfl_")]
    _retired = rel.stale_public_tfls(_existing_tfl_views, final, _tfl_ids)
    for _v in _retired:
        print(f"   RETIRED      {_v} — no longer in this release; the view still serves the "
              f"previous build. Retire it manually.")

    # THE ATOMIC COMMIT. Every view above moved one statement at a time and Databricks has no
    # transaction across them, so a consumer reading a TFL view directly could see this build's TFL
    # beside the previous build's ADS. One `INSERT OVERWRITE` of a one-row table is one Delta
    # transaction: a consumer resolving the set through the pointer sees the whole previous release
    # or the whole new one. Written LAST, so the release is published when the pointer says so.
    _published_at = datetime.now(timezone.utc).isoformat()
    spark.sql(rel.pointer_create_sql(final))                                   # noqa: F821
    _assert_lock_owned()                     # the fence, immediately before the COMMIT ANCHOR moves
    spark.sql(rel.pointer_write_sql(final, cfg.refresh, build_id, _tfl_ids,    # noqa: F821
                                    spec_version=str(cfg.spec_version),
                                    published_at=_published_at))
    # READ BACK BEFORE THE RECEIPT. A pointer saying something else is worse than no pointer: it is
    # the one place a consumer is being told to trust over the views.
    _ptr_why = rel.pointer_blockers(
        [r.asDict() for r in spark.table(rel.release_pointer_table(final)).collect()],  # noqa: F821
        final, cfg.refresh, build_id, _tfl_ids,
        spec_version=str(cfg.spec_version), published_at=_published_at)
    if _ptr_why:
        raise RuntimeError(
            "PUBLISHED, AND THE RELEASE POINTER IS WRONG — the public views serve build "
            f"{build_id} and the pointer consumers resolve through does not name it:\n  " +
            "\n  ".join(_ptr_why) + f"\nRe-run the promotion: it resumes from the journal and "
            f"rewrites the pointer without rebuilding or re-materialising anything.")
    print(f"   pointer      {rel.release_pointer_table(final)}")
    _journal = rel.advance(_journal, "pointed")
    _assert_lock_owned()
    _write_journal(_journal_path, _journal)

    # `released`, NOT `published`. The refresh schema's status enum is
    # qc_pending|qc_passed|released|superseded and `published` is not in it, so this receipt could
    # never be committed to the ledger it exists to become — the one artifact proving a governed
    # release, invalid against the repository's own schema. `validate_manifest` additionally requires
    # the companions of `released`, which is why each is set below rather than assumed.
    _cand["status"] = "released"
    # THE POINTER'S TIMESTAMP, not a second reading of the clock. Two `datetime.now()` calls a few
    # statements apart give a manifest and a pointer that disagree about when this release was
    # published — a small lie, in the two artifacts an auditor compares first.
    _cand["published_at"] = _published_at
    _cand["release"] = rel.release_pointer(final, cfg.refresh, build_id, _tfl_ids,
                                           spec_version=str(cfg.spec_version))
    # THE VIEWS DID SWAP — this line is after the swap loop, and the loop raises on any failure.
    _cand["tfl_promotion"] = {"passed": True, "promoted": list(_tfl_ids), "via": "promote_build_id",
                              "retired_tfls": list(_retired)}
    # `released_date`, the manifest schema's own key — `released_at` put the release timestamp in
    # a slot nothing downstream reads, so the receipt looked signed but undated to every consumer.
    _cand.setdefault("sign_off", {}).update(
        {"released_by": _approval_actor, "released_date": _approval_date,
         # Gate 5's human exit, from the approval form's own fields — promotion used to DROP the
         # validator and date, so the receipt said who released and not who reviewed the evidence
         "qc_by": _validated_by, "qc_date": _validation_date})
    _cand["promoted_from"] = {"candidate_manifest": _cand_path,
                              "candidate_manifest_sha256": _cand_sha,
                              "candidate_identity": _approved_identity,
                              # WHAT THE PROMOTION MADE, from the journal that watched it being
                              # made — the versioned tables' own {table_id, location,
                              # delta_version, schema_digest}, so the receipt names the outputs
                              # by identity and not just by name.
                              "outputs": dict(_journal.get("outputs") or {}),
                              "built_nothing": True}
    # THE RUNTIME THIS PROMOTION EXECUTED ON. A receipt that cannot say which engine ran it is a
    # receipt that cannot be reproduced against the right runtime; recorded best-effort, absent
    # values stated as None rather than omitted.
    _cand["deployment"] = {"spark_version": getattr(spark, "version", None),        # noqa: F821
                           "databricks_runtime":
                               os.environ.get("DATABRICKS_RUNTIME_VERSION") or None}
    # VALIDATED BEFORE IT IS WRITTEN. A receipt that will not validate is not a receipt, and finding
    # that out when somebody tries to commit it — after the views have already moved — is finding it
    # out too late to do anything about.
    _bad = validate_manifest(_cand)
    if _bad:
        raise RuntimeError(
            "PUBLISHED, AND THE RECEIPT IS INVALID — the public views now serve build "
            f"{build_id} and this record does not validate:\n  " + "\n  ".join(_bad) +
            f"\nThe release is live; what is missing is its ledger entry. Fix the record by hand "
            f"from {artifact_root}/manifest.yaml and commit it — do NOT re-run the promotion.")
    # A SIBLING file. The candidate manifest is the subject of the approval and its digest is what was
    # signed, so rewriting it would break the binding the promotion just verified.
    dbutils.fs.put(f"{artifact_root}/published_manifest.yaml",   # noqa: F821
                   yaml.safe_dump(_cand, sort_keys=False), True)
    _journal = rel.advance(_journal, "receipted")
    _journal["published_manifest"] = f"{artifact_root}/published_manifest.yaml"
    _assert_lock_owned()
    _write_journal(_journal_path, _journal)
    # THE AUDIT BUNDLE, BEFORE THE LOCK DROPS. Written after the lock release, a bundle failure
    # left the product unlocked with its evidence missing — a second promotion could start over
    # the gap. Failing here keeps the lock held, so the loud state is also the serialised one.
    # Fatal on failure either way: the release is live and stays live; a green job standing over
    # missing evidence is the inversion of what a green job is for.
    # `tfl_qc.json` carries the REAL TFL QC gate (engine.tfl.tfl_qc), which the candidate recorded
    # under deliverables at build time — not the promotion stub (`tfl_promotion`), which is
    # about view swaps and was being written into the QC slot.
    try:
        _bundle = audit.build_bundle(
            _cand, ((_cand.get("deliverables") or {}).get("tfls") or {}).get("tfl_qc"))
        for _bn, _bo in _bundle.items():
            _body = _bo if isinstance(_bo, str) else json.dumps(_bo, indent=2, default=str)
            dbutils.fs.put(f"{artifact_root}/{_bn}", _body, True)   # noqa: F821
        print(f"Wrote release bundle ({len(_bundle)} files) -> {artifact_root}")
    except Exception as _e:                                          # noqa: BLE001
        raise RuntimeError(
            f"PUBLISHED, AND THE AUDIT BUNDLE FAILED — the views are live on build {build_id} and "
            f"stay live, and the promotion lock is still held so nothing else can move this "
            f"product. Re-run: the terminal branch verifies the receipt, REBUILDS this bundle, "
            f"and releases the lock. ({_e})") from _e
    # THE EVIDENCE, RECORDED IN THE JOURNAL. A rerun's terminal branch reads this to know the
    # bundle exists; without it, a crash after the receipt looked identical to a crash after the
    # bundle, and the missing-evidence case exited green forever.
    _journal["audit_bundle"] = sorted(_bundle)
    _assert_lock_owned()
    _write_journal(_journal_path, _journal)
    # RELEASED LAST, and only after the journal says `receipted` and the evidence exists — and
    # only while STILL OWNED: `release_lock_sql` is a DROP, and an unconditional drop by a
    # displaced writer would free a lock some OTHER attempt now holds.
    _assert_lock_owned()
    spark.sql(rel.release_lock_sql(final))   # noqa: F821
    print(f"PUBLISHED build {build_id} — {len(_tfl_ids)} TFL view(s) then the ADS. "
          f"Candidate manifest untouched at {_cand_path}; journal at {_journal_path}.")
    dbutils.notebook.exit("promoted")   # noqa: F821

# THE PROBED VERSION IS THE READ VERSION. Between the probe and Spark's first action another
# writer can commit; versionAsOf pins every source read to exactly what the manifest records,
# so the race is closed by construction rather than by timing. A publication run refuses any
# input that could not be pinned — a ledger claiming version N over a read of N+1 is the
# recorded-but-not-used lineage failure, and absence of a pin must never read as "current is fine".
# (_pins was probed and built at the top of the data phase — ONE snapshot for every reader)
if _require_published and _unpinned:
    raise RuntimeError(f"PUBLICATION REFUSED — {_unpinned} source table(s) could not be pinned "
                       f"(no probed delta_version); a published build must read exactly the "
                       f"versions its manifest records")
_telemetry = None
if (dbutils.widgets.get("stage_telemetry") or "").strip().lower() in ("1", "true", "yes"):   # noqa: F821
    from engine.telemetry import StageTelemetry      # noqa: E402
    _telemetry = StageTelemetry()
ads = build(spark, cfg, pins=_pins, telemetry=_telemetry)        # noqa: F821
(ads.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(staging))   # noqa: F821
# The collector's ONE action, spent after the build's own write so the telemetry job can never
# sit between the build and the bytes it stages. `stage_telemetry` is None when the run did not
# opt in — build_manifest then records {} = "not collected", which is the honest third answer,
# not a pass. Never wired into candidate_verdict: these are numbers a person reads, not a gate.
stage_telemetry = _telemetry.report() if _telemetry is not None else None
if stage_telemetry:
    for _o in stage_telemetry["skipped"]:
        print(f"stage-telemetry SKIPPED: {_o}")
    for _o in stage_telemetry["observations"]:
        print(f"stage-telemetry OBSERVATION: {_o}")
    print("Stage telemetry:\n" + json.dumps(stage_telemetry["stages"], indent=2, default=str))
    print("Selection telemetry:\n" + json.dumps(stage_telemetry["selections"], indent=2,
                                                default=str))
# IDENTITY AT THE MOMENT OF THE WRITE. QC, counts, goldens, TFLs and the deliverables all read
# THIS version of the staging table, and the manifest's candidate_identity must still match it.
# Without the pin each later step read whatever held the staging NAME when it happened to run —
# a same-name replacement between QC and signing signed bytes that were never QC'd.
_staging_write_row = _probe_candidate_tables([staging])[0]
staged = (spark.read.option("versionAsOf", str(_staging_write_row["delta_version"]))  # noqa: F821
          .table(staging))

# THE EDA LAYERS, over the same run — opt-in, evidence-never-a-verdict, exactly the telemetry
# rules. Collected against the LOADED sources (a fresh lazy load under the same pins, the
# grain-report pattern above) and the PINNED staging read above — an adversarial review caught
# the first wiring reading the staging NAME before the identity probe, so a same-name
# replacement in that window could put counts about other bytes into the signed manifest. The
# doc lands in the manifest and, below, in the artifact root with its sha256 recorded under
# `artifacts` — both inside the candidate manifest digest Gate 6 signs.
eda_doc = None
# DECLARED ACCEPTANCE MAKES EDA MANDATORY. The widget stays a run parameter for packs that
# declare nothing — but a pack that has written qc.eda_acceptance limits has made collection
# part of its candidate contract, and "the widget was off" must not read as "the gate passed"
# (declared acceptance with optional collection is a gate that
# evaporates on the quiet path).
_eda_limits = (cfg.raw.get("qc") or {}).get("eda_acceptance")
_eda_wanted = (dbutils.widgets.get("eda") or "").strip().lower() in ("1", "true", "yes")   # noqa: F821
if _eda_limits and not _eda_wanted:
    print("qc.eda_acceptance is declared — EDA collection is mandatory for this pack; "
          "collecting despite the widget")
if _eda_limits or _eda_wanted:
    from engine.stages import sources as _eda_sources    # noqa: E402
    import eda_report as _eda_report                     # noqa: E402
    eda_doc = _eda_report.eda(spark, _eda_sources.load(spark, cfg, _pins), cfg,   # noqa: F821
                              telemetry_report=stage_telemetry, ads=staged)
    print(f"EDA evidence collected: {len(json.dumps(eda_doc, default=str))} bytes, counts only "
          f"(restricted_derived — a person reads it; only a DECLARED acceptance contract "
          f"gates on it)")

report = run_qc(spark, staged, cfg)            # noqa: F821
gate = qc_gate(report, qc_thresholds(cfg))
# THE OUTPUT CONTRACT, over the SAME pinned staging read. Not a second `spark.read` of the same
# name: the pin above exists because a same-name replacement between QC and signing would sign
# bytes that were never QC'd, and an output contract scored against a different read of the table
# would be open to exactly that. `qc` answers "are the distributions sane"; this answers "is this
# even the shape we promised" — one patient per cohort per index date, every configured cohort
# present, no value outside a codelist the config compiles.
oc_report = run_output_contract(spark, staged, cfg)          # noqa: F821
# WITH THE SPEC, not just the report. The gate's strict machinery (skipped-rule failures,
# not_applicable excusals) reads the spec; calling it report-only silently ran a weaker gate on
# the one path that matters. The report now also EMBEDS the spec
# fields it needs, so a spec-less caller elsewhere gets the same verdict, but the runner states
# its intent explicitly.
from engine.output_contract import contract_spec as _contract_spec   # noqa: E402
oc_gate = output_contract_gate(oc_report, _contract_spec(cfg))
# THE VERDICT CARRIES ITS EVIDENCE. A bare {passed: True} in the ledger cannot be audited later —
# which cohorts were compared, how many rules reached the build, what the null rates were. The
# report is nested under the verdict rather than added as a second top-level field so a reader
# cannot find one without the other.
oc_manifest = dict(oc_gate, report=oc_report)
for _u in oc_gate["unconfigured"]:
    # PRINTED EVEN WHEN THE GATE PASSES. No pack declares a `qc:` block yet, so most of these are
    # unconfigured today, and a silent pass over them is the number that would later be quoted as
    # "the output contract was green".
    print(f"output-contract UNCONFIGURED: {_u}")
for _f in oc_gate["failures"]:
    print(f"output-contract FAILURE: {_f}")
counts = {
    "total_rows": staged.count(),
    "cohorts": {r["cohort"]: r["n"] for r in
                staged.groupBy("cohort").agg(F.count(F.lit(1)).alias("n")).collect()}
    if "cohort" in staged.columns else {},
}
ref = dbutils.widgets.get("reference_table")   # noqa: F821
golden = {"reference": "none"}
# Bound BEFORE the `if ref:` branch, because the manifest is written on every path. The
# first version defined it only where a reference exists, which is a NameError on exactly
# the runs that have no reference — the common case, and the one nobody would test first.
differential = {"reference": "none"}
if ref:
    # the REFERENCE is a governed input like any other: probe its FULL identity (id + location +
    # version, the same fields every other pin carries) and read pinned, so the comparison the
    # gate scores is the comparison the manifest describes. Version alone left the yardstick
    # movable: a drop-and-recreate serves the same version number from a different table.
    _ref_h, _ref_d = rel.candidate_probe_statements(ref)
    _ref_identity = rel.input_lineage_row(ref,
                                          spark.sql(_ref_h).collect()[0].asDict(),   # noqa: F821
                                          spark.sql(_ref_d).collect()[0].asDict())   # noqa: F821
    _ref_ver = _ref_identity["delta_version"]
    summary = run_golden(spark, staging, ref, cfg,   # noqa: F821
                         new_version=_staging_write_row["delta_version"], ref_version=_ref_ver)
    # PATIENT-LEVEL, over the SAME two pinned reads. Every aggregate `run_golden` computes is
    # invariant under a permutation of patients: swap two patients' ECOG and the distribution is
    # byte-identical. This pairs on the output key and reports who actually moved, so a clean
    # golden summary can no longer stand in for "the same patients got the same values".
    _new_pinned = (spark.read.option("versionAsOf", str(_staging_write_row["delta_version"]))  # noqa: F821
                   .table(staging))                                              # noqa: F821
    _ref_pinned = spark.read.option("versionAsOf", str(_ref_ver)).table(ref)      # noqa: F821
    diff_report = run_differential(spark, _new_pinned, _ref_pinned, cfg)          # noqa: F821
    diff_spec = differential_spec(cfg)
    diff_gate = differential_gate(diff_report, diff_spec)
    for _f in diff_gate["failures"]:
        print(f"differential FAILURE: {_f}")
    for _u in diff_gate["unapproved"]:
        # UNAPPROVED, not "failed": a refresh is supposed to change things. What it may not do is
        # change them without a person having named the change in `golden.approved_deltas`.
        print(f"differential UNAPPROVED CHANGE: {_u}")
    differential = dict(diff_gate, report=diff_report)
    # THE SANDWICH. `versionAsOf` fixes WHICH version was read, not WHOSE table served it: a
    # drop-and-recreate (or a catalog rebind) between the probe above and the comparison serves
    # version N from a different Delta log under the same name — the same gap every ordinary
    # source read closes with a before/after identity check, closed here the same way.
    _ref_after = rel.input_lineage_row(ref,
                                       spark.sql(_ref_h).collect()[0].asDict(),   # noqa: F821
                                       spark.sql(_ref_d).collect()[0].asDict())   # noqa: F821
    if (_ref_after.get("table_id"), _ref_after.get("location")) != \
            (_ref_identity.get("table_id"), _ref_identity.get("location")):
        raise RuntimeError(
            f"GOLDEN COMPARISON VOID — the reference {ref} changed identity DURING the "
            f"comparison (table_id/location "
            f"{_ref_identity.get('table_id')}/{_ref_identity.get('location')} -> "
            f"{_ref_after.get('table_id')}/{_ref_after.get('location')}). The gate just scored a "
            f"comparison against a table the manifest would not describe; fix the reference and "
            f"re-run.")
    ggate = golden_gate(summary, golden_thresholds(cfg))
    golden = {"reference": ref, "identity": _ref_identity, "summary": summary, "gate": ggate}
else:
    ggate = golden_gate(None)        # no reference -> skipped (passes)
    if cfg.raw.get("status") == "active":
        print("WARNING: no `reference_table` supplied — golden comparison SKIPPED for an ACTIVE "
              "product. A release-grade run should pass --var reference_table=<known-good ADS>.")
print("QC report:\n" + json.dumps(report, indent=2, default=str))
print("QC gate:\n" + json.dumps(gate, indent=2, default=str))
print("Golden gate:\n" + json.dumps(ggate, indent=2, default=str))

# COMMAND ----------
# GATE ON ALL FIVE VERDICTS, from the ONE list in `refresh.CANDIDATE_VERDICTS`: source QC, ADS QC,
# the output contract, the aggregate golden and the patient differential. Any failing keeps staging
# and FAILS the job WITHOUT publishing (temp-then-swap).
#
# This line used to read `if not gate["passed"] or not ggate["passed"]` — ADS QC and golden only.
# The output-contract and differential gates were computed a few cells above, printed, and written
# into the manifest, and stopped NOTHING: a product with duplicate output keys or a missing cohort
# produced a green candidate job, and a differential full of unapproved patient-level changes
# reached release validation unexamined. An external review found it.
#
# Composed rather than re-listed here, so a sixth gate cannot be added to the manifest and not to
# the job — which is exactly how these two came to be enforced in one place out of three.
_verdict_manifest = {"source_qc_gate": src_gate, "qc": gate, "output_contract": oc_manifest,
                     # the adapter binding is part of the candidate's IDENTITY: the digest names
                     # which reviewed adapter file governed every physical read of this run
                     **({"adapter_binding": cfg.adapter_binding} if cfg.adapter_binding else {}),
                     **({"source_grain": source_grain} if source_grain else {}),
                     # eda() attaches `acceptance` only when the pack declares limits; absent
                     # limits leave this {} and the verdict says "not evaluated" — but declared
                     # limits now reach the SAME verdict the job stops on, not only the manifest
                     "eda_acceptance": (eda_doc or {}).get("acceptance") or {},
                     "golden": golden, "differential": differential}
candidate = candidate_verdict(_verdict_manifest)
print("Candidate verdict:\n" + json.dumps(candidate, indent=2, default=str))
if not candidate["passed"]:
    m = build_manifest(cfg, tumor=tumor, family=family, source_lineage=src_lineage, git_commit=dbutils.widgets.get("git_commit") or None,  # noqa: F821
                       counts=counts, qc=gate, output_contract=oc_manifest, golden=golden, differential=differential,
                       source_grain=source_grain, stage_telemetry=stage_telemetry, eda=eda_doc, source_qc=src_qc, source_qc_gate=src_gate,
                       config_identity=_config_identity, run_mode=_run_mode)
    qc_md = render_qc_report(report, gate, golden, m)
    print("Manifest (GATE FAILED):\n" + json.dumps(m, indent=2, default=str))
    print("\n=== QC REPORT ===\n" + qc_md)
    import yaml   # noqa: E402
    for name, body in [("manifest.yaml", yaml.safe_dump(m, sort_keys=False)), ("qc_report.md", qc_md)]:
        try:    # persist the FAILED-refresh evidence durably (best-effort; the job is already failing)
            dbutils.fs.put(f"{artifact_root}/{name}", body, True)   # noqa: F821
        except Exception as e:   # noqa: BLE001
            print(f"(could not persist failed-gate {name} to {artifact_root}: {e})")
    # EVERY failing verdict, not two of them. The old message named QC and golden, so a run stopped
    # by the output contract would have reported two empty failure lists and no reason at all.
    raise RuntimeError(
        f"Publish blocked — '{final}' NOT published. Candidate verdict: "
        + "; ".join(candidate["failures"])
        + (f". Not evaluated (no reference): {', '.join(candidate['not_evaluated'])}"
           if candidate["not_evaluated"] else "")
        + f". Staging kept: {staging}")

# COMMAND ----------
# Deliverables are generated FROM THE STAGED table BEFORE the swap, so a REQUIRED deliverable that
# fails BLOCKS publish — the final ADS is never overwritten by an incomplete refresh. The dictionary
# is column-aware (filtered to the staged ADS columns, like the dashboard); TFLs read the staged ADS, byte-for-byte what
# will publish (the staged ADS is copied to the IMMUTABLE versioned table, then the public view swaps to
# it). Each deliverable is
# required | optional | skip per the config `deliverables:` block (default optional); status is
# recorded in the manifest.
# THE SAME BYTES QC JUST PASSED. This re-bind used to read the live staging NAME, so a same-name
# replacement landing between the QC gate and here handed the dictionary and TFLs bytes the gate
# never scored — caught only at the end, by the pre-signature probe, after every deliverable had
# been generated from the impostor. Re-verify identity NOW and keep reading the pinned version the
# write recorded, so the gap is closed at its opening rather than reported at its far end.
_post_qc_row = _probe_candidate_tables([staging])[0]
for _f in ("table_id", "location"):
    if str(_post_qc_row.get(_f)) != str(_staging_write_row.get(_f)):
        raise RuntimeError(
            f"CANDIDATE REFUSED — {staging} is not the table QC just passed: {_f} was "
            f"{_staging_write_row.get(_f)!r} at the write and is {_post_qc_row.get(_f)!r} now. "
            f"The table was dropped and recreated (or the name re-pointed) after the QC gate; "
            f"nothing here will generate deliverables from bytes the gate never scored.")
staged = (spark.read.option("versionAsOf", str(_staging_write_row["delta_version"]))  # noqa: F821
          .table(staging))
deliv_cfg = cfg.raw.get("deliverables") or {}
def _policy(name):   # required | optional | skip — a governed (prod+active) run REQUIRES the release
    default = "required" if (governed and not waiver) else "optional"   # waiver -> smoke-test bypass
    return str(deliv_cfg.get(name, default)).lower()

artifacts = {}
# The EDA artifact, written into the artifact root and RECORDED (path + sha256) before the
# canonical manifest serialize below — so the digest the Gate 6 approval signs covers it, and
# an eda_report.json swapped after signing no longer matches its recorded hash.
if eda_doc is not None:
    import eda_report as _eda_report                     # noqa: E402
    _eda_raw, _eda_sha = _eda_report.serialized(eda_doc)
    dbutils.fs.put(f"{artifact_root}/eda_report.json", _eda_raw.decode("utf-8"), True)   # noqa: F821
    artifacts["eda_report"] = f"{artifact_root}/eda_report.json"
    artifacts["eda_report_sha256"] = _eda_sha
deliverables = {}

if _policy("dictionary") == "skip":
    deliverables["dictionary"] = {"status": "skipped", "reason": "deliverables.dictionary=skip"}
else:
    try:
        catalog = load_yaml(str(shared_asset(products_root, "catalog")))
        auds = dict_engine.load_audiences(str(shared_asset(products_root, "audiences")))
        made, xlsx_failed = [], []
        for audience in (auds or {"internal": 1, "partner": 1, "customer": 1}):
            d = dict_engine.build_dictionary(catalog, audience=audience, tumor=tumor, audiences=auds,
                                             columns=staged.columns)   # restrict to what the ADS emits
            p = f"{artifact_root}/dictionary_{audience}.md"
            dbutils.fs.put(p, dict_engine.render_markdown(d), True)   # noqa: F821
            artifacts[f"dictionary_{audience}"] = p
            try:    # XLSX is a governed human-review deliverable (OPERATIONS.md) — its failure is RECORDED
                import os, tempfile   # noqa: E402
                xl = os.path.join(tempfile.mkdtemp(), f"dictionary_{audience}.xlsx")
                dict_engine.render_xlsx(d, xl)
                xlr = f"{artifact_root}/dictionary_{audience}.xlsx"
                dbutils.fs.cp(f"file:{xl}", xlr)   # noqa: F821
                artifacts[f"dictionary_{audience}_xlsx"] = xlr
            except Exception as xe:   # noqa: BLE001
                xlsx_failed.append(audience)
                print(f"(dictionary XLSX for {audience} FAILED: {xe})")
            made.append(audience)
        # 'ok' only when BOTH formats are produced; an XLSX failure -> 'partial' so a REQUIRED dictionary
        # (governed run) BLOCKS publish, while an optional one still publishes with the gap recorded.
        deliverables["dictionary"] = {
            "status": "ok" if (made and not xlsx_failed) else ("partial" if made else "empty"),
            "audiences": made, "markdown": "ok" if made else "empty",
            "xlsx": "ok" if (made and not xlsx_failed) else ("failed" if xlsx_failed else "empty"),
            "xlsx_failed": xlsx_failed}
        print(f"Dictionaries: {made}  (xlsx failed: {xlsx_failed or 'none'})")
    except Exception as e:   # noqa: BLE001
        deliverables["dictionary"] = {"status": "failed", "error": str(e)}
        print(f"(dictionary generation FAILED: {e})")

# COMMAND ----------
# Dashboard manifest — the generated CONTRACT the dashboard reads (labels/types/value-sets/units/
# time-to-event pairings) so the app never hard-codes variable metadata. Built from the catalog + the
# variable packs, filtered to this tumor (so it carries the mcrpc-specific variables).
if _policy("dashboard") == "skip":
    deliverables["dashboard"] = {"status": "skipped", "reason": "deliverables.dashboard=skip"}
else:
    try:
        from engine import dashboard as dash_engine   # noqa: E402
        layout = load_yaml(str(shared_asset(products_root, "dashboard_vars")))
        dm = dash_engine.build_manifest(
            cfg, load_yaml(str(shared_asset(products_root, "catalog"))), tumor,
            dashboard=layout, columns=staged.columns)   # restrict to what the ADS actually emits
        dpth = f"{artifact_root}/dashboard_manifest.json"
        dbutils.fs.put(dpth, dash_engine.render_json(dm), True)   # noqa: F821
        artifacts["dashboard_manifest"] = dpth
        deliverables["dashboard"] = {"status": "ok", "n_variables": dm["summary"]["n_variables"]}
        print(f"Dashboard manifest: {dm['summary']['n_variables']} variables -> {dpth}")
    except Exception as e:   # noqa: BLE001
        deliverables["dashboard"] = {"status": "failed", "error": str(e)}
        print(f"(dashboard manifest FAILED: {e})")

tfl_staged = {}   # tid -> (final_name, staging_name); promoted to final ONLY after the ADS publishes
_tfl_write_rows = {}   # staging name -> identity row captured AT THE WRITE, verified at signing
tfl_qc_result = None   # the TFL QC gate (engine.tfl.tfl_qc); goes into the release bundle below
if _policy("tfls") == "skip":
    deliverables["tfls"] = {"status": "skipped", "reason": "deliverables.tfls=skip"}
else:
    try:
        specs = tfl_engine.load_specs(str(shared_asset(products_root, "tfl_specs")))
        made = []
        for tid, df in tfl_engine.generate(spark, staged, specs).items():   # noqa: F821
            tfinal, tstg = rel.public_tfl(final, tid), rel.staging_tfl(final, build_id, tid)
            df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(tstg)   # STAGE only
            _tfl_write_rows[tstg] = _probe_candidate_tables([tstg])[0]
            tfl_staged[tid] = (tfinal, tstg)
            artifacts[f"tfl_{tid}"] = tfinal     # final location (after the post-publish promotion below)
            made.append(tid)
        # TFL QC gate — computed AFTER generate() with the SET ACTUALLY EMITTED (made): a required TFL
        # that is column-producible but that generate() silently skipped (no kept summarise/listing
        # columns) is a real `failure`, not a false `ok`. per-TFL applicability + required/optional skips.
        tfl_qc_result = tfl_engine.tfl_qc(specs, tfl_engine.tfl_plan(specs, staged.columns, hard=True),  # noqa: F821
                                          generated=set(made))
        # ENFORCE: a failed gate FAILS the tfls deliverable -> a governed run (tfls=required) BLOCKS
        # publish; optional / not-applicable TFLs only warn (don't block). tfl_qc rides along for evidence.
        if tfl_qc_result and not tfl_qc_result["passed"]:
            _failed = [r["id"] for r in tfl_qc_result["tfls"] if r["status"] == "failure"]
            deliverables["tfls"] = {"status": "failed", "tfls": made, "tfl_qc": tfl_qc_result,
                                    "error": f"TFL QC gate failed — required TFLs not producible: {_failed}"}
            print(f"(TFL QC GATE FAILED: required TFLs not producible: {_failed})")
        else:
            deliverables["tfls"] = {"status": "ok" if made else "empty", "tfls": made, "tfl_qc": tfl_qc_result}
        print("TFLs (staged):", made)
    except Exception as e:   # noqa: BLE001
        deliverables["tfls"] = {"status": "failed", "error": str(e)}
        print(f"(TFL generation FAILED: {e})")

# A REQUIRED deliverable that didn't complete BLOCKS publish (staging kept, final never overwritten).
# Record the evidence manifest, then fail — BEFORE the swap.
required_failed = [name for name in ("dictionary", "tfls", "dashboard")
                   if _policy(name) == "required" and deliverables.get(name, {}).get("status") != "ok"]
if required_failed:
    m = build_manifest(cfg, tumor=tumor, family=family, source_lineage=src_lineage, git_commit=dbutils.widgets.get("git_commit") or None,  # noqa: F821
                       counts=counts, qc=gate, output_contract=oc_manifest, golden=golden, differential=differential,
                       source_grain=source_grain, stage_telemetry=stage_telemetry, eda=eda_doc, source_qc=src_qc, source_qc_gate=src_gate,
                       deliverables=deliverables, artifacts={"artifact_root": artifact_root, **artifacts},
                       config_identity=_config_identity, run_mode=_run_mode)
    try:
        import yaml   # noqa: E402
        dbutils.fs.put(f"{artifact_root}/manifest.yaml",   # noqa: F821
                       yaml.safe_dump(m, sort_keys=False), True)
    except Exception as e:   # noqa: BLE001
        print(f"(could not write evidence manifest: {e})")
    raise RuntimeError(
        f"Publish blocked — required deliverable(s) {required_failed} did not complete; "
        f"'{final}' NOT published. Staging kept: {staging}. See manifest.deliverables "
        "(set deliverables.<name>=optional to publish without them).")

# COMMAND ----------
# VALIDATE-ONLY STOPS HERE — before the RELEASE PHASE, not part-way through it.
#
# Guarding only the view swap is not enough. If a validate-only run created IMMUTABLE versioned
# release tables, wrote a release pointer into the manifest and touched the public TFL names, then
# release-NAMED objects would appear in the production output schema even though nothing was
# published — and a later reader could not tell "this build was validated" from "a release was
# prepared and abandoned". `validate_only` must not also mean "created release objects".
#
# Everything worth having from a smoke test has already happened above: the build ran, source/ADS/TFL
# QC ran, deliverables were produced, and staging holds the exact bytes that would publish. What is
# skipped is only the part that makes a release a release.
# The manifest is built HERE — before the validate-only stop — because BOTH exits write it: the
# validate-only branch records its evidence manifest, and the publish path records the ledger.
# Building it after the stop made every validate-only run die on a NameError instead of exiting
# `validate_only`, with no evidence manifest written — the governed smoke path of every
# not-yet-releasable pack, which today is all of them.
manifest = build_manifest(cfg, tumor=tumor, family=family, source_lineage=src_lineage, git_commit=dbutils.widgets.get("git_commit") or None,  # noqa: F821
                          counts=counts, qc=gate, output_contract=oc_manifest, golden=golden, differential=differential,
                          source_grain=source_grain, stage_telemetry=stage_telemetry, eda=eda_doc,
                          source_qc=src_qc, source_qc_gate=src_gate, deliverables=deliverables,
                          artifacts={"artifact_root": artifact_root, **artifacts},
                          config_identity=_config_identity, run_mode=_run_mode)

if not may_publish:
    manifest["tfl_promotion"] = {"passed": False, "skipped": "validate_only",
                                 "intended": list(tfl_staged)}
    manifest["validate_only"] = {"reason": "waiver" if waiver else "not_release_ready",
                                 "blockers": release_blockers[:20],
                                 "stopped_before": "versioned_release_tables"}
    dbutils.fs.put(f"{artifact_root}/manifest.yaml",   # noqa: F821
                   yaml.safe_dump(manifest, sort_keys=False), True)
    print(f"VALIDATE-ONLY: staged {staging} and {len(tfl_staged)} TFL(s). No versioned release table, "
          f"no release pointer, no public view touched. published_at is null. Blockers: "
          f"{'; '.join(release_blockers[:3]) or 'none (waiver)'}")
    _stop_without_publishing("validate_only")

# Final pre-publish guard: every PUBLIC name the swap will replace (the ADS + each public TFL) must be
# FREE or already a VIEW. The ADS was checked pre-build; the public TFL names are known only now the
# TFLs are staged. A pre-pointer TABLE squatting on a public TFL name would fail the swap mid-flight.
for _pub, _ver, _ in rel.swap_plan(final, cfg.refresh, build_id, list(tfl_staged)):
    _assert_swappable(_pub)

# DURABLE RELEASE LEDGER FIRST, THEN PUBLISH. The manifest + QC report record exactly what is about
# to be published — counts / QC / golden / deliverables / artifacts are all known from the staged
# table, which is byte-for-byte what will publish. Writing them to artifact_root BEFORE the
# irreversible swap, and FAILING LOUD if that write fails, guarantees we can never end up "published
# but not durably recorded": if the ledger can't be persisted, the final table is left untouched and
# the job fails with staging kept. status = qc_passed and published_at = null here (PRE-publish) — so
# this record can never be mistaken for a successful publish if the swap below fails.
# (the manifest itself was built above, before the validate-only stop — both exits write it)
# THE PHYSICAL IDENTITY OF THE STAGED CANDIDATE, recorded BEFORE the manifest is hashed so the
# approval digest covers it. Without this the approval bound a NAME: `promotion_blockers` asked
# whether a table called `…__staging__<build_id>` existed, and a table with that name holding
# different bytes satisfied it. Now the manifest states the Delta version and row count of every
# staged table, the approver signs those bytes, and promotion re-probes and refuses a mismatch.
#
# `DESCRIBE HISTORY` needs the table to be Delta. Every table this runner writes is; a probe that
# fails is recorded as such rather than swallowed, because an absent identity must block promotion
# (`identity_blockers` fails closed on it) and not silently pass as "nothing changed".
_staged_tables = [staging] + [t for _f, t in tfl_staged.values()]
# NOT WRAPPED IN A TRY. An earlier version caught per-table probe failures, recorded whatever
# succeeded, printed a warning and went on to offer approval instructions — so a candidate could be
# SIGNED with one table measured and another not. There is no useful partial answer: a candidate is
# approved whole or not at all, and a run that cannot say what it staged has not produced one.
# RE-PROBE AND REFUSE MOVEMENT. Identities were captured at each write; a staging table whose id
# or version moved between its write and this signature is a REPLACEMENT — signing it would sign
# bytes the QC above never saw.
_now_rows = _probe_candidate_tables(_staged_tables)
_write_rows = {staging: _staging_write_row, **_tfl_write_rows}
for _row in _now_rows:
    _then = _write_rows.get(_row["table_name"])
    if _then and (_row["table_id"] != _then["table_id"]
                  or _row["delta_version"] != _then["delta_version"]):
        raise RuntimeError(
            f"CANDIDATE REFUSED — {_row['table_name']} moved after it was written and measured: "
            f"id/version {_then['table_id']}/{_then['delta_version']} at the write, "
            f"{_row['table_id']}/{_row['delta_version']} now. The QC verdict describes the earlier "
            f"bytes; nothing here will sign the later ones.")
manifest["candidate_identity"] = rel.candidate_identity(_now_rows)
# ...AND WHICH RELEASE THIS CANDIDATE EXPECTS TO REPLACE, recorded before the digest so the approver
# signs it too. Nothing bound a promotion to the state of the world it was approved against: build A
# staged and signed, build B built and published while A waited, A then promoted — moving every
# public view BACKWARDS onto older data with every check passing, because A's bytes really were the
# bytes A's approver signed. The approval was never about the release it would replace.
manifest["supersedes"] = _observe_public_views(final, sorted(tfl_staged))

qc_md = render_qc_report(report, gate, golden, manifest)
print("Refresh manifest (pre-publish, published_at=null):\n" + json.dumps(manifest, indent=2, default=str))
print("\n=== QC REPORT (markdown) ===\n" + qc_md)
import yaml   # noqa: E402
# THE CANONICAL CANDIDATE BYTES, serialized ONCE. What gets written, what gets hashed and what an
# approver is told to sign are the same string, not three calls to `safe_dump` that agree today.
# `_manifest_sha` is computed here, beside the write, for the same reason: a digest taken somewhere
# else in the notebook is a digest of whatever the dict happened to be at that point.
_persisted = yaml.safe_dump(manifest, sort_keys=False)
_manifest_sha = hashlib.sha256(_persisted.encode("utf-8")).hexdigest()
for name, body in [("manifest.yaml", _persisted), ("qc_report.md", qc_md)]:
    dbutils.fs.put(f"{artifact_root}/{name}", body, True)   # noqa: F821  (raises on failure -> no publish)
    print(f"Wrote {artifact_root}/{name}")

# COMMAND ----------
# GATE 6 — THE NAMED APPROVAL OF *THIS BUILD*, and the last thing between a clean run and the public
# views. Checked HERE because the thing being approved does not exist until now: the candidate
# manifest carrying this run's counts, QC verdict and golden comparison. Approving earlier would
# approve a configuration, which is Gate 4's job.
#
# WORKFLOW.md has always required this. The runner did not ask: it confirmed Gates 1-4, built, ran QC
# and swapped, and sign-off was promoted to the ledger AFTERWARDS. So production credentials plus a
# technically clean run moved the public product with no accountable person having looked at it.
#
# WHAT THIS IS AND IS NOT. It is a BLOCK: a prod run with no matching approval stops here, staged and
# QC'd, with nothing public touched. The two-run flow it stops into IS built — `promote_build_id`
# above adopts this build id, verifies the approval against the persisted manifest, re-probes the
# staged tables and publishes those bytes without rebuilding. `build_id` embeds `{{job.run_id}}`, so
# every ordinary execution mints a new identity and moves the manifest digest with it: an approval of
# build A can never be satisfied by a later run B, and promotion is the only path that honours A.
#
# WHAT IS STILL OUTSTANDING is the sequencing of where the approval is READ from — see
# products/OPERATIONS.md §"Gate 6" item 4 — and the fact that no promotion has yet run on a cluster.
# Neither is a missing mechanism; both are stated there rather than here so one file owns the list.
#
# GATES 1-4 COME FROM `release_ready`, NOT FROM A FRESH `releasable()`. In prod that verdict was
# derived from RELEASE_EVIDENCE.yaml precisely because the allowlisted tree omits the Gate 1 material
# a live evaluation needs — so re-deriving here would fail for the reason the packaging exists to
# create. The first version of this block called `releasable()` and could never have passed in
# production.
print(f"Candidate manifest sha256: {_manifest_sha}  build_id: {build_id}")
if env == "prod":
    _pub_why = publish_approval_errors(str(_repo), _rel, build_id, _manifest_sha)
    if _pub_why:
        # THE CANDIDATE MANIFEST IS NEVER REWRITTEN. An earlier version recorded this state by adding
        # a `release_approval` block to `manifest` and putting the file again — so `manifest.yaml` on
        # disk did NOT hash to the digest printed above and carried into the approval form. The
        # approver would sign a value no artifact reproduced, and the promotion step verifying the
        # file would reject the very build the approval names. A binding whose subject is edited
        # after it is hashed binds nothing.
        #
        # So the stop is recorded ALONGSIDE, in its own file. `manifest.yaml` stays byte-identical to
        # `_persisted`: `status: qc_passed` with a null `published_at` is ALREADY the pre-publish
        # state and needs no new word (an invented `awaiting_release_approval` also fails
        # `validate_manifest`, and a ledger entry that will not validate is not a ledger entry).
        dbutils.fs.put(f"{artifact_root}/release_candidate.yaml",   # noqa: F821
                       yaml.safe_dump({"granted": False, "build_id": build_id,
                                       "candidate_manifest_sha256": _manifest_sha,
                                       "candidate_manifest": f"{artifact_root}/manifest.yaml",
                                       "blockers": _pub_why[:20],
                                       "stopped_before": "versioned_release_tables"},
                                      sort_keys=False), True)
        print("AWAITING RELEASE APPROVAL — staged and QC'd, no versioned release table, no release "
              "pointer, no public view touched. published_at is null.")
        for _b in _pub_why[:6]:
            print(f"   - {_b}")
        print(f"   To approve THIS build, record in {_rel}/handoff/RELEASE_APPROVAL.yaml:\n"
              f"     approved_build_id: {build_id}\n"
              f"     approved_manifest_sha256: {_manifest_sha}\n"
              f"   Then re-run this job with promote_build_id={build_id}. That run publishes THESE\n"
              f"   staged bytes and builds nothing: it re-probes each staged table, refuses if its\n"
              f"   Delta version or row count has moved since this manifest was signed, and reads\n"
              f"   each one VERSION AS OF the approved version. A rerun WITHOUT promote_build_id\n"
              f"   mints a new build_id and is a different candidate needing its own approval.")
        _stop_without_publishing(
            "awaiting_release_approval",
            f"The candidate {build_id} is staged and recorded; approval is what is missing.")

# COMMAND ----------
# A CANDIDATE ALWAYS STOPS. The direct-publish phase that lived here — versioned tables, pointer,
# view swaps, staging drop, receipt — was a SECOND, weaker release algorithm: no lock, no journal,
# no supersedes check, no receipt prevalidation. Two publication codepaths meant the strong one
# was optional. ONE state machine publishes now: `promote_build_id`, above, in every environment.
# This run's terminal state is what it built: a staged, measured, identified, approvable candidate.
print(f"CANDIDATE READY — staged {staging} and {len(tfl_staged)} TFL(s); manifest, QC report and "
      f"identity persisted to {artifact_root}. To publish: record the approval "
      f"(handoff/RELEASE_APPROVAL.yaml naming build {build_id} and manifest sha256 "
      f"{_manifest_sha}), then run this job with promote_build_id={build_id}.")
_stop_without_publishing(
    "candidate_ready",
    f"The candidate {build_id} is staged and recorded; publication is a promotion run.")
