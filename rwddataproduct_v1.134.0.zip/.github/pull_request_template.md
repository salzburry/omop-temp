<!-- See governance/VERSIONING.md and docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md. -->

## What & why

<!-- One or two lines. Link the issue. -->

## Change type (pick one — it drives review routing + versioning)

- [ ] **Engine** (`platform/`) — bump `platform/VERSION` (SemVer) if behaviour changed; R↔Python parity must stay green
- [ ] **Product contract** (cohorts / derivations / variables / codelists) — needs a **new `YYYYMM` spec_version** + a classified CHANGELOG entry + a `registry.yaml` lineage row
- [ ] **Data refresh only** (`--var refresh=…`) — a committed `refreshes/<family>/<product>/<spec_version>/<refresh>.yaml` manifest, no code change
- [ ] **Governance / docs** — no runtime impact

## Contract-change classification (only if a product contract changed)

- [ ] **breaking** — cohort / derivation / rename / remove (changes existing values)
- [ ] **additive** — new variable / TFL / codelist value (existing values unchanged)
- [ ] **none** — data cut / typo (no new spec_version)

## Checklist

- [ ] `rwdp-ci` green (pure-Python suite + R↔Python parity)
- [ ] CHANGELOG + `registry.yaml` updated if the contract changed (`test_registry_lineage_matches_config`)
- [ ] CODEOWNERS routing satisfied — or a **waiver** named below
- [ ] No model identifier, secrets, or PII in the diff

## Waiver (optional)

<!-- If a required gate is intentionally skipped, name the gate + the approver here.
     Waiver is a PR-checklist field, not a label. -->
