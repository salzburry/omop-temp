#!/usr/bin/env python3
"""The READ-ONLY governance app — the surface a Domino deployment serves.

One rule decides everything here: the app is a WINDOW, never a hand. It serves exactly the pages
the governed tools already generate (status flow, rule review, worksheet, decision packets) and
the knowledge-graph queries, each computed fresh per request from the checked-out commit — so what
is on screen is always what is merged, with the commit stamped in the footer. It performs no
governed act: no approval, no decision recording, no regeneration into the repository, and it
serves no file from the checkout itself — every rendered page lands in a temp directory outside
the tree, per the restricted-output rule, and only that byte stream is returned.

Domino runs `app.sh`, which runs this. Binds 0.0.0.0 on $PORT (Domino proxies and authenticates;
set the app's access to your project's collaborators, never public). stdlib only.
"""
import glob
import html
import os
import re
import subprocess
import sys
import tempfile
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOOLS = os.path.join(ROOT, "platform", "tools")
TMP = tempfile.mkdtemp(prefix="rwdp_app_")
if os.path.realpath(TMP).startswith(os.path.realpath(ROOT) + os.sep):
    raise SystemExit("TMPDIR points inside the checkout — rendered pages must never land in the "
                     "tree; unset TMPDIR or point it elsewhere")

VIEWS = ("flow", "rules", "worksheet")               # render_html.py's own vocabulary
LABELS = {"flow": "where this stands", "rules": "every rule, three ways",
          "worksheet": "what to prepare"}            # plain-language link text for each view


def packs():
    """The served allowlist — a pack exists because the COMMIT holds it, never because a URL or a
    directory names it. Discovery used to glob the filesystem, and git does not track directories:
    an untracked (or .gitignore'd) `products/.../handoff` directory read as a pack, appeared on
    the board, and served under the clean commit footer — an external review planted exactly
    that. `git ls-files` lists the INDEX, so only tracked content can found a pack; an unreadable
    listing yields no packs, and _proven() is already refusing by then."""
    r = subprocess.run(["git", "ls-files", "--", "products/*/*/*/handoff/*"], cwd=ROOT,
                       capture_output=True, text=True, encoding="utf-8")
    if r.returncode != 0:
        return []
    return sorted({"/".join(p.split("/")[:4]) for p in (r.stdout or "").splitlines()
                   if p.count("/") >= 4})


def commit():
    r = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=ROOT,
                       capture_output=True, text=True, encoding="utf-8")
    return r.stdout.strip() or "unknown"


def _dirty():
    """Paths the working tree changed relative to HEAD, or ['(unreadable)'] when git cannot say.

    The footer stamps a COMMIT, and the pages are rendered from the FILES — an edited checkout
    serves content the stamped commit never contained, which an external review demonstrated: a
    hand-edited register under a clean footer. An unreadable status is treated as dirty, because
    "cannot tell" and "clean" must never be the same answer."""
    r = subprocess.run(["git", "status", "--porcelain"], cwd=ROOT,
                       capture_output=True, text=True, encoding="utf-8")
    if r.returncode != 0:
        return ["(git status unreadable)"]
    return [ln for ln in r.stdout.splitlines() if ln.strip()]


def _provenance():
    """(commit, version) — the STARTUP identity the footer stamps. Either may be 'unknown';
    _proven() turns that into a refusal to serve — see below."""
    try:
        ver = open(os.path.join(ROOT, "platform", "VERSION"), encoding="utf-8").read().strip()
    except OSError:
        ver = "unknown"
    try:
        c = commit()
    except OSError:
        c = "unknown"
    return c, ver


COMMIT, VERSION = None, None                         # filled by main; tests may call _provenance


def _proven():
    """A governance window ties every page to a merged commit and a platform version — VERIFIED
    PER REQUEST, not remembered from startup. Three ways the footer's claim can stop being true,
    each a refusal: provenance resolved 'unknown'; HEAD moved under the running app (the footer
    would stamp a commit the checkout no longer holds); the working tree is DIRTY (the pages are
    rendered from the files, so an edited checkout serves content the stamped commit never
    contained — under a clean footer, which is the disguise an external review demonstrated).
    Fail-closed on all three."""
    global COMMIT, VERSION
    if COMMIT is None:
        COMMIT, VERSION = _provenance()
    if "unknown" in (COMMIT, VERSION):
        return False
    try:
        now = commit()
    except OSError:
        now = "unknown"
    return now == COMMIT and not _dirty()


def _refusal():
    """The 503 every route serves while provenance cannot be proven. Its own footer may say
    'unknown' — that is the one page where the word is the truth being told."""
    return 503, _frame("cannot prove what is being served",
                       "<h1>cannot prove what is being served</h1>"
                       "<p>every page here must be tied to a merged commit and a platform "
                       "version, and rendered from exactly that commit's files. at least one of "
                       "these is not true right now: git metadata or platform/VERSION is "
                       "unreadable, HEAD moved under the running app, or the working tree has "
                       "uncommitted changes — an edited checkout under a clean footer proves "
                       "nothing. no page is served until the checkout matches what the footer "
                       "would claim; fix the deployment (commit or discard the edits) and "
                       "restart.</p>")


TOOL_TIMEOUT = 60      # seconds — a governed tool that hangs must fail the request, never the app
TOOL_CAP = 262144      # chars kept per captured stream — real listings and error tails fit;
                       # a runaway tool's output must not balloon a response or the process


def _tool(args):
    """Run one governed tool exactly as the CLI would — the tools stay the one owner of every
    page; this app never re-implements a view. Bounded IN MEMORY, not merely in output:
    `capture_output=True` collected a child's ENTIRE stream before the slice, so a 64 MiB
    stdout cost ~200 MiB of peak RSS to return 256 KiB — an external review measured it. The
    streams are read incrementally into capped buffers and a child that exceeds the cap or the
    timeout is KILLED and reported (returncode 124, the shell's own timeout convention)."""
    import threading
    cmd = [sys.executable, os.path.join(TOOLS, args[0])] + args[1:]
    p = subprocess.Popen(cmd, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    def _drain(stream, keep_head):
        """Read to EOF in chunks, keeping only TOOL_CAP bytes (head for stdout — results read
        top-down; tail for stderr — the failing line comes last). Overflow is drained and
        dropped so the child never blocks on a full pipe."""
        kept, total = b"", 0
        while True:
            chunk = stream.read(65536)
            if not chunk:
                return kept, total
            total += len(chunk)
            if keep_head:
                if len(kept) < TOOL_CAP:
                    kept += chunk[:TOOL_CAP - len(kept)]
            else:
                kept = (kept + chunk)[-TOOL_CAP:]
            if total > TOOL_CAP * 64:                # runaway stream: kill, keep what we have
                try:
                    p.kill()
                except OSError:
                    pass
                return kept, total

    out = {}
    threads = [threading.Thread(target=lambda k, s, h: out.__setitem__(k, _drain(s, h)),
                                args=(k, s, h), daemon=True)
               for k, s, h in (("out", p.stdout, True), ("err", p.stderr, False))]
    for t in threads:
        t.start()
    try:
        rc = p.wait(timeout=TOOL_TIMEOUT)
    except subprocess.TimeoutExpired:
        p.kill()
        p.wait()
        rc = 124
    for t in threads:
        t.join(timeout=5)
    stdout = out.get("out", (b"", 0))[0].decode("utf-8", "replace")
    stderr = out.get("err", (b"", 0))[0].decode("utf-8", "replace")
    if rc == 124 and not stderr:
        stderr = (f"{args[0]} timed out after {TOOL_TIMEOUT}s — no page is served from a tool "
                  f"that did not finish")
    return subprocess.CompletedProcess(cmd, rc, stdout=stdout, stderr=stderr)


def _scrub(text):
    """Tool stderr reaches the browser on failure pages; the tool's own message must survive,
    but machine paths must not — a governance window does not disclose where the checkout
    lives. Only the checkout-root prefix is cut; relative paths still point at the file."""
    return (text or "").replace(ROOT + os.sep, "").replace(ROOT, "")


def _frame(title, body):
    # Accessibility floor, no framework: explicit html/lang for screen readers, viewport for
    # phones, and the content in <main> so its headings outline a document, not a fragment.
    global COMMIT, VERSION
    if COMMIT is None:
        COMMIT, VERSION = _provenance()
    return (f"<!doctype html><html lang='en'><head><meta charset='utf-8'>"
            f"<meta name='viewport' content='width=device-width, initial-scale=1'>"
            f"<title>{html.escape(title)}</title></head>"
            f"<body style='font-family:sans-serif;max-width:70em;margin:2em auto'>"
            f"<main>{body}</main>"
            f"<hr><footer><small>read-only · serving commit {COMMIT} · platform v{VERSION} — "
            f"approvals, signatures and decision answers are committed file edits by a named "
            f"person, never acts of this app</small></footer></body></html>").encode("utf-8")


STATUS_FAILED = "status unavailable — the status tool failed; this page will not guess"


def _standings():
    """{pack: status.py's own one-line standing}, or None when status.py itself failed. The
    words are the tool's, never this app's — a summary the app composed itself would be a second
    implementation of status, free to flatter. A nonzero exit is a FAILURE, never an empty
    board: whatever status.py printed before dying is plausible rows, and blank standings read
    as 'no news is good news' — so the caller gets None and must say so, not guess.
    status.py separates its columns with runs of spaces; collapsing those runs to one space fused
    'Gate 1' into '3 open' — so column gaps become ' · ', and the words inside stay untouched."""
    r = _tool(["status.py"])
    if r.returncode != 0:
        return None
    out = {}
    for line in (r.stdout or "").splitlines():
        s = line.strip()
        if s.startswith("products/"):
            cols = re.split(r"\s{2,}", s)
            out[cols[0]] = " · ".join(c.strip() for c in cols[1:] if c.strip())
    # EXIT ZERO WITH NO ROWS IS A FAILURE, not a quiet board. A truncated or reshaped status
    # output parsed to zero standings and the page rendered every pack blank — which reads as
    # "no news is good news", the exact disguise the nonzero-exit branch already refuses.
    if not out:
        return None
    return out


def index():
    # Two links lead, because they are the two acts a stakeholder takes: see where it stands, see
    # what is owed. The reviewer views (rules, worksheet) stay one click away but read as "deeper",
    # not as a menu of equal things — the streamlined loop, not a file listing.
    # EVERY pack status.py reports is on the board — a page titled "where everything stands" that
    # silently hides the packs with no handoff/ yet is a summary free to flatter. Those rows carry
    # their standing and say why there is nothing to click.
    if not _proven():
        return _refusal()
    standing = _standings()
    served = packs()
    if standing is None:
        # status.py died: the board still lists every served pack (the links still work), but a
        # banner and EVERY row say the standing is unavailable — an honest outage, never blank
        # standings that read as "all quiet"
        banner = f"<p role='alert'><strong>{html.escape(STATUS_FAILED)}</strong></p>"
        standing = {p: STATUS_FAILED for p in served}
    else:
        banner = ""
    # `p` is a repository path and repository paths are DATA here, exactly like tool output: a
    # pack directory named `<script>…` must render as its own strange name, never execute. An
    # external review demonstrated stored markup injection through this interpolation.
    rows = "".join(
        f"<li style='margin-bottom:.8em'><b>{html.escape(p)}</b><br>"
        f"<span>{html.escape(standing.get(p, ''))}</span><br>"
        + (f"<a href='page?view=flow&pack={q}'>{LABELS['flow']}</a>"
           f" · <a href='questions?pack={q}'>questions awaiting an answer</a><br>"
           f"<small>deeper: <a href='page?view=rules&pack={q}'>{LABELS['rules']}</a>"
           f" · <a href='page?view=worksheet&pack={q}'>{LABELS['worksheet']}</a></small>"
           if p in served else
           "<small>no handoff yet — nothing to serve; the standing above is the whole story</small>")
        + "</li>"
        for p in sorted(set(served) | set(standing)) for q in [urllib.parse.quote(p)])
    # No /suggest link here: the route survives for those who know it, but review measured its
    # precision as indefensible for a stakeholder front page — the board does not advertise it.
    body = (f"<h1>RWD data products — where everything stands</h1>{banner}"
            f"<p>Every number on every page here is computed by the governed tools from the merged "
            f"repository state named in the footer — nothing is typed in, cached, or editable from "
            f"this app. If a page says something is blocked, it is blocked; the page also says who "
            f"owes the next action.</p><ul>{rows}</ul>"
            f"<form action='knowledge'><label for='q'>search past decisions</label> "
            f"<input id='q' name='q' placeholder='have we decided … before?' "
            f"size='40'><button>search</button></form>")
    return 200, _frame("RWD governance", body)


def _render(cli):
    """Run a page generator into a PER-REQUEST temp file and return its bytes.

    Per request, not per (view, pack): a shared path let two concurrent requests for the same
    page write over each other's file and serve a torn read — the server is threaded, so this is
    not theoretical. Each request gets its own file and removes it after reading."""
    fd, out = tempfile.mkstemp(suffix=".html", dir=TMP)
    os.close(fd)
    try:
        r = _tool(cli + ["--out", out])
        if r.returncode != 0 or not os.path.getsize(out):
            # scrub BEFORE truncating, so a cut can never resurrect a path prefix
            return 500, _frame("failed",
                               f"<pre>{html.escape(_scrub(r.stderr or r.stdout)[-2000:])}</pre>")
        raw = open(out, "rb").read()
        # the provenance footer rides EVERY page, generated ones included — a page without the
        # served commit is a page nobody can tie to a merged state
        foot = _frame("x", "").split(b"<hr>", 1)[1].rsplit(b"</body>", 1)[0]
        if b"</body>" in raw:
            return 200, raw.replace(b"</body>", b"<hr>" + foot + b"</body>", 1)
        return 200, raw + b"<hr>" + foot
    finally:
        try:
            os.unlink(out)
        except OSError:
            pass


def page(view, pack):
    if not _proven():
        return _refusal()
    if view not in VIEWS or pack not in packs():
        return 404, _frame("not here", "<p>unknown view, or a pack this repository does not hold "
                                       "or cannot serve yet (no handoff/).</p>")
    return _render(["render_html.py", view, pack])


def questions(pack):
    if not _proven():
        return _refusal()
    if pack not in packs():
        return 404, _frame("not here", "<p>unknown pack.</p>")
    return _render(["decision_packet.py", pack])


def knowledge(q):
    # A query term is DATA, never a flag: without the strip, `?q=--suggest` reached the CLI's
    # argument parser and ran a different verb than the route promises. Leading dashes carry no
    # meaning for a substring search, so they are dropped rather than refused.
    if not _proven():
        return _refusal()
    terms = [t.lstrip("-") for t in q.split() if t.strip().lstrip("-")]
    if not terms:
        return 200, _frame("search", "<p>type terms, e.g. <i>biomarker window</i>.</p>")
    r = _tool(["knowledge_graph.py", "--query"] + terms)
    if r.returncode != 0:                            # no-match exits 0; nonzero is a FAILURE
        return 500, _frame("failed",
                           f"<pre>{html.escape(_scrub(r.stderr or r.stdout)[-2000:])}</pre>")
    return 200, _frame(f"decisions: {q}", f"<pre>{html.escape(r.stdout)}</pre>")


def suggest():
    if not _proven():
        return _refusal()
    r = _tool(["knowledge_graph.py", "--suggest"])
    if r.returncode != 0:
        return 500, _frame("failed",
                           f"<pre>{html.escape(_scrub(r.stderr or r.stdout)[-2000:])}</pre>")
    return 200, _frame("candidates", f"<pre>{html.escape(r.stdout)}</pre>")


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(u.query)
        one = lambda k: (qs.get(k) or [""])[0]
        if not _proven():
            # EVERY route refuses on unknown provenance, the 404 page included — a page that
            # cannot be tied to a merged commit proves nothing, whatever its status code
            status, body = _refusal()
        elif u.path == "/":
            status, body = index()
        elif u.path == "/page":
            status, body = page(one("view"), one("pack"))
        elif u.path == "/questions":
            status, body = questions(one("pack"))
        elif u.path == "/knowledge":
            status, body = knowledge(one("q"))
        elif u.path == "/suggest":
            status, body = suggest()
        else:
            status, body = 404, _frame("not here", "<p>four routes and a search box; "
                                                   "nothing else is served.</p>")
        # PROVENANCE, RE-VERIFIED AFTER RENDERING. The check at the top ran BEFORE the tools
        # read the files; an edit landing in that window rendered edited content under the old
        # clean footer — an external review timed exactly that race. The window between this
        # check and the socket write is the irreducible remainder; everything the tools READ is
        # inside the two checks.
        if status == 200 and not _proven():
            status, body = _refusal()
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        # the window has no hands: no route accepts a write, so say 405, not an ambiguous 501
        # (unless provenance is unknown — the refusal outranks even the refusal to write)
        if not _proven():
            code, body = _refusal()
        else:
            code = 405
            body = _frame("read-only", "<p>this app accepts no writes — approvals and answers "
                                       "are committed file edits by a named person.</p>")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Allow", "GET")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):                 # quiet; Domino keeps its own access logs
        pass


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8888"))
    host = os.environ.get("HOST", "0.0.0.0")   # Domino needs 0.0.0.0; set HOST=127.0.0.1 locally
    print(f"rwdp governance app: read-only, commit {commit()}, {host}:{port}")
    ThreadingHTTPServer((host, port), Handler).serve_forever()
