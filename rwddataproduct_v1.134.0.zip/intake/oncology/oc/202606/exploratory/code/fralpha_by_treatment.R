# FRalpha status at index by treatment (Mirvetuximab vs ICC), for ovarian patients on 2L-4L
# lines. A patient can be in both arms; each arm uses its own first dose date. ICC must be a
# single drug, unless the line also has mirvetuximab. Builds Table 1 (counts and %).
# Pulls from Databricks over ODBC, then works on local data frames with dplyr:
#   DATABRICKS_DSN=RWDE DATABRICKS_PWD=... Rscript fralpha_by_treatment.R

library(dplyr); library(tidyr); library(stringr)

# ---- config ----
catalog         <- Sys.getenv("FRA_CATALOG", "hive_metastore")
schema          <- "clnprw_flatiron_pano_ovar_use"
drugepisode_tbl <- "t_drugepisode_2026m06"
biomarker_tbl   <- "t_enh_ovbiomarkers_2026m06"   # FOLR1 biomarker snapshot
biomarker_name  <- "FOLR1/FRalpha"
index_lines     <- c(2L, 3L, 4L)
bio_window_days <- 14L
pct_scale       <- Sys.getenv("FRA_PCT_SCALE", "percent") # fraction | percent | auto
source_mode     <- Sys.getenv("FRA_SOURCE_MODE", "dbi")  # dbi | local
local_dir       <- Sys.getenv("FRA_LOCAL_DIR", "")

ARM_ICC   <- "ICC (Paclitaxel, PLD, or topotecan)"
FRA_ORDER <- c("FRa high", "FRa low", "FRa moderate", "Unknown/untested")   # table row order
FRA_RANK  <- c("FRa high", "FRa moderate", "FRa low", "Unknown/untested")   # best to worst

this_dir <- tryCatch(dirname(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))),
                     error = function(e) ".")
if (!length(this_dir) || this_dir == "") this_dir <- "."
out_dir <- Sys.getenv("FRA_OUT_DIR", file.path(this_dir, "outputs"))

# ---- load a table into a local data frame ----
load_tbl <- function(tbl, cols) {
  df <- if (source_mode == "local") {
    stopifnot(nzchar(local_dir))
    pq <- file.path(local_dir, paste0(tbl, ".parquet"))
    cs <- file.path(local_dir, paste0(tbl, ".csv"))
    if      (file.exists(pq)) as_tibble(arrow::read_parquet(pq))
    else if (file.exists(cs)) as_tibble(readr::read_csv(cs, show_col_types = FALSE))
    else stop(sprintf("no extract for %s in %s", tbl, local_dir))
  } else {
    fqtn <- paste(c(catalog, schema, tbl), collapse = ".")
    as_tibble(DBI::dbGetQuery(con, sprintf("SELECT %s FROM %s", paste(cols, collapse = ", "), fqtn)))
  }
  # Databricks may hand back a column in mixed case (e.g. PercentStaining). The script uses
  # lowercase names, so make them lowercase here.
  names(df) <- tolower(names(df))
  miss <- setdiff(cols, names(df))
  if (length(miss)) stop(sprintf("%s is missing column(s): %s", tbl, paste(miss, collapse = ", ")))
  df[, cols, drop = FALSE]
}

# ---- FRalpha result: percent, intensity, class ----
# PercentStaining is text like "75%", so default to percent. "auto" reads it from the data.
resolve_scale <- function(num) {
  if (pct_scale %in% c("fraction", "percent")) return(pct_scale)
  v <- num[!is.na(num)]
  if (!length(v)) return("percent")
  if (max(v) <= 1) return("fraction")
  if (min(v) > 1)  return("percent")
  stop("PercentStaining has values on both sides of 1 — set FRA_PCT_SCALE to 'fraction' or 'percent'.")
}
pct_numeric <- function(x) suppressWarnings(as.numeric(str_replace_all(as.character(x), "[^0-9.\\-]", "")))
to_pct <- function(x, scale) { num <- pct_numeric(x); if (scale == "fraction") num * 100 else num }
to_intensity <- function(x) {
  s <- str_to_lower(as.character(x))
  # accept "3+", a word (strong/moderate/weak), or a bare digit
  case_when(str_detect(s, "3\\s*\\+|strong")             ~ 3L,
            str_detect(s, "2\\s*\\+|moderate")           ~ 2L,
            str_detect(s, "1\\s*\\+|weak")               ~ 1L,
            str_detect(s, "negative|no staining")        ~ 0L,
            str_detect(s, "(^|[^0-9])3([^0-9]|$)")       ~ 3L,
            str_detect(s, "(^|[^0-9])2([^0-9]|$)")       ~ 2L,
            str_detect(s, "(^|[^0-9])1([^0-9]|$)")       ~ 1L,
            str_detect(s, "(^|[^0-9])0([^0-9]|$)")       ~ 0L,
            TRUE ~ NA_integer_)
}
fra_class <- function(pct, intensity) {
  case_when(pct >= 75 & intensity %in% c(2L, 3L)            ~ "FRa high",
            pct >= 50 & pct < 75 & intensity %in% c(2L, 3L) ~ "FRa moderate",
            (pct < 50) | (intensity <= 1L)                  ~ "FRa low",
            TRUE                                            ~ "Unknown/untested")
}

# ---- treatment arm from drug name ----
arm_of <- function(drugname) {
  d <- str_to_lower(drugname)
  case_when(str_detect(d, "mirvetuximab")                      ~ "Mirvetuximab",
            str_detect(d, "topotecan")                         ~ ARM_ICC,
            str_detect(d, "doxil|lipodox|caelyx")              ~ ARM_ICC,  # pegylated liposomal doxorubicin
            str_detect(d, "doxorubicin") & str_detect(d, "liposom|pegylat") ~ ARM_ICC,
            str_detect(d, "paclitaxel")                        ~ ARM_ICC,
            TRUE                                               ~ NA_character_)
}
is_nab      <- function(d) { d2 <- str_squish(str_to_lower(d))
  str_detect(d2, "paclitaxel") & str_detect(d2, "nab|protein[- ]?bound|albumin|abraxane") }
is_nonmaint <- function(x) str_to_lower(str_trim(as.character(x))) %in% c("false","f","n","no","0")
is_advanced <- function(s) str_to_lower(str_trim(coalesce(as.character(s), ""))) == "advanced"

# ---- build the markdown table ----
table1_md <- function(df, title) {
  d <- df %>% mutate(arm = factor(arm, c("Mirvetuximab", ARM_ICC)),
                     fra = factor(fra, FRA_ORDER)) %>%
    count(arm, fra, .drop = FALSE, name = "n") %>%
    group_by(arm) %>% mutate(tot = sum(n), pct = if_else(tot > 0, 100 * n / tot, NA_real_)) %>% ungroup()
  cell <- function(a, f) { r <- d[d$arm == a & d$fra == f, ]
    if (is.na(r$pct)) sprintf("%d", r$n) else sprintf("%d (%.1f%%)", r$n, r$pct) }
  nm <- sum(d$n[d$arm == "Mirvetuximab"]); ni <- sum(d$n[d$arm == ARM_ICC])
  out <- c(sprintf("### %s", title),
           sprintf("| FOLR1/FRalpha at index (N, %%) | Mirvetuximab (N = %d) | %s (N = %d) |", nm, ARM_ICC, ni),
           "|---|---|---|")
  for (f in FRA_ORDER) out <- c(out, sprintf("| %s | %s | %s |", f, cell("Mirvetuximab", f), cell(ARM_ICC, f)))
  paste(out, collapse = "\n")
}

# ---- run ----
run_analysis <- function() {
  if (!pct_scale %in% c("fraction", "percent", "auto"))
    stop("FRA_PCT_SCALE must be 'fraction', 'percent', or 'auto'.")
  if (!source_mode %in% c("dbi", "local"))
    stop("FRA_SOURCE_MODE must be 'dbi' or 'local'.")
  if (source_mode == "dbi" && !exists("con")) {
    pwd <- Sys.getenv("DATABRICKS_PWD", "")
    if (!nzchar(pwd))
      stop("set DATABRICKS_PWD, or provide a DBI `con`, or use FRA_SOURCE_MODE=local.")
    # Databricks over ODBC. bigint = "character" keeps 64-bit ids (patientid) EXACT — a true out-of-range
    # BIGINT would lose precision as a double and could collide in a join/distinct. linenumber is coerced
    # back to numeric at load (below), so the line filters and math still work.
    con <<- DBI::dbConnect(odbc::odbc(), dsn = Sys.getenv("DATABRICKS_DSN", "RWDE"),
                           pwd = pwd, timeout = 120, bigint = "character")
  }

  drugep <- load_tbl(drugepisode_tbl,
                     c("patientid","drugname","linenumber","linesetting","ismaintenancetherapy","episodedate"))
  biomk  <- load_tbl(biomarker_tbl,
                     c("patientid","biomarkername","specimenreceiveddate","resultdate","percentstaining","stainingintensity"))

  drugep <- drugep %>% mutate(linenumber = suppressWarnings(as.numeric(linenumber))) %>%
    filter(!is.na(patientid))    # patientid stays exact (character); linenumber -> numeric for the 2L-4L filter
  biomk  <- biomk  %>% filter(!is.na(patientid))

  # ---- qualifying episodes, per arm (a patient can be in both) ----
  # Per line: how many drugs, and does it include mirvetuximab (needed for the ICC rule).
  line_comp <- drugep %>%
    filter(linenumber %in% index_lines, is_nonmaint(ismaintenancetherapy)) %>%
    mutate(agent = str_split(str_squish(str_to_lower(drugname)), "\\s*[,/+;&|]\\s*")) %>%
    tidyr::unnest(agent) %>%
    filter(!is.na(agent), agent != "") %>%
    group_by(patientid, linenumber) %>%
    summarise(n_agents = n_distinct(agent),
              has_mirv = any(str_detect(agent, "mirvetuximab")), .groups = "drop")

  base_ep <- drugep %>% mutate(episodedate = as.Date(episodedate)) %>%
    filter(linenumber %in% index_lines, is_nonmaint(ismaintenancetherapy))
  # Split each drug name so a single "mirve + ICC" value can feed both arms.
  agent_ep <- base_ep %>% filter(!is.na(episodedate)) %>%
    mutate(agent = str_split(str_squish(str_to_lower(drugname)), "\\s*[,/+;&|]\\s*")) %>%
    tidyr::unnest(agent) %>% filter(agent != "") %>%
    mutate(arm = arm_of(agent)) %>%
    left_join(line_comp, by = c("patientid","linenumber"))

  # Mirvetuximab arm: any line with mirvetuximab (combinations are fine).
  mirv_ep <- agent_ep %>% filter(arm == "Mirvetuximab")
  # ICC arm: an ICC drug (not nab) that is the only drug on the line, or on a line that also
  # has mirvetuximab (that line counts in both arms).
  icc_ep  <- agent_ep %>% filter(arm == ARM_ICC, !is_nab(agent), n_agents == 1 | has_mirv)
  # Missing dates: an undated dose can't set the index, so an arm can shift to a later date
  # or be missed. Report the total dropped, and how many patients this may affect per arm.
  n_nodate <- base_ep %>% filter(is.na(episodedate), !is.na(arm_of(drugname))) %>% nrow()
  undated_ag <- base_ep %>% filter(is.na(episodedate)) %>%
    mutate(agent = str_split(str_squish(str_to_lower(drugname)), "\\s*[,/+;&|]\\s*")) %>%
    tidyr::unnest(agent) %>% filter(agent != "") %>% mutate(arm = arm_of(agent))
  n_mirv_nd <- n_distinct(undated_ag$patientid[undated_ag$arm == "Mirvetuximab"])
  n_icc_nd  <- n_distinct(undated_ag$patientid[undated_ag$arm == ARM_ICC & !is_nab(undated_ag$agent)])

  # ---- FRalpha per patient (score once, apply the window per arm) ----
  folr1 <- biomk %>% filter(str_to_upper(str_trim(biomarkername)) == str_to_upper(biomarker_name))
  if (nrow(folr1) == 0)
    stop(sprintf("no records match biomarkername='%s' in %s — check the table and name.", biomarker_name, biomarker_tbl))
  scale    <- resolve_scale(pct_numeric(folr1$percentstaining))
  if (pct_scale == "auto" && scale == "fraction")
    message("PercentStaining read as fractions (all values <=1); set FRA_PCT_SCALE explicitly for the final run.")
  pct_norm <- to_pct(folr1$percentstaining, scale)
  if (any(pct_norm > 100 + 1e-9 | pct_norm < 0, na.rm = TRUE))
    stop(sprintf("PercentStaining out of 0-100 after scaling (%.2f..%.2f) — check FRA_PCT_SCALE.",
                 min(pct_norm, na.rm = TRUE), max(pct_norm, na.rm = TRUE)))
  fin     <- pct_norm[is.finite(pct_norm)]
  if (!length(fin)) message("no usable PercentStaining — high/moderate not possible; using intensity only.")
  pct_rng <- if (length(fin)) sprintf("%.3g..%.3g", min(fin), max(fin)) else "n/a"
  scored <- folr1 %>%
    mutate(test_date = pmax(as.Date(specimenreceiveddate), as.Date(resultdate), na.rm = TRUE),
           rec = fra_class(pct_norm, to_intensity(stainingintensity)))

  # best FRalpha among the patient's tests inside that arm's window; none -> Unknown
  attach_fra <- function(pop1) {   # pop1 = one arm, one row per patient
    f <- scored %>% inner_join(select(pop1, patientid, index_date), by = "patientid") %>%
      filter(!is.na(test_date), test_date <= index_date + bio_window_days) %>%
      mutate(rank = match(rec, FRA_RANK)) %>%
      group_by(patientid) %>% summarise(rank = min(rank), .groups = "drop") %>%
      transmute(patientid, fra = FRA_RANK[rank])
    pop1 %>% left_join(f, by = "patientid") %>% mutate(fra = coalesce(fra, "Unknown/untested"))
  }

  # each arm on its own: one row per patient, index = first qualifying dose of that arm
  arm_pop <- function(ep, arm_label, advanced_only = FALSE) {
    if (advanced_only) ep <- ep %>% filter(is_advanced(linesetting))
    p <- ep %>% group_by(patientid) %>% slice_min(episodedate, n = 1, with_ties = FALSE) %>% ungroup() %>%
      transmute(patientid, arm = arm_label, index_date = episodedate)
    attach_fra(p)
  }
  build_pop <- function(advanced_only)
    bind_rows(arm_pop(mirv_ep, "Mirvetuximab", advanced_only), arm_pop(icc_ep, ARM_ICC, advanced_only))

  all_pop <- build_pop(FALSE)   # any setting
  adv_pop <- build_pop(TRUE)    # advanced only, chosen independently

  t_all <- table1_md(all_pop, "Table 1a — all 2L-4L lines (any setting)")
  t_adv <- table1_md(adv_pop, "Table 1b — advanced setting only")
  both_of <- function(p) length(intersect(p$patientid[p$arm == "Mirvetuximab"], p$patientid[p$arm == ARM_ICC]))
  summary <- paste(
    "A patient can be in both arms. Each arm uses its own first dose date.",
    sprintf("Cohort 1a: Mirv %d, ICC %d patients (%d counted in both).",
            n_distinct(all_pop$patientid[all_pop$arm == "Mirvetuximab"]),
            n_distinct(all_pop$patientid[all_pop$arm == ARM_ICC]), both_of(all_pop)),
    sprintf("Cohort 1b (advanced): Mirv %d, ICC %d patients (%d counted in both).",
            n_distinct(adv_pop$patientid[adv_pop$arm == "Mirvetuximab"]),
            n_distinct(adv_pop$patientid[adv_pop$arm == ARM_ICC]), both_of(adv_pop)),
    sprintf("FOLR1 records: %d rows, %d patients. PercentStaining scale=%s (range %s).",
            nrow(folr1), n_distinct(folr1$patientid), scale, pct_rng),
    sprintf("Target episodes dropped for missing date: %d (undated qualifying agents, review if >0: %d mirvetuximab, %d ICC patients).",
            n_nodate, n_mirv_nd, n_icc_nd),
    sprintf("Source: %s / %s.%s.", drugepisode_tbl, biomarker_tbl, biomarker_name),
    sep = "\n")

  cat("\n", summary, "\n\n", t_all, "\n\n", t_adv, "\n", sep = "")
  dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)
  writeLines(c(summary, "", t_all, "", t_adv), file.path(out_dir, "fralpha_by_treatment.md"))
  message(sprintf("wrote %s", file.path(out_dir, "fralpha_by_treatment.md")))
  invisible(list(all = all_pop, adv = adv_pop, table1_all = t_all, table1_adv = t_adv))
}

if (!nzchar(Sys.getenv("FRA_DEFINE_ONLY"))) run_analysis()
