# Snapshot comparison — diff two profile_<cut>.tsv files (from data_profiler.R) into a data refresh
# change summary: what changed in the data between an OLD and a NEW snapshot, not just which columns
# were added or dropped. Standalone, works for any tumor/product. dplyr only, no Spark or Databricks —
# it just reads the two metrics files the profiler already wrote, so it never re-queries the
# database and never overwrites those files.
#
# TO RUN: point it at the two profiles (edit CFG, or pass them as arguments):
#   Rscript compare_snapshots.R outputs/2026m03/profile_2026m03.tsv outputs/2026m06/profile_2026m06.tsv
# Any CFG value can also be set with its CMP_* env var (env wins).
#
# TWO reports are written from one comparison:
#   - data_refresh_change_summary.html  — stakeholder view: the columns whose VALUES changed, in plain
#     language with exact old→new evidence, most material first.
#   - snapshot_comparison.html          — technical view: every signal, change-family composition, full
#     schema diff, thresholds and formulas. (Plus snapshot_comparison.md as the record.)
#
# A "review signal" is a REAL change in the data values a stakeholder acts on: completeness (missingness),
# numeric distribution (SMD / quantile / constant), category mix, date quality, or a true storage-type
# change. A profiler-interpretation change (KIND numeric<->categorical) or a bare cardinality change is
# NOT a review signal — it is a by-product of how the profiler summarises a column (the numeric-vs-
# categorical threshold), not a source-data change, so it is reported only as a technical/structural note.
# Flags are size-based CANDIDATES to review — whether a change matters clinically is a human call.

library(dplyr); library(stringr)

# ============================ CONFIG — edit these, then run ============================
CFG <- list(
  old = "",       # path to the OLD snapshot's profile_<cut>.tsv   (or 1st CLI arg / CMP_OLD)
  new = "",       # path to the NEW snapshot's profile_<cut>.tsv   (or 2nd CLI arg / CMP_NEW)
  out_dir = "",   # where the reports are written; "" = ./outputs next to this script   (CMP_OUT)
  # -- optional metadata shown in the header (blank = the row is omitted) --
  product = "",           # product / tumor name, e.g. "OC Panoramic"                   (CMP_PRODUCT)
  run_id  = "",           # run identifier for the header/footer                        (CMP_RUN_ID)
  thresholds_label = "default-v1",  # stable label/version for this threshold set        (CMP_THRESHOLDS_LABEL)
  # -- flag thresholds: what counts as a shift worth reviewing --
  miss_pts     = 5,     # flag |Δ % missing| >= this many percentage points        (CMP_MISS_PTS)
  rows_pct     = 10,    # note |Δ table row count| >= this %                        (CMP_ROWS_PCT)
  distinct_pct = 20,    # flag |Δ distinct-per-non-missing| >= this %               (CMP_DISTINCT_PCT)
  smd          = 0.10,  # flag continuous |SMD| >= this                             (CMP_SMD)
  cat_pts      = 10,    # flag categorical |Δ share| >= this many points, or a top  (CMP_CAT_PTS)
                        #   value entering/leaving the top list
  cat_min      = 1      # ignore categories below this % share                      (CMP_CAT_MIN)
)
# ======================================================================================

TOP_N_STAKE <- 15   # most-material review items shown in the stakeholder summary (rest go to the detail)

getcfg  <- function(env, default) { v <- Sys.getenv(env, ""); if (nzchar(v)) v else default }
getcfgn <- function(env, default) { v <- Sys.getenv(env, ""); if (nzchar(v)) as.numeric(v) else as.numeric(default) }
args <- commandArgs(trailingOnly = TRUE)
old_path <- if (length(args) >= 1) args[1] else getcfg("CMP_OLD", CFG$old)
new_path <- if (length(args) >= 2) args[2] else getcfg("CMP_NEW", CFG$new)
miss_pts     <- getcfgn("CMP_MISS_PTS",     CFG$miss_pts)
rows_pct     <- getcfgn("CMP_ROWS_PCT",     CFG$rows_pct)
distinct_pct <- getcfgn("CMP_DISTINCT_PCT", CFG$distinct_pct)
smd_thresh   <- getcfgn("CMP_SMD",          CFG$smd)
cat_pts      <- getcfgn("CMP_CAT_PTS",      CFG$cat_pts)
cat_min      <- getcfgn("CMP_CAT_MIN",      CFG$cat_min)
product   <- getcfg("CMP_PRODUCT",          CFG$product)
run_id    <- getcfg("CMP_RUN_ID",           CFG$run_id)
thr_label <- getcfg("CMP_THRESHOLDS_LABEL", CFG$thresholds_label)

this_dir <- tryCatch(dirname(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))),
                     error = function(e) ".")
if (!length(this_dir) || this_dir == "") this_dir <- "."
out_dir <- { v <- getcfg("CMP_OUT", CFG$out_dir); if (nzchar(v)) v else file.path(this_dir, "outputs") }

# ---- read ----
NUM_COLS <- c("n_rows","n_rows_total","n_nonmissing","n_missing","pct_missing","distinct",
              "mean","sd","min","p1","p5","p10","p25","p50","p75","p90","p95","p99","max","unparseable")
read_profile <- function(path, label) {
  if (!nzchar(path)) stop(sprintf("%s profile path is empty — set it in CFG, CMP_%s, or as a CLI arg.",
                                  label, toupper(label)))
  if (!file.exists(path)) stop(sprintf("%s profile not found: %s", label, path))
  # A profile_new_<cut>.tsv is the partial (new-columns-only) profile from DC_NEW_ONLY. Comparing it
  # would give a bogus diff — every column it skipped would look "dropped" — so reject it loudly,
  # the same as qc_runner does before calling this.
  if (grepl("profile_new", basename(path), fixed = TRUE))
    stop(sprintf("%s is a PARTIAL profile (profile_new_*, new columns only) — drift needs a COMPLETE profile_<cut>.tsv, not a subset: %s",
                 label, path))
  df <- utils::read.delim(path, sep = "\t", quote = "", na.strings = "",
                          stringsAsFactors = FALSE, check.names = FALSE, colClasses = "character")
  need <- c("table_base","column","kind")
  if (!all(need %in% names(df)))
    stop(sprintf("%s (%s) doesn't look like a profile_<cut>.tsv — missing %s",
                 label, path, paste(setdiff(need, names(df)), collapse = ", ")))
  # Need one row per (table_base, column): the two profiles are joined on that key, so a duplicate
  # (a cut=all profile, or a hand-edited/merged file) would fan the join out and quietly break every
  # per-column delta. Reject it loudly instead of comparing bad input.
  dup <- unique(paste(df$table_base, df$column, sep = "|")[duplicated(paste(df$table_base, df$column, sep = "|"))])
  if (length(dup))
    stop(sprintf("%s (%s) has duplicate table_base|column rows (%s) — a full profile_<cut>.tsv must be one row per column (not a cut=all or merged file).",
                 label, path, paste(utils::head(dup, 10), collapse = ", ")))
  for (c in intersect(NUM_COLS, names(df))) df[[c]] <- suppressWarnings(as.numeric(df[[c]]))
  as_tibble(df)
}
# CMP_DEFINE_ONLY: parse-check only. By this line R has already parsed the whole file (a syntax error
# anywhere would have stopped it earlier), so quit before we touch any input file.
if (nzchar(Sys.getenv("CMP_DEFINE_ONLY"))) { message("CMP_DEFINE_ONLY: parsed OK"); quit(save = "no", status = 0L) }
old <- read_profile(old_path, "old")
new <- read_profile(new_path, "new")
old_sampled <- "sampled" %in% names(old) && any(toupper(as.character(old$sampled)) == "TRUE")
new_sampled <- "sampled" %in% names(new) && any(toupper(as.character(new$sampled)) == "TRUE")
samp_note <- if (old_sampled || new_sampled)
    sprintf("%s%s%s profiled from a sample — a flagged difference may be sampling variation; re-run the profiler with DC_SAMPLE_N=0 for exact metrics.",
      if (old_sampled) "OLD" else "", if (old_sampled && new_sampled) " and " else "", if (new_sampled) "NEW" else "") else ""

# ---- schema diff ----
o_tbls <- unique(old$table_base); n_tbls <- unique(new$table_base)
added_tbls   <- sort(setdiff(n_tbls, o_tbls))
dropped_tbls <- sort(setdiff(o_tbls, n_tbls))
shared_tbls  <- intersect(o_tbls, n_tbls)
o_keys <- paste(old$table_base, old$column, sep = "|")
n_keys <- paste(new$table_base, new$column, sep = "|")
added_cols   <- sort(n_keys[!(n_keys %in% o_keys)])
dropped_cols <- sort(o_keys[!(o_keys %in% n_keys)])

# ---- per-column deltas (columns present in both) ----
j <- inner_join(old, new, by = c("table_base","column"), suffix = c(".o",".n"))
j <- j %>% mutate(
  colname   = paste(table_base, column, sep = "."),
  d_miss    = pct_missing.n - pct_missing.o,
  ratio.o   = distinct.o / pmax(1, n_nonmissing.o),
  ratio.n   = distinct.n / pmax(1, n_nonmissing.n),
  d_distinct_rel    = ifelse(ratio.o > 0, abs(ratio.n - ratio.o) / ratio.o, NA_real_),  # magnitude -> flag
  d_distinct_signed = ifelse(ratio.o > 0, (ratio.n - ratio.o) / ratio.o, NA_real_),     # signed  -> display
  pooled_sd = sqrt((sd.o^2 + sd.n^2) / 2),
  smd       = ifelse(is.na(pooled_sd) | pooled_sd == 0, NA_real_, (mean.n - mean.o) / pooled_sd),
  # Catches shape/tail drift the mean-based SMD misses: the biggest standardized shift across
  # p5..p95 (a steady mean can still hide a fatter tail). Same pooled-SD denominator as SMD.
  q_shift_max = ifelse(is.na(pooled_sd) | pooled_sd == 0, NA_real_,   # suppress the all-NA pmax warning on categorical rows (result discarded by the ifelse)
                suppressWarnings(pmax(abs(p5.n - p5.o), abs(p10.n - p10.o), abs(p25.n - p25.o), abs(p50.n - p50.o),
                     abs(p75.n - p75.o), abs(p90.n - p90.o), abs(p95.n - p95.o), na.rm = TRUE)) / pooled_sd),
  kind_change     = kind.o != kind.n,
  date_min_change = kind.o == "date" & kind.n == "date" &
                    (coalesce(date_min.o, "") != coalesce(date_min.n, "")),
  d_unparse        = coalesce(unparseable.n, 0) - coalesce(unparseable.o, 0),
  unparse_up       = coalesce(unparseable.n, 0) > coalesce(unparseable.o, 0),   # more parse failures = QA regression
  date_max_regress = kind.o == "date" & kind.n == "date" & !is.na(date_max.o) & !is.na(date_max.n) &
                     (date_max.n < date_max.o),   # max moved backwards = truncated history (an advance is expected, not flagged)
  type_change      = type.o != type.n & kind.o == kind.n,   # same-kind storage change (e.g. integer -> double)
  const_shift      = kind.o == "numeric" & kind.n == "numeric" & is.na(smd) &
                     !is.na(mean.o) & !is.na(mean.n) & (mean.o != mean.n))  # zero-variance column whose value moved (SMD undefined)

# Categorical drift: parse "count:value|..." into per-value shares and compare the two snapshots.
parse_topv <- function(s, nn) {
  if (is.na(s) || !nzchar(s) || is.na(nn) || nn <= 0) return(setNames(numeric(0), character(0)))
  items <- str_split(s, "\\|")[[1]]
  cnts  <- suppressWarnings(as.numeric(sub(":.*$", "", items)))   # count = before the first ':'
  vals  <- sub("^[0-9]+:", "", items)                            # value = after the first ':'
  ok <- !is.na(cnts) & nzchar(vals)
  setNames(100 * cnts[ok] / nn, vals[ok])
}
cat_compare <- function(tv_o, nn_o, tv_n, nn_n) {
  so <- parse_topv(tv_o, nn_o); sn <- parse_topv(tv_n, nn_n)
  msgs <- character(0)
  for (v in union(names(so), names(sn))) {
    a <- if (v %in% names(so)) so[[v]] else NA_real_
    b <- if (v %in% names(sn)) sn[[v]] else NA_real_
    if (is.na(a)) { if (!is.na(b) && b >= cat_min) msgs <- c(msgs, sprintf("+%s (%.0f%%)", v, b)) }
    else if (is.na(b)) { if (a >= cat_min) msgs <- c(msgs, sprintf("-%s (%.0f%%)", v, a)) }
    else if (abs(b - a) >= cat_pts) msgs <- c(msgs, sprintf("%s %.0f%%->%.0f%%", v, a, b))
  }
  list(flag = length(msgs) > 0, desc = paste(msgs, collapse = "; "))
}
# Leading category and its share on each side, plus the largest absolute share change — so the report
# can say WHICH category leads (and whether the leader actually changed vs just its share).
cat_stats <- function(tv_o, nn_o, tv_n, nn_n) {
  so <- parse_topv(tv_o, nn_o); sn <- parse_topv(tv_n, nn_n)
  lead_o <- if (length(so)) names(so)[which.max(so)] else NA_character_
  lead_n <- if (length(sn)) names(sn)[which.max(sn)] else NA_character_
  maxd <- 0
  for (v in union(names(so), names(sn))) {
    a <- if (v %in% names(so)) so[[v]] else 0
    b <- if (v %in% names(sn)) sn[[v]] else 0
    maxd <- max(maxd, abs(b - a))
  }
  list(lead_o = lead_o, share_o = if (length(so)) max(so) else NA_real_,
       lead_n = lead_n, share_n = if (length(sn)) max(sn) else NA_real_, max_delta = maxd)
}
cat_flag <- rep(FALSE, nrow(j)); cat_desc <- rep("", nrow(j))
cat_lead_o <- rep(NA_character_, nrow(j)); cat_share_o <- rep(NA_real_, nrow(j))
cat_lead_n <- rep(NA_character_, nrow(j)); cat_share_n <- rep(NA_real_, nrow(j)); cat_max_delta <- rep(0, nrow(j))
is_cat <- j$kind.o == "categorical" & j$kind.n == "categorical"
for (i in which(is_cat)) {
  cc <- cat_compare(j$top_values.o[i], j$n_nonmissing.o[i], j$top_values.n[i], j$n_nonmissing.n[i])
  cat_flag[i] <- cc$flag; cat_desc[i] <- cc$desc
  cs <- cat_stats(j$top_values.o[i], j$n_nonmissing.o[i], j$top_values.n[i], j$n_nonmissing.n[i])
  cat_lead_o[i] <- cs$lead_o; cat_share_o[i] <- cs$share_o
  cat_lead_n[i] <- cs$lead_n; cat_share_n[i] <- cs$share_n; cat_max_delta[i] <- cs$max_delta
}
j$cat_flag <- cat_flag; j$cat_desc <- cat_desc
j$cat_lead_o <- cat_lead_o; j$cat_share_o <- cat_share_o
j$cat_lead_n <- cat_lead_n; j$cat_share_n <- cat_share_n; j$cat_max_delta <- cat_max_delta

j <- j %>% mutate(
  flag_miss     = !is.na(d_miss) & abs(d_miss) >= miss_pts,
  flag_smd      = !is.na(smd) & abs(smd) >= smd_thresh,
  flag_quantile = !is.na(q_shift_max) & q_shift_max >= smd_thresh,
  flag_distinct = !is.na(d_distinct_rel) & d_distinct_rel >= distinct_pct / 100,
  flag_kind     = kind_change,
  flag_type     = type_change,
  flag_const    = const_shift,
  flag_date     = date_min_change | unparse_up | date_max_regress,
  # A REVIEW signal is a change a stakeholder acts on: completeness, distribution, category mix, date
  # quality, or a source storage-type change. A profiler-interpretation change (KIND numeric<->categorical)
  # is how the profiler classified the field, not a source change. A cardinality change (distinct-per-
  # nonmissing) IS observed in the delivered values, but is kept out of the default stakeholder list. Both
  # are "structural" — reported in the technical detail, not counted as review changes.
  review_flag   = flag_miss | flag_smd | flag_quantile | flag_const | cat_flag | flag_type | flag_date,
  struct_flag   = flag_kind | flag_distinct,
  any_flag      = review_flag | struct_flag,
  # One primary change family per flagged column, so the composition counts are mutually exclusive and
  # reconcile to the total. Review families rank above the structural ones; profiler-interpretation and
  # cardinality are separate families (a kind flip and a distinct-count move are different things).
  family = dplyr::case_when(
    flag_miss                              ~ "Completeness",
    flag_smd | flag_quantile | flag_const  ~ "Numeric distribution",
    cat_flag                               ~ "Categorical distribution",
    flag_date                              ~ "Date quality",
    flag_type                              ~ "Storage type / technical",
    flag_kind                              ~ "Profiler interpretation",
    flag_distinct                          ~ "Cardinality movement",
    TRUE                                   ~ NA_character_),
  # review-ordering score (magnitude-based, NOT clinical priority) — orders the stakeholder list.
  review_score = abs(coalesce(smd, 0)) + coalesce(q_shift_max, 0) + abs(coalesce(d_miss, 0)) / 5 +
                 coalesce(cat_max_delta, 0) / 20 + ifelse(flag_type, 0.4, 0) + ifelse(flag_date, 0.3, 0))

review_items  <- j %>% filter(review_flag) %>% arrange(desc(review_score))
struct_items  <- j %>% filter(struct_flag & !review_flag) %>% arrange(desc(coalesce(d_distinct_rel, 0)))
flagged       <- j %>% filter(any_flag) %>% arrange(desc(review_flag), desc(review_score))
n_review <- nrow(review_items); n_struct_only <- nrow(struct_items); n_shared <- nrow(j)
FAM_LEVELS  <- c("Completeness","Numeric distribution","Categorical distribution",
                 "Date quality","Storage type / technical","Profiler interpretation","Cardinality movement")
REVIEW_FAMS <- FAM_LEVELS[1:5]      # data-value / quality / type changes shown to stakeholders
STRUCT_FAMS <- FAM_LEVELS[6:7]      # profiler interpretation + cardinality (technical only)
TYPE_FAM    <- "Storage type / technical"
fam_counts <- vapply(FAM_LEVELS, function(f) sum(j$family == f, na.rm = TRUE), integer(1))
n_type <- sum(review_items$family == TYPE_FAM); n_valq <- n_review - n_type   # split of the review changes

# Table-level row-count change: n_rows_total is constant within a table. Flagged tables first, then by
# absolute % change; keep the stable tables too, for context.
tbl_rows <- j %>% group_by(table_base) %>%
  summarise(rows_o = dplyr::first(n_rows_total.o), rows_n = dplyr::first(n_rows_total.n), .groups = "drop") %>%
  mutate(d_abs = rows_n - rows_o,
         d_rel = ifelse(rows_o > 0, 100 * (rows_n - rows_o) / rows_o, NA_real_),
         flag  = !is.na(d_rel) & abs(d_rel) >= rows_pct) %>%
  arrange(desc(flag), desc(abs(d_rel)))
n_tbl_flag <- sum(tbl_rows$flag, na.rm = TRUE)

# ---- formatting helpers ----
fmtn <- function(v) ifelse(is.na(v), "", ifelse(abs(v - round(v)) < 1e-9,
                    formatC(v, format = "f", digits = 0, big.mark = ","), formatC(v, format = "f", digits = 2, big.mark = ",")))
fmi  <- function(n) if (length(n) != 1 || is.na(n)) "n/a" else format(round(as.numeric(n)), big.mark = ",", scientific = FALSE)
fmi_signed <- function(n) if (length(n) != 1 || is.na(n)) "n/a" else paste0(if (n >= 0) "+" else "", fmi(n))  # "+1,380" / "-1,380"
esc  <- function(x) { x <- as.character(x); x <- gsub("&","&amp;",x,fixed=TRUE)
  x <- gsub("<","&lt;",x,fixed=TRUE); gsub(">","&gt;",x,fixed=TRUE) }
cut_of <- function(p) sub("^profile_(new_)?", "", sub("\\.tsv$", "", basename(p)))   # profile_2026m06.tsv -> 2026m06

# Plain-language change + exact old/new evidence + magnitude for a flagged column's PRIMARY family.
# Every figure is read straight from the profile metrics (nothing approximated). full=TRUE adds the
# extra evidence the technical report wants (SD on numerics, per-category deltas on categoricals).
change_evidence <- function(r, full = FALSE) {
  fam <- r$family
  if (identical(fam, "Completeness")) {
    list(change = if (r$d_miss > 0) "Completeness decreased" else "Completeness improved",
         old = sprintf("missing %s / %s rows (%.1f%%)", fmi(r$n_missing.o), fmi(r$n_rows.o), r$pct_missing.o),
         new = sprintf("missing %s / %s rows (%.1f%%)", fmi(r$n_missing.n), fmi(r$n_rows.n), r$pct_missing.n),
         mag = sprintf("%+.1f pts", r$d_miss))
  } else if (identical(fam, "Numeric distribution")) {
    if (isTRUE(r$flag_const))
      list(change = "Constant value changed", old = sprintf("value %s", fmtn(r$mean.o)),
           new = sprintf("value %s", fmtn(r$mean.n)), mag = sprintf("%s → %s", fmtn(r$mean.o), fmtn(r$mean.n)))
    else {
      sd_o <- if (full) sprintf(" · SD %s", fmtn(r$sd.o)) else ""
      sd_n <- if (full) sprintf(" · SD %s", fmtn(r$sd.n)) else ""
      list(change = "Numeric distribution shifted",
           old = sprintf("median %s · IQR %s–%s · mean %s%s", fmtn(r$p50.o), fmtn(r$p25.o), fmtn(r$p75.o), fmtn(r$mean.o), sd_o),
           new = sprintf("median %s · IQR %s–%s · mean %s%s", fmtn(r$p50.n), fmtn(r$p25.n), fmtn(r$p75.n), fmtn(r$mean.n), sd_n),
           mag = if (!is.na(r$smd)) sprintf("SMD %+.2f", r$smd) else sprintf("%.2f SD", r$q_shift_max))
    }
  } else if (identical(fam, "Categorical distribution")) {
    same_lead <- !is.na(r$cat_lead_o) && !is.na(r$cat_lead_n) && identical(r$cat_lead_o, r$cat_lead_n)
    deltas <- if (full && nzchar(r$cat_desc)) sprintf(" · shifts: %s", r$cat_desc) else ""
    list(change = if (isTRUE(same_lead)) "Leading-category share changed" else "Leading category changed",
         old = if (!is.na(r$cat_lead_o)) sprintf("leader %s %.1f%%", r$cat_lead_o, r$cat_share_o) else "n/a",
         new = if (!is.na(r$cat_lead_n)) sprintf("leader %s %.1f%%%s", r$cat_lead_n, r$cat_share_n, deltas) else "n/a",
         mag = if (isTRUE(same_lead)) sprintf("%s %+.1f pts", r$cat_lead_n, r$cat_share_n - r$cat_share_o)
               else sprintf("%s → %s", coalesce(r$cat_lead_o, "n/a"), coalesce(r$cat_lead_n, "n/a")))
  } else if (identical(fam, "Date quality")) {
    if (isTRUE(r$unparse_up))
      list(change = "Unreadable dates increased",
           old = sprintf("%s / %s nonblank (%.2f%%)", fmi(coalesce(r$unparseable.o, 0)), fmi(r$n_nonmissing.o), 100 * coalesce(r$unparseable.o, 0) / pmax(1, r$n_nonmissing.o)),
           new = sprintf("%s / %s nonblank (%.2f%%)", fmi(coalesce(r$unparseable.n, 0)), fmi(r$n_nonmissing.n), 100 * coalesce(r$unparseable.n, 0) / pmax(1, r$n_nonmissing.n)),
           mag = sprintf("%+d records", as.integer(r$d_unparse)))
    else
      list(change = "Date coverage changed",
           old = sprintf("%s – %s", coalesce(r$date_min.o, "n/a"), coalesce(r$date_max.o, "n/a")),
           new = sprintf("%s – %s", coalesce(r$date_min.n, "n/a"), coalesce(r$date_max.n, "n/a")),
           mag = if (isTRUE(r$date_max_regress)) "range truncated" else "range shifted")
  } else if (identical(fam, TYPE_FAM)) {
    list(change = "Storage type changed", old = as.character(r$type.o), new = as.character(r$type.n),
         mag = sprintf("%s → %s", r$type.o, r$type.n))
  } else if (identical(fam, "Profiler interpretation")) {
    list(change = "Profiler classification changed", old = sprintf("summarised as %s", r$kind.o),
         new = sprintf("summarised as %s", r$kind.n), mag = sprintf("%s → %s", r$kind.o, r$kind.n))
  } else {   # Cardinality movement
    list(change = "Distinct-value count moved", old = sprintf("%s distinct", fmi(r$distinct.o)),
         new = sprintf("%s distinct", fmi(r$distinct.n)), mag = sprintf("%+.0f%% per nonmissing", 100 * coalesce(r$d_distinct_signed, 0)))
  }
}
# A change is a deterioration (amber) only when its direction is unambiguous: more missing values, or
# more unreadable dates. Everything else — including a completeness IMPROVEMENT — stays neutral, so an
# improvement is never shown in the same alarm colour as a regression (both still need confirming).
chg_class <- function(r) if ((identical(r$family, "Completeness") && isTRUE(r$d_miss > 0)) || isTRUE(r$unparse_up)) " down" else ""
# Technical signal chips — every dimension that fired, exact magnitudes. KIND is labelled "PROFILER";
# a bare cardinality change is shown only when there is no kind change (else it restates the same event).
sig <- function(txt, warn = FALSE) sprintf('<span class="sig%s">%s</span>', if (warn) " sig-warn" else "", esc(txt))
sig_chips <- function(r) {
  s <- character(0)
  if (isTRUE(r$flag_miss))     s <- c(s, sig(sprintf("MISSING %+.1fpt", r$d_miss), warn = r$d_miss > 0))
  if (isTRUE(r$flag_smd))      s <- c(s, sig(sprintf("SMD %+.2f", r$smd)))
  if (isTRUE(r$flag_quantile)) s <- c(s, sig(sprintf("QUANTILE %.2f SD", r$q_shift_max)))
  if (isTRUE(r$flag_const))    s <- c(s, sig(sprintf("CONSTANT %s → %s", fmtn(r$mean.o), fmtn(r$mean.n))))
  if (isTRUE(r$cat_flag))      s <- c(s, sig("CATEGORY MIX"))
  if (isTRUE(r$flag_type))     s <- c(s, sig(sprintf("TYPE %s → %s", r$type.o, r$type.n)))
  if (isTRUE(r$unparse_up))    s <- c(s, sig(sprintf("UNPARSEABLE %+d", as.integer(r$d_unparse)), warn = TRUE))
  if (isTRUE(r$flag_date) && !isTRUE(r$unparse_up)) s <- c(s, sig("DATE RANGE"))
  if (isTRUE(r$flag_kind))     s <- c(s, sig(sprintf("PROFILER %s → %s", r$kind.o, r$kind.n)))
  if (isTRUE(r$flag_distinct) && !isTRUE(r$flag_kind)) s <- c(s, sig(sprintf("CARDINALITY %+.0f%%", 100 * r$d_distinct_signed)))
  paste(s, collapse = "")
}
# note_for: the full one-line technical detail for the markdown record (every signal spelled out).
note_for <- function(r) {
  m <- character(0)
  if (isTRUE(r$flag_miss))  m <- c(m, sprintf("missing %.1f%%->%.1f%% (%+.1fpt; %s/%s -> %s/%s)", r$pct_missing.o, r$pct_missing.n, r$d_miss,
    fmi(r$n_missing.o), fmi(r$n_rows.o), fmi(r$n_missing.n), fmi(r$n_rows.n)))
  if (isTRUE(r$flag_smd))   m <- c(m, sprintf("SMD %+.2f (mean %s->%s)", r$smd, fmtn(r$mean.o), fmtn(r$mean.n)))
  if (isTRUE(r$flag_quantile) || isTRUE(r$flag_smd))
    m <- c(m, sprintf("quantiles p25/p50/p75: %s->%s / %s->%s / %s->%s (max shift %.2f SD)",
      fmtn(r$p25.o), fmtn(r$p25.n), fmtn(r$p50.o), fmtn(r$p50.n), fmtn(r$p75.o), fmtn(r$p75.n), r$q_shift_max))
  if (isTRUE(r$flag_const)) m <- c(m, sprintf("constant value %s->%s", fmtn(r$mean.o), fmtn(r$mean.n)))
  if (nzchar(r$cat_desc)) m <- c(m, sprintf("categories: %s", r$cat_desc))
  if (isTRUE(r$flag_type))  m <- c(m, sprintf("storage type %s->%s", r$type.o, r$type.n))
  if (isTRUE(r$flag_date)) m <- c(m, sprintf("date range %s..%s -> %s..%s%s",
    coalesce(r$date_min.o, "n/a"), coalesce(r$date_max.o, "n/a"), coalesce(r$date_min.n, "n/a"), coalesce(r$date_max.n, "n/a"),
    if (isTRUE(r$unparse_up)) sprintf("; unparseable %s->%s", fmi(coalesce(r$unparseable.o, 0)), fmi(coalesce(r$unparseable.n, 0))) else ""))
  if (isTRUE(r$flag_kind)) m <- c(m, sprintf("profiler kind %s->%s (not a source change)", r$kind.o, r$kind.n))
  if (isTRUE(r$flag_distinct)) m <- c(m, sprintf("cardinality %+.0f%%", 100 * r$d_distinct_signed))
  paste(m, collapse = " | ")
}

gen_time <- format(Sys.time(), "%Y-%m-%d %H:%M")
cut_o <- cut_of(old_path); cut_n <- cut_of(new_path)
thr_txt <- sprintf("Thresholds (%s): completeness ≥%gpt · SMD ≥%g (and max per-quantile shift) · cardinality ≥%g%% · category share ≥%gpt (≥%g%% share) · row count ≥%g%%.",
                   thr_label, miss_pts, smd_thresh, distinct_pct, cat_pts, cat_min, rows_pct)

# ---- shared stylesheet (GSK palette — swap the hex values in the :root block) ----
report_css <- '<style>
:root{
  --accent:#C4441C; --accent-bar:#F36633; --accent-soft:#FDE7DD; --accent-ink:#7A2A10;
  --amber:#CA8A04; --amber-soft:#EAB308; --amber-bg:#FEF3C7; --amber-ink:#8A6D09; --fail:#C8102E;
  --ink:#2A1A47; --ink-2:#3F3A4A; --muted:#6B6A78; --faint:#A3A1AD;
  --line:#E7E3EF; --line-2:#D6D1E0; --surface:#FFFFFF; --page:#F2F0F7; --panel:#F8F6FB; --panel-edge:#ECE8F3;
  --track:#ECEAF2;
  --mono:ui-monospace,"Cascadia Code","Source Code Pro",Menlo,Consolas,monospace;
  --sans:system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
}
*{box-sizing:border-box}
body{font:15px/1.55 var(--sans);color:var(--ink-2);background:var(--page);margin:0;padding:28px}
.sheet{max-width:1180px;margin:0 auto;background:var(--surface);border:1px solid var(--line);border-radius:12px;box-shadow:0 1px 3px rgba(15,23,42,.06);padding:34px 38px 30px}
.eyebrow{font-size:11px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--accent);margin:0 0 4px}
h1{font-size:26px;line-height:1.15;font-weight:700;color:var(--ink);margin:0 0 10px;letter-spacing:-.01em}
.meta{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:2px 26px;font-size:13px;color:var(--muted);margin:0 0 6px;max-width:820px}
.meta .r{display:flex;gap:8px}.meta .k{color:var(--faint);min-width:104px}.meta b{color:var(--ink-2);font-weight:600}
.conf{display:inline-block;font-size:10.5px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--amber-ink);background:var(--amber-bg);border:1px solid #FCD34D;border-radius:5px;padding:2px 8px;margin-top:6px}
.cue{font-size:12.5px;color:var(--muted);margin:12px 0 0;font-style:italic}
.says{font-size:14px;color:var(--ink-2);margin:14px 0 2px;line-height:1.5}
.says b{color:var(--ink);font-weight:700}
h2{font-size:12px;font-weight:700;letter-spacing:.09em;text-transform:uppercase;color:var(--muted);margin:28px 0 12px;padding-bottom:7px;border-bottom:1px solid var(--line)}
h2 .n{color:var(--accent);margin-left:6px;text-transform:none;letter-spacing:0;font-weight:600}
.note-line{font-size:12.5px;color:var(--muted);margin:2px 0 6px}
.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:2px 0 4px}
.card{background:var(--panel);border:1px solid var(--panel-edge);border-left:3px solid var(--accent);border-radius:10px;padding:14px 16px}
.card.warn{border-left-color:var(--amber)}.card.mute{border-left-color:var(--faint)}
.card .val{font-size:26px;font-weight:700;color:var(--ink);line-height:1.05;letter-spacing:-.02em}
.card.warn .val{color:var(--amber-ink)}.card.mute .val{color:var(--muted)}
.card .lab{font-size:12.5px;font-weight:600;color:var(--ink-2);margin-top:3px}
.card .sub{font-size:11.5px;color:var(--muted);margin-top:2px}
.table-wrap{width:100%;overflow-x:auto}
table{border-collapse:collapse;width:100%;margin:2px 0 6px;font-size:13.5px}
thead th{background:var(--panel);text-align:left;font-weight:600;color:var(--ink-2);font-size:12px;padding:9px 11px;border-bottom:2px solid var(--line-2);white-space:nowrap}
th.num,td.num{text-align:right;font-variant-numeric:tabular-nums}
tbody td{padding:9px 11px;border-bottom:1px solid var(--line);vertical-align:top}
tbody tr:nth-child(even){background:#FBFAFC}
tbody tr:hover{background:#FAF5F1}
.colname{font-family:var(--mono);font-size:12.5px;font-weight:600;color:var(--ink);overflow-wrap:anywhere}
.tblname{font-family:var(--mono);font-size:11.5px;color:var(--muted);overflow-wrap:anywhere}
.col{font-family:var(--mono);font-size:12.5px;color:var(--ink);font-weight:600;overflow-wrap:anywhere;min-width:150px}
.tbl{font-family:var(--mono);font-size:12.5px;color:var(--muted);overflow-wrap:anywhere}
.chg{font-weight:600;color:var(--ink)}
.chg.down{color:var(--amber-ink)}
.fam{display:block;font-size:11px;color:var(--muted);font-weight:400;margin-top:1px}
.ev{font-variant-numeric:tabular-nums;font-size:12.5px;color:var(--ink-2)}
.mag{font-variant-numeric:tabular-nums;font-weight:600;color:var(--ink);white-space:nowrap}
.chip{display:inline-block;font-size:11px;font-weight:600;padding:2px 8px;border-radius:20px;white-space:nowrap}
.chip.rev{background:var(--amber-bg);color:var(--amber-ink);border:1px solid #FCD34D}
.sig{display:inline-block;font-family:var(--mono);font-size:10.5px;font-weight:600;padding:2px 7px;border-radius:5px;background:#EEF0F5;color:#3F3A4A;border:1px solid #E3E1EA;margin:1px 3px 1px 0;white-space:nowrap}
.sig.sig-warn{background:var(--amber-bg);color:var(--amber-ink);border-color:#FCD34D}
.sigcell{min-width:210px}
.na{color:var(--faint);font-size:13px}
.comp{margin:2px 0 6px;max-width:640px}
.comprow{display:grid;grid-template-columns:220px 1fr 42px;align-items:center;gap:10px;font-size:12.5px;padding:3px 0}
.comprow .cl{color:var(--ink-2)}
.comprow .tk{height:10px;background:var(--track);border-radius:3px;overflow:hidden}
.comprow .fl{display:block;height:100%;background:var(--accent-bar);border-radius:3px}
.comprow.struct .fl{background:var(--faint)}
.comprow .ct{text-align:right;font-variant-numeric:tabular-nums;color:var(--muted)}
.adds{margin:2px 0 6px}
.adds .row{display:flex;gap:10px;align-items:baseline;padding:6px 2px;border-bottom:1px solid var(--line)}
.adds .row:last-child{border-bottom:0}
.adds .gt{font-family:var(--mono);font-size:13px;font-weight:600;color:var(--ink);min-width:230px;overflow-wrap:anywhere}
.adds .tag{font-family:var(--sans);font-size:10.5px;font-weight:700;color:#fff;border-radius:10px;padding:1px 7px}
.adds .newtab{background:var(--accent)}.adds .droptab{background:var(--muted)}
.adds .d{font-size:13px;color:var(--ink-2)}
.grp{padding:8px 0;break-inside:avoid}
.grp .gt{font-family:var(--mono);font-size:13px;font-weight:600;color:var(--ink)}
.grp .gt .newtab,.grp .gt .droptab{font-family:var(--sans);font-size:10.5px;font-weight:700;color:#fff;border-radius:10px;padding:1px 7px;margin-left:6px;vertical-align:1px}
.grp .gt .newtab{background:var(--accent)}.grp .gt .droptab{background:var(--muted)}
.grp ul{margin:5px 0 0;padding:0 0 0 4px;list-style:none}
.grp li{font-family:var(--mono);font-size:12.5px;color:var(--ink-2);padding:1px 0}
.grp li .plus{color:var(--accent);font-weight:700;margin-right:6px}.grp li .minus{color:var(--muted);font-weight:700;margin-right:6px}
.subh{font-size:12.5px;font-weight:700;color:var(--ink-2);margin:10px 0 2px}
.link{font-size:12.5px;color:var(--accent-ink);margin:8px 0 0}
.panel{background:var(--panel);border:1px solid var(--panel-edge);border-radius:10px;padding:14px 18px;font-size:13px;color:var(--muted)}
.panel p{margin:0 0 7px}.panel p:last-child{margin:0}
.caveat{color:var(--amber-ink);font-size:12.5px}
.foot{display:flex;flex-wrap:wrap;justify-content:space-between;gap:8px;margin-top:26px;padding-top:14px;border-top:1px solid var(--line);font-size:11.5px;color:var(--faint)}
.foot b{color:var(--muted);font-weight:600}
.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
.printfoot{display:none}
@media (max-width:820px){.cards{grid-template-columns:repeat(2,1fr)}.meta{grid-template-columns:1fr}.comprow{grid-template-columns:150px 1fr 42px}}
@media print{
  @page{size:A4 landscape;margin:12mm 12mm 16mm}
  *{-webkit-print-color-adjust:exact;print-color-adjust:exact}
  body{background:#fff;padding:0;font-size:10pt}
  .sheet{border:0;box-shadow:none;border-radius:0;max-width:none;padding:0}
  thead{display:table-header-group}
  tr,.card,.panel,.adds .row,.grp,.comprow{break-inside:avoid}
  h2{break-after:avoid}
  .ev{white-space:normal}
  .detail-section{break-before:page}
  .printfoot{display:block;position:fixed;bottom:0;left:0;right:0;font-size:8pt;color:var(--muted);border-top:1px solid var(--line);padding-top:3px;background:#fff}
}
</style>'

# ---- shared building blocks ----
meta_html <- function() {
  rows <- c(
    if (nzchar(product)) sprintf('<div class="r"><span class="k">Product</span><b>%s</b></div>', esc(product)) else "",
    sprintf('<div class="r"><span class="k">Comparison</span><b>%s → %s</b></div>', esc(cut_o), esc(cut_n)),
    sprintf('<div class="r"><span class="k">Coverage</span><b>%s old · %s new</b></div>', if (old_sampled) "sampled" else "exact", if (new_sampled) "sampled" else "exact"),
    sprintf('<div class="r"><span class="k">Scope</span><b>%d shared tables · %d shared variables</b></div>', length(shared_tbls), n_shared),
    sprintf('<div class="r"><span class="k">Schema</span><b>%d tables added · %d removed</b></div>', length(added_tbls), length(dropped_tbls)),
    if (nzchar(run_id)) sprintf('<div class="r"><span class="k">Run</span><b>%s · thresholds %s</b></div>', esc(run_id), esc(thr_label))
      else sprintf('<div class="r"><span class="k">Thresholds</span><b>%s</b></div>', esc(thr_label)))
  paste0('<div class="meta">', paste(rows[nzchar(rows)], collapse = ""), '</div>')
}
cards_html <- function(cards) paste0('<div class="cards">', paste(vapply(cards, function(c)
  sprintf('<div class="card%s"><div class="val">%s</div><div class="lab">%s</div><div class="sub">%s</div></div>',
    paste0(if (isTRUE(c$warn)) " warn" else "", if (isTRUE(c$mute)) " mute" else ""),
    esc(c$val), esc(c$lab), esc(c$sub)), character(1)), collapse = ""), '</div>')
# Per-table schema summary lines (added / removed counts, new / dropped tables badged).
schema_summary_html <- function() {
  if (!length(added_cols) && !length(dropped_cols)) return('<p class="na">No schema additions or removals.</p>')
  rows <- character(0)
  a_tb <- sub("\\|.*$", "", added_cols); d_tb <- sub("\\|.*$", "", dropped_cols)
  for (t in c(intersect(added_tbls, a_tb), sort(setdiff(unique(a_tb), added_tbls)))) {
    n <- sum(a_tb == t); tag <- if (t %in% added_tbls) ' <span class="tag newtab">new table</span>' else ""
    rows <- c(rows, sprintf('<div class="row"><span class="gt">%s%s</span><span class="d">%d column%s added</span></div>',
      esc(t), tag, n, if (n == 1) "" else "s")) }
  for (t in c(intersect(dropped_tbls, d_tb), sort(setdiff(unique(d_tb), dropped_tbls)))) {
    n <- sum(d_tb == t); tag <- if (t %in% dropped_tbls) ' <span class="tag droptab">table removed</span>' else ""
    rows <- c(rows, sprintf('<div class="row"><span class="gt">%s%s</span><span class="d">%d column%s removed</span></div>',
      esc(t), tag, n, if (n == 1) "" else "s")) }
  paste0('<div class="adds">', paste(rows, collapse = ""), '</div>')
}
# Full grouped schema list (technical view).
group_cols_html <- function(cols, special, sign_cls, sign_ch, tag) {
  if (!length(cols)) return('<p class="na">None.</p>')
  tb <- sub("\\|.*$", "", cols); cl <- sub("^[^|]*\\|", "", cols)
  tabs <- unique(tb); tabs <- c(intersect(special, tabs), setdiff(tabs, special))
  grp <- vapply(tabs, function(t) {
    lis <- paste(sprintf('<li><span class="%s">%s</span>%s</li>', sign_cls, sign_ch, esc(cl[tb == t])), collapse = "")
    bd  <- if (t %in% special) sprintf(' <span class="%s">%s</span>', if (identical(sign_cls, "plus")) "newtab" else "droptab", tag) else ""
    sprintf('<div class="grp"><div class="gt">%s%s</div><ul>%s</ul></div>', esc(t), bd, lis) }, character(1))
  paste(grp, collapse = "")
}
# A short new-snapshot distribution summary for an added column (built from the metrics the profiler wrote).
dist_summary <- function(nr) {
  if (identical(nr$kind, "numeric") && !is.na(nr$p50))
    sprintf("median %s · IQR %s–%s · mean %s", fmtn(nr$p50), fmtn(nr$p25), fmtn(nr$p75), fmtn(nr$mean))
  else if (identical(nr$kind, "date") && !is.na(nr$date_min))
    sprintf("%s – %s", nr$date_min, coalesce(nr$date_max, "n/a"))
  else if (identical(nr$kind, "categorical")) {
    tv <- parse_topv(nr$top_values, nr$n_nonmissing)
    if (length(tv)) paste(sprintf("%s %.0f%%", utils::head(names(tv), 3), utils::head(unname(tv), 3)), collapse = "; ") else "—"
  } else "—"
}
# Added columns are new — there is no OLD value to compare, so show each one's new-snapshot profile
# (kind, rows, missingness, distinct, distribution) instead of only its name. Data comes from `new`.
added_detail_html <- function() {
  if (!length(added_cols)) return('<p class="na">No columns added.</p>')
  new_keys <- paste(new$table_base, new$column, sep = "|")
  idx <- match(added_cols, new_keys)
  rows <- vapply(seq_along(added_cols), function(k) { i <- idx[k]
    if (is.na(i)) return(sprintf('<tr><td class="col">%s</td><td colspan="5" class="na">not found in new profile</td></tr>', esc(added_cols[k])))
    nr <- new[i, ]; pm <- if (is.na(nr$pct_missing)) "n/a" else sprintf("%.1f%%", nr$pct_missing)
    sprintf('<tr><td class="col">%s.%s</td><td>%s</td><td class="num">%s</td><td class="num">%s</td><td class="num">%s</td><td class="ev">%s</td></tr>',
      esc(nr$table_base), esc(nr$column), esc(nr$kind), fmi(nr$n_rows), pm, fmi(nr$distinct), esc(dist_summary(nr))) }, character(1))
  paste0('<div class="table-wrap"><table><caption class="sr-only">Added columns with new-snapshot profile</caption>',
    '<thead><tr><th scope="col">Variable</th><th scope="col">Kind</th><th scope="col" class="num">Rows</th><th scope="col" class="num">% missing</th><th scope="col" class="num">Distinct</th><th scope="col">Distribution (new snapshot)</th></tr></thead><tbody>',
    paste(rows, collapse = ""), '</tbody></table></div>')
}
rowcount_html <- function() {
  if (!nrow(tbl_rows)) return('<p class="na">No shared tables.</p>')
  rc <- paste(vapply(seq_len(nrow(tbl_rows)), function(i) { t <- tbl_rows[i, ]
    sprintf('<tr><td class="tbl">%s</td><td class="num">%s</td><td class="num">%s</td><td class="num">%s</td><td class="num">%s</td><td>%s</td></tr>',
      esc(t$table_base), fmi(t$rows_o), fmi(t$rows_n), fmi_signed(t$d_abs),
      if (is.na(t$d_rel)) "n/a" else sprintf("%+.1f%%", t$d_rel),
      if (isTRUE(t$flag)) '<span class="chip rev">review</span>' else "") }, character(1)), collapse = "")
  paste0('<div class="table-wrap"><table><caption class="sr-only">Table row counts, flagged first</caption>',
    '<thead><tr><th scope="col">Table</th><th scope="col" class="num">Old rows</th><th scope="col" class="num">New rows</th><th scope="col" class="num">Δ rows</th><th scope="col" class="num">Δ%</th><th scope="col">Review</th></tr></thead><tbody>',
    rc, '</tbody></table></div>',
    '<p class="note-line">Row counts reflect each table’s native grain (patient-, episode-, line-, specimen- or result-level) and are not necessarily patient counts. Flagged when |Δ| ≥ ', sprintf("%g", rows_pct), '%.</p>')
}
# Factual one-liner about the REVIEW changes (the structural 231 are summarised separately, once, below).
factual_statement <- function() {
  if (n_review == 0) return("No shared variable crossed a review threshold in this comparison.")
  br <- if (n_type > 0) sprintf(" — %d data-quality / value change%s and %d storage-type change%s",
    n_valq, if (n_valq == 1) "" else "s", n_type, if (n_type == 1) "" else "s") else ""
  sprintf("<b>%d change%s</b> %s listed for review%s.", n_review, if (n_review == 1) "" else "s",
          if (n_review == 1) "is" else "are", br)
}
# Executive-summary block (four cards + the factual line + a structural note) — shared so both reports
# lead with the same numbers. `heading` is optional: the stakeholder report is already titled a
# "summary", so it passes "" (cards lead directly); the technical report keeps the "Executive summary" h2.
exec_summary_html <- function(struct_note, heading = "Executive summary") {
  cov_val <- if (old_sampled || new_sampled) "Sampled" else "Exact"
  cards <- cards_html(list(
    list(val = sprintf("+%d · −%d", length(added_cols), length(dropped_cols)), lab = "Column changes", sub = "added · removed", mute = TRUE),
    list(val = n_review, lab = "Review changes", sub = if (n_type > 0) sprintf("%d value/quality · %d type", n_valq, n_type) else "columns to review", warn = n_review > 0),
    list(val = n_tbl_flag, lab = "Row-count review", sub = sprintf("shared tables above ±%g%%", rows_pct)),
    list(val = cov_val, lab = "Coverage", sub = sprintf("%d shared tables · %d variables", length(shared_tbls), n_shared), mute = TRUE)))
  paste0(if (nzchar(heading)) sprintf('<h2>%s</h2>', heading) else "", cards,
         sprintf('<p class="says">%s</p>', factual_statement()), struct_note)
}

# ============================ STAKEHOLDER SUMMARY ============================
render_stakeholder <- function() {
  ident <- sprintf("%s%s → %s · generated %s", if (nzchar(product)) paste0(esc(product), " · ") else "", esc(cut_o), esc(cut_n), esc(gen_time))
  # Storage-type changes go in their own "confirm" block; the main table is completeness/distribution/date.
  main_items <- review_items %>% filter(family != TYPE_FAM)
  type_items <- review_items %>% filter(family == TYPE_FAM)
  n_main <- nrow(main_items); n_show <- min(TOP_N_STAKE, n_main)
  hdr <- if (n_main > n_show) sprintf('<h2>Changes requiring review <span class="n">· top %d of %d</span></h2>', n_show, n_main)
         else sprintf('<h2>Changes requiring review <span class="n">· %d</span></h2>', n_main)
  main_tbl <- if (n_main > 0) {
    rows <- paste(vapply(seq_len(n_show), function(i) { r <- main_items[i, ]; e <- change_evidence(r)
      sprintf('<tr><td><div class="colname">%s</div><div class="tblname">%s</div></td><td class="chg%s">%s<span class="fam">%s</span></td><td class="ev">%s</td><td class="ev">%s</td><td class="num mag">%s</td></tr>',
        esc(r$column), esc(r$table_base), chg_class(r), esc(e$change), esc(r$family), esc(e$old), esc(e$new), esc(e$mag)) }, character(1)), collapse = "")
    paste0(hdr, '<p class="note-line">Ordered for review by a composite magnitude score. The Magnitude column mixes units (percentage points, SMD, record counts, category shifts) and is comparable only within a change family, not across families — it is not a clinical-priority ranking.</p>',
      sprintf('<div class="table-wrap"><table><caption class="sr-only">Changes requiring review between %s and %s</caption>', esc(cut_o), esc(cut_n)),
      '<thead><tr><th scope="col">Variable</th><th scope="col">Change</th><th scope="col">Old snapshot (', esc(cut_o), ')</th><th scope="col">New snapshot (', esc(cut_n), ')</th><th scope="col" class="num">Magnitude</th></tr></thead><tbody>',
      rows, '</tbody></table></div>',
      if (n_main > n_show) sprintf('<p class="link">The remaining %d changes and all technical signals are in the <a href="snapshot_comparison.html">technical detail report</a>.</p>', n_main - n_show) else "")
  } else '<h2>Changes requiring review</h2><p class="na">No column crossed a completeness/distribution/date review threshold.</p>'

  type_block <- if (nrow(type_items) > 0) {
    rows <- paste(vapply(seq_len(nrow(type_items)), function(i) { r <- type_items[i, ]; e <- change_evidence(r)
      sprintf('<tr><td><div class="colname">%s</div><div class="tblname">%s</div></td><td class="ev">%s → %s</td></tr>', esc(r$column), esc(r$table_base), esc(e$old), esc(e$new)) }, character(1)), collapse = "")
    paste0('<h2>Technical change to confirm <span class="n">· storage type</span></h2>',
      '<p class="note-line">Source storage type changed — usually not a data-value change; confirm against the feed release notes.</p>',
      '<div class="table-wrap"><table><caption class="sr-only">Storage-type changes to confirm</caption><thead><tr><th scope="col">Variable</th><th scope="col">Storage type (old → new)</th></tr></thead><tbody>',
      rows, '</tbody></table></div>')
  } else ""

  struct_line <- if (n_struct_only > 0) sprintf('<p class="note-line">%d additional profiler-interpretation and cardinality signals are kept in the technical report and are not stakeholder actions.</p>', n_struct_only) else ""

  schema_sec <- paste0('<h2>Schema changes <span class="n">· summary; full diff in the technical report</span></h2>', schema_summary_html(),
    if (length(added_cols)) '<p class="link">See the New-variable review for distributions and missingness of the added columns.</p>' else "")

  paste0('<!doctype html><html lang="en"><head><meta charset="utf-8">',
    '<meta name="viewport" content="width=device-width, initial-scale=1">',
    sprintf('<title>Data refresh change summary — %s → %s</title>', esc(cut_o), esc(cut_n)), report_css,
    '</head><body><div class="sheet">',
    '<p class="eyebrow">Data refresh change summary</p>',
    sprintf('<h1>%s%s → %s</h1>', if (nzchar(product)) paste0(esc(product), " — ") else "", esc(cut_o), esc(cut_n)),
    meta_html(),
    sprintf('<span class="conf">Restricted RWD output · %s → %s</span>', esc(cut_o), esc(cut_n)),
    '<p class="cue">Review signals are magnitude-based cues for a human to check — not QC pass/fail results.</p>',
    if (nzchar(samp_note)) sprintf('<p class="caveat">%s</p>', esc(samp_note)) else "",
    exec_summary_html(struct_line, heading = ""),
    main_tbl, type_block,
    schema_sec,
    '<h2>Table row counts <span class="n">· flagged first</span></h2>', rowcount_html(),
    '<p class="note-line">Full per-signal detail, the change-family composition, thresholds and the complete schema diff are in the <a href="snapshot_comparison.html">technical detail report</a>.</p>',
    sprintf('<div class="foot"><span><b>%s%s → %s</b></span><span>Restricted RWD output%s · generated %s</span></div>',
      if (nzchar(product)) paste0(esc(product), " · ") else "", esc(cut_o), esc(cut_n),
      if (nzchar(run_id)) paste0(" · ", esc(run_id)) else "", esc(gen_time)),
    '</div>', sprintf('<div class="printfoot">Restricted RWD output · %s</div>', ident), '</body></html>')
}

# ============================ TECHNICAL DETAIL ============================
render_technical <- function() {
  ident <- sprintf("%s → %s · generated %s", esc(cut_o), esc(cut_n), esc(gen_time))
  # Two-level composition: review families normalised against the review total, structural signals shown
  # separately so the 200+ structural bars don't dwarf the review families into invisibility.
  bar <- function(f, denom, cls) { ct <- fam_counts[[f]]; w <- if (denom > 0) 100 * ct / denom else 0
    sprintf('<div class="comprow%s"><span class="cl">%s</span><span class="tk"><span class="fl" style="width:%.1f%%"></span></span><span class="ct">%s</span></div>', cls, esc(f), w, fmi(ct)) }
  comp_rev <- paste(vapply(REVIEW_FAMS, function(f) bar(f, n_review, ""), character(1)), collapse = "")
  comp_str <- paste(vapply(STRUCT_FAMS, function(f) bar(f, max(1, n_struct_only), " struct"), character(1)), collapse = "")
  comp_sec <- paste0(
    sprintf('<h2>Review-change composition <span class="n">· %d of %d shared variables</span></h2>', n_review, n_shared),
    if (n_review > 0) paste0('<div class="comp">', comp_rev, '</div>') else '<p class="na">No review changes.</p>',
    sprintf('<h2>Additional technical signals <span class="n">· %d · not review changes</span></h2>', n_struct_only),
    if (n_struct_only > 0) paste0('<div class="comp">', comp_str, '</div>') else '<p class="na">None.</p>',
    '<p class="note-line">Each flagged variable is counted once under its primary family, so the counts reconcile. Profiler interpretation = how the field was classified (numeric↔categorical); cardinality movement = distinct-per-nonmissing changed (observed in the delivered values). Both are kept out of the stakeholder review list. Because kind is inferred per field, a difference in the profiler’s numeric/categorical inference settings or overrides between the two runs can reclassify many fields at once — confirm those settings match across both profile runs before reading a large profiler-interpretation count as data drift.</p>')

  # full review table (all of them), with richer evidence (SD, category deltas) + technical signals
  rev_sec <- if (n_review > 0) {
    rows <- paste(vapply(seq_len(n_review), function(i) { r <- review_items[i, ]; e <- change_evidence(r, full = TRUE)
      sprintf('<tr><td class="col">%s</td><td class="chg%s">%s<span class="fam">%s</span></td><td class="ev">%s</td><td class="ev">%s</td><td class="num mag">%s</td><td class="sigcell">%s</td></tr>',
        esc(r$colname), chg_class(r), esc(e$change), esc(r$family), esc(e$old), esc(e$new), esc(e$mag), sig_chips(r)) }, character(1)), collapse = "")
    paste0(sprintf('<h2>Review changes <span class="n">· %d</span></h2>', n_review),
      '<div class="table-wrap"><table><caption class="sr-only">All review changes with old/new metrics</caption>',
      '<thead><tr><th scope="col">Variable</th><th scope="col">Change</th><th scope="col">Old</th><th scope="col">New</th><th scope="col" class="num">Magnitude</th><th scope="col">Technical signals</th></tr></thead><tbody>',
      rows, '</tbody></table></div>')
  } else '<h2>Review changes</h2><p class="na">None crossed a review threshold.</p>'

  # structural signals (profiler interpretation + cardinality) — full list, with an explicit disposition
  str_sec <- if (n_struct_only > 0) {
    rows <- paste(vapply(seq_len(n_struct_only), function(i) { r <- struct_items[i, ]
      sprintf('<tr><td class="col">%s</td><td>%s</td><td class="sigcell">%s</td></tr>', esc(r$colname), esc(r$family), sig_chips(r)) }, character(1)), collapse = "")
    paste0(sprintf('<h2>Structural signals <span class="n">· %d · not review changes</span></h2>', n_struct_only),
      '<p class="note-line">Profiler interpretation = how the profiler classified the field (numeric↔categorical), not a source change. Cardinality movement = distinct-per-nonmissing changed, observed in the delivered values. Both are technical and kept out of the stakeholder review list.</p>',
      '<div class="table-wrap"><table><caption class="sr-only">Structural signals: profiler interpretation and cardinality</caption><thead><tr><th scope="col">Variable</th><th scope="col">Disposition</th><th scope="col">Signals</th></tr></thead><tbody>', rows, '</tbody></table></div>')
  } else ""

  schema_sec <- paste0('<h2>Schema additions &amp; removals <span class="n">· by table</span></h2>',
    sprintf('<p class="subh">Added <span class="n">· %d columns%s</span></p>', length(added_cols),
            if (length(added_tbls)) sprintf(", %d new tables", length(added_tbls)) else ""),
    if (length(added_cols)) '<p class="note-line">New columns — no prior snapshot to compare, so the new-snapshot profile is shown. Full distributions and missingness are in the New-variable review.</p>' else "",
    added_detail_html(),
    sprintf('<p class="subh">Removed <span class="n">· %d columns%s</span></p>', length(dropped_cols),
            if (length(dropped_tbls)) sprintf(", %d dropped tables", length(dropped_tbls)) else ""),
    group_cols_html(dropped_cols, dropped_tbls, "minus", "−", "dropped table"))

  method_sec <- paste0('<h2>Thresholds &amp; methodology</h2><div class="panel">',
    sprintf('<p><b>Provenance.</b> Old profile <span class="tbl">%s</span> · new profile <span class="tbl">%s</span> · comparison generated %s · threshold set <b>%s</b>.</p>',
            esc(basename(old_path)), esc(basename(new_path)), esc(gen_time), esc(thr_label)),
    sprintf('<p>%s</p>', esc(thr_txt)),
    '<p>Completeness drift is a rate (comparable across differing row counts), with n_missing / n_rows shown so a change can be traced to the numerator or the denominator. Numeric drift is SMD = (mean_new − mean_old) / pooled SD, plus a max per-quantile shift (p5..p95) for tail/shape the mean misses. Category drift compares top-value shares. Cardinality is distinct-per-nonmissing. A KIND change (numeric↔categorical) is a profiler-summarisation change, not a source-data change, and is not a review signal.</p>',
    if (nzchar(samp_note)) sprintf('<p class="caveat">%s</p>', esc(samp_note)) else "", '</div>')

  paste0('<!doctype html><html lang="en"><head><meta charset="utf-8">',
    '<meta name="viewport" content="width=device-width, initial-scale=1">',
    sprintf('<title>Snapshot comparison (detail) — %s → %s</title>', esc(cut_o), esc(cut_n)), report_css,
    '</head><body><div class="sheet">',
    '<p class="eyebrow">Snapshot comparison · technical detail</p>',
    sprintf('<h1>%s%s → %s</h1>', if (nzchar(product)) paste0(esc(product), " — ") else "", esc(cut_o), esc(cut_n)),
    meta_html(), sprintf('<span class="conf">Restricted RWD output · %s → %s</span>', esc(cut_o), esc(cut_n)),
    '<p class="cue">Review signals are magnitude-based cues for a human to check — not QC pass/fail results.</p>',
    '<p class="link">Stakeholder summary: <a href="data_refresh_change_summary.html">data_refresh_change_summary.html</a>.</p>',
    exec_summary_html(if (n_struct_only > 0) sprintf('<p class="note-line">%d additional profiler-interpretation and cardinality signals are structural (not review changes) — detailed in Structural signals below.</p>', n_struct_only) else ""),
    comp_sec,
    rev_sec,
    schema_sec,
    '<h2>Table row counts <span class="n">· all shared tables, flagged first</span></h2>', rowcount_html(),
    '<section class="detail-section">', str_sec, method_sec,
    '<p class="note-line">The complete per-variable comparison (every shared column, all metrics) is written alongside as <span class="tbl">snapshot_comparison_signals.tsv</span>; the full record is <span class="tbl">snapshot_comparison.md</span>.</p>',
    '</section>',
    sprintf('<div class="foot"><span><b>%s → %s</b></span><span>Restricted RWD output · generated %s</span></div>', esc(cut_o), esc(cut_n), esc(gen_time)),
    '</div>', sprintf('<div class="printfoot">Restricted RWD output · %s</div>', ident), '</body></html>')
}

# ============================ MARKDOWN RECORD ============================
render_md <- function() {
  c(sprintf("# Snapshot comparison — %s → %s\n\nold: %s | new: %s | generated %s\n%s\n_%s_\n",
            cut_o, cut_n, basename(old_path), basename(new_path), gen_time,
            if (nzchar(samp_note)) sprintf("\n**%s**\n", samp_note) else "", thr_txt),
    sprintf("\n%d review changes and %d structural signals (profiler interpretation / cardinality), of %d shared variables.\n", n_review, n_struct_only, n_shared),
    "## Signal composition\n", "| change family | variables |", "|---|---:|",
    vapply(FAM_LEVELS, function(f) sprintf("| %s | %s |", f, fmi(fam_counts[[f]])), character(1)),
    "\n## Schema changes\n",
    sprintf("- **Added tables (%d):** %s", length(added_tbls), if (length(added_tbls)) paste(added_tbls, collapse=", ") else "—"),
    sprintf("- **Dropped tables (%d):** %s", length(dropped_tbls), if (length(dropped_tbls)) paste(dropped_tbls, collapse=", ") else "—"),
    sprintf("- **Added columns (%d):** %s", length(added_cols), if (length(added_cols)) paste(added_cols, collapse=", ") else "—"),
    sprintf("- **Dropped columns (%d):** %s", length(dropped_cols), if (length(dropped_cols)) paste(dropped_cols, collapse=", ") else "—"),
    "\n## Row counts by table\n", "| table | old rows | new rows | Δ rows | Δ% |", "|---|---:|---:|---:|---:|",
    if (nrow(tbl_rows)) vapply(seq_len(nrow(tbl_rows)), function(i) { t <- tbl_rows[i, ]
      sprintf("| %s | %s | %s | %s | %s |", t$table_base, fmi(t$rows_o), fmi(t$rows_n), fmi_signed(t$d_abs),
        if (is.na(t$d_rel)) "n/a" else sprintf("%+.1f%%%s", t$d_rel, if (isTRUE(t$flag)) " ⚠" else "")) }, character(1)) else character(0),
    sprintf("\n## Review changes (%d)\n", n_review),
    if (n_review > 0) c("| table.column | family | old → new | magnitude | technical detail |", "|---|---|---|---|---|",
      vapply(seq_len(n_review), function(i) { r <- review_items[i, ]; e <- change_evidence(r, full = TRUE)
        sprintf("| %s | %s | %s → %s | %s | %s |", r$colname, r$family, gsub("|","\\|", e$old, fixed=TRUE),
          gsub("|","\\|", e$new, fixed=TRUE), gsub("|","\\|", e$mag, fixed=TRUE), gsub("|","\\|", note_for(r), fixed=TRUE)) }, character(1)))
    else "_No column crossed a review threshold._",
    sprintf("\n## Structural signals (%d — profiler interpretation / cardinality, not review changes)\n", n_struct_only),
    if (n_struct_only > 0) c("| table.column | detail |", "|---|---|",
      vapply(seq_len(n_struct_only), function(i) { r <- struct_items[i, ]
        sprintf("| %s | %s |", r$colname, gsub("|","\\|", note_for(r), fixed=TRUE)) }, character(1)))
    else "_None._")
}

# Machine-readable per-column comparison (every shared variable, all metrics) — the technical audit record.
signals_tsv <- function() {
  j %>% transmute(
    table_base, column, family = coalesce(family, ""),
    review_change = review_flag, structural = struct_flag,
    kind_old = kind.o, kind_new = kind.n, type_old = type.o, type_new = type.n,
    n_rows_old = n_rows.o, n_rows_new = n_rows.n,
    n_missing_old = n_missing.o, n_missing_new = n_missing.n,
    pct_missing_old = pct_missing.o, pct_missing_new = pct_missing.n, d_missing_pt = d_miss,
    mean_old = mean.o, mean_new = mean.n, sd_old = sd.o, sd_new = sd.n, smd = smd, q_shift_max_sd = q_shift_max,
    distinct_old = distinct.o, distinct_new = distinct.n, d_distinct_pct = 100 * d_distinct_signed,
    date_min_old = date_min.o, date_max_old = date_max.o, date_min_new = date_min.n, date_max_new = date_max.n,
    unparseable_old = unparseable.o, unparseable_new = unparseable.n, category_shift = cat_desc)
}

run <- function() {
  dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)
  stake <- file.path(out_dir, "data_refresh_change_summary.html")
  tech  <- file.path(out_dir, "snapshot_comparison.html")   # keep this name — qc_runner checks for it
  md    <- file.path(out_dir, "snapshot_comparison.md")
  tsv   <- file.path(out_dir, "snapshot_comparison_signals.tsv")
  writeLines(render_stakeholder(), stake)
  writeLines(render_technical(), tech)
  writeLines(paste(render_md(), collapse = "\n"), md)
  # Belt-and-braces for the unquoted TSV: strip any tab/newline from text cells so a stray one can't
  # misalign columns (the source profiles are tab-delimited, so this shouldn't ever fire — but cheap).
  sd_out <- signals_tsv()
  sd_out[] <- lapply(sd_out, function(col) if (is.character(col)) gsub("[\t\r\n]", " ", col) else col)
  utils::write.table(sd_out, tsv, sep = "\t", quote = FALSE, row.names = FALSE, na = "")
  message(sprintf("compared %d shared columns; %d review changes, %d structural. wrote %s, %s and %s",
                  n_shared, n_review, n_struct_only, stake, tech, tsv))
  invisible(list(review = review_items, structural = struct_items, tbl_rows = tbl_rows))
}
if (!nzchar(Sys.getenv("CMP_DEFINE_ONLY"))) run()
