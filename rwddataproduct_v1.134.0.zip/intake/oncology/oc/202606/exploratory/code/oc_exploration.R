# OC Panoramic — LOT and platinum. Builds one HTML + md report: patient counts by treatment
# setting, lines of therapy, and platinum use. dplyr over ODBC, no Spark.
#   DATABRICKS_DSN=RWDE DATABRICKS_PWD=... Rscript oc_exploration.R
# Lines come from the non-maintenance drug episodes. Items 2e (recurrence date) and 3b/3c
# (platinum-status table) need extra columns — set them below; if they're missing, those items
# are marked pending instead of run.

library(dplyr); library(tidyr); library(stringr)

# ---- config ----
catalog         <- Sys.getenv("OC_CATALOG", "hive_metastore")
schema          <- Sys.getenv("OC_SCHEMA",  "clnprw_flatiron_pano_ovar_use")
drugepisode_tbl <- Sys.getenv("OC_DRUGEP",  "t_drugepisode_2026m06")
platinum_drugs  <- "carboplatin|cisplatin|oxaliplatin"     # platinum drugs
settings_keep   <- c("Neoadjuvant", "Adjuvant", "Advanced")

# Column names for 2e / 3b / 3c. Two things to watch: recurrence date may not be delivered yet
# (check it's there, and how null it is, on a new feed); the platinum table has one row per
# platinum line (Sensitive/Resistant/Refractory/null), so a non-platinum line has no row.
recur_tbl   <- Sys.getenv("OC_RECUR_TBL",   "t_enh_ov_2026m06")
recur_col   <- Sys.getenv("OC_RECUR_COL",   "recurrencedate")
plat_tbl    <- Sys.getenv("OC_PLAT_TBL",    "t_enh_ov_platstatus_2026m06")
plat_line   <- Sys.getenv("OC_PLAT_LINE",   "linenumber")
plat_status <- Sys.getenv("OC_PLAT_STATUS", "platinumstatus")

this_dir <- tryCatch(dirname(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))),
                     error = function(e) ".")
if (!length(this_dir) || this_dir == "") this_dir <- "."
out_dir <- Sys.getenv("OC_OUT_DIR", file.path(this_dir, "outputs"))

is_nonmaint <- function(x) str_to_lower(str_trim(as.character(x))) %in% c("false","f","n","no","0")
# linesetting arrives uppercase (ADVANCED/...); title-case it so comparisons ignore casing.
canon_setting <- function(x) { s <- str_squish(as.character(x))
  ifelse(is.na(s) | s == "", NA_character_, str_to_title(s)) }
# A segment's drugs as a sorted, de-duplicated set, so order and repeats don't matter
# ("Carbo, Pac" == "Pac + Carbo"). Returns one "a|b" string from all the segment's drug names.
drug_set <- function(v) {
  toks <- unlist(str_split(str_squish(str_to_lower(as.character(v))), "\\s*[,/+;&|]\\s*"))
  toks <- toks[!is.na(toks) & toks != ""]
  paste(sort(unique(toks)), collapse = "|") }

# ---- connection ----
get_con <- function() {
  if (exists("con", envir = .GlobalEnv)) return(get("con", envir = .GlobalEnv))
  pwd <- Sys.getenv("DATABRICKS_PWD", "")
  if (!nzchar(pwd)) stop("set DATABRICKS_PWD, or provide a DBI `con`.")
  # bigint = "character" keeps 64-bit ids (patientid) EXACT — a true BIGINT beyond R's ~2^53 exact-double
  # range would otherwise lose precision and two distinct ids could collide in a join/distinct count. Small
  # numeric fields (linenumber) are coerced back to numeric at load, so ordering/arithmetic still works.
  DBI::dbConnect(odbc::odbc(), dsn = Sys.getenv("DATABRICKS_DSN", "RWDE"),
                 pwd = pwd, timeout = 120, bigint = "character")
}
fqtn <- function(tbl) paste(c(catalog, schema, tbl), collapse = ".")
load_tbl <- function(con, tbl, cols = NULL) {
  sel <- if (is.null(cols)) "*" else paste(cols, collapse = ", ")
  df <- as_tibble(DBI::dbGetQuery(con, sprintf("SELECT %s FROM %s", sel, fqtn(tbl))))
  names(df) <- tolower(names(df)); df
}

# ---- analysis ----
run_analysis <- function(con) {
  # Drop rows with no patient or line key — they can't be placed on a line, and dropping them up
  # front keeps the R and SQL counts in step (the two handle missing keys differently).
  drugep <- load_tbl(con, drugepisode_tbl,
    c("patientid","linenumber","linesetting","ismaintenancetherapy","linename","linestartdate","episodedate","drugname")) %>%
    mutate(linenumber = suppressWarnings(as.numeric(linenumber))) %>%   # patientid stays exact (character); linenumber -> numeric for ordering/joins
    filter(!is.na(patientid), !is.na(linenumber))

  # Non-maintenance episodes, setting title-cased per episode. One line can span settings
  # (neoadjuvant then adjuvant on line 1), so setting isn't one-per-line.
  ep <- drugep %>% filter(is_nonmaint(ismaintenancetherapy)) %>%
    mutate(setting = canon_setting(linesetting),
           linestartdate = as.Date(linestartdate), episodedate = as.Date(episodedate))

  # One row per line-segment (patient, line, setting). Since a line can span settings, build the
  # regimen and start from this segment's own episodes — its drug names, and its first episode.
  seg <- ep %>% filter(!is.na(setting)) %>%
    group_by(patientid, linenumber, setting) %>%
    summarise(regimen = drug_set(drugname),
              start   = suppressWarnings(min(episodedate, na.rm = TRUE)), .groups = "drop") %>%
    mutate(start = as.Date(ifelse(is.finite(start), start, NA), origin = "1970-01-01"))

  # Lines that span more than one setting. The platinum table is line-level, so their status
  # can't be tied to a single setting — flagged as a QC caveat in 3b/3c.
  span_lines <- seg %>% distinct(patientid, linenumber, setting) %>%
    count(patientid, linenumber, name = "n_set") %>% filter(n_set > 1) %>%
    distinct(patientid, linenumber)

  out <- list()   # each element: list(title, note, table)

  # 2a. patients by non-maintenance setting combination
  combo <- seg %>% filter(setting %in% settings_keep) %>% distinct(patientid, setting) %>%
    group_by(patientid) %>% summarise(combo = paste(sort(unique(setting)), collapse = " + "), .groups = "drop")
  out$q2a <- list(
    title = "2a. Patients by non-maintenance treatment setting combination",
    note  = sprintf("Denominator = %d patients with >=1 non-maintenance line in Neoadjuvant/Adjuvant/Advanced (Off-Systemic-Therapy and missing settings excluded).",
                    n_distinct(combo$patientid)),
    table = combo %>% count(combo, name = "patients") %>%
      mutate(pct = sprintf("%.1f%%", 100 * patients / sum(patients))) %>% arrange(desc(patients)))

  # 2b. patients with >1 non-maintenance adjuvant line
  adj_lines <- seg %>% filter(setting == "Adjuvant") %>% distinct(patientid, linenumber)
  n_multi_adj <- adj_lines %>% count(patientid, name = "n") %>% filter(n > 1) %>% nrow()
  out$q2b <- list(title = "2b. Patients with multiple non-maintenance adjuvant lines", note = "",
    table = tibble(metric = "patients with >1 adjuvant line", patients = n_multi_adj))

  # 2c. advanced-setting patients by total LOT count. Count only treatment settings (Neo/Adj/Adv),
  # like 2a, so Off-Systemic-Therapy doesn't inflate the line count.
  adv_pts <- seg %>% filter(setting == "Advanced") %>% distinct(patientid) %>% pull(patientid)
  lot_ct  <- seg %>% filter(patientid %in% adv_pts, setting %in% settings_keep) %>%
    distinct(patientid, linenumber) %>% count(patientid, name = "n_lot")
  out$q2c <- list(
    title = "2c. Advanced-setting patients by total number of lines of therapy",
    note  = sprintf("Denominator = %d patients with >=1 Advanced line. LOT = distinct non-maintenance lines in Neoadjuvant/Adjuvant/Advanced (Off-Systemic-Therapy excluded), not Advanced-only. Confirm whether Advanced-only is intended instead.", length(adv_pts)),
    table = lot_ct %>% count(n_lot, name = "patients") %>%
      mutate(pct = sprintf("%.1f%%", 100 * patients / sum(patients))) %>% arrange(n_lot))

  # 2d. last adjuvant regimen vs first-line Advanced regimen. regimen is a sorted drug set, so
  # equality ignores order. L1 = first Advanced line (line 1 is the earliest, so "prior to L1"
  # would be vacuous).
  first_adv <- seg %>% filter(setting == "Advanced") %>%
    arrange(patientid, linenumber) %>% group_by(patientid) %>% slice(1L) %>% ungroup() %>%
    transmute(patientid, adv_regimen = regimen, adv_start = start)
  # last adjuvant line starting before the first Advanced line ("last prior to L1"). Ties on
  # start break by higher line number, so R and SQL pick the same one.
  adj_last_pre <- seg %>% filter(setting == "Adjuvant") %>% inner_join(first_adv, by = "patientid") %>%
    filter(!is.na(start), !is.na(adv_start), start < adv_start) %>%
    arrange(patientid, desc(start), desc(linenumber)) %>%
    group_by(patientid) %>% slice(1L) %>% ungroup()
  n_same <- adj_last_pre %>% filter(nzchar(regimen) & regimen == adv_regimen) %>% nrow()
  out$q2d <- list(
    title = "2d. Patients whose last adjuvant regimen matches their first-line Advanced regimen",
    note  = "L1 = first Advanced line; adjuvant line = the last one starting before it; regimens compared as drug sets (blanks excluded). (2e uses line number 1; 2d can't, since nothing starts before line 1.)",
    table = tibble(metric = c("patients with an adjuvant line before their first-Advanced line", "same regimen"),
                   patients = c(nrow(adj_last_pre), n_same)))

  # 2e. L1 start < recurrence date  (needs recurrence date). L1 = line number 1. This uses
  # linestartdate (the line-start field), since the ask says "1L start date" — not the per-episode
  # date 2d uses. A line can span settings, so take the earliest line start across them. Built from `ep`
  # (BEFORE the setting filter), because 2e is setting-independent — a line-1 row with a missing setting
  # still counts; the SQL mirrors this by building l1 from the drug episodes directly, not from oc_lines.
  l1 <- ep %>% filter(linenumber == 1) %>% group_by(patientid) %>%
    summarise(l1_start = suppressWarnings(min(linestartdate, na.rm = TRUE)), .groups = "drop") %>%
    mutate(l1_start = as.Date(ifelse(is.finite(l1_start), l1_start, NA), origin = "1970-01-01"))
  rec <- tryCatch(load_tbl(con, recur_tbl, c("patientid", recur_col)), error = function(e) e)
  out$q2e <- if (inherits(rec, "error")) list(title = "2e. Patients with 1L start date < recurrence date",
      note = sprintf("PENDING: confirm recurrence date column (tried %s.%s). %s", recur_tbl, recur_col, conditionMessage(rec)),
      table = NULL)
    else {
      names(rec)[2] <- "recur"
      # One recurrence date per patient (earliest), so a table with >1 row per patient can't
      # fan out the join and overcount — matches the SQL's min(recurrencedate).
      rec <- rec %>% mutate(recur = as.Date(recur)) %>% filter(!is.na(recur)) %>%
        group_by(patientid) %>% summarise(recur = min(recur), .groups = "drop")
      n_l1 <- l1 %>% filter(!is.na(l1_start)) %>% nrow()
      j <- l1 %>% inner_join(rec, by = "patientid") %>% filter(!is.na(l1_start))
      list(title = "2e. Patients with 1L start date < recurrence date",
           note = "1L = line number 1, the first line of therapy (confirmed). The drop from row 1 to row 2 is patients with no recurrence date.",
           table = tibble(metric = c("patients with an L1 start", "of those, have a recurrence date", "L1 start < recurrence"),
                          patients = c(n_l1, nrow(j), sum(j$l1_start < j$recur))))
    }

  # 3a. among adjuvant-setting patients, % who received platinum chemo. The platinum has to be
  # on an adjuvant episode itself: a line can span settings, so joining on the line number would
  # wrongly credit platinum given in the neoadjuvant part of the same line.
  adj_pts  <- seg %>% filter(setting == "Adjuvant") %>% distinct(patientid) %>% pull(patientid)
  plat_adj <- ep %>% filter(setting == "Adjuvant", str_detect(str_to_lower(drugname), platinum_drugs)) %>%
    distinct(patientid) %>% pull(patientid)
  out$q3a <- list(
    title = "3a. Adjuvant-setting patients who received platinum-based chemotherapy",
    note  = sprintf("Platinum = drug name contains %s, on an adjuvant non-maintenance episode.", platinum_drugs),
    table = tibble(metric = c("adjuvant-setting patients", "received platinum", "%"),
                   value  = c(as.character(length(adj_pts)), as.character(length(plat_adj)),
                              # n/a (not 0.0%) when there are no adjuvant patients — matches the SQL's nullif(denominator,0)
                              if (length(adj_pts) > 0) sprintf("%.1f%%", 100 * length(plat_adj) / length(adj_pts)) else "n/a")))

  # 3b/3c. platinum status by setting  (needs the Panoramic platinum-status table)
  # Patient-level: one line per patient. A conflict (line with >1 distinct status) is flagged,
  # not silently resolved; matched-but-blank and no-matching-row are shown separately, so the
  # denominator stays all patients in the setting.
  plat_status_block <- function(pt_lines, title, note) {
    ps <- tryCatch(load_tbl(con, plat_tbl, c("patientid", plat_line, plat_status)), error = function(e) e)
    if (inherits(ps, "error")) return(list(title = title, table = NULL,
      note = sprintf("PENDING: confirm platinum-status table/columns (tried %s: %s, %s). %s",
                     plat_tbl, plat_line, plat_status, conditionMessage(ps))))
    names(ps) <- c("patientid", "linenumber", "status")
    # Trim before comparing (keep the trimmed text, not the raw), so " Sensitive " and "Sensitive"
    # are one status — same as the SQL's nullif(trim(platinumstatus),'').
    ps <- ps %>% mutate(linenumber = suppressWarnings(as.numeric(linenumber)),   # match drugep's numeric linenumber for the join
                        status = str_trim(status),
                        status = ifelse(is.na(status) | status == "", NA_character_, status),
                        matched = TRUE)
    cls <- pt_lines %>% left_join(ps, by = c("patientid","linenumber")) %>%
      group_by(patientid) %>%
      summarise(matched = any(!is.na(matched)),
                n_stat  = n_distinct(status[!is.na(status)]),
                one     = { s <- unique(status[!is.na(status)]); if (length(s) == 1) s else NA_character_ },
                .groups = "drop") %>%
      mutate(status = case_when(n_stat == 1 ~ one,
                                n_stat >  1 ~ "Conflicting status (multiple rows)",
                                matched     ~ "Status row present but blank",
                                TRUE        ~ "No status row"))
    # The status table has one row per line, but a line can cover more than one setting. Count how
    # many of these lines do, so that risk is shown, not hidden.
    n_span <- pt_lines %>% distinct(patientid, linenumber) %>%
      semi_join(span_lines, by = c("patientid","linenumber")) %>% nrow()
    if (n_span > 0) note <- sprintf(
      "%s QC: %d of these lines also have episodes in another setting, so their status can't be tied to just one setting — confirm how to count those.",
      note, n_span)
    list(title = title, note = note,
         table = cls %>% count(status, name = "patients") %>%
           mutate(pct = sprintf("%.1f%%", 100 * patients / sum(patients))) %>% arrange(desc(patients)))
  }

  # All adjuvant lines: the status table only has platinum lines, so the last adjuvant line
  # may not be the one with a status. The block aggregates per patient and flags conflicts.
  adj_all <- seg %>% filter(setting == "Adjuvant") %>% distinct(patientid, linenumber)
  out$q3b <- plat_status_block(adj_all, "3b. Platinum status in the adjuvant setting (patients)",
    "Panoramic PlatinumStatus across a patient's adjuvant lines; denominator = all adjuvant-setting patients (non-platinum lines have no status row).")

  first_adv_line <- seg %>% filter(setting == "Advanced") %>%
    arrange(patientid, linenumber) %>% group_by(patientid) %>% slice(1L) %>% ungroup() %>%
    distinct(patientid, linenumber)
  out$q3c <- plat_status_block(first_adv_line, "3c. Platinum status in the first-line advanced setting (patients)",
    "Panoramic PlatinumStatus. One row per patient = their earliest Advanced line; denominator = all first-line-advanced patients.")

  out
}

# ---- rendering ----
esc <- function(x) { x <- as.character(x); x <- gsub("&","&amp;",x,fixed=TRUE)
  x <- gsub("<","&lt;",x,fixed=TRUE); gsub(">","&gt;",x,fixed=TRUE) }
df_to_md <- function(df) {
  if (is.null(df) || !nrow(df)) return("_no rows_")
  head <- paste0("| ", paste(names(df), collapse = " | "), " |")
  sep  <- paste0("| ", paste(rep("---", ncol(df)), collapse = " | "), " |")
  body <- apply(df, 1, function(r) paste0("| ", paste(r, collapse = " | "), " |"))
  paste(c(head, sep, body), collapse = "\n")
}
df_to_html <- function(df) {
  if (is.null(df) || !nrow(df)) return("<p class='pending'>no rows</p>")
  th <- paste0("<th>", paste(esc(names(df)), collapse = "</th><th>"), "</th>")
  tr <- apply(df, 1, function(r) paste0("<tr><td>", paste(esc(r), collapse = "</td><td>"), "</td></tr>"))
  paste0("<table><thead><tr>", th, "</tr></thead><tbody>", paste(tr, collapse = ""), "</tbody></table>")
}
render <- function(out, gen_time) {
  md <- c(sprintf("# OC Panoramic exploration — LOT & platinum\n\n%s.%s — generated %s\n",
                  catalog, schema, gen_time))
  html_secs <- character()
  for (s in out) {
    note_md <- if (nzchar(s$note)) paste0("\n", s$note, "\n") else ""
    md <- c(md, sprintf("\n## %s\n%s", s$title, note_md), df_to_md(s$table))
    pend <- grepl("^PENDING", s$note)
    html_secs <- c(html_secs, sprintf("<h2%s>%s</h2>%s%s",
      if (pend) " class='pend'" else "", esc(s$title),
      if (nzchar(s$note)) sprintf("<p class='note'>%s</p>", esc(s$note)) else "",
      df_to_html(s$table)))
  }
  html <- paste0(
    "<!doctype html><html><head><meta charset='utf-8'><title>OC exploration — LOT &amp; platinum</title><style>",
    "body{font:14px/1.5 -apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#1a1a1a;margin:0;padding:32px;max-width:900px}",
    "h1{font-size:22px;margin:0 0 4px}h2{font-size:17px;margin:28px 0 6px;border-top:1px solid #e5e5e5;padding-top:18px}",
    "h2.pend{color:#b45309}.sub{color:#666;margin:0 0 20px}.note{color:#666;font-size:13px;margin:0 0 8px}",
    "table{border-collapse:collapse;margin:6px 0}th,td{text-align:left;padding:6px 12px;border-bottom:1px solid #eee}",
    "th{font-size:12px;text-transform:uppercase;letter-spacing:.03em;color:#555;background:#fafafa}",
    "td{font-variant-numeric:tabular-nums}</style></head><body><h1>OC Panoramic exploration — LOT &amp; platinum</h1>",
    sprintf("<p class='sub'>%s.%s &middot; generated %s</p>", esc(catalog), esc(schema), esc(gen_time)),
    paste(html_secs, collapse = "\n"), "</body></html>")
  list(md = paste(md, collapse = "\n"), html = html)
}

run <- function() {
  dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)
  con <- get_con()
  out <- run_analysis(con)
  r <- render(out, format(Sys.time(), "%Y-%m-%d %H:%M"))
  writeLines(r$html, file.path(out_dir, "oc_exploration.html"))
  writeLines(r$md,   file.path(out_dir, "oc_exploration.md"))
  cat(r$md, "\n")
  message(sprintf("wrote %s", file.path(out_dir, "oc_exploration.html")))
  invisible(out)
}
if (!nzchar(Sys.getenv("OC_DEFINE_ONLY"))) run()
