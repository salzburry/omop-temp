# qc_runner.R — the universal (tumor-agnostic) QC engine, all in one file.
#
# Nothing here is tumor-specific. In order: the shared helpers (%||%, .chk, tag), the check generators
# (product_*/reconcile_*/merge_*), the coverage gate (execution-completeness vs data-QC verdict, plus
# generated traceability), and the engine (verb handlers, SQL builders, report renderer, run_all). A tumor
# supplies only a config file that calls the generators; see qc_nsclc_config.R.
#
# Rscript qc_runner.R -> writes an HTML + md QC report and exits non-zero if any check failed.
# QC_DEFINE_ONLY=1 -> defines everything without connecting (a launcher sets this, then points CFG at a
# tumor's checks and calls run_all); also a credential-free parse check.

`%||%` <- function(x, y) if (is.null(x) || length(x) == 0 || (length(x) == 1 && is.na(x)) || identical(x, "")) y else x

# ============================ reusable check generators ============================
# Build one check entry, dropping any NULL argument (so optional fields like `filter` just vanish).
.chk  <- function(...) { x <- list(...); x[!vapply(x, is.null, logical(1))] }

# Stamp each check with its id, required flag, and disposition — the traceability metadata the coverage gate
# and generated traceability read (see the coverage-gate section below). `checks` is a generator's return
# value (a list of check entries); returns them tagged, so a tumor config writes
# `tag("17.5", reconcile_agg(...))` and never threads ref_id through every generator signature.
tag <- function(ref_id, checks, required = TRUE, disposition = "implemented")
  lapply(checks, function(ck) { ck$ref_id <- ref_id; ck$required <- required; ck$disposition <- disposition; ck })

# ============================ product-internal generators ============================

# Non-empty guard + non-null primary key + primary-key uniqueness — what every table needs first.
# The non-null check matters: unique_key (GROUP BY key HAVING count>1) treats all NULL keys as one group, so
# a lone NULL key isn't a "duplicate" and slips through; null_rate(max_pct=0) catches it.
product_identity <- function(tbl, id = "patientid", source = "product")
  c(list(.chk(type = "row_count", source = source, table = tbl, min = 1,
              label = sprintf("%s has rows", tbl))),
    lapply(id, function(k) .chk(type = "null_rate", source = source, table = tbl, col = k, max_pct = 0,
              label = sprintf("%s.%s is never null", tbl, k))),
    list(.chk(type = "unique_key", source = source, table = tbl, keys = id,
              label = sprintf("%s is 1:1 on %s", tbl, paste(id, collapse = "+")))))

# One unique_key per spec = list(table=, keys=, filter=NULL, label=NULL) — for the many "one row per key"
# CTE/table checks (single or composite keys, optionally filtered).
product_unique_keys <- function(specs, source = "product")
  lapply(specs, function(s) .chk(type = "unique_key", source = source, table = s$table,
    keys = s$keys, filter = s$filter,
    label = s$label %||% sprintf("%s is 1:1 on %s", s$table, paste(s$keys, collapse = "+"))))

# Allowed-value set. Note: `domain` is case-sensitive; for a case-insensitive set, pass a `rate` predicate
# with upper via product_predicate instead.
product_domain <- function(tbl, col, allowed, filter = NULL, source = "product")
  list(.chk(type = "domain", source = source, table = tbl, col = col, allowed = allowed,
            filter = filter, label = sprintf("%s.%s in allowed set", tbl, col)))

# Dates (one or several) aren't in the future; require_valid also fails an unparseable non-blank date.
product_not_future <- function(tbl, cols, source = "product")
  list(.chk(type = "not_future", source = source, table = tbl, cols = cols, require_valid = TRUE,
            label = sprintf("%s: %s not in the future", tbl, paste(cols, collapse = ", "))))

# lo <= hi (+ optional day offset for windows). Dates compared as dates (require_valid).
product_ordering <- function(tbl, lo, hi, offset_days = 0, filter = NULL, source = "product")
  list(.chk(type = "ordering", source = source, table = tbl, lo = lo, hi = hi,
            offset_days = if (offset_days != 0) offset_days else NULL, filter = filter, require_valid = TRUE,
            label = sprintf("%s: %s <= %s%s", tbl, lo, hi, if (offset_days != 0) sprintf(" + %dd", offset_days) else "")))

# One null_rate per column (max_pct=0 => must be fully populated).
product_completeness <- function(tbl, cols, max_pct = 0, source = "product")
  lapply(cols, function(c) .chk(type = "null_rate", source = source, table = tbl, col = c, max_pct = max_pct,
            label = sprintf("%s.%s missingness <= %g%%", tbl, c, max_pct)))

# General single-relation predicate rate (range / format / int / length checks). max_pct=0 => hard fail.
# Watch out: a hand-written predicate that casts is fail-open — a non-null value that fails to cast makes the
# predicate NULL and isn't counted. Prefer product_valid_range below for numeric bounds so an unparseable
# value is caught too; if you write `predicate` yourself, add the unparseable clause.
# strict=TRUE makes the ceiling exclusive (pct < max_pct); default is inclusive.
product_predicate <- function(tbl, predicate, label, max_pct = 0, filter = NULL, source = "product", strict = FALSE)
  list(.chk(type = "rate", source = source, table = tbl, predicate = predicate, filter = filter,
            max_pct = max_pct, strict = if (isTRUE(strict)) TRUE else NULL, label = label))

# Parse-safe numeric bound: flags a non-blank value that doesn't parse as `cast`, or a parsed value outside
# [lo, hi]. `lo`/`hi` may be numbers or SQL expressions (e.g. hi = "year(current_date)"); pass NULL to skip
# a side. Closes the fail-open trap where try_cast(x) IS NULL (an invalid non-blank like "N/A") would
# otherwise escape a range predicate. `col` is a bare column name (interpolated into raw SQL).
product_valid_range <- function(tbl, col, lo = NULL, hi = NULL, cast = "double", filter = NULL,
                                source = "product", label = NULL) {
  cst       <- sprintf("try_cast(%s AS %s)", col, cast)
  parse_bad <- sprintf("(%s IS NOT NULL AND trim(cast(%s AS string)) <> '' AND %s IS NULL)", col, col, cst)
  range_bad <- paste(c(if (!is.null(lo)) sprintf("%s < %s", cst, lo),
                       if (!is.null(hi)) sprintf("%s > %s", cst, hi)), collapse = " OR ")
  pred <- if (nzchar(range_bad)) sprintf("%s OR (%s)", parse_bad, range_bad) else parse_bad
  list(.chk(type = "rate", source = source, table = tbl, predicate = pred, filter = filter, max_pct = 0,
            label = label %||% sprintf("%s.%s is a valid %s%s", tbl, col, cast,
              if (!is.null(lo) || !is.null(hi))
                sprintf(" in [%s, %s]", if (is.null(lo)) "-inf" else lo, if (is.null(hi)) "inf" else hi) else "")))
}

# ============================ merge-safety generators ============================

merge_no_fanout <- function(base, attribute, by = "patientid", source = "product")
  list(.chk(type = "no_fanout", by = by,
            left  = list(source = source, table = base),
            right = list(source = source, table = attribute),
            label = sprintf("%s <- %s does not fan out", base, attribute)))

merge_no_loss <- function(base, attribute, by = "patientid", source = "product")
  list(.chk(type = "no_row_loss", by = by,
            left  = list(source = source, table = base),
            right = list(source = source, table = attribute),
            label = sprintf("no rows lost joining %s <- %s", base, attribute)))

# ============================ reconciliation generators (product vs source) ============================

# Every left key exists on the right (product patient in source; cohort subset; etc.). `id` is the left
# (product) key; `right_id` the right (source) key when they differ (e.g. product `patid` -> raw `patientid`).
# Per-side filters scope each universe (e.g. only deceased patients must exist in the mortality table).
reconcile_referential <- function(left_tbl, right_tbl, id = "patientid", right_id = NULL,
                                  left_filter = NULL, right_filter = NULL,
                                  left_source = "product", right_source = "raw")
  list(.chk(type = "referential",
            left  = list(source = left_source,  table = left_tbl,  col = id, filter = left_filter),
            right = list(source = right_source, table = right_tbl, col = right_id %||% id, filter = right_filter),
            label = sprintf("every %s.%s exists in %s.%s", left_tbl, id, right_tbl, right_id %||% id)))

# distinct(col) of product `relation` distinct(col) of source. `source_col` when the key name differs.
reconcile_count <- function(product_tbl, source_tbl, col = "patientid", source_col = NULL, relation = "<=",
                            product_source = "product", source_source = "raw")
  list(.chk(type = "row_count", source = product_source, table = product_tbl, select = col, distinct = TRUE,
            relation = relation,
            compare = list(source = source_source, table = source_tbl, select = source_col %||% col, distinct = TRUE),
            label = sprintf("distinct %s: %s %s %s", col, product_tbl, relation, source_tbl)))

# product_col == agg(source_col) per key (± numeric tolerance / day tolerance). `key` is the product key;
# `source_key` the source key when they differ (product `patid` -> raw `patientid`). `filter` scopes the
# source aggregate; `product_filter` scopes the product rows compared — use it to match the eligible-row
# scope (e.g. only patients with a LOT1) so the check isn't stricter and doesn't false-fail on a
# legitimately-empty product value. `allow_unmatched=TRUE` compares only keys present on both sides.
reconcile_agg <- function(key, product_tbl, product_col, source_tbl, source_col, agg, source_key = NULL,
                          filter = NULL, product_filter = NULL, tolerance = NULL, tolerance_days = NULL,
                          allow_unmatched = NULL, product_source = "product", source_source = "raw")
  list(.chk(type = "derive_equals", key = key,
            product_source = product_source, product_table = product_tbl, product = product_col,
            product_filter = product_filter, tolerance = tolerance, tolerance_days = tolerance_days,
            allow_unmatched = allow_unmatched,
            raw = list(source = source_source, table = source_tbl, key = source_key, agg = agg, col = source_col, filter = filter),
            label = sprintf("%s == %s(%s.%s)", product_col, agg, source_tbl, source_col)))

# product_col == CASE/expr mapping of a single source column (source 1:1 on key). `source_key` when the key
# name differs. `product_filter` scopes the product rows compared; `allow_unmatched=TRUE` compares only keys
# present on both sides (use it when only patients who have the source record are reconciled — a product
# patient absent from the source legitimately gets a default value and must not be flagged here).
reconcile_mapping <- function(key, product_tbl, product_col, source_tbl, source_expr, source_key = NULL,
                              product_filter = NULL, allow_unmatched = NULL, require_unique_raw = TRUE,
                              product_source = "product", source_source = "raw")
  list(.chk(type = "derive_equals", key = key,
            product_source = product_source, product_table = product_tbl, product = product_col,
            product_filter = product_filter, allow_unmatched = allow_unmatched, require_unique_raw = require_unique_raw,
            raw = list(source = source_source, table = source_tbl, key = source_key, expr = source_expr),
            label = sprintf("%s == mapping of %s", product_col, source_tbl)))

# agg(product_col) `relation` agg(source_col), global or per-key. cast handles number/date-as-string. For a
# per-key bound with different key names, pass by = list product/source keys via product_key/source_key.
# A per-key bound is fail-closed on unmatched keys by default (FULL OUTER JOIN); set allow_unmatched=TRUE to
# compare only keys present on both sides (inner join) — use it when only matched patients are reconciled
# (e.g. an inner_join spot-check), so a raw-only or product-only patient isn't counted as a violation.
# allow_empty=TRUE passes when an aggregate is NULL/empty (no data on a side) — use it when a missing
# aggregate is acceptable (e.g. `is.na(final) | is.na(raw) | final <= raw`), so a legitimately empty
# filtered population doesn't false-fail the global fail-closed default.
reconcile_bound <- function(product_tbl, product_col, source_tbl, source_col, agg = "max",
                            relation = "<=", cast = "double", by = NULL, product_key = NULL, source_key = NULL,
                            filter = NULL, product_filter = NULL, allow_unmatched = NULL, allow_empty = NULL,
                            product_source = "product", source_source = "raw")
  list(.chk(type = "bound", agg = agg, relation = relation, cast = cast, by = by, require_valid = TRUE,
            allow_unmatched = allow_unmatched, allow_empty = allow_empty,
            product = list(source = product_source, table = product_tbl, col = product_col, key = product_key, filter = product_filter),
            raw     = list(source = source_source, table = source_tbl, col = source_col, key = source_key, filter = filter),
            label = sprintf("%s(%s.%s) %s %s(source.%s)", agg, product_tbl, product_col, relation, agg, source_col)))

# Cross-table window / composite-key predicate join (use when the check mixes product + source columns or
# joins on a composite key — cases derive_equals is too narrow for). No joined row may satisfy `predicate`.
# `source_filter` scopes the source (right) rows before the join — use it to restrict to the eligible source
# records (e.g. only the biomarker names the product actually uses); `product_filter` scopes the product
# (left) rows the same way. Both default to NULL, so existing callers are unaffected.
reconcile_window <- function(product_tbl, product_keys, source_tbl, by, predicate, kind = "inner",
                             label = NULL, product_filter = NULL, source_filter = NULL,
                             product_source = "product", source_source = "raw")
  list(.chk(type = "join_check", kind = kind,
            left  = list(source = product_source, table = product_tbl, select = product_keys, filter = product_filter),
            right = list(source = source_source, table = source_tbl, filter = source_filter),
            by = by, predicate = predicate,
            label = label %||% sprintf("%s <- %s window predicate", product_tbl, source_tbl)))

# ============================ profiling / drift orchestration ============================
# Profiles each source, then (if prev_cut) drifts each source cut-over-cut. The drift paths must match where
# the `profile` verb actually writes: it points the profiler at <QC_OUT>/profile_<source>, and the profiler
# nests a per-cut folder and stamps the filename, giving
# <QC_OUT>/profile_<source>/<cut>/profile_<cut>.tsv
# so we build exactly that (one drift per source, not one generic "raw drift"). `out_root` defaults to the
# runner's default output dir name ("outputs", resolved relative to the runner); pass out_root = your QC_OUT
# if you set one. The prev_cut profile must already exist from a prior run's archive.
profile_and_drift <- function(cut, prev_cut = NULL, sources = c("raw", "product"), out_root = "outputs")
  c(lapply(sources, function(s) .chk(type = "profile", source = s, cut = cut,
             label = sprintf("profile %s", s))),
    if (!is.null(prev_cut)) lapply(sources, function(s) .chk(type = "drift",
       old = sprintf("%s/profile_%s/%s/profile_%s.tsv", out_root, s, prev_cut, prev_cut),
       new = sprintf("%s/profile_%s/%s/profile_%s.tsv", out_root, s, cut, cut),
       label = sprintf("%s drift %s -> %s", s, prev_cut, cut))) else NULL)

# ============================ coverage gate + generated traceability ====================

# One structured outcome per result, derived from fields the engine sets — never from the detail text.
# skipped placeholder template — emitted but NOT evaluated
# execution_error config error / disabled expr / dead connection / handler crash — NOT a data verdict
# info profile/drift/informational — non-gating
# passed / data_failure the actual data verdict
outcome_of <- function(r) {
  if (isTRUE(r$skipped)) return("skipped")
  if (isTRUE(r$error))   return("execution_error")
  if (isTRUE(r$info))    return("info")
  if (isTRUE(r$pass))    "passed" else "data_failure"
}

# Coverage verdict. `registry` (optional) is a named character vector ref_id -> disposition covering the full
# check inventory; when supplied, a required-and-implemented id with no emitted check is also a gap.
#
# Rules:
# * EXECUTION is INCOMPLETE if any required check was skipped (placeholder), errored, or (with a registry)
# is required-implemented but absent from the config.
# * DATA-QC is NOT EVALUABLE on an INCOMPLETE run (a partial suite must never show a green data verdict);
# otherwise FAIL if any required check failed, else PASS.
qc_coverage_report <- function(results, registry = NULL) {
  oc  <- vapply(results, outcome_of, character(1))    # structured outcome, not a text match on the detail
  req <- vapply(results, function(r) isTRUE(r$required), logical(1))
  req_skipped <- sum(req & oc == "skipped")
  req_errored <- sum(req & oc == "execution_error")
  req_passed  <- sum(req & oc == "passed")
  req_failed  <- sum(req & oc == "data_failure")
  optional_failed  <- sum(!req & oc == "data_failure")     # an enabled non-required check that failed on the data
  optional_errored <- sum(!req & oc == "execution_error")  # an enabled non-required check that errored (config/crash)
  emitted_ids <- unique(vapply(results, function(r) r$ref_id %||% "", character(1)))
  emitted_ids <- emitted_ids[nzchar(emitted_ids)]
  absent_required <- character(0)
  if (!is.null(registry)) {
    reg_impl <- names(registry)[registry %in% c("implemented", "corrected")]
    absent_required <- sort(setdiff(reg_impl, emitted_ids))
  }
  incomplete <- req_skipped > 0 || req_errored > 0 || length(absent_required) > 0
  data_qc <- if (incomplete) "NOT EVALUABLE" else if (req_failed > 0) "FAIL" else "PASS"
  list(execution_status = if (incomplete) "INCOMPLETE" else "COMPLETE",
       data_qc_result   = data_qc,
       required_total   = sum(req), required_passed = req_passed, required_failed = req_failed,
       required_skipped = req_skipped, required_errored = req_errored,
       optional_failed  = optional_failed, optional_errored = optional_errored,
       absent_required  = absent_required)
}

# One-line human summary for the report / message.
qc_coverage_line <- function(cov) sprintf(
  "Execution status: %s  |  Data QC result: %s  (required: %d passed, %d failed, %d skipped%s%s)",
  cov$execution_status, cov$data_qc_result, cov$required_passed, cov$required_failed, cov$required_skipped,
  if (cov$required_errored > 0) sprintf(", %d errored", cov$required_errored) else "",
  if (length(cov$absent_required)) sprintf(", %d absent", length(cov$absent_required)) else "")

# Build a traceability table from the config + a registry, so it can never drift from the code.
# registry: named char vector ref_id -> disposition (the maintained inventory).
qc_traceability_md <- function(results, registry, product_label = "PRODUCT") {
  by_id <- list()
  for (r in results) { id <- r$ref_id %||% ""; if (nzchar(id)) by_id[[id]] <- c(by_id[[id]], list(r)) }
  observed <- function(id) {
    rs <- by_id[[id]]; if (is.null(rs)) return("absent")
    if (any(vapply(rs, function(r) isTRUE(r$error),   logical(1)))) return("errored")
    ev <- Filter(function(r) !isTRUE(r$info) && !isTRUE(r$skipped), rs)
    if (!length(ev)) return("skipped")
    if (any(vapply(ev, function(r) !isTRUE(r$pass), logical(1)))) "failed" else "passed"
  }
  ids <- names(registry)
  n_by <- function(d) sum(registry == d)
  rows <- vapply(ids, function(id) {
    obs <- observed(id)
    # drift flag: registry says implemented but nothing emitted, or vice versa
    flag <- if (registry[[id]] %in% c("implemented", "corrected") && obs == "absent") " ⚠ MISSING"
            else if (!registry[[id]] %in% c("implemented", "corrected") && obs %in% c("passed", "failed")) " ⚠ UNEXPECTED"
            else ""
    sprintf("| %s | %s | %s%s |", id, registry[[id]], obs, flag)
  }, character(1))
  # Count every disposition the registry actually uses (so a new disposition name can't silently vanish from
  # the summary), gating ones first. The set is data-driven, not hardcoded, for exactly that reason.
  gating   <- c("implemented", "corrected")
  disp_order <- c(gating, sort(setdiff(unique(registry), gating)))
  summary_line <- paste(vapply(disp_order, function(d) sprintf("%s %d", d, n_by(d)), character(1)), collapse = ", ")
  c(sprintf("# %s QC coverage — regenerated on each run\n", product_label),
    "> Auto-generated; do not hand-edit.\n",
    sprintf("Inventory: %d checks — %s. Gating (must-run): %d.\n",
            length(ids), summary_line, sum(registry %in% gating)),
    "| Ref ID | Registry disposition | Observed in config |", "|---|---|---|",
    unname(rows))
}

# ============================ QC engine: verbs, SQL, report, run_all ======================
# Config-driven QC runner — declare the "ends" (data sources) and the checks to run against them, all in the
# CFG block below. Standalone, works for any tumor/product. The same check library runs at any stage: the raw
# feed (before/at ingestion) and the built product (after), plus raw->product reconciliation across stages.
#
# Two outputs from one file:
# - Rscript qc_runner.R -> writes an HTML + md QC report and exits non-zero if any check failed
# - testthat::test_file("qc_runner.R") -> the same checks register as test_that cases for CI/test runners
#
# Each rule check pushes its work down to SQL as one or a few COUNT queries — it never pulls a whole table
# (some verbs run 2: row_count-compare, no_fanout/no_row_loss, derive_equals; domain adds a sample query
# only when it fails). Dates, domains and joins are all checked in the warehouse. `profile`/`drift` shell
# out to the sibling scripts, so one config covers profiling, drift, and rule/reconciliation QC with no
# duplicated logic. Exception: the `expr` escape hatch can pull a table into R (its load does SELECT *);
# it's an expert-only fallback for a check no verb covers — prefer the verbs, which stay push-down.
#
# Check verbs (type = ...). Every table-target verb also takes an optional `filter` (a SQL WHERE
# fragment) so a check can target a filtered/derived subset, not just a whole table. Join-shaped verbs
# take `left`/`right` relation specs {source, table, filter, select, distinct}; `by` is a key column,
# a vector of key columns, or list(left=, right=) when the names differ across the two sides.
# profile profile a whole source (distribution + missingness) -> data_profiler.R
# drift diff two profile_<cut>.tsv files (temporal drift) -> compare_snapshots.R
# domain column values are within an allowed set
# not_future a date column (or several, via `cols`) is not in the future
# ordering one column <= another (+ optional `offset_days`, e.g. testdate <= indexdt + 14)
# null_rate a column's missingness (over the optional filter) is <= a threshold
# rate the share of rows (single relation OR a join) matching `predicate` is <= `max_pct`
# unique_key no duplicate key combinations (1:1 safety)
# referential every key in A exists in B (no orphan keys; multi-col keys + per-side filters supported)
# row_count row count within [min,max]/equals, OR compares (<=,==,...) to another relation's count
# (needs >=1 of expected/min/max/compare, else it asserts nothing — set informational=TRUE to just report the count)
# no_fanout a LEFT JOIN does not expand the left row count
# no_row_loss an INNER JOIN keeps every left row (counts unmatched left rows via an anti-join)
# derive_equals a product column equals an aggregate OR a mapping-`expr` of raw (per key; optional
# tolerance / tolerance_days — tolerance is fail-closed on an unmatched/one-null row unless allow_unmatched=TRUE;
# mapping mode assumes a 1:1 raw key — add require_unique_raw=TRUE to assert it)
# bound min/max/sum/avg(product col) <op> same-agg(raw col), globally or per key (e.g. final max <=
# raw max); per-key is fail-closed on unmatched/NULL keys unless allow_unmatched=TRUE. Set
# cast="double"/"date" when the columns are numbers/dates stored as strings (else agg is lexical);
# add require_valid=TRUE to also fail on a non-blank value that doesn't parse (the agg would skip it)
# join_check join two relations and assert no `predicate` violations, or no fan-out / no loss (windows, pairings)
# expr escape hatch: a user R expression returning the count of violations (0 = pass). Runs
# arbitrary R with the connection in scope — expert-only; set QC_NO_EXPR=1 to reject expr checks
# Empty-data policy: null_rate / rate / bound don't treat a zero-row or all-NULL relation as a pass — they
# flag it unless allow_empty=TRUE. A nonzero profile/drift subprocess exit is a failure, not an info row.

library(dplyr); library(stringr)

# ============================ CONFIG — edit these, then run ============================
CFG <- list(
  # The "ends". Name each stage; point it at any catalog/schema (edit per tumor / product).
  sources = list(
    raw     = list(catalog = "hive_metastore", schema = ""),   # REQUIRED — the raw feed's schema (per tumor/product)
    product = list(catalog = "hive_metastore", schema = "")     # REQUIRED — the built product's schema (may equal raw)
  ),
  out_dir = "",  # where the report goes; "" = ./outputs next to this script (QC_OUT)

  # The checks. Empty by default — a launcher (e.g. qc_run_nsclc.R) sets CFG$checks to its tumor's list before
  # calling run_all(). Left empty here so running this engine file on its own asserts nothing (and reports that)
  # rather than running any product's checks. See the `examples` block below and the generators for how to
  # build a check list; qc_nsclc_config.R is a full worked one.
  checks = list(),

  # A copy-paste library of every verb, incl. cross-stage reconciliation and raw->product merge-QC checks.
  # Not executed — run_all only iterates CFG$checks. To use one: move the entry up into `checks`, replace
  # every <placeholder> table/column name, and point CFG$sources$product at your product schema. (Safety
  # net: run_checks skips — as an "info" row, not a run — any check whose table name still contains "<...>",
  # so an un-edited copy shows up as a template instead of erroring.) Some examples use illustrative table
  # names (t_lineoftherapy, t_demographics, t_vitals) just to show the pattern.
  examples = list(
    # --- profiling / drift orchestration (one config surface over profiling + QC). profile runs an exact
    # full-schema profile (DC_SAMPLE_N=0) unless you set sample_n, so it can be expensive; drift needs
    # real full profile_<cut>.tsv paths from prior profiler runs (never profile_new_*). ---
    list(type = "profile", source = "raw",     cut = "2026m06", label = "profile raw feed"),
    list(type = "profile", source = "product", cut = "2026m06", label = "profile product"),
    list(type = "drift",
         old = "outputs/2026m03/profile_2026m03.tsv",
         new = "outputs/2026m06/profile_2026m06.tsv", label = "raw drift m03 -> m06"),

    # --- cross-stage raw -> product reconciliation ---
    list(type = "referential",
         left  = list(source = "product", table = "<product_tbl>", col = "patientid"),
         right = list(source = "raw",     table = "t_enh_ov_2026m06", col = "patientid"),
         label = "every product patient exists in raw"),
    list(type = "no_fanout",
         left = list(source = "product", table = "<base_tbl>"),
         right = list(source = "product", table = "<demographics_tbl>"), by = "patientid"),
    list(type = "derive_equals", label = "lot1 start == min raw non-maint LOT1 episode",
         key = "patientid", product_source = "product", product_table = "<product_tbl>", product = "lot1sd",
         raw = list(source = "raw", table = "t_drugepisode_2026m06", agg = "min", col = "linestartdate",
                    filter = "linenumber = 1 AND lower(trim(ismaintenancetherapy)) IN ('false','f','n','no','0')")),

    # --- filtered targets & new verbs (raw->product parity; edit placeholders per product) ---
    # A filtered target: LOT1 non-maintenance rows must be 1:1 per patient (safe to join).
    list(type = "unique_key", source = "raw", table = "t_lineoftherapy_2026m06", keys = "patientid",
         filter = "linenumber = 1 AND upper(ismaintenancetherapy) = 'FALSE'", label = "LOT1 non-maint is 1:1"),
    # No fan-out when a filtered raw table is left-joined onto the distinct patient list.
    list(type = "no_fanout", label = "advanced cohort <- LOT1 does not fan out",
         left  = list(source = "raw", table = "t_enh_ov_2026m06", select = "patientid", distinct = TRUE),
         right = list(source = "raw", table = "t_lineoftherapy_2026m06", filter = "linenumber = 1"), by = "patientid"),
    # Count-vs-count: product patient count must not exceed raw patient count.
    list(type = "row_count", source = "product", table = "<product_tbl>", select = "patientid", distinct = TRUE,
         relation = "<=", compare = list(source = "raw", table = "t_enh_ov_2026m06", select = "patientid", distinct = TRUE),
         label = "product patients <= raw patients"),
    # Mapping derivation: product 'gender' equals a CASE mapping of raw birthsex (raw side 1:1 on key).
    list(type = "derive_equals", label = "gender == mapping of raw birthsex", key = "patientid",
         product_table = "<product_tbl>", product = "gender",
         raw = list(source = "raw", table = "t_demographics_2026m06",
                    expr = "CASE WHEN upper(birthsex)='F' THEN 'Female' WHEN upper(birthsex)='M' THEN 'Male' ELSE 'Missing' END")),
    # Numeric tolerance: derived age within 1 of year(indexdt) - birthyear (raw side 1:1 on key).
    list(type = "derive_equals", label = "age within 1 of indexyr - birthyear", key = "patientid",
         product_table = "<product_tbl>", product = "age", tolerance = 1,
         raw = list(source = "raw", table = "t_demographics_2026m06", expr = "year(current_date()) - birthyear")),
    # Aggregate bound: final weight max must not exceed the raw weight max. cast="double" because both columns
    # are numbers stored as strings (testresultcleaned is cast to double in the rate check below) — without it
    # max compares lexically ("1000" < "95") and a real over-max could pass.
    list(type = "bound", agg = "max", relation = "<=", cast = "double", label = "final weight max <= raw weight max",
         product = list(source = "product", table = "<product_tbl>", col = "weight"),
         raw     = list(source = "raw", table = "t_vitals_2026m06", col = "testresultcleaned",
                        filter = "upper(test) = 'BODY WEIGHT'")),
    # Predicate rate over a join: <1% of same-date BP pairs have diastolic >= systolic. Values are cast
    # in the predicate so the comparison stays numeric even when the raw column is stored as a string.
    list(type = "rate", max_pct = 1, label = "<1% of BP pairs have diastolic >= systolic",
         left  = list(source = "raw", table = "t_vitals_2026m06",
                      filter = "upper(test) = 'SYSTOLIC BLOOD PRESSURE' AND testresultcleaned IS NOT NULL"),
         right = list(source = "raw", table = "t_vitals_2026m06",
                      filter = "upper(test) = 'DIASTOLIC BLOOD PRESSURE' AND testresultcleaned IS NOT NULL"),
         by = list(left = c("patientid", "testdate"), right = c("patientid", "testdate")),
         predicate = "try_cast(r.testresultcleaned AS double) >= try_cast(l.testresultcleaned AS double)"),
    # Date-window join: no raw biomarker result used later than indexdt + 14 days. (<biomarker_tbl> is a
    # placeholder — point right at your biomarker source and its result-date column.)
    list(type = "join_check", kind = "inner", label = "biomarker resultdate <= indexdt + 14",
         left  = list(source = "product", table = "<product_tbl>", select = c("patid", "indexdt")),
         right = list(source = "raw", table = "<biomarker_tbl>"),
         by = list(left = "patid", right = "patientid"),
         predicate = "try_cast(r.resultdate AS date) > date_add(try_cast(l.indexdt AS date), 14)")
  ),

  # A run with no runnable pass/fail assertion (empty checks, only placeholders, or only info steps) fails
  # by default, so a mis-wired config can't exit 0 silently. Set TRUE (or QC_ALLOW_INFO_ONLY=1) for a
  # deliberately info-only run (e.g. profile/drift only).
  allow_info_only = FALSE,

  # profile/drift verbs shell out to these sibling scripts (paths relative to this script unless absolute)
  profiler_script = "data_profiler.R",
  compare_script  = "compare_snapshots.R"
)
# ======================================================================================

getcfg  <- function(env, default) { v <- Sys.getenv(env, ""); if (nzchar(v)) v else default }

this_dir <- tryCatch(dirname(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))),
                     error = function(e) ".")
if (!length(this_dir) || this_dir == "") this_dir <- "."
out_dir <- { v <- getcfg("QC_OUT", CFG$out_dir); if (nzchar(v)) v else file.path(this_dir, "outputs") }
abspath <- function(p) if (nzchar(p) && (startsWith(p, "/") || grepl("^[A-Za-z]:", p))) p else file.path(this_dir, p)

# ---- connection + SQL helpers ----
# bigint = "character" keeps 64-bit ids exact (matches data_profiler.R). Rule checks run in SQL and only
# return counts, which q1 re-parses as numbers, so they never notice. It only matters for the `expr`
# hatch, where a large id pulled into R stays exact instead of losing precision as a double.
get_con <- function() {
  if (exists("con", envir = .GlobalEnv)) return(get("con", envir = .GlobalEnv))
  pwd <- Sys.getenv("DATABRICKS_PWD", "")
  if (!nzchar(pwd)) stop("set DATABRICKS_PWD, or provide a DBI `con` in the global env.")
  DBI::dbConnect(odbc::odbc(), dsn = Sys.getenv("DATABRICKS_DSN", "RWDE"), pwd = pwd, timeout = 120, bigint = "character")
}
bt  <- function(x) paste0("`", x, "`")                                   # backtick an identifier
# Escape backslashes then single-quotes: Spark parses backslash escapes inside '...' literals by default
# (spark.sql.parser.escapedStringLiterals=false), so a raw "\t" in an allowed value would become a TAB and
# mis-match. Double each backslash first, then double each quote, so the literal is taken verbatim.
sqs <- function(x) sprintf("'%s'", gsub("'", "''", gsub("\\", "\\\\", x, fixed = TRUE)))
fq  <- function(source, table) {                                        # fully-qualified name for a named source
  s <- CFG$sources[[source]]
  if (is.null(s)) stop(sprintf("check references unknown source '%s' (define it in CFG$sources)", source))
  if (!nzchar(s$catalog %||% "") || !nzchar(s$schema %||% ""))          # blank-required: no silent wrong-schema run
    stop(sprintf("source '%s' has an empty catalog/schema — set CFG$sources$%s (differs per tumor/product)", source, source))
  paste(c(s$catalog, s$schema, table), collapse = ".")
}
# Every DB read goes through qdf so a single counter measures per-check query volume — measure before you
# optimize. run_checks snapshots the counter around each check.
.qstat <- new.env(); .qstat$n <- 0L
qdf <- function(con, sql) { .qstat$n <- .qstat$n + 1L; DBI::dbGetQuery(con, sql) }
q1  <- function(con, sql) as.numeric(qdf(con, sql)[[1]][1])             # scalar from a single-value query
qcol <- function(con, sql) qdf(con, sql)[[1]]                           # first column as a vector
fmi <- function(n) format(n, big.mark = ",", scientific = FALSE)        # integer count -> "1,234,567" (never 1e+06)

# ---- result constructor ----
# info=TRUE marks a non-pass/fail step (profile/drift) so it never fails the suite. error=TRUE marks a result
# that is NOT a data verdict but an EXECUTION problem the coverage gate must read as incomplete, not as a data
# failure — a config error (missing threshold), a disabled expr, an unknown check type, a dead connection, or a
# handler crash. It is set structurally (never inferred from the detail text), so the coverage gate keys off a
# field, not a string.
res <- function(label, type, pass = NA, n_bad = NA, total = NA, detail = "", sample = "", info = FALSE, error = FALSE) {
  # Normalize the text fields to a single non-empty-safe string: a handler that builds a detail with
  # sprintf and a NULL argument yields character(0), and render's vapply(..., character(1)) would then
  # abort the WHOLE run (writing no report) instead of surfacing that one check. Length-0 -> "".
  n1 <- function(x) if (length(x) == 0) "" else x[[1]]
  # ref_id / required / disposition are traceability metadata (coverage gate + generated traceability). They
  # start empty here and run_checks copies them from the check config onto each result after the handler
  # runs, so a handler never has to know about them.
  list(label = n1(label), type = n1(type), pass = pass, n_bad = n_bad, total = total,
       detail = n1(detail), sample = n1(sample), info = info, error = error,
       ref_id = "", required = FALSE, disposition = "")
}

# ---- SQL builders shared by the verbs ----
# Join keys: a char vector (same names both sides) or list(left=, right=) for differing names.
# Validate equal, non-zero lengths so unequal vectors can't silently recycle into a wrong join condition.
join_on <- function(by) {
  if (is.list(by)) {
    if (length(by$left) != length(by$right) || length(by$left) < 1)
      stop(sprintf("join keys must be non-empty and equal length: left=%d, right=%d", length(by$left), length(by$right)))
    paste(sprintf("l.%s = r.%s", bt(by$left), bt(by$right)), collapse = " AND ")
  } else {
    if (length(by) < 1) stop("join key `by` must be non-empty")
    paste(sprintf("l.%s = r.%s", bt(by), bt(by)), collapse = " AND ")
  }
}
and_filter <- function(base, filter) if (!is.null(filter) && nzchar(filter)) sprintf("(%s) AND (%s)", base, filter) else base
whereof    <- function(filter) if (!is.null(filter) && nzchar(filter)) sprintf(" WHERE %s", filter) else ""
# A filtered/derived relation -> "(SELECT [DISTINCT] <cols|*> FROM cat.sch.tbl [WHERE <filter>])". Every
# table-target verb builds on this, so any check can target a filtered subset or a projected key list.
rel <- function(spec) {
  sel  <- if (!is.null(spec$select)) paste(vapply(spec$select, bt, character(1)), collapse = ", ") else "*"
  dist <- if (isTRUE(spec$distinct)) "DISTINCT " else ""
  sprintf("(SELECT %s%s FROM %s%s)", dist, sel, fq(spec$source, spec$table), whereof(spec$filter))
}
fmt2 <- function(v) if (length(v) != 1 || is.na(v)) "NA" else fmi(v)     # scalar formatter tolerant of NA/empty

# ---- verb handlers: each returns res(...) ----
handlers <- list(
  domain = function(chk, con) {
    lst  <- paste(vapply(chk$allowed, sqs, character(1)), collapse = ", ")
    tab  <- fq(chk$source, chk$table)
    cond <- and_filter(sprintf("%s IS NOT NULL AND %s NOT IN (%s)", bt(chk$col), bt(chk$col), lst), chk$filter)
    nbad <- q1(con, sprintf("SELECT count(*) FROM %s WHERE %s", tab, cond))
    samp <- if (nbad > 0) paste(utils::head(qcol(con, sprintf(
      "SELECT DISTINCT %s FROM %s WHERE %s LIMIT 20", bt(chk$col), tab, cond)), 20), collapse = ", ") else ""
    res(chk$label %||% sprintf("domain %s.%s", chk$table, chk$col), "domain",
        pass = nbad == 0, n_bad = nbad, detail = sprintf("%d rows outside the allowed set", nbad), sample = samp)
  },
  schema = function(chk, con) {
    # Compare a relation's columns to a manifest: a named list/vector of column -> expected data type. Flags
    # MISSING expected columns, UNEXPECTED extra columns (unless allow_extra=TRUE), and TYPE mismatches (unless
    # check_types=FALSE). Type match: a PARAMETERIZED expected type (has "(") must match EXACTLY, so
    # decimal(10,2) rejects decimal(18,4); a BARE expected type matches the family (expected "decimal" accepts
    # any decimal, "int" accepts only int not "interval"). Complex <...> types compare in full. Reads the schema
    # from DESCRIBE, dropping the partition/detail block (its rows have a blank or "#"-prefixed name).
    want_n  <- tolower(names(chk$manifest)); want_t <- tolower(as.character(unlist(chk$manifest)))
    if (!length(want_n) || anyDuplicated(want_n) || any(!nzchar(want_n)) || any(!nzchar(want_t)))
      stop("schema: manifest must be a non-empty named list of unique columns -> non-blank types")
    base    <- function(x) sub("\\(.*$", "", x)          # strip (params) for a family match; keeps <...> intact
    tymatch <- function(a, w) if (grepl("(", w, fixed = TRUE)) a == w else base(a) == base(w)
    d  <- qdf(con, sprintf("DESCRIBE %s", fq(chk$source, chk$table)))
    cn <- tolower(trimws(as.character(d[[1]]))); dt <- tolower(trimws(as.character(d[[2]])))
    meta <- which(cn == "" | startsWith(cn, "#"))
    keep <- if (length(meta)) seq_len(meta[1] - 1L) else seq_along(cn)
    actual  <- stats::setNames(dt[keep], cn[keep])
    missing <- setdiff(want_n, names(actual))
    extra   <- if (isTRUE(chk$allow_extra)) character(0) else setdiff(names(actual), want_n)
    badtype <- character(0)
    if (!identical(chk$check_types, FALSE))
      for (i in seq_along(want_n)) {
        # `actual` is an ATOMIC character vector, not a list: for an atomic vector x[["absent"]]
        # THROWS "subscript out of bounds" rather than returning NULL, so the !is.null() guard below
        # never got the chance to fire. A manifest naming any column the DESCRIBE does not return
        # crashed the schema verb instead of reporting it — the exact case the verb exists to catch.
        # Missing columns are already collected in `missing`; this loop only type-checks present ones.
        a <- if (want_n[i] %in% names(actual)) actual[[want_n[i]]] else NULL
        if (!is.null(a) && !tymatch(a, want_t[i]))
          badtype <- c(badtype, sprintf("%s(%s!=%s)", want_n[i], a, want_t[i]))
      }
    nbad <- length(missing) + length(extra) + length(badtype)
    res(chk$label %||% sprintf("schema %s", chk$table), "schema", pass = nbad == 0, n_bad = nbad,
        detail = sprintf("%d missing [%s]; %d unexpected [%s]; %d wrong-type [%s]",
          length(missing), paste(utils::head(missing, 10), collapse = ","),
          length(extra),   paste(utils::head(extra, 10),   collapse = ","),
          length(badtype), paste(utils::head(badtype, 10), collapse = ",")))
  },
  not_future = function(chk, con) {
    cols <- chk$cols %||% chk$col
    # try_cast makes an invalid date NULL, so by itself this proves "no PARSEABLE future date". require_valid=TRUE
    # also counts a non-blank value that fails to parse as a violation, closing that fail-open for date QC.
    per_col <- function(c) { f <- sprintf("try_cast(%s AS date) > current_date()", bt(c))
      if (isTRUE(chk$require_valid))
        f <- sprintf("(%s) OR (%s IS NOT NULL AND trim(cast(%s AS string)) <> '' AND try_cast(%s AS date) IS NULL)",
                     f, bt(c), bt(c), bt(c))
      f }
    disj <- paste(vapply(cols, per_col, character(1)), collapse = " OR ")
    nbad <- q1(con, sprintf("SELECT count(*) FROM %s WHERE %s", fq(chk$source, chk$table), and_filter(disj, chk$filter)))
    res(chk$label %||% sprintf("not_future %s.%s", chk$table, paste(cols, collapse = ",")), "not_future",
        pass = nbad == 0, n_bad = nbad,
        detail = sprintf("%d rows with a future%s date", nbad, if (isTRUE(chk$require_valid)) " or unparseable" else ""))
  },
  ordering = function(chk, con) {
    off <- as.integer(chk$offset_days %||% 0L)
    # Compare as DATES when there's a date offset, or the columns are declared dates (as_date / require_valid).
    # Otherwise compare the raw columns (native date/timestamp or numeric). Casting is what stops a non-ISO
    # character date from being compared LEXICOGRAPHICALLY (e.g. "09/01/2026" vs "10/12/2025").
    as_date <- off != 0L || isTRUE(chk$as_date) || isTRUE(chk$require_valid)
    if (as_date) {
      lo_e <- sprintf("try_cast(%s AS date)", bt(chk$lo))
      hi_e <- if (off != 0L) sprintf("date_add(try_cast(%s AS date), %d)", bt(chk$hi), off)
              else           sprintf("try_cast(%s AS date)", bt(chk$hi))
    } else { lo_e <- bt(chk$lo); hi_e <- bt(chk$hi) }
    base <- sprintf("%s IS NOT NULL AND %s IS NOT NULL AND %s > %s", bt(chk$lo), bt(chk$hi), lo_e, hi_e)
    # require_valid=TRUE (date columns): also count a non-blank lo/hi that fails to parse as a date, so an
    # invalid date can't slip through by casting to NULL.
    if (isTRUE(chk$require_valid))
      base <- sprintf("(%s) OR %s", base, paste(vapply(c(chk$lo, chk$hi), function(c)
        sprintf("(%s IS NOT NULL AND trim(cast(%s AS string)) <> '' AND try_cast(%s AS date) IS NULL)", bt(c), bt(c), bt(c)),
        character(1)), collapse = " OR "))
    nbad <- q1(con, sprintf("SELECT count(*) FROM %s WHERE %s", fq(chk$source, chk$table), and_filter(base, chk$filter)))
    res(chk$label %||% sprintf("ordering %s: %s <= %s%s", chk$table, chk$lo, chk$hi, if (off != 0L) sprintf(" + %d", off) else ""),
        "ordering", pass = nbad == 0, n_bad = nbad,
        detail = sprintf("%d rows violating %s <= %s%s", nbad, chk$lo, chk$hi, if (isTRUE(chk$require_valid)) " (or unparseable)" else ""))
  },
  null_rate = function(chk, con) {
    if (is.null(chk$max_pct))   # required ceiling: without it `pct <= NULL` is logical(0) and the detail sprintf
      return(res(chk$label %||% sprintf("null_rate %s.%s", chk$table, chk$col), "null_rate",   # collapses to character(0)
                 pass = FALSE, error = TRUE, detail = "null_rate requires max_pct (the percent-missing ceiling)"))
    r <- qdf(con, sprintf(
      "SELECT sum(CASE WHEN %s IS NULL OR trim(cast(%s AS string)) = '' THEN 1 ELSE 0 END) AS bad, count(*) AS tot FROM %s%s",
      bt(chk$col), bt(chk$col), fq(chk$source, chk$table), whereof(chk$filter)))
    bad <- as.numeric(r$bad[1]); tot <- as.numeric(r$tot[1])
    if (tot == 0)   # a zero-row relation is NOT 0% missing — don't let an empty table silently pass a gate
      return(res(chk$label %||% sprintf("null_rate %s.%s", chk$table, chk$col), "null_rate",
                 pass = isTRUE(chk$allow_empty), n_bad = 0, total = 0,
                 detail = "no rows to evaluate (set allow_empty=TRUE to pass)"))
    pct <- 100 * bad / tot
    res(chk$label %||% sprintf("null_rate %s.%s", chk$table, chk$col), "null_rate",
        pass = pct <= chk$max_pct, n_bad = bad, total = tot,
        detail = sprintf("%.1f%% missing (%s of %s); limit %.1f%%", pct, fmi(bad), fmi(tot), chk$max_pct))
  },
  rate = function(chk, con) {
    if (is.null(chk$max_pct))   # required ceiling (see null_rate): a missing max_pct would crash render, not this check
      return(res(chk$label %||% "rate", "rate", pass = FALSE, error = TRUE, detail = "rate requires max_pct (the percent ceiling)"))
    # NOTE: `predicate` is authored verbatim; this verb does NOT validate that its operands parse. If the
    # predicate casts (e.g. try_cast(x AS date)), a non-null-but-unparseable value makes the predicate NULL
    # and is NOT counted — make the predicate handle it (e.g. OR try_cast(x AS date) IS NULL) if that matters.
    from <- if (!is.null(chk$right))
              sprintf("%s l %s JOIN %s r ON %s", rel(chk$left), toupper(chk$kind %||% "INNER"), rel(chk$right), join_on(chk$by))
            else sprintf("%s x", rel(chk))
    r <- qdf(con, sprintf("SELECT sum(CASE WHEN %s THEN 1 ELSE 0 END) AS bad, count(*) AS tot FROM %s", chk$predicate, from))
    bad <- as.numeric(r$bad[1]); tot <- as.numeric(r$tot[1])
    if (tot == 0)   # empty denominator: not "0% match" — flag unless explicitly allowed
      return(res(chk$label %||% "rate", "rate", pass = isTRUE(chk$allow_empty), n_bad = 0, total = 0,
                 detail = "no rows to evaluate (set allow_empty=TRUE to pass)"))
    pct <- 100 * bad / tot
    # strict=TRUE => the ceiling is EXCLUSIVE (pct < max_pct); the default is inclusive (<=). Only differs at
    # pct == max_pct exactly, but that boundary is where a strict check flips, so some checks need it (e.g. a
    # "< 20%" or "< 1%" rule fails at exactly the threshold).
    pass <- if (isTRUE(chk$strict)) pct < chk$max_pct else pct <= chk$max_pct
    res(chk$label %||% "rate", "rate", pass = pass, n_bad = bad, total = tot,
        detail = sprintf("%.2f%% of %s rows match predicate (limit %s %.2f%%)", pct, fmi(tot),
                         if (isTRUE(chk$strict)) "<" else "<=", chk$max_pct))
  },
  unique_key = function(chk, con) {
    keys <- paste(vapply(chk$keys, bt, character(1)), collapse = ", ")
    nbad <- q1(con, sprintf("SELECT count(*) FROM (SELECT %s FROM %s%s GROUP BY %s HAVING count(*) > 1)",
                            keys, fq(chk$source, chk$table), whereof(chk$filter), keys))
    res(chk$label %||% sprintf("unique_key %s (%s)", chk$table, paste(chk$keys, collapse = ",")), "unique_key",
        pass = nbad == 0, n_bad = nbad, detail = sprintf("%d duplicate key combinations", nbad))
  },
  referential = function(chk, con) {
    lcols <- chk$left$col; rcols <- chk$right$col
    if (length(lcols) != length(rcols) || length(lcols) < 1)   # unequal key vectors would recycle into a wrong join
      stop(sprintf("referential: left$col and right$col must be non-empty and equal length (%d vs %d)", length(lcols), length(rcols)))
    lk  <- paste(vapply(lcols, bt, character(1)), collapse = ", ")
    rk  <- paste(vapply(rcols, bt, character(1)), collapse = ", ")
    onj <- paste(sprintf("l.%s = r.%s", vapply(lcols, bt, character(1)), vapply(rcols, bt, character(1))), collapse = " AND ")
    # A null left key matches nothing on the right, so by default it counts as an orphan (a null patientid in a
    # raw table is a real integrity failure, not something to skip). allow_null_left = TRUE filters null keys out
    # first — use it only when a null key is a legitimate, expected value on the left side.
    lwhere <- if (isTRUE(chk$allow_null_left))
      and_filter(paste(vapply(lcols, function(c) sprintf("%s IS NOT NULL", bt(c)), character(1)), collapse = " AND "),
                 chk$left$filter)
    else chk$left$filter
    nbad <- q1(con, sprintf(
      "SELECT count(*) FROM (SELECT DISTINCT %s FROM %s%s) l LEFT ANTI JOIN (SELECT DISTINCT %s FROM %s%s) r ON %s",
      lk, fq(chk$left$source, chk$left$table), whereof(lwhere),
      rk, fq(chk$right$source, chk$right$table), whereof(chk$right$filter), onj))
    res(chk$label %||% sprintf("referential %s.%s in %s.%s", chk$left$table, paste(lcols, collapse = ","),
        chk$right$table, paste(rcols, collapse = ",")), "referential",
        pass = nbad == 0, n_bad = nbad, detail = sprintf("%d orphan keys not found in the right table", nbad))
  },
  row_count = function(chk, con) {
    n  <- q1(con, sprintf("SELECT count(*) FROM %s", rel(chk)))
    # An unconstrained row_count (no expected/min/max/compare) asserts NOTHING but would otherwise pass
    # unconditionally AND satisfy the "at least one assertion" guard — a vacuous gate. Treat it as a config
    # error (FAIL loud), unless informational=TRUE, which reports the count as a non-gating info row.
    if (is.null(chk$expected) && is.null(chk$min) && is.null(chk$max) && is.null(chk$compare))
      return(res(chk$label %||% sprintf("row_count %s", chk$table), "row_count",
                 pass = if (isTRUE(chk$informational)) NA else FALSE,
                 n_bad = if (isTRUE(chk$informational)) NA else 1, total = n, info = isTRUE(chk$informational),
                 error = !isTRUE(chk$informational),   # an unconstrained non-informational row_count is a CONFIG error, not a data failure
                 detail = if (isTRUE(chk$informational)) sprintf("%s rows (informational)", fmi(n))
                          else sprintf("%s rows — row_count asserts nothing without expected/min/max/compare (or set informational=TRUE)", fmi(n))))
    ok <- TRUE; detail <- sprintf("%s rows", fmi(n))
    if (!is.null(chk$expected)) ok <- n == chk$expected
    if (!is.null(chk$min))      ok <- ok && n >= chk$min
    if (!is.null(chk$max))      ok <- ok && n <= chk$max
    if (!is.null(chk$compare)) {
      m  <- q1(con, sprintf("SELECT count(*) FROM %s", rel(chk$compare)))
      op <- chk$relation %||% "=="
      if (!op %in% c("==", "<=", "<", ">=", ">"))     # reject a typo'd operator instead of silently using ==
        stop(sprintf("row_count: unknown relation '%s' (==, <=, <, >=, >)", op))
      ok <- ok && switch(op, "==" = n == m, "<=" = n <= m, "<" = n < m, ">=" = n >= m, ">" = n > m)
      detail <- sprintf("%s rows %s %s", fmi(n), op, fmi(m))
    }
    res(chk$label %||% sprintf("row_count %s", chk$table), "row_count",
        pass = ok, n_bad = if (ok) 0 else 1, total = n, detail = detail)
  },
  no_fanout = function(chk, con) {
    n_left <- q1(con, sprintf("SELECT count(*) FROM %s l", rel(chk$left)))
    n_join <- q1(con, sprintf("SELECT count(*) FROM %s l LEFT JOIN %s r ON %s", rel(chk$left), rel(chk$right), join_on(chk$by)))
    res(chk$label %||% sprintf("no_fanout %s <- %s", chk$left$table, chk$right$table), "no_fanout",
        pass = n_join == n_left, n_bad = max(0, n_join - n_left), total = n_left,
        detail = sprintf("LEFT JOIN row count %s -> %s", fmi(n_left), fmi(n_join)))
  },
  no_row_loss = function(chk, con) {
    # Count left rows with NO match (LEFT ANTI JOIN) rather than comparing inner-join size: an INNER JOIN
    # can both DROP unmatched rows and FAN OUT matched ones, so equal counts don't prove no loss.
    n_left <- q1(con, sprintf("SELECT count(*) FROM %s l", rel(chk$left)))
    n_lost <- q1(con, sprintf("SELECT count(*) FROM %s l LEFT ANTI JOIN %s r ON %s", rel(chk$left), rel(chk$right), join_on(chk$by)))
    res(chk$label %||% sprintf("no_row_loss %s <- %s", chk$left$table, chk$right$table), "no_row_loss",
        pass = n_lost == 0, n_bad = n_lost, total = n_left,
        detail = sprintf("%s of %s left rows have no match in the right table", fmi(n_lost), fmi(n_left)))
  },
  derive_equals = function(chk, con) {
    pfq  <- fq(chk$product_source %||% "product", chk$product_table)
    rfq  <- fq(chk$raw$source, chk$raw$table); rkey <- chk$raw$key %||% chk$key
    if (!is.null(chk$raw$expr)) {                                   # value-mapping: raw side is assumed 1:1 on the key
      # The mapping subquery does NOT group, so a duplicated raw key fans the product row out in the LEFT JOIN
      # and a consistent-but-duplicated key can leave n_bad=0 without proving the intended 1:1 mapping. The
      # aggregate branch is immune (it GROUPs BY key). require_unique_raw=TRUE asserts raw-key uniqueness first.
      if (isTRUE(chk$require_unique_raw)) {
        dup <- q1(con, sprintf("SELECT count(*) FROM (SELECT %s FROM %s%s GROUP BY %s HAVING count(*) > 1)",
                               bt(rkey), rfq, whereof(chk$raw$filter), bt(rkey)))
        if (dup > 0)
          return(res(chk$label %||% sprintf("derive_equals %s == mapping", chk$product), "derive_equals",
                     pass = FALSE, n_bad = dup,
                     detail = sprintf("raw mapping key %s is not unique: %s duplicate key(s) — the 1:1 assumption fails", rkey, fmi(dup))))
      }
      rsub  <- sprintf("(SELECT %s AS k, %s AS rv FROM %s%s)", bt(rkey), chk$raw$expr, rfq, whereof(chk$raw$filter))
      rdesc <- "mapping"
    } else {                                                        # aggregate of a raw column, grouped by key
      agg <- tolower(chk$raw$agg)
      if (!agg %in% c("min", "max", "sum", "avg", "count"))
        stop(sprintf("derive_equals: unsupported agg '%s' (min/max/sum/avg/count) or set raw$expr", chk$raw$agg))
      rsub  <- sprintf("(SELECT %s AS k, %s(%s) AS rv FROM %s%s GROUP BY %s)", bt(rkey), agg, bt(chk$raw$col), rfq, whereof(chk$raw$filter), bt(rkey))
      rdesc <- sprintf("%s(%s)", agg, chk$raw$col)
    }
    # FAIL-CLOSED by default. `r.k IS NULL` (from the LEFT JOIN) is the UNMATCHED signal — keyed on the raw
    # KEY, not on value nullness, so a product row with a NULL value AND no raw match is still a violation
    # (a value-only test would let p.pv=NULL, r.rv=NULL slip through). `val_bad` is the matched-row mismatch:
    # exact = null-safe inequality; tolerance = one-side-null OR both present and beyond the band.
    # allow_unmatched=TRUE compares ONLY matched keys (unmatched product rows are not counted).
    # The "both present and beyond the band" clause. Both tolerance bands are FAIL-CLOSED on a non-null value
    # that fails to parse: its try_cast would be NULL, the diff would be NULL, and a NULL is not a violation —
    # so a garbage measure/date would silently pass the band. tolerance_days casts to date; tolerance casts to
    # double. (The exact path uses <=> and needs no cast.)
    diff_over <- if (!is.null(chk$tolerance_days))
                   sprintf("try_cast(p.pv AS date) IS NULL OR try_cast(r.rv AS date) IS NULL OR abs(datediff(try_cast(p.pv AS date), try_cast(r.rv AS date))) > %d", as.integer(chk$tolerance_days))
                 else if (!is.null(chk$tolerance))
                   sprintf("try_cast(p.pv AS double) IS NULL OR try_cast(r.rv AS double) IS NULL OR abs(try_cast(p.pv AS double) - try_cast(r.rv AS double)) > %s", chk$tolerance)
                 else NULL
    val_bad <- if (is.null(diff_over)) "NOT (p.pv <=> r.rv)"
               else sprintf("((p.pv IS NULL) <> (r.rv IS NULL)) OR (p.pv IS NOT NULL AND r.rv IS NOT NULL AND (%s))", diff_over)
    cmp <- if (isTRUE(chk$allow_unmatched)) sprintf("r.k IS NOT NULL AND (%s)", val_bad)
           else                             sprintf("r.k IS NULL OR (%s)", val_bad)
    nbad <- q1(con, sprintf(
      "SELECT count(*) FROM (SELECT %s AS k, %s AS pv FROM %s%s) p LEFT JOIN %s r ON p.k = r.k WHERE %s",
      bt(chk$key), bt(chk$product), pfq, whereof(chk$product_filter), rsub, cmp))
    tot  <- q1(con, sprintf("SELECT count(*) FROM %s%s", pfq, whereof(chk$product_filter)))
    res(chk$label %||% sprintf("derive_equals %s == %s", chk$product, rdesc), "derive_equals",
        pass = nbad == 0, n_bad = nbad, total = tot,
        detail = sprintf("%s of %s rows where %s != %s", fmi(nbad), fmi(tot), chk$product, rdesc))
  },
  bound = function(chk, con) {
    agg <- tolower(chk$agg %||% "max"); op <- chk$relation %||% "<="
    if (!op %in% c("<=", "<", ">=", ">", "=="))                    # reject a typo'd operator instead of silently using <=
      stop(sprintf("bound: unknown relation '%s' (<=, <, >=, >, ==)", op))
    if (!agg %in% c("min", "max", "sum", "avg"))                   # "count" would defeat the empty-data guard below
      stop(sprintf("bound: unsupported agg '%s' (min/max/sum/avg) — count() returns 0 (not NULL) on an empty relation, so it would silently pass 0<=0; use row_count for counts", chk$agg))
    # Cast BEFORE aggregating when the columns are numbers/dates stored as strings: max/min on a string
    # column are LEXICOGRAPHIC ("1000" < "95"), so a real out-of-range product value could pass. `cast` (e.g.
    # "double", "date", "decimal(38,6)") wraps each side in try_cast; default = no cast (native numeric/date).
    cst <- function(colexpr) if (nzchar(chk$cast %||% "")) sprintf("try_cast(%s AS %s)", colexpr, chk$cast) else colexpr
    # A cast aggregate SKIPS values that fail to parse (try_cast -> NULL, ignored by min/max/sum/avg), so a
    # bound can pass while some source values were invalid. require_valid=TRUE (with cast) additionally FAILS
    # if either side has a non-blank value that doesn't parse — same fail-closed intent as not_future/ordering.
    if (isTRUE(chk$require_valid) && nzchar(chk$cast %||% "")) {
      n_invalid <- function(spec) q1(con, sprintf(
        "SELECT count(*) FROM %s WHERE %s",
        fq(spec$source, spec$table),
        and_filter(sprintf("%s IS NOT NULL AND trim(cast(%s AS string)) <> '' AND try_cast(%s AS %s) IS NULL",
                           bt(spec$col), bt(spec$col), bt(spec$col), chk$cast), spec$filter)))
      np <- n_invalid(chk$product); nr <- n_invalid(chk$raw)
      if (np + nr > 0)
        return(res(chk$label %||% sprintf("bound %s(%s) %s %s(raw)", agg, chk$product$col, op, agg), "bound",
                   pass = FALSE, n_bad = np + nr,
                   detail = sprintf("%s product + %s raw value(s) don't parse as %s (the aggregate would silently skip them)", fmi(np), fmi(nr), chk$cast)))
    }
    if (is.null(chk$by)) {                                          # global bound: agg over the whole (filtered) sources
      pv <- q1(con, sprintf("SELECT %s(%s) FROM %s%s", agg, cst(bt(chk$product$col)), fq(chk$product$source, chk$product$table), whereof(chk$product$filter)))
      rv <- q1(con, sprintf("SELECT %s(%s) FROM %s%s", agg, cst(bt(chk$raw$col)),     fq(chk$raw$source, chk$raw$table),         whereof(chk$raw$filter)))
      if (is.na(pv) || is.na(rv))   # a NULL aggregate means no data to compare — not a pass, unless allow_empty
        return(res(chk$label %||% sprintf("bound %s(%s) %s %s(raw)", agg, chk$product$col, op, agg), "bound",
                   pass = isTRUE(chk$allow_empty), n_bad = if (isTRUE(chk$allow_empty)) 0 else 1,
                   detail = sprintf("no data to evaluate: %s(product)=%s, %s(raw)=%s (set allow_empty=TRUE to pass)", agg, fmt2(pv), agg, fmt2(rv))))
      ok <- switch(op, "<=" = pv <= rv, "<" = pv < rv, ">=" = pv >= rv, ">" = pv > rv, "==" = pv == rv)
      res(chk$label %||% sprintf("bound %s(%s) %s %s(raw)", agg, chk$product$col, op, agg), "bound",
          pass = ok, n_bad = if (ok) 0 else 1, detail = sprintf("%s(product)=%s %s %s(raw)=%s", agg, fmt2(pv), op, agg, fmt2(rv)))
    } else {
      # Per-key bound. FAIL-CLOSED by default: a key present on only one side, or with a NULL aggregate on
      # either side, counts as a violation (via FULL OUTER JOIN), so an unmatched key can't silently pass.
      # allow_unmatched=TRUE reverts to comparing only keys present-and-non-null on BOTH sides (inner join).
      pk <- chk$product$key %||% chk$by; rk <- chk$raw$key %||% chk$by
      jt   <- if (isTRUE(chk$allow_unmatched)) "JOIN" else "FULL OUTER JOIN"
      viol <- if (isTRUE(chk$allow_unmatched)) sprintf("NOT (p.v %s r.v)", op)
              else sprintf("p.v IS NULL OR r.v IS NULL OR NOT (p.v %s r.v)", op)
      nbad <- q1(con, sprintf(
        "SELECT count(*) FROM (SELECT %s AS k, %s(%s) AS v FROM %s%s GROUP BY %s) p %s (SELECT %s AS k, %s(%s) AS v FROM %s%s GROUP BY %s) r ON p.k = r.k WHERE %s",
        bt(pk), agg, cst(bt(chk$product$col)), fq(chk$product$source, chk$product$table), whereof(chk$product$filter), bt(pk),
        jt, bt(rk), agg, cst(bt(chk$raw$col)), fq(chk$raw$source, chk$raw$table),         whereof(chk$raw$filter), bt(rk), viol))
      res(chk$label %||% sprintf("bound per-key %s(%s) %s %s(raw)", agg, chk$product$col, op, agg), "bound",
          pass = nbad == 0, n_bad = nbad, detail = sprintf("%s keys unmatched or where %s(product) not %s %s(raw)", fmi(nbad), agg, op, agg))
    }
  },
  join_check = function(chk, con) {
    kind   <- toupper(chk$kind %||% "INNER")
    expect <- chk$expect %||% "no_violation"
    if (expect == "no_loss") {                                     # every left row must match (anti-join is offset-proof,
      n_left <- q1(con, sprintf("SELECT count(*) FROM %s l", rel(chk$left)))   # unlike an inner-join row-count compare)
      n_lost <- q1(con, sprintf("SELECT count(*) FROM %s l LEFT ANTI JOIN %s r ON %s", rel(chk$left), rel(chk$right), join_on(chk$by)))
      res(chk$label %||% sprintf("join_check %s <- %s (no_loss)", chk$left$table, chk$right$table), "join_check",
          pass = n_lost == 0, n_bad = n_lost, total = n_left,
          detail = sprintf("%s of %s left rows have no match", fmi(n_lost), fmi(n_left)))
    } else if (expect == "no_fanout") {                            # a LEFT JOIN never loses rows, so > left iff a left row matched >1 right
      n_left <- q1(con, sprintf("SELECT count(*) FROM %s l", rel(chk$left)))
      n_join <- q1(con, sprintf("SELECT count(*) FROM %s l LEFT JOIN %s r ON %s", rel(chk$left), rel(chk$right), join_on(chk$by)))
      res(chk$label %||% sprintf("join_check %s <- %s (no_fanout)", chk$left$table, chk$right$table), "join_check",
          pass = n_join == n_left, n_bad = max(0, n_join - n_left), total = n_left,
          detail = sprintf("LEFT JOIN row count %s -> %s", fmi(n_left), fmi(n_join)))
    } else {                                                        # predicate: no joined row may satisfy the violation predicate
      # `predicate` is authored verbatim and this verb does NOT validate operand parseability: if it casts
      # (e.g. try_cast(x AS date)), a non-null-but-unparseable value makes the predicate NULL and is NOT
      # counted. Make the predicate catch that itself (OR try_cast(x AS date) IS NULL) when it matters.
      joined <- sprintf("%s l %s JOIN %s r ON %s", rel(chk$left), kind, rel(chk$right), join_on(chk$by))
      nbad <- q1(con, sprintf("SELECT count(*) FROM %s WHERE %s", joined, chk$predicate))
      res(chk$label %||% sprintf("join_check %s <- %s", chk$left$table, chk$right$table), "join_check",
          pass = nbad == 0, n_bad = nbad, detail = sprintf("%d joined rows violate the predicate", nbad))
    }
  },
  expr = function(chk, con) {
    # expr runs arbitrary R with the live connection in scope — expert-only, and not structurally read-only.
    # A governed run can set QC_NO_EXPR=1 to reject every expr check instead of evaluating it. Parse it as an
    # explicit truthy value (1/true/yes/t) — the same way the other env flags parse — so a QC_NO_EXPR=0 or
    # =false does NOT silently disable every expr.
    if (tolower(Sys.getenv("QC_NO_EXPR", "")) %in% c("1", "true", "yes", "t"))
      return(res(chk$label %||% "expr", "expr", pass = FALSE, error = TRUE,
                 detail = "expr checks are disabled in this run (QC_NO_EXPR) — use declarative verbs"))
    load_src <- function(source, table) as_tibble(qdf(con, sprintf("SELECT * FROM %s", fq(source, table))))
    # Inject the query helpers an expr commonly uses (q1/qcol) so an expr resolves them regardless of how the
    # file was loaded — under `Rscript qc_runner.R` they're in globalenv, but under testthat::test_file the
    # file is sourced into a child env and would NOT be on this env's globalenv parent (a wired expr would
    # then error "could not find function q1"). Injecting them makes the expr hatch invocation-independent.
    env <- list2env(list(con = con, fq = fq, load = load_src, q1 = q1, qcol = qcol, qdf = qdf), parent = globalenv())
    val  <- suppressWarnings(as.numeric(eval(parse(text = chk$r), envir = env)))
    # Fail-closed on a malformed result: require EXACTLY ONE finite, non-negative number (a violation count).
    # A non-numeric, length-0, length>1 (e.g. c(0,5)), NA/Inf, or negative result is a CONFIG/expr error, not a
    # data failure — mark it error=TRUE so the coverage gate reports INCOMPLETE, not a misleading data-QC FAIL.
    okval <- length(val) == 1L && is.finite(val) && val >= 0
    res(chk$label %||% "expr", "expr", pass = okval && val == 0, n_bad = if (okval) val else NA, error = !okval,
        detail = if (okval) sprintf("expression returned %s violation(s)", fmi(val))
                 else sprintf("expression returned a malformed result (need one finite value >= 0; got length %d)", length(val)))
  },
  profile = function(chk, con) {
    s  <- CFG$sources[[chk$source]]
    # Catalog/schema are required in DBI mode (blank-required, so a mis-config can't silently profile the wrong
    # schema); local source_mode reads files from DC_LOCAL_DIR + DC_TABLES and ignores catalog/schema, so don't
    # force dummy values there — mirror the profiler, which only requires catalog/schema in DBI mode.
    local_mode <- identical(tolower(chk$source_mode %||% ""), "local")
    if (!local_mode && (is.null(s) || !nzchar(s$catalog %||% "") || !nzchar(s$schema %||% "")))
      return(res(chk$label %||% sprintf("profile %s", chk$source), "profile", pass = FALSE,
                 detail = sprintf("source '%s' is undefined or has a blank catalog/schema (DBI mode) — set CFG$sources$%s, or use source_mode='local'", chk$source, chk$source)))
    od <- file.path(out_dir, sprintf("profile_%s", chk$source))
    # system2(env=) ADDS to the child's environment, it doesn't replace it — so a DC_* still set in the
    # parent shell (a stray DC_NEW_ONLY=1 or DC_DEFINE_ONLY=1) would leak in and change the child's mode,
    # cut, or baseline. So set EVERY DC_* the profiler reads (unset -> "" so it uses its own default; flags
    # -> explicit 0/1); the CFG then fully controls the child run. Only the credentials (DATABRICKS_DSN/PWD)
    # are inherited on purpose.
    # SHELL-SAFE: system2 builds a /bin/sh string and does NOT quote these env values or args (only the
    # command is quoted), so a value with a space (DC_MISSING_TOKENS="Unknown,Not documented"), a regex char
    # (DC_CUT_REGEX="_(a|b)$"), or a path with spaces would break the launch — so shQuote each one.
    kv <- function(name, x) sprintf("%s=%s", name, shQuote(if (is.null(x)) "" else as.character(x)))  # unset -> '' (child default)
    fl <- function(x) if (isTRUE(x)) "1" else "0"                 # explicit boolean (never inherit)
    env <- c(
      kv("DC_CATALOG", s$catalog),          kv("DC_SCHEMA", s$schema),
      kv("DC_CUT", chk$cut),                kv("DC_TABLES", chk$tables),
      kv("DC_SAMPLE_N", chk$sample_n %||% "0"), kv("DC_SAMPLE_SEED", chk$sample_seed),
      kv("DC_TOPN", chk$top_n),             kv("DC_NUMERIC_CAT_MAX", chk$numeric_cat_max),
      kv("DC_SOURCE_MODE", chk$source_mode), kv("DC_LOCAL_DIR", chk$local_dir),
      kv("DC_BASELINE_COLS", chk$baseline),  kv("DC_PRODUCT_ID", chk$product_id),
      kv("DC_MISSING_TOKENS", chk$missing_tokens), kv("DC_KIND_OVERRIDES", chk$kind_overrides),
      kv("DC_CUT_REGEX", chk$cut_regex),    kv("DC_CUT_FILTER_REGEX", chk$cut_filter_regex),
      kv("DC_KNOWN_NEW_TABLES", chk$known_new_tables), kv("DC_KNOWN_NEW_COLS", chk$known_new_cols),
      kv("DC_INVENTORY_ONLY", fl(chk$inventory_only)), kv("DC_NEW_ONLY", fl(chk$new_only)),
      kv("DC_REQUIRE_BASELINE", fl(chk$require_baseline)),
      kv("DC_DEFINE_ONLY", ""),                     # ensure the child actually RUNS even if the parent set the parse-only guard
      kv("DC_OUT_DIR", od))
    st <- system2("Rscript", shQuote(abspath(CFG$profiler_script)), env = env, stdout = FALSE, stderr = FALSE)
    # A nonzero exit (Rscript missing, profiler error, bad path) is a FAILURE that must gate the run;
    # a clean exit is informational (non-gating) success.
    res(chk$label %||% sprintf("profile %s", chk$source), "profile",
        pass = if (st == 0) NA else FALSE, n_bad = if (st == 0) NA else 1, info = st == 0,
        detail = sprintf("data_profiler.R exit %d -> %s", st, od))
  },
  drift = function(chk, con) {
    # Drift needs COMPLETE profiles: a profile_new_<cut>.tsv is a partial (new-columns-only) profile and
    # would produce a bogus comparison, so reject it as a FAIL rather than silently drift a subset.
    bad_in <- grep("profile_new", c(chk$old, chk$new), value = TRUE)
    if (length(bad_in))
      return(res(chk$label %||% "drift", "drift", pass = FALSE, n_bad = 1,
                 detail = sprintf("partial profile input(s) %s — drift needs full profile_<cut>.tsv, not profile_new_*", paste(basename(bad_in), collapse = ", "))))
    # Unique per-check output folder (from `out`, else a slug of the label) so several drift checks in one
    # config don't overwrite each other's comparison in a single shared "drift" folder.
    slug <- if (!is.null(chk$out)) chk$out
            else if (!is.null(chk$label)) sprintf("drift_%s", gsub("[^a-z0-9]+", "_", tolower(chk$label)))
            else "drift"
    od <- file.path(out_dir, slug)
    # Clean child env, same policy as the profile handler: system2(env=) ADDS to the inherited environment,
    # so a CMP_* still set in the parent shell would leak in. A leaked CMP_DEFINE_ONLY is the dangerous one —
    # compare_snapshots.R quits status 0 the moment it sees it, WITHOUT reading a profile or writing a report,
    # which would score an un-run drift as info success. Leaked CMP_*_PTS/PCT/SMD would quietly shift the
    # thresholds. So clear the guard, pass old/new as CLI args (and blank the CMP_OLD/NEW fallbacks), and pin
    # every threshold from the check's CFG (unset -> "" so the child uses its own default).
    # SHELL-SAFE like the profile handler: shQuote each env value and path arg, since system2 doesn't quote
    # them and CMP_OUT / the profile paths can contain spaces (say a restricted-archive run folder).
    kv <- function(name, x) sprintf("%s=%s", name, shQuote(if (is.null(x)) "" else as.character(x)))
    env <- c(kv("CMP_OUT", od), kv("CMP_DEFINE_ONLY", ""), kv("CMP_OLD", ""), kv("CMP_NEW", ""),
             kv("CMP_MISS_PTS", chk$miss_pts),   kv("CMP_ROWS_PCT", chk$rows_pct),
             kv("CMP_DISTINCT_PCT", chk$distinct_pct), kv("CMP_SMD", chk$smd),
             kv("CMP_CAT_PTS", chk$cat_pts),     kv("CMP_CAT_MIN", chk$cat_min))
    st <- system2("Rscript", shQuote(c(abspath(CFG$compare_script), abspath(chk$old), abspath(chk$new))),
                  env = env, stdout = FALSE, stderr = FALSE)
    # A clean exit alone is not proof drift ran: confirm the report was actually written (guards against a
    # child that exits 0 without comparing, e.g. a leaked parse-only guard that slipped past the clear above).
    wrote <- file.exists(file.path(od, "snapshot_comparison.html"))
    ok <- st == 0 && wrote
    res(chk$label %||% "drift", "drift",
        pass = if (ok) NA else FALSE, n_bad = if (ok) NA else 1, info = ok,
        detail = if (ok) sprintf("compare_snapshots.R exit 0 -> %s", od)
                 else if (st == 0) sprintf("compare_snapshots.R exit 0 but wrote no report to %s (drift did not run)", od)
                 else sprintf("compare_snapshots.R exit %d -> %s", st, od))
  }
)

# A check still carrying a "<placeholder>" (an example copied from CFG$examples / a catalog entry but not
# yet edited) is a template, not a runnable check — skip it as an info row instead of running it and failing
# on a bogus name. Scan EVERY character value in the check recursively (nested left/right/raw/product/compare
# specs, plus filter, predicate, cut, old/new paths, and an expr `r` string), so a placeholder anywhere — not
# just in a table field — is caught. The pattern is an angle-bracketed IDENTIFIER (<product_tbl>, <cut>), so
# it never trips on a SQL operator (<, >, <=, >=, <>) or a spaced comparison like "birthyear < 1900".
# (Caveat: avoid Spark complex-type literals like array<int>/map<...> in a predicate — they would match; cast
# to scalar types instead.)
has_placeholder <- function(chk) {
  found <- FALSE
  scan <- function(x) {
    if (found) return(invisible())
    if (is.character(x)) { if (any(grepl("<[A-Za-z0-9_]+>", x))) found <<- TRUE }
    else if (is.list(x)) {
      # A `schema` manifest holds type strings like "array<int>" / "map<string,int>" that look like
      # placeholders but aren't — never scan it (the real placeholder, an unwired <table>, is elsewhere on chk).
      nm <- names(x)
      for (i in seq_along(x)) if (is.null(nm) || !identical(nm[i], "manifest")) scan(x[[i]])
    }
  }
  scan(chk)
  found
}

# ---- run every check (queries execute here, once) ----
run_checks <- function() {
  # Lazy connection: only open the DB when a check actually needs it, so a drift/profile-only run (which
  # shells out to child scripts) — or a config that's all placeholder templates — needs no DB credentials.
  cst <- new.env(); cst$tried <- FALSE; cst$val <- NULL
  conn <- function() { if (!cst$tried) { cst$tried <- TRUE; cst$val <- tryCatch(get_con(), error = function(e) e) }; cst$val }
  run_one <- function(chk) {
    h <- handlers[[chk$type]]
    # An unknown check type, a dead connection, and a handler crash are all EXECUTION errors (error=TRUE), not
    # data failures — the coverage gate reads them as an incomplete run, not a data verdict.
    if (is.null(h)) return(res(chk$label %||% chk$type, chk$type, pass = FALSE, error = TRUE,
                               detail = sprintf("unknown check type '%s'", chk$type)))
    if (has_placeholder(chk)) { r <- res(chk$label %||% chk$type, chk$type, info = TRUE,
                 detail = "template check — replace the placeholder <...> table name(s) in CFG before running")
      r$skipped <- TRUE; return(r) }
    needs_db <- !chk$type %in% c("profile", "drift")   # profile/drift shell out to child scripts; they don't use `con`
    con <- if (needs_db) conn() else NULL
    if (needs_db && inherits(con, "error"))
      return(res(chk$label %||% chk$type, chk$type, pass = FALSE, error = TRUE, detail = paste("no connection:", conditionMessage(con))))
    tryCatch(h(chk, con), error = function(e)
      res(chk$label %||% chk$type, chk$type, pass = FALSE, error = TRUE, detail = paste("error:", conditionMessage(e))))
  }
  # After the handler runs, copy the check's traceability metadata onto the result so the coverage gate and
  # generated traceability can key off it (a handler never has to carry these through).
  lapply(CFG$checks, function(chk) {
    q0 <- .qstat$n; t0 <- Sys.time()               # snapshot the query counter + clock around each check
    r  <- run_one(chk)
    r$elapsed_s   <- round(as.numeric(difftime(Sys.time(), t0, units = "secs")), 3)
    r$nqueries    <- .qstat$n - q0                  # DB reads this check issued (0 for a template-skip)
    r$ref_id      <- chk$ref_id %||% ""
    r$required    <- isTRUE(chk$required)
    r$disposition <- chk$disposition %||% ""
    if (is.null(r$skipped)) r$skipped <- FALSE
    r
  })
}

# ---- report ----
esc <- function(x) { x <- as.character(x); x <- gsub("&","&amp;",x,fixed=TRUE)
  x <- gsub("<","&lt;",x,fixed=TRUE); gsub(">","&gt;",x,fixed=TRUE) }
status_of <- function(r) if (isTRUE(r$info)) "info" else if (isTRUE(r$pass)) "pass" else "FAIL"

# ---- HTML report (stakeholder-facing); the MD output stays the complete technical record ----
qc_css <- '<style>
:root{
  --accent:#C4441C; --accent-bar:#F36633; --amber:#CA8A04; --amber-bg:#FEF3C7; --amber-ink:#8A6D09;
  --fail:#C8102E; --pass:#15803D;
  --ink:#2A1A47; --ink-2:#3F3A4A; --muted:#6B6A78; --faint:#A3A1AD;
  --line:#E7E3EF; --line-2:#D6D1E0; --surface:#FFFFFF; --page:#F2F0F7; --panel:#F8F6FB; --panel-edge:#ECE8F3; --track:#ECEAF2;
  --mono:ui-monospace,"Cascadia Code","Source Code Pro",Menlo,Consolas,monospace;
  --sans:system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
}
*{box-sizing:border-box}
body{font:15px/1.55 var(--sans);color:var(--ink-2);background:var(--page);margin:0;padding:28px}
.sheet{max-width:1180px;margin:0 auto;background:var(--surface);border:1px solid var(--line);border-radius:12px;box-shadow:0 1px 3px rgba(15,23,42,.06);padding:34px 38px 30px}
.eyebrow{font-size:11px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--accent);margin:0 0 4px}
h1{font-size:27px;line-height:1.15;font-weight:700;color:var(--ink);margin:0 0 8px;letter-spacing:-.01em}
h1 .verdict{font-size:14px;font-weight:700;letter-spacing:.04em;padding:3px 12px;border-radius:20px;vertical-align:4px;margin-left:8px}
h1 .verdict.pass{background:#DCFCE7;color:var(--pass);border:1px solid #86EFAC}
h1 .verdict.fail{background:#FEE2E2;color:var(--fail);border:1px solid #FCA5A5}
h1 .verdict.warn{background:var(--amber-bg);color:var(--amber-ink);border:1px solid #FCD34D}
.runmeta{display:flex;flex-wrap:wrap;gap:6px 14px;font-size:13px;color:var(--muted);margin:0 0 4px}
.runmeta b{color:var(--ink-2);font-weight:600}
.conf{display:inline-block;font-size:10.5px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--amber-ink);background:var(--amber-bg);border:1px solid #FCD34D;border-radius:5px;padding:2px 8px;margin-top:6px}
.covbar{display:flex;flex-wrap:wrap;align-items:center;gap:8px 14px;margin:14px 0 2px;padding:11px 15px;border:1px solid var(--line);border-left:3px solid var(--muted);border-radius:10px;background:var(--panel);font-size:13.5px;color:var(--ink-2)}
.covbar.ok{border-left-color:var(--pass)}.covbar.bad{border-left-color:var(--fail)}
.covstat{display:inline-flex;align-items:center;gap:7px}
.covstat .k{font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--muted)}
.covstat .v{font-size:12px;font-weight:700;letter-spacing:.03em;padding:2px 10px;border-radius:20px;white-space:nowrap}
.covstat .v.ok{background:#DCFCE7;color:var(--pass);border:1px solid #86EFAC}
.covstat .v.bad{background:#FEE2E2;color:var(--fail);border:1px solid #FCA5A5}
.covstat .v.warn{background:var(--amber-bg);color:var(--amber-ink);border:1px solid #FCD34D}
.covstat .v.neutral{background:#EEF0F5;color:#4B5563;border:1px solid #E3E1EA}
.covbar .covnote{flex-basis:100%;font-size:12px;color:var(--muted);margin:0}
h2{font-size:12px;font-weight:700;letter-spacing:.09em;text-transform:uppercase;color:var(--muted);margin:30px 0 12px;padding-bottom:7px;border-bottom:1px solid var(--line)}
.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:2px 0 4px}
.card{background:var(--panel);border:1px solid var(--panel-edge);border-left:3px solid var(--accent);border-radius:10px;padding:14px 16px}
.card.warn{border-left-color:var(--amber)}.card.fail{border-left-color:var(--fail)}.card.good{border-left-color:var(--pass)}
.card .val{font-size:30px;font-weight:700;color:var(--ink);line-height:1.05;letter-spacing:-.02em}
.card.fail .val{color:var(--fail)}.card.good .val{color:var(--pass)}
.card .lab{font-size:12.5px;font-weight:600;color:var(--ink-2);margin-top:3px}
.card .sub{font-size:11.5px;color:var(--muted);margin-top:2px}
.segbar{display:flex;height:12px;border-radius:6px;overflow:hidden;background:var(--track);max-width:520px;margin:12px 0 4px}
.segbar .seg{height:100%}
.segbar .pass{background:#22A559}.segbar .fail{background:var(--fail)}.segbar .info{background:#B9B7C4}
.seglegend{font-size:12px;color:var(--muted);margin:2px 0 0}
.seglegend .sw{display:inline-block;width:9px;height:9px;border-radius:2px;margin:0 3px 0 12px;vertical-align:0}.seglegend .sw:first-child{margin-left:0}
.table-wrap{width:100%;overflow-x:auto}
table{border-collapse:collapse;width:100%;margin:2px 0 6px;font-size:14px}
thead th{position:sticky;top:0;background:var(--panel);text-align:left;font-weight:600;color:var(--ink-2);font-size:12.5px;padding:9px 12px;border-bottom:2px solid var(--line-2);white-space:nowrap}
tbody td{padding:9px 12px;border-bottom:1px solid var(--line);vertical-align:top}
tbody tr:nth-child(even){background:#FBFAFC}
tbody tr:hover{background:#FAF5F1}
tr.fail td{background:#FEF6F6}tr.fail:hover td{background:#FDEEEE}
.badge{display:inline-block;font-size:11px;font-weight:700;letter-spacing:.03em;padding:2px 9px;border-radius:20px;white-space:nowrap}
.badge.fail{background:#FEE2E2;color:var(--fail);border:1px solid #FCA5A5}
.badge.pass{background:#DCFCE7;color:var(--pass);border:1px solid #86EFAC}
.badge.info{background:#EEF0F5;color:#4B5563;border:1px solid #E3E1EA}
.vtype{font-family:var(--mono);font-size:12.5px;color:var(--muted)}
.chk{color:var(--ink);font-weight:500}
.det{font-size:13px;color:var(--ink-2);white-space:normal;word-break:break-word}
.samp{color:var(--amber-ink);font-family:var(--mono);font-size:12px}
.panel{background:var(--panel);border:1px solid var(--panel-edge);border-radius:10px;padding:12px 16px;font-size:12.5px;color:var(--muted);margin-top:8px}
.panel b{color:var(--ink-2);font-weight:600}
.says{font-size:14.5px;color:var(--ink-2);margin:12px 0 2px}.says b{color:var(--ink);font-weight:700}
.allclear{background:#F0FBF3;border:1px solid #BBF7D0;border-left:3px solid var(--pass);border-radius:10px;padding:12px 16px;font-size:13.5px;color:var(--pass);margin:4px 0}.allclear b{font-weight:700}
tr.dimhead td{background:var(--panel);font-weight:700;color:var(--ink);font-size:11px;letter-spacing:.07em;text-transform:uppercase;padding:8px 12px;border-bottom:2px solid var(--line-2)}
tr.dimhead:hover td{background:var(--panel)}
td.num,th.num{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.z{color:var(--faint)}
.foot{display:flex;flex-wrap:wrap;justify-content:space-between;gap:8px;margin-top:26px;padding-top:14px;border-top:1px solid var(--line);font-size:11.5px;color:var(--faint)}
.foot b{color:var(--muted);font-weight:600}
.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
.printfoot{display:none}
@media (max-width:820px){.cards{grid-template-columns:repeat(2,1fr)}}
@media print{
  @page{size:A4 landscape;margin:12mm 12mm 15mm}
  *{-webkit-print-color-adjust:exact;print-color-adjust:exact}
  body{background:#fff;padding:0;font-size:10pt}
  .sheet{border:0;box-shadow:none;border-radius:0;max-width:none;padding:0}
  thead{display:table-header-group}
  tr,.card{break-inside:avoid}h2{break-after:avoid}
  .printfoot{display:block;position:fixed;bottom:0;left:0;right:0;font-size:8pt;color:var(--muted);border-top:1px solid var(--line);padding-top:3px;background:#fff}
}
</style>'
cards_html <- function(cards) paste0('<div class="cards">', paste(vapply(cards, function(c)
  sprintf('<div class="card%s"><div class="val">%s</div><div class="lab">%s</div><div class="sub">%s</div></div>',
    paste0(if (isTRUE(c$fail)) " fail" else "", if (isTRUE(c$good)) " good" else "", if (isTRUE(c$warn)) " warn" else ""),
    esc(c$val), esc(c$lab), esc(c$sub)), character(1)), collapse = ""), '</div>')
badge_html <- function(st) sprintf('<span class="badge %s">%s</span>', tolower(st), toupper(st))

# ---- QC dimensions ----
# Fold the ~16 check verbs into the handful of quality areas a reviewer actually reasons about, so the
# report reads as "which area is failing", not a flat list of verb names. Same idea as the drift report's
# change families: a stakeholder scans dimensions; the verb (the how) stays in the per-row Type column.
dim_of <- function(type) switch(type %||% "",
  row_count = "Volume",
  null_rate = "Completeness",
  domain =, schema =, not_future =, ordering =, rate = "Validity",
  unique_key =, referential =, no_fanout =, no_row_loss =, join_check = "Keys & integrity",
  derive_equals =, bound = "Reconciliation",
  profile =, drift = "Profiling & drift",
  expr = "Custom check",
  meta = "Run integrity",
  "Other")
DIM_LEVELS <- c("Volume", "Completeness", "Validity", "Keys & integrity", "Reconciliation",
                "Profiling & drift", "Custom check", "Run integrity", "Other")
# Failures first, then passes, then info — the ordering used inside every table.
rank_of <- function(r) if (status_of(r) == "FAIL") 0L else if (status_of(r) == "info") 2L else 1L
row_one <- function(r) sprintf(
  '<tr class="%s"><td>%s</td><td class="vtype">%s</td><td class="chk">%s</td><td class="det">%s%s</td></tr>',
  tolower(status_of(r)), badge_html(status_of(r)), esc(r$type), esc(r$label), esc(r$detail),
  if (nzchar(r$sample)) sprintf(' <span class="samp">[%s]</span>', esc(r$sample)) else "")

# One factual sentence under the cards — mirrors the stakeholder drift report: no adjectives, just counts.
# `incomplete` (execution INCOMPLETE per the coverage gate) qualifies a zero-failure run so the prose can't
# read as a clean pass when required checks were never evaluated.
says_line <- function(results, npass, nfail, ninfo, incomplete = FALSE) {
  n_assert <- npass + nfail
  if (nfail == 0 && incomplete)
    return(sprintf("All <b>%d</b> evaluated assertion%s passed, but the suite is <b>incomplete</b> — required checks were not evaluated, so no data-QC conclusion can be drawn (see the coverage banner).",
      n_assert, if (n_assert == 1) "" else "s"))
  if (nfail == 0)
    return(sprintf("All <b>%d</b> assertion%s passed%s.", n_assert, if (n_assert == 1) "" else "s",
      if (ninfo > 0) sprintf("; <b>%d</b> informational step%s ran (non-gating)", ninfo, if (ninfo == 1) "" else "s") else ""))
  fdims <- unique(vapply(Filter(function(r) rank_of(r) == 0L, results), function(r) dim_of(r$type), character(1)))
  where <- if (length(fdims) == 1) sprintf("all in <b>%s</b>", esc(fdims))
           else sprintf("across <b>%s</b>", esc(paste(fdims, collapse = ", ")))
  sprintf("<b>%d check%s failed</b> — %s. <b>%d</b> passed, <b>%d</b> informational.",
    nfail, if (nfail == 1) "" else "s", where, npass, ninfo)
}

render <- function(results, gen_time, cov = NULL) {
  npass <- sum(vapply(results, function(r) isTRUE(r$pass), logical(1)))
  nfail <- sum(vapply(results, function(r) !isTRUE(r$info) && !isTRUE(r$pass), logical(1)))
  ninfo <- sum(vapply(results, function(r) isTRUE(r$info), logical(1)))
  total <- npass + nfail + ninfo
  # Resolved source provenance in the report, so an archived HTML says which catalog.schema each end used.
  src_txt <- paste(vapply(names(CFG$sources), function(nm) { s <- CFG$sources[[nm]]
    sprintf("%s=%s.%s", nm, s$catalog %||% "?", if (nzchar(s$schema %||% "")) s$schema else "?") }, character(1)), collapse = " · ")
  verdict <- if (nfail > 0) "fail" else "pass"
  # Header pill. With a required inventory (coverage metadata present), three categories drive it in priority
  # order: a REQUIRED data failure (FAIL) > an INCOMPLETE execution (required checks skipped/errored/absent) >
  # optional (non-required) failures only (REVIEW) > PASS. So a clean required run where an enabled
  # build_pipeline check happens to fail reads as "REVIEW", not a bare FAIL, and a partial config never shows a
  # green PASS. Without an inventory (the OC default, nothing required) the pill stays the simple fail/pass.
  incomplete <- !is.null(cov) && identical(cov$execution_status, "INCOMPLETE")
  has_inv    <- !is.null(cov) && cov$required_total > 0
  # Optional (non-required) issues = an enabled build_pipeline check that failed on the data OR errored
  # (config error / crash). Both must reach the REVIEW branch, else a non-required error shows a green PASS
  # pill while the run still exits non-zero and lists the failure.
  opt_issues <- if (!is.null(cov)) (cov$optional_failed %||% 0L) + (cov$optional_errored %||% 0L) else 0L
  if (has_inv) {
    if (cov$required_failed > 0) { hverdict <- "fail"; hlabel <- "FAIL" }
    else if (incomplete)         { hverdict <- "warn"; hlabel <- "INCOMPLETE" }
    else if (opt_issues > 0)     { hverdict <- "warn"; hlabel <- "REVIEW" }
    else                         { hverdict <- "pass"; hlabel <- "PASS" }
  } else {
    hverdict <- if (nfail > 0) "fail" else "pass"
    hlabel   <- toupper(hverdict)
  }
  seg <- function(n, cls) if (total > 0 && n > 0) sprintf('<span class="seg %s" style="width:%.1f%%"></span>', cls, 100 * n / total) else ""
  segbar <- paste0('<div class="segbar">', seg(npass, "pass"), seg(nfail, "fail"), seg(ninfo, "info"), '</div>',
    '<p class="seglegend"><span class="sw" style="background:#22A559"></span>passed ', npass,
    '<span class="sw" style="background:var(--fail)"></span>failed ', nfail,
    '<span class="sw" style="background:#B9B7C4"></span>info ', ninfo, '</p>')
  cards <- cards_html(list(
    list(val = nfail, lab = "Failed", sub = "assertions not passing", fail = nfail > 0),
    list(val = npass, lab = "Passed", sub = "assertions held", good = npass > 0 && nfail == 0),
    list(val = ninfo, lab = "Info",   sub = "non-gating steps"),
    list(val = total, lab = "Checks", sub = "run this pass")))

  # Dimensions actually present, in canonical order (drops empty areas from every table below).
  all_dims     <- vapply(results, function(r) dim_of(r$type), character(1))
  dims_present <- DIM_LEVELS[DIM_LEVELS %in% all_dims]

  # Failures requiring attention — only the fails, ordered by dimension then label. The one section a
  # reviewer must read; empty -> a green all-clear note instead of an empty table.
  fails <- Filter(function(r) rank_of(r) == 0L, results)
  if (length(fails)) {
    ford <- order(match(vapply(fails, function(r) dim_of(r$type), character(1)), DIM_LEVELS),
                  tolower(vapply(fails, function(r) r$label, character(1))))
    fail_sec <- paste0('<h2>Failures requiring attention</h2>',
      '<div class="table-wrap"><table><caption class="sr-only">Failing checks</caption>',
      '<thead><tr><th scope="col">Status</th><th scope="col">Type</th><th scope="col">Check</th><th scope="col">Detail</th></tr></thead><tbody>',
      paste(vapply(fails[ford], row_one, character(1)), collapse = ""), '</tbody></table></div>')
  } else if (incomplete) {
    # Zero failures but the execution is INCOMPLETE: required checks were skipped/errored/absent, so this is
    # NOT a clean pass. Use the amber coverage style, not the green all-clear, and say so.
    fail_sec <- paste0('<h2>Failures requiring attention</h2>',
      sprintf('<div class="covbar bad"><span class="covstat"><span class="k">No failures, but incomplete</span></span><p class="covnote">All %d evaluated assertion%s passed, but required checks were not evaluated — see the coverage banner. No data-QC conclusion can be drawn.</p></div>',
        npass, if (npass == 1) "" else "s"))
  } else {
    fail_sec <- paste0('<h2>Failures requiring attention</h2>',
      sprintf('<div class="allclear"><b>No failures.</b> All %d assertion%s passed%s.</div>',
        npass, if (npass == 1) "" else "s",
        if (ninfo > 0) sprintf("; %d informational step%s ran", ninfo, if (ninfo == 1) "" else "s") else ""))
  }

  # Coverage by dimension — checks / passed / failed / info per quality area.
  cov_rows <- vapply(dims_present, function(d) {
    rs <- Filter(function(r) dim_of(r$type) == d, results)
    p  <- sum(vapply(rs, function(r) isTRUE(r$pass), logical(1)))
    f  <- sum(vapply(rs, function(r) rank_of(r) == 0L, logical(1)))
    i  <- sum(vapply(rs, function(r) isTRUE(r$info), logical(1)))
    z  <- function(n) if (n > 0) as.character(n) else '<span class="z">0</span>'
    sprintf('<tr%s><td class="chk">%s</td><td class="num">%d</td><td class="num">%s</td><td class="num">%s</td><td class="num">%s</td></tr>',
      if (f > 0) ' class="fail"' else "", esc(d), length(rs), z(p),
      if (f > 0) sprintf('<b>%d</b>', f) else '<span class="z">0</span>', z(i))
  }, character(1))
  cov_sec <- paste0('<h2>Coverage by dimension</h2>',
    '<div class="table-wrap"><table><caption class="sr-only">Check coverage by quality dimension</caption>',
    '<thead><tr><th scope="col">Dimension</th><th scope="col" class="num">Checks</th><th scope="col" class="num">Passed</th><th scope="col" class="num">Failed</th><th scope="col" class="num">Info</th></tr></thead><tbody>',
    paste(cov_rows, collapse = ""), '</tbody></table></div>')

  # All checks — the complete record, grouped by dimension with failures first inside each group.
  grouped <- unlist(lapply(dims_present, function(d) {
    rs  <- Filter(function(r) dim_of(r$type) == d, results)
    ord <- order(vapply(rs, rank_of, integer(1)), tolower(vapply(rs, function(r) r$label, character(1))))
    c(sprintf('<tr class="dimhead"><td colspan="4">%s</td></tr>', esc(d)),
      vapply(rs[ord], row_one, character(1)))
  }))
  all_sec <- paste0('<h2>All checks</h2>',
    '<div class="table-wrap"><table><caption class="sr-only">All QC checks grouped by dimension</caption>',
    '<thead><tr><th scope="col">Status</th><th scope="col">Type</th><th scope="col">Check</th><th scope="col">Detail</th></tr></thead><tbody>',
    paste(grouped, collapse = ""), '</tbody></table></div>')

  # Coverage banner — only when the config carries a `required` inventory (nothing required => no coverage
  # story, and forcing a green "COMPLETE" chip on an unannotated config would be noise). Separates whether the
  # suite RAN completely (execution) from what the data SAID (data QC), so a partial config can't read green.
  cov_html <- ""
  if (!is.null(cov) && cov$required_total > 0) {
    exec_ok <- cov$execution_status == "COMPLETE"
    dq      <- cov$data_qc_result
    dq_cls  <- if (dq == "PASS") "ok" else if (dq == "FAIL") "bad" else "warn"
    bits <- character(0)
    if (cov$required_skipped > 0)
      bits <- c(bits, sprintf("%d required check%s skipped — product table(s) not yet wired", cov$required_skipped,
                              if (cov$required_skipped == 1) "" else "s"))
    if (cov$required_errored > 0)
      bits <- c(bits, sprintf("%d required check%s errored", cov$required_errored, if (cov$required_errored == 1) "" else "s"))
    if (length(cov$absent_required))
      bits <- c(bits, sprintf("%d required test%s absent from the config: %s%s", length(cov$absent_required),
                              if (length(cov$absent_required) == 1) "" else "s",
                              esc(paste(utils::head(cov$absent_required, 8), collapse = ", ")),
                              if (length(cov$absent_required) > 8) ", …" else ""))
    note <- if (length(bits)) sprintf('<p class="covnote">%s.</p>', paste(bits, collapse = "; ")) else ""
    opt_iss <- (cov$optional_failed %||% 0L) + (cov$optional_errored %||% 0L)
    of_chip <- if (opt_iss > 0)
      sprintf('<span class="covstat"><span class="k">Additional findings</span><span class="v warn">%d optional check%s failed or errored</span></span>',
              opt_iss, if (opt_iss == 1) "" else "s") else ""
    cov_html <- paste0(
      sprintf('<div class="covbar %s">', if (exec_ok) "ok" else "bad"),
      sprintf('<span class="covstat"><span class="k">Execution</span><span class="v %s">%s</span></span>',
              if (exec_ok) "ok" else "bad", esc(cov$execution_status)),
      sprintf('<span class="covstat"><span class="k">Data QC</span><span class="v %s">%s</span></span>', dq_cls, esc(dq)),
      sprintf('<span class="covstat"><span class="k">Required</span><span class="v neutral">%d passed · %d failed · %d skipped</span></span>',
              cov$required_passed, cov$required_failed, cov$required_skipped),
      of_chip, note, '</div>')
  }

  # Slowest checks — surface the per-check timing/query counts we already capture, so a repeated-scan hotspot
  # shows up in the report itself. Only rendered when a run actually issued queries.
  timed <- Filter(function(r) (r$elapsed_s %||% 0) > 0 || (r$nqueries %||% 0L) > 0, results)
  perf_sec <- if (length(timed)) {
    top  <- timed[utils::head(order(vapply(timed, function(r) r$elapsed_s %||% 0, numeric(1)), decreasing = TRUE), 10)]
    prows <- paste(vapply(top, function(r) sprintf('<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>',
      esc(r$label), esc(r$type), fmt2(r$elapsed_s %||% NA), fmt2(r$nqueries %||% NA)), character(1)), collapse = "")
    paste0('<h2>Slowest checks</h2>',
      sprintf('<p class="says">%.1fs total across %d DB queries.</p>',
              sum(vapply(results, function(r) r$elapsed_s %||% 0, numeric(1))),
              sum(vapply(results, function(r) as.integer(r$nqueries %||% 0L), integer(1)))),
      '<div class="table-wrap"><table><caption class="sr-only">Slowest checks by elapsed time</caption>',
      '<thead><tr><th scope="col">Check</th><th scope="col">Type</th><th scope="col">Seconds</th><th scope="col">Queries</th></tr></thead><tbody>',
      prows, '</tbody></table></div>')
  } else ""

  ident <- sprintf("QC %s · generated %s", hlabel, esc(gen_time))
  html <- paste0('<!doctype html><html lang="en"><head><meta charset="utf-8">',
    '<meta name="viewport" content="width=device-width, initial-scale=1">',
    '<title>QC report</title>', qc_css, '</head><body><div class="sheet">',
    '<p class="eyebrow">Data quality</p>',
    sprintf('<h1>QC report <span class="verdict %s">%s</span></h1>', hverdict, hlabel),
    sprintf('<div class="runmeta"><span>sources <b>%s</b></span><span><b>%d</b> checks</span><span>generated <b>%s</b></span></div>', esc(src_txt), total, esc(gen_time)),
    '<span class="conf">Restricted RWD output</span>',
    cov_html,
    '<h2>Executive summary</h2>',
    cards, segbar,
    sprintf('<p class="says">%s</p>', says_line(results, npass, nfail, ninfo, incomplete)),
    fail_sec,
    cov_sec,
    perf_sec,
    all_sec,
    '<div class="panel"><b>Sources</b> — ', esc(src_txt),
    '. Status: <b>FAIL</b> gates the run (non-zero exit). A <em>successful</em> profile/drift/placeholder step is <b>info</b> (non-gating); a <em>failed</em> profile/drift subprocess is a FAIL.</div>',
    sprintf('<div class="foot"><span><b>QC report</b></span><span>Restricted RWD output · generated %s</span></div>', esc(gen_time)),
    '</div>', sprintf('<div class="printfoot">Restricted RWD output · %s</div>', ident), '</body></html>')

  ordr <- order(vapply(results, rank_of, integer(1)))
  cov_md <- if (!is.null(cov) && cov$required_total > 0) sprintf("\n**%s**\n", qc_coverage_line(cov)) else ""
  # Per-check timing/query volume in the technical record — the profiling input the reviews asked for (measure
  # before optimizing). Also a run-level total, so a repeated-scan hotspot is visible without a profiler.
  tot_s <- sum(vapply(results, function(r) r$elapsed_s %||% 0, numeric(1)))
  tot_q <- sum(vapply(results, function(r) as.integer(r$nqueries %||% 0L), integer(1)))
  md <- c(sprintf("# QC report\n\n%d passed · %d failed · %d info — generated %s\n\nsources: %s\n%s\ntiming: %.1fs total across %d DB queries\n",
      npass, nfail, ninfo, gen_time, src_txt, cov_md, tot_s, tot_q),
    "| status | dimension | type | check | detail | elapsed_s | queries |", "|---|---|---|---|---|---|---|",
    vapply(results[ordr], function(r) sprintf("| %s | %s | %s | %s | %s%s | %s | %s |", status_of(r), dim_of(r$type), r$type, r$label,
      gsub("|","\\|", r$detail, fixed = TRUE), if (nzchar(r$sample)) sprintf(" [%s]", gsub("|","\\|", r$sample, fixed=TRUE)) else "",
      fmt2(r$elapsed_s %||% NA), fmt2(r$nqueries %||% NA)), character(1)))
  list(html = html, md = paste(md, collapse = "\n"), npass = npass, nfail = nfail, ninfo = ninfo)
}

# ---- drive: report + exit code (Rscript), and register testthat cases when under a test runner ----
# Both outputs from one file: always writes the HTML/md report; registers a test_that per check so
# testthat::test_file collects them; exits non-zero on failure under Rscript (but never quits a
# testthat run). QC_DEFINE_ONLY=1 defines everything without connecting — a credential-free parse check.
run_all <- function() {
  results  <- run_checks()
  has_tt   <- requireNamespace("testthat", quietly = TRUE)
  under_tt <- has_tt && isTRUE(tryCatch(testthat::is_testing(), error = function(e) FALSE))
  dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)
  # No runnable assertion (only info/placeholder/empty results) is a failure unless explicitly allowed —
  # otherwise a mis-wired config would exit 0 without checking anything. Add the failure as a real result row
  # BEFORE rendering, so the report itself shows it (counts, exit code, and testthat then all stay aligned).
  allow_info_only <- tolower(getcfg("QC_ALLOW_INFO_ONLY", as.character(isTRUE(CFG$allow_info_only)))) %in% c("true","1","yes","t")
  n_assert <- sum(vapply(results, function(r) !isTRUE(r$info), logical(1)))
  if (n_assert == 0 && !allow_info_only)
    results <- c(results, list(res("qc_runner ran at least one assertion", "meta", pass = FALSE, n_bad = 1,
      detail = "no runnable pass/fail assertion ran (only info/placeholder/empty) — set QC_ALLOW_INFO_ONLY=1 to allow")))
  # Coverage gate: separate EXECUTION completeness from the DATA-QC verdict, so a partial config (required
  # checks placeholder-skipped) reports INCOMPLETE / NOT EVALUABLE instead of a false green. No-op for a
  # config whose checks carry no ref_id/required metadata (nothing required => always COMPLETE). Optional
  # registry (global QC_REGISTRY, a named ref_id->disposition vector) also flags required-but-absent tests.
  cov <- if (exists("qc_coverage_report", mode = "function")) {
    reg <- if (exists("QC_REGISTRY", envir = .GlobalEnv)) get("QC_REGISTRY", envir = .GlobalEnv) else NULL
    cv  <- qc_coverage_report(results, reg)
    if (!is.null(reg) && exists("qc_traceability_md", mode = "function"))
      writeLines(qc_traceability_md(results, reg, product_label = toupper(getcfg("QC_PRODUCT_LABEL", "PRODUCT"))),
                 file.path(out_dir, "qc_coverage_traceability.md"))
    cv
  } else NULL
  rep <- render(results, format(Sys.time(), "%Y-%m-%d %H:%M"), cov)
  writeLines(rep$html, file.path(out_dir, "qc_report.html"))
  writeLines(rep$md,   file.path(out_dir, "qc_report.md"))
  message(sprintf("QC: %d passed, %d failed, %d info -> %s", rep$npass, rep$nfail, rep$ninfo,
                  file.path(out_dir, "qc_report.html")))
  if (!is.null(cov) && cov$required_total > 0) message(qc_coverage_line(cov))  # only when a required inventory exists (silent for the OC default)
  if (has_tt) for (r in results) if (!isTRUE(r$info))
    testthat::test_that(r$label, testthat::expect_true(isTRUE(r$pass), info = r$detail))
  # Fail the run on a data failure OR an incomplete execution (required checks skipped/absent/errored).
  bad <- rep$nfail > 0 || (!is.null(cov) && cov$execution_status == "INCOMPLETE")
  if (!under_tt) quit(save = "no", status = if (bad) 1L else 0L)
  invisible(results)
}
if (!nzchar(Sys.getenv("QC_DEFINE_ONLY"))) run_all()
