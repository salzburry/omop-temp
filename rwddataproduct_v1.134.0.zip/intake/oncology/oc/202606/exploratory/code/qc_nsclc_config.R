# qc_nsclc_config.R — NSCLC data-product QC, built on the qc_runner.R generators. This one tumor file holds
# the delivered-product suite, the build-stage suite (bottom), and the full check inventory.
#
# WHAT THIS IS
# The NSCLC QC suite as a qc_runner config. Most checks are EMITTED and gating here (loops expanded
# per lab / biomarker / flag; product-referencing `expr` checks like 24.3, 42.4 are templated exprs that the
# recursive placeholder scan skips until P is wired). Everything that is NOT a delivered-product assertion —
# the §30-42 build-stage merge checks, the checks subsumed by 42.5, the one product-decision note (15.6),
# the broken/retired checks, and the one out-of-scope metadata test (42.8) — is listed, with a reason
# per id, in the inventory at the bottom (QC_REGISTRY — the single source of truth for each disposition).
#
# Run it against RWDE before trusting a green result.
#
# CONVENTIONS
# * Product keys on `patid`; raw keys on `patientid`. Every product<->raw reconciliation passes both
# (id/right_id, key/source_key, col/source_col, by=list(left=,right=)).
# * Raw table names are cut-resolved through rt: set NSCLC_CUT (e.g. "2026m06") and rt("t_demographics")
# -> "t_demographics_2026m06". Unset -> bare name (for a schema that exposes unsuffixed views).
# * P is the built product table; set NSCLC_PRODUCT_TBL to run. Left as <placeholder> otherwise, so every
# product-side check template-skips until wired (it never false-passes).
# * qc_run_nsclc.R sources qc_runner.R (engine + generators + coverage) then this file; use it to run.

CUT <- Sys.getenv("NSCLC_CUT", "")                                # e.g. "2026m06"; appended to raw tables
rt  <- function(t) if (nzchar(CUT)) paste0(t, "_", CUT) else t    # raw table name for the cut (bare if unset)
P   <- Sys.getenv("NSCLC_PRODUCT_TBL", "<nsclc_product>")         # built NSCLC analysis dataset (df)

# The EXACT expected cohort label set. 42.1 checks the count (5) AND the domain (these labels), so together
# they prove exact set equality — a product with 5 arbitrary labels can't pass count alone. Each tumor config
# supplies its own set (the cohort-nesting subset checks 31.6/31.7/31.8/42.7 rely on these exact strings).
NSCLC_COHORTS <- c("Overall advNSCLC", "L1 + treated advNSCLC", "L2 + treated advNSCLC",
                   "L3 + treated advNSCLC", "L1m + treated advNSCLC")

# The built product's required columns and their types — the schema manifest. FILL IN with the approved NSCLC
# product schema as column = type (e.g. patid = "string", indexdt = "date", bpsys = "double", biom = "int").
# When filled, 42.4 checks the EXACT column set (names + types), which is stronger than a bare column count and
# catches a dropped column swapped for an unrelated one. Left empty, 42.4 falls back to the column COUNT
# (NSCLC_EXPECTED_NCOL). Each tumor supplies its own manifest — product schemas differ by tumor.
NSCLC_COLUMNS <- list(
  # patid = "string", cohort = "string", cohortn = "int", indexdt = "date",
  # bpsys = "double", bpdia = "double", bpdt = "date", biom = "int",
  # ...  <-- FILL IN the full approved column -> type list here (then 42.4 upgrades to the schema check)
)

NSCLC_CHECKS <- c(

  # ===== non-empty guards: a raw table a rule check reads must have rows FIRST, else domain / ordering /
  # not_future count 0 bad rows and pass vacuously on an empty feed ==
  # Left UNTAGGED (ref_id="", required=FALSE): supporting guards, not gating checks. Split into MANDATORY
  # (must be non-empty — an empty feed is a real problem) and OPTIONAL (can legitimately be empty for a
  # tumor/cut — telemedicine, baseline ECOG, SES, medication order/admin). Optional guards are INFORMATIONAL
  # (report the row count, non-gating) so an empty optional source doesn't fail the run; a rule check on an
  # empty optional table then passes vacuously, which is right when the table is legitimately absent.
  lapply(c("t_demographics", "t_practice", "t_lineoftherapy", "t_drugepisode",
           "t_enh_advnsclcbioma", "t_lab", "t_vitals", "t_visit", "t_ecog",
           "t_enh_mortality_v2", "t_enh_advnsclcprogr", "t_enh_advnsclc_oral"),
         function(t) .chk(type = "row_count", source = "raw", table = rt(t), min = 1,
                          label = sprintf("%s has rows", t))),
  lapply(c("t_telemedicine", "t_baseline_ecog", "t_socdetofhealth", "t_medicationorder", "t_medicationadmin"),
         function(t) .chk(type = "row_count", source = "raw", table = rt(t), informational = TRUE,
                          label = sprintf("%s row count (optional source)", t))),

  # ===== §14 raw cohort t_enh_advancednsclc =====================================================
  # tag(ref_id, checks) stamps each emitted check with its id + required flag; the coverage gate in qc_runner.R
  # then reports INCOMPLETE if any required check is placeholder-skipped, errored, or absent.
  tag("14.6", product_identity(rt("t_enh_advancednsclc"), source = "raw")),                     # 14.6 rows + patientid non-null + unique
  tag("14.1", reconcile_referential(P, rt("t_enh_advancednsclc"), id = "patid", right_id = "patientid")), # 14.1 final patients in raw
  tag("14.2", product_completeness(rt("t_enh_advancednsclc"), "advanceddiagnosisdate", source = "raw")),  # 14.2 non-null
  tag("14.3", product_ordering(rt("t_enh_advancednsclc"), "diagnosisdate", "advanceddiagnosisdate", source = "raw")), # 14.3
  tag("14.4", product_domain(rt("t_enh_advancednsclc"), "histology",
                 allowed = c("Squamous cell carcinoma", "Non-squamous cell carcinoma", "NSCLC histology NOS"),
                 source = "raw")),                                                              # 14.4
  tag("14.5", product_domain(rt("t_enh_advancednsclc"), "smokingstatus",
                 allowed = c("History of smoking", "No history of smoking", "Unknown/Not documented"),
                 source = "raw")),                                                              # 14.5 (exact casing)
  tag("14.7", product_not_future(rt("t_enh_advancednsclc"), "advanceddiagnosisdate", source = "raw")),    # 14.7
  tag("14.8", reconcile_agg("patid", P, "init", rt("t_enh_advancednsclc"), "diagnosisdate", "min", source_key = "patientid", tolerance_days = 0)), # 14.8 (compare as dates)

  # ===== §15 demographics =======================================================================
  # 30.1 raw t_demographics is 1:1 on patientid — a real raw uniqueness check, unlike the 30.2+ build
  # aggregations that are unique by construction; an agg can hide a duplicate raw demographics row:
  tag("30.1", list(.chk(type = "unique_key", source = "raw", table = rt("t_demographics"), keys = "patientid",
    label = "30.1 raw t_demographics is 1:1 on patientid"))),
  tag("15.1", reconcile_referential(P, rt("t_demographics"), id = "patid", right_id = "patientid")),      # 15.1
  tag("15.2", product_domain(rt("t_demographics"), "birthsex", allowed = c("F", "M"), source = "raw")),   # 15.2 (NULL passes)
  tag("15.3", product_valid_range(rt("t_demographics"), "birthyear", lo = 1900, hi = "year(current_date())", cast = "int",
    source = "raw", label = "birthyear valid year in [1900, current]"), disposition = "corrected"),       # 15.3 parse-safe
  tag("15.4", reconcile_mapping("patid", P, "gender", rt("t_demographics"), source_key = "patientid",     # 15.4 gender mapping
    source_expr = "CASE WHEN upper(birthsex)='F' THEN 'Female' WHEN upper(birthsex)='M' THEN 'Male' ELSE 'Missing' END")),
  tag("15.5", reconcile_window(P, product_keys = c("patid", "indexdt", "age"), source_tbl = rt("t_demographics"), # 15.5 (mixes product+raw)
    by = list(left = "patid", right = "patientid"),
    predicate = "abs(try_cast(l.age AS int) - (year(try_cast(l.indexdt AS date)) - try_cast(r.birthyear AS int))) > 1",
    label = "age within 1 of year(indexdt) - birthyear")),
  # 15.6 "brthdt matches raw birthyear" is a YEAR match (date vs year) -> join_check on year(brthdt)=birthyear,
  # not a date-vs-year derive_equals (which would always fail). Left as a note; wire when brthdt is confirmed.

  # ===== §16 practice ===========================================================================
  tag("16.1", product_predicate(rt("t_practice"), predicate = "upper(practicetype) NOT IN ('ACADEMIC','COMMUNITY')",
    label = "practicetype in ACADEMIC/COMMUNITY (case-insensitive)", source = "raw"), disposition = "corrected"), # 16.1
  tag("16.2", product_domain(P, "practic", allowed = c("Academic", "Community", "Both academic and community", "Missing")), disposition = "corrected"), # 16.2
  # 16.3 / 16.4 practic == per-patient AGGREGATE of a CASE over raw practicetype rows — a per-key CASE-aggregate
  # no declarative verb expresses, so written as an expr. Template-skips until P is wired.
  tag("16.3", list(.chk(type = "expr", label = "16.3 all-ACADEMIC patients have practic='Academic'",
    r = sprintf('q1(con, sprintf("SELECT count(*) FROM %%s p INNER JOIN (SELECT patientid FROM %%s GROUP BY patientid HAVING min(CASE WHEN upper(practicetype) = \'ACADEMIC\' THEN 1 ELSE 0 END) = 1) a ON p.patid = a.patientid WHERE p.practic <> \'Academic\'", fq("product","%s"), fq("raw","%s")))',
      P, rt("t_practice"))))),
  tag("16.4", list(.chk(type = "expr", label = "16.4 patients with both ACADEMIC and COMMUNITY have practic='Both academic and community'",
    r = sprintf('q1(con, sprintf("SELECT count(*) FROM %%s p INNER JOIN (SELECT patientid FROM %%s GROUP BY patientid HAVING max(CASE WHEN upper(practicetype) = \'ACADEMIC\' THEN 1 ELSE 0 END) = 1 AND max(CASE WHEN upper(practicetype) = \'COMMUNITY\' THEN 1 ELSE 0 END) = 1) b ON p.patid = b.patientid WHERE p.practic <> \'Both academic and community\'", fq("product","%s"), fq("raw","%s")))',
      P, rt("t_practice"))))),

  # ===== §17 line of therapy ====================================================================
  tag("17.1", product_predicate(rt("t_lineoftherapy"), predicate = "upper(ismaintenancetherapy) NOT IN ('TRUE','FALSE')", # 17.1
    label = "ismaintenancetherapy in TRUE/FALSE (case-insensitive)", source = "raw"), disposition = "corrected"),
  tag("17.2", product_predicate(rt("t_lineoftherapy"),                                           # 17.2 (ignore NULL; reject 1.5)
    predicate = "linenumber IS NOT NULL AND (try_cast(linenumber AS int) IS NULL OR try_cast(linenumber AS int) < 1 OR try_cast(linenumber AS double) <> try_cast(linenumber AS int))",
    label = "linenumber is a positive integer (non-null rows)", source = "raw"), disposition = "corrected"),
  tag("17.3", product_ordering(rt("t_lineoftherapy"), "startdate", "enddate", source = "raw")),  # 17.3
  tag("17.5", reconcile_agg("patid", P, "lot1sd", rt("t_lineoftherapy"), "startdate", "min", source_key = "patientid", # 17.5
    filter = "linenumber = 1 AND enhancedcohort = 'AdvancedNSCLC' AND upper(ismaintenancetherapy) = 'FALSE'",
    product_filter = "lot1sd IS NOT NULL", tolerance_days = 0, allow_unmatched = TRUE), disposition = "corrected"), # skip null lot1sd, compare as dates
  # NOTE: 17.6 raw max(linenumber) has NO enhancedcohort filter (max over ALL raw LOT rows); the
  # enhancedcohort='AdvancedNSCLC' scope kept here is intentionally less strict — confirm product lotn's scope.
  # 17.6 lotn == max raw linenumber over ALL raw LOT lines (per the product definition, confirmed — no cohort
  # filter). product_filter=lotn>0 + allow_unmatched reproduce the source-row filter and
  # inner-join scope.
  tag("17.6", reconcile_agg("patid", P, "lotn", rt("t_lineoftherapy"), "linenumber", "max", source_key = "patientid", # 17.6
    product_filter = "lotn > 0", allow_unmatched = TRUE)),
  # 17.7 lot1 treatment NAME exists in raw LOT1 (composite patid/lot1 -> patientid/linename, differing keys):
  tag("17.7", list(.chk(type = "referential",                                                    # 17.7
    left  = list(source = "product", table = P, col = c("patid", "lot1"),
                 filter = "lot1 <> 'No Treatment' AND cohort = 'L1 + treated advNSCLC'"),
    right = list(source = "raw", table = rt("t_lineoftherapy"), col = c("patientid", "linename"),
                 filter = "linenumber = 1 AND enhancedcohort = 'AdvancedNSCLC'"),
    label = "17.7 lot1 treatment name exists in raw LOT1 (AdvancedNSCLC)"))),
  # 17.8 lot1plat 0/1 flag == "exists in filtered raw platinum LOT1", absence => 0, BOTH directions. This is
  # the corrected flag-equals-exists form:
  # lot1plat must equal (1 if the patient has a raw platinum non-maint LOT1, else 0).
  tag("17.8", list(.chk(type = "expr", label = "17.8 lot1plat flag agrees with raw platinum LOT1 existence",
    r = sprintf('q1(con, sprintf("SELECT count(*) FROM %%s p LEFT JOIN (SELECT DISTINCT patientid FROM %%s WHERE linenumber = 1 AND enhancedcohort = \'AdvancedNSCLC\' AND upper(ismaintenancetherapy) = \'FALSE\' AND upper(linename) RLIKE \'PLATIN\') r ON p.patid = r.patientid WHERE p.lot1plat <> (CASE WHEN r.patientid IS NOT NULL THEN 1 ELSE 0 END)", fq("product","%s"), fq("raw","%s")))',
      P, rt("t_lineoftherapy")))), disposition = "corrected"),

  # ===== §18 drug episode =======================================================================
  tag("18.1", product_not_future(rt("t_drugepisode"), "episodedate", source = "raw")),           # 18.1
  tag("18.2", product_ordering(rt("t_drugepisode"), "linestartdate", "lineenddate", source = "raw")),     # 18.2
  tag("18.3", product_ordering(rt("t_drugepisode"), "linestartdate", "episodedate", source = "raw")),     # 18.3
  tag("18.4", reconcile_agg("patid", P, "lot1ed", rt("t_drugepisode"), "episodedate", "max", source_key = "patientid", # 18.4
    filter = "linenumber = 1 AND enhancedcohort = 'AdvancedNSCLC' AND upper(ismaintenancetherapy) = 'FALSE'",
    product_filter = "lot1ed IS NOT NULL", tolerance_days = 0, allow_unmatched = TRUE), disposition = "corrected"), # skip null lot1ed, compare as dates
  # 18.5 lot1med == max maintenance LOT1 episodedate (product_filter + allow_unmatched skip a
  # null/unmatched lot1med so it is not flagged):
  tag("18.5", reconcile_agg("patid", P, "lot1med", rt("t_drugepisode"), "episodedate", "max", source_key = "patientid", # 18.5
    filter = "linenumber = 1 AND enhancedcohort = 'AdvancedNSCLC' AND upper(ismaintenancetherapy) = 'TRUE' AND episodedate IS NOT NULL",
    product_filter = "lot1med IS NOT NULL", tolerance_days = 0, allow_unmatched = TRUE), disposition = "corrected"),

  # ===== §19 biomarkers =========================================================================
  tag("19.1", product_not_future(rt("t_enh_advnsclcbioma"), c("resultdate", "specimenreceiveddate"), source = "raw")), # 19.1
  # 19.2 <20% of biomarker rows are tested (result/specimen date present) but have blank status:
  tag("19.2", product_predicate(rt("t_enh_advnsclcbioma"),                                       # 19.2
    "(resultdate IS NOT NULL OR specimenreceiveddate IS NOT NULL) AND (biomarkerstatus IS NULL OR trim(biomarkerstatus) = '')",
    "19.2 <20% biomarker rows tested-but-missing status", max_pct = 20, source = "raw", strict = TRUE)),
  # 19.3 biomarker window: compares the LATER of result/specimen date to indexdt + 14, restricted to
  # the biomarker names the product actually uses (ALK/ROS1/EGFR/BRAF/KRAS/MET/RET/HER2/ERBB2/PDL1 + NTRK).
  # source_filter applies that restriction. NTRK is matched by prefix (LIKE 'NTRK%') to
  # agree with 19.4 — this is the corrected form (a '^ntrk' pattern would be a no-op LIKE).
  tag("19.3", reconcile_window(P, product_keys = c("patid", "indexdt"), source_tbl = rt("t_enh_advnsclcbioma"), # 19.3
    by = list(left = "patid", right = "patientid"),
    source_filter = "upper(biomarkername) IN ('ALK','ROS1','EGFR','BRAF','KRAS','MET','RET','HER2/ERBB2','PDL1') OR upper(biomarkername) LIKE 'NTRK%'",
    predicate = "greatest(try_cast(r.resultdate AS date), try_cast(r.specimenreceiveddate AS date)) > date_add(try_cast(l.indexdt AS date), 14)",
    label = "biomarker (later of result/specimen date) <= indexdt + 14"), disposition = "corrected"),
  # 19.4 each final biomarker result (Positive/Negative/Unknown) has a supporting raw record for that marker:
  tag("19.4", lapply(list(list(v="alk",nm="ALK"), list(v="egfr",nm="EGFR"), list(v="braf",nm="BRAF"), list(v="ros1",nm="ROS1"),
              list(v="kras",nm="KRAS"), list(v="met",nm="MET"), list(v="ret",nm="RET"), list(v="ntrk",nm="NTRK"),
              list(v="her2",nm="HER2/ERBB2")),
    function(b) .chk(type = "referential",                                                       # 19.4
      left  = list(source = "product", table = P, col = "patid",
                   filter = sprintf("%s IN ('Positive','Negative','Unknown')", b$v)),
      right = list(source = "raw", table = rt("t_enh_advnsclcbioma"), col = "patientid",
                   filter = if (b$nm == "NTRK") "upper(biomarkername) LIKE 'NTRK%'"
                            else sprintf("upper(biomarkername) = '%s'", b$nm)),
      label = sprintf("19.4 %s final result has supporting raw biomarker record", b$nm)))),
  # 33.6 product patients whose composite biomarker class is 'Unknown/Missing' (alkc/egfrc/brafc) exist in the
  # raw biomarker table (a DISTINCT population from 19.4's alk/egfr/braf Positive/Negative/Unknown):
  tag("33.6", list(.chk(type = "referential",
    left  = list(source = "product", table = P, col = "patid",
                 filter = "alkc = 'Unknown/Missing' OR egfrc = 'Unknown/Missing' OR brafc = 'Unknown/Missing'"),
    right = list(source = "raw", table = rt("t_enh_advnsclcbioma"), col = "patientid"),
    label = "33.6 Unknown/Missing biomarker patients exist in raw biomarker table"))),

  # ===== §20 labs ===============================================================================
  tag("20.2", product_not_future(rt("t_lab"), c("resultdate", "testdate"), source = "raw")),     # 20.2
  # 20.3 every raw lab row has a resultdate or a testdate:
  tag("20.3", product_predicate(rt("t_lab"), "resultdate IS NULL AND testdate IS NULL",          # 20.3
    "20.3 lab record has a resultdate or testdate", max_pct = 0, source = "raw")),
  # 20.4 each final lab-max variable <= the raw max for its testbasename (10 labs):
  tag("20.4", lapply(list(
    list(col = "labneuv", tb = "NEUTROPHILS"),               list(col = "labplav", tb = "PLATELETS"),
    list(col = "labhemv", tb = "HEMOGLOBIN"),                list(col = "labcrev", tb = "CREATININE"),
    list(col = "labbilv", tb = "BILIRUBIN"),                 list(col = "labastv", tb = "ASPARTATE AMINOTRANSFERASE"),
    list(col = "labaltv", tb = "ALANINE AMINOTRANSFERASE"),  list(col = "labalpv", tb = "ALKALINE PHOSPHATASE"),
    list(col = "lablymv", tb = "LYMPHOCYTES"),               list(col = "labalbv", tb = "ALBUMIN")
  ), function(l) reconcile_bound(P, l$col, rt("t_lab"), "testresultcleaned", agg = "max", cast = "double", # 20.4
       filter = sprintf("upper(testbasename) = '%s'", l$tb), allow_empty = TRUE)[[1]])),  # null raw max passes
  # 20.5 all 10 expected lab testbasenames are present in raw -> one row_count(min=1) per name:
  tag("20.5", lapply(c("NEUTROPHILS", "PLATELETS", "HEMOGLOBIN", "CREATININE", "BILIRUBIN", "ASPARTATE AMINOTRANSFERASE",
           "ALANINE AMINOTRANSFERASE", "ALBUMIN", "LYMPHOCYTES", "ALKALINE PHOSPHATASE"),        # 20.5
    function(nm) .chk(type = "row_count", source = "raw", table = rt("t_lab"), min = 1,
      filter = sprintf("upper(testbasename) = '%s'", nm), label = sprintf("lab '%s' present", nm)))),

  # ===== §21-22 vitals / visits =================================================================
  tag("21.3", reconcile_bound(P, "weight", rt("t_vitals"), "testresultcleaned", agg = "max", cast = "double", # 21.3 (BODY WEIGHT in KG)
    filter = "upper(test) = 'BODY WEIGHT' AND upper(testunitscleaned) = 'KG'", allow_empty = TRUE), disposition = "corrected"), # null raw max passes
  # 21.5: bad_pairs / n_sys < 1% (STRICT), where the denominator is the count of SYSTOLIC
  # records (not the join). The generic rate join would divide by matched pairs, so this is an expr with the
  # systolic-record denominator + strict comparison. Raw-only (no product side), so it runs without P.
  tag("21.5", list(.chk(type = "expr", label = "21.5 <1% of systolic BP records have a same-date diastolic >= systolic",  # 21.5
    r = sprintf('{ v <- fq("raw","%s"); sysf <- "upper(test) = \'SYSTOLIC BLOOD PRESSURE\' AND testdate IS NOT NULL AND testresultcleaned IS NOT NULL"; diaf <- "upper(test) = \'DIASTOLIC BLOOD PRESSURE\' AND testdate IS NOT NULL AND testresultcleaned IS NOT NULL"; n_sys <- q1(con, paste0("SELECT count(*) FROM ", v, " WHERE ", sysf)); n_bad <- q1(con, paste0("SELECT count(*) FROM (SELECT patientid, testdate, testresultcleaned FROM ", v, " WHERE ", sysf, ") s INNER JOIN (SELECT patientid, testdate, testresultcleaned FROM ", v, " WHERE ", diaf, ") d ON s.patientid = d.patientid AND s.testdate = d.testdate WHERE try_cast(d.testresultcleaned AS double) >= try_cast(s.testresultcleaned AS double)")); if (n_sys > 0 && n_bad / n_sys >= 0.01) 1L else 0L }', rt("t_vitals")))), disposition = "corrected"),
  tag("22.3", reconcile_bound(P, "last_visit_date", rt("t_visit"), "visitdate", agg = "max", cast = "date", allow_empty = TRUE)), # 22.3 (null raw max passes)

  # ===== §24 ECOG windowed existence (templated expr — skips until P is wired) ===================
  # 24.3 every final-ECOG patient has a raw ECOG within [indexdt-30, indexdt+7]. The left is
  # the DISTINCT (patid, indexdt) of product patients whose product `ecog` is populated
  # and not 'Unknown'; the right is the UNION of raw t_ecog and t_baseline_ecog; a LEFT JOIN with the window
  # in the ON clause + WHERE r.patientid IS NULL counts patients with no in-window raw ECOG. Emitted as an
  # expr: the r string carries P (<nsclc_product>), so the recursive has_placeholder scan skips it until
  # NSCLC_PRODUCT_TBL is set. The inner sprintf's %s (escaped %%s here) resolve fq at run time.
  tag("24.3", list(.chk(type = "expr", label = "24.3 every final-ECOG patient has a raw ECOG within [indexdt-30, indexdt+7]",
    r = sprintf('q1(con, sprintf("SELECT count(*) FROM (SELECT DISTINCT patid, indexdt FROM %%s WHERE ecog IS NOT NULL AND ecog <> \'Unknown\') l LEFT JOIN (SELECT patientid, ecogdate FROM %%s UNION ALL SELECT patientid, ecogdate FROM %%s) r ON l.patid = r.patientid AND try_cast(r.ecogdate AS date) BETWEEN date_add(try_cast(l.indexdt AS date), -30) AND date_add(try_cast(l.indexdt AS date), 7) WHERE r.patientid IS NULL", fq("product","%s"), fq("raw","%s"), fq("raw","%s")))',
      P, rt("t_ecog"), rt("t_baseline_ecog"))))),

  # ===== §25 mortality ==========================================================================
  # 25.1 dthfl=1 only for patients with a raw mortality record that has a non-null dateofdeath:
  tag("25.1", reconcile_referential(P, rt("t_enh_mortality_v2"), id = "patid", right_id = "patientid",    # 25.1
    left_filter = "dthfl = 1", right_filter = "dateofdeath IS NOT NULL")),
  tag("25.2", product_predicate(rt("t_enh_mortality_v2"),                                        # 25.2 (raw dateofdeath length)
    predicate = "dateofdeath IS NOT NULL AND trim(cast(dateofdeath AS string)) <> '' AND length(cast(dateofdeath AS string)) NOT IN (4,7,10)",
    label = "raw dateofdeath length in {4,7,10}", source = "raw"), disposition = "corrected"),
  # 25.3 month-year deaths (raw length 7) imputed to day 15 or month-end:
  tag("25.3", list(.chk(type = "join_check", kind = "inner",                                     # 25.3
    left  = list(source = "product", table = P, select = c("patid", "dthdt"), filter = "dthfl = 1 AND dthdt IS NOT NULL"),
    right = list(source = "raw", table = rt("t_enh_mortality_v2"), filter = "dateofdeath IS NOT NULL AND length(dateofdeath) = 7"),
    by = list(left = "patid", right = "patientid"),
    predicate = "dayofmonth(try_cast(l.dthdt AS date)) <> 15 AND dayofmonth(try_cast(l.dthdt AS date)) <> dayofmonth(last_day(try_cast(l.dthdt AS date)))",
    label = "25.3 month-year deaths imputed to day 15 or month-end"))),
  # 25.4 dthdt year == raw dateofdeath year (year match tolerates the 25.3 day imputation):
  tag("25.4", list(.chk(type = "join_check", kind = "inner",                                     # 25.4
    left  = list(source = "product", table = P, select = c("patid", "dthdt"), filter = "dthfl = 1 AND dthdt IS NOT NULL"),
    right = list(source = "raw", table = rt("t_enh_mortality_v2")),
    by = list(left = "patid", right = "patientid"),
    predicate = "year(try_cast(l.dthdt AS date)) <> try_cast(substr(r.dateofdeath, 1, 4) AS int)",
    label = "25.4 dthdt year == raw dateofdeath year"))),

  # ===== §26 progression ========================================================================
  tag("26.3", product_not_future(rt("t_enh_advnsclcprogr"), "progressiondate", source = "raw")), # 26.3
  # 26.4 pfsdt == min real progressiondate for PFS-event patients (pfsfl=1), 1-day tolerance. A "real"
  # progression is non-pseudo AND has at least one evidence flag = Yes (radiographic /
  # pathologic / clinical-assessment-only / mixed-response) AND a non-null progressiondate.
  tag("26.4", reconcile_agg("patid", P, "pfsdt", rt("t_enh_advnsclcprogr"), "progressiondate", "min", source_key = "patientid", # 26.4
    filter = paste("ispseudoprogressionmentioned = 'No'",
                   "AND (isradiographicevidence = 'Yes' OR ispathologicevidence = 'Yes'",
                   "OR isclinicalassessmentonly = 'Yes' OR ismixedresponse = 'Yes')",
                   "AND progressiondate IS NOT NULL"),
    product_filter = "pfsfl = 1 AND pfsdt IS NOT NULL", tolerance_days = 1, allow_unmatched = TRUE), disposition = "corrected"),
  # 26.2: a pfsfl=1 patient must
  # have a valid raw progression (non-pseudo, an evidence flag = Yes, non-null date) OR be deceased (dthfl=1).
  tag("26.2", list(.chk(type = "expr", label = "26.2 pfsfl=1 patients have a valid raw progression or are deceased",
    r = sprintf('{ P <- fq("product","%s"); R <- fq("raw","%s"); q1(con, paste0("SELECT count(*) FROM (SELECT DISTINCT patid FROM ", P, " WHERE pfsfl = 1 AND coalesce(dthfl, 0) <> 1) l LEFT JOIN (SELECT DISTINCT patientid FROM ", R, " WHERE ispseudoprogressionmentioned = \'No\' AND (isradiographicevidence = \'Yes\' OR ispathologicevidence = \'Yes\' OR isclinicalassessmentonly = \'Yes\' OR ismixedresponse = \'Yes\') AND progressiondate IS NOT NULL) r ON l.patid = r.patientid WHERE r.patientid IS NULL")) }',
      P, rt("t_enh_advnsclcprogr")))), disposition = "corrected"),
  # 26.1 CORRECTED (was a note): every eligpfs=1 patient must have a raw clinic note dated AFTER their index
  # date. Raw `indexdt` may not exist on that raw table (so grouping the raw table by it would be unsafe);
  # this instead uses the PRODUCT's (patid,indexdt) and requires a raw lastclinicnotedate > product indexdt,
  # so raw indexdt is unnecessary. LEFT JOIN with the date condition in the ON, then count eligpfs=1 rows with
  # NO qualifying note (g.patientid IS NULL); must be 0. Calendar dates compared explicitly (try_cast AS date).
  tag("26.1", list(.chk(type = "expr", label = "26.1 eligpfs=1 only when a raw clinic note exists after the index date",
    r = sprintf('{ P <- fq("product","%s"); R <- fq("raw","%s"); q1(con, paste0("SELECT count(*) FROM (SELECT DISTINCT patid, indexdt FROM ", P, " WHERE eligpfs = 1 AND indexdt IS NOT NULL) l LEFT JOIN (SELECT patientid, lastclinicnotedate FROM ", R, " WHERE lastclinicnotedate IS NOT NULL) g ON l.patid = g.patientid AND try_cast(g.lastclinicnotedate AS date) > try_cast(l.indexdt AS date) WHERE g.patientid IS NULL")) }',
      P, rt("t_enh_advnsclcprogr")))), disposition = "corrected"),

  # ===== §27 oral drugs =========================================================================
  # 27.1 minavaildate is NOT derived from a year-granularity oral start: no product patient has
  # minavaildate equal to one of their own year-only oral startdates.
  tag("27.1", reconcile_window(P, product_keys = c("patid", "minavaildate"), source_tbl = rt("t_enh_advnsclc_oral"), # 27.1
    by = list(left = "patid", right = "patientid"),
    source_filter = "upper(dategranularity) = 'YEAR' AND startdate IS NOT NULL",
    predicate = "try_cast(l.minavaildate AS date) = try_cast(r.startdate AS date)",
    label = "27.1 minavaildate not derived from a year-granularity oral start")),
  # 27.2 startdate <= enddate, excluding year-granularity records (case-insensitive; keep null granularity):
  tag("27.2", product_ordering(rt("t_enh_advnsclc_oral"), "startdate", "enddate", source = "raw", # 27.2
    filter = "dategranularity IS NULL OR upper(dategranularity) <> 'YEAR'")),

  # ===== §28 SES ================================================================================
  tag("28.1", reconcile_mapping("patid", P, "ses", rt("t_socdetofhealth"), source_key = "patientid", # 28.1 ses mapping
    source_expr = "sesindex2015_2019", product_filter = "ses IS NOT NULL AND ses <> 'Missing'",   # compares non-null non-Missing product ses only
    allow_unmatched = TRUE), disposition = "corrected"),                                          # (28.2 covers the absent=>Missing case)
  # 28.2 patients absent from raw SES have ses='Missing':
  tag("28.2", list(.chk(type = "join_check", kind = "LEFT",                                      # 28.2
    left  = list(source = "product", table = P),
    right = list(source = "raw", table = rt("t_socdetofhealth"), select = "patientid", distinct = TRUE),
    by = list(left = "patid", right = "patientid"),
    predicate = "r.patientid IS NULL AND coalesce(l.ses, '') <> 'Missing'",
    label = "28.2 patients absent from raw SES have ses='Missing'"))),

  # ===== §29 cross-table referential + count (raw->raw uses patientid both sides) ================
  tag("29.2", reconcile_referential(rt("t_lineoftherapy"), rt("t_enh_advancednsclc"), left_source = "raw", # 29.2 (AdvancedNSCLC scope)
    left_filter = "enhancedcohort = 'AdvancedNSCLC'"), disposition = "corrected"),
  tag("29.3", reconcile_referential(rt("t_drugepisode"), rt("t_enh_advancednsclc"), left_source = "raw",   # 29.3 (AdvancedNSCLC scope)
    left_filter = "enhancedcohort = 'AdvancedNSCLC'"), disposition = "corrected"),
  tag("29.4", reconcile_referential(rt("t_enh_advnsclcbioma"), rt("t_enh_advancednsclc"), left_source = "raw")), # 29.4
  tag("29.5", reconcile_referential(rt("t_enh_mortality_v2"), rt("t_enh_advancednsclc"), left_source = "raw")),  # 29.5
  tag("29.6", reconcile_count(P, rt("t_enh_advancednsclc"), col = "patid", source_col = "patientid", relation = "<=")), # 29.6
  # 29.7 per-key: an inner join of product to raw earliest visit, so compare MATCHED patients
  # only (allow_unmatched=TRUE) — a raw-visit patient outside the product, or a product patient with no visit,
  # must not count as a violation. Pass = min(minavaildate) <= min(visitdate) per matched patient.
  tag("29.7", reconcile_bound(P, "minavaildate", rt("t_visit"), "visitdate", agg = "min", cast = "date",   # 29.7 per-key
    by = "patid", source_key = "patientid", allow_unmatched = TRUE), disposition = "corrected"),
  # 30.15 the final Overall advNSCLC cohort has exactly the raw NSCLC patient count (runs on the
  # delivered product's Overall cohort vs raw NSCLC, an equality; stronger than 29.6's <=).
  tag("30.15", list(.chk(type = "row_count", source = "product", table = P, select = "patid", distinct = TRUE,
    filter = "cohort = 'Overall advNSCLC'", relation = "==",
    compare = list(source = "raw", table = rt("t_enh_advancednsclc"), select = "patientid", distinct = TRUE),
    label = "30.15 Overall advNSCLC cohort distinct patid == raw NSCLC distinct patientid"))),
  # 30.16 <1% of raw NSCLC patients lack a raw demographics record (raw-vs-raw on patientid, a
  # RATE not zero-loss). Runs on raw sources (no build intermediate), so it belongs in the delivered suite.
  tag("30.16", list(.chk(type = "rate", kind = "LEFT", max_pct = 1, strict = TRUE,
    left  = list(source = "raw", table = rt("t_enh_advancednsclc"), select = "patientid", distinct = TRUE),
    right = list(source = "raw", table = rt("t_demographics"),      select = "patientid", distinct = TRUE),
    by = list(left = "patientid", right = "patientid"),
    predicate = "r.patientid IS NULL", label = "30.16 <1% of raw NSCLC patients lack a demographics record"))),

  # ===== §30-42 merge-QC (build_pipeline) is the build-stage suite at the BOTTOM of this file ============
  # The uniqueness / fan-out / count checks against build-time intermediate tables (<demographics_agg>,
  # <base_tbl>, <idx_tbl>, ...) are emitted below as NSCLC_BUILD_CHECKS and run at the product-build stage —
  # not on the delivered product — so they are out of this delivered-product suite (the launcher selects them
  # with NSCLC_BUILD=1).
  # (35.1 ecog UNION uniqueness is true-by-construction and is registry-retired_invalid.)

  # ===== §31 follow-up / index ==================================================================
  # 31.10 id3mosfu derived from the index/max-index gap (> 91 days), product-internal:
  tag("31.10", product_predicate(P, "id3mosfu <> (CASE WHEN datediff(try_cast(maxindex AS date), try_cast(indexdt AS date)) > 91 THEN 1 ELSE 0 END)",
    "31.10 id3mosfu == (maxindex - indexdt > 91)", filter = "indexdt IS NOT NULL AND maxindex IS NOT NULL")),

  # ===== §32 follow-up completeness / ordering ==================================================
  tag("32.10", product_completeness(P, "fued")),                                                  # 32.10
  tag("32.11", product_ordering(P, "fu_enddt_preliminary", "fued")),                              # 32.11
  tag("32.12", product_ordering(P, "dthdt", "fued", filter = "dthfl = 1")),                       # 32.12 (scoped to dthfl=1)
  # 32.13 patients absent from BOTH raw t_visit and t_telemedicine have NULL last_visit_date.
  # Emitted as an expr (union of two raw tables); templated on P so it skips until the product is wired.
  tag("32.13", list(.chk(type = "expr", label = "32.13 patients with no visit/telemedicine record have NULL last_visit_date",
    r = sprintf('q1(con, sprintf("SELECT count(*) FROM %%s l LEFT JOIN (SELECT patientid FROM %%s UNION SELECT patientid FROM %%s) r ON l.patid = r.patientid WHERE r.patientid IS NULL AND l.last_visit_date IS NOT NULL", fq("product","%s"), fq("raw","%s"), fq("raw","%s")))',
      P, rt("t_visit"), rt("t_telemedicine"))))),

  # ===== §34 lab flag/value consistency (expanded per lab pair) ==================================
  # 34.5 flag='Present' implies the value is populated (10 pairs):
  tag("34.5", lapply(list(c("labneu","labneuv"), c("labpla","labplav"), c("labhem","labhemv"), c("labcre","labcrev"),
              c("labbil","labbilv"), c("labalt","labaltv"), c("labalp","labalpv"), c("labast","labastv"),
              c("lablym","lablymv"), c("labalb","labalbv")),
    function(p) .chk(type = "rate", source = "product", table = P, max_pct = 0, allow_empty = TRUE, # 34.5
      filter = sprintf("%s = 'Present'", p[1]), predicate = sprintf("%s IS NULL", p[2]),            # implication is vacuously true with 0 'Present' rows
      label = sprintf("34.5 %s='Present' implies %s populated", p[1], p[2])))),
  # 34.6 flag='Missing' implies the value is null (9 pairs):
  tag("34.6", lapply(list(c("labneu","labneuv"), c("labpla","labplav"), c("labhem","labhemv"), c("labcre","labcrev"),
              c("labbil","labbilv"), c("labalt","labaltv"), c("lablym","lablymv"), c("labalp","labalpv"),
              c("labalb","labalbv")),
    function(p) .chk(type = "rate", source = "product", table = P, max_pct = 0, allow_empty = TRUE, # 34.6
      filter = sprintf("%s = 'Missing'", p[1]), predicate = sprintf("%s IS NOT NULL", p[2]),        # implication is vacuously true with 0 'Missing' rows
      label = sprintf("34.6 %s='Missing' implies %s null", p[1], p[2])))),

  # ===== §33-37 biomarker / lab / ECOG / BP / drug consistency (promoted from omitted; templated on P) ====
  # 33.5 every product biomarker close-date <= indexdt + 14. This loops the 11 close-date
  # columns that EXIST in the product (found via a DESCRIBE) so a product
  # missing a column doesn't error — build the OR of only the present columns.
  # FAIL-CLOSED: if NONE of the expected close-date columns exist, the intersect is empty and a bare `0L`
  # would PASS vacuously on a wrong schema — instead stop so an entirely-absent column set is an execution
  # error (INCOMPLETE), not a green data verdict. A partial subset still runs over the columns that do exist.
  tag("33.5", list(.chk(type = "expr", label = "33.5 product biomarker close-dates are <= indexdt + 14",
    r = sprintf('{ P <- fq("product","%s"); cols <- tolower(qcol(con, paste0("DESCRIBE ", P))); vars <- intersect(c("alkcdt","egfrcdt","brafcdt","ros1cdt","krascdt","metcdt","retcdt","ntrkcdt","her2cdt","pdl1cdt","pdl1psdt"), cols); if (!length(vars)) stop("33.5: no expected biomarker close-date columns present in product — schema mismatch") else q1(con, paste0("SELECT count(*) FROM ", P, " WHERE ", paste(sprintf("(%%s IS NOT NULL AND try_cast(%%s AS date) > date_add(try_cast(indexdt AS date), 14))", vars, vars), collapse=" OR "))) }', P)))),
  # 34.3 every product lab close-date <= indexdt, same DESCRIBE-guarded loop over the 10 lab dates.
  # Same fail-closed treatment: an entirely-absent lab-date column set stops (INCOMPLETE) instead of passing.
  tag("34.3", list(.chk(type = "expr", label = "34.3 product lab close-dates are <= indexdt",
    r = sprintf('{ P <- fq("product","%s"); cols <- tolower(qcol(con, paste0("DESCRIBE ", P))); vars <- intersect(c("labneudt","labpladt","labhemdt","labcredt","labbildt","labastdt","labaltdt","labalpdt","lablymdt","labalbdt"), cols); if (!length(vars)) stop("34.3: no expected lab close-date columns present in product — schema mismatch") else q1(con, paste0("SELECT count(*) FROM ", P, " WHERE ", paste(sprintf("(%%s IS NOT NULL AND try_cast(%%s AS date) > try_cast(indexdt AS date))", vars, vars), collapse=" OR "))) }', P)))),
  # 33.7 CORRECTED: ROW-LEVEL equivalence
  # biom=1 <=> (any driver flag = 1). Count rows where the biom flag and the any-driver flag DISAGREE (XOR via
  # CASE), so one false-positive and one false-negative patient can no longer cancel to a passing aggregate
  # count. A NULL biom/driver flag counts as 0 (not positive), taking `== 1` as the positive test.
  tag("33.7", list(.chk(type = "expr", label = "33.7 biom flag equals any-positive-driver flag row-by-row, and every non-null flag is 0/1",
    r = sprintf('{ P <- fq("product","%s"); flags <- c("biom","alkn","egfrn","brafn","ros1n","krasn","metn","retn","ntrkn","her2n"); nonbin <- paste(sprintf("(%%s IS NOT NULL AND %%s NOT IN (0,1))", flags, flags), collapse = " OR "); q1(con, paste0("SELECT count(*) FROM ", P, " WHERE (CASE WHEN biom = 1 THEN 1 ELSE 0 END) <> (CASE WHEN (alkn = 1 OR egfrn = 1 OR brafn = 1 OR ros1n = 1 OR krasn = 1 OR metn = 1 OR retn = 1 OR ntrkn = 1 OR her2n = 1) THEN 1 ELSE 0 END) OR ", nonbin)) }', P))), disposition = "corrected"),
  # ===== §35-37 ECOG / BP / drug-date consistency (promoted from omitted; product-vs-raw, templated on P) ====
  # 35.4 final ecog (as int) does not exceed the per-patient max raw ecog across t_ecog UNION t_baseline_ecog
  #. Union + per-key aggregate needs the expr hatch; templated on P so it skips until wired.
  tag("35.4", list(.chk(type = "expr", label = "35.4 final ecog does not exceed per-patient raw max ecog",
    r = sprintf('q1(con, sprintf("SELECT count(*) FROM %%s l INNER JOIN (SELECT patientid, max(try_cast(ecogvalue AS int)) AS raw_max_ecog FROM (SELECT patientid, ecogvalue FROM %%s UNION ALL SELECT patientid, ecogvalue FROM %%s) u WHERE try_cast(ecogvalue AS int) IS NOT NULL GROUP BY patientid) r ON l.patid = r.patientid WHERE l.ecog IS NOT NULL AND l.ecog <> \'Unknown\' AND try_cast(l.ecog AS int) > r.raw_max_ecog", fq("product","%s"), fq("raw","%s"), fq("raw","%s")))',
      P, rt("t_ecog"), rt("t_baseline_ecog"))))),
  # 36.3 + 36.4 as ONE fail-closed BP check. A bp='Present' row is valid only if bpdt, bpsys and bpdia are all
  # populated and parseable, AND that date has a raw systolic and a raw diastolic whose value reconciles to
  # bpsys/bpdia within 1. Raw values use testresultcleaned (the normalized numeric column, same as 21.3/21.5).
  # Count Present rows that miss any of these; must be 0. All comparisons use try_cast, so a null or unparseable
  # value on either side is a violation, not a silent pass. This subsumes the old value-only 36.4 (which skipped
  # rows with a null side and didn't count unparseable casts). Skips until P is wired.
  tag("36.3", list(.chk(type = "expr", label = "36.3 bp='Present' has parseable bpdt/bpsys/bpdia and both reconcile to same-date raw within 1",
    r = sprintf('{ v <- fq("raw","%s"); P <- fq("product","%s"); q1(con, paste0("SELECT count(*) FROM (SELECT patid, bpdt, bpsys, bpdia FROM ", P, " WHERE bp = \'Present\') l WHERE try_cast(l.bpdt AS date) IS NULL OR try_cast(l.bpsys AS double) IS NULL OR try_cast(l.bpdia AS double) IS NULL OR NOT EXISTS (SELECT 1 FROM ", v, " s WHERE s.patientid = l.patid AND try_cast(s.testdate AS date) = try_cast(l.bpdt AS date) AND upper(s.test) = \'SYSTOLIC BLOOD PRESSURE\' AND try_cast(s.testresultcleaned AS double) IS NOT NULL AND abs(try_cast(s.testresultcleaned AS double) - try_cast(l.bpsys AS double)) <= 1) OR NOT EXISTS (SELECT 1 FROM ", v, " d WHERE d.patientid = l.patid AND try_cast(d.testdate AS date) = try_cast(l.bpdt AS date) AND upper(d.test) = \'DIASTOLIC BLOOD PRESSURE\' AND try_cast(d.testresultcleaned AS double) IS NOT NULL AND abs(try_cast(d.testresultcleaned AS double) - try_cast(l.bpdia AS double)) <= 1)")) }',
      rt("t_vitals"), P))), disposition = "corrected"),
  # 36.4 (bpsys/bpdia reconcile to raw on bpdt) is now folded into the single 36.3 check above -> subsumed.
  # 37.2 CSF drug dates are <= indexdt for flagged (csf=1) patients, across medicationorder / medicationadmin /
  # drugepisode. grepl(pattern) -> RLIKE. medorder here has no iscanceled filter.
  tag("37.2", list(.chk(type = "expr", label = "37.2 CSF drug dates are <= indexdt for csf=1 patients",
    r = sprintf('q1(con, sprintf("SELECT count(*) FROM (SELECT DISTINCT patid, indexdt FROM %%s WHERE csf = 1) l INNER JOIN (SELECT patientid, coalesce(expectedstartdate, ordereddate) AS meddate FROM %%s WHERE upper(commondrugname) RLIKE \'FILGRASTIM|PEGFILGRASTIM|EPOETIN ALFA-EPBX\' UNION ALL SELECT patientid, administereddate AS meddate FROM %%s WHERE upper(commondrugname) RLIKE \'FILGRASTIM|PEGFILGRASTIM|EPOETIN ALFA-EPBX\' UNION ALL SELECT patientid, episodedate AS meddate FROM %%s WHERE upper(drugname) RLIKE \'FILGRASTIM|PEGFILGRASTIM|EPOETIN ALFA-EPBX\') r ON l.patid = r.patientid WHERE r.meddate IS NOT NULL AND try_cast(r.meddate AS date) > try_cast(l.indexdt AS date)", fq("product","%s"), fq("raw","%s"), fq("raw","%s"), fq("raw","%s")))',
      P, rt("t_medicationorder"), rt("t_medicationadmin"), rt("t_drugepisode"))))),
  # 37.3 SS (systemic steroid) drug dates are <= indexdt for flagged (ss=1) patients. medorder
  # additionally requires iscanceled IS NULL; medadmin / drugepisode do not.
  tag("37.3", list(.chk(type = "expr", label = "37.3 SS drug dates are <= indexdt for ss=1 patients",
    r = sprintf('q1(con, sprintf("SELECT count(*) FROM (SELECT DISTINCT patid, indexdt FROM %%s WHERE ss = 1) l INNER JOIN (SELECT patientid, coalesce(expectedstartdate, ordereddate) AS meddate FROM %%s WHERE upper(commondrugname) RLIKE \'DEXAMETHASONE|PREDNISONE|PREDNISOLONE|METHYLPREDNISOLONE|TRIAMCINOLONE|HYDROCORTISONE|CORTISONE ACETATE|BETAMETASONE|FLUDROCORTISONE\' AND iscanceled IS NULL UNION ALL SELECT patientid, administereddate AS meddate FROM %%s WHERE upper(commondrugname) RLIKE \'DEXAMETHASONE|PREDNISONE|PREDNISOLONE|METHYLPREDNISOLONE|TRIAMCINOLONE|HYDROCORTISONE|CORTISONE ACETATE|BETAMETASONE|FLUDROCORTISONE\' UNION ALL SELECT patientid, episodedate AS meddate FROM %%s WHERE upper(drugname) RLIKE \'DEXAMETHASONE|PREDNISONE|PREDNISOLONE|METHYLPREDNISOLONE|TRIAMCINOLONE|HYDROCORTISONE|CORTISONE ACETATE|BETAMETASONE|FLUDROCORTISONE\') r ON l.patid = r.patientid WHERE r.meddate IS NOT NULL AND try_cast(r.meddate AS date) > try_cast(l.indexdt AS date)", fq("product","%s"), fq("raw","%s"), fq("raw","%s"), fq("raw","%s")))',
      P, rt("t_medicationorder"), rt("t_medicationadmin"), rt("t_drugepisode"))))),
  # 37.4 the csf/ss output flags are binary 0/1 ( all(df$csf %in% c(0,1)) — NA also fails).
  tag("37.4", c(
    product_predicate(P, "csf IS NULL OR csf NOT IN (0, 1)", "37.4 csf is a binary 0/1 flag"),
    product_predicate(P, "ss IS NULL OR ss NOT IN (0, 1)",   "37.4 ss is a binary 0/1 flag"))),

  # ===== §31-42 final-product STRUCTURE (run on the delivered product P) — promoted from build_pipeline ====
  # The §30-42 uniqueness/fan-out tests mostly run on the final df and reduce to
  # (patid, cohort) uniqueness on the delivered product (42.5) — those are registry-SUBSUMED by 42.5. These
  # assert something 42.5 does not, and run against P (no build-time intermediate needed).
  # 42.5 the product is a VALID composite key on (patid, cohort) — the core structural invariant the rest
  # reduce to. unique_key(GROUP BY..HAVING count>1) treats all-NULL keys as one group, so a SINGLE null patid
  # is not a "duplicate" and slips through; the null_rate closes that (cohort non-null is 42.2/42.3).
  tag("42.5", list(
    .chk(type = "unique_key", source = "product", table = P, keys = c("patid", "cohort"),
         label = "42.5 product is 1:1 on (patid, cohort)"),
    .chk(type = "null_rate", source = "product", table = P, col = "patid", max_pct = 0,
         label = "42.5 patid is never null (a valid (patid, cohort) key)"))),
  # 40.2 every product patient appears in the Overall advNSCLC cohort:
  tag("40.2", list(.chk(type = "referential",
    left  = list(source = "product", table = P, col = "patid"),
    right = list(source = "product", table = P, col = "patid", filter = "cohort = 'Overall advNSCLC'"),
    label = "40.2 every patid is present in the Overall advNSCLC cohort"))),
  # 31.6 / 31.7 / 31.8 / 42.7 cohort nesting (self-referential on P): L1 <= Overall, L2 <= L1, L3 <= L2, L1m <= L1:
  tag("31.6", list(.chk(type = "referential",
    left  = list(source = "product", table = P, col = "patid", filter = "cohort = 'L1 + treated advNSCLC'"),
    right = list(source = "product", table = P, col = "patid", filter = "cohort = 'Overall advNSCLC'"),
    label = "31.6 L1 cohort patients are a subset of Overall advNSCLC"))),
  tag("31.7", list(.chk(type = "referential",
    left  = list(source = "product", table = P, col = "patid", filter = "cohort = 'L2 + treated advNSCLC'"),
    right = list(source = "product", table = P, col = "patid", filter = "cohort = 'L1 + treated advNSCLC'"),
    label = "31.7 L2 cohort patients are a subset of L1"))),
  tag("31.8", list(.chk(type = "referential",
    left  = list(source = "product", table = P, col = "patid", filter = "cohort = 'L3 + treated advNSCLC'"),
    right = list(source = "product", table = P, col = "patid", filter = "cohort = 'L2 + treated advNSCLC'"),
    label = "31.8 L3 cohort patients are a subset of L2"))),
  tag("42.7", list(.chk(type = "referential",
    left  = list(source = "product", table = P, col = "patid", filter = "cohort = 'L1m + treated advNSCLC'"),
    right = list(source = "product", table = P, col = "patid", filter = "cohort = 'L1 + treated advNSCLC'"),
    label = "42.7 L1m cohort patients are a subset of L1"))),
  # 41.4 fued is populated whenever id3mosfu=1 and a treatment-to-next-treatment flag (ttntfl) is present:
  tag("41.4", product_predicate(P, "id3mosfu = 1 AND ttntfl IS NOT NULL AND fued IS NULL",
    "41.4 id3mosfu=1 with ttntfl present implies fued populated")),
  # 34.4 a populated labneuv has a supporting valid raw NEUTROPHILS record (representative lab):
  tag("34.4", list(.chk(type = "referential",
    left  = list(source = "product", table = P, col = "patid", filter = "labneuv IS NOT NULL"),
    right = list(source = "raw", table = rt("t_lab"), col = "patientid",
                 filter = "upper(testbasename) = 'NEUTROPHILS' AND try_cast(testresultcleaned AS double) > 0 AND upper(testunitscleaned) = '10*9/L' AND (resultdate IS NOT NULL OR testdate IS NOT NULL)"),
    label = "34.4 labneuv populated implies a valid raw NEUTROPHILS record")), disposition = "corrected"),

  # ===== §38 treatment category defaults ========================================================
  # 38.4 patients absent from raw LOT1 (non-maint) have lot1cat='No treatment':
  tag("38.4", list(.chk(type = "join_check", kind = "LEFT",                                       # 38.4
    left  = list(source = "product", table = P),
    right = list(source = "raw", table = rt("t_lineoftherapy"), select = "patientid", distinct = TRUE,
                 filter = "linenumber = 1 AND enhancedcohort = 'AdvancedNSCLC' AND upper(ismaintenancetherapy) = 'FALSE'"),
    by = list(left = "patid", right = "patientid"),
    predicate = "r.patientid IS NULL AND coalesce(l.lot1cat, '') <> 'No treatment'",
    label = "38.4 patients without raw LOT1 have lot1cat='No treatment'"))),
  # 38.5 patients absent from raw LOT1 maintenance have lot1mcat='No maintenance therapy':
  tag("38.5", list(.chk(type = "join_check", kind = "LEFT",                                       # 38.5
    left  = list(source = "product", table = P),
    right = list(source = "raw", table = rt("t_lineoftherapy"), select = "patientid", distinct = TRUE,
                 filter = "linenumber = 1 AND enhancedcohort = 'AdvancedNSCLC' AND upper(ismaintenancetherapy) = 'TRUE'"),
    by = list(left = "patid", right = "patientid"),
    predicate = "r.patientid IS NULL AND coalesce(l.lot1mcat, '') <> 'No maintenance therapy'",
    label = "38.5 patients without raw LOT1m have lot1mcat='No maintenance therapy'"))),

  # ===== §40-42 final-product completeness / cohort fields =======================================
  tag("40.3", product_completeness(P, "minavaildate")),                                           # 40.3
  # 40.4 biom=1 implies the composite biomarker result biomc is populated (; the assertion is
  # filter(biom==1 & is.na(biomc)), a product-internal predicate).
  tag("40.4", product_predicate(P, "biom = 1 AND biomc IS NULL",
    "40.4 biom=1 implies biomc is populated", max_pct = 0)),                                       # 40.4
  tag("41.8", product_predicate(P, "pfs2dt IS NOT NULL", "41.8 pfs2dt is NULL for Overall advNSCLC", filter = "cohort = 'Overall advNSCLC'")), # 41.8
  tag("41.9", product_predicate(P, "pfs2 IS NOT NULL",   "41.9 pfs2 is NULL for Overall advNSCLC",   filter = "cohort = 'Overall advNSCLC'")), # 41.9
  # 42.1 exactly the expected cohort SET: count == 5 distinct AND every cohort is one of the expected labels.
  # count-only would pass a product with 5 arbitrary labels (and the L1/L2/L3/L1m subset checks would then
  # pass vacuously); the domain check closes that.
  tag("42.1", list(
    .chk(type = "row_count", source = "product", table = P, select = "cohort", distinct = TRUE,
         expected = length(NSCLC_COHORTS), label = "42.1 exactly 5 distinct cohort labels"),
    .chk(type = "domain", source = "product", table = P, col = "cohort", allowed = NSCLC_COHORTS,
         label = "42.1 every cohort is one of the 5 expected NSCLC cohort labels"))),
  tag("42.2", product_completeness(P, "cohort")),                                                 # 42.2
  tag("42.3", product_completeness(P, "cohortn")),                                                # 42.3
  # 42.4 the final dataset has exactly the approved columns. Two forms, strongest available wins:
  #   * manifest filled (NSCLC_COLUMNS) -> a `schema` check of the exact column names + types (catches a column
  #     dropped and swapped for an unrelated one, which a count alone misses).
  #   * manifest empty -> fall back to the approved column COUNT (NSCLC_EXPECTED_NCOL), validated with a strict
  #     regex at assembly time so a mistyped "150.9" is a clear error, not a silent truncation to 150.
  # Either way it template-skips until the product table P is wired.
  local({
    if (length(NSCLC_COLUMNS)) {
      tag("42.4", list(.chk(type = "schema", source = "product", table = P, manifest = NSCLC_COLUMNS,
        label = "42.4 final dataset has exactly the approved columns (names + types)")), disposition = "corrected")
    } else {
      .ncol_env <- Sys.getenv("NSCLC_EXPECTED_NCOL", "")
      .ncol_tok <- if (grepl("^[1-9][0-9]*$", .ncol_env)) .ncol_env else if (nzchar(.ncol_env)) "INVALID" else "<expected_ncol>"
      tag("42.4", list(.chk(type = "expr", label = "42.4 final dataset has the approved column count",
        r = sprintf('{ tok <- "%s"; if (tok == "INVALID") stop("42.4: NSCLC_EXPECTED_NCOL must be a positive integer (^[1-9][0-9]*$)"); n <- as.integer(tok); as.numeric(ncol(qdf(con, sprintf("SELECT * FROM %%s LIMIT 0", fq("product","%s")))) != n) }',
          .ncol_tok, P))), disposition = "corrected")
    }
  }),
  # 42.6 the Overall advNSCLC cohort has the largest distinct-patient count. Corrected to a well-defined form:
  # instead of asserting Overall sorts strictly FIRST (undefined at a tie), require that no cohort has MORE
  # than Overall (Overall is the largest or tied for it).
  tag("42.6", list(.chk(type = "expr", label = "42.6 Overall advNSCLC cohort has the largest patient count",
    r = sprintf('{ P <- fq("product","%s"); q1(con, paste0("SELECT count(*) FROM (SELECT cohort, count(DISTINCT patid) AS n FROM ", P, " GROUP BY cohort) c WHERE c.cohort <> \'Overall advNSCLC\' AND c.n > (SELECT count(DISTINCT patid) FROM ", P, " WHERE cohort = \'Overall advNSCLC\')")) }', P))), disposition = "corrected"),
  tag("42.10", product_completeness(P, c("cohortu", "cohortun")))                                 # 42.10 (last emitted entry)

  # ===== notes for the residual tests (see the QC_REGISTRY section below for the full disposition of each) =====
  # The one remaining `note` id needs a product decision this static config can't make: 15.6 (brthdt vs
  # birthyear — a date-vs-year comparison whose meaning depends on the product's brthdt type). 42.8 (SAS
  # variable-label metadata) is OUT OF SCOPE for the SQL-count model — it would need a label-aware check the
  # profiler does NOT currently implement, so it is genuinely unasserted today (not silently covered elsewhere).
  # Profiling + drift: append profile_and_drift(cut = CUT, prev_cut = "<prev>") once you have real cut labels
  # (the drift paths are cut-derived — see the generator).
)

# ============================ build-stage suite ================================
# Runs at product-build time against the intermediate <...> tables. Not part of a delivered run; the launcher
# swaps CFG$checks to NSCLC_BUILD_CHECKS (and drops QC_REGISTRY) when NSCLC_BUILD=1. Uses rt/CUT/P from above.
#
# STRICT BY DEFAULT: every build check is required, so an unmapped or empty intermediate fails the run. Set
# NSCLC_BUILD_ALLOW_PARTIAL=1 during development to run only what's wired and skip the rest without failing.
BUILD_STRICT <- !(tolower(Sys.getenv("NSCLC_BUILD_ALLOW_PARTIAL", "")) %in% c("1", "true", "yes", "t"))
bp <- function(id, checks) tag(id, checks, required = BUILD_STRICT, disposition = "build_pipeline")

# ---- non-empty guards for the mandatory build relations ----------------------------------------------------
# Fan-out and set checks pass vacuously on empty inputs (0 rows in -> 0 bad rows out), so guard every relation
# such a check leans on: <base_tbl> and <idx_tbl> (fan-out bases), <clin_tbl> (40.6), and <union_tbl> plus the
# product P (42.9). Untagged supporting guards (not tumor checks); required with BUILD_STRICT, so a strict
# build fails on an empty mandatory relation, and each skips until mapped. Optional aggregates (<lot2_agg>,
# <biomarker_*_cte>, ...) are deliberately unguarded — many legitimately have zero rows, and their own checks
# handle empty inputs correctly.
.bp_nonempty <- list(
  .chk(type = "row_count", source = "product", table = "<base_tbl>",  min = 1, required = BUILD_STRICT,
       disposition = "build_pipeline", label = "base_tbl (patient base every fan-out joins onto) has rows"),
  .chk(type = "row_count", source = "product", table = "<idx_tbl>",   min = 1, required = BUILD_STRICT,
       disposition = "build_pipeline", label = "idx_tbl (index/df base for 38.3 / 39.5) has rows"),
  .chk(type = "row_count", source = "product", table = "<clin_tbl>",  min = 1, required = BUILD_STRICT,
       disposition = "build_pipeline", label = "clin_tbl (base for the 40.6 trt_cat fan-out) has rows"),
  .chk(type = "row_count", source = "product", table = "<union_tbl>", min = 1, required = BUILD_STRICT,
       disposition = "build_pipeline", label = "union_tbl (5-cohort UNION that 42.9 compares to the product) has rows"),
  .chk(type = "row_count", source = "product", table = P,             min = 1, required = BUILD_STRICT,
       disposition = "build_pipeline", label = "product (final dataset that 42.9 compares to union_tbl) has rows"))

# ---- uniqueness of an aggregated intermediate on its key (id, table, keys) ----
.bp_unique <- list(
  # NB: 30.1 is NOT here — it checks uniqueness on the RAW t_demographics table, which is a gating delivered
  # check above. The 30.2+ aggregations below are unique by construction.
  list(id = "30.2", t = "<practicetype_agg>",       k = "patientid"),
  list(id = "30.3", t = "<lot1_agg>",               k = "patientid"),
  list(id = "30.4", t = "<lot2_agg>",               k = "patientid"),
  list(id = "30.5", t = "<lot3_agg>",               k = "patientid"),
  list(id = "30.6", t = "<linenumber_max_agg>",     k = "patientid"),
  list(id = "30.7", t = "<lot1_enddt_agg>",         k = "patientid"),
  list(id = "30.8", t = "<lot1m_agg>",              k = "patientid"),
  list(id = "30.9", t = "<sesindex_agg>",           k = "patientid"),
  list(id = "31.9", t = "<lot1_minstartdt_agg>",    k = "patientid"),
  list(id = "32.1", t = "<visit_agg>",              k = "patientid"),
  list(id = "32.2", t = "<lot_enddt_agg>",          k = "patientid"),
  list(id = "32.3", t = "<drugepisode_maxdt_agg>",  k = "patientid"),
  list(id = "32.4", t = "<oraldrug_agg>",           k = "patientid"),
  list(id = "32.5", t = "<mortality_agg>",          k = "patientid"),
  list(id = "33.1", t = "<biomarker_status_cte>",   k = c("patientid", "biomarkername")),
  list(id = "33.2", t = "<biomarker_closedt_cte>",  k = c("patientid", "biomarkername")),
  list(id = "34.1", t = "<lab_closedt_cte>",        k = c("patientid", "testbasename")),
  list(id = "36.1", t = "<bp_closedt_cte>",         k = "patientid"),
  list(id = "38.1", t = "<trtcat_cte>",             k = c("patientid", "linenumber")),
  list(id = "38.2", t = "<mtrtcat_cte>",            k = "patientid"),
  list(id = "39.1", t = "<weight_agg>",             k = "patientid"),
  list(id = "39.2", t = "<height_agg>",             k = "patientid"),
  # 35.2 the baseline-ECOG close-date CTE is unique per (patientid, index_date). The check as written is
  # broken as written (an undefined `combined_ecog`), but this uniqueness ASSERTION on the real build CTE
  # is valid — so it is recovered here as a build-stage uniqueness check (was retired_invalid).
  list(id = "35.2", t = "<bl_max_ecogdt>",          k = c("patientid", "index_date")))

# ---- LEFT JOIN base <- attribute does not fan out (id, base, attribute, by) ----
.bp_fanout <- list(
  list(id = "30.10", base = "<base_tbl>", attr = "<demographics_agg>", by = "patientid"),
  list(id = "30.11", base = "<base_tbl>", attr = "<practicetype_agg>", by = "patientid"),
  list(id = "30.12", base = "<base_tbl>", attr = "<lot1_agg>",         by = "patientid"),
  list(id = "30.13", base = "<base_tbl>", attr = "<plat_l1_agg>",      by = "patientid"),
  list(id = "30.14", base = "<base_tbl>", attr = "<sesindex_agg>",     by = "patientid"),
  # 32.6-32.9 fan out onto the RAW NSCLC patient base (distinct patientid in raw NSCLC), so the base
  # is <base_tbl> keyed patientid — NOT <idx_tbl>. (33.3 / 35.3 are df group_by(patid,cohort) checks, subsumed
  # by 42.5, so they are not here.)
  list(id = "32.6",  base = "<base_tbl>", attr = "<visit_agg>",        by = "patientid"),
  list(id = "32.7",  base = "<base_tbl>", attr = "<medorder_agg>",     by = "patientid"),
  list(id = "32.8",  base = "<base_tbl>", attr = "<telemedicine_agg>", by = "patientid"),
  list(id = "32.9",  base = "<base_tbl>", attr = "<mortality_agg>",    by = "patientid"),
  # 38.3 / 39.5 join the index table (df, keyed patid) to a patientid-keyed aggregate — an ASYMMETRIC join, so
  # the aggregate keeps its patientid contract (as declared for 39.1 etc.) instead of being silently re-keyed.
  list(id = "38.3",  base = "<idx_tbl>",  attr = "<trtcat_agg>",       by = list(left = "patid", right = "patientid")),
  list(id = "39.5",  base = "<idx_tbl>",  attr = "<weight_agg>",       by = list(left = "patid", right = "patientid")),
  # 40.6 the treatment-category join onto the clinical table stays 1:1 — checked directly at the build stage
  # (final per-(patid,cohort) uniqueness can't prove an intermediate join didn't fan out then get deduped).
  list(id = "40.6",  base = "<clin_tbl>", attr = "<trtcat_agg>",       by = "patientid"))

NSCLC_BUILD_CHECKS <- c(
  .bp_nonempty,
  do.call(c, lapply(.bp_unique, function(s) bp(s$id, product_unique_keys(list(list(table = s$t, keys = s$k)))))),
  do.call(c, lapply(.bp_fanout, function(s) bp(s$id, merge_no_fanout(s$base, s$attr, by = s$by)))),
  # 37.1 the CSF/SS drug UNION introduces no patient absent from the union of the raw drug sources:
  bp("37.1", reconcile_referential("<drug_union_pats>", "<all_drug_pats>", id = "patientid",
             left_source = "product", right_source = "product")),
  # 42.9 the final SELECT keeps exactly the union_tbl patient set: the (patid,cohort) sets of <union_tbl> and
  # the product P must be EQUAL. Count the symmetric difference (pairs in one but not the other, both
  # directions) — must be 0. Equal counts alone would miss a swap (one pair dropped, another added), so this
  # uses EXCEPT both ways. Skips until <union_tbl> and P are both wired.
  bp("42.9", list(.chk(type = "expr", label = "42.9 final SELECT keeps exactly the union_tbl (patid,cohort) set",
    r = sprintf('{ u <- fq("product","%s"); P <- fq("product","%s"); q1(con, paste0("SELECT (SELECT count(*) FROM (SELECT DISTINCT patid, cohort FROM ", u, " EXCEPT SELECT DISTINCT patid, cohort FROM ", P, ")) + (SELECT count(*) FROM (SELECT DISTINCT patid, cohort FROM ", P, " EXCEPT SELECT DISTINCT patid, cohort FROM ", u, "))")) }',
      "<union_tbl>", P)))))
  # NB: 31.7 (L2<=L1 nesting), 30.15 (Overall cohort count == raw NSCLC count) and 30.16 (NSCLC patients have a
  # demographics record) run on the delivered product / raw sources, not a build intermediate — they are
  # gating checks in qc_nsclc_config.R.

# ============================ check inventory / dispositions check inventory ===================
.reg <- function(disposition, ids) stats::setNames(rep(disposition, length(ids)), ids)

QC_REGISTRY <- c(
  # -- implemented (69): an emitted gating check covers it directly --
  .reg("implemented", c(
    "14.1", "14.2", "14.3", "14.4", "14.5", "14.6", "14.7", "14.8",
    "15.1", "15.2", "15.4", "15.5",
    "16.3", "16.4",
    "17.3", "17.6", "17.7",
    "18.1", "18.2", "18.3",
    "19.1", "19.2", "19.4",
    "20.2", "20.3", "20.4", "20.5",
    "22.3", "24.3",
    "25.1", "25.3", "25.4",
    "26.3", "27.1", "27.2",
    "29.4", "29.5", "29.6",
    "30.1", "30.15", "30.16",
    "31.6", "31.7", "31.8", "31.10",
    "32.10", "32.11", "32.12", "32.13",
    "33.5", "33.6",
    "34.3", "34.6",
    "35.4", "37.2", "37.3", "37.4",
    "40.2", "40.3", "40.4",
    "41.4", "41.8", "41.9",
    "42.1", "42.2", "42.3", "42.5", "42.7", "42.10")),

  # -- corrected (29): implemented but the emitted check fixes a semantic bug in the check --
  .reg("corrected", c(
    "15.3",                     # birthyear: parse-safe range (unparseable non-blank now fails, not fail-open)
    "16.1", "16.2",             # practicetype / practic: case-insensitive; 'Both academic and community' added
    "17.8",                     # broken as written (undefined raw_lot1plat col): lot1plat equals whether a platinum LOT1 exists in raw
    "26.1",                     # was a note: uses PRODUCT (patid,indexdt) + raw note > index (drops the raw indexdt group-by)
    "36.3",                     # broken as written (discards inner_join, asserts nrow of wrong frame): bp='Present' pair fail-closed (both source records)
    "28.2", "38.4", "38.5",     # coalesce flags a NULL product value as a mismatch; the literal R filter would drop nulls
    "34.5",                     # the lab_pairs list had a malformed 1-element entry c("labhemv"); the 10-pair form repairs it
    "42.4",                     # the 150 column count is provisional: configurable via NSCLC_EXPECTED_NCOL; reliable LIMIT-0 ncol
    "42.6",                     # sorting Overall strictly-first is undefined at ties; this requires no cohort > Overall
    "17.1", "17.2",             # ismaintenancetherapy case-insensitive; linenumber rejects 1.5, ignores NULL
    "17.5",                     # lot1sd: allow_unmatched so absent-from-source patients don't false-fail
    "18.4", "18.5",             # lot1ed / lot1med: allow_unmatched + product_filter scope
    "19.3",                     # biomarker window: raw-side name-set restriction; NTRK matched by prefix (the ^ntrk pattern is a no-op)
    "21.3",                     # weight bound: testunitscleaned (not `unit`)
    "21.5",                     # BP rate: systolic-record-count denominator + strict <; numeric cast
    "25.2",                     # dateofdeath length uses RAW dateofdeath, not product dthdt
    "26.2",                     # broken as written (progressiondate as a bare boolean): pfsfl=1 => valid raw progression OR dthfl=1
    "26.4",                     # pfsdt: non-null progressiondate + evidence-flag scope + pfsfl=1/pfsdt-not-null + 1-day tolerance
    "33.7",                     # broken as written (undefined biom_pos_count): count(biom=1) == count(any-positive driver)
    "34.4",                     # labneuv referential: ref's toupper(testresultcleaned)>0 (lexicographic) -> numeric try_cast>0
    "28.1",                     # ses mapping: allow_unmatched (absent => Missing handled by 28.2)
    "29.2", "29.3",             # cross-table referential scoped to enhancedcohort='AdvancedNSCLC'
    "29.7")),                   # minavaildate bound: allow_unmatched (inner-joins matched patients only)

  # -- build_pipeline (37): merge/uniqueness/fan-out checks against build-time intermediate CTEs/tables (raw
  # aggregations, SAS intermediates) that do not survive in the delivered product. Emitted (against <...>
  # placeholders) in the build-stage suite below; run at the product-build stage. Not gating for a delivered run.
  # (30.1 is NOT here — RAW t_demographics uniqueness, a gating delivered check. 33.3 / 35.3 are NOT here —
  # they group the final df by (patid,cohort), so they are subsumed by 42.5, not build-intermediate joins.) --
  .reg("build_pipeline", c(
    "30.2", "30.3", "30.4", "30.5", "30.6", "30.7", "30.8",
    "30.9", "30.10", "30.11", "30.12", "30.13", "30.14",   # (36 total)
    "31.9",
    "32.1", "32.2", "32.3", "32.4", "32.5", "32.6", "32.7", "32.8", "32.9",
    "33.1", "33.2",
    "34.1",
    "35.2",                     # bl_max_ecogdt CTE unique on (patientid,index_date) — was retired (undefined combined_ecog), assertion is valid at build
    "36.1",
    "37.1",
    "38.1", "38.2", "38.3",
    "39.1", "39.2", "39.5",
    "40.6",                     # trt_cat join onto the clinical table stays 1:1 — direct build no-fanout (not subsumed by final uniqueness)
    "42.9")),                   # union_tbl and product hold the same (patid,cohort) set — a real build check (was a self-comparison)

  # -- subsumed (24): covered by another EMITTED gating check (named) — no separate assertion needed. The §30-42
  # per-(patid,cohort) uniqueness/fan-out tests all reduce to 42.5 (product 1:1 on patid,cohort) --
  .reg("subsumed", c(
    "29.1",                     # == 14.1 (final patids exist in raw NSCLC)
    "41.7",                     # broken as written (dangling anti-join); literal check == 41.9
    "31.1", "31.2", "31.3", "31.4", "31.5",   # per-cohort patid uniqueness => 42.5
    "33.3", "33.4", "34.2", "35.3", "36.2",   # one biomarker / pdl1c / lab / ecog / bp per (patid,cohort) => 42.5
    "36.4",                     # bpsys/bpdia value reconciliation folded into the single fail-closed 36.3 check
    "39.3", "39.4", "39.6",     # one weight / height / bmi per (patid,cohort) => 42.5
    "40.1",                     # each cohort has >0 patients => implied by 42.1 (5 cohorts) + product identity
    "40.5",                     # one csd row per (patid,cohort) => 42.5
    "41.1", "41.2", "41.3", "41.5", "41.6", "41.10")),   # one row per (patid,cohort) [per attr] => 42.5

  # -- note (1): needs a PRODUCT DECISION this static config can't make (not merely unimplemented) --
  # 15.6 brthdt vs birthyear is a date-vs-year comparison whose meaning depends on the product's brthdt type.
  .reg("note", c("15.6")),

  # -- retired_invalid (3): the check is broken / inverted / tautological, deliberately not asserted.
  # WAIVER: each is unsalvageable AS WRITTEN (not merely unimplemented) — asserting it would either error or
  # pass vacuously, so it can't be asserted as-is. Rationale is inline per id; these need an upstream
  # fix upstream (or an external mapping) before they can gate. (35.2 -> build_pipeline, 40.6 -> build_pipeline,
  # 42.9 -> build_pipeline, 36.3 -> corrected: all recovered; the three below stay genuinely unsalvageable.)
  .reg("retired_invalid", c(
    "17.4",                     # inverted: expects ZERO of the normal valid LOT1 rows (a passing build would fail it)
    "35.1",                     # UNION dedups before the uniqueness test — true by construction (never fails)
    "38.6")),                   # malformed cat_map; join key ltrtcatn absent — needs a versioned 18-value label/code map to recover

  # -- out_of_scope (1): not expressible in the SQL-count model --
  .reg("out_of_scope", c("42.8"))
)

# Expected emitted-check MULTIPLICITY for the ref_ids whose generator/loop emits more than one check under a
# single id. The contract test asserts the config emits EXACTLY this many checks per id, so accidentally
# dropping (say) 9 of the 10 lab-bound checks under 20.4 is caught even though ref_id "20.4" is still present.
# Ids not listed here are expected to emit >= 1 check (the ordinary "every gating id is emitted" rule).
# 14.6 product_identity -> row_count + null_rate + unique_key
# 19.4 9 biomarkers | 20.4 10 lab bounds | 20.5 10 lab-name guards | 34.5 10 flag/value | 34.6 9 flag/value
# 37.4 csf + ss | 42.10 product_completeness(cohortu, cohortun)
# 42.1 distinct-count (row_count) + allowed-label domain => count 5 AND every label in NSCLC_COHORTS (set equality)
QC_EXPECTED_MULTIPLICITY <- c(
  "14.6" = 3L, "19.4" = 9L, "20.4" = 10L, "20.5" = 10L,
  "34.5" = 10L, "34.6" = 9L, "37.4" = 2L, "42.1" = 2L, "42.5" = 2L, "42.10" = 2L)

# Sanity: the inventory is exactly the 164 checks, no id counted twice; every multiplicity id gates.
stopifnot(length(QC_REGISTRY) == 164L, !any(duplicated(names(QC_REGISTRY))),
          all(names(QC_EXPECTED_MULTIPLICITY) %in% names(QC_REGISTRY)[QC_REGISTRY %in% c("implemented", "corrected")]))
