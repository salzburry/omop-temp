# qc_contract_test.R — OFFLINE contract test for the generator library + a tumor config (NSCLC here).
#
# Runs with NO database: it sources the generators, the config, and the engine (define-only), then validates
# the ASSEMBLED check list structurally — so a config typo is caught in CI before a live Databricks run,
# instead of failing halfway through a long suite. This is the "source the files together and validate the
# flat check list" gate the reviews asked for.
#
# Run (in CI, where R is installed):
#   Rscript -e 'testthat::test_file("qc_contract_test.R")'
#
# It checks: the config assembles to a flat list; every check has a type with a registered handler; every
# check carries the fields its handler reads; rate is either single-relation or join form; relation specs are
# lists with a table; and there are no exact-duplicate labels (a cheap traceability smell). It does NOT need
# a DB or resolved placeholders — placeholders are legal templates and are ignored here.

library(testthat)

here <- tryCatch(dirname(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))),
                 error = function(e) ".")
if (!length(here) || here == "") here <- "."

# The framework is 3 files now: source the UNIVERSAL engine (generators + coverage + engine) FIRST, define-only,
# then the NSCLC config (delivered + build suite + QC_REGISTRY). Engine-first because the config CALLS the
# generators at source time. Build QC is strict by default, so set NSCLC_BUILD_ALLOW_PARTIAL before the config
# to get the non-required build shape the structural tests validate.
Sys.setenv(NSCLC_BUILD_ALLOW_PARTIAL = "1")
old_define <- Sys.getenv("QC_DEFINE_ONLY", "")
Sys.setenv(QC_DEFINE_ONLY = "1")
source(file.path(here, "qc_runner.R"))                         # %||% + generators + coverage + engine (handlers/CFG/run_all, no run)
if (nzchar(old_define)) Sys.setenv(QC_DEFINE_ONLY = old_define) else Sys.unsetenv("QC_DEFINE_ONLY")
source(file.path(here, "qc_nsclc_config.R"))                   # builds NSCLC_CHECKS + NSCLC_BUILD_CHECKS + QC_REGISTRY (offline; placeholders ok)

# Fields each handler reads to build its query (top-level presence check; relation specs validated separately).
REQUIRED <- list(
  row_count     = c("source", "table"),
  null_rate     = c("source", "table", "col", "max_pct"),
  domain        = c("source", "table", "col", "allowed"),
  schema        = c("source", "table", "manifest"),
  not_future    = c("source", "table"),                        # plus col OR cols (checked below)
  ordering      = c("source", "table", "lo", "hi"),
  rate          = c("predicate", "max_pct"),                   # plus single (source/table) OR join (left/right/by)
  unique_key    = c("source", "table", "keys"),
  referential   = c("left", "right"),
  no_fanout     = c("left", "right", "by"),
  no_row_loss   = c("left", "right", "by"),
  derive_equals = c("key", "product_table", "product", "raw"),
  bound         = c("product", "raw"),
  join_check    = c("left", "right"),
  expr          = c("r"),
  profile       = c("source"),
  drift         = c("old", "new")
)

test_that("the config assembles to a non-empty flat list of check lists", {
  expect_true(is.list(NSCLC_CHECKS))
  expect_gt(length(NSCLC_CHECKS), 0)
  for (i in seq_along(NSCLC_CHECKS)) {
    chk <- NSCLC_CHECKS[[i]]
    expect_true(is.list(chk) && !is.null(chk$type) && is.character(chk$type),
                info = sprintf("element %d is not a check list with a character `type`", i))
  }
})

# Both suites get the SAME deep structural validation — a build check with a missing field or a malformed
# relation spec must fail CI just like a delivered-product one.
ALL_CHECKS <- c(NSCLC_CHECKS, NSCLC_BUILD_CHECKS)

test_that("every check type has a registered handler (both suites)", {
  for (chk in ALL_CHECKS)
    expect_true(chk$type %in% names(handlers), info = sprintf("no handler for type '%s' (label: %s)",
                chk$type, chk$label %||% ""))
})

test_that("every check carries the fields its handler reads (both suites)", {
  for (chk in ALL_CHECKS) {
    lbl <- chk$label %||% "(no label)"
    req <- REQUIRED[[chk$type]]
    if (is.null(req)) next
    for (f in req)
      expect_false(is.null(chk[[f]]), info = sprintf("%s '%s' is missing required field `%s`", chk$type, lbl, f))
    if (identical(chk$type, "not_future"))
      expect_false(is.null(chk$col) && is.null(chk$cols), info = sprintf("not_future '%s' needs col or cols", lbl))
    if (identical(chk$type, "rate")) {
      has_single <- !is.null(chk$source) && !is.null(chk$table)
      has_join   <- !is.null(chk$left) && !is.null(chk$right) && !is.null(chk$by)
      expect_true(has_single || has_join, info = sprintf("rate '%s' is neither single-relation nor join form", lbl))
    }
  }
})

test_that("relation specs are lists with a table (both suites)", {
  spec_ok <- function(x, who) {
    if (is.null(x)) return(invisible())
    expect_true(is.list(x) && !is.null(x$table) && !is.null(x$source),
                info = sprintf("%s relation spec must be a list with source+table", who))
  }
  for (chk in ALL_CHECKS) {
    lbl <- chk$label %||% "(no label)"
    spec_ok(chk$left,  sprintf("%s '%s' left",  chk$type, lbl))
    spec_ok(chk$right, sprintf("%s '%s' right", chk$type, lbl))
    if (identical(chk$type, "bound")) { spec_ok(chk$product, lbl); spec_ok(chk$raw, lbl) }
    if (identical(chk$type, "derive_equals")) spec_ok(chk$raw, lbl)
  }
})

test_that("every expr check's r-string is syntactically valid R (parse, no eval)", {
  for (chk in ALL_CHECKS) if (identical(chk$type, "expr"))
    expect_error(parse(text = chk$r), NA, info = sprintf("expr '%s' r does not parse", chk$label %||% ""))
})

test_that("42.4 picks the right form and stays valid (count when the manifest is empty, schema when filled)", {
  # Branch-aware so filling NSCLC_COLUMNS later can't break CI: if 42.4 is the schema form, it carries a
  # manifest; if it's the count form, its r-string has resolved <expected_ncol> and still parses.
  old <- Sys.getenv("NSCLC_EXPECTED_NCOL", "")
  on.exit(if (nzchar(old)) Sys.setenv(NSCLC_EXPECTED_NCOL = old) else Sys.unsetenv("NSCLC_EXPECTED_NCOL"), add = TRUE)
  Sys.setenv(NSCLC_EXPECTED_NCOL = "150")
  senv <- new.env(parent = globalenv())
  sys.source(file.path(here, "qc_nsclc_config.R"), envir = senv)
  c424 <- Filter(function(c) identical(c$ref_id %||% "", "42.4"), get("NSCLC_CHECKS", envir = senv))[[1]]
  if (identical(c424$type, "schema")) {
    expect_true(length(c424$manifest) > 0, info = "42.4 schema form has an empty manifest")
  } else {
    expect_equal(c424$type, "expr")
    expect_false(grepl("<expected_ncol>", c424$r, fixed = TRUE), info = "42.4 still holds <expected_ncol> after the env is set")
    expect_error(parse(text = c424$r), NA)
  }
})

test_that("the schema verb detects missing, extra, and wrong-type columns (mocked DESCRIBE)", {
  # Drive the handler with a fake DESCRIBE result (no DB): rebind the global qdf to return a canned schema, then
  # run handlers$schema against a fixed manifest {patid=string, n=int} for each failure mode.
  expect_true("schema" %in% names(handlers))
  old_qdf <- get("qdf", envir = .GlobalEnv)
  on.exit(assign("qdf", old_qdf, envir = .GlobalEnv), add = TRUE)
  run_schema <- function(actual, manifest = list(patid = "string", n = "int"), allow_extra = FALSE) {
    assign("qdf", function(con, sql) data.frame(col_name = names(actual), data_type = unname(unlist(actual)),
             comment = NA_character_, stringsAsFactors = FALSE), envir = .GlobalEnv)
    handlers$schema(list(type = "schema", source = "product", table = "t",
                         manifest = manifest, allow_extra = allow_extra), NULL)
  }
  expect_true (run_schema(list(patid = "string", n = "int"))$pass)                                   # exact match
  expect_false(run_schema(list(patid = "string"))$pass)                                              # missing n
  expect_false(run_schema(list(patid = "string", n = "int", extra = "double"))$pass)                 # unexpected extra
  expect_false(run_schema(list(patid = "int", n = "int"))$pass)                                      # wrong type on patid
  expect_false(run_schema(list(patid = "string", n = "interval"))$pass)                              # int != interval (base-type match)
  expect_true (run_schema(list(patid = "string", amt = "decimal(10,2)"),
                          manifest = list(patid = "string", amt = "decimal"))$pass)                  # bare decimal accepts decimal(10,2)
  expect_false(run_schema(list(patid = "string", amt = "decimal(18,4)"),
                          manifest = list(patid = "string", amt = "decimal(10,2)"))$pass)            # parameterized -> exact precision required
  expect_true (run_schema(list(patid = "string", n = "int", extra = "double"), allow_extra = TRUE)$pass)  # extra allowed
})

test_that("no two checks share an exact label (traceability smell)", {
  labs <- vapply(NSCLC_CHECKS, function(c) c$label %||% "", character(1))
  dups <- unique(labs[duplicated(labs) & nzchar(labs)])
  expect_equal(length(dups), 0L, info = paste("duplicate labels:", paste(dups, collapse = " | ")))
})

# ---- coverage harness: registry + traceability metadata contract ----
# These enforce the gate contract offline: the metadata each check carries (ref_id/required) and the registry
# stay consistent, so a config/registry drift is caught in CI, not at a live run.

VALID_DISPOSITIONS <- c("implemented", "corrected", "build_pipeline", "subsumed",
                        "note", "retired_invalid", "out_of_scope")

test_that("the registry is the full 164-test inventory with no duplicate ids", {
  expect_equal(length(QC_REGISTRY), 164L)
  expect_equal(length(unique(names(QC_REGISTRY))), 164L)
  expect_true(all(QC_REGISTRY %in% VALID_DISPOSITIONS),
              info = paste("unknown disposition(s):", paste(setdiff(QC_REGISTRY, VALID_DISPOSITIONS), collapse = ", ")))
})

test_that("loop checks emit the expected multiplicity (a dropped item in a loop is caught)", {
  # For every id with a declared expected count, the config must emit EXACTLY that many checks — so removing
  # (say) 9 of 10 lab bounds under 20.4 fails here even though ref_id "20.4" is still present.
  counts <- table(Filter(nzchar, vapply(NSCLC_CHECKS, function(c) c$ref_id %||% "", character(1))))
  for (id in names(QC_EXPECTED_MULTIPLICITY)) {
    got <- if (id %in% names(counts)) as.integer(counts[[id]]) else 0L
    expect_equal(got, as.integer(QC_EXPECTED_MULTIPLICITY[[id]]),
                 info = sprintf("ref_id %s emits %d checks, expected %d", id, got, QC_EXPECTED_MULTIPLICITY[[id]]))
  }
})

test_that("registry ids match the reference .txt test ids exactly (parity, no drift)", {
  # Parse the actual reference suites and compare their `test_that("NN.N ...")` ids to the registry names, so a
  # test added to / removed from the reference can't silently leave the registry (and thus the coverage gate)
  # stale. Skips when the ref/ files aren't in this checkout — the other registry tests still run.
  ref_ids_of <- function(path) {
    if (!file.exists(path)) return(character(0))
    ls <- readLines(path, warn = FALSE)
    m  <- regmatches(ls, regexpr('test_that\\("[0-9]+\\.[0-9]+', ls))
    sub('test_that\\("', "", m)
  }
  ref_ids <- sort(unique(c(ref_ids_of(file.path(here, "ref", "test_nsclc_cohort.R.txt")),
                           ref_ids_of(file.path(here, "ref", "test_nsclc_cohort_merge_qc.R.txt")))))
  if (!length(ref_ids)) skip("reference .txt suites not present in this checkout")
  reg_ids <- names(QC_REGISTRY)
  expect_equal(length(ref_ids), 164L, info = sprintf("found %d reference ids, expected 164", length(ref_ids)))
  miss <- setdiff(ref_ids, reg_ids); extra <- setdiff(reg_ids, ref_ids)
  expect_equal(length(miss),  0L, info = paste("reference ids missing from registry:", paste(miss,  collapse = ", ")))
  expect_equal(length(extra), 0L, info = paste("registry ids not in the reference:",  paste(extra, collapse = ", ")))
})

test_that("every required check carries a non-empty ref_id", {
  for (chk in NSCLC_CHECKS) if (isTRUE(chk$required))
    expect_true(!is.null(chk$ref_id) && nzchar(chk$ref_id),
                info = sprintf("required check '%s' has no ref_id", chk$label %||% "(no label)"))
})

test_that("every emitted ref_id is known to the registry", {
  emitted <- unique(Filter(nzchar, vapply(NSCLC_CHECKS, function(c) c$ref_id %||% "", character(1))))
  unknown <- setdiff(emitted, names(QC_REGISTRY))
  expect_equal(length(unknown), 0L, info = paste("ref_ids not in the registry:", paste(unknown, collapse = ", ")))
})

test_that("gate contract: emitted required ref_ids == registry implemented+corrected ids", {
  # The coverage gate treats implemented/corrected as the MUST-RUN set. If a config check tagged required=TRUE
  # is not so classified in the registry (or vice versa) the run would mis-report completeness — fail loudly here.
  req_emitted <- sort(unique(Filter(nzchar,
    vapply(NSCLC_CHECKS, function(c) if (isTRUE(c$required)) c$ref_id %||% "" else "", character(1)))))
  reg_gating  <- sort(names(QC_REGISTRY)[QC_REGISTRY %in% c("implemented","corrected")])
  expect_equal(req_emitted, reg_gating,
               info = paste("in config not registry:", paste(setdiff(req_emitted, reg_gating), collapse = ", "),
                            "| in registry not config:", paste(setdiff(reg_gating, req_emitted), collapse = ", ")))
})

# ---- build-stage suite (the NSCLC_BUILD_CHECKS section of qc_nsclc_config.R): the build_pipeline checks ----

test_that("the build suite assembles to a flat list of non-required build_pipeline checks with handlers", {
  expect_true(is.list(NSCLC_BUILD_CHECKS) && length(NSCLC_BUILD_CHECKS) > 0)
  for (chk in NSCLC_BUILD_CHECKS) {
    lbl <- chk$label %||% "(no label)"
    expect_true(is.list(chk) && is.character(chk$type), info = sprintf("build element '%s' has no type", lbl))
    expect_true(chk$type %in% names(handlers), info = sprintf("no handler for build check type '%s' (%s)", chk$type, lbl))
    expect_false(isTRUE(chk$required), info = sprintf("build check '%s' must be required=FALSE", lbl))
    id <- chk$ref_id %||% ""
    # An UNTAGGED (ref_id="") entry is a non-empty support guard (like the delivered suite's), not a reference
    # test — it carries no registry id by design; only the tagged reference-test checks must map to build_pipeline.
    if (!nzchar(id)) next
    expect_true(id %in% names(QC_REGISTRY) && QC_REGISTRY[[id]] == "build_pipeline",
                info = sprintf("build check '%s' ref_id '%s' is not a registry build_pipeline id", lbl, id))
  }
})

test_that("the build suite emits exactly the registry's build_pipeline id set", {
  emitted <- sort(unique(Filter(nzchar, vapply(NSCLC_BUILD_CHECKS, function(c) c$ref_id %||% "", character(1)))))
  reg_bp  <- sort(names(QC_REGISTRY)[QC_REGISTRY == "build_pipeline"])
  expect_equal(emitted, reg_bp,
               info = paste("in build not registry-bp:", paste(setdiff(emitted, reg_bp), collapse = ", "),
                            "| registry-bp not emitted:", paste(setdiff(reg_bp, emitted), collapse = ", ")))
})

test_that("no two build checks share an exact label", {
  labs <- vapply(NSCLC_BUILD_CHECKS, function(c) c$label %||% "", character(1))
  dups <- unique(labs[duplicated(labs) & nzchar(labs)])
  expect_equal(length(dups), 0L, info = paste("duplicate build labels:", paste(dups, collapse = " | ")))
})

test_that("build QC is strict by default: every build check required and a placeholder-skip is INCOMPLETE", {
  # Re-source the config in an ISOLATED env in strict mode (the default — NSCLC_BUILD_ALLOW_PARTIAL unset), so
  # the global partial-mode NSCLC_BUILD_CHECKS the other tests use is untouched. Prove the strict branch: all
  # build checks required, and an all-skipped run reports INCOMPLETE (req_skipped alone drives it,
  # registry-independent). The build suite lives inside qc_nsclc_config.R; generators resolve via the parent
  # globalenv where qc_runner.R is loaded.
  old <- Sys.getenv("NSCLC_BUILD_ALLOW_PARTIAL", "")
  on.exit(if (nzchar(old)) Sys.setenv(NSCLC_BUILD_ALLOW_PARTIAL = old) else Sys.unsetenv("NSCLC_BUILD_ALLOW_PARTIAL"), add = TRUE)
  Sys.unsetenv("NSCLC_BUILD_ALLOW_PARTIAL")
  senv <- new.env(parent = globalenv())
  sys.source(file.path(here, "qc_nsclc_config.R"), envir = senv)
  strict_checks <- get("NSCLC_BUILD_CHECKS", envir = senv)
  expect_true(all(vapply(strict_checks, function(c) isTRUE(c$required), logical(1))),
              info = "not every build check is required=TRUE in strict (default) build mode")
  skipped <- lapply(strict_checks, function(c) {
    r <- res(c$label %||% "", c$type, info = TRUE)
    r$ref_id <- c$ref_id %||% ""; r$required <- isTRUE(c$required); r$skipped <- TRUE; r })
  cov <- qc_coverage_report(skipped)          # no registry — the required-skip path must stand alone
  expect_equal(cov$execution_status, "INCOMPLETE")
  expect_equal(cov$required_skipped, length(strict_checks))
})

# ---- qc_coverage_report(): the execution-vs-data-QC split, exercised on synthetic results (no DB) ----
mk <- function(ref_id, required, pass = TRUE, info = FALSE, skipped = FALSE, error = FALSE, detail = "") {
  r <- res(sprintf("check %s", ref_id), "row_count", pass = pass, detail = detail, info = info, error = error)
  r$ref_id <- ref_id; r$required <- required; r$skipped <- skipped; r
}

test_that("all required checks passed => COMPLETE / PASS", {
  cov <- qc_coverage_report(list(mk("14.1", TRUE, pass = TRUE), mk("14.2", TRUE, pass = TRUE)))
  expect_equal(cov$execution_status, "COMPLETE")
  expect_equal(cov$data_qc_result,   "PASS")
})

test_that("a required data failure => COMPLETE / FAIL (execution still complete)", {
  cov <- qc_coverage_report(list(mk("14.1", TRUE, pass = TRUE), mk("14.2", TRUE, pass = FALSE)))
  expect_equal(cov$execution_status, "COMPLETE")
  expect_equal(cov$data_qc_result,   "FAIL")
})

test_that("a required placeholder-skip => INCOMPLETE / NOT EVALUABLE (never a green data verdict)", {
  cov <- qc_coverage_report(list(mk("14.1", TRUE, pass = TRUE), mk("24.3", TRUE, skipped = TRUE, info = TRUE)))
  expect_equal(cov$execution_status, "INCOMPLETE")
  expect_equal(cov$data_qc_result,   "NOT EVALUABLE")
  expect_equal(cov$required_skipped, 1L)
})

test_that("a required errored check => INCOMPLETE / NOT EVALUABLE (structured, not text-matched)", {
  cov <- qc_coverage_report(list(mk("14.1", TRUE, pass = TRUE),
                                 mk("14.2", TRUE, pass = FALSE, error = TRUE, detail = "no connection: DSN not found")))
  expect_equal(cov$execution_status, "INCOMPLETE")
  expect_equal(cov$required_errored, 1L)
  expect_equal(cov$required_failed,  0L)   # an execution error is NOT counted as a data failure
})

test_that("an enabled NON-required check that fails is an optional finding, not a required failure", {
  cov <- qc_coverage_report(list(mk("14.1", TRUE, pass = TRUE), mk("30.10", FALSE, pass = FALSE)))
  expect_equal(cov$execution_status, "COMPLETE")
  expect_equal(cov$data_qc_result,   "PASS")   # required data-QC still passes
  expect_equal(cov$optional_failed,  1L)       # but the optional failure is surfaced
})

test_that("a NON-required EXECUTION error is an optional finding, not a required incompleteness", {
  cov <- qc_coverage_report(list(mk("14.1", TRUE, pass = TRUE), mk("30.10", FALSE, pass = FALSE, error = TRUE)))
  expect_equal(cov$execution_status, "COMPLETE")   # a non-required error does NOT make the run incomplete
  expect_equal(cov$data_qc_result,   "PASS")
  expect_equal(cov$optional_failed,  0L)           # not a data failure
  expect_equal(cov$optional_errored, 1L)           # surfaced as an optional error (drives the REVIEW header)
})

test_that("a registry implemented id with no emitted check => absent => INCOMPLETE", {
  reg <- c("14.1" = "implemented", "14.2" = "implemented")   # 14.2 has no result below
  cov <- qc_coverage_report(list(mk("14.1", TRUE, pass = TRUE)), registry = reg)
  expect_equal(cov$execution_status, "INCOMPLETE")
  expect_true("14.2" %in% cov$absent_required)
})

test_that("non-required (build_pipeline) skips do NOT make the run incomplete", {
  cov <- qc_coverage_report(list(mk("14.1", TRUE, pass = TRUE), mk("30.10", FALSE, skipped = TRUE, info = TRUE)))
  expect_equal(cov$execution_status, "COMPLETE")
  expect_equal(cov$data_qc_result,   "PASS")
})

# ---- SQL-builder unit tests (no DB): the shared string builders every verb composes its query from ----
# These catch a builder regression (e.g. a composite-key join emitting the wrong ON clause, which several
# checks like 36.4 rely on) at the string level, without a Databricks connection.

test_that("bt/sqs quote identifiers and string literals correctly", {
  expect_equal(bt("patid"), "`patid`")
  expect_equal(sqs("AdvancedNSCLC"), "'AdvancedNSCLC'")
  expect_equal(sqs("O'Brien"), "'O''Brien'")               # single quote doubled
})

test_that("join_on builds the ON clause for same-name and differing composite keys", {
  expect_equal(join_on("patientid"), "l.`patientid` = r.`patientid`")
  expect_equal(join_on(c("patientid", "testdate")),
               "l.`patientid` = r.`patientid` AND l.`testdate` = r.`testdate`")
  expect_equal(join_on(list(left = c("patid", "bpdt"), right = c("patientid", "testdate"))),
               "l.`patid` = r.`patientid` AND l.`bpdt` = r.`testdate`")
})

test_that("join_on rejects empty or unequal-length key vectors (no silent recycling)", {
  expect_error(join_on(character(0)))
  expect_error(join_on(list(left = c("a", "b"), right = "c")))
})

test_that("and_filter / whereof compose predicates and only emit WHERE when non-empty", {
  expect_equal(and_filter("a = 1", "b = 2"), "(a = 1) AND (b = 2)")
  expect_equal(and_filter("a = 1", NULL), "a = 1")
  expect_equal(and_filter("a = 1", ""), "a = 1")
  expect_equal(whereof("x > 0"), " WHERE x > 0")
  expect_equal(whereof(NULL), "")
  expect_equal(whereof(""), "")
})
