#!/usr/bin/env Rscript
# Run NSCLC data-product QC. This is the entry point — the other two files are qc_runner.R (the engine and
# reusable checks) and qc_nsclc_config.R (the NSCLC checks and inventory).
#
# It loads the engine without running it, loads the config (which builds the check lists using the engine's
# generators), points the run at the right suite and your schemas, and runs.
#
# Two modes:
#   default        the delivered-product suite (checks the built product against the raw sources).
#   NSCLC_BUILD=1  the build-stage suite (checks the build-time intermediate <...> tables). Strict by default:
#                  an unmapped or empty intermediate fails the run. Set NSCLC_BUILD_ALLOW_PARTIAL=1 in dev to
#                  run only the wired subset without failing.
#
# Run (delivered):
#   DATABRICKS_DSN=RWDE DATABRICKS_PWD=... \
#   NSCLC_RAW_SCHEMA=<raw> NSCLC_PRODUCT_SCHEMA=<built> NSCLC_PRODUCT_TBL=<product_table> \
#   NSCLC_CUT=2026m06 NSCLC_EXPECTED_NCOL=<column_count> \
#   Rscript qc_run_nsclc.R
# Run (build stage): add  NSCLC_BUILD=1  and map the <...> intermediates in the config (strict by default).
#
# NSCLC_CUT is appended to every raw table name (t_demographics -> t_demographics_2026m06); leave it unset for
# unsuffixed views. Any check still holding a <placeholder> skips itself, so a partial wiring runs what's ready
# and never false-passes. NSCLC_EXPECTED_NCOL is the approved column count 42.4 checks — until it's set, 42.4
# skips and the run reports INCOMPLETE. Don't set QC_NO_EXPR=1 here: the suite needs its expr checks.

here <- tryCatch(dirname(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))),
                 error = function(e) ".")
if (!length(here) || here == "") here <- "."

# Load the engine (helpers, generators, coverage, engine) but don't run it — QC_DEFINE_ONLY holds back the
# auto-run at the bottom of qc_runner.R. It must load before the config, which calls the generators.
old_define <- Sys.getenv("QC_DEFINE_ONLY", "")
Sys.setenv(QC_DEFINE_ONLY = "1")
source(file.path(here, "qc_runner.R"))
if (nzchar(old_define)) Sys.setenv(QC_DEFINE_ONLY = old_define) else Sys.unsetenv("QC_DEFINE_ONLY")

# Build the checks (delivered + build suites + the inventory).
source(file.path(here, "qc_nsclc_config.R"))

# Label the report/traceability for this product (the engine default is generic).
if (!nzchar(Sys.getenv("QC_PRODUCT_LABEL", ""))) Sys.setenv(QC_PRODUCT_LABEL = "NSCLC")

# Point the sources at your catalogs + schemas (catalog defaults to the engine's, override per environment).
raw_schema      <- Sys.getenv("NSCLC_RAW_SCHEMA", "")
product_schema  <- Sys.getenv("NSCLC_PRODUCT_SCHEMA", "")
raw_catalog     <- Sys.getenv("NSCLC_RAW_CATALOG", "")
product_catalog <- Sys.getenv("NSCLC_PRODUCT_CATALOG", "")
if (nzchar(raw_schema))      CFG$sources$raw$schema      <- raw_schema
if (nzchar(product_schema))  CFG$sources$product$schema  <- product_schema
if (nzchar(raw_catalog))     CFG$sources$raw$catalog     <- raw_catalog
if (nzchar(product_catalog)) CFG$sources$product$catalog <- product_catalog

# Pick the suite. Build mode also drops the inventory, which lists the delivered checks a build run doesn't emit.
build_mode <- tolower(Sys.getenv("NSCLC_BUILD", "")) %in% c("1", "true", "yes", "t")
if (build_mode) {
  CFG$checks          <- NSCLC_BUILD_CHECKS
  CFG$allow_info_only <- !isTRUE(BUILD_STRICT)
  if (exists("QC_REGISTRY", envir = .GlobalEnv)) rm("QC_REGISTRY", envir = .GlobalEnv)
} else {
  CFG$checks <- NSCLC_CHECKS
}

# Preflight: fail FAST (before connecting) on the wiring a run needs, so a mis-config is a clear message, not a
# late error or a vacuous run. QC_PREFLIGHT=0 skips it (e.g. an intentionally partial dev run).
if (!identical(Sys.getenv("QC_PREFLIGHT", "1"), "0")) {
  gaps <- c(
    if (!nzchar(CFG$sources$raw$schema))     "NSCLC_RAW_SCHEMA (raw schema)",
    if (!nzchar(CFG$sources$product$schema)) "NSCLC_PRODUCT_SCHEMA (product schema)",
    if (!nzchar(CFG$sources$raw$catalog))    "raw catalog (NSCLC_RAW_CATALOG or the CFG default)",
    if (!nzchar(CFG$sources$product$catalog)) "product catalog (NSCLC_PRODUCT_CATALOG or the CFG default)",
    if (!build_mode && !nzchar(Sys.getenv("NSCLC_PRODUCT_TBL", ""))) "NSCLC_PRODUCT_TBL (built product table)",
    if (!build_mode && !length(NSCLC_COLUMNS) && !grepl("^[1-9][0-9]*$", Sys.getenv("NSCLC_EXPECTED_NCOL", "")))
      "NSCLC_EXPECTED_NCOL or a filled NSCLC_COLUMNS manifest (42.4)")
  if (length(gaps))
    stop(sprintf("qc_run_nsclc preflight: not configured to run — missing:\n  - %s\nSet these (or QC_PREFLIGHT=0 for a partial dev run).",
                 paste(gaps, collapse = "\n  - ")))
}

run_all()
