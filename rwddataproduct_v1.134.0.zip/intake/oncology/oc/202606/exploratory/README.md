# FRalpha status by treatment — ovarian

FOLR1/FRalpha status at index, cross-tabbed against treatment arm (Mirvetuximab vs
ICC), for ovarian patients on 2L–4L lines (ICC restricted to single-agent; see below).
Runs on local data frames with dplyr, so it needs no Spark.

Source: Databricks `hive_metastore.clnprw_flatiron_pano_ovar_use` (`t_drugepisode_2026m06`,
`t_enh_ovbiomarkers_2026m06`).

## Files

- `code/fralpha_by_treatment.R` — the analysis; opens the Databricks connection and builds Table 1.

## What it builds

Two tables of patient counts (within-arm %), FRalpha status × arm:

- **Table 1a** — all 2L–4L lines (any setting).
- **Table 1b** — advanced setting only, built independently (first qualifying advanced
  dose in that arm, its own index).

**Population** (`t_drugepisode_2026m06`): 2L–4L, non-maintenance lines of Mirvetuximab or
ICC (paclitaxel, PLD, or topotecan). **Arms are non-exclusive — a patient can be in both.**
The Mirvetuximab arm is any line carrying mirvetuximab (combinations allowed). The ICC arm
is a **single-agent** qualifying ICC line (a platinum doublet is not ICC), **or** a line
carrying both mirvetuximab and an ICC drug — that cross-arm line counts in **both** arms.
Each arm indexes independently on the patient's **first qualifying dose of that arm** (so a
patient on mirvetuximab at 2L and 4L indexes at 2L). nab-paclitaxel is not a qualifying ICC
drug. The run summary reports the Mirv and ICC counts and how many patients are in both.

**FRalpha** (`t_enh_ovbiomarkers_2026m06`, `biomarkername = "FOLR1/FRalpha"`): per record,
high = PercentStaining ≥ 75 & intensity 2+/3+; moderate = 50–<75 & 2+/3+; low = <50 or
≤1+; else unknown. Biomarker date = max(specimen received, result). Among records dated
≤ index + 14 days, take the highest class (high > moderate > low > unknown); no record →
unknown. Every patient stays in the denominator.

The run stops on: no matching FOLR1 records; an out-of-range PercentStaining scale; an
invalid `FRA_PCT_SCALE` (plus, under `FRA_PCT_SCALE=auto`, a mixed fraction/percent
scale). It warns (does not stop) if no PercentStaining parses.

## Run

```bash
# Databricks (default): opens an ODBC connection and reads catalog.schema.table —
# set the DSN and password first:
export DATABRICKS_DSN=RWDE DATABRICKS_PWD=...
Rscript code/fralpha_by_treatment.R

# local extracts instead:
FRA_SOURCE_MODE=local FRA_LOCAL_DIR=/path/to/extracts Rscript code/fralpha_by_treatment.R
```

Results write to an `outputs/` folder next to the script (e.g. `code/outputs/`; override
with `FRA_OUT_DIR`). Apply small-cell suppression before sharing.

## Check first (data checks — described here; no .sql was captured in the freeze)

1. **FOLR1 snapshot + name** — which `t_enh_ovbiomarkers_*` table to use, and the exact
   `biomarkername` string (§0–2).
2. **PercentStaining scale** — whether values are a fraction (0–1) or a percent (0–100);
   set `FRA_PCT_SCALE` accordingly (§3). This moves the 50/75 cutoffs.
3. **Codelist + line composition** — confirm the drug matches (esp. PLD is pegylated) and
   that single-agent lines really have one agent, against the delivered values (§5, §8).

Section 10 rebuilds Table 1a/1b in SQL as an independent cross-check (set the scale from §3).

---

# Data characterization & exploration

Two more scripts for the follow-up exploration asks.

## `platform/tools/data_profiler.R` — characterize any table

> Lives in `platform/tools/`, not in this folder: it is shared, tumour-agnostic platform code that
> every pack's Gate 3 evidence comes from, so it must ship wherever the platform ships. Run the
> commands below **from the repo root**.

Points at a schema and writes a stakeholder report — per-column distribution and
missingness for every table. Standalone and tumor/product-agnostic (set the catalog/schema/cut;
nothing OC-specific is baked in), reusable across snapshots (new or old); it's how you answer
"summarize distribution and missingness for all new variables". New columns (added vs the
baseline) are tagged.

Set the feed one of two ways: **edit the `CFG` block at the top of `data_profiler.R`** (`schema` is
required and blank by default, so a copy can't silently profile the wrong product — set it to yours),
or pass the matching `DC_*` env vars (env overrides `CFG`). The OC schema is
`clnprw_flatiron_pano_ovar_use`.

```bash
export DATABRICKS_DSN=RWDE DATABRICKS_PWD=...
# catalog + schema differ per tumor/product. Either edit the CFG block in data_profiler.R,
# or set them here (env wins over CFG):
export DC_CATALOG=hive_metastore DC_SCHEMA=clnprw_flatiron_pano_ovar_use   # OC; use each product's own
# outputs default to ./outputs in the working dir; point them at this folder so the
# compare_snapshots.R paths further down line up:
export DC_OUT_DIR=intake/oncology/oc/202606/exploratory/code/outputs
Rscript platform/tools/data_profiler.R                       # all tables in the schema
DC_TABLES="t_drugepisode_2026m06,t_enh_ov_platstatus_2026m06" Rscript platform/tools/data_profiler.R
```

Writes each run into a per-cut `<DC_OUT_DIR>/<cut>/` folder with snapshot-stamped names:
`data_characterization_<cut>.html` (open in a browser) + `.md`, `inventory_<cut>.txt`,
`catalogue_<cut>.txt`, and a machine-readable `profile_<cut>.tsv` (per-column metrics for the
snapshot comparison; named `profile_new_<cut>.tsv` in `DC_NEW_ONLY` mode since it's a partial
profile). A **different** cut can't overwrite another's files, but **re-running the same cut
overwrites** it — for an immutable archive point `DC_OUT_DIR` at a unique per-run directory. Big tables
get a reproducible random sample (`DC_SAMPLE_N` rows, default 200,000; seed `DC_SAMPLE_SEED`)
— sampled sections say so and their metrics are estimates. **Use `DC_SAMPLE_N=0` for exact
final numbers.** `DC_SOURCE_MODE=local` + `DC_LOCAL_DIR` reads `.parquet`/`.csv` extracts.
The report lists the most common values of each low-cardinality column, so raw labels (site,
provider, free text) can show up in it — no patient rows, but give it a look before sharing widely.
Missingness counts `NULL`/`NA`/blank strings by default — sentinel values like `"Unknown"` or `"Not
documented"` are treated as their own category, so read a high "Unknown" share off the distribution
column, not the missingness column. If a feed's docs define such tokens as missing, opt in with
`DC_MISSING_TOKENS="Unknown,Not documented"` (matched case-insensitively). `n` is the number of
**table rows profiled** — episode-level for an episode table, patient-level for a one-row-per-patient
table — not necessarily unique patients, and a sampled run's `n` is the sample size.

Types: a variable's **kind** (numeric / categorical / date) is inferred — a numeric column with more than
`DC_NUMERIC_CAT_MAX` distinct values is summarised as continuous, otherwise as a category list; ISO-date
strings get a range. Inference can't know clinical semantics, so **reconcile each new variable's kind
against the data dictionary** and correct with `DC_KIND_OVERRIDES="col=numeric,col2=categorical"` (keyed
by **column name**, so an override applies to that column in every table it appears in). 64-bit
integers are read as **character** (exact — a large id as an R double can lose precision and collapse
distinct values), so identifiers read as high-cardinality categoricals (the right treatment); a genuine
numeric measure delivered as a big integer or a string can be forced back with `col=numeric`, which now
**coerces** the character values to numeric (unparseable values are counted, not dropped).

### Comparing snapshots (the growing list)

Each run writes, in `outputs/<cut>/`, an `inventory_<cut>.txt` (the `tablebase|column` list for
**this drop only**) — feed the previous drop's inventory back in as `DC_BASELINE_COLS` and the
report gains a **Changes vs baseline** section (added/dropped tables and columns) and flags each
new column. Keeping the baseline to one drop means a column dropped once shows as dropped once,
not on every later drop. `catalogue_<cut>.txt` is **this drop's columns plus whatever baseline you
fed in** (not a true cross-drop "ever seen" list unless you keep feeding the prior catalogue back);
it's kept separate so it doesn't muddy the per-drop diff, and it's optional — the key file is
`inventory_<cut>.txt`. Each run also writes `profile_<cut>.tsv` — per-column metrics (counts,
missingness rate, distinct, numeric quantiles, top values) that feed the data-level snapshot comparison.

**Focused / cheaper modes** (the direct answer to the "new variables" ask): `DC_INVENTORY_ONLY=1`
writes only the column inventory, reading no data rows — use it for the *old* snapshot. `DC_NEW_ONLY=1`
(with a baseline) profiles **only the newly-added columns** and leads the report with a compact **New
variables** table (table · variable · kind · n · missing n/% · distribution), keeping the full
per-column profile below. `DC_REQUIRE_BASELINE=TRUE` refuses to run without both `DC_BASELINE_COLS`
and `DC_CUT` — use it for a formal old→new run so a forgotten cut can't merge two snapshots.

Each `inventory_<cut>.txt` carries a `#`-commented **provenance header** (catalog, schema, cut, scope,
cut_regex, cut_filter_regex, generated, and `product` when `DC_PRODUCT_ID` is set). When it's fed back
as `DC_BASELINE_COLS`, the run verifies it: a baseline from a different product/schema, a different
`cut_regex` or table-selection regex (incompatible table-name normalization / different table universe),
a different table scope, one whose cut equals this run's, or one whose cut is **newer** than this run's
(a likely swapped old/new — the baseline should be the prior snapshot; checked for recognized cut formats
`YYYYmMM`/`YYYYqN`/`YYYYMM`/`YYYY`, skipped for custom formats) all **warn**, and **hard-error under
`DC_REQUIRE_BASELINE`**. Scope is compared as normalized table *bases* (order- and cut-suffix-insensitive,
so `t_x_2026m03` and `t_x_2026m06` read as the same scope; a real difference makes added/dropped
unreliable, so formal mode stops). **Formal mode is strict about provenance**: it *rejects* (not warns) a
baseline missing this tool's header, a `cut=all` baseline (it may combine snapshots), any malformed
`tablebase|column` line, or **any missing manifest field** — catalog, schema, cut, scope, cut_regex,
cut_filter_regex (and `product` when `DC_PRODUCT_ID` is set) — so no identity/normalization/scope check is
silently skipped. Because it compares the two `cut_regex` / `cut_filter_regex` strings **literally**, strict
mode requires the **same selection expression on both runs**: a feed whose old and new snapshots genuinely
need *different* table-selection regexes (e.g. prefix-based `^2026m03__` vs `^2026m06__`, not the supported
`_<cut>$` suffix) must use one cut-insensitive expression that matches both drops, or run without
`DC_REQUIRE_BASELINE` and verify scope by hand. Without formal mode, a headerless (older) inventory only warns that provenance can't be
verified, and malformed inventory lines are dropped with a warning. If the two snapshots live in
**cut-specific schemas** (same product, different `DC_SCHEMA`), set `DC_PRODUCT_ID` on **both** runs — the
wrong-product check then compares the product id, so the schema is allowed to change; strict mode enforces
that the baseline actually carries it. The
report also records the output-affecting settings (`missing_tokens`, `numeric_cat_max`, `top_n`,
`kind_overrides`, `product_id`, `cut_filter_regex`) so an archived copy is reproducible.

The report's inline **Changes vs baseline** is schema-level: it catches added and dropped tables
and columns, not type, category, missingness, or distribution shifts. Those data-level shifts are
captured by the per-run `profile_<cut>.tsv` files, which a comparison step diffs across two drops.
Give both runs the same table scope — if the
new run uses `DC_TABLES` to profile a subset, "dropped" partly reflects that subset (the report
says so). Character columns that look like dates are summarised as a range; any non-blank values
that fail to parse are reported as an "unparseable" count so a mostly-clean date column can't
hide a few bad values. (One column that leaves and later returns is flagged "new" again on its
return, since the baseline is the prior drop; a `catalogue.txt` that you keep feeding back each drop
is where you'd check whether it was ever seen — a single drop's catalogue is only that drop ∪ its
baseline, not a full history.)

The **recommended** old→new run for the "new variables" ask — old is inventory-only (no data read),
new profiles only the added columns, exact, in formal mode (needs baseline + cut):

```bash
export DC_CATALOG=hive_metastore DC_SCHEMA=clnprw_flatiron_pano_ovar_use   # set per product
export DC_OUT_DIR=intake/oncology/oc/202606/exploratory/code/outputs
# 1. prior snapshot — inventory only, reads no data rows
DC_CUT=2026m03 DC_INVENTORY_ONLY=1 Rscript platform/tools/data_profiler.R
# 2. new snapshot — profile only the added columns; report leads with the New-variables table
DC_CUT=2026m06 DC_NEW_ONLY=1 DC_REQUIRE_BASELINE=TRUE DC_SAMPLE_N=0 \
  DC_BASELINE_COLS=intake/oncology/oc/202606/exploratory/code/outputs/2026m03/inventory_2026m03.txt Rscript platform/tools/data_profiler.R
```

Drop `DC_INVENTORY_ONLY` / `DC_NEW_ONLY` to **fully** profile every column on both sides — needed only
if you also want the `profile_<cut>.tsv` drift inputs for `compare_snapshots.R` (existing-variable QA,
not part of the new-variables ask):

```bash
DC_CUT=2026m03 Rscript platform/tools/data_profiler.R
DC_CUT=2026m06 DC_BASELINE_COLS=intake/oncology/oc/202606/exploratory/code/outputs/2026m03/inventory_2026m03.txt Rscript platform/tools/data_profiler.R
```

`DC_CUT` restricts to tables ending in that cut, so it works whether the two snapshots share
a schema (both `t_*_2026m03` and `t_*_2026m06`) or live apart (use `DC_SCHEMA` instead). Feed
each drop's `inventory.txt` in as the next drop's baseline for the per-drop diff, and chain the
`catalogue.txt` forward (feed each drop's catalogue in as the next baseline) if you want a running
ever-seen list — a lone catalogue is only that drop plus its baseline. Without a baseline, nothing is
flagged as new unless you pass a manual hint via `DC_KNOWN_NEW_TABLES` / `DC_KNOWN_NEW_COLS`
(no tumor-specific defaults ship, so the one script stays reusable across products) — the report
header says which mode. A `DC_BASELINE_COLS` path that is set but not found is a hard error, so a
typo can't silently skip the comparison.

### Data-level comparison — `code/compare_snapshots.R`

The two runs above each leave a `profile_<cut>.tsv` in their snapshot folder. Diff two of them for
a **data-level** drift report — missingness, distributions and counts, not just added/dropped
columns:

```bash
Rscript code/compare_snapshots.R \
  code/outputs/2026m03/profile_2026m03.tsv \
  code/outputs/2026m06/profile_2026m06.tsv
```

Writes **two HTML reports** (plus `snapshot_comparison.md` as the full record):

- `code/outputs/data_refresh_change_summary.html` — **stakeholder** view. Leads with the columns whose
  **values** changed, in plain language with exact old→new evidence, most material first, then table
  row counts and a schema-change summary. Short, print-friendly.
- `code/outputs/snapshot_comparison.html` — **technical** detail. Every signal, the change-family
  composition, the full schema diff, and the thresholds/formulas.
- `code/outputs/snapshot_comparison.md` — the full record; `snapshot_comparison_signals.tsv` — a
  machine-readable per-variable comparison (every shared column, all metrics) for audit.

A **review signal** is a real change in the data a stakeholder acts on: **completeness** (missingness as
a rate, `pct_missing`, with `n_missing / n_rows` shown so a shift traces to numerator vs denominator);
**numeric distribution** via SMD = (mean_new − mean_old) / pooled SD plus per-quantile shifts for
shape/tails; **category-mix** share changes; **date quality** (range regression / new unreadable dates);
and a true **storage-type** change. A **profiler-interpretation** change (`KIND` numeric↔categorical) or
a bare **cardinality** change is *not* a review signal — it's a by-product of the profiler's
numeric-vs-categorical threshold, not a source-data change, so it's reported only as a structural note in
the technical detail. Thresholds are editable in the `CFG` block (or `CMP_*` env vars); optional header
metadata comes from `CMP_PRODUCT` / `CMP_RUN_ID` / `CMP_THRESHOLDS_LABEL`. It reads only the profiler's
`.tsv` files, so it never re-queries Databricks. Flags are magnitude-based **candidates to review**;
clinical significance is a human judgment, and the QC pass/fail verdict is produced separately by
`qc_runner.R`.

## `code/qc_runner.R` — config-driven QC at any stage

One runner for QC across the whole pipeline: the **raw source feed** (before/at ingestion), the
**built data product** (after creation), and **raw → product reconciliation**. You edit one `CFG`
block with three lists — `sources` (the named "ends", each a catalog/schema), `checks` (each
`list(type=…, args)`, the ones that run), and `examples` (a copy-paste library of every verb,
**not** run) — and every check names the source it runs against, so the same runner covers every
stage with no code edits.

**This is a template — edit it before running, not a safe run-as-is config.** Like the profiler,
source schemas are **blank and required** (`CFG$sources$raw$schema` / `$product$schema`): a run
fails loud if they're unset, so a copy can't silently query the OC schema for another tumor. The
default `checks` are **cheap** OC-flavoured rule checks (one COUNT each — t_drugepisode / t_enh_ov),
so a first run after just setting the schemas is quick; the heavier `profile`/`drift` orchestration
(exact full-schema profiles, environment-specific paths) lives in `examples`, opt-in. Replace the
tables/cols for your product. Any check still carrying a `<placeholder>` table name (e.g. one copied
from `examples` without editing) is skipped as an *info* row, not run.

### Applying it to another tumor / another refresh (year)

The verb library is tumor- and year-agnostic; everything product-specific is in the `CFG` block, so
"apply it elsewhere" = **edit `CFG`** (or keep one edited copy per tumor+refresh — e.g.
`qc_runner_<tumor>_2026m06.R`). There is no external-config loader; the config is inline by design.

1. **Point the sources at the tumor.** Set `CFG$sources$raw$schema` (and `$product$schema`) to that
   product's schema — e.g. `clnprw_flatiron_<tumor>_use`. `catalog` is usually the shared metastore.
   Blank-required means a forgotten schema stops the run rather than hitting OC.
2. **Rewrite `checks` for that tumor's tables/columns/domains.** The cut/year is part of each table
   name (`t_drugepisode_2026m06`), so a **different refresh** just means the new cut suffix on the
   table names (and `cut=` on any `profile` check). Copy patterns from `examples`; delete the OC ones.
3. **Guard each critical relation** with `row_count(min = 1)` first (row-oriented verbs pass vacuously
   on an empty table), and use `require_valid = TRUE` / `as_date = TRUE` on date checks over
   character-delivered dates.
4. **Year-over-year drift:** run the profiler on each cut to get `profile_<cut>.tsv`, then a `drift`
   check (in `examples`) diffs the old vs new full profiles — never a partial `profile_new_*`.
5. **Governed runs:** set `QC_NO_EXPR=1`, point `QC_OUT` at a unique per-run folder, and archive the
   exact edited `CFG` (the report records the resolved `catalog.schema` per source but not the full
   check list). Reports can contain low-cardinality raw values, so keep them in restricted storage.

```bash
DATABRICKS_DSN=RWDE DATABRICKS_PWD=... Rscript code/qc_run_nsclc.R   # writes qc_report.html/.md; exit 1 if any check fails
Rscript -e 'testthat::test_file("code/qc_run_nsclc.R")'             # same checks as test_that() cases
```
(Run via the launcher — `qc_runner.R` is the engine and ships with an empty check list, so running it on its
own asserts nothing.)

Two outputs from one file: a human-readable `outputs/qc_report.html` (+ `.md`) **and** a non-zero
exit on failure (CI gating), plus each check registers as a `test_that()` case under
`testthat::test_file()`. Each rule check pushes one — or for a few verbs a small number of — COUNT
queries to Databricks (no table pulls): `row_count`-compare, `no_fanout`/`no_row_loss` and
`derive_equals` run two, and `domain` adds a sample query only on failure.

The HTML report is stakeholder-first (the `.md` stays the full technical record). It opens with an
executive summary — pass/fail/info cards, a segmented bar, and one factual sentence — then
**Failures requiring attention** (only the failing checks, the one section a reviewer must read; an
all-clear note when there are none), a **Coverage by dimension** table, and finally **All checks**
grouped by dimension. Dimensions fold the ~16 verbs into the quality areas a reviewer reasons about
— Volume, Completeness, Validity, Keys & integrity, Reconciliation, Profiling & drift, Custom check,
Run integrity — so the report reads as *which area* is failing, not a flat list of verb names; the
verb itself stays in each row's Type column.

Verb library (config, no logic edits): `domain` (allowed value set), `not_future` (one date column
or several via `cols`), `ordering` (colA ≤ colB, with an optional `offset_days` for windows like
`testdate ≤ indexdt + 14`), `null_rate` (missingness ≤ threshold), `rate` (share of rows — single
relation or a join — matching a predicate ≤ threshold), `unique_key` (1:1 safety), `referential`
(no orphan keys; multi-column keys + per-side filters), `row_count` (a count within bounds, or
compared `<=`/`==`/… to another relation's count), `no_fanout` / `no_row_loss` (join cardinality
preserved), **`derive_equals`** (a product column equals an aggregate **or a mapping `expr`** of raw,
per key, with an optional numeric `tolerance` / `tolerance_days`), `bound` (`agg(product) <op>
agg(raw)` for `agg` ∈ min/max/sum/avg, global or per key, e.g. final max ≤ raw max — set `cast="double"`
/`"date"` when the columns are numbers/dates stored as strings, else the aggregate is lexical), `join_check` (join two relations and assert
no `predicate` violations, or no fan-out / no loss — windows, same-date pairings), and an `expr`
escape hatch (a user R expression returning the count of violations). **Every table-target verb also
takes an optional `filter`** (a SQL `WHERE` fragment) so a check can target a filtered/derived subset
— e.g. "LOT1 non-maintenance rows are 1:1 per patient" — not just a whole table; join verbs take
`left`/`right` relation specs `{source, table, filter, select, distinct}`. `profile` and `drift`
shell out to `data_profiler.R` / `compare_snapshots.R`, so there's one config surface over
everything. `QC_DEFINE_ONLY=1 Rscript code/qc_runner.R` parses the file without connecting.

These verbs give **broad** coverage of cross-tumor raw→product and merge-QC checks (allowed
values, date windows, 1:1 / fan-out / row-loss on filtered dimension tables, referential integrity,
count-vs-count, value-mapping and aggregate-bound derivations) as **config** — not literal complete
parity: a check that operates on an *aggregated intermediate* relation (group-then-check, e.g. LOT1's
min-startdate-per-patient) needs either a materialized intermediate table or the `expr` hatch, which
also stays the fallback for a bespoke multi-CTE check. Gating and empty-data behaviour to rely on:
`no_row_loss` / `join_check(no_loss)` count unmatched left rows via an anti-join (an inner-join
row-count compare can false-pass when loss and fan-out offset); `null_rate` / `rate` / `bound` do
**not** treat a zero-row or all-NULL relation as a pass (they flag it unless `allow_empty=TRUE`); and
a nonzero `profile` / `drift` subprocess exit is a **failure** that drives the exit code, not an info
line. Note the row-oriented verbs (`domain`, `not_future`, `ordering`, `unique_key`, `referential`,
`no_fanout`) are **vacuously true on a zero-row table** — a silently-empty source would pass them all,
so guard every critical input with a `row_count`, `min = 1` check first (the default config shows the
pattern). A `row_count` with **none** of `expected`/`min`/`max`/`compare` asserts nothing, so it **fails**
as a mis-config (rather than passing vacuously and satisfying the "≥1 assertion" guard) — set
`informational = TRUE` to just report the count as a non-gating row. `not_future` casts to date with `try_cast`, so by default it proves "no *parseable* future
date" — add `require_valid=TRUE` to also flag a non-blank value that fails to parse (fail-closed date QC).
`ordering` compares the raw columns by default (correct for native date/timestamp and numeric columns);
for **character** date columns set `as_date=TRUE` (or `require_valid=TRUE`) so it casts to date — otherwise
non-ISO strings would sort lexicographically. `offset_days` (e.g. `≤ indexdt + 14`) implies the date cast. A run with **no runnable pass/fail assertion** (empty `checks`, only placeholders, or only info
steps) **fails** unless `allow_info_only=TRUE` / `QC_ALLOW_INFO_ONLY=1`, so a mis-wired config can't exit
0 without checking anything — and that failure now shows as a row in the report, not just in the exit
code. `drift` needs **complete** profiles: it rejects a `profile_new_<cut>.tsv` (partial, new-columns-only)
input, so an accidental partial drift fails instead of silently comparing a subset. Reconciliation verbs are **fail-closed on unmatched keys** by
default: per-key `bound` and tolerance-mode `derive_equals` treat a key present on only one side (keyed
on the raw *key* via the join, not on value-nullness, so a null product value with no raw match is
still caught) as a mismatch — set `allow_unmatched=TRUE` to compare only matched keys. Both tolerance
bands of `derive_equals` are **fail-closed on an unparseable value**: `tolerance_days` casts to date and
`tolerance` casts to double, and a non-null value that fails to cast counts as a mismatch (otherwise its
`try_cast` would be NULL and the diff silently wouldn't count). `derive_equals` in **mapping mode**
(`raw$expr`) assumes the raw side is 1:1 on the key but doesn't group, so a duplicated raw key fans the
product row out — set `require_unique_raw=TRUE` to assert raw-key uniqueness first (the aggregate mode is
immune, it `GROUP`s by key). A cast `bound` **skips** values that fail `try_cast` (min/max/sum/avg ignore
NULLs), so it can pass while some source values were invalid — set `require_valid=TRUE` (with `cast`) to
also fail on a non-blank value that doesn't parse. Join keys are
length-validated (`by` / `left$col`/`right$col` must be non-empty and equal length) so an unequal
vector can't silently recycle into a wrong join. The `expr` hatch runs arbitrary R with the live
connection, so it's expert-only; a governed run can set `QC_NO_EXPR=1` to reject every `expr` check.
The connection is opened lazily, so a `drift`/`profile`-only run needs no DB credentials; each `drift`
check writes to its own labelled folder so several don't overwrite. The `profile` verb forwards the
profiler's flags (`cut`, `baseline`, `inventory_only`, `new_only`, `require_baseline`, `product_id`,
`tables`, `sample_n`, `cut_regex`, `cut_filter_regex`, `numeric_cat_max`, `top_n`, `sample_seed`,
`source_mode`, `local_dir`, `missing_tokens`, `kind_overrides`) when set — one config surface — and it
launches the child profiler with a **fully-specified `DC_*` environment** (every flag set explicitly,
unset ones to empty / `0`, incl. clearing `DC_DEFINE_ONLY`), so a stale `DC_*` exported in the parent
shell can't leak in and change the child's mode/cut/baseline; only the `DATABRICKS_*` credentials are
inherited. Every child env value and path argument is **`shQuote`-wrapped**, because `system2()` prepends
env entries and appends args to the shell command *unquoted* — so a missing-token with a space, a
`cut_regex` with `|`/`()`, or an output path with spaces launches correctly instead of breaking. The
profile wrapper requires `catalog`/`schema` only in DBI mode; a `source_mode='local'` check reads local
files (`local_dir` + `tables`) and doesn't need them. The `drift` verb sanitizes its child the same way: it
clears `CMP_DEFINE_ONLY` (a leaked parse-only guard would otherwise make `compare_snapshots.R` exit 0
**without comparing**, scoring an un-run drift as a pass) and pins every `CMP_*` threshold (`miss_pts`,
`rows_pct`, `distinct_pct`, `smd`, `cat_pts`, `cat_min` — settable per drift check, else empty so the
child uses its own default), and it verifies the comparison report was actually written before reporting
success. For the new-variables ask you still run `data_profiler.R` directly. (Note: `null_rate` counts only null/blank, not the profiler's optional
`DC_MISSING_TOKENS` sentinels, so the two can report different rates for a token-coded field by design.
`rate` and `join_check`'s predicate branch author the predicate verbatim and do **not** validate operand
parseability — if the predicate casts, make it also catch the unparseable case, e.g. `OR try_cast(x AS
date) IS NULL`.)

### Reusing checks across tumors — three files: universal engine, tumor config, launcher

The framework is **three files** (plus an offline CI test). This turns qc_runner from "write the config from
scratch per tumor" into "assemble it from reusable parts", so an analyst doesn't hand-write 150+ bespoke tests
per tumor (the NSCLC-from-scratch approach):

- **`code/qc_runner.R`** — the **universal** (tumor-agnostic) core, one file: the shared helpers, the check
  **generators**, the **coverage gate**, and the **engine**. The generators (`product_identity`,
  `product_domain`, `product_ordering`, `merge_no_fanout`, `reconcile_agg`, `reconcile_bound`,
  `reconcile_window`, …) each return a list of qc_runner check entries from a few parameters, so
  `CFG$checks <- c(product_identity(P), reconcile_agg(...), …)` assembles a tumor's QC in a handful of calls.
  Every table/column name is a **parameter** (no vendor baked in), and every generated check still appears
  individually in the report — generators return *data*, not hidden logic, so auditability is unchanged.
  `product_identity` emits a non-empty guard, a **non-null key** check, and uniqueness together (uniqueness
  alone misses a single NULL key). Nothing in this file is NSCLC-specific — a new tumor reuses it untouched.
- **`code/qc_nsclc_config.R`** — the worked **NSCLC** config: the delivered-product suite (built on the
  generators), the build-stage suite (`NSCLC_BUILD_CHECKS`, at the bottom), and the canonical **inventory**
  (`QC_REGISTRY`) mapping each of the 164 reference tests to a disposition (implemented / corrected /
  build_pipeline / subsumed / note / retired_invalid / out_of_scope) with an inline rationale. The registry is
  the source of truth; per-test *observed* status is regenerated each run into
  `outputs/qc_coverage_traceability.md` (see the coverage-harness section below). This one file is the
  template every other tumor (EC, prostate, GIST, HNSCC, DLBCL, CLL, OC) clones: swap the table/column names,
  reuse the engine.
- **`code/qc_run_nsclc.R`** — the runnable entry point. It **sources** the engine in define-only mode (so it
  doesn't auto-run — the engine now carries the generators, so it loads *before* the config that calls them),
  then the config, then wires `CFG$checks` and your schemas and runs — so a tumor's QC is "source + set
  schemas + run", never copy-pasting the generators into each runner (which would recreate version drift).
  `NSCLC_BUILD=1` selects the build-stage suite instead of the delivered suite (and drops the delivered
  registry so the build run isn't scored against the 98 delivered ids). Clone it per tumor as
  `qc_run_<tumor>.R`. Run:
  `NSCLC_RAW_SCHEMA=… NSCLC_PRODUCT_SCHEMA=… NSCLC_PRODUCT_TBL=… NSCLC_CUT=… NSCLC_EXPECTED_NCOL=… Rscript
  code/qc_run_nsclc.R`. **`NSCLC_EXPECTED_NCOL`** (the approved final-product column count that 42.4 checks) is
  required for a **COMPLETE** run — until it's set to a positive integer, 42.4 template-skips and the run
  reports INCOMPLETE. Note that a column *count* is a weaker contract than an approved column-*name* manifest
  (a rename that preserves the count would still pass 42.4); a per-tumor column-name+type manifest is now available: fill NSCLC_COLUMNS in the tumor config and 42.4
  upgrades from a count check to an exact schema check. **Do NOT set `QC_NO_EXPR=1` for NSCLC**: the delivered suite relies on reviewed,
  version-controlled `expr` checks (windowed existence, drug-union, cohort-count) that no declarative verb
  expresses; `QC_NO_EXPR` turns each into an execution error → INCOMPLETE. Those expressions are the approved
  mechanism here and are parse-checked by the offline contract test.

**Safe by default:** qc_runner skips any check that still carries a `<placeholder>` **anywhere** — not just
in a table field but in a `filter`, `predicate`, `cut`, `old`/`new` path, or `expr` string — and reports it
as a template instead of running it and failing on a bogus name. The placeholder pattern is an
angle-bracketed identifier (`<product_tbl>`, `<cut>`), so it never trips on a SQL `<` / `>` / `<=` operator
or a spaced comparison. A half-edited tumor config therefore produces clean template-skips, never a false
green or a spurious red.

### Coverage harness — a partial config can't read green, and traceability can't drift

Template-skipping keeps a half-wired config from false-*failing*, but on its own it introduces the opposite
risk: a skip is a non-gating info row, so a config where the product table was never wired could still show
**all-green** while silently having asserted nothing about the product. The harness closes that by separating
**execution completeness** from the **data-QC verdict**, and by generating the traceability table from the
code so it can never fall out of sync with what actually ran.

- **`QC_REGISTRY` (inline in `code/qc_nsclc_config.R`)** — the canonical inventory: all 164 reference tests →
  a `disposition`.
  Every test resolves to exactly one, so a non-gating test always says *why*: `implemented` / `corrected`
  (the two gating dispositions), `build_pipeline` (a merge/uniqueness check that runs at the product-build
  stage against intermediate tables, not the delivered product), `subsumed` (covered by another emitted
  gating check, named inline), `note` (a real requirement needing a verb the runner lacks), `retired_invalid`
  (the reference test is broken / inverted / tautological), or `out_of_scope` (not expressible in the
  SQL-count model). It also carries `QC_EXPECTED_MULTIPLICITY` — the exact emitted-check count for each
  loop id (e.g. 20.4 = 10 lab bounds), so dropping items from a loop is caught even though the id survives.
  This is the maintained source of truth for "which tests we assert and which we deliberately don't".
- **Tagged checks.** Each emitted reference check in `qc_nsclc_config.R` is wrapped in `tag("17.5", …,
  required = TRUE)`, stamping it with its reference id + a `required` flag. Final-product and raw checks are
  `required = TRUE` (they must run for a complete product QC); build-time merge-safety templates that target
  intermediate `<…>` tables are `required = FALSE` / `build_pipeline` (enable them when those tables exist —
  not wiring them does **not** make a delivered run incomplete). Supporting non-empty guards stay untagged.
- **The coverage gate (in `code/qc_runner.R`)** — `qc_coverage_report()` computes an **Execution status**
  (`COMPLETE` / `INCOMPLETE`) and a **Data QC result** (`PASS` / `FAIL` / `NOT EVALUABLE`). A run is
  `INCOMPLETE` if any **required** check was placeholder-skipped, errored (no DB / bad table), or — with the
  registry — is `implemented` but absent from the config entirely; and an `INCOMPLETE` run reports
  `NOT EVALUABLE`, never a green data verdict. So forgetting `NSCLC_PRODUCT_TBL` yields
  *INCOMPLETE / NOT EVALUABLE*, listing the skipped required checks — not a false PASS. The report gains a
  banner showing both statuses, and the runner **exits non-zero** on `INCOMPLETE` as well as on any FAIL.
  Whether a result is a data verdict or an **execution error** (a config error, a `QC_NO_EXPR`-disabled expr,
  a dead connection, a handler crash) is decided by a structured `error` flag the engine sets — never inferred
  from the detail text — so an errored required check reads as INCOMPLETE, not as a data failure. When a
  required inventory is present the header pill is a **three-category** verdict — a required data FAIL, then an
  INCOMPLETE execution, then optional-only findings (`REVIEW`), then PASS — and the banner surfaces any
  **enabled non-required** (`build_pipeline`) check that fails as a separate "Additional findings" count, so a
  clean required run with an optional failure never reads as a bare FAIL. (Without an inventory — the OC
  default — the pill stays the simple FAIL/PASS.)
- **Generated traceability.** When the registry is loaded, each run **regenerates**
  `outputs/qc_coverage_traceability.md` from the assembled check list joined to the registry — flagging any
  drift (`⚠ MISSING` = registry says implemented but nothing emitted; `⚠ UNEXPECTED` = the reverse). This
  generated-on-every-run file replaces any hand-maintained snapshot, so traceability can't go stale.
- **`code/qc_contract_test.R`** — extended to enforce the gate contract **offline, with no DB**: the
  registry is exactly 164 tests with valid dispositions; every `required` check carries a `ref_id`; every
  emitted `ref_id` is known to the registry; the emitted `required` set equals the registry's
  `implemented`+`corrected` set; and `qc_coverage_report()`'s COMPLETE/INCOMPLETE and PASS/FAIL/NOT-EVALUABLE
  logic is exercised on synthetic results. A config-vs-registry drift fails CI before any live run.

`qc_run_nsclc.R` sources the registry alongside the config, so a normal run produces the split verdict and
the regenerated traceability automatically.

### Delivered-product vs build-pipeline suites

All 164 reference tests are **accounted for with a disposition**, and **135 of them are individually runnable
checks** — 98 in the delivered-product suite and 37 in the build-pipeline suite. The other 29 are, by design,
*not* standalone checks: 24 are **subsumed** by an emitted gating check (mostly by 42.5), just 1 is a **note**
that needs a *product decision* this static config can't make (`15.6` brthdt-vs-birthyear type), 3 are
**retired_invalid** (the reference test is genuinely broken and unsalvageable as written), and 1
is **out_of_scope** (SAS label metadata). The registry is explicit about which is which. The two runnable
suites split by *where* the data lives:

- **the delivered suite in `code/qc_nsclc_config.R`** (run via `qc_run_nsclc.R`) — the **delivered-product**
  suite: everything that
  runs against the built product and the raw sources. This is where the 98 gating checks live, including the
  core structural invariant **42.5 (the product is a valid key on `patid,cohort`** — unique *and* `patid`
  non-null), which subsumes the ~19 per-cohort uniqueness/fan-out tests, plus cohort nesting
  (31.6/31.7/31.8/42.7), `40.2`, `41.4`, `34.4`, `30.15`, and `30.16`.
- **the build suite in `code/qc_nsclc_config.R`** (run via `qc_run_nsclc.R` with **`NSCLC_BUILD=1`**) — the
  **build-pipeline** suite: the 37
  `build_pipeline` merge-QC checks (uniqueness / fan-out / count) against build-time intermediate tables
  (`<demographics_agg>`, `<base_tbl>`, `<idx_tbl>`, …) that don't survive into the delivered product. Run it
  *while building the product*, mapping each `<placeholder>` to the real intermediate; unmapped ones
  template-skip. These never gate a delivered-product run — build QC is strict by default, so an unmapped
  intermediate makes the build run report INCOMPLETE and exit non-zero (a production guard against a forgotten
  mapping). The two mandatory bases every fan-out check joins onto (`<base_tbl>`, `<idx_tbl>`) additionally
  carry a `row_count(min=1)` non-empty guard, so a strict build can't pass vacuously on an empty base (a
  `no_fanout` check is trivially true when both sides are 0 rows).

So an intermediate-table test is genuinely runnable (at the build stage), not merely "covered by a
generator" — the reviewer's requirement — and the delivered-product report isn't cluttered with build-stage
skips. The contract test validates *both* suites (structure, handlers, that the build suite emits exactly the
registry's `build_pipeline` id set).

## `code/oc_exploration.R` — LOT & platinum

Patient counts by treatment setting, lines of therapy, and platinum use.
Lines are built from the non-maintenance drug episodes.

```bash
export DATABRICKS_DSN=RWDE DATABRICKS_PWD=...
Rscript code/oc_exploration.R
```

`code/oc_exploration.sql` is the same items in SQL — paste it into the Databricks editor and
run top to bottom for one result set per item (2a–3c), no R setup needed. It mirrors the R
logic and is built to return the same numbers; run both on the live feed and confirm they
agree. Items 2e/3b/3c need the recurrence and platinum-status tables.

Writes `code/outputs/oc_exploration.html` and `.md`. Items 2a–2d and 3a run on the drug
episode table alone. Three items need columns to confirm from the profiler first — set them
via env or at the top of the script, else they're marked **pending** and skipped:

- **2e** recurrence date — `OC_RECUR_TBL` / `OC_RECUR_COL`
- **3b / 3c** Panoramic platinum status — `OC_PLAT_TBL` / `OC_PLAT_LINE` / `OC_PLAT_STATUS`

3b/3c are patient-level. 3b looks across **all** of a patient's adjuvant lines; 3c uses their
**earliest** Advanced line. A patient with more than one distinct status is shown as
"Conflicting status (multiple rows)", a matched-but-empty row as "Status row present but
blank", and no matching row as "No status row" — so the denominator stays all patients in the
setting. The platinum-status table is keyed by line only, but a line can span settings, so the
status can't be pinned to one setting when it does; the note counts how many of the lines used
in 3b/3c span settings (the SQL has the same count in a QC block) — confirm the attribution
rule if it isn't ~0. Line start dates come from `linestartdate`; `linesetting` casing,
string-typed dates, and order of drugs in a regimen are all handled.

**2c** counts distinct lines in the treatment settings only (Neoadjuvant/Adjuvant/Advanced),
so Off-Systemic-Therapy doesn't inflate the line count; whether it should be Advanced-only is
still open.

**L1** is defined per item: 2e uses **line number 1** (the first line of therapy) for the
1L-vs-recurrence check — confirmed. 2d uses the **first Advanced line** instead, because
nothing can start "prior to line number 1", so that reading would be empty. The two items
ask different questions, so they use different anchors on purpose.
