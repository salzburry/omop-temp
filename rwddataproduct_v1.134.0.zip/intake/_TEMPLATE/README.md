# <Tumor> RWDP — intake submission (<source / owner>)

> Copy of `intake/_TEMPLATE`. Fill this in, drop your code in `code/`, complete `QC_CHECKLIST.md`,
> and set `status` in `submission.yaml`. Staging only — not governed prod; **no patient data**.

## What this code does
- Cohorts:        <e.g. overall + L1–L3; advanced / metastatic>
- Endpoints:      <e.g. OS, rwPFS, TTNT>
- Key variables:  <staging, biomarkers, LOT categories, …>

## How it runs today
- Environment:    <Domino / Databricks / local R>
- Entry point:    <script + command>
- Schedule:       <ad-hoc / per refresh>
- Last good run:  <YYYY-MM-DD, on refresh ____>

## Source tables it reads
- <list the t_* / catalog tables + the schema>

## Output it produces
- <table name + the ADS columns / cohorts>

## Known issues / TODOs
- <anything fragile, hard-coded, or unverified>
