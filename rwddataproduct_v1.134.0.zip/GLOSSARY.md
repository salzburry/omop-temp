# Glossary — the words this repository uses

For someone in their first week. Half of what follows is framework vocabulary and half is
oncology real-world-data vocabulary, and nothing distinguishes them on sight.

**This file defines words. It does not define rules.** Where a term has an authoritative definition
in code, the owner is named beside it — read that, not this, when the answer matters. A glossary
that restated the rules would be a second copy of them, agreeing today and free to drift, which is
the failure mode `docs/ENGINEERING.md` opens with.

---

## 1. Who is who

| Term | Meaning |
|---|---|
| **RWB** | The sponsor's scientific side. **Owns the intent** — writes the program specification, approves the answers to methodology questions, corrects defects found in its own document. |
| **RWP** | The product side. **Owns the interpretation** — turns the specification into contract records, maps variables to source columns, authors the executable configuration. |
| **RWDE** | Engineering. **Owns the shared engine and the build** — `platform/engine/`, and everything that runs on the cluster. |
| **vendor** | The data supplier — Flatiron or COTA today. Delivers the patient-level tables the product is built from. Declared per product in `products/registry.yaml`, and it decides which evidence route applies (`product_gates.evidence_route`). |
| **Panoramic** | The Flatiron delivery this framework was first built against. Not a synonym for "the data" — the next vendor lays its tables out differently. |

> Ownership in one line, from `governance/WORKFLOW.md`: *RWB owns the scientific intent. RWP owns
> the interpretation, the source mapping, and the executable configuration. RWDE owns the shared
> engine and the build.*

---

## 2. The things

| Term | Meaning | Owner |
|---|---|---|
| **pack** | One product at one specification version — `products/<family>/<slug>/<version>/`. The unit everything is discovered and gated by. | `product_gates.products` |
| **program specification** | RWB's workbook. The input. Registered and hashed, never re-typed. | `source_refs.yaml` |
| **extraction** | The deterministic parse of that workbook into rows, in `spec_pipeline/out/extracted.json`. Re-runnable and byte-comparable — `--check` regenerates it into a temp directory and compares. | `run_spec_pipeline.py` |
| **contract record** | One variable's requirement: the rule, the spec rows it cites, the digest of those rows, the source, the open questions. ~200 per pack. | `contract_lint.records` |
| **functional contract** | The file all the records live in — `handoff/FUNCTIONAL_CONTRACT.md`. | |
| **configuration** | The executable YAML — bands, codelists, cohorts, index dates. What the engine actually reads. | `product_gates.pack_yaml` |
| **engine** | The shared, tumour-agnostic code in `platform/engine/`. Nine stages assembled by configuration. It contains no tumour's name. | |
| **ADS** | Analytic Data Set — the built table, one row per patient per cohort. The deliverable. | `engine/build_ads.py` |
| **TFL** | Tables, Figures and Listings — the reporting outputs built from the ADS. | |
| **profile** | Per-column statistics of a live vendor table, produced by `data_profiler.R`. **Restricted output**: it carries top values with no small-cell floor and never enters the checkout. | `profile_io` |

---

## 3. The lifecycle

**Six gates.** In full in `governance/WORKFLOW.md`; `demo.py` runs all of them in order.

| | Asks |
|---|---|
| **Gate 1** | Is every source material registered, classified, and does it still hash to the bytes its record names? May AI read this pack? |
| **Gate 2** | Do the generated artifacts still regenerate identically, does every record hold its invariants, and have the specification's own defects been returned to RWB? |
| **Gate 3** | Is the named column the *right* column? Structure is checkable from the repo; the answer needs a profile and a person. |
| **Gate 4** | Is every governed config block claimed by a contract record, and does every record say where it is implemented? |
| **Gate 5** | Does the pack's own test suite pass? |
| **Gate 6** | May this pack publish? |

**maturity** — `handoff/MATURITY.yaml`. A **claim**, not evidence: a person writes what the pack has
reached, and the gates check whether the evidence supports it. `contract:` moves
`not_started → draft → coverage_complete → approved`; `configuration:` moves
`not_started → draft → approved`.

**the four status axes** — every contract record carries `status: {requirement, source,
implementation, validation}`. They advance independently and for different reasons:
`requirement` on RWB/RWP agreement, `source` on a Gate 3 profile, `implementation` on config and
engine work, `validation` on a build against real data.

---

## 4. The registers

Three markdown tables per pack, all read by `contract_lint.decision_rows`. Columns are located **by
name**, and the packs spell them differently — `contract_lint.ANSWER_COLUMNS` and friends hold every
accepted spelling.

| File | Holds |
|---|---|
| `handoff/DECISIONS.md` | **Open methodology questions.** Things the specification left ambiguous. `OPEN → RESOLVED / WITHDRAWN / SUPERSEDED`. |
| `handoff/SPEC_QC_FINDINGS.md` | **Defects in RWB's own document** — impossible dates, contradictions, wrong-tumour references. Returning these is a Gate 2 exit deliverable. |
| `handoff/ENGINE_GAPS.md` | **Where the executable diverges from the requirement.** Each row says whether the fix is *config* (RWP's YAML) or *engine* (RWDE's Python). |

The distinction matters and is easy to get wrong: a **decision** is a question for a human, a **QC
finding** is a defect in the vendor's document, an **engine gap** is missing capability in the code.

---

## 5. Words the tools print that do not mean what you would guess

This section is the one worth reading twice.

| Phrase | What it actually means |
|---|---|
| **`coverage_complete`** | Every spec item is *traceable* to a record. **Not** that anyone agreed with the records. Gate 2 does not close until each is approved or explicitly blocked. |
| **releasable** | **Derived** from Gates 1–4 by `source_manifest.releasable`. There is no flag; it cannot be granted by editing a file. |
| **blast radius** | How many contract records an open decision blocks. Answering the top one on prostate/202606 unblocks 19. | 
| **latent blocker** | A blocker that appears only once a pack *claims* approval — invisible until then. `dry_run.py` simulates the claim on a copy to surface them. |
| **precedent** | A pointer to a question another product already faced — *not* a stored answer. The answer is read live from that pack's register, so it cannot go stale. Advisory: no gate reads it. |
| **carries as-is** | A record whose `spec_digest` still matches the new extraction — the cited text is provably unchanged, so it need not be re-drafted. `spec_diff.py`. |
| **disposition** | What was decided about a spec row that did *not* become a record — out of scope, superseded, context only. An undispositioned row is one nobody has looked at. |
| **unstated** | A field that is absent, blank, or a placeholder (`TODO`, `TBD`, `REPLACE_ME`). Treated as an **unanswered question**, never as a default. `product_gates.unstated`. |
| **fail closed** | When a check cannot get an answer it **refuses** rather than passing. An absent counter is not a zero; an unreadable register is not a clean one. |
| **"nothing to check, not nothing wrong"** | An empty result over an empty denominator. Printed wherever a `0 of 0` would otherwise read as success. |
| **a PASS is scoped** | Gate 3's structural check prints *"a PASS here is 'nothing unreadable', NOT 'nothing wrong'"*. Several checks state the limit of their own green light — believe the sentence, not the colour. |

---

## 6. The clinical vocabulary

| Term | Meaning |
|---|---|
| **cohort** | A defined patient group with its own index date — e.g. `overall_mcrpc`, `lot1_mhspc`. One ADS row per patient *per cohort*; the cohorts are unioned. |
| **index date** | The anchor every window is measured from. What sets it differs by cohort and tumour class — advanced-diagnosis date for solid tumours, diagnosis for heme. |
| **LOT** | Line of Therapy. A numbered treatment line. `new_lot_n` is the engine's deterministic re-numbering after filtering. |
| **line setting** | Which disease state a line belongs to — `mCRPC`, `mHSPC`. Prostate splits on it; most tumours have no equivalent, so it is configuration, not an assumption. |
| **mHSPC / mCRPC** | Metastatic hormone-sensitive / castration-resistant prostate cancer. Sequential disease states — a patient can appear in both. |
| **cut / refresh** | The vendor delivery this build reads — e.g. `2026q1`. The **stamped** `profile_cut` is the identity; a table-name suffix only corroborates it. |
| **censoring** | A patient whose event was not observed by end of follow-up contributes time without an event. Which date ends follow-up is `FUED`, and it is one of the most-argued decisions in every pack. |
| **rwPFS** | Real-world progression-free survival. Derived, not delivered — the definition is a decision, not a fact. |

---

## 7. First week

Run these in order. All read-only.

```bash
python3 platform/tools/demo.py                                   # the packs, and what state each is in
python3 platform/tools/demo.py products/oncology/prostate/202606 # the six gates, end to end
python3 platform/tools/blocks.py                                 # what configuration is allowed to name
python3 platform/tools/worksheet.py products/oncology/prostate/202606   # what the work actually is
python3 platform/tools/precedents.py --for <pack>                # questions other products already hit
```

Then read, in this order: `README.md` → `governance/WORKFLOW.md` (the gates in full, and the AI
eligibility rule) → `docs/ENGINEERING.md` (the rules that are expensive to get wrong) → `HANDOVER.md` (where
everything actually stands).

**The one rule worth knowing on day one:** before you write a predicate, a parser or a checksum,
grep for the existing one. Three times a change added a second implementation of something the repo
already had, and each duplicate was subtly *wrong* rather than merely redundant. `docs/ENGINEERING.md` names
where every shared definition lives.
