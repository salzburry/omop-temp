# Handover — a working RWDP product/process someone can take forward

**What this file is.** What we are building, where it stands, and the ordered work left. It is a
status board, not a governed artifact. No gate reads it.

Counts live in `governance/CURRENT_STATE.md`, which is generated and CI-checked. Prose here points
there instead of restating figures — hand-carried numbers drifted four times before that rule.

Companion visual: <https://claude.ai/code/artifact/c17bbfde-8642-4f49-855a-38feb715e1c8>

Last grounded: 2026-08-15 (sixth external review).

---

## 0. See it work

Get on `main` and pull. Then check the machine first — most "bugs" a stranger hits are a missing
dependency or an unwritable directory:

```bash
pip install -r platform/requirements.txt
python3 platform/tools/doctor.py
```

One command runs the real governance tools over one pack, in lifecycle order:

```bash
python3 platform/tools/demo.py                                     # the packs you can walk
python3 platform/tools/demo.py products/oncology/prostate/202606   # walk the reference product
python3 platform/tools/demo.py products/oncology/prostate/202606 --full
```

It is read-only. Nothing signs anything. Watch two steps in particular:

- **Step 4** — may AI read the spec? The answer is derived from `ai_readable`, never asserted.
  Today every pack refuses, each naming its missing human act. Permission comes from a named
  person against specific bytes, never from asking.
- **Step 13** — the release decision is derived from Gates 1–4. There is no flag to set. It
  reports BLOCKED and names the remaining distance.

Run it across packs and each one's real state falls out — passed, refused, or nothing-to-read are
three different answers. Don't quote step counts from here; run it. `test_demo.py` guards the
walkthrough: every tool it names must exist and stay read-only.

Shareable page of what it proves: <https://claude.ai/code/artifact/2383a2dd-e34d-404e-b138-de1705e0ccf0>

### 0.1 The helper tools, one line each

All read-only. Each composes tools that own the numbers; none computes its own.

```bash
python3 platform/tools/precedents.py --for <pack>     # questions other packs already argued
python3 platform/tools/blocks.py                      # every named thing config can select
python3 platform/tools/worksheet.py <pack>            # blank config? the ordered worklist
python3 platform/tools/dry_run.py <pack>              # what breaks the moment you CLAIM approval
python3 platform/tools/spec_diff.py <old> <new>       # what a revision changed; what carries
python3 platform/tools/decision_packet.py <pack> --out p.html   # the questions, as one page each
python3 platform/tools/placeholders.py --all          # what every TODO/REPLACE_ME is doing there
```

Design rules they share:

- **Pointers, not copies.** The precedent store cites `(pack, decision id)` and reads the live
  register. A copied answer could drift; a pointer can only stop resolving, and `--check` catches
  that.
- **Advisory and powerless.** No gate reads them. A test asserts no gate starts to.
- **Derived, not restated.** `blocks.py` imports the same registries `validate.py` checks against.
  A hand-written list is wrong from the first edit after.
- **Empty says which kind of empty.** "We looked and found nothing" and "there was nothing to look
  at" print differently, everywhere. This failure happened five times before the rule.
- **Ranked by unblock count.** On prostate, one decision blocks 19 records while ten block one or
  two. File order is close to the worst order.

### 0.2 The knowledge layer

```bash
python3 platform/tools/knowledge_search.py follow-up end   # all six surfaces, ranked by authority
python3 platform/tools/capability_registry.py --check      # every coverage claim resolves to code
python3 platform/tools/portfolio_status.py --check         # declared status vs what is on disk
python3 platform/tools/citation_register.py --check        # every citation's verification route
python3 platform/tools/protocol_record.py --scope          # which builds each study actually read
```

The repository holds six kinds of knowledge in six places. `knowledge_search.py` searches them in
one pass and says, per hit, what kind of authority it could carry and how far it has been taken.
A mention and a signed ruling must never look alike. Every render carries the line that nothing
returned is an approval.

A coverage claim resolves to code: `platform/capabilities.yaml` names, per family, the config key,
the Python and R symbols, the published columns, and the tests — and `capability_registry.py`
refuses the file unless every one resolves. It cannot prove the code is right; its header says so.

Three fields only a person may write, all empty today: a citation's `supports:`, a shelf entry's
`workbook_confirmed`, a sealed benchmark key. The counts are printed, not hidden. No AI fills
them — the judgement is the field.

---

## 1. The goal

Show a working product and process, then hand it over. Three parts:

1. **The pipeline runs end to end** — spec → extraction → contract → config → engine build →
   gates. DONE: `demo.py` walks it; `local_smoke.py` builds an ADS through the production
   entrypoint on synthetic sources.
2. **A new tumour is mostly configuration**, and the framework helps write it. The engine side is
   done. Guided authoring exists (worksheet, precedents, blocks); the store of precedent is still
   thin because few decisions are settled.
3. **The governance is real, not theatre.** The mechanism is done and tested. The enforcement is
   not: `main` is unprotected and CI is not running (§8, first item).

The thesis: today an analyst re-implements each product from a spec. The target is an analyst who
assembles a product from reusable engine blocks plus precedent, with the machine drafting the
mechanical parts and raising a decision wherever judgment is needed.

## 2. What stays human, permanently

- Which physical column is the right one — confirmed at Gate 3 against the live data.
- Codes, fallthrough, missing-value handling, operators, output names — the framework refuses to
  guess these and raises a decision instead.
- Approvals. Every green proposal is a proposal a person confirms. Nothing flips a maturity level.
- The precedent store holds decisions and outcomes only. Never vendor data.

---

## 3. Where we are (grounded against the code)

| Layer | State | Reading |
|---|---|---|
| Engine (reusable blocks) | ✅ built | 9 stages + formula registries + codelist DSL, assembled by config. `validate.py` imports the same registries it checks, so validation cannot drift. |
| Governance gates 1–6 | 🟡 built, not enforced | Releasability is derived, never toggled. But every gate is repository-local: with `main` unprotected and CI down, a gate runs only when someone chooses to run it. |
| AI drafting layer | ✅ built, bounded | Proposes spec-stated values and hashes evidence. Refuses to invent mappings, codes, fallthrough — each becomes a named gap. |
| Knowledge layer | ✅ built | Six surfaces, one search, every hit graded. Its own verdict on the repo — no attributed rulings, no workbook-confirmed entries — is the useful part. |
| Prostate 202606 | 🟡 furthest | Full executable config; 200-item traceable contract; config `draft`. Gate 1 pending; almost all decisions open; 0 records approved. |
| Ovarian oc/202606 | 🟠 scaffold | Config authored; contract covers study_period only; most spec items undispositioned. |
| Endometrial | 🔴 seed | Reconstructed, not verified. Version is the literal `YYYYMM`. Passes no gate. |
| mCRC 202606 | 🟡 configured | Full config + variables; builds in the smoke. Spec workbook not yet registered in the repo. |

**The honest gap:** everything is ready and nothing has shipped. No source is reviewed, no record
approved, no config approved. That is a provenance state — the approved workbooks were never
supplied — not a capability gap.

---

## 4. What remains, in order

| # | Work | Why |
|---|---|---|
| 1 | **The four engine generalisations** — match operators, row selection, a duration-formula registry, line/setting parameters (`handoff/ENGINE_GAPS.md`) | The 26 engine gaps cluster into these four. Build them and a new tumour is configuration. Highest-value remaining code. |
| 2 | **Attested decisions** — give the register `approved_by` / `approval_date` and a tool that writes the row | Makes a methodology decision as auditable as every other approval. |
| 3 | **Answer decisions** | Nearly all are open. Everything that compounds — precedents, carry-forward — is downstream of settled answers. The machinery is built and starved. |

Phases 0–4 of the old roadmap (demo, precedents, blocks, worksheet, the four §0.1 tools, the Spark
build and CI job) are done and folded into §0.

## 5. A first-time analyst's day (target state)

1. Drop the approved spec in `prog_spec/`, run the pipeline. Get extraction, coverage, scaffolded
   records.
2. The precedent store proposes the reusable decisions. Confirm or override each.
3. Open the worksheet. Value-lists are pre-filled; the genuine decisions are listed with
   citations, highest unblock count first.
4. Author `config/`. Validation errors name the valid blocks, so nobody greps the engine.
5. The gates say plainly what is still unapproved.

The machine never answers for them. It shortens the blank part with every product that ships.

---

## 8. Open governance items (human acts, in order)

- **Restore CI and protect `main`. Everything else is downstream.** Three reviews found the same
  thing: `main.protected=false`, merges with zero reviews, every CI job dead on billing. Nothing
  inside the repository can fix this. Until it is fixed, read every "enforced" here as
  "implemented and tested".
- **Approve the `ai_extraction` registrations.** No pack's extraction is signed. Until one is,
  `spec_slice` and `contract_record --item` refuse to serve the spec's words, by design. Trust
  the tools' own output over any sentence here.
- **Supply an approved workbook** (or accept the stand-in explicitly) to move a pack off Gate-1
  pending.
- **Sign a decision.** Resolved-but-unsigned rows are useful but are answers, not citable
  rulings, and the tools grade them exactly that way. The signature is a person's to give.
- **Register a signing key** (`governance/allowed_signers.yaml` is empty — registering one is a
  person's own act). Existing approvals predate the mechanism and are baselined; new unsupported
  approvals fail `approval_identity.py --check`.
- **Fill or raise the unaccounted placeholders** — `placeholders.py --all --check` is the count.
- **Ovarian is split across two directories** — the governed pack and a sandbox draft with far
  more records. Merging or not merging is an open decision.
- **Give endometrial a real spec version** and the missing pack files.

### History was rewritten on 2026-08-02 — re-clone, do not pull

183 vendor-document paths were purged from history; the repo went from 502 MB to 6 MB. A `git
pull` into an old clone brings every removed document back. Re-clone. `repo_hygiene.py --history
--check` runs in CI ahead of everything else and keeps the claim true.

---

## 9. Pointers

Read in this order: `GLOSSARY.md` → `DEMO.md` (run it) → this file → `docs/ENGINEERING.md`.

| document | for |
|---|---|
| `GLOSSARY.md` | every term, pointing at the code that owns it. Self-checking. |
| `DEMO.md` | the run sheet. Every command was executed before it was written down. |
| `REVIEW_BRIEF.md` | hand to a reviewer. Domain-neutral, points questions at exact code. |
| `docs/ENGINEERING.md` | the rules that are expensive to get wrong. |
| `docs/CHAT_JOURNEY.md` | how the repo is operated from chat. |
| `docs/PRODUCTION_READINESS.md` | what "production ready" means, concretely. |
| `governance/CURRENT_STATE.md` | **generated** — every count. Prose points here. |

- Start: `python3 platform/tools/demo.py`
- Framework: `README.md`, `governance/WORKFLOW.md` (the six gates)
- Engine: `platform/engine/stages/`, `codelists.py`, `validate.py`
- Drafting: `.claude/skills/draft-contract-record/SKILL.md`, `contract_binding.py`,
  `contract_scaffold.py`
- Gates/deploy/release: `product_gates.py`, `source_manifest.py`, `deploy_tree.py`,
  `bundle_products.py`, `repo_hygiene.py`
- Approver identity: `approval_identity.py` + `governance/allowed_signers.yaml` +
  `governance/approval_baseline.yaml`
- Change impact: `change_impact.py <pack> clinical:12` — spec row → record → config → column →
  the goldens to re-run. Reports reach, not risk.
- Plan size: `plan_size.py <pack> --scale` — measured before proposing any redesign.
- Config provenance: `config_propose.py <pack>` — confirmed / changed / unresolved / unsupported
  per block.
- Drafting benchmark: `skill_benchmark.py` — read its docstring before quoting any number.
- Most complete pack: `products/oncology/prostate/202606/`
