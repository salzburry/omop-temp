# Design: authenticated approval events

**Status: the PR-review design below is STILL NOT IMPLEMENTED. Two narrower things now are —
see "What exists today" — and neither is a substitute for it.**

## What exists today

| Built | Not built |
|---|---|
| `platform/tools/approval_identity.py` — for each governed approval file, finds the commit that last set it and asks whether that commit is signed by a key `governance/allowed_signers.yaml` registers as `person_review` | everything under "The event" below: `approval_event`, `reviewed_sha` ancestry, structural separation of duties, the CI attestation step |
| `governance/allowed_signers.yaml` — a registry recording what each key ATTESTS (`person_review` / `forge_merge` / `automation`), only the first of which may support an approval | branch protection on `main`, which is a repository-admin act and step 1 of the migration below |
| every governed human attribution is now held to `person_rules.not_a_person` — `attested_by`, the QC register's `Waived by`, the decision register's approver, `requested_by` / `analyst`, `registered_by` and every amendment's `by`, and a released refresh's `sign_off.qc_by` / `released_by` | any verification that a named person *exists*, or that the approval is *correct* |

**What the verifier reports today: 0 registered keys, 0 authenticated approvals.** That is the true
state, not a broken tool. This repository's history holds 1341 unsigned commits and 32 signed ones;
every signed one is a GitHub merge commit on the forge's key `B5690EEEBB952194`. Every commit
touching `governance/**` and every `source_refs.yaml` is unsigned.

Two numbers, because they need two different actions:

- **No key is registered.** A person registering their own key is a five-minute act. Nothing
  automated may do it — registering a key on somebody's behalf forges the identity the mechanism
  exists to prove — so `signers:` is empty and stays empty until a person acts.
- **No approval-bearing commit is signed.** This cannot be fixed after the fact. No check applied
  later turns an unsigned commit into a signed one; those approvals are re-made under signature or
  they remain what they are.

The obvious wrong fix is recorded in the registry as `known_ineligible`: registering the GitHub
web-flow key would make 32 signatures verify and authenticate no approval whatsoever. A forge
signature attests that the platform performed a merge, on a key available to anyone with write
access, applied by the same operation whether or not a human read the diff.

**A `person_review` signature is still not an approval.** It proves who wrote a value, never that
the value is right. It closes the gap between a typed name and an accountable one — the whole of
what it claims, and less than what the design below would give.

---

This document exists because the external review of
`main@a5bafe4` is right about the current approval model: the YAML forms bind an approval to
**bytes** (hashes of the extraction, the contract, the manifest) and to **typed names** — and a
typed name authenticates nobody. Any writer can enter a plausible name and satisfy the machine
gate. That was a known trade-off, designed around a control that did not exist; this is the design
for the control.

## The principle

**The YAML stops being the authority and becomes the record of an authority.** Authority moves to
an event a platform authenticates — something the approver does while logged in as themselves,
that the repository can later verify happened and cannot itself forge.

## The event

A GitHub **pull-request review** is the chosen event, because it is the one authenticated act this
project's approvers already perform, it is attributable (login, timestamp, review id, commit sha
reviewed), and branch protection can *require* it — which makes the same event serve merge control
and approval identity.

An approval of X becomes, concretely:

1. A PR whose diff **is** the approval form: the `*_APPROVAL.yaml` file, filled in, hashing the
   exact artifacts approved (unchanged from today — the *subject* binding already works).
2. An **approving PR review** on that PR by the named person's GitHub account — the authenticated
   event. The reviewer states in the review body which role they are exercising
   (clinical approver / technical reviewer / validator).
3. The merge, performed by someone **other than** the form's author, under branch protection that
   requires the review and green CI.

The form then RECORDS the event it rode in on:

```yaml
# added to CONTRACT_APPROVAL.yaml / CONFIGURATION_APPROVAL.yaml / RELEASE_APPROVAL.yaml
approval_event:
  kind: github_pr_review
  pr: 412
  review_id: 987654321
  reviewer_login: dr-example          # must be the account of approved_by's named person
  reviewed_sha: <head sha the review approved>
```

## What the machine gate verifies, then

`product_gates.approval_record_errors` gains, **only once branch protection exists**:

- `approval_event` present and complete for any `approved` claim;
- `reviewed_sha` is an ancestor of the checkout, and the approval file at that sha hashes to what
  the event block says — the review covered *these* bytes;
- **separation of duties, structurally**: the commit author of the form ≠ `reviewer_login`; for
  Gate 6, approver ≠ validator ≠ the build's `git_commit` author. Git author strings are
  self-asserted, so this check is only as strong as the platform behind it — which is exactly why
  the event, not the string, is the authority.

What the repo **cannot** verify offline is that review id 987654321 really exists with that login:
that needs either (a) CI querying the GitHub API at merge time and stamping a signed attestation
artifact, or (b) an auditor resolving the PR URL. Design choice: **(a) in CI, (b) as fallback** —
the CI job runs authenticated, the checkout does not, and the gate consumes CI's stamped artifact
the same way Gate 3 consumes the verdict report.

## Separation of duties — the minimum matrix

| Act | May not be the same account as |
|---|---|
| Author of a governed change (incl. the agent) | its technical reviewer, its clinical approver, its merger |
| Clinical approver (Gate 2/4) | the change author, the agent |
| Release approver (Gate 6) | the validator, the build author, the merger of the approval PR |
| The agent (any session) | ANY approver, reviewer, validator or merger — structurally, by holding a branch-only token |

## Migration

1. **Now (admin, ~15 min):** branch protection on `main` — require green CI + 1 review, dismiss
   stale approvals, no admin bypass. Without this, everything below is decoration.
2. **Then (repo):** add `approval_event` to the three approval schemas as OPTIONAL; tools print a
   warning when absent. Existing forms stay valid.
3. **Then (repo + CI):** the CI attestation step (a); flip `approval_event` to REQUIRED for any
   NEW `approved` claim; `unaccountable_resolutions`-style latency for old ones.
4. **Decision registers:** decision answers keep the hand-typed committed form
   (`decision_record.py`) — but the PR that lands a wave of answers is reviewed by the register's
   owner under the same branch protection, which is what upgrades "a name in a cell" to "a name a
   platform authenticated".

## What this deliberately does not do

- No in-repo cryptography or homegrown signing — a key the deployer holds reproduces the exact
  trust hole `deploy_tree.py` already documents. If signing is wanted, it is Sigstore/GitHub
  artifact attestation in protected CI, not code here. `approval_identity.py` does not breach
  this: it implements no cryptography, generates no key and signs nothing. It shells out to
  `git log --pretty=%G?` and reads git's own verdict, and the key it checks that verdict against
  is one a PERSON registered in `allowed_signers.yaml` — never one this repository holds.
- No biometric/HR identity claims: "the account the org gave Dr. X approved this" is the claim;
  binding accounts to humans is the org's identity provider's job.
- Nothing here weakens the existing byte-binding — hashes stay; identity is ADDED to them.
