# Citations on the reference shelf — how each one was checked

**GENERATED from `CITATIONS.yaml` by `platform/tools/citation_register.py` — edit the
register, then regenerate. `--check` refuses a stale copy.**

281 citation RECORDS covering **246 distinct identifiers**, cited 858 times across 509 variables.

The two numbers differ because 35 records are a second spelling of a work already registered — `Curtis MD et al. 2018, … PMID 29756355` and `Curtis 2018, … PMID: 29756355` are one paper. **Read 246, not 281, as the breadth of the evidence**; the record count is a count of strings. Records sharing one identifier must agree about how that work was checked, and the register refuses them if they do not.

**Identifiers, not works: 246 is an upper bound on the papers.** They span arxiv, doi, in_house, journal_locator, pmcid, pmid, and a paper cited once by PMID and once by DOI is two of them — the strings share no characters, so nothing mechanical can merge them. `same_work:` records that equivalence when a person resolves one identifier and reads back the other; **0 such groups are recorded**, so the paper count is 246 or fewer and nobody has checked which.

**No human has verified any of these.** `route` records how an AUTOMATED pass checked the
citation; nothing here is an approval, and nothing here is evidence that a cited paper says
what the entry using it says. What it gives a reader is the ability to weigh a citation
before relying on it — the weakest routes are listed in full below, by name, which is what
the per-tumour caveats could not do when they said "a few".

| route | citations | what it means |
|---|---|---|
| `pubmed_or_publisher` | 242 | identifier resolved against PubMed or the publisher page (2026-08-13 pass) |
| `web_search_result` | 31 | identity from live web-search results and publisher URLs carrying the DOI (2026-08-14 mcrc pass; PubMed and Crossref were unreachable) |
| `identifier_route_unavailable` | 6 | no PMID or DOI resolved; journal, volume and pages only, with no identifier guessed |
| `in_house_drafting_surface` | 2 | a concept stated on a live pack's committed drafting surfaces, not literature |

## The claim binding is empty, and that is the finding

`supports:` binds a citation to the CLAIM it supports rather than to the variable that
lists it — an EDGE carrying `{claim, locator, relation, reviewed_by, reviewed_date}`,
where `relation` is one of `supports`, `contradicts`, `context` so that a
work CONTRADICTING a claim can be recorded, which is the most valuable binding there is.
**0 of 281 records carry one.** Until a person fills them in, a
citation list on a variable means only "these works are relevant to this entry" — not that
any particular sentence in the entry is sourced to any particular one of them.

An AI must not fill this in. Choosing which paper supports which clause IS the judgement the
binding exists to record; inventing it would make the shelf look better-evidenced than it is
while destroying the one signal that says otherwise.

**`common_sources:` on every variable carries no citation at all** — which databases carry a
concept is stated on all 509 variables and supported by none of the 858 citation
uses.

## `web_search_result` — 31 citation(s)

identity from live web-search results and publisher URLs carrying the DOI (2026-08-14 mcrc pass; PubMed and Crossref were unreachable)

- Andre T et al. 2020, N Engl J Med 383:2207-2218, DOI 10.1056/NEJMoa2017699 — cited by mcrc
- Ann Surg 2013 (mucinous and signet-ring vs classical adenocarcinoma), PMID 23989057 — cited by mcrc
- Ann Surg Oncol 2015 (conversion hepatectomy long-term outcomes), DOI 10.1245/s10434-015-4460-0 — cited by mcrc
- Ann Surg Oncol 2015 (signet-ring and mucinous components), DOI 10.1245/s10434-014-4159-7 — cited by mcrc
- Arnold D et al. 2017, Ann Oncol, DOI 10.1093/annonc/mdx175 — cited by mcrc
- CAIRO4 2021, JAMA Surg 156(12):1093-1101, DOI 10.1001/jamasurg.2021.4992 — cited by mcrc
- Cancer Sci 2014 (baseline CEA and bevacizumab-based response), DOI 10.1111/cas.12451 — cited by mcrc
- Cervantes A et al. 2023, Ann Oncol 34(1):10-32, DOI 10.1016/j.annonc.2022.10.003 — cited by mcrc
- Clin Colorectal Cancer 2014 (synchronous vs metachronous stage IV), PMID 24373733 — cited by mcrc
- Cremolini C et al. 2015, Lancet Oncol 16:1306-1315, DOI 10.1016/S1470-2045(15)00122-9 — cited by mcrc
- Cremolini C et al. 2020, Lancet Oncol 21(4):497-507, DOI 10.1016/S1470-2045(19)30862-9 — cited by mcrc
- Dasari A et al. 2023, Lancet 402(10395):41-53, DOI 10.1016/S0140-6736(23)00772-9 — cited by mcrc
- Douillard JY et al. 2013, N Engl J Med 369(11):1023-1034, DOI 10.1056/NEJMoa1305275 — cited by mcrc
- Drilon A et al. 2018, N Engl J Med 378(8):731-739, DOI 10.1056/NEJMoa1714448 — cited by mcrc
- Fakih MG et al. 2023, N Engl J Med 389:2125-2139, DOI 10.1056/NEJMoa2308795 — cited by mcrc
- Franko J et al. 2016, Lancet Oncol 17:1709-1719, DOI 10.1016/S1470-2045(16)30500-9 — cited by mcrc
- Front Oncol 2022 (MSI and metastatic colorectal cancer), DOI 10.3389/fonc.2022.888181 — cited by mcrc
- Gbolahan O et al. 2023, Cancer Med, DOI 10.1002/cam4.5133 — cited by mcrc
- Grothey A et al. 2013, Lancet 381(9863):303-312, DOI 10.1016/S0140-6736(12)61900-X — cited by mcrc
- Hess LM et al. 2019, Int J Colorectal Dis, DOI 10.1007/s00384-018-03227-5 — cited by mcrc
- Hurwitz H et al. 2004, N Engl J Med 350(23):2335-2342, DOI 10.1056/NEJMoa032691 — cited by mcrc
- Iyer P et al. 2022, JNCI Cancer Spectr 6(6):pkac065, DOI 10.1093/jncics/pkac065 — cited by mcrc
- JCOG1007/iPACS 2021, J Clin Oncol 39(10):1098-1107, DOI 10.1200/JCO.20.02447 — cited by mcrc
- Kopetz S et al. 2019, N Engl J Med, DOI 10.1056/NEJMoa1908075 — cited by mcrc
- Mayer RJ et al. 2015, N Engl J Med 372(20):1909-1919, DOI 10.1056/NEJMoa1414325 — cited by mcrc
- Sepulveda AR et al. 2017, Arch Pathol Lab Med 141(5):625-657, DOI 10.5858/arpa.2016-0554-CP — cited by mcrc
- Siegel RL et al. 2026, CA Cancer J Clin, DOI 10.3322/caac.70067 — cited by mcrc
- Simkens LHJ et al. 2015, Lancet 385(9980):1843-1852, DOI 10.1016/S0140-6736(14)62004-3 — cited by mcrc
- Strickler JH et al. 2023, Lancet Oncol 24(5):496-508, DOI 10.1016/S1470-2045(23)00150-X — cited by mcrc
- TRIBE-2 protocol 2017, BMC Cancer, DOI 10.1186/s12885-017-3360-z — cited by mcrc
- Van Cutsem E et al. 2009, N Engl J Med 360:1408-1417, DOI 10.1056/NEJMoa0805019 — cited by mcrc

## `identifier_route_unavailable` — 6 citation(s)

no PMID or DOI resolved; journal, volume and pages only, with no identifier guessed

- Cervantes F et al. 2009, Blood 113(13):2895-2901 — cited by myelofibrosis
- Maffioli M et al. 2022, Blood Adv 6(6):1855-1864 — cited by myelofibrosis
- Malcovati L et al. 2020, Blood 136(2):157-170 — cited by mds
- Passamonti F et al. 2010, Blood 115(9):1703-1708 — cited by myelofibrosis
- Passamonti F et al. 2010, Blood 116(15):2857 (DIPSS predicts progression to AML) — cited by myelofibrosis
- Platzbecker U et al. 2019, Blood 133(10):1020-1030 — cited by mds

## `in_house_drafting_surface` — 2 citation(s)

a concept stated on a live pack's committed drafting surfaces, not literature

- in-house: oc 202606 programme specification (sanitized extraction) — cited by _master, ovarian
- in-house: prostate 202606 programme specification / functional contract — cited by _master, prostate

## Recorded without a confirmed author list

The harvesting pass surfaced title, journal and identifier only. The work is
identified; who wrote it was not confirmed.

- Ann Surg 2013 (mucinous and signet-ring vs classical adenocarcinoma), PMID 23989057 — cited by mcrc
- Ann Surg Oncol 2015 (conversion hepatectomy long-term outcomes), DOI 10.1245/s10434-015-4460-0 — cited by mcrc
- Ann Surg Oncol 2015 (signet-ring and mucinous components), DOI 10.1245/s10434-014-4159-7 — cited by mcrc
- CAIRO4 2021, JAMA Surg 156(12):1093-1101, DOI 10.1001/jamasurg.2021.4992 — cited by mcrc
- Cancer Sci 2014 (baseline CEA and bevacizumab-based response), DOI 10.1111/cas.12451 — cited by mcrc
- Clin Colorectal Cancer 2014 (synchronous vs metachronous stage IV), PMID 24373733 — cited by mcrc
- Front Oncol 2022 (MSI and metastatic colorectal cancer), DOI 10.3389/fonc.2022.888181 — cited by mcrc
- JCOG1007/iPACS 2021, J Clin Oncol 39(10):1098-1107, DOI 10.1200/JCO.20.02447 — cited by mcrc
- Real-world evaluation of first-line atezolizumab + etoposide-carboplatin in ES-SCLC 2023, PMID 36800677 — cited by sclc
## What each entry IS — basis, not citation route

A route grades a CITATION: was this paper's identity resolved. A basis grades the
ENTRY: is this definition a reading of the literature, a concept the house has
drafted against, or a statement the approved workbook actually makes.

- **`literature_inferred`** — 491 entries. read off published RWD methodology and tumour literature. What studies of this tumour typically define — never what any workbook states
- **`in_house_drafting`** — 18 entries. stated on a live pack's COMMITTED drafting surfaces (spec-pipeline output and hand-typed contract records). Provisional discovery metadata: what the house has drafted against, not what anyone signed
- **`workbook_confirmed`** — 0 entries. a NAMED person read the approved workbook and recorded that it states this. The only basis that carries any authority, and the only one an AI may not write

**0 of 509 entries are `workbook_confirmed`.** The promotion is a human act: a named person, a date, and a workbook registered at Gate 1 as `<pack>#<material_id>`. `citation_register.py` refuses the claim without all three, and an AI must never write it — the whole content of the tier is that a person read the document.


## Per tumour

How many of each tumour's citation uses run through each route. A tumour reading high
in a weak column is not wrong — it is a tumour whose shelf entries deserve more
scrutiny before a workbook is drafted against them.

| tumour | variables | citation uses | `pubmed_or_publisher` | `web_search_result` | `identifier_route_unavailable` | `in_house_drafting_surface` |
|---|---|---|---|---|---|---|
| cll | 35 | 52 | 52 | 0 | 0 | 0 |
| dlbcl | 38 | 54 | 54 | 0 | 0 | 0 |
| endometrial | 35 | 55 | 55 | 0 | 0 | 0 |
| gist | 32 | 48 | 48 | 0 | 0 | 0 |
| hnscc | 37 | 76 | 76 | 0 | 0 | 0 |
| mcrc | 56 | 112 | 27 | 85 | 0 | 0 |
| mds | 35 | 68 | 64 | 0 | 4 | 0 |
| multiple_myeloma | 40 | 76 | 76 | 0 | 0 | 0 |
| myelofibrosis | 36 | 74 | 62 | 0 | 12 | 0 |
| nsclc | 38 | 60 | 60 | 0 | 0 | 0 |
| ovarian | 47 | 69 | 59 | 0 | 0 | 10 |
| prostate | 50 | 69 | 60 | 0 | 0 | 9 |
| sclc | 30 | 45 | 45 | 0 | 0 | 0 |
