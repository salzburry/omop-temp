# ADR-001 — The canonical RWDP framework

- **Status:** Accepted (Wave 1) · _approvers + date to be filled on merge_
- **Deciders:** Program lead · RWP · RWDE · RWB
- **Context doc:** [`docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md`](../../docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md)

> **Update — Phase-6 executed.** The canonical system has since been moved to its target layout: the engine
> is in **`platform/`** and the governed products in **`products/oncology/<product>/`**. The Context below
> describes the *pre-move* state (the system then lived under the space-containing `current data products/`);
> the decision stands, and issue C3 (the space) is now **resolved**.

## Context

The repo carries **more than one** framework iteration, which makes it ambiguous which code is
production and sends new contributors to the wrong place (issue **C1** in the migration doc):

- **`current data products/`** — a locked PySpark engine + per-product YAML config, with an R
  (sparklyr/dbplyr) parity engine, a Databricks bundle, a refresh-manifest ledger, and a QC +
  golden-compare publish gate. **Prostate `202606` is built end-to-end** here and is the pack the
  engine is validated against.
- **`variable-specs/`** — a parallel, self-contained "pack-as-spec" framework ("lift into its own
  repo when ready").
- **`oncology/`** — an earlier pack-as-spec **design exploration** (design-only; never run).
- **`rwddataproduct_example/`** — an example/reference structure.

Without a recorded decision, each review re-opens "which one is real?"

## Decision

1. **The locked engine + per-product YAML config is the single canonical, production RWDP system**
   (realized post-move as `platform/` + `products/`; it lived under `current data products/` at decision
   time). All governed work — engine changes, product config, refreshes, releases — happens there.
2. **`variable-specs/`, `oncology/`, `rwddataproduct_example/` (and the source PDFs, programme plan, and
   demo docs) were reference / parallel / archival** — **not** production and **not** maintained as
   governed products. They served as a guiding reference during the migration and have since been
   **removed from the repo**; source provenance is now linked externally (the Excel program-spec on
   the sponsor's document store — see a product's `source_refs.yaml`).
3. **The target structure and the path to it are non-disruptive and phased** (migration doc §H):
   governance first (this wave), the physical move (`platform/` + `products/<family>/<product>/`) last
   and optional. **No product runtime changes** are required to adopt the structure.
4. **The space in `current data products/` is a known defect** (issue **C3**): it breaks `CODEOWNERS`
   path matching (GitHub cannot escape spaces), shell globs, and bundle/CI paths. Removing it is part
   of the Phase-6 rename; until then, governed paths under it cannot be CODEOWNERS-routed.

## Consequences

- New contributors are pointed to `platform/` + `products/` and the migration doc from the root README.
- Reviewers can treat anything outside the canonical system as reference and decline to gate on it.
- `CODEOWNERS` now routes the **full governed tree** (`platform/**` + `products/**` + the ledgers): the
  Phase-6 rename removed the space (C3), so the pre-move limitation is resolved. *(Every line routes to
  the sole owner `@salzburry` today — stand up real per-role teams + branch protection for
  separation-of-duties enforcement.)*
- The decision is revisitable: superseding it requires a new ADR (e.g. ADR-002) referencing this one.

## Alternatives considered

- **Keep multiple frameworks "until we decide later."** Rejected — it is the status quo that causes the
  repeated re-litigation; a recorded decision is the cheapest fix.
- **Delete `variable-specs/` / `oncology/` now.** Rejected for Wave 1 — they hold reference value and
  deletion is irreversible; archival under `reference/` at Phase 6 is reversible and lower-risk.
- **Rename `current data products/` immediately.** Deferred — it is the most disruptive single change
  (bundle, CI, every test path); it belongs in the one mechanical Phase-6 PR, after governance lands.
