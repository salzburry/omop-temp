# `record_selection` as a controlled vocabulary — a proposal

> **Status: PROPOSED, not implemented.** Nothing enforces this document. `record_selection` is free
> text today and every existing record is valid. This is the measurement and the design; adopting it
> is a separate decision, and migrating 406 records is a separate change again.

`record_selection` answers one question: **when several source rows qualify, which one wins?** Get it
wrong and the output is non-reproducible — the same cut run twice can differ. It is the field most
directly responsible for determinism, and it is currently the field with the least structure.

## The measurement

Across the **406 hand-authored records** in `prostate/202606`, `oc/202606` and the prostate/202607 revision (now a test fixture),
`record_selection` holds **65 distinct values**. They are not 65 rules. They are roughly eight rules
in 65 spellings:

```
 31  closest to index among qualifying records
 30  closest to index
  5  closest such date to index
  5  closest to index, prior to or including the index date
  5  the single closest qualifying result
  4  single closest qualifying result          <- same rule, different words
  4  closest to index among non-null values with the matching unit
  4  closest to index (latest vitaldate <= index)
  3  closest to the anchor
  3  closest
```

Ninety-four records express one rule ten ways. The same holds for existence tests, earliest-in-window
and pass-through.

This is the repo's own cardinal failure — **two definitions of one concept, agreeing today** — sitting
inside the governed contract. `single closest qualifying result` and `the single closest qualifying
result` are already two, and nothing can tell whether `closest to index` and `closest to the anchor`
are a third and a fourth or the same rule twice.

## Why it matters more than it looks

**Nothing can validate prose.** Every other controlled field in a record — `status.*`, `output.role`,
`publish.*` — is checked against a vocabulary by I3. `record_selection` is checked by nobody. A
reviewer reads it; that is the whole verification.

**Prose is where drafter capability leaks in.** Writing the rule requires *generating* text; picking a
term requires *selecting* from a list. The framework is heading toward machine drafting at scale
(299 undispositioned records in ovarian alone), possibly on a smaller model than the one a record was
prototyped with. Generation is exactly the step where that substitution shows; selection is where it
mostly does not. Converting the field is worth more than any amount of prompt tuning, because it
holds whoever — or whatever — does the drafting next.

**The engine cannot consume it.** A person reads the prose and writes code. `implementation_refs`
names the file that resulted, and `contract_binding` checks the path resolves — but nothing checks
the *rule* the code implements is the rule the record states. A `rule:` term the engine dispatches on
closes that, exactly as `bmi_method` / `bsa_method` and the named orals filters already do one layer
down. This proposal is that pattern applied to the contract layer.

*Partly narrowed since this was written, and the remainder is the argument.* `contract_binding
--parameters` now compares the record's window, its selection DIRECTION and its source stem against
the config that implements them, so `earliest` against a config that says `latest` is caught. It
does that by matching a word list against free text, which is precisely the fragility this proposes
to remove: the ECOG record says `record_selection: closest, tie_break: {equidistant: prior}` and
never the word `earliest`, so `prior` had to be added to the vocabulary after a planted flip went
through undetected. Every term a drafter reaches for that nobody thought to list is a silent pass.
A `rule:` term is selected from a list rather than generated, which is the same check without the
guessing — and it extends to the derivations, which no word list will ever reach.

## The vocabulary

A `rule:` plus optional qualifiers — the same inline-dict shape `status` and `output` already use, so
the CI lint parses it with the machinery that exists.

| `rule` | Means | Qualifiers |
|---|---|---|
| `none` | no source-row resolution applies — the variable is a constant, a parameter, or purely derived | — |
| `closest` | the qualifying record nearest the anchor | `to:` (default the record's `anchor`), `bound:` `on_or_before` / `on_or_after` / `either` |
| `extreme` | **select the ROW** that minimises or maximises a column, then read a field off it | `pick:` `first` / `last`, `by:` the ordering column, `tie_break:` |
| `aggregate` | **compute a SCALAR** across all qualifying records — no row is selected | `fn:` `max` / `min` / `sum` / `count`, `over:` the column aggregated |
| `existence` | a flag: does any qualifying record exist? No row is selected | — |
| `passthrough` | a source record already exists at the target grain and is carried through — there were never several candidates to choose between | — |
| `unstated` | **the specification does not say which record wins** | must carry a `decision_ids` entry |
| `TODO` | not yet written (what the scaffold emits) | — |

`unstated` and `TODO` are **workflow states, not executable rules**. Nothing may ever dispatch on
them, and the lint must refuse either on a record at `requirement: approved` — otherwise a pack can
reach a buildable maturity with a selection rule that was never written.

`extreme` and `aggregate` must not be collapsed, and an earlier draft of this document collapsed them.
It claimed `earliest`/`latest` were always `aggregate` with `fn: min`/`max` over a date. They are not.
`PSA6MO` records `record_selection: "earliest in each window"` and outputs a **PSA value**: the value
belongs to the row with the smallest `resultdate`. `min(resultdate)` returns a date and identifies no
row — it answers a different question, and an engine dispatching on it would be wrong. Selecting a row
by an ordering column is `argmin`/`argmax`; summarising a column is not. Two rules, two terms.

`none` and `passthrough` are likewise distinct and the same earlier draft had them overlapping — both
were defined as "one row per patient by construction", which is the exact duplication this document
exists to remove. `none` means no source row is in play at all; `passthrough` means one is, and it is
already unique at the target grain.

```yaml
record_selection: {rule: closest, to: index_date, bound: on_or_before}
record_selection: {rule: aggregate, fn: max, over: episodedate}
record_selection: {rule: existence}
record_selection: {rule: unstated}          # + decision_ids: [PROS-SITE-TIEBREAK]
```

## Fit against the real 406

**349 of 406 — 86% — classify into eight terms — but see the correction below before quoting that
figure.** The classification was made against the earlier vocabulary, which conflated `extreme` with
`aggregate`. The 86% counts how many values map to *some* term; it does not establish that they map to
the *right* one, and for the 69 records in the two aggregate buckets it is now known that at least
some are `extreme`. The split must be re-measured after the audit below.

| `rule` | records | share |
|---|---:|---:|
| `none` | 120 | 30% |
| `closest` | 97 | 24% |
| `aggregate` / `extreme` (max-shaped) | 38 | 9% |
| `aggregate` / `extreme` (min-shaped) | 31 | 8% |
| `existence` | 23 | 6% |
| `unstated` | 15 | 4% |
| `passthrough` | 14 | 3% |
| `TODO` | 11 | 3% |
| **no fit** | **57** | **14%** |

The 57 that do not fit are four distinct problems, and only one of them is the vocabulary's fault:

| cause | records | distinct |
|---|---:|---:|
| implementation strategy written into a requirement field | 33 | 7 |
| genuinely open prose | 13 | 5 |
| per-cohort dispatch — one record, a different rule per cohort | 8 | 3 |
| multi-variable record (already an I16 violation) | 3 | 2 |

**The true irreducible remainder is 13 records — about 3%.**

- The **33** are values like `"B1 aggregate-then-join: drug_episode filtered to the cohort setting,
  aggregated to patient+linenumber"` and `"linesetting='mCRPC', new_lot_n in {1,2,3,4}, dedup one
  row/patient"`. Those say how the engine does it, not which record wins. They belong in `derivation`
  or `implementation_refs`. Adopting the vocabulary surfaces a filing error that exists today.
- The **3** are records covering two variables at once (`"<SITE>_METDT: earliest at the site;
  <SITE>_MET: existence of any record"`). I16 already forbids that at `contract: coverage_complete`;
  fixing I16 fixes these.
- The **8** need a nested shape or a record split. Left unresolved here on purpose — a vocabulary
  invented for eight records before anyone has looked at them is a guess.

## The finding that was not the point of the exercise

Fifteen records say, in prose, that the specification does not answer the question:

```
8  "not stated — the rows do not say which record wins when a site has several dates"
6  "NOT STATED — the rows define a window but not which result in it is taken"
1  "unstated — the row says 'merge onto patient level data' without saying which record wins"
```

Someone read the spec, found a real gap, and wrote it down honestly. **Nothing can see it.** No lint
counts it, no gate blocks on it, no register carries it. Fifteen open questions are recorded in a
field no check reads.

As `{rule: unstated}` the admission becomes machine-readable, and I17's logic extends to it directly:
a record stating the specification is silent must name the decision that will settle it. That is the
strongest single argument for adopting this, and it is independent of who does the drafting.

## What adoption would require

1. `RECORD_SELECTION_RULES` in `platform/tools/contract_lint.py`, beside `REQ` / `SRC` / `IMPL` /
   `ROLE`, validated by I3's existing enum machinery — one place, no second definition.
2. An invariant tying `{rule: unstated}` to a `decision_ids` entry, mirroring I17.
3. `contract_scaffold.py` emitting `{rule: TODO}` rather than bare `TODO`.
4. A migration of 406 records. **Stage it**: `record_selection` alone first, measure, then decide on
   `tie_break` (16 distinct, 67% on one value — likely easy). Do not touch `window` (56 distinct) or
   `cohort_applicability` (71) until the first one has been through a real review.
5. Engine dispatch on `rule:`, if and when the contract→code binding is worth tightening. Everything
   above stands without it.

## What this does not fix

`missing` holds **106 distinct values across 406 records**, with the most common covering 8%. That
one looks genuinely per-variable and no vocabulary is proposed for it.

And the classifier behind the 86% is **regex over the recorded text, not semantics**. It is known to
be wrong in kind, not merely over-generous: it filed `"earliest in each window"` (PSA6MO, PSA12MO) as
`aggregate: min` when the record selects a row and reads a value off it — `extreme`, not `aggregate`.
That error is now corrected in the vocabulary but not in the measurement.

So before anyone commits to the migration, someone who knows the domain must audit the **69 records**
in the two aggregate-shaped buckets and split them into `aggregate` and `extreme`. Until that
happens, 86% is the ceiling on *coverage* and says nothing about *correctness*, and no figure in this
document should be quoted as settled.
