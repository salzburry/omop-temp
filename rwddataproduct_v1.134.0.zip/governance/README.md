# `governance/` — the operating contract for the RWDP system

Governance-only artifacts that sit **around** the runnable system (`platform/` + `products/`) without
changing how it builds. This directory is **Wave 1** of the production migration
([`docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md`](../docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md) §H) — it
adds review routing, version policy, and machine-checkable schemas with **zero file moves**. The
physical restructure (`platform/` + `products/<family>/<product>/`) is a later, optional phase.

| File | What it fixes |
|---|---|
| [`WORKFLOW.md`](./WORKFLOW.md) | The **governed workflow** — roles, the six governance gates, the AI/vendor-material boundary, the status and traceability models, and the new-product vs refresh branches. Tumor-agnostic; each product's `handoff/` records which controls are live for it. |
| [`decisions/ADR-001-canonical-framework.md`](./decisions/ADR-001-canonical-framework.md) | Records which framework is **prod** vs reference (stops the re-litigation in issue C1). |
| [`VERSIONING.md`](./VERSIONING.md) | The three version axes (engine SemVer · spec CalVer · data refresh), the bump rule, and change classification. |
| [`schemas/release.schema.json`](./schemas/release.schema.json) | The shape of a released refresh manifest / release record (the audit ledger). |
| [`schemas/tfl_qc.schema.json`](./schemas/tfl_qc.schema.json) | The TFL QC gate result (per-TFL applicability + skip states). |
| [`schemas/source_refs.schema.json`](./schemas/source_refs.schema.json) | The lightweight, presence-only product → source-material index. |

These are enforced by `platform/tests/test_governance.py` (runs in `rwdp-ci`):
the engine `VERSION` is valid SemVer, the schemas are well-formed, every **active** product carries a
well-formed `source_refs.yaml` whose local materials exist, and the root `CODEOWNERS` covers governance.

> **Why governance lives at the repo root, not under `platform/` or a product:** it is *repo-level*
> (CODEOWNERS, ADRs, version policy apply across every product and the engine), and the target structure
> puts it here. It is repo-level and applies across `platform/` + every product.
