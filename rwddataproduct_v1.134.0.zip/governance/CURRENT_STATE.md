# Current state — GENERATED, do not edit

Every number here is computed on demand by the tool that owns the question; this file is
written by `platform/tools/current_state.py` and byte-compared in CI. Prose elsewhere
should POINT HERE rather than restate a figure, because a number copied into a paragraph
is true on the day it is written and free to drift afterwards — which is exactly what an
external review found in `HANDOVER.md`, in four places at once.

Most of what follows is zero. Each zero is a place where only a person can write, and
printing them is the point: a report that omitted its zeroes would read as a system with
nothing outstanding.

## Approver identity

`approval_identity.py`. The unit is the APPROVAL, bound to the commit whose diff wrote it. Registering a key is a person's own act and re-signing history is not possible at all, which is why these are separate numbers: they need different actions, and one figure would hide which is the blocker. Baselined approvals predate the mechanism and are grandfathered by (file, field, who, commit) — re-make one and it comes back under the check.

| what | count |
|---|---:|
| person_review keys registered | 0 |
| governed approvals on disk | 3 |
| …authenticated by a signature | 0 |
| …baselined as predating the mechanism | 3 |
| …neither — `--check` fails on these | 0 |
| governed surfaces holding no file | 7 |

## Decisions

`knowledge_graph.py`. A decision becomes citable precedent when it carries BOTH a named approver and a usable date.

| what | count |
|---|---:|
| packs keeping a decision register | 2 |
| decisions recorded | 30 |
| …RESOLVED | 3 |
| …RESOLVED with a named approver AND a usable date | 0 |
| …cited by at least one contract record | 23 |

## Precedent store

`precedents.py`. Two independent axes — how far the evidence REACHES and what AUTHORITY stands behind the answers — both computed from the live registers, never stored. Only governed product packs count as sightings; a test fixture is not evidence.

| what | count |
|---|---:|
| precedent entries | 2 |
| …reach `multi_tumour` | 2 |
| …reach `single_tumour` | 0 |
| …authority `ruling` | 0 |
| …authority `answer` | 0 |
| …authority `partial` | 0 |
| …authority `question` | 2 |
| …authority `unresolvable` | 0 |

## Engine capabilities

`capability_registry.py`. `component_parity` compares what the two engines COMPILE or COMPUTE; `stage_conformance` would compare stage OUTPUT and no harness can support it yet.

| what | count |
|---|---:|
| capabilities registered | 22 |
| …with an engine at `declared` | 12 |
| …with an engine at `unit_tested` | 12 |
| …with an engine at `component_parity` | 10 |

## Reference shelf

`citation_register.py`. `workbook_confirmed` is the only basis that claims anything, and it now requires Gate 1 to pass on the bytes.

| what | count |
|---|---:|
| shelf variables | 509 |
| …`workbook_confirmed` by a named person | 0 |

## Citations

`citation_register.py`. Records and works differ because one work cited in two spellings is one work.

| what | count |
|---|---:|
| citation records | 281 |
| …distinct identifiers (spellings merged) | 246 |
| …declared cross-scheme work equivalences | 0 |
| …route `identifier_route_unavailable` | 6 |
| …route `in_house_drafting_surface` | 2 |
| …route `pubmed_or_publisher` | 242 |
| …route `web_search_result` | 31 |

---

Nothing in this file is an approval, and no count here is evidence that a value is
correct. These are counts of RECORDS, and a record says who claimed something, never
that the claim is true.
