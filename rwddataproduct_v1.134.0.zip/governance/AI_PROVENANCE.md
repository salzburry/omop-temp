# AI provenance — what a session records, and what it cannot

The external review of `main@a5bafe4` was right: a `Co-Authored-By` trailer is attribution, not an
audit trail. This file states exactly which provenance facts this repository captures, where each
one lives, and — the part that must not be papered over — which facts **cannot be captured from
inside an agent session** and therefore need an organisation-side control if they are required.

## Captured, and where

| Fact | Where it lives | Why it is trustworthy |
|---|---|---|
| Which model authored a change | `Co-Authored-By: Claude <model>` commit trailer | Written per commit; verifiable only as strongly as the commit itself (see limits) |
| Which session produced it | `Claude-Session: <url>` commit trailer | Resolvable by the account owner to the full conversation |
| The exact skill text a session ran | the commit SHA — `.claude/skills/**` is in-tree, so any commit pins every skill byte-for-byte | Content-addressed by git; no separate register can drift from it |
| Which instruction *set* that was | `version:` in each skill's frontmatter | Bumped on instruction changes; the CI version guard covers `.claude/skills`, so an unbumped behavioural edit needs `platform/VERSION` to move or a visible waiver |
| What the change did to governed rows | the diff itself, plus `config_diff.py --all --base <rev>` (semantic, not byte) | Derived from both revisions at read time, never hand-written |
| What the operating instructions were | `docs/ENGINEERING.md` + the skills (the former `CLAUDE.md` was deliberately converted to `docs/ENGINEERING.md`; agents are pointed at it rather than auto-fed) | In-tree, pinned by the commit like everything else |

## Not capturable from inside a session — stated as a limit, not papered over

An agent cannot attest facts about its own runtime that its runtime does not expose to it, and a
self-reported value here would be **exactly the `--actor` pattern this repository removed**: the
same process that could misreport the value is the one writing it down.

| Fact | Why it cannot come from the session | The control that would capture it |
|---|---|---|
| Exact model build/revision and sampling settings | Not exposed inside the session; a self-typed value is unverifiable | Provider-side logging (API request logs), org-retained |
| System-prompt snapshot or hash | External to the repository and to the session's writable surface | Org-side session export/retention |
| Tool-call transcript, durable and tamper-evident | The session can write *a* transcript; it cannot make it tamper-evident against itself | Org-side session export; the `Claude-Session` URL resolves to the provider-held record |
| Conversation-memory / context manifest | Same self-attestation problem | Org-side export |
| That the committer *is* the agent (or is not) | Git author/committer strings are self-asserted | Signed commits / branch-scoped tokens (GitHub-side) |

**Practical consequence:** any release process that requires those facts must obtain them from the
provider/org side. Nothing in this repository claims to hold them, and any in-repo file that
appeared to should be treated as unverified text.

## The conventions, normatively

1. Every agent-authored commit carries both trailers (`Co-Authored-By`, `Claude-Session`).
2. Every skill carries `version:` frontmatter and bumps it when its **instructions** change; the
   CI version guard makes an unbumped `.claude/skills` edit visible.
3. An agent session records nothing about itself that it cannot verify — no sampling settings, no
   prompt hashes, no self-attested transcripts inside the repository.
4. The agent's write surface is a branch; merge, approval and deploy authority are withheld by
   GitHub/Databricks configuration, **not** by anything in this repository (see
   `docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md` on branch protection — an admin-side control this
   file can only point at).
