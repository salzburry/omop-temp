# Why this skill says what it says — the measurements behind the rules

Everything here is EVIDENCE for a rule in `SKILL.md`, not an instruction. It is separated for one
reason: these are **counts of a moment**, and a count embedded in an operational instruction goes
stale silently. The contract-sanitization work already changed one of them (the quotation counts) in
the same week it was written, while the sentence carrying it still read as current guidance.

Read this when you want to know whether a rule is worth following. Do not read it to find out what to
do — that is `SKILL.md`, and it is the only file that governs a run.

Regenerate any figure here rather than trusting it:

```bash
python3 platform/tools/source_manifest.py <pack> --ai-boundary       # vendor quotation counts
python3 platform/tools/contract_lint.py <pack>                        # live invariant failures
python3 platform/tools/spec_slice.py <pack> --domain <d>              # what a drafter actually sees
```

---

## 1. Inventing an answer to an already-flagged row was 100% of the error mass

The rule it supports: *"A record citing a row flagged VERIFY_MARKER / PLACEHOLDER / TRUNCATED /
NO_TERMINAL_ELSE must leave the field TODO or name a decision/gap"* (invariant I17).

An earlier full drafting run against the ovarian workbook produced **295 records**. Scored against the
lint as it stands: **99 of them — 45% of the 220 records that cite a flagged row — answered a question
the specification does not contain.** No other error class appeared at all.

Every one of those rows had already been flagged, automatically, before drafting began. The failure
was not detection; it was a drafter reading a flag and answering anyway.

### Severity was the trap

**97 of the 99 involved only `VERIFY_MARKER` and `PLACEHOLDER`, which carry severity INFO.** Just 2
involved anything marked HIGH. Meanwhile `UNBALANCED` and `OUTLIER_IN_LIST` are HIGH and do NOT mean
the spec is silent — they mean the row looks internally inconsistent.

That is why `SKILL.md` says to judge by KIND and never by severity. A row scrolls past as INFO and is
still a question the specification declines to answer.

### The move that produced them

"The answer is obvious from the sibling row." It is the most reasonable-sounding wrong move available,
which is why the rule has no third option and why the slice now redacts neighbouring records rather
than trusting an instruction not to copy from them.

---

## 2. Vendor documentation quoted inside sponsor-authored material

The rule it supports: the slice REFUSES when its assembled content trips a marker in
`governance/ai_boundary.yaml`. That is now one of several bindings on the pack's registered
`ai_extraction` — the derived, redacted artifact a named person approves — rather than a check
against the classification recorded on the input, which is what it was when this eval was written.

At the time the check was built, **both prostate packs carried about forty quotations each** — mostly
the BP/BPSYS/BPDIA family, where the `TestResultCleaned` conditions are copied out of a Flatiron
Knowledge Center article. Ten records were sanitized afterwards, so the current figure is lower and
you should measure it rather than quote this sentence.

What has not changed is the shape: **a recorded classification and the content it describes can
disagree, and the field is the half people look at.** `governance/WORKFLOW.md` §"Eligibility" is
explicit that eligibility follows the CONTENT's provenance, so an internally authored document that
quotes vendor documentation inherits the restricted classification.

### The marker that was REJECTED, and why it matters more than the ones accepted

`vendor documentation` reads like the obvious marker. It is not one. The ovarian workbook's Review
Decisions tab says: *"A tick = 'this is what the cited vendor documentation says' — NOT approval, NOT
proof the feed delivers it."* That is the sponsor DISTINGUISHING a vendor claim from an approved fact
— meta-commentary about the boundary, and the opposite of reproducing vendor prose. It produced nine
hits on the one pack that is genuinely clean.

The lesson: a marker must name the ACT of quoting, not the SUBJECT being discussed. A phrase people
use to talk ABOUT vendor documentation fires hardest on the documents most careful about it.

---

## 3. Invented source aliases, and what they cost

The rule it supports: `source.kind: pending_mapping` with `spec_identifiers` copied verbatim, on a
pack whose `config/` does not exist yet.

* `psmapet` in prostate/202606 and `psma_pet` in prostate/202607 are the same vendor table spelled two
  ways, and **neither pack declares either**. Nothing can now tell whether two records mean one source
  or two, and the next drafter has no reason to prefer either spelling over a third.
* A frozen ovarian run with no config at all asserted **fourteen** aliases — `oc_clinical`,
  `drugepisode`, `biomarkers`, `adverse_events` — every one made up on the spot.

Before `pending_mapping` existed, the skill could only say what NOT to write while offering nothing
the parser accepts. Drafters filled the gap with `TODO`, a physical table name, or an invented alias —
and the last is indistinguishable from a real mapping once config arrives.

### The gap requirement that broke the path it was written for

An earlier version demanded a `gap_ids` entry alongside `pending_mapping`. The starter pack ships no
`ENGINE_GAPS.md` — a gap is an APPROVED requirement the build or feed cannot satisfy, Gate 4 material
that arrives after the contract exists — so the cited id resolved to nothing and I2 failed on every
genuinely new product. The requirement was removed; `pending_mapping` is already explicit, countable
and barred from approval, so that state IS the backlog.

---

## 4. The shifted-column defect nobody sees

The rule it supports: *"You write `key: value`. You do NOT write the row."*

One unescaped `|` in `derivation` shifts every later field one column left. `status` lands in
`decision_ids`. The lint then reports a vocabulary error **in a field the drafter never touched** —
and every individual cell stays well-formed, so nothing catches it by shape.

At one record that is a nuisance. At several hundred per product it is a defect generator, and the
reviewer reading the diff cannot reliably catch it. Four mechanical rules applied by hand (field
order, pipe escaping, newline folding, cell count) is not a judgment call a drafter should be making
hundreds of times.

`contract_record.py` proves its own output: every field is re-parsed out of the rendered row through
the same parser every gate uses and compared byte-for-byte with what went in.

---

## 5. `--product` was documented in brackets, and that was most of the risk

The rule it supports: `--product` is required; `--format-only` is the named way to opt out.

Completeness and the round-trip run without a pack, which is what made the bracketed form look
sufficient. But **I8** (do the cited rows exist), **I15** (does the digest still match), **I17** (is an
unsettled row answered), and the decision- and gap-reference checks all need the pack. A drafter
following the documented command got a clean-looking record no gate had seen.

---

## 6. Machine-owned fields were machine-owned only in prose

The rule it supports: `--item <domain:row>` supplies `spec_refs`, `spec_digest` and `required_rule`,
and the tool REFUSES a draft that also carries them.

The skill has said "pass these through, never author them" since the first version. The tool then
accepted the entire record from the model, so the rule was a sentence in a prompt.

Two different failures follow, and the second is worse:

* retyping a digit of the digest fails I15 loudly, with a message about hashing;
* tidying `required_rule` into better English replaces the spec's exact words with a paraphrase and
  **nothing fails at all**. The record reads well and no longer says what RWB wrote.

Verified: replacing one real digest with `TODO` in prostate/202606 produces
`[AGE] I15 spec_digest TODO but the cited spec rows now hash to 84862a4fc275`.

---

## 7. Registers that cannot be reconciled

The rule it supports: the slice carries a QC-finding index and a gap index for the rows in scope, and
reports register citations that resolve nowhere.

The slice previously carried a decision index and nothing about the other two registers. A drafter
working one domain could see that a question had already been raised and could NOT see that the defect
was already a QC finding or the shortfall already a gap — so two agents working two domains would each
raise the same finding under a different id, in the one register nobody deduplicates afterwards.

Building that index surfaced a live defect: **prostate/202606's `SPEC_QC_FINDINGS.md` carries six
`Spec ref` cells naming sheets the workbook does not contain** — `5B.ClinVars` and `5D.Outcomes`,
where the actual tabs are `5B. ClinChars` and `6.Outcomes`. Those findings cannot be matched to a row
by anything. Matching is punctuation-insensitive (`3.DataPrep` is `3.data prep`) and deliberately no
fuzzier: `ClinVars` and `ClinChars` are different words, and linking them would attach a finding to a
row nobody said it was about.
