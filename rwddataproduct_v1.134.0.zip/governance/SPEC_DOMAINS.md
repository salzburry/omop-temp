# Specification domains — the citation vocabulary

Every contract record cites the specification rows it comes from, as `spec_refs: [<domain>:<row>]`.
This file defines the domains. It is repo-level and **product-agnostic**, because the alternative —
citing each workbook's own sheet names — produces a vocabulary that means nothing outside that one
document and changes whenever RWB reorganises their tabs.

Prostate's workbook labels its clinical sheet `5B. ClinChars` while the contract cited `5B.ClinVars`;
ovarian calls the same content `6.Clinical characteristics`. Same requirement domain, three spellings,
none of them portable. The domain is the stable name; the sheet label is an implementation detail of a
particular workbook.

## The domains

| # | Domain | Covers |
|---|---|---|
| 1 | `study_period` | data preparation, study time periods, index/follow-up window definitions, release metadata |
| 2 | `study_population` | cohorts, inclusion and exclusion criteria, treated/untreated splits |
| 3 | `demographics` | age, sex, race, ethnicity, region, practice type, socioeconomic index |
| 4 | `clinical` | clinical characteristics, staging, labs, vitals, biomarkers, disease history |
| 5 | `treatment` | lines of therapy, drug categories, prior treatment, concomitant medication |
| 6 | `outcomes` | survival, progression, response, time-to-event and their eligibility gates |

A citation is `<domain>:<row>`, where **row is the original Excel row number** in the source workbook —
that is what lets a reader open the approved document and land on the exact line. A range is
`clinical:17-46`.

Products may add a domain when they genuinely carry requirements outside these six (ovarian's
platinum-sensitivity strategy is a candidate). Add it here first, so it stays one shared vocabulary
rather than a per-product invention.

## Sheet → domain mapping

One map, shared by every product: [`spec_sheet_map.yaml`](spec_sheet_map.yaml). RWB's sheet names are
their template, so the mapping is a repo-level fact, not a per-product one — a new tumour normally adds
nothing. The map is data, never hardcoded in a tool; that is what lets one pipeline serve every product.

The map does double duty. **A sheet listed in it is requirement-bearing by that fact**, and that is how
the pipeline decides what to scan. Sheets not listed — cover pages, change logs, review-decision
trackers, approval gates, backlogs — are skipped deliberately: they legitimately say "confirm" and
"[TBD]" throughout, and including them turned ~15 real ovarian findings into 392.

A product overrides or extends the map only for a sheet genuinely specific to itself, via `DOMAINS` in
its `spec_pipeline/pipeline.conf`. Anything RWB ships across products belongs in the shared map instead.

If a workbook uses a label the map does not carry, the extractor prints it under `UNMAPPED` and the rows
on that sheet are not scanned — visible, not silent.

## The record keys

Separately from the citation vocabulary, every contract record carries the same **21 keys**. That list
is defined in `FUNCTIONAL_CONTRACT.md` section B and **enforced** by invariant I6 in each product's
`handoff/tests/test_functional_contract.py`. It is deliberately not repeated here: a second copy is a
second thing to drift, which is the failure this repo has already had to undo once.

Order matters and is fixed — the contract is read side by side across records, so a stable key order is
what makes a diff legible. That order lives in exactly one place, `CANON_ORDER` in
`platform/tools/contract_scaffold.py`, which is what emits records in it. This file used to restate the
list three lines below the sentence warning against restating it, and the copy had already gone stale:
it was missing `spec_digest`.

`status`, `output` and `publish` are single-line inline dicts. The lint parses them positionally, so a
multi-line version parses as absent and the record silently fails I6.
