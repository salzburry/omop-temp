# Refresh governance — git IS the ledger

Every released data cut (a **refresh**, e.g. `2026q1` → `2026q2`) is tracked as a committed
manifest, so the full history of what was built, from what, and signed off by whom lives in git.

## How a refresh is tracked

```
refreshes/<family>/<product>/<spec_version>/<refresh>.yaml      # one manifest per (product, spec_version, refresh) — committed
```

The manifest (see `REFRESH_TEMPLATE.yaml`, built by `platform/engine/refresh.py`) records:
spec version, **git commit**, run params, row/cohort **counts**, the **QC** result, the
**golden-comparison** summary, and **sign-off**. Because it's committed, the ADS is reproducible:
checkout the commit (or the release tag), re-run the same config + refresh.

## Lifecycle (one refresh)

> **The approval comes BEFORE the swap, not after it.** This section used to read run → publish →
> copy the manifest into git → QC reviewer signs → set `status: released`, which was the order before
> Gate 6 existed. In that order the public views had already moved by the time anyone signed
> anything, so the sign-off recorded who noticed a release rather than who authorised one. The runner
> now refuses to publish without a named approval of the specific build. The steps below are the
> order it actually enforces.

1. **Run** the build (`databricks bundle run rwdp_build_<slug> --var <slug>_refresh=… --var <slug>_artifact_root=…`).
   The runner runs source QC → build → staging → ADS QC + golden gate → deliverables (dictionary +
   dashboard + TFLs) → **durable ledger**. It writes `manifest.yaml` + `qc_report.md` (and the
   dictionaries) to the **durable `artifact_root`** (a UC Volume / DBFS path). A Databricks job can't
   push to git, so this is the reliable record.
2. **Gate 6 stops there** on a prod run with no matching approval: staged and QC'd, no versioned
   release table, no release pointer, no public view touched, `published_at` null. It prints the
   `build_id` and the candidate manifest's sha256, and writes them to
   `<artifact_root>/release_candidate.yaml`.
3. **Approve THIS build.** A person reads `<artifact_root>/manifest.yaml`, verifies its digest
   themselves (`sha256sum` — the runner never rewrites that file after hashing it), and fills
   `<pack>/handoff/RELEASE_APPROVAL.yaml` from
   `platform/TUMOR_TEMPLATE/handoff/RELEASE_APPROVAL.example.yaml`: `approved_by`, `approval_date`,
   `validated_by`, `validation_date`, `approved_build_id`, `approved_manifest_sha256`. The QC and
   golden evidence being reviewed here is what closes Gate 5; `validated_by` is that reviewer.
4. **Promote the approved candidate** — swap the public views without rebuilding. **NOT IMPLEMENTED.**
   A rerun mints a new `build_id`, so an approval of build A cannot be satisfied by run B. The four
   requirements this needs are in `../products/OPERATIONS.md` §"Gate 6". Until it is built, a governed
   prod release cannot complete, and steps 5–6 describe the intended end state rather than a path you
   can walk today.
5. **Promote the manifest into git** (the ledger): copy it from `artifact_root` into
   `refreshes/<family>/<product>/<spec_version>/<refresh>.yaml` and open a PR — manually
   (`databricks fs cp <artifact_root>/manifest.yaml "refreshes/<family>/<product>/<spec_version>/<refresh>.yaml"`)
   or via a small scheduled "promote" CI job. The PR is the reviewed refresh record. `sign_off.qc_*`
   and `sign_off.released_*` in the manifest carry the same people as the Gate 6 form —
   `validated_by`/`validation_date` become `qc_by`/`qc_date`, `approved_by`/`approval_date` become
   `released_by`/`released_date`. That mapping is performed by the promotion step, which is why it is
   not yet performed anywhere.
6. **Release**: `status: released` + `sign_off.released_*`, merge, and tag
   `release/<registry_code>/<spec_version>/<refresh>` (e.g. `release/mcrpc/202606/2026q1`; the `spec_version`
   segment avoids cross-version collisions). ADS rows carry `spec_version` + `data_refresh` stamps matching the manifest.
   A superseded refresh is marked `status: superseded` (kept for audit).

> **The R engine is not a refresh path.** `platform/engine-r/` can rebuild the same ADS from the same
> config for cross-validation, but it has **no manifest, QC/golden gate, or release pointer** — it never
> produces a `refreshes/…` ledger entry. Use it only as a side-by-side check (write to a **separate `_r`
> schema**, then golden-compare vs the governed Python ADS); see `../platform/engine-r/README.md`.

## Branching

- Spec/engine changes land on feature branches → PR → `main` (reviewed config diff).
- A refresh that only changes the data cut is a `--var refresh=…` run + a manifest commit; no code
  change. The manifest's `git_commit` pins the exact engine/spec used.
