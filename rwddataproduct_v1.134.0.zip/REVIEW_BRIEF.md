# Review brief

For a reviewer who has never seen this repository, and does not need to.

## What this is

A **governance framework for regulated data products**. One party writes a specification; a second
party interprets it into executable configuration; it runs against sensitive third-party data;
nothing publishes until a human has attested to specific bytes, and every stage is bound to the one
before it by a hash. The framework's job is to make a pipeline that **cannot lie about its own
state**.

Its first tenant is oncology real-world data, so the vocabulary you'll see — cohort, line of
therapy, index date — is domain content sitting on top of the framework, not the framework. Roughly
half the tooling never mentions the domain at all (`profile_io`, `profile_facts`,
`legacy_source_resolve` are entirely domain-free; most others carry the odd clinical word in a
comment or an example). What you are reviewing is Python, YAML and CI configuration.

## There is no data here

**Zero data files** (run `repo_hygiene.py --check` for the live tracked-file count). No CSV, no TSV, no parquet — nothing patient-level, and the
framework's own `repo_hygiene.py` refuses to let any in (it scans the git index, the working tree,
**and** history). A clinical variable name like `AGEGR1N` is a banding rule in a schema, not a
person. Reviewing this needs no clinician and no medical judgement.

```
106 .py · 100 .md · 83 .yaml · 18 .R · 17 .json     — and 0 rows of anyone's data
```

## The one idea

Everything derives from one binding. `contract_lint.spec_digest` (`platform/tools/contract_lint.py`)
hashes `item_id + content_hash` for every specification row a record cites. So a contract record is
bound to the **text** of the spec, not to a line number — retype the spec and the digest breaks and
CI fails. That single mechanism is what makes "the code implements the spec" checkable rather than
asserted.

## The five questions worth your time

Each is domain-free, and each has a place to look.

### 1. Is `releasable()` genuinely derived, with no settable escape?

`source_manifest.releasable` (`source_manifest.py:1006`) is meant to be *computed* from Gates 1–4 —
there should be no flag anywhere that grants release directly. Six tools read it
(`bundle_products`, `deploy_tree`, `dry_run`, `demo`, `precedents`, and its own module); none should
be able to set it. `bundle_products.activation_errors` makes `schedule_enabled: true` **require**
`releasable(pack)` — check that dependency runs one way only, and that it uses `is True` rather than
truthiness (so `1` or `"yes"` from a hand-edit does not pass).

### 2. Are the fail-closed paths actually fail-closed?

The rule is that an absence refuses rather than passes: an absent counter is not a zero, an
unreadable register is not a clean one, a missing extraction is not "no changes". **This is the most
productive thing to attack, because ten instances were fail-*open* when this session began** — a
test suite that skipped and passed, an unstarted config reported as "drifted", a coverage conclusion
drawn over 299 unexamined rows, a new-tumour cold-start test whose fixture did not exist. Each is now
a `test_*` that was mutation-verified to fail against the bug. Look for the next one. The shape to
hunt: any function that can return a clean-looking result without having examined anything.

The last two have their own shapes and are worth hunting separately.

**One decision, two doors.** `source_manifest.ai_readable` is the single answer to "may AI read this
pack"; `spec_slice` asked it and `contract_record --item` did not, so the same artifact was refused
and served depending on which tool you ran. Pick any predicate that gates something and ask who
*else* should be calling it — the duplicate is rarely a second implementation, usually a caller that
never asked.

**Two sides checked, three sides needed.** `contract_binding` proved a config block name resolves
between the *contract* and the *config*. Rename a block in both and it is satisfied, `validate.check`
passes, `finalize --check` passes — and the *engine*, which reads the old name, silently stops
producing the variable (`emitted_variables` 153 → 151, `AGEGR1`/`AGEGR1N` gone). Wherever two
artifacts are checked against each other, ask whether a third one has to agree as well.

### 3. Does "one definition per concept" hold across 31 tools?

The cardinal rule (see `docs/ENGINEERING.md`) is that no concept has two implementations. The proof-shape is an
**object-identity assertion** — 22 of them — e.g. `dry_run.source_manifest is source_manifest`
(`test_dry_run.py:69`), or `blocks.BMI_FORMULAS is validate.BMI_FORMULAS is clinical.BMI_FORMULAS`
(one registry object shared across three modules). These assert the two sides share the same *object*,
not merely that they agree today. Check that a tool computing a governed number imports it rather than
recomputing it — the register-column vocabulary (`contract_lint.ANSWER_COLUMNS` and friends) is a
good test case: one pack spelling a column `Resolution` and another `Approved answer` silently
discarded a resolved answer until that vocabulary was centralised.

### 4. Do the mutation-verified tests actually bite?

Nearly every fix this session was checked by **reverting it and confirming the test fails** — the
commit messages record the mutations and their caught output. Spot-check one: pick a `test_*` that
claims a guard, break the guard in the tool, run the single test, confirm it fails. If any doesn't,
that is a finding worth more than a dozen passing ones.

### 5. Is `spec_digest` a sound binding?

The load-bearing claim of §"The one idea". Read `spec_digest` and `spec_rows`
(`contract_lint.py:644` and nearby) and ask: can the spec text change without the digest moving? Can
two different specs collide to one digest? Is a record with no digest ever treated as validated
(it must not be — see `spec_diff.py`, which carries a record forward **only** on a matching digest and
re-drafts everything else)?

## How to run it — read-only, ~1 minute, no data

```bash
python3 platform/tools/repo_hygiene.py --check              # live count, nothing refused
python3 platform/tools/repo_hygiene.py --history --check    # ...and nothing in history either
python3 platform/tools/demo.py products/oncology/prostate/202606   # the six gates, end to end
```

The Python suites run from `platform/`; the gate tools from the repo root. The full sweep is in
`docs/ENGINEERING.md` §"Verify before claiming". Two suites (`test_stages_spark`, `test_smoke_spark`) need
PySpark and a JDK; everything else is stdlib plus PyYAML.

## The changed surface

This review's diff is the commits from `a5d9b07` onward (`git log a5d9b07^..HEAD`). Fourteen changes,
each with a test. In one sentence each:

| commit | what it does |
|---|---|
| `dry_run` | shows the blockers that appear only once a pack claims approval |
| `--history` | `repo_hygiene` scans reachable history, not just the index |
| history purge | 183 vendor documents removed from all branches (502 MB → 6 MB) |
| register vocabulary | one spelling-set for the decision columns; recovered a lost answer |
| `decision_packet` | the open questions, for the person who answers them |
| `spec_diff` | which records carry to a new spec revision, on digest evidence |
| coverage scope | the binder no longer says "nobody required it" over an undrafted spec |
| CI spark job | 28 engine tests that had never executed, now do |
| cold-start fix | the new-tumour test that never ran, now runs |
| `placeholders` | classifies every REPLACE_ME; 86 unaccounted across 7 packs |
| AI gate | the drafting tool now asks `ai_readable` too — the slicer was the only one that did |
| config reads | the binder refuses a config block the engine never reads; a rename used to drop 2 variables silently |
| published names | a record may not promise a column the catalog does not carry; 3 real, not the 92 the wrong oracle reported |
| revision status | `contract_record` passed a path where text was wanted, so every revision reset the status it was meant to preserve |
| `GLOSSARY` / `DEMO` | domain-neutral onboarding, self-checked against the code |

## What is NOT ready, stated plainly

- No pack is releasable — by design; each is blocked on human approvals and live-data evidence.
- The build runs on **synthetic** sources; no real vendor data is reachable in any environment here.
- 26 engine gaps stand between the current state and "spec-only editing"; they cluster into ~4
  capabilities (see `handoff/ENGINE_GAPS.md` on any prostate pack).
- 48 of 51 decisions are open. The framework is built to make that visible, not to hide it.
