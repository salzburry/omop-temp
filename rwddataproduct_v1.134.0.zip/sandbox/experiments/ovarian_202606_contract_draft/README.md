# Historical snapshot — an exploratory drafting run, NOT governed evidence

This directory is a **frozen record of one experiment**: an end-to-end AI drafting run against the
ovarian 202606 reconstructed workbook, made while developing the `draft-contract-record` skill.

**Nothing here is evidence for anything.** It is not drift-checked, not discovered by
`product_gates.products()`, not covered by any CI gate, and not a product pack. Do not cite it in an
approval, a maturity claim, or a gate argument. If you want a governed ovarian product, that is
`products/oncology/oc/202606`.

**NOT RUNNABLE, and deliberately so.** Its `source_refs.yaml` points at the OC pack's workbook, which
is a LIVE governed file: re-running the pipeline here would extract whatever that workbook says today
and overwrite a snapshot whose only value is being what it was. A "frozen" artifact that changes when
another product changes is not frozen. The captured `spec_pipeline/out/` IS the record — read it, do
not regenerate it. If you want a repeatable conformance fixture rather than a historical specimen,
build one from a small synthetic `.tsv` tab set that nothing else owns; that is a different artifact
with a different purpose, and it does not belong in this directory.

## Why it lives here

It was written into `sandbox/new_tumour_start`, which `sandbox/README.md` and `START_HERE.md` both
describe as a **pristine placeholder starter** — a directory whose whole purpose is to be empty and to
fail Gate 1 until a user fills it in. One directory cannot be both the empty starter and a finished
295-record run, and while it was both, neither claim about it could be trusted. The starter has been
restored to its documented placeholder state; this snapshot moved here intact.

## Known internal contradictions — do not "fix" them, they are what the run produced

The point of keeping this is to show what an unfinalised run looks like. Every item below was true at
the moment it was frozen and is left exactly as it was:

| Where | Says | Actually |
|---|---|---|
| `handoff/FUNCTIONAL_CONTRACT.md` header | "shared 21-key record shape" | the shape has since changed, and the file is stored in the **legacy fenced** form, not the current table |
| same header | "Scope: `demographics` only … the other five domains are extracted, scanned and covered but not yet drafted" | **295 records across all six domains** — demographics 18, study_period 12, study_population 4, clinical 146, treatment 81, outcomes 34 |
| `handoff/MATURITY.yaml` | "295 mapped + 47 dispositions + 18 context, 0 undispositioned" | `spec_pipeline/out/COVERAGE.md` reports **360 items — UNDISPOSITIONED 342 · context 18**. (The same note's "all 15 invariants" is CORRECT and was wrongly listed here: 17 ids are enumerated, I7 is RETIRED and I9 is FOLDED INTO I13, so 15 fire.) |
| `spec_pipeline/out/SCAFFOLDED_RECORDS.md` | 342 fenced ```yaml blocks, "the rules, all 15 of them" | generated before the scaffold moved to table rows — stale relative to today's tooling |
| `handoff/tests/test_functional_contract.py` | `FLOORS = {"decisions": 0, "gaps": 0, "records": 1}` | the contract holds 295 records and the register holds many decisions, so the floor would accept almost total parser loss |
| `source_refs.yaml` | `product: demo`, `status: pending` | points at the ovarian 202606 workbook |
| `spec_pipeline/pipeline.conf` | `TUMOR="ovarian"` | still carries the starter's `# <- replace, including the angle brackets` comment |
| `source_refs.yaml` | `path_or_link: sandbox/new_tumour_start/reference/…/PROG_SPEC_RWDP_Ovarian_PANO_202606.xlsx` | the workbook moved here with the rest of the run, so that path no longer resolves. Left as-is: rewriting it would suggest the snapshot is re-runnable, and it is not |

These are **assembly failures, not drafting failures**: individually plausible records were produced,
and the header, scope, counts, coverage, generated artifacts and maturity claim were never brought
back into agreement with them. That is the single most useful thing this snapshot demonstrates, and
editing it away would delete the finding.

## If you want to re-run the experiment

Copy `sandbox/new_tumour_start` to a fresh directory — do not draft into the starter itself.
