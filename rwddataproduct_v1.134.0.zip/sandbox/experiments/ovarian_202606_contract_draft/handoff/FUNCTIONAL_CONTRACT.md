# RWP → RWDE functional contract — ovarian PANO 202606 (new_tumour_start sandbox)

Drafted from `PROG_SPEC_RWDP_Ovarian_PANO_202606.xlsx` via the deterministic extraction in
`spec_pipeline/out/`, using the shared 21-key record shape and `platform/tools/contract_lint.py`.

**Scope: `demographics` only (the `5.Demographics` tab, spec rows 6–23).** The other five domains are
extracted, scanned and covered but not yet drafted. `spec_digest` on each record is the value the
scaffold computed from the cited row's text; I15 re-checks it against `spec_pipeline/out/extracted.json`.

**Two standing caveats for every record below.**

1. **The source is not yet approved.** `../source_refs.yaml` records the workbook as `status: pending`
   (`ai_classification: sponsor_ai_eligible`, so it is AI-drafting-eligible). No record here may reach
   `requirement: approved` until Gate 1 marks the material `reviewed`. Everything is drafted at
   `requirement: draft` or `decision_required`, `source: unverified`, `validation: not_run`.
2. **No `config/` exists yet.** The `source.inputs` keys — `demographics`, `practice`, `sdoh`,
   `insurance` — are the logical sources the spec's `Source` column names (`Demographics.*`,
   `Practice.PracticeType`, `SocialDeterminantsOfHealth.SESIndex2015_2019`, `Insurance table`). They
   are **proposed**: this pack has no `config/data_product.yaml` `sources:` block to bind them to, so
   the config keys and the physical table names must be authored at Gate 4, and Gate 3's
   `source_check` will be the first thing to prove the mapping. They cannot be carried as `gap_ids`
   yet because this pack has no `ENGINE_GAPS.md` (the lint's gap index) — that file arrives with the
   build. Likewise, value sets named in `derivation` (state→region map, age bands, RACE/ETHN/payer
   code lists, the nine payer flags) are summarised here and belong in `variables/`/`codelists/` once
   those exist — they are not inlined, per the repo's summarise-in-contract / enumerate-in-YAML rule.

Row numbers are the original Excel rows on the `5.Demographics` tab, read directly from the extraction
(I8 checkable — each `demographics:<row>` resolves in `extracted.json`).

## Records

#### AGE

```yaml
variable_id: AGE
spec_refs: [demographics:6]
spec_digest: 6398e2228221
required_rule: AGE = year(INDEXDT) − birthyear, computed at index. Approximate — only birth YEAR is delivered.
source: {kind: vendor, inputs: {demographics: {birth_year: birthyear}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "year(index_date) - cast(birthyear as int)"
cohort_applicability: all cohorts (index date varies per cohort)
missing: {no_record: n/a, present_null: "birthyear null → AGE null"}
units: years
depends_on: [INDEX]
output: {physical_name: age, target_published_name: AGE, name_status: undecided, type: integer, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "index_date=2020-06-01, birthyear=1955 → AGE=65"
notes: "Year-only DOB, so AGE is approximate (±1yr) — flag in the dictionary. Source col names Demographics.BirthYear. The band child AGEGR1/AGEGR1N are separate records."
```

#### AGEGR1

```yaml
variable_id: AGEGR1
spec_refs: [demographics:7]
spec_digest: e4bec50f6831
required_rule: Categorical age band of AGE at index — 0-18, 19-34, 35-49, 50-64, 65-74, 75-84, >=85. The spec lists no "Unknown" band.
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "band AGE into 0-18 | 19-34 | 35-49 | 50-64 | 65-74 | 75-84 | >=85 (full per-band bounds to variables/codelists). Behaviour for null AGE is undefined — no Unknown band is listed (BLOCKED: AGEBAND-MISSING)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "AGE null → band undefined; the spec provides no Unknown band (BLOCKED: AGEBAND-MISSING)"}
units: n/a
depends_on: [AGE]
output: {physical_name: agegr1, target_published_name: AGEGR1, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [AGEBAND-MISSING]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "AGE=72 → AGEGR1='65-74'"
notes: "Spec registered full logic for the first band only; the value list gives all seven boundaries. Ovarian population is age>=18 (POP_FILTER_age_ge_18), so '0-18' should be near-empty."
```

#### AGEGR1N

```yaml
variable_id: AGEGR1N
spec_refs: [demographics:8]
spec_digest: e4be5cf05e84
required_rule: Numeric code for AGEGR1 — 1=0-18, 2=19-34, 3=35-49, 4=50-64, 5=65-74, 6=75-84, 7=>=85.
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of AGEGR1: 1..7 as listed. Code for a null AGE is undefined — no Unknown code is listed (BLOCKED: AGEBAND-MISSING)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "AGE null → code undefined; no Unknown code listed (BLOCKED: AGEBAND-MISSING)"}
units: n/a
depends_on: [AGEGR1]
output: {physical_name: agegr1n, target_published_name: AGEGR1N, name_status: undecided, type: integer, nullable: true, codes: "1=0-18;2=19-34;3=35-49;4=50-64;5=65-74;6=75-84;7=>=85", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [AGEBAND-MISSING]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "AGEGR1='65-74' → AGEGR1N=5"
notes: "Numeric counterpart of AGEGR1, on its own row per the tab's convention."
```

#### REGION1

```yaml
variable_id: REGION1
spec_refs: [demographics:9]
spec_digest: 50fc4de007e0
required_rule: US Census region of residence (character) — Northeast, Midwest, South, West, "Other region", Missing — mapped from the patient's STATE.
source: {kind: vendor, inputs: {demographics: {state: STATE}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "character label of REGION1N: Northeast | Midwest | South | West | 'Other region' (PR) | Missing (STATE null). Full STATE→region map to variables/codelists. 'Academic centers set to unknown' — the identification of an academic-center patient and whether it forces Missing is BLOCKED (REGION-ACADEMIC); an unmatched non-missing STATE is BLOCKED (REGION-UNMATCHED)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "STATE null → 'Missing'. Academic-center patients set to unknown (BLOCKED: REGION-ACADEMIC)"}
units: n/a
depends_on: [REGION1N]
output: {physical_name: region1, target_published_name: REGION1, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [REGION-ACADEMIC, REGION-UNMATCHED]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "STATE='NY' → REGION1='Northeast'; STATE null → REGION1='Missing'"
notes: "REGION1's state arrays are truncated in the source and were reconstructed from REGION1N (SQ-REGION-TRUNC). The token 'Implementation' is a spurious non-state entry in the South list (SQ-REGION-IMPL). STATE read from the t_&cohort_demographics_&date table."
```

#### REGION1N

```yaml
variable_id: REGION1N
spec_refs: [demographics:10]
spec_digest: 62b92fd28e25
required_rule: Ordinal code of REGION1 — 1=Northeast, 2=Midwest, 3=South, 4=West, 5="Other region" (PR), 6=Missing — by STATE membership in the census-region sets.
source: {kind: vendor, inputs: {demographics: {state: STATE}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "STATE→region ordinal: NE set→1, MW set→2, South set→3, West set→4, PR→5, STATE missing→6 (full sets to variables/codelists). Chain has no terminal else: a present STATE in none of the sets is undefined (BLOCKED: REGION-UNMATCHED). Academic-center override BLOCKED (REGION-ACADEMIC)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "STATE null → 6 (Missing)"}
units: n/a
depends_on: []
output: {physical_name: region1n, target_published_name: REGION1N, name_status: undecided, type: integer, nullable: true, codes: "1=Northeast;2=Midwest;3=South;4=West;5=Other region;6=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [REGION-ACADEMIC, REGION-UNMATCHED]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "STATE='TX' → REGION1N=3; STATE='PR' → REGION1N=5; STATE null → REGION1N=6"
notes: "The South set carries a stray 'Implementation' token (SQ-REGION-IMPL). REGION1 is the character label of this variable."
```

#### RACE

```yaml
variable_id: RACE
spec_refs: [demographics:11]
spec_digest: 76e174be29aa
required_rule: Race — Asian, "Black or African American", "White", "Other Race", Unknown/Missing — using delivered RACE as-is, recoding "Hispanic or Latino" into "Other Race".
source: {kind: vendor, inputs: {demographics: {race: RACE}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "delivered RACE as-is; recode 'Hispanic or Latino' → 'Other Race'; categories {Asian, Black or African American, White, Other Race, Unknown/Missing}. Whether 'Asian' is a reported category or folded into 'Other Race' is contradicted within the row and BLOCKED (RACE-ASIAN)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "delivered RACE null → 'Unknown/Missing'"}
units: n/a
depends_on: []
output: {physical_name: race, target_published_name: RACE, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [RACE-ASIAN]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "delivered RACE='Hispanic or Latino' → RACE='Other Race'; delivered RACE='White' → RACE='White'"
notes: "Read from the t_&cohort_demographics_&date table. The row says a separate character variable isn't needed since RACE is delivered. Small-cell grouping ('like Asian/Hispanic') conflicts with Asian being a listed value — SQ-RACE-ASIAN."
```

#### RACEN

```yaml
variable_id: RACEN
spec_refs: [demographics:12]
spec_digest: cbd5052c45a7
required_rule: Numeric code of RACE (1–5).
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of RACE, 1..5 (code list to variables/codelists once the category set is settled). Same small-cell/Asian grouping question as RACE (RACE-ASIAN)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "RACE 'Unknown/Missing' → its corresponding code"}
units: n/a
depends_on: [RACE]
output: {physical_name: racen, target_published_name: RACEN, name_status: undecided, type: integer, nullable: true, codes: "1..5 (assignment pending RACE-ASIAN)", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [RACE-ASIAN]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until the RACE category set is settled (RACE-ASIAN); e.g. RACE='White' → RACEN=<code for White>"
notes: "The spec gives the 1–5 range but not the per-category assignment; it depends on whether Asian is a distinct category (RACE-ASIAN)."
```

#### ETH

```yaml
variable_id: ETH
spec_refs: [demographics:13]
spec_digest: ecd8249c40d8
required_rule: Ethnicity — "Not Hispanic or Latino", "Hispanic or Latino", Unknown/Missing — from ETHNICITY, with RACE="Hispanic..." also mapping to Hispanic.
source: {kind: vendor, inputs: {demographics: {ethnicity: ETHNICITY, race: RACE}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "if RACE='Hispanic or Latino' or ETHNICITY='Hispanic or Latino' → 'Hispanic or Latino'; else if ETHNICITY='Not Hispanic or Latino' → 'Not Hispanic or Latino'; else if ETHNICITY missing → 'Unknown/Missing'. NOTE: further conditional lines are clipped in the source (SQ-ETH-CLIP) — confirm the full chain on re-extraction."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "ETHNICITY missing (and RACE not Hispanic) → 'Unknown/Missing'"}
units: n/a
depends_on: []
output: {physical_name: eth, target_published_name: ETH, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "ETHNICITY='Hispanic or Latino' → ETH='Hispanic or Latino'; ETHNICITY='Not Hispanic or Latino', RACE='White' → ETH='Not Hispanic or Latino'"
notes: "Drafted from the legible branches; SQ-ETH-CLIP records that the source clipped some conditions — a delivery-format defect that resolves by re-extraction, not an RWB question, so this stays draft rather than decision_required. Read from the t_&cohort_demographics_&date table."
```

#### ETHN

```yaml
variable_id: ETHN
spec_refs: [demographics:14]
spec_digest: 4a22a5ce6be7
required_rule: Numeric code of ETH. The spec does not state the code values.
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of ETH; the code list is NOT stated in the spec (the Values cell holds a label, SQ-ETHN-VALUES) and is BLOCKED (ETHN-CODES)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "ETH 'Unknown/Missing' → its corresponding code (pending ETHN-CODES)"}
units: n/a
depends_on: [ETH]
output: {physical_name: ethn, target_published_name: ETHN, name_status: undecided, type: integer, nullable: true, codes: "unspecified (BLOCKED: ETHN-CODES)", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [ETHN-CODES]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be written — ETHN's numeric codes are unspecified (ETHN-CODES)"
notes: "The ETHN 'Values' cell reads 'Race/Ethnicity (N)', a column label rather than a code list — recorded as SQ-ETHN-VALUES. Probable intent is 1=Not Hispanic, 2=Hispanic, 3=Unknown, but that is not stated, so it is not asserted here."
```

#### PRACTIC

```yaml
variable_id: PRACTIC
spec_refs: [demographics:15]
spec_digest: 63fb8a877b1d
required_rule: Practice type (character) — "Academic only", "Community only", "Both academic and community" — the label of PRACTICN. Time period FU.
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: FU
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "character label of PRACTICN (1→'Academic only', 2→'Community only', 3→'Both academic and community'). The label for a patient with no classifiable practice record is undefined (BLOCKED: PRACTIC-MISSING)."
cohort_applicability: all cohorts
missing: {no_record: "patient with no ACADEMIC/COMMUNITY practice record → undefined (BLOCKED: PRACTIC-MISSING)", present_null: n/a}
units: n/a
depends_on: [PRACTICN]
output: {physical_name: practic, target_published_name: PRACTIC, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [PRACTIC-MISSING]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "PRACTICN=3 → PRACTIC='Both academic and community'"
notes: "The definition cell is blank in the source; labels are taken from the PRACTICN value list. Character of the numeric PRACTICN."
```

#### PRACTICN

```yaml
variable_id: PRACTICN
spec_refs: [demographics:16]
spec_digest: 759533754009
required_rule: Practice type (numeric) — 1=Academic only, 2=Community only, 3=Both — a patient-level rollup across the patient's PracticeType records. Time period FU.
source: {kind: vendor, inputs: {practice: {practice_type: PracticeType}}}
grain: [patientid, cohortn]
anchor: n/a
window: FU
record_selection: "patient-level rollup across ALL of the patient's practice records"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "any record PracticeType='ACADEMIC' and no record 'COMMUNITY' → 1; any 'COMMUNITY' and no 'ACADEMIC' → 2; both present → 3. No terminal else: a patient with no ACADEMIC/COMMUNITY record is undefined (BLOCKED: PRACTIC-MISSING)."
cohort_applicability: all cohorts
missing: {no_record: "no classifiable practice record → undefined (BLOCKED: PRACTIC-MISSING)", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: practicn, target_published_name: PRACTICN, name_status: undecided, type: integer, nullable: true, codes: "1=Academic only;2=Community only;3=Both academic and community", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [PRACTIC-MISSING]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "patient with only 'ACADEMIC' records → PRACTICN=1; patient with both → PRACTICN=3"
notes: "Definition rows are clipped across the source split and the block begins unlabeled (SQ-PRACTICN-CLIP). Rollup is over all records, so the grain is the patient, not a single visit."
```

#### SES

```yaml
variable_id: SES
spec_refs: [demographics:17]
spec_digest: 3546aabcdd52
required_rule: Socioeconomic-status index (1=lowest … 5=highest, Missing), taken at the patient's most/last visit date. Time period STUDY_PD.
source: {kind: vendor, inputs: {sdoh: {ses_index: SESIndex2015_2019}}}
grain: [patientid, cohortn]
anchor: last visit date
window: STUDY_PD
record_selection: "the SES value recorded at the patient's latest visit date (BLOCKED: SES-TIEBREAK)"
tie_break: {equidistant: n/a, same_day: "more than one SES value on the same last visit date — resolution BLOCKED (SES-TIEBREAK)"}
derivation: "take SESIndex2015_2019 from the SDOH table, merged to patient level, at the patient's last visit date; codes 1(lowest)..5(highest), else Missing."
cohort_applicability: all cohorts
missing: {no_record: "no SDOH record → 'Missing'", present_null: "SES null at last visit → 'Missing'"}
units: n/a
depends_on: []
output: {physical_name: ses, target_published_name: SES, name_status: undecided, type: integer, nullable: true, codes: "1=lowest;2;3;4;5=highest;Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [SES-TIEBREAK]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "SESIndex2015_2019=1 at the last visit → SES=1 (lowest)"
notes: "Source is t_meg_socdetohealth_&date / SocialDeterminantsOfHealth.SESIndex2015_2019 (a fixed 2015–2019 index). The last-visit date column is not named in the spec, so no date column is proposed under source.inputs; the selection rule is carried in record_selection and blocked on SES-TIEBREAK."
```

#### GENDER

```yaml
variable_id: GENDER
spec_refs: [demographics:18]
spec_digest: 6ed6c6ae1886
required_rule: Gender — Female, Male, Unknown — as defined in the raw dataset (Panoramic BirthSex). Time period STUDY_PD.
source: {kind: vendor, inputs: {demographics: {birth_sex: BirthSex}}}
grain: [patientid, cohortn]
anchor: n/a
window: STUDY_PD
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "map delivered BirthSex: F→'Female', M→'Male'; missing/other → 'Unknown'."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "BirthSex null → 'Unknown'"}
units: n/a
depends_on: [birthsex]
output: {physical_name: gender, target_published_name: GENDER, name_status: undecided, type: string, nullable: false, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "BirthSex='F' → GENDER='Female'; BirthSex missing → GENDER='Unknown'"
notes: "The banner states gender = Panoramic BirthSex, whose value set is {F,M} (see birthsex, row 20); 'Unknown' therefore arises only from a missing/other value. Drafted straight because the mapping is unambiguous."
```

#### GenderN

```yaml
variable_id: GenderN
spec_refs: [demographics:19]
spec_digest: 01fed2c34180
required_rule: Numeric code for Gender — 1=Female, 2=Male, 3=Unknown.
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: STUDY_PD
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of GENDER: 1=Female, 2=Male, 3=Unknown."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "GENDER='Unknown' → 3"}
units: n/a
depends_on: [GENDER]
output: {physical_name: gendern, target_published_name: GenderN, name_status: undecided, type: integer, nullable: false, codes: "1=Female;2=Male;3=Unknown", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "GENDER='Male' → GenderN=2"
notes: "Source fragment shows a duplicated '2-Male' / '2 Male (No records)' and a [verify] marker (SQ-GENDERN-DUP) — treated as a stand-in doubling; the 1/2/3 code list itself is legible, so this is drafted rather than blocked. Confirm on re-extraction."
```

#### birthsex

```yaml
variable_id: birthsex
spec_refs: [demographics:20]
spec_digest: e742f0225b31
required_rule: Raw Panoramic BirthSex value {F, M} carried into the analytic dataset; drives GENDER/GenderN.
source: {kind: vendor, inputs: {demographics: {birth_sex: BirthSex}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry BirthSex ({F,M}) through to the analytic dataset unchanged; it is the source for GENDER and GenderN."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "BirthSex null → carried null (surfaces as GENDER='Unknown')"}
units: n/a
depends_on: []
output: {physical_name: birthsex, target_published_name: n/a, name_status: undecided, type: string, nullable: true, codes: "F;M", role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: excluded, dictionary: excluded, dashboard: excluded, tfl: excluded}
acceptance: "delivered BirthSex='F' is retained as birthsex='F' and yields GENDER='Female'"
notes: "A source/keep passthrough, not a published output — role internal. Its keep-list membership (from t_&cohort_enh_ov_&date, under PRE_INT) carries a [verify] marker in the source; noted, not blocking, as it concerns dataset assembly rather than this variable's definition."
```

#### PayerCategory

```yaml
variable_id: PayerCategory
spec_refs: [demographics:21]
spec_digest: b97ca7ed8c1d
required_rule: Latest recorded, normalized payer category for the patient — Medicaid, Medicare, Commercial, Workers Comp, Other Govt, Patient Assistance, Self Pay, Other-Unknown. (ADDITIVE Panoramic field.)
source: {kind: vendor, inputs: {insurance: {payer_category: PayerCategory}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the latest recorded payer category (BLOCKED: PAYER-LATEST — latest by which date)"
tie_break: {equidistant: n/a, same_day: "two payer categories tied on the governing date — resolution BLOCKED (PAYER-LATEST)"}
derivation: "take the patient's latest recorded normalized payer category; categories {Medicaid, Medicare, Commercial, Workers Comp, Other Govt, Patient Assistance, Self Pay, Other-Unknown} (enumerate in variables/codelists). 'Latest' by which date, the tie-break, and the no-record case are BLOCKED (PAYER-LATEST)."
cohort_applicability: all cohorts
missing: {no_record: "no insurance record → handling unstated (BLOCKED: PAYER-LATEST)", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: payer_category, target_published_name: PayerCategory, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [PAYER-LATEST]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until 'latest' is defined (PAYER-LATEST); e.g. a patient whose most recent plan is Commercial → PayerCategory='Commercial'"
notes: "ADDITIVE Panoramic insurance field (not in the prior EDM spec). Source is the Insurance table; the specific normalized column and the date used for 'latest' are not named in the spec."
```

#### INS_PLAN_DATES

```yaml
variable_id: INS_PLAN_DATES
spec_refs: [demographics:22]
spec_digest: a99dd963c185
required_rule: StartDate / EndDate of each insurance plan; a patient may have more than one plan. (ADDITIVE Panoramic field.)
source: {kind: vendor, inputs: {insurance: {plan_start: StartDate, plan_end: EndDate}}}
grain: [patientid, plan]
anchor: n/a
window: n/a
record_selection: "all plans retained (one row per plan)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry StartDate and EndDate of each insurance plan; grain is one row per patient per plan."
cohort_applicability: all cohorts
missing: {no_record: "patient with no plan → no plan-date rows", present_null: "open plan → EndDate null"}
units: date
depends_on: []
output: {physical_name: "ins_plan_startdate ins_plan_enddate", target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "a patient with two plans yields two (StartDate, EndDate) rows"
notes: "ADDITIVE Panoramic field at a per-plan grain, not per-patient — a supporting building block for coverage/payer logic. Role internal and publish undecided: the spec does not state whether these dates are themselves published."
```

#### INS_PAYER_FLAGS

```yaml
variable_id: INS_PAYER_FLAGS
spec_refs: [demographics:23]
spec_digest: 85cf258fab39
required_rule: Nine payer-detail flags, each Yes / No-Unknown — IsMedicareAdv, IsMedicareSupp, IsPartAOnly, IsPartBOnly, IsPartAandPartB, IsPartDOnly, IsManagedGovtPlan, IsManagedMedicaid, IsMedicareMedicaid. (ADDITIVE Panoramic field.)
source: {kind: vendor, inputs: {insurance: {is_medicare_adv: IsMedicareAdv, is_medicare_supp: IsMedicareSupp, is_part_a_only: IsPartAOnly, is_part_b_only: IsPartBOnly, is_part_a_and_part_b: IsPartAandPartB, is_part_d_only: IsPartDOnly, is_managed_govt_plan: IsManagedGovtPlan, is_managed_medicaid: IsManagedMedicaid, is_medicare_medicaid: IsMedicareMedicaid}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "nine Boolean payer-detail flags (Yes / No-Unknown) carried per patient; enumerate the nine flag names in variables/codelists."
cohort_applicability: all cohorts
missing: {no_record: "no insurance record → each flag 'No-Unknown'", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: "ins_payer_flags (9 columns)", target_published_name: n/a, name_status: undecided, type: string, nullable: true, codes: "each: Yes | No-Unknown", role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "a Medicare-Advantage patient → IsMedicareAdv='Yes'; a patient with no insurance record → all nine flags 'No-Unknown'"
notes: "ADDITIVE Panoramic field: nine flags on one spec row, kept together as one family record with the values enumerated in YAML (one record per spec row, per I16). Role internal and publish undecided — the spec does not state whether the flags are published."
```

## study_period — SP

#### DATAV

```yaml
variable_id: DATAV
spec_refs: [study_period:6]
spec_digest: 0ed20e2ff495
required_rule: "Data Version of the delivered feed = 2026m03 (the latest in-house version carrying progression)."
source: {kind: constant}
grain: [dataset]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "constant string '2026m03' stamped as the data version (latest in-house version carrying progression)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: datav, target_published_name: n/a, name_status: undecided, type: string, nullable: false, codes: n/a, role: metadata}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "the delivered feed is the 2026m03 in-house version -> DATAV='2026m03'"
notes: "Dataset-level metadata (Data Version), not a per-patient variable -> role metadata. Value read from the definition cell; 'latest in-house version with progression' is qualifying context."
```

#### RAWRWD

```yaml
variable_id: RAWRWD
spec_refs: [study_period:7]
spec_digest: dd59bd649ecb
required_rule: "RWD Data Source of the feed = Flatiron Health, Ovarian Cancer EDM population subset, version 2026m03; progression is available only for EDM patients. (Values cell is masked in the source.)"
source: {kind: constant}
grain: [dataset]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "constant: RWD source = Flatiron Health (Ovarian Cancer EDM subset), version 2026m03. The Values cell is masked in the stand-in (SP-RAWRWD-MASKED); the source is recovered from the Section A context."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: rawrwd, target_published_name: n/a, name_status: undecided, type: string, nullable: false, codes: n/a, role: metadata}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "feed = Flatiron Health Ovarian Cancer EDM, 2026m03 -> RAWRWD names that source"
notes: "Dataset-level metadata -> role metadata. The Values cell is redacted in the stand-in; recovered from Section A (Flatiron Health / Ovarian Cancer EDM / 2026m03) and recorded as format finding SP-RAWRWD-MASKED (resolves on re-extraction)."
```

#### MININDEX

```yaml
variable_id: MININDEX
spec_refs: [study_period:8]
spec_digest: 71d9ae2f144e
required_rule: "Minimum potential index date within a cohort = 01-Jan-2011 - a cohort-level constant (same date for every patient in the cohort), marking the start of data recording."
source: {kind: constant}
grain: [cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "constant cohort-level date 2011-01-01 (start of data recording); identical for all patients within a cohort."
cohort_applicability: "all cohorts (constant within a cohort)"
missing: {no_record: n/a, present_null: n/a}
units: date
depends_on: []
output: {physical_name: minindex, target_published_name: n/a, name_status: undecided, type: date, nullable: false, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "MININDEX = 2011-01-01 for every patient in the cohort"
notes: "Cohort-level constant, not per-patient (spec is explicit). Lower bound of the patient-selection period ID_PD."
```

#### MAXINDEX

```yaml
variable_id: MAXINDEX
spec_refs: [study_period:9]
spec_digest: 0d5ae5754690
required_rule: "Maximum potential index date within a cohort = 28-Feb-2026 - a cohort-level constant (same date for every patient in the cohort); also the study_end date bounding STUDY_PD."
source: {kind: constant}
grain: [cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "constant cohort-level date 2026-02-28; identical for all patients within a cohort; serves as study_end (upper bound of STUDY_PD and ID_PD)."
cohort_applicability: "all cohorts (constant within a cohort)"
missing: {no_record: n/a, present_null: n/a}
units: date
depends_on: []
output: {physical_name: maxindex, target_published_name: n/a, name_status: undecided, type: date, nullable: false, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "MAXINDEX = 2026-02-28 for every patient in the cohort"
notes: "Cohort-level constant. Upper bound of ID_PD and STUDY_PD; consistent with the 2026m03 data version (DATAV)."
```

#### STUDY_PD

```yaml
variable_id: STUDY_PD
spec_refs: [study_period:10]
spec_digest: 05d41377b417
required_rule: "Full study period = earliest available data (accounting for full patient clinical history) through the study_end date (MAXINDEX)."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: "[earliest available data, MAXINDEX]"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "lower bound = patient's earliest available data (full clinical history); upper bound = MAXINDEX (2026-02-28)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: n/a}
units: date
depends_on: [MAXINDEX, MINAVAILDATE]
output: {physical_name: "study_pd_start study_pd_end", target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "patient earliest data 2015-03-01, MAXINDEX 2026-02-28 -> STUDY_PD = [2015-03-01, 2026-02-28]"
notes: "Window building block. The lower bound is the patient's earliest available data; how earliest-available date is computed is the open MINAVAILDATE field question (SP-MINAVAILDATE-FIELD), but STUDY_PD's own rule is stated, so it is drafted."
```

#### ID_PD

```yaml
variable_id: ID_PD
spec_refs: [study_period:11]
spec_digest: 20d980a9763a
required_rule: "Patient selection period = 01-Jan-2011 through 28-Feb-2026 - the window over which patients are selected, bounded by MININDEX and MAXINDEX."
source: {kind: derived}
grain: [cohortn]
anchor: n/a
window: "[MININDEX (2011-01-01), MAXINDEX (2026-02-28)]"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "patient-selection window = MININDEX (2011-01-01) through MAXINDEX (2026-02-28), inclusive."
cohort_applicability: "all cohorts (constant within a cohort)"
missing: {no_record: n/a, present_null: n/a}
units: date
depends_on: [MININDEX, MAXINDEX]
output: {physical_name: "id_pd_start id_pd_end", target_published_name: n/a, name_status: undecided, type: date, nullable: false, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "ID_PD = [2011-01-01, 2026-02-28]"
notes: "The scope refers to this period as 'IO_PD' while the stand-in records 'ID_PD' - a naming inconsistency recorded as format finding SP-IDPD-NAME; both denote the same 2011-01-01..2026-02-28 window. Drafted (a stand-in-format issue, not an RWB question)."
```

#### INDEX

```yaml
variable_id: INDEX
spec_refs: [study_period:12]
spec_digest: dc528939fdf3
required_rule: "Index date, defined per cohort - Overall OC: initial diagnosis; 1L/1LM/2L/2LM/3L/4L/5L treated: the respective line start; 2L+ PROC: the start of the FIRST platinum-resistant line. One index date per patient per cohort."
source: {kind: vendor, inputs: {oc_clinical: {diagnosis_date: DiagnosisDate}, lot: {line_start: StartDate}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "single per-patient index; the anchor column is selected by COHORT (defined in study_population). 2L+ PROC anchors on the StartDate of the first line with PLAT_SEN_v1='Resistant' (may fall at 2L/3L/4L/5L)."
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "Overall OC -> Enhanced_OvarianCancer.DiagnosisDate; line cohorts (1L,1LM,2L,2LM,3L,4L,5L) -> LineOfTherapy.StartDate of that line; 2L+ PROC -> StartDate of the FIRST platinum-resistant line (PLAT_SEN_v1='Resistant'). COHORT assignment is defined in study_population."
cohort_applicability: "all cohorts; the anchor differs per cohort (see derivation)"
missing: {no_record: "patient with no qualifying anchor event for the cohort -> no index (excluded from that cohort)", present_null: n/a}
units: date
depends_on: [COHORT, PLAT_SEN_v1]
output: {physical_name: index, target_published_name: n/a, name_status: undecided, type: date, nullable: false, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "a 1L treated OC patient with LineOfTherapy.StartDate 2020-06-01 for line 1 -> INDEX=2020-06-01; a 2L+ PROC patient whose first platinum-resistant line is 3L starting 2021-09-15 -> INDEX=2021-09-15"
notes: "The per-cohort anchor is fully specified in the spec, so drafted (no anchor invented). COHORT (study_population) and PLAT_SEN_v1 (outcomes) are defined in other tabs; the 2L+ PROC cohort contributes one index per patient at first platinum resistance, so its follow-up/baseline anchor varies across patients."
```

#### FU

```yaml
variable_id: FU
spec_refs: [study_period:13]
spec_digest: 0c60d563e2c6
required_rule: "Follow-up period = INDEX+1 (day after index) through the end of data availability. The end-of-follow-up rule (death / last structured activity / etc.) is NOT yet defined."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: index_date
window: "[INDEX+1, end of data availability (BLOCKED: SP-FU-END)]"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "start = INDEX + 1 day; end = end of data availability, to be defined via death, last structured activity, etc. - the exact end-of-follow-up rule is undefined (BLOCKED: SP-FU-END)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "end of follow-up undefined until SP-FU-END is answered"}
units: date
depends_on: [INDEX]
output: {physical_name: "fu_start fu_end", target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [SP-FU-END]
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "start = INDEX+1 (e.g. INDEX=2020-06-01 -> FU start 2020-06-02); the end cannot be fixed until end-of-follow-up is defined (SP-FU-END)"
notes: "The start is stated (INDEX+1); the end-of-follow-up definition is explicitly left open in the spec ('need to define end of follow-up utilizing death, last structured activity, etc.') - raised as SP-FU-END."
```

#### PRE_INT

```yaml
variable_id: PRE_INT
spec_refs: [study_period:14]
spec_digest: e9b2c781e39a
required_rule: "Any time prior to index date, including index date = earliest available data through INDEX, inclusive of index date."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: index_date
window: "[earliest available data, INDEX] inclusive"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "lower bound = patient's earliest available data; upper bound = INDEX, inclusive of the index date."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: n/a}
units: date
depends_on: [INDEX]
output: {physical_name: "pre_int_start pre_int_end", target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "earliest data 2015-03-01, INDEX 2020-06-01 -> PRE_INT = [2015-03-01, 2020-06-01]"
notes: "Look-back window (any time on/before index). The lower bound is the patient's earliest available data (see MINAVAILDATE / SP-MINAVAILDATE-FIELD); PRE_INT's own rule is stated, so it is drafted."
```

#### PRE_BIO

```yaml
variable_id: PRE_BIO
spec_refs: [study_period:15]
spec_digest: fa6d14e72bf2
required_rule: "Biomarker assessment period = any time prior to index date (index date minus infinity) through index date + 14 days."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: index_date
window: "[index date minus infinity (any time prior), index date + 14 days]"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "lower bound = unbounded before index (any time prior); upper bound = INDEX + 14 days."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: n/a}
units: date
depends_on: [INDEX]
output: {physical_name: "pre_bio_start pre_bio_end", target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "INDEX=2020-06-01 -> PRE_BIO upper bound = 2020-06-15; lower bound unbounded"
notes: "Biomarker-status assessment window used by the biomarker variables (clinical). Lower bound is 'any time prior' (unbounded). The biomarker test-date rule that decides which tests fall in this window is dispositioned (BIO_DATE_RULE) and carries the SP-BIO-DATE-CONFLICT finding."
```

#### LOT_ECOG

```yaml
variable_id: LOT_ECOG
spec_refs: [study_period:16]
spec_digest: 144cc55d9e2d
required_rule: "ECOG assessment period = INDEX - 30 days through INDEX + 7 days."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: index_date
window: "[INDEX - 30 days, INDEX + 7 days]"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "lower bound = INDEX - 30 days; upper bound = INDEX + 7 days."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: n/a}
units: date
depends_on: [INDEX]
output: {physical_name: "lot_ecog_start lot_ecog_end", target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "INDEX=2020-06-01 -> LOT_ECOG = [2020-05-02, 2020-06-08]"
notes: "ECOG selection window used by the ECOG variables (clinical). The bracket notation in the source is literal bounds, not an unresolved placeholder. Which ECOG source table supplies values within this window is the open SP-ECOG-SOURCE question."
```

#### ECOG_SOURCE_DECISION

```yaml
variable_id: ECOG_SOURCE_DECISION
spec_refs: [study_period:24]
spec_digest: a0f1183f4919
required_rule: "Which ECOG source table(s) supply ECOG values, per cohort. The spec's guidance is internally inconsistent: treated cohorts (1L,2L,3L,...) should use the baseline ECOG table only, diagnosed/untreated cohorts should combine both tables, yet the stated Action is 'use both ECOG tables'."
source: {kind: vendor, inputs: {ecog: {ecog_value: EcogValue, ecog_date: EcogDate}, baseline_ecog: {ecog_value: ECOGValue, ecog_date: ECOGDate}}}
grain: [patientid, cohortn]
anchor: n/a
window: LOT_ECOG
record_selection: "ECOG source table selected by cohort - treated (1L,2L,3L,...): BaselineECOG only; diagnosed/untreated: the spec offers combine-both vs ECOG-only and then states 'use both', which conflicts with the treated-cohort recommendation (BLOCKED: SP-ECOG-SOURCE)."
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "select ECOG values from the ECOG and/or BaselineECOG tables depending on cohort; the exact per-cohort source selection is contradictory in the spec and BLOCKED (SP-ECOG-SOURCE)."
cohort_applicability: "all cohorts; source table differs by cohort (BLOCKED)"
missing: {no_record: "no ECOG record in the chosen source -> ECOG Unknown (handled by the ECOG variable, clinical)", present_null: n/a}
units: n/a
depends_on: [LOT_ECOG]
output: {physical_name: ecog_source, target_published_name: n/a, name_status: undecided, type: string, nullable: true, codes: n/a, role: internal}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [SP-ECOG-SOURCE]
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "cannot be specified until the ECOG source selection is settled (SP-ECOG-SOURCE)"
notes: "Source-selection rule feeding the ECOG variables (clinical). The spec Action ('use both ECOG tables') conflicts with its recommendation that treated cohorts use baseline ECOG only - raised as SP-ECOG-SOURCE. BaselineECOG is already cleaned relative to treatment start and suppresses ECOG 5 to Unknown (see SRC_BASELINE_ECOG)."
```


## study_population — POP

#### COHORT

```yaml
variable_id: COHORT
spec_refs: [study_population:10]
spec_digest: 1ead761c83e9
required_rule: "Analysis cohort label, one output row per patient per cohort. Cohorts: Overall OC (index at Init/Diag); 1L/1LM/2L/2LM/3L/4L/5L treated OC (index at each line start); 2L+ PROC (index at First Platinum Resistance). A patient may appear in several cohort rows."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: "cohort-specific index date (Overall OC: Init/Diag; treated cohorts: the line start; 2L+ PROC: First Platinum Resistance)"
window: "ID_PD (index date within [MININDEX, MAXINDEX])"
record_selection: "one output row per patient per qualifying cohort; any within-cohort dedup/tie-break beyond one-row-per-patient-per-cohort is unstated (BLOCKED: POP-ROWSEL-TIEBREAK)"
tie_break: {equidistant: n/a, same_day: "within-cohort row selection/tie-break unstated (BLOCKED: POP-ROWSEL-TIEBREAK)"}
derivation: "emit COHORT per patient per qualifying cohort: 'Overall OC, Index at Init/Diag' if in EDM; '1L treated OC, Index at 1L Start' if has 1L; '1LM...' if has 1LM; '2L'/'2LM'/'3L'/'4L'/'5L' by the same pattern on each line start (explicit 2L-5L lines not separately spelled out in source — finding POP-COHORT-LINES-VERIFY); '2L+ PROC, Index at First Platinum Resistance' if COHORTN in (4,6,7,8) and PLAT_SEN='Platinum Resistant', derived after all other cohorts, cross-referenced to PLAT_SEN_v1/PFI in a prior spec and not stated here (BLOCKED: POP-PROC-PLATSEN). Which cohort SET is published (studypop 1-9 vs clinical 1-11) is unresolved (BLOCKED: POP-COHORTN-SET). Full cohort/code list to variables/codelists."
cohort_applicability: "defines the cohort axis itself"
missing: {no_record: "patient in no cohort → no cohort rows", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: cohort, target_published_name: COHORT, name_status: undecided, type: string, nullable: false, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [POP-COHORTN-SET, POP-PROC-PLATSEN, POP-ROWSEL-TIEBREAK]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "a patient in EDM treated with 1L yields >=2 rows: COHORT='Overall OC, Index at Init/Diag' and COHORT='1L treated OC, Index at 1L Start'"
notes: "Character label; COHORTN is the numeric code. Findings POP-COHORT-LINES-VERIFY (2L-5L lines not separately spelled out; [verify] marker) and POP-PLATSEN-TERM ('Platinum Resistant' literal vs PLAT_SEN_v1 emitting Refractory/Resistant/Sensitive) apply. Row-19 one-row-per-patient-per-cohort is realized by this record's per-cohort output-row conditions."
```

#### COHORTN

```yaml
variable_id: COHORTN
spec_refs: [study_population:11]
spec_digest: 504dde746afe
required_rule: "Numeric code of COHORT — 1=Overall OC, 2=1L, 3=1LM, 4=2L, 5=2LM, 6=3L, 7=4L, 8=5L, 9=2L+ PROC (study-population enumeration). The clinical section instead enumerates 1..11 (10=L1m+, 11=L2m+); which set is published is unresolved."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: "cohort-specific index date (as for COHORT)"
window: "ID_PD (index date within [MININDEX, MAXINDEX])"
record_selection: "one output row per patient per qualifying cohort (as for COHORT)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of COHORT: 1..9 as listed. The two spec sections define different cohort sets (studypop 1-9 vs clinical 1-11) — not a stand-in error — and which is published is BLOCKED (POP-COHORTN-SET). Code 9 (2L+ PROC) membership is BLOCKED (POP-PROC-PLATSEN). Full code list to variables/codelists."
cohort_applicability: "defines the cohort axis itself"
missing: {no_record: "patient in no cohort → no cohort rows", present_null: n/a}
units: n/a
depends_on: [COHORT]
output: {physical_name: cohortn, target_published_name: COHORTN, name_status: undecided, type: integer, nullable: false, codes: "1=Overall OC;2=1L;3=1LM;4=2L;5=2LM;6=3L;7=4L;8=5L;9=2L+ PROC", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [POP-COHORTN-SET, POP-PROC-PLATSEN]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "COHORT='Overall OC, Index at Init/Diag' → COHORTN=1; COHORT='2L+ PROC, Index at First Platinum Resistance' → COHORTN=9"
notes: "Numeric counterpart of COHORT. The spec itself flags the 1-9 vs 1-11 conflict (Review Decisions R4/B4), captured as POP-COHORTN-SET. Carries a [verify] marker in the source."
```

#### COHORTU

```yaml
variable_id: COHORTU
spec_refs: [study_population:12]
spec_digest: cca72b9cb304
required_rule: "Treated/Untreated axis — within Overall OC, COHORTU='Untreated OC' if the patient has NO LOT1 start in the line-of-therapy table, else 'Treated OC'."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "if COHORT='Overall OC' and the patient has no LOT1 start in the line-of-therapy (lot) table → 'Untreated OC'; else 'Treated OC'. TREATED is the presence of a LOT1 start; LOT1 is defined in the treatment domain, so the atomic start-date column is not proposed here."
cohort_applicability: "Untreated OC arises only within the Overall OC cohort; other cohorts are treated by construction"
missing: {no_record: n/a, present_null: "no LOT1 start → 'Untreated OC'"}
units: n/a
depends_on: [COHORT]
output: {physical_name: cohortu, target_published_name: COHORTU, name_status: undecided, type: string, nullable: false, codes: "Untreated OC;Treated OC", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "Overall OC patient with no LOT1 start → COHORTU='Untreated OC'; a 1L-treated patient → COHORTU='Treated OC'"
notes: "The rule is fully stated (untreated = absence of a LOT1 start), so drafted rather than blocked. LOT1 is a cross-domain treatment variable, hence source is derived and no lot column is invented here."
```

#### COHORTUN

```yaml
variable_id: COHORTUN
spec_refs: [study_population:13]
spec_digest: 1e41ab21582f
required_rule: "Numeric code of COHORTU — 1=Treated OC, 2=Untreated OC."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of COHORTU: 1=Treated OC, 2=Untreated OC."
cohort_applicability: "all cohorts"
missing: {no_record: n/a, present_null: "COHORTU='Untreated OC' → 2"}
units: n/a
depends_on: [COHORTU]
output: {physical_name: cohortun, target_published_name: COHORTUN, name_status: undecided, type: integer, nullable: false, codes: "1=Treated OC;2=Untreated OC", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "COHORTU='Untreated OC' → COHORTUN=2"
notes: "Numeric counterpart of COHORTU. Note the code order 1=Treated, 2=Untreated (the values cell reads '1, 2' with definition '1 = Treated OC, 2 = Untreated OC')."
```


## clinical — CL-A

#### INIT

```yaml
variable_id: INIT
spec_refs: [clinical:6]
spec_digest: cf698095566b
required_rule: Initial OC diagnosis date, taken from the Enhanced OC table (source var INT_OC_DX); for multiple primaries diagnosed after 2011 the primary with the highest stage is chosen.
source: {kind: vendor, inputs: {oc_clinical: {diagnosis_date: DiagnosisDate}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "Enhanced_OvarianCancer.DiagnosisDate; multiple primaries after 2011 -> the primary with the highest stage. The DiagnosisDate coalescence hierarchy (biopsy-collection > physician-biopsy > physician-dx > definitive-surgery) is applied upstream in the source (per source dict)."
tie_break: {equidistant: n/a, same_day: "multiple primaries after 2011 -> highest-stage primary"}
derivation: "carry Enhanced_OvarianCancer.DiagnosisDate as the initial OC diagnosis date; multiple primaries after 2011 -> take the highest-stage primary."
cohort_applicability: all cohorts
missing: {no_record: "no Enhanced OC diagnosis record -> INIT null", present_null: "DiagnosisDate null -> INIT null"}
units: date
depends_on: []
output: {physical_name: init, target_published_name: INIT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "Enhanced_OvarianCancer.DiagnosisDate=2020-03-15 -> INIT=2020-03-15"
notes: "Source var INT_OC_DX. The biopsy>physician-dx>surgery date hierarchy and the multiple-primaries->highest-stage rule are stated by RWB (source dict); INIT is the anchor for INITYR and TT_FIRST_TX_DIAG."
```

#### INITYR

```yaml
variable_id: INITYR
spec_refs: [clinical:7]
spec_digest: a2fed8ed068b
required_rule: Year of initial OC diagnosis = year(INIT) (source var INTYR).
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "year(INIT)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "INIT null -> INITYR null"}
units: years
depends_on: [INIT]
output: {physical_name: inityr, target_published_name: INITYR, name_status: undecided, type: integer, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "INIT=2020-03-15 -> INITYR=2020"
notes: "Source var INTYR. Pure year extraction from INIT."
```

#### HISTO

```yaml
variable_id: HISTO
spec_refs: [clinical:8]
spec_digest: e3da5af9a636
required_rule: Histology group at OC diagnosis (character) - Serous / Epithelial NOS and Other / Unknown or missing - recoded from source Histology; a tumor with multiple epithelial histologies is Epithelial NOS.
source: {kind: vendor, inputs: {oc_clinical: {histology: Histology}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "recode Enhanced_OvarianCancer.Histology into three groups: 'Serous'; 'Epithelial NOS' or Other; 'Unknown/not documented'. Multiple/combination epithelial histologies -> 'Epithelial NOS' (per Flatiron). Full source-value -> group map to variables/codelists."
cohort_applicability: all cohorts
missing: {no_record: "no Histology record -> 'Unknown/not documented'", present_null: "Histology null -> 'Unknown/not documented'"}
units: n/a
depends_on: []
output: {physical_name: histo, target_published_name: HISTO, name_status: undecided, type: string, nullable: true, codes: "1=Serous;2=Epithelial NOS and Other;3=Unknown or missing", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "Histology='Serous' -> HISTO='Serous'; two epithelial histologies -> HISTO='Epithelial NOS and Other'"
notes: "Read from t_&cohort_enh_ov_&date. HISTON is the numeric counterpart on its own row. The combination->Epithelial NOS collapse is stated."
```

#### HISTON

```yaml
variable_id: HISTON
spec_refs: [clinical:9]
spec_digest: e68b8c4b5df6
required_rule: Numeric code of HISTO - 1=Serous, 2=Epithelial NOS/Other, 3=Unknown/missing.
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of HISTO: 1=Serous, 2=Epithelial NOS/Other, 3=Unknown/missing (recode source Histology as-is, combinations -> 2)."
cohort_applicability: all cohorts
missing: {no_record: "no Histology record -> 3", present_null: "Histology null -> 3"}
units: n/a
depends_on: [HISTO]
output: {physical_name: histon, target_published_name: HISTON, name_status: undecided, type: integer, nullable: true, codes: "1=Serous;2=Epithelial NOS/Other;3=Unknown/missing", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "HISTO='Serous' -> HISTON=1"
notes: "Numeric mirror of HISTO on its own row per the tab's convention."
```

#### STAGE

```yaml
variable_id: STAGE
spec_refs: [clinical:10]
spec_digest: 89aa626bc669
required_rule: Stage at OC diagnosis (character) - I / II / III / IV / Unknown/not documented - by FIGO prefix cascade on GroupStage.
source: {kind: vendor, inputs: {oc_clinical: {group_stage: GroupStage}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "GroupStage: FIGO preferred over AJCC; pathologic unless neoadjuvant -> clinical; staging window dx -> definitive-surgery or 4 months (applied upstream in the source per source dict)."
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "FIGO cascade on GroupStage, testing prefixes in order: startswith 'IV' -> 'IV'; else startswith 'III' -> 'III'; else startswith 'II' -> 'II'; else startswith 'I' -> 'I'; else 'Unknown/not documented'."
cohort_applicability: all cohorts
missing: {no_record: "no GroupStage record -> 'Unknown/not documented'", present_null: "GroupStage null/blank -> 'Unknown/not documented'"}
units: n/a
depends_on: []
output: {physical_name: stage, target_published_name: STAGE, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "GroupStage='IIIC' -> STAGE='III'; GroupStage='IV' -> STAGE='IV'; GroupStage null -> STAGE='Unknown/not documented'"
notes: "Prefix cascade must test 'IV' before 'III' before 'II' before 'I' (order matters). FIGO-over-AJCC and pathologic-vs-clinical selection are stated as GroupStage's upstream derivation. STAGEN is the numeric counterpart."
```

#### STAGEN

```yaml
variable_id: STAGEN
spec_refs: [clinical:11]
spec_digest: f35f900de1f7
required_rule: Numeric code of STAGE - 1=I, 2=II, 3=III, 4=IV, 5=Unknown/not documented.
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of STAGE: 1=I, 2=II, 3=III, 4=IV, 5=Unknown/not documented."
cohort_applicability: all cohorts
missing: {no_record: "no GroupStage record -> 5", present_null: "STAGE='Unknown/not documented' -> 5"}
units: n/a
depends_on: [STAGE]
output: {physical_name: stagen, target_published_name: STAGEN, name_status: undecided, type: integer, nullable: true, codes: "1=I;2=II;3=III;4=IV;5=Unknown/not documented", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "STAGE='III' -> STAGEN=3; STAGE='Unknown/not documented' -> STAGEN=5"
notes: "The definition cell carries a stray 'NSCLC' label, an apparent copy-paste artifact from a lung-cancer spec (finding CL-A-STAGEN-NSCLC); it does not affect the 1..5 mapping, which mirrors STAGE. Numeric counterpart of STAGE."
```

#### ISSURG

```yaml
variable_id: ISSURG
spec_refs: [clinical:12]
spec_digest: 330cebe7da0b
required_rule: Debulking surgery flag (character) - 'Yes' / 'No' - indicating whether a surgical procedure was performed for the patient's initial OC diagnosis (source var ISSURGERY_FLAG).
source: {kind: vendor, inputs: {oc_clinical: {is_surgery: IsSurgery}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "if IsSurgery='No/unknown' -> 'No'; else if IsSurgery='Yes' -> 'Yes'. Chain has no terminal else: an IsSurgery that is null/absent or outside {Yes, No/unknown} is undefined (BLOCKED: CL-A-ISSURG-UNMATCHED)."
cohort_applicability: all cohorts
missing: {no_record: "no Enhanced OC record / IsSurgery null -> undefined (BLOCKED: CL-A-ISSURG-UNMATCHED)", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: issurg, target_published_name: ISSURG, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-A-ISSURG-UNMATCHED]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "IsSurgery='Yes' -> ISSURG='Yes'; IsSurgery='No/unknown' -> ISSURG='No'"
notes: "Definitive curative-intent resection; diagnostic/palliative excluded (per source dict). 'No/unknown' collapses into 'No'. The Values cell shows numeric codes (1=Yes/0=No/unknown) that belong to ISSURGN; the char output is 'Yes'/'No'. No-terminal-else on the IsSurgery input raises CL-A-ISSURG-UNMATCHED."
```

#### ISSURGN

```yaml
variable_id: ISSURGN
spec_refs: [clinical:13]
spec_digest: 9b18276eb608
required_rule: Numeric mirror of ISSURG - 1=Yes, 0=No/unknown (source var ISSURGERY_FLAG (N)).
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "if IsSurgery='Yes' -> 1; if IsSurgery='No/unknown' -> 0. Same no-terminal-else as ISSURG: IsSurgery null/absent/other is undefined (BLOCKED: CL-A-ISSURG-UNMATCHED)."
cohort_applicability: all cohorts
missing: {no_record: "no Enhanced OC record / IsSurgery null -> undefined (BLOCKED: CL-A-ISSURG-UNMATCHED)", present_null: n/a}
units: n/a
depends_on: [ISSURG]
output: {physical_name: issurgn, target_published_name: ISSURGN, name_status: undecided, type: integer, nullable: true, codes: "1=Yes;0=No/unknown", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-A-ISSURG-UNMATCHED]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "IsSurgery='Yes' -> ISSURGN=1; IsSurgery='No/unknown' -> ISSURGN=0"
notes: "The cell carries a '[verify - both branches Prior spec-read as 0]' marker recording that the prior spec mistakenly mapped both branches to 0 (finding CL-A-ISSURGN-VERIFY); the current 1/0 mapping is legible. Numeric counterpart of ISSURG; shares the unmatched-input decision CL-A-ISSURG-UNMATCHED."
```

#### SURG

```yaml
variable_id: SURG
spec_refs: [clinical:14]
spec_digest: 04046749e84a
required_rule: Type of cytoreductive surgery - 1=PCS, 2=ICS, 3=No surgery, 4=Unknown, 5=Missing - tying the surgery date to the 1L window (source var SURGERY_TYPE).
source: {kind: vendor, inputs: {oc_clinical: {surgery_date: SurgeryDate, is_surgery: IsSurgery}}}
grain: [patientid, cohortn]
anchor: n/a
window: "1L window bounds startdate11 (1L start) and lastdate11 (1L end)"
record_selection: "measured among patients who received surgery; surgery before debulking/1L start -> PDS(PCS), else IDS(ICS)."
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "if ISSURG ne 'Yes' -> 3; else if ISSURG='Yes' and surgerydate_sasdt missing -> 4; else if surgerydate_sasdt < startdate11 -> 1 (PCS); else if startdate11 <= surgerydate_sasdt <= lastdate11 or surgerydate_sasdt > lastdate11 -> 2 (ICS); else -> 5 (Missing). Terminal else present."
cohort_applicability: all cohorts
missing: {no_record: "ISSURG ne 'Yes' -> 3 (No surgery)", present_null: "ISSURG='Yes' with SurgeryDate missing -> 4 (Unknown)"}
units: n/a
depends_on: [ISSURG]
output: {physical_name: surg, target_published_name: SURG, name_status: undecided, type: string, nullable: true, codes: "1=Primary cytoreductive surgery (PCS);2=Interval cytoreductive surgery (ICS);3=No surgery;4=Unknown;5=Missing", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "ISSURG='Yes', surgerydate < startdate11 -> SURG=1 (PCS); ISSURG='Yes', startdate11 <= surgerydate <= lastdate11 -> SURG=2 (ICS)"
notes: "startdate11/lastdate11 are the 1L line-start/end dates (LineOfTherapy). The ICS operator '<=' plus the 'or surgerydate>lastdate11' clause are a documented correction vs the source pending Epi ratification (finding CL-A-SURG-OPERATOR); the rule is stated so drafted, not blocked. The '[and surgerydate_sasdt missing]' bracket is a legible condition, not a placeholder."
```

#### SURGN

```yaml
variable_id: SURGN
spec_refs: [clinical:15]
spec_digest: 363fad4fa842
required_rule: Numeric mirror of SURG - 1..5 - same 1L-window tie (source var SURGERY_TYPE_N).
source: {kind: vendor, inputs: {oc_clinical: {surgery_date: SurgeryDate, is_surgery: IsSurgery}}}
grain: [patientid, cohortn]
anchor: n/a
window: "1L window bounds startdate11 (1L start) and lastdate11 (1L end)"
record_selection: "same 1L-window tie as SURG."
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "if ISSURG ne 'Yes' -> 3; else if ISSURG='Yes' and surgerydate missing -> 4; else if surgerydate_sasdt < startdate11 -> 1; else if startdate11 <= surgerydate_sasdt <= lastdate11 or surgerydate_sasdt > lastdate11 -> 2; else -> 5."
cohort_applicability: all cohorts
missing: {no_record: "ISSURG ne 'Yes' -> 3", present_null: "ISSURG='Yes' with SurgeryDate missing -> 4 (Unknown)"}
units: n/a
depends_on: [ISSURG]
output: {physical_name: surgn, target_published_name: SURGN, name_status: undecided, type: integer, nullable: true, codes: "1=PCS;2=ICS;3=No surgery;4=Unknown;5=Missing", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "ISSURG='Yes', surgerydate > lastdate11 -> SURGN=2; ISSURG='Yes', surgerydate missing -> SURGN=4"
notes: "Numeric mirror of SURG; same ICS operator correction pending Epi ratification (finding CL-A-SURG-OPERATOR). The '[surgerydate missing]' bracket is a legible condition, not a placeholder."
```

#### NEOADJ

```yaml
variable_id: NEOADJ
spec_refs: [clinical:16]
spec_digest: 6c67be0ce109
required_rule: Neoadjuvant chemotherapy (character) - Yes / No / Unknown - derived from SURGN (source var NEOADJ_CHEMO).
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "if SURGN=2 -> 'Yes'; else if SURGN=4 -> 'Unknown'; else -> 'No'."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "SURGN=4 (Unknown) -> 'Unknown'; all other SURGN -> 'No'"}
units: n/a
depends_on: [SURGN]
output: {physical_name: neoadj, target_published_name: NEOADJ, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "SURGN=2 (ICS) -> NEOADJ='Yes'; SURGN=1 (PCS) -> NEOADJ='No'"
notes: "Fully specified 3-state derivation from SURGN (ICS implies neoadjuvant chemo). Measured among patients who received surgery (IDS vs PDS framing)."
```

#### NEOADJN

```yaml
variable_id: NEOADJN
spec_refs: [clinical:17]
spec_digest: a3bda62ff939
required_rule: Numeric mirror of NEOADJ - 1=Yes, 2=No, 0=Unknown (source var NEOADJ_CHEMO_numeric).
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "if SURGN=2 -> 1; else if SURGN=4 -> 0; else -> 2."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "SURGN=4 -> 0 (Unknown)"}
units: n/a
depends_on: [SURGN]
output: {physical_name: neoadjn, target_published_name: NEOADJN, name_status: undecided, type: integer, nullable: true, codes: "1=Yes;2=No;0=Unknown", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "SURGN=2 -> NEOADJN=1; SURGN=1 -> NEOADJN=2"
notes: "Numeric counterpart of NEOADJ, derived from SURGN. Note the non-sequential code (0=Unknown)."
```

#### RD

```yaml
variable_id: RD
spec_refs: [clinical:18]
spec_digest: 7ba6582869a2
required_rule: Residual disease status post-debulking (character) - Visible residual disease / No visible residual disease / No surgery/Unknown (source var RD_CHAR).
source: {kind: vendor, inputs: {oc_clinical: {residual_disease_status: ResidualDiseaseStatus, is_surgery: IsSurgery}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "if IsSurgery='No/unknown' -> 'No surgery/Unknown'; else if ResidualDiseaseStatus='Residual disease' -> 'Visible residual disease'; else if ResidualDiseaseStatus='No residual disease' -> 'No visible residual disease'; else -> 'No surgery/Unknown'. Branch 1 (keyed on IsSurgery, not ResidualDiseaseStatus) appears struck through in the source - whether it is active is BLOCKED (CL-A-RD-BRANCH1)."
cohort_applicability: all cohorts
missing: {no_record: "no Enhanced OC record -> terminal else 'No surgery/Unknown'", present_null: "ResidualDiseaseStatus 'Unknown/not documented'/null -> 'No surgery/Unknown'"}
units: n/a
depends_on: []
output: {physical_name: rd, target_published_name: RD, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-A-RD-BRANCH1]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "IsSurgery='Yes', ResidualDiseaseStatus='Residual disease' -> RD='Visible residual disease'; IsSurgery='No/unknown' -> RD='No surgery/Unknown'"
notes: "Read from t_&cohort_enh_ov_&date. Branch 1 was corrected vs source to key on IsSurgery='No/unknown' but is struck through - Epi must confirm whether it is active (CL-A-RD-BRANCH1). The '[residual disease]' bracket in branch 3 is legible, not a placeholder."
```

#### RDN

```yaml
variable_id: RDN
spec_refs: [clinical:19]
spec_digest: b9377dc90a25
required_rule: Ordinal mirror of RD - 1=Visible residual disease, 2=No visible residual disease, 3=No surgery/Unknown (source var RD_NUM).
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "if IsSurgery='No/unknown' -> 3; else if ResidualDiseaseStatus='Residual disease' -> 1; else if ResidualDiseaseStatus='No residual disease' -> 2. As registered the chain has no terminal else; per its declared status as the ordinal mirror of RD the missing terminal is RD's else 'No surgery/Unknown' -> 3 (finding CL-A-RDN-ELSE-CLIP). Branch-1 struck-through question BLOCKED (CL-A-RD-BRANCH1)."
cohort_applicability: all cohorts
missing: {no_record: "no Enhanced OC record -> 3 (mirroring RD's terminal else)", present_null: "ResidualDiseaseStatus 'Unknown/not documented'/null -> 3"}
units: n/a
depends_on: [RD]
output: {physical_name: rdn, target_published_name: RDN, name_status: undecided, type: integer, nullable: true, codes: "1=Visible residual disease;2=No visible residual disease;3=No surgery/Unknown", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-A-RD-BRANCH1]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "IsSurgery='Yes', ResidualDiseaseStatus='No residual disease' -> RDN=2; IsSurgery='No/unknown' -> RDN=3"
notes: "Ordinal counterpart of RD; shares the struck-through branch-1 decision CL-A-RD-BRANCH1. Its if/else-if chain omits the terminal else that RD states -> stand-in clip recorded as CL-A-RDN-ELSE-CLIP (resolves by mirroring RD's '->3')."
```

#### sizeofresidualdisease

```yaml
variable_id: sizeofresidualdisease
spec_refs: [clinical:20]
spec_digest: 94614b308e17
required_rule: Size of residual disease, reported as-is from the Enhanced OC table - value set {<=1 cm, <=2 cm, >1 cm, >2 cm, Unknown}.
source: {kind: vendor, inputs: {oc_clinical: {size_of_residual_disease: SizeOfResidualDisease}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "reported as-is; the source coalescence hierarchy op-report > radiology+clinician > clinician > radiology is applied upstream (per source dict)."
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry Enhanced_OvarianCancer.SizeOfResidualDisease as-is; retain the delivered value set {<=1 cm, <=2 cm, >1 cm, >2 cm, Unknown}."
cohort_applicability: all cohorts
missing: {no_record: "no record -> 'Unknown'", present_null: "SizeOfResidualDisease null -> 'Unknown'"}
units: n/a
depends_on: []
output: {physical_name: sizeofresidualdisease, target_published_name: sizeofresidualdisease, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "SizeOfResidualDisease='<=1 cm' -> sizeofresidualdisease='<=1 cm'"
notes: "Kept as-is per the processing banner and carried into the final output; a '[verify]' sign-off marker is noted. The delivered value set overlaps ({<=1 cm, <=2 cm, >1 cm, >2 cm}) but is retained exactly as delivered, so no recode is applied."
```

#### TT_FIRST_TX_DIAG

```yaml
variable_id: TT_FIRST_TX_DIAG
spec_refs: [clinical:21]
spec_digest: b428c8c82a45
required_rule: Time from initial diagnosis to first treatment/surgery (days) = min(SurgeryDate, 1L start) - INIT; NA for no surgery, no 1L, or a negative result.
source: {kind: vendor, inputs: {oc_clinical: {surgery_date: SurgeryDate, diagnosis_date: DiagnosisDate}, lot: {line_start: StartDate}}}
grain: [patientid, cohortn]
anchor: INIT
window: n/a
record_selection: "earliest of SurgeryDate and 1L StartDate (LOT1SD)."
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "min(surgerydate, LOT1SD) - INIT_diagnosisdate, in days; result set to NA if no surgery date, no 1L, or if the result is negative."
cohort_applicability: all cohorts
missing: {no_record: "no surgery date and no 1L start -> NA", present_null: "negative result -> NA"}
units: days
depends_on: [INIT]
output: {physical_name: tt_first_tx_diag, target_published_name: TT_FIRST_TX_DIAG, name_status: undecided, type: integer, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "INIT=2020-03-01, 1L StartDate=2020-04-10, no earlier surgery -> TT_FIRST_TX_DIAG=40"
notes: "LOT1SD is the 1L StartDate (LineOfTherapy). The cell carries '[verify - Prior spec mixed this cell with UPLAT content]' - a prior-spec contamination recorded as CL-A-TTFTD-UPLAT (resolves by confirming the current cell on re-extraction); the current rule is legible so drafted. ~70 patients had negative values in the March delivery (set to NA); whether they enter the cohort is a population question handled by the cohort filters, not here."
```

#### ECOG

```yaml
variable_id: ECOG
spec_refs: [clinical:22]
spec_digest: 78c83ce278ce
required_rule: ECOG performance status (character) - '0'..'4', 'Unknown', 'Missing' - the highest ECOGVALUE whose ECOGDATE is closest to INDEXDT.
source: {kind: vendor, inputs: {ecog: {ecog_value: EcogValue, ecog_date: EcogDate}, baseline_ecog: {ecog_value: ECOGValue, ecog_date: ECOGDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "ECOG assessment period (study_period:16 LOT_ECOG) = INDEX-30 through INDEX+7; but the definition uses closest-to-INDEXDT with 'none on/prior to index -> Missing', and which tables scope the selection is BLOCKED (CL-A-ECOG-SOURCE)"
record_selection: "pick the ECOGDATE closest to INDEXDT; whether both the ECOG and BaselineECOG tables are used depends on cohort and is BLOCKED (CL-A-ECOG-SOURCE)."
tie_break: {equidistant: "on a tie take the highest ECOGVALUE", same_day: "take the highest ECOGVALUE"}
derivation: "from the applicable ECOG source table(s), take the ECOGVALUE whose ECOGDATE is closest to INDEXDT; on a date tie take the highest value; no value on/prior to index -> 'Missing'; ECOG 5 suppressed -> 'Unknown' (source)."
cohort_applicability: "all cohorts; source-table selection differs by cohort (treated: BaselineECOG only; diagnosed/untreated: both) - BLOCKED (CL-A-ECOG-SOURCE)"
missing: {no_record: "no ECOG value on/prior to index -> 'Missing'", present_null: "ECOG 5 suppressed -> 'Unknown'"}
units: n/a
depends_on: []
output: {physical_name: ecog, target_published_name: ECOG, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-A-ECOG-SOURCE]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be finalized until the source-table selection is decided (CL-A-ECOG-SOURCE); e.g. closest pre-index ECOGVALUE=2 -> ECOG='2'"
notes: "Reads t_meg_ecog_&date and t_meg_baseline_ecog_&date. study_period:24 ECOG_SOURCE_DECISION records the open recommendation (treated cohorts: baseline table only; diagnosed/untreated: use both) - raised here as CL-A-ECOG-SOURCE. A subsidiary tension between the LOT_ECOG window [INDEX-30,INDEX+7] and the 'closest-to-index / none on-or-prior -> Missing' wording is noted for the same decision."
```

#### ECOGN

```yaml
variable_id: ECOGN
spec_refs: [clinical:23]
spec_digest: d47cde035169
required_rule: Numeric mirror of ECOG (1..7 over ECOG's ordered categories) - highest ECOGVALUE [0-4] with ECOGDATE closest to INDEXDT; none on/prior to index -> Missing.
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "same ECOG assessment/selection as ECOG - BLOCKED (CL-A-ECOG-SOURCE)"
record_selection: "closest ECOGDATE to INDEXDT; source-table selection BLOCKED (CL-A-ECOG-SOURCE)."
tie_break: {equidistant: "on a tie take the highest value", same_day: "highest value"}
derivation: "numeric code of ECOG following ECOG's ordered categories (1='0',2='1',3='2',4='3',5='4',6=Unknown,7=Missing); closest ECOGDATE to INDEXDT, tie -> highest; none on/prior to index -> Missing."
cohort_applicability: "all cohorts; source-table selection differs by cohort - BLOCKED (CL-A-ECOG-SOURCE)"
missing: {no_record: "no ECOG value on/prior to index -> Missing (code 7)", present_null: "ECOG 5 suppressed -> Unknown (code 6)"}
units: n/a
depends_on: [ECOG]
output: {physical_name: ecogn, target_published_name: ECOGN, name_status: undecided, type: integer, nullable: true, codes: "1..7 mirror of ECOG's ordered categories (1='0';2='1';3='2';4='3';5='4';6=Unknown;7=Missing)", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-A-ECOG-SOURCE]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be finalized until source-table selection is decided (CL-A-ECOG-SOURCE); e.g. ECOG='2' -> ECOGN=3"
notes: "Numeric counterpart of ECOG; shares CL-A-ECOG-SOURCE. The Values cell states '1,2,3,4,5,6,7' but not the per-category assignment; the 1..7 code follows ECOG's listed category order and is to be enumerated in variables/codelists and confirmed."
```

#### WEIGHT

```yaml
variable_id: WEIGHT
spec_refs: [clinical:24]
spec_digest: d04436696d21
required_rule: Weight in kg - TestResultCleaned closest to INDEXDT where Test='body weight' and TestUnitsCleaned='kg'; multiple on the closest date -> highest; value <0 -> missing; 0 removed.
source: {kind: vendor, inputs: {vitals: {test_result: TestResultCleaned, test: Test, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "not stated - no outer selection window bound and no equidistant (before-vs-after index) tie-break given (BLOCKED: CL-A-VITALS-SELECTION)"
record_selection: "the body-weight TestResultCleaned whose date = max(TestDate, ResultDate) is closest to INDEXDT; among ties on the closest date take the highest; window bound and equidistant tie-break BLOCKED (CL-A-VITALS-SELECTION)."
tie_break: {equidistant: "record equally close before vs after index - BLOCKED (CL-A-VITALS-SELECTION)", same_day: "multiple on the closest date -> highest"}
derivation: "filter Vitals to Test='body weight' and TestUnitsCleaned='kg'; date = max(TestDate, ResultDate); select the record closest to INDEXDT (same-date tie -> highest); value <0 -> missing; value=0 removed."
cohort_applicability: all cohorts
missing: {no_record: "no qualifying body-weight record -> WEIGHT missing", present_null: "value <0 or =0 -> missing"}
units: kg
depends_on: []
output: {physical_name: weight, target_published_name: WEIGHT, name_status: undecided, type: float, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-A-VITALS-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be finalized until the selection window/equidistant tie-break is decided (CL-A-VITALS-SELECTION); e.g. a single kg body-weight record 10 days pre-index of 68 -> WEIGHT=68"
notes: "09-Jun-2025 decision: remove 0's, keep other extreme values (note outliers to end users) - stated. A '[verify]' marker and an odd single quote in the rule text are stand-in artifacts, noted. The 'closest to INDEXDT' selection gives no outer window and no equidistant tie-break -> CL-A-VITALS-SELECTION."
```

#### WEIGHTDT

```yaml
variable_id: WEIGHTDT
spec_refs: [clinical:25]
spec_digest: b050efc130b6
required_rule: Weight status date = max(TestDate, ResultDate) of the body-weight record selected for WEIGHT.
source: {kind: vendor, inputs: {vitals: {test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "inherits WEIGHT's selection - BLOCKED (CL-A-VITALS-SELECTION)"
record_selection: "the record chosen for WEIGHT."
tie_break: {equidistant: "inherits WEIGHT (BLOCKED: CL-A-VITALS-SELECTION)", same_day: n/a}
derivation: "max(TestDate, ResultDate) of the body-weight record selected for WEIGHT."
cohort_applicability: all cohorts
missing: {no_record: "no WEIGHT record selected -> WEIGHTDT null", present_null: n/a}
units: date
depends_on: [WEIGHT]
output: {physical_name: weightdt, target_published_name: WEIGHTDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-A-VITALS-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be finalized until WEIGHT selection is decided (CL-A-VITALS-SELECTION); given the selected record, WEIGHTDT = max(TestDate, ResultDate)"
notes: "The max(TestDate, ResultDate) date rule is fully specified; the value is undetermined only because it points at the WEIGHT record whose selection is blocked (CL-A-VITALS-SELECTION). '[verify]' marker noted."
```

#### HEIGHT

```yaml
variable_id: HEIGHT
spec_refs: [clinical:26]
spec_digest: b192af03f91d
required_rule: Height in cm - TestResultCleaned closest to index where Test='body height' and TestUnitsCleaned='cm', not null; multiple -> highest; value <0 -> missing.
source: {kind: vendor, inputs: {vitals: {test_result: TestResultCleaned, test: Test, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "not stated - no outer selection window bound and no equidistant tie-break given (BLOCKED: CL-A-VITALS-SELECTION)"
record_selection: "the body-height TestResultCleaned whose date = max(TestDate, ResultDate) is closest to INDEXDT; among ties on the closest date take the highest; window bound and equidistant tie-break BLOCKED (CL-A-VITALS-SELECTION)."
tie_break: {equidistant: "record equally close before vs after index - BLOCKED (CL-A-VITALS-SELECTION)", same_day: "multiple on the closest date -> highest"}
derivation: "filter Vitals to Test='body height' and TestUnitsCleaned='cm' and TestResultCleaned not null; date = max(TestDate, ResultDate); select the record closest to INDEXDT (same-date tie -> highest); value <0 -> missing. (TestResultCleaned is character - cast to numeric.)"
cohort_applicability: all cohorts
missing: {no_record: "no qualifying body-height record -> HEIGHT missing", present_null: "value <0 -> missing"}
units: cm
depends_on: []
output: {physical_name: height, target_published_name: HEIGHT, name_status: undecided, type: float, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-A-VITALS-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be finalized until the selection window/equidistant tie-break is decided (CL-A-VITALS-SELECTION); e.g. a single cm body-height record near index of 165 -> HEIGHT=165"
notes: "Same closest-to-index selection as WEIGHT with no outer window and no equidistant tie-break -> shares CL-A-VITALS-SELECTION. TestResultCleaned is character and needs casting. '[verify]' marker noted."
```

#### HEIGHTDT

```yaml
variable_id: HEIGHTDT
spec_refs: [clinical:27]
spec_digest: 1d2fa8b7849e
required_rule: Height status date = max(TestDate, ResultDate) of the body-height record selected for HEIGHT.
source: {kind: vendor, inputs: {vitals: {test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "inherits HEIGHT's selection - BLOCKED (CL-A-VITALS-SELECTION)"
record_selection: "the record chosen for HEIGHT."
tie_break: {equidistant: "inherits HEIGHT (BLOCKED: CL-A-VITALS-SELECTION)", same_day: n/a}
derivation: "max(TestDate, ResultDate) of the body-height record selected for HEIGHT."
cohort_applicability: all cohorts
missing: {no_record: "no HEIGHT record selected -> HEIGHTDT null", present_null: n/a}
units: date
depends_on: [HEIGHT]
output: {physical_name: heightdt, target_published_name: HEIGHTDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-A-VITALS-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be finalized until HEIGHT selection is decided (CL-A-VITALS-SELECTION); given the selected record, HEIGHTDT = max(TestDate, ResultDate)"
notes: "The date rule is fully specified; the value is undetermined only because it points at the HEIGHT record whose selection is blocked (CL-A-VITALS-SELECTION). '[verify]' marker noted."
```

#### BMI

```yaml
variable_id: BMI
spec_refs: [clinical:28]
spec_digest: e5313843143f
required_rule: BMI (kg/m^2) = WEIGHT_kg / (HEIGHT_cm/100)^2; missing if WEIGHT or HEIGHT missing; height and weight need not share a date.
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "if WEIGHT or HEIGHT missing -> missing; else BMI = WEIGHT / (HEIGHT/100)^2 (HEIGHT in cm)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "WEIGHT or HEIGHT missing -> BMI missing"}
units: kg/m^2
depends_on: [WEIGHT, HEIGHT]
output: {physical_name: bmi, target_published_name: BMI, name_status: undecided, type: float, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "WEIGHT=68, HEIGHT=165 -> BMI=68/(1.65)^2=24.98"
notes: "Formula fully specified (height/weight need not share a date). Consumes WEIGHT and HEIGHT, whose record selection is blocked on CL-A-VITALS-SELECTION - the BMI value therefore inherits that uncertainty, though its own derivation raises no separate question."
```

#### BMI_GRP

```yaml
variable_id: BMI_GRP
spec_refs: [clinical:29]
spec_digest: fc4e70229e98
required_rule: BMI group (character) - 1=Underweight, 2=Normal weight, 3=Overweight, 4=Obese, 5=Missing - banded from BMI (source var BMI_GRP).
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "BMI<18.5 -> 1 (Underweight); 18.5<=BMI<25 -> 2 (Normal weight); 25<=BMI<30 -> 3 (Overweight); BMI>=30 -> 4 (Obese); BMI missing -> 5 (Missing)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "BMI missing -> 5 (Missing)"}
units: n/a
depends_on: [BMI]
output: {physical_name: bmi_grp, target_published_name: BMI_GRP, name_status: undecided, type: string, nullable: true, codes: "1=Underweight;2=Normal weight;3=Overweight;4=Obese;5=Missing", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "BMI=31 -> BMI_GRP=4 (Obese); BMI=18.4 -> BMI_GRP=1 (Underweight)"
notes: "The obese boundary was re-read and confirmed BMI>=30 -> 4 (the prior spec's 'BMI<=30' was wrong); this correction is pending Epi ratification and carries a '[verify >=30 vs >30]' marker (finding CL-A-BMIGRP-BOUNDARY). Rule is stated so drafted. Inherits WEIGHT/HEIGHT selection uncertainty via BMI (CL-A-VITALS-SELECTION)."
```

#### BMIGRN

```yaml
variable_id: BMIGRN
spec_refs: [clinical:30]
spec_digest: 05e732b2dc61
required_rule: Numeric mirror of BMI_GRP - 1..5 (source var BMIGR1N).
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "BMI<18.5 -> 1; 18.5<=BMI<25 -> 2; 25<=BMI<30 -> 3; BMI>=30 -> 4; BMI missing -> 5."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "BMI missing -> 5"}
units: n/a
depends_on: [BMI]
output: {physical_name: bmigrn, target_published_name: BMIGRN, name_status: undecided, type: integer, nullable: true, codes: "1=Underweight;2=Normal weight;3=Overweight;4=Obese;5=Missing", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "BMI=24.98 -> BMIGRN=2 (Normal weight)"
notes: "Numeric counterpart of BMI_GRP; same confirmed BMI>=30 -> 4 boundary correction pending Epi ratification (finding CL-A-BMIGRP-BOUNDARY). Inherits WEIGHT/HEIGHT selection uncertainty via BMI (CL-A-VITALS-SELECTION)."
```

#### BSA

```yaml
variable_id: BSA
spec_refs: [clinical:31]
spec_digest: df14ba5cc398
required_rule: Body surface area (m^2) by the Du Bois formula = 0.007184 * height[cm]^0.725 * weight[kg]^0.425; missing if height or weight missing.
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "if HEIGHT or WEIGHT missing -> missing; else BSA = 0.007184 * HEIGHT^0.725 * WEIGHT^0.425 (HEIGHT in cm, WEIGHT in kg)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "HEIGHT or WEIGHT missing -> BSA missing"}
units: m^2
depends_on: [HEIGHT, WEIGHT]
output: {physical_name: bsa, target_published_name: BSA, name_status: undecided, type: float, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "HEIGHT=165, WEIGHT=68 -> BSA=0.007184*165^0.725*68^0.425=1.75 (approx)"
notes: "Du Bois formula fully specified. BSA is confirmed as EDM baseline (not a new additive variable) - corrects the assessment workbook that had listed it as proposed additive. Consumes HEIGHT/WEIGHT, whose selection is blocked on CL-A-VITALS-SELECTION (inherited uncertainty; no separate question of its own)."
```


## clinical — CL-B

#### BRCA

```yaml
variable_id: BRCA
spec_refs: [clinical:32]
spec_digest: f89f9d9638c1
required_rule: BRCA status (character) — Mutated, Wild type, Unknown, None — by a time-agnostic ever-mutated-wins hierarchy over the biomarker window, from Enhanced_OvarianBiomarkers where BiomarkerName='BRCA'.
source: {kind: vendor, inputs: {biomarkers: {biomarker_name: BiomarkerName, biomarker_status: BiomarkerStatus}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "biomarker window — 'on or prior to index' per status text vs PRE_BIO (index+14d) per data-prep (BLOCKED: CL-B-BIO-WINDOW)"
record_selection: "time-agnostic 'ever' over the biomarker window; ever-Mutated wins over Wild type on conflict"
tie_break: {equidistant: n/a, same_day: "Mutated beats Wild type (ever-mutated-wins)"}
derivation: "map delivered BiomarkerStatus per the Biomarker_Status adhoc map (BRCA Mutation NOS / BRCA1 / BRCA2 / Both → Mutated; No BRCA Mutation / VUS / Genetic Variant Favor Polymorphism → Wild type; Unsuccessful-indeterminate / Results Pending / Other → Unknown), then: ever Mutated → Mutated; else ever Wild type → Wild type; else tested-no-result → Unknown; else (absent) → None. Full string→category map to variables/codelists."
cohort_applicability: all cohorts
missing: {no_record: "patient absent from Enhanced_OvarianBiomarkers → 'None'", present_null: "tested, no interpretable result → 'Unknown'"}
units: n/a
depends_on: [INDEX]
output: {physical_name: brca, target_published_name: BRCA, name_status: undecided, type: string, nullable: false, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-B-BIO-WINDOW]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "patient with a 'BRCA1 Mutation Identified' result on/prior to index → BRCA='Mutated'; patient absent from Enhanced_OvarianBiomarkers → BRCA='None'"
notes: "Table t_&cohort_enh_ovbiomarkers_&date. Row carries a [verify] marker. Window contradiction (status text 'on or prior to index' vs PRE_BIO index+14d) recorded as finding CL-B-BIO-WINDOW-CONTRA and blocked on decision CL-B-BIO-WINDOW. The string→category adhoc map is summarised here; values belong in variables/codelists."
```

#### BRCAN

```yaml
variable_id: BRCAN
spec_refs: [clinical:33]
spec_digest: f65d58236358
required_rule: Numeric code for BRCA — 1=Mutated, 2=Wild type, 3=Unknown, 4=None — same time-agnostic determination as BRCA.
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "same biomarker window as BRCA (BLOCKED upstream: CL-B-BIO-WINDOW)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of BRCA: Mutated→1, Wild type→2, Unknown→3, None→4."
cohort_applicability: all cohorts
missing: {no_record: "BRCA='None' → 4", present_null: "BRCA='Unknown' → 3"}
units: n/a
depends_on: [BRCA]
output: {physical_name: brcan, target_published_name: BRCAN, name_status: undecided, type: integer, nullable: false, codes: "1=Mutated;2=Wild type;3=Unknown;4=None", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "BRCA='Wild type' → BRCAN=2"
notes: "Numeric mirror of BRCA; the 1..4 code list is fully stated, so drafted. Correctness of the underlying status is subject to the BRCA window decision CL-B-BIO-WINDOW. Row carries a [verify] marker."
```

#### BRCADT

```yaml
variable_id: BRCADT
spec_refs: [clinical:34]
spec_digest: 626a7e501882
required_rule: BRCA biomarker date — the result date closest to (and on/prior to) index for the BRCA record, computed as max(SpecimenReceivedDate, ResultDate); missing when the status is missing.
source: {kind: vendor, inputs: {biomarkers: {specimen_received_date: SpecimenReceivedDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "on or prior to index"
record_selection: "the BRCA record closest to index (on/prior); test date = max(SpecimenReceivedDate, ResultDate)"
tie_break: {equidistant: "not specified for two equidistant BRCA records — corresponds to the status selection", same_day: n/a}
derivation: "test date = max(SpecimenReceivedDate, ResultDate); take the record closest to index whose value/status backs BRCA; if the BRCA status is missing → date missing."
cohort_applicability: all cohorts
missing: {no_record: "no BRCA record → date null", present_null: "BRCA status missing → date null"}
units: date
depends_on: [INDEX, BRCA]
output: {physical_name: brcadt, target_published_name: BRCADT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "one BRCA result with SpecimenReceivedDate=2020-03-01, ResultDate=2020-03-05, index=2020-06-01 → BRCADT=2020-03-05"
notes: "Row carries a [verify] marker. BRCA (the status this date accompanies) is determined time-agnostically while this date is closest-to-index — a design mismatch noted but not resolved here; the max(SpecimenReceivedDate, ResultDate) rule is stated. Table t_&cohort_enh_ovbiomarkers_&date."
```

#### BRCAC

```yaml
variable_id: BRCAC
spec_refs: [clinical:35]
spec_digest: b5d3b9896fcf
required_rule: BRCA status closest to index (character) — Mutated, Wild type, Unknown, None — using the record closest to (on/prior to) index, with stated same-date tie-breaks.
source: {kind: vendor, inputs: {biomarkers: {biomarker_name: BiomarkerName, biomarker_status: BiomarkerStatus, specimen_received_date: SpecimenReceivedDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "on or prior to index (closest-to-index selection)"
record_selection: "map BiomarkerStatus as for BRCA, then report the result closest to index; ties resolved per tie_break"
tie_break: {equidistant: n/a, same_day: "Mut+WT → Unknown; Mut+WT+Unk → Unknown; Mut+Unk → Mutated; WT+Unk → Wild type"}
derivation: "same string→category map as BRCA; among records on/prior to index take the one closest to index (test date = max(SpecimenReceivedDate, ResultDate)); apply the same-date tie-breaks above; absent → None."
cohort_applicability: all cohorts
missing: {no_record: "patient absent → 'None'", present_null: "tested, no interpretable result → 'Unknown'"}
units: n/a
depends_on: [INDEX]
output: {physical_name: brcac, target_published_name: BRCAC, name_status: undecided, type: string, nullable: false, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "two results on/prior to index, the latest 'No BRCA Mutation' → BRCAC='Wild type'; same-date Mutated+Wild type → BRCAC='Unknown'"
notes: "The Variable label cell reads 'PDL1 Status - Closest', a stray other-biomarker template label — format finding CL-B-VARCELL-MISLABEL; the row's variable_id BRCAC and its rules are otherwise legible, so drafted. Row carries a [verify] marker. Table t_&cohort_enh_ovbiomarkers_&date."
```

#### BRCACN

```yaml
variable_id: BRCACN
spec_refs: [clinical:36]
spec_digest: 2cc7f4fef05e
required_rule: Numeric code for BRCAC — 1=Mutated, 2=Wild type, 3=Unknown, 4=None (else 4).
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "on or prior to index (closest-to-index)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of BRCAC: Mutated→1, Wild type→2, Unknown→3, else→4."
cohort_applicability: all cohorts
missing: {no_record: "BRCAC='None' → 4", present_null: "BRCAC='Unknown' → 3"}
units: n/a
depends_on: [BRCAC]
output: {physical_name: brcacn, target_published_name: BRCACN, name_status: undecided, type: integer, nullable: false, codes: "1=Mutated;2=Wild type;3=Unknown;4=None", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "BRCAC='Mutated' → BRCACN=1"
notes: "Numeric mirror of BRCAC; code list fully stated. Row carries a [verify] marker."
```

#### BRCACDT

```yaml
variable_id: BRCACDT
spec_refs: [clinical:37]
spec_digest: 4d9773d10a75
required_rule: Date associated with BRCAC — the date of the closest-to-index record chosen for BRCAC, computed as max(SpecimenReceivedDate, ResultDate).
source: {kind: vendor, inputs: {biomarkers: {specimen_received_date: SpecimenReceivedDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "on or prior to index (closest-to-index)"
record_selection: "the record selected for BRCAC (closest to index)"
tie_break: {equidistant: "resolves with BRCAC's same-date tie-break", same_day: n/a}
derivation: "date = max(SpecimenReceivedDate, ResultDate) of the record chosen for BRCAC; status missing → date missing."
cohort_applicability: all cohorts
missing: {no_record: "no BRCAC record → date null", present_null: "BRCAC status missing → date null"}
units: date
depends_on: [BRCAC]
output: {physical_name: brcacdt, target_published_name: BRCACDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "BRCAC selected from the 2020-05-20 record → BRCACDT=2020-05-20"
notes: "Definition cell states only 'Date associated with BRCAC'; date rule taken from the source column note. Row carries a [verify] marker."
```

#### HRD

```yaml
variable_id: HRD
spec_refs: [clinical:38]
spec_digest: 713a1e25e10b
required_rule: HRD (homologous-recombination deficiency) status (character) — HRD positive, HRD negative, Unknown, None — by a time-agnostic ever-positive-wins hierarchy over the biomarker window, from Enhanced_OvarianBiomarkers where BiomarkerName='HRD'.
source: {kind: vendor, inputs: {biomarkers: {biomarker_name: BiomarkerName, biomarker_status: BiomarkerStatus}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "biomarker window — 'on or prior to index' per status text vs PRE_BIO (index+14d) per data-prep (BLOCKED: CL-B-BIO-WINDOW)"
record_selection: "time-agnostic 'ever' over the biomarker window; ever-Positive wins over Negative"
tie_break: {equidistant: n/a, same_day: "Positive beats Negative (ever-positive-wins)"}
derivation: "map delivered BiomarkerStatus per the adhoc map (Positive→Positive; Negative→Negative; Unsuccessful-indeterminate / Results pending / Unknown → Unknown), then: ever Positive → HRD positive; else ever Negative → HRD negative; else tested-no-result → Unknown; else (absent) → None."
cohort_applicability: all cohorts
missing: {no_record: "patient absent from Enhanced_OvarianBiomarkers → 'None'", present_null: "tested, no interpretable result → 'Unknown'"}
units: n/a
depends_on: [INDEX]
output: {physical_name: hrd, target_published_name: HRD, name_status: undecided, type: string, nullable: false, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-B-BIO-WINDOW]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "patient with any 'Positive' HRD result on/prior to index → HRD='HRD positive'; patient absent → HRD='None'"
notes: "Table t_&cohort_enh_ovbiomarkers_&date. Row carries a [verify] marker. Window contradiction recorded as finding CL-B-BIO-WINDOW-CONTRA and blocked on decision CL-B-BIO-WINDOW."
```

#### HRDN

```yaml
variable_id: HRDN
spec_refs: [clinical:39]
spec_digest: ed32ee8d14d5
required_rule: Numeric code for HRD — 1=Positive, 2=Negative, 3=Unknown (tested-no-result), 4=None (never tested).
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "same biomarker window as HRD (BLOCKED upstream: CL-B-BIO-WINDOW)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of HRD: HRD positive→1, HRD negative→2, Unknown→3, None→4."
cohort_applicability: all cohorts
missing: {no_record: "HRD='None' → 4", present_null: "HRD='Unknown' → 3"}
units: n/a
depends_on: [HRD]
output: {physical_name: hrdn, target_published_name: HRDN, name_status: undecided, type: integer, nullable: false, codes: "1=Positive;2=Negative;3=Unknown;4=None", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "HRD='HRD negative' → HRDN=2"
notes: "Numeric mirror of HRD; code list fully stated. Underlying status subject to CL-B-BIO-WINDOW. Row carries a [verify] marker."
```

#### HRDDT

```yaml
variable_id: HRDDT
spec_refs: [clinical:40]
spec_digest: c280c369b0cd
required_rule: HRD biomarker date — the result date closest to (on/prior to) index for the HRD record, computed as max(SpecimenReceivedDate, ResultDate); missing when the status is missing.
source: {kind: vendor, inputs: {biomarkers: {specimen_received_date: SpecimenReceivedDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "on or prior to index"
record_selection: "the HRD record closest to index (on/prior); test date = max(SpecimenReceivedDate, ResultDate)"
tie_break: {equidistant: "not specified for two equidistant HRD records", same_day: n/a}
derivation: "test date = max(SpecimenReceivedDate, ResultDate); take the record closest to index backing HRD; status missing → date missing."
cohort_applicability: all cohorts
missing: {no_record: "no HRD record → date null", present_null: "HRD status missing → date null"}
units: date
depends_on: [INDEX, HRD]
output: {physical_name: hrddt, target_published_name: HRDDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "single HRD result with SpecimenReceivedDate=2019-11-01, ResultDate=2019-11-08 → HRDDT=2019-11-08"
notes: "Row carries a [verify] marker. Table t_&cohort_enh_ovbiomarkers_&date."
```

#### HRDC

```yaml
variable_id: HRDC
spec_refs: [clinical:41]
spec_digest: 2a9eb0a6638d
required_rule: HRD status closest to index (character) — HRd (positive), HRp (negative), Unknown, None — using the record closest to (on/prior to) index, with stated same-date tie-breaks.
source: {kind: vendor, inputs: {biomarkers: {biomarker_name: BiomarkerName, biomarker_status: BiomarkerStatus, specimen_received_date: SpecimenReceivedDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "on or prior to index (closest-to-index selection)"
record_selection: "among records on/prior to index take the one closest to index; ties per tie_break"
tie_break: {equidistant: n/a, same_day: "HRd+HRp → Unknown; HRd+HRp+Unk → Unknown; HRd+Unk → HRd; HRp+Unk → HRp"}
derivation: "map BiomarkerStatus as for HRD; take result closest to index (test date = max(SpecimenReceivedDate, ResultDate)); apply same-date tie-breaks above; no test → None."
cohort_applicability: all cohorts
missing: {no_record: "patient absent → 'None'", present_null: "tested, no interpretable result → 'Unknown'"}
units: n/a
depends_on: [INDEX]
output: {physical_name: hrdc, target_published_name: HRDC, name_status: undecided, type: string, nullable: false, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "latest on/prior result 'Positive' → HRDC='HRd'; same-date HRd+HRp → HRDC='Unknown'"
notes: "Labels HRd/HRp are the closest-variant spellings of positive/negative. Row carries a [verify] marker. Same-date three-way (HRd+HRp+Unk) → Unknown, consistent with GISC/FOLR1C. Table t_&cohort_enh_ovbiomarkers_&date."
```

#### HRDCN

```yaml
variable_id: HRDCN
spec_refs: [clinical:42]
spec_digest: b9f4d4079cd0
required_rule: Numeric code for HRDC — 1=HRd (positive), 2=HRp (negative), 3=Unknown, 4=None.
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "on or prior to index (closest-to-index)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of HRDC: HRd→1, HRp→2, Unknown→3, None→4."
cohort_applicability: all cohorts
missing: {no_record: "HRDC='None' → 4", present_null: "HRDC='Unknown' → 3"}
units: n/a
depends_on: [HRDC]
output: {physical_name: hrdcn, target_published_name: HRDCN, name_status: undecided, type: integer, nullable: false, codes: "1=HRd;2=HRp;3=Unknown;4=None", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "HRDC='HRd' → HRDCN=1"
notes: "Numeric mirror of HRDC; code list fully stated. Row carries a [verify] marker."
```

#### HRDCDT

```yaml
variable_id: HRDCDT
spec_refs: [clinical:43]
spec_digest: 461f54683515
required_rule: Date associated with HRDC — the date of the closest-to-index record chosen for HRDC, computed as max(SpecimenReceivedDate, ResultDate).
source: {kind: vendor, inputs: {biomarkers: {specimen_received_date: SpecimenReceivedDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "on or prior to index (closest-to-index)"
record_selection: "the record selected for HRDC (closest to index)"
tie_break: {equidistant: "resolves with HRDC's same-date tie-break", same_day: n/a}
derivation: "date = max(SpecimenReceivedDate, ResultDate) of the record chosen for HRDC; status missing → date missing."
cohort_applicability: all cohorts
missing: {no_record: "no HRDC record → date null", present_null: "HRDC status missing → date null"}
units: date
depends_on: [HRDC]
output: {physical_name: hrdcdt, target_published_name: HRDCDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "HRDC selected from the 2021-02-10 record → HRDCDT=2021-02-10"
notes: "Definition cell states only 'Date associated with HRDC'; date rule from the source column note. Row carries a [verify] marker."
```

#### GIS

```yaml
variable_id: GIS
spec_refs: [clinical:44]
spec_digest: 4bb9302f9525
required_rule: GIS (genomic instability score) status (character) — Positive, Negative, Unknown, None — by a time-agnostic ever-positive-wins hierarchy over the biomarker window, from Enhanced_OvarianBiomarkers where BiomarkerName='GIS'.
source: {kind: vendor, inputs: {biomarkers: {biomarker_name: BiomarkerName, biomarker_status: BiomarkerStatus}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "biomarker window — 'on or prior to index' per status text vs PRE_BIO (index+14d) per data-prep (BLOCKED: CL-B-BIO-WINDOW)"
record_selection: "time-agnostic 'ever' over the biomarker window; ever-Positive wins over Negative"
tie_break: {equidistant: n/a, same_day: "Positive beats Negative (ever-positive-wins)"}
derivation: "map delivered BiomarkerStatus per the adhoc map (Positive→Positive; Negative→Negative; Unsuccessful-indeterminate → Unknown), then: ever Positive → Positive; else ever Negative → Negative; else tested-no-result → Unknown; else (absent) → None."
cohort_applicability: all cohorts
missing: {no_record: "patient absent from Enhanced_OvarianBiomarkers → 'None'", present_null: "tested, no interpretable result → 'Unknown'"}
units: n/a
depends_on: [INDEX]
output: {physical_name: gis, target_published_name: GIS, name_status: undecided, type: string, nullable: false, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-B-BIO-WINDOW]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "patient with any 'Positive' GIS result on/prior to index → GIS='Positive'; patient absent → GIS='None'"
notes: "GIS is delivered by the vendor as a categorical BiomarkerStatus (Positive/Negative), not as a raw numeric genomic-instability score — the spec applies no numeric cutoff, so no score-threshold decision is raised. Row carries a [verify] marker. Window contradiction recorded as finding CL-B-BIO-WINDOW-CONTRA, blocked on decision CL-B-BIO-WINDOW. Table t_&cohort_enh_ovbiomarkers_&date."
```

#### GISN

```yaml
variable_id: GISN
spec_refs: [clinical:45]
spec_digest: f2db7670f0d0
required_rule: Numeric code for GIS — 1=Positive, 2=Negative, 3=Unknown, 4=None.
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "same biomarker window as GIS (BLOCKED upstream: CL-B-BIO-WINDOW)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of GIS: Positive→1, Negative→2, Unknown→3, None→4."
cohort_applicability: all cohorts
missing: {no_record: "GIS='None' → 4", present_null: "GIS='Unknown' → 3"}
units: n/a
depends_on: [GIS]
output: {physical_name: gisn, target_published_name: GISN, name_status: undecided, type: integer, nullable: false, codes: "1=Positive;2=Negative;3=Unknown;4=None", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "GIS='Positive' → GISN=1"
notes: "Numeric mirror of GIS; code list fully stated. Underlying status subject to CL-B-BIO-WINDOW. Row carries a [verify] marker."
```

#### GISDT

```yaml
variable_id: GISDT
spec_refs: [clinical:46]
spec_digest: afd2cd1b82ec
required_rule: GIS biomarker date — the result date closest to (on/prior to) index for the GIS record, computed as max(SpecimenReceivedDate, ResultDate); missing when the status is missing.
source: {kind: vendor, inputs: {biomarkers: {specimen_received_date: SpecimenReceivedDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "on or prior to index"
record_selection: "the GIS record closest to index (on/prior); test date = max(SpecimenReceivedDate, ResultDate)"
tie_break: {equidistant: "not specified for two equidistant GIS records", same_day: n/a}
derivation: "test date = max(SpecimenReceivedDate, ResultDate); take the record closest to index backing GIS; status missing → date missing."
cohort_applicability: all cohorts
missing: {no_record: "no GIS record → date null", present_null: "GIS status missing → date null"}
units: date
depends_on: [INDEX, GIS]
output: {physical_name: gisdt, target_published_name: GISDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "single GIS result with SpecimenReceivedDate=2020-08-01, ResultDate=2020-08-04 → GISDT=2020-08-04"
notes: "Formula-bar note 'Date corresponds to GIS var'. Row carries a [verify] marker. Table t_&cohort_enh_ovbiomarkers_&date."
```

#### GISC

```yaml
variable_id: GISC
spec_refs: [clinical:47]
spec_digest: d61eb564499a
required_rule: GIS status closest to index (character) — Positive, Negative, Unknown, None — using the record closest to (on/prior to) index, with stated same-date tie-breaks.
source: {kind: vendor, inputs: {biomarkers: {biomarker_name: BiomarkerName, biomarker_status: BiomarkerStatus, specimen_received_date: SpecimenReceivedDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "on or prior to index (closest-to-index selection)"
record_selection: "rename BiomarkerStatus per the Biomarker_Status tab, then report the result closest to index; ties per tie_break"
tie_break: {equidistant: n/a, same_day: "Positive+Negative → Unknown; Positive+Negative+Unknown → Unknown; Positive+Unknown → Positive; Negative+Unknown → Negative"}
derivation: "among records on/prior to index take the one closest to index (test date = max(SpecimenReceivedDate, ResultDate)); apply same-date tie-breaks above; absent → None."
cohort_applicability: all cohorts
missing: {no_record: "patient absent → 'None'", present_null: "tested, no interpretable result → 'Unknown'"}
units: n/a
depends_on: [INDEX]
output: {physical_name: gisc, target_published_name: GISC, name_status: undecided, type: string, nullable: false, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "latest on/prior result 'Negative' → GISC='Negative'; same-date Positive+Negative → GISC='Unknown'"
notes: "The Variable label cell reads 'NTRK Status - Closest', a stray other-biomarker template label — format finding CL-B-VARCELL-MISLABEL; variable_id GISC and its rules are otherwise legible, so drafted. The [Tutorial] reference is to Flatiron's 'Assigning Patient-Level Biomarker Status' (closest-to-index wins), a documentation pointer, not a gap. Row carries a [verify] marker."
```

#### GISCN

```yaml
variable_id: GISCN
spec_refs: [clinical:48]
spec_digest: 45e1881b1713
required_rule: Numeric code for GISC — 1=Positive, 2=Negative, 3=Unknown, 4=None.
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "on or prior to index (closest-to-index)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of GISC: Positive→1, Negative→2, Unknown→3, None→4."
cohort_applicability: all cohorts
missing: {no_record: "GISC='None' → 4", present_null: "GISC='Unknown' → 3"}
units: n/a
depends_on: [GISC]
output: {physical_name: giscn, target_published_name: GISCN, name_status: undecided, type: integer, nullable: false, codes: "1=Positive;2=Negative;3=Unknown;4=None", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "GISC='Positive' → GISCN=1"
notes: "Numeric mirror of GISC; code list fully stated. Row carries a [verify] marker."
```

#### GISCDT

```yaml
variable_id: GISCDT
spec_refs: [clinical:49]
spec_digest: b350bcbc6a25
required_rule: Date associated with GISC — the date of the closest-to-index record chosen for GISC, computed as max(SpecimenReceivedDate, ResultDate).
source: {kind: vendor, inputs: {biomarkers: {specimen_received_date: SpecimenReceivedDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "on or prior to index (closest-to-index)"
record_selection: "the record selected for GISC (closest to index)"
tie_break: {equidistant: "resolves with GISC's same-date tie-break", same_day: n/a}
derivation: "date = max(SpecimenReceivedDate, ResultDate) of the record chosen for GISC; status missing → date missing."
cohort_applicability: all cohorts
missing: {no_record: "no GISC record → date null", present_null: "GISC status missing → date null"}
units: date
depends_on: [GISC]
output: {physical_name: giscdt, target_published_name: GISCDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "GISC selected from the 2020-08-04 record → GISCDT=2020-08-04"
notes: "The Variable label cell reads 'NTRK Status - Closest', a stray other-biomarker template label — format finding CL-B-VARCELL-MISLABEL. Definition cell states only 'Date associated with GISC'. Row carries a [verify] marker."
```

#### FOLR1

```yaml
variable_id: FOLR1
spec_refs: [clinical:50]
spec_digest: 363fdca9fcd5
required_rule: FOLR1/FRalpha (folate receptor alpha) status (character) — Positive, Negative, Unknown, None — by a time-agnostic ever-positive-wins hierarchy over the biomarker window, from Enhanced_OvarianBiomarkers where BiomarkerName='FOLR1/FRalpha'.
source: {kind: vendor, inputs: {biomarkers: {biomarker_name: BiomarkerName, biomarker_status: BiomarkerStatus}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "biomarker window — 'on or prior to index' per status text vs PRE_BIO (index+14d) per data-prep (BLOCKED: CL-B-BIO-WINDOW)"
record_selection: "time-agnostic 'ever' over the biomarker window; ever-Positive wins over Negative"
tie_break: {equidistant: n/a, same_day: "Positive beats Negative (ever-positive-wins)"}
derivation: "map delivered BiomarkerStatus per the adhoc map (Positive→Positive; Negative→Negative; Unsuccessful-indeterminate / Results pending / Equivocal / Unknown → Unknown), then: ever Positive → 1; else ever Negative → 2; else tested-no-result → 3; else (absent) → 4."
cohort_applicability: all cohorts
missing: {no_record: "patient absent from Enhanced_OvarianBiomarkers → 'None'", present_null: "tested, no interpretable result → 'Unknown'"}
units: n/a
depends_on: [INDEX]
output: {physical_name: folr1, target_published_name: FOLR1, name_status: undecided, type: string, nullable: false, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-B-BIO-WINDOW]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "patient with any 'Positive' FOLR1/FRalpha result on/prior to index → FOLR1='Positive'; patient absent → FOLR1='None'"
notes: "Source variable FOLR1FR, BiomarkerName 'FOLR1/FRalpha'. NH-vars note that a companion FOLR1FR variant combines codes 3 & 4 into 'Unknown or untested'; the primary FOLR1 keeps four distinct codes as listed, so that collapsed variant is noted, not asserted here. Window contradiction recorded as finding CL-B-BIO-WINDOW-CONTRA, blocked on decision CL-B-BIO-WINDOW. Row carries a [verify] marker. Table t_&cohort_enh_ovbiomarkers_&date."
```

#### FOLR1N

```yaml
variable_id: FOLR1N
spec_refs: [clinical:51]
spec_digest: 48623faef014
required_rule: Numeric code for FOLR1 — 1=Positive, 2=Negative, 3=Unknown, 4=None.
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "same biomarker window as FOLR1 (BLOCKED upstream: CL-B-BIO-WINDOW)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of FOLR1: Positive→1, Negative→2, Unknown→3, None→4."
cohort_applicability: all cohorts
missing: {no_record: "FOLR1='None' → 4", present_null: "FOLR1='Unknown' → 3"}
units: n/a
depends_on: [FOLR1]
output: {physical_name: folr1n, target_published_name: FOLR1N, name_status: undecided, type: integer, nullable: false, codes: "1=Positive;2=Negative;3=Unknown;4=None", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "FOLR1='Positive' → FOLR1N=1"
notes: "Source variable FOLR1FRN. Numeric mirror of FOLR1; code list fully stated. Underlying status subject to CL-B-BIO-WINDOW. Row carries a [verify] marker."
```

#### FOLR1DT

```yaml
variable_id: FOLR1DT
spec_refs: [clinical:52]
spec_digest: 55cd91c2d02e
required_rule: FOLR1/FRalpha biomarker date — the result date closest to (on/prior to) index for the FOLR1 record, computed as max(SpecimenReceivedDate, ResultDate); missing when the status is missing.
source: {kind: vendor, inputs: {biomarkers: {specimen_received_date: SpecimenReceivedDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "on or prior to index"
record_selection: "the FOLR1 record closest to index (on/prior); test date = max(SpecimenReceivedDate, ResultDate)"
tie_break: {equidistant: "not specified for two equidistant FOLR1 records", same_day: n/a}
derivation: "test date = max(SpecimenReceivedDate, ResultDate); take the record closest to index backing FOLR1; status missing → date missing."
cohort_applicability: all cohorts
missing: {no_record: "no FOLR1 record → date null", present_null: "FOLR1 status missing → date null"}
units: date
depends_on: [INDEX, FOLR1]
output: {physical_name: folr1dt, target_published_name: FOLR1DT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "single FOLR1 result with SpecimenReceivedDate=2021-06-01, ResultDate=2021-06-09 → FOLR1DT=2021-06-09"
notes: "Source variable FOLR1FRDT. Row carries a [verify] marker. Table t_&cohort_enh_ovbiomarkers_&date."
```

#### FOLR1C

```yaml
variable_id: FOLR1C
spec_refs: [clinical:53]
spec_digest: 7e77ab45e68e
required_rule: FOLR1/FRalpha status closest to index (character) — Positive, Negative, Unknown, None — using the record closest to (on/prior to) index, with the same same-date tie-break pattern as GISC.
source: {kind: vendor, inputs: {biomarkers: {biomarker_name: BiomarkerName, biomarker_status: BiomarkerStatus, specimen_received_date: SpecimenReceivedDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "on or prior to index (closest-to-index selection)"
record_selection: "report the result closest to index; ties per tie_break"
tie_break: {equidistant: n/a, same_day: "Positive+Negative → Unknown; Positive+Unknown → Positive; Negative+Unknown → Negative"}
derivation: "among records on/prior to index take the one closest to index (test date = max(SpecimenReceivedDate, ResultDate)); apply same-date tie-breaks above (as GISC); absent → None."
cohort_applicability: all cohorts
missing: {no_record: "patient absent → 'None'", present_null: "tested, no interpretable result → 'Unknown'"}
units: n/a
depends_on: [INDEX]
output: {physical_name: folr1c, target_published_name: FOLR1C, name_status: undecided, type: string, nullable: false, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "latest on/prior result 'Positive' → FOLR1C='Positive'; same-date Positive+Negative → FOLR1C='Unknown'"
notes: "Source variable FOLR1FRC. The Variable label cell reads 'NTRK', a stray other-biomarker template label — format finding CL-B-VARCELL-MISLABEL; variable_id FOLR1C and its rules are otherwise legible, so drafted. Row carries a [verify] marker."
```

#### FOLR1CN

```yaml
variable_id: FOLR1CN
spec_refs: [clinical:54]
spec_digest: 0828843f7f77
required_rule: Numeric code for FOLR1C — 1=Positive, 2=Negative, 3=Unknown, 4=None.
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "on or prior to index (closest-to-index)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of FOLR1C: Positive→1, Negative→2, Unknown→3, None→4."
cohort_applicability: all cohorts
missing: {no_record: "FOLR1C='None' → 4", present_null: "FOLR1C='Unknown' → 3"}
units: n/a
depends_on: [FOLR1C]
output: {physical_name: folr1cn, target_published_name: FOLR1CN, name_status: undecided, type: integer, nullable: false, codes: "1=Positive;2=Negative;3=Unknown;4=None", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "FOLR1C='Positive' → FOLR1CN=1"
notes: "Source variable FOLR1FRCN. Numeric mirror of FOLR1C; code list fully stated. Row carries a [verify] marker."
```

#### FOLR1CDT

```yaml
variable_id: FOLR1CDT
spec_refs: [clinical:55]
spec_digest: 62a50e51b9e1
required_rule: Date associated with FOLR1C — the date of the closest-to-index record chosen for FOLR1C, computed as max(SpecimenReceivedDate, ResultDate).
source: {kind: vendor, inputs: {biomarkers: {specimen_received_date: SpecimenReceivedDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "on or prior to index (closest-to-index)"
record_selection: "the record selected for FOLR1C (closest to index)"
tie_break: {equidistant: "resolves with FOLR1C's same-date tie-break", same_day: n/a}
derivation: "date = max(SpecimenReceivedDate, ResultDate) of the record chosen for FOLR1C; status missing → date missing."
cohort_applicability: all cohorts
missing: {no_record: "no FOLR1C record → date null", present_null: "FOLR1C status missing → date null"}
units: date
depends_on: [FOLR1C]
output: {physical_name: folr1cdt, target_published_name: FOLR1CDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "FOLR1C selected from the 2021-06-09 record → FOLR1CDT=2021-06-09"
notes: "Source variable FOLR1FRCDT. The Variable label cell reads 'NTRK', a stray other-biomarker template label — format finding CL-B-VARCELL-MISLABEL. Definition cell states only 'Date associated with FOLR1C'. Row carries a [verify] marker."
```

#### HRDFL

```yaml
variable_id: HRDFL
spec_refs: [clinical:56]
spec_digest: aa275b7c366f
required_rule: BRCA-mutated-or-(BRCAwt-with-HRd) subgroup flag (HRd_subgrp_fl) — 1 if BRCA=1 OR (BRCA=2 AND HRD=1), else 0.
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "inherits BRCA/HRD biomarker window"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "if BRCAN=1 OR (BRCAN=2 AND HRDN=1) then 1 else 0."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "BRCA/HRD always resolve (incl None=4/Unknown=3) → flag computes to 0 when the positive condition is not met"}
units: n/a
depends_on: [BRCA, HRD]
output: {physical_name: hrdfl, target_published_name: HRDFL, name_status: undecided, type: integer, nullable: false, codes: "1=BRCAm or (BRCAwt+HRd);0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "BRCA='Wild type' (2) and HRD='HRD positive' (1) → HRDFL=1; BRCA='Wild type' and HRD='HRD negative' → HRDFL=0"
notes: "Source variable HRDFL / HRd_subgrp_fl. Rule has a terminal else (fully specified), so drafted. QC crosstab BRCA*HRD*BRCA_HRD noted in the spec. Row carries a [verify] marker. Uses the time-agnostic BRCA/HRD inputs."
```

#### HRPFL

```yaml
variable_id: HRPFL
spec_refs: [clinical:57]
spec_digest: f0106799962b
required_rule: HR-proficient & BRCAwt/HRD-unknown subgroup flag (HRp_unk_subgrp_fl) — 1 if (HRD=2 AND BRCA!=1) OR (HRD in (3,4) AND BRCA=2); 0 if BRCA=3; else 0.
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "inherits BRCA/HRD biomarker window"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "if BRCAN=3 then 0; else if (HRDN=2 AND BRCAN!=1) OR (HRDN in (3,4) AND BRCAN=2) then 1 else 0."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "BRCA/HRD always resolve (incl None/Unknown) → flag computes per rule"}
units: n/a
depends_on: [BRCA, HRD]
output: {physical_name: hrpfl, target_published_name: HRPFL, name_status: undecided, type: integer, nullable: false, codes: "1=HRp + BRCA/HRD unknown;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "BRCA='Wild type' (2) and HRD='HRD negative' (2) → HRPFL=1; BRCA='Unknown' (3) → HRPFL=0"
notes: "Source variable HRPFL / HRp_unk_subgrp_fl. The BRCA=3 → 0 override is stated explicitly; rule has a terminal else, so drafted. Row carries a [verify] marker."
```

#### UHRDBRCA

```yaml
variable_id: UHRDBRCA
spec_refs: [clinical:58]
spec_digest: a04de273d172
required_rule: Both BRCA and HRD unknown subgroup flag (HRD_BRCA_unk_subgrp_fl) — 1 if BRCA in (3,4) AND HRD in (3,4), else 0.
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "inherits BRCA/HRD biomarker window"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "if BRCAN in (3,4) AND HRDN in (3,4) then 1 else 0."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "BRCA/HRD always resolve (incl None/Unknown) → flag computes per rule"}
units: n/a
depends_on: [BRCA, HRD]
output: {physical_name: uhrdbrca, target_published_name: UHRDBRCA, name_status: undecided, type: integer, nullable: false, codes: "1=HRD BRCA unknown;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "BRCA='Unknown' (3) and HRD='None' (4) → UHRDBRCA=1; BRCA='Mutated' (1) → UHRDBRCA=0"
notes: "Source variable UHRDBRCA / HRD_BRCA_unk_subgrp_fl. Rule has a terminal else (fully specified), so drafted. Row carries a [verify] marker."
```

#### BRCAHRD

```yaml
variable_id: BRCAHRD
spec_refs: [clinical:59]
spec_digest: 1a6dc6b3085d
required_rule: BRCA/HRD composite (BRCA_HRD_composite) — Level 1 = HRDFL=1 (HRd = BRCAm or BRCAwt+HRd); Level 2 = HRPFL=1 (HRp + BRCAwt, excluding HRp&BRCAm); Level 0 (or 3) = UHRDBRCA=1 (BRCA and HRD unknown). Unknown-level code and the treatment of combinations matching none of the three flags are unresolved.
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "inherits BRCA/HRD biomarker window"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "HRDFL=1 → 1; HRPFL=1 → 2; UHRDBRCA=1 → 0 (or 3). Two open points: (a) the Values cell reads '3/0 = Unknown' but the definition assigns Level 0 = UHRDBRCA=1 — the unknown code is ambiguous; (b) a BRCA×HRD combination that satisfies none of HRDFL/HRPFL/UHRDBRCA (e.g. BRCA=Unknown with HRD=positive) is unassigned (BLOCKED: CL-B-BRCAHRD-CODE)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "combination in none of the three subgroup flags → composite undefined (BLOCKED: CL-B-BRCAHRD-CODE)"}
units: n/a
depends_on: [HRDFL, HRPFL, UHRDBRCA]
output: {physical_name: brcahrd, target_published_name: BRCAHRD, name_status: undecided, type: integer, nullable: true, codes: "1=HRd;2=HRp + BRCAwt;0/3=Unknown BRCA and HRD (BLOCKED: CL-B-BRCAHRD-CODE)", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-B-BRCAHRD-CODE]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fully written until the unknown-level code and unmatched-combination handling are decided (CL-B-BRCAHRD-CODE); e.g. HRDFL=1 → BRCAHRD=1"
notes: "Source variable brcahrd / BRCA_HRD_composite. Built from the three time-agnostic subgroup flags. Row carries a [verify] marker."
```

#### BRCAHRDC

```yaml
variable_id: BRCAHRDC
spec_refs: [clinical:60]
spec_digest: ace3d7eeda0c
required_rule: BRCA/HRD composite, closest-to-index (BRCA_HRD_composite closest) — same level definitions as BRCAHRD but computed from the closest-to-index BRCAC/HRDC inputs via closest-variant subgroup flags HRDFLC/HRPFLC/UHRDBRC. Unknown-level code and unmatched-combination handling unresolved.
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "on or prior to index (closest-to-index inputs)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "compute closest-variant subgroup flags from BRCAC/HRDC: HRDFLC = 1 if BRCAC=1 OR (BRCAC=2 AND HRDC=1); HRPFLC and UHRDBRC mirror HRPFL/UHRDBRCA on the closest inputs; then HRDFLC=1 → 1; HRPFLC=1 → 2; UHRDBRC=1 → 0 (or 3). Same two open points as BRCAHRD — unknown code and unmatched combinations (BLOCKED: CL-B-BRCAHRD-CODE)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "combination in none of the three closest subgroup flags → composite undefined (BLOCKED: CL-B-BRCAHRD-CODE)"}
units: n/a
depends_on: [BRCAC, HRDC]
output: {physical_name: brcahrdc, target_published_name: BRCAHRDC, name_status: undecided, type: integer, nullable: true, codes: "1=HRd;2=HRp + BRCAwt;0/3=Unknown BRCA and HRD (BLOCKED: CL-B-BRCAHRD-CODE)", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-B-BRCAHRD-CODE]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fully written until the unknown-level code and unmatched-combination handling are decided (CL-B-BRCAHRD-CODE); e.g. BRCAC=1 → HRDFLC=1 → BRCAHRDC=1"
notes: "Source variable brcahrdc / BRCA_HRD_composite (closest). The intermediate closest sub-flags HRDFLC/HRPFLC/UHRDBRC are described inline in this row and are not separate spec rows, so they are computed within this record rather than given their own records. Row carries a [verify] marker."
```


## clinical — CL-C

#### LABCA125

```yaml
variable_id: LABCA125
spec_refs: [clinical:61]
spec_digest: 0a4b5e83eba0
required_rule: "CA 125 Value Present tri-state: 'Present'/'Unknown'/'Missing' (numeric 1/2/3), for testbasename='cancer ag 125' (unit 'iU/L') over the lab eligibility window."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "'Present' if >=1 t_lab record with testbasename='cancer ag 125', testdate not missing, testresultcleansed>0 (not missing) and testunitscleansed='iU/L' within the window; else 'Unknown' if record(s) exist but none qualify; 'Missing' if no t_lab record. testdate=max(resultdate,testdate). Window and closest-direction BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record in t_lab -> 'Missing' (3)", present_null: "record(s) present but none meet criteria -> 'Unknown' (2)"}
units: n/a
depends_on: []
output: {physical_name: labca125, target_published_name: LABCA125, name_status: undecided, type: string, nullable: false, codes: "1=Present;2=Unknown;3=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "one t_lab record testbasename='cancer ag 125', testresultcleansed=250, testunitscleansed='iU/L', testdate present -> LABCA125='Present' (1); no t_lab record -> 'Missing' (3)"
notes: "Tri-state present flag with numeric mirror 1/2/3. testbasename/unit carry [verify] markers -- stand-in unconfirmed (CL-C-VERIFY-PANEL). Read from t_lab. Variable-name cell was misread as 'LAB_CA' (CL-C-VARCELL). Result/units column spelled both TestResultCleaned and testresultcleansed across the row (CL-C-CLEANSED-SPELLING, panel-wide)."
```

#### LABCA125V

```yaml
variable_id: LABCA125V
spec_refs: [clinical:62]
spec_digest: c71de746b4ce
required_rule: "CA 125 value (iU/L) closest to index date among records meeting the LABCA125 criteria; same-date tie-break -> highest."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "testresultcleansed of the record closest to index date meeting the LABCA125 criteria; equidistant (either side of index) tie BLOCKED (CL-C-LAB-SELECTION)"
tie_break: {equidistant: "BLOCKED (CL-C-LAB-SELECTION)", same_day: highest}
derivation: "take testresultcleansed of the closest-to-index qualifying record; same-date tie-break -> highest. Window and equidistant-tie BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no qualifying lab record -> LABCA125V null", present_null: n/a}
units: iU/L
depends_on: [LABCA125]
output: {physical_name: labca125v, target_published_name: LABCA125V, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "qualifying values 200 at index-30d and 250 at index-10d (iU/L) -> LABCA125V=250 (closest); two at index-10d -> highest"
notes: "Numeric value closest to index among records meeting the LABCA125 criteria. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABCA125VDT

```yaml
variable_id: LABCA125VDT
spec_refs: [clinical:63]
spec_digest: efb226167f59
required_rule: "CA 125 status date (iU/L) = max(resultdate, testdate) of the record selected for LABCA125V."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "date of the record selected for LABCA125V"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(resultdate, testdate) of the record chosen for LABCA125V; null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABCA125V -> date null", present_null: n/a}
units: date
depends_on: [LABCA125V]
output: {physical_name: labca125vdt, target_published_name: LABCA125VDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record resultdate=2020-05-20, testdate=2020-05-22 -> LABCA125VDT=2020-05-22"
notes: "Status date of the record chosen for LABCA125V. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABCA125VU

```yaml
variable_id: LABCA125VU
spec_refs: [clinical:64]
spec_digest: a10aff4484ad
required_rule: "CA 125 status unit (iU/L) = testunitscleansed of the record selected for LABCA125V (expected 'iU/L')."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_units: TestUnitsCleaned}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "unit of the record selected for LABCA125V"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "testunitscleansed of the record chosen for LABCA125V (expected 'iU/L'); null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABCA125V -> unit null", present_null: n/a}
units: n/a
depends_on: [LABCA125V]
output: {physical_name: labca125vu, target_published_name: LABCA125VU, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record testunitscleansed='iU/L' -> LABCA125VU='iU/L'"
notes: "Delivered unit of the record chosen for LABCA125V; the LABCA125 criteria already require testunitscleansed='iU/L'. [verify] marker (CL-C-VERIFY-PANEL)."
```

#### LABPLA

```yaml
variable_id: LABPLA
spec_refs: [clinical:65]
spec_digest: 1d44f85fbf04
required_rule: "Platelet Value Present tri-state: 'Present'/'Unknown'/'Missing' (numeric 1/2/3), for testbasename='platelets' (unit '10^9/L') over the lab eligibility window."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "'Present' if >=1 t_lab record with testbasename='platelets', testdate not missing, testresultcleansed>0 (not missing) and testunitscleansed='10^9/L' within the window; else 'Unknown' if record(s) exist but none qualify; 'Missing' if no t_lab record. testdate=max(resultdate,testdate). Window and closest-direction BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record in t_lab -> 'Missing' (3)", present_null: "record(s) present but none meet criteria -> 'Unknown' (2)"}
units: n/a
depends_on: []
output: {physical_name: labpla, target_published_name: LABPLA, name_status: undecided, type: string, nullable: false, codes: "1=Present;2=Unknown;3=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "one t_lab record testbasename='platelets', testresultcleansed=250, testunitscleansed='10^9/L', testdate present -> LABPLA='Present' (1); no t_lab record -> 'Missing' (3)"
notes: "Tri-state present flag with numeric mirror 1/2/3. testbasename/unit carry [verify] markers -- stand-in unconfirmed (CL-C-VERIFY-PANEL). Read from t_lab. Variable-name cell was misread as 'LAB_PLA' (CL-C-VARCELL)."
```

#### LABPLAV

```yaml
variable_id: LABPLAV
spec_refs: [clinical:66]
spec_digest: 510ef498b47b
required_rule: "Platelet value (10^9/L) closest to index date among records meeting the LABPLA criteria; same-date tie-break -> lowest."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "testresultcleansed of the record closest to index date meeting the LABPLA criteria; equidistant (either side of index) tie BLOCKED (CL-C-LAB-SELECTION)"
tie_break: {equidistant: "BLOCKED (CL-C-LAB-SELECTION)", same_day: lowest}
derivation: "take testresultcleansed of the closest-to-index qualifying record; same-date tie-break -> lowest. Window and equidistant-tie BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no qualifying lab record -> LABPLAV null", present_null: n/a}
units: 10^9/L
depends_on: [LABPLA]
output: {physical_name: labplav, target_published_name: LABPLAV, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "qualifying values 200 at index-30d and 250 at index-10d (10^9/L) -> LABPLAV=250 (closest); two at index-10d -> lowest"
notes: "Numeric value closest to index among records meeting the LABPLA criteria. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABPLAVDT

```yaml
variable_id: LABPLAVDT
spec_refs: [clinical:67]
spec_digest: 737032effc66
required_rule: "Platelet status date (10^9/L) = max(resultdate, testdate) of the record selected for LABPLAV."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "date of the record selected for LABPLAV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(resultdate, testdate) of the record chosen for LABPLAV; null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABPLAV -> date null", present_null: n/a}
units: date
depends_on: [LABPLAV]
output: {physical_name: labplavdt, target_published_name: LABPLAVDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record resultdate=2020-05-20, testdate=2020-05-22 -> LABPLAVDT=2020-05-22"
notes: "Status date of the record chosen for LABPLAV. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABPLAVU

```yaml
variable_id: LABPLAVU
spec_refs: [clinical:68]
spec_digest: e0b92e78ecad
required_rule: "Platelet status unit (10^9/L) = testunitscleansed of the record selected for LABPLAV (expected '10^9/L')."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_units: TestUnitsCleaned}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "unit of the record selected for LABPLAV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "testunitscleansed of the record chosen for LABPLAV (expected '10^9/L'); null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABPLAV -> unit null", present_null: n/a}
units: n/a
depends_on: [LABPLAV]
output: {physical_name: labplavu, target_published_name: LABPLAVU, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record testunitscleansed='10^9/L' -> LABPLAVU='10^9/L'"
notes: "Delivered unit of the record chosen for LABPLAV; the LABPLA criteria already require testunitscleansed='10^9/L'. [verify] marker (CL-C-VERIFY-PANEL)."
```

#### LABNEU

```yaml
variable_id: LABNEU
spec_refs: [clinical:69]
spec_digest: e0312bce86eb
required_rule: "Neutrophil Value Present tri-state: 'Present'/'Unknown'/'Missing' (numeric 1/2/3), for testbasename='neutrophils' (unit '10^9/L') over the lab eligibility window."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "'Present' if >=1 t_lab record with testbasename='neutrophils', testdate not missing, testresultcleansed>0 (not missing) and testunitscleansed='10^9/L' within the window; else 'Unknown' if record(s) exist but none qualify; 'Missing' if no t_lab record. testdate=max(resultdate,testdate). Window and closest-direction BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record in t_lab -> 'Missing' (3)", present_null: "record(s) present but none meet criteria -> 'Unknown' (2)"}
units: n/a
depends_on: []
output: {physical_name: labneu, target_published_name: LABNEU, name_status: undecided, type: string, nullable: false, codes: "1=Present;2=Unknown;3=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "one t_lab record testbasename='neutrophils', testresultcleansed=250, testunitscleansed='10^9/L', testdate present -> LABNEU='Present' (1); no t_lab record -> 'Missing' (3)"
notes: "Tri-state present flag with numeric mirror 1/2/3. testbasename/unit carry [verify] markers -- stand-in unconfirmed (CL-C-VERIFY-PANEL). Read from t_lab."
```

#### LABNEUV

```yaml
variable_id: LABNEUV
spec_refs: [clinical:70]
spec_digest: 7279530ce73b
required_rule: "Neutrophil value (10^9/L) closest to index date among records meeting the LABNEU criteria; same-date tie-break -> lowest."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "testresultcleansed of the record closest to index date meeting the LABNEU criteria; equidistant (either side of index) tie BLOCKED (CL-C-LAB-SELECTION)"
tie_break: {equidistant: "BLOCKED (CL-C-LAB-SELECTION)", same_day: lowest}
derivation: "take testresultcleansed of the closest-to-index qualifying record; same-date tie-break -> lowest. Window and equidistant-tie BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no qualifying lab record -> LABNEUV null", present_null: n/a}
units: 10^9/L
depends_on: [LABNEU]
output: {physical_name: labneuv, target_published_name: LABNEUV, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "qualifying values 200 at index-30d and 250 at index-10d (10^9/L) -> LABNEUV=250 (closest); two at index-10d -> lowest"
notes: "Numeric value closest to index among records meeting the LABNEU criteria. [verify] marker on the row (CL-C-VERIFY-PANEL). Same-date tie-break 'lowest' per the lab-pattern banner."
```

#### LABNEUVDT

```yaml
variable_id: LABNEUVDT
spec_refs: [clinical:71]
spec_digest: 27db92500b7c
required_rule: "Neutrophil status date (10^9/L) = max(resultdate, testdate) of the record selected for LABNEUV."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "date of the record selected for LABNEUV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(resultdate, testdate) of the record chosen for LABNEUV; null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABNEUV -> date null", present_null: n/a}
units: date
depends_on: [LABNEUV]
output: {physical_name: labneuvdt, target_published_name: LABNEUVDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record resultdate=2020-05-20, testdate=2020-05-22 -> LABNEUVDT=2020-05-22"
notes: "Status date of the record chosen for LABNEUV. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABNEUVU

```yaml
variable_id: LABNEUVU
spec_refs: [clinical:72]
spec_digest: 0a8803556500
required_rule: "Neutrophil status unit (10^9/L) = testunitscleansed of the record selected for LABNEUV (expected '10^9/L')."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_units: TestUnitsCleaned}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "unit of the record selected for LABNEUV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "testunitscleansed of the record chosen for LABNEUV (expected '10^9/L'); null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABNEUV -> unit null", present_null: n/a}
units: n/a
depends_on: [LABNEUV]
output: {physical_name: labneuvu, target_published_name: LABNEUVU, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record testunitscleansed='10^9/L' -> LABNEUVU='10^9/L'"
notes: "Delivered unit of the record chosen for LABNEUV; the LABNEU criteria already require testunitscleansed='10^9/L'. [verify] marker (CL-C-VERIFY-PANEL)."
```

#### LABHEM

```yaml
variable_id: LABHEM
spec_refs: [clinical:73]
spec_digest: ee16b1290b95
required_rule: "Hemoglobin Value Present tri-state: 'Present'/'Unknown'/'Missing' (numeric 1/2/3), for testbasename='hemoglobin' (unit 'g/dL') over the lab eligibility window."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "'Present' if >=1 t_lab record with testbasename='hemoglobin', testdate not missing, testresultcleansed>0 (not missing) and testunitscleansed='g/dL' within the window; else 'Unknown' if record(s) exist but none qualify; 'Missing' if no t_lab record. testdate=max(resultdate,testdate). Window and closest-direction BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record in t_lab -> 'Missing' (3)", present_null: "record(s) present but none meet criteria -> 'Unknown' (2)"}
units: n/a
depends_on: []
output: {physical_name: labhem, target_published_name: LABHEM, name_status: undecided, type: string, nullable: false, codes: "1=Present;2=Unknown;3=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "one t_lab record testbasename='hemoglobin', testresultcleansed=250, testunitscleansed='g/dL', testdate present -> LABHEM='Present' (1); no t_lab record -> 'Missing' (3)"
notes: "Tri-state present flag with numeric mirror 1/2/3. testbasename/unit carry [verify] markers -- stand-in unconfirmed (CL-C-VERIFY-PANEL). Read from t_lab."
```

#### LABHEMV

```yaml
variable_id: LABHEMV
spec_refs: [clinical:74]
spec_digest: 1f3a79d7a9ac
required_rule: "Hemoglobin value (g/dL) closest to index date among records meeting the LABHEM criteria; same-date tie-break -> lowest."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "testresultcleansed of the record closest to index date meeting the LABHEM criteria; equidistant (either side of index) tie BLOCKED (CL-C-LAB-SELECTION)"
tie_break: {equidistant: "BLOCKED (CL-C-LAB-SELECTION)", same_day: lowest}
derivation: "take testresultcleansed of the closest-to-index qualifying record; same-date tie-break -> lowest. Window and equidistant-tie BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no qualifying lab record -> LABHEMV null", present_null: n/a}
units: g/dL
depends_on: [LABHEM]
output: {physical_name: labhemv, target_published_name: LABHEMV, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "qualifying values 200 at index-30d and 250 at index-10d (g/dL) -> LABHEMV=250 (closest); two at index-10d -> lowest"
notes: "Numeric value closest to index among records meeting the LABHEM criteria. [verify] marker on the row (CL-C-VERIFY-PANEL). Same-date tie-break 'lowest' taken from the lab-pattern banner (row flags it not explicit for HEM)."
```

#### LABHEMVDT

```yaml
variable_id: LABHEMVDT
spec_refs: [clinical:75]
spec_digest: b580eb9eccdc
required_rule: "Hemoglobin status date (g/dL) = max(resultdate, testdate) of the record selected for LABHEMV."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "date of the record selected for LABHEMV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(resultdate, testdate) of the record chosen for LABHEMV; null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABHEMV -> date null", present_null: n/a}
units: date
depends_on: [LABHEMV]
output: {physical_name: labhemvdt, target_published_name: LABHEMVDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record resultdate=2020-05-20, testdate=2020-05-22 -> LABHEMVDT=2020-05-22"
notes: "Status date of the record chosen for LABHEMV. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABHEMVU

```yaml
variable_id: LABHEMVU
spec_refs: [clinical:76]
spec_digest: ba2030e58914
required_rule: "Hemoglobin status unit (g/dL) = testunitscleansed of the record selected for LABHEMV (expected 'g/dL')."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_units: TestUnitsCleaned}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "unit of the record selected for LABHEMV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "testunitscleansed of the record chosen for LABHEMV (expected 'g/dL'); null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABHEMV -> unit null", present_null: n/a}
units: n/a
depends_on: [LABHEMV]
output: {physical_name: labhemvu, target_published_name: LABHEMVU, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record testunitscleansed='g/dL' -> LABHEMVU='g/dL'"
notes: "Delivered unit of the record chosen for LABHEMV; the LABHEM criteria already require testunitscleansed='g/dL'. [verify] marker (CL-C-VERIFY-PANEL)."
```

#### LABCRE

```yaml
variable_id: LABCRE
spec_refs: [clinical:77]
spec_digest: 159c68e941c6
required_rule: "Creatinine Value Present tri-state: 'Present'/'Unknown'/'Missing' (numeric 1/2/3), for testbasename='creatinine' (unit 'mg/dL') over the lab eligibility window."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate, lab_component: LabComponent}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "'Present' if >=1 t_lab record with testbasename='creatinine' AND an additional labcomponent filter whose value is unstated (BLOCKED: CL-C-CRE-LABCOMPONENT), testdate not missing, testresultcleansed>0 (not missing) and testunitscleansed='mg/dL' within the window; else 'Unknown' if record(s) exist but none qualify; 'Missing' if no t_lab record. testdate=max(resultdate,testdate). Window and closest-direction BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record in t_lab -> 'Missing' (3)", present_null: "record(s) present but none meet criteria -> 'Unknown' (2)"}
units: n/a
depends_on: []
output: {physical_name: labcre, target_published_name: LABCRE, name_status: undecided, type: string, nullable: false, codes: "1=Present;2=Unknown;3=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION, CL-C-CRE-LABCOMPONENT]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "one t_lab record testbasename='creatinine', testresultcleansed=250, testunitscleansed='mg/dL', testdate present -> LABCRE='Present' (1); no t_lab record -> 'Missing' (3)"
notes: "Tri-state present flag with numeric mirror 1/2/3. testbasename/unit carry [verify] markers -- stand-in unconfirmed (CL-C-VERIFY-PANEL). Read from t_lab. Creatinine adds an unstated labcomponent filter (CL-C-CRE-LABCOMPONENT)."
```

#### LABCREV

```yaml
variable_id: LABCREV
spec_refs: [clinical:78]
spec_digest: 1ab5fe7d42dc
required_rule: "Creatinine value (mg/dL) closest to index date among records meeting the LABCRE criteria; same-date tie-break -> unstated."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate, lab_component: LabComponent}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "testresultcleansed of the record closest to index date meeting the LABCRE criteria; equidistant (either side of index) tie BLOCKED (CL-C-LAB-SELECTION)"
tie_break: {equidistant: "BLOCKED (CL-C-LAB-SELECTION)", same_day: "per tie-break -- NOT stated for creatinine (BLOCKED: CL-C-CRE-TIEBREAK)"}
derivation: "take testresultcleansed of the closest-to-index qualifying record; same-date tie-break NOT stated (BLOCKED: CL-C-CRE-TIEBREAK). Window and equidistant-tie BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no qualifying lab record -> LABCREV null", present_null: n/a}
units: mg/dL
depends_on: [LABCRE]
output: {physical_name: labcrev, target_published_name: LABCREV, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION, CL-C-CRE-TIEBREAK, CL-C-CRE-LABCOMPONENT]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "qualifying values 200 at index-30d and 250 at index-10d (mg/dL) -> LABCREV=250 (closest); two at index-10d -> tie-break BLOCKED"
notes: "Numeric value closest to index among records meeting the LABCRE criteria. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABCREVDT

```yaml
variable_id: LABCREVDT
spec_refs: [clinical:79]
spec_digest: 703ce7128a0b
required_rule: "Creatinine status date (mg/dL) = max(resultdate, testdate) of the record selected for LABCREV."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "date of the record selected for LABCREV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(resultdate, testdate) of the record chosen for LABCREV; null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABCREV -> date null", present_null: n/a}
units: date
depends_on: [LABCREV]
output: {physical_name: labcrevdt, target_published_name: LABCREVDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION, CL-C-CRE-LABCOMPONENT]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record resultdate=2020-05-20, testdate=2020-05-22 -> LABCREVDT=2020-05-22"
notes: "Status date of the record chosen for LABCREV. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABCREVU

```yaml
variable_id: LABCREVU
spec_refs: [clinical:80]
spec_digest: a938db835eae
required_rule: "Creatinine status unit (mg/dL) = testunitscleansed of the record selected for LABCREV (expected 'mg/dL')."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_units: TestUnitsCleaned}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "unit of the record selected for LABCREV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "testunitscleansed of the record chosen for LABCREV (expected 'mg/dL'); null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABCREV -> unit null", present_null: n/a}
units: n/a
depends_on: [LABCREV]
output: {physical_name: labcrevu, target_published_name: LABCREVU, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION, CL-C-CRE-LABCOMPONENT]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record testunitscleansed='mg/dL' -> LABCREVU='mg/dL'"
notes: "Delivered unit of the record chosen for LABCREV; the LABCRE criteria already require testunitscleansed='mg/dL'. [verify] marker (CL-C-VERIFY-PANEL)."
```

#### LABBIL

```yaml
variable_id: LABBIL
spec_refs: [clinical:81]
spec_digest: 7d5eebc779d5
required_rule: "Bilirubin Value Present tri-state: 'Present'/'Unknown'/'Missing' (numeric 1/2/3), for testbasename='bilirubin' (unit 'mg/dL') over the lab eligibility window."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "'Present' if >=1 t_lab record with testbasename='bilirubin', testdate not missing, testresultcleansed>0 (not missing) and testunitscleansed='mg/dL' within the window; else 'Unknown' if record(s) exist but none qualify; 'Missing' if no t_lab record. testdate=max(resultdate,testdate). Window and closest-direction BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record in t_lab -> 'Missing' (3)", present_null: "record(s) present but none meet criteria -> 'Unknown' (2)"}
units: n/a
depends_on: []
output: {physical_name: labbil, target_published_name: LABBIL, name_status: undecided, type: string, nullable: false, codes: "1=Present;2=Unknown;3=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "one t_lab record testbasename='bilirubin', testresultcleansed=250, testunitscleansed='mg/dL', testdate present -> LABBIL='Present' (1); no t_lab record -> 'Missing' (3)"
notes: "Tri-state present flag with numeric mirror 1/2/3. testbasename/unit carry [verify] markers -- stand-in unconfirmed (CL-C-VERIFY-PANEL). Read from t_lab. Unit shows a garbled '<10^9L^' before 'mg/dL' in the prior spec (CL-C-BIL-UNIT)."
```

#### LABBILV

```yaml
variable_id: LABBILV
spec_refs: [clinical:82]
spec_digest: 880abd84d05c
required_rule: "Bilirubin value (mg/dL) closest to index date among records meeting the LABBIL criteria; same-date tie-break -> highest."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "testresultcleansed of the record closest to index date meeting the LABBIL criteria; equidistant (either side of index) tie BLOCKED (CL-C-LAB-SELECTION)"
tie_break: {equidistant: "BLOCKED (CL-C-LAB-SELECTION)", same_day: highest}
derivation: "take testresultcleansed of the closest-to-index qualifying record; same-date tie-break -> highest. Window and equidistant-tie BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no qualifying lab record -> LABBILV null", present_null: n/a}
units: mg/dL
depends_on: [LABBIL]
output: {physical_name: labbilv, target_published_name: LABBILV, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "qualifying values 200 at index-30d and 250 at index-10d (mg/dL) -> LABBILV=250 (closest); two at index-10d -> highest"
notes: "Numeric value closest to index among records meeting the LABBIL criteria. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABBILVDT

```yaml
variable_id: LABBILVDT
spec_refs: [clinical:83]
spec_digest: 62cf4c2bfbe9
required_rule: "Bilirubin status date (mg/dL) = max(resultdate, testdate) of the record selected for LABBILV."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "date of the record selected for LABBILV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(resultdate, testdate) of the record chosen for LABBILV; null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABBILV -> date null", present_null: n/a}
units: date
depends_on: [LABBILV]
output: {physical_name: labbilvdt, target_published_name: LABBILVDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record resultdate=2020-05-20, testdate=2020-05-22 -> LABBILVDT=2020-05-22"
notes: "Status date of the record chosen for LABBILV. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABBILVU

```yaml
variable_id: LABBILVU
spec_refs: [clinical:84]
spec_digest: 2ca460a33ade
required_rule: "Bilirubin status unit (mg/dL) = testunitscleansed of the record selected for LABBILV (expected 'mg/dL')."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_units: TestUnitsCleaned}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "unit of the record selected for LABBILV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "testunitscleansed of the record chosen for LABBILV (expected 'mg/dL'); null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABBILV -> unit null", present_null: n/a}
units: n/a
depends_on: [LABBILV]
output: {physical_name: labbilvu, target_published_name: LABBILVU, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record testunitscleansed='mg/dL' -> LABBILVU='mg/dL'"
notes: "Delivered unit of the record chosen for LABBILV; the LABBIL criteria already require testunitscleansed='mg/dL'. [verify] marker (CL-C-VERIFY-PANEL)."
```

#### LABAST

```yaml
variable_id: LABAST
spec_refs: [clinical:85]
spec_digest: 10d4b13a3217
required_rule: "Aspartate Aminotransferase Value Present tri-state: 'Present'/'Unknown'/'Missing' (numeric 1/2/3), for testbasename='aspartate aminotransferase' (unit 'U/L') over the lab eligibility window."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "'Present' if >=1 t_lab record with testbasename='aspartate aminotransferase', testdate not missing, testresultcleansed>0 (not missing) and testunitscleansed='U/L' within the window; else 'Unknown' if record(s) exist but none qualify; 'Missing' if no t_lab record. testdate=max(resultdate,testdate). Window and closest-direction BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record in t_lab -> 'Missing' (3)", present_null: "record(s) present but none meet criteria -> 'Unknown' (2)"}
units: n/a
depends_on: []
output: {physical_name: labast, target_published_name: LABAST, name_status: undecided, type: string, nullable: false, codes: "1=Present;2=Unknown;3=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "one t_lab record testbasename='aspartate aminotransferase', testresultcleansed=250, testunitscleansed='U/L', testdate present -> LABAST='Present' (1); no t_lab record -> 'Missing' (3)"
notes: "Tri-state present flag with numeric mirror 1/2/3. testbasename/unit carry [verify] markers -- stand-in unconfirmed (CL-C-VERIFY-PANEL). Read from t_lab."
```

#### LABASTV

```yaml
variable_id: LABASTV
spec_refs: [clinical:86]
spec_digest: 3e2334f050fd
required_rule: "Aspartate Aminotransferase value (U/L) closest to index date among records meeting the LABAST criteria; same-date tie-break -> highest."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "testresultcleansed of the record closest to index date meeting the LABAST criteria; equidistant (either side of index) tie BLOCKED (CL-C-LAB-SELECTION)"
tie_break: {equidistant: "BLOCKED (CL-C-LAB-SELECTION)", same_day: highest}
derivation: "take testresultcleansed of the closest-to-index qualifying record; same-date tie-break -> highest. Window and equidistant-tie BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no qualifying lab record -> LABASTV null", present_null: n/a}
units: U/L
depends_on: [LABAST]
output: {physical_name: labastv, target_published_name: LABASTV, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "qualifying values 200 at index-30d and 250 at index-10d (U/L) -> LABASTV=250 (closest); two at index-10d -> highest"
notes: "Numeric value closest to index among records meeting the LABAST criteria. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABASTVDT

```yaml
variable_id: LABASTVDT
spec_refs: [clinical:87]
spec_digest: 6ea34af9de87
required_rule: "Aspartate Aminotransferase status date (U/L) = max(resultdate, testdate) of the record selected for LABASTV."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "date of the record selected for LABASTV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(resultdate, testdate) of the record chosen for LABASTV; null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABASTV -> date null", present_null: n/a}
units: date
depends_on: [LABASTV]
output: {physical_name: labastvdt, target_published_name: LABASTVDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record resultdate=2020-05-20, testdate=2020-05-22 -> LABASTVDT=2020-05-22"
notes: "Status date of the record chosen for LABASTV. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABASTVU

```yaml
variable_id: LABASTVU
spec_refs: [clinical:88]
spec_digest: ad74497dd747
required_rule: "Aspartate Aminotransferase status unit (U/L) = testunitscleansed of the record selected for LABASTV (expected 'U/L')."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_units: TestUnitsCleaned}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "unit of the record selected for LABASTV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "testunitscleansed of the record chosen for LABASTV (expected 'U/L'); null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABASTV -> unit null", present_null: n/a}
units: n/a
depends_on: [LABASTV]
output: {physical_name: labastvu, target_published_name: LABASTVU, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record testunitscleansed='U/L' -> LABASTVU='U/L'"
notes: "Delivered unit of the record chosen for LABASTV; the LABAST criteria already require testunitscleansed='U/L'. [verify] marker (CL-C-VERIFY-PANEL)."
```

#### LABALT

```yaml
variable_id: LABALT
spec_refs: [clinical:89]
spec_digest: 20cb3e9765eb
required_rule: "Alanine Aminotransferase Value Present tri-state: 'Present'/'Unknown'/'Missing' (numeric 1/2/3), for testbasename='alanine aminotransferase' (unit 'U/L') over the lab eligibility window."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "'Present' if >=1 t_lab record with testbasename='alanine aminotransferase', testdate not missing, testresultcleansed>0 (not missing) and testunitscleansed='U/L' within the window; else 'Unknown' if record(s) exist but none qualify; 'Missing' if no t_lab record. testdate=max(resultdate,testdate). Window and closest-direction BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record in t_lab -> 'Missing' (3)", present_null: "record(s) present but none meet criteria -> 'Unknown' (2)"}
units: n/a
depends_on: []
output: {physical_name: labalt, target_published_name: LABALT, name_status: undecided, type: string, nullable: false, codes: "1=Present;2=Unknown;3=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "one t_lab record testbasename='alanine aminotransferase', testresultcleansed=250, testunitscleansed='U/L', testdate present -> LABALT='Present' (1); no t_lab record -> 'Missing' (3)"
notes: "Tri-state present flag with numeric mirror 1/2/3. testbasename/unit carry [verify] markers -- stand-in unconfirmed (CL-C-VERIFY-PANEL). Read from t_lab."
```

#### LABALTV

```yaml
variable_id: LABALTV
spec_refs: [clinical:90]
spec_digest: 61b25a3dad75
required_rule: "Alanine Aminotransferase value (U/L) closest to index date among records meeting the LABALT criteria; same-date tie-break -> highest."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "testresultcleansed of the record closest to index date meeting the LABALT criteria; equidistant (either side of index) tie BLOCKED (CL-C-LAB-SELECTION)"
tie_break: {equidistant: "BLOCKED (CL-C-LAB-SELECTION)", same_day: highest}
derivation: "take testresultcleansed of the closest-to-index qualifying record; same-date tie-break -> highest. Window and equidistant-tie BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no qualifying lab record -> LABALTV null", present_null: n/a}
units: U/L
depends_on: [LABALT]
output: {physical_name: labaltv, target_published_name: LABALTV, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "qualifying values 200 at index-30d and 250 at index-10d (U/L) -> LABALTV=250 (closest); two at index-10d -> highest"
notes: "Numeric value closest to index among records meeting the LABALT criteria. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABALTVDT

```yaml
variable_id: LABALTVDT
spec_refs: [clinical:91]
spec_digest: b8bfa306e891
required_rule: "Alanine Aminotransferase status date (U/L) = max(resultdate, testdate) of the record selected for LABALTV."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "date of the record selected for LABALTV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(resultdate, testdate) of the record chosen for LABALTV; null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABALTV -> date null", present_null: n/a}
units: date
depends_on: [LABALTV]
output: {physical_name: labaltvdt, target_published_name: LABALTVDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record resultdate=2020-05-20, testdate=2020-05-22 -> LABALTVDT=2020-05-22"
notes: "Status date of the record chosen for LABALTV. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABALTVU

```yaml
variable_id: LABALTVU
spec_refs: [clinical:92]
spec_digest: 6fca3de398c9
required_rule: "Alanine Aminotransferase status unit (U/L) = testunitscleansed of the record selected for LABALTV (expected 'U/L')."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_units: TestUnitsCleaned}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "unit of the record selected for LABALTV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "testunitscleansed of the record chosen for LABALTV (expected 'U/L'); null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABALTV -> unit null", present_null: n/a}
units: n/a
depends_on: [LABALTV]
output: {physical_name: labaltvu, target_published_name: LABALTVU, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record testunitscleansed='U/L' -> LABALTVU='U/L'"
notes: "Delivered unit of the record chosen for LABALTV; the LABALT criteria already require testunitscleansed='U/L'. [verify] marker (CL-C-VERIFY-PANEL)."
```

#### LABALP

```yaml
variable_id: LABALP
spec_refs: [clinical:93]
spec_digest: bca510a2af27
required_rule: "Alkaline Phosphatase Value Present tri-state: 'Present'/'Unknown'/'Missing' (numeric 1/2/3), for testbasename='Alkaline Phosphatase' (unit 'U/L') over the lab eligibility window."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "'Present' if >=1 t_lab record with testbasename='Alkaline Phosphatase', testdate not missing, testresultcleansed>0 (not missing) and testunitscleansed='U/L' within the window; else 'Unknown' if record(s) exist but none qualify; 'Missing' if no t_lab record. testdate=max(resultdate,testdate). Window and closest-direction BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record in t_lab -> 'Missing' (3)", present_null: "record(s) present but none meet criteria -> 'Unknown' (2)"}
units: n/a
depends_on: []
output: {physical_name: labalp, target_published_name: LABALP, name_status: undecided, type: string, nullable: false, codes: "1=Present;2=Unknown;3=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "one t_lab record testbasename='Alkaline Phosphatase', testresultcleansed=250, testunitscleansed='U/L', testdate present -> LABALP='Present' (1); no t_lab record -> 'Missing' (3)"
notes: "Tri-state present flag with numeric mirror 1/2/3. testbasename/unit carry [verify] markers -- stand-in unconfirmed (CL-C-VERIFY-PANEL). Read from t_lab."
```

#### LABALPV

```yaml
variable_id: LABALPV
spec_refs: [clinical:94]
spec_digest: 288117ff3573
required_rule: "Alkaline Phosphatase value (U/L) closest to index date among records meeting the LABALP criteria; same-date tie-break -> highest."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "testresultcleansed of the record closest to index date meeting the LABALP criteria; equidistant (either side of index) tie BLOCKED (CL-C-LAB-SELECTION)"
tie_break: {equidistant: "BLOCKED (CL-C-LAB-SELECTION)", same_day: highest}
derivation: "take testresultcleansed of the closest-to-index qualifying record; same-date tie-break -> highest. Window and equidistant-tie BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no qualifying lab record -> LABALPV null", present_null: n/a}
units: U/L
depends_on: [LABALP]
output: {physical_name: labalpv, target_published_name: LABALPV, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "qualifying values 200 at index-30d and 250 at index-10d (U/L) -> LABALPV=250 (closest); two at index-10d -> highest"
notes: "Numeric value closest to index among records meeting the LABALP criteria. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABALPVDT

```yaml
variable_id: LABALPVDT
spec_refs: [clinical:95]
spec_digest: c5a84fd118c5
required_rule: "Alkaline Phosphatase status date (U/L) = max(resultdate, testdate) of the record selected for LABALPV."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "date of the record selected for LABALPV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(resultdate, testdate) of the record chosen for LABALPV; null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABALPV -> date null", present_null: n/a}
units: date
depends_on: [LABALPV]
output: {physical_name: labalpvdt, target_published_name: LABALPVDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record resultdate=2020-05-20, testdate=2020-05-22 -> LABALPVDT=2020-05-22"
notes: "Status date of the record chosen for LABALPV. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABALPVU

```yaml
variable_id: LABALPVU
spec_refs: [clinical:96]
spec_digest: 30f63d8eb780
required_rule: "Alkaline Phosphatase status unit (U/L) = testunitscleansed of the record selected for LABALPV (expected 'U/L')."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_units: TestUnitsCleaned}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "unit of the record selected for LABALPV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "testunitscleansed of the record chosen for LABALPV (expected 'U/L'); null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABALPV -> unit null", present_null: n/a}
units: n/a
depends_on: [LABALPV]
output: {physical_name: labalpvu, target_published_name: LABALPVU, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record testunitscleansed='U/L' -> LABALPVU='U/L'"
notes: "Delivered unit of the record chosen for LABALPV; the LABALP criteria already require testunitscleansed='U/L'. [verify] marker (CL-C-VERIFY-PANEL)."
```

#### LABALB

```yaml
variable_id: LABALB
spec_refs: [clinical:97]
spec_digest: 3b7d5bfd2a43
required_rule: "Serum albumin Value Present tri-state: 'Present'/'Unknown'/'Missing' (numeric 1/2/3), for testbasename='albumin' (unit 'g/L') over the lab eligibility window."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate, lab_component: LabComponent}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "'Present' if >=1 t_lab record with testbasename='albumin' AND labcomponent='Albumin, serum', testdate not missing, testresultcleansed>0 (not missing) and testunitscleansed='g/L' within the window; else 'Unknown' if record(s) exist but none qualify; 'Missing' if no t_lab record. testdate=max(resultdate,testdate). Window and closest-direction BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record in t_lab -> 'Missing' (3)", present_null: "record(s) present but none meet criteria -> 'Unknown' (2)"}
units: n/a
depends_on: []
output: {physical_name: labalb, target_published_name: LABALB, name_status: undecided, type: string, nullable: false, codes: "1=Present;2=Unknown;3=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "one t_lab record testbasename='albumin', testresultcleansed=250, testunitscleansed='g/L', testdate present -> LABALB='Present' (1); no t_lab record -> 'Missing' (3)"
notes: "Tri-state present flag with numeric mirror 1/2/3. testbasename/unit carry [verify] markers -- stand-in unconfirmed (CL-C-VERIFY-PANEL). Read from t_lab. labcomponent='Albumin, serum' filter applied per the definition."
```

#### LABALBV

```yaml
variable_id: LABALBV
spec_refs: [clinical:98]
spec_digest: ea8ad8609775
required_rule: "Serum albumin value (g/L) closest to index date among records meeting the LABALB criteria; same-date tie-break -> lowest."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate, lab_component: LabComponent}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "testresultcleansed of the record closest to index date meeting the LABALB criteria; equidistant (either side of index) tie BLOCKED (CL-C-LAB-SELECTION)"
tie_break: {equidistant: "BLOCKED (CL-C-LAB-SELECTION)", same_day: lowest}
derivation: "take testresultcleansed of the closest-to-index qualifying record; same-date tie-break -> lowest. Window and equidistant-tie BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no qualifying lab record -> LABALBV null", present_null: n/a}
units: g/L
depends_on: [LABALB]
output: {physical_name: labalbv, target_published_name: LABALBV, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "qualifying values 200 at index-30d and 250 at index-10d (g/L) -> LABALBV=250 (closest); two at index-10d -> lowest"
notes: "Numeric value closest to index among records meeting the LABALB criteria. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABALBVDT

```yaml
variable_id: LABALBVDT
spec_refs: [clinical:99]
spec_digest: 2124400c61f5
required_rule: "Serum albumin status date (g/L) = max(resultdate, testdate) of the record selected for LABALBV."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "date of the record selected for LABALBV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(resultdate, testdate) of the record chosen for LABALBV; null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABALBV -> date null", present_null: n/a}
units: date
depends_on: [LABALBV]
output: {physical_name: labalbvdt, target_published_name: LABALBVDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record resultdate=2020-05-20, testdate=2020-05-22 -> LABALBVDT=2020-05-22"
notes: "Status date of the record chosen for LABALBV. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABALBVU

```yaml
variable_id: LABALBVU
spec_refs: [clinical:100]
spec_digest: 1fd24fa624b3
required_rule: "Serum albumin status unit (g/L) = testunitscleansed of the record selected for LABALBV (expected 'g/L')."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_units: TestUnitsCleaned}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "unit of the record selected for LABALBV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "testunitscleansed of the record chosen for LABALBV (expected 'g/L'); null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABALBV -> unit null", present_null: n/a}
units: n/a
depends_on: [LABALBV]
output: {physical_name: labalbvu, target_published_name: LABALBVU, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record testunitscleansed='g/L' -> LABALBVU='g/L'"
notes: "Delivered unit of the record chosen for LABALBV; the LABALB criteria already require testunitscleansed='g/L'. [verify] marker (CL-C-VERIFY-PANEL)."
```

#### LABLYM

```yaml
variable_id: LABLYM
spec_refs: [clinical:101]
spec_digest: 289370b78605
required_rule: "Lymphocytes Value Present tri-state: 'Present'/'Unknown'/'Missing' (numeric 1/2/3), for testbasename='lymphocytes' (unit '10^9/L') over the lab eligibility window."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "'Present' if >=1 t_lab record with testbasename='lymphocytes', testdate not missing, testresultcleansed>0 (not missing) and testunitscleansed='10^9/L' within the window; else 'Unknown' if record(s) exist but none qualify; 'Missing' if no t_lab record. testdate=max(resultdate,testdate). Window and closest-direction BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record in t_lab -> 'Missing' (3)", present_null: "record(s) present but none meet criteria -> 'Unknown' (2)"}
units: n/a
depends_on: []
output: {physical_name: lablym, target_published_name: LABLYM, name_status: undecided, type: string, nullable: false, codes: "1=Present;2=Unknown;3=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "one t_lab record testbasename='lymphocytes', testresultcleansed=250, testunitscleansed='10^9/L', testdate present -> LABLYM='Present' (1); no t_lab record -> 'Missing' (3)"
notes: "Tri-state present flag with numeric mirror 1/2/3. testbasename/unit carry [verify] markers -- stand-in unconfirmed (CL-C-VERIFY-PANEL). Read from t_lab."
```

#### LABLYMV

```yaml
variable_id: LABLYMV
spec_refs: [clinical:102]
spec_digest: 832549861387
required_rule: "Lymphocytes value (10^9/L) closest to index date among records meeting the LABLYM criteria; same-date tie-break -> highest."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_base_name: TestBaseName, test_result: TestResultCleaned, test_units: TestUnitsCleaned, test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "testresultcleansed of the record closest to index date meeting the LABLYM criteria; equidistant (either side of index) tie BLOCKED (CL-C-LAB-SELECTION)"
tie_break: {equidistant: "BLOCKED (CL-C-LAB-SELECTION)", same_day: highest}
derivation: "take testresultcleansed of the closest-to-index qualifying record; same-date tie-break -> highest. Window and equidistant-tie BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no qualifying lab record -> LABLYMV null", present_null: n/a}
units: 10^9/L
depends_on: [LABLYM]
output: {physical_name: lablymv, target_published_name: LABLYMV, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "qualifying values 200 at index-30d and 250 at index-10d (10^9/L) -> LABLYMV=250 (closest); two at index-10d -> highest"
notes: "Numeric value closest to index among records meeting the LABLYM criteria. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABLYMVDT

```yaml
variable_id: LABLYMVDT
spec_refs: [clinical:103]
spec_digest: 7c549b3ae459
required_rule: "Lymphocytes status date (10^9/L) = max(resultdate, testdate) of the record selected for LABLYMV."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_date: TestDate, result_date: ResultDate}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "date of the record selected for LABLYMV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(resultdate, testdate) of the record chosen for LABLYMV; null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABLYMV -> date null", present_null: n/a}
units: date
depends_on: [LABLYMV]
output: {physical_name: lablymvdt, target_published_name: LABLYMVDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record resultdate=2020-05-20, testdate=2020-05-22 -> LABLYMVDT=2020-05-22"
notes: "Status date of the record chosen for LABLYMV. [verify] marker on the row (CL-C-VERIFY-PANEL)."
```

#### LABLYMVU

```yaml
variable_id: LABLYMVU
spec_refs: [clinical:104]
spec_digest: 24ceb18c4abc
required_rule: "Lymphocytes status unit (10^9/L) = testunitscleansed of the record selected for LABLYMV (expected '10^9/L')."
source: {kind: vendor, physical_stem: t_lab, inputs: {lab: {test_units: TestUnitsCleaned}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: "lab eligibility window (the spec prints 'index window'/'time period' but no bounds appear in these rows); 'closest to index' direction also unstated -- BLOCKED (CL-C-LAB-SELECTION)"
record_selection: "unit of the record selected for LABLYMV"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "testunitscleansed of the record chosen for LABLYMV (expected '10^9/L'); null if no record selected. Selection window BLOCKED (CL-C-LAB-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no record selected for LABLYMV -> unit null", present_null: n/a}
units: n/a
depends_on: [LABLYMV]
output: {physical_name: lablymvu, target_published_name: LABLYMVU, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-LAB-SELECTION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "selected record testunitscleansed='10^9/L' -> LABLYMVU='10^9/L'"
notes: "Delivered unit of the record chosen for LABLYMV; the LABLYM criteria already require testunitscleansed='10^9/L'. [verify] marker (CL-C-VERIFY-PANEL)."
```

#### CA125GRP

```yaml
variable_id: CA125GRP
spec_refs: [clinical:105]
spec_digest: 5df0a488ba9c
required_rule: "CA 125 category banded from LABCA125V: 1=Normalized, 2=Elevated, 3=Unknown. The operative cutoff is contested -- label says <35 iU/L but the definition uses a raw cutoff of 35000."
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "band LABCA125V: below cutoff -> 1 (Normalized), above cutoff -> 2 (Elevated), missing -> 3 (Unknown). The operative cutoff (35 vs 35000, per unit) is BLOCKED (CL-C-CA125-CUTOFF); the exact-boundary value (==cutoff) is unassigned (CL-C-BAND-BOUNDARY)."
cohort_applicability: all cohorts
missing: {no_record: "LABCA125V missing -> 3 (Unknown)", present_null: n/a}
units: n/a
depends_on: [LABCA125V]
output: {physical_name: ca125grp, target_published_name: CA125GRP, name_status: undecided, type: string, nullable: false, codes: "1=Normalized;2=Elevated;3=Unknown", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-CA125-CUTOFF]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be finalized until the cutoff is settled (CL-C-CA125-CUTOFF); e.g. with cutoff=35, LABCA125V=20 -> CA125GRP=Normalized (1)"
notes: "Clinical grouping (banded CA125). Label <35 iU/L contradicts the definition raw cutoff 35000 -- IU/L vs kU/L (CL-C-CA125-UNIT). Strict </> leaves the exact-cutoff value unassigned (CL-C-BAND-BOUNDARY)."
```

#### CA125GRPN

```yaml
variable_id: CA125GRPN
spec_refs: [clinical:106]
spec_digest: 8cd33807c22e
required_rule: "Numeric mirror of CA125GRP: 1=Normalized, 2=Elevated, 3=Unknown (same cutoff dispute)."
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of CA125GRP (1/2/3). Operative cutoff BLOCKED (CL-C-CA125-CUTOFF); exact-boundary value unassigned (CL-C-BAND-BOUNDARY)."
cohort_applicability: all cohorts
missing: {no_record: "LABCA125V missing -> 3", present_null: n/a}
units: n/a
depends_on: [CA125GRP]
output: {physical_name: ca125grpn, target_published_name: CA125GRPN, name_status: undecided, type: integer, nullable: false, codes: "1=Normalized;2=Elevated;3=Unknown", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-C-CA125-CUTOFF]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "CA125GRP=Elevated -> CA125GRPN=2 (pending CL-C-CA125-CUTOFF)"
notes: "Numeric mirror of CA125GRP; {kind: derived}. Same cutoff/unit contradiction (CL-C-CA125-UNIT)."
```

#### PLTGRP

```yaml
variable_id: PLTGRP
spec_refs: [clinical:107]
spec_digest: 3f0143bf6c47
required_rule: "Platelet count category banded from LABPLAV (10^9/L): 1=<150 (i.e. <150,000/uL), 2=>150 (>150,000/uL), 3=Unknown."
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "band LABPLAV (10^9/L): <150 -> 1, >150 -> 2, missing -> 3. Strict </> leaves the exact value ==150 unassigned (CL-C-BAND-BOUNDARY)."
cohort_applicability: all cohorts
missing: {no_record: "LABPLAV missing -> 3 (Unknown)", present_null: n/a}
units: n/a
depends_on: [LABPLAV]
output: {physical_name: pltgrp, target_published_name: PLTGRP, name_status: undecided, type: string, nullable: false, codes: "1=<150,000/uL;2=>150,000/uL;3=Unknown", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "LABPLAV=120 -> PLTGRP=<150,000/uL (1); LABPLAV=300 -> >150,000/uL (2); LABPLAV missing -> Unknown (3)"
notes: "Cutoff 150 x10^9/L = 150,000/uL, so units are consistent (unlike CA125) -- drafted straight. Strict </> leaves ==150 unassigned, recorded as a finding not a block (CL-C-BAND-BOUNDARY)."
```

#### PLTGRPN

```yaml
variable_id: PLTGRPN
spec_refs: [clinical:108]
spec_digest: b3c5a6d1b100
required_rule: "Numeric mirror of PLTGRP: 1, 2, 3."
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of PLTGRP (1/2/3). Same ==150 boundary caveat (CL-C-BAND-BOUNDARY)."
cohort_applicability: all cohorts
missing: {no_record: "LABPLAV missing -> 3", present_null: n/a}
units: n/a
depends_on: [PLTGRP]
output: {physical_name: pltgrpn, target_published_name: PLTGRPN, name_status: undecided, type: integer, nullable: false, codes: "1=<150,000/uL;2=>150,000/uL;3=Unknown", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "PLTGRP=>150,000/uL -> PLTGRPN=2"
notes: "Numeric mirror of PLTGRP; {kind: derived}."
```


## clinical — CL-D

#### MINAVAILDATE

```yaml
variable_id: MINAVAILDATE
spec_refs: [clinical:109]
spec_digest: 7bb1751aa187
required_rule: Earliest available data date for a patient — the minimum date across all source tables (date of earliest available data).
source: {kind: vendor, inputs: {diagnosis: {diagnosis_date: DiagnosisDate}, oc_clinical: {diagnosis_date: DiagnosisDate}, lab: {test_date: TestDate, result_date: ResultDate}, medorder: {ordered_date: OrderedDate}, visit: {visit_date: VisitDate}, lot: {start_date: StartDate}, orals: {start_date: StartDate}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "minimum over all listed source-date columns for the patient; the drug-episode/medication date field is BLOCKED (SP-MINAVAILDATE-FIELD)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "min over: Diagnosis.DiagnosisDate, Enhanced_OvarianCancer.DiagnosisDate, Lab.TestDate, Lab.ResultDate, MedicationOrder.OrderedDate, Visit.VisitDate, LineOfTherapy.StartDate, Enhanced_Ovarian_Orals.StartDate — the earliest available data date across all source tables. The drug/medication contribution field (MedicationOrder.OrderedDate here vs DrugEpisode.EpisodeDate on the data-prep tab) is contested between the two tabs and BLOCKED (SP-MINAVAILDATE-FIELD)."
cohort_applicability: all cohorts
missing: {no_record: "patient with no records in any source table → MINAVAILDATE null", present_null: n/a}
units: date
depends_on: []
output: {physical_name: minavaildate, target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [SP-MINAVAILDATE-FIELD]
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "earliest of a patient's source dates is Diagnosis.DiagnosisDate=2019-02-11 → MINAVAILDATE=2019-02-11"
notes: "An internal building block feeding BASEDUR. study_period:26 (SP domain) records an open ORDERDATE-vs-EPISODEDATE choice for the drug-episode contribution to min-available; the same variable is also stated on the data-prep tab (study_period:26), which is dispositioned as a duplicate of this row; the two tabs disagree on the drug-episode date field, so this record is blocked on SP-MINAVAILDATE-FIELD rather than silently taking OrderedDate. Physical source tables are Enhanced_OvarianCancer / Diagnosis / Lab / MedicationOrder / Visit / LineOfTherapy / Enhanced_Ovarian_Orals; the source.inputs keys are proposed (no config/ yet)."
```

#### BASEDUR

```yaml
variable_id: BASEDUR
spec_refs: [clinical:110]
spec_digest: 546107a5e1b2
required_rule: Baseline duration in days = INDEXDT − MINAVAILDATE + 1 (index date minus date of earliest available data, plus one).
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "index_date - MINAVAILDATE + 1 (days)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "MINAVAILDATE null → BASEDUR null"}
units: days
depends_on: [INDEXDT, MINAVAILDATE]
output: {physical_name: basedur, target_published_name: BASEDUR, name_status: undecided, type: integer, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "index_date=2020-06-01, MINAVAILDATE=2019-06-01 → BASEDUR=367"
notes: "The +1 is stated explicitly (inclusive-day convention); study_period:2 lists 'BASEDUR +1' as a data-prep decision recorded there. INDEXDT is defined on the outcomes tab (outcomes:7)."
```

#### FUDUR

```yaml
variable_id: FUDUR
spec_refs: [clinical:111]
spec_digest: 4edceefeffe6
required_rule: Follow-up duration in days = end of follow-up (FUED) − INDEXDT.
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "FUED - index_date (days). Depends on the end-of-follow-up definition, which is unsettled (BLOCKED: CL-D-FU-END)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "FUED null → FUDUR null"}
units: days
depends_on: [INDEXDT, FUED]
output: {physical_name: fudur, target_published_name: FUDUR, name_status: undecided, type: integer, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-D-FU-END]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until end-of-follow-up is defined (CL-D-FU-END); e.g. FUED=2021-06-01, index_date=2020-06-01 → FUDUR=365"
notes: "Blocked transitively on the FU-end definition via FUED — see CL-D-FU-END. The arithmetic is unambiguous; only the FUED endpoint is open."
```

#### PFUDUR

```yaml
variable_id: PFUDUR
spec_refs: [clinical:112]
spec_digest: 2ae0a77f3280
required_rule: Potential follow-up duration in days = end of data (data cutoff) − INDEXDT.
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "end_of_data (data cutoff) - index_date (days). The 'end of data / data-availability cutoff' endpoint is not defined in the spec (BLOCKED: CL-D-DATACUT)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "index_date null → PFUDUR null"}
units: days
depends_on: [INDEXDT]
output: {physical_name: pfudur, target_published_name: PFUDUR, name_status: undecided, type: integer, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-D-DATACUT]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until the data-cutoff endpoint is defined (CL-D-DATACUT); e.g. data cutoff=2026-03-31, index_date=2020-06-01 → PFUDUR=2130"
notes: "The '*_preliminary' follow-up framing in this spec family leaves both the actual follow-up end (CL-D-FU-END) and the data-availability endpoint (CL-D-DATACUT) unsettled; PFUDUR depends on the latter. The data version is 2026m03 (study_period:6 DATAV), but the concrete cutoff DATE for potential follow-up is not stated."
```

#### INDEXYR

```yaml
variable_id: INDEXYR
spec_refs: [clinical:113]
spec_digest: ddf6603d934e
required_rule: Index year = year(INDEXDT).
source: {kind: derived}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "year(index_date)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "index_date null → INDEXYR null"}
units: year
depends_on: [INDEXDT]
output: {physical_name: indexyr, target_published_name: INDEXYR, name_status: undecided, type: integer, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "index_date=2020-06-01 → INDEXYR=2020"
notes: "No study_period twin of INDEXYR was found in the extraction, so this is a record (not a duplicate). INDEXDT is defined on the outcomes tab (outcomes:7)."
```

#### DEATH_DT_PRELIMINARY

```yaml
variable_id: DEATH_DT_PRELIMINARY
spec_refs: [clinical:114]
spec_digest: 941f9b20f686
required_rule: Preliminary (pre-death-check) date of death imputed from Enhanced_Mortality_V2.DateOfDeath — month granularity → 15th of the month (exception: death month/year = FUED month/year → last day of that month, so imputed death does not precede last activity); year-only with death year = INDEXDT year → Jul-15 if monthday(INDEXDT) ≤ Jul-15 else Dec-31.
source: {kind: vendor, inputs: {mortality: {date_of_death: DateOfDeath}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "from Enhanced_Mortality_V2.DateOfDeath: month-granular → 15th of month, UNLESS death month/year = FUED month/year → last day of month; year-only AND death year = year(INDEXDT) → Jul-15 if monthday(INDEXDT) <= Jul-15 else Dec-31."
cohort_applicability: all cohorts
missing: {no_record: "no DateOfDeath → DEATH_DT_PRELIMINARY null (presumed alive)", present_null: n/a}
units: date
depends_on: [INDEXDT, FUED]
output: {physical_name: death_dt_preliminary, target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "DateOfDeath='2021-03' (month granularity), FUED month/year != 2021-03 → DEATH_DT_PRELIMINARY=2021-03-15"
notes: "Internal building block for DTHDT/FUED. The month-exception references FUED while FUED's reconciliation references DEATH_DT_PRELIMINARY — a circular dependency with unspecified evaluation order (finding CL-D-DEATH-FUED-CIRC), whose resolution belongs to CL-D-FU-END. The imputation logic itself is legible, so this stays draft; the author's '[verify vs golden ADS]' marker is recorded as CL-D-DEATH-VERIFY. Source table Enhanced_Mortality_V2; logical key 'mortality' proposed."
```

#### DTHDT

```yaml
variable_id: DTHDT
spec_refs: [clinical:115]
spec_digest: 05729187a983
required_rule: Final date of death = DEATH_DT_PRELIMINARY (month → 15th; same month/year as FUED / max LOT-end → last day of month; year-only with death year = INDEXDT year → Jul-15 if monthday(INDEXDT) ≤ Jul-15 else Dec-31). The last-day case is the same-month-as-follow-up exception preventing an imputed death preceding last activity.
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "DTHDT = DEATH_DT_PRELIMINARY, with month-granular imputed to 15th; if same month/year as FUED / MAX_LOTEND_DT → last day of month; year-only (death year = year(INDEXDT)) → Jul-15 if monthday(INDEXDT) <= Jul-15 else Dec-31."
cohort_applicability: all cohorts
missing: {no_record: "no DateOfDeath → DTHDT null (presumed alive)", present_null: n/a}
units: date
depends_on: [DEATH_DT_PRELIMINARY, FUED, MAX_LOTEND_DT, INDEXDT]
output: {physical_name: dthdt, target_published_name: DTHDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "DEATH_DT_PRELIMINARY imputed 2021-03-15 with no follow-up-month collision → DTHDT=2021-03-15"
notes: "Death and clinical sections agree on the 15th base and the same-month-as-follow-up last-day exception. Underlying vendor value is Enhanced_Mortality_V2.DateOfDeath (via DEATH_DT_PRELIMINARY). The FUED / max-LOT-end exception makes DTHDT depend on the unsettled FU-end model (CL-D-FU-END) and shares the circularity finding CL-D-DEATH-FUED-CIRC; the imputation rule is legible so this stays draft. Author '[verify vs golden ADS]' marker → CL-D-DEATH-VERIFY."
```

#### DTHFL

```yaml
variable_id: DTHFL
spec_refs: [clinical:116]
spec_digest: 0d183c9817a1
required_rule: Patient death flag (source var F_DEATH) — 1 if a death date is present (vital status 'deceased'), else 0 (presumed alive; Enhanced Mortality V2.0).
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "1 if DTHDT (DateOfDeath) present else 0."
cohort_applicability: all cohorts
missing: {no_record: "no DateOfDeath → DTHFL=0 (presumed alive)", present_null: n/a}
units: n/a
depends_on: [DTHDT]
output: {physical_name: dthfl, target_published_name: DTHFL, name_status: undecided, type: integer, nullable: false, codes: "1=death;0=alive/no death date", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "DateOfDeath present → DTHFL=1; DateOfDeath missing → DTHFL=0"
notes: "Derived presence indicator over Enhanced_Mortality_V2.DateOfDeath; always defined (0 when no death date), so nullable false. Source var name F_DEATH noted."
```

#### DTHFUFL

```yaml
variable_id: DTHFUFL
spec_refs: [clinical:117]
spec_digest: b0eb2dea1bcd
required_rule: Acceptable death / follow-up-end gap flag — 1 if (DTHDT − FUED) ≤ 120 days else 0. A data-quality flag for a ≥120-day gap between death and last record; per 13-Mar-2025 TC it is NOT used to exclude patients from outcomes (OS, rwPFS).
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "1 if (DTHDT - FUED) <= 120 days else 0. Flag only — does not exclude patients from OS/rwPFS."
cohort_applicability: all cohorts
missing: {no_record: "no DTHDT (alive) → gap not evaluable; flag not set (per-record handling follows the alive branch)", present_null: n/a}
units: days
depends_on: [DTHDT, FUED]
output: {physical_name: dthfufl, target_published_name: DTHFUFL, name_status: undecided, type: integer, nullable: true, codes: "1=gap acceptable;0=gap too large", role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "DTHDT=2021-03-15, FUED=2021-02-01 → gap 42 days ≤ 120 → DTHFUFL=1"
notes: "The 120-day threshold is stated, so this is drafted; the author's '[verify]' markers on this row are stand-in-confirm markers (no rule change). It reads FUED, which is blocked on CL-D-FU-END, so its values move with that decision, but its own rule is defined. Role internal (a DQ flag; not a published outcome and explicitly non-excluding)."
```

#### FU_ENDDT_PRELIMINARY

```yaml
variable_id: FU_ENDDT_PRELIMINARY
spec_refs: [clinical:118]
spec_digest: 6050e10bc926
required_rule: End of follow-up (preliminary, before the death-date check) = maximum of last confirmed EHR activity dates — Visit.VisitDate, Telemedicine.VisitDate, LineOfTherapy.EndDate, and Enhanced_Ovarian_Orals.EndDate (where EndDate not null AND DateGranularity != 'Year').
source: {kind: vendor, inputs: {visit: {visit_date: VisitDate}, telemedicine: {visit_date: VisitDate}, lot: {end_date: EndDate}, orals: {end_date: EndDate, date_granularity: DateGranularity}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "maximum across the four activity-date columns for the patient (orals restricted to EndDate not null AND DateGranularity != 'Year')"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max of Visit.VisitDate, Telemedicine.VisitDate, LineOfTherapy.EndDate, Enhanced_Ovarian_Orals.EndDate (orals: EndDate not null AND DateGranularity != 'Year') — the last confirmed EHR activity date."
cohort_applicability: all cohorts
missing: {no_record: "no qualifying activity record → FU_ENDDT_PRELIMINARY undefined (resolution is part of the FU-end model, CL-D-FU-END)", present_null: n/a}
units: date
depends_on: [MIN_VSL_DT, MIN_VSTTELEMED_DT, MAX_VSTTELEMED_DT, MAX_VST_DT, MAX_LOTEND_DT, MAX_ORLEND_DT]
output: {physical_name: fu_enddt_preliminary, target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-D-FU-END]
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until the end-of-follow-up model is settled (CL-D-FU-END); e.g. max(last visit 2021-05-02, LOT-end 2021-04-30) → FU_ENDDT_PRELIMINARY=2021-05-02"
notes: "The max-of-activities rule is registered, but the end-of-follow-up definition is a known-open question in this spec family (the '*_preliminary' naming, and the note that end of follow-up must be defined 'utilizing death, last structured activity, etc.'), so this is blocked on CL-D-FU-END per the drafting instruction. Interim min/max activity dates are carried as separate records (clinical:120-126)."
```

#### FUED

```yaml
variable_id: FUED
spec_refs: [clinical:119]
spec_digest: 017b6aaf346b
required_rule: Follow-up end date (source var FU_ENDDT) = FU_ENDDT_PRELIMINARY, reconciled against death — if FU_ENDDT_PRELIMINARY > DEATH_DT_PRELIMINARY and death month/year = max LOT-end date then FUED = max LOT-end date, else FUED = DEATH_DT_PRELIMINARY; then floor at INDEXDT (if INDEXDT ≥ FUED then FUED = INDEXDT). Follow-up runs index date → death / end of record / data cutoff, whichever is first.
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "FUED = FU_ENDDT_PRELIMINARY; if FU_ENDDT_PRELIMINARY > DEATH_DT_PRELIMINARY and death month/year = MAX_LOTEND_DT then FUED = MAX_LOTEND_DT else FUED = DEATH_DT_PRELIMINARY; then if INDEXDT >= FUED then FUED = INDEXDT. Comparison operators (> vs <, >= vs >) are contradicted against the prior spec and unresolved (BLOCKED: CL-D-FU-END)."
cohort_applicability: all cohorts
missing: {no_record: "no activity and no death → FUED undefined pending CL-D-FU-END", present_null: n/a}
units: date
depends_on: [FU_ENDDT_PRELIMINARY, DEATH_DT_PRELIMINARY, MAX_LOTEND_DT, INDEXDT]
output: {physical_name: fued, target_published_name: FUED, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-D-FU-END]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until CL-D-FU-END settles the reconciliation and operators; e.g. no death, FU_ENDDT_PRELIMINARY=2021-05-02, INDEXDT<that → FUED=2021-05-02"
notes: "Blocked on CL-D-FU-END, which must define the end-of-follow-up reconciliation, resolve the operator discrepancy the spec itself flags ('[verify operator > vs < and >= vs >]'), and pin the evaluation order for the DEATH_DT_PRELIMINARY↔FUED circular reference (finding CL-D-DEATH-FUED-CIRC). Underlying vendor inputs are Visit/Telemedicine/LOT/Orals/Mortality dates via FU_ENDDT_PRELIMINARY and DEATH_DT_PRELIMINARY."
```

#### MIN_VSL_DT

```yaml
variable_id: MIN_VSL_DT
spec_refs: [clinical:120]
spec_digest: 8a6c2f353e23
required_rule: Interim minimum visit date — the earliest Visit.VisitDate, kept from the FU_ENDDT_preliminary construction (use the _sasdt variant).
source: {kind: vendor, inputs: {visit: {visit_date: VisitDate}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "minimum VisitDate over the patient's visit records"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "min(Visit.VisitDate) per patient (use the _sasdt date variant)."
cohort_applicability: all cohorts
missing: {no_record: "no visit records → MIN_VSL_DT null", present_null: n/a}
units: date
depends_on: []
output: {physical_name: min_vsl_dt, target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: excluded, dictionary: excluded, dashboard: excluded, tfl: excluded}
acceptance: "visit dates {2020-06-10, 2021-01-05} → MIN_VSL_DT=2020-06-10"
notes: "Interim variable feeding follow-up construction; role internal. The exact SAS variable name carries a '[verify]' marker (finding CL-D-INTERIM-NAME) — a stand-in/naming artifact, not an RWB question."
```

#### MIN_VSTTELEMED_DT

```yaml
variable_id: MIN_VSTTELEMED_DT
spec_refs: [clinical:121]
spec_digest: ad8e84698709
required_rule: Interim minimum telemedicine visit date — the earliest Telemedicine.VisitDate, kept from the FU_ENDDT_preliminary construction (use the _sasdt variant).
source: {kind: vendor, inputs: {telemedicine: {visit_date: VisitDate}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "minimum VisitDate over the patient's telemedicine records"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "min(Telemedicine.VisitDate) per patient (use the _sasdt date variant)."
cohort_applicability: all cohorts
missing: {no_record: "no telemedicine records → MIN_VSTTELEMED_DT null", present_null: n/a}
units: date
depends_on: []
output: {physical_name: min_vsttelemed_dt, target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: excluded, dictionary: excluded, dashboard: excluded, tfl: excluded}
acceptance: "telemedicine visit dates {2020-07-01} → MIN_VSTTELEMED_DT=2020-07-01"
notes: "Interim variable; role internal. Capture shows an inconsistent spelling ('min_vsltelemed_dt' vs 'min_vsttelemed_dt') and a '[verify]' marker — finding CL-D-INTERIM-NAME."
```

#### MIN_MEDORD_DT

```yaml
variable_id: MIN_MEDORD_DT
spec_refs: [clinical:122]
spec_digest: b7e792e92051
required_rule: Interim minimum medication-order date — the earliest MedicationOrder.OrderedDate, kept from the FU_ENDDT_preliminary construction (use the _sasdt variant).
source: {kind: vendor, inputs: {medorder: {ordered_date: OrderedDate}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "minimum OrderedDate over the patient's medication-order records"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "min(MedicationOrder.OrderedDate) per patient (use the _sasdt date variant)."
cohort_applicability: all cohorts
missing: {no_record: "no medication-order records → MIN_MEDORD_DT null", present_null: n/a}
units: date
depends_on: []
output: {physical_name: min_medord_dt, target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: excluded, dictionary: excluded, dashboard: excluded, tfl: excluded}
acceptance: "medication-order dates {2020-06-15, 2020-09-01} → MIN_MEDORD_DT=2020-06-15"
notes: "Interim variable; role internal. Exact SAS variable name carries a '[verify]' marker — finding CL-D-INTERIM-NAME."
```

#### MAX_VSTTELEMED_DT

```yaml
variable_id: MAX_VSTTELEMED_DT
spec_refs: [clinical:123]
spec_digest: b8c682b33740
required_rule: Interim maximum telemedicine visit date — the latest Telemedicine.VisitDate, kept from the FU_ENDDT_preliminary construction (use the _sasdt variant).
source: {kind: vendor, inputs: {telemedicine: {visit_date: VisitDate}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "maximum VisitDate over the patient's telemedicine records"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(Telemedicine.VisitDate) per patient (use the _sasdt date variant)."
cohort_applicability: all cohorts
missing: {no_record: "no telemedicine records → MAX_VSTTELEMED_DT null", present_null: n/a}
units: date
depends_on: []
output: {physical_name: max_vsttelemed_dt, target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: excluded, dictionary: excluded, dashboard: excluded, tfl: excluded}
acceptance: "telemedicine visit dates {2020-07-01, 2021-02-10} → MAX_VSTTELEMED_DT=2021-02-10"
notes: "Interim variable feeding FU_ENDDT_PRELIMINARY; role internal. Capture shows 'max_vsltelemed_dt' vs 'max_vsttelemed_dt' and a '[verify]' marker — finding CL-D-INTERIM-NAME."
```

#### MAX_LOTEND_DT

```yaml
variable_id: MAX_LOTEND_DT
spec_refs: [clinical:124]
spec_digest: 8d525a23f0dd
required_rule: Interim maximum line-of-therapy end date — the latest LineOfTherapy.EndDate; feeds the DTHDT / FUED death reconciliation.
source: {kind: vendor, inputs: {lot: {end_date: EndDate}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "maximum EndDate over the patient's line-of-therapy records"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(LineOfTherapy.EndDate) per patient (use the _sasdt date variant)."
cohort_applicability: all cohorts
missing: {no_record: "no LOT records → MAX_LOTEND_DT null", present_null: n/a}
units: date
depends_on: []
output: {physical_name: max_lotend_dt, target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: excluded, dictionary: excluded, dashboard: excluded, tfl: excluded}
acceptance: "LOT end dates {2020-12-01, 2021-04-30} → MAX_LOTEND_DT=2021-04-30"
notes: "Interim variable feeding DTHDT/FUED death reconciliation; role internal. Exact SAS variable name carries a '[verify]' marker — finding CL-D-INTERIM-NAME."
```

#### MAX_VST_DT

```yaml
variable_id: MAX_VST_DT
spec_refs: [clinical:125]
spec_digest: 83f24f5e9d40
required_rule: Interim maximum visit date — the latest Visit.VisitDate, kept from the FU_ENDDT_preliminary construction (use the _sasdt variant).
source: {kind: vendor, inputs: {visit: {visit_date: VisitDate}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "maximum VisitDate over the patient's visit records"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(Visit.VisitDate) per patient (use the _sasdt date variant)."
cohort_applicability: all cohorts
missing: {no_record: "no visit records → MAX_VST_DT null", present_null: n/a}
units: date
depends_on: []
output: {physical_name: max_vst_dt, target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: excluded, dictionary: excluded, dashboard: excluded, tfl: excluded}
acceptance: "visit dates {2020-06-10, 2021-05-02} → MAX_VST_DT=2021-05-02"
notes: "Interim variable feeding FU_ENDDT_PRELIMINARY; role internal. Exact SAS variable name carries a '[verify]' marker — finding CL-D-INTERIM-NAME."
```

#### MAX_ORLEND_DT

```yaml
variable_id: MAX_ORLEND_DT
spec_refs: [clinical:126]
spec_digest: ce54ef63a841
required_rule: Interim maximum oral-therapy end date — the latest Enhanced_Ovarian_Orals.EndDate where EndDate not null AND DateGranularity != 'Year'.
source: {kind: vendor, inputs: {orals: {end_date: EndDate, date_granularity: DateGranularity}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "maximum EndDate over the patient's oral-therapy records (EndDate not null AND DateGranularity != 'Year')"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(Enhanced_Ovarian_Orals.EndDate) per patient, restricted to EndDate not null AND DateGranularity != 'Year' (use the _sasdt date variant)."
cohort_applicability: all cohorts
missing: {no_record: "no qualifying oral-therapy records → MAX_ORLEND_DT null", present_null: n/a}
units: date
depends_on: []
output: {physical_name: max_orlend_dt, target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: excluded, dictionary: excluded, dashboard: excluded, tfl: excluded}
acceptance: "orals EndDate {2021-03-15 (Day granularity)} → MAX_ORLEND_DT=2021-03-15"
notes: "Interim variable feeding FU_ENDDT_PRELIMINARY; role internal. The DateGranularity != 'Year' filter is stated. Exact SAS variable name carries a '[verify]' marker — finding CL-D-INTERIM-NAME."
```

#### PCYCL1

```yaml
variable_id: PCYCL1
spec_refs: [clinical:127]
spec_digest: 18d706897f6d
required_rule: Number of platinum cycles in line 1 = count of distinct DrugEpisode.EpisodeDate where IsMaintenanceTherapy='False' AND LineNumber=1 AND DrugName contains 'platin'. Administration count is used as a proxy for cycle count.
source: {kind: vendor, inputs: {drugepisode: {episode_date: EpisodeDate, line_number: LineNumber, is_maintenance: IsMaintenanceTherapy, drug_name: DrugName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "DrugEpisode rows with IsMaintenanceTherapy='False' AND LineNumber=1 AND DrugName contains 'platin'"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "count(distinct EpisodeDate) over non-maintenance platinum episodes in line 1. Platinum identified by DrugName substring 'platin' (rule to variables/codelists). Number of administrations proxies number of cycles."
cohort_applicability: all cohorts
missing: {no_record: "no matching platinum episodes in line 1 → PCYCL1=0", present_null: n/a}
units: cycles
depends_on: []
output: {physical_name: pcycl1, target_published_name: PCYCL1, name_status: undecided, type: integer, nullable: false, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line-1 non-maintenance platinum EpisodeDates {2020-06-01, 2020-06-22, 2020-07-13} → PCYCL1=3"
notes: "Platinum variables are the spec's top sign-off priority (clinical:2). The cycle-identification rule is fully stated (distinct non-maintenance platinum episode dates in the line), so this is drafted; the substring 'platin' heuristic is the spec's own rule and is named in derivation for the codelist."
```

#### PCYCL2

```yaml
variable_id: PCYCL2
spec_refs: [clinical:128]
spec_digest: 17f6de0e31d8
required_rule: Number of platinum cycles in line 2 = count of distinct DrugEpisode.EpisodeDate where IsMaintenanceTherapy='False' AND LineNumber=2 AND DrugName contains 'platin'. Administration count is used as a proxy for cycle count.
source: {kind: vendor, inputs: {drugepisode: {episode_date: EpisodeDate, line_number: LineNumber, is_maintenance: IsMaintenanceTherapy, drug_name: DrugName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "DrugEpisode rows with IsMaintenanceTherapy='False' AND LineNumber=2 AND DrugName contains 'platin'"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "count(distinct EpisodeDate) over non-maintenance platinum episodes in line 2. Platinum identified by DrugName substring 'platin'. Administration count proxies cycle count."
cohort_applicability: all cohorts
missing: {no_record: "no matching platinum episodes in line 2 → PCYCL2=0", present_null: n/a}
units: cycles
depends_on: []
output: {physical_name: pcycl2, target_published_name: PCYCL2, name_status: undecided, type: integer, nullable: false, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line-2 non-maintenance platinum EpisodeDates {2021-05-01, 2021-05-22} → PCYCL2=2"
notes: "Same rule as PCYCL1 at LineNumber=2. Platinum variables are the spec's top sign-off priority."
```

#### PCYCL3

```yaml
variable_id: PCYCL3
spec_refs: [clinical:129]
spec_digest: 2f3251ac4d3d
required_rule: Number of platinum cycles in line 3 = count of distinct DrugEpisode.EpisodeDate where IsMaintenanceTherapy='False' AND LineNumber=3 AND DrugName contains 'platin'. Administration count is used as a proxy for cycle count.
source: {kind: vendor, inputs: {drugepisode: {episode_date: EpisodeDate, line_number: LineNumber, is_maintenance: IsMaintenanceTherapy, drug_name: DrugName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "DrugEpisode rows with IsMaintenanceTherapy='False' AND LineNumber=3 AND DrugName contains 'platin'"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "count(distinct EpisodeDate) over non-maintenance platinum episodes in line 3. Platinum identified by DrugName substring 'platin'. Administration count proxies cycle count."
cohort_applicability: all cohorts
missing: {no_record: "no matching platinum episodes in line 3 → PCYCL3=0", present_null: n/a}
units: cycles
depends_on: []
output: {physical_name: pcycl3, target_published_name: PCYCL3, name_status: undecided, type: integer, nullable: false, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line-3 non-maintenance platinum EpisodeDates {} → PCYCL3=0"
notes: "Same rule as PCYCL1 at LineNumber=3. Platinum variables are the spec's top sign-off priority."
```

#### PCYCL4

```yaml
variable_id: PCYCL4
spec_refs: [clinical:130]
spec_digest: 011148cdfc42
required_rule: Number of platinum cycles in line 4 = count of distinct DrugEpisode.EpisodeDate where IsMaintenanceTherapy='False' AND LineNumber=4 AND DrugName contains 'platin'. Administration count is used as a proxy for cycle count.
source: {kind: vendor, inputs: {drugepisode: {episode_date: EpisodeDate, line_number: LineNumber, is_maintenance: IsMaintenanceTherapy, drug_name: DrugName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "DrugEpisode rows with IsMaintenanceTherapy='False' AND LineNumber=4 AND DrugName contains 'platin'"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "count(distinct EpisodeDate) over non-maintenance platinum episodes in line 4. Platinum identified by DrugName substring 'platin'. Administration count proxies cycle count."
cohort_applicability: all cohorts
missing: {no_record: "no matching platinum episodes in line 4 → PCYCL4=0", present_null: n/a}
units: cycles
depends_on: []
output: {physical_name: pcycl4, target_published_name: PCYCL4, name_status: undecided, type: integer, nullable: false, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line-4 non-maintenance platinum EpisodeDates {} → PCYCL4=0"
notes: "Same rule as PCYCL1 at LineNumber=4. Platinum variables are the spec's top sign-off priority."
```

#### PCYCL5

```yaml
variable_id: PCYCL5
spec_refs: [clinical:131]
spec_digest: f6d35bf4da20
required_rule: Number of platinum cycles in line 5 = count of distinct DrugEpisode.EpisodeDate where IsMaintenanceTherapy='False' AND LineNumber=5 AND DrugName contains 'platin'. Administration count is used as a proxy for cycle count.
source: {kind: vendor, inputs: {drugepisode: {episode_date: EpisodeDate, line_number: LineNumber, is_maintenance: IsMaintenanceTherapy, drug_name: DrugName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "DrugEpisode rows with IsMaintenanceTherapy='False' AND LineNumber=5 AND DrugName contains 'platin'"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "count(distinct EpisodeDate) over non-maintenance platinum episodes in line 5. Platinum identified by DrugName substring 'platin'. Administration count proxies cycle count."
cohort_applicability: all cohorts
missing: {no_record: "no matching platinum episodes in line 5 → PCYCL5=0", present_null: n/a}
units: cycles
depends_on: []
output: {physical_name: pcycl5, target_published_name: PCYCL5, name_status: undecided, type: integer, nullable: false, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line-5 non-maintenance platinum EpisodeDates {} → PCYCL5=0"
notes: "Same rule as PCYCL1 at LineNumber=5. Platinum variables are the spec's top sign-off priority."
```

#### PCYCL1ED

```yaml
variable_id: PCYCL1ED
spec_refs: [clinical:132]
spec_digest: 2eb1100e59a5
required_rule: Date of the LAST platinum cycle in line 1 = latest DrugEpisode.EpisodeDate where IsMaintenanceTherapy='False' AND LineNumber=1 AND DrugName contains 'platin'; NA if none. Feeds the platinum-free interval (PFI uses PCYCL{i-1}ED).
source: {kind: vendor, inputs: {drugepisode: {episode_date: EpisodeDate, line_number: LineNumber, is_maintenance: IsMaintenanceTherapy, drug_name: DrugName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "latest EpisodeDate among IsMaintenanceTherapy='False' AND LineNumber=1 AND DrugName contains 'platin'"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max EpisodeDate over non-maintenance platinum episodes in line 1; NA if none. Feeds PFI."
cohort_applicability: all cohorts
missing: {no_record: "no matching platinum episodes in line 1 → PCYCL1ED=NA (null)", present_null: n/a}
units: date
depends_on: []
output: {physical_name: pcycl1ed, target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "line-1 non-maintenance platinum EpisodeDates {2020-06-01, 2020-07-13} → PCYCL1ED=2020-07-13"
notes: "Last-cycle date feeding PFI (platinum-free interval); role internal building block. 'NA if none' is stated. Same platinum/line filter as PCYCL1."
```

#### PCYCL2ED

```yaml
variable_id: PCYCL2ED
spec_refs: [clinical:133]
spec_digest: 703ad5087082
required_rule: Date of the LAST platinum cycle in line 2 = latest DrugEpisode.EpisodeDate where IsMaintenanceTherapy='False' AND LineNumber=2 AND DrugName contains 'platin'; NA if none. Feeds the platinum-free interval (PFI uses PCYCL{i-1}ED).
source: {kind: vendor, inputs: {drugepisode: {episode_date: EpisodeDate, line_number: LineNumber, is_maintenance: IsMaintenanceTherapy, drug_name: DrugName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "latest EpisodeDate among IsMaintenanceTherapy='False' AND LineNumber=2 AND DrugName contains 'platin'"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max EpisodeDate over non-maintenance platinum episodes in line 2; NA if none. Feeds PFI."
cohort_applicability: all cohorts
missing: {no_record: "no matching platinum episodes in line 2 → PCYCL2ED=NA (null)", present_null: n/a}
units: date
depends_on: []
output: {physical_name: pcycl2ed, target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "line-2 non-maintenance platinum EpisodeDates {2021-05-01, 2021-05-22} → PCYCL2ED=2021-05-22"
notes: "Last-cycle date feeding PFI; role internal. Same platinum/line filter as PCYCL2."
```

#### PCYCL3ED

```yaml
variable_id: PCYCL3ED
spec_refs: [clinical:134]
spec_digest: a4a6af9b049f
required_rule: Date of the LAST platinum cycle in line 3 = latest DrugEpisode.EpisodeDate where IsMaintenanceTherapy='False' AND LineNumber=3 AND DrugName contains 'platin'; NA if none. Feeds the platinum-free interval (PFI uses PCYCL{i-1}ED).
source: {kind: vendor, inputs: {drugepisode: {episode_date: EpisodeDate, line_number: LineNumber, is_maintenance: IsMaintenanceTherapy, drug_name: DrugName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "latest EpisodeDate among IsMaintenanceTherapy='False' AND LineNumber=3 AND DrugName contains 'platin'"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max EpisodeDate over non-maintenance platinum episodes in line 3; NA if none. Feeds PFI."
cohort_applicability: all cohorts
missing: {no_record: "no matching platinum episodes in line 3 → PCYCL3ED=NA (null)", present_null: n/a}
units: date
depends_on: []
output: {physical_name: pcycl3ed, target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "line-3 non-maintenance platinum EpisodeDates {} → PCYCL3ED=NA"
notes: "Last-cycle date feeding PFI; role internal. Same platinum/line filter as PCYCL3."
```

#### PCYCL4ED

```yaml
variable_id: PCYCL4ED
spec_refs: [clinical:135]
spec_digest: 9ac94bf42099
required_rule: Date of the LAST platinum cycle in line 4 = latest DrugEpisode.EpisodeDate where IsMaintenanceTherapy='False' AND LineNumber=4 AND DrugName contains 'platin'; NA if none. Feeds the platinum-free interval (PFI uses PCYCL{i-1}ED).
source: {kind: vendor, inputs: {drugepisode: {episode_date: EpisodeDate, line_number: LineNumber, is_maintenance: IsMaintenanceTherapy, drug_name: DrugName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "latest EpisodeDate among IsMaintenanceTherapy='False' AND LineNumber=4 AND DrugName contains 'platin'"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max EpisodeDate over non-maintenance platinum episodes in line 4; NA if none. Feeds PFI."
cohort_applicability: all cohorts
missing: {no_record: "no matching platinum episodes in line 4 → PCYCL4ED=NA (null)", present_null: n/a}
units: date
depends_on: []
output: {physical_name: pcycl4ed, target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "line-4 non-maintenance platinum EpisodeDates {} → PCYCL4ED=NA"
notes: "Last-cycle date feeding PFI; role internal. Same platinum/line filter as PCYCL4."
```

#### PCYCL5ED

```yaml
variable_id: PCYCL5ED
spec_refs: [clinical:136]
spec_digest: 2d857c27f566
required_rule: Date of the LAST platinum cycle in line 5 = latest DrugEpisode.EpisodeDate where IsMaintenanceTherapy='False' AND LineNumber=5 AND DrugName contains 'platin'; NA if none. Feeds the platinum-free interval (PFI uses PCYCL{i-1}ED).
source: {kind: vendor, inputs: {drugepisode: {episode_date: EpisodeDate, line_number: LineNumber, is_maintenance: IsMaintenanceTherapy, drug_name: DrugName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "latest EpisodeDate among IsMaintenanceTherapy='False' AND LineNumber=5 AND DrugName contains 'platin'"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max EpisodeDate over non-maintenance platinum episodes in line 5; NA if none. Feeds PFI."
cohort_applicability: all cohorts
missing: {no_record: "no matching platinum episodes in line 5 → PCYCL5ED=NA (null)", present_null: n/a}
units: date
depends_on: []
output: {physical_name: pcycl5ed, target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "line-5 non-maintenance platinum EpisodeDates {} → PCYCL5ED=NA"
notes: "Last-cycle date feeding PFI; role internal. Same platinum/line filter as PCYCL5."
```

#### TSTAGE

```yaml
variable_id: TSTAGE
spec_refs: [clinical:137]
spec_digest: 16451dcb1646
required_rule: AJCC T stage at initial diagnosis (coded, e.g. T1) from Enhanced_OvarianCancer — additive to the FIGO GroupStage that EDM uses (STAGE).
source: {kind: vendor, inputs: {oc_clinical: {t_stage: TStage}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "T stage recorded at the initial OC diagnosis"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the delivered AJCC T stage at initial diagnosis as-is. Handling of missing / non-conforming AJCC values is not stated (BLOCKED: CL-D-STAGE-UNMATCHED)."
cohort_applicability: all cohorts
missing: {no_record: "no T stage recorded → handling unstated (BLOCKED: CL-D-STAGE-UNMATCHED)", present_null: "delivered T stage null → handling unstated (BLOCKED: CL-D-STAGE-UNMATCHED)"}
units: n/a
depends_on: []
output: {physical_name: tstage, target_published_name: TStage, name_status: undecided, type: string, nullable: true, codes: "AJCC T categories (full delivered list [verify], CL-D-STAGE-LIST; enumerate in variables/codelists)", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-D-STAGE-UNMATCHED]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fully fixed until missing/unmatched handling is defined (CL-D-STAGE-UNMATCHED); e.g. delivered TStage='T3c' → TSTAGE='T3c'"
notes: "ADDITIVE Panoramic field (Origin='ADDITIVE (not in prior spec)', clinical:2) — DEFER/proposed. The spec names only the Enhanced_Ovarian table; the delivered column is proposed as TStage (spec prints no atomic column). The full AJCC T code list is marked '[verify]' — stand-in-incomplete, finding CL-D-STAGE-LIST (resolves by re-extraction)."
```

#### NSTAGE

```yaml
variable_id: NSTAGE
spec_refs: [clinical:138]
spec_digest: ee1acdc9871b
required_rule: AJCC N stage at initial diagnosis (coded, e.g. N1) from Enhanced_OvarianCancer.
source: {kind: vendor, inputs: {oc_clinical: {n_stage: NStage}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "N stage recorded at the initial OC diagnosis"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the delivered AJCC N stage at initial diagnosis as-is. Handling of missing / non-conforming AJCC values is not stated (BLOCKED: CL-D-STAGE-UNMATCHED)."
cohort_applicability: all cohorts
missing: {no_record: "no N stage recorded → handling unstated (BLOCKED: CL-D-STAGE-UNMATCHED)", present_null: "delivered N stage null → handling unstated (BLOCKED: CL-D-STAGE-UNMATCHED)"}
units: n/a
depends_on: []
output: {physical_name: nstage, target_published_name: NStage, name_status: undecided, type: string, nullable: true, codes: "AJCC N categories (enumerate in variables/codelists)", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-D-STAGE-UNMATCHED]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fully fixed until missing/unmatched handling is defined (CL-D-STAGE-UNMATCHED); e.g. delivered NStage='N1' → NSTAGE='N1'"
notes: "ADDITIVE Panoramic field — DEFER/proposed. The spec names only the Enhanced_Ovarian table; the delivered column is proposed as NStage (spec prints no atomic column)."
```

#### MSTAGE

```yaml
variable_id: MSTAGE
spec_refs: [clinical:139]
spec_digest: 459f977cb894
required_rule: AJCC M stage at initial diagnosis (coded, e.g. M1) from Enhanced_OvarianCancer.
source: {kind: vendor, inputs: {oc_clinical: {m_stage: MStage}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "M stage recorded at the initial OC diagnosis"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the delivered AJCC M stage at initial diagnosis as-is. Handling of missing / non-conforming AJCC values is not stated (BLOCKED: CL-D-STAGE-UNMATCHED)."
cohort_applicability: all cohorts
missing: {no_record: "no M stage recorded → handling unstated (BLOCKED: CL-D-STAGE-UNMATCHED)", present_null: "delivered M stage null → handling unstated (BLOCKED: CL-D-STAGE-UNMATCHED)"}
units: n/a
depends_on: []
output: {physical_name: mstage, target_published_name: MStage, name_status: undecided, type: string, nullable: true, codes: "AJCC M categories (enumerate in variables/codelists)", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [CL-D-STAGE-UNMATCHED]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fully fixed until missing/unmatched handling is defined (CL-D-STAGE-UNMATCHED); e.g. delivered MStage='M0' → MSTAGE='M0'"
notes: "ADDITIVE Panoramic field — DEFER/proposed. The spec names only the Enhanced_Ovarian table; the delivered column is proposed as MStage (spec prints no atomic column)."
```

#### EXTENTOFDEBULKING

```yaml
variable_id: EXTENTOFDEBULKING
spec_refs: [clinical:140]
spec_digest: 340984d173a0
required_rule: Extent of debulking following surgery for the initial OC diagnosis — Optimal / Suboptimal / Unknown — from Enhanced_OvarianCancer; a surgical-outcome dimension beyond RD / SizeOfResidualDisease.
source: {kind: vendor, inputs: {oc_clinical: {extent_of_debulking: ExtentOfDebulking}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "extent recorded for the surgery following the initial OC diagnosis"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the delivered extent of debulking as-is: {Optimal, Suboptimal, Unknown}."
cohort_applicability: all cohorts
missing: {no_record: "no debulking/surgery record → 'Unknown'", present_null: "delivered value null → 'Unknown'"}
units: n/a
depends_on: []
output: {physical_name: extentofdebulking, target_published_name: ExtentOfDebulking, name_status: undecided, type: string, nullable: true, codes: "Optimal;Suboptimal;Unknown", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "delivered ExtentOfDebulking='Optimal' → EXTENTOFDEBULKING='Optimal'"
notes: "ADDITIVE Panoramic field — DEFER/proposed. Value set (incl. Unknown for missing) is fully stated, so drafted. The spec names only the Enhanced_Ovarian table; the delivered column is proposed as ExtentOfDebulking."
```

#### BIOMARKERDETAIL

```yaml
variable_id: BIOMARKERDETAIL
spec_refs: [clinical:141]
spec_digest: a333ad177fe5
required_rule: Genomic alteration class for a biomarker record where status is Positive — Mutation / Rearrangement / Amplification / Protein expression / VUS / Gene Expression / Loss / Other / Unknown. (No separate NGS gene/variant table exists; genomics is this biomarker metadata.)
source: {kind: vendor, inputs: {biomarkers: {biomarker_detail: BiomarkerDetail}}}
grain: [patientid, biomarker_record]
anchor: n/a
window: n/a
record_selection: "biomarker records where BiomarkerStatus = Positive"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "type/class of genomic alteration for Positive biomarker records: {Mutation, Rearrangement, Amplification, Protein expression, VUS, Gene Expression, Loss, Other, Unknown} (enumerate in variables/codelists)."
cohort_applicability: all cohorts
missing: {no_record: "no positive biomarker record → no BIOMARKERDETAIL row", present_null: "delivered class null → 'Unknown'"}
units: n/a
depends_on: []
output: {physical_name: biomarkerdetail, target_published_name: BiomarkerDetail, name_status: undecided, type: string, nullable: true, codes: "Mutation;Rearrangement;Amplification;Protein expression;VUS;Gene Expression;Loss;Other;Unknown", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "a Positive biomarker with alteration class 'Mutation' → BIOMARKERDETAIL='Mutation'"
notes: "ADDITIVE Panoramic biomarker metadata — DEFER/proposed. Restriction to Positive status is stated. Grain is per biomarker record (Enhanced_OvarianBiomarkers), not per patient. The spec names only the table; the delivered column is proposed as BiomarkerDetail. Logical source key 'biomarkers' mirrors SRC_BIOMARKERS (study_period:29)."
```

#### DNATYPE

```yaml
variable_id: DNATYPE
spec_refs: [clinical:142]
spec_digest: 5a532076e7db
required_rule: DNA source used for the biomarker test — Germline / Somatic / Unknown (only populated for BRCA).
source: {kind: vendor, inputs: {biomarkers: {dna_type: DnaType}}}
grain: [patientid, biomarker_record]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the delivered DNA source as-is: {Germline, Somatic, Unknown}. Populated only for BRCA biomarkers."
cohort_applicability: all cohorts
missing: {no_record: "no biomarker record → no DNATYPE row", present_null: "non-BRCA or missing → 'Unknown'"}
units: n/a
depends_on: []
output: {physical_name: dnatype, target_published_name: DnaType, name_status: undecided, type: string, nullable: true, codes: "Germline;Somatic;Unknown", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "a BRCA biomarker with DnaType='Germline' → DNATYPE='Germline'"
notes: "ADDITIVE Panoramic biomarker metadata — DEFER/proposed. 'Only populated for BRCA' is stated. Grain per biomarker record. The spec names only the Enhanced_OvarianBiomarkers table; the delivered column is proposed as DnaType."
```

#### BIOMARKER_METHOD

```yaml
variable_id: BIOMARKER_METHOD
spec_refs: [clinical:143]
spec_digest: f26f1eddf609
required_rule: Assay methodology / platform of the biomarker test — FISH / IHC / NGS / RNA sequencing / PCR / Other / Unknown.
source: {kind: vendor, inputs: {biomarkers: {}}}
grain: [patientid, biomarker_record]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the delivered biomarker test method/platform as-is: {FISH, IHC, NGS, RNA sequencing, PCR, Other, Unknown}."
cohort_applicability: all cohorts
missing: {no_record: "no biomarker record → no BIOMARKER_METHOD row", present_null: "delivered method null → 'Unknown'"}
units: n/a
depends_on: []
output: {physical_name: biomarker_method, target_published_name: BiomarkerMethod, name_status: undecided, type: string, nullable: true, codes: "FISH;IHC;NGS;RNA sequencing;PCR;Other;Unknown", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "a biomarker tested by IHC → BIOMARKER_METHOD='IHC'"
notes: "ADDITIVE Panoramic biomarker metadata — DEFER/proposed. The exact delivered column name is explicitly '[verify] on delivered dict' — the spec names neither an atomic column nor a stable field name, so source.inputs carries the logical source 'biomarkers' with the column left UNKNOWN (finding CL-D-BMETHOD-FIELD, resolves by re-extraction / dictionary confirmation at Gate 3). The value set is legible, so this is drafted."
```

#### STAININGINTENSITY

```yaml
variable_id: STAININGINTENSITY
spec_refs: [clinical:144]
spec_digest: 79c587535526
required_rule: Vendor-coded IHC staining intensity for FOLR1 / FRalpha — raw labels 0, 1/1+/Weak, 2/2+/Moderate, 3/3+/Strong, Other.
source: {kind: vendor, inputs: {biomarkers: {staining_intensity: StainingIntensity}}}
grain: [patientid, biomarker_record]
anchor: n/a
window: n/a
record_selection: "FOLR1/FRalpha IHC biomarker records"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the delivered raw IHC staining-intensity label as-is: {0, 1/1+/Weak, 2/2+/Moderate, 3/3+/Strong, Other}. The named high/moderate/low FRalpha EXPRESSION tiers used for scoring are NOT documented and would be a DERIVED variable with cut-offs to decide (CL-D-FRALPHA-TIERS); this record carries the RAW intensity only."
cohort_applicability: all cohorts
missing: {no_record: "no FOLR1/FRalpha IHC record → no STAININGINTENSITY row", present_null: "delivered intensity null → null"}
units: n/a
depends_on: []
output: {physical_name: stainingintensity, target_published_name: StainingIntensity, name_status: undecided, type: string, nullable: true, codes: "0;1/1+/Weak;2/2+/Moderate;3/3+/Strong;Other", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "delivered staining intensity '2+' → STAININGINTENSITY='2/2+/Moderate' (raw label as delivered)"
notes: "ADDITIVE Panoramic biomarker metadata — DEFER/proposed. The raw intensity labels are documented, so this is drafted as a pass-through. The FRalpha high/moderate/low expression tiers used for scoring are undocumented (cut-offs to decide) and are registered as CL-D-FRALPHA-TIERS for a future derived score variable — they are NOT asserted here. Grain per biomarker record; delivered column proposed."
```

#### PERCENTSTAINING

```yaml
variable_id: PERCENTSTAINING
spec_refs: [clinical:145]
spec_digest: 1a40b25de1db
required_rule: Percent of cells staining for FOLR1 / FRalpha by IHC.
source: {kind: vendor, inputs: {biomarkers: {percent_staining: PercentStaining}}}
grain: [patientid, biomarker_record]
anchor: n/a
window: n/a
record_selection: "FOLR1/FRalpha IHC biomarker records"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the delivered percent of cells staining for FOLR1/FRalpha by IHC (0-100)."
cohort_applicability: all cohorts
missing: {no_record: "no FOLR1/FRalpha IHC record → no PERCENTSTAINING row", present_null: "delivered percent null → null"}
units: percent
depends_on: []
output: {physical_name: percentstaining, target_published_name: PercentStaining, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "delivered percent staining 75 → PERCENTSTAINING=75"
notes: "ADDITIVE Panoramic biomarker metadata — DEFER/proposed. A straight quantitative pass-through, so drafted. Together with STAININGINTENSITY it feeds the undocumented FRalpha expression-tier scoring (CL-D-FRALPHA-TIERS), which is a future derived variable and not asserted here. Grain per biomarker record; delivered column proposed."
```

#### LABNAME

```yaml
variable_id: LABNAME
spec_refs: [clinical:146]
spec_digest: bd7621b5f267
required_rule: Laboratory / assay that performed the biomarker test (e.g. Foundation Medicine, Guardant, Tempus, Caris, Myriad; HRD/GIS adds assay names e.g. Myriad myChoice).
source: {kind: vendor, inputs: {biomarkers: {lab_name: LabName}}}
grain: [patientid, biomarker_record]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the delivered testing lab / assay name as-is (open-ended list; example values Foundation Medicine, Guardant, Tempus, Caris, Myriad, Myriad myChoice)."
cohort_applicability: all cohorts
missing: {no_record: "no biomarker record → no LABNAME row", present_null: "delivered lab null → null"}
units: n/a
depends_on: []
output: {physical_name: labname, target_published_name: LabName, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "delivered lab 'Foundation Medicine' → LABNAME='Foundation Medicine'"
notes: "ADDITIVE Panoramic biomarker metadata — DEFER/proposed. The value list is open-ended (spec shows '...'), so no fixed code list is asserted. Grain per biomarker record; delivered column proposed."
```

#### SAMPLETYPE

```yaml
variable_id: SAMPLETYPE
spec_refs: [clinical:147]
spec_digest: 325063e6d74f
required_rule: Specimen type tested — Blood / Tissue / Saliva / Urine / Other / Unknown.
source: {kind: vendor, inputs: {biomarkers: {sample_type: SampleType}}}
grain: [patientid, biomarker_record]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the delivered specimen type as-is: {Blood, Tissue, Saliva, Urine, Other, Unknown}."
cohort_applicability: all cohorts
missing: {no_record: "no biomarker record → no SAMPLETYPE row", present_null: "delivered value null → 'Unknown'"}
units: n/a
depends_on: []
output: {physical_name: sampletype, target_published_name: SampleType, name_status: undecided, type: string, nullable: true, codes: "Blood;Tissue;Saliva;Urine;Other;Unknown", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "delivered specimen 'Tissue' → SAMPLETYPE='Tissue'"
notes: "ADDITIVE Panoramic biomarker metadata — DEFER/proposed. Value set fully stated, so drafted. Grain per biomarker record; delivered column proposed."
```

#### BIOMARKER_DATES

```yaml
variable_id: BIOMARKER_DATES
spec_refs: [clinical:148]
spec_digest: 041a401298fd
required_rule: Biomarker test dates — SpecimenCollectedDate / SpecimenReceivedDate / ResultDate for the biomarker test.
source: {kind: vendor, inputs: {biomarkers: {specimen_collected_date: SpecimenCollectedDate, specimen_received_date: SpecimenReceivedDate, result_date: ResultDate}}}
grain: [patientid, biomarker_record]
anchor: n/a
window: n/a
record_selection: "all three dates retained per biomarker record"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry SpecimenCollectedDate, SpecimenReceivedDate and ResultDate of the biomarker test."
cohort_applicability: all cohorts
missing: {no_record: "no biomarker record → no BIOMARKER_DATES row", present_null: "an individual date null → carried null"}
units: date
depends_on: []
output: {physical_name: "specimen_collected_date specimen_received_date result_date", target_published_name: n/a, name_status: undecided, type: date, nullable: true, codes: n/a, role: internal}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: undecided, dictionary: undecided, dashboard: undecided, tfl: undecided}
acceptance: "a biomarker record with ResultDate=2021-02-10 yields BIOMARKER_DATES.result_date=2021-02-10"
notes: "ADDITIVE Panoramic biomarker metadata — DEFER/proposed. Three atomic date columns are named by the spec (SpecimenCollectedDate/SpecimenReceivedDate/ResultDate). Kept together as one family record per spec row (per I16), role internal, values enumerated as columns. Grain per biomarker record."
```

#### CTDNA_REPORTDATE

```yaml
variable_id: CTDNA_REPORTDATE
spec_refs: [clinical:149]
spec_digest: 8e41afe1d931
required_rule: Date of the Natera Signatera ctDNA report (report-level grain — one row per report).
source: {kind: vendor, inputs: {ctdna: {report_date: ReportDate}}}
grain: [patientid, ctdna_report]
anchor: n/a
window: n/a
record_selection: "one row per ctDNA report"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the Natera Signatera ctDNA report date; grain is one row per report."
cohort_applicability: all cohorts
missing: {no_record: "no ctDNA report → no row", present_null: "report date null (rare) → null"}
units: date
depends_on: []
output: {physical_name: ctdna_reportdate, target_published_name: ctDNA_ReportDate, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "a Signatera report dated 2022-01-15 → CTDNA_REPORTDATE=2022-01-15"
notes: "ADDITIVE Panoramic field (Enhanced_Ovarian_ctDNA) — DEFER/proposed. Report-level grain is stated. 'rarely null', so nullable true. Logical source 'ctdna' is PROPOSED — no SRC_* declaration for ctDNA exists in study_period rows 28-48, which is worth confirming with the study_period chunk; the spec names only the Enhanced_Ovarian_ctDNA table and the delivered column is proposed."
```

#### CTDNA_TESTRESULT

```yaml
variable_id: CTDNA_TESTRESULT
spec_refs: [clinical:150]
spec_digest: 207191c83068
required_rule: Natera Signatera ctDNA result — Positive / Negative / Inconclusive (never null).
source: {kind: vendor, inputs: {ctdna: {test_result: TestResult}}}
grain: [patientid, ctdna_report]
anchor: n/a
window: n/a
record_selection: "one row per ctDNA report"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the delivered Signatera ctDNA result as-is: {Positive, Negative, Inconclusive}."
cohort_applicability: all cohorts
missing: {no_record: "no ctDNA report → no row", present_null: "never null per spec"}
units: n/a
depends_on: []
output: {physical_name: ctdna_testresult, target_published_name: ctDNA_TestResult, name_status: undecided, type: string, nullable: false, codes: "Positive;Negative;Inconclusive", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "a Signatera report with result 'Positive' → CTDNA_TESTRESULT='Positive'"
notes: "ADDITIVE Panoramic field (Enhanced_Ovarian_ctDNA) — DEFER/proposed. Value set stated and 'never null' (nullable false). Report-level grain; no patient-level selection is stated (one row per report). Logical source 'ctdna' proposed (see CTDNA_REPORTDATE note)."
```

#### CTDNA_TESTMEASUREMENT

```yaml
variable_id: CTDNA_TESTMEASUREMENT
spec_refs: [clinical:151]
spec_digest: 5453e709026b
required_rule: Quantitative ctDNA measurement — mean tumor molecules per mL (MTM/mL); null if the result is Negative or Inconclusive.
source: {kind: vendor, inputs: {ctdna: {test_measurement: TestMeasurement}}}
grain: [patientid, ctdna_report]
anchor: n/a
window: n/a
record_selection: "one row per ctDNA report"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the delivered quantitative ctDNA measurement in MTM/mL; null when TestResult is Negative or Inconclusive."
cohort_applicability: all cohorts
missing: {no_record: "no ctDNA report → no row", present_null: "result Negative/Inconclusive → measurement null"}
units: MTM/mL
depends_on: [CTDNA_TESTRESULT]
output: {physical_name: ctdna_testmeasurement, target_published_name: ctDNA_TestMeasurement, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "a Positive Signatera report measuring 12.4 MTM/mL → CTDNA_TESTMEASUREMENT=12.4; a Negative report → null"
notes: "ADDITIVE Panoramic field (Enhanced_Ovarian_ctDNA) — DEFER/proposed. The null-when-Negative/Inconclusive rule is stated, so drafted; depends on CTDNA_TESTRESULT for the null branch. Report-level grain; logical source 'ctdna' proposed (see CTDNA_REPORTDATE note)."
```


## treatment — TX-A

#### LOT1

```yaml
variable_id: LOT1
spec_refs: [treatment:6]
spec_digest: 7ab412eacd77
required_rule: "Regimen name for line 1 (non-maintenance): the linename recorded in the LineOfTherapy table where linenumber=1 AND ismaintenancetherapy=FALSE. COHORTU=1 -> actual name; COHORTU=2 -> 'NONE'."
source: {kind: vendor, inputs: {lot: {line_name: linename, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=1 AND ismaintenancetherapy=FALSE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "COHORTU=1 -> linename where linenumber=1 AND ismaintenancetherapy=FALSE; COHORTU=2 -> 'NONE'. The line assignment (linenumber) and the maintenance flag (ismaintenancetherapy) are vendor-delivered and their construction is not stated in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts; COHORTU=1 -> actual regimen name, COHORTU=2 -> 'NONE' (index date differs per cohort)"
missing: {no_record: "patient reaches fewer than 1 lines -> no line-1 record; fill value for an absent line is not stated (not invented)", present_null: "linename null on the line-1 record -> null"}
units: n/a
depends_on: []
output: {physical_name: lot1, target_published_name: LOT1, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "COHORTU=1 patient whose line-1 linename='Carboplatin,Paclitaxel' -> LOT1='Carboplatin,Paclitaxel'; COHORTU=2 -> LOT1='NONE'"
notes: "Family LOTi (i=1..5), one record per line per I16. Definitions print table t_lineoftherapy_&date; the Values cell prints the near-duplicate t_lineotherapy_&date (TX-A-TABLE-TYPO). VERIFY_MARKER is a tab-wide sign-off-pending flag. No physical_stem set (macro-templated name)."
```

#### LOT2

```yaml
variable_id: LOT2
spec_refs: [treatment:7]
spec_digest: 90fec1d1b5e8
required_rule: "Regimen name for line 2 (non-maintenance): the linename recorded in the LineOfTherapy table where linenumber=2 AND ismaintenancetherapy=FALSE. COHORTU=1 -> actual name; COHORTU=2 -> 'NONE'."
source: {kind: vendor, inputs: {lot: {line_name: linename, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=2 AND ismaintenancetherapy=FALSE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "COHORTU=1 -> linename where linenumber=2 AND ismaintenancetherapy=FALSE; COHORTU=2 -> 'NONE'. The line assignment (linenumber) and the maintenance flag (ismaintenancetherapy) are vendor-delivered and their construction is not stated in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts; COHORTU=1 -> actual regimen name, COHORTU=2 -> 'NONE' (index date differs per cohort)"
missing: {no_record: "patient reaches fewer than 2 lines -> no line-2 record; fill value for an absent line is not stated (not invented)", present_null: "linename null on the line-2 record -> null"}
units: n/a
depends_on: []
output: {physical_name: lot2, target_published_name: LOT2, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "COHORTU=1 patient whose line-2 linename='Carboplatin,Paclitaxel' -> LOT2='Carboplatin,Paclitaxel'; COHORTU=2 -> LOT2='NONE'"
notes: "Family LOTi (i=1..5), one record per line per I16. Definitions print table t_lineoftherapy_&date; the Values cell prints the near-duplicate t_lineotherapy_&date (TX-A-TABLE-TYPO). VERIFY_MARKER is a tab-wide sign-off-pending flag. No physical_stem set (macro-templated name)."
```

#### LOT3

```yaml
variable_id: LOT3
spec_refs: [treatment:8]
spec_digest: c4c81341421d
required_rule: "Regimen name for line 3 (non-maintenance): the linename recorded in the LineOfTherapy table where linenumber=3 AND ismaintenancetherapy=FALSE. COHORTU=1 -> actual name; COHORTU=2 -> 'NONE'."
source: {kind: vendor, inputs: {lot: {line_name: linename, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=3 AND ismaintenancetherapy=FALSE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "COHORTU=1 -> linename where linenumber=3 AND ismaintenancetherapy=FALSE; COHORTU=2 -> 'NONE'. The line assignment (linenumber) and the maintenance flag (ismaintenancetherapy) are vendor-delivered and their construction is not stated in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts; COHORTU=1 -> actual regimen name, COHORTU=2 -> 'NONE' (index date differs per cohort)"
missing: {no_record: "patient reaches fewer than 3 lines -> no line-3 record; fill value for an absent line is not stated (not invented)", present_null: "linename null on the line-3 record -> null"}
units: n/a
depends_on: []
output: {physical_name: lot3, target_published_name: LOT3, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "COHORTU=1 patient whose line-3 linename='Carboplatin,Paclitaxel' -> LOT3='Carboplatin,Paclitaxel'; COHORTU=2 -> LOT3='NONE'"
notes: "Family LOTi (i=1..5), one record per line per I16. Definitions print table t_lineoftherapy_&date; the Values cell prints the near-duplicate t_lineotherapy_&date (TX-A-TABLE-TYPO). VERIFY_MARKER is a tab-wide sign-off-pending flag. No physical_stem set (macro-templated name)."
```

#### LOT4

```yaml
variable_id: LOT4
spec_refs: [treatment:9]
spec_digest: 28c46d0f7f1f
required_rule: "Regimen name for line 4 (non-maintenance): the linename recorded in the LineOfTherapy table where linenumber=4 AND ismaintenancetherapy=FALSE. COHORTU=1 -> actual name; COHORTU=2 -> 'NONE'."
source: {kind: vendor, inputs: {lot: {line_name: linename, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=4 AND ismaintenancetherapy=FALSE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "COHORTU=1 -> linename where linenumber=4 AND ismaintenancetherapy=FALSE; COHORTU=2 -> 'NONE'. The line assignment (linenumber) and the maintenance flag (ismaintenancetherapy) are vendor-delivered and their construction is not stated in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts; COHORTU=1 -> actual regimen name, COHORTU=2 -> 'NONE' (index date differs per cohort)"
missing: {no_record: "patient reaches fewer than 4 lines -> no line-4 record; fill value for an absent line is not stated (not invented)", present_null: "linename null on the line-4 record -> null"}
units: n/a
depends_on: []
output: {physical_name: lot4, target_published_name: LOT4, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "COHORTU=1 patient whose line-4 linename='Carboplatin,Paclitaxel' -> LOT4='Carboplatin,Paclitaxel'; COHORTU=2 -> LOT4='NONE'"
notes: "Family LOTi (i=1..5), one record per line per I16. Definitions print table t_lineoftherapy_&date; the Values cell prints the near-duplicate t_lineotherapy_&date (TX-A-TABLE-TYPO). VERIFY_MARKER is a tab-wide sign-off-pending flag. No physical_stem set (macro-templated name)."
```

#### LOT5

```yaml
variable_id: LOT5
spec_refs: [treatment:10]
spec_digest: 04ef637f8cf2
required_rule: "Regimen name for line 5 (non-maintenance): the linename recorded in the LineOfTherapy table where linenumber=5 AND ismaintenancetherapy=FALSE. COHORTU=1 -> actual name; COHORTU=2 -> 'NONE'."
source: {kind: vendor, inputs: {lot: {line_name: linename, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=5 AND ismaintenancetherapy=FALSE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "COHORTU=1 -> linename where linenumber=5 AND ismaintenancetherapy=FALSE; COHORTU=2 -> 'NONE'. The line assignment (linenumber) and the maintenance flag (ismaintenancetherapy) are vendor-delivered and their construction is not stated in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts; COHORTU=1 -> actual regimen name, COHORTU=2 -> 'NONE' (index date differs per cohort)"
missing: {no_record: "patient reaches fewer than 5 lines -> no line-5 record; fill value for an absent line is not stated (not invented)", present_null: "linename null on the line-5 record -> null"}
units: n/a
depends_on: []
output: {physical_name: lot5, target_published_name: LOT5, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "COHORTU=1 patient whose line-5 linename='Carboplatin,Paclitaxel' -> LOT5='Carboplatin,Paclitaxel'; COHORTU=2 -> LOT5='NONE'"
notes: "Family LOTi (i=1..5), one record per line per I16. Definitions print table t_lineoftherapy_&date; the Values cell prints the near-duplicate t_lineotherapy_&date (TX-A-TABLE-TYPO). VERIFY_MARKER is a tab-wide sign-off-pending flag. No physical_stem set (macro-templated name)."
```

#### LOT1SD

```yaml
variable_id: LOT1SD
spec_refs: [treatment:11]
spec_digest: 57854e608f9b
required_rule: "Start date of line 1 (non-maintenance): the startdate recorded in the LineOfTherapy table where linenumber=1 AND ismaintenancetherapy=FALSE."
source: {kind: vendor, inputs: {lot: {line_start: startdate, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=1 AND ismaintenancetherapy=FALSE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "startdate where linenumber=1 AND ismaintenancetherapy=FALSE. Line assignment and maintenance flag are vendor-delivered and undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort); the COHORTU=2 -> 'NONE' rule is stated for regimen names, not restated for dates"
missing: {no_record: "patient reaches fewer than 1 lines -> no line-1 record", present_null: "startdate null on the line-1 record -> null"}
units: date
depends_on: []
output: {physical_name: lot1sd, target_published_name: LOT1SD, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line-1 startdate=2020-06-01 -> LOT1SD=2020-06-01"
notes: "Family LOTiSD (i=1..5). Read from t_lineoftherapy_&date (macro-templated; no physical_stem set). Decision_required is inherited from the unstated line/maintenance construction, not from the date read itself."
```

#### LOT2SD

```yaml
variable_id: LOT2SD
spec_refs: [treatment:12]
spec_digest: ae061db5a043
required_rule: "Start date of line 2 (non-maintenance): the startdate recorded in the LineOfTherapy table where linenumber=2 AND ismaintenancetherapy=FALSE."
source: {kind: vendor, inputs: {lot: {line_start: startdate, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=2 AND ismaintenancetherapy=FALSE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "startdate where linenumber=2 AND ismaintenancetherapy=FALSE. Line assignment and maintenance flag are vendor-delivered and undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort); the COHORTU=2 -> 'NONE' rule is stated for regimen names, not restated for dates"
missing: {no_record: "patient reaches fewer than 2 lines -> no line-2 record", present_null: "startdate null on the line-2 record -> null"}
units: date
depends_on: []
output: {physical_name: lot2sd, target_published_name: LOT2SD, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line-2 startdate=2020-06-01 -> LOT2SD=2020-06-01"
notes: "Family LOTiSD (i=1..5). Read from t_lineoftherapy_&date (macro-templated; no physical_stem set). Decision_required is inherited from the unstated line/maintenance construction, not from the date read itself."
```

#### LOT3SD

```yaml
variable_id: LOT3SD
spec_refs: [treatment:13]
spec_digest: b935bf6f0c64
required_rule: "Start date of line 3 (non-maintenance): the startdate recorded in the LineOfTherapy table where linenumber=3 AND ismaintenancetherapy=FALSE."
source: {kind: vendor, inputs: {lot: {line_start: startdate, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=3 AND ismaintenancetherapy=FALSE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "startdate where linenumber=3 AND ismaintenancetherapy=FALSE. Line assignment and maintenance flag are vendor-delivered and undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort); the COHORTU=2 -> 'NONE' rule is stated for regimen names, not restated for dates"
missing: {no_record: "patient reaches fewer than 3 lines -> no line-3 record", present_null: "startdate null on the line-3 record -> null"}
units: date
depends_on: []
output: {physical_name: lot3sd, target_published_name: LOT3SD, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line-3 startdate=2020-06-01 -> LOT3SD=2020-06-01"
notes: "Family LOTiSD (i=1..5). Read from t_lineoftherapy_&date (macro-templated; no physical_stem set). Decision_required is inherited from the unstated line/maintenance construction, not from the date read itself."
```

#### LOT4SD

```yaml
variable_id: LOT4SD
spec_refs: [treatment:14]
spec_digest: 1d92f9b0e87e
required_rule: "Start date of line 4 (non-maintenance): the startdate recorded in the LineOfTherapy table where linenumber=4 AND ismaintenancetherapy=FALSE."
source: {kind: vendor, inputs: {lot: {line_start: startdate, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=4 AND ismaintenancetherapy=FALSE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "startdate where linenumber=4 AND ismaintenancetherapy=FALSE. Line assignment and maintenance flag are vendor-delivered and undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort); the COHORTU=2 -> 'NONE' rule is stated for regimen names, not restated for dates"
missing: {no_record: "patient reaches fewer than 4 lines -> no line-4 record", present_null: "startdate null on the line-4 record -> null"}
units: date
depends_on: []
output: {physical_name: lot4sd, target_published_name: LOT4SD, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line-4 startdate=2020-06-01 -> LOT4SD=2020-06-01"
notes: "Family LOTiSD (i=1..5). Read from t_lineoftherapy_&date (macro-templated; no physical_stem set). Decision_required is inherited from the unstated line/maintenance construction, not from the date read itself."
```

#### LOT5SD

```yaml
variable_id: LOT5SD
spec_refs: [treatment:15]
spec_digest: 773254a8ab1b
required_rule: "Start date of line 5 (non-maintenance): the startdate recorded in the LineOfTherapy table where linenumber=5 AND ismaintenancetherapy=FALSE."
source: {kind: vendor, inputs: {lot: {line_start: startdate, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=5 AND ismaintenancetherapy=FALSE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "startdate where linenumber=5 AND ismaintenancetherapy=FALSE. Line assignment and maintenance flag are vendor-delivered and undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort); the COHORTU=2 -> 'NONE' rule is stated for regimen names, not restated for dates"
missing: {no_record: "patient reaches fewer than 5 lines -> no line-5 record", present_null: "startdate null on the line-5 record -> null"}
units: date
depends_on: []
output: {physical_name: lot5sd, target_published_name: LOT5SD, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line-5 startdate=2020-06-01 -> LOT5SD=2020-06-01"
notes: "Family LOTiSD (i=1..5). Read from t_lineoftherapy_&date (macro-templated; no physical_stem set). Decision_required is inherited from the unstated line/maintenance construction, not from the date read itself."
```

#### LOT1ED

```yaml
variable_id: LOT1ED
spec_refs: [treatment:16]
spec_digest: 2a051b165b51
required_rule: "End date of line 1 (non-maintenance): the maximum EPISODEDATE_SASDT in the DrugEpisode table where linenumber=1 AND ismaintenancetherapy=FALSE."
source: {kind: vendor, inputs: {drugepisode: {episode_date: EPISODEDATE_SASDT, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "max(EPISODEDATE_SASDT) over DrugEpisode rows with linenumber=1 AND ismaintenancetherapy=FALSE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(EPISODEDATE_SASDT) where linenumber=1 AND ismaintenancetherapy=FALSE. The definition (DrugEpisode max) and the source Additional Notes (LineOfTherapy.enddate) disagree on the end-date source (TX-A-ED-SOURCE-CONFLICT); the definition cell governs. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "patient reaches fewer than 1 lines -> no line-1 record", present_null: "no DrugEpisode row for line 1 -> LOT1ED null"}
units: date
depends_on: []
output: {physical_name: lot1ed, target_published_name: LOT1ED, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line-1 DrugEpisode rows with max EPISODEDATE_SASDT=2020-08-15 -> LOT1ED=2020-08-15"
notes: "Family LOTiED (i=1..5). Drafted to the definition cell (DrugEpisode max) despite the LineOfTherapy.enddate conflict recorded as TX-A-ED-SOURCE-CONFLICT. Read from t_&cohort_drugepisode_&date (macro-templated; no physical_stem set)."
```

#### LOT2ED

```yaml
variable_id: LOT2ED
spec_refs: [treatment:17]
spec_digest: 6a55bb07b124
required_rule: "End date of line 2 (non-maintenance): the maximum EPISODEDATE_SASDT in the DrugEpisode table where linenumber=2 AND ismaintenancetherapy=FALSE."
source: {kind: vendor, inputs: {drugepisode: {episode_date: EPISODEDATE_SASDT, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "max(EPISODEDATE_SASDT) over DrugEpisode rows with linenumber=2 AND ismaintenancetherapy=FALSE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(EPISODEDATE_SASDT) where linenumber=2 AND ismaintenancetherapy=FALSE. The definition (DrugEpisode max) and the source Additional Notes (LineOfTherapy.enddate) disagree on the end-date source (TX-A-ED-SOURCE-CONFLICT); the definition cell governs. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "patient reaches fewer than 2 lines -> no line-2 record", present_null: "no DrugEpisode row for line 2 -> LOT2ED null"}
units: date
depends_on: []
output: {physical_name: lot2ed, target_published_name: LOT2ED, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line-2 DrugEpisode rows with max EPISODEDATE_SASDT=2020-08-15 -> LOT2ED=2020-08-15"
notes: "Family LOTiED (i=1..5). Drafted to the definition cell (DrugEpisode max) despite the LineOfTherapy.enddate conflict recorded as TX-A-ED-SOURCE-CONFLICT. Read from t_&cohort_drugepisode_&date (macro-templated; no physical_stem set)."
```

#### LOT3ED

```yaml
variable_id: LOT3ED
spec_refs: [treatment:18]
spec_digest: fa22e385e2ea
required_rule: "End date of line 3 (non-maintenance): the maximum EPISODEDATE_SASDT in the DrugEpisode table where linenumber=3 AND ismaintenancetherapy=FALSE."
source: {kind: vendor, inputs: {drugepisode: {episode_date: EPISODEDATE_SASDT, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "max(EPISODEDATE_SASDT) over DrugEpisode rows with linenumber=3 AND ismaintenancetherapy=FALSE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(EPISODEDATE_SASDT) where linenumber=3 AND ismaintenancetherapy=FALSE. The definition (DrugEpisode max) and the source Additional Notes (LineOfTherapy.enddate) disagree on the end-date source (TX-A-ED-SOURCE-CONFLICT); the definition cell governs. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "patient reaches fewer than 3 lines -> no line-3 record", present_null: "no DrugEpisode row for line 3 -> LOT3ED null"}
units: date
depends_on: []
output: {physical_name: lot3ed, target_published_name: LOT3ED, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line-3 DrugEpisode rows with max EPISODEDATE_SASDT=2020-08-15 -> LOT3ED=2020-08-15"
notes: "Family LOTiED (i=1..5). Drafted to the definition cell (DrugEpisode max) despite the LineOfTherapy.enddate conflict recorded as TX-A-ED-SOURCE-CONFLICT. Read from t_&cohort_drugepisode_&date (macro-templated; no physical_stem set)."
```

#### LOT4ED

```yaml
variable_id: LOT4ED
spec_refs: [treatment:19]
spec_digest: e06af60b42a3
required_rule: "End date of line 4 (non-maintenance): the maximum EPISODEDATE_SASDT in the DrugEpisode table where linenumber=4 AND ismaintenancetherapy=FALSE."
source: {kind: vendor, inputs: {drugepisode: {episode_date: EPISODEDATE_SASDT, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "max(EPISODEDATE_SASDT) over DrugEpisode rows with linenumber=4 AND ismaintenancetherapy=FALSE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(EPISODEDATE_SASDT) where linenumber=4 AND ismaintenancetherapy=FALSE. The definition (DrugEpisode max) and the source Additional Notes (LineOfTherapy.enddate) disagree on the end-date source (TX-A-ED-SOURCE-CONFLICT); the definition cell governs. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "patient reaches fewer than 4 lines -> no line-4 record", present_null: "no DrugEpisode row for line 4 -> LOT4ED null"}
units: date
depends_on: []
output: {physical_name: lot4ed, target_published_name: LOT4ED, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line-4 DrugEpisode rows with max EPISODEDATE_SASDT=2020-08-15 -> LOT4ED=2020-08-15"
notes: "Family LOTiED (i=1..5). Drafted to the definition cell (DrugEpisode max) despite the LineOfTherapy.enddate conflict recorded as TX-A-ED-SOURCE-CONFLICT. Read from t_&cohort_drugepisode_&date (macro-templated; no physical_stem set)."
```

#### LOT5ED

```yaml
variable_id: LOT5ED
spec_refs: [treatment:20]
spec_digest: ead7aa900657
required_rule: "End date of line 5 (non-maintenance): the maximum EPISODEDATE_SASDT in the DrugEpisode table where linenumber=5 AND ismaintenancetherapy=FALSE."
source: {kind: vendor, inputs: {drugepisode: {episode_date: EPISODEDATE_SASDT, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "max(EPISODEDATE_SASDT) over DrugEpisode rows with linenumber=5 AND ismaintenancetherapy=FALSE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(EPISODEDATE_SASDT) where linenumber=5 AND ismaintenancetherapy=FALSE. The definition (DrugEpisode max) and the source Additional Notes (LineOfTherapy.enddate) disagree on the end-date source (TX-A-ED-SOURCE-CONFLICT); the definition cell governs. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "patient reaches fewer than 5 lines -> no line-5 record", present_null: "no DrugEpisode row for line 5 -> LOT5ED null"}
units: date
depends_on: []
output: {physical_name: lot5ed, target_published_name: LOT5ED, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line-5 DrugEpisode rows with max EPISODEDATE_SASDT=2020-08-15 -> LOT5ED=2020-08-15"
notes: "Family LOTiED (i=1..5). Drafted to the definition cell (DrugEpisode max) despite the LineOfTherapy.enddate conflict recorded as TX-A-ED-SOURCE-CONFLICT. Read from t_&cohort_drugepisode_&date (macro-templated; no physical_stem set)."
```

#### LOT1M

```yaml
variable_id: LOT1M
spec_refs: [treatment:21]
spec_digest: 2fa71032b64b
required_rule: "Maintenance regimen name for line 1: the linename in the LineOfTherapy table where linenumber=1 AND ismaintenancetherapy=TRUE. COHORTU=2 -> 'NONE'."
source: {kind: vendor, inputs: {lot: {line_name: linename, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=1 AND ismaintenancetherapy=TRUE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "COHORTU=1 -> linename where linenumber=1 AND ismaintenancetherapy=TRUE; COHORTU=2 -> 'NONE'. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts; COHORTU=1 -> actual maintenance regimen, COHORTU=2 -> 'NONE' (per the Values cell; index date differs per cohort)"
missing: {no_record: "line 1 has no maintenance therapy -> no line-1 maintenance record; fill value not stated (not invented)", present_null: "linename null on the maintenance line-1 record -> null"}
units: n/a
depends_on: []
output: {physical_name: lot1m, target_published_name: LOT1M, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "COHORTU=1 patient with a line-1 maintenance linename='Niraparib' -> LOT1M='Niraparib'; COHORTU=2 -> LOT1M='NONE'"
notes: "Family LOTiM (i=1..5), a regimen-name STRING. The Values cell reads 'Date' (PLACEHOLDER) for this name variable and carries the COHORTU=2 -> 'NONE' rule -- recorded as TX-A-LOTM-VALUES-DATE; drafted as string per the label/definition. Read from t_lineoftherapy_&date."
```

#### LOT2M

```yaml
variable_id: LOT2M
spec_refs: [treatment:22]
spec_digest: e84659a85e05
required_rule: "Maintenance regimen name for line 2: the linename in the LineOfTherapy table where linenumber=2 AND ismaintenancetherapy=TRUE. COHORTU=2 -> 'NONE'."
source: {kind: vendor, inputs: {lot: {line_name: linename, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=2 AND ismaintenancetherapy=TRUE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "COHORTU=1 -> linename where linenumber=2 AND ismaintenancetherapy=TRUE; COHORTU=2 -> 'NONE'. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts; COHORTU=1 -> actual maintenance regimen, COHORTU=2 -> 'NONE' (per the Values cell; index date differs per cohort)"
missing: {no_record: "line 2 has no maintenance therapy -> no line-2 maintenance record; fill value not stated (not invented)", present_null: "linename null on the maintenance line-2 record -> null"}
units: n/a
depends_on: []
output: {physical_name: lot2m, target_published_name: LOT2M, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "COHORTU=1 patient with a line-2 maintenance linename='Niraparib' -> LOT2M='Niraparib'; COHORTU=2 -> LOT2M='NONE'"
notes: "Family LOTiM (i=1..5), a regimen-name STRING. The Values cell reads 'Date' (PLACEHOLDER) for this name variable and carries the COHORTU=2 -> 'NONE' rule -- recorded as TX-A-LOTM-VALUES-DATE; drafted as string per the label/definition. Read from t_lineoftherapy_&date."
```

#### LOT3M

```yaml
variable_id: LOT3M
spec_refs: [treatment:23]
spec_digest: 9722c7c5e88c
required_rule: "Maintenance regimen name for line 3: the linename in the LineOfTherapy table where linenumber=3 AND ismaintenancetherapy=TRUE. COHORTU=2 -> 'NONE'."
source: {kind: vendor, inputs: {lot: {line_name: linename, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=3 AND ismaintenancetherapy=TRUE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "COHORTU=1 -> linename where linenumber=3 AND ismaintenancetherapy=TRUE; COHORTU=2 -> 'NONE'. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts; COHORTU=1 -> actual maintenance regimen, COHORTU=2 -> 'NONE' (per the Values cell; index date differs per cohort)"
missing: {no_record: "line 3 has no maintenance therapy -> no line-3 maintenance record; fill value not stated (not invented)", present_null: "linename null on the maintenance line-3 record -> null"}
units: n/a
depends_on: []
output: {physical_name: lot3m, target_published_name: LOT3M, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "COHORTU=1 patient with a line-3 maintenance linename='Niraparib' -> LOT3M='Niraparib'; COHORTU=2 -> LOT3M='NONE'"
notes: "Family LOTiM (i=1..5), a regimen-name STRING. The Values cell reads 'Date' (PLACEHOLDER) for this name variable and carries the COHORTU=2 -> 'NONE' rule -- recorded as TX-A-LOTM-VALUES-DATE; drafted as string per the label/definition. Read from t_lineoftherapy_&date."
```

#### LOT4M

```yaml
variable_id: LOT4M
spec_refs: [treatment:24]
spec_digest: 037dc2a3f5ea
required_rule: "Maintenance regimen name for line 4: the linename in the LineOfTherapy table where linenumber=4 AND ismaintenancetherapy=TRUE. COHORTU=2 -> 'NONE'."
source: {kind: vendor, inputs: {lot: {line_name: linename, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=4 AND ismaintenancetherapy=TRUE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "COHORTU=1 -> linename where linenumber=4 AND ismaintenancetherapy=TRUE; COHORTU=2 -> 'NONE'. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts; COHORTU=1 -> actual maintenance regimen, COHORTU=2 -> 'NONE' (per the Values cell; index date differs per cohort)"
missing: {no_record: "line 4 has no maintenance therapy -> no line-4 maintenance record; fill value not stated (not invented)", present_null: "linename null on the maintenance line-4 record -> null"}
units: n/a
depends_on: []
output: {physical_name: lot4m, target_published_name: LOT4M, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "COHORTU=1 patient with a line-4 maintenance linename='Niraparib' -> LOT4M='Niraparib'; COHORTU=2 -> LOT4M='NONE'"
notes: "Family LOTiM (i=1..5), a regimen-name STRING. The Values cell reads 'Date' (PLACEHOLDER) for this name variable and carries the COHORTU=2 -> 'NONE' rule -- recorded as TX-A-LOTM-VALUES-DATE; drafted as string per the label/definition. Read from t_lineoftherapy_&date."
```

#### LOT5M

```yaml
variable_id: LOT5M
spec_refs: [treatment:25]
spec_digest: 1731b06c4b53
required_rule: "Maintenance regimen name for line 5: the linename in the LineOfTherapy table where linenumber=5 AND ismaintenancetherapy=TRUE. COHORTU=2 -> 'NONE'."
source: {kind: vendor, inputs: {lot: {line_name: linename, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=5 AND ismaintenancetherapy=TRUE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "COHORTU=1 -> linename where linenumber=5 AND ismaintenancetherapy=TRUE; COHORTU=2 -> 'NONE'. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts; COHORTU=1 -> actual maintenance regimen, COHORTU=2 -> 'NONE' (per the Values cell; index date differs per cohort)"
missing: {no_record: "line 5 has no maintenance therapy -> no line-5 maintenance record; fill value not stated (not invented)", present_null: "linename null on the maintenance line-5 record -> null"}
units: n/a
depends_on: []
output: {physical_name: lot5m, target_published_name: LOT5M, name_status: undecided, type: string, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "COHORTU=1 patient with a line-5 maintenance linename='Niraparib' -> LOT5M='Niraparib'; COHORTU=2 -> LOT5M='NONE'"
notes: "Family LOTiM (i=1..5), a regimen-name STRING. The Values cell reads 'Date' (PLACEHOLDER) for this name variable and carries the COHORTU=2 -> 'NONE' rule -- recorded as TX-A-LOTM-VALUES-DATE; drafted as string per the label/definition. Read from t_lineoftherapy_&date."
```

#### LOT1MSD

```yaml
variable_id: LOT1MSD
spec_refs: [treatment:26]
spec_digest: bd95bf0080f3
required_rule: "Maintenance start date for line 1: the startdate recorded in the LineOfTherapy table where linenumber=1 AND ismaintenancetherapy=TRUE."
source: {kind: vendor, inputs: {lot: {line_start: startdate, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=1 AND ismaintenancetherapy=TRUE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "startdate where linenumber=1 AND ismaintenancetherapy=TRUE. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "line 1 has no maintenance therapy -> no maintenance start-date record", present_null: "startdate null on the maintenance line-1 record -> null"}
units: date
depends_on: []
output: {physical_name: lot1msd, target_published_name: LOT1MSD, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "maintenance line-1 startdate=2020-09-01 -> LOT1MSD=2020-09-01"
notes: "Family LOTiMSD (i=1..5). Read from t_lineoftherapy_&date (macro-templated; no physical_stem set)."
```

#### LOT2MSD

```yaml
variable_id: LOT2MSD
spec_refs: [treatment:27]
spec_digest: 6a67afe8940b
required_rule: "Maintenance start date for line 2: the startdate recorded in the LineOfTherapy table where linenumber=2 AND ismaintenancetherapy=TRUE."
source: {kind: vendor, inputs: {lot: {line_start: startdate, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=2 AND ismaintenancetherapy=TRUE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "startdate where linenumber=2 AND ismaintenancetherapy=TRUE. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "line 2 has no maintenance therapy -> no maintenance start-date record", present_null: "startdate null on the maintenance line-2 record -> null"}
units: date
depends_on: []
output: {physical_name: lot2msd, target_published_name: LOT2MSD, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "maintenance line-2 startdate=2020-09-01 -> LOT2MSD=2020-09-01"
notes: "Family LOTiMSD (i=1..5). Read from t_lineoftherapy_&date (macro-templated; no physical_stem set)."
```

#### LOT3MSD

```yaml
variable_id: LOT3MSD
spec_refs: [treatment:28]
spec_digest: 60894fcf52ba
required_rule: "Maintenance start date for line 3: the startdate recorded in the LineOfTherapy table where linenumber=3 AND ismaintenancetherapy=TRUE."
source: {kind: vendor, inputs: {lot: {line_start: startdate, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=3 AND ismaintenancetherapy=TRUE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "startdate where linenumber=3 AND ismaintenancetherapy=TRUE. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "line 3 has no maintenance therapy -> no maintenance start-date record", present_null: "startdate null on the maintenance line-3 record -> null"}
units: date
depends_on: []
output: {physical_name: lot3msd, target_published_name: LOT3MSD, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "maintenance line-3 startdate=2020-09-01 -> LOT3MSD=2020-09-01"
notes: "Family LOTiMSD (i=1..5). Read from t_lineoftherapy_&date (macro-templated; no physical_stem set)."
```

#### LOT4MSD

```yaml
variable_id: LOT4MSD
spec_refs: [treatment:29]
spec_digest: 646b686b016c
required_rule: "Maintenance start date for line 4: the startdate recorded in the LineOfTherapy table where linenumber=4 AND ismaintenancetherapy=TRUE."
source: {kind: vendor, inputs: {lot: {line_start: startdate, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=4 AND ismaintenancetherapy=TRUE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "startdate where linenumber=4 AND ismaintenancetherapy=TRUE. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "line 4 has no maintenance therapy -> no maintenance start-date record", present_null: "startdate null on the maintenance line-4 record -> null"}
units: date
depends_on: []
output: {physical_name: lot4msd, target_published_name: LOT4MSD, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "maintenance line-4 startdate=2020-09-01 -> LOT4MSD=2020-09-01"
notes: "Family LOTiMSD (i=1..5). Read from t_lineoftherapy_&date (macro-templated; no physical_stem set)."
```

#### LOT5MSD

```yaml
variable_id: LOT5MSD
spec_refs: [treatment:30]
spec_digest: e131af2141ac
required_rule: "Maintenance start date for line 5: the startdate recorded in the LineOfTherapy table where linenumber=5 AND ismaintenancetherapy=TRUE."
source: {kind: vendor, inputs: {lot: {line_start: startdate, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "the LineOfTherapy row with linenumber=5 AND ismaintenancetherapy=TRUE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "startdate where linenumber=5 AND ismaintenancetherapy=TRUE. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "line 5 has no maintenance therapy -> no maintenance start-date record", present_null: "startdate null on the maintenance line-5 record -> null"}
units: date
depends_on: []
output: {physical_name: lot5msd, target_published_name: LOT5MSD, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "maintenance line-5 startdate=2020-09-01 -> LOT5MSD=2020-09-01"
notes: "Family LOTiMSD (i=1..5). Read from t_lineoftherapy_&date (macro-templated; no physical_stem set)."
```

#### LOT1MED

```yaml
variable_id: LOT1MED
spec_refs: [treatment:31]
spec_digest: 1a3a91197bd4
required_rule: "Maintenance end date for line 1 (derived): the maximum EPISODEDATE_SASDT in the DrugEpisode table where linenumber=1 AND ismaintenancetherapy=TRUE."
source: {kind: vendor, inputs: {drugepisode: {episode_date: EPISODEDATE_SASDT, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "max(EPISODEDATE_SASDT) over DrugEpisode rows with linenumber=1 AND ismaintenancetherapy=TRUE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(EPISODEDATE_SASDT) where linenumber=1 AND ismaintenancetherapy=TRUE. Definition (DrugEpisode max) and source Additional Notes (LineOfTherapy.enddate) disagree (TX-A-ED-SOURCE-CONFLICT); the definition cell governs. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "line 1 has no maintenance therapy -> no maintenance end-date record", present_null: "no maintenance DrugEpisode row for line 1 -> LOT1MED null"}
units: date
depends_on: []
output: {physical_name: lot1med, target_published_name: LOT1MED, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "maintenance line-1 DrugEpisode rows with max EPISODEDATE_SASDT=2021-01-10 -> LOT1MED=2021-01-10"
notes: "Family LOTiMED (i=1..5). Source Variable cell printed 'LOTiED' (a name collision with the non-maintenance end dates) -- recorded as format finding TX-A-MED-VARNAME; drafted under the intended name LOT1MED. End-date source conflict TX-A-ED-SOURCE-CONFLICT also applies."
```

#### LOT2MED

```yaml
variable_id: LOT2MED
spec_refs: [treatment:32]
spec_digest: d479d3f35190
required_rule: "Maintenance end date for line 2 (derived): the maximum EPISODEDATE_SASDT in the DrugEpisode table where linenumber=2 AND ismaintenancetherapy=TRUE."
source: {kind: vendor, inputs: {drugepisode: {episode_date: EPISODEDATE_SASDT, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "max(EPISODEDATE_SASDT) over DrugEpisode rows with linenumber=2 AND ismaintenancetherapy=TRUE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(EPISODEDATE_SASDT) where linenumber=2 AND ismaintenancetherapy=TRUE. Definition (DrugEpisode max) and source Additional Notes (LineOfTherapy.enddate) disagree (TX-A-ED-SOURCE-CONFLICT); the definition cell governs. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "line 2 has no maintenance therapy -> no maintenance end-date record", present_null: "no maintenance DrugEpisode row for line 2 -> LOT2MED null"}
units: date
depends_on: []
output: {physical_name: lot2med, target_published_name: LOT2MED, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "maintenance line-2 DrugEpisode rows with max EPISODEDATE_SASDT=2021-01-10 -> LOT2MED=2021-01-10"
notes: "Family LOTiMED (i=1..5). Source Variable cell printed 'LOTiED' (a name collision with the non-maintenance end dates) -- recorded as format finding TX-A-MED-VARNAME; drafted under the intended name LOT2MED. End-date source conflict TX-A-ED-SOURCE-CONFLICT also applies."
```

#### LOT3MED

```yaml
variable_id: LOT3MED
spec_refs: [treatment:33]
spec_digest: 4bf9ac6d1d32
required_rule: "Maintenance end date for line 3 (derived): the maximum EPISODEDATE_SASDT in the DrugEpisode table where linenumber=3 AND ismaintenancetherapy=TRUE."
source: {kind: vendor, inputs: {drugepisode: {episode_date: EPISODEDATE_SASDT, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "max(EPISODEDATE_SASDT) over DrugEpisode rows with linenumber=3 AND ismaintenancetherapy=TRUE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(EPISODEDATE_SASDT) where linenumber=3 AND ismaintenancetherapy=TRUE. Definition (DrugEpisode max) and source Additional Notes (LineOfTherapy.enddate) disagree (TX-A-ED-SOURCE-CONFLICT); the definition cell governs. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "line 3 has no maintenance therapy -> no maintenance end-date record", present_null: "no maintenance DrugEpisode row for line 3 -> LOT3MED null"}
units: date
depends_on: []
output: {physical_name: lot3med, target_published_name: LOT3MED, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "maintenance line-3 DrugEpisode rows with max EPISODEDATE_SASDT=2021-01-10 -> LOT3MED=2021-01-10"
notes: "Family LOTiMED (i=1..5). Source Variable cell printed 'LOTiED' (a name collision with the non-maintenance end dates) -- recorded as format finding TX-A-MED-VARNAME; drafted under the intended name LOT3MED. End-date source conflict TX-A-ED-SOURCE-CONFLICT also applies."
```

#### LOT4MED

```yaml
variable_id: LOT4MED
spec_refs: [treatment:34]
spec_digest: d291b9836d24
required_rule: "Maintenance end date for line 4 (derived): the maximum EPISODEDATE_SASDT in the DrugEpisode table where linenumber=4 AND ismaintenancetherapy=TRUE."
source: {kind: vendor, inputs: {drugepisode: {episode_date: EPISODEDATE_SASDT, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "max(EPISODEDATE_SASDT) over DrugEpisode rows with linenumber=4 AND ismaintenancetherapy=TRUE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(EPISODEDATE_SASDT) where linenumber=4 AND ismaintenancetherapy=TRUE. Definition (DrugEpisode max) and source Additional Notes (LineOfTherapy.enddate) disagree (TX-A-ED-SOURCE-CONFLICT); the definition cell governs. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "line 4 has no maintenance therapy -> no maintenance end-date record", present_null: "no maintenance DrugEpisode row for line 4 -> LOT4MED null"}
units: date
depends_on: []
output: {physical_name: lot4med, target_published_name: LOT4MED, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "maintenance line-4 DrugEpisode rows with max EPISODEDATE_SASDT=2021-01-10 -> LOT4MED=2021-01-10"
notes: "Family LOTiMED (i=1..5). Source Variable cell printed 'LOTiED' (a name collision with the non-maintenance end dates) -- recorded as format finding TX-A-MED-VARNAME; drafted under the intended name LOT4MED. End-date source conflict TX-A-ED-SOURCE-CONFLICT also applies."
```

#### LOT5MED

```yaml
variable_id: LOT5MED
spec_refs: [treatment:35]
spec_digest: 274c7f16b79e
required_rule: "Maintenance end date for line 5 (derived): the maximum EPISODEDATE_SASDT in the DrugEpisode table where linenumber=5 AND ismaintenancetherapy=TRUE."
source: {kind: vendor, inputs: {drugepisode: {episode_date: EPISODEDATE_SASDT, line_number: linenumber, is_maintenance: ismaintenancetherapy}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "max(EPISODEDATE_SASDT) over DrugEpisode rows with linenumber=5 AND ismaintenancetherapy=TRUE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "max(EPISODEDATE_SASDT) where linenumber=5 AND ismaintenancetherapy=TRUE. Definition (DrugEpisode max) and source Additional Notes (LineOfTherapy.enddate) disagree (TX-A-ED-SOURCE-CONFLICT); the definition cell governs. Line/maintenance construction undefined in-spec (BLOCKED: TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION)."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "line 5 has no maintenance therapy -> no maintenance end-date record", present_null: "no maintenance DrugEpisode row for line 5 -> LOT5MED null"}
units: date
depends_on: []
output: {physical_name: lot5med, target_published_name: LOT5MED, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "maintenance line-5 DrugEpisode rows with max EPISODEDATE_SASDT=2021-01-10 -> LOT5MED=2021-01-10"
notes: "Family LOTiMED (i=1..5). Source Variable cell printed 'LOTiED' (a name collision with the non-maintenance end dates) -- recorded as format finding TX-A-MED-VARNAME; drafted under the intended name LOT5MED. End-date source conflict TX-A-ED-SOURCE-CONFLICT also applies."
```

#### LOT1DUR

```yaml
variable_id: LOT1DUR
spec_refs: [treatment:36]
spec_digest: d987549ecbf4
required_rule: "Duration of line 1 in days = LOT1ED - LOT1SD + 1 (both endpoints inclusive)."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "(LOT1ED - LOT1SD) + 1, in days."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "no line-1 record -> no duration", present_null: "LOT1ED or LOT1SD null -> LOT1DUR null"}
units: days
depends_on: [LOT1ED, LOT1SD]
output: {physical_name: lot1dur, target_published_name: LOT1DUR, name_status: undecided, type: integer, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "LOT1SD=2020-06-01, LOT1ED=2020-06-30 -> LOT1DUR=30"
notes: "Family LOTiDUR (i=1..5). The formula is fully stated, so this is draft; its inputs LOT1ED/LOT1SD are themselves decision_required (TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION), which propagates via depends_on, not via this record's status. +1 makes the interval inclusive of both endpoints."
```

#### LOT2DUR

```yaml
variable_id: LOT2DUR
spec_refs: [treatment:37]
spec_digest: 1711bb7ebc3b
required_rule: "Duration of line 2 in days = LOT2ED - LOT2SD + 1 (both endpoints inclusive)."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "(LOT2ED - LOT2SD) + 1, in days."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "no line-2 record -> no duration", present_null: "LOT2ED or LOT2SD null -> LOT2DUR null"}
units: days
depends_on: [LOT2ED, LOT2SD]
output: {physical_name: lot2dur, target_published_name: LOT2DUR, name_status: undecided, type: integer, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "LOT2SD=2020-06-01, LOT2ED=2020-06-30 -> LOT2DUR=30"
notes: "Family LOTiDUR (i=1..5). The formula is fully stated, so this is draft; its inputs LOT2ED/LOT2SD are themselves decision_required (TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION), which propagates via depends_on, not via this record's status. +1 makes the interval inclusive of both endpoints."
```

#### LOT3DUR

```yaml
variable_id: LOT3DUR
spec_refs: [treatment:38]
spec_digest: 4982782902d8
required_rule: "Duration of line 3 in days = LOT3ED - LOT3SD + 1 (both endpoints inclusive)."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "(LOT3ED - LOT3SD) + 1, in days."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "no line-3 record -> no duration", present_null: "LOT3ED or LOT3SD null -> LOT3DUR null"}
units: days
depends_on: [LOT3ED, LOT3SD]
output: {physical_name: lot3dur, target_published_name: LOT3DUR, name_status: undecided, type: integer, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "LOT3SD=2020-06-01, LOT3ED=2020-06-30 -> LOT3DUR=30"
notes: "Family LOTiDUR (i=1..5). The formula is fully stated, so this is draft; its inputs LOT3ED/LOT3SD are themselves decision_required (TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION), which propagates via depends_on, not via this record's status. +1 makes the interval inclusive of both endpoints."
```

#### LOT4DUR

```yaml
variable_id: LOT4DUR
spec_refs: [treatment:39]
spec_digest: 1079be603c9e
required_rule: "Duration of line 4 in days = LOT4ED - LOT4SD + 1 (both endpoints inclusive)."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "(LOT4ED - LOT4SD) + 1, in days."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "no line-4 record -> no duration", present_null: "LOT4ED or LOT4SD null -> LOT4DUR null"}
units: days
depends_on: [LOT4ED, LOT4SD]
output: {physical_name: lot4dur, target_published_name: LOT4DUR, name_status: undecided, type: integer, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "LOT4SD=2020-06-01, LOT4ED=2020-06-30 -> LOT4DUR=30"
notes: "Family LOTiDUR (i=1..5). The formula is fully stated, so this is draft; its inputs LOT4ED/LOT4SD are themselves decision_required (TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION), which propagates via depends_on, not via this record's status. +1 makes the interval inclusive of both endpoints."
```

#### LOT5DUR

```yaml
variable_id: LOT5DUR
spec_refs: [treatment:40]
spec_digest: ed92c14a50ab
required_rule: "Duration of line 5 in days = LOT5ED - LOT5SD + 1 (both endpoints inclusive)."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "(LOT5ED - LOT5SD) + 1, in days."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "no line-5 record -> no duration", present_null: "LOT5ED or LOT5SD null -> LOT5DUR null"}
units: days
depends_on: [LOT5ED, LOT5SD]
output: {physical_name: lot5dur, target_published_name: LOT5DUR, name_status: undecided, type: integer, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "LOT5SD=2020-06-01, LOT5ED=2020-06-30 -> LOT5DUR=30"
notes: "Family LOTiDUR (i=1..5). The formula is fully stated, so this is draft; its inputs LOT5ED/LOT5SD are themselves decision_required (TX-A-LOT-DEFINITION, TX-A-MAINT-DEFINITION), which propagates via depends_on, not via this record's status. +1 makes the interval inclusive of both endpoints."
```

#### LOT1mDUR

```yaml
variable_id: LOT1mDUR
spec_refs: [treatment:41]
spec_digest: a95eb0e2e2b4
required_rule: "Duration of maintenance line 1 in days = LOT1MED - LOT1MSD + 1 (both endpoints inclusive)."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "(LOT1MED - LOT1MSD) + 1, in days."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "line 1 has no maintenance therapy -> no maintenance duration", present_null: "LOT1MED or LOT1MSD null -> LOT1mDUR null"}
units: days
depends_on: [LOT1MED, LOT1MSD]
output: {physical_name: lot1mdur, target_published_name: LOT1mDUR, name_status: undecided, type: integer, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "LOT1MSD=2020-09-01, LOT1MED=2020-09-30 -> LOT1mDUR=30"
notes: "Family LOTimDUR (i=1..5). The formula is fully stated, so this is draft; its inputs are decision_required (propagated via depends_on). Source Variable cell printed 'LOTiDUR' (collision with the non-maintenance durations) -- recorded as format finding TX-A-MDUR-VARNAME; drafted under the intended name LOT1mDUR."
```

#### LOT2mDUR

```yaml
variable_id: LOT2mDUR
spec_refs: [treatment:42]
spec_digest: 398c2c67efa8
required_rule: "Duration of maintenance line 2 in days = LOT2MED - LOT2MSD + 1 (both endpoints inclusive)."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "(LOT2MED - LOT2MSD) + 1, in days."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "line 2 has no maintenance therapy -> no maintenance duration", present_null: "LOT2MED or LOT2MSD null -> LOT2mDUR null"}
units: days
depends_on: [LOT2MED, LOT2MSD]
output: {physical_name: lot2mdur, target_published_name: LOT2mDUR, name_status: undecided, type: integer, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "LOT2MSD=2020-09-01, LOT2MED=2020-09-30 -> LOT2mDUR=30"
notes: "Family LOTimDUR (i=1..5). The formula is fully stated, so this is draft; its inputs are decision_required (propagated via depends_on). Source Variable cell printed 'LOTiDUR' (collision with the non-maintenance durations) -- recorded as format finding TX-A-MDUR-VARNAME; drafted under the intended name LOT2mDUR."
```

#### LOT3mDUR

```yaml
variable_id: LOT3mDUR
spec_refs: [treatment:43]
spec_digest: 3c375af8a080
required_rule: "Duration of maintenance line 3 in days = LOT3MED - LOT3MSD + 1 (both endpoints inclusive)."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "(LOT3MED - LOT3MSD) + 1, in days."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "line 3 has no maintenance therapy -> no maintenance duration", present_null: "LOT3MED or LOT3MSD null -> LOT3mDUR null"}
units: days
depends_on: [LOT3MED, LOT3MSD]
output: {physical_name: lot3mdur, target_published_name: LOT3mDUR, name_status: undecided, type: integer, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "LOT3MSD=2020-09-01, LOT3MED=2020-09-30 -> LOT3mDUR=30"
notes: "Family LOTimDUR (i=1..5). The formula is fully stated, so this is draft; its inputs are decision_required (propagated via depends_on). Source Variable cell printed 'LOTiDUR' (collision with the non-maintenance durations) -- recorded as format finding TX-A-MDUR-VARNAME; drafted under the intended name LOT3mDUR."
```

#### LOT4mDUR

```yaml
variable_id: LOT4mDUR
spec_refs: [treatment:44]
spec_digest: bc3d68acfa93
required_rule: "Duration of maintenance line 4 in days = LOT4MED - LOT4MSD + 1 (both endpoints inclusive)."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "(LOT4MED - LOT4MSD) + 1, in days."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "line 4 has no maintenance therapy -> no maintenance duration", present_null: "LOT4MED or LOT4MSD null -> LOT4mDUR null"}
units: days
depends_on: [LOT4MED, LOT4MSD]
output: {physical_name: lot4mdur, target_published_name: LOT4mDUR, name_status: undecided, type: integer, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "LOT4MSD=2020-09-01, LOT4MED=2020-09-30 -> LOT4mDUR=30"
notes: "Family LOTimDUR (i=1..5). The formula is fully stated, so this is draft; its inputs are decision_required (propagated via depends_on). Source Variable cell printed 'LOTiDUR' (collision with the non-maintenance durations) -- recorded as format finding TX-A-MDUR-VARNAME; drafted under the intended name LOT4mDUR."
```

#### LOT5mDUR

```yaml
variable_id: LOT5mDUR
spec_refs: [treatment:45]
spec_digest: 5769ecfb3a83
required_rule: "Duration of maintenance line 5 in days = LOT5MED - LOT5MSD + 1 (both endpoints inclusive)."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "(LOT5MED - LOT5MSD) + 1, in days."
cohort_applicability: "all cohorts (index date differs per cohort)"
missing: {no_record: "line 5 has no maintenance therapy -> no maintenance duration", present_null: "LOT5MED or LOT5MSD null -> LOT5mDUR null"}
units: days
depends_on: [LOT5MED, LOT5MSD]
output: {physical_name: lot5mdur, target_published_name: LOT5mDUR, name_status: undecided, type: integer, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "LOT5MSD=2020-09-01, LOT5MED=2020-09-30 -> LOT5mDUR=30"
notes: "Family LOTimDUR (i=1..5). The formula is fully stated, so this is draft; its inputs are decision_required (propagated via depends_on). Source Variable cell printed 'LOTiDUR' (collision with the non-maintenance durations) -- recorded as format finding TX-A-MDUR-VARNAME; drafted under the intended name LOT5mDUR."
```


## treatment — TX-B

#### L1PLAT

```yaml
variable_id: L1PLAT
spec_refs: [treatment:46]
spec_digest: 971c0c6043f3
required_rule: "Received platinum chemotherapy in line 1 (1=Yes/0=No): 1 if any qualifying drug-episode of line 1 (linenumber=1 AND ismaintenance='False') has a regimen name containing 'platin', else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 1 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='False'; flag=1 if any such episode regimen/linename contains substring 'platin', else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-1 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l1plat, target_published_name: L1PLAT, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 1 has a non-maintenance episode with linename 'Carboplatin' (contains 'platin') -> L1PLAT=1; line 1 with no 'platin' regimen -> 0"
notes: "Platinum class is a substring match on the line regimen name ('platin') per spec, so no separate platinum drug codelist is asserted; if RWB later supplies an explicit platinum agent list it belongs in variables/codelists. Source table t_&cohort_drugepisode_&date. Line composition (linenumber/ismaintenance/linename) is produced by upstream line-of-therapy construction. One record per spec row (LiPLAT family i=1..5)."
```

#### L2PLAT

```yaml
variable_id: L2PLAT
spec_refs: [treatment:47]
spec_digest: 220913c23fc3
required_rule: "Received platinum chemotherapy in line 2 (1=Yes/0=No): 1 if any qualifying drug-episode of line 2 (linenumber=2 AND ismaintenance='False') has a regimen name containing 'platin', else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 2 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='False'; flag=1 if any such episode regimen/linename contains substring 'platin', else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-2 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l2plat, target_published_name: L2PLAT, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 2 has a non-maintenance episode with linename 'Carboplatin' (contains 'platin') -> L2PLAT=1; line 2 with no 'platin' regimen -> 0"
notes: "Platinum class is a substring match on the line regimen name ('platin') per spec, so no separate platinum drug codelist is asserted; if RWB later supplies an explicit platinum agent list it belongs in variables/codelists. Source table t_&cohort_drugepisode_&date. Line composition (linenumber/ismaintenance/linename) is produced by upstream line-of-therapy construction. One record per spec row (LiPLAT family i=1..5)."
```

#### L3PLAT

```yaml
variable_id: L3PLAT
spec_refs: [treatment:48]
spec_digest: 765cd43dd1e0
required_rule: "Received platinum chemotherapy in line 3 (1=Yes/0=No): 1 if any qualifying drug-episode of line 3 (linenumber=3 AND ismaintenance='False') has a regimen name containing 'platin', else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 3 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='False'; flag=1 if any such episode regimen/linename contains substring 'platin', else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-3 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l3plat, target_published_name: L3PLAT, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 3 has a non-maintenance episode with linename 'Carboplatin' (contains 'platin') -> L3PLAT=1; line 3 with no 'platin' regimen -> 0"
notes: "Platinum class is a substring match on the line regimen name ('platin') per spec, so no separate platinum drug codelist is asserted; if RWB later supplies an explicit platinum agent list it belongs in variables/codelists. Source table t_&cohort_drugepisode_&date. Line composition (linenumber/ismaintenance/linename) is produced by upstream line-of-therapy construction. One record per spec row (LiPLAT family i=1..5)."
```

#### L4PLAT

```yaml
variable_id: L4PLAT
spec_refs: [treatment:49]
spec_digest: a95f03eeaf82
required_rule: "Received platinum chemotherapy in line 4 (1=Yes/0=No): 1 if any qualifying drug-episode of line 4 (linenumber=4 AND ismaintenance='False') has a regimen name containing 'platin', else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 4 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='False'; flag=1 if any such episode regimen/linename contains substring 'platin', else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-4 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l4plat, target_published_name: L4PLAT, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 4 has a non-maintenance episode with linename 'Carboplatin' (contains 'platin') -> L4PLAT=1; line 4 with no 'platin' regimen -> 0"
notes: "Platinum class is a substring match on the line regimen name ('platin') per spec, so no separate platinum drug codelist is asserted; if RWB later supplies an explicit platinum agent list it belongs in variables/codelists. Source table t_&cohort_drugepisode_&date. Line composition (linenumber/ismaintenance/linename) is produced by upstream line-of-therapy construction. One record per spec row (LiPLAT family i=1..5)."
```

#### L5PLAT

```yaml
variable_id: L5PLAT
spec_refs: [treatment:50]
spec_digest: 3b4927be8026
required_rule: "Received platinum chemotherapy in line 5 (1=Yes/0=No): 1 if any qualifying drug-episode of line 5 (linenumber=5 AND ismaintenance='False') has a regimen name containing 'platin', else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 5 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='False'; flag=1 if any such episode regimen/linename contains substring 'platin', else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-5 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l5plat, target_published_name: L5PLAT, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 5 has a non-maintenance episode with linename 'Carboplatin' (contains 'platin') -> L5PLAT=1; line 5 with no 'platin' regimen -> 0"
notes: "Platinum class is a substring match on the line regimen name ('platin') per spec, so no separate platinum drug codelist is asserted; if RWB later supplies an explicit platinum agent list it belongs in variables/codelists. Source table t_&cohort_drugepisode_&date. Line composition (linenumber/ismaintenance/linename) is produced by upstream line-of-therapy construction. One record per spec row (LiPLAT family i=1..5)."
```

#### L1BEV

```yaml
variable_id: L1BEV
spec_refs: [treatment:51]
spec_digest: e5091905e4be
required_rule: "Received Bevacizumab in line 1 (1=Yes/0=No): 1 if any qualifying drug-episode of line 1 (linenumber=1 AND ismaintenance='False') has a regimen name containing 'bevacizumab', else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 1 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='False'; flag=1 if any such episode regimen/linename contains substring 'bevacizumab', else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-1 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l1bev, target_published_name: L1BEV, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 1 non-maintenance episode linename contains 'Bevacizumab' -> L1BEV=1; otherwise 0"
notes: "Class match is a substring on the line regimen name ('bevacizumab') per spec. Source table t_&cohort_drugepisode_&date. One record per spec row (LiBEV family i=1..5)."
```

#### L2BEV

```yaml
variable_id: L2BEV
spec_refs: [treatment:52]
spec_digest: 844b7c819269
required_rule: "Received Bevacizumab in line 2 (1=Yes/0=No): 1 if any qualifying drug-episode of line 2 (linenumber=2 AND ismaintenance='False') has a regimen name containing 'bevacizumab', else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 2 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='False'; flag=1 if any such episode regimen/linename contains substring 'bevacizumab', else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-2 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l2bev, target_published_name: L2BEV, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 2 non-maintenance episode linename contains 'Bevacizumab' -> L2BEV=1; otherwise 0"
notes: "Class match is a substring on the line regimen name ('bevacizumab') per spec. Source table t_&cohort_drugepisode_&date. One record per spec row (LiBEV family i=1..5)."
```

#### L3BEV

```yaml
variable_id: L3BEV
spec_refs: [treatment:53]
spec_digest: 0378909199ee
required_rule: "Received Bevacizumab in line 3 (1=Yes/0=No): 1 if any qualifying drug-episode of line 3 (linenumber=3 AND ismaintenance='False') has a regimen name containing 'bevacizumab', else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 3 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='False'; flag=1 if any such episode regimen/linename contains substring 'bevacizumab', else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-3 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l3bev, target_published_name: L3BEV, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 3 non-maintenance episode linename contains 'Bevacizumab' -> L3BEV=1; otherwise 0"
notes: "Class match is a substring on the line regimen name ('bevacizumab') per spec. Source table t_&cohort_drugepisode_&date. One record per spec row (LiBEV family i=1..5)."
```

#### L4BEV

```yaml
variable_id: L4BEV
spec_refs: [treatment:54]
spec_digest: f0081727c741
required_rule: "Received Bevacizumab in line 4 (1=Yes/0=No): 1 if any qualifying drug-episode of line 4 (linenumber=4 AND ismaintenance='False') has a regimen name containing 'bevacizumab', else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 4 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='False'; flag=1 if any such episode regimen/linename contains substring 'bevacizumab', else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-4 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l4bev, target_published_name: L4BEV, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 4 non-maintenance episode linename contains 'Bevacizumab' -> L4BEV=1; otherwise 0"
notes: "Class match is a substring on the line regimen name ('bevacizumab') per spec. Source table t_&cohort_drugepisode_&date. One record per spec row (LiBEV family i=1..5)."
```

#### L5BEV

```yaml
variable_id: L5BEV
spec_refs: [treatment:55]
spec_digest: d453930fd285
required_rule: "Received Bevacizumab in line 5 (1=Yes/0=No): 1 if any qualifying drug-episode of line 5 (linenumber=5 AND ismaintenance='False') has a regimen name containing 'bevacizumab', else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 5 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='False'; flag=1 if any such episode regimen/linename contains substring 'bevacizumab', else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-5 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l5bev, target_published_name: L5BEV, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 5 non-maintenance episode linename contains 'Bevacizumab' -> L5BEV=1; otherwise 0"
notes: "Class match is a substring on the line regimen name ('bevacizumab') per spec. Source table t_&cohort_drugepisode_&date. One record per spec row (LiBEV family i=1..5)."
```

#### L1BEVM

```yaml
variable_id: L1BEVM
spec_refs: [treatment:56]
spec_digest: 536ace4c3c0e
required_rule: "Received Bevacizumab maintenance monotherapy in line 1 (1=Yes/0=No): 1 if any qualifying drug-episode of line 1 (linenumber=1 AND ismaintenance='True') has ONLY regimen names containing 'bevacizumab', else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 1 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='True'; flag=1 if the line regimen names contain ONLY 'bevacizumab' (bev-only), else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-1 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l1bevm, target_published_name: L1BEVM, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 1 maintenance episode whose only drug is Bevacizumab -> L1BEVM=1; maintenance line 1 containing Bevacizumab plus another drug -> 0"
notes: "Maintenance monotherapy = ismaintenance='True' AND the line's ONLY regimen drug is bevacizumab (substring 'bevacizumab'). Source table t_&cohort_drugepisode_&date. One record per spec row (LiBEVM family i=1..5)."
```

#### L2BEVM

```yaml
variable_id: L2BEVM
spec_refs: [treatment:57]
spec_digest: ca620983e0d6
required_rule: "Received Bevacizumab maintenance monotherapy in line 2 (1=Yes/0=No): 1 if any qualifying drug-episode of line 2 (linenumber=2 AND ismaintenance='True') has ONLY regimen names containing 'bevacizumab', else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 2 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='True'; flag=1 if the line regimen names contain ONLY 'bevacizumab' (bev-only), else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-2 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l2bevm, target_published_name: L2BEVM, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 2 maintenance episode whose only drug is Bevacizumab -> L2BEVM=1; maintenance line 2 containing Bevacizumab plus another drug -> 0"
notes: "Maintenance monotherapy = ismaintenance='True' AND the line's ONLY regimen drug is bevacizumab (substring 'bevacizumab'). Source table t_&cohort_drugepisode_&date. One record per spec row (LiBEVM family i=1..5)."
```

#### L3BEVM

```yaml
variable_id: L3BEVM
spec_refs: [treatment:58]
spec_digest: b74a30883133
required_rule: "Received Bevacizumab maintenance monotherapy in line 3 (1=Yes/0=No): 1 if any qualifying drug-episode of line 3 (linenumber=3 AND ismaintenance='True') has ONLY regimen names containing 'bevacizumab', else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 3 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='True'; flag=1 if the line regimen names contain ONLY 'bevacizumab' (bev-only), else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-3 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l3bevm, target_published_name: L3BEVM, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 3 maintenance episode whose only drug is Bevacizumab -> L3BEVM=1; maintenance line 3 containing Bevacizumab plus another drug -> 0"
notes: "Maintenance monotherapy = ismaintenance='True' AND the line's ONLY regimen drug is bevacizumab (substring 'bevacizumab'). Source table t_&cohort_drugepisode_&date. One record per spec row (LiBEVM family i=1..5)."
```

#### L4BEVM

```yaml
variable_id: L4BEVM
spec_refs: [treatment:59]
spec_digest: c266349fcfbf
required_rule: "Received Bevacizumab maintenance monotherapy in line 4 (1=Yes/0=No): 1 if any qualifying drug-episode of line 4 (linenumber=4 AND ismaintenance='True') has ONLY regimen names containing 'bevacizumab', else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 4 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='True'; flag=1 if the line regimen names contain ONLY 'bevacizumab' (bev-only), else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-4 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l4bevm, target_published_name: L4BEVM, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 4 maintenance episode whose only drug is Bevacizumab -> L4BEVM=1; maintenance line 4 containing Bevacizumab plus another drug -> 0"
notes: "Maintenance monotherapy = ismaintenance='True' AND the line's ONLY regimen drug is bevacizumab (substring 'bevacizumab'). Source table t_&cohort_drugepisode_&date. One record per spec row (LiBEVM family i=1..5)."
```

#### L5BEVM

```yaml
variable_id: L5BEVM
spec_refs: [treatment:60]
spec_digest: 6ec2fb3b8056
required_rule: "Received Bevacizumab maintenance monotherapy in line 5 (1=Yes/0=No): 1 if any qualifying drug-episode of line 5 (linenumber=5 AND ismaintenance='True') has ONLY regimen names containing 'bevacizumab', else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 5 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='True'; flag=1 if the line regimen names contain ONLY 'bevacizumab' (bev-only), else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-5 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l5bevm, target_published_name: L5BEVM, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 5 maintenance episode whose only drug is Bevacizumab -> L5BEVM=1; maintenance line 5 containing Bevacizumab plus another drug -> 0"
notes: "Maintenance monotherapy = ismaintenance='True' AND the line's ONLY regimen drug is bevacizumab (substring 'bevacizumab'). Source table t_&cohort_drugepisode_&date. One record per spec row (LiBEVM family i=1..5)."
```

#### L1IO

```yaml
variable_id: L1IO
spec_refs: [treatment:61]
spec_digest: 5d9d10a344d4
required_rule: "Received IO (immuno-oncology) in line 1 (1=Yes/0=No): 1 if any qualifying drug-episode of line 1 (linenumber=1) has a line name containing >=1 of the four IO agents, else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 1 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i; flag=1 if the line name contains at least one of Atezolizumab, Durvalumab, Nivolumab, Pembrolizumab, else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-1 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l1io, target_published_name: L1IO, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 1 linename contains 'Pembrolizumab' -> L1IO=1; line 1 with none of the four IO agents -> 0"
notes: "IO agent list {Atezolizumab, Durvalumab, Nivolumab, Pembrolizumab} is stated in the spec; enumerate it in variables/codelists rather than inlining. No maintenance filter is stated for the IO flag. Capture defects on this family recorded as finding TX-B-IO-LABEL-BB (source Label cell reads 'bb'; 'Atezolizumab' carries a [verify] marker; the source names a 'LineNameTi' column alongside LineName). Rule itself is legible, so drafted rather than blocked."
```

#### L2IO

```yaml
variable_id: L2IO
spec_refs: [treatment:62]
spec_digest: 7fd50073dbfd
required_rule: "Received IO (immuno-oncology) in line 2 (1=Yes/0=No): 1 if any qualifying drug-episode of line 2 (linenumber=2) has a line name containing >=1 of the four IO agents, else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 2 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i; flag=1 if the line name contains at least one of Atezolizumab, Durvalumab, Nivolumab, Pembrolizumab, else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-2 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l2io, target_published_name: L2IO, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 2 linename contains 'Pembrolizumab' -> L2IO=1; line 2 with none of the four IO agents -> 0"
notes: "IO agent list {Atezolizumab, Durvalumab, Nivolumab, Pembrolizumab} is stated in the spec; enumerate it in variables/codelists rather than inlining. No maintenance filter is stated for the IO flag. Capture defects on this family recorded as finding TX-B-IO-LABEL-BB (source Label cell reads 'bb'; 'Atezolizumab' carries a [verify] marker; the source names a 'LineNameTi' column alongside LineName). Rule itself is legible, so drafted rather than blocked."
```

#### L3IO

```yaml
variable_id: L3IO
spec_refs: [treatment:63]
spec_digest: c18e3adb64a1
required_rule: "Received IO (immuno-oncology) in line 3 (1=Yes/0=No): 1 if any qualifying drug-episode of line 3 (linenumber=3) has a line name containing >=1 of the four IO agents, else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 3 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i; flag=1 if the line name contains at least one of Atezolizumab, Durvalumab, Nivolumab, Pembrolizumab, else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-3 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l3io, target_published_name: L3IO, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 3 linename contains 'Pembrolizumab' -> L3IO=1; line 3 with none of the four IO agents -> 0"
notes: "IO agent list {Atezolizumab, Durvalumab, Nivolumab, Pembrolizumab} is stated in the spec; enumerate it in variables/codelists rather than inlining. No maintenance filter is stated for the IO flag. Capture defects on this family recorded as finding TX-B-IO-LABEL-BB (source Label cell reads 'bb'; 'Atezolizumab' carries a [verify] marker; the source names a 'LineNameTi' column alongside LineName). Rule itself is legible, so drafted rather than blocked."
```

#### L4IO

```yaml
variable_id: L4IO
spec_refs: [treatment:64]
spec_digest: 399131867714
required_rule: "Received IO (immuno-oncology) in line 4 (1=Yes/0=No): 1 if any qualifying drug-episode of line 4 (linenumber=4) has a line name containing >=1 of the four IO agents, else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 4 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i; flag=1 if the line name contains at least one of Atezolizumab, Durvalumab, Nivolumab, Pembrolizumab, else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-4 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l4io, target_published_name: L4IO, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 4 linename contains 'Pembrolizumab' -> L4IO=1; line 4 with none of the four IO agents -> 0"
notes: "IO agent list {Atezolizumab, Durvalumab, Nivolumab, Pembrolizumab} is stated in the spec; enumerate it in variables/codelists rather than inlining. No maintenance filter is stated for the IO flag. Capture defects on this family recorded as finding TX-B-IO-LABEL-BB (source Label cell reads 'bb'; 'Atezolizumab' carries a [verify] marker; the source names a 'LineNameTi' column alongside LineName). Rule itself is legible, so drafted rather than blocked."
```

#### L5IO

```yaml
variable_id: L5IO
spec_refs: [treatment:65]
spec_digest: 6c32c91bd38a
required_rule: "Received IO (immuno-oncology) in line 5 (1=Yes/0=No): 1 if any qualifying drug-episode of line 5 (linenumber=5) has a line name containing >=1 of the four IO agents, else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 5 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i; flag=1 if the line name contains at least one of Atezolizumab, Durvalumab, Nivolumab, Pembrolizumab, else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-5 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l5io, target_published_name: L5IO, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 5 linename contains 'Pembrolizumab' -> L5IO=1; line 5 with none of the four IO agents -> 0"
notes: "IO agent list {Atezolizumab, Durvalumab, Nivolumab, Pembrolizumab} is stated in the spec; enumerate it in variables/codelists rather than inlining. No maintenance filter is stated for the IO flag. Capture defects on this family recorded as finding TX-B-IO-LABEL-BB (source Label cell reads 'bb'; 'Atezolizumab' carries a [verify] marker; the source names a 'LineNameTi' column alongside LineName). Rule itself is legible, so drafted rather than blocked."
```

#### L1PARPM

```yaml
variable_id: L1PARPM
spec_refs: [treatment:66]
spec_digest: ec00f962804a
required_rule: "Received line maintenance containing a PARPi in line 1 (1=Yes/0=No): 1 if any qualifying drug-episode of line 1 (linenumber=1 AND ismaintenance='True') has a line name containing ANY of the four PARPi, else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 1 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='True'; flag=1 if the line name contains ANY of Niraparib, Olaparib, Rucaparib, Talazoparib, else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-1 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l1parpm, target_published_name: L1PARPM, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 1 maintenance linename contains 'Olaparib' -> L1PARPM=1; line 1 maintenance with no PARPi -> 0"
notes: "PARPi list {Niraparib, Olaparib, Rucaparib, Talazoparib} is stated in the spec; enumerate in variables/codelists. 'contains ANY of the four PARPi' (combinations allowed). Source Variable cell read 'LiMparp' (stand-in); the canonical id is used. Source table t_&cohort_drugepisode_&date. One record per spec row (LiparpM family i=1..5)."
```

#### L2PARPM

```yaml
variable_id: L2PARPM
spec_refs: [treatment:67]
spec_digest: 48d344644d01
required_rule: "Received line maintenance containing a PARPi in line 2 (1=Yes/0=No): 1 if any qualifying drug-episode of line 2 (linenumber=2 AND ismaintenance='True') has a line name containing ANY of the four PARPi, else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 2 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='True'; flag=1 if the line name contains ANY of Niraparib, Olaparib, Rucaparib, Talazoparib, else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-2 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l2parpm, target_published_name: L2PARPM, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 2 maintenance linename contains 'Olaparib' -> L2PARPM=1; line 2 maintenance with no PARPi -> 0"
notes: "PARPi list {Niraparib, Olaparib, Rucaparib, Talazoparib} is stated in the spec; enumerate in variables/codelists. 'contains ANY of the four PARPi' (combinations allowed). Source Variable cell read 'LiMparp' (stand-in); the canonical id is used. Source table t_&cohort_drugepisode_&date. One record per spec row (LiparpM family i=1..5)."
```

#### L3PARPM

```yaml
variable_id: L3PARPM
spec_refs: [treatment:68]
spec_digest: 3fdf798c9e72
required_rule: "Received line maintenance containing a PARPi in line 3 (1=Yes/0=No): 1 if any qualifying drug-episode of line 3 (linenumber=3 AND ismaintenance='True') has a line name containing ANY of the four PARPi, else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 3 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='True'; flag=1 if the line name contains ANY of Niraparib, Olaparib, Rucaparib, Talazoparib, else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-3 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l3parpm, target_published_name: L3PARPM, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 3 maintenance linename contains 'Olaparib' -> L3PARPM=1; line 3 maintenance with no PARPi -> 0"
notes: "PARPi list {Niraparib, Olaparib, Rucaparib, Talazoparib} is stated in the spec; enumerate in variables/codelists. 'contains ANY of the four PARPi' (combinations allowed). Source Variable cell read 'LiMparp' (stand-in); the canonical id is used. Source table t_&cohort_drugepisode_&date. One record per spec row (LiparpM family i=1..5)."
```

#### L4PARPM

```yaml
variable_id: L4PARPM
spec_refs: [treatment:69]
spec_digest: f3390540fa33
required_rule: "Received line maintenance containing a PARPi in line 4 (1=Yes/0=No): 1 if any qualifying drug-episode of line 4 (linenumber=4 AND ismaintenance='True') has a line name containing ANY of the four PARPi, else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 4 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='True'; flag=1 if the line name contains ANY of Niraparib, Olaparib, Rucaparib, Talazoparib, else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-4 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l4parpm, target_published_name: L4PARPM, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 4 maintenance linename contains 'Olaparib' -> L4PARPM=1; line 4 maintenance with no PARPi -> 0"
notes: "PARPi list {Niraparib, Olaparib, Rucaparib, Talazoparib} is stated in the spec; enumerate in variables/codelists. 'contains ANY of the four PARPi' (combinations allowed). Source Variable cell read 'LiMparp' (stand-in); the canonical id is used. Source table t_&cohort_drugepisode_&date. One record per spec row (LiparpM family i=1..5)."
```

#### L5PARPM

```yaml
variable_id: L5PARPM
spec_refs: [treatment:70]
spec_digest: bfa2165e20cf
required_rule: "Received line maintenance containing a PARPi in line 5 (1=Yes/0=No): 1 if any qualifying drug-episode of line 5 (linenumber=5 AND ismaintenance='True') has a line name containing ANY of the four PARPi, else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 5 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='True'; flag=1 if the line name contains ANY of Niraparib, Olaparib, Rucaparib, Talazoparib, else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-5 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l5parpm, target_published_name: L5PARPM, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 5 maintenance linename contains 'Olaparib' -> L5PARPM=1; line 5 maintenance with no PARPi -> 0"
notes: "PARPi list {Niraparib, Olaparib, Rucaparib, Talazoparib} is stated in the spec; enumerate in variables/codelists. 'contains ANY of the four PARPi' (combinations allowed). Source Variable cell read 'LiMparp' (stand-in); the canonical id is used. Source table t_&cohort_drugepisode_&date. One record per spec row (LiparpM family i=1..5)."
```

#### L1PARPMO

```yaml
variable_id: L1PARPMO
spec_refs: [treatment:71]
spec_digest: 118d7c4d9802
required_rule: "Received PARPi maintenance monotherapy in line 1 (1=Yes/0=No): 1 if any qualifying drug-episode of line 1 (linenumber=1 AND ismaintenance='True') has EXACTLY one PARPi and no other drug, else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 1 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='True'; flag=1 if the line name is exactly one of Niraparib, Olaparib, Rucaparib, Talazoparib with NO OTHER DRUGS, else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-1 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l1parpmo, target_published_name: L1PARPMO, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 1 maintenance whose only drug is 'Niraparib' -> L1PARPMO=1; line 1 maintenance with Niraparib plus another drug -> 0"
notes: "PARP maintenance MONOtherapy = ismaintenance='True' AND the line's only drug is exactly one of {Niraparib, Olaparib, Rucaparib, Talazoparib} with NO OTHER DRUGS. Same stated PARPi list as LiparpM; enumerate in codelists. Source table t_&cohort_drugepisode_&date. One record per spec row (LiparpMO family i=1..5)."
```

#### L2PARPMO

```yaml
variable_id: L2PARPMO
spec_refs: [treatment:72]
spec_digest: 38ed3d8f5e16
required_rule: "Received PARPi maintenance monotherapy in line 2 (1=Yes/0=No): 1 if any qualifying drug-episode of line 2 (linenumber=2 AND ismaintenance='True') has EXACTLY one PARPi and no other drug, else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 2 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='True'; flag=1 if the line name is exactly one of Niraparib, Olaparib, Rucaparib, Talazoparib with NO OTHER DRUGS, else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-2 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l2parpmo, target_published_name: L2PARPMO, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 2 maintenance whose only drug is 'Niraparib' -> L2PARPMO=1; line 2 maintenance with Niraparib plus another drug -> 0"
notes: "PARP maintenance MONOtherapy = ismaintenance='True' AND the line's only drug is exactly one of {Niraparib, Olaparib, Rucaparib, Talazoparib} with NO OTHER DRUGS. Same stated PARPi list as LiparpM; enumerate in codelists. Source table t_&cohort_drugepisode_&date. One record per spec row (LiparpMO family i=1..5)."
```

#### L3PARPMO

```yaml
variable_id: L3PARPMO
spec_refs: [treatment:73]
spec_digest: 4d75c6fae5e2
required_rule: "Received PARPi maintenance monotherapy in line 3 (1=Yes/0=No): 1 if any qualifying drug-episode of line 3 (linenumber=3 AND ismaintenance='True') has EXACTLY one PARPi and no other drug, else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 3 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='True'; flag=1 if the line name is exactly one of Niraparib, Olaparib, Rucaparib, Talazoparib with NO OTHER DRUGS, else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-3 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l3parpmo, target_published_name: L3PARPMO, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 3 maintenance whose only drug is 'Niraparib' -> L3PARPMO=1; line 3 maintenance with Niraparib plus another drug -> 0"
notes: "PARP maintenance MONOtherapy = ismaintenance='True' AND the line's only drug is exactly one of {Niraparib, Olaparib, Rucaparib, Talazoparib} with NO OTHER DRUGS. Same stated PARPi list as LiparpM; enumerate in codelists. Source table t_&cohort_drugepisode_&date. One record per spec row (LiparpMO family i=1..5)."
```

#### L4PARPMO

```yaml
variable_id: L4PARPMO
spec_refs: [treatment:74]
spec_digest: 8eb2783edc2f
required_rule: "Received PARPi maintenance monotherapy in line 4 (1=Yes/0=No): 1 if any qualifying drug-episode of line 4 (linenumber=4 AND ismaintenance='True') has EXACTLY one PARPi and no other drug, else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 4 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='True'; flag=1 if the line name is exactly one of Niraparib, Olaparib, Rucaparib, Talazoparib with NO OTHER DRUGS, else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-4 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l4parpmo, target_published_name: L4PARPMO, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 4 maintenance whose only drug is 'Niraparib' -> L4PARPMO=1; line 4 maintenance with Niraparib plus another drug -> 0"
notes: "PARP maintenance MONOtherapy = ismaintenance='True' AND the line's only drug is exactly one of {Niraparib, Olaparib, Rucaparib, Talazoparib} with NO OTHER DRUGS. Same stated PARPi list as LiparpM; enumerate in codelists. Source table t_&cohort_drugepisode_&date. One record per spec row (LiparpMO family i=1..5)."
```

#### L5PARPMO

```yaml
variable_id: L5PARPMO
spec_refs: [treatment:75]
spec_digest: c41b4c5ed1be
required_rule: "Received PARPi maintenance monotherapy in line 5 (1=Yes/0=No): 1 if any qualifying drug-episode of line 5 (linenumber=5 AND ismaintenance='True') has EXACTLY one PARPi and no other drug, else 0."
source: {kind: vendor, inputs: {drugepisode: {line_number: LineNumber, is_maintenance: IsMaintenance, line_name: LineName}}}
grain: [patientid, cohortn]
anchor: n/a
window: n/a
record_selection: "any qualifying drug-episode in line 5 (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "line i = linenumber=i AND ismaintenance='True'; flag=1 if the line name is exactly one of Niraparib, Olaparib, Rucaparib, Talazoparib with NO OTHER DRUGS, else 0."
cohort_applicability: all cohorts
missing: {no_record: "no line-5 episode meeting the filter -> flag=0 (spec terminal 'else no')", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: l5parpmo, target_published_name: L5PARPMO, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "line 5 maintenance whose only drug is 'Niraparib' -> L5PARPMO=1; line 5 maintenance with Niraparib plus another drug -> 0"
notes: "PARP maintenance MONOtherapy = ismaintenance='True' AND the line's only drug is exactly one of {Niraparib, Olaparib, Rucaparib, Talazoparib} with NO OTHER DRUGS. Same stated PARPi list as LiparpM; enumerate in codelists. Source table t_&cohort_drugepisode_&date. One record per spec row (LiparpMO family i=1..5)."
```

#### FNIRA

```yaml
variable_id: FNIRA
spec_refs: [treatment:76]
spec_digest: 51b456825a94
required_rule: "Flag (1=Yes/0=No) for patients with >=1 non-cancelled medication order for niraparib at any time: 1 if any MedicationOrder row has commondrugname='niraparib' AND isCancelled != 'True', else 0."
source: {kind: vendor, inputs: {medorder: {common_drug_name: CommonDrugName, is_cancelled: IsCancelled}}}
grain: [patientid, cohortn]
anchor: n/a
window: STUDY_PD
record_selection: "any non-cancelled niraparib order in the study period (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "flag=1 if EXISTS a MedicationOrder with commondrugname='niraparib' AND isCancelled != 'True' at any time (STUDY_PD), else 0."
cohort_applicability: all cohorts
missing: {no_record: "no niraparib order (or all cancelled) -> flag=0", present_null: "isCancelled null is not 'True', so a null-isCancelled niraparib order still qualifies (isCancelled != 'True')"}
units: n/a
depends_on: []
output: {physical_name: fnira, target_published_name: FNIRA, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "patient with one order commondrugname='niraparib', isCancelled='False' -> FNIRA=1; patient whose only niraparib order has isCancelled='True' -> 0"
notes: "Source table t_&cohort_MedicationOrder_&date. Capture defects recorded as finding TX-B-FNIRA-VARCELL (source Variable cell reads 'F_nira_order'; prior spec spelled the drug 'nirapanib'). Context (not a rule): Zejula Registry patients have a niraparib-order inclusion criterion while EDM patients do not, and ~14% of EDM patients have a niraparib oral span from unstructured data. Rule is legible, so drafted rather than blocked."
```

#### CSD_PRE_INT

```yaml
variable_id: CSD_PRE_INT
spec_refs: [treatment:77]
spec_digest: 67a64f37bb4e
required_rule: "Presence of a Clinical Study Drug BEFORE the index treatment line (1=Yes/0=No): 1 if a drug-episode whose linename contains 'Clinical Study Drug' falls in the pre-index window, else 0."
source: {kind: vendor, inputs: {drugepisode: {line_name: LineName, episode_date: EPISODEDATE}}}
grain: [patientid, cohortn]
anchor: "line start date (treated cohorts) or index date (Overall cohort)"
window: PRE_INT
record_selection: "any Clinical Study Drug episode in the pre-index window (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "flag=1 if EXISTS a drug-episode with linename containing 'Clinical Study Drug' where (Treated cohorts) EPISODEDATE < line start date, or (Overall cohort) EPISODEDATE < index date; index line excluded. Else 0."
cohort_applicability: "Treated cohorts (EPISODEDATE < line start date) and Overall cohort (EPISODEDATE < index date)"
missing: {no_record: "no qualifying Clinical Study Drug episode in the pre-index window -> flag=0", present_null: n/a}
units: n/a
depends_on: [INDEX]
output: {physical_name: csd_pre_int, target_published_name: CSD_PRE_INT, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "Overall-cohort patient with a 'Clinical Study Drug' episode dated before index -> CSD_PRE_INT=1; no such episode -> 0"
notes: "Source table t_&cohort_drugepisode_&date; the line start date (treated) and index date (overall) are the window boundaries, carried in depends_on/derivation rather than as source columns. Clinical Study Drug membership is a linename substring per spec."
```

#### CSD_INDEX

```yaml
variable_id: CSD_INDEX
spec_refs: [treatment:78]
spec_digest: 6204571df097
required_rule: "Presence of a Clinical Study Drug DURING the index treatment line (1=Yes/0=No): 1 if a drug-episode whose regimen/linename contains 'Clinical Study Drug' falls in the index window, else 0."
source: {kind: vendor, inputs: {drugepisode: {line_name: LineName, episode_date: EPISODEDATE}}}
grain: [patientid, cohortn]
anchor: "index treatment line (treated cohorts) or index date (Overall cohort)"
window: "index treatment line (treated); index date (overall)"
record_selection: "any Clinical Study Drug episode within the index window (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "flag=1 if EXISTS a drug-episode with regimen/linename containing 'Clinical Study Drug' where (Treated cohorts) line start date <= EPISODEDATE <= line end date, or (Overall cohort) EPISODEDATE = index date. Else 0."
cohort_applicability: "Treated cohorts (line start date <= EPISODEDATE <= line end date) and Overall cohort (EPISODEDATE = index date)"
missing: {no_record: "no qualifying Clinical Study Drug episode in the index window -> flag=0", present_null: n/a}
units: n/a
depends_on: [INDEX]
output: {physical_name: csd_index, target_published_name: CSD_INDEX, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "treated-cohort patient with a 'Clinical Study Drug' episode dated within the index line span -> CSD_INDEX=1; none -> 0"
notes: "Source table t_&cohort_drugepisode_&date. Finding TX-B-CSD-INDEX-CLIP: the source definition was partly clipped ('if t_&cohort_dr... [verify] contains 'Clinical [verify]'), which is also the source of the UNBALANCED single-quote lint flag (the clipped 'Clinical Study Drug' literal). The rule is recovered from the parallel CSD_PRE_INT / CSD_FU rows, so drafted; confirm the full DURING clause on re-extraction."
```

#### CSD_FU

```yaml
variable_id: CSD_FU
spec_refs: [treatment:79]
spec_digest: 18690cf1cfae
required_rule: "Presence of a Clinical Study Drug AFTER the index treatment line (1=Yes/0=No): 1 if a drug-episode whose linename contains 'Clinical Study Drug' falls in the follow-up window, else 0."
source: {kind: vendor, inputs: {drugepisode: {line_name: LineName, episode_date: EPISODEDATE}}}
grain: [patientid, cohortn]
anchor: "line end date (treated cohorts) or index date (Overall cohort)"
window: FU
record_selection: "any Clinical Study Drug episode in the follow-up window (else 0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "flag=1 if EXISTS a drug-episode with linename containing 'Clinical Study Drug' where (Treated cohorts) EPISODEDATE > line end date, or (Overall cohort) EPISODEDATE > index date; index line/date excluded. Else 0."
cohort_applicability: "Treated cohorts (EPISODEDATE > line end date) and Overall cohort (EPISODEDATE > index date)"
missing: {no_record: "no qualifying Clinical Study Drug episode in the follow-up window -> flag=0", present_null: n/a}
units: n/a
depends_on: [INDEX]
output: {physical_name: csd_fu, target_published_name: CSD_FU, name_status: undecided, type: integer, nullable: false, codes: "1=Yes;0=No", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "Overall-cohort patient with a 'Clinical Study Drug' episode dated after index -> CSD_FU=1; none -> 0"
notes: "Source table t_&cohort_drugepisode_&date. Clinical Study Drug membership is a linename substring per spec; the follow-up window excludes the index line (treated) / index date (overall)."
```

#### LOTN

```yaml
variable_id: LOTN
spec_refs: [treatment:80]
spec_digest: 49543c59f868
required_rule: "Number of lines of therapy (LOTs): max(LineNumber) across the patient's line-of-therapy records for Treated OC; 0 for Untreated OC. Captured at patient level."
source: {kind: vendor, inputs: {lot: {line_number: LineNumber}}}
grain: [patientid, cohortn]
anchor: n/a
window: FU
record_selection: "the maximum LineNumber across the patient's line-of-therapy rows"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "LOTN = max(LineNumber) over t_&cohort_lineotherapy_&date for a Treated OC patient; LOTN = 0 for an Untreated OC patient."
cohort_applicability: "Treated OC (max LineNumber); Untreated OC (0)"
missing: {no_record: "Untreated OC / no line-of-therapy record -> LOTN=0", present_null: n/a}
units: count
depends_on: []
output: {physical_name: lotn, target_published_name: LOTN, name_status: undecided, type: integer, nullable: false, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "Treated OC patient with lines 1..3 -> LOTN=3; Untreated OC patient -> LOTN=0"
notes: "Source table t_&cohort_lineotherapy_&date. Continuous/count at the patient level; the 0-for-Untreated rule is stated in the spec."
```

#### LOTNGR1

```yaml
variable_id: LOTNGR1
spec_refs: [treatment:81]
spec_digest: c21274ccd843
required_rule: "Banded LOT count: LOTN grouped into 0, 1, 2, 3, 4, 5+ (character)."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: FU
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "band LOTN into '0' | '1' | '2' | '3' | '4' | '5+' (LOTN>=5 -> '5+'); band edges are stated in the spec value set."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "LOTN=0 -> '0' (Untreated maps to the '0' band)"}
units: n/a
depends_on: [LOTN]
output: {physical_name: lotngr1, target_published_name: LOTNGR1, name_status: undecided, type: string, nullable: false, codes: "0;1;2;3;4;5+", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "LOTN=7 -> LOTNGR1='5+'; LOTN=2 -> LOTNGR1='2'"
notes: "Band cutoffs (0,1,2,3,4,5+) are stated in the spec, so drafted. Code Lists Group cell is N/A per spec."
```

#### LOTNGR1N

```yaml
variable_id: LOTNGR1N
spec_refs: [treatment:82]
spec_digest: 0654cc01d8f4
required_rule: "Numeric code of LOTNGR1: 1..6 mapping the bands 0,1,2,3,4,5+."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: n/a
window: FU
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of LOTNGR1: '0'->1, '1'->2, '2'->3, '3'->4, '4'->5, '5+'->6 (order of the stated 1..6 code set)."
cohort_applicability: all cohorts
missing: {no_record: n/a, present_null: "LOTNGR1='0' -> 1"}
units: n/a
depends_on: [LOTNGR1]
output: {physical_name: lotngr1n, target_published_name: LOTNGR1N, name_status: undecided, type: integer, nullable: false, codes: "1=0;2=1;3=2;4=3;5=4;6=5+", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "LOTNGR1='5+' -> LOTNGR1N=6; LOTNGR1='2' -> LOTNGR1N=3"
notes: "The spec states both the 1..6 code range and the 0,1,2,3,4,5+ band set; the mapping follows the stated band order."
```

#### LINESETTING

```yaml
variable_id: LINESETTING
spec_refs: [treatment:83]
spec_digest: ce5a47f8b38a
required_rule: "Per-line treatment setting (Panoramic-added, Derived/Coded, on the LineOfTherapy table). Ovarian value set = {Neoadjuvant, Adjuvant, Advanced, Off Systemic Therapy}."
source: {kind: vendor, inputs: {lot: {line_setting: LineSetting}}}
grain: [patientid, cohortn, linenumber]
anchor: n/a
window: n/a
record_selection: "one setting value per line (LineOfTherapy row)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "coded per-line setting from the ovarian value set {Neoadjuvant, Adjuvant, Advanced, Off Systemic Therapy}; per-value construction rules are in the component rows (Neoadjuvant/Adjuvant/Advanced, treatment:84-86) and the Off-Systemic-Therapy construction (treatment:88). Adjuvant-vs-Advanced assignment depends on RecurrenceDate and its null handling (BLOCKED: TX-B-LINESETTING-RECUR-NULL); the Advanced has-surgery/no-surgery split is BLOCKED (TX-B-LINESETTING-ADV-SPLIT); the precise Off-Systemic-Therapy definition is BLOCKED (TX-B-OST-DEFINITION)."
cohort_applicability: all cohorts
missing: {no_record: "a line with no assignable setting -> undefined (dependent on the blocked rules above)", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: linesetting, target_published_name: LineSetting, name_status: undecided, type: string, nullable: true, codes: "Neoadjuvant;Adjuvant;Advanced;Off Systemic Therapy", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-B-LINESETTING-RECUR-NULL, TX-B-LINESETTING-ADV-SPLIT, TX-B-OST-DEFINITION]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "a line before first definitive surgery -> LineSetting='Neoadjuvant' (pending the blocked Adj/Advanced/OST rules for other lines)"
notes: "Source table LineOfTherapy (t_&cohort_lineotherapy_&date), column LineSetting; related columns LineNumber, LineName, IsMaintenance, StartDate, EndDate, EnhancedCohort. The generic data-dictionary example value 'METASTATIC' is the NSCLC copy; the ovarian value set is from the ovarian documentation (SQ note). Line-splitting/re-numbering (treatment:87) and the PARP carve-out (treatment:89) are build-control rules realized in LineOfTherapy construction."
```

#### LINESETTING_NEOADJUVANT

```yaml
variable_id: LINESETTING_NEOADJUVANT
spec_refs: [treatment:84]
spec_digest: a1527fecda62
required_rule: "Definition of the LineSetting value 'Neoadjuvant': treatment for ovarian cancer occurring before the date of first definitive surgery."
source: {kind: derived}
grain: [patientid, cohortn, linenumber]
anchor: "date of first definitive surgery"
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "a line/episode dated before the date of first definitive surgery is assigned LineSetting='Neoadjuvant'. Special case (stated): a newly-diagnosed patient receiving neoadjuvant therapy ahead of a planned definitive surgery is assigned 'Advanced' until the surgery date, then retroactively updated to 'Neoadjuvant' at the surgery date."
cohort_applicability: all cohorts
missing: {no_record: "no definitive surgery date -> this value's boundary is undefined (see Advanced, TX-B-LINESETTING-ADV-SPLIT)", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: n/a, target_published_name: n/a, name_status: undecided, type: n/a, nullable: n/a, codes: n/a, role: metadata}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: excluded, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "an episode dated 2 months before the first definitive surgery -> LineSetting='Neoadjuvant'"
notes: "Value-definition of the LineSetting field (row 83), not a separate output column (role metadata); documents the coded value. The Neoadjuvant rule is stated (before first definitive surgery) with the retroactive special case, so drafted."
```

#### LINESETTING_ADJUVANT

```yaml
variable_id: LINESETTING_ADJUVANT
spec_refs: [treatment:85]
spec_digest: 285f47ea275d
required_rule: "Definition of the LineSetting value 'Adjuvant': treatment occurring between the date of first definitive surgery and the recurrence date."
source: {kind: derived}
grain: [patientid, cohortn, linenumber]
anchor: "date of first definitive surgery; recurrence date (RecurrenceDate)"
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "a line/episode dated between the first-definitive-surgery date and the recurrence date is assigned LineSetting='Adjuvant'. Adjuvant-vs-Advanced is decided by RecurrenceDate; the LOT rules specify NO handling for a missing/null RecurrenceDate, so the null case (e.g. default to Unknown) is BLOCKED (TX-B-LINESETTING-RECUR-NULL)."
cohort_applicability: all cohorts
missing: {no_record: "RecurrenceDate null -> Adjuvant-vs-Advanced undefined (BLOCKED: TX-B-LINESETTING-RECUR-NULL)", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: n/a, target_published_name: n/a, name_status: undecided, type: n/a, nullable: n/a, codes: n/a, role: metadata}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-B-LINESETTING-RECUR-NULL]
gap_ids: []
publish: {ads: excluded, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "an episode dated after first definitive surgery and before RecurrenceDate -> LineSetting='Adjuvant'; RecurrenceDate null -> cannot be assigned until TX-B-LINESETTING-RECUR-NULL is resolved"
notes: "Value-definition of the LineSetting field (row 83), not a separate output column (role metadata). Follows Flatiron LOT rules. The null-RecurrenceDate fallback is explicitly called out by the spec as an Implementation/Biostats decision, so blocked rather than invented."
```

#### LINESETTING_ADVANCED

```yaml
variable_id: LINESETTING_ADVANCED
spec_refs: [treatment:86]
spec_digest: a87be9153ada
required_rule: "Definition of the LineSetting value 'Advanced'. Per documentation it covers (a) has-surgery: treatment after, or up to 14 days prior to, the recurrence date, and (b) no-surgery: treatment after the date of diagnosis; plus the pre-surgery neoadjuvant special case. The has-surgery/no-surgery split is not readable in the source."
source: {kind: derived}
grain: [patientid, cohortn, linenumber]
anchor: "recurrence date (RecurrenceDate); date of diagnosis; date of first definitive surgery"
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "a line/episode is assigned LineSetting='Advanced' by the documentation sub-rules (has-surgery: after or up to 14 days before RecurrenceDate; no-surgery: after date of diagnosis) plus the neoadjuvant-until-surgery retroactive case. BLOCKED: both sub-bullets were registered as beginning 'if a patient does NOT have definitive surgery', so the intended has-surgery vs no-surgery split must be signed off (TX-B-LINESETTING-ADV-SPLIT); do not infer."
cohort_applicability: all cohorts
missing: {no_record: "RecurrenceDate null -> Adjuvant-vs-Advanced undefined (see TX-B-LINESETTING-RECUR-NULL)", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: n/a, target_published_name: n/a, name_status: undecided, type: n/a, nullable: n/a, codes: n/a, role: metadata}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [TX-B-LINESETTING-ADV-SPLIT]
gap_ids: []
publish: {ads: excluded, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be written until the has-surgery/no-surgery split is confirmed (TX-B-LINESETTING-ADV-SPLIT); e.g. a has-surgery patient with an episode 10 days before RecurrenceDate -> LineSetting='Advanced'"
notes: "Value-definition of the LineSetting field (row 83), not a separate output column (role metadata). Finding TX-B-ADVANCED-SPLIT-DUP records the stand-in defect (both sub-bullets read 'if a patient does NOT have definitive surgery', with [verify surgery condition] and [verify boundary] markers) that gives rise to decision TX-B-LINESETTING-ADV-SPLIT."
```


## outcomes — OUT

#### ID3MOSFU

```yaml
variable_id: ID3MOSFU
spec_refs: [outcomes:8]
spec_digest: 21fcd81ccfa6
required_rule: "3-months-potential-follow-up flag (0=No, 1=Yes): 1 if (MAXINDEX − INDEXDT) ≥ 91 days, else 0. The formula states ≥91 days while the accompanying note states the index date must be ≥90 days before study cut-off — an unresolved 90-vs-91 threshold."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "ID3MOSFU = 1 if (MAXINDEX − INDEXDT) ≥ 91 days else 0. MAXINDEX is the cohort-level Max Potential Index Date constant (study_period:9, 28-Feb-26). The '≥' operator was spot-checked/confirmed, but the day threshold is stated as 91 in the formula and 90 in the note (BLOCKED: OUT-ID3MOSFU-THRESHOLD)."
cohort_applicability: all cohorts
missing: {no_record: "INDEXDT missing → ID3MOSFU cannot be computed (INDEXDT is missing when the relevant line start is missing)", present_null: n/a}
units: n/a
depends_on: [INDEX, MAXINDEX]
output: {physical_name: id3mosfu, target_published_name: ID3MOSFU, name_status: undecided, type: integer, nullable: false, codes: "0=No;1=Yes", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-ID3MOSFU-THRESHOLD]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until the threshold is settled (OUT-ID3MOSFU-THRESHOLD); e.g. MAXINDEX=2026-02-28, INDEXDT=2025-01-01 → 423 days → ID3MOSFU=1 under either 90 or 91"
notes: "Source-primary variable per the tab banner (Epi sign-off). MAXINDEX is a cohort-level constant, not a per-patient column. Gates most other outcomes (outcomes only computed where ID3MOSFU=1)."
```

#### OS

```yaml
variable_id: OS
spec_refs: [outcomes:9]
spec_digest: d4f882dbfc8e
required_rule: "Overall Survival in months from INDEXDT: if ID3MOSFU=1 AND DTHFL=1 then (death_dt − INDEXDT + 1)/30.4375; if DTHFL=0 then censor at FUED (FUED − INDEXDT + 1)/30.4375."
source: {kind: vendor, inputs: {mortality: {date_of_death: DateOfDeath}}}
grain: [patientid, cohortn]
anchor: index_date
window: STUDY_PD
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "death (ID3MOSFU=1 AND DTHFL=1): (DateOfDeath − INDEXDT + 1)/30.4375; alive (DTHFL=0): (FUED − INDEXDT + 1)/30.4375. 30.4375 = DAYS_PER_MONTH (study_period:17). The chain has no terminal else: a patient with ID3MOSFU=0 AND DTHFL=1 is unmatched, and the censor branch does not restate the ID3MOSFU=1 gate while the tab elsewhere restricts outcomes to ID3MOSFU=1 — the OS value for ID3MOSFU=0 is undefined (BLOCKED: OUT-OS-CENSORING). FUED (follow-up end) is itself not yet fully defined (study_period FU note: 'need to define end of follow-up')."
cohort_applicability: all cohorts
missing: {no_record: "INDEXDT missing → OS missing", present_null: "ID3MOSFU=0 → OS undefined (BLOCKED: OUT-OS-CENSORING)"}
units: months
depends_on: [INDEX, ID3MOSFU]
output: {physical_name: os, target_published_name: OS, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-OS-CENSORING]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fully fixed until censoring for ID3MOSFU=0 is settled (OUT-OS-CENSORING); e.g. DTHFL=1, DateOfDeath=2022-06-30, INDEXDT=2022-01-01 → (181)/30.4375 ≈ 5.95 months"
notes: "death_dt from Enhanced_Mortality_V2.DateOfDeath; DTHFL (death flag) and FUED (follow-up end) are contract variables outside this chunk — noted, not restated. The +1 and /30.4375 carry [verify] sign-off markers (see OUT-CLIP-TRUNCATION)."
```

#### VIS120

```yaml
variable_id: VIS120
spec_refs: [outcomes:10]
spec_digest: 4024d7db7eed
required_rule: "Visit-120-days-after-index-TRT-end flag (1=Yes, 0=No): 1 if the patient has a Visit.VisitDate OR Telemedicine.VisitDate occurring ≥120 days after the last episode date of the index line of therapy, else 0."
source: {kind: vendor, inputs: {visit: {visit_date: VisitDate}, telemedicine: {visit_date: VisitDate}}}
grain: [patientid, cohortn]
anchor: last episode date of index line of therapy
window: ">=120 days after the last episode date of the index LOT"
record_selection: "any qualifying visit (visit OR telemedicine) at ≥120 days after last index-LOT episode date"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "1 if EXISTS a VisitDate (Visit or Telemedicine) ≥ (last episode date of index LOT + 120 days), else 0. Rendered as VIS120 / VIS120i."
cohort_applicability: all cohorts
missing: {no_record: "no visit/telemedicine record → 0", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: vis120, target_published_name: VIS120, name_status: undecided, type: integer, nullable: false, codes: "0=No;1=Yes", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "last episode date of index LOT=2022-01-01, a Visit.VisitDate=2022-06-01 (>151 days) → VIS120=1; only visits within 119 days → VIS120=0"
notes: "Source-primary variable per the tab banner (Epi sign-off). Visit from t_&cohort_visit_&date, telemedicine from t_&cohort_telemedicine_&date. The 120-day value carries a [verify] sign-off marker; drafted straight because the rule is stated (see OUT-CLIP-TRUNCATION for the verify inventory). VIS120i is the same rule at the index-LOT scope."
```

#### PFSFL

```yaml
variable_id: PFSFL
spec_refs: [outcomes:11]
spec_digest: 9f82de3cc9b0
required_rule: "rw progression-event flag (1=Yes, 0=No, missing): missing if COHORTN=1; for COHORTN in (2..6) AND ELIGPFS=1, 1 if a non-pseudo progression flag has a PROGRESSIONDATE ≥ INDEXDT+14, or (no eligible progression) DTHFL=1; 0 if no eligible progression and DTHFL=0."
source: {kind: vendor, inputs: {progression: {progression_date: PROGRESSIONDATE, is_pseudo_progression: IsPseudoProgressionMentioned}}}
grain: [patientid, cohortn]
anchor: index_date
window: ">= INDEXDT+14"
record_selection: "first eligible progression (PROGRESSIONDATE ≥ INDEXDT+14, IsPseudoProgressionMentioned≠1); death used only if no eligible progression"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "COHORTN=1 → missing; COHORTN in (2..6) AND ELIGPFS=1: 1 if a progression flag other than IsPseudoProgressionMentioned=1 has PROGRESSIONDATE ≥ INDEXDT+14; else if no such date AND DTHFL=1 → 1; else if no such date AND DTHFL=0 → 0. Two blocked items: (a) the day-14 progression-attachment gap — Flatiron investigated 0/14/28-day gaps and used 14 as a rule of thumb, not yet ratified (BLOCKED: OUT-PFS-GAP); (b) which progression flags constitute a valid progression event (only pseudo-progression is excluded here; the full event definition may sit on an unscanned strategy sheet) and the PFSFL value when ELIGPFS=0 (BLOCKED: OUT-PFS-PROGRESSION-DEF)."
cohort_applicability: "COHORTN in (2..6); COHORTN=1 → missing"
missing: {no_record: "no progression record and DTHFL unknown → cannot classify", present_null: "COHORTN=1 → missing; ELIGPFS=0 → undefined (BLOCKED: OUT-PFS-PROGRESSION-DEF)"}
units: n/a
depends_on: [INDEX, ELIGPFS]
output: {physical_name: pfsfl, target_published_name: PFSFL, name_status: undecided, type: integer, nullable: true, codes: "0=No;1=Yes;.=missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-PFS-GAP, OUT-PFS-PROGRESSION-DEF]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until the day-14 gap and progression-event definition are settled (OUT-PFS-GAP, OUT-PFS-PROGRESSION-DEF)"
notes: "Progression from Enhanced_Ovarian_Progression. The re-read resolved the date operator to '≥ INDEXDT+14' (Epi to ratify). Row-2 routing sends progression-vs-death to Biostats; the death-only-if-no-eligible-progression precedence is stated. Variable name PFSC1LM carries [verify]."
```

#### PFSDT

```yaml
variable_id: PFSDT
spec_refs: [outcomes:12]
spec_digest: c45431e2a3bc
required_rule: "rw progression-event date: missing if COHORTN=1; for COHORTN in (2..6) AND ELIGPFS=1, the FIRST PROGRESSIONDATE ≥ INDEXDT+14; if none, DTHDT; if neither, missing."
source: {kind: vendor, inputs: {progression: {progression_date: PROGRESSIONDATE}}}
grain: [patientid, cohortn]
anchor: index_date
window: ">= INDEXDT+14"
record_selection: "the FIRST eligible PROGRESSIONDATE ≥ INDEXDT+14; fallback DTHDT only if no eligible progression"
tie_break: {equidistant: n/a, same_day: "the earliest (first) eligible PROGRESSIONDATE is taken"}
derivation: "COHORTN=1 → missing; COHORTN in (2..6) AND ELIGPFS=1: first PROGRESSIONDATE where PROGRESSIONDATE ≥ INDEXDT+14; else DTHDT; else missing. Unified with PFSFL. Same open items as PFSFL: the day-14 gap (BLOCKED: OUT-PFS-GAP) and the valid-progression-event definition / ELIGPFS=0 behaviour (BLOCKED: OUT-PFS-PROGRESSION-DEF)."
cohort_applicability: "COHORTN in (2..6); COHORTN=1 → missing"
missing: {no_record: "no eligible PROGRESSIONDATE and no DTHDT → missing", present_null: "COHORTN=1 → missing"}
units: date
depends_on: [INDEX, ELIGPFS, PFSFL]
output: {physical_name: pfsdt, target_published_name: PFSDT, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-PFS-GAP, OUT-PFS-PROGRESSION-DEF]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until OUT-PFS-GAP and OUT-PFS-PROGRESSION-DEF are settled; e.g. first eligible PROGRESSIONDATE=2022-05-01 → PFSDT=2022-05-01"
notes: "DTHDT (death date) is a contract variable outside this chunk. Variable name PFS1LD carries [verify]. All death dates are month/year only in source (imputed); progression dates retain day-level granularity."
```

#### PFS

```yaml
variable_id: PFS
spec_refs: [outcomes:13]
spec_digest: 9e7c79ad3d51
required_rule: "rw Progression-Free Survival in months: missing if COHORTN=1; for COHORTN in (2..6), if PFSFL=1 then (PFSDT − INDEXDT + 1)/30.4375; if PFSFL=0 then censor at LASTCLINICNOTEDATE (LASTCLINICNOTEDATE − INDEXDT + 1)/30.4375."
source: {kind: vendor, inputs: {progression: {last_clinic_note_date: LASTCLINICNOTEDATE}}}
grain: [patientid, cohortn]
anchor: index_date
window: STUDY_PD
record_selection: "event date = PFSDT (PFSFL=1); censor date = LASTCLINICNOTEDATE from the progression table (PFSFL=0)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "COHORTN=1 → missing; PFSFL=1: (PFSDT − INDEXDT + 1)/30.4375; PFSFL=0: (LASTCLINICNOTEDATE − INDEXDT + 1)/30.4375. 30.4375 = DAYS_PER_MONTH (study_period:17). Value is underivable until the PFS-event definition is settled (BLOCKED: OUT-PFS-GAP, OUT-PFS-PROGRESSION-DEF) because it consumes PFSFL/PFSDT."
cohort_applicability: "COHORTN in (2..6); COHORTN=1 → missing"
missing: {no_record: "no censor date available → missing", present_null: "COHORTN=1 → missing"}
units: months
depends_on: [INDEX, PFSFL, PFSDT]
output: {physical_name: pfs, target_published_name: PFS, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-PFS-GAP, OUT-PFS-PROGRESSION-DEF]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until OUT-PFS-GAP and OUT-PFS-PROGRESSION-DEF are settled; e.g. PFSFL=1, PFSDT=2022-05-01, INDEXDT=2022-01-01 → (121)/30.4375 ≈ 3.98 months"
notes: "LASTCLINICNOTEDATE used as censor because last structured activity is not an accurate censoring date. Variable name rwPFS1L carries [verify]. Row carries an unbalanced-quote / clipped-text artifact (see OUT-CLIP-TRUNCATION)."
```

#### ELIGPFS

```yaml
variable_id: ELIGPFS
spec_refs: [outcomes:14]
spec_digest: c661c59c1346
required_rule: "Eligible-for-rwPFS flag (1=Yes, 0=No, missing): missing if COHORTN=1; for COHORTN in (2..6), 1 if ID3MOSFU=1 AND LASTCLINICNOTEDATE > INDEXDT (strictly after), else 0."
source: {kind: vendor, inputs: {progression: {last_clinic_note_date: LASTCLINICNOTEDATE}}}
grain: [patientid, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "COHORTN=1 → missing; COHORTN in (2..6): if ID3MOSFU=1 AND LASTCLINICNOTEDATE > INDEXDT then 1 else 0. The strictly-greater-than (not on/after) is deliberate: it avoids counting patients censored on the index date, whose early censoring could pull down the PFS median."
cohort_applicability: "COHORTN in (2..6); COHORTN=1 → missing"
missing: {no_record: "no LASTCLINICNOTEDATE → cannot satisfy the > INDEXDT gate → 0", present_null: "COHORTN=1 → missing"}
units: n/a
depends_on: [INDEX, ID3MOSFU]
output: {physical_name: eligpfs, target_published_name: ELIGPFS, name_status: undecided, type: integer, nullable: true, codes: "0=No;1=Yes;.=missing", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "COHORTN=2, ID3MOSFU=1, LASTCLINICNOTEDATE=2022-03-01 > INDEXDT=2022-01-01 → ELIGPFS=1"
notes: "LASTCLINICNOTEDATE from Enhanced_Ovarian_Progression. Drafted straight — the rule and the strict-inequality rationale are stated. Carries a [verify] sign-off marker (double-check how many deaths where index=lastclinicnote=death are excluded); noted, not blocking. Consumes ID3MOSFU (which is itself decision_required on its threshold)."
```

#### TTDFL

```yaml
variable_id: TTDFL
spec_refs: [outcomes:15]
spec_digest: 31f7d614f33b
required_rule: "Inferred-treatment-discontinued flag (1=Yes, 0=No, missing): missing if COHORTN=1 or ID3MOSFU≠1; otherwise uncensored (event) if the patient advanced to a new LOT, OR (no new LOT) has a death date, OR (no new LOT and no death) has >120 days of structured activity after the last episode date of the index line."
source: {kind: vendor, inputs: {lot: {line_number: LineNumber}, drugepisode: {line_start: LineStartDate}, mortality: {date_of_death: DateOfDeath}}}
grain: [patientid, cohortn]
anchor: index_date
window: FU
record_selection: "patient-level: any new LOT after the index line, else death, else >120d structured activity after the index line's last episode date"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "COHORTN=1 or ID3MOSFU≠1 → missing. Per cohort the index line is LOT1SD (COHORTN=2), LOT1MSD (3), LOT2SD (4), LOT2MSD (5), LOT3SD (6). Uncensored if ANY of: (1) advanced to a new LOT, (2) no new LOT but has a death date, (3) no new LOT and no death but >120 days of structured activity after the last episode date. The precise value-assignment (censored vs uncensored codes) is truncated in the source (see OUT-CLIP-TRUNCATION) and the 120-day structured-activity discontinuation-inference window is not yet ratified (BLOCKED: OUT-TTD-DISCONT-WINDOW)."
cohort_applicability: "COHORTN in (2..6); COHORTN=1 → missing"
missing: {no_record: "COHORTN=1 or ID3MOSFU≠1 → missing", present_null: n/a}
units: n/a
depends_on: [ID3MOSFU]
output: {physical_name: ttdfl, target_published_name: TTDFL, name_status: undecided, type: integer, nullable: true, codes: "0=No;1=Yes;.=missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-TTD-DISCONT-WINDOW]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until the 120-day discontinuation window is ratified (OUT-TTD-DISCONT-WINDOW)"
notes: "COHORTN=1 (Overall) index is anchored to diagnosis not treatment, hence missing. Line starts (LOT1SD etc.) and DTHFL are contract variables outside this chunk. Variable name TTDC1L; source-dated 21/6/2025 [verify]. Definition cells clipped (OUT-CLIP-TRUNCATION)."
```

#### TTD

```yaml
variable_id: TTD
spec_refs: [outcomes:16]
spec_digest: 12d444d98fdf
required_rule: "Months to inferred treatment discontinuation: missing if COHORTN=1; for COHORTN in (2..6) with ID3MOSFU=1, (LOTxED − INDEXDT + 1)/30.4375 where LOTxED is the per-cohort index-line end date."
source: {kind: vendor, inputs: {drugepisode: {line_end: LineEndDate}, lot: {line_end: EndDate}}}
grain: [patientid, cohortn]
anchor: index_date
window: FU
record_selection: "the per-cohort index-line end date: LOT1ED (COHORTN=2), LOT1MED (3), LOT2ED (4), LOT2MED (5), LOT3ED (6)"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "COHORTN=1 → missing; COHORTN in (2..6) AND ID3MOSFU=1: (LOTxED − INDEXDT + 1)/30.4375. 30.4375 = DAYS_PER_MONTH (study_period:17). The spec gives only this end-date formula with NO censoring branch for a patient who did not discontinue (TTDFL=0) — whether LOTxED is the intended value for all patients or a censor at follow-up end should apply is undefined (BLOCKED: OUT-TTD-CENSOR)."
cohort_applicability: "COHORTN in (2..6); COHORTN=1 → missing"
missing: {no_record: "LOTxED missing → missing", present_null: "COHORTN=1 → missing"}
units: months
depends_on: [INDEX, ID3MOSFU, TTDFL]
output: {physical_name: ttd, target_published_name: TTD, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-TTD-CENSOR]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until the censoring rule is settled (OUT-TTD-CENSOR); e.g. COHORTN=2, LOT1ED=2022-06-30, INDEXDT=2022-01-01 → (181)/30.4375 ≈ 5.95 months"
notes: "The +1 convention carries a [verify] marker routed to Implementation (row-2). Line end dates (LOTxED) are contract variables outside this chunk. Variable name TTD1L."
```

#### TTNTFL

```yaml
variable_id: TTNTFL
spec_refs: [outcomes:17]
spec_digest: 99b098db66c5
required_rule: "Presence-of-next-LOT-or-death flag (1=Yes, 0=No, missing): missing if COHORTN=1 or <3 months potential follow-up; otherwise 1 if (a new line beyond the cohort's threshold OR DTHFL=1), else 0."
source: {kind: vendor, inputs: {lot: {line_number: LineNumber}, mortality: {date_of_death: DateOfDeath}}}
grain: [patientid, cohortn]
anchor: index_date
window: FU
record_selection: "patient-level LOTN count against the per-cohort next-line threshold"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "COHORTN=1 → missing; with ID3MOSFU=1: COHORTN in (2,3): (LOTN>1 OR DTHFL=1)→1 else 0; COHORTN in (4,5): (LOTN>2 OR DTHFL=1)→1 else 0; COHORTN=6: (LOTN>3 OR DTHFL=1)→1 else 0. Missing if the patient lacks ≥3 months potential follow-up after index (ID3MOSFU≠1)."
cohort_applicability: "COHORTN in (2..6); COHORTN=1 → missing"
missing: {no_record: "COHORTN=1 or ID3MOSFU≠1 → missing", present_null: n/a}
units: n/a
depends_on: [ID3MOSFU]
output: {physical_name: ttntfl, target_published_name: TTNTFL, name_status: undecided, type: integer, nullable: true, codes: "0=No;1=Yes;.=missing", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "COHORTN=2, ID3MOSFU=1, LOTN=2 → TTNTFL=1; COHORTN=2, ID3MOSFU=1, LOTN=1, DTHFL=0 → TTNTFL=0"
notes: "Drafted straight — all per-cohort LOTN thresholds are stated. LOTN and DTHFL are contract variables outside this chunk. The '3 months potential follow-up' gate is ID3MOSFU (itself decision_required on its threshold). The bracketed '[Overall cohort]' token is a cohort label, not a missing rule."
```

#### TTNT

```yaml
variable_id: TTNT
spec_refs: [outcomes:18]
spec_digest: 757609957133
required_rule: "Time to next treatment in months: missing if COHORTN=1; for COHORTN in (2..6), if TTNTFL=1 then (MIN(next-LOT start, DTHDT) − INDEXDT + 1)/30.4375; if TTNTFL=0 then censor at FUED (FUED − INDEXDT + 1)/30.4375."
source: {kind: vendor, inputs: {lot: {line_start: StartDate}, mortality: {date_of_death: DateOfDeath}}}
grain: [patientid, cohortn]
anchor: index_date
window: FU
record_selection: "event date = MIN(next-LOT start, DTHDT) per cohort: LOT2SD (COHORTN=2,3), LOT3SD (4,5), LOT4SD (6); censor date = FUED"
tie_break: {equidistant: n/a, same_day: "MIN(next-LOT start, DTHDT) already selects the earlier of the two"}
derivation: "COHORTN=1 → missing; TTNTFL=1: (MIN(next-LOT start, DTHDT) − INDEXDT + 1)/30.4375; TTNTFL=0: (FUED − INDEXDT + 1)/30.4375. 30.4375 = DAYS_PER_MONTH. FUED (follow-up end) is referenced as the censor but is not yet fully defined in study_period ('need to define end of follow-up') — dependency noted, not invented."
cohort_applicability: "COHORTN in (2..6); COHORTN=1 → missing"
missing: {no_record: "FUED / next-LOT start unavailable → missing", present_null: "COHORTN=1 → missing"}
units: months
depends_on: [INDEX, TTNTFL]
output: {physical_name: ttnt, target_published_name: TTNT, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "COHORTN=2, TTNTFL=1, LOT2SD=2022-04-01, DTHDT=missing, INDEXDT=2022-01-01 → (91)/30.4375 ≈ 2.99 months"
notes: "Drafted from the stated event/censor structure; the per-cohort continuation is clipped at the right page edge (OUT-CLIP-TRUNCATION) but the MIN(next-LOT start, DTHDT) pattern is legible. FUED and DTHDT are contract variables outside this chunk; FUED's own definition is a study_period open item."
```

#### TSSTFL

```yaml
variable_id: TSSTFL
spec_refs: [outcomes:19]
spec_digest: bf40a69161f2
required_rule: "Next-2-LOTs-or-death-present flag (1=Yes, 0=No, missing): missing if COHORTN=1 or <3 months potential follow-up; otherwise 1 if the 2nd-subsequent line is reached (source-defined per-cohort LOTN thresholds) OR DTHFL=1, else 0."
source: {kind: vendor, inputs: {lot: {line_number: LineNumber}, mortality: {date_of_death: DateOfDeath}}}
grain: [patientid, cohortn]
anchor: index_date
window: FU
record_selection: "patient-level LOTN count against the source-defined per-cohort 2nd-subsequent-line threshold"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "COHORTN=1 → missing; with ID3MOSFU=1: COHORTN in (2,3): (LOTN≥3 OR DTHFL=1)→1 else 0; COHORTN in (4,5): (LOTN≥4 OR DTHFL=1)→1 else 0; COHORTN=6: (LOTN≥5 OR DTHFL=1)→1 else 0. Thresholds are source-defined (Prior spec, Epi read) — NOT ambiguous. Missing if <3 months potential follow-up (ID3MOSFU≠1)."
cohort_applicability: "COHORTN in (2..6); COHORTN=1 → missing"
missing: {no_record: "COHORTN=1 or ID3MOSFU≠1 → missing", present_null: n/a}
units: n/a
depends_on: [ID3MOSFU]
output: {physical_name: tsstfl, target_published_name: TSSTFL, name_status: undecided, type: integer, nullable: true, codes: "0=No;1=Yes;.=missing", role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "COHORTN=2, ID3MOSFU=1, LOTN=3 → TSSTFL=1; COHORTN=4, ID3MOSFU=1, LOTN=3, DTHFL=0 → TSSTFL=0"
notes: "Drafted straight — thresholds resolved per Prior spec / Epi read (≥N form). The engine currently generalizes LOTN>N and is to align to ≥N (Implementation follow-up, row-2). The values header shows '0=missing' while the values cell shows '0=No, missing' — recorded as OUT-TSSTFL-VALUES."
```

#### TSST

```yaml
variable_id: TSST
spec_refs: [outcomes:20]
spec_digest: ca8f7637ef8f
required_rule: "Time to 2nd-subsequent treatment in months: missing if COHORTN=1; for COHORTN in (2..6), if TSSTFL=1 then (MIN(2nd-subsequent-LOT start, DTHDT) − INDEXDT + 1)/30.4375; if TSSTFL=0 then censor at FUED (FUED − INDEXDT + 1)/30.4375."
source: {kind: vendor, inputs: {lot: {line_start: StartDate}, mortality: {date_of_death: DateOfDeath}}}
grain: [patientid, cohortn]
anchor: index_date
window: FU
record_selection: "event date = MIN(2nd-subsequent-LOT start, DTHDT) per cohort: LOT3SD (COHORTN=2,3), LOT4SD (4,5), LOT5SD (6); censor date = FUED"
tie_break: {equidistant: n/a, same_day: "MIN(2nd-subsequent-LOT start, DTHDT) selects the earlier of the two"}
derivation: "COHORTN=1 → missing; TSSTFL=1: (MIN(2nd-subsequent-LOT start, DTHDT) − INDEXDT + 1)/30.4375; TSSTFL=0: (FUED − INDEXDT + 1)/30.4375. 30.4375 = DAYS_PER_MONTH. Event set follows the cohort-specific ≥N thresholds (see TSSTFL). FUED censor dependency noted, not invented."
cohort_applicability: "COHORTN in (2..6); COHORTN=1 → missing"
missing: {no_record: "FUED / 2nd-subsequent-LOT start unavailable → missing", present_null: "COHORTN=1 → missing"}
units: months
depends_on: [INDEX, TSSTFL]
output: {physical_name: tsst, target_published_name: TSST, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: []
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "COHORTN=2, TSSTFL=1, LOT3SD=2022-07-01, DTHDT=missing, INDEXDT=2022-01-01 → (182)/30.4375 ≈ 5.98 months"
notes: "Drafted from the stated event/censor structure. Carries a [verify] sign-off marker. FUED and DTHDT are contract variables outside this chunk; FUED's own definition is a study_period open item."
```

#### RWR1

```yaml
variable_id: RWR1
spec_refs: [outcomes:21]
spec_digest: 3b31c1832f58
required_rule: "Real-world response for line 1 (character): map scaled rwR Assessment CR→'Complete Response', PR→'Partial Response', SD→'Stable disease', PD→'Progressive disease', Unknown→'Unknown', else 'Missing', assessed in the interval (1L start + 14 days, 1L end) on line 1, non-maintenance."
source: {kind: vendor, inputs: {response: {assessment: Assessment}}}
grain: [patientid, cohortn]
anchor: 1L start
window: "(1L start + 14 days, 1L end)"
record_selection: "assessments in (1L start + 14 days, 1L end) on line 1, non-maintenance; best-vs-first selection unresolved (BLOCKED: OUT-RWR-SELECTION)"
tie_break: {equidistant: n/a, same_day: "multiple assessments in the window — best response vs first response is not stated (BLOCKED: OUT-RWR-SELECTION)"}
derivation: "CR→'Complete Response'; PR→'Partial Response'; SD→'Stable disease'; PD→'Progressive disease'; Unknown→'Unknown'; else 'Missing'. Two blocked items: (a) whether the window may draw on the scaled rwR Add-On at all (subscription/scope not confirmed — BLOCKED: OUT-RWR-ADDON); (b) when several assessments fall in the window, best vs first response (BLOCKED: OUT-RWR-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no assessment in the window → 'Missing'", present_null: "Assessment null/other → 'Missing'"}
units: n/a
depends_on: []
output: {physical_name: rwr1, target_published_name: RWR1, name_status: undecided, type: string, nullable: true, codes: "1=Complete Response;2=Partial Response;3=Stable disease;4=Progressive disease;5=Unknown;6=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWR-SELECTION, OUT-RWR-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until best-vs-first selection and Add-On scope are settled (OUT-RWR-SELECTION, OUT-RWR-ADDON)"
notes: "Assessment from Enhanced_Ovarian_Response_Scaled (scaled rwR Add-On). i=1 (line 1). The +14 response-window boundary carries a [verify] sign-off marker (OUT-RWR-WINDOW-VERIFY). Variable name carries [verify name]. RWR1N is the numeric child."
```

#### RWR2

```yaml
variable_id: RWR2
spec_refs: [outcomes:22]
spec_digest: bfa70c67a06f
required_rule: "Real-world response for line 2 (character): map scaled rwR Assessment CR→'Complete Response', PR→'Partial Response', SD→'Stable disease', PD→'Progressive disease', Unknown→'Unknown', else 'Missing', assessed in the interval (2L start + 14 days, 2L end) on line 2, non-maintenance."
source: {kind: vendor, inputs: {response: {assessment: Assessment}}}
grain: [patientid, cohortn]
anchor: 2L start
window: "(2L start + 14 days, 2L end)"
record_selection: "assessments in (2L start + 14 days, 2L end) on line 2, non-maintenance; best-vs-first selection unresolved (BLOCKED: OUT-RWR-SELECTION)"
tie_break: {equidistant: n/a, same_day: "multiple assessments in the window — best vs first not stated (BLOCKED: OUT-RWR-SELECTION)"}
derivation: "CR→'Complete Response'; PR→'Partial Response'; SD→'Stable disease'; PD→'Progressive disease'; Unknown→'Unknown'; else 'Missing'. Blocked on scaled rwR Add-On scope (OUT-RWR-ADDON) and best-vs-first selection (OUT-RWR-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no assessment in the window → 'Missing'", present_null: "Assessment null/other → 'Missing'"}
units: n/a
depends_on: []
output: {physical_name: rwr2, target_published_name: RWR2, name_status: undecided, type: string, nullable: true, codes: "1=Complete Response;2=Partial Response;3=Stable disease;4=Progressive disease;5=Unknown;6=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWR-SELECTION, OUT-RWR-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until OUT-RWR-SELECTION and OUT-RWR-ADDON are settled"
notes: "Assessment from Enhanced_Ovarian_Response_Scaled (scaled rwR Add-On). i=2 (line 2). +14 window carries [verify] (OUT-RWR-WINDOW-VERIFY); variable name carries [verify name]. RWR2N is the numeric child."
```

#### RWR3

```yaml
variable_id: RWR3
spec_refs: [outcomes:23]
spec_digest: cec728d769e6
required_rule: "Real-world response for line 3 (character): map scaled rwR Assessment CR→'Complete Response', PR→'Partial Response', SD→'Stable disease', PD→'Progressive disease', Unknown→'Unknown', else 'Missing', assessed in the interval (3L start + 14 days, 3L end) on line 3, non-maintenance."
source: {kind: vendor, inputs: {response: {assessment: Assessment}}}
grain: [patientid, cohortn]
anchor: 3L start
window: "(3L start + 14 days, 3L end)"
record_selection: "assessments in (3L start + 14 days, 3L end) on line 3, non-maintenance; best-vs-first selection unresolved (BLOCKED: OUT-RWR-SELECTION)"
tie_break: {equidistant: n/a, same_day: "multiple assessments in the window — best vs first not stated (BLOCKED: OUT-RWR-SELECTION)"}
derivation: "CR→'Complete Response'; PR→'Partial Response'; SD→'Stable disease'; PD→'Progressive disease'; Unknown→'Unknown'; else 'Missing'. Blocked on scaled rwR Add-On scope (OUT-RWR-ADDON) and best-vs-first selection (OUT-RWR-SELECTION)."
cohort_applicability: all cohorts
missing: {no_record: "no assessment in the window → 'Missing'", present_null: "Assessment null/other → 'Missing'"}
units: n/a
depends_on: []
output: {physical_name: rwr3, target_published_name: RWR3, name_status: undecided, type: string, nullable: true, codes: "1=Complete Response;2=Partial Response;3=Stable disease;4=Progressive disease;5=Unknown;6=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWR-SELECTION, OUT-RWR-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until OUT-RWR-SELECTION and OUT-RWR-ADDON are settled"
notes: "Assessment from Enhanced_Ovarian_Response_Scaled (scaled rwR Add-On). i=3 (line 3). +14 window carries [verify] (OUT-RWR-WINDOW-VERIFY); variable name carries [verify name]. RWR3N is the numeric child."
```

#### RWR1N

```yaml
variable_id: RWR1N
spec_refs: [outcomes:24]
spec_digest: d81f1ba3e19a
required_rule: "Numeric recode of RWR1: 1=Complete Response, 2=Partial Response, 3=Stable disease, 4=Progressive disease, 5=Unknown, 6=Missing."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: 1L start
window: "(1L start + 14 days, 1L end)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of RWR1: 'Complete Response'→1, 'Partial Response'→2, 'Stable disease'→3, 'Progressive disease'→4, 'Unknown'→5, 'Missing'→6. Underivable until RWR1 is settled (BLOCKED: OUT-RWR-SELECTION, OUT-RWR-ADDON)."
cohort_applicability: all cohorts
missing: {no_record: "RWR1='Missing' → 6", present_null: n/a}
units: n/a
depends_on: [RWR1]
output: {physical_name: rwr1n, target_published_name: RWR1N, name_status: undecided, type: integer, nullable: true, codes: "1=Complete Response;2=Partial Response;3=Stable disease;4=Progressive disease;5=Unknown;6=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWR-SELECTION, OUT-RWR-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "RWR1='Stable disease' → RWR1N=3 (once RWR1 is derivable)"
notes: "Numeric child of RWR1; the 1..6 recode is fully stated but inherits RWR1's open selection/Add-On items. Window inherited (1L start+14, 1L end), line 1, non-maintenance. Variable name carries [verify name]."
```

#### RWR2N

```yaml
variable_id: RWR2N
spec_refs: [outcomes:25]
spec_digest: 75ebf559a574
required_rule: "Numeric recode of RWR2: 1=Complete Response, 2=Partial Response, 3=Stable disease, 4=Progressive disease, 5=Unknown, 6=Missing."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: 2L start
window: "(2L start + 14 days, 2L end)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of RWR2: 'Complete Response'→1, 'Partial Response'→2, 'Stable disease'→3, 'Progressive disease'→4, 'Unknown'→5, 'Missing'→6. Underivable until RWR2 is settled (BLOCKED: OUT-RWR-SELECTION, OUT-RWR-ADDON)."
cohort_applicability: all cohorts
missing: {no_record: "RWR2='Missing' → 6", present_null: n/a}
units: n/a
depends_on: [RWR2]
output: {physical_name: rwr2n, target_published_name: RWR2N, name_status: undecided, type: integer, nullable: true, codes: "1=Complete Response;2=Partial Response;3=Stable disease;4=Progressive disease;5=Unknown;6=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWR-SELECTION, OUT-RWR-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "RWR2='Partial Response' → RWR2N=2 (once RWR2 is derivable)"
notes: "Numeric child of RWR2; recode fully stated but inherits RWR2's open items. Window inherited (2L start+14, 2L end), line 2, non-maintenance. Variable name carries [verify name]."
```

#### RWR3N

```yaml
variable_id: RWR3N
spec_refs: [outcomes:26]
spec_digest: a36bc58a9ffe
required_rule: "Numeric recode of RWR3: 1=Complete Response, 2=Partial Response, 3=Stable disease, 4=Progressive disease, 5=Unknown, 6=Missing."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: 3L start
window: "(3L start + 14 days, 3L end)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of RWR3: 'Complete Response'→1, 'Partial Response'→2, 'Stable disease'→3, 'Progressive disease'→4, 'Unknown'→5, 'Missing'→6. Underivable until RWR3 is settled (BLOCKED: OUT-RWR-SELECTION, OUT-RWR-ADDON)."
cohort_applicability: all cohorts
missing: {no_record: "RWR3='Missing' → 6", present_null: n/a}
units: n/a
depends_on: [RWR3]
output: {physical_name: rwr3n, target_published_name: RWR3N, name_status: undecided, type: integer, nullable: true, codes: "1=Complete Response;2=Partial Response;3=Stable disease;4=Progressive disease;5=Unknown;6=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWR-SELECTION, OUT-RWR-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "RWR3='Complete Response' → RWR3N=1 (once RWR3 is derivable)"
notes: "Numeric child of RWR3; recode fully stated but inherits RWR3's open items. Window inherited (3L start+14, 3L end), line 3, non-maintenance. Variable name carries [verify name]."
```

#### RWR1M

```yaml
variable_id: RWR1M
spec_refs: [outcomes:27]
spec_digest: 4ad7704515b9
required_rule: "Real-world response on maintenance for line 1 (character), best response: map scaled rwR Assessment CR→'Complete Response', PR→'Partial Response', SD→'Stable disease', PD→'Progressive disease', Unknown→'Unknown', else 'Missing', in the interval (1L start + 14 days, 1L end) on line 1, maintenance=True."
source: {kind: vendor, inputs: {response: {assessment: Assessment}, lot: {is_maintenance: IsMaintenanceTherapy}}}
grain: [patientid, cohortn]
anchor: 1L start
window: "(1L start + 14 days, 1L end)"
record_selection: "best response among maintenance-line assessments in (1L start + 14 days, 1L end) on line 1"
tie_break: {equidistant: n/a, same_day: "best response is taken (CR>PR>SD>PD>Unknown)"}
derivation: "CR→'Complete Response'; PR→'Partial Response'; SD→'Stable disease'; PD→'Progressive disease'; Unknown→'Unknown'; else 'Missing'. Maintenance=True (IsMaintenanceTherapy). Best response is stated for the maintenance variants, so selection is NOT blocked; but drawing on the scaled rwR Add-On is unconfirmed (BLOCKED: OUT-RWR-ADDON). The source chain drops the terminal 'else Missing' and carries unbalanced quotes (OUT-CLIP-TRUNCATION); Missing=6 is confirmed by the value set."
cohort_applicability: all cohorts
missing: {no_record: "no maintenance assessment in the window → 'Missing'", present_null: "Assessment null/other → 'Missing'"}
units: n/a
depends_on: []
output: {physical_name: rwr1m, target_published_name: RWR1M, name_status: undecided, type: string, nullable: true, codes: "1=Complete Response;2=Partial Response;3=Stable disease;4=Progressive disease;5=Unknown;6=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWR-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until scaled rwR Add-On scope is settled (OUT-RWR-ADDON)"
notes: "Maintenance variant (i=1); IsMaintenanceTherapy from LineOfTherapy. Best response prioritised per the spec. +14 window carries [verify] (OUT-RWR-WINDOW-VERIFY); chain truncation recorded in OUT-CLIP-TRUNCATION. Variable name carries [verify name]. RWR1MN is the numeric child."
```

#### RWR2M

```yaml
variable_id: RWR2M
spec_refs: [outcomes:28]
spec_digest: 9a0f67e1bbc5
required_rule: "Real-world response on maintenance for line 2 (character), best response: map scaled rwR Assessment CR→'Complete Response', PR→'Partial Response', SD→'Stable disease', PD→'Progressive disease', Unknown→'Unknown', else 'Missing', in the interval (2L start + 14 days, 2L end) on line 2, maintenance=True."
source: {kind: vendor, inputs: {response: {assessment: Assessment}, lot: {is_maintenance: IsMaintenanceTherapy}}}
grain: [patientid, cohortn]
anchor: 2L start
window: "(2L start + 14 days, 2L end)"
record_selection: "best response among maintenance-line assessments in (2L start + 14 days, 2L end) on line 2"
tie_break: {equidistant: n/a, same_day: "best response is taken (CR>PR>SD>PD>Unknown)"}
derivation: "CR→'Complete Response'; PR→'Partial Response'; SD→'Stable disease'; PD→'Progressive disease'; Unknown→'Unknown'; else 'Missing'. Maintenance=True. Selection resolved (best response); blocked on scaled rwR Add-On scope (OUT-RWR-ADDON). Source chain drops terminal 'else Missing' with unbalanced quotes (OUT-CLIP-TRUNCATION); Missing=6 confirmed by the value set."
cohort_applicability: all cohorts
missing: {no_record: "no maintenance assessment in the window → 'Missing'", present_null: "Assessment null/other → 'Missing'"}
units: n/a
depends_on: []
output: {physical_name: rwr2m, target_published_name: RWR2M, name_status: undecided, type: string, nullable: true, codes: "1=Complete Response;2=Partial Response;3=Stable disease;4=Progressive disease;5=Unknown;6=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWR-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until scaled rwR Add-On scope is settled (OUT-RWR-ADDON)"
notes: "Maintenance variant (i=2). Best response prioritised. +14 window carries [verify] (OUT-RWR-WINDOW-VERIFY); truncation recorded in OUT-CLIP-TRUNCATION. Variable name carries [verify name]. RWR2MN is the numeric child."
```

#### RWR3M

```yaml
variable_id: RWR3M
spec_refs: [outcomes:29]
spec_digest: b28222d39472
required_rule: "Real-world response on maintenance for line 3 (character), best response: map scaled rwR Assessment CR→'Complete Response', PR→'Partial Response', SD→'Stable disease', PD→'Progressive disease', Unknown→'Unknown', else 'Missing', in the interval (3L start + 14 days, 3L end) on line 3, maintenance=True."
source: {kind: vendor, inputs: {response: {assessment: Assessment}, lot: {is_maintenance: IsMaintenanceTherapy}}}
grain: [patientid, cohortn]
anchor: 3L start
window: "(3L start + 14 days, 3L end)"
record_selection: "best response among maintenance-line assessments in (3L start + 14 days, 3L end) on line 3"
tie_break: {equidistant: n/a, same_day: "best response is taken (CR>PR>SD>PD>Unknown)"}
derivation: "CR→'Complete Response'; PR→'Partial Response'; SD→'Stable disease'; PD→'Progressive disease'; Unknown→'Unknown'; else 'Missing'. Maintenance=True. Selection resolved (best response); blocked on scaled rwR Add-On scope (OUT-RWR-ADDON). Source chain drops terminal 'else Missing' with unbalanced quotes (OUT-CLIP-TRUNCATION); Missing=6 confirmed by the value set."
cohort_applicability: all cohorts
missing: {no_record: "no maintenance assessment in the window → 'Missing'", present_null: "Assessment null/other → 'Missing'"}
units: n/a
depends_on: []
output: {physical_name: rwr3m, target_published_name: RWR3M, name_status: undecided, type: string, nullable: true, codes: "1=Complete Response;2=Partial Response;3=Stable disease;4=Progressive disease;5=Unknown;6=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWR-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until scaled rwR Add-On scope is settled (OUT-RWR-ADDON)"
notes: "Maintenance variant (i=3). Best response prioritised. +14 window carries [verify] (OUT-RWR-WINDOW-VERIFY); truncation recorded in OUT-CLIP-TRUNCATION. Variable name carries [verify name]. RWR3MN is the numeric child."
```

#### RWR1MN

```yaml
variable_id: RWR1MN
spec_refs: [outcomes:30]
spec_digest: 9a63bc35c76d
required_rule: "Numeric recode of RWR1M: 1=Complete Response, 2=Partial Response, 3=Stable disease, 4=Progressive disease, 5=Unknown, 6=Missing."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: 1L start
window: "(1L start + 14 days, 1L end)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of RWR1M: 'Complete Response'→1, 'Partial Response'→2, 'Stable disease'→3, 'Progressive disease'→4, 'Unknown'→5, 'Missing'→6. Underivable until RWR1M is settled (BLOCKED: OUT-RWR-ADDON)."
cohort_applicability: all cohorts
missing: {no_record: "RWR1M='Missing' → 6", present_null: n/a}
units: n/a
depends_on: [RWR1M]
output: {physical_name: rwr1mn, target_published_name: RWR1MN, name_status: undecided, type: integer, nullable: true, codes: "1=Complete Response;2=Partial Response;3=Stable disease;4=Progressive disease;5=Unknown;6=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWR-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "RWR1M='Complete Response' → RWR1MN=1 (once RWR1M is derivable)"
notes: "Numeric child of RWR1M; the source lists 1..4 explicitly with '(Unknown=5, Missing=6) [verify]', consistent with the value set. Window inherited (1L start+14, 1L end), line 1, maintenance=True. Variable name carries [verify name]."
```

#### RWR2MN

```yaml
variable_id: RWR2MN
spec_refs: [outcomes:31]
spec_digest: c0cb86dd1c7e
required_rule: "Numeric recode of RWR2M: 1=Complete Response, 2=Partial Response, 3=Stable disease, 4=Progressive disease, 5=Unknown, 6=Missing."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: 2L start
window: "(2L start + 14 days, 2L end)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of RWR2M: 'Complete Response'→1, 'Partial Response'→2, 'Stable disease'→3, 'Progressive disease'→4, 'Unknown'→5, 'Missing'→6. Underivable until RWR2M is settled (BLOCKED: OUT-RWR-ADDON)."
cohort_applicability: all cohorts
missing: {no_record: "RWR2M='Missing' → 6", present_null: n/a}
units: n/a
depends_on: [RWR2M]
output: {physical_name: rwr2mn, target_published_name: RWR2MN, name_status: undecided, type: integer, nullable: true, codes: "1=Complete Response;2=Partial Response;3=Stable disease;4=Progressive disease;5=Unknown;6=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWR-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "RWR2M='Stable disease' → RWR2MN=3 (once RWR2M is derivable)"
notes: "Numeric child of RWR2M; recode consistent with the value set ('(Unknown=5, Missing=6) [verify]'). Window inherited (2L start+14, 2L end), line 2, maintenance=True. Variable name carries [verify name]."
```

#### RWR3MN

```yaml
variable_id: RWR3MN
spec_refs: [outcomes:32]
spec_digest: b43940a9e74d
required_rule: "Numeric recode of RWR3M: 1=Complete Response, 2=Partial Response, 3=Stable disease, 4=Progressive disease, 5=Unknown, 6=Missing."
source: {kind: derived}
grain: [patientid, cohortn]
anchor: 3L start
window: "(3L start + 14 days, 3L end)"
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "numeric code of RWR3M: 'Complete Response'→1, 'Partial Response'→2, 'Stable disease'→3, 'Progressive disease'→4, 'Unknown'→5, 'Missing'→6. Underivable until RWR3M is settled (BLOCKED: OUT-RWR-ADDON)."
cohort_applicability: all cohorts
missing: {no_record: "RWR3M='Missing' → 6", present_null: n/a}
units: n/a
depends_on: [RWR3M]
output: {physical_name: rwr3mn, target_published_name: RWR3MN, name_status: undecided, type: integer, nullable: true, codes: "1=Complete Response;2=Partial Response;3=Stable disease;4=Progressive disease;5=Unknown;6=Missing", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWR-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "RWR3M='Progressive disease' → RWR3MN=4 (once RWR3M is derivable)"
notes: "Numeric child of RWR3M; recode consistent with the value set ('(Unknown=5, Missing=6) [verify]'). Window inherited (3L start+14, 3L end), line 3, maintenance=True. Variable name carries [verify name]."
```

#### PFS2

```yaml
variable_id: PFS2
spec_refs: [outcomes:33]
spec_digest: 80b80ab42111
required_rule: "rwPFS after subsequent treatment: an event-flag / event-date / months family measuring, from INDEXDT, time to progression after the start of the subsequent line of therapy (LOTxSD) or death; alive-and-not-progressed censored at the last clinic visit date."
source: {kind: vendor, inputs: {progression: {progression_date: PROGRESSIONDATE, last_clinic_note_date: LASTCLINICNOTEDATE}, lot: {line_start: StartDate}}}
grain: [patientid, cohortn]
anchor: index_date
window: STUDY_PD
record_selection: "event = first progression after the subsequent-line start (LOTxSD per cohort) or death; censor = last clinic visit date / LASTCLINICNOTEDATE"
tie_break: {equidistant: n/a, same_day: "if a death date precedes the progression date, the progression date is used as the event date"}
derivation: "Event-date: from INDEXDT to progression after the subsequent-line start (COHORTN=2 after LOT3SD, COHORTN=4/5 requiring LOT4SD, COHORTN=6 requiring LOT5SD) or death; if no progression event, use death date; if death precedes progression, use progression date. Months: analogous to PFS with 30.4375. The per-cohort event/flag/date/months definitions are heavily truncated across the row (BLOCKED: OUT-PFS2-DEFINITION) and depend on the same valid-progression-event definition as rwPFS (BLOCKED: OUT-PFS-PROGRESSION-DEF)."
cohort_applicability: "COHORTN in (2..6); COHORTN=1 to confirm"
missing: {no_record: "no progression and no death → censor at last clinic visit / LASTCLINICNOTEDATE", present_null: "COHORTN=1 → to confirm"}
units: months
depends_on: [INDEX, ELIGPFS]
output: {physical_name: pfs2, target_published_name: PFS2, name_status: undecided, type: number, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-PFS2-DEFINITION, OUT-PFS-PROGRESSION-DEF]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until the truncated per-cohort definition is restated (OUT-PFS2-DEFINITION) and the progression-event definition is settled (OUT-PFS-PROGRESSION-DEF)"
notes: "Progression / LASTCLINICNOTEDATE from Enhanced_Ovarian_Progression; subsequent-line starts (LOTxSD) from LineOfTherapy. The row crams flag/date/months sub-variables into one spec row and carries multiple [verify]/[to confirm] markers and truncation (OUT-CLIP-TRUNCATION). Variable name carries [verify name]; source-dated 15July2025 [date to confirm]."
```

#### RWAE_ADVERSEEVENT

```yaml
variable_id: RWAE_ADVERSEEVENT
spec_refs: [outcomes:34]
spec_digest: 45b292ba653d
required_rule: "Real-world adverse-event term (coded), one row per Patient × line-of-therapy × AE, from the Enhanced_Ovarian_AdverseEvents Add-On feed. AE terms are project/subscription-specific and not enumerated in the spec."
source: {kind: vendor, inputs: {adverse_events: {ae_term: AdverseEvent}}}
grain: [patientid, lot, ae]
anchor: n/a
window: n/a
record_selection: "one row per Patient × line-of-therapy × AE"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the coded rwAE term from the Enhanced_Ovarian_AdverseEvents feed. The term codelist is project/subscription-specific and is not enumerated in the spec. This is an ADDITIVE Add-On requiring a Program subscription and is marked DEFER/proposed — availability/scope is unconfirmed (BLOCKED: OUT-RWAE-ADDON)."
cohort_applicability: all cohorts
missing: {no_record: "no AE record for the patient-line → no rwAE rows", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: rwae_adverseevent, target_published_name: RWAE_AdverseEvent, name_status: undecided, type: string, nullable: true, codes: "project/subscription-specific term codelist (enumerate in codelists once scoped)", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWAE-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until the rwAE Add-On subscription/scope is confirmed (OUT-RWAE-ADDON)"
notes: "Source Enhanced_Ovarian_AdverseEvents (Add-On table family). The spec names the table but not the term column; the physical column is proposed from the field label. ADDITIVE, DEFER/proposed."
```

#### RWAE_ONSETDATE

```yaml
variable_id: RWAE_ONSETDATE
spec_refs: [outcomes:35]
spec_digest: 7d1a7cb3e170
required_rule: "Onset date (+ Day/Month/Year granularity) of the AE, capturing the first new-or-worsened instance only; the companion PresentAtBaseline field (condition present in the 30-day pre-therapy baseline) drives the OnsetDate null-logic."
source: {kind: vendor, inputs: {adverse_events: {onset_date: OnsetDate, present_at_baseline: PresentAtBaseline}}}
grain: [patientid, lot, ae]
anchor: n/a
window: "30-day pre-therapy baseline informs PresentAtBaseline"
record_selection: "first new-or-worsened instance only"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry OnsetDate (with Day/Month/Year granularity) for the first new-or-worsened AE instance; PresentAtBaseline (Yes/No = condition present in the 30-day pre-therapy baseline) drives whether OnsetDate is nulled. Add-On requiring Program subscription, DEFER/proposed — scope unconfirmed (BLOCKED: OUT-RWAE-ADDON)."
cohort_applicability: all cohorts
missing: {no_record: "no AE record → no onset date", present_null: "PresentAtBaseline=Yes → OnsetDate null per the companion-field logic"}
units: date
depends_on: []
output: {physical_name: rwae_onsetdate, target_published_name: RWAE_OnsetDate, name_status: undecided, type: date, nullable: true, codes: n/a, role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWAE-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until the rwAE Add-On subscription/scope is confirmed (OUT-RWAE-ADDON)"
notes: "Source Enhanced_Ovarian_AdverseEvents. OnsetDate and PresentAtBaseline are named in the definition; a companion granularity flag accompanies OnsetDate. ADDITIVE, DEFER/proposed."
```

#### RWAE_GRADE

```yaml
variable_id: RWAE_GRADE
spec_refs: [outcomes:36]
spec_digest: 298abfad54ad
required_rule: "Clinician-documented CTCAE-style severity grade of the AE: 1 / 2 / 3 / 4 / 5 / Not documented."
source: {kind: vendor, inputs: {adverse_events: {grade: Grade}}}
grain: [patientid, lot, ae]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the clinician-documented CTCAE grade {1,2,3,4,5,Not documented} from the AE feed. Add-On requiring Program subscription, DEFER/proposed — scope unconfirmed (BLOCKED: OUT-RWAE-ADDON)."
cohort_applicability: all cohorts
missing: {no_record: "no AE record → no grade row", present_null: "grade not recorded → 'Not documented'"}
units: n/a
depends_on: []
output: {physical_name: rwae_grade, target_published_name: RWAE_Grade, name_status: undecided, type: string, nullable: true, codes: "1;2;3;4;5;Not documented", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWAE-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until the rwAE Add-On subscription/scope is confirmed (OUT-RWAE-ADDON)"
notes: "Source Enhanced_Ovarian_AdverseEvents. Grading scale (CTCAE) is stated. The physical column is proposed from the field label. ADDITIVE, DEFER/proposed."
```

#### RWAE_SEVERITY

```yaml
variable_id: RWAE_SEVERITY
spec_refs: [outcomes:37]
spec_digest: 719e5a152556
required_rule: "Terminological severity of the AE (distinct from CTCAE Grade): Mild / Moderate / Severe / Life-threatening / Fatal / Not documented."
source: {kind: vendor, inputs: {adverse_events: {severity: Severity}}}
grain: [patientid, lot, ae]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the terminological severity {Mild,Moderate,Severe,Life-threatening,Fatal,Not documented} from the AE feed; distinct from Grade. Add-On requiring Program subscription, DEFER/proposed — scope unconfirmed (BLOCKED: OUT-RWAE-ADDON)."
cohort_applicability: all cohorts
missing: {no_record: "no AE record → no severity row", present_null: "severity not recorded → 'Not documented'"}
units: n/a
depends_on: []
output: {physical_name: rwae_severity, target_published_name: RWAE_Severity, name_status: undecided, type: string, nullable: true, codes: "Mild;Moderate;Severe;Life-threatening;Fatal;Not documented", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWAE-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until the rwAE Add-On subscription/scope is confirmed (OUT-RWAE-ADDON)"
notes: "Source Enhanced_Ovarian_AdverseEvents. Distinct from Grade. Physical column proposed from the field label. ADDITIVE, DEFER/proposed."
```

#### RWAE_DRUGATTRIBUTION

```yaml
variable_id: RWAE_DRUGATTRIBUTION
spec_refs: [outcomes:38]
spec_digest: 4c8fb2aa5a70
required_rule: "Attribution of the AE to the therapy of interest: Definite / Likely / Not attributed / No documentation."
source: {kind: vendor, inputs: {adverse_events: {drug_attribution: DrugAttribution}}}
grain: [patientid, lot, ae]
anchor: n/a
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the clinician-documented attribution of the AE to the therapy of interest {Definite,Likely,Not attributed,No documentation}. Add-On requiring Program subscription, DEFER/proposed — scope unconfirmed (BLOCKED: OUT-RWAE-ADDON)."
cohort_applicability: all cohorts
missing: {no_record: "no AE record → no attribution row", present_null: "attribution not recorded → 'No documentation'"}
units: n/a
depends_on: []
output: {physical_name: rwae_drugattribution, target_published_name: RWAE_DrugAttribution, name_status: undecided, type: string, nullable: true, codes: "Definite;Likely;Not attributed;No documentation", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWAE-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until the rwAE Add-On subscription/scope is confirmed (OUT-RWAE-ADDON)"
notes: "Source Enhanced_Ovarian_AdverseEvents. Attribution is clinician-documented as delivered; the spec does not state an algorithmic attribution rule. Physical column proposed from the field label. ADDITIVE, DEFER/proposed."
```

#### RWAE_RESOLUTION

```yaml
variable_id: RWAE_RESOLUTION
spec_refs: [outcomes:39]
spec_digest: 7e435f60b0fc
required_rule: "AE status at the end of the line of therapy (+ ResolutionDate + granularity): Resolved / Resolving / Resolved with sequelae / Ongoing / Fatal / Not documented."
source: {kind: vendor, inputs: {adverse_events: {resolution_status: ResolutionStatus, resolution_date: ResolutionDate}}}
grain: [patientid, lot, ae]
anchor: end of line of therapy
window: n/a
record_selection: "AE status assessed at the end of the line of therapy"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the AE resolution status {Resolved,Resolving,Resolved with sequelae,Ongoing,Fatal,Not documented} at the end of the line of therapy, plus ResolutionDate and its granularity. Add-On requiring Program subscription, DEFER/proposed — scope unconfirmed (BLOCKED: OUT-RWAE-ADDON)."
cohort_applicability: all cohorts
missing: {no_record: "no AE record → no resolution row", present_null: "status not recorded → 'Not documented'; ongoing AE → ResolutionDate null"}
units: n/a
depends_on: []
output: {physical_name: rwae_resolution, target_published_name: RWAE_Resolution, name_status: undecided, type: string, nullable: true, codes: "Resolved;Resolving;Resolved with sequelae;Ongoing;Fatal;Not documented", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWAE-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until the rwAE Add-On subscription/scope is confirmed (OUT-RWAE-ADDON)"
notes: "Source Enhanced_Ovarian_AdverseEvents. Carries a companion ResolutionDate + granularity. Physical columns proposed from the field label. ADDITIVE, DEFER/proposed."
```

#### RWAE_RELATEDOUTCOME

```yaml
variable_id: RWAE_RELATEDOUTCOME
spec_refs: [outcomes:40]
spec_digest: d8824dead1e2
required_rule: "Outcome in response to the AE, one row per outcome: Hospitalization / Dose-or-schedule change / Treatment for AE / Discontinuation / Hold / None / Death."
source: {kind: vendor, inputs: {adverse_events_outcomes: {related_outcome: Outcome}}}
grain: [patientid, lot, ae, outcome]
anchor: n/a
window: n/a
record_selection: "one row per AE-related outcome"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry the AE-related outcome {Hospitalization,Dose-or-schedule change,Treatment for AE,Discontinuation,Hold,None,Death} from the Enhanced_Ovarian_AdverseEvents_Outcomes feed, one row per outcome. Add-On requiring Program subscription, DEFER/proposed — scope unconfirmed (BLOCKED: OUT-RWAE-ADDON)."
cohort_applicability: all cohorts
missing: {no_record: "no AE-outcome record → no related-outcome rows", present_null: n/a}
units: n/a
depends_on: []
output: {physical_name: rwae_relatedoutcome, target_published_name: RWAE_RelatedOutcome, name_status: undecided, type: string, nullable: true, codes: "Hospitalization;Dose-or-schedule change;Treatment for AE;Discontinuation;Hold;None;Death", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWAE-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until the rwAE Add-On subscription/scope is confirmed (OUT-RWAE-ADDON)"
notes: "Source Enhanced_Ovarian_AdverseEvents_Outcomes (separate child table at a per-outcome grain). Physical column proposed from the field label. ADDITIVE, DEFER/proposed."
```

#### RWAE_HOSPITALIZATION

```yaml
variable_id: RWAE_HOSPITALIZATION
spec_refs: [outcomes:41]
spec_digest: dff7456a8ddd
required_rule: "AE-related hospitalization, one row per admission: AdmissionDate (+ granularity) and HospitalizationType (AE-led / AE-during admission)."
source: {kind: vendor, inputs: {adverse_events_hospitalizations: {admission_date: AdmissionDate, hospitalization_type: HospitalizationType}}}
grain: [patientid, lot, ae, admission]
anchor: n/a
window: n/a
record_selection: "one row per AE-related admission"
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "carry AdmissionDate (with granularity) and HospitalizationType {AE-led, AE-during admission} from the Enhanced_Ovarian_AdverseEvents_Hospitalizations feed, one row per admission. Add-On requiring Program subscription, DEFER/proposed — scope unconfirmed (BLOCKED: OUT-RWAE-ADDON)."
cohort_applicability: all cohorts
missing: {no_record: "no AE-hospitalization record → no admission rows", present_null: "AdmissionDate granularity may be partial"}
units: date
depends_on: []
output: {physical_name: rwae_hospitalization, target_published_name: RWAE_Hospitalization, name_status: undecided, type: date, nullable: true, codes: "HospitalizationType: AE-led | AE-during admission", role: published}
status: {requirement: decision_required, source: unverified, implementation: not_implemented, validation: not_run}
decision_ids: [OUT-RWAE-ADDON]
gap_ids: []
publish: {ads: proposed, dictionary: proposed, dashboard: undecided, tfl: undecided}
acceptance: "cannot be fixed until the rwAE Add-On subscription/scope is confirmed (OUT-RWAE-ADDON)"
notes: "Source Enhanced_Ovarian_AdverseEvents_Hospitalizations (separate child table at a per-admission grain). AdmissionDate and HospitalizationType are named in the values. ADDITIVE, DEFER/proposed."
```

