Drop the RWB program specification in this folder, then delete this file.

    PROG_SPEC_<PROGRAM>_<TUMOUR>_<YYYYMM>.xlsx      <- the production path, read directly

A folder of `.md` stand-ins works too — that is what exists when the workbook cannot be brought
into the repo. To try it with a real one:

    cp -r "products/oncology/prostate/202606/prog_spec/." \
          "sandbox/new_tumour_start/prog_spec/"

Nothing here is read by NAME. `spec_pipeline/pipeline.conf` names a `material_id`, `source_refs.yaml`
maps that id to a path, and the extractor reads whatever the path resolves to. Rename this folder and
update `source_refs.yaml` and it still works; drop a file in without registering it and nothing reads it.
