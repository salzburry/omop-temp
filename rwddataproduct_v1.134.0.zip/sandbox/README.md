# sandbox — run the pipeline without enrolling a pack in governance

Anything under `products/` becomes a PACK the moment it carries `source_refs.yaml`,
`handoff/MATURITY.yaml`, `handoff/FUNCTIONAL_CONTRACT.md`, `spec_pipeline/pipeline.conf` or
`config/data_product.yaml`. Discovery is by shape — that is what lets a new tumour be picked up by
adding a folder instead of editing CI — and it is why copying the template *into* `products/`
immediately fails Gate 1 on its own placeholders and joins every `--list-*` loop.

`sandbox/` is outside `products/`, so `product_gates.products()` never sees it: no gate, no CI step,
no discovery loop. The tools still work on it because each takes the pack path as an argument rather
than resolving it through the registry.

## Two directories, one purpose each

| | |
|---|---|
| `new_tumour_start/` | the pristine starter — placeholders only, expected to FAIL Gate 1 until filled in |
| `experiments/` | frozen snapshots of past exploratory runs, each with its own README |

That separation is deliberate and was learned the hard way. A completed 295-record ovarian run was
drafted directly INTO `new_tumour_start`, so the directory was simultaneously the empty starter this
file describes and a finished contract. While it was both, neither description was true of it: the
starter no longer failed Gate 1 on its own placeholders, and the run's own header still claimed the
scope the starter had. **Draft into a copy, never into the starter.**

## `new_tumour_start/`

The smallest pack that can register a specification and generate a contract from it — nine files,
every one a placeholder. Open `new_tumour_start/START_HERE.md` and work down it.

It must keep failing: `source_manifest.py sandbox/new_tumour_start --check` reports errors on the
unreplaced placeholders, and its contract test reports `no FUNCTIONAL_CONTRACT.md`. Both are the
documented starting state, not a problem to fix in place.

It deliberately does NOT contain `config/`, `variables/`, `codelists/`, the approval forms or
`ENGINE_GAPS.md`. Those are the Gate 4/5 half; they live in `platform/TUMOR_TEMPLATE/` and get copied
in when a contract exists. Carrying them from day one is eight files of `REPLACE_ME` sitting in a pack
that has not finished Gate 2.

Verified: stripping to these nine files reaches Gate 1 and generates all 199 records against the
prostate 202606 specification, identically to the full template.

## `experiments/`

Snapshots of runs worth keeping, one directory each, each carrying a README that says what it is and
what is inconsistent inside it. They are frozen: not regenerated, not drift-checked, not discovered.
`ovarian_202606_contract_draft/` is the run described above, kept because what it demonstrates is a
whole class of failure — records that are individually plausible while the header, scope, counts,
coverage and maturity claim around them were never brought back into agreement.

## Rules

Nothing here is drift-checked, so anything generated goes stale as soon as the specification or the
tools move. Regenerate before reading, and never cite it as evidence — a pack with no gates is safe to
experiment in and counts for nothing, which is the same fact stated twice.

Do not add a `products/registry.yaml` entry for a sandbox pack. The registry is what every DEFAULT
product lookup resolves through; an entry pointing here would send them all into the sandbox.
