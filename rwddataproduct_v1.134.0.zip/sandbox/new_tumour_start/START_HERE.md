# Start a tumour from scratch

Everything in this folder is a placeholder. Gate 1 REFUSES it as it stands — that is the point: a
half-filled template is an unevidenced claim, so it cannot be adopted by accident. Try it first:

    python3 platform/tools/source_manifest.py sandbox/new_tumour_start --check

    ai_classification '<sponsor_ai_eligible | ...>' is not one of sponsor_ai_eligible, ...
    status:pending requires `classified_by`
    status:pending requires `classified_date`
    path_or_link 'products/<family>/<slug>/<YYYYMM>/...' names a path in the repo that does not exist

Then clear them one at a time and watch the errors go.

## 1. Put a specification in `prog_spec/`

See the note in that folder.

## 2. `source_refs.yaml`

Replace `product`, `spec_version`, `document_id`, `classified_by`, `classified_date`, and set
`path_or_link` to the folder or workbook from step 1. Choose the `ai_classification`: it follows the
CONTENT's provenance, never the folder — a sponsor-authored spec is `sponsor_ai_eligible`; anything
vendor-originated or vendor-derived is not.

## 3. `spec_pipeline/pipeline.conf`

`TUMOR` = the slug. `SPEC_SOURCE_ID` = the `material_id` the extractor should read.

## 4. Run it

### Gate 1 — registration. Pure Python, runs anywhere.

    python3 platform/tools/source_manifest.py <PACK> --check

Do not go on until this says `OK  0 error(s)`.

### Gate 2 — generation.

`run_spec_pipeline.sh` is the only bash in the workflow. Where bash exists:

    bash platform/tools/run_spec_pipeline.sh <PACK>
    bash platform/tools/run_spec_pipeline.sh <PACK> --check    # later: are the artifacts current?

Git for Windows ships one:

    & "C:\Program Files\Git\bin\bash.exe" platform/tools/run_spec_pipeline.sh <PACK>

Without bash, run the pipeline directly — same tool, no shell:

    python3 platform/tools/run_spec_pipeline.py <PACK>

The `.sh` is a one-line wrapper around that file, so the two cannot diverge.

`--check` does NOT generate. It regenerates into a temp directory and byte-compares that against
`spec_pipeline/out/`, which is why the paths it prints are under `Temp\` and why nothing appears in
your pack: a verifier that wrote over the files it compares against could never report drift. It is
for CI and for "are these artifacts still current?" — not for the first run. Generate with no flag.

If you would rather see each step, the six calls are, in this order. `<TUMOR>` and `<SPEC_SOURCE_ID>` are
the two values in `spec_pipeline/pipeline.conf`.

PowerShell:

    $P = "<PACK>"; $T = "platform/tools"; $O = "$P/spec_pipeline/out"
    New-Item -ItemType Directory -Force -Path $O | Out-Null

    $SRC = py $T/source_manifest.py $P --resolve <SPEC_SOURCE_ID>

    py $T/spec_extract.py "$SRC" --out "$O/extracted.json"
    py $T/spec_lint.py "$O/extracted.json" --tumor <TUMOR> --format json | Out-File -Encoding utf8 "$O/lint.json"
    py $T/spec_lint.py "$O/extracted.json" --tumor <TUMOR>                | Out-File -Encoding utf8 "$O/SPEC_FINDINGS.txt"
    py $T/contract_scaffold.py "$O/extracted.json" --product $P --lint "$O/lint.json" `
       --coverage "$O/COVERAGE.md" --out "$O/scaffold.json" --records "$O/SCAFFOLDED_RECORDS.md"
    py $T/spec_codelists.py "$O/extracted.json" --product $P --out "$O/ENUMERATION_CANDIDATES.yaml"

Step 1 resolves the material through `source_refs.yaml` — that is why the pipeline never names a
path. If `$SRC` comes back as the `TBD …` text rather than a folder, `SPEC_SOURCE_ID` is pointing at
the workbook material instead of the one the extractor should read.

Seven files must appear in `spec_pipeline/out/`. Fewer means a step failed — check each command's exit
code rather than trusting the last one.

If step 2 says **`read 0 requirement rows`**, the extractor found no specification: the folder still
holds only `PUT_THE_SPEC_HERE.md`, or `path_or_link` points somewhere else. It refuses rather than
writing an empty `extracted.json`, because everything downstream would then be truthful about nothing
— no defects found, nothing undispositioned, no records scaffolded — and `--check` would compare seven
empty files against seven identical empty files and call them current.

Seven generated files appear in `spec_pipeline/out/`. The two to read:

  * `SCAFFOLDED_RECORDS.md` — one contract record per specification row. Every judgment field is
    `TODO`: the machine fills the citation, the spec's rule verbatim and a digest binding the record
    to that text, and refuses to invent the source mapping, grain, window or worked example.
  * `COVERAGE.md` — every spec item, all `UNDISPOSITIONED`, because coverage measures
    `handoff/FUNCTIONAL_CONTRACT.md` and there isn't one yet.

## 4b. Approve the sanitized extraction — or nothing may read it

The pipeline has run and the artifacts are on disk. **The drafting skill and `spec_slice.py` will
still refuse.** That is not a defect and it is the step people miss, because everything above it
succeeded.

What AI reads is not your specification. It is `spec_pipeline/out/extracted.json`, a DERIVED artifact
from which vendor documentation has been redacted — and it has to be registered and approved in its
own right, because the classification on the input says nothing about the file that gets opened.

    python3 platform/tools/source_manifest.py --register-ai-extraction sandbox/new_tumour_start

That prints a block to paste into `source_refs.yaml` with every mechanical field computed — the path,
the artifact hash, the extraction fingerprint, the redaction-policy digest, the redaction counts — and
**five TODOs no tool may fill in**: what the artifact is classified as, who judged it so, who approves
it for AI use, and the two dates. Answer them, set `status: reviewed`, then:

    python3 platform/tools/source_manifest.py sandbox/new_tumour_start --check   # Gate 1
    python3 platform/tools/spec_slice.py sandbox/new_tumour_start --domain demographics

Gate 1 refuses an unstated classification at any status, so the pack is RED from the moment you paste
the block until a person answers it. That is what an unclassified material is; the fix is the answer,
not a default. From then on Gate 1 verifies the recorded hash against the artifact on every run, so
re-running the pipeline revokes the approval rather than inheriting it.

## 5. The actual work — UNDISPOSITIONED -> accounted for

Four routes, and only four:

| the spec... | you write | result |
|---|---|---|
| answers it | a record in `handoff/FUNCTIONAL_CONTRACT.md` citing that row | `mapped` |
| does NOT answer it | the record + a question in `handoff/DECISIONS.md`, `requirement: decision_required` | accounted, Gate 2 stays open |
| the row is not a variable | an entry in `handoff/spec_dispositions.yaml` naming where it IS handled | its disposition |
| the row is a banner | nothing | `context`, detected automatically |

Create `handoff/FUNCTIONAL_CONTRACT.md` yourself — the template does not ship one, because an empty
contract is a claim that there is nothing to require. Paste records from `SCAFFOLDED_RECORDS.md` into
it as you work them.

Check as you go:

    python3 platform/tools/contract_lint.py sandbox/new_tumour_start
    bash platform/tools/run_spec_pipeline.sh sandbox/new_tumour_start --strict

Pasting records unedited makes coverage green and the lint red — 200 unwritten fields. Only doing the
work clears both. That disagreement is deliberate: coverage proves nothing was overlooked, the lint
proves it was actually written.

## What is NOT here

`config/`, `variables/`, `codelists/` and the two approval forms are the Gate 4 half and live in
`platform/TUMOR_TEMPLATE/`. Copy them in when a contract exists. `handoff/ENGINE_GAPS.md` comes later
still — nothing can fall short of a requirement before there is a build.

Do NOT add a `products/registry.yaml` entry for this pack. The registry is what every default product
lookup resolves through; an entry pointing here would send them all into the sandbox.
