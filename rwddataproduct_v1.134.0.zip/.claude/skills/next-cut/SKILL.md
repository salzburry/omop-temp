---
name: next-cut
version: "1.0.1"   # bump on any change to the skill's INSTRUCTIONS — the version guard
                   # holds .claude/skills to platform/VERSION, and this names which
                   # instruction set a session ran; the commit SHA pins the exact bytes
description: >
  Bootstrap the next cut of an existing product when a revised RWB workbook arrives: compare the
  old and new packs with spec_diff on digest evidence, carry forward what provably survived, and
  route only what actually changed into re-drafting. Use for "the revised workbook landed", "stand
  up the next version from the previous one", "what carries forward", "did the revision fix what we
  reported". Do not use for the first cut of a new tumour (platform/TUMOR_TEMPLATE/NEW_TUMOUR.md),
  to draft or revise individual records (that is draft-contract-record), or for a data refresh with
  no requirement change (WORKFLOW.md §6.B). Never infer the packs — if the request does not name
  both the old and the new version, ask.
---

# Bootstrapping the next cut from the previous one

`governance/WORKFLOW.md` §6.C owns this branch, and the comparison has an owner: `spec_diff.py`.
This repository has already paid for skipping it once: a revision arrived with 196 of 200 rows
byte-identical and was re-extracted and re-drafted from scratch anyway — the questions recurred
under new ids, and neither answer the previous cut had settled carried across. The numbers live in
`platform/tools/spec_diff.py`'s own docstring; this skill exists so they never recur.

Two defaults pull against each other here, and both hold. Per RECORD, re-drafting is the default
and carrying is earned — a digest that recomputes identical against the new extraction is evidence,
and anything uncheckable is RE-DRAFT, never carried. Per CUT, reuse is the default — a settled
answer attached to text that provably did not change is never re-asked, and re-drafting an
unchanged record is the failure this skill exists to prevent.

## 1. Resolve both packs

`products/<area>/<tumour>/<old>` and `products/<area>/<tumour>/<new>`, both explicit. **Never infer
either.** If the request names the tumour but only one version, ask — "the previous one" is a guess
about lineage, and a carry computed against the wrong base carries the wrong judgments perfectly.

## 2. Establish READ_ONLY or APPLY, and say which

State your mode in your first sentence, exactly as `draft-contract-record` §2 defines the two, with
the same repository-wide baseline-and-diff discipline in every mode. **Unclear → READ_ONLY, and say
so.** The comparison (step 4), the findings check (step 5) and the carry plan (step 6) are all
READ_ONLY — `spec_diff.py` writes nothing into any pack, and the plan lands outside the checkout.
Applying carry commands, copying a register, or touching `SPEC_QC_FINDINGS.md` is APPLY.

## 3. Preconditions — check them, and stop where the act is not yours

**The new pack exists, with a COMPLETE re-extraction.** §6.C: extract the whole workbook, then
scope the review — a partial re-extraction misses deleted rows, moved requirements, and changes
outside the area anyone believed was affected, and every one of those is exactly what the diff is
for. The pipeline (`spec_extract.py` under `run_spec_pipeline.py`) reads the material named by the
new pack's `spec_pipeline/pipeline.conf`. Verify currency read-only:

```bash
python3 platform/tools/run_spec_pipeline.py <new pack> --check    # reports, writes nothing
```

If `spec_pipeline/out/` is missing or stale, generating it (`run_spec_pipeline.py <new pack>`
without `--check`) REGENERATES seven governed artifacts — an APPLY act on the new pack. In
READ_ONLY, report the state and stop.

**Gate 1 registration of the revised workbook is a human act. Name it and stop.**

```bash
python3 platform/tools/source_manifest.py <new pack> --check
```

If the new workbook is not `status: reviewed` in `<new pack>/source_refs.yaml`, say precisely what
is owed and by whom: a person (RWP) records the material — filename, revision, approval date,
approver, AI classification — with the sha256 computed by `source_manifest.py <new pack>
--record-digest <material_id>` so the checksum is never typed. Declaring a document revision
authoritative is an act of authority; no tool grants it and no session performs it. You may compare
and plan against an unregistered extraction; you must say the basis is provisional, in those words.

**The registry.** The new pack is built ALONGSIDE the old; `current_spec_version` moves only in the
final promotion change, never at the start (`platform/TUMOR_TEMPLATE/NEW_TUMOUR.md`).

## 4. Read the delta — the comparison has an owner

```bash
python3 platform/tools/spec_diff.py <old pack> <new pack>
```

It compares by CONTENT hash, not row number, and partitions every record in the old pack's
contract:

| verdict | meaning |
|---|---|
| **CARRIES AS-IS** | the record's `spec_digest` recomputes identical against the NEW extraction — the cited text is unchanged |
| **CARRIES, NEW REF** | the same text at a different row number — `spec_refs` updates, nothing else does |
| **RE-DRAFT** | the cited text changed or is gone, or the record has no checkable digest — fail-closed |

The verdict is `contract_lint.spec_digest` recomputed against the new extraction — the same
function I15 uses, so the lint and the carry can never disagree about whether text changed. It is
evidence, not resemblance: a wrongly carried record is a requirement nobody re-read, asserting a
rule the specification may no longer make. The report also lists the decisions attached to carrying
records — with which are already ANSWERED — and the findings section below. Quote its counts rather
than summarising them.

## 5. Did the revision fix what was reported?

The same run answers it, per OPEN row of the old pack's `handoff/SPEC_QC_FINDINGS.md`, by content
— a defect whose row merely moved cannot read as corrected:

| verdict | meaning |
|---|---|
| `still there` | cited text unchanged — the defect survives, and re-drafting against it re-inherits it |
| `changed — review` | cited text changed or gone — a person reads the new text, then sets the finding `corrected` or `waived` |
| `uncheckable` | the citation is unparsable or absent from the old extraction — fix the citation; a defect the check cannot see did not go away |

**The register's status moves only on this evidence.** `still there` findings go back to RWB before
the revision is adopted — a revision can be nominally new and fix nothing, and this section is what
says so before anyone re-drafts against the same defects. `changed — review` is a review to have,
not a closure to write: writing `SPEC_QC_FINDINGS.md` is APPLY, and the corrected/waived judgment
is a human's after reading the new text.

## 5b. What the moved rows have made unverified

`spec_diff` says WHICH rows moved. It does not say what those rows reach, and that is the half a
re-drafting session forgets: the records get re-drafted, the lint is clean, the artifacts
regenerate — and a golden case citing one of those rows was never re-run.

```bash
python3 platform/tools/change_impact.py <new pack> <row> [<row> ...]
python3 platform/tools/change_impact.py <new pack> --changed-file <file of rows, one per line>
```

READ_ONLY, and it writes nothing. It walks specification row → contract record → config block →
capability → published output column → the goldens that must be re-run, reading every link from the
thing itself rather than re-deriving it, so the impact set cannot silently shrink.

Two of its answers are findings rather than empty results, and both matter here: a row **no record
cites** means the row is unimplemented or a citation is missing, and "no golden cites these rows"
is printed with the reminder that it may mean untested rather than unaffected.

## 6. Write the carry plan

```bash
python3 platform/tools/spec_diff.py <old pack> <new pack> --carry-plan <dir>
```

`<dir>` goes **outside the checkout** — under the user's home, like every restricted output in this
repository. The tool itself refuses a directory inside either pack ("the plan is an input to
drafting, not a pack artifact"); do not settle for merely clearing that guard.

What lands there is the re-draft turned into a checklist: one judgment YAML per carrying record
holding ONLY the drafter-owned fields, plus `carry_commands.txt` — the exact `contract_record.py`
invocation per record, `--item` already re-pointed at the row in the NEW pack for moved text. What
the judgments do NOT hold is as load-bearing as what they do:

- **no `status`** — `contract_record.py` injects the initial values; an approval never travels by
  omission, and every carried record starts unapproved in the new cut;
- **no `spec_refs` / `spec_digest` / `required_rule`** — re-supplied from the NEW extraction by
  `--item`, which is the entire evidentiary point;
- `# BY HAND` lines name records citing several spec rows — `--item` names one row, so a person
  chooses rather than the tool guessing;
- `# RE-DRAFT` lines name every excluded record with its reason.

## 7. Apply the carry — APPLY only

Run the commands in `carry_commands.txt` as printed. Each one passes the full drafting path —
every invariant, the AI gate, the redaction refusals — exactly as a hand-written draft would;
nothing about carrying bypasses anything. Two refusals are expected and correct:

- **I2 on an unported decision id** — the judgment carries `decision_ids`; the register row does
  not travel with it. Carry the register (step 8); never strip the citation to make the lint pass.
- **any other PROBLEM line** — a finding about the record, to report, not to smooth over.

In READ_ONLY, return the plan location and the partition counts, and run nothing.

## 8. Carry the registers — answers are facts, not questions

The diff names the decisions attached to carrying records and which are already ANSWERED. Those
answers are settled facts of this programme, and they are precisely what the last full re-draft
lost.

- **A row carries ONLY when its ground did not move.** Carry a decision's register row when
  every record citing it is CARRIES (AS-IS or NEW REF) — its question and evidence therefore
  attach to text that provably survived. A decision touching ANY RE-DRAFT record does not carry
  by copy: the new cut may have changed the cohort, source, window or premise the answer assumed,
  and an answered question whose premise moved is a NEW question. Route it to explicit
  revalidation — re-asked through a fresh form, or SUPERSEDED naming what now governs.
- **Bring the qualifying rows across as a mechanical copy** — byte-for-byte from the old pack's
  `handoff/DECISIONS.md` into the new pack's (APPLY). The `Approved by` and `Approval date` cells
  are human facts: they exist in the new register only because the copy carried them. Never retype,
  reword, or reconstruct them, and never fill a blank one — WORKFLOW.md is explicit that no tool
  may invent them; they arrive only inside a committed form.
- **An answered question whose ground held is never re-asked.** A re-drafted record touching the
  same concept cites the carried id; raising a fresh decision for a settled question is two ids
  for one thing, which no single reviewer can see. The carry condition above is what earns this:
  reuse without it would assert old answers over changed premises.
- **Still-open carried questions stay OPEN under their old ids** — the diff warns they will be
  asked again unless carried. New answers come only through `decision_record.py <pack> --forms` /
  `--apply` with a committed form.
- **If the revision itself settles an old question**, the closure is a form too — RESOLVED, or
  SUPERSEDED with `superseded_by` naming what now governs — never a silent drop from the register.
- **Check the cross-product store first**: `python3 platform/tools/precedents.py --for <new pack>`
  proposes the precedents not yet recorded against this pack. Cite an existing entry rather than
  re-arguing it; extend the store with `--add` (citations are validated live; the store stays
  advisory and powerless).

## 9. Route ONLY the RE-DRAFT partition into drafting

The `RE-DRAFT` names, with their reasons, are the entire drafting workload of the new cut — that is
what "scope the review to the delta" means as a computed list. Hand exactly that list to
`draft-contract-record`, against the NEW pack, one record per spec row, through
`contract_record.py --product <new pack> --item <domain:row>`. The changed text is read fresh from
the new slice; nothing is pasted from the old record, because the verdict just said the text that
judgment was made about no longer exists. The inverse bound is step 4's: a CARRIES-AS-IS record
never enters drafting at all.

## 10. The executable delta between cuts

Where the new cut's `config/`, `variables/` and `codelists/` were seeded by copying the old cut's
(that copy is a commit), the between-cuts question has its own owner:

```bash
python3 platform/tools/config_diff.py <new pack> --base <the seeding revision>
```

Both revisions are parsed and compared as structures, so the answer is legible: DROPPED and ADDED
keys by full path, CHANGED values old → new, REORDERED where precedence is positional — "the window
moved from -30 to -365" as a sentence, not a hunk. It attaches no clinical meaning and approves
nothing: it is the input to the new cut's Gate 4 review, which no carry replaces.

## What carries mechanically, and what a human re-approves

| carries mechanically | needs a human, again |
|---|---|
| drafter judgment fields, via the plan's YAMLs | `requirement: approved` — every status restarts at the injected initial values |
| `spec_refs` re-pointed at moved rows, by the tool | Gate 1 registration of the revised workbook — authority, checksum, approver |
| decision ids on records, and register rows — including `Approved by` / `Approval date` — via byte-for-byte copy | answers to still-OPEN questions; closure of findings (`corrected` / `waived`) |
| config files, via the git copy that seeded them | Gate 4 approval of the new cut's configuration; MATURITY claims; moving `current_spec_version` |

## What this skill never does

- **Never re-answers an answered question.** The carried decision or precedent id is cited; a
  session choosing a window, a tie-break or a fallback code because "the old pack settled it" is
  re-deciding, and re-deciding is RWB's, not yours.
- **Never re-drafts a CARRIES-AS-IS record.** Its digest against the new extraction is the
  evidence it did not change; re-reading it by hand re-introduces exactly the cost this branch
  exists to remove, and a "light touch-up" of carried prose is a re-draft wearing a smaller name.
- **Never marks a finding corrected without findings-check evidence.** `still there` is not
  arguable around, `uncheckable` is a citation to fix, and even `changed — review` licenses a
  review — the `corrected` / `waived` word in the register is a human's, written after reading the
  new text.
- **Never registers the workbook itself.** Filename, revision, sha256, approver, approval date,
  classification in `source_refs.yaml` are Gate 1 human acts; the session names the act and the
  owner, and stops.
- **Never carries a status or an approval.** No judgment file holds one, the tool injects the
  initial values, and the two approval columns travel only inside the mechanical copy — a retyped
  approval is an invented one.
- **Never writes the carry plan inside the checkout**, and never reads vendor material anywhere in
  this procedure.

If a request needs any of those, name the tool and the person, and hand it back.
