---
name: answer-decisions
version: "1.1.0"   # bump on any change to the skill's INSTRUCTIONS — the version guard
                   # holds .claude/skills to platform/VERSION, and this names which
                   # instruction set a session ran; the commit SHA pins the exact bytes
description: >
  Run the Gate 2 decision loop for an explicitly named product pack: rank the open questions by
  what each answer unblocks, assemble the packet for the person who must answer, check precedents
  before any new question is phrased, issue the answer forms, transcribe the committed answers, and
  hand back the unblock worklist. Use when a decision needs answering, when answers have come back
  from RWB, or for "what should we ask RWB". Do NOT use to answer a clinical or methodology
  question (that is RWB/BIO's), to draft or re-disposition contract records (that is
  draft-contract-record), or for a plain status page (that is operate-rwd-product). Never infer
  the pack — if the request does not name one, ask.
---

# Answering a decision

A decision is a question the specification does not answer, and the loop that settles it has one
write path. This skill runs the loop's machinery — ranking, packets, forms, transcription — and
contributes no answer at any step. **No tool may invent `Approved by` / `Approval date`; they
arrive only inside a committed form a person typed** (`governance/WORKFLOW.md`, Gate 2). Every
command below either reads, or writes through the tool that owns the artifact.

## 1. Which pack, and which of three requests

`products/<area>/<tumour>/<version>`. **Never infer it** — a decision id, a blast radius and a
question's evidence are all pack- and version-specific. If the request does not name one, ask.

Then say which shape the request is, because they stop at different steps:

| "what should we ask RWB" | steps 2–4; the ranked page and the packet are the deliverable |
| answers came back from RWB | steps 5–6, then every step of the aftermath in 7 |
| "where do the decisions stand" | step 2's terminal print — and if that is the whole request, `operate-rwd-product` is the skill |

## 2. Rank before asking

```bash
python3 platform/tools/decision_report.py <pack>
```

The order to ask in is the blast radius — how many contract records each answer unblocks — and it
is not the order the questions were raised in. The join only exists between the records and the
register, so the report is generated, never hand-maintained: it rewrites
`<pack>/handoff/RWB_QUESTIONS.md` (a committed, GENERATED page — regenerate, never hand-edit) and
prints the ranking. Read the tail of the print too: **an open decision blocking no record** is not
unimportant — it can mean a record that SHOULD cite the question does not.

A diff after the rewrite means the committed page was stale. Report that and leave the fresh page
in the tree for the user to commit — CI runs `decision_report.py <pack> --check` per pack and goes
red on a stale one.

## 3. A page per question, outside the checkout

```bash
python3 platform/tools/decision_packet.py <pack> --text
python3 platform/tools/decision_packet.py <pack> --out <dir outside the repo>/questions.html
```

One page per open decision, for the person who must answer it: the question, the evidence the
register holds, how many records it blocks, and what other tumours decided when they hit the same
thing. The pack's open specification-QC findings ride the same page, split so capture defects
(ours, fixed by re-extracting) never land on RWB's list. It composes; it computes nothing, writes
nothing to the pack, and **it is not an approval** — recording is `decision_record.py`'s, and the
page says so itself.

**`--out` is not refused inside the checkout, which is exactly why the rule lives here:**
`repo_hygiene` reports every committed `*.html` as a saved web page. Put it under the user's home,
or use `--text`.

**In chat, one question at a time.** `--text` prints every page; a stakeholder gets ONE — the
highest blast-radius question not yet settled — and the next only when they ask for it or settle
that one. The full page/file is for handing to the answerer offline, not for pasting whole into a
conversation. The same rule governs step 5: never open all the forms — point at the one form for
the question in hand, in the packet's order.

The loop this page feeds is convergent by construction: each question and each finding needs
exactly ONE act, once — answer or withdraw the question; correct the cited cell or waive the
finding — and the list only shrinks. When a revised workbook arrives, `spec_diff.py` reports per
finding whether the cited text actually changed, so a revision that fixes nothing is named before
anyone re-drafts against it.

## 4. Precedents BEFORE phrasing any new question

```bash
python3 platform/tools/precedents.py --for <pack>     # settled elsewhere, not yet recorded here
python3 platform/tools/precedents.py                  # the whole store, citations resolved live
python3 platform/tools/knowledge_graph.py --query <terms>   # every register, live, with provenance
python3 platform/tools/knowledge_graph.py --suggest         # unpaired same-question candidates
```

Advisory and deliberately powerless: the store holds no answers, only (pack, decision) citations
read live through the register, and no gate reads it. Its whole job is to stop this pack
re-arguing a question another product settled. What another tumour decided is EVIDENCE shown to
the answerer, never an approval to adopt.

If a genuinely new question must be raised, that is a register edit and it belongs to the drafting
workflow (`draft-contract-record`, APPLY): phrased as a question, with the conflicting evidence,
cited from the affected records via `decision_ids`. This skill's part is the lookup first — two
ids for one question is invisible to every single reviewer, because both entries look correct.

## 5. Issue the forms; a human signs

```bash
python3 platform/tools/decision_record.py <pack> --forms
```

One YAML form per OPEN decision lands in `handoff/decision_answers/<ID>.yaml`. Each carries the
question, the evidence, `question_sha256` — the hash of both as issued, so an answer can never be
transcribed onto a question that changed after the answerer read it — and `records_sha256`, the
same discipline over the CITING RECORDS' requirement fields: the contract stays hand-editable,
but an edit under an open question invalidates the outstanding form loudly. An existing form is
**never overwritten**, whatever it contains: it may be half-typed by the person answering. A stale
form is retired by deleting it, which is a visible act in a diff.

**The human types `answer`, `answered_by` and `answer_date` into the form BY HAND and commits
it.** Those become the register's `Approved by` / `Approval date`. There is no `--by` flag and
never will be — the caller that would misreport a value is the caller that would pass the flag —
and the session types NONE of the three, in any mode, dictated or not. `status:` stays `RESOLVED`
for an answer; `WITHDRAWN` and `SUPERSEDED` (with `superseded_by`) are retractions, and demanding
a signature on a retraction is what the tool deliberately does not do.

## 6. The wave

```bash
python3 platform/tools/decision_record.py <pack> --apply          # every form in decision_answers/
python3 platform/tools/decision_record.py <pack> --apply FORM...  # or exactly these
```

All-or-nothing: every form is validated before a single row changes, and one defect in ANY form
refuses the whole wave — `REFUSED — nothing was written`. The refusals, each the point:

| a blank or placeholder `answer`, `answered_by` or `answer_date` on a RESOLVED form | an answer nobody is recorded as having given is what this tool exists to end |
| `answered_by` names a team or a bare acronym | the approver is a person (`not_a_person`); initials like `J.S.` pass, `RWP` does not |
| `answer_date` is not a real `YYYY-MM-DD` date | a date that cannot be checked is not an attestation |
| a stale `question_sha256` | the question or its evidence moved after the form was issued — delete the form, re-issue with `--forms`; the answer may no longer answer what is asked |
| a stale or missing `records_sha256` | a record CITING this question changed while it was open (or the form predates the freeze) — the answerer judged the records as they stood; delete the form, re-issue, and have the answer re-read against the records as they now stand |
| the row is already settled and the form differs | **a recorded answer is never overwritten.** Add a NEW decision row for the revised question (drafting work), then record the old one as `status: SUPERSEDED` / `superseded_by: <new ID>` |
| a `\|` in the answer | the register is a markdown table and its readers split on pipes — rephrase |
| `status:` left OPEN, or SUPERSEDED naming nothing, itself, or an id not in the register | a form settles a question; anything else is not a recordable act |

Re-applying a wave is expected and idempotent — a form whose content already matches its row
prints `already recorded` and is skipped. **The filled forms stay committed after the wave**: the
register cell is the index, the form is the answer as the person typed it, and a later edit to
either one is a visible diff.

## 7. Aftermath — the handback

`--apply` prints the unblock worklist itself, computed before the write: each settled decision and
the records that cite it and still say `decision_required`. That is `contract_lint` **I11** — a
record is `decision_required` if and only if it cites an OPEN requirement-level decision — so the
lint names those records until each is re-dispositioned, in both directions; **I2** keeps every
cited `decision_id` resolving while rows are added or superseded. Writing the answers into the
records is drafting judgment: hand the worklist to `draft-contract-record`, one record at a time,
never a batch edit here.

Then, in order:

```bash
python3 platform/tools/decision_report.py <pack>    # regenerate RWB_QUESTIONS.md — the list must shrink
python3 platform/tools/contract_lint.py <pack>      # reprints the I11 worklist until it is empty
python3 platform/tools/finalize.py <pack> --check   # only if the contract changed — its stated numbers must still agree
python3 platform/tools/precedents.py --add --key <entry> --pack <pack> --decision <ID>
```

The last is manual on purpose: no matcher can pair two registers' spellings of one question, and
the judgment that they are one question is a person's, made while the answer is fresh. A recurring
question with no entry yet gets `--add --new <kebab-id> --question '...'` with two or more
`--pack`/`--decision` pairs. CI runs `decision_report.py --check` and `finalize.py --check` per
pack, so a wave that lands without its regenerations goes red — but CI is the backstop, not the
procedure.

## What this skill never does

- **Never answers a clinical or methodology question.** Study windows, index rules, tie-breaks,
  missing-data meaning, clinical grouping — ranking, phrasing and transcribing are this loop's
  whole contribution. "What should the window be" is RWB's, and the honest reply names the open
  decision and who owns it.
- **Never types a form field.** Not `answer`, not `answered_by`, not `answer_date` — not even a
  value the user dictated in chat. The person types and commits the form themselves; a
  session-typed field is an attestation the attester never made.
- **Never marks a decision RESOLVED by hand, and never edits `DECISIONS.md` directly.**
  `decision_record.py --apply` is the only write path for an answer. A hand edit bypasses the hash
  binding, the person and the date in one motion — it is exactly the clerical loop the tool
  exists to end.
- **Never overwrites or deletes a recorded answer.** A wrong answer is superseded by a new row,
  never corrected in place; a committed form is retired by its owner, not regenerated over.
- **Never re-dispositions the unblocked records on the way past.** The worklist is the handback,
  and each record on it goes through the drafting skill's own procedure.

If a request needs any of those, name the tool and the person, and hand it back.
