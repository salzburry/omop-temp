---
name: propose-source-mapping
version: "1.3.0"   # bump on any change to the skill's INSTRUCTIONS — the version guard
                   # holds .claude/skills to platform/VERSION, and this names which
                   # instruction set a session ran; the commit SHA pins the exact bytes
description: >
  Assemble mapping-candidate evidence for a pack's source gaps — roles the config reads with no
  physical table, or declared stems the delivery does not carry — rank the candidates from a
  human-cleared MAPPING_EVIDENCE.json (names and kinds only, binding-verified), and hand a person
  the evidence with blockers stated. Use when a pack has pending or missing source mappings and a
  mapping-evidence file exists ("what could supply biomarkers", "propose mappings for mcrc",
  "which delivered table matches this role"). NEVER use to decide that two columns mean the same
  thing, to edit `sources:` or any config, to set `source_mapping` status, or to read vendor
  tables, workbooks, or the restricted profiler TSV. If the request names no pack or no evidence
  file, ask.
---

# Proposing source mappings — evidence in, judgment out

The workflow this skill drives, and where it stops, comes from an external review:

    AI ranks mapping candidates
    → deterministic schema checks (column NAMES and kinds; declared physical types are shown
      beside candidates for the person — type/grain/join COMPATIBILITY against live data is
      NOT yet validated by any tool, and is never AI's judgment)
    → RWP reviews and approves
    → an approved mapping updates the YAML (a person's reviewed edit)

This skill is the first arrow only. `platform/tools/propose_source_mapping.py` computes the gaps,
the ranked candidates, the evidence counts and the blockers — all deterministic, all recheckable.
What this skill adds on top is READING: explaining the evidence, spotting what the arithmetic
cannot (a table whose name matches but whose vocabulary looks wrong for the concept), and drafting
the decision question when the answer is not mechanical.

## 1. Resolve the pack and the evidence — and which evidence an AI session may touch

Both named, never inferred. TWO evidence files exist and they are not interchangeable:

  * `MAPPING_EVIDENCE.json` — names and kinds only, produced by `mapping_evidence.py` beside the
    profiler. Its binding (product, schema, cut, modes, profile sha256) is READ from the
    profile's own embedded provenance, never typed as arguments. It is born
    `ai_eligibility: requires_human_review`; the person who confirms it carries names and kinds
    only edits `state` to `reviewed` and signs `reviewed_by` / `review_date` in the file. The
    proposal tool refuses it until then — and no AI session performs that review or edits those
    fields. **This is the only file an AI session reads.**
  * the `data_profiler.R` TSV — counts, dates and top values. RESTRICTED. It stays on the
    governed platform, and this skill must never read it or ask for it to be pasted. (An
    external review caught this skill's first version calling the TSV "sanitized" while the
    profiler's own classification said otherwise. The profiler was right.)

If neither exists, stop: the evidence run is a human/RWDE act on the governed platform, and this
skill must not substitute the workbook, the vendor tables, or memory for it.

## 2. Run the tool, read the evidence

    python3 platform/tools/propose_source_mapping.py <pack> --profile MAPPING_EVIDENCE.json

The tool verifies the evidence binding before ranking anything — wrong product, a partial
profile, or synthetic evidence each refuse by name.

For each gap it prints candidates with counted evidence (`4/4 required columns`, grain-key
presence, name-token overlap) and blockers (`required column(s) absent: ...`). Its own
recommendation vocabulary is deliberately small:

  * `map_candidate` — exactly ONE delivered table carries every required column. The mechanical
    case. Even here, a person applies it.
  * `do_not_map` — everything else: every candidate blocked, no evidence at all, or MORE THAN ONE
    clean candidate. Two clean candidates is an ambiguity, and picking the higher score would be
    the silent-closest-name failure with extra steps.

## 3. Add the reading the arithmetic cannot do — and no more

Say what the evidence supports and what it cannot settle. The line you must not cross, in the
review's own examples: whether `DateOfDeath` means day-level `DEATH_DT`; whether a visit date can
substitute for `LAST_CLINIC_NOTE_DT`; whether vendor platinum status equals a derived algorithm;
whether one row per patient versus per test changes the concept. Those are RWP/RWB decisions —
draft them as decision questions (the answer-decisions skill owns that path), never as answers.

## 4. Hand over, do not apply

  * `--patch` prints a COMMENTED proposal block for the `map_candidate` gaps. Give it to the
    person; moving a line into `sources:` is their reviewed edit.
  * A mapping someone is considering gets `--validate role=table` — non-zero on any deterministic
    blocker. Passing EARNS A REVIEW, never an application; the tool's own output says so.
  * `confirmed_mappings` and the `source_mapping` status axis stay human-entered with rationale,
    through the apply-source-verdicts path. This skill changes nothing about that boundary — it is
    the boundary that makes the proposal safe to make.

## How much to trust the ranking — measured, not asserted

    python3 platform/tools/mapping_benchmark.py

Leave-one-out over prostate's and OC's APPROVED `sources:` maps, against the synthetic schemas the
smoke build runs on. Current baseline, measured under adversarial near-miss decoys: OC 12/12 top-1, prostate 11/15 top-1 and 14/15 top-3, and —
the number that must stay zero — 0 unsafe proposals (a `map_candidate` naming a wrong table) on
either pack. Those baselines are FLOORS the benchmark itself enforces, plus an abstention cap so
total abstention can never read as a pass. The prostate misses are patientid+date tables that
genuinely share a schema, where abstaining IS the correct answer. The benchmark scores the
ENGINEERING layer only; the clinical layer is constitutionally unscored, and the harness's own
tests pin that a number can never appear under it.

## What this skill never does

Edit config or contract. Read a vendor table, a workbook, the profiler TSV, or anything outside a
human-cleared `MAPPING_EVIDENCE.json`. Conclude semantic equivalence from name similarity — the
tool refuses to and so does this skill. Silently pick among clean candidates. Proceed without a
named pack and evidence file.
