# Dashboard layer (`dashboard/`)

Consumer-facing dashboard variables for the RWDPs.

- the dashboard variable definitions — the source spec, held by the sponsor with the other
  source documents.
- `dashboard_vars.yaml` — **machine-readable** panel/variable layout. **Status: seed** — a
  representative set whose variables reference codes in `../metadata/catalog.yaml`; the full
  set needs stand-in from the PDF.

Cross-checked by `platform/tests/test_catalog.py` (every dashboard variable resolves to a catalog
code). Phase 5 will generate the consumer data dictionary from this + the catalog (reuse
`rwddataproduct_example/build_dictionary` patterns).
