# TFL layer (`products/_reporting/tfl/`)

Tables, Figures, and Listings — the analytic deliverables produced from each tumor's ADS.

- `tfl_specs.yaml` — the TFL shells (Table 1 demographics, baseline clinical, treatment
  distribution, OS KM figure, patient listing), each referencing variable codes in
  `../metadata/catalog.yaml`. **Status: seed** — extend per the SAP / mock shells.
- Engine: `platform/engine/tfl.py` — `load_specs()` / `tfl_plan()` (which TFLs are producible
  from a given ADS) are pure-Python and tested; `generate()` produces the tables on Spark
  (figures/listings stubbed — wire to your plotting/export layer).

TFLs are produced **after** the refresh passes QC (see `../refreshes/README.md`), and are
versioned alongside the refresh manifest so each delivered table traces back to a spec version +
git commit + data cut.
