# Data dictionary (`dictionary/`)

The consumer-facing variable spec, generated per **audience** from the master catalog
(`../metadata/catalog.yaml`).

- `audiences.yaml` — the audience contract. Generalised from the legacy `internal/sales/customer`
  model to **neutral** names: `internal` (full, codes + applicability, PII flagged), `partner`
  (external stakeholder spec — **replaces "sales"** — trimmed to label-level, **PII dropped**),
  `customer` (label + applicability, PII dropped).
- Engine: `platform/engine/dictionary.py` — `build_dictionary()` / `render_markdown()`
  (pure-Python) filter by tumor applicability + per-variable `pii`/`audiences` flags and project to
  the audience's columns. Observed-values / %-patients statistics are an optional `stats` input
  computed from the ADS on a cluster.

```bash
python3 platform/engine/dictionary.py ../metadata/catalog.yaml --audience partner --tumor mcrpc
```

A dictionary is generated **after** a refresh passes QC, versioned with its refresh manifest
(`../refreshes/`), so each delivered dictionary traces to a spec version + git commit + data cut.
PII never ships in `partner`/`customer` outputs.
