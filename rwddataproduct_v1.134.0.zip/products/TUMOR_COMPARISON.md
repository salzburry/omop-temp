# Cross-tumor comparison (prostate · EC · OC) → a complete, unified config structure

Derived by reconstructing the three original R/dbplyr build scripts from the originals:
`prostate/prostate_rdap.R`, `endometrial/endometrial_rdap.R`, `oc/ovarian_rdap.R`
(reference-only reconstructions — verify vs the originals). This doc compares what the
three products actually do and proposes one config structure rich enough to drive all of them
(and the upcoming NSCLC/SCLC/mCRC/heme tumors) on the shared engine.

---

## 1. The shared spine (identical across all three)

Every script is the **same pipeline**; only the per-step *rules* differ:

```
setup + helpers (001_setup / 000_helper_functions / personalSchemaFunctions)   # boilerplate, identical
  → load source tables (enhanced cohort, LOT, demographics, SES, practice, …)
  → index_lot_cohort(coh_flag)         # per-cohort index table  (overall + line cohorts)
  → demographics_variable_addn()       # age/region/race/eth/practice/SES  ← IDENTICAL crosswalks
  → minavaildate                       # earliest data-availability date across sources
  → clin_char_*_var()                  # stage / ECOG / biomarkers / labs / vitals  ← tumor-specific
  → treatment / LOT categorisation     # drug-class classifier (lotcat)  ← tumor-specific
  → outcomes                           # id3mosfu, OS, PFS/progression, follow-up
  → (OC only) proc / platinum sens.    # platinum-free interval → Sensitive/Resistant → PROC cohort
  → overall_ads_creation() per cohort  → copyToPersonalSchema (push) → union → final ADS
  → count() / freq_func() reporting    # TFL-style frequencies
```

The **demographics block is byte-for-byte the same** across EC and OC (age bands, the 4-region
state lists, race/ethnicity/practice crosswalks, SES) and matches prostate. That is the strongest
evidence the engine should own these as shared, config-tuned crosswalks (it already does).

---

## 2. Side-by-side

### 2a. Source / vendor / cohorts / index
| | **Prostate (mCRPC)** | **Endometrial (EC)** | **Ovarian (OC)** |
|---|---|---|---|
| Vendor / schema | Flatiron, single | **Flatiron EDM ∪ Dostarlimab registry** (`db="EDM"`/`"DOS"`) | Flatiron, single |
| Table prefix | `t_enh_prostate_*`, `t_*` | `t_*` (`t_enh_advendom_`) | **`t_meg_*`** (`t_meg_enh_ov_`) |
| `refresh` example | (per run) | `2026m03` | (per run) |
| Index window | study start/end | `2013-01-01 … 2026-02-26` | study start/end |
| **Index date (overall)** | `advanceddiagnosisdate = pmax(metastaticdiagnosisdate, crpcdate)` | `advanceddiagnosisdate` | `diagnosisdate` |
| **Cohorts** | overall, lot1, lot2, lot3 | overall, **lota (adjuvant)**, lot1, **lot1m**, lot2, lot3, lot4 | overall, lot1, **lot1m**, lot2, **lot2m**, lot3, lot4, lot5 + **PROC** (platinum-resistant, cohortn 9) |
| Line cohort index | line-N start (mCRPC) | line-N start; `lotNm` = maintenance; `lota` = adjuvant line start | line-N start; `lotNm` = maintenance |
| Line-setting filter | `linesetting == "mCRPC"` | `linesetting != "ADVANCED"`; adjuvant/neoadjuvant + `ismaintenancetherapy` | `ismaintenancetherapy` (False/True per cohort) |

### 2b. Clinical characteristics (the big divergence)
| Block | **Prostate** | **Endometrial** | **Ovarian** |
|---|---|---|---|
| Stage system | AJCC (I–IV) | **FIGO endometrial** (I–IV) + **TNM** (T/N/M) | **FIGO ovarian** (IA–IVB, substages IC1-3, IIIA1(i/ii)…) |
| Grade | — | **G1/G2/G3** | — |
| Histology | — | carcinosarcoma/clear-cell/endometrioid/serous/NOS | serous / epithelial-NOS / other |
| Surgery | — | **cytoreductive PCS/ICS** + modality + **residual disease** | **cytoreductive PCS/ICS** + neoadj + **residual disease + size** |
| Invasion | — | **myometrial, lymphovascular** | — |
| Radiation | — | **radiation flag/type + recurrence dates** | — |
| ECOG | baseline (window) | **6-step closest-to-index** [−30,+7] | **6-step closest-to-index** [−30,+7] |
| Vitals | BMI | BMI / BP | BMI |
| Tumor markers | Gleason, PSA (init/met), mCRPC flag | — | **CA-125** (≤35 / >35 KU/L) |
| **Biomarkers** | (Gleason/PSA) | **ER, HER2, MMR/MSI, PDL1(+%staining), PR** | **BRCA(1/2/both/VUS), HRD, GIS, FOLR1/FRα** + BRCA/HRD composite |
| **Labs** | — | — | **CA-125, platelets, neutrophils, hemoglobin, creatinine, bilirubin, AST, ALT, alk-phos, albumin, lymphocytes** |

### 2c. Treatment & outcomes
| | **Prostate** | **Endometrial** | **Ovarian** |
|---|---|---|---|
| LOT classifier | 17-way (ARSI mono/combo, docetaxel, cabazitaxel, chemo, Pluvicto, Ra-223, PARPi, pembro, sip-T, …) | chemo backbone (carbo/paclitaxel/cisplatin/gemcitabine/doxorubicin/ifosfamide/…) + IO; adjuvant/neoadjuvant | platinum / taxane / bevacizumab / PARP mono+maintenance / IO |
| Outcomes | id3mosfu, OS, **vis120 / TTD / TTNT / trtdis** (config `line_outcomes`, parity-proven) | id3mosfu, OS, **PFS/progression** (clinical/radiographic/pathologic evidence) | id3mosfu, OS, **PFS/progression** (+ scaled response), **platinum sensitivity (PFI) → PROC cohort**, `tt_first_tx_diag` |
| Death/follow-up | mortality + last-activity anchors | same pattern | same pattern |

---

## 3. Current config schema — coverage vs gaps

The current `config/data_product.yaml` + `variables/*` covers: vendor/tumor_class, run/study,
`index_dates` (single rule), `cohorts` (overall + lotN), `treatment_status`, `sources`, demographics
(`age_bands`/`regions`/`race_map`/`ethnicity_map`/`practice_map`/`ses`), `staging.groups`, baseline
ECOG, vitals BMI, the treatment codelist, and outcomes (min-follow-up, OS).

**Gaps the three scripts expose:**
1. **Multi-source union** (EC EDM ∪ Dostar) — no concept of unioning two schemas with a `db` flag.
2. **Cohort variety** — no `adjuvant`/`maintenance` cohorts, no per-cohort index/line rules.
3. **Gender** — not modelled (EC/OC need it; prostate is male-only).
4. **Clinical-characteristic blocks beyond stage/ECOG/BMI** — grade, histology, surgery (PCS/ICS +
   residual + size), invasion (myometrial/lymphovascular), radiation, tumor markers (Gleason/PSA/CA-125),
   **biomarker panels** (tumor-specific), **lab panels** (tumor-specific).
5. **ECOG closest-to-index** detail (window `[-30,+7]`, tie-breaks) — only a window is configured today.
6. **Progression / PFS** — only OS is modelled.
7. **minavaildate** — the data-availability floor isn't a configured concept.

---

## 4. Proposed complete config structure

One schema, every block **optional** (a tumor includes only what applies). The engine stays
code-locked; each block is a small reviewed config the existing compilers already know how to turn
into Spark SQL (the R↔Python parity tests prove this for the CASE-generating blocks).

```yaml
# config/data_product.yaml  (proposed superset)
data_product_id: ...,  name: ...,  version: "YYYYMM.{snapshot}"
vendor: flatiron            # flatiron | cota | …
tumor_class: solid          # solid | heme

run: { refresh, source_schema, output_schema, output_table, write_mode }
study: { index_start, index_end }

# --- NEW: source resolution can union >1 schema with a discriminator flag (EC) ---
sources:
  layout: "{schema}.{stem}_{refresh}"          # vendor default; OC overrides prefix via stem
  union:                                        # OPTIONAL (EC): union primary + registry
    discriminator: db                           # adds a 'db' column
    members:
      - { schema: clnprw_flatiron_endo_use,        flag: EDM }
      - { schema: clnprw_flatiron_dostar_endo_use, flag: DOS }
  tables:                                        # logical -> stem (vendor-resolved)
    enhanced: t_enh_advendom_      # OC: t_meg_enh_ov_ ; prostate: t_enh_prostate
    lot: t_lineoftherapy_ ; demographics: t_demographics_ ; ses: t_socdetofhealth_
    practice: ... ; diagnosis: ... ; lab: ... ; visit: ... ; telemed: ...
    drug_episode: ... ; mortality: t_enh_mortality_v2_ ; orals: ...
    baseline_ecog: ... ; ecog: ... ; vitals: ... ; biomarkers: ... ; progression: ...

# --- index source per role (overall vs line) ---
index_dates:
  overall:
    source: enhanced                            # OC: same; date column below
    date: advanceddiagnosisdate                 # OC: diagnosisdate
    of: [metastaticdiagnosisdate, crpcdate]     # prostate: pmax(...) ; else single column
    method: max
  line:    { source: lot, date: startdate }     # lotN cohorts index off line start

# --- richer cohorts: each names its index rule + line/maintenance/setting ---
cohorts:
  - { id: overall, cohortn: 1, label: "Overall <T>",   index: overall }
  - { id: lota,    cohortn: 7, label: "Adjuvant <T>",  index: line, line_setting: ADJUVANT, maintenance: false }   # EC
  - { id: lot1,    cohortn: 2, label: "L1+ <T>",       index: line, lot_number: 1, maintenance: false }
  - { id: lot1m,   cohortn: 3, label: "L1 maint <T>",  index: line, lot_number: 1, maintenance: true }            # EC/OC
  - { id: lot2,    cohortn: 4, label: "L2+ <T>",       index: line, lot_number: 2, maintenance: false }
  # … lot2m (OC), lot3, lot4, lot5 …
derived_cohorts:                                # NEW (OC): a cohort SPLIT from others by a row condition
  - { id: proc, cohortn: 9, label: "2L+ PROC: Index at First Platinum Resistance",
      from: [lot2, lot3, lot4, lot5], where: "plat_sen_v1 == 'Resistant'" }
lot:
  exclude_settings: [ADVANCED]                  # EC drops ADVANCED rows
  line_setting: mCRPC                           # prostate keeps only mCRPC; omit elsewhere
treatment_status: { treated_label, untreated_label }

# --- demographics (shared crosswalks; already supported) ---
demographics:
  gender:   { from: birthsex, map: { M: Male, F: Female }, missing: Missing }   # NEW (EC/OC)
  age_bands: [...]                              # 0-18 … >=85, fallthrough Unknown
  regions:   [...]                              # NE/MW/S/W state lists + PR + null + fallthrough
  race_map / ethnicity_map / practice_map / ses
  raceeth:  combine race+ethnicity (OC)         # NEW (OC raceeth/raceethn)

# --- clinical characteristics: every sub-block OPTIONAL ---
clinical:
  data_availability:                            # NEW: minavaildate floor
    sources: [enhanced.advanceddiagnosisdate, diagnosis, lab, med_order, visit, telemed, lot, orals]
  stage:    { source, column: groupstage, system: figo_endometrial,  groups: [...] }   # AJCC/FIGO-ec/FIGO-oc
  grade:    { column: grade, groups: [G1, G2, G3] }                       # NEW (EC)
  histology:{ column: histology, map: [...] }                            # NEW (EC/OC)
  tnm:      { t: {...}, n: {...}, m: {...} }                              # NEW (EC)
  surgery:  { type: cytoreductive, window: line, residual_disease: true, size: true }  # NEW (EC/OC)
  invasion: { myometrial: true, lymphovascular: true }                    # NEW (EC)
  radiation:{ flag: true, type: true, recurrence_dates: true }            # NEW (EC)
  ecog:     { sources: [baseline_ecog, ecog], window_days: [-30, 7], tie: [earliest_date, max_value],
              value_codes: {0:1,1:2,2:3,3:4,4:5}, unknown: 7, missing: 99 }
  tumor_markers:                                                         # NEW
    gleason: { column: gleasonscore }            # prostate
    psa:     { columns: [psainitialdiagnosis, psametdiagnosis] }
    ca125:   { from_lab: "CANCER AG 125", bands: [ {<=: 35, label: Normalized}, {>: 35, label: Elevated} ] }  # OC
  biomarkers:                                                            # NEW: tumor-specific panel
    panel: [ER, HER2, MMR/MSI, PDL1, PR]         # OC: [BRCA, HRD, GIS, FOLR1/FRALPHA]
    window_days: [null, 14]                       # <= index + 14
    status_map: { Positive: 1, Negative: 2, ...: 3 }
    composites: [ { name: brcahrd, from: [brca, hrd], rules: [...] } ]    # OC BRCA/HRD composite
  labs:                                                                  # NEW: tumor-specific (OC)
    window: closest_to_index
    panel: [CA-125, PLATELETS, NEUTROPHILS, HEMOGLOBIN, CREATININE, BILIRUBIN, AST, ALT,
            "ALKALINE PHOSPHATASE", ALBUMIN, LYMPHOCYTES]
  vitals:   { bmi: true, bp: true }              # BMI all; BP for EC

# --- treatment classifier (existing codelist DSL) + adjuvant/neoadjuvant flags ---
codelists: { treatment_categories: codelists/treatment_categories.yaml }
treatment:
  chemo_backbone: [carboplatin, paclitaxel, docetaxel, cisplatin, gemcitabine, doxorubicin,
                   ifosfamide, capecitabine, topotecan, mitomycin]       # EC adjt_chm flag
  maintenance_flags: [adjmever, neoadjtever]      # EC adjuvant/neoadjuvant maintenance ever

# --- outcomes: OS today; ADD progression/PFS ---
outcomes:
  min_followup_days: 90,  days_per_month: 30.4375
  overall_survival: { event_flag: dthfl, death_anchor: dthdt, censor_anchor: fued }
  progression:                                   # NEW (EC/OC)
    evidence: [IsClinicalAssessmentOnly, IsRadiographicEvidence, IsPathologicEvidence,
               IsPhysicalExamEvidence, IsTumorMarkerEvidence, IsMixedResponse]
    pfs: { event: progression_or_death }
  platinum_sensitivity:                          # NEW (OC): PFI carried forward line-to-line
    pfi_window_days: 14
    status: [Sensitive, Resistant]               # plat_sen_v1 (current) / plat_sen_v2 (previous line)
    time_to_first_tx: tt_first_tx_diag           # diagnosis -> first treatment (min surgery / lot1 start)
```

---

## 5. Engine implications (what the shared engine must grow)

In priority order — each is an additive, config-driven block the locked engine compiles:

1. **`sources.union`** — a vendor/source adapter that unions N schemas with a `db` discriminator
   (EC). Small change to `engine/vendors.py` + `stages/sources.py`.
2. **Cohort model** — `cohorts[].index` (overall|line), `lot_number`, `maintenance`, `line_setting`
   per cohort; `lot.exclude_settings`. Generalises `stages/index.py` + `stages/lot.py`.
3. **Clinical sub-block compilers** — grade / histology / TNM / surgery(PCS-ICS+residual) /
   invasion / radiation / tumor_markers / biomarker-panel / lab-panel. Each is a CASE/closest-to-index
   compiler in the same family as today's `stage_case`/`_bands_case` — so each is **R↔Python
   parity-testable** the moment it lands.
4. **ECOG closest-to-index** (window + tie-break) — upgrade `stages/clinical.py` ECOG from
   window-only to the 6-step nearest-record logic the scripts use.
5. **Progression / PFS** in `outcomes` (evidence-type flags → PFS event).
6. **`minavaildate`** data-availability floor as a configured derived date.
7. **Derived cohorts** (`derived_cohorts`) — cohorts split from existing ones by a row condition
   (OC's PROC = 2L+ platinum-Resistant, `cohortn=9`), plus the **platinum-sensitivity** (PFI carried
   forward per line) that condition depends on. OC-specific but generalises (e.g. heme transformation
   cohorts). The OC `002_Function_Calls.R` driver (the function-call companion) is the orchestration reference for this.

Because each new block is a reviewed YAML + a pure compiler, the two-engine parity guarantee
(`tests/test_r_parity.py`) extends to cover them — keeping the R and PySpark builds in lock-step as
the schema grows to all tumors.

> **Status:** the reconstructions are reference-only (verify vs the originals). Treatment/outcomes/assembly
> stand-in for EC (`the original EC script`) and OC (`the original OC script` + `the function-call companion`) continues; the
> structure above is already complete enough to design against.
