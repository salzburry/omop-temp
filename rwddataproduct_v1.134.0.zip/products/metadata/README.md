# Master variable spec (`metadata/`)

The cross-tumor variable governance source.

- The cross-tumor MASTER VARIABLE CATALOG (Category · Variable · Label · naming · per-tumor
  applicability sheets: NSCLC/OC/EC/mCRC/SCLC/DLBCL/mCRPC), held by the sponsor outside this repo.
- The PER-TUMOR VARIABLE DEFINITIONS (Category · Variable · Label · Cohort · Definition · Notes),
  likewise held by the sponsor.
- `catalog.yaml` — **machine-readable** form the tumor packs validate against. **Status: seed** —
  populated with the variables the prostate pack already emits (correct, working). Full population
  (every row + all tumor applicability) still needs encoding from the two documents above.

`catalog.yaml` is cross-checked by `platform/tests/test_catalog.py`: it is well-formed, its tumor
codes match `../registry.yaml`, and — already enforced in CI, not deferred — **every variable a tumor
pack emits must resolve to a catalog entry** (`test_catalog_documents_every_emitted_variable`, all four
tumors). So naming/completeness governance is live today. What Phase 4 still owes is **reconciliation**:
fold `variable-specs/` and `oncology/packs/` into this one catalog (not three), and finish encoding
every row + all tumor-applicability from the two PDFs above (the catalog is still a seed).
