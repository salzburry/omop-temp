# mCRC RWDP — config pack  *(scaffold, unverified)*

Runs on the shared engine (`../../../platform/`). Registered in `products/registry.yaml` as
`mcrc` on vendor `flatiron`, tumour class `solid`.

**Status: scaffold. It lints clean and can be pointed at a delivery — and nothing in it is
approved.** Every clinical value was INFERRED from published RWD practice for this tumour, not read
from an approved workbook: no workbook is registered for this pack. Values marked
`verify-vs-source` are best readings and must be confirmed before use. The approved RWB workbook is
the specification; this pack is the starting configuration to check against it.

```bash
python3 platform/engine/validate.py products/oncology/mcrc/202606/config/data_product.yaml
python3 platform/tools/product_gates.py --report
```

Both are run FROM THE REPOSITORY ROOT. The first line used to read `python3 -m engine.validate
../../../platform ...`, which fails with `ModuleNotFoundError: No module named 'engine'` from any
directory — `engine` is only importable with `platform/` on the path, and the validator takes one
argument, not two. A first command that does not run is the worst line in a README: it is the one a
newcomer types before they have any way to tell a broken instruction from a broken pack.

## What was inferred, and what to check first

- **Index** is the metastatic-diagnosis date. Whether de novo (synchronous) and recurrent (metachronous) presentations share one column is the first thing to check against the delivery.
- **Line categories** split the backbone from the biologic (anti-VEGF vs anti-EGFR), because that is the split mCRC RWD reports. Maintenance de-escalation is the largest line-attribution question in this tumour and is NOT modelled here — no `maintenance_column` is declared until the workbook states the rule.
- **Sidedness, RAS/BRAF/MSI/HER2** are the defining covariates (see the overlay) and need a confirmed biomarker table stem before they can be configured.

## The reference shelf behind these choices

`governance/reference/variable_inventory/INVENTORY.yaml` -> `tumours.mcrc` carries the
literature-cited definitions the values above were drawn from, each with its engine coverage class.
It is `status: reference_only` — **a drafting AID, never a specification.** A variable enters THIS
product only when the approved workbook states it.

```bash
python3 platform/tools/inventory_coverage.py                       # engine coverage + the gap list
python3 platform/tools/variables_scaffold.py products/oncology/mcrc/202606   # parameter skeletons
```

## Before this pack is anything more than a scaffold

1. ~~**Name the spec version.**~~ Done — this pack is `202606/`, and `products/registry.yaml`
   carries `current_spec_version: "202606"` to match. Nothing could be registered before it:
   `source_refs.schema.json` pins `spec_version` to `^[0-9]{6}$`, because a registration records
   WHICH cut it governs.
2. **Register the source** — the next step, and it needs three things only a person can supply:

   ```bash
   python3 platform/tools/source_refs_init.py products/oncology/mcrc/202606 \
       --path-or-link products/oncology/mcrc/202606/prog_spec/<the-workbook>.xlsx \
       --ai-classification <sponsor_ai_eligible|vendor_restricted|restricted_derived> \
       --classified-by "<your name>" --classified-date <YYYY-MM-DD>
   ```

   The tool composes everything else and validates against the schema before writing, but it has
   no default for those three and refuses a team name, an acronym or a placeholder. That is
   deliberate: `ai_classification` decides what AI may read at all, and a generated one would read
   exactly like a considered call while nobody had made one.

   `--path-or-link` defaults to `TBD`, which is correct only while the workbook is NOT in hand.
   Registering the pack ON the day the workbook arrives — the one day this command matters — and
   leaving the path at `TBD` records a registration of nothing, so it is written out here rather
   than left to be discovered. Follow it with the digest, which is what binds the registration to
   the bytes:

   ```bash
   python3 platform/tools/source_manifest.py products/oncology/mcrc/202606 \
       --record-digest program_spec
   python3 platform/tools/source_manifest.py products/oncology/mcrc/202606 --check
   ```
3. **Run the spec pipeline** to produce `spec_pipeline/out/extracted.json` — the sanitized
   extraction, and the only artifact of this pack AI may read.
4. **Reconcile every `verify-vs-source` value** against the workbook, and drop `version: 0.1` to a
   real version once each is confirmed.
5. **Draft the contract** (`.claude/skills/draft-contract-record`) and register the decisions.
