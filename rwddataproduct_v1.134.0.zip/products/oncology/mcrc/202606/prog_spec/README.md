# Where the approved workbook lands

This directory is the pack's `prog_spec/` — the home for the RWB program specification once it is
supplied. It is EMPTY on purpose, and that emptiness is a true statement: no workbook has been
approved for mCRC, so `../source_refs.yaml` does not exist either and Gate 1 reports this pack as
unregistered.

## Before any of it: prove the pipeline is healthy

Run the extraction against a pack that ALREADY WORKS, first, before the new workbook is touched:

```bash
python3 platform/tools/run_spec_pipeline.py products/oncology/prostate/202606 --check
```

It must print `OK — all 7 generated artifacts are current`, and it takes under a minute. That is a
CONTROL, and it costs almost nothing to have: after it passes, any failure on the new workbook is
the workbook or its registration, and cannot be a broken extractor, a missing dependency or a bad
checkout. Without it, the first failure of the day is ambiguous in exactly the way that burns an
afternoon — and the pressure to "just get past it" is highest at precisely that moment.

It reads a committed pack and regenerates into a temp directory, so it writes nothing here.

## The order, and why it is that order

1. **Register the material first.** `source_refs.yaml` records WHAT was approved; the spec pipeline
   then extracts the material named by `SPEC_SOURCE_ID` in `../spec_pipeline/pipeline.conf`. Doing it
   the other way round — extracting a file and registering it afterwards — makes "what was approved"
   and "what was read" two facts that nothing reconciles.

   Put the workbook in this directory first (or, when it may not enter the repository, register a
   stand-in whose `derived_from` names the authoritative document), then name it in the SAME
   command that registers it:

   ```bash
   python3 platform/tools/source_refs_init.py products/oncology/mcrc/202606 \
       --path-or-link products/oncology/mcrc/202606/prog_spec/<the-workbook>.xlsx \
       --ai-classification <sponsor_ai_eligible|vendor_restricted|restricted_derived> \
       --classified-by "<your name>" --classified-date <YYYY-MM-DD>
   ```

   The three classification flags have no defaults and no tool may supply them: `ai_classification`
   decides what AI may read at all, and a generated one would read exactly like a considered call
   while nobody had made one.

   `--path-or-link` DOES have a default, `TBD`, and it is correct only while the workbook is not in
   hand. On the day the workbook arrives — the day this command is actually run — accepting that
   default registers a pointer to nothing, so it is spelled out above rather than left to be found.

2. **Bind the registration to the bytes.**

   ```bash
   python3 platform/tools/source_manifest.py products/oncology/mcrc/202606 \
       --record-digest program_spec
   python3 platform/tools/source_manifest.py products/oncology/mcrc/202606 --check
   ```

   Without the digest the registration names a file; with it, the registration names a file's
   CONTENT. Only the second survives somebody replacing the workbook in place.

3. **Extract.**

   ```bash
   python3 platform/tools/run_spec_pipeline.py products/oncology/mcrc/202606
   ```

   The `.py`, not the `.sh` this file used to name. The shell script is a two-line wrapper around
   exactly this, and naming it here made Gate 2 unreachable on a Windows checkout — which is why CI
   runs the `.py` on both platforms.

   This produces `../spec_pipeline/out/extracted.json` — the sanitized extraction, and the only
   artifact of this pack AI is permitted to read — plus the defect scan, the coverage report, the
   scaffolded records and the enumeration candidates.

4. **Register the extraction for AI use.** Nothing may read `extracted.json` until a person has
   classified and approved it — `spec_slice` refuses, and Gate 1 refuses an unstated classification
   at every status.

   ```bash
   python3 platform/tools/source_manifest.py --register-ai-extraction products/oncology/mcrc/202606
   ```

   This PRINTS a block; it writes nothing. Paste it as a new list item inside `source_materials:`,
   matching that list's indentation — text appended after the last top-level key attaches to the
   wrong key, and every check stays green because to them the material simply does not exist.
   Confirm with `source_manifest.py products/oncology/mcrc/202606 --check`: the pack must go **RED**
   on an unstated classification. An OK immediately after pasting means the paste did not land.

   The derivation fields — path, sha256, fingerprint, redaction policy and counts — are computed for
   you. `ai_classification`, `classified_by` and `classified_date` are left `TODO`, and the two
   approval fields stay commented out until review. Those are the human acts: a helper that filled
   in the classification would be answering the one question it exists to pose.

   Re-running the pipeline after this point changes the artifact's bytes, so the registration must
   be redone by a person — `--record-digest` deliberately REFUSES to re-point a recorded digest at
   bytes nobody has looked at.

5. **Draft the contract** from the extraction, then
   `python3 platform/tools/contract_binding.py products/oncology/mcrc/202606 --promote` prints the
   candidate VALUES the spec states, each carrying the spec row it came from, so nobody retypes
   fifty-two state codes. It is **not** paste-and-run YAML: the key names are neutral, and the
   codes, fallthrough and missing-value handling the spec does not state come out as named gaps
   rather than guesses. It never writes into `variables/`: an existing block holds decisions a
   person made.

6. **Check what you wrote against what the records say.**

   ```bash
   python3 platform/tools/contract_binding.py products/oncology/mcrc/202606 \
       --enumerations --parameters --check
   ```

   `--enumerations` compares the spec's value lists against the YAML; `--parameters` compares each
   record's window, record-selection direction and `physical_stem` against the config it binds to
   and against this pack's `sources:` map. Both report and neither edits — and both report what
   they could NOT read, which for this tumour is where the maintenance rule and the index anchor
   will sit.

## The golden matrix, waiting for its answers

`platform/tests/fixtures/mcrc_goldens.yaml` holds ten hand-shaped patients, one per way an mCRC
build comes out internally consistent and clinically wrong: the window boundary read exclusively,
synchronous versus recurrent presentation, an uninterpretable sidedness, an indeterminate
biomarker, a death with no date, two results colliding on one day, and maintenance de-escalation.

The SHAPES are written. Every `expect:` is `REPLACE_ME`, and must stay that way until a person
reads the workbook and computes the answer BY HAND — writing the arithmetic in `working:` and the
row in `spec_ref:`. Filling one in from `config/data_product.yaml` would test the engine against
this pack's own inferred guesses and report the result as a clinical golden, which is the failure
goldens exist to catch. `platform/tests/test_mcrc_goldens.py` enforces the matrix's shape now and
refuses a `spec_ref` pointing into an extraction that does not exist.

```bash
python3 platform/tests/test_mcrc_goldens.py
python3 platform/tools/config_propose.py products/oncology/mcrc/202606   # what backs each block
python3 platform/tools/pilot_readiness.py products/oncology/mcrc/202606  # can this run today
```

## What is already here, and what it is worth

`config/`, `variables/` and `codelists/` are populated — but from PUBLISHED PRACTICE for this
tumour, not from your workbook. Every value marked `verify-vs-source` is a place someone inferred
rather than read. Reconciling those against the approved specification is the work step 4 begins,
and it is genuine work: the index anchor, the cohort set, the source stems and the maintenance rule
(deliberately not modelled) are all open until the workbook says otherwise.
