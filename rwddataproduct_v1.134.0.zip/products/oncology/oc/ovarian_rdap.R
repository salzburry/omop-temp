# =============================================================================
# Ovarian (OC) RWDP — original R / dbplyr build script (RECONSTRUCTION)
# =============================================================================
# SOURCE: the original OC build script and its function-call companion, held outside this
# repository. This file is a RECONSTRUCTION of them,
# so TREAT IT AS REFERENCE ONLY and VERIFY against the originals.
#
# SCOPE (per request): the OC-SPECIFIC BUILD LOGIC only. The generic boilerplate
# (DB libs, 001_setup.R, 002_helper_functions.R, personalSchemaFunctions.R,
# count/freq helpers) is REFERENCED BY FILENAME, not reproduced — it is the
# same set of utilities as the EC/prostate scripts.
#
# OC source-table prefix (confirmed against the original script): t_meg_*
#   t_meg_enh_ov_, t_meg_lineoftherapy_, t_meg_demographics_, t_meg_socdetofhealth_,
#   t_meg_practice_, t_meg_diagnosis_, t_meg_lab_, t_meg_medicationorder_,
#   t_meg_telemedicine_, t_meg_visit_, t_meg_drugepisode_, t_meg_enh_mortality_v2_,
#   t_meg_enh_ov_orals_, t_meg_enh_ov_edmincl_, t_meg_baseline_ecog_, t_meg_ecog_,
#   t_meg_vitals_, t_meg_enh_ovbiomarkers_, t_meg_enh_ov_progression_,
#   t_meg_enh_ov_resp_scaled_
# Setup vars (dbname / refresh / index_start / index_end / personal_schema) come
# from 001_setup.R (boilerplate, not reproduced).
#
# COVERAGE: reconstruction IN PROGRESS (part 1). Reconstructed so far:
#   the original script's opening section — libraries/sources, the t_meg_* table map, the
#   column-lowercasing loop, index_lot_cohort() (cohort/index definition incl.
#   the maintenance cohorts), the cohort build+push loop, and the start of the
#   demographics derivation. Remaining sections under "TODO(reconstruct)" below.
# =============================================================================

# ---------------------------------------------------------------------------
# Load libraries (boilerplate, == EC/prostate).
library(odbc)       # database connections using ODBC
library(DBI)        # standard database interface
library(dbplyr)     # dplyr over database tables
library(dplyr); library(tidyr); library(purrr); library(lubridate); library(stringr)
library(sparklyr)   # Spark
library(gsklog)     # logging
con <- connect()    # database connection

# Support files + helper functions (boilerplate, referenced by filename):
source('/mnt/code/R/01_project_necessities/001_setup.R')                       # setup vars
source('/mnt/code/R/01_project_necessities/002_helper_functions.R')            # count/freq/etc.
source('/mnt/code/R/helperScripts/databases/copyToPersonalSchema.R')           # personal-schema push

# ===========================================================================
# Source tables (OC uses the t_meg_* datamart prefix).
# ===========================================================================
enh_ov             <- tbl(con, in_schema(dbname, paste0("t_meg_enh_ov_",            refresh)))  # enhanced ovarian cohort
enh_ov_lot         <- tbl(con, in_schema(dbname, paste0("t_meg_lineoftherapy_",     refresh)))  # line of therapy
enh_ov_dem         <- tbl(con, in_schema(dbname, paste0("t_meg_demographics_",      refresh)))  # demographics
enh_ov_ses         <- tbl(con, in_schema(dbname, paste0("t_meg_socdetofhealth_",    refresh)))  # SES
enh_ov_practice    <- tbl(con, in_schema(dbname, paste0("t_meg_practice_",          refresh)))  # practice
enh_ov_diag        <- tbl(con, in_schema(dbname, paste0("t_meg_diagnosis_",         refresh)))  # diagnosis
enh_ov_lab         <- tbl(con, in_schema(dbname, paste0("t_meg_lab_",               refresh)))  # lab
enh_ov_med_order   <- tbl(con, in_schema(dbname, paste0("t_meg_medicationorder_",   refresh)))  # medication order
enh_ov_telemed     <- tbl(con, in_schema(dbname, paste0("t_meg_telemedicine_",      refresh)))  # telemedicine
enh_ov_visit       <- tbl(con, in_schema(dbname, paste0("t_meg_visit_",             refresh)))  # visit
enh_ov_drugepisode <- tbl(con, in_schema(dbname, paste0("t_meg_drugepisode_",       refresh)))  # drug episode
enh_ov_mortality   <- tbl(con, in_schema(dbname, paste0("t_meg_enh_mortality_v2_",  refresh)))  # mortality
enh_ov_orals       <- tbl(con, in_schema(dbname, paste0("t_meg_enh_ov_orals_",      refresh)))  # ovarian orals
enh_ov_edm_incl    <- tbl(con, in_schema(dbname, paste0("t_meg_enh_ov_edmincl_",    refresh)))  # EDM inclusion
enh_ov_bl_ecog     <- tbl(con, in_schema(dbname, paste0("t_meg_baseline_ecog_",     refresh))) %>%
                        select(patientid, ECOGdate, ECOGvalue)                                   # baseline ECOG
enh_ov_ecog        <- tbl(con, in_schema(dbname, paste0("t_meg_ecog_",              refresh))) %>%
                        select(PatientID, ECOGDate, ECOGValue)                                   # ECOG
enh_ov_vitals      <- tbl(con, in_schema(dbname, paste0("t_meg_vitals_",            refresh)))  # vitals
enh_ov_biomarkers  <- tbl(con, in_schema(dbname, paste0("t_meg_enh_ovbiomarkers_",  refresh)))  # biomarkers
enh_ov_prog        <- tbl(con, in_schema(dbname, paste0("t_meg_enh_ov_progression_", refresh))) # progression
enh_ov_resp        <- tbl(con, in_schema(dbname, paste0("t_meg_enh_ov_resp_scaled_", refresh))) # scaled response

# --- Rename columns to lowercase for readability (every enh_ov* lazy table) ---
object_names <- ls()
enh_ov_pointers <- object_names[sapply(object_names, function(x) startsWith(x, "enh_ov"))]
for (pointer_name in enh_ov_pointers) {
  lazy_table <- get(pointer_name)                 # dereference the pointer to the lazy table
  if (inherits(lazy_table, "tbl_lazy")) {
    lazy_table <- lazy_table %>% rename_with(tolower)   # lowercase via dplyr
    assign(pointer_name, lazy_table)              # save the updated lazy table back
  } else {
    warning(paste("object", pointer_name, "is not a tbl_lazy; skipping."))
  }
}
print(paste("Updated column names for:", enh_ov_pointers))

# ===========================================================================
# Index-cohort definition.
#   overall : index_date = diagnosisdate, within [index_start, index_end]
#   lotN    : index_date = line-N start date (linenumber == N, NOT maintenance)
#   lotNm   : the maintenance variant (ismaintenancetherapy == "True")
# ===========================================================================
index_lot_cohort <- function(coh_flag) {
  if (coh_flag == "overall") {
    ov_index <- enh_ov %>%
      filter(diagnosisdate >= index_start & diagnosisdate <= index_end) %>%   # diagnosisdate in window
      select(patientid, diagnosisdate)
    final_ov_index <- ov_index %>%
      mutate(index_date = as.Date(diagnosisdate)) %>%                          # index_date = diagnosisdate
      select(patientid, index_date, diagnosisdate)
    return(final_ov_index)

  } else if (nchar(coh_flag) == 4) {                                           # lot1 / lot2 / lot3
    ov_index <- enh_ov %>%
      filter(diagnosisdate >= index_start & diagnosisdate <= index_end) %>%
      select(patientid, diagnosisdate)
    lot_number <- as.numeric(gsub("[^0-9.]", "", coh_flag))                    # LOT number from the flag
    lot_index <- enh_ov_lot %>%
      filter((startdate >= index_start & startdate <= index_end) &            # startdate in window
             linenumber == lot_number &                                       # the requested line
             ismaintenancetherapy == "False") %>%                             # non-maintenance
      select(patientid, linenumber, linename, startdate, enddate, ismaintenancetherapy)
    final_lot_index <- lot_index %>%
      inner_join(ov_index, by = c("patientid" = "patientid")) %>%             # join LOT to enhanced cohort
      mutate(index_date = as.Date(startdate)) %>%                             # index_date = line start
      select(patientid, index_date, diagnosisdate, linenumber, linename, startdate, enddate, ismaintenancetherapy)
    return(final_lot_index)

  } else if (nchar(coh_flag) == 5) {                                           # lot1m / lot2m (maintenance)
    ov_index <- enh_ov %>%
      filter(diagnosisdate >= index_start & diagnosisdate <= index_end) %>%
      select(patientid, diagnosisdate)
    lot_number <- as.numeric(gsub("[^0-9.]", "", coh_flag))
    lot_index <- enh_ov_lot %>%
      filter((startdate >= index_start & startdate <= index_end) &
             linenumber == lot_number &
             ismaintenancetherapy == "True") %>%                              # maintenance
      select(patientid, linenumber, linename, startdate, enddate, ismaintenancetherapy)
    final_lot_index <- lot_index %>%
      inner_join(ov_index, by = c("patientid" = "patientid")) %>%
      mutate(index_date = as.Date(startdate)) %>%
      select(patientid, index_date, diagnosisdate, linenumber, linename, startdate, enddate, ismaintenancetherapy)
    return(final_lot_index)
  }
}

# Cohort list: overall + first three lines + the L1/L2 maintenance variants.
coh_list <- c("overall", "lot1", "lot1m", "lot2", "lot2m", "lot3")

# Build each cohort's index table and push it to Databricks (personal schema).
for (coh_flag in coh_list) {
  var_name <- paste0("enh_ov_", coh_flag, "_index_tbl")    # create table name
  df <- index_lot_cohort(coh_flag)                         # run the index function
  assign(var_name, df)                                     # assign dynamically
  # pushing index table to databricks
  df <- get(var_name) %>% collect()
  copyToPersonalSchema(con, df, var_name, replace = TRUE)  # push to databricks
  rm(df, var_name)
}
# pull each pushed table back as a lazy pointer
for (coh_flag in coh_list) {
  var_name <- paste0("enh_ov_", coh_flag, "_index_tbl")
  df <- tbl(con, in_schema(personal_schema, var_name))     # pull back from Databricks
  assign(var_name, df)
  rm(df)
}

# ===========================================================================
# Demographics.
# ===========================================================================
# Aggregate practicetype at the patient level.
enh_ov_practice_agg <- enh_ov_practice %>%
  distinct(patientid, practicetype) %>%
  group_by(patientid) %>%
  summarize(practicetype_agg =
              sql("STRING_AGG(practicetype, '/') WITHIN GROUP (ORDER BY practicetype)"))

# Function to add demographics-related variables to a cohort index table.
# OC demographics derivation — IDENTICAL structure to EC (only `gender` differs: OC is
# female-only). age/agegr/region/race/eth/practice/SES use the same bands/crosswalks.
demographics_variable_addn <- function(input_ds) {
  df_dem_interim <- input_ds %>%
    left_join(enh_ov_dem,          by = c("patientid" = "patientid")) %>%   # demographics
    left_join(enh_ov_practice_agg, by = c("patientid" = "patientid")) %>%   # aggregated practice
    left_join(enh_ov_ses,          by = c("patientid" = "patientid")) %>%   # SES
    mutate(
      gender  = case_when(birthsex == "F" ~ "Female", is.na(birthsex) ~ "Missing", TRUE ~ "Missing"),
      gendern = case_when(birthsex == "F" ~ 1, is.na(birthsex) ~ 3, TRUE ~ 3),
      year_index = year(index_date),
      age = year_index - as.numeric(birthyear),
      agegrl = case_when(age >= 0  & age <= 18 ~ "0-18",  age >= 19 & age <= 34 ~ "19-34",
                         age >= 35 & age <= 49 ~ "35-49", age >= 50 & age <= 64 ~ "50-64",
                         age >= 65 & age <= 74 ~ "65-74", age >= 75 & age <= 84 ~ "75-84",
                         age >= 85 ~ ">=85", TRUE ~ "Unknown"),
      agegrln = case_when(age >= 0  & age <= 18 ~ 1, age >= 19 & age <= 34 ~ 2, age >= 35 & age <= 49 ~ 3,
                          age >= 50 & age <= 64 ~ 4, age >= 65 & age <= 74 ~ 5, age >= 75 & age <= 84 ~ 6,
                          age >= 85 ~ 7, TRUE ~ 8),
      region1 = case_when(
        state %in% c('ME','VT','NH','MA','RI','CT','NY','PA','NJ') ~ "Northeast",
        state %in% c('ND','SD','NE','KS','MN','IA','MO','WI','IL','MI','IN','OH') ~ "Midwest",
        state %in% c('TX','OK','AR','LA','KY','TN','MS','AL','MD','DE','DC','VA','WV','NC','SC','GA','FL') ~ "South",
        state %in% c('CA','WA','OR','NV','AZ','UT','NM','CO','ID','MT','WY','HI','AK') ~ "West",
        state == 'PR' ~ "Other region", is.na(state) ~ "Missing", TRUE ~ "Unknown"),
      regionln = case_when(
        state %in% c('ME','VT','NH','MA','RI','CT','NY','PA','NJ') ~ 1,
        state %in% c('ND','SD','NE','KS','MN','IA','MO','WI','IL','MI','IN','OH') ~ 2,
        state %in% c('TX','OK','AR','LA','KY','TN','MS','AL','MD','DE','DC','VA','WV','NC','SC','GA','FL') ~ 3,
        state %in% c('CA','WA','OR','NV','AZ','UT','NM','CO','ID','MT','WY','HI','AK') ~ 4,
        state == 'PR' ~ 5, is.na(state) ~ 6, TRUE ~ 7),
      race = case_when(race == "Asian" ~ "Asian", race == "Black or African American" ~ "Black or African American",
                       race == "White" ~ "White", race == "Hispanic or Latino" ~ "Other Race",
                       race == "Other Race" ~ "Other Race", is.na(race) ~ "Unknown/Missing", TRUE ~ "Unknown/Missing"),
      racen = case_when(race == "Asian" ~ 1, race == "Black or African American" ~ 2, race == "White" ~ 3,
                        race == "Hispanic or Latino" ~ 4, race == "Other Race" ~ 4, is.na(race) ~ 5, TRUE ~ 5),
      # race+ethnicity combined (raceeth/raceethn): Hispanic-or-Latino ethnicity overrides race
      raceeth = case_when(race == "Hispanic or Latino" | ethnicity == "Hispanic or Latino" ~ "Hispanic or Latino",
                          ethnicity == "Not Hispanic or Latino" ~ "Not Hispanic or Latino",
                          is.na(ethnicity) ~ "Unknown/Missing", TRUE ~ "Unknown/Missing"),
      raceethn = case_when(race == "Hispanic or Latino" | ethnicity == "Hispanic or Latino" ~ 1,
                           ethnicity == "Not Hispanic or Latino" ~ 2, is.na(ethnicity) ~ 3, TRUE ~ 4),
      practic = case_when(practicetype_agg == "ACADEMIC" ~ "Academic only", practicetype_agg == "COMMUNITY" ~ "Community only",
                          practicetype_agg == "ACADEMIC,COMMUNITY" ~ "Both academic and community", TRUE ~ "Missing"),
      practicn = case_when(practicetype_agg == "ACADEMIC" ~ 1, practicetype_agg == "COMMUNITY" ~ 2,
                           practicetype_agg == "ACADEMIC,COMMUNITY" ~ 3, TRUE ~ 99),
      ses = case_when(is.na(sesindex2015_2019) ~ "Missing", TRUE ~ sesindex2015_2019)
    ) %>%
    select(patientid, index_date, diagnosisdate, birthyear, birthsex, age, agegrl, agegrln,
           gender, gendern, state, region1, regionln, race, racen, raceeth, raceethn,
           practic, practicn, ses)
  return(df_dem_interim)
}

# ===========================================================================
# Clinical characteristics from the enhanced table.
# clin_char_enh_ov_var(): histology, FIGO OVARIAN stage, surgery (primary/interval
# cytoreductive), neo-adjuvant, residual disease + size.
# ===========================================================================
clin_char_enh_ov_var <- function(input_ds) {
  input_ds %>%
    left_join(enh_ov, by = "patientid") %>%
    left_join(enh_ov_lot %>% filter(linenumber == 1 & ismaintenancetherapy == "False"),
              by = "patientid") %>%
    mutate(
      init = diagnosisdate, inityr = year(diagnosisdate),
      histo = case_when(histology == "Serous" ~ "Serous",
                        histology == "Unknown/not documented" ~ "Unknown or missing",
                        TRUE ~ "Epithelial NOS and Other"),
      histon = case_when(histology == "Serous" ~ 1, histology == "Unknown/not documented" ~ 3, TRUE ~ 2),
      stage = case_when(                                  # FIGO ovarian stage grouping
        groupstage %in% c('I','IA','IB','IC','IC1','IC2','IC3') ~ "I",
        groupstage %in% c('II','IIA','IIB','IIC') ~ "II",
        groupstage %in% c('III','IIIA1(i)','IIIA1(ii)','IIIA2','IIIB','IIIC') ~ "III",
        groupstage %in% c('IV','IVA','IVB') ~ "IV",
        groupstage == "Unknown/not documented" ~ "Unknown/not documented", TRUE ~ "CHECK"),
      stagen = case_when(
        groupstage %in% c('I','IA','IB','IC','IC1','IC2','IC3') ~ 1,
        groupstage %in% c('II','IIA','IIB','IIC') ~ 2,
        groupstage %in% c('III','IIIA1(i)','IIIA1(ii)','IIIA2','IIIB','IIIC') ~ 3,
        groupstage %in% c('IV','IVA','IVB') ~ 4, TRUE ~ 5),
      issurg = case_when(issurgery == "Yes" ~ "Yes", issurgery == "No" ~ "No Surgery",
                         issurgery != "Yes" & is.na(surgerydate) ~ "Unknown", TRUE ~ "Missing"),
      surg = case_when(
        (issurgery == "Yes" & is.na(surgerydate)) | (surgerydate < linestartdate) ~ "Primary cytoreductive surgery (PCS)",
        (surgerydate >= linestartdate & surgerydate <= lineenddate) | (surgerydate > lineenddate) ~ "Interval cytoreductive surgery (ICS)",
        TRUE ~ "No Surgery"),
      neoadj = case_when(surgerydate >= linestartdate & surgerydate <= lineenddate ~ "Yes", TRUE ~ "No"),
      rdc = case_when(residualdiseasestatus == "Residual disease" ~ "Visible residual disease",
                      residualdiseasestatus == "No residual disease" ~ "No visible residual disease",
                      is.na(residualdiseasestatus) ~ "Missing", TRUE ~ "Missing"),
      sizeofresidualdisease = sizeofresidualdisease
    ) %>%
    select(patientid, index_date, histology, groupstage, residualdiseasestatus, sizeofresidualdisease,
           init, inityr, histo, histon, stage, stagen, issurg = issurgery, surg, surgn = stagen,
           neoadj, rdc)
}

# --- Baseline ECOG: closest to index in window [-30, +7] days (SAME 6-step as EC). ---
clin_char_ecog_var <- function(input_ds) {
  bl_ecog_pull <- union_all(input_ds %>% inner_join(enh_ov_bl_ecog, by = "patientid"),
                            input_ds %>% inner_join(enh_ov_ecog,    by = "patientid")) %>%
    filter(ecogdate >= dbplyr::sql("DATE_SUB(index_date, 30)") &
           ecogdate <= dbplyr::sql("DATE_ADD(index_date, 7)"))
  gap_calc <- bl_ecog_pull %>% mutate(gap = abs(datediff(ecogdate, index_date)))
  min_gap  <- gap_calc %>% group_by(patientid, index_date) %>% summarise(min_gap = min(gap, na.rm = TRUE), .groups = "drop")
  bl_max_ecogdt <- gap_calc %>% inner_join(min_gap, by = c("patientid", "index_date")) %>%
    filter(gap == min_gap) %>% group_by(patientid, index_date) %>%
    summarise(ecogdate = min(ecogdate, na.rm = TRUE), .groups = "drop")        # ties -> earliest date
  bl_ecog_value <- bl_max_ecogdt %>% group_by(patientid, index_date, ecogdate) %>%
    summarise(ecogvalue = max(ecogvalue, na.rm = TRUE), .groups = "drop")      # ties -> max value
  input_ds %>% left_join(bl_ecog_value, by = c("patientid", "index_date")) %>%
    mutate(ecog  = case_when(ecogvalue == '0' ~ "0", ecogvalue == '1' ~ "1", ecogvalue == '2' ~ "2",
                             ecogvalue == '3' ~ "3", ecogvalue == '4' ~ "4",
                             is.na(ecogvalue) ~ "Missing", TRUE ~ "Unknown"),
           ecogn = case_when(ecog == '0' ~ 1, ecog == '1' ~ 2, ecog == '2' ~ 3, ecog == '3' ~ 4,
                             ecog == '4' ~ 5, ecog == "Unknown" ~ 7, is.na(ecog) ~ 99, TRUE ~ 98)) %>%
    select(patientid, index_date, ecogdate, ecog, ecogn)
}

# --- Biomarkers: OVARIAN-specific — BRCA, HRD, GIS, FOLR1/FRalpha. ---
# Status closest to index (+14d). BRCA -> BRCA1/BRCA2/Both/NOS/VUS/Favor-Polymorphism;
# HRD/GIS/FOLR1 -> positive/negative; mapped to status codes, then aggregated per patient.
clin_char_biom_var <- function(input_ds) {
  bl_biom_pull <- input_ds %>%
    inner_join(enh_ov_biomarkers, by = "patientid") %>%
    filter(toupper(biomarkername) %in% c('BRCA','HRD','GIS','FOLR1/FRALPHA') &
           biomarkerdate <= dbplyr::sql("DATE_ADD(index_date, 14)")) %>%
    mutate(biomstatus = case_when(
      toupper(biomarkername) == 'BRCA' & biomarkerstatus %in% c('BRCA1 mutation identified','BRCA2 mutation identified',
                                                                'Both BRCA1 and BRCA2 mutations identified',
                                                                'BRCA mutation NOS') ~ 1,
      toupper(biomarkername) == 'BRCA' & biomarkerstatus %in% c('Genetic Variant of Unknown Significance (VUS)',
                                                                'Genetic Variant Favor Polymorphism') ~ 2,
      toupper(biomarkername) == 'HRD'          & biomarkerstatus %in% c('Positive') ~ 1,
      toupper(biomarkername) == 'GIS'          & biomarkerstatus %in% c('Positive') ~ 1,
      toupper(biomarkername) == 'FOLR1/FRALPHA' & biomarkerstatus %in% c('Positive') ~ 1,
      biomarkerstatus %in% c('Negative') ~ 2,
      biomarkerstatus %in% c('Unknown','Other','Unsuccessful/indeterminate test','Results pending','Equivocal') ~ 3,
      TRUE ~ 3))
  # ... per-patient aggregation + closest-to-index pick (as in EC clin_char_biom_var) -- see the original.
  bl_biom_pull
}

# --- BRCA/HRD composite (PARP / FRalpha eligibility). ---
# Combine the BRCA status code (brcan) and HRD status code (hrdn) into a composite:
#   brcahrd: "HRd (BRCAm + BRCAwt/HRd)", "HRp + BRCAwt (excluding HRp/BRCAm)",
#            "HRp + BRCA/HRD unknown", "Unknown BRCA and HRD status".
# (hrdfl / hrpfl / uhrdbrca / brcahrdn flags derive from brcan x hrdn -- see the original.)

# --- Lab characteristics clin_char_lab_var(): one block per analyte. ---
# Each analyte: pull the lab record closest to index, classify value, keep value/
# date/unit/status. OC panel (richer than EC/prostate — CA-125 is the key marker):
#   CA-125 (cal125: Normalized <=35 / Elevated >35 KU/L), PLATELETS (pltgrp <150 / >=150,000/uL),
#   NEUTROPHILS, HEMOGLOBIN, CREATININE, BILIRUBIN, ASPARTATE AMINOTRANSFERASE (AST),
#   ALANINE AMINOTRANSFERASE (ALT), ALKALINE PHOSPHATASE, ALBUMIN, LYMPHOCYTES.
# labstatus = case_when(... testresultcleaned > 0 ~ "Positive"/1, ... ~ "Unknown"/2,
#                       is.na(labdate) ~ "Missing"/3) then per-analyte value bands.

# --- Vitals: baseline BMI (BODY HEIGHT cm / BODY WEIGHT kg, closest to index). ---
clin_char_vitals_var <- function(input_ds) {
  bl_vitals_pull <- input_ds %>%
    inner_join(enh_ov_vitals, by = "patientid") %>%
    filter((toupper(test) == 'BODY HEIGHT' & testunitscleaned == "cm" & testresultcleaned > 0) |
           (toupper(test) == 'BODY WEIGHT' & testunitscleaned == "kg" & testresultcleaned > 0)) %>%
    mutate(vitaldate = pmax(testdate, resultdate, na.rm = TRUE)) %>%
    filter(vitaldate <= index_date)
  bl_max_vitaldate <- bl_vitals_pull %>% group_by(patientid, index_date, test) %>%
    summarise(vitaldate = max(vitaldate, na.rm = TRUE), .groups = "drop")     # closest to index
  # join height + weight back, bmi = weight / (height/100)^2, then bmi bands (== prostate vitals).
  bl_max_vitaldate
}

# ===========================================================================
# DRIVER — R/Programs/02_Data_Creation/002_Function_Calls.R           (the function-call companion, all 20pp)
# Sources 001_Data_Creation_Functions.R (the function definitions above) and orchestrates the
# per-cohort build: each step runs a *_var function over the cohort's index table and pushes the
# result to the personal schema (enh_ov_<coh>_<step>_tbl). Build order:
#   index_lot_cohort -> demographics_variable_addn -> minavaildate -> clin_char_master
#     -> trt_var_creation -> visit_var -> outcomes_tbl_var -> proc (platinum sensitivity)
#     -> overall_ads_creation (union all cohorts + the PROC cohort) -> push final ADS.
# Full OC cohort list (8): overall, lot1, lot1m, lot2, lot2m, lot3, lot4, lot5.
# ===========================================================================
coh_list <- c("overall", "lot1", "lot1m", "lot2", "lot2m", "lot3", "lot4", "lot5")

# Generic "run a step function per cohort and push" pattern used throughout the driver:
run_step_for_all <- function(step_fun, suffix) {
  for (coh_flag in coh_list) {
    index_tbl <- tbl(con, in_schema(personal_schema,
                                    paste0("enh_ov_", coh_flag, "_index_tbl")))   # pull cohort index
    df  <- step_fun(index_tbl) %>% collect()
    var_name <- paste0("enh_ov_", coh_flag, "_", suffix, "_tbl")
    copyToPersonalSchema(con, df, var_name, replace = TRUE)                       # push step output
    rm(df)
  }
}
# run_step_for_all(demographics_variable_addn, "dem")    # Demog creation calls
# run_step_for_all(clin_char_master,           "clin")   # Clinical creation calls (wraps clin_char_*_var)
# run_step_for_all(trt_var_creation,           "trt_var")# Treatment creation calls
# run_step_for_all(visit_var,                  "visit_var")  # Visits creation (vis120-style recency)
# run_step_for_all(outcomes_tbl_var,           "outcomes_var") # Outcomes (id3mosfu / OS / PFS)

# --- Platinum sensitivity (PROC) — the OC-defining outcome dimension. ---  (the function-call companion the original)
# For line cohorts 2L+ (proc_cohorts = lot2/lot3/lot4/lot5), compute platinum-free interval (PFI)
# and a platinum-sensitivity status (plat_sen_v1/v2 ∈ Sensitive/Resistant), carrying the PREVIOUS
# line's status forward iteratively (prev_line_plat_sen_status). pcycled = platinum recycled;
# eligibility columns flag PROC eligibility. prev_ln_sd window = DATE_ADD(line_start, 14).
proc_cohorts <- c("lot2", "lot3", "lot4", "lot5")
# (iterative per-line: 2L has no previous line; 3L+ inherits prev line's plat_sen; recompute PFI.)

# --- Treated flag (cohortu) + final ADS assembly (overall_ads_creation). ---  (the function-call companion the original)
treated_patients <- enh_ov_lot %>% mutate(treat_flag = 1) %>% select(patientid, treat_flag) %>% distinct()

# overall_ads_creation(): left-join all per-cohort step tables, add cohort labels, and SPLIT OUT the
# PROC cohort — patients in 2L+ who are platinum-RESISTANT get an extra cohort row:
#   cohort = "2L+ PROC: Index at First Platinum Resistance", cohortn = 9.
# tt_first_tx_diag = time from diagnosis (init) to first treatment (min(surgerydate, lot1sd)).
# Bind all cohorts (union_all) + the PROC rows into one ADS, then push.
#   df_proc <- df %>% filter(cohortn %in% c(4, 6, 7, 8) & plat_sen_v1 == "Resistant") %>%
#                     mutate(cohort = "2L+ PROC: Index at First Platinum Resistance", cohortn = 9)
#   oc_ads  <- rbind(df, df_proc)
#   oc_ads_final <- oc_ads %>%
#     mutate(tt_first_tx_diag = as.numeric(pmin(surgerydate, lot1sd, na.rm = TRUE) - init)) %>%
#     select(-prev_plat_sen_v1, -prev_plat_sen_v2, -db) %>% distinct()
#   copyToPersonalSchema(con, oc_ads_final, "rwdp_oc_2026m03_v1", replace = TRUE)   # FINAL OC ADS
#   dbDisconnect(con)

# ===========================================================================
# Follow-up-end / death anchors.
# clin_char_fuend_dthdt_var(): IDENTICAL pattern to the prostate engine's
# follow_up_and_death — fu_enddt_preliminary = latest of last visit/televisit/
# LOT-end/oral-end/med-order/drug-episode; coarse dateofdeath imputation (YYYY-MM ->
# 15th; YYYY -> index-aware Jul-15/Dec-31); cap follow-up at death; dthfufl 120-day
# window; fued = max(fu_enddt, index). (This is SHARED logic, not OC-specific.)
clin_char_fuend_dthdt_var <- function(input_ds) {
  fu <- input_ds %>% select(patientid, index_date) %>%
    left_join(enh_ov_visit %>% group_by(patientid) %>% summarise(last_visitdate = max(visitdate, na.rm = TRUE)), by = "patientid") %>%
    left_join(enh_ov_med_order %>% filter(is.na(iscancelled)) %>% group_by(patientid) %>% summarise(last_ordereddate = max(ordereddate, na.rm = TRUE)), by = "patientid") %>%
    left_join(enh_ov_telemed %>% group_by(patientid) %>% summarise(last_televisitdate = max(visitdate, na.rm = TRUE)), by = "patientid") %>%
    left_join(enh_ov_lot %>% group_by(patientid) %>% summarise(last_lotenddate = max(enddate, na.rm = TRUE)), by = "patientid") %>%
    left_join(enh_ov_orals %>% filter((dategranularity != 'Year' | is.na(dategranularity)) & !is.na(enddate)) %>% group_by(patientid) %>% summarise(last_oralenddate = max(enddate, na.rm = TRUE)), by = "patientid") %>%
    left_join(enh_ov_drugepisode %>% group_by(patientid) %>% summarise(last_drugepidate = max(episodedate, na.rm = TRUE)), by = "patientid") %>%
    mutate(fu_enddt_preliminary = pmax(last_visitdate, last_televisitdate, last_ordereddate,
                                       last_lotenddate, last_oralenddate, last_drugepidate, na.rm = TRUE)) %>%
    left_join(enh_ov_mortality %>% select(patientid, dateofdeath), by = "patientid") %>%
    mutate(
      dateofdeath_init = dbplyr::sql("CASE WHEN LENGTH(dateofdeath)=7 THEN CAST(CONCAT(dateofdeath,'-15') AS DATE) WHEN LENGTH(dateofdeath)=4 THEN CAST(CONCAT(dateofdeath,'-07-15') AS DATE) ELSE NULL END"),
      f_death = dbplyr::sql("CASE WHEN dateofdeath IS NOT NULL THEN 1 ELSE 0 END"),
      death_dt_preliminary = dbplyr::sql("CASE WHEN LENGTH(dateofdeath)=7 AND SUBSTR(CAST(fu_enddt_preliminary AS STRING),1,7)=SUBSTR(dateofdeath,1,7) THEN LAST_DAY(dateofdeath_init) ELSE dateofdeath_init END"),
      fu_enddt = dbplyr::sql("CASE WHEN death_dt_preliminary IS NOT NULL AND fu_enddt_preliminary > death_dt_preliminary THEN CASE WHEN SUBSTR(CAST(death_dt_preliminary AS STRING),1,7)=SUBSTR(CAST(last_lotenddate AS STRING),1,7) THEN last_lotenddate ELSE death_dt_preliminary END ELSE fu_enddt_preliminary END"),
      dthdt = dbplyr::sql("CASE WHEN SUBSTR(CAST(death_dt_preliminary AS STRING),1,7)=SUBSTR(CAST(last_lotenddate AS STRING),1,7) THEN CAST(LAST_DAY(death_dt_preliminary) AS DATE) ELSE death_dt_preliminary END"),
      dthfl = dbplyr::sql("CASE WHEN dthdt IS NOT NULL THEN 1 ELSE 0 END"),
      fued = dbplyr::sql("CASE WHEN fu_enddt > index_date THEN fu_enddt ELSE index_date END"),
      dthfufl_dur = dbplyr::sql("DATEDIFF(dthdt, fued)"),
      dthfufl = dbplyr::sql("CASE WHEN dthdt IS NULL THEN 'Missing' WHEN dthfufl_dur <= 120 THEN 1 WHEN dthfufl_dur > 120 THEN 0 ELSE NULL END"))
  fu
}

# clin_char_master(): compose all clinical-characteristic functions + minavaildate, add duration
# vars (basedur/pinddur/fudur/pfudur/indexyr).
clin_char_master <- function(input_ds) {
  input_ds %>% select(patientid, index_date) %>%
    left_join(clin_char_ecog_var(input_ds),      by = c("patientid", "index_date")) %>%
    left_join(clin_char_enh_ov_var(input_ds),    by = c("patientid", "index_date")) %>%
    left_join(clin_char_biom_var(input_ds),      by = c("patientid", "index_date")) %>%
    left_join(clin_char_lab_var(input_ds),       by = c("patientid", "index_date")) %>%
    left_join(clin_char_vitals_var(input_ds),    by = c("patientid", "index_date")) %>%
    left_join(clin_char_fuend_dthdt_var(input_ds), by = c("patientid", "index_date")) %>%
    left_join(minavaildate_tbl,                  by = c("patientid", "index_date")) %>%
    mutate(basedur = datediff(index_date, minavaildate),     # index - data-availability floor
           pinddur = datediff(index_date, init),             # index - initial diagnosis
           fudur   = datediff(fued, index_date) + 1,         # follow-up duration
           pfudur  = datediff(index_end, index_date) + 1,    # potential follow-up
           indexyr = year(index_date)) %>%
    distinct()
}

# ===========================================================================
# Treatment variables — trt_var_creation().
# OC uses per-line drug-CLASS FLAGS (not a single classifier): for lines 1..5 build
# lot<i>{clin,bev,bevm,plat,io,parpm,parpmo} = 1 if that line's name matches the class
# (max to patient level). lotn = max line; lotngrl/n band it (1/2/3/4/5+). db flag =
# EDM/ZEJ (Niraparib-band). fnira = Niraparib first line.
trt_var_creation <- function(input_ds) {
  # per-line frames lot<i>* (non-maintenance) + lot<i>m* (maintenance) + drug-episode flags:
  #   lotbev = ismaintenancetherapy='False' AND UPPER(linename) LIKE '%BEVACIZUMAB%'
  #   lotbevm= ismaintenancetherapy='True'  AND ... '%BEVACIZUMAB%'
  #   lotplat= ismaintenancetherapy='False' AND UPPER(linename) LIKE '%PLATIN%'
  #   lotio  = ismaintenancetherapy='False' AND UPPER(linename) LIKE
  #            ('%ATEZOLIZUMAB%' OR '%DURVALUMAB%' OR '%NIVOLUMAB%' OR '%PEMBROLIZUMAB%')
  #   lotparpM  = ismaintenancetherapy='True' AND UPPER(linename) RLIKE
  #              '(?=.*\b(OLAPARIB|RUCAPARIB|TALAZOPARIB|NIRAPARIB)\b)' (PARP mono maintenance)
  #   lotparpoM = PARP in combination/other maintenance
  #   lotclin   = ismaintenancetherapy='False' AND UPPER(linename) LIKE '%CLINICAL STUDY DRUG%'
  # then group_by(patientid,index_date) %>% summarise(max(...)) and rename lot<i><flag>.
  # lotn = max(linenumber); lotngrl = case_when(1~"1",2~"2",3~"3",4~"4",>=5~"5+",TRUE~"0"); lotngrln 1..6.
  input_ds %>% select(patientid, index_date)   # (full per-line flag construction: the original)
}

# ===========================================================================
# Outcomes — outcomes_tbl_var().
# Composes: id3mosfu (~3mo potential follow-up), vis120 (active visit within 120d of
# line end), trtdis (treatment discontinuation), ttd (time-to-discontinuation), ttnt/
# ttntfl (time-to-next-treatment), os (months: death -> dthdt, censor -> fued), and the
# real-world PFS family. PFS uses progression EVIDENCE: (isradiographicevidence |
# ispathologicevidence | isclinicalassessmentonly | istumormarkerevidence | ismixedresponse)
# == 'Yes' AND ispseudoprogressionmentioned == 'No' AND progressiondate > line start, with
# eligpfs eligibility. Emits pfsfl/pfsdt/pfs (PFS) and pfs2fl/pfs2dt/pfs2 (PFS2 = 2nd progression).
outcomes_tbl_var <- function(input_ds) {
  base <- input_ds %>% select(patientid, index_date)
  base %>%
    mutate(id3mosfu = dbplyr::sql("CASE WHEN DATEDIFF(index_end, index_date) > 91 THEN 1 ELSE 0 END"))
  # ... join clin_char (dthdt/dthfl/fued), trt (lot<i>sd/ed, lotn), vis120, eligpfs, pfs* ...
  # os = (DATEDIFF(dthdt|fued, index_date)+1)/30.4375 ; ttnt = (DATEDIFF(pmin(next_lot_sd, dthdt), index)+1)/30.4375.
}

# ===========================================================================
# Final assembly — overall_ads_creation() + push.                   (the original; function-call driver)
# Per cohort: left-join index + dem + clin + trt + outcomes; add cohort labels and the treated split;
# rename to the published column names; (PROC cohort added by the driver). Union all cohorts -> push.
overall_ads_creation <- function(coh_flag) {
  index_tbl    <- tbl(con, in_schema(personal_schema, paste0("enh_ov_", coh_flag, "_index_tbl")))
  dem_tbl      <- tbl(con, in_schema(personal_schema, paste0("enh_ov_", coh_flag, "_dem_tbl")))
  clin_tbl     <- tbl(con, in_schema(personal_schema, paste0("enh_ov_", coh_flag, "_clin_tbl")))
  trt_tbl      <- tbl(con, in_schema(personal_schema, paste0("enh_ov_", coh_flag, "_trt_var_tbl")))
  outcomes_tbl <- tbl(con, in_schema(personal_schema, paste0("enh_ov_", coh_flag, "_outcomes_var_tbl")))
  index_tbl %>%
    left_join(dem_tbl, by = c("patientid", "index_date")) %>%
    left_join(clin_tbl, by = c("patientid", "index_date")) %>%
    left_join(trt_tbl, by = c("patientid", "index_date")) %>%
    left_join(outcomes_tbl, by = c("patientid", "index_date")) %>%
    left_join(treated_patients, by = "patientid") %>%
    mutate(
      cohort = case_when(coh_flag == "overall" ~ "Overall OC", coh_flag == "lot1" ~ "L1 + treated OC",
                         coh_flag == "lot1m" ~ "L1m + treated OC", coh_flag == "lot2" ~ "L2 + treated OC",
                         coh_flag == "lot2m" ~ "L2m + treated OC", coh_flag == "lot3" ~ "L3 + treated OC",
                         TRUE ~ "Unknown"),
      cohortn  = case_when(coh_flag == "overall" ~ 1, coh_flag == "lot1" ~ 2, coh_flag == "lot1m" ~ 3,
                           coh_flag == "lot2" ~ 4, coh_flag == "lot2m" ~ 5, coh_flag == "lot3" ~ 6, TRUE ~ 99),
      cohortu  = case_when(!is.na(treat_flag) ~ "Treated OC", TRUE ~ "Untreated OC"),
      cohortun = case_when(!is.na(treat_flag) ~ 1, TRUE ~ 2)) %>%
    rename(patid = patientid, indexdt = index_date, datav = refresh, rawrwd = rawrwd_source,
           minindex = index_start, maxindex = index_end, last_visit_date = lastvisitdate) %>%
    distinct()
}
# Final ADS: oc_final_ads <- union_all over all cohorts (+ the PROC cohort, see driver) ->
#   copyToPersonalSchema(con, oc_ads_final, "rwdp_oc_2025m03_v1", replace = TRUE); dbDisconnect(con)
#
# OC reconstruction: build logic reconstructed from the original OC script and its function-call companion.
# Reference only — verify against the original build script Remaining: full per-line flag construction
# inside trt_var_creation and the complete PFS/PFS2 join chain (logic captured above as comments).
