# Specification QC findings — oc 202606

RWP's INDEPENDENT specification QC, performed while drafting the contract records. Distinct from
`DECISIONS.md`: a decision is a question the specification does not answer; a finding here is a defect
in the specification itself — a contradiction, a truncated value list, a value stated in one tab and
contradicted in another, an impossible date.

This register is REQUIRED before `contract: approved` (Gate 2). An empty table is a valid and
meaningful state — it says RWP did the QC and found nothing. A missing file says nothing at all, which
is why the gate will not accept its absence.

**Status vocabulary:** `open` (reported, not yet corrected) · `corrected` (RWB issued a revised
workbook) · `waived` (RWB confirmed the current reading; no document change).

**A workaround is not a correction.** Reading a bad literal as the value you think was meant, to
unblock a build, leaves the finding `open`: re-extracting the source workbook reintroduces it.

Findings caused by the DELIVERY FORMAT rather than by RWB are marked `format` in `Kind`; they close by
extracting the approved workbook, with no RWB round-trip.

Every row needs a Status. A blank one is an unanswered question and blocks approval exactly as `open`
does — so add rows to THIS table rather than a second one with different columns. A row under a table
with no Status column cannot be read at all, and Gate 2 says so by name.

**A `waived` row needs two more columns.** WORKFLOW.md §"Waivers": *a waiver names who approved it,
the rationale, its scope, its expiry, and the evidence it rests on — a waiver without an expiry is a
silent permanent exception and is not a waiver.* Rationale, scope and evidence are `Defect`, `Impact`
and `Disposition`; the approver and the expiry have nowhere else to go, so add `Waived by` and
`Waiver expires` (YYYY-MM-DD) when — and only when — you first waive something. Gate 2 refuses a
`waived` row without them, and treats a waiver whose expiry has passed as OPEN again.

**State of this register:** opened at `contract: draft` with only the study_period domain drafted, so an empty table here means *not yet surveyed*, NOT *surveyed clean* — the empty-table-is-meaningful reading above applies only once the contract claims `coverage_complete`. Findings land as records are drafted.

| ID | Kind | Spec ref | Defect | Impact | Disposition | Status |
|---|---|---|---|---|---|---|
| SQ-01 | format | `study_period:17` | Landmark list internally inconsistent in the reconstruction: one half reads "[9] months = 365 days" (bracketed transcriber reconstruction), the continuation reads "9 months = 274 days, 12 [months]", and the row carries the transcriber's own "[verify exact figures]" marker | The platinum 90/183-day thresholds and the 3-month-FU landmark feed on these figures | Blocked — `OC-DAYS-PER-MONTH-LANDMARKS`; closes by extracting the approved workbook | **open** |
