# Engine gaps — approved requirements the build does not yet meet

Empty: no contract has been approved and no build binds to one yet.

| Gap | What is not met |
|---|---|
