# Ovarian (OC) Spec — Plain-English Variable Guide

> **Purpose.** You have no ovarian-cancer background. This explains, domain by domain,
> **what each variable in the spec represents clinically** and **how it is derived from
> the source data** — so when you open the workbook you understand *why* each variable
> exists, not just its formula. It mirrors the workbook tabs (3.Data Prep → 9.PROC).

---

## 0. First, the 5 ideas that unlock everything

Before the variables, four conventions and one timeline. Once these click, 300+
variables collapse into a handful of patterns.

### 0.1 Everything is measured from the **index date**
Each patient's clock starts at an **index date** (`INDEXDT`) — the anchor for that
patient in that cohort. *Almost every variable is "as of index" or "relative to index".*
The index differs by cohort:
- **Overall** cohort → index = **initial diagnosis date**
- **Line cohorts** (1L, 2L, …) → index = **that line's start date**
- **2L+ PROC** cohort → index = **date of first platinum resistance**

So the *same patient* can appear in several cohorts with *different* index dates and
therefore different values. (That's why a treated patient produces several output rows.)

### 0.2 The "**closest-to-index**" selection pattern
Patients have many lab/biomarker/vital records over time. For a baseline snapshot we
pick the **one record closest to the index date** (often "on or before index", sometimes
within a small window). Ties on the same date are broken by a documented rule (e.g.
"take the highest value"). You'll see this pattern dozens of times — it's the single
most common derivation in the spec.

### 0.3 Variable-name suffix cheat-sheet
The spec uses consistent suffixes, so a "family" of related columns repeats:

| Suffix | Means | Example |
|---|---|---|
| *(none)* | the character/label value | `BRCA` = "Mutated" |
| **N** | numeric code of the label | `BRCAN` = 1 |
| **DT** | the date associated with the value | `BRCADT` |
| **V** | the numeric value (labs) | `LABCA125V` |
| **VU** | the unit of that value | `LABCA125VU` = "iU/L" |
| **C** | "**closest**-to-index" variant (vs an ever/time-agnostic variant) | `BRCAC` |
| **GR / GRP** | a grouped/banded version | `AGEGR1`, `BMI_GRP` |
| **FL** | a yes/no **flag** (event happened or not) | `PFSFL`, `DTHFL` |
| **L1…L5 / i=1..5** | the **line of therapy** the variable is about | `LOT2SD`, `L3PLAT` |
| **M** | the **maintenance** part of a line (vs the main regimen) | `LOT1M`, `L2parpM` |

So `LABCA125V / LABCA125VDT / LABCA125VU / CA125GRP` is **one lab** (CA-125) expressed
as value / its date / its unit / a banded category.

### 0.4 Two recurring constants
- **30.4375** = average days per month (used to convert day-counts to months for
  survival endpoints). So "3 months" = 91 days, "6 months" = 183 days.
- **"+1" (inclusive day count)** — durations count both endpoints, e.g.
  `duration = end − start + 1`.

### 0.5 The patient timeline (the periods)
| Period | What it spans | Used for |
|---|---|---|
| **STUDY_PD** | earliest data → study end (28-Feb-2026) | the whole dataset window |
| **ID_PD** | 01-Jan-2011 → 28-Feb-2026 | who's eligible to enter |
| **PRE_INT** | start of data → index (inclusive) | "any time before index" lookups |
| **PRE_BIO** | index−∞ → index **+14 days** | which biomarker tests count as baseline |
| **LOT_ECOG** | index **−30 → +7 days** | which ECOG scores count as baseline |
| **FU** (follow-up) | index+1 → end of data/death | where outcomes are measured |

> ⚠️ **PRE_BIO (+14) and LOT_ECOG (−30/+7) are current *working* rules carrying `[verify]`,
> not signed off.** The biomarker window in particular has a **flagged source conflict**
> (data-prep allows up to index+14 days, while some clinical text reads "on or prior to
> index only"). Check the workbook's Status / Source Register before relying on them.

---

## 1. Study population & cohorts — *who is in the dataset* (tab 4.StudyPop)

**Why it matters:** before deriving anything, we must define *which patients* and *how
they’re grouped*. In OC, patients are analysed both overall and by line of therapy,
because treatment and prognosis change at each recurrence.

| Variable(s) | What it represents | How it's derived (plain) |
|---|---|---|
| `COHORT` / `COHORTN` | The **analysis cohort** a row belongs to (Overall OC; 1L, 1L-maintenance, 2L, 2L-maint, 3L, 4L, 5L treated; **2L+ PROC**). `…N` is its numeric code. | Assigned from the patient's treatment history; the cohort sets the index date. |
| `COHORTU` / `COHORTUN` | **Treated vs Untreated** OC. | A patient with no recorded line of therapy is "Untreated OC"; otherwise "Treated OC". |
| `PROC_cohort_membership` | Rule that puts a patient into the **Platinum-Resistant OC (PROC)** cohort. | A later-line patient whose platinum status = "Platinum Resistant" enters PROC, indexed at first resistance. *(working direction: build to EDM-derived `PLAT_SEN` as the PROC source — Biostats/Program ratification pending, D1.)* |
| `POP_FILTER_*` (female, epithelial OC/FT/PP, diagnosis ≥2011, age ≥18) | The **eligibility filters** for the study. | Inclusion criteria; *flagged as source-pending because the legacy PDFs don't state them explicitly.* |
| `ROW_SELECTION_one_row_per_patient_per_cohort` | The rule that one patient → **one row per cohort**. | A 2L-treated patient appears in Overall + 1L + 2L (etc.), one row each. |
| `MININDEX` / `MAXINDEX` | The earliest/latest **possible** index date for a cohort. | Used to test whether a patient has enough potential follow-up (see `ID3MOSFU`). |

> *Plain takeaway:* "epithelial OC/FT/PP" = epithelial **ovarian / fallopian-tube /
> primary-peritoneal** cancer — clinically treated as one disease.

---

## 2. Data prep — *the plumbing* (tab 3.Data Prep)

**Why it matters:** this domain doesn't produce clinical variables; it defines the
**source tables** and the **rules** (date handling, dedup, periods) the rest of the spec
relies on. You can skim it, but it's where data-quality decisions live.

- `SRC_*` (≈25 rows) — each names a **Flatiron source table** the product reads
  (e.g. `SRC_LINEOFTHERAPY` → the LineOfTherapy table; `SRC_BIOMARKERS` → the biomarker
  table; `SRC_MORTALITY` → the death table). Think of these as the "ingredients list".
- `INDEX`, `FU`, `PRE_BIO`, `LOT_ECOG`, `STUDY_PD`, `ID_PD` — the **time periods** above.
- `BIO_DATE_RULE`, `LOT_DEDUP`, `DATE_FORMAT_PICK`, `PROG_VS_DEATH`,
  `MAXVISIT_AFTER_DEATH` — **rules / data-quality checks** (e.g. how a biomarker's date
  is defined; how to de-duplicate line-of-therapy rows; how to break ties between a
  progression date and a death date). Several carry `[verify]` because they're awaiting
  sign-off.
- `DAYS_PER_MONTH` — the 30.4375 constant.

---

## 3. Demographics — *who the patient is* (tab 5.Demographics)

**Why it matters:** standard descriptors used to characterise the cohort and adjust
analyses.

| Variable(s) | Represents | Derived |
|---|---|---|
| `AGE`, `AGEGR1(N)` | **Age at index** and its band (0-18 … ≥85). | `year(index) − birth year`; then bucketed. |
| `REGION1(N)` | **US census region** of residence. | State mapped to Northeast/Midwest/South/West. |
| `RACE(N)`, `ETH(N)` | **Race / ethnicity**. | As reported; small categories collapsed; Hispanic handling per rule. |
| `GENDER`/`GenderN`, `birthsex` | **Sex** (OC patients are essentially all female). | As recorded in the raw data. |
| `PRACTIC(N)` | **Practice type** (Academic vs Community). | From the treating practice's attributes. |
| `SES` | **Socioeconomic status** (area-level index). | Yost SES index at the last visit. |

---

## 4. Disease characteristics at diagnosis (tab 6.Clinical, part 1)

**Why it matters:** these describe *what kind* of ovarian cancer and *how advanced* —
the strongest baseline prognostic factors, and they drive treatment choice.

| Variable(s) | What it represents (clinical) | How it's derived |
|---|---|---|
| `INIT`, `INITYR` | **Date / year of initial OC diagnosis**. | From the Enhanced OC table. |
| `HISTO(N)` | **Histology** = the tumour's cell type (Serous / Epithelial-NOS-or-Other / Unknown). Serous is the commonest, most aggressive epithelial subtype. | Mapped from the source histology field. |
| `STAGE(N)` | **FIGO stage I–IV** = how far the cancer has spread (I = ovary only … IV = distant spread). Most OC is diagnosed at III/IV. | "Cascade" prefix match on the source group-stage (test IV, then III, then II, then I). |
| `ISSURG(N)` | Whether the patient had **cytoreductive ("debulking") surgery** (removing as much tumour as possible). | Yes/No from the surgery flag. |
| `SURG(N)` | **Type/timing of surgery**: Primary (PCS, surgery first) vs Interval (ICS, after neoadjuvant chemo) vs none/unknown. | Compares surgery date to the 1L start date. |
| `NEOADJ(N)` | **Neoadjuvant chemotherapy** = chemo *before* surgery (used when upfront surgery isn't feasible). | Derived from surgery type (interval surgery ⇒ neoadjuvant = Yes). |
| `RD(N)`, `sizeofresidualdisease` | **Residual disease** = how much tumour remained after surgery (none / visible). A key prognostic factor — less residual = better. | From the residual-disease status field. |
| `TT_FIRST_TX_DIAG` | **Time from diagnosis to first treatment/surgery** (days). | `min(surgery date, 1L start) − diagnosis date`. |

---

## 5. Performance status & body metrics (tab 6.Clinical, part 2)

**Why it matters:** how fit the patient is and their body size — used for eligibility,
chemo dosing, and risk adjustment.

| Variable(s) | Represents | Derived |
|---|---|---|
| `ECOG(N)` | **ECOG performance status (0–4)**: 0 = fully active, 4 = completely disabled. Captures how well the patient functions. | The ECOG score **closest to index**; same-day tie → take the **highest** (worst) score. |
| `WEIGHT`/`HEIGHT` (+`…DT`) | Body weight (kg) / height (cm) closest to index. | Closest-to-index vital; tie → highest. |
| `BMI`, `BMI_GRP`/`BMIGRN` | **Body-mass index** and band (underweight…obese). | `weight / (height/100)²`. |
| `BSA` | **Body-surface area (m²)** — used to **dose chemotherapy**. | Du Bois formula: `0.007184 × height^0.725 × weight^0.425`. |

---

## 6. Biomarkers (tab 6.Clinical, part 3)

**Why it matters:** biomarkers decide **which targeted drugs a patient can get**. This
is central to modern OC treatment.

- **BRCA1/2 mutation** and **HRD** (homologous-recombination deficiency) → predict
  benefit from **PARP-inhibitor** maintenance.
- **FOLR1 / FRα** (folate-receptor-alpha) → eligibility for **mirvetuximab**.
- **GIS** (genomic-instability score) → another HRD-type signal.

| Variable family | Represents | Derived |
|---|---|---|
| `BRCA(N)` / `BRCAC(N)` (+`…DT`) | **BRCA status**: Mutated / Wild-type / Unknown / None(=never tested). Two flavours: a **time-agnostic "ever"** view (`BRCA`) and a **closest-to-index** view (`BRCAC`). | "Ever-mutated wins" for the time-agnostic version; closest-to-index for the `C` version; same-day ties resolved by documented rules. |
| `HRD(N)` / `HRDC(N)` | **HRD status**: HRd (deficient/positive) / HRp (proficient/negative) / Unknown / None. | Same two-flavour pattern. Same-day 3-way tie (HRd+HRp+Unknown) → **Unknown**. |
| `GIS(N)` / `GISC(N)`, `FOLR1(N)` / `FOLR1C(N)` | **GIS** and **FOLR1** status (Positive / Negative / Unknown / None). | Same pattern as HRD. |
| `HRDFL`, `HRPFL`, `UHRDBRCA`, `brcahrd(c)` | **Composite HR subgroups**: HR-deficient (BRCA-mutated *or* HRD-positive), HR-proficient, or both-unknown — and a combined `BRCA_HRD_composite`. | Logical combinations of the BRCA × HRD statuses (e.g. HR-deficient flag = BRCA mutated OR (BRCA wild-type AND HRD positive)). |
| `…DT` dates | The biomarker test date for each. | `max(SpecimenReceivedDate, ResultDate)` of the selected record. |

> *Plain takeaway:* most biomarker variables come in a quartet — **label, numeric,
> date, and a "closest-to-index" twin** — because *which* result you pick (ever-positive
> vs nearest to index) can change the baseline value.

---

## 7. Laboratory values (tab 6.Clinical, part 4)

**Why it matters:** baseline blood tests reflect organ function and disease burden, and
gate whether a patient can safely receive chemo.

**The 11 analytes:** CA-125 (the OC **tumour marker** — tracks disease burden/response),
platelets, neutrophils, hemoglobin, creatinine, bilirubin, AST, ALT, alkaline
phosphatase, albumin, lymphocytes.

Each analyte repeats the **same four-variable pattern**, e.g. for CA-125:

| Variable | Represents | Derived |
|---|---|---|
| `LABCA125` (+`…N`) | CA-125 result **status — three-state**: **Present / Unknown / Missing** (numeric 1/2/3). *Not* a yes/no flag. | Present = ≥1 valid qualifying record; Unknown = a record exists but key fields (value/unit/date) are unusable; Missing = no relevant record at all. |
| `LABCA125V` | The **value** closest to index. | Closest-to-index; same-day tie → a documented rule (highest *or* lowest depending on the analyte). |
| `LABCA125VDT` | The **date** of that value. | `max(ResultDate, TestDate)`. |
| `LABCA125VU` | The **unit** (e.g. iU/L). | From the cleaned unit field. |
| `CA125GRP(N)` | A **banded** category of the value. | Threshold cut — **unit-dependent** (e.g. iU/L → 35,000; kU/L → 35); confirm the delivered unit strings on the feed. |

The other 10 labs (`LABPLA…`, `LABNEU…`, `LABHEM…`, `LABCRE…`, `LABBIL…`, `LABAST…`,
`LABALT…`, `LABALP…`, `LABALB…`, `LABLYM…`) follow the identical **status (tri-state
Present/Unknown/Missing) / value / date / unit** shape, plus a `PLTGRP` band for platelets.

---

## 8. Treatment / lines of therapy (tab 7.Treatment)

**Why it matters:** this captures **what drugs each patient got, in what order**, which
is the backbone of every treatment and outcome analysis.

### 8.1 The per-line families (i = 1…5)
For each line of therapy, the spec records a parallel set (this is most of the 85
treatment variables):

| Family | Represents | Derived |
|---|---|---|
| `LOTi` | The **regimen name** of line *i* (the drug combination). | The line-name from the LineOfTherapy table where line = *i*, main (non-maintenance) part. |
| `LOTiSD` / `LOTiED` | Line *i* **start / end** dates. | Start from the line table; end = last drug-episode date in the line. |
| `LOTiM` / `LOTiMSD` / `LOTiMED` | The **maintenance** regimen of line *i* and its start/end (the drug continued after the main regimen). | The maintenance-flagged part of the same line. |
| `LOTiDUR` / `LOTimDUR` | **Durations** (days) of the line and its maintenance. | `end − start + 1`. |

### 8.2 Per-line drug-class flags
Did line *i* contain a given drug class? (yes/no)

| Flag family | Drug class — and why it's tracked in OC |
|---|---|
| `LiPLAT` | **Platinum** chemo (carboplatin/cisplatin) — the OC backbone; drives platinum-sensitivity. |
| `LiBEV` / `LiBEVM` | **Bevacizumab** (anti-angiogenic) — given with chemo and/or as maintenance. |
| `LiparpM` / `LiparpMO` | **PARP-inhibitor maintenance** (niraparib/olaparib/rucaparib) — any-PARP vs PARP-monotherapy. |
| `LiIO` | **Immuno-oncology** agents (e.g. atezolizumab) — less established in OC; tracked for completeness. |

### 8.3 Counts, study-drug, and the Panoramic LineSetting delta
| Variable(s) | Represents | Derived |
|---|---|---|
| `LOTN`, `LOTNGR1(N)` | **Number of lines** the patient received (and a band). | `max(line number)`; 0 if untreated. |
| `FNIRA` | Patient ever had a (non-cancelled) **niraparib order**. | From the medication-orders table. |
| `CSD_PRE_INT` / `CSD_INDEX` / `CSD_FU` | Presence of a **clinical study drug** before / during / after the index line. | Line-name contains "Clinical Study Drug". |
| `LineSetting` (+ values Neoadjuvant / Adjuvant / Advanced / Off-Systemic-Therapy) | **NEW in Panoramic**: an explicit per-line **treatment setting** (where in the disease course the line sits). | Provided by Panoramic; rules: Neoadjuvant = before first surgery; Adjuvant = between surgery and recurrence; Advanced = after (or ≤14 d before) recurrence. |
| `Line-splitting`, `Off Systemic Therapy`, `PARP carve-out`, `RecurrenceDate dependency` | The **rules** Panoramic uses to split lines at setting boundaries (and the exception for PARP-containing lines). | Panoramic logic; **this can renumber lines vs the legacy EDM**, which is why it's a headline migration delta. |

---

## 9. Platinum sensitivity & PROC (tab 9.PROC PSOC Strategy)

**Why it matters — this is the clinical centrepiece of ovarian cancer.** OC is treated
with platinum chemo; **how long the patient stays in remission after platinum decides
the next treatment**. Patients who recur quickly ("platinum-resistant") have worse
prognosis and are the target of many new drugs (the **PROC** population).

| Variable(s) | Represents | Derived (plain) |
|---|---|---|
| `PFI` | **Platinum-Free Interval** (days) — the gap between the last platinum dose and the next progression. | `first qualifying progression date − last platinum-episode date of the prior line`. |
| `PFSDT_IndexToPriorPlatEnd` | The **qualifying progression date** used for PFI. | First non-pseudo progression in the eligible window (≥14 days after platinum). |
| `PCYCL1…5` / `PCYCL1ED…5ED` | **Number of platinum cycles** in each line, and the **last platinum date** in each line. | Count / last of the platinum drug-episodes per line. |
| `ELIG_PLAT_SEN_v1 / v2` | Is the patient **eligible** to have platinum sensitivity evaluated? Two variants: v1 = all-prior-lines (main); v2 = immediate-prior-line. | Requires the relevant prior line(s) to have contained platinum, plus window conditions. |
| `PLAT_SEN_v1 / v2` | **Platinum-sensitivity status**: Refractory / Resistant / Sensitive (plus Not-eligible and prior-LOT states). | Compares `PFI` to day thresholds. **EDM cuts (strict, 2L determination): Refractory `PFI <= 90`; Resistant `90 < PFI <= 183`; Sensitive `PFI > 183` days** (at 3L+ a freshly-scored line uses `0 < PFI <= 183` → Resistant, no Refractory band; prior-resistant lines chain to "Primary prior-LOT"). |
| `UPLAT` | Platinum-use indicator referenced by the strategy. | "Received platinum chemotherapy" concept. |
| `Panoramic Platinum Status` (grain / derivation / thresholds) + `EDM-vs-Panoramic…` | The **Panoramic** vendor's *own* per-line platinum table — related but **not identical** to the EDM derivation. | Panoramic: one row per platinum-containing line; thresholds **91 / 92–183 / 184**. **Working direction:** build to the EDM-derived `PLAT_SEN_v1/v2` as the PROC source of truth (it fits the core tables + matches the prior analysis); the Panoramic Platinum Status table is an **Add-On cross-check** to discuss with Biostats — **Biostats/Program ratification pending (D1)**. |

> *Plain takeaway:* `PLAT_SEN_v1 = "Platinum Resistant"` is the gate into the **PROC**
> cohort. EDM and Panoramic compute this slightly differently (different reference line,
> window, and day thresholds) — reconciling them is a key open decision.

---

## 10. Outcomes / endpoints (tab 8.Outcomes)

**Why it matters:** these are the **results** — how long patients live, how long until
their cancer worsens, how long treatment lasts. They're the reason the dataset exists.

| Variable(s) | Endpoint — plain meaning | Derived (plain) |
|---|---|---|
| `ID3MOSFU` | Has the patient **≥3 months of potential follow-up**? (a gate so we don't measure outcomes on patients with too-short data) | `(MAXINDEX − INDEXDT) ≥ 91 days`. |
| `OS` | **Overall Survival** (months) — time from index to death. | If died: `(death date − index + 1)/30.4375`; if alive: censored at last follow-up. |
| `DTHFL`, `DTHDT`, `DEATH_DT_preliminary` | **Death flag** and **death date**. RWD often knows only the *month* of death. | Month-only death → imputed to the **15th** (same-month-as-follow-up exception → last day; year-only, same year as index → Jul-15 if index month/day ≤ Jul-15, else Dec-31). **The exact parity rule is still a pending Biostats / golden-ADS decision** — Flatiron recommends the 15th/midpoint; sign-off must confirm it reproduces the legacy EDM output. |
| `FUED`, `FUDUR`, `PFUDUR`, `BASEDUR`, `INDEXYR` | **Follow-up end / durations / baseline duration / index year** — the bookkeeping that sets each patient's clocks. | Follow-up end = latest activity (visit/line-end/etc.), reconciled with the death date. |
| `PFSFL`, `PFSDT`, `PFS`, `ELIGPFS` | **rwPFS** — real-world Progression-Free Survival: time to the **first qualifying progression**, or to **death** if there is no eligible progression. `…FL`=did an event happen, `…DT`=its date, `ELIGPFS`=eligible to be analysed. | Event = first qualifying progression **on/after `INDEXDT+14`** (`>= INDEXDT+14`); if none, death is used. Progression is **prioritised over death even when death is earlier** (progression is day-level accurate, death may be month-imputed). No-event patients are **censored** at the last clinic-note date (*not excluded — they still count*). |
| `TTDFL`, `TTD` | **Time to Treatment Discontinuation** — how long the index line lasted. | `(line end − index + 1)/30.4375`. |
| `TTNTFL`, `TTNT` | **Time to Next Treatment** — time until the next line starts (or death). | `(min(next-line start, death) − index + 1)/30.4375`; censored at follow-up end if no event (same inclusive-day convention). |
| `TSSTFL`, `TSST` | **Time to Second Subsequent Therapy** — time to the *line after next* (or death). | Uses the +2 line's start; thresholds are cohort-specific (e.g. 1L cohort needs ≥3 total lines). |
| `RWR1/2/3 (+N, +M, +MN)` | **real-world Response** for lines 1–3: Complete / Partial Response, Stable / Progressive Disease, Unknown, Missing — main regimen and **maintenance** variants. | The recorded response assessment in each line's window; best-vs-first selection still a sign-off item. |
| `PFS2` | **PFS2** — progression-free survival measured after the *next* line (a regulatory-relevant endpoint). | Progression after the subsequent line's start, or death; censored at last clinic note. |
| `VIS120` | A **visit ≥120 days after** the index line end — a data-completeness/engagement check. | Presence of a qualifying visit after the index line. |

> *Plain takeaway:* the endpoint families share a pattern — a **flag** (`…FL`, did the
> event happen), a **date** (`…DT`), and a **time-in-months** value. "Censored" means
> "we stopped watching before the event" — those patients still count, they're not dropped.

---

## 11. How a single patient flows through all of this

Putting the domains in order, for one patient in (say) the **2L** cohort:

1. **Eligibility & cohort** (§1) — qualifies, enters Overall + 1L + 2L; the **2L** row's
   index = 2L start date.
2. **Index & periods** (§0) — clocks set; baseline windows defined.
3. **Diagnosis characteristics** (§4) — histology, stage, surgery, residual disease.
4. **Baseline snapshot** (§5–7) — ECOG, BMI/BSA, biomarkers, labs **closest to index**.
5. **Treatment history** (§8) — lines, regimens, drug-class flags, maintenance, LineSetting.
6. **Platinum sensitivity** (§9) — PFI → `PLAT_SEN`; if resistant, also a PROC row.
7. **Outcomes** (§10) — OS, rwPFS, TTNT/TTD/TSST, response, death date — measured over
   follow-up.

That ordering *is* the spec: **who → when → what kind of cancer → baseline state →
treatment → platinum status → outcomes.**

---

## 12. Reading the `[verify]` / status language

In the workbook you'll see honesty markers — they're not errors, they're the review state:

- **`[verify]` / "first-pass"** — reconstructed from the source but **not yet signed off**.
- **"PENDING" / "conflict"** — a decision not yet made, or two source sections disagree.
- **Owner tags** (Epi/Biostats/Program/Implementation) — who must resolve each open item.
- **Source context** (Prior spec / Flatiron data dictionary / Flatiron LOT rules /
  Flatiron Panoramic doc / RWDP methodology / Clinical dataset) — where each rule comes
  from (by context, since the workbook is production-de-referenced — no filenames/pages).

---

*Companion to the workbook `products/oncology/oc/reference/PROG_SPEC_RWDP_Ovarian_PANO_202606.xlsx`.
This guide is a plain-English learning aid; the workbook tabs hold the authoritative,
per-variable detail (definition · values · derivation · source · owner · open decision).*
