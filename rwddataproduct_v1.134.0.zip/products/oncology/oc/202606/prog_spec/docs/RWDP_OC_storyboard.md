# RWDP + the Ovarian (OC) Spec — a Storyboard for Newcomers

> **Who this is for.** You're new to oncology real-world data. This walks you from
> "what is RWD" all the way to "how the OC 202606 product gets built", using the
> actual artifacts in this repo. Read top to bottom once; after that use it as a map.

---

## 0. TL;DR (the one-paragraph version)

We take **real-world oncology data** from a vendor (Flatiron), and turn it into a
**governed, reproducible analytic dataset** (a *Real-World Data Product*, RWDP) for
ovarian cancer. A **locked engine** (shared code) does the maths; a **per-product
config** (YAML) tells it *what* to build for *this* product. Before any code is
written, humans agree on **a specification** — every cohort, variable, and rule —
which lives in the Excel workbook in `prog_spec/`. We are currently **migrating the
ovarian product from the old data model (EDM) to Flatiron's new delivery (Panoramic)**,
so the spec also records exactly what *changes* in that move. The workbook is the
**draft spec under review**; once signed off, it gets encoded as YAML and the engine
produces the dataset.

---

## 1. Concepts, fastest path

### 1.1 RWD — Real-World Data
Data generated during **routine clinical care** (electronic health records, etc.),
*not* from a clinical trial. **Flatiron Health** is a major oncology RWD vendor: they
abstract oncology EHRs into structured tables (diagnoses, treatments, labs, biomarkers,
progression, death). It is messy, longitudinal, and patient-level.

### 1.2 RWDP — Real-World Data **Product**
Instead of every analyst re-deriving "what's a 2nd-line patient?" or "what's
progression-free survival?" by hand (slow, inconsistent, unauditable), we build the
derivation **once**, as a **product**:

- **Standardized** — one agreed definition per variable.
- **Reproducible** — same input + same config ⇒ same output, every time.
- **Governed** — changes go through review gates, not ad-hoc edits.
- **Reusable** — many studies consume the same analytic-ready dataset (ADS).

Think of it like turning a hand-written recipe that everyone interprets differently
into a **factory line with a written spec**: same product every run.

### 1.3 The two data models: EDM → Panoramic
| | What it is |
|---|---|
| **EDM** | The **existing/legacy** Enhanced Data Mart — how the ovarian variables are derived *today*. The "baseline" we must reproduce. |
| **Panoramic** | Flatiron's **newer delivery** of the same underlying data, with some structural changes (e.g. an explicit `LineSetting` field, a per-line Platinum Status table, a new mortality table). |

The OC 202606 project is a **migration**: keep the EDM logic where it's unchanged,
and carefully handle the places Panoramic is *different* (the "deltas").

### 1.4 The three pieces that make the product
```
        ┌─────────────────────────────┐
        │  SPEC  (human-authoritative) │   ← the Excel workbook in reference/
        │  every cohort/variable/rule  │       (what this whole effort is about)
        └──────────────┬──────────────┘
                       │ encodes into
                       ▼
        ┌─────────────────────────────┐        ┌──────────────────────────┐
        │  CONFIG (per-product YAML)   │  +     │  ENGINE (locked PySpark) │
        │ products/oncology/oc/YYYYMM  │        │  platform/  — shared code│
        │  config + variables + codes  │        │  does the derivations    │
        └──────────────┬──────────────┘        └────────────┬─────────────┘
                       └──────────────┬─────────────────────┘
                                      ▼ run
                         ┌──────────────────────────┐
                         │  ADS — analytic dataset   │  ← the delivered product
                         │  one row per patient/...  │
                         └──────────────────────────┘
```
- **Engine** = locked, shared code (`platform/`). It is *generic*: it knows how to
  build lines of therapy, time-to-event endpoints, etc., but not the OC specifics.
- **Config** = per-product YAML. It supplies the OC cohorts, code lists, thresholds,
  and variable definitions the engine consumes. **Today this exists only as a
  placeholder scaffold** at `products/oncology/oc/YYYYMM/` (`status: scaffold`,
  reconstructed from the original build script — *not* the governed product); the directory is
  version-stamped (e.g. `202606/`) and flipped to `status: active` once verified
  against the signed-off spec and golden-compared.
- **Spec** = the Excel workbook (`prog_spec/`). The **human** contract the YAML must
  faithfully encode. *Reference-only — the engine never reads it.*

> A useful mental model: **Engine = the printer. Config = the document you send it.
> Spec = the approved manuscript the document is typed from.**

---

## 2. Just-enough ovarian-cancer (OC) clinical primer

You don't need to be a clinician, but these concepts *drive every variable*:

- **Lines of therapy (LOT).** Cancer treatment comes in sequential "lines": **1L** =
  first regimen; when disease comes back, **2L**, then **3L**, … Each line is a set of
  drugs given together. **Maintenance** = a drug continued after a line to delay
  recurrence (in OC, the **PARP inhibitors** niraparib/olaparib/rucaparib, and
  bevacizumab).
- **Surgery.** OC is treated with cytoreductive ("debulking") surgery + chemo.
  **Primary debulking (PDS)** = surgery first; **neoadjuvant chemo (NACT)** = chemo
  first, then "interval" surgery. The variable `NEOADJ_CHEMO` captures this.
- **Platinum sensitivity.** OC chemo is **platinum-based** (carboplatin). How long
  the patient stays in remission after platinum — the **platinum-free interval (PFI)**
  — classifies them:
  - **Refractory** — progresses essentially during/right after platinum (EDM: `PFI <= 90` days)
  - **Resistant** — recurs within ~6 months (EDM: `90 < PFI <= 183` days)
  - **Sensitive** — recurs later (EDM: `PFI > 183` days)
  This decides the next treatment, so it's the **biggest clinical driver** in the spec.
  **PROC = Platinum-Resistant Ovarian Cancer** — a key population for newer drugs.
- **Biomarkers.** **BRCA1/2** mutations and **HRD** (homologous-recombination
  deficiency) predict benefit from PARP inhibitors. **FOLR1** (folate-receptor-α) and
  **GIS** (genomic instability score) gate other therapies. The spec derives a status
  per biomarker (Mutated/Positive/Negative/Unknown).
- **Outcomes / endpoints** (how we measure how patients do):
  | Endpoint | Plain meaning |
  |---|---|
  | **OS** | Overall Survival — time from index to death |
  | **rwPFS** | real-world Progression-Free Survival — time to progression *or* death |
  | **TTNT** | Time To Next Treatment |
  | **TTD** | Time To (treatment) Discontinuation |
  | **TSST** | Time to Second Subsequent Therapy |
  | **RWR** | real-world Response (CR/PR/SD/PD …) |
  | **PFS2** | PFS measured after the *next* line |

---

## 3. The build storyboard 🎬 (how the product gets made)

This is the process we are living through. Each "scene" maps to tabs in the workbook.

```mermaid
flowchart TD
    A[Scene 1: Raw Flatiron feed arrives<br/>Panoramic tables] --> B[Scene 2: Write the SPEC<br/>every cohort + variable + rule]
    B --> C[Scene 3: Record the EDM→Panoramic DELTAS<br/>what changes in the migration]
    C --> D[Scene 4: Human SIGN-OFF gates<br/>Epi / Biostats / Program / Implementation]
    D --> E[Scene 5: Encode spec as YAML CONFIG]
    E --> F[Scene 6: ENGINE + config run → ADS]
    F --> G[Scene 7: VALIDATE<br/>golden-compare + first-feed profiling]
    G --> H[Scene 8: RELEASE the product]
    G -. issues .-> B
```

### Scene 1 — The raw material
Flatiron delivers Panoramic tables (patients, diagnoses, drug episodes, lines of
therapy, biomarkers, progression, mortality, labs…). It is patient-level and
longitudinal, but it is **not** analysis-ready: no cohorts, no endpoints, and no
**EDM-derived** platinum status (`PLAT_SEN`) or **PROC** cohort. (Panoramic *may* ship a
separate **vendor Platinum Status** add-on table — related to, but not identical to, the
EDM derivation, and validated separately.) (*Workbook:* `Data Dictionary` lists the source columns.)

### Scene 2 — Write the spec
For **every** published variable we record: its definition, values/codes, the exact
derivation, source, tie-breaks, missing-data handling, owner, and open questions.
(*Workbook:* tabs **3.Data Prep, 4.StudyPop, 5.Demographics, 6.Clinical
characteristics, 7.Treatment variables, 8.Outcomes, 9.PROC PSOC Strategy** — one row
per variable.)

### Scene 3 — Record the deltas (EDM → Panoramic)
The migration isn't free: Panoramic changes a few things. We classify each item
**UNCHANGED / ADDITIVE / MODIFIED / DEPRECATED / PENDING** and document the three big
deltas. (*Workbook:* **2.CHANGES** is the exec summary; **10.Deltas** carries the detail.)
The three headline deltas:
1. **Treatment setting (`LineSetting`)** — Panoramic adds an explicit
   Neoadjuvant/Adjuvant/Advanced/Off-Systemic-Therapy field and can *split* lines,
   which can ripple into line numbering and the index date.
2. **Platinum status** — Panoramic ships a per-line Platinum Status table with
   different thresholds (Panoramic: Refractory `PFI<=91` / Resistant `92-183` /
   Sensitive `>=184`; vs EDM: `<=90` / `90<PFI<=183` / `>183`) — and a different
   grain/window besides. **Working direction:** build to the **EDM-derived**
   definition as the PROC source of truth (it fits the core tables + matches the
   prior analysis); the Panoramic table is an **Add-On cross-check** to discuss with
   Biostats — Biostats/Program ratification pending (D1).
3. **Mortality** — a new `Mortality_V2` death table (different death dates can shift OS).

### Scene 4 — Human sign-off (the gates)
Nothing becomes "approved" until the right human signs it. Different rules go to
different owners (see §5). (*Workbook:* **11.Review Decisions** pre-fills every open
decision with a recommendation + owner; **16.Approval Gate** tracks readiness.)

### Scene 5 — Encode the spec as YAML config
Once a section is signed off, its rules are written as **per-product YAML** (config +
variables + codelists) — the machine-readable version of the spec. *Today the only YAML
present is a non-governed **placeholder scaffold** at `products/oncology/oc/YYYYMM/`
(`status: scaffold`, reconstructed from the original build script). Turning that into the verified,
spec-aligned, version-stamped package (e.g. `202606/`, `status: active`) is the work
gated behind sign-off.*

### Scene 6 — Engine + config run → ADS
The **locked engine** reads the **config** and the **Flatiron feed**, and produces the
**analytic dataset (ADS)** — cohorts assembled, variables derived, endpoints computed.

### Scene 7 — Validate
- **Golden-compare**: does the new output match the trusted existing EDM output where
  it *should*? (Differences are expected only where a delta applies.)
- **First-feed profiling**: run sanity checks on the actual delivered Panoramic data
  (missingness, value ranges, table/column mapping). (*Workbook:* **15.Worked Examples**,
  plus the **Cross-Validation** / **Data Profiling Checklist** appendix.)

### Scene 8 — Release
When gates A (draft-YAML) and B (activation) are clear, the product is released and
studies consume the ADS.

---

## 4. The data storyboard 🧬 (follow one patient through the engine)

To make it concrete, follow a single (fictional) patient and watch a few variables
get derived — this is what the engine does, row by row.

> **Patient P.** Diagnosed with epithelial ovarian cancer 2019-03. Surgery, then
> carboplatin+paclitaxel (1L) with niraparib maintenance. Recurrence 2020-06 →
> 2L platinum. Progression 2021-02. Last clinic note 2021-09. Death recorded 2021-10
> (month granularity only).

1. **Eligibility / cohort** *(4.StudyPop)* — **assuming the population filters (female,
   epithelial OC/FT/PP, diagnosis ≥2011, age ≥18 — these are still *source-pending* in
   the spec) are approved**, P enters the study population. P contributes to the
   **Overall** cohort and the **2L** cohort. (If P had reached platinum resistance, P
   would also anchor into the **2L+ PROC** cohort at first resistance.)
2. **Index date** *(3.Data Prep)* — chosen per cohort: diagnosis date for Overall,
   line-start for line cohorts. Everything else is measured *relative to index*.
3. **Lines of therapy** *(7.Treatment)* — the engine assembles drug episodes into
   lines (28-day windows, gap rules), tags niraparib as **maintenance**, and (under
   Panoramic) assigns a **LineSetting**.
4. **Platinum sensitivity** *(9.PROC)* — PFI = time from last platinum to the
   qualifying progression; compared against the day thresholds → Sensitive/Resistant/
   Refractory. This determines PROC membership.
5. **Biomarkers** *(6.Clinical)* — P's BRCA/HRD results are selected closest to index;
   same-day ties resolved by the documented rules.
6. **Outcomes** *(8.Outcomes)* —
   - **rwPFS**: progression 2021-02 is the event — progression is prioritized over death
     (even if a death date were earlier), because progression dates are day-level and
     death dates may be month-imputed.
   - **OS**: death 2021-10; only the month is known, so — **if the 15th/midpoint
     convention is ratified (the EDM parity rule is still a pending decision)** — the day
     is imputed → 2021-10-15.
   - **TTNT/TTD/TSST/RWR** computed from the line and response history.
7. **Output row** — P becomes one (or several, per cohort) rows in the ADS, with all
   variables filled and follow-up clocks set.

That chain — *eligibility → index → lines → platinum → biomarkers → outcomes* — is the
spine of the whole spec.

---

## 5. Who signs off what (owners & gates)

Not everything is a "biostatistics" decision — the spec routes each open item to the
right owner so the biostats meeting only sees true biostats calls.

The workbook uses four **reviewer-facing** owner labels (internal roles are folded into these):

| Owner | What they decide (folded-in internal roles) |
|---|---|
| **Epi** | Source / epidemiology review — *confirm the read* (the rule is clearly stated; just verify it against the source). |
| **Biostats** | Genuine analytic judgement (a real choice or a conflict). |
| **Program** | Scope + governance — what's in/out for this release, and which Flatiron add-ons we subscribe to. *(was Product Owner + Commercial)* |
| **Implementation** | Engineering follow-up — feed mapping, engine/structure work (e.g. line-splitting impact). *(was Data Engineer + Architecture)* |

**Review gates:** Gate 1 (baseline reconstruction) → Gate 2 (Panoramic source) →
Gate 3 (business decisions) → Gate 4 (first-feed profiling). And the **16.Approval Gate**
tab's **A** (stable enough to draft YAML) → **B** (data + sign-off complete → release).

---

## 6. How to read the workbook (tab map)

Open `reference/PROG_SPEC_RWDP_Ovarian_PANO_202606.xlsx`, start at **1.Cover**.

The workbook is **EDM-first**: the section tabs look like the familiar EDM spec, with the
Panoramic migration detail moved to the right and to dedicated tabs.

| Tab(s) | What it gives you |
|---|---|
| **1.Cover** | Purpose, status, a "for EDM reviewers" reading guide, the tab map, authority hierarchy |
| **2.CHANGES** | Executive summary of the EDM→Panoramic changes (6 high-level rows) |
| **3.Data Prep … 9.PROC PSOC Strategy** | The EDM baseline — one variable per row; **EDM columns first** (Variable/Label/Values/Definition/Source), the Panoramic overlay (Origin/delta/Evidence/Status/Owner/decision) on the right |
| **10.Deltas** | The EDM→Panoramic differences in one place (summary + treatment setting + platinum/PROC + mortality + additive/mapping notes + by-cohort impact) |
| **11.Review Decisions** | Every open decision, pre-filled with a recommendation + owner |
| **12.Epi Source Check** | The confirm-the-read rows re-read vs the source scans (122 confirmed / 4 corrected / 0 unresolved) |
| **13.New Panoramic Fields** | New Panoramic fields not in the current contract (INCLUDE/DEFER) |
| **14.Source Register · 15.Worked Examples** | What each rule is evidenced by + sign-off status; worked boundary examples |
| **16.Approval Gate · 17.Plan & Validation** | The two gates (draft-YAML / activation); the phased plan |
| **Appendix** (Data Dictionary · Cross-Validation · Data Profiling Checklist · Engine Assessment · OC Backlog) | Program/Implementation technical detail — **not** part of the Epi/Biostats review path |

**Reading aids in the workbook:** long cells are shown as **bullets**; the big tables
have **frozen headers + filters** (filter by Owner/Status/Basis/Change-type). Every
rule names the **context** it comes from — never a filename or page:

> **Source-context labels:** `Prior spec` (the legacy EDM program spec) ·
> `Flatiron data dictionary` (column lists / value sets) · `Flatiron LOT rules`
> (line-of-therapy / LineSetting construction) · `Flatiron Panoramic doc`
> (ovarian Panoramic documentation) · `RWDP methodology` · `Clinical dataset`
> (the delivered feed / golden output).

**Status language:** `[verify]` / `first-pass` = sign-off pending (not yet confirmed
against the source); `PENDING` = a decision not yet made; `Documented`/`Inferred` in a
*Basis* column = whether a recommendation is backed by a source doc or is our reasoning.

---

## 7. Where the OC product is *right now*

- The workbook is a **draft review package** — **not approved, not YAML-ready**.
- The EDM baseline is a **first-pass reconstruction** of the legacy spec (sign-off pending).
- The Panoramic reads are drafted from the Flatiron documentation (sign-off pending).
- Remaining work is **decisions and sign-off**, not hidden construction:
  death-imputation parity, PROC membership, cohort numbering (1–9 vs 1–11), a few
  operator confirmations (TSST, TTD +1), RWR semantics, and first-feed profiling.
- **The only YAML present is a non-governed `YYYYMM` scaffold** (`status: scaffold`,
  reconstructed from the original build script). The verified, spec-aligned, version-stamped package waits
  for the Approval Gate — it has *not* been built from the approved spec yet.

---

## 8. Mini-glossary

| Term | Meaning |
|---|---|
| **RWD / RWDP** | Real-World Data / …Product (governed analytic dataset) |
| **ADS** | Analytic Data Set — the delivered, analysis-ready output |
| **EDM** | Enhanced Data Mart — the legacy ovarian data model (the baseline) |
| **Panoramic** | Flatiron's newer data delivery (migration target) |
| **Engine** | Locked shared PySpark code (`platform/`) that derives the data |
| **Config / YAML** | Per-product machine-readable spec — currently the `YYYYMM/` placeholder scaffold (`status: scaffold`); version-stamped (e.g. `202606/`) and set `active` when approved |
| **Spec** | The human-authoritative Excel workbook in `prog_spec/` |
| **LOT** | Line Of Therapy (1L, 2L, …); **LineSetting** = Neoadj/Adj/Advanced/OST |
| **OST** | Off Systemic Therapy (a treatment-gap line; has a setting but no line number) |
| **PFI** | Platinum-Free Interval — drives platinum sensitivity |
| **PROC** | Platinum-Resistant Ovarian Cancer (a cohort) |
| **OS / rwPFS / TTNT / TTD / TSST / RWR / PFS2** | The outcome endpoints (see §2) |
| **BRCA / HRD / GIS / FOLR1** | Ovarian biomarkers driving therapy eligibility |
| **PDS / NACT / NEOADJ** | Primary debulking surgery / neoadjuvant chemo |
| **Index date** | The anchor each patient's timeline is measured from |
| **Golden-compare** | Validating new output against the trusted existing output |
| **Gate (1–4, A/B)** | The review/approval checkpoints |
| **Epi / Biostats / Program / Implementation** | Decision owners (reviewer-facing, see §5) |

---

*This is a learning/reference aid, not part of the governed product. The authoritative
spec is the Excel workbook under `products/oncology/oc/reference/`.*
