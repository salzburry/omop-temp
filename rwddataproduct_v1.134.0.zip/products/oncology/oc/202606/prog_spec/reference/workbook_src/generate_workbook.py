#!/usr/bin/env python3
"""OC 202606 — Panoramic spec workbook, v9 (consistency pass; no new variables).

Fixes the v8 integrity findings:
- ONE controlled status model with SEPARATE columns: Role / Scaf / Evid / Impl (stop conflating Scaf+Evidence).
- 'Confirmed' is NOT used for low-confidence reads. Evid hierarchy: Approved > Visual > Transcribed > Confl > R-only > Pend.
- ID3MOSFU / VIS120 / surgery / NEOADJ are Conflicting consistently across ALL tabs (no cross-tab drift).
- LineSetting corrections: Advanced split = last therapy episode <14d AFTER recurrence; Off-Systemic-Therapy has
  LineSetting but NO LineNumber (does not advance lines).
- Delta-impact matrix rebuilt BY COHORT (index-relative outputs are NOT exact-parity for split/PROC histories).
- Engine Assessment reclassified to actual engine capability (much LOT/TTE/lab/rwPFS work is Config, not Engine).
- Source Evidence: Reviewer/Date/Approval columns + tighter page anchors. Role splits Published vs Intermediate.
"""
import sys, os, json, re
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "PROG_SPEC_RWDP_Ovarian_PANO_202606.xlsx")
NAVY, BLUE, WHITE, GREY = "1F3864", "2E5496", "FFFFFF", "F2F2F2"
FILL = {  # controlled value sets, colour-coded
    # Scaf (current coverage)
    "Yes": "C6E0B4", "Partial": "FFF2CC", "No": "F8CBAD",
    # Evid (evidence confidence) — NOTE: no 'Confirmed' for transcribed reads
    "Approved": "A9D08E", "Visual": "C6E0B4", "Transcribed": "FFF2CC", "Confl": "F8CBAD", "R-only": "FCE4D6", "Pend": "D9D9D9",
    # Appr
    "Decide": "FCE4D6", "OOS": "D0CECE",
    # Impl
    "Current": "E2EFDA", "Config": "DDEBF7", "Engine": "E4DFEC", "DataVal": "FFF2CC",
    # Role  (NB: 'Add' — NOT '+Add' — the leading '+' tripped the formula guard)
    "Pub": "DDEBF7", "Intrm": "EDEDED", "Src": "F2F2F2", "QC": "FCE4D6", "Const": "EDEDED", "Add": "E4DFEC",
    # Change-type (2.CHANGES) — classification of each item vs the approved EDM baseline
    "UNCHANGED": "E2EFDA", "ADDITIVE": "DDEBF7", "MODIFIED": "FFF2CC", "DEPRECATED": "F8CBAD", "PENDING": "D9D9D9",
    "DELTA": "FFF2CC", "NEW": "DDEBF7", "Standard": "E2EFDA", "Add-On": "FFF2CC", "Custom": "F8CBAD",
    "INCLUDE": "C6E0B4", "Consider": "FFF2CC", "DEFER": "F8CBAD",
    # Basis of a recommendation: Documented (green) / my inference (orange, scrutinize) / mixed / business call
    "Documented": "C6E0B4", "PDF": "C6E0B4", "Inferred": "F8CBAD", "Mixed": "FFF2CC", "Business": "DDEBF7",
    # Source context (what each rule is referenced from, now that documents are not cited)
    "Prior spec": "DDEBF7", "EDM data dictionary (received)": "E2EFDA", "Flatiron Panoramic doc": "E4DFEC",
    "Flatiron LOT rules": "DAEEF3", "RWDP methodology": "FCE4D6", "Clinical dataset": "FFF2CC",
    # Origin (is the variable in the prior EDM spec, an additive Panoramic field, or a modified EDM rule?)
    "EDM baseline": "F2F2F2", "ADDITIVE (not in prior spec)": "DDEBF7", "MODIFIED (vs prior spec)": "FFF2CC",
    # Approval Gate status
    "Done": "A9D08E", "Pending": "D9D9D9",
    "ACTION": "FFC000",
}
title_font = Font(bold=True, size=14, color=WHITE)
sub_font = Font(italic=True, size=10, color="404040")
section_font = Font(bold=True, size=11, color=WHITE)
header_font = Font(bold=True, size=9, color=WHITE)
cell_font = Font(size=9)
note_font = Font(italic=True, size=9, color="595959")
title_fill = PatternFill("solid", fgColor=NAVY)
section_fill = PatternFill("solid", fgColor=BLUE)
header_fill = PatternFill("solid", fgColor=BLUE)
grey_fill = PatternFill("solid", fgColor=GREY)
thin = Side(style="thin", color="BFBFBF")
border = Border(left=thin, right=thin, top=thin, bottom=thin)
wrap = Alignment(wrap_text=True, vertical="top")


def _safe(v):
    # Guard against Excel parsing a cell as a formula. NB: use tuple membership, NOT substring —
    # ""[:1] == "" and "" in "=+@" is True, which would stamp a stray zero-width space on every blank cell.
    return ("​" + v) if isinstance(v, str) and v[:1] in ("=", "+", "@") else v


# Production de-reference: this workbook is the governed reference artifact, so it must NOT cite source
# DOCUMENTS (PDF filenames / page numbers / scans). Every rule instead names the CONTEXT it comes from:
#   Prior spec · Flatiron data dictionary · Flatiron LOT rules · Flatiron Panoramic doc · RWDP methodology · Clinical dataset
# _deref() rewrites file tokens + page anchors + scan/image language at generate time.
_DEREF = [
    # --- image / transcription / visual language (do FIRST, before file tokens) ---
    (r"(?i)\bimage-only KC pages?\b", "the Flatiron documentation"),
    (r"(?i)\bimage-only PDFs?\b", "source documents"),
    (r"(?i)\bimage-only\b", "source"),
    (r"(?i)\bvision-read\b", "transcribed"),
    (r"(?i)\bvisually readable\b", "legible"),
    (r"(?i)\bvisually-validated\b", "source-validated"),
    (r"(?i)\bvisually signed[- ]off\b", "signed off"),
    (r"(?i)\bvisual[- ]sign-?off\b", "sign-off"),
    (r"(?i)\bvisually\b", "on review"),
    (r"(?i)\bscreenshots?\b", ""),
    # --- 'scan' of the source documents -> 'source' (de-ref intent: don't reveal the medium).
    #     Targeted (NOT a blanket \bscans?\b) so a future clinical 'CT/PET scan' is never clobbered. ---
    (r"(?i)\bsource scans?\b", "source"),                                   # 'vs source scan' -> 'vs source'
    (r"(?i)\bprior[- ]spec scans?\b", "prior spec"),
    (r"(?i)\bprogram[- ]spec scans?\b", "program spec"),
    (r"(?i)\bsibling scans?\b", "sibling sources"),
    (r"(?i)\b(studypop|data[- ]prep|clinical[- ]characteristics|demo|outcomes|treatment) scans?\b", r"\1 source"),
    (r"(?i)\bthe scans?\b", "the source"),
    (r"(?i)\bKC pages?\b", "documentation"),
    (r"(?i)\bKC articles?\b", "documentation"),
    (r"(?i)\bKC\b", "documentation"),
    (r"(?i)\bdocumentation image\b", "documentation"),
    (r"(?i)\bagainst image\b", ""),
    (r"(?i)\bimage\b", "source"),
    (r"(?i)\bOCR-noisy\b", "draft-transcription"),
    # --- PDF-prefixed compounds (before bare PDF) ---
    (r"(?i)\bPDF Evidence Register\b", "Source Register"),
    (r"(?i)\bPDF[- ]primary\b", "source-primary"),
    (r"(?i)\bPDF-defined\b", "source-defined"),
    (r"(?i)\bPDF-proven\b", "documented"),
    (r"(?i)\bPDF reading\b", "source reading"),
    (r"(?i)\bPDF read\b", "source read"),
    (r"(?i)\bPDF page\b", "source"),
    (r"(?i)\bsource PDFs?\b", "source documents"),
    (r"(?i)\bthe PDFs?\b", "the source documents"),
    (r"(?i)\bPDFs\b", "documents"),
    # --- counts / page totals ---
    (r"(?i)\b\d+\s*pp\b\.?", ""),               # "228 pp", "63 pp."
    # --- multi-word GSK prior-spec files (space + underscore forms) ---
    (r"(?i)\bnh[ _]study[ _]vars(\.pdf)?", "Prior spec"),
    (r"(?i)\bnh vars\b", "Prior spec"),
    (r"(?i)\badhic[ _]bio[ _]?marker(\.pdf)?", "Prior spec"),
    (r"(?i)\bplatinum sensitivity\.pdf", "Prior spec"),
    (r"(?i)\brwdp methodology( old)?(\.pdf)?", "RWDP methodology"),
    # --- long unambiguous GSK prior-spec file tokens ---
    (r"(?i)\bclincharsoc(\.pdf)?", "Prior spec"),
    (r"(?i)\btreatcharoc(\.pdf)?", "Prior spec"),
    (r"(?i)\boutcomesoc(\.pdf)?", "Prior spec"),
    (r"(?i)\bstudypopoc(\.pdf)?", "Prior spec"),
    (r"(?i)\bdataprepoc(\.pdf)?", "Prior spec"),
    (r"(?i)\bdemooc(\.pdf)?", "Prior spec"),
    (r"(?i)\bprocpsopstratoc(\.pdf)?", "Prior spec"),
    (r"(?i)\bprocpsop(\.pdf)?", "Prior spec"),
    (r"(?i)\bprocps\b", "Prior spec"),
    (r"(?i)\bdeath\.pdf", "Prior spec"),
    # --- Flatiron documents ---
    # flatiromdata1 spans BOTH the LOT Rules section (LineSetting/splitting/maintenance/OST/PARP,
    # ~p.62-68; oral-span ~p.76-83) AND generic data-dictionary content (core table, labs, ECOG,
    # demographics). Label the LOT-rules pages precisely; everything else is the data dictionary.
    (r"(?i)\bflatiromdata1(\.pdf)?\s*p\.?\s*6[248](\s*[-/]\s*6[08])?\b", "Flatiron LOT rules"),  # p.62-68 / p.64 / p.64-68 / p.68
    (r"(?i)\bflatiromdata1(\.pdf)?\s*p\.?\s*76\s*-\s*83\b", "Flatiron LOT rules"),               # oral-span rules
    (r"(?i)\bflatiromdata1(\.pdf)?", "Flatiron Panoramic doc"),
    (r"(?i)\bflatiromfatadivt(\.pdf)?", "EDM data dictionary (received)"),
    # The only data dictionary in hand describes the RECEIVED EDM data (not the Panoramic feed) - relabel
    # every 'data dictionary' citation so it is not read as Panoramic confirmation (user correction).
    (r"(?i)\bFlatiron data dictionary\b", "EDM data dictionary (received)"),
    (r"(?i)\bdata_dictionary\b", "EDM data dictionary (received)"),
    (r"(?i)\bflatirompt2(\.pdf)?", "Flatiron Panoramic doc"),
    # --- GSK short-forms that carry a page ref -> Prior spec (consume the page) ---
    (r"(?i)\b(clinical|clinchar|outcomes|studypop|dataprep|demo|treatchar|death)\s+p\.?\s*\d+(\s*[-,/]\s*\d+)*", "Prior spec"),
    # --- strip a leading preposition together with the page ref (avoids dangling "at"/"on"/"per") ---
    (r"(?i)\s+(?:at|on|in|per|see|from|of)\s+pp?\.\s*\d+(\s*[-,/]\s*\d+)*", ""),
    # --- strip any remaining page / section anchors (do NOT eat surrounding parens) ---
    (r"(?i)\bpp?\.\s*\d+(\s*[-,/]\s*\d+)*", ""),
    (r"(?i)\bp\d+(\s*[-,/]\s*\d+)*\b", ""),       # "p64", "p50-52", "p64/68" (no dot)
    (r"(?i)\bsec\.?\s*\d+", ""),
    (r"(?i)\bpages?\s+\d+(\s*[-,/]\s*\d+)*", ""),
    # --- "page" used to mean "the source page" (no scans in production) ---
    (r"(?i)\bpage-by-page sign-?off\b", "section-by-section sign-off"),
    (r"(?i)\bpage-by-page\b", "section-by-section"),
    (r"(?i)\bpage[- ]anchored\b", "source-referenced"),
    (r"(?i)\bpage sign-?off\b", "sign-off"),
    (r"(?i)\bpage anchors?\b", "source reference"),
    (r"(?i)\bvendor page\b", "vendor documentation"),
    (r"(?i)\bFlatiron page\b", "Flatiron documentation"),
    (r"(?i)\bexact page\b", "exact source"),
    (r"(?i)\bGSK[- ]page\b", "prior spec"),
    (r"(?i)\bGSK[- ]source\b", "prior-spec source"),
    (r"(?i)\bthe page is clear\b", "the source is clear"),
    (r"(?i)\bon the page\b", "in the source"),
    (r"(?i)\bthe page\b", "the source"),
    # --- external-document references (production: nothing lives outside this workbook) ---
    (r"(?i)\bTeams program-spec Excel\b", "approved EDM program spec"),
    (r"(?i)\bTeams Excel\b", "approved EDM program spec"),
    (r"(?i)\bunder upload/\b", "with the program"),
    (r"(?i)\bupload/", ""),
    # --- transcription artifacts (production: state uncertainty, not the scan) ---
    (r"(?i)\bobscured by (a )?red banner\b", "masked in the source"),
    (r"(?i)\bblue-banded\b", ""),
    (r"(?i)\bmis-rendered\b", "ambiguous"),
    (r"(?i)\bclipped at (the )?right page edge\b", "truncated in the source"),
    (r"(?i)\bclipped at (a )?page split\b", "truncated in the source"),
    (r"(?i)\b(spans )?clipped page split\b", "truncated in the source"),
    (r"(?i)\bpage split\b", "source break"),
    (r"(?i)\bpage edge\b", "source margin"),
    (r"(?i)\bspelled out on this page\b", "spelled out in the source"),
    (r"(?i)\bon this page\b", "in the source"),
    (r"(?i)\bon a source page\b", "in a source document"),
    (r"(?i)\bsource page\b", "source document"),
    (r"(?i)\billegible\b", "to confirm"),
    (r"(?i)\bin md\b", "in the source"),
    (r"(?i)\bin the source PDFs\b", "in the source"),
    # --- Basis / evidence chips and parenthetical (PDF) ---
    (r"(?i)\bOCR\b", "Prior spec"),
    (r"\(PDF\)", "(documented)"),
    (r"(?i)\bbacked by a source page\b", "backed by a source document"),
    (r"(?i)\bagainst PDF\b", "against the source"),
    (r"^PDF$", "Documented"),                     # exact Basis chip cell -> Documented
    (r"(?i)\bPDF\b", "source"),                   # any remaining inline 'PDF' -> source (e.g. 'the visible PDF')
]
_DEREF = [(re.compile(p), r) for p, r in _DEREF]


def _deref(s):
    if not isinstance(s, str):
        return s
    for rx, rep in _DEREF:
        s = rx.sub(rep, s)
    # tidy artifacts left by removals
    s = re.sub(r"\(\s*\)", "", s)
    s = re.sub(r"\s{2,}", " ", s)
    for a, b in (("( ", "("), (" )", ")"), (" ,", ","), (" ;", ";"), (" :", ":"),
                 (",,", ","), ("(,", "("), (",)", ")")):
        s = s.replace(a, b)
    # collapse "Prior spec / Prior spec", "Prior spec, Prior spec", "X vs X"
    s = re.sub(r"\b(Prior spec|Flatiron data dictionary|Flatiron Panoramic doc|RWDP methodology|Clinical dataset)"
               r"(\s*(?:[/,;]|vs|and)\s*\1\b)+", r"\1", s)
    s = re.sub(r"\s+([.;,])", r"\1", s)
    s = re.sub(r"[\s;,/]+$", "", s)   # trailing separators left by removals
    return s.strip()


def _norm(v):
    # full text normalization for a cell value: markdown retarget -> de-reference
    return _deref(_clean(v)) if isinstance(v, str) else v


# Sentence boundary split that is SAFE for formulas/decimals/abbreviations:
# only splits ". " when preceded by a lowercase/close-bracket/%/' and followed by an
# uppercase/open-bracket. So "30.4375", "PFI = a - b", "e.g. foo" are never split.
_SENT = re.compile(r"(?<=[a-z)\]'%])\.\s+(?=[A-Z(\[])")


def _bullets(s):
    # Render a long, multi-clause cell as in-cell bullets (newline-separated) so it
    # reads as a list instead of a wall of text. Splits on '; ' and safe sentence
    # boundaries only — never on math operators, so formulas stay intact.
    if not isinstance(s, str) or len(s) < 10 or "\n" in s:
        return s
    segs = []
    for part in s.split("; "):
        segs.extend(x.strip() for x in _SENT.split(part))
    segs = [x for x in segs if x]
    if len(segs) < 2:
        return s
    return "\n".join("• " + x for x in segs)


def render(ws, blocks, widths, freeze_main=True):
    ncols = len(widths)
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    r = 1
    tables = []  # (header_row, first_data_row, last_data_row)
    for b in blocks:
        k = b[0]
        if k == "title":
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols)
            c = ws.cell(r, 1, _norm(b[1])); c.font = title_font; c.fill = title_fill; ws.row_dimensions[r].height = 22; r += 1
        elif k == "sub":
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols)
            txt = _norm(b[1])
            c = ws.cell(r, 1, _safe(txt)); c.font = sub_font; c.alignment = wrap
            ws.row_dimensions[r].height = max(26, 12 * (1 + len(txt) // 120)); r += 1
        elif k == "gap":
            r += 1
        elif k == "section":
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols)
            c = ws.cell(r, 1, _norm(b[1])); c.font = section_font; c.fill = section_fill; r += 1
        elif k == "note":
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols)
            txt = _norm(b[1])
            c = ws.cell(r, 1, _safe(txt)); c.font = note_font; c.alignment = wrap
            ws.row_dimensions[r].height = max(14, 12 * (1 + len(txt) // 130)); r += 1
        elif k == "table":
            headers, rows = b[1], b[2]
            hdr_row = r
            for j, h in enumerate(headers, start=1):
                c = ws.cell(r, j, _norm(h)); c.font = header_font; c.fill = header_fill; c.border = border; c.alignment = wrap
            r += 1
            data_start = r
            for row in rows:
                for j, val in enumerate(row, start=1):
                    dv = _norm(val)
                    c = ws.cell(r, j, _safe(_bullets(dv))); c.font = cell_font; c.border = border; c.alignment = wrap
                    if isinstance(dv, str) and dv in FILL:
                        c.fill = PatternFill("solid", fgColor=FILL[dv])
                    elif r % 2 == 0:
                        c.fill = grey_fill
                r += 1
            tables.append((hdr_row, data_start, r - 1, [str(h).lower() for h in headers]))
    # Freeze header + enable filter/sort on the main table so long sheets stay navigable.
    # Excel allows ONE autofilter per sheet, so on multi-table sheets target the
    # decision/variable table (Owner/Basis first, then Status/Change/Route) rather than
    # whichever block is merely longest.
    if freeze_main and tables:
        ws.freeze_panes = f"A{tables[0][0] + 1}"
        def tier(t):
            hs = " ".join(t[3])
            if "owner" in hs and "basis" in hs: return 0
            if "owner" in hs or "basis" in hs: return 1
            if any(d in hs for d in ("status", "change", "route", "sign-off", "decide")): return 2
            return 3
        best_tier = min(tier(t) for t in tables)
        cands = [t for t in tables if tier(t) == best_tier]
        big = max(cands, key=lambda t: t[2] - t[1])
        if big[2] >= big[1]:
            ws.auto_filter.ref = f"A{big[0]}:{get_column_letter(ncols)}{big[2]}"
    else:
        ws.freeze_panes = "A4"


# Inventory model: Var | Derivation | Codes | Role | Scaf | Evid | Impl
# ===== rich per-variable section tabs (loaded from the per-section JSON extracts) =====
# EDM-FIRST layout: the left 5 columns mirror the familiar EDM program-spec (Variable / Label / Values /
# Definition / Source); the right 6 are the Panoramic migration overlay (Origin / delta / Evidence / Status /
# Owner / Open decision). A reviewer who knows the EDM sheet reads left-to-right and can ignore the overlay.
RH = ["Variable", "Label", "Values / codes", "Definition / EDM derivation", "Source & selection",
      "Origin", "Panoramic delta", "Evidence", "Status", "Owner", "Open decision"]
RW = [16, 16, 15, 44, 22, 19, 22, 13, 15, 14, 22]


_DATA = None
def load_rows(name):
    """Section rows from the combined rows.json (keyed by section). Falls back to a
    per-section rows_<name>.json for back-compat. utf-8 is explicit so it runs on
    Windows too (the default cp1252 codec would choke on the non-ASCII chars)."""
    global _DATA
    if _DATA is None:
        combined = os.path.join(HERE, "rows.json")
        if os.path.exists(combined):
            with open(combined, encoding="utf-8") as fh:
                _DATA = json.load(fh)
        else:
            _DATA = {}
    if name in _DATA:
        return _DATA[name]
    p = os.path.join(HERE, f"rows_{name}.json")     # legacy fallback
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8") as fh:
        return json.load(fh)


def _src_sel(r):
    s = (r.get("source") or "").strip()
    sel = (r.get("selection") or "").strip()
    return f"{s}  |  {sel}" if (s and sel) else (s or sel)


# Retarget references to the (now-removed) intermediate markdown onto the kept source PDFs / in-workbook tabs.
_MD_FIX = [
    ("treatment_setting.md", "Panoramic Delta tab"), ("cross_validation.md", "Cross-Validation tab"),
    ("additive_candidates.md", "Additive Candidates tab"), ("data_dictionary.md", "Data Dictionary tab"),
    ("biostats_decision_pack.md", "Biostats Decision Pack tab"),
    ("platinum_sensitivity.md", "platinum sensitivity.pdf"), ("platinum.md", "Panoramic Delta tab"),
    ("procpsopstratoc.md", "procpsopstratoc.pdf"), ("studypopoc.md", "studypopoc.pdf"),
    ("dataprepoc.md", "dataprepoc.pdf"), ("demooc.md", "demooc.pdf"), ("clincharsoc.md", "clincharsoc.pdf"),
    ("treatcharoc.md", "treatcharoc.pdf"), ("outcomesoc.md", "outcomesoc.pdf"), ("death.md", "death.pdf"),
    ("adhic_bio_marker.md", "adhic bio marker.pdf"), ("nh_study_vars.md", "nh study vars.pdf"),
    ("per task scope", "per the program scope"), ("the task scope", "the program scope"),
    ("task scope", "program scope"), ("(md var ", "(source var "),
    ("the provided markdown", "the source PDFs"), ("provided markdown", "the source PDFs"),
    ("studypopoc/procpsopstratoc markdown", "the studypopoc/procpsopstratoc source PDFs"), ("markdown", "the source PDFs"),
]


def _clean(s):
    if not isinstance(s, str):
        return s
    for a, b in _MD_FIX:
        s = s.replace(a, b)
    return s


def rh_rows(rows):
    # EDM-first column order: Variable, Label, Values, Definition, Source | Origin, Panoramic delta,
    # Evidence, Status, Owner, Open decision. (Owner codes are relabelled reviewer-facing post-build.)
    return [[_clean(r.get("var", "")), _clean(r.get("label", "")), _clean(r.get("values", "")),
             _clean(r.get("definition", "")), _clean(_src_sel(r)),
             _clean(r.get("origin", "EDM baseline")), _clean(r.get("delta", "")),
             _clean(r.get("evidence", "")), _clean(r.get("status", "")), _clean(r.get("owner", "")),
             _clean(r.get("decision", ""))] for r in (rows or [])]


def section_tab(ws, title, sub, rows):
    blocks = [("title", title), ("sub", sub), ("gap",)]
    if not rows:
        blocks.append(("note", "[rows JSON not found at generate time — re-run the generator after the extract completes]"))
        render(ws, blocks, RW)
        return
    table = rh_rows(rows)
    blocks.append(("note", f"{len(table)} variables — one row each (parametric families fully exploded). "
                           "READ LEFT-TO-RIGHT: the first 5 columns are the familiar EDM spec (Variable / Label / Values / "
                           "Definition / Source); the columns after 'Source & selection' are the Panoramic migration overlay. "
                           "Origin: 'EDM baseline' = in the prior EDM spec · 'ADDITIVE (not in prior spec)' = new Panoramic field · "
                           "'MODIFIED (vs prior spec)' = an EDM rule whose derivation changes. "
                           "Owner: Epi = confirm-the-read · Biostats = stats decision · Program = scope/governance · Implementation = eng follow-up. "
                           "'[verify]' = sign-off pending; 'conflict' = internal EDM conflict to reconcile."))
    blocks.append(("table", RH, table))
    render(ws, blocks, RW)


IH = ["RWDAP Var", "Definition / derivation", "Values / codes"]
IW = [24, 80, 24]
wb = Workbook()

# ===== 1.Cover =====
ws = wb.active; ws.title = "1.Cover"
render(ws, [
    ("title", "Ovarian (OC) RWDP 202606 — DRAFT review spec (EDM -> Panoramic) — NOT approved / NOT YAML-ready  [v0.x]"),
    ("sub", "EDM-FIRST & SELF-CONTAINED. Tabs 3-9 are the EDM spec you know — read the LEFT columns (Variable / Label / Values / "
            "Definition / Source); the columns to the RIGHT are the Panoramic migration overlay (Origin / Panoramic delta / Evidence / "
            "Status / Owner / Open decision). Tabs after 9 are review-support tabs. HONEST STATUS: the EDM baseline is a FIRST-PASS "
            "transcription of the prior EDM program spec (≈{{NVERIFY}} [verify], sign-off pending), NOT yet approved; Panoramic reads are "
            "from the Flatiron documentation pending sign-off. NOT a programmer-complete contract and NOT YAML-ready (16.Approval Gate)."),
    ("gap",),
    ("section", "For EDM reviewers — how to read this workbook"),
    ("note", "Tabs 3-9 follow the familiar EDM program-spec structure. Read the left-side columns first: Variable, Label, Values/Codes, "
             "Definition/Derivation, Source/Selection. The columns to the right are the Panoramic migration overlay: Origin, Panoramic "
             "delta, Evidence, Status, Owner, Open decision. Tabs after 9 are review-support tabs; they do NOT replace the section tabs. "
             "Owners are reviewer-facing: Epi = confirm-the-read · Biostats = stats decisions · Program = scope/governance · "
             "Implementation = engineering follow-up (a small program/implementation appendix sits at the very end)."),
    ("gap",),
    ("section", "Where to find each part of the spec — ALL IN THIS WORKBOOK (no external files needed)"),
    ("table", ["Part of the spec", "Tab(s)", "What it is"], [
        ["EDM baseline (the BASE)", "3.Data Prep · 4.StudyPop · 5.Demographics · 6.Clinical characteristics · 7.Treatment variables · 8.Outcomes · 9.PROC PSOC Strategy", "the EDM program spec (first-pass transcription), one variable per row — EDM columns left, Panoramic overlay right"],
        ["Panoramic deltas", "10.Deltas (+ delta rows inside 7.Treatment / 9.PROC)", "treatment setting + platinum + mortality in full + the 4-category taxonomy + by-cohort impact"],
        ["Open decisions (sign-off pre-read)", "11.Review Decisions", "every open decision pre-filled (owner + recommendation), sorted by gate"],
        ["Source-read confirmation", "12.Epi Source Check", "the confirm-the-read rows re-checked vs the source (122 confirmed, 4 corrected)"],
        ["New (additive) Panoramic fields", "13.New Panoramic Fields", "optional Panoramic elements NOT in the current EDM contract (INCLUDE/DEFER)"],
        ["Source + sign-off / worked examples", "14.Source Register · 15.Worked Examples", "each section's source + sign-off status; worked boundary examples"],
        ["Governance / plan", "16.Approval Gate · 17.Plan & Validation", "gates + the phased plan"],
        ["Program / implementation appendix", "Data Dictionary · Cross-Validation · Data Profiling Checklist · Engine Assessment · OC Backlog", "technical detail for Implementation/Program owners — NOT part of the Epi/Biostats review path"],
    ]),
    ("note", "Validation verdict: the documentation supports broad LOGICAL source compatibility; PROVISIONAL until baseline sign-off, "
             "subscription confirmation, and first-feed profiling. Differences fall in 4 categories (see 10.Deltas), not 2."),
    ("gap",),
    ("section", "Suggested review path"),
    ("note", "1) Read 2.CHANGES (the executive summary of what differs).  2) Work 11.Review Decisions (open decisions, pre-filled + "
             "owner-tagged).  3) In tabs 3-9, review the rows for your role (Epi / Biostats / Program) — read left-to-right; the overlay "
             "columns on the right carry the Panoramic deltas + decisions.  4) Use 12.Epi Source Check + 14.Source Register for source "
             "sign-off.  5) Do NOT proceed to YAML until 16.Approval Gate is cleared.  Status: 'first-pass' / '[verify]' = sign-off "
             "pending; 'conflict' = internal EDM conflict to reconcile."),
    ("gap",),
    ("section", "Identity & assumption"),
    ("table", ["Field", "Value"], [
        ["Product / spec / output", "Ovarian (OC) / 202606 / rwdp_ov_pano_202606 · data version 2026m03"],
        ["study window", "2011-01-01 -> 2026-02-28 (source: studypopoc p.1; sign-off pending)"],
        ["EDM<->Pano (logical compat.)", "substantially compatible LOGICAL concepts; exact physical tables/columns/types/version MUST be mapped from the received feed. Not 'same schema' until profiled."],
    ]),
    ("gap",),
    ("section", "Authority hierarchy (high -> low) — what wins when sources disagree"),
    ("table", ["Rank", "Source", "Governs"], [
        ["1", "Approved EDM program spec", "ALL unchanged EDM variables — authoritative; this workbook does NOT redefine them"],
        ["2", "Approved Panoramic delta", "an explicitly identified, evidenced & approved Panoramic change ONLY"],
        ["3", "Source-validated rule (prior spec / Flatiron documentation)", "rules confirmed against the exact source (pending sign-off: SDR for clear reads, BIO only for judgement calls)"],
        ["4", "Golden ADS / original program output", "observed values where spec text is silent"],
        ["5", "Methodology doc", "cross-product conventions"],
        ["6", "Reconstructed R (ovarian_rdap.R) — DEFECTIVE", "clue source ONLY; never overrides 1-5"],
        ["7", "YAML scaffold / proposal / inference", "lowest; a starting point, not evidence"],
    ]),
    ("note", "Three-artifact target: (1) EDM baseline = FIRST-PASS transcription of the prior EDM spec (NOT yet approved/immutable; "
             "≈{{NVERIFY}} [verify]; the approved EDM program spec supersedes it if obtained) -> rendered in tabs 3-9; (2) Panoramic delta contract "
             "(treatment setting + platinum; drafted from the Flatiron documentation) -> Panoramic "
             "Delta + Cross-Validation tabs; (3) mechanical 202606 merge = baseline + APPROVED deltas (not started). This workbook is the "
             "self-contained review artifact feeding (3)."),
    ("gap",),
    ("section", "Open ACTIONs (external — block YAML)"),
    ("table", ["Action", "Status"], [
        ["Platinum Status Table documentation located (Flatiron Panoramic doc); now decide source-of-truth EDM-derivation vs Panoramic-table for PROC (biostats)", "ACTION"],
        ["Sign-off of the LineSetting rules (Flatiron LOT rules) + PARP carve-out", "ACTION"],
        ["SDR confirm-the-read vs the prior spec (NOT biostats calls): ID3MOSFU >=91, VIS120 >=120, surgery/NEOADJ, platinum thresholds, Adj->Advanced core rule", "ACTION"],
        ["BIO sign-off (genuine judgement): platinum source-of-truth (EDM v1/v2 vs vendor) + death imputation + PROC membership + RWR mapping + progression-vs-death", "ACTION"],
        ["Profile the delivered Panoramic feed (Data Profiling Checklist)", "ACTION"],
    ]),
    ("note", "To close these fast: the 'Biostats Decision Pack' tab pre-fills every Panoramic-side answer from the Flatiron docs "
             "(page anchor + recommendation), sorted into confirm-the-read (Gate 2) / decide-with-guidance / business / "
             "needs-the-GSK-source (Gate 1). Use it as the sign-off worksheet."),
], widths=[26, 46, 40], freeze_main=False)

# ===== 2.CHANGES =====
ws = wb.create_sheet("2.CHANGES")
render(ws, [
    ("title", "2.CHANGES — executive summary of EDM -> Panoramic changes"),
    ("sub", "High-level migration summary. ~90% of variables are UNCHANGED (reproduced from the EDM spec, tagged 'EDM baseline' in "
            "tabs 3-9). The rows below are the handful of real changes + open sign-off items; the per-variable detail lives in tabs "
            "3-9 (Origin / Panoramic delta columns) and the 10.Deltas tab. Type: ADDITIVE (new) / MODIFIED (rule altered) / PENDING (decision open)."),
    ("gap",),
    ("table", ["Change ID", "Area", "Change type", "What changed", "Owner", "Status"], [
        ["C1", "Treatment setting (LineSetting)", "ADDITIVE", "Explicit per-line Neoadjuvant/Adjuvant/Advanced/Off-Systemic-Therapy + line SPLITTING that can change LineNumber, cohort membership and index dates (HIGH impact, ripples to all line-indexed outputs). Detail: 10.Deltas + 7.Treatment.", "Implementation/Biostats", "Open"],
        ["C2", "Platinum / PROC", "MODIFIED", "Panoramic adds a per-line vendor Platinum Status table (different grain / window / thresholds 91-184 vs 90-183 / states). DIRECTION SET: build to the EDM derivation (fits the core tables + matches prior analysis); the vendor Platinum Status table is an Add-On kept as a cross-check for Biostats. Biostats ratification + PROC membership still pending. Detail: 10.Deltas + 9.PROC.", "Biostats", "Direction set (D1)"],
        ["C3", "Mortality", "MODIFIED", "Mortality_V2 source + month->midpoint(15th) death imputation; can shift OS / rwPFS / TTD / TTNT / TSST. Confirm vs golden output.", "Biostats", "Open"],
        ["C4", "PFS2 scope", "PENDING", "PFS2 IS a real EDM outcome (not a port artifact). Any drop is a proposed DEPRECATION needing approval + downstream-consumer check.", "Program/Biostats", "Open"],
        ["C5", "Additive variables", "ADDITIVE", "New optional Panoramic fields (rwAE, ctDNA, biomarker metadata, T/N/M, ExtentOfDebulking, insurance) - all DEFER/proposed. Catalogue: 13.New Panoramic Fields; rows in the section tabs (Origin = ADDITIVE).", "Program/Biostats", "Open"],
        ["C6", "Open source sign-off", "PENDING", "Confirm-the-read items (ID3MOSFU >=91, VIS120 >=120, surgery/NEOADJ, platinum thresholds, cohort 1-9 vs 1-11) + the baseline transcription. See 12.Epi Source Check + 11.Review Decisions.", "Epi/Biostats", "Open"],
    ]),
    ("note", "Digest only — the authoritative, per-variable record is tabs 3-9 (every row tagged in the Origin column) and the 10.Deltas tab. "
             "~{{NVERIFY}} [verify] items remain across the workbook; the confirm-the-read breakdown is in 12.Epi Source Check."),
], widths=[10, 26, 12, 66, 20, 11])

# ===== inventory helpers =====
def inv(rows):
    # Role/Scaf/Evid/Impl removed per review — keep only Var/Definition/Codes.
    # The FULL, rich, per-variable definitions now live in the section tabs (3-9) themselves, loaded from rows_*.json.
    return ("table", IH, [list(r)[:3] for r in rows])

# 3.Data Prep
ws = wb.create_sheet("3.Data Prep")
section_tab(ws, "3.Data Prep — sources, periods, data-prep decisions",
            "EDM data-prep: data version/window, analysis periods, and each source-prep DECISION (LOT dedup, biomarker date, progression-vs-death, MINAVAILDATE field, BASEDUR +1) as its own row, plus logical->Flatiron source mappings. Physical source parity is a first-feed validation (Data Profiling Checklist tab).",
            load_rows("dataprep"))

ws = wb.create_sheet("4.StudyPop")
section_tab(ws, "4.StudyPop — population, cohorts, eligibility",
            "Cohorts + index rules + eligibility + population filters + deterministic row-selection. COHORTN 1-9 (studypop) vs 1-11 (clinical) is a flagged conflict (Biostats Decision Pack R4).",
            load_rows("studypop"))

# ===== ADDITIVE variables (Panoramic fields NOT in the prior EDM spec) =====
# Placed IN the relevant section tabs (not a separate sheet) and flagged via the Origin column.
# Presence noted in the RECEIVED EDM data dictionary (which describes the EDM data we received, NOT the
# Panoramic feed): loose matching finds ExtentOfDebulking, T/N/M, the biomarker metadata, PayerCategory +
# the Is* payer flags THERE - i.e. they were in the EDM DATA, just not derived by the prior RWDP spec.
# Panoramic delivery must still be confirmed on the ovarian Panoramic data dictionary. rwAE + ctDNA are
# from the Panoramic doc (image-only); DiseaseGrade / RecurrenceDate / extra-SDOH were NOT confirmed for
# ovarian and are deliberately NOT added (see New Panoramic Fields).
_ADD_DEC = "INCLUDE vs DEFER for 202606 (B2 - PO/BIO; Add-Ons need COMM subscription)"
def _add(var, label, values, defn, source, evidence, owner="PO/BIO",
         status="DEFER (proposed); present in the received EDM data dictionary - confirm in the Panoramic feed", tier="Standard"):
    return {"var": var, "origin": "ADDITIVE (not in prior spec)", "label": label, "role": "Add",
            "values": values, "definition": defn,
            "delta": "ADDITIVE - Panoramic " + tier + " field, NOT in the prior EDM spec",
            "source": source, "selection": "", "evidence": evidence,
            "status": status, "owner": owner, "decision": _ADD_DEC}
_KC = "DEFER (proposed); confirm field names on delivered dict"

ADDITIVE_DEMO = [
    _add("PayerCategory", "Payer category (latest)", "Medicaid / Medicare / Commercial / Workers Comp / Other Govt / Patient Assistance / Self Pay / Other-Unknown", "Latest recorded payer category for the patient (normalized).", "Insurance table", "Flatiron data dictionary", owner="PO/COMM"),
    _add("INS_PLAN_DATES", "Insurance plan start/end dates", "date (a patient may have >1 plan)", "StartDate / EndDate of each insurance plan.", "Insurance table", "Flatiron data dictionary", owner="PO/COMM"),
    _add("INS_PAYER_FLAGS", "Payer-detail flags (9)", "each Yes / No-Unknown", "IsMedicareAdv / IsMedicareSupp / IsPartAOnly / IsPartBOnly / IsPartAandPartB / IsPartDOnly / IsManagedGovtPlan / IsManagedMedicaid / IsMedicareMedicaid (Medicare Advantage/Supplement, Part A/B/D, managed govt/Medicaid, dual-eligible).", "Insurance table", "Flatiron data dictionary", owner="PO/COMM"),
]
ADDITIVE_CLINICAL = [
    _add("TStage", "T stage at diagnosis", "coded (e.g. T1; full list [verify])", "AJCC T stage at initial diagnosis - additive to the FIGO GroupStage that EDM uses (STAGE).", "Enhanced_Ovarian", "Flatiron data dictionary"),
    _add("NStage", "N stage at diagnosis", "coded (e.g. N1)", "AJCC N stage at initial diagnosis.", "Enhanced_Ovarian", "Flatiron data dictionary"),
    _add("MStage", "M stage at diagnosis", "coded (e.g. M1)", "AJCC M stage at initial diagnosis.", "Enhanced_Ovarian", "Flatiron data dictionary"),
    _add("ExtentOfDebulking", "Extent of debulking (post initial-dx surgery)", "Optimal / Suboptimal / Unknown", "Extent of debulking following surgery for the initial OC diagnosis - a surgical-outcome dimension beyond the existing RD / SizeOfResidualDisease.", "Enhanced_Ovarian", "Flatiron data dictionary", status="DEFER (proposed) - recommend INCLUDE (lead candidate, B2); present in the received EDM data dictionary - confirm in the Panoramic feed"),
    _add("BiomarkerDetail", "Genomic alteration class (biomarker)", "Mutation / Rearrangement / Amplification / Protein expression / VUS / Gene Expression / Loss / Other / Unknown", "Type/class of genomic alteration where the biomarker status is Positive. (No separate NGS gene/variant table exists - genomics is this biomarker metadata.)", "Enhanced_OvarianBiomarkers", "Flatiron data dictionary"),
    _add("DnaType", "DNA source (biomarker)", "Germline / Somatic / Unknown (only populated for BRCA)", "DNA source used for the biomarker test.", "Enhanced_OvarianBiomarkers", "Flatiron data dictionary"),
    _add("BIOMARKER_METHOD", "Biomarker test method/platform", "FISH / IHC / NGS / RNA sequencing / PCR / Other / Unknown", "Assay methodology/platform of the biomarker test (exact field name [verify] on delivered dict).", "Enhanced_OvarianBiomarkers", "Flatiron data dictionary"),
    _add("StainingIntensity", "FOLR1/FRalpha IHC staining intensity", "1 / 1+ / Weak staining; 2 / 2+ / Moderate staining; 3 / 3+ / Strong staining; 0; Other", "Vendor-coded IHC staining intensity for FOLR1/FRalpha. The raw intensity labels (Weak/Moderate/Strong) ARE in the data dict; the named high/moderate/low EXPRESSION tiers used for FRalpha scoring are NOT documented - those would be DERIVED (cut-offs to decide).", "Enhanced_OvarianBiomarkers", "Flatiron data dictionary"),
    _add("PercentStaining", "FOLR1/FRalpha % cells staining", "percent", "Percent of cells staining for FOLR1/FRalpha by IHC.", "Enhanced_OvarianBiomarkers", "Flatiron data dictionary"),
    _add("LabName", "Testing lab/assay (biomarker)", "Foundation Medicine / Guardant / Tempus / Caris / Myriad / ... (HRD/GIS adds assay names e.g. Myriad myChoice)", "Laboratory/assay that performed the biomarker test.", "Enhanced_OvarianBiomarkers", "Flatiron data dictionary"),
    _add("SampleType", "Specimen type (biomarker)", "Blood / Tissue / Saliva / Urine / Other / Unknown", "Specimen type tested.", "Enhanced_OvarianBiomarkers", "Flatiron data dictionary"),
    _add("BIOMARKER_DATES", "Biomarker test dates", "date (each)", "SpecimenCollectedDate / SpecimenReceivedDate / ResultDate for the biomarker test.", "Enhanced_OvarianBiomarkers", "Flatiron data dictionary"),
    _add("ctDNA_ReportDate", "ctDNA report date (Natera Signatera)", "date (rarely null)", "Date of the Natera Signatera ctDNA report (report-level grain; one row per report).", "Enhanced_Ovarian_ctDNA", "Flatiron Panoramic doc", status=_KC),
    _add("ctDNA_TestResult", "ctDNA test result", "Positive / Negative / Inconclusive (never null)", "Natera Signatera ctDNA result.", "Enhanced_Ovarian_ctDNA", "Flatiron Panoramic doc", status=_KC),
    _add("ctDNA_TestMeasurement", "ctDNA quantitative measurement", "numeric MTM/mL; null if Negative/Inconclusive", "Quantitative ctDNA (mean tumor molecules per mL).", "Enhanced_Ovarian_ctDNA", "Flatiron Panoramic doc", status=_KC),
]
ADDITIVE_OUTCOMES = [
    _add("rwAE_AdverseEvent", "rwAE term (real-world adverse event)", "coded; AE terms project/subscription-specific (not enumerated)", "The real-world adverse-event term. Grain = one row per Patient x line-of-therapy x AE. Add-On table family.", "Enhanced_Ovarian_AdverseEvents", "Flatiron Panoramic doc", owner="COMM/BIO", status=_KC, tier="Add-On"),
    _add("rwAE_OnsetDate", "rwAE onset date (+granularity)", "date (+ Day/Month/Year)", "Onset of the AE (first new-or-worsened instance only). Companion field PresentAtBaseline (Yes/No, = condition present in the 30d pre-therapy baseline) drives the OnsetDate null-logic.", "Enhanced_Ovarian_AdverseEvents", "Flatiron Panoramic doc", owner="COMM/BIO", status=_KC, tier="Add-On"),
    _add("rwAE_Grade", "rwAE CTCAE grade", "1 / 2 / 3 / 4 / 5 / Not documented", "Clinician-documented CTCAE-style severity grade.", "Enhanced_Ovarian_AdverseEvents", "Flatiron Panoramic doc", owner="COMM/BIO", status=_KC, tier="Add-On"),
    _add("rwAE_Severity", "rwAE terminological severity", "Mild / Moderate / Severe / Life-threatening / Fatal / Not documented", "Terminological severity (distinct from Grade).", "Enhanced_Ovarian_AdverseEvents", "Flatiron Panoramic doc", owner="COMM/BIO", status=_KC, tier="Add-On"),
    _add("rwAE_DrugAttribution", "rwAE drug attribution", "Definite / Likely / Not attributed / No documentation", "Attribution of the AE to the therapy of interest.", "Enhanced_Ovarian_AdverseEvents", "Flatiron Panoramic doc", owner="COMM/BIO", status=_KC, tier="Add-On"),
    _add("rwAE_Resolution", "rwAE resolution status (+date)", "Resolved / Resolving / Resolved with sequelae / Ongoing / Fatal / Not documented", "AE status at end of the line of therapy (+ ResolutionDate + granularity).", "Enhanced_Ovarian_AdverseEvents", "Flatiron Panoramic doc", owner="COMM/BIO", status=_KC, tier="Add-On"),
    _add("rwAE_RelatedOutcome", "rwAE related outcome", "Hospitalization / Dose-or-schedule change / Treatment for AE / Discontinuation / Hold / None / Death", "Outcome in response to the AE (one row per outcome).", "Enhanced_Ovarian_AdverseEvents_Outcomes", "Flatiron Panoramic doc", owner="COMM/BIO", status=_KC, tier="Add-On"),
    _add("rwAE_Hospitalization", "rwAE hospitalization", "AdmissionDate (+granularity); HospitalizationType (AE-led / AE-during admission)", "AE-related hospitalization (one row per admission).", "Enhanced_Ovarian_AdverseEvents_Hospitalizations", "Flatiron Panoramic doc", owner="COMM/BIO", status=_KC, tier="Add-On"),
]

ws = wb.create_sheet("5.Demographics")
section_tab(ws, "5.Demographics",
            "AGE/age-band, region, race, ethnicity, practice, SES, gender (= Panoramic BirthSex). Each categorical and its numeric counterpart on its own row. ADDITIVE rows (Origin column): Insurance / payer.",
            (load_rows("demo") or []) + ADDITIVE_DEMO)

ws = wb.create_sheet("6.Clinical characteristics")
section_tab(ws, "6.Clinical characteristics",
            "Diagnosis/staging/surgery; ECOG/vitals/BSA; biomarkers (BRCA/HRD/GIS/FOLR1 families, 6 rows each); 11 labs (status/value/date/unit each); BRCAxHRD composite; follow-up/death/availability; PCYCL. DTHDT imputes month-granular death to the 15th (same-month-as-follow-up -> last-day exception; year-only -> Jul-15/Dec-31) - confirm vs golden ADS (Decision Pack D7); platinum variables are top sign-off priority. ADDITIVE rows (Origin column = 'ADDITIVE (not in prior spec)'): T/N/M stage, ExtentOfDebulking, biomarker metadata (FOLR1 staining intensity/percent, alteration class, DNA source, method, lab, sample type, dates), ctDNA - all DEFER/proposed.",
            (load_rows("clinical") or []) + ADDITIVE_CLINICAL)

ws = wb.create_sheet("7.Treatment variables")
section_tab(ws, "7.Treatment variables (+ Δ treatment setting)",
            "Per-line families (i=1..5) fully EXPLODED: LOT regimen/start/end, maintenance, durations, per-line class flags; FNIRA/CSD; LOTN bands; PLUS the LineSetting Panoramic delta rows (delta column filled; owner ARCH). OST carries a LineSetting but NO LineNumber.",
            load_rows("treatment"))

ws = wb.create_sheet("8.Outcomes")
section_tab(ws, "8.Outcomes",
            "ID3MOSFU/OS/VIS120/rwPFS/ELIGPFS/TTD/TTNT/TSST/RWR (exploded i=1..3)/PFS2. ID3MOSFU & VIS120 PDF-primary (SDR sign-off). Owner routing (Decision Pack R5-R8): TSST cohort-thresholds -> SDR; TTD +1 -> ENG; rwPFS progression-vs-death -> BIO. ADDITIVE rows (Origin column = 'ADDITIVE (not in prior spec)'): rwAE adverse-event family (term/onset/grade/severity/attribution/resolution/related-outcome/hospitalization) - Add-On, needs COMM subscription; all DEFER/proposed.",
            (load_rows("outcomes") or []) + ADDITIVE_OUTCOMES)

ws = wb.create_sheet("9.PROC PSOC Strategy")
render(ws, [
    ("title", "9.PROC PSOC Strategy (Δ platinum)"),
    ("sub", "Largest clinical blocker. Rich variable rows (EDM derivation + Panoramic delta) + truth tables. v1/v2 / eligibility / source-of-truth need biostats sign-off (Biostats Decision Pack D1, R1-R3). EDM cuts <=90/183 DIFFER from Panoramic 91/184 - kept distinct."),
    ("gap",),
    ("section", "Platinum-sensitivity variables (one per row; EDM derivation + Panoramic delta)"),
    ("table", RH, rh_rows(load_rows("platinum") or [])),
    ("section", "2L truth table (source observed; sign-off pending)"),
    ("table", ["Condition", "PLAT_SEN_v1", "Evid"], [
        ["not eligible", "Not eligible", "Transcribed"], ["eligible & PFI<=90", "Refractory", "Transcribed"],
        ["eligible & 90<PFI<=183", "Resistant", "Transcribed"], ["eligible & PFI>183", "Sensitive", "Transcribed"],
    ]),
    ("section", "3L+ truth table (uses PRIOR line status)"),
    ("table", ["Condition", "PLAT_SEN_v1", "Evid"], [
        ["not eligible", "Not eligible", "Transcribed"], ["prior Sensitive & PFI<=183", "Resistant", "Transcribed"],
        ["prior Sensitive & PFI>183", "Sensitive", "Transcribed"], ["prior Refractory/Resistant", "Primary platinum resistant/refractory in a prior LOT", "Transcribed"],
    ]),
    ("note", "Worked boundary examples (PFI exactly 90/183, multi-progression, v1!=v2) are in the Worked Examples tab; the Panoramic Platinum Status table detail is in the Panoramic Delta tab. Panoramic Platinum Status must confirm grain/values/PFI before any equivalence is assumed."),
], widths=RW)

# ===== 10.Deltas (merged: detail + 4-category taxonomy + by-cohort impact) =====
ws = wb.create_sheet("10.Deltas")
render(ws, [
    ("title", "10.Deltas — the EDM -> Panoramic changes (detail + taxonomy + by-cohort impact)"),
    ("sub", "Everything that DIFFERS from the EDM spec, in one place: the 3 analytic/source deltas (treatment setting, platinum, "
            "mortality) in full, the 4-category difference taxonomy, and the by-cohort golden-compare expectations. "
            "Provisional until baseline sign-off + first-feed profiling."),
    ("gap",),
    ("section", "A. Summary of deltas — the 4 categories (2 primary analytic + source/delivery + physical mapping + additive)"),
    ("table", ["Category", "Item", "EDM (today)", "Panoramic"], [
        ["Analytic derivation", "Treatment setting / line splitting", "NEOADJ surgery-timing flag only", "explicit LineSetting {Neoadj/Adj/Advanced/Off} + line SPLITTING -> can change LineNumber/index"],
        ["Analytic derivation", "Platinum status", "DERIVED PLAT_SEN_v1/v2; PFI; 90/183", "per-line Platinum Status table; 91 / 92-183 / 184; no v1/v2/eligibility states"],
        ["Source / delivery", "Mortality", "Enhanced_Mortality_V2 (extra death source)", "Mortality_V2 (differs) -> can shift death flag/date, OS, rwPFS, TTD/TTNT/TSST"],
        ["Source / delivery", "Add-On dependencies", "core derivation", "rwP REQUIRED (rwPFS + EDM platinum PFI); Scaled rwR REQUIRED only if RWR in scope; Platinum Status OPTIONAL for EDM-derived PROC. See Review Decisions B1"],
        ["Source / delivery", "Death-date imputation", "EDM: month -> 15th base (same-month-as-follow-up last-day exception; year-only Jul-15/Dec-31)", "Mortality_V2 also -> midpoint(15th); broadly aligned - confirm vs golden output"],
        ["Physical mapping", "table & column names", "t_meg_enh_ov / RESULTDATE / ismaintenancetherapy", "Enhanced_Ovarian / ResultDate / IsMaintenanceTherapy — MAP from the delivered feed; data-dict lags KC (RecurrenceDate)"],
        ["Additive scope", "new Panoramic fields", "absent", "FOLR1 staining, ExtentOfDebulking, T/N/M, ctDNA, Insurance, rwAE... (see New Panoramic Fields tab; DiseaseGrade is endometrial-only, NOT an ovarian field)"],
    ]),
    ("section", "B. Treatment setting (LineSetting) [Flatiron LOT rules] — owner Implementation/Biostats"),
    ("table", ["Aspect", "Rule", "Change-type / impact"], [
        ["LineSetting field", "LineOfTherapy.LineSetting {Neoadjuvant / Adjuvant / Advanced / Off Systemic Therapy} (Derived, Coded)", "ADDITIVE (new per-line attribute)"],
        ["Neoadjuvant", "treatment BEFORE the date of first definitive surgery", "rule"],
        ["Adjuvant", "treatment BETWEEN first definitive surgery and the recurrence date", "rule"],
        ["Advanced", "if definitive surgery: treatment after OR up to 14d BEFORE recurrence; if NO definitive surgery: treatment after diagnosis. BOTH surgery branches are source-stated (Flatiron LOT rules) + a neoadjuvant-ahead-of-planned-surgery clause (tagged Advanced, then retroactively Neoadjuvant)", "rule (source-resolved; SDR ratify)"],
        ["Line splitting", "lines split at Neoadj->Adj and Adj->Advanced boundaries -> can CHANGE LineNumber", "MODIFIED - HIGH: ripples to index date, cohort membership, LOTN, all index-relative outputs"],
        ["Adj->Advanced split math", "CORE RULE (source-defined): adjuvant continuing >=14d after recurrence is SPLIT; 2nd line = Advanced, start = LAST episode <14d after recurrence", "Core rule + day-14 boundary are source-resolved; D2 = SDR ratify + pin remaining edge cases (end-date truncation, source-row, boundary-spanning drugs) + >=3 worked examples"],
        ["Off Systemic Therapy", "created at a >=90-day gap; carries a LineSetting but NO LineNumber; does NOT advance lines", "ADDITIVE - surfaced only if the analysis chooses to (D3)"],
        ["PARP carve-out", "lines containing niraparib/olaparib/rucaparib are NOT split (rev 30-APR-2026). Talazoparib in/out [verify]", "exception to splitting"],
        ["RecurrenceDate dependency", "Adjuvant-vs-Advanced needs RecurrenceDate (documented in the Flatiron Enhanced_Ovarian table; data dict lags). Missing/null handling is NOT specified in the LOT rules", "delivery/completeness pending + the missing-value rule is an ARCH/BIO decision (Data Profiling)"],
        ["NEOADJ_CHEMO (legacy)", "EDM surgery-timing proxy SURGN=2->Yes/4->Unknown/else No; NOT equivalent to LineSetting='Neoadjuvant'", "UNCHANGED (keep) + optional neoadj_concordance (D5)"],
    ]),
    ("section", "C. Platinum / PROC [Flatiron Panoramic doc] — owner Biostats"),
    ("note", "Panoramic ships a per-line Platinum Status table (Add-On). EDM derives platinum itself and attaches the status to the SUBSEQUENT line cohort using the PRIOR line's platinum. Related but NOT identical - reconcile + source-of-truth decision (D1)."),
    ("table", ["Aspect", "EDM baseline", "Panoramic Platinum Status"], [
        ["Grain", "per patient/cohort - status on the SUBSEQUENT line (e.g. 2L cohort)", "per LINE - one row per non-neoadjuvant platinum-containing line (multiple/patient)"],
        ["Platinum reference", "PRIOR line's last platinum episode (PCYCL{i-1}ED)", "the SAME line's last platinum episode"],
        ["Progression window", "priorLSD+14 <= PROGRESSIONDATE < currentLSD+14 (bounded by next line)", "first recurrence/progression >=14d after the FIRST platinum episode (no explicit next-line bound)"],
        ["PFI", "PFSDT_IndexToPriorPlatEnd - PCYCL{i-1}ED", "(first qualifying recurrence/progression) - (last platinum episode of the line)"],
        ["Day thresholds", "Refractory <=90 / Resistant 90<PFI<=183 / Sensitive >183", "Refractory <=91 / Resistant 92-183 / Sensitive >=184"],
        ["Value set", "Sensitive/Resistant/Refractory/Primary-prior-LOT/Not eligible/(v2 Not Derived)", "Sensitive/Resistant/Refractory/null ONLY"],
        ["3L+ chaining", "depends on the prior line's status (Primary-prior-LOT rule)", "none - each line scored independently"],
        ["Availability", "core EDM derivation", "Add-On (subscription) - OPTIONAL for EDM-derived PROC"],
    ]),
    ("note", "DECISION (working direction, D1): build to the EDM derivation as the PROC source - it fits the CORE tables (engine-derived from LOT + DrugEpisode + progression) and matches the prior EDM analysis (richer states + at-first-resistance indexing). The Panoramic Platinum Status table is an Add-On, kept as a CROSS-CHECK to discuss with Biostats - NOT adopted as source. Biostats/Program ratification is the formal gate. Net: a Panoramic PlatinumStatus='Resistant' on line L is NOT a drop-in equal of EDM PLAT_SEN_v1='Resistant' at the L+1 cohort."),
    ("section", "D. Mortality / source-delivery [Flatiron Panoramic doc] — owner Biostats/Implementation"),
    ("table", ["Aspect", "EDM baseline", "Panoramic"], [
        ["Table", "Enhanced_Mortality_V2 (Enhanced; extra death-date source)", "Mortality_V2 (Derived)"],
        ["Death-date imputation", "month -> 15th base (+ same-month-as-follow-up last-day exception; year-only Jul-15/Dec-31)", "month-granular; Flatiron recommends MIDPOINT (~15th) - aligned with the EDM 15th base"],
        ["Resolution", "confirm the 15th base + same-month exception reproduces golden ADS (D7)", "Flatiron sets the PANORAMIC convention only, NOT the EDM rule (D8). If midpoint adopted -> MODIFIED derivation (OS/rwPFS/TTNT/TSST impact)"],
    ]),
    ("note", "Distinct concept: the LOT-Rules generalisation of death to last-day-of-month for a LINE END-DATE is a different rule from the death-date imputation used in outcomes - do not conflate."),
    ("section", "E. Additive / source-delivery / physical-mapping notes"),
    ("note", "Additive Panoramic fields are catalogued INCLUDE/DEFER in the New Panoramic Fields tab and folded into the section tabs as ADDITIVE rows. "
             "Source/delivery: rwP is REQUIRED (rwPFS + the EDM platinum PFI); Platinum Status is OPTIONAL for the EDM-derived PROC. "
             "Physical mapping (table/column names + types + delivery version) must be mapped from the delivered feed at activation - see the program/implementation appendix (Data Dictionary / Data Profiling) and Review Decisions."),
    ("section", "F. Impact by cohort (golden-compare expectations)"),
    ("table", ["Cohort / history", "Expected parity", "Why"], [
        ["Overall cohort (index = diagnosis)", "Close; additive Panoramic fields; mortality-source diffs possible", "index not affected by LineSetting; but DateOfDeath source differs"],
        ["Line cohorts with UNCHANGED line history", "Close (subject to mortality + sign-off)", "no split/reclassification"],
        ["SPLIT / reclassified treatment histories", "DIFFERENCES expected across ALL index-relative outputs: LOT numbering, line dates, cohort membership, index date, AGE, INDEXYR, ECOG, lab/biomarker selection, FU duration, OS, rwPFS, TTD/TTNT/TSST, eligibility", "LineSetting + Off-Systemic-Therapy can move the index date -> everything index-relative shifts"],
        ["Off Systemic Therapy histories", "DIFFERENCES possible ONLY if OST is surfaced", "OST carries a LineSetting but NO LineNumber (does NOT advance lines); architecture decision whether/how to surface it (off-treatment time) — must not silently shift EDM cohorts"],
        ["PROC rows", "DIFFERENCES expected (platinum status; possibly index)", "platinum delta + index selection"],
        ["Mortality-source-different patients", "DIFFERENCES in death flag/date -> OS/rwPFS/TTE", "Mortality_V2 vs Enhanced_Mortality_V2"],
        ["Raw source attributes (birthyear, race, histology source value)", "Close", "raw inputs; but their DERIVED per-row values may differ"],
    ]),
    ("note", "Row-for-row EDM=Panoramic parity is NOT expected. Golden-compare must be stratified: unchanged / split / "
             "Off-Systemic-Therapy / PROC / mortality-source-different histories. Stays Pending until first-feed profiling."),
], widths=[24, 32, 36, 42])

# ===== Cross-Validation =====
ws = wb.create_sheet("Cross-Validation")
render(ws, [
    ("title", "EDM <-> Panoramic cross-validation (vs all Flatiron KC docs + data dict + methodology, 228 pp)"),
    ("sub", "PROVISIONAL: documentation supports broad LOGICAL source compatibility; physical mapping, subscription and data-profile "
            "validation remain pending. Vocabulary: documented / transcribed / visually-signed-off / approved / observed-in-data."),
    ("gap",),
    ("section", "Subscription tiers (Ovarian Panoramic Solution Overview, flatiromdata1 p.1-5) - key operational fact"),
    ("table", ["Tier", "", "", "Tables (what GSK gets)"], [
        ["STANDARD (default)", "", "", "Demographics, Practice, Visits, Telemedicine, ECOG, Baseline ECOG, Insurance, SES Index, Diagnosis, Enhanced_Ovarian (Cancer Characteristics), MedicationAdministration, MedicationOrders, Line of Therapy (+Rules), Drug Episodes, Oral Therapies, Labs & Vitals, Ovarian Biomarkers (BRCA/HRD/GIS/FOLR1), ctDNA, Mortality"],
        ["ADD-ONS (subscribe)", "", "", "Real-World Progression (rwP); Scaled Real-World Response (rwR); Scaled Real-World Adverse Events (rwAE); Platinum Status"],
        ["CUSTOM ADD-ONS", "", "", "Reasons for Discontinuation; Detailed Orals; CCI Comorbidities; Additional Malignancies; Detailed rwR; Detailed rwAE"],
    ]),
    ("note", "Subscription action (CORRECTED): rwP REQUIRED (rwPFS + EDM platinum PFI); Scaled rwR REQUIRED only if RWR in scope; "
             "Platinum Status OPTIONAL for EDM-derived PROC (needed only to publish/validate/adopt the vendor status). See Biostats Decision Pack B1."),
    ("section", "Per-table verdict ledger"),
    ("table", ["Panoramic table / article", "EDM baseline", "Class", "Verdict"], [
        ["Platinum Status", "PLAT_SEN_v1/v2", "DELTA", "additive+modified (grain/reference-line/window/thresholds 91&184 vs 90&183/value set); source-of-truth decision pending (D1)"],
        ["rwR Response (scaled/detailed)", "RWRi family", "DELTA", "EDM derives FROM it, but value sets NOT proven equivalent (Non-Response/Pseudoprog/Indeterminate/Not-documented + multi-assessment selection) - reconciliation pending (D9)"],
        ["rwAE Adverse Events", "-", "NEW", "Panoramic-only Add-On; out of current EDM scope; candidate additive"],
        ["rwP Progression", "PFSFL/PFSDT/PFS", "DELTA", "concepts available (ProgressionDate/IsPseudoprog/LastClinicNote) but Panoramic adds PHYSICAL-EXAM evidence the OC scaffold omits - evidence-set + combination rule reconciliation pending (D10); Add-On"],
        ["Biomarkers (Enhanced_OvarianBiomarkers)", "BRCA/HRD/GIS/FOLR1", "UNCHANGED", "source columns + value sets match the EDM derivation; FOLR1 StainingIntensity/PercentStaining additive"],
        ["LineSetting / LOT construction", "NEOADJ_CHEMO + LOT family", "DELTA", "LineSetting + line-splitting (changes LineNumber); the 28-day/120d-gap/90d-OST/maintenance LOT rules themselves are UNCHANGED"],
        ["Mortality", "death.pdf / DTHDT", "DELTA", "minor (Mortality_V2 vs Enhanced_Mortality_V2 extra source); Flatiron sets the Panoramic convention (month->midpoint) NOT the EDM rule (D7/D8)"],
        ["Core OC table (Enhanced_Ovarian)", "clinical sections", "UNCHANGED", "matches every EDM derivation input; RecurrenceDate documented (data dict lags; delivery pending); ExtentOfDebulking/TNM/residual-size additive (DiseaseGrade is endometrial-only, NOT ovarian)"],
        ["Demographics / Practice / Visit / Telemed", "demo sections", "UNCHANGED", "confirms AGE/RACE/ETH/GENDER(BirthSex)/REGION/PRACTIC"],
        ["ECOG / SES / Diagnosis / Labs / Orals", "baseline sections", "UNCHANGED", "source columns + value sets + unit-aware handling confirmed (ECOG-5 suppressed->Unknown; CA-125 kU/L)"],
        ["ctDNA / Insurance / NGS-date", "-", "NEW", "Standard availability; additive candidates"],
        ["RFD / Comorbidities / Add'l Malignancies / Detailed Orals", "-", "NEW", "Add-On/Custom; out of current scope"],
    ]),
    ("section", "Headline verdict by 5 validation dimensions (PROVISIONAL)"),
    ("table", ["Dimension", "", "", "Status"], [
        ["Logical concept compatibility", "", "", "Substantially supported - every EDM source concept exists in Panoramic"],
        ["Derivation equivalence (semantic)", "", "", "Partial - 2 analytic deltas + engine gaps (platinum algorithm, TTD+1, PFS/death priority, TSST) + rwR/rwP reconciliation; pending sign-off"],
        ["Physical mapping", "", "", "Not established - exact table/column names/types/version must be mapped from the feed (data dict lags KC)"],
        ["Subscription availability", "", "", "Pending - rwP / Scaled rwR are Add-Ons; Platinum Status optional; confirm GSK subscription"],
        ["Data-profile validation", "", "", "Not started - first-feed profiling pending"],
    ]),
    ("note", "Differences fall in 4 categories: analytic derivation (treatment setting, platinum) | source/delivery (Mortality_V2; Add-On deps; death imputation) | physical mapping (table/column names) | additive scope (FOLR1 staining, ExtentOfDebulking, ctDNA, Insurance...; DiseaseGrade is endometrial-only, NOT ovarian). Two must-confirms: (1) subscription includes rwP + Scaled rwR; (2) RecurrenceDate completeness on first data."),
], widths=[30, 4, 4, 80])

# ===== Data Dictionary =====
ws = wb.create_sheet("Data Dictionary")
render(ws, [
    ("title", "Source data dictionary - ovarian tables & columns (from the RECEIVED EDM data dictionary + the ovarian Panoramic data-table article; the definitive ovarian Panoramic dictionary is still needed)"),
    ("sub", "Built from the RECEIVED EDM data dictionary (Data Model 2026-05-28 - it describes the EDM data we received, NOT the Panoramic feed) plus the ovarian Panoramic data-table article. "
            "So these columns / value sets are the EDM-side structure; the definitive OVARIAN PANORAMIC data dictionary must still be obtained and diffed on the first feed. [verify] = transcription-uncertain; DiseaseGrade is UNCONFIRMED for ovarian (Grade is Endometrial-only)."),
    ("gap",),
    ("section", "Enhanced_Ovarian (Enhanced; one row/patient) - the core OC clinical table  [Panoramic name; the EDM-era table was 'Enhanced_OvarianCancer' - confirm the exact physical name on the delivered feed]"),
    ("table", ["Column", "Type", "Values / notes"], [
        ["PatientID", "String (FK)", ""],
        ["DiagnosisDate", "Date", "hierarchy: biopsy-collection > physician-biopsy > physician-dx > definitive-surgery; multiple primaries after 2011 -> highest stage"],
        ["Histology", "Coded", "Serous / Mucinous / Clear cell / Transitional cell / Endometrioid / Epithelial NOS / Borderline / Unknown"],
        ["GroupStage", "Coded", "FIGO I-IV w/ substages / Unknown (FIGO preferred over AJCC; pathologic unless neoadjuvant->clinical; window dx->surgery or 4 mo)"],
        ["TStage / NStage / MStage", "Coded", "TNM substages / Unknown"],
        ["IsSurgery", "Coded", "Yes / No-unknown (definitive curative-intent resection; diagnostic/palliative excluded)"],
        ["SurgeryDate", "Date", "last significant procedure of initial surgical treatment"],
        ["ExtentOfDebulking", "Coded", "Optimal / Suboptimal / Unknown"],
        ["ResidualDiseaseStatus", "Coded", "Residual / No residual / Unknown"],
        ["SizeOfResidualDisease", "Coded", "<=1cm / <=2cm / >1cm / >2cm / Unknown (hierarchy op-report > radiology+clinician > clinician > radiology)"],
        ["DiseaseGrade", "[unconfirmed for OC]", "UNCONFIRMED for ovarian: the ovarian data dict has only Histology, no Grade; a Grade field (G1/G2/G3) exists only for Endometrial; the ovarian KC variable-detail article was not available to confirm. Confirm on the delivered data dict before treating as a field."],
        ["RecurrenceDate", "Date", "earliest recurrence-event date (4 defns) - in KC article (31-JUL-2025); data dict copy omits it; KC authoritative"],
    ]),
    ("note", "EDM derives HISTO(->3)/STAGE/ISSURG/SURGERY_TYPE/RD/sizeofresidualdisease from this table; DiagnosisDate/SurgeryDate/RecurrenceDate feed the treatment-setting delta."),
    ("section", "Enhanced_OvarianBiomarkers (Enhanced) - BRCA/HRD/GIS/FOLR1"),
    ("table", ["Column", "Type", "Values / notes"], [
        ["BiomarkerName", "Coded", "BRCA / HRD / GIS / FOLR1(FRalpha)"],
        ["SpecimenCollected/Received/ResultDate", "Date", "EDM biomarker date = max(SpecimenReceivedDate, ResultDate)"],
        ["BiomarkerStatus", "Coded", "BRCA: BRCA1/BRCA2/Both/NOS / No mutation / VUS / Favor Polymorphism / Other / Pending / Unsuccessful / Unknown. FOLR1: Pos/Neg/Equivocal/Pending/Unsuccessful/Unknown. HRD&GIS: Pos/Neg/Pending/Unsuccessful/Unknown"],
        ["SampleType", "Coded", "Blood / Tissue / Saliva / Urine / Other / Unknown"],
        ["LabName", "Coded", "Myriad, Foundation Medicine, Caris, Guardant, ..."],
        ["DnaType", "Coded", "Germline / Somatic / Unknown - BRCA only"],
        ["StainingIntensity", "Coded", "1 / 1+ / Weak staining; 2 / 2+ / Moderate staining; 3 / 3+ / Strong staining; 0; Other - FOLR1/FRalpha IHC"],
        ["PercentStaining", "Coded", "% cells staining - FOLR1/FRalpha (enables FRa high/moderate/low per NH protocol)"],
        ["BiomarkerDetail", "Coded", "Mutation / Rearrangement / Amplification / Protein expression / VUS / Gene Expression / Loss / Other"],
        ["TissueCollectionSite / TestType", "String", "FISH / IHC / NGS / PCR / RNA-seq / Other"],
    ]),
    ("section", "Other ovarian Enhanced tables + generic source tables"),
    ("table", ["Table", "Kind", "Columns / value sets"], [
        ["Enhanced_Ovarian_Orals", "Enhanced", "PatientID; DrugName (Altretamine, Anastrozole, Capecitabine, Etoposide, Letrozole, Megestrol, Melphalan, Niraparib, Olaparib, Rucaparib, Pazopanib, Tamoxifen, Relacorilant, Clinical Study Drug, Other); StartDate; EndDate; DateGranularity {Day/Month/Year}. Span: stop >60d->multiple; <=60d->single"],
        ["Enhanced_OvarianNGS", "Enhanced", "NGSTestDate (NEW; additive)"],
        ["Demographics", "Standard", "PatientID; BirthYear (de-id for older patients); BirthSex {F,M}; Race {Asian, Black/AA, Hispanic/Latino, White, Other}; Ethnicity {Hisp, Not-Hisp}; State {USPS}"],
        ["Practice", "Standard", "PracticeID; PracticeType {ACADEMIC, COMMUNITY}; PrimaryPhysicianID"],
        ["Diagnosis", "Standard", "DiagnosisDate; DiagnosisCode; DiagnosisCodeSystem {ICD-9-CM, ICD-10-CM} (ICD-10 if dx >=2015-10-01); Description"],
        ["Visit", "Standard", "VisitDate; VisitType {Vitals, Treatment, Lab}; IsVitals/IsTreatment/IsLabVisit"],
        ["Lab", "Standard", "TestDate; LOINC; Test; LabComponent; TestBaseName; TestUnits(+Cleaned); ResultDate; TestResult(+Cleaned); MinNorm/MaxNorm; LabSource. CA-125 -> LOINC 10334-1, kU/L [verify]"],
        ["Vitals", "Standard", "lab shape; Test {body weight, body height, ...}; TestResultCleaned normalized (kg, cm)"],
        ["MedicationOrder", "Standard", "OrderID; OrderedDate; ExpectedStartDate; OrderedAmount/Units; DrugName; CommonDrugName; DrugCategory; DetailedDrugCategory; Route; PlannedCycles; IsCanceled"],
        ["MedicationAdministration", "Standard", "OrderID; DrugName; CommonDrugName; Route; DrugCategory; AdministeredDate; AdministeredAmount/Units"],
        ["DrugEpisode", "Derived", "LineName; LineNumber; LineSetting; IsMaintenanceTherapy; EnhancedCohort; LineStart/EndDate; EpisodeDate (priority EnhancedOrals->AdministeredDate->ExpectedStartDate->OrderedDate); EpisodeDataSource; DrugName; Amount; Units; DrugCategory; Route"],
        ["LineOfTherapy", "Derived", "LineName; LineNumber; LineSetting; IsMaintenanceTherapy; EnhancedCohort; StartDate; EndDate"],
        ["ECOG / BaselineECOG", "Standard/Derived", "ECOG: EcogDate; EcogValue {0-4}. BaselineECOG: ECOGSource {Structured,Extracted}; LineNumber; LineStartDate; ECOGValue {0-4,Unknown}; ECOGDate (ECOG 5 suppressed->Unknown)"],
        ["Insurance", "Standard", "PayerCategory {Medicaid, Medicare, Commercial, Workers Comp, Other Gov, Patient Assistance, Self Pay, Other}; Start/EndDate; plan-type flags"],
        ["Telemedicine", "Standard", "VisitDate (>=2020-03-01)"],
        ["SocialDeterminantsOfHealth", "Standard", "SESIndex2015_2019 {1-Lowest .. 5-Highest} (Yost)"],
        ["Mortality_V2 / Enhanced_Mortality_V2", "Derived/Enhanced", "DateOfDeath (month+year; recommend midpoint/15th). Enhanced_Mortality_V2 = EDM variant (extra death-date source)"],
    ]),
], widths=[28, 16, 78])

# ===== Additive Candidates =====
ws = wb.create_sheet("Additive Candidates")
render(ws, [
    ("title", "Additive candidates - Panoramic elements available but NOT in the current EDM-based 202606 contract"),
    ("sub", "Each row is a candidate to INCLUDE (add to 202606) or DEFER. None changes an existing EDM variable. Tier: Standard "
            "(default) / Add-On (subscribe) / Custom (targeted). Owner PO (+BIO). For the FIRST release, DEFER most; include only "
            "low-risk Standard fields with clear demand. Additivity must be DEMONSTRATED (no effect on existing rows/cohorts/joins). "
            "TWO SEPARATE COLUMNS: 'Recommend' is the RWDP team's recommendation; 'Decision' is the live governance status - Pending "
            "for EVERY row (nothing here is approved for 202606 yet). That is why the matching section-tab additive rows all carry "
            "Status = 'DEFER (proposed)' regardless of recommendation: a 'Recommend = INCLUDE' (e.g. ExtentOfDebulking) is still "
            "DEFER until the B2 scope sign-off."),
    ("gap",),
    ("table", ["#", "Candidate", "Source (Panoramic)", "Tier", "What it adds to OC", "Recommend", "Decision"], [
        ["A1", "FOLR1 staining (StainingIntensity 1/1+/Weak, 2/2+/Moderate, 3/3+/Strong, 0, Other + PercentStaining)", "Enhanced_OvarianBiomarkers", "Standard", "raw FRa IHC intensity (vendor-labelled) + % staining. RE-READ: the named high/moderate/low EXPRESSION TIERS used for FRalpha scoring are NOT in the docs - they would be DERIVED (cut-offs to decide). mirvetuximab-style scoring; NH protocol wanted it", "Consider", "Pending"],
        ["A2", "ExtentOfDebulking {Optimal/Suboptimal/Unknown}", "Enhanced_Ovarian", "Standard", "surgical-outcome dimension beyond residual status", "INCLUDE", "Pending"],
        ["A3", "DiseaseGrade (tumour grade)", "unconfirmed (OC dict lacks it)", "-", "RE-READ: the ovarian data dict has only Histology, NO Grade; a Grade field exists only for Endometrial; the ovarian KC variable-detail article was not captured -> UNCONFIRMED for OC. Confirm on the delivered data dict", "DEFER", "Pending"],
        ["A4", "T / N / M Stage (substaged)", "Enhanced_Ovarian", "Standard", "TStage/NStage/MStage at diagnosis, additive to the FIGO GroupStage the EDM uses (full value lists [verify] on data dict)", "Consider", "Pending"],
        ["A5", "ctDNA (ReportDate, TestResult, TestMeasurement)", "Enhanced_Ovarian_ctDNA", "Standard", "Natera Signatera MRD/ctDNA (report-level); emerging biomarker", "Consider", "Pending"],
        ["A6", "Insurance (PayerCategory + 9 plan-type flags + plan dates)", "Insurance", "Standard", "payer mix / access analyses; NH protocol listed insurance", "Consider", "Pending"],
        ["A7", "NGS / genomics metadata", "Enhanced_OvarianBiomarkers", "Standard", "RE-READ: NO separate NGS gene/variant table in the Panoramic doc/data-dict; genomics is the Enhanced_OvarianBiomarkers metadata (alteration class, Germline/Somatic, method incl. NGS, lab, dates). (dataprep SRC_NGS 'Enhanced_OvarianNGS / NGSTestDate' to confirm.)", "DEFER", "Pending"],
        ["A8", "Real-World Adverse Events (rwAE) - scaled + detailed", "Enhanced_[Disease]_AdverseEvents*", "Add-On", "safety/tolerability endpoints; entirely new family", "DEFER", "Pending"],
        ["A9", "Reasons for Discontinuation (RFD) - per-drug reason", "Enhanced_[Disease]_DiscontinuationReason", "Custom", "the REASON a drug stopped (complements EDM TTD timing)", "Consider", "Pending"],
        ["A10", "CCI Comorbidities (Charlson Yes/No flags)", "Enhanced_[Disease]_Comorbidities", "Custom", "comorbidity burden for risk adjustment", "Consider", "Pending"],
        ["A11", "Additional Malignancies (other invasive/heme)", "Enhanced_[Disease]_Malignancies", "Custom", "second-primary context", "DEFER", "Pending"],
        ["A12", "Detailed Orals (dose, schedule, episode-end + reason)", "Enhanced_[Disease]_OralsDetail(+_EpisodeEndReason)", "Custom", "dose-level oral-therapy detail beyond start/end", "DEFER", "Pending"],
    ]),
    ("note", "Field-level draft specs for these candidates now live IN the section tabs (5.Demographics / 6.Clinical characteristics / "
             "8.Outcomes), flagged in the 'Origin' column as 'ADDITIVE (not in prior spec)' and shaded blue (all DEFER/proposed). "
             "A1 FOLR1 staining: raw intensity/percent are documented; the high/moderate/low cut-offs are NOT - keep DEFER until defined + signed off. "
             "rwP / Scaled rwR / Platinum Status are NOT here - they are Add-Ons that existing EDM variables depend on (see Cross-Validation subscription)."),
], widths=[5, 26, 24, 10, 40, 12, 12])

# ===== PDF Evidence Register =====
ws = wb.create_sheet("Source Register")
render(ws, [
    ("title", "Source Register - what each part is evidenced by + sign-off status"),
    ("sub", "What each rule/section is evidenced by (by CONTEXT, not document) and whether it is signed off. The EDM baseline is a "
            "first-pass transcription of the prior EDM program spec (≈{{NVERIFY}} [verify]); the Panoramic side is drawn from the Flatiron "
            "documentation. Sign-off confirms each section against its source; the original approved EDM program spec supersedes the transcription."),
    ("gap",),
    ("section", "EDM baseline sections (context: prior EDM program spec)"),
    ("table", ["Section / tab", "Source", "Note", "Sign-off"], [
        ["4.StudyPop", "Prior spec", "", "Pending"],
        ["3.Data Prep", "Prior spec", "", "Pending"],
        ["5.Demographics", "Prior spec", "", "Pending"],
        ["6.Clinical characteristics", "Prior spec", "platinum block is the highest sign-off priority", "Pending"],
        ["7.Treatment variables", "Prior spec", "", "Pending"],
        ["8.Outcomes", "Prior spec", "RWR response value-set names inferred - confirm", "Pending"],
        ["9.PROC PSOC Strategy", "Prior spec", "machine-checked STEP 1-2", "Pending"],
        ["9.PROC platinum sensitivity", "Prior spec", "", "Pending"],
        ["6.Clinical death / mortality", "Prior spec", "", "Pending"],
        ["6.Clinical biomarkers (ad-hoc)", "Prior spec", "", "Pending"],
        ["Natural-history study variables (feeds clinical/outcomes)", "Prior spec", "", "Pending"],
    ]),
    ("section", "Panoramic deltas / additive elements (context: Flatiron documentation)"),
    ("table", ["What it evidences", "Source", "Note", "Sign-off"], [
        ["LineSetting rules + splitting + OST + PARP carve-out", "Flatiron LOT rules", "", "Pending"],
        ["Platinum Status table (grain/values/derivation/thresholds 91/184)", "Flatiron Panoramic doc", "thresholds confirmed", "Pending"],
        ["Core OC table incl. RecurrenceDate", "Flatiron data dictionary", "", "Pending"],
        ["Biomarkers (BRCA/HRD/GIS/FOLR1 + staining)", "Flatiron Panoramic doc", "", "Pending"],
        ["rwP progression inputs (+ physical-exam evidence)", "Flatiron Panoramic doc", "", "Pending"],
        ["rwR response value set", "Flatiron Panoramic doc", "", "Pending"],
        ["Mortality_V2 midpoint imputation", "Flatiron Panoramic doc", "", "Pending"],
        ["LOT construction (28d/120d gap/90d OST/maintenance)", "Flatiron LOT rules", "", "Pending"],
        ["Subscription tiers (Standard/Add-On/Custom)", "Flatiron data dictionary", "", "Pending"],
        ["Labs/units, ECOG, Demographics, Orals, SES, Diagnosis", "Flatiron data dictionary", "", "Pending"],
    ]),
    ("section", "Other source context (not section sign-off)"),
    ("table", ["Source", "What it is", "Use"], [
        ["Reconstructed R (ovarian_rdap.R; DEFECTIVE)", "a reconstructed, defective port of the original program", "clue source ONLY - the prior spec overrides it (e.g. the surgn=stagen bug). Never authoritative. (NB: PFS2 is a real EDM outcome, NOT an R artifact.)"],
        ["RWDP methodology", "the cross-product RWDP methodology (Ovarian Methods DRAFT)", "confirms the line-construction rules under LineSetting (28-day line, oral overlap, maintenance/gap/end-date)"],
        ["Flatiron LOT rules", "the Line-of-Therapy construction + LineSetting rules (Flatiron Common Data Tables LOT Rules section), corroborated by the RWDP methodology", "the source for treatment-setting / line-splitting / OST / maintenance / PARP carve-out / oral-span; DISTINCT from the generic data dictionary"],
        ["Flatiron data dictionary", "the data dictionary delivered with the RECEIVED EDM data (Data Model 2026-05-28; generic/NSCLC example values)", "describes the EDM data structure / value sets - it does NOT confirm the Panoramic ovarian feed; the definitive ovarian Panoramic data dictionary is still needed (diff on first feed)"],
        ["Flatiron Panoramic doc", "the Ovarian Panoramic documentation bundle", "the Panoramic-side source for the deltas + additive candidates"],
    ]),
    ("note", "Highest-leverage move for the EDM baseline sign-off: obtain the original approved EDM program spec - it supersedes the "
             "transcription wholesale and closes Gate 1 faster than re-checking section by section. The Flatiron documentation cannot certify the EDM transcription."),
], widths=[40, 26, 40, 12])

# ===== SDR Read Confirmation =====
ws = wb.create_sheet("SDR Read Confirmation")
render(ws, [
    ("title", "SDR Read Confirmation - pre-confirmation of the 126 confirm-the-read rows vs the source scans"),
    ("sub", "Every section-tab variable owned by SDR and flagged 'first-pass [verify]' (the confirm-the-read items) was re-read "
            "against the ORIGINAL GSK program-spec scans, section by section. Result: 122 confirmed, 4 corrected, 0 unresolved. "
            "Confirmed rows now read 'SDR-confirmed vs source scan (ratify)' in their Status column; the 4 corrected rows carry the "
            "fix inline + 'CORRECTED vs source scan'. This is a PRE-confirmation to shorten SDR's list - it does NOT replace SDR "
            "sign-off, and the original approved EDM program spec (Teams Excel) still supersedes the transcription if obtained."),
    ("note", "Method: each section was rendered from the source documents and read transcription-by-transcription; only what the source "
             "legibly shows was accepted - nothing inferred. 'Confirmed-as-family' means a parametric family (e.g. LOTi i=1..5, "
             "PCYCLi) appears once in the source as an indexed pattern, so confirming the pattern confirms all members."),
    ("gap",),
    ("section", "Summary by section"),
    ("table", ["Section", "SDR rows", "Confirmed", "Corrected / open"], [
        ["3.Data Prep", "14", "14", "0 (RAWRWD + BASEDUR cross-confirmed in sibling scans)"],
        ["4.StudyPop", "7", "7", "0"],
        ["5.Demographics", "11", "11", "0 (REGION/ETH/SES legible in full - 3 old [verify]s cleared)"],
        ["6.Clinical characteristics", "42", "38", "4 corrected (SURG / SURGN / RD / RDN)"],
        ["7.Treatment variables", "43", "43", "0 (all confirmed-as-family from the LOTi i=1..5 pattern)"],
        ["8.Outcomes", "9", "9", "0 (ID3MOSFU >=91, VIS120 >=120, TSSTFL >= thresholds all verified)"],
        ["TOTAL", "126", "122", "4 corrected, 0 unresolved"],
    ]),
    ("gap",),
    ("section", "Short list - items still needing SDR attention"),
    ("note", "Everything else is pre-confirmed; these are the only rows that changed or carry a caveat."),
    ("table", ["Item", "Variable(s)", "What the re-read found / change", "SDR action"], [
        ["Correction", "SURG / SURGN", "The SURG=2 (surgery-type) branch: operator is '<=' not '<', and the source includes an additional 'or surgerydate_sasdt > lastdate11' clause that the first pass had dropped. Definitions updated in 6.Clinical.", "Ratify the corrected derivation"],
        ["Correction", "RD / RDN", "Residual-disease branch 1 keys on ISSURGERY='No/unknown' (the first pass had RESIDUALDISEASESTATUS='No surgery' - wrong field + value). In RD this branch also appears struck through in the source. Definitions updated.", "Ratify; confirm whether the struck-through branch is active"],
        ["Cross-confirmed", "RAWRWD", "The data-prep scan cell is masked by an overlay, but the same variable reads 'Ovarian Cancer EDM' legibly in the StudyPop scan.", "Note only - value confirmed"],
        ["Cross-confirmed", "BASEDUR", "The data-prep scan does not restate it, but the 'index date - MINAVAILDATE + 1' rule is legible in the clinical-characteristics scan.", "Note only - rule confirmed"],
    ]),
    ("note", "Net effect: the confirm-the-read workload drops from 126 rows to ratifying 4 corrections (plus 2 note-only cross-confirms). "
             "The remaining open items in the workbook are NOT SDR reads - they are BIO/PO decisions, DE feed-mapping, and engine work (see Biostats Decision Pack + Approval Gate)."),
], widths=[16, 16, 60, 26])

ws = wb.create_sheet("Data Profiling Checklist")
render(ws, [
    ("title", "Data Profiling Checklist — run on first Panoramic feed (Gate 4)"),
    ("sub", "Proves/disproves the logical-compatibility assumption and closes the physical-mapping + data-profile dimensions. "
            "Owner DE; results feed back to the deltas + decision pack. Nothing here is settled until observed in data."),
    ("gap",),
    ("section", "Physical mapping & schema"),
    ("table", ["Check", "How", "Status"], [
        ["physical mapping (logical->Panoramic table/column)", "SHOW TABLES / DESCRIBE; declare formats.Panoramic rename only where a name differs from the EDM default", "Pend"],
        ["delivered table/column names + types vs Data Dictionary tab", "diff received schema vs the Data Dictionary tab; note data-dict-lags-KC fields (RecurrenceDate)", "Pend"],
        ["grain & keys / row counts / duplicates", "COUNT vs COUNT(DISTINCT key); GROUP BY HAVING", "Pend"],
    ]),
    ("section", "Subscription / delivery (must-confirm)"),
    ("table", ["Check", "How", "Status"], [
        ["rwP Add-On delivered", "table present + populated (else rwPFS + EDM platinum PFI cannot be built)", "Pend"],
        ["Scaled rwR Add-On delivered (if RWR in scope)", "table present + value set", "Pend"],
        ["Platinum Status Add-On (only if adopting/validating vendor status)", "table present; grain = per non-neoadj platinum line; {Sensitive,Resistant,Refractory,null}", "Pend"],
    ]),
    ("section", "Value sets & completeness"),
    ("table", ["Check", "How", "Status"], [
        ["LineSetting present + value set + null %", "SELECT DISTINCT LineSetting; {Neoadjuvant,Adjuvant,Advanced,Off Systemic Therapy}; null %", "Pend"],
        ["RecurrenceDate non-null %", "non-null % (drives the Adj-vs-Advanced null-handling DECISION; the LOT rules specify no fallback)", "Pend"],
        ["CA-125 unit strings", "SELECT DISTINCT TestUnitsCleaned for CA-125; confirm kU/L vs IU/L + variants", "Pend"],
        ["ECOG-5 suppression", "confirm 5 delivered as Unknown w/ NULL date", "Pend"],
        ["null & contradiction patterns", "per-field null %, cross-field checks", "Pend"],
    ]),
    ("section", "Golden-compare (stratified - parity is NOT expected row-for-row)"),
    ("table", ["Check", "How", "Status"], [
        ["count patients whose LineNumber sequence differs from EDM", "split / Off-Systemic-Therapy histories (treatment-setting delta)", "Pend"],
        ["cross-tab Panoramic PlatinumStatus vs recomputed EDM PLAT_SEN_v1", "quantify disagreements at 90/91 & 183/184 + grain/window", "Pend"],
        ["death flag/date vs Enhanced_Mortality_V2", "OS/rwPFS/TTE deltas from Mortality_V2 vs Enhanced_Mortality_V2", "Pend"],
        ["stratify golden-compare", "unchanged / split / OST / PROC / mortality-source-different histories", "Pend"],
    ]),
], widths=[44, 56, 10])

# Worked Examples
ws = wb.create_sheet("Worked Examples")
render(ws, [
    ("title", "Worked Examples"),
    ("sub", "Illustrative. Platinum cases pending sign-off (thresholds = SDR confirm-the-read; PROC membership / source-of-truth = BIO)."),
    ("gap",),
    ("section", "A. Treatment setting"),
    ("table", ["Case", "Surgery / IsSurgery", "Chemo start", "Recurrence", "-> LineSetting"], [
        ["A Neoadjuvant", "2021-08-01 / Yes", "2021-05-01 (before surgery)", "—", "Neoadjuvant"],
        ["B Adjuvant", "2021-03-01 / Yes", "2021-04-01 (after surgery)", "2022-06-01", "Adjuvant"],
        ["C Advanced (no surgery)", "— / No", "2021-03-01 (after dx)", "—", "Advanced"],
        ["X EDM, no RecurrenceDate", "2021-03-01 / Yes", "after surgery", "(missing)", "Adjuvant-vs-Advanced NOT derivable -> Unknown"],
    ]),
    ("section", "B. Platinum (PFI=progression - last non-maint platinum date prior line; <=90 Refractory / 90-183 Resistant / >183 Sensitive)"),
    ("table", ["Case", "last platinum", "progression", "PFI(d)", "PLAT_SEN_v1", "PROC?"], [
        ["1 Sensitive", "2022-04-15", "2022-12-20", "249", "Sensitive", "No"],
        ["2 Resistant->PROC", "2022-04-15", "2022-08-20", "127", "Resistant", "YES"],
        ["3 Refractory", "2022-04-15", "2022-06-10", "56", "Refractory", "No (excluded)"],
        ["B1 PFI=90 (boundary)", "2022-04-15", "2022-07-14", "90", "Refractory (<=90)", "No"],
        ["B2 PFI=183 (boundary)", "2022-04-15", "2022-10-15", "183", "Resistant (<=183)", "YES"],
        ["4 Not eligible / death-no-prog", "2022-04-15", "none", "undef", "Not eligible", "No"],
    ]),
    ("note", "These cuts (<=90 / 90<PFI<=183 / >183) are the 2L determination. At 3L+ a freshly-scored line uses 0<PFI<=183 -> Resistant (NO Refractory band), and a line whose prior line was Refractory/Resistant chains to 'Primary prior-LOT' (see B-PROC + 9.PROC PLAT_SEN_v1). Boundary cases B1/B2 illustrate the inclusive upper bounds; full example set (multi-progression, multi-platinum, missing dates, v1!=v2) pending sign-off."),
    ("section", "B-PROC. Which line indexes a PROC patient (index = START of the FIRST 2L+ line classified 'Resistant'; ONE index per patient, pick:first)"),
    ("table", ["Patient & line", "prior-line last platinum", "qualifying progression", "PFI(d)", "PLAT_SEN_v1 (this line)", "First Resistant? -> PROC index"], [
        ["Patient A, 2L", "2020-03-01 (1L plat end)", "2020-12-01", "275", "Sensitive (PFI>183)", "no (Sensitive)"],
        ["Patient A, 3L", "2021-03-15 (2L plat end)", "2021-08-15", "153", "Resistant (prior=Sensitive; 0<PFI<=183)", "YES -> index = 3L start (2021-09-01)"],
        ["Patient A, 4L", "(chained from prior)", "-", "-", "Primary resistant/refractory in a prior LOT", "already set at 3L (pick:first)"],
        ["Patient B, 2L", "2022-01-01 (1L plat end)", "2022-05-15", "134", "Resistant (90<PFI<=183)", "YES -> index = 2L start (2022-05-20)"],
    ]),
    ("note", "Same rule, DIFFERENT anchor line. Patient A is platinum-SENSITIVE entering 2L (PFI 275) so does NOT enter PROC there; they turn RESISTANT entering 3L (PFI 153), so PROC indexes at 3L start. Patient B is RESISTANT already entering 2L (PFI 134), so PROC indexes at 2L start. THAT is what the 3.Data Prep note means by 'anchored to different time points across patients' - Patient A's clock starts at 3L, Patient B's at 2L. Once a line is Resistant/Refractory, later lines chain to 'Primary prior-LOT', so pick:first takes the earliest resistant line and avoids double-counting. OPEN (11.Review Decisions): the current rule keys on the 'Resistant' state only - whether a Refractory-first patient (PFI<=90) also enters PROC is the open PROC-membership decision."),
    ("section", "C. Adj->Advanced line-split (CORE rule PDF-defined; D2 = edge cases). Rule: adjuvant continuing >=14d after recurrence is SPLIT; 2nd line=Advanced, start=LAST episode <14d after recurrence"),
    ("table", ["Case", "Recurrence", "Adjuvant-line episodes (days after recurrence)", "Continues >=14d after recurrence?", "-> Split / Advanced-line start"], [
        ["S1 No split", "2022-06-01", "2022-04-01 (pre), 2022-06-08 (+7)", "No (last episode +7 < 14)", "NOT split -> whole line stays Adjuvant"],
        ["S2 Split", "2022-06-01", "2022-06-08 (+7), 2022-06-22 (+21)", "Yes (+21 >= 14)", "SPLIT -> Advanced starts 2022-06-08 (last episode <14d after recurrence); named by post-recurrence drugs"],
        ["S3 EDGE: exactly recur+14", "2022-06-01", "2022-06-08 (+7), 2022-06-15 (+14)", "Yes IF day-14 inclusive [D2 edge]", "If inclusive: SPLIT -> Advanced starts 2022-06-08 (+14 episode falls in Advanced). Confirm inclusivity."],
        ["S4 PARP carve-out", "2022-06-01", "2022-06-08 (+7), 2022-06-22 (+21), contains olaparib", "Yes, but PARP carve-out applies", "NOT split (rev 30-APR-2026) -> stays one line"],
    ]),
    ("note", "S3 is the only genuinely open point (is recurrence+14 inclusive?). Remaining D2 edge items: end-date truncation of the Adjuvant line, source-row assignment, and drugs whose episode spans the boundary. Sign off p.64 then confirm these four."),
], widths=[24, 22, 24, 10, 28, 18])

# (Source Evidence tab removed — merged into PDF Evidence Register: per-section sign-off + 'Other source documents' section.)

# OC Backlog
ws = wb.create_sheet("OC Backlog")
render(ws, [
    ("title", "OC Backlog — non-delta gaps & enhancements"),
    ("sub", "Variable-level gaps are flagged in the section tabs (Status / [verify] / Open decision). These are the themed decisions (Appr = Decide; or OOS = out of scope)."),
    ("gap",),
    ("table", ["#", "Item", "Appr"], [
        ["B1", "BRCAxHRD composite + subgroup flags + 'closest' mirror", "Decide"],
        ["B2", "Biomarker code 4 'None' for BRCA/HRD/GIS/FOLR1 + per-case truth tables", "Decide"],
        ["B3", "Lab tri-state + value/date/unit-output vars + unit/labcomponent filters + window", "Decide"],
        ["B4", "BSA / FUDUR / PFUDUR / INDEXYR / DTHFL / INIT-INITYR — all confirmed IN the EDM baseline; scaffold-coverage gaps to BUILD (NOT additive/new)", "Decide"],
        ["B5", "GENDER/GenderN, SES 1-5 (+selection rule), birthsex, practice window", "Decide"],
        ["B6", "Per-line LOTi family + flags + CSD + FNIRA + PCYCL", "Decide"],
        ["B7", "TTD/TTNT/TSST + RWR family (line_outcomes)", "Decide"],
        ["B8", "max_lines 6->5 / PFS2 scope: keep vs deprecate (PFS2 IS in the EDM spec - contract + lineage)", "Decide"],
        ["B9", "RecurrenceDate + medication-order source (hard dependencies)", "Decide"],
        ["B10", "New EDM/Pano fields (ExtentOfDebulking, residual-size bands, T/N/MStage, NGS, DnaType, staining)", "OOS"],
    ]),
], widths=[6, 64, 10])

# Engine Assessment (reclassified to ACTUAL engine capability)
ws = wb.create_sheet("Engine Assessment")
render(ws, [
    ("title", "Engine Assessment — engine PATTERN vs OC opt-in"),
    ("sub", "IMPORTANT: 'pattern exists' means the LOCKED engine already does this FOR OTHER PRODUCTS. It does NOT mean OC is "
            "ready — the OC config has NOT opted in and the OC output is NOT validated. 'Route=Config' = wire up + validate "
            "OC; it is still real work and still gated by Approval. Genuine NEW engine extensions are the 'Engine' rows."),
    ("gap",),
    ("table", ["Capability", "Engine pattern (other products)", "Route for OC"], [
        ["Per-line LOTi name/start/end/last-activity/duration/category + maintenance variants", "pattern exists in the treatment stage; OC not opted-in / not validated", "Config (opt-in + name reconciliation + LOTiED semantics) + validation"],
        ["TTD / TTNT / TSST / VIS120", "line_outcomes block exists; OC not opted-in / not validated", "Config (opt-in) + validation"],
        ["Lab closest value + date + unit-filter + tie-break + tri-state", "pattern exists (Present/Unknown/Missing optional); OC not opted-in", "Config (opt-in); + small Engine for published ...VU unit column"],
        ["rwPFS +14 exclusion / last-clinic-note censor / eligibility flag / cohort restriction", "configurable in the engine; OC config just doesn't set them", "Config (opt-in) + source validation"],
        ["Non-exclusive per-line class flags (LiPLAT/LiBEV/...)", "single first-match lotcat today (no per-class flags)", "Engine (new)"],
        ["Platinum v1/v2 + PROC + PCYCLiED + eligibility", "current proc.py is MATERIALLY DIFFERENT: 2-state (Sens/Resist) only; PFI = prior-line-end -> current-line-start in MONTHS; NO Refractory; NO progression-window eligibility; NO prior-resistant carry-forward; NO v1/v2", "Engine (NEW) — 'keep the EDM derivation' = BUILD a new algorithm, not merely configure"],
        ["BRCAxHRD composite (multi-variable)", "'pending' — not implemented", "Engine (new)"],
        ["RWR derivations", "absent", "Engine (new)"],
        ["Treatment-line normalization/splitting (LineSetting)", "per-setting model exists; splitting does not", "Engine (new)"],
        ["TTD month conversion (+1 day)", "EDM spec: (LOTiED - INDEXDT + 1)/30.4375; current engine OMITS the +1", "Engine fix (known engine-vs-baseline discrepancy)"],
        ["rwPFS event: progression-vs-death priority", "EDM spec: progression PRIORITIZED (day-level) even when after imputed death; current engine uses least(progression, dthdt)", "Engine fix — confirm intended rule, then implement"],
        ["TSSTFL thresholds (cohort-specific)", "SOURCE-DEFINED: COHORTN(2,3)->LOTN>=3; (4,5)->LOTN>=4; 6->LOTN>=5; or death (outcomesoc p5). Engine generalizes LOTN>N", "ENG: align engine to >=N per cohort vs the signed-off baseline"],
    ]),
    ("note", "Two headlines: (1) 'engine patterns exist' does NOT mean OC is ready — Config rows are opt-in + golden-compare, gated "
             "by Approval. (2) Several rows are genuine ENGINE-vs-BASELINE discrepancies (platinum algorithm, TTD +1, PFS/death "
             "priority, TSST operator) — the current engine does NOT implement the EDM baseline; building it is real work."),
], widths=[40, 40, 30])

# Approval Gate (split + corrected statuses)
ws = wb.create_sheet("Biostats Decision Pack")
render(ws, [
    ("title", "Biostatistics decision pack — pre-read sorted by owner & evidence"),
    ("sub", "Turns the open sign-off gates into CONFIRM/DECIDE, not RESEARCH. TWO BOUNDARIES: (1) Flatiron settles the Panoramic "
            "side ONLY - it cannot certify the GSK EDM transcription (Gate 1, Sec 4) nor which rule the legacy EDM ADS used. "
            "(2) 'Vendor-documented' != 'approved': a Sec-1 tick means 'this is what the cited vendor page says', NOT 'approved "
            "for 202606' and NOT 'the feed delivers it' (field names/value strings/day boundaries need visual sign-off + first-feed "
            "mapping). Owners (SDR/DE/ARCH/BIO/COMM/PO) defined below so the load is shared, not dumped on biostats."),
    ("gap",),
    ("section", "Owners (so the load is shared)"),
    ("table", ["Code", "Owner", "Closes"], [
        ["SDR", "Source-document reviewer / Flatiron SME", "confirm what a vendor page states; metadata/cosmetic [verify]"],
        ["DE", "Data engineer / data quality", "physical table/column mapping; null %, value distributions, unit strings"],
        ["ARCH", "Data-product architect (+ programmer)", "line-splitting / canonical line spine; OST representation; line-number consumption"],
        ["BIO", "Biostatistics", "analytic choices: PROC source/membership, death imputation, progression-vs-death, RWR mapping"],
        ["COMM", "Commercial / vendor management", "subscription / Add-On procurement"],
        ["PO", "Product owner / governance (+ biostats input)", "PFS2, max-lines, additive scope; release-parity acceptance"],
    ]),
    ("section", "Gate map - where the Flatiron docs help"),
    ("table", ["Gate", "What it certifies", "Eased?", "How"], [
        ["Gate 1", "Baseline transcription (we copied the GSK EDM spec faithfully; ≈{{NVERIFY}} [verify])", "No", "Corroborate only - Sec 4 rule-level triage; needs the GSK source / Teams Excel"],
        ["Gate 2", "Panoramic source sign-off (the Panoramic side is read correctly)", "Partial", "Substantially reduced, NOT closed - Sec 1 pre-filled + page-anchored; pending visual sign-off + feed mapping"],
        ["Gate 3", "Business decisions (scope / source-of-truth / additive)", "Partial", "Sec 2 guided + Sec 3 business"],
        ["Gate 4", "First-feed profiling (EDM<->Pano outputs match on real data)", "No", "Needs data - profiling checklists in the delta docs"],
    ]),
    ("section", "Sec 1 - Vendor-documented (confirm the transcription; delivery mapping pending) -> REDUCES Gate 2"),
    ("note", "A tick = 'this is what the cited vendor page says' - NOT approval, NOT proof the feed delivers it. Semantic-equivalence "
             "claims (death/rwR/rwP) were MOVED to Sec 2. Owner SDR unless noted. (All Sec-1 rows are direct PDF page-reads, i.e. Basis = PDF.)"),
    ("table", ["#", "What the Flatiron page states", "Detail", "Anchor", "Owner", "Confirm"], [
        ["F1", "Platinum day thresholds", "Refractory <=91d; Resistant 92-183d; Sensitive >=184d; null otherwise", "flatirompt2 p.51 (2 reads)", "SDR", "Pending"],
        ["F2", "Platinum table grain + value set", "1 row per non-neoadjuvant platinum-containing line (multiple/pt); {Sensitive,Resistant,Refractory,null} only", "flatirompt2 p.50-52", "SDR", "Pending"],
        ["F3", "Platinum PFI definition (Panoramic)", "(first recurrence/progression >=14d after FIRST platinum episode) - (LAST platinum episode of the line)", "flatirompt2 p.51", "SDR", "Pending"],
        ["F4", "LineSetting value set", "{Neoadjuvant, Adjuvant, Advanced, Off Systemic Therapy} (exact field name + value strings still [verify] vs the ovarian data dict)", "flatiromdata1 p.64", "SDR", "Pending"],
        ["F5", "Line splitting at setting boundaries", "split at Neoadj->Adj and Adj->Advanced; PARP-containing lines NOT split (rev 30-APR-2026). CORE split rule is PDF-defined (2nd line=Advanced, start=last episode <14d after recurrence); D2 tracks EDGE cases only", "flatiromdata1 p.64/68", "SDR", "Pending"],
        ["F6", "Off-Systemic-Therapy line", "created at a >=90-day gap; carries a LineSetting but does NOT advance the LineNumber (labels the gap, not a treated regimen); FirstRecurrenceDate removed (rev 30-SEP-2025). [verify exact LineName/IsMaintenance]", "flatiromdata1 p.64/68", "SDR", "Pending"],
        ["F7", "PARP carve-out drug list", "niraparib / olaparib / rucaparib named (talazoparib NOT named -> Sec 2 D6)", "flatiromdata1 p.64/68", "SDR", "Pending"],
        ["F8", "RecurrenceDate", "DOCUMENTED in the newer KC Enhanced_Ovarian article (earliest recurrence-event date; 4 defs), Standard. NB the data dict OMITS it (version lag) -> delivery version + completeness PENDING", "flatiromdata1 p.39-48", "SDR/DE", "Pending"],
        ["F10", "LOT construction rules", "28-day line; 3-day oral overlap; >120d gap advances line; >=90d gap -> OST; Anastrozole excluded", "flatiromdata1 p.62-68", "SDR", "Pending"],
        ["F11", "Maintenance criteria", "bev (>=1d overlap + >=21d after non-maint drop, or >=30d within platinum line); PARP within 120d of platinum line; paclitaxel/gemcitabine >=28-30d", "flatiromdata1 p.62-68", "SDR", "Pending"],
        ["F14", "Oral-span rule", "stop >60d then restart -> multiple spans; <=60d -> single span", "flatiromdata1 p.76-83", "SDR", "Pending"],
        ["F15", "Labs / units", "LOINC-normalized; CA-125 -> LOINC 10334-1, kU/L [verify code]; date=max(resultdate,testdate). CANDIDATE mapping - contract needs normalized-unit logic for IU/L, kU/L, casing/spelling variants, unexpected units (confirm on feed)", "flatiromdata1 p.84-100", "SDR/DE", "Pending"],
        ["F16", "ECOG", "0-4; ECOG-5 suppressed -> delivered Unknown w/ NULL date; consistent with EDM Unknown/Missing handling", "flatiromdata1 p.26-38", "SDR", "Pending"],
        ["F17", "Demographics mapping", "EDM GENDER = Panoramic BirthSex (was 'Gender'); BirthYear is DE-IDENTIFIED for older patients (constrains derived age; EDM AGE top-code 85 is the analytic counterpart) - confirm exact top-code at each index date; Race/Eth/State match", "flatiromdata1 p.6-19", "SDR/DE", "Pending"],
    ]),
    ("section", "Sec 2 - Decide with guidance (Flatiron gives the input; the owner picks the contract) -> Gate 2->3"),
    ("note", "BASIS column = is the RECOMMENDATION itself backed by a source page (PDF), my reasoning (Inferred - scrutinise these), a "
             "mix (Mixed), or a commercial/scope call (Business)? Inferred rows are recommendations, NOT facts - the owner should decide."),
    ("table", ["#", "Decision", "Flatiron input (+ anchor)", "Recommendation / candidates", "Owner", "Decide", "Basis"], [
        ["D1", "Platinum source-of-truth for PROC", "Panoramic per-line Platinum Status (Add-On) {Sens/Res/Refr/null} only; EDM derivation carries Primary-prior-LOT/Not-eligible/v1-v2 + at-first-resistance indexing (flatirompt2 p.50-52)", "WORKING DIRECTION (build to this): EDM-derived = PROC source - it fits the CORE tables (engine-derived from LOT+DrugEpisode+progression) and matches the prior EDM analysis. Panoramic Platinum Status (Add-On) = cross-check ONLY, to discuss with Biostats - NOT adopted as source. Biostats/Program ratification is the formal gate.", "BIO", "Direction set; ratify", "Inferred"],
        ["D2", "Adj->Advanced split - edge cases (CORE RULE is PDF-defined)", "CORE RULE per flatiromdata1 p.64 sec5 (visually readable): adjuvant therapy that CONTINUES >=14 days after recurrence is SPLIT; the 2nd line = Advanced; its start date = the LAST therapy episode <14 days after recurrence; PARP carve-out drugs per p.68. This is NOT a pure judgement call.", "Confirm the core rule at p.64 sign-off, then pin the EDGE cases only: exactly day-14 (inclusive?), end-date truncation of the 1st line, source-row assignment, and drugs spanning the boundary. Provide >=3 worked date examples (incl. exactly recur+14).", "ARCH (BIO approves effect)", "Pending", "PDF"],
        ["D3", "OST representation in the analysis", "Per corrected p.64: OST carries a LineSetting but NO LineNumber; does NOT advance lines (flatiromdata1 p.64 sec6)", "Decide whether the analysis SURFACES OST at all (off-treatment time) and how. Architecture: keep source_line_number + analysis_line_number + line_setting_raw/std; OST must NOT silently shift EDM cohorts", "ARCH", "Pending", "Inferred"],
        ["D4", "Panoramic LineNumber consumption after splitting", "Splitting changes LineNumber vs EDM (flatiromdata1 p.64)", "Decide whether 1L/2L indexing uses Panoramic line numbers as-is or an EDM-compatible analysis number; expect golden-compare diffs for split/OST histories", "ARCH (BIO approves)", "Pending", "Inferred"],
        ["D5", "NEOADJ_CHEMO vs LineSetting='Neoadjuvant'", "Both exist; NOT equivalent (surgery-timing proxy vs source field)", "Keep NEOADJ_CHEMO; add LineSetting; optionally derive neoadj_concordance", "BIO", "Pending", "Inferred"],
        ["D6", "Talazoparib in the PARP carve-out", "Only niraparib/olaparib/rucaparib named (flatiromdata1 p.64)", "Confirm talazoparib in/out at the p.64 sign-off", "SDR (BIO)", "Pending", "PDF"],
        ["D7", "EDM baseline death-date imputation", "Both the death and clinical sections impute month-granular death to the 15th; clinical adds a same-month-as-follow-up -> last-day exception (+ year-only Jul-15/Dec-31). The earlier '15th vs last-day conflict' was overstated", "Confirm the 15th base + same-month exception reproduces the existing EDM / golden ADS output", "BIO", "Pending", "PDF"],
        ["D8", "Panoramic 202606 death-date imputation", "Mortality_v2 month-granular; Flatiron RECOMMENDS midpoint (~15th) (flatirompt2 p.13-15). DISTINCT from the LOT rule that generalises death to last-day for LINE END-DATE", "Preserve EDM rule for parity, OR approve a MODIFIED 202606 rule (midpoint). If MODIFIED -> classify MODIFIED derivation; impact OS/rwPFS/TTNT/TSST/death-based discontinuation", "BIO", "Pending", "PDF"],
        ["D9", "RWR value-set mapping (semantic reconciliation)", "Panoramic adds Non-Response/Pseudoprogression/Indeterminate/Not-documented; EDM RWRi maps only {CR,PR,SD,PD,Unknown,Missing} (flatirompt2 p.28-35,76-79)", "Reconcile via the truth table below - this is a potential derivation DELTA, not a settled fact", "BIO", "Pending", "Mixed"],
        ["D10", "rwP progression-evidence reconciliation", "Panoramic includes PHYSICAL-EXAM evidence + radiographic/pathologic/clinical-only/tumor-marker(OC)/mixed; OC scaffold OMITS physical-exam (flatirompt2 p.16-25)", "PROPOSE: include ALL progression-evidence flags except pseudoprogression; confirm the EXACT column names against the rwP article - candidates: IsRadiographic / IsPathologic / IsPhysicalExam / IsClinicalAssessmentOnly / IsTumorMarker* (incl. IsTumorMarkersOnly, OC) / IsMixedResponse* (incl. IsMixedResponseMentioned) - all names [verify]; progression date = min(ProgressionDate) across included evidence; exclude IsPseudoprogressionMentioned. Confirm names + completeness on first feed.", "ARCH/DE + BIO", "Pending", "Inferred"],
    ]),
    ("note", "D9 - RWR mapping: only the DIRECT rows (CR/PR/SD/PD, Indeterminate, no-row) are low-controversy. Non-Response and the "
             "multiple-assessment selection are GENUINE BIO calls and are NOT PDF-proven - do NOT treat them as recommended defaults. "
             "NB: the EDM maintenance note prioritises BEST response, so 'latest-in-window' is NOT supported."),
    ("table", ["Panoramic Assessment", "Mapping -> EDM RWRi", "Basis", "Residual question"], [
        ["CR / PR / SD / PD", "1 / 2 / 3 / 4", "direct value match (PDF)", "none"],
        ["Pseudoprogression", "4 = PD  [vendor-derived]", "Flatiron scaled rwR groups Pseudoprogression with PD", "BIO ratify the EDM collapse"],
        ["Non-Response (NR)", "UNRESOLVED - BIO decides", "NR has no EDM equivalent; the visible PDF does NOT establish a collapse (SD / Unknown / other all plausible)", "BIO: choose the collapse - do NOT default to SD"],
        ["Indeterminate", "5 = Unknown", "Flatiron scaled groups Indeterminate -> Unknown", "confirm"],
        ["Not documented (row present)", "5 = Unknown", "documented-as-unknown assessment; distinct from no row", "confirm Unknown(5) vs Missing(6)"],
        ["(no assessment row in window)", "6 = Missing", "not assessed in the iL+14 -> iL-end window", "confirm 'no row' = Missing"],
        ["(multiple assessments in window)", "UNRESOLVED - source suggests BEST (not latest)", "EDM maintenance note PRIORITISES BEST response; 'latest-in-window' is NOT established and conflicts with it", "BIO: best vs latest; confirm whether maintenance vs non-maintenance differ"],
    ]),
    ("section", "Sec 3 - Business / commercial (no Flatiron doc settles these) -> Gate 3"),
    ("note", "Subscription requirements CORRECTED - depends on the D1 source-of-truth choice. Tier facts: flatiromdata1 p.1-5; whether GSK subscribes is commercial."),
    ("table", ["Add-On", "Core EDM-parity requirement", "Additional purpose", "Owner"], [
        ["rwP (Real-World Progression)", "REQUIRED - rwPFS AND the EDM platinum PFI/progression logic", "-", "COMM"],
        ["Scaled rwR", "REQUIRED ONLY IF the RWR family stays in scope", "-", "COMM"],
        ["Platinum Status", "OPTIONAL for EDM-derived PROC (the EDM derivation does not consume it)", "required only to PUBLISH the vendor status, run the EDM-vs-vendor cross-check, or ADOPT it as source-of-truth", "COMM"],
    ]),
    ("note", "CORRECTION: the earlier 'without Platinum Status, platinum cannot be built' was wrong under the recommended keep-EDM approach (D1). Platinum Status is NOT required to derive PLAT_SEN_v1/v2 or PROC."),
    ("table", ["#", "Decision", "Note", "", "Owner", "Decide", "Basis"], [
        ["B1", "Subscription", "confirm rwP (required) + Scaled rwR (if RWR in scope) + Platinum Status (only if publishing/validating/adopting vendor status - see table above)", "", "COMM", "Pending", "Business"],
        ["B2", "Additive candidates A1-A12", "which to INCLUDE vs DEFER (see Additive Candidates tab). FOLR1 staining stays DEFER until high/moderate/low cut-offs visually signed off", "", "PO (BIO)", "Pending", "Business"],
        ["B3", "PFS2", "CORRECTED: PFS2 family (PFS2DT/PFS2FL/PFS2) IS in the EDM OC spec (outcomesoc p5-7) - NOT a port artifact. DECIDE: keep (finish transcription/sign-off) vs deprecate for 202606 (needs PO/BIO approval + confirm no downstream consumer).", "", "PO (BIO)", "Pending", "PDF"],
        ["B4", "max_lines 6->5", "RECOMMEND: 5 (treatcharoc enumerates lines i=1..5; 6 is a scaffold default). Confirm no published 6L cohort.", "", "PO", "Pending", "PDF"],
        ["B5", "PROC membership", "RECOMMEND: Resistant-only (StudyPop PROC = PLAT_SEN_v1='Platinum Resistant', indexed at first resistance). Confirm whether Refractory is in/out for 202606.", "", "BIO", "Pending", "PDF"],
    ]),
    ("section", "Sec 4 - Gate-1 rule-level triage (the GSK-source items Flatiron cannot certify)"),
    ("note", "Triage the ≈{{NVERIFY}} [verify] tokens at the RULE level. B=metadata (labels, QC initials, dates) -> SDR; C=cosmetic -> SDR. "
             "Category A (semantic) splits THREE ways, shown in the Route column: SDR = CONFIRM-THE-READ (the page is clear; the reviewer "
             "just confirms it, NOT a judgement call); BIO = GENUINE JUDGEMENT (a conflict or a 202606 decision); ENG = engine-vs-baseline "
             "fix. Only the BIO rows are true biostats decisions. Highest-leverage move = obtain the Teams Excel (supersedes the transcription)."),
    ("table", ["Rule", "Variable / family", "Source", "Uncertain text", "Route", "Resolution"], [
        ["R1", "EDM platinum day-cuts <=90 / 183", "Prior spec", "operator at 90 ('(correction)' annotation)", "SDR", "confirm the cut in the prior spec (Panoramic 91/184 is DIFFERENT, cannot infer EDM). The PROC-membership judgement is B5 (BIO)"],
        ["R2", "PFI PFSDT_IndexToPriorPlatEnd - PCYCL{i-1}ED", "Prior spec", "which prior-line episode", "SDR", "confirm the formula in the prior spec"],
        ["R3", "ELIG_PLAT_SEN_v1/v2 eligibility windows", "Prior spec", "eligibility condition", "SDR", "confirm the eligibility condition in the prior spec (escalate to BIO only if genuinely unclear)"],
        ["R4", "Cohort numbering 1-9 vs 1-11", "Prior spec", "which set is published", "BIO+PO", "reconcile which cohort set is published (vs golden output); do NOT silently add 10/11"],
        ["R5", "TSSTFL thresholds (cohort-specific)", "Prior spec", "operator (>= per cohort)", "SDR", "confirm-the-read: SOURCE-DEFINED COHORTN(2,3)->LOTN>=3; (4,5)->>=4; 6->>=5; or death. NOT a conflict. Engine align (ENG) to >=N."],
        ["R6", "TTD +1 convention", "Prior spec", "whether +1 applies", "ENG", "engine-vs-baseline fix: spec includes +1, engine omits it; apply +1 (not a biostats call)"],
        ["R7", "rwPFS progression-vs-death priority", "Prior spec", "priority wording", "BIO", "spec prioritises progression; engine uses least()=earliest - reconcile (changes PFSDT)"],
        ["R8", "ID3MOSFU >=91 / VIS120 >=120", "Prior spec", "operator / threshold", "SDR", "confirm >=91 / >=120 in the prior spec (read is clear; NOT a judgement call)"],
        ["R9", "DEATH_DT 15th base + same-month exception", "Prior spec", "confirm base + exception", "BIO", "NOT a conflict: both the death and clinical sections use the 15th base; last-day is the same-month-as-follow-up exception. Confirm vs golden ADS (= D7). Flatiron midpoint = Panoramic convention only"],
        ["R10", "surgery / NEOADJ (SURGN=4->Unknown)", "Prior spec", "mapping", "SDR", "confirm the mapping in the prior spec (source read done; just confirm)"],
        ["R11", "biomarker date max(coll,recv,result) vs max(recv,result)", "Prior spec", "which", "BIO/DE", "reconcile to one canonical biomarker-date formula"],
    ]),
    ("note", "SOURCE RE-READ (independent re-read of the prior-spec scans, this round) - CONFIRMS the reads at high confidence; "
             "these still need SDR/BIO ratification but the transcription is solid: R1 platinum cuts (Refractory PFI<=90 / Resistant 90<PFI<=183 / "
             "Sensitive PFI>183; 90 belongs to Refractory); R2 PFI = PFSDT_IndexToPriorPlatEnd - prior-line PCYCL{i-1}ED (cohort-specific); "
             "R5 TSSTFL (COHORTN 2,3->LOTN>=3; 4,5->>=4; 6->>=5; or death); R6 TTD carries the +1 inclusive-day term; R7 rwPFS PRIORITISES "
             "progression over death (death only if no eligible progression); R8 ID3MOSFU (MAXINDEX-INDEXDT)>=91 and VIS120 >=120 days after the "
             "index-LOT last episode; R10 SURGN (ISSURG='Yes' + missing surgery date -> 4 Unknown; PCS before 1L start, ICS within/after); "
             "R11 biomarker date = max(SpecimenReceivedDate, ResultDate). ALSO resolved: BMI>=30 -> group 4 (the transcribed 'BMI<=30' was wrong); "
             "rwPFS day-14 selection operator = '>= INDEXDT+14'. R4 (cohort set): clinical defines 1..11 (10=L1m+, 11=L2m+, both Index at 1L End) "
             "vs study-pop 1..9 - a genuine which-set-is-published decision, not a transcription error."),
    ("section", "The genuine biostatistics decision set (after the load is shared)"),
    ("note", "Once SDR/DE/ARCH/COMM items are peeled off, the core BIO decisions are small: 1 PROC source-of-truth (D1); 2 PROC "
             "membership (B5); 3 death imputation EDM-parity vs midpoint (D7+D8); 4 progression-vs-death (R7); 5 RWR mapping (D9); "
             "6 PFS2 (B3); 7 cohort 10/11 + max line slots (R4+B4); 8 line-splitting impact acceptance (D4). Everything else should "
             "arrive at the biostats meeting already resolved or pre-profiled by the right owner."),
    ("note", "Not a build input. This pack records evidence + recommendations; the DECISIONS remain the owners'. BASIS legend: PDF = "
             "stated on a source page; Inferred = my recommendation/reasoning (scrutinise); Mixed = part PDF / part inferred; Business "
             "= commercial/scope/governance call."),
], widths=[8, 22, 30, 26, 11, 24, 13])

ws = wb.create_sheet("Approval Gate")
render(ws, [
    ("title", "Approval Gate — two gates"),
    ("sub", "Gate A (Draft-YAML): rules stable enough to encode structure/placeholders. Gate B (Activation/Release): data + sign-off complete. Add owner/target/approver per row when scheduling."),
    ("gap",),
    ("section", "Gate A — before drafting YAML"),
    ("table", ["#", "Condition", "Status"], [
        ["A1", "Self-contained workbook: section tabs carry the rich per-variable spec (Variable/Definition/Values/Source/Evidence/Owner/Decision) + change-type on 2.CHANGES", "Done"],
        ["A2", "Cross-tab contradictions resolved (ID3MOSFU/VIS120/surgery/NEOADJ consistent = PDF-primary, R-conflict noted)", "Done"],
        ["A3", "Delta-impact matrix is by-cohort and index-relative-aware", "Done"],
        ["A4", "Engine routes framed as pattern-exists vs OC-opt-in (Config vs Engine)", "Done"],
        ["A5", "Every core variable: source/grain/type/derivation/tie-break/missing/codes + Origin", "Pending"],
        ["A6", "Each contracted family expanded to one variable per row", "Done"],
        ["A7", "Platinum v1/v2 + PROC truth tables + boundary worked examples complete", "Pending"],
        ["A8", "Disputed rules (ID3MOSFU/VIS120/surgery/NEOADJ/LineSetting/PFI) visually signed off vs the exact page", "Pending"],
        ["A9", "Workbook tabs tell one consistent story (no stale cross-refs / superseded framing) - cross-tab consistency is REVIEWER-confirmed, not self-certified (recurring drift found: TSST, PFS2, routing)", "Pending"],
    ]),
    ("section", "Gate B — before activation / YAML translation to release"),
    ("table", ["#", "Condition", "Status"], [
        ["B1", "Panoramic Platinum Status Table article — FOUND (flatirompt2 p50-52); source-of-truth DIRECTION set (build to EDM-derived; vendor Add-On = cross-check for Biostats) — Biostats/Program ratification + visual sign-off still pending", "Pending"],
        ["B2", "Panoramic feed profiled (Data Profiling Checklist); schema assumption proven", "Pending"],
        ["B3", "Study-population filters operationally defined", "Pending"],
        ["B4", "202606 scope decisions approved (max_lines 6->5, PFS2 keep-vs-deprecate, Refractory-in-PROC)", "Pending"],
        ["B5", "Golden-compare plan per the by-cohort impact matrix", "Pending"],
    ]),
], widths=[5, 72, 12])

# Plan & Validation
ws = wb.create_sheet("Plan & Validation")
render(ws, [
    ("title", "Plan & Validation — Excel-first"),
    ("sub", "Next pass = consistency + executable rules + sign-off (NOT more variables). YAML only after Gate A; release after Gate B."),
    ("gap",),
    ("table", ["Phase", "Goal"], [
        ["0 Scope", "assumptions (1.Cover)"],
        ["1 Self-contained review spec + punch-list", "THIS workbook (rich per-variable rows + change-type classification + decision pack)"],
        ["2 Assemble 3 artifacts", "(1) EDM baseline (first-pass transcription, tabs 3-9); (2) Panoramic delta contract; (3) mechanical 202606 merge"],
        ["3 Consistency + sign-off", "sign-off of disputed rules; complete platinum; expand families -> Gate A"],
        ["4 Article + data", "Platinum Status Table article; Panoramic profiling -> Gate B"],
        ["5 Draft YAML", "encode structure/placeholders once Gate A green"],
        ["6 Activate", "translate approved derivations; minimum engine changes; golden-compare by cohort"],
    ]),
    ("note", "Three-artifact target: Artifact 1 = EDM baseline, currently a FIRST-PASS transcription of the source PDFs rendered in "
             "tabs 3-9 (page sign-off pending — PDF Evidence Register; the original Teams program-spec Excel supersedes it if obtained). "
             "Artifact 2 = Panoramic delta (drafted — Panoramic Delta + Cross-Validation tabs). Artifact 3 = mechanical 202606 merge "
             "(not started). YAML only after Gate A; release after Gate B."),
], widths=[24, 64])

# ─────────────────────────────────────────────────────────────────────────────
# POST-BUILD: EDM-first, reviewer-facing restructure
# ─────────────────────────────────────────────────────────────────────────────
# (a) cross-reference text remap for renamed/merged tabs (order: longest first)
_XREF = [("Biostatistics decision pack", "Review Decisions"), ("Biostats Decision Pack", "Review Decisions"),
         ("Decision Pack", "Review Decisions"), ("SDR Read Confirmation", "Epi Source Check"),
         ("Additive Candidates", "New Panoramic Fields"), ("EDM-Pano Deltas", "Deltas"),
         ("Panoramic Delta", "Deltas")]
# (b) reviewer-facing owner labels (case-sensitive whole-word technical codes)
_OWN = [("SDR", "Epi"), ("BIO", "Biostats"), ("ARCH", "Implementation"), ("ENG", "Implementation"),
        ("DE", "Implementation"), ("COMM", "Program"), ("PO", "Program")]
def _relabel(s):
    for a, b in _XREF:
        s = s.replace(a, b)
    for code, lab in _OWN:
        s = re.sub(r"\b" + code + r"\b", lab, s)
    return re.sub(r"\b(Epi|Biostats|Program|Implementation)(?:/\1)+\b", r"\1", s)  # dedup X/X
for ws in wb:
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value, str):
                c.value = _relabel(c.value)

# (c) stamp the LIVE [verify] count so the control figure never drifts
_nverify = sum(c.value.count("[verify]") for ws in wb for row in ws.iter_rows()
               for c in row if isinstance(c.value, str))
for ws in wb:
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value, str) and "{{NVERIFY}}" in c.value:
                c.value = c.value.replace("{{NVERIFY}}", str(_nverify))

# (d) rename review/support tabs to plain reviewer language
_RENAME = {"Biostats Decision Pack": "11.Review Decisions", "SDR Read Confirmation": "12.Epi Source Check",
           "Additive Candidates": "13.New Panoramic Fields", "Source Register": "14.Source Register",
           "Worked Examples": "15.Worked Examples", "Approval Gate": "16.Approval Gate",
           "Plan & Validation": "17.Plan & Validation"}
for _old, _new in _RENAME.items():
    if _old in wb.sheetnames:
        wb[_old].title = _new

# (e) reorder: EDM-first review path; technical tabs demoted to a program/implementation appendix
_ORDER = ["1.Cover", "2.CHANGES", "3.Data Prep", "4.StudyPop", "5.Demographics", "6.Clinical characteristics",
          "7.Treatment variables", "8.Outcomes", "9.PROC PSOC Strategy", "10.Deltas", "11.Review Decisions",
          "12.Epi Source Check", "13.New Panoramic Fields", "14.Source Register", "15.Worked Examples",
          "16.Approval Gate", "17.Plan & Validation",
          "Data Dictionary", "Cross-Validation", "Data Profiling Checklist", "Engine Assessment", "OC Backlog"]
wb._sheets.sort(key=lambda s: _ORDER.index(s.title) if s.title in _ORDER else 999)

wb.save(OUT)
print("wrote", OUT, "| sheets:", len(wb.sheetnames), "| live [verify] count:", _nverify)
tot = 0
for s in wb.sheetnames:
    tot += wb[s].max_row
print("sheets:", len(wb.sheetnames), "| total rows:", tot)
