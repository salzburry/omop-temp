#!/usr/bin/env python3
"""Export the OC PANO 202606 workbook to a plain-text file (one block per tab).

Windows / VSCode:  python dump_to_text.py [optional\\out.txt]
macOS / Linux:     python3 dump_to_text.py [optional/out.txt]

Reads PROG_SPEC_RWDP_Ovarian_PANO_202606.xlsx from this folder and writes
PROG_SPEC_RWDP_Ovarian_PANO_202606.txt next to it (override with an argument).
Only dependency: openpyxl  (pip install openpyxl)
"""
import sys, os
import openpyxl

HERE = os.path.dirname(os.path.abspath(__file__))
XLSX = os.path.join(HERE, "PROG_SPEC_RWDP_Ovarian_PANO_202606.xlsx")
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "PROG_SPEC_RWDP_Ovarian_PANO_202606.txt")


def flat(v):
    """Flatten a cell to one line: bullets (\\n• ) -> '; ', other newlines -> space."""
    if v is None:
        return ""
    return str(v).replace("\n• ", "; ").replace("\n", " ").strip()


def main():
    if not os.path.exists(XLSX):
        sys.exit(f"workbook not found: {XLSX}\nRun generate_workbook.py first.")
    wb = openpyxl.load_workbook(XLSX, data_only=True)
    out = []
    out.append("PROG_SPEC_RWDP_Ovarian_PANO_202606 - text export")
    out.append(f"{len(wb.sheetnames)} tabs: {', '.join(wb.sheetnames)}")
    out.append("")
    for name in wb.sheetnames:
        ws = wb[name]
        out.append("=" * 100)
        out.append(f"TAB: {name}")
        out.append("=" * 100)
        for row in ws.iter_rows():
            parts = [p for p in (flat(c.value) for c in row) if p]
            if parts:
                out.append(" | ".join(parts))
        out.append("")
    with open(OUT, "w", encoding="utf-8") as fh:
        fh.write("\n".join(out))
    print(f"wrote {OUT} | {len(wb.sheetnames)} tabs")


if __name__ == "__main__":
    main()
