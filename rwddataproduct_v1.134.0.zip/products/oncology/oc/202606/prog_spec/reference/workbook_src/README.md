# OC PANO 202606 workbook — build source

Version-controllable **source** for the reviewer workbook
`../PROG_SPEC_RWDP_Ovarian_PANO_202606.xlsx`. The `.xlsx` is a binary build
output; this folder is the text/Python form you can diff, review, and
regenerate. **Workbook only** (does not touch the YAML config or the docs).

## Files
| File | What it does |
|---|---|
| `generate_workbook.py` | Builds the `.xlsx` (22 tabs): renders the per-variable section tabs 3–9 from `rows.json`, and the review-support tabs from structured blocks in the script itself. |
| `dump_to_text.py` | Exports the `.xlsx` to a plain-text `.txt` (one block per tab; diff/grep friendly). |
| `rows.json` | **All section-tab data in one file**, keyed by section (`studypop, dataprep, demo, clinical, treatment, outcomes, platinum`) → drives tabs **3–9**. Edit here to change per-variable content. |

### What lives where (important)
- **Tabs 3–9** (Data Prep, StudyPop, Demographics, Clinical, Treatment, Outcomes, PROC) — content comes from **`rows.json`**.
- **All other tabs** — `1.Cover`, `2.CHANGES`, `10.Deltas`, `11.Review Decisions`, `12.Epi Source Check`, `13.New Panoramic Fields`, `14.Source Register`, **`15.Worked Examples`**, `16.Approval Gate`, `17.Plan & Validation`, and the appendix — are authored as `render(...)` blocks **inside `generate_workbook.py`**. They are rebuilt every run; to change their content, edit the script.

## Run on Windows (VSCode)
1. Install **Python 3.9+** (python.org — tick "Add python.exe to PATH") and the VSCode **Python** extension.
2. Open this folder in VSCode, then in the integrated terminal (PowerShell):
   ```powershell
   pip install openpyxl
   python generate_workbook.py     # -> PROG_SPEC_RWDP_Ovarian_PANO_202606.xlsx  (this folder)
   python dump_to_text.py          # -> PROG_SPEC_RWDP_Ovarian_PANO_202606.txt   (this folder)
   ```
   - Write the `.xlsx` somewhere else:
     ```powershell
     python generate_workbook.py ..\PROG_SPEC_RWDP_Ovarian_PANO_202606.xlsx
     ```
   - macOS/Linux: use `python3` instead of `python`.

## Notes
- **Only dependency is `openpyxl`** (tested with 3.1.5). Nothing else, no internet needed.
- All paths are **script-relative** (`os.path.abspath(__file__)`), so it runs from any drive/working directory.
- The script prints `sheets: 22 | live [verify] count: NNN` on success; the `[verify]` count is stamped into the workbook automatically.
- The workbook is still a **DRAFT review spec — not approved, not YAML-ready** (start at the `1.Cover` tab).
