# OC (Ovarian) — Reference Material

> **Reference-only — not a build input.** Nothing here is parsed by the engine or CI. The governed
> implementation is the YAML config pack one level up (`products/oncology/oc/`) — today a non-governed
> **`YYYYMM/` placeholder scaffold** (`status: scaffold`, reconstructed from scans), version-stamped
> (e.g. `202606/`) and flipped to `status: active` once verified against this signed-off material. This
> folder holds the human-authoritative review material the YAML must eventually encode.

## What's here

| Item | What it is |
|---|---|
| **`PROG_SPEC_RWDP_Ovarian_PANO_202606.xlsx`** | ⭐ **DRAFT review spec — self-contained, reviewer-facing (NOT approved / NOT YAML-ready).** Everything needed for review is in its tabs; no other file is required. **Start at the `1.Cover` tab.** |
| `PROG_SPEC_RWDP_Ovarian_PANO_202606.txt` | Plain-text export of the workbook (every tab, one row per line) — for diff / grep / prod review without Excel. Regenerate with `workbook_src/dump_to_text.py`. |
| `workbook_src/` | **Build source** for the workbook (Python + JSON, cross-platform): `generate_workbook.py` rebuilds the `.xlsx`, `dump_to_text.py` rebuilds the `.txt`. Windows/VSCode run steps in `workbook_src/README.md`. The `.xlsx`/`.txt` are build outputs of this. |

> **The source-of-record documents are NOT in the repository.** The prior GSK program specs, the
> Flatiron Panoramic documentation and data dictionary, and the RWDP methodology are held where the
> sponsor holds them; exported documents and vendor documentation are refused a place in the checkout
> by `platform/tools/repo_hygiene.py`, and the vendor material among them may not be read by AI at
> all (`governance/WORKFLOW.md` §"Eligibility"). Nothing here depends on them being present: the
> workbook is **production-de-referenced** — it cites its sources only by *context* (Prior spec /
> Flatiron data dictionary / Flatiron LOT rules / Flatiron Panoramic doc / RWDP methodology /
> Clinical dataset), never by filename or page, which is why removing the files changed no claim in
> it. The **Source Register** tab tracks each section's source + sign-off status, and
> `../../source_refs.yaml` is where the approved document's link, revision and checksum get recorded.

## The workbook (22 tabs, EDM-first)

Tabs 3–9 are the **familiar EDM program spec** — read the **left columns** (Variable · Label · Values · Definition · Source). The columns to the **right** are the Panoramic migration **overlay** (Origin · Panoramic delta · Evidence · Status · Owner · Open decision), ignorable until you're reviewing a change. Owners are **reviewer-facing**: **Epi** (confirm-the-read) · **Biostats** (stats decisions) · **Program** (scope/governance) · **Implementation** (engineering follow-up). Tabs 10–17 are review-support; a small **program/implementation appendix** sits at the very end.

- **`1.Cover`** — purpose, status, a "for EDM reviewers" reading guide, the tab map, authority hierarchy, open ACTIONs.
- **`2.CHANGES`** — **executive summary** of the EDM→Panoramic changes (6 high-level rows: LineSetting, Platinum/PROC, Mortality, PFS2 scope, Additive, Open sign-off). Per-variable detail lives in tabs 3–9 + `10.Deltas`.
- **`3.Data Prep` … `9.PROC PSOC Strategy`** — the EDM baseline, one variable per row, EDM columns first then the Panoramic overlay. The **`Origin`** column flags each row `EDM baseline` / `ADDITIVE (not in prior spec)` / `MODIFIED (vs prior spec)`; additive field specs are folded in here (T/N/M, ExtentOfDebulking, biomarker/FOLR1 staining, insurance = data-dict-confirmed; rwAE/ctDNA = Panoramic-doc, delivered-dict-pending; all **DEFER/proposed**).
- **`10.Deltas`** — the EDM→Panoramic changes in one place: (A) 4-category summary, (B) treatment setting/LineSetting, (C) platinum/PROC, (D) mortality, (E) additive/source/physical-mapping notes, (F) by-cohort impact. *(Merges the former Panoramic Delta + EDM-Pano Deltas tabs.)*
- **`11.Review Decisions`** — every open decision pre-filled (recommendation + owner), sorted by gate. *(was Biostats Decision Pack.)*
- **`12.Epi Source Check`** — the confirm-the-read rows re-read vs the source documents, summarized **by section** (per-section roll-up: **126 Epi rows → 122 confirmed, 4 corrected, 0 unresolved**, with the 4 corrections + 2 cross-confirms itemized — a pre-confirmation summary, *not* a 122-line audit register and not a substitute for sign-off). *(was SDR Read Confirmation.)*
- **`13.New Panoramic Fields`** — optional additive Panoramic elements not in the EDM contract (INCLUDE/DEFER), with honest "not available" negatives (e.g. no ovarian DiseaseGrade). *(was Additive Candidates.)*
- **`14.Source Register` · `15.Worked Examples`** — each section's source + sign-off status; worked boundary examples.
- **`16.Approval Gate` · `17.Plan & Validation`** — gates + the phased plan.
- **Program/implementation appendix** (`Data Dictionary` · `Cross-Validation` · `Data Profiling Checklist` · `Engine Assessment` · `OC Backlog`) — technical detail for Implementation/Program owners; **not** part of the Epi/Biostats review path.

## Status (honest)

The EDM baseline (tabs 3–9) is a **first-pass reconstruction** of the prior EDM program spec (sign-off pending — see `Source Register`); the Panoramic reads are drawn from the Flatiron documentation pending sign-off. This is a **review / decision-support package, not yet an approved programmer contract, and not YAML-ready** (see `Approval Gate`). The original approved EDM program spec, if obtained, supersedes this reconstruction.

> **Note.** The workbook is the single **review** artifact — everything needed for sign-off is in its tabs.
> Earlier per-section markdown transcriptions (`edm_baseline/`, `panoramic_delta/`) were consolidated into
> the workbook and removed (they remain in git history). Separate plain-English **onboarding aids** live
> under `../docs/` (`RWDP_OC_storyboard.md`, `OC_spec_variable_guide.md`) — learning material for newcomers,
> **not** part of the review package and not required to review the spec.
