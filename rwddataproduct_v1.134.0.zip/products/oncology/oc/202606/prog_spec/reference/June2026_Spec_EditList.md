# June 2026 Prog Spec — Ready-to-Paste Edit List (verbatim FIND → REPLACE)

Literal edits: **FIND** the current text, **REPLACE** with the given string, **DELETE** the quoted text, or **ADD ROW** with the given cells. Do **Step 1** (global find/replace) first — it clears most renames in one pass — then the per-worksheet edits.

> 🛑 **CORRECTION (this revision).** The original edit list flagged **11 "ADD" rows in clinvars** as missing. That was **wrong** — it came from a scrambled text export, not the actual pages. After re-reading **clinvars PDF pages 1–13** directly, those fields (T/N/M stage, ExtentOfDebulking, BiomarkerDetail, GeneType, TestType, FOLR1 staining intensity + % staining, LabName, SampleType, biomarker dates, ctDNA) are **already in your spec**. The clinvars edits are now down to minor value-label alignments + the table rename. Net edits are now almost all 🔧 CHANGE (renames + value labels), with **no confirmed ADDs**.

> ⚠️ **Read this too.** The **FIND** strings are transcribed from the master spec, so they may not byte-match your Excel cells (separators `/` vs `,`, punctuation). Match FIND against the actual cell; the **REPLACE** side is verbatim-exact from the June 2026 dict. ✅ CORRECT / ❓ CONFIRM items are not here — see `June2026_Spec_Validation.md`.

---

## Step 1 — Global find & replace (whole workbook)

| # | FIND | REPLACE |
|---|---|---|
| 1 | `Enhanced_OvarianCancer` | `Enhanced_Ovarian` |
| 2 | `Enhanced_OvarianBiomarkers` | `Enhanced_OvarianBiomarker` *(dictionary is authoritative for names — use the singular even though the Flatiron article shows plural)* |
| 3 | `Enhanced_Mortality_V2` | `Mortality_V2` |
| 4 | `Enhanced_Ovarian_Progression` | `Enhanced_Ovarian_Progression_Scaled` |
| 5 | `t_&cohort_demographics_&date` | `Demographics` |
| 6 | `t_meg_socdetohealth_&date` | `SocialDeterminantsOfHealth` |
| 7 | `t_&cohort_enh_ov_&date` *(where used as the source of BirthSex)* | `Demographics` |
| 8 | `t_meg_ecog_&date` / `t_meg_baseline_ecog_&date` | `ECOG` / `BaselineECOG` |

*After Step 1, the rename-only CHANGEs (Data Prep `INDEX`, `PROG_VS_DEATH`, `MAXVISIT_AFTER_DEATH`, `BIO_DATE_RULE`; all biomarker rows' table names; Outcomes `INDEX/INDEXDT/OS/PFS*/TTD*/TTNT*/TSST*/PFS2`; Treatment `SurgeryDate`) are already done.*

---

## 4. Study Population

**PROC_cohort_membership** — Values/Definition:
- FIND: `PLAT_SEN ='Platinum Resistant'`  → REPLACE: `PLAT_SEN_v1 = 'Resistant'`

**POP_FILTER_female** — the cell names the filter but has no rule. ADD to Definition:
- ADD: `Include only patients where Demographics.BirthSex = 'F'.`

**POP_FILTER_age_ge_18** — ADD to Definition (and drop the ">18" wording):
- ADD: `Include only patients where age at index = (year(INDEXDT) − Demographics.BirthYear) ≥ 18.`

**POP_FILTER_diagnosis_ge_2011** — ADD to Definition:
- ADD: `Include only patients where year(Enhanced_Ovarian.DiagnosisDate) ≥ 2011 (diagnosis on/after 01-Jan-2011).`

**POP_FILTER_epithelial_OC_FT_PP** — ADD to Definition:
- ADD: `Restrict to the epithelial OC/FT/PP population via Enhanced_Ovarian cohort membership (EnhancedCohort); if an explicit rule is needed, Enhanced_Ovarian.Histology in {Serous, Mucinous, Clear cell, Transitional cell, Endometrioid, Epithelial NOS, Borderline}.`

**MAXINDEX** — the spec has two conflicting values; pick one:
- FIND: `28-May-26` **or** `28-Feb-26` → REPLACE: *the single true data cutoff for the 2026m06 feed* (reconcile).

**ROW_SELECTION_one_row_per_patient_per_cohort** — ADD to Definition:
- ADD: `Enforce uniqueness on (PatientID × COHORTN); if >1 candidate index date within a cohort, select the earliest qualifying line StartDate.`

---

## 5. Demographics

**GENDER** — Values cell:
- FIND: `Female / Male / Unknown`  → REPLACE: `Female / Male`
- Definition: FIND `As defined in the raw dataset` → REPLACE `Mapped from Demographics.BirthSex: F→Female, M→Male. 'Unknown' only if BirthSex is null (BirthSex is delivered as {F, M} — no Unknown value, no Gender field).`

**GenderN** — Values cell:
- FIND: `1=Female, 2=Male, 3=Unknown`  → REPLACE: `1=Female, 2=Male` *(retain 3=Unknown only if the feed shows null BirthSex)*

**PayerCategory** — Values cell:
- FIND: `Medicaid / Medicare / Commercial / Workers comp / Other Govt / Patient Assistance / Self Pay / Other-Unknown`
- REPLACE: `Medicaid / Medicare / Commercial Health Plan / Workers Compensation / Other Government Program / Patient Assistance Program / Self Pay / Other Payer - Type Unknown`

**INS_PAYER_FLAGS** — Values/coding cell:
- FIND: `binary indicator (1=Yes, 0=No)`  → REPLACE: `Yes / No-Unknown` *(9 flag names already match the dict)*

**SES** — Definition/selection cell:
- DELETE: `Record selection: most recent visit date within STUDY_PD` **and** the label suffix `at most last visit date`
- ADD: `SocialDeterminantsOfHealth is one record per patient (area-level SES Index, 2015-2019 Census block group) — no per-visit selection. Available for Community and Academic centers.`

**RACE / RACEN** — after Step 1 rename, resolve the internal contradiction:
- In RACE Values, `Asian` is listed as an output yet also folded into `Other Race`; and `Hispanic or Latino` is both a value and recoded to `Other Race`. Decide the final collapse and make RACEN's numeric codes match it.

---

## 6. Clinical Characteristics (6. ClinChars + 6b. ClinChars OC)

> ⚠️ **CORRECTION — re-verified against the actual PDF pages 1–13 (not the scrambled text export).** Your clinvars worksheet is **comprehensive**; an earlier pass wrongly flagged ~8 fields as "missing (ADD)". They are **already present**: `TStage / NStage / MStage` (p12), `ExtentOfDebulking` = Optimal/Suboptimal/Unknown (p12), `BiomarkerDetail` = Mutation/Rearrangement/Amplification/Protein expression/VUS/Gene Expression/Loss (p12), `DNAType`/GeneType = Germline/Somatic/Unknown (BRCA only, p12), `BIOMARKER_METHOD`/TestType = IHC/NGS/FISH/RNAseq (p12), FOLR1 `StainingIntensity` = 0/1+/2+/3+ Weak/Moderate/Strong (p12–13), FOLR1 `PercentStaining` (p13), `LabName` (p13), `SampleType` = Blood/Tissue/Saliva/Urine/Other/Unknown (p13), `BIOMARKER_DATES` = Collected/Received/Result (p13), and **ctDNA** `ReportDate` / `TestResult` (Pos/Neg/Inconclusive) / `TestMeasurement` (MTM/mL) (p13). **No ADD rows remain.**

### 🔧 Edits (all minor — no new variables)
- **Table name** — Step 1 #2: `Enhanced_OvarianBiomarkers` → `Enhanced_OvarianBiomarker` (singular), across all biomarker rows.
- **ResidualDiseaseStatus (RESID/RESIDN)** — Values: FIND `Visible residual disease / No visible residual disease` → REPLACE `Residual disease / No residual disease / Unknown/not documented` (dict wording).
- **SizeOfResidualDisease** — Values: FIND `<1cm / <2cm / >1cm / >2cm` → REPLACE `Less than or equal to 1 cm / Less than or equal to 2 cm / Greater than 1 cm / Greater than 2 cm / Unknown`.
- **ExtentOfDebulking** — already present (p12). Values: FIND `Optimal / Suboptimal / Unknown` → REPLACE `Optimal / Suboptimal / Unknown/not documented` (align the third label only).
- **FOLR1 StainingIntensity** — already present, and your spec already flags that the derived expression tiers (High/Mod/Low) need cut-off thresholds. Nothing to add; just define the cut-offs at sign-off.
- **Biomarker date rule** — the per-biomarker `…DT` rows use `max(SpecimenReceivedDate, ResultDate)` (2-date) while your `BIOMARKER_DATES` row lists all three; reconcile with dataprep's 3-date `BIO_DATE_RULE` (spec-internal decision, not a dict gap).
- **NTRK** — confirm the label; the dict `BiomarkerName` set is only {BRCA, HRD, GIS, FOLR1/FRalpha}, so NTRK isn't a standalone delivered biomarker (this row reads as the BRCA/HRD composite).
- **BiomarkerDetail — ⚠️ dict-vs-doc:** your spec's value set includes `Gene Expression` and `Loss` (which are in the Flatiron biomarker **doc**), but the June **dict** lists only 7 values (`Mutation, Rearrangement (translocation/fusion), Amplification, Protein expression, VUS, Other result type, Unknown result type`). Confirm whether Gene Expression/Loss are actually delivered for ovarian, or trim to the dict's 7.
- **TestType/BIOMARKER_METHOD — ⚠️ dict-vs-doc:** your spec's set (`IHC / NGS / FISH / RNA sequencing / PCR / Other / Unknown`) is per the **doc**; the June **dict** only shows the example `IHC`. Confirm the delivered value set on first feed.
- **Histology (HISTON)** — your spec collapses histology into ~3 buckets; the dict delivers 8 (`Serous, Mucinous, Clear cell, Transitional cell, Endometrioid, Epithelial NOS, Borderline, Unknown/not documented`). This is an analytic-collapse decision — confirm it's intended (not a dict mismatch).

### Possible additive candidates (verify — do NOT assume missing)
- `DiseaseGrade` (dict: Low grade / High grade / Unknown-not-documented) and `TissueCollectionSite` — I did **not** spot these in the variable columns, but given how complete the sheet is, **verify against your worksheet before treating either as a gap.**

---

## 6b. Clinical Characteristics OC (Platinum / PROC)

**IsPseudoProgressionMentioned usage** (in PFSDT_IndexToPriorPlatEnd, ELIG_PLAT_SEN_v1/v2, and the outcomes PFS rows) — ⚠️ **logic fix**:
- FIND: `IsPseudoProgressionMentioned = 1`
- REPLACE: `IsPseudoProgressionMentioned = False (0)`  *(dict: True/1 means the event IS pseudoprogression; to select NON-pseudo events you must filter to False)*

**PCYCL{i-1}ED (PCYCLE1ED / PCYCLE2ED)** — Definition cell:
- ADD/CLARIFY: `= MAX(DrugEpisode.EpisodeDate) over the prior line's platinum episodes (DrugEpisode has no per-episode end-date column; episodes are single-date).`

**Progression source** in this tab → `Enhanced_Ovarian_Progression_Scaled` (Step 1 #4).

*(Note: the EDM 90/183 vs Panoramic 91/92-183/184 thresholds are a source-of-truth **decision**, kept separate — see the validation report; not a find/replace.)*

---

## 7. Treatment

**RecurrenceDate dependency** — Definition/Notes cell:
- DELETE (whole sentence): `RecurrenceDate is absent from the supplied data dictionary (dictionary lags Flatiron documentation) - confirm field availability and completeness on first data feed, profile non-null rate`
- REPLACE WITH: `RecurrenceDate is delivered in Enhanced_Ovarian ('Date on which a recurrence event occurs'); confirm completeness / null-rate on first feed and define the null-handling default.`

**Line construction rules** — Additional Notes cell:
- FIND: `Anastrozole excluded`  → REPLACE: `Amifostine excluded`
- FIND: `Gap >120 days advances the line number`  → REPLACE: *verify against the Pano doc's 90-day gap rule* (confirm 90 vs 120)

**PARP carve-out** — Notes cell:
- Keep `Niraparib, Olaparib, Rucaparib`; RESOLVE the Talazoparib note → the split carve-out names **only** those three, so **Talazoparib is NOT excluded from splitting** (it is still included in the separate `L*parpM` maintenance flags — different purpose).

---

## 8. Outcomes

**rwAE_ rows (all 8: rwAE_AdverseEvent, _OnsetDate, _Grade, _Severity, _DrugAttribution, _Resolution, _RelatedOutcome, _Hospitalization)** — ⚠️ **delivery gap**:
- Source tables `Enhanced_Ovarian_AdverseEvents` / `_Outcomes` / `_Hospitalizations` are **NOT in the June dict** (0 hits); the spec itself calls this "the Panoramic AE Add-On table."
- ACTION: either **DELETE** these 8 rows, or tag each `NOT DELIVERED — pending rwAE Add-On subscription confirmation`. Do not leave them build-ready.

**Death-date rows (OS, TTD, TTNT, TSST, PFS*, and their FLs)** — after Step 1 #3 rename, ADD to Definition:
- ADD: `Mortality_V2.DateOfDeath is month-granular (generalized to month of death) — impute to the 15th before any day-level subtraction.`

**Progression rows (PFSFL, PFSDT, RWPFS, ELIGPFS, PFS2)** — source rename to `Enhanced_Ovarian_Progression_Scaled` (Step 1 #4).

---

## Validation of this edit list

Both sides checked against source, 2026-07-06:
- **REPLACE / ADD strings** — verified verbatim in the June dict: PayerCategory 8-value set (dict L3083-3086), ResidualDiseaseStatus / SizeOfResidualDisease / DiseaseGrade / ExtentOfDebulking value sets, ctDNA `Positive, Negative, Inconclusive` + `MTM/mL`, BiomarkerDetail, SampleType, RECIST. Table renames (Step 1) confirmed by 0-hit greps (`OvarianCancer`, plural `OvarianBiomarkers`, `Enhanced_Mortality`). Pano-doc rules (LineSetting, splitting, PARP/Talazoparib, Amifostine, FOLR1 `0/1+/2+/3+`, CA-125 IU/L) read first-hand.
- **FIND strings** — confirmed present in the spec exports: `Anastrozole exduded` (treatment L898), the RecurrenceDate-absent sentence (L994), `Gap >120 days` (L897), GENDER/GenderN/PayerCategory values (Demo), `Visible residual disease` (clinvars L185), `IsPseudoProgressionMentioned` (clinvarsoc L40/104).
- **Corrections made during validation:** `ExtentOfDebulking` reclassified from find/replace to ADD (not in the clinvars export); `StainingIntensity 0/1+/2+/3+` attributed to the Pano biomarker doc (dict example differs); `GeneType` softened to the dict-confirmed `Germline` example; T/N/M value sets marked "example only, confirm full set."
- **Reminder:** FIND strings are transcribed — match them against the live Excel cells before replacing.
