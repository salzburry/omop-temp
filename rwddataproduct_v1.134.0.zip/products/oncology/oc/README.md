# Ovarian (OC) RWDP — config pack

Runs on the shared engine (`../../../platform/`). This folder is config + `ovarian_rdap.R` — a
RECONSTRUCTION of the original OC build script (reference only; see its header for what it covers).
**The authoritative review material is the workbook under `202606/prog_spec/reference/`**, which is
what the YAML must eventually encode once signed off; the documents behind it are held by the sponsor.

**Status: scaffold** (reconstructed, then superseded by the review workbook). The structure matches
prostate (same author/template), so the shared demographics / ECOG / vitals / outcomes defaults apply
unchanged. The ovarian-specific pieces are marked `verify-vs-the original` / `status: scaffold`:

- **source tables** — ovarian datamart uses a `t_meg_*` prefix (shared tables) + `t_enh_ov_*`
  (enhanced); confirm exact names (`config/data_product.yaml`).
- **index rule** — ovarian advanced/recurrent diagnosis date (placeholder columns; verify).
- **treatment taxonomy** — `codelists/treatment_categories.yaml` captures the drug CLASSES the
  script keys on (platinum, taxane, bevacizumab, PARP mono + maintenance, IO) from p.56; the exact
  categories/order/maintenance logic need verification (version `0.1` = unverified).
- **staging** — `variables/clinical.yaml` keeps the I–IV grouping (FIGO-compatible); confirm.

## Finish the port
1. Verify the items above against the prior program-spec source (held by the sponsor).
2. Lint: `python3 ../../../platform/engine/validate.py YYYYMM/config/data_product.yaml`  (the spec-version pack dir)
3. Run a sample on Databricks (job `rwdp_build_oc`) and diff against the original ovarian ADS
   (golden comparison), then flip `status` to `active` here and in `../../registry.yaml`.

> **Cross-check on the R engine (same config).** The R-proficient team can rebuild this pack on the R
> engine — a *validation* path (it writes directly; use a **separate `_r` schema**), then golden-compare
> vs the Python ADS. The `formats.Panoramic` overlay (EDM→Pano), when activated, is honoured by **both**
> engines, so EDM→Pano needs no R change. From a Spark-connected R session (Databricks, or Domino→Databricks):
> ```bash
> Rscript ../../../platform/engine-r/run_rwdp.R --allow_direct_write=true \
>   --config_path=YYYYMM/config/data_product.yaml \
>   --refresh=<cut> --source_schema=<src> --output_schema=<out>_r
> ```
> Detail + caveats (incl. `--allow_direct_write` fail-close): `../../../platform/engine-r/README.md`.
