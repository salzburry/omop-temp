# MDS (COTA) RWDP — config pack  *(heme / myeloid scaffold)*

Runs on the shared engine (`../../../platform/`). Myelodysplastic syndromes — a **COTA hematologic
(myeloid)** product. Index = initial MDS diagnosis; risk by **IPSS-R** (not AJCC staging); treated with
HMAs / lenalidomide / luspatercept / ESAs / immunosuppressive therapy / venetoclax+HMA / intensive
chemo / allo-HSCT.

**Status: scaffold (PLACEHOLDER, not verified).** Scaffolded from the DLBCL COTA/heme pack, then the
disease-specific pieces (codelist, clinical/outcomes call-outs) were swapped for MDS. It lints clean and
exercises `vendor: cota` + `tumor_class: heme` + optional sources. **Everything tumor-specific below is a
default to VERIFY** against the real MDS program-spec + the COTA MDS data dictionary.

## What the shared engine already handles for MDS today
- vendor-aware table resolution (`vendor: cota`);
- optional sources — MDS declares no `alphabet`/`provenge`; the engine skips them;
- all LOT lines counted (no `lot.line_setting`);
- diagnosis-date index; the MDS treatment codelist (HMA/lenalidomide/luspatercept/…);
- **overall survival (OS)** + demographics + ECOG.

## MDS-specific pieces to fill from the real spec (call-outs in the packs)
| Where | What to fill | Needs |
|---|---|---|
| `config` `cohorts` | confirm the cohort model — MDS is usually **IPSS-R lower- vs higher-risk** (± line) | the MDS spec |
| `config` `sources` | confirm COTA stems; declare `labs` (CBC/blast%), `cytogenetics`, `transfusions` | COTA dictionary |
| `variables/clinical.yaml` | **IPSS-R risk**, **bone-marrow blast %**, **cytogenetics/del(5q)**, **ring sideroblasts**, **transfusion dependence** (commented placeholders) | source columns or a heme module |
| `variables/outcomes.yaml` | **AML transformation** (blast ≥20%), **transfusion independence (RBC-TI)** (commented placeholders) | source columns or a heme module |
| `codelists/treatment_categories.yaml` | verify drug names/categories vs COTA `linename` | COTA dictionary |

## What needs heme MODULES in the engine (not built — ROADMAP Phase 7)
- **IPSS-R derivation** (blast% + cytogenetics + cytopenias → risk category) if not a stored column.
- **AML transformation** + **transfusion independence** endpoints.

The survival/demographics/ECOG/treatment path works today; the IPSS-R / AML-transformation / TI modules are additive, selected by `tumor_class: heme`.
