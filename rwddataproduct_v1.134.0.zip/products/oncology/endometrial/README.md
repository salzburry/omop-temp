# Endometrial (EC) RWDP — config pack

Runs on the shared engine (`../../../platform/`). Config + `endometrial_rdap.R` — a RECONSTRUCTION of
the original EC build script, which is held by the sponsor outside this repo (reference only; see its
header for what it covers so far, and verify against the original).

**Status: scaffold, RECONSTRUCTED — NOT VERIFIED.** Structure matches prostate; shared demographics /
ECOG / vitals / outcomes defaults apply. EC-specific pieces (marked `verify-vs-source`):

- **source tables** — confirmed against the original: enhanced = `t_enh_endometrial_*`; shared
  tables use the plain `t_*` prefix (like prostate, not `t_meg_`). Verify drug_episode / orals /
  biomarker names.
- **treatment taxonomy** — `codelists/treatment_categories.yaml` from the standard EC regimen
  classes (pembrolizumab+lenvatinib, platinum doublet, dostarlimab/IO, hormonal, chemo); verify
  exact categories/order (version `0.1` = unverified).
- **index rule** / **staging** — advanced/recurrent index + FIGO-compatible I–IV grouping; verify.

## Finish the port
1. Verify the above against the EC the original.
2. Lint: `python3 ../../../platform/engine/validate.py YYYYMM/config/data_product.yaml`  (the spec-version pack dir)
3. Sample-run on Databricks (job `rwdp_build_endometrial`, generated once the pack exists),
   golden-compare, then flip
   `status` to `active` here and in `../../registry.yaml`.

> **Cross-check on the R engine (same config).** The R-proficient team can rebuild this pack on the R
> engine — same pack, same ADS — a *validation* path (it writes directly; use a **separate `_r`
> schema**), then golden-compare vs the Python ADS. From a Spark-connected R session (Databricks, or
> Domino→Databricks via sparklyr):
> ```bash
> Rscript ../../../platform/engine-r/run_rwdp.R --allow_direct_write=true \
>   --config_path=YYYYMM/config/data_product.yaml \
>   --refresh=<cut> --source_schema=<src> --output_schema=<out>_r
> ```
> Detail + caveats (incl. `--allow_direct_write` fail-close): `../../../platform/engine-r/README.md`.
