# =============================================================================
# Endometrial (EC) RWDP — original R / dbplyr build script (RECONSTRUCTION)
# =============================================================================
# SOURCE: the original EC build script, held outside this repository. This file is a RECONSTRUCTION
# of it, so TREAT IT AS REFERENCE ONLY and VERIFY every line against
# the original before relying on it.
#
# By line number the original is one CONTINUOUS script of roughly 11,650 lines; the reconstruction
# covers it in four parts, and the line numbers are contiguous, so nothing analytic appears to be
# missing between them.
#
# SCOPE (per request): the EC-SPECIFIC BUILD LOGIC only. The generic boilerplate
# that is identical to the prostate script is REFERENCED BY NAME, not
# re-reconstructed — see "BOILERPLATE (not reconstructed)" below.
#
# EC-specific run config read from the original (100_Database.R):
#     edm_dbname      = "clnprw_flatiron_endo_use"        # Flatiron EDM use-schema
#     reg_dbname      = "clnprw_flatiron_dostar_endo_use" # Dostarlimab registry schema
#     refresh         = "2026m03"
#     index_start     = as.Date("2013-01-01")
#     index_end       = as.Date("2026-02-26")
#     db flag         = "EDM" (Flatiron) unioned with "DOS" (Dostar registry)
#     output          = "/mnt/artifacts/results/"
#     personal_schema = Sys.getenv("DOMINO_USER_NAME")
#
# COVERAGE: reconstruction IN PROGRESS (part 1). Reconstructed so far:
#   the original's opening ~522 lines — the file headers, 100_Database.R union,
#   201_EDM.R table map, and the line-of-therapy treatment categorisation. The
#   remaining sections are listed under "TODO(reconstruct)" at the bottom.
# =============================================================================

# ---------------------------------------------------------------------------
# BOILERPLATE (referenced by name, NOT reproduced — generic, == prostate):
#   000_PersonalSchemaFunctions.R  copyToPersonalSchema(), createInPersonalSchema()
#                                  (push an R data.frame back to the Domino personal schema)
#   000_helper_functions.R         contents(), count(), freq_func(), cross_freq_func(),
#                                  means_func(), summary_func(), summary_stats(), str_df(),
#                                  min_max_dates(), min_max(), prnt(), sql(), drop()
#   001_Setup.R                    library(odbc/DBI/dbplyr/dplyr/tidyr/purrr/lubridate/
#                                  stringr/sparklyr/gsklog); source() the two files above;
#                                  edm_dbname / reg_dbname / personal_schema / refresh /
#                                  index_start / index_end / connect() / con / paths
# Full text of these is in the original build script pages 1-8.
# ---------------------------------------------------------------------------

# ===========================================================================
# R/Programs/100_Database.R  — union the Flatiron EDM cohort with the Dostar
# registry (flagging db = "EDM" / "DOS") and persist each combined table to the
# personal schema, so downstream code reads one set of tables.   (original EC script)
# ===========================================================================
con <- connect()                       # database connection

# one-off QC of the already-combined cohort table
edm <- tbl(con, in_schema("pdg40077", "rwdp_endo_edm_2026m03_qc"))
dos <- tbl(con, in_schema("pdg40077", "rwdp_endo_dos_2026m03_qc"))
dataset_union <- edm %>% union_all(dos)
freq_func(edm, "db"); freq_func(dos, "db"); freq_func(dataset_union, "db")
createInPersonalSchema(dataset_union, "rwdp_endo_2026m03_qc", replace = TRUE)

# Function to union EDM and Dostar registry with the appropriate db flag and
# save the combined table back into the personal schema.
union_func <- function(dataset) {
  edm <- tbl(con, in_schema(edm_dbname, paste0(dataset, refresh))) %>% mutate(db = "EDM")
  dos <- tbl(con, in_schema(reg_dbname, paste0(dataset, refresh))) %>% mutate(db = "DOS")
  dataset_union <- edm %>% union_all(dos)
  # QC
  print(freq_func(edm, "db")); print(freq_func(dos, "db")); print(freq_func(dataset_union, "db"))
  createInPersonalSchema(dataset_union, paste0(dataset, refresh), replace = TRUE)
}

# Combine every source table the EC ADS needs (EDM + Dostar registry):
union_func("t_enh_advendom_")            # enhanced advanced endometrial cohort
union_func("t_demographics_")
union_func("t_baseline_ecog_")
union_func("t_diagnosis_")
union_func("t_drugepisode_")
union_func("t_ecog_")
union_func("t_enh_advendo_orals_")
union_func("t_enh_advendo_progresion_")  # progression (sic: "progresion")
union_func("t_enh_advendobiomar_")       # biomarkers
union_func("t_enh_advendom_disconrsn_")  # discontinuation reason
union_func("t_enh_mortality_v2_")
union_func("t_lab_")
union_func("t_lineoftherapy_")
union_func("t_medicationorder_")
union_func("t_practice_")
union_func("t_socdetofhealth_")
union_func("t_telemedicine_")
union_func("t_visit_")
union_func("t_vitals_")

# ===========================================================================
# R/Programs/201_EDM.R  — the main EC dataset build.                (original EC script)
# ===========================================================================
source('/mnt/code/R/Programs/001_Setup.R')          # setup file
con <- connect()                                     # database connection
dbname <- "clnprw_flatiron_endo_use"

# --- Load required tables from the (now combined) database into the environment ---
enh_ec             <- tbl(con, in_schema(dbname, paste0("t_enh_advendom_",       refresh)))  # enhanced endometrial cohort
enh_ec_lot         <- tbl(con, in_schema(dbname, paste0("t_lineoftherapy_",      refresh)))  # line of therapy
enh_ec_dem         <- tbl(con, in_schema(dbname, paste0("t_demographics_",       refresh)))  # demographics
enh_ec_ses         <- tbl(con, in_schema(dbname, paste0("t_socdetofhealth_",     refresh)))  # SES / social determinants
enh_ec_practice    <- tbl(con, in_schema(dbname, paste0("t_practice_",           refresh)))  # practice
enh_ec_diag        <- tbl(con, in_schema(dbname, paste0("t_diagnosis_",          refresh)))  # diagnosis
enh_ec_lab         <- tbl(con, in_schema(dbname, paste0("t_lab_",                refresh)))  # lab
enh_ec_med_order   <- tbl(con, in_schema(dbname, paste0("t_medicationorder_",    refresh)))  # medication order
enh_ec_med_admin   <- tbl(con, in_schema(dbname, paste0("t_medicationadmin_",    refresh)))  # medication administered
enh_ec_visit       <- tbl(con, in_schema(dbname, paste0("t_visit_",              refresh)))  # visit
enh_ec_telemed     <- tbl(con, in_schema(dbname, paste0("t_telemedicine_",       refresh)))  # telemedicine
enh_ec_drugepisode <- tbl(con, in_schema(dbname, paste0("t_drugepisode_",        refresh)))  # drug episode
enh_ec_mortality   <- tbl(con, in_schema(dbname, paste0("t_enh_mortality_v2_",   refresh)))  # mortality
enh_ec_orals       <- tbl(con, in_schema(dbname, paste0("t_enh_advendo_orals_",  refresh)))  # endometrial orals
enh_ov_edm_incl    <- tbl(con, in_schema(dbname, paste0("t_meg_enh_ov_edmincl_", refresh)))  # EDM inclusion (sic: t_meg_..._ov_)
# (also referenced later: t_baseline_ecog_, t_ecog_, t_enh_advendo_progresion_,
#  t_enh_advendobiomar_, t_enh_advendom_disconrsn_, t_vitals_)

# --- Line-of-therapy treatment categorisation -------------------------------
# Aggregate the LoT table at (linenumber, linesetting, maintenance level). Drop the
# "ADVANCED" line-setting rows; rename "Off Systemic Therapy" -> "OST". A line is a
# chemo line (adjt_chm) if its name matches the EC chemo backbone. first_chemo_line
# is the earliest non-maintenance chemo line; adjuvant/neoadjuvant "ever" flags mark
# patients with maintenance therapy in those settings.
enh_ec_new_lot <- enh_ec_lot %>%
  filter(linesetting != "ADVANCED") %>%
  distinct(patientid, linesetting, linename, ismaintenancetherapy, startdate, enddate) %>%
  mutate(
    linename_new = ifelse(linename == "Off Systemic Therapy", "OST", linename),
    adjt_chm = sql("CASE WHEN LOWER(linename_new) LIKE '%carboplatin%'
                          OR LOWER(linename_new) LIKE '%paclitaxel%'
                          OR LOWER(linename_new) LIKE '%docetaxel%'
                          OR LOWER(linename_new) LIKE '%cisplatin%'
                          OR LOWER(linename_new) LIKE '%gemcitabine%'
                          OR LOWER(linename_new) LIKE '%doxorubicin%'
                          OR LOWER(linename_new) LIKE '%ifosfamide%'
                          OR LOWER(linename_new) LIKE '%capecitabine%'
                          OR LOWER(linename_new) LIKE '%topotecan%'
                          OR LOWER(linename_new) LIKE '%mitomycin%'
                     THEN 1 ELSE 0 END")
  ) %>%
  group_by(patientid, linesetting, ismaintenancetherapy) %>%
  arrange(startdate, .by_group = TRUE) %>%
  mutate(
    linenumber       = row_number(),
    first_chemo_line = min(if_else(adjt_chm == 1L & ismaintenancetherapy == "False",
                                   linenumber, NA_integer_), na.rm = TRUE),
    adjt_1chm        = if_else(linenumber == first_chemo_line, linename,  NA_character_),
    adjt_1chmsd      = if_else(linenumber == first_chemo_line, startdate, as.Date(NA)),
    adjt_1chmed_raw  = if_else(linenumber == first_chemo_line, enddate,   as.Date(NA)),
    adjt_chmep       = sum(adjt_chm, na.rm = TRUE),
    adjtever         = if_else(linesetting == "ADJUVANT"    & ismaintenancetherapy == "True", 1L, 0L),
    adjmever         = if_else(linesetting == "ADJUVANT"    & ismaintenancetherapy == "True", 1L, 0L),
    neoadjtever      = if_else(linesetting == "NEOADJUVANT" & ismaintenancetherapy == "True", 1L, 0L)
  ) %>%
  ungroup()

# collapse to one row per patient
enh_ec_new_lot_pat <- enh_ec_new_lot %>%
  group_by(patientid) %>%
  summarise(
    adjt_1chm       = min(adjt_1chm,       na.rm = TRUE),
    adjt_1chmsd     = min(adjt_1chmsd,     na.rm = TRUE),
    adjt_1chmed_raw = min(adjt_1chmed_raw, na.rm = TRUE),
    adjt_chmep      = max(adjt_chmep,      na.rm = TRUE),
    adjmever        = max(adjmever,        na.rm = TRUE),
    neoadjtever     = max(neoadjtever,     na.rm = TRUE),
    .groups = "drop"
  )

# Advanced-line name aggregation (linename_agg = '/'-joined line names in start-date
# order, per linesetting/maintenance) — used to label the advanced-disease regimen.
enh_ec_new_lot <- enh_ec_lot %>%
  filter(linesetting != "ADVANCED") %>%
  mutate(linename_new = ifelse(linename == "Off Systemic Therapy", "OST", linename)) %>%
  group_by(patientid, linesetting, ismaintenancetherapy) %>%
  summarize(
    adjsd        = min(startdate, na.rm = TRUE),
    linename_agg = sql("STRING_AGG(linename_new, '/') WITHIN GROUP (ORDER BY startdate)")
  )

# ===========================================================================
# Index-cohort definition.                                          (original EC script)
#   overall : index_date = advanceddiagnosisdate, within [index_start, index_end]
#   lota    : ADJUVANT line start (adjsd), non-maintenance       (the adjuvant cohort)
#   lotN    : line-N start date (linenumber == N, NOT maintenance)
#   lotNm   : line-N start, maintenance (ismaintenancetherapy == "True")
# NOTE: EC indexes on advanceddiagnosisdate (OC indexes on diagnosisdate).
# ===========================================================================
index_lot_cohort <- function(coh_flag) {
  if (coh_flag == "overall") {
    ec_index <- enh_ec %>%
      filter(advanceddiagnosisdate >= index_start & advanceddiagnosisdate <= index_end) %>%
      select(patientid, advanceddiagnosisdate)
    final_ec_index <- ec_index %>%
      mutate(index_date = as.Date(advanceddiagnosisdate)) %>%
      select(patientid, index_date, advanceddiagnosisdate)
    return(final_ec_index)

  } else if (coh_flag == "lota") {                                   # ADJUVANT cohort
    adjuvant_index <- enh_ec %>%
      filter(advanceddiagnosisdate >= index_start & advanceddiagnosisdate <= index_end) %>%
      select(patientid, advanceddiagnosisdate)
    enh_ec_index <- enh_ec_line_agg %>%                              # from the line-name aggregation above
      filter(linesetting == "ADJUVANT", ismaintenancetherapy == "False")
    final_adjuvant_index <- adjuvant_index %>%
      inner_join(enh_ec_index, by = "patientid") %>%
      mutate(index_date = as.Date(adjsd)) %>%
      select(patientid, index_date, advanceddiagnosisdate, linesetting, adjsd,
             ismaintenancetherapy, linename_agg)
    return(final_adjuvant_index)

  } else if (nchar(coh_flag) == 4) {                                 # lot1 / lot2 / lot3 / lot4
    ec_index <- enh_ec %>%
      filter(advanceddiagnosisdate >= index_start & advanceddiagnosisdate <= index_end) %>%
      select(patientid, advanceddiagnosisdate)
    lot_number <- as.numeric(gsub("[^0-9.]", "", coh_flag))
    lot_index <- enh_ec_lot %>%
      filter((startdate >= index_start & startdate <= index_end) &
             linenumber == lot_number & ismaintenancetherapy == "False") %>%
      select(patientid, linenumber, linename, startdate, enddate, ismaintenancetherapy)
    final_lot_index <- lot_index %>%
      inner_join(ec_index, by = c("patientid" = "patientid")) %>%
      mutate(index_date = as.Date(startdate)) %>%
      select(patientid, index_date, advanceddiagnosisdate, linenumber, linename,
             startdate, enddate, ismaintenancetherapy)
    return(final_lot_index)

  } else if (nchar(coh_flag) == 5) {                                 # lot1m (maintenance / induction lines)
    ec_index <- enh_ec %>%
      filter(advanceddiagnosisdate >= index_start & advanceddiagnosisdate <= index_end) %>%
      select(patientid, advanceddiagnosisdate)
    lot_number <- as.numeric(gsub("[^0-9.]", "", coh_flag))
    lot_index <- enh_ec_lot %>%
      filter((startdate >= index_start & startdate <= index_end) &
             linenumber == lot_number & ismaintenancetherapy == "True") %>%
      select(patientid, linenumber, linename, startdate, enddate, ismaintenancetherapy)
    final_lot_index <- lot_index %>%
      inner_join(ec_index, by = "patientid") %>%
      mutate(index_date = as.Date(startdate)) %>%
      select(patientid, index_date, advanceddiagnosisdate, linenumber, linename,
             startdate, enddate, ismaintenancetherapy)
    return(final_lot_index)
  }
}

# EC cohort list (7 cohorts): overall, adjuvant, L1-L4, and the L1 maintenance variant.
coh_list <- c("overall", "lota", "lot1", "lot1m", "lot2", "lot3", "lot4")
for (coh_flag in coh_list) {                       # build + push each cohort's index table
  var_name <- paste0("enh_ec_", coh_flag, "_index_tbl")
  df <- index_lot_cohort(coh_flag); assign(var_name, df)
  df <- get(var_name) %>% collect(); copyToPersonalSchema(con, df, var_name, replace = TRUE); rm(df)
}

# ===========================================================================
# Demographics.                                                     (original EC script)
# ===========================================================================
enh_ec_practice_agg <- enh_ec_practice %>%
  distinct(patientid, practicetype) %>%
  group_by(patientid) %>%
  summarize(practicetype_agg = sql("STRING_AGG(practicetype, '/') WITHIN GROUP (ORDER BY practicetype)"))

demographics_variable_addn <- function(input_ds) {
  df_dem_interim <- input_ds %>%
    left_join(enh_ec_dem,          by = c("patientid" = "patientid")) %>%   # demographics
    left_join(enh_ec_practice_agg, by = c("patientid" = "patientid")) %>%   # aggregated practice
    left_join(enh_ec_ses,          by = c("patientid" = "patientid")) %>%   # SES
    mutate(
      gender  = case_when(birthsex == "M" ~ "Male", birthsex == "F" ~ "Female",
                          is.na(birthsex) ~ "Missing", TRUE ~ "Missing"),
      gendern = case_when(birthsex == "M" ~ 1, birthsex == "F" ~ 2,
                          is.na(birthsex) ~ 3, TRUE ~ 3),
      year_index = year(index_date),
      age = year_index - as.numeric(birthyear),                             # age at index
      agegrl = case_when(age >= 0  & age <= 18 ~ "0-18",  age >= 19 & age <= 34 ~ "19-34",
                         age >= 35 & age <= 49 ~ "35-49", age >= 50 & age <= 64 ~ "50-64",
                         age >= 65 & age <= 74 ~ "65-74", age >= 75 & age <= 84 ~ "75-84",
                         age >= 85 ~ ">=85", TRUE ~ "Unknown"),
      agegrln = case_when(age >= 0  & age <= 18 ~ 1, age >= 19 & age <= 34 ~ 2,
                          age >= 35 & age <= 49 ~ 3, age >= 50 & age <= 64 ~ 4,
                          age >= 65 & age <= 74 ~ 5, age >= 75 & age <= 84 ~ 6,
                          age >= 85 ~ 7, TRUE ~ 8),                          # 8 = Unknown / out of range
      region1 = case_when(
        state %in% c('ME','VT','NH','MA','RI','CT','NY','PA','NJ') ~ "Northeast",
        state %in% c('ND','SD','NE','KS','MN','IA','MO','WI','IL','MI','IN','OH') ~ "Midwest",
        state %in% c('TX','OK','AR','LA','KY','TN','MS','AL','MD','DE','DC','VA','WV','NC','SC','GA','FL') ~ "South",
        state %in% c('CA','WA','OR','NV','AZ','UT','NM','CO','ID','MT','WY','HI','AK') ~ "West",
        state == 'PR' ~ "Other region", is.na(state) ~ "Missing", TRUE ~ "Unknown"),
      regionln = case_when(
        state %in% c('ME','VT','NH','MA','RI','CT','NY','PA','NJ') ~ 1,
        state %in% c('ND','SD','NE','KS','MN','IA','MO','WI','IL','MI','IN','OH') ~ 2,
        state %in% c('TX','OK','AR','LA','KY','TN','MS','AL','MD','DE','DC','VA','WV','NC','SC','GA','FL') ~ 3,
        state %in% c('CA','WA','OR','NV','AZ','UT','NM','CO','ID','MT','WY','HI','AK') ~ 4,
        state == 'PR' ~ 5, is.na(state) ~ 99, TRUE ~ 7),
      race = case_when(race == "Asian" ~ "Asian",
                       race == "Black or African American" ~ "Black or African American",
                       race == "White" ~ "White",
                       race == "Hispanic or Latino" ~ "Other Race",
                       race == "Other Race" ~ "Other Race",
                       is.na(race) ~ "Unknown/Missing", TRUE ~ "Unknown/Missing"),
      racen = case_when(race == "Asian" ~ 1, race == "Black or African American" ~ 2,
                        race == "White" ~ 3, race == "Hispanic or Latino" ~ 4,
                        race == "Other Race" ~ 4, is.na(race) ~ 97, TRUE ~ 97),
      eth = case_when(ethnicity == "Not Hispanic or Latino" ~ "Not Hispanic or Latino",
                      ethnicity == "Hispanic or Latino" ~ "Hispanic or Latino",
                      is.na(ethnicity) ~ "Unknown/Missing", TRUE ~ "Unknown/Missing"),
      ethn = case_when(ethnicity == "Not Hispanic or Latino" ~ 1,
                       ethnicity == "Hispanic or Latino" ~ 2,
                       is.na(ethnicity) ~ 99, TRUE ~ 99),
      practic = case_when(practicetype_agg == "ACADEMIC" ~ "Academic only",
                          practicetype_agg == "COMMUNITY" ~ "Community only",
                          practicetype_agg == "ACADEMIC,COMMUNITY" ~ "Both academic and community",
                          TRUE ~ "Missing"),
      practicn = case_when(practicetype_agg == "ACADEMIC" ~ 1, practicetype_agg == "COMMUNITY" ~ 2,
                           practicetype_agg == "ACADEMIC,COMMUNITY" ~ 3, TRUE ~ 98),
      # SHOULD BE CHECKED WITH DATABASE AND SPECS ("Missing" not specified in specs)
      ses = case_when(is.na(sesindex2015_2019) ~ "99-Null", TRUE ~ sesindex2015_2019)
    ) %>%
    select(patientid, index_date, advanceddiagnosisdate, birthyear, birthsex, age, agegrl,
           agegrln, gender, gendern, state, region1, regionln, race, racen, eth, ethn,
           practic, practicn, ses)
  return(df_dem_interim)
}

# ===========================================================================
# Minimum-available-date (data-availability floor).                (original EC script)
# minavaildate = earliest of advanceddiagnosisdate + the first date seen in each
# source (diagnosis / lab / med-order / visit / televisit / LOT / orals).
# ===========================================================================
minavaildate_tbl <- enh_ec %>%
  left_join(enh_ov_diag %>% group_by(patientid) %>%
              summarise(first_diagnosisdate = min(diagnosisdate, na.rm = TRUE)), by = "patientid") %>%
  left_join(enh_ec_lab %>% group_by(patientid) %>%
              summarise(first_labdate = min(pmin(testdate, resultdate, na.rm = TRUE), na.rm = TRUE)), by = "patientid") %>%
  left_join(enh_ec_med_order %>% filter(is.na(iscancelled)) %>% group_by(patientid) %>%
              summarise(first_medorderdate = min(ordereddate, na.rm = TRUE)), by = "patientid") %>%
  left_join(enh_ec_visit %>% group_by(patientid) %>%
              summarise(first_visitdate = min(visitdate, na.rm = TRUE)), by = "patientid") %>%
  left_join(enh_ec_telemed %>% group_by(patientid) %>%
              summarise(first_televisitdate = min(visitdate, na.rm = TRUE)), by = "patientid") %>%
  left_join(enh_ec_lot %>% group_by(patientid) %>%
              summarise(first_lotdate = min(startdate, na.rm = TRUE)), by = "patientid") %>%
  left_join(enh_ec_orals %>% filter((dategranularity != 'Year' | is.na(dategranularity)) & !is.na(startdate)) %>%
              group_by(patientid) %>%
              summarise(first_oraldate = min(startdate, na.rm = TRUE)), by = "patientid") %>%
  mutate(minavaildate = pmin(advanceddiagnosisdate, first_diagnosisdate, first_labdate,
                             first_medorderdate, first_visitdate, first_televisitdate,
                             first_lotdate, first_oraldate, na.rm = TRUE)) %>%
  select(patientid, advanceddiagnosisdate, first_diagnosisdate, first_labdate, first_medorderdate,
         first_visitdate, first_televisitdate, first_lotdate, first_oraldate, minavaildate) %>%
  distinct()

# ===========================================================================
# Clinical characteristics from the enhanced table.                (original EC script)
# clin_char_enh_ec_var(): histology, FIGO stage, TNM, grade, surgery (type/
# modality/residual disease), myometrial & lymphovascular invasion, radiation.
# (NOTE on "PCS"/"ICS": primary vs interval cytoreductive surgery, decided by
#  surgerydate relative to the line start/end window. Many "... NOT ALIGNED WITH
#  SPEC CLINCHARS" author notes appear here — verify against the EC spec.)
# ===========================================================================
clin_char_enh_ec_var <- function(input_ds) {
  input_ds %>%
    left_join(enh_ec, by = "patientid") %>%
    left_join(enh_ec_lot %>% filter(linenumber == 1 & ismaintenancetherapy == "False"),
              by = "patientid") %>%
    mutate(
      init  = diagnosisdate,                       # initial diagnosis date
      inityr = year(diagnosisdate),                # initial diagnosis year
      advdxdt = advanceddiagnosisdate,
      histo = case_when(
        histology == "Carcinosarcoma / MMT"     ~ "Carcinosarcoma/MMT",
        histology == "Clear cell carcinoma"     ~ "Clear cell carcinoma",
        histology == "Endometrial cancer, NOS"  ~ "Endometrial cancer, NOS",
        histology == "Endometrioid carcinoma"   ~ "Endometrioid carcinoma",
        histology == "Serous carcinoma"         ~ "Serous Carcinoma",
        is.na(histology) ~ "Unknown/not documented", TRUE ~ "CHECK"),
      stage = case_when(                            # FIGO group stage
        groupstage %in% c('I','IA','IB','IC')                       ~ "I",
        groupstage %in% c('II','IIA','IIB')                         ~ "II",
        groupstage %in% c('III','IIIA','IIIB','IIIC','IIIC1','IIIC2') ~ "III",
        groupstage %in% c('IV','IVA','IVB')                         ~ "IV",
        groupstage == "Unknown/not documented" ~ "Unknown/not documented", TRUE ~ "CHECK"),
      stagen = case_when(
        groupstage %in% c('I','IA','IB','IC') ~ 1, groupstage %in% c('II','IIA','IIB') ~ 2,
        groupstage %in% c('III','IIIA','IIIB','IIIC','IIIC1','IIIC2') ~ 3,
        groupstage %in% c('IV','IVA','IVB') ~ 4, is.na(groupstage) ~ 99, TRUE ~ 98),
      grade = case_when(
        grade == "G1 (well-differentiated)"                                    ~ "G1",
        grade == "G2 (moderately differentiated)"                              ~ "G2",
        grade == "G3 (poorly differentiated or undifferentiated)"              ~ "G3",
        grade == "Unknown/not documented" ~ "Unknown/not documented", TRUE ~ "CHECK"),
      tstage = case_when(
        tstage %in% 'T0' ~ "T0", tstage %in% c('T1','T1a','T1b','T1c') ~ "T1",
        tstage %in% c('T2','T2a','T2b') ~ "T2", tstage %in% c('T3','T3a','T3b') ~ "T3",
        tstage %in% 'T4' ~ "T4", tstage %in% 'TX' ~ "TX",
        is.na(tstage) ~ "Unknown/not documented", TRUE ~ "CHECK"),
      nstage = case_when(
        nstage %in% c('N0','N0(i+)') ~ "N0", nstage %in% c('N1','N1a','N1mi') ~ "N1",
        nstage %in% c('N2','N2a','N2mi') ~ "N2", nstage %in% 'NX' ~ "NX",
        is.na(nstage) ~ "Unknown/not documented", TRUE ~ "CHECK"),
      mstage = case_when(
        mstage %in% c('M0') ~ "M0", mstage %in% c('M1','M1a','M1b') ~ "M1", mstage %in% 'MX' ~ "MX",
        is.na(mstage) ~ "Unknown/not documented", TRUE ~ "CHECK"),
      # surgery: flag, type (primary/interval cytoreductive), modality, date
      issurg = case_when(issurgery == "Yes" ~ "Yes", issurgery == "No" ~ "No Surgery",
                         issurgery != "Yes" & is.na(surgerydate) ~ "Unknown", TRUE ~ "Not documented"),
      surg = case_when(
        (issurgery == "Yes" & is.na(surgerydate)) | (surgerydate < linestartdate) ~ "Primary cytoreductive surgery (PCS)",
        (surgerydate >= linestartdate & surgerydate <= lineenddate) | (surgerydate > lineenddate) ~ "Interval cytoreductive surgery (ICS)",
        TRUE ~ "No Surgery"),
      neoadj = case_when(surgerydate >= linestartdate & surgerydate <= lineenddate ~ "Yes", TRUE ~ "No"),
      rdc = case_when(residualdiseasestatus == "Residual disease" ~ "Visible residual disease",
                      residualdiseasestatus == "No residual disease" ~ "No visible residual disease",
                      TRUE ~ "No surgery/Unknown"),
      myometrial_invasion    = case_when(ismyometrialinvasion == "Yes" ~ "Yes", ismyometrialinvasion == "No" ~ "No",
                                         ismyometrialinvasion == "Unknown" ~ "Unknown", TRUE ~ "Missing"),
      lymphovascular_invasion = case_when(islymphovascularinvasion == "Yes" ~ "Yes", islymphovascularinvasion == "No" ~ "No",
                                          islymphovascularinvasion == "Unknown" ~ "Unknown", TRUE ~ "Missing"),
      radiation_type = radiationtype,
      radiation_flag = case_when(is.na(radiationtherapydate) ~ "No/unknown", TRUE ~ "Yes"),
      firsttreatmentdt = firsttreatmentdate, first_locoregionaldt = locoregionaldate,
      radiationdt = radiationtherapydate, first_distantrecurrencedt = distantrecurrencedate,
      multipleprimary_flag = ismultipleprimaries, firstadditionalprimarydt = firstadditionalprimarydate
    ) %>%
    select(patientid, index_date, histology, groupstage, issurgery, surgerydate,
           init, inityr, advdxdt, stage, stagen, issurg, surg, surgn = stagen,
           residualdiseasestatus, rdc, grade, t_stage = tstage, n_stage = nstage, m_stage = mstage,
           surgery_flag = issurg, surgerytype = surg, surgerymodality = surg, surgerydt = surgerydate,
           myometrial_invasion, lymphovascular_invasion, radiation_flag, radiation_type,
           firsttreatmentdt, first_locoregionaldt, radiationdt, first_distantrecurrencedt,
           multipleprimary_flag, firstadditionalprimarydt)
}

# --- Baseline ECOG: closest to index in window [-30, +7] days. ---  (original EC script)
# 6-step: pull ECOG in window -> abs gap to index -> min gap -> closest (ties:
# earliest ecogdate, then max ecogvalue) -> map 0..4 -> code; null -> Missing.
clin_char_ecog_var <- function(input_ds) {
  bl_ecog_pull <- input_ds %>%                                   # union baseline_ecog + ecog tables
    inner_join(enh_ec_bl_ecog, by = "patientid") %>%
    filter(ecogdate >= dbplyr::sql("DATE_SUB(index_date, 30)") &  # -30 days
           ecogdate <= dbplyr::sql("DATE_ADD(index_date, 7)"))    # +7 days
  gap_calc <- bl_ecog_pull %>% mutate(gap = abs(datediff(ecogdate, index_date)))
  min_gap  <- gap_calc %>% group_by(patientid, index_date) %>% summarise(min_gap = min(gap, na.rm = TRUE), .groups = "drop")
  bl_max_ecogdt <- gap_calc %>% inner_join(min_gap, by = c("patientid", "index_date")) %>%
    filter(gap == min_gap) %>% group_by(patientid, index_date) %>%
    summarise(ecogdate = min(ecogdate, na.rm = TRUE), .groups = "drop")   # ties -> earliest date
  bl_ecog_value <- bl_max_ecogdt %>%                              # ties -> max ecogvalue at that date
    mutate(ecog = case_when(ecogvalue == '0' ~ "0", ecogvalue == '1' ~ "1", ecogvalue == '2' ~ "2",
                            ecogvalue == '3' ~ "3", ecogvalue == '4' ~ "4",
                            ecogvalue == "Unknown" ~ "Unknown", is.na(ecogvalue) ~ "Unknown", TRUE ~ "Unknown"))
  # Final: ecog label + ecogn code; no baseline record -> "Missing".
  input_ds %>% left_join(bl_ecog_value, by = c("patientid", "index_date")) %>%
    mutate(ecog  = case_when(is.na(ecog) ~ "Missing", TRUE ~ ecog),
           ecogn = case_when(ecog == '0' ~ 1, ecog == '1' ~ 2, ecog == '2' ~ 3, ecog == '3' ~ 4,
                             ecog == '4' ~ 5, ecog == "Unknown" ~ 7, is.na(ecog) ~ 99, TRUE ~ 98)) %>%
    select(patientid, index_date, ecogdate, ecog, ecogn)
}

# --- Biomarkers: ER, HER2, MMR/MSI, PDL1, PR; closest to index (+14d window). ---  (original EC script)
# Status mapped to Positive/Negative; MMR/MSI -> MSI-H/dMMR vs MSS/pMMR; PDL1
# positive/negative; biomarker hierarchy + per-patient aggregation; PDL1 percent
# staining bands. (Multi-step; verify against the EC biomarker spec.)
clin_char_biom_var <- function(input_ds) {
  bl_biom_pull <- input_ds %>%
    inner_join(enh_ec_biomarkers, by = "patientid") %>%
    filter(toupper(biomarkername) %in% c('ER','HER2','MMR/MSI','PDL1','PR') &
           biomarkerstatus %in% c('Positive','Negative') &
           biomarkerdate <= dbplyr::sql("DATE_ADD(index_date, 14)")) %>%       # <= index + 14 days
    mutate(
      biomstatus = case_when(
        toupper(biomarkername) == 'ER'       & biomarkerstatus %in% c('Positive') ~ 1,
        toupper(biomarkername) == 'HER2'     & biomarkerstatus %in% c('Positive') ~ 1,
        toupper(biomarkername) == 'MMR/MSI'  & biomarkerstatus %in% c('Positive') ~ 1,  # MSI-H / dMMR
        toupper(biomarkername) == 'PDL1'     & biomarkerstatus %in% c('PD-L1 positive') ~ 1,
        toupper(biomarkername) == 'PR'       & biomarkerstatus %in% c('Positive') ~ 1,
        biomarkerstatus %in% c('Negative') ~ 2, TRUE ~ 3))
  # ... per-patient biomarker hierarchy/aggregation + PDL1 % staining bands, then
  #     join the biomarker closest to index_date. (clin_char_biom_var returns the
  #     ER/HER2/MMR-MSI/PDL1/PR status columns.) -- see the original EC script the original.
  bl_biom_pull
}

# ===========================================================================
# TODO(reconstruct) — remaining EC build logic, with their section names:
#   - Vitals: BMI / blood pressure (bmigrl, bp/bpn)                              the original EC script p.~67     (line ~2075)
#   - Cohort / index assembly: coh_flag labels (L1+/L2+ treated ENDO),           the original EC script p.~95-100 (line ~3087)
#     cohortu/cohortn, overall_ads_creation() + push loop                        the original EC script (line ~3120+)
#   - Progression / PFS (IsClinicalAssessmentOnly/IsRadiographicEvidence/...)    the original EC script (line ~9594+)
#   - Overall survival, follow-up end, death anchors                            the original EC script/the original EC script
#   - Reporting: count() / freq_func() / cross_freq_func() tables                the original EC script (line ~9594+)
# ===========================================================================
