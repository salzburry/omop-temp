# DLBCL (COTA) RWDP — config pack  *(heme / vendor proof)*

Runs on the shared engine (`../../../platform/`). This pack exists primarily to **prove the engine
handles a different vendor (COTA) and tumor class (heme)** — different schema, no provenge/alphabet
sources, diagnosis-date index, R-CHOP/CAR-T/bispecific treatment taxonomy.

**Status: scaffold (INFERRED, not scan-reconstructed)** from `oncology/packs/cota_dlbcl` + the heme
common spec. It lints clean and exercises `vendor: cota`, `tumor_class: heme`, and optional sources.

## What the shared engine already handles for heme
- vendor-aware table resolution (`vendor: cota`);
- optional sources — DLBCL declares no `alphabet`/`provenge`; the engine skips them;
- all LOT lines counted (no `lot.line_setting` — DLBCL has no mCRPC-style setting);
- diagnosis-date index; heme treatment codelist.

## What still needs heme MODULES in the engine (ROADMAP Phase 7 — not built)
- **Ann Arbor staging + IPI score** (vs solid-tumor AJCC/FIGO).
- **Lugano/IWG response** + **EFS** (event-free survival) — heme uses response/EFS, not just OS.
- **Transplant / CAR-T / bispecific exposure**, cell-of-origin (GCB/non-GCB), double/triple-hit.
- COTA exact table names + layout (`source_layout`) — `verify-vs-source`.

These are additive engine modules selected by `tumor_class: heme`; the survival path works today.
