# CLL RWDP — config pack  *(scaffold, unverified)*

Runs on the shared engine (`../../../platform/`). Registered in `products/registry.yaml` as
`cll` on vendor `cota`, tumour class `heme`.

**Status: scaffold. It lints clean and can be pointed at a delivery — and nothing in it is
approved.** Every clinical value was INFERRED from published RWD practice for this tumour, not read
from an approved workbook: no workbook is registered for this pack. Values marked
`verify-vs-source` are best readings and must be confirmed before use. The approved RWB workbook is
the specification; this pack is the starting configuration to check against it.

```bash
python3 -m engine.validate ../../../platform ../products/oncology/cll/YYYYMM/config/data_product.yaml
python3 platform/tools/product_gates.py --report
```

## What was inferred, and what to check first

- **No group stage is emitted.** CLL is staged Rai/Binet; the engine has no heme staging module (ROADMAP Phase 7).
- **Index is the diagnosis date**, read from the `diagnosis` source — CLL has a long watch-and-wait interval before first treatment, so a treatment-anchored index is a real alternative the workbook may state.
- **del(17p)/TP53, IGHV mutational status and the FISH panel** are the defining prognostic covariates (see the overlay) and are not configured.
- **Time-to-first-treatment**, the endpoint that matters most in CLL, is not in `emits` — it needs the watch-and-wait interval modelled.

## The reference shelf behind these choices

`governance/reference/variable_inventory/INVENTORY.yaml` -> `tumours.cll` carries the
literature-cited definitions the values above were drawn from, each with its engine coverage class.
It is `status: reference_only` — **a drafting AID, never a specification.** A variable enters THIS
product only when the approved workbook states it.

```bash
python3 platform/tools/inventory_coverage.py                       # engine coverage + the gap list
python3 platform/tools/variables_scaffold.py products/oncology/cll/YYYYMM   # parameter skeletons
```

## Before this pack is anything more than a scaffold

1. **Name the spec version.** Rename `YYYYMM/` to the six-digit cut the workbook governs
   (e.g. `202608/`). Nothing can be registered before this: `source_refs.schema.json` pins
   `spec_version` to `^[0-9]{6}$`, because a registration records WHICH cut it governs.
2. **Register the source** — one command, and it needs three things only a person can supply:

   ```bash
   python3 platform/tools/source_refs_init.py products/oncology/cll/<YYYYMM> \
       --ai-classification <sponsor_ai_eligible|vendor_restricted|restricted_derived> \
       --classified-by "<your name>" --classified-date <YYYY-MM-DD>
   ```

   The tool composes everything else and validates against the schema before writing, but it has
   no default for those three and refuses a team name, an acronym or a placeholder. That is
   deliberate: `ai_classification` decides what AI may read at all, and a generated one would read
   exactly like a considered call while nobody had made one.
3. **Run the spec pipeline** to produce `spec_pipeline/out/extracted.json` — the sanitized
   extraction, and the only artifact of this pack AI may read.
4. **Reconcile every `verify-vs-source` value** against the workbook, and drop `version: 0.1` to a
   real version once each is confirmed.
5. **Draft the contract** (`.claude/skills/draft-contract-record`) and register the decisions.
