# profile/ — live-cut evidence

Two live checks that run in **different runtimes** (don't conflate them):

| Tool | What it answers | Runtime |
|---|---|---|
| `run_product_schema_check.py` (shared) | Do the configured tables + build-required columns exist? | **Spark cluster** (Databricks) |
| `run_product_profile.py` -> `data_profiler.R` (shared) | What are the values / distributions / missingness? | **DBI/ODBC** R env (Domino or local) — `DATABRICKS_DSN` + `DATABRICKS_PWD` |

## 1. Schema preflight — `run_product_schema_check.py` (Spark)

Config-driven (no hardcoded list — reuses `engine.validate`). Confirms the configured tables (`sources:`)
and the columns the build **requires** (`required_columns()`) exist; also records the **optional** configured
columns (present/absent — never fatal) and each column's **observed type**; writes JSON + Markdown evidence.

```bash
python3 platform/tools/run_product_schema_check.py products/oncology/prostate/202606 \
    --cut 2026m06 --schema <delivered prostate schema> --out-dir $OUT
# -> $OUT/<data_product_id>/<schema>/<cut>/SCHEMA_VALIDATION_<cut>.{json,md}; non-zero exit on any miss
```

`--cut` and `--schema` are **required** (no silent default to a historical cut); the checker lints the
config before touching Spark. `--out-dir` is required and refused inside the checkout — the report names
physical vendor tables and columns with their observed types.

This replaced a `validate_schema.py` that lived in this folder and resolved its config through the
**registry** (`product_config(root, "prostate")`), so it would have validated the 202607 config the day
`current_spec_version` moved, while writing evidence into the 202606 pack. It also defaulted its output
beside itself, inside the checkout. The shared checker takes the pack path, so what it validates is what
you point it at, and it handles `source_union` members (`--member` / `--all-members`).

**Scope — what a green report does and does NOT prove.** It is a **build-preflight** check:

- ✅ proves: the tables read, the build-required columns exist, and records optional columns + observed types.
- ❌ does **not** prove: data types are *correct*, value vocabularies, grain / joins / duplicates / windows /
  ties, or that a column is the clinically intended source.

So a green run establishes `schema_presence: passed_live` — **one input** to source verification, attached to
the contract provenance. It does **not** by itself move any contract row to `source: verified`; that needs the
value profile + targeted checks + RWP review.

## 2. Value profiler — shared `run_product_profile.py` → shared `data_profiler.R` (DBI/ODBC, a different runtime)

Use the shared runner `platform/tools/run_product_profile.py`: it **derives `DC_TABLES` from this pack's config** (so the
profiler is scoped to exactly this product's sources, not every table in the schema), defaults to a
`DC_SAMPLE_N=2000` screening run, and invokes the SHARED, tumor-agnostic `data_profiler.R` — it does **not**
copy the profiler. Run it from an ODBC-enabled R environment — it is **not** the Spark cluster:

```bash
DATABRICKS_DSN=RWDE DATABRICKS_PWD=... \
python3 platform/tools/run_product_profile.py products/oncology/prostate/202606 \
    --cut 2026m06 --schema <delivered prostate schema> \
    --out-dir $HOME/restricted/prostate-202606        # screening (--sample-n 2000)

# inspect the derived table scope without touching R / ODBC:
python3 platform/tools/run_product_profile.py products/oncology/prostate/202606 \
    --cut 2026m06 --print-tables
```

Env: `DC_SCHEMA`/`DC_CUT` (required to run), `DC_CATALOG` (default `hive_metastore`), `DC_SAMPLE_N` (default
`2000` — screening; set `0` for **exact per-column** values / missingness / distributions), `DC_OUT_DIR`
(**required, and must be OUTSIDE this checkout** — see below), `DC_PROFILER` (path to `data_profiler.R`;
default `platform/tools/data_profiler.R`, the one shared implementation).

**`DC_OUT_DIR` is required and is refused inside the repository.** The profile carries top values and
date min/max per column, with no small-cell floor — a `count:1` entry is one patient. That is IHD under
GSK R&D policy §9. `.gitignore` prevents a commit; it does **not** stop a repo-indexing tool, an agent
search, or any other process with checkout access from reading a file that is sitting in the working
tree. The wrapper therefore exits non-zero if `DC_OUT_DIR` is unset or resolves inside the checkout.
(`--print-tables` needs no data and is unaffected.)

**Scope of the profiler (even at `DC_SAMPLE_N=0`).** A full-table run makes the **per-column** metrics
exact — values, missingness, distributions. It does **not** validate **composite grain, duplicate keys, join
coverage, same-day ties, or window coverage**: those are relationships/derivations the profiler can't see, and
need **targeted SQL / Spark checks**. (`profile_facts.py` states the same limits.)

Then generate the facts report:

The shared runner writes each run to `<out-dir>/<data_product_id>/<schema>/<cut>/` — per **product** and
per **source schema**, so two members of a `source_union` at the same cut cannot overwrite one another.
Name the profile once and reuse it, rather than retyping the path:

```bash
PROFILE="$OUT/<data_product_id>/<schema>/<cut>/profile_<cut>.tsv"

python3 platform/tools/profile_facts.py <pack> "$PROFILE"           # writes PROFILE_FACTS_<cut>.md beside the TSV
python3 platform/tools/profile_facts.py <pack> "$PROFILE" --strict  # fail if any configured stem is missing
```

`$PROFILE` is the same path `source_check.py --profile` takes, so the facts report and the Gate 3
verdict are always derived from one identical file.

## State of the evidence

- **No profile is held in the repository, and none may be.** A profile carries per-column top values and
  date ranges with no small-cell floor, so it is restricted output: `--out-dir` is required and refused
  inside the checkout, and `platform/tools/repo_hygiene.py` refuses a committed profile or a retyped
  reconstruction of one. Point `$PROFILE` at the restricted folder the run wrote to.
- **No clean full-scope TSV / generated `PROFILE_FACTS`, and no live `SCHEMA_VALIDATION` JSON/MD, are attached
  yet**, and no targeted exact evidence. Until those exist, every `🔍 needs data check` row in the handoff is
  unverified — and schema presence alone is not source verification.
