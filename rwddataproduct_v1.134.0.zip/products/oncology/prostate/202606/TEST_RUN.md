# Prostate 202606 — end-to-end test run

A record of driving the framework from a packaged checkout on a Windows workstation: what was run, what
it returned, what broke, and what the run says should change. Written after the fact from the commands
actually issued, so the numbers are results, not targets.

**What this run establishes.** That the pipeline executes on a clean machine with no cluster, that the
gates refuse what they are supposed to refuse, and that pointing the tools at a real workbook produces
findings a person can act on.

**What it does not establish.** Nothing about delivered data. No gate was closed by this run — the
statuses a human owns (`approved`, `human_confirmed`, `passed_live`) were not written, and no tool
here can write them. `releasable` stays derived from Gates 1–4 and stays `false`.

---

## Environment

| | |
|---|---|
| Package | repo + `deploy/` tree, built by `platform/tools/deploy_tree.py` |
| Host | Windows, PowerShell, no WSL, no bash |
| Python | launched as `py`, not `python3` |
| Deps | `pyyaml`, `openpyxl`, `jsonschema` (`pyspark` only for the Spark suites) |
| Cluster | none — every step below is local |

Two portability facts decided most of the friction and are worth stating before the commands:

- **The docs assumed bash.** `for t in tests/test_*.py; do …; done` is not a PowerShell construct. It
  fails with a parse error that names the token, not the cause, which reads as a broken package.
- **Windows console encoding is not UTF-8.** Redirect the output of a tool that prints `—`, `·` or `∪`
  and Python raises `UnicodeEncodeError` on the character rather than on anything to do with the task.

PowerShell equivalents that worked:

```powershell
Get-ChildItem tests\test_*.py | ForEach-Object { py $_.FullName }
$env:PYTHONIOENCODING = 'utf-8'      # set once per shell, before any redirected run
```

> **Both are now fixed in the repository** (§8). Every tool sets its own output encoding, so
> `PYTHONIOENCODING` is no longer something to remember; `docs/ENGINEERING.md` carries the PowerShell
> commands beside the bash ones.

---

## 1. The suites

```powershell
cd repo\platform
py -m pytest tests\ -q
```

**580 passed, 65 failed.** The failures are all from two suites and are by design in an unzipped copy:

| Suite | Why it fails without `.git` |
|---|---|
| `test_governance.py` | calls `repo_hygiene`, which reads the git **index**. With no git it raises rather than returning an empty list — an empty list would report a clean repository, which is the one answer it may not invent. |
| `test_render_html.py` | checks generated evidence is bound to a real commit; with no `.git` the commit reads as all-zeros. |

`git init && git add -A && git commit` inside `repo/` turns both green.

Run standalone rather than under pytest, the same suites report **30 pure-Python suites pass**,
`test_r_parity` **31/31** (needs `Rscript`), `test_stages_spark` **31/31** and `test_smoke_spark`
**2/2** (need `pyspark` + Java 17/21).

> **Unresolved: the two Spark suites interact when run in one pytest process.** Separately,
> `test_stages_spark` is 31/31 and `test_smoke_spark` is 2/2. Together — `pytest test_stages_spark.py
> test_smoke_spark.py` — `test_smoke_prostate_production_union_path` fails, after the first suite has
> driven some 3,500 Spark stages through the shared session. Not diagnosed, and it does not reproduce
> under the documented workflow, which runs each suite as its own process. Worth knowing before
> reading a combined-run failure as a defect in the engine.

> **Issue found.** A standalone runner aborts at its first failing assertion, so the standalone sweep
> reported far fewer failures than pytest, which counts every test function. Reading the standalone
> output as a failure count understates it — here, by an order of magnitude. Use pytest for counts.

Gate tools run from the **repository root**, not `platform/`, because they emit root-relative paths:

```powershell
cd repo
py platform\tools\repo_hygiene.py --check
py platform\tools\source_manifest.py --all --check
py platform\tools\product_gates.py --list-tests      # then run each path it prints
```

---

## 2. Gate 1 — registering the workbook

The pack shipped with a stand-in at `status: pending`. Replacing it with the real workbook is a
`source_refs.yaml` edit plus a digest, and the digest is what binds the record to the bytes:

```powershell
py -c "import hashlib,sys; print(hashlib.sha256(open(sys.argv[1],'rb').read()).hexdigest())" <workbook.xlsx>
```

Then in `source_refs.yaml`, on the workbook's own record: the real `path_or_link`, that
`artifact_sha256`, and `status` moved off `pending`.

> **Issue found.** Two separate typos in hand-copied sha256 values. A 64-character hex string
> transcribed by eye is a reliable source of error; generate it into the file, never retype it.

> **Rule that held.** The AI boundary follows the **content's** `ai_classification` in
> `source_refs.yaml`, not the folder the file sits in. Being told in a task to process something is not
> an approval mechanism — the record is.

---

## 3. Extraction — the pipeline

```powershell
py platform\tools\run_spec_pipeline.py products\oncology\prostate\202606
```

Writes seven artifacts to `spec_pipeline/out/`, all generated, none hand-editable:

| Artifact | What it is |
|---|---|
| `extracted.json` | structured rows with Excel coordinates |
| `lint.json` / `SPEC_FINDINGS.txt` | deterministic defect scan, ranked HIGH / INFO |
| `COVERAGE.md` | every spec item and its disposition — Gate 2 completeness evidence |
| `scaffold.json` / `SCAFFOLDED_RECORDS.md` | one contract record stub per specification row |
| `ENUMERATION_CANDIDATES.yaml` | candidate value enumerations, as evidence to audit YAML against |

`--check` fails if any artifact drifted from what the inputs produce; `--strict` requires coverage to
be complete for Gate 2.

### The sheet-label defect — the most expensive thing in this run

The extraction produced **no `clinical` domain at all**. Everything downstream that cited a clinical
row then failed to resolve, and the obvious readings — bad workbook, broken extractor, wrong pack —
were all wrong.

The cause was a **single missing space**. The workbook's tab is labelled `5B.ClinChars`;
`governance/spec_sheet_map.yaml` maps `"5B. ClinChars"`. The lookup is exact-string, so the sheet
matched neither `sheets:` nor `ignored:` and was skipped. Adding the label recovered **96 records**.

Two things made this hard rather than trivial:

1. The sheet *was* reported as unclassified, but as one line among the run's normal output. `--strict`
   would have failed on it; the default run did not.
2. The symptom (a whole domain absent) is far away from the cause (one character in a shared governance
   file), and nothing in the failure text connects them.

### Hidden sheets

`openpyxl` read **22 sheets** where Excel showed **8 tabs**. Hidden and very-hidden sheets are still
sheets. The `ignored:` block is what makes this safe: a sheet in neither list is unclassified and gets
reported, so "this sheet carries no requirements" and "nobody has looked at this sheet" are not the
same state. Without it, extra sheets would be silently in scope or silently out of it.

---

## 4. Drafting records

The `draft-contract-record` skill, run in REVIEW mode by default so an audit never writes to a governed
file.

> **Behaviour worth recording.** Given an item id that did not exist (`study_population:24`), the skill
> **refused to draft** and printed the rows that do exist, instead of producing a plausible record for a
> row nobody had. That is the whole point of the citation invariants: a drafter that invents a row is
> the failure mode, and here it was caught at the source rather than at lint.

> **Rule that held.** Row numbers do not transfer between extractions. The stand-in numbers the
> HRR/BRCA rows `clinical:72`/`76`; the real workbook numbers them `73`/`77`. A citation copied from an
> older document points at the wrong row and still parses.

Iterative drafting works — records can be added in batches and re-linted — which matters, because the
process is manual by design and a single pass over a hundred rows is not realistic.

**`spec_diff.py` needs an "old" pack** to partition records into CARRIES AS-IS / CARRIES NEW REF /
RE-DRAFT. On a first extraction there is nothing to diff against, and that is not a defect: every
record is new, so every record is drafted. The diff earns its keep at the *second* revision.

---

## 5. Gate 3 — the profiler

Ran directly against a downloaded profile TSV. Iterating on record shape, not on the feed, moved:

| Counter | Before | After |
|---|---|---|
| `present` | 334 | **456** |
| `not_a_column` | 68 | **13** |
| `absent_column` | 0 | 0 |
| `absent_table` | 0 | 0 |
| `stem_drift` | 0 | 0 |

The three zeros held throughout, which is the load-bearing result: **nothing the contract asks for is
missing from the delivered feed.** The movement was records naming things the wrong way, not the feed
lacking things.

> **Issue found.** The `not_in_profile` **count** is on the console, in the counter line. The
> **records behind it** were not: they appear only in the `--out` report, filed under a human-readable
> title rather than the counter key — so searching the report for the name just read on the console
> returns nothing. A count with no list is a number nobody can act on.

> **Rule that held.** Restricted output — profiles, schema reports — must never land in the checkout.
> `--out-dir` is required and is refused if it points inside the checkout.

Still open on the pack after this run: **13** `unknown_source`, **26** `derived_input_candidate`,
**8** `not_in_profile`, **2** `ambiguous_source`.

---

## 6. The enumeration audit

The one part of config that *is* generatable from the workbook is value enumerations — the codes and
labels a specification row lists verbatim. Everything else is written by a person from the contract,
because the contract summarises (`"STATE→region map (codes 1-5, PR→Other region)"`) where the YAML
enumerates (fifty-two state codes). The codes are in the specification row, not in the summary.

```powershell
py platform\tools\spec_codelists.py products\oncology\prostate\202606\spec_pipeline\out\extracted.json `
   --product products\oncology\prostate\202606 --out <somewhere outside the checkout>
```

> **Issue found.** The tool takes the extraction **file**, not the pack directory. Passing the pack dir
> fails with a bare `usage:` line that does not say which argument was wrong.

Comparing `ENUMERATION_CANDIDATES.yaml` against `variables/*.yaml` in REVIEW MODE — no files written —
produced four findings:

| # | Finding | Disposition |
|---|---|---|
| 1 | `HRR_INDEX_TESTN` (`clinical:73`) and `BRCA_INDEX_TESTN` (`clinical:77`) each enumerate 7 test methods (IHC, FISH, PCR, NGS, Other sequencing method, Other, Unknown). **No config exists for either.** | Blocked on `NAME-ALIGN` (OPEN), which asks whether the `_INDEX_TEST*` fields are published, excluded or metadata. Writing the enumeration answers that question by shipping it. **No YAML.** |
| 2 | `variables/demographics.yaml#/regions` carries a 7th group — `code 99 Unknown, when: fallthrough` — that the workbook does not state (it lists 6). | Already `CODE-ALIGN` (OPEN), which already names this exact path. No new row. |
| 3 | Workbook spells the null-state group `state_is_missing`; config spells it `state_is_null`. | Wording only, and **must not be "fixed"**: `state_is_null` is the literal `engine/stages/demographics.py:57` and `engine-r/cases.R:69` recognise. Rename it and the group matches nothing, the `WHEN state IS NULL THEN 'Missing'` branch is never emitted, and every null state falls to the code-99 `ELSE`. |
| 4 | `PFSFL` (`outcomes:17`) came back **unparsed** — the lifter did not recognise the row's shape. | A hole in the audit's coverage, not a YAML defect. `PFSFL` was **not checked**, which is not the same as checked-and-clean. |

**Finding 4 turned out to be the largest of the four.** The lifter read only the *Definition* cell.
`PFSFL`'s codes are in the **Values** cell — `1='Yes'<br>0='No';<br>missing` — the one column named for
the enumeration, and it was never read; the `in (…)` the tool did see was `if COHORTN IN (1,2)`, an
applicability gate on another variable. A second rule compounded it: a numeric map had to run `1..n`,
which refused every `1='Yes' 0='No'` flag in the specification as if it were truncated.

Both are fixed (§8, item 5). On this pack the lift went **6 → 19 enumerations, 0 unparsed** — and the
newly read rows include `HRR_INDEX_TESTN` and `BRCA_INDEX_TESTN`, finding 1's two missing test-method
maps. Re-running the audit against the approved workbook will now compare them rather than skip them.

Everything else matched value-for-value: `REGION1` (`demographics:14`) all five state lists
byte-identical, `HRR_INDEXN` and `BRCA_INDEXN` exact. The workbook disclaims the numeric codes
(`numeric_codes: not_stated_by_the_spec`), so config's 1–5 is unasserted by the specification, not
contradicted by it.

**Two of four findings landed on decisions the pack recorded months ago against a stand-in, now
confirmed against the real workbook.** That is the result worth showing: the audit reproduced known
open questions from an independent input.

### Recording a finding against a decision

Findings go in the `Conflict / evidence` column of `handoff/DECISIONS.md`. `Approved answer` stays `—`
and `Status` stays `OPEN` — those are the human's. `NAME-ALIGN` and `CODE-ALIGN` are in
`contract_lint.OUTPUT_DECISIONS`, so they accumulate evidence without blocking every record.

Verify the edit parsed, in this order:

```powershell
py -c "import sys; sys.path.insert(0,'platform/tools'); import contract_lint as cl; t=open('products/oncology/prostate/202606/handoff/DECISIONS.md',encoding='utf-8').read(); r=cl.decision_rows(t); print(len(r),'rows'); print({d:r[d]['Status'] for d in ('NAME-ALIGN','CODE-ALIGN')})"
py platform\tools\contract_lint.py products\oncology\prostate\202606
py platform\tools\decision_report.py products\oncology\prostate\202606 --check
```

Expected: same row count as before the edit with both statuses `OPEN`; `202 records, all 19 invariants
pass` (I21 is the every-OPEN-decision-referenced check that used to be the pack-local
`test_decision_refs.py`); `OK — the question list is current`.

Markdown tables are line-based. A newline inside a cell splits the row; a raw `|` shifts every column
right. Injecting one stray `|` into the CODE-ALIGN cell was enough to make the parser read
`Owner = "Unknown, when: fallthrough — which the workbook does no…"` and `Status = "—"`, and the lint
caught it:

```
FAIL 202606: decision register 'CODE-ALIGN' Status '—' is not one of
['OPEN','RESOLVED','SUPERSEDED','WITHDRAWN'] — an unrecognised status
reads as 'not open' and silently stops blocking
```

That is the failure mode worth internalising: **a broken register row does not read as broken, it reads
as not blocking anything.** The lint refuses the unrecognised status rather than treating it as closed.

---

## 7. What the run exposed, and what was done about it

Ranked by the cost of the failure each one prevents. **All nine are implemented**; the commands and
verification are in `docs/ENGINEERING.md` and each has a test that fails without the fix.

> A later pass extended five of these. The additions are in `docs/ENGINEERING.md` and
> `governance/WORKFLOW.md`; what changed beyond the list below is at the end of this section.

**1. An unclassified sheet now stops the extraction.**
One character in `spec_sheet_map.yaml` silently removed a whole domain and 96 records. The run did
report the unclassified sheet — as one line among the positional, header and skipped-sheet lines, to
a reader running a new workbook for whom every line is unfamiliar. `spec_extract.py` now exits with
the tab, the number of rows it did not scan, and the three files that can classify it.
`--allow-unclassified` proceeds anyway, which makes the scope gap a choice that is in the shell
history rather than a default nobody chose.

**2. Tab labels are compared with whitespace removed.**
`spec_extract.sheet_key` is now the single comparison key — casefolded, all whitespace stripped — used
by the map's own keys, the domain lookup, `ignored:`, a pack's `IGNORE` and `--tabs`. `5B. ClinChars`
and `5B.ClinChars` are one key. Merging spellings is safe; merging *answers* is not, so
`shared_sheet_map` refuses two labels that normalise together and carry different rulings.

**3. The tools set their own output encoding.**
`platform/tools/console.py` defines `use_utf8()`, called from all 32 tool entry points. Verified
against the character that actually failed: a child printing `A ∪ B` under `PYTHONIOENCODING=cp1252`
exits 1 with `UnicodeEncodeError: '\u222a'` without it and 0 with it. `$env:PYTHONIOENCODING` is no
longer something to remember. A governance test holds every tool with an entry point to calling it.

**4. `spec_codelists.py` names the argument.**
A directory now gets: *"…is a directory. This tool takes the extraction FILE, not the pack"*, plus the
`extracted.json` path that would have worked — or, if it does not exist yet, that the pipeline has to
run first.

**5. The Values column is read, and coverage is stated.**
The two real defects behind `PFSFL` are fixed: only the Definition cell was read, and a numeric map
had to run `1..n` so every `1='Yes' 0='No'` flag was refused as truncated. A Values cell is taken only
when **every** segment of it is accounted for — as a code pair, or as a bare `missing`/`null`/`.`
recorded as `missing_permitted` — and one unaccounted segment yields nothing, with the segment quoted
in the finding. Every run states `lifted` and `unparsed` in the file as well as the console, because
the comparison against the approved YAML is done against the file, later, by somebody else.

Prostate went **6 → 19 lifted, 0 unparsed**. Every one of the 13 new lifts was checked against its
source cell. On the ovarian pack the completeness rule holds: three lab rows are refused, naming
`'Unknown'` as the segment that would have been dropped.

**6. `not_in_profile` records are listed, not just counted.**
Bounded to twelve, worded so they cannot be read as defects — the profile not carrying a column is
evidence of nothing either way.

**7. PowerShell beside bash.**
`docs/ENGINEERING.md` §"On Windows" carries a twin for every command in the gate sequence. Every tool
was already pure Python; only the documentation assumed a shell.

> **This was written as done before it was.** The first version carried three of the six commands and
> dropped the Spark/R skip-list from the one loop it did carry — so a Windows operator following it
> ran two suites that need PySpark, and never ran `contract_binding` or `finalize` at all. Every step
> they *did* run passed, which is what makes a partial port worse than none: the omission presents as
> a clean run. It also said nothing about PowerShell not stopping a loop when a native command exits
> non-zero, so a failing gate completes and reads as green.
>
> Both are fixed, and `test_the_windows_runbook_covers_every_bash_loop_it_stands_beside` now matches
> the two lists on the TOOL each command invokes. Adding a bash step to the sequence fails until its
> twin exists — which is the difference between "somebody wrote the PowerShell down once" and the
> environment cost actually being absorbed.

**8. Digests are computed into the record.**
`source_manifest.py <pack> --record-digest <material_id>` hashes the registered file and writes it in.
It fills only an **unstated** field: a recorded digest that no longer matches means the file changed
under an approval, and it refuses rather than re-pointing that approval at bytes nobody has looked at.
Exit is non-zero when nothing was written, so "already matching" and "REFUSED" cannot read as success.

**9. Which runner to trust for counts.**
`docs/ENGINEERING.md` now says it: the standalone runners abort at the first failing assertion, so
they answer *green or not*; `python3 -m pytest platform/tests/ -q` answers *how many and which*.

### What this cost, and one thing it found

Widening the lifter surfaced eight new differences on this pack's own config — `VIS120`, `ELIGPFS` and
`PFSFL` state published `1=Yes / 0=No` codes in their Values cells, and the config blocks the contract
binds those rows to (`#/visit_recency_days`, `#/min_followup_days`, `#/progression`) hold the rule and
assign no codes. They are recorded as evidence under `NAME-ALIGN`, which is the open decision that owns
published names and codes. No config changed and no status moved.

That is the check working on the repository that wrote it: a tool improved for one pack immediately
found something in another.

### What a second pass added

**The other direction of the sheet ruling.** Item 1 protects against a sheet nobody classified. A
sheet classified WRONGLY had no detector at all, and it is the worse of the two: `requirement_rows`
keeps only rows with a domain, so the linter never reads an ignored sheet, coverage never counts it,
and the unclassified check excludes it by construction. One line in `ignored:` or a pack's `IGNORE`
takes a requirements tab out of scope permanently and nothing says so. An ignored sheet whose rows
resolve a Variable column and hold variable-shaped names is now reported with its count — reported,
never fatal, because a scope ruling is somebody's decision and this only puts it next to its cost.

The threshold is measured. Ovarian's `9.PROC PSOC Strategy`, the one sheet any pack has ruled out by
its own IGNORE, has 28 rows, 25 resolving a Variable column and **two** holding a variable-shaped
name; every other ignored sheet in that workbook resolves no Variable column at all. The separation
is 2 against a variable list's dozens.

**CI on Windows.** All six jobs ran `ubuntu-latest`. There is now a `windows-latest` job that runs
the commands a person types, in PowerShell, drives the pipeline through `run_spec_pipeline.py`, and
**redirects** the gate tools to a file — then asserts those bytes decode as UTF-8, with a vacuity
guard so a pure-ASCII capture cannot pass as proof. Both defects in §Environment would have been red
builds.

**The lifter, further.** The two workbooks separate values differently and one of ovarian's labels
contains the other separator (`1=<150,000/uL`). Each cell now picks its own separator and each segment
is matched anchored at both ends: ovarian **61 → 85 lifted, 21 unparsed**, prostate unmoved at 19/0.
The 21 are refusals worth reading — a cell stating two contradictory mappings, a label containing the
separator, a string enumeration beside a parenthesised numeric one, and `3/0 = Unknown` naming two
codes for one label.

**`spec_diff` against a real revision.** It had never run on one — the two prostate revisions are
near-identical, so the CARRIES-NEW-REF verdict had never fired. Four tests now build old/new packs by
really re-extracting a tab so the row numbers genuinely shift: an insertion above a citation carries
with a new ref and brings its settled decision; an edit in place at the same coordinate is a re-draft
and its decision does not travel; a deletion is a re-draft; an unchanged revision carries.

**One finding split in two.** `compare_enumerations` said "the approved YAML does not state these"
whether the bound block held a *different* enumeration or *none at all*. Read as the first, the second
sends a reader to compare a codelist against an integer.

---

## 8. State of the pack after this run

| | |
|---|---|
| Gates | none closed by this run; `releasable` remains derived and `false` |
| Config | **unchanged** — the audit ran in REVIEW MODE and wrote nothing to `variables/` |
| Contract | 202 records, all 18 invariants pass |
| Decisions | 23 rows, 21 OPEN |
| Profiler | `absent_column` / `absent_table` / `stem_drift` all 0 |
| Open items | 13 `unknown_source`, 26 `derived_input_candidate`, 8 `not_in_profile`, 2 `ambiguous_source`, ~191 I15, 3 undispositioned |

The four enumeration findings are evidence for `DECISIONS.md`, not edits. Two of them are questions
already on the register; one is a field blocked on `NAME-ALIGN`; the fourth was a coverage gap in the
lifter, now closed. None of them is a change to `variables/` today.

Re-run the audit after §7 — the lifter reads thirteen more rows on this pack than it did during this
run, including the two test-method maps finding 1 is about, so the comparison covers ground it
previously passed over in silence.
