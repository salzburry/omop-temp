# Engine & config gaps — prostate 202606 (index)

Every place the **current executable** (YAML + shared engine) diverges from the RWB requirement, consolidated
from the six tabs. Each row says whether the fix is **config** (RWP-owned YAML) or **engine** (RWDE, shared
`platform/engine/`), with a minimal acceptance case. This is an **index/backlog**, not a new spec.

A green config-lint proves the YAML is *structurally valid* — **not** that it matches the RWB spec. The rows
below are the known deltas. Work them in the four bounded packages at the bottom, each with its own tests.

## Gap ID index (stable references for the functional contract's `gap_ids`)

`FUNCTIONAL_CONTRACT.md` references gaps by these stable IDs; each maps to the row it labels below. One ID per
gap **row** (the row is the unit of work); a row's sub-aspects are described in that row's cell and in the
variable record's `notes`. The contract CI lint (`handoff/tests/test_functional_contract.py`) requires every
`gap_id` to appear in this table.

| Gap ID | Section · row it labels |
|---|---|
| B1 | Preflight · `lot.detaileddrugcategory` → DrugEpisode (LOT category source) |
| B2 | Preflight · `biomarkers.biomarkerdate` (absent; feed ships resultdate+specimencollecteddate) |
| B3 | Preflight · progression evidence fields (B3a config / B3b semantic) |
| G-ASSAY-TYPE | Source · HRR/BRCA assay type not delivered (blocks HRR_INDEX_TEST / BRCA_INDEX_TEST) |
| G-ADRENAL | Config · ADRENAL_MET lowercase match |
| G-PSA-INDEX-PICK | Config · PSA_INDEX earliest-in-window pick — **APPLIED** (`pick: earliest` is live in `variables/clinical.yaml`, pinned by `tests/test_product_codes.py`); no record cites it by design: the divergence is gone, and live verification is the PSA_INDEX record's `validation` axis, not a gap |
| G-BIOMARKER-NEG | Config · biomarker negative variants (`Mutation Negative`) |
| G-STAGE-0 | Config · STAGE value-set adds a `0` group |
| G-GLEASON-MAP | Config · GLEASON 3-level string map (vs numeric bands that break on `3+4=7`) |
| G-LAB-UNITS | Config · LAB per-analyte units + pre-index window |
| G-MHSPCDD | Config · MHSPCDD family passthrough (`hspcdiagnosisdate`, `crpctype`/`hspctype`) |
| G-STAGE-PREFIX | Config · STAGE longest-prefix collapse — `from_startswith_ci` SHIPPED in the shared engine; remaining work is the RWP config change + confirming the delivered values |
| G-STAGE-MISSING | Engine · STAGE **absent row** → Unknown/5 (left join still yields null). The PRESENT-NULL half is closed: `when: missing` ships and maps a delivered null to its own group instead of CHECK/99 |
| G-REGION-ACADEMIC | Engine · REGION1 academic-only → Unknown |
| G-ECOG | Engine · ECOG cohort anchor + line association + `baseline_ecog ∪ ecog` source union |
| G-BIOMARKER-CLOSEST | Engine · biomarker closest record + same-day conflict rules |
| G-VITALS-DATES | Engine · vitals `_DT` emission + same-day highest-value tie |
| G-LABS | Engine · lab later-of date / `>0` / labcomponent / missing-date→Unknown / pre-index window |
| G-PSADIAG-CRPC | Engine · PSADIAG_CRPC CRPC-anchored PSA derivation |
| G-MET-METDT | Engine · metastasis `_METDT` emission + `≤` boundary |
| G-PSMA-BP-CSF | Engine · PSMA / BP / CSF·SS emission |
| G-ETHNICITY-OR | Engine · ethnicity race-OR-ethnicity union |
| G-ABSENT-LINE | Engine · absent line → category 17 vs null |
| G-LOTN-ZERO | Engine · `coalesce(LOTN, 0)` for untreated |
| G-CSD | Engine · CSD emission (blocked by CSD-SCOPE) |
| G-PRIOR-TAX-PRE | Engine · `prior_tax_pre_mcrpc` not emitted — `pre_mcrpc_source` is commented out in config |
| G-TSST-EMIT | Engine · TSST/TSSTFL still emitted while struck through in the spec; the DTH_BEFORE_FUED guard is not applied |
| G-PER-SETTING-LOT | Engine · per-setting LOT counts (2 mHSPC / 4 mCRPC) |
| G-SETTING-LOT-ED | Engine · setting `LOT*` ED = max drug-episode + setting join |
| G-PRIOR-TX | Engine · prior-treatment drug-episode source / `episodedate < index` / PARP monotherapy / chemo-by-category |
| G-DTH-GUARD | Engine · DTH_BEFORE_FUED guard applied to gated outcomes |
| G-FUED | Engine · FUED drug-episode inclusion + death/study-end caps |
| G-DTHFUFL | Engine · DTHFUFL direction on uncapped preliminary values |
| G-ADS-WHITELIST | Engine · final ADS ordered published-column whitelist |
| G-TTD-PLUS1 | Engine · TTD `+1` inclusive day |
| G-TTNT-CROSS | Engine · cross-setting TTNT (1L mHSPC next = min(mHSPC L2, mCRPC L1, death)) |
| G-RWPFS | Engine · rwPFS precedence / PFSDT-null-for-censored / progression-table censor / day-14 / Boolean evidence |

## ⚠ Preflight blockers — the first strict source-preflight is expected to FAIL on these

| # | Configured field | Problem | Route |
|---|---|---|---|
| B1 | `lot.detaileddrugcategory` | Not on the delivered `Enhanced_ProstateLOT` table — it lives on DrugEpisode / MedicationAdministration. Preflight hard-required it on LOT. | **IMPLEMENTED (Python + R); the Spark grain test runs in CI — pending LIVE Databricks + R↔Python ADS validation.** Engine now aggregates it from DrugEpisode; preflight requires it on `drug_episode`. See B1 detail. |
| B2 | `biomarkers.biomarkerdate` | Column does not exist; feed delivers `resultdate` + `specimencollecteddate`. Preflight requires every configured panel date field. | **RWB decision (BIOMARKER-WINDOW) → RWP config → Gate 3/5.** The engine mechanism is DONE — a block names its record date via `date_basis: {method: later_of, columns: [...]}`. See B2 detail |
| B3 | progression evidence field names + `="Yes"/"No"` | Feed uses `True`/`False` values (physical Spark type — Boolean vs string — needs a live `DESCRIBE`) and different field names; `LastClinicNoteDate` is on the progression table. Preflight requires the configured fields. | Config + engine — see B3 detail (split B3a config / B3b semantic) |

**B1 detail — IMPLEMENTED in Python + R; Spark grain test runs in CI; pending LIVE Databricks + R↔Python validation** (`feat(engine): source line drug-category from DrugEpisode, keyed per setting`). As built, exactly the ONE-contract grain: **within each treatment-stage invocation**, the per-line DrugEpisode aggregate (which already feeds `lot{i}ed`) computes `_lastdate = max(episodedate)` **and** `_has_chemo = max(when(lower(detaileddrugcategory)='chemotherapy',1).otherwise(0))`, then synthesizes a line-level `detaileddrugcategory` (`'chemotherapy'` when `_has_chemo=1`, else NULL) and joins it onto the picked line; the **unchanged** `category_equals` compiler consumes that column for category 9. **Setting grain is config-driven, not physical-column-driven** (the fix for the shared-engine bug flagged in review): the effective line setting is resolved once from the cohort's `line_setting` (falling back to `cfg.lot_line_setting`); when a setting is configured the aggregate **filters drug_episode to it** (mirroring `lot_norm`) and groups by `(patientid, linenumber)`, and the join keys on `(patientid, linenumber)` — because both frames are then single-setting, so an mHSPC line and an mCRPC line with the same `linenumber` never collide (and there is no fan-out against a LOT frame that lacks `linesetting`). When **no** setting is configured (heme/COTA) it aggregates + joins on `(patientid, linenumber)` and does **not** introduce `linesetting` merely because the source carries it. Because the codelist DSL/compiler is untouched, there is **no new codelist operator and no new parity-test case** — but the **R dataflow was mirrored in lock-step** (a substantive, hand-written change, verified by R parse-check, *not* by the parity test). Preflight drops `detaileddrugcategory` from the `lot` requirement and requires `linenumber, episodedate, detaileddrugcategory` on **drug_episode** — plus `linesetting` only when a line-setting model is configured (the same gate as `lot.linesetting`) — all gated on the codelist actually using `category_equals` (`episodedate` because the runtime only builds the aggregate, hence the category, when it is present). Fallback (defensive runtime compatibility, **not** an approved alternate source model — for prostate, drug_episode IS the required category source and strict preflight enforces it): if drug_episode is **absent** or lacks `linenumber`/`episodedate`, there is no aggregate, so `lot{i}ed` falls back to the line enddate and the category comes from any LOT-native column (else NULL). If drug_episode has line/date fields **but no category column**, `lot{i}ed` still comes from the episode date (only the *category* is kept from LOT-native); the episode aggregate is authoritative for the category **only when it actually sources one**. **Notable choices vs the original sketch:** matched `lower(detaileddrugcategory)='chemotherapy'` with **no `trim`**, to be byte-consistent with how `category_equals` itself matches; used `max(when(...))` (version-safe) not `bool_or`; `_has_csd` is **not** folded in yet (CSD stays blocked by `CSD-SCOPE`, but the single aggregate is the place to add it with no extra pass). Note on scans: `treatment.build()` runs **once per cohort** (7 for prostate), so the DrugEpisode aggregate appears once per invocation — whether Spark reuses one physical exchange across cohorts is an optimizer decision to confirm on the Databricks physical plan (`EXPLAIN FORMATTED`), not a code guarantee; do not claim product-level single-scan until then.

**B1 verification status.** Verified locally: config-lint (all packs), full pure-Python suite (incl. new preflight lock-down tests), R parse-check (all `engine-r/*.R`), and R↔Python compiler parity (`test_r_parity.py`, 28/28). What each proves and does **not** prove: parse-check proves R **syntax**; 28/28 proves the **unchanged** codelist compiler/helpers stay aligned — **neither executes or compares the B1 DrugEpisode setting-scoped aggregation or join across engines.** The Spark grain test (`test_treatment_chemo_category_from_drug_episode`: episode-driven category 9, one row per patient, no cross-setting leak on both category and `lot1ed`) now **runs in CI** — the `spark` job installs PySpark and executes `tests/test_stages_spark.py`, whose runner calls every `test_*` function, so the grain assertion is exercised on every push rather than merely defined. That proves the aggregation and join behave on Spark; it does not prove anything about the delivered prostate data. **Remaining to call B1 verified:** run a dev prostate build once B2/B3 no longer stop preflight; and validate the R dataflow against Python either with an equivalent Sparklyr fixture or the planned Python↔R ADS golden comparison.

**B2 detail — THE ENGINE CHANGE IS DONE; THE QUESTION IS NOT.** A block now declares its record date by name:

```yaml
date_basis:
  method: later_of          # column | later_of | earlier_of
  columns: [resultdate, specimencollecteddate]
```

so `greatest(...)` is config, not an engine gap. What remains is entirely human, and none of it is unblocked by the mechanism: `BIOMARKER-WINDOW` must close the "received vs collected" question (RWB); RWP then sets `date_basis` and drops `date_column: biomarkerdate`; Gate 3 confirms both physical columns exist on the delivered biomarker table; Gate 5 validates the values. Do **not** set it before the decision closes — the selector makes the wrong answer as easy to express as the right one.

**B3 detail** — split into **B3a (config/preflight)** and **B3b (semantic engine)**: (B3a) replace the nonexistent evidence field names with the delivered **six** — `isradiographicevidence`, `ispathologicevidence`, `isphysicalexamevidence`, `istumormarkerevidence`, `ispsaincreased`, `ismixedresponsementioned` — set the pseudo-progression field + the `True`/`False` values, and point the censor block at the progression source's `LastClinicNoteDate`; if the fields are **strings**, configuring `"True"`/`"False"` needs no new engine abstraction. (B3b) the current predicate emits quoted `col = 'Yes'` literals (`outcomes.py:73`); if the fields are true **Booleans**, add typed Boolean-literal handling. rwPFS precedence / PFSDT-null-for-censored / day-14 stay as the separate B3b semantic work.

## Config-only (RWP YAML) — deviations the spec resolves

_**Package 1 status:** `CONFIG UPDATED — UNVERIFIED` = applied to `variables/clinical.yaml` but **not smoke-tested** (no PySpark/Databricks here). This is NOT a `✅` handoff row (which means requirement + data-check complete) — verify on the live build._

| Output / row | Current → required | Status |
|---|---|---|
| ADRENAL_MET (clinical 18) | matched `Adrenal Gland` → match delivered lowercase `adrenal` | CONFIG UPDATED — UNVERIFIED |
| PSA_INDEX (clinical 11) | `pick: closest` → **earliest** in `[-14,0]`, same-day → max | CONFIG UPDATED — UNVERIFIED |
| BIOMARKER negative (clinical 12/13) | exact `Negative` → also `Mutation Negative` (spec says *contains* — confirm the exact delivered variants on an exact query; a small `from_contains_ci` may be needed rather than enumerating) | CONFIG UPDATED — UNVERIFIED |
| STAGE `0` (clinical 8) | value set omitted `0` → add a stage `0` group | CONFIG UPDATED — UNVERIFIED (code-0 **provisional** — confirm the exact delivered string. The prefix collapse is no longer an engine gap: `from_startswith_ci` ships, and switching the STAGE groups onto it is RWP config work — see G-STAGE-PREFIX) |
| GLEASON (clinical 9) | 4-way numeric `try_cast` bands (string `'3 + 4 = 7'` → NULL) → **3-level string map via the existing `clinical.categoricals`** (`from_equals_ci`): `<8`={Less than or equal to 6, 3+4=7, 4+3=7, 7 (not documented)}, `≥8`={8,9,10}, else Unknown | OPEN — **config, no new engine capability** (the `categoricals`/`_categorical_pick` route already does string→group); gated on the GLEASON output-naming call (raw `gleason` vs categorized + `gleasonn`; retire `gleason_cat`) under NAME-ALIGN |
| LAB units/window (clinical 16) | no `units:`/`window_days` → add per-analyte `units:` (eligibility only — **no** `…VU` output) + pre-index `window_days` | OPEN — needs the analyte unit strings from an exact profile |
| MHSPCDD family (clinical 1) | not emitted → pass through `hspcdiagnosisdate` as `mhspcdd` **with `optional: true`** (preflight checks *physical* fields; if `hspcdiagnosisdate` is loader-materialized rather than physical, a non-optional passthrough would wrongly hard-require it), `derive` `mhspcddyr` from it, pass through `crpctype`/`hspctype` | OPEN — config, no engine change |

## Engine (shared `platform/engine/`) — capability gaps

| Output / row | Current behavior | Required behavior | Acceptance case |
|---|---|---|---|
| ~~STAGE prefix (clinical 8)~~ **DELIVERED — no longer an engine gap** | `from_startswith_ci` ships beside the unchanged exact-`IN` `from_prefixes`, sorts **longest prefix first** so `III`, `II`, `IV` are evaluated before `I`, and is parity-checked against `engine-r/cases.R`. | RWP config work: switch the STAGE groups to `from_startswith_ci` and confirm the delivered `groupstage` values on a live profile. | `IB1`→I, `IIIA`→III, `IVB`→IV |
| REGION-ACADEMIC (demographics 3) | region from state only | spec `demos.md`: academic-only sites → REGION1 = **Unknown** (needs practice/site context; **not a decision**) | academic-only patient → REGION1=Unknown |
| ECOG anchor + line assoc (clinical 5) | patient+date only; composite INDEX anchor; reads `baseline_ecog` only | **spec-resolved (not a decision):** C1 anchor HSPCDate, C2 CRPCDate; C3-7 match `linenumber=NEW_LOT_N` & `linestartdate=LOT{N}SD`. **Source rule:** read `baseline_ecog`; the spec's "or ecog" means union `ecog` too, dedup by `patientid+ecogdate`, precedence `baseline_ecog` on ties (confirm the precedence on the live cut) | line-2 patient → ECOG at line-2 start; C1 → nearest HSPCDate |
| BIOMARKER closest+conflict (clinical 12/13) | priority-aggregates ALL in-window rows | **spec-resolved (not a decision):** closest qualifying result, equidistant→prior, explicit same-day conflict rules (Pos+Neg→Unknown; Pos+Unk→Pos; Neg+Unk→Neg) | same-day Pos+Neg → Unknown |
| Vitals dates/ties (clinical 6) | emits values only; date-only ordering | emit `heightdt`/`weightdt`; same-day tie → highest value | two same-day weights → highest; date emitted |
| Labs (clinical 16) | testdate only; non-null only; no component filter | later-of(testdate,resultdate); `>0`; optional `labcomponent`; missing-date→Unknown | zero value → excluded; component 'Creatinine, serum' enforced |
| PSADIAG_CRPC (clinical 10) | optional pass-through of `psacrpcdiagnosis` | derive from the PSA table: **earliest** ScoreSerial in `[-14,0]` before CRPCDate (same-day→max) — a CRPC-anchored PSA derivation | CRPCDate 2022-06-01, ScoreSerial at 2022-05-20 → that value |
| Metastasis `_METDT` (clinical 18/19) | flags only; flag uses `<` | emit `_METDT` (earliest date, **independent of flag**); flag uses `≤` | after-index met → MET=No, METDT=that date |
| PSMA / BP / CSF·SS (clinical 7/15/17) | not emitted | add PSMA scan date/result; BP pair; CSF_PRE/FU + SS from drug categories | present in `t_vitals`/psmapet/drug feeds |
| Ethnicity (demographics 5) | maps `ethnicity` only | Hispanic if race=Hispanic **OR** ethnicity=Hispanic | race=Hispanic, ethnicity blank → ETH=Hispanic |
| LOT category source (treatment 4) | ~~`detaileddrugcategory` from LOT frame~~ → **IMPLEMENTED (B1), pending Spark validation:** DrugEpisode filtered to the cohort setting, aggregated per (patient, linenumber), synthesized onto the line, unchanged `category_equals` compiler | join category from drug-episode onto the line | Other-chemo line classified 9 (grain test defined; runs on Databricks) |
| Absent line → cat 17 (treatment 4) | null | a nonexistent line → 17 "No treatment" (or per decision) | patient with 1 line → line-2 cat = 17/null per decision |
| LOTN=0 (treatment 1) | raw LOTN null for untreated | `coalesce(LOTN, 0)` for untreated | untreated mCRPC → LOTN=0 |
| CSD (treatment 7) | not emitted | **BLOCKED BY `CSD-SCOPE`** — implement the approved source (`drug_episode.linename`/`drugname`; no `regimen` column), token, window (INDEX treated / FU overall-untreated), and setting/line scope; if line-based, fold `_has_csd` into the B1 DrugEpisode aggregation (no extra scan) | (defined once CSD-SCOPE closes — do not assume "index line") |
| Per-setting LOT counts (treatment 5/6) | one shared `lines: 2` | 2 mHSPC + 4 mCRPC (per-setting counts) | LOT3SD_MCRPC emitted; no LOT3_MHSPC |
| Setting LOT ED + join (treatment 5/6) | `ed`→enddate; the per-setting `LOT*_MHSPC/MCRPC` columns don't join drug-episode at all | ED = max drug-episode; join includes LineSetting. **NOTE:** B1 already made the *main* `lot{i}ed`/`lotcat` episode aggregate setting-scoped (drug_episode filtered to the cohort setting, then aggregated/joined on patient+linenumber); this row is the separate `_setting_line_columns` path, still enddate-only | mHSPC L1 & mCRPC L1 episodes don't collide |
| Prior treatments (treatment 8-11) | LOT-name / LOT-start `≤ index` | drug-episode regimen, `episodedate < index`; PARP monotherapy; chemo by category | prior line on index day → not "prior" |
| DTH_BEFORE_FUED guard (outcomes 2/4/8/9/12) | computed, never applied | apply once upstream to the spec-gated outcomes — **OS, TRTDIS, TTD, TTNT, TTNTFL**; **TSST/TSSTFL guard applicability is NOT clearly specified → resolve in `OUTCOME-COHORT-MAP`**, don't auto-apply. The exact affected set is part of that matrix. Also: the guard is computed on an already death-capped `fued`, so it must be recomputed on **preliminary/uncapped** values (one state machine with FUED/DTHFUFL). | DTH_BEFORE_FUED=1 → each gated outcome/flag NA |
| FUED (clinical 20) | omits drug-episode; no study-end cap | drug-episode inclusion is strongly supported; the death/study-end caps are **candidate, gated on `FUED-DEFINITION`** | drug-episode after last visit extends FUED |
| DTHFUFL (dataprep 17) | wrong direction on death-capped FUED | `prelim_fu_end − prelim_death ≥ 120` on **uncapped** values (threshold **120** + **1/0** output are **known**; the exact operands, subtraction direction, absent-death behavior, and published type stay open under `DTHFUFL-RULE`) | 121d post-death activity → flag=1 (operands provisional) |
| Final ADS whitelist (NAME-ALIGN) | `assemble.build` returns `ads.distinct()` with **no column selection** — internal helpers (`treat_flag`, `f_death`, `fu_enddt`, `dthfufl_dur`, `dth_before_fued`, `mcrpc`, …) can leak into the published ADS | after NAME-ALIGN, apply a final **ordered column whitelist** (published columns only) + a **Spark schema test** asserting the ADS schema == the approved contract | helper columns absent from the ADS; schema matches the contract |
| TTD +1 (outcomes 8) | `datediff/dpm` (no +1) | `(LOTiED − INDEXDT + 1)/30.4375` — if TTD kept | matches spec by 1 day |
| Cross-setting TTNT (outcomes 9) | next line in own setting only | 1L mHSPC next = min(mHSPC L2, mCRPC L1, death) | mHSPC→first mCRPC counted as next |
| rwPFS (outcomes 10/11) | earliest-of; PFSDT=censor for non-events; visit censor; `='Yes'` | progression precedence; PFSDT null for censored; progression-table LastClinicNoteDate; Boolean evidence | censored patient → PFSDT null, PFS from LastClinicNoteDate |

## Bounded implementation packages (one PR + its tests each — not one giant PR)

1. **Source contract + config-only** — inventory + sampled profile; physical columns/values; stage 0; Gleason; PSA-index pick; biomarker negative/panel; adrenal; lab units/window; provenance; output-naming decisions.
2. **Clinical source selection** — ECOG anchor/line-assoc; vitals dates/ties; biomarker derived date; lab component/date/value; metastasis boundary + dates; BP/PSMA/CSF/steroid; ethnicity OR.
3. **Treatment** — setting-aware drug-episode join; category source; per-setting LOT outputs; prior-treatment rules; raw LOTN=0; CSD; absent-line category.
4. **Follow-up & outcomes** — FUED definition + study cap; DTHFUFL; DTH_BEFORE_FUED guard; TTD disposition; cross-setting TTNT; rwPFS fields/precedence/day-14/censor.

*Prerequisite for all: close the relevant `DECISIONS.md` rows and record the approved workbook in `source_refs.yaml`.*
