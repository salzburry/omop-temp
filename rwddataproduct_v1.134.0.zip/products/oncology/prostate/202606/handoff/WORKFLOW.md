# RWB → RWP → RWDE — the handover workflow (prostate 202606)

> **The authoritative, tumor-agnostic process is [`governance/WORKFLOW.md`](../../../../../governance/WORKFLOW.md)** —
> roles, the six governance gates, the AI boundary and content classification, the status model, the
> traceability model, and the new-product vs refresh branches. **This file is the prostate 202606
> instantiation**: the concrete files, source map, spec tabs and profiling commands for this product.
> Where the two differ, `governance/WORKFLOW.md` governs the *process* and this file gives the *paths*.
>
> Note: the governed process restricts AI from vendor-originated and vendor-derived material (vendor
> documentation, delivered data, and profiling output). The profiling steps below are run by
> people and validated scripts; their outputs are not AI-eligible.

How a requirement travels from **RWB** (the science) through **RWP** (interpretation, profiling, the
YAML) to **RWDE** (the shared engine) — with the exact file at each step and what to do with it.

> **Ownership in one line:** RWB owns the scientific/statistical *intent*. RWP owns the *interpretation,
> the data profiling, and the executable YAML*. RWDE owns the *shared engine and the build*.

```mermaid
flowchart TD
  classDef rwb  fill:#e8f0ff,stroke:#3b6,stroke-width:1px,color:#111
  classDef rwp  fill:#fff4e6,stroke:#e8a,stroke-width:1px,color:#111
  classDef dec  fill:#fde8e8,stroke:#d66,stroke-width:1px,color:#111
  classDef rwde fill:#eafaf0,stroke:#4a4,stroke-width:1px,color:#111
  classDef out  fill:#f0f0f5,stroke:#88a,stroke-width:1px,color:#111

  A["RWB approved program spec<br/><b>PROG_SPEC_..._202606_rXX_APPROVED.xlsx</b><br/>(Excel · the sponsor's document store · versioned)"]:::rwb

  S1["1 · Intake and version<br/>record the exact approved workbook<br/>out: <b>source_refs.yaml</b>"]:::rwp
  S2["2 · Interpret and decompose<br/>one canonical record per output: meaning + source + rule,<br/>flag decisions<br/>out: <b>FUNCTIONAL_CONTRACT.md</b> (draft records)"]:::rwp
  S3["3 · Profile the delivered cut<br/>run_product_profile.py (inventory to sampled to exact)<br/>then profile_facts.py<br/>out (RESTRICTED, outside checkout): <b>$OUT/&lt;product&gt;/&lt;schema&gt;/&lt;cut&gt;/*.tsv</b> + <b>PROFILE_FACTS_&lt;cut&gt;.md</b>"]:::rwp
  S4["4 · Finalize spec and update YAML<br/>close decisions, set stems/windows/codes<br/>out: <b>config/ variables/ codelists/*.yaml</b><br/>+ finalize <b>FUNCTIONAL_CONTRACT.md</b> status axes"]:::rwp

  D["RWB / BIO answer decisions<br/>study window, rwPFS event, CODE-ALIGN, ...<br/>out: decision log"]:::dec

  S5["5 · Implement engine gaps<br/><b>platform/engine/</b> (only rows on the engine-gap list)"]:::rwde
  S6["6 · Build + verify<br/>config to ADS; preflight, tests, QC, golden compare"]:::rwde
  R["7 · RWP validates output · RWB signs methodology<br/>8 · governed release"]:::out

  A -->|"the .xlsx (evidence, NOT a build input)"| S1
  S1 --> S2
  S2 -->|"open decisions"| D
  D -->|"resolved values"| S4
  S2 --> S3
  S3 -->|"facts are evidence; RWP clears a data-check row after review"| S4
  S4 ==>|"FORMAL HANDOFF<br/>FUNCTIONAL_CONTRACT.md (ready records) + config/ + variables/ + codelists/<br/>+ PROFILE_FACTS + acceptance cases + engine-gap list"| S5
  S5 --> S6
  S6 --> R
  R -.->|"change request / next refresh"| S2
```

## What RWP receives, produces, and hands over — step by step

| # | Step | Owner | Input file | What to do (instruction) | Output file (type) |
|---|---|---|---|---|---|
| — | **Approved spec** | RWB | — | Approve and version the program spec; keep it in the sponsor's document store | `PROG_SPEC_…_202606_rXX_APPROVED.xlsx` *(Excel — evidence, not a build input)* |
| 1 | **Intake & version** | RWP | the `.xlsx` | Record the exact workbook identity: filename, `spec_version` (202606), document revision (rXX), stable link, approver, approval date. Note the `data_refresh` (2026m06) separately | `source_refs.yaml` *(YAML)* |
| 2 | **Interpret & decompose** | RWP | the Excel rows (6 tabs: Data Prep · Study Pop · Demographics · ClinChars · TreatVars · Outcomes) | One record per output variable in the canonical crosswalk shape: **meaning/required_rule**, **source** `table.column`, the **rule with the gaps filled** (missing behavior, inclusive/exclusive, codes), and `status`/`decision_ids`/`gap_ids`. Flag anything unsettled via `decision_ids` | `handoff/FUNCTIONAL_CONTRACT.md` *(Markdown — one canonical record per variable; replaces the retired per-tab prose)* |
| 3 | **Profile the delivered cut** | **RWP** (owns conclusions; RWP or RWDE may run the job) | the live `2026m06` Databricks cut + the config `sources:` map | Run `run_product_profile.py <pack> --cut <cut> --schema <schema> --out-dir $OUT` cheap→expensive: **`--inventory-only`** (confirm stems, no data rows read) → **sampled over ALL product sources in one run** (`DC_SAMPLE_N=2000`, screening — feed THIS full-scope TSV to `profile_facts.py`) → **targeted exact** only for specific checks (complete value sets, grain, duplicate keys, joins, same-day ties, window/unit/component), each with a **unique `--out-dir`**. Do **not** feed a one-table exact TSV to the full-product reporter — it marks every other source missing (the reporter now labels that PARTIAL PRODUCT SCOPE). Confirm stems, columns, types, value sets, null rates (grain/duplicates/joins/ties/window need targeted SQL — the reporter can't establish them) | all under `$OUT/<product>/<schema>/<cut>/` **outside the checkout**: `inventory_<cut>.txt`, `profile_<cut>.tsv` *(TSV)*, `PROFILE_FACTS_<cut>.md` *(Markdown)* |
| 4 | **Finalize spec + update YAML** | RWP | interpreted rows + profile facts + closed decisions | Set source stems / windows / codes from the profile and the decisions; update the **executable** config. Set each record's `status` axes (the seven of `governance/WORKFLOW.md` §7 — `requirement`, the four source axes, `implementation`, `validation`) and its `decision_ids` / `gap_ids`; engine gaps are named via `gap_ids` → `ENGINE_GAPS.md`, not a separate status. **This is the file RWP maintains for versioning** | `config/data_product.yaml`, `variables/*.yaml`, `codelists/*.yaml` *(YAML)* + finalized `FUNCTIONAL_CONTRACT.md` |
| ↺ | **Decisions** | RWB / BIO | the open `decision_required` records | Answer methodology/scope questions (study window, MAXINDEX, rwPFS event date, biomarker window, `CODE-ALIGN`, …). Answers land only through the governed write path: `decision_record.py --forms` → the named human fills and signs the committed form → `--apply`. RWP feeds the answer back into step 4 | `handoff/DECISIONS.md` *(the register; `RWB_QUESTIONS.md` is its generated, CI-checked view)* |
| ═ | **FORMAL HANDOFF → RWDE** | RWP → RWDE | — | Hand over: the **ready records** + the updated `config/` + `variables/` + `codelists/` + `PROFILE_FACTS` + acceptance cases + the **engine-gap list**. **Ready = requirement `approved`, `source_mapping: human_confirmed` with its checks passed, output aligned, implementation `implemented` (or gap-classified)** — records still `decision_required` / `proposed` stay with RWP | *(the files above)* |
| 5 | **Implement engine gaps** | RWDE | the engine-gap list (rows whose rule text flags an engine change) | Add the shared-engine capability only where the config can't express the rule (e.g. a per-site metastasis date). Config-only rows need no engine work | `platform/engine/*.py` (+ `engine-r/`) |
| 6 | **Build + verify** | RWDE | config + engine | `config → ADS`; run `validate.py` + source preflight + tests + semantic QC + **golden compare** | ADS table + build/QC evidence |
| 7 | **Accept** | RWP + RWB | the built ADS | RWP checks the output against the functional contract; RWB signs methodology-sensitive results | acceptance record |
| 8 | **Release** | RWDE | — | Governed release stamped with `spec_version` + `data_refresh` + git commit | release manifest |

## The contract and its indexes

[`FUNCTIONAL_CONTRACT.md`](./FUNCTIONAL_CONTRACT.md) is the whole functional contract: **one
markdown-table row per record**, every record in the canonical column shape
(`governance/WORKFLOW.md` §8), enforced by `platform/tools/contract_lint.py` via
[`tests/test_functional_contract.py`](./tests/test_functional_contract.py).
[`DECISIONS.md`](./DECISIONS.md) and [`ENGINE_GAPS.md`](./ENGINE_GAPS.md) **index** it —
`decision_ids` / `gap_ids` point into them, nothing is copied — and the per-record row is the single
source of truth. The lint holds both directions (a cited id must exist; an open decision must be
cited), so the indexes and the contract cannot drift apart.

A record's readiness is its `status` dict — the **seven controlled-vocabulary axes** of
`governance/WORKFLOW.md` §7: `requirement` · `source_mapping` · `dictionary_check` ·
`live_schema_check` · `data_profile_check` · `implementation` · `validation`. Who may set which axis,
and on what evidence, is §7's table: `live_schema_check` arrives only via
`contract_record.py --apply-verdicts` from committed `source_check.py` evidence, `dictionary_check`
stays hand-set, and no tool ever fills in a human's approval.

### Conventions
- **Categorical missing/unknown codes.** Demos-tab fallthroughs (`AGEGR1N`, `REGION1N`, `RACEN`,
  `ETHN`, `PRACTICN`) use `99` as a **config-inferred** code (their RWB "Values" columns were hidden
  in the source) — flagged under `CODE-ALIGN`; those rows keep `requirement: decision_required` until
  it closes. The clinvars-tab codes ARE present and used as specified (`BMIGR1N` Missing = 5,
  `HRR_INDEXN`/`BRCA_INDEXN` Unknown = 4). Distinct by design: `ECOGN` Unknown 6 / Missing 7,
  `STAGEN` fallthrough 99 = CHECK (QC). Continuous missing stays `null`.
- **Authority.** The approved RWB spec + closed decisions govern the requirement; **the contract
  records it**; the executable YAML is the implementation downstream. Where they disagree the
  contract wins and the YAML is corrected — never the reverse.
- **Profile output is restricted.** The profiler TSV and `PROFILE_FACTS_*.md` stay outside the
  checkout (step 3); `handoff/SOURCE_VERDICTS.md` from `source_check.py` is the sanitized,
  commit-safe Gate 3 artifact. The facts reporter is deterministic and read-only: it never edits the
  contract, flips a status, or approves a source — and its output is not AI-eligible.

## File-type legend

| Type | Files | Role |
|---|---|---|
| **Excel** `.xlsx` | RWB program spec | scientific requirement (evidence; *never* a build input) |
| **YAML** `.yaml` | `config/` · `variables/` · `codelists/` · `source_refs.yaml` | **executable** product (RWP-maintained) + provenance |
| **Markdown** `.md` | `handoff/FUNCTIONAL_CONTRACT.md` (contract) · `DECISIONS.md`/`ENGINE_GAPS.md` (indexes) · `PROFILE_FACTS_*.md` | the RWP→RWDE functional contract + its indexes + profiling evidence (generated/authored, *not* run) |
| **TSV** `.tsv` | `$OUT/<product>/<schema>/<cut>/profile_<cut>.tsv` *(restricted, outside checkout)* | machine-readable profile metrics |
| **Tools** `.R` / `.py` | `run_product_profile.py` → `data_profiler.R` · `profile_facts.py` | RWP profiling + facts reporting (deterministic, read-only) |
| **Engine** `.py` | `platform/engine/` (+ `engine-r/`) | shared, locked build engine (RWDE-owned) |

**The one rule that keeps it clean:** the **YAML is the authoritative record of the current executable
implementation**; the **approved RWB spec + closed decisions** govern the intended requirement; the
**handoff** carries meaning, evidence, decisions, and examples — it is not itself run by the engine.
