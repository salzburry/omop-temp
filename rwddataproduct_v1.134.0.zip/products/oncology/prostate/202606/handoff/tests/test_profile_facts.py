#!/usr/bin/env python3
"""The pack's live smoke of the SHARED profile-facts reporter — stdlib only, run directly:

    python3 test_profile_facts.py        # exits non-zero on any failure

Only the checks that need THIS pack's real config live here: the reporter resolves configured
table stems through the product dir, so partial-scope labelling, --strict, cut mixing and
escaping are proven against the pack a person will actually run it on. The reporter's
pack-independent validation/rejection contract is platform code and its suite moved to
`platform/tests/test_profile_facts.py` — archiving this pack must not take the platform's only
profile_io-validation suite with it.
"""
import os, sys, subprocess, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
PRODUCT_DIR = os.path.normpath(os.path.join(HERE, "..", ".."))      # the 202606 product dir


def _repo_root(start):
    """Walk UP for `platform/tools` — the same marker every other tool in this pack uses, so this
    test does not care how deep the pack sits."""
    d = os.path.dirname(os.path.abspath(start))
    while True:
        if os.path.isdir(os.path.join(d, "platform", "tools")):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            raise SystemExit(f"{start}: no platform/tools above this file")
        d = parent


_TOOLS = os.path.join(_repo_root(__file__), "platform", "tools")
PF_PATH = os.path.join(_TOOLS, "profile_facts.py")
sys.path.insert(0, _TOOLS)
import profile_io                                                            # noqa: E402

COLS = ["table", "table_base", "column", "kind", "sampled", "n_rows", "n_rows_total",
        "pct_missing", "distinct", "date_min", "date_max", "top_values"]
HDR = "\t".join(COLS) + "\n"


def row(tbl, col, sampled="FALSE", nr="100", nt="100", pm="0.5", tv="10:a|5:b", kind="categorical"):
    return "\t".join([tbl, profile_io.CUT.sub("", tbl), col, kind, sampled, nr, nt, pm, "3", "", "", tv]) + "\n"


def tmp_tsv(body, header=HDR):
    p = os.path.join(tempfile.mkdtemp(), "profile_2026m06.tsv")
    open(p, "w", encoding="utf-8").write(header + body)
    return p


CHECKS = []
def check(name):
    def deco(f):
        CHECKS.append((name, f))
        return f
    return deco


@check("mixed cuts rejected (CLI)")
def _():
    p = tmp_tsv(row("t_x_2026m06", "c") + row("t_y_2026m07", "c"))
    r = subprocess.run([sys.executable, PF_PATH, PRODUCT_DIR, p, "--out", p + ".md"],
                       capture_output=True, text=True, encoding="utf-8")
    assert r.returncode != 0 and "mixes cuts" in r.stderr


@check("Markdown + HTML escaping (CLI)")
def _():
    p = tmp_tsv(row("t_demographics_2026m06", "state", tv="44:CA|36:<0.1|20:A & B"))
    out = p + ".md"
    r = subprocess.run([sys.executable, PF_PATH, PRODUCT_DIR, p, "--out", out],
                       capture_output=True, text=True, encoding="utf-8")
    assert r.returncode == 0, r.stderr
    txt = open(out, encoding="utf-8").read()
    assert "<br>" in txt and "&lt;0.1" in txt and "&amp;" in txt and "EXACT_METRICS" in txt


@check("partial configured-table scope is labelled; no --strict -> exit 0 (CLI)")
def _():
    p = tmp_tsv(row("t_demographics_2026m06", "state"))     # 1 of ~20 configured stems -> partial
    out = p + ".md"
    r = subprocess.run([sys.executable, PF_PATH, PRODUCT_DIR, p, "--out", out],
                       capture_output=True, text=True, encoding="utf-8")
    assert r.returncode == 0, r.stderr
    assert "PARTIAL CONFIGURED-TABLE SCOPE" in open(out, encoding="utf-8").read()


@check("--strict on a partial-scope profile -> exit nonzero (CLI)")
def _():
    p = tmp_tsv(row("t_demographics_2026m06", "state"))
    r = subprocess.run([sys.executable, PF_PATH, PRODUCT_DIR, p, "--out", p + ".md", "--strict"],
                       capture_output=True, text=True, encoding="utf-8")
    assert r.returncode != 0 and "PARTIAL CONFIGURED-TABLE SCOPE" in r.stderr


def main():
    fails = 0
    for name, f in CHECKS:
        try:
            f()
            print(f"  ok  {name}")
        except Exception as e:                       # noqa: BLE001 - report and continue
            fails += 1
            print(f"FAIL  {name}: {e}")
    print(f"\n{len(CHECKS) - fails}/{len(CHECKS)} passed")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
