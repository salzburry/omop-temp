#!/usr/bin/env python3
"""Contract <-> engine binding for AGE — the anti-drift guard across the spec and the code.

The AGE derivation lives in the governed contract (FUNCTIONAL_CONTRACT.md) AND in both engines. Editing
one without the other used to be silent (only the human `reconciled_against_commit` note attested it).
This test makes them provably agree, so a formula change in any one place fails the build until the
others are updated too:

  * R engine  — the contract's `derivation:` string is the *exact* SQL the R engine executes
    (`dplyr::sql("...")`), so we assert byte-equality: the two copies are forced to stay identical.
  * PySpark   — expresses the same formula structurally (year_index = F.year("index_date"); age =
    F.col("year_index") - F.col("birthyear").cast("int")); we assert those operands + the subtraction
    are present, so swapping the column, the source date, the cast, or the operator trips it.

Scope is AGE specifically (its derivation is an exact SQL string, so an exact bind is possible). Most
other variables' derivations are prose and cannot be bound this way — do NOT generalize this blindly.

stdlib only; run with `python3 test_contract_engine_binding.py` or under pytest.
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PRODUCT = os.path.dirname(os.path.dirname(HERE))                 # handoff/tests -> handoff -> 202606


def _checkout(start):
    """Walk UP for `platform/tools`. Four fixed hops assumed the pack sat at exactly
    products/<area>/<tumour>/<version>; nest it one level deeper and ROOT landed inside products/,
    so the engine files were looked for at products/platform/engine-r/ and the test failed with
    FileNotFoundError on a move that changed nothing about the contract."""
    d = os.path.dirname(os.path.abspath(start))
    while True:
        if os.path.isdir(os.path.join(d, "platform", "tools")):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            raise SystemExit(f"{start}: no platform/tools above this file")
        d = parent


ROOT = _checkout(__file__)
CONTRACT = os.path.join(PRODUCT, "handoff", "FUNCTIONAL_CONTRACT.md")
ENGINE_PY = os.path.join(ROOT, "platform", "engine", "stages", "demographics.py")
ENGINE_R = os.path.join(ROOT, "platform", "engine-r", "stages.R")


sys.path.insert(0, os.path.join(ROOT, "platform", "tools"))
from contract_lint import read, records                             # noqa: E402


def _norm(s):
    return re.sub(r"\s+", " ", s).strip()


def age_derivation():
    """The `derivation:` string from the AGE record in the contract (quotes stripped).

    Through the shared `records()`, not a regex of this test's own. The private version searched for
    a `variable_id: AGE` LINE, which only exists while the contract stores records as fenced yaml;
    when the contract became a markdown table it found nothing and this test failed with "could not
    locate AGE" — a parser mismatch that reads exactly like the engines having drifted. One reader of
    a contract record, and this test is a caller of it like every other tool.
    """
    for block in records(read(CONTRACT)):
        if re.search(r"(?m)^variable_id:\s*AGE\s*$", block):
            m = re.search(r"(?m)^derivation:\s*(.+?)\s*$", block)
            assert m, "the AGE record carries no `derivation:`"
            return m.group(1).strip().strip('"')
    raise AssertionError("no AGE record in FUNCTIONAL_CONTRACT.md")


def test_contract_and_engines_exist():
    for p in (CONTRACT, ENGINE_PY, ENGINE_R):
        assert os.path.exists(p), f"binding target missing: {p} (path/layout changed)"


def test_age_derivation_matches_r_engine():
    """The contract's AGE derivation is the verbatim SQL the R engine runs — assert byte-equality."""
    d = age_derivation()                                        # year(index_date) - cast(birthyear as int)
    r = read(ENGINE_R)
    assert _norm(d) in _norm(r), (
        f"AGE derivation {d!r} (contract) is not the SQL the R engine executes — "
        f"FUNCTIONAL_CONTRACT.md and platform/engine-r/stages.R have DRIFTED. Update both.")


def test_age_derivation_matches_pyspark_engine():
    """The PySpark engine computes the same formula (year_index - birthyear::int) — assert its operands."""
    py = read(ENGINE_PY)
    assert 'F.year("index_date")' in _norm(py), (
        "PySpark demographics.py no longer derives year_index from F.year(\"index_date\") — "
        "diverged from the contract AGE derivation")
    age_line = next((ln for ln in py.splitlines() if 'withColumn("age"' in ln), None)
    assert age_line, "could not find the `age` withColumn in demographics.py"
    body = _norm(age_line)
    for token in ("year_index", "birthyear", 'cast("int")', "-"):
        assert token in body, (
            f"PySpark `age` expression {body!r} is missing {token!r} — it no longer matches the "
            f"contract AGE derivation {age_derivation()!r}. Update the contract and/or the engine.")


if __name__ == "__main__":
    tests = [test_contract_and_engines_exist,
             test_age_derivation_matches_r_engine,
             test_age_derivation_matches_pyspark_engine]
    failed = 0
    for fn in tests:
        try:
            fn()
            print(f"ok  {fn.__name__}")
        except AssertionError as e:
            failed += 1
            print(f"FAIL {fn.__name__}: {e}")
    if failed:
        sys.exit(1)
    print(f"\n{len(tests)} tests passed — AGE contract <-> engine binding holds")
