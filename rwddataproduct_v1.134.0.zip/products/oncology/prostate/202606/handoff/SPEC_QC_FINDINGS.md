# Specification QC findings — prostate 202606

Defects found in the **RWB program specification** while authoring the functional contract, to be
returned to RWB for correction. This is the Gate 2 deliverable defined in
[`governance/WORKFLOW.md`](../../../../../governance/WORKFLOW.md) §5.

**What belongs here:** defects in RWB's own document — impossible values, internal contradictions,
wrong-tumour references, placeholders, omissions. **What does not:** open methodology questions (those
are `DECISIONS.md`) and engine limitations (those are `ENGINE_GAPS.md`).

**Status vocabulary:** `open` (reported, not yet corrected) · `corrected` (RWB issued a revised
workbook) · `waived` (RWB confirmed the current reading; no document change).

> A finding may be **worked around** in config while remaining `open`. A workaround is not a
> correction: until the workbook itself is fixed, the next extraction re-introduces the defect. Every
> workaround therefore names the finding it depends on.

| ID | Spec ref | Defect | Impact | Disposition | Status |
|---|---|---|---|---|---|
| SQ-01 | `study_period:13` | MAXINDEX literal is **`4/31/2026`** — an impossible date (April has 30 days) | Study-window upper bound; gates ID3MOSFU / PFUDUR / STUDY_PD | Read as **2026-04-30** (see below) | **open** |
| SQ-02 | `clinical:89` vs `clinical:94` | FUED defined **twice with different source lists** — r89 uses visit + telemedicine + LOT end + oral end; r94 uses visit + drugepisode(Abstraction) | End-of-follow-up drives OS, TTNT, PFS, all durations | Blocked — `FUED-DEFINITION` | **open** |
| SQ-03 | `clinical:89` | References **`t_enh_metcrc_oral`** — a metastatic **colorectal** table in a prostate specification | Wrong source table; not delivered for prostate | Blocked — `FUED-DEFINITION` | **open** |
| SQ-04 | `clinical:91` | *"If INDEXDT<FUED, then FUED=INDEXDT"* — clamps FUED to index whenever follow-up extends past index; appears reversed | Would zero out follow-up for every followed patient | Blocked — `FUED-DEFINITION` | **open** |
| SQ-05 | `outcomes:15` (and the FU outcome family) | Cohorts **C1/C2 carry bracketed placeholders** (`[Overall mHSPC cohort]`) instead of formulas, and **C7 is absent entirely** | Blocks 11 outcome variables; the product has 7 cohorts | Blocked — `OUTCOME-COHORT-MAP` | **open** |
| SQ-06 | `study_population:12` | COHORTU: *"does not have LOT1_MHSPC then COHORTU='**Treated** mHSPC'"* — the parallel mCRPC branch assigns *Untreated*. Also only **2 of 4** values are ever assigned | Treated/untreated split | Blocked — `COHORTU-LOGIC` | **open** |
| SQ-07 | `demographics:7` + `study_period:32` | DTHFUFL formula `DTHDT-FUED <= 120` contradicts its own note **and** dataprep r32, which both say *"death date 120 days **or more before** the end of follow-up"* (i.e. `FUED − DTHDT >= 120`) | Post-death-activity QC flag; as written it flags nearly every patient | Blocked — `DTHFUFL-RULE` | **open** |
| SQ-08 | `clinical:72` / `clinical:76` | Both rows name the variable **`HRR_INDEX_TEST`**; r76 is labelled *"BRCA Test Type"* and should presumably be `BRCA_INDEX_TEST` | Duplicate variable ID | Non-blocking; contract uses distinct IDs | **open** |

## Findings caused by the delivery format, not by RWB

These are **not defects in RWB's document** — the content exists in the source workbook but did not
survive capture. They resolve by extracting the `.xlsx` directly, with **no RWB
involvement**.

These rows use the SAME header as the table above, and must. `contract_lint._register_rows` finds the
first `| ID | … |` header in the file and reads EVERY pipe row against it, so a second table with its
own column names does not get its own columns — its cells are mapped onto the first header's names,
and any column past the end reads as absent. That is what happened here: these five carried a
`Blocks` column and no `Status`, so `decision_status` could not see a status for them at all, and a
status nothing can read is not `closed`. It stayed invisible because the check fires only when a pack
claims `contract: approved` — the moment it would be most disruptive to discover.

Every status below is `open` because each row's cited decision is open. Close one here when its
extraction defect is actually closed.

| ID | Spec ref | Defect | Impact | Disposition | Status |
|---|---|---|---|---|---|
| SQ-T1 | `treatment:2` | Row ends *"Do separa… (cut off in the source)"* — text lost in capture | LOTN scope cannot be read from the stand-in | Blocked — `LOTN-SCOPE` | **open** |
| SQ-T2 | `treatment:39` | Row ends *"…at least one drug being abiraterone, enzaluta… (cut off)"* | The ADT agent list is truncated, so the engine's filled-in list is unconfirmed | Blocked — `NHA-ADT-AGENT-LIST` | **open** |
| SQ-T3 | `treatment:23` | Per-cohort CSD list truncated mid-line | CSD scope and window cannot be read | Blocked — `CSD-SCOPE` | **open** |
| SQ-T4 | `outcomes:12` `outcomes:13` `outcomes:20` `outcomes:21` | **Strikethrough formatting discarded** — the stand-in header states *"highlight colors ignored"* | Struck outcomes are indistinguishable from live ones | Blocked — `DEPRECATED-OUTCOMES` | **open** |
| SQ-T5 | `outcomes:14` | Strikethrough formatting discarded | Cannot tell whether `TTNTFL` was struck | Blocked — `TTNTFL-DISPOSITION` | **open** |

> Obtaining the approved `.xlsx` and running the deterministic extractor is expected to close all five
> without an RWB round-trip. Formatting that carries meaning (strikethrough) must be preserved by the
> extractor, not discarded — see `governance/WORKFLOW.md` §5 Gate 2.

---

## SQ-01 — MAXINDEX, resolved reading

**Defect.** `study_period:13` gives MAXINDEX as `4/31/2026`. April has 30 days, so the literal cannot be
parsed as written.

**Resolution applied: `2026-04-30`.** Two independent lines of evidence agree:

1. **Typo correction.** Day-31 in a 30-day month is a single-digit slip; day-30 is the only reading that
   preserves the stated month and year.
2. **Delivery-lag corroboration.** `DATAV = 20260630`. `2026-06-30 − 2026-04-30 = 61 days`, matching the
   ~60-day delivery lag the specification raises for MAXINDEX. The alternative reading (`3/31/2026`)
   implies a ~91-day lag, which nothing in the specification supports.

The lag question is therefore answered as a by-product: **the lag does apply**, and the previous config
value of `2026-06-30` — the raw cut date with no lag — was wrong.

**Effect.** `study.index_end` moves `2026-06-30 → 2026-04-30`. The admissible index window narrows by
~2 months, so **cohort membership shrinks** relative to any earlier build. This is a deliberate
correction, not drift, and must be expected in the first golden comparison after this change.

**Still owed by RWB.** The workbook literal is uncorrected. Until it is, re-extraction will re-introduce
`4/31/2026`, so this finding stays `open` and the config comment cites it.
