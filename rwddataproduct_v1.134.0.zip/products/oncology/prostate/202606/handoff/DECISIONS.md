# Decisions — prostate 202606 (index)

Every open **⛔ decision** across the six handoff tabs, in one place. A decision is a question a **human**
(RWB / BIO / RWP) must answer — it is *not* an engine gap (those live in `ENGINE_GAPS.md`). This is an
**index**, not a new spec: the authoritative wording is the RWB program-spec; the detail is in the tab cell cited.

**A handoff row becomes `✅` (ready for RWDE coding) when the decisions *applicable to that row* are closed, its
data-checks are cleared, its output contract is fixed, and any engine gap is precisely specified with acceptance
cases in `ENGINE_GAPS.md` — engine *implementation* is NOT required first.** So one unrelated open decision does
not block every row; bounded packages can hand off independently.

Provenance is still `pending` (`source_refs.yaml`) — until the approved workbook revision is recorded, every
"spec says…" below is *"documented in the available stand-in, pending confirmation of the approved revision."*

| ID | Question | Conflict / evidence | Owner | Approved answer | Approved by | Approval date | Status |
|---|---|---|---|---|---|---|---|
| STUDY-WINDOW | What is MININDEX? | RWB `2011-01-01` vs config `2020-01-01` (dataprep 2, demographics banner) | RWB/RWP | **`2011-01-01`** — the RWB spec value (dataprep r14 `01-Jan-11`) governs; config previously used 2020-01-01. Widens the window ~9 years, so cohort counts grow. |  |  | RESOLVED |
| MAXINDEX | What is the valid study-end, and does the 60-day delivery lag apply? | RWB `4/31/2026` (impossible date) vs config `2026-06-30` (dataprep 3) | RWB | **`2026-04-30`; the lag DOES apply.** Day-31 is impossible in April; 2026-04-30 is the only reading that also matches the ~60-day lag (DATAV 20260630 − 61d). RWB must still correct the workbook literal — `SPEC_QC_FINDINGS.md` SQ-01. |  |  | RESOLVED |
| FUED-DEFINITION | How is end-of-follow-up defined (which activity sources, death cap, study-end cap)? | Spec leaves it open; engine caps at death, omits drug-episode + study-end cap (dataprep 6, clinical 20, outcomes 2/4) | RWB/RWP | — |  |  | OPEN |
| DTHFUFL-RULE | Which preliminary dates + subtraction direction implement "≥120 days after death"? (the 120 threshold + 1/0 output are known) | Engine measures wrong direction on a death-capped FUED (dataprep 17, demographics 9) | RWB | — |  |  | OPEN |
| CODE-ALIGN | Confirm the demographics-tab `99` fallback codes (the tab's Values column is hidden in the workbook, so the `99=Unknown` fallthrough is config-inferred, not spec-stated) | AGEGR1N/REGION1N/RACEN/ETHN/PRACTICN (WORKFLOW.md convention); config adds the `Unknown` label in `variables/demographics.yaml#/age_bands` and `variables/demographics.yaml#/regions` | RWB | — |  |  | OPEN |
| BIOMARKER-WINDOW | Window (`[-30,+7]` vs any-time-before-index) and date basis (specimen-collected vs -received) | Data Prep vs clinical conflict; feed has `specimencollecteddate` not `received` (clinical 12, dataprep 15) | RWB | — |  |  | OPEN |
| TT-INTERVAL-FORMULA | TINTCRPCHSPC sign + divisor `30.4375` vs `30.4376` | Source typo; label says HSPC→CRPC but formula is hspc−crpc (clinical 3) | RWB | — |  |  | OPEN |
| DEPRECATED-OUTCOMES | Keep or drop TRTDIS / TTD / TSST (struck in the spec but still emitted)? If kept, TTD needs the `+1` | Struck-through in RWB; config emits them (outcomes 8/12) | RWB | — |  |  | OPEN |
| OUTCOME-COHORT-MAP | The per-cohort **C1–C7** applicability matrix for every FU outcome: applicable-or-null, line anchor, event + censor defs, ID3MOSFU + DTH_BEFORE_FUED gating, and the C7 next-treatment **source** + event definition + censoring when no qualifying next treatment is observed (the boundary is the next-treatment *source*, not ADS publication — a LOT5 source record may be usable even if LOT5 isn't a published column). RWP drafts the matrix, RWB approves | Spec `outcomes.md` uses legacy partial mappings (TRTDIS/TTD C2–4; TTNTFL C2–4; TTNT C2–6, omits C7; TSSTFL C2–5); the engine applies line outcomes generally (`outcomes.py`) | RWP/RWB | — |  |  | OPEN |
| TTNTFL-DISPOSITION | Is struck `TTNTFL` published, internal-only, or removed? (cross-setting TTNT itself is a confirmed engine requirement — in ENGINE_GAPS) | outcomes 9 | RWB | — |  |  | OPEN |
| RWPFS-DAY14 | Progression eligibility boundary `> index+14` vs `>= index+14` | Spec-internal inconsistency (outcomes 11) | RWB | — |  |  | OPEN |
| OS-ID3MOSFU | Keep the engine-added ID3MOSFU gate on OS? (the OS var def gates on DTH_BEFORE_FUED, not ID3MOSFU) | Engine gates OS on id3mosfu; a general note says outcomes run where id3mosfu=1 (outcomes 4) | RWB | — |  |  | OPEN |
| ABSENT-LINE-CATEGORY | For a nonexistent line, is the LOT category null or 17 "No treatment"? | Engine leaves absent lines null; 17 fires only on an existing null-linename row (treatment 4) | RWB/RWP | — |  |  | OPEN |
| COHORTU-LOGIC | Confirm the "Treated mHSPC" no-LOT1 branch is a spec typo for *Untreated* | Spec text vs config clean per-setting rule (studypop 5) | RWB | — |  |  | OPEN |
| ID-PD-CONTRACT | Are ID_PD_mCRPC / ID_PD_mHSPC published ADS vars, internal gates, or replaced by cohort-row inclusion? | Engine emits neither; only an internal `mcrpc` flag (studypop 1/2) | RWP | — |  |  | OPEN |
| LOTN-SCOPE | Is LOTN mCRPC-only, or cohort-setting-specific? (LOTN=0-for-untreated is a *requirement*, in ENGINE_GAPS) | Scope unstated (treatment 1) | RWB/RWP | — |  |  | OPEN |
| NAME-ALIGN | The exact output contract — per field: **published name · physical name · type · nullability · codes · role** (published / internal-only / metadata-only / excluded). Must settle at least: `DATAV`, `RAWRWD`, `INDEXDT`↔`index_date`, `ID_PD_mCRPC`, `ID_PD_mHSPC`, **raw vs categorized Gleason** (`gleason`/`gleasonn` vs `gleason_cat`/`gleason_raw` — the raw and categorized outputs **must not share the physical name `gleason`**), `TTNTFL`/`TSSTFL`/`TRTDIS`, `CSD` (= Clinical Study Drug), the **HRR/BRCA `_INDEX_TEST*` assay fields** (published-null / excluded / metadata?), and the `conmed_*`/`hepatic_met` additions. **The final ADS must be an approved ordered column whitelist** — the engine currently publishes every joined column incl. internal helpers (see ENGINE_GAPS "final ADS whitelist") | Engine emits lowercase + only stamps id/version/refresh, no final `select` (treatment 14, dataprep 1, assemble.py) Enumeration audit: the spec states the published 1/0 code pairs for `VIS120` (`outcomes:11`), `ELIGPFS` (`outcomes:16`) and `PFSFL` (`outcomes:17`) — `1=Yes`, `0=No`, and for the last two `missing` as a permitted state — in their **Values** cells; the config blocks the contract binds those rows to (`variables/outcomes.yaml#/visit_recency_days`, `#/min_followup_days`, `#/progression`) hold the RULE and assign no codes. Whether these flags publish 0/1/null and under which physical names is this row's question. | RWP/RWDE | — |  |  | OPEN |
| NHA-ADT-AGENT-LIST | Confirm the full ADT agent list (the spec was truncated) | Engine filled leuprolide/goserelin/degarelix/relugolix/%adt% (treatment 11) | RWB | — |  |  | OPEN |
| CSD-SCOPE | How is CSD ("Clinical Study Drug") computed? physical source (`drug_episode.linename`/`drugname` — **no `regimen` column** is delivered), match token (`"CSD"` vs `"Clinical Study Drug"` — the delivered value is the latter), FU window for overall/untreated, setting/line scope | Spec `treatvars.md` row 23 has **potentially inconsistent source statements** — `index()` is SAS substring-search, not "index line", and the capture flags the block's placement as uncertain (treatment 7). (0-vs-null is NOT open — spec says `1/0/else 0`.) | RWB | — |  |  | OPEN |
| PRACTICE-MISSING-CODE | Is "no practice rows → Missing (99)" intended? | Unconfirmed (demographics 6) | RWP | — |  |  | OPEN |
| HEPATIC-MET-INCLUDE | Keep `hepatic_met` (a config addition not in the RWB site rows)? Same for delivered `lymph node`. | Config addition (clinical 18) | RWB/RWP | — |  |  | OPEN |
| CONMED-INCLUDE | Keep `conmed_bp`/`conmed_csf`/`conmed_steroid` (not in RWB spec; differ from CSF_PRE/FU/SS)? | Config additions (treatment 13, clinical 17) | RWB/RWP | — |  |  | OPEN |
| PRIOR-TAX-INCLUDE | Keep `PRIOR_TAX`? It is an **engine addition with no spec row** — RWB never asked for it. Confirm the provenance, or drop it. | No captured spec row; `spec_refs: [none]` | RWB/RWP | — |  |  | OPEN |

**Not decisions (moved to `ENGINE_GAPS.md` as requirements/deviations — recorded so they don't get re-litigated):**
*stage prefix + stage-0*, *Gleason 3-level string map (config via `categoricals`)*, *PSA-index earliest pick*,
*PSADIAG_CRPC derivation*, *metastasis `≤` + independent `_METDT`*, *setting-LOT ED = max drug-episode*,
*prior-treatment `episodedate < index`*, *rwPFS progression precedence + progression-table censor*, *REGION1
academic→Unknown* (`demos.md`), *ECOG C1/C2 HSPC/CRPCDate anchor + C3-7 line association*, *biomarker
closest-record + same-day conflict rules* — the RWB spec resolves these. Biomarker **assay type**
(HRR/BRCA_INDEX_TEST) is **not derivable** from the delivered feed (no assay field).
