# `spec_pipeline/` — deterministic spec processing

Runs the approved specification through extraction, defect scan, coverage and scaffolding. Nothing here
edits a governed artifact; everything in `out/` is **generated evidence**.

```bash
platform/tools/run_spec_pipeline.sh products/oncology/prostate/202606
platform/tools/run_spec_pipeline.sh products/oncology/prostate/202606 --check   # CI: fail if stale
```

| Artifact | What it is |
|---|---|
| `out/extracted.json` | every spec row with original Excel coordinates, a content hash, a stable item id and its columns resolved **by name** from the tab's own header |
| `out/SPEC_FINDINGS.txt` | deterministic defect scan, ranked **HIGH** (wrong or unusable) / **INFO** (annotated by design) |
| `out/lint.json` | the same findings, machine-readable |
| `out/COVERAGE.md` | **every spec item and its disposition** — the Gate 2 completeness evidence |
| `out/scaffold.json` | skeleton records for items still needing judgment, judgment fields marked `TODO` |

`pipeline.conf` holds the two per-product parameters: tumour slug and spec source. The sheet -> domain
mapping and the set of requirement-bearing sheets are shared, in
[`governance/spec_sheet_map.yaml`](../../../../../governance/spec_sheet_map.yaml) — RWB's sheet names
are their template, so restating them per product would copy a shared fact and invite it to drift. The
runner is shared across products, same pattern as the engine.

**Regenerate, never hand-edit.** A stale `out/` is evidence of nothing, which is what `--check` guards.

## Reading COVERAGE.md

Every item resolves to exactly one disposition. `UNDISPOSITIONED` is the only failing state —
`decision_required` items are *intentionally* unresolved and still count as accounted for.

Items no contract record cites, but which are genuinely handled elsewhere, are declared in
[`../handoff/spec_dispositions.yaml`](../handoff/spec_dispositions.yaml), each naming **where** it is
handled. That file is what stops "handled by section A2" and "overlooked" from looking identical.

Current state: **200 items — 192 mapped · 5 control · 2 duplicate · 1 context · 0 undispositioned**, and
`out/SCAFFOLDED_RECORDS.md` is empty: nothing in the prostate spec is waiting for a record.

## Columns are read by name, not by position

Each tab's own header row decides which cell is the variable, the definition, the notes. The columns move
between tabs (`4.StudyPop` puts Variable third, behind Section and Time Period) and are labelled
differently per product (`Definition` vs `Definition / EDM derivation`), so position is not a safe proxy —
reading by position reported the `Time Period` cell as the variable name on 192 of these 200 rows, and
carried the `Label` cell into `required_rule` on 148 of them. Both failures are silent: the output stays
well-formed. `platform/tests/test_spec_pipeline.py` holds the resolution, and the extraction summary
prints how many rows resolved by header versus fell back to position.

Spec columns with no home among the 21 contract keys — `Label`, `Values`, `Time Period`, the codelist
group — are carried **verbatim alongside** each scaffolded record rather than guessed into a field.
