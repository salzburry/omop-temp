# The participation pilot — read, ask, and feed the question queue

Two or three named people from commercial / HEOR / epi join as **consumers**, not authors:
they read the generated pages, ask feasibility questions through the exploration lane, and
every definition they have to assume becomes recorded demand for the decision loop. Nothing in
this pilot adds an approval path — pilot users are **requesters in the register, never
approvers**, and commercial use of any output remains subject to its own compliance review by
the policy owners, which this document does not replace.

## Who (fill in before starting — names, not teams)

| role | name | function |
|---|---|---|
| pilot user 1 | _TODO_ | commercial |
| pilot user 2 | _TODO_ | HEOR |
| pilot user 3 (optional) | _TODO_ | epi |
| pilot owner (routes the intake into the decision loop) | _TODO_ | RWP |

## What pilot users get

1. **The read pages.** One folder, any static host:

       python3 platform/tools/publish_site.py --out <site-dir>

   Regenerate on every push. The pages accept no input and perform no approvals; each carries
   the commit it was generated from. Locally: add `--serve` for a preview.

2. **The chat page** (questions in plain language, every answer showing the command behind it):

       python3 platform/tools/chat_demo.py        # router mode, or API mode with a key

   The keyless `--backend cli` mode is NOT part of the pilot — demo use only, per its own
   startup caveat.

3. **The exploration lane** (counts-only feasibility, small cells suppressed):

       python3 platform/tools/quick_counts.py <pack> --frame <tsv> --by <column> \
           --log-dir <intake-dir> --asked-by "Their Name"

   The rules the lane enforces are the pilot's rules: counts only; a column no contract
   defines must be `--assume`d with its meaning and lands in the intake ledger, or the query
   refuses to run. Where the frame lives (and whether the user may touch it at all) follows
   the data-access policy for that source — the lane prints counts and stores none of the
   frame, but it does not grant anyone access to anything.

## The loop that makes the pilot worth running

Weekly, the pilot owner runs:

    python3 platform/tools/quick_counts.py --intake <intake-dir>
    python3 platform/tools/precedent_metric.py

The first says which definitions pilot users keep assuming — each recurring name is a real
question routed into the decision loop (the answer-decisions path owns the phrasing; nothing
is auto-promoted). The second tracks candidate precedent coverage: as rulings accumulate, new
questions should increasingly find candidate answers from earlier packs — the compounding the
platform's scalability claim rests on, measured instead of asserted.

## What pilot users must not do (and mostly cannot)

* No patient-level rows leave any tool — every surface is counts-only by construction.
* No approvals, decision answers, or rulings — those are committed file edits by the named
  owners; a pilot user's want becomes a QUESTION in the register.
* No AI tool reads vendor material on their behalf — the AI boundary is unchanged by the
  pilot (governance/WORKFLOW.md owns it).

## Exit criteria

The pilot has worked when, after ~4 weeks: the intake ledger contains recurring assumed
definitions (demand exists), at least one intake item has been phrased into the register and
answered (the loop closes), and the pilot users can answer "where does X stand" from the site
without asking an engineer (the surfaces carry themselves).
