# Deploying the governance app on Domino

`app.sh` + `app/serve.py` are the Domino app: the READ-ONLY governance surfaces (status flow,
rule review, worksheet, decision packets, knowledge-graph search), computed fresh per request
from the checked-out commit by the same tools CI verifies, with the served commit stamped in
every footer. The practices below are what keep a hosted window from becoming a hand.

## Set-up

1. **Git-based Domino project pointing at this repository, pinned to `main`.** The app serves
   whatever is checked out, so the checkout must be a MERGED state — never a working copy, never
   a feature branch. What is on screen is then exactly what passed CI and review.
2. **App entry point:** Domino runs `app.sh` at the repo root; it starts `app/serve.py`, which
   binds `0.0.0.0` on `$PORT` (Domino's proxy sets it; default 8888). No web framework — the app
   is stdlib Python, so any Python 3.11 compute environment works.
3. **Compute environment: pin it.** A named, versioned Domino environment (Python 3.11.x, PyYAML)
   — the same pin-by-name discipline as `.github/workflows/rwdp-ci.yml`. No other dependency is
   needed; do not add one for the app's sake.
4. **Access: project collaborators only.** The pages carry governance state including approver
   names. Never "anyone with the link", never public.
5. **Redeploy on merge, not on a timer.** Restart the app when `main` moves (manually, or a CI
   step calling Domino's API). A timer-synced app can show a state nobody decided to publish; a
   merge-triggered one shows only decided states — and the footer's commit hash is how a reader
   checks which.

## The boundaries that must survive deployment

- **No vendor material near the app.** Do not mount Domino datasets holding delivered data,
  profiles or data dictionaries into this project. The repository holds none by construction
  (`repo_hygiene` enforces it), and the app serves only from the repository.
- **The app performs no governed act.** Approvals, signatures, decision answers and maturity
  claims are committed file edits by a named person, through a pull request. If the app ever
  grows a POST route or a write flag, that is the hole this design closes —
  `platform/tests/test_app_serve.py` pins the read-only surface and fails the build on a hand.
- **Rendered pages land outside the tree** (a temp dir), same as every restricted output; the
  checkout stays byte-identical under any amount of serving.
- **Builds do not run here.** The Databricks bundle (`resources/products.yml`, `run_rwdp.py`) is
  the execution surface; Domino hosts the window. Keeping them separate is what keeps "who can
  see" and "who can run" as two different permissions.

## Test it locally first — Windows, VS Code

`app.sh` is only Domino's entry shim; locally you run the server directly. In a VS Code terminal
at the repo root:

    set HOST=127.0.0.1
    py app\serve.py

then open http://localhost:8888 in a browser (set `PORT` first to use another port). The
checklist, each of which is also pinned by `platform/tests/test_app_serve.py` and verified over
real HTTP before this was committed:

1. `/` lists every pack with its three views and question packets, plus the decision search.
2. A flow page renders (~25 KB), a questions page renders (~23 KB),
   `/knowledge?q=fued` returns decision cards with approver and citations.
3. The footer of every page stamps the commit being served — compare it to `git rev-parse
   --short HEAD`.
4. `/page?view=flow&pack=products/../etc` returns 404 — a URL cannot name a path the
   repository does not hold.
5. `git status` stays clean while you browse — serving writes nothing into the checkout.

For plain HTML files with no server at all (to open from disk or mail to a reader), generate
them OUTSIDE the checkout, per the restricted-output rule:

    py platform\tools\render_html.py flow products/oncology/prostate/202606 --out %USERPROFILE%\rwdp\flow.html
    py platform\tools\decision_packet.py products/oncology/prostate/202606 --out %USERPROFILE%\rwdp\questions.html

These are the same pages the app serves — one generator owns both paths, so what you test from a
file is what Domino will serve.

## What to demo from it

Open `/` — every pack, three views and its question packets, plus the decision search. The flow
page is the six gates with their real blockers; `/knowledge?q=...` answers "have we decided this
before" with approver and date. The footer's commit hash ties the whole screen to one merged,
CI-verified state.
