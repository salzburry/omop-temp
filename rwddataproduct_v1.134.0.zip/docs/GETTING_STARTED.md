# Getting started — your first 30 minutes

Read `README.md` → "Who are you?" first. If your role is answer-giver or reviewer, stop here:
someone brings you a packet or a workbook; you never need this page. This page is for the
person operating the tooling.

## 1. Install and verify (10 min)

    pip install -r platform/requirements.txt "pyspark>=3.5"
    python3 -m pytest platform/tests -q        # full suite; expect all green, ~35 min
    # or the fast confidence check (~2 min), no Spark:
    python3 -m pytest platform/tests -q --ignore=platform/tests/test_stages_spark.py -k "not spark"

A red test on a fresh clone means your environment, not the repo — start with
`python3 platform/tools/doctor.py --out-dir <tmp>`.

## 2. See where things stand (5 min)

    python3 platform/tools/status.py                                   # every pack, one line
    python3 platform/tools/status.py products/oncology/prostate/202606 # six gates, next owner
    python3 platform/tools/executive_page.py --out ~/exec.html         # the one-page view

## 3. Ask questions in plain language (5 min)

    python3 platform/tools/chat_demo.py        # open http://127.0.0.1:8377

Click the example chips. Every answer shows the command that produced it. With a `claude`
login or an API key it becomes conversational; without either it is a fixed router.

## 4. The five commands you will actually use

| you want | run |
|---|---|
| where does X stand / what blocks it | `status.py <pack>` |
| where did this number come from | `receipt.py <pack> --variable <ID>` |
| what should we ask the methodology owner | `decision_packet.py <pack> --out ~/q.html` |
| is this draft workbook ready to hand off | `spec_precheck.py <draft.xlsx>` |
| publish the read pages for stakeholders | `publish_site.py --out <dir>` |

The full command-per-question table is `docs/CHAT_JOURNEY.md`. Standing up a new tumour is
`platform/TUMOR_TEMPLATE/NEW_TUMOUR.md`. Engineering internals are `docs/ENGINEERING.md`.

## 5. The three rules that keep you safe

1. **Tools draft and check; people decide.** Anything shaped like an approval, an answer, or
   a ruling is a named person's dated edit to a governed file. Tools refuse to do it for you.
2. **Absence is never a pass.** A check that could not run says so. Do not read a missing
   report as a clean one.
3. **Generated files are regenerated, never edited.** Anything marked GENERATED has a tool
   and a `--check`; edit the source, rerun the tool.
