# Production readiness — the plan, from stress-tested evidence

**What "production ready" means here, concretely:** (a) one pack through all six gates with
committed human evidence; (b) the platform SIT-passed on the real infrastructure (Databricks
DBR 15.4, Domino); (c) the organisational controls live (rulesets, CODEOWNERS, identity); and
(d) a repeatable per-tumour rollout proven by a second pack. Anything less is a demo.

**Where this plan comes from.** A four-angle stress round run against `b2e55f8`, each in an
isolated clone: (1) a new-tumour bootstrap followed literally from the docs (synthetic "bladder"
pack — extraction, lint, contract, decision loop and a synthetic ADS all reached); (2) a
151-cell tool×pack matrix over all six pack states plus app fuzzing; (3) a red team running
25+ tampers against the gates; (4) a multi-tumour engine audit (feature coverage, hardcoded
assumptions, release-path collisions, a full-suite run — the suite has grown since, so
`pytest --collect-only -q platform/tests` is the count, not this sentence). Everything repo-fixable and
high-severity found by that round is **already fixed and pinned** — the table at the bottom is
the ledger. What no repository commit can supply is Phases 1–3's human evidence and
infrastructure runs; that is the plan.

The state of every pack is always `python3 platform/tools/status.py`; the latent blockers behind
any approval claim are `python3 platform/tools/dry_run.py <pack>`. Those tools own the numbers —
this document deliberately repeats none of them.

---

## Phase 0 — held today (the baseline the plan builds on)

- Six gates, one owner per question; every governed act is a committed file edit by a named
  person; the tools refuse to perform one. Red-team round: 25+ tampers, every transition tamper
  caught by the gate that owns it (register hand-edits, form forgery, hash staleness, generated
  drift, hygiene, app injection/traversal).
- A 900+-test suite (`pytest --collect-only -q platform/tests` is the count — a number written
  here goes stale the week it lands) including per-stage Spark suites, an end-to-end synthetic
  build of **every** configured tumour, five hand-computed patient goldens, and R↔Python
  byte-parity across five packs' codelists.
- Source pinning end to end: builds read `versionAsOf`-pinned inputs, publication refuses
  unpinned lineage, the release receipt speaks the manifest schema's vocabulary.
- The read-only app (Domino window) with a plain-language status board; fail-closed everywhere a
  stress agent poked it.

## Phase 1 — the pilot pack earns its gates (prostate/202606; owners: RWB / RWP / RWDE)

Work `dry_run.py` top to bottom; each act is a committed file edit and the tool re-verifies.
In order:

1. **Gate 1 — the source is signed** (RWP): register the approved workbook revision
   (`source_refs.yaml` → `status: reviewed` + attestation), and re-sign the sanitized
   extraction (the three-line edit; still absent). Everything downstream cites this.
2. **Gate 2 — the questions are answered** (RWB, via the forms only): the ranked page
   (`RWB_QUESTIONS.md`) top-down; the two pre-filled-but-unsigned rows (STUDY-WINDOW, MAXINDEX)
   get real forms so the ruling is bound to an attestation — the new `decision_record --check`
   makes that binding permanent; the 13 SPEC_QC findings each get a status; then
   `CONTRACT_APPROVAL.yaml`.
3. **Gate 3 — the source is verified against the live feed** (RWP/RWDE on the cluster):
   profile the delivered cut, `source_check.py <pack> --profile <cut>.tsv --complete` →
   `SOURCE_VERDICTS.md`, then `apply-source-verdicts`. 166 vendor-sourced records carry no
   Gate 3 evidence today; this is the single largest block of work in the plan.
4. **Gate 4 — the configuration is approved** (RWP + RWDE): settle the two output-layer
   decisions (CODE-ALIGN, NAME-ALIGN — the exact published-name/code contract), then
   `CONFIGURATION_APPROVAL.yaml`.
5. **Gates 5–6 — build, validate, release** on the real cluster (Phase 2's S1–S4 are the
   rehearsal): candidate build, QC + goldens against live data, then the release approval and
   the promotion that writes the receipt.

## Phase 2 — platform SIT on real infrastructure (owner: RWDE)

The stress round's sharpest lesson: **two `NameError`s lived in the only file no test
environment can execute** (`run_rwdp.py` — the validate-only exit and the promotion branch;
both now fixed and order-pinned). Local suites cannot stand in for the cluster. The matrix —
each row produces a named evidence artifact:

| # | Test | Environment | Evidence |
|---|------|-------------|----------|
| S1 | `cd build/deploy && databricks bundle deploy` (the generated tree is the only deploy route) + validate-only job run of prostate — the governed smoke; exits `validate_only`, writes the evidence manifest | DBR 15.4 | run URL + manifest |
| S2 | Build twice against moving source tables; pins recorded and honoured (`versionAsOf`) | DBR 15.4 | manifest lineage |
| S3 | Negative: unpinned input → `PUBLICATION REFUSED`; error lineage → released-manifest refusal | DBR 15.4 | job log |
| S4 | Kill a promotion mid-flight; re-run resumes from the journal without rebuilding | DBR 15.4 | journal states |
| S5 | `source_check --profile <real cut> --complete` → verdict report (also Phase 1 step 3) | secure env | SOURCE_VERDICTS.md |
| S6 | Domino app deploy per `docs/DOMINO.md`; its 5-point checklist; footer commit = deployed main | Domino | screenshots + hash |
| S7 | App under concurrent load (threaded server, per-request temp files) — 50 parallel readers | Domino | clean `git status` |
| S8 | Full CI green on org runners, including the Windows/PowerShell lane | GitHub org | run |
| S9 | Codelist-label alignment class: config labels vs live `SELECT DISTINCT` (the failure class just seen in the legacy cohortattrition pipeline) | DBR 15.4 | source_check verdicts |
| S10 | Spark **3.5** lane: CI pins pyspark 4.x while DBR 15.4 runs Spark 3.5 — add a 3.5 matrix leg or accept S1 as the only 3.5 execution, in writing | CI | lane green |
| S11 | R entry-point/packaging class (parse + parity lanes already exist; S8 proves them on org runners) | CI | lane green |

## Phase 3 — organisational controls (owner: repo admin; none of this is a repo commit)

1. Branch protection/rulesets on `main`: require the CI checks, require review, forbid
   force-push. Without this, every gate is advisory against a determined push.
2. `CODEOWNERS` → real teams; the governed tree already routes.
3. Approval identity: pick and implement one of `governance/APPROVAL_IDENTITY.md`'s options so
   "a named person edited this file" is backed by authentication, not convention.
4. Access separation: repo read, Databricks run, Domino view are three different grants.
5. Merge strategy for this branch: the external audit recommended themed PRs; the branch
   currently carries the whole platform.

## Phase 4 — multi-tumour rollout (the "different tumours" answer)

The bootstrap stress proved Gates 1–2 and a synthetic build stand up for a brand-new tumour
from the template; its 13 findings are fixed (docs completed, template commits clean, closed
set covers the gate artifacts). The engine audit proved release names cannot collide across
products (and the one uncovered seam — two packs declaring one `output_table` — is now a test).
Order of march:

1. **oc/202606 completes second** — it exercises five engine features prostate never touches
   (maintenance lines, raw `linenumber`, derived cohorts, platinum/PROC, labs/surgery), so its
   completion is the real proof of tumour-agnosticism. Two known debts, tracked in its pack:
   the simplified platinum engine vs the spec's full EDM derivation, and template-inherited
   treated/untreated codes never verified against its spec (the template now demands explicit
   codes).
2. **One net-new tumour via the template** (dlbcl or mds when a real spec arrives) — proves the
   documented path a stranger would walk. The COTA vendor layout is a documented guess until a
   real delivery verifies it.
3. **Engine features nobody exercises stay out of production claims** until a pack exercises
   them: `formats:` rename overlay (the planned Panoramic switch — land one real block and
   smoke it BEFORE the delivery that needs it), `source_union`, `lot.exclude_settings`,
   `clinical.durations`, BSA, `write_mode: append`.
4. Backlog from the audits, in the pack that first needs each: per-tumour dashboard typing from
   the catalog instead of name heuristics; config-named prior-taxane output columns; per-product
   bundle `spec_version` variables; per-rule `source:` on index-date models; app standings
   memoisation at ~20 packs.

## Phase 5 — operating it (owner: RWP/RWDE jointly)

- **Refresh** (same spec, new cut): WORKFLOW §6.B; the runner's validate-only path is the
  rehearsal for every one.
- **Spec revision**: the `next-cut` skill; carry is digest-evidence, re-drafting is routed, and
  the revision gate names what the new workbook actually changed.
- **Every answer recorded is a precedent**: `precedents.py --add` at answer time; the knowledge
  graph is the cross-tumour memory that stops the same question being re-argued.
- **The app is the stakeholder window**; redeploy on merge, never on a timer.
- **Weekly honesty report**: `dry_run.py` per pack — latent blockers surface before anyone
  claims an approval, not during it.

## The stress round's ledger (2026-08-12, against b2e55f8)

| Finding (agent) | Severity | State |
|---|---|---|
| `run_rwdp.py` validate-only path: `manifest` used before assignment — every smoke run of a not-releasable pack died on NameError (engine) | HIGH | **Fixed** + AST order test |
| `run_rwdp.py` promotion branch: no `import os` in scope — Gate 6 promote unexecutable (engine) | HIGH | **Fixed** + same test |
| Signed RESOLVED register answers bound to nothing — silent rewrite of a recorded ruling (red team N1) | HIGH | **Fixed**: `decision_record --check` binds row↔form; in CI |
| `answered_by: "RWB team"` accepted (red team, first pass) | HIGH | **Fixed** earlier (b2e55f8): word-level `not_a_person` |
| Four tools crashed or passed falsely on pre-Gate-2 packs; app board hid 4 of 6 packs (matrix) | HIGH | **Fixed** (ac0d008) + regression tests |
| Handoff closed set omitted the Gate 3/4/6 artifacts and refused a verbatim template copy (bootstrap) | HIGH | **Fixed**: allowlist extended |
| Bootstrap docs: 4 undocumented registration edits, wrong CLI form, stale TUMOR_STEMS pointer, missing §4b step, undocumented stand-in format (bootstrap) | HIGH–LOW | **Fixed**: NEW_TUMOUR.md/template/READMEs |
| Template ships flipped treated/untreated defaults and an uncataloged `bsa` emit (engine D3 / bootstrap A9) | MEDIUM | **Fixed** in template; oc's codes flagged in Phase 4 |
| Disposition-register integrity ran only under `--strict` (red team N6) | MEDIUM | **Fixed**: routine `--check` now fails on it |
| No cross-pack `output_table` uniqueness (engine D9) | LOW | **Fixed**: registry test |
| `--register-ai-extraction` emitted approval fields as schema-illegal `TODO`s; paste instructions invited a silent mis-registration; a schema defect in one pack masqueraded as a date-test failure (bootstrap A4) | HIGH | **Fixed**: approval fields emit commented-out (absent is the honest pending state); paste instruction demands the material land IN the list and go RED; the date test validates its base pack first and names the real culprit. Verified: the gate refuses an unstated classification (rc=1) — gate and schema agree |
| Published-surface reconciliation suppressed wholesale while any output decision is open (red team N2) | MEDIUM | **Fixed**: `contract_binding --surface-base <rev>` — the allowance keeps covering the standing divergence; a column that NEWLY leaks since the merge base fails. In CI beside the legacy ratchet; negative-tested with a planted rogue column |
| Legacy-allowlist hand-adds visible only to the git-base ratchet (red team N4) | MEDIUM | **Closed**: CI already runs `--ratchet-against` the merge base; the in-tree check now additionally refuses `legacy_phantom` — an allowlisted id naming no captured spec row |
| status.py quotes Gate-4-conditional wording as if current; truncates mid-word; scaffold and full pack identical on the board; ambiguous basename labels; `contract_lint --help` (matrix B4/B7/B8/B9/B10, bootstrap A13) | MEDIUM–LOW | **Fixed**: every quoted latent line carries `(when claimed)`; blockers wrap instead of truncating; the board gains a records-drafted column; source_check labels repo-relative; contract_lint gets argparse |
| catalog `tumor_codes` mirror unenforced (bootstrap A12) | LOW | **Fixed**: test enforces the mirror in both directions |
| `acceptance` worked-examples unverified (red team N5) | LOW | **Accepted, with reasons**: the example is free text; an arithmetic re-evaluator over prose would refuse valid examples, I22 already pins the RULE verbatim to the spec cell, and the worked example is exactly what a Gate 4 reviewer reads. A wrong example cannot change what builds |

Every row is now Fixed, Closed, or Accepted with its reasons stated.

### Second external review (main@4cc41ea) — the release-integrity slate, implemented

| Blocker | State |
|---|---|
| B1 repository governance (rulesets, owners, authenticated review) | **Admin-only** — GitHub plan + settings; the repo cannot grant itself branch protection |
| B2 preflight/QC/build reading different data | **Fixed**: the lineage probe runs FIRST; preflight, source QC, the build and the goldens all read through one pinned snapshot |
| B3 pins carry no table identity | **Fixed**: pins are full lineage entries; `sources._read` verifies the Delta table id around every pinned read — drop-and-recreate is a refusal |
| B4 candidate QC unbound from the signed candidate | **Fixed**: identity captured at each staging/TFL write; QC/counts/goldens/TFLs read that version; the manifest refuses to sign if anything moved |
| B5 unpinned candidates publishable; receipt validated after the swap | **Fixed**: prod candidates refuse unpinned inputs at build time; the complete prospective receipt is validated BEFORE the lock and before any public object moves |
| B6 recovery defects (own-swap refusal, lock re-entry, count-only reconcile, pointer readback, malformed journal) | **Fixed**: resume tolerates its own partial swaps; lock re-entry requires a journal; versioned tables carry an `rwdp_build_id` tag reconcile demands; pointer readback checks spec_version + published_at; a malformed journal refuses instead of reading as absent |
| B7 second, weaker publication algorithm | **Deleted**: a candidate ALWAYS stops (`candidate_ready`); promotion is the one state machine, in every environment, and now writes the audit bundle |
| Gate 5 validator dropped from the receipt | **Fixed**: `qc_by`/`qc_date` map from the approval form's `validated_by`/`validation_date`; `validate_manifest` requires all four at released |
| Golden reference read live | **Fixed**: probed and read `versionAsOf`, versions recorded in the report |
| PyYAML last-wins duplicate keys | **Fixed**: one strict loader (`engine.strict_yaml`) behind every governed read; duplicates refuse with line numbers |
| Windows pack ids, Python 3.12 escape | **Fixed** (v1.80.0) |
| App trust (rc ignored, no timeouts, raw stderr, unknown provenance served, suggest on the front page, a11y basics) | **Fixed**: honest failure banners, 60s timeouts + output caps, path-scrubbed errors, 503 on unprovable provenance, suggest de-linked, semantic frame |
| Root pytest ≠ CI; smoke can skip a configured product; doc contradictions; open decisions unlabeled in knowledge output | **Fixed** in the same slate |
| Spark 3.5 lane, DBR/UC SIT, lockfiles (uv/renv), Playwright/axe lane, Dependabot, typed portal core, `rwdp` CLI façade | **Planned** — tooling adoption and infrastructure runs; Phases 2–4 above |
 None of the accepted
items touches the six gates' refusal behaviour, which the red team could not break through the
front door.
