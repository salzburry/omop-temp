# Running the whole journey from chat

The chat interface is not a future feature — it is how this repository is operated today. Claude
Code **is** the chat surface: open this repo in VS Code with the Claude Code extension (the panel
is the "popup") or run `claude` in a terminal at the repo root, and type the questions below in
plain language. The seven skills in `.claude/skills/` cover the recurring governed workflows —
drafting contract records, answering decisions, applying source verdicts, proposing source
mappings, proposing variable names, starting the next cut, and operating a product; a request
outside those seven goes straight to the tool that owns it,
with `governance/INDEX.yaml` as the routing map. Nothing here bypasses a gate — the chat
drives the same tools CI verifies, and the acts that need a named human still refuse a session.

## One loop, one thing on screen

The many files under `<pack>/handoff/` are the **ledger, not the interface**. Nobody browses that
folder from chat: `DECISIONS.md` is the register the tools write, `RWB_QUESTIONS.md` is a generated
ranked view of that same register (CI fails if it drifts — the two can never disagree), and the
rest is RWP/RWDE working evidence. The only files a stakeholder ever *opens* are the answer forms
in `decision_answers/` — one small YAML per question, and only to type their answer and name.

What chat shows is a loop of four turns, each producing **exactly one page**, repeated until the
question list is empty:

1. **"where do we stand"** → one status view: the six gates, the blockers, the single next action
   and who owes it.
2. **"what do you need from me"** → one ranked question page for the PACK — highest
   blast-radius first, evidence and precedents on the same page. (The page lists each
   question's owner; it is one page per pack, not one page per answerer — several owners
   share it and read their own rows.)
3. **The person types their answers** into the named forms and commits — the one step outside
   chat, by design. Chat points at the exact file; it never types the values.
4. **"the answers are in"** → one all-or-nothing wave (`decision_record.py --apply`), one unblock
   worklist back, and turn 1's standing has moved.

The session rule the skills enforce: **one artifact per turn**. If an answer seems to need two
pages, it is two turns — nothing else pops up alongside.

## The journey, as chat

| you type | what runs | what you get |
|---|---|---|
| "where does prostate stand" / "what is blocking us" | `operate-rwd-product` → `status.py` | the six gates, blockers, next action and its owner |
| "extract the new spec" (a person registers the workbook first) | `run_spec_pipeline.py` | extraction + lint + coverage, `--check`-fenced |
| "draft the record for clinical:61" | `draft-contract-record` → `contract_record.py --item` | a lint-clean record quoting the spec verbatim (I22) |
| "what should we ask RWB" | `answer-decisions` → `decision_report.py`, `decision_packet.py` | questions ranked by blast radius, one page per pack with each question's owner named |
| "have we decided something like this before" | `knowledge_graph.py --query` | every pack's ruling, with approver, date and citations |
| "what do we know about X, anywhere" | `knowledge_search.py <terms>` | every surface at once — decisions, precedents, contract records, the shelf, capabilities, citations — each hit carrying WHAT KIND of authority it has and how far that has been taken |
| "RWB's answers came back" | `answer-decisions` → `decision_record.py --forms` / `--apply` | the signed forms transcribed, all-or-nothing, plus the unblock worklist |
| "apply the source verdicts" | `apply-source-verdicts` → `contract_record.py --apply-verdicts` | Gate 3 evidence moved into the two evidence-fed axes |
| "what sources does this pack need" | `source_requirements.py` | the requirement matrix: role, availability state, required columns, which blocks read it, expected grain |
| "what could supply biomarkers" (a profile TSV exists) | `propose-source-mapping` → `propose_source_mapping.py` | ranked mapping candidates with counted evidence and blockers — a person applies or declines; `--validate` re-checks a choice, and `mapping_benchmark.py` says how far to trust the ranking |
| "show me this rule three ways" | `rule_review.py` | the spec's words, the interpretation, and the YAML that runs, side by side — the page an approver reads |
| "what should this variable be called" / "does agegrp already exist" | `propose-variable-name` → `naming_registry.py` | the cross-pack name registry, the standard spelling recommended, near-misses and format conflicts as QUESTIONS — a person rules in `governance/NAMING_RULINGS.yaml`, never the tool |
| "the revised workbook landed" | `next-cut` → `spec_diff.py` / `--carry-plan` | what provably carries, what needs re-reading, where |
| "run the build" / "validate it" | `run_rwdp.py` (Databricks), the Spark test suites | candidate vs published, goldens, QC — Gate 5/6 evidence |
| "how did the build behave, stage by stage" | `local_smoke.py --stage-telemetry` locally; the `stage_telemetry` widget on a governed run | per-cohort join counts at every stage boundary and per-item selection counts (candidates, ties, non-null outputs) — evidence a person reads, never a verdict |
| "what does the delivery look like BETWEEN tables" | `eda_report.py` (`--synthetic` for the shape; `eda()` composed on the cluster for the facts) | layered counts: inventory and null keys, grain, patient overlap and fan-out vs the index source, date sanity, the cohort funnel, the output contract |
| "where did this number come from" | `receipt.py <pack> --variable X` | one variable's whole chain on one page: the spec's words, the contract record, the decisions (quoted from the register), the config blocks, the name's registry entry, the build manifest — absence printed as absence |
| "is this cohort even big enough to bother" | `quick_counts.py` (the exploration lane) | counts-only feasibility, small cells pooled; a column no contract defines must be `--assume`d and logged to the intake ledger or the query refuses — `--intake` turns the ledger into demand evidence for the decision loop |
| "one page for the steering meeting" | `executive_page.py --out ~/exec.html` | every pack's six gates and next owner, plus the leverage table: which open decision unblocks the most contract records — the gate tools' own verdicts, rearranged |
| "show me the semantic view" / "can we pool rwPFS across Flatiron and claims" | `semantic_view.py <pack>` (`--pooling VAR A B` for one pair) | the tumour's conceptual layer: every contract variable with its derivation, each dataset's implementation, and the pooling state per source pair — a recorded human ruling from `governance/EQUIVALENCE_RULINGS.yaml`, or NOT ESTABLISHED with the question routed to RWP/RWB; the tool never rules |
| "put the pages where stakeholders can read them" | `publish_site.py --out <dir>` (`--serve` to preview) | every read surface regenerated into one hostable folder with an index — commit-stamped, input-free, absences listed with their reasons (docs/PILOT.md is the participation runbook) |
| "is my draft workbook ready to hand off" (an RWB author asks) | `spec_precheck.py <draft.xlsx>` | the governed pipeline's own extraction and lint over a DRAFT, in fix-it language, exit 1 on blocking findings — a courtesy check that registers nothing and approves nothing |
| "is the platform actually compounding" | `precedent_metric.py` | per pack: decisions, open, resolved, and CANDIDATE precedent coverage against other packs' resolved rulings — every match a question a person confirms, nothing marked answered by the tool |
| "give the reviewer one Excel file" / "the review came back" | `review_workbook.py build <pack> --out X.xlsx` / `read <filled> <pack>` | one workbook per pack — a tab per domain with lint severity beside every extracted row, four reviewer columns to fill; `read` verifies the extraction fingerprint and item ids, refuses drift and unowned decisions, and PRINTS the review — transport, never approval |
| "bind this role to the delivered table, typed" | `source_adapter.py skeleton <pack>` / `check <pack>` | the typed source-adapter contract: per role — physical table, column types and parsers, grain, join cardinality, vocabulary, units, review binding. `skeleton` derives the machine-knowable half; a person fills and signs; `check` refuses partial coverage, TODO types, invented cardinalities and unowned reviews. A checked adapter set with a `dataset:` label is the semantic view's second implementation — the moment the equivalence axis goes live |

The whole journey — spec extraction, contract records, ranked questions, config, tests and
release machinery — runs conversationally, every write through a tool that refuses what a
session must not do.

## What chat deliberately cannot do

Approvals, signatures, decision answers, maturity claims. Those arrive only as **committed file
edits by a named person** — the forms in `handoff/decision_answers/`, the approval YAMLs, the
`source_refs.yaml` record. A chat interface that could perform them would be the hole the whole
design exists to close. The chat's job is to make the human act tiny and exactly located.

## For people who will never open VS Code

The read-only surfaces are HTML, generated out-of-checkout and shareable:

    python3 platform/tools/render_html.py flow <pack> --out ~/flow.html      # the status page
    python3 platform/tools/decision_packet.py <pack> --out ~/questions.html  # the pack's question page
    python3 platform/tools/executive_page.py --out ~/exec.html               # every pack + the leverage table

And for a live DEMO there is a chat page that needs no VS Code and no scripts:

    python3 platform/tools/chat_demo.py        # then open http://127.0.0.1:8377

Three backends, one boundary, auto-detected (`--backend` to force):

  * **claude CLI (no key)** — anywhere Claude Code is installed and logged in, the page is the
    end-to-end ASSISTANT on the operator's own seat: no key is ever provisioned, and the
    allowlist is enforced by Claude Code's OWN permission engine — the model's only permitted
    command is `chat_demo.py --tool …`, which funnels through the same validated allowlist.
  * **API** — with `ANTHROPIC_API_KEY` set and `pip install anthropic`, the same assistant over
    the Messages API (default `claude-opus-5`).
  * **router** — with neither, a fixed intent table maps the questions above to one read-only
    tool each. No model at all.

In every backend the tool's output arrives with the command printed underneath, the model's
only reach is the six read-only tools, and anything approval-shaped gets the standing refusal
BEFORE any model is consulted. Localhost only.

## The standalone AI chat page, and why its boundary is small

`chat_demo.py`'s assistant mode IS the second harness this section used to warn about — built
with the boundary the warning demanded. The model holds no shell, no filesystem, and no write
path: its entire reach is six validated read-only argv arrays (`_tool_argv` is the allowlist,
test-pinned), the approval refusal fires before the model sees the message, and every command
it triggers is printed under its reply. What it deliberately still cannot do is everything in
"What chat deliberately cannot do" above — a model with a tool for typing an answer form would
be the approval hole, so no such tool exists. Anything BIGGER than this page (hosted for
stakeholders, authenticated, multi-user) should start from this same shape: grow the tool list
one read-only argv at a time, never hand the model the repository.
