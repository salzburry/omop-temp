# =============================================================================
# QC 07. COLUMN TYPES AND NULLABILITY
# =============================================================================
#   Rscript qc/07_type_contract.R      (after the build, from the repo root)
#
# WHY. validation/00_column_contract.csv pins column names and order. Nothing
# pins the types. A column that turns from DATE into STRING keeps its name and
# position, passes every other check, and breaks the first consumer who does
# date arithmetic on it.
#
# That is a live risk here. The table is built by union_all across seven cohort
# frames. A case_when returning 1 in one place and 1L in another gives DOUBLE
# and INT, and Spark widens the union - so the shipped type depends on which
# branch happened to fire.
#
# HOW. The first run CAPTURES the types into qc/qc_column_types.csv for review.
# Later runs compare against it and fail on a change. A hand-written list of
# 190 expected Spark types would be a guess, and a wrong guess gets corrected
# towards whatever the build emitted - a transcript, not a contract.
#
# Check the capture before you commit it. Dates should be DATE. Codes should be
# whole numbers. A wrong type gets fixed in the build, not accepted here.
#
# Nullability is different and is declared below, because it follows from the
# code: a case_when with a TRUE branch cannot return NULL.
# =============================================================================

if (!exists("con")) {
  message("no open connection - sourcing code/modules/00_setup.R")
  source("code/modules/00_setup.R")
}
stopifnot(exists("con"), exists("personal_schema"), exists("output_table"))

ADS       <- paste0(personal_schema, ".", output_table)
TYPE_FILE <- "qc/qc_column_types.csv"

# -----------------------------------------------------------------------------
# Declared non-nullable columns
# -----------------------------------------------------------------------------
# Each of these ends in a case_when TRUE branch, an ifelse with a non-NA
# alternative, or a run stamp - so the code cannot produce NULL. A NULL here
# means either a branch was removed or the column arrived through a join that
# did not match, and both are defects.
#
# DELIBERATELY ABSENT, and why:
#   ses       Q51 - "Null" is one of its documented values
#   dthfufl   Q57 - NULL when there is no death date (a comparison with nothing
#             to compare). This note previously described the reverted rule.
#   os/pfs/ttnt/vis120/eligpfs   restricted by cohort, NULL where inapplicable
#   every LAB*V / LAB*DT         NULL when the analyte is not Present
NON_NULLABLE <- c(
  # identity and run stamps
  "patid", "indexdt", "cohort", "cohortn", "cohortu", "cohortun",
  "datav", "rawrwd", "minindex", "maxindex", "indexyr",
  # eligibility flags - ifelse with a 0 alternative
  "id3mosfu", "id_pd_mcrpc", "id_pd_mhspc",
  # demographics - every one has a residual branch
  "agegr1", "agegr1n", "region1", "region1n", "race", "racen",
  "eth", "ethn", "practic", "practicn",
  # clinical categoricals - all have a documented residual level
  "stage", "stagen", "gleason", "gleasonn", "ecog", "ecogn", "bp", "bpn",
  # lab PRESENCE flags (not the values) - case_when ends in "Missing"
  "labneu", "labpla", "labhem", "labcre", "labbil",
  "labast", "labalt", "labalp", "labalb", "lablym",
  # follow-up - FUED is floored at index, so it and its derivatives always exist
  "fued", "fudur", "dthfl", "dth_before_fued",
  # prior-exposure flags - ifelse producing "Yes"/"No"
  "prior_pluvicto", "prior_parp", "prior_chemo", "prior_nha_adt",
  "prior_docetaxel", "prior_abiraterone", "prior_arpi",
  # Added 2026-08-08: the first list stopped at the variables I happened to be
  # looking at, which is not a contract. Every column below also ends in a
  # case_when TRUE branch or an ifelse with a non-NA alternative, so the code
  # cannot emit NULL for any of them either.
  "hrr_index", "hrr_indexn", "brca_index", "brca_indexn",
  "hrr_label_index", "hrr_label_indexn",
  "hrr_index_test", "hrr_index_testn", "brca_index_test", "brca_index_testn",
  "psma_scanresult",
  "lung_met", "adrenal_met", "bone_met", "brain_met",
  "lot1cat_mhspc", "lot1catn_mhspc", "lot2cat_mhspc", "lot2catn_mhspc",
  "lot1cat_mcrpc", "lot1catn_mcrpc", "lot2cat_mcrpc", "lot2catn_mcrpc",
  "lot3cat_mcrpc", "lot3catn_mcrpc", "lot4cat_mcrpc", "lot4catn_mcrpc",
  "lotngr1", "lotngr1n", "lotngr1_mhspc", "lotngr1n_mhspc",
  "csd", "bmigr1", "bmigr1n",
  # Concomitant-medication and line-count flags: ifelse with a 0 alternative.
  "csf_pre", "csf_fu", "ss", "lotn", "lotn_mhspc",
  "psa50_6mo", "psal6mo", "psa50_12mo", "psal12mo"
)
# NOTE the deliberate exclusions among these families: LOT1_MCRPC and its
# siblings are the line NAMES, which are NULL when the line does not exist
# (register Q64) - only the CATEGORY has a "No treatment" level. BMI itself is
# nullable; only its banding is not. PSA6MO / PSA12MO are nullable; only the
# Y/N response flags derived from them are not.

contract <- utils::read.csv("validation/00_column_contract.csv", stringsAsFactors = FALSE)
known    <- tolower(contract$column)
unknown  <- setdiff(NON_NULLABLE, known)
if (length(unknown)) {
  stop("NON_NULLABLE names a column that is not in the contract: ",
       paste(unknown, collapse = ", "), call. = FALSE)
}

# -----------------------------------------------------------------------------
# 1. Types
# -----------------------------------------------------------------------------
desc <- DBI::dbGetQuery(con, paste("DESCRIBE TABLE", ADS))
# DESCRIBE appends partition/detail blocks after a blank-named row on some
# runtimes; keep only the real column rows and only those in the contract.
desc <- desc[!is.na(desc$col_name) & nzchar(trimws(desc$col_name)) &
               !startsWith(desc$col_name, "#"), , drop = FALSE]
observed <- data.frame(column    = tolower(trimws(desc$col_name)),
                       data_type = tolower(trimws(desc$data_type)),
                       stringsAsFactors = FALSE)
observed <- observed[observed$column %in% known, , drop = FALSE]

# match() below returns NA for a contract column DESCRIBE did not report, and
# silently picks the first of any duplicate - so both failure modes would have
# produced a clean-looking type table. Checked explicitly first.
absent <- setdiff(known, observed$column)
dupes  <- unique(observed$column[duplicated(observed$column)])
ok <- TRUE
if (length(absent) || length(dupes)) {
  if (length(absent))
    cat("DESCRIBE did not report ", length(absent), " contract column(s): ",
        paste(absent, collapse = ", "), "\n", sep = "")
  if (length(dupes))
    cat("DESCRIBE reported ", length(dupes), " column(s) more than once: ",
        paste(dupes, collapse = ", "), "\n", sep = "")
  cat("The delivered table does not match validation/00_column_contract.csv. Fix\n")
  cat("that before pinning types - a type contract over the wrong column set\n")
  cat("is worse than none.\n")
  ok <- FALSE
}

observed <- observed[match(known, observed$column), , drop = FALSE]

if (!file.exists(TYPE_FILE)) {
  utils::write.csv(observed, TYPE_FILE, row.names = FALSE)
  cat("CAPTURED ", TYPE_FILE, " - ", nrow(observed), " columns.\n", sep = "")
  cat("\nThis is the FIRST run. Nothing has been checked yet.\n")
  cat("REVIEW the captured types before committing:\n")
  cat("  * every *dt / *date / indexdt / lot*sd / lot*ed should be `date`\n")
  cat("  * every *n code and every flag should be integral, not string\n")
  cat("  * no clinical value should be `string` unless it is a label\n")
  cat("A wrong type belongs fixed in the build, not accepted into this file.\n")
  cat("Once reviewed: git add ", TYPE_FILE, " and commit it.\n", sep = "")
  # NOT a pass. An earlier version left ok = TRUE here and, if the nullability
  # section also passed, printed "QC 07 PASS" for a run that verified no types
  # at all - the most dangerous shape a check can have, because it produces
  # evidence for a claim it never tested. A capture is an input to review, not
  # a result.
  captured_only <- TRUE
  ok <- FALSE
} else {
  captured_only <- FALSE
  pinned <- utils::read.csv(TYPE_FILE, stringsAsFactors = FALSE)
  cmp <- merge(pinned, observed, by = "column", all = TRUE,
               suffixes = c("_pinned", "_observed"))
  drift <- cmp[is.na(cmp$data_type_pinned) | is.na(cmp$data_type_observed) |
                 cmp$data_type_pinned != cmp$data_type_observed, , drop = FALSE]
  if (nrow(drift)) {
    cat("TYPE DRIFT - ", nrow(drift), " column(s) changed:\n\n", sep = "")
    print(drift, row.names = FALSE)
    cat("\nA type change that nobody intended is a defect. If it IS intended,\n")
    cat("delete ", TYPE_FILE, ", re-run to recapture, and say why in the\n", sep = "")
    cat("commit message.\n")
    ok <- FALSE
  } else {
    cat("types: all ", nrow(pinned), " columns match ", TYPE_FILE, "\n", sep = "")
  }
}

# -----------------------------------------------------------------------------
# 2. Nullability
# -----------------------------------------------------------------------------
# One pass, one row: how many NULLs does each declared-non-nullable column hold.
nn_sql <- paste0(
  "SELECT COUNT(*) AS n_rows, ",
  paste(sprintf("SUM(CASE WHEN %1$s IS NULL THEN 1 ELSE 0 END) AS null_%1$s",
                NON_NULLABLE), collapse = ", "),
  " FROM ", ADS)
nn <- DBI::dbGetQuery(con, nn_sql)

null_counts <- vapply(NON_NULLABLE,
                      function(c) as.numeric(nn[[paste0("null_", c)]]), numeric(1))
viol <- null_counts[null_counts > 0]

cat("\n---- nullability ---------------------------------------------\n")
cat("rows: ", format(nn$n_rows, big.mark = ","), "\n", sep = "")
if (length(viol)) {
  cat("FAIL - ", length(viol), " declared-non-nullable column(s) hold NULLs:\n\n",
      sep = "")
  print(data.frame(column = names(viol), n_null = unname(viol),
                   pct = round(100 * unname(viol) / nn$n_rows, 3)),
        row.names = FALSE)
  cat("\nEach of these is produced by a case_when TRUE branch, an ifelse with a\n")
  cat("non-NA alternative, or a run stamp, so the code cannot emit NULL. A NULL\n")
  cat("means a branch was removed, or the column arrived through a join that\n")
  cat("did not match and was never meant to be a left join.\n")
  ok <- FALSE
} else {
  cat("PASS - all ", length(NON_NULLABLE),
      " declared-non-nullable columns are fully populated\n", sep = "")
}

out_csv <- file.path("qc", paste0("qc07_nullability_", get0("refresh", ifnotfound = "run"), ".csv"))
utils::write.csv(data.frame(column = NON_NULLABLE, n_null = unname(null_counts),
                            n_rows = nn$n_rows),
                 out_csv, row.names = FALSE)
cat("wrote ", out_csv, " - retain this in the QC pack\n", sep = "")

cat("\n", if (ok) "QC 07 PASS\n"
         else if (isTRUE(captured_only))
           "QC 07 INCOMPLETE - types CAPTURED, not checked. Review and commit\n              qc/qc_column_types.csv, then re-run to verify.\n"
         else "QC 07 FAIL - see above\n", sep = "")
if (!ok) quit(status = 1L)
