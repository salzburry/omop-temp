# Deviations from the program specification

79 decisions. Each one is a place where the specification is wrong,
silent, or contradicts itself, and we had to choose.

Before you read a delivered number as final, look up its variable here. If it
appears, the value depends on a choice, not only on the specification.

The rule each decision produced is in `SPEC.csv`, which is the corrected
specification. Anything still unanswered is in `OPEN_QUESTIONS.md`.

- **58 change a delivered value.** These are the ones that matter.
- **8 change a column name, or which columns ship.**
- **13 change nothing.** Recorded so nobody re-opens them.

**79 rows, 77 distinct questions.** Two rows are duplicates - the same question
asked twice and answered twice, marked as such in the index and left in place
because their ids are cited in code and commits. Two more (Q31, Q32) are not
independent decisions but Q50's residual convention applied to a named
variable; they stay so a lookup on STAGEN or PRACTICN finds something.

## Rows that look alike but are not

Several variables appear on more than one row. They are different questions, and
reading only one of them gives a partial rule.

| Variable | Rows | What each one settles |
|---|---|---|
| `COHORTU` | Q11, **Q19** | Q11: populate all seven cohorts, treated = has a line in that setting. Q19 duplicates it. |
| `PRIOR_DOCETAXEL`, `PRIOR_ABIRATERONE` | Q08, **Q46** | Q08: correct both misspellings. Q46 duplicates it. |
| `HRR_INDEX`, `BRCA_INDEX` | Q04, Q05, Q18, Q20, Q28, Q29, Q37, Q44 | Q04 which date column; Q05 which genes; Q18 how to match a negative; Q20 the window; Q28 the olaparib-label sibling; Q29 the collision and rollup rules; Q37 one shared winning date; Q44 freeze the panel. |
| `FUED`, `FU_ENDDT_preliminary` | Q40, Q45, Q54 | Q40 exactly four sources; Q45 the clamp direction; Q54 the oral table is prostate, not a colorectal relic. |
| `ECOG`, `ECOGN` | Q23, Q30, Q56, Q71 | Q23 six categories; Q30 closest to index for the treated cohorts; Q56 the window applies to all seven; Q71 clamp anything outside 0-4. |
| `WEIGHT`, `HEIGHT`, `BMI`, `BSA` | Q68, Q72 | Q68 the record filter and the arithmetic guards; Q72 normalise the test name before grouping. |
| residual code `99` | **Q50**, Q31, Q32 | Q50 states the convention. Q31 and Q32 apply it to STAGEN and PRACTICN. |
| `LOT1_MCRPC` and siblings | Q64, Q73 | Q64 a missing line is NULL, not a placeholder. Q73 a line that EXISTS with no name - the consequence, still being sized. |
| PSA response | Q35, Q59, Q79 | Q35 a missing PSA scores N; Q59 the baseline positivity guard; Q79 the six-month window. |
| `TTNT` | Q02, Q42 | Q02 TTNTFL is internal, not delivered; Q42 the next-treatment date is always after index. |
| `LABPLA`, `LABBIL` | Q07, **Q55** | Q07 the bilirubin unit is a spec slip. Q55 WITHDRAWS Q07's platelet limb - there was no defect there. |

`qc/00_coverage.R` reads the index table below. Every row that affects output
must be named by a check under `qc/` or `validation/` and carry an approver.

**Where those checks are.** The production copy is `docs/` and `code/`. The
checks named throughout this file - `qc/03` R29, `validation/03` V41, preflight
B13, and the rest - live in the build repository, not beside the code. So a
citation here tells you the check exists and where to run it; it does not mean
the file is in the folder you are reading. `OPEN_QUESTIONS.md` section 8 says
which copy holds what.

A citation is also not a result. Most rows below read `PENDING` under **QC
evidence**, because no build has yet run against the database. The few that do
not rest on SOURCE queries, which predict what the build must produce rather
than confirming what it did.

## Index

| ID | Variable | Affects | Approved by | Status | Commit |
|---|---|---|---|---|---|
| Q01 | MAXINDEX | values | Onkar Kshirsagar | RESOLVED | 23a9294 (settling commit; 3 commits name this row, first 3c7d5e4) |
| Q02 | TTNTFL | columns | Onkar Kshirsagar | RESOLVED | 1aa2fdb (settling commit; 3 commits name this row, first f95d6e6) |
| Q03 | HRR_INDEX_TEST / BRCA_INDEX_TEST | values | Onkar Kshirsagar | RESOLVED | 364732b (settling commit; 3 commits name this row, first 2660f0a) |
| Q04 | HRR_INDEX / BRCA_INDEX | values | Onkar Kshirsagar | RESOLVED | 1cfca36 (settling commit; 2 commits name this row, first f95d6e6) |
| Q05 | HRR_INDEX | values | Onkar Kshirsagar | RESOLVED | 84a53a1 (settling commit; 8 commits name this row, first 3c7d5e4) |
| Q06 | LOTN | values | Onkar Kshirsagar | RESOLVED - LOTN_MHSPC family added | 3100f65 |
| Q07 | LABPLA / LABBIL | values | Onkar Kshirsagar | RESOLVED - LABBIL limb only; LABPLA limb withdrawn (Q55) | b763ddb (settling commit; 6 commits name this row, first 75eec0f) |
| Q08 | PRIOR_DOCITAXEL / PRIOR+ABIRATERONE | columns | Onkar Kshirsagar | RESOLVED | 84a53a1 (settling commit; 3 commits name this row, first a3a68a3) |
| Q09 | INITYR | values | Onkar Kshirsagar | RESOLVED | 1aa2fdb (settling commit; 4 commits name this row, first e433717) |
| Q10 | TINTCRPCHSPC | values | Onkar Kshirsagar | RESOLVED | 1cfca36 (settling commit; 7 commits name this row, first 3c7d5e4) |
| Q11 | COHORTU | values | Onkar Kshirsagar | RESOLVED | 84a53a1 (settling commit; 7 commits name this row, first a050293) |
| Q12 | LABLYMDT | values | Onkar Kshirsagar | RESOLVED | 1aa2fdb (settling commit; 4 commits name this row, first e433717) |
| Q13 | All labs | values | Onkar Kshirsagar | RESOLVED - note #5 authoritative; LABNEUV row is an erratum (E16) | 1aa2fdb (settling commit; 5 commits name this row, first f95d6e6) |
| Q14 | Output naming | columns | Onkar Kshirsagar | RESOLVED - name confirmed by the owner; the defining spec page remains unsupplied | 1aa2fdb (settling commit; 5 commits name this row, first f95d6e6) |
| Q15 | t_allprostate_pats | none | Onkar Kshirsagar | RESOLVED | 1aa2fdb (settling commit; 2 commits name this row, first 23a9294) |
| Q16 | max_drug_ep_abstracted_dt | values | Onkar Kshirsagar | RESOLVED | 201c516 (settling commit; 4 commits name this row, first efe51d0) |
| Q17 | LOT4CATN -> LOT4CATN_MCRPC | columns | Onkar Kshirsagar | RESOLVED | 84a53a1 (settling commit; 4 commits name this row, first 906b68b) |
| Q18 | BIOMARKERSTATUS | values | Onkar Kshirsagar | RESOLVED | d23382c (settling commit; 3 commits name this row, first 75eec0f) |
| Q19 | COHORTU | values | Onkar Kshirsagar | DUPLICATE of Q11 - read Q11 | 84a53a1 (settling commit; 7 commits name this row, first a050293) |
| Q20 | HRR/BRCA window | values | Onkar Kshirsagar | RESOLVED | 1aa2fdb (settling commit; 5 commits name this row, first a050293) |
| Q21 | min_vst_dt / min_vsttelemed_dt / min_medord_dt | columns | Onkar Kshirsagar | RESOLVED | 1aa2fdb (settling commit; 3 commits name this row, first f95d6e6) |
| Q22 | BIRTHYEAR | columns | Onkar Kshirsagar | RESOLVED | 3d9b122 (settling commit; 5 commits name this row, first 3c7d5e4) |
| Q23 | ECOGN | values | Onkar Kshirsagar | RESOLVED - corrected to the spec's six categories; was a real divergence | 175187c (settling commit; 5 commits name this row, first 8661459) |
| Q24 | NEW_LOT_N | values | Onkar Kshirsagar | RESOLVED | 3d9b122 (settling commit; 6 commits name this row, first 75eec0f) |
| Q25 | LABALB | values | Onkar Kshirsagar | RESOLVED - g/L filter restored; scale confirmed g/L | e7d054e (settling commit; 15 commits name this row, first f344808) |
| Q26 | PSMA_SCANRESULT | values | Onkar Kshirsagar | RESOLVED | 1a4d888 (settling commit; 6 commits name this row, first f344808) |
| Q27 | Publication step | none | Onkar Kshirsagar | RESOLVED | ee01c8c (settling commit; 8 commits name this row, first 6faece8) |
| Q28 | HRR_INDEX / BRCA_INDEX | columns | Onkar Kshirsagar | RESOLVED | 23a9294 (settling commit; 3 commits name this row, first f310ad3) |
| Q29 | HRR_INDEX / BRCA_INDEX | values | Onkar Kshirsagar | RESOLVED | 16952e5 (settling commit; 13 commits name this row, first 87f07d2) |
| Q30 | ECOG (treated cohorts) | values | Onkar Kshirsagar | RESOLVED | d72c197 (settling commit; 2 commits name this row, first 1334f00) |
| Q31 | STAGE / STAGEN | values | Onkar Kshirsagar | RESOLVED - the Q50 residual convention, applied to STAGEN | 84a53a1 (settling commit; 4 commits name this row, first d54395b) |
| Q32 | PRACTIC / PRACTICN | values | Onkar Kshirsagar | RESOLVED - the Q50 residual convention, applied to PRACTICN | 84a53a1 (settling commit; 3 commits name this row, first 1cfca36) |
| Q33 | FUED / DTHDT / PSMA_SCANDT | values | Onkar Kshirsagar | RESOLVED | 1aa2fdb (settling commit; 3 commits name this row, first 87f07d2) |
| Q34 | PFSDT / PFS | values | Onkar Kshirsagar | RESOLVED - spec says no action; quantified by X03/X03b | 201c516 (settling commit; 15 commits name this row, first 8661459) |
| Q35 | PSA50_6MO / PSAL6MO / PSA50_12MO / PSAL12MO | values | Onkar Kshirsagar | RESOLVED | 1aa2fdb (settling commit; 4 commits name this row, first f59308c) |
| Q36 | VIS120 | values | Onkar Kshirsagar | RESOLVED | 16952e5 (settling commit; 5 commits name this row, first 87f07d2) |
| Q37 | HRR_INDEX / BRCA_INDEX | values | Onkar Kshirsagar | RESOLVED | 8eee68c (settling commit; 7 commits name this row, first 1334f00) |
| Q38 | Index date / cohort membership | values | Onkar Kshirsagar | RESOLVED - accepted and documented; 10,170 patients affected | 7fe51d0 (settling commit; 10 commits name this row, first efe51d0) |
| Q39 | CSF_FU | values | Onkar Kshirsagar | RESOLVED | 1b52044 (settling commit; 3 commits name this row, first d72c197) |
| Q40 | FU_ENDDT_preliminary / FUED | values | Onkar Kshirsagar | RESOLVED | 1aa2fdb (settling commit; 2 commits name this row, first a3a68a3) |
| Q41 | PFSDT / PFSFL | values | Onkar Kshirsagar | RESOLVED - build matches the spec verbatim | 893cb9c (settling commit; 7 commits name this row, first f95d6e6) |
| Q42 | TTNT / TTNTFL | values | Onkar Kshirsagar | RESOLVED - closed on evidence, both limbs (Q42 within setting, Q42b cross setting) | fea1c7e (settling commit; 13 commits name this row, first efe51d0) |
| Q43 | Build identification | values | Onkar Kshirsagar | RESOLVED | 84a53a1 (settling commit; 8 commits name this row, first efe51d0) |
| Q44 | HRR_INDEX gene inventory | values | Onkar Kshirsagar | RESOLVED | 84a53a1 (settling commit; 10 commits name this row, first efe51d0) |
| Q45 | FUED | values | Onkar Kshirsagar | RESOLVED | 1aa2fdb (settling commit; 6 commits name this row, first d23382c) |
| Q46 | PRIOR_DOCITAXEL / PRIOR+ABIRATERONE | columns | Onkar Kshirsagar | DUPLICATE of Q08 - read Q08 | 84a53a1 (settling commit; 5 commits name this row, first 7891b9f) |
| Q47 | OS | values | Onkar Kshirsagar | RESOLVED | 1aa2fdb (settling commit; 4 commits name this row, first f59308c) |
| Q48 | COHORT | values | Onkar Kshirsagar | RESOLVED | 1aa2fdb (settling commit; 3 commits name this row, first e95964e) |
| Q49 | CSD | values | Onkar Kshirsagar | RESOLVED | 893cb9c (settling commit; 5 commits name this row, first 906b68b) |
| Q50 | REGION1 / REGION1N / PRACTIC / PRACTICN | values | Onkar Kshirsagar | RESOLVED | 84a53a1 (settling commit; 6 commits name this row, first d54395b) |
| Q51 | SES | values | Onkar Kshirsagar | RESOLVED - fixed in code | 0aa917e (settling commit; 4 commits name this row, first d54395b) |
| Q52 | INDEXDT (Overall cohorts) / MHSPCDD / MCRPCDD | values | Onkar Kshirsagar | RESOLVED | fea1c7e (settling commit; 10 commits name this row, first 7c5c25c) |
| Q53 | DTHFL | values | Onkar Kshirsagar | RESOLVED - spec text is complete SAS; build matches it exactly | bef56f4 (settling commit; 2 commits name this row, first 8eee68c) |
| Q54 | FU_ENDDT_preliminary | none | Onkar Kshirsagar | RESOLVED - confirmed a colorectal copy-paste relic (E15) | 1aa2fdb (settling commit; 4 commits name this row, first bef56f4) |
| Q55 | LABPLA | none | Onkar Kshirsagar | RESOLVED - no defect; Q07 LABPLA limb withdrawn | 9c2eef7 (settling commit; 3 commits name this row, first d4c76c4) |
| Q56 | ECOG (cohorts 3-7) | none | Onkar Kshirsagar | RESOLVED - measured; the window drops zero rows | a81f663 (settling commit; 4 commits name this row, first b9e6e36) |
| Q57 | DTHFUFL | values | Onkar Kshirsagar | RESOLVED - recomputed on the preliminary dates; limitation accepted | df58317 (settling commit; 9 commits name this row, first b9e6e36) |
| Q58 | all LAB* and BP | values | Onkar Kshirsagar | RESOLVED - spec followed literally; Unknown is no longer a quality signal | 364732b (settling commit; 9 commits name this row, first b9e6e36) |
| Q59 | PSA50_6MO / PSA50_12MO | none | Onkar Kshirsagar | RESOLVED - measured; guard is value-neutral and retained | 890d01a (settling commit; 6 commits name this row, first b9e6e36) |
| Q60 | PRIOR_NHA_ADT | values | Onkar Kshirsagar | RESOLVED - definition wins; label is an erratum (E17) | 1aa2fdb (settling commit; 4 commits name this row, first b9e6e36) |
| Q61 | GLEASONN | none | Onkar Kshirsagar | RESOLVED - three categories confirmed; 3 is a value, not a sentinel | b763ddb (settling commit; 2 commits name this row, first b9e6e36) |
| Q62 | PSA_INDEX | values | Onkar Kshirsagar | RESOLVED - build follows the definition; note is an erratum (E18) | f0d7def (settling commit; 3 commits name this row, first b22142e) |
| Q63 | all LAB* Present criteria | none | Onkar Kshirsagar | RESOLVED - closed on evidence (zero occurrences) | a81f663 (settling commit; 3 commits name this row, first b22142e) |
| Q64 | LOT1_MCRPC / LOT2_MCRPC / LOT3_MCRPC / LOT4_MCRPC / LOT1_MHSPC / LOT2_MHSPC | values | Onkar Kshirsagar | RESOLVED - NULL per the spec definition; the None literal is withdrawn | 890d01a (settling commit; 5 commits name this row, first 0aa917e) |
| Q65 | LOT1CAT_* category 12, PRIOR_PARP | values | Onkar Kshirsagar | RESOLVED - separators unified and the format contract is now gated (B13) | 4bb2bd9 (settling commit; 4 commits name this row, first 0aa917e) |
| Q66 | DATEOFDEATH / DEATH_DT_preliminary / DTHDT / DTHFL | values | Onkar Kshirsagar | RESOLVED - spec-literal; the exposure is measured by qc/08, not gated | 4bb2bd9 (settling commit; 6 commits name this row, first 0aa917e) |
| Q67 | BP / BPSYS / BPDIA | values | Onkar Kshirsagar | RESOLVED - spec implemented; integrality now required | 72995ac (settling commit; 5 commits name this row, first 364732b) |
| Q68 | WEIGHT / HEIGHT / BMI / BSA | values | Onkar Kshirsagar | RESOLVED - spec-literal record filter; division guards retained separately | 84a53a1 (settling commit; 13 commits name this row, first 364732b) |
| Q69 | LABHEM / LABHEMV / LABHEMDT | none | Onkar Kshirsagar | RESOLVED - trimmed comparison; the spec cell is erratum E20 | 1aa2fdb (settling commit; 4 commits name this row, first 364732b) |
| Q70 | MCRPCDDYR / MHSPCDDYR / MPCDDYR / INITYR, PSA50_6MO / PSAL6MO / PSA50_12MO / PSAL12MO, BMIGR1 | none | Onkar Kshirsagar | RESOLVED - build types confirmed; contract pinned when qc/07 is run and reviewed | ca52ff3 (settling commit; 7 commits name this row, first 364732b) |
| Q71 | ECOG / ECOGN | values | Onkar Kshirsagar | RESOLVED - clamped to the six documented categories | 1a4d888 (settling commit; 3 commits name this row, first 14deccc) |
| Q72 | WEIGHT / HEIGHT / BMI / BSA, HRR_INDEX / BRCA_INDEX, LOT1CAT_MCRPC | values | Onkar Kshirsagar | RESOLVED - both group on a normalised name | 4bb2bd9 (settling commit; 6 commits name this row, first 14deccc) |
| Q73 | LOT1_MCRPC and siblings, LOT1CAT_MCRPC and siblings | values | Onkar Kshirsagar | RESOLVED - accepted for now; sized by R55 and S6 before any change | 16952e5 (settling commit; 2 commits name this row, first 14deccc) |
| Q74 | AGEGR1 | values | Onkar Kshirsagar | RESOLVED - the label that pairs with AGEGR1N's 99 | fea1c7e (settling commit; 2 commits name this row, first 6aa35e0) |
| Q75 | GLEASON / GLEASONN | values | Onkar Kshirsagar | RESOLVED - match both spellings, source wins | fea1c7e (settling commit; 2 commits name this row, first 6aa35e0) |
| Q76 | LOT uniqueness key | none | Onkar Kshirsagar | RESOLVED - the printed key cannot be built in this cut | fea1c7e (settling commit; 2 commits name this row, first 6aa35e0) |
| Q77 | DATAV / source tables | values | Onkar Kshirsagar | RESOLVED - the cut is June 2026 | fea1c7e (settling commit; 2 commits name this row, first 6aa35e0) |
| Q78 | B15 / B16 / B17 | none | Onkar Kshirsagar | RESOLVED - approved as build preconditions | 84a53a1 (settling commit; 2 commits name this row, first 6aa35e0) |
| Q79 | PSA6MO / PSA50_6MO / PSAL6MO | none | Onkar Kshirsagar | RESOLVED - no change; the variable's own row governs | fea1c7e (settling commit; 2 commits name this row, first 546f6a1) |

## Detail

### Q01 - MAXINDEX

- **Spec reference:** 3.Data Prep r13
- **Spec says:** Printed as 4/31/2026, not a calendar date
- **We do:** Using 2026-04-30 (max date observed in source tables)
- **Decision:** MAXINDEX = 2026-04-30.
- **Why:** Spec prints the impossible 4/31/2026; preflight D1 shows all six source tables max at 2026-04-30. RESOLVED 2026-08-07. The spec prints 4/31/2026, which is not a date - April has 30 days. 2026-04-30 is both the last valid day of that month and the latest date observed across the source tables. No code change; spec erratum E14.
- **Evidence:** Preflight D1 (2026-08): lot.startdate, visit, telemedicine, drugepisode, prog.lastclinicnote and psa.resultdate ALL max at 2026-04-30
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q02 - TTNTFL

- **Spec reference:** 6.Outcomes
- **Spec says:** Struck out, but the active TTNT definition reads it
- **We do:** Derived internally; not emitted
- **Decision:** Build's reading confirmed; correct the spec, not the code.
- **Why:** APPROVED 2026-08-07 as part of the nine-item spec errata block (this file). The build's reading is confirmed correct and the SPEC is what gets corrected; no code change. Approved as a block because in each case the literal spec text is self-evidently not the intent - most starkly Q45, which taken literally clamps FUED to the index date for every patient with follow-up and would zero OS, TTNT, PFS and FUDUR across the study.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q03 - HRR_INDEX_TEST / BRCA_INDEX_TEST

- **Spec reference:** 5B.ClinChars r72/r76
- **Spec says:** No test-type column exists on the biomarker table
- **We do:** Hard-coded 'Unknown' / 7 for every row
- **Decision:** No differentiation by test type. HRR_INDEX_TEST / BRCA_INDEX_TEST stay 'Unknown' (7).
- **Why:** RESOLVED. SME ruled that test type is not differentiated. The source has no test-type column, so the delivered value stays hard-coded 'Unknown'/7, and test type is not used to choose the winning test either (Q37). The columns remain in the ADS as constants; the null sweep waives them on that basis. Recorded from an SME consultation relayed by the data product owner on 2026-08-07; the SME is not named in the relay, so name them here before this is used as a release record.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q04 - HRR_INDEX / BRCA_INDEX

- **Spec reference:** 5B.ClinChars r70/r74
- **Spec says:** Spec says max(SPECIMENRECEIVEDDATE, RESULTDATE); table has SPECIMENCOLLECTEDDATE
- **We do:** Using max(specimencollecteddate resultdate)
- **Decision:** Build's reading confirmed; correct the spec, not the code.
- **Why:** APPROVED 2026-08-07 as part of the nine-item spec errata block (this file). The build's reading is confirmed correct and the SPEC is what gets corrected; no code change. Approved as a block because in each case the literal spec text is self-evidently not the intent - most starkly Q45, which taken literally clamps FUED to the index date for every patient with follow-up and would zero OS, TTNT, PFS and FUDUR across the study.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q05 - HRR_INDEX

- **Spec reference:** 5B.ClinChars r70/r74
- **Spec says:** Spec matches BIOMARKERNAME='HRR'; the column holds gene symbols. Which genes constitute HRR?
- **We do:** Three modes via RDAP_HRR_PANEL: 'flatiron_all' (default, all 19 genes in the table), 'olaparib_label' (14), 'talapro2' (12). The winning test date is ONE date per patient - the biomarker test CLOSEST to index, chosen over ALL biomarker tests regardless of gene or test type, and shared by the HRR and BRCA calls (Q37). Status is then resolved within each gene on that shared date and rolled up across genes (Q29). A NON-DEFAULT panel writes to a study-specific table name so a panel build cannot overwrite the governed one.
- **Decision:** HRR = the 19 approved gene symbols, frozen in code.
- **Why:** General-purpose RWDP feeding many studies, not a single asset's evidence package. For a data product the principle is capture broadly and let each study narrow: HRR_INDEX is a collapsed patient-level status with no gene-level column in the ADS, so a narrower panel cannot be widened downstream without rebuilding from source. The table is exactly the union of the olaparib-label (14) and TALAPRO-2 (12) panels, so 'all genes' is a defensible definition rather than a catch-all, and flatiron_all uses no gene list so it cannot go stale or miss an alias. D5b: the three options differ by at most 6.3% of positives. Marked 'for now' - revisit if this ADS is later scoped to a specific asset (see Q28). RESOLVED 2026-08-07. flatiron_all now names the 19 symbols explicitly instead of applying no filter.
- **Evidence:** Preflight D5pre (2026-08): exactly 19 distinct genes, precisely the union of the FDA olaparib mCRPC label panel (14) and the TALAPRO-2 panel (12). Nothing outside either panel; all symbols canonical, no aliases. PPP2R2A - the sole PROfound gene the FDA label omits - is absent from the data. D5b: HRR-positive patients = 16011 flatiron_all / 15453 talapro2 / 14999 olaparib_label / 5715 BRCA-only. The three HRR options differ by at most 1012 patients (6.3% of positives), so the choice is minor. TEXT CORRECTED 2026-08-07: this row previously said the winning date was resolved PER GENE. That described the superseded algorithm and contradicted both Q37 and the code. A reviewer reading this row could have approved an algorithm the build does not run.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row
- **Stale narrative, noted 2026-08-08.** Parts of the reasoning above still describe `flatiron_all` as "whatever is in the table", with no gene list. Q44 froze it to the nineteen named symbols and the code has worked that way since. The DECISION is right; only the account of what it replaced is out of date.
- **Wording corrected 2026-08-08.** The 'We do' above described the pre-Q44 world, where `flatiron_all` meant every gene in the table. Q44 froze it to the nineteen NAMED symbols and the code has worked that way since. Read Q05 as 'which genes count as HRR' and Q44 as 'freeze them, do not track the table'. Two facets, one implementation, no contradiction.

### Q06 - LOTN

- **Spec reference:** 5C.TreatVars r2
- **Spec says:** Note asks 'Do separate for mCRPC and mHSPC?' - unresolved
- **We do:** LOTN / LOTNGR1 / LOTNGR1N count mCRPC lines, as the spec defines. LOTN_MHSPC / LOTNGR1_MHSPC / LOTNGR1N_MHSPC count mHSPC lines, generated by the same function so the banding cannot drift between the two settings. Contract is now 190 columns.
- **Decision:** Yes, separate. Deliver an mHSPC line count alongside the mCRPC one.
- **Why:** RESOLVED 2026-08-07. The spec asked itself this question in row 2's Additional Notes and never answered it; the owner answered yes. WHY IT MATTERED: mHSPC precedes mCRPC and not every patient progresses, so a patient in cohort 1 or cohort 3 who is on treatment but still hormone-sensitive has no mCRPC lines and reads LOTN = 0. Cohort 3 alone holds 79,051 patients. Without the mHSPC pair that line count was simply absent from the ADS - not merely undocumented - and LOTN = 0 reads as 'untreated' to anyone who does not know the definition. Documenting the caveat could warn about the gap but could not fill it. NAMING ASYMMETRY, deliberate: the unsuffixed LOTN still means mCRPC, because that is what the spec names it. Only the new pair carries a suffix. Renaming LOTN to LOTN_MCRPC would read better but would break a name the spec gets right - unlike the three corrected under Q08/Q46/Q17, which were malformed. Flagged here so the asymmetry is a recorded choice rather than an oversight.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q07 - LABPLA / LABBIL

- **Spec reference:** 5B.ClinChars r20/r29
- **Spec says:** LABPLA Present clause says testbasename='hemoglobin'; LABBIL unit says 10*9/L
- **We do:** Coded to the clinically intended analyte and unit
- **Decision:** LABBIL reads bilirubin at mg/dL - the spec's '10*9/L' unit filter is a slip. LABPLA: NO DEFECT (see Q55) - the spec says 'platelets' and the build reads platelets.
- **Why:** PARTIALLY WITHDRAWN 2026-08-08 (see Q55). The LABBIL limb STANDS: the spec's LABBIL unit filter says 10*9/L while its label says mg/dL, corroborated by the spec text and by the data (bilirubin populated at mg/dL, 4,923,058 rows). Coding it literally would have emptied the variable. The LABPLA limb is WITHDRAWN: it was reported the Present clause as naming testbasename='hemoglobin'; the owner confirmed against the spec that it says 'platelets', matching its own Missing clause. There was never a slip on that row. The build filtered platelets throughout, so this was a documentation error only.
- **Evidence:** Preflight C10/D7 (2026-08): bilirubin populated at mg/dL (4923058 rows); platelets populated at 10*9/L
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q08 - PRIOR_DOCITAXEL / PRIOR+ABIRATERONE

- **Spec reference:** 5C.TreatVars r40/r41
- **Spec says:** Spelling typos in the spec
- **We do:** Delivered as PRIOR_DOCETAXEL and PRIOR_ABIRATERONE. Both spec spellings corrected.
- **Decision:** Correct to PRIOR_DOCETAXEL and PRIOR_ABIRATERONE.
- **Why:** RESOLVED 2026-08-07: correct all three to clean names. Delivered as PRIOR_DOCETAXEL, PRIOR_ABIRATERONE and LOT4CATN_MCRPC. This DIVERGES from the spec's column list on purpose - the spec is what gets corrected (errata E13). The asymmetry that used to exist here is gone: the build no longer preserves one slip while fixing another. Note the consequence: any consumer already coding against PRIOR_DOCITAXEL or LOT4CATN must change, which is why this was worth ruling on before release rather than after.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row
- **What the spec prints, in full (from Q46):** row 40 names the docetaxel flag PRIOR_DOCITAXEL - 'DOCITAXEL', misspelt - with the label 'Docitaxel received prior to index'. Row 41 names the abiraterone flag PRIOR+ABIRATERONE, with a plus sign where an underscore belongs. Both are delivered corrected: PRIOR_DOCETAXEL and PRIOR_ABIRATERONE.

### Q09 - INITYR

- **Spec reference:** 5B.ClinChars r9
- **Spec says:** Definition reads Year(INITYR) - self-referential
- **We do:** Coded as Year(INIT)
- **Decision:** Build's reading confirmed; correct the spec, not the code.
- **Why:** APPROVED 2026-08-07 as part of the nine-item spec errata block (this file). The build's reading is confirmed correct and the SPEC is what gets corrected; no code change. Approved as a block because in each case the literal spec text is self-evidently not the intent - most starkly Q45, which taken literally clamps FUED to the index date for every patient with follow-up and would zero OS, TTNT, PFS and FUDUR across the study.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q10 - TINTCRPCHSPC

- **Spec reference:** 5B.ClinChars r14
- **Spec says:** Printed formula (HSPCDate-CRPCDate) contradicts the label 'Time from HSPC to CRPC'; divisor 30.4376 vs 30.4375 elsewhere
- **We do:** (CRPCDate - HSPCDate)/30.4375, per the row's label. Single formula, no environment switch.
- **Decision:** Build's reading confirmed; correct the spec, not the code.
- **Why:** The spec row's label ('Time from HSPC to CRPC') and its printed formula (HSPCDate - CRPCDate) are opposite. Preflight D2: 72543 of 73026 patients reach CRPC after HSPC, so the printed form would be negative for 99.3%. Label taken as intent, formula as a transposition slip; divisor aligned to the 30.4375 used everywhere else. The verbatim form was briefly selectable via an environment variable; that was removed once this was decided, since a switch that flips the sign of a delivered column is one more way for a run to differ from the approved definition. For the record, the formula that was REJECTED - the spec's printed form, not what the build computes - is (HSPCDate - CRPCDate)/30.4376. APPROVED 2026-08-07 as part of the nine-item spec errata block (this file). The build's reading is confirmed correct and the SPEC is what gets corrected; no code change. Approved as a block because in each case the literal spec text is self-evidently not the intent - most starkly Q45, which taken literally clamps FUED to the index date for every patient with follow-up and would zero OS, TTNT, PFS and FUDUR across the study.
- **Evidence:** Preflight D2 (2026-08): crpc_after_hspc 72543, crpc_before_hspc 50, same_day 433 of 73026 - the printed formula is negative for 99.3% of patients Spec image read 2026-08-07 confirms the printed formula is (HSPCDate - CRPCDate)/30.4376 while the label reads 'Time from HSPC to CRPC'. Note the divisor on this row alone is 30.4376; every other months conversion on the sheet, and 3.Data Prep Section C, uses 30.4375. The build uses 30.4375 throughout. The 1e-4 difference is immaterial to any delivered value but it is one more sign this row was typed rather than derived, which is the argument for trusting its label over its formula.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q11 - COHORTU

- **Spec reference:** 4.StudyPop r13
- **Spec says:** Definition inverts treated/untreated and never assigns 'Treated mCRPC'
- **We do:** Implemented the coherent reading (has a line in setting -> Treated)
- **Decision:** Populate all seven cohorts; treated = has a line in that setting.
- **Why:** RESOLVED 2026-08-07: populate all seven cohorts. Cohorts 3-7 are treated BY CONSTRUCTION - they are defined by having a line of therapy in that setting - so they resolve to 'Treated <setting>' and the value is constant within each. It is therefore redundant with COHORTN, but a consumer filtering COHORTU='Treated mCRPC' gets every treated mCRPC patient rather than only those inside the Overall cohort, which is the more useful behaviour. No code change: the build already does this. The spec row is wrong on two counts - it inverts treated/untreated and never assigns 'Treated mCRPC' at all - so it joins the errata list as E12.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q12 - LABLYMDT

- **Spec reference:** 5B.ClinChars r46
- **Spec says:** Definition duplicates LABLYMV's text
- **We do:** Coded as the date
- **Decision:** Build's reading confirmed; correct the spec, not the code.
- **Why:** APPROVED 2026-08-07 as part of the nine-item spec errata block (this file). The build's reading is confirmed correct and the SPEC is what gets corrected; no code change. Approved as a block because in each case the literal spec text is self-evidently not the intent - most starkly Q45, which taken literally clamps FUED to the index date for every patient with follow-up and would zero OS, TTNT, PFS and FUDUR across the study.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q13 - All labs

- **Spec reference:** 3.Data Prep sC r29
- **Spec says:** Open item: 'lowest or highest' on same-day ties
- **We do:** Per-row red-bold instructions in 5B followed (per analyte)
- **Decision:** Note #5 (the dated email quoted in Section C) is authoritative. LABNEUV's 'highest' contradicts the note it cites and is an erratum.
- **Evidence:** CLOSED 2026-08-07 on the spec. 3.Data Prep Section C row 29 leaves 'lowest or highest' open, but 5B.ClinChars states a direction on every analyte's own value row, in red bold, and all ten were read individually during the reconciliation: NEU/PLA/HEM/CRE/ALB take the LOWEST value on a tied date, BIL/AST/ALT/ALP/LYM the HIGHEST. The build matches all ten. This is a reading check, not a judgement about what the direction should be - the spec answers its own open item elsewhere. CORRECTED 2026-08-07. My closure said all ten per-analyte rows were read individually and gave NEU as LOWEST. That is wrong: the LABNEUV row reads 'take the [highest value, per note #5]'. Nine of the ten rows agree with note #5; LABNEUV is the exception AND it contradicts the very note it cites - Section C item 5 quotes a dated email from Linda giving 'Albumin, neutrophil, platelet, hemoglobin, serum creatinine - lowest'. The code uses LOWEST for neutrophils, which matches the email, matches the other nine rows' pattern, and is the clinically expected direction (the nadir is what matters for neutropenia). So the CODE is right and my REASONING was wrong - the closure said 'the per-analyte row supersedes Section C', which applied to NEU would give highest.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q14 - Output naming

- **Spec reference:** 3.Data Prep rows 1-8
- **Spec says:** Section A of 3.Data Prep was not supplied, so the output table name is unconfirmed
- **We do:** output_table = paste0('rwdp_pros_pano_', refresh, panel_suffix), written to personal_schema = 'osk02156'. A non-default HRR panel appends a suffix so a panel build cannot overwrite the governed table.
- **Decision:** Output table is rwdp_pros_pano_2026m06, in schema osk02156.
- **Why:** RESOLVED 2026-08-07 by the data product owner, confirming the name directly. WORTH BEING PRECISE ABOUT WHAT THIS CLOSES ON: the name is confirmed by the OWNER, not verified against the spec. Section A of 3.Data Prep - the sheet that defines output naming - was never supplied and still does not exist in anything this build has seen. The name was originally inferred from convention and has now been confirmed to be the right one, which is a different and weaker basis than every other resolved row in this register, where the spec text was read. If that page later surfaces and names something else, this row reopens.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q15 - t_allprostate_pats

- **Spec reference:** 5A.Demos r3
- **Spec says:** References a separate all-prostate-patients dataset
- **We do:** Out of scope for this script
- **Decision:** Out of scope for this build.
- **Why:** RESOLVED 2026-08-07. 5A.Demos Section A's header describes a SECOND deliverable - an all-prostate patients dataset 'to be used for other studies' - built from t_allprostate_pats_2026j30. That is a different source with a different refresh suffix (2026j30, not 2026m06), and this build delivers the seven-cohort ADS only. Scoped out rather than forgotten; if it is wanted it needs its own source, output and column contract.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q16 - max_drug_ep_abstracted_dt

- **Spec reference:** 5B.ClinChars r88
- **Spec says:** EpisodeDataSource='Abstraction' does not exist in 2026m06, so max_drug_ep_abstracted_dt ships all-null. Resolve by naming a replacement source (changes values) or dropping the column (changes the column set).
- **We do:** Filter kept as specified; resolves to NULL for all
- **Decision:** Keep the column. It is all-null in 2026m06 and both QC tests already exist.
- **Why:** RESOLVED 2026-08-07: keep the column, with QC. The QC the owner asked for is already in place at both ends, so nothing new was needed - it just was not pointed at from this row. AT SOURCE: preflight C3 lists every distinct episodedatasource with counts, and D3 counts rows where episodedatasource='Abstraction' - currently zero. If a future cut reintroduces the value, D3 stops being zero and the column stops being all-null, which is the signal. AT OUTPUT: the null sweep waives max_drug_ep_abstracted_dt with shape 'null', meaning it expects NO values at all - so if the column ever becomes populated the sweep reports REVIEW rather than passing silently. The waiver checks the SHAPE, not just a boolean 'waived', which is what makes it a test rather than an excuse.
- **Evidence:** Preflight C3 (2026-08): episodedatasource is only Administrations/Unstructured/Orders - Abstraction does not exist, so max_drug_ep_abstracted_dt is NULL for every patient
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q17 - LOT4CATN

- **Spec reference:** 5C.TreatVars r35
- **Spec says:** Named without the _MCRPC suffix every other line uses
- **We do:** Delivered as LOT4CATN_MCRPC, matching the LOTnCATN_<SET> pattern of every other line.
- **Decision:** Correct to LOT4CATN_MCRPC.
- **Why:** RESOLVED 2026-08-07: correct all three to clean names. Delivered as PRIOR_DOCETAXEL, PRIOR_ABIRATERONE and LOT4CATN_MCRPC. This DIVERGES from the spec's column list on purpose - the spec is what gets corrected (errata E13). The asymmetry that used to exist here is gone: the build no longer preserves one slip while fixing another. Note the consequence: any consumer already coding against PRIOR_DOCITAXEL or LOT4CATN must change, which is why this was worth ruling on before release rather than after.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q18 - BIOMARKERSTATUS

- **Spec reference:** 5B.ClinChars r70/r74
- **Spec says:** Spec matches 'Mutation Negative'; data holds 'Negative'
- **We do:** Matching on 'negative'
- **Decision:** Match BIOMARKERSTATUS on 'negative' rather than the spec's literal 'Mutation Negative'.
- **Why:** 'Mutation Negative' never occurs in 2026m06 - the delivered values are Negative, Positive, Unknown-not-documented and VUS. Matching the spec literally would score every negative result as unmatched. Substring matching on 'negative' also survives a future 'Mutation Negative' should the vocabulary change. Transcription correction, not a change of definition.
- **Evidence:** Preflight C5 (2026-08): biomarkerstatus values are Negative/Positive/Unknown-not-documented/VUS; Mutation Negative never occurs
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q19 - COHORTU

- **Spec reference:** 4.StudyPop r13
- **Spec says:** Definition only branches on the two Overall cohorts
- **We do:** Populated for all seven
- **Decision:** Populate all seven cohorts, not just the two Overall ones.
- **Why:** RESOLVED 2026-08-07: populate all seven cohorts. Cohorts 3-7 are treated BY CONSTRUCTION - they are defined by having a line of therapy in that setting - so they resolve to 'Treated <setting>' and the value is constant within each. It is therefore redundant with COHORTN, but a consumer filtering COHORTU='Treated mCRPC' gets every treated mCRPC patient rather than only those inside the Overall cohort, which is the more useful behaviour. No code change: the build already does this. The spec row is wrong on two counts - it inverts treated/untreated and never assigns 'Treated mCRPC' at all - so it joins the errata list as E12.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row
- **Duplicate of Q11, marked 2026-08-08.** Same variable, same question, same answer. Q11 is the fuller row - it also covers the definition inverting treated and untreated. Nothing here contradicts Q11; it was raised twice and answered twice. Read Q11.

### Q20 - HRR/BRCA window

- **Spec reference:** 5B.ClinChars r70/r74
- **Spec says:** Which window bounds the HRR/BRCA biomarker search? THE SPEC CONTRADICTS ITSELF ACROSS TWO SHEETS. 3.Data Prep Section C item 6 ('Biomarker tests / Biomarker dates to use') says biomarker status is defined from tests conducted 'ON OR ANY TIME PRIOR TO INDEX DATE' - unlimited lookback, no post-index tests. 5B.ClinChars HRR_INDEX and BRCA_INDEX Additional Notes say 'Use [-30, +7] window around index date' - 30 days lookback, 7 days AFTER index allowed. The two cannot both hold: each admits tests the other excludes.
- **We do:** [-30, +7], following 5B.ClinChars. 03_clinical.R filters testdt >= DATE_SUB(index_date,30) and testdt <= DATE_ADD(index_date,7). Section C's 'any time prior to index' is NOT implemented.
- **Decision:** Use the [-30, +7] window from 5B.ClinChars for HRR_INDEX and BRCA_INDEX.
- **Why:** RESOLVED. The spec contradicts itself: 3.Data Prep Section C #6 says biomarker tests 'on or any time prior to index date' (unlimited lookback, no post-index tests), while 5B.ClinChars carries '[-30, +7]' on both variable rows. Owner ruled for the 5B window, which is the sheet that defines the variable and which matches LOT_ECOG's [INDEX-30, INDEX+7] elsewhere in the spec. Section C should be corrected to match, otherwise the next reader hits the same contradiction. Recorded from an SME consultation relayed by the data product owner on 2026-08-07; the SME is not named in the relay, so name them here before this is used as a release record.
- **Evidence:** Read from the spec, 2026-08-07. 3.Data Prep Section C #6 full text: 'Biomarker status will be defined as biomarker tests conducted on or any time prior to index date. Biomarker test date is defined as the later date of specimen received, or date of result in the biomarker tables for a given test. If any of the date of specimen received, or date of result is missing, only the available dates will be used to define the biomarker test date. No imputation will be conducted to missing date variables.' 5B.ClinChars carries '[-30, +7]' in Additional Notes on both the HRR_INDEX and BRCA_INDEX rows. MATERIALITY: preflight D5b counted 16,011 HRR-positive patients scanning ALL TIME. A 37-day window admits far fewer tests, so the delivered HRR_INDEX/BRCA_INDEX positive counts under the current code should be well below 16,011. The gap between the delivered count and D5b is the size of this decision and must be read off the first real run. Note the same Section C text also confirms two things the code already does: the test date is the LATER of the two dates, and when one is missing only the available one is used (pmax with na.rm=TRUE). It says 'specimen RECEIVED'; the 2026m06 table has specimencollecteddate only - that substitution is Q04.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q21 - min_vst_dt / min_vsttelemed_dt / min_medord_dt

- **Spec reference:** 5B.ClinChars r88
- **Spec says:** Named in row 88 but unused by the row-89 derivation
- **We do:** All six produced; min_medord_dt sourced from t_medicationorder.expectedstartdate
- **Decision:** Build's reading confirmed; correct the spec, not the code.
- **Why:** APPROVED 2026-08-07 as part of the nine-item spec errata block (this file). The build's reading is confirmed correct and the SPEC is what gets corrected; no code change. Approved as a block because in each case the literal spec text is self-evidently not the intent - most starkly Q45, which taken literally clamps FUED to the index date for every patient with follow-up and would zero OS, TTNT, PFS and FUDUR across the study.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q22 - BIRTHYEAR

- **Spec reference:** 5A.Demos r8
- **Spec says:** Row 8 says keep it; 202603 deliberately dropped it; it is identifying
- **We do:** Retained
- **Decision:** Keep BIRTHYEAR, as 5A.Demos row 8 instructs.
- **Why:** 5A.Demos row 8 lists birthyear among 'keep these variables when creating this analytic dataset'. Supersedes 202603, which dropped it. RESOLVED 2026-08-07: keep it, per the spec. No code change. RECORDED BECAUSE IT DOES NOT GO AWAY BY BEING APPROVED: BIRTHYEAR is directly identifying, and AGE and AGEGR1N are already delivered, so it adds re-identification risk without adding analysis those two do not already support. The 202603 build dropped it deliberately. This is a data-product decision, not a disclosure-risk assessment - if anyone owns disclosure risk for this deliverable, they should see this row before consumers get access.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q23 - ECOGN

- **Spec reference:** 5B.ClinChars r47
- **Spec says:** How many ECOG categories and codes does the spec define? the earlier reading of the ECOGN Values list as '1,2,3,4,5,6,7' - seven codes for six categories - and built the extra code to separate Unknown (a record exists, value null) from Missing (no record at all).
- **We do:** ECOG delivers '0','1','2','3','4','Unknown/Missing' and ECOGN 1..6, matching the spec. Corrected 2026-08-07.
- **Decision:** Six categories, six codes, exactly as the spec lists.
- **Why:** A REAL DEFECT, introduced by me and shipped until now. The build delivered a seventh ECOG category and a seventh ECOGN code that the spec does not define, and split a label the spec combines - so BOTH the character and the numeric column diverged from the Values list. Worse, I had CLOSED this row on 2026-08-07 with the reasoning that 6 and 7 were 'the spec's own codes', which was the misreading restated as a justification. Now fixed: ecog = 'Unknown/Missing', ecogn = 6, and V1's c15 mapping gate updated to match. WHAT IS LOST, and it is worth knowing: the build could distinguish 'a record exists but the value is null' from 'no ECOG record at all'. That distinction is real and is now gone, because the spec asks for one category. If it is wanted, it needs a new variable rather than an undeclared seventh code.
- **Evidence:** CORRECTED 2026-08-07 against the spec text (the spec text), an independent reading of the same source pages. It gives ECOG Values as '0','1','2','3','4','Unknown/Missing' - six categories with unknown and missing COMBINED - and ECOGN as 1,2,3,4,5,6. Six codes, not seven. The earlier reading of a seventh code was wrong.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q24 - NEW_LOT_N

- **Spec reference:** 3.Data Prep r19
- **Spec says:** No tie-breaker defined for two lines starting the same day in one setting
- **We do:** Build STOPS via run_preflight() check B1; no tie-breaker invented
- **Decision:** Keep the preflight gate. The build stops rather than guessing a tie-break.
- **Why:** RESOLVED 2026-08-07. A non-deterministic NEW_LOT_N would silently move cohort membership, index dates and every LOTn variable, so stopping is safer than inventing an order the spec does not have. It costs nothing today: the Q42 query measured ZERO same-day line pairs in either setting for 2026m06, so gate B1 never fires on this cut. It stays as protection for future cuts.
- **Evidence:** Preflight B1 (2026-08): 0 same-day LOT ties. run_preflight() check B1 enforces this on every build SUPPORTED 2026-08-07 by the Q42 query, which is the same condition: zero consecutive line pairs share a start date in either mHSPC or mCRPC. So NEW_LOT_N is deterministic on 2026m06 and the preflight gate B1 does not fire. The gate stays as protection for future cuts, but the current build carries no exposure. Source: validation/'Query Results .txt' (on main), run 2026-08-07.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q25 - LABALB

- **Spec reference:** 5B.ClinChars r44
- **Spec says:** No albumin rows carry testunitscleaned='g/L'; the populated serum-albumin rows have a NULL unit
- **We do:** The spec's testunitscleaned='g/L' filter is APPLIED, alongside labcomponent='Albumin, serum'. Restored 2026-08-07 after the query showed the premise for dropping it was false.
- **Decision:** Apply the spec's g/L filter. The delivered LABALBV is g/L.
- **Why:** RESOLVED. Two separate things were settled. (1) SCALE: 'Albumin, serum' carries unit g/L on 4,966,771 rows with median 40, which is g/L (35-50) and not g/dL (3.5-5.0) - so the delivered value was already on the right scale and there is no factor-of-ten error. (2) FILTER: it had been dropped on the belief that no albumin row carried g/L, which the same query disproved, so it is restored. The scale is now right BY CONSTRUCTION rather than by luck - a future row arriving in a different unit is excluded instead of being averaged into a g/L column. The filter sits in the 'Present' criteria, not in the record-exists check, because the spec's Missing clause names only testbasename and labcomponent: a wrong-unit record makes LABALB 'Unknown', not 'Missing'. Still worth an explicit nod rather than a silent inheritance: 'Albumin [mass/volume] in serum by electrophoresis' (181,577 rows, also g/L, median 39) is excluded by the exact labcomponent match. That looks right - different assay - but it was never a considered choice.
- **Evidence:** RESOLVED ON SCALE 2026-08-07. t_lab, all rows with testbasename='albumin', grouped by labcomponent and testunitscleaned: 'Albumin, serum' carries unit 'g/L' on 4,966,771 rows / 308,946 patients, with p25 37 and MEDIAN 40. Serum albumin in g/L runs 35-50; in g/dL it would run 3.5-5.0. The delivered LABALBV is therefore g/L, which is exactly what the spec's label says. THERE IS NO 10x ERROR. The urine variants are mg/L or mg/d and are correctly excluded by the labcomponent='Albumin, serum' filter. BUT THIS ROW'S ORIGINAL PREMISE IS FALSIFIED. It claimed no albumin row carried testunitscleaned='g/L' and that the populated serum rows had a NULL unit. Nearly five million rows carry g/L. Whatever earlier check produced that claim was wrong or was scoped to something much narrower; it should not be relied on again. Source: validation/'Query Results .txt' (on main), run 2026-08-07.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q26 - PSMA_SCANRESULT

- **Spec reference:** 5B.ClinChars r79
- **Spec says:** Patients have two PSMA scans on the same date with conflicting IsDiseaseEvidence; the spec gives no tie rule
- **We do:** Same-date conflicts resolve Yes+No -> Unknown/not documented, Yes+Unknown -> Yes, No+Unknown -> No. The alphabetical MAX() is gone.
- **Decision:** Yes+No on the same date resolves to Unknown/not documented.
- **Why:** RESOLVED 2026-08-07. Implemented, replacing max() on the string - which resolved alphabetically and so favoured 'Yes' as an artefact of collation rather than a clinical rule. The new rule mirrors the one the spec DOES state for biomarkers on a shared date: Yes+No -> Unknown (cf. Positive+Negative -> Unknown), Yes+Unknown -> Yes, No+Unknown -> No. Affects the 8 patients with a hard contradiction; the other 30 pair a definite answer with Unknown and are unchanged.
- **Evidence:** Preflight B10 (2026-08): same-date conflicts confirmed (No/Yes, Yes/Unknown) QUANTIFIED 2026-08-07 from validation/preflightoutpt.pdf (result set 6 of 27), which lists every patient whose latest PSMA scan date carries more than one distinct IsDiseaseEvidence: 38 rows. The conflicting pairs are not all value-vs-Unknown - at least 8 of the 38 are a hard ["No","Yes"] contradiction on the same scan date, with the rest pairing a definite answer against 'Unknown/not documented'. So the tie rule is not a formality: for those 8 patients it decides whether PSMA_SCANRESULT is Yes or No, and MAX() on the string currently resolves it alphabetically, which favours 'Yes' over 'No' and 'Unknown/not documented' over both.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q27 - Publication step

- **Spec reference:** n/a
- **Spec says:** Should the build write the deliverable directly, or to a staging copy that a separate manual step publishes?
- **We do:** Writes the deliverable directly. One table, one path, no staging copy and no publish step.
- **Decision:** Keep the direct write. No staging copy, no publish step.
- **Why:** Owner's decision: the two-step was ceremony for a single-analyst build. The cost is explicit and documented - the table is live the moment the build finishes, so an unvalidated build is immediately visible to consumers and a validation FAIL means rebuild or drop rather than 'hold the release'. What still stops a bad build BEFORE anything is written is the preflight gates - twelve of them now, plus the input-contract check and the pre-write cohort count. Revisit if this ADS is ever read by an automated downstream consumer that cannot tolerate a transiently wrong table. RESOLVED 2026-08-07: current behaviour confirmed. This is an ACCEPT-THE-RISK decision, not a no-risk one, and the residual risk belongs in writing: the deliverable is LIVE the moment the build finishes, so the output validation (V1, V2c, V4, the null sweep, the column checker) can only run AFTER consumers could already have read it. If validation fails, the remedy is to drop or rebuild the table FAST - there is no quarantine. What makes this defensible today: the preflight gates stop a bad run BEFORE anything is written, the build prints 'This table is LIVE - run the output validation now', and the product is in controlled UAT with no consumers attached. WHAT WOULD CHANGE THE ANSWER: real consumers. Once anything downstream reads this table on a schedule, a failed validation stops being recoverable by speed, and staging or a view swap should be revisited.
- **Evidence:** n/a
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row
- **Mitigation 2026-08-08:** the decision is unchanged, but one gap in it is now closed. The preflight gates check the SOURCE; nothing checked the RESULT, so a build that came out empty - a bad refresh, a filter that matched nothing - would have replaced the live table with zero rows before any validation ran. 06_assemble.R now counts the seven materialized cohort stages before the write and stops if any is empty, leaving the previous table untouched. It can only refuse a write; it cannot change a value.

### Q28 - HRR_INDEX / BRCA_INDEX

- **Spec reference:** 5B.ClinChars r70-r77
- **Spec says:** Should HRR_INDEX be accompanied by a label-aligned sibling variable, the way BRCA_INDEX already is? HRR_INDEX is a collapsed patient-level status and the ADS carries no gene-level column, so the panel choice is irreversible downstream - a study needing a different definition must rebuild from t_enh_prostate_biomarker.
- **We do:** HRR_LABEL_INDEX and HRR_LABEL_INDEXN ship alongside HRR_INDEX, computed over the 14-gene olaparib label set through the same biomarker_status() function and the same shared winning date.
- **Decision:** Add a label-aligned sibling: HRR_LABEL_INDEX / HRR_LABEL_INDEXN.
- **Why:** RESOLVED 2026-08-07 and implemented. Before this, seeing the label-aligned view meant running the whole build again with RDAP_HRR_PANEL set, so the two views could never appear in one dataset and no single row could be compared across panels. DELIBERATE: the sibling is NOT affected by RDAP_HRR_PANEL - it always means the olaparib label, whatever panel the main HRR_INDEX is built from. If it tracked the switch the two columns would move together and the comparison they exist for would be lost. New gate V2e: the 14 label genes are a subset of the default 19, so HRR_LABEL_INDEX='Positive' must imply HRR_INDEX='Positive'. Same shape as V2c, and it fails closed if the two gene lists are ever edited out of subset relation.
- **Evidence:** validation/00_column_contract.csv carries hrr_index/hrr_indexn and brca_index/brca_indexn only - no biomarkername or gene-level column. The spec already uses the two-variable pattern (broad + narrow), so a third label-aligned variable would follow its own design.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q29 - HRR_INDEX / BRCA_INDEX

- **Spec reference:** 5B.ClinChars r70/r74
- **Spec says:** How is a multi-gene panel collapsed to one patient-level status? The spec's HRR_INDEX row is written for BIOMARKERNAME='HRR' - a SINGLE aggregated value per test - and gives a same-date collision list for that value. The source holds ONE ROW PER GENE and never a row named 'HRR', so the spec's rules have no cross-gene rollup to apply.
- **We do:** Two steps. (1) WITHIN each gene, on the ONE shared winning date (Q37), the spec's four same-date rules plus three VUS pairs all now ruled: Negative+VUS -> Negative, VUS+Unknown -> Unknown/Not documented, Positive+VUS -> Positive. (2) ACROSS genes, best status wins, ranked Positive > Negative > VUS > Unknown.
- **Decision:** Within a gene: Pos+VUS -> Positive, Neg+VUS -> Negative, VUS+Unknown -> Unknown. Across genes: Positive > Negative > VUS > Unknown.
- **Why:** RESOLVED FOR NOW. FROM THE SPEC and reproduced unchanged: all four same-date collision rules (Positive+Negative -> Unknown, Positive+Negative+Unknown -> Unknown, Positive+Unknown -> Positive, Negative+Unknown -> Negative) and the delivered coding 1=Positive 2=Negative 3=VUS 4=Unknown. FROM THE SME (2026-08-07): VUS+Unknown -> Unknown/Not documented, and Negative+VUS -> Negative on the reasoning that a definite negative call is knowledge and a VUS is not, the same way Negative+Unknown resolves Negative. STILL DECIDED IN CODE, not ruled on, and both still change delivered values: (a) Positive+VUS on one gene resolves Positive; (b) the CROSS-GENE rollup, which has no counterpart in the spec at all and currently ranks VUS ABOVE Negative - so a patient with one VUS gene and the rest Negative delivers VUS. Note the tension worth putting to the SME: their reasoning for Negative+VUS within a gene, extended across genes, would rank Negative above VUS and flip (b). They are different questions - contradictory readings of one gene, versus different genes each read cleanly - so this was NOT extended unilaterally. Recorded from an SME consultation relayed by the data product owner on 2026-08-07; the SME is not named in the relay, so name them here before this is used as a release record. FULLY RESOLVED 2026-08-07. The last two pieces are ruled and implemented. (a) Positive+VUS -> Positive: a pathogenic variant on the same gene on the same date outranks an uncertain one, consistent with the spec's own Positive+Unknown -> Positive. (b) The CROSS-GENE order is reversed, from Positive > VUS > Negative to Positive > NEGATIVE > VUS. The old order let one VUS gene outrank several clean negatives, which contradicted the within-gene ruling that Negative+VUS resolves to Negative. The two levels now agree, and the order also matches the only ordering the spec ever states - its parsing cascade Positive > Negative > VUS. CHANGES DELIVERED VALUES: any patient whose only non-negative finding is a VUS moves from HRR_INDEX='VUS' to 'Negative'. The internal rank now equals the delivered coding (1=Positive, 2=Negative, 3=VUS, 4=Unknown), so the two can no longer drift apart. V2c is unaffected: BRCA genes are a subset of every HRR panel and both calls share one winning date, so BRCA-positive still implies HRR-positive by construction regardless of how the ranks are ordered.
- **Evidence:** WHAT THE SPEC ACTUALLY SAYS (5B.ClinChars HRR_INDEX and BRCA_INDEX rows, read from the spec; the BRCA row is word-for-word the HRR row with BIOMARKERNAME='BRCA'): status parsed from one BIOMARKERSTATUS string as Positive, else 'Mutation Negative' -> Negative, else VUS, else Unknown/Not documented; window [-30,+7]; multiple tests in the period -> report closest to index date, prioritising tests PRIOR to index when equidistant; multiple tests ON THE SAME DATE -> exactly four rules: Positive/Negative = Unknown/Not documented, Positive/Negative/Unknown = Unknown/Not documented, Positive/Unknown = Positive, Negative/Unknown = Negative. VUS DOES NOT APPEAR IN THE SAME-DATE LIST AT ALL, so Positive/VUS, Negative/VUS and VUS/Unknown are all undefined by the spec. The spec also has no cross-gene rollup, because it assumes BIOMARKERNAME='HRR' holds one aggregated value per test - the source has one row per gene and no row named 'HRR'. CORRECTION: an earlier version of this row listed 'Positive/VUS -> Positive' as one of the spec's four same-date rules. That was a misreading; rule 2 is Positive/Negative/Unknown -> Unknown. The practical effect is that the code fills three VUS gaps, not one. WHY THE CODE DEVIATES ON THE ROLLUP: the previous implementation collapsed across genes FIRST and then applied the same-date Positive+Negative rule, so on a 19-gene report a BRCA2-positive patient with 18 negative genes scored 'Unknown' and essentially every true positive was lost. Preflight D5b puts flatiron_all positives at 16011 and BRCA-only at 5715; V2c asserts BRCA-positive implies HRR-positive, true under any panel and false under the old rollup. TEXT CORRECTED 2026-08-07. This field previously described the SUPERSEDED algorithm on two counts: it said each gene used 'that gene's own winning test date' (it is now one shared date), and it listed 'Negative+VUS -> VUS' and 'VUS+Unknown -> VUS', both of which the SME reversed and the code no longer does. The row's own rationale already carried the corrected rulings, so the register was internally inconsistent - the worst possible state for a control document, because either field could be read as authoritative.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q30 - ECOG (treated cohorts)

- **Spec reference:** 5B.ClinChars r47
- **Spec says:** t_enh_prostate_bsln_ecog has duplicates on patientid+linenumber+linestartdate; the spec gives no tie rule. Two things need deciding: which DATE wins, and which VALUE wins on that date.
- **We do:** Cohorts 3-7 take the baseline-ECOG record CLOSEST TO INDEX, ties to the earlier record, then the highest value on that date.
- **Decision:** Closest to index, then the highest value on that date.
- **Why:** Resolving the date before the value is not optional: min(ecogdate) and max(ecogvalue) in one summarise can take the date from one record and the value from another. Which date should win is genuinely open - EARLIEST is what the code does; CLOSEST-TO-LINE-START is arguably the better clinical reading of a baseline measurement. MAX(value) is conservative (reports the worse performance status) but the spec does not say so. RESOLVED 2026-08-07. Cohorts 3-7 now use the same date rule as cohorts 1-2, so all seven share one shape. Worth recording WHY the row existed: the spec states a date rule only for cohorts 1-2; for 3-7 it gives just linenumber + linestartdate and assumes that match is unique. The baseline-ECOG table has duplicates on that key, so the build had to invent something. It previously took the earliest record; it now takes the closest to index, ties to the earlier - which is the tie-break the spec does state for cohorts 1-2.
- **Evidence:** Preflight B11 lists the duplicate keys and their values
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q31 - STAGE / STAGEN

- **Spec reference:** 5A.Demos r12/r13
- **Spec says:** The Values list gives five stages; the spec gives no code for a patient with no group stage recorded.
- **We do:** Residual code 99, per the fallthrough convention.
- **Decision:** 99 is the fallthrough code.
- **Why:** Follows the same pattern as ECOG and GLEASON, where the spec DOES supply an explicit unknown level. Chosen for consistency, not from the sheet. CONVENTION SET 2026-08-07 by the data product owner: 99 is the fallthrough sentinel for a category the spec's Values list does not code. Applied to every build-invented residual: AGEGR1N, REGION1N, STAGEN, PRACTICN and COHORTUN all now use 99, where before they used 8, 7, 6, 99 and 99. An earlier attempt went the other way - it made PRACTICN 4 on a 'next integer after the spec's last code' rule inferred from what four of the variables happened to do. That was wrong: 99 is a recognisable sentinel and a low integer sitting beside real codes is not. Reverted the same day. NOT changed: RACEN 5, ETHN 3, GLEASONN 3 and ECOGN 6/7 are all codes the spec's own Values lists provide, not residuals this build invented. RESOLVED 2026-08-07: 99 confirmed as the fallthrough code, applied to every build-invented residual - AGEGR1N, REGION1N, STAGEN, PRACTICN and COHORTUN.
- **Evidence:** Sheet reference corrected 2026-08-07: STAGE/STAGEN are on 5A.Demos rows 12-13, not 5B.ClinChars - the register had mis-cited them. Reading the sheet also confirms the prefix cascade is ordered IV, III, II, I, 0, which the code follows; testing 'I%' before 'II%' would misclassify every stage II and III patient as stage I.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row
- **Not an independent decision.** This is Q50's residual convention applied to STAGEN. The row stays because someone looking up STAGE or STAGEN needs to find it, but the rule it applies is stated once, in Q50.

### Q32 - PRACTIC / PRACTICN

- **Spec reference:** 5A.Demos r16/r17
- **Spec says:** The Values list gives three practice types; the spec gives no code for a patient with no practice record.
- **We do:** Residual code 99, per the fallthrough convention.
- **Decision:** 99 is the fallthrough code.
- **Why:** 99 is the site convention for missing in a small code list, and keeping it out of the 1-3 range means it cannot be mistaken for a real category in an ordinal analysis. Not stated in the sheet. CONVENTION SET 2026-08-07 by the data product owner: 99 is the fallthrough sentinel for a category the spec's Values list does not code. Applied to every build-invented residual: AGEGR1N, REGION1N, STAGEN, PRACTICN and COHORTUN all now use 99, where before they used 8, 7, 6, 99 and 99. An earlier attempt went the other way - it made PRACTICN 4 on a 'next integer after the spec's last code' rule inferred from what four of the variables happened to do. That was wrong: 99 is a recognisable sentinel and a low integer sitting beside real codes is not. Reverted the same day. NOT changed: RACEN 5, ETHN 3, GLEASONN 3 and ECOGN 6/7 are all codes the spec's own Values lists provide, not residuals this build invented. RESOLVED 2026-08-07: 99 confirmed as the fallthrough code, applied to every build-invented residual - AGEGR1N, REGION1N, STAGEN, PRACTICN and COHORTUN.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row
- **Not an independent decision.** This is Q50's residual convention applied to PRACTICN. Same as Q31: kept for lookup, ruled once in Q50.

### Q33 - FUED / DTHDT / PSMA_SCANDT

- **Spec reference:** 6.Outcomes / 5B.ClinChars r94-r95
- **Spec says:** May a follow-up or event date lie after MAXINDEX? The index date is bounded to [MININDEX, MAXINDEX]; nothing bounds the follow-up dates.
- **We do:** Not bounded. Dates are carried as recorded and may exceed 2026-04-30
- **Decision:** Yes. Follow-up and event dates may exceed MAXINDEX.
- **Why:** Truncating follow-up at MAXINDEX would bias OS and PFS downward for late-index patients, which is worse than carrying a date past the nominal cut. But the quantity has to be on the record before that is accepted, which is what X01/X02/X06 are for. RESOLVED 2026-08-07. MAXINDEX bounds when a patient may ENTER the study, not how long they are followed; capping follow-up at it would truncate survival for everyone indexed late and bias OS downward. No code change. V4's X01, X02 and X06 already count how many FUED, DTHDT and PSMA_SCANDT values exceed it - record those with the release.
- **Evidence:** Output validation V4 X01/X02/X06 count how many actually do
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q34 - PFSDT / PFS

- **Spec reference:** 6.Outcomes
- **Spec says:** Progression can be recorded after the patient has died. The spec defines no chronology repair, so PFSDT is taken as recorded and can exceed DTHDT - which makes PFS longer than OS for the same patient in the delivered ADS.
- **We do:** PFSDT is the FIRST qualifying PROGRESSIONDATE at or after INDEXDT+14, taken verbatim. No clamping to DTHDT, no exclusion of impossible rows, no flag. PFS is then (PFSDT - INDEXDT + 1)/30.4375 with no upper bound.
- **Decision:** No action. Treat progression-after-death as a documented data limitation.
- **Why:** RESOLVED as specified. X03 and X03b stay, not as gates but to QUANTIFY the limitation for the release record - which is what 'treat as limitation' requires someone to do. Note X03/X03b measure DELIVERED PFSDT > DTHDT, which is not the same population as the 896 source rows: death-date imputation moves the boundary. Both numbers are worth recording and neither substitutes for the other.
- **Evidence:** SIZED AT SOURCE 2026-08-07. Across 231,261 qualifying progression rows on 70,538 patients: progression after the LAST CLINIC NOTE = 0 rows, so that half of the concern closes outright. Progression after the END OF THE DEATH MONTH = 896 rows. That bound is deliberately generous - DateOfDeath is only month/year granular - so all 896 post-date the last day the patient could have died and none is a granularity artefact. IMPORTANT: 896 is a count of SOURCE ROWS, not of delivered patients, and it OVERSTATES the delivered impact. PFSDT takes the FIRST qualifying progression, so a patient who has a valid early progression and also an impossible late one is unaffected - the early one wins. Only patients whose WINNING PFSDT falls after death are actually wrong in the ADS. That delivered number is already measured, by check X03 'pfsdt after dthdt' in section V4 of validation/03_output_validation_databricks.sql. X03 has never been run, because no live build has been executed from this branch. Source: validation/'Query Results .txt' (on main), run 2026-08-07. ANSWERED BY THE SPEC 2026-08-07, found in the spec text. 3.Data Prep Section C item 7 raises this exact issue - 'X patients had death date before progression date' - cites Flatiron's own guidance that a small number of records carry structured activity after DateofDeath through data entry error, and rules: **'No action - treat as limitation.'** So the build's behaviour is the SPECIFIED behaviour, not an unresolved gap. This row asked for an SME ruling that the spec had already given on a page I had read but not connected to it.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q35 - PSA50_6MO / PSAL6MO / PSA50_12MO / PSAL12MO

- **Spec reference:** 6.Outcomes
- **Spec says:** These are built as case_when(<responded> ~ 'Y', TRUE ~ 'N'), so a patient with NO post-index PSA - or no baseline PSA - reads 'N', not missing.
- **We do:** Emitted verbatim as specified: 'N' covers both 'measured, did not respond' and 'never measured'
- **Decision:** Keep 'N'. A missing PSA scores N, as the spec's 'Else N' states.
- **Why:** This is what the spec's Y/N formulation says, and the point of an RDAP is to transform the source into the specified format rather than to improve on it. But a response rate computed off this column counts unmeasured patients as non-responders, so the size of X08/X09 decides whether a third level ('Not evaluable') is needed. RESOLVED 2026-08-07: owner ruled to follow the spec verbatim. CONSEQUENCE TO CARRY FORWARD, because it does not go away by being approved: 'N' merges 'measured, did not respond' with 'never measured', so any response RATE computed off these columns has an inflated denominator and is biased LOW. Anyone reporting PSA response should compute the denominator from PSA6MO/PSA12MO being non-null rather than from a count of rows. Check X08/X09 in V4 sizes the affected population - record it with the release.
- **Evidence:** Output validation V4 X08/X09 count how many 'N' values have no PSA behind them
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q36 - VIS120

- **Spec reference:** 6.Outcomes
- **Spec says:** VIS120 is ifelse(<visit 120+ days after the index line ended>, 1, 0), so a patient whose index line has no end date scores 0 rather than missing.
- **We do:** Emitted as 0. Same shape as Q35
- **Decision:** Keep 0. A missing index-line end date scores 0, matching Q35's shape.
- **Why:** Identical reasoning to Q35, and identical risk: 0 means both 'no late visit' and 'we do not know when treatment ended'. The count decides whether it needs a missing level. RESOLVED 2026-08-07: owner ruled to follow the spec verbatim, consistent with Q35. Same caveat: 0 merges 'no late visit' with 'index line never ended', so VIS120 is not a clean denominator. Check X10 in V4 counts the patients whose index line has no end date.
- **Evidence:** Output validation V4 X10 counts the 0s that have no index-line end date behind them
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q37 - HRR_INDEX / BRCA_INDEX

- **Spec reference:** 5B.ClinChars r70/r74
- **Spec says:** Which test date wins when a patient has more than one biomarker report inside the [-30,+7] window: the closest report as a whole, or the closest test PER GENE?
- **We do:** The biomarker test CLOSEST TO INDEX inside the [-30,+7] window, chosen over ALL biomarker tests - every gene, every test type - giving ONE winning date per patient that the HRR and BRCA calls share. Equidistant before/after resolves to the earlier (pre-index) test, per the spec. Status is then resolved within each gene on that date and rolled up across genes (Q29).
- **Decision:** One winning date per patient: the biomarker test closest to index, over all biomarker tests. Applies identically to HRR_INDEX and BRCA_INDEX. Test type is not a selection criterion.
- **Why:** RESOLVED. This restores the spec's closest-to-index rule but applies it to a single pool of all biomarker tests rather than per gene, which is the reading that matches the spec's own assumption that BIOMARKERNAME='HRR' holds one aggregated value per test. Cost, and it should be understood before release: a gene tested only on a NON-winning report contributes nothing, so a real positive on an earlier report is discarded - which is what happens to BRCA in the example above. Interacts with Q20: bounded to [-30,+7], 'closest' ranges over a 37-day window only. Recorded from an SME consultation relayed by the data product owner on 2026-08-07; the SME is not named in the relay, so name them here before this is used as a release record. RESIDUAL RISK noted by review 2026-08-07, documented rather than changed: the shared winning date is chosen over ALL biomarker tests BEFORE the frozen-panel gene filter is applied, so a future out-of-panel gene could move the winning date and shift HRR/BRCA status without itself being counted. That is what 'earliest/closest amongst ALL biomarker tests' was ruled to mean, so it is permitted by the decision rather than contrary to it, and it cannot bite on 2026m06 where the frozen 19 are exactly the genes present. Revisit if a cut adds a gene.
- **Evidence:** SME worked example, 2026-08-07: index 7 Feb, ATM Negative on 30 Jan, BRCA Positive on 25 Jan -> the ATM reading is taken. 30 Jan is 8 days from index, 25 Jan is 13, so this is CLOSEST-to-index selection over a single pool. HRR_INDEX is therefore Negative; BRCA has no result on 30 Jan so BRCA_INDEX is Unknown/Not documented, not Positive. The relay first described the rule as 'earliest amongst all biomarker tests', which would have selected BRCA on 25 Jan and returned HRR=Positive - the opposite answer. The worked example was taken as decisive and the owner confirmed it, including that it applies to BRCA as well. Sharing ONE date across both calls is what preserves V2c: resolving the date separately per panel is what used to give HRR=Negative with BRCA=Positive on exactly this shape. CORRECTION AND WHO MADE IT: the rule was first implemented as 'earliest', following the wording of the relay, and committed that way. Onkar Kshirsagar corrected it on 2026-08-07 by supplying the SME's worked example above, which selects the LATER of the two tests and so is closest-to-index, not earliest, and confirmed that the same rule applies to BRCA_INDEX. The corrected rule is what ships; the superseded 'earliest' implementation never left this branch.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q38 - Index date / cohort membership

- **Spec reference:** 4.StudyPop section B
- **Spec says:** A treated cohort's index line can START BEFORE the mHSPC/mCRPC milestone it is joined to. The cohort join matches on patientid only and enforces no chronology.
- **We do:** Allowed. Both dates must fall inside [MININDEX, MAXINDEX], but the line start is not required to be at or after the milestone.
- **Decision:** Accept. The index line may start before the milestone defining the cohort; no chronology is enforced.
- **Why:** Real and concentrated in the two L1+ cohorts. For 10,170 patients the index treatment predates the mHSPC/mCRPC classification it is supposed to follow, so 'L1+ treated mCRPC' includes patients whose first line began while they were still classified otherwise. Whether that is intended is a study-design question, not a coding one: requiring line start >= milestone would remove 6.1% of cohort 3 and 10.5% of cohort 4. Needs an SME ruling with those numbers in front of them. RESOLVED 2026-08-07: accept and document. 10,170 patients are affected - 4,855 in cohort 3 (6.1%) and 5,315 in cohort 4 (10.5%). Cohorts 5-7 are zero, which is the expected shape since later lines start later. The defensible reading is that real-world coding of the mHSPC/mCRPC milestone lags the clinical reality, so a first line legitimately predates the recorded classification date. Requiring chronology would have removed a tenth of cohort 4. WHAT THIS DOES NOT BREAK: survival cannot go negative. For cohorts 3-7 the index date IS the line start, and OS is measured from the index date - the milestone does not appear in the formula. V1's c07 gate already fails the run on any negative OS/TTNT/PFS/FUDUR, so this is checked rather than assumed. WHAT IT DOES MEAN, and what must travel with the release: 'L1+ treated mCRPC' includes patients whose first line began while they were still classified otherwise. Anyone interpreting the treated cohorts as 'first line AFTER becoming mCRPC' would be wrong for 10.5% of cohort 4. Record the two percentages alongside the cohort counts.
- **Evidence:** SIZED 2026-08-07, per delivered cohort. Cohort 3 (L1+ mHSPC): 4,855 of 79,051 patients = 6.1%. Cohort 4 (L1+ mCRPC): 5,315 of 50,502 = 10.5%. Cohorts 5, 6 and 7: ZERO, which is expected since later lines start later. So 10,170 patients are indexed on a line of therapy that began BEFORE the milestone defining the cohort they are in. Source: validation/'Query Results .txt' (on main), run 2026-08-07.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q39 - CSF_FU

- **Spec reference:** 5B.ClinChars r55-r56
- **Spec says:** The follow-up window for the growth-factor flag has no upper bound: any qualifying record after the index date counts, with no FUED or MAXINDEX limit.
- **We do:** CSF_FU counts qualifying records in (index_date, FUED]. The window is bounded at the patient's own follow-up end.
- **Decision:** Bound the follow-up window at FUED.
- **Why:** A record years after the index date, and after follow-up has ended, still sets the flag. The spec names the period as post-index without stating an end. If the intent is 'during follow-up', the bound should be FUED; if it is 'within the study period', MAXINDEX. RESOLVED 2026-08-07 and IMPLEMENTED. CSF_FU counted any qualifying record after index with no upper bound, so a growth-factor order years after the patient left follow-up still set the flag - which no other follow-up variable does. Now bounded at the patient's own FUED. This lowers CSF_FU for anyone with a late record, so it changes delivered values.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q40 - FU_ENDDT_preliminary / FUED

- **Spec reference:** 5B.ClinChars r88-r89
- **Spec says:** 202603 derived follow-up end partly from the alpha/beta-emitter and Provenge tables. Those are not in the 202606 definition and are not read here.
- **We do:** Excluded, per the 202606 sheet
- **Decision:** The 202606 sheet is authoritative. Follow-up end excludes the alpha/beta-emitter and Provenge tables.
- **Why:** The 202606 row lists its own sources and those two are not among them, so dropping them is the faithful reading. It does mean a patient whose last recorded contact was one of those therapies now has an earlier FUED, which shortens OS and PFS follow-up. Confirm the omission is intended rather than an editing slip. RESOLVED 2026-08-07. FU_ENDDT_preliminary uses visit, telemedicine, line-of-therapy end and oral end only, exactly as 5B.ClinChars row 89 lists. No code change. CONSEQUENCE WORTH CARRYING: this can SHORTEN follow-up relative to 202603 for any patient whose last recorded activity was an alpha/beta-emitter or Provenge administration, so OS and FUDUR are not directly comparable across the two cuts for those patients.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q41 - PFSDT / PFSFL

- **Spec reference:** 6.Outcomes rwPFS
- **Spec says:** IsPseudoProgressionMentioned is not used. It neither qualifies a progression nor vetoes one.
- **We do:** Omitted from the qualifying-evidence list. A row flagged as pseudo-progression still counts if any OTHER evidence flag is true.
- **Decision:** Closed. The build already does what the spec says.
- **Why:** Pseudo-progression is radiographic change that is not true progression, so a row carrying that flag is the one case where the other evidence flags may be misleading. Treating it as a veto is the alternative reading. The spec lists the qualifying flags and does not mention it either way.
- **Evidence:** CLOSED 2026-08-07 on the spec. 6.Outcomes PFSFL reads 'if patient has any progression flag OTHER THAN IsPseudoProgressionMentioned=1 associated with a PROGRESSIONDATE occurring after INDEXDT+14'. The build ORs the other six evidence flags and omits IsPseudoProgressionMentioned entirely, so a row flagged as pseudo-progression qualifies only if some other evidence flag is also true. That is the spec's wording exactly. No ambiguity to rule on.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q42 - TTNT / TTNTFL

- **Spec reference:** 6.Outcomes TTNT
- **Spec says:** The next-treatment date is taken from the next line's start date with no explicit requirement that it fall after the index date.
- **We do:** next_trt_dt = the next line's start date, unconditioned
- **Decision:** No change. The condition is satisfied by the data.
- **Why:** Closed on evidence, not judgement. Note this is a statement about 2026m06, not a guarantee: if a future cut introduces two lines starting the same day, the preflight gate in Q24 catches it before the build writes anything.
- **Evidence:** CLOSED 2026-08-07. Counting consecutive line pairs within a patient and setting where the next line starts on or before the current one: NO ROWS RETURNED, in either mHSPC or mCRPC. The next-treatment date is therefore always strictly after the index date, so the missing explicit condition costs nothing on this data cut. Source: validation/'Query Results .txt' (on main), run 2026-08-07.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** SOURCE-SIDE, 2026-08-08. Q42b reads the source tables and rebuilds the cohort definition, so it PREDICTS what the build must produce rather than confirming what it did. That is the right instrument here, because the question is one about source chronology. What it does not do is prove the delivered TTNT column is correct - qc/05 and the V-gates do that, and neither has run.
- **Reopened 2026-08-08.** The closing evidence counted consecutive lines WITHIN a setting and found none out of order. Cohort 3 does not use a within-setting pair: its next treatment is the earlier of mHSPC LOT2 and mCRPC LOT1, so the chronology that matters there is mHSPC LOT1 against mCRPC LOT1 - a CROSS-SETTING comparison the query never made. The formula is not in doubt; the closure is. Run the cross-setting pair and this row can close properly. The query is now written: `validation/04_open_question_queries.sql` **Q42b**. It rebuilds the delivered cohort 3 - mHSPC line 1 with both the line start and the mHSPC milestone inside the index window - joins each patient's first mCRPC line, and counts those starting on or before the index date. `n_le = 0` closes the row. `n_before` and `n_same` are reported apart, because a same-day start gives a TTNT of one day, which is degenerate rather than impossible.
- **Closed on evidence 2026-08-08, Q42b run on 2026m06.** `n_cohort3` 79,051; `n_with_mcrpc_l1` 21,887; `n_le` 0; `n_before` 0; `n_same` 0; `worst_gap_days` 28. So of the 79,051 patients in the delivered L1+ treated mHSPC cohort, 21,887 also have a first mCRPC line - the comparison is not vacuous - and NONE of them starts it on or before their index date. The closest any comes is 28 days after, which puts the smallest possible cohort-3 TTNT at 29/30.4375 = 0.95 months. Both limbs of cohort 3's `min(mHSPC LOT2, mCRPC LOT1)` are now proven strictly after index: the within-setting limb by the original Q42 query, the cross-setting limb by this one.
- **The query reproduced the cohort exactly.** `n_cohort3` = 79,051 is the same figure Q38's independent sizing reports for cohort 3, which is a check on the query as well as on the answer - a rebuild that had the population wrong would not land on that number.

### Q43 - Build identification

- **Spec reference:** n/a - run governance
- **Spec says:** Should every run carry a mandatory unique build ID, applied to all 42 stage tables, the output table and the manifest, with fail-if-exists rather than replace?
- **We do:** No build ID. Stage and output names are stable and written with replace=TRUE. The constant 'uat' tag was removed because a constant tag isolates nothing, and the staging copy was removed too (Q27), so a re-run replaces the delivered table directly.
- **Decision:** Keep stable table names written with replace=TRUE. No per-run build ID.
- **Why:** NOT IMPLEMENTED - this reverses a decision already taken, so it is recorded rather than actioned. The argument for it is sound: QC evidence should refer to the exact table being published, and replace=TRUE means it may not. The argument against is that it puts a suffix on 44 objects for a risk that a disciplined single-threaded run process also removes. Needs an owner's ruling, not a code change made on a reviewer's say-so. RECLASSIFIED from 'no' to 'values': with stable names and replace=TRUE, a re-run or an overlapping run can change every value in the table QC already reviewed. The reviewer also reframes it, fairly - a mandatory unique ID is not restoring the constant tag, it is replacing an ineffective constant with real identity. Still an owner's call, not a code change made unilaterally. RESOLVED 2026-08-07: current behaviour confirmed. Also an accept-the-risk decision. RESIDUAL RISK: a rerun silently overwrites whatever QC last reviewed, and nothing in the output records that it happened - program_version is a hand-maintained label that cannot tell two runs of the same code apart, and RUN_MANIFEST is regenerated by each run. Two builds also cannot coexist for comparison. This does NOT reinstate the constant 'uat' tag that was removed earlier: that was removed correctly, because a constant tag isolates nothing. The question here was a UNIQUE per-run ID, which is a different mechanism, and it is declined for now. WHAT WOULD CHANGE THE ANSWER: a formal QC sign-off step. The moment someone signs off on a specific table, that table needs to be immutable or the signature means nothing. Revisit before any release that is reviewed rather than exploratory.
- **Evidence:** External review (2026-08) recommends a mandatory unique ID with no default. The concrete risk: a re-run silently replaces the exact table QC reviewed, and two overlapping runs by one analyst in one schema interleave their stages. Different personal schemas separate USERS, not RUNS.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q44 - HRR_INDEX gene inventory

- **Spec reference:** 5B.ClinChars r70/r74
- **Spec says:** Should the governed build freeze the exact 19 approved gene symbols instead of using every gene present in the biomarker table?
- **We do:** flatiron_all names the 19 approved gene symbols explicitly. report_excluded_genes() announces any gene present in the table but absent from the frozen list.
- **Decision:** Freeze the 19 approved symbols; do not track the table's contents.
- **Why:** NOT IMPLEMENTED - Q05 decided flatiron_all deliberately, on the grounds that a list cannot go stale or miss an alias. Freezing inverts that: it cannot silently widen, but it CAN silently narrow if the source renames a symbol, and it needs maintaining. The review's point stands that a self-changing case definition is unusual in a governed product. This is the same decision as Q05 seen from the other side and should be settled with Q05 and Q28 together. RESOLVED 2026-08-07 and IMPLEMENTED. The case definition is now the study's rather than Flatiron's. The signal that was missing comes for free: report_excluded_genes() already lists genes present in the biomarker table but absent from the panel, and with the list frozen it will announce any gene a future cut adds - where previously flatiron_all meant that function printed 'no genes excluded' by construction and a new gene entered HRR silently. Delivered values are unchanged for 2026m06, since the frozen 19 are exactly the 19 the table currently holds.
- **Evidence:** Preflight B7 reports unexpected genes as WARN; B7b names drift in both directions. Neither blocks publication.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q45 - FUED

- **Spec reference:** 5B.ClinChars r91 (FUED)
- **Spec says:** The FUED definition ends 'If INDEXDT<FUED, then FUED=INDEXDT'. Taken literally that clamps FUED down to the index date for every patient who HAS follow-up, which would zero out OS, TTNT and PFS for the whole cohort. The condition is inverted.
- **We do:** FUED = max(FU_ENDDT, INDEXDT). Coded as CASE WHEN fu_enddt > index_date THEN fu_enddt ELSE index_date END, i.e. the sensible reading 'if FUED < INDEXDT then FUED = INDEXDT'.
- **Decision:** Build's reading confirmed; correct the spec, not the code.
- **Why:** Same class as Q07 and Q18: a reading slip in the spec where the data and the surrounding logic make the intent unambiguous. Implemented to intent, not to the letter. Flagged so the spec is corrected rather than silently worked around, and so nobody re-reads the row later and 'fixes' the code to match it. APPROVED 2026-08-07 as part of the nine-item spec errata block (this file). The build's reading is confirmed correct and the SPEC is what gets corrected; no code change. Approved as a block because in each case the literal spec text is self-evidently not the intent - most starkly Q45, which taken literally clamps FUED to the index date for every patient with follow-up and would zero OS, TTNT, PFS and FUDUR across the study.
- **Evidence:** Read from the spec 2026-08-07. The rest of the FUED row is implemented verbatim: FUED = FU_ENDDT_preliminary; if FU_ENDDT_preliminary > DEATH_DT_preliminary, then FUED = max line-of-therapy end date when the death month and year match it, else DEATH_DT_preliminary. Only the final clamp is inverted. The literal reading is self-evidently not intended - it would make FUED equal INDEXDT for essentially every patient and every time-to-event variable would be 1/30.4375 months.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q46 - PRIOR_DOCITAXEL / PRIOR_ABIRATERONE

- **Spec reference:** 5C.TreatVars r35-r42
- **Spec says:** Two prior-therapy VARIABLE NAMES are malformed in the spec. Row 40 names the docetaxel flag PRIOR_DOCITAXEL - 'DOCITAXEL', misspelt - and its label reads 'Docitaxel received prior to index'. Row 41 names the abiraterone flag PRIOR+ABIRATERONE, with a PLUS SIGN where every other variable has an underscore. Column names are part of the delivered contract, so both need a ruling rather than a silent choice.
- **We do:** Delivered as PRIOR_DOCETAXEL and PRIOR_ABIRATERONE. Both spec spellings corrected.
- **Decision:** Correct to PRIOR_DOCETAXEL and PRIOR_ABIRATERONE.
- **Why:** The two are treated differently on purpose, and that asymmetry is the thing to confirm. A misspelt-but-legal name is still a name a downstream consumer can code against, so changing it would break them; an illegal name cannot be delivered at all, so it had to be changed. If the study team would rather PRIOR_DOCITAXEL were corrected to PRIOR_DOCETAXEL, say so before release - it is a one-line change here and in the column contract, but it is not reversible once consumers are reading the table. RESOLVED 2026-08-07: correct all three to clean names. Delivered as PRIOR_DOCETAXEL, PRIOR_ABIRATERONE and LOT4CATN_MCRPC. This DIVERGES from the spec's column list on purpose - the spec is what gets corrected (errata E13). The asymmetry that used to exist here is gone: the build no longer preserves one slip while fixing another. Note the consequence: any consumer already coding against PRIOR_DOCITAXEL or LOT4CATN must change, which is why this was worth ruling on before release rather than after.
- **Evidence:** Read from the spec 2026-08-07. Every other variable on the sheet uses underscores, and '+' is not a legal character in an unquoted column name in Spark SQL or SAS, so the plus is a typing slip rather than an intended name. The misspelling in DOCITAXEL is legal, so it was preserved on the principle that the spec names the deliverable.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row
- **Duplicate of Q08, marked 2026-08-08.** Same two variable names, same correction. Q46 carries the fuller account of what the spec prints; Q08 is the row cited first in code. Read Q08 and treat this as its long form.

### Q47 - OS

- **Spec reference:** 6.Outcomes r4 (OS)
- **Spec says:** The OS formula reads OS=(death_dt - INDEXDT + 1)/30.4375. There is no variable called death_dt. 5B.ClinChars defines DEATH_DT_preliminary and DTHDT, and the two differ: DTHDT promotes the date to the last day of the month when the death month and year match both FUED and max_lotend_dt. Which one OS should use is not stated.
- **We do:** OS uses DTHDT, the delivered Date of Death.
- **Decision:** Build's reading confirmed; correct the spec, not the code.
- **Why:** Low risk but not zero. The two dates differ only for patients whose death month and year match both FUED and the last line-of-therapy end date; for those, DTHDT is the last day of the month and DEATH_DT_preliminary is the 15th, so OS differs by up to about half a month. Everyone else is unaffected. DTHDT is the better reading and is what ships; flagged so the choice is on the record rather than assumed. APPROVED 2026-08-07 as part of the nine-item spec errata block (this file). The build's reading is confirmed correct and the SPEC is what gets corrected; no code change. Approved as a block because in each case the literal spec text is self-evidently not the intent - most starkly Q45, which taken literally clamps FUED to the index date for every patient with follow-up and would zero OS, TTNT, PFS and FUDUR across the study.
- **Evidence:** Read from the spec 2026-08-07. DTHDT is the variable actually delivered as 'Date of Death'; DEATH_DT_preliminary is explicitly named 'preliminary' and exists only as an intermediate. OS sits directly beneath DTHFL on the same sheet, and DTHFL is defined from DTHDT, so the surrounding rows read as though DTHDT is meant.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q48 - COHORT

- **Spec reference:** 4.StudyPop r11 (COHORT)
- **Spec says:** The COHORT row gives two different label sets in two adjacent columns. The Values column lists 'Overall - mHSPC, Overall - mCRPC, 1L - mHSPC, 1L - mCRPC, 2L - mCRPC, 3L - mCRPC, 4L - mCRPC'. The Definition column assigns COHORT='Overall mHSPC', 'L1+ treated mHSPC', 'L1+ treated mCRPC', 'L2+ treated mCRPC' and so on. The two disagree on every treated cohort and on the dash in the Overall ones.
- **We do:** The Definition form ships: 'Overall mHSPC', 'Overall mCRPC', 'L1+ treated mHSPC', 'L1+ treated mCRPC', 'L2+ treated mCRPC', 'L3+ treated mCRPC', 'L4+ treated mCRPC'.
- **Decision:** Ship the Definition-column form: 'L1+ treated mCRPC' etc.
- **Why:** COHORT is a delivered character column that downstream code will filter on, so the exact string matters even though the cohort membership does not change. The Definition form was chosen because it is the assigning clause rather than a summary of it. If any downstream table or TLF already keys on '1L - mHSPC', this needs to change before release - it is a pure relabel, but a breaking one once consumers exist. RESOLVED 2026-08-07. The Definition column is the clause that performs the assignment, so its labels are the delivered strings. No code change - the build already emits them. Cohort membership and COHORTN are identical under either reading, so only the character column was ever at stake.
- **Evidence:** Read from the spec 2026-08-07. The Definition column is the one that actually performs the assignment, and 6.Outcomes refers to the cohorts by the same '[1L mHSPC cohort]' style shorthand without settling the literal string either. COHORTN 1-7 is unambiguous and identical under both readings, so only the character column is affected.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q49 - CSD

- **Spec reference:** 5C.TreatVars r23 (CSD)
- **Spec says:** The CSD row gives two incompatible instructions. Its prose says the regimen is 'Clinical Study Drug' in the DrugEpisode table. Its pseudo-code is index(LOT1_MCRPC,"CSD") and so on per cohort - a SAS substring search for the three letters CSD, against LINENAME from the LOT table. Flatiron spells the value out as 'Clinical Study Drug', which does not contain the substring 'CSD', so the pseudo-code as written matches nothing and CSD would be 0 for every patient. The two also name different source tables.
- **We do:** Matches on the spelled-out string: LINENAME LIKE '%clinical study drug%'. For the two Overall cohorts, any line in the cohort's setting; for the five treated cohorts, the index line's LOTn_<SETTING> value - which is the per-cohort structure the pseudo-code lays out.
- **Decision:** Build's reading confirmed; correct the spec, not the code.
- **Why:** Implemented to intent, like Q07 and Q45. Flagged because the deviation is not visible from the code alone: a reader checking the code against the pseudo-code would think it is wrong. The source-table discrepancy is the part still worth a ruling - the prose says DrugEpisode while the pseudo-code says LINENAME/LOTn from the LOT table, and the build follows the pseudo-code. For a line whose LOT-level LINENAME omits a study drug that appears on an individual drug episode, the two would disagree. APPROVED 2026-08-07 as part of the nine-item spec errata block (this file). The build's reading is confirmed correct and the SPEC is what gets corrected; no code change. Approved as a block because in each case the literal spec text is self-evidently not the intent - most starkly Q45, which taken literally clamps FUED to the index date for every patient with follow-up and would zero OS, TTNT, PFS and FUDUR across the study.
- **Evidence:** Read from the spec 2026-08-07. The prose names the real value and the pseudo-code names an abbreviation of it; 'CSD' is not a value that appears in LINENAME. Taking the pseudo-code literally produces an all-zero column, which is self-evidently not the intent. Note the same spelled-out string is what category 15 of LOTnCAT ('Clinical study drug-containing') matches on, and that category is verified against the spec, so the two are consistent with each other.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q50 - REGION1 / REGION1N / PRACTIC / PRACTICN

- **Spec reference:** 5A.Demos r14/r15, r20/r21
- **Spec says:** Both variables carry a residual level the spec's Values list does not contain. REGION1's list is Northeast/Midwest/South/West/Other region/Missing with REGION1N 1-6, but a state that is present and in none of those lists falls through. PRACTIC's list is the three practice types with PRACTICN 1-3, but the spec's final branch is an unconditional 'else then = Both academic and community', which would label a patient with NO practice record as both.
- **We do:** Residual code 99, per the fallthrough convention.
- **Decision:** 99 is the fallthrough code.
- **Why:** Same pattern as Q31 (STAGEN gets a 6 where the spec lists 1-5): the spec enumerates only clean values and gives no code for missing or unclassifiable. Three variables now do this and they do it INCONSISTENTLY - STAGEN uses the next integer (6), REGION1N uses the next integer (7), PRACTICN uses 99. That inconsistency is the thing to settle, not just whether a residual should exist. CONVENTION SET 2026-08-07 by the data product owner: 99 is the fallthrough sentinel for a category the spec's Values list does not code. Applied to every build-invented residual: AGEGR1N, REGION1N, STAGEN, PRACTICN and COHORTUN all now use 99, where before they used 8, 7, 6, 99 and 99. An earlier attempt went the other way - it made PRACTICN 4 on a 'next integer after the spec's last code' rule inferred from what four of the variables happened to do. That was wrong: 99 is a recognisable sentinel and a low integer sitting beside real codes is not. Reverted the same day. NOT changed: RACEN 5, ETHN 3, GLEASONN 3 and ECOGN 6/7 are all codes the spec's own Values lists provide, not residuals this build invented. RESOLVED 2026-08-07: 99 confirmed as the fallthrough code, applied to every build-invented residual - AGEGR1N, REGION1N, STAGEN, PRACTICN and COHORTUN.
- **Evidence:** Read from the spec 2026-08-07. The REGION1 residual is arguably required by the spec's own Additional Notes, which say 'Academic centers all set to unknown' - an Unknown the Values list then omits. The PRACTIC residual is a deliberate departure: taking the spec's unconditional else literally would assign 'Both academic and community' to a patient with no practice records at all.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q51 - SES

- **Spec reference:** 5A.Demos r22
- **Spec says:** The SES Values list is '1 - lowest SES, 2, 3, 4, 5 - highest SES, Null'. The spec asks for NULL when the socialdeterminantsofhealth index is absent. The build writes the literal string 'Missing' instead.
- **We do:** ses = sesindex2015_2019, passed through unchanged. An absent socialdeterminantsofhealth record now stays NULL, as the spec's Values list asks.
- **Decision:** Leave SES NULL when the source record is absent, per the spec.
- **Why:** RESOLVED and FIXED. The spec lists 'Null' as a value of SES in its own right alongside 1-5, so NULL is specified behaviour, not an omission. The previous code wrote the string 'Missing', which made 'WHERE ses IS NULL' return nothing and made SES the only column in the ADS encoding absence as text rather than NULL. Owner directed the fix on 2026-08-07. CONSEQUENCE TO EXPECT ON THE NEXT RUN: SES now carries NULLs where it previously carried a string, so the null sweep's n_ses will drop below n_rows. That is correct, not a regression - the sweep only flags a column as a defect when it is entirely empty or constant, so no waiver was needed. If SES does come back entirely null, that is a real data finding about t_socdetofhealth coverage and should be investigated rather than waived.
- **Evidence:** Read from the spec 2026-08-07. 'Null' is listed as a value in its own right alongside 1-5, so it is specified behaviour rather than an omission - unlike Q50, where the spec simply has no branch for the case.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q52 - INDEXDT (Overall cohorts) / MHSPCDD / MCRPCDD

- **Spec reference:** 4.StudyPop sB / 6.Outcomes r2 (INDEXDT, cohorts 1-2)
- **Spec says:** The milestone dates that index the two Overall cohorts are not always day-granular. t_enh_prostate carries hspcdategranularity DAY 701 / MONTH 197 / YEAR 155 - about 15% of HSPCDate values are year-level. crpcdate is DAY 381 / MONTH 7 / YEAR 2 and metastaticdiagnosisdate is DAY 590 / MONTH 49 / YEAR 11. INDEXDT for cohort 1 is max(MetastaticDiagnosisDate, HSPCDate) and for cohort 2 max(MetastaticDiagnosisDate, CRPCDate), so a year-level component can become the index date - but only when it is the LATER of the two, which the profile cannot tell us.
- **We do:** The milestone date is used as INDEXDT verbatim for cohorts 1-2, whatever its granularity. No granularity column is carried into the ADS.
- **Decision:** Accept the index-date granularity and record it with the release.
- **Why:** Narrower than first stated, and now about the Overall cohorts rather than the treated ones. A year-granular HSPCDate almost certainly lands on 1 January, so where it is the later of the two components it sets an index date that can be up to a year early, and everything anchored on index inherits that - OS, FUDUR, and the [-30,+7] biomarker and ECOG windows. Whether it actually propagates depends on which component wins the max(), which needs the query in validation/04_open_question_queries.sql. Note the spec DOES respect granularity elsewhere, in the FU_ENDDT oral-end-date rule, so the concept is in its vocabulary and is simply absent from the index-date definition. RESOLVED 2026-08-07: accept and document. Roughly 17% of Overall mHSPC index dates are not day-level - 13.00% MONTH and 4.01% YEAR (7,943 patients) - against 3.86% for Overall mCRPC. A year-granular value almost certainly resolves to 1 January, so for those patients OS, FUDUR and the [-30,+7] biomarker and ECOG windows are all measured from a date that can be up to a year early. MUST BE CARRIED WITH THE RELEASE, not left in this register: anyone doing time-to-event analysis on cohort 1 needs the number. Cohorts 3-7 are NOT covered by this - the LOT table records no granularity at all, so their index-date precision is unknowable rather than merely unmeasured.
- **Evidence:** CORRECTED 2026-08-07. This row previously claimed the LOT table's startdate was DAY 209,271 / MONTH 46,992 / YEAR 11,401 and that a fifth of LOT-cohort index dates were therefore imprecise. That was WRONG: t_enh_prostate_lot has no granularity column at all, and those three counts sum to 267,664, which is exactly the row count of t_enh_prostate_ORALS - the table they actually describe. There is no evidence either way about LOT startdate precision, so cohorts 3-7 are NOT implicated by anything read so far. The orals figure is not wasted: 5B.ClinChars r89 excludes oral end dates where dategranularity = 'Year' from FU_ENDDT_preliminary, so roughly 4.3% of oral rows are dropped by a rule the spec already states and the build already implements. The milestone granularities above come from t_enh_prostate in the profiler and stand. SIZED 2026-08-07 by counting the granularity of the component that WINS the max(). Cohort 1 (Overall mHSPC): DAY 164,240 (82.99%), MONTH 25,720 (13.00%), YEAR 7,943 (4.01%). Cohort 2 (Overall mCRPC): DAY 129,092 (96.14%), MONTH 4,506 (3.36%), YEAR 683 (0.51%). So 8,626 patients across the two Overall cohorts have an index date derived from a year-level component, and 33,663 patients in cohort 1 alone - 17% - have an index date that is not day-level. Source: validation/'Query Results .txt' (on main), run 2026-08-07.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q53 - DTHFL

- **Spec reference:** 5B.ClinChars r93 (DTHFL)
- **Spec says:** DTHFL's definition reads 'if DTHDT>. then 1, else 0'. Read as English this looks truncated mid-comparison, and it was recorded that way. It is not truncated.
- **We do:** dthfl = CASE WHEN dthdt IS NOT NULL THEN 1 ELSE 0 END
- **Decision:** No change. The build already transcribes the spec exactly.
- **Why:** Closed by correcting a misreading of unapproved, not by a ruling. the earlier reading of a SAS missing-value literal as truncated text, filed it as a cosmetic erratum, and review then correctly pointed out that a truncated DTHFL would be output-affecting rather than cosmetic - both of us reasoning from the same wrong premise about the text. The untruncated file settles it. V40 stays: it now asserts a reading rather than an inference, which is still worth gating because DTHFL drives the event-versus-censor branch of OS and feeds PFSFL and TTNT.
- **Evidence:** RESOLVED 2026-08-07 from the untruncated spec text supplied by the owner. The '.' is the SAS NUMERIC MISSING literal, and 'DTHDT > .' is the standard SAS idiom for 'DTHDT is not missing' - missing sorts below every number, so the comparison is true for any populated value. The definition is complete SAS, not a sentence that lost its ending. The build codes CASE WHEN dthdt IS NOT NULL THEN 1 ELSE 0 END, which is that idiom translated to SQL. This is a TRANSCRIPTION, not an inference - which is the opposite of how this row and SPEC_ERRATA E11 described it.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q54 - FU_ENDDT_preliminary

- **Spec reference:** 5B.ClinChars r89 (FU_ENDDT_preliminary)
- **Spec says:** The oral-therapy source is named 't_enh_metcrc_oral_&date'. 'metcrc' is metastatic COLORECTAL cancer - the table belongs to a different tumour type, and no such table exists in the prostate input contract.
- **We do:** Reads t_enh_prostate_orals, the prostate equivalent.
- **Decision:** Confirmed: a relic of a colorectal spec. The build's t_enh_prostate_orals is correct. Spec erratum E15 stands; no code change.
- **Why:** RESOLVED 2026-08-08 by the owner. This closes the register. The row is kept rather than deleted because it is the single clearest piece of evidence about how this spec was assembled: every other table in that same FU_ENDDT_preliminary definition uses the &cohort placeholder (t_&cohort_visit_&date, t_&cohort_telemedicine_&date, t_&cohort_lineoftherapy_&date) and only the oral one is hard-coded - to the wrong tumour type. That provenance is the reason several other errata exist (E16's LABNEUV tie direction, E18's PSA_INDEX anchor note), and it is the standing argument for treating unverified spec text as suspect rather than authoritative at the next refresh.
- **Evidence:** Found in the untruncated spec text supplied 2026-08-07. Every other table in the same definition is named with the &cohort placeholder (t_&cohort_visit_&date, t_&cohort_telemedicine_&date, t_&cohort_lineoftherapy_&date); only the oral one is hard-coded, and hard-coded to the wrong tumour type. It is a copy-paste from a colorectal spec.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q55 - LABPLA

- **Spec reference:** 5B.ClinChars r21 (LABPLA)
- **Spec says:** Q07 records that LABPLA's 'Present' clause names testbasename='hemoglobin' while its own 'Missing' clause names 'platelets' - a copy-paste slip. TWO INDEPENDENT READINGS OF THE SAME PHOTOGRAPH DISAGREE. The earlier reading says 'hemoglobin'; the spec text says 'platelets', i.e. no slip at all.
- **We do:** The build filters testbasename = 'platelets' for LABPLA, which is correct under EITHER reading. No delivered value depends on resolving this.
- **Decision:** No spec defect on the LABPLA row. Q07's LABPLA limb is WITHDRAWN. Q07's LABBIL limb stands - it is corroborated by the spec text and by the data.
- **Why:** No code change: the build has always filtered testbasename='platelets', so no delivered value was ever affected. What was wrong was the documentation - a code comment in 03_clinical.R and three passages in SPEC_RECONCILIATION.md asserted a spec defect that does not exist. All four corrected. WHY THIS IS WORTH THE ROW: an erratum list is only useful if it is trustworthy, and a false entry is worse than a missing one - it invites someone to 'fix' correct code to match a defect that was never there.
- **Evidence:** RESOLVED 2026-08-08 by the owner, reading the spec directly: the Present clause names testbasename='platelets', matching its own Missing clause. The spec text agrees. The earlier reading of 'hemoglobin' was wrong - and wrong TWICE, on two separate passes of the page, both made while looking for the slip register Q07 had already told me to expect. That is the confirmation bias I flagged when raising this row, confirmed.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q56 - ECOG (cohorts 3-7)

- **Spec reference:** 5B.ClinChars r47 / 3.Data Prep LOT_ECOG
- **Spec says:** Does the [INDEX-30, INDEX+7] window apply to the treated cohorts? Cohorts 1-2 applied it; cohorts 3-7 selected baseline ECOG by line number and line start date with NO date bound at all.
- **We do:** The window now applies to all seven cohorts.
- **Decision:** Keep the window on all seven cohorts. Confirmed by measurement, not by argument: it removes zero rows.
- **Why:** RESOLVED 2026-08-08 on evidence. The expected drop in ECOG completeness for cohorts 3-7 does not occur - it cannot, because Flatiron's baseline-ECOG table is already bounded to exactly [INDEX-30, INDEX+7]. The filter is therefore redundant TODAY but is retained deliberately: it makes the spec's stated LOT_ECOG assessment period explicit in our code instead of silently inherited from a vendor table's construction. If a future refresh widens that table, the build keeps the spec's window and the delivered values do not move. Zero cost, real insurance.
- **Evidence:** MEASURED 2026-08-08 (validation/05_sizing_queries.sql S4, run on 2026m06). The window costs NOTHING: n_lost = 0 in all five treated cohorts (3: 47,225 rows; 4: 34,427; 5: 21,526; 6: 12,643; 7: 7,048 - every one kept). The reason is visible in the same result: across all five cohorts MIN(gap) = -30 and MAX(gap) = +7 EXACTLY. t_enh_prostate_bsln_ecog is itself constructed on the [-30, +7] assessment window, so no record outside it exists to be dropped.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** n_lost = 0 / 122,869 treated-cohort rows with a baseline ECOG (S4, 2026m06)

### Q57 - DTHFUFL

- **Spec reference:** 5B.ClinChars r96 (DTHFUFL)
- **Spec says:** The definition and the stated purpose disagree. Definition: 'If DTHDT-FUED <=120 days then DTHFUFL=1; else 0'. Purpose, from both the row's notes and 3.Data Prep Section C item 7: flag patients whose PRELIMINARY death date is 120 days or more BEFORE the PRELIMINARY end of follow-up, because that suggests bad data.
- **We do:** DATEDIFF(death_dt_preliminary, fu_enddt_preliminary) <= 120 -> 1, else 0. NULL only when there is no death date - the pre-Q57 rule, carried forward unchanged. The spec's arithmetic and polarity are kept verbatim; only the inputs moved off the final DTHDT/FUED.
- **Decision:** Keep the definition's literal formula, move it onto the PRELIMINARY dates the notes name (DEATH_DT_preliminary and FU_ENDDT_preliminary). Do not flip the sign.
- **Why:** RULED 2026-08-08. WHY THE INPUTS MOVED: FUED is clamped toward the death date before this point, so on the final dates the discrepancy the notes describe has already been closed - DTHFUFL read 1 for essentially every death by construction and could not detect the thing it exists for. The preliminary dates are the only place it is still visible, and 5B.ClinChars r96 and 3.Data Prep Section C item 7 both name them explicitly. WHY THE SIGN DID NOT FLIP: the owner chose to keep the spec's arithmetic rather than reinterpret what the value 1 means. KNOWN LIMITATION, accepted: '<= 120' is satisfied by a large NEGATIVE difference, so a death 120+ days BEFORE the preliminary follow-up end - the suspect case - still scores 1, the same as an ordinary death. CORRECTION 2026-08-08, made after review: an earlier version of this row said the suspect case is 'reported by DTH_BEFORE_FUED'. THAT WAS WRONG. DTH_BEFORE_FUED compares the FINAL dthdt and fued, and fued has already been clamped toward the death date, so the preliminary discrepancy is closed before that flag is computed as well. Nothing in the delivered 190 columns identifies the narrative suspect case. That is a real consequence of the ruling and it is accepted, but it must not be described as covered elsewhere. REVERTED OVERREACH, same review: the first implementation ALSO returned NULL when FU_ENDDT_preliminary was absent. The spec's Values list is '0 = No; 1 = Yes' and its definition ends 'else 0' - there is no third state - and the owner's ruling covered the formula, the polarity and the input dates, NOT missing-input behaviour. Introducing a state the spec does not define, on a decision that did not cover it, was unapproved and unapproved. REMOVED. With the guard gone the spec's own arithmetic answers the case: DATEDIFF(death, NULL) is NULL, NULL <= 120 is NULL, and the ELSE branch gives 0 - exactly 'else 0'. The only NULL is the pre-existing no-death-date case, which Q57 never touched. GATES: V41 (the single null rule), V42 (the arithmetic), V43 (domain {0,1}). SIZING: S5 in validation/05_sizing_queries.sql gives the four-way input split; it reads the DELIVERED ADS, because both preliminary dates are output columns.
- **Evidence:** Raised by review 2026-08-07. The polarity differs - death 120 days BEFORE follow-up end is DTHDT - FUED <= -120, which satisfies '<= 120' and so scores 1 = 'acceptable', the opposite of the flag's purpose. Worse, FUED is CLAMPED toward the death date before this is computed, so the gap the notes describe has already been closed and cannot be observed on the final dates at all.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - run S5 against the delivered ADS for the four-way input split, and V41/V42/V43 for the rules. Row '2 death, no FU end' is the population the ruling did not cover; if it is non-zero, confirm that scoring it 0 is wanted.

### Q58 - all LAB* and BP

- **Spec reference:** 5B.ClinChars r17-r46 (labs) / r49-r51 (BP)
- **Spec says:** 'Missing' means no record for the analyte. The spec's Missing clause reads 'no record with testbasename = X is present in the t_lab table' - no time qualifier. The build tests for a record only AFTER restricting to labdate <= index_date.
- **We do:** The Missing test is NOT time-bounded. A patient with ANY record for the analyte anywhere in t_lab (or, for BP, any systolic/diastolic record in t_vitals) reads 'Unknown' when no qualifying pre-index record exists; 'Missing' now requires no record at all, at any date. LAB*V, LAB*DT, BPDT, BPSYS and BPDIA are unchanged - the value side stays bounded at dt_x <= index_date.
- **Decision:** Follow the spec sentence literally. Un-window the Missing test for all ten labs and for BP.
- **Why:** RULED 2026-08-08. The spec draws the distinction inside a single sentence - "'Present' if there is at least one record ... IN THE TIME PERIOD" against "Missing - if no record ... is present IN THE T_LAB_&DATE TABLE" - and the owner ruled that the contrast is deliberate. WHAT MOVED: 182,254-202,191 rows per analyte (35.4-39.2% of 515,406) and 144,079 BP rows (27.9%), all of them patients whose only records for that analyte are post-index. For albumin 'Missing' drops from ~50% of the ADS to ~11%. WHAT DID NOT MOVE: no lab value or lab date changes; only the three-way flag. CONSEQUENCE THAT MUST REACH THE DATA DICTIONARY: 'Unknown' is no longer a baseline data-quality signal. It now holds two populations - a few percent with a baseline record that fails the Present criteria, and ~39% who were simply tested later - and the second swamps the first. 'Missing' correspondingly now means the strict thing: this analyte never appears for this patient anywhere in the source table. Anyone building a baseline characteristics table should read Present as the only positive statement and treat Unknown + Missing together as 'no baseline value'. MY RECOMMENDATION WAS THE OPPOSITE and is recorded here so the choice is visible: I argued the row's PRE_INT Time Period governs every clause, citing the BP row, whose Present clause is equally unqualified yet must be index-bounded because BPSYS says 'prior or including the index date'. The owner ruled for the literal text over that inference.
- **Evidence:** MEASURED 2026-08-08 (validation/05_sizing_queries.sql S1/S1b, run on 2026m06). LARGE. Of 515,406 delivered rows, the number that would flip Missing -> Unknown is 182,254-202,191 per analyte (35.4%-39.2%): LABALB 202,191 (39.23%), LABALT 201,509, LABALP 201,461, LABAST 201,242, LABBIL 201,194, LABCRE 196,400, LABLYM 183,843, LABNEU 183,652, LABPLA 182,266, LABHEM 182,254 (35.36%). BP: 144,079 (27.9%). For albumin that moves 'Missing' from ~50% of the ADS to ~11%. n_flip_all_records_undated = 0 for every analyte, so the flip is entirely patients whose ONLY records for that analyte are POST-index - not undated records. TEXT RE-READ against the spec text, and it CUTS BOTH WAYS: the lab rows say 'Present if there is at least one record ... in the time period' but 'Missing - if no record ... is present in the t_lab_&date table' - a deliberate-looking contrast that supports the literal reading. The BP row does NOT: its Present clause also says only 'in the t_vitals_&date table' with no window, yet BPSYS confirms 'prior or including the index date' - so for BP the PRE_INT Time Period column is demonstrably the only thing bounding an unqualified clause.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** pre-change baseline: 182,254-202,191 rows per analyte and 144,079 BP rows predicted to flip Missing -> Unknown (S1/S1b, 2026m06). VERIFY WITH qc/05 C12a-C12j, NOT with S1: S1 reads only the SOURCE tables and rebuilds the cohort rows itself, so it returns the same numbers whether this ruling shipped correctly, shipped backwards, or did not ship at all. It predicts what should flip; it cannot confirm what did. C12a-C12j re-derive the three-way flag from source for all ten analytes and compare it to the delivered column patient by patient.

### Q59 - PSA50_6MO / PSA50_12MO

- **Spec reference:** 6.Outcomes (PSA50_6MO / PSA50_12MO)
- **Spec says:** The build requires PSABL > 0 before applying the PSA50 formula. The spec has no such condition.
- **We do:** case_when(!is.na(psa6mo) & !is.na(psabl) & psabl > 0 & ((psa6mo - psabl)/psabl) <= -0.5 ~ 'Y', TRUE ~ 'N')
- **Decision:** Keep the PSABL > 0 guard. Measurement shows it is value-neutral: it delivers exactly what the spec's own formula delivers for these rows, and protects the build from failing.
- **Why:** RESOLVED 2026-08-08 on evidence. WHY IT IS NOT A DEVIATION IN EFFECT: the spec says 'If (PSA6MO - PSABL)/PSABL <= -0.5 then Y, Else N'. With PSABL = 0 the quotient is 0/0 or x/0; Spark returns NULL for both under legacy semantics, NULL <= -0.5 is NULL, and the Else branch fires - so the unguarded spec formula ALSO yields 'N' on every one of these 3,764 rows. The guard cannot turn a Y into an N, because no division by zero can produce a finite value <= -0.5. WHY IT IS STILL NEEDED: under ANSI semantics the same expression raises DIVIDE_BY_ZERO and the build fails outright rather than delivering the spec's answer. The guard is therefore at worst neutral and at best load-bearing. INTERPRETIVE POINT, unchanged and consistent with Q35: those 3,764 rows read 'N' for PSA50 although an undetectable baseline PSA makes a 50% decline mathematically undefined, not merely unobserved - the same conflation Q35 accepted for a missing follow-up PSA. Spec errata E19.
- **Evidence:** MEASURED 2026-08-08 (validation/05_sizing_queries.sql S3, run on 2026m06). The guard IS reached: 707,895 of 4,385,815 PSA rows carry ScoreSerial = 0 (136,923 patients); no value is negative and the minimum is 0. Carried through the PSA_INDEX derivation, 3,764 delivered rows have PSABL = 0 - all zero, none negative (cohort 1: 1,000; 2: 1,086; 3: 1,113; 4: 321; 5: 161; 6: 65; 7: 18), i.e. 1.8% of the 205,197 rows that have a baseline PSA at all.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** 3,764 / 205,197 rows have PSABL = 0 (all zero, none negative); guard changes no delivered value (S3, 2026m06)

### Q60 - PRIOR_NHA_ADT

- **Spec reference:** 5C.TreatVars r39 (PRIOR_NHA_ADT)
- **Spec says:** The label says 'Any NHA and ADT received as combination therapy'. The definition says 'regimen names that contains at least two drugs, with at least one drug being abiraterone, enzalutamide, apalutamide, and/or darolutamide' - which does not require the second drug to be an ADT.
- **We do:** Follows the definition: an NHA plus any second drug sets the flag, whether or not that drug is an ADT.
- **Decision:** Keep the definition: an NHA plus any second drug sets the flag. The label's 'and ADT' is not enforced.
- **Why:** RULED 2026-08-08. The definition is the clause that derives the value and it is unambiguous: 'at least two drugs, with at least one being abiraterone, enzalutamide, apalutamide and/or darolutamide'. The label is the looser artefact. DECIDING FACTOR AGAINST THE LABEL READING: the spec supplies no ADT drug list anywhere in 39 pages, so enforcing 'and ADT' would mean inventing one - and any ADT agent omitted from an invented list would silently score No, turning a documentation mismatch into a data defect. CONSEQUENCE, accepted: PRIOR_NHA_ADT is broader than its name - an NHA with docetaxel or with a PARP inhibitor sets it. Anyone reading the column as strict NHA+ADT combination therapy will overcount. Carried as spec erratum E17 so the label gets corrected rather than the code.
- **Evidence:** Raised by review 2026-08-07 and confirmed against the spec text. Under the definition a patient on an NHA plus chemotherapy, or an NHA plus a PARP inhibitor, sets a flag whose label says NHA+ADT.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q61 - GLEASONN

- **Spec reference:** 5B.ClinChars r63 (GLEASONN)
- **Spec says:** GLEASONN's provenance is unverified. The spec text contains GLEASON but not GLEASONN, and register rationales have claimed its residual code 3 comes from the spec.
- **We do:** gleasonn = 1 for '<8', 2 for '>=8', 3 otherwise.
- **Decision:** Confirmed as built. GLEASONN = 1 / 2 / 3, where 3 is the spec's own third category, not a residual sentinel.
- **Why:** The distinction matters and is now stated in the code. Code 3 is an ENUMERATED value, in the same family as STAGEN's 5, RACEN's 5 and ETHN's 3 - not a fallthrough. The 99 convention (register Q50) applies only where the spec's Values list provides no residual at all: AGEGR1N, REGION1N, PRACTICN, COHORTUN and STAGEN's overflow. Without that note, someone later applying Q50 uniformly would 'correct' GLEASONN's 3 to 99 and break a delivered value that is right. Register rationales that described 3 as spec-provided were correct after all; the gap was that no supplied source had been cited for it. It is cited now.
- **Evidence:** RESOLVED 2026-08-08 by the owner: GLEASON has exactly THREE categories. The spec text of 5B.ClinChars r63 gives Values '<8, >=8, Unknown/Missing' with the mapping '<8' = Less than or equal to 6 / 4+3=7 / 3+4=7 / 7 (when breakdown not available); '>=8' = 8 / 9 / 10; 'Unknown/Missing' = Unknown / Not documented. GLEASONN numbers those three 1, 2, 3.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q62 - PSA_INDEX

- **Spec reference:** 5B.ClinChars r69 (PSA_INDEX)
- **Spec says:** The row conflicts with itself on the anchor. Its definition windows the PSA search on INDEXDT; its Additional Notes say CRPCDate.
- **We do:** Anchored on INDEXDT, per the definition. The [-14, 0] window and the earliest-then-highest rule are unchanged.
- **Decision:** Anchor on INDEXDT, as built. The Additional Notes' CRPCDate is a spec erratum.
- **Why:** RULED 2026-08-08. The definition is the clause that derives the value; INDEXDT is what a variable named PSA_INDEX should mean; and PSADIAG_CRPC, which legitimately anchors on CRPCDate, sits directly above PSA_INDEX on the sheet - the same copy-down pattern already confirmed for E15 (colorectal oral table) and E16 (LABNEUV tie direction). DECIDING FACTOR: under the CRPCDate reading the four mHSPC-indexed cohorts would lose their entire PSA response block, because a hormone-sensitive patient who has not progressed has no CRPCDate at all. That is not a subtle difference in a denominator, it is a variable that cannot be computed - which is itself evidence the note was copied rather than intended. No code change. Carried as spec erratum E18.
- **Evidence:** Raised by review 2026-08-07. PSADIAG_CRPC is the variable that legitimately anchors on CRPCDate and sits directly above PSA_INDEX, so the note looks like language copied down a row - the same copy-paste pattern as E15's colorectal table and E16's LABNEUV tie direction.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - no Databricks build has been executed for this head, so no delivered-data evidence exists for this row

### Q63 - all LAB* Present criteria

- **Spec reference:** 5B.ClinChars r17-r46 (labs)
- **Spec says:** The Present criteria require 'testdate is not missing', and the same row separately says 'Testdate will be derived by taking max(resultdate, testdate)'. Does criterion 1 test the RAW testdate column or the DERIVED date?
- **We do:** Requires the RAW testdate to be non-null. A row with a populated resultdate but a missing testdate is excluded, even though its derived date is available.
- **Decision:** No change. The question is unobservable in this data: raw testdate and derived max(resultdate, testdate) select identical record sets.
- **Why:** RESOLVED 2026-08-08 on evidence. The two readings of 'testdate is not missing' are indistinguishable on the 2026m06 snapshot, so no delivered value depends on the interpretation. The build keeps the raw-testdate test. NOTE FOR FUTURE REFRESHES: this is a property of the data, not of the spec - a later cut that populates resultdate without testdate would reopen the question. S2 is cheap; re-run it at refresh.
- **Evidence:** MEASURED 2026-08-08 (validation/05_sizing_queries.sql S2, run on 2026m06). NO ROWS RETURNED. Across all ten analytes there is not a single t_lab record with testdate NULL and resultdate populated - the only rows on which the raw-vs-derived reading could differ.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** 0 rows with testdate NULL and resultdate populated, all 10 analytes (S2, 2026m06)

### Q64 - LOT1_MCRPC / LOT2_MCRPC / LOT3_MCRPC / LOT4_MCRPC / LOT1_MHSPC / LOT2_MHSPC

- **Spec reference:** 5C.TreatVars r220 (LOT1_MCRPC and siblings)
- **Spec says:** A patient with no line at a given position was delivered the literal string 'None' in the line-NAME column. Is that intended, or should the column be NULL?
- **We do:** Passed through unchanged: linename, so a nonexistent line is NULL.
- **Decision:** Deliver NULL. The 'None' literal is removed.
- **Why:** A consumer-visible divergence with no register row behind it - the same class as SES writing 'Missing' before Q51. It also made three QC rules dishonest, which is how it surfaced: R40/R41 test for line-number gaps using IS NULL and could never fire; R42/R43 counted all four mCRPC and both mHSPC names as populated for every patient and would have FAILED every patient with fewer than four lines; and golden-patient profile P7 selected on lot4_mcrpc IS NOT NULL and would have matched anyone. All three become correct as written once the nulls are restored - the production fix repaired the QC rather than the other way round. LOTnCAT is unaffected: lotcat_expr reads linename directly and keeps its 'No treatment' branch. CSD is unaffected: for the treated cohorts the index line exists by construction, and LOWER(NULL) LIKE '%clinical study drug%' resolves through the ELSE branch to 0 exactly as LOWER('None') did. RULED 2026-08-08 on the spec text: the Values column reads 'Character' - a TYPE, not an enumeration - so there is no permitted value to put 'None' into; the Definition is a lookup, and a row that does not exist has no value to take; and the word 'None' appears nowhere in 39 pages. DECIDING CONTRAST: LOTnCAT one row down enumerates all seventeen levels ending '17) No treatment'. The spec author DID consider the no-line case and gave the CATEGORY a level for it while giving the NAME none. That asymmetry is deliberate, not an oversight.
- **Evidence:** Found by review 2026-08-08. The spec row reads 'Value of LINENAME from lineoftherapy table where LineSetting=... and NEW_LOT_N=n', type Character, with NO Values list - selecting a row that does not exist yields missing, not a word. Contrast LOTnCAT, whose Values list DOES carry an explicit level 17 'No treatment'; the CATEGORY has a no-treatment value in the spec and the NAME does not.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - no Databricks build has been executed for this head

### Q65 - LOT1CAT_* category 12, PRIOR_PARP

- **Spec reference:** 5C.TreatVars r231 category 12 (PARPi monotherapy) / r39 PRIOR_PARP
- **Spec says:** Regimen parsing assumed a comma delimiter for the PARPi 'no other drugs allowed' rule, while every combination rule in the same function accepted comma OR slash. Which is right?
- **We do:** Both the PARPi rule and PRIOR_PARP use the separator class [,/]. Preflight gates B13 (LOT table) and B14 (drug-episode table) fail the build on any other separator, on space around a separator, or on leading/trailing space in LINENAME.
- **Decision:** Accept both separators consistently, AND gate the LINENAME format at preflight so an unexpected separator stops the build instead of misclassifying a regimen.
- **Why:** RULED 2026-08-08. The spec names the drugs and says 'no other drugs allowed'; it never states a delimiter, so where the spec is silent the build must at least be self-consistent - and it was not: the same source string was read two ways in one function, with 2,487 slash-formatted LOT rows in the preflight output making that reachable. WHY THE GATE, which is the part that was actually decided: the 17 treatment categories are decided entirely by parsing LINENAME, and a regimen joined by a semicolon, plus or pipe is not REJECTED by the parser - it is read as one drug name, matches no monotherapy and no combination test, and lands silently in category 16 'Any other therapy'. LOTnCAT is a headline variable and nothing downstream reports the misclassification. Preflight already counted delimiters, but counting only helps if somebody reads it. B13 stops the build instead. If the count is zero on this cut the gate costs nothing and catches the refresh where it stops being zero. DELIBERATELY NARROW: it looks for separator punctuation only, because drug names legitimately contain hyphens (Radium-223, Sipuleucel-T) and spaces (Clinical Study Drug). WIDENED 2026-08-08: B13 originally covered the LOT table only, but PRIOR_PARP and PRIOR_NHA_ADT parse LINENAME from the DRUG-EPISODE table, so an unexpected separator there changed a delivered flag while the mandatory gate passed. B14 now covers that table. Both gates also flag whitespace around a separator, because the anchored monotherapy and PARPi expressions match exact strings and do not tolerate it.
- **Evidence:** Found by review 2026-08-08. The saved preflight output reports 2,487 slash-formatted LOT rows, so the inconsistency was reachable, not theoretical. A slash-delimited PARPi regimen fell through to 'Any other therapy' (category 16) while a slash-delimited NHA regimen was correctly called a combination - the same source formatting read two different ways in one function.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - B13 must read PASS in the preflight before the build is trusted; a non-zero count names the offending separator directly

### Q66 - DATEOFDEATH / DEATH_DT_preliminary / DTHDT / DTHFL

- **Spec reference:** 5B.ClinChars r90 (DATEOFDEATH imputation)
- **Spec says:** The imputation handled only 7-character (YYYY-MM) and 4-character (YYYY) death dates. Any other length fell to NULL. What should a full YYYY-MM-DD value do?
- **We do:** SPEC-LITERAL: only the two documented shapes are imputed - 7-character YYYY-MM to the 15th, 4-character YYYY by the Jul-15 / Dec-31 rule. Every other length falls to NULL. The 10-character branch added earlier is REVERTED.
- **Decision:** Implement the two cases the spec describes and nothing more. Measure the exposure in QC rather than gating it at preflight.
- **Why:** RULED 2026-08-08. The spec does not have a rule here to be literal about in the usual sense - 5B.ClinChars r90 describes month-and-year and year-only and gives NO 'else' clause, so the case is a HOLE, not a decision the spec made. The owner ruled to implement exactly what is written and not fill the hole with invented behaviour. A 10-character YYYY-MM-DD branch had been added on the reasoning that a full date needs no imputation; it is REVERTED, because that reasoning is unapproved and the same overreach as the withdrawn Q57 null state - plausible behaviour that no clause supports and nobody approved. WHAT IS NOT SETTLED, and is now measured instead: a POPULATED death date that falls to NULL turns a dead patient into a censored one - DTHFL reads 0, OS switches from the death date to FUED, PFS loses its death event - and nothing in the build reports it. qc/08_death_date_formats.sql quantifies exactly that: Q08a the length distribution, Q08b the patients the source says died and the ADS says did not, Q08c what it does to their delivered outcomes, and Q08d the case the length checks are structurally blind to - a value seven characters long that is not YYYY-MM, or that carries an impossible month, where the length is right and only the content is wrong. NOT GATED at preflight, on the owner's ruling: see whether it is failing anything first.
- **Evidence:** Found by review 2026-08-08. t_mortality_v2 is documented as month- or year-granular, so a full date is unexpected - but it is unambiguous, and discarding it turns a dead patient into a censored one, changing DTHFL, OS and PFS with nothing reporting it.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - run qc/08. Q08b returning zero closes this row with no code change; anything above zero reopens the derivation with a known fix.

### Q67 - BP / BPSYS / BPDIA

- **Spec reference:** 5B.ClinChars r186 (BP)
- **Spec says:** The spec requires TESTRESULT to be 'a positive integer'. The build casts to DOUBLE and tests only > 0, so a decimal reading counts as Present.
- **We do:** bpval > 0 AND bpval = ROUND(bpval), applied to both the same-date pairing and each arm's value.
- **Decision:** Implement the spec: a BP reading must be a positive INTEGER to count as Present.
- **Why:** RULED 2026-08-08. Unlike Q58 this was never ambiguous - the spec states the requirement TWICE, positively ('TESETRESULT is a positive integer and not NULL') and again as the Unknown condition ('0 or not a positive integer or is null then = Unknown'). A fractional reading moves from Present to Unknown and loses its BPSYS/BPDIA, which is exactly what the Unknown clause instructs. THE TEST IS ON THE VALUE, NOT THE TEXT: TRY_CAST('120.0' AS DOUBLE) is 120.0, which equals its own ROUND, so a decimal point in the source string does not by itself disqualify a row - only a genuinely fractional reading such as 120.5 moves. Expected near-zero impact, since blood pressure is recorded in whole mmHg; qc/09 Q09a gives the count.
- **Evidence:** Found by review 2026-08-08. The BP row says 'TESETRESULT is a positive integer and not NULL' for Present, and 'If one of diastolic or systolic records is 0 or not a positive integer or is null then = Unknown' - so under the literal reading a decimal reading is Unknown, not Present.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - qc/09 Q09a counts positive non-integral BP readings per arm

### Q68 - WEIGHT / HEIGHT / BMI / BSA

- **Spec reference:** 5B.ClinChars r194-197 (WEIGHT / HEIGHT)
- **Spec says:** The spec requires TESTRESULTCLEANED to be non-null. The build additionally requires it to be > 0. Is the extra condition wanted?
- **We do:** SPEC-LITERAL: the vitals filter is `!is.na(testresultcleaned)` only. The > 0 condition is REMOVED from record selection and now appears solely as a division guard on BMI and BSA.
- **Decision:** Accept any non-null TESTRESULTCLEANED, as the spec states. Do not filter on sign.
- **Why:** RULED 2026-08-08, and it went the OPPOSITE way to my recommendation - recorded so the choice is visible. 5B.ClinChars r194-197 qualifies a record on 'where TESTRESULTCLEANED is not null' and nothing else; the > 0 condition was unapproved and unstated, and the owner ruled to implement what is written, consistent with Q64 and Q66. WHAT WAS NOT LOOSENED, and why: BMI and BSA keep a height > 0 guard. That is not a record filter, it is arithmetic protection - the spec's own BMI formula divides by HEIGHT, and a zero height raises DIVIDE_BY_ZERO under ANSI, which is a BUILD FAILURE rather than a value. Under legacy semantics the same expression yields NULL and BMIGR1 reads 'Missing', so the guard delivers exactly what the spec's formula delivers and only removes the crash - identical reasoning to the PSABL guard ruled under Q59. BSA is guarded for a different reason: POWER() of a negative base with a fractional exponent returns NaN, not an error, and NaN in a numeric column is worse than NULL because it survives the null sweep and poisons any downstream mean. MEASURED, not assumed: qc/09 Q09b counts the non-positive records now admitted and Q09c shows what reaches the delivered table.
- **Evidence:** Found by review 2026-08-08. The spec clause is 'where TESTRESULTCLEANED is not null'; nothing about positivity.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - qc/09 Q09b is the count that matters; Q09c confirms no NaN reaches BMI or BSA
- **Follow-up 2026-08-08:** the BMI guard was tightened to match this ruling. It read `height > 0 AND weight > 0`; the `weight > 0` limb was a filter on sign, which this row forbids, and the formula is well defined for a negative weight. It now reads `height <> 0` - the only input the formula has no value for. BSA still guards both sides, at `>= 0`, because a fractional power of a negative base is NaN rather than a number and NaN survives every null check downstream; zero is allowed through, since POWER(0, 0.725) is 0.
- **Correction 2026-08-08:** the sentence above originally ended by saying a negative BMI beside `BMIGR1 = Missing` is "what the spec's own formula and bands give". THAT WAS WRONG. The formula gives the negative number, yes - but the bands say every BMI below 18.5 is Underweight, with no positivity test, and the build's band carried `bmi > 0 AND bmi < 18.5`. So a negative BMI read `Missing` / 5 while BMI itself was populated, and the register described that as spec-compliant when it is not.
- **Resolved 2026-08-08, by applying this row's own ruling:** the `bmi > 0` limb is removed. It is the same filter-on-sign this row rules against, one level further down - the same mistake as the `weight > 0` guard, in the band instead of the formula. `BMIGR1` now follows the spec: below 18.5 is Underweight, full stop. `Missing` means exactly one thing, that BMI could not be computed. `qc/03` R56 is a GATE on it, and R29 tracks the formula guard. No new approval is needed for this - it moves the code TOWARD the spec and toward the ruling already given here - but the consequence is worth stating: a negative weight now delivers a negative BMI banded Underweight. Whether such a reading should reach the output at all is the plausibility-gate question in OPEN_QUESTIONS.

### Q69 - LABHEM / LABHEMV / LABHEMDT

- **Spec reference:** 5B.ClinChars r127 (LABHEM)
- **Spec says:** The spec's hemoglobin unit filter is written as ' g/dL' with a LEADING SPACE. The build filters 'g/dL'. Which is right?
- **We do:** TRIM(testunitscleaned) compared against the trimmed literal, for ALL TEN analytes.
- **Decision:** Compare trimmed values. g/dL is the correct unit; the spec's leading space is a reading artefact, recorded as errata E20.
- **Why:** RULED 2026-08-08. The owner confirmed g/dL is the standardised unit hemoglobin must be in - it is the conventional US reporting unit, and TESTUNITSCLEANED is the vendor's own standardised unit column, so a leading space is not a real value. TRIM was chosen over simply keeping 'g/dL' because it makes the question MOOT rather than answered: both readings of that spec cell then select identical rows. It also guards the SOURCE side, which nothing else checked - a stray space in testunitscleaned would silently empty an analyte, and that failure looks exactly like 'this lab was never done'. Applied to all ten analytes rather than hemoglobin alone: a robustness rule that holds for one column and not its nine siblings is a trap, not a rule. Zero cost where no whitespace exists.
- **Evidence:** Found by review 2026-08-08. Every other analyte's unit is written without a leading space in the same column ('10*9/L', 'mg/dL', 'U/L', 'g/L'); hemoglobin is the only one with it.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - preflight C10 reports the observed unit strings; qc/01 will show LABHEM is populated

### Q70 - MCRPCDDYR / MHSPCDDYR / MPCDDYR / INITYR, PSA50_6MO / PSAL6MO / PSA50_12MO / PSAL12MO, BMIGR1

- **Spec reference:** 5B.ClinChars (year fields), 6.Outcomes (PSA response), BMIGR1
- **Spec says:** The spec's Values column disagrees with what the build emits for three families: the year fields say 'Date' but the build emits a numeric year; the PSA response fields say 'Numeric' but the build emits Y/N; BMIGR1's Values mix numbers and labels while the build emits a label plus a separate BMIGR1N.
- **We do:** Numeric years, Y/N response flags, label + N pair for BMI banding.
- **Decision:** Keep the build's types. The three Values cells are errata; the type contract is pinned by qc/07.
- **Why:** RULED 2026-08-08. Same principle as Q60 and Q62: where a row contradicts itself, the clause that DERIVES the value wins over the clause that describes it. The owner settled BMIGR1 directly - BMIGR1 is the CHARACTER label and BMIGR1N is its numeric counterpart, the N suffix denoting numeric exactly as it does on RACEN, STAGEN and every other sibling - so the spec's mixed Values cell is describing the pair, not requiring BMIGR1 to be numeric. The same reading settles the other two: a year field typed Date would need an invented month and day, and PSA50 typed Numeric contradicts its own 'then Y, Else N'. WHAT REMAINS, and it cannot be closed from the desk: no approved type contract exists. qc/07_type_contract.R captures the delivered Spark types on its first run and pins nothing until a human reviews and commits qc_column_types.csv. Until then the delivered types are whatever the build emitted, which is not the same as agreed.
- **Evidence:** Found by review 2026-08-08. In each case the DEFINITION supports the build and only the Values column disagrees: INITYR is defined as Year(INIT), PSA50 is defined as 'If ... <= -0.5 then Y, Else N', and BMIGR1N exists as its own row.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - run qc/07, review the captured types, commit qc_column_types.csv

### Q71 - ECOG / ECOGN

- **Spec reference:** 5B.ClinChars r47
- **Spec says:** ECOG values are 0, 1, 2, 3, 4 and Unknown/Missing. The spec does not say what to do with a source value outside 0-4.
- **We do:** A castable value outside 0-4 reads Unknown/Missing, matching ECOGN = 6.
- **Decision:** Clamp ECOG to the six documented categories.
- **Why:** RULED 2026-08-08: clamp. The spec lists six categories and says nothing about a value outside 0-4. Before this, the label took any castable value while ECOGN mapped anything outside 0-4 to 6, so ECOG='5' shipped with ECOGN=6 - a label and a code that disagree, and a seventh category the spec does not define. A frequency table grouped on ECOG would have shown a '5' row that ECOGN counted as Unknown. qc/03 R48 already tested for this and would have failed the run, so the alternative was shipping a known gate failure. Checked by R48.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - no build has been run against the database

### Q72 - WEIGHT / HEIGHT / BMI / BSA, HRR_INDEX / BRCA_INDEX, LOT1CAT_MCRPC

- **Spec reference:** 5B.ClinChars r57-64, r70-74
- **Spec says:** The spec names TEST and BIOMARKERNAME values in one letter case and says nothing about variants.
- **We do:** Vitals group on the lower-cased TEST. Biomarker conflicts group on the upper-cased BIOMARKERNAME.
- **Decision:** Normalise case before grouping, everywhere the value is also filtered case-insensitively.
- **Why:** RULED 2026-08-08: normalise case before grouping. Both places already FILTERED case-insensitively, so grouping on the raw value was simply inconsistent with the filter - there was never an intent to treat 'BRCA1' and 'brca1' as different genes. The vitals half fanned a patient out: 'Body Height' and 'body height' became two winning rows that both joined back. The biomarker half is worse - a Positive on one spelling and a Negative on the other formed separate groups and BOTH survived, which is exactly what the Q29 collision rules exist to prevent, and nothing downstream would show it as anything but a plausible call. Checked by R01 (grain).
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - no build has been run against the database
- **Follow-up 2026-08-08:** a third place had the same inconsistency. The line-category rule and PRIOR_CHEMO both compared DETAILEDDRUGCATEGORY case-insensitively, while the per-line chemotherapy look-up in 04_treatment.R compared the raw value - so 'Chemotherapy' counted in two of the three and not the third. Now lower-cased there too, on the reasoning above. This changes LOTnCAT to 'Other chemotherapy-containing' for any line whose episodes carry a capitalised category and no earlier rule matched.
- **Limit of this ruling, 2026-08-08:** it authorises normalising for MATCHING and GROUPING. It does not authorise changing a delivered value, and one had been changed: `LINENAME` was lower-cased when the LOT table was opened, so `LOT1_MHSPC` and its seven siblings - which are a straight copy of it - shipped a normalised name rather than the source's. The spec says deliver LineName. Removed; the name is delivered raw. Nothing needed it, because every place that matches on the name lower-cases inside its own predicate: the 17 category rules, the prior-drug flags, CSD, `like_any_sql()` and gate B17. Delivered `LOTn_*` values change for any regimen the source records in mixed case.

### Q73 - LOT1_MCRPC and siblings, LOT1CAT_MCRPC and siblings

- **Spec reference:** 5C.TreatVars r220, r231
- **Spec says:** The spec does not distinguish a line that does not exist from a line that exists with no LINENAME.
- **We do:** Unchanged. A line that exists with no name still gives a NULL name and category 17.
- **Decision:** Leave as-is. Size it from the first run before deciding.
- **Why:** RULED 2026-08-08: no code change yet, count first. Q64 settled the ABSENT line. A line that EXISTS with a null LINENAME lands in the same place, so a patient in a treated cohort - where the index line exists by construction - can read 'No treatment'. Nobody has counted how often that happens, and the fix depends on the number: zero closes it, a small count suits category 16 or a preflight gate, a large count is a source problem to raise upstream. TWO QUERIES, because they answer different halves. qc/03 R55 counts the DELIVERED contradiction - a treated cohort whose own index line reads 'No treatment'. validation/05 S6 counts the SOURCE population, and also counts BLANK names, which are a second shape of the same problem: a blank string is not NULL, so it misses the 'No treatment' branch and falls to category 16 instead. Two source shapes, two different delivered answers, neither a real treatment.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - qc/03 R55 and validation/05 S6
- **Narrowed 2026-08-08.** This row also said a BLANK or whitespace-only LINENAME falls through to category 16. That is no longer reachable: gate B13 requires the name to match `token([,/]token)*`, and a blank or whitespace-only value matches nothing, so the build stops before delivering it. What remains in scope here is the NULL name, which B13 explicitly permits and which reads `No treatment`.

### Q74 - AGEGR1

- **Spec reference:** 5A.Demos r8-r22
- **Spec says:** The AGEGR1 Values list gives seven age bands and no residual level.
- **We do:** A missing or negative AGE reads `Unknown`.
- **Decision:** Keep `Unknown`. It is the label that pairs with AGEGR1N's 99.
- **Why:** AGEGR1N needs a residual code and Q50 approves 99 for exactly this shape. A coded pair whose label has no matching level fails the label/code agreement check, and leaving the label NULL would make AGEGR1 the only character band variable in the ADS that can be null. AGE is missing when BIRTHYEAR is missing and negative when the recorded birth year is later than the index year - both are source conditions, not build defects. Registered and approved 2026-08-08 after review found it implemented but unrecorded.
- **Evidence:** qc/03 R10 counts rows reading `Unknown` with a non-null AGE, which is precisely the negative-age population.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - no Databricks build has been executed for this head

### Q75 - GLEASON / GLEASONN

- **Spec reference:** 5B.ClinChars
- **Spec says:** The Values list prints unspaced sums and `7 (when breakdown not available)`.
- **We do:** Match the spellings the source carries - `3 + 4 = 7`, `4 + 3 = 7`, `7 (not documented)` - alongside the printed ones.
- **Decision:** Match both sets. Where they differ the source spelling is what selects rows.
- **Why:** The spec's spellings do not occur in t_enh_prostate. Matching them literally would send every spaced sum to `Unknown/Missing`, and those sums are most of the `<8` category. Accepting both means neither reading loses data. Q61 settled the three categories and their codes; it never covered the lexical mapping, which is why this row exists. A spelling in NEITHER set still falls to `Unknown/Missing` without announcing itself - preflight section C lists the distinct values so that stays visible.
- **Evidence:** qc/05 C07 re-derives GLEASON from the source spellings and compares it row by row.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - no Databricks build has been executed for this head

### Q76 - LOT uniqueness key

- **Spec reference:** 3.Data Prep
- **Spec says:** Check line uniqueness on PatientID + LineNumber + IsMaintenanceTherapy.
- **We do:** Check PatientID + LineSetting + LineNumber (gate B6).
- **Decision:** Use the setting key. The maintenance flag does not exist in this cut.
- **Why:** t_enh_prostate_lot_2026m06 carries no ismaintenancetherapy column, so the printed key cannot be built at all. The substituted key is the one NEW_LOT_N actually depends on: numbering restarts inside each setting, so a LineNumber repeating within a patient AND setting is what would send baseline ECOG to the wrong line. This changes which source shapes stop the build. It changes no delivered value.
- **Evidence:** ismaintenancetherapy appears in neither validation/00_input_contract.csv nor the 98 columns 00_setup.R requires before it writes.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** n/a - no delivered value depends on this

### Q77 - DATAV / source tables

- **Spec reference:** 3.Data Prep section B
- **Spec says:** The data cut is printed as `2026j30`.
- **We do:** Read June 2026 - source tables suffixed `_2026m06`, DATAV `20260630`.
- **Decision:** June 2026. `2026j30` is a print artefact, not a suffix.
- **Why:** No table carries a `_2026j30` suffix; all 21 exist as `_2026m06`. `20260630` is 30 June 2026, the month end of that cut. There is no other reading under which the build has any input at all. Recorded because it selects the entire input snapshot, which makes it the single widest-reaching interpretation in the register even though it is not in doubt.
- **Evidence:** preflight section A confirms all 21 tables and 98 columns exist under the `_2026m06` suffix, and the build's own input-contract check repeats it before the first write. The run manifest records source_refresh on every build.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** PENDING - no Databricks build has been executed for this head

### Q78 - B15 / B16 / B17

- **Spec reference:** n/a - build preconditions
- **Spec says:** Nothing. The spec states no gate on LINESETTING form or on repeated drug tokens.
- **We do:** Stop the build on a LINESETTING case or whitespace variant, on either table, and on a LINENAME naming the same drug twice.
- **Decision:** Approved as preconditions, alongside B1-B6 and B12-B14.
- **Why:** Each can only REFUSE a run. None transforms a value on data that passes, so none can change a delivered number. They guard two silent failures. LINESETTING is matched exactly, so a variant drops a line out of its cohort, out of NEW_LOT_N and out of every LOTn variable with nothing reporting it - the table still looks complete and a patient is simply absent. A repeated drug token reads as a combination regimen rather than a monotherapy, and the format gates pass it because the format is legal. Stopping is the right answer to both, because neither is visible in the finished table. Registered 2026-08-08 so the build-stop set is fully accounted for.
- **Evidence:** the gates run in run_preflight() and are mirrored in validation/01 section B; the two implementations were made identical in 202606.19.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** n/a - a gate cannot change a delivered value

### Q79 - PSA6MO / PSA50_6MO / PSAL6MO

- **Spec reference:** 6.Outcomes (the PSA6MO row) against 3.Data Prep section C
- **Spec says:** The PSA6MO row defines the six-month window as `[INDEXDT + 180, INDEXDT + 210]`. Data Prep separately converts a month to 30.4375 days, which puts six months at 183.
- **We do:** `[+180, +210]`, as the PSA6MO row states.
- **Decision:** No change. The variable's own row governs; the 183-day figure is not a competing definition of this window.
- **Why:** The two numbers are not in conflict. 183 days is the generic month conversion used for DURATIONS - OS, TTNT, PFS, TTCRPC all divide by 30.4375 - and says nothing about which PSA result to select. The PSA6MO row states a deliberately WIDE selection window, `[+180, +210]`, so a result that arrives late still counts as the six-month reading; a 183-day point would defeat that purpose. Registered as a no-change clarification because two independent reviews reached opposite conclusions on it - one calling it an unregistered divergence, the other calling the code correct. Recording it settles which reading applies and stops the question returning.
- **Evidence:** The window is stated on the variable row itself; nothing in the spec applies the 183-day figure to PSA selection.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **QC evidence:** n/a - no change was made, so there is nothing to evidence. If the boundary is ever queried, days +179 through +183 and +210 through +211 are the rows that distinguish the two readings.
