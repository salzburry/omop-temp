# =============================================================================
# Index cohort definition
# =============================================================================
# 4.StudyPop section B - one index table per cohort.
# Sourced by the driver in numbered order. Not runnable on its own.
# =============================================================================

# Overall cohorts index on the metastatic milestone date. LOT cohorts index on
# the start date of the matching line within the setting. Every cohort also
# needs the milestone date itself inside the index window.
index_lot_cohort <- function(coh_flag) {
  ci      <- coh_info(coh_flag)
  setting <- ci$setting
  lot_n   <- ci$lot_n      # local, not ci$lot_n: dbplyr reads `ci$lot_n`
                           # inside a verb as a SQL column reference, not an
                           # R value, so `ci$...` must never appear in one.

  milestone <- enh_pros_pano %>%
    mutate(advanceddiagnosisdate = if (setting == "mHSPC") mhspcdd else mcrpcdd) %>%
    filter(advanceddiagnosisdate >= index_start & advanceddiagnosisdate <= index_end) %>%
    select(patientid, advanceddiagnosisdate)

  if (is.na(ci$lot_n)) {
    # Overall mHSPC / Overall mCRPC
    return(milestone %>%
             mutate(index_date = as.Date(advanceddiagnosisdate)) %>%
             select(patientid, index_date, advanceddiagnosisdate))
  }

  lot_index <- lot_tbl(setting) %>%
    filter(startdate >= index_start & startdate <= index_end & new_lot_n == !!lot_n) %>%
    select(patientid, linename, linenumber, startdate, enddate, new_lot_n)

  lot_index %>%
    inner_join(milestone, by = "patientid") %>%
    mutate(index_date = as.Date(startdate)) %>%
    select(patientid, index_date, advanceddiagnosisdate,
           linenumber, linename, startdate, enddate, new_lot_n)
}

for (coh_flag in coh_list) {
  var_name <- paste0("enh_pros_pano_", coh_flag, "_index_tbl")
  df <- index_lot_cohort(coh_flag)
  createInPersonalSchema(df, stage_name(var_name), replace = TRUE)  # push to Databricks
  # Rebind to the MATERIALIZED table, not the lazy query. Keeping the lazy
  # object would make every downstream stage re-expand the whole upstream
  # query, so the final ADS would be one enormous nested SELECT and the
  # intermediate writes would be paid for without ever being used.
  assign(var_name, tbl(con, in_schema(personal_schema, stage_name(var_name))))
  rm(df)
}
