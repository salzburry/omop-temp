# =============================================================================
# Assemble, write and stamp the ADS
# =============================================================================
# The 190-column allowlist, the seven-cohort union, the output write.
# Sourced by the driver in numbered order. Not runnable on its own.
# =============================================================================

# Output contract. The final frame is selected against this ordered allowlist,
# not assembled and then trimmed. Anything a block carries that is not named
# here never reaches the output, and a variable that stops being produced fails
# the run instead of quietly disappearing. Ordered by spec sheet: identifiers,
# 5A.Demos, 5B.ClinChars, 5C.TreatVars, 6.Outcomes, then cohort labels and
# study constants.
ads_columns <- c(
  "patid", "indexdt", "id3mosfu", "birthyear",
  "age", "agegr1", "agegr1n", "state",
  "region1", "region1n", "race", "racen",
  "ethnicity", "eth", "ethn", "practicn",
  "practic", "ses", "id_pd_mcrpc", "id_pd_mhspc",
  "mcrpcdd", "mcrpcddyr", "mcrpctype", "mhspcdd",
  "mhspcddyr", "mhspctype", "init", "inityr",
  "mpcdd", "mpcddyr", "ttcrpc", "tthspc",
  "tintcrpchspc", "stage", "stagen", "gleason",
  "gleasonn", "psadiag_init", "psadiag_met", "ecog",
  "ecogn", "labneu", "labneuv", "labneudt",
  "labpla", "labplav", "labplavdt", "labhem",
  "labhemv", "labhemdt", "labcre", "labcrev",
  "labcredt", "labbil", "labbilv", "labbildt",
  "labast", "labastv", "labastdt", "labalt",
  "labaltv", "labaltdt", "labalp", "labalpv",
  "labalpdt", "labalb", "labalbv", "labalbdt",
  "lablym", "lablymv", "lablymdt", "bp",
  "bpn", "bpdt", "bpsys", "bpdia",
  "csf_pre", "csf_fu", "ss", "weight",
  "weightdt", "height", "heightdt", "bmi",
  "bmigr1", "bmigr1n", "bsa", "psadiag_crpc",
  "psa_index", "hrr_index", "hrr_indexn",
  "hrr_label_index", "hrr_label_indexn", "brca_index",
  "brca_indexn", "hrr_index_test", "hrr_index_testn", "brca_index_test",
  "brca_index_testn", "psma_scandt", "psma_scanresult", "lung_metdt",
  "lung_met", "adrenal_metdt", "adrenal_met", "bone_metdt",
  "bone_met", "brain_metdt", "brain_met", "min_vst_dt",
  "min_vsttelemed_dt", "min_medord_dt", "max_vsttelemed_dt", "max_lotend_dt",
  "max_drug_ep_abstracted_dt", "fu_enddt_preliminary", "dateofdeath", "death_dt_preliminary",
  "dthdt", "dthfl", "fued", "dthfufl",
  "dth_before_fued", "fudur", "indexyr", "lot1_mhspc",
  "lot1sd_mhspc", "lot1ed_mhspc", "lot1cat_mhspc", "lot1catn_mhspc",
  "lot2_mhspc", "lot2sd_mhspc", "lot2ed_mhspc", "lot2cat_mhspc",
  "lot2catn_mhspc", "lot1_mcrpc", "lot1sd_mcrpc", "lot1ed_mcrpc",
  "lot1cat_mcrpc", "lot1catn_mcrpc", "lot2_mcrpc", "lot2sd_mcrpc",
  "lot2ed_mcrpc", "lot2cat_mcrpc", "lot2catn_mcrpc", "lot3_mcrpc",
  "lot3sd_mcrpc", "lot3ed_mcrpc", "lot3cat_mcrpc", "lot3catn_mcrpc",
  "lot4_mcrpc", "lot4sd_mcrpc", "lot4ed_mcrpc", "lot4cat_mcrpc",
  "lot4catn_mcrpc", "lotn", "lotngr1", "lotngr1n",
  "lotn_mhspc", "lotngr1_mhspc", "lotngr1n_mhspc",
  "prior_pluvicto", "prior_parp", "prior_chemo", "prior_nha_adt",
  "prior_docetaxel", "prior_abiraterone", "prior_arpi", "csd",
  "os", "vis120", "ttnt", "eligpfs",
  "pfsfl", "pfsdt", "pfs", "psa6mo",
  "psa50_6mo", "psal6mo", "psa12mo", "psa50_12mo",
  "psal12mo", "cohort", "cohortn", "cohortu",
  "cohortun", "datav", "rawrwd", "minindex",
  "maxindex"
)


# Treated status is per setting, because COHORTU distinguishes treated from
# untreated within mHSPC and within mCRPC separately.
treated_mhspc <- enh_pros_pano_lot_mhspc %>%
  mutate(treat_mhspc = 1) %>% select(patientid, treat_mhspc) %>% distinct()
treated_mcrpc <- enh_pros_pano_lot_mcrpc %>%
  mutate(treat_mcrpc = 1) %>% select(patientid, treat_mcrpc) %>% distinct()

overall_ads_creation <- function(coh_flag) {
  ci <- coh_info(coh_flag)

  # Only patientid and index_date come from the index table. LOT cohorts also
  # hold new_lot_n, linename and linenumber, but those are not spec outputs and
  # keeping them would give the seven frames different column sets, which
  # union_all() cannot align.
  index_tbl <- get(paste0("enh_pros_pano_", coh_flag, "_index_tbl")) %>%
    select(patientid, index_date)

  dem_tbl      <- get(paste0("enh_pros_pano_", coh_flag, "_dem_tbl"))
  clin_tbl     <- get(paste0("enh_pros_pano_", coh_flag, "_clin_tbl"))
  trt_tbl      <- get(paste0("enh_pros_pano_", coh_flag, "_trt_var_tbl"))
  outcomes_tbl <- get(paste0("enh_pros_pano_", coh_flag, "_outcomes_var_tbl"))

  # Chosen in R and spliced into mutate() with !!. An `if` inside mutate() goes
  # to dbplyr, which reads its condition as a SQL column reference.
  cohortu_expr <- if (ci$setting == "mHSPC") {
    rlang::expr(case_when(!is.na(treat_mhspc) ~ "Treated mHSPC",
                          TRUE ~ "Untreated mHSPC"))
  } else {
    rlang::expr(case_when(!is.na(treat_mcrpc) ~ "Treated mCRPC",
                          TRUE ~ "Untreated mCRPC"))
  }

  index_tbl %>%
    left_join(dem_tbl,       by = c("patientid", "index_date")) %>%
    left_join(clin_tbl,      by = c("patientid", "index_date")) %>%
    left_join(trt_tbl,       by = c("patientid", "index_date")) %>%
    left_join(outcomes_tbl,  by = c("patientid", "index_date")) %>%
    left_join(treated_mhspc, by = "patientid") %>%
    left_join(treated_mcrpc, by = "patientid") %>%
    mutate(
      cohort  = !!ci$cohort,
      cohortn = !!ci$cohortn,
      cohortu = !!cohortu_expr,
      cohortun = case_when(
        cohortu == "Untreated mCRPC" ~ 1,
        cohortu == "Treated mCRPC"   ~ 2,
        cohortu == "Untreated mHSPC" ~ 3,
        cohortu == "Treated mHSPC"   ~ 4,
        # 99 = fallthrough (register Q50). UNREACHABLE: cohortu_expr always
        # returns one of the four strings above.
        TRUE ~ 99),
      # SPEC-Q: the COHORTU definition only branches on the two Overall cohorts.
      # It is populated for all seven here - cohorts 3-7 are treated by
      # construction, so they resolve to "Treated <setting>". Confirm.
      datav    = datav,
      rawrwd   = rawrwd,
      minindex = index_start,
      maxindex = index_end
      # STUDY_PD is a time-period definition ("earliest available data through
      # MAXINDEX"), not a date constant, so it is not emitted as a column.
    ) %>%
    rename(patid = patientid, indexdt = index_date) %>%
    # drop intermediate / helper columns
    # 5B.ClinChars row 88 says to keep the interim dates used to build
    # FU_ENDDT_preliminary, and row 90 says to keep DATEOFDEATH, so those stay.
    # Only the internal scratch columns are dropped.
    select(all_of(ads_columns)) %>%
    distinct()
}

# Build each cohort's ADS and bind into one
for (coh_flag in coh_list) {
  var_name <- paste0("enh_pros_pano_", coh_flag, "_coh_tbl")
  df <- overall_ads_creation(coh_flag)
  createInPersonalSchema(df, stage_name(var_name), replace = TRUE)
  # Rebind to the materialized table, not the lazy query. Keeping the lazy
  # object makes every downstream stage re-expand the whole upstream query, so
  # the final ADS becomes one huge nested SELECT and the writes are paid for
  # without ever being read.
  assign(var_name, tbl(con, in_schema(personal_schema, stage_name(var_name))))

  if (coh_flag == coh_list[1]) {
    pros_final_ads <- get(var_name)
  } else {
    pros_final_ads <- union_all(pros_final_ads, get(var_name))
  }
  rm(df)
}

# Pre-write gate. The write below is replace = TRUE onto the live table, with
# no staging copy (Q27), so a build that came out EMPTY would destroy the last
# good table before any validation ran. Count the seven materialized cohort
# stages first - they are already written, so this is seven cheap COUNT(*)s,
# not a re-run of the union.
#
# EMPTY ONLY. This does not catch a SHORT build - a cohort that collapsed from
# 79,000 patients to 400 still passes. Catching that needs a baseline to compare
# against, and no build has ever run, so there is no baseline to hold. Set the
# tolerances after the first accepted run; until then read qc/04 attrition.
#
# Skipped under the offline harness, where every source frame is empty by
# design and a zero count means nothing.
if (!identical(personal_schema, "sim_personal")) {
  coh_rows <- vapply(coh_list, function(cf) {
    n <- get(paste0("enh_pros_pano_", cf, "_coh_tbl")) %>% tally() %>% collect()
    as.numeric(n$n[1])
  }, numeric(1))
  names(coh_rows) <- coh_list
  message("pre-write gate: ", paste(names(coh_rows), format(coh_rows, big.mark = ","),
                                    sep = "=", collapse = "  "))
  empty <- names(coh_rows)[coh_rows == 0]
  if (length(empty)) {
    stop("BUILD REFUSED - no rows for cohort(s): ", paste(empty, collapse = ", "),
         ". ", output_table, " is UNCHANGED. Check the preflight output and the ",
         "source refresh before rerunning.", call. = FALSE)
  }
}

# Write the deliverable. There is no staging copy and no publish step.
createInPersonalSchema(pros_final_ads, output_table, replace = TRUE)

message("built ", output_table, " (", length(ads_columns), " columns, ",
        length(coh_list), " cohorts). This table is LIVE - run the output ",
        "validation now.")

# =============================================================================
# Run manifest
# =============================================================================
# Output validation V2b asks which HRR panel produced the table. That is not
# recoverable from the table: HRR_INDEX is a collapsed status and looks equally
# plausible under all three panels. The manifest is the record.
manifest <- c(
  paste0("built_at            ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("program_version     ", program_version),
  paste0("source_namespace    ", dbname),
  paste0("output_table        ", personal_schema, ".", output_table),
  paste0("datav               ", datav),
  paste0("rawrwd              ", rawrwd),
  paste0("source_refresh      ", refresh),
  paste0("index_window        ", index_start, " .. ", index_end),
  paste0("cohorts             ", length(coh_list)),
  paste0("columns             ", length(ads_columns)),
  paste0("hrr_panel  (Q05)    ", hrr_panel_mode,
         "  (", length(hrr_genes), " genes)"),
  paste0("preflight_gates     ", preflight_status),
  paste0("R                   ", R.version.string),
  paste0("dbplyr              ", as.character(utils::packageVersion("dbplyr"))),
  paste0("dplyr               ", as.character(utils::packageVersion("dplyr"))),
  "qc_status           NOT VALIDATED - the table is live; validate it now")

writeLines(manifest, manifest_file)
message("\n---- run manifest (also written to ", manifest_file, ") ----\n",
        paste(manifest, collapse = "\n"),
        "\n----------------------------------------------------------------")
