#!/usr/bin/env Rscript
# July-20 study-team questions Q2 + Q3 -> CSVs, summaries and one Excel workbook.
#
#   Rscript jul20_studyteam_qs.R
#
# Q1 (the dashboard refresh) is in jul20_refresh_dashboard.R. The workbook
# needs openxlsx and degrades to CSV-only with a note if it is absent. Nothing
# permanent is written - session temp views only, safe to run any time.
#
# Population: LOT_LONG_FINAL, the study population, which is the cohort the
# question names. LOT_POPULATION=PRECRITERIA gives the run before the line
# criteria. Run the pair with the population stated:
#   LOT_POPULATION=FINAL Rscript jul20_refresh_dashboard.R
#   LOT_POPULATION=FINAL Rscript jul20_studyteam_qs.R
#
# Q2 - 1L DARA+BORT dual therapy. EXACTLY those two agents in the LOT1
#   regimen, no other MM agent. Steroids never enter the regimen strings, so
#   they do not change the pairing; a context file counts the broader
#   "contains both, possibly with others" group beside it.
#
#   Outputs: one row per patient (diagnosis date, drug episodes, medical
#   service dates, pharmacy fills, 2L regimen, region, payer), per-episode MAP
#   files during and after LOT1, and summaries for 2L, diagnosis year and
#   region x payer.
#
#   Measures are named for what claims can show. Protocol CYCLES are not in
#   claims, so these are drug episodes, medical service dates and fill dates.
#
#   Region comes only from an approved source - REGION_SOURCE_TABLE and
#   REGION_SOURCE_COLUMN. Unset, region is reported unavailable and a
#   candidate-columns file lists geographic-looking columns to approve. Values
#   pass through untouched unless REGION_MAP=CENSUS, which rolls a STATE field
#   up to the four US Census regions (DC in South) as Optum does; anything
#   else stays visible as Other/Unmapped.
#
#   Payer is the Optum line of business (member_enrollment.BUS) on the span
#   covering the LOT1 start - the dashboard's anchor. MCR = Medicare, COM =
#   Commercial, blank = Unknown. Payer at diagnosis or across LOT1 is a
#   different anchor, and the definitions file says so.
#
# Q3 - PRELIMINARY screen of two candidate LOT-rule changes. Read-only over the
#   persisted tables, NOT an engine re-run, so its counts are not the exact
#   impact of either rule: moving a boundary changes induction windows,
#   regimens, discontinuation dates, transplant classification and every later
#   line. Only a scenario re-run can give exact numbers.
#
#   (a) MELP: the line transitions attributable to melphalan, bucketed by
#       timing against the line's first MELP MAP. The rule as written is
#       ambiguous - both branches keep MELP inside the line, so read literally
#       no MELP ever advances a line. The summary lists what the study team has
#       to settle first.
#   (b) CAR-T: every patient whose first CAR-T falls inside the LOT1 induction
#       window (60 days; an override is flagged as a gap because the rule names
#       60), classified by how the engine handled it. The fold-back merge is
#       computed for patients whose LOT1 ended by the CAR-T and whose LOT2 is
#       CART-started; the other groups stay visible and flagged.
#
# Every run writes a validation summary (reconciliation checks, definition
# audits, category sums, cross-tab totals) and a run-status file: either
# TECHNICALLY COMPLETE - PENDING MANUAL REVIEW, or INCOMPLETE with reasons.

.script_dir <- local({
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg) > 0)
    return(dirname(normalizePath(sub("^--file=", "", file_arg[1]))))
  for (i in seq_len(sys.nframe())) {
    ofile <- tryCatch(sys.frame(i)$ofile, error = function(e) NULL)
    if (!is.null(ofile)) return(dirname(normalizePath(ofile)))
  }
  getwd()
})

source(file.path(.script_dir, "_setup.R"))
qs_setup(.script_dir)
source(file.path(.script_dir, "validation_helpers.R"))        # vqs_* helpers (shared)

`%||%` <- function(a, b) if (is.null(a)) b else a

# Run a pull and return its data, or a one-row "status" table naming the
# failure, so a gap is visible instead of silent.
best_effort <- function(expr, label) {
  r <- tryCatch(expr, error = function(e) {
    log_msg("  NOTE: '", label, "' unavailable - ", conditionMessage(e))
    data.frame(status = sprintf("'%s' unavailable: %s", label, conditionMessage(e)),
               stringsAsFactors = FALSE)
  })
  if (is.null(r))
    data.frame(status = sprintf("'%s' returned no data (unavailable this run)", label),
               stringsAsFactors = FALSE)
  else r
}

is_status_table <- function(x)
  is.data.frame(x) && identical(names(x), "status")

# ===========================================================================
# Consolidated Excel writer (openxlsx). A "sheet" is a list of name, title,
# optional subtitle, narrative lines, and named tables (each a data.frame).
# Same writer as lot_followup_qs.R / poma_studyteam_qs.R. openxlsx must be
# installed; the caller checks and degrades to CSV-only if it is missing.
# ===========================================================================
wbx_write_workbook <- function(sheets, xlsx_path) {
  ox <- function(f) getExportedValue("openxlsx", f)
  wb <- ox("createWorkbook")()
  st_title <- ox("createStyle")(fontSize = 14, textDecoration = "bold",
                                fontColour = "#FFFFFF", fgFill = "#1F3864")
  st_sub   <- ox("createStyle")(fontColour = "#FFFFFF", fgFill = "#2E5496",
                                textDecoration = "italic")
  st_narr  <- ox("createStyle")(wrapText = TRUE, valign = "top")
  st_cap   <- ox("createStyle")(textDecoration = "bold", fgFill = "#D6E0F0")
  st_hdr   <- ox("createStyle")(textDecoration = "bold", fontColour = "#FFFFFF",
                                fgFill = "#2E5496", border = "TopBottomLeftRight",
                                halign = "left")
  for (s in sheets) {
    # Excel forbids \ / ? * [ ] : in sheet names and caps them at 31 chars.
    # Strip each illegal char literally (fixed = TRUE avoids regex-class
    # escaping pitfalls), collapse whitespace, then truncate.
    sn <- s$name
    for (ch in c("\\", "/", "?", "*", "[", "]", ":")) sn <- gsub(ch, " ", sn, fixed = TRUE)
    sn <- substr(trimws(gsub("[[:space:]]+", " ", sn)), 1, 31)
    ox("addWorksheet")(wb, sn)
    r <- 1L
    ox("writeData")(wb, sn, s$title, startRow = r, startCol = 1)
    ox("addStyle")(wb, sn, st_title, rows = r, cols = 1:10, gridExpand = TRUE)
    r <- r + 1L
    if (!is.null(s$subtitle)) {
      ox("writeData")(wb, sn, s$subtitle, startRow = r, startCol = 1)
      ox("addStyle")(wb, sn, st_sub, rows = r, cols = 1:10, gridExpand = TRUE)
      r <- r + 1L
    }
    r <- r + 1L
    for (line in s$narrative %||% character()) {
      ox("writeData")(wb, sn, line, startRow = r, startCol = 1)
      ox("addStyle")(wb, sn, st_narr, rows = r, cols = 1, gridExpand = TRUE)
      r <- r + 1L
    }
    r <- r + 1L
    for (nm in names(s$tables %||% list())) {
      df <- s$tables[[nm]]
      ox("writeData")(wb, sn, nm, startRow = r, startCol = 1)
      ox("addStyle")(wb, sn, st_cap, rows = r, cols = 1:10, gridExpand = TRUE)
      r <- r + 1L
      if (is.data.frame(df) && nrow(df) > 0) {
        ox("writeData")(wb, sn, df, startRow = r, startCol = 1,
                        headerStyle = st_hdr, withFilter = FALSE)
        r <- r + nrow(df) + 2L
      } else {
        ox("writeData")(wb, sn, "(no rows / not available)", startRow = r, startCol = 1)
        r <- r + 2L
      }
    }
    ox("setColWidths")(wb, sn, cols = 1:14, widths = "auto")
  }
  ox("saveWorkbook")(wb, xlsx_path, overwrite = TRUE)
  log_msg("wrote consolidated workbook -> ", xlsx_path, " (", length(sheets), " sheets)")
  invisible(TRUE)
}

num <- function(x) suppressWarnings(as.numeric(x))
pct1 <- function(x, d) if (isTRUE(num(d) > 0)) round(100 * num(x) / num(d), 1) else NA_real_

# ---------------------------------------------------------------------------
# Drug tokens (DARA/BORT/MELP) resolved from cl_mma_codelist.csv by full drug
# name; resolved = TRUE only when every code came from the codelist.
# ---------------------------------------------------------------------------
resolve_jul20_tokens <- function(con) {
  out <- list(dara = "DARA", bort = "BORT", melp = "MELP",
              notes = character(0), resolved = FALSE)
  ok <- tryCatch({ vqs_build_mma_codelist(con); TRUE }, error = function(e) FALSE)
  if (!ok) {
    out$notes <- "mma_codelist unavailable; using default tokens (DARA/BORT/MELP)."
    return(out)
  }
  fell_back <- character()
  pick <- function(name, like, dflt) {
    df <- tryCatch(db_q(con, glue("
      SELECT CL_MED_ABBR, count(*) AS n
      FROM mma_codelist
      WHERE lower(CL_MEDICATION_FULL) LIKE '%{like}%'
      GROUP BY CL_MED_ABBR ORDER BY n DESC")), error = function(e) NULL)
    if (is.null(df) || nrow(df) == 0) { fell_back <<- c(fell_back, name); return(dflt) }
    toupper(trimws(df$CL_MED_ABBR[1]))
  }
  out$dara <- pick("DARA", "daratumumab", "DARA")
  out$bort <- pick("BORT", "bortezomib",  "BORT")
  out$melp <- pick("MELP", "melphalan",   "MELP")
  out$resolved <- length(fell_back) == 0
  if (length(fell_back))
    out$notes <- sprintf("Some tokens not found in cl_mma_codelist.csv (fell back to defaults for: %s). Tokens: DARA=%s, BORT=%s, MELP=%s.",
                         paste(fell_back, collapse = ", "), out$dara, out$bort, out$melp)
  else out$notes <- sprintf("Resolved tokens from cl_mma_codelist.csv: DARA=%s, BORT=%s, MELP=%s.",
                       out$dara, out$bort, out$melp)
  out
}

# The drug codes in a regimen string, dropping blanks.
MEDS_ARR <- "filter(split(LOT_BASE_MEDS, ' '), x -> length(x) > 0)"

# Label used for lines that have no drug regimen (transplant / CAR-T-only).
blank_regimen_sql <- function(meds_col = "LOT_BASE_MEDS", type_col = "LOT_START_TYPE") {
  glue("CASE WHEN {meds_col} IS NULL OR trim({meds_col}) = ''
             THEN concat('(no drug regimen - ', coalesce({type_col}, 'unknown'), ' start)')
             ELSE {meds_col} END")
}

# DESCRIBE-based column discovery (same pattern as lot1_studyteam_qs.R).
make_describe_cols <- function(con) {
  function(tbl) {
    d <- tryCatch(db_q(con, glue("DESCRIBE TABLE {tbl}")), error = function(e) NULL)
    if (is.null(d) || !"col_name" %in% names(d)) return(character(0))
    cn <- trimws(as.character(d$col_name))
    cn <- cn[nzchar(cn) & !startsWith(cn, "#")]
    unique(cn)
  }
}

# ---------------------------------------------------------------------------
# US Census Bureau state -> region rollup (opt-in via REGION_MAP=CENSUS), for
# when the approved region source is a STATE field rather than a REGION field.
# This reproduces Optum's own REGION derivation ("the US Census Region
# associated with the member"). DC is in the South, per the Census Bureau.
# The map is keyed on BOTH the 2-letter USPS code and the full state name, so
# either encoding resolves; any value that is neither is left visible as
# 'Other/Unmapped' (territories, military, junk) rather than silently bucketed.
# ---------------------------------------------------------------------------
CENSUS_REGIONS <- list(
  Northeast = c("CT","ME","MA","NH","RI","VT","NJ","NY","PA"),
  Midwest   = c("IL","IN","MI","OH","WI","IA","KS","MN","MO","NE","ND","SD"),
  South     = c("DE","FL","GA","MD","NC","SC","VA","DC","WV","AL","KY","MS","TN","AR","LA","OK","TX"),
  West      = c("AZ","CO","ID","MT","NV","NM","UT","WY","AK","CA","HI","OR","WA"))
STATE_ABBR_NAME <- c(
  AL="ALABAMA", AK="ALASKA", AZ="ARIZONA", AR="ARKANSAS", CA="CALIFORNIA",
  CO="COLORADO", CT="CONNECTICUT", DE="DELAWARE", DC="DISTRICT OF COLUMBIA",
  FL="FLORIDA", GA="GEORGIA", HI="HAWAII", ID="IDAHO", IL="ILLINOIS",
  IN="INDIANA", IA="IOWA", KS="KANSAS", KY="KENTUCKY", LA="LOUISIANA",
  ME="MAINE", MD="MARYLAND", MA="MASSACHUSETTS", MI="MICHIGAN", MN="MINNESOTA",
  MS="MISSISSIPPI", MO="MISSOURI", MT="MONTANA", NE="NEBRASKA", NV="NEVADA",
  NH="NEW HAMPSHIRE", NJ="NEW JERSEY", NM="NEW MEXICO", NY="NEW YORK",
  NC="NORTH CAROLINA", ND="NORTH DAKOTA", OH="OHIO", OK="OKLAHOMA", OR="OREGON",
  PA="PENNSYLVANIA", RI="RHODE ISLAND", SC="SOUTH CAROLINA", SD="SOUTH DAKOTA",
  TN="TENNESSEE", TX="TEXAS", UT="UTAH", VT="VERMONT", VA="VIRGINIA",
  WA="WASHINGTON", WV="WEST VIRGINIA", WI="WISCONSIN", WY="WYOMING")

# Build a Spark SQL CASE mapping a state-value expression to its Census region.
census_state_region_case <- function(val_expr) {
  norm <- glue("upper(trim(cast({val_expr} as string)))")
  whens <- vapply(names(CENSUS_REGIONS), function(reg) {
    abbrs <- CENSUS_REGIONS[[reg]]
    toks  <- unique(c(abbrs, unname(STATE_ABBR_NAME[abbrs])))
    inlist <- paste(sprintf("'%s'", toks), collapse = ", ")
    glue("WHEN {norm} IN ({inlist}) THEN '{reg}'")
  }, character(1))
  glue("CASE
          {paste(whens, collapse = '\n          ')}
          WHEN {norm} IS NULL OR {norm} = '' THEN 'Unknown'
          ELSE 'Other/Unmapped'
        END")
}

# ===========================================================================
# Q2 setup - the 1L DARA+BORT exact-dual cohort as a temp view, plus the
# exact-vs-contains-both context counts.
# ===========================================================================
q2_build_dual_view <- function(con, lot_long, dara, bort) {
  db_exec(con, glue("
    CREATE OR REPLACE TEMPORARY VIEW _jul20_dual AS
    WITH l1 AS (
      SELECT cast(PATID as string) AS PATID,
             cast(LOT_START_DT as date)    AS L1,
             cast(LOT_BASE_END_DT as date) AS L1_END,
             LOT_BASE_END_REASON           AS L1_END_REASON,
             {MEDS_ARR} AS meds
      FROM {lot_long}
      WHERE LOT_NUM = 1 AND LOT_BASE_MEDS IS NOT NULL AND trim(LOT_BASE_MEDS) <> ''
    )
    SELECT PATID, L1, L1_END, L1_END_REASON,
           coalesce(L1_END, cast('9999-12-31' as date)) AS L1_CAP
    FROM l1
    WHERE size(meds) = 2 AND array_contains(meds, '{dara}')
      AND array_contains(meds, '{bort}')"))
  num(db_q(con, "SELECT count(*) AS n FROM _jul20_dual")$n[1])
}

q2_context_counts <- function(con, lot_long, dara, bort) {
  d <- db_q(con, glue("
    WITH l1 AS (
      SELECT cast(PATID as string) AS PATID, {MEDS_ARR} AS meds
      FROM {lot_long}
      WHERE LOT_NUM = 1 AND LOT_BASE_MEDS IS NOT NULL AND trim(LOT_BASE_MEDS) <> ''
    )
    SELECT
      count(DISTINCT PATID) AS n_lot1_with_drug_regimen,
      count(DISTINCT CASE WHEN size(meds) = 2 AND array_contains(meds, '{dara}')
                           AND array_contains(meds, '{bort}') THEN PATID END)
                            AS n_exact_dara_bort_dual,
      count(DISTINCT CASE WHEN array_contains(meds, '{dara}')
                           AND array_contains(meds, '{bort}') THEN PATID END)
                            AS n_contains_dara_and_bort_any
  FROM l1"))
  data.frame(
    group = c(
      "LOT1 patients with a drug regimen (context denominator)",
      "EXACT DARA+BORT dual therapy (the Q2 cohort: regimen is exactly the two agents, no other MM agent)",
      "LOT1 regimen CONTAINS both DARA and BORT, possibly with other agents (context only)"),
    n_patients = c(as.integer(num(d$n_lot1_with_drug_regimen[1])),
                   as.integer(num(d$n_exact_dara_bort_dual[1])),
                   as.integer(num(d$n_contains_dara_and_bort_any[1]))),
    stringsAsFactors = FALSE)
}

# Per-patient-per-agent drug-episode (MAP) summary inside LOT1.
q2_build_agent_views <- function(con, map_tbl, dara, bort) {
  db_exec(con, glue("
    CREATE OR REPLACE TEMPORARY VIEW _jul20_dual_agent AS
    SELECT d.PATID,
           upper(trim(m.MAP_MED_TYPE)) AS agent,
           count(*)                          AS n_episodes,
           min(cast(m.MAP_START_DT as date)) AS first_episode_start,
           max(cast(m.MAP_END_DT as date))   AS last_episode_end,
           sum(datediff(least(cast(m.MAP_END_DT as date), d.L1_CAP),
                        cast(m.MAP_START_DT as date)) + 1) AS days_covered_in_lot1
    FROM {map_tbl} m
    JOIN _jul20_dual d ON cast(m.PATID as string) = d.PATID
    WHERE upper(trim(m.MAP_MED_TYPE)) IN ('{dara}', '{bort}')
      AND cast(m.MAP_START_DT as date) BETWEEN d.L1 AND d.L1_CAP
    GROUP BY d.PATID, upper(trim(m.MAP_MED_TYPE))"))
  invisible(TRUE)
}

# Per-patient-per-agent service-date counts inside LOT1. MMA_MED_PROCESSED is
# deduplicated to one row per patient + agent + service date + claim type, so
# these are counts of distinct medication service dates / fill dates - NOT
# administrations and NOT cycles.
q2_build_claim_view <- function(con, mma_tbl, dara, bort) {
  db_exec(con, glue("
    CREATE OR REPLACE TEMPORARY VIEW _jul20_dual_claims AS
    SELECT d.PATID,
           upper(trim(c.MED_ABBR)) AS agent,
           sum(CASE WHEN lower(c.CLAIM_TYPE) = 'medical'  THEN 1 ELSE 0 END) AS n_medical_service_dates,
           sum(CASE WHEN lower(c.CLAIM_TYPE) = 'pharmacy' THEN 1 ELSE 0 END) AS n_pharmacy_fill_dates
    FROM {mma_tbl} c
    JOIN _jul20_dual d ON cast(c.PATID as string) = d.PATID
    WHERE upper(trim(c.MED_ABBR)) IN ('{dara}', '{bort}')
      AND cast(c.DATE_SERVICE as date) BETWEEN d.L1 AND d.L1_CAP
    GROUP BY d.PATID, upper(trim(c.MED_ABBR))"))
  invisible(TRUE)
}

# ===========================================================================
# Q2a - utilization per agent: episode (MAP) and service-date summaries.
# ===========================================================================
q2_utilization_summary <- function(con, have_claims) {
  summ <- db_q(con, "
    SELECT agent,
           count(*)                              AS n_patients,
           percentile_approx(n_episodes, 0.5)    AS median_episodes,
           percentile_approx(n_episodes, 0.25)   AS p25_episodes,
           percentile_approx(n_episodes, 0.75)   AS p75_episodes,
           max(n_episodes)                       AS max_episodes,
           percentile_approx(days_covered_in_lot1, 0.5) AS median_days_covered
    FROM _jul20_dual_agent GROUP BY agent ORDER BY agent")

  dist <- db_q(con, "
    SELECT agent,
           CASE WHEN n_episodes >= 5 THEN '5+'
                ELSE cast(n_episodes as string) END AS n_episodes_bucket,
           count(*) AS n_patients
    FROM _jul20_dual_agent
    GROUP BY agent, CASE WHEN n_episodes >= 5 THEN '5+'
                         ELSE cast(n_episodes as string) END
    ORDER BY agent, n_episodes_bucket")

  out <- list(summary = summ, distribution = dist)
  if (have_claims) {
    out$service_dates <- db_q(con, "
      SELECT agent,
             count(*)                                        AS n_patients,
             percentile_approx(n_medical_service_dates, 0.5)  AS median_medical_service_dates,
             percentile_approx(n_medical_service_dates, 0.25) AS p25_medical_service_dates,
             percentile_approx(n_medical_service_dates, 0.75) AS p75_medical_service_dates,
             max(n_medical_service_dates)                     AS max_medical_service_dates,
             percentile_approx(n_pharmacy_fill_dates, 0.5)    AS median_pharmacy_fill_dates,
             max(n_pharmacy_fill_dates)                       AS max_pharmacy_fill_dates
      FROM _jul20_dual_claims GROUP BY agent ORDER BY agent")
  }
  out
}

# ===========================================================================
# Q2b - what the DARA+BORT patients receive in 2L (all regimens, plus a
# "(no 2L observed)" row so the denominator stays the full dual cohort).
# ===========================================================================
q2_lot2_regimens <- function(con, lot_long, n_dual) {
  d <- db_q(con, glue("
    WITH l2 AS (
      SELECT cast(PATID as string) AS PATID,
             {blank_regimen_sql()} AS regimen
      FROM {lot_long} WHERE LOT_NUM = 2
    )
    SELECT CASE WHEN l2.PATID IS NULL THEN '(no 2L observed)'
                ELSE l2.regimen END AS lot2_regimen,
           count(DISTINCT d.PATID) AS n_patients
    FROM _jul20_dual d LEFT JOIN l2 ON l2.PATID = d.PATID
    GROUP BY CASE WHEN l2.PATID IS NULL THEN '(no 2L observed)' ELSE l2.regimen END
    ORDER BY n_patients DESC, lot2_regimen"))
  if (nrow(d) == 0)
    return(data.frame(status = "No DARA+BORT dual patients found.", stringsAsFactors = FALSE))
  data.frame(rank = seq_len(nrow(d)),
             lot2_regimen = d$lot2_regimen,
             n_patients = as.integer(num(d$n_patients)),
             pct_of_dual = vapply(num(d$n_patients), function(x) pct1(x, n_dual), numeric(1)),
             stringsAsFactors = FALSE)
}

# ===========================================================================
# Q2c - diagnosis years: INDEX_DATE (the qualifying MM diagnosis date behind
# the Part-1 cohort) by calendar year, with an NA row so the total stays the
# full dual cohort.
# ===========================================================================
q2_diagnosis_years <- function(con, coh_tbl, n_dual) {
  d <- db_q(con, glue("
    SELECT year(cast(e.INDEX_DATE as date)) AS diagnosis_year,
           count(DISTINCT d.PATID)          AS n_patients
    FROM _jul20_dual d
    JOIN {coh_tbl} e ON cast(e.PATID as string) = d.PATID
    WHERE e.INDEX_DATE IS NOT NULL
    GROUP BY year(cast(e.INDEX_DATE as date))
    ORDER BY diagnosis_year"))
  if (nrow(d) == 0)
    return(data.frame(status = "No diagnosis dates found (ELIG_COH_FINAL join returned no rows).",
                      stringsAsFactors = FALSE))
  out <- data.frame(diagnosis_year = as.integer(num(d$diagnosis_year)),
                    n_patients = as.integer(num(d$n_patients)),
                    pct_of_dual = vapply(num(d$n_patients), function(x) pct1(x, n_dual), numeric(1)),
                    stringsAsFactors = FALSE)
  n_matched <- sum(out$n_patients)
  if (n_matched < n_dual)
    out <- rbind(out, data.frame(diagnosis_year = NA_integer_,
                                 n_patients = as.integer(n_dual - n_matched),
                                 pct_of_dual = pct1(n_dual - n_matched, n_dual),
                                 stringsAsFactors = FALSE))
  out
}

# ===========================================================================
# Q2d setup - payer (production derivation, anchored at the LOT1 start) and
# region (ONLY from the explicitly approved env-configured source).
# ===========================================================================
q2_build_payer_view <- function(con, enr) {
  db_exec(con, glue("
    CREATE OR REPLACE TEMPORARY VIEW _jul20_payer AS
    WITH span AS (
      SELECT d.PATID,
             upper(trim(cast(e.BUS as string))) AS bus,
             row_number() OVER (PARTITION BY d.PATID
                                ORDER BY
                                  CASE WHEN cast(e.ELIGEND as date) >= d.L1
                                       THEN 0 ELSE 1 END,
                                  CASE WHEN cast(e.ELIGEND as date) >= d.L1
                                        AND upper(trim(cast(e.BUS as string))) = 'MCR'
                                       THEN 0 ELSE 1 END,
                                  cast(e.ELIGEFF as date) DESC,
                                  cast(e.ELIGEND as date) DESC) AS rn
      FROM _jul20_dual d
      LEFT JOIN {enr} e
        ON cast(e.PATID as string) = d.PATID
       AND cast(e.ELIGEFF as date) <= d.L1
    )
    SELECT PATID,
           CASE WHEN bus = 'MCR' THEN 'Medicare'
                WHEN bus = 'COM' THEN 'Commercial'
                WHEN bus IS NULL OR bus = '' THEN 'Unknown'
                ELSE concat('Other (', bus, ')') END AS payer
    FROM span WHERE rn = 1"))
  invisible(TRUE)
}

# Resolve the approved region source from REGION_SOURCE_TABLE /
# REGION_SOURCE_COLUMN. Returns list(tbl, col, has_spans, reason). No
# automatic column guessing: unset or unusable -> region unavailable.
q2_region_source_from_env <- function(con, describe_cols) {
  tbl_env <- trimws(Sys.getenv("REGION_SOURCE_TABLE", unset = ""))
  col_env <- trimws(Sys.getenv("REGION_SOURCE_COLUMN", unset = ""))
  if (!nzchar(tbl_env) || !nzchar(col_env))
    return(list(tbl = NULL, col = NULL, has_spans = FALSE,
                reason = "REGION_SOURCE_TABLE / REGION_SOURCE_COLUMN not set - region requires an explicitly approved source"))
  cands <- if (grepl("\\.", tbl_env)) tbl_env else {
    c(tryCatch(cdm_src(tbl_env), error = function(e) NULL),
      tryCatch(cdm(tbl_env),     error = function(e) NULL))
  }
  cands <- unique(cands[!vapply(cands, is.null, logical(1))])
  fails <- character(0)
  for (tbl in cands) {
    cols <- describe_cols(tbl)
    if (length(cols) == 0) { fails <- c(fails, paste0(tbl, ": not readable")); next }
    up <- toupper(cols)
    if (!(toupper(col_env) %in% up)) {
      fails <- c(fails, sprintf("%s: column '%s' not present (columns: %s)",
                                tbl, col_env, paste(head(cols, 30), collapse = ", ")))
      next
    }
    return(list(tbl = tbl, col = cols[up == toupper(col_env)][1],
                has_spans = all(c("ELIGEFF", "ELIGEND") %in% up),
                reason = ""))
  }
  list(tbl = NULL, col = NULL, has_spans = FALSE,
       reason = sprintf("no usable source for '%s' (%s)", tbl_env,
                        paste(fails, collapse = "; ")))
}

# Report geographic-looking columns on the enrollment/member tables WITHOUT
# using any of them - so the team can approve one and set the env vars.
q2_region_candidates_report <- function(con, describe_cols) {
  rows <- list()
  for (base in c("member_cont_enrollment", "member_enrollment", "member")) {
    for (namer in list(cdm_src, cdm)) {
      tbl <- tryCatch(namer(base), error = function(e) NULL)
      if (is.null(tbl)) next
      cols <- describe_cols(tbl)
      if (length(cols) == 0) next
      hits <- cols[grepl("REGION|DIVISION|STATE|GEO|ZIP", toupper(cols))]
      if (length(hits))
        rows[[length(rows) + 1]] <- data.frame(
          candidate_table = tbl, candidate_column = hits,
          stringsAsFactors = FALSE)
      break   # first readable naming of this base table is enough
    }
  }
  if (length(rows) == 0)
    return(data.frame(status = "No geographic-looking columns found on the probed enrollment/member tables.",
                      stringsAsFactors = FALSE))
  out <- do.call(rbind, rows)
  out$note <- "candidate only - confirm meaning against the Optum data dictionary, then set REGION_SOURCE_TABLE / REGION_SOURCE_COLUMN"
  out
}

# _jul20_region has TWO columns: region_raw (the source value, e.g. the state
# code) and region (what the crosstab uses). When map_census is TRUE the raw
# value is rolled up to the 4 Census regions; otherwise region = the raw value
# (blank -> 'Unknown'). Keeping both lets the value-counts file audit the map.
q2_build_region_view <- function(con, src, map_census = FALSE) {
  region_final <- if (isTRUE(map_census)) census_state_region_case("region_raw")
    else "CASE WHEN region_raw IS NULL OR region_raw = '' THEN 'Unknown' ELSE region_raw END"
  if (src$has_spans) {
    db_exec(con, glue("
      CREATE OR REPLACE TEMPORARY VIEW _jul20_region AS
      WITH span AS (
        SELECT d.PATID,
               upper(trim(cast(e.{src$col} as string))) AS region_raw,
               row_number() OVER (PARTITION BY d.PATID
                                  ORDER BY
                                    CASE WHEN cast(e.ELIGEND as date) >= d.L1
                                         THEN 0 ELSE 1 END,
                                    cast(e.ELIGEFF as date) DESC,
                                    cast(e.ELIGEND as date) DESC) AS rn
        FROM _jul20_dual d
        LEFT JOIN {src$tbl} e
          ON cast(e.PATID as string) = d.PATID
         AND cast(e.ELIGEFF as date) <= d.L1
      )
      SELECT PATID, region_raw, {region_final} AS region
      FROM span WHERE rn = 1"))
  } else {
    db_exec(con, glue("
      CREATE OR REPLACE TEMPORARY VIEW _jul20_region AS
      WITH vals AS (
        SELECT d.PATID,
               upper(trim(cast(e.{src$col} as string))) AS region_raw,
               count(*) AS n
        FROM _jul20_dual d
        JOIN {src$tbl} e ON cast(e.PATID as string) = d.PATID
        GROUP BY d.PATID, upper(trim(cast(e.{src$col} as string)))
      ),
      ranked AS (
        SELECT PATID, region_raw,
               row_number() OVER (PARTITION BY PATID ORDER BY n DESC, region_raw) AS rn
        FROM vals
      )
      SELECT PATID, region_raw, {region_final} AS region
      FROM ranked WHERE rn = 1"))
  }
  invisible(TRUE)
}

# Source value -> region-used correspondence with counts, for manual
# confirmation of the mapping (any 'Other/Unmapped' rows are visible here).
q2_region_values <- function(con) {
  db_q(con, "
    SELECT region_raw AS region_source_value, region AS region_used,
           count(*) AS n_patients
    FROM _jul20_region GROUP BY region_raw, region ORDER BY n_patients DESC")
}

# ===========================================================================
# Q2d - region x payer cross-tab over the dual cohort.
# ===========================================================================
q2_region_payer_crosstab <- function(con, have_region, have_payer, n_dual) {
  reg_expr <- if (have_region) "coalesce(r.region, 'Unknown')" else "'(region unavailable)'"
  pay_expr <- if (have_payer)  "coalesce(p.payer, 'Unknown')"  else "'(payer unavailable)'"
  joins <- paste(
    if (have_payer)  "LEFT JOIN _jul20_payer p  ON p.PATID = d.PATID" else "",
    if (have_region) "LEFT JOIN _jul20_region r ON r.PATID = d.PATID" else "",
    sep = "\n    ")
  long <- db_q(con, glue("
    SELECT {reg_expr} AS region, {pay_expr} AS payer,
           count(DISTINCT d.PATID) AS n_patients
    FROM _jul20_dual d
    {joins}
    GROUP BY {reg_expr}, {pay_expr}
    ORDER BY region, payer"))
  if (nrow(long) == 0)
    return(list(long = data.frame(status = "No dual patients to cross-tabulate.",
                                  stringsAsFactors = FALSE), wide = NULL))

  long$n_patients <- as.integer(num(long$n_patients))
  long$pct_of_dual <- vapply(long$n_patients, function(x) pct1(x, n_dual), numeric(1))

  regions <- sort(unique(long$region))
  payers  <- sort(unique(long$payer))
  wide <- data.frame(region = regions, stringsAsFactors = FALSE)
  for (p in payers) {
    v <- vapply(regions, function(rg) {
      i <- which(long$region == rg & long$payer == p)
      if (length(i)) long$n_patients[i[1]] else 0L
    }, integer(1))
    wide[[p]] <- v
  }
  wide$row_total <- rowSums(wide[, payers, drop = FALSE])
  tot <- c(region = "TOTAL",
           as.list(colSums(wide[, c(payers, "row_total"), drop = FALSE])))
  wide <- rbind(wide, as.data.frame(tot, stringsAsFactors = FALSE, check.names = FALSE))
  list(long = long, wide = wide)
}

# ===========================================================================
# Q2 - patient-level roster (one row per dual patient).
# ===========================================================================
q2_roster <- function(con, lot_long, coh_tbl, dara, bort,
                      have_claims, have_payer, have_region) {
  claims_sel <- if (have_claims) "
           dc.n_medical_service_dates  AS dara_medical_service_dates,
           dc.n_pharmacy_fill_dates    AS dara_pharmacy_fill_dates,
           bc.n_medical_service_dates  AS bort_medical_service_dates,
           bc.n_pharmacy_fill_dates    AS bort_pharmacy_fill_dates," else "
           cast(NULL as int) AS dara_medical_service_dates,
           cast(NULL as int) AS dara_pharmacy_fill_dates,
           cast(NULL as int) AS bort_medical_service_dates,
           cast(NULL as int) AS bort_pharmacy_fill_dates,"
  claims_join <- if (have_claims) glue("
    LEFT JOIN _jul20_dual_claims dc ON dc.PATID = d.PATID AND dc.agent = '{dara}'
    LEFT JOIN _jul20_dual_claims bc ON bc.PATID = d.PATID AND bc.agent = '{bort}'") else ""
  payer_sel  <- if (have_payer)  "coalesce(p.payer, 'Unknown')"   else "'(unavailable)'"
  payer_join <- if (have_payer)  "LEFT JOIN _jul20_payer p ON p.PATID = d.PATID" else ""
  region_sel  <- if (have_region) "coalesce(r.region, 'Unknown')" else "'(unavailable)'"
  region_join <- if (have_region) "LEFT JOIN _jul20_region r ON r.PATID = d.PATID" else ""

  db_q(con, glue("
    WITH l2 AS (
      SELECT cast(PATID as string) AS PATID,
             cast(LOT_START_DT as date) AS L2_START,
             LOT_START_TYPE AS L2_START_TYPE,
             {blank_regimen_sql()} AS L2_REGIMEN
      FROM {lot_long} WHERE LOT_NUM = 2
    )
    SELECT d.PATID,
           cast(e.INDEX_DATE as string)          AS mm_diagnosis_index_date,
           year(cast(e.INDEX_DATE as date))      AS mm_diagnosis_year,
           e.AGE_INDEX_YR                        AS age_at_index,
           e.GDR_CD                              AS gender,
           cast(d.L1 as string)                  AS lot1_start_dt,
           cast(d.L1_END as string)              AS lot1_end_dt,
           d.L1_END_REASON                       AS lot1_end_reason,
           da.n_episodes                         AS dara_n_episodes,
           cast(da.first_episode_start as string) AS dara_first_episode_start,
           cast(da.last_episode_end as string)   AS dara_last_episode_end,
           da.days_covered_in_lot1               AS dara_days_covered,
           bo.n_episodes                         AS bort_n_episodes,
           cast(bo.first_episode_start as string) AS bort_first_episode_start,
           cast(bo.last_episode_end as string)   AS bort_last_episode_end,
           bo.days_covered_in_lot1               AS bort_days_covered,{claims_sel}
           CASE WHEN l2.PATID IS NULL THEN 0 ELSE 1 END AS has_lot2,
           cast(l2.L2_START as string)           AS lot2_start_dt,
           l2.L2_START_TYPE                      AS lot2_start_type,
           l2.L2_REGIMEN                         AS lot2_regimen,
           {region_sel}                          AS region,
           {payer_sel}                           AS payer
    FROM _jul20_dual d
    LEFT JOIN {coh_tbl} e ON cast(e.PATID as string) = d.PATID
    LEFT JOIN _jul20_dual_agent da ON da.PATID = d.PATID AND da.agent = '{dara}'
    LEFT JOIN _jul20_dual_agent bo ON bo.PATID = d.PATID AND bo.agent = '{bort}'{claims_join}
    LEFT JOIN l2 ON l2.PATID = d.PATID
    {payer_join}
    {region_join}
    ORDER BY d.PATID"))
}

# Per-MAP detail for the dual cohort: every DARA/BORT episode from the LOT1
# start on. The caller splits it into DURING-LOT1 and AFTER-LOT1 files so 1L
# utilization is never mixed with later use.
q2_map_detail <- function(con, map_tbl, dara, bort, w1) {
  db_q(con, glue("
    SELECT d.PATID,
           upper(trim(m.MAP_MED_TYPE))        AS agent,
           m.MAP_CNT                          AS episode_number,
           cast(m.MAP_START_DT as string)     AS map_start_dt,
           cast(m.MAP_END_DT as string)       AS map_end_dt,
           datediff(cast(m.MAP_END_DT as date),
                    cast(m.MAP_START_DT as date)) + 1 AS map_days,
           m.MAP_DISCON_FLG                   AS map_discon_flg,
           CASE WHEN cast(m.MAP_START_DT as date)
                     BETWEEN d.L1 AND date_add(d.L1, {w1} - 1)
                THEN 1 ELSE 0 END             AS starts_in_induction_window,
           CASE WHEN cast(m.MAP_START_DT as date) BETWEEN d.L1 AND d.L1_CAP
                THEN 1 ELSE 0 END             AS starts_in_lot1
    FROM {map_tbl} m
    JOIN _jul20_dual d ON cast(m.PATID as string) = d.PATID
    WHERE upper(trim(m.MAP_MED_TYPE)) IN ('{dara}', '{bort}')
      AND cast(m.MAP_START_DT as date) >= d.L1
    ORDER BY d.PATID, agent, m.MAP_CNT"))
}

# ===========================================================================
# Q3b - CAR-T rule: PRELIMINARY affected-patient screen (not an engine
# re-run). Affected = LOT1 rows ended by a CAR-T whose first CAR-T date falls
# inside [LOT1 start, start + w1 - 1]. The screen shows what folding the
# CART-started LOT2 back into LOT1 would look like; affected patients with no
# LOT2 row are flagged (their merged LOT1 end is not derivable from the
# existing outputs).
# ===========================================================================
q3_cart_screen <- function(con, lot_long, sct_tbl, w1) {
  db_exec(con, glue("
    CREATE OR REPLACE TEMPORARY VIEW _jul20_cart AS
    WITH l1 AS (
      SELECT cast(PATID as string) AS PATID,
             cast(LOT_START_DT as date)    AS L1,
             cast(LOT_BASE_END_DT as date) AS L1_END,
             LOT_BASE_END_REASON           AS END_REASON
      FROM {lot_long} WHERE LOT_NUM = 1
    ),
    sct AS (
      SELECT cast(PATID as string) AS PATID,
             min(cast(FIRST_CART_DT as date)) AS CART_DT
      FROM {sct_tbl} WHERE FIRST_CART_DT IS NOT NULL
      GROUP BY cast(PATID as string)
    ),
    l2 AS (
      SELECT cast(PATID as string) AS PATID,
             cast(LOT_START_DT as date)    AS L2,
             LOT_START_TYPE                AS L2_TYPE,
             {blank_regimen_sql()}         AS L2_REGIMEN,
             cast(LOT_BASE_END_DT as date) AS L2_END,
             LOT_BASE_END_REASON           AS L2_END_REASON
      FROM {lot_long} WHERE LOT_NUM = 2
    ),
    cnt AS (
      SELECT cast(PATID as string) AS PATID, count(*) AS n_lots
      FROM {lot_long} GROUP BY cast(PATID as string)
    )
    SELECT l.PATID, l.L1, l.L1_END, l.END_REASON, s.CART_DT,
           datediff(s.CART_DT, l.L1) AS days_from_lot1_start,
           CASE WHEN s.CART_DT IS NOT NULL
                 AND s.CART_DT BETWEEN l.L1 AND date_add(l.L1, {w1} - 1)
                THEN 1 ELSE 0 END AS cart_in_window,
           CASE WHEN l.END_REASON IN ('SCT_CART', 'CART_INIT')
                THEN 1 ELSE 0 END AS ended_by_cart,
           l2.L2, l2.L2_TYPE, l2.L2_REGIMEN, l2.L2_END, l2.L2_END_REASON,
           c.n_lots
    FROM l1 l
    LEFT JOIN sct s ON s.PATID = l.PATID
    LEFT JOIN l2  ON l2.PATID  = l.PATID
    LEFT JOIN cnt c ON c.PATID = l.PATID"))

  inv <- db_q(con, glue("
    SELECT
      count(*)                                                          AS n_lot1_patients,
      sum(CASE WHEN CART_DT IS NOT NULL THEN 1 ELSE 0 END)              AS n_any_cart_on_after_lot1,
      sum(cart_in_window)                                               AS n_cart_in_induction_window,
      sum(CASE WHEN cart_in_window = 1 AND ended_by_cart = 1
               THEN 1 ELSE 0 END)                                       AS n_affected_lot1_ended_by_cart,
      sum(CASE WHEN cart_in_window = 1 AND ended_by_cart = 0
               THEN 1 ELSE 0 END)                                       AS n_in_window_not_ending_lot1,
      sum(CASE WHEN cart_in_window = 1 AND ended_by_cart = 1
                AND END_REASON = 'SCT_CART' THEN 1 ELSE 0 END)          AS n_affected_reason_sct_cart,
      sum(CASE WHEN cart_in_window = 1 AND ended_by_cart = 1
                AND END_REASON = 'CART_INIT' THEN 1 ELSE 0 END)         AS n_affected_reason_cart_init,
      sum(CASE WHEN cart_in_window = 1 AND ended_by_cart = 1
                AND L2 IS NOT NULL THEN 1 ELSE 0 END)                   AS n_affected_with_lot2_to_merge,
      sum(CASE WHEN cart_in_window = 1 AND ended_by_cart = 1
                AND L2 IS NULL THEN 1 ELSE 0 END)                       AS n_affected_without_lot2_end_not_derivable,
      sum(CASE WHEN cart_in_window = 1 AND ended_by_cart = 1
                AND L2_TYPE = 'CART' THEN 1 ELSE 0 END)                 AS n_affected_lot2_type_cart,
      sum(CASE WHEN cart_in_window = 1 AND ended_by_cart = 1
                AND L2_TYPE = 'CART' AND L2 <> CART_DT
               THEN 1 ELSE 0 END)                                       AS n_group1_lot2_not_on_cart_date
    FROM _jul20_cart"))

  mid <- max(2L, as.integer(floor(w1 / 2)))
  timing <- db_q(con, glue("
    SELECT first_cart_timing,
           count(*)            AS n_patients,
           sum(ended_by_cart)  AS n_lot1_ended_by_cart
    FROM (
      SELECT CASE
               WHEN CART_DT IS NULL THEN '(no CAR-T on/after LOT1)'
               WHEN days_from_lot1_start = 0 THEN 'day 0 (on the LOT1 start date)'
               WHEN days_from_lot1_start BETWEEN 1 AND {mid - 1} THEN 'day 1-{mid - 1}'
               WHEN days_from_lot1_start BETWEEN {mid} AND {w1 - 1} THEN 'day {mid}-{w1 - 1}'
               ELSE 'day {w1}+ (outside the induction window)'
             END AS first_cart_timing,
             ended_by_cart
      FROM _jul20_cart
    ) t
    GROUP BY first_cart_timing
    ORDER BY first_cart_timing"))

  # The fold-back merge applies only to group 1 (LOT1 ended by the CAR-T and
  # a CART-started LOT2 exists); groups 2-4 stay visible in the roster but do
  # not move in the screened shift.
  shift <- db_q(con, "
    SELECT n_lots,
           count(*) AS n_patients,
           sum(CASE WHEN cart_in_window = 1 AND ended_by_cart = 1
                     AND L2 IS NOT NULL AND L2_TYPE = 'CART'
                    THEN 1 ELSE 0 END) AS n_losing_one_line
    FROM _jul20_cart
    GROUP BY n_lots ORDER BY n_lots")

  # Every in-window CAR-T patient stays in the affected universe, classified
  # by how the current engine handled the CAR-T.
  roster <- db_q(con, "
    SELECT PATID,
           CASE
             WHEN ended_by_cart = 1 AND L2 IS NOT NULL AND L2_TYPE = 'CART'
               THEN '1: LOT1 ended by CAR-T; CART-started LOT2 folds back'
             WHEN ended_by_cart = 1 AND L2 IS NULL
               THEN '2: LOT1 ended by CAR-T; no LOT2 - merged end not derivable'
             WHEN ended_by_cart = 1
               THEN '4: LOT1 ended by CAR-T; LOT2 not CART-started - review individually'
             ELSE '3: in-window CAR-T but LOT1 currently ends for another reason - needs the scenario re-run'
           END AS screen_group,
           cast(L1 as string)      AS lot1_start_dt,
           cast(L1_END as string)  AS lot1_end_dt,
           END_REASON              AS lot1_end_reason,
           cast(CART_DT as string) AS first_cart_dt,
           days_from_lot1_start,
           cast(L2 as string)      AS lot2_start_dt,
           L2_TYPE                 AS lot2_start_type,
           L2_REGIMEN              AS lot2_regimen,
           cast(L2_END as string)  AS lot2_end_dt,
           L2_END_REASON           AS lot2_end_reason,
           CASE WHEN ended_by_cart = 1 AND L2 IS NOT NULL AND L2_TYPE = 'CART'
                THEN cast(L2_END as string)
                ELSE '(not derivable from existing outputs - needs the scenario re-run)' END
                                   AS screened_merged_lot1_end,
           n_lots                  AS n_lots_current,
           CASE WHEN ended_by_cart = 1 AND L2 IS NOT NULL AND L2_TYPE = 'CART'
                THEN n_lots - 1 ELSE n_lots END AS n_lots_screened
    FROM _jul20_cart
    WHERE cart_in_window = 1
    ORDER BY screen_group, PATID")

  list(inventory = inv, timing = timing, shift = shift, roster = roster)
}

# Lines-per-patient distribution, current vs screened merge: affected
# patients with a LOT2 move down one bucket, everyone else is unchanged.
q3_cart_shift_table <- function(shift) {
  if (is_status_table(shift) || nrow(shift) == 0) return(shift)
  lots  <- as.integer(num(shift$n_lots))
  n     <- as.integer(num(shift$n_patients))
  lose  <- as.integer(num(shift$n_losing_one_line))
  mx <- max(lots)
  before <- integer(mx); after <- integer(mx)
  for (i in seq_along(lots)) {
    before[lots[i]] <- before[lots[i]] + n[i]
    after[lots[i]]  <- after[lots[i]] + (n[i] - lose[i])
    tgt <- max(1L, lots[i] - 1L)
    after[tgt] <- after[tgt] + lose[i]
  }
  data.frame(lines_per_patient = seq_len(mx),
             n_patients_current = before,
             n_patients_screened = after,
             change = after - before,
             stringsAsFactors = FALSE)
}

# ===========================================================================
# Q3a - MELP rule: PRELIMINARY boundary screen (not an engine re-run).
# A "MELP boundary" is a line transition attributable to melphalan: the
# earlier line ended MED_ADD with MELP as the added drug, and/or the next
# line is MED-started on the date a MELP MAP begins. Each boundary is
# bucketed by timing against the first MELP MAP of the line it follows,
# because the rule text is ambiguous (see the summary file).
# ===========================================================================
q3_melp_screen <- function(con, lot_long, map_tbl, melp) {
  db_exec(con, glue("
    CREATE OR REPLACE TEMPORARY VIEW _jul20_melp_maps AS
    SELECT cast(PATID as string) AS PATID,
           cast(MAP_START_DT as date) AS MSTART
    FROM {map_tbl}
    WHERE upper(trim(MAP_MED_TYPE)) = '{melp}'"))

  db_exec(con, glue("
    CREATE OR REPLACE TEMPORARY VIEW _jul20_lots AS
    SELECT cast(PATID as string) AS PATID,
           LOT_NUM,
           cast(LOT_START_DT as date)    AS LSTART,
           cast(LOT_BASE_END_DT as date) AS LEND,
           LOT_START_TYPE,
           LOT_BASE_END_REASON,
           upper(trim(coalesce(LOT_BASE_1ST_ADD_MED, ''))) AS ADD_MED,
           cast(LOT_BASE_1ST_ADD_MED_DT as date)           AS ADD_DT,
           coalesce(LOT_TX_AUTO_FLG, 0) AS AUTO_FLG,
           LOT_BASE_MEDS
    FROM {lot_long}"))

  db_exec(con, glue("
    CREATE OR REPLACE TEMPORARY VIEW _jul20_melp_bounds AS
    WITH b AS (
      SELECT p.PATID,
             p.LOT_NUM              AS prev_lot,
             p.LSTART               AS prev_start,
             p.LEND                 AS prev_end,
             p.LOT_BASE_END_REASON  AS prev_end_reason,
             p.LOT_BASE_MEDS        AS prev_regimen,
             p.ADD_DT,
             p.AUTO_FLG             AS prev_auto_flg,
             n.LOT_NUM              AS next_lot,
             n.LSTART               AS next_start,
             n.LOT_START_TYPE       AS next_start_type,
             n.AUTO_FLG             AS next_auto_flg,
             n.LOT_BASE_MEDS        AS next_regimen,
             CASE WHEN p.LOT_BASE_END_REASON = 'MED_ADD' AND p.ADD_MED = '{melp}'
                  THEN 1 ELSE 0 END AS ended_by_melp_add,
             CASE WHEN n.LOT_START_TYPE = 'MED' AND mm.PATID IS NOT NULL
                  THEN 1 ELSE 0 END AS next_starts_on_melp
      FROM _jul20_lots p
      LEFT JOIN _jul20_lots n
        ON n.PATID = p.PATID AND n.LOT_NUM = p.LOT_NUM + 1
      LEFT JOIN (SELECT DISTINCT PATID, MSTART FROM _jul20_melp_maps) mm
        ON mm.PATID = p.PATID AND mm.MSTART = n.LSTART
    ),
    adv AS (
      SELECT *,
             CASE WHEN ended_by_melp_add = 1 THEN date_add(ADD_DT, 1)
                  ELSE next_start END AS adv_melp_start
      FROM b
      WHERE ended_by_melp_add = 1 OR next_starts_on_melp = 1
    ),
    anch AS (
      SELECT a.PATID, a.prev_lot, min(m.MSTART) AS anchor_melp_start
      FROM adv a
      JOIN _jul20_melp_maps m
        ON m.PATID = a.PATID
       AND m.MSTART >= a.prev_start
       AND m.MSTART <  a.adv_melp_start
       AND m.MSTART <= coalesce(a.prev_end, a.adv_melp_start)
      GROUP BY a.PATID, a.prev_lot
    )
    SELECT a.*,
           anch.anchor_melp_start,
           CASE WHEN anch.anchor_melp_start IS NULL THEN NULL
                ELSE datediff(a.adv_melp_start, anch.anchor_melp_start) END AS gap_days,
           CASE
             WHEN anch.anchor_melp_start IS NULL THEN 'first MELP of the line (no earlier MELP anchor)'
             WHEN datediff(a.adv_melp_start, anch.anchor_melp_start) < 60 THEN 'under 60 days'
             WHEN datediff(a.adv_melp_start, anch.anchor_melp_start) <= 180 THEN '60-180 days'
             ELSE 'over 180 days'
           END AS gap_bucket
    FROM adv a
    LEFT JOIN anch ON anch.PATID = a.PATID AND anch.prev_lot = a.prev_lot"))

  totals <- db_q(con, glue("
    SELECT
      (SELECT count(DISTINCT PATID) FROM _jul20_melp_maps
        WHERE PATID IN (SELECT cast(PATID as string) FROM {lot_long}))  AS n_patients_with_melp_map,
      (SELECT count(*) FROM _jul20_melp_bounds)                          AS n_melp_boundaries,
      (SELECT count(DISTINCT PATID) FROM _jul20_melp_bounds)             AS n_patients_with_melp_boundary,
      (SELECT count(*) FROM _jul20_melp_bounds WHERE gap_bucket = '60-180 days')
                                                                         AS n_boundaries_60_180,
      (SELECT count(*) FROM _jul20_melp_bounds WHERE next_lot IS NOT NULL)
                                                                         AS n_boundaries_with_next_line"))

  inv <- db_q(con, "
    SELECT gap_bucket,
           count(*)                                                    AS n_boundaries,
           count(DISTINCT PATID)                                       AS n_patients,
           sum(ended_by_melp_add)                                      AS n_prev_ended_med_add_melp,
           sum(next_starts_on_melp)                                    AS n_next_line_starts_on_melp,
           sum(CASE WHEN prev_auto_flg = 1 OR coalesce(next_auto_flg, 0) = 1
                     OR coalesce(next_start_type, '') = 'SCT_AUTO'
                    THEN 1 ELSE 0 END)                                 AS n_with_transplant_context
    FROM _jul20_melp_bounds
    GROUP BY gap_bucket
    ORDER BY gap_bucket")

  by_line <- db_q(con, "
    SELECT concat('LOT', cast(prev_lot as string), ' -> ',
                  CASE WHEN next_lot IS NULL THEN '(line end only)'
                       ELSE concat('LOT', cast(next_lot as string)) END) AS boundary,
           count(*) AS n_boundaries,
           count(DISTINCT PATID) AS n_patients
    FROM _jul20_melp_bounds
    GROUP BY prev_lot, next_lot
    ORDER BY prev_lot, next_lot")

  # Per-(n_lots, suppressed-count) groups so the caller can regroup patients
  # into a true current-vs-screened lines-per-patient distribution. Only
  # boundaries with a next line reduce the line count when suppressed.
  shift <- db_q(con, glue("
    WITH cnt AS (
      SELECT cast(PATID as string) AS PATID, count(*) AS n_lots
      FROM {lot_long} GROUP BY cast(PATID as string)
    ),
    supp AS (
      SELECT PATID,
             sum(CASE WHEN next_lot IS NOT NULL THEN 1 ELSE 0 END) AS n_supp_literal,
             sum(CASE WHEN next_lot IS NOT NULL AND gap_bucket = '60-180 days'
                      THEN 1 ELSE 0 END)                           AS n_supp_narrow
      FROM _jul20_melp_bounds GROUP BY PATID
    )
    SELECT c.n_lots,
           coalesce(s.n_supp_literal, 0) AS n_supp_literal,
           coalesce(s.n_supp_narrow, 0)  AS n_supp_narrow,
           count(*)                      AS n_patients
    FROM cnt c LEFT JOIN supp s ON s.PATID = c.PATID
    GROUP BY c.n_lots, coalesce(s.n_supp_literal, 0), coalesce(s.n_supp_narrow, 0)
    ORDER BY c.n_lots"))

  roster <- db_q(con, "
    SELECT PATID,
           prev_lot,
           cast(prev_start as string)        AS prev_lot_start_dt,
           cast(prev_end as string)          AS prev_lot_end_dt,
           prev_end_reason,
           prev_regimen,
           ended_by_melp_add,
           next_starts_on_melp,
           next_lot,
           cast(next_start as string)        AS next_lot_start_dt,
           next_start_type,
           next_regimen,
           cast(adv_melp_start as string)    AS advancing_melp_map_start_dt,
           cast(anchor_melp_start as string) AS first_melp_map_in_line_dt,
           gap_days,
           gap_bucket,
           prev_auto_flg,
           coalesce(next_auto_flg, 0)        AS next_auto_flg
    FROM _jul20_melp_bounds
    ORDER BY PATID, prev_lot")

  list(totals = totals, inventory = inv, by_line = by_line,
       shift = shift, roster = roster)
}

# True current-vs-screened lines-per-patient distributions for the MELP
# screen, one column per reading. Per patient: screened lines = current
# lines minus that patient's suppressed boundaries (floored at 1).
q3_melp_shift_table <- function(shift) {
  if (is_status_table(shift) || nrow(shift) == 0) return(shift)
  lots <- as.integer(num(shift$n_lots))
  supl <- as.integer(num(shift$n_supp_literal))
  supn <- as.integer(num(shift$n_supp_narrow))
  n    <- as.integer(num(shift$n_patients))
  mx <- max(lots)
  cur <- integer(mx); lit <- integer(mx); nar <- integer(mx)
  for (i in seq_along(lots)) {
    cur[lots[i]] <- cur[lots[i]] + n[i]
    tl <- max(1L, lots[i] - supl[i]); lit[tl] <- lit[tl] + n[i]
    tn <- max(1L, lots[i] - supn[i]); nar[tn] <- nar[tn] + n[i]
  }
  data.frame(lines_per_patient = seq_len(mx),
             n_patients_current = cur,
             n_patients_screened_literal_reading = lit,
             n_patients_screened_narrow_reading = nar,
             stringsAsFactors = FALSE)
}

# Timeline extracts for the first n boundary patients: their full LOT rows
# and their MELP MAP dates, so the boundaries can be reviewed by hand.
q3_melp_examples <- function(con, n = 10L) {
  ids <- db_q(con, glue("
    SELECT DISTINCT PATID FROM _jul20_melp_bounds ORDER BY PATID LIMIT {as.integer(n)}"))
  if (nrow(ids) == 0)
    return(list(lots = data.frame(status = "No MELP boundary patients to extract.",
                                  stringsAsFactors = FALSE),
                maps = NULL))
  id_list <- paste(sprintf("'%s'", ids$PATID), collapse = ", ")
  lots <- db_q(con, glue("
    SELECT PATID, LOT_NUM,
           cast(LSTART as string) AS lot_start_dt,
           cast(LEND as string)   AS lot_end_dt,
           LOT_START_TYPE         AS lot_start_type,
           LOT_BASE_END_REASON    AS lot_end_reason,
           LOT_BASE_MEDS          AS regimen,
           ADD_MED                AS first_add_med,
           cast(ADD_DT as string) AS first_add_med_dt,
           AUTO_FLG               AS auto_transplant_flg
    FROM _jul20_lots WHERE PATID IN ({id_list})
    ORDER BY PATID, LOT_NUM"))
  maps <- db_q(con, glue("
    SELECT PATID, cast(MSTART as string) AS melp_map_start_dt
    FROM _jul20_melp_maps WHERE PATID IN ({id_list})
    ORDER BY PATID, MSTART"))
  list(lots = lots, maps = maps)
}

# ===========================================================================
main <- function() {
  stop_if_blank(cfg$pwd, "DATABRICKS_PWD environment variable is not set.")

  con <- DBI::dbConnect(odbc::odbc(), dsn = cfg$dsn, pwd = cfg$pwd, timeout = 120)
  on.exit(try(DBI::dbDisconnect(con), silent = TRUE), add = TRUE)

  out_dir <- cfg$output_dir
  if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  stamp <- format(Sys.time(), "%Y%m%d_%H%M%S")

  # ---- Cohort selection --------------------------------------------------
  # NDMM by default - the cohort the July-20 questions name. Both July-20
  # scripts share this default and accept the same values (FULL and OVERALL
  # the same population), so running the pair without env
  # overrides always uses the same population.
  .pop         <- qs_population()
  cohort_mode  <- .pop$mode
  lot_long     <- .pop$table
  cohort_label <- .pop$label
  map_tbl <- qs_tbl("MAP_STACKED")
  sct_tbl <- qs_tbl("LOT1_SCT")
  mma_tbl <- qs_tbl("MMA_MED_PROCESSED")
  coh_tbl <- wrk(cfg$input_cohort_table)

  log_msg(SEP)
  log_msg("July-20 study-team questions Q2+Q3 [", cohort_label, "] -> CSVs + summaries")
  log_msg(SEP)
  if (!vqs_readable(con, lot_long)) {
    stop("Cannot read ", lot_long, ". Run the LOT build for this prefix first.")
  }
  # Readable is not ownership. This script pairs the selected LOT prefix with
  # wrk(cfg$input_cohort_table) itself, and a readable cohort table is no
  # evidence the LOT run used it - nor that the run that last wrote these
  # tables finished.
  qs_check_run_binding(con)
  have_map <- vqs_readable(con, map_tbl)
  have_sct <- vqs_readable(con, sct_tbl)
  have_mma <- vqs_readable(con, mma_tbl)
  have_coh <- vqs_readable(con, coh_tbl)
  if (!have_map) log_msg("WARNING: ", map_tbl, " not readable - Q2 episodes and the Q3a MELP screen cannot be built.")
  if (!have_sct) log_msg("WARNING: ", sct_tbl, " not readable - the Q3b CAR-T screen cannot be built.")
  if (!have_mma) log_msg("NOTE: ", mma_tbl, " not readable - service-date counts will be blank (episodes still reported).")
  if (!have_coh) log_msg("WARNING: ", coh_tbl, " not readable - diagnosis dates cannot be reported.")

  tok <- resolve_jul20_tokens(con)
  log_msg(paste(tok$notes, collapse = " "))

  describe_cols <- make_describe_cols(con)

  # Every table written to CSV is also registered here so the consolidated
  # Excel workbook can be assembled from the same frames at the end.
  wb_reg <- list()
  write_out <- function(df, tag) {
    if (is.null(df) || !is.data.frame(df) || nrow(df) == 0) {
      log_msg("  (", tag, ": no rows to write)")
      return(invisible(NULL))
    }
    f <- file.path(out_dir, paste0("jul20_qs_", tag, "_", tolower(cohort_mode), "_", stamp, ".csv"))
    write.csv(df, f, row.names = FALSE)
    wb_reg[[tag]] <<- df
    log_msg("  wrote ", tag, " -> ", f, " (", nrow(df), " rows)")
    f
  }
  write_text <- function(lines, tag, ext = ".txt") {
    f <- file.path(out_dir, paste0("jul20_qs_", tag, "_", tolower(cohort_mode), "_", stamp, ext))
    writeLines(lines, f)
    log_msg("  wrote ", tag, " -> ", f)
    f
  }

  gaps <- character()
  if (!isTRUE(tok$resolved))
    gaps <- c(gaps,
      "Agent tokens could not be resolved from cl_mma_codelist.csv - fell back to defaults (DARA/BORT/MELP); every token-based answer is unverified")
  # The July-20 CAR-T rule names the 60-day induction window explicitly. The
  # screen uses the environment's configured window (VQS_W1), so an override
  # must be surfaced rather than silently changing what the screen means.
  if (VQS_W1 != 60L)
    gaps <- c(gaps, sprintf(
      "induction window is %d days in this environment but the July-20 CAR-T rule names 60 - confirm the setting before using the Q3b screen", VQS_W1))

  # Automated reconciliation checks collected along the way. flag_only = TRUE
  # records a visible FLAG (a caveat the reader must see) without marking the
  # run incomplete; plain FALSE is a FAIL and forces INCOMPLETE.
  checks <- list()
  add_check <- function(name, ok, detail, flag_only = FALSE) {
    status <- if (is.na(ok)) "SKIPPED"
              else if (ok) "PASS"
              else if (flag_only) "FLAG" else "FAIL"
    checks[[length(checks) + 1L]] <<- data.frame(
      check = name, status = status, detail = detail, stringsAsFactors = FALSE)
    if (identical(status, "FAIL")) {
      log_msg("  CHECK FAIL: ", name, " - ", detail)
      gaps <<- c(gaps, paste0("validation check failed: ", name, " (", detail, ")"))
    }
    if (identical(status, "FLAG"))
      log_msg("  CHECK FLAG: ", name, " - ", detail)
  }

  # Central required-output gate: every answer the study team asked for must either
  # produce real data or force the run INCOMPLETE. A best_effort() status
  # table anywhere in the required set registers a gap here, so "technically
  # complete" can never coexist with a failed required output.
  require_result <- function(x, label) {
    if (is.null(x) || is_status_table(x)) {
      msg <- if (is.data.frame(x) && nrow(x) > 0)
        substr(as.character(x$status[1]), 1, 200) else "no result"
      gaps <<- c(gaps, paste0("required output failed: ", label, " - ", msg))
      return(FALSE)
    }
    TRUE
  }

  n_lot1 <- num(db_q(con, glue(
    "SELECT count(DISTINCT cast(PATID as string)) AS n FROM {lot_long} WHERE LOT_NUM = 1"))$n[1])
  lot_totals <- db_q(con, glue("
    SELECT LOT_NUM, count(DISTINCT cast(PATID as string)) AS n_patients
    FROM {lot_long} GROUP BY LOT_NUM ORDER BY LOT_NUM"))
  log_msg(sprintf("Cohort denominator: LOT1 = %s patients.", format(n_lot1, big.mark = ",")))
  write_out(data.frame(line = paste0("LOT", lot_totals$LOT_NUM),
                       n_patients = as.integer(num(lot_totals$n_patients)),
                       note = "reconcile these against the current NDMM/overall dashboard before sharing",
                       stringsAsFactors = FALSE),
            "lot_totals_for_reconciliation")

  # ======================================================================
  # Q2 - DARA+BORT 1L dual therapy
  # ======================================================================
  dual_res <- best_effort(q2_build_dual_view(con, lot_long, tok$dara, tok$bort),
                          "DARA+BORT dual cohort")
  n_dual <- if (is_status_table(dual_res)) NA_real_ else num(dual_res[1])
  if (length(n_dual) == 0 || is.na(n_dual)) {
    n_dual <- NA_real_
    gaps <- c(gaps, "Q2 could not be built - the DARA+BORT dual cohort view failed")
  }

  have_payer <- FALSE; have_region <- FALSE
  region_note <- ""; payer_note <- ""
  q2_util <- NULL; q2_l2 <- NULL; q2_dx <- NULL
  roster <- NULL; xt <- NULL; q2_zero_note <- NULL

  if (!is.na(n_dual)) {
    log_msg(sprintf("1L exact DARA+BORT dual-therapy patients: %s.", format(n_dual, big.mark = ",")))

    ctx <- best_effort(q2_context_counts(con, lot_long, tok$dara, tok$bort),
                       "exact-dual vs contains-both context")
    write_out(ctx, "dual_definition_and_context")
    require_result(ctx, "Q2 exact-dual vs contains-both context")
    if (!is_status_table(ctx)) {
      n_exact_ctx <- ctx$n_patients[2]
      add_check("dual_definition_consistent", isTRUE(n_exact_ctx == n_dual),
                sprintf("context count %s vs dual view %s", n_exact_ctx, n_dual))
    }

    if (n_dual == 0) {
      # An empty exact-dual cohort is a RESULT, not an error: say so plainly
      # instead of silently omitting the patient-level files.
      q2_zero_note <- paste0(
        "No exact DARA+BORT dual-therapy patients were identified in this cohort. ",
        "This is a result, not an error. The dual_definition_and_context file shows how many ",
        "LOT1 regimens contain both agents alongside other drugs; patient-level Q2 files ",
        "are not produced for an empty cohort.")
      log_msg("RESULT: ", q2_zero_note)
      payer_note  <- "(not derived - zero exact-dual patients)"
      region_note <- "(not derived - zero exact-dual patients)"
      add_check("roster_one_row_per_patient", NA, "skipped - zero exact-dual patients")
    } else {

    have_agent <- FALSE
    if (have_map)
      have_agent <- !is_status_table(best_effort(
        q2_build_agent_views(con, map_tbl, tok$dara, tok$bort), "per-agent episode view"))
    have_claims <- FALSE
    if (have_mma)
      have_claims <- !is_status_table(best_effort(
        q2_build_claim_view(con, mma_tbl, tok$dara, tok$bort), "per-agent service-date view"))
    if (!have_claims)
      gaps <- c(gaps, "Q2a service-date counts unavailable (MMA_MED_PROCESSED unreadable) - episode counts still reported")

    # Payer (documented anchor: enrollment span covering the LOT1 start).
    enr <- tryCatch(cdm_src("member_enrollment"), error = function(e) NULL)
    enr_ok <- !is.null(enr) && isTRUE(tryCatch({
      db_q(con, glue("SELECT BUS, ELIGEFF, ELIGEND FROM {enr} LIMIT 1")); TRUE
    }, error = function(e) FALSE))
    if (enr_ok) {
      have_payer <- !is_status_table(best_effort(q2_build_payer_view(con, enr), "payer lookup"))
      if (have_payer) {
        payer_note <- paste0("Payer = member_enrollment.BUS on the enrollment span covering the ",
                             "LOT1 start (MCR = Medicare, COM = Commercial; Medicare wins overlaps; ",
                             "blank = Unknown; else Other(<BUS>)). Anchor is the LOT1 start date - ",
                             "if payer at diagnosis / across LOT1 / ever is wanted instead, that is a different derivation.")
      } else {
        payer_note <- "The payer lookup could not be built (see the log), so payer is unavailable this run."
        gaps <- c(gaps, "Q2d payer derivation failed - the payer lookup view could not be built")
      }
    } else {
      payer_note <- "member_enrollment.BUS was not readable, so payer is unavailable this run."
      gaps <- c(gaps, "Q2d payer unavailable - member_enrollment.BUS not readable")
    }

    # Region: approved source only; candidates reported for approval.
    write_out(best_effort(q2_region_candidates_report(con, describe_cols),
                          "region candidate columns"), "region_candidate_columns")
    # Opt-in state -> Census region rollup (REGION_MAP=CENSUS). Use it when the
    # approved region source is a STATE field and the ask wants the 4 regions.
    region_map_mode <- toupper(Sys.getenv("REGION_MAP", unset = ""))
    do_census <- region_map_mode %in% c("CENSUS", "CENSUS_REGION", "STATE_TO_CENSUS")
    reg_src <- q2_region_source_from_env(con, describe_cols)
    if (!is.null(reg_src$tbl)) {
      have_region <- !is_status_table(best_effort(q2_build_region_view(con, reg_src, do_census), "region lookup"))
      if (have_region) {
        region_note <- sprintf(
          "Region = %s.%s (approved via REGION_SOURCE_TABLE/REGION_SOURCE_COLUMN; %s). %s Confirm the mapping in the region_value_counts file.",
          reg_src$tbl, reg_src$col,
          if (reg_src$has_spans) "anchored to the enrollment span covering the LOT1 start"
          else "per-patient modal value - the table has no span dates",
          if (do_census) "Values are rolled up to the 4 US Census regions (Northeast/Midwest/South/West; DC in South); any non-state value shows as 'Other/Unmapped'."
          else "Values are passed through untouched (set REGION_MAP=CENSUS to roll a STATE field up to the 4 US Census regions).")
        write_out(best_effort(q2_region_values(con), "region value counts"),
                  "region_value_counts")
      } else {
        region_note <- sprintf(
          "The region lookup on the approved source %s.%s could not be built (see the log), so region is unavailable this run.",
          reg_src$tbl, reg_src$col)
        gaps <- c(gaps, "Q2d region derivation failed - the region lookup view could not be built")
      }
    } else {
      region_note <- paste0("Region unavailable: ", reg_src$reason,
                            ". Candidate columns are listed in the region_candidate_columns file; ",
                            "confirm one against the Optum data dictionary and set the env vars.")
      gaps <- c(gaps, paste0("Q2d region unavailable - ", reg_src$reason))
    }
    log_msg("  ", payer_note)
    log_msg("  ", region_note)

    if (have_agent) {
      # The exact-dual definition came from LOT_BASE_MEDS; the episodes come
      # from the separately persisted MAP_STACKED. Every exact-dual patient
      # must have at least one LOT1 episode of EACH agent - a shortfall means
      # the two persisted tables are out of sync (e.g. a stale MAP_STACKED).
      agt <- best_effort(db_q(con, glue("
        SELECT sum(CASE WHEN agent = '{tok$dara}' THEN 1 ELSE 0 END) AS n_dara_patients,
               sum(CASE WHEN agent = '{tok$bort}' THEN 1 ELSE 0 END) AS n_bort_patients
        FROM _jul20_dual_agent")), "per-agent episode completeness")
      if (!is_status_table(agt)) {
        add_check("every_dual_patient_has_dara_episodes",
                  isTRUE(num(agt$n_dara_patients[1]) == n_dual),
                  sprintf("%s of %d dual patients have a DARA episode in LOT1 (MAP_STACKED may be stale/out of sync if lower)",
                          agt$n_dara_patients[1], as.integer(n_dual)))
        add_check("every_dual_patient_has_bort_episodes",
                  isTRUE(num(agt$n_bort_patients[1]) == n_dual),
                  sprintf("%s of %d dual patients have a BORT episode in LOT1 (MAP_STACKED may be stale/out of sync if lower)",
                          agt$n_bort_patients[1], as.integer(n_dual)))
      }

      q2_util <- best_effort(q2_utilization_summary(con, have_claims), "utilization per agent")
      require_result(q2_util, "Q2a utilization summary")
      if (!is_status_table(q2_util)) {
        write_out(q2_util$summary, "utilization_summary")
        write_out(q2_util$distribution, "episode_distribution")
        if (!is.null(q2_util$service_dates)) write_out(q2_util$service_dates, "service_date_summary")
      } else {
        write_out(q2_util, "utilization_summary")
      }
      roster <- best_effort(q2_roster(con, lot_long, coh_tbl, tok$dara, tok$bort,
                                      have_claims, have_payer, have_region),
                            "DARA+BORT patient roster")
      write_out(roster, "dara_bort_patients")
      if (!is_status_table(roster)) {
        add_check("roster_one_row_per_patient", isTRUE(nrow(roster) == n_dual),
                  sprintf("%d roster rows vs %d dual patients", nrow(roster), as.integer(n_dual)))
      } else {
        add_check("roster_one_row_per_patient", FALSE, "roster could not be built")
      }

      map_detail <- best_effort(q2_map_detail(con, map_tbl, tok$dara, tok$bort, VQS_W1),
                                "DARA+BORT MAP detail")
      require_result(map_detail, "Q2a per-episode MAP detail")
      if (!is_status_table(map_detail)) {
        during <- map_detail[num(map_detail$starts_in_lot1) == 1, , drop = FALSE]
        after  <- map_detail[num(map_detail$starts_in_lot1) != 1, , drop = FALSE]
        write_out(during, "dara_bort_maps_during_lot1")
        write_out(after,  "dara_bort_maps_after_lot1")
        if (!is_status_table(roster)) {
          ep_roster <- sum(num(roster$dara_n_episodes), na.rm = TRUE) +
                       sum(num(roster$bort_n_episodes), na.rm = TRUE)
          add_check("episodes_reconcile_roster_vs_detail",
                    isTRUE(ep_roster == nrow(during)),
                    sprintf("roster episode sum %d vs during-LOT1 detail rows %d",
                            as.integer(ep_roster), nrow(during)))
        }
      } else {
        write_out(map_detail, "dara_bort_maps_during_lot1")
      }
    } else {
      gaps <- c(gaps, "Q2a episodes unavailable - the per-agent episode view could not be built (MAP_STACKED unreadable or view creation failed)")
      add_check("roster_one_row_per_patient", NA, "skipped - per-agent episode view unavailable")
    }

    # Definition audit: every dual patient has exactly the two expected tokens.
    aud <- best_effort(db_q(con, glue("
      WITH l1 AS (
        SELECT cast(PATID as string) AS PATID, {MEDS_ARR} AS meds
        FROM {lot_long}
        WHERE LOT_NUM = 1 AND LOT_BASE_MEDS IS NOT NULL AND trim(LOT_BASE_MEDS) <> ''
      )
      SELECT count(*) AS n_bad
      FROM _jul20_dual d JOIN l1 ON l1.PATID = d.PATID
      WHERE NOT (size(l1.meds) = 2 AND array_contains(l1.meds, '{tok$dara}')
                 AND array_contains(l1.meds, '{tok$bort}'))")), "dual definition audit")
    if (!is_status_table(aud))
      add_check("dual_definition_audit_exact_two_tokens",
                isTRUE(num(aud$n_bad[1]) == 0),
                sprintf("%s patient(s) violate the exact-two-token definition", aud$n_bad[1]))

    q2_l2 <- best_effort(q2_lot2_regimens(con, lot_long, n_dual), "2L regimens of the dual cohort")
    write_out(q2_l2, "lot2_regimens")
    require_result(q2_l2, "Q2b 2L regimen distribution")
    if (!is_status_table(q2_l2))
      add_check("lot2_categories_sum_to_dual",
                isTRUE(sum(q2_l2$n_patients) == n_dual),
                sprintf("2L category sum %d vs %d dual patients",
                        sum(q2_l2$n_patients), as.integer(n_dual)))

    if (have_coh) {
      q2_dx <- best_effort(q2_diagnosis_years(con, coh_tbl, n_dual), "diagnosis years")
      write_out(q2_dx, "diagnosis_years")
      require_result(q2_dx, "Q2c diagnosis years")
      if (!is_status_table(q2_dx))
        add_check("diagnosis_years_sum_to_dual",
                  isTRUE(sum(q2_dx$n_patients) == n_dual),
                  sprintf("diagnosis-year sum %d (incl. missing) vs %d dual patients",
                          sum(q2_dx$n_patients), as.integer(n_dual)))
    } else {
      gaps <- c(gaps, "Q2c diagnosis dates unavailable - ELIG_COH_FINAL unreadable")
    }

    xt <- best_effort(q2_region_payer_crosstab(con, have_region, have_payer, n_dual),
                      "region x payer crosstab")
    require_result(xt, "Q2d region x payer cross-tab")
    if (!is_status_table(xt)) {
      write_out(xt$long, "region_payer_counts")
      if (!is.null(xt$wide)) write_out(xt$wide, "region_payer_grid")
      add_check("crosstab_sums_to_dual",
                isTRUE(sum(xt$long$n_patients) == n_dual),
                sprintf("crosstab sum %d vs %d dual patients",
                        sum(xt$long$n_patients), as.integer(n_dual)))
    }
    }   # end n_dual > 0
  }

  # ======================================================================
  # Q3 - PRELIMINARY rule screens
  # ======================================================================
  cart <- if (have_sct)
    best_effort(q3_cart_screen(con, lot_long, sct_tbl, VQS_W1), "CAR-T rule screen")
  else data.frame(status = paste0(sct_tbl, " not readable - LOT1_SCT (FIRST_CART_DT) is required."),
                  stringsAsFactors = FALSE)
  if (!is_status_table(cart)) {
    write_out(cart$inventory, "cart_rule_inventory")
    write_out(cart$timing, "cart_rule_timing")
    write_out(q3_cart_shift_table(cart$shift), "cart_rule_lines_shift")
    write_out(cart$roster, "cart_rule_affected_patients")
    inv <- cart$inventory
    n_group3 <- num(inv$n_in_window_not_ending_lot1[1])
    n_group4 <- num(inv$n_affected_with_lot2_to_merge[1]) -
                num(inv$n_affected_lot2_type_cart[1])
    n_bad_l2_date <- num(inv$n_group1_lot2_not_on_cart_date[1])
    add_check("cart_screened_shift_covers_all_in_window_patients",
              isTRUE(!is.na(n_group3) && n_group3 == 0),
              sprintf("%s in-window CAR-T patient(s) whose LOT1 currently ends for another reason (group 3) - in the roster but outside the fold-back shift; the scenario re-run must cover them",
                      n_group3),
              flag_only = TRUE)
    add_check("cart_group4_lot2_not_cart_started",
              isTRUE(!is.na(n_group4) && n_group4 == 0),
              sprintf("%s patient(s) whose LOT1 ended by CAR-T but LOT2 is not CART-started (group 4; e.g. a same-day higher-priority transplant) - excluded from the fold-back, review individually",
                      n_group4),
              flag_only = TRUE)
    add_check("cart_group1_lot2_starts_on_cart_date",
              isTRUE(!is.na(n_bad_l2_date) && n_bad_l2_date == 0),
              sprintf("%s group-1 patient(s) whose CART-started LOT2 does not start on the first CAR-T date - engine-output inconsistency, investigate",
                      n_bad_l2_date))
  } else {
    write_out(cart, "cart_rule_inventory")
    gaps <- c(gaps, paste0("Q3b CAR-T screen unavailable - ",
                           substr(as.character(cart$status[1]), 1, 200)))
  }

  melp <- if (have_map)
    best_effort(q3_melp_screen(con, lot_long, map_tbl, tok$melp), "MELP rule screen")
  else data.frame(status = paste0(map_tbl, " not readable - MAP_STACKED is required."),
                  stringsAsFactors = FALSE)
  if (!is_status_table(melp)) {
    write_out(melp$totals, "melp_rule_totals")
    write_out(melp$inventory, "melp_rule_inventory")
    write_out(melp$by_line, "melp_rule_by_line")
    write_out(q3_melp_shift_table(melp$shift), "melp_rule_lines_shift")
    write_out(melp$roster, "melp_rule_boundaries")
    ex <- best_effort(q3_melp_examples(con, 10L), "MELP example timelines")
    if (!is_status_table(ex)) {
      write_out(ex$lots, "melp_rule_example_lots")
      write_out(ex$maps, "melp_rule_example_maps")
    }
  } else {
    write_out(melp, "melp_rule_totals")
    gaps <- c(gaps, paste0("Q3a MELP screen unavailable - ",
                           substr(as.character(melp$status[1]), 1, 200)))
  }

  # ======================================================================
  # Summary, definitions, validation, run status
  # ======================================================================
  fmt_or_na <- function(x) if (length(x) == 0 || is.na(x)) "(unavailable)" else format(x, big.mark = ",")
  summary_lines <- c(
    paste0("July-20 study-team questions Q2+Q3 - ", cohort_label),
    paste0("Generated ", stamp, " by jul20_studyteam_qs.R against ", cfg$work_schema, "."),
    paste0("Q1 (the dashboard refresh) is produced separately by jul20_refresh_dashboard.R."),
    "",
    "== Q2: 1L DARA+BORT dual therapy ==",
    paste0("Cohort definition: LOT1 regimen is EXACTLY daratumumab + bortezomib (tokens ",
           tok$dara, " + ", tok$bort, ") - no other MM agent. Steroids never enter the regimen strings."),
    paste0("Exact-dual patients: ", fmt_or_na(n_dual),
           " (the dual_definition_and_context file shows the broader contains-both count)."),
    if (!is.null(q2_zero_note)) q2_zero_note else NULL,
    "Utilization is reported as drug episodes (MAPs), medical service dates and pharmacy fill dates - protocol cycles are not recorded in claims.",
    payer_note,
    region_note,
    "",
    "== Q3: PRELIMINARY rule screens - NOT an engine re-run ==",
    "These screens identify the patients and line boundaries the two candidate rules would touch, from the already-derived LOT output. They do not re-derive lines: moving a boundary changes induction windows, regimens, discontinuation dates, add-med picks, transplant classification and every later line. Exact numbers need an isolated scenario re-run of the LOT derivation (separate scenario output tables; production untouched) once the rules are confirmed.",
    "",
    "-- (a) MELP 60-180-day rule --",
    "The rule as written is ambiguous: 'if a MELP occurs >=60 and <=180 days after the start of the first MELP MAP in a LOT, it does not advance the LOT; otherwise MELP should be treated as part of the LOT.' Read literally, BOTH branches keep MELP inside the line, so no MELP would ever advance a line. Before a scenario is built the study team needs to confirm:",
    "  1. Does the rule apply only to repeated MELP episodes 60-180 days apart, or to every MELP?",
    "  2. Is it restricted to an autologous-transplant (conditioning) context?",
    "  3. Is the anchor the first MELP MAP of the line, or",
    "  4. ... the transplant date?",
    "  5. Does it apply to one specific line (e.g. LOT1) or",
    "  6. ... to all lines?",
    "The melp_rule_inventory file buckets every MELP-attributable boundary by timing against the first MELP MAP of its line (including 'no earlier MELP' rows), so each candidate reading can be sized from the same table. The lines-shift file shows the current lines-per-patient distribution next to the screened distributions under the literal and the narrow (60-180-day-only) readings.",
    "",
    "-- (b) CAR-T induction-window rule --",
    sprintf(paste0(
      "Under the current engine a CAR-T occurring while LOT1 is open ends it the day before ",
      "(SCT_CART, or CART_INIT when it lands within %d days of an added agent) and opens a ",
      "CART-started LOT2. The screen covers EVERY patient whose first CAR-T falls inside the ",
      "%d-day induction window (LOT1 start .. start+%dd) and classifies them: ",
      "(1) LOT1 ended by the CAR-T and a CART-started LOT2 exists - the fold-back merge is computed for these; ",
      "(2) LOT1 ended by the CAR-T but no LOT2 row exists - the merged end is not derivable from existing outputs; ",
      "(3) the CAR-T is in-window but LOT1 currently ends for another reason - the rule may still touch these patients, and only the scenario re-run can say how; ",
      "(4) LOT1 ended by the CAR-T but LOT2 is not CART-started (e.g. a same-day higher-priority transplant) - excluded from the fold-back. ",
      "Groups 2-4 are flagged in the validation summary; the lines-per-patient shift covers group 1 only and is a lower bound on the change."),
      VQS_CART, VQS_W1, VQS_W1 - 1),
    "",
    paste0("Files: see jul20_qs_*_", tolower(cohort_mode), "_", stamp,
           ".csv alongside this summary; the validation_summary file carries the automated reconciliation checks, and the run_status file distinguishes 'technically complete - pending manual review' from an incomplete run."))
  write_text(summary_lines, "rule_impact_and_q2_summary")

  defs <- data.frame(
    item = c(
      "cohort",
      "Q2 dual cohort",
      "drug episodes (MAPs)",
      "medical service dates",
      "pharmacy fill dates",
      "days covered",
      "diagnosis date",
      "2L regimen",
      "payer",
      "region",
      "Q3 framing",
      "MELP boundary",
      "CAR-T affected patient"),
    definition = c(
      cohort_label,
      paste0("LOT1 regimen exactly ", tok$dara, " + ", tok$bort,
             " (no other MM agent in LOT_BASE_MEDS; steroids excluded from regimen strings by construction)"),
      "contiguous medication-availability periods per patient+agent from MAP_STACKED, counted when they start inside LOT1 (LOT1 start .. LOT1 end)",
      "distinct medication service dates on medical claims (MMA_MED_PROCESSED is deduplicated to one row per patient+agent+date+claim type) inside LOT1 - not administrations, not cycles",
      "distinct pharmacy fill dates inside LOT1",
      "days between episode start and the earlier of episode end / LOT1 end, summed per agent",
      "ELIG_COH_FINAL.INDEX_DATE - the qualifying MM diagnosis index date behind cohort entry",
      "LOT_LONG LOT_NUM=2 regimen; '(no 2L observed)' keeps the denominator at the full dual cohort",
      "member_enrollment.BUS on the span covering the LOT1 start; MCR=Medicare, COM=Commercial, blank=Unknown, else Other(<BUS>); anchor = LOT1 start date. 'Payer/type' is answered by this line-of-business split; a finer plan/product breakdown would need an explicitly approved enrollment field, configured the same way as the region source",
      if (nzchar(region_note)) region_note else "(not derived)",
      "PRELIMINARY affected-patient/boundary screen over existing LOT output; NOT an engine re-run; exact impact needs an isolated scenario re-derivation",
      "a line transition attributable to melphalan: prior line ended MED_ADD with MELP as the added drug, and/or the next line is MED-started on a MELP MAP start date",
      sprintf("any patient whose first CAR-T date falls within LOT1 start .. start+%dd (the %d-day induction window), classified by how the current engine handled the CAR-T; the fold-back merge is computed only for those whose LOT1 ended by the CAR-T and whose LOT2 is CART-started",
              VQS_W1 - 1, VQS_W1)),
    stringsAsFactors = FALSE)
  write_out(defs, "definitions")

  if (length(checks) > 0) write_out(do.call(rbind, checks), "validation_summary")

  # ---- consolidated Excel workbook (all Q2/Q3 tables in one file) ---------
  # Assembled from the same frames already written as CSVs (wb_reg). Built
  # before run_status so a workbook failure is reflected there. Degrades to
  # CSV-only with a clear note if openxlsx is not installed.
  if (requireNamespace("openxlsx", quietly = TRUE)) {
    wb_status <- if (length(gaps) == 0)
      "STATUS: TECHNICALLY COMPLETE - PENDING MANUAL REVIEW (not sign-off to share)."
      else paste0("STATUS: INCOMPLETE - ", length(gaps), " issue(s); see the run_status file and the gaps below.")
    tbls <- function(...) {
      m <- list(...)
      out <- list()
      for (cap in names(m)) if (!is.null(wb_reg[[m[[cap]]]])) out[[cap]] <- wb_reg[[m[[cap]]]]
      out
    }
    wb_sheets <- list()
    add_wb <- function(name, title, subtitle = NULL, narrative = NULL, tables = list()) {
      if (length(tables) == 0) return(invisible(NULL))
      wb_sheets[[length(wb_sheets) + 1L]] <<- list(name = name, title = title,
        subtitle = subtitle, narrative = narrative, tables = tables)
    }
    add_wb("Read Me", paste0("July-20 Q2+Q3 - ", cohort_label),
      subtitle = paste0("Generated ", stamp, " by jul20_studyteam_qs.R against ", cfg$work_schema),
      narrative = c(wb_status, if (length(gaps)) paste0("  - ", gaps) else NULL, "", summary_lines),
      tables = tbls("Cohort denominators (reconcile vs the dashboard)" = "lot_totals_for_reconciliation",
                    "Definitions" = "definitions",
                    "Validation checks" = "validation_summary"))
    add_wb("Q2 cohort and use", "Q2 - DARA+BORT dual therapy: cohort and per-agent utilization",
      subtitle = cohort_label,
      tables = tbls("Exact-dual vs contains-both context" = "dual_definition_and_context",
                    "Episodes (MAPs) per agent in LOT1" = "utilization_summary",
                    "Episode-count distribution" = "episode_distribution",
                    "Service / fill dates per agent in LOT1" = "service_date_summary"))
    add_wb("Q2 patients", "Q2 - DARA+BORT patient roster (one row per patient)",
      subtitle = cohort_label,
      tables = tbls("Patient roster" = "dara_bort_patients"))
    add_wb("Q2 MAP detail", "Q2 - per-episode (MAP) detail",
      subtitle = cohort_label,
      tables = tbls("DARA/BORT episodes during LOT1" = "dara_bort_maps_during_lot1",
                    "DARA/BORT episodes after LOT1" = "dara_bort_maps_after_lot1"))
    add_wb("Q2 2L and diagnosis", "Q2 - 2L regimens and diagnosis years",
      subtitle = cohort_label,
      tables = tbls("2L regimens of the dual cohort" = "lot2_regimens",
                    "Diagnosis years" = "diagnosis_years"))
    add_wb("Q2 region x payer", "Q2 - region x payer",
      subtitle = cohort_label,
      tables = tbls("Region x payer (grid)" = "region_payer_grid",
                    "Region x payer (long, with %)" = "region_payer_counts",
                    "Region value counts" = "region_value_counts"))
    add_wb("Q3a MELP", "Q3(a) - MELP rule PRELIMINARY screen (not exact impact)",
      subtitle = cohort_label,
      tables = tbls("Headline totals" = "melp_rule_totals",
                    "Boundaries by timing bucket" = "melp_rule_inventory",
                    "Boundaries by line pair" = "melp_rule_by_line",
                    "Lines per patient (current vs screened)" = "melp_rule_lines_shift"))
    add_wb("Q3a MELP patients", "Q3(a) - MELP boundary patients and example timelines",
      subtitle = cohort_label,
      tables = tbls("Boundary roster" = "melp_rule_boundaries",
                    "Example patient LOT rows" = "melp_rule_example_lots",
                    "Example patient MELP MAP dates" = "melp_rule_example_maps"))
    add_wb("Q3b CAR-T", "Q3(b) - CAR-T rule PRELIMINARY screen (not exact impact)",
      subtitle = cohort_label,
      tables = tbls("Inventory" = "cart_rule_inventory",
                    "First CAR-T timing vs LOT1 start" = "cart_rule_timing",
                    "Lines per patient (current vs screened)" = "cart_rule_lines_shift"))
    add_wb("Q3b CAR-T patients", "Q3(b) - CAR-T affected patients (all in-window CAR-T)",
      subtitle = cohort_label,
      tables = tbls("Affected patients" = "cart_rule_affected_patients"))

    xlsx <- file.path(out_dir, paste0("jul20_studyteam_qs_", tolower(cohort_mode), "_", stamp, ".xlsx"))
    ok_wb <- isTRUE(tryCatch({ wbx_write_workbook(wb_sheets, xlsx); TRUE },
                             error = function(e) {
                               log_msg("  WARN: consolidated Excel failed - ", conditionMessage(e))
                               FALSE
                             }))
    if (!ok_wb)
      gaps <- c(gaps, "consolidated Excel workbook could not be written (the per-result CSVs are present)")
  } else {
    log_msg("NOTE: openxlsx not installed - consolidated Excel skipped; the per-result CSVs are written. install.packages('openxlsx') to enable the workbook.")
    gaps <- c(gaps, "consolidated Excel skipped - openxlsx not installed (per-result CSVs written)")
  }

  status_lines <- if (length(gaps) == 0) {
    c("RUN STATUS: TECHNICALLY COMPLETE - PENDING MANUAL REVIEW",
      paste0("Generated ", stamp, " on ", cohort_label, "."),
      "All requested outputs were produced and all automated checks passed. This is NOT sign-off to share.",
      "Manual review still required before anything goes to the study team:",
      "  - reconcile lot_totals_for_reconciliation against the current dashboard;",
      "  - confirm the region source and its values (region_value_counts);",
      "  - review the MELP example timelines against the boundary definitions.")
  } else {
    c("RUN STATUS: INCOMPLETE",
      paste0("Generated ", stamp, " on ", cohort_label, "."),
      paste0(length(gaps), " issue(s):"),
      paste0("  - ", gaps))
  }
  write_text(status_lines, "run_status")

  log_msg(SEP)
  if (length(gaps) > 0) {
    log_msg("July-20 Q2+Q3 COMPLETED WITH GAPS (", length(gaps), " issue(s)):")
    for (g in gaps) log_msg("  - ", g)
  } else {
    log_msg("July-20 Q2+Q3 complete. Outputs in ", out_dir)
  }
  log_msg(SEP)
}

if (!interactive()) {
  main()
}
