# Mouth-cancer synthetic input kit

Synthetic demonstration inputs only; no scientific approval or release.

This kit is staged input for a fresh software rehearsal. It is not evidence that a fresh end-to-end journey has passed. It contains invented records and rules, not real patient data.

## Contents

- `specification.xlsx`: the unchanged 22-requirement workbook.
- `sources/`: six prepared TSV tables for 26 invented patients.
- `oracle/expected-rows.json`: 18 expected patient/cohort rows and 23 clinical fields, before runtime provenance stamps.
- `oracle/expected-membership.json`: all 52 patient/cohort inclusion outcomes.
- `oracle/source-inputs.json`: source roles, table names, columns, row counts and original TSV hashes using portable relative paths.
- `DEMO_KIT.json`: the closed file inventory and content hashes.

| File | Source role | Table name | Rows |
|---|---|---|---|
| `sources/enhanced.tsv` | `enhanced` | `mw_enhanced` | 26 |
| `sources/demographics.tsv` | `demographics` | `mw_demographics` | 26 |
| `sources/lot.tsv` | `lot` | `mw_lot` | 28 |
| `sources/baseline_ecog.tsv` | `baseline_ecog` | `mw_baseline_ecog` | 27 |
| `sources/mortality.tsv` | `mortality` | `mw_mortality` | 4 |
| `sources/visit.tsv` | `visit` | `mw_visit` | 27 |

## Use in a fresh product

Create a new product and import `specification.xlsx`. Import the six TSVs, assign the table names above, and review their mappings through the application. Draft the new scientific definitions and executable settings from the workbook; complete the required current-product reviews before requesting a local candidate. No prior configuration, contract, review form, registered identity, build receipt or output dataset is included.

The delivery label `synthetic22` can identify this exact synthetic input set. The original source manifest does not declare a refresh; this label comes from the recorded source-preparation setup. It is not a publication version or a claim that a new build passed. Use the new product's actual identity and refresh for its output stamps.

## Explicit test choices

Record these choices in the new product's native question or typed definition controls before using this oracle:

1. ECOG uses the nearest prior observation within inclusive [-30, 0] days of the current cohort index. For a same-day tie, choose the highest numeric value.
2. A complete death date on or before the administrative cutoff 2026-06-30 is an OS event even when it follows the last recorded activity. Subtract dates without adding one day. If there is no eligible event or activity, leave OS missing.
3. Eligible activity is within inclusive [the current cohort index, 2026-06-30].

These are synthetic test conventions, not clinical recommendations. If a reviewer chooses different rules, version an independent oracle before comparing results. Do not change expected values to match a failed build.

## Expected comparison and limits

For these choices, expect 18 rows: 16 in treatment-line cohort 1 and 2 in cohort 2. Check all 52 membership outcomes. Dates, strings, integers, nulls and categorical values match exactly; fractional month values use tolerance 1e-10. There is no built ADS in this kit.

The oracle contains 23 fields per row, including three explanatory survival helpers (`os_event`, `os_end_date`, `os_days`). Final column counts depend on the reviewed publication choices. The tested publication omits these helpers and adds the three current provenance fields, producing 23 columns and 414 compared cells. Retaining the helpers would produce 26 columns; that is a different publication contract.

Freeze the comparison view before running. In the tested publication, `ecog_value` becomes the string-coded `ecog`, `lot1_date`/`lot2_date` become `lot1sd`/`lot2sd`, and cohort labels become `Line1`/`Line2`. Bind the three provenance fields to the current product, specification and delivery. These presentation mappings must not change any clinical value or membership expectation.

The enhanced table already includes source treatment-line joins, a complete recorded death date and latest activity on/before cutoff. These are prepared inputs; the kit does not demonstrate automatic raw-source preparation. Age, age bands, cohort inclusion, index-dependent ECOG and OS remain calculations for the application.

This small fixture does not cover leap-day birthdays, a retained pre-index-only activity case, broad clinical validation, real data scale, authentication or production release. Earlier source-preparation refusals are not new application test results.

## Content preservation

Workbook SHA-256: `aa1aaa780307eada9f0132e8d1d9dd3b047f85e24b36918fc0b14816c9235936`. Workbook, six TSVs and both oracle datasets are byte-identical to their frozen originals. They contain no personal or machine-path metadata requiring alteration. Renaming files to portable kit names does not change their content.

The source-manifest metadata alone has a portability transformation: absolute source paths become relative `sources/<filename>` paths, with all other table metadata retained. Original manifest SHA-256: `807751f29a30d2724aae43aeee7bf31ff18d431424f051f8e4c5d544ee6f62bb`. Portable manifest SHA-256: `3ae8cda6841644369b3b7bcde102b1a598d1434bda99ee25175868c935025a5c`. No clinical values or expected outcomes were transformed.
