# Your first data product

Start with **New product**. Name the product, choose its data source, and add
the specification workbook. Check which sheets and columns to use, then select
**Preview the plan**. Correct any highlighted fields and create the draft.

Before you create your first product, its review pages are not shown. Once the
draft is created, **Progress and next step** opens and the six review stages
become available. **Save work to my branch** is shown only in a Git workspace;
it is not needed to open a clean installation.

## Work through the six stages

1. **Specification:** check the extracted rows against your workbook. Correct
   sheet mappings, column meanings and rows that do not belong in this product.
2. **Definitions:** choose a variable in the table and edit it below the table.
   Reuse a master definition when its meaning fits. Your workbook's dates,
   windows and categories stay specific to this product. Check differences
   before choosing master values. If no master fits, create a definition.
3. **Sources:** add the source-table information supplied by your data expert.
   Choose whether each value is already in a column or must be calculated, then
   choose the actual table and columns. A source-table description alone does
   not provide patient data or run a calculation.
4. **Configuration:** review how the definitions become executable rules. A
   missing supported calculation stays visible for the data expert to resolve.
5. **Validation:** run the available checks and inspect their results. A failed
   or unfinished check remains open; saving a draft does not make it pass.
6. **Release:** complete the required named reviews before sharing the dataset.
   A dataset build alone does not approve its scientific meaning or release it.

## Editing a variable

Use **Resolve a variable** to choose a row. The editor shows choices for its
type: categories, numeric bands, dates or text. A calculation may also need a
window relative to the index event, a missing-value choice and source columns.
If an option does not fit, use the custom option and explain the difference.

Save the draft before moving on. The table and its unresolved list refresh from
the saved result. A saved row can still need review if required answers are
missing. Read the message beside the row; it tells you what remains.

## Getting help and keeping your work

The assistant stays open on the right on a desktop. On a small screen it follows
the form so it cannot cover the Save or Next buttons. Ask it to explain a field
or suggest an answer. Review proposed changes before applying them. The
assistant does not supply scientific approval on your behalf.

Use **Unfinished work** to return to saved work. For a new-product form, use
**Save or resume unfinished setup** before leaving. Clearing a conversation
clears its messages; it does not cancel a running task or erase saved drafts.

When you are stuck, open **Progress and next step** for the next action. Keep
uncertain scientific choices open for their owner. Use a data-expert handoff
when a source column or supported calculation is missing.

Reference examples, when available, show structure. Their values and approvals
do not transfer to your product. A local profile is a development label;
authenticated approvals need your organisation's configured identity service.

For installation and administration, open the linked documents below:

- [Local start steps](../README.md#start-locally-on-windows)
- [Assistant connection](../README.md#assistant-connection)
- [Runtime and governance boundaries](../README.md#runtime-state-and-boundaries)
