# R mirror of engine/config.py — a resolved view over a tumor's data_product.yaml.
#
# Load order: source("vendors.R") BEFORE this file (config uses vendors_resolve; it does not source
# vendors.R itself, to avoid fragile relative-path sourcing). tests/test_r_parity.py and run_rwdp.R
# both source vendors.R first.
#
# Two layers, mirroring config.py exactly:
#  (1) PURE resolution helpers that operate on an ALREADY-PARSED config list (the same structure
#      Python's yaml.safe_load produces). These need NO packages and are cross-checked against
#      engine/config.py by tests/test_r_parity.py: cfg_all_tables() (flatiron AND cota),
#      cfg_index_source(), cfg_lot_line_setting(), cfg_vendor(), cfg_tumor_class(), cfg_output_fqn(),
#      cfg_version(), cfg_spec_version(), cfg_write_mode().
#  (2) load_config(): reads the YAML from disk (yaml::read_yaml) + applies dotted-key overrides.
#      This needs the `yaml` package — present on Databricks, NOT in the offline authoring sandbox —
#      so it is REVIEW-ONLY here. `yaml::` is referenced only inside the function body, so sourcing
#      this file never requires the package.

`%||%` <- function(a, b) if (is.null(a)) b else a

# A Config is just the parsed `raw` list + the product root (for pack/codelist file resolution).
make_config <- function(raw, root = NULL) list(raw = raw, root = root)

# Explicit omission only; missing controls retain the legacy execution path.
cfg_enabled <- function(block, key, where) {
  if (!(key %in% names(block))) return(TRUE)
  value <- block[[key]]
  if (!is.logical(value) || length(value) != 1L || is.na(value))
    stop(paste0(where, " must be a boolean"))
  value
}
cfg_native_treatment_enabled <- function(cfg) {
  if (!("treatment" %in% cfg_roles(cfg))) return(TRUE)
  cfg_enabled(cfg_pack(cfg,"treatment"),"enabled","treatment.enabled")
}
cfg_native_lot_required <- function(cfg)
  cfg_native_treatment_enabled(cfg) || cfg_treatment_status_enabled(cfg) ||
    any(vapply(cfg_cohorts(cfg),function(cohort) !is.null(cohort[["lot_number"]]),logical(1)))
cfg_line_categories_enabled <- function(cfg) {
  if (!cfg_native_treatment_enabled(cfg)) return(FALSE)
  cfg_enabled(cfg_pack(cfg, "treatment"), "line_categories_enabled", "treatment.line_categories_enabled")
}
cfg_treatment_status_enabled <- function(cfg)
  cfg_enabled(cfg$raw[["treatment_status"]] %||% list(), "enabled", "treatment_status.enabled")
cfg_clinical_followup_enabled <- function(cfg) {
  clinical <- cfg_pack(cfg, "clinical")
  block <- if ("death_date_imputation" %in% names(clinical)) clinical[["death_date_imputation"]] else list()
  if (!is.list(block) || (length(block) && is.null(names(block))))
    stop("clinical.death_date_imputation must be a mapping")
  cfg_enabled(block, "enabled", "clinical.death_date_imputation.enabled")
}
cfg_minimum_followup_enabled <- function(cfg)
  cfg_enabled(cfg_pack(cfg, "outcomes"), "minimum_followup_enabled", "outcomes.minimum_followup_enabled")
cfg_demographics_enabled <- function(cfg) {
  if (!("demographics" %in% cfg_roles(cfg))) return(TRUE)
  cfg_enabled(cfg_pack(cfg, "demographics"), "enabled", "demographics.enabled")
}
LEGACY_DEMOGRAPHICS_OUTPUTS <- c("age", "agegrl", "agegrln", "race", "racen", "eth", "ethn",
  "regionl", "regionln", "practic", "practicn", "ses")
LEGACY_CLINICAL_SURVIVAL_OUTPUTS <- c("f_death", "dthdt", "dthfl", "fu_enddt", "fued",
  "dthfufl_dur", "dthfufl", "dth_before_fued")

# The R runtime has no shared Python SQL parser. This guard is deliberately a
# bounded dependency check, not proof of SQL validity: quoted literals are not
# columns, comments/unreadable declarations refuse, and Spark still validates SQL.
cfg_require_survival_omission_support <- function(cfg) {
  roles <- cfg_roles(cfg)
  clinical_on <- !("clinical" %in% roles) || cfg_clinical_followup_enabled(cfg)
  minimum_on <- !("outcomes" %in% roles) || cfg_minimum_followup_enabled(cfg)
  if (clinical_on && minimum_on) return(invisible(TRUE))
  clinical <- if ("clinical" %in% roles) cfg_pack(cfg, "clinical") else list()
  outcomes <- if ("outcomes" %in% roles) cfg_pack(cfg, "outcomes") else list()
  if (!clinical_on && !identical(names(clinical[["death_date_imputation"]]), "enabled"))
    stop("clinical.death_date_imputation.enabled=false: keep only enabled; residual settings would be inactive scientific configuration")
  residual <- intersect(c("min_followup_days", "visit_recency_days"), names(outcomes))
  if (!minimum_on && length(residual))
    stop("outcomes.minimum_followup_enabled=false: remove ", paste(residual, collapse=", "))
  for (key in c("overall_survival", "line_outcomes", "progression"))
    if (length(outcomes[[key]]) > 0L)
      stop("R BUILD REFUSED - outcomes.", key, " requires the enabled native clinical follow-up and minimum-follow-up stages; late calculations cannot supply early anchors")
  omitted <- c(if (!clinical_on) LEGACY_CLINICAL_SURVIVAL_OUTPUTS, if (!minimum_on) "id3mosfu")
  cfg_require_omitted_output_support(cfg, omitted)
}

cfg_require_demographics_omission_support <- function(cfg) {
  if (cfg_demographics_enabled(cfg)) return(invisible(TRUE))
  demographics <- cfg_pack(cfg, "demographics")
  metadata <- c("pack_id","name","description","owner","version","status","metadata","extensions")
  residual <- setdiff(names(demographics), c(metadata,"enabled"))
  if (length(residual)) stop("demographics.enabled=false: remove inactive calculation settings: ",paste(residual,collapse=", "))
  # Only the stage's own source need disappears. Independently configured
  # native readers must still declare their delivery; omission is no mapping.
  source_refs <- function(node) {
    if (!is.list(node)) return(character())
    own <- node[["source"]]
    if (!is.null(own) && (!is.character(own) || length(own)!=1L || is.na(own)))
      stop("R BUILD REFUSED - cannot verify independent source consumer during demographics omission")
    c(own,unlist(lapply(node[vapply(node,is.list,logical(1))],source_refs),use.names=FALSE))
  }
  refs <- cfg_index_source(cfg)
  for (role in intersect(c("clinical","treatment","outcomes"),cfg_roles(cfg))) {
    pack <- cfg_pack(cfg,role)
    refs <- c(refs,source_refs(pack[setdiff(names(pack),metadata)]))
  }
  cfg_require_source_availability(cfg,refs,c("demographics","practice","ses"))
  cfg_require_omitted_output_support(cfg, LEGACY_DEMOGRAPHICS_OUTPUTS)
}

cfg_require_source_availability <- function(cfg, referenced, roles) {
  raw <- cfg$raw[["source_availability"]] %||% list()
  if (!is.list(raw) || (length(raw) && is.null(names(raw))))
    stop("R BUILD REFUSED - source_availability must be a mapping")
  normalized <- list()
  for (role in names(raw)) {
    entry <- raw[[role]]
    if (is.character(entry) && length(entry)==1L && !is.na(entry)) entry <- list(state=entry)
    if (!is.list(entry) || (length(entry) && is.null(names(entry))))
      stop("R BUILD REFUSED - source_availability.",role," must be a state or mapping")
    state <- entry[["state"]]
    if (!is.character(state) || length(state)!=1L || is.na(state) ||
        !(trimws(state) %in% c("required","optional","unavailable_by_design")))
      stop("R BUILD REFUSED - source_availability.",role," has an invalid state")
    state <- trimws(state)
    if (state=="unavailable_by_design") {
      nonempty <- function(value) is.character(value) && length(value)==1L && !is.na(value) && nzchar(trimws(value))
      if (!nonempty(entry[["reason"]]) || !nonempty(entry[["decision_id"]]))
        stop("R BUILD REFUSED - source_availability.",role," unavailable_by_design needs reason and decision_id")
    }
    normalized[[role]] <- state
  }
  supplied <- names(cfg_sources(cfg))
  for (role in intersect(names(normalized),roles)) {
    if (normalized[[role]]=="unavailable_by_design" && role %in% supplied)
      stop("R BUILD REFUSED - source_availability.",role," is unavailable_by_design but its source is declared")
    if (!(role %in% referenced) && !(role %in% supplied))
      stop("R BUILD REFUSED - source_availability.",role," has no independent source consumer or declared delivery")
  }
  for (role in setdiff(intersect(referenced,roles),supplied))
    if (identical(normalized[[role]] %||% "required","required"))
      stop("R BUILD REFUSED - independent source consumer still requires declared source: ",role)
  invisible(TRUE)
}

cfg_native_treatment_output <- function(name)
  tolower(name) %in% c("lotn","lotngrl","lotngrln","prior_tax_mcrpc","prior_tax_pre_mcrpc") |
    grepl("^lot[1-9][0-9]*m?(sd|ld|ed|dur|catn?)?$",tolower(name))

# Only exact, mandatory source copies are earlier producers when native LOT is
# omitted. The runtime checks the corresponding physical columns before joins.
cfg_prepared_treatment_columns <- function(cfg) {
  clinical <- if ("clinical" %in% cfg_roles(cfg)) cfg_pack(cfg,"clinical") else list()
  block <- clinical[["passthrough"]] %||% list()
  source <- block[["source"]] %||% cfg_index_source(cfg)
  if (!is.character(source) || length(source)!=1L || is.na(source) ||
      !(source %in% names(cfg_sources(cfg)))) return(list())
  columns <- block[["columns"]] %||% list()
  if (!is.list(columns) || (!is.null(names(columns)) && length(columns)) ||
      !all(vapply(columns,is.list,logical(1))))
    stop("R BUILD REFUSED - clinical.passthrough.columns must be a list of mappings")
  identifier <- function(value) is.character(value) && length(value)==1L && !is.na(value) &&
    grepl("^[A-Za-z_][A-Za-z0-9_]*$",value)
  names_out <- vapply(columns,function(item) {
    name <- item[["as"]] %||% item[["column"]]
    if (identifier(name)) tolower(name) else ""
  }, "")
  out <- list()
  for (i in seq_along(columns)) {
    item <- columns[[i]]; name <- names_out[[i]]
    if (!cfg_native_treatment_output(name)) next
    if (sum(names_out==name)!=1L)
      stop("R BUILD REFUSED - duplicate prepared treatment output: ",name)
    if ((! ("optional" %in% names(item)) || identical(item[["optional"]],FALSE)) &&
        !("bands" %in% names(item)) && identifier(item[["column"]]))
      out[[length(out)+1L]] <- item
  }
  out
}

cfg_require_native_treatment_omission_support <- function(cfg) {
  if (cfg_native_treatment_enabled(cfg)) return(invisible(TRUE))
  treatment <- cfg_pack(cfg,"treatment")
  metadata <- c("pack_id","name","description","owner","version","status","metadata","extensions")
  residual <- setdiff(names(treatment),c(metadata,"enabled"))
  if (length(residual)) stop("treatment.enabled=false: remove inactive calculation settings: ",paste(residual,collapse=", "))
  if (cfg_treatment_status_enabled(cfg))
    stop("treatment.enabled=false: omit treatment_status explicitly; native treated status requires LOT execution")
  if ("treatment_categories" %in% names(cfg$raw[["codelists"]]))
    stop("treatment.enabled=false: remove inactive codelists.treatment_categories binding")
  if (!cfg_native_lot_required(cfg) && "lot" %in% names(cfg$raw))
    stop("treatment.enabled=false: remove inactive root lot settings; no independent native LOT index consumes them")
  if (cfg_native_lot_required(cfg) && !("lot" %in% names(cfg_sources(cfg))))
    stop("R BUILD REFUSED - independent native LOT index still requires the declared lot source")
  outcomes <- if ("outcomes" %in% cfg_roles(cfg)) cfg_pack(cfg,"outcomes") else list()
  if (length(outcomes[["line_outcomes"]]))
    stop("R BUILD REFUSED - outcomes.line_outcomes consumes the omitted native treatment frame; prepared copies cannot supply that earlier frame")
  clinical <- if ("clinical" %in% cfg_roles(cfg)) cfg_pack(cfg,"clinical") else list()
  source_refs <- function(node) {
    if (!is.list(node)) return(character())
    own <- node[intersect(names(node),c("source","line_source"))]
    if (!all(vapply(own,function(value) is.null(value) ||
        (is.character(value) && length(value)==1L && !is.na(value)),logical(1))))
      stop("R BUILD REFUSED - cannot verify independent source consumer during treatment omission")
    c(unlist(own,use.names=FALSE),unlist(lapply(node[vapply(node,is.list,logical(1))],source_refs),use.names=FALSE))
  }
  refs <- cfg_index_source(cfg)
  for (role in intersect(c("clinical","outcomes"),cfg_roles(cfg))) {
    pack <- cfg_pack(cfg,role)
    refs <- c(refs,source_refs(pack[setdiff(names(pack),metadata)]))
  }
  followup <- (clinical[["death_date_imputation"]] %||% list())[["follow_up_sources"]]
  if (is.character(followup) || (is.list(followup) && all(vapply(followup,is.character,logical(1)))))
    refs <- c(refs,unlist(followup,use.names=FALSE))
  if (length(clinical[["surgery"]]))
    refs <- c(refs,clinical[["surgery"]][["line_source"]] %||% "lot")
  if (cfg_native_lot_required(cfg)) refs <- c(refs,"lot")
  cfg_require_source_availability(cfg,refs,"lot")
  copies <- vapply(cfg_prepared_treatment_columns(cfg),function(item) tolower(item[["as"]] %||% item[["column"]]),"")
  disabled <- cfg_disabled_treatment_outputs(cfg,copies)
  if (length(disabled)) stop("R BUILD REFUSED - prepared copy replaces disabled native output: ",paste(disabled,collapse=", "))
  # Discover only the canonical treatment output vocabulary mentioned by this
  # configuration; no max_lines=0 surrogate or arbitrary suffix is invented.
  words <- function(node) {
    if (is.list(node)) return(c(names(node),unlist(lapply(node,words),use.names=FALSE)))
    if (!is.character(node)) return(character())
    unlist(regmatches(node,gregexpr("[A-Za-z_][A-Za-z0-9_]*",node,perl=TRUE)),use.names=FALSE)
  }
  declared <- tolower(c(words(cfg$raw),unlist(lapply(cfg_roles(cfg),function(role) words(cfg_pack(cfg,role))),use.names=FALSE)))
  omitted <- unique(c("lotn","lotngrl","lotngrln","prior_tax_mcrpc","prior_tax_pre_mcrpc",
    declared[cfg_native_treatment_output(declared)]))
  cfg_require_omitted_output_support(cfg,omitted,early_replacements=intersect(copies,omitted))
}

cfg_require_omitted_output_support <- function(cfg, omitted, early_replacements=character()) {
  roles <- cfg_roles(cfg)
  clinical <- if ("clinical" %in% roles) cfg_pack(cfg,"clinical") else list()
  outcomes <- if ("outcomes" %in% roles) cfg_pack(cfg,"outcomes") else list()
  identifiers <- function(value, where) {
    if (is.null(value) || length(value) == 0L) return(character())
    if ((!is.character(value) && !is.list(value)) || !all(vapply(as.list(value),
        function(x) is.character(x) && length(x)==1L && !is.na(x) && grepl("^[A-Za-z_][A-Za-z0-9_]*$",x), logical(1))))
      stop("R BUILD REFUSED - cannot verify omitted dependencies in ", where, "; expected column identifiers")
    tolower(unlist(value, use.names=FALSE))
  }
  check <- function(value, where, available=early_replacements) {
    absent <- setdiff(intersect(identifiers(value,where), omitted), available)
    if (length(absent)) stop("R BUILD REFUSED - ", where, " consumes omitted native output(s): ", paste(absent,collapse=", "))
  }
  expressions <- function(value, where, available=early_replacements) {
    if (!is.character(value) || length(value)!=1L || is.na(value) || !nzchar(value))
      stop("R BUILD REFUSED - cannot verify omitted dependencies in ", where, "; expected an expression")
    bare <- gsub("'(?:''|[^'])*'", "", value, perl=TRUE)
    if (grepl("'|--|/\\*|\\*/", bare, perl=TRUE))
      stop("R BUILD REFUSED - cannot verify omitted dependencies in ", where, "; unreadable expression")
    tokens <- regmatches(bare,gregexpr("[A-Za-z_][A-Za-z0-9_]*",bare,perl=TRUE))[[1]]
    check(tokens,where,available)
  }
  records <- function(value,where) {
    if (is.null(value)) return(list())
    if (!is.list(value) || !is.null(names(value)) || !all(vapply(value,is.list,logical(1))))
      stop("R BUILD REFUSED - cannot verify omitted dependencies in ",where,"; expected a list of mappings")
    value
  }
  # Native OS runs before assembly/ads_derived, so a later replacement cannot
  # provide one of its configured event/death/censor anchors.
  os <- outcomes[["overall_survival"]]
  if (length(os)) check(os[c("event_flag","death_anchor","censor_anchor")],"outcomes.overall_survival")
  # Reserved native names can only be introduced by explicit, ordered late
  # calculations, never by a clinical alias or another early helper.
  outputs <- function(node) {
    if (!is.list(node)) return(character())
    own <- unlist(node[intersect(names(node),c("name","as","date_as","flag_as"))],use.names=FALSE)
    c(own,unlist(lapply(node[vapply(node,is.list,logical(1))],outputs),use.names=FALSE))
  }
  metadata <- c("pack_id","name","description","owner","version","status","metadata","extensions")
  named <- tolower(outputs(clinical[setdiff(names(clinical),c(metadata,"passthrough"))]))
  check(named[named %in% omitted],"clinical output replacement",character())
  check(outputs((clinical[["passthrough"]] %||% list())[["flags"]]),"clinical.passthrough flag replacement",character())
  for (item in records((clinical[["passthrough"]] %||% list())[["columns"]],"clinical.passthrough.columns"))
    check(item[["as"]] %||% item[["column"]],"clinical.passthrough output replacement")
  for (item in records(clinical[["derived"]],"clinical.derived")) {
    check(item[["requires"]],"clinical.derived.requires")
    expressions(item[["expr"]],"clinical.derived.expr")
  }
  treatment <- if ("treatment" %in% roles) cfg_pack(cfg,"treatment") else list()
  for (family in c("prior_treatments","conmed_exposures"))
    for (item in records((treatment[[family]] %||% list())[["flags"]],paste0("treatment.",family,".flags")))
      check(item[["name"]],paste0("treatment.",family," output replacement"),character())
  extra <- records(outcomes[["followup_sufficiency"]],"outcomes.followup_sufficiency")
  check(lapply(extra,function(item) item[["name"]]),"outcomes.followup_sufficiency output replacement",character())
  available <- early_replacements
  produced <- character()
  for (item in records(outcomes[["ads_derived"]],"outcomes.ads_derived")) {
    name <- identifiers(item[["name"]],"outcomes.ads_derived.name")
    if (length(name)!=1L || name %in% produced) stop("R BUILD REFUSED - duplicate or missing outcomes.ads_derived output name")
    where <- paste0("outcomes.ads_derived[",name,"]")
    if (length(intersect(names(item),c("expr","interval","landmark")))!=1L || !length(item[["requires"]]))
      stop("R BUILD REFUSED - ",where," requires one calculation and named input columns")
    check(item[["requires"]],paste0(where,".requires"),available)
    if (!is.null(item[["expr"]])) expressions(item[["expr"]],paste0(where,".expr"),available)
    if (!is.null(item[["interval"]])) check(item[["interval"]][c("from","to")],paste0(where,".interval"),available)
    if (!is.null(item[["landmark"]])) {
      landmark <- item[["landmark"]]
      if (!is.list(landmark) || length(identifiers(landmark[["anchor"]],paste0(where,".landmark.anchor")))!=1L)
        stop("R BUILD REFUSED - ",where,".landmark needs an anchor column")
      check(landmark[["anchor"]],paste0(where,".landmark.anchor"),available)
      for (event in c(records(landmark[["events"]],paste0(where,".landmark.events")),list(landmark[["censor"]]))) {
        if (!is.list(event) || length(identifiers(event[["date"]],paste0(where,".landmark.date")))!=1L)
          stop("R BUILD REFUSED - ",where,".landmark needs event and censor date columns")
        check(event[["date"]],paste0(where,".landmark.date"),available)
      }
    }
    available <- c(available,name)
    produced <- c(produced,name)
  }
  check((cfg$raw[["publication"]] %||% list())[["columns"]],"publication.columns",available)
  check(outcomes[["emits"]],"outcomes.emits",available)
  qc <- cfg$raw[["qc"]] %||% list()
  if (!is.list(qc)) stop("R BUILD REFUSED - qc must be a mapping")
  for (key in c("null_limits","column_types")) {
    node <- qc[[key]]
    if (!is.null(node) && (!is.list(node) || (length(node) && is.null(names(node)))))
      stop("R BUILD REFUSED - qc.",key," must be a mapping")
    check(names(node),paste0("qc.",key),available)
  }
  for (key in c("nonnegative","publish_columns")) check(qc[[key]],paste0("qc.",key),available)
  for (key in c("flag_date_pairs","event_date_pairs","date_order")) {
    fields <- if (key=="date_order") c("start","end") else c("flag","date")
    for (item in records(qc[[key]],paste0("qc.",key))) {
      if (!all(fields %in% names(item))) stop("R BUILD REFUSED - qc.",key," requires ",paste(fields,collapse=" and "))
      check(item[fields],paste0("qc.",key),available)
    }
  }
  for (cohort in records(cfg$raw[["derived_cohorts"]],"derived_cohorts"))
    expressions(cohort[["where"]],"derived_cohorts.where",available)
  invisible(TRUE)
}
cfg_disabled_treatment_outputs <- function(cfg, columns) {
  disabled <- (!cfg_treatment_status_enabled(cfg) & tolower(columns) %in% c("cohortu", "cohortun", "treat_flag")) |
    (!cfg_line_categories_enabled(cfg) & grepl("^lot([1-9][0-9]*m?)?catn?$", tolower(columns)))
  columns[disabled]
}

# --- run / output (pure) ----------------------------------------------------
cfg_run           <- function(cfg) cfg$raw[["run"]] %||% list()
cfg_refresh       <- function(cfg) cfg_run(cfg)[["refresh"]]
cfg_source_schema <- function(cfg) cfg_run(cfg)[["source_schema"]]
cfg_output_schema <- function(cfg) cfg_run(cfg)[["output_schema"]]
cfg_output_table  <- function(cfg) cfg_run(cfg)[["output_table"]]
cfg_output_fqn    <- function(cfg) sprintf("%s.%s", cfg_output_schema(cfg), cfg_output_table(cfg))
cfg_write_mode    <- function(cfg) cfg_run(cfg)[["write_mode"]] %||% "overwrite"
cfg_data_product_id <- function(cfg) cfg$raw[["data_product_id"]] %||% ""   # stamped on every ADS row
cfg_source_union  <- function(cfg) cfg$raw[["source_union"]]            # multi-schema union (EC); NULL = single
cfg_vendor        <- function(cfg) cfg$raw[["vendor"]] %||% "flatiron"
cfg_tumor_class   <- function(cfg) cfg$raw[["tumor_class"]] %||% "solid"
# Data format (EDM | Panoramic …): a per-format overlay over sources / table-layout / column renames.
cfg_data_format    <- function(cfg) cfg_run(cfg)[["data_format"]] %||% cfg$raw[["data_format"]] %||% "EDM"
cfg_format_block   <- function(cfg) (cfg$raw[["formats"]] %||% list())[[cfg_data_format(cfg)]] %||% list()
cfg_source_layout  <- function(cfg) cfg_format_block(cfg)[["source_layout"]] %||% cfg_run(cfg)[["source_layout"]]
cfg_source_renames <- function(cfg) cfg_format_block(cfg)[["rename"]] %||% list()

# Full product version with {snapshot} filled from the refresh (e.g. "202606.{snapshot}" ->
# "202606.2026q1"). A human-readable spec+cut label for logs; the audit STAMP is cfg_spec_version().
cfg_version <- function(cfg) {
  v <- as.character(cfg$raw[["version"]] %||% "")
  gsub("{snapshot}", as.character(cfg_refresh(cfg)), v, fixed = TRUE)
}

# The contract version alone (CalVer YYYYMM, e.g. "202606") — `version` with the data-refresh snapshot
# stripped. THIS is what stamps ADS rows + manifests (== Python Config.spec_version); the data cut is
# carried separately as data_refresh, so the two axes never duplicate. Mirrors assemble.py byte-for-byte.
cfg_spec_version <- function(cfg) {
  v <- as.character(cfg$raw[["version"]] %||% "")
  head <- strsplit(v, "{snapshot}", fixed = TRUE)[[1]][1]
  if (length(head) == 0L || is.na(head)) head <- ""
  sub("[._/ -]+$", "", head)                # strip trailing separators (== Python rstrip("._-/ "))
}

# LOT line-setting filter for new_lot_n (e.g. mCRPC for prostate). NULL = no filter.
cfg_lot_line_setting <- function(cfg) (cfg$raw[["lot"]] %||% list())[["line_setting"]]

# LOT model (backward-compatible defaults reproduce prostate): which line numbering, settings to
# drop, and the maintenance-flag column. Mirrors config.py.
cfg_lot_exclude_settings   <- function(cfg) (cfg$raw[["lot"]] %||% list())[["exclude_settings"]] %||% list()
cfg_lot_line_number_col    <- function(cfg) (cfg$raw[["lot"]] %||% list())[["line_number"]] %||% "new_lot_n"
cfg_lot_maintenance_column <- function(cfg) (cfg$raw[["lot"]] %||% list())[["maintenance_column"]] %||% "ismaintenancetherapy"

# Logical source the 'overall' index date is built from. Default 'enhanced'; heme indexes off
# 'diagnosis' (index_dates.advanced_diagnosis_date.source).
cfg_index_source <- function(cfg) {
  idx <- (cfg$raw[["index_dates"]] %||% list())[["advanced_diagnosis_date"]] %||% list()
  idx[["source"]] %||% "enhanced"
}

# --- sources (pure, vendor-aware) -------------------------------------------
# Base source map overlaid with the active data format's `sources` overrides (EDM = no overlay).
cfg_sources <- function(cfg)
  modifyList(cfg$raw[["sources"]] %||% list(), cfg_format_block(cfg)[["sources"]] %||% list())

# Resolve a logical source name to a physical table. Mirrors R dbplyr in_schema(dbname, ...).
cfg_table <- function(cfg, name) {
  srcs <- cfg_sources(cfg)
  if (is.null(srcs[[name]]))
    stop(sprintf("unknown source '%s'. Known: %s", name, paste(sort(names(srcs)), collapse = ", ")))
  vendors_resolve(cfg_vendor(cfg), cfg_source_layout(cfg),
                  cfg_source_schema(cfg), srcs[[name]], cfg_refresh(cfg))
}

cfg_all_tables <- function(cfg) {
  srcs <- cfg_sources(cfg)
  out <- list()
  for (nm in names(srcs)) out[[nm]] <- cfg_table(cfg, nm)
  out
}

# Resolve a source in a SPECIFIC schema (for multi-schema unions). Mirrors config.py::table_in.
cfg_table_in <- function(cfg, name, schema) {
  srcs <- cfg_sources(cfg)
  vendors_resolve(cfg_vendor(cfg), cfg_source_layout(cfg), schema, srcs[[name]], cfg_refresh(cfg))
}

# Every physical table a source resolves to: one normally, or one per source_union member schema.
cfg_source_fqns <- function(cfg, name) {
  u <- cfg_source_union(cfg)
  if (!is.null(u))
    return(vapply(u[["members"]], function(m) cfg_table_in(cfg, name, m[["schema"]]), ""))
  cfg_table(cfg, name)
}

# --- cohorts (pure) ---------------------------------------------------------
cfg_cohorts <- function(cfg) cfg$raw[["cohorts"]] %||% list()
cfg_cohort <- function(cfg, cohort_id) {
  for (c in cfg_cohorts(cfg)) if (identical(c[["id"]], cohort_id)) return(c)
  stop(sprintf("unknown cohort '%s'", cohort_id))
}

# --- variable packs / codelists (REVIEW-ONLY: need yaml::read_yaml on disk) ------------------
# Variable pack by ROLE = the file stem (demographics / clinical / treatment / outcomes), mirroring
# config.py.pack(role). Keeps the engine tumor-agnostic.
cfg_pack <- function(cfg, role) {
  rels <- cfg$raw[["variables"]] %||% list()
  for (rel in rels) {
    rel <- as.character(rel)
    if (identical(tools::file_path_sans_ext(basename(rel)), role))
      return(yaml::read_yaml(file.path(cfg$root, rel)))   # yaml:: resolved only when called
  }
  stop(sprintf("no variable pack for role '%s'", role))
}

cfg_roles <- function(cfg) {
  rels <- cfg$raw[["variables"]] %||% list()
  vapply(rels, function(rel) tools::file_path_sans_ext(basename(as.character(rel))), "")
}

# These Python stages and reviewed source bindings have no R implementation.
# Refuse them before reading sources; a smaller ADS is not cross-validation of
# the same configuration. Empty optional families retain their no-op behavior.
cfg_require_r_execution_support <- function(cfg) {
  cfg_require_survival_omission_support(cfg)
  cfg_require_demographics_omission_support(cfg)
  cfg_require_native_treatment_omission_support(cfg)
  unsupported <- list(outcomes = c("risk_scores", "serial_markers", "modality_relations"),
                      treatment = c("rt_courses", "dose_exposures"))
  missing <- character()
  condition_class <- cfg$raw[["condition_class"]] %||% "oncology"
  if (!identical(condition_class, "oncology"))
    missing <- c(missing, paste("condition_class", condition_class, "(general execution profile)"))
  if (any(vapply(cfg_cohorts(cfg), function(cohort) !is.null(cohort[["eligibility"]]), logical(1))))
    missing <- c(missing, "cohort.eligibility (typed patient inclusion/exclusion rules)")
  roles <- cfg_roles(cfg)
  if (!cfg_treatment_status_enabled(cfg) && !identical(names(cfg$raw[["treatment_status"]]), "enabled"))
    stop("treatment_status.enabled=false: keep only enabled; labels, codes and settings would be inactive scientific configuration")
  if ("treatment" %in% roles && !cfg_line_categories_enabled(cfg)) {
    trt <- cfg_pack(cfg, "treatment")
    if ("line_category_codelist" %in% names(trt) || "treatment_categories" %in% names(cfg$raw[["codelists"]]))
      stop("treatment.line_categories_enabled=false: remove line_category_codelist and codelists.treatment_categories bindings")
  }
  for (role in intersect(names(unsupported), roles)) {
    pack <- cfg_pack(cfg, role)
    for (family in unsupported[[role]]) {
      declared <- pack[[family]]
      if (!is.null(declared) && length(declared) > 0L)
        missing <- c(missing, paste(role, family, sep = "."))
    }
  }
  if (!is.null(cfg$root) && file.exists(file.path(cfg$root, "config", "source_adapters.yaml")))
    missing <- c(missing, "config/source_adapters.yaml (reviewed source bindings and parsers)")
  if (length(missing) > 0L)
    stop(paste0("R BUILD REFUSED - the R validation engine does not implement: ",
                paste(missing, collapse = "; "), ". Run platform/databricks/run_rwdp.py with the reviewed configuration, ",
                "or complete and validate an R implementation handoff. No source tables were read or outputs written."),
         call. = FALSE)
  invisible(TRUE)
}

cfg_codelist <- function(cfg, key) {
  rel <- (cfg$raw[["codelists"]] %||% list())[[key]]
  if (is.null(rel)) stop(sprintf("no codelist for key '%s'", key))
  yaml::read_yaml(file.path(cfg$root, as.character(rel)))
}

# --- loader (REVIEW-ONLY: needs the `yaml` package, present on Databricks) -------------------
.set_dotted <- function(d, dotted_key, value) {
  parts <- strsplit(dotted_key, ".", fixed = TRUE)[[1]]
  if (length(parts) == 1L) { d[[parts]] <- value; return(d) }
  head_key <- parts[1]
  rest <- paste(parts[-1], collapse = ".")
  node <- d[[head_key]] %||% list()
  d[[head_key]] <- .set_dotted(node, rest, value)
  d
}

# The ENVIRONMENT half, mirroring engine/config.py's PIPELINE. Same filename, same merge, same
# refusal of a key declared twice — the two engines run the SAME config, so a pack that loads in one
# and not the other is a cross-engine comparison that silently stopped comparing the same thing.
PIPELINE <- "pipeline.yaml"

load_config <- function(path, overrides = list()) {
  raw <- yaml::read_yaml(path)
  pipeline <- file.path(dirname(path), PIPELINE)
  if (file.exists(pipeline)) {
    env <- yaml::read_yaml(pipeline)
    if (!is.null(env)) {
      if (!is.list(env)) stop(sprintf("%s: must be a mapping", pipeline))
      both <- intersect(names(env), names(raw))
      if (length(both) > 0L) {
        stop(sprintf(paste0("%s defined in BOTH %s and %s — the environment half belongs in exactly ",
                            "one of them, and preferring either silently would decide where the ",
                            "product writes without anybody reading it."),
                     paste(sort(both), collapse = ", "), basename(path), PIPELINE))
      }
      raw[names(env)] <- env
    }
  }
  for (k in names(overrides)) {
    v <- overrides[[k]]
    if (is.null(v) || (is.character(v) && length(v) == 1L && !nzchar(v))) next  # skip blank passthroughs
    raw <- .set_dotted(raw, k, v)
  }
  root <- dirname(dirname(normalizePath(path, mustWork = FALSE)))   # folder containing config/
  make_config(raw, root)
}

# --- the temporal field model. == engine/config.py: the same default chains, one spelling each.
# `index_end` carried three meanings (enrollment close, observation end, sanity bound); the split
# fields are optional and every unstated one falls back so no pack moves until a human writes it.
# falsy-tolerant pick, matching Python's `or` chain EXACTLY: NULL or the empty string falls
# back (Python: None or ""), nothing else — so the two engines resolve the same config the
# same way, including a deliberate whitespace value (both keep it).
`%|v|%` <- function(a, b) if (is.null(a) || identical(as.character(a), "")) b else a
cfg_index_period_start <- function(cfg) {
  s <- cfg$raw[["study"]]; s[["index_period_start"]] %|v|% s[["index_start"]] }
cfg_index_period_end <- function(cfg) {
  s <- cfg$raw[["study"]]; s[["index_period_end"]] %|v|% s[["index_end"]] }
cfg_observation_end <- function(cfg) {
  s <- cfg$raw[["study"]]; s[["observation_end"]] %|v|% s[["data_cutoff"]] %|v|% s[["index_end"]] }
cfg_data_cutoff <- function(cfg) {
  s <- cfg$raw[["study"]]; s[["data_cutoff"]] %|v|% s[["observation_end"]] %|v|% s[["index_end"]] }
