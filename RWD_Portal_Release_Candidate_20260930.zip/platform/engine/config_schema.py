"""Version 1 structural checks before scientific/configuration semantic checks.

The JSON Schema is an explicit, intentionally partial structural contract, not
an alternative clinical validator. It never mutates the supplied configuration,
defaults missing values, loads remote schemas, or imports Spark.
"""
from __future__ import annotations

from datetime import date, datetime
from difflib import get_close_matches
from functools import lru_cache
import json
import math
from pathlib import Path

from jsonschema import Draft202012Validator, validators

SCHEMA_VERSION = 1
MAX_ERRORS = 50
PACK_ROLES = ("demographics", "clinical", "treatment", "outcomes")

# YAML 1.0 is not an integer declaration in this engine, and True must never
# become cohort 1. Keep the existing engine's whole-number type semantics.
_Validator = validators.extend(
    Draft202012Validator,
    type_checker=Draft202012Validator.TYPE_CHECKER.redefine(
        "integer", lambda _checker, value: type(value) is int),
)


@lru_cache(maxsize=1)
def schema() -> dict:
    """Load only the packaged schema; callers must not modify this mapping."""
    with Path(__file__).with_suffix(".json").open(encoding="utf-8") as stream:
        document = json.load(stream)
    Draft202012Validator.check_schema(document)
    return document


def _path(parts) -> str:
    result = ""
    for part in parts:
        if isinstance(part, int):
            result += f"[{part}]"
        else:
            result += ("." if result else "") + str(part)
    return result or "configuration"


def _json_view(value, parts=(), depth=0):
    """YAML dates have an equivalent JSON string; leave the original untouched."""
    if depth > 96:
        raise ValueError(f"{_path(parts)}: configuration nesting exceeds 96 levels")
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, dict):
        if any(not isinstance(key, str) for key in value):
            raise ValueError(f"{_path(parts)}: mapping keys must be text names")
        return {key: _json_view(item, (*parts, key), depth + 1)
                for key, item in value.items()}
    if isinstance(value, list):
        return [_json_view(item, (*parts, index), depth + 1)
                for index, item in enumerate(value)]
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError(f"{_path(parts)}: numeric values must be finite")
    if value is not None and not isinstance(value, (str, int, float, bool)):
        raise ValueError(f"{_path(parts)}: use a JSON-compatible scalar, list or mapping")
    return value


def _message(error, prefix) -> str:
    parts = (*prefix, *error.absolute_path)
    where = _path(parts)
    field = str(parts[-1]) if parts else "configuration"
    if error.validator == "type":
        names = {"integer": "a whole number", "number": "a number", "string": "a string",
                 "boolean": "true/false", "object": "a mapping", "array": "a list"}
        types = error.validator_value
        wanted = " or ".join(names.get(item, item) for item in types) if isinstance(types, list) else names.get(types, str(types))
        suffix = ""
        if error.validator_value == "object" and parts and isinstance(parts[-1], int):
            suffix = f"; {_path(parts[:-1])} must be a list of mappings"
        return f"{where}: {field} must be {wanted}{suffix} (schema v1)"
    if error.validator == "required":
        absent = [name for name in error.validator_value if name not in error.instance]
        return f"{where} missing {', '.join(repr(name) for name in absent)} (schema v1)"
    if error.validator == "additionalProperties":
        allowed = set(error.schema.get("properties", {}))
        unknown = sorted(set(error.instance) - allowed)
        near = get_close_matches(unknown[0], sorted(allowed), n=1) if unknown else []
        hint = f" (did you mean '{near[0]}'?)" if near else ""
        return f"{where}: unknown key {', '.join(repr(name) for name in unknown)}{hint}; allowed keys: {', '.join(sorted(allowed))} (schema v1)"
    if error.validator == "pattern":
        return f"{where}: use an identifier beginning with a letter, containing only letters, digits and underscores (schema v1)"
    if error.validator == "const" and field == "schema_version":
        return f"{where}: unsupported configuration schema version; supported version is 1"
    if error.validator == "anyOf" and error.schema == schema()["$defs"]["integer"]:
        return f"{where}: {field} must be a whole number or the explicit REPLACE_ME scaffold marker (schema v1)"
    if error.validator == "minLength":
        return f"{where}: enter a non-empty string (schema v1)"
    # Do not include the submitted value or a potentially long SQL expression.
    if error.validator == "enum":
        return f"{where}: choose one of {', '.join(map(str, error.validator_value))} (schema v1)"
    if error.validator == "maxLength":
        return f"{where}: text exceeds {error.validator_value} characters (schema v1)"
    return f"{where}: does not match the declared {error.validator} structure (schema v1)"


def validate_document(document, *, role: str | None = None) -> list[str]:
    """Validate one merged configuration, or one named variable-pack document.

    Version 1 also covers legacy documents without ``schema_version``. New
    versions must be implemented explicitly rather than interpreted as v1.
    """
    if role is not None and role not in PACK_ROLES:
        raise ValueError("Unknown variable-pack schema role")
    prefix = (role,) if role else ()
    try:
        instance = _json_view(document, prefix)
    except ValueError as error:
        return [str(error)]
    base = schema()
    chosen = base if role is None else {"$defs": base["$defs"], "$ref": f"#/$defs/{role}"}
    errors = []
    for error in _Validator(chosen).iter_errors(instance):
        message = _message(error, prefix)
        if message not in errors:
            errors.append(message)
        if len(errors) > MAX_ERRORS:
            return errors[:MAX_ERRORS] + ["configuration: more structural errors remain; fix these fields and check again"]
    return errors


def validate_config(cfg) -> list[str]:
    """Validate the exact config and cached packs used by the engine.

    Structural failures always refuse execution. The caller may additionally
    collect independent semantic findings when those validators can safely run.
    Deeper clinical, SQL, source, and approval checks are still needed when this
    returns no errors. Loading alone never asserts a validated config.
    """
    errors = validate_document(cfg.raw)
    if errors:
        return errors
    # Use cfg.pack, not a second YAML reader: in-memory overrides and the actual
    # execution view must be subject to the same structural contract.
    for role in PACK_ROLES:
        try:
            document = cfg.pack(role)
        except KeyError:
            continue  # Existing validation reports required missing roles.
        except (OSError, ValueError, TypeError, AttributeError):
            return [f"variables.{role}: cannot read a variable-pack mapping; check its declared YAML file"]
        errors.extend(validate_document(document, role=role))
    return errors
