"""One reader for legacy panels and independent named panel instances."""
from copy import deepcopy
import re

FAMILIES = ("biomarkers", "labs", "response", "lab_values")


def instances(block, family):
    """Return (diagnostic name, settings) pairs without changing authored YAML."""
    if not block:
        return []
    if not isinstance(block, dict):
        raise ValueError(f"clinical.{family} must contain panel settings.")
    if "instances" not in block:
        return [(family, block)]
    if set(block) != {"instances"} or not isinstance(block["instances"], list) or not 1 <= len(block["instances"]) <= 256:
        raise ValueError(f"clinical.{family}.instances must contain 1–256 named settings, without competing shared settings.")
    result, names, outputs = [], set(), set()
    for item in block["instances"]:
        if not isinstance(item, dict) or set(item) != {"id", "settings"}:
            raise ValueError(f"clinical.{family} instances need id and settings only.")
        name, settings = item["id"], item["settings"]
        if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,79}", name) or name.casefold() in names:
            raise ValueError(f"clinical.{family} instance identifiers must be unique letter-led names.")
        names.add(name.casefold())
        if not isinstance(settings, dict) or "instances" in settings or not isinstance(settings.get("panel"), list) or not settings["panel"]:
            raise ValueError(f"clinical.{family}.{name} needs its own settings and a nonempty panel.")
        for member in settings["panel"]:
            if not isinstance(member, dict) or not isinstance(member.get("name"), str):
                raise ValueError(f"clinical.{family}.{name} has an unnamed panel member.")
            output = member["name"].casefold()
            if output in outputs:
                raise ValueError(f"clinical.{family} repeats output {member['name']} across independent panels.")
            outputs.add(output)
        result.append((family + ".instances[" + name + "]", settings))
    return result


def iter_panels(clinical, families=FAMILIES):
    for family in families:
        for label, block in instances(clinical.get(family), family):
            yield family, label, block


def shape_errors(clinical):
    errors = []
    for family in FAMILIES:
        try:
            instances(clinical.get(family), family)
        except ValueError as error:
            errors.append(str(error))
    return errors


def update(block, family, requested):
    """Replace explicitly named members, preserving every unrelated setting.

    Keep the legacy compact form when all members truly share settings. Promote
    to named instances only where an independent selection needs its own block.
    """
    original = instances(block, family)
    requested = list(requested)  # [(member, settings)]
    stems = {item["name"] for item, _settings in requested}
    retained = []
    for label, settings in original:
        members = []
        for member in settings.get("panel") or []:
            if member.get("name") not in stems:
                members.append(deepcopy(member))
            else:
                replacement = next(item for item, _ in requested if item["name"] == member["name"])
                if set(member) - set(replacement):
                    raise ValueError(f"Existing {family} item {member['name']} has additional settings; review them before replacing this rule.")
                allowed = set(next(new for item, new in requested if item["name"] == member["name"])) | {"panel", "emit_date"}
                if set(settings) - allowed:
                    raise ValueError(f"Existing {family} item {member['name']} has additional shared settings; review them before replacement.")
        if members:
            retained.append({**deepcopy(settings), "panel": members})
    groups = retained
    for member, settings in requested:
        match = next((entry for entry in groups if {k: v for k, v in entry.items() if k != "panel"} == settings), None)
        if match is None:
            groups.append({**deepcopy(settings), "panel": [deepcopy(member)]})
        elif not any(item["name"] == member["name"] for item in match["panel"]):
            match["panel"].append(deepcopy(member))
    if len(groups) == 1:
        return groups[0]
    result = {"instances": [{"id": "panel_" + str(i + 1), "settings": settings} for i, settings in enumerate(groups)]}
    instances(result, family)
    return result
