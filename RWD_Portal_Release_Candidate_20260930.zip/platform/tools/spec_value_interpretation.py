"""Conservative, source-bound proposals for a specification Values cell.

This module interprets representation, never a clinical rule. A proposal is not
an approval or executable configuration. The caller presents editable fields,
confirms against the current extraction digest, then persists the returned
record with the product's review draft. The original cell is never overwritten.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import date, datetime, timezone
import hashlib
import json
import math
import re

PARSER = "spec-values"
PARSER_VERSION = "2"
KINDS = ("bands", "flag", "ordinal", "continuous", "date", "codes", "text", "unknown")
TYPES = ("string", "integer", "long", "double", "boolean", "date", "timestamp")
MAX_TEXT = 12000
MAX_LEVELS = 200
_NUMBER = r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)"
_BOUND = re.compile(r"(<=|>=|<|>|≤|≥)\s*(" + _NUMBER + r")")
_RANGE = re.compile(r"(" + _NUMBER + r")\s*[-–—]\s*(" + _NUMBER + r")")
_PLUS_BOUND = re.compile(r"(" + _NUMBER + r")\s*\+")
_MISSING = {"missing", "null", "na", "n/a"}
_UNITS = {"month", "months", "year", "years", "day", "days", "week", "weeks",
          "hour", "hours", "minute", "minutes", "second", "seconds", "mg/day",
          "mg/kg", "mg/kg/day", "g/day", "kg", "mg", "g", "cm", "mm", "m",
          "kg/m2", "kg/m²", "bpm", "%", "percent",
          "millimetre", "millimetres", "millimeter", "millimeters"}
_MONTHS = {name: index for index, name in enumerate(
    ("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"), 1)}


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()


def raw_digest(raw):
    """Digest the exact text, including spaces and line breaks."""
    if not isinstance(raw, str):
        raise ValueError("The Values cell must be supplied as its original text.")
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _number(text):
    number = float(text)
    if not math.isfinite(number):
        raise ValueError("A numeric limit must be finite.")
    return int(number) if number.is_integer() else number


def _is_number(value):
    try:
        return type(value) in (int, float) and math.isfinite(value)
    except OverflowError:
        return False


def _text(value, *, maximum=MAX_TEXT):
    return isinstance(value, str) and bool(value.strip()) and len(value) <= maximum


def _base(kind, data_type):
    return {"kind": kind, "data_type": data_type, "missing_allowed": None}


def _band(token):
    match = _BOUND.fullmatch(token)
    if match:
        op, number = match.groups()
        lower = op in (">", ">=", "≥")
        return {"label": token, "lower": _number(number) if lower else None,
                "upper": None if lower else _number(number),
                "lower_inclusive": lower and op in (">=", "≥"),
                "upper_inclusive": not lower and op in ("<=", "≤")}
    match = _RANGE.fullmatch(token)
    if match:
        return {"label": token, "lower": _number(match[1]), "upper": _number(match[2]),
                "lower_inclusive": True, "upper_inclusive": True}
    match = _PLUS_BOUND.fullmatch(token)
    if match:
        return {"label": token, "lower": _number(match[1]), "upper": None,
                "lower_inclusive": True, "upper_inclusive": False}
    return None


def _parse(raw):
    # Whitespace normalization is solely for parsing; the record retains raw.
    text = re.sub(r"\s+", " ", raw.strip())
    lower = text.casefold()
    iso = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})", text)
    named = re.fullmatch(r"(\d{1,2})[- ]([A-Za-z]{3})[- ](\d{4})", text)
    if iso or named:
        try:
            if iso:
                literal = date(*(int(part) for part in iso.groups())).isoformat()
            else:
                literal = date(int(named[3]), _MONTHS[named[2].casefold()], int(named[1])).isoformat()
        except (ValueError, KeyError):
            return _base("unknown", ""), ["This Values cell looks like a date but is not a valid calendar date. Choose the intended date in the editor."]
        return {**_base("date", "date"), "literal": literal}, []
    if lower in {"date", "datetime", "date/time", "timestamp"}:
        return _base("date", "date" if lower == "date" else "timestamp"), []
    typed_unit = re.fullmatch(r"(integer|whole number|numeric|decimal|double|float)\s+(.+)", lower)
    if typed_unit and typed_unit[2] in _UNITS:
        unit = text[len(typed_unit[1]):].strip()
        return {**_base("continuous", "integer" if typed_unit[1] in {"integer", "whole number"} else "double"),
                "unit": unit, "minimum": None, "maximum": None}, []
    # Recognize slash-containing units BEFORE considering category separators.
    if lower in _UNITS:
        return {**_base("continuous", "double"), "unit": text,
                "minimum": None, "maximum": None}, []
    if re.fullmatch(r"yes\s*/\s*no|no\s*/\s*yes", text, flags=re.I):
        tokens = [part.strip() for part in text.split("/")]
        return {**_base("flag", "string"), "codes": [{"code": part, "label": part} for part in tokens]}, []
    tokens = [part.strip() for part in re.split(r"\s*/\s*|\s*;\s*|\s*\|\s*", text)]
    missing = [part for part in tokens if part.casefold() in _MISSING]
    substantive = [part for part in tokens if part.casefold() not in _MISSING]
    # An integer range followed by an explicit missing level is the common
    # ordinal notation. A lone 0-4 may instead mean a continuous range.
    if len(substantive) == 1 and len(missing) == 1:
        match = _RANGE.fullmatch(substantive[0])
        if match and all(re.fullmatch(r"[+-]?\d+", part) for part in match.groups()):
            start, end = (int(part) for part in match.groups())
            if 0 <= end - start < MAX_LEVELS:
                return {**_base("ordinal", "integer"), "missing_allowed": True,
                        "codes": [{"code": code, "label": str(code)} for code in range(start, end + 1)]}, []
    if len(substantive) >= 2 and all(substantive) and len(missing) <= 1:
        bands = [_band(part) for part in substantive]
        if all(bands):
            value = {**_base("bands", "string"), "bands": bands}
            if missing:
                value["missing_allowed"] = True
            return value, validate(value)
        # A semicolon-delimited list of plain identifiers declares categories.
        # Keep slash/prose/mixed-band cases for review, and never interpret a
        # literal "unknown" as missing or infer an ordinal/Boolean encoding.
        if (";" in text and not re.search(r"[/|]", text) and not missing and not any(bands)
                and all(len(part) <= 200 and re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]*|[+-]?\d+", part)
                        for part in tokens)):
            integer_codes = all(re.fullmatch(r"0|[1-9]\d*|-[1-9]\d*", part) for part in tokens)
            value = {**_base("codes", "integer" if integer_codes else "string"),
                     "codes": [{"code": int(part) if integer_codes else part, "label": part} for part in tokens]}
            return value, validate(value)
        # Preserve explicit code-label assignments only if every token matches.
        assignments = [re.fullmatch(r"([^=]+?)\s*=\s*(.+)", part) for part in substantive]
        if all(assignments):
            codes = []
            for match in assignments:
                code, label = match[1].strip(), match[2].strip().strip("'\"")
                # Preserve zero-padded codes as identifiers, not integers.
                if re.fullmatch(r"0|[1-9]\d*|-[1-9]\d*", code):
                    code = int(code)
                codes.append({"code": code, "label": label})
            value = {**_base("codes", "integer" if all(type(item["code"]) is int for item in codes) else "string"),
                     "codes": codes}
            if missing:
                value["missing_allowed"] = True
            return value, validate(value)
    return _base("unknown", ""), ["Choose how this Values cell should be represented; its meaning is not unambiguous."]


def validate(value):
    """Return actionable findings for edited representation fields.

    Gaps in numeric bands remain legitimate scientific choices. Overlapping or
    reversed bands are invalid because one value would have conflicting labels.
    """
    if not isinstance(value, dict):
        return ["The value interpretation must contain named fields."]
    kind = value.get("kind")
    if kind not in KINDS or kind == "unknown":
        return ["Choose a value format before confirming."]
    issues = []
    shared = {"kind", "data_type", "missing_allowed"}
    allowed = {"bands": {"bands"}, "flag": {"codes"}, "ordinal": {"codes"},
               "codes": {"codes"}, "continuous": {"unit", "minimum", "maximum"}, "date": {"literal"}, "text": set()}
    if set(value) - shared - allowed[kind]:
        issues.append("Remove fields that do not belong to the selected value format.")
    data_type = value.get("data_type")
    if data_type not in TYPES:
        issues.append("Choose a supported data type.")
    if value.get("missing_allowed") is not None and type(value.get("missing_allowed")) is not bool:
        issues.append("Choose whether missing values are allowed, or leave this undecided.")
    if kind == "text" and data_type != "string":
        issues.append("Text values need the string data type.")
    if kind == "date" and data_type not in {"date", "timestamp"}:
        issues.append("A date format needs a date or timestamp data type.")
    if kind == "date" and "literal" in value:
        try:
            if data_type != "date" or not isinstance(value["literal"], str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value["literal"]):
                raise ValueError("date format")
            date.fromisoformat(value["literal"])
        except ValueError:
            issues.append("The product date must be a real date in YYYY-MM-DD form.")
    if kind == "continuous":
        if data_type not in {"integer", "long", "double"}:
            issues.append("A numeric measurement needs an integer or decimal data type.")
        if "unit" in value and value["unit"] is not None and (not isinstance(value["unit"], str) or len(value["unit"]) > 200):
            issues.append("The unit must be text of at most 200 characters.")
        bounds = [value.get("minimum"), value.get("maximum")]
        if any(limit is not None and not _is_number(limit) for limit in bounds):
            issues.append("Numeric limits must be finite numbers or blank.")
        elif all(limit is not None for limit in bounds) and bounds[0] > bounds[1]:
            issues.append("The minimum must not exceed the maximum.")
        if data_type in {"integer", "long"} and any(_is_number(limit) and int(limit) != limit for limit in bounds):
            issues.append("Integer measurements need whole-number limits.")
    if kind in {"codes", "ordinal", "flag"}:
        codes = value.get("codes")
        if not isinstance(codes, list) or not 1 <= len(codes) <= MAX_LEVELS:
            issues.append(f"Choose between 1 and {MAX_LEVELS} allowed values.")
        else:
            seen = set()
            for index, item in enumerate(codes, 1):
                if not isinstance(item, dict) or set(item) != {"code", "label"}:
                    issues.append(f"Value {index} needs a code and label.")
                    continue
                code, label = item["code"], item["label"]
                valid_code = _text(code, maximum=200) or type(code) is int or type(code) is bool or (type(code) is float and math.isfinite(code))
                if not valid_code or not _text(label, maximum=1000):
                    issues.append(f"Value {index} needs a nonempty code and label.")
                    continue
                identity = str(code).strip()
                if identity in seen:
                    issues.append(f"Code {identity} appears more than once; keep one label for each code.")
                seen.add(identity)
                if data_type in {"integer", "long"} and type(code) is not int:
                    issues.append(f"Code {identity} must be an integer for the selected data type.")
                if data_type == "double" and not _is_number(code):
                    issues.append(f"Code {identity} must be numeric for the selected data type.")
                if data_type == "boolean" and type(code) is not bool:
                    issues.append("Boolean values require explicit true/false codes; Yes/No text can use string.")
                if data_type in {"date", "timestamp"}:
                    issues.append("Use the date format for date values.")
            if kind == "flag" and len(codes) != 2:
                issues.append("A flag needs exactly two allowed values; use a codelist for more levels.")
        if kind == "ordinal" and data_type not in {"integer", "long", "double", "string"}:
            issues.append("Ordinal levels need text or numeric codes.")
    if kind == "bands":
        bands = value.get("bands")
        if data_type != "string":
            issues.append("Band labels use the string data type; numeric recoding requires an explicit codelist.")
        if not isinstance(bands, list) or not 1 <= len(bands) <= MAX_LEVELS:
            issues.append(f"Add between 1 and {MAX_LEVELS} bands.")
        else:
            labels, intervals = set(), []
            required = {"label", "lower", "upper", "lower_inclusive", "upper_inclusive"}
            for index, band in enumerate(bands, 1):
                if not isinstance(band, dict) or set(band) != required:
                    issues.append(f"Band {index} needs a label, both limits and their boundary choices.")
                    continue
                if not _text(band["label"], maximum=1000):
                    issues.append(f"Band {index} needs a label.")
                elif band["label"].strip() in labels:
                    issues.append(f"Band label {band['label']} appears more than once.")
                else:
                    labels.add(band["label"].strip())
                lo, hi = band["lower"], band["upper"]
                if any(limit is not None and not _is_number(limit) for limit in (lo, hi)):
                    issues.append(f"Band {index} limits must be finite numbers or blank.")
                    continue
                if any(type(band[name]) is not bool for name in ("lower_inclusive", "upper_inclusive")):
                    issues.append(f"Band {index} needs explicit inclusive/exclusive boundary choices.")
                    continue
                if (lo is None and band["lower_inclusive"]) or (hi is None and band["upper_inclusive"]):
                    issues.append(f"Band {index} cannot include an unbounded limit.")
                if lo is not None and hi is not None and (lo > hi or (lo == hi and not (band["lower_inclusive"] and band["upper_inclusive"]))):
                    issues.append(f"Band {index} has an empty or reversed range.")
                    continue
                intervals.append((float('-inf') if lo is None else lo, float('inf') if hi is None else hi, band, index))
            intervals.sort(key=lambda item: item[:2])
            for left, right in zip(intervals, intervals[1:]):
                if left[1] > right[0] or (left[1] == right[0] and left[2]["upper_inclusive"] and right[2]["lower_inclusive"]):
                    issues.append(f"Bands {left[3]} and {right[3]} overlap; adjust their limits or boundaries.")
    return list(dict.fromkeys(issues))


def _source(raw, citation, source_digest):
    if not isinstance(raw, str) or len(raw) > MAX_TEXT:
        raise ValueError(f"The exact Values cell must be text of at most {MAX_TEXT} characters.")
    if not _text(source_digest, maximum=1000):
        raise ValueError("The current source digest is required.")
    if not isinstance(citation, (dict, str)) or not citation:
        raise ValueError("The original Values cell citation is required.")
    # Ensure source evidence is a finite, serializable JSON value.
    _digest(citation)
    return {"raw": raw, "raw_digest": raw_digest(raw), "citation": deepcopy(citation), "source_digest": source_digest}


def source_binding(extracted_row, extraction_digest):
    """Return proposal arguments for a Values cell, retaining coordinate evidence.

    Old extraction files may only hold captured, normalized text. Their citation
    explicitly says so; it must never claim exact workbook bytes were retained.
    A future extraction with cell evidence will require a new confirmation.
    """
    if not isinstance(extracted_row, dict):
        return None
    fields = extracted_row.get("fields") or extracted_row.get("spec_fields") or {}
    sources = extracted_row.get("field_sources") or {}
    if not isinstance(fields, dict) or not isinstance(sources, dict):
        return None
    selected = next((name for name in ("values", "value", "allowed_values", "codes")
                     if fields.get(name) not in (None, "") or name in sources), None)
    if selected is None:
        # An identified specification row may have no Values column at all.
        # Bind manual choices to that absence and the current extraction, not
        # to invented workbook text or a made-up cell coordinate.
        if not extracted_row.get("item_id") and not (
                extracted_row.get("tab", extracted_row.get("sheet"))
                and extracted_row.get("excel_row", extracted_row.get("row"))):
            return None
        selected = next((name for name in ("values", "value", "allowed_values", "codes") if name in fields), None)
        return {"raw": "", "citation": {
            "item_id": extracted_row.get("item_id", ""),
            "sheet": extracted_row.get("tab", extracted_row.get("sheet", "")),
            "excel_row": extracted_row.get("excel_row", extracted_row.get("row")),
            "field": selected, "capture": "values_not_declared"}, "source_digest": extraction_digest}
    evidence = sources.get(selected)
    citation = {"item_id": extracted_row.get("item_id", ""),
                "sheet": extracted_row.get("tab", extracted_row.get("sheet", "")),
                "excel_row": extracted_row.get("excel_row", extracted_row.get("row")), "field": selected}
    if isinstance(evidence, dict) and "raw_value" in evidence:
        raw_value = evidence["raw_value"]
        raw = raw_value if isinstance(raw_value, str) else str(raw_value) if raw_value is not None else ""
        if evidence.get("raw_sha256") and evidence["raw_sha256"] != raw_digest(raw):
            raise ValueError("The extracted Values cell digest does not match its preserved text; re-extract the workbook.")
        citation.update({key: deepcopy(evidence[key]) for key in
                         ("sheet", "cell", "header_cell", "header", "raw_sha256", "parser", "parser_version", "source_type")
                         if key in evidence})
        citation["capture"] = "exact_cell_text"
    else:
        raw_value = fields.get(selected)
        raw = raw_value if isinstance(raw_value, str) else str(raw_value) if raw_value is not None else ""
        citation["capture"] = "legacy_extracted_text"
    return {"raw": raw, "citation": citation, "source_digest": extraction_digest}


def propose(raw, *, citation, source_digest, model_proposal=None):
    """Prepare a deterministic proposal or a clearly attributed model proposal.

    A model proposal is accepted only for ambiguous cells and must supply
    {value, provider, model, version}. This module never contacts a provider.
    """
    source = _source(raw, citation, source_digest)
    value, issues = _parse(raw)
    origin = {"kind": "deterministic", "parser": PARSER, "version": PARSER_VERSION}
    if not raw.strip():
        origin = {"kind": "user", "basis": "values_not_declared"}
    if model_proposal is not None:
        if not raw.strip():
            raise ValueError("No Values text is declared. Choose the format and values explicitly.")
        if value["kind"] != "unknown":
            raise ValueError("A deterministic Values proposal already exists; edit or confirm that proposal.")
        if not isinstance(model_proposal, dict) or any(not _text(model_proposal.get(key), maximum=500) for key in ("provider", "model", "version")):
            raise ValueError("A model proposal must identify its provider, model and version.")
        value = deepcopy(model_proposal.get("value"))
        issues = validate(value)
        origin = {"kind": "model", **{key: model_proposal[key] for key in ("provider", "model", "version")}}
    result = {"version": 1, "status": "needs_input" if issues else "proposed", **source,
              "origin": origin, "value": value, "issues": issues, "approved": False}
    result["proposal_digest"] = _digest(result)
    return result


def _valid_proposal(proposal):
    if not isinstance(proposal, dict) or proposal.get("version") != 1 or proposal.get("approved") is not False:
        raise ValueError("Reload the original Values proposal before confirming.")
    unsigned = {key: value for key, value in proposal.items() if key != "proposal_digest"}
    if proposal.get("proposal_digest") != _digest(unsigned):
        raise ValueError("The original Values proposal changed; reload it before confirming.")
    if proposal.get("raw_digest") != raw_digest(proposal.get("raw")):
        raise ValueError("The original Values cell changed; reload it before confirming.")


def _confirmation(actor_id, confirmed_at, edited):
    if not _text(actor_id, maximum=500):
        raise ValueError("Select a review profile before confirming the Values interpretation.")
    stamp = confirmed_at or datetime.now(timezone.utc).isoformat(timespec="seconds")
    try:
        instant = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
        if instant.tzinfo is None:
            raise ValueError("timezone required")
    except (AttributeError, TypeError, ValueError) as error:
        raise ValueError("The confirmation time must include its timezone.") from error
    return {"actor_id": actor_id, "at": stamp, "edited": edited}


def confirm(proposal, value, *, actor_id, source_digest, confirmed_at=None):
    """Record explicit confirmation of an edited proposal against current source."""
    _valid_proposal(proposal)
    if source_digest != proposal["source_digest"]:
        raise ValueError("The specification changed; reload the Values proposal before confirming.")
    issues = validate(value)
    if issues:
        raise ValueError(" ".join(issues))
    result = {"version": 1, "status": "confirmed", "approved": False,
              **{key: deepcopy(proposal[key]) for key in ("raw", "raw_digest", "citation", "source_digest", "origin")},
              "proposed_value": deepcopy(proposal["value"]), "value": deepcopy(value),
              "proposal_digest": proposal["proposal_digest"],
              "confirmation": _confirmation(actor_id, confirmed_at, value != proposal["value"])}
    result["record_digest"] = _digest(result)
    return result


def revise(record, value, *, actor_id, raw, citation, source_digest, confirmed_at=None):
    """Reconfirm user edits while retaining an earlier model/parser's origin.

    A fresh model token is unnecessary when a person edits an already confirmed
    source-bound record. Its initial confirmation and previous digest remain in
    the record; the product review history records each save separately.
    """
    issues = verify(record, raw=raw, citation=citation, source_digest=source_digest) + validate(value)
    if issues:
        raise ValueError(" ".join(issues))
    result = deepcopy(record)
    result["initial_confirmation"] = deepcopy(record.get("initial_confirmation", record["confirmation"]))
    result["revision_of"] = record["record_digest"]
    result["value"] = deepcopy(value)
    result["confirmation"] = _confirmation(actor_id, confirmed_at, value != record["proposed_value"])
    result.pop("record_digest", None)
    result["record_digest"] = _digest(result)
    return result


def verify(record, *, raw, citation, source_digest):
    """Check a saved interpretation's integrity and exact current source binding."""
    if not isinstance(record, dict) or record.get("version") != 1 or record.get("status") != "confirmed":
        return ["Confirm this Values interpretation before using it."]
    try:
        expected_source = _source(raw, citation, source_digest)
        unsigned = {key: value for key, value in record.items() if key != "record_digest"}
        issues = []
        if record.get("record_digest") != _digest(unsigned):
            issues.append("The saved Values interpretation changed; review and confirm it again.")
        if any(record.get(key) != value for key, value in expected_source.items()):
            issues.append("The Values interpretation belongs to an earlier specification; review and confirm it again.")
        if record.get("approved") is not False:
            issues.append("A Values interpretation cannot grant scientific approval.")
        confirmation = record.get("confirmation", {})
        if not isinstance(confirmation, dict) or not _text(confirmation.get("actor_id")) or not _text(confirmation.get("at")):
            issues.append("The Values confirmation needs its reviewer and date.")
        issues.extend(validate(record.get("value")))
        return issues
    except (TypeError, ValueError, OverflowError):
        return ["The saved Values interpretation is invalid; review and confirm it again."]


def fields_for_value(value):
    """Preview field changes for a valid editable value without confirming it."""
    errors = validate(value)
    if errors:
        raise ValueError(" ".join(errors))
    fields = {"output.type": value["data_type"]}
    if value["kind"] == "bands":
        fields["output.codes"] = [band["label"] for band in value["bands"]]
    elif value["kind"] in {"codes", "ordinal", "flag"}:
        fields["output.codes"] = deepcopy(value["codes"])
    else:
        fields["output.codes"] = []
    if value["kind"] == "continuous":
        fields["units"] = value.get("unit") or ""
    if value["kind"] == "date":
        # The workflow applies this only to declared parameter/constant rows.
        # Removing the fixed-date choice must also remove its previous value.
        fields["source.value"] = value.get("literal", "")
    if value.get("missing_allowed") is not None:
        fields["output.nullable"] = value["missing_allowed"]
    return fields


def review_fields(record):
    """Apply confirmed representation fields once, without inventing other rules.

    The caller must first use verify against its freshly read source. Band
    thresholds and continuous limits remain in this record; the output codelist
    contains labels only, not an invented executable derivation.
    """
    if not isinstance(record, dict) or record.get("status") != "confirmed":
        raise ValueError("Confirm the Values interpretation before using its fields.")
    errors = verify(record, **{key: record.get(key) for key in ("raw", "citation", "source_digest")})
    if errors:
        raise ValueError(" ".join(errors))
    return fields_for_value(record["value"])
