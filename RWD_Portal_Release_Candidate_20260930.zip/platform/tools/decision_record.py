#!/usr/bin/env python3
"""Record a human's answer to a decision.

    python platform/tools/decision_record.py <pack> --forms            # one form per OPEN decision
    python platform/tools/decision_record.py <pack> --apply [FORM...]  # transcribe filled forms

How an answer arrives: `--forms` writes one YAML form per open decision into
`handoff/decision_answers/`. A person types `answer`, `answered_by` and `answer_date`
into the form and commits it — there is no `--by` flag, and no tool ever writes those
fields. `--apply` transcribes the committed forms into DECISIONS.md. Each form carries
`question_sha256`, so an answer can never land on a question that changed after the
answerer read it.

Refusals:
  * a blank or placeholder answer, name, or date on a RESOLVED form;
  * `answered_by` naming a team — the approver is a person;
  * a stale `question_sha256` — re-issue the form;
  * a form for a row already settled — recorded answers are never overwritten; supersede
    with a new row instead;
  * a `|` in the answer (the register is a markdown table);
  * any defect in any form — the wave applies whole or not at all.

Filled forms stay committed after `--apply`: the register cell is the index, the form is
the answer as typed, and a later edit to either is a visible diff. Re-applying is
idempotent. After a wave, `--apply` prints the worklist of records that cite the settled
decisions and still say `decision_required`.

Needs PyYAML.
"""
import argparse
import hashlib
import os
import subprocess
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))
from rwd_tools.spec_extract import repo_relative                                  # noqa: E402

import yaml                                                              # noqa: E402
from rwd_tools import contract_lint                                                     # noqa: E402
from rwd_tools import decision_report                                                   # noqa: E402
from rwd_tools.contract_lint import ANSWER_COLUMNS, APPROVAL_DATE_COLUMNS, APPROVER_COLUMNS, DECISION_STATUSES, cell, decision_evidence, decision_question, decision_rows, decision_status
from rwd_tools.product_gates import bad_date, not_a_person, read_yaml, unstated    # noqa: E402

DECISIONS = os.path.join("handoff", "DECISIONS.md")
FORMS_DIR = os.path.join("handoff", "decision_answers")


def _blankish(value):
    """`unstated`, plus the register's own em/en-dash convention for "nothing here"."""
    return unstated(value) or str(value or "").strip() in {"—", "–"}


def _atomic_write(path, text):
    """Replace `path` with `text` in one step: unique temp file, fsync, `os.replace`.

    `open(path, "w")` TRUNCATES before it writes, so a fault mid-write leaves the register a
    fragment of itself — an external review's fault injection turned a 7,751-byte register into
    25 bytes. The temp file lands in the SAME directory (os.replace requires one filesystem) and
    carries a UNIQUE name (`mkstemp`) — a fixed `.tmp` name gave two concurrent writers one
    staging file to interleave in, which the review also flagged. The rename is atomic on every
    platform Python supports: readers see the whole old text or the whole new one, never a torn
    write.
    """
    import tempfile
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(os.path.abspath(path)) or ".",
                               prefix=os.path.basename(path) + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
            fh.write(text)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise

# What a form settles a question TO. RESOLVED is an answer and demands who/when; the other two are
# retractions — one says the question went away, the other that a different row now governs — and
# demanding a signature on a retraction is what `unaccountable_resolutions` deliberately does not do.
FORM_STATUSES = tuple(sorted(DECISION_STATUSES - {"OPEN"}))


def question_sha256(row):
    """The hash binding a form to the question it was issued for.

    Over question AND evidence: the evidence cell is part of what the answerer read — two conflicting
    spec values, a config default — and an evidence edit can flip which answer is right while the
    question's wording stays identical.
    """
    basis = (decision_question(row) or "").strip() + "\n" + (decision_evidence(row) or "").strip()
    return hashlib.sha256(basis.encode("utf-8")).hexdigest()


def citing_records_sha256(pack, did, root=ROOT):
    """The hash freezing the CITING RECORDS' requirement fields under an open question.

    `question_sha256` pins what was ASKED; this pins what it was asked ABOUT. Between issuing a
    form and transcribing its answer, the requirement fields of the records citing the decision
    must not move: the answerer judged those records as they stood, and an answer recorded onto
    silently reworded requirements is an answer to a different situation wearing the same id.
    This is the decision-blocked freeze — the contract stays hand-editable, but a hand edit under
    an OPEN question invalidates the outstanding form loudly instead of being transcribed over.

    Over each citing record's REQUIREMENT_FIELDS lines (contract_lint owns that partition), in
    sorted order. A pack with no contract, or a question no record cites, returns the SENTINEL
    `no-citing-records` rather than the hash of the empty string: the two states — "these exact
    requirement fields were frozen" and "nothing cites this question" — used to wear the same
    64-hex costume, so a form binding an answer to nothing looked exactly like one binding it to
    something. An external review flagged the disguise; the sentinel makes the vacuous freeze say
    so in the committed artifact.
    """
    contract = os.path.join(root, pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    parts = []
    if os.path.exists(contract):
        for block in contract_lint.records(contract_lint.read(contract)):
            if did not in (contract_lint._list(block, "decision_ids") or []):
                continue
            vid = contract_lint._scalar(block, "variable_id") or ""
            fields = [f"{k}: {contract_lint._scalar(block, k) or ''}"
                      for k in sorted(contract_lint.REQUIREMENT_FIELDS)]
            parts.append(vid + "\n" + "\n".join(fields))
    if not parts:
        return "no-citing-records"
    return hashlib.sha256("\x1f".join(sorted(parts)).encode("utf-8")).hexdigest()


def duplicate_keys(path):
    """Keys a form states twice. YAML last-wins would silently discard half an attestation — on
    the one artifact whose whole job is recording exactly what the person typed."""
    try:
        with open(path, encoding="utf-8") as fh:
            node = yaml.compose(fh)
    except yaml.YAMLError:
        return []                                    # unreadable is its own, earlier refusal
    dupes = []

    def walk(n):
        if isinstance(n, yaml.MappingNode):
            seen = set()
            for k, v in n.value:
                if isinstance(k, yaml.ScalarNode):
                    if k.value in seen:
                        dupes.append(k.value)
                    seen.add(k.value)
                walk(v)
        elif isinstance(n, yaml.SequenceNode):
            for c in n.value:
                walk(c)

    if node is not None:
        walk(node)
    return dupes


def write_forms(pack, root=ROOT, out_dir=None):
    """Emit one form per OPEN decision. Returns ([written], [skipped-existing], note-or-None).

    An EXISTING form is never overwritten, whatever it contains: a form on disk may be half-typed by
    the person answering it, and "regenerate the stubs" must never be able to destroy an answer.
    Stale forms are retired by deleting them, which is a visible act in a diff.
    """
    path = os.path.join(root, pack, DECISIONS)
    if not os.path.exists(path):
        return [], [], f"{pack} keeps no {DECISIONS} — there is no register to answer."
    text = contract_lint.read(path)
    reg_bad = contract_lint.decision_register_errors(text, pack)
    if reg_bad:
        return [], [], (f"the register itself does not parse as a governed table — a form issued "
                        f"off a duplicated or malformed row would answer the wrong question. Fix "
                        f"these first:\n  " + "\n  ".join(reg_bad))
    rows, status = decision_rows(text), decision_status(text)
    if not rows:
        return [], [], f"{pack}'s decisions register holds no readable rows."

    # A FORM IS ONLY AS GOOD AS THE QUESTION ON IT. An OPEN row whose Question, Evidence or Owner
    # is blank or a placeholder would issue a form asking a person to attest an answer to nothing —
    # and the attestation machinery downstream would bind their signature to that nothing. Refused
    # for the whole wave: the register is repaired first, then the forms are issued.
    hollow = []
    for did, row in sorted(rows.items()):
        if str(status.get(did, "OPEN")).strip().upper() != "OPEN":
            continue
        for label, value in (("Question", decision_question(row)),
                             ("Evidence", decision_evidence(row)),
                             ("Owner", cell(row, "Owner", default=""))):
            if _blankish(value):
                hollow.append(f"{did}: {label} is blank or a placeholder")
    if hollow:
        return [], [], (f"{pack}'s register has OPEN rows a form cannot be issued for — an answer "
                        f"would attest to nothing. Fill these cells first:\n  "
                        + "\n  ".join(hollow))

    dest = out_dir or os.path.join(root, pack, FORMS_DIR)
    os.makedirs(dest, exist_ok=True)
    written, kept = [], []
    for did, row in sorted(rows.items()):
        if str(status.get(did, "OPEN")).strip().upper() != "OPEN":
            continue
        target = os.path.join(dest, f"{did}.yaml")
        if os.path.exists(target):
            kept.append(target)
            continue
        body = yaml.safe_dump(
            {"decision_id": did,
             "pack": pack,
             "question": (decision_question(row) or "").strip(),
             "evidence": (decision_evidence(row) or "").strip(),
             "question_sha256": question_sha256(row),
             "records_sha256": citing_records_sha256(pack, did, root),
             "answer": "",
             "answered_by": "",
             "answer_date": "",
             "status": "RESOLVED",
             "superseded_by": ""},
            sort_keys=False, allow_unicode=True, width=98, default_flow_style=False)
        head = (
            "# Decision answer form — fill BY HAND, then commit.\n"
            "#   answer        what was decided, in full sentences (no `|` — this lands in a table)\n"
            "#   answered_by   the PERSON who decided (a name, never a team)\n"
            "#   answer_date   YYYY-MM-DD\n"
            "#   status        RESOLVED as issued; change it to WITHDRAWN / SUPERSEDED (then name superseded_by)\n"
            "# question / evidence / question_sha256 are the question as issued, and records_sha256\n"
            "# freezes the citing records' requirement fields while it is open — edit none of them.\n"
            f"# Record it:  python3 platform/tools/decision_record.py {pack} --apply\n")
        _atomic_write(target, head + body)
        written.append(target)
    return written, kept, None


# --------------------------------------------------------------------------- applying
def _column_segment(header_line, *names):
    """The pipe-segment index of the first of `names` present in this header, or None.

    Resolved the way `cell` resolves — case- and spacing-insensitively — so the writer cannot
    disagree with the reader about which column is which.
    """
    cols = [re.sub(r"\s+", " ", c).strip().lower() for c in header_line.strip().strip("|").split("|")]
    for n in names:
        want = re.sub(r"\s+", " ", n).strip().lower()
        if want in cols:
            return cols.index(want) + 1              # +1: segment 0 is the text left of the first |
    return None


def _one_line(value):
    """A form value as a table cell: internal whitespace (including newlines) collapsed to spaces.

    The words are the answerer's, untouched; only the line structure changes, because a markdown
    table row IS one line. Pipes are refused before this is reached.
    """
    return " ".join(str(value or "").split())


def form_errors(form, path, register_rows, register_status, records_sha=None,
                expected_pack=None, root=ROOT):
    """[why this form cannot be recorded] — every check fail-closed, all of them reported at once.

    `records_sha` is {decision_id: citing_records_sha256(...)} computed by the caller against the
    contract as it stands NOW. When supplied, every form must carry a matching `records_sha256` —
    a missing field reads as a form that predates (or hand-dropped) the freeze, and fail-closed
    means it is re-issued, not waved through."""
    rel = path
    errors = []
    if not isinstance(form, dict):
        return [f"{rel}: not a YAML mapping — was the form hand-edited into another shape?"]
    did = str(form.get("decision_id") or "").strip()
    if not did:
        return [f"{rel}: carries no decision_id"]
    row = register_rows.get(did)
    if row is None:
        return [f"{rel}: {did} is not in the register — was the row renamed after the form was issued?"]

    # The DISPLAYED question must be the HASHED question. The stored hash pins the register's
    # wording; without re-hashing the form's own question/evidence text, a form could show the
    # answerer altered clinical wording while carrying the original hash — and apply cleanly.
    shown = ((str(form.get("question") or "").strip()) + "\n"
             + (str(form.get("evidence") or "").strip()))
    if hashlib.sha256(shown.encode("utf-8")).hexdigest() != \
            str(form.get("question_sha256") or "").strip():
        errors.append(f"{rel}: {did} the form's DISPLAYED question/evidence does not hash to its "
                      f"own question_sha256 — the wording shown to the answerer was edited after "
                      f"issue. Delete the form and re-issue with --forms.")
    fpack = str(form.get("pack") or "").strip()
    if expected_pack and not fpack:
        errors.append(f"{rel}: {did} the form names no pack — deleting `pack:` was enough to make "
                      f"a form portable between registers, and a form answers exactly the register "
                      f"it was issued from. Re-issue it (--forms).")
    elif fpack and expected_pack and fpack != expected_pack:
        errors.append(f"{rel}: {did} the form names pack {fpack!r} but is being applied to "
                      f"{expected_pack!r} — a form answers exactly the register it was issued from.")
    stem = os.path.splitext(os.path.basename(path))[0]
    if stem != did:
        errors.append(f"{rel}: filename {stem!r} does not match its decision_id {did!r} — one form "
                      f"per decision, named for it, so a directory listing IS the answered set.")
    # An answer must answer SOMETHING. A form whose displayed question or evidence is blank (or the
    # register's own `—`) binds a signature to nothing — the hash checks above cannot catch it,
    # because a blank question hashes as consistently as a real one.
    for label in ("question", "evidence"):
        if _blankish(form.get(label)):
            errors.append(f"{rel}: {did} `{label}` is blank or a placeholder — an attestation over "
                          f"an empty {label} binds the answer to nothing. Repair the register row "
                          f"and re-issue the form (--forms).")
    want = question_sha256(row)
    got = str(form.get("question_sha256") or "").strip()
    if got != want:
        errors.append(f"{rel}: {did} question_sha256 is {got[:12] or '(blank)'}… but the register's "
                      f"question now hashes to {want[:12]}… — the question changed after this form "
                      f"was issued. Delete the form and re-issue it (--forms); the answer may no "
                      f"longer answer what is being asked.")

    # Only while the row is still OPEN — that is the freeze's whole window. After the answer lands,
    # the unblocked records are SUPPOSED to change (the worklist exists to change them), and a
    # re-applied wave must stay idempotent over that legitimate movement.
    if records_sha is not None and str(register_status.get(did, "OPEN")).strip().upper() == "OPEN":
        rec_want = records_sha.get(did, "")
        rec_got = str(form.get("records_sha256") or "").strip()
        if not rec_got:
            errors.append(f"{rel}: {did} carries no records_sha256 — the form predates (or lost) "
                          f"the citing-records freeze. Delete it and re-issue with --forms so the "
                          f"answer is given against the records as they now stand.")
        elif rec_got != rec_want:
            errors.append(f"{rel}: {did} records_sha256 is {rec_got[:12]}… but the citing records' "
                          f"requirement fields now hash to {rec_want[:12]}… — a record this "
                          f"question gates changed after the form was issued. Re-read those "
                          f"records, delete the form and re-issue (--forms); the answer may have "
                          f"been judged against requirements that no longer say the same thing.")

    st = str(form.get("status") or "").strip().upper()
    if st not in FORM_STATUSES:
        errors.append(f"{rel}: {did} status {st or '(blank)'!r} is not one of {FORM_STATUSES} — a "
                      f"form settles a question; leaving it OPEN is not a recordable act.")
        return errors

    answer = str(form.get("answer") or "")
    if "answer_choice" in form:
        from rwd_tools import decision_choice
        try:
            decision_choice.validated(form)
        except (ValueError, TypeError, KeyError) as error:
            errors.append(f"{rel}: {did} {error}")
    if len(answer) > 4000:
        errors.append(f"{rel}: {did} answer is {len(answer)} characters — a register cell is a "
                      f"ruling, not a document. State the decision; detail belongs in the "
                      f"artifacts the ruling governs.")
    if "|" in answer:
        errors.append(f"{rel}: {did} answer contains `|` — the register is a markdown table and its "
                      f"readers split on pipes. Rephrase (e.g. 'or' / a semicolon).")
    if st == "RESOLVED":
        for field in ("answer", "answered_by", "answer_date"):
            if unstated(form.get(field)):
                errors.append(f"{rel}: {did} `{field}` is blank or a placeholder — an answer nobody "
                              f"is recorded as having given is not recordable. Type it into the "
                              f"form; there is no flag for it.")
        why = not_a_person(form.get("answered_by")) if not unstated(form.get("answered_by")) else None
        if why:
            errors.append(f"{rel}: {did} answered_by: {why}")
        bad = bad_date(form.get("answer_date")) if not unstated(form.get("answer_date")) else None
        if bad:
            errors.append(f"{rel}: {did} answer_date {bad}")
    # The structured equivalence block, validated at the EARLIEST gate. record_event refuses
    # these too — but by then the register row is written, and a wave that half-lands is the
    # state auto-seal exists to prevent. Same rules, same closed vocabulary, one gate sooner.
    eq = form.get("equivalence")
    if isinstance(eq, dict):
        from rwd_tools import semantic_view as _sv                                       # noqa: PLC0415
        missing = [k for k in EQUIVALENCE_FIELDS if not str(eq.get(k) or "").strip()]
        if missing:
            errors.append(f"{rel}: {did} the equivalence block leaves {', '.join(missing)} "
                          f"unstated — a structured outcome names the verdict, the variable "
                          f"and both sources, or the block comes out.")
        if not missing and eq.get("equivalence_outcome") not in _sv.VOCAB:
            errors.append(f"{rel}: {did} equivalence_outcome {eq.get('equivalence_outcome')!r} "
                          f"is not in the closed vocabulary {list(_sv.VOCAB)} — an outcome word "
                          f"outside it is exactly what the sealed rulings refuse.")
        for why in equivalence_definition_errors(eq, root):
            errors.append(f"{rel}: {did} {why}")
    if st == "SUPERSEDED":
        sid = str(form.get("superseded_by") or "").strip()
        if not sid:
            errors.append(f"{rel}: {did} is SUPERSEDED by nothing — name the decision that now "
                          f"governs in `superseded_by`.")
        elif sid == did:
            errors.append(f"{rel}: {did} cannot supersede itself.")
        elif sid not in register_rows:
            errors.append(f"{rel}: {did} superseded_by {sid} is not in the register — add the new "
                          f"decision row first, then retire this one.")

    current = str(register_status.get(did, "OPEN")).strip().upper()
    if current != "OPEN" and errors == [] and not _already_recorded(form, row):
        errors.append(f"{rel}: {did} is already {current} in the register and this form says "
                      f"something different. A recorded answer is never overwritten: add a NEW "
                      f"decision row for the revised question, then record this one as "
                      f"status: SUPERSEDED / superseded_by: <new ID>.")
    return errors


def _cell_values(form):
    """{column-role: text} this form would put in the row, exactly as the writer will."""
    st = str(form.get("status") or "").strip().upper()
    answer = _one_line(form.get("answer"))
    if st == "SUPERSEDED":
        sid = str(form.get("superseded_by") or "").strip()
        pointer = f"Superseded by {sid}."
        answer = f"{answer} {pointer}" if answer and pointer not in answer else (answer or pointer)
    return {"answer": answer,
            "approver": _one_line(form.get("answered_by")),
            "date": _one_line(form.get("answer_date")),
            "status": st}


def _already_recorded(form, row):
    """True when the row already says exactly what this form says — the idempotent re-apply.

    Status through the SAME normaliser every other reader uses (`_status_text` strips markdown):
    comparing the raw cell made a hand-bolded `**RESOLVED**` unequal to the form's RESOLVED, so
    the idempotent path was lost and the user was confidently told to SUPERSEDE an identical
    answer — a factually false refusal."""
    from rwd_tools.contract_lint import _status_text
    want = _cell_values(form)
    return (_status_text(cell(row, "Status")) == want["status"]
            and cell(row, *ANSWER_COLUMNS).strip() == want["answer"]
            and cell(row, *APPROVER_COLUMNS).strip() == want["approver"]
            and cell(row, *APPROVAL_DATE_COLUMNS).strip() == want["date"])


def apply_forms(pack, form_paths=None, root=ROOT):
    """(applied ids, skipped-as-recorded ids, errors, new register text or None).

    All-or-nothing by construction: every form is validated against the register BEFORE a single row
    changes, and the register is returned rewritten only when the error list is empty. Rows not named
    by a form are byte-identical in the result — the rewrite substitutes cells, it does not reformat.
    """
    reg_path = os.path.join(root, pack, DECISIONS)
    if not os.path.exists(reg_path):
        return [], [], [f"{pack} keeps no {DECISIONS}"], None
    text = contract_lint.read(reg_path)
    # A WELL-FORMED REGISTER, before any row means anything. `decision_rows` keys by id, so a
    # duplicated id resolves last-wins — contract_lint reports the duplicate, but this tool used
    # to accept the register anyway and rewrite whichever row the keying kept. Refuse the wave:
    # a register with two rows for one question has no row an answer can safely land in.
    reg_bad = contract_lint.decision_register_errors(text, pack)
    if reg_bad:
        return [], [], [f"the register itself does not parse as a governed table — fix it before "
                        f"any answer lands:"] + reg_bad, None
    rows, status = decision_rows(text), decision_status(text)

    if form_paths is None:
        dirp = os.path.join(root, pack, FORMS_DIR)
        form_paths = sorted(
            os.path.join(dirp, f) for f in os.listdir(dirp)
            if f.endswith(".yaml")) if os.path.isdir(dirp) else []
    if not form_paths:
        return [], [], [f"no answer forms found — write them with --forms, or pass files to --apply"], None

    rsha = {did: citing_records_sha256(pack, did, root) for did in rows}
    errors, todo, skipped = [], [], []
    for path in form_paths:
        if not os.path.isfile(path):
            # `--forms` prints pack-relative paths, so a person passes one back; that used to raise
            # FileNotFoundError out of duplicate_keys (thirteenth pass, J7)
            in_pack = os.path.join(root, pack, path)
            if os.path.isfile(in_pack):
                path = in_pack
            else:
                errors.append(f"{path}: no such form — a form path is repository-relative "
                              f"({FORMS_DIR}/<ID>.yaml under the pack) or pack-relative; nothing was applied")
                continue
        form, unreadable = read_yaml(path)
        for k in duplicate_keys(path):
            errors.append(f"{path}: states `{k}` twice — YAML keeps only the last, which would "
                          f"silently discard half an attestation. Keep exactly one.")
        if unreadable:
            hint = (" — an unquoted impossible date (a day that month does not have) fails YAML itself "
                    "before any field check runs; find the date in the form, quote it or fix it"
                    if "out of range" in str(unreadable) else "")
            errors.append(f"{path}: unreadable YAML ({unreadable}){hint}")
            continue
        errs = form_errors(form, path, rows, status, records_sha=rsha, expected_pack=pack, root=root)
        if errs:
            errors.extend(errs)
        elif _already_recorded(form, rows[str(form.get("decision_id")).strip()]):
            skipped.append(str(form.get("decision_id")).strip())
        else:
            todo.append(form)
    if errors:
        return [], skipped, errors, None
    if not todo:
        return [], skipped, [], None

    lines = text.splitlines(keepends=True)
    hdr_idx = next((i for i, l in enumerate(lines)
                    if l.startswith("|") and re.search(contract_lint.id_column_re(), l)), None)
    if hdr_idx is None:
        return [], skipped, [f"{pack}/{DECISIONS}: no `| ID | …` header — the register is not a "
                             f"table this tool can write into"], None
    header = lines[hdr_idx]
    seg = {"answer": _column_segment(header, *ANSWER_COLUMNS),
           "approver": _column_segment(header, *APPROVER_COLUMNS),
           "date": _column_segment(header, *APPROVAL_DATE_COLUMNS),
           "status": _column_segment(header, "Status")}
    for role, names in (("answer", ANSWER_COLUMNS), ("approver", APPROVER_COLUMNS),
                        ("date", APPROVAL_DATE_COLUMNS), ("status", ("Status",))):
        if seg[role] is None:
            errors.append(f"{pack}/{DECISIONS}: the register has no `{names[0]}` column, so an "
                          f"answer has nowhere to land. Extend the header (accepted spellings: "
                          f"{', '.join(names)}) — the template's is canonical.")
    if errors:
        return [], skipped, errors, None

    applied = []
    by_id = {str(f["decision_id"]).strip(): f for f in todo}
    for i, line in enumerate(lines):
        if not line.startswith("|"):
            continue
        first = line.strip().strip("|").split("|")[0].strip()
        form = by_id.get(first)
        if not form:
            continue
        parts = line.rstrip("\n").split("|")
        want = _cell_values(form)
        for role, value in (("answer", want["answer"]), ("approver", want["approver"]),
                            ("date", want["date"]), ("status", want["status"])):
            if value or role == "status":
                parts[seg[role]] = f" {value} "
        lines[i] = "|".join(parts) + "\n"
        applied.append(first)
    missing = sorted(set(by_id) - set(applied))
    if missing:
        return [], skipped, [f"{pack}/{DECISIONS}: row(s) {missing} vanished between validation and "
                             f"rewrite — nothing was written"], None
    return applied, skipped, [], "".join(lines)


def signed_rulings(pack, root=ROOT):
    """The decision ids `check_bindings` will actually EXAMINE — RESOLVED with a named approver.

    Named separately because the check's own OK line covered zero of them on both live packs and
    read as "every signed ruling matches its committed form". Every one of the repository's
    RESOLVED rows is unsigned, so the loop body never ran; the sentence was true and meant nothing.
    A count is what tells those two states apart.
    """
    reg_path = os.path.join(root, pack, DECISIONS)
    if not os.path.exists(reg_path):
        return []
    from rwd_tools.contract_lint import read
    text = read(reg_path)
    rows, status = decision_rows(text), decision_status(text)
    return [d for d in sorted(rows)
            if status.get(d) == "RESOLVED" and cell(rows[d], *APPROVER_COLUMNS).strip()]


def check_bindings(pack, root=ROOT):
    """[errors] — the OTHER half of the attestation loop.

    `--apply` guards the OPEN→RESOLVED transition; nothing guarded the RESOLVED ruling afterwards:
    the answer cell — the governed scientific fact — could be rewritten by hand and every gate
    stayed green (red-team finding N1). So: every RESOLVED row with a NAMED approver must be
    indexed to its committed form, the form's question_sha256 must still match the question as it
    stands, and the row must say exactly what the form says. A row that drifted from its form is a
    ruling bound to nothing. Unsigned RESOLVED rows stay the maturity path's finding
    (product_gates/dry_run flag them at contract:approved) — reporting them twice is one defect."""
    reg_path = os.path.join(root, pack, DECISIONS)
    if not os.path.exists(reg_path):
        return []
    from rwd_tools.contract_lint import read
    text = read(reg_path)
    rows, status = decision_rows(text), decision_status(text)
    errors = []
    for did in sorted(rows):
        if status.get(did) != "RESOLVED":
            continue
        row = rows[did]
        approver = cell(row, *APPROVER_COLUMNS).strip()
        if not approver:
            continue
        rel = f"{FORMS_DIR}/{did}.yaml".replace(os.sep, "/")
        path = os.path.join(root, pack, FORMS_DIR, f"{did}.yaml")
        if not os.path.exists(path):
            tracked = subprocess.run(["git", "-C", root, "ls-files", "--error-unmatch", os.path.join(pack, rel)],
                                     capture_output=True, text=True, encoding="utf-8").returncode == 0
            errors.append(f"{did}: RESOLVED and signed ({approver}) but {rel} is "
                          + (f"missing from the working tree (it is committed — restore it: git checkout -- {pack}/{rel})"
                             if tracked else "not committed")
                          + " — the ruling is indexed to no attestation, so a hand edit to the answer cell would be invisible")
            continue
        form, unreadable = read_yaml(path)
        if unreadable or not isinstance(form, dict):
            errors.append(f"{did}: {rel} is unreadable ({unreadable}) — an attestation that "
                          f"cannot be read binds nothing")
            continue
        # Equal text is not valid evidence: coordinated edits to both projections must
        # still satisfy the same content, person and date rules as the original apply.
        errors += [f"{did}: {e}" for e in form_errors(
            form, path, rows, status, expected_pack=pack, root=root)]
        if duplicate_keys(path):
            errors.append(f"{did}: {rel} repeats YAML keys; the recorded answer is ambiguous")
        if str(form.get("question_sha256") or "").strip() != question_sha256(row):
            errors.append(f"{did}: the register's question/evidence no longer hash to the form's "
                          f"question_sha256 — the question moved after it was answered; the "
                          f"answer may no longer answer what is asked")
        # ...and the form's OWN displayed wording must still hash to its stored hash. After
        # recording, an editor could reword the shown question/evidence while keeping the old
        # hash — the register comparison above stays green because the REGISTER did not move,
        # and the attestation then shows wording nobody answered.
        _shown = ((str(form.get("question") or "").strip()) + "\n"
                  + (str(form.get("evidence") or "").strip()))
        if hashlib.sha256(_shown.encode("utf-8")).hexdigest() != \
                str(form.get("question_sha256") or "").strip():
            errors.append(f"{did}: {rel} displays question/evidence that do not hash to its own "
                          f"question_sha256 — the attestation's shown wording was edited after "
                          f"recording, so the form no longer shows what was answered")
        if not _already_recorded(form, row):
            errors.append(f"{did}: the register row does not say what {rel} says — answer, "
                          f"approver, date or status drifted after recording; a recorded ruling "
                          f"changes only by SUPERSEDE, never by edit")
    return errors


def open_question(pack, id_, question, owner, root, evidence=None):
    """Append one OPEN row to the register — the write side of RAISING a question.

    Every simulated drafting journey hand-typed 16-22 long register rows and asked for exactly
    this; only downstream lints caught a broken pipe. Mirrors the answer-side tooling in shape but
    not in authority: it writes NO approver, NO date, NO resolution — Status is OPEN, always.
    Answering stays where it was: a hand-typed committed form, transcribed by --apply.

    REFUSED means NOTHING WAS WRITTEN — like --apply, all validation happens on an in-memory
    candidate and the file is replaced once, atomically, only after the candidate parses. The
    first version wrote first and validated after, so a refusal could leave the row it refused;
    an external review reproduced exactly that against a malformed register.

    `evidence` is required: a question raised on nothing points its answerer at nothing, and the
    live case that motivated it (a register row with Evidence `—` and an empty blast radius)
    binds an attestation to no citable content. A `tab:row` citation, a repo-relative path, or a
    named finding all serve; emptiness does not.
    """
    path = os.path.join(root, pack, DECISIONS)
    if not os.path.exists(path):
        sys.exit(f"{pack} has no {DECISIONS} — copy the template's register first; this tool "
                 f"appends questions, it does not create the file that explains them")
    if not re.fullmatch(r"[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)*", id_):
        sys.exit(f"{id_!r} is not a decision id — UPPERCASE words joined by dashes (OC9-MAXINDEX, "
                 f"DPM-CONST), so records can cite it and I2 can hold the citation")
    if not (question or "").strip():
        sys.exit("--question is required: a register row without a question is a placeholder "
                 "nobody can answer")
    if _blankish(owner):
        sys.exit("--owner is blank or a placeholder: a question put to nobody is a question "
                 "nobody will answer — name the function or person it goes to")
    if not (evidence or "").strip():
        sys.exit("--evidence is required: name what the answerer should look at — a `tab:row` "
                 "citation, a finding id, or a repo-relative path. A question raised on nothing "
                 "binds its eventual answer to nothing")
    # ...and it must NAME something this repository can check, not merely look like a citation.
    # `--evidence x` passed the presence check; then `not_a_real_tab:999999` and imaginary finding
    # ids passed the SHAPE check — syntactic validation binds the answer to nothing. Three forms,
    # each resolved as far as the checkout can resolve it:
    #   * a finding id (CAPS-AND-DASHES) must exist in the pack's SPEC_QC register;
    #   * a `tab:row` citation's tab must exist in the pack's sanitized extraction WHEN one is
    #     committed (a pack whose extraction is still pending cites the workbook the repo cannot
    #     read — the citation form is accepted there, stated as far as it can be checked);
    #   * a repo path must exist.
    ev = str(evidence).strip().strip("`")            # `tab:row` — the register's code-format wrap
    looks_finding = bool(re.fullmatch(r"[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)+", ev))
    is_path = os.path.exists(os.path.join(root, ev.replace("\\", "/")))
    cite = re.match(r"^([\w][\w .-]*?)\s*:\s*\S", ev)
    if looks_finding:
        qc_path = os.path.join(root, pack, "handoff", "SPEC_QC_FINDINGS.md")
        qc_ids = set()
        if os.path.exists(qc_path):
            qc_ids = set(re.findall(r"(?m)^\|\s*([A-Z][A-Z0-9-]+)\s*\|",
                                    open(qc_path, encoding="utf-8").read()))
        if ev not in qc_ids:
            sys.exit(f"--evidence {ev!r} looks like a finding id and the pack's "
                     f"SPEC_QC_FINDINGS.md does not carry it — an imaginary finding binds the "
                     f"answer to nothing. Cite a real finding, a tab:row, or a repo path")
    elif cite and not is_path:
        extracted = os.path.join(root, pack, "spec_pipeline", "out", "extracted.json")
        if os.path.exists(extracted):
            import json as _json
            try:
                _rows = _json.load(open(extracted, encoding="utf-8")).get("rows") or []
                _tabs = {str(r.get("tab") or "").strip().lower()
                         for r in _rows if isinstance(r, dict)} - {""}
                # THE GRAMMAR EVERY OTHER TOOL PRINTS: `<domain>:<row>` is the item id a contract
                # record cites (`spec_refs`) and SPEC_FINDINGS.txt names findings by. A person who
                # copied `outcomes:4` from the findings was refused for it (twelfth verdict journey);
                # the domain form binds to exactly one extracted row, which is stronger than a tab.
                _items = {str(r.get("item_id") or "").strip().lower()
                          for r in _rows if isinstance(r, dict)} - {""}
                _domains = {str(r.get("domain") or "").strip().lower()
                            for r in _rows if isinstance(r, dict)} - {""}
            except Exception:                        # noqa: BLE001 — unreadable extraction
                _tabs, _items, _domains = set(), set(), set()   # cannot vouch; the citation stands unchecked
            head = cite.group(1).strip().lower()
            if _tabs and head not in _tabs and head not in _domains:
                sys.exit(f"--evidence {ev!r} cites tab {cite.group(1)!r} and the pack's "
                         f"sanitized extraction has no such tab (nor a domain of that name) — a "
                         f"citation into a document that does not say it binds the answer to "
                         f"nothing. Real tabs: {', '.join(sorted(_tabs))}; domains: "
                         f"{', '.join(sorted(_domains))}")
            if _items and head in _domains and ev.strip().lower() not in _items:
                sys.exit(f"--evidence {ev!r} names no extracted row: the {head} domain carries "
                         f"{', '.join(sorted(i for i in _items if i.startswith(head + ':'))[:12])}")
    elif not (cite or is_path):
        sys.exit(f"--evidence {ev!r} names nothing checkable: not a `tab:row`-style citation, not "
                 f"a finding id (CAPS-AND-DASHES), and not a path that exists in this repository. "
                 f"Point the answerer at the thing itself")
    cells = {"id": id_, "question": question, "owner": owner, "evidence": evidence}
    for field, val in cells.items():
        if "|" in val:
            sys.exit(f"the {field} contains a pipe, which breaks the register table — rephrase")
        if any(ch in val for ch in "\r\n") or any(ord(ch) < 32 for ch in val if ch != "\t"):
            sys.exit(f"the {field} contains a line break or control character — a register row "
                     f"is ONE line; rephrase as a single sentence (the answer form has room "
                     f"for detail)")
    text = open(path, encoding="utf-8", newline="").read()
    if id_ in contract_lint.decision_ids(text):
        sys.exit(f"{id_} is already in the register — one row per question; edit the existing row "
                 f"only through the answer machinery")
    # The register must be WELL-FORMED before the append, or the refusal blames the wrong text.
    errs = contract_lint.decision_register_errors(text, os.path.basename(pack))
    if errs:
        for e in errs:
            print(f"  {e}", file=sys.stderr)
        sys.exit(f"REFUSED — nothing was written. {pack}/{DECISIONS} does not parse as it "
                 f"stands; fix the register before raising a new question in it")
    lines = text.split("\n")
    last_row = max((i for i, ln in enumerate(lines) if ln.strip().startswith("|")), default=None)
    if last_row is None:
        sys.exit(f"REFUSED — nothing was written. {pack}/{DECISIONS} has no table; restore the "
                 f"register's header row first")
    lines.insert(last_row + 1,
                 f"| {id_} | {question.strip()} | {evidence.strip()} | {owner.strip()} "
                 f"| — |  |  | OPEN |")
    candidate = "\n".join(lines)
    errs = contract_lint.decision_register_errors(candidate, os.path.basename(pack))
    if errs or id_ not in contract_lint.decision_ids(candidate):
        for e in errs:
            print(f"  {e}", file=sys.stderr)
        sys.exit(f"REFUSED — nothing was written. The appended row would not parse back; "
                 f"rephrase the question as one plain sentence")
    _atomic_write(path, candidate)
    print(f"OPEN     {id_} -> {pack}/{DECISIONS} (owner {owner.strip()})")
    print("Cite it from the blocked record(s): decision_ids: [" + id_ + "]")
    return 0


def partition_untouched(pack, root=ROOT):
    """([submitted/invalid forms], [valid but incomplete OPEN draft ids]).

    Missing response fields do not submit an unsealed OPEN draft. Invalid provenance,
    malformed forms and existing rulings still fail closed. Explicit paths are never skipped.
    """
    dirp = os.path.join(root, pack, FORMS_DIR)
    if not os.path.isdir(dirp):
        return [], []
    answered, untouched = [], []
    register = contract_lint.read(os.path.join(root, pack, DECISIONS))
    rows, statuses = decision_rows(register), decision_status(register)
    for f in sorted(os.listdir(dirp)):
        if not f.endswith(".yaml"):
            continue
        path = os.path.join(dirp, f)
        form, err = read_yaml(path)
        did = str(form.get("decision_id") or "") if isinstance(form, dict) else ""
        blank = (not err and isinstance(form, dict) and not duplicate_keys(path)
                 and statuses.get(did) == "OPEN"
                 and any(_blankish(form.get(k)) for k in ("answer", "answered_by", "answer_date"))
                 and not str(form.get("object_uuid") or "").strip()
                 and str(form.get("status") or "").strip().upper() == "RESOLVED")
        if blank:
            problems = form_errors(form, path, rows, statuses,
                records_sha={did: citing_records_sha256(pack, did, root)}, expected_pack=pack, root=root)
            blank = not [e for e in problems if not any(
                f"`{field}` is blank or a placeholder" in e for field in ("answer", "answered_by", "answer_date"))]
        if blank:
            untouched.append(str(form.get("decision_id") or os.path.splitext(f)[0]))
        else:
            answered.append(path)
    return answered, untouched


def stale_open_forms(pack, root=ROOT):
    """[why] — issued forms for OPEN rows whose question or citing records moved since issue.

    Second pass of the eleventh verdict: four committed prostate forms were stale at HEAD, so a
    person following the runbook was refused only AFTER typing an answer into one. Read-only; the
    repair is the one the refusal names — delete the stale form and re-issue it with --forms.
    """
    reg_path = os.path.join(root, pack, DECISIONS)
    dirp = os.path.join(root, pack, FORMS_DIR)
    if not os.path.exists(reg_path) or not os.path.isdir(dirp):
        return []
    text = contract_lint.read(reg_path)
    rows, status = decision_rows(text), decision_status(text)
    out = []
    for f in sorted(os.listdir(dirp)):
        if not f.endswith(".yaml"):
            continue
        path = os.path.join(dirp, f)
        form, err = read_yaml(path)
        if err or not isinstance(form, dict):
            continue                              # apply_forms reports an unreadable form
        did = str(form.get("decision_id") or "").strip()
        row = rows.get(did)
        if row is None or str(status.get(did, "OPEN")).strip().upper() != "OPEN":
            continue
        rel = repo_relative(path, root)
        if str(form.get("question_sha256") or "").strip() != question_sha256(row):
            out.append(f"{rel}: {did} is OPEN and the form's question_sha256 no longer matches the "
                       f"register — delete the form and re-issue it (--forms) before anyone answers it")
        if str(form.get("records_sha256") or "").strip() != citing_records_sha256(pack, did, root):
            out.append(f"{rel}: {did} is OPEN and the form's records_sha256 no longer matches the "
                       f"citing records — delete the form and re-issue it (--forms) before anyone "
                       f"answers it")
    return out


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack", help="the pack directory (repo-root-relative)")
    ap.add_argument("--forms", action="store_true",
                    help=f"emit one YAML answer form per OPEN decision into {FORMS_DIR}/")
    ap.add_argument("--apply", nargs="*", metavar="FORM",
                    help=f"transcribe filled forms (default: every .yaml in {FORMS_DIR}/)")
    ap.add_argument("--check", action="store_true",
                    help="CI: every signed RESOLVED row must match its committed form")
    ap.add_argument("--record-event", metavar="ID",
                    help="seal one RESOLVED answer form into the approval-event ledger "
                         "(actor transcribed from the form's answered_by; an immutable "
                         "unsigned assertion until signing keys exist)")
    ap.add_argument("--open", metavar="ID",
                    help="append an OPEN question row to DECISIONS.md (with --question / --owner). "
                         "Raising a question is the drafter's act; answering it is not — the row "
                         "is written with empty approver fields and Status OPEN, always")
    ap.add_argument("--question", help="the question text for --open")
    ap.add_argument("--evidence", help="what the answerer should look at (required with --open): "
                                       "a `tab:row` citation, a finding id, or a repo path")
    ap.add_argument("--owner", default="Science", help="who the question is put to (default Science)")
    a = ap.parse_args(argv)
    if a.record_event:
        now = _now_recorded()
        event, why = record_event(ROOT, a.pack, a.record_event, now)
        if why:
            print(f"REFUSED - {why}")
            return 1
        if str(event.get("occurred_at")) != now:           # an idempotent replay wrote nothing (thirteenth pass)
            print(f"already sealed {event['object_uuid']} seq {event['seq']} ({event['action']}) on "
                  f"{event.get('occurred_at')} - nothing new recorded")
            return 0
        print(f"sealed {event['object_uuid']} seq {event['seq']} ({event['action']}, "
              f"trust {event['actor']['trust_level']}) - commit governance/events/ with "
              f"the form")
        return 0
    pack = repo_relative(os.path.abspath(a.pack), ROOT)
    if not os.path.isdir(os.path.join(ROOT, pack)):
        sys.exit(f"{a.pack}: not a directory")
    if sum((a.forms, a.apply is not None, a.check, a.open is not None)) != 1:
        sys.exit("choose exactly one of --forms / --apply / --check / --open")

    if a.open is not None:
        return open_question(pack, a.open, a.question, a.owner, root=ROOT, evidence=a.evidence)

    if a.check:
        bad = check_bindings(pack, root=ROOT)
        # ...AND THE FORMS NOBODY HAS ANSWERED YET: a stale one is red here, before a person types
        bad += stale_open_forms(pack, root=ROOT)
        for e in bad:
            print(f"  {e}", file=sys.stderr)
        # A COUNT, NOT A VERDICT. Zero signed rulings is the state of every register in this
        # repository, and "every signed ruling matches" over zero of them is an absence wearing a
        # pass. Say how many were examined, and when that is none, say what it does not prove.
        examined = signed_rulings(pack, root=ROOT)

        # ...AND THE ROWS THAT ARE RESOLVED WITH NOBODY BEHIND THEM, which this check could not
        # see. It examines RESOLVED rows that ALREADY have an approver, so a RESOLVED row with a
        # BLANK one is invisible to it exactly when it matters most. Measured on prostate:
        # MAXINDEX and STUDY-WINDOW are RESOLVED with no approver and no date, and they set the
        # study window the build would execute — so this printed "NOTHING CHECKED ... there is
        # nothing here this check can hold" over two answered questions nobody is recorded as
        # having answered. That message was not cautious, it was false.
        #
        # `product_gates.unaccountable_resolutions` is the one implementation and already carries
        # the reasoning; it was reachable only from `contract_approval_errors`, so it fired only
        # once a pack CLAIMED `contract: approved`. The register is unsound now, whatever the
        # pack claims.
        #
        # A resolved row claiming an answer without valid attribution is a failed check,
        # even when the matching form and register contain the same invalid text.
        # Repairing the attribution remains a person's act; the checker invents nothing.
        from rwd_tools import product_gates as _pg                                       # noqa: PLC0415
        # BY DECISION, because that is the noun the sentence uses. One unattributed resolution
        # yields up to TWO findings - a missing approver and a missing date are separate repairs -
        # and counting the flat list reported twice as many unattributed DECISIONS as the register
        # holds. oc/202606 has exactly one and this said two.
        _by = _pg.unaccountable_resolutions(
            os.path.join(ROOT, pack) if not os.path.isabs(pack) else pack, pack,
            by_decision=True)
        _by = _by if isinstance(_by, dict) else {}       # a pack with no register yields a list (eleventh verdict: --check crashed)
        unaccountable = [m for ms in _by.values() for m in ms]
        bad += unaccountable
        if _by:
            print(f"{len(_by)} RESOLVED decision(s) with nobody recorded behind them "
                  f"({len(unaccountable)} finding(s)):", file=sys.stderr)
            for u in unaccountable:
                print(f"    ! {u}", file=sys.stderr)
            print(f"    These are answers nobody is recorded as having given, which is what this "
                  f"tool exists to end. Run `--forms`, have a named person fill answered_by and "
                  f"answer_date, then `--apply`.", file=sys.stderr)

        if not bad and not examined:
            print(f"NOTHING SIGNED — {pack} has no RESOLVED decision with a named approver, so no "
                  f"ruling was bound to a committed form. This does not say the register is "
                  f"sound; it says there is nothing here this check can hold"
                  + (f", and {len(_by)} resolution(s) above have nobody behind them."
                     if _by else "."))
            return 0
        print(f"OK — all {len(examined)} recorded ruling(s) match their forms; this does not authenticate approval" if not bad else
              f"{len(bad)} decision check finding(s); the register is not ready", file=sys.stderr if bad else sys.stdout)
        return 1 if bad else 0

    if a.forms:
        written, kept, note = write_forms(pack, root=ROOT)
        if note:
            sys.exit(note)
        for p in written:
            print(f"wrote    {repo_relative(p, ROOT)}")
        for p in kept:
            print(f"kept     {repo_relative(p, ROOT)}  (existing form, not overwritten)")
        if not written and not kept:
            print("no OPEN decisions — nothing to answer.")
        else:
            print(f"\nFill answer / answered_by / answer_date BY HAND, commit, then:\n"
                  f"  python3 platform/tools/decision_record.py {pack} --apply")
        return 0

    # blast radius BEFORE the write: these are the records each answer is about to unblock.
    blocking, _t, _i, _s = decision_report.blast_radius(os.path.join(ROOT, pack))
    forms = a.apply or None
    if not forms:
        # The bare wave discovers complete responses. Intact, unsealed OPEN drafts with
        # missing response fields remain drafts even when somebody has started typing.
        # Invalid provenance and every explicitly named form still fail closed.
        answered, untouched = partition_untouched(pack, root=ROOT)
        for did in untouched:
            print(f"not yet answered  {did}  (unfinished draft; preserved and skipped)")
        if untouched and not answered:
            print("nothing to record: every issued form is still an unfinished draft.")
            return 0
        forms = answered or None
    applied, skipped, errors, new_text = apply_forms(pack, forms, root=ROOT)
    for id_ in skipped:
        print(f"already recorded  {id_}")
    if errors:
        print(f"\nREFUSED — nothing was written. {len(errors)} defect(s):", file=sys.stderr)
        for e in errors:
            print(f"  {e}", file=sys.stderr)
        return 1
    if not applied and not skipped:
        print("nothing to record.")
        return 0
    # FORESEEABLE seal refusals fail the wave BEFORE the register writes — the register
    # write is atomic and the seal completes it, so nothing that can be known now may
    # be discovered after the rows have landed.
    pre = seal_preflight(pack, applied + skipped, root=ROOT)
    if pre:
        print(f"\nREFUSED — nothing was written. The seal would fail for "
              f"{len(pre)} answer(s):", file=sys.stderr)
        for p in pre:
            print(f"  {p}", file=sys.stderr)
        return 1
    if applied:
        _atomic_write(os.path.join(ROOT, pack, DECISIONS), new_text)
        print(f"\nrecorded {len(applied)} answer(s) into {pack}/{DECISIONS}:")
        for id_ in applied:
            print(f"  {id_}")
    # THE WAVE SEALS WHAT IT WRITES — and what an earlier wave wrote before auto-seal
    # existed (`skipped` covers the re-run). A retraction is skipped by name; a seal
    # failure is LOUD and exits nonzero with the register standing, because the row and
    # its form are real — the ledger just does not hold the act yet, and saying so is
    # the point.
    sealed, by_design, unsealed, report_error = complete_applied(pack, applied + skipped, root=ROOT)
    for id_, event in sealed:
        print(f"  sealed      {id_}  event {event['event_sha256'][:12]}")
    for id_, st in by_design:
        print(f"  not sealed  {id_}  ({st}: a retraction carries no signature by design)")
    if report_error:
        print(f"QUESTION REPORT NOT UPDATED — the register IS written: {report_error}", file=sys.stderr)
    if unsealed:
        print(f"\nSEAL REFUSED for {len(unsealed)} answer(s) — the register IS written and "
              f"the ledger does NOT yet hold these acts:", file=sys.stderr)
        for id_, why in unsealed:
            print(f"  {id_}: {why}", file=sys.stderr)
        print(f"  Fix the named defect, then re-run --apply (idempotent) or seal one:\n"
              f"  python3 platform/tools/decision_record.py {pack} --record-event <ID>",
              file=sys.stderr)
        return 1
    if report_error:
        return 1
    if not applied:
        print("nothing new to record; existing answers re-sealed above.")
        return 0
    worklist = {id_: blocking.get(id_, []) for id_ in applied if blocking.get(id_)}
    if worklist:
        print("\nTHE ANSWERS NOW HAVE TO BE WRITTEN IN. These records cite the settled decisions and "
              "still say decision_required —\ncontract_lint I11 names them until each is re-dispositioned:")
        for id_, vids in sorted(worklist.items(), key=lambda kv: -len(kv[1])):
            print(f"  {id_}  →  {len(vids)} record(s): {', '.join(sorted(vids))}")
        print(f"\n  python3 platform/tools/contract_lint.py {pack}")
    print("\nKeep the filled forms committed — they are the attestation the register row indexes.")
    # Unconditionally, because no matcher can pair FUED-DEFINITION with OC-FU-END-DEFINITION — the
    # judgment that two registers ask one question is a person's, made while the answer is fresh.
    print("If any settled question also exists on another pack, record the precedent now:\n"
          "  python3 platform/tools/precedents.py --add --key <entry> "
          f"--pack {pack} --decision <ID>")
    return 0




# ------------------------------------------------------- the approval-event ledger (side by side)

EQUIVALENCE_FIELDS = ("equivalence_outcome", "variable", "source_a", "source_b")
EQUIVALENCE_DEFINITION_FIELDS = ("definition_a", "definition_b")


def equivalence_definition_errors(eq, root=ROOT):
    """Why the analytical definitions an equivalence answer names cannot stand, or [] — the ONE
    rule for the answer form, the sealed event and the ruling that cites it (programme item 2).
    Two vendor names say WHERE a variable was measured; the definition ids say WHAT was compared.
    Optional until every product registers its definitions; when stated, both are stated, and
    each is registered in governance/DEFINITIONS.yaml."""
    d_a, d_b = (str(eq.get(k) or "").strip() for k in EQUIVALENCE_DEFINITION_FIELDS)
    if not (d_a or d_b):
        return []
    if not (d_a and d_b):
        return [f"names definition_{'a' if d_a else 'b'} but not the other — a comparison is "
                f"between two definitions; state both or neither"]
    from rwd_tools import definition_registry as _reg                                    # noqa: PLC0415
    entries, problems = _reg.read(root)
    if problems:
        return [f"names definitions and the register cannot be read — {problems[0]}"]
    ids = {str(e.get("definition_id")) for e in entries}
    unknown = [d for d in (d_a, d_b) if d not in ids]
    if unknown:
        return [f"definition {', '.join(unknown)} is not registered in governance/DEFINITIONS.yaml "
                f"— register the definition (definition_registry.py --propose) before ruling on it"]
    return []


def _now_utc():
    import datetime as _dt
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _now_recorded():
    """Keep the host's calendar date and offset used by the portal's Today action."""
    return _rfc3339(_now_utc()).astimezone().isoformat(timespec="seconds")


def form_path(root, pack, decision_id):
    return os.path.join(root, pack, "handoff", "decision_answers", f"{decision_id}.yaml")


def _rfc3339(s):
    """An RFC 3339 instant as an aware datetime, tolerant of Z and fractional seconds."""
    import datetime as _dt
    return _dt.datetime.fromisoformat(str(s).replace("Z", "+00:00"))


def _ledger_epoch(root):
    """The earliest `occurred_at` across every sealed event — the ledger's birth instant.

    None when no event exists yet: no adoption boundary has been established, so
    commitment alone cannot prove that an answer is a legacy import. Scans event files (the
    checkpoint holds heads, not births) — small trees, read once per seal wave."""
    from rwd_tools import event_ledger as el                                            # noqa: PLC0415
    import glob as _glob                                                 # noqa: PLC0415
    from rwd_tools import product_gates as _pg                                          # noqa: PLC0415
    earliest = None
    # `*.yaml`, THE LEDGER'S OWN SUFFIX (event_ledger writes NNNN-<uuid>.yaml). This globbed
    # *.json, found nothing, and every committed answer was sealed as a pre-ledger import
    # (eleventh verdict, second pass).
    for f in _glob.glob(os.path.join(root, el.EVENTS_DIR, "*", "*.yaml")):
        ev, err = _pg.read_yaml(f)
        if err or not isinstance(ev, dict):
            continue                     # an unreadable event cannot move the epoch
        at = str((ev or {}).get("occurred_at") or "")
        if at and (earliest is None or _rfc3339(at) < _rfc3339(earliest)):
            earliest = at
    return earliest


def event_payload(doc):
    """The COMPLETE decision content of one answered form, as the ledger seals it."""
    out = {k: str(doc.get(k) or "") for k in
           ("decision_id", "status", "answer", "answered_by", "answer_date",
            "superseded_by")}
    eq = doc.get("equivalence")
    out["equivalence"] = ({k: str(eq.get(k) or "") for k in
                           EQUIVALENCE_FIELDS + ("rationale",)}
                          if isinstance(eq, dict) else "")
    # WHICH DEFINITIONS were compared (programme item 2) — carried ONLY when the form states
    # them, so every decision sealed before the field existed keeps the digest it was sealed under
    if isinstance(eq, dict):
        for k in EQUIVALENCE_DEFINITION_FIELDS:
            if str(eq.get(k) or "").strip():
                out["equivalence"][k] = str(eq.get(k)).strip()
    # Omitted on legacy forms so their existing sealed payload remains byte-identical.
    if "answer_choice" in doc:
        from rwd_tools import decision_choice
        out["answer_choice"] = decision_choice.validated(doc)
    return out


def sealed_decision_event(root, doc):
    """Read a matching decision lifecycle event; attestations never replace its content.

    Uses the ledger's chain/checkpoint validator. This is integrity, not authentication.
    Unbound forms and invalid/terminal histories are never reported as completed.
    """
    from rwd_tools import event_ledger as el
    obj = str(doc.get("object_uuid") or "")
    if not obj:
        return None, None
    if not el.UUID4.fullmatch(obj):
        return None, "The decision object identifier is not a valid UUID; repair the saved form before completion."
    directory = os.path.abspath(os.path.join(root, el.EVENTS_DIR, obj))
    if os.path.normcase(os.path.realpath(directory)) != os.path.normcase(directory):
        return None, "The decision ledger location redirects elsewhere; repair it before completion."
    try:
        files = el._event_files(root, obj)
        if not files:
            return None, None
        checkpoints = el._checkpoints(root).get("heads", {})
        errors = el._check_object(root, obj, checkpoints.get(obj))
        if errors:
            return None, " ".join(errors)
        latest = None
        for _seq, filename in files:
            event, _error = el.read_event(root, obj, filename)
            if isinstance(event, dict) and event.get("action") != "attested":
                latest = event
        if latest and (latest.get("object_kind") != "decision" or latest.get("action") not in ("answered", "legacy_imported")):
            return None, "The decision history is " + str(latest.get("action")) + "; use its decision revision workflow instead of completing an old answer."
        subject = f"{doc.get('pack')}:{doc.get('decision_id')}:"
        if latest and not str(latest.get("idempotency_key") or "").startswith(subject):
            return None, "This ledger object belongs to a different product or decision; restore the form's own object identifier."
        if latest and latest.get("payload_sha256") == el.payload_digest(event_payload(doc)):
            return latest, None
        return None, "The saved answer differs from its recorded ledger content; review the decision revision before completion."
    except (el.LedgerError, OSError, ValueError, TypeError, KeyError) as error:
        return None, "The decision ledger could not be verified (" + type(error).__name__ + "). Repair it before completion."


def recorded_answer(pack, decision_id, root=ROOT):
    """Read a literal recorded choice for downstream tools, with legacy prose fallback.

    A structured value requires its matching form, current register and sealed
    decision event. This establishes integrity only, never signer authentication.
    """
    from pathlib import Path
    result = {"answer": "", "answer_choice": None, "choice_error": ""}
    if not re.fullmatch(r"(?:products|fixtures)/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/\d{6}", str(pack)) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,100}", str(decision_id)):
        return {**result, "choice_error": "Choose a valid product and decision identifier."}
    base = Path(root).resolve()
    paths = [base / pack / DECISIONS, Path(form_path(str(base), pack, decision_id))]
    try:
        for path in paths:
            if path.resolve() != path:
                raise ValueError("A decision input redirects outside its canonical location.")
            if path.exists() and path.stat().st_size > 2 * 1024 * 1024:
                raise ValueError("The decision input is too large to read safely.")
        text = paths[0].read_text(encoding="utf-8")
        rows, statuses = decision_rows(text), decision_status(text)
        row = rows.get(decision_id)
        if row is None or statuses.get(decision_id) != "RESOLVED":
            raise ValueError("This question has no current recorded answer.")
        result["answer"] = contract_lint.decision_answer(row)
        if not paths[1].exists():
            return result  # Older registers carry prose without structured forms.
        from rwd_tools import product_gates
        doc, why = product_gates.read_yaml(str(paths[1]))
        if why or not isinstance(doc, dict) or duplicate_keys(str(paths[1])):
            raise ValueError("The decision form is not an unambiguous mapping.")
        if "answer_choice" not in doc:
            return result
        errors = form_errors(doc, str(paths[1]), rows, statuses, expected_pack=pack, root=str(base))
        if errors:
            raise ValueError("The structured answer no longer matches its recorded question or answer.")
        event, why = sealed_decision_event(str(base), doc)
        if not event:
            raise ValueError(why or "The structured answer needs its decision evidence completion before downstream use.")
        from rwd_tools import decision_choice
        result["answer_choice"] = decision_choice.validated(doc)
        return result
    except (OSError, ValueError, TypeError, KeyError) as error:
        return {**result, "choice_error": str(error) if isinstance(error, ValueError) else "The structured decision could not be read safely."}


def record_event(root, pack, decision_id, now_utc):
    """Seal one RESOLVED answer form into the event ledger - the person's act, recorded.

    The actor is TRANSCRIBED from the form's own `answered_by` - never a flag - at typed
    trust, which every surface reports as an UNSIGNED assertion until signing keys exist.
    A retraction form (WITHDRAWN/SUPERSEDED) carries no signature by design and is not
    sealed here. Returns (event, None) or (None, why)."""
    import subprocess                                                    # noqa: PLC0415
    from rwd_tools import event_ledger as el                                            # noqa: PLC0415
    path = form_path(root, pack, decision_id)
    from rwd_tools import product_gates as _pg                                          # noqa: PLC0415
    doc, err = _pg.read_yaml(path)
    if err or not isinstance(doc, dict):
        return None, f"{pack}: no readable answer form for {decision_id} ({err})"
    if str(doc.get("status")) != "RESOLVED":
        return None, (f"{pack}: {decision_id} is {doc.get('status')!r} - only a RESOLVED "
                      f"answer seals here; a retraction carries no signature by design")
    register_path = os.path.join(root, pack, DECISIONS)
    if not os.path.isfile(register_path):
        return None, f"{pack}: no decision register; apply the reviewed answer before sealing"
    register_text = contract_lint.read(register_path)
    rows, statuses = decision_rows(register_text), decision_status(register_text)
    problems = form_errors(doc, path, rows, statuses, expected_pack=pack, root=root)
    if duplicate_keys(path):
        problems.append("the form repeats YAML keys; the recorded answer is ambiguous")
    if statuses.get(decision_id) != "RESOLVED":
        problems.append(f"the register is {statuses.get(decision_id, 'missing')}, not RESOLVED; "
                        "review and apply the answer to its register before sealing")
    instant = el._parse_rfc3339(now_utc)
    if instant is not None and not bad_date(doc.get("answer_date")):
        import datetime as _dt                                           # noqa: PLC0415
        if _rfc3339(now_utc).date() < _dt.date.fromisoformat(str(doc.get("answer_date"))):
            problems.append("the event timestamp predates answer_date; an answer cannot be recorded before it occurred")
    if problems:
        return None, f"{pack}: {decision_id} cannot be sealed:\n  - " + "\n  - ".join(problems)
    eq = doc.get("equivalence")
    if isinstance(eq, dict):
        from rwd_tools import semantic_view as sv                                       # noqa: PLC0415
        missing = [k for k in EQUIVALENCE_FIELDS if not str(eq.get(k) or "").strip()]
        if missing:
            return None, (f"{pack}: {decision_id}: the equivalence block leaves "
                          f"{', '.join(missing)} unstated - a structured outcome names "
                          f"the verdict, the variable and both sources")
        if eq.get("equivalence_outcome") not in sv.VOCAB:
            return None, (f"{pack}: {decision_id}: equivalence_outcome "
                          f"{eq.get('equivalence_outcome')!r} is not in the closed "
                          f"vocabulary {sv.VOCAB}")
        bad = equivalence_definition_errors(eq, root)
        if bad:
            return None, f"{pack}: {decision_id}: {bad[0]}"
    who = str(doc.get("answered_by") or "")
    if not who.strip():
        return None, f"{pack}: {decision_id}: answered_by is unstated"
    # A FORM THAT NO LONGER SAYS WHAT ITS REGISTER ROW SAYS IS SEALED BY NOTHING: `--check`
    # already calls that ruling unbound, and `--record-event` used to seal a fresh object over it
    # anyway, twice per run, leaving the ledger red (thirteenth pass, J7).
    drift = [e for e in check_bindings(pack, root) if e.startswith(f"{decision_id}:")]
    if drift:
        return None, (f"{pack}: {decision_id} is not recorded in the ledger — the form and the register disagree, "
                      f"and an attestation bound to nothing is not an act to record:\n  - " + "\n  - ".join(drift))
    obj = str(doc.get("object_uuid") or "") or None
    prev = ""
    if obj:
        existing, why = sealed_decision_event(root, doc)
        if why:
            return None, why
        if existing:
            return existing, None
        try:
            _seq, prev = el.head_of(root, obj)
        except el.LedgerError as e:
            return None, str(e)
    payload = event_payload(doc)
    action, trust = "answered", "typed"
    if not prev:
        # LEGACY IS "OLDER THAN THE LEDGER", NOT "COMMITTED" (external review, absorbed
        # 2026-08-28): the documented workflow commits the filled form BEFORE --apply, so
        # "any git history = legacy" relabelled every legitimate new answer as
        # legacy_imported/unauthenticated_legacy. The discriminator is the ledger's own
        # birth AND the committed answer content. An old blank form is not an old
        # answer; filling or changing it after adoption remains a typed answer.
        # An empty ledger has no epoch against which to establish legacy.
        rel_file = repo_relative(path, root)
        r = subprocess.run(["git", "-C", root, "log", "-1", "--format=%H %cI", "--",
                            rel_file], capture_output=True, text=True, encoding="utf-8")
        commit = r.stdout.strip().split(maxsplit=1) if r.returncode == 0 else []
        if len(commit) == 2:
            revision, committed_at = commit
            epoch = _ledger_epoch(root)
            if epoch is not None and _rfc3339(committed_at) < _rfc3339(epoch):
                prior = subprocess.run(["git", "-C", root, "show", f"{revision}:{rel_file}"],
                    capture_output=True, text=True, encoding="utf-8")
                try:
                    import yaml
                    committed = yaml.safe_load(prior.stdout) if prior.returncode == 0 else None
                except (yaml.YAMLError, ValueError):
                    committed = None
                if isinstance(committed, dict) and event_payload(committed) == payload:
                    action, trust = "legacy_imported", "unauthenticated_legacy"
    actor = {"subject_id": who, "identity_provider": "typed", "display_name": who,
             "role": "rwb", "trust_level": trust}
    if obj is None:
        # Reserve the identity in the applied form before append. If storage fails,
        # retry reuses this UUID; no event can be orphaned by a later form-write failure.
        import uuid
        obj = str(uuid.uuid4())
        with open(path, encoding="utf-8") as fh:
            text = fh.read()
        line = f"object_uuid: {obj}"
        if re.search(r"(?m)^object_uuid:.*$", text):
            text = re.sub(r"(?m)^object_uuid:.*$", line, text, count=1)
        else:
            text = text + ("" if text.endswith("\n") or not text else "\n") + line + "\n"
        _atomic_write(path, text)
    try:
        event = el.append_event(
            root, object_uuid=obj, object_kind="decision", action=action, actor=actor,
            occurred_at=now_utc, payload=payload, expected_previous_event_sha256=prev,
            idempotency_key=f"{pack}:{decision_id}:{action}:"
                            f"{el.payload_digest(payload)[:16]}")
    except el.LedgerError as e:
        return None, str(e)
    return event, None


def seal_preflight(pack, ids, root=ROOT):
    """[why] — every reason the coming seal would refuse, found BEFORE the register writes.

    The wave's atomicity contract (external review, absorbed 2026-08-28): the register is
    one atomic write, and sealing follows — so every FORESEEABLE seal refusal must fail
    the whole wave first, or a multi-answer wave could land its register half-sealed.
    The field-level checks (status, attribution, the equivalence vocabulary) are
    form_errors' and already ran; what remains is the ledger side — a readable form and
    a consistent chain behind any uuid the form already carries. What this cannot
    foresee (append-time IO, a form deleted mid-wave) stays on seal_applied's loud path.
    """
    from rwd_tools import product_gates as _pg                                          # noqa: PLC0415
    from rwd_tools import event_ledger as el                                            # noqa: PLC0415
    problems = []
    for did in ids:
        doc, err = _pg.read_yaml(form_path(root, pack, did))
        if err or not isinstance(doc, dict):
            problems.append(f"{did}: no readable answer form ({err})")
            continue
        if str(doc.get("status") or "") != "RESOLVED":
            continue                     # a retraction is never sealed, by design
        obj = str(doc.get("object_uuid") or "") or None
        if obj:
            _event, why = sealed_decision_event(root, doc)
            if why:
                problems.append(f"{did}: {why}")
    return problems


def seal_applied(pack, ids, root=ROOT, now_utc=None):
    """Seal every RESOLVED form the wave wrote (or re-wrote) — the wave's own closing act.

    Auto-seal (operator ruling 2026-08-28): --record-event as a SECOND command someone must
    remember is the trust gap the ledger closed, reopened by forgetfulness — Science answering
    through the app's composer never sees the second verb at all. Covers the wave's SKIPPED
    (already-recorded) ids too, so re-running --apply retro-seals answers applied before
    this existed. Idempotent through the ledger's own key: a re-seal matches the existing
    event, never appends a twin. A retraction is skipped BY NAME — it carries no signature
    by design. Returns (sealed [(id, event)], by_design [(id, status)], failures [(id, why)]).
    """
    from rwd_tools import product_gates as _pg                                          # noqa: PLC0415
    now = now_utc or _now_recorded()
    sealed, by_design, failures = [], [], []
    for did in ids:
        doc, err = _pg.read_yaml(form_path(root, pack, did))
        st = "" if err or not isinstance(doc, dict) else str(doc.get("status") or "")
        if st and st != "RESOLVED":
            by_design.append((did, st))
            continue
        try:
            event, why = record_event(root, pack, did, now)
        except (OSError, ValueError) as error:
            event, why = None, f"The decision was applied but its ledger completion failed ({type(error).__name__}). Retry completion after repairing the storage."
        if why:
            failures.append((did, why))
        else:
            sealed.append((did, event))
    return sealed, by_design, failures


def question_report_text(pack, root=ROOT):
    product = os.path.abspath(os.path.join(root, pack))
    return decision_report.render(product, *decision_report.blast_radius(product))


def refresh_questions(pack, root=ROOT):
    """Refresh the canonical ranked report without changing any scientific ruling."""
    path = os.path.abspath(os.path.join(root, pack, "handoff", "SCIENCE_QUESTIONS.md"))
    if os.path.normcase(os.path.realpath(path)) != os.path.normcase(path):
        raise ValueError("The question report redirects to another location; repair it before refreshing.")
    _atomic_write(path, question_report_text(pack, root))


def complete_applied(pack, ids, root=ROOT):
    """Shared CLI/portal completion. Applied records survive a reported completion failure.

    A typed ledger event records integrity; it does not authenticate the named decision maker.
    Retrying uses the existing idempotent sealing path and refreshes the ranked question list.
    """
    sealed, by_design, failures = seal_applied(pack, ids, root=root)
    report_error = None
    try:
        refresh_questions(pack, root)
    except (OSError, ValueError, UnicodeError) as error:
        report_error = str(error) if isinstance(error, ValueError) else "The ranked questions could not be written safely. Retry completion after repairing the storage."
    return sealed, by_design, failures, report_error


def claimed_objects(root):
    """{object_uuid: form rel path} for every answer form whose content VALIDATES against
    its chain head - schema-shaped, uuid-valid, payload digest equal to the newest sealed
    payload. A form that merely CARRIES a uuid claims nothing."""
    import glob as _glob                                                 # noqa: PLC0415
    from rwd_tools import event_ledger as el                                            # noqa: PLC0415
    out = {}
    for base in ("products", "fixtures"):
        for f in _glob.glob(os.path.join(root, base, "*", "*", "*", "handoff",
                                         "decision_answers", "*.yaml")):
            from rwd_tools import product_gates as _pg                                  # noqa: PLC0415
            doc, err = _pg.read_yaml(f)
            if err or not isinstance(doc, dict):
                continue                     # a malformed form claims nothing
            obj = str((doc or {}).get("object_uuid") or "")
            if not el.UUID4.match(obj):
                continue
            newest = None
            for _seq, fname in el._event_files(root, obj):
                ev, err = el.read_event(root, obj, fname)
                if not err and isinstance(ev, dict) and ev.get("action") != "attested":
                    newest = ev
            if newest is None:
                continue
            if str(newest.get("payload_sha256")) == el.payload_digest(event_payload(doc)):
                out[obj] = repo_relative(f, root)
    return out


# THE ENTRY POINT IS THE LAST STATEMENT (eleventh verdict): it sat above the ledger helpers, so every
# documented mutation — --apply, --record-event — raised NameError as a subprocess while the imported
# module the tests drove had every name. A script is executed top to bottom; main() may only run once
# everything it calls exists.
if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
