"""Versioned reviewed-variable payloads referenced by canonical contract bytes.

An immutable JSON object is content addressed. The contract's own approval hash
pins its reference, and every reader verifies the object hash and row binding.
No payload can claim approval; clinical/runtime validators still own execution.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re

VERSION = 1
FOLDER = "handoff/scientific_rules"
MAX_BYTES = 256 * 1024
REFERENCE = re.compile(r"\[Scientific rule v1\]\(scientific_rules/([a-f0-9]{64})\.json\)")
FIELDS = {"version", "pack", "item_id", "variable_id", "values", "clinical_rule", "family",
          "master_link", "field_choices", "value_interpretation"}


def encode(record):
    return json.dumps(record, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(record):
    return hashlib.sha256(encode(validate(record))).hexdigest()


def validate(record):
    if not isinstance(record, dict) or set(record) != FIELDS or type(record.get("version")) is not int or record["version"] != VERSION:
        raise ValueError("The scientific rule needs the complete version 1 reviewed-variable record.")
    if not isinstance(record["variable_id"], str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,79}", record["variable_id"]):
        raise ValueError("The scientific rule must name its variable identifier.")
    if not isinstance(record["pack"], str) or not record["pack"] or Path(record["pack"]).is_absolute() or ".." in Path(record["pack"]).parts or "\\" in record["pack"]:
        raise ValueError("The scientific rule must name one checkout-relative product.")
    if not isinstance(record["item_id"], str) or not re.fullmatch(r"[A-Za-z0-9_.-]+:[1-9][0-9]*", record["item_id"]):
        raise ValueError("The scientific rule must name its specification row.")
    for field in ("values", "clinical_rule", "family", "field_choices"):
        if not isinstance(record[field], dict):
            raise ValueError("Scientific rule " + field + " must be a mapping.")
    if record["values"].get("variable_id") != record["variable_id"]:
        raise ValueError("The scientific rule and its values name different variables.")
    for field in ("master_link", "value_interpretation"):
        if record[field] is not None and not isinstance(record[field], dict):
            raise ValueError("Scientific rule " + field + " must be recorded metadata or null.")
    def walk(value, depth=0):
        if depth > 20:
            raise ValueError("The scientific rule is nested too deeply.")
        if isinstance(value, dict):
            if len(value) > 1000 or any(not isinstance(key, str) for key in value):
                raise ValueError("Scientific rule mappings need bounded text keys.")
            for key, child in value.items():
                walk(key, depth + 1); walk(child, depth + 1)
        elif isinstance(value, list):
            if len(value) > 1000:
                raise ValueError("Scientific rule lists exceed the supported limit.")
            for child in value:
                walk(child, depth + 1)
        elif isinstance(value, str):
            if len(value) > 20000 or any(ord(c) < 32 and c not in "\n\r\t" for c in value):
                raise ValueError("Scientific rule text exceeds its limit or contains control characters.")
        elif value is not None and type(value) not in (bool, int, float):
            raise ValueError("Scientific rules must be finite JSON values.")
    walk(record)
    if len(encode(record)) > MAX_BYTES:
        raise ValueError("The scientific rule exceeds 256 KB.")
    return deepcopy(record)


def from_review(row, *, pack):
    values = deepcopy(row["values"])
    values["notes"] = strip_reference(values.get("notes") or "")
    return validate({"version": VERSION, "pack": pack, "item_id": row["item_id"],
        "variable_id": values["variable_id"], "values": values,
        "clinical_rule": deepcopy(row.get("clinical_rule") or {}), "family": deepcopy(row.get("family") or {}),
        "master_link": deepcopy(row.get("master_link")), "field_choices": deepcopy(row.get("field_choices") or {}),
        "value_interpretation": deepcopy(row.get("value_interpretation"))})


def strip_reference(notes):
    if not isinstance(notes, str):
        return notes
    return REFERENCE.sub("", notes).strip()


def referenced_digest(notes):
    if not isinstance(notes, str):
        return None
    found = REFERENCE.findall(notes)
    if len(found) > 1:
        raise ValueError("A contract row names more than one structured scientific rule.")
    if "[Scientific rule v1]" in notes and not found:
        raise ValueError("The structured scientific-rule reference is malformed.")
    return found[0] if found else None


def attach(notes, record):
    before = strip_reference(notes)
    return ((before + " ") if before else "") + f"[Scientific rule v1](scientific_rules/{digest(record)}.json)"


def same_values(left, right):
    from rwd_tools import contract_lint as cl
    def normalized(value):
        if isinstance(value, str) and value.strip().startswith(("{", "[")):
            import yaml
            try:
                parsed = yaml.safe_load(value)
                if isinstance(parsed, (dict, list)):
                    return normalized(parsed)
            except yaml.YAMLError:
                pass
        if isinstance(value, dict):
            return {str(key): normalized(child) for key, child in sorted(value.items(), key=lambda pair: str(pair[0]))}
        if isinstance(value, list):
            return [normalized(child) for child in value]
        return cl._unpipe(cl.pipe(cl.inline(value))).strip()
    def canonical(key, value):
        if key == "notes":
            value = strip_reference(value)
        return normalized(value)
    return set(left) == set(right) and all(canonical(key, left[key]) == canonical(key, right[key]) for key in left)


def verify_binding(record, values, *, pack=None, item_id=None):
    record = validate(record)
    if pack is not None and record["pack"] != pack or item_id is not None and record["item_id"] != item_id:
        raise ValueError("The scientific rule belongs to a different product or specification row.")
    if not same_values(record["values"], values):
        raise ValueError("The structured scientific rule and displayed definition differ. Update the variable review table and transfer its current complete rule again.")
    return record


def load(product, notes, *, values=None, item_id=None):
    pin = referenced_digest(notes)
    if pin is None:
        return None
    product = Path(product).absolute()
    path = product / FOLDER / (pin + ".json")
    if path.resolve() != path or product.resolve() != product:
        raise ValueError("The scientific rule redirects outside its canonical product location.")
    if not path.is_file() or path.stat().st_size > MAX_BYTES:
        raise ValueError("The referenced scientific rule is missing or exceeds its size limit.")
    raw = path.read_bytes()
    record = validate(json.loads(raw))
    suffix = tuple(Path(record["pack"]).parts)
    if tuple(product.parts[-len(suffix):]) != suffix:
        raise ValueError("The scientific rule belongs to a different product.")
    if encode(record) != raw or hashlib.sha256(raw).hexdigest() != pin:
        raise ValueError("The referenced scientific rule bytes differ from the contract's approved digest.")
    if item_id is not None and record["item_id"] != item_id:
        raise ValueError("The scientific rule names a different specification row.")
    if values is not None:
        verify_binding(record, values, item_id=item_id)
    return record


def contract_errors(product, blocks):
    from rwd_tools import contract_lint as cl
    errors = []
    for block in blocks:
        notes = cl._scalar(block, "notes") or ""
        try:
            record = load(product, notes)
            if record is not None:
                values = {key: cl._scalar(block, key) or "" for key in record["values"]}
                verify_binding(record, values)
                if record["item_id"] not in cl._list(block, "spec_refs"):
                    raise ValueError("The scientific rule is not bound to a cited specification row.")
        except (ValueError, TypeError, KeyError, OSError, RecursionError) as error:
            errors.append(f"[{cl._scalar(block, 'variable_id')}] structured scientific rule: {error}")
    return errors


def semantic_projection(record):
    """Export authored rules, not the original workbook words in evidence metadata."""
    record = validate(record)
    link = record.get("master_link") or {}
    ancestry, current = [], link
    while current:
        lineage = current.get("lineage") or {}
        origin = lineage.get("origin") or {}
        ancestry.append({"name": current.get("master_name", current.get("name")), "content_digest": current.get("content_digest"),
                         "version": current.get("declared_version"),
                         "origin": {key: origin[key] for key in ("pack", "item_id", "variable_id", "at") if key in origin}})
        current = lineage.get("parent") or {}
    deviations = []
    for field, baseline in (link.get("fields") or {}).items():
        product_value = record["values"]
        for part in field.split("."):
            product_value = product_value.get(part) if isinstance(product_value, dict) else None
        if product_value is not None and product_value != baseline:
            deviations.append({"field": field, "master": deepcopy(baseline), "product": deepcopy(product_value)})
    return {"version": VERSION, "rule_digest": digest(record), "variable_id": record["variable_id"],
            "clinical_rule": deepcopy(record["clinical_rule"]), "family": deepcopy(record["family"]),
            "master_digest": (record.get("master_link") or {}).get("content_digest"),
            "master_ancestry": ancestry, "deviations": deviations,
            "field_choices": deepcopy(record["field_choices"])}
