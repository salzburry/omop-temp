"""Optional master comparison and change history beside the simple value editor."""
import json
import hashlib

import streamlit as st

from experiments.portal import variable_review_lineage as lineage
from experiments.portal import variable_review_workflow as workflow


LABELS = {"derivation": "Meaning / rule", "output.type": "Data type", "source.kind": "Variable kind",
          "source.value": "Product value", "output.codes": "Categories", "window": "Time window",
          "record_selection": "Which record to use", "tie_break": "Multiple matches", "units": "Units",
          "value_interpretation": "Values and thresholds", "family": "Treatment-line choices"}


def _product_value(row, path):
    if path == "family":
        return row.get("family")
    if path == "typed_value":
        return (row.get("value_interpretation") or {}).get("value")
    return workflow._get(row.get("values") or {}, path)


def _master_text(reference):
    if not reference:
        return "Not recorded"
    return reference.get("name", reference.get("master_name", "")) + " · " + reference.get("digest", reference.get("content_digest", ""))[:12]


def _text(value):
    if value is None:
        return "Not set"
    return json.dumps(value, ensure_ascii=False) if isinstance(value, (dict, list)) else str(value)


def label(tracking):
    status = (tracking or {}).get("status", "untracked")
    if status == "deviates":
        count = tracking.get("change_count", 0)
        return f"{count} difference{'s' if count != 1 else ''} from master"
    return {"matches": "Matches master", "product_settings": "Master + product settings",
            "custom": "Custom definition", "invalid": "Check master history"}.get(status, "Master version not recorded")


def render(root, pack, actor_id, report, row, *, key, permitted, local_demo, allowed_packs=None):
    tracking = row.get("master_tracking") or lineage.compare(row.get("master_link"), row)
    reason = ""
    with st.expander("Master and changes · " + label(tracking)):
        link = row.get("master_link")
        if link:
            st.write("**Based on " + link["master_name"] + "**")
            st.caption("Recorded version: " + (link.get("declared_version") or link["content_digest"][:12]))
            if tracking.get("master_changed"):
                st.warning("The master has changed since this version was used. Your saved definition keeps its recorded baseline.")
                current = row.get("master")
                if current:
                    latest = lineage.capture(current)
                    st.dataframe([{"Field": LABELS.get(path, path), "Recorded master": _text(link["fields"].get(path)),
                                   "Current master": _text(latest["fields"].get(path))}
                                  for path in sorted(set(link["fields"]) | set(latest["fields"]))
                                  if link["fields"].get(path) != latest["fields"].get(path)], hide_index=True, width="stretch")
                    st.caption("Updating this baseline keeps your product answers and records a new comparison version.")
                    if st.button("Track against current master", key=key + "refresh_master", disabled=not permitted):
                        result = workflow.save_row(root, pack, actor_id, row["item_id"], "science", {},
                            expected_input_digest=report["input_digest"], expected_state_digest=report["state_digest"],
                            allowed_packs=allowed_packs, local_demo=local_demo, can_write=permitted,
                            refresh_master=True, change_reason="Explicitly updated the recorded master baseline; product answers retained.")
                        if result.get("ok"):
                            st.session_state.setdefault("flow_result", {}).pop(pack, None)
                            st.rerun()
                        for error in result.get("errors", []):
                            st.error(str(error))
            if tracking.get("chain"):
                st.write("**Definition history**")
                st.caption(" → ".join(item["master_name"] for item in tracking["chain"]) + " → this product")
                st.dataframe([{"Definition": item["master_name"], "Version": item["content_digest"][:12],
                               "Created from product": (item.get("origin") or {}).get("pack", "Master library"),
                               "Created by": (item.get("origin") or {}).get("actor_id", "Not recorded"),
                               "When": (item.get("origin") or {}).get("at", "Not recorded")}
                              for item in tracking["chain"]], hide_index=True, width="stretch")
                origins = [item for item in tracking["chain"] if item.get("origin") and item.get("product_snapshot")]
                if origins:
                    chosen_origin = st.selectbox("Inspect an originating variant", list(range(len(origins))),
                        index=len(origins) - 1, format_func=lambda index: origins[index]["master_name"] + " · " + origins[index]["origin"]["pack"], key=key + "origin")
                    ancestor = origins[chosen_origin]
                    ancestor_values = ancestor["product_snapshot"]
                    st.caption("Compare this product with the saved choices in that originating product.")
                    st.dataframe([{"Saved setting": LABELS.get(path, path), "Originating product": _text(value),
                                   "This product": _text(_product_value(row, path)),
                                   "Changed": "Yes" if value != _product_value(row, path) else ""}
                                  for path, value in ancestor_values.items() if path != "scientific_changes"], hide_index=True, width="stretch")
                    past_changes = ancestor_values.get("scientific_changes") or []
                    if past_changes:
                        st.write("**Changes recorded before this variant was shared**")
                        history_rows = [{"When": event["at"], "Who": event["actor_id"], "Reason": event.get("reason") or "Not supplied",
                            "Field": LABELS.get(change["path"], change["path"]), "Before": _text(change["before"]), "After": _text(change["after"])}
                            for event in past_changes for change in event.get("changes", [])]
                        history_rows.extend({"When": event["at"], "Who": event["actor_id"], "Reason": event.get("reason") or "Not supplied",
                            "Field": "Master version", "Before": _master_text(event.get("master_before")), "After": _master_text(event.get("master_after"))}
                            for event in past_changes if "master_after" in event)
                        st.dataframe(history_rows, hide_index=True, width="stretch")
            differences = tracking.get("deviations") or []
            if differences:
                st.write("**Differences from the recorded master**")
                st.dataframe([{"Field": LABELS.get(item["path"], item["path"]), "Master": _text(item["master"]),
                               "This product": _text(item["value"])} for item in differences], hide_index=True, width="stretch")
            else:
                st.caption("No differences from the fields declared by this master version.")
            if tracking.get("settings"):
                st.write("**Product settings**")
                st.caption("These answers were not fixed by the master; they are tracked with this product.")
                st.dataframe([{"Setting": LABELS.get(item["path"], item["path"]), "This product": _text(item["value"])}
                              for item in tracking["settings"]], hide_index=True, width="stretch")
            if st.button("Find products using this version", key=key + "usage"):
                from experiments.portal import variable_lineage_usage
                found = variable_lineage_usage.describe(root, pack, actor_id, item_id=row["item_id"], allowed_packs=allowed_packs)
                for error in found.get("errors", []):
                    st.error(str(error))
                for warning in found.get("warnings", []):
                    st.caption(str(warning))
                if found.get("rows"):
                    st.dataframe(found["rows"], hide_index=True, width="stretch")
                elif found.get("ok"):
                    st.info("No saved uses of this version were found in products you can access.")
        elif row.get("master_name"):
            st.info("This row has no recorded master-version snapshot yet. Its next scientific save records the current version; earlier differences cannot be reconstructed.")
        else:
            st.caption("This is a custom definition. Selecting a master links future comparisons to that version.")

        history = report.get("history") or []
        if report.get("history_archives"):
            st.caption("Recent changes are shown below. Older changes remain in the verified review archive.")
            cache_key = "variable_review_lineage_archive_" + hashlib.sha256(json.dumps(
                [str(root), pack, actor_id, allowed_packs, row["item_id"], report["state_digest"]], sort_keys=True).encode()).hexdigest()[:16]
            if st.button("Load all recorded changes for this variable", key=key + "history_load"):
                audit = workflow.read_history(root, pack, actor_id, allowed_packs=allowed_packs)
                if not audit.get("ok") or audit.get("state_digest") != report["state_digest"]:
                    st.error(" ".join(audit.get("errors") or ["The review changed. Reload the current variable before loading its history."]))
                else:
                    st.session_state[cache_key] = [event for event in audit["history"]
                        if event.get("item_id") == row["item_id"] or row["item_id"] in (event.get("changes_by_item") or {})]
            if cache_key in st.session_state:
                history = st.session_state[cache_key]
                st.caption("Showing all recorded changes for this variable, including archived events.")
        entries = []
        for saved in history:
            event = saved.get("change_event") if saved.get("item_id") == row["item_id"] else None
            event = event or (saved.get("changes_by_item") or {}).get(row["item_id"])
            if event:
                entries.append(event)
        if entries:
            chosen = st.selectbox("Saved change", list(range(len(entries) - 1, -1, -1)), key=key + "history",
                format_func=lambda index: f"{entries[index]['at']} · {entries[index]['actor_id']} · {entries[index].get('phase', 'science')}")
            event = entries[chosen]
            st.caption("Reason: " + (event.get("reason") or "Not supplied"))
            if event.get("master_before") != event.get("master_after"):
                st.caption("Master version: " + _master_text(event.get("master_before")) + " → " + _master_text(event.get("master_after")))
            if event.get("changes"):
                st.dataframe([{"Field": LABELS.get(item["path"], item["path"]), "Before": _text(item["before"]),
                               "After": _text(item["after"])} for item in event["changes"]], hide_index=True, width="stretch")
            else:
                st.caption("Recorded a master version or reconfirmed values; the product answers did not change.")
        elif any(entry.get("item_id") == row["item_id"] for entry in history):
            st.caption("Older entries recorded field names only. Detailed before-and-after tracking starts with the next save.")
        choices = ["", "Matches this product's specification", "Scientific review decision", "Source data constraint", "Correction", "Other"]
        picked = st.selectbox("Reason for this change (optional)", choices, key=key + "reason",
            format_func=lambda item: item or "Choose a reason", disabled=not permitted)
        reason = st.text_input("Your reason", key=key + "reason_text", max_chars=2000, disabled=not permitted) if picked == "Other" else picked
    return reason
