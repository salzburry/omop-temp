"""The portal's visual identity: one palette, one type pair, and the HTML fragments the page
renders through them. Pure functions and constants — no Streamlit import — so the escaping and
the status vocabulary are tested without a browser (platform/tests/test_portal_theme.py).

WHY A MODULE. Streamlit's defaults read as a stock dashboard, and the operator said so
(2026-09-03). The identity lives in two places: `.streamlit/config.toml` (the theme Streamlit
applies to its own widgets) and the CSS here (the sidebar as a navigation rail, the type pair, the
metric cards, the gate pills). Semantic colours for gate status are separate from the accent, so
the accent never has to mean "good": complete, in progress, not started and blocked each carry
their own colour and their own word — never colour alone.
"""
from __future__ import annotations

import html
import uuid

# GSK WHITE AND ORANGE (operator, 2026-09-03). The brand orange is the ONE accent — the active
# section, links, focus — on a white ground with dark-grey ink. Gate status keeps its own semantic
# colours, and amber is kept visibly distinct from the brand orange so "in progress" never reads
# as a highlight: every pill also carries its word.
PALETTE = {
    "ground": "#FFFFFF",        # the page
    "surface": "#FFFFFF",       # cards, tables, messages
    "ink": "#2B2B2B",           # text (GSK dark grey)
    "muted": "#6B6B6B",         # captions, labels
    "line": "#E5E5E5",          # hairlines
    "rail": "#FFFFFF",          # the sidebar — white, with an orange edge
    "rail_ink": "#2B2B2B",      # sidebar text
    "rail_muted": "#6B6B6B",    # sidebar captions
    "rail_hover": "#FFF1EA",    # a section under the pointer: a pale orange wash
    "rail_line": "#E5E5E5",     # sidebar hairlines and control borders
    "rail_field": "#FAFAFA",    # sidebar select background
    "accent": "#F36633",        # GSK orange
    "accent_ink": "#202020",    # dark text on brand orange meets normal-text contrast
    "accent_text": "#AC350F",   # accessible orange for text on white/light fields
    "status_ink": "#FFFFFF",   # statuses use darker backgrounds than the brand accent
    "focus": "#135CB0",         # visible keyboard ring on white and light fields
    "control_line": "#767676", # active input boundaries, separate from decorative hairlines
    "complete": "#176B43",
    "in_progress": "#826007",   # amber, deliberately darker than the brand orange
    "not_started": "#626D78",
    "blocked": "#B3261E",
}


def streamlit_arguments() -> tuple[str, ...]:
    """Native widgets must match this palette even in a data-only workspace."""
    values = {
        "theme.base": "light",
        "theme.primaryColor": PALETTE["accent"],
        "theme.backgroundColor": PALETTE["ground"],
        "theme.secondaryBackgroundColor": PALETTE["surface"],
        "theme.textColor": PALETTE["ink"],
        "theme.font": "sans serif",
        "client.toolbarMode": "viewer",
    }
    return tuple(f"--{key}={value}" for key, value in values.items())


STATUS_STYLE = {                # gate status -> (colour key, label shown); status.py's own words included
    "complete": ("complete", "complete"),
    "done": ("complete", "done"),
    "in progress": ("in_progress", "in progress"),
    "approved, awaiting promotion": ("in_progress", "approved, awaiting promotion"),
    "awaiting a named approval": ("in_progress", "awaiting a named approval"),
    "not started": ("not_started", "not started"),
    "blocked": ("blocked", "blocked"),
    "cannot complete": ("blocked", "cannot complete"),
}

FONTS_URL = ("https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600"
             "&family=IBM+Plex+Mono:wght@400;500&display=swap")


TOP_CLEARANCE = ".block-container{padding-top:3.5rem !important;}"

FOCUS_TARGETS = frozenset({"rwd-variable-editor", "rwd-variable-feedback",
                           "rwd-definition-editor", "rwd-definition-section", "rwd-definition-feedback"})
FOCUS_REQUEST = "_rwd_explicit_focus_request"


def queue_focus(state, anchor):
    """Request focus only from an explicit navigation or validation action."""
    if anchor not in FOCUS_TARGETS:
        raise ValueError("Choose a registered researcher editing destination.")
    state[FOCUS_REQUEST] = {"anchor": anchor, "token": uuid.uuid4().hex}


def take_focus_markup(state, anchor):
    """Consume transient UI intent; never restore focus from an authoring draft."""
    request = state.get(FOCUS_REQUEST)
    if not isinstance(request, dict) or request.get("anchor") != anchor:
        return ""
    state.pop(FOCUS_REQUEST, None)
    token = request.get("token", "")
    if anchor not in FOCUS_TARGETS or not isinstance(token, str) or len(token) != 32 or any(c not in "0123456789abcdef" for c in token):
        return ""
    return f'<span hidden data-rwd-focus-target="{html.escape(anchor, quote=True)}" data-rwd-focus-token="{token}"></span>'

# Trusted, fixed application markup only. No profile, workbook, chat or other
# user-provided text is interpolated into executable JavaScript.
SIDEBAR_ACCESSIBILITY = r"""<script>
(() => {
  const key = '__rwdSidebarAccessibility';
  const previous = window[key];
  const navigation = previous?.navigation || {initialStateHandled: false};
  const states = previous ? previous.states : new WeakMap();
  const dateStates = previous?.dateStates || new WeakMap();
  const focused = previous?.focused || new Set();
  if (previous) previous.stop();
  const root = document.querySelector('[data-testid="stApp"]') || document.body;
  let frame = 0;
  let stopped = false;
  const set = (node, name, value) => {
    if (node.getAttribute(name) !== value) node.setAttribute(name, value);
  };
  const apply = () => {
    const main = document.querySelector('[data-testid="stMain"], [data-testid="stAppScrollToBottomContainer"]');
    if (main) set(main, 'role', 'main');
    const assistant = document.querySelector('.st-key-rwd_assistant_rail');
    const assistantColumn = assistant?.closest('[data-testid="stColumn"]');
    if (assistantColumn) {
      set(assistantColumn, 'role', 'complementary');
      set(assistantColumn, 'aria-label', 'Product assistant');
      // The desktop rail scrolls independently. Make its scroll container
      // reachable by keyboard without changing its children's tab order.
      set(assistantColumn, 'tabindex', '0');
    }
    document.querySelectorAll('[data-rwd-focus-target][data-rwd-focus-token]').forEach(marker => {
      const name = marker.dataset.rwdFocusTarget;
      const token = marker.dataset.rwdFocusToken;
      if (!['rwd-variable-editor', 'rwd-variable-feedback', 'rwd-definition-editor',
            'rwd-definition-section', 'rwd-definition-feedback'].includes(name)
          || !/^[0-9a-f]{32}$/.test(token) || focused.has(token)) return;
      const target = document.getElementById(name);
      if (!target || !target.matches('h2,h3,h4') || !target.getClientRects().length
          || target.closest('[inert], [aria-hidden="true"]')) return;
      focused.add(token);
      if (focused.size > 64) focused.delete(focused.values().next().value);
      set(target, 'tabindex', '-1');
      target.focus({preventScroll: false});
    });
    document.querySelectorAll('[data-testid="stMultiSelectTagsContainer"] span[data-tag][aria-label]:not([role])').forEach(tag => {
      const label = tag.querySelector(':scope > span');
      const remove = tag.querySelector(':scope > button[aria-label]');
      if (label && label.textContent.trim() && remove) set(tag, 'role', 'group');
    });
    document.querySelectorAll('[data-testid="stDateInputField"]').forEach(field => {
      const group = field.querySelector('[role="group"][id]');
      if (!group || !group.querySelector('[role="spinbutton"]')) return;
      const nativeState = field.getAttribute('aria-expanded');
      if (nativeState === 'true' || nativeState === 'false') dateStates.set(field, nativeState);
      const expanded = dateStates.get(field);
      if (expanded !== 'true' && expanded !== 'false') return;
      const id = 'rwd-calendar-state-' + group.id;
      let status = document.getElementById(id);
      if (!status) {
        status = document.createElement('span');
        status.id = id;
        status.className = 'rwd-visually-hidden';
        set(status, 'role', 'status');
        field.append(status);
      }
      const text = expanded === 'true' ? 'Calendar open. Press Escape to close.'
        : 'Calendar closed. Press Alt+ArrowDown to open the calendar.';
      if (status.textContent !== text) status.textContent = text;
      const descriptions = (group.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean);
      if (!descriptions.includes(id)) set(group, 'aria-describedby', [...descriptions, id].join(' '));
      set(group, 'aria-keyshortcuts', 'Alt+ArrowDown');
      set(group, 'aria-haspopup', 'dialog');
      field.removeAttribute('aria-expanded');
    });
    document.querySelectorAll('[role="dialog"]').forEach(dialog => {
      if (!dialog.querySelector('[role="grid"]')) return;
      dialog.querySelectorAll('header:not([role])').forEach(header => set(header, 'role', 'presentation'));
    });
    document.querySelectorAll('[data-testid="stCode"] pre').forEach(code => {
      if (code.scrollWidth > code.clientWidth + 1 || code.scrollHeight > code.clientHeight + 1) {
        if (!code.hasAttribute('tabindex')) set(code, 'tabindex', '0');
      }
    });
    const sidebar = document.querySelector('[data-testid="stSidebar"]');
    if (!sidebar) return;
    const nativeState = sidebar.getAttribute('aria-expanded');
    if (nativeState === 'true' || nativeState === 'false') states.set(sidebar, nativeState);
    let expanded = states.get(sidebar) || 'false';
    set(sidebar, 'id', 'rwd-product-navigation');
    set(sidebar, 'role', 'complementary');
    set(sidebar, 'aria-label', 'Product navigation');
    // On a phone the navigation rail should not cover the first form field on
    // load.  Keep the desktop/tablet rail available; the person can reopen
    // it with the native Show navigation control when needed.
    if (!navigation.initialStateHandled && (nativeState === 'true' || nativeState === 'false')) {
      // Consume this before clicking: the resulting DOM mutation must not
      // collapse the rail again when the person deliberately reopens it.
      navigation.initialStateHandled = true;
      if (window.matchMedia && window.matchMedia('(max-width: 720px)').matches && expanded === 'true') {
        const collapse = document.querySelector('[data-testid="stSidebarCollapseButton"] button, '
          + 'button[data-testid="stSidebarCollapseButton"], [data-testid="stSidebarCollapseButton"]');
        if (collapse) {
          collapse.click();
          expanded = 'false';
          states.set(sidebar, expanded);
        }
      }
    }
    const hidden = expanded !== 'true';
    if (sidebar.inert !== hidden) sidebar.inert = hidden;
    set(sidebar, 'aria-hidden', String(hidden));
    sidebar.removeAttribute('aria-expanded');
    const selectors = '[data-testid="stSidebarCollapseButton"] button, '
      + 'button[data-testid="stSidebarCollapseButton"], '
      + '[data-testid="stSidebarCollapsedControl"] button, '
      + '[data-testid="stExpandSidebarButton"] button, '
      + 'button[data-testid="stExpandSidebarButton"]';
    document.querySelectorAll(selectors).forEach(button => {
      set(button, 'aria-controls', 'rwd-product-navigation');
      set(button, 'aria-expanded', expanded);
      set(button, 'aria-label', expanded === 'true' ? 'Hide navigation' : 'Show navigation');
    });
  };
  const options = {subtree: true, childList: true, attributes: true, attributeFilter: ['aria-expanded']};
  const observer = new MutationObserver(() => {
    if (stopped || frame) return;
    frame = requestAnimationFrame(() => {
      frame = 0;
      observer.disconnect();
      apply();
      if (!stopped && root.isConnected) observer.observe(root, options);
    });
  });
  const stop = () => {
    stopped = true;
    observer.disconnect();
    if (frame) cancelAnimationFrame(frame);
    window.removeEventListener('pagehide', stop);
  };
  apply();
  observer.observe(root, options);
  window.addEventListener('pagehide', stop, {once: true});
  window[key] = {states, dateStates, focused, navigation, stop};
})();
</script>"""


def css() -> str:
    """The style block injected once per page. Every colour comes from PALETTE; the two faces
    fall back to the system stack when the font host is unreachable (an offline GSK laptop).
    Emitted WITHOUT blank lines: Streamlit's markdown renderer ends an HTML block at a blank
    line, and everything after the first one inside <style> was printed on the page as text."""
    return "\n".join(l for l in _css_source().splitlines() if l.strip()).replace("</style>", TOP_CLEARANCE + "</style>", 1)


def _css_source() -> str:
    p = PALETTE
    return f"""
<link rel="stylesheet" href="{FONTS_URL}">
<style>
:root {{ --rwdp-ground:{p['ground']}; --rwdp-surface:{p['surface']}; --rwdp-ink:{p['ink']};
        --rwdp-muted:{p['muted']}; --rwdp-line:{p['line']}; --rwdp-rail:{p['rail']};
        --rwdp-rail-ink:{p['rail_ink']}; --rwdp-rail-muted:{p['rail_muted']};
        --rwdp-rail-hover:{p['rail_hover']}; --rwdp-rail-line:{p['rail_line']};
        --rwdp-rail-field:{p['rail_field']}; --rwdp-accent:{p['accent']};
        --rwdp-accent-ink:{p['accent_ink']}; --rwdp-accent-text:{p['accent_text']};
        --rwdp-status-ink:{p['status_ink']}; --rwdp-focus:{p['focus']};
        --rwdp-control-line:{p['control_line']}; }}
html, body, [data-testid="stAppViewContainer"], .stMarkdown, .stCaption, button, input, textarea {{
  font-family: "IBM Plex Sans", "Segoe UI", system-ui, -apple-system, sans-serif; }}
code, pre, .stCode, [data-testid="stCode"] {{ font-family: "IBM Plex Mono", Consolas, "Courier New", monospace; }}
h1, h2, h3 {{ font-weight: 600; letter-spacing: -0.01em; text-wrap: balance; color: var(--rwdp-ink); }}
.rwdp-sr-only {{ position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px;
  overflow: hidden; clip: rect(0, 0, 0, 0); white-space: nowrap; border: 0; }}
[data-testid="stAppViewContainer"] :is(input, textarea, select, button, summary, [tabindex]) {{
  scroll-margin-block: 5rem 2rem;
}}
@media (prefers-reduced-motion: reduce) {{
  [data-testid="stAppViewContainer"] *, [data-testid="stSidebar"] * {{
    scroll-behavior: auto !important; animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important; transition-duration: 0.01ms !important;
  }}
}}
.block-container {{ padding-top: 1.4rem; padding-bottom: 5rem; max-width: 1180px; }}
/* The assistant stays in a visible right rail beside the working task.  The
   outer column stretches to the form and the inner dock owns the sticky
   position; a sticky element cannot outlive a short parent column. */
.st-key-rwd_assistant_rail {{ min-width: 0; position: relative; height: 100%; }}
.st-key-rwd_assistant_dock {{ min-width: 0; width: 100%; position: sticky; top: 1.25rem; }}
.st-key-rwd_assistant_dock [data-testid="stChatMessage"] {{ padding: 0.65rem; }}
.st-key-rwd_assistant_dock [data-testid="stChatMessage"] p {{ overflow-wrap: anywhere; }}
/* The shell owns one outer column row.  Scope these rules to that row so
   nested form columns keep their natural widths instead of inheriting the
   assistant rail width and becoming squeezed on another screen. */
.st-key-rwd_workspace_columns > [data-testid="stHorizontalBlock"],
.st-key-rwd_workspace_columns > div > [data-testid="stHorizontalBlock"] {{
  flex-direction: row !important; flex-wrap: nowrap !important; align-items: flex-start !important;
  gap: 1.5rem !important;
}}
.st-key-rwd_workspace_columns > [data-testid="stHorizontalBlock"] > [data-testid="stColumn"],
.st-key-rwd_workspace_columns > div > [data-testid="stHorizontalBlock"] > [data-testid="stColumn"] {{
  min-width: 0 !important;
}}
.st-key-rwd_workspace_columns > [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:first-child,
.st-key-rwd_workspace_columns > div > [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:first-child {{
  flex: 1 1 auto !important; width: auto !important;
}}
.st-key-rwd_workspace_columns > [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:last-child,
.st-key-rwd_workspace_columns > div > [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:last-child {{
  flex: 0 0 clamp(240px, 25vw, 310px) !important;
  width: clamp(240px, 25vw, 310px) !important; align-self: stretch !important;
}}
@media (min-width: 1101px) {{
  /* Streamlit's column wrapper is shorter than a long form, so sticky stops
     when the wrapper ends. Pin the assistant to the viewport while reserving
     its width in the working row. */
  .st-key-rwd_workspace_columns > [data-testid="stHorizontalBlock"],
  .st-key-rwd_workspace_columns > div > [data-testid="stHorizontalBlock"] {{
    padding-right: clamp(240px, 25vw, 310px) !important;
  }}
  .st-key-rwd_workspace_columns > [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:last-child,
  .st-key-rwd_workspace_columns > div > [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:last-child {{
    /* Leave the Streamlit header and its status controls unobscured. */
    position: fixed !important; right: 1.25rem !important; top: 4.5rem !important;
    width: clamp(220px, 25vw, 310px) !important; max-width: clamp(220px, 25vw, 310px) !important;
    max-height: calc(100vh - 5.75rem) !important; overflow-y: auto !important;
    z-index: 1000 !important; background: var(--rwdp-surface) !important;
    border: 1px solid var(--rwdp-line); border-radius: 0.6rem;
    box-shadow: 0 8px 28px rgb(0 0 0 / 12%); padding: 0.25rem !important;
  }}
  .st-key-rwd_assistant_rail, .st-key-rwd_assistant_dock {{ position: static; height: auto; }}
}}
@media (max-width: 1100px) {{
  /* With navigation open, tablets and small windows need the whole task width.
     Keep the conversation open after the form without covering its controls. */
  .st-key-rwd_workspace_columns > [data-testid="stHorizontalBlock"],
  .st-key-rwd_workspace_columns > div > [data-testid="stHorizontalBlock"] {{
    display: block !important; overflow: visible !important; padding-right: 0 !important;
  }}
  .st-key-rwd_workspace_columns > [data-testid="stHorizontalBlock"] > [data-testid="stColumn"],
  .st-key-rwd_workspace_columns > div > [data-testid="stHorizontalBlock"] > [data-testid="stColumn"] {{
    width: 100% !important; max-width: 100% !important; flex: none !important;
  }}
  .st-key-rwd_workspace_columns > [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:last-child,
  .st-key-rwd_workspace_columns > div > [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:last-child {{
    position: static !important; margin-top: 1.25rem !important; width: 100% !important;
    max-width: 100% !important; max-height: none !important; overflow: visible !important;
    z-index: auto !important; padding: 0 !important; background: transparent !important;
    border: 0 !important; border-radius: 0; box-shadow: none;
  }}
  .st-key-rwd_assistant_rail, .st-key-rwd_assistant_dock {{ position: static; height: auto; }}
}}
[data-testid="stCaptionContainer"] {{ opacity: 1 !important; color: var(--rwdp-muted); }}
[data-testid="stCaptionContainer"] p {{ color: var(--rwdp-muted); }}
[data-testid="stSidebar"] [data-testid="stCaptionContainer"] {{ opacity: 1 !important; color: var(--rwdp-rail-muted); }}

/* the sidebar is a navigation rail */
[data-testid="stSidebar"] {{ background: var(--rwdp-rail); border-right: 4px solid var(--rwdp-accent); }}
[data-testid="stSidebar"] * {{ color: var(--rwdp-rail-ink); }}
[data-testid="stSidebar"] h1 {{ font-size: 1.1rem; letter-spacing: 0.08em; text-transform: uppercase;
                               color: var(--rwdp-accent-text); margin-bottom: 0.2rem; }}
[data-testid="stSidebar"] [data-testid="stCaptionContainer"] p {{ color: var(--rwdp-rail-muted); font-size: 0.78rem; }}
[data-testid="stSidebar"] [role="radiogroup"] label {{ padding: 0.35rem 0.6rem; border-radius: 6px;
                               margin: 1px 0; display: flex; }}
[data-testid="stSidebar"] [role="radiogroup"] label:hover {{ background: var(--rwdp-rail-hover); }}
[data-testid="stSidebar"] [role="radiogroup"] label[data-checked="true"],
[data-testid="stSidebar"] [role="radiogroup"] label:has(input:checked) {{ background: var(--rwdp-accent); }}
[data-testid="stSidebar"] [role="radiogroup"] label[data-checked="true"] *,
[data-testid="stSidebar"] [role="radiogroup"] label:has(input:checked) * {{ color: var(--rwdp-accent-ink) !important; }}
[data-testid="stSidebar"] [data-baseweb="select"] > div {{ background: var(--rwdp-rail-field); border-color: var(--rwdp-control-line); }}
[data-testid="stSidebar"] [data-baseweb="select"] div, [data-testid="stSidebar"] [data-baseweb="select"] span,
[data-testid="stSidebar"] [data-baseweb="select"] svg {{ color: var(--rwdp-rail-ink) !important; fill: var(--rwdp-rail-ink); }}
[data-testid="stSidebar"] [data-baseweb="popover"] li {{ color: var(--rwdp-ink) !important; }}
[data-testid="stSidebar"] hr {{ border-color: var(--rwdp-rail-line); }}
a, [data-testid="stMarkdown"] a {{ color: var(--rwdp-accent-text); text-decoration: underline; text-underline-offset: 0.15em; }}
[data-testid="stBaseButton-primary"]:not(:disabled), button[kind="primary"]:not(:disabled) {{
  background-color: var(--rwdp-accent); color: var(--rwdp-accent-ink) !important;
}}
[data-testid="stBaseButton-primary"] *, button[kind="primary"] * {{ color: inherit; }}
[data-testid="stMultiSelectTagsContainer"] [data-tag] {{
  background-color: var(--rwdp-accent); color: var(--rwdp-accent-ink);
}}
[data-testid="stMultiSelectTagsContainer"] [data-tag] > span,
[data-testid="stMultiSelectTagsContainer"] [data-tag] > button {{
  color: var(--rwdp-accent-ink);
}}
[data-testid="stChatInput"] {{ border-color: var(--rwdp-accent); }}
/* Keep native focusable controls. A two-colour ring remains visible against
   both the white form and filled navigation/buttons; do not rely on border colour. */
#rwd-variable-editor, #rwd-variable-feedback, #rwd-definition-editor,
#rwd-definition-section, #rwd-definition-feedback {{ scroll-margin-top: 6rem; }}
.rwd-visually-hidden {{ position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px;
  overflow: hidden; clip-path: inset(50%); white-space: nowrap; border: 0; }}
[data-testid="stAlertContentSuccess"], [data-testid="stAlertContentSuccess"] p {{ color: {p['complete']} !important; }}
[data-testid="stAppViewContainer"] :is(a, button, input, textarea, select, summary,
  [role="button"], [role="combobox"], [role="checkbox"], [role="radio"], [tabindex]):focus-visible,
[data-testid="stAppViewContainer"] :is([data-testid="stTextInput"], [data-testid="stTextArea"],
  [data-testid="stNumberInput"], [data-testid="stSelectbox"], [data-testid="stMultiSelect"],
  [data-testid="stChatInput"]):has(:focus-visible),
[data-testid="stAppViewContainer"] label:has(input:focus-visible),
[role="dialog"] :is(button, input, [role="button"], [tabindex]):focus-visible,
[data-testid="stSidebar"] label:has(input:focus-visible) {{
  outline: 3px solid var(--rwdp-focus) !important; outline-offset: 3px !important;
  box-shadow: 0 0 0 3px var(--rwdp-ground) !important;
}}
@media (forced-colors: active) {{
  :root {{ --rwdp-focus: Highlight; --rwdp-ground: Canvas; }}
  [data-testid="stAppViewContainer"] :focus-visible,
  [data-testid="stSidebar"] label:has(input:focus-visible) {{ outline: 3px solid Highlight !important; }}
}}

/* header strip and metric cards */
.rwdp-strip {{ display: flex; align-items: baseline; gap: 0.8rem; margin-bottom: 0.6rem; }}
.rwdp-strip .pack {{ font-family: "IBM Plex Mono", Consolas, monospace; font-size: 0.95rem;
                     color: var(--rwdp-muted); }}
.rwdp-strip .role {{ font-size: 0.78rem; color: var(--rwdp-muted); text-transform: uppercase;
                     letter-spacing: 0.06em; }}
[data-testid="stMetric"] {{ background: var(--rwdp-surface); border: 1px solid var(--rwdp-line);
                            border-radius: 10px; padding: 0.7rem 0.9rem; }}
[data-testid="stMetricLabel"] p {{ color: var(--rwdp-muted); font-size: 0.78rem; text-transform: uppercase;
                                   letter-spacing: 0.06em; }}
[data-testid="stMetricValue"] {{ font-variant-numeric: tabular-nums; color: var(--rwdp-ink); }}

/* gate pills and table */
.rwdp-pill {{ display: inline-block; padding: 0.12rem 0.55rem; border-radius: 999px; font-size: 0.78rem;
              font-weight: 500; color: var(--rwdp-status-ink); white-space: nowrap; }}
.rwdp-gates {{ width: 100%; border-collapse: collapse; background: var(--rwdp-surface);
               border: 1px solid var(--rwdp-line); border-radius: 10px; overflow: hidden; }}
.rwdp-gates th {{ text-align: left; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.06em;
                  color: var(--rwdp-muted); padding: 0.55rem 0.8rem; border-bottom: 1px solid var(--rwdp-line); }}
.rwdp-gates td {{ padding: 0.5rem 0.8rem; border-bottom: 1px solid var(--rwdp-line); font-size: 0.9rem;
                  vertical-align: middle; }}
.rwdp-gates tr:last-child td {{ border-bottom: none; }}
.rwdp-gates td.n {{ font-family: "IBM Plex Mono", Consolas, monospace; color: var(--rwdp-muted); width: 3rem; }}
.rwdp-gates tbody th {{ text-transform: none; letter-spacing: normal; font-size: 0.9rem;
  font-weight: 500; color: var(--rwdp-ink); }}
.rwdp-gates td.b {{ font-variant-numeric: tabular-nums; text-align: right; width: 5rem; }}

/* chat */
[data-testid="stChatMessage"] {{ background: var(--rwdp-surface); border: 1px solid var(--rwdp-line);
                                 border-radius: 12px; padding: 0.6rem 0.9rem; }}
[data-testid="stChatInput"] textarea {{ font-family: "IBM Plex Sans", system-ui, sans-serif; }}
[data-testid="stStatusWidget"], [data-testid="stExpander"] {{ border-radius: 10px; }}
.rwdp-strip .badge {{ background: {p['blocked']}; color: #fff; font: 600 11px/1 "IBM Plex Mono", monospace; letter-spacing: .04em; padding: 5px 8px; border-radius: 4px; margin-left: 10px; }}
.rwdp-watermark {{ background: {p['in_progress']}; color: #fff; font: 600 12px/1.4 "IBM Plex Sans", sans-serif; padding: 6px 12px; border-radius: 6px; margin: 0 0 8px 0; }}
.rwdp-stepper {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(110px, 1fr)); gap: 8px; margin: 8px 0 16px 0; }}
.rwdp-stepper .step {{ border-top: 4px solid {p['line']}; padding: 6px 4px 2px 4px; }}
.rwdp-stepper .step-name {{ font: 600 12px/1.3 "IBM Plex Sans", sans-serif; color: {p['ink']}; }}
.rwdp-stepper .step-state {{ font: 500 11px/1.3 "IBM Plex Mono", monospace; }}
.rwdp-stepper .step-why {{ font: 400 11px/1.3 "IBM Plex Sans", sans-serif; color: {p['muted']}; }}
[data-testid="stRadio"] [role="radiogroup"] {{ gap: 0.3rem 0.8rem; flex-wrap: wrap; }}
[data-testid="stVerticalBlockBorderWrapper"] > div {{ border-radius: 12px; }}
[data-testid="stButton"] button, [data-testid="stDownloadButton"] button {{ border-radius: 8px; min-height: 2.65rem; }}
[data-testid="stTextArea"] textarea, [data-testid="stTextInput"] input {{ border: 1px solid {p['control_line']}; border-radius: 8px; background: {p['rail_field']}; }}
[data-testid="stTextArea"] textarea:focus, [data-testid="stTextInput"] input:focus {{ border-color: {p['focus']}; }}
.rwdp-gates {{ width: 100%; }}

/* the product header: name, badge, the six stages as one strip, the next step */
.rwdp-header {{ background: var(--rwdp-surface); border: 1px solid var(--rwdp-line); border-radius: 12px;
                padding: 0.9rem 1.1rem 0.8rem 1.1rem; margin: 0 0 1rem 0; }}
.rwdp-header .crumbs {{ font-size: 0.78rem; color: var(--rwdp-muted); margin-bottom: 0.15rem; }}
.rwdp-header .crumbs b {{ color: var(--rwdp-ink); font-weight: 500; }}
.rwdp-header .product-line {{ display: flex; align-items: center; gap: 0.6rem; flex-wrap: wrap; }}
.rwdp-header .name {{ font-size: 1.35rem; font-weight: 600; letter-spacing: -0.01em; color: var(--rwdp-ink); margin: 0; padding: 0; }}
.rwdp-header .badge {{ font: 600 10px/1.2 "IBM Plex Sans", sans-serif; letter-spacing: .04em; text-transform: uppercase; color: {p['blocked']}; border: 1px solid {p['blocked']}; border-radius: 4px; padding: 3px 6px; }}
.rwdp-header .who {{ font-size: 0.78rem; color: var(--rwdp-muted); margin-left: auto; text-transform: uppercase; letter-spacing: 0.06em; }}
.rwdp-stages {{ display: flex; gap: 0; margin: 0.7rem 0 0.4rem 0; padding: 0;
  list-style: none; align-items: stretch; }}
.rwdp-stages .stage {{ flex: 1 1 0; position: relative; padding: 0.35rem 0.2rem 0.2rem 0.2rem; text-align: center;
                       border-top: 4px solid {p['line']}; }}
.rwdp-stages .stage .num {{ display: inline-block; width: 1.5rem; height: 1.5rem; line-height: 1.5rem; border-radius: 999px;
                            font: 600 0.78rem/1.5rem "IBM Plex Mono", monospace; color: #fff; background: {p['not_started']}; }}
.rwdp-stages .stage .lbl {{ display: block; font-size: 0.78rem; color: var(--rwdp-muted); margin-top: 0.2rem; }}
.rwdp-stages .stage .st {{ display: block; font-size: 0.7rem; letter-spacing: 0.04em; text-transform: uppercase; color: var(--rwdp-muted); }}
.rwdp-stages .stage.complete {{ border-top-color: {p['complete']}; }}
.rwdp-stages .stage.complete .num {{ background: {p['complete']}; }}
.rwdp-stages .stage.current {{ border-top-color: {p['accent']}; }}
.rwdp-stages .stage.current .num {{ background: {p['accent']}; color: {p['accent_ink']}; }}
.rwdp-stages .stage.current .lbl {{ color: var(--rwdp-ink); font-weight: 600; }}
.rwdp-stages .stage.blocked {{ border-top-color: {p['blocked']}; }}
.rwdp-stages .stage.blocked .num {{ background: {p['blocked']}; }}
.rwdp-stages .stage.blocked .lbl {{ color: var(--rwdp-ink); font-weight: 600; }}
.rwdp-header .next {{ margin-top: 0.5rem; font-size: 0.92rem; color: var(--rwdp-ink); }}
.rwdp-header .next .k {{ font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.06em; color: var(--rwdp-muted); margin-right: 0.5rem; }}
.rwdp-header .next .owner {{ color: var(--rwdp-muted); font-size: 0.82rem; margin-left: 0.5rem; }}
.rwdp-header .checked {{ font-size: 0.74rem; color: var(--rwdp-muted); margin-top: 0.25rem; }}
@media (max-width: 1024px) {{
  .rwdp-stages {{ display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 0.5rem 0; }}
}}
[role="dialog"] [role="grid"] [role="button"][data-selected="true"] {{
  background-color: var(--rwdp-accent) !important; color: var(--rwdp-accent-ink) !important;
}}
@media (max-width: 640px) {{
  .rwdp-header .who {{ margin-left: 0; overflow-wrap: anywhere; }}
  .rwdp-pill {{ white-space: normal; }}
  .rwdp-gates :is(th, td) {{ padding: 0.4rem; overflow-wrap: anywhere; }}
}}
/* the small strip a Home card carries */
.rwdp-mini {{ display: flex; gap: 3px; margin: 0.35rem 0 0.4rem 0; }}
.rwdp-mini span {{ flex: 1 1 0; height: 6px; border-radius: 3px; background: {p['line']}; }}
.rwdp-mini span.complete {{ background: {p['complete']}; }}
.rwdp-mini span.current {{ background: {p['accent']}; }}
.rwdp-mini span.blocked {{ background: {p['blocked']}; }}
.rwdp-mini-line {{ font-size: 0.82rem; color: var(--rwdp-ink); }}
.rwdp-mini-line .muted {{ color: var(--rwdp-muted); }}
/* the sidebar rail reads as one navigation, not a form */
[data-testid="stSidebar"] [data-testid="stRadio"] > label {{ display: none; }}
[data-testid="stSidebar"] [data-testid="stRadio"] [role="radiogroup"] {{ gap: 0; flex-direction: column; }}
/* Native radio controls stay present and keyboard-focusable. */
[data-testid="stSidebar"] [data-testid="stRadio"] [role="radiogroup"] label {{ padding: 0.42rem 0.7rem; margin: 1px 0; font-size: 0.92rem; }}
[data-testid="stSidebar"] .rwdp-navhead {{ font-size: 0.7rem; letter-spacing: 0.08em; text-transform: uppercase; color: var(--rwdp-rail-muted);
                                            margin: 0.6rem 0 0.15rem 0.2rem; }}
[data-testid="stSidebar"] [data-testid="stSelectbox"] > label {{ font-size: 0.74rem; text-transform: uppercase; letter-spacing: 0.06em; color: var(--rwdp-rail-muted); }}
[data-testid="stSidebar"] [data-testid="stButton"] button {{ min-height: 2.3rem; }}
[data-testid="stSidebarCollapseButton"], [data-testid="stSidebarCollapseButton"] button {{
  visibility: visible !important; opacity: 1 !important;
}}
/* cards and section titles */
.rwdp-card-title {{ font-size: 1.05rem; font-weight: 600; margin: 0 0 0.2rem; padding: 0; color: var(--rwdp-ink); }}
.rwdp-card-sub {{ font-size: 0.8rem; color: var(--rwdp-muted); }}
.rwdp-section {{ margin: 0 0 0.6rem 0; }}
.rwdp-section .t {{ font-size: 1.5rem; font-weight: 600; letter-spacing: -0.01em; color: var(--rwdp-ink); margin: 0; padding: 0; }}
.rwdp-section .s {{ font-size: 0.9rem; color: var(--rwdp-muted); margin-top: 0.1rem; }}
[data-testid="stExpander"] details summary p {{ font-size: 0.9rem; }}
@media (max-width: 760px) {{
  .rwdp-stepper {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
  .rwdp-strip {{ flex-wrap: wrap; gap: 8px; }}
  .rwdp-stages {{ flex-wrap: wrap; }}
  .rwdp-stages .stage {{ flex: 1 1 30%; }}
  .block-container {{ padding-left: 1rem; padding-right: 1rem; }}
}}
</style>"""


def pill(status: str) -> str:
    """A status pill: colour AND word, HTML-escaped. Unknown statuses render muted, never blank."""
    key, label = STATUS_STYLE.get(str(status or "").strip().lower(), ("not_started", str(status or "unknown")))
    return f'<span class="rwdp-pill" style="background:{PALETTE[key]}">{html.escape(label)}</span>'


def gate_table(gates: list) -> str:
    """The six gates as a table with pills. Every cell is escaped: a gate name or a blocker is
    text from a governance page, and text from a page is never markup."""
    rows = []
    for g in gates or []:
        if not isinstance(g, dict):
            continue
        n = html.escape(str(g.get("gate") if g.get("gate") is not None else ""))
        name = html.escape(str(g.get("name") or ""))
        blockers = g.get("blockers") or []
        rows.append(f'<tr><td class="n">{n}</td><th scope="row">{name}</th><td>{pill(g.get("status"))}</td>'
                    f'<td class="b">{len(blockers) if isinstance(blockers, list) else 0}</td></tr>')
    return ('<table class="rwdp-gates"><caption class="rwdp-sr-only">Product review gate status</caption>'
            '<thead><tr><th scope="col">gate</th><th scope="col">name</th><th scope="col">status</th>'
            '<th scope="col">blockers</th></tr></thead><tbody>' + "".join(rows) + "</tbody></table>")


def strip(pack: str, actor_name: str, role: str, badge: str = "") -> str:
    """The header strip: which pack, who, as what — and the PERSISTENT badge a non-product pack
    carries (ninth review: fixtures read as live products). Escaped."""
    b = f'<span class="badge">{html.escape(badge)}</span>' if badge else ""
    return (f'<div class="rwdp-strip"><span class="pack">{html.escape(pack)}</span>{b}'
            f'<span class="role">{html.escape(actor_name)} · {html.escape(role)}</span></div>')


def watermark() -> str:
    """The demo watermark: reference fixtures and synthetic data, nothing here is a product."""
    return ('<div class="rwdp-watermark">DEMO / SYNTHETIC. Reference fixtures and synthetic data. '
            'Nothing shown here is a product, a count of real patients, or a release.</div>')


LIFECYCLE_STATES = {"done": "complete", "open": "in_progress", "blocked": "blocked", "not started": "not_started",
                    # the six gates on the Flow page speak status.py's words; the current gate is the one a person acts on
                    "in progress": "in_progress", "current": "in_progress", "approved, awaiting promotion": "in_progress",
                    "awaiting a named approval": "in_progress", "cannot complete": "blocked"}


def stepper(steps: list) -> str:
    """The product lifecycle as one row of steps, each with its colour AND its word."""
    cells = []
    for s in steps or []:
        key = LIFECYCLE_STATES.get(str(s.get("state") or "not started"), "not_started")
        cells.append(f'<div class="step" style="border-top-color:{PALETTE[key]}">'
                     f'<div class="step-name">{html.escape(str(s.get("name") or ""))}</div>'
                     f'<div class="step-state" style="color:{PALETTE[key]}">{html.escape(str(s.get("state") or ""))}</div>'
                     f'<div class="step-why">{html.escape(str(s.get("why") or ""))}</div></div>')
    return '<div class="rwdp-stepper">' + "".join(cells) + "</div>"


# The six stages (stage_model) as HTML. State words are stage_model's; the CSS class is the word.
_STAGE_WORDS = {"complete": "complete", "current": "current step", "blocked": "blocked", "upcoming": "upcoming", "not checked": "not checked"}


def stages_strip(rows: list) -> str:
    """The six stages as one strip: number, name, state — colour AND word, escaped."""
    cells = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        state = str(r.get("state") or "not checked")
        cls = {"complete": "complete", "current": "current", "blocked": "blocked"}.get(state, "")
        current = ' aria-current="step"' if state == "current" else ""
        cells.append(f'<li class="stage {cls}"{current}><span class="num">{html.escape(str(r.get("gate") or ""))}</span>'
                     f'<span class="lbl">{html.escape(str(r.get("label") or ""))}</span>'
                     f'<span class="st">{html.escape(_STAGE_WORDS.get(state, state))}</span></li>')
    return '<ol class="rwdp-stages" role="list" aria-label="Product review stages">' + "".join(cells) + "</ol>"


def product_header(label: str, rows: list, *, badge: str = "", actor: str = "", role: str = "", crumb: str = "",
                   next_title: str = "", next_owner: str = "", checked_at: str = "", unchecked_note: str = "",
                   checked_label: str = "Checked") -> str:
    """The card at the top of every product page: where you are, how far the product is, what it
    needs next — the same words the Flow card uses. Every string is escaped."""
    b = f'<span class="badge">{html.escape(badge)}</span>' if badge else ""
    who = f'<span class="who">{html.escape(actor)} · {html.escape(role)}</span>' if actor else ""
    crumbs = f'<div class="crumbs">Home › <b>{html.escape(label)}</b>' + (f' › {html.escape(crumb)}' if crumb else "") + "</div>"
    if next_title:
        nxt = (f'<div class="next"><span class="k">Next step</span>{html.escape(next_title)}'
               + (f'<span class="owner">{html.escape(next_owner)}</span>' if next_owner else "") + "</div>")
    else:
        nxt = f'<div class="next"><span class="k">Next step</span>{html.escape(unchecked_note or "Not checked yet.")}</div>'
    checked = f'<div class="checked">{html.escape(checked_label)} {html.escape(checked_at)}</div>' if checked_at else ""
    return (f'<div class="rwdp-header">{crumbs}<div class="product-line"><h1 class="name">{html.escape(label)}</h1>{b}{who}</div>'
            f'{stages_strip(rows)}{nxt}{checked}</div>')


def mini_stages(rows: list, line: str = "") -> str:
    """A Home card's six-segment progress strip with its one-line summary, escaped."""
    segs = "".join(f'<span aria-hidden="true" class="{ {"complete": "complete", "current": "current", "blocked": "blocked"}.get(str(r.get("state")), "") }"></span>'
                   for r in rows or [] if isinstance(r, dict))
    summary = "; ".join(f'{r.get("label") or "Step " + str(r.get("gate") or index)}: '
        f'{_STAGE_WORDS.get(str(r.get("state") or "not checked"), str(r.get("state")))}'
        for index, r in enumerate(rows or [], 1) if isinstance(r, dict)) or "Review progress not checked"
    return (f'<div class="rwdp-mini" role="img" aria-label="{html.escape(summary, quote=True)}">'
            f'{segs}</div>') + (f'<div class="rwdp-mini-line">{html.escape(line)}</div>' if line else "")


def section_title(title: str, sub: str = "") -> str:
    """A page title with its one-line purpose, so every section opens the same way."""
    return f'<div class="rwdp-section"><h2 class="t">{html.escape(title)}</h2>' + (f'<div class="s">{html.escape(sub)}</div>' if sub else "") + "</div>"


def navhead(text: str) -> str:
    return f'<h2 class="rwdp-navhead">{html.escape(text)}</h2>'


def card_title(text: str, rows: list | None = None, line: str = "") -> str:
    """A card's title, optionally with its six-segment stage strip beneath. Escaped."""
    return f'<h3 class="rwdp-card-title">{html.escape(text)}</h3>' + (mini_stages(rows, line) if rows is not None else "")
