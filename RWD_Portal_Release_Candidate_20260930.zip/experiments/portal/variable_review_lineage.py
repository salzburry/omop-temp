"""Content-pinned draft master links and readable scientific change evidence.

No file reads or writes, equivalence guesses, or approval decisions happen here.
The caller captures a library candidate at an explicit save and retains that
snapshot on later edits. Missing historical links are never reconstructed.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import re

from experiments.portal.variable_review_consistency import canonical_type

MAX_BYTES = 512 * 1024
MAX_DEPTH = 8
_SHA = re.compile(r"[a-f0-9]{64}")
_LINK_KEYS = {"version", "master_name", "declared_version", "source_fingerprint",
              "source_paths", "definition", "fields", "parameter_slots", "citations",
              "lineage", "content_digest"}
_LINEAGE_KEYS = {"version", "origin", "originating_row_digest", "product_snapshot", "parent"}
_ORIGIN_KEYS = {"pack", "item_id", "variable_id", "actor_id", "at"}
_BASELINE_PATHS = {"derivation", "grain", "anchor", "window", "record_selection", "tie_break",
                   "cohort_applicability", "missing", "units", "source.value", "source.kind",
                   "output.type", "output.codes", "output.nullable"}
_SETTING_PATHS = _BASELINE_PATHS - {"derivation", "output.type", "source.kind"}


def _encoded(value):
    raw = json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False).encode("utf-8")
    if len(raw) > MAX_BYTES:
        raise ValueError("The master history exceeds its supported size.")
    return raw


def _digest(value):
    return hashlib.sha256(_encoded(value)).hexdigest()


def _present(value):
    return value is not None and value != "" and value != [] and value != {}


def _get(values, path):
    value = values
    for part in path.split("."):
        value = value.get(part) if isinstance(value, dict) else None
    return value


def _sha(value):
    return isinstance(value, str) and _SHA.fullmatch(value) is not None


def _check_lineage(value, depth):
    if value is None:
        return
    if depth > MAX_DEPTH:
        raise ValueError("The master history contains too many parent definitions.")
    if not isinstance(value, dict) or set(value) != _LINEAGE_KEYS or type(value.get("version")) is not int or value["version"] != 1:
        raise ValueError("The originating definition history has an unsupported format.")
    origin = value["origin"]
    if not isinstance(origin, dict) or set(origin) != _ORIGIN_KEYS or any(
            not isinstance(text, str) or not text.strip() or len(text) > 2000 for text in origin.values()):
        raise ValueError("The originating definition needs its product, row, author and time.")
    if not _sha(value["originating_row_digest"]) or not isinstance(value["product_snapshot"], dict):
        raise ValueError("The originating definition needs its recorded product values and content digest.")
    if value["originating_row_digest"] != _digest(value["product_snapshot"]):
        raise ValueError("The originating product values no longer match their recorded digest.")
    if value["parent"] is not None:
        _check(value["parent"], depth + 1)


def _check(value, depth=0):
    if depth > MAX_DEPTH:
        raise ValueError("The master history contains too many parent definitions.")
    if not isinstance(value, dict) or set(value) != _LINK_KEYS or type(value.get("version")) is not int or value["version"] != 1:
        raise ValueError("The saved master link has an unsupported format.")
    if not isinstance(value["master_name"], str) or not value["master_name"].strip():
        raise ValueError("The saved master link is missing its definition name.")
    if any(not isinstance(value[key], str) for key in ("definition", "declared_version")):
        raise ValueError("The saved master link has invalid definition or version text.")
    if not _sha(value["source_fingerprint"]) or not _sha(value["content_digest"]):
        raise ValueError("The saved master link is missing its content fingerprints.")
    if any(not isinstance(value[key], list) or any(not isinstance(item, str) for item in value[key])
           for key in ("source_paths", "citations")):
        raise ValueError("The saved master link has invalid source citations.")
    if not isinstance(value["fields"], dict) or set(value["fields"]) - _BASELINE_PATHS:
        raise ValueError("The saved master link contains unsupported comparison fields.")
    if not isinstance(value["parameter_slots"], list) or any(not isinstance(slot, dict) for slot in value["parameter_slots"]):
        raise ValueError("The saved master link contains invalid parameter slots.")
    if value["content_digest"] != _digest({key: item for key, item in value.items() if key != "content_digest"}):
        raise ValueError("The saved master definition no longer matches its recorded content.")
    _check_lineage(value["lineage"], depth)


def validate(snapshot):
    """Return errors for a complete link, including its bounded parent chain."""
    try:
        _encoded(snapshot)
        _check(snapshot)
        return []
    except (ValueError, TypeError, KeyError, RecursionError, OverflowError) as error:
        return [str(error) or "The saved master link cannot be read."]


def validate_lineage(value):
    """Validate an optional custom catalogue origin and its frozen parent link."""
    try:
        _encoded(value)
        _check_lineage(value, 0)
        return []
    except (ValueError, TypeError, KeyError, RecursionError, OverflowError) as error:
        return [str(error) or "The definition origin cannot be read."]


def capture(master):
    """Freeze declared reusable content, excluding illustrative example values."""
    if not isinstance(master, dict) or not str(master.get("variable_id") or "").strip():
        raise ValueError("Choose a current master definition before recording its link.")
    fields = {}
    for path, value in (("derivation", master.get("reusable_derivation") or master.get("derivation")
                        or (master.get("record") or {}).get("derivation")),
                        ("output.type", master.get("data_type")), ("source.kind", master.get("declared_source_kind"))):
        if _present(value):
            fields[path] = (canonical_type(value) or value) if path == "output.type" else deepcopy(value)
    options = {}
    for option in master.get("reference_options") or []:
        if not isinstance(option, dict) or option.get("illustrative") is not False or option.get("path") not in _BASELINE_PATHS:
            continue
        if _present(option.get("value")):
            options.setdefault(option["path"], []).append(option["value"])
    # Conflicting declarations have no single baseline. Do not silently choose
    # the first one or mistake illustrative prostate settings for a standard.
    for path, values in options.items():
        if path not in fields and all(item == values[0] for item in values):
            fields[path] = (canonical_type(values[0]) or values[0]) if path == "output.type" else deepcopy(values[0])
    payload = {"version": 1, "master_name": master["variable_id"],
               "declared_version": str(master.get("declared_version") or ""),
               "source_paths": deepcopy(master.get("source_paths") or ([master["source_path"]] if master.get("source_path") else [])),
               "definition": str((master.get("record") or {}).get("spec", {}).get("rule") or ""),
               "fields": fields, "parameter_slots": deepcopy(master.get("parameter_slots") or []),
               "citations": deepcopy(master.get("spec_refs") or []), "lineage": deepcopy(master.get("lineage"))}
    payload["source_fingerprint"] = master.get("source_fingerprint") or _digest(payload)
    payload["content_digest"] = _digest(payload)
    errors = validate(payload)
    if errors:
        raise ValueError(errors[0])
    return payload


def _chain(snapshot):
    chain = []
    while snapshot is not None:
        lineage = snapshot["lineage"]
        chain.append({"master_name": snapshot["master_name"], "content_digest": snapshot["content_digest"],
                      "declared_version": snapshot["declared_version"],
                      "origin": deepcopy(lineage["origin"]) if lineage else None,
                      "product_snapshot": deepcopy(lineage["product_snapshot"]) if lineage else None})
        snapshot = lineage["parent"] if lineage else None
    return list(reversed(chain))


def compare(snapshot, row, current_master=None):
    """Compare a product to its saved baseline, never today's replacement text.

    Settings without a declared master value are product choices, not deviations.
    The report is draft history only and makes no scientific approval claim.
    """
    result = {"status": "custom", "deviations": [], "settings": [], "unchanged": [],
              "master_changed": False, "errors": [], "chain": [], "change_count": 0}
    if snapshot is None:
        result["status"] = "untracked" if row.get("master_name") else "custom"
        return result
    result["errors"] = validate(snapshot)
    if result["errors"]:
        result["status"] = "invalid"
        return result
    result["chain"] = _chain(snapshot)
    if current_master is not None:
        try:
            result["master_changed"] = capture(current_master)["content_digest"] != snapshot["content_digest"]
        except (ValueError, TypeError, KeyError):
            result["master_changed"] = True
    values = row.get("values") or {}
    for path, baseline in snapshot["fields"].items():
        actual = _get(values, path)
        item = {"path": path, "master": deepcopy(baseline), "value": deepcopy(actual)}
        result["unchanged" if actual == baseline else "deviations"].append(item)
    for path in sorted(_SETTING_PATHS - set(snapshot["fields"])):
        actual = _get(values, path)
        if _present(actual):
            result["settings"].append({"path": path, "value": deepcopy(actual)})
    for path, value in (("family", row.get("family")),
                        ("clinical_rule", row.get("clinical_rule")),
                        ("value_interpretation", (row.get("value_interpretation") or {}).get("value"))):
        if _present(value):
            result["settings"].append({"path": path, "value": deepcopy(value)})
    result["change_count"] = len(result["deviations"])
    result["status"] = "deviates" if result["deviations"] else "product_settings" if result["settings"] else "matches"
    return result


def _state(row):
    values = deepcopy(row.get("values") or {})
    result = {}
    def flatten(value, prefix=""):
        for key, item in value.items():
            path = prefix + "." + key if prefix else key
            if isinstance(item, dict) and item:
                flatten(item, path)
            else:
                result[path] = deepcopy(item)
    flatten(values)
    result["family"] = deepcopy(row.get("family") or {})
    if row.get("clinical_rule"):
        result["clinical_rule"] = deepcopy(row["clinical_rule"])
    result["value_interpretation"] = deepcopy((row.get("value_interpretation") or {}).get("value"))
    result["master_name"] = row.get("master_name") or ""
    return result


def event(before, after, *, actor_id, at, phase="science", item_id="", input_digest=""):
    """Record exact before/after answers; omit confirmation-clock-only changes."""
    if not isinstance(actor_id, str) or not actor_id.strip() or not isinstance(at, str) or not at.strip():
        raise ValueError("A recorded change needs its editing profile and time.")
    previous, current = _state(before), _state(after)
    changes = [{"path": path, "before": deepcopy(previous.get(path)), "after": deepcopy(current.get(path))}
               for path in sorted(set(previous) | set(current)) if previous.get(path) != current.get(path)]
    record = {"version": 1, "actor_id": actor_id.strip(), "at": at, "phase": phase,
              "item_id": item_id, "input_digest": input_digest, "changes": changes,
              "before_digest": _digest(previous), "after_digest": _digest(current),
              "master_before": deepcopy(before.get("master_link")), "master_after": deepcopy(after.get("master_link"))}
    for link in (record["master_before"], record["master_after"]):
        if link is not None and validate(link):
            raise ValueError("A recorded change cannot refer to an invalid master link.")
    _encoded(record)
    return record
