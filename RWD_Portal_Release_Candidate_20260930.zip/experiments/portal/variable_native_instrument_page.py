"""Guided fields for native instruments; no code/JSON authoring and no defaults."""
from copy import deepcopy
import streamlit as st
from experiments.portal import variable_review_controls as controls
from experiments.portal import variable_native_instruments as native

ENUMS = {
    "series_scope": ("from_index", "full_history"), "reference": ("nadir", "baseline"),
    "direction": ("rise", "fall"), "event_date": ("first_qualifying", "confirming"),
    "same_day": ("lowest_first", "highest_first"), "mode": ("abstracted", "sessionised"),
    "reduce": ("sum", "first", "last"),
    "relation": ("overlaps_within", "starts_after_within", "precedes"),
}
NUMBERS = {"threshold_pct", "threshold_abs", "confirm_after_days", "gap_days", "window_days_before", "window_days_after", "window_days"}


def _bounds(record):
    return {"lower": record.get("min", record.get("min_excl")), "upper": record.get("max", record.get("max_excl")),
            "include_lower": "min" in record, "include_upper": "max" in record}


def _native_bounds(row):
    return {("min" if row.get("include_lower") else "min_excl"): row["lower"] for _ in [0] if row.get("lower") is not None} | {
            ("max" if row.get("include_upper") else "max_excl"): row["upper"] for _ in [0] if row.get("upper") is not None}


def _risk_tables(item, key, permitted):
    from experiments.portal.variable_clinical_rule_page import _grid
    st.caption("Use whole-number points here. Fractional scores need an engineering handoff to preserve their exact decimal result.")
    point_rows = []
    for component in item.get("components") or []:
        kind = "Number ranges" if component.get("bands") else "Categories"
        for entry in component.get("bands") or component.get("values") or []:
            point_rows.append({"component": component.get("name", ""), "column": component.get("column", ""),
                "kind": kind, "values": "\n".join(entry.get("from_equals_ci", entry.get("from_prefixes", []))),
                "case_sensitive": "from_prefixes" in entry, "points": entry.get("points"),
                "special": entry.get("when", ""), **_bounds(entry)})
    st.write("Component points")
    columns = {"component": st.column_config.TextColumn("Component"), "column": st.column_config.TextColumn("Input column"),
        "kind": st.column_config.SelectboxColumn("Match using", options=["Number ranges", "Categories"]),
        "values": st.column_config.TextColumn("Category values · one per line"),
        "case_sensitive": st.column_config.CheckboxColumn("Match case"),
        "lower": st.column_config.NumberColumn("From"), "include_lower": st.column_config.CheckboxColumn("Include From"),
        "upper": st.column_config.NumberColumn("To"), "include_upper": st.column_config.CheckboxColumn("Include To"),
        "points": st.column_config.NumberColumn("Points", step=1),
        "special": st.column_config.SelectboxColumn("Special case", options=["", "missing", "fallthrough"])}
    rows = _grid(point_rows, key + "points", permitted, columns,
                 numeric=("lower", "upper", "points"), boolean=("include_lower", "include_upper", "case_sensitive"))
    grouped, problems = {}, []
    for row in rows:
        if not any(row.get(key) for key in ("component", "column", "values")) and row.get("points") is None: continue
        identity = row.get("component") or ""
        kind = "bands" if row.get("kind") == "Number ranges" else "values"
        component = grouped.setdefault(identity, {"name": identity, "column": row.get("column") or "", kind: []})
        if component["column"] != (row.get("column") or "") or kind not in component:
            problems.append("Each component must use one input column and one match type."); continue
        points = row.get("points")
        entry = {"points": int(points) if isinstance(points, float) and points.is_integer() else points}
        if row.get("special"): entry["when"] = row["special"]
        elif kind == "bands": entry.update(_native_bounds(row))
        else: entry["from_prefixes" if row.get("case_sensitive") else "from_equals_ci"] = [v.strip() for v in str(row.get("values") or "").splitlines() if v.strip()]
        component[kind].append(entry)
    item["components"] = list(grouped.values())
    st.write("Categories for the total points")
    category_columns = {"label": st.column_config.TextColumn("Risk category"), "code": st.column_config.NumberColumn("Code", step=1),
        "lower": st.column_config.NumberColumn("From"), "include_lower": st.column_config.CheckboxColumn("Include From"),
        "upper": st.column_config.NumberColumn("To"), "include_upper": st.column_config.CheckboxColumn("Include To")}
    categories = [{"label": c.get("label", ""), "code": c.get("code"), **_bounds(c)} for c in item.get("categories") or []]
    edited = _grid(categories, key + "categories", permitted, category_columns,
                   numeric=("code", "lower", "upper"), boolean=("include_lower", "include_upper"))
    item["categories"] = [{"label": r.get("label") or "", "code": int(r["code"]) if isinstance(r.get("code"), float) and r["code"].is_integer() else r.get("code"), **_native_bounds(r)} for r in edited if r.get("label") or r.get("code") is not None]
    incomplete = item.get("incomplete") or {}
    item["incomplete"] = {"label": st.text_input("Category when a component is missing", value=incomplete.get("label", ""), key=key + "missing_label", disabled=not permitted),
                          "code": st.number_input("Missing-category code", value=incomplete.get("code"), step=1, key=key + "missing_code", disabled=not permitted)}
    return problems


def render(row, rule, *, key, permitted):
    operator = rule["operator"]
    item = deepcopy(rule.get("native") or {})
    original_keys = set(item)
    source = (row.get("values") or {}).get("source") or {}
    columns = list((source.get("columns") or {}).keys()) if isinstance(source.get("columns"), dict) else []
    st.caption("Supply this product's calculation rules. No published instrument or clinical coefficients are filled in automatically.")
    st.caption({
        "risk_score": "This adds discrete component points and classifies the total. Continuous weighted prediction models need a separate implementation.",
        "serial_marker": "Use a source containing one marker's dated measurements. This tests a confirmed change; it does not filter mixed analytes or calculate a rate.",
        "rt_course": "Outputs describe the first course and the total course count. Treatment intent and per-course details require separate definitions.",
        "dose_exposure": "Only the selected drug names and one stated unit are included. Dose conversion and dose changes over time require separate calculations.",
        "modality_relation": "This compares two dated episodes already on the patient record. It does not infer treatment intent."
    }[operator])
    rule["output_stem"] = st.text_input("Output name for this instrument", value=rule.get("output_stem", row.get("variable_id", "").lower()), key=key + "stem", disabled=not permitted)
    item["name"] = rule["output_stem"]
    results = [name for name, _suffix, _type in native.RESULTS[operator]]
    rule["result"] = st.selectbox("Result to deliver", results, index=results.index(rule["result"]) if rule.get("result") in results else None,
                                  format_func=lambda v: v.replace("_", " ").capitalize(), key=key + "result", disabled=not permitted) or ""
    if operator in native.DERIVED:
        st.caption("This calculation uses columns already assembled for the patient. Select Calculated from other variables as its origin.")
    else:
        st.caption("Link an existing source table above; its logical column names are offered here. Sources review checks the delivered names.")
        # A legacy explicit source is kept for mismatch checking, never silently rebound.
        if item.get("source") and source.get("logical_table") and item["source"] != source["logical_table"]:
            st.warning("This saved instrument still names source " + item["source"] + ".")
            if st.button("Use the source table selected above", key=key + "use_selected_source", disabled=not permitted):
                item["source"] = source["logical_table"]
    problems = []
    if operator == "risk_score": problems.extend(_risk_tables(item, key, permitted))
    fields = sorted(native.FIELDS[operator] - {"name", "source", "components", "categories", "incomplete"} - native.GOVERNED)
    if operator == "rt_course":
        mode = st.selectbox("Course records", list(ENUMS["mode"]), index=list(ENUMS["mode"]).index(item["mode"]) if item.get("mode") in ENUMS["mode"] else None,
                            format_func=lambda v: {"abstracted": "Dates already identify each course", "sessionised": "Group sessions using a gap"}[v], key=key + "mode", disabled=not permitted)
        item["mode"] = mode or ""
        active = {"start_column", "end_column"} if mode == "abstracted" else {"date_column", "gap_days"} if mode == "sessionised" else set()
        for old in {"start_column", "end_column", "date_column", "gap_days"} - active: item.pop(old, None)
        fields = sorted(active)
    for field in fields:
        label = field.replace("_", " ").capitalize()
        if field in ENUMS:
            options = list(ENUMS[field])
            item[field] = st.selectbox(label, options, index=options.index(item[field]) if item.get(field) in options else None, key=key + field, disabled=not permitted) or ""
        elif field in NUMBERS:
            if field == "window_days" and item.get("relation") == "precedes":
                item.pop(field, None); continue
            integer = field not in {"threshold_pct", "threshold_abs"}
            value = item.get(field)
            if value is not None: value = int(value) if integer else float(value)
            entered = st.number_input(label, value=value, step=1 if integer else 0.1, key=key + field, disabled=not permitted)
            if entered is None: item.pop(field, None)
            else: item[field] = entered
        elif field == "drugs":
            item[field] = controls.render_multi("Drug names to include", item.get(field, []), item.get(field, []), key=key + field, disabled=not permitted)
        elif field.endswith("_column") or field == "unit":
            choices = {name: name for name in columns} if field.endswith("_column") else {name: name for name in ["mg", "mg/m2", "mg/kg", "g", "Gy"]}
            item[field] = controls.render_choice(label, item.get(field, ""), choices, key=key + field, disabled=not permitted)
        else:
            item[field] = st.text_input(label, value=item.get(field, ""), key=key + field, disabled=not permitted)
    if operator in {"risk_score", "serial_marker"} or operator == "rt_course" and item.get("mode") == "sessionised":
        with st.expander("Instrument reference and reviewer"):
            for field in ("instrument", "citation", "clinically_reviewed_by", "review_date"):
                item[field] = st.text_input(field.replace("_", " ").capitalize(), value=item.get(field, ""), key=key + field, disabled=not permitted,
                                           help="YYYY-MM-DD" if field == "review_date" else None)
            st.caption("These fields document the instrument. Saving them does not approve or sign the product.")
    item = {field: value for field, value in item.items() if field in original_keys or value not in (None, "")}
    rule["native"] = item
    updates = {"clinical_rule": rule}
    try:
        updates.update(native.scientific_updates(rule))
        for issue in native.issues({**row, "clinical_rule": rule}): st.caption(issue)
    except (ValueError, TypeError) as error:
        problems.append(str(error))
    output = next((c for c in native.emitted_columns(rule) if c["result"] == rule.get("result")), None)
    if output: st.info("Delivered field: " + output["name"] + " · " + controls.TYPE_LABELS.get(output["type"], output["type"]))
    if problems:
        updates["_ui_issues"] = problems
        for issue in problems: st.warning(issue)
    return updates
