"""Stage explicit Plan changes for review without changing the governed product.

Allowlisted scalar parameters and reviewed typed clinical rules can be translated. Optional LOT numbering and
observation/cutoff dates for a separate enrollment period can be explicitly added.
Other settings must already exist. Scientific prose
is retained in an engineering handoff, never compiled into a derivation. Candidate
bytes, exclusions and impact are immutable; submission reruns the existing gates
in an isolated copy and records a local review request, never approval or release.

THE REVIEW REQUEST LEAVES THE AUTHOR'S FOLDER (2026-09-07): submission used to stop at a
receipt inside the author's private draft folder, where no reviewer could see it. Submission
now also publishes an immutable snapshot of the checked proposal under the product's shared
.portal-drafts/reviews/ folder (review_inbox.py); the receipt names that request so the author
can follow it. The gates run in the same isolated copy for a proposal and for an applied draft
revision (``validate_files``), so a reviewer's later check is the same check the author ran.
"""
from __future__ import annotations

import difflib
from copy import deepcopy
from collections import Counter
import hashlib
import json
import math
import os
import re
import shutil
import tempfile
import uuid
from datetime import date, datetime, timezone
from pathlib import Path

import yaml

from experiments.portal import design_workspace as dw
from rwd_tools import contract_binding as cb
from rwd_tools import config_diff
from rwd_tools import study_pin
from engine.config import load_config, observation_end, data_cutoff, index_period_start, index_period_end
from engine.strict_yaml import strict_load
from engine.validate import problems
from experiments.portal.treatment_codelist_rules import REF as TREATMENT_CODELIST_REF

CODELIST_REFS = {TREATMENT_CODELIST_REF}

PARAMETERS = {
    "config/data_product.yaml#/study/index_start": ("Study index start", "date"),
    "config/data_product.yaml#/study/index_end": ("Study index end", "date"),
    "config/data_product.yaml#/study/index_period_start": ("Enrollment period start (explicit)", "date"),
    "config/data_product.yaml#/study/index_period_end": ("Enrollment period end (explicit)", "date"),
    "config/data_product.yaml#/study/observation_end": ("Observation end", "date"),
    "config/data_product.yaml#/study/data_cutoff": ("Data cutoff", "date"),
    "variables/outcomes.yaml#/min_followup_days": ("Minimum follow-up days", "integer"),
    "variables/outcomes.yaml#/visit_recency_days": ("Visit recency days", "integer"),
    "variables/outcomes.yaml#/days_per_month": ("Days per month", "number"),
    "variables/treatment.yaml#/max_lines": ("Maximum treatment line", "positive_integer"),
    "config/data_product.yaml#/lot/line_number": ("Treatment line numbering", "lot_numbering"),
    # the delivery declaration (walk UC4-20, 2026-09-07): the schema the vendor delivers into and the cut
    # label a build reads; both are names, checked as names, never data
    # (walk RW4-N03: the run block lives in config/pipeline.yaml on every product and fixture)
    "config/pipeline.yaml#/run/source_schema": ("Delivered source schema", "text"),
    "config/pipeline.yaml#/run/refresh": ("Delivery cut", "text"),
}
CLINICAL_REFS = frozenset("variables/clinical.yaml#/" + name for name in
    ("categoricals", "biomarkers", "labs", "response", "lab_values", "baseline_ecog"))
DICTIONARY_REF = "config/data_product.yaml#/dictionary_overlay"
QC_DATE_ORDER_REF = "config/data_product.yaml#/qc/date_order"
NATIVE_INSTRUMENT_REFS = frozenset({
    "variables/outcomes.yaml#/risk_scores", "variables/outcomes.yaml#/serial_markers",
    "variables/outcomes.yaml#/modality_relations", "variables/treatment.yaml#/rt_courses",
    "variables/treatment.yaml#/dose_exposures",
})
REVIEWED_BLOCK_REFS = CLINICAL_REFS | NATIVE_INSTRUMENT_REFS | {DICTIONARY_REF}
COHORT_REFS = frozenset({"config/data_product.yaml#/cohorts", "config/data_product.yaml#/index_dates"})
LOT_NUMBERING_REF = "config/data_product.yaml#/lot/line_number"
LOT_NUMBERING_CHOICES = ("linenumber", "new_lot_n")
LOT_NUMBERING_DEFAULT = "new_lot_n"
OPTIONAL_STUDY_DATES = {
    "config/data_product.yaml#/study/observation_end": observation_end,
    "config/data_product.yaml#/study/data_cutoff": data_cutoff,
}
REVIEW_RECORD_FIELDS = ("item_id", "variable_id", "definition", "spec_values", "values", "family", "master_name", "logic_reviewed")
MAX_REVIEW_RECORDS = 2000
TEXT_NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.\-]{0,79}")
# Two ceilings, because two different things happen to a product file. A file this module
# PARSES (YAML, JSON, a diff) is loaded whole, so it stays small. A file it only fingerprints
# or copies (an attached specification workbook under prog_spec/) is streamed in chunks and
# never decoded, so the ceiling is the size of a document a person may legitimately attach.
LIMIT = 4 * 1024 * 1024
SOURCE_LIMIT = 128 * 1024 * 1024
CHUNK = 1024 * 1024
SHARED_FOLDER = "handoff/CONFIGURATION_PROPOSALS"
SHARED_NOTICE = "Branch handoff only. Validator results are historical; restage in this checkout and run fresh validators before submission. No approval, reviewer decision, release or study pin is imported."
NO_SUPPORTED_SETTINGS = "This product has no supported settings to change yet."
SHARED_INPUTS = ("products/registry.yaml", "products/metadata/catalog.yaml",
                 "products/_reporting/dashboard/dashboard_vars.yaml")


class Invalid(ValueError):
    pass


def _failure(exc):
    message = str(exc) if isinstance(exc, (Invalid, dw._DraftError)) else dw._storage_message(exc,
        "The configuration proposal could not be processed safely. Reopen it or ask its owner to repair the inputs.")
    return {"ok": False, "passed": False, "changed": False, "errors": [message]}


def _path(root, pack, allowed_packs=None):
    """Applicability is a property of the product's files, never of a product name.

    The feature once compared the pack to one hard-coded product; when that product left the
    repository the whole editor became unreachable. Any pack the workspace accepts qualifies as
    soon as one supported setting is actually present in its YAML.
    """
    base, path, name = dw._pack_path(root, pack, allowed_packs)
    if not supported_parameters(base, name):
        raise Invalid(NO_SUPPORTED_SETTINGS)
    return base, path, name


def _safe(file):
    if file.resolve() != file:
        raise Invalid("A proposal input redirects to another location.")
    return file


def _name(file):
    """Name a file the way the person sees it: relative to its pack when it lives in one."""
    parts = file.parts
    for index, part in enumerate(parts):
        if part in ("products", "fixtures") and len(parts) > index + 4:
            return "/".join(parts[index + 4:])
    return "/".join(parts[-2:])


def _bounded(file, limit):
    """Refuse a missing or oversized file by name, so the person knows which file to look at."""
    _safe(file)
    if not file.is_file():
        raise Invalid(f"A proposal input is missing: {_name(file)}.")
    size = file.stat().st_size
    if size > limit:
        megabytes = -(-size // (1024 * 1024))
        raise Invalid(f"{_name(file)} is larger than the supported size of {limit // (1024 * 1024)} MB; "
                      f"it is {megabytes} MB.")
    return file


def _read(file):
    """Bytes of a file this module parses whole; the small ceiling bounds memory, not attachments."""
    return _bounded(file, LIMIT).read_bytes()


def _fingerprint(file):
    """Streamed digest: an attached workbook is hashed in chunks and never held in memory."""
    digest = hashlib.sha256()
    with _bounded(file, SOURCE_LIMIT).open("rb") as stream:
        for chunk in iter(lambda: stream.read(CHUNK), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _copy(file, dest):
    """Stream a product file into the isolated candidate under the same ceiling as its digest."""
    shutil.copyfile(_bounded(file, SOURCE_LIMIT), dest)


def _json(file):
    return json.loads(_read(file).decode("utf-8"))


def _digest(data):
    return hashlib.sha256(data).hexdigest()


def _parse(text):
    doc = _parameter_document(text, "configuration YAML")
    if not isinstance(doc, dict):
        raise Invalid("Configuration must be a YAML mapping.")
    return doc


def _encode(value):
    data = json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False).encode("utf-8")
    if len(data) > LIMIT:
        raise Invalid("This proposal is too large; split it into smaller changes.")
    return data


def _owner_directory(path, owner):
    """Resolve the same private proposal location for authors and review receipts."""
    # Preserve old proposals in place. The full digest remains in every packet;
    # shorter new folders leave room for candidate paths in a Windows checkout.
    parent = path / ".portal-drafts" / "configuration"
    legacy = _safe(parent / owner[:24])
    return legacy if legacy.exists() else _safe(parent / owner[:dw.OWNER_DIRECTORY_CHARS])


def _store(root, pack, actor_id, allowed_packs):
    base, path, name = _path(root, pack, allowed_packs)
    # Reuse the draft editor's actor identity rules without reading another actor.
    _base, _name, owner, _directory = dw._store(base, name, actor_id, allowed_packs)
    directory = _owner_directory(path, owner)
    return base, path, name, owner, directory


def _authorized(local_demo, can_write):
    if local_demo is not True or can_write is not True:
        raise Invalid("Staging, validation and submission require an authorized local editing session.")


def _folder(directory, proposal_id):
    if not isinstance(proposal_id, str) or not re.fullmatch(r"[0-9a-f]{32}", proposal_id):
        raise Invalid("Choose a staged proposal from this product and editing session.")
    return _safe(directory / proposal_id)


def _tree_files(folder):
    if not folder.exists():
        return []
    _safe(folder)
    result = []
    for directory, dirs, files in os.walk(folder, followlinks=False):
        dirs[:] = [name for name in dirs if name not in {".portal-drafts", "__pycache__", ".git"}]
        for name in dirs:
            _safe(Path(directory) / name)
        for name in files:
            file = _safe(Path(directory) / name)
            if file.suffix not in {".pyc", ".pyo"}:
                result.append(file)
    return sorted(result)


def _snapshot(base, path):
    """Fingerprint validation and declared consumer inputs, including absent files."""
    from experiments.portal import workflow_outputs
    references = workflow_outputs.declared_references(path, _read)
    files = {file for file in _tree_files(path)
             if not workflow_outputs.is_saved_output(file.relative_to(base).as_posix()) or file.resolve() in references}
    for rel in (*SHARED_INPUTS, "work", "refreshes"):
        file = _safe(base / rel)
        if file.is_dir():
            # Consumer enumeration reads pins and published build receipts. Other
            # study documents and delivered data are outside this review surface.
            files.update(p for p in _tree_files(file) if (
                p.name == study_pin.PINS if rel == "work" else p.suffix.lower() in {".yaml", ".yml", ".json"}))
        else:
            files.add(file)
    return dw._hash({file.relative_to(base).as_posix(): _fingerprint(file) if file.is_file() else None
                     for file in sorted(files)})


def _scalar_node(text, keys):
    node = yaml.compose(text)
    for key in keys:
        if not isinstance(node, yaml.MappingNode):
            raise Invalid("The configured parameter is no longer an editable scalar.")
        matches = [value for name, value in node.value if name.value == key]
        if len(matches) != 1:
            raise Invalid("The configured parameter is missing or ambiguous.")
        node = matches[0]
    if not isinstance(node, yaml.ScalarNode):
        raise Invalid("The configured parameter is no longer an editable scalar.")
    return node


def _parameter_document(text, relative):
    # An alias can make an apparent scalar edit change another configuration
    # field too. Refuse it before construction, including recursive aliases.
    try:
        if any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(text)):
            raise Invalid("YAML aliases and anchors are not supported by this scalar editor.")
        return strict_load(text)
    except (yaml.YAMLError, ValueError) as exc:
        raise Invalid(f"Repair {relative} before proposing changes: {exc}") from exc


def _lot_parent(document):
    if not isinstance(document, dict):
        raise Invalid("Repair config/data_product.yaml: treatment numbering requires a YAML mapping.")
    if "lot" in document and not isinstance(document["lot"], dict):
        raise Invalid("Repair config/data_product.yaml: lot must be a mapping before proposing treatment numbering.")
    parent = document.get("lot", {})
    if "line_number" in parent and (parent["line_number"] is None or isinstance(parent["line_number"], (dict, list))):
        raise Invalid("Repair config/data_product.yaml: lot.line_number must be a scalar setting.")
    return parent


def _insert_mapping_entry(text, node, key, value):
    """Insert one explicit key without rewriting unrelated YAML or its comments."""
    if node.flow_style:
        position = node.end_mark.index - 1
        if text[position:position + 1] != "}":
            raise Invalid("The configuration mapping cannot be edited safely.")
        preceding = [token for token in yaml.scan(text) if token.start_mark.index < position]
        has_comma = preceding and isinstance(preceding[-1], yaml.FlowEntryToken)
        entry = (", " if node.value and not has_comma else " ") + key + ": " + value
        return text[:position] + entry + text[position:]
    if not node.value:
        raise Invalid("The configuration mapping cannot be edited safely.")
    first_key = node.value[0][0]
    position = first_key.start_mark.index
    newline = "\r\n" if "\r\n" in text else "\n"
    entry = key + ": " + value + newline + " " * first_key.start_mark.column
    return text[:position] + entry + text[position:]


def _patch_parameter(text, ref, value):
    relative, pointer = ref.split("#/", 1)
    document = _parameter_document(text, relative)
    replacement = yaml.safe_dump(value, allow_unicode=True, default_flow_style=True).removesuffix("...\n").rstrip("\n")
    if ref == LOT_NUMBERING_REF:
        parent = _lot_parent(document)
        if "line_number" not in parent:
            root = yaml.compose(text)
            if "lot" not in document:
                return _insert_mapping_entry(text, root, "lot", "{line_number: " + replacement + "}")
            node = next(child for name, child in root.value if name.value == "lot")
            return _insert_mapping_entry(text, node, "line_number", replacement)
    if ref in OPTIONAL_STUDY_DATES:
        parent = document.get("study") if isinstance(document, dict) else None
        key = pointer.split("/")[-1]
        if isinstance(parent, dict) and key not in parent:
            if not (parent.get("index_period_start") or parent.get("index_period_end")):
                raise Invalid("Declare a separate enrollment period before adding optional observation dates here.")
            root = yaml.compose(text)
            node = next(child for name, child in root.value if name.value == "study")
            return _insert_mapping_entry(text, node, key, replacement)
    node = _scalar_node(text, pointer.split("/"))
    return text[:node.start_mark.index] + replacement + text[node.end_mark.index:]


def supported_parameters(root, pack):
    """{parameter path: (label, kind, current value)} for the allowlisted settings this product carries.

    Each entry resolves against the product's own YAML, read with the strict loader the
    validators use, so a duplicated key or an impossible date is reported rather than read
    last-wins. A file that fails to parse is an error, never 'no settings': a broken file must
    not silently hide a setting a person expects to change. A missing file or a missing key
    simply means that setting is not offered for this product, except optional LOT
    numbering and observation/cutoff dates for an explicit enrollment period. Their
    displayed values are the engine defaults until explicitly selected for declaration.
    """
    _base, path, _name = dw._pack_path(root, pack)
    documents, result = {}, {}
    for ref, (label, kind) in PARAMETERS.items():
        rel, pointer = ref.split("#/", 1)
        if rel not in documents:
            file = _safe(path / rel)
            documents[rel] = None
            if file.is_file():
                try:
                    documents[rel] = _parameter_document(_read(file).decode("utf-8"), rel)
                except Invalid:
                    raise
                except (yaml.YAMLError, ValueError) as exc:
                    raise Invalid(f"Repair {rel} before proposing changes: {exc}") from exc
        value = documents[rel]
        if ref == LOT_NUMBERING_REF:
            if value is None:
                continue
            parent = _lot_parent(value)
            if "line_number" not in parent:
                if _safe(path / "variables/treatment.yaml").is_file():
                    result[ref] = (label, kind, LOT_NUMBERING_DEFAULT)
                continue
        if ref in OPTIONAL_STUDY_DATES:
            parent = value.get("study") if isinstance(value, dict) else None
            key = pointer.split("/")[-1]
            if isinstance(parent, dict) and (parent.get("index_period_start") or parent.get("index_period_end")):
                if isinstance(parent.get(key), (dict, list)):
                    raise Invalid(f"Repair config/data_product.yaml: study.{key} must be a scalar date.")
                if not parent.get(key):
                    inherited = OPTIONAL_STUDY_DATES[ref](parent)
                    if inherited is not None and inherited != "":
                        result[ref] = (label + " (inherited; select to declare explicitly)", kind, str(inherited))
                    continue
        for key in pointer.split("/"):
            value = value.get(key) if isinstance(value, dict) else None
        if value is None or isinstance(value, (dict, list)):
            continue
        legacy = {"study/index_start": "index_period_start", "study/index_end": "index_period_end"}.get(pointer)
        if legacy and (documents[rel].get("study") or {}).get(legacy):
            label += f" (legacy; enrollment uses {legacy})"
        result[ref] = (label, kind, str(value) if isinstance(value, date) else value)
    return result


def applicable(root, pack):
    """Whether to offer the configuration route at all; a page that cannot read the product says why itself."""
    try:
        return bool(supported_parameters(root, pack))
    except (OSError, ValueError, TypeError, UnicodeError, RecursionError):
        return False


def editable_parameters(root, pack):
    parameters = supported_parameters(root, pack)
    if not parameters:
        raise Invalid(NO_SUPPORTED_SETTINGS)
    return [{"ref": ref, "label": label, "kind": kind, "value": value}
            for ref, (label, kind, value) in parameters.items()]


def _value(ref, value):
    kind = PARAMETERS[ref][1]
    if kind == "date":
        if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
            raise Invalid("Study dates must be explicit YYYY-MM-DD values.")
        try:
            date.fromisoformat(value)
        except ValueError as exc:
            raise Invalid("Study dates must be real calendar dates in YYYY-MM-DD form.") from exc
    elif kind == "integer":
        if type(value) is not int or value < 0:
            raise Invalid("Day windows must be non-negative whole numbers.")
    elif kind == "positive_integer":
        if type(value) is not int or value < 1:
            raise Invalid("Maximum treatment line must be a positive whole number.")
    elif kind == "lot_numbering":
        if not isinstance(value, str) or value not in LOT_NUMBERING_CHOICES:
            raise Invalid("Treatment line numbering must be linenumber or new_lot_n.")
    elif kind == "text":
        if not isinstance(value, str) or not TEXT_NAME.fullmatch(value.strip()) or "REPLACE_ME" in value:
            raise Invalid("A schema or cut name uses letters, digits, underscores, dots or hyphens, up to 80 characters.")
        return value.strip()
    elif type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
        raise Invalid("Days per month must be a finite positive number.")
    return value


def _cohort_text(value, label, *, identifier=False):
    if (not isinstance(value, str) or not value.strip() or len(value) > 250
            or any(ord(char) < 32 for char in value)
            or (identifier and not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", value))):
        raise Invalid(f"{label} must be a nonempty {'identifier' if identifier else 'text label'} without control characters.")


def _cohort_context(document):
    """The current declared basis, usable on saved review bytes without disk reads."""
    if not isinstance(document, dict):
        raise Invalid("Repair config/data_product.yaml: the cohort configuration must be a mapping.")
    condition = document.get("condition_class", "oncology")
    general = condition == "non_oncology"
    cohorts, models = document.get("cohorts"), document.get("index_dates")
    if not isinstance(cohorts, list) or not cohorts or len(cohorts) > 200 or not all(isinstance(c, dict) for c in cohorts):
        if general and cohorts == []:
            raise Invalid("This independent product has no cohort yet. Link its delivered source columns in Sources, "
                          "then prepare and review the initial cohort and index_date configuration. "
                          "No patient population or clinical index is inferred from another product.")
        raise Invalid("Prepare a nonempty list of existing cohorts before using the cohort editor.")
    if not isinstance(models, dict) or not models or len(models) > 200:
        raise Invalid("Prepare the existing index-date models before using the cohort editor.")
    sources = document.get("sources")
    formats, run, study, lot = (document.get(key, {}) for key in ("formats", "run", "study", "lot"))
    if not isinstance(sources, dict) or any(not isinstance(value, dict) for value in (formats, run, study, lot)):
        raise Invalid("Repair sources, formats, run, study and lot as mappings before editing cohorts.")
    data_format = run.get("data_format") or document.get("data_format") or "EDM"
    if not isinstance(data_format, str):
        raise Invalid("Repair the declared data format before editing cohorts.")
    overlay = formats.get(data_format, {})
    if not isinstance(overlay, dict) or not isinstance(overlay.get("sources", {}), dict):
        raise Invalid("Repair the selected format's source mapping before editing cohorts.")
    sources = {**sources, **overlay.get("sources", {})}
    primary_name = "index_date" if general else "advanced_diagnosis_date"
    primary = models.get(primary_name, {})
    if not isinstance(primary, dict):
        raise Invalid(f"The {primary_name} index model must be a mapping.")
    index_source = primary.get("source", "" if general else "enhanced")
    _cohort_text(index_source, "Index source", identifier=True)
    if index_source not in sources:
        raise Invalid(f"Index source {index_source} is not declared. Link its source before editing cohorts.")
    columns, settings = set(), set()
    for name, rule in models.items():
        _cohort_text(name, "Index model name", identifier=True)
        if not isinstance(rule, dict) or not isinstance(rule.get("of"), list) or not rule["of"]:
            raise Invalid(f"Index model {name} needs a nonempty list of declared source columns.")
        for column in rule["of"]:
            _cohort_text(column, f"Index model {name} column", identifier=True)
            columns.add(column)
    excluded = lot.get("exclude_settings", [])
    if not isinstance(excluded, list) or len(excluded) > 200:
        raise Invalid("lot.exclude_settings must be a list of declared setting names.")
    for value in [lot.get("line_setting"), *excluded, *(c.get("line_setting") for c in cohorts)]:
        if value is not None:
            _cohort_text(value, "Treatment-line setting")
            settings.add(value)
    if general:
        for cohort in cohorts:
            unsupported = set(cohort) & {"lot_number", "line_setting", "diag", "maintenance", "ecog_line_match"}
            if unsupported or cohort.get("index") == "lot_start_date":
                raise Invalid("non_oncology does not execute treatment-line settings: "
                              + ", ".join(sorted(unsupported) or ["lot_start_date"]))
    for name in ("index_start", "index_end", "index_period_start", "index_period_end", "observation_end", "data_cutoff"):
        value = study.get(name)
        if value not in (None, ""):
            try:
                if isinstance(value, datetime) or date.fromisoformat(str(value)).isoformat() != str(value):
                    raise ValueError()
            except (ValueError, TypeError):
                raise Invalid(f"study.{name} needs a real YYYY-MM-DD date. Resolve it in the study-date settings first.") from None
    start, end = index_period_start(study), index_period_end(study)
    if not start or not end:
        raise Invalid("Declare both enrollment dates in the study-date settings before editing cohorts.")
    from experiments.portal.variable_execution_rules import study_date_issues
    date_issues = study_date_issues(study)
    if date_issues:
        raise Invalid(" ".join(date_issues))
    return {"cohorts": deepcopy(cohorts), "index_dates": deepcopy(models), "index_source": index_source,
            "index_columns": sorted(columns), "line_settings": sorted(settings - set(excluded)),
            "global_excluded_settings": sorted(set(excluded)), "has_lot": not general and "lot" in sources,
            "condition_class": condition,
            "study": deepcopy(study), "start": str(start), "end": str(end)}


def _validate_cohort_blocks(before, after):
    """Validate the proposed pair together; no independent source or episode inference."""
    basis = _cohort_context(before)
    proposed = _cohort_context(after)
    old_cohorts, cohorts = basis["cohorts"], proposed["cohorts"]
    models, old_models = proposed["index_dates"], basis["index_dates"]
    if set(models) != set(old_models):
        raise Invalid("This editor changes existing index models only. Keep their IDs; request a reviewed implementation change to add or remove a model.")
    materialized = set()
    for name, rule in models.items():
        unknown = set(rule) - {"method", "of", "source"}
        if unknown or rule.get("method", "max") != "max":
            raise Invalid(f"Index model {name} supports only method max over declared source columns. Other keys or earliest-event rules need an implementation review.")
        native_name = name.replace("_", "").casefold()
        if native_name in materialized:
            raise Invalid("Index model names collide after the engine removes underscores. Reconcile these models before editing.")
        materialized.add(native_name)
        if ("source" in rule, rule.get("source")) != ("source" in old_models[name], old_models[name].get("source")):
            raise Invalid(f"Preserve index model {name}'s source declaration. New sources need a separate reviewed source mapping.")
        if rule.get("source", basis["index_source"]) != basis["index_source"]:
            raise Invalid(f"Index model {name} must use the shared index source {basis['index_source']}; independent per-model sources are not executed.")
        columns = rule["of"]
        if (len(columns) > 200 or len({c.casefold() for c in columns}) != len(columns)
                or any(c not in basis["index_columns"] for c in columns)):
            raise Invalid(f"Index model {name}: choose each currently declared index source column at most once. New columns require source review first.")
    from engine.validate import COHORT_KEYS, COHORT_TYPES
    def identities(rows):
        result, codes, labels = {}, set(), set()
        for cohort in rows:
            for required in ("id", "label", "cohortn", "index"):
                if required not in cohort:
                    raise Invalid(f"Each cohort needs {required}. Repair the existing cohort definition first.")
            unknown = set(cohort) - COHORT_KEYS
            if unknown:
                raise Invalid("Unsupported cohort field(s): " + ", ".join(sorted(map(str, unknown))) + ". Patient eligibility expressions are not base-cohort settings.")
            for key, kind in COHORT_TYPES.items():
                if key not in cohort:
                    continue
                value = cohort[key]
                if kind == "str":
                    _cohort_text(value, f"Cohort {key}", identifier=key in {"id", "index", "diag"})
                elif (kind == "bool" and type(value) is not bool) or (kind == "int" and (type(value) is not int or value < 1)):
                    raise Invalid(f"Cohort {key} must be {'true or false' if kind == 'bool' else 'a positive whole number'}.")
            cid, number, label = cohort["id"], cohort["cohortn"], cohort["label"].strip().casefold()
            if cid.casefold() in {key.casefold() for key in result} or number in codes or label in labels:
                raise Invalid("Each cohort needs a unique ID, numeric code and label.")
            result[cid] = number
            codes.add(number)
            labels.add(label)
        return result
    if identities(old_cohorts) != identities(cohorts):
        raise Invalid("This editor preserves existing cohort IDs and numeric codes. Additions, removals or renumbering require a separate reviewed implementation change.")
    previous_by_id = {c["id"]: c for c in old_cohorts}
    for cohort in cohorts:
        cid = cohort["id"]
        if "eligibility" in cohort:
            from engine.sql_expressions import eligibility_errors
            failures = eligibility_errors(cohort["eligibility"], where=f"Cohort {cid} eligibility")
            if failures:
                raise Invalid(" ".join(failures))
        if "lot_number" in cohort:
            if not basis["has_lot"]:
                raise Invalid(f"Cohort {cid} needs a declared lot source before choosing a treatment-line index.")
            if cohort["index"] != "lot_start_date":
                raise Invalid(f"Cohort {cid}: a treatment line uses index lot_start_date. Choose its diagnosis model separately.")
            if cohort.get("diag", "advanced_diagnosis_date") not in models:
                raise Invalid(f"Cohort {cid}: select a declared diagnosis model for its enrollment check.")
            selected_setting = cohort.get("line_setting", (before.get("lot") or {}).get("line_setting"))
            old = previous_by_id[cid]
            old_setting = old.get("line_setting", (before.get("lot") or {}).get("line_setting"))
            if selected_setting in basis["global_excluded_settings"] and ("lot_number" not in old or selected_setting != old_setting):
                raise Invalid(f"Cohort {cid}: setting {selected_setting} is excluded by the global treatment-line rule. Choose another setting or review that exclusion separately.")
        else:
            if cohort["index"] not in models:
                raise Invalid(f"Cohort {cid}: choose an existing index-date model, or declare a treatment line with lot_number.")
            if any(key in cohort for key in ("diag", "maintenance")) or cohort.get("ecog_line_match"):
                raise Invalid(f"Cohort {cid}: diagnosis-line matching and maintenance apply to treatment-line cohorts only. Preserve this advanced rule outside the simple cohort editor.")
    return proposed


def _cohort_product_document(path):
    """Keep the cohort review basis self-contained in its candidate file.

    The engine merges pipeline.yaml. A delivery format declared only there can
    select a different source overlay from the reviewed product bytes; refuse
    that advanced case instead of displaying one source and executing another.
    """
    file = _safe(path / "config/data_product.yaml")
    cfg = load_config(file)
    document = _parse(_read(file).decode("utf-8"))
    run = document.get("run") or {}
    declared_format = run.get("data_format") or document.get("data_format") or "EDM"
    if cfg.data_format != declared_format:
        raise Invalid(
            "The cohort editor cannot use this external data-format override: "
            f"config/pipeline.yaml selects {cfg.data_format}, while config/data_product.yaml selects {declared_format}. "
            "Ask the data expert to reconcile run.data_format and data_format in those files through configuration review, then reopen this editor.")
    for key in ("cohorts", "index_dates", "sources", "formats", "study", "lot"):
        if cfg.raw.get(key) != document.get(key):
            raise Invalid(f"The cohort editor requires {key} in config/data_product.yaml. "
                          "Ask the data expert to reconcile its config/pipeline.yaml declaration through configuration review first.")
    return document


def cohort_editor(root, pack):
    """Current declared choices only; does not inspect data or guess date columns."""
    _base, path, _name = dw._pack_path(root, pack)
    document = _cohort_product_document(path)
    result = _validate_cohort_blocks(document, document)
    result["eligibility_fields"] = eligibility_fields(root, pack)
    return result


def eligibility_fields(root, pack):
    """Declared single-column outputs; no cross-product name/type inference."""
    _base, path, _name = dw._pack_path(root, pack)
    return _eligibility_fields(path)


def _eligibility_fields(path, document=None):
    from engine.validate import emitted_variables
    cfg = load_config(_safe(path / "config/data_product.yaml"))
    emitted = emitted_variables(cfg) | {"index_date", "patientid", "cohortn", "cohortun"}
    # The catalogue inventories labels. Its declared numeric companions follow
    # the same convention used by contract_binding, with the two native label
    # names that end in "l" rather than their code stem handled explicitly.
    companions = {name + "n" for name in emitted if isinstance(name, str)}
    companions.update(code for label, code in (("agegrl", "agegrn"), ("regionl", "regionn")) if label in emitted)
    kinds = {"int": "integer", "integer": "integer", "long": "integer", "bigint": "integer",
             "double": "number", "float": "number", "numeric": "number", "number": "number",
             "string": "string", "str": "string", "date": "date", "bool": "boolean", "boolean": "boolean"}
    result = {"index_date": {"type": "date", "label": "Cohort index date", "values": []}}
    contract = _safe(path / "handoff/FUNCTIONAL_CONTRACT.md")
    if contract.is_file():
        for record in dw.cl.typed_records(dw.cl.read(str(contract))):
            names = record.physical_names()
            kind = kinds.get(str(record.output.get("type", "")).strip(" \"'").lower())
            if len(names) == 1 and kind and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", names[0]):
                result[names[0]] = {"type": kind, "label": record.variable_id, "values": []}
    document = document if document is not None else cfg.raw
    overlay = document.get("dictionary_overlay") or {}
    for item in overlay.get("variables") or []:
        if not isinstance(item, dict):
            continue
        name, kind = item.get("code"), kinds.get(item.get("data_type"))
        if isinstance(name, str) and kind and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", name):
            codes = item.get("codes") or []
            result[name] = {"type": kind, "label": item.get("label", name),
                            "values": [entry["code"] for entry in codes if isinstance(entry, dict) and "code" in entry]}
    return {name: info for name, info in result.items() if name in emitted or name in companions}


def _validate_eligibility_fields(path, document):
    cohorts = document.get("cohorts") or []
    if not any("eligibility" in cohort for cohort in cohorts):
        return
    from engine.sql_expressions import eligibility_plan
    fields = _eligibility_fields(path, document)
    for cohort in cohorts:
        if "eligibility" not in cohort:
            continue
        try:
            plan = eligibility_plan(cohort["eligibility"], available=fields)
        except (ValueError, TypeError, OverflowError) as exc:
            raise Invalid(f"Cohort {cohort['id']}: {exc}") from exc
        for name, kind in plan["columns"].items():
            if kind != fields[name]["type"]:
                raise Invalid(f"Cohort {cohort['id']}: eligibility type for {name} must be {fields[name]['type']}, "
                              "matching its current variable definition. Review the output type first.")


def cohort_changes(root, pack, cohorts, index_dates):
    _base, path, _name = dw._pack_path(root, pack)
    before = _cohort_product_document(path)
    document = deepcopy(before)
    document.update(cohorts=deepcopy(cohorts), index_dates=deepcopy(index_dates))
    _validate_cohort_blocks(before, document)
    _validate_eligibility_fields(path, document)
    return [{"ref": "config/data_product.yaml#/" + key, "value": deepcopy(document[key])}
            for key in ("cohorts", "index_dates") if document[key] != before.get(key)]


def _patch_cohort_block(text, ref, value):
    if ref not in COHORT_REFS:
        raise Invalid("This configuration block has no supported cohort editor.")
    _encode(value)
    key = ref.split("#/", 1)[1]
    document = _parse(text)
    if type(value) is not (list if key == "cohorts" else dict):
        raise Invalid(f"{key} has the wrong structure for the cohort editor.")
    if document.get(key) == value:
        return text
    # Only the declared top-level block is replaced. Adjacent YAML retains its
    # exact bytes; the pair is validated once after all requested edits compose.
    tree = yaml.compose(text)
    selected = next(((k, v) for k, v in tree.value if k.value == key), None)
    if selected is None:
        raise Invalid(f"The current product has no {key} block. Prepare it through an implementation review first.")
    key_node, value_node = selected
    replacement = yaml.safe_dump({key: value}, sort_keys=False, allow_unicode=True)
    newline = "\r\n" if "\r\n" in text else "\n"
    replacement = replacement.replace("\n", newline)
    return text[:key_node.start_mark.index] + replacement + text[value_node.end_mark.index:]


def _patch_clinical_block(text, ref, value):
    """Replace one compiler-owned block; unrelated configuration stays intact.

    Admission to staging also requires the complete current review binding and
    byte-equivalent recompilation. This function alone grants no execution right.
    """
    if ref not in REVIEWED_BLOCK_REFS:
        raise Invalid("This configuration block has no reviewed typed editor.")
    def bounded(item, depth=0):
        if depth > 32:
            raise Invalid("The clinical configuration is nested too deeply.")
        if isinstance(item, dict):
            if len(item) > 2000 or any(not isinstance(key, str) for key in item):
                raise Invalid("Clinical settings need bounded mappings with text keys.")
            for key, child in item.items():
                bounded(key, depth + 1)
                bounded(child, depth + 1)
        elif isinstance(item, list):
            if len(item) > 2000:
                raise Invalid("Split this clinical configuration into smaller reviews.")
            for child in item:
                bounded(child, depth + 1)
        elif isinstance(item, str):
            if len(item) > 65536 or any(ord(char) < 32 and char not in "\n\r\t" for char in item):
                raise Invalid("A clinical setting has invalid text.")
        elif type(item) is float and not math.isfinite(item):
            raise Invalid("Clinical settings require finite numbers.")
        elif type(item) not in (bool, int, float, type(None)):
            raise Invalid("Clinical settings must contain literal values.")
    bounded(value)
    expected = list if ref.endswith("/categoricals") or ref in NATIVE_INSTRUMENT_REFS else dict
    if not isinstance(value, expected):
        raise Invalid("The clinical configuration block has the wrong structure.")
    _encode(value)
    if ref == DICTIONARY_REF:
        from engine.product_catalog import validate_overlay
        value = validate_overlay(value)
    document = _parameter_document(text, ref.split("#", 1)[0])
    if not isinstance(document, dict):
        raise Invalid("Clinical configuration must be a YAML mapping.")
    key = ref.split("#/", 1)[1]
    if document.get(key) == value:
        return text
    document[key] = deepcopy(value)
    return yaml.safe_dump(document, sort_keys=False, allow_unicode=True)


def _compose(path, changes):
    if not isinstance(changes, list) or len(changes) > 100:
        raise Invalid("Supply a list of explicit configuration changes.")
    available = {p["ref"] for p in editable_parameters(path.parents[3], path.relative_to(path.parents[3]).as_posix())}
    originals, proposed, seen, handoff = {}, {}, set(), []
    for change in changes:
        if not isinstance(change, dict) or set(change) != {"ref", "value"} or not isinstance(change["ref"], str):
            raise Invalid("Each configuration change needs only ref and value.")
        ref = change["ref"]
        if ref in seen:
            raise Invalid("List each configuration parameter only once.")
        seen.add(ref)
        if ref not in REVIEWED_BLOCK_REFS | CODELIST_REFS | COHORT_REFS and (ref not in PARAMETERS or ref not in available):
            handoff.append({"kind": "unsupported_configuration", "requested_change": change,
                            "reason": "This setting has no supported explicit editor.",
                            "required_work": "Establish specification references, declared consumers and an engine-supported implementation before proposing a configuration patch."})
            continue
        value = change["value"] if ref in REVIEWED_BLOCK_REFS | CODELIST_REFS | COHORT_REFS else _value(ref, change["value"])
        rel, pointer = ref.split("#/", 1)
        if rel not in originals:
            originals[rel] = _read(path / rel).decode("utf-8")
            proposed[rel] = originals[rel]
        text = proposed[rel]
        if ref in CODELIST_REFS:
            cfg = load_config(path / "config/data_product.yaml")
            if cfg.raw.get("codelists", {}).get("treatment_categories") != rel:
                raise Invalid("This product does not execute the standard treatment code-list file. Ask the data expert to reconcile its codelist binding.")
            proposed[rel] = _patch_codelist(text, value)
            from engine.validate import _codelist_problems
            cfg._codelists = {"treatment_categories": _parse(proposed[rel])}
            errors = _codelist_problems(cfg)
            if errors:
                raise Invalid(" ".join(errors))
        elif ref in COHORT_REFS:
            proposed[rel] = _patch_cohort_block(text, ref, value)
        else:
            proposed[rel] = (_patch_clinical_block(text, ref, value) if ref in REVIEWED_BLOCK_REFS
                         else _patch_parameter(text, ref, value))
        parsed = _parse(proposed[rel])
        for key in ([] if ref in CODELIST_REFS else pointer.split("/")):
            parsed = parsed.get(key) if isinstance(parsed, dict) else None
        if parsed != value or type(parsed) is not type(value):
            raise Invalid("The proposed value did not survive configuration read-back.")
    files = []
    config_text = proposed.get("config/data_product.yaml")
    if config_text and seen & COHORT_REFS:
        _cohort_product_document(path)
        _validate_cohort_blocks(_parse(originals["config/data_product.yaml"]), _parse(config_text))
        _validate_eligibility_fields(path, _parse(config_text))
    date_keys = {"index_start", "index_end", "index_period_start", "index_period_end", "observation_end", "data_cutoff"}
    if config_text and any(ref == "config/data_product.yaml#/study/" + name for ref in seen for name in date_keys):
        from experiments.portal.variable_execution_rules import study_date_issues
        study = _parse(config_text).get("study") or {}
        before = _parse(originals["config/data_product.yaml"]).get("study") or {}
        issues = study_date_issues(study, before=before)
        if issues:
            raise Invalid(" ".join(issues))
    for rel, after in proposed.items():
        before = originals[rel]
        if before == after:
            continue
        files.append({"path": rel, "before": before, "after": after,
                      "diff": "".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                      fromfile="a/" + rel, tofile="b/" + rel)),
                      "semantic_diff": config_diff.diff_docs(_parse(before), _parse(after))})
    return files, handoff


def _patch_codelist(text, value):
    from experiments.portal.treatment_codelist_rules import validate
    try:
        document = validate(value, before=_parse(text))
    except ValueError as exc:
        raise Invalid(str(exc)) from exc
    return yaml.safe_dump(document, sort_keys=False, allow_unicode=True)


def _brief(description, brief):
    if not isinstance(brief, dict) or brief.get("pack") != description["pack"]:
        raise Invalid("The revision brief belongs to a different product.")
    if brief.get("baseline_sha256") != description["baseline_sha256"]:
        raise Invalid("The revision brief is stale. Rebuild it from the current product.")
    source = (brief.get("source") or {}).get("proposed") or {}
    inputs = dw._inputs({"retained": brief.get("kept"), "additions": brief.get("added"),
                         "purpose": brief.get("purpose"), "studies": brief.get("studies"),
                         "target_source": source.get("vendor"), "target_modality": source.get("modality")})
    plan = dw.build_plan(description, **inputs)
    if brief.get("removed") != plan["removed"]:
        raise Invalid("The brief selections do not match the current contract.")
    return plan


def _plan_errors(plan):
    # A configuration-only brief (including an empty scaffold contract) can be
    # staged without inventing a new scientific definition. Removed dependencies
    # are assessed against shared changes and each study's actual exclusions.
    ignored = {"No product change is selected. Add or remove a definition, or propose a different source.",
               "Keep or propose at least one definition so the planned product is not empty."}
    return [error for error in plan["errors"] if error not in ignored and "depends on removed variable(s):" not in error]


def _exclusions(plan, exclusions):
    if not isinstance(exclusions, list) or len(exclusions) > 1000:
        raise Invalid("Study exclusions must be a list, separate from shared-product changes.")
    result, seen = [], set()
    for row in exclusions:
        if not isinstance(row, dict) or set(row) != {"study", "variables"}:
            raise Invalid("Each study-only exclusion needs study and variables.")
        study, variables = row["study"], row["variables"]
        if not isinstance(study, str) or study not in plan["studies"] or study in seen:
            raise Invalid("Name each exclusion study once in the brief's intended studies.")
        if (not isinstance(variables, list) or not all(isinstance(v, str) for v in variables)
                or len(set(variables)) != len(variables) or not set(variables) <= set(plan["removed"])):
            raise Invalid("Study-only exclusions must identify removed variables from this brief exactly once.")
        if variables:
            result.append({"study": study, "variables": variables})
        seen.add(study)
    return result


def _impact(base, path, plan, changes, exclusions):
    records = list(dw.cl.typed_records(dw.cl.read(str(path / "handoff/FUNCTIONAL_CONTRACT.md"))))
    by_id = {r.variable_id: r for r in records}
    refs = {c["ref"] for c in changes if c["ref"] in PARAMETERS or c["ref"] in REVIEWED_BLOCK_REFS | CODELIST_REFS | COHORT_REFS}
    excluded = {v for row in exclusions for v in row["variables"]}
    shared_removed = [v for v in plan["removed"] if v not in excluded]
    # Cohort membership and index anchors affect the population and timing of
    # every output, including records without a sufficiently detailed binding.
    direct = set(by_id) if plan["source_changed"] or refs & COHORT_REFS else set(shared_removed)
    for record in records:
        if any(ref == binding or ref.startswith(binding + "/") or
               (ref in COHORT_REFS and binding.startswith(ref + "/")) or
               (ref in CODELIST_REFS and binding.split("#/", 1)[0] == ref.split("#/", 1)[0])
               for ref in refs for binding in record.implementation_refs or []):
            direct.add(record.variable_id)
    affected = set(direct)
    while True:
        more = {r.variable_id for r in records if set(r.depends_on) & affected}
        if more <= affected:
            break
        affected.update(more)
    dependencies = [{"variable_id": r.variable_id, "depends_on": [d for d in r.depends_on if d != "none"],
                     "dependencies_declared": dw.cl._list(r.raw, "depends_on") is not None}
                    for r in records if r.variable_id in affected]
    errors, consumers = [], []
    # The canonical convenience reader skips corrupt pins. Surface that uncertainty
    # before using it, so an unreadable consumer can never mean 'no consumers'.
    for study in study_pin.studies(str(base)):
        _doc, error = study_pin.load(study, str(base))
        if error:
            errors.append(f"Declared consumer {study} could not be read: {error}")
    for row in study_pin.pins_for_product(plan["pack"], str(base)):
        consumers.append({key: value for key, value in row.items() if key not in {"pinned_by", "pinned_date"}})
    # Registry citations are also declared consumers even before a PINS file exists.
    registry, err = dw.pg.read_yaml(str(base / "products/registry.yaml")) if (base / "products/registry.yaml").exists() else ({}, None)
    if err:
        errors.append("The consumer registry could not be read: " + str(err))
    slug, version = plan["pack"].split("/")[-2:]
    registry_consumers = []
    for entry in (registry or {}).get("work", []) if isinstance(registry, dict) else []:
        if isinstance(entry, dict) and any(isinstance(c, dict) and str(c.get("product")) == slug and str(c.get("spec_version")) == version for c in entry.get("cites_release") or []):
            registry_consumers.append({"study": entry.get("id"), "cites_release": entry["cites_release"]})
    conflicts = []
    for row in exclusions:
        for rec in records:
            missing = sorted(set(rec.depends_on) & set(row["variables"]))
            if rec.variable_id not in row["variables"] and missing:
                conflicts.append({"study": row["study"], "variable_id": rec.variable_id, "missing_dependencies": missing})
    from rwd_tools import change_impact
    capabilities, capability_error = change_impact.capabilities_for(refs)
    notes = ["Impact covers declared metadata only; unrecorded consumers and engine dependencies require engineering review."]
    if not records:
        notes.append("No contract records are declared; variable dependencies and output consumers are not established.")
    if not consumers and not registry_consumers:
        notes.append("No study consumers were found in declared pins or registry citations; this is not proof that no studies are affected.")
    if capability_error:
        notes.append(capability_error)
    return {"direct_variables": sorted(direct), "dependent_variables": sorted(affected - direct),
            "dependencies": dependencies,
            "external_dependencies": sorted({d for r in dependencies for d in r["depends_on"] if d not in by_id}),
            "consumers": consumers, "registry_consumers": registry_consumers, "capabilities": capabilities,
            "shared_removed": shared_removed, "study_dependency_conflicts": conflicts,
            "notes": notes, "errors": errors}


def _engineering_handoff(plan, impact, unsupported):
    handoff = list(unsupported)
    for item in plan["added"]:
        handoff.append({"kind": "new_derivation", **item, "reason": "Scientific text has no supported executable mapping.",
                        "required_work": "Bind specification rows, source fields, dependencies and acceptance examples; implement and review the derivation."})
    for vid in impact["shared_removed"]:
        handoff.append({"kind": "shared_removal", "variable_id": vid,
                        "reason": "Removing a contract selection does not remove an engine output or its shared configuration block.",
                        "required_work": "Review declared and engine consumers, revise the contract and emitted surface, and produce a reviewed implementation patch."})
    if plan["source_changed"]:
        handoff.append({"kind": "source_change", "source": plan["source"],
                        "reason": "A source name or modality does not establish delivered mappings.",
                        "required_work": "Review the delivery schema, adapters, availability, cohort attrition and source evidence before implementation."})
    return handoff


def _binding_shape(binding):
    if (not isinstance(binding, dict) or set(binding) != {"input_digest", "state_digest"}
            or any(not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value) for value in binding.values())):
        raise Invalid("A variable-review proposal must name the exact reviewed inputs and shared table snapshot.")


def _require_review_binding(base, name, actor_id, binding, allowed_packs):
    if binding is None:
        return
    _binding_shape(binding)
    from experiments.portal import variable_review_workflow as workflow
    report = workflow.describe(base, name, actor_id, allowed_packs=allowed_packs)
    if (not report.get("ok") or report.get("current_phase") != "complete"
            or any(report.get(key) != value for key, value in binding.items())):
        raise Invalid("The reviewed variable tables changed or are incomplete. Reload and complete their reviews before preparing configuration.")
    return report


def _review_handoff(base, path, name, report, changes):
    from experiments.portal import variable_execution_rules
    from experiments.portal import variable_execution_config
    compiled = variable_execution_rules.build(report, variable_execution_config.load(path),
                                               supported_parameters(base, name))
    expected = compiled["configuration_changes"]
    if (not isinstance(changes, list) or any(not isinstance(row, dict) or set(row) != {"ref", "value"}
            or not isinstance(row["ref"], str) for row in changes)
            or _encode(sorted(changes, key=lambda row: row["ref"])) != _encode(sorted(expected, key=lambda row: row["ref"]))):
        raise Invalid("The configuration changes differ from the reviewed variable choices. Reload the execution proposal before staging.")
    return [{"kind": "reviewed_definition", "item_id": row.get("item_id", ""),
        "variable_id": row.get("variable_id", ""), "reason": row["message"],
        "required_work": row.get("required_work") or "Resolve this variable in the reviewed tables or provide a reviewed implementation, then prepare a fresh configuration proposal."}
        for row in compiled["blockers"]]


def _check_review_records(proposal):
    """Literal historical requirements only; no copied identities or approvals."""
    if "variable_review_binding" not in proposal:
        if "variable_review_records" in proposal:
            raise Invalid("Reviewed variable records require their originating review snapshot.")
        return
    records = proposal.get("variable_review_records")
    if not isinstance(records, list) or not 1 <= len(records) <= MAX_REVIEW_RECORDS:
        raise Invalid("The proposal needs its complete, bounded reviewed-variable snapshot. Prepare a fresh proposal.")
    from experiments.portal import scientific_definitions as definitions
    from experiments.portal import variable_review_family

    def literal(value, depth=0):
        if depth > 32:
            raise Invalid("A reviewed-variable snapshot is nested too deeply.")
        if isinstance(value, str):
            if len(value) > 65536 or any(ord(char) < 32 and char not in "\n\r\t" for char in value):
                raise Invalid("A reviewed-variable reference exceeds its text limit or contains control characters.")
        elif isinstance(value, dict):
            if len(value) > 2000 or any(not isinstance(key, str) for key in value):
                raise Invalid("Reviewed-variable fields must be bounded mappings with text keys.")
            for key, child in value.items():
                literal(key, depth + 1)
                literal(child, depth + 1)
        elif isinstance(value, list):
            if len(value) > 2000:
                raise Invalid("A reviewed-variable reference contains too many entries.")
            for child in value:
                literal(child, depth + 1)
        elif type(value) not in (bool, int, float, type(None)):
            raise Invalid("A reviewed-variable snapshot contains an unsupported value.")

    seen = set()
    for row in records:
        if (not isinstance(row, dict) or set(row) - {"clinical_rule"} != set(REVIEW_RECORD_FIELDS)
                or not isinstance(row["definition"], str) or not isinstance(row["spec_values"], dict)
                or not isinstance(row["master_name"], str) or type(row["logic_reviewed"]) is not bool):
            raise Invalid("A reviewed-variable snapshot has unsupported or missing fields.")
        definitions._draft_name(row["item_id"])
        if row["item_id"] in seen:
            raise Invalid("The reviewed-variable snapshot repeats a specification row.")
        seen.add(row["item_id"])
        values = definitions._values(row["values"])
        if any(not isinstance(values.get(key), dict) for key in ("source", "output", "publish")):
            raise Invalid("Reviewed source, output and destination fields must preserve their structured mappings.")
        if row["variable_id"] != values["variable_id"]:
            raise Invalid("A reviewed-variable snapshot names inconsistent variable identifiers.")
        variable_review_family.validate(row["family"])
        if "clinical_rule" in row:
            from experiments.portal import variable_clinical_rules
            variable_clinical_rules.validate(row["clinical_rule"], allow_incomplete=True)
        literal(row)
    _encode(records)  # The same total byte limit as every other proposal artifact.


def _review_records(report):
    records = [{key: deepcopy(row[key]) for key in REVIEW_RECORD_FIELDS} for row in report["rows"]]
    for record, row in zip(records, report["rows"]):
        if row.get("clinical_rule"):
            record["clinical_rule"] = deepcopy(row["clinical_rule"])
    _check_review_records({"variable_review_binding": True, "variable_review_records": records})
    return records


def _recorded_review_handoff(proposal):
    """Branch copies carry historical open work, never a fresh workflow claim."""
    rows = [row for row in proposal["engineering_handoff"] if row.get("kind") == "reviewed_definition"]
    if rows and "variable_review_binding" not in proposal:
        raise Invalid("Reviewed-definition work must identify its originating variable review.")
    if "variable_review_binding" in proposal:
        _binding_shape(proposal["variable_review_binding"])
    _check_review_records(proposal)
    if any(set(row) != {"kind", "item_id", "variable_id", "reason", "required_work"}
           or any(not isinstance(value, str) for value in row.values())
           or not row["reason"] or not row["required_work"] for row in rows):
        raise Invalid("The variable-review engineering handoff is incomplete.")
    records = {row["item_id"]: row["variable_id"] for row in proposal.get("variable_review_records", [])}
    if any((row["item_id"] or row["variable_id"]) and records.get(row["item_id"]) != row["variable_id"] for row in rows):
        raise Invalid("The engineering handoff names a variable absent from its reviewed snapshot.")
    return rows


def _review_binding_stale(base, path, binding):
    _binding_shape(binding)
    from experiments.portal import variable_review_workflow as workflow
    state_path = workflow.definitions._safe(path / workflow.STORE)
    state_digest = workflow.definitions._hash(workflow.definitions._read(state_path)) if state_path.is_file() else ""
    return (state_digest != binding["state_digest"]
            or workflow._input_digest(base, path) != binding["input_digest"])


def stage(root, pack, brief, *, configuration_changes, study_exclusions, actor_id,
          local_demo, can_write, expected_baseline, allowed_packs=None, variable_review_binding=None,
          expected_snapshot=None):
    temporary = None
    try:
        _authorized(local_demo, can_write)
        base, path, name, owner, directory = _store(root, pack, actor_id, allowed_packs)
        description = dw.describe(base, name)
        if description["errors"] or not expected_baseline or expected_baseline != description["baseline_sha256"]:
            raise Invalid("The starting product changed or cannot be read. Reopen it before staging.")
        review_report = _require_review_binding(base, name, actor_id, variable_review_binding, allowed_packs)
        if any(isinstance(change, dict) and change.get("ref") in REVIEWED_BLOCK_REFS for change in configuration_changes) and review_report is None:
            raise Invalid("Clinical rules require the current confirmed variable tables. Prepare them from the variable review dashboard.")
        fingerprint = _snapshot(base, path)
        if expected_snapshot is not None and expected_snapshot != fingerprint:
            raise Invalid("The product changed after you opened the editor. Reload current evidence, review your entries and stage again.")
        plan = _brief(description, brief)
        exclusions = _exclusions(plan, study_exclusions)
        files, handoff = _compose(path, configuration_changes)
        impact = _impact(base, path, plan, configuration_changes, exclusions)
        # Configuration-only and study-only briefs do not need an invented variable.
        errors = _plan_errors(plan)
        if errors:
            raise Invalid(" ".join(errors))
        handoff = _engineering_handoff(plan, impact, handoff)
        if variable_review_binding is not None:
            handoff.extend(_review_handoff(base, path, name, review_report, configuration_changes))
        if not files and not handoff and not exclusions:
            raise Invalid("No configuration change, study-only exclusion or engineering handoff is selected.")
        errors = impact["errors"][:]
        if impact["study_dependency_conflicts"]:
            errors.append("Study-only exclusions leave declared dependent variables in scope. Resolve the study dependency conflicts before submission.")
        identifier = uuid.uuid4().hex
        proposal = {"schema_version": 1, "proposal_id": identifier, "pack": name, "owner": owner,
                    "created_at": datetime.now(timezone.utc).isoformat(), "status": "staged",
                    "draft_only": True, "approved": False, "released": False, "can_submit": False,
                    "baseline_sha256": expected_baseline, "snapshot_sha256": fingerprint,
                    "purpose": plan["purpose"], "brief": plan,
                    "configuration_changes": configuration_changes, "files": files,
                    "study_exclusions": exclusions, "impact": impact, "engineering_handoff": handoff,
                    "errors": errors, "warnings": impact["notes"] + ["A submitted proposal requests local review only. It confers no scientific approval, release, execution or study-pin change."]}
        if variable_review_binding is not None:
            proposal["variable_review_binding"] = dict(variable_review_binding)
            proposal["variable_review_records"] = _review_records(review_report)
        artifacts = {"review.diff": "".join(f["diff"] for f in files).encode("utf-8"),
                     "STUDY_EXCLUSIONS.json": _encode({"draft_only": True, "study_exclusions": exclusions}),
                     "ENGINEERING_HANDOFF.json": _encode({"draft_only": True, "items": handoff})}
        artifacts.update({"candidate/" + f["path"]: f["after"].encode("utf-8") for f in files})
        proposal["artifacts"] = {rel: _digest(data) for rel, data in artifacts.items()}
        proposal["proposal_sha256"] = dw._hash(proposal)
        artifacts["proposal.json"] = _encode(proposal)
        destination = _folder(directory, identifier)
        dw._check_storage_paths([destination / rel for rel in artifacts]
                                + [destination / name for name in ("validation.json", "submission.json", ".receipt-" + "0" * 24)])
        directory.mkdir(parents=True, exist_ok=True)
        temporary = Path(tempfile.mkdtemp(prefix=".staging-", dir=_safe(directory)))
        for rel, data in artifacts.items():
            dest = temporary / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
        if _snapshot(base, path) != fingerprint or dw.describe(base, name)["baseline_sha256"] != expected_baseline:
            raise Invalid("Product or consumer inputs changed during staging. Rebuild the proposal.")
        current_review = _require_review_binding(base, name, actor_id, variable_review_binding, allowed_packs)
        if variable_review_binding is not None and dw._hash(_review_records(current_review)) != dw._hash(proposal["variable_review_records"]):
            raise Invalid("The reviewed variable definitions changed during staging. Prepare a fresh proposal.")
        os.rename(_safe(temporary), destination)
        temporary = None
        return load(base, name, proposal_id=identifier, actor_id=actor_id, allowed_packs=allowed_packs)
    except (OSError, ValueError, TypeError, KeyError, AttributeError, UnicodeError, RecursionError) as exc:
        return _failure(exc)
    finally:
        if temporary is not None and temporary.exists() and temporary.resolve() == temporary and temporary.parent == directory:
            shutil.rmtree(temporary)


def _load(base, path, name, owner, directory, proposal_id):
    folder = _folder(directory, proposal_id)
    proposal = _json(folder / "proposal.json")
    if (not isinstance(proposal, dict) or proposal.get("proposal_id") != proposal_id
            or proposal.get("pack") != name or proposal.get("owner") != owner
            or proposal.get("status") != "staged" or proposal.get("draft_only") is not True
            or proposal.get("approved") is not False or proposal.get("released") is not False
            or proposal.get("proposal_sha256") != dw._hash({k: v for k, v in proposal.items() if k != "proposal_sha256"})):
        raise Invalid("The staged proposal identity or contents changed. Create a fresh proposal.")
    expected = {"review.diff", "STUDY_EXCLUSIONS.json", "ENGINEERING_HANDOFF.json"}
    expected.update("candidate/" + f["path"] for f in proposal["files"])
    if set(proposal["artifacts"]) != expected:
        raise Invalid("The staged proposal artifact list is incomplete.")
    allowed_files = {ref.split("#/", 1)[0] for ref in (*PARAMETERS, *REVIEWED_BLOCK_REFS, *CODELIST_REFS, *COHORT_REFS)}
    if any(f["path"] not in allowed_files for f in proposal["files"]):
        raise Invalid("The proposal contains an unsupported candidate file.")
    for rel, digest in proposal["artifacts"].items():
        if _digest(_read(folder / rel)) != digest:
            raise Invalid("A staged artifact changed. Stage a fresh proposal before validation or submission.")
    for f in proposal["files"]:
        if _read(folder / "candidate" / f["path"]) != f["after"].encode("utf-8"):
            raise Invalid("Candidate bytes differ from the reviewed proposal.")
        if f["path"] == "config/data_product.yaml" and any(c.get("ref") in COHORT_REFS for c in proposal["configuration_changes"]):
            _validate_cohort_blocks(_parse(f["before"]), _parse(f["after"]))
    stale = _snapshot(base, path) != proposal["snapshot_sha256"] or dw.describe(base, name)["baseline_sha256"] != proposal["baseline_sha256"]
    if "variable_review_binding" in proposal:
        _check_review_records(proposal)
        stale = _review_binding_stale(base, path, proposal["variable_review_binding"]) or stale
    elif "variable_review_records" in proposal:
        _check_review_records(proposal)
    return proposal, folder, stale


def _check_validation_consistency(validation):
    """A saved check cannot exempt an engine failure or claim an unfinished run passed."""
    if (not isinstance(validation, dict) or type(validation.get("passed")) is not bool
            or not isinstance(validation.get("checks"), list) or not isinstance(validation.get("errors"), list)):
        raise Invalid("The validation receipt is incomplete. Run the proposal validators again.")
    seen = set()
    for check in validation["checks"]:
        if (not isinstance(check, dict) or not isinstance(check.get("validator"), str) or not check["validator"]
                or check["validator"] in seen or type(check.get("passed")) is not bool
                or type(check.get("completed", True)) is not bool or type(check.get("pre_existing", False)) is not bool
                or not isinstance(check.get("errors"), list)):
            raise Invalid("The saved validator checks are malformed or repeated. Run the proposal validators again.")
        seen.add(check["validator"])
        if check["passed"] and (check.get("completed") is False or check["errors"]):
            raise Invalid("A failed or unfinished validator cannot be reported as passed. Run the proposal validators again.")
        if check.get("pre_existing") is True and (check["validator"] not in PRE_EXISTING_EXEMPT
                or check.get("completed") is False or check["passed"]):
            raise Invalid("Only completed existing scientific findings can be carried as caveats; strict engine validation cannot be exempted. Run the proposal validators again.")
    if seen - REQUIRED_VALIDATORS:
        raise Invalid("The saved checks name an unsupported validator. Run the proposal validators again.")
    if validation["passed"] and (seen != REQUIRED_VALIDATORS or validation["errors"] or
            not all(check["passed"] or check.get("pre_existing") is True for check in validation["checks"])):
        raise Invalid("The saved validation does not contain all required passing checks. Run the proposal validators again.")


def _read_receipt(file, proposal):
    record = _json(file)
    if (not isinstance(record, dict) or record.get("proposal_sha256") != proposal["proposal_sha256"]
            or record.get("receipt_sha256") != dw._hash({k: v for k, v in record.items() if k != "receipt_sha256"})):
        raise Invalid("The proposal receipt changed or belongs to different candidate bytes.")
    if file.name == "submission.json" and (
            record.get("status") != "submitted_for_review" or record.get("draft_only") is not True
            or record.get("approved") is not False or record.get("released") is not False
            or record.get("proposal_id") != proposal["proposal_id"]):
        raise Invalid("A proposal receipt can record a review request only, never approval or release.")
    if file.name == "submission.json" and "request_id" in record and (
            not isinstance(record["request_id"], str) or not re.fullmatch(r"[0-9a-f]{32}", record["request_id"])):
        raise Invalid("The submission receipt names a review request that cannot exist.")
    validation = record.get("validation") if file.name == "submission.json" else record
    _check_validation_consistency(validation)
    if validation.get("proposal_sha256") != proposal["proposal_sha256"] or (
            file.name == "submission.json" and validation["passed"] is not True):
        raise Invalid("A submission receipt requires passing validation of these exact proposal bytes.")
    return record


def load(root, pack, *, proposal_id, actor_id, allowed_packs=None):
    try:
        base, path, name, owner, directory = _store(root, pack, actor_id, allowed_packs)
        proposal, folder, stale = _load(base, path, name, owner, directory, proposal_id)
        validation, validation_error = None, ""
        if (folder / "validation.json").exists():
            try:
                validation = _read_receipt(folder / "validation.json", proposal)
            except (ValueError, TypeError, KeyError, AttributeError, UnicodeError, RecursionError) as exc:
                # Keep the immutable proposal and its existing revalidation
                # action reachable. The invalid receipt is preserved until an
                # explicit fresh validator run replaces it; it confers no state.
                validation_error = str(exc)
        submission = _read_receipt(folder / "submission.json", proposal) if (folder / "submission.json").exists() else None
        can_submit = bool(validation and validation.get("passed") is True and not stale and not submission
                          and not proposal["errors"] and not proposal["engineering_handoff"])
        return {"ok": True, "proposal_id": proposal_id, "proposal_sha256": proposal["proposal_sha256"],
                "path": folder.relative_to(base).as_posix(), "proposal": proposal, "stale": stale,
                "validation": validation, "submission": submission, "can_submit": can_submit,
                "validation_error": validation_error,
                "review_request": (submission or {}).get("request_id"), "errors": []}
    except (OSError, ValueError, TypeError, KeyError, AttributeError, UnicodeError, RecursionError) as exc:
        return _failure(exc)


def list_proposals(root, pack, *, actor_id, allowed_packs=None):
    try:
        base, path, name, owner, directory = _store(root, pack, actor_id, allowed_packs)
        proposals, errors = [], []
        if directory.exists():
            for folder in sorted(directory.iterdir()):
                if not re.fullmatch(r"[0-9a-f]{32}", folder.name):
                    continue
                result = load(base, name, proposal_id=folder.name, actor_id=actor_id, allowed_packs=allowed_packs)
                if result["ok"]:
                    proposals.append({"proposal_id": folder.name, "purpose": result["proposal"]["purpose"],
                                      "created_at": result["proposal"]["created_at"], "stale": result["stale"]})
                else:
                    errors.extend(result["errors"])
        return {"ok": True, "proposals": sorted(proposals, key=lambda p: p["created_at"], reverse=True), "errors": errors}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError) as exc:
        return {**_failure(exc), "proposals": []}


def _share_ingress(value):
    # Scan the complete selected packet before preview/persistence, never an excerpt.
    from experiments.portal import scientific_definition_ai as ai
    _encode(value)  # Retain the complete artifact size and serialization checks.
    # Scan decoded fields: JSON quoting hides identifier labels and its wrapper
    # commas can make multiline configuration look like rows of patient data.
    ai._ingress(ai._plain(value))


def _shared_file(path, packet_id):
    if not isinstance(packet_id, str) or not re.fullmatch(r"[a-f0-9]{32}", packet_id):
        raise Invalid("Choose an existing branch proposal handoff.")
    return _safe(path / SHARED_FOLDER / (packet_id + ".json"))


def _shared_inputs(proposal):
    plan = proposal["brief"]
    source = plan["source"]["proposed"]
    return dw._inputs({"retained": plan["kept"], "additions": plan["added"], "purpose": plan["purpose"],
        "studies": plan["studies"], "target_source": source["vendor"], "target_modality": source["modality"]})


def _branch_text_baseline(base, path, name):
    entry = dw.pg.registry_entry(str(base), name) or {}
    return dw._hash(dw._baseline(path, name, entry if isinstance(entry, dict) else {}, branch_text=True))


def _branch_text(value):
    if isinstance(value, str):
        return value.replace("\r\n", "\n")
    if isinstance(value, dict):
        return {key: _branch_text(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_branch_text(item) for item in value]
    return value


def _check_shared(packet, name):
    if (not isinstance(packet, dict) or set(packet) != {"schema_version", "packet_id", "pack", "proposal", "validation", "historical_submission", "notice", "digest", "baseline_text_sha256"}
            or packet["schema_version"] != 1 or packet["pack"] != name
            or not re.fullmatch(r"[a-f0-9]{64}", str(packet["baseline_text_sha256"]))
            or packet["digest"] != dw._hash({k: v for k, v in packet.items() if k != "digest"})):
        raise Invalid("The branch proposal handoff is unreadable or changed.")
    proposal = packet["proposal"]
    if (not isinstance(proposal, dict) or proposal.get("pack") != name or proposal.get("status") != "staged"
            or proposal.get("draft_only") is not True or proposal.get("approved") is not False or proposal.get("released") is not False
            or not re.fullmatch(r"[a-f0-9]{32}", str(proposal.get("proposal_id", "")))
            or proposal.get("proposal_sha256") != dw._hash({k: v for k, v in proposal.items() if k != "proposal_sha256"})):
        raise Invalid("The shared proposal must preserve its exact unapproved draft snapshot.")
    _shared_inputs(proposal)
    _recorded_review_handoff(proposal)
    if proposal.get("purpose") != proposal["brief"].get("purpose"):
        raise Invalid("The shared purpose differs from its declared planning inputs.")
    _exclusions(proposal["brief"], proposal["study_exclusions"])
    changes = proposal["configuration_changes"]
    if (not isinstance(changes, list) or len(changes) > 100
            or any(not isinstance(c, dict) or set(c) != {"ref", "value"} or not isinstance(c["ref"], str) for c in changes)
            or len({c["ref"] for c in changes}) != len(changes)):
        raise Invalid("The shared handoff has inconsistent setting selections.")
    files = proposal["files"]
    allowed = {ref.split("#/", 1)[0] for ref in (*PARAMETERS, *REVIEWED_BLOCK_REFS, *CODELIST_REFS, *COHORT_REFS)}
    if (not isinstance(files, list) or len(files) > len(allowed)
            or any(not isinstance(f, dict) or set(f) != {"path", "before", "after", "diff", "semantic_diff"}
                   or f["path"] not in allowed or any(not isinstance(f[k], str) for k in ("before", "after", "diff")) for f in files)
            or len({f["path"] for f in files}) != len(files)):
        raise Invalid("The shared handoff names unsupported or duplicate configuration files.")
    # A rehashed foreign packet is untrusted input. Prove each displayed candidate
    # is exactly its declared allowlisted scalar edits, without writing its paths.
    for file in files:
        after = file["before"]
        for change in changes:
            ref = change["ref"]
            if ref in REVIEWED_BLOCK_REFS and ref.split("#/", 1)[0] == file["path"]:
                if "variable_review_binding" not in proposal:
                    raise Invalid("Clinical settings require their originating reviewed-variable snapshot.")
                after = _patch_clinical_block(after, ref, change["value"])
            elif ref in CODELIST_REFS and ref.split("#/", 1)[0] == file["path"]:
                after = _patch_codelist(after, change["value"])
            elif ref in COHORT_REFS and ref.split("#/", 1)[0] == file["path"]:
                after = _patch_cohort_block(after, ref, change["value"])
            elif ref in PARAMETERS and ref.split("#/", 1)[0] == file["path"]:
                value = _value(ref, change["value"])
                after = _patch_parameter(after, ref, value)
        if file["path"] == "config/data_product.yaml" and any(c["ref"] in COHORT_REFS for c in changes):
            _validate_cohort_blocks(_parse(file["before"]), _parse(after))
        expected_diff = "".join(difflib.unified_diff(file["before"].splitlines(True), after.splitlines(True),
            fromfile="a/" + file["path"], tofile="b/" + file["path"]))
        if (after == file["before"] or after != file["after"] or expected_diff != file["diff"]
                or _encode(config_diff.diff_docs(_parse(file["before"]), _parse(after))) != _encode(file["semantic_diff"])):
            raise Invalid("The shared candidate does not match its declared supported settings.")
    artifacts = {"review.diff": _digest("".join(f["diff"] for f in files).encode()),
        "STUDY_EXCLUSIONS.json": _digest(_encode({"draft_only": True, "study_exclusions": proposal["study_exclusions"]})),
        "ENGINEERING_HANDOFF.json": _digest(_encode({"draft_only": True, "items": proposal["engineering_handoff"]}))}
    artifacts.update({"candidate/" + f["path"]: _digest(f["after"].encode()) for f in files})
    if artifacts != proposal["artifacts"]:
        raise Invalid("The shared proposal artifacts differ from the reviewed snapshot.")
    validation = packet["validation"]
    if validation is not None and (not isinstance(validation, dict)
            or validation.get("proposal_sha256") != proposal["proposal_sha256"]
            or validation.get("receipt_sha256") != dw._hash({k: v for k, v in validation.items() if k != "receipt_sha256"})):
        raise Invalid("Historical validation does not belong to this proposal.")
    if validation is not None:
        _check_validation_consistency(validation)
    history = packet["historical_submission"]
    if history is not None and (not isinstance(history, dict) or set(history) != {"request_id", "submitted_at", "receipt_sha256"}
            or not re.fullmatch(r"[a-f0-9]{32}", str(history.get("request_id", "")))
            or not re.fullmatch(r"[a-f0-9]{64}", str(history.get("receipt_sha256", "")))
            or history.get("submitted_at") is not None and (not isinstance(history["submitted_at"], str) or len(history["submitted_at"]) > 80)):
        raise Invalid("A branch handoff can retain a submission reference only; reviewer decisions are not portable authority.")
    expected_id = dw._hash({"proposal": proposal["proposal_sha256"], "validation": validation,
        "submission": packet["historical_submission"], "baseline_text": packet["baseline_text_sha256"]})[:32]
    if packet["packet_id"] != expected_id:
        raise Invalid("The branch handoff identity does not match its snapshot.")
    _share_ingress(packet)
    return packet


def share_preview(root, pack, *, proposal_id, actor_id, allowed_packs=None):
    """Explicitly selected existing artifacts only; never export other private work."""
    try:
        loaded = load(root, pack, proposal_id=proposal_id, actor_id=actor_id, allowed_packs=allowed_packs)
        if not loaded.get("ok") or loaded["stale"] or loaded.get("validation_error"):
            raise Invalid("Reopen a current intact proposal before preparing its branch handoff.")
        submission = loaded.get("submission")
        base, path, name = _path(root, pack, allowed_packs)
        history = ({key: submission.get(key) for key in ("request_id", "submitted_at", "receipt_sha256")}
                   if submission else None)
        packet = {"schema_version": 1, "pack": loaded["proposal"]["pack"], "proposal": loaded["proposal"],
            "validation": loaded.get("validation"), "historical_submission": history, "notice": SHARED_NOTICE,
            "baseline_text_sha256": _branch_text_baseline(base, path, name)}
        packet["packet_id"] = dw._hash({"proposal": loaded["proposal_sha256"], "validation": packet["validation"], "submission": history,
            "baseline_text": packet["baseline_text_sha256"]})[:32]
        packet["digest"] = dw._hash(packet)
        _check_shared(packet, packet["pack"])
        return {"ok": True, "packet": packet, "digest": packet["digest"], "packet_id": packet["packet_id"],
                "path": packet["pack"] + "/" + SHARED_FOLDER + "/" + packet["packet_id"] + ".json"}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
        return _failure(exc)


def share(root, pack, *, proposal_id, actor_id, expected_digest, confirmed=False, local_demo=False, can_write=False, allowed_packs=None):
    try:
        _authorized(local_demo, can_write)
        if confirmed is not True:
            raise Invalid("Review the complete branch handoff and confirm sharing those exact records.")
        preview = share_preview(root, pack, proposal_id=proposal_id, actor_id=actor_id, allowed_packs=allowed_packs)
        if not preview.get("ok") or preview["digest"] != expected_digest:
            raise Invalid("The proposal or its checks changed. Review a fresh handoff preview.")
        base, path, name = _path(root, pack, allowed_packs)
        target = _shared_file(path, preview["packet_id"])
        if target.exists():
            if _check_shared(_json(target), name) != preview["packet"]:
                raise Invalid("A different branch handoff already uses this identity.")
            return {**preview, "changed": False}
        target.parent.mkdir(parents=True, exist_ok=True)
        # Publish complete bytes without clobbering a concurrent conflicting file.
        # The link is on the same filesystem and the random temporary file is ours.
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(prefix=".sharing-", dir=target.parent, delete=False) as stream:
                temporary = Path(stream.name)
                stream.write(_encode(preview["packet"]))
                stream.flush()
                os.fsync(stream.fileno())
            try:
                os.link(temporary, target)
            except FileExistsError:
                if _check_shared(_json(target), name) != preview["packet"]:
                    raise Invalid("A different branch handoff was saved concurrently. It was not overwritten.")
                return {**preview, "changed": False}
        finally:
            if temporary is not None:
                _safe(temporary).unlink(missing_ok=True)
        return {**preview, "changed": True}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
        return _failure(exc)


def load_shared(root, pack, *, packet_id, actor_id, allowed_packs=None):
    try:
        base, path, name, _owner, _directory = _store(root, pack, actor_id, allowed_packs)
        packet = _check_shared(_json(_shared_file(path, packet_id)), name)
        if packet["packet_id"] != packet_id:
            raise Invalid("The handoff filename does not match its record.")
        description = dw.describe(base, name)
        baseline = description["baseline_sha256"]
        same_text = _branch_text_baseline(base, path, name) == packet["baseline_text_sha256"]
        if same_text:
            proposal = packet["proposal"]
            # Rebuild the origin plan's metadata only to compare intentions.
            # The eventual stage always receives the current exact raw baseline.
            origin_description = {**description, "baseline_sha256": proposal["baseline_sha256"],
                "contract_sha256": proposal["brief"]["contract_sha256"]}
            plan = _brief(origin_description, proposal["brief"])
            files, unsupported = _compose(path, proposal["configuration_changes"])
            impact = _impact(base, path, plan, proposal["configuration_changes"], proposal["study_exclusions"])
            if (_encode(plan) != _encode(proposal["brief"]) or _encode(_branch_text(files)) != _encode(_branch_text(proposal["files"]))
                    or _encode(_engineering_handoff(plan, impact, unsupported) + _recorded_review_handoff(proposal)) != _encode(proposal["engineering_handoff"])):
                raise Invalid("The shared handoff omits or changes part of its declared proposal. Restaging cannot introduce hidden changes.")
        return {"ok": True, "packet": packet, "packet_id": packet_id, "digest": packet["digest"],
                "baseline_sha256": baseline, "stale": not same_text,
                "line_endings_changed": same_text and baseline != packet["proposal"]["baseline_sha256"], "notice": SHARED_NOTICE}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
        return _failure(exc)


def list_shared(root, pack, *, actor_id, allowed_packs=None, page=0, page_size=20):
    """Read one bounded page of validated packet metadata, without recomposing each product."""
    try:
        if type(page) is not int or page < 0 or type(page_size) is not int or not 1 <= page_size <= 50:
            raise Invalid("Choose a valid handoff history page.")
        base, path, name, _owner, _directory = _store(root, pack, actor_id, allowed_packs)
        folder = _safe(path / SHARED_FOLDER)
        files = sorted(f for f in folder.glob("*.json") if re.fullmatch(r"[a-f0-9]{32}", f.stem)) if folder.is_dir() else []
        page = min(page, max(0, (len(files) - 1) // page_size))
        baseline = _branch_text_baseline(base, path, name) if files else None
        records, errors = [], []
        for file in files[page * page_size:(page + 1) * page_size]:
            try:
                packet = _check_shared(_json(_shared_file(path, file.stem)), name)
                if packet["packet_id"] != file.stem:
                    raise Invalid("The handoff filename does not match its record.")
                records.append({"packet_id": file.stem, "purpose": packet["proposal"]["purpose"],
                                "stale": baseline != packet["baseline_text_sha256"]})
            except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
                errors.extend(_failure(exc)["errors"])
        return {"ok": True, "records": records, "errors": errors, "page": page, "page_size": page_size,
                "total": len(files), "has_next": (page + 1) * page_size < len(files)}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
        return {**_failure(exc), "records": []}


def request_engineering(root, pack, *, proposal_id, actor_id, expected_digest, note,
                        confirmed=False, local_demo=False, can_write=False, allowed_packs=None):
    """Share the explicitly reviewed snapshot, then reference its full immutable identity."""
    from experiments.portal import handoffs
    try:
        _authorized(local_demo, can_write)
        # Validate user text before publishing any shared bytes.
        handoffs._text(note, "the details the engineer needs")
        _share_ingress(note)
        preview = share_preview(root, pack, proposal_id=proposal_id, actor_id=actor_id, allowed_packs=allowed_packs)
        if not preview.get("ok") or not preview["packet"]["proposal"]["engineering_handoff"]:
            raise Invalid("Choose a current proposal with unresolved engineering work.")
        saved = share(root, pack, proposal_id=proposal_id, actor_id=actor_id, expected_digest=expected_digest,
            confirmed=confirmed, local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
        if not saved.get("ok"):
            return saved
        reference = "configuration-proposal:" + saved["packet_id"] + ":" + saved["digest"]
        for doc in handoffs.listing(root, pack, allowed_packs=allowed_packs, include_closed=False):
            if doc.get("action_id") == reference:
                return {"ok": True, "handoff": doc, "packet_id": saved["packet_id"], "changed": False}
        doc = handoffs.create(root, pack, title="Review the requested implementation changes", owner="Engineering",
            note=note, requested_by=actor_id, action_id=reference, allowed_packs=allowed_packs,
            local_demo=local_demo, can_view=True)
        return {"ok": True, "handoff": doc, "packet_id": saved["packet_id"], "changed": True}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError, handoffs.Refused) as exc:
        return _failure(exc)


def load_engineering_request(root, pack, handoff_id, *, actor_id, allowed_packs=None):
    from experiments.portal import handoffs
    try:
        doc = handoffs.load(root, pack, handoff_id, allowed_packs=allowed_packs)
        reference = re.fullmatch(r"configuration-proposal:([a-f0-9]{32}):([a-f0-9]{64})", str(doc.get("action_id", "")))
        if not reference:
            raise Invalid("This engineering request has no exact proposal reference.")
        loaded = load_shared(root, pack, packet_id=reference[1], actor_id=actor_id, allowed_packs=allowed_packs)
        if not loaded.get("ok") or loaded["digest"] != reference[2]:
            raise Invalid("The engineering request's exact shared proposal is missing or changed. Ask its author to share a fresh reviewed handoff.")
        return {**loaded, "handoff": doc}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError, handoffs.Refused) as exc:
        return _failure(exc)


def shared_revision_preview(root, pack, *, packet_id, actor_id, allowed_packs=None):
    """Prepare reviewed intent for the existing editor; never import validation or write a draft."""
    try:
        loaded = load_shared(root, pack, packet_id=packet_id, actor_id=actor_id, allowed_packs=allowed_packs)
        if not loaded.get("ok"):
            return loaded
        original = loaded["packet"]["proposal"]
        description = dw.describe(root, pack)
        if description["errors"]:
            raise Invalid("The current product needs repair before revising this handoff.")
        current = {row["variable_id"] for row in description["rows"]}
        old = set(original["brief"]["kept"]) | set(original["brief"]["removed"])
        conflicts = []
        if original["brief"]["contract_sha256"] != description["contract_sha256"]:
            conflicts.append({"Item": "Scientific definitions", "Change": "The contract changed since this handoff",
                "Restoration": "Review current meanings and dependencies; old selections do not approve the revised definitions."})
        for variable in sorted(old - current):
            conflicts.append({"Item": variable, "Change": "No longer in the current contract", "Restoration": "Not selected; review its intended study use."})
        for variable in sorted(current - old):
            conflicts.append({"Item": variable, "Change": "Added to the current contract", "Restoration": "Retained; this handoff did not request removing it."})
        values = _shared_inputs(original)
        values["retained"] = [row["variable_id"] for row in description["rows"] if row["variable_id"] not in original["brief"]["removed"]]
        if not original["brief"]["source_changed"]:
            values.update(target_source=description["source"]["vendor"], target_modality=description["source"]["modality"])
        elif original["brief"]["source"]["current"] != description["source"]:
            conflicts.append({"Item": "Data source", "Change": "The baseline source changed", "Restoration": "The explicitly proposed source is retained for review."})
        plan = dw.build_plan(description, **values)
        exclusions = []
        for row in original["study_exclusions"]:
            kept = [v for v in row["variables"] if v in plan["removed"]]
            if kept:
                exclusions.append({"study": row["study"], "variables": kept})
            missing = sorted(set(row["variables"]) - set(kept))
            if missing:
                conflicts.append({"Item": row["study"], "Change": "Excluded definitions are absent: " + ", ".join(missing),
                                  "Restoration": "These exclusions cannot be restored; reconsider the study's current choices."})
        supported = supported_parameters(root, pack)
        if any(change["ref"] in COHORT_REFS for change in original["configuration_changes"]):
            cohort_state = cohort_editor(root, pack)
            for key, label in (("cohorts", "Cohort definitions"), ("index_dates", "Index-date models")):
                supported["config/data_product.yaml#/" + key] = (label, "block", cohort_state[key])
        settings = []
        for change in original["configuration_changes"]:
            ref = change["ref"]
            present = supported.get(ref)
            previous = next((f["before"] for f in original["files"] if f["path"] == ref.split("#/", 1)[0]), None)
            prior = None
            if previous is not None and ref in PARAMETERS.keys() | COHORT_REFS:
                prior = _parse(previous)
                for part in ref.split("#/", 1)[1].split("/"):
                    prior = prior.get(part) if isinstance(prior, dict) else None
            settings.append({"Setting": present[0] if present else ref, "Original": prior,
                "Current": present[2] if present else "Unsupported", "Requested": change["value"]})
            if present and (prior is None or type(prior) is not type(present[2]) or prior != present[2]):
                conflicts.append({"Item": present[0], "Change": "Current value differs or the old value is unavailable",
                    "Restoration": "The explicit requested value is retained for editing."})
        try:
            files, unsupported = _compose(Path(root) / pack, original["configuration_changes"])
            preview_errors = list(plan["errors"])
        except (ValueError, OSError) as exc:
            files, preview_errors = [], list(plan["errors"]) + _failure(exc)["errors"]
        restored = {"brief": plan, "baseline_sha256": description["baseline_sha256"],
            "configuration_changes": original["configuration_changes"], "study_exclusions": exclusions}
        result = {"ok": True, "packet_id": packet_id, "packet_digest": loaded["digest"],
            "baseline_sha256": description["baseline_sha256"], "restore": restored, "conflicts": conflicts,
            "snapshot_sha256": _snapshot(Path(root).resolve(), Path(root).resolve() / pack),
            "impact": _impact(Path(root).resolve(), Path(root).resolve() / pack, plan, original["configuration_changes"], exclusions),
            "settings": settings, "files": files, "errors": preview_errors,
            "unsupported_changes": [c for c in original["configuration_changes"] if c["ref"] not in supported],
            "notice": "Copying this intent only fills an unfinished revision. Review every changed selection, stage a new diff and run fresh validators. Prior checks, submission and approvals are not carried forward."}
        _share_ingress(result)
        return {**result, "digest": dw._hash(result)}
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
        return _failure(exc)


def restage_shared(root, pack, *, packet_id, actor_id, expected_digest, expected_baseline,
                   confirmed=False, local_demo=False, can_write=False, allowed_packs=None):
    try:
        _authorized(local_demo, can_write)
        if confirmed is not True:
            raise Invalid("Review the branch handoff and confirm a new local proposal.")
        loaded = load_shared(root, pack, packet_id=packet_id, actor_id=actor_id, allowed_packs=allowed_packs)
        if not loaded.get("ok") or loaded["digest"] != expected_digest or loaded["stale"] or loaded["baseline_sha256"] != expected_baseline:
            raise Invalid("The branch handoff or product changed. Review the differences before creating a new proposal.")
        proposal = loaded["packet"]["proposal"]
        if any(change["ref"] in REVIEWED_BLOCK_REFS for change in proposal["configuration_changes"]):
            raise Invalid("This handoff contains clinical rules. Review them in the current variable tables and prepare a fresh execution proposal; historical review choices cannot confirm this checkout.")
        plan = dw.build_plan(dw.describe(root, pack), **_shared_inputs(proposal))
        if plan["removed"] != proposal["brief"]["removed"]:
            raise Invalid("The current definitions no longer match these retained and removed selections.")
        return stage(root, pack, plan, configuration_changes=proposal["configuration_changes"],
            study_exclusions=proposal["study_exclusions"], actor_id=actor_id, expected_baseline=expected_baseline,
            local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError) as exc:
        return _failure(exc)


def _run_validators(root, candidate_pack):
    """Existing pure-Python gates; never execute the proposed derivations."""
    checks = []
    def check(name, fn):
        try:
            errors, detail = fn()
            checks.append({"validator": name, "passed": not errors, "errors": list(errors), "detail": detail, "completed": True})
        except Exception as exc:  # A gate that cannot run is a failed gate.
            checks.append({"validator": name, "passed": False, "completed": False, "errors": [f"{type(exc).__name__}: {exc}"]})
    check("engine.validate (strict)", lambda: (problems(load_config(candidate_pack / "config/data_product.yaml"), strict=True), {}))
    check("contract_lint", lambda: dw.cl.run(str(candidate_pack)))
    check("contract_binding", lambda: cb.check(str(candidate_pack), cb.pack_yaml(str(candidate_pack))))
    def blocks():
        return cb.governed_blocks(str(candidate_pack), cb.pack_yaml(str(candidate_pack)))
    check("contract_binding parameters", lambda: cb.compare_parameters(str(candidate_pack), blocks()))
    def enumerations():
        read = cb.enumerations_read(str(candidate_pack))
        errors = cb.compare_enumerations(str(candidate_pack), blocks())
        if read["present"] and not read["parsed"]:
            errors.append("The specification enumeration artifact could not be parsed.")
        return errors, {"present": read["present"], "parsed": read["parsed"],
                        "enumeration_groups": len(read["enumerations"])}
    check("contract_binding enumerations", enumerations)
    for result in checks:
        detail = result.get("detail")
        if isinstance(detail, dict) and detail.get("compared") == 0:
            result["note"] = "No readable parameter comparisons were made; this does not establish agreement with the scientific requirement."
        if isinstance(detail, dict) and detail.get("enumeration_groups") == 0:
            result["note"] = "No declared enumeration groups were compared; this does not establish agreement on codes or categories."
    return checks


def _candidate(base, path, proposal, target):
    """Mirror ancestry for root-sensitive validators, omitting all portal artifacts."""
    (target / "platform/tools").mkdir(parents=True)
    for file in _tree_files(path):
        dest = target / file.relative_to(base)
        dest.parent.mkdir(parents=True, exist_ok=True)
        _copy(file, dest)
    for rel in SHARED_INPUTS:
        source = base / rel
        for file in _tree_files(source) if source.is_dir() else ([source] if source.is_file() else []):
            dest = target / file.relative_to(base)
            dest.parent.mkdir(parents=True, exist_ok=True)
            _copy(file, dest)
    for file in proposal["files"]:
        (target / proposal["pack"] / file["path"]).write_bytes(file["after"].encode("utf-8"))
    return target / proposal["pack"]


def validate_files(base, path, name, files):
    """Run the existing gates on an isolated copy of the product carrying these candidate files.

    One entry point for the two moments a candidate is checked: when its author validates the
    staged proposal and when a reviewer validates the applied draft revision. The product itself
    is never the candidate; the copy is discarded once the gates have reported.
    """
    with tempfile.TemporaryDirectory(prefix="rwd-config-review-") as temporary:
        target = Path(temporary).resolve()
        candidate = _candidate(base, path, {"pack": name, "files": files}, target)
        return _run_validators(target, candidate)


# The checks a product between Gate 2 and Gate 4 fails for reasons a supported setting does not
# touch; a failure that is identical without the change is a caveat for the reviewer, not a block.
# The strict engine validation of the changed configuration is never exempt.
PRE_EXISTING_EXEMPT = frozenset({"contract_lint", "contract_binding", "contract_binding parameters", "contract_binding enumerations"})
REQUIRED_VALIDATORS = PRE_EXISTING_EXEMPT | {"engine.validate (strict)"}


def _validate(base, path, name, owner, directory, proposal_id):
    proposal, folder, stale = _load(base, path, name, owner, directory, proposal_id)
    if stale:
        raise Invalid("Product or declared consumer inputs changed since staging. Create a fresh proposal.")
    # Checksums detect accidents; they are not an authorization mechanism. Rebuild
    # the candidate from the supported inputs before letting any saved bytes run
    # through the validators, even if somebody recomputed a packet checksum.
    description = dw.describe(base, name)
    plan = _brief(description, proposal["brief"])
    exclusions = _exclusions(plan, proposal["study_exclusions"])
    files, unsupported = _compose(path, proposal["configuration_changes"])
    impact = _impact(base, path, plan, proposal["configuration_changes"], exclusions)
    if dw._hash(files) != dw._hash(proposal["files"]) or dw._hash(impact) != dw._hash(proposal["impact"]):
        raise Invalid("The staged configuration or impact no longer matches its supported inputs. Stage a fresh proposal.")
    if "variable_review_binding" in proposal:
        report = _require_review_binding(base, name, owner, proposal["variable_review_binding"], [name])
        if dw._hash(_review_records(report)) != dw._hash(proposal["variable_review_records"]):
            raise Invalid("The staged variable definitions differ from the reviewed table. Prepare a fresh proposal.")
        expected_handoff = _engineering_handoff(plan, impact, unsupported)
        expected_handoff.extend(_review_handoff(base, path, name, report, proposal["configuration_changes"]))
        if _encode(expected_handoff) != _encode(proposal["engineering_handoff"]):
            raise Invalid("The staged proposal no longer includes the reviewed variables' implementation work. Prepare a fresh proposal.")
    checks = validate_files(base, path, name, proposal["files"])
    # A FAILURE THE PRODUCT ALREADY HAD IS NOT THIS PROPOSAL'S (walk UC3-P1-4, 2026-09-07): a product
    # between Gate 2 and Gate 4 fails contract lint or binding for reasons the proposed setting does
    # not touch. Those checks are run once more on the product as it stands; a validator that fails
    # there with the same reasons is recorded as pre-existing, shown to the reviewer as a caveat, and
    # does not block submission. A failure the proposal ADDS still blocks.
    needs_baseline = any(not c.get("passed") and c["validator"] in PRE_EXISTING_EXEMPT for c in checks)
    baseline = {c["validator"]: c for c in validate_files(base, path, name, {})} if needs_baseline else {}
    caveats = []
    for check in checks:
        if check.get("passed") or check["validator"] not in PRE_EXISTING_EXEMPT:
            continue        # the changed configuration itself must always validate (engine.validate strict)
        before = baseline.get(check["validator"])
        if (before and check.get("completed", True) and before.get("completed", True)
                and not before.get("passed") and set(check.get("errors") or []) <= set(before.get("errors") or [])):
            check["pre_existing"] = True
            caveats.append(f"{check['validator']} already fails on this product without the proposed change "
                           f"({len(before.get('errors') or [])} reason(s)); the reviewer sees them as the product's own open work.")
    # Check both original inputs and exact reviewed bytes again after validation.
    fresh, _folder_, stale = _load(base, path, name, owner, directory, proposal_id)
    if stale or fresh["proposal_sha256"] != proposal["proposal_sha256"]:
        raise Invalid("Proposal or product inputs changed during validation. Stage and validate a fresh proposal.")
    errors = list(proposal["errors"]) + impact["errors"] + _plan_errors(plan)
    if impact["study_dependency_conflicts"]:
        errors.append("Study exclusions leave unresolved declared dependencies.")
    if proposal["engineering_handoff"] or unsupported or plan["added"] or plan["source_changed"] or impact["shared_removed"]:
        errors.append("Engineering handoff remains unresolved. Stage supported changes separately before submission.")
    if len(checks) != len(REQUIRED_VALIDATORS) or {check.get("validator") for check in checks} != REQUIRED_VALIDATORS:
        errors.append("The complete required validator set did not run. Run all proposal validators again.")
    passed = bool(checks) and all(c.get("passed") is True or c.get("pre_existing") is True for c in checks) and not errors
    return {"ok": True, "passed": passed, "proposal_sha256": proposal["proposal_sha256"],
            "validated_at": datetime.now(timezone.utc).isoformat(), "checks": checks, "errors": errors,
            "caveats": caveats}, folder


def _receipt(folder, name, record):
    target = _safe(folder / name)
    temp = _safe(folder / (".receipt-" + uuid.uuid4().hex[:24]))
    try:
        saved = {**record, "receipt_sha256": dw._hash(record)}
        temp.write_bytes(_encode(saved))
        os.replace(temp, target)
    finally:
        if temp.exists() and temp.resolve() == temp and temp.parent == folder:
            temp.unlink()


def validate(root, pack, *, proposal_id, actor_id, local_demo, can_write, allowed_packs=None):
    try:
        _authorized(local_demo, can_write)
        context = _store(root, pack, actor_id, allowed_packs)
        result, folder = _validate(*context, proposal_id)
        _receipt(folder, "validation.json", result)
        return result
    except (OSError, ValueError, TypeError, KeyError, AttributeError, UnicodeError, RecursionError) as exc:
        return _failure(exc)


def submit(root, pack, *, proposal_id, actor_id, local_demo, can_write, allowed_packs=None):
    try:
        _authorized(local_demo, can_write)
        context = _store(root, pack, actor_id, allowed_packs)
        # Never trust a browser flag or even a saved validation receipt.
        result, folder = _validate(*context, proposal_id)
        _receipt(folder, "validation.json", result)
        if not result["passed"]:
            return {**result, "ok": False, "errors": result["errors"] + ["Existing validators must pass before this proposal can be submitted for review."]}
        receipt = {"status": "submitted_for_review", "draft_only": True, "approved": False, "released": False,
                   "proposal_id": proposal_id, "proposal_sha256": result["proposal_sha256"],
                   "request_id": uuid.uuid4().hex,
                   "submitted_at": datetime.now(timezone.utc).isoformat(), "validation": result,
                   "scope": "Local review request only; no product, approval, release or study pin is changed."}
        receipt["receipt_sha256"] = dw._hash(receipt)
        proposal, _folder_, stale = _load(*context, proposal_id)
        if stale or proposal["proposal_sha256"] != result["proposal_sha256"]:
            raise Invalid("The product or proposal changed before submission. Stage a fresh proposal.")
        target = _safe(folder / "submission.json")
        try:
            with target.open("xb") as stream:
                stream.write(_encode(receipt))
        except FileExistsError:
            receipt = _read_receipt(target, proposal)
        # The receipt is the author's; the request is what a reviewer sees. Publishing is
        # idempotent on the receipt's request id, so a submit repeated after a failed publish
        # completes the same request instead of opening a second one.
        from experiments.portal import review_inbox
        request = None
        if receipt.get("request_id"):
            request = review_inbox.publish(context[0], context[2], proposal=proposal, validation=receipt["validation"],
                                           actor_id=actor_id, request_id=receipt["request_id"])
        return {"ok": True, "submission": receipt, "review_request": request, "errors": []}
    except (OSError, ValueError, TypeError, KeyError, AttributeError, UnicodeError, RecursionError) as exc:
        return _failure(exc)


# Whole-workbook proposals use the same contract renderer and isolated native
# validators as manual authoring. Model input names judgments and native fields,
# never filesystem paths, review verdicts or executable source code.
WORKBOOK_FOLDER = "workbooks"
WORKBOOK_NOTICE = "Private workbook draft. Technical checks do not approve scientific choices, source mappings, execution or release."
WORKBOOK_RAW_CONTROLS = frozenset({"expr", "expression", "sql", "where", "filter", "script", "command", "python"})
WORKBOOK_POLICY = ".portal-drafts/workbooks/drafting-policy.json"
WORKBOOK_DESTINATIONS = frozenset({"ads", "dictionary", "dashboard", "tfl"})


def _workbook_policy_value(policy):
    if not isinstance(policy, dict) or set(policy) != {"destinations", "naming_rule", "default_output_role"}:
        raise Invalid("Choose product destinations, a naming rule and an optional output role.")
    destinations = policy["destinations"]
    if (not isinstance(destinations, list) or any(not isinstance(value, str) or value not in WORKBOOK_DESTINATIONS for value in destinations)
            or len(set(destinations)) != len(destinations)):
        raise Invalid("Choose each supported publication destination at most once.")
    if policy["naming_rule"] != "preserve_physical_name" or policy["default_output_role"] not in {None, "published", "internal"}:
        raise Invalid("Keep existing physical names and choose published, internal or no default role.")
    if policy["default_output_role"] == "published" and not destinations:
        raise Invalid("Published outputs need at least one proposed destination.")
    if policy["default_output_role"] == "internal" and "ads" in destinations:
        raise Invalid("An internal output cannot also be proposed for the published ADS.")
    return {**policy, "destinations": sorted(destinations)}


def _workbook_policy_read(product, name):
    path = _safe(product / WORKBOOK_POLICY)
    if not path.exists():
        return {"configured": False, "policy_digest": "", "policy": None}
    raw = _read(path)
    saved = json.loads(raw)
    if (not isinstance(saved, dict) or saved.get("schema_version") != 1 or saved.get("pack") != name
            or saved.get("draft_only") is not True or saved.get("approved") is not False
            or not isinstance(saved.get("recorded_by"), str) or not saved["recorded_by"]):
        raise Invalid("The saved product drafting choices are invalid; restore their original receipt.")
    return {"configured": True, "policy_digest": _digest(raw), "policy": _workbook_policy_value(saved["policy"]),
            "recorded_by": saved["recorded_by"], "recorded_at": saved.get("recorded_at", "")}


def workbook_drafting_policy(root, pack, *, actor_id, allowed_packs=None):
    """Product-wide explicit draft defaults, shared across authorized reviewers."""
    try:
        base, product, name, _owner, _folder = _workbook_scope(root, pack, actor_id, allowed_packs)
        return {"ok": True, **_workbook_policy_read(product, name), "input_digest": _workbook_snapshot(base, product, actor_id=actor_id),
                "notice": "These are proposed output choices, not configured destinations or approvals."}
    except (OSError, ValueError, TypeError, KeyError) as error:
        return _failure(error)


def save_workbook_drafting_policy(root, pack, *, actor_id, policy, expected_input_digest,
                                 expected_policy_digest, local_demo, can_write, allowed_packs=None):
    """CAS the existing authoring store; changing choices invalidates saved candidates."""
    lock_fd, lock = None, None
    try:
        from experiments.portal import scientific_definitions as science
        _authorized(local_demo, can_write)
        base, product, name, _owner, _folder = _workbook_scope(root, pack, actor_id, allowed_packs)
        value = _workbook_policy_value(policy)
        path = _safe(product / WORKBOOK_POLICY)
        path.parent.mkdir(parents=True, exist_ok=True)
        lock = _safe(path.with_suffix(".lock"))
        try:
            lock_fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            raise Invalid("Another editor is saving product drafting choices. Reload them before retrying.")
        def current():
            if (_workbook_snapshot(base, product, actor_id=actor_id) != expected_input_digest
                    or _workbook_policy_read(product, name)["policy_digest"] != expected_policy_digest):
                raise Invalid("The product or its drafting choices changed. Reload before saving.")
        current()
        saved = {"schema_version": 1, "pack": name, "policy": value, "recorded_by": actor_id,
                 "recorded_at": datetime.now(timezone.utc).isoformat(), "draft_only": True, "approved": False,
                 "previous_policy_digest": expected_policy_digest}
        science._atomic(path, _encode(saved), check=current)
        return {**workbook_drafting_policy(root, pack, actor_id=actor_id, allowed_packs=allowed_packs), "changed": True}
    except (OSError, ValueError, TypeError, KeyError) as error:
        return _failure(error)
    finally:
        if lock_fd is not None:
            os.close(lock_fd)
            lock.unlink(missing_ok=True)


def _workbook_scope(root, pack, actor_id, allowed_packs):
    from experiments.portal import scientific_definitions as science
    if allowed_packs is None or pack not in allowed_packs:
        raise Invalid("This product is not available to the current editing identity.")
    product, name, owner, _folder = science._scope(root, pack, actor_id, allowed_packs)
    base = Path(root).resolve()
    folder = _safe(product / ".portal-drafts" / WORKBOOK_FOLDER / owner[:24])
    return base, product, name, owner, folder


def _workbook_upload_snapshot(base, product, actor_id):
    """Fingerprint scoped external uploads without adding their contents to context."""
    from experiments.portal import source_table_intake, source_workspace, authoring_session
    inventory = _safe(product / source_table_intake.INVENTORY)
    if not inventory.exists():
        return {}
    tables = source_table_intake.decode_inventory(_read(inventory))["tables"]
    if not tables:
        return {}
    if not actor_id:
        return {"state": "unscoped"}
    pack = product.relative_to(base).as_posix()
    authoring_session.check_scope(base, pack, actor_id)
    folder = source_workspace._scope(base, pack, actor_id, [pack])[4]
    result = {}
    for table in tables:
        name = table["physical_table"]
        if table["imported_by"] != actor_id:
            result[name] = {"state": "different_owner"}
            continue
        try:
            path = _safe(folder / "table_uploads" / (table["sha256"] + ".tsv"))
            digest = hashlib.sha256()
            size = 0
            with _bounded(path, source_table_intake.MAX_BYTES).open("rb") as stream:
                while chunk := stream.read(CHUNK):
                    size += len(chunk)
                    if size > source_table_intake.MAX_BYTES:
                        raise Invalid("The uploaded file exceeds its metadata intake limit.")
                    digest.update(chunk)
            result[name] = {"sha256": digest.hexdigest(), "bytes": size}
        except (OSError, ValueError):
            result[name] = {"state": "unavailable"}
    return result


def _workbook_snapshot(base, product, *, actor_id=None):
    from experiments.portal import scientific_definitions as science, scientific_definition_ai as ai, workflow_outputs
    from experiments.portal import (source_table_intake, variable_clinical_rules, source_provisioning,
        source_workspace, authoring_session, identity, installation_storage, specification_details)
    from rwd_tools import contract_lint, contract_record, contract_scaffold, spec_lint, spec_codelists, source_manifest, product_gates, source_adapter
    engine = Path(cb._engine_dir() or "")
    if not engine.is_dir():
        raise Invalid("The native configuration reader is unavailable.")
    code = {path.as_posix(): _digest(path.read_bytes()) for path in sorted(engine.rglob("*"))
            if path.is_file() and path.suffix in {".py", ".json"}}
    modules = (cb, science, ai, workflow_outputs, contract_lint, contract_record,
               contract_scaffold, spec_lint, spec_codelists, source_manifest, product_gates,
               source_table_intake, source_adapter, variable_clinical_rules, source_provisioning,
               source_workspace, authoring_session, identity, installation_storage, specification_details)
    for module in (Path(__file__), *(Path(module.__file__) for module in modules)):
        code[module.as_posix()] = _digest(module.read_bytes())
    policy = _safe(product / WORKBOOK_POLICY)
    return _digest(_encode({"product": science._snapshot(product), "readers": code,
                           "uploaded_inputs": _workbook_upload_snapshot(base, product, actor_id),
                           "drafting_policy": _digest(_read(policy)) if policy.exists() else ""}))


def _workbook_finding(code, message, *, item_id="", field="", kind="scientific", repairable=False):
    from experiments.portal import form_assistance
    messages, _omitted = form_assistance.validation_messages([str(message)])
    return {"code": code, "item_id": item_id, "field": field, "kind": kind,
            "message": " ".join(messages) or "Inspect the current workbook and its source evidence.",
            "repairable": bool(repairable), "choices": []}


def _workbook_judgment_constraints():
    """The contract reader's interface vocabulary, never clinical defaults."""
    from experiments.portal import scientific_definitions as science
    cl = science.cl
    return {
        "enums": {"output.role": sorted(cl.ROLE), "output.name_status": sorted(cl.NAMEST),
                  "publish.*": sorted(cl.PUB), "output.nullable": sorted(cl.NULLABLE),
                  "source.kind": sorted(cl.SOURCE_KINDS)},
        "arrays_of_strings": {"depends_on": "[] if no dependencies; otherwise exact record IDs or engine:stage refs",
                              "decision_ids": "[] or existing decision IDs", "gap_ids": "[] or existing gap IDs",
                              "implementation_refs": "[\"none\"] if unbound; otherwise supplied YAML refs or engine anchors"},
        "objects": {"output": sorted(cl.INLINE_SCHEMA["output"]), "publish": sorted(cl.INLINE_SCHEMA["publish"])},
        "other_shapes": "source may be text or an object with source.kind; grain may be text or an array of keys. Scientific fields may be text or simple structured values. output.type is a data-type name; nullable is JSON true/false. Output codes may be a code-to-label object or n/a. Never turn a reference into a source-verification claim.",
        "metadata_syntax": {"source": {"kind": "parameter"}, "output": {"physical_name": "none", "target_published_name": "n/a", "name_status": "undecided", "type": "date", "nullable": False, "codes": "n/a", "role": "metadata"}, "publish": {key: "excluded" for key in sorted(cl.INLINE_SCHEMA["publish"])}, "depends_on": []},
        "scope": "Syntax example for a non-column date parameter, not a date or publication decision for this source. metadata means a study/configuration parameter with no ADS column. Pending naming review may remain undecided. Parameter is a source kind, not an output role. No/not_published are not contract enums. Canonical rendering and validation remain authoritative.",
    }


def workbook_judgment_representation(values):
    """Normalize only lossless interface spelling for a technical-repair comparison."""
    if not isinstance(values, dict):
        return deepcopy(values)
    result = deepcopy(values)
    constraints = _workbook_judgment_constraints()
    for path, choices in constraints["enums"].items():
        parent, key = path.split(".")
        mapping = result.get(parent)
        if not isinstance(mapping, dict):
            continue
        keys = list(mapping) if key == "*" else [key]
        for name in keys:
            value = mapping.get(name)
            if isinstance(value, str) and value.strip().casefold() in choices:
                normalized = value.strip().casefold()
                mapping[name] = normalized == "true" if path == "output.nullable" else normalized
    for field in constraints["arrays_of_strings"]:
        value = result.get(field)
        if isinstance(value, str) and value.strip().casefold() in {"none", "[]"}:
            result[field] = ["none"] if field == "implementation_refs" else []
    return result


def _workbook_judgment_interface(values, item_id):
    """Scoped errors for the known interface, with only lossless repairs eligible."""
    constraints = _workbook_judgment_constraints()
    normalized = workbook_judgment_representation(values)
    findings = []
    def issue(path, message, choices, value, replacement):
        repairable = replacement != value
        finding = _workbook_finding("judgment_interface", message, item_id=item_id, field=path,
                                    kind="technical", repairable=repairable)
        finding["choices"] = list(choices)
        if repairable:
            finding["repair_value"] = replacement
        findings.append(finding)
    for path, choices in constraints["enums"].items():
        parent, key = path.split(".")
        mapping = values.get(parent)
        if not isinstance(mapping, dict):
            continue
        keys = list(mapping) if key == "*" else [key]
        for name in keys:
            if name not in mapping:
                continue
            value = mapping[name]
            if isinstance(value, str) and (value.strip() == "TODO" or value in choices):
                continue
            if path == "output.nullable" and isinstance(value, bool):
                continue
            field = parent + "." + name
            issue(field, field + " must use the contract's supplied choices: " + ", ".join(choices) + ".",
                  choices, value, normalized[parent][name])
    for field in constraints["arrays_of_strings"]:
        value = values.get(field)
        if value == "TODO" or isinstance(value, list) and all(isinstance(item, str) for item in value):
            continue
        issue(field, field + " must be an array of strings. " + constraints["arrays_of_strings"][field] + ".",
              [], value, normalized.get(field))
    return findings


def _workbook_interface_questions(row, findings):
    """Keep ambiguous finite interface choices answerable in the saved draft."""
    added = []
    for finding in findings:
        if finding.get("repairable") or not finding.get("choices") or len(row["questions"]) >= 6:
            continue
        field = finding["field"]
        choices = list(finding["choices"])
        question = "For " + str(row["values"]["variable_id"]) + ", which contract value should " + field + " use?"
        if len(choices) > 5:
            question += " Allowed values: " + ", ".join(choices) + "."
            choices = []  # Preserve every option when the control supports only five.
        entry = {"question": question, "choices": choices}
        if entry in row["questions"]:
            continue
        row["questions"].append(entry)
        added.append({"id": _digest(_encode([row["item_id"], question, choices]))[:24],
                      "item_id": row["item_id"], "question": question, "kind": "scientific", "choices": choices,
                      "fields": [field]})
    return added


def _workbook_bindings(product, allowed):
    """Distinguish the binder's block references from editable leaf pointers."""
    unreadable = {}
    current = cb.governed_blocks(str(product), cb.pack_yaml(str(product)), unreadable)
    if unreadable:
        raise Invalid("Read the current configuration before proposing implementation bindings.")
    added = {ref for ref, entry in allowed.items() if len(entry["keys"]) == 1 and ref not in current}
    if QC_DATE_ORDER_REF in allowed and "config/data_product.yaml#/qc" not in current:
        added.add("config/data_product.yaml#/qc")
    def grouped(refs):
        result = {}
        for ref in sorted(refs):
            file, pointer = ref.split("#", 1)
            result.setdefault(file, []).append(pointer)
        return result
    parents = {}
    for ref, entry in allowed.items():
        if len(entry["keys"]) > 1:
            parent = entry["file"] + "#/" + entry["keys"][0]
            if parent in current or ref == QC_DATE_ORDER_REF:
                parents[ref] = parent
    return {"current_blocks": grouped(current), "blocks_if_added": grouped(added),
            "write_pointer_to_binding": parents,
            "scope": "Bind implementation_refs to file+block pointer, not editable leaf pointers. blocks_if_added bind only after the candidate activates that native block. Engine anchors are separate. Exact leaf-to-parent mappings are technical references, not scientific approval."}


def _workbook_binding_interface(values, item_id, bindings):
    findings = []
    for ref in values.get("implementation_refs") or []:
        if not isinstance(ref, str) or ref not in bindings["write_pointer_to_binding"]:
            continue
        parent = bindings["write_pointer_to_binding"][ref]
        finding = _workbook_finding("implementation_binding", ref + " is an editable leaf. The canonical binder reads " + parent + ".",
                                    item_id=item_id, field="implementation_refs", kind="technical", repairable=True)
        finding.update(choices=[parent], repair_value=parent)
        findings.append(finding)
    return findings


def _workbook_native(product):
    """Existing native readers own the permitted variable-block vocabulary."""
    cfg = load_config(product / "config/data_product.yaml")
    from engine import config_schema
    schema = json.loads(_read(Path(config_schema.__file__).with_suffix(".json")))
    keys = cb.engine_config_keys()
    if not keys:
        raise Invalid("The native configuration field catalog could not be read.")
    documents, allowed = {}, {}
    for relative in cfg.raw.get("variables") or []:
        if not isinstance(relative, str) or not re.fullmatch(r"variables/[A-Za-z][A-Za-z0-9_]*\.yaml", relative):
            raise Invalid("The active variable configuration must use product-local native YAML files.")
        document = _parse(_read(_safe(product / relative)).decode("utf-8"))
        if not isinstance(document, dict):
            raise Invalid("Every native variable file must contain a mapping.")
        documents[relative] = document
        role_fields = schema["$defs"].get(Path(relative).stem, {}).get("properties", {})
        for key in sorted(keys.get(Path(relative).stem, set()) & set(role_fields)):
            if key not in {"status", "version", "owner", "pack_id", "name", "description"}:
                allowed[relative + "#/" + key] = {"file": relative, "keys": [key], "current": document.get(key)}
    for ref in PARAMETERS:
        if ref.startswith("config/data_product.yaml#/study/"):
            relative, pointer = ref.split("#/", 1)
            document = documents.setdefault(relative, _parse(_read(product / relative).decode("utf-8")))
            value = document
            for key in pointer.split("/"):
                value = value.get(key) if isinstance(value, dict) else None
            allowed[ref] = {"file": relative, "keys": pointer.split("/"), "current": value}
    # Existing typed cohort/index editors remain the source of these native structures.
    for ref in COHORT_REFS | {LOT_NUMBERING_REF, DICTIONARY_REF, QC_DATE_ORDER_REF}:
        relative, pointer = ref.split("#/", 1)
        document = documents.setdefault(relative, _parse(_read(product / relative).decode("utf-8")))
        if ref == QC_DATE_ORDER_REF and "qc" in document and not isinstance(document["qc"], dict):
            raise Invalid("Read the current QC mapping before proposing date-order checks.")
        value = document
        for key in pointer.split("/"):
            value = value.get(key) if isinstance(value, dict) else None
        allowed[ref] = {"file": relative, "keys": pointer.split("/"), "current": value}
    return cfg, documents, allowed


def _workbook_schemas(allowed):
    from engine import config_schema, validate as native_validation
    schema = json.loads(_read(Path(config_schema.__file__).with_suffix(".json")))
    definitions = {}
    def compact(node):
        if isinstance(node, list):
            return [compact(child) for child in node]
        if not isinstance(node, dict):
            return deepcopy(node)
        if "$ref" in node:
            ref = node["$ref"]
            if not ref.startswith("#/$defs/") or ref.split("/")[-1] not in schema["$defs"]:
                raise Invalid("Only the installed native schema may define workbook fields.")
            name = ref.split("/")[-1]
            if name not in definitions:
                # Native eligibility groups are recursive. Preserve the actual
                # local reference graph once, rather than expanding it forever.
                definitions[name] = {}
                definitions[name] = compact(schema["$defs"][name])
        return {key: compact(child) for key, child in node.items()
                if key not in {"description", "title", "$id", "$schema", "default", "examples"}}
    result = {}
    for ref, entry in allowed.items():
        definition = schema["$defs"].get(Path(entry["file"]).stem, {}) if entry["file"].startswith("variables/") else schema
        for key in entry["keys"]:
            while "$ref" in definition:
                definition = schema["$defs"][definition["$ref"].split("/")[-1]]
            definition = definition.get("properties", {}).get(key, {})
        result[ref] = {} if ref == "variables/outcomes.yaml#/ads_derived" else compact(definition)
        if ref == "variables/outcomes.yaml#/overall_survival":
            active = {"type": "object", "required": list(native_validation.OS_ANCHORS),
                "properties": {key: {"type": "string", "pattern": "^[A-Za-z][A-Za-z0-9_]{0,127}$"}
                               for key in (*native_validation.OS_ANCHORS, "gate")},
                "additionalProperties": False}
            result[ref] = {"oneOf": [{"type": "object", "maxProperties": 0}, active]}
        if ref == "variables/outcomes.yaml#/ads_derived":
            from experiments.portal import variable_clinical_rules
            # Models supply a bounded typed tree; only the deterministic compiler
            # below may introduce expression text into the native shadow files.
            item = deepcopy(variable_clinical_rules.workbook_calculation_schema())
            definitions.update(item.pop("$defs", {}))
            existing = entry.get("current") or []
            result[ref] = {"type": "array", "items": {"anyOf": [item, {"enum": existing}]}
                           if isinstance(existing, list) and existing else item}
    result["$defs"] = definitions
    return result


def _workbook_configured_upload_links(root, product, cfg, actor_id, allowed_packs, inventory):
    """Join explicit source declarations to recorded local provisioning, never review them."""
    from experiments.portal import source_provisioning, source_table_intake, authoring_session
    result = {"state": "absent", "links": [], "findings": [], "source_mapping_approved": False,
        "runtime_reverified": False,
        "scope": "Unreviewed explicit table declarations linked to current upload/provisioning receipts only. "
                 "All imported columns are present; runtime_renames contains only changed names. "
                 "observed_types is the recorded runtime schema checked against saved type choices, "
                 "separate from inferred imported_inventory types. No clinical column mapping, adapter "
                 "approval, current runtime verification or production qualification is supplied."}
    if not inventory["tables"]:
        return result
    result["state"] = "unavailable"
    def unavailable():
        result["links"] = []
        result["findings"] = [{"code": "configured_upload_evidence_unavailable",
            "message": "Current scoped upload and provisioning evidence cannot be linked. "
                       "Review the source table receipts, delivery and access; no source binding is inferred."}]
        return result
    try:
        pack = product.relative_to(root).as_posix()
        if allowed_packs is None or pack not in allowed_packs or not actor_id:
            return unavailable()
        authority = authoring_session.CURRENT.get()
        if authority is not None and authority.mode not in {"local", "demo"}:
            return unavailable()
        _scope, _identity, sources, _binding = source_provisioning._local_profile_inputs(
            root, pack, actor_id, allowed_packs)
        if len(cfg.sources) > source_table_intake.MAX_TABLES:
            return unavailable()
        expected_types = {"string": "string", "integer": "int", "long": "bigint", "double": "double",
                          "boolean": "boolean", "date": "date", "timestamp": "timestamp"}
        indexed = {}
        for name, item in sources.items():
            receipt, columns = item["receipt"], item["columns"]
            observed = receipt.get("observed_types")
            if (receipt.get("provisioned_by") != actor_id or not isinstance(observed, dict)
                    or observed != {column["name"]: expected_types[column["type"]] for column in columns}):
                return unavailable()
            target = item["qualified_table"]
            if target in indexed:
                return unavailable()
            indexed[target] = {"imported_table": name, "runtime_table": target,
                "upload_sha256": item["table"]["sha256"], "receipt_sha256": _digest(_encode(receipt)),
                "runtime_renames": {column["source"]: column["name"] for column in columns
                                    if column["source"] != column["name"]},
                "observed_types": deepcopy(observed)}
        for role in sorted(cfg.sources):
            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,127}", str(role)):
                return unavailable()
            target = cfg.table(role)
            if target not in indexed:
                result["findings"].append({"code": "configured_upload_table_unmatched", "role": role,
                    "message": "No unique current provisioning receipt matches this role's configured runtime table."})
                continue
            result["links"].append({"role": role, **deepcopy(indexed[target])})
        result["state"] = "unreviewed" if result["links"] else "unavailable"
        return result
    except (OSError, ValueError, KeyError, TypeError, AttributeError, yaml.YAMLError):
        # Only fixed recovery language enters AI context; the readers can include
        # private paths or upload details in their human-facing exceptions.
        result["links"] = []
        return unavailable()


def _workbook_source_bindings(product, cfg, *, root=None, actor_id=None, allowed_packs=None):
    """Expose imported column metadata separately from a reviewed adapter plan."""
    from experiments.portal import source_table_intake
    from rwd_tools import source_adapter
    inventory_file = _safe(product / source_table_intake.INVENTORY)
    raw = _read(inventory_file) if inventory_file.exists() else None
    inventory = source_table_intake.decode_inventory(raw)
    tables = [{"physical_table": table["physical_table"], "role_hint": table["role_hint"],
               "approval": "pending", "upload_sha256": table["sha256"],
               "columns": deepcopy(table["columns"])} for table in inventory["tables"]]
    plan = source_adapter.compiled(str(product))
    reviewed = plan.get("state") == "compiled" and not plan.get("problems")
    binding_problems = list(plan.get("problems") or [])
    if reviewed:
        if str(plan.get("schema")) != str(cfg.source_schema) or str(plan.get("cut")) != str(cfg.refresh):
            binding_problems.append("The reviewed adapter schema/cut differs from the configured delivery.")
        for role, table in plan["bindings"].items():
            if role not in cfg.sources or cfg.table(role) != table:
                binding_problems.append("The reviewed adapter table differs from the configured source role " + role + ".")
        reviewed = not binding_problems
    if reviewed:
        cfg.bind_sources(plan["bindings"], plan["digest"], plan.get("dataset"),
                         roles=plan["roles"], mapping_digest=plan.get("mapping_digest"))
    return {"sources": deepcopy(cfg.sources), "adapter_columns": deepcopy(cfg.adapter_columns),
        "reviewed_bindings": {"state": "mismatch" if plan.get("state") == "compiled" and binding_problems else plan.get("state", "absent"),
            "bindings": deepcopy(plan.get("bindings") or {}) if reviewed else {},
            "mapping_digest": plan.get("mapping_digest") if reviewed else None,
            "dataset": plan.get("dataset"), "schema": plan.get("schema"), "cut": plan.get("cut"),
            "problems": binding_problems,
            "scope": "A compiled mapping is a recorded adapter review, not authentication or delivered-data qualification."},
        **({"configured_upload_links": _workbook_configured_upload_links(
            root, product, cfg, actor_id, allowed_packs, inventory)} if tables else {}),
        "imported_inventory": {"state": "pending_review" if tables else "absent",
            "sha256": _digest(raw) if raw is not None else "", "tables": tables,
            "scope": "Column metadata only, without patient rows or samples. Role hints and inferred types are unapproved mapping choices; import does not authorize a source binding."}}


def _workbook_technical(cfg):
    """Read-only native facts, without observing or claiming delivered patient data."""
    import importlib
    import inspect
    from engine import source_contract, output_contract, validate as native_validation
    from engine.config import configured_demographics, native_treatment_enabled
    native_demographics = configured_demographics(cfg)
    native_treatment = native_treatment_enabled(cfg)
    sources = source_contract.compiled(cfg)
    columns = {}
    for role, row in sources["roles"].items():
        if not row["engine_reads"]:
            continue
        detail = {"required": row["required_columns"]}
        for key in ("optional_columns", "grain"):
            if row[key]:
                detail[key] = row[key]
        physical = {key: value for key, value in cfg.canonical_physical(role).items() if key != value}
        if physical:
            detail["physical"] = physical
        columns[role] = detail
    plan = output_contract.contract_spec(cfg)
    anchors, functions_by_stage = set(), {}
    for role in cfg.roles():
        if role not in native_validation.EXPECTED_ROLES:
            continue
        module = importlib.import_module("engine.stages." + role)
        functions = sorted("engine:" + name for name, value in inspect.getmembers(module, inspect.isfunction)
                           if not name.startswith("_") and name != "reads" and value.__module__ == module.__name__)
        anchors.update(functions)
        functions_by_stage["engine:" + role] = functions
    names = set(native_validation.emitted_variables(cfg))
    semantics = {}
    if native_demographics and "age" in names:
        semantics["age"] = "Native demographics.build emits age=year(index_date)-try_cast(birthyear as int); invalid/null birthyear gives null, no clamp. Bind engine:build; no AGE expression needed."
    if any(isinstance(rule, dict) and rule.get("method", "max") == "max" and rule.get("of")
           for rule in (cfg.index_dates or {}).values()):
        semantics["index_max"] = "index_dates max is row-wise greatest(of) on index_source; one present column is copied. No patient aggregation. Overall index keeps distinct patient/date/anchor tuples within inclusive entry dates."
    pairs = {label: code for label, code in (("agegrl", "agegrln"), ("race", "racen"),
             ("eth", "ethn"), ("regionl", "regionln"), ("practic", "practicn"), ("ecog", "ecogn"),
             ("lotngrl", "lotngrln")) if label in names and
             (native_demographics or label in {"ecog", "lotngrl"}) and
             (native_treatment or label != "lotngrl")}
    if pairs:
        semantics["label_to_code"] = pairs
        semantics["coded_outputs"] = ("Each left name is the native string label; its right name is the numeric code. "
            + ("age_bands supplies agegrl labels and agegrln codes from native year-only age before ads_derived runs; replacing age there does not recompute these groups. Use later typed bands for a revised age. " if native_demographics else "")
            + "New codes need source evidence or an owner decision.")
    if "treatment" in cfg.roles() and native_treatment:
        from engine.stages.treatment import line_cols
        semantics["line_columns"] = line_cols("{i}")
        semantics["line_selection"] = {"order": "non_maintenance_then_start_end_name", "no_selected_line": "null",
                                       "shared_outputs": list(line_cols("{i}").values())}
        semantics["line_outputs"] = "For i=1..max_lines: name=linename, start=startdate, end=enddate; lastdate=max drug-episode date, falling back to enddate; dur=inclusive days(lastdate-start). cat is the codelist label, catn its code. Maintenance inserts m after i."
        semantics["line_count"] = "lotn=max observed normalized line number per patient, or 0 with no line. max_lines limits detailed line columns, not lotn. lot_count_bands supplies lotngrl/lotngrln."
    if "outcomes" in cfg.roles():
        semantics["os"] = "When overall_survival is active, native outcomes emits numeric os; its anchors/gate and configured days_per_month determine the calculation. This does not claim the block is currently active."
        semantics["typed_calculations"] = "outcomes.ads_derived accepts {name,requires,calculation} using its supplied typed-node schema. The compiler lowers the tree; prose and model-written expr do not execute. Rows contribute named additions, merged in dependency order; identical repeats coalesce and different definitions for one output refuse. Existing entries are retained exactly. Use explicit column dependencies, supplied source rules and owner answers."
    if "clinical" in cfg.roles():
        semantics["source_copy"] = {"ref": "variables/clinical.yaml#/passthrough",
            "shape": {"source": "configured logical source role", "columns": [{"column": "declared source column", "as": "output name"}]},
            "scope": "Copies the declared column without inventing mappings or changing its type. Rows may contribute disjoint column additions only with identical source and other settings; existing columns are retained. Materialize needed source columns before typed ADS calculations. Source grain, selection and missingness still require review."}
    semantics["date_order"] = "qc.date_order adds {start,end} column pairs. Non-null start>end fails the output-contract build gate; equal or missing dates do not violate this check. It does not repair dates, impute missingness or approve science. Both columns must survive final publication. Existing checks remain."
    stage_dir = Path(native_validation.__file__).parent / "stages"
    return columns, {"configured_names": sorted(names), "key": plan["key"],
        "declared_types": plan["column_types"], "semantics": semantics,
        "functions_by_stage": functions_by_stage,
        "stages_by_function": {function: sorted(stage for stage, functions in functions_by_stage.items() if function in functions)
                               for function in sorted(anchors)},
        "capability_scope": "Configured native emissions are not approved publication decisions; an explicit publication whitelist may omit them.",
        "dependency_stages": ["engine:" + file.stem for file in sorted(stage_dir.glob("*.py"))
                              if file.stem != "__init__"]}, sorted(anchors), sources["problems"]


def _workbook_references(product, cfg):
    """Complete read-only product codelists; never a model-writable file catalog."""
    result = {}
    for key, relative in (cfg.raw.get("codelists") or {}).items():
        if not isinstance(relative, str) or not re.fullmatch(r"codelists/[A-Za-z][A-Za-z0-9_-]*\.ya?ml", relative):
            raise Invalid("Whole-workbook reference codelists must be product-local YAML files.")
        raw = _read(_safe(product / relative))
        value = _parse(raw.decode("utf-8"))
        if not isinstance(value, (dict, list)):
            raise Invalid("A read-only codelist must contain its complete structured values.")
        result[relative] = {"kind": "codelist", "config_key": key, "sha256": _digest(raw), "value": value}
    return result


def _workbook_source_facts(rows):
    """Recognize exact bounded source syntax; ambiguous prose yields no automatic fact."""
    result = {}
    for row in rows:
        evidence = row.get("evidence", {})
        rule = str(evidence.get("required_rule") or "")
        if re.search(r"\b(?:not|never|rather|instead|examples?|prior|previous|template|formerly|alternative|either)\b", rule, re.I):
            continue  # A mentioned value is not necessarily the operative instruction.
        citations = {"item_id": row["item_id"], "spec_digest": evidence.get("spec_digest", ""),
                     "spec_refs": evidence.get("spec_refs", [row["item_id"]]), "required_rule": rule,
                     "source_columns": evidence.get("_spec_columns", [])}
        facts = []
        def fact(kind, ref, value):
            facts.append({"kind": kind, "ref": ref, "value": value, "citations": deepcopy(citations)})
        if re.search(r"\bage\b", rule, re.I):
            from rwd_tools import spec_codelists
            candidates, explicit_codes = [], {}
            code_statement = re.search(r"\bNumeric codes:\s*([^.]*)\.?\s*$", rule, re.I)
            if code_statement:
                for segment in code_statement[1].split(";"):
                    entry = re.fullmatch(r"\s*(<\d+|<=\d+|>\d+|>=\d+|\d+-\d+|Unknown)\s*=\s*(\d+)\s*", segment)
                    if entry and entry[1] not in explicit_codes and int(entry[2]) not in explicit_codes.values():
                        explicit_codes[entry[1]] = int(entry[2])
                    else:
                        explicit_codes = {}
                        break
            for column in evidence.get("_spec_columns", []):
                if not isinstance(column, (list, tuple)) or len(column) != 2 or not re.search("value|categor|band", str(column[0]), re.I):
                    continue
                pairs, _missing, unread = spec_codelists._value_parts(str(column[1]))
                if (pairs and not unread and len({code for code, _label in pairs}) == len(pairs)
                        and len({label for _code, label in pairs}) == len(pairs)
                        and all(cb._age_label_bounds(label) is not None or label == "Unknown" for _code, label in pairs)):
                    explicit_codes.update({label: code for code, label in pairs})
                    labels = [label for _code, label in pairs if label != "Unknown"]
                else:
                    labels = [label.strip() for label in re.split(r"[/;]", str(column[1])) if label.strip()]
                if labels and all(cb._age_label_bounds(label) is not None for label in labels):
                    candidates.append(labels)
            if len(candidates) == 1:
                bands = []
                for label in candidates[0]:
                    low, high = cb._age_label_bounds(label)
                    bands.append({"label": label, **({"code": explicit_codes[label]} if label in explicit_codes else {}), **({"min": low} if low is not None else {}),
                                  **({"max": high} if high is not None else {})})
                if re.search(r"\bmissing\s+age\s+(?:is|=)\s+Unknown\b", rule, re.I):
                    # All integer ages must be covered for fallthrough to mean only missing.
                    bounds = [cb._age_label_bounds(label) for label in candidates[0]]
                    if (bounds[0][0] is None and bounds[-1][1] is None
                            and all(left[1] is not None and right[0] == left[1] + 1 for left, right in zip(bounds, bounds[1:]))):
                        bands.append({"label": "Unknown", "when": "fallthrough",
                                      **({"code": explicit_codes["Unknown"]} if "Unknown" in explicit_codes else {})})
                fact("age_bands", "variables/demographics.yaml#/age_bands", bands)
        if re.search(r"\bECOG\b", rule, re.I):
            window = _workbook_literal_index_window(rule)
            if window is not None:
                value = {"window_days": window}
                if re.search(r"equidistant\s+(?:grades\s+)?(?:use|take)\s+(?:the\s+)?worst\s+value", rule, re.I):
                    value["equidistant"] = "worst_value"
                if re.search(r"then\s+(?:the\s+)?earliest\s+date", rule, re.I):
                    value["tie_break"] = "earliest_date"
                fact("ecog_settings", "variables/clinical.yaml#/baseline_ecog", value)
        for key in ("days_per_month", "visit_recency_days", "min_followup_days"):
            matches = re.findall(r"\b" + key + r"\s*(?:=|:|is)\s*(\d+(?:\.\d+)?)\b", rule, re.I)
            if key == "days_per_month" and re.search(r"\boverall\s+survival\b", rule, re.I):
                matches += re.findall(r"\bdivided\s+by\s+(\d+(?:\.\d+)?)\b", rule, re.I)
            if key == "visit_recency_days":
                matches += re.findall(r"\b(\d+)-day\s+visit-recency\b", rule, re.I)
            if len(set(matches)) == 1:
                number = float(matches[0])
                if number > 0 and (key == "days_per_month" or number.is_integer()):
                    fact("native_scalar", "variables/outcomes.yaml#/" + key, int(number) if number.is_integer() else number)
        if facts:
            result[row["item_id"]] = facts
    return result


def _workbook_line_selection_parent(row, source, semantics):
    values = row.get("values")
    output = values.get("output") if isinstance(values, dict) else None
    physical = output.get("physical_name", "") if isinstance(output, dict) else ""
    match = re.fullmatch(r"lot(\d+)(?:sd|ld|ed|dur|cat|catn)?", str(physical))
    if not match or semantics.get("line_selection", {}).get("order") != "non_maintenance_then_start_end_name":
        return None
    parents = [entry for entry in source.values() if str(entry.get("variable_id", "")).lower() == "lot" + match[1]]
    if len(parents) != 1:
        return None
    parent = parents[0]
    rule = str(parent.get("evidence", {}).get("required_rule") or "")
    if (re.search(r"\b(?:not|never|rather|instead|example|previous|template|alternative)\b", rule, re.I)
            or not re.search(r"preferr?ing\s+non-maintenance\s+then\s+earliest\s+start,\s*earliest\s+end\s+and\s+name", rule, re.I)):
        return None
    return parent


def _workbook_related_rows(rows):
    """Link explicit variable references and native line families without choosing a rule."""
    names = {}
    for row in rows:
        name = str(row.get("variable_id") or "")
        if re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", name):
            names.setdefault(name.casefold(), []).append(row)
    links = []
    for row in rows:
        rule = str(row.get("evidence", {}).get("required_rule") or "")
        targets = [other[0]["item_id"] for name, other in names.items() if len(other) == 1
                   and other[0]["item_id"] != row["item_id"]
                   and re.search(r"(?<![A-Za-z0-9_])" + re.escape(name) + r"(?![A-Za-z0-9_])", rule, re.I)]
        match = re.fullmatch(r"LOT(\d+)(?:[A-Z_]*)", str(row.get("variable_id") or "").upper())
        if match:
            parent = names.get("lot" + match[1], [])
            if len(parent) == 1 and parent[0]["item_id"] != row["item_id"]:
                targets.append(parent[0]["item_id"])
        if targets:
            links.append({"item_id": row["item_id"], "related_item_ids": sorted(set(targets)),
                          "rule": "Read these original requirements together; related names alone do not prove equivalent calculation or approval."})
    return links


def _workbook_question_fields(question, variable=""):
    """Recognize complete interface questions, never infer scope from English keywords."""
    text = question.get("question", "") if isinstance(question, dict) else str(question)
    text = str(text).replace("`", "").strip()
    if variable:
        text = re.sub(r"(?<![A-Za-z0-9_])" + re.escape(variable) + r"(?![A-Za-z0-9_])", "variable", text, flags=re.I)
    fields = set()
    role = r"(?:published|internal|metadata|excluded)"
    roles = role + r"(?:\s*(?:,|or|and)\s*" + role + r")*"
    destination = r"(?:ads|dictionary|dashboard|tfl)"
    destinations = destination + r"(?:\s*(?:,|or|and)\s*" + destination + r")*"
    explicit = re.fullmatch(r"For variable, which contract value should (output\.role|publish\.(?:ads|dictionary|dashboard|tfl)|output\.target_published_name) use\?", text, re.I)
    if explicit:
        fields.add(explicit[1].lower())
    elif (re.fullmatch(r"Which output\.role should variable use(?:\s*:\s*" + roles + r")?\?", text, re.I)
          or re.fullmatch(r"Should variable be " + roles + r"\?", text, re.I)):
        fields.add("output.role")
    elif (re.fullmatch(r"Should variable publish to " + destinations + r"\?", text, re.I)
          or re.fullmatch(r"Where should variable be published\?", text, re.I)
          or re.fullmatch(r"Which (?:output |publication )?destinations should variable use\?", text, re.I)):
        fields.update("publish." + destination for destination in WORKBOOK_DESTINATIONS)
    if isinstance(question, dict) and question.get("choices"):
        allowed = {"published", "internal", "metadata", "excluded"} if fields == {"output.role"} else {
            "ads", "dictionary", "dashboard", "tfl", "configured", "required", "proposed", "excluded", "undecided"}
        if any(str(choice).strip().lower() not in allowed for choice in question["choices"]):
            return []
    return sorted(fields)


def _workbook_source_output_type(evidence):
    types = []
    for column in evidence.get("_spec_columns", []):
        if isinstance(column, (list, tuple)) and len(column) == 2 and re.fullmatch(r"(?:data |declared )?type", str(column[0]).strip(), re.I):
            types.append(str(column[1]).strip().lower())
    rule = str(evidence.get("required_rule") or "")
    types.extend(re.findall(r"\b(?:output|data)\s+type\s*(?:is|=|:)\s*(integer|numeric|string|text|date|boolean)\b", rule, re.I))
    if len(set(types)) == 1:
        return types[0]
    return None


def _workbook_outer_typed_cast(item):
    """Return only a compiler-validated outer cast and its explicit result type."""
    from experiments.portal import variable_clinical_rules
    if not isinstance(item, dict) or not isinstance(item.get("calculation"), dict) or item["calculation"].get("op") != "cast":
        return None
    try:
        lowered = variable_clinical_rules.compile_workbook_calculation(item)
    except (ValueError, TypeError, KeyError):
        return None
    return lowered, {"integer": "integer", "long": "long", "number": "double",
                     "string": "string", "date": "date"}[item["calculation"]["type"]]


def correct_workbook_draft(records, *, context, schema, trusted_ai_item_ids, protected_fields=None):
    """Repair generated, unreviewed fields using exact source/engine facts or explicit policy.

    The caller proves model origin against its saved response history. This pure
    helper grants no origin rights, writes nothing and never changes existing
    human/approved records. Every mutation is returned with its original value.
    """
    result, repairs, findings = deepcopy(records), [], []
    source = {row["item_id"]: row for row in context.get("rows", [])}
    trusted = set(trusted_ai_item_ids)
    protected_fields = protected_fields or {}
    facts = _workbook_source_facts(list(source.values()))  # Never trust model-authored fact metadata.
    allowed = set(schema.get("native_refs", []))
    bindings = schema.get("implementation_bindings", {}).get("write_pointer_to_binding", {})
    native = context.get("native_outputs", {})
    semantics = native.get("semantics", {})
    stages = set(native.get("dependency_stages", []))
    functions = set(schema.get("implementation_anchors", []))
    stage_functions = native.get("functions_by_stage", {})
    function_stages = native.get("stages_by_function", {})
    def qualified_engine_reference(ref):
        match = re.fullmatch(r"engine:([A-Za-z][A-Za-z0-9_]*)[/#]([A-Za-z][A-Za-z0-9_]*)", ref) if isinstance(ref, str) else None
        if match:
            stage, function = "engine:" + match[1], "engine:" + match[2]
            declared = stage_functions.get(stage, [])
            if isinstance(declared, list) and function in functions and function in declared:
                return stage, function
        return None
    locked_refs = set()
    for source_row in source.values():
        if not source_row.get("retained"):
            continue
        for existing in source_row.get("existing_records", []):
            refs = existing.get("implementation_refs", [])
            if isinstance(refs, str):
                try:
                    refs = yaml.safe_load(refs)
                except yaml.YAMLError:
                    refs = []
            if isinstance(refs, list):
                locked_refs.update(ref for ref in refs if isinstance(ref, str) and "#/" in ref)
    ids = {}
    for row in result:
        values = row.get("values")
        if isinstance(values, dict) and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", str(values.get("variable_id") or "")):
            ids.setdefault(row.get("item_id"), []).append(values["variable_id"])
    name_counts = {}
    for names in ids.values():
        for name in names:
            name_counts[name.casefold()] = name_counts.get(name.casefold(), 0) + 1
    def unanswered(value):
        return value is None or isinstance(value, str) and value.strip().casefold() in {"", "todo", "tbd", "undecided", "not decided"}
    def effective(ref, row):
        for change in row.get("configuration_changes", []):
            if change.get("ref") == ref:
                return deepcopy(change.get("value"))
        relative, pointer = ref.split("#/", 1)
        value = context.get("native_configuration", {}).get(relative)
        for key in pointer.split("/"):
            value = value.get(key) if isinstance(value, dict) else None
        return deepcopy(value)
    for row in result:
        item, values = row.get("item_id"), row.get("values")
        original = source.get(item)
        if (item not in trusted or not original or original.get("retained") or original.get("existing_records")
                or not isinstance(values, dict)):
            continue
        def protected(path):
            return any(field == "*" or path == field or path.startswith(field + ".") or field.startswith(path + ".")
                       or path.startswith(field + "/") or field.startswith(path + "/")
                       for field in protected_fields.get(item, []))
        def change_field(parent, key, value, origin, citations, path):
            if protected(path) and not (origin == "engine_interface" and path in {"depends_on", "implementation_refs"}):
                return
            prior = deepcopy(parent.get(key))
            if _encode(prior) != _encode(value) or key not in parent:
                parent[key] = deepcopy(value)
                repairs.append({"item_id": item, "field": path, "before": prior, "after": deepcopy(value),
                                "origin": origin, "citations": deepcopy(citations)})
        def configure(ref, value, citation):
            if (ref not in allowed or protected(ref) or protected("configuration_changes")
                    or any(ref == locked or ref.startswith(locked + "/") or locked.startswith(ref + "/") for locked in locked_refs)):
                return False
            changes = row.setdefault("configuration_changes", [])
            prior = effective(ref, row)
            if _encode(prior) != _encode(value):
                old = next((entry for entry in changes if entry.get("ref") == ref), None)
                if old is None:
                    changes.append({"ref": ref, "value": deepcopy(value)})
                else:
                    old["value"] = deepcopy(value)
                repairs.append({"item_id": item, "field": ref, "before": prior, "after": deepcopy(value),
                                "origin": "source", "citations": deepcopy(citation)})
            return True
        evidence = original.get("evidence", {})
        cite = {"item_id": item, "spec_refs": evidence.get("spec_refs", [item]), "spec_digest": evidence.get("spec_digest", "")}
        dependencies = values.get("depends_on")
        qualified_dependency = qualified_engine_reference(dependencies)
        if isinstance(dependencies, str) and (dependencies in stages
                or dependencies in functions and len(function_stages.get(dependencies, [])) == 1
                    and function_stages[dependencies][0] in stages
                or qualified_dependency is not None and qualified_dependency[0] in stages):
            dependencies = [dependencies]
        if isinstance(dependencies, list):
            fixed, proofs = [], []
            for dependency in dependencies:
                replacement = dependency
                matches = ids.get(dependency, []) if isinstance(dependency, str) else []
                qualified = qualified_engine_reference(dependency)
                if len(matches) == 1 and name_counts[matches[0].casefold()] == 1:
                    replacement = matches[0]
                elif qualified is not None and qualified[0] in stages:
                    replacement = qualified[0]
                    proofs.append({"supplied_ref": dependency, "stage": qualified[0], "function": qualified[1]})
                elif (isinstance(dependency, str) and dependency not in stages
                      and len(function_stages.get(dependency, [])) == 1 and function_stages[dependency][0] in stages):
                    replacement = function_stages[dependency][0]
                if replacement not in fixed:
                    fixed.append(replacement)
            change_field(values, "depends_on", fixed, "engine_interface",
                         {**cite, **({"native_function_pairs": proofs} if proofs else {})}, "depends_on")
        refs = values.get("implementation_refs")
        if isinstance(refs, str) and (refs in functions or qualified_engine_reference(refs) is not None
                or refs in stages and "engine:build" in functions and "engine:build" in stage_functions.get(refs, [])):
            refs = [refs]
        if isinstance(refs, list):
            fixed, proofs = [], []
            for ref in refs:
                replacement = bindings.get(ref, ref) if isinstance(ref, str) else ref
                qualified = qualified_engine_reference(ref)
                if qualified is not None:
                    replacement = qualified[1]
                    proofs.append({"supplied_ref": ref, "stage": qualified[0], "function": qualified[1]})
                elif (isinstance(ref, str) and ref in stages and ref not in functions
                      and "engine:build" in functions and "engine:build" in stage_functions.get(ref, [])):
                    replacement = "engine:build"
                if replacement not in fixed:
                    fixed.append(replacement)
            change_field(values, "implementation_refs", fixed, "engine_interface",
                         {**cite, **({"native_function_pairs": proofs} if proofs else {})}, "implementation_refs")
        output = values.get("output")
        if isinstance(output, dict):
            physical = str(output.get("physical_name") or "")
            paired = semantics.get("label_to_code", {})
            known_type = "string" if physical in paired else "integer" if physical in paired.values() else None
            typed_override = any(isinstance(change, dict)
                and change.get("ref") == "variables/outcomes.yaml#/ads_derived" and change["ref"] in allowed
                and isinstance(change.get("value"), list)
                and any(isinstance(item, dict) and isinstance(item.get("name"), str)
                        and item["name"].casefold() == physical.casefold() and _workbook_outer_typed_cast(item)
                        for item in change["value"])
                for change in row.get("configuration_changes", []))
            # Keep the proposed type, including a potentially wrong one, for
            # canonical final-producer and original-source validation below.
            if known_type and not typed_override:
                from engine.output_contract import type_family
                source_type = _workbook_source_output_type(evidence)
                if source_type and type_family(source_type) != type_family(known_type):
                    findings.append(_workbook_finding("source_output_representation", "The workbook declares " + source_type +
                        " but " + physical + " is a native " + known_type + " output. Choose the matching label/code column explicitly.",
                        item_id=item, field="output.physical_name"))
                elif type_family(str(output.get("type") or "")) != type_family(known_type):
                    change_field(output, "type", known_type, "engine_interface", {"native_output": physical}, "output.type")
            age_rule = str(evidence.get("required_rule") or "")
            if (physical == "age" and "age" in semantics and "engine:build" in functions
                    and re.fullmatch(r"Age equals the index calendar year minus the delivered birth year; nonnumeric birth year gives null\.?", age_rule, re.I)
                    and values.get("implementation_refs") in ([], ["none"])):
                change_field(values, "implementation_refs", ["engine:build"], "engine_interface", {"native_output": "age"}, "implementation_refs")
        parent = _workbook_line_selection_parent(row, source, semantics)
        linked_resolved = False
        if parent:
            child_rule = str(evidence.get("required_rule") or "")
            parent_rule = parent["evidence"]["required_rule"]
            linked_cite = {"parent_item_id": parent["item_id"], "parent_spec_digest": parent["evidence"].get("spec_digest", ""),
                           "parent_rule": parent_rule, **cite, "native_reader": "engine.stages.treatment._line_frame"}
            if re.search(r"\b(?:latest|last|recent)\s+(?:line\s+)?(?:start|regimen|treatment)|\bprefer\w*\s+maintenance\b", child_rule, re.I):
                findings.append(_workbook_finding("linked_selection_conflict", "This line output states a selection that conflicts with its original line definition "
                    + parent["variable_id"] + ". Resolve the two source instructions before copying a selection.", item_id=item, field="record_selection"))
            else:
                change_field(values, "record_selection", "Use the same selected delivered line as " + parent["variable_id"] + ": " + parent_rule,
                             "linked_source", linked_cite, "record_selection")
                change_field(values, "tie_break", "Prefer non-maintenance, then earliest start, earliest end and name; native final category order resolves otherwise identical rows.",
                             "linked_source", linked_cite, "tie_break")
                if isinstance(output, dict):
                    change_field(output, "nullable", True, "native_join", linked_cite, "output.nullable")
                prior_missing = values.get("missing")
                missing = deepcopy(prior_missing) if isinstance(prior_missing, dict) else {}
                if isinstance(prior_missing, str) and prior_missing.strip().lower() not in {"", "todo", "none", "n/a", "null"}:
                    missing["selected_line"] = prior_missing
                missing["no_selected_line"] = "null"
                change_field(values, "missing", missing, "native_join", linked_cite, "missing")
                linked_resolved = not protected("record_selection") and not protected("tie_break")
        scientific_refs = []
        for fact in facts.get(item, []):
            ref, value, kind = fact["ref"], deepcopy(fact["value"]), fact["kind"]
            if ref not in allowed:
                continue
            if protected("derivation") or protected("configuration_changes") or protected(ref):
                continue
            if kind == "ecog_settings":
                if protected("window") or protected("source"):
                    continue
                current = effective(ref, row)
                if not isinstance(current, dict):
                    findings.append(_workbook_finding("source_settings_need_operator", "The source timing is explicit; the remaining ECOG operator fields need a supported typed draft.", item_id=item, field=ref))
                    continue
                value = {**current, **value}
                change_field(values, "window", str(fact["value"]["window_days"]) + " days relative to index", "source", fact["citations"], "window")
                missing = re.search(r"\bNo record is Missing and a present null is Unknown\b", fact["citations"]["required_rule"], re.I)
                if missing:
                    change_field(values, "missing", missing.group(0) + ".", "source", fact["citations"], "missing")
                if re.search(r"\bChoose\s+(?:the\s+)?closest\s+ECOG\b", fact["citations"]["required_rule"], re.I):
                    change_field(values, "record_selection", "Closest ECOG to index within the source day window.", "source", fact["citations"], "record_selection")
                if fact["value"].get("equidistant") == "worst_value" and fact["value"].get("tie_break") == "earliest_date":
                    change_field(values, "tie_break", "At equal distance use the worst grade, then earliest date.", "source", fact["citations"], "tie_break")
            elif kind == "age_bands":
                if protected("output.codes"):
                    continue
                if any(branch.get("label") == "Unknown" and branch.get("when") == "fallthrough" for branch in value):
                    change_field(values, "missing", "Missing age is Unknown.", "source", fact["citations"], "missing")
                if isinstance(output, dict):
                    codes = {str(branch["code"]): branch["label"] for branch in value if "code" in branch}
                    change_field(output, "codes", codes if len(codes) == len(value) else "TODO",
                                 "source", fact["citations"], "output.codes")
                # Never carry template or model-invented numeric codes into a
                # source that states labels only. The engine needs codes, so the
                # resulting explicit question remains a readiness block.
                question = {"question": "Which numeric codes should accompany the source age-band labels, including any stated missing category? The workbook supplies labels but no numeric codes.", "choices": []}
                if any("code" not in branch for branch in value) and question not in row.setdefault("questions", []) and not protected("questions"):
                    row["questions"].append(question)
                    repairs.append({"item_id": item, "field": "questions", "before": None, "after": deepcopy(question), "origin": "source", "citations": fact["citations"]})
                elif all("code" in branch for branch in value) and question in row.setdefault("questions", []):
                    change_field(row, "questions", [entry for entry in row["questions"] if entry != question], "source", fact["citations"], "questions")
            if configure(ref, value, fact["citations"]):
                scientific_refs.append(bindings.get(ref, ref))
                if kind in {"ecog_settings", "age_bands"}:
                    change_field(values, "derivation", fact["citations"]["required_rule"], "source", fact["citations"], "derivation")
                if kind == "native_scalar" and ref.endswith("#/days_per_month") and re.search(r"\boverall\s+survival\b", fact["citations"]["required_rule"], re.I):
                    change_field(values, "units", "months", "source", fact["citations"], "units")
                    gate = re.search(r"\bWhen\s+([A-Za-z][A-Za-z0-9_]*)\s+is\s+1,.*;\s*otherwise\s+null\b", fact["citations"]["required_rule"], re.I)
                    if gate:
                        change_field(values, "missing", "Null when " + gate[1] + " is not 1; missing patient anchor values propagate through the native survival calculation.",
                                     "source", fact["citations"], "missing")
        if scientific_refs and isinstance(values.get("implementation_refs"), list):
            refs = [ref for ref in values["implementation_refs"] if ref != "none"]
            refs.extend(ref for ref in scientific_refs if ref not in refs)
            change_field(values, "implementation_refs", refs, "source_binding", cite, "implementation_refs")
        saved = context.get("drafting_policy", {})
        policy = _workbook_policy_value(saved["policy"]) if saved.get("configured") else None
        source_kind = values.get("source", {}).get("kind") if isinstance(values.get("source"), dict) else None
        if (policy and isinstance(output, dict) and source_kind != "parameter"
                and output.get("role") not in {"metadata", "excluded"}
                and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", str(output.get("physical_name") or ""))
                and str(output.get("physical_name")).casefold() not in {"none", "todo", "undecided"}):
            policy_cite = {"policy_digest": saved.get("policy_digest", ""), "recorded_by": saved.get("recorded_by", "")}
            if unanswered(output.get("role")) and policy["default_output_role"] is not None:
                change_field(output, "role", policy["default_output_role"], "owner_product_policy", policy_cite, "output.role")
            if unanswered(output.get("target_published_name")):
                change_field(output, "target_published_name", output["physical_name"], "owner_product_policy", policy_cite, "output.target_published_name")
            publish = values.get("publish")
            if isinstance(publish, dict):
                for destination in sorted(WORKBOOK_DESTINATIONS):
                    if unanswered(publish.get(destination)):
                        change_field(publish, destination, "proposed" if destination in policy["destinations"] else "excluded",
                                     "owner_product_policy", policy_cite, "publish." + destination)
        # Only narrowly identified publication questions whose exact fields
        # now have explicit answers can retire. Mixed science questions remain.
        questions = row.get("questions", [])
        unique = []
        resolved_scopes, seen_scopes = set(), set()
        for question in questions:
            fields = _workbook_question_fields(question, str(values.get("variable_id") or ""))
            question_text = question.get("question", "") if isinstance(question, dict) else str(question)
            if (linked_resolved and re.search(r"\b(?:ordering|tie.break|row.selection)\b", question_text, re.I)
                    and not re.search(r"\b(?:cohort|eligib\w*|missing\w*|null\w*|window|codes?|publish\w*|scope|acceptance)\b", question_text, re.I)):
                resolved_scopes.update({"record_selection", "tie_break"})
                continue
            answered = bool(policy and fields)
            for field in fields:
                parent, key = field.split(".")
                current = values.get(parent)
                answered = answered and isinstance(current, dict) and not unanswered(current.get(key))
                if parent == "publish":
                    answered = answered and isinstance(current, dict) and current.get(key) in {"configured", "required", "proposed", "excluded"}
                elif field == "output.role":
                    answered = answered and isinstance(current, dict) and current.get(key) in {"published", "internal", "metadata", "excluded"}
            if answered:
                resolved_scopes.update(fields)
                continue
            if fields:
                scope = tuple(fields)
                if scope in seen_scopes:
                    continue
                seen_scopes.add(scope)
            if question not in unique:
                unique.append(question)
        if unique != questions:
            change_field(row, "questions", unique, "answered_product_policy" if resolved_scopes else "interface_deduplication",
                         {**cite, "resolved_fields": sorted(resolved_scopes)}, "questions")
    return {"records": result, "repairs": repairs, "findings": findings}


def _workbook_context_ingress(value, *, native_columns):
    """Keep verified column-name lists distinct from patient label/value text."""
    from experiments.portal import scientific_definition_ai as ai
    screened = deepcopy(value)
    bindings = screened.get("source_bindings") if isinstance(screened, dict) else None
    supplied = bindings.get("native_columns") if isinstance(bindings, dict) else None
    if isinstance(bindings, dict):
        # Preserve field boundaries in names-only schema metadata. Flattening
        # {name: patientid, type: string} fabricates a patient-id/value pair.
        # The full text still passes ingress; no sample or unknown container is
        # excluded from screening.
        for field in ("imported_inventory", "adapter_columns", "reviewed_bindings", "configured_upload_links"):
            if field in bindings:
                bindings[field] = json.dumps(bindings[field], ensure_ascii=False, separators=(",", ":"))
    if isinstance(supplied, dict) and isinstance(native_columns, dict):
        for role, detail in supplied.items():
            expected = native_columns.get(role)
            if not isinstance(detail, dict) or not isinstance(expected, dict):
                continue
            for field in ("required", "optional_columns", "grain"):
                names = detail.get(field)
                if (isinstance(names, list) and _encode(names) == _encode(expected.get(field))
                        and all(isinstance(name, str) and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,127}", name)
                                for name in names)):
                    # Flattening two independent identifiers across a newline can
                    # fabricate "patientid <value>". Delimit only these exact
                    # engine-derived names; source rows and unknown lists retain
                    # the ordinary ingress representation and checks.
                    detail[field] = ", ".join(names)
    ai._ingress(ai._plain(screened))


def workbook_context(root, pack, *, actor_id, allowed_packs=None):
    """Fresh AI-authorized workbook evidence; never an approval or a write."""
    try:
        from experiments.portal import scientific_definitions as science
        from experiments.portal import scientific_definition_ai as ai
        from rwd_tools import contract_scaffold as scaffold, spec_lint
        base, product, name, _owner, _folder = _workbook_scope(root, pack, actor_id, allowed_packs)
        try:
            scaffold.ai_gate(str(product))
        except scaffold.NotApprovedForAI as error:
            # The typed refusal identifies the access check. Its long diagnostic
            # belongs in local review details, not the bounded model-facing text.
            message = ("AI drafting is blocked because the extracted specification has not passed its AI access review. "
                       "Open extracted source access to review its recorded decision and current checks.")
            return {"ok": False, "ready": False, "errors": [message],
                "findings": [_workbook_finding("source_ai_access_required", message, kind="source")],
                "source_access_details": str(error), "notice": WORKBOOK_NOTICE}
        initial = _workbook_snapshot(base, product, actor_id=actor_id)
        data = science._json(_read(product / "spec_pipeline/out/extracted.json"))
        if not isinstance(data, dict) or not isinstance(data.get("rows"), list) or not data["rows"]:
            raise Invalid("The current extraction has no workbook rows. Extract the specification first.")
        raw_rows = list(scaffold.requirement_rows(data))
        findings = []
        for error in scaffold.extraction_integrity(data, None, None):
            findings.append(_workbook_finding("extraction_integrity", error, kind="source"))
        lint = spec_lint.scan(data)
        for finding in lint:
            if finding.get("severity") == "HIGH":
                findings.append(_workbook_finding("source_" + finding["kind"].lower(), finding["detail"],
                    item_id=finding.get("item_id", ""), kind="source"))
        contract = _read(product / "handoff/FUNCTIONAL_CONTRACT.md").decode("utf-8")
        if science.cl.table_shape_errors(contract) or list(science.cl._fenced_blocks(contract)):
            raise Invalid("Repair the existing contract table before preparing a whole-workbook draft.")
        existing = list(science.cl.typed_records(contract))
        ids = [record.variable_id.casefold() for record in existing]
        if len(set(ids)) != len(ids) or any(not identity for identity in ids):
            raise Invalid("Existing contract records have ambiguous identifiers. Resolve them before drafting the workbook.")
        cfg, documents, allowed = _workbook_native(product)
        source_bindings = _workbook_source_bindings(product, cfg, root=base, actor_id=actor_id, allowed_packs=allowed_packs)
        native_columns, native_outputs, anchors, read_problems = _workbook_technical(cfg)
        source_bindings["native_columns"] = native_columns
        rows, seen, locked = [], set(), []
        for row in raw_rows:
            item_id = scaffold.row_item_id(row)
            if item_id in seen:
                raise Invalid("The extraction repeats a row identifier. Correct the workbook mapping before drafting.")
            seen.add(item_id)
            evidence = scaffold.evidence_for(str(product), item_id, data=data, lint_findings=lint, reader="ai")
            matches = [record for record in existing if item_id in science.cl.spec_ref_ids(science.cl._list(record.raw, "spec_refs") or [])]
            retained = any(record.axis("requirement") == "approved" for record in matches)
            if retained:
                locked.append(item_id)
            if not str(row.get("variable") or "").strip() and not scaffold.is_context(row):
                findings.append(_workbook_finding("unnamed_source_row", "This workbook row needs a variable identifier or a reviewed document-context disposition.", item_id=item_id, kind="source"))
            rows.append({"item_id": item_id, "variable_id": row.get("variable") or "", "evidence": evidence,
                "is_context": bool(scaffold.is_context(row)), "retained": retained,
                "existing_records": [dict(record.cells) for record in matches], "native_refs": sorted(allowed)})
        projected = {}
        for entry in allowed.values():
            source = documents[entry["file"]]
            for key in entry["keys"]:
                if not isinstance(source, dict) or key not in source:
                    break
                source = source[key]
            else:
                target = projected.setdefault(entry["file"], {})
                for key in entry["keys"][:-1]:
                    target = target.setdefault(key, {})
                target[entry["keys"][-1]] = deepcopy(source)
        payload = {"rows": rows, "source_row_catalog": [{"item_id": row["item_id"], "variable_id": row["variable_id"]} for row in rows],
            "drafting_policy": _workbook_policy_read(product, name),
            "source_facts": _workbook_source_facts(rows), "related_row_plan": _workbook_related_rows(rows),
            "native_references": _workbook_references(product, cfg),
            "existing_records": [dict(record.cells) for record in existing],
            "native_configuration": projected, "locked_item_ids": locked,
            "native_configuration_scope": "Complete editable native calculation subtrees. Read-only product identity, delivery, maturity and approval metadata are omitted and cannot be changed; validation uses the complete original product.",
            "source_bindings": source_bindings, "native_outputs": native_outputs,
            "native_facts_scope": "Native read requirements and configured outputs, not observed data or approvals. ADS key is patient/cohort/index episode. Empty adapter_columns means no reviewed adapter is bound, not no known columns. Types appear only when explicitly declared; other types remain unproven. Engine anchors establish available syntax, not scientific equivalence.",
            "native_read_findings": read_problems}
        _workbook_context_ingress(payload, native_columns=native_columns)
        if initial != _workbook_snapshot(base, product, actor_id=actor_id):
            raise Invalid("The source or native readers changed while preparing workbook context. Reload it.")
        # These are operator inputs, never model-editable scientific fields. Surface
        # their absence once before drafting without treating a partial draft as ready.
        execution_setup = {key: label for key, label in (("source_schema", "source schema"),
            ("refresh", "delivery cut"), ("output_schema", "output schema"))
            if not isinstance(cfg.run.get(key), str) or not cfg.run[key].strip()
            or re.search(r"REPLACE_ME|\bTODO\b", cfg.run[key], re.I)}
        optional_treatment = []
        if (cfg.raw.get("status") in {"scaffold", "draft"} and cfg.raw.get("request_type") == "new_product"
                and not locked):
            if "demographics" in cfg.roles() and cfg.pack("demographics").get("status") in {"scaffold", "draft"}:
                from engine.config import configured_demographics
                if configured_demographics(cfg):
                    optional_treatment.append("legacy_demographics")
            if "treatment" in cfg.roles() and cfg.pack("treatment").get("status") in {"scaffold", "draft"}:
                from engine.config import native_treatment_enabled
                if native_treatment_enabled(cfg):
                    optional_treatment.append("legacy_treatment")
                if native_treatment_enabled(cfg) and cfg.pack("treatment").get("line_categories_enabled", True) is not False:
                    optional_treatment.append("line_categories")
                if (cfg.raw.get("treatment_status") or {}).get("enabled", True) is not False:
                    optional_treatment.append("treatment_status")
            if ({"clinical", "outcomes"} <= set(cfg.roles())
                    and all(cfg.pack(role).get("status") in {"scaffold", "draft"} for role in ("clinical", "outcomes"))):
                from engine.config import clinical_followup_enabled, minimum_followup_enabled
                if (clinical_followup_enabled(cfg) or minimum_followup_enabled(cfg)
                        or cfg.pack("outcomes").get("overall_survival")):
                    optional_treatment.append("legacy_survival")
        return {"ok": True, "input_digest": initial, "row_count": len(rows), "locked_item_ids": locked,
            "unresolved_execution_setup": execution_setup, "optional_treatment_outputs": optional_treatment,
            "context": payload, "findings": findings, "write_schema": {"schema_version": 1,
                "record_keys": ["item_id", "values", "configuration_changes", "questions"],
                "judgment_fields": list(science.FIELDS), "native_refs": sorted(allowed),
                "implementation_anchors": anchors,
                "judgment_shape": science.starting_values("VARIABLE"),
                "judgment_constraints": _workbook_judgment_constraints(),
                "implementation_bindings": _workbook_bindings(product, allowed),
                "configuration_change": {"shape": {"ref": "one supplied native ref", "value": "complete JSON value matching that ref's schema"}, "no_change": []},
                "native_schema": _workbook_schemas(allowed),
                "schema_scope": "Placeholders in judgment_shape are unanswered fields, not values to adopt. The packaged structural schema is partial; native semantic validators also run. Scientific values come only from the current source and explicit owner answers.",
                "machine_owned": [*scaffold.MACHINE_OWNED, "status"],
                "unchangeable_native_controls": sorted(WORKBOOK_RAW_CONTROLS),
                "preserve": "values=null and no changes preserves current records; every item_id occurs exactly once",
                "rule": "Use native typed values only. outcomes.ads_derived accepts bounded calculation trees lowered by the compiler, never model-authored expr. clinical.passthrough copies declared source columns; baseline_ecog selects the configured dated record. Source columns need their explicit logical mapping; imported role hints do not approve that mapping. Unknown clinical choices are questions, never invented defaults. Approved records and their configured rules remain unchanged."}, "notice": WORKBOOK_NOTICE}
    except Exception as error:
        return {"ok": False, "ready": False, "errors": [" ".join(_workbook_finding("context", error, kind="source")["message"].split())],
            "findings": [_workbook_finding("context_unavailable", error, kind="source")], "notice": WORKBOOK_NOTICE}


def _workbook_json(value):
    raw = json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
    if len(raw.encode("utf-8")) > LIMIT:
        raise Invalid("The workbook draft exceeds its bounded candidate size.")
    return json.loads(raw)


def _workbook_os_errors(block):
    """The native OS reader consumes exactly its three anchors and optional gate."""
    from engine import validate as native_validation
    if not isinstance(block, dict):
        return []  # The native structural validator handles disabled/invalid block types.
    fields = {*native_validation.OS_ANCHORS, "gate"}
    errors = []
    unknown = sorted(set(block) - fields)
    if unknown:
        errors.append("OS overall_survival has unsupported fields: " + ", ".join(unknown)
                      + ". These fields are not read by the native calculation.")
    for key in fields & set(block):
        if not isinstance(block[key], str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,127}", block[key]):
            errors.append("OS overall_survival." + key + " must name one plain column identifier; raw expressions are not supported.")
    return errors


def _workbook_judgment(values):
    """Preserve known draft answers; missing fields keep canonical TODO markers."""
    from experiments.portal import scientific_definitions as science
    if not isinstance(values, dict) or not set(values) <= set(science.FIELDS) or "variable_id" not in values:
        raise Invalid("Supply judgment fields with an explicit variable_id; source evidence and statuses are machine-owned.")
    result = science.starting_values(values["variable_id"])
    for field, value in values.items():
        if value is None:
            continue
        if field != "variable_id" and isinstance(value, str) and not value.strip() and (
                isinstance(result[field], str) and science._placeholder(result[field])):
            continue  # A blank required scalar is the same unanswered TODO as an omitted scalar.
        if field in {"output", "publish"} and isinstance(value, dict):
            for key, child in value.items():
                if child is None:
                    continue
                default = result[field].get(key)
                if isinstance(child, str) and not child.strip() and isinstance(default, str) and (
                        science._placeholder(default) or default == "undecided"):
                    continue
                result[field][key] = deepcopy(child)
        else:
            result[field] = deepcopy(value)
    return science._values(result)


def _workbook_unanswered(values):
    """Use the canonical placeholder vocabulary only on human judgment values."""
    from experiments.portal import scientific_definitions as science
    stub = science.starting_values(values["variable_id"])
    fields = []
    def walk(value, path, default=None):
        if isinstance(value, dict):
            for key, child in value.items():
                walk(child, path + "." + key, default.get(key) if isinstance(default, dict) else None)
        elif isinstance(value, list):
            for index, child in enumerate(value):
                walk(child, path + "[" + str(index) + "]")
        elif isinstance(value, str) and (science.cl.TODO_RE.search(value)
                or science.cl.PLACEHOLDER_VALUE_RE.fullmatch(value.strip())):
            fields.append(path)
        elif isinstance(default, str) and science._placeholder(value):
            # A blank canonical scalar is unanswered, including an explicit
            # blank replacing the stub's TODO. Real none/n/a answers stay valid.
            fields.append(path)
        elif isinstance(value, str) and value.strip() == "undecided" and (
                (default == "undecided" and path != "output.name_status") or path == "output.type"):
            # Publication intent and data type need an answer. Naming review
            # may remain pending on an unapproved draft; do not fake alignment.
            # A clinical code label 'undecided' is also literal evidence.
            fields.append(path)
    for field in science.FIELDS:
        if field != "variable_id":
            walk(values[field], field, stub.get(field))
    return sorted(fields)


def _workbook_named_additions(existing, additions, *, column=False):
    """Union exact named entries; omission never deletes an existing entry."""
    if not isinstance(existing, list) or not isinstance(additions, list):
        raise ValueError("Named calculation and source-column additions must be lists.")
    result, names = [], {}
    for items in (existing, additions):
        if len(items) > 256:
            raise ValueError("Review at most 256 named additions in one configuration block.")
        seen = set()
        for item in items:
            name = None
            if isinstance(item, dict):
                name = item.get("as", item.get("column")) if column else item.get("name")
            if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,127}", name):
                raise ValueError("Each addition needs a plain output column identifier.")
            key = name.casefold()
            if key in seen:
                raise ValueError("An addition list repeats output " + name + ".")
            seen.add(key)
            if key in names:
                if names[key] != item:
                    raise ValueError("Different definitions target output " + name + "; review that choice explicitly.")
                continue
            names[key] = item
            result.append(deepcopy(item))
    if len(result) > 256:
        raise ValueError("Review at most 256 named additions in one configuration block.")
    return result


def _workbook_order_calculations(items, current):
    """Keep existing execution order; order new expressions by declared inputs."""
    from engine.stages.ads_derived import ads_derived_errors
    fixed = {item["name"].casefold() for item in current}
    ordered = [deepcopy(item) for item in current]
    pending = [item for item in items if item["name"].casefold() not in fixed]
    while pending:
        names = {item["name"].casefold() for item in pending}
        ready = [item for item in pending if not names.intersection(name.casefold() for name in item["requires"])]
        if not ready:
            raise ValueError("The new ADS calculations have a dependency cycle; review their input columns.")
        ordered.extend(ready)
        done = {item["name"].casefold() for item in ready}
        pending = [item for item in pending if item["name"].casefold() not in done]
    errors = ads_derived_errors(ordered)
    if errors:
        raise ValueError(" ".join(errors))
    return ordered


def _workbook_passthrough_additions(existing, proposed):
    """Merge only columns; source and all other selection settings must agree."""
    if not isinstance(proposed, dict) or "columns" not in proposed:
        raise ValueError("Source-column additions need a columns list and matching source settings.")
    if existing is None or existing == {}:
        existing = {key: deepcopy(value) for key, value in proposed.items() if key != "columns"}
        existing["columns"] = []
    if not isinstance(existing, dict) or ({key: value for key, value in existing.items() if key != "columns"}
            != {key: value for key, value in proposed.items() if key != "columns"}):
        raise ValueError("Source-column additions use different sources or selection settings; review one shared mapping first.")
    merged = deepcopy(existing)
    merged["columns"] = _workbook_named_additions(existing.get("columns", []), proposed["columns"], column=True)
    return merged


def _workbook_date_order_additions(existing, proposed):
    """Add explicit pairs without replacing, reversing or weakening existing checks."""
    existing = [] if existing is None else existing
    result, seen = [], {}
    for index, pairs in enumerate((existing, proposed)):
        if not isinstance(pairs, list) or len(pairs) > 64:
            raise ValueError("Date-order checks need a list of at most 64 explicit column pairs.")
        for pair in pairs:
            if (not isinstance(pair, dict) or set(pair) != {"start", "end"}
                    or any(not isinstance(pair[key], str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,127}", pair[key])
                           for key in ("start", "end"))):
                raise ValueError("Each date-order check needs only start and end plain column identifiers.")
            key = (pair["start"].casefold(), pair["end"].casefold())
            if key[0] == key[1] or key[::-1] in seen:
                raise ValueError("A date-order check repeats one column or reverses an existing pair; review the intended chronology.")
            if key in seen and pair != seen[key]:
                raise ValueError("Date-order column spelling differs from an existing pair; use its exact identifiers.")
            if index == 0 or key not in seen:
                result.append(deepcopy(pair))
            seen[key] = pair
    if len(result) > 64:
        raise ValueError("Review at most 64 date-order pairs together.")
    return result


def _workbook_date_order_findings(product, proposed_rows):
    """A drafted output check must reach both columns at the executed QC boundary."""
    owners = [row["item_id"] for row in proposed_rows if any(
        change.get("ref") == QC_DATE_ORDER_REF for change in row.get("configuration_changes", [])
        if isinstance(change, dict))]
    if not owners:
        return []
    from engine.stages.assemble import PUBLICATION_MANDATORY
    cfg = load_config(product / "config/data_product.yaml")
    try:
        pairs = _workbook_date_order_additions([], (cfg.raw.get("qc") or {}).get("date_order"))
        projection = cb._configured_publication(cfg)
        available = set(projection) if projection is not None else cb._execution_output_names(cfg) | set(PUBLICATION_MANDATORY)
        missing = sorted({pair[key] for pair in pairs for key in ("start", "end") if pair[key] not in available})
        if not missing:
            return []
        message = "Date-order check column(s) do not survive the configured final ADS: " + ", ".join(missing) + ". Review exact source/output names and publication; a skipped check cannot enforce chronology."
        code = "qc_date_order_unavailable_column"
    except (ValueError, TypeError, KeyError) as error:
        message, code = "Date-order checks could not be verified: " + str(error), "qc_date_order_unverified"
    return [_workbook_finding(code, message, item_id=item, field=QC_DATE_ORDER_REF, kind="technical")
            for item in dict.fromkeys(owners)]


def _workbook_native_ecog_translation(product, items, records, allowed, changes, findings, translations):
    """Lower a proven native-label selection without changing its reviewed tree.

    Only the native codebook supplies the inverse mapping. Other mentions of the
    native label/code outside this selection conservatively prevent translation:
    an uncertain producer must keep its ordinary validation finding.
    """
    from experiments.portal import variable_clinical_rules as typed
    from engine.config import is_non_oncology
    native_ref = "variables/clinical.yaml#/baseline_ecog"
    ads_ref = "variables/outcomes.yaml#/ads_derived"
    target = next((item for item in items if item.get("name") == "ecog" and item.get("requires") == ["ecog"]), None)
    if target is None or native_ref not in allowed:
        return items
    if any(str(item.get("name", "")).casefold() in {"ecog", "ecogn"}
           for item in allowed[ads_ref]["current"] or []):
        return items
    if any(str(item.get("name", "")).casefold() in {"ecog", "ecogn"} and item is not target for item in items):
        return items
    proposed = [change for row in records for change in row.get("configuration_changes", []) if isinstance(change, dict)]
    blocks = [change["value"] for change in proposed if change.get("ref") == native_ref]
    if (any(block != blocks[0] for block in blocks[1:])
            or any(str(change.get("ref", "")).startswith(native_ref + "/") for change in proposed)
            or any(finding.get("field") == native_ref for finding in findings)):
        return items
    def mentions_native(value):
        if isinstance(value, dict):
            return any(mentions_native(key) or mentions_native(child) for key, child in value.items())
        if isinstance(value, list):
            return any(mentions_native(child) for child in value)
        return isinstance(value, str) and value.casefold() in {"ecog", "ecogn"}
    for ref, entry in allowed.items():
        if ref not in {native_ref, ads_ref} and mentions_native(changes.get(ref, entry["current"])):
            return items
    if any(change.get("ref") not in {native_ref, ads_ref} and mentions_native(change.get("value")) for change in proposed):
        return items
    try:
        if is_non_oncology(load_config(product / "config/data_product.yaml")):
            return items
        block = changes.get(native_ref, allowed[native_ref]["current"])
        witnesses = []
        for row in records:
            for change in row.get("configuration_changes", []):
                if change.get("ref") != ads_ref or not isinstance(change.get("value"), list):
                    continue
                for item in change["value"]:
                    if isinstance(item, dict) and item.get("name") == "ecog" and "calculation" in item:
                        resolved = typed.resolve_native_ecog_selection(item, block)
                        if resolved == item or typed.compile_workbook_calculation(item) != target:
                            return items
                        witnesses.append((row["item_id"], item, resolved))
        if not witnesses:
            return items
        lowered = typed.compile_workbook_calculation(witnesses[0][2])
        if any(typed.compile_workbook_calculation(resolved) != lowered for _, _, resolved in witnesses):
            return items
    except (ValueError, TypeError, KeyError, OSError):
        return items
    translations.append({"item_ids": list(dict.fromkeys(owner for owner, _, _ in witnesses)),
        "output": "ecog", "native_ref": native_ref, "native_value_codes": deepcopy(block["value_codes"]),
        "native_missing_code": block["missing_code"], "native_missing_label": block["missing_label"],
        "before": deepcopy(witnesses[0][1]), "after": deepcopy(witnesses[0][2]),
        "scientific_choices_changed": False, "approved": False,
        "message": "The explicit grade filter is compiled using the native code mapping. Its window, selection, string values and null rule are unchanged."})
    return [lowered if item is target else item for item in items]


def _workbook_changes(product, records, allowed, locked_refs, *, translations=None):
    translations = translations if translations is not None else []
    changes, owners, findings, blocked = {}, {}, [], set()
    ads_ref, passthrough_ref = "variables/outcomes.yaml#/ads_derived", "variables/clinical.yaml#/passthrough"
    for row in records:
        for change in row["configuration_changes"]:
            if not isinstance(change, dict) or set(change) != {"ref", "value"} or change.get("ref") not in allowed:
                findings.append(_workbook_finding("unsupported_native_field", "Choose a native configuration field supplied with this workbook; arbitrary paths or code cannot be drafted.", item_id=row["item_id"], kind="technical"))
                continue
            ref, value = change["ref"], change["value"]
            if ref in blocked:
                continue
            if ref == "variables/outcomes.yaml#/overall_survival":
                errors = _workbook_os_errors(value)
                if errors:
                    findings.extend(_workbook_finding("unsupported_native_field", error, item_id=row["item_id"],
                        field=ref, kind="technical") for error in errors)
                    continue
            def raw_controls(item, path=()):
                captured = {}
                if isinstance(item, dict):
                    for key, child in item.items():
                        if key in WORKBOOK_RAW_CONTROLS:
                            captured[path + (key,)] = child
                        captured.update(raw_controls(child, path + (key,)))
                elif isinstance(item, list):
                    for index, child in enumerate(item):
                        captured.update(raw_controls(child, path + (index,)))
                return captured
            current = allowed[ref]["current"]
            ads_additions = ref == ads_ref and isinstance(value, list)
            unsafe_raw = (any(raw_controls(item) and item not in (current or []) for item in value)
                          if ads_additions else raw_controls(value) != raw_controls(current))
            if unsafe_raw:
                findings.append(_workbook_finding("unsupported_executable_text", "This workbook draft cannot introduce, change or remove raw SQL, expressions or programs. Use a supported typed calculation or ask for explicit engineering review.", item_id=row["item_id"], field=ref, kind="technical"))
                if ref in {ads_ref, passthrough_ref}:
                    blocked.add(ref)
                    changes.pop(ref, None)
                continue
            if any(ref == locked or ref.startswith(locked + "/") or locked.startswith(ref + "/") for locked in locked_refs):
                if value != allowed[ref]["current"]:
                    findings.append(_workbook_finding("reviewed_rule_locked", "This configuration field supports an approved record. Reopen its scientific review separately before changing it.", item_id=row["item_id"], field=ref))
                    continue
            def unsafe(item):
                if isinstance(item, dict):
                    return any(unsafe(child) for child in item.values())
                if isinstance(item, list):
                    return any(unsafe(child) for child in item)
                return isinstance(item, str) and bool(re.search(r"^\s*(?:SELECT|DROP|ALTER|INSERT|UPDATE|DELETE|CREATE|EXECUTE|EXEC)\b|;\s*(?:SELECT|DROP|ALTER|INSERT|UPDATE|DELETE|CREATE|EXEC)\b", item, re.I))
            if unsafe(value):
                findings.append(_workbook_finding("unsupported_executable_text", "SQL statements or executable programs cannot be drafted into native calculation fields.", item_id=row["item_id"], field=ref, kind="technical"))
                if ref in {ads_ref, passthrough_ref}:
                    blocked.add(ref)
                    changes.pop(ref, None)
                continue
            if ref == QC_DATE_ORDER_REF:
                try:
                    value = _workbook_date_order_additions(changes.get(ref, current), value)
                except (ValueError, TypeError) as error:
                    findings.append(_workbook_finding("invalid_date_order", error,
                        item_id=row["item_id"], field=ref, kind="technical"))
                    blocked.add(ref)
                    changes.pop(ref, None)
                    continue
                changes[ref] = value
                owners.setdefault(ref, []).append(row["item_id"])
                continue
            if ads_additions:
                from experiments.portal import variable_clinical_rules
                try:
                    if any(not isinstance(item, dict) or "calculation" not in item and item not in (current or []) for item in value):
                        raise ValueError("New ADS calculations need the bounded typed form; existing entries may only be retained exactly.")
                    value = [variable_clinical_rules.compile_workbook_calculation(item)
                             if isinstance(item, dict) and "calculation" in item else deepcopy(item)
                             for item in value]
                except (ValueError, TypeError) as error:
                    findings.append(_workbook_finding("invalid_typed_calculation", error,
                        item_id=row["item_id"], field=ref, kind="technical"))
                    blocked.add(ref)
                    changes.pop(ref, None)
                    continue
            if ads_additions or ref == passthrough_ref and isinstance(value, dict) and "columns" in value:
                try:
                    existing = changes.get(ref, current)
                    value = (_workbook_named_additions(existing or [], value) if ads_additions
                             else _workbook_passthrough_additions(existing, value))
                except (ValueError, TypeError) as error:
                    findings.append(_workbook_finding("conflicting_native_choices", error,
                        item_id=row["item_id"], field=ref))
                    blocked.add(ref)
                    changes.pop(ref, None)
                    continue
                changes[ref] = value
                owners.setdefault(ref, []).append(row["item_id"])
                continue
            if ref in changes and changes[ref] != value:
                findings.append(_workbook_finding("conflicting_native_choices", "Two workbook rows propose different values for the same native field.", item_id=row["item_id"], field=ref))
                continue
            changes[ref] = value
            owners.setdefault(ref, []).append(row["item_id"])
    if ads_ref in changes:
        try:
            changes[ads_ref] = _workbook_native_ecog_translation(product, changes[ads_ref], records,
                allowed, changes, findings, translations)
            changes[ads_ref] = _workbook_order_calculations(changes[ads_ref], allowed[ads_ref]["current"] or [])
        except (ValueError, TypeError, KeyError) as error:
            findings.append(_workbook_finding("invalid_typed_calculation", error,
                item_id=owners[ads_ref][0], field=ads_ref, kind="technical"))
            changes.pop(ads_ref)
    documents, before = {}, {}
    for ref, value in changes.items():
        entry = allowed[ref]
        relative = entry["file"]
        if relative not in documents:
            before[relative] = _read(product / relative).decode("utf-8")
            documents[relative] = _parse(before[relative])
        parent = documents[relative]
        for key in entry["keys"][:-1]:
            if not isinstance(parent.get(key), dict):
                parent[key] = {}
            parent = parent[key]
        parent[entry["keys"][-1]] = deepcopy(value)
    files = []
    for relative, document in documents.items():
        after = yaml.safe_dump(document, sort_keys=False, allow_unicode=True)
        if _parse(after) != document:
            raise Invalid("The candidate native values did not survive YAML read-back.")
        if document != _parse(before[relative]):
            files.append(_workbook_file(relative, before[relative], after))
    return files, owners, findings


def _workbook_file(relative, before, after):
    return {"path": relative, "before": before, "after": after, "before_sha256": _digest(before.encode("utf-8")),
            "after_sha256": _digest(after.encode("utf-8")), "diff": "".join(difflib.unified_diff(
                before.splitlines(True), after.splitlines(True), fromfile="a/" + relative, tofile="b/" + relative))}


WORKBOOK_SOURCE_QUESTION_END = " What corrected typed definition should be drafted? Changes to original source wording require editing the workbook."


def _workbook_sync_source_questions(row, variable, findings):
    """Retire this compiler's obsolete prompts only after fresh source checks ran."""
    prefix = "Review " + str(variable) + ": "
    messages = ("Original source ", "The original source does not identify ", "The source ECOG selection requires ",
                "Preserve both source cases:", "The source native survival calculation ", "Describe missing patient anchors ",
                "The original workbook declares output type ", "The source age category ", "This output must use the line selection ",
                "Native line outputs are left-joined;", "Native age bands ")
    removed, retained = [], []
    for question in row["questions"]:
        text = question.get("question", "") if isinstance(question, dict) else str(question)
        body = text[len(prefix):-len(WORKBOOK_SOURCE_QUESTION_END)] if text.startswith(prefix) and text.endswith(WORKBOOK_SOURCE_QUESTION_END) else ""
        emitted_type = bool(re.match(r"[A-Za-z][A-Za-z0-9_]* is emitted by the (?:native reader|final typed ADS cast) as ", body))
        if body and (body.startswith(messages) or emitted_type):
            removed.append(text)
        else:
            retained.append(question)
    row["questions"] = retained
    added = []
    if findings and len(retained) < 6:
        text = prefix + " ".join(entry["message"] for entry in findings)
        question = text[:470] + WORKBOOK_SOURCE_QUESTION_END
        row["questions"].append(question)
        added.append({"id": _digest(_encode([row["item_id"], question, []]))[:24], "item_id": row["item_id"],
                      "question": question, "kind": "scientific", "choices": [],
                      "fields": sorted({field for entry in findings
                          for field in entry.get("fields", [entry["field"]] if entry.get("field") else [])})})
    return removed, added


def compile_workbook_candidate(root, pack, *, actor_id, proposal, expected_input_digest, allowed_packs=None):
    """Compile a complete proposed workbook on a disposable shadow, never in place."""
    try:
        from experiments.portal import scientific_definitions as science
        from rwd_tools import contract_record as records, product_gates
        context = workbook_context(root, pack, actor_id=actor_id, allowed_packs=allowed_packs)
        if not context.get("ok"):
            return context
        if not expected_input_digest or context["input_digest"] != expected_input_digest:
            raise Invalid("The workbook, product or native readers changed. Prepare a fresh candidate from the current source.")
        base, product, name, _owner, _folder = _workbook_scope(root, pack, actor_id, allowed_packs)
        proposal = _workbook_json(proposal)
        if not isinstance(proposal, dict) or set(proposal) != {"schema_version", "records"} or type(proposal["schema_version"]) is not int or proposal["schema_version"] != 1 or not isinstance(proposal["records"], list):
            raise Invalid("Supply the version-one workbook record envelope.")
        offered = {row["item_id"]: row for row in context["context"]["rows"]}
        seen, questions, findings, drafted = set(), [], list(context["findings"]), []
        before = _read(product / "handoff/FUNCTIONAL_CONTRACT.md").decode("utf-8")
        existing_blocks = list(science.cl.records(before))
        existing = {science.cl._scalar(block, "variable_id"): block for block in existing_blocks}
        dec_file = product / "handoff/DECISIONS.md"
        decisions = science.cl.decision_status(_read(dec_file).decode("utf-8")) if dec_file.exists() else {}
        bindings = context["write_schema"]["implementation_bindings"]
        for row in proposal["records"]:
            if not isinstance(row, dict) or set(row) != {"item_id", "values", "configuration_changes", "questions"} or row.get("item_id") not in offered:
                raise Invalid("Every candidate row must name an exact supplied item_id and only judgment values, native changes and questions.")
            item = row["item_id"]
            if item in seen:
                raise Invalid("The candidate repeats a workbook row. Each item_id must occur exactly once.")
            seen.add(item)
            if not isinstance(row["configuration_changes"], list) or len(row["configuration_changes"]) > 100 or not isinstance(row["questions"], list) or len(row["questions"]) > 12:
                raise Invalid("Each workbook row needs bounded lists of native changes and unresolved questions.")
            for entry in row["questions"]:
                if isinstance(entry, dict):
                    if set(entry) != {"question", "choices"}:
                        raise Invalid("A structured question contains only question and choices.")
                    question, choices = entry["question"], entry["choices"]
                else:
                    question, choices = entry, []
                if not isinstance(question, str) or not question.strip() or len(question) > 1200:
                    raise Invalid("An unresolved workbook question must be a bounded nonempty sentence.")
                if not isinstance(choices, list) or len(choices) > 5 or any(not isinstance(choice, str) or not choice.strip() or len(choice) > 200 for choice in choices) or len(set(choices)) != len(choices):
                    raise Invalid("A question may offer up to five distinct bounded choices, without selecting a default.")
                fields = _workbook_question_fields(entry, str(offered[item]["variable_id"]))
                questions.append({"id": _digest(_encode([item, question, choices]))[:24], "item_id": item, "question": question,
                                  "kind": "product_output" if fields else "scientific", "choices": choices,
                                  **({"fields": fields} if fields else {})})
            if offered[item]["retained"]:
                if row["values"] is not None or row["configuration_changes"] or row["questions"]:
                    findings.append(_workbook_finding("reviewed_record_locked", "Preserve this approved record. Reopen its scientific review explicitly before replacing its judgments.", item_id=item))
                continue
            if row["values"] is None:
                if not offered[item]["existing_records"] and not offered[item]["is_context"]:
                    findings.append(_workbook_finding("missing_judgment", "This specification row still needs a complete judgment or an explicit scientific answer.", item_id=item))
                continue
            try:
                try:
                    values = _workbook_judgment(row["values"])
                except (ValueError, TypeError) as error:
                    known_fields = isinstance(row["values"], dict) and set(row["values"]) <= set(science.FIELDS)
                    findings.append(_workbook_finding("judgment_shape", error, item_id=item, kind="technical", repairable=known_fields))
                    continue
                interface_findings = _workbook_judgment_interface(values, item)
                findings.extend(interface_findings)
                questions.extend(_workbook_interface_questions(row, interface_findings))
                findings.extend(_workbook_binding_interface(values, item, bindings))
                record, errors = records.merge_evidence(values, str(product), item, reader="ai")
                if errors:
                    raise Invalid(" ".join(errors))
                old = existing.get(record["variable_id"])
                if old and item not in (science.cl._list(old, "spec_refs") or []):
                    raise Invalid("This variable identifier already belongs to a different specification row.")
                if old and len(science.cl._list(old, "spec_refs") or []) != 1:
                    raise Invalid("A record combining several source rows needs explicit human reconciliation; preserve it here.")
                current = records._status_map({"status": science.cl._scalar(old, "status")}) if old else None
                record, errors = records.apply_status(record, current=current, dec_open=decisions,
                    reopen=records.requirement_changes(record, old) if old else None)
                if errors:
                    raise Invalid(" ".join(errors))
                # A prospective binding is a machine-checkable implementation
                # assertion. It is admitted only if the full shadow checks below
                # prove native activation, references and promised outputs.
                status = records._status_map(record)
                status["implementation"] = "implemented" if any(ref != "none" for ref in record.get("implementation_refs") or []) else "not_implemented"
                record["status"] = status
                _rendered, errors = records.row_for(record)
                if errors:
                    raise Invalid(" ".join(errors))
                drafted.append(record)
                unanswered = _workbook_unanswered(values)
                if unanswered:
                    groups = sorted({field.split(".", 1)[0].split("[", 1)[0] for field in unanswered})
                    findings.append(_workbook_finding("unresolved_judgment",
                        record["variable_id"] + " still needs answers for: " + ", ".join(unanswered) + ". The known draft fields are retained for review.",
                        item_id=item, field=", ".join(groups), kind="scientific"))
                    # One bounded question covers the unanswered fields. Existing
                    # model questions remain intact; never duplicate or crowd out
                    # their explicit scientific choices with one prompt per cell.
                    if not row["questions"]:
                        named = ", ".join(unanswered)
                        if len(named) > 400:
                            named = ", ".join(groups)
                        question = ("For " + record["variable_id"] + ", complete the unanswered fields: "
                                    + named + ". What should these fields say?")
                        row["questions"].append(question)
                        questions.append({"id": _digest(_encode([item, question, []]))[:24], "item_id": item,
                                          "question": question, "kind": "scientific", "choices": [], "fields": unanswered})
            except (ValueError, TypeError) as error:
                findings.append(_workbook_finding("invalid_judgment", error, item_id=item, kind="technical"))
        missing = sorted(set(offered) - seen)
        for item in missing:
            findings.append(_workbook_finding("missing_workbook_row", "This source row was omitted from the candidate. Include its exact item_id; do not silently remove a requirement.", item_id=item, kind="technical", repairable=True))
        identities = [str(record["variable_id"]).casefold() for record in drafted]
        if len(identities) != len(set(identities)):
            findings.append(_workbook_finding("duplicate_candidate_identifier", "Two workbook rows draft the same contract identifier. Resolve their distinct meanings before combining them.", kind="scientific"))
            drafted = []
        _cfg, _documents, allowed = _workbook_native(product)
        locked_refs = {ref for block in existing_blocks if (records._status_map({"status": science.cl._scalar(block, "status")}) or {}).get("requirement") == "approved"
                       for ref in science.cl._list(block, "implementation_refs") or [] if "#/" in ref}
        translations = []
        files, owners, config_findings = _workbook_changes(product, proposal["records"], allowed, locked_refs,
            translations=translations)
        findings.extend(config_findings)
        after = records.upsert(before, drafted)
        if after != before:
            files.append(_workbook_file("handoff/FUNCTIONAL_CONTRACT.md", before, after))
        checks = []
        with tempfile.TemporaryDirectory(prefix="rwd-workbook-") as temporary:
            candidate = _candidate(base, product, {"pack": name, "files": files}, Path(temporary))
            def native_checks():
                cfg = load_config(candidate / "config/data_product.yaml")
                return problems(cfg, strict=True) + _workbook_os_errors(cfg.pack("outcomes").get("overall_survival")), {}
            for validator, run in (
                ("engine.validate (strict)", native_checks),
                ("contract_lint", lambda: science.cl.run(str(candidate))),
                ("contract_binding (complete)", lambda: cb.check(str(candidate), cb.pack_yaml(str(candidate)), require_complete=True)),
            ):
                try:
                    errors, detail = run()
                    checks.append({"validator": validator, "passed": not errors, "errors": list(errors), "detail": detail, "completed": True})
                except Exception as error:
                    checks.append({"validator": validator, "passed": False, "errors": [str(error)], "detail": {}, "completed": False})
            for error in product_gates.spec_qc_errors(str(candidate), name):
                findings.append(_workbook_finding("open_source_qc", error, kind="source"))
            findings.extend(_workbook_source_band_findings(candidate, proposal["records"]))
            findings.extend(_workbook_date_order_findings(candidate, proposal["records"]))
            source_checks = _workbook_source_calculation_findings(candidate, proposal["records"], context["context"]["rows"])
            findings.extend(source_checks)
            for row in proposal["records"]:
                checks_for_row = [entry for entry in source_checks if entry["item_id"] == row["item_id"]]
                if isinstance(row.get("values"), dict):
                    removed, added = _workbook_sync_source_questions(row, offered[row["item_id"]]["variable_id"], checks_for_row)
                    questions = [question for question in questions if question["item_id"] != row["item_id"] or question["question"] not in removed]
                    questions.extend(added)
        for check in checks:
            for error in check["errors"]:
                matching = [row["item_id"] for row in context["context"]["rows"] if row["item_id"] in str(error)
                    or str(row["variable_id"]) and re.search(r"(?<![A-Za-z0-9_])" + re.escape(str(row["variable_id"])) + r"(?![A-Za-z0-9_])", str(error), re.I)]
                findings.append(_workbook_finding("candidate_validation", error, item_id=matching[0] if len(matching) == 1 else "",
                    field=check["validator"], kind="technical", repairable=bool(len(matching) == 1)))
        if _workbook_snapshot(base, product, actor_id=actor_id) != expected_input_digest:
            raise Invalid("The source or product changed while validating the candidate. No draft was accepted.")
        coverage = {"required_rows": len(offered), "accounted_rows": len(seen), "missing_rows": missing,
            "drafted_records": len(drafted), "preserved_records": len(existing) - len(set(existing) & {r["variable_id"] for r in drafted}),
            "complete": not missing and all(check["passed"] for check in checks)}
        result = {"ok": True, "ready": not findings and not questions and bool(checks) and all(check["passed"] for check in checks),
            "proposal": proposal, "input_digest": expected_input_digest, "coverage": coverage, "findings": findings,
            "questions": questions, "files": files, "checks": checks, "compiler_translations": translations, "notice": WORKBOOK_NOTICE,
            "approved": False, "released": False, "changed": False}
        result["digest"] = _digest(_encode(result))
        return result
    except Exception as error:
        return {"ok": False, "ready": False, "changed": False, "errors": [_workbook_finding("candidate", error)["message"]],
            "findings": [_workbook_finding("candidate_refused", error, kind="technical")], "notice": WORKBOOK_NOTICE}


def _workbook_source_band_findings(product, proposed_rows):
    """Compare literal age bounds even while the proposed row remains unbound."""
    evidence = cb.enumerations_read(str(product), current_extraction=True)
    if evidence.get("error"):
        return [_workbook_finding("source_band_unavailable", evidence["error"], kind="source")]
    by_item = {}
    for name, value in evidence.get("enumerations", {}).items():
        if value.get("kind") == "literal_values":
            by_item.setdefault(value.get("spec_ref"), []).append((name, value))
    blocks = cb.governed_blocks(str(product), cb.pack_yaml(str(product)))
    findings = []
    for row in proposed_rows:
        values = row.get("values")
        refs = {ref for ref in values.get("implementation_refs", []) if isinstance(ref, str)} if isinstance(values, dict) and isinstance(values.get("implementation_refs"), list) else set()
        refs.update(change.get("ref") for change in row.get("configuration_changes", []) if isinstance(change, dict))
        for ref in sorted(ref for ref in refs if isinstance(ref, str) and ref.endswith("#/age_bands") and ref in blocks):
            configured = blocks[ref]
            if not isinstance(configured, list):
                continue  # Native structural validation reports this separately.
            for name, source in by_item.get(row.get("item_id"), []):
                literals = source.get("values") or []
                if not literals or not all(isinstance(item, dict) and cb._age_label_bounds(item.get("literal", "")) is not None for item in literals):
                    continue  # No inferred clinical interpretation of unparsed or non-range labels.
                numeric = [branch for branch in configured if not isinstance(branch, dict) or branch.get("when") != "fallthrough"]
                for error in cb._literal_differences(name, source, ref, numeric):
                    findings.append(_workbook_finding("source_band_mismatch", error,
                        item_id=row["item_id"], field=ref, kind="scientific"))
    return findings


def _workbook_literal_index_window(text):
    """Recognize one explicit signed day interval at index, never infer a lookback."""
    text = str(text or "").replace("\u2212", "-")
    if re.search(r"\b(?:not|never|rather|instead|examples?|prior|previous|template|formerly|alternative|either)\b", text, re.I):
        return None  # Mentioned historical/forbidden windows are not operative instructions.
    anchor = (r"\s*(?:of|from|relative\s+to)\s+(?:the\s+)?(?:current\s+)?"
              r"(?:cohort\s+)?index(?:[\s-]+date)?\b")
    spans, windows = [], []
    patterns = (re.compile(r"\bwithin\s+([+-]?\d+)\s+(?:through|to)\s+([+-]?\d+)\s+days?" + anchor, re.I),
                re.compile(cb.OFFSET_PAIR.pattern + r"\s*days?" + anchor, re.I))
    for pattern in patterns:
        for match in pattern.finditer(text):
            pair = [int(match[1]), int(match[2])]
            parsed, unread = cb._window_numbers("[" + str(pair[0]) + "," + str(pair[1]) + "]")
            if unread or parsed != set(pair):
                return None
            spans.append(match.span())
            windows.append(pair)
    if len(windows) != 1 or windows[0][0] > windows[0][1]:
        return None
    remaining = text
    for start, end in sorted(spans, reverse=True):
        remaining = remaining[:start] + " " * (end - start) + remaining[end:]
    if cb.DURATION.search(remaining) or cb.OFFSET_PAIR.search(remaining):
        return None  # Several timing statements need an explicit scoped interpretation.
    return windows[0]


def _workbook_typed_age_band_evidence(row, derived, active):
    """Prove the exact final typed label producer, without approving its science."""
    from engine import output_contract
    from engine.stages.ads_derived import ads_derived_errors
    from experiments.portal import variable_clinical_rules
    ref = "variables/outcomes.yaml#/ads_derived"
    output = row.get("values", {}).get("output")
    output = output if isinstance(output, dict) else {}
    physical = str(output.get("physical_name") or "").casefold()
    proposals = [item for change in row.get("configuration_changes", [])
                 if isinstance(change, dict) and change.get("ref") == ref and isinstance(change.get("value"), list)
                 for item in change["value"] if isinstance(item, dict)
                 and str(item.get("name") or "").casefold() == physical and "calculation" in item]
    if not proposals:
        return None  # Raw SQL and unrelated writes do not establish typed band semantics.
    problem = "The source age category needs one validated typed bands producer over age, with an available earlier age dependency."
    result = {"ref": ref, "bands": [], "error": problem}
    if len(proposals) != 1 or not isinstance(derived, list) or ads_derived_errors(derived):
        return result
    item = proposals[0]
    calculation = item.get("calculation")
    if (not isinstance(calculation, dict) or calculation.get("op") != "bands"
            or calculation.get("value") != {"op": "column", "name": "age"}
            or item.get("requires") != ["age"]):
        return result
    try:
        lowered = variable_clinical_rules.compile_workbook_calculation(item)
    except (ValueError, TypeError, KeyError):
        return result
    positions = {str(value.get("name") or "").casefold(): index for index, value in enumerate(derived)}
    position = positions.get(physical)
    if (position is None or not _workbook_equal(lowered, derived[position])
            or ("age" in positions and positions["age"] >= position)
            or ("age" not in positions and "age" not in active)):
        return result
    if output_contract.type_family(str(output.get("type") or "")) != "string":
        result["error"] = "The source age category uses string labels; the declared final output type differs."
        return result
    bands = deepcopy(calculation["bands"])
    for branch in bands:
        if (not isinstance(branch.get("label"), str) or "min_excl" in branch
                or any(type(value) is not int for key, value in branch.items() if key != "label")):
            return result  # Do not reinterpret fractional ranges or numeric output codes as labels.
    otherwise = calculation["otherwise"]
    if otherwise is not None:
        if not isinstance(otherwise, str):
            return result
        bands.append({"label": otherwise, "when": "fallthrough"})
    elif output.get("nullable") is False or str(output.get("nullable")).lower() == "false":
        result["error"] = "The source age category returns null for missing or unmatched age; the declared output must permit null."
        return result
    if len({branch["label"] for branch in bands}) != len(bands):
        return result
    return {"ref": ref, "bands": bands, "error": None}


def _workbook_source_calculation_findings(product, proposed_rows, source_rows):
    """Narrow original-source timing, native age and label/code type checks."""
    from engine import output_contract, validate as native_validation
    from engine.config import configured_demographics
    cfg = load_config(product / "config/data_product.yaml")
    native_demographics = configured_demographics(cfg)
    source = {row["item_id"]: row for row in source_rows}
    facts = _workbook_source_facts(source_rows)
    active = set(native_validation.emitted_variables(cfg))
    derived = cfg.pack("outcomes").get("ads_derived", []) if "outcomes" in cfg.roles() else []
    late_positions = {str(item.get("name", "")).lower(): index for index, item in enumerate(derived)
                      if isinstance(item, dict)} if isinstance(derived, list) else {}
    native_age_bands = cfg.pack("demographics").get("age_bands") if native_demographics else None
    # These pairs are explicitly selected by the existing native readers. This
    # does not infer types for other configured or future derived outputs.
    expected_types = {}
    for label, code in (("ecog", "ecogn"), ("agegrl", "agegrln"), ("race", "racen"),
                        ("eth", "ethn"), ("regionl", "regionln"), ("practic", "practicn")):
        if label in active and (native_demographics or label == "ecog"):
            expected_types.update({label: "string", code: "integer"})
    # An explicit outer typed cast fixes the final type after native assembly.
    # Require its exact lowered producer; arbitrary SQL or an unmatched draft
    # expression supplies no type evidence and never disables the native check.
    from engine.stages.ads_derived import ads_derived_errors
    late_cast_types = {}
    if isinstance(derived, list) and not ads_derived_errors(derived):
        for proposed in proposed_rows:
            for change in proposed.get("configuration_changes", []):
                if (not isinstance(change, dict) or change.get("ref") != "variables/outcomes.yaml#/ads_derived"
                        or not isinstance(change.get("value"), list)):
                    continue
                for item in change["value"]:
                    if not isinstance(item, dict) or not isinstance(item.get("name"), str):
                        continue
                    name, calculation = item["name"].lower(), item.get("calculation")
                    if (name not in expected_types or name not in late_positions
                            or not isinstance(calculation, dict) or calculation.get("op") != "cast"):
                        continue
                    cast = _workbook_outer_typed_cast(item)
                    if cast is None:
                        continue
                    lowered, cast_type = cast
                    if _workbook_equal(lowered, derived[late_positions[name]]):
                        late_cast_types[name] = cast_type
    findings = []
    for row in proposed_rows:
        values = row.get("values")
        if not isinstance(values, dict) or row.get("item_id") not in source:
            continue
        output = values.get("output") if isinstance(values.get("output"), dict) else {}
        physical = str(output.get("physical_name") or "").lower()
        declared_type = output.get("type")
        evidence = source[row["item_id"]].get("evidence", {})
        refs = values.get("implementation_refs", [])
        if (native_age_bands and "age" in late_positions
                and late_positions.get(physical, -1) <= late_positions["age"] and isinstance(refs, list)
                and ("variables/demographics.yaml#/age_bands" in refs
                     or physical in {"agegrl", "agegrln"})):
            finding = _workbook_finding("source_age_band_stage_mismatch",
                "Native age bands run before outcomes.ads_derived replaces age. The earlier agegrl/agegrln "
                "values are not recomputed from that replacement. Use reviewed typed bands after the revised age "
                "or keep an explicitly distinct native age; matching band limits alone does not establish matching calculations.",
                item_id=row["item_id"], field="implementation_refs", kind="scientific")
            finding["fields"] = ["derivation", "depends_on", "implementation_refs", "acceptance", "notes",
                "variables/demographics.yaml#/age_bands", "variables/outcomes.yaml#/ads_derived"]
            findings.append(finding)
        # Recognize an explicit requirement, not a mention in a question, example
        # or negation. This is deliberately not a general clinical/SQL verifier.
        age_rule = str(evidence.get("required_rule") or "").split(".", 1)[0].strip()
        completed_age = re.fullmatch(r"(?:include\s+|calculate\s+|require\s+|use\s+)?age\s+in\s+completed\s+years\s+at\s+"
            r"(?:the\s+)?(?:current\s+)?(?:cohort\s+)?index(?:\s+date)?(?:\s*(?:>=|<=|>|<|=)\s*\d+)?", age_rule, re.I)
        if completed_age and "demographics" in cfg.roles() and "age" in active:
            refs = values.get("implementation_refs", [])
            native_binding = native_demographics and physical == "age" and isinstance(refs, list) and "engine:build" in refs
            expression = r"year\s*\(\s*index_date\s*\)\s*-\s*try_cast\s*\(\s*birthyear\s+as\s+int\s*\)"
            derivation = str(values.get("derivation") or "").strip()
            # These two known forms explicitly use the native year-only age.
            # Expressions with adjustments or other SQL remain unclassified.
            year_only = (re.fullmatch(r"(?:age\s*=\s*)?" + expression
                + r"(?:;\s*invalid/null birthyear gives null,\s*no clamp)?", derivation, re.I)
                or re.fullmatch(r"Eligible \([A-Za-z][A-Za-z0-9_]*=Yes\) if age at index\s*>=\s*\d+,\s*where age\s*=\s*"
                    + expression + r" per native demographics\.build; no clamp is applied\. Missing/invalid age \(null\) is not eligible, so [A-Za-z][A-Za-z0-9_]*=No\.",
                    derivation, re.I))
            if native_binding or year_only:
                findings.append(_workbook_finding("source_age_calculation_mismatch",
                    "Original source " + row["item_id"] + " requires age in completed years at index. "
                    "The draft uses the native year(index_date)-try_cast(birthyear as int) calculation, which lacks the birthday adjustment. "
                    "Resolve the source mapping and calculation explicitly; no birth date or replacement rule was inferred.",
                    item_id=row["item_id"], field="derivation", kind="scientific"))
        source_type = _workbook_source_output_type(evidence)
        if (source_type and isinstance(declared_type, str) and declared_type.strip().upper() not in {"", "TODO", "TBD", "UNDECIDED"}
                and output_contract.type_family(source_type) != output_contract.type_family(declared_type)):
            findings.append(_workbook_finding("source_output_type_mismatch", "The original workbook declares output type " + source_type
                + "; the draft declares " + declared_type + ".", item_id=row["item_id"], field="output.type"))
        for fact in facts.get(row["item_id"], []):
            if fact["kind"] == "native_scalar":
                role = Path(fact["ref"].split("#", 1)[0]).stem
                key = fact["ref"].split("#/", 1)[1]
                actual = cfg.pack(role).get(key) if role in cfg.roles() else None
                if actual != fact["value"]:
                    findings.append(_workbook_finding("source_scalar_mismatch", "Original source states " + key + "=" + str(fact["value"])
                        + "; native configuration contains " + str(actual) + ".", item_id=row["item_id"], field=fact["ref"]))
                if key == "days_per_month" and re.search(r"\boverall\s+survival\b", evidence.get("required_rule", ""), re.I):
                    units = str(values.get("units") or "").strip().lower()
                    if units and units not in {"month", "months", "todo", "tbd", "undecided"}:
                        findings.append(_workbook_finding("source_units_mismatch", "The source native survival calculation divides elapsed days by days_per_month and emits months.",
                            item_id=row["item_id"], field="units"))
                    if re.search(r"configuration|not.active|missing.block|block.absen", str(values.get("missing", "")), re.I):
                        findings.append(_workbook_finding("source_missingness_mismatch", "Describe missing patient anchors and the stated survival gate, rather than absent configuration.",
                            item_id=row["item_id"], field="missing"))
            elif fact["kind"] == "ecog_settings":
                block = cfg.pack("clinical").get("baseline_ecog", {}) if "clinical" in cfg.roles() else {}
                for key in ("equidistant", "tie_break"):
                    if key in fact["value"] and block.get(key) != fact["value"][key]:
                        findings.append(_workbook_finding("source_selection_mismatch", "The source ECOG selection requires " + key + "=" + fact["value"][key]
                            + "; the native rule differs.", item_id=row["item_id"], field=fact["ref"]))
                if re.search(r"\bNo record is Missing and a present null is Unknown\b", evidence.get("required_rule", ""), re.I):
                    missing = json.dumps(values.get("missing", ""), ensure_ascii=False)
                    if not re.search(r"no.record.*Missing.*present.null.*Unknown", missing, re.I):
                        findings.append(_workbook_finding("source_missingness_mismatch", "Preserve both source cases: no record is Missing; a present null is Unknown.",
                            item_id=row["item_id"], field="missing"))
            elif fact["kind"] == "age_bands":
                actual = cfg.pack("demographics").get("age_bands", []) if native_demographics else []
                typed = _workbook_typed_age_band_evidence(row, derived, active)
                if typed is None and physical in late_positions:
                    findings.append(_workbook_finding("source_age_category_mismatch",
                        "The source age category has no matching validated typed bands proposal for its final derived output. Earlier native bands do not establish its bounds or missingness.",
                        item_id=row["item_id"], field="variables/outcomes.yaml#/ads_derived"))
                    continue
                field = typed["ref"] if typed else fact["ref"]
                if typed and typed["error"]:
                    findings.append(_workbook_finding("source_age_category_mismatch", typed["error"],
                        item_id=row["item_id"], field=field))
                    continue
                if typed:
                    actual = typed["bands"]
                by_label = {branch.get("label"): branch for branch in actual if isinstance(branch, dict)} if isinstance(actual, list) else {}
                if typed and set(by_label) != {branch["label"] for branch in fact["value"]}:
                    findings.append(_workbook_finding("source_age_category_mismatch",
                        "The source age category has an added or omitted label or missing-value branch in the final typed producer.",
                        item_id=row["item_id"], field=field))
                for branch in fact["value"]:
                    present = by_label.get(branch["label"])
                    if (not present or cb._age_config_bounds(present) != cb._age_config_bounds(branch)
                            or branch.get("when") != present.get("when")
                            or "code" in branch and branch["code"] != present.get("code")):
                        findings.append(_workbook_finding("source_age_category_mismatch", "The source age category " + branch["label"]
                            + " has different bounds, missingness or an explicit numeric code in the native configuration.",
                            item_id=row["item_id"], field=field))
        parent = _workbook_line_selection_parent(row, source, {"line_selection": {"order": "non_maintenance_then_start_end_name"}})
        if parent:
            interpretation = " ".join(str(values.get(field, "")) for field in ("record_selection", "tie_break"))
            if re.search(r"\b(?:latest|most.recent)\s+(?:line\s+)?start|\bprefer\w*\s+maintenance\b", interpretation, re.I):
                findings.append(_workbook_finding("linked_selection_mismatch", "This output must use the line selection stated by " + parent["variable_id"] +
                    ": non-maintenance, earliest start, earliest end and name.", item_id=row["item_id"], field="record_selection"))
            if output.get("nullable") is False:
                findings.append(_workbook_finding("native_line_missingness_mismatch", "Native line outputs are left-joined; a patient with no selected line has null output values.",
                    item_id=row["item_id"], field="output.nullable"))
        if physical in expected_types and isinstance(declared_type, str) and declared_type.strip().upper() not in {"", "TODO", "TBD", "UNDECIDED"}:
            expected = late_cast_types.get(physical, expected_types[physical])
            if output_contract.type_family(declared_type) != output_contract.type_family(expected):
                producer = "final typed ADS cast" if physical in late_cast_types else "native reader"
                findings.append(_workbook_finding("native_output_type_mismatch",
                    physical + " is emitted by the " + producer + " as " + expected + ", but the draft declares " + declared_type
                    + ("." if physical in late_cast_types else ". The paired label and numeric code are different columns."),
                    item_id=row["item_id"], field="output.type", kind="scientific"))
        refs = {ref for ref in values.get("implementation_refs", []) if isinstance(ref, str)} if isinstance(values.get("implementation_refs"), list) else set()
        refs.update(change.get("ref") for change in row.get("configuration_changes", []) if isinstance(change, dict) and isinstance(change.get("ref"), str))
        if physical not in {"ecog", "ecogn"} and not any(ref.endswith("#/baseline_ecog") for ref in refs):
            continue
        evidence = source[row["item_id"]].get("evidence", {})
        window = _workbook_literal_index_window(evidence.get("required_rule"))
        field = "variables/clinical.yaml#/baseline_ecog"
        if window is None:
            findings.append(_workbook_finding("source_window_unresolved",
                "The original source does not identify one supported explicit ECOG day window relative to index. Review its timing statements; no window was inferred from the template or draft.",
                item_id=row["item_id"], field=field, kind="scientific"))
            continue
        block = cfg.pack("clinical").get("baseline_ecog") if "clinical" in cfg.roles() else None
        actual = block.get("window_days") if isinstance(block, dict) else None
        if actual != window:
            findings.append(_workbook_finding("source_window_mismatch",
                "Original source " + row["item_id"] + " states ECOG window " + str(window)
                + " days at index; native baseline_ecog applies " + str(actual)
                + ". Agreement between a copied draft and configuration does not resolve this source difference.",
                item_id=row["item_id"], field=field, kind="scientific"))
    return findings


def _workbook_ingress_unit(value):
    """Screen a complete independent record, including nested structured data."""
    from experiments.portal import scientific_definition_ai as ai
    ai._ingress(ai._plain(value))
    literals = []
    def walk(item):
        if isinstance(item, dict):
            for child in item.values():
                walk(child)
        elif isinstance(item, list):
            # Do not split an embedded patient table into harmless-looking rows.
            # JSON lines also expose tables represented as dictionaries rather
            # than already delimited text to the unchanged ingress classifier.
            ai._ingress("\n".join(json.dumps(child, ensure_ascii=False, allow_nan=False) for child in item))
            for child in item:
                walk(child)
        elif isinstance(item, str):
            literals.append(item)
        elif item is not None:
            literals.append(str(item))
    walk(value)
    # A sensitive label and its value can occupy separate fields. Keep those
    # values together as well as checking the original keys and full structure.
    ai._ingress(": ".join(literals))


def _workbook_proposal_ingress(proposal):
    """History repetition is not data; each proposed record remains a full unit."""
    if isinstance(proposal, dict) and isinstance(proposal.get("records"), list):
        _workbook_ingress_unit({key: value for key, value in proposal.items() if key != "records"})
        for record in proposal["records"]:
            _workbook_ingress_unit(record)
    else:
        _workbook_ingress_unit(proposal)


def _workbook_history(versions):
    """Retain independently screened history, withholding only unsafe units."""
    from experiments.portal import scientific_definition_ai as ai
    versions = _workbook_json(versions or [])
    if not isinstance(versions, list) or len(versions) > 40:
        raise Invalid("Keep at most forty bounded attempt summaries with this workbook draft.")
    withheld = []
    def screen(value):
        try:
            _workbook_ingress_unit(value)
            return value
        except ai.Invalid:
            marker = {"content_withheld": True, "reason": "Restricted attempt-history content was withheld.",
                      "sha256": _digest(_encode(value))}
            withheld.append(marker["sha256"])
            return marker
    retained = []
    for event in versions:
        if not isinstance(event, dict):
            retained.append(screen(event))
            continue
        # Only these known history containers hold independent proposal records,
        # findings or explicit answers. Everything else stays one inspected unit.
        separate = {key: event[key] for key in ("proposal", "original_proposal", "findings", "answers", "repairs", "metadata_repairs", "row_origins", "rejected_response_diagnostics") if key in event}
        count = len(withheld)
        rest = screen({key: value for key, value in event.items() if key not in separate})
        if len(withheld) != count:
            retained.append(rest)
            continue
        for key, value in separate.items():
            if key in {"proposal", "original_proposal"} and isinstance(value, dict) and isinstance(value.get("records"), list):
                count = len(withheld)
                shell = screen({field: content for field, content in value.items() if field != "records"})
                rest[key] = shell if len(withheld) != count else {
                    **shell, "records": [screen(record) for record in value["records"]]}
            elif key in {"findings", "answers", "repairs", "metadata_repairs"} and isinstance(value, list):
                rest[key] = [screen(item) for item in value]
            elif key == "row_origins" and isinstance(value, dict):
                rest[key] = {}
                for item_id, origin in value.items():
                    answer_keys = [name for name in ("owner_answers", "pending_owner_answers")
                                   if isinstance(origin, dict) and isinstance(origin.get(name), list)]
                    if not answer_keys:
                        rest[key][item_id] = screen(origin)
                        continue
                    shell = {field: content for field, content in origin.items() if field not in answer_keys}
                    count = len(withheld)
                    checked = screen(shell)
                    if len(withheld) != count:
                        rest[key][item_id] = checked
                        continue
                    rest[key][item_id] = checked
                    for answer_key in answer_keys:
                        answers = []
                        for answer in origin[answer_key]:
                            # One complete answer plus its ownership/field context
                            # stays atomic; nested patient tables still fail.
                            atom = screen({"owner_context": shell, "answer": answer})
                            answers.append(atom["answer"] if "answer" in atom else atom)
                        rest[key][item_id][answer_key] = answers
            else:
                rest[key] = screen(value)
        retained.append(rest)
    return retained, withheld


def _workbook_equal(left, right):
    """Compare JSON values without conflating booleans/numbers or key order."""
    return json.dumps(left, sort_keys=True, ensure_ascii=False, allow_nan=False) == json.dumps(
        right, sort_keys=True, ensure_ascii=False, allow_nan=False)


def _workbook_retain_question_scopes(candidate, parent_questions, native_refs, *,
                                    pending_origins=None, input_digest=None):
    """Preserve checked scope only for the exact same unanswered question."""
    from experiments.portal import scientific_definition_ai as ai, scientific_definitions as science
    for question in candidate["questions"]:
        matches = [old for old in parent_questions if isinstance(old, dict)
                   and old.get("id") == question.get("id")]
        if len(matches) > 1:
            raise Invalid("The original draft repeats a question identifier; its field scope is ambiguous.")
        if not matches:
            continue
        old = matches[0]
        if (question.get("kind") not in {"scientific", "product_output"}
                or any(not _workbook_equal(old.get(key), question.get(key))
                       for key in ("id", "item_id", "question", "kind"))
                or not _workbook_equal(old.get("choices", []), question.get("choices", []))):
            continue
        fields = old.get("fields", [old["field"]] if isinstance(old.get("field"), str) else [])
        if fields == []:
            continue
        pending_unscoped = False
        if fields == ["*"]:
            # This is the saved unanswered-scope sentinel, never permission to
            # modify every field. Only the exact bound pending atom may retain it.
            origin = (pending_origins or {}).get(question["item_id"], {})
            rows = [row for row in candidate["proposal"]["records"]
                    if row.get("item_id") == question["item_id"]]
            atoms = origin.get("pending_owner_answers", []) if isinstance(origin, dict) else []
            matches = [atom for atom in atoms if isinstance(atom, dict)
                       and atom.get("id") == question["id"]] if isinstance(atoms, list) else []
            pending_unscoped = (len(rows) == 1 and len(matches) == 1
                and isinstance(input_digest, str) and re.fullmatch(r"[a-f0-9]{64}", input_digest)
                and origin.get("record_sha256") == ai._hash(rows[0])
                and origin.get("source_input_digest") == input_digest
                and all(_workbook_equal(matches[0].get(key), old.get(key))
                        for key in ("id", "item_id", "question", "fields"))
                and _workbook_equal(matches[0].get("choices", []), old.get("choices", []))
                and "update_fields" not in matches[0]
                and isinstance(matches[0].get("answer"), str)
                and 0 < len(matches[0]["answer"].strip()) <= 1000)
        if (not isinstance(fields, list) or not fields
                or any(not isinstance(field, str) or not field
                       or not (field.split(".", 1)[0] in science.FIELDS or field in native_refs
                               or field == "*" and pending_unscoped)
                       for field in fields) or len(set(fields)) != len(fields)
                or question["id"] != _digest(_encode([
                    question["item_id"], question["question"], question.get("choices", [])]))[:24]):
            raise Invalid("An unchanged saved question has an invalid field scope. Review it explicitly before revalidation.")
        current = question.get("fields", [question["field"]] if isinstance(question.get("field"), str) else [])
        if current and not _workbook_equal(current, fields):
            raise Invalid("The field scope of an unchanged question changed during validation. Review that question separately.")
        question["fields"] = deepcopy(fields)
    candidate["digest"] = _digest(_encode({key: value for key, value in candidate.items() if key != "digest"}))


def _workbook_pending_answer_review(candidate, origins, input_digest):
    """Keep bound, unapplied answers answerable without granting field ownership."""
    from experiments.portal import scientific_definition_ai as ai
    rows = {row["item_id"]: row for row in candidate["proposal"]["records"]}
    for item_id, origin in origins.items():
        pending = origin.get("pending_owner_answers", []) if isinstance(origin, dict) else []
        if not pending:
            continue
        row = rows.get(item_id)
        if (not row or not isinstance(pending, list) or origin.get("record_sha256") != ai._hash(row)
                or origin.get("source_input_digest") != input_digest):
            raise Invalid("Pending answers do not match the exact current private draft.")
        seen = set()
        for answer in pending:
            if (not isinstance(answer, dict) or answer.get("item_id") != item_id
                    or not isinstance(answer.get("question"), str) or not answer["question"].strip() or len(answer["question"]) > 1200
                    or not isinstance(answer.get("answer"), str) or not answer["answer"].strip() or len(answer["answer"]) > 1000
                    or not isinstance(answer.get("fields"), list) or not answer["fields"]
                    or any(not isinstance(field, str) for field in answer["fields"])
                    or not isinstance(answer.get("choices", []), list) or len(answer.get("choices", [])) > 5
                    or any(not isinstance(choice, str) or not choice.strip() or len(choice) > 200 for choice in answer.get("choices", []))):
                raise Invalid("A pending answer has no exact saved question and field scope.")
            choices = deepcopy(answer.get("choices", []))
            identifier = _digest(_encode([item_id, answer["question"], choices]))[:24]
            if answer.get("id", identifier) != identifier:
                raise Invalid("A pending answer's question identifier no longer matches its saved text and choices.")
            if identifier in seen:
                raise Invalid("A pending question has repeated answers. Resolve that ambiguity explicitly before saving.")
            seen.add(identifier)
            existing = next((question for question in candidate["questions"] if question.get("id") == identifier), None)
            if existing and existing.get("kind") not in {"scientific", "product_output"}:
                raise Invalid("A source correction question cannot be replaced by a pending scientific answer.")
            question = {"id": identifier, "item_id": item_id, "question": answer["question"],
                "kind": existing.get("kind", "scientific") if existing else "scientific",
                "choices": choices, "fields": deepcopy(answer["fields"])}
            candidate["questions"] = [entry for entry in candidate["questions"] if entry.get("id") != identifier] + [question]
            def shape(entry):
                return (entry.get("question"), entry.get("choices", [])) if isinstance(entry, dict) else (entry, [])
            if len(row["questions"]) < 6 and not any(_encode(shape(entry)) == _encode((answer["question"], choices)) for entry in row["questions"]):
                row["questions"].append({"question": answer["question"], "choices": choices})
        origin["record_sha256"] = ai._hash(row)
        if not any(finding.get("code") == "pending_owner_answer" and finding.get("item_id") == item_id
                   for finding in candidate["findings"]):
            candidate["findings"].append(_workbook_finding("pending_owner_answer",
                "Saved answers have not produced an accepted revised row. Review and continue those answers; the retained wording has not acquired scientific ownership.",
                item_id=item_id, kind="scientific"))
        candidate["ready"] = False
    candidate["digest"] = _digest(_encode({key: value for key, value in candidate.items() if key != "digest"}))


def stage_workbook_candidate(root, pack, *, actor_id, proposal, expected_input_digest,
                             local_demo=False, can_write=False, allowed_packs=None, versions=None,
                             _additional_findings=None, _freshness_check=None, _preserve_history_prefix=0,
                             _retained_questions=None):
    """Save an immutable private draft, including incomplete candidates for review."""
    temporary = None
    try:
        _authorized(local_demo, can_write)
        proposal = _workbook_json(proposal)
        _workbook_proposal_ingress(proposal)
        result = compile_workbook_candidate(root, pack, actor_id=actor_id, proposal=proposal,
            expected_input_digest=expected_input_digest, allowed_packs=allowed_packs)
        if not result.get("ok"):
            return result
        if _additional_findings:
            _workbook_ingress_unit(_additional_findings)
            result["findings"].extend(deepcopy(_additional_findings))
            result["ready"] = False
            result["digest"] = _digest(_encode({key: value for key, value in result.items() if key != "digest"}))
        base, product, name, owner, folder = _workbook_scope(root, pack, actor_id, allowed_packs)
        versions, withheld = _workbook_history(versions)
        from experiments.portal import scientific_definition_ai as ai
        submitted_rows = {row["item_id"]: row for row in proposal["records"]}
        compiled_rows = {row["item_id"]: row for row in result["proposal"]["records"]}
        for index, event in enumerate(versions):
            if index < _preserve_history_prefix:
                continue
            if not isinstance(event, dict) or event.get("phase") != "run_summary":
                continue
            origins = event.get("row_origins", {})
            if not isinstance(origins, dict):
                continue
            for item, origin in origins.items():
                before, after = submitted_rows.get(item), compiled_rows.get(item)
                if (not isinstance(origin, dict) or not before or not after
                        or origin.get("record_sha256") != ai._hash(before)):
                    continue
                if all(_workbook_equal(before.get(key), after.get(key)) for key in ("item_id", "values", "configuration_changes")):
                    origin["record_sha256"] = ai._hash(after)
        summaries = [event for event in versions if isinstance(event, dict) and event.get("phase") == "run_summary"]
        if _retained_questions is not None:
            _cfg, _documents, native_refs = _workbook_native(product)
            pending_origins = (summaries[-1].get("row_origins", {}) if summaries
                and summaries[-1].get("owner_answer_provenance_version") == 2 else {})
            _workbook_retain_question_scopes(result, _retained_questions, native_refs,
                pending_origins=pending_origins, input_digest=expected_input_digest)
        if summaries and summaries[-1].get("owner_answer_provenance_version") == 2:
            _workbook_pending_answer_review(result, summaries[-1].get("row_origins", {}), expected_input_digest)
        if withheld:
            result["findings"].append(_workbook_finding("history_withheld",
                "Some attempt-history content was withheld by the input checks. The safe draft is retained; review it and prepare a fresh checked draft before adoption.",
                field="attempt_history", kind="technical"))
            result["ready"] = False
            result["digest"] = _digest(_encode({key: value for key, value in result.items() if key != "digest"}))
        identifier = uuid.uuid4().hex
        candidate = {**result, "versions": versions}
        packet = {"schema_version": 1, "candidate_id": identifier, "pack": name, "owner": owner,
                  "created_at": datetime.now(timezone.utc).isoformat(), "candidate": candidate}
        packet["packet_sha256"] = _digest(_encode(packet))
        folder.mkdir(parents=True, exist_ok=True)
        destination = _safe(folder / (identifier + ".json"))
        with tempfile.NamedTemporaryFile(dir=folder, delete=False) as handle:
            temporary = Path(handle.name)
            handle.write(_encode(packet))
        if _workbook_snapshot(base, product, actor_id=actor_id) != expected_input_digest:
            raise Invalid("The source changed before the private draft was saved. Prepare a current candidate.")
        if _freshness_check is not None:
            _freshness_check(candidate)
        os.link(temporary, destination)
        return {"ok": True, "candidate_id": identifier, "candidate": candidate, "stale": False,
                "ready": candidate["ready"], "changed": False, "notice": WORKBOOK_NOTICE}
    except Exception as error:
        return {"ok": False, "ready": False, "changed": False, "errors": [_workbook_finding("storage", error)["message"]]}
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _read_workbook_packet(folder, name, owner, candidate_id, current_digest):
    if not isinstance(candidate_id, str) or not re.fullmatch(r"[0-9a-f]{32}", candidate_id):
        raise Invalid("Choose a saved workbook draft from this profile and product.")
    packet = json.loads(_read(_safe(folder / (candidate_id + ".json"))))
    unsigned = {key: value for key, value in packet.items() if key != "packet_sha256"}
    if packet.get("packet_sha256") != _digest(_encode(unsigned)) or packet.get("candidate_id") != candidate_id or packet.get("pack") != name or packet.get("owner") != owner:
        raise Invalid("This private workbook draft changed or belongs to another profile.")
    candidate = packet["candidate"]
    core = {key: value for key, value in candidate.items() if key not in {"digest", "versions"}}
    if candidate.get("digest") != _digest(_encode(core)):
        raise Invalid("The candidate content no longer matches its recorded digest.")
    stale = current_digest != candidate["input_digest"]
    return {"ok": True, "candidate_id": candidate_id, "candidate": candidate, "stale": stale,
            "ready": bool(candidate["ready"] and not stale), "created_at": packet["created_at"], "notice": WORKBOOK_NOTICE}


def load_workbook_candidate(root, pack, *, actor_id, candidate_id, allowed_packs=None):
    try:
        base, product, name, owner, folder = _workbook_scope(root, pack, actor_id, allowed_packs)
        # AI access can be withdrawn after a draft was saved. Do not show the
        # stored source-bearing text to a caller without the current read gate.
        from rwd_tools import contract_scaffold
        contract_scaffold.ai_gate(str(product))
        return _read_workbook_packet(folder, name, owner, candidate_id, _workbook_snapshot(base, product, actor_id=actor_id))
    except Exception as error:
        return {"ok": False, "ready": False, "errors": [_workbook_finding("load", error)["message"]]}


def list_workbook_candidates(root, pack, *, actor_id, allowed_packs=None):
    try:
        base, product, name, owner, folder = _workbook_scope(root, pack, actor_id, allowed_packs)
        from rwd_tools import contract_scaffold
        contract_scaffold.ai_gate(str(product))
        current_digest = _workbook_snapshot(base, product, actor_id=actor_id)
        rows = []
        paths = sorted(folder.glob("*.json"), key=lambda item: (item.stat().st_mtime_ns, item.name), reverse=True)[:50]
        for path in paths:
            try:
                loaded = _read_workbook_packet(folder, name, owner, path.stem, current_digest)
            except (ValueError, OSError, TypeError, KeyError):
                continue
            rows.append({"candidate_id": path.stem, "created_at": loaded["created_at"], "stale": loaded["stale"],
                "ready": loaded["ready"], "coverage": loaded["candidate"]["coverage"],
                "question_count": len(loaded["candidate"]["questions"]), "finding_count": len(loaded["candidate"]["findings"])})
        return {"ok": True, "candidates": sorted(rows, key=lambda row: row["created_at"], reverse=True)[:50]}
    except Exception as error:
        return {"ok": False, "candidates": [], "errors": [_workbook_finding("list", error)["message"]]}


def _workbook_row_correction_question(variable):
    return ("For " + str(variable) + ", what correction do you request in this private draft? "
            "Select the exact fields this answer may update; all other saved choices stay unchanged.")


def workbook_row_correction_items(candidate, current_context):
    """Only current, privately owned rows can acquire an explicit revision question."""
    from experiments.portal import scientific_definition_ai as ai
    if (not current_context.get("ok") or not current_context.get("input_digest")
            or candidate.get("input_digest") != current_context["input_digest"]):
        return []
    rows = {row["item_id"]: row for row in (candidate.get("proposal") or {}).get("records", [])}
    sources = {row["item_id"]: row for row in (current_context.get("context") or {}).get("rows", [])}
    origins = ai._workbook_saved_origins(rows, candidate, context=current_context.get("context") or {},
                                        input_digest=current_context["input_digest"])
    eligible = []
    for item, row in rows.items():
        source, origin = sources.get(item, {}), origins.get(item, {})
        protected = origin.get("owner_fields", [])
        if (not source or source.get("retained") or source.get("existing_records")
                or not isinstance(row.get("values"), dict)
                or origin.get("kind") not in {"model_draft", "owner_answer"}
                or origin.get("record_sha256") != ai._hash(row)
                or origin.get("source_input_digest") != current_context["input_digest"]
                or not isinstance(protected, list) or not protected
                or any(not isinstance(field, str) or not field for field in protected)):
            continue
        question = _workbook_row_correction_question(source.get("variable_id", item))
        existing = {entry.get("question") if isinstance(entry, dict) else entry for entry in row.get("questions", [])}
        existing.update(entry.get("question") for entry in candidate.get("questions", []) if entry.get("item_id") == item)
        if question not in existing and len(existing) < 6:
            eligible.append(item)
    return eligible


def request_workbook_row_corrections(root, pack, *, actor_id, candidate_id, item_ids,
                                     expected_candidate_digest, expected_input_digest, confirmed=False,
                                     local_demo=False, can_write=False, allowed_packs=None):
    """Append explicit revision questions in a new private packet, never change science."""
    try:
        from experiments.portal import scientific_definition_ai as ai, authoring_session
        _authorized(local_demo, can_write)
        authoring_session.check_scope(root, pack, actor_id)
        authoring_session.require_edit()
        if confirmed is not True:
            raise Invalid("Explicitly request corrections for the selected private draft rows first.")
        saved = load_workbook_candidate(root, pack, actor_id=actor_id, candidate_id=candidate_id, allowed_packs=allowed_packs)
        if (not saved.get("ok") or saved.get("stale")
                or saved["candidate"]["digest"] != expected_candidate_digest
                or saved["candidate"]["input_digest"] != expected_input_digest):
            raise Invalid("The private draft or current inputs changed. Revalidate and review it before requesting corrections.")
        parent = saved["candidate"]
        base, product, name, owner, folder = _workbook_scope(root, pack, actor_id, allowed_packs)
        path = _safe(folder / (candidate_id + ".json"))
        original = _read(path)
        if not _workbook_equal(json.loads(original).get("candidate"), parent):
            raise Invalid("The private parent changed while opening this request.")
        context = workbook_context(root, pack, actor_id=actor_id, allowed_packs=allowed_packs)
        if not context.get("ok") or context.get("input_digest") != expected_input_digest:
            raise Invalid("The workbook source and current access checks must pass before requesting corrections.")
        eligible = set(workbook_row_correction_items(parent, context))
        if (not isinstance(item_ids, list) or not item_ids or len(item_ids) > 100
                or any(not isinstance(item, str) or item not in eligible for item in item_ids)
                or len(set(item_ids)) != len(item_ids)):
            raise Invalid("Select distinct current private rows with bound saved choices and room for a correction question. Existing, approved, unfinished or already-requested rows cannot be reopened here.")
        history, withheld = _workbook_history(parent.get("versions", []))
        if withheld or not _workbook_equal(history, parent.get("versions", [])):
            raise Invalid("The retained private history fails current privacy checks; it cannot be silently altered or copied.")
        summaries = [event for event in history if event.get("phase") == "run_summary"]
        if not summaries or summaries[-1].get("owner_answer_provenance_version") != 2:
            raise Invalid("Revalidate the saved answer provenance before requesting corrections.")
        origins, _facts, _ancestors = _workbook_revalidation_origins(parent, candidate_id=candidate_id,
            folder=folder, name=name, owner=owner, current_digest=expected_input_digest,
            native_refs=context["write_schema"].get("native_refs", []))
        proposal = deepcopy(parent["proposal"])
        sources = {row["item_id"]: row for row in context["context"]["rows"]}
        added = []
        for row in proposal["records"]:
            if row["item_id"] in item_ids:
                question = _workbook_row_correction_question(sources[row["item_id"]]["variable_id"])
                row["questions"].append({"question": question, "choices": []})
                added.append({"id": _digest(_encode([row["item_id"], question, []]))[:24],
                              "item_id": row["item_id"], "question": question, "choices": []})
                origins[row["item_id"]]["record_sha256"] = ai._hash(row)
        receipt = {"version": 1, "phase": "private_row_correction_request",
            "parent_candidate_id": candidate_id, "parent_candidate_digest": expected_candidate_digest,
            "parent_file_sha256": _digest(original), "input_digest": expected_input_digest,
            "parent_history_sha256": _digest(_encode(history)), "parent_history_count": len(history),
            "history_storage": "intact_immutable_parent",
            "requested_item_ids": list(item_ids), "questions": added, "confirmed": True,
            "model_calls": 0, "approved": False,
            "notice": "Only questions were added. No fields were reopened yet; explicitly choose fields and submit an answer before a model may revise them. The next run stores its own attempt history and references this intact immutable parent."}
        summary = {**deepcopy(summaries[-1]), "version": 2, "phase": "run_summary",
            "input_digest": expected_input_digest, "row_origins": origins, "calls": 0,
            "correction_request_sha256": _digest(_encode(receipt)), "approved": False}
        def unchanged(candidate):
            authoring_session.check_scope(root, pack, actor_id)
            authoring_session.require_edit()
            if _read(path) != original:
                raise Invalid("The private parent changed before the correction request was saved.")
            old_rows = {row["item_id"]: row for row in parent["proposal"]["records"]}
            if set(old_rows) != {row["item_id"] for row in candidate["proposal"]["records"]} or any(
                    any(not _workbook_equal(row.get(key), old_rows[row["item_id"]].get(key))
                        for key in ("item_id", "values", "configuration_changes")) for row in candidate["proposal"]["records"]):
                raise Invalid("A correction request cannot change an existing scientific or native value.")
            current_questions = {entry["id"]: entry for entry in candidate["questions"]}
            if any(not _workbook_equal(current_questions.get(entry["id"]), entry) for entry in parent.get("questions", [])):
                raise Invalid("A correction request cannot remove or change an existing question or its field scope.")
            if not _workbook_equal(candidate["versions"][0], receipt):
                raise Invalid("A correction request must retain the exact immutable history reference.")
        result = stage_workbook_candidate(root, pack, actor_id=actor_id, proposal=proposal,
            expected_input_digest=expected_input_digest, local_demo=local_demo, can_write=can_write,
            allowed_packs=allowed_packs, versions=[receipt, summary],
            _freshness_check=unchanged, _retained_questions=deepcopy(parent.get("questions", [])))
        if result.get("ok"):
            result.update(parent_candidate_id=candidate_id, requested_item_ids=list(item_ids),
                approved=False, released=False, changed=False,
                notice="A new private draft contains the requested correction questions. Select the fields each answer may update, then explicitly continue. No model was called and no product, approval or release was changed.")
        return result
    except Exception as error:
        return {"ok": False, "ready": False, "changed": False,
                "errors": [_workbook_finding("private_correction", error)["message"]]}


WORKBOOK_REVALIDATION_CONFIRMATION = (
    "I reviewed the retained scientific choices and every saved answer against the current workbook, "
    "sources and configuration, and confirm that my saved answers still apply. Create a new private "
    "draft for further review; this does not approve the AI wording, scientific definitions, mappings or build."
)


def _workbook_revalidation_origins(candidate, *, candidate_id, folder, name, owner,
                                   current_digest, native_refs, visited=()):
    """Recover legacy submitted answers without claiming a failed reply applied them."""
    from experiments.portal import scientific_definition_ai as ai, scientific_definitions as science
    if candidate_id in visited or len(visited) >= 8:
        raise Invalid("The retained answer ancestry is cyclic or exceeds eight drafts. Review the original answers explicitly.")
    history, withheld = _workbook_history(candidate.get("versions", []))
    if withheld or not _workbook_equal(history, candidate.get("versions", [])):
        raise Invalid("Retained answer ancestry fails the current privacy checks; it cannot supply ownership.")
    summaries = [event for event in history if isinstance(event, dict) and event.get("phase") == "run_summary"]
    summary = summaries[-1] if summaries else {}
    claims = deepcopy(summary.get("row_origins", {}))
    if not isinstance(claims, dict):
        raise Invalid("The saved row ownership manifest is malformed.")
    exact_rows = {row["item_id"]: row for row in candidate["proposal"]["records"]}
    for item, claim in claims.items():
        if isinstance(claim, dict) and (claim.get("owner_answers") or claim.get("pending_owner_answers") or claim.get("owner_fields")):
            if (item not in exact_rows or claim.get("record_sha256") != ai._hash(exact_rows[item])
                    or claim.get("source_input_digest") != candidate["input_digest"]
                    or claim.get("owner_fields") and not claim.get("owner_answers")):
                raise Invalid("An inherited answer claim is not bound to its exact original row and inputs. Revalidation cannot rebind unproven ownership.")
    has_answers = any(isinstance(claim, dict) and (claim.get("owner_answers") or claim.get("pending_owner_answers"))
                      for claim in claims.values())
    if summary.get("owner_answer_provenance_version") == 2 or not has_answers:
        return claims, [], []
    events = [(index, event) for index, event in enumerate(history)
              if isinstance(event, dict) and event.get("phase") == "explicit_answers"]
    if len(events) != 1:
        raise Invalid("Legacy answer ownership has no unique retained submission. Review and enter those answers explicitly; ownership cannot be inferred.")
    index, event = events[0]
    parent_id = event.get("parent_candidate_id")
    parent_loaded = _read_workbook_packet(folder, name, owner, parent_id, current_digest)
    parent_raw = _read(_safe(folder / (parent_id + ".json")))
    parent_packet = json.loads(parent_raw)
    parent = parent_loaded["candidate"]
    if (parent_packet.get("candidate_id") != parent_id or parent_packet.get("pack") != name
            or parent_packet.get("owner") != owner
            or parent_packet.get("packet_sha256") != _digest(_encode({key: value for key, value in parent_packet.items() if key != "packet_sha256"}))
            or not _workbook_equal(parent_packet.get("candidate"), parent)
            or not _workbook_equal(event.get("proposal"), parent["proposal"])
            or event.get("input_digest") != candidate["input_digest"]
            or parent["input_digest"] != candidate["input_digest"]):
        raise Invalid("The legacy answer submission does not match its intact private parent and source inputs. Re-enter current answers explicitly.")
    prior, facts, receipts = _workbook_revalidation_origins(parent, candidate_id=parent_id, folder=folder,
        name=name, owner=owner, current_digest=current_digest, native_refs=native_refs, visited=(*visited, candidate_id))
    receipts.append({"candidate_id": parent_id, "packet_sha256": parent_packet["packet_sha256"], "file_sha256": _digest(parent_raw)})
    parent_rows = {row["item_id"]: row for row in parent["proposal"]["records"]}
    rows = {row["item_id"]: row for row in candidate["proposal"]["records"]}
    if set(parent_rows) != set(rows):
        raise Invalid("Legacy answer ancestry changes the requirement rows; reconcile the source manually.")
    questions = parent.get("questions", [])
    submitted = {item: [] for item in rows}
    answer_keys = set()
    for answer in event.get("answers", []):
        if (not isinstance(answer, dict) or set(answer) not in ({"item_id", "question", "answer"}, {"id", "item_id", "question", "answer"})
                or answer.get("item_id") not in rows):
            raise Invalid("The retained answer submission is malformed.")
        key = (answer.get("id"), answer["item_id"], answer.get("question"))
        if key in answer_keys:
            raise Invalid("The retained submission repeats an answer. Resolve that ambiguity explicitly.")
        answer_keys.add(key)
        matches = [question for question in questions if question.get("item_id") == answer["item_id"]
            and question.get("kind") in {"scientific", "product_output"}
            and question.get("question") == answer.get("question") and (
                question.get("id") == answer["id"] if "id" in answer else not question.get("choices"))]
        if len(matches) != 1:
            raise Invalid("A retained answer does not identify one exact parent question. Re-enter it explicitly.")
        question = matches[0]
        fields = question.get("fields", [question["field"]] if isinstance(question.get("field"), str) else [])
        exact = isinstance(fields, list) and bool(fields) and all(isinstance(field, str) and (
            field.split(".", 1)[0] in science.FIELDS or field in native_refs) for field in fields)
        atom = {**deepcopy(answer), "fields": fields if exact else ["*"], "choices": deepcopy(question.get("choices", []))}
        submitted[answer["item_id"]].append(atom)
    # The historical writer visited parent questions, not the submitted map's
    # UI insertion order. Reconstruct that exact append order without changing
    # any question, answer, choice or field metadata.
    for atoms in submitted.values():
        atoms.sort(key=lambda atom: next(position for position, question in enumerate(questions)
            if question.get("item_id") == atom["item_id"] and question.get("question") == atom["question"]
            and (question.get("id") == atom["id"] if "id" in atom else not question.get("choices"))))
    raw_parent_summaries = [entry for entry in parent.get("versions", []) if entry.get("phase") == "run_summary"]
    raw_prior = raw_parent_summaries[-1].get("row_origins", {}) if raw_parent_summaries else {}
    def science_equal(left, right):
        return all(_workbook_equal(left.get(key), right.get(key)) for key in ("item_id", "values", "configuration_changes"))
    recovered = {}
    for item, row in rows.items():
        claim = claims.get(item, {})
        base = deepcopy(prior.get(item, {"kind": "unknown"}))
        if not submitted[item]:
            if not science_equal(row, parent_rows[item]) and base.get("owner_answers"):
                raise Invalid("An unsubmitted legacy row changed previously accepted science. Review its ownership manually.")
            base.update(record_sha256=ai._hash(row), source_input_digest=candidate["input_digest"], has_model_draft=False)
            recovered[item] = base
            continue
        expected_answers = [*deepcopy(raw_prior.get(item, {}).get("owner_answers", [])), *submitted[item]]
        expected_fields = sorted(set(raw_prior.get(item, {}).get("owner_fields", [])) |
                                 {field for answer in submitted[item] for field in answer["fields"]})
        if (not isinstance(claim, dict) or claim.get("record_sha256") != ai._hash(row)
                or claim.get("source_input_digest") != candidate["input_digest"]
                or not _workbook_equal(claim.get("owner_answers"), expected_answers)
                or not _workbook_equal(claim.get("owner_fields"), expected_fields)):
            raise Invalid("Legacy answer claims do not match the exact submitted answers and retained row. Re-enter the answers explicitly.")
        accepted, accepted_other_rows = [], []
        for attempt in history[index + 1:]:
            if (not isinstance(attempt, dict) or attempt.get("phase") != "generation" or attempt.get("findings") != []
                    or attempt.get("input_digest") != candidate["input_digest"] or item not in attempt.get("item_ids", [])
                    or not isinstance(attempt.get("response_sha256"), str) or not re.fullmatch(r"[a-f0-9]{64}", attempt["response_sha256"])
                    or item in attempt.get("retained_prior_item_ids", [])):
                continue
            attempts = [proposed for proposed in (attempt.get("proposal") or {}).get("records", [])
                        if isinstance(proposed, dict) and proposed.get("item_id") == item and isinstance(proposed.get("values"), dict)]
            if any(science_equal(row, proposed) for proposed in attempts):
                accepted.append(attempt.get("version"))
            elif attempts:
                accepted_other_rows.append(attempt.get("version"))
        if accepted_other_rows and not accepted:
            raise Invalid("An accepted legacy answer was followed by different scientific values. The exact ownership transition cannot be proved; review this row explicitly.")
        if base.get("owner_answers") and not ai._workbook_owner_fields_retained(parent_rows[item], row,
                protected_fields=base.get("owner_fields", ["*"]),
                answered_fields=[field for answer in submitted[item] for field in answer["fields"]] if accepted else []):
            raise Invalid("The legacy reply changed a previously accepted answer without a proven new accepted response.")
        if accepted:
            base["owner_answers"] = [*deepcopy(base.get("owner_answers", [])), *submitted[item]]
            base["owner_fields"] = sorted(set(base.get("owner_fields", [])) | {field for answer in submitted[item] for field in answer["fields"]})
            base["owner_answer_ids"] = sorted(set(base.get("owner_answer_ids", [])) | {answer["id"] for answer in submitted[item] if "id" in answer})
            base["kind"] = "owner_answer"
            keys = {(answer.get("id"), answer["question"]) for answer in submitted[item]}
            base["pending_owner_answers"] = [answer for answer in base.get("pending_owner_answers", [])
                if (answer.get("id"), answer.get("question")) not in keys]
        else:
            keys = {(answer.get("id"), answer["question"]) for answer in submitted[item]}
            base["pending_owner_answers"] = [answer for answer in base.get("pending_owner_answers", [])
                if (answer.get("id"), answer.get("question")) not in keys] + submitted[item]
        # This new integrity binding does not grant old model wording authority.
        base.update(record_sha256=ai._hash(row), source_input_digest=candidate["input_digest"], has_model_draft=False)
        recovered[item] = base
        facts.append({"candidate_id": candidate_id, "item_id": item,
            "submitted_answer_ids": [answer.get("id") for answer in submitted[item]],
            "disposition": "accepted_response" if accepted else "pending_no_matching_accepted_response",
            "accepted_generation_versions": accepted, "parent_candidate_id": parent_id})
    return recovered, facts, receipts


def preview_workbook_candidate_revalidation(root, pack, *, actor_id, candidate_id, expected_digest,
                                          local_demo=False, can_write=False, allowed_packs=None):
    """Recheck an immutable old proposal; never infer that only software changed."""
    try:
        _authorized(local_demo, can_write)
        saved = load_workbook_candidate(root, pack, actor_id=actor_id, candidate_id=candidate_id,
                                        allowed_packs=allowed_packs)
        if not saved.get("ok") or saved["candidate"]["digest"] != expected_digest:
            raise Invalid("The saved workbook draft is unavailable or changed. Select it again before revalidation.")
        parent = saved["candidate"]
        base, product, name, owner, folder = _workbook_scope(root, pack, actor_id, allowed_packs)
        parent_raw = _read(_safe(folder / (candidate_id + ".json")))
        parent_packet = json.loads(parent_raw)
        if (parent_packet.get("candidate_id") != candidate_id or parent_packet.get("pack") != name
                or parent_packet.get("owner") != owner
                or parent_packet.get("packet_sha256") != _digest(_encode({key: value for key, value in parent_packet.items() if key != "packet_sha256"}))
                or not _workbook_equal(parent_packet.get("candidate"), parent)):
            raise Invalid("The saved workbook draft changed while preparing revalidation.")
        context = workbook_context(root, pack, actor_id=actor_id, allowed_packs=allowed_packs)
        if not context.get("ok"):
            raise Invalid("The current workbook source and access checks must pass before revalidation.")
        _workbook_context_ingress(context["context"], native_columns=context["context"].get("source_bindings", {}).get("native_columns", {}))
        proposal = deepcopy(parent["proposal"])
        _workbook_proposal_ingress(proposal)
        rows = {row["item_id"]: row for row in proposal["records"]}
        current_rows = {row["item_id"]: row for row in context["context"]["rows"]}
        if len(rows) != len(proposal["records"]) or set(rows) != set(current_rows):
            raise Invalid("The current workbook has different requirement rows. Review those source changes and start a new draft; no rows or answers were dropped.")
        for item_id, row in rows.items():
            current = current_rows[item_id]
            if (current.get("retained") or current.get("existing_records")) and (
                    row.get("values") is not None or row.get("configuration_changes") or row.get("questions")):
                raise Invalid("A current saved or approved definition would be replaced by the old proposal. Review it in the variable editor; revalidation cannot overwrite current human work.")
        history, withheld = _workbook_history(parent.get("versions", []))
        if withheld or not _workbook_equal(history, parent.get("versions", [])):
            raise Invalid("Some retained history or answers fail the current privacy checks. The old draft is preserved; unsafe content cannot be copied into a revalidated draft.")
        history_storage = "intact_immutable_parent" if len(history) > 38 else "copied_prefix_and_intact_parent"
        summaries = [event for event in history if isinstance(event, dict) and event.get("phase") == "run_summary"]
        summary = summaries[-1] if summaries else {}
        claims = summary.get("row_origins", {})
        pending = summary.get("pending_item_ids", [])
        if (not isinstance(claims, dict) or not isinstance(pending, list)
                or len(set(pending)) != len(pending) or any(item not in rows for item in pending)):
            raise Invalid("The saved row provenance or unfinished-row manifest is malformed.")
        from experiments.portal import scientific_definition_ai as ai, scientific_definitions as science
        if any(not ai._workbook_pending_shell(rows[item], claims.get(item, {})) for item in pending):
            raise Invalid("The saved unfinished-row manifest includes a scientific draft. Revalidation cannot reopen that row for generation.")
        claims, ownership_reconciliation, ancestor_packets = _workbook_revalidation_origins(parent,
            candidate_id=candidate_id, folder=folder, name=name, owner=owner,
            current_digest=context["input_digest"], native_refs=context["write_schema"].get("native_refs", []))
        answers, accepted_answers, pending_answers, origins, provenance_findings = [], [], [], {}, []
        def valid_fields(fields):
            return isinstance(fields, list) and bool(fields) and all(isinstance(field, str) and (
                field == "*" or field.split(".", 1)[0] in science.FIELDS
                or field in context["write_schema"].get("native_refs", [])) for field in fields)
        for item_id, row in rows.items():
            claim = claims.get(item_id, {})
            bound = (isinstance(claim, dict) and claim.get("kind") in {"owner_answer", "model_draft"}
                     and claim.get("record_sha256") == ai._hash(row)
                     and claim.get("source_input_digest") == parent["input_digest"])
            owner_answers = claim.get("owner_answers", []) if isinstance(claim, dict) else []
            pending_owner_answers = claim.get("pending_owner_answers", []) if isinstance(claim, dict) else []
            if not isinstance(owner_answers, list) or not isinstance(pending_owner_answers, list) or any(not isinstance(answer, dict)
                    or answer.get("item_id") != item_id or not isinstance(answer.get("answer"), str)
                    or not answer["answer"].strip() or len(answer["answer"]) > 1000
                    or not isinstance(answer.get("question"), str) or not answer["question"].strip()
                    or len(answer["question"]) > 1200 or not valid_fields(answer.get("fields"))
                    or "id" in answer and (not isinstance(answer["id"], str) or not re.fullmatch(r"[a-f0-9]{24}", answer["id"]))
                    or not isinstance(answer.get("choices", []), list) or len(answer.get("choices", [])) > 5
                    or any(not isinstance(choice, str) or not choice.strip() or len(choice) > 200 for choice in answer.get("choices", []))
                    for answer in [*owner_answers, *pending_owner_answers]):
                raise Invalid("The retained owner answers are malformed. Review the original private draft before continuing.")
            if owner_answers and (not bound or not valid_fields(claim.get("owner_fields"))
                    or not isinstance(claim.get("owner_answer_ids", []), list)
                    or any(not isinstance(value, str) for value in claim.get("owner_answer_ids", []))):
                raise Invalid("The retained owner-answer provenance is unbound or malformed. Revalidation cannot drop those answers or silently trust them; review the original draft and enter current answers explicitly.")
            if owner_answers and any(not any(owned == "*" or field == owned or field.startswith(owned + ".")
                    or "#" in owned and field.startswith(owned.rstrip("/") + "/")
                    for owned in claim["owner_fields"])
                    for answer in owner_answers for field in answer["fields"]):
                raise Invalid("A retained answer is outside its recorded protected fields. Review this inconsistent ownership record; revalidation cannot silently weaken answer protection.")
            if pending_owner_answers and (claim.get("record_sha256") != ai._hash(row)
                    or claim.get("source_input_digest") != parent["input_digest"]):
                raise Invalid("The pending answers are not bound to the retained draft. Review them explicitly before reusing them.")
            answers.extend(deepcopy([*owner_answers, *pending_owner_answers]))
            accepted_answers.extend(deepcopy(owner_answers))
            pending_answers.extend(deepcopy(pending_owner_answers))
            if bound and owner_answers:
                origins[item_id] = {"kind": "owner_answer", "has_model_draft": False,
                    "owner_fields": deepcopy(claim.get("owner_fields", ["*"])),
                    "owner_answers": deepcopy(owner_answers),
                    "owner_answer_ids": deepcopy(claim.get("owner_answer_ids", []))}
            else:
                origins[item_id] = {"kind": "unknown"}
                if row.get("values") is not None or owner_answers:
                    provenance_findings.append(_workbook_finding("revalidation_provenance_unknown",
                        "The earlier scientific draft has no bound owner-answer provenance. Review this row explicitly; revalidation does not turn old model wording into current scientific evidence.",
                        item_id=item_id, kind="scientific"))
            if pending_owner_answers:
                origins[item_id]["pending_owner_answers"] = deepcopy(pending_owner_answers)
        fresh = compile_workbook_candidate(root, pack, actor_id=actor_id, proposal=proposal,
            expected_input_digest=context["input_digest"], allowed_packs=allowed_packs)
        if not fresh.get("ok"):
            raise Invalid("The retained proposal cannot be compiled against current inputs. Review its source and schema findings before starting a new draft.")
        for old, new in zip(proposal["records"], fresh["proposal"]["records"]):
            if any(not _workbook_equal(old.get(key), new.get(key)) for key in ("item_id", "values", "configuration_changes")):
                raise Invalid("Revalidation changed a saved scientific choice or native value. Review that change separately; it cannot be silently accepted.")
        if provenance_findings:
            fresh["findings"].extend(deepcopy(provenance_findings))
            fresh["ready"] = False
            fresh["digest"] = _digest(_encode({key: value for key, value in fresh.items() if key != "digest"}))
        for row in fresh["proposal"]["records"]:
            origins[row["item_id"]].update(record_sha256=ai._hash(row), source_input_digest=context["input_digest"])
        _workbook_retain_question_scopes(fresh, parent.get("questions", []), context["write_schema"].get("native_refs", []),
            pending_origins=origins, input_digest=context["input_digest"])
        _workbook_pending_answer_review(fresh, origins, context["input_digest"])
        question_changes = []
        for item in rows:
            before = [question for question in parent.get("questions", []) if question.get("item_id") == item]
            after = [question for question in fresh["questions"] if question.get("item_id") == item]
            if not _workbook_equal(before, after):
                question_changes.append({"item_id": item, "before": before, "after": after})
        if (_workbook_snapshot(base, product, actor_id=actor_id) != context["input_digest"]
                or _read(_safe(folder / (candidate_id + ".json"))) != parent_raw):
            raise Invalid("The parent draft or current inputs changed during revalidation. Refresh the preview.")
        result = {"ok": True, "can_save": True, "candidate_id": candidate_id,
            "parent_candidate_digest": expected_digest, "parent_packet_sha256": parent_packet["packet_sha256"],
            "parent_file_sha256": _digest(parent_raw), "previous_input_digest": parent["input_digest"],
            "parent_history_count": len(history), "parent_history_sha256": _digest(_encode(history)),
            "history_storage": history_storage,
            "input_digest": context["input_digest"], "change_classification": "unproven_component_changes",
            "confirmation_text": WORKBOOK_REVALIDATION_CONFIRMATION,
            "reconfirmation": {"required": True, "reason": "legacy_component_manifest_unavailable",
                "item_ids": list(rows), "answers": answers,
                "accepted_answers": accepted_answers, "pending_answers": pending_answers},
            "current_context": {key: deepcopy(context["context"].get(key)) for key in
                ("rows", "native_configuration", "source_bindings")},
            "candidate": fresh, "files": fresh["files"], "findings": fresh["findings"], "checks": fresh["checks"],
            "question_changes": question_changes, "provenance_findings": provenance_findings,
            "ownership_reconciliation": ownership_reconciliation, "ancestor_packets": ancestor_packets,
            "row_origins": origins, "pending_item_ids": pending, "errors": [],
            "approved": False, "released": False, "changed": False,
            "notice": "This preview rechecks a saved proposal against current inputs. The original draft stays unchanged. No code-only change or scientific approval is inferred."}
        result["preview_digest"] = _digest(_encode(result))
        return result
    except Exception as error:
        return {"ok": False, "can_save": False, "changed": False, "errors": [_workbook_finding("revalidation", error)["message"]]}


def revalidate_workbook_candidate(root, pack, *, actor_id, candidate_id, expected_digest,
                                  expected_preview_digest, expected_input_digest, confirmed=False,
                                  local_demo=False, can_write=False, allowed_packs=None):
    """Record explicit answer reconfirmation in a NEW private candidate only."""
    try:
        _authorized(local_demo, can_write)
        if confirmed is not True:
            raise Invalid("Review the current source, choices and retained answers and explicitly confirm them before creating a new private draft.")
        preview = preview_workbook_candidate_revalidation(root, pack, actor_id=actor_id, candidate_id=candidate_id,
            expected_digest=expected_digest, local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
        if not preview.get("can_save"):
            return preview
        if preview["preview_digest"] != expected_preview_digest or preview["input_digest"] != expected_input_digest:
            raise Invalid("The current inputs or revalidation preview changed. Review a fresh preview and confirm again.")
        base, product, name, owner, folder = _workbook_scope(root, pack, actor_id, allowed_packs)
        parent_path = _safe(folder / (candidate_id + ".json"))
        parent_raw = _read(parent_path)
        if _digest(parent_raw) != preview["parent_file_sha256"]:
            raise Invalid("The original workbook draft changed after the revalidation preview.")
        parent = json.loads(parent_raw)["candidate"]
        preserved = 0 if preview["history_storage"] == "intact_immutable_parent" else len(parent.get("versions", []))
        receipt = {"version": preserved + 1, "phase": "candidate_revalidation",
            "parent_candidate_id": candidate_id, "parent_candidate_digest": expected_digest,
            "parent_packet_sha256": preview["parent_packet_sha256"], "parent_file_sha256": preview["parent_file_sha256"],
            "parent_history_count": preview["parent_history_count"], "parent_history_sha256": preview["parent_history_sha256"],
            "history_storage": preview["history_storage"],
            "previous_input_digest": preview["previous_input_digest"], "input_digest": expected_input_digest,
            "preview_digest": expected_preview_digest, "change_classification": preview["change_classification"],
            "confirmed": True, "confirmation_text": WORKBOOK_REVALIDATION_CONFIRMATION,
            "owner_answers_sha256": _digest(_encode(preview["reconfirmation"]["answers"])),
            "ownership_reconciliation": deepcopy(preview["ownership_reconciliation"]),
            "ancestor_packets": deepcopy(preview["ancestor_packets"]),
            "approved": False, "model_calls": 0}
        receipt_digest = _digest(_encode(receipt))
        from experiments.portal import scientific_definition_ai as ai
        origins = deepcopy(preview["row_origins"])
        for row in preview["candidate"]["proposal"]["records"]:
            origin = origins[row["item_id"]]
            origin.update(record_sha256=ai._hash(row), source_input_digest=expected_input_digest)
            if origin["kind"] == "owner_answer":
                origin["reconfirmation_receipt_sha256"] = receipt_digest
        summary = {"version": receipt["version"] + 1, "phase": "run_summary", "input_digest": expected_input_digest,
            "owner_answer_provenance_version": 2,
            "row_origins": origins, "pending_item_ids": deepcopy(preview["pending_item_ids"]),
            "calls": 0, "approved": False, "revalidation_receipt_sha256": receipt_digest,
            "findings": deepcopy(preview["candidate"]["findings"])}
        def unchanged(candidate):
            if _read(parent_path) != parent_raw:
                raise Invalid("The original workbook draft changed before the new private draft was saved.")
            for ancestor in preview["ancestor_packets"]:
                if _digest(_read(_safe(folder / (ancestor["candidate_id"] + ".json")))) != ancestor["file_sha256"]:
                    raise Invalid("Retained answer ancestry changed before the new private draft was saved.")
            if any(not _workbook_equal(candidate.get(key), preview["candidate"].get(key)) for key in
                   ("proposal", "digest", "files", "findings", "checks")):
                raise Invalid("Fresh validation differs from the reviewed preview. Refresh and confirm the latest findings.")
        result = stage_workbook_candidate(root, pack, actor_id=actor_id,
            proposal=deepcopy(parent["proposal"]), expected_input_digest=expected_input_digest,
            local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs,
            versions=[*deepcopy(parent.get("versions", [])[:preserved]), receipt, summary],
            _additional_findings=preview["provenance_findings"], _freshness_check=unchanged,
            _preserve_history_prefix=preserved,
            _retained_questions=deepcopy(parent.get("questions", [])))
        if result.get("ok"):
            result.update(parent_candidate_id=candidate_id, approved=False, released=False, changed=False,
                notice="A new private draft retains your reconfirmed answers and current check results. The original draft and product files are unchanged; further scientific and technical review remains required.")
        return result
    except Exception as error:
        return {"ok": False, "can_save": False, "changed": False, "errors": [_workbook_finding("revalidation", error)["message"]]}


def adopt_workbook_candidate(root, pack, *, actor_id, candidate_id, expected_digest, confirmed=False,
                             local_demo=False, can_write=False, allowed_packs=None):
    """Explicitly adopt a freshly checked contract/configuration draft together."""
    descriptor, lock = None, None
    try:
        _authorized(local_demo, can_write)
        if confirmed is not True:
            raise Invalid("Review the complete contract and native configuration diff, then confirm adopting this draft.")
        base, product, name, _owner, _folder = _workbook_scope(root, pack, actor_id, allowed_packs)
        from experiments.portal import scientific_definitions as science, delivery_binding
        lock = science._contract_lock(product)
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        saved = load_workbook_candidate(root, pack, actor_id=actor_id, candidate_id=candidate_id, allowed_packs=allowed_packs)
        if not saved.get("ok") or saved["stale"] or saved["candidate"]["digest"] != expected_digest:
            raise Invalid("The draft or source changed. Reload and inspect the current candidate before adopting it.")
        candidate = saved["candidate"]
        fresh = compile_workbook_candidate(root, pack, actor_id=actor_id, proposal=candidate["proposal"],
            expected_input_digest=candidate["input_digest"], allowed_packs=allowed_packs)
        if not fresh.get("ok") or not fresh.get("ready") or fresh.get("digest") != expected_digest:
            raise Invalid("The exact candidate no longer passes every workbook check. Resolve its current findings before adopting.")
        if _workbook_snapshot(base, product, actor_id=actor_id) != candidate["input_digest"]:
            raise Invalid("The product changed immediately before adoption. Nothing was saved.")
        delivery_binding._replace_files(product, fresh["files"])
        return {"ok": True, "changed": bool(fresh["files"]), "candidate_id": candidate_id, "approved": False,
                "released": False, "notice": "The checked workbook draft was adopted. Scientific and source reviews, build validation and release approvals remain separate.",
                "files": [{key: item[key] for key in ("path", "before_sha256", "after_sha256")} for item in fresh["files"]]}
    except Exception as error:
        return {"ok": False, "changed": False, "approved": False, "released": False, "errors": [_workbook_finding("adopt", error)["message"]]}
    finally:
        if descriptor is not None:
            os.close(descriptor)
            lock.unlink(missing_ok=True)


def _unfinished_native_checks(product):
    """Run semantic/dependency readers even when scaffold structure blocks execution."""
    from engine import validate as native, source_contract, config_schema
    cfg = load_config(product / "config/data_product.yaml")
    structure = config_schema.validate_document(cfg.raw)
    for role in cfg.roles():
        structure.extend(config_schema.validate_document(cfg.pack(role), role=role))
    _reads, unreadable = native.stage_reads(cfg)
    if unreadable:
        raise Invalid("Source dependencies could not be read: " + " ".join(unreadable))
    return {"structure": structure, "semantics": native._semantic_problems(cfg, strict=True),
            "sources": native.availability_problems(cfg, strict=True) + source_contract.compiled(cfg)["problems"]}


def _unfinished_finding_identity(validator, message):
    """Stable identities for two explicit coverage counters; other evidence is exact."""
    if validator == "contract_lint":
        match = re.fullmatch(r"parsed \d+ variable records from FUNCTIONAL_CONTRACT\.md \(floor (\d+)\) . parser or file changed", message)
        if match:
            return (validator, "contract_record_floor", match[1])
    if validator == "contract_binding":
        # Adding a definition changes these explanatory counts. Keep its exact
        # native reference, required total and all surrounding failure text.
        message = re.sub(r"This contract accounts for \d+ of (\d+) specification item\(s\), with \d+ never examined",
                         r"This contract accounts for <drafted> of \1 specification item(s), with <remaining> never examined", message)
    return validator, message


def _unfinished_new_findings(validator, before, after):
    remaining = Counter(_unfinished_finding_identity(validator, error) for error in before)
    result = []
    for error in after:
        identity = _unfinished_finding_identity(validator, error)
        if remaining[identity]:
            remaining[identity] -= 1
        else:
            result.append(error)
    return result


def preview_unfinished_workbook_candidate(root, pack, *, actor_id, candidate_id, expected_digest,
                                          selected_item_ids, allowed_packs=None):
    """Check a selected, unapproved subset; never interpret this as ready adoption."""
    try:
        from experiments.portal import scientific_definitions as science
        from rwd_tools import contract_record as records
        base, product, name, _owner, _folder = _workbook_scope(root, pack, actor_id, allowed_packs)
        saved = load_workbook_candidate(root, pack, actor_id=actor_id, candidate_id=candidate_id, allowed_packs=allowed_packs)
        if not saved.get("ok") or saved["stale"] or saved["candidate"]["digest"] != expected_digest:
            raise Invalid("The draft or source changed. Refresh the candidate before saving unfinished work.")
        candidate = saved["candidate"]
        if any(item.get("code") == "history_withheld" for item in candidate.get("findings", [])):
            raise Invalid("This candidate's retained history is incomplete. Prepare a new candidate before saving.")
        context = workbook_context(root, pack, actor_id=actor_id, allowed_packs=allowed_packs)
        if not context.get("ok") or context["input_digest"] != candidate["input_digest"]:
            raise Invalid("Current workbook evidence could not be verified.")
        offered = {row["item_id"]: row for row in context["context"]["rows"]}
        proposal = deepcopy(candidate["proposal"])
        rows = proposal["records"]
        identifiers = [row["item_id"] for row in rows]
        if len(set(identifiers)) != len(identifiers) or set(identifiers) != set(offered):
            raise Invalid("Every workbook row must occur exactly once in the retained candidate.")
        if (not isinstance(selected_item_ids, list) or not selected_item_ids or
                any(not isinstance(item, str) for item in selected_item_ids) or
                len(set(selected_item_ids)) != len(selected_item_ids) or not set(selected_item_ids) <= set(offered)):
            raise Invalid("Select distinct workbook rows from this candidate to save.")
        selected = set(selected_item_ids)
        before = _read(product / "handoff/FUNCTIONAL_CONTRACT.md").decode("utf-8")
        old_blocks = list(science.cl.records(before, keep_unnamed=True))
        old_names = {str(science.cl._scalar(block, "variable_id") or "").casefold() for block in old_blocks}
        if (any(science.cl._fenced_blocks(before)) or science.cl.table_shape_errors(before)
                or "" in old_names or len(old_names) != len(old_blocks)):
            raise Invalid("Repair the existing contract's structure and ambiguous identifiers before saving new definitions.")
        protected_refs = {ref for block in old_blocks for ref in science.cl._list(block, "implementation_refs") or [] if "#/" in ref}
        drafted, changes = [], []
        for row in rows:
            item = row["item_id"]
            if item not in selected:
                # The original packet remains immutable, including owner answers.
                row.update(values=None, configuration_changes=[], questions=[])
                continue
            if offered[item].get("retained") or offered[item].get("existing_records"):
                raise Invalid("An existing definition is protected. Use its row editor for revisions: " + item)
            if row.get("questions") or not isinstance(row.get("values"), dict):
                raise Invalid("Answer this row's questions before selecting it: " + item)
            values = _workbook_judgment(row["values"])
            if str(values["variable_id"]).casefold() in old_names:
                raise Invalid("This identifier already belongs to an existing definition: " + values["variable_id"])
            if _workbook_unanswered(values):
                raise Invalid("Complete the selected row's required scientific fields: " + item)
            refs = values.get("implementation_refs") or []
            for change in row["configuration_changes"]:
                if not any(change["ref"] == ref or change["ref"].startswith(ref + "/") for ref in refs if "#/" in ref):
                    raise Invalid("A selected row cannot change an unrelated native field: " + change["ref"])
            record, errors = records.merge_evidence(values, str(product), item, reader="ai")
            if errors:
                raise Invalid(" ".join(errors))
            record, errors = records.apply_status(record)
            if errors:
                raise Invalid(" ".join(errors))
            record["status"] = dict(records.INITIAL_STATUS)
            _rendered, errors = records.row_for(record)
            if errors:
                raise Invalid(" ".join(errors))
            drafted.append(record)
            changes.extend(row["configuration_changes"])
        if changes and any(any(ref.startswith("engine:") for ref in science.cl._list(block, "implementation_refs") or [])
                           for block in old_blocks):
            raise Invalid("An existing definition depends on engine behavior. Review changes to its shared native settings through the existing definition editor before saving new configuration.")
        checked = compile_workbook_candidate(root, pack, actor_id=actor_id, proposal=proposal,
            expected_input_digest=candidate["input_digest"], allowed_packs=allowed_packs)
        if not checked.get("ok") or not checked.get("checks") or any(not check.get("completed") for check in checked["checks"]):
            raise Invalid("Every selected-draft validator must complete before unfinished work can be saved.")
        blocking = [finding["message"] for finding in checked["findings"] if finding.get("code") != "candidate_validation"
            and (not finding.get("item_id") or finding["item_id"] in selected)]
        blocking.extend(question["question"] for question in checked["questions"] if question.get("item_id") in selected)
        _cfg, _documents, allowed = _workbook_native(product)
        # Protect every existing definition, including an unapproved human draft.
        files, _owners, conflicts = _workbook_changes(product, rows, allowed, protected_refs)
        blocking.extend(finding["message"] for finding in conflicts)
        schemas = _workbook_schemas(allowed)
        import jsonschema
        for change in changes:
            ref = change["ref"]
            if ref not in schemas:
                raise Invalid("The selected native field has no exact schema: " + ref)
            fragment = {**deepcopy(schemas[ref]), "$defs": schemas["$defs"]}
            jsonschema.Draft202012Validator.check_schema(fragment)
            blocking.extend(ref + ": " + error.message for error in
                            jsonschema.Draft202012Validator(fragment).iter_errors(change["value"]))
        after = records.upsert(before, drafted)
        if any(block not in list(science.cl.records(after, keep_unnamed=True)) for block in old_blocks):
            raise Invalid("The draft would change an existing definition.")
        files.append(_workbook_file("handoff/FUNCTIONAL_CONTRACT.md", before, after))
        remaining = []
        with tempfile.TemporaryDirectory(prefix="rwd-unfinished-workbook-") as temporary:
            shadow = _candidate(base, product, {"pack": name, "files": []}, Path(temporary))
            baseline_native = _unfinished_native_checks(shadow)
            baseline_lint = science.cl.run(str(shadow))[0]
            baseline_binding = cb.check(str(shadow), cb.pack_yaml(str(shadow)))[0]
            for file in files:
                (shadow / file["path"]).write_bytes(file["after"].encode("utf-8"))
            updated_native = _unfinished_native_checks(shadow)
            for validator, errors in updated_native.items():
                baseline = Counter(baseline_native[validator])
                blocking.extend((Counter(errors) - baseline).elements())
                for error in errors:
                    # Untouched operational scaffolds may remain unfinished. No
                    # arbitrary pre-existing clinical failure is exempted here.
                    if not re.match(r"^(?:config\.)?(?:run[.\[]|treatment_status[.\[: ])", error):
                        blocking.append(error)
                    else:
                        remaining.append({"validator": validator, "message": error})
            lint = science.cl.run(str(shadow))[0]
            names = {record["variable_id"] for record in drafted}
            blocking.extend(error for error in lint if any("[" + name + "]" in error for name in names))
            blocking.extend(_unfinished_new_findings("contract_lint", baseline_lint, lint))
            # Check prospective implementation bindings as well as the saved
            # draft statuses, which deliberately make no implementation claim.
            prospective = next(file["after"] for file in checked["files"] if file["path"] == "handoff/FUNCTIONAL_CONTRACT.md")
            (shadow / "handoff/FUNCTIONAL_CONTRACT.md").write_text(prospective, encoding="utf-8", newline="\n")
            binding = cb.check(str(shadow), cb.pack_yaml(str(shadow)))[0]
            blocking.extend(_unfinished_new_findings("contract_binding", baseline_binding, binding))
            blocking.extend(error for error in binding if any("[" + name + "]" in error for name in names))
            remaining.extend({"validator": "contract_lint", "message": error} for error in lint
                             if not any("[" + name + "]" in error for name in names))
            remaining.extend({"validator": "contract_binding", "message": error} for error in binding
                             if not any("[" + name + "]" in error for name in names))
        if _workbook_snapshot(base, product, actor_id=actor_id) != candidate["input_digest"]:
            raise Invalid("The product changed during draft validation. Reload before saving.")
        result = {"ok": True, "can_save": not blocking, "ready": False, "approved": False, "released": False,
            "changed": False, "candidate_id": candidate_id, "candidate_digest": expected_digest,
            "input_digest": candidate["input_digest"], "selected_item_ids": sorted(selected),
            "skipped_item_ids": sorted(set(offered) - selected), "errors": list(dict.fromkeys(blocking)),
            "remaining_findings": remaining, "retained_questions": deepcopy(candidate["questions"]), "files": files,
            "checks": {"native_before": baseline_native, "native_after": updated_native,
                "contract_lint_before": baseline_lint, "contract_lint_after": lint,
                "prospective_binding_before": baseline_binding, "prospective_binding_after": binding},
            "notice": "This saves unapproved definitions and configuration only. Implementation, source review, validation and release remain unfinished. Refresh the workbook candidate after saving."}
        result["digest"] = _digest(_encode(result))
        return result
    except Exception as error:
        return {"ok": False, "can_save": False, "ready": False, "changed": False,
                "errors": [_workbook_finding("unfinished_preview", error)["message"]]}


def save_unfinished_workbook_candidate(root, pack, *, actor_id, candidate_id, expected_digest,
                                       selected_item_ids, expected_preview_digest, confirmed=False,
                                       local_demo=False, can_write=False, allowed_packs=None):
    """Save an explicitly reviewed draft with a durable, non-approval receipt."""
    descriptor, lock = None, None
    try:
        _authorized(local_demo, can_write)
        if confirmed is not True:
            raise Invalid("Review the selected rows, exact diff and remaining work, then confirm the unfinished save.")
        from experiments.portal import scientific_definitions as science, delivery_binding
        base, product, name, owner, folder = _workbook_scope(root, pack, actor_id, allowed_packs)
        lock = science._contract_lock(product)
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        preview = preview_unfinished_workbook_candidate(root, pack, actor_id=actor_id, candidate_id=candidate_id,
            expected_digest=expected_digest, selected_item_ids=selected_item_ids, allowed_packs=allowed_packs)
        if not preview.get("can_save") or preview.get("digest") != expected_preview_digest:
            raise Invalid("The selected draft or checks changed. Preview its current contents before saving.")
        receipt = {"schema_version": 1, "operation": "unfinished_workbook_save", "pack": name, "owner": owner,
            "created_at": datetime.now(timezone.utc).isoformat(), "state": "prepared", "preview": preview}
        folder = _safe(folder / "unfinished_saves")
        folder.mkdir(parents=True, exist_ok=True)
        receipt_path = _safe(folder / ("unfinished-" + uuid.uuid4().hex + ".json"))
        science._atomic(receipt_path, _encode(receipt))
        if _workbook_snapshot(base, product, actor_id=actor_id) != preview["input_digest"]:
            raise Invalid("The product changed immediately before saving. Nothing was saved.")
        delivery_binding._replace_files(product, preview["files"])
        receipt["state"] = "saved_unapproved"
        warning = None
        try:
            science._atomic(receipt_path, _encode(receipt))
        except (OSError, ValueError):
            warning = "Draft files were saved, but the private receipt remains prepared. Compare its file hashes before retrying; ask Engineering to repair the private storage."
        return {"ok": True, "changed": True, "ready": False, "approved": False, "released": False,
            "selected_item_ids": preview["selected_item_ids"], "skipped_item_ids": preview["skipped_item_ids"],
            "receipt": receipt_path.name, "notice": preview["notice"], "warning": warning}
    except Exception as error:
        return {"ok": False, "changed": False, "ready": False, "approved": False, "released": False,
                "errors": [_workbook_finding("unfinished_save", error)["message"]]}
    finally:
        if descriptor is not None:
            os.close(descriptor)
            lock.unlink(missing_ok=True)
