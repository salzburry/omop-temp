# RWD Portal 1.277.0 — local source transfer QC

Package: `RWD-Portal-1.277.0-company-source.zip`  
SHA-256: `27b1aff69b84ab20b207e29cd7048c78bf12da47c9c89778a48aba3d6bc04e92`  
Contents: 1,409 source files; 9,617,869 ZIP bytes.

The final ZIP is byte-identical to an independent export of the validated source.
This package supports local company Git import and branch-based work. It is not
a hosted deployment, authenticated scientific approval or patient-data release.

## Results

| Check | Recorded result |
|---|---|
| Fresh constrained Python environment | Installation succeeded; pip check passed; dependency profile matched |
| Manifest, checksum and independent repeat export | Passed; closed member list and every file hash verified |
| Quick local checks | 12 passed; no failures or skips |
| Focused regression cases | 445 passing final outcomes after the test-fixture repair below |
| New product, template reuse and existing revision | 3 passed; study separation, source handoff and stale-state recovery checked |
| Actual selected-product Spark build | Passed; two prewritten expected-output cases checked |
| Python/R output comparisons | 2 passed: ECOG tie handling and generated derived-output dependencies |
| Managed launcher lifecycle | Start, healthy status and stop passed from the fresh extraction |
| Packaged source after tests | All 1,409 manifest file hashes unchanged |

Across the recorded test invocations, **451 distinct pytest cases have passing
final results**, with no remaining failures or skips. This is a reconciled count,
not a single full CI execution. The first focused run recorded 440 passes and five
failures because a handcrafted test argument object omitted the current
`sheet_domain` parser field. Those tests now enter through the real CLI parser;
all five stale-input refusal and no-install assertions remain and passed on
rerun. The rebuilt package changed only that test file and its source manifest;
application code was unchanged. The machine-readable QC file lists outcomes and
receipt hashes. Raw receipts are retained separately and are not bundled with
workstation paths or private runtime diagnostics.

The first standalone conformance invocation recorded two skips because the
user-local R package library was not selected. It was rerun using the portal's
existing runtime environment adapter with R required. Both engines then executed
and matched for the two cases. The initial skips remain in the machine-readable
record; they are not counted as passes.

## Package cleanup

Git/editor history, private drafts, uploads, local accounts/settings, connections,
caches, environments and build output are excluded. Recognizable credentials,
personal paths and personal emails were not found in the packaged content; the
scan includes bounded supported compressed document contents. This is pattern
checking, not general sensitive-data classification.

The registered signer list starts empty; the known-ineligible key guard remains.
One verified retired/deleted ledger object is omitted, with the omission recorded
in the manifest. Original source records are unchanged. All four bundled workbook
hashes are preserved. Scientific citations, required attribution and retained
audit evidence remain intact. Personal repository examples and obsolete personal
hosting instructions were replaced with neutral company-import instructions.

## Import and verification

1. Extract into a short local path outside synchronized folders and import the
   source into the company repository, preserving hidden configuration folders.
2. Follow `docs/LOCAL_INSTALLATION.md` to create the user's own environment.
3. Verify the archive with `platform/tools/source_transfer.py --verify <zip>`.
4. Start through `Start-RwdPortal.cmd`; connect the user's own authorized model
   from that repository's editor window if assistant access is needed.

The source includes the exporter, manifest, tests and setup instructions. The
company must supply actual repository owners/review controls and independently
administered reviewer authentication before claiming authenticated approvals.
Reference-material permissions, clinical review and validation of the actual
patient delivery remain required. Full company CI, hosted execution, claims
refresh execution and a real-data release were not established by these checks.
The two added conversation scenarios have offline coverage; they have not been
clinically adjudicated or compared live against a vendor's tool.
