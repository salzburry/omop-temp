# Refresh governance — git IS the ledger

Every released data cut (a **refresh**, e.g. `2026q1` → `2026q2`) is tracked as a committed
manifest, so the full history of what was built, from what, and signed off by whom lives in git.

## How a refresh is tracked

```
refreshes/<family>/<product>/<spec_version>/<refresh>.yaml      # one manifest per (product, spec_version, refresh) — committed
```

The manifest (see `REFRESH_TEMPLATE.yaml`, built by `platform/engine/refresh.py`) records:
spec version, **git commit**, run params, row/cohort **counts**, the **QC** result, the
**golden-comparison** summary, and **sign-off**. Because it's committed, the ADS is reproducible:
checkout the commit (or the release tag), re-run the same config + refresh.

## Lifecycle (one refresh)

1. **Run** the build (`databricks bundle run rwdp_build --var refresh=… --var artifact_root=…`).
   The runner runs source QC → build → staging → ADS QC + golden gate → deliverables (dictionary +
   dashboard + TFLs) → **durable ledger** → **publish** (immutable versioned tables + public-view swap).
   It writes `manifest.yaml` + `qc_report.md` (and the dictionaries) to the **durable `artifact_root`**
   (a UC Volume / DBFS path) **BEFORE** the swap. A Databricks job can't push to git, so this is the
   reliable record.
2. **Promote into git** (the actual ledger): copy the manifest from `artifact_root` into
   `refreshes/<family>/<product>/<spec_version>/<refresh>.yaml` and open a PR — manually
   (`databricks fs cp <artifact_root>/manifest.yaml "refreshes/<family>/<product>/<spec_version>/<refresh>.yaml"`)
   or via a small scheduled "promote" CI job. The PR is the reviewed refresh record.
3. **QC gate** (`engine/qc.qc_gate`) must already have passed (the runner fails the job otherwise);
   the QC reviewer fills `sign_off.qc_*` in the PR.
4. **Golden-compare** vs the prior refresh / original R ADS is attached in the manifest `golden`.
5. **Release**: set `status: released` + `sign_off.released_*`, merge, and tag
   `release/<registry_code>/<spec_version>/<refresh>` (e.g. `release/mcrpc/202606/2026q1`; the `spec_version`
   segment avoids cross-version collisions). ADS rows carry `spec_version` + `data_refresh` stamps matching the manifest.
6. A superseded refresh is marked `status: superseded` (kept for audit).

> **The R engine is not a refresh path.** `platform/engine-r/` can rebuild the same ADS from the same
> config for cross-validation, but it has **no manifest, QC/golden gate, or release pointer** — it never
> produces a `refreshes/…` ledger entry. Use it only as a side-by-side check (write to a **separate `_r`
> schema**, then golden-compare vs the governed Python ADS); see `../platform/engine-r/README.md`.

## Branching

- Spec/engine changes land on feature branches → PR → `main` (reviewed config diff).
- A refresh that only changes the data cut is a `--var refresh=…` run + a manifest commit; no code
  change. The manifest's `git_commit` pins the exact engine/spec used.
