# =============================================================================
# Prostate mCRPC RWDP — original R / dbplyr build script (RECONSTRUCTION)
# =============================================================================
# The 202603 program was supplied as a document rather than as a runnable file,
# so this is a faithful transcription of it. It captures the real logic and the
# actual column and table names, but:
#   * it is NOT byte-for-byte identical to the original (whitespace, comment
#     wording, and the original's many commented-out "push/pull to Databricks"
#     experiment blocks are summarised, not reproduced line-for-line);
#   * verify any specific line against the PDF before relying on it.
#
# The validated, executable translation of this script lives in the PySpark
# engine in this same folder (engine/, config/, variables/, codelists/,
# databricks/). This .R file is provided as a human-readable reference only.
# =============================================================================

# ---- Load libraries ---------------------------------------------------------
library(odbc)        # database connections (ODBC)
library(DBI)         # standard database interface
library(dbplyr)      # dplyr over database tables
library(dplyr)       # data manipulation
library(tidyr)       # tidying data
library(purrr)       # functional programming over lists/vectors
library(lubridate)   # date/time handling
library(stringr)     # string manipulation
library(sparklyr)    # Spark interface
library(gsklog)      # logging utility

# ---- Setup / helpers / connection ------------------------------------------
source('/mnt/code/R/01_project_necessities/001_setup.R')             # setup file
source('/mnt/code/R/01_project_necessities/002_helper_functions.R')  # helper functions
source('/mnt/code/R/helperScripts/databases/personalSchemaFunctions.R')  # personal-schema helpers

con <- connect()   # database connection

# Parameters (these were loose globals in the original; the PySpark port moves
# them into config/data_product.yaml):
#   dbname          - source schema holding the t_* tables
#   refresh         - snapshot suffix, e.g. paste0("t_enh_prostate_", refresh)
#   personal_schema - output schema
#   index_start, index_end, study_start - study window

# ---- Source tables ----------------------------------------------------------
# Enhanced prostate cohort; advanceddiagnosisdate = max(metastatic, CRPC) date
enh_pros_pano <- tbl(con, in_schema(dbname, paste0("t_enh_prostate_", refresh))) %>%
  mutate(advanceddiagnosisdate = pmax(MetastaticDiagnosisDate, CRPCDate, na.rm = TRUE))

# Line of therapy table (lowercase line name; ordered by line number)
enh_pros_pano_lot <- tbl(con, in_schema(dbname, paste0("t_enh_prostate_lot_", refresh))) %>%
  window_order(patientid, LineNumber) %>%
  mutate(LineName = tolower(LineName))

# Non-mCRPC (nmCRPC / HSPC) lines
enh_pros_pano_non_mcrpc <- enh_pros_pano_lot %>%
  filter(LineSetting %in% c("nmCRPC", "HSPC")) %>%
  window_order(patientid, StartDate)

# mCRPC lines, numbered by start date -> new_lot_n
lenh_pros_pano_lot <- enh_pros_pano_lot %>%
  filter(LineSetting == "mCRPC") %>%
  window_order(patientid, StartDate) %>%
  group_by(patientid) %>%
  mutate(new_lot_n = row_number()) %>%
  ungroup()

enh_pros_pano_diagnosis <- tbl(con, in_schema(dbname, paste0("t_diagnosis_", refresh)))
enh_pros_pano_dem       <- tbl(con, in_schema(dbname, paste0("t_demographics_", refresh)))
enh_pros_pano_ses       <- tbl(con, in_schema(dbname, paste0("t_socdetofhealth_", refresh)))
enh_pros_pano_practice  <- tbl(con, in_schema(dbname, paste0("t_practice_", refresh)))
enh_pros_pano_visit     <- tbl(con, in_schema(dbname, paste0("t_visit_", refresh)))
enh_pros_pano_telemed   <- tbl(con, in_schema(dbname, paste0("t_telemedicine_", refresh)))
enh_pros_pano_drugepisode <- tbl(con, in_schema(dbname, paste0("t_enh_prostate_drg_epsode_", refresh)))

# Mortality (dateofdeath imputed to the 15th when month-level)
enh_pros_pano_mortality <- tbl(con, in_schema(dbname, paste0("t_mortality_v2_", refresh)))

enh_pros_pano_orals    <- tbl(con, in_schema(dbname, paste0("t_enh_prostate_orals_", refresh)))
enh_pros_pano_alphabet <- tbl(con, in_schema(dbname, paste0("t_enh_prostate_alpbta_emt_", refresh)))
enh_pros_pano_prov     <- tbl(con, in_schema(dbname, paste0("t_enh_prostate_provenge_", refresh)))

enh_pros_pano_bl_ecog <- tbl(con, in_schema(dbname, paste0("t_baseline_ecog_", refresh))) %>%
  select(PatientID, ECOGDate, ECOGValue, LineNumber, LineStartDate)
enh_pros_pano_ecog <- tbl(con, in_schema(dbname, paste0("t_ecog_", refresh))) %>%
  select(patientid, ecogdate, ecogvalue)
enh_pros_pano_vitals <- tbl(con, in_schema(dbname, paste0("t_vitals_", refresh)))

# Lowercase the column names of every enh_pros_pano_* lazy table
object_names <- ls()
enh_pros_pano_pointers <- object_names[sapply(object_names,
                                              function(x) startsWith(x, "enh_pros_pano"))]
for (pointer_name in enh_pros_pano_pointers) {
  lazy_table <- get(pointer_name)
  if (inherits(lazy_table, "tbl_lazy")) {
    lazy_table <- lazy_table %>% rename_with(tolower)
    assign(pointer_name, lazy_table)
  } else {
    warning(paste("Object", pointer_name, "is not a tbl_lazy; skipping."))
  }
}

# =============================================================================
# Index cohort definition
# =============================================================================
index_lot_cohort <- function(coh_flag) {
  if (coh_flag == "overall") {
    pros_index <- enh_pros_pano %>%
      filter(advanceddiagnosisdate >= index_start & advanceddiagnosisdate <= index_end) %>%
      select(patientid, advanceddiagnosisdate)
    final_pros_index <- pros_index %>%
      mutate(index_date = as.Date(advanceddiagnosisdate)) %>%
      select(patientid, index_date, advanceddiagnosisdate)
    return(final_pros_index)
  } else if (nchar(coh_flag) == 4) {   # "lotN"
    enh_pros_pano_index <- enh_pros_pano %>%
      filter(advanceddiagnosisdate >= index_start & advanceddiagnosisdate <= index_end) %>%
      select(patientid, advanceddiagnosisdate)

    lot_number <- as.numeric(gsub("[^0-9.]", "", coh_flag))   # LOT number from the flag
    lot_index <- lenh_pros_pano_lot %>%
      filter((startdate >= index_start & startdate <= index_end) & new_lot_n == lot_number) %>%
      select(patientid, linename, linenumber, startdate, enddate, new_lot_n)

    final_lot_index <- lot_index %>%
      inner_join(enh_pros_pano_index, by = "patientid") %>%
      mutate(index_date = as.Date(startdate)) %>%
      select(patientid, index_date, advanceddiagnosisdate,
             linenumber, linename, startdate, enddate, new_lot_n)
    return(final_lot_index)
  }
}

# Cohort list and per-cohort index tables
coh_list <- c("overall", "lot1", "lot2", "lot3")
for (coh_flag in coh_list) {
  if (coh_flag == "overall") {
    var_name <- paste0("enh_pros_pano_", coh_flag, "_index_tbl")
  } else {
    var_name <- paste0("enh_pros_pano_lot", substring(coh_flag, 4), "_index_tbl")
  }
  df <- index_lot_cohort(coh_flag)
  createInPersonalSchema(df, var_name, replace = TRUE)   # push to Databricks
  assign(var_name, df)
  rm(df)
}

# =============================================================================
# Demographics
# =============================================================================
# Aggregate practice type to one value per patient
enh_pros_pano_practice_agg <- enh_pros_pano_practice %>%
  distinct(patientid, practicetype) %>%
  group_by(patientid) %>%
  summarize(practicetype_agg = sql(
    "STRING_AGG(practicetype, ', ') WITHIN GROUP (ORDER BY practicetype)"))

demographics_variable_addn <- function(input_ds) {
  df_dem_interim <- input_ds %>%
    left_join(enh_pros_pano_dem, by = "patientid") %>%
    left_join(enh_pros_pano_practice_agg, by = "patientid") %>%
    left_join(enh_pros_pano_ses, by = "patientid") %>%
    mutate(
      year_index = year(index_date),
      age = year_index - as.numeric(birthyear),
      agegrl = case_when(
        age >= 0  & age <= 18 ~ "0-18",
        age >= 19 & age <= 34 ~ "19-34",
        age >= 35 & age <= 49 ~ "35-49",
        age >= 50 & age <= 64 ~ "50-64",
        age >= 65 & age <= 74 ~ "65-74",
        age >= 75 & age <= 84 ~ "75-84",
        age >= 85             ~ ">=85",
        TRUE ~ "Unknown"),
      agegrln = case_when(
        age >= 0  & age <= 18 ~ 1,
        age >= 19 & age <= 34 ~ 2,
        age >= 35 & age <= 49 ~ 3,
        age >= 50 & age <= 64 ~ 4,
        age >= 65 & age <= 74 ~ 5,
        age >= 75 & age <= 84 ~ 6,
        age >= 85             ~ 7,
        TRUE ~ 8),
      regionl = case_when(
        state %in% c('ME','VT','NH','MA','RI','CT','NY','PA','NJ') ~ 'Northeast',
        state %in% c('ND','SD','NE','KS','MN','IA','MO','WI','IL','MI','IN','OH') ~ 'Midwest',
        state %in% c('TX','OK','AR','LA','KY','TN','MS','AL','MD','DE','DC','VA','WV','NC','SC','GA','FL') ~ 'South',
        state %in% c('CA','WA','OR','NV','AZ','UT','NM','CO','ID','MT','WY','HI','AK') ~ 'West',
        state == 'PR' ~ 'Other region',
        is.na(state) ~ 'Missing',
        TRUE ~ 'Unknown'),
      regionln = case_when(
        state %in% c('ME','VT','NH','MA','RI','CT','NY','PA','NJ') ~ 1,
        state %in% c('ND','SD','NE','KS','MN','IA','MO','WI','IL','MI','IN','OH') ~ 2,
        state %in% c('TX','OK','AR','LA','KY','TN','MS','AL','MD','DE','DC','VA','WV','NC','SC','GA','FL') ~ 3,
        state %in% c('CA','WA','OR','NV','AZ','UT','NM','CO','ID','MT','WY','HI','AK') ~ 4,
        state == 'PR' ~ 5,
        is.na(state) ~ 6,
        TRUE ~ 7),
      eth = case_when(
        race == 'Hispanic or Latino' | ethnicity == 'Hispanic or Latino' ~ 'Hispanic or Latino',
        ethnicity == 'Not Hispanic or Latino' ~ 'Not Hispanic or Latino',
        is.na(ethnicity) ~ 'Unknown/Missing',
        TRUE ~ 'Unknown/Missing'),
      ethn = case_when(
        race == 'Hispanic or Latino' | ethnicity == 'Hispanic or Latino' ~ 1,
        ethnicity == 'Not Hispanic or Latino' ~ 2,
        is.na(ethnicity) ~ 3,
        TRUE ~ 4),
      race = case_when(
        race == 'Asian' ~ 'Asian',
        race == 'Black or African American' ~ 'Black or African American',
        race == 'White' ~ 'White',
        race == 'Hispanic or Latino' ~ 'Other Race',
        race == 'Other Race' ~ 'Other Race',
        is.na(race) ~ 'Unknown/Missing',
        TRUE ~ 'Unknown/Missing'),
      racen = case_when(
        race == 'Asian' ~ 1,
        race == 'Black or African American' ~ 2,
        race == 'White' ~ 3,
        race == 'Hispanic or Latino' ~ 4,
        race == 'Other Race' ~ 4,
        is.na(race) ~ 5,
        TRUE ~ 5),
      practic = case_when(
        practicetype_agg == 'ACADEMIC' ~ 'Academic only',
        practicetype_agg == 'COMMUNITY' ~ 'Community only',
        practicetype_agg == 'ACADEMIC,COMMUNITY' ~ 'Both academic and community',
        TRUE ~ 'Missing'),
      practicn = case_when(
        practicetype_agg == 'ACADEMIC' ~ 1,
        practicetype_agg == 'COMMUNITY' ~ 2,
        practicetype_agg == 'ACADEMIC,COMMUNITY' ~ 3,
        TRUE ~ 99),
      ses = case_when(
        is.na(sesindex2015_2019) ~ 'Missing',
        TRUE ~ sesindex2015_2019)
    ) %>%
    select(patientid, index_date, advanceddiagnosisdate, birthyear, birthsex,
           age, agegrl, agegrln, state, regionl, regionln, race, racen,
           ethnicity, eth, ethn, practicn, practic, ses)
  return(df_dem_interim)
}

for (coh_flag in coh_list) {
  if (coh_flag == "overall") {
    var_name <- paste0("enh_pros_pano_", coh_flag, "_dem_tbl")
    input_ds <- get(paste0("enh_pros_pano_", coh_flag, "_index_tbl"))
  } else {
    var_name <- paste0("enh_pros_pano_lot", substring(coh_flag, 4), "_dem_tbl")
    input_ds <- get(paste0("enh_pros_pano_lot", substring(coh_flag, 4), "_index_tbl"))
  }
  df <- demographics_variable_addn(input_ds)
  createInPersonalSchema(df, var_name, replace = TRUE)
  assign(var_name, df)
  rm(df)
}

# =============================================================================
# Clinical characteristics
# =============================================================================
# --- enhanced prostate variables (stage / gleason / PSA / mCRPC) -------------
clin_char_enh_pros_var <- function(input_ds) {
  clin_char_enh_pros_pano_variables <- input_ds %>%
    left_join(enh_pros_pano, by = "patientid", suffix = c(".ind", ".ec")) %>%
    left_join(
      enh_pros_pano_lot %>%
        filter(linenumber == 1) %>%
        mutate(linestartdate = startdate, lineenddate = enddate) %>%
        select(patientid, linenumber, linestartdate, lineenddate),
      by = "patientid") %>%
    mutate(
      mcrpcdd = pmax(metastaticdiagnosisdate, crpcdate, na.rm = TRUE),
      mcrpc = case_when(index_start <= mcrpcdd & mcrpcdd <= index_end ~ 1, TRUE ~ 0),
      mcrpcddyr = year(mcrpcdd),
      init = diagnosisdate,
      inityr = year(diagnosisdate),
      mpcdd = metastaticdiagnosisdate,
      mpcddyr = year(mpcdd),
      stage = case_when(
        groupstage %in% c('I','IA','IB','IC') ~ 'I',
        groupstage %in% c('II','IIA','IIB','IIC') ~ 'II',
        groupstage %in% c('III','IIIA','IIIB','IIIC','IIIC1','IIIC2') ~ 'III',
        groupstage %in% c('IV','IVA','IVB') ~ 'IV',
        tolower(groupstage) == 'unknown/not documented' ~ 'Unknown/not documented',
        startsWith(groupstage, '0') ~ '0',
        TRUE ~ 'CHECK'),
      stagen = case_when(
        groupstage %in% c('I','IA','IB','IC') ~ 1,
        groupstage %in% c('II','IIA','IIB','IIC') ~ 2,
        groupstage %in% c('III','IIIA','IIIB','IIIC','IIIC1','IIIC2') ~ 3,
        groupstage %in% c('IV','IVA','IVB') ~ 4,
        tolower(groupstage) == 'unknown/not documented' ~ 5,
        TRUE ~ 99),
      gleason = gleasonscore,
      psadiag_init = psainitialdiagnosis,
      psadiag_met  = psametdiagnosis
    ) %>%
    select(patientid, index_date, histology, groupstage, issurgery, surgerydate,
           init, inityr, iadvdxdt, stage, stagen, issurg, issurgn, surg, surgn,
           mcrpc, mcrpcdd, mcrpcddyr, mpcdd, mpcddyr,
           gleason, psadiag_init, psadiag_met)
  return(clin_char_enh_pros_pano_variables)
}

# --- baseline ECOG (closest to index within [-30, +7] days) ------------------
clin_char_ecog_var <- function(input_ds) {
  # Step 1: union baseline_ecog + ecog within the window around index
  bl_ecog_pull <- input_ds %>%
    inner_join(enh_pros_pano_bl_ecog, by = "patientid") %>%
    filter(ecogdate >= dbplyr::sql("DATE_SUB(index_date, 30)"),
           ecogdate <= dbplyr::sql("DATE_ADD(index_date, 7)")) %>%
    select(patientid, index_date, ecogdate, ecogvalue) %>%
    union_all(
      input_ds %>%
        inner_join(enh_pros_pano_ecog, by = "patientid") %>%
        filter(ecogdate >= dbplyr::sql("DATE_SUB(index_date, 30)"),
               ecogdate <= dbplyr::sql("DATE_ADD(index_date, 7)")) %>%
        select(patientid, index_date, ecogdate, ecogvalue)) %>%
    mutate(ecogvalue = ifelse(is.na(ecogvalue), NA, as.integer(ecogvalue)))

  # Step 2: absolute gap between ecogdate and index_date
  gap_calc <- bl_ecog_pull %>%
    mutate(gap = abs(datediff(ecogdate, index_date))) %>%
    select(patientid, index_date, ecogdate, gap) %>% distinct()

  # Step 3: minimum gap per patient/index
  min_gap <- gap_calc %>%
    group_by(patientid, index_date) %>%
    summarise(min_gap = min(gap, na.rm = TRUE), .groups = "drop")

  # Step 4: ecogdate closest to index (ties -> earliest)
  bl_max_ecogdt <- gap_calc %>%
    inner_join(min_gap, by = c("patientid", "index_date")) %>%
    filter(gap == min_gap) %>%
    group_by(patientid, index_date) %>%
    summarise(ecogdate = min(ecogdate, na.rm = TRUE), .groups = "drop")

  # Step 5: the ecog value at that date (max on ties)
  bl_ecog_value <- bl_ecog_pull %>%
    inner_join(bl_max_ecogdt, by = c("patientid", "index_date", "ecogdate")) %>%
    group_by(patientid, index_date, ecogdate) %>%
    summarise(ecogvalue = max(ecogvalue, na.rm = TRUE), .groups = "drop")

  # Step 6: label, "Unknown" for null value within a record
  bl_ecog_final <- bl_ecog_value %>%
    mutate(
      ecog = case_when(is.na(ecogvalue) ~ "Unknown", TRUE ~ as.character(ecogvalue)),
      ecogn = case_when(
        ecog == '0' ~ 1, ecog == '1' ~ 2, ecog == '2' ~ 3,
        ecog == '3' ~ 4, ecog == '4' ~ 5, ecog == 'Unknown' ~ 6, TRUE ~ 7)
    ) %>%
    select(patientid, index_date, ecogdate, ecog, ecogn)

  # No record at all -> "Missing"
  indx_tbl <- input_ds %>% select(patientid, index_date)
  clin_char_ecog_tbl <- indx_tbl %>%
    left_join(bl_ecog_final, by = c("patientid", "index_date")) %>%
    mutate(
      ecog = case_when(is.na(ecog) ~ 'Missing', TRUE ~ ecog),
      ecogn = case_when(is.na(ecogn) ~ 7, TRUE ~ ecogn)
    ) %>%
    select(patientid, index_date, ecogdate, ecog, ecogn)
  return(clin_char_ecog_tbl)
}

# --- vitals: BMI / BSA from baseline height & weight -------------------------
clin_char_vitals_var <- function(input_ds) {
  bl_vitals_pull <- input_ds %>%
    inner_join(
      enh_pros_pano_vitals %>%
        filter(((toupper(test) == 'BODY HEIGHT' & testunitscleaned == "cm") |
                (toupper(test) == 'BODY WEIGHT' & testunitscleaned == "kg")) &
               testresultcleaned > 0) %>%
        select(patientid, test, testdate, resultdate, testresult,
               testresultcleaned, testunitscleaned),
      by = "patientid") %>%
    mutate(vitaldate = pmax(testdate, resultdate, na.rm = TRUE)) %>%
    filter(vitaldate <= index_date) %>%
    select(patientid, index_date, test, testdate, resultdate, vitaldate,
           testresult, testresultcleaned, testunitscleaned)

  bl_max_vitaldate <- bl_vitals_pull %>%
    group_by(patientid, index_date, test) %>%
    summarise(vitaldate = max(vitaldate, na.rm = TRUE), .groups = "drop")

  bl_vital_value <- bl_max_vitaldate %>%
    inner_join(bl_vitals_pull, by = c("patientid", "index_date", "test", "vitaldate")) %>%
    group_by(patientid, index_date, test, vitaldate, testunitscleaned) %>%
    summarise(vitalvalue = max(testresultcleaned), .groups = "drop") %>%
    select(patientid, index_date, test, vitaldate, vitalvalue, vitalunit = testunitscleaned)

  bl_bmi_calc <- input_ds %>%
    left_join(bl_vital_value %>% filter(toupper(test) == 'BODY HEIGHT') %>%
                select(patientid, index_date, heightdt = vitaldate, height = vitalvalue),
              by = c("patientid", "index_date")) %>%
    left_join(bl_vital_value %>% filter(toupper(test) == 'BODY WEIGHT') %>%
                select(patientid, index_date, weightdt = vitaldate, weight = vitalvalue),
              by = c("patientid", "index_date")) %>%
    mutate(
      bmi = case_when((!is.na(weight) & !is.na(height)) ~ (weight / (height / 100)^2), TRUE ~ NA),
      bmigrl = case_when(
        (bmi > 0 & bmi < 18.5) ~ 'Underweight',
        (bmi >= 18.5 & bmi < 25) ~ 'Normal weight',
        (bmi >= 25 & bmi < 30) ~ 'Overweight',
        (bmi >= 30) ~ 'Obese',
        TRUE ~ 'Missing'),
      bmigrln = case_when(
        (bmi > 0 & bmi < 18.5) ~ 1, (bmi >= 18.5 & bmi < 25) ~ 2,
        (bmi >= 25 & bmi < 30) ~ 3, (bmi >= 30) ~ 4, TRUE ~ 5),
      bsa = case_when((!is.na(weight) & !is.na(height)) ~
                        (0.007184 * (height)^0.725 * (weight)^0.425), TRUE ~ NA)
    ) %>%
    select(patientid, index_date, weightdt, weight, heightdt, height, bmi, bmigrl, bmigrln, bsa)
  return(bl_bmi_calc)
}

# --- follow-up end date & death date ----------------------------------------
clin_char_fuend_dthdt_var <- function(input_ds) {
  index_tbl <- input_ds %>% select(patientid, index_date) %>% distinct()

  fuend_dt_tbl <- index_tbl %>%
    left_join(enh_pros_pano_visit %>% group_by(patientid) %>%
                summarise(last_visitdate = max(visitdate, na.rm = TRUE)) %>% distinct(),
              by = "patientid") %>%
    left_join(enh_pros_pano_telemed %>% group_by(patientid) %>%
                summarise(last_televisitdate = max(visitdate, na.rm = TRUE)) %>% distinct(),
              by = "patientid") %>%
    left_join(enh_pros_pano_lot %>% group_by(patientid) %>%
                summarise(last_lotenddate = max(enddate, na.rm = TRUE)) %>% distinct(),
              by = "patientid") %>%
    left_join(enh_pros_pano_orals %>%
                filter((startdategranularity != 'Year' | is.na(startdategranularity)) &
                       !is.na(enddate)) %>%
                group_by(patientid) %>%
                summarise(last_oralenddate = max(enddate, na.rm = TRUE)) %>% distinct(),
              by = "patientid") %>%
    left_join(enh_pros_pano_alphabet %>% group_by(patientid) %>%
                summarise(last_alphadate = max(administrationdate, na.rm = TRUE)) %>% distinct(),
              by = "patientid") %>%
    left_join(enh_pros_pano_prov %>% group_by(patientid) %>%
                summarise(last_provdate = max(startdate, na.rm = TRUE)) %>% distinct(),
              by = "patientid") %>%
    mutate(
      fu_enddt_preliminary = pmax(last_visitdate, last_alphadate, last_provdate,
                                  last_televisitdate, last_lotenddate, last_oralenddate,
                                  na.rm = TRUE)
    ) %>%
    # Join death, imputing coarse-granularity dates
    left_join(
      enh_pros_pano_mortality %>%
        mutate(dateofdeath_init = dbplyr::sql(
          "CASE
             WHEN LENGTH(dateofdeath) = 7 THEN CAST(CONCAT(dateofdeath, '-15') AS DATE)
             WHEN LENGTH(dateofdeath) = 4 THEN CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
             ELSE NULL END")) %>%
        select(patientid, dateofdeath, dateofdeath_init) %>% distinct(),
      by = "patientid") %>%
    mutate(
      # NOTE: the original carried "Before/After" and "seem to be wrong" comments here.
      # Year-level deaths use index-year logic so a same-year death after the index isn't
      # dropped below the index date.
      dateofdeath_v1 = dbplyr::sql(
        "CASE
           WHEN LENGTH(dateofdeath) = 7 THEN dateofdeath_init
           WHEN LENGTH(dateofdeath) = 4
             AND EXTRACT(MONTH FROM dateofdeath_init) <= EXTRACT(MONTH FROM index_date)
             AND EXTRACT(YEAR  FROM dateofdeath_init)  = EXTRACT(YEAR  FROM index_date)
             THEN CAST(CONCAT(dateofdeath, '-12-31') AS DATE)
           WHEN LENGTH(dateofdeath) = 4
             AND EXTRACT(MONTH FROM dateofdeath_init) >  EXTRACT(MONTH FROM index_date)
             AND EXTRACT(YEAR  FROM dateofdeath_init)  = EXTRACT(YEAR  FROM index_date)
             THEN CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
           WHEN LENGTH(dateofdeath) = 4
             AND EXTRACT(YEAR FROM index_date) < EXTRACT(YEAR FROM dateofdeath_init)
             THEN CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
           ELSE dateofdeath_init END"),
      f_death = dbplyr::sql("CASE WHEN dateofdeath IS NOT NULL THEN 1 ELSE 0 END")
    ) %>%
    mutate(
      death_dt_preliminary = dbplyr::sql(
        "CASE
           WHEN LENGTH(dateofdeath) = 4 THEN dateofdeath_v1
           WHEN LENGTH(dateofdeath) = 7
             AND SUBSTR(fu_enddt_preliminary, 1, 7) = SUBSTR(dateofdeath_v1, 1, 7)
             THEN CAST(LAST_DAY(dateofdeath_v1) AS DATE)
           ELSE dateofdeath_v1 END"),
      fu_enddt = dbplyr::sql(
        "CASE
           WHEN death_dt_preliminary IS NOT NULL AND fu_enddt_preliminary > death_dt_preliminary THEN
             CASE WHEN SUBSTR(death_dt_preliminary,1,7) = SUBSTR(last_lotenddate,1,7)
                  THEN last_lotenddate ELSE death_dt_preliminary END
           ELSE fu_enddt_preliminary END"),
      fued = dbplyr::sql("CASE WHEN fu_enddt > index_date THEN fu_enddt ELSE index_date END"),
      dthdt = dbplyr::sql(
        "CASE WHEN SUBSTR(death_dt_preliminary,1,7) = SUBSTR(last_lotenddate,1,7)
              THEN CAST(LAST_DAY(death_dt_preliminary) AS DATE) ELSE death_dt_preliminary END"),
      dthfl = dbplyr::sql("CASE WHEN dthdt IS NOT NULL THEN 1 ELSE 0 END"),
      dthfufl_dur = dbplyr::sql("DATEDIFF(dthdt, fued)"),
      dthfufl = dbplyr::sql(
        "CASE WHEN dthdt IS NULL THEN 'Missing'
              WHEN dthfufl_dur <= 120 THEN 1
              WHEN dthfufl_dur > 120 THEN 0 ELSE NULL END"),
      dth_before_fued = ifelse(!is.na(dthdt) & !is.na(fued) & dthdt < fued, 1, 0)
    ) %>%
    select(patientid, index_date, last_visitdate, last_alphadate, last_provdate,
           last_televisitdate, last_lotenddate, last_oralenddate, fu_enddt_preliminary,
           f_death, dateofdeath, dateofdeath_init, dateofdeath_v1, death_dt_preliminary,
           dthdt, dthfl, fu_enddt, fued, dthfufl_dur, dthfufl, dth_before_fued)
  return(fuend_dt_tbl)
}

# --- master clinical: combine the pieces ------------------------------------
clin_char_master <- function(input_ds) {
  enh_pros_pano_var_interim_tbl   <- clin_char_enh_pros_var(input_ds)
  enh_pros_pano_ecog_interim_tbl  <- clin_char_ecog_var(input_ds)
  enh_pros_pano_vital_interim_tbl <- clin_char_vitals_var(input_ds)
  enh_pros_pano_fued_interim_tbl  <- clin_char_fuend_dthdt_var(input_ds)

  indx_tbl <- input_ds %>% select(patientid, index_date)
  clin_char_master_tbl <- indx_tbl %>%
    left_join(enh_pros_pano_var_interim_tbl,   by = c("patientid", "index_date")) %>%
    left_join(enh_pros_pano_ecog_interim_tbl,  by = c("patientid", "index_date")) %>%
    left_join(enh_pros_pano_vital_interim_tbl, by = c("patientid", "index_date")) %>%
    left_join(enh_pros_pano_fued_interim_tbl,  by = c("patientid", "index_date")) %>%
    mutate(
      pinddur = datediff(index_date, mcrpcdd),
      fudur   = datediff(fued, index_date) + 1,
      pfudur  = datediff(index_end, index_date) + 1,
      indexyr = year(index_date)
    ) %>% distinct()
  return(clin_char_master_tbl)
}

for (coh_flag in coh_list) {
  if (coh_flag == "overall") {
    var_name <- paste0("enh_pros_pano_", coh_flag, "_clin_tbl")
    input_ds <- get(paste0("enh_pros_pano_", coh_flag, "_index_tbl"))
  } else {
    var_name <- paste0("enh_pros_pano_lot", substring(coh_flag, 4), "_clin_tbl")
    input_ds <- get(paste0("enh_pros_pano_lot", substring(coh_flag, 4), "_index_tbl"))
  }
  df <- clin_char_master(input_ds)
  createInPersonalSchema(df, var_name, replace = TRUE)
  assign(var_name, df)
  rm(df)
}

# =============================================================================
# Treatment variables
# =============================================================================
trt_var_creation <- function(input_ds) {
  indx_tbl <- input_ds %>% select(patientid, index_date)

  # Max LOT and grouping
  lot_max_df <- indx_tbl %>%
    left_join(enh_pros_pano_lot, by = "patientid") %>%
    group_by(patientid, index_date) %>%
    summarise(lotn = max(new_lot_n, na.rm = TRUE), .groups = "drop") %>%
    mutate(
      lotngrl = case_when(lotn == 1 ~ '1', lotn == 2 ~ '2', lotn == 3 ~ '3',
                          lotn == 4 ~ '4', lotn >= 5 ~ '5+', TRUE ~ '0'),
      lotngrln = case_when(lotn == 1 ~ '2', lotn == 2 ~ '3', lotn == 3 ~ '4',
                           lotn == 4 ~ '5', lotn >= 5 ~ '6', TRUE ~ '1')
    ) %>%
    select(patientid, index_date, lotn, lotngrl, lotngrln)

  # Prior taxane (docetaxel/cabazitaxel) in mCRPC setting and pre-mCRPC setting
  taxane_based_df <- indx_tbl %>%
    left_join(enh_pros_pano_lot, by = "patientid") %>%
    filter(startdate <= index_date) %>%
    mutate(prior_tax_mcrpc_n = case_when(
      coh_flag == "lot1" ~ 0,
      coh_flag == "lot2" & new_lot_n == 1 &
        sql("LOWER(linename) LIKE '%docetaxel%' OR LOWER(linename) LIKE '%cabazitaxel%'") ~ 2,
      coh_flag == "lot3" & new_lot_n %in% c(1, 2) &
        sql("LOWER(linename) LIKE '%docetaxel%' OR LOWER(linename) LIKE '%cabazitaxel%'") ~ 2,
      TRUE ~ 1)) %>%
    group_by(patientid, index_date) %>%
    summarize(prior_tax_mcrpc_n = max(prior_tax_mcrpc_n, na.rm = TRUE), .groups = "drop") %>%
    mutate(prior_tax_mcrpc = case_when(
      prior_tax_mcrpc_n == 0 ~ NA_character_,
      prior_tax_mcrpc_n == 1 ~ "No",
      prior_tax_mcrpc_n == 2 ~ "Yes")) %>%
    select(patientid, index_date, prior_tax_mcrpc)

  taxane_based_pre_df <- indx_tbl %>%
    left_join(enh_pros_pano_non_mcrpc, by = "patientid") %>%
    filter(startdate <= index_date) %>%
    mutate(prior_tax_pre_mcrpc_n = case_when(
      sql("LOWER(linename) LIKE '%docetaxel%' OR LOWER(linename) LIKE '%cabazitaxel%'") ~ 2,
      TRUE ~ 1)) %>%
    group_by(patientid, index_date) %>%
    summarize(prior_tax_pre_mcrpc_n = max(prior_tax_pre_mcrpc_n, na.rm = TRUE), .groups = "drop") %>%
    mutate(prior_tax_pre_mcrpc = case_when(
      prior_tax_pre_mcrpc_n == 1 ~ "No",
      prior_tax_pre_mcrpc_n == 2 ~ "Yes")) %>%
    select(patientid, index_date, prior_tax_pre_mcrpc)

  # Per-line columns lot1..lot6 (name/dates/duration/category)
  trt_lot_df <- data.frame()
  for (i in 1:6) {
    trt_lot_interim_df <- indx_tbl %>%
      left_join(enh_pros_pano_lot %>% filter(new_lot_n == i) %>%
                  select(patientid, linenumber, new_lot_n, linename, startdate, enddate),
                by = "patientid") %>%
      left_join(enh_pros_pano_drugepisode %>%
                  left_join(enh_pros_pano_lot %>% filter(new_lot_n == i),
                            by = c("patientid", "linenumber")) %>%
                  filter(new_lot_n == i) %>%
                  group_by(patientid, linenumber, new_lot_n) %>%
                  summarise(lastdate = max(episodedate, na.rm = TRUE), .groups = "drop") %>%
                  select(patientid, linenumber, new_lot_n, lastdate),
                by = "patientid", suffix = c(".lot", ".epi")) %>%
      left_join(enh_pros_pano_drugepisode %>%
                  left_join(enh_pros_pano_lot %>% filter(new_lot_n == i),
                            by = c("patientid", "linenumber")) %>%
                  filter(new_lot_n == i, detaileddrugcategory == 'chemotherapy') %>%
                  select(patientid, linenumber, new_lot_n, detaileddrugcategory),
                by = "patientid", suffix = c(".lot2", ".epi2")) %>%
      mutate(
        lotname = if_else(!is.na(linename), linename, 'None'),
        lotsd = startdate, lotld = enddate, loted = lastdate,
        lotdur = sql("DATEDIFF(lastdate, startdate) + 1"),
        # --- 17-way line category (lotcat) ---
        lotcat = case_when(
          sql("LOWER(linename) = 'abiraterone'")  ~ "Abiraterone monotherapy",
          sql("LOWER(linename) = 'enzalutamide'") ~ "Enzalutamide monotherapy",
          sql("LOWER(linename) = 'apalutamide'")  ~ "Apalutamide monotherapy",
          sql("LOWER(linename) = 'darolutamide'") ~ "Darolutamide monotherapy",
          sql("(LOWER(linename) LIKE '%abiraterone%' OR LOWER(linename) LIKE '%enzalutamide%'
                OR LOWER(linename) LIKE '%apalutamide%' OR LOWER(linename) LIKE '%darolutamide%')
               AND (LOWER(linename) LIKE '%,%' OR LOWER(linename) LIKE '%/%')") ~ "NHA combination therapy",
          sql("LOWER(linename) = 'docetaxel'") ~ "Docetaxel monotherapy",
          sql("LOWER(linename) LIKE '%docetaxel%'
               AND (LOWER(linename) LIKE '%,%' OR LOWER(linename) LIKE '%/%')") ~ "Docetaxel combination therapy",
          sql("LOWER(linename) LIKE '%cabazitaxel%'") ~ "Cabazitaxel-containing",
          sql("LOWER(detaileddrugcategory) = 'chemotherapy'") ~ "Other chemotherapy-containing",
          sql("LOWER(linename) LIKE '%vipivotide tetraxetan%'") ~ "Pluvicto-containing",
          sql("LOWER(linename) LIKE '%radium-223%'") ~ "Radium 223-containing",
          sql("LOWER(linename) REGEXP '^(olaparib|talazoparib|niraparib|rucaparib)(,olaparib|,talazoparib|,niraparib|,rucaparib)*$'") ~ "PARPi monotherapy",
          sql("LOWER(linename) LIKE '%pembrolizumab%'") ~ "Pembrolizumab-containing",
          sql("LOWER(linename) LIKE '%sipuleucel-t%'") ~ "Sipuleucel-T-containing",
          sql("LOWER(linename) LIKE '%clinical study drug%'") ~ "Clinical study drug-containing",
          sql("linename IS NULL") ~ "No treatment",
          TRUE ~ "Any other therapy"),
        lotcatn = case_when(
          lotcat == "Abiraterone monotherapy" ~ 1, lotcat == "Enzalutamide monotherapy" ~ 2,
          lotcat == "Apalutamide monotherapy" ~ 3, lotcat == "Darolutamide monotherapy" ~ 4,
          lotcat == "NHA combination therapy" ~ 5, lotcat == "Docetaxel monotherapy" ~ 6,
          lotcat == "Docetaxel combination therapy" ~ 7, lotcat == "Cabazitaxel-containing" ~ 8,
          lotcat == "Other chemotherapy-containing" ~ 9, lotcat == "Pluvicto-containing" ~ 10,
          lotcat == "Radium 223-containing" ~ 11, lotcat == "PARPi monotherapy" ~ 12,
          lotcat == "Pembrolizumab-containing" ~ 13, lotcat == "Sipuleucel-T-containing" ~ 14,
          lotcat == "Clinical study drug-containing" ~ 15, lotcat == "Any other therapy" ~ 16,
          lotcat == "No treatment" ~ 17)
      ) %>%
      select(patientid, index_date,
             !!paste0("lot", i)       := lotname,
             !!paste0("lot", i, "sd") := lotsd,
             !!paste0("lot", i, "ed") := loted,
             !!paste0("lot", i, "ld") := lotld,
             !!paste0("lot", i, "dur") := lotdur,
             !!paste0("lot", i, "cat") := lotcat,
             !!paste0("lot", i, "catn") := lotcatn)

    if (i == 1) {
      trt_lot_df <- trt_lot_interim_df
    } else {
      trt_lot_df <- trt_lot_df %>%
        left_join(trt_lot_interim_df, by = c("patientid", "index_date"))
    }
  }

  trt_var_df <- indx_tbl %>%
    left_join(trt_lot_df,          by = c("patientid", "index_date")) %>%
    left_join(lot_max_df,          by = c("patientid", "index_date")) %>%
    left_join(taxane_based_df,     by = c("patientid", "index_date")) %>%
    left_join(taxane_based_pre_df, by = c("patientid", "index_date")) %>%
    distinct() %>%
    mutate(
      prior_tax_mcrpc = ifelse(is.na(prior_tax_mcrpc) & coh_flag != "lot1", "No", prior_tax_mcrpc),
      prior_tax_pre_mcrpc = ifelse(is.na(prior_tax_pre_mcrpc), "No", prior_tax_pre_mcrpc)
    ) %>% distinct()
  return(trt_var_df)
}

for (coh_flag in coh_list) {
  if (coh_flag == "overall") {
    var_name <- paste0("enh_pros_pano_", coh_flag, "_trt_var_tbl")
    input_ds <- get(paste0("enh_pros_pano_", coh_flag, "_index_tbl"))
  } else {
    var_name <- paste0("enh_pros_pano_lot", substring(coh_flag, 4), "_trt_var_tbl")
    input_ds <- get(paste0("enh_pros_pano_lot", substring(coh_flag, 4), "_index_tbl"))
  }
  df <- trt_var_creation(input_ds)
  createInPersonalSchema(df, var_name, replace = TRUE)
  assign(var_name, df)
  rm(df)
}

# =============================================================================
# Outcomes (OS / TTD / TTNT / discontinuation)
# =============================================================================
outcomes_tbl_var <- function(input_ds) {
  indx_tbl <- input_ds %>% select(patientid, index_date)

  if (coh_flag == "overall") {
    clin_char_tbl <- get(paste0("enh_pros_pano_", coh_flag, "_clin_tbl"))
    trt_var_tbl   <- get(paste0("enh_pros_pano_", coh_flag, "_trt_var_tbl"))
  } else {
    clin_char_tbl <- get(paste0("enh_pros_pano_lot", substring(coh_flag, 4), "_clin_tbl"))
    trt_var_tbl   <- get(paste0("enh_pros_pano_lot", substring(coh_flag, 4), "_trt_var_tbl"))
  }

  # >= ~3 months of potential follow-up
  id3mosfu_tbl <- indx_tbl %>%
    mutate(id3mosfu = if_else(datediff(index_end, index_date) >= 91, 1, 0)) %>%
    select(patientid, index_date, id3mosfu)

  # vis120: visit/telemed within 120 days of line end (per cohort)
  vis120_tbl <- indx_tbl %>%
    left_join(trt_var_tbl %>% select(patientid, index_date,
                                     lot1sd, lot2sd, lot3sd, lot4sd,
                                     lot1ed, lot2ed, lot3ed, lot4ed),
              by = c("patientid", "index_date")) %>%
    left_join(enh_pros_pano_visit   %>% select(patientid, visitdate), by = "patientid") %>%
    left_join(enh_pros_pano_telemed %>% select(patientid, visitdate),
              by = "patientid", suffix = c(".visit", ".telemed")) %>%
    filter(case_when(
      coh_flag == "overall" ~ NA,
      coh_flag == "lot1" ~ (visitdate.visit >= dbplyr::sql("DATE_ADD(lot1ed, 120)")) |
                           (visitdate.telemed >= dbplyr::sql("DATE_ADD(lot1ed, 120)")),
      coh_flag == "lot2" ~ (visitdate.visit >= dbplyr::sql("DATE_ADD(lot2ed, 120)")) |
                           (visitdate.telemed >= dbplyr::sql("DATE_ADD(lot2ed, 120)")),
      coh_flag == "lot3" ~ (visitdate.visit >= dbplyr::sql("DATE_ADD(lot3ed, 120)")) |
                           (visitdate.telemed >= dbplyr::sql("DATE_ADD(lot3ed, 120)")),
      TRUE ~ NA)) %>%
    mutate(maxvisitdate = pmax(visitdate.visit, visitdate.telemed, na.rm = TRUE)) %>%
    group_by(patientid, index_date) %>%
    summarise(lastvisitdate = max(maxvisitdate, na.rm = TRUE), .groups = "drop") %>%
    left_join(trt_var_tbl %>% select(patientid, index_date,
                                     lot1sd, lot2sd, lot3sd, lot1ed, lot2ed, lot3ed),
              by = c("patientid", "index_date")) %>%
    mutate(
      vis120 = case_when(
        coh_flag == "overall" ~ 0,
        coh_flag == "lot1" & lastvisitdate >= dbplyr::sql("DATE_ADD(lot1ed, 120)") ~ 1,
        coh_flag == "lot2" & lastvisitdate >= dbplyr::sql("DATE_ADD(lot2ed, 120)") ~ 1,
        coh_flag == "lot3" & lastvisitdate >= dbplyr::sql("DATE_ADD(lot3ed, 120)") ~ 1,
        TRUE ~ 0)) %>%
    select(patientid, index_date, lastvisitdate, vis120)

  # Treatment discontinuation / TTD / TTNT
  ttd_ttnt_tsst_df <- indx_tbl %>%
    left_join(clin_char_tbl %>% select(patientid, index_date, dthdt, dthfl, fued),
              by = c("patientid", "index_date")) %>%
    left_join(trt_var_tbl %>% select(patientid, index_date, lotn,
                                     lot1sd, lot2sd, lot3sd, lot4sd,
                                     lot1ed, lot2ed, lot3ed),
              by = c("patientid", "index_date")) %>%
    left_join(vis120_tbl,   by = c("patientid", "index_date")) %>%
    left_join(id3mosfu_tbl, by = c("patientid", "index_date")) %>%
    mutate(
      trtdis = case_when(
        coh_flag == "overall" ~ NA_integer_,
        coh_flag == "lot1" & id3mosfu == 1 & !is.na(lot1sd) ~
          case_when(lotn > 1 | (lotn == 1 & !is.na(dthdt)) | vis120 == 1 ~ 1, TRUE ~ 0),
        coh_flag == "lot2" & id3mosfu == 1 & !is.na(lot2sd) ~
          case_when(lotn > 2 | (lotn == 2 & !is.na(dthdt)) | vis120 == 1 ~ 1, TRUE ~ 0),
        coh_flag == "lot3" & id3mosfu == 1 & !is.na(lot3sd) ~
          case_when(lotn > 3 | (lotn == 3 & !is.na(dthdt)) | vis120 == 1 ~ 1, TRUE ~ 0),
        TRUE ~ NA_integer_),
      ttd = case_when(
        coh_flag == "overall" ~ NA_integer_,
        coh_flag == "lot2" & id3mosfu == 1 ~ datediff(lot2ed, index_date) / 30.4375,
        coh_flag == "lot3" & id3mosfu == 1 ~ datediff(lot3ed, index_date) / 30.4375,
        TRUE ~ NA_integer_),
      ttntfl = case_when(
        coh_flag == "overall" ~ NA_integer_,
        coh_flag == "lot1" & id3mosfu == 1 ~ case_when(lotn > 1 | dthfl == 1 ~ 1, TRUE ~ 0),
        coh_flag == "lot2" & id3mosfu == 1 ~ case_when(lotn > 2 | dthfl == 1 ~ 1, TRUE ~ 0),
        coh_flag == "lot3" & id3mosfu == 1 ~ case_when(lotn > 3 | dthfl == 1 ~ 1, TRUE ~ 0),
        TRUE ~ NA_integer_),
      ttnt = case_when(
        coh_flag == "overall" ~ NA_integer_,
        coh_flag == "lot1" & id3mosfu == 1 ~ case_when(
          ttntfl == 1 ~ (datediff(pmin(lot2sd, dthdt, na.rm = TRUE), index_date) + 1) / 30.4375,
          ttntfl == 0 ~ (datediff(fued, index_date) + 1) / 30.4375, TRUE ~ 0),
        coh_flag == "lot2" & id3mosfu == 1 ~ case_when(
          ttntfl == 1 ~ (datediff(pmin(lot3sd, dthdt, na.rm = TRUE), index_date) + 1) / 30.4375,
          ttntfl == 0 ~ (datediff(fued, index_date) + 1) / 30.4375, TRUE ~ 0),
        coh_flag == "lot3" & id3mosfu == 1 ~ case_when(
          ttntfl == 1 ~ (datediff(pmin(lot4sd, dthdt, na.rm = TRUE), index_date) + 1) / 30.4375,
          ttntfl == 0 ~ (datediff(fued, index_date) + 1) / 30.4375, TRUE ~ 0),
        TRUE ~ NA_integer_)
    ) %>%
    select(patientid, index_date, trtdis, ttd, ttntfl, ttnt) %>% distinct()

  outcomes_tbl <- indx_tbl %>%
    left_join(clin_char_tbl %>% select(patientid, index_date, dthdt, dthfl, fued),
              by = c("patientid", "index_date")) %>%
    left_join(id3mosfu_tbl, by = c("patientid", "index_date")) %>%
    left_join(vis120_tbl %>% select(patientid, index_date, lastvisitdate, vis120),
              by = c("patientid", "index_date")) %>%
    left_join(ttd_ttnt_tsst_df, by = c("patientid", "index_date")) %>%
    mutate(
      os = case_when(
        id3mosfu == 0 ~ NA,
        id3mosfu == 1 & dthfl == 1 ~ sql("(DATEDIFF(dthdt, index_date)+1)/30.4375"),
        id3mosfu == 1 & dthfl == 0 ~ sql("(DATEDIFF(fued, index_date)+1)/30.4375"),
        TRUE ~ NA),
      vis120 = case_when(is.na(vis120) ~ 0, TRUE ~ 1)
    ) %>%
    select(patientid, index_date, id3mosfu, os, vis120, lastvisitdate, trtdis, ttd, ttntfl, ttnt) %>%
    distinct()
  return(outcomes_tbl)
}

for (coh_flag in coh_list) {
  if (coh_flag == "overall") {
    var_name <- paste0("enh_pros_pano_", coh_flag, "_outcomes_var_tbl")
    input_ds <- get(paste0("enh_pros_pano_", coh_flag, "_index_tbl"))
  } else {
    var_name <- paste0("enh_pros_pano_lot", substring(coh_flag, 4), "_outcomes_var_tbl")
    input_ds <- get(paste0("enh_pros_pano_lot", substring(coh_flag, 4), "_index_tbl"))
  }
  df <- outcomes_tbl_var(input_ds)
  createInPersonalSchema(df, var_name, replace = TRUE)
  assign(var_name, df)
  rm(df)
}

# =============================================================================
# Overall analytic dataset (ADS): join all blocks, label cohorts, bind, upload
# =============================================================================
treated_patients <- enh_pros_pano_lot %>%
  mutate(treat_flag = 1) %>%
  select(patientid, treat_flag) %>%
  distinct()

overall_ads_creation <- function(coh_flag) {
  if (coh_flag == "overall") {
    index_tbl <- get(paste0("enh_pros_pano_", coh_flag, "_index_tbl")) %>%
      select(patientid, index_date)
    dem_tbl      <- get(paste0("enh_pros_pano_", coh_flag, "_dem_tbl"))
    clin_tbl     <- get(paste0("enh_pros_pano_", coh_flag, "_clin_tbl"))
    trt_tbl      <- get(paste0("enh_pros_pano_", coh_flag, "_trt_var_tbl"))
    outcomes_tbl <- get(paste0("enh_pros_pano_", coh_flag, "_outcomes_var_tbl"))
  } else {
    index_tbl <- get(paste0("enh_pros_pano_lot", substring(coh_flag, 4), "_index_tbl")) %>%
      select(patientid, index_date, new_lot_n, linename, linenumber)
    dem_tbl      <- get(paste0("enh_pros_pano_lot", substring(coh_flag, 4), "_dem_tbl"))
    clin_tbl     <- get(paste0("enh_pros_pano_lot", substring(coh_flag, 4), "_clin_tbl"))
    trt_tbl      <- get(paste0("enh_pros_pano_lot", substring(coh_flag, 4), "_trt_var_tbl"))
    outcomes_tbl <- get(paste0("enh_pros_pano_lot", substring(coh_flag, 4), "_outcomes_var_tbl"))
  }

  overall_ads_df <- index_tbl %>%
    left_join(dem_tbl,      by = c("patientid", "index_date")) %>%
    left_join(clin_tbl,     by = c("patientid", "index_date")) %>%
    left_join(trt_tbl,      by = c("patientid", "index_date")) %>%
    left_join(outcomes_tbl, by = c("patientid", "index_date")) %>%
    left_join(treated_patients, by = "patientid") %>%
    mutate(
      cohort = case_when(
        coh_flag == "overall" ~ "Overall mCRPC",
        coh_flag == "lot1" ~ "L1 + treated mCRPC",
        coh_flag == "lot2" ~ "L2 + treated mCRPC",
        coh_flag == "lot3" ~ "L3 + treated mCRPC",
        TRUE ~ "Unknown"),
      cohortu = case_when(!is.na(treat_flag) ~ "Treated mCRPC", TRUE ~ "Untreated mCRPC"),
      cohortn = case_when(
        coh_flag == "overall" ~ 1, coh_flag == "lot1" ~ 2,
        coh_flag == "lot2" ~ 3, coh_flag == "lot3" ~ 4, TRUE ~ 99),
      cohortun = case_when(!is.na(treat_flag) ~ 1, TRUE ~ 2),
      minindex = index_start,
      maxindex = index_end
    ) %>%
    rename(patid = patientid, indexdt = index_date, last_visit_date = lastvisitdate) %>%
    # drop intermediate / sensitive helper columns
    select(-c(birthyear, birthsex, ethnicity, ecogdate,
              last_visitdate, last_alphadate, last_provdate, last_televisitdate,
              last_lotenddate, last_oralenddate, fu_enddt_preliminary,
              f_death, dateofdeath, dateofdeath_init, dateofdeath_v1,
              death_dt_preliminary, fu_enddt, dthfufl_dur, treat_flag)) %>%
    distinct()
  return(overall_ads_df)
}

# Build each cohort's ADS and bind into one
for (coh_flag in coh_list) {
  if (coh_flag == "overall") {
    var_name <- paste0("enh_pros_pano_", coh_flag, "_coh_tbl")
  } else {
    var_name <- paste0("enh_pros_pano_lot", substring(coh_flag, 4), "_coh_tbl")
  }
  df <- overall_ads_creation(coh_flag)
  createInPersonalSchema(df, var_name, replace = TRUE)
  assign(var_name, df)

  if (coh_flag == "overall") {
    pros_final_ads <- get(var_name)
  } else {
    pros_final_ads <- union_all(pros_final_ads, get(var_name))
  }
  rm(df)
}

# Upload the combined ADS to the personal schema
createInPersonalSchema(pros_final_ads, "rwdp_pros_pano_v1", replace = TRUE)
