# Repository guide - what each file is and how to run it

202606 prostate PANO real-world data product. Two documents describe this
repository and nothing else does:

- **this file** - what every file is, and the order to run them in;
- **`VARIABLES.md`** - the data. All 190 delivered columns tabulated in
  specification-sheet order with the derivation as the code performs it and the
  block of code that performs it, the intermediate values the build creates on
  the way, and all 84 assumptions with their approvals. Written to be read
  beside the specification by someone checking that each row was interpreted
  correctly and implemented correctly. It names the build modules and nothing
  else - no check programs.

`SPEC.csv` sits beside them and is not documentation: it is the corrected
specification the build implements, one row per delivered column, and the
offline check parses it. Treat it as a contract, not prose.

---

## 1. What runs where

Everything runs **inside Databricks**, over an ODBC connection from an R
session. No program pulls data into the R session: every query is pushed down
and every result is written back as a table in your personal schema. That is
deliberate - the volumes involved do not fit in a client session, and a result
that never leaves the platform cannot drift from what the platform holds.

| | Value |
|---|---|
| Catalog | `hive_metastore` |
| Source schema | `clnprw_flatiron_pano_pros_use` |
| Refresh | `2026m06` |
| Delivered table | `rwdp_pros_pano_2026m06` |
| Your schema | wherever the build writes - the 43 stage tables and the ADS |

## 2. Two copies of this repository

The production copy holds `docs/` and `code/` only. The build repository holds
all of it.

| | Production copy | Build repository |
|---|---|---|
| Holds | `docs/`, `code/` | everything, including `validation/` and `qc/` |
| Can | run the build | run the build, and check what it produced |
| Cannot | check anything | - |

**The build never reads `validation/` or `qc/`.** The cohort code only creates;
every check lives outside it. The one contract the build keeps for itself is the
190-column allowlist in `code/modules/06_assemble.R`, because selecting against
it is part of writing the table. So the production copy will build correctly, and
it will not tell you whether the source was fit to build from or whether the
result is right.

## 3. `code/` - the build

Sourced in numbered order by the driver. No module runs on its own.

| File | What it does |
|---|---|
| `prostate_rdap_202606.R` | The driver. Sources the modules in order, writes 43 stage tables, the ADS and `RUN_MANIFEST.txt`. |
| `modules/00_setup.R` | Connection, parameters, source-table handles, the frozen gene panels, and the program version with its changelog. |
| `modules/01_studypop.R` | Patient-level death date and follow-up end date, then one index table per cohort, with the per-cohort death exclusion. |
| `modules/02_demographics.R` | 5A.Demos - age, race, ethnicity, region, practice type. |
| `modules/03_clinical.R` | 5B.ClinChars - stage, Gleason, PSA, labs, vitals, ECOG, metastatic sites, and the follow-up join. The largest module. |
| `modules/04_treatment.R` | 5C.TreatVars - lines of therapy, drug classes, prior therapy flags. |
| `modules/05_outcomes.R` | 6.Outcomes - OS, TTNT, rwPFS and their event flags. |
| `modules/06_assemble.R` | Selects the 190 contracted columns in order, writes the ADS, stamps the run. |

## 4. `validation/` - gates that must pass

| File | What it does |
|---|---|
| `00_connect.R` | Connection-only bootstrap for the check programs. Sourced, not run. |
| `00_build_identity.R` | Shared helper: which code produced a given piece of evidence. |
| `01_preflight.R` / `01_preflight_databricks.sql` | **Source gates, before every build.** Thirteen B-gates on the source tables plus the input contract and the lab-unit checks. `B18` must read zero - a nonzero count is unparseable death dates escaping the cohort exclusion. |
| `02_offline_build_check.R` | **The only program that needs no database.** Renders every stage table and the ADS, then cross-checks the generated SQL, the column contract, `SPEC.csv`, the variable tables in `VARIABLES.md` section 5 and the register against each other. |
| `03_output_validation.R` / `03_output_validation_databricks.sql` | The V-gates, against the delivered table. Any `FAIL` is a build defect. |
| `03b_null_sweep.R` / `03b_null_sweep.sql` | All-null and constant-value sweep. **Fail-closed on `FAIL` and on `REVIEW`.** |
| `04_column_contract_check.R` | The 190 columns, exact names and exact order. Prints a verdict and exits. |
| `04_open_questions.R` / `04_open_question_queries.sql` | Queries that close register rows without a judgement call. |
| `05_sizing.R` / `05_sizing_queries.sql` | Sizing counts `S1`-`S7` for register rows that need a number before they can be ruled on. |
| `06_register_counts.R` | Register-closing counts, including the Q66 death-parse oracle. |
| `10_source_question_pack.sql` | Source-only pack: everything answerable without a rebuild, in one runnable file. |
| `11_q83_decision_pack.sql` | Runs after the rebuild. Characterises the follow-up-before-index population that gate `V46` counts, so Q83 can be ruled on a description rather than a single number: size in patients as well as rows, per cohort, how far before the index the gap runs, and which of `OS`, `TTNT`, `PFS`, `ID3MOSFU` and `ELIGPFS` it carries with it. Read-only; five assertions establish the population is the one the pack claims. |
| `12_q83_why_no_activity.sql` | Runs after `11`. Asks whether Q83 is a problem about these patients or about the definition: recomputes `FU_ENDDT_preliminary` from the four sources the spec names to prove the delivered value is not a bug, then looks for records in sources the definition does not read - labs, PSA, vitals, ECOG, medication administrations, PSMA PET, and the two tables register Q40 dropped. Reads the delivered table and the source schema together. Read-only. |
| `00a_pre_q82_snapshot_TAKE.sql` | **Runs once, before the rebuild.** Captures the pre-ruling table as `pre_q82_ads` with its metadata. Eleven assertions. Uses `CREATE TABLE`, so it fails rather than overwrites. |
| `00a_recover_metadata.sql` | Run only if `00a` stopped at A2b. Rebuilds the snapshot's metadata row and runs the two checks that never ran, through the runner so the assertions still bind. Drops the metadata table only - never the snapshot. |
| `00b_pre_q82_snapshot_COMPARE.sql` | Runs after the rebuild. Before/after comparison of membership, `DTHFUFL`, the death-derived outcomes and the `CSF_FU` window. Read-only. |
| `run_sql.R` | Runs a `.sql` file over the build's own connection, and **enforces its `-- @assert` directives**. Pasted into an editor those directives are inert comments, so the assertions only bind through this. |
| `read_deviations.R` | Parser for the register in `VARIABLES.md`. Sourced by the offline check and the traceability backfill. |
| `materialize_checks.R` | Materializes the `.sql` checks as tables. |
| `make_null_sweep.R`, `make_traceability.R` | Generators - see section 6. |

### Not programs

| File | What it is |
|---|---|
| `00_column_contract.csv` | The 190 delivered columns, names and order. |
| `00_input_contract.csv` | The source tables and columns the build reads: 21 tables, 98 columns. |
| `evidence_2026-09-12_source_pack.txt` | Transcribed results of the source-only pack, pinned to the commit and blob that produced them. |
| `evidence_hrr_panel_counts.txt`, `evidence_biomarker_gene_counts.txt` | Gene and panel counts behind the frozen inventory. |
| `generated_sql/`, `generated_sql.md5` | Rendered stage SQL and its manifest. A diff in the manifest means the delivered SQL moved. |

## 5. `qc/` - checks that produce a number somebody reads

The V-gates fail the run. Most of `qc/` does not: it writes a table and a person
decides. Both mirrors exist for every check that has one - the `.R` runs it, the
`.sql` is the same check for someone holding only the extract.

| File | What it does |
|---|---|
| `00_coverage.R` | **Decision coverage.** Every register row that affects an output must be named by a check and carry an approver. Reads the register in `VARIABLES.md`. |
| `01_variable_profile.R` / `.sql` | Per-cohort null rate and cardinality, all 190 columns. |
| `02_code_label_agreement.R` / `.sql` | Every code/label pair, both directions. |
| `03_cross_variable_rules.R` / `.sql` | 70 cross-variable rules, `R01`-`R64`. `GATE` rows must read zero; `REVIEW` rows are counts to read. |
| `04_cohort_attrition.R` / `.sql` | The attrition waterfall, including the death-exclusion step. |
| `05_independent_rederivation.R` | **Rebuilds 39 values from source** and compares them with the delivered table, so the build cannot agree with itself and be wrong. |
| `06_golden_patients.R` / `.sql` | Ten golden patients, `P1`-`P10`, traced end to end for a human to read. |
| `07_type_contract.R` | Column types and nullability. **Two passes:** the first captures `qc_column_types.csv` and exits nonzero by design; review it, commit it, then the second checks against it. |
| `08_death_date_formats.R` / `.sql` | The death-date shapes the specification documents, and the cost of the ones it does not. |
| `09_vitals_domain.R` / `.sql` | Vitals value domains - non-integer blood pressure, zero or negative height and weight. |
| `make_qc_sql.R` | Generator - see section 6. |

## 6. Generated files - do not edit by hand

| Generated file | By | From |
|---|---|---|
| `validation/03b_null_sweep.sql` | `validation/make_null_sweep.R` | the column contract |
| `qc/01_variable_profile.sql`, `qc/02_code_label_agreement.sql` | `qc/make_qc_sql.R` | the column contract and `SPEC.csv` |
| `validation/generated_sql/*`, `generated_sql.md5` | `validation/02_offline_build_check.R` | the build modules |
| the register's `Commit` column | `validation/make_traceability.R` | git history |
| `VARIABLES.md` section 5's `Built in` column | scan of the module blocks | `code/modules/*.R` section headers |
| `qc/qc00_coverage.csv` | `qc/00_coverage.R` | the register and the checks |

## 7. How to run it, in order

**Take the snapshot first.** The build writes with `replace = TRUE` and keeps no
staging copy, so the pre-ruling table disappears the moment the rebuild starts,
and the before/after figures it carries become unmeasurable for this cut
permanently. This is the one step in this repository that cannot be repeated.

```
# 0. offline, no database
Rscript validation/02_offline_build_check.R
Rscript qc/00_coverage.R

# 1. once, before anything else - fill its three FILL IN literals first
Rscript validation/run_sql.R validation/00a_pre_q82_snapshot_TAKE.sql

# 2. source gates. B18 must read zero
Rscript validation/01_preflight.R

# 3. the build
Rscript code/prostate_rdap_202606.R

# 4. record the build identity BY HAND
#    commit, refresh, panel, run timestamp, operator. Nothing in the
#    delivered table records it, so this note is its only provenance.

# 5. the checks
Rscript validation/03_output_validation.R      # the V-gates
Rscript validation/03b_null_sweep.R            # nonzero exit on FAIL *or* REVIEW
Rscript validation/04_column_contract_check.R
Rscript qc/01_variable_profile.R
Rscript qc/02_code_label_agreement.R
Rscript qc/03_cross_variable_rules.R
Rscript qc/04_cohort_attrition.R
Rscript qc/05_independent_rederivation.R
Rscript qc/06_golden_patients.R
Rscript qc/08_death_date_formats.R
Rscript qc/09_vitals_domain.R
Rscript validation/05_sizing.R
Rscript validation/04_open_questions.R
Rscript validation/06_register_counts.R
Rscript qc/07_type_contract.R                  # pass 1 exits nonzero by design

# 6. after the rebuild - the before/after comparison
Rscript validation/run_sql.R validation/00b_pre_q82_snapshot_COMPARE.sql

# 7. if V46 reported a nonzero count - the description Q83 needs to be ruled,
#    then why those patients have no activity. Run both before ruling.
Rscript validation/run_sql.R validation/11_q83_decision_pack.sql
Rscript validation/run_sql.R validation/12_q83_why_no_activity.sql
```

Run `00a` and `00b` **through `run_sql.R`**, not in the SQL editor. Their
`-- @assert` directives are what make the capture and the comparison bind; in an
editor they are comments and a wrong result passes silently.

**Run the checks before reading any `qcr_*` table.** Every check program writes
with `replace = TRUE`, so a table from an earlier run sits under the same name as
a fresh one. Each writes a `qcr_stamp_*` table carrying the checker's commit,
dirty flag, refresh and panel - which tells you what CHECKED the table, not what
BUILT it.

## 8. What a green run does and does not prove

- **A zero exit is not a pass for most of these.** Of the fifteen check
  programs, five halt on failure, three write a verdict you have to read, and
  seven are descriptive output that nothing can mark pass or fail.
- **`qc/00_coverage.R` exits nonzero today, and that is correct.** Since
  2026-09-13 it refuses to certify a decision whose approver is a placeholder
  rather than a person, or whose register status is still `OPEN`. Two rows are
  in that state - the follow-up disposition and the albumin values - so the
  gate fails and the offline check fails with it. Both pass again when those
  two are ruled and signed, and not before.
- **`03_output_validation.R`'s `PASS` does not cover its three `REVIEW` rows.**
  `V26`, `V46` and `V46c` are assigned `REVIEW` when they fire, and the verdict
  query that decides the exit status excludes exactly that status, so all three
  could report large counts and the program would still print
  `PASS - no gate failing`. That is deliberate: the cohort counts and the two
  Q83 populations need a person, not a threshold. It also means the printed
  verdict is not the result - read `qcr_vgates_r` and `qcr_v26_cohorts_r`. A
  row reading zero is assigned `PASS` and drops out of a `REVIEW` filter, so
  seeing fewer than three rows there is the good outcome, not a missing check.
- **The offline check proves internal consistency, not correctness.** It renders
  the SQL deterministically and confirms the documents agree with each other and
  with the contract. It says nothing about the delivered data.
- **Coverage proves a decision is *named* by a check, not that the check is
  right.** Four checks once passed coverage while testing the wrong thing.
- **`SPEC.csv` is checked for shape, not for truth.** The harness confirms it
  carries the 190 columns in order with a definition each. It cannot confirm a
  definition still matches the code, and that drifted once already. Change a
  derivation and its `SPEC.csv` row in the same commit.
- **The delivered table carries no provenance.** It records nothing about which
  build produced it, a re-run overwrites the table the checks reviewed, and it is
  live the moment the build finishes. Recorded as an accepted risk for this cut;
  the hand-written note from step 4 is the only thing that ties results to a run.
