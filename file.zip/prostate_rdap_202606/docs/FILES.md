# Files — what each one is, and the order to run them

202606 prostate real-world data product. Two documents describe this package:

- **this file** — every file and what it does;
- **`VARIABLES.md`** — the data. All 190 delivered columns in specification order with the
  derivation as the code performs it, and the intermediate values it creates on the way.

`SPEC.csv` sits beside them and is not documentation: it is the corrected specification the build
implements, one row per delivered column, read by `validation/02_offline_build_check.R`.

## Where it runs

**Site dependency.** `code/modules/00_setup.R`, `validation/00_connect.R` and
`validation/04_column_contract_check.R` each source three helper scripts by absolute path under
`/mnt/code/intake/oncology/prostrate/202606/`. Those files are not in this repository and the paths
are not configurable, so every program that opens a connection runs only where that tree is
mounted. `validation/02_offline_build_check.R` sources none of them and touches no database, which
is why it is the only program that runs anywhere.

Everything else runs inside Databricks over an ODBC connection from an R session. Queries are pushed
down and results are written back as tables in your personal schema. Two deliberate exceptions:
`qc/05_independent_rederivation.R` reads its comparison rows back with `DBI::dbGetQuery`, because
it is a hand-written second opinion that uses none of the build's machinery, and it keeps a CSV
rather than a `qcr_*` table; and the fail-closed checks fetch their own one-row verdict so they
can exit nonzero. Nothing else comes back.

| | Value |
|---|---|
| Catalog | `hive_metastore` |
| Source schema | `clnprw_flatiron_pano_pros_use` |
| Refresh | `2026m06` |
| Delivered table | `rwdp_pros_pano_2026m06` |

## `code/` — the build

Sourced in numbered order by the driver. No module runs on its own.

| File | What it does |
|---|---|
| `prostate_rdap_202606.R` | The driver. Sources the modules in order, writes 43 stage tables, the delivered table and `RUN_MANIFEST.txt`. |
| `modules/00_setup.R` | Connection, parameters, source-table handles, the frozen gene panels, and the program version with its changelog. |
| `modules/01_studypop.R` | Patient-level death date and follow-up end date, then one index table per cohort, with the per-cohort death exclusion. |
| `modules/02_demographics.R` | 5A.Demos — age, race, ethnicity, region, practice type. |
| `modules/03_clinical.R` | 5B.ClinChars — stage, Gleason, PSA, labs, vitals, ECOG, metastatic sites, and the follow-up join. The largest module. |
| `modules/04_treatment.R` | 5C.TreatVars — lines of therapy, drug classes, prior therapy flags. |
| `modules/05_outcomes.R` | 6.Outcomes — OS, TTNT, rwPFS and their event flags. |
| `modules/06_assemble.R` | Selects the 190 contracted columns in order, writes the delivered table, stamps the run. |

## `validation/` — gates that must pass

| File | What it does |
|---|---|
| `00_connect.R` | Connection-only bootstrap for the check programs. Sourced, not run. |
| `00_build_identity.R` | Shared helper: stamps each QC result with the `program_version` read from `code/modules/00_setup.R`, plus the refresh and HRR panel, so two runs of different code cannot look identical. |
| `00_render_names.R` | Shared helper: how `RENDER_ONLY` is read and what the `${...}` placeholders fall back to, including the HRR panel suffix. Sourced by both `.sql` runners so the two cannot drift. |
| `01_preflight.R` / `01_preflight_databricks.sql` | **Source gates, before every build.** Fifteen gates on the source tables plus the input contract and the lab-unit checks. `B18` must read zero — a nonzero count is unparseable death dates escaping the cohort exclusion. **The two are not equivalent:** every mandatory gate is in both, but `B7`–`B11` — the castability warnings for gene, ECOG and BP values, and the PSMA/ECOG duplicate reports — exist only in the `.sql`. Run the `.sql` too if you want the full source picture; the `.R` alone gates the build but does not describe it. |
| `02_offline_build_check.R` | **The only program that needs no database.** Renders every stage table and the delivered table, then cross-checks the generated SQL, the column contract, `SPEC.csv`, and the variable tables in `VARIABLES.md` against each other. |
| `03_output_validation.R` / `03_output_validation_databricks.sql` | The V-gates, against the delivered table. Any `FAIL` is a build defect and stops the run — including `V26`, the cohort counts against the accepted figures. Two rows stay advisory, `V46` and `V46c`, because the population they size is unruled; the printed verdict excludes those, so read `qcr_vgates_r`. |
| `03b_null_sweep.R` / `03b_null_sweep.sql` | All-null and constant-value sweep. Fail-closed on `FAIL` and on `REVIEW`. |
| `04_column_contract_check.R` | The 190 columns, exact names and exact order. Prints a verdict and exits. |
| `04_open_questions.R` / `04_open_question_queries.sql` | Queries that answer a documented question without needing a judgement call. |
| `05_sizing.R` / `05_sizing_queries.sql` | Sizing counts `S1`–`S7` for the decisions that need a number before they can be settled. |
| `06_closing_counts.R` | Closing counts for the open decisions, including the death-parse oracle. |
| `10_source_question_pack.sql` | Source-only pack: everything answerable without a rebuild, in one runnable file. |
| `00a_pre_ruling_snapshot_TAKE.sql` | **Runs once, before a rebuild.** Captures the pre-ruling table with its metadata. Uses `CREATE TABLE`, so it fails rather than overwrites. |
| `00a_recover_metadata.sql` | Run only if `00a` stopped at its metadata check. Rebuilds the metadata row and runs the two checks that never ran. Drops the metadata table only — never the snapshot. |
| `00b_pre_ruling_snapshot_COMPARE.sql` | Runs after the rebuild. Before/after comparison of membership, the death-derived outcomes and the follow-up window. Read-only. |
| `run_sql.R` | Runs a `.sql` file over the build's own connection and **enforces its `-- @assert` directives**. Pasted into an editor those directives are inert comments, so the assertions only bind through this. |
| `materialize_checks.R` | Materializes the `.sql` checks as tables, for when the driver cannot fetch a result. **It does not enforce `-- @assert` directives and cannot** — an assertion is evaluated by reading the result, which is what this file exists to avoid. It prints every directive it passes over and lists them all again at the end, so a clean finish here is not a pass. Use `run_sql.R` when you want the checks to bind. |
| `make_null_sweep.R` | Generator — see **Generated files** below. |
| `00_column_contract.csv` | The 190 delivered columns, names and order. Not a program. |
| `00_input_contract.csv` | The source tables and columns the build reads: 21 tables, 98 columns. Not a program. |

## `qc/` — checks that produce a number somebody reads

The V-gates fail the run. Most of `qc/` does not: it writes a table and a person decides.

Most checks come as a pair — the `.R` runs it over the build's connection, the `.sql` is there for
someone holding only the extract. `05_independent_rederivation.R` and `07_type_contract.R` have no
`.sql`. **The pairs are maintained by hand and nothing tests that they agree.** They have drifted
before: one side has carried a fail-closed exit the other lacked, and a membership check the other
did not perform. Treat a disagreement between a pair as a finding about the pair, and change both
sides together.

| File | What it does |
|---|---|
| `01_variable_profile.R` / `.sql` | Per-cohort null rate and cardinality, all 190 columns. |
| `02_code_label_agreement.R` / `.sql` | Every code/label pair, both directions. |
| `03_cross_variable_rules.R` / `.sql` | 70 cross-variable rules. `GATE` rows must read zero; `REVIEW` rows are counts to read. |
| `04_cohort_attrition.R` / `.sql` | The attrition waterfall, including the death-exclusion step, rebuilt from source. **Fail-closed:** exits nonzero if any cohort differs from the rebuild or if the gate does not carry all seven. Compares membership, not just counts — two anti-joins catch a build that swapped one patient for another while keeping the totals intact. |
| `05_independent_rederivation.R` | **Rebuilds 39 values from source** and compares them with the delivered table, so the build cannot agree with itself and be wrong. The only source-anchored proof of the death-date rules. Deliberately excludes OS, PFS and TTNT: a second hand-written version of either would disagree for reasons that are bugs in the copy. Writes a CSV, not a `qcr_*` table; keep that CSV with the release. |
| `06_golden_patients.R` / `.sql` | Ten golden patients traced end to end for a human to read. Descriptive, not assertive — it carries no expected values, so it cannot fail; it shows you rows and you judge them. |
| `07_type_contract.R` | Column types and nullability. **Two passes:** the first captures `qc_column_types.csv` and exits nonzero by design; review it, keep it, then the second checks against it. **No baseline ships** — `qc_column_types.csv` is not included, so the first run here is always a capture and there is nothing yet for a type change to fail against. Keep the reviewed file beside the code to make it a contract. |
| `08_death_date_formats.R` / `.sql` | The death-date shapes the specification documents, and the cost of the ones it does not. |
| `09_vitals_domain.R` / `.sql` | Vitals value domains — non-integer blood pressure, zero or negative height and weight. |
| `make_qc_sql.R` | Generator — see below. |

## Generated files — do not edit by hand

| Generated | By | From |
|---|---|---|
| `validation/03b_null_sweep.sql` | `validation/make_null_sweep.R` | the column contract |
| `qc/01_variable_profile.sql`, `qc/02_code_label_agreement.sql` | `qc/make_qc_sql.R` | the column contract |
| `validation/generated_sql/`, `generated_sql.md5` | `validation/02_offline_build_check.R` | the build modules |

The first two DO ship, so a reader holding only the extract can run them; both are
rewritten by their generator and the offline check fails if either has drifted from the column
contract. The rendered stage SQL and its manifest are NOT included, and are written on the first
run. The SQL
manifest has no prior version to compare against here, so the first offline check establishes the
baseline rather than detecting drift from it.

## How to run it, in order

**Take the snapshot first.** The build writes with `replace = TRUE` and keeps no staging copy, so the
pre-existing table disappears the moment a rebuild starts. This is the one step that cannot be
repeated.

```
# 0. offline, no database
Rscript validation/02_offline_build_check.R

# 1. once, before anything else - fill its three literals first
Rscript validation/run_sql.R validation/00a_pre_ruling_snapshot_TAKE.sql

# 2. source gates. B18 must read zero
Rscript validation/01_preflight.R

# 3. the build
Rscript code/prostate_rdap_202606.R

# 4. record the build identity BY HAND
#    program_version, refresh, panel, run timestamp, operator. Nothing in the
#    delivered table records it, so this note is its only provenance. Keep
#    RUN_MANIFEST.txt - the next build overwrites it in place.

# 5. the checks
Rscript validation/03_output_validation.R
Rscript validation/03b_null_sweep.R
Rscript validation/04_column_contract_check.R
Rscript qc/01_variable_profile.R
Rscript qc/02_code_label_agreement.R
Rscript qc/03_cross_variable_rules.R
Rscript qc/04_cohort_attrition.R
Rscript qc/05_independent_rederivation.R
Rscript qc/06_golden_patients.R
Rscript qc/08_death_date_formats.R
Rscript qc/09_vitals_domain.R
Rscript validation/05_sizing.R
Rscript validation/04_open_questions.R
Rscript validation/06_closing_counts.R
Rscript qc/07_type_contract.R                  # pass 1 exits nonzero by design

# 6. after the rebuild - the before/after comparison
Rscript validation/run_sql.R validation/00b_pre_ruling_snapshot_COMPARE.sql
```

Run the `.sql` files **through `run_sql.R`**, not in a SQL editor. Their `-- @assert` directives are
what make them bind; in an editor they are comments and a wrong result passes silently.

**Run the checks before reading any `qcr_*` table.** Every check program writes with
`replace = TRUE`, so a table from an earlier run sits under the same name as a fresh one.

## What a green run does and does not prove

- **A zero exit is not a pass for most of these.** Of the check programs, five halt on failure,
  three write a verdict you have to read, and the rest are descriptive output that nothing can mark
  pass or fail.
- **`03_output_validation.R`'s `PASS` excludes its `REVIEW` rows** by design — the cohort counts and
  the two follow-up populations need a person, not a threshold. The printed verdict is not the
  result; read the tables.
- **The offline check proves internal consistency, not correctness.** It confirms the documents agree
  with each other and with the contract. It says nothing about the delivered data.
- **Nothing here is a fixture test.** Every check reads the live source or the delivered table, so
  each one proves a statement about *this* data. None of them proves the code handles a malformed
  cast, a duplicate mortality row, a tie or an out-of-order event, because no such row is
  constructed anywhere in the package. A green run on clean data says nothing about dirty data.
- **`SPEC.csv` is checked for shape, not for truth.** Change a derivation and its `SPEC.csv` row
  together.
- **The `.R` and `.sql` mirrors are not proven equivalent.** No check compares them; they agree
  only as far as they have been kept in step by hand.
- **No type contract is in force.** `qc/07` ships no baseline, so a column that changed type would
  pass every check in this package until its first pass is run and the file kept.
- **Nothing enforces the run order.** The driver does not invoke preflight, check that it ran, or
  read its result, and the build publishes directly onto the live table. A direct call to
  `code/prostate_rdap_202606.R` therefore replaces the deliverable with output no gate has seen.
  The sequence below is a runbook, not a mechanism.
- **The delivered table carries no provenance.** A re-run overwrites the table the checks reviewed,
  and it is live the moment the build finishes. The hand-written note from step 4 is the only thing
  tying results to a run.
