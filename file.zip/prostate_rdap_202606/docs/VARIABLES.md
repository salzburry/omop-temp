# Variables - what each one is, how the build derives it, and what we assumed

For anyone checking this data product against the program specification. It is
written to be read **beside the specification**, sheet by sheet and row by row,
so you can answer two separate questions for every variable:

1. **Was the specification read correctly?** Where a spec row was ambiguous,
   silent or self-contradictory, somebody made a choice. Section 8 records all
   84 of them, what the spec said, what was chosen, and who approved it.
2. **Was that reading implemented?** Section 5 lists all 190 delivered columns
   in specification order with the derivation as the code performs it and the
   block of code that performs it, so you can go from a spec row to the lines
   that implement it without reading the whole build.

You have three things: the build code under `code/`, this file, and
`REPO_GUIDE.md`, which says what every file in the repository is. `SPEC.csv`
sits beside this file as the same 190 rows in machine-readable form.

**Two cautions before you read a number out of the table.** Every delivered
figure quoted here predates the study-team ruling of 2026-09-11, because the
table was last built on 2026-08-08 and that ruling changed the death date, the
follow-up end date and cohort membership - section 7. And a decision recorded in
section 8 is a decision, not a measurement: it says what the build was told to
do, not that it does it.

---

## 1. How to check this against the specification

Work one sheet at a time. For each spec row:

| Step | Where to look |
|---|---|
| Find the variable | Section 5, grouped by spec sheet, in spec order. Names are upper-case as delivered; the code uses lower-case. |
| Compare the definition | The **Definition as implemented** column. Where it differs from the spec text, the **Judgement** column names the register row that decided it. |
| Read the decision | Section 8, the `Qnn` row named in **Judgement**. It carries what the spec said, what we do, why, and who approved it. |
| Find the code | The **Built in** column names the module and the block inside it. Section 4 maps blocks to spec row ranges. |
| Check the window | Variables with a time period carry it in italics after the name - `[PRE_INT]`, `[FU]`, `[INDEX]`. Section 3 defines each. |

Two things that are easy to miss:

- **A variable can be delivered and still be interim.** The spec keeps several
  working dates in the output. Section 6 lists every intermediate the build
  creates and says which are delivered and which only feed something else.
- **`TTNTFL` is derived and NOT delivered.** The spec strikes it out, but its
  active definition still reads it, so the build computes it internally and the
  190-column contract excludes it (register Q02).

The `Label`, `Permitted values` and `Definition as implemented` columns in
section 5 carry the same text as `SPEC.csv`, and the two are checked against
each other before a release: a variable in one and not the other, or a row
numbered with the wrong delivered position, fails that check. The `#` column is
the column's position in the delivered table, so the tables can be grouped by
specification sheet without losing the delivered order.

## 2. The shape of the delivered table

One row per patient per cohort. A patient who qualifies for several cohorts has
several rows, and everything time-anchored in each row is anchored on **that
cohort's** index date.

| | |
|---|---|
| Grain | patient x cohort |
| Cohorts | seven, numbered 1-7 |
| Columns | 190, in the order `SPEC.csv` gives |
| Key | `PATID`, `COHORTN` |

The seven cohorts, with what fixes the index date for each:

| # | Cohort | Setting | Index date |
|---|---|---|---|
| 1 | Overall mHSPC | mHSPC | `MHSPCDD`, the milestone date |
| 2 | Overall mCRPC | mCRPC | `MCRPCDD`, the milestone date |
| 3 | L1+ treated mHSPC | mHSPC | start date of the line with `NEW_LOT_N` = 1 |
| 4 | L1+ treated mCRPC | mCRPC | start date of the line with `NEW_LOT_N` = 1 |
| 5 | L2+ treated mCRPC | mCRPC | start date of the line with `NEW_LOT_N` = 2 |
| 6 | L3+ treated mCRPC | mCRPC | start date of the line with `NEW_LOT_N` = 3 |
| 7 | L4+ treated mCRPC | mCRPC | start date of the line with `NEW_LOT_N` = 4 |

**Inclusion.** The setting's milestone date must fall within `[MININDEX,
MAXINDEX]`, both bounds inclusive. For cohorts 3-7 the line start date must fall
in that window as well.

**Exclusion.** A patient whose index date for a cohort falls **after** their
death date is excluded from that cohort - **per cohort, not per patient**. The
same patient can hold their place in an early cohort and be dropped from a later
one whose line started after they died. See section 3.

## 3. Time windows and conventions

Every window is relative to the row's own index date. Nothing is anchored on a
calendar date.

| Window | Span |
|---|---|
| `PRE_INT` baseline | earliest available data through `INDEXDT`, inclusive |
| `INDEX` | `INDEXDT` itself |
| `FU` follow-up | after `INDEXDT` through `FUED`, inclusive |
| `LOT_ECOG` | `INDEXDT - 30` through `INDEXDT + 7` |
| `BIOMARKER` | `INDEXDT - 30` through `INDEXDT + 7` |
| `PSA_INDEX` | `INDEXDT - 14` through `INDEXDT` |

Two conventions apply throughout. **A derived date from two candidates** takes
the later of the two, uses whichever is present if one is missing, and never
imputes a missing date. **A coded variable with no documented residual level**
falls to `99`; where the permitted values name a residual, that one is used
instead.

Text comparison is **not** uniformly case-insensitive. `LINESETTING`,
`GLEASONSCORE` and `LABCOMPONENT` are compared literally, so a variant spelling
falls to the residual category or drops the row - which is why source gates
`B13`-`B16` exist to prove no variant spelling is present in the source.

## 4. Where each part of the table is built

The driver `code/prostate_rdap_202606.R` sources the modules in numbered order,
once per cohort, and writes 43 stage tables before selecting the 190 delivered
columns. Where a block header names spec rows, those are the rows it implements.

| Module | Block | Spec rows |
|---|---|---|
| `00_setup.R` | parameters, source-table handles, the frozen gene panels, and the shared helpers: `lot_tbl()` line numbering, `closest_value()`, `earliest_value()` | 3.Data Prep B and C |
| `01_studypop.R` | patient-level death date and follow-up end date | 5B.ClinChars 88-93 |
| `01_studypop.R` | `index_lot_cohort()` - one index table per cohort, with the death exclusion | 4.StudyPop B |
| `02_demographics.R` | `demographics_variable_addn()` | 5A.Demos |
| `03_clinical.R` | milestone dates, stage, Gleason, diagnosis PSA | 2-16, 62, 65-67 |
| `03_clinical.R` | baseline laboratory values - ten analytes, three columns each | 17-46 |
| `03_clinical.R` | baseline ECOG | 47-48 |
| `03_clinical.R` | blood pressure | 49-53 |
| `03_clinical.R` | concomitant medication flags | 54-56 |
| `03_clinical.R` | vitals: weight, height, BMI, BSA | 57-64 |
| `03_clinical.R` | PSA at the mCRPC milestone and at index | 68-69 |
| `03_clinical.R` | biomarker status at index - HRR, the olaparib label panel, BRCA | 70-77 |
| `03_clinical.R` | PSMA PET scan | 78-79 |
| `03_clinical.R` | sites of metastasis | 80-87 |
| `03_clinical.R` | follow-up end date and death date - joins the patient-level table | 88-93, 97 |
| `03_clinical.R` | `clin_char_master()` - combines the blocks, computes `FUDUR` and `INDEXYR` | 5B.ClinChars |
| `04_treatment.R` | `trt_lot_block()` per setting, `trt_prior_flags()`, `trt_var_creation()` | 5C.TreatVars |
| `05_outcomes.R` | `outcomes_tbl_var()` - OS, TTNT, rwPFS and their event flags | 6.Outcomes |
| `06_assemble.R` | `overall_ads_creation()` - the 190-column allowlist, the rename to delivered names, the write | - |

Three helpers in `00_setup.R` carry logic worth reading before any variable
that uses them:

- **`lot_tbl(setting)`** numbers lines within a patient and a setting by start
  date, producing `NEW_LOT_N`. Cohort membership for cohorts 3-7 and every
  `LOT*` variable depend on it.
- **`closest_value(src, lo, hi, out_value, out_date, agg)`** takes the record
  closest to an anchor date inside a window, breaking a same-day tie with the
  named aggregate. Labs, ECOG, blood pressure, vitals and biomarkers all use it,
  and the tie rule differs by variable.
- **`earliest_value(src, lo, hi, out_value)`** takes the earliest record in the
  window instead, with the maximum on that day. Only the two PSA variables use
  it, which is the spec's own asymmetry.

## 5. The delivered columns, by specification sheet

All 190 columns, grouped by specification sheet so you can work one sheet at a
time, and within a sheet in the order the spec gives them. The **#** column is
the column's position in the delivered table, which interleaves the sheets - so
`DATAV` is spec sheet 3 but delivered 187th.

A dash in **Judgement** means the spec was followed with no choice to make. A
`Qnn` means a choice was made: section 8 has what the spec said, what was
chosen, why, and who approved it.

### 5.1 3.Data Prep - Data preparation  (6 columns)

| # | Variable | Label | Permitted values | Definition as implemented | Built in | Judgement |
|---|---|---|---|---|---|---|
| 1 | `PATID` | Patient identifier | Character | PatientID. | 06_assemble.R | - |
| 2 | `INDEXDT` *[INDEX]* | Index date | Date | Per the cohort table: the setting's milestone date for cohorts 1-2, the index line's StartDate for cohorts 3-7. | 06_assemble.R | Q52 |
| 187 | `DATAV` | Data version | Character | Constant 20260630. | 06_assemble.R | Q77 |
| 188 | `RAWRWD` | Data source | Character | Constant Flatiron Prostate Panoramic Dataset. | 06_assemble.R | - |
| 189 | `MININDEX` | Earliest potential index | Date | Constant 2011-01-01. | 06_assemble.R | - |
| 190 | `MAXINDEX` | Latest potential index | Date | Constant 2026-04-30. | 06_assemble.R | Q01 |

### 5.2 4.StudyPop - Study population  (6 columns)

| # | Variable | Label | Permitted values | Definition as implemented | Built in | Judgement |
|---|---|---|---|---|---|---|
| 19 | `ID_PD_MCRPC` *[PRE_INT]* | mCRPC milestone in the index window | 0; 1 | 1 if MCRPCDD is not null and falls in [MININDEX, MAXINDEX], else 0. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | - |
| 20 | `ID_PD_MHSPC` *[PRE_INT]* | mHSPC milestone in the index window | 0; 1 | 1 if MHSPCDD is not null and falls in [MININDEX, MAXINDEX], else 0. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | - |
| 183 | `COHORT` | Analysis cohort | Overall mHSPC; Overall mCRPC; L1+ treated mHSPC; L1+ treated mCRPC; L2+ treated mCRPC; L3+ treated mCRPC; L4+ treated mCRPC | Per the cohort table. | 06_assemble.R | Q38 Q48 Q82 |
| 184 | `COHORTN` | Analysis cohort (N) | 1-7 | Numeric of COHORT, per the cohort table. | 05_outcomes.R | - |
| 185 | `COHORTU` | Treated status within setting | Untreated mCRPC; Treated mCRPC; Untreated mHSPC; Treated mHSPC | Treated means the patient has at least one line of therapy in the cohort's setting. Combine with the setting to give the label. | 06_assemble.R | Q11 Q19 |
| 186 | `COHORTUN` | Treated status within setting (N) | 1-4; 99 | Untreated mCRPC = 1, Treated mCRPC = 2, Untreated mHSPC = 3, Treated mHSPC = 4. | 06_assemble.R | - |

### 5.3 5A.Demos - Demographics  (19 columns)

| # | Variable | Label | Permitted values | Definition as implemented | Built in | Judgement |
|---|---|---|---|---|---|---|
| 3 | `ID3MOSFU` | 3 months potential follow-up | 0; 1 | 1 if MAXINDEX - INDEXDT >= 91 days, else 0. | 02_demographics.R | - |
| 4 | `BIRTHYEAR` *[PRE_INT]* | Birth year | Numeric | BirthYear, as given. | ? | Q22 |
| 5 | `AGE` *[INDEX]* | Age at index | Numeric | YEAR(INDEXDT) - BIRTHYEAR. | 02_demographics.R | - |
| 6 | `AGEGR1` *[INDEX]* | Age group | 0-18; 19-34; 35-49; 50-64; 65-74; 75-84; >=85; Unknown | Band AGE. Unknown where AGE is missing or negative. | 02_demographics.R | Q74 |
| 7 | `AGEGR1N` *[INDEX]* | Age group (N) | 1-7; 99 | Numeric of AGEGR1 in the Values order. 99 for Unknown. | 02_demographics.R | - |
| 8 | `STATE` *[PRE_INT]* | State of residence | Character | State, as given. | ? | - |
| 9 | `REGION1` *[PRE_INT]* | Census region | Northeast; Midwest; South; West; Other region; Missing; Unknown | Map STATE to census region. PR is Other region. A null state is Missing. A state in no region is Unknown. | 02_demographics.R | Q50 |
| 10 | `REGION1N` *[PRE_INT]* | Census region (N) | 1-6; 99 | Numeric of REGION1. 99 where the state is present but in no region. | 02_demographics.R | Q50 |
| 11 | `RACE` *[PRE_INT]* | Race | Asian; Black or African American; White; Other Race; Unknown/Missing | From demographics. Hispanic or Latino recodes to Other Race. Anything else is Unknown/Missing. | 02_demographics.R | - |
| 12 | `RACEN` *[PRE_INT]* | Race (N) | 1-5 | Numeric of RACE in the Values order. Evaluated on the source categories, before RACE is recoded. | 02_demographics.R | - |
| 13 | `ETHNICITY` *[PRE_INT]* | Ethnicity, source value | Character | Ethnicity, as given. | ? | - |
| 14 | `ETH` *[PRE_INT]* | Ethnicity | Not Hispanic or Latino; Hispanic or Latino; Unknown/Missing | Hispanic or Latino if either RACE or ETHNICITY says so. Else Not Hispanic or Latino if ETHNICITY says so. Else Unknown/Missing. | 02_demographics.R | - |
| 15 | `ETHN` *[PRE_INT]* | Ethnicity (N) | 1; 2; 3 | Numeric of ETH in the Values order: 1 Not Hispanic, 2 Hispanic, 3 Unknown/Missing. | 02_demographics.R | - |
| 16 | `PRACTICN` *[PRE_INT/FU]* | Practice type (N) | 1; 2; 3; 99 | Numeric of PRACTIC. 99 where the patient has no practice record. | 02_demographics.R | Q32 Q50 |
| 17 | `PRACTIC` *[PRE_INT/FU]* | Practice type | Academic only; Community only; Both academic and community; Missing | Aggregate the distinct practice types across all of the patient's practices. | 02_demographics.R | Q32 Q50 |
| 18 | `SES` *[PRE_INT]* | Socioeconomic status | 1 = lowest; 2; 3; 4; 5 = highest; Null | SESIndex2015_2019, passed through unchanged. | 02_demographics.R | Q51 |
| 34 | `STAGE` *[PRE_INT]* | Stage at initial diagnosis | 0; I; II; III; IV; Unknown/not documented | Prefix-match GroupStage longest first: IV, then III, then II, then I, then 0. Anything else is Unknown/not documented. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | Q31 |
| 35 | `STAGEN` *[PRE_INT]* | Stage (N) | 1-5; 99 | 0=1, I=2, II=3, III=4, IV=5. 99 where no group stage is recorded. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | Q31 |
| 122 | `DTHFUFL` *[FU]* | Acceptable death / follow-up gap | 0 = No; 1 = Yes; Null | 1 if DEATH_DT_preliminary - FU_ENDDT_preliminary <= 120 days, else 0. Null where there is no death date. | 01_studypop.R - patient-level death date and follow-up end date | Q57 |

### 5.4 5B.ClinChars - Clinical characteristics  (102 columns)

| # | Variable | Label | Permitted values | Definition as implemented | Built in | Judgement |
|---|---|---|---|---|---|---|
| 21 | `MCRPCDD` *[PRE_INT]* | mCRPC milestone date | Date | Later of MetastaticDiagnosisDate and CRPCDate. If one is missing, the other. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | Q52 |
| 22 | `MCRPCDDYR` *[PRE_INT]* | mCRPC milestone year | Numeric | YEAR(MCRPCDD). | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | Q70 |
| 23 | `MCRPCTYPE` *[PRE_INT]* | mCRPC evidence type | Character | CRPCType, as given. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | - |
| 24 | `MHSPCDD` *[PRE_INT]* | mHSPC milestone date | Date | Later of MetastaticDiagnosisDate and HSPCDate. If one is missing, the other. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | Q52 |
| 25 | `MHSPCDDYR` *[PRE_INT]* | mHSPC milestone year | Numeric | YEAR(MHSPCDD). | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | Q70 |
| 26 | `MHSPCTYPE` *[PRE_INT]* | mHSPC evidence type | Character | HSPCType, as given. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | - |
| 27 | `INIT` *[PRE_INT]* | Initial diagnosis date | Date | DiagnosisDate. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | - |
| 28 | `INITYR` *[PRE_INT]* | Initial diagnosis year | Numeric | YEAR(INIT). | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | Q09 Q70 |
| 29 | `MPCDD` *[PRE_INT]* | Metastatic diagnosis date | Date | MetastaticDiagnosisDate. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | - |
| 30 | `MPCDDYR` *[PRE_INT]* | Metastatic diagnosis year | Numeric | YEAR(MPCDD). | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | Q70 |
| 31 | `TTCRPC` *[PRE_INT]* | Time from initial diagnosis to CRPC | Numeric, months | DATEDIFF(CRPCDate, DiagnosisDate) / 30.4375. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | - |
| 32 | `TTHSPC` *[PRE_INT]* | Time from initial diagnosis to HSPC | Numeric, months | DATEDIFF(HSPCDate, DiagnosisDate) / 30.4375. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | - |
| 33 | `TINTCRPCHSPC` *[PRE_INT]* | Time from HSPC to CRPC | Numeric, months | DATEDIFF(CRPCDate, HSPCDate) / 30.4375. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | Q10 |
| 36 | `GLEASON` *[PRE_INT]* | Gleason score group | <8; >=8; Unknown/Missing | GleasonScore in {Less than or equal to 6, 3 + 4 = 7, 4 + 3 = 7, 7 (not documented), 7 (when breakdown not available)} is <8. In {8, 9, 10} is >=8. Anything else is Unknown/Missing. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | Q75 |
| 37 | `GLEASONN` *[PRE_INT]* | Gleason score group (N) | 1; 2; 3 | <8 = 1, >=8 = 2, Unknown/Missing = 3. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | Q61 Q75 |
| 38 | `PSADIAG_INIT` *[PRE_INT]* | PSA at initial diagnosis | Numeric | PSAInitialDiagnosis, as given. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | - |
| 39 | `PSADIAG_MET` *[PRE_INT]* | PSA at metastatic diagnosis | Numeric | PSAMetDiagnosis, as given. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) | - |
| 40 | `ECOG` *[LOT_ECOG]* | ECOG at baseline | 0; 1; 2; 3; 4; Unknown/Missing | Cohorts 1-2: baseline and longitudinal ECOG pooled, the record closest to the raw HSPCDate (cohort 1) or CRPCDate (cohort 2), within [INDEXDT-30, INDEXDT+7]. Cohorts 3-7: baseline ECOG matched on the index line's LineNumber and LineStartDate, the same window, the record closest to INDEXDT. Ties on distance take the earlier record; several on that date take the highest value. Any value outside 0-4 is Unknown/Missing. | 03_clinical.R - baseline ECOG (rows 47-48) | Q30 Q56 Q71 |
| 41 | `ECOGN` *[LOT_ECOG]* | ECOG at baseline (N) | 1-6 | 0=1, 1=2, 2=3, 3=4, 4=5, Unknown/Missing=6. | 03_clinical.R - baseline ECOG (rows 47-48) | Q23 Q71 |
| 42 | `LABNEU` *[PRE_INT]* | Neutrophils, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'neutrophils', TRIM(TestUnitsCleaned) = '10*9/L', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no neutrophils record at any date. Otherwise Unknown. | ? | Q58 Q63 Q80 |
| 43 | `LABNEUV` *[PRE_INT]* | Neutrophils, value (10*9/L) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the lowest value. | 03_clinical.R - baseline laboratory values (rows 17-46) | Q58 Q63 |
| 44 | `LABNEUDT` *[PRE_INT]* | Neutrophils, test date | Date | The later of TestDate and ResultDate on the record behind LABNEUV. | ? | Q58 Q63 |
| 45 | `LABPLA` *[PRE_INT]* | Platelets, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'platelets', TRIM(TestUnitsCleaned) = '10*9/L', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no platelets record at any date. Otherwise Unknown. | ? | Q07 Q55 Q58 Q63 |
| 46 | `LABPLAV` *[PRE_INT]* | Platelets, value (10*9/L) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the lowest value. | 03_clinical.R - baseline laboratory values (rows 17-46) | Q58 Q63 |
| 47 | `LABPLAVDT` *[PRE_INT]* | Platelets, test date | Date | The later of TestDate and ResultDate on the record behind LABPLAV. | ? | Q58 Q63 |
| 48 | `LABHEM` *[PRE_INT]* | Hemoglobin, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'hemoglobin', TRIM(TestUnitsCleaned) = 'g/dL', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no hemoglobin record at any date. Otherwise Unknown. | ? | Q58 Q63 Q69 |
| 49 | `LABHEMV` *[PRE_INT]* | Hemoglobin, value (g/dL) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the lowest value. | 03_clinical.R - baseline laboratory values (rows 17-46) | Q58 Q63 Q69 |
| 50 | `LABHEMDT` *[PRE_INT]* | Hemoglobin, test date | Date | The later of TestDate and ResultDate on the record behind LABHEMV. | ? | Q58 Q63 Q69 |
| 51 | `LABCRE` *[PRE_INT]* | Creatinine, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'creatinine' and LabComponent = 'Creatinine, serum', TRIM(TestUnitsCleaned) = 'mg/dL', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no creatinine record at any date. Otherwise Unknown. | ? | Q58 Q63 |
| 52 | `LABCREV` *[PRE_INT]* | Creatinine, value (mg/dL) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the lowest value. | 03_clinical.R - baseline laboratory values (rows 17-46) | Q58 Q63 |
| 53 | `LABCREDT` *[PRE_INT]* | Creatinine, test date | Date | The later of TestDate and ResultDate on the record behind LABCREV. | ? | Q58 Q63 |
| 54 | `LABBIL` *[PRE_INT]* | Bilirubin, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'bilirubin', TRIM(TestUnitsCleaned) = 'mg/dL', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no bilirubin record at any date. Otherwise Unknown. | ? | Q07 Q58 Q63 |
| 55 | `LABBILV` *[PRE_INT]* | Bilirubin, value (mg/dL) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the highest value. | 03_clinical.R - baseline laboratory values (rows 17-46) | Q58 Q63 |
| 56 | `LABBILDT` *[PRE_INT]* | Bilirubin, test date | Date | The later of TestDate and ResultDate on the record behind LABBILV. | ? | Q58 Q63 |
| 57 | `LABAST` *[PRE_INT]* | Aspartate aminotransferase, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'aspartate aminotransferase', TRIM(TestUnitsCleaned) = 'U/L', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no aspartate aminotransferase record at any date. Otherwise Unknown. | ? | Q58 Q63 |
| 58 | `LABASTV` *[PRE_INT]* | Aspartate aminotransferase, value (U/L) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the highest value. | 03_clinical.R - baseline laboratory values (rows 17-46) | Q58 Q63 |
| 59 | `LABASTDT` *[PRE_INT]* | Aspartate aminotransferase, test date | Date | The later of TestDate and ResultDate on the record behind LABASTV. | ? | Q58 Q63 |
| 60 | `LABALT` *[PRE_INT]* | Alanine aminotransferase, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'alanine aminotransferase', TRIM(TestUnitsCleaned) = 'U/L', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no alanine aminotransferase record at any date. Otherwise Unknown. | ? | Q58 Q63 |
| 61 | `LABALTV` *[PRE_INT]* | Alanine aminotransferase, value (U/L) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the highest value. | 03_clinical.R - baseline laboratory values (rows 17-46) | Q58 Q63 |
| 62 | `LABALTDT` *[PRE_INT]* | Alanine aminotransferase, test date | Date | The later of TestDate and ResultDate on the record behind LABALTV. | ? | Q58 Q63 |
| 63 | `LABALP` *[PRE_INT]* | Alkaline phosphatase, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'alkaline phosphatase', TRIM(TestUnitsCleaned) = 'U/L', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no alkaline phosphatase record at any date. Otherwise Unknown. | ? | Q58 Q63 |
| 64 | `LABALPV` *[PRE_INT]* | Alkaline phosphatase, value (U/L) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the highest value. | 03_clinical.R - baseline laboratory values (rows 17-46) | Q58 Q63 |
| 65 | `LABALPDT` *[PRE_INT]* | Alkaline phosphatase, test date | Date | The later of TestDate and ResultDate on the record behind LABALPV. | ? | Q58 Q63 |
| 66 | `LABALB` *[PRE_INT]* | Albumin, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'albumin' and LabComponent = 'Albumin, serum', TRIM(TestUnitsCleaned) = 'g/L', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no albumin record at any date. Otherwise Unknown. | ? | Q25 Q58 Q63 |
| 67 | `LABALBV` *[PRE_INT]* | Albumin, value (g/L) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the lowest value. | 03_clinical.R - baseline laboratory values (rows 17-46) | Q58 Q63 Q84 |
| 68 | `LABALBDT` *[PRE_INT]* | Albumin, test date | Date | The later of TestDate and ResultDate on the record behind LABALBV. | ? | Q58 Q63 |
| 69 | `LABLYM` *[PRE_INT]* | Lymphocytes, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'lymphocytes', TRIM(TestUnitsCleaned) = '10*9/L', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no lymphocytes record at any date. Otherwise Unknown. | ? | Q58 Q63 Q80 |
| 70 | `LABLYMV` *[PRE_INT]* | Lymphocytes, value (10*9/L) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the highest value. | 03_clinical.R - baseline laboratory values (rows 17-46) | Q58 Q63 |
| 71 | `LABLYMDT` *[PRE_INT]* | Lymphocytes, test date | Date | The later of TestDate and ResultDate on the record behind LABLYMV. | ? | Q12 Q58 Q63 |
| 72 | `BP` *[PRE_INT]* | Blood pressure, record status | Present; Unknown; Missing | Present if some TestDate on or before INDEXDT carries both a systolic and a diastolic reading and both are positive integers. Missing if the patient has no systolic and no diastolic record at any date. Otherwise Unknown. | 03_clinical.R - blood pressure (rows 49-53) | Q58 Q67 |
| 73 | `BPN` *[PRE_INT]* | Blood pressure, record status (N) | 1; 2; 3 | Present = 1, Unknown = 2, Missing = 3. | 03_clinical.R - blood pressure (rows 49-53) | - |
| 74 | `BPDT` *[PRE_INT]* | Blood pressure date | Date | The qualifying date closest to INDEXDT. Ties take the earlier date. | 03_clinical.R - blood pressure (rows 49-53) | - |
| 75 | `BPSYS` *[PRE_INT]* | Systolic blood pressure | Numeric | Highest systolic reading on BPDT. | ? | Q67 |
| 76 | `BPDIA` *[PRE_INT]* | Diastolic blood pressure | Numeric | Highest diastolic reading on BPDT. | ? | Q67 |
| 77 | `CSF_PRE` *[PRE_INT]* | Growth factor before index | 0; 1 | 1 if a record with DetailedDrugCategory = 'growth factor' dated on or before INDEXDT appears in drug episodes, medication orders that are not cancelled, or medication administrations. | ? | - |
| 78 | `CSF_FU` *[FU]* | Growth factor in follow-up | 0; 1 | The same three sources, dated after INDEXDT and on or before FUED. | ? | Q39 |
| 79 | `SS` *[PRE_INT]* | Steroid before index | 0; 1 | 1 if a record with DrugCategory = 'steroid' dated on or before INDEXDT appears in the same three sources. | ? | - |
| 80 | `WEIGHT` *[PRE_INT]* | Weight (kg) | Numeric | Vitals 'body weight' in kg with a non-null TestResultCleaned. Take the latest vital date on or before INDEXDT, then the highest value on that date. | 03_clinical.R - vitals: weight, height, BMI, BSA (rows 57-64) | Q68 Q72 |
| 81 | `WEIGHTDT` *[PRE_INT]* | Weight date | Date | The vital date behind WEIGHT. | 03_clinical.R - vitals: weight, height, BMI, BSA (rows 57-64) | - |
| 82 | `HEIGHT` *[PRE_INT]* | Height (cm) | Numeric | Vitals 'body height' in cm, by the same rule as WEIGHT. | 03_clinical.R - vitals: weight, height, BMI, BSA (rows 57-64) | Q68 Q72 |
| 83 | `HEIGHTDT` *[PRE_INT]* | Height date | Date | The vital date behind HEIGHT. | 03_clinical.R - vitals: weight, height, BMI, BSA (rows 57-64) | - |
| 84 | `BMI` *[PRE_INT]* | Body mass index | Numeric | WEIGHT / (HEIGHT/100)^2. Null unless both are present and HEIGHT is not zero. | 03_clinical.R - vitals: weight, height, BMI, BSA (rows 57-64) | Q68 Q72 |
| 85 | `BMIGR1` *[PRE_INT]* | BMI group | Underweight; Normal weight; Overweight; Obese; Missing | Under 18.5 Underweight; 18.5 to under 25 Normal weight; 25 to under 30 Overweight; 30 and over Obese; otherwise Missing. | 03_clinical.R - vitals: weight, height, BMI, BSA (rows 57-64) | Q70 |
| 86 | `BMIGR1N` *[PRE_INT]* | BMI group (N) | 1-5 | Numeric of BMIGR1 in the Values order, Missing = 5. | 03_clinical.R - vitals: weight, height, BMI, BSA (rows 57-64) | - |
| 87 | `BSA` *[PRE_INT]* | Body surface area | Numeric | 0.007184 * HEIGHT^0.725 * WEIGHT^0.425. Null unless both are present and neither is negative. | 03_clinical.R - vitals: weight, height, BMI, BSA (rows 57-64) | Q68 Q72 |
| 88 | `PSADIAG_CRPC` *[PRE_INT]* | PSA at the mCRPC milestone | Numeric | ScoreSerial from the earliest PSA result in [CRPCDate - 14, CRPCDate]. Several on that day take the highest. | 03_clinical.R - PSA at the mCRPC milestone and at index (rows 68-69) | - |
| 89 | `PSA_INDEX` *[PSA_INDEX]* | PSA at index | Numeric | ScoreSerial from the earliest PSA result in [INDEXDT - 14, INDEXDT]. Several on that day take the highest. | 03_clinical.R - PSA at the mCRPC milestone and at index (rows 68-69) | Q62 |
| 90 | `HRR_INDEX` *[BIOMARKER]* | HRR status at index | Positive; Negative; VUS; Unknown/Not documented | One winning test date per patient: the biomarker test closest to INDEXDT within [INDEXDT-30, INDEXDT+7], taken over every gene and every test type, with equidistant ties going to the earlier test. On that date resolve within each HRR gene - Positive+Negative gives Unknown; Positive with Unknown or VUS gives Positive; Negative with Unknown or VUS gives Negative; VUS+Unknown gives Unknown - then roll up across genes best first: Positive, Negative, VUS, Unknown. | 03_clinical.R - biomarker status at index (rows 70-77) | Q04 Q05 Q28 Q29 Q37 Q44 Q72 |
| 91 | `HRR_INDEXN` *[BIOMARKER]* | HRR status at index (N) | 1-4 | Positive = 1, Negative = 2, VUS = 3, Unknown/Not documented = 4. | 03_clinical.R - biomarker status at index (rows 70-77) | - |
| 92 | `HRR_LABEL_INDEX` *[BIOMARKER]* | HRR status, olaparib label panel | Positive; Negative; VUS; Unknown/Not documented | The same derivation as HRR_INDEX, over the 14 genes named on the olaparib label. | 03_clinical.R - biomarker status at index (rows 70-77) | - |
| 93 | `HRR_LABEL_INDEXN` *[BIOMARKER]* | HRR status, olaparib label panel (N) | 1-4 | Positive = 1, Negative = 2, VUS = 3, Unknown/Not documented = 4. | 03_clinical.R - biomarker status at index (rows 70-77) | - |
| 94 | `BRCA_INDEX` *[BIOMARKER]* | BRCA status at index | Positive; Negative; VUS; Unknown/Not documented | The same derivation over BRCA1 and BRCA2, on the same winning date as HRR_INDEX. | 03_clinical.R - biomarker status at index (rows 70-77) | Q04 Q28 Q29 Q37 Q72 |
| 95 | `BRCA_INDEXN` *[BIOMARKER]* | BRCA status at index (N) | 1-4 | Positive = 1, Negative = 2, VUS = 3, Unknown/Not documented = 4. | 03_clinical.R - biomarker status at index (rows 70-77) | - |
| 96 | `HRR_INDEX_TEST` *[BIOMARKER]* | HRR test type | Unknown | Emitted as Unknown for every patient. | 03_clinical.R - biomarker status at index (rows 70-77) | Q03 |
| 97 | `HRR_INDEX_TESTN` *[BIOMARKER]* | HRR test type (N) | 7 | Emitted as 7. | 03_clinical.R - biomarker status at index (rows 70-77) | - |
| 98 | `BRCA_INDEX_TEST` *[BIOMARKER]* | BRCA test type | Unknown | Emitted as Unknown for every patient. | 03_clinical.R - biomarker status at index (rows 70-77) | Q03 |
| 99 | `BRCA_INDEX_TESTN` *[BIOMARKER]* | BRCA test type (N) | 7 | Emitted as 7. | 03_clinical.R - biomarker status at index (rows 70-77) | - |
| 100 | `PSMA_SCANDT` *[PRE_INT]* | Latest PSMA PET scan date | Date | Latest ScanDate on or before INDEXDT. | 03_clinical.R - PSMA PET scan (rows 78-79) | Q33 |
| 101 | `PSMA_SCANRESULT` *[PRE_INT]* | PSMA PET disease evidence | Yes; No; Unknown/not documented | IsDiseaseEvidence on PSMA_SCANDT. Yes and No on the same date give Unknown/not documented; Yes with Unknown gives Yes; No with Unknown gives No. No scan gives Unknown/not documented. | 03_clinical.R - PSMA PET scan (rows 78-79) | Q26 |
| 102 | `LUNG_METDT` *[PRE_INT/FU]* | Lung metastasis date | Date | Earliest DateOfMetastasis for site Lung, with no date bound; the date may postdate MAXINDEX. | 03_clinical.R - sites of metastasis (rows 80-87) | - |
| 103 | `LUNG_MET` *[PRE_INT]* | Lung metastasis at index | Yes; No | Yes if LUNG_METDT is on or before INDEXDT, else No. | 03_clinical.R - sites of metastasis (rows 80-87) | - |
| 104 | `ADRENAL_METDT` *[PRE_INT/FU]* | Adrenal metastasis date | Date | Earliest DateOfMetastasis for site Adrenal, with no date bound; the date may postdate MAXINDEX. | 03_clinical.R - sites of metastasis (rows 80-87) | - |
| 105 | `ADRENAL_MET` *[PRE_INT]* | Adrenal metastasis at index | Yes; No | Yes if ADRENAL_METDT is on or before INDEXDT, else No. | 03_clinical.R - sites of metastasis (rows 80-87) | - |
| 106 | `BONE_METDT` *[PRE_INT/FU]* | Bone metastasis date | Date | Earliest DateOfMetastasis for site Bone, with no date bound; the date may postdate MAXINDEX. | 03_clinical.R - sites of metastasis (rows 80-87) | - |
| 107 | `BONE_MET` *[PRE_INT]* | Bone metastasis at index | Yes; No | Yes if BONE_METDT is on or before INDEXDT, else No. | 03_clinical.R - sites of metastasis (rows 80-87) | - |
| 108 | `BRAIN_METDT` *[PRE_INT/FU]* | Brain metastasis date | Date | Earliest DateOfMetastasis for site Brain, with no date bound; the date may postdate MAXINDEX. | 03_clinical.R - sites of metastasis (rows 80-87) | - |
| 109 | `BRAIN_MET` *[PRE_INT]* | Brain metastasis at index | Yes; No | Yes if BRAIN_METDT is on or before INDEXDT, else No. | 03_clinical.R - sites of metastasis (rows 80-87) | - |
| 110 | `MIN_VST_DT` *[PRE_INT/FU]* | First visit date | Date | Earliest VisitDate. | 01_studypop.R - patient-level death date and follow-up end date | Q21 |
| 111 | `MIN_VSTTELEMED_DT` *[PRE_INT/FU]* | First telemedicine visit date | Date | Earliest telemedicine VisitDate. | 01_studypop.R - patient-level death date and follow-up end date | Q21 |
| 112 | `MIN_MEDORD_DT` *[PRE_INT/FU]* | First medication order date | Date | Earliest ExpectedStartDate among medication orders that are not cancelled. | 01_studypop.R - patient-level death date and follow-up end date | Q21 |
| 113 | `MAX_VSTTELEMED_DT` *[PRE_INT/FU]* | Last telemedicine visit date | Date | Latest telemedicine VisitDate. | 01_studypop.R - patient-level death date and follow-up end date | - |
| 114 | `MAX_LOTEND_DT` *[PRE_INT/FU]* | Last line-of-therapy end date | Date | Latest line-of-therapy EndDate. | 01_studypop.R - patient-level death date and follow-up end date | - |
| 115 | `MAX_DRUG_EP_ABSTRACTED_DT` *[PRE_INT/FU]* | Last abstracted drug-episode date | Date | Latest EpisodeDate where EpisodeDataSource = 'Abstraction'. | 01_studypop.R - patient-level death date and follow-up end date | Q16 |
| 116 | `FU_ENDDT_PRELIMINARY` *[FU]* | Last activity date | Date | Latest of four dates: last visit, last telemedicine visit, last line-of-therapy end, and last oral end date where the start-date granularity is not YEAR and the end date is present. | 01_studypop.R - patient-level death date and follow-up end date | Q40 Q54 |
| 117 | `DATEOFDEATH` *[FU]* | Death date, source value | Character | DateOfDeath, as given. | ? | Q66 |
| 118 | `DEATH_DT_PRELIMINARY` *[FU]* | Death date, imputed | Date | From DATEOFDEATH, imputed to the middle of the period and not adjusted again. Length 7 (YYYY-MM) imputes day 15; length 4 (YYYY) imputes 07-15. Any other length is NULL. | 01_studypop.R - patient-level death date and follow-up end date | Q66 |
| 119 | `DTHDT` *[FU]* | Death date, final | Date | DEATH_DT_preliminary, unchanged. The row-92 promotion to the last day of the month is withdrawn. | 01_studypop.R - patient-level death date and follow-up end date | Q33 Q66 Q82 |
| 120 | `DTHFL` *[FU]* | Death flag | 0 = No; 1 = Yes | 1 if DTHDT is not null, else 0. | 01_studypop.R - patient-level death date and follow-up end date | Q53 Q66 |
| 121 | `FUED` *[FU]* | Follow-up end date | Date | DTHDT where a death date exists, otherwise FU_ENDDT_preliminary. NOT the earlier of the two. | 01_studypop.R - patient-level death date and follow-up end date | Q33 Q40 Q45 Q82 |
| 123 | `DTH_BEFORE_FUED` *[FU]* | Death before follow-up end | 0; 1 | 1 if DTHDT and FUED are both present and DTHDT < FUED, else 0. | 01_studypop.R - patient-level death date and follow-up end date | - |
| 124 | `FUDUR` *[FU]* | Follow-up duration | Numeric, days | DATEDIFF(FUED, INDEXDT) + 1. | 03_clinical.R - master clinical: combine the pieces | Q83 |
| 125 | `INDEXYR` *[INDEX]* | Index year | Numeric | YEAR(INDEXDT). | 03_clinical.R - master clinical: combine the pieces | - |

### 5.5 5C.TreatVars - Treatment  (44 columns)

| # | Variable | Label | Permitted values | Definition as implemented | Built in | Judgement |
|---|---|---|---|---|---|---|
| 126 | `LOT1_MHSPC` *[PRE_INT/FU]* | Line 1 regimen, mHSPC | Character | LineName of the line with NEW_LOT_N = 1 in the mHSPC setting. NULL where the line does not exist. | 04_treatment.R | Q64 |
| 127 | `LOT1SD_MHSPC` *[PRE_INT/FU]* | Line 1 start date, mHSPC | Date | StartDate of the line with NEW_LOT_N = 1 in the mHSPC setting. | 04_treatment.R | - |
| 128 | `LOT1ED_MHSPC` *[PRE_INT/FU]* | Line 1 end date, mHSPC | Date | Latest EpisodeDate in the drug-episode table for that line, matched on the source LineNumber within the mHSPC setting. | 04_treatment.R | - |
| 129 | `LOT1CAT_MHSPC` *[PRE_INT/FU]* | Line 1 category, mHSPC | 1 Abiraterone monotherapy; 2 Enzalutamide monotherapy; 3 Apalutamide monotherapy; 4 Darolutamide monotherapy; 5 NHA combination therapy; 6 Docetaxel monotherapy; 7 Docetaxel combination therapy; 8 Cabazitaxel-containing; 9 Other chemotherapy-containing; 10 Pluvicto-containing; 11 Radium 223-containing; 12 PARPi monotherapy; 13 Pembrolizumab-containing; 14 Sipuleucel-T-containing; 15 Clinical study drug-containing; 16 Any other therapy; 17 No treatment | Classify the line's LineName, first match wins, in the order the Values list gives. A monotherapy category is a whole-string match; a combination category needs the drug plus a comma or slash. Other chemotherapy-containing reads DetailedDrugCategory = 'chemotherapy' on the line's drug episodes. PARPi monotherapy is an anchored whole-string match on olaparib, talazoparib, niraparib and rucaparib with no other drug allowed. A null LineName is No treatment. | 04_treatment.R | Q65 |
| 130 | `LOT1CATN_MHSPC` *[PRE_INT/FU]* | Line 1 category (N), mHSPC | 1-17 | Numeric of the category, per the Values list. | 04_treatment.R | Q65 |
| 131 | `LOT2_MHSPC` *[PRE_INT/FU]* | Line 2 regimen, mHSPC | Character | LineName of the line with NEW_LOT_N = 2 in the mHSPC setting. NULL where the line does not exist. | 04_treatment.R | Q64 |
| 132 | `LOT2SD_MHSPC` *[PRE_INT/FU]* | Line 2 start date, mHSPC | Date | StartDate of the line with NEW_LOT_N = 2 in the mHSPC setting. | 04_treatment.R | - |
| 133 | `LOT2ED_MHSPC` *[PRE_INT/FU]* | Line 2 end date, mHSPC | Date | Latest EpisodeDate in the drug-episode table for that line, matched on the source LineNumber within the mHSPC setting. | 04_treatment.R | - |
| 134 | `LOT2CAT_MHSPC` *[PRE_INT/FU]* | Line 2 category, mHSPC | 1 Abiraterone monotherapy; 2 Enzalutamide monotherapy; 3 Apalutamide monotherapy; 4 Darolutamide monotherapy; 5 NHA combination therapy; 6 Docetaxel monotherapy; 7 Docetaxel combination therapy; 8 Cabazitaxel-containing; 9 Other chemotherapy-containing; 10 Pluvicto-containing; 11 Radium 223-containing; 12 PARPi monotherapy; 13 Pembrolizumab-containing; 14 Sipuleucel-T-containing; 15 Clinical study drug-containing; 16 Any other therapy; 17 No treatment | Classify the line's LineName, first match wins, in the order the Values list gives. A monotherapy category is a whole-string match; a combination category needs the drug plus a comma or slash. Other chemotherapy-containing reads DetailedDrugCategory = 'chemotherapy' on the line's drug episodes. PARPi monotherapy is an anchored whole-string match on olaparib, talazoparib, niraparib and rucaparib with no other drug allowed. A null LineName is No treatment. | 04_treatment.R | - |
| 135 | `LOT2CATN_MHSPC` *[PRE_INT/FU]* | Line 2 category (N), mHSPC | 1-17 | Numeric of the category, per the Values list. | 04_treatment.R | - |
| 136 | `LOT1_MCRPC` *[PRE_INT/FU]* | Line 1 regimen, mCRPC | Character | LineName of the line with NEW_LOT_N = 1 in the mCRPC setting. NULL where the line does not exist. | 04_treatment.R | Q64 Q73 |
| 137 | `LOT1SD_MCRPC` *[PRE_INT/FU]* | Line 1 start date, mCRPC | Date | StartDate of the line with NEW_LOT_N = 1 in the mCRPC setting. | 04_treatment.R | - |
| 138 | `LOT1ED_MCRPC` *[PRE_INT/FU]* | Line 1 end date, mCRPC | Date | Latest EpisodeDate in the drug-episode table for that line, matched on the source LineNumber within the mCRPC setting. | 04_treatment.R | - |
| 139 | `LOT1CAT_MCRPC` *[PRE_INT/FU]* | Line 1 category, mCRPC | 1 Abiraterone monotherapy; 2 Enzalutamide monotherapy; 3 Apalutamide monotherapy; 4 Darolutamide monotherapy; 5 NHA combination therapy; 6 Docetaxel monotherapy; 7 Docetaxel combination therapy; 8 Cabazitaxel-containing; 9 Other chemotherapy-containing; 10 Pluvicto-containing; 11 Radium 223-containing; 12 PARPi monotherapy; 13 Pembrolizumab-containing; 14 Sipuleucel-T-containing; 15 Clinical study drug-containing; 16 Any other therapy; 17 No treatment | Classify the line's LineName, first match wins, in the order the Values list gives. A monotherapy category is a whole-string match; a combination category needs the drug plus a comma or slash. Other chemotherapy-containing reads DetailedDrugCategory = 'chemotherapy' on the line's drug episodes. PARPi monotherapy is an anchored whole-string match on olaparib, talazoparib, niraparib and rucaparib with no other drug allowed. A null LineName is No treatment. | 04_treatment.R | Q65 Q72 Q73 |
| 140 | `LOT1CATN_MCRPC` *[PRE_INT/FU]* | Line 1 category (N), mCRPC | 1-17 | Numeric of the category, per the Values list. | 04_treatment.R | Q65 |
| 141 | `LOT2_MCRPC` *[PRE_INT/FU]* | Line 2 regimen, mCRPC | Character | LineName of the line with NEW_LOT_N = 2 in the mCRPC setting. NULL where the line does not exist. | 04_treatment.R | Q64 |
| 142 | `LOT2SD_MCRPC` *[PRE_INT/FU]* | Line 2 start date, mCRPC | Date | StartDate of the line with NEW_LOT_N = 2 in the mCRPC setting. | 04_treatment.R | - |
| 143 | `LOT2ED_MCRPC` *[PRE_INT/FU]* | Line 2 end date, mCRPC | Date | Latest EpisodeDate in the drug-episode table for that line, matched on the source LineNumber within the mCRPC setting. | 04_treatment.R | - |
| 144 | `LOT2CAT_MCRPC` *[PRE_INT/FU]* | Line 2 category, mCRPC | 1 Abiraterone monotherapy; 2 Enzalutamide monotherapy; 3 Apalutamide monotherapy; 4 Darolutamide monotherapy; 5 NHA combination therapy; 6 Docetaxel monotherapy; 7 Docetaxel combination therapy; 8 Cabazitaxel-containing; 9 Other chemotherapy-containing; 10 Pluvicto-containing; 11 Radium 223-containing; 12 PARPi monotherapy; 13 Pembrolizumab-containing; 14 Sipuleucel-T-containing; 15 Clinical study drug-containing; 16 Any other therapy; 17 No treatment | Classify the line's LineName, first match wins, in the order the Values list gives. A monotherapy category is a whole-string match; a combination category needs the drug plus a comma or slash. Other chemotherapy-containing reads DetailedDrugCategory = 'chemotherapy' on the line's drug episodes. PARPi monotherapy is an anchored whole-string match on olaparib, talazoparib, niraparib and rucaparib with no other drug allowed. A null LineName is No treatment. | 04_treatment.R | - |
| 145 | `LOT2CATN_MCRPC` *[PRE_INT/FU]* | Line 2 category (N), mCRPC | 1-17 | Numeric of the category, per the Values list. | 04_treatment.R | - |
| 146 | `LOT3_MCRPC` *[PRE_INT/FU]* | Line 3 regimen, mCRPC | Character | LineName of the line with NEW_LOT_N = 3 in the mCRPC setting. NULL where the line does not exist. | 04_treatment.R | Q64 |
| 147 | `LOT3SD_MCRPC` *[PRE_INT/FU]* | Line 3 start date, mCRPC | Date | StartDate of the line with NEW_LOT_N = 3 in the mCRPC setting. | 04_treatment.R | - |
| 148 | `LOT3ED_MCRPC` *[PRE_INT/FU]* | Line 3 end date, mCRPC | Date | Latest EpisodeDate in the drug-episode table for that line, matched on the source LineNumber within the mCRPC setting. | 04_treatment.R | - |
| 149 | `LOT3CAT_MCRPC` *[PRE_INT/FU]* | Line 3 category, mCRPC | 1 Abiraterone monotherapy; 2 Enzalutamide monotherapy; 3 Apalutamide monotherapy; 4 Darolutamide monotherapy; 5 NHA combination therapy; 6 Docetaxel monotherapy; 7 Docetaxel combination therapy; 8 Cabazitaxel-containing; 9 Other chemotherapy-containing; 10 Pluvicto-containing; 11 Radium 223-containing; 12 PARPi monotherapy; 13 Pembrolizumab-containing; 14 Sipuleucel-T-containing; 15 Clinical study drug-containing; 16 Any other therapy; 17 No treatment | Classify the line's LineName, first match wins, in the order the Values list gives. A monotherapy category is a whole-string match; a combination category needs the drug plus a comma or slash. Other chemotherapy-containing reads DetailedDrugCategory = 'chemotherapy' on the line's drug episodes. PARPi monotherapy is an anchored whole-string match on olaparib, talazoparib, niraparib and rucaparib with no other drug allowed. A null LineName is No treatment. | 04_treatment.R | - |
| 150 | `LOT3CATN_MCRPC` *[PRE_INT/FU]* | Line 3 category (N), mCRPC | 1-17 | Numeric of the category, per the Values list. | 04_treatment.R | - |
| 151 | `LOT4_MCRPC` *[PRE_INT/FU]* | Line 4 regimen, mCRPC | Character | LineName of the line with NEW_LOT_N = 4 in the mCRPC setting. NULL where the line does not exist. | 04_treatment.R | Q64 |
| 152 | `LOT4SD_MCRPC` *[PRE_INT/FU]* | Line 4 start date, mCRPC | Date | StartDate of the line with NEW_LOT_N = 4 in the mCRPC setting. | 04_treatment.R | - |
| 153 | `LOT4ED_MCRPC` *[PRE_INT/FU]* | Line 4 end date, mCRPC | Date | Latest EpisodeDate in the drug-episode table for that line, matched on the source LineNumber within the mCRPC setting. | 04_treatment.R | - |
| 154 | `LOT4CAT_MCRPC` *[PRE_INT/FU]* | Line 4 category, mCRPC | 1 Abiraterone monotherapy; 2 Enzalutamide monotherapy; 3 Apalutamide monotherapy; 4 Darolutamide monotherapy; 5 NHA combination therapy; 6 Docetaxel monotherapy; 7 Docetaxel combination therapy; 8 Cabazitaxel-containing; 9 Other chemotherapy-containing; 10 Pluvicto-containing; 11 Radium 223-containing; 12 PARPi monotherapy; 13 Pembrolizumab-containing; 14 Sipuleucel-T-containing; 15 Clinical study drug-containing; 16 Any other therapy; 17 No treatment | Classify the line's LineName, first match wins, in the order the Values list gives. A monotherapy category is a whole-string match; a combination category needs the drug plus a comma or slash. Other chemotherapy-containing reads DetailedDrugCategory = 'chemotherapy' on the line's drug episodes. PARPi monotherapy is an anchored whole-string match on olaparib, talazoparib, niraparib and rucaparib with no other drug allowed. A null LineName is No treatment. | 04_treatment.R | - |
| 155 | `LOT4CATN_MCRPC` *[PRE_INT/FU]* | Line 4 category (N), mCRPC | 1-17 | Numeric of the category, per the Values list. | 04_treatment.R | Q17 |
| 156 | `LOTN` *[PRE_INT/FU]* | Number of mCRPC lines | Numeric | Highest NEW_LOT_N in the mCRPC setting; 0 if the patient has none. | 04_treatment.R | Q06 |
| 157 | `LOTNGR1` *[PRE_INT/FU]* | Number of mCRPC lines, grouped | 0; 1; 2; 3; 4; 5+ | Band LOTN. | 04_treatment.R | - |
| 158 | `LOTNGR1N` *[PRE_INT/FU]* | Number of mCRPC lines, grouped (N) | 1-6 | 0 = 1, 1 = 2, 2 = 3, 3 = 4, 4 = 5, 5+ = 6. | 04_treatment.R | - |
| 159 | `LOTN_MHSPC` *[PRE_INT/FU]* | Number of mHSPC lines | Numeric | Highest NEW_LOT_N in the mHSPC setting; 0 if the patient has none. | 04_treatment.R | - |
| 160 | `LOTNGR1_MHSPC` *[PRE_INT/FU]* | Number of mHSPC lines, grouped | 0; 1; 2; 3; 4; 5+ | Band LOTN_MHSPC. | 04_treatment.R | - |
| 161 | `LOTNGR1N_MHSPC` *[PRE_INT/FU]* | Number of mHSPC lines, grouped (N) | 1-6 | 0 = 1, 1 = 2, 2 = 3, 3 = 4, 4 = 5, 5+ = 6. | 04_treatment.R | - |
| 162 | `PRIOR_PLUVICTO` *[PRE_INT]* | Prior Pluvicto | Yes; No | Read from the drug-episode regimen names with EpisodeDate before INDEXDT, in any setting. Yes if a regimen contains vipivotide tetraxetan. | ? | - |
| 163 | `PRIOR_PARP` *[PRE_INT]* | Prior PARP inhibitor | Yes; No | Read from the drug-episode regimen names with EpisodeDate before INDEXDT, in any setting. Yes if a regimen is made up only of olaparib, talazoparib, niraparib or rucaparib, separated by comma or slash. | ? | Q65 |
| 164 | `PRIOR_CHEMO` *[PRE_INT]* | Prior chemotherapy | Yes; No | Read from the drug-episode regimen names with EpisodeDate before INDEXDT, in any setting. Yes if any drug episode has DetailedDrugCategory = 'chemotherapy'. | ? | - |
| 165 | `PRIOR_NHA_ADT` *[PRE_INT]* | Prior NHA combination | Yes; No | Read from the drug-episode regimen names with EpisodeDate before INDEXDT, in any setting. Yes if a regimen contains an NHA - abiraterone, enzalutamide, apalutamide or darolutamide - and at least one further drug. | ? | Q60 |
| 166 | `PRIOR_DOCETAXEL` *[PRE_INT]* | Prior docetaxel | Yes; No | Read from the drug-episode regimen names with EpisodeDate before INDEXDT, in any setting. Yes if a regimen contains docetaxel. | ? | - |
| 167 | `PRIOR_ABIRATERONE` *[PRE_INT]* | Prior abiraterone | Yes; No | Read from the drug-episode regimen names with EpisodeDate before INDEXDT, in any setting. Yes if a regimen contains abiraterone. | ? | - |
| 168 | `PRIOR_ARPI` *[PRE_INT]* | Prior ARPI | Yes; No | Read from the drug-episode regimen names with EpisodeDate before INDEXDT, in any setting. Yes if a regimen contains any NHA, alone or in combination. | ? | - |
| 169 | `CSD` *[PRE_INT/FU]* | Clinical study drug | 0; 1 | Cohorts 3-7: 1 if the index line's regimen name contains 'clinical study drug'. Cohorts 1-2: 1 if any line in the cohort's setting does. | 04_treatment.R | Q49 Q81 |

### 5.6 6.Outcomes - Outcomes  (13 columns)

| # | Variable | Label | Permitted values | Definition as implemented | Built in | Judgement |
|---|---|---|---|---|---|---|
| 170 | `OS` *[FU]* | Overall survival | Numeric, months | Dead: (DATEDIFF(DTHDT, INDEXDT) + 1) / 30.4375. Alive: (DATEDIFF(FUED, INDEXDT) + 1) / 30.4375. Null when DTH_BEFORE_FUED = 1. | 05_outcomes.R | Q47 Q83 |
| 171 | `VIS120` *[FU]* | Visit 120 days after the index line | 0; 1 | Cohorts 3-7: 1 if a visit or telemedicine visit falls on or after the index line's end date plus 120 days, else 0. Null for cohorts 1-2, which have no index line. | 05_outcomes.R | Q36 |
| 172 | `TTNT` *[FU]* | Time to next treatment | Numeric, months | Cohorts 3-6 with ID3MOSFU = 1. Next treatment is: cohort 3, the earlier of LOT2SD_MHSPC and LOT1SD_MCRPC; cohort 4, LOT2SD_MCRPC; cohort 5, LOT3SD_MCRPC; cohort 6, LOT4SD_MCRPC. Event, meaning a next treatment or a death is seen: (DATEDIFF(earlier of next treatment and DTHDT, INDEXDT) + 1) / 30.4375. Otherwise censored at FUED. Null when DTH_BEFORE_FUED = 1, and for cohorts 1, 2 and 7. | 05_outcomes.R | Q42 Q83 |
| 173 | `ELIGPFS` *[FU]* | rwPFS eligibility | 0; 1 | 1 if ID3MOSFU = 1 and the last clinic note falls after INDEXDT, else 0. Null for cohorts 1-2. | 05_outcomes.R | - |
| 174 | `PFSFL` *[FU]* | rwPFS event flag | 0; 1 | Among eligible patients: 1 if an eligible progression is seen, or none is seen and the patient died; else 0. Null for cohorts 1-2. | 05_outcomes.R | Q41 |
| 175 | `PFSDT` *[FU]* | rwPFS event date | Date | First progression dated on or after INDEXDT + 14 carrying any progression evidence other than pseudo-progression. Where no eligible progression is seen and the patient died, DTHDT. Missing when there is no event. | 05_outcomes.R | Q34 Q41 |
| 176 | `PFS` *[FU]* | rwPFS | Numeric, months | Event: (DATEDIFF(PFSDT, INDEXDT) + 1) / 30.4375. Censored: (DATEDIFF(LastClinicNoteDate, INDEXDT) + 1) / 30.4375. Null for cohorts 1-2. | 05_outcomes.R | Q34 |
| 177 | `PSA6MO` *[FU]* | PSA at 6 months | Numeric | Earliest ScoreSerial in [INDEXDT + 180, INDEXDT + 210]. Several on that day take the highest. | ? | Q79 |
| 178 | `PSA50_6MO` *[FU]* | PSA50 response at 6 months | Y; N | Y if (PSA6MO - PSA_INDEX) / PSA_INDEX <= -0.5, with PSA_INDEX > 0. Else N. | 05_outcomes.R | Q35 Q59 Q70 Q79 |
| 179 | `PSAL6MO` *[FU]* | PSA under 0.2 at 6 months | Y; N | Y if PSA6MO < 0.2, else N. | 05_outcomes.R | Q35 Q70 Q79 |
| 180 | `PSA12MO` *[FU]* | PSA at 12 months | Numeric | Earliest ScoreSerial in [INDEXDT + 365, INDEXDT + 395]. Several on that day take the highest. | ? | - |
| 181 | `PSA50_12MO` *[FU]* | PSA50 response at 12 months | Y; N | Y if (PSA12MO - PSA_INDEX) / PSA_INDEX <= -0.5, with PSA_INDEX > 0. Else N. | 05_outcomes.R | Q35 Q59 Q70 |
| 182 | `PSAL12MO` *[FU]* | PSA under 0.2 at 12 months | Y; N | Y if PSA12MO < 0.2, else N. | 05_outcomes.R | Q35 Q70 |

## 6. Intermediate variables

Values the build creates on the way to a delivered column. Check these when a
delivered value looks wrong and its own definition looks right: most of the
specification's harder derivations are two or three steps, and the step that
went wrong is usually here rather than in the final column.

**Delivered** says whether the value reaches the ADS. Several do, because the
specification asks for its own working dates to be kept (register Q21).

| Intermediate | Built in | What it is | Feeds | Delivered |
|---|---|---|---|---|
| `index_date` | `01_studypop.R`, `index_lot_cohort()` | The cohort's index date: the setting's milestone for cohorts 1-2, the index line's start date for 3-7. Every window in the row is relative to it | everything time-anchored | as `INDEXDT` |
| `new_lot_n` | `00_setup.R`, `lot_tbl()` | Line number within a patient and a setting, ordered by start date. **Not** the source's own line number | cohort membership 3-7, every `LOT*` column | no |
| `id_pd_mcrpc`, `id_pd_mhspc` | `03_clinical.R`, milestone block | Whether the setting's milestone falls inside `[MININDEX, MAXINDEX]` - the inclusion test | cohort membership | yes |
| `last_visitdate`, `last_televisitdate`, `last_lotenddate`, `last_oralenddate` | `01_studypop.R`, death and follow-up block | The four activity dates the spec lists at row 89. The oral end date is filtered to non-year granularity with an end date present | `FU_ENDDT_preliminary` | no |
| `min_vst_dt`, `min_vsttelemed_dt`, `min_medord_dt`, `max_drug_ep_abstracted_dt` | `01_studypop.R`, death and follow-up block | Row-88 interim dates. They play no part in the follow-up derivation; row 88 asks for them by name, so they are produced and carried through. `max_drug_ep_abstracted_dt` is null for every patient because its source value does not exist in this cut (Q16) | nothing | yes |
| `fu_enddt_preliminary` | `01_studypop.R`, death and follow-up block | The latest of those four activity dates - the "last activity date" | `FUED`, `DTHFUFL` | yes |
| `dateofdeath_init` | `01_studypop.R`, death and follow-up block | `DATEOFDEATH` imputed to the middle of the period: day 15 for a month-and-year value, 15 July for a year-only value, NULL for any other length | `DEATH_DT_preliminary` | no |
| `death_dt_preliminary` | `01_studypop.R`, death and follow-up block | The imputed value itself, with nothing applied after it | `DTHDT`, `DTHFUFL` | yes |
| `dthfufl_dur` | `01_studypop.R`, death and follow-up block | `DEATH_DT_preliminary - FU_ENDDT_preliminary` in days, on the **preliminary** dates, not the final ones | `DTHFUFL` | no |
| `lotcat`, `lotcatn` | `04_treatment.R`, `lotcat_expr()` / `lotcatn_expr()` | The 17 treatment categories parsed from `LINENAME`, and their codes. A comma is taken as proof of a second drug; a slash binds inside one product name | every `LOT*CAT*` column | no |
| `csd_flag` | `04_treatment.R` | Whether the index line's own category is systemic | `CSD` | no |
| `treat_mhspc`, `treat_mcrpc` | `06_assemble.R` | Whether the patient has any line in that setting, used for the treated-status column | `COHORTU`, `COHORTUN` | no |
| `practicetype_agg` | `02_demographics.R` | Practice type collapsed to the spec's categories | `PRACTIC`, `PRACTICN` | no |
| `flatiron_all`, `olaparib_label`, `talapro2` | `00_setup.R` | The three frozen gene panels - 19 approved symbols, the 14-gene FDA olaparib label panel, the 12-gene TALAPRO-2 panel. Naming them in code pins the case definition | `HRR_INDEX`, `HRR_LABEL_INDEX`, `BRCA_INDEX` | no |
| `bpval` | `03_clinical.R`, blood pressure block | The castable blood-pressure reading before the whole-number test | `SBP`, `DBP` and their flags | no |
| `psabl` | `05_outcomes.R` | The baseline PSA the PSA50 response guard reads | the PSA response columns | no |
| `index_lot_ed` | `05_outcomes.R` | End date of the index line | `VIS120` - whether the last contact is at least 120 days after it | no |
| `next_trt_dt` | `05_outcomes.R` | The next-treatment date: for cohort 3 the earlier of the L2 mHSPC and L1 mCRPC starts, otherwise the next line in the same setting. **It is not constrained to follow the index date** | `TTNT`, `TTNTFL` | no |
| `ttntfl` | `05_outcomes.R` | The TTNT event flag. The spec strikes the variable out but its active definition still reads it, so it is derived and excluded from the 190 (Q02) | `TTNT` | **no, by decision** |
| `first_progdt` | `05_outcomes.R` | First progression date after index | `PFSDT`, `PFS` | no |
| `last_contact_dt`, `lastclinicnotedate` | `05_outcomes.R` | The censoring anchors for the alive branches | `OS`, `PFS` | no |

## 7. Follow-up end date, death date, and cohort membership

This is the part of the build that changed most recently and the part most worth
reading before using an outcome. It implements a study-team ruling of
**2026-09-11**, recorded as register rows **Q82** and **Q83**.

The ruling is four rules, labelled **RP1-RP4** here and cited by that label from
every program that implements or checks one:

| | Rule | Where it lives |
|---|---|---|
| **RP1** | The death date is imputed to the middle of the period - day 15 for a month-and-year value, 15 July for a year-only value - and **not adjusted again**. | `01_studypop.R`, `dateofdeath_init` -> `death_dt_preliminary` -> `dthdt` |
| **RP2** | `FUED` is the **death date where one exists**, and the last recorded activity date otherwise. Not the earlier of the two. | `01_studypop.R`, `fued = coalesce(dthdt, fu_enddt_preliminary)` |
| **RP3** | Both are derived **once per patient**, before any cohort is assigned and before any index date exists. | stage table `enh_pros_pano_pt_fu_death_tbl`, built ahead of the cohort loop; `03_clinical.R` joins it |
| **RP4** | A patient whose index date falls after their death date is excluded **from that cohort only**. | `index_lot_cohort()` in `01_studypop.R` |

**Why RP2 is not a minimum.** The first message of the ruling defined `FUED` as
the earlier of the death date and the last activity date. A clarification the
same day withdrew that, because a death recorded after the last activity would
then fall outside follow-up and an overall-survival analysis would drop the
event. A known death is the end of follow-up however stale the activity record.
The worked example was a death on 15 July 2025 against a last activity of
20 May 2025: under the minimum `FUED` was 20 May and the death was invisible;
under RP2 `FUED` is 15 July and the event is inside follow-up.

**Three behaviours the specification asked for are withdrawn by RP1**, labelled
**W1-W3**. Each has a different guard, and two of them cannot be seen from the
delivered columns at all:

| | Withdrawn behaviour | What would catch its return |
|---|---|---|
| **W1** | Pushing a year-only death to 31 December when the index fell after 15 July. It needed the index date, so RP3 alone makes it impossible. | Only a source re-derivation of the death date. No comparison of delivered columns can see it |
| **W2** | Promoting `DEATH_DT_preliminary` to month end when the death shared `FU_ENDDT_preliminary`'s month. | The same source re-derivation, for the same reason |
| **W3** | Promoting `DTHDT` to the last day of the month. | A comparison of `DTHDT` with `DEATH_DT_preliminary`, which the ruling makes equal |

W1 and W2 both acted on `DEATH_DT_preliminary` *before* `DTHDT` was set, so
their return leaves the two delivered columns equal and every gate green. C21 is
the only automated guard on either; treat a C21 mismatch as seriously as a
failed gate.

The specification's own cascade sat at 5B.ClinChars rows 88-93. Read the two
together - those rows are what the build did until 2026-09-11:

| Row | Column | What the ruling leaves |
|---|---|---|
| 88 | interim dates kept for the derivation | unchanged |
| 89 | `FU_ENDDT_preliminary` - latest of four activity dates | unchanged |
| 90 | `DATEOFDEATH` - two documented shapes, month-and-year and year-only | unchanged; any other length is NULL (Q66) |
| 91 | `DEATH_DT_preliminary` | the imputation only; W1 and W2 withdrawn |
| 92 | `DTHDT` | equal to `DEATH_DT_preliminary`; W3 withdrawn |
| 93 | `FUED` | `COALESCE(DTHDT, FU_ENDDT_preliminary)`; the clamp withdrawn |

Row numbers are as the build cites them, and are still to be confirmed against
the workbook.

**Provenance of the ruling.** It arrived as two messages on the thread *"Followup
End date alignment across Data Products"*, 2026-09-11. What this repository holds
is a hand transcription with no sender identities, headers, export or hash, so it
cannot prove what was sent. That transcription was accepted as the record for
this cut by the data product owner on 2026-09-12, knowingly and in writing. It is
not authoritative, and the acceptance does not carry to the next cut.

### The ruling, transcribed

Two messages, the same day, on the thread *"Followup End date alignment across
Data Products"*. The second supersedes point 2 of the first. The wording is the
study team's, not ours, and this is a hand copy - see the provenance note above.

From the data product owner to the study team, 2026-09-11, summarising a call
held that morning.

> I'm summarizing the discussion points from our call earlier today. Please
> review and let me know if I missed anything or if my understanding is
> incorrect.
>
> 1. Per Flatiron's recommendation, death date will be imputed to the middle of
>    the month (or middle of the year, where only year-level granularity is
>    available), with no further adjustments applied.
>
> 2. Follow-up end date is defined as the earlier of the death date and the last
>    activity date. Below is an example.
>
>    | Raw DateofDeath | Death_dt  | last_act_dt | FUED      |
>    |-----------------|-----------|-------------|-----------|
>    | Jan-25          | 15-Jan-25 | 20-May-25   | 15-Jan-25 |
>    | 2025            | 15-Jul-25 | 20-May-25   | 20-May-25 |
>
> 3. Both death date and follow-up end date will be derived at the patient level
>    prior to cohort assignment and index date determination.
>
> 4. Patients whose index date falls after their death date will be excluded
>    from that specific cohort only.
>    Example: a patient may qualify for the Overall, L1, and L2 cohorts (index
>    dates preceding death date) while being excluded from the L3 cohort if the
>    L3 start date falls after their death date.
>    Edge case callout: a patient may be excluded from all cohorts entirely if
>    their index date for the Overall cohort (diagnosis date) falls after their
>    death date.
>
> Action Items:
> Pratyk to share worked examples comparing death date and follow-up end date
> assignment under the current rules vs. the previous rules, to illustrate the
> impact of the change.

**Clarification - supersedes point 2 above.**

Reply from the study statistician, later the same day.

> Thanks for the summary. For clarification, in the example you shared, in an OS
> analysis what would the time and event indicator be for this patient? If the
> patient died on July 15, 2025, but was derived to have a FUED of May 20, 2025,
> would the death event on July 15 2025 still be counted in the analysis? Or
> would it be excluded because it comes after the FUED? The event should not be
> excluded. Rather than specifying FUED as the minimum of the two, it would be
> more appropriate to have FUED be the death date when available, and the last
> activity in the absence of death.

**Effect on the worked table.** The clarification reverses its second row. Under
the minimum, a year-only death of `2025` against a last activity of 20-May-25
gave FUED = 20-May-25 and the July death fell outside follow-up. Under the
clarification it gives **FUED = 15-Jul-25**, and the death event is inside
follow-up where an OS analysis can count it. The first row is unchanged, because
there the death is already the earlier of the two.

### What the ruling does not say

Recorded here because each is a live limitation of a delivered value, not a
historical note.

- It removes the index floor on `FUED` as a consequence of RP3 - a patient-level
  value has no index date to be floored against - but says nothing about a
  patient whose last activity precedes their index date. **Their `FUED` precedes
  their index, and `FUDUR`, `OS` and `TTNT` can be negative.** Register Q83,
  open.
- It does not say what `FUED` should be for a patient with neither a death date
  nor any recorded activity. `COALESCE` of two nulls is null, so **`FUED` and
  `FUDUR` are null** for them - newly possible, since the old floor guaranteed a
  value.
- RP4 says "falls after their death date". Implemented strictly: an index date
  **equal** to the death date is kept. The worked examples do not cover equality.
- An unparseable `DATEOFDEATH` yields a null death date (Q66), which cannot be
  compared with an index date, so RP4 silently cannot fire for that patient.
  A source gate counts them and must read zero before a build. Measured
  2026-09-12: **zero** - no such value exists in this cut.

### What this changed in the delivered values

| Column | Effect |
|---|---|
| `DTHDT` | Equal to `DEATH_DT_preliminary` on every row now. Month-granular deaths move up to 16 days **earlier** than before. |
| `FUED` | The death date wherever one exists, so it can now exceed `MAXINDEX`, precede the index date, or be null. |
| `FUDUR` | `DATEDIFF(FUED, INDEXDT) + 1`, so it can be zero or negative - only for a patient with no death date. |
| `DTH_BEFORE_FUED` | Unreachable, and delivered as a **constant 0**. With a death date `FUED` *is* `DTHDT`; without one `DTHDT` is null. It is kept because it is one of the 190 contracted columns, and it is no longer informative. |
| `OS`, `TTNT`, `PFS` | The null that `DTH_BEFORE_FUED` used to trigger is unreachable. The death branches cannot go negative, because `DTHDT >= INDEXDT` after the exclusion. The censored branches read `FUED` and can. |
| `CSF_FU` | Its window is bounded at `FUED`, so it moves **both ways**: wider for a patient who died after their last activity, narrower for one whose month-granular death used to be promoted to month end. Both are legitimate. |
| `DTHFUFL` | Reads the two *preliminary* dates, so its inputs moved while its value should not flip. |
| Cohort counts | Every cohort falls. Measured from source 2026-09-12: 196,549 / 133,299 / 78,635 / 50,327 / 28,865 / 16,007 / 8,582 - down 3,142 cohort memberships in total, every cohort between 0.35% and 0.73%. Accepted by the owner on 2026-09-12; the delivered table has still to reproduce them. |

## 8. Assumptions and decisions

Eighty-four rows. Each one is a place where the specification is wrong, silent,
or contradicts itself, and a choice had to be made.

**Before you read a delivered number as final, look its variable up here.** If
it appears, the value depends on a choice and not only on the specification.

`RP1`-`RP4` and `W1`-`W3`, cited in the Q82 rows and several rows they touched,
are defined in section 3.

**Decision precedence (owner ruling, 2026-08-09).** Where an issue has no clear
answer: (1) the specification answers - follow it, even over the 202603
implementation; (2) the specification is silent - follow 202603 and record the
match; (3) neither - keep the behaviour as built and record it. Every row carries
a "202603" note saying what matched, what the specification overrode, or why no
prior surface existed.

- **60 change a delivered value.** These are the ones that matter.
- **9 change a column name, or which columns ship.**
- **15 change nothing.** Recorded so nobody re-opens them.

**84 rows, 82 distinct questions.** Two are duplicates - the same question asked
and answered twice - kept in place because their ids are cited in code and
commits. Two more, Q31 and Q32, are not independent decisions but Q50's residual
convention applied to a named variable; they stay so a lookup on `STAGEN` or
`PRACTICN` finds something.

**`QC evidence` is a citation, not a result.** Many rows read `PENDING`: the
build ran on 2026-08-08, but the check naming that row has not run against the
delivered table since, or at all. A row that does not read `PENDING` rests on a
check that has run, or on a source query - which predicts what the build must
produce rather than confirming what it did.


A citation is also not a result. Many rows below read `PENDING` under **QC
evidence**: the build ran on 2026-08-08, but the check naming those rows has
not yet run against the delivered table. The rows that do not read PENDING
rest on the checks that have run, or on SOURCE queries, which predict what the
build must produce rather than confirming what it did.

### Index

| ID | Variable | Affects | Approved by | Status | Commit |
|---|---|---|---|---|---|
| Q01 | MAXINDEX | values | Onkar Kshirsagar | RESOLVED | 23a9294 (settling commit; 3 commits name this row, first 3c7d5e4) |
| Q02 | TTNTFL | columns | Onkar Kshirsagar | RESOLVED | 6a69469 (settling commit; 4 commits name this row, first f95d6e6) |
| Q03 | HRR_INDEX_TEST / BRCA_INDEX_TEST | values | Onkar Kshirsagar | RESOLVED | 364732b (settling commit; 3 commits name this row, first 2660f0a) |
| Q04 | HRR_INDEX / BRCA_INDEX | values | Onkar Kshirsagar | RESOLVED | 1cfca36 (settling commit; 2 commits name this row, first f95d6e6) |
| Q05 | HRR_INDEX | values | Onkar Kshirsagar | RESOLVED | c3ad5d1 (settling commit; 9 commits name this row, first 3c7d5e4) |
| Q06 | LOTN | columns | Onkar Kshirsagar | RESOLVED - LOTN_MHSPC family added | 6166362 (settling commit; 2 commits name this row, first 3100f65) |
| Q07 | LABPLA / LABBIL | values | Onkar Kshirsagar | RESOLVED - LABBIL limb only; LABPLA limb withdrawn (Q55) | b763ddb (settling commit; 6 commits name this row, first 75eec0f) |
| Q08 | PRIOR_DOCITAXEL / PRIOR+ABIRATERONE | columns | Onkar Kshirsagar | RESOLVED | 84a53a1 (settling commit; 3 commits name this row, first a3a68a3) |
| Q09 | INITYR | values | Onkar Kshirsagar | RESOLVED | 6a69469 (settling commit; 5 commits name this row, first e433717) |
| Q10 | TINTCRPCHSPC | values | Onkar Kshirsagar | RESOLVED | 1cfca36 (settling commit; 7 commits name this row, first 3c7d5e4) |
| Q11 | COHORTU | values | Onkar Kshirsagar | RESOLVED | 5f67a2c (settling commit; 9 commits name this row, first a050293) |
| Q12 | LABLYMDT | values | Onkar Kshirsagar | RESOLVED | 1aa2fdb (settling commit; 4 commits name this row, first e433717) |
| Q13 | All labs | values | Onkar Kshirsagar | RESOLVED - note #5 authoritative; LABNEUV row is an erratum (E16) | a42d03d (settling commit; 8 commits name this row, first f95d6e6) |
| Q14 | Output naming | columns | Onkar Kshirsagar | RESOLVED - name confirmed by the owner; the defining spec page remains unsupplied | 1aa2fdb (settling commit; 5 commits name this row, first f95d6e6) |
| Q15 | t_allprostate_pats | none | Onkar Kshirsagar | RESOLVED | 1aa2fdb (settling commit; 2 commits name this row, first 23a9294) |
| Q16 | max_drug_ep_abstracted_dt | values | Onkar Kshirsagar | RESOLVED - keep, reopened 2026-09-12 as ship-or-drop and **CLOSED the same day: keep confirmed**. Dropping takes the contract to 189 and breaks existing consumers | 201c516 (settling commit; 4 commits name this row, first efe51d0) |
| Q17 | LOT4CATN -> LOT4CATN_MCRPC | columns | Onkar Kshirsagar | RESOLVED | 84a53a1 (settling commit; 4 commits name this row, first 906b68b) |
| Q18 | BIOMARKERSTATUS | values | Onkar Kshirsagar | RESOLVED | 601123a (settling commit; 4 commits name this row, first 75eec0f) |
| Q19 | COHORTU | values | Onkar Kshirsagar | DUPLICATE of Q11 - read Q11 | 84a53a1 (settling commit; 7 commits name this row, first a050293) |
| Q20 | HRR/BRCA window | values | Onkar Kshirsagar | RESOLVED | 1aa2fdb (settling commit; 5 commits name this row, first a050293) |
| Q21 | min_vst_dt / min_vsttelemed_dt / min_medord_dt | columns | Onkar Kshirsagar | RESOLVED | bc2668e (settling commit; 6 commits name this row, first f95d6e6) |
| Q22 | BIRTHYEAR | columns | Onkar Kshirsagar | RESOLVED | eeeb06d (settling commit; 6 commits name this row, first 3c7d5e4) |
| Q23 | ECOGN | values | Onkar Kshirsagar | RESOLVED - corrected to the spec's six categories; was a real divergence | 19be531 (settling commit; 7 commits name this row, first 8661459) |
| Q24 | NEW_LOT_N | values | Onkar Kshirsagar | RESOLVED | 63cd73a (settling commit; 9 commits name this row, first 75eec0f) |
| Q25 | LABALB | values | Onkar Kshirsagar | RESOLVED - g/L filter restored; scale confirmed g/L | f47d4eb (settling commit; 18 commits name this row, first f344808) |
| Q26 | PSMA_SCANRESULT | values | Onkar Kshirsagar | RESOLVED | 8d70a96 (settling commit; 8 commits name this row, first f344808) |
| Q27 | Publication step | none | Onkar Kshirsagar | **REVERSED 2026-09-12, DEFERRED to the next cut** with Q43 - a promotion step is to be built and is not in 202606, which ships live-on-write. Accepted risk; see section 6 | 63cd73a (settling commit; 11 commits name this row, first 6faece8) |
| Q28 | HRR_INDEX / BRCA_INDEX | columns | Onkar Kshirsagar | RESOLVED | 5f67a2c (settling commit; 5 commits name this row, first f310ad3) |
| Q29 | HRR_INDEX / BRCA_INDEX | values | Onkar Kshirsagar | RESOLVED | eeeb06d (settling commit; 16 commits name this row, first 87f07d2) |
| Q30 | ECOG (treated cohorts) | values | Onkar Kshirsagar | RESOLVED | 6a69469 (settling commit; 5 commits name this row, first 1334f00) |
| Q31 | STAGE / STAGEN | values | Onkar Kshirsagar | RESOLVED - the Q50 residual convention, applied to STAGEN | 63cd73a (settling commit; 6 commits name this row, first d54395b) |
| Q32 | PRACTIC / PRACTICN | values | Onkar Kshirsagar | RESOLVED - the Q50 residual convention, applied to PRACTICN | eeeb06d (settling commit; 6 commits name this row, first 1cfca36) |
| Q33 | FUED / DTHDT / PSMA_SCANDT | values | Onkar Kshirsagar | RESOLVED | 646dc88 (settling commit; 7 commits name this row, first 87f07d2) |
| Q34 | PFSDT / PFS | values | Onkar Kshirsagar | RESOLVED - spec says no action; quantified by X03/X03b | 56dc86b (settling commit; 18 commits name this row, first 8661459) |
| Q35 | PSA50_6MO / PSAL6MO / PSA50_12MO / PSAL12MO | values | Onkar Kshirsagar | RESOLVED | 646dc88 (settling commit; 6 commits name this row, first f59308c) |
| Q36 | VIS120 | values | Onkar Kshirsagar | RESOLVED | 646dc88 (settling commit; 9 commits name this row, first 87f07d2) |
| Q37 | HRR_INDEX / BRCA_INDEX | values | Onkar Kshirsagar | RESOLVED | eeeb06d (settling commit; 10 commits name this row, first 1334f00) |
| Q38 | Index date / cohort membership | values | Onkar Kshirsagar | RESOLVED - accepted and documented; 10,148 patients affected post-exclusion, 10,170 before it | 74fbed9 (settling commit; 15 commits name this row, first efe51d0) |
| Q39 | CSF_FU | values | Onkar Kshirsagar | RESOLVED | 76a564c (settling commit; 5 commits name this row, first d72c197) |
| Q40 | FU_ENDDT_preliminary / FUED | values | Onkar Kshirsagar | RESOLVED | a42d03d (settling commit; 6 commits name this row, first a3a68a3) |
| Q41 | PFSDT / PFSFL | values | Onkar Kshirsagar | RESOLVED - build matches the spec verbatim | 63cd73a (settling commit; 8 commits name this row, first f95d6e6) |
| Q42 | TTNT / TTNTFL | values | Onkar Kshirsagar | RESOLVED - closed on evidence, both limbs (Q42 within setting, Q42b cross setting) | d13de7c (settling commit; 18 commits name this row, first efe51d0) |
| Q43 | Build identification | values | Onkar Kshirsagar | **REVERSED 2026-09-12, DEFERRED to the next cut** - build identity in the table AND a promotion step are both to be built, and neither is in 202606. This cut ships with no provenance in the table: accepted risk, see section 6 | 6a69469 (settling commit; 13 commits name this row, first efe51d0) |
| Q44 | HRR_INDEX gene inventory | values | Onkar Kshirsagar | RESOLVED | 0c1f1d8 (settling commit; 13 commits name this row, first efe51d0) |
| Q45 | FUED | values | Onkar Kshirsagar | SUPERSEDED 2026-09-11 by Q82 - the INDEXDT clamp this errata corrected is gone entirely | 74fbed9 (settling commit; 9 commits name this row, first d23382c) |
| Q46 | PRIOR_DOCITAXEL / PRIOR+ABIRATERONE | columns | Onkar Kshirsagar | DUPLICATE of Q08 - read Q08 | 84a53a1 (settling commit; 5 commits name this row, first 7891b9f) |
| Q47 | OS | values | Onkar Kshirsagar | RESOLVED | 5f67a2c (settling commit; 7 commits name this row, first f59308c) |
| Q48 | COHORT | values | Onkar Kshirsagar | RESOLVED | 646dc88 (settling commit; 6 commits name this row, first e95964e) |
| Q49 | CSD | values | Onkar Kshirsagar | RESOLVED | bc2668e (settling commit; 6 commits name this row, first 906b68b) |
| Q50 | REGION1 / REGION1N / PRACTIC / PRACTICN | values | Onkar Kshirsagar | RESOLVED | 9dde5aa (settling commit; 10 commits name this row, first d54395b) |
| Q51 | SES | values | Onkar Kshirsagar | RESOLVED - fixed in code | 63cd73a (settling commit; 6 commits name this row, first d54395b) |
| Q52 | INDEXDT (Overall cohorts) / MHSPCDD / MCRPCDD | values | Onkar Kshirsagar | RESOLVED | 5582e23 (settling commit; 14 commits name this row, first 7c5c25c) |
| Q53 | DTHFL | values | Onkar Kshirsagar | RESOLVED - spec text is complete SAS; build matches it exactly | 63cd73a (settling commit; 4 commits name this row, first 8eee68c) |
| Q54 | FU_ENDDT_preliminary | none | Onkar Kshirsagar | RESOLVED - confirmed a colorectal copy-paste relic (E15) | 6a69469 (settling commit; 5 commits name this row, first bef56f4) |
| Q55 | LABPLA | none | Onkar Kshirsagar | RESOLVED - no defect; Q07 LABPLA limb withdrawn | 6166362 (settling commit; 4 commits name this row, first d4c76c4) |
| Q56 | ECOG (cohorts 3-7) | none | Onkar Kshirsagar | RESOLVED - measured; the window drops zero rows | 7ac042f (settling commit; 5 commits name this row, first b9e6e36) |
| Q57 | DTHFUFL | values | Onkar Kshirsagar | RESOLVED - recomputed on the preliminary dates; limitation accepted | eeeb06d (settling commit; 11 commits name this row, first b9e6e36) |
| Q58 | all LAB* and BP | values | Onkar Kshirsagar | RESOLVED - spec followed literally; Unknown is no longer a quality signal | 364732b (settling commit; 9 commits name this row, first b9e6e36) |
| Q59 | PSA50_6MO / PSA50_12MO | none | Onkar Kshirsagar | RESOLVED - measured; guard is value-neutral and retained | 2e1b6f5 (settling commit; 7 commits name this row, first b9e6e36) |
| Q60 | PRIOR_NHA_ADT | values | Onkar Kshirsagar | RESOLVED - definition wins; label is an erratum (E17) | a42d03d (settling commit; 5 commits name this row, first b9e6e36) |
| Q61 | GLEASONN | none | Onkar Kshirsagar | RESOLVED - three categories confirmed; 3 is a value, not a sentinel | 63cd73a (settling commit; 4 commits name this row, first b9e6e36) |
| Q62 | PSA_INDEX | values | Onkar Kshirsagar | RESOLVED - build follows the definition; note is an erratum (E18) | f0d7def (settling commit; 3 commits name this row, first b22142e) |
| Q63 | all LAB* Present criteria | none | Onkar Kshirsagar | RESOLVED - closed on evidence (zero occurrences) | a81f663 (settling commit; 3 commits name this row, first b22142e) |
| Q64 | LOT1_MCRPC / LOT2_MCRPC / LOT3_MCRPC / LOT4_MCRPC / LOT1_MHSPC / LOT2_MHSPC | values | Onkar Kshirsagar | RESOLVED - NULL per the spec definition; the None literal is withdrawn | 5582e23 (settling commit; 8 commits name this row, first 0aa917e) |
| Q65 | LOT1CAT_* category 12, PRIOR_PARP | values | Onkar Kshirsagar | RESOLVED - separators unified and the format contract is now gated (B13) | bc2668e (settling commit; 11 commits name this row, first 0aa917e) |
| Q66 | DATEOFDEATH / DEATH_DT_preliminary / DTHDT / DTHFL | values | Onkar Kshirsagar | RESOLVED - spec-literal; sized at source and, since Q82, gated there | 74fbed9 (settling commit; 15 commits name this row, first 0aa917e) |
| Q67 | BP / BPSYS / BPDIA | values | Onkar Kshirsagar | RESOLVED - spec implemented; integrality now required | e2d2b13 (settling commit; 7 commits name this row, first 364732b) |
| Q68 | WEIGHT / HEIGHT / BMI / BSA | values | Onkar Kshirsagar | RESOLVED - spec-literal record filter; division guards retained separately | 6a69469 (settling commit; 17 commits name this row, first 364732b) |
| Q69 | LABHEM / LABHEMV / LABHEMDT | none | Onkar Kshirsagar | RESOLVED - trimmed comparison; the spec cell is erratum E20 | a42d03d (settling commit; 8 commits name this row, first 364732b) |
| Q70 | MCRPCDDYR / MHSPCDDYR / MPCDDYR / INITYR, PSA50_6MO / PSAL6MO / PSA50_12MO / PSAL12MO, BMIGR1 | none | Onkar Kshirsagar | RESOLVED - build types confirmed; contract pinned once the captured types are reviewed and committed | 160850f (settling commit; 11 commits name this row, first 364732b) |
| Q71 | ECOG / ECOGN | values | Onkar Kshirsagar | RESOLVED - clamped to the six documented categories | 6a69469 (settling commit; 6 commits name this row, first 14deccc) |
| Q72 | WEIGHT / HEIGHT / BMI / BSA, HRR_INDEX / BRCA_INDEX, LOT1CAT_MCRPC | values | Onkar Kshirsagar | RESOLVED - both group on a normalised name | 646dc88 (settling commit; 8 commits name this row, first 14deccc) |
| Q73 | LOT1_MCRPC and siblings, LOT1CAT_MCRPC and siblings | values | Onkar Kshirsagar | RESOLVED - sized 2026-08-09: zero NULL-named lines in this cut | 5582e23 (settling commit; 9 commits name this row, first 14deccc) |
| Q74 | AGEGR1 | values | Onkar Kshirsagar | RESOLVED - the label that pairs with AGEGR1N's 99 | d13de7c (settling commit; 7 commits name this row, first 6aa35e0) |
| Q75 | GLEASON / GLEASONN | values | Onkar Kshirsagar | RESOLVED - match both spellings, source wins | d13de7c (settling commit; 5 commits name this row, first 6aa35e0) |
| Q76 | LOT uniqueness key | none | Onkar Kshirsagar | RESOLVED - the printed key cannot be built in this cut | d13de7c (settling commit; 5 commits name this row, first 6aa35e0) |
| Q77 | DATAV / source tables | values | Onkar Kshirsagar | RESOLVED - the cut is June 2026 | 646dc88 (settling commit; 4 commits name this row, first 6aa35e0) |
| Q78 | B15 / B16 / B17 | none | Onkar Kshirsagar | RESOLVED - approved as build preconditions | f9f5d93 (settling commit; 8 commits name this row, first 6aa35e0) |
| Q79 | PSA6MO / PSA50_6MO / PSAL6MO | none | Onkar Kshirsagar | RESOLVED - no change; the variable's own row governs | 57868bd (settling commit; 5 commits name this row, first 546f6a1) |
| Q80 | LABNEU-LABLYM (all ten analytes) | none | Onkar Kshirsagar | RESOLVED - case-insensitive TestBaseName match confirmed value-neutral | 74c8421 (settling commit; 3 commits name this row, first 44fda70) |
| Q81 | CSD (cohorts 3-7) | none | Onkar Kshirsagar | RESOLVED - latent NULL path unreachable this cut; explicit else at next refresh | 5582e23 (settling commit; 4 commits name this row, first 44fda70) |
| Q82 | DTHDT / FUED / cohort membership | values | Onkar Kshirsagar | RESOLVED - 2026-09-11 ruling implemented as written, RP1-RP4 with W1-W3 withdrawn; **new cohort counts accepted 2026-09-12, and V26's frozen baseline is to be refreshed to them** | 10ec9a6 (settling commit; recorded by hand - make_traceability.R halts on the pre-existing Q04/Q10 gap; first e1bd419) |
| Q83 | FUDUR / OS / TTNT where follow-up precedes the index | values | Onkar Kshirsagar | OPEN - delivered as it falls out; the six sizing figures need the rebuild and are not yet measured; deliver/floor/null/exclude ruling pending | 10ec9a6 (settling commit; recorded by hand - see Q82; first a6e95c2) |
| Q84 | LABALBV delivered value plausibility | values | UNASSIGNED - needs a named SME | OPEN - the UNIT is settled as g/L (Q25); the VALUES are not. Sized; no ruling exists and Q68 does not cover it | recorded by hand, 2026-09-12 |

### Detail

### Q01 - MAXINDEX

- **Spec reference:** 3.Data Prep r13
- **Spec says:** Printed as 4/31/2026, not a calendar date
- **We do:** Using 2026-04-30 (max date observed in source tables)
- **Decision:** MAXINDEX = 2026-04-30.
- **Why:** Spec prints the impossible 4/31/2026; a source check shows all six source tables max at 2026-04-30. RESOLVED 2026-08-07. The spec prints 4/31/2026, which is not a date - April has 30 days. 2026-04-30 is both the last valid day of that month and the latest date observed across the source tables. No code change; spec erratum E14.
- **Evidence:** Measured at source 2026-08: lot.startdate, visit, telemedicine, drugepisode, prog.lastclinicnote and psa.resultdate ALL max at 2026-04-30
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** not comparable. The 202603 window came from loose site globals; the 4/31 print is new with this spec.

### Q02 - TTNTFL

- **Spec reference:** 6.Outcomes
- **Spec says:** Struck out, but the active TTNT definition reads it
- **We do:** Derived internally; not emitted
- **Decision:** Build's reading confirmed; correct the spec, not the code.
- **Why:** APPROVED 2026-08-07 as part of the nine-item spec errata block (this file). The build's reading is confirmed correct and the SPEC is what gets corrected; no code change. Approved as a block because in each case the literal spec text is self-evidently not the intent - most starkly Q45, which taken literally clamps FUED to the index date for every patient with follow-up and would zero OS, TTNT, PFS and FUDUR across the study.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** 202603 built and DELIVERED ttntfl. This spec strikes it, so it is derived internally for TTNT and dropped.

### Q03 - HRR_INDEX_TEST / BRCA_INDEX_TEST

- **Spec reference:** 5B.ClinChars r72/r76
- **Spec says:** No test-type column exists on the biomarker table
- **We do:** Hard-coded 'Unknown' / 7 for every row
- **Decision:** No differentiation by test type. HRR_INDEX_TEST / BRCA_INDEX_TEST stay 'Unknown' (7).
- **Why:** RESOLVED. SME ruled that test type is not differentiated. The source has no test-type column, so the delivered value stays hard-coded 'Unknown'/7, and test type is not used to choose the winning test either (Q37). The columns remain in the ADS as constants; the null sweep waives them on that basis. Recorded from an SME consultation relayed by the data product owner on 2026-08-07; the SME is not named in the relay, so name them here before this is used as a release record.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** no prior surface - 202603 never read the biomarker table (Q37). No test-type column existed anywhere.

### Q04 - HRR_INDEX / BRCA_INDEX

- **Spec reference:** 5B.ClinChars r70/r74
- **Spec says:** Spec says max(SPECIMENRECEIVEDDATE, RESULTDATE); table has SPECIMENCOLLECTEDDATE
- **We do:** Using max(specimencollecteddate resultdate)
- **Decision:** Build's reading confirmed; correct the spec, not the code.
- **Why:** APPROVED 2026-08-07 as part of the nine-item spec errata block (this file). The build's reading is confirmed correct and the SPEC is what gets corrected; no code change. Approved as a block because in each case the literal spec text is self-evidently not the intent - most starkly Q45, which taken literally clamps FUED to the index date for every patient with follow-up and would zero OS, TTNT, PFS and FUDUR across the study.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** no prior surface (Q37). Neither date column was ever read before.

### Q05 - HRR_INDEX

- **Spec reference:** 5B.ClinChars r70/r74
- **Spec says:** Spec matches BIOMARKERNAME='HRR'; the column holds gene symbols. Which genes constitute HRR?
- **We do:** Three modes via RDAP_HRR_PANEL: 'flatiron_all' (default, all 19 genes in the table), 'olaparib_label' (14), 'talapro2' (12). The winning test date is ONE date per patient - the biomarker test CLOSEST to index, chosen over ALL biomarker tests regardless of gene or test type, and shared by the HRR and BRCA calls (Q37). Status is then resolved within each gene on that shared date and rolled up across genes (Q29). A NON-DEFAULT panel writes to a study-specific table name so a panel build cannot overwrite the governed one.
- **Decision:** HRR = the 19 approved gene symbols, frozen in code.
- **Why:** General-purpose RWDP feeding many studies, not a single asset's evidence package. For a data product the principle is capture broadly and let each study narrow: HRR_INDEX is a collapsed patient-level status with no gene-level column in the ADS, so a narrower panel cannot be widened downstream without rebuilding from source. The table is exactly the union of the olaparib-label (14) and TALAPRO-2 (12) panels, so 'all genes' is a defensible definition rather than a catch-all, and flatiron_all names its nineteen symbols explicitly (Q44), so the panel cannot drift with the table's contents. D5b: the three options differ by at most 6.3% of positives. Marked 'for now' - revisit if this ADS is later scoped to a specific asset (see Q28). RESOLVED 2026-08-07.
- **Evidence:** Measured at source 2026-08: exactly 19 distinct genes, precisely the union of the FDA olaparib mCRPC label panel (14) and the TALAPRO-2 panel (12). Nothing outside either panel; all symbols canonical, no aliases. PPP2R2A - the sole PROfound gene the FDA label omits - is absent from the data. D5b: HRR-positive patients = 16011 flatiron_all / 15453 talapro2 / 14999 olaparib_label / 5715 BRCA-only. The three HRR options differ by at most 1012 patients (6.3% of positives), so the choice is minor. TEXT CORRECTED 2026-08-07: this row previously said the winning date was resolved PER GENE. That described the superseded algorithm and contradicted both Q37 and the code. A reviewer reading this row could have approved an algorithm the build does not run.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **Wording corrected 2026-08-08, reconciled 2026-08-09.** Earlier text here described the pre-Q44 world, where `flatiron_all` meant every gene in the table with no list to go stale. Q44 froze the nineteen named symbols and the code has worked that way since; the rationale above now says so directly. Read Q05 as 'which genes count as HRR' and Q44 as 'freeze them, do not track the table'. Two facets, one implementation, no contradiction.
- **202603:** no prior surface (Q37). The gene-list question starts with this cut.

### Q06 - LOTN

- **Spec reference:** 5C.TreatVars r2
- **Spec says:** Note asks 'Do separate for mCRPC and mHSPC?' - unresolved
- **We do:** LOTN / LOTNGR1 / LOTNGR1N count mCRPC lines, as the spec defines. LOTN_MHSPC / LOTNGR1_MHSPC / LOTNGR1N_MHSPC count mHSPC lines, generated by the same function so the banding cannot drift between the two settings. Contract is now 190 columns.
- **Decision:** Yes, separate. Deliver an mHSPC line count alongside the mCRPC one.
- **Why:** RESOLVED 2026-08-07. The spec asked itself this question in row 2's Additional Notes and never answered it; the owner answered yes. WHY IT MATTERED: mHSPC precedes mCRPC and not every patient progresses, so a patient in cohort 1 or cohort 3 who is on treatment but still hormone-sensitive has no mCRPC lines and reads LOTN = 0. Cohort 3 alone holds 79,051 patients. Without the mHSPC pair that line count was simply absent from the ADS - not merely undocumented - and LOTN = 0 reads as 'untreated' to anyone who does not know the definition. Documenting the caveat could warn about the gap but could not fill it. NAMING ASYMMETRY, deliberate: the unsuffixed LOTN still means mCRPC, because that is what the spec names it. Only the new pair carries a suffix. Renaming LOTN to LOTN_MCRPC would read better but would break a name the spec gets right - unlike the three corrected under Q08/Q46/Q17, which were malformed. Flagged here so the asymmetry is a recorded choice rather than an oversight.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** 202603 had one unsuffixed LOTN over mCRPC-only numbering. The per-setting split comes from this spec.

### Q07 - LABPLA / LABBIL

- **Spec reference:** 5B.ClinChars r20/r29
- **Spec says:** LABPLA Present clause says testbasename='hemoglobin'; LABBIL unit says 10*9/L
- **We do:** Coded to the clinically intended analyte and unit
- **Decision:** LABBIL reads bilirubin at mg/dL - the spec's '10*9/L' unit filter is a slip. LABPLA: NO DEFECT (see Q55) - the spec says 'platelets' and the build reads platelets.
- **Why:** PARTIALLY WITHDRAWN 2026-08-08 (see Q55). The LABBIL limb STANDS: the spec's LABBIL unit filter says 10*9/L while its label says mg/dL, corroborated by the spec text and by the data (bilirubin populated at mg/dL, 4,923,058 rows). Coding it literally would have emptied the variable. The LABPLA limb is WITHDRAWN: it was reported the Present clause as naming testbasename='hemoglobin'; the owner confirmed against the spec that it says 'platelets', matching its own Missing clause. There was never a slip on that row. The build filtered platelets throughout, so this was a documentation error only.
- **Evidence:** Measured at source 2026-08: bilirubin populated at mg/dL (4923058 rows); platelets populated at 10*9/L
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** no prior surface - t_lab is new. Both clause slips are defects of the 202606 sheet.

### Q08 - PRIOR_DOCITAXEL / PRIOR+ABIRATERONE

- **Spec reference:** 5C.TreatVars r40/r41
- **Spec says:** Spelling typos in the spec
- **We do:** Delivered as PRIOR_DOCETAXEL and PRIOR_ABIRATERONE. Both spec spellings corrected.
- **Decision:** Correct to PRIOR_DOCETAXEL and PRIOR_ABIRATERONE.
- **Why:** RESOLVED 2026-08-07: correct all three to clean names. Delivered as PRIOR_DOCETAXEL, PRIOR_ABIRATERONE and LOT4CATN_MCRPC. This DIVERGES from the spec's column list on purpose - the spec is what gets corrected (errata E13). The asymmetry that used to exist here is gone: the build no longer preserves one slip while fixing another. Note the consequence: any consumer already coding against PRIOR_DOCITAXEL or LOT4CATN must change, which is why this was worth ruling on before release rather than after.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **What the spec prints, in full (from Q46):** row 40 names the docetaxel flag PRIOR_DOCITAXEL - 'DOCITAXEL', misspelt - with the label 'Docitaxel received prior to index'. Row 41 names the abiraterone flag PRIOR+ABIRATERONE, with a plus sign where an underscore belongs. Both are delivered corrected: PRIOR_DOCETAXEL and PRIOR_ABIRATERONE.
- **202603:** no prior surface. 202603's taxane flags were different variables, replaced by these seven.

### Q09 - INITYR

- **Spec reference:** 5B.ClinChars r9
- **Spec says:** Definition reads Year(INITYR) - self-referential
- **We do:** Coded as Year(INIT)
- **Decision:** Build's reading confirmed; correct the spec, not the code.
- **Why:** APPROVED 2026-08-07 as part of the nine-item spec errata block (this file). The build's reading is confirmed correct and the SPEC is what gets corrected; no code change. Approved as a block because in each case the literal spec text is self-evidently not the intent - most starkly Q45, which taken literally clamps FUED to the index date for every patient with follow-up and would zero OS, TTNT, PFS and FUDUR across the study.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** matches - 202603 computed inityr = year(diagnosisdate), same shape for the other year fields.

### Q10 - TINTCRPCHSPC

- **Spec reference:** 5B.ClinChars r14
- **Spec says:** Printed formula (HSPCDate-CRPCDate) contradicts the label 'Time from HSPC to CRPC'; divisor 30.4376 vs 30.4375 elsewhere
- **We do:** (CRPCDate - HSPCDate)/30.4375, per the row's label. Single formula, no environment switch.
- **Decision:** Build's reading confirmed; correct the spec, not the code.
- **Why:** The spec row's label ('Time from HSPC to CRPC') and its printed formula (HSPCDate - CRPCDate) are opposite. Measured at source: 72543 of 73026 patients reach CRPC after HSPC, so the printed form would be negative for 99.3%. Label taken as intent, formula as a transposition slip; divisor aligned to the 30.4375 used everywhere else. The verbatim form was briefly selectable via an environment variable; that was removed once this was decided, since a switch that flips the sign of a delivered column is one more way for a run to differ from the approved definition. For the record, the formula that was REJECTED - the spec's printed form, not what the build computes - is (HSPCDate - CRPCDate)/30.4376. APPROVED 2026-08-07 as part of the nine-item spec errata block (this file). The build's reading is confirmed correct and the SPEC is what gets corrected; no code change. Approved as a block because in each case the literal spec text is self-evidently not the intent - most starkly Q45, which taken literally clamps FUED to the index date for every patient with follow-up and would zero OS, TTNT, PFS and FUDUR across the study.
- **Evidence:** Measured at source 2026-08: crpc_after_hspc 72543, crpc_before_hspc 50, same_day 433 of 73026 - the printed formula is negative for 99.3% of patients Direct read of the spec 2026-08-07 confirms the printed formula is (HSPCDate - CRPCDate)/30.4376 while the label reads 'Time from HSPC to CRPC'. Note the divisor on this row alone is 30.4376; every other months conversion on the sheet, and 3.Data Prep Section C, uses 30.4375. The build uses 30.4375 throughout. The 1e-4 difference is immaterial to any delivered value but it is one more sign this row was typed rather than derived, which is the argument for trusting its label over its formula.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** no prior surface - no HSPC dates existed in 202603.

### Q11 - COHORTU

- **Spec reference:** 4.StudyPop r13
- **Spec says:** Definition inverts treated/untreated and never assigns 'Treated mCRPC'
- **We do:** Implemented the coherent reading (has a line in setting -> Treated)
- **Decision:** Populate all seven cohorts; treated = has a line in that setting.
- **Why:** RESOLVED 2026-08-07: populate all seven cohorts. Cohorts 3-7 are treated BY CONSTRUCTION - they are defined by having a line of therapy in that setting - so they resolve to 'Treated <setting>' and the value is constant within each. It is therefore redundant with COHORTN, but a consumer filtering COHORTU='Treated mCRPC' gets every treated mCRPC patient rather than only those inside the Overall cohort, which is the more useful behaviour. No code change: the build already does this. The spec row is wrong on two counts - it inverts treated/untreated and never assigns 'Treated mCRPC' at all - so it joins the errata list as E12.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** 202603 populated COHORTU for every cohort, but its treated test used the UNFILTERED all-setting LOT table: a line in any setting read 'Treated mCRPC'. A patient whose only lines sit outside mCRPC read Treated there and Untreated here, and the coding reverses (Treated=1/Untreated=2 there, the Values order here). Recode before comparing; unsized - the per-cohort profile bounds it.

### Q12 - LABLYMDT

- **Spec reference:** 5B.ClinChars r46
- **Spec says:** Definition duplicates LABLYMV's text
- **We do:** Coded as the date
- **Decision:** Build's reading confirmed; correct the spec, not the code.
- **Why:** APPROVED 2026-08-07 as part of the nine-item spec errata block (this file). The build's reading is confirmed correct and the SPEC is what gets corrected; no code change. Approved as a block because in each case the literal spec text is self-evidently not the intent - most starkly Q45, which taken literally clamps FUED to the index date for every patient with follow-up and would zero OS, TTNT, PFS and FUDUR across the study.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** no prior surface - t_lab is new; the duplicated text is a sheet slip.

### Q13 - All labs

- **Spec reference:** 3.Data Prep sC r29
- **Spec says:** Open item: 'lowest or highest' on same-day ties
- **We do:** Per-row red-bold instructions in 5B followed (per analyte)
- **Decision:** Note #5 (the dated email quoted in Section C) is authoritative. LABNEUV's 'highest' contradicts the note it cites and is an erratum.
- **Evidence:** CLOSED 2026-08-07 on the spec. 3.Data Prep Section C row 29 leaves 'lowest or highest' open, but 5B.ClinChars states a direction on every analyte's own value row, in red bold, and all ten were read individually during the reconciliation: NEU/PLA/HEM/CRE/ALB take the LOWEST value on a tied date, BIL/AST/ALT/ALP/LYM the HIGHEST. The build matches all ten. This is a reading check, not a judgement about what the direction should be - the spec answers its own open item elsewhere. CORRECTED 2026-08-07. My closure said all ten per-analyte rows were read individually and gave NEU as LOWEST. That is wrong: the LABNEUV row reads 'take the [highest value, per note #5]'. Nine of the ten rows agree with note #5; LABNEUV is the exception AND it contradicts the very note it cites - Section C item 5 quotes a dated email from Linda giving 'Albumin, neutrophil, platelet, hemoglobin, serum creatinine - lowest'. The code uses LOWEST for neutrophils, which matches the email, matches the other nine rows' pattern, and is the clinically expected direction (the nadir is what matters for neutropenia). So the CODE is right and my REASONING was wrong - the closure said 'the per-analyte row supersedes Section C', which applied to NEU would give highest.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** no lab surface. 202603's same-day ties (ECOG, vitals) took the highest value, matching the 'highest' half; the per-analyte split is a new SME ruling.

### Q14 - Output naming

- **Spec reference:** 3.Data Prep rows 1-8
- **Spec says:** Section A of 3.Data Prep was not supplied, so the output table name is unconfirmed
- **We do:** output_table = paste0('rwdp_pros_pano_', refresh, panel_suffix), written to personal_schema = 'osk02156'. A non-default HRR panel appends a suffix so a panel build cannot overwrite the governed table.
- **Decision:** Output table is rwdp_pros_pano_2026m06, in schema osk02156.
- **Why:** RESOLVED 2026-08-07 by the data product owner, confirming the name directly. WORTH BEING PRECISE ABOUT WHAT THIS CLOSES ON: the name is confirmed by the OWNER, not verified against the spec. Section A of 3.Data Prep - the sheet that defines output naming - was never supplied and still does not exist in anything this build has seen. The name was originally inferred from convention and has now been confirmed to be the right one, which is a different and weaker basis than every other resolved row in this register, where the spec text was read. If that page later surfaces and names something else, this row reopens.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** 202603 wrote rwdp_pros_pano_v1 the same way; the new name pins the refresh.

### Q15 - t_allprostate_pats

- **Spec reference:** 5A.Demos r3
- **Spec says:** References a separate all-prostate-patients dataset
- **We do:** Out of scope for this script
- **Decision:** Out of scope for this build.
- **Why:** RESOLVED 2026-08-07. 5A.Demos Section A's header describes a SECOND deliverable - an all-prostate patients dataset 'to be used for other studies' - built from t_allprostate_pats_2026j30. That is a different source with a different refresh suffix (2026j30, not 2026m06), and this build delivers the seven-cohort ADS only. Scoped out rather than forgotten; if it is wanted it needs its own source, output and column contract.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** not in 202603 either; out of scope in both cuts.

### Q16 - max_drug_ep_abstracted_dt

- **Spec reference:** 5B.ClinChars r88
- **Spec says:** EpisodeDataSource='Abstraction' does not exist in 2026m06, so max_drug_ep_abstracted_dt ships all-null. Resolve by naming a replacement source (changes values) or dropping the column (changes the column set).
- **We do:** Filter kept as specified; resolves to NULL for all
- **Decision:** Keep the column. It is all-null in 2026m06 and both QC tests already exist.
- **Reopened and closed 2026-09-12:** reopened as ship-or-drop, and **kept** - the 2026-08-07 ruling is confirmed by Onkar Kshirsagar on 2026-09-12. A column that says nothing about every patient is a release-notes decision as well as a build one, which is why it was put to the owner a second time. Dropping it would have taken the contract to 189 columns and broken consumers already coding against it; Source checks detect the source value reappearing in a future cut, at which point the column starts carrying data with no code change.
- **Why:** RESOLVED 2026-08-07: keep the column, with QC. The QC the owner asked for is already in place at both ends, so nothing new was needed - it just was not pointed at from this row. AT SOURCE: a source check lists every distinct episodedatasource with counts, and D3 counts rows where episodedatasource='Abstraction' - currently zero. If a future cut reintroduces the value, D3 stops being zero and the column stops being all-null, which is the signal. AT OUTPUT: the null sweep waives max_drug_ep_abstracted_dt with shape 'null', meaning it expects NO values at all - so if the column ever becomes populated the sweep reports REVIEW rather than passing silently. The waiver checks the SHAPE, not just a boolean 'waived', which is what makes it a test rather than an excuse.
- **Evidence:** Measured at source 2026-08: episodedatasource is only Administrations/Unstructured/Orders - Abstraction does not exist, so max_drug_ep_abstracted_dt is NULL for every patient
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** no prior surface - the abstraction interim is new with row 89.

### Q17 - LOT4CATN

- **Spec reference:** 5C.TreatVars r35
- **Spec says:** Named without the _MCRPC suffix every other line uses
- **We do:** Delivered as LOT4CATN_MCRPC, matching the LOTnCATN_<SET> pattern of every other line.
- **Decision:** Correct to LOT4CATN_MCRPC.
- **Why:** RESOLVED 2026-08-07: correct all three to clean names. Delivered as PRIOR_DOCETAXEL, PRIOR_ABIRATERONE and LOT4CATN_MCRPC. This DIVERGES from the spec's column list on purpose - the spec is what gets corrected (errata E13). The asymmetry that used to exist here is gone: the build no longer preserves one slip while fixing another. Note the consequence: any consumer already coding against PRIOR_DOCITAXEL or LOT4CATN must change, which is why this was worth ruling on before release rather than after.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** no prior surface - 202603's names were unsuffixed by design (one setting).

### Q18 - BIOMARKERSTATUS

- **Spec reference:** 5B.ClinChars r70/r74
- **Spec says:** Spec matches 'Mutation Negative'; data holds 'Negative'
- **We do:** Matching on 'negative'
- **Decision:** Match BIOMARKERSTATUS on 'negative' rather than the spec's literal 'Mutation Negative'.
- **Why:** 'Mutation Negative' never occurs in 2026m06 - the delivered values are Negative, Positive, Unknown-not-documented and VUS. Matching the spec literally would score every negative result as unmatched. Substring matching on 'negative' also survives a future 'Mutation Negative' should the vocabulary change. Transcription correction, not a change of definition.
- **Evidence:** Measured at source 2026-08: biomarkerstatus values are Negative/Positive/Unknown-not-documented/VUS; Mutation Negative never occurs
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** no prior surface (Q37). No status string was ever matched before.

### Q19 - COHORTU

- **Spec reference:** 4.StudyPop r13
- **Spec says:** Definition only branches on the two Overall cohorts
- **We do:** Populated for all seven
- **Decision:** Populate all seven cohorts, not just the two Overall ones.
- **Why:** RESOLVED 2026-08-07: populate all seven cohorts. Cohorts 3-7 are treated BY CONSTRUCTION - they are defined by having a line of therapy in that setting - so they resolve to 'Treated <setting>' and the value is constant within each. It is therefore redundant with COHORTN, but a consumer filtering COHORTU='Treated mCRPC' gets every treated mCRPC patient rather than only those inside the Overall cohort, which is the more useful behaviour. No code change: the build already does this. The spec row is wrong on two counts - it inverts treated/untreated and never assigns 'Treated mCRPC' at all - so it joins the errata list as E12.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **Duplicate of Q11, marked 2026-08-08.** Same variable, same question, same answer. Q11 is the fuller row - it also covers the definition inverting treated and untreated. Nothing here contradicts Q11; it was raised twice and answered twice. Read Q11.
- **202603:** duplicate of Q11 - see that note.

### Q20 - HRR/BRCA window

- **Spec reference:** 5B.ClinChars r70/r74
- **Spec says:** Which window bounds the HRR/BRCA biomarker search? THE SPEC CONTRADICTS ITSELF ACROSS TWO SHEETS. 3.Data Prep Section C item 6 ('Biomarker tests / Biomarker dates to use') says biomarker status is defined from tests conducted 'ON OR ANY TIME PRIOR TO INDEX DATE' - unlimited lookback, no post-index tests. 5B.ClinChars HRR_INDEX and BRCA_INDEX Additional Notes say 'Use [-30, +7] window around index date' - 30 days lookback, 7 days AFTER index allowed. The two cannot both hold: each admits tests the other excludes.
- **We do:** [-30, +7], following 5B.ClinChars. 03_clinical.R filters testdt >= DATE_SUB(index_date,30) and testdt <= DATE_ADD(index_date,7). Section C's 'any time prior to index' is NOT implemented.
- **Decision:** Use the [-30, +7] window from 5B.ClinChars for HRR_INDEX and BRCA_INDEX.
- **Why:** RESOLVED. The spec contradicts itself: 3.Data Prep Section C #6 says biomarker tests 'on or any time prior to index date' (unlimited lookback, no post-index tests), while 5B.ClinChars carries '[-30, +7]' on both variable rows. Owner ruled for the 5B window, which is the sheet that defines the variable and which matches LOT_ECOG's [INDEX-30, INDEX+7] elsewhere in the spec. Section C should be corrected to match, otherwise the next reader hits the same contradiction. Recorded from an SME consultation relayed by the data product owner on 2026-08-07; the SME is not named in the relay, so name them here before this is used as a release record.
- **Evidence:** Read from the spec, 2026-08-07. 3.Data Prep Section C #6 full text: 'Biomarker status will be defined as biomarker tests conducted on or any time prior to index date. Biomarker test date is defined as the later date of specimen received, or date of result in the biomarker tables for a given test. If any of the date of specimen received, or date of result is missing, only the available dates will be used to define the biomarker test date. No imputation will be conducted to missing date variables.' 5B.ClinChars carries '[-30, +7]' in Additional Notes on both the HRR_INDEX and BRCA_INDEX rows. MATERIALITY: a source count found 16,011 HRR-positive patients scanning ALL TIME. A 37-day window admits far fewer tests, so the delivered HRR_INDEX/BRCA_INDEX positive counts under the current code should be well below 16,011. The gap between the delivered count and D5b is the size of this decision and must be read off the first real run. Note the same Section C text also confirms two things the code already does: the test date is the LATER of the two dates, and when one is missing only the available one is used (pmax with na.rm=TRUE). It says 'specimen RECEIVED'; the 2026m06 table has specimencollecteddate only - that substitution is Q04.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** no prior surface (Q37). The contradiction is internal to the 202606 sheets.

### Q21 - min_vst_dt / min_vsttelemed_dt / min_medord_dt

- **Spec reference:** 5B.ClinChars r88
- **Spec says:** Named in row 88 but unused by the row-89 derivation
- **We do:** All six produced; min_medord_dt sourced from t_medicationorder.expectedstartdate
- **Decision:** Build's reading confirmed; correct the spec, not the code.
- **Why:** APPROVED 2026-08-07 as part of the nine-item spec errata block (this file). The build's reading is confirmed correct and the SPEC is what gets corrected; no code change. Approved as a block because in each case the literal spec text is self-evidently not the intent - most starkly Q45, which taken literally clamps FUED to the index date for every patient with follow-up and would zero OS, TTNT, PFS and FUDUR across the study.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** the min_* trio is new with row 88. 202603 derived different helpers, dropped the follow-up and death ones, and delivered lastvisitdate renamed to last_visit_date. Keeping the interims is this spec's decision.

### Q22 - BIRTHYEAR

- **Spec reference:** 5A.Demos r8
- **Spec says:** Row 8 says keep it; 202603 deliberately dropped it; it is identifying
- **We do:** Retained
- **Decision:** Keep BIRTHYEAR, as 5A.Demos row 8 instructs.
- **Why:** 5A.Demos row 8 lists birthyear among 'keep these variables when creating this analytic dataset'. Supersedes 202603, which dropped it. RESOLVED 2026-08-07: keep it, per the spec. No code change. RECORDED BECAUSE IT DOES NOT GO AWAY BY BEING APPROVED: BIRTHYEAR is directly identifying, and AGE and AGEGR1N are already delivered, so it adds re-identification risk without adding analysis those two do not already support. The 202603 build dropped it deliberately. This is a data-product decision, not a disclosure-risk assessment - if anyone owns disclosure risk for this deliverable, they should see this row before consumers get access.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** deliberately reversed - 202603's final select dropped birthyear (with birthsex and ethnicity); the spec's keep-list overrides.

### Q23 - ECOGN

- **Spec reference:** 5B.ClinChars r47
- **Spec says:** How many ECOG categories and codes does the spec define? the earlier reading of the ECOGN Values list as '1,2,3,4,5,6,7' - seven codes for six categories - and built the extra code to separate Unknown (a record exists, value null) from Missing (no record at all).
- **We do:** ECOG delivers '0','1','2','3','4','Unknown/Missing' and ECOGN 1..6, matching the spec. Corrected 2026-08-07.
- **Decision:** Six categories, six codes, exactly as the spec lists.
- **Why:** A REAL DEFECT, introduced by me and shipped until now. The build delivered a seventh ECOG category and a seventh ECOGN code that the spec does not define, and split a label the spec combines - so BOTH the character and the numeric column diverged from the Values list. Worse, I had CLOSED this row on 2026-08-07 with the reasoning that 6 and 7 were 'the spec's own codes', which was the misreading restated as a justification. Now fixed: ecog = 'Unknown/Missing', ecogn = 6, and V1's c15 mapping gate updated to match. WHAT IS LOST, and it is worth knowing: the build could distinguish 'a record exists but the value is null' from 'no ECOG record at all'. That distinction is real and is now gone, because the spec asks for one category. If it is wanted, it needs a new variable rather than an undeclared seventh code.
- **Evidence:** CORRECTED 2026-08-07 against the spec text (the spec text), an independent reading of the same source pages. It gives ECOG Values as '0','1','2','3','4','Unknown/Missing' - six categories with unknown and missing COMBINED - and ECOGN as 1,2,3,4,5,6. Six codes, not seven. The earlier reading of a seventh code was wrong.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** the seven-code split this row corrects IS the 202603 implementation: Unknown 6, Missing 7. The spec's six categories override it. The lost distinction (null value vs no record) would need a new variable.

### Q24 - NEW_LOT_N

- **Spec reference:** 3.Data Prep r19
- **Spec says:** No tie-breaker defined for two lines starting the same day in one setting
- **We do:** The run STOPS at the source gate, which must pass before any build; no tie-breaker invented
- **Decision:** Keep the source gate. The run stops rather than guessing a tie-break.
- **Why:** RESOLVED 2026-08-07. A non-deterministic NEW_LOT_N would silently move cohort membership, index dates and every LOTn variable, so stopping is safer than inventing an order the spec does not have. It costs nothing today: the Q42 query measured ZERO same-day line pairs in either setting for 2026m06, so gate B1 never fires on this cut. It stays as protection for future cuts.
- **Evidence:** Measured at source 2026-08: 0 same-day LOT ties. That source gate enforces this before every build SUPPORTED 2026-08-07 by the Q42 query, which is the same condition: zero consecutive line pairs share a start date in either mHSPC or mCRPC. So NEW_LOT_N is deterministic on 2026m06 and that source gate does not fire. The gate stays as protection for future cuts, but the current build carries no exposure. Source: the same-day LOT tie check (zero, PASS) and the Q42 query returning no rows - two independent limbs. Re-run 2026-09-12; recorded from source on 2026-09-12.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** same ordering, new protection. 202603 ran the identical ROW_NUMBER over startdate with no tie gate. Per-setting numbering and gate B1 are new.

### Q25 - LABALB

- **Spec reference:** 5B.ClinChars r44
- **Spec says:** No albumin rows carry testunitscleaned='g/L'; the populated serum-albumin rows have a NULL unit
- **We do:** The spec's testunitscleaned='g/L' filter is APPLIED, alongside labcomponent='Albumin, serum'. Restored 2026-08-07 after the query showed the premise for dropping it was false.
- **Decision:** Apply the spec's g/L filter. The delivered LABALBV is g/L.
- **Why:** RESOLVED. Two separate things were settled. (1) SCALE: 'Albumin, serum' carries unit g/L on 4,966,771 rows with median 40, which is g/L (35-50) and not g/dL (3.5-5.0) - so the delivered value was already on the right scale and there is no factor-of-ten error. (2) FILTER: it had been dropped on the belief that no albumin row carried g/L, which the same query disproved, so it is restored. The scale is now right BY CONSTRUCTION rather than by luck - a future row arriving in a different unit is excluded instead of being averaged into a g/L column. The filter sits in the 'Present' criteria, not in the record-exists check, because the spec's Missing clause names only testbasename and labcomponent: a wrong-unit record makes LABALB 'Unknown', not 'Missing'. Still worth an explicit nod rather than a silent inheritance: 'Albumin [mass/volume] in serum by electrophoresis' (181,577 rows, also g/L, median 39) is excluded by the exact labcomponent match. That looks right - different assay - but it was never a considered choice.
- **Evidence:** RESOLVED ON SCALE 2026-08-07. t_lab, all rows with testbasename='albumin', grouped by labcomponent and testunitscleaned: 'Albumin, serum' carries unit 'g/L' on 4,966,771 rows / 308,946 patients, with p25 37 and MEDIAN 40. Serum albumin in g/L runs 35-50; in g/dL it would run 3.5-5.0. The delivered LABALBV is therefore g/L, which is exactly what the spec's label says. THERE IS NO 10x ERROR. The urine variants are mg/L or mg/d and are correctly excluded by the labcomponent='Albumin, serum' filter. BUT THIS ROW'S ORIGINAL PREMISE IS FALSIFIED. It claimed no albumin row carried testunitscleaned='g/L' and that the populated serum rows had a NULL unit. Nearly five million rows carry g/L. Whatever earlier check produced that claim was wrong or was scoped to something much narrower; it should not be relied on again. Source: plus the albumin unit and scale checks. Re-run 2026-09-12: serum albumin median 40 g/L, C10c PASS at 99.91% g/L.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** no prior surface - albumin appears nowhere in 202603. The g/L ruling and C10's presence gate are first-time.

### Q26 - PSMA_SCANRESULT

- **Spec reference:** 5B.ClinChars r79
- **Spec says:** Patients have two PSMA scans on the same date with conflicting IsDiseaseEvidence; the spec gives no tie rule
- **We do:** Same-date conflicts resolve Yes+No -> Unknown/not documented, Yes+Unknown -> Yes, No+Unknown -> No. The alphabetical MAX() is gone.
- **Decision:** Yes+No on the same date resolves to Unknown/not documented.
- **Why:** RESOLVED 2026-08-07. Implemented, replacing max() on the string - which resolved alphabetically and so favoured 'Yes' as an artefact of collation rather than a clinical rule. The new rule mirrors the one the spec DOES state for biomarkers on a shared date: Yes+No -> Unknown (cf. Positive+Negative -> Unknown), Yes+Unknown -> Yes, No+Unknown -> No. Affects the 8 patients with a hard contradiction; the other 30 pair a definite answer with Unknown and are unchanged.
- **Evidence:** Measured at source 2026-08: same-date conflicts confirmed (No/Yes, Yes/Unknown) QUANTIFIED 2026-08-07 and re-run 2026-09-12 as a reading, not a gate. It lists patient/scan-date pairs carrying more than one distinct IsDiseaseEvidence on the SAME date: 38 rows both times. Because it scans any scan date rather than only the winning pre-index one, 38 is an upper bound on the rows the tie rule decides. The conflicting pairs are not all value-vs-Unknown - at least 8 of the 38 are a hard ["No","Yes"] contradiction on the same scan date, with the rest pairing a definite answer against 'Unknown/not documented'. So the tie rule is not a formality: for those 8 patients it decides whether PSMA_SCANRESULT is Yes or No, and MAX() on the string currently resolves it alphabetically, which favours 'Yes' over 'No' and 'Unknown/not documented' over both.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** no prior surface - the PSMA table is new. The superseded alphabetical MAX() was this cut's early draft; the tie rule follows the spec's biomarker collision table. B10's 38 patients (8 hard conflicts) are what it decides.

### Q27 - Publication step

- **Spec reference:** n/a
- **Spec says:** Should the build write the deliverable directly, or to a staging copy that a separate manual step publishes?
- **We do:** Writes the deliverable directly. One table, one path, no staging copy and no publish step.
- **Decision:** Keep the direct write. No staging copy, no publish step.
- **Reversed 2026-09-12, deferred to the next cut:** by Onkar Kshirsagar, with Q43. A promotion step is to be built - the deliverable written under a staging name, validated, then published, so it stops being live before any check has run - and it is **not in 202606**. This cut still writes directly, which is the 2026-08-07 behaviour, with the risk accepted in writing - see section 10. The superseded decision is kept above.
- **Why:** Owner's decision: the two-step was ceremony for a single-analyst build. The cost is explicit and documented - the table is live the moment the build finishes, so an unvalidated build is immediately visible to consumers and a validation FAIL means rebuild or drop rather than 'hold the release'. What still stops a bad build BEFORE anything is written is the source gates - thirteen of them now (B18 added 2026-09-11), plus the input-contract check and the pre-write cohort count. Revisit if this ADS is ever read by an automated downstream consumer that cannot tolerate a transiently wrong table. RESOLVED 2026-08-07: current behaviour confirmed. This is an ACCEPT-THE-RISK decision, not a no-risk one, and the residual risk belongs in writing: the deliverable is LIVE the moment the build finishes, so the output validation (V1, V2c, V4, the null sweep, the column checker) can only run AFTER consumers could already have read it. If validation fails, the remedy is to drop or rebuild the table FAST - there is no quarantine. What makes this defensible today: the source gates stop a bad run BEFORE anything is written, the build prints 'This table is LIVE - run the output validation now', and the product is in controlled UAT with no consumers attached. WHAT WOULD CHANGE THE ANSWER: real consumers. Once anything downstream reads this table on a schedule, a failed validation stops being recoverable by speed, and staging or a view swap should be revisited.
- **Evidence:** n/a
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **Mitigation 2026-08-08:** the decision is unchanged, but one gap in it is now closed. The source gates check the SOURCE; nothing checked the RESULT, so a build that came out empty - a bad refresh, a filter that matched nothing - would have replaced the live table with zero rows before any validation ran. 06_assemble.R now counts the seven materialized cohort stages before the write and stops if any is empty, leaving the previous table untouched. It can only refuse a write; it cannot change a value.
- **Superseded 2026-08-09 (202606.25), owner's directive:** the build now only creates - the source gates and the input contract moved out of the build, and the pre-write cohort count was REMOVED with them. Nothing inside the build protects the live write any more. What stands instead: the runbook orders the source gates before every build and the V26 cohort counts straight after it. The residual risk widens accordingly - a skipped or stale source gate, or an empty build, replaces the live table and is only caught by the validation run that follows. Same accept-the-risk logic as the direct write itself: single analyst, controlled UAT, no attached consumers. The 'real consumers' trigger above now also covers restoring an in-build write guard, not only staging.
- **202603:** matches. 202603 published the same way - createInPersonalSchema(..., replace = TRUE) straight onto its table, no staging, no publish step.

### Q28 - HRR_INDEX / BRCA_INDEX

- **Spec reference:** 5B.ClinChars r70-r77
- **Spec says:** Should HRR_INDEX be accompanied by a label-aligned sibling variable, the way BRCA_INDEX already is? HRR_INDEX is a collapsed patient-level status and the ADS carries no gene-level column, so the panel choice is irreversible downstream - a study needing a different definition must rebuild from t_enh_prostate_biomarker.
- **We do:** HRR_LABEL_INDEX and HRR_LABEL_INDEXN ship alongside HRR_INDEX, computed over the 14-gene olaparib label set through the same biomarker_status() function and the same shared winning date.
- **Decision:** Add a label-aligned sibling: HRR_LABEL_INDEX / HRR_LABEL_INDEXN.
- **Why:** RESOLVED 2026-08-07 and implemented. Before this, seeing the label-aligned view meant running the whole build again with RDAP_HRR_PANEL set, so the two views could never appear in one dataset and no single row could be compared across panels. DELIBERATE: the sibling is NOT affected by RDAP_HRR_PANEL - it always means the olaparib label, whatever panel the main HRR_INDEX is built from. If it tracked the switch the two columns would move together and the comparison they exist for would be lost. New gate V2e: the 14 label genes are a subset of the default 19, so HRR_LABEL_INDEX='Positive' must imply HRR_INDEX='Positive'. Same shape as V2c, and it fails closed if the two gene lists are ever edited out of subset relation.
- **Evidence:** the column contract carries hrr_index/hrr_indexn and brca_index/brca_indexn only - no biomarkername or gene-level column. The spec already uses the two-variable pattern (broad + narrow), so a third label-aligned variable would follow its own design.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** no prior surface (Q37). The sibling is an addition to the spec - an owner design following its broad-plus-narrow pattern - so its 14-gene meaning, V2e and panel independence stand on this row.

### Q29 - HRR_INDEX / BRCA_INDEX

- **Spec reference:** 5B.ClinChars r70/r74
- **Spec says:** How is a multi-gene panel collapsed to one patient-level status? The spec's HRR_INDEX row is written for BIOMARKERNAME='HRR' - a SINGLE aggregated value per test - and gives a same-date collision list for that value. The source holds ONE ROW PER GENE and never a row named 'HRR', so the spec's rules have no cross-gene rollup to apply.
- **We do:** Two steps. (1) WITHIN each gene, on the ONE shared winning date (Q37), the spec's four same-date rules plus three VUS pairs all now ruled: Negative+VUS -> Negative, VUS+Unknown -> Unknown/Not documented, Positive+VUS -> Positive. (2) ACROSS genes, best status wins, ranked Positive > Negative > VUS > Unknown.
- **Decision:** Within a gene: Pos+VUS -> Positive, Neg+VUS -> Negative, VUS+Unknown -> Unknown. Across genes: Positive > Negative > VUS > Unknown.
- **Why:** RESOLVED FOR NOW. FROM THE SPEC and reproduced unchanged: all four same-date collision rules (Positive+Negative -> Unknown, Positive+Negative+Unknown -> Unknown, Positive+Unknown -> Positive, Negative+Unknown -> Negative) and the delivered coding 1=Positive 2=Negative 3=VUS 4=Unknown. FROM THE SME (2026-08-07): VUS+Unknown -> Unknown/Not documented, and Negative+VUS -> Negative on the reasoning that a definite negative call is knowledge and a VUS is not, the same way Negative+Unknown resolves Negative. STILL DECIDED IN CODE, not ruled on, and both still change delivered values: (a) Positive+VUS on one gene resolves Positive; (b) the CROSS-GENE rollup, which has no counterpart in the spec at all and currently ranks VUS ABOVE Negative - so a patient with one VUS gene and the rest Negative delivers VUS. Note the tension worth putting to the SME: their reasoning for Negative+VUS within a gene, extended across genes, would rank Negative above VUS and flip (b). They are different questions - contradictory readings of one gene, versus different genes each read cleanly - so this was NOT extended unilaterally. Recorded from an SME consultation relayed by the data product owner on 2026-08-07; the SME is not named in the relay, so name them here before this is used as a release record. FULLY RESOLVED 2026-08-07. The last two pieces are ruled and implemented. (a) Positive+VUS -> Positive: a pathogenic variant on the same gene on the same date outranks an uncertain one, consistent with the spec's own Positive+Unknown -> Positive. (b) The CROSS-GENE order is reversed, from Positive > VUS > Negative to Positive > NEGATIVE > VUS. The old order let one VUS gene outrank several clean negatives, which contradicted the within-gene ruling that Negative+VUS resolves to Negative. The two levels now agree, and the order also matches the only ordering the spec ever states - its parsing cascade Positive > Negative > VUS. CHANGES DELIVERED VALUES: any patient whose only non-negative finding is a VUS moves from HRR_INDEX='VUS' to 'Negative'. The internal rank now equals the delivered coding (1=Positive, 2=Negative, 3=VUS, 4=Unknown), so the two can no longer drift apart. V2c is unaffected: BRCA genes are a subset of every HRR panel and both calls share one winning date, so BRCA-positive still implies HRR-positive by construction regardless of how the ranks are ordered.
- **Evidence:** WHAT THE SPEC ACTUALLY SAYS (5B.ClinChars HRR_INDEX and BRCA_INDEX rows, read from the spec; the BRCA row is word-for-word the HRR row with BIOMARKERNAME='BRCA'): status parsed from one BIOMARKERSTATUS string as Positive, else 'Mutation Negative' -> Negative, else VUS, else Unknown/Not documented; window [-30,+7]; multiple tests in the period -> report closest to index date, prioritising tests PRIOR to index when equidistant; multiple tests ON THE SAME DATE -> exactly four rules: Positive/Negative = Unknown/Not documented, Positive/Negative/Unknown = Unknown/Not documented, Positive/Unknown = Positive, Negative/Unknown = Negative. VUS DOES NOT APPEAR IN THE SAME-DATE LIST AT ALL, so Positive/VUS, Negative/VUS and VUS/Unknown are all undefined by the spec. The spec also has no cross-gene rollup, because it assumes BIOMARKERNAME='HRR' holds one aggregated value per test - the source has one row per gene and no row named 'HRR'. CORRECTION: an earlier version of this row listed 'Positive/VUS -> Positive' as one of the spec's four same-date rules. That was a misreading; rule 2 is Positive/Negative/Unknown -> Unknown. The practical effect is that the code fills three VUS gaps, not one. WHY THE CODE DEVIATES ON THE ROLLUP: the previous implementation collapsed across genes FIRST and then applied the same-date Positive+Negative rule, so on a 19-gene report a BRCA2-positive patient with 18 negative genes scored 'Unknown' and essentially every true positive was lost. A source count puts flatiron_all positives at 16011 and BRCA-only at 5715; the delivered mirror asserts BRCA-positive implies HRR-positive, true under any panel and false under the old rollup. TEXT CORRECTED 2026-08-07. This field previously described the SUPERSEDED algorithm on two counts: it said each gene used 'that gene's own winning test date' (it is now one shared date), and it listed 'Negative+VUS -> VUS' and 'VUS+Unknown -> VUS', both of which the SME reversed and the code no longer does. The row's own rationale already carried the corrected rulings, so the register was internally inconsistent - the worst possible state for a control document, because either field could be read as authoritative.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** no prior surface (Q37). No collision rule, VUS ranking or rollup existed. Every rule stands on the spec's four collisions, the SME's two VUS rulings, and the owner's Positive+VUS and cross-gene ordering.

### Q30 - ECOG (treated cohorts)

- **Spec reference:** 5B.ClinChars r47
- **Spec says:** t_enh_prostate_bsln_ecog has duplicates on patientid+linenumber+linestartdate; the spec gives no tie rule. Two things need deciding: which DATE wins, and which VALUE wins on that date.
- **We do:** Cohorts 3-7 take the baseline-ECOG record CLOSEST TO INDEX, ties to the earlier record, then the highest value on that date.
- **Decision:** Closest to index, then the highest value on that date.
- **Why:** Resolving the date before the value is not optional: min(ecogdate) and max(ecogvalue) in one summarise can take the date from one record and the value from another. Which date should win is genuinely open - EARLIEST is what the code does; CLOSEST-TO-LINE-START is arguably the better clinical reading of a baseline measurement. MAX(value) is conservative (reports the worse performance status) but the spec does not say so. RESOLVED 2026-08-07. Cohorts 3-7 now use the same date rule as cohorts 1-2, so all seven share one shape. Worth recording WHY the row existed: the spec states a date rule only for cohorts 1-2; for 3-7 it gives just linenumber + linestartdate and assumes that match is unique. The baseline-ECOG table has duplicates on that key, so the build had to invent something. It previously took the earliest record; it now takes the closest to index, ties to the earlier - which is the tie-break the spec does state for cohorts 1-2.
- **Evidence:** A source check lists the duplicate keys and their values
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** the tie rule is 202603's own - closest date, earlier on ties, highest value on the day, for every cohort. The population differs by spec: line-matched here for treated cohorts vs pooled tables there, and the Overall anchor moved to the raw milestone date (Q71). ECOG can differ across cuts on both counts.

### Q31 - STAGE / STAGEN

- **Spec reference:** 5A.Demos r12/r13
- **Spec says:** The Values list gives five stages; the spec gives no code for a patient with no group stage recorded.
- **We do:** Residual code 99, per the fallthrough convention.
- **Decision:** 99 is the fallthrough code.
- **Why:** Follows the same pattern as ECOG and GLEASON, where the spec DOES supply an explicit unknown level. Chosen for consistency, not from the sheet. CONVENTION SET 2026-08-07 by the data product owner: 99 is the fallthrough sentinel for a category the spec's Values list does not code. Applied to every build-invented residual: AGEGR1N, REGION1N, STAGEN, PRACTICN and COHORTUN all now use 99, where before they used 8, 7, 6, 99 and 99. An earlier attempt went the other way - it made PRACTICN 4 on a 'next integer after the spec's last code' rule inferred from what four of the variables happened to do. That was wrong: 99 is a recognisable sentinel and a low integer sitting beside real codes is not. Reverted the same day. NOT changed: RACEN 5, ETHN 3, GLEASONN 3 and ECOGN 6 are all codes the spec's own Values lists provide, not residuals this build invented. RESOLVED 2026-08-07: 99 confirmed as the fallthrough code, applied to every build-invented residual - AGEGR1N, REGION1N, STAGEN, PRACTICN and COHORTUN.
- **Evidence:** Sheet reference corrected 2026-08-07: STAGE/STAGEN are on 5A.Demos rows 12-13, not 5B.ClinChars - the register had mis-cited them. Reading the sheet also confirms the prefix cascade is ordered IV, III, II, I, 0, which the code follows; testing 'I%' before 'II%' would misclassify every stage II and III patient as stage I.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **Not an independent decision.** This is Q50's residual convention applied to STAGEN. The row stays because someone looking up STAGE or STAGEN needs to find it, but the rule it applies is stated once, in Q50.
- **202603:** the 99 residual matches; the mapping does not. 202603 matched exact lists with a literal 'CHECK' label; the prefix match and enumerated Unknown follow the spec.

### Q32 - PRACTIC / PRACTICN

- **Spec reference:** 5A.Demos r16/r17
- **Spec says:** The Values list gives three practice types; the spec gives no code for a patient with no practice record.
- **We do:** Residual code 99, per the fallthrough convention.
- **Decision:** 99 is the fallthrough code.
- **Why:** 99 is the site convention for missing in a small code list, and keeping it out of the 1-3 range means it cannot be mistaken for a real category in an ordinal analysis. Not stated in the sheet. CONVENTION SET 2026-08-07 by the data product owner: 99 is the fallthrough sentinel for a category the spec's Values list does not code. Applied to every build-invented residual: AGEGR1N, REGION1N, STAGEN, PRACTICN and COHORTUN all now use 99, where before they used 8, 7, 6, 99 and 99. An earlier attempt went the other way - it made PRACTICN 4 on a 'next integer after the spec's last code' rule inferred from what four of the variables happened to do. That was wrong: 99 is a recognisable sentinel and a low integer sitting beside real codes is not. Reverted the same day. NOT changed: RACEN 5, ETHN 3, GLEASONN 3 and ECOGN 6 are all codes the spec's own Values lists provide, not residuals this build invented. RESOLVED 2026-08-07: 99 confirmed as the fallthrough code, applied to every build-invented residual - AGEGR1N, REGION1N, STAGEN, PRACTICN and COHORTUN.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **Not an independent decision.** This is Q50's residual convention applied to PRACTICN. Same as Q31: kept for lookup, ruled once in Q50.
- **202603:** the levels and 99 residual match; the aggregation does not. 202603 aggregated with ', ' but tested the spaceless 'ACADEMIC,COMMUNITY', so a dual-practice patient fell to Missing/99 - if its non-Spark STRING_AGG ran at all. Here CONCAT_WS(',') matches and they read Both/3. Not comparable across cuts; unsized.

### Q33 - FUED / DTHDT / PSMA_SCANDT

- **Spec reference:** 6.Outcomes / 5B.ClinChars r94-r95
- **Spec says:** May a follow-up or event date lie after MAXINDEX? The index date is bounded to [MININDEX, MAXINDEX]; nothing bounds the follow-up dates.
- **We do:** Not bounded. Dates are carried as recorded and may exceed 2026-04-30
- **Decision:** Yes. Follow-up and event dates may exceed MAXINDEX.
- **Why:** Truncating follow-up at MAXINDEX would bias OS and PFS downward for late-index patients, which is worse than carrying a date past the nominal cut. But the quantity has to be on the record before that is accepted, which is what X01/X02/X06 are for. RESOLVED 2026-08-07. MAXINDEX bounds when a patient may ENTER the study, not how long they are followed; capping follow-up at it would truncate survival for everyone indexed late and bias OS downward. No code change. V4's X01, X02 and X06 already count how many FUED, DTHDT and PSMA_SCANDT values exceed it - record those with the release.
- **Evidence:** Output validation V4 X01/X02/X06 count how many actually do
- **Scope note.** The ruling bites for FUED and DTHDT only. PSMA_SCANDT is defined as the latest ScanDate on or before INDEXDT, and INDEXDT never exceeds MAXINDEX, so X06 can only ever read zero - kept for symmetry, not because the case is reachable.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **Changed by Q82, 2026-09-11:** both counts must be re-read, and they move in OPPOSITE directions. X02 (dthdt > MAXINDEX) can only fall, because W3 is withdrawn and the dates move earlier. X01 (fued > MAXINDEX) can RISE: FUED is now DTHDT wherever a death date exists, and for a patient whose death post-dates their last activity that is later than the old pullback ever produced, so FUED can cross MAXINDEX where it previously did not. FUED can also now be NULL. The rule itself - a follow-up or death date may legitimately exceed MAXINDEX - is unaffected.
- **202603:** matches - 202603 bounded only cohort entry; follow-up, death and visit dates ran past MAXINDEX exactly as here. Its two post-entry MAXINDEX uses: ID3MOSFU (shared, caps nothing) and PFUDUR (not in this spec).

### Q34 - PFSDT / PFS

- **Spec reference:** 6.Outcomes
- **Spec says:** Progression can be recorded after the patient has died. The spec defines no chronology repair, so PFSDT is taken as recorded and can exceed DTHDT - which makes PFS longer than OS for the same patient in the delivered ADS.
- **We do:** PFSDT is the FIRST qualifying PROGRESSIONDATE at or after INDEXDT+14, taken verbatim. No clamping to DTHDT, no exclusion of impossible rows, no flag. PFS is then (PFSDT - INDEXDT + 1)/30.4375 with no upper bound.
- **Decision:** No action. Treat progression-after-death as a documented data limitation.
- **Why:** RESOLVED as specified. X03 and X03b stay, not as gates but to QUANTIFY the limitation for the release record - which is what 'treat as limitation' requires someone to do. Note X03/X03b measure DELIVERED PFSDT > DTHDT, which is not the same population as the 896 source rows: death-date imputation moves the boundary. Both numbers are worth recording and neither substitutes for the other.
- **Evidence:** SIZED AT SOURCE 2026-08-07. Across 231,261 qualifying progression rows on 70,538 patients: progression after the LAST CLINIC NOTE = 0 rows, so that half of the concern closes outright. Progression after the END OF THE DEATH MONTH = 896 rows. That bound is deliberately generous - DateOfDeath is only month/year granular - so all 896 post-date the last day the patient could have died and none is a granularity artefact. IMPORTANT: 896 is a count of SOURCE ROWS, not of delivered patients, and it OVERSTATES the delivered impact. PFSDT takes the FIRST qualifying progression, so a patient who has a valid early progression and also an impossible late one is unaffected - the early one wins. Only patients whose WINNING PFSDT falls after death are actually wrong in the ADS. That delivered number is already measured, as 'pfsdt after dthdt' among the delivered-value checks. X03 has not yet been run against the delivered table. ANSWERED BY THE SPEC 2026-08-07, found in the spec text. 3.Data Prep Section C item 7 raises this exact issue - 'X patients had death date before progression date' - cites Flatiron's own guidance that a small number of records carry structured activity after DateofDeath through data entry error, and rules: **'No action - treat as limitation.'** So the build's behaviour is the SPECIFIED behaviour, not an unresolved gap. This row asked for an SME ruling that the spec had already given on a page I had read but not connected to it.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **Owner confirmation 2026-08-09:** progression dates stand as recorded - no clamp to death, PFS unbounded. X03 sizes the delivered exposure.
- **202603:** no precedent - 202603 had no rwPFS and never read the progression table. The spec's own 'no action' instruction is the rule.

### Q35 - PSA50_6MO / PSAL6MO / PSA50_12MO / PSAL12MO

- **Spec reference:** 6.Outcomes
- **Spec says:** These are built as case_when(<responded> ~ 'Y', TRUE ~ 'N'), so a patient with NO post-index PSA - or no baseline PSA - reads 'N', not missing.
- **We do:** Emitted verbatim as specified: 'N' covers both 'measured, did not respond' and 'never measured'
- **Decision:** Keep 'N'. A missing PSA scores N, as the spec's 'Else N' states.
- **Why:** This is what the spec's Y/N formulation says, and the point of an RDAP is to transform the source into the specified format rather than to improve on it. But a response rate computed off this column counts unmeasured patients as non-responders, so the size of X08/X09 decides whether a third level ('Not evaluable') is needed. RESOLVED 2026-08-07: owner ruled to follow the spec verbatim. CONSEQUENCE TO CARRY FORWARD, because it does not go away by being approved: 'N' merges 'measured, did not respond' with 'never measured', so any response RATE computed off these columns has an inflated denominator and is biased LOW. Anyone reporting PSA response should compute the denominator from PSA6MO/PSA12MO being non-null rather than from a count of rows. Check X08/X09 in V4 sizes the affected population - record it with the release.
- **Evidence:** Output validation V4 X08/X09 count how many 'N' values have no PSA behind them
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** the PSA table is new. 202603's only PSA columns (PSADIAG_INIT/MET) are t_enh_prostate copies, as here. Missing-scores-N stands on the spec's 'Else N'.

### Q36 - VIS120

- **Spec reference:** 6.Outcomes
- **Spec says:** VIS120 is ifelse(<visit 120+ days after the index line ended>, 1, 0), so a patient whose index line has no end date scores 0 rather than missing.
- **We do:** Emitted as 0. Same shape as Q35
- **Decision:** Keep 0. A missing index-line end date scores 0, matching Q35's shape.
- **Why:** Identical reasoning to Q35, and identical risk: 0 means both 'no late visit' and 'we do not know when treatment ended'. The count decides whether it needs a missing level. RESOLVED 2026-08-07: owner ruled to follow the spec verbatim, consistent with Q35. Same caveat: 0 merges 'no late visit' with 'index line never ended', so VIS120 is not a clean denominator. Check X10 in V4 counts the patients whose index line has no end date.
- **Evidence:** Output validation V4 X10 counts the 0s that have no index-line end date behind them
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** no working precedent. 202603's VIS120 was an existence implementation, hard-coded per cohort; its Overall scored 0 where this spec leaves 1-2 missing. The no-end-date-scores-0 outcome happens to match; the definition here is the spec's. X10 sizes the merge.

### Q37 - HRR_INDEX / BRCA_INDEX

- **Spec reference:** 5B.ClinChars r70/r74
- **Spec says:** Which test date wins when a patient has more than one biomarker report inside the [-30,+7] window: the closest report as a whole, or the closest test PER GENE?
- **We do:** The biomarker test CLOSEST TO INDEX inside the [-30,+7] window, chosen over ALL biomarker tests - every gene, every test type - giving ONE winning date per patient that the HRR and BRCA calls share. Equidistant before/after resolves to the earlier (pre-index) test, per the spec. Status is then resolved within each gene on that date and rolled up across genes (Q29).
- **Decision:** One winning date per patient: the biomarker test closest to index, over all biomarker tests. Applies identically to HRR_INDEX and BRCA_INDEX. Test type is not a selection criterion.
- **Why:** RESOLVED. This restores the spec's closest-to-index rule but applies it to a single pool of all biomarker tests rather than per gene, which is the reading that matches the spec's own assumption that BIOMARKERNAME='HRR' holds one aggregated value per test. Cost, and it should be understood before release: a gene tested only on a NON-winning report contributes nothing, so a real positive on an earlier report is discarded - which is what happens to BRCA in the example above. Interacts with Q20: bounded to [-30,+7], 'closest' ranges over a 37-day window only. Recorded from an SME consultation relayed by the data product owner on 2026-08-07; the SME is not named in the relay, so name them here before this is used as a release record. RESIDUAL RISK noted by review 2026-08-07, documented rather than changed: the shared winning date is chosen over ALL biomarker tests BEFORE the frozen-panel gene filter is applied, so a future out-of-panel gene could move the winning date and shift HRR/BRCA status without itself being counted. That is what 'earliest/closest amongst ALL biomarker tests' was ruled to mean, so it is permitted by the decision rather than contrary to it, and it cannot bite on 2026m06 where the frozen 19 are exactly the genes present. Revisit if a cut adds a gene.
- **Evidence:** SME worked example, 2026-08-07: index 7 Feb, ATM Negative on 30 Jan, BRCA Positive on 25 Jan -> the ATM reading is taken. 30 Jan is 8 days from index, 25 Jan is 13, so this is CLOSEST-to-index selection over a single pool. HRR_INDEX is therefore Negative; BRCA has no result on 30 Jan so BRCA_INDEX is Unknown/Not documented, not Positive. The relay first described the rule as 'earliest amongst all biomarker tests', which would have selected BRCA on 25 Jan and returned HRR=Positive - the opposite answer. The worked example was taken as decisive and the owner confirmed it, including that it applies to BRCA as well. Sharing ONE date across both calls is what preserves V2c: resolving the date separately per panel is what used to give HRR=Negative with BRCA=Positive on exactly this shape. CORRECTION AND WHO MADE IT: the rule was first implemented as 'earliest', following the wording of the relay, and committed that way. Onkar Kshirsagar corrected it on 2026-08-07 by supplying the SME's worked example above, which selects the LATER of the two tests and so is closest-to-index, not earliest, and confirmed that the same rule applies to BRCA_INDEX. The corrected rule is what ships; the superseded 'earliest' implementation never left this branch.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** none exists - 202603 never read the biomarker table; the whole family (Q04, Q05, Q18, Q20, Q28, Q29, Q44) is new. The rule stands on the spec's closest-to-index reading plus the SME worked example above.

### Q38 - Index date / cohort membership

- **Spec reference:** 4.StudyPop section B
- **Spec says:** A treated cohort's index line can START BEFORE the mHSPC/mCRPC milestone it is joined to. The cohort join matches on patientid only and enforces no chronology.
- **We do:** Allowed. Both dates must fall inside [MININDEX, MAXINDEX], but the line start is not required to be at or after the milestone.
- **Decision:** Accept. The index line may start before the milestone defining the cohort; no chronology is enforced.
- **Why:** Real and concentrated in the two L1+ cohorts. For 10,148 patients (10,170 before the Q82 exclusion) the index treatment predates the mHSPC/mCRPC classification it is supposed to follow, so 'L1+ treated mCRPC' includes patients whose first line began while they were still classified otherwise. Whether that is intended is a study-design question, not a coding one: requiring line start >= milestone would remove 6.1% of cohort 3 and 10.5% of cohort 4. Needs an SME ruling with those numbers in front of them. RESOLVED 2026-08-07: accept and document. 10,170 patients are affected - 4,855 in cohort 3 (6.1%) and 5,315 in cohort 4 (10.5%). Cohorts 5-7 are zero, which is the expected shape since later lines start later. The defensible reading is that real-world coding of the mHSPC/mCRPC milestone lags the clinical reality, so a first line legitimately predates the recorded classification date. Requiring chronology would have removed a tenth of cohort 4. WHAT THIS DOES AND DOES NOT BREAK (corrected 2026-08-09, first gate run): OS and TTNT cannot go negative - DTH_BEFORE_FUED nulls both and FUED is clamped to index. rwPFS CAN: its spec formula has no DTH_BEFORE_FUED null, so a death date before index delivers a negative rwPFS through the death-branch PFSDT. The first V-gate run measured 285 such rows (V07b) among 2,799 death-before-index rows (V08b). SOURCE, NOT IMPUTATION: of those 2,799, 2,757 rows / 1,376 patients carry a raw DATEOFDEATH whose month is strictly earlier than the index month - t_mortality_v2 and t_enh_prostate_lot contradict each other, so the source records a line of therapy starting after the patient died. Only 42 rows / 22 patients come from the spec's day-15 convention landing before an index later in the same month. The gap sizing rules out granularity altogether: 2,490 of the 2,799 rows exceed one year, cohorts 5-7 have MINIMUM gaps of 717/1,002/2,362 days, and the maxima reach 40,528 and 41,727 days (about 111 and 114 years, tail not yet characterised). The values themselves are ordinary: the 30 most common are all 7-character months in 2013-2017 - e.g. DATEOFDEATH 2013-11 across 20 patients whose index dates run 2014-12 to 2025-01. No sentinel or placeholder is involved. The shape - a plausible death date, real treatment years later - is consistent with false-positive mortality linkage, a known limitation of composite EHR/obituary/SSDI death data, and is a question for the data provider. The extreme tail is a second, smaller defect: impossible values - DATEOFDEATH 1901-01, 1911-01, 1920-05, 1932-01 against index dates in 2012-2022. DELIVERED EFFECT, measured: FUDUR = 1 day for all 2,799 rows (min = max = 1). The FU_ENDDT pullback moves follow-up end back to the death date, the FUED clamp floors it at the index date, and follow-up collapses to a single day. OS and TTNT are NULL, 285 rwPFS values are negative, DTHFL reads 1. Every step is the spec's; the input is what is wrong. MITIGATION, already delivered and measured exact: DTH_BEFORE_FUED = 1 on all 2,799 rows and on no other row in the table (n_flag_only = 0), so `WHERE dth_before_fued = 1` isolates this population precisely - it neither misses an affected row nor catches a sound one. Release notes must say so, and the data provider should be asked about both defects. WHAT IT DOES MEAN, and what must travel with the release: 'L1+ treated mCRPC' includes patients whose first line began while they were still classified otherwise. Anyone interpreting the treated cohorts as 'first line AFTER becoming mCRPC' would be wrong for 10.5% of cohort 4. Record the two percentages alongside the cohort counts.
- **Evidence:** RE-MEASURED 2026-09-12, post-Q82, per delivered cohort. Cohort 3 (L1+ mHSPC): **4,839 of 78,635 = 6.2%**. Cohort 4 (L1+ mCRPC): **5,309 of 50,327 = 10.5%**. Cohorts 5, 6 and 7: ZERO, expected since later lines start later. Total **10,148**. The exclusion removed patients from numerator and denominator at almost the same rate, so the shape is unchanged - which is the finding, not a coincidence. Superseded figures, kept for the audit trail: SIZED 2026-08-07 as 4,855 of 79,051 = 6.1% and 5,315 of 50,502 = 10.5%, total 10,170. So 10,170 patients are indexed on a line of therapy that began BEFORE the milestone defining the cohort they are in.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **Owner confirmation 2026-08-09:** anchoring stays on the line start date for all baseline windows, OS, TTNT and PFS. CORRECTED same day by the first gate run: OS and TTNT cannot go negative (DTH_BEFORE_FUED, FUED clamp) but rwPFS can and does - 285 rows, sized by V07b.
- **Resolved by Q82, 2026-09-11:** index anchoring on the line start is unchanged, but the death-before-index consequence is gone. A patient whose index date follows their death date now leaves that cohort rather than being retained with a clamped FUED, so the 2,799 rows and all 285 negative rwPFS values disappear at source. The 10,170 patients indexed on a line that predates their MILESTONE still ship, and that part of this row stands - but they are NOT a disjoint population: a pre-milestone line start and a post-death index can sit on the same row, and the open-question queries now applies the exclusion to the very query that produced the 10,170 and the two percentages. All three figures are pre-Q82 and must be re-measured; the overlap has never been measured.
- **202603:** same mechanism, now measured. 202603 joined milestone patients to the numbered line on patientid alone, index_date = line start, no chronology test anywhere - the same shape as here. It was mCRPC-only, so the mHSPC half of the 10,170 has no direct prior counterpart.

### Q39 - CSF_FU

- **Spec reference:** 5B.ClinChars r55-r56
- **Spec says:** The follow-up window for the growth-factor flag has no upper bound: any qualifying record after the index date counts, with no FUED or MAXINDEX limit.
- **We do:** CSF_FU counts qualifying records in (index_date, FUED]. The window is bounded at the patient's own follow-up end.
- **Decision:** Bound the follow-up window at FUED.
- **Why:** A record years after the index date, and after follow-up has ended, still sets the flag. The spec names the period as post-index without stating an end. If the intent is 'during follow-up', the bound should be FUED; if it is 'within the study period', MAXINDEX. RESOLVED 2026-08-07 and IMPLEMENTED. CSF_FU counted any qualifying record after index with no upper bound, so a growth-factor order years after the patient left follow-up still set the flag - which no other follow-up variable does. Now bounded at the patient's own FUED. This lowers CSF_FU for anyone with a late record, so it changes delivered values.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **Changed by Q82, 2026-09-11:** the FUED bound moved in BOTH directions, and the larger effect OPENS the window. Before the ruling a patient whose death fell AFTER their last recorded activity kept FU_ENDDT_preliminary as their FUED, because the old clamp only ever pulled FUED back. FUED is now the later DTHDT, so the window extends and CSF_FU can move 0 -> 1. None of the three growth-factor sources feeds FU_ENDDT_preliminary, so a qualifying record in (last activity, death] is ordinary rather than rare - the golden-patient trace for a death after last activity pulls exactly that patient. The two closing shapes are a NULL FUED and a FUED before the index, which both empty the window and read 0.
- **202603:** no prior surface. Two of the three sources are new tables, and the drug-episode table was never searched for growth factor. The FUED bound is this register's ruling.

### Q40 - FU_ENDDT_preliminary / FUED

- **Spec reference:** 5B.ClinChars r88-r89
- **Spec says:** 202603 derived follow-up end partly from the alpha/beta-emitter and Provenge tables. Those are not in the 202606 definition and are not read here.
- **We do:** Excluded, per the 202606 sheet
- **Decision:** The 202606 sheet is authoritative. Follow-up end excludes the alpha/beta-emitter and Provenge tables.
- **Why:** The 202606 row lists its own sources and those two are not among them, so dropping them is the faithful reading. It does mean a patient whose last recorded contact was one of those therapies now has an earlier FUED, which shortens OS, TTNT and FUDUR follow-up (NOT rwPFS - corrected 2026-09-12: rwPFS censors on LastClinicNoteDate and takes its event date from PFSDT, so it never reads FUED). Confirm the omission is intended rather than an editing slip. RESOLVED 2026-08-07. FU_ENDDT_preliminary uses visit, telemedicine, line-of-therapy end and oral end only, exactly as 5B.ClinChars row 89 lists. No code change. CONSEQUENCE WORTH CARRYING: this can SHORTEN follow-up relative to 202603 for any patient whose last recorded activity was an alpha/beta-emitter or Provenge administration, so OS and FUDUR are not directly comparable across the two cuts for those patients.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **Changed by Q82, 2026-09-11:** this shortening is now CONDITIONAL. It only bites for a patient with NO death date, because FUED is the death date wherever one exists and the four-source FU_ENDDT_preliminary never enters the calculation for them.
- **202603:** also found in the listing: 202603's oral-granularity filter compared 'Year' against a source delivering 'YEAR' - it never fired, so year-level oral ends leaked into its follow-up end. The upper-cased compare here makes the exclusion real (~4.3% of oral rows). FUED can differ across cuts for both reasons.

### Q41 - PFSDT / PFSFL

- **Spec reference:** 6.Outcomes rwPFS
- **Spec says:** IsPseudoProgressionMentioned is not used. It neither qualifies a progression nor vetoes one.
- **We do:** Omitted from the qualifying-evidence list. A row flagged as pseudo-progression still counts if any OTHER evidence flag is true.
- **Decision:** Closed. The build already does what the spec says.
- **Why:** Pseudo-progression is radiographic change that is not true progression, so a row carrying that flag is the one case where the other evidence flags may be misleading. Treating it as a veto is the alternative reading. The spec lists the qualifying flags and does not mention it either way.
- **Evidence:** CLOSED 2026-08-07 on the spec. 6.Outcomes PFSFL reads 'if patient has any progression flag OTHER THAN IsPseudoProgressionMentioned=1 associated with a PROGRESSIONDATE occurring after INDEXDT+14'. The build ORs the other six evidence flags and omits IsPseudoProgressionMentioned entirely, so a row flagged as pseudo-progression qualifies only if some other evidence flag is also true. That is the spec's wording exactly. No ambiguity to rule on.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** no prior surface - no rwPFS, no progression table (Q34). Neither-qualifies-nor-vetoes is the spec's reading.

### Q42 - TTNT / TTNTFL

- **Spec reference:** 6.Outcomes TTNT
- **Spec says:** The next-treatment date is taken from the next line's start date with no explicit requirement that it fall after the index date.
- **We do:** next_trt_dt = the next line's start date, unconditioned
- **Decision:** No change. The condition is satisfied by the data.
- **Why:** Closed on evidence, not judgement. Note this is a statement about 2026m06, not a guarantee: if a future cut introduces two lines starting the same day, the source gate in Q24 catches it before the build writes anything.
- **Evidence:** CLOSED 2026-08-07. Counting consecutive line pairs within a patient and setting where the next line starts on or before the current one: NO ROWS RETURNED, in either mHSPC or mCRPC. The next-treatment date is therefore always strictly after the index date, so the missing explicit condition costs nothing on this data cut.. Re-run 2026-09-12: no rows, Q42b clean.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **Reopened 2026-08-08.** The closing evidence counted consecutive lines WITHIN a setting and found none out of order. Cohort 3 does not use a within-setting pair: its next treatment is the earlier of mHSPC LOT2 and mCRPC LOT1, so the chronology that matters there is mHSPC LOT1 against mCRPC LOT1 - a CROSS-SETTING comparison the query never made. The formula is not in doubt; the closure is. Run the cross-setting pair and this row can close properly. The query is now written. It rebuilds the delivered cohort 3 - mHSPC line 1 with both the line start and the mHSPC milestone inside the index window - joins each patient's first mCRPC line, and counts those starting on or before the index date. `n_le = 0` closes the row. `n_before` and `n_same` are reported apart, because a same-day start gives a TTNT of one day, which is degenerate rather than impossible.
- **Closed on evidence 2026-08-08, Q42b run on 2026m06.** `n_cohort3` 79,051; `n_with_mcrpc_l1` 21,887; `n_le` 0; `n_before` 0; `n_same` 0; `worst_gap_days` 28. So of the 79,051 patients in the delivered L1+ treated mHSPC cohort, 21,887 also have a first mCRPC line - the comparison is not vacuous - and NONE of them starts it on or before their index date. The closest any comes is 28 days after, which puts the smallest possible cohort-3 TTNT at 29/30.4375 = 0.95 months. Both limbs of cohort 3's `min(mHSPC LOT2, mCRPC LOT1)` are now proven strictly after index: the within-setting limb by the original Q42 query, the cross-setting limb by this one.
- **The query reproduced the cohort exactly.** `n_cohort3` = 79,051 is the same figure Q38's independent sizing reports for cohort 3, which is a check on the query as well as on the answer - a rebuild that had the population wrong would not land on that number.
- **Also changed by Q82, 2026-09-11:** for a RETAINED patient the death date itself can move EARLIER, because W2 and W3 are withdrawn, so a death-driven TTNT event date moves with it and the delivered TTNT shortens by up to a fortnight. The same applies to a death-derived PFSDT and so to rwPFS (Q34). Neither is sized - no post-ruling run exists - and both must be re-measured rather than assumed unchanged.
- **Changed by Q82, 2026-09-11:** the DTH_BEFORE_FUED guard this row lists as a live 202606 feature is now unreachable - where a death date exists FUED IS that date. TTNT's formula is unchanged and kept verbatim; its censored branch reads FUED and can go negative for a patient with no death date (Q83).
- **202603:** the rule is 202603's own: pmin(next line start, dthdt), unconditioned, resting on the same within-setting ordering. New by spec: cohort 3's cross-setting candidate (Q42b measured zero violations), the DTH_BEFORE_FUED guard, and missing instead of 202603's literal 0. The ID3MOSFU condition remains in both cuts.

### Q43 - Build identification

- **Spec reference:** n/a - run governance
- **Spec says:** Should every run carry a mandatory unique build ID, applied to all 43 stage tables, the output table and the manifest, with fail-if-exists rather than replace?
- **We do:** No build ID. Stage and output names are stable and written with replace=TRUE. The constant 'uat' tag was removed because a constant tag isolates nothing, and the staging copy was removed too (Q27), so a re-run replaces the delivered table directly.
- **Decision:** Keep stable table names written with replace=TRUE. No per-run build ID.
- **Reversed 2026-09-12:** by Onkar Kshirsagar. The 2026-08-07 approval was given on condition of a formal sign-off, and that sign-off turned out to be a checklist reading overwritable tables that carry no build identity - so the condition was never really met. **Both halves are now to be built:** a build identity recorded in the delivered table, and a promotion step so the table is not live before validation runs. The 2026-08-07 objection - that a suffix on 45 objects is a large change - is overruled rather than answered, and the identity columns change the delivered column contract, which is why this is a decision and not a preference. Both are **deferred to the next cut**, decided 2026-09-12: both change the delivered column set or the table's name, and doing either between a signed decision and an unbuilt table is the wrong order - it would also have made the pre-ruling snapshot compare two different contracts. **What 202606 therefore delivers is the 2026-08-07 behaviour**, with the risk accepted in writing - see section 10 - and the build identity recorded by hand as the only provenance. The QC stamp still describes the CHECKER, not the build. Q27 is the same mechanism from the other end, reversed with it. The superseded decision is kept above, not deleted - an audit trail needs the thing that changed.
- **Why:** NOT IMPLEMENTED - this reverses a decision already taken, so it is recorded rather than actioned. The argument for it is sound: QC evidence should refer to the exact table being published, and replace=TRUE means it may not. The argument against is that it puts a suffix on 45 objects - 43 stage tables, the ADS and the manifest for a risk that a disciplined single-threaded run process also removes. Needs an owner's ruling, not a code change made on a reviewer's say-so. RECLASSIFIED from 'no' to 'values': with stable names and replace=TRUE, a re-run or an overlapping run can change every value in the table QC already reviewed. The reviewer also reframes it, fairly - a mandatory unique ID is not restoring the constant tag, it is replacing an ineffective constant with real identity. Still an owner's call, not a code change made unilaterally. RESOLVED 2026-08-07: current behaviour confirmed. Also an accept-the-risk decision. RESIDUAL RISK: a rerun silently overwrites whatever QC last reviewed, and nothing in the output records that it happened - program_version is a hand-maintained label that cannot tell two runs of the same code apart, and RUN_MANIFEST is regenerated by each run. Two builds also cannot coexist for comparison. This does NOT reinstate the constant 'uat' tag that was removed earlier: that was removed correctly, because a constant tag isolates nothing. The question here was a UNIQUE per-run ID, which is a different mechanism, and it is declined for now. WHAT WOULD CHANGE THE ANSWER: a formal QC sign-off step. The moment someone signs off on a specific table, that table needs to be immutable or the signature means nothing. Revisit before any release that is reviewed rather than exploratory.
- **Evidence:** Review (2026-08) recommends a mandatory unique ID with no default. The concrete risk: a re-run silently replaces the exact table QC reviewed, and two overlapping runs by one analyst in one schema interleave their stages. Different personal schemas separate USERS, not RUNS.
- **Reopened in effect 2026-09-12:** this row was accepted on the reasoning that formal sign-off is what would require an immutable build identity. The release sign-off IS that formal sign-off, and it signs a table `replace = TRUE` can overwrite, against QC tables whose stamps carry a time and a target but no build identity. The acceptance stands as recorded; the condition it rested on has arrived, so the checklist carries a manual build-identity step and names this row as an owner decision rather than a settled one.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **Scope extended 2026-08-09.** The check-result tables share this risk: stable names, replace-on-write, no build id. Each check now writes a stamp row with the target table and a server-side timestamp, which dates the evidence but cannot distinguish two builds under one name. The full fix is the same build id this row asks for.
- **202603:** matches - 202603 ran the same stable-name replace-on-write with no build id.

### Q44 - HRR_INDEX gene inventory

- **Spec reference:** 5B.ClinChars r70/r74
- **Spec says:** Should the governed build freeze the exact 19 approved gene symbols instead of using every gene present in the biomarker table?
- **We do:** flatiron_all names the 19 approved gene symbols explicitly. A source check announces drift in both directions - a gene present in the table but off the frozen list, and a listed gene absent from the cut.
- **Decision:** Freeze the 19 approved symbols; do not track the table's contents.
- **Why:** NOT IMPLEMENTED - Q05 decided flatiron_all deliberately, on the grounds that a list cannot go stale or miss an alias. Freezing inverts that: it cannot silently widen, but it CAN silently narrow if the source renames a symbol, and it needs maintaining. The review's point stands that a self-changing case definition is unusual in a governed product. This is the same decision as Q05 seen from the other side and should be settled with Q05 and Q28 together. RESOLVED 2026-08-07 and IMPLEMENTED. The case definition is now the study's rather than Flatiron's. The signal that was missing comes for free: the excluded-gene report lists genes present in the biomarker table but absent from the panel, and with the list frozen it will announce any gene a future cut adds - where previously flatiron_all meant that report was empty by construction and a new gene entered HRR silently. Delivered values are unchanged for 2026m06, since the frozen 19 are exactly the 19 the table currently holds.
- **Evidence:** A source check reports unexpected genes as a warning and names drift in both directions. Neither blocks publication.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** no prior surface (Q37). The freeze had nothing to weigh against.

### Q45 - FUED

- **Spec reference:** 5B.ClinChars r91 (FUED)
- **Spec says:** The FUED definition ends 'If INDEXDT<FUED, then FUED=INDEXDT'. Taken literally that clamps FUED down to the index date for every patient who HAS follow-up, which would zero out OS, TTNT and PFS for the whole cohort. The condition is inverted.
- **We do:** HISTORICAL, superseded by Q82 on 2026-09-11. Until then: FUED = max(FU_ENDDT, INDEXDT), coded as CASE WHEN fu_enddt > index_date THEN fu_enddt ELSE index_date END - the sensible reading of 'if FUED < INDEXDT then FUED = INDEXDT'. The build no longer contains that expression: FUED is now COALESCE(DTHDT, FU_ENDDT_preliminary) with no reference to the index date at all, so there is nothing left for either reading of the clause to apply to.
- **Decision:** Build's reading confirmed; correct the spec, not the code. SUPERSEDED 2026-09-11 (Q82): the clamp is gone entirely - FUED no longer references the index date at all, so neither the spec's literal reading nor this errata correction applies any more.
- **Why:** Same class as Q07 and Q18: a reading slip in the spec where the data and the surrounding logic make the intent unambiguous. Implemented to intent, not to the letter. Flagged so the spec is corrected rather than silently worked around, and so nobody re-reads the row later and 'fixes' the code to match it. APPROVED 2026-08-07 as part of the nine-item spec errata block (this file). The build's reading is confirmed correct and the SPEC is what gets corrected; no code change. Approved as a block because in each case the literal spec text is self-evidently not the intent - most starkly Q45, which taken literally clamps FUED to the index date for every patient with follow-up and would zero OS, TTNT, PFS and FUDUR across the study.
- **Evidence:** HISTORICAL - read from the spec 2026-08-07, before Q82 replaced the whole FUED definition. The rest of the FUED row is implemented verbatim: FUED = FU_ENDDT_preliminary; if FU_ENDDT_preliminary > DEATH_DT_preliminary, then FUED = max line-of-therapy end date when the death month and year match it, else DEATH_DT_preliminary. Only the final clamp is inverted. The literal reading is self-evidently not intended - it would make FUED equal INDEXDT for essentially every patient and every time-to-event variable would be 1/30.4375 months.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** 202603 used the identical clamp word for word, so follow-up could not go negative in either cut. Its negatives lived downstream: a DTHFUFL_dur interim (computed, dropped) and an OS with no death-before-follow-up exclusion. Both clamps are now history: the 2026-09-11 ruling (Q82) removed the index floor outright, and the death-before-index population it used to mask is excluded from its cohort instead. The 285 negative rwPFS values go too - not because the clamp produced them, since rwPFS never read FUED, but because they came from PFSDT = DTHDT falling before the index and the exclusion removes the patients that produced them. What survives is narrower and new - a patient with NO death date whose last activity precedes their index (Q83) - which had no counterpart in either cut, because the floor made it impossible.

### Q46 - PRIOR_DOCITAXEL / PRIOR_ABIRATERONE

- **Spec reference:** 5C.TreatVars r35-r42
- **Spec says:** Two prior-therapy VARIABLE NAMES are malformed in the spec. Row 40 names the docetaxel flag PRIOR_DOCITAXEL - 'DOCITAXEL', misspelt - and its label reads 'Docitaxel received prior to index'. Row 41 names the abiraterone flag PRIOR+ABIRATERONE, with a PLUS SIGN where every other variable has an underscore. Column names are part of the delivered contract, so both need a ruling rather than a silent choice.
- **We do:** Delivered as PRIOR_DOCETAXEL and PRIOR_ABIRATERONE. Both spec spellings corrected.
- **Decision:** Correct to PRIOR_DOCETAXEL and PRIOR_ABIRATERONE.
- **Why:** The two are treated differently on purpose, and that asymmetry is the thing to confirm. A misspelt-but-legal name is still a name a downstream consumer can code against, so changing it would break them; an illegal name cannot be delivered at all, so it had to be changed. If the study team would rather PRIOR_DOCITAXEL were corrected to PRIOR_DOCETAXEL, say so before release - it is a one-line change here and in the column contract, but it is not reversible once consumers are reading the table. RESOLVED 2026-08-07: correct all three to clean names. Delivered as PRIOR_DOCETAXEL, PRIOR_ABIRATERONE and LOT4CATN_MCRPC. This DIVERGES from the spec's column list on purpose - the spec is what gets corrected (errata E13). The asymmetry that used to exist here is gone: the build no longer preserves one slip while fixing another. Note the consequence: any consumer already coding against PRIOR_DOCITAXEL or LOT4CATN must change, which is why this was worth ruling on before release rather than after.
- **Evidence:** Read from the spec 2026-08-07. Every other variable on the sheet uses underscores, and '+' is not a legal character in an unquoted column name in Spark SQL or SAS, so the plus is a typing slip rather than an intended name. The misspelling in DOCITAXEL is legal, so it was preserved on the principle that the spec names the deliverable.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **Duplicate of Q08, marked 2026-08-08.** Same two variable names, same correction. Q46 carries the fuller account of what the spec prints; Q08 is the row cited first in code. Read Q08 and treat this as its long form.
- **202603:** duplicate of Q08 - see that note.

### Q47 - OS

- **Spec reference:** 6.Outcomes r4 (OS)
- **Spec says:** The OS formula reads OS=(death_dt - INDEXDT + 1)/30.4375. There is no variable called death_dt. 5B.ClinChars defines DEATH_DT_preliminary and DTHDT, and the two differ: DTHDT promotes the date to the last day of the month when the death month and year match both FUED and max_lotend_dt. Which one OS should use is not stated.
- **We do:** OS uses DTHDT, the delivered Date of Death.
- **Decision:** Build's reading confirmed; correct the spec, not the code.
- **Why:** Low risk but not zero. The two dates differ only for patients whose death month and year match both FUED and the last line-of-therapy end date; for those, DTHDT is the last day of the month and DEATH_DT_preliminary is the 15th, so OS differs by up to about half a month. Everyone else is unaffected. DTHDT is the better reading and is what ships; flagged so the choice is on the record rather than assumed. APPROVED 2026-08-07 as part of the nine-item spec errata block (this file). The build's reading is confirmed correct and the SPEC is what gets corrected; no code change. Approved as a block because in each case the literal spec text is self-evidently not the intent - most starkly Q45, which taken literally clamps FUED to the index date for every patient with follow-up and would zero OS, TTNT, PFS and FUDUR across the study.
- **Evidence:** Read from the spec 2026-08-07. DTHDT is the variable actually delivered as 'Date of Death'; DEATH_DT_preliminary is explicitly named 'preliminary' and exists only as an intermediate. OS sits directly beneath DTHFL on the same sheet, and DTHFL is defined from DTHDT, so the surrounding rows read as though DTHDT is meant.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **Changed by Q82, 2026-09-11:** the choice this row makes is now VALUE-NEUTRAL: W3 is withdrawn, so DTHDT = DEATH_DT_preliminary on every row (and the delivered-column comparison confirms it) and OS is identical under either reading. The 'up to about half a month' difference described in Why is no longer reachable. Separately, the DTH_BEFORE_FUED exclusion this row describes is now unreachable - where a death date exists FUED IS that date, so DTHDT < FUED cannot hold. The formula is kept verbatim because the spec still states it; the work it did is done upstream by the cohort exclusion. OS's alive branch can now go negative for a patient with no death date (Q83).
- **202603:** the arithmetic matches - DTHDT/FUED anchors, +1, 30.4375 - so DTHDT over the preliminary is also how 202603 read it. Spec-driven changes: the ID3MOSFU gate is gone, and OS nulls under DTH_BEFORE_FUED where 202603 could deliver a negative. Beyond eligibility, the FUED (Q40) and DTHDT (Q66) input differences shift OS too.

### Q48 - COHORT

- **Spec reference:** 4.StudyPop r11 (COHORT)
- **Spec says:** The COHORT row gives two different label sets in two adjacent columns. The Values column lists 'Overall - mHSPC, Overall - mCRPC, 1L - mHSPC, 1L - mCRPC, 2L - mCRPC, 3L - mCRPC, 4L - mCRPC'. The Definition column assigns COHORT='Overall mHSPC', 'L1+ treated mHSPC', 'L1+ treated mCRPC', 'L2+ treated mCRPC' and so on. The two disagree on every treated cohort and on the dash in the Overall ones.
- **We do:** The Definition form ships: 'Overall mHSPC', 'Overall mCRPC', 'L1+ treated mHSPC', 'L1+ treated mCRPC', 'L2+ treated mCRPC', 'L3+ treated mCRPC', 'L4+ treated mCRPC'.
- **Decision:** Ship the Definition-column form: 'L1+ treated mCRPC' etc.
- **Why:** COHORT is a delivered character column that downstream code will filter on, so the exact string matters even though the cohort membership does not change. The Definition form was chosen because it is the assigning clause rather than a summary of it. If any downstream table or TLF already keys on '1L - mHSPC', this needs to change before release - it is a pure relabel, but a breaking one once consumers exist. RESOLVED 2026-08-07. The Definition column is the clause that performs the assignment, so its labels are the delivered strings. No code change - the build already emits them. Cohort membership and COHORTN are identical under either reading, so only the character column was ever at stake.
- **Evidence:** Read from the spec 2026-08-07. The Definition column is the one that actually performs the assignment, and 6.Outcomes refers to the cohorts by the same '[1L mHSPC cohort]' style shorthand without settling the literal string either. COHORTN 1-7 is unambiguous and identical under both readings, so only the character column is affected.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** the labels come from the Definition column. 202603's four labels spaced the plus ('L1 + treated mCRPC'), so normalise before joining on the label string.

### Q49 - CSD

- **Spec reference:** 5C.TreatVars r23 (CSD)
- **Spec says:** The CSD row gives two incompatible instructions. Its prose says the regimen is 'Clinical Study Drug' in the DrugEpisode table. Its pseudo-code is index(LOT1_MCRPC,"CSD") and so on per cohort - a SAS substring search for the three letters CSD, against LINENAME from the LOT table. Flatiron spells the value out as 'Clinical Study Drug', which does not contain the substring 'CSD', so the pseudo-code as written matches nothing and CSD would be 0 for every patient. The two also name different source tables.
- **We do:** Matches on the spelled-out string: LINENAME LIKE '%clinical study drug%'. For the two Overall cohorts, any line in the cohort's setting; for the five treated cohorts, the index line's LOTn_<SETTING> value - which is the per-cohort structure the pseudo-code lays out.
- **Decision:** Build's reading confirmed; correct the spec, not the code.
- **Why:** Implemented to intent, like Q07 and Q45. Flagged because the deviation is not visible from the code alone: a reader checking the code against the pseudo-code would think it is wrong. The source-table discrepancy is the part still worth a ruling - the prose says DrugEpisode while the pseudo-code says LINENAME/LOTn from the LOT table, and the build follows the pseudo-code. For a line whose LOT-level LINENAME omits a study drug that appears on an individual drug episode, the two would disagree. APPROVED 2026-08-07 as part of the nine-item spec errata block (this file). The build's reading is confirmed correct and the SPEC is what gets corrected; no code change. Approved as a block because in each case the literal spec text is self-evidently not the intent - most starkly Q45, which taken literally clamps FUED to the index date for every patient with follow-up and would zero OS, TTNT, PFS and FUDUR across the study.
- **Evidence:** Read from the spec 2026-08-07. The prose names the real value and the pseudo-code names an abbreviation of it; 'CSD' is not a value that appears in LINENAME. Taking the pseudo-code literally produces an all-zero column, which is self-evidently not the intent. Note the same spelled-out string is what category 15 of LOTnCAT ('Clinical study drug-containing') matches on, and that category is verified against the spec, so the two are consistent with each other.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** the flag is new, but 202603's category 15 matched the same spelled-out '%clinical study drug%' - agreeing with this row's reading over the pseudo-code's 'CSD'. The per-cohort split and source question are new.

### Q50 - REGION1 / REGION1N / PRACTIC / PRACTICN

- **Spec reference:** 5A.Demos r14/r15, r20/r21
- **Spec says:** Both variables carry a residual level the spec's Values list does not contain. REGION1's list is Northeast/Midwest/South/West/Other region/Missing with REGION1N 1-6, but a state that is present and in none of those lists falls through. PRACTIC's list is the three practice types with PRACTICN 1-3, but the spec's final branch is an unconditional 'else then = Both academic and community', which would label a patient with NO practice record as both.
- **We do:** Residual code 99, per the fallthrough convention.
- **Decision:** 99 is the fallthrough code.
- **Why:** Same pattern as Q31 (STAGEN gets a 6 where the spec lists 1-5): the spec enumerates only clean values and gives no code for missing or unclassifiable. Three variables now do this and they do it INCONSISTENTLY - STAGEN uses the next integer (6), REGION1N uses the next integer (7), PRACTICN uses 99. That inconsistency is the thing to settle, not just whether a residual should exist. CONVENTION SET 2026-08-07 by the data product owner: 99 is the fallthrough sentinel for a category the spec's Values list does not code. Applied to every build-invented residual: AGEGR1N, REGION1N, STAGEN, PRACTICN and COHORTUN all now use 99, where before they used 8, 7, 6, 99 and 99. An earlier attempt went the other way - it made PRACTICN 4 on a 'next integer after the spec's last code' rule inferred from what four of the variables happened to do. That was wrong: 99 is a recognisable sentinel and a low integer sitting beside real codes is not. Reverted the same day. NOT changed: RACEN 5, ETHN 3, GLEASONN 3 and ECOGN 6 are all codes the spec's own Values lists provide, not residuals this build invented. RESOLVED 2026-08-07: 99 confirmed as the fallthrough code, applied to every build-invented residual - AGEGR1N, REGION1N, STAGEN, PRACTICN and COHORTUN.
- **Evidence:** Read from the spec 2026-08-07. The REGION1 residual is arguably required by the spec's own Additional Notes, which say 'Academic centers all set to unknown' - an Unknown the Values list then omits. The PRACTIC residual is a deliberate departure: taking the spec's unconditional else literally would assign 'Both academic and community' to a patient with no practice records at all.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** 202603 used positional next-codes (agegrln 8, regionln 6/7) and 99 only for practicn/stagen. The uniform 99 convention is this cut's; map before comparing.

### Q51 - SES

- **Spec reference:** 5A.Demos r22
- **Spec says:** The SES Values list is '1 - lowest SES, 2, 3, 4, 5 - highest SES, Null'. The spec asks for NULL when the socialdeterminantsofhealth index is absent. The build writes the literal string 'Missing' instead.
- **We do:** ses = sesindex2015_2019, passed through unchanged. An absent socialdeterminantsofhealth record now stays NULL, as the spec's Values list asks.
- **Decision:** Leave SES NULL when the source record is absent, per the spec.
- **Why:** RESOLVED and FIXED. The spec lists 'Null' as a value of SES in its own right alongside 1-5, so NULL is specified behaviour, not an omission. The previous code wrote the string 'Missing', which made 'WHERE ses IS NULL' return nothing and made SES the only column in the ADS encoding absence as text rather than NULL. Owner directed the fix on 2026-08-07. CONSEQUENCE TO EXPECT ON THE NEXT RUN: SES now carries NULLs where it previously carried a string, so the null sweep's n_ses will drop below n_rows. That is correct, not a regression - the sweep only flags a column as a defect when it is entirely empty or constant, so no waiver was needed. If SES does come back entirely null, that is a real data finding about t_socdetofhealth coverage and should be investigated rather than waived.
- **Evidence:** Read from the spec 2026-08-07. 'Null' is listed as a value in its own right alongside 1-5, so it is specified behaviour rather than an omission - unlike Q50, where the spec simply has no branch for the case.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** 202603 substituted the string 'Missing' for a null SES. The Values list ends in Null, so NULL ships - that population moves levels across cuts.

### Q52 - INDEXDT (Overall cohorts) / MHSPCDD / MCRPCDD

- **Spec reference:** 4.StudyPop sB / 6.Outcomes r2 (INDEXDT, cohorts 1-2)
- **Spec says:** The milestone dates that index the two Overall cohorts are not always day-granular. t_enh_prostate carries hspcdategranularity DAY 701 / MONTH 197 / YEAR 155 - about 15% of HSPCDate values are year-level. crpcdate is DAY 381 / MONTH 7 / YEAR 2 and metastaticdiagnosisdate is DAY 590 / MONTH 49 / YEAR 11. INDEXDT for cohort 1 is max(MetastaticDiagnosisDate, HSPCDate) and for cohort 2 max(MetastaticDiagnosisDate, CRPCDate), so a year-level component can become the index date - but only when it is the LATER of the two, which the profile cannot tell us.
- **We do:** The milestone date is used as INDEXDT verbatim for cohorts 1-2, whatever its granularity. No granularity column is carried into the ADS.
- **Decision:** Accept the index-date granularity and record it with the release.
- **Why:** Narrower than first stated, and now about the Overall cohorts rather than the treated ones. A year-granular HSPCDate almost certainly lands on 1 January, so where it is the later of the two components it sets an index date that can be up to a year early, and everything anchored on index inherits that - OS, FUDUR, and the [-30,+7] biomarker and ECOG windows. Whether it actually propagates depends on which component wins the max(), which needs the component-split query. Note the spec DOES respect granularity elsewhere, in the FU_ENDDT oral-end-date rule, so the concept is in its vocabulary and is simply absent from the index-date definition. RESOLVED 2026-08-07: accept and document. Roughly 17% of Overall mHSPC index dates are not day-level - 13.00% MONTH and 4.01% YEAR (7,943 patients) - against 3.86% for Overall mCRPC. A year-granular value almost certainly resolves to 1 January, so for those patients OS, FUDUR and the [-30,+7] biomarker and ECOG windows are all measured from a date that can be up to a year early. MUST BE CARRIED WITH THE RELEASE, not left in this register: anyone doing time-to-event analysis on cohort 1 needs the number. Cohorts 3-7 are NOT covered by this - the LOT table records no granularity at all, so their index-date precision is unknowable rather than merely unmeasured.
- **Evidence:** CORRECTED 2026-08-07. This row previously claimed the LOT table's startdate was DAY 209,271 / MONTH 46,992 / YEAR 11,401 and that a fifth of LOT-cohort index dates were therefore imprecise. That was WRONG: t_enh_prostate_lot has no granularity column at all, and those three counts sum to 267,664, which is exactly the row count of t_enh_prostate_ORALS - the table they actually describe. There is no evidence either way about LOT startdate precision, so cohorts 3-7 are NOT implicated by anything read so far. The orals figure is not wasted: 5B.ClinChars r89 excludes oral end dates where dategranularity = 'Year' from FU_ENDDT_preliminary, so roughly 4.3% of oral rows are dropped by a rule the spec already states and the build already implements. The milestone granularities above come from t_enh_prostate in the profiler and stand. SIZED 2026-08-07 by counting the granularity of the component that WINS the max(). Cohort 1 (Overall mHSPC): DAY 164,240 (82.99%), MONTH 25,720 (13.00%), YEAR 7,943 (4.01%). Cohort 2 (Overall mCRPC): DAY 129,092 (96.14%), MONTH 4,506 (3.36%), YEAR 683 (0.51%). So 8,626 patients across the two Overall cohorts have an index date derived from a year-level component, and 33,663 patients in cohort 1 alone - 17% - have an index date that is not day-level.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **Owner confirmation 2026-08-09:** the source-resolved milestone date stands as the index. The ~17% cohort-1 figure travels with the release.
- **Changed by Q82, 2026-09-11, and RE-MEASURED 2026-09-12:** cohort 1 non-day index dates **17.01%** (MONTH 12.99, YEAR 4.02, ties 0.00) on 196,549 patients; cohort 2 non-day **3.87%** on 133,299. The pre-Q82 ~17% holds. Recorded from source on 2026-09-12; the query rebuilds cohort membership from source and carries the exclusion, so it needed no rebuild. The figures below in Why and Evidence are PRE-Q82 and are kept for the audit trail. The cohort-1 split sums to 197,903 and the cohort-2 split to 134,281 - exactly the two frozen baselines the exclusion moves - and the open-question queries now applies the exclusion to the granularity query itself, because a patient whose milestone index falls after their death date is not in the cohort and their granularity is not a delivered granularity. The ~17% figure does not travel with the release until it is re-run.
- **202603:** 202603 applied no granularity handling to its index date either - same behavior. It was mCRPC-only; the ~17% figure is cohort 1 (mHSPC), which has no direct prior counterpart.

### Q53 - DTHFL

- **Spec reference:** 5B.ClinChars r93 (DTHFL)
- **Spec says:** DTHFL's definition reads 'if DTHDT>. then 1, else 0'. Read as English this looks truncated mid-comparison, and it was recorded that way. It is not truncated.
- **We do:** dthfl = CASE WHEN dthdt IS NOT NULL THEN 1 ELSE 0 END
- **Decision:** No change. The build already transcribes the spec exactly.
- **Why:** Closed by correcting a misreading of unapproved, not by a ruling. the earlier reading of a SAS missing-value literal as truncated text, filed it as a cosmetic erratum, and review then correctly pointed out that a truncated DTHFL would be output-affecting rather than cosmetic - both of us reasoning from the same wrong premise about the text. The untruncated file settles it. V40 stays: it now asserts a reading rather than an inference, which is still worth gating because DTHFL drives the event-versus-censor branch of OS and feeds PFSFL and TTNT.
- **Evidence:** RESOLVED 2026-08-07 from the untruncated spec text supplied by the owner. The '.' is the SAS NUMERIC MISSING literal, and 'DTHDT > .' is the standard SAS idiom for 'DTHDT is not missing' - missing sorts below every number, so the comparison is true for any populated value. The definition is complete SAS, not a sentence that lost its ending. The build codes CASE WHEN dthdt IS NOT NULL THEN 1 ELSE 0 END, which is that idiom translated to SQL. This is a TRANSCRIPTION, not an inference - which is the opposite of how this row and SPEC_ERRATA E11 described it.
- **Approved:** Onkar Kshirsagar, 2026-08-07
- **202603:** identical in both cuts: dthfl = 1 exactly when dthdt is present.

### Q54 - FU_ENDDT_preliminary

- **Spec reference:** 5B.ClinChars r89 (FU_ENDDT_preliminary)
- **Spec says:** The oral-therapy source is named 't_enh_metcrc_oral_&date'. 'metcrc' is metastatic COLORECTAL cancer - the table belongs to a different tumour type, and no such table exists in the prostate input contract.
- **We do:** Reads t_enh_prostate_orals, the prostate equivalent.
- **Decision:** Confirmed: a relic of a colorectal spec. The build's t_enh_prostate_orals is correct. Spec erratum E15 stands; no code change.
- **Why:** RESOLVED 2026-08-08 by the owner. This closes the register. The row is kept rather than deleted because it is the single clearest piece of evidence about how this spec was assembled: every other table in that same FU_ENDDT_preliminary definition uses the &cohort placeholder (t_&cohort_visit_&date, t_&cohort_telemedicine_&date, t_&cohort_lineoftherapy_&date) and only the oral one is hard-coded - to the wrong tumour type. That provenance is the reason several other errata exist (E16's LABNEUV tie direction, E18's PSA_INDEX anchor note), and it is the standing argument for treating unverified spec text as suspect rather than authoritative at the next refresh.
- **Evidence:** Found in the untruncated spec text supplied 2026-08-07. Every other table in the same definition is named with the &cohort placeholder (t_&cohort_visit_&date, t_&cohort_telemedicine_&date, t_&cohort_lineoftherapy_&date); only the oral one is hard-coded, and hard-coded to the wrong tumour type. It is a copy-paste from a colorectal spec.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** matches - 202603 read t_enh_prostate_orals too; the colorectal name is a spec slip.

### Q55 - LABPLA

- **Spec reference:** 5B.ClinChars r21 (LABPLA)
- **Spec says:** Q07 records that LABPLA's 'Present' clause names testbasename='hemoglobin' while its own 'Missing' clause names 'platelets' - a copy-paste slip. Two independent readings of the same spec page disagree. The earlier reading says 'hemoglobin'; the spec text says 'platelets', i.e. no slip at all.
- **We do:** The build filters testbasename = 'platelets' for LABPLA, which is correct under EITHER reading. No delivered value depends on resolving this.
- **Decision:** No spec defect on the LABPLA row. Q07's LABPLA limb is WITHDRAWN. Q07's LABBIL limb stands - it is corroborated by the spec text and by the data.
- **Why:** No code change: the build has always filtered testbasename='platelets', so no delivered value was ever affected. What was wrong was the documentation - a code comment in 03_clinical.R and three passages in SPEC_RECONCILIATION.md asserted a spec defect that does not exist. All four corrected. WHY THIS IS WORTH THE ROW: an erratum list is only useful if it is trustworthy, and a false entry is worse than a missing one - it invites someone to 'fix' correct code to match a defect that was never there.
- **Evidence:** RESOLVED 2026-08-08 by the owner, reading the spec directly: the Present clause names testbasename='platelets', matching its own Missing clause. The spec text agrees. The earlier reading of 'hemoglobin' was wrong - and wrong TWICE, on two separate passes of the page, both made while looking for the slip register Q07 had already told me to expect. That is the confirmation bias I flagged when raising this row, confirmed.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** no prior surface - t_lab is new.

### Q56 - ECOG (cohorts 3-7)

- **Spec reference:** 5B.ClinChars r47 / 3.Data Prep LOT_ECOG
- **Spec says:** Does the [INDEX-30, INDEX+7] window apply to the treated cohorts? Cohorts 1-2 applied it; cohorts 3-7 selected baseline ECOG by line number and line start date with NO date bound at all.
- **We do:** The window now applies to all seven cohorts.
- **Decision:** Keep the window on all seven cohorts. Confirmed by measurement, not by argument: it removes zero rows.
- **Why:** RESOLVED 2026-08-08 on evidence. The expected drop in ECOG completeness for cohorts 3-7 does not occur - it cannot, because Flatiron's baseline-ECOG table is already bounded to exactly [INDEX-30, INDEX+7]. The filter is therefore redundant TODAY but is retained deliberately: it makes the spec's stated LOT_ECOG assessment period explicit in our code instead of silently inherited from a vendor table's construction. If a future refresh widens that table, the build keeps the spec's window and the delivered values do not move. Zero cost, real insurance.
- **Evidence:** MEASURED 2026-08-08 (2026m06 cut). The window costs NOTHING: n_lost = 0 in all five treated cohorts (3: 47,225 rows; 4: 34,427; 5: 21,526; 6: 12,643; 7: 7,048 - every one kept). The reason is visible in the same result: across all five cohorts MIN(gap) = -30 and MAX(gap) = +7 EXACTLY. t_enh_prostate_bsln_ecog is itself constructed on the [-30, +7] assessment window, so no record outside it exists to be dropped.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** 202603 applied [-30,+7] to every cohort - it had no unbounded path. Spec and prior code agree; S4 showed the window costs nothing.

### Q57 - DTHFUFL

- **Spec reference:** 5B.ClinChars r96 (DTHFUFL)
- **Spec says:** The definition and the stated purpose disagree. Definition: 'If DTHDT-FUED <=120 days then DTHFUFL=1; else 0'. Purpose, from both the row's notes and 3.Data Prep Section C item 7: flag patients whose PRELIMINARY death date is 120 days or more BEFORE the PRELIMINARY end of follow-up, because that suggests bad data.
- **We do:** DATEDIFF(death_dt_preliminary, fu_enddt_preliminary) <= 120 -> 1, else 0. NULL only when there is no death date - the pre-Q57 rule, carried forward unchanged. The spec's arithmetic and polarity are kept verbatim; only the inputs moved off the final DTHDT/FUED.
- **Decision:** Keep the definition's literal formula, move it onto the PRELIMINARY dates the notes name (DEATH_DT_preliminary and FU_ENDDT_preliminary). Do not flip the sign.
- **Why:** RULED 2026-08-08. WHY THE INPUTS MOVED: FUED is clamped toward the death date before this point, so on the final dates the discrepancy the notes describe has already been closed - DTHFUFL read 1 for essentially every death by construction and could not detect the thing it exists for. The preliminary dates are the only place it is still visible, and 5B.ClinChars r96 and 3.Data Prep Section C item 7 both name them explicitly. WHY THE SIGN DID NOT FLIP: the owner chose to keep the spec's arithmetic rather than reinterpret what the value 1 means. KNOWN LIMITATION, accepted: '<= 120' is satisfied by a large NEGATIVE difference, so a death 120+ days BEFORE the preliminary follow-up end - the suspect case - still scores 1, the same as an ordinary death. CORRECTION 2026-08-08, made after review: an earlier version of this row said the suspect case is 'reported by DTH_BEFORE_FUED'. THAT WAS WRONG. DTH_BEFORE_FUED compares the FINAL dthdt and fued, and fued has already been clamped toward the death date, so the preliminary discrepancy is closed before that flag is computed as well. Nothing in the delivered 190 columns identifies the narrative suspect case. That is a real consequence of the ruling and it is accepted, but it must not be described as covered elsewhere. REVERTED OVERREACH, same review: the first implementation ALSO returned NULL when FU_ENDDT_preliminary was absent. The spec's Values list is '0 = No; 1 = Yes' and its definition ends 'else 0' - there is no third state - and the owner's ruling covered the formula, the polarity and the input dates, NOT missing-input behaviour. Introducing a state the spec does not define, on a decision that did not cover it, was unapproved and unapproved. REMOVED. With the guard gone the spec's own arithmetic answers the case: DATEDIFF(death, NULL) is NULL, NULL <= 120 is NULL, and the ELSE branch gives 0 - exactly 'else 0'. The only NULL is the pre-existing no-death-date case, which Q57 never touched. GATES: V41 (the single null rule), V42 (the arithmetic), V43 (domain {0,1}). SIZING: the four-way input split gives the four-way input split; it reads the DELIVERED ADS, because both preliminary dates are output columns.
- **Evidence:** Raised by review 2026-08-07. The polarity differs - death 120 days BEFORE follow-up end is DTHDT - FUED <= -120, which satisfies '<= 120' and so scores 1 = 'acceptable', the opposite of the flag's purpose. Worse, FUED is CLAMPED toward the death date before this is computed, so the gap the notes describe has already been closed and cannot be observed on the final dates at all.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **Changed by Q82, 2026-09-11 (corrected 2026-09-12):** this row's INPUTS are untouched and its limitation stands. DTHFUFL reads DEATH_DT_preliminary and FU_ENDDT_preliminary - the two preliminary columns - and never read FUED, so the withdrawn clamp never entered its arithmetic and a death long after the last recorded activity already scored 0 before the ruling. An earlier version of this bullet said the ruling restored that ability; it did not, because it was never lost. What DID move is DEATH_DT_preliminary itself, and for MONTH-granular deaths as well as year-only ones: a month-granular death that shared FU_ENDDT_preliminary's month used to be promoted to the last day of that month and now stays on the 15th, which moves the death up to 16 days EARLIER (day 31 to day 15), so DTHFUFL_dur only decreases. But for a RETAINED patient the flag should not flip at all, in either direction: the promotion fired ONLY when the death shared FU_ENDDT_preliminary's month, so both the old and the new death sit inside that month and the difference stays far under 120 days either way - the flag reads 1 before and after. The year-only 31-December case moved much further, but those patients now die on 15 July, before an index falling later in the same year, so the Q82 exclusion removes them and they are not retained. Expect ZERO retained-row flips. Snapshot comparison B1 counts them both ways; a nonzero result contradicts this paragraph rather than confirming it. Two earlier versions of this bullet were wrong - one said 'either direction' and 'a fortnight', the next said the flag could only flip 0 to 1. Separately, DTH_BEFORE_FUED is now permanently 0, so it can never surface the suspect case either: the blind spot is unchanged and is now structural rather than incidental.
- **202603:** 202603 delivered dthfufl with the same <=120 arithmetic but on the FINAL dthdt/fued - after the clamp had closed the gap the flag detects - plus a 'Missing' string state. Its duration was computed and dropped, as here. Q57 moved the inputs to the preliminary dates and kept 0/1.

### Q58 - all LAB* and BP

- **Spec reference:** 5B.ClinChars r17-r46 (labs) / r49-r51 (BP)
- **Spec says:** 'Missing' means no record for the analyte. The spec's Missing clause reads 'no record with testbasename = X is present in the t_lab table' - no time qualifier. The build tests for a record only AFTER restricting to labdate <= index_date.
- **We do:** The Missing test is NOT time-bounded. A patient with ANY record for the analyte anywhere in t_lab (or, for BP, any systolic/diastolic record in t_vitals) reads 'Unknown' when no qualifying pre-index record exists; 'Missing' now requires no record at all, at any date. LAB*V, LAB*DT, BPDT, BPSYS and BPDIA are unchanged - the value side stays bounded at dt_x <= index_date.
- **Decision:** Follow the spec sentence literally. Un-window the Missing test for all ten labs and for BP.
- **Why:** RULED 2026-08-08. The spec draws the distinction inside a single sentence - "'Present' if there is at least one record ... IN THE TIME PERIOD" against "Missing - if no record ... is present IN THE T_LAB_&DATE TABLE" - and the owner ruled that the contrast is deliberate. WHAT MOVED: 182,254-202,191 rows per analyte (35.4-39.2% of 515,406) and 144,079 BP rows (27.9%), all of them patients whose only records for that analyte are post-index. For albumin 'Missing' drops from ~50% of the ADS to ~11%. WHAT DID NOT MOVE: no lab value or lab date changes; only the three-way flag. CONSEQUENCE THAT MUST REACH THE DATA DICTIONARY: 'Unknown' is no longer a baseline data-quality signal. It now holds two populations - a few percent with a baseline record that fails the Present criteria, and ~39% who were simply tested later - and the second swamps the first. 'Missing' correspondingly now means the strict thing: this analyte never appears for this patient anywhere in the source table. Anyone building a baseline characteristics table should read Present as the only positive statement and treat Unknown + Missing together as 'no baseline value'. MY RECOMMENDATION WAS THE OPPOSITE and is recorded here so the choice is visible: I argued the row's PRE_INT Time Period governs every clause, citing the BP row, whose Present clause is equally unqualified yet must be index-bounded because BPSYS says 'prior or including the index date'. The owner ruled for the literal text over that inference.
- **Evidence:** MEASURED 2026-08-08 (2026m06 cut). LARGE. Of 515,406 delivered rows, the number that would flip Missing -> Unknown is 182,254-202,191 per analyte (35.4%-39.2%): LABALB 202,191 (39.23%), LABALT 201,509, LABALP 201,461, LABAST 201,242, LABBIL 201,194, LABCRE 196,400, LABLYM 183,843, LABNEU 183,652, LABPLA 182,266, LABHEM 182,254 (35.36%). BP: 144,079 (27.9%). For albumin that moves 'Missing' from ~50% of the ADS to ~11%. n_flip_all_records_undated = 0 for every analyte, so the flip is entirely patients whose ONLY records for that analyte are POST-index - not undated records. TEXT RE-READ against the spec text, and it CUTS BOTH WAYS: the lab rows say 'Present if there is at least one record ... in the time period' but 'Missing - if no record ... is present in the t_lab_&date table' - a deliberate-looking contrast that supports the literal reading. The BP row does NOT: its Present clause also says only 'in the t_vitals_&date table' with no window, yet BPSYS confirms 'prior or including the index date' - so for BP the PRE_INT Time Period column is demonstrably the only thing bounding an unqualified clause.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** no prior surface - the status construction is new; its semantics belong in the data dictionary.

### Q59 - PSA50_6MO / PSA50_12MO

- **Spec reference:** 6.Outcomes (PSA50_6MO / PSA50_12MO)
- **Spec says:** The build requires PSABL > 0 before applying the PSA50 formula. The spec has no such condition.
- **We do:** case_when(!is.na(psa6mo) & !is.na(psabl) & psabl > 0 & ((psa6mo - psabl)/psabl) <= -0.5 ~ 'Y', TRUE ~ 'N')
- **Decision:** Keep the PSABL > 0 guard. Measurement shows it is value-neutral: it delivers exactly what the spec's own formula delivers for these rows, and protects the build from failing.
- **Why:** RESOLVED 2026-08-08 on evidence. WHY IT IS NOT A DEVIATION IN EFFECT: the spec says 'If (PSA6MO - PSABL)/PSABL <= -0.5 then Y, Else N'. With PSABL = 0 the quotient is 0/0 or x/0; Spark returns NULL for both under legacy semantics, NULL <= -0.5 is NULL, and the Else branch fires - so the unguarded spec formula ALSO yields 'N' on every one of these 3,764 rows. The guard cannot turn a Y into an N, because no division by zero can produce a finite value <= -0.5. WHY IT IS STILL NEEDED: under ANSI semantics the same expression raises DIVIDE_BY_ZERO and the build fails outright rather than delivering the spec's answer. The guard is therefore at worst neutral and at best load-bearing. INTERPRETIVE POINT, unchanged and consistent with Q35: those 3,764 rows read 'N' for PSA50 although an undetectable baseline PSA makes a 50% decline mathematically undefined, not merely unobserved - the same conflation Q35 accepted for a missing follow-up PSA. Spec errata E19.
- **Evidence:** MEASURED 2026-08-08 (2026m06 cut). The guard IS reached: 707,895 of 4,385,815 PSA rows carry ScoreSerial = 0 (136,923 patients); no value is negative and the minimum is 0. Carried through the PSA_INDEX derivation, 3,764 delivered rows have PSABL = 0 - all zero, none negative (cohort 1: 1,000; 2: 1,086; 3: 1,113; 4: 321; 5: 161; 6: 65; 7: 18), i.e. 1.8% of the 205,197 rows that have a baseline PSA at all.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** no prior surface - the formula is new (Q35).

### Q60 - PRIOR_NHA_ADT

- **Spec reference:** 5C.TreatVars r39 (PRIOR_NHA_ADT)
- **Spec says:** The label says 'Any NHA and ADT received as combination therapy'. The definition says 'regimen names that contains at least two drugs, with at least one drug being abiraterone, enzalutamide, apalutamide, and/or darolutamide' - which does not require the second drug to be an ADT.
- **We do:** Follows the definition: an NHA plus any second drug sets the flag, whether or not that drug is an ADT.
- **Decision:** Keep the definition: an NHA plus any second drug sets the flag. The label's 'and ADT' is not enforced.
- **Why:** RULED 2026-08-08. The definition is the clause that derives the value and it is unambiguous: 'at least two drugs, with at least one being abiraterone, enzalutamide, apalutamide and/or darolutamide'. The label is the looser artefact. DECIDING FACTOR AGAINST THE LABEL READING: the spec supplies no ADT drug list anywhere in 39 pages, so enforcing 'and ADT' would mean inventing one - and any ADT agent omitted from an invented list would silently score No, turning a documentation mismatch into a data defect. CONSEQUENCE, accepted: PRIOR_NHA_ADT is broader than its name - an NHA with docetaxel or with a PARP inhibitor sets it. Anyone reading the column as strict NHA+ADT combination therapy will overcount. Carried as spec erratum E17 so the label gets corrected rather than the code.
- **Evidence:** Raised by review 2026-08-07 and confirmed against the spec text. Under the definition a patient on an NHA plus chemotherapy, or an NHA plus a PARP inhibitor, sets a flag whose label says NHA+ADT.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** no prior surface. 202603's taxane flags asked a different question (Q08).

### Q61 - GLEASONN

- **Spec reference:** 5B.ClinChars r63 (GLEASONN)
- **Spec says:** GLEASONN's provenance is unverified. The spec text contains GLEASON but not GLEASONN, and register rationales have claimed its residual code 3 comes from the spec.
- **We do:** gleasonn = 1 for '<8', 2 for '>=8', 3 otherwise.
- **Decision:** Confirmed as built. GLEASONN = 1 / 2 / 3, where 3 is the spec's own third category, not a residual sentinel.
- **Why:** The distinction matters and is now stated in the code. Code 3 is an ENUMERATED value, in the same family as STAGEN's 5, RACEN's 5 and ETHN's 3 - not a fallthrough. The 99 convention (register Q50) applies only where the spec's Values list provides no residual at all: AGEGR1N, REGION1N, PRACTICN, COHORTUN and STAGEN's overflow. Without that note, someone later applying Q50 uniformly would 'correct' GLEASONN's 3 to 99 and break a delivered value that is right. Register rationales that described 3 as spec-provided were correct after all; the gap was that no supplied source had been cited for it. It is cited now.
- **Evidence:** RESOLVED 2026-08-08 by the owner: GLEASON has exactly THREE categories. The spec text of 5B.ClinChars r63 gives Values '<8, >=8, Unknown/Missing' with the mapping '<8' = Less than or equal to 6 / 4+3=7 / 3+4=7 / 7 (when breakdown not available); '>=8' = 8 / 9 / 10; 'Unknown/Missing' = Unknown / Not documented. GLEASONN numbers those three 1, 2, 3.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** 202603 delivered the raw score - gleason = gleasonscore, no band, no code. The banded pair is this spec's.

### Q62 - PSA_INDEX

- **Spec reference:** 5B.ClinChars r69 (PSA_INDEX)
- **Spec says:** The row conflicts with itself on the anchor. Its definition windows the PSA search on INDEXDT; its Additional Notes say CRPCDate.
- **We do:** Anchored on INDEXDT, per the definition. The [-14, 0] window and the earliest-then-highest rule are unchanged.
- **Decision:** Anchor on INDEXDT, as built. The Additional Notes' CRPCDate is a spec erratum.
- **Why:** RULED 2026-08-08. The definition is the clause that derives the value; INDEXDT is what a variable named PSA_INDEX should mean; and PSADIAG_CRPC, which legitimately anchors on CRPCDate, sits directly above PSA_INDEX on the sheet - the same copy-down pattern already confirmed for E15 (colorectal oral table) and E16 (LABNEUV tie direction). DECIDING FACTOR: under the CRPCDate reading the four mHSPC-indexed cohorts would lose their entire PSA response block, because a hormone-sensitive patient who has not progressed has no CRPCDate at all. That is not a subtle difference in a denominator, it is a variable that cannot be computed - which is itself evidence the note was copied rather than intended. No code change. Carried as spec erratum E18.
- **Evidence:** Raised by review 2026-08-07. PSADIAG_CRPC is the variable that legitimately anchors on CRPCDate and sits directly above PSA_INDEX, so the note looks like language copied down a row - the same copy-paste pattern as E15's colorectal table and E16's LABNEUV tie direction.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** no prior surface - the PSA table is new (Q79).

### Q63 - all LAB* Present criteria

- **Spec reference:** 5B.ClinChars r17-r46 (labs)
- **Spec says:** The Present criteria require 'testdate is not missing', and the same row separately says 'Testdate will be derived by taking max(resultdate, testdate)'. Does criterion 1 test the RAW testdate column or the DERIVED date?
- **We do:** Requires the RAW testdate to be non-null. A row with a populated resultdate but a missing testdate is excluded, even though its derived date is available.
- **Decision:** No change. The question is unobservable in this data: raw testdate and derived max(resultdate, testdate) select identical record sets.
- **Why:** RESOLVED 2026-08-08 on evidence. The two readings of 'testdate is not missing' are indistinguishable on the 2026m06 snapshot, so no delivered value depends on the interpretation. The build keeps the raw-testdate test. NOTE FOR FUTURE REFRESHES: this is a property of the data, not of the spec - a later cut that populates resultdate without testdate would reopen the question. S2 is cheap; re-run it at refresh.
- **Evidence:** MEASURED 2026-08-08 (2026m06 cut). NO ROWS RETURNED. Across all ten analytes there is not a single t_lab record with testdate NULL and resultdate populated - the only rows on which the raw-vs-derived reading could differ.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** no prior surface - t_lab is new; the tension is internal to the 202606 block.

### Q64 - LOT1_MCRPC / LOT2_MCRPC / LOT3_MCRPC / LOT4_MCRPC / LOT1_MHSPC / LOT2_MHSPC

- **Spec reference:** 5C.TreatVars r220 (LOT1_MCRPC and siblings)
- **Spec says:** A patient with no line at a given position was delivered the literal string 'None' in the line-NAME column. Is that intended, or should the column be NULL?
- **We do:** Passed through unchanged: linename, so a nonexistent line is NULL.
- **Decision:** Deliver NULL. The 'None' literal is removed.
- **Why:** A consumer-visible divergence with no register row behind it - the same class as SES writing 'Missing' before Q51. It also made three QC rules dishonest, which is how it surfaced: R40/R41 test for line-number gaps using IS NULL and could never fire; R42/R43 counted all four mCRPC and both mHSPC names as populated for every patient and would have FAILED every patient with fewer than four lines; and golden-patient profile P7 selected on lot4_mcrpc IS NOT NULL and would have matched anyone. All three become correct as written once the nulls are restored - the production fix repaired the QC rather than the other way round. LOTnCAT is unaffected: lotcat_expr reads linename directly and keeps its 'No treatment' branch. CSD is exposed, not unaffected: the ifelse renders CASE WHEN c THEN 1 WHEN NOT c THEN 0 END, and a NULL name satisfies neither branch, so it would render NULL rather than 0 - Q81 records that path (unreachable this cut, zero NULL-named lines). RULED 2026-08-08 on the spec text: the Values column reads 'Character' - a TYPE, not an enumeration - so there is no permitted value to put 'None' into; the Definition is a lookup, and a row that does not exist has no value to take; and the word 'None' appears nowhere in 39 pages. DECIDING CONTRAST: LOTnCAT one row down enumerates all seventeen levels ending '17) No treatment'. The spec author DID consider the no-line case and gave the CATEGORY a level for it while giving the NAME none. That asymmetry is deliberate, not an oversight.
- **Evidence:** Found by review 2026-08-08. The spec row reads 'Value of LINENAME from lineoftherapy table where LineSetting=... and NEW_LOT_N=n', type Character, with NO Values list - selecting a row that does not exist yields missing, not a word. Contrast LOTnCAT, whose Values list DOES carry an explicit level 17 'No treatment'; the CATEGORY has a no-treatment value in the spec and the NAME does not.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** deliberately reversed. 202603 shipped the placeholder this row removes: lotname = if_else(!is.na(linename), linename, 'None'). The spec's NULL wins; a 'None' level there is NULL here.

### Q65 - LOT1CAT_* category 12, PRIOR_PARP

- **Spec reference:** 5C.TreatVars r231 category 12 (PARPi monotherapy) / r39 PRIOR_PARP
- **Spec says:** Regimen parsing assumed a comma delimiter for the PARPi 'no other drugs allowed' rule, while every combination rule in the same function accepted comma OR slash. Which is right?
- **We do:** Both the PARPi rule and PRIOR_PARP use the separator class [,/]. Source gates on the LOT table and the drug-episode table fail the build on any other separator, on space around a separator, or on leading/trailing space in LINENAME.
- **Decision:** Accept both separators consistently, AND gate the LINENAME format at source so an unexpected separator stops the build instead of misclassifying a regimen.
- **Why:** RULED 2026-08-08. The spec names the drugs and says 'no other drugs allowed'; it never states a delimiter, so where the spec is silent the build must at least be self-consistent - and it was not: the same source string was read two ways in one function, with 2,487 slash-formatted LOT rows making that reachable. WHY THE GATE, which is the part that was actually decided: the 17 treatment categories are decided entirely by parsing LINENAME, and a regimen joined by a semicolon, plus or pipe is not REJECTED by the parser - it is read as one drug name, matches no monotherapy and no combination test, and lands silently in category 16 'Any other therapy'. LOTnCAT is a headline variable and nothing downstream reports the misclassification. The delimiters were already counted, but counting only helps if somebody reads it. B13 stops the build instead. If the count is zero on this cut the gate costs nothing and catches the refresh where it stops being zero. DELIBERATELY NARROW: it looks for separator punctuation only, because drug names legitimately contain hyphens (Radium-223, Sipuleucel-T) and spaces (Clinical Study Drug). WIDENED 2026-08-08: B13 originally covered the LOT table only, but PRIOR_PARP and PRIOR_NHA_ADT parse LINENAME from the DRUG-EPISODE table, so an unexpected separator there changed a delivered flag while the mandatory gate passed. B14 now covers that table. Both gates also flag whitespace around a separator, because the anchored monotherapy and PARPi expressions match exact strings and do not tolerate it.
- **Evidence:** The 2,487 slash-formatted LOT rows quoted here are NOT reproducible from any current gate: B17 counts a repeated drug token inside one LINENAME (0, PASS on 2026-09-12) and B13/B14 test the separator and whitespace contract, neither of which tallies slash formats. Treat the 2,487 as a historical figure with no in-tree source. The inconsistency it evidenced is real and the fix is in code either way. A slash-delimited PARPi regimen fell through to 'Any other therapy' (category 16) while a slash-delimited NHA regimen was correctly called a combination - the same source formatting read two different ways in one function.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **What the data actually showed, 2026-08-08.** The slash-formatted rows this row counted are not slash-DELIMITED regimens. They are co-formulated products whose own name contains a slash - `Niraparib/Abiraterone`, `Decitabine/Cedazuridine`, `Rituximab/Hyaluronidase`. Accepting `/` alongside `,` in the PARPi and prior-drug patterns costs nothing either way, because no such product is made of two PARP inhibitors, so the delivered values are unchanged. But nothing should read this row as evidence that a regimen separator can be a slash. It cannot. The working rule, stated once: a COMMA separates top-level products within one regimen; a SLASH joins active components inside a single co-formulated product's own name. The category patterns keep the `[,/]` class because a co-formulated product genuinely is a combination for classification purposes - and no product pairs two PARP inhibitors, so the PARPi monotherapy pattern cannot over-match - while B17's duplicate-product test splits on the comma alone.
- **202603:** partial match. Both cuts read comma and slash as combination markers, and 202603's PARPi rule split on the comma alone (comma-joined repeats of the four PARPis, nothing else). This cut widens the PARPi class to [,/] - zero impact, no slash-joined all-PARPi regimen exists - and adds the B13/B14/B17 gates.

### Q66 - DATEOFDEATH / DEATH_DT_preliminary / DTHDT / DTHFL

- **Spec reference:** 5B.ClinChars r90 (DATEOFDEATH imputation)
- **Spec says:** The r90 imputation describes only 7-character (YYYY-MM) and 4-character (YYYY) death dates and gives no rule for any other shape. The fall-to-NULL for everything else is the ruled implementation below, not spec text. What should a full YYYY-MM-DD value do?
- **We do:** SPEC-LITERAL, and since Q82 also GATED at source rather than only measured: only the two documented shapes are imputed - 7-character YYYY-MM to the 15th, 4-character YYYY to 15 July unconditionally, the Jul-15 / Dec-31 split having been withdrawn by Q82. Every other length falls to NULL. The 10-character branch added earlier is REVERTED.
- **Decision:** Implement the two cases the spec describes and nothing more. Measure the exposure rather than gating it at source - AMENDED 2026-09-11 by Q82: it is now gated as well, by a mandatory source gate, because a NULL death date silently exempts the patient from the new per-cohort exclusion. The imputation itself is unchanged.
- **Why:** RULED 2026-08-08. The spec does not have a rule here to be literal about in the usual sense - 5B.ClinChars r90 describes month-and-year and year-only and gives NO 'else' clause, so the case is a HOLE, not a decision the spec made. The owner ruled to implement exactly what is written and not fill the hole with invented behaviour. A 10-character YYYY-MM-DD branch had been added on the reasoning that a full date needs no imputation; it is REVERTED, because that reasoning is unapproved and the same overreach as the withdrawn Q57 null state - plausible behaviour that no clause supports and nobody approved. WHAT IS NOT SETTLED, and is now measured instead: a POPULATED death date that falls to NULL turns a dead patient into a censored one - DTHFL reads 0, OS switches from the death date to FUED, PFS loses its death event - and nothing in the build reports it. the death-format readings quantifies exactly that: Q08a the length distribution, Q08b the patients the source says died and the ADS says did not, Q08c what it does to their delivered outcomes, and Q08d the cases the length checks are structurally blind to - a right-length value whose content still fails the cast, tested on both branches: a 7-character value that is not YYYY-MM or carries an impossible month, plus the 4-character exact-cast arm kept for symmetry. NOT GATED at source when this row was written, on the owner's ruling - see whether it is failing anything first. SUPERSEDED 2026-09-11: Q82 made an unparseable death date a MEMBERSHIP defect as well as a censoring one, because a NULL death date cannot be compared to an index date and the exclusion silently cannot fire. It IS gated now, by a mandatory source gate.
- **Evidence:** Found by review 2026-08-08. t_mortality_v2 is documented as month- or year-granular, so a full date is unexpected - but it is unambiguous, and discarding it turns a dead patient into a censored one, changing DTHFL, OS and PFS with nothing reporting it.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **Raised in stakes by Q82, 2026-09-11:** the parse is unchanged, but an unparseable DATEOFDEATH now silently disables the cohort exclusion for that patient IN ADDITION TO the censoring effect it always had - both at once, which is worth stating plainly because the two are sometimes described as alternatives. The NULL death date means the exclusion cannot fire; DTHFL still reads 0, so the same patient is also delivered as censored with OS measuring follow-up rather than survival - a NULL death date cannot be compared to an index date, so they are kept even where the source says they died first. That turns a censoring exposure into a membership exposure, which is why it is now gated at source rather than only measured afterwards.
- **CLOSED on the raised stake, 2026-09-12:** the source gate reads **zero** on the 2026m06 source. No populated-but-unparseable DATEOFDEATH exists in this cut, so the per-cohort death exclusion cannot be silently disabled for any patient and the Q82 stake above is not live here. Source-only, so this holds independently of the rebuild.
- **202603:** same shapes (7-char + '-15', 4-char imputation, else NULL), same 7-char month-match promotion, FU_ENDDT pullback and FUED clamp. Two differences, both this spec's: (a) same-year year-only deaths - 202603 compared months alone, sending every July index to Dec-31; the 15-July day cut-off sends a 1-15 July index to Jul-15. (b) DTHDT month-end promotion - 202603 needed the line-end month alone; row 92 needs FUED and line end both, so this cut promotes less often. TRY_CAST is the remaining non-value difference. Account for both when comparing DTHDT across cuts.

### Q67 - BP / BPSYS / BPDIA

- **Spec reference:** 5B.ClinChars r186 (BP)
- **Spec says:** The spec requires TESTRESULT to be 'a positive integer'. The build casts to DOUBLE and tests only > 0, so a decimal reading counts as Present.
- **We do:** bpval > 0 AND bpval = ROUND(bpval), applied to both the same-date pairing and each arm's value.
- **Decision:** Implement the spec: a BP reading must be a positive INTEGER to count as Present.
- **Why:** RULED 2026-08-08. Unlike Q58 this was never ambiguous - the spec states the requirement TWICE, positively ('TESETRESULT is a positive integer and not NULL') and again as the Unknown condition ('0 or not a positive integer or is null then = Unknown'). A fractional reading moves from Present to Unknown and loses its BPSYS/BPDIA, which is exactly what the Unknown clause instructs. THE TEST IS ON THE VALUE, NOT THE TEXT: TRY_CAST('120.0' AS DOUBLE) is 120.0, which equals its own ROUND, so a decimal point in the source string does not by itself disqualify a row - only a genuinely fractional reading such as 120.5 moves. Expected near-zero impact, since blood pressure is recorded in whole mmHg; the vitals readings give the count.
- **Evidence:** Found by review 2026-08-08. The BP row says 'TESETRESULT is a positive integer and not NULL' for Present, and 'If one of diastolic or systolic records is 0 or not a positive integer or is null then = Unknown' - so under the literal reading a decimal reading is Unknown, not Present.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** no BP surface - t_vitals was read for height/weight only, via TESTRESULTCLEANED where BP reads raw TESTRESULT. The integer rule stands on the spec's twice-stated wording; Q09a sizes fractional readings.

### Q68 - WEIGHT / HEIGHT / BMI / BSA

- **Spec reference:** 5B.ClinChars r194-197 (WEIGHT / HEIGHT)
- **Spec says:** The spec requires TESTRESULTCLEANED to be non-null. The build additionally requires it to be > 0. Is the extra condition wanted?
- **We do:** SPEC-LITERAL: the vitals filter is `!is.na(testresultcleaned)` only. The > 0 condition is REMOVED from record selection and now appears solely as a division guard on BMI and BSA.
- **Decision:** Accept any non-null TESTRESULTCLEANED, as the spec states. Do not filter on sign.
- **Why:** RULED 2026-08-08, and it went the OPPOSITE way to my recommendation - recorded so the choice is visible. 5B.ClinChars r194-197 qualifies a record on 'where TESTRESULTCLEANED is not null' and nothing else; the > 0 condition was unapproved and unstated, and the owner ruled to implement what is written, consistent with Q64 and Q66. WHAT WAS NOT LOOSENED, and why: BMI and BSA keep a height > 0 guard. That is not a record filter, it is arithmetic protection - the spec's own BMI formula divides by HEIGHT, and a zero height raises DIVIDE_BY_ZERO under ANSI, which is a BUILD FAILURE rather than a value. Under legacy semantics the same expression yields NULL and BMIGR1 reads 'Missing', so the guard delivers exactly what the spec's formula delivers and only removes the crash - identical reasoning to the PSABL guard ruled under Q59. BSA is guarded for a different reason: POWER() of a negative base with a fractional exponent returns NaN, not an error, and NaN in a numeric column is worse than NULL because it survives the null sweep and poisons any downstream mean. MEASURED, not assumed: the vitals readings count the non-positive records now admitted and show what reaches the delivered table.
- **Evidence:** Found by review 2026-08-08. The spec clause is 'where TESTRESULTCLEANED is not null'; nothing about positivity.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **Follow-up 2026-08-08:** the BMI guard was tightened to match this ruling. It read `height > 0 AND weight > 0`; the `weight > 0` limb was a filter on sign, which this row forbids, and the formula is well defined for a negative weight. It now reads `height <> 0` - the only input the formula has no value for. BSA still guards both sides, at `>= 0`, because a fractional power of a negative base is NaN rather than a number and NaN survives every null check downstream; zero is allowed through, since POWER(0, 0.725) is 0.
- **Correction 2026-08-08:** the sentence above originally ended by saying a negative BMI beside `BMIGR1 = Missing` is "what the spec's own formula and bands give". THAT WAS WRONG. The formula gives the negative number, yes - but the bands say every BMI below 18.5 is Underweight, with no positivity test, and the build's band carried `bmi > 0 AND bmi < 18.5`. So a negative BMI read `Missing` / 5 while BMI itself was populated, and the register described that as spec-compliant when it is not.
- **Resolved 2026-08-08, by applying this row's own ruling:** the `bmi > 0` limb is removed. It is the same filter-on-sign this row rules against, one level further down - the same mistake as the `weight > 0` guard, in the band instead of the formula. `BMIGR1` now follows the spec: below 18.5 is Underweight, full stop. `Missing` means exactly one thing, that BMI could not be computed. a delivered-value gate covers it, and another tracks the formula guard. No new approval is needed for this - it moves the code TOWARD the spec and toward the ruling already given here - but the consequence is worth stating: a negative weight now delivers a negative BMI banded Underweight. Whether such a reading should reach the output at all is the plausibility-gate question still open - see section 5.
- **Owner confirmation 2026-08-09:** the ruling stands - spec over prior code.
- **202603:** deliberately not followed. 202603 filtered vitals to testresultcleaned > 0 and its BMI band carried the same bmi > 0 limb. The spec answers - 'not null', nothing about sign - so it overrides the prior code. Q09b/Q09c measure what that admits.

### Q69 - LABHEM / LABHEMV / LABHEMDT

- **Spec reference:** 5B.ClinChars r127 (LABHEM)
- **Spec says:** The spec's hemoglobin unit filter is written as ' g/dL' with a LEADING SPACE. The build filters 'g/dL'. Which is right?
- **We do:** TRIM(testunitscleaned) compared against the trimmed literal, for ALL TEN analytes.
- **Decision:** Compare trimmed values. g/dL is the correct unit; the spec's leading space is a reading artefact, recorded as errata E20.
- **Why:** RULED 2026-08-08. The owner confirmed g/dL is the standardised unit hemoglobin must be in - it is the conventional US reporting unit, and TESTUNITSCLEANED is the vendor's own standardised unit column, so a leading space is not a real value. TRIM was chosen over simply keeping 'g/dL' because it makes the question MOOT rather than answered: both readings of that spec cell then select identical rows. It also guards the SOURCE side, which nothing else checked - a stray space in testunitscleaned would silently empty an analyte, and that failure looks exactly like 'this lab was never done'. Applied to all ten analytes rather than hemoglobin alone: a robustness rule that holds for one column and not its nine siblings is a trap, not a rule. Zero cost where no whitespace exists.
- **Evidence:** Found by review 2026-08-08. Every other analyte's unit is written without a leading space in the same column ('10*9/L', 'mg/dL', 'U/L', 'g/L'); hemoglobin is the only one with it.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** no lab surface. 202603's only unit tests were exact untrimmed literals (cm/kg), safe because those values were clean; its unfolded 'Year' filter (Q40) shows what a stray space would do - an analyte silently emptying. TRIM (errata E20) makes that impossible, and C10 compares the same way.

### Q70 - MCRPCDDYR / MHSPCDDYR / MPCDDYR / INITYR, PSA50_6MO / PSAL6MO / PSA50_12MO / PSAL12MO, BMIGR1

- **Spec reference:** 5B.ClinChars (year fields), 6.Outcomes (PSA response), BMIGR1
- **Spec says:** The spec's Values column disagrees with what the build emits for three families: the year fields say 'Date' but the build emits a numeric year; the PSA response fields say 'Numeric' but the build emits Y/N; BMIGR1's Values mix numbers and labels while the build emits a label plus a separate BMIGR1N.
- **We do:** Numeric years, Y/N response flags, label + N pair for BMI banding.
- **Decision:** Keep the build's types. The three Values cells are errata; the type contract is pinned by the captured types.
- **Why:** RULED 2026-08-08. Same principle as Q60 and Q62: where a row contradicts itself, the clause that DERIVES the value wins over the clause that describes it. The owner settled BMIGR1 directly - BMIGR1 is the CHARACTER label and BMIGR1N is its numeric counterpart, the N suffix denoting numeric exactly as it does on RACEN, STAGEN and every other sibling - so the spec's mixed Values cell is describing the pair, not requiring BMIGR1 to be numeric. The same reading settles the other two: a year field typed Date would need an invented month and day, and PSA50 typed Numeric contradicts its own 'then Y, Else N'. WHAT REMAINS, and it cannot be closed from the desk: no approved type contract exists. the type-contract check captures the delivered Spark types on its first run and pins nothing until a human reviews and commits qc_column_types.csv. Until then the delivered types are whatever the build emitted, which is not the same as agreed.
- **Evidence:** Found by review 2026-08-08. In each case the DEFINITION supports the build and only the Values column disagrees: INITYR is defined as Year(INIT), PSA50 is defined as 'If ... <= -0.5 then Y, Else N', and BMIGR1N exists as its own row.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** no type contract existed - types were whatever the code emitted. Its year fields were the same numerics; its LOTNGRLN shipped as CHARACTER where LOTNGR1N is numeric - drift nothing caught there, the kind the type contract catches once it is committed.

### Q71 - ECOG / ECOGN

- **Spec reference:** 5B.ClinChars r47
- **Spec says:** ECOG values are 0, 1, 2, 3, 4 and Unknown/Missing. The spec does not say what to do with a source value outside 0-4.
- **We do:** A castable value outside 0-4 reads Unknown/Missing, matching ECOGN = 6.
- **Decision:** Clamp ECOG to the six documented categories.
- **Why:** RULED 2026-08-08: clamp. The spec lists six categories and says nothing about a value outside 0-4. Before this, the label took any castable value while ECOGN mapped anything outside 0-4 to 6, so ECOG='5' shipped with ECOGN=6 - a label and a code that disagree, and a seventh category the spec does not define. A frequency table grouped on ECOG would have shown a '5' row that ECOGN counted as Unknown. a delivered-value rule already tested for this and would have failed the run, so the alternative was shipping a known gate failure. Checked by R48.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** deliberately not followed. 202603 shipped any castable label and coded everything outside 0-4 as 7 - its Missing code - so ECOG='5' with ECOGN=7. The spec's six categories override; R48 gates the pair. The window, table union and tie rules match; the treated pool and Overall anchor differ by spec (Q30).

### Q72 - WEIGHT / HEIGHT / BMI / BSA, HRR_INDEX / BRCA_INDEX, LOT1CAT_MCRPC

- **Spec reference:** 5B.ClinChars r57-64, r70-74
- **Spec says:** The spec names TEST and BIOMARKERNAME values in one letter case and says nothing about variants.
- **We do:** Vitals group on the lower-cased TEST. Biomarker conflicts group on the upper-cased BIOMARKERNAME.
- **Decision:** Normalise case before grouping, everywhere the value is also filtered case-insensitively.
- **Why:** RULED 2026-08-08: normalise case before grouping. Both places already FILTERED case-insensitively, so grouping on the raw value was simply inconsistent with the filter - there was never an intent to treat 'BRCA1' and 'brca1' as different genes. The vitals half fanned a patient out: 'Body Height' and 'body height' became two winning rows that both joined back. The biomarker half is worse - a Positive on one spelling and a Negative on the other formed separate groups and BOTH survived, which is exactly what the Q29 collision rules exist to prevent, and nothing downstream would show it as anything but a plausible call. Checked by R01 (grain).
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **Follow-up 2026-08-08:** a third place had the same inconsistency. The line-category rule and PRIOR_CHEMO both compared DETAILEDDRUGCATEGORY case-insensitively, while the per-line chemotherapy look-up in 04_treatment.R compared the raw value - so 'Chemotherapy' counted in two of the three and not the third. Now lower-cased there too, on the reasoning above. This changes LOTnCAT to 'Other chemotherapy-containing' for any line whose episodes carry a capitalised category and no earlier rule matched.
- **Limit of this ruling, 2026-08-08:** it authorises normalising for MATCHING and GROUPING. It does not authorise changing a delivered value, and one had been changed: `LINENAME` was lower-cased when the LOT table was opened, so `LOT1_MHSPC` and its seven siblings - which are a straight copy of it - shipped a normalised name rather than the source's. The spec says deliver LineName. Removed; the name is delivered raw. Nothing needed it, because every place that matches on the name lower-cases inside its own predicate: the 17 category rules, the prior-drug flags, CSD, `like_any_sql()` and gate B17. Delivered `LOTn_*` values change for any regimen the source records in mixed case.
- **202603:** the same pattern shows wherever 202603 had the surface: vitals filtered case-folded but grouped raw (same latent fan-out), and its category rule folded while its per-line look-up did not. Biomarkers had no surface. The LINENAME limit reverses a 202603 habit - it lower-cased at open and delivered normalised names; the spec ships them raw, so mixed-case regimens differ across cuts.

### Q73 - LOT1_MCRPC and siblings, LOT1CAT_MCRPC and siblings

- **Spec reference:** 5C.TreatVars r220, r231
- **Spec says:** The spec does not distinguish a line that does not exist from a line that exists with no LINENAME.
- **We do:** Unchanged. A line that exists with no name still gives a NULL name and category 17.
- **Decision:** Leave as-is. Size it from the first run before deciding.
- **Why:** RULED 2026-08-08: no code change yet, count first. Q64 settled the ABSENT line. A line that EXISTS with a null LINENAME lands in the same place, so a patient in a treated cohort - where the index line exists by construction - can read 'No treatment'. Nobody has counted how often that happens, and the fix depends on the number: zero closes it, a small count suits category 16 or a source gate, a large count is a source problem to raise upstream. TWO QUERIES, because they answer different halves. A delivered-value rule counts the contradiction - a treated cohort whose own index line reads 'No treatment'. a source count covers the SOURCE population, and also counts BLANK names, which are a second shape of the same problem: a blank string is not NULL, so it misses the 'No treatment' branch and falls to category 16 instead. Two source shapes, two different delivered answers, neither a real treatment.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **Narrowed 2026-08-08.** This row also said a BLANK or whitespace-only LINENAME falls through to category 16. That is no longer reachable: gate B13 requires the name to match `token([,/]token)*`, and a blank or whitespace-only value matches nothing, so the build stops before delivering it. What remains in scope here is the NULL name, which B13 explicitly permits and which reads `No treatment`.
- **202603:** shared ambiguity, new visibility. 202603 collapsed absent and NULL-named lines into 'None' and scored an existing NULL-named line 'No treatment'/17, as here. The delivered table hid it there behind 'None' and still cannot show it here; R55 (delivered) and S6 (source) size it, and measured zero. The source itself was queryable in either cut.

### Q74 - AGEGR1

- **Spec reference:** 5A.Demos r8-r22
- **Spec says:** The AGEGR1 Values list gives seven age bands and no residual level.
- **We do:** A missing or negative AGE reads `Unknown`.
- **Decision:** Keep `Unknown`. It is the label that pairs with AGEGR1N's 99.
- **Why:** AGEGR1N needs a residual code and Q50 approves 99 for exactly this shape. A coded pair whose label has no matching level fails the label/code agreement check, and leaving the label NULL would make AGEGR1 the only character band variable in the ADS that can be null. AGE is missing when BIRTHYEAR is missing and negative when the recorded birth year is later than the index year - both are source conditions, not build defects. Registered and approved 2026-08-08 after review found it implemented but unrecorded.
- **Evidence:** A delivered-value rule gates the band logic but deliberately PASSES the approved negative-age Unknowns - counting them would fail a build doing what this row approves. R57 (REVIEW, added 2026-08-09) is the count that sizes them: AGE < 0 delivered as 'Unknown'.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** same bands, same arithmetic, same 'Unknown' fallthrough - coded 8 there as a positional code. AGEGR1N = 99 follows Q50; map 8 to 99 across cuts. R57 sizes the negative-age population; R10 gates the bands.

### Q75 - GLEASON / GLEASONN

- **Spec reference:** 5B.ClinChars
- **Spec says:** The Definition lists the spaced sums the data carries - `3 + 4 = 7`, `4 + 3 = 7` - plus `Less than or equal to 6` and `7 (when breakdown not available)`. Verified against the sheet directly, 2026-08-09; an earlier reading of "unspaced sums" here was wrong.
- **We do:** Match the sheet's spellings, plus the source's alias for the unbroken-down seven - `7 (not documented)` - which the sheet does not print.
- **Decision:** Match both aliases. Where they differ the source spelling is what selects rows.
- **Why:** The sheet's sums match the source exactly; the one lexical divergence is the unbroken-down seven, where the sheet's `7 (when breakdown not available)` occurs nowhere in t_enh_prostate and the data's `7 (not documented)` appears nowhere on the sheet. Matching only the sheet's alias would send every unbroken-down seven to `Unknown/Missing`. Accepting both aliases means neither reading loses data. Q61 settled the three categories and their codes; it never covered the lexical mapping, which is why this row exists. A spelling in NEITHER set still falls to `Unknown/Missing` without announcing itself - a source reading lists the distinct values so that stays visible.
- **Evidence:** A source re-derivation rebuilds GLEASON from the source spellings and compares it row by row.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** 202603 never matched - gleason = gleasonscore, a straight copy - so its output witnesses the source spellings these aliases accept. Detection of a NEW spelling is manual: canonical C6 lists the values; nothing gates them.

### Q76 - LOT uniqueness key

- **Spec reference:** 3.Data Prep
- **Spec says:** Check line uniqueness on PatientID + LineNumber + IsMaintenanceTherapy.
- **We do:** Check PatientID + LineSetting + LineNumber (gate B6).
- **Decision:** Use the setting key. The maintenance flag does not exist in this cut.
- **Why:** t_enh_prostate_lot_2026m06 carries no ismaintenancetherapy column, so the printed key cannot be built at all. The substituted key is the one NEW_LOT_N actually depends on: numbering restarts inside each setting, so a LineNumber repeating within a patient AND setting is what would send baseline ECOG to the wrong line. This changes which source shapes stop the build. It changes no delivered value.
- **Evidence:** ismaintenancetherapy appears in neither the input contract nor the 98 columns required before any build.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** the key matches, the linkage does not. 202603's episode look-up joined by patientid + linenumber with no setting condition - a number reused across settings could pull another setting's episodes into LOTnED and the chemo category. This cut restricts both sides to the setting. Latent cross-cut difference, unsized. 202603 also had no uniqueness gate; B6 checks the key NEW_LOT_N depends on.

### Q77 - DATAV / source tables

- **Spec reference:** 3.Data Prep section B
- **Spec says:** The data cut is printed as `2026j30`.
- **We do:** Read June 2026 - source tables suffixed `_2026m06`, DATAV `20260630`.
- **Decision:** June 2026. `2026j30` is a print artefact, not a suffix.
- **Why:** No table carries a `_2026j30` suffix; all 21 exist as `_2026m06`. `20260630` is 30 June 2026, the month end of that cut. There is no other reading under which the build has any input at all. Recorded because it selects the entire input snapshot, which makes it the single widest-reaching interpretation in the register even though it is not in doubt.
- **Evidence:** A source check confirms all 21 tables and 98 columns exist under the `_2026m06` suffix, and the same contract is checked before every build. The run manifest records source_refresh on every build.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** not comparable - which cut 202603 read was environment state (a loose refresh global). This cut pins refresh, DATAV and RAWRWD in code, asserts the schema and contracts the 21 tables; the delivered constants are new columns.

### Q78 - B15 / B16 / B17

- **Spec reference:** n/a - build preconditions
- **Spec says:** Nothing. The spec states no gate on LINESETTING form or on repeated drug tokens.
- **We do:** Stop the build on a LINESETTING case or whitespace variant, on either table, and on a LINENAME naming the same drug twice.
- **Decision:** Approved as preconditions, alongside B1-B6 and B12-B14.
- **Why:** Each can only REFUSE a run. None transforms a value on data that passes, so none can change a delivered number. They guard two silent failures. LINESETTING is matched exactly, so a variant drops a line out of its cohort, out of NEW_LOT_N and out of every LOTn variable with nothing reporting it - the table still looks complete and a patient is simply absent. A repeated drug token reads as a combination regimen rather than a monotherapy, and the format gates pass it because the format is legal. Stopping is the right answer to both, because neither is visible in the finished table. Registered 2026-08-08 so the build-stop set is fully accounted for.
- **Evidence:** the gates run in both the R and the SQL mirror; the two implementations were made identical in 202606.19.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **Relocated 2026-08-09 (202606.25).** The gates, input contract and excluded-gene report moved out of the build; the build only creates. Still mandatory before every build - a hit means DO NOT BUILD. C10 (Q25) runs there too, fail-closed, under the build's own comparison rule.
- **B17 corrected at the first live run, 2026-08-08.** It split LINENAME on `[,/]` and failed on 3,549 rows. The slash is NOT a regimen separator in this source - it binds inside a single product name: `Niraparib/Abiraterone`, `Decitabine/Cedazuridine`, `Daratumumab/Hyaluronidase-Fihj`. So `Abiraterone,Leuprolide,Niraparib/Abiraterone` looked like a repeated abiraterone when it is abiraterone plus the co-formulated product. Split on the comma only. B15 and B16 passed on the same run, as did B13 and B14.
- **202603:** no prior surface - 202603 ran no gates of any kind. The B-gate set is new protection.

### Q79 - PSA6MO / PSA50_6MO / PSAL6MO

- **Spec reference:** 6.Outcomes (the PSA6MO row) against 3.Data Prep section C
- **Spec says:** The PSA6MO row defines the six-month window as `[INDEXDT + 180, INDEXDT + 210]`. Data Prep separately converts a month to 30.4375 days, which puts six months at 183.
- **We do:** `[+180, +210]`, as the PSA6MO row states.
- **Decision:** No change. The variable's own row governs; the 183-day figure is not a competing definition of this window.
- **Why:** The two numbers are not in conflict. 183 days is the generic month conversion used for DURATIONS - OS, TTNT, PFS, TTCRPC all divide by 30.4375 - and says nothing about which PSA result to select. The PSA6MO row states a deliberately WIDE selection window, `[+180, +210]`, so a result that arrives late still counts as the six-month reading; a 183-day point would defeat that purpose. Registered as a no-change clarification because two independent reviews reached opposite conclusions on it - one calling it an unregistered divergence, the other calling the code correct. Recording it settles which reading applies and stops the question returning.
- **Evidence:** The window is stated on the variable row itself; nothing in the spec applies the 183-day figure to PSA selection.
- **Approved:** Onkar Kshirsagar, 2026-08-08
- **202603:** no prior surface - nothing was windowed from the PSA table (Q35). 202603 used 30.4375 for durations only, exactly the role this row assigns the 183-day figure. The window stands on the PSA6MO row's text.

### Q80 - LABNEU / LABPLA / LABHEM / LABCRE / LABBIL / LABAST / LABALT / LABALP / LABALB / LABLYM

- **Spec reference:** 5B.ClinChars lab block (LABPLA is r21)
- **Spec says:** Each analyte's Present and Missing clauses identify it by an exact TestBaseName written in lowercase - 'neutrophils', 'platelets', and so on.
- **We do:** The build matches `tolower(testbasename) == '<name>'` - case-insensitive - for all ten analytes, on both the Present and the Missing side.
- **Decision:** Keep the case-insensitive match. It is confirmed value-neutral on this cut.
- **Why:** RESOLVED 2026-08-09. An exact-lowercase filter and a case-folded one differ only where the source carries a mixed-case spelling of an analyte name. If one ever appears, the exact filter silently drops those records from Present and Missing alike - a patient tested under 'Neutrophils' would read Missing - while the case-folded filter keeps them. The defensive reading costs nothing where the source is clean, and this cut is clean.
- **Evidence:** Direct query 2026-08-09: zero rows in t_lab where testbasename differs from LOWER(testbasename) among the ten analyte names. Both readings select identical records on this cut.
- **Approved:** Onkar Kshirsagar, 2026-08-09
- **202603:** no lab surface, but both sides have witnesses: 202603 case-folded its vitals match, and its one unfolded filter silently never fired (Q40) - the failure a mixed-case name would cause. Value-neutral on this cut (zero mixed-case names); recheck at refresh.

### Q81 - CSD (cohorts 3-7)

- **Spec reference:** 5C.TreatVars (CSD); corrected spec row values '0; 1'
- **Spec says:** CSD is 0 or 1 for every patient - no NULL is provided for.
- **We do:** Cohorts 1-2 derive CSD from a join flag whose test cannot be NULL, so they always emit 0 or 1. Cohorts 3-7 derive it as `ifelse(LOWER(lotN_*) LIKE '%clinical study drug%', 1L, 0L)`, which renders CASE WHEN c THEN 1 WHEN NOT c THEN 0 END - an index line whose LINENAME is NULL would give NULL, not 0.
- **Decision:** No code change this cut. Make the else explicit (a case_when ending TRUE ~ 0L) at the next refresh, when the rendered SQL moves anyway.
- **Why:** RESOLVED 2026-08-09. The trigger population is empty twice over: the source holds zero mHSPC/mCRPC lines with a NULL LINENAME (Q73's sizing query), and the type contract shows CSD fully populated on all 515,406 delivered rows. Changing the rendered SQL under an already-built and QC'd table to close an unreachable path would force a rebuild for no delivered difference; recording the path and fixing it at the next refresh does not.
- **Evidence:** Direct query 2026-08-09: zero NULL-named lines in either setting. Nullability: zero NULL CSD across 515,406 rows.
- **Approved:** Onkar Kshirsagar, 2026-08-09
- **202603:** CSD is new (Q49), so no prior flag existed to go NULL - that is the whole comparison. 202603's category cascade handled a NULL name through its explicit `linename IS NULL ~ 'No treatment'` limb, as this cut's does; only the new CSD ifelse lacks that explicit else. Unreachable this cut (zero NULL-named lines, CSD fully populated), guarded by the type contract; explicit else at the next refresh.

### Q82 - DTHDT / FUED / cohort membership

- **Spec reference:** 5B.ClinChars r90-r93 (death date, FU_ENDDT, FUED); 4.StudyPop sB (cohort membership). Superseded by the study-team ruling of 2026-09-11 and its clarification the same day. The two messages are transcribed verbatim in section 7 below; read those rather than relying on this summary.
- **Spec says:** r90-r93 build the death date through a four-step cascade - impute the middle of the period, push a same-year year-only death past the index, promote to month end when the death month matches FU_ENDDT_preliminary's, promote again when it matches both FUED and the maximum line end - then clamp FUED back toward the death date and floor it at the index. Nothing anywhere excludes a patient whose index date follows their death date.
- **We do:** Implement RP1-RP4 as section 7 states them, with W1-W3 withdrawn. Three consequences are this repository's rather than the ruling's, and are recorded here because nothing in the ruling text names them: DEATH_DT_preliminary and DTHDT are now equal by construction; FUED has no floor at the index date, so it can precede one or be NULL (Q83); and the patient-level stage table is built before any cohort is assigned, which 03_clinical.R joins rather than re-deriving. One knock-on worth naming because it is easy to miss: CSF_FU's follow-up window is bounded at FUED, so for a patient whose death post-dates their last recorded activity that window now EXTENDS and the flag can move 0 to 1 (Q39).
- **Decision:** Implement the ruling as written. Where the written spec conflicts, the ruling wins - it is the more recent instruction from the same owners, and the precedence rule puts an explicit answer above a prior implementation.
- **Why:** RULED 2026-09-11. The delivered table had 2,799 rows in which the death date preceded the index date, across at most 1,398 patients - that is 1,376 + 22 from Q38's two disjoint ROW subsets, so a patient appearing in both is counted twice; the distinct-patient count over all 2,799 rows was never measured and is lower, every one of them collapsed to a single day of follow-up by the FUED clamp, and 285 of them shipping a negative rwPFS. That was faithful to the spec and indefensible as data. The ruling fixes the cause rather than the symptom: if the index date post-dates the death, the patient does not belong in that cohort, and there is nothing left to clamp. RP2 matters for the same reason, and the clarification and its worked example are in the ruling file. Two things this does NOT fix, both recorded: an unparseable DATEOFDEATH still yields a NULL death date, which cannot be compared to an index and so silently exempts that patient from the exclusion (Q66, now gated at source); and a patient with no death date can still have follow-up that ends before their index, because FUED is then a last activity date that nothing ties to the index (Q83).
- **Evidence:** The populations the ruling removes were measured on the 2026-08-09 run before it was issued: 2,799 death-before-index rows (V08b), of which 2,757 rows / 1,376 patients carried a source death month strictly earlier than the index month, FUDUR = 1 on all 2,799, and 285 negative rwPFS values (V07b). The new gates V44-V47 assert the ruling's mechanics directly; V26 carries the size of the resulting cohort-count drop, which is the impact figure the study team asked for.
- **Approved:** Onkar Kshirsagar, 2026-09-11
- **Counts accepted 2026-09-12:** by Onkar Kshirsagar. The delivered cohort counts the ruling produces - 196,549 / 133,299 / 78,635 / 50,327 / 28,865 / 16,007 / 8,582, down 3,142 cohort memberships in total - replace the 2026-08-09 figures the cut was accepted on, and V26's frozen baseline is to be refreshed to them, in both the R and the SQL mirror of the delivered-value gates. The copy of the OLD baseline in `00a_pre_q82_snapshot_TAKE.sql` must NOT be refreshed - it is what proves the snapshot is the pre-ruling table. They are source-measured, not delivered: the signature accepts a prediction, so a delivered count that differs from these is a defect rather than a new baseline. The copy of the OLD baseline in `00a_pre_q82_snapshot_TAKE.sql` must NOT be refreshed - it is what proves the snapshot is the pre-ruling table.
- **202603:** the ruling keeps exactly one stage of 202603's death handling and discards the rest. The first imputation - 7-character to the 15th, 4-character to 15 July - is 202603's, apart from TRY_CAST in place of its CAST, which Q66 records as a real behavioural difference on a malformed value of the right length and which is exactly what B18 now catches. Everything after it goes: 202603's same-year push (which compared months alone), its month-end LAST_DAY promotion of DEATH_DT_preliminary against FU_ENDDT_preliminary, its FU_ENDDT pullback, its own DTHDT LAST_DAY promotion on the line-end month alone, and its FUED clamp, which this cut had reproduced word for word (Q45). The per-cohort death exclusion has no 202603 precedent at all - the prior cut retained those patients and relied on the clamp, so this is new behaviour rather than a restored one, and 202603 cannot be used to check it.

### Q83 - FUDUR / OS / TTNT where follow-up precedes the index

- **Spec reference:** none. This is the exposure the 2026-09-11 ruling opens and does not address. The two messages are transcribed verbatim in section 7 below; read those rather than relying on this summary.
- **Spec says:** Nothing. FUED is now defined without reference to the index date, and no rule says what should happen when it falls before one. FUDUR = DATEDIFF(FUED, INDEXDT) + 1 is stated unconditionally.
- **We do:** Deliver the values as they fall out. A patient with NO death date whose last recorded activity precedes their index date gets a negative FUDUR, a negative OS on the alive branch, and a negative TTNT on the censored branch. FUED itself is NULL, and FUDUR with it, where the patient has neither a death date nor any activity in the four FU_ENDDT_preliminary sources - previously impossible, because the index floor guaranteed a value.
- **Decision:** Deliver and size. Do not floor, null or exclude without a ruling, because each of those is a different study-level answer and none is derivable from the ruling's text.
- **Why:** The ruling removed the index floor as a consequence of moving FUED to patient level - with no index date in scope there is nothing to floor against - and it closed the death-side exposure by excluding the patient instead. It did not address the mirror case on the activity side. Inventing a fix would be the same overreach as the withdrawn Q66 10-character branch: plausible behaviour that no clause supports and nobody approved. So the behaviour follows the ruling literally and the number is put in front of the study team instead. Note which patients can be affected: only those with no death date, since FUED is the death date whenever one exists and the cohort exclusion puts that on or after the index. Gate V46b fails the run if a death-dated patient ever appears in this population, which would mean the exclusion or the FUED rule had drifted. Two cautions on the sizing: V46 counts `fued < indexdt`, which is an UPPER BOUND on the negative population - a FUED exactly one day before the index gives FUDUR = 0 and OS = 0, not a negative - and the NULL-FUED half is invisible to it, because a NULL makes that predicate UNKNOWN, so V46c carries it separately.
- **Evidence:** Measured for the first time on the 2026-09-13 build of `rwdp_pros_pano_2026m06`. **V46 = 1,059 rows** with follow-up ending before the index, out of 512,264 delivered - 0.21%. **V46c = 0**: nobody has a null follow-up end, so the second half of this question is empty and only the negative half survives. **V46b = 0**, so none of the 1,059 carries a death date and the population is the Q83 residue rather than a broken exclusion. V07 reported no negative it could not account for. Two things the 1,059 does NOT yet say, both of which the ruling needs: how many distinct PATIENTS it is (the ADS grain is one row per patient per cohort, so a patient in four cohorts is counted four times), and how it splits between `FUDUR < 0` and `FUDUR = 0` - the second is a one-day boundary, not a backwards window, and may deserve a different answer. `validation/11_q83_decision_pack.sql` produces both, with the per-cohort spread, the distance distribution and the `OS`/`TTNT`/`PFS`/`ID3MOSFU`/`ELIGPFS` carry-through.
- **Approved:** Onkar Kshirsagar, 2026-09-11, for the interim behaviour only - implement the ruling as written and measure what it exposes. The disposition question is open and carried in section 5: deliver the negative value, floor it, null it, or exclude the patient - four options; the 2026-09-11 ruling settled exclusion for the DEATH side and is silent on the activity side, so it stays on the table.
- **202603:** no precedent, and none possible. 202603's FUED carried the same index floor this cut had, so follow-up could never precede the index there and this population could not exist. The prior cut is silent because the question did not arise until the floor was removed.

### Q84 - LABALBV delivered value plausibility

- **Spec reference:** 5B.ClinChars, LABALB / LABALBV
- **Spec says:** the analyte is albumin, `testunitscleaned = 'g/L'`, and the delivered value is whatever the winning record carries. No range is given.
- **We do:** deliver every qualifying positive value unchanged, with no plausibility bound.
- **Decision:** OPEN. Nobody has ruled on it.
- **Why it is its own row, and NOT part of Q68:** Q68 governs HEIGHT and WEIGHT - it rules that a non-null value is admitted whatever its sign, which is why BMI can come out negative. Albumin plausibility was being justified by pointing at Q68, and that was wrong twice over: Q68 does not mention labs, and no register row owned the albumin question at all. It had a measurement (S7) and no owner, which is the shape of a finding nobody has to answer.
- **Why it matters:** Q25 settled the SCALE. C10c confirms 99.91% of source serum-albumin rows sit in the g/L band, so the `g/L` label is right and no rescaling is needed. But the same 2026-09-12 run showed the g/L group reaching 42,010 and 3,878 positive rows outside both scale bands, and production applies no range filter. So a delivered `LABALBV` can be far outside anything physiological. Serum albumin runs about 35-50 g/L; 15-70 is generous on both sides, and a value outside that is not a borderline reading.
- **What the ruling has to say:** deliver the implausible value, null it, floor and cap it, or exclude the record from the winning-value selection. Note that Q68's reasoning - a filter on value is a filter the spec does not authorise - applies here too, so "deliver it" is the spec-literal answer and the others all need an explicit departure.
- **Evidence:** A per-cohort sizing reading: rows inside 15-70 g/L, outside it, inside the g/dL band (1.5-7.0), below 15 but in neither band, above 70, min, max and the percentage. Built on a seven-cohort spine so a cohort with no albumin reports zero rather than vanishing. Sizing only - it is deliberately not a gate, because gating would pre-empt the ruling.
- **Approved:** NOT APPROVED. Open, unassigned, and carried in section 9.
- **202603:** not applicable. The prior cut carried the same unbounded delivery and nobody asked.

## 9. Still open

Two register rows are genuinely undecided, and neither stops the build. Both
need a named clinician - an owner cannot rule on a clinical question on a
clinician's behalf.

| Row | Question | What it needs |
|---|---|---|
| **Q83** | A patient with no death date can have follow-up that ends before the date they entered the cohort, delivering a negative `FUDUR`, and a negative `OS` and `TTNT` on the censored branches; with no activity either, `FUED` and `FUDUR` are null. **Four options: deliver the negative value, floor it at zero, null it, or exclude the patient.** The 2026-09-11 ruling chose exclusion for the death side and is silent here. The same answer is needed three times - for the negative, for the null, and for the `FUDUR = 0` boundary. Two of the six figures are in from the 2026-09-13 build: **1,059 rows** with follow-up before the index, and **zero** with a null follow-up end - so the null half of this question is empty and one option, nulling, has nothing to apply to. The remaining four - negative `FUDUR`, negative alive-branch `OS`, negative censored `TTNT`, and `FUDUR` exactly zero - plus the patient count behind the 1,059 come from `validation/11_q83_decision_pack.sql`, which reads the delivered table and writes nothing. Delivered as it falls out and sized, not repaired, because flooring, nulling and excluding are three different study-level answers and none is derivable from the ruling's text. |
| **Q84** | Delivered `LABALBV` outside 15-70 g/L. **Deliver it, null it, floor and cap it, or exclude the record from the winning-value selection.** Registered 2026-09-12 and **unassigned**: it needs a named clinician before it can have an answer. The unit is settled as g/L (Q25); only the values are open. It had been justified by pointing at Q68, which governs height and weight and says nothing about labs - so the question had a measurement and no owner. | A per-cohort sizing of the delivered values against the 15-70 g/L band, which needs a rebuild. |

Five further rows are **decided and approved but not ratified by a clinician**:
Q68 (height and weight admitted at any non-null value, so a negative weight
delivers a negative `BMI`), Q38 (10,148 patients indexed on a line that began
before the milestone admitting them), Q52 (17.01% of cohort 1 index dates are
not day-level), Q34 (`PFS` can exceed `OS` because a progression can be recorded
after death), and Q03/Q20/Q29/Q37 (four biomarker rulings that reached the team
second-hand and need a named clinician against them). Each is recorded in
section 4 with its owner approval and date; what is missing is the second
signature, not the decision.

## 10. What these values cannot tell you

- **`Unknown` in a lab or `BP` variable is not a data-quality signal.** It mixes
  a few percent with an unusable baseline record and about 39% who were simply
  tested later. `Present` is the only positive statement (Q58).
- **`PRIOR_NHA_ADT` is broader than its name.** Any NHA plus a second drug sets
  it, whether or not that drug is an ADT. An NHA with chemotherapy counts (Q60).
- **A cohort's index date can precede the milestone that admitted the patient.**
  10,148 patients, 6.2% of cohort 3 and 10.5% of cohort 4. Their baseline
  windows, `OS`, `TTNT` and `PFS` all anchor on that earlier date (Q38).
- **17.01% of cohort 1 index dates are not day-level.** A year-level milestone
  resolves to 1 January, so every index window can be up to a year early for
  those patients (Q52).
- **`PFS` can exceed `OS`.** A progression can be recorded after the death date;
  the specification says to treat it as a data limitation and take no action
  (Q34).
- **Height and weight are admitted at any non-null value.** A negative weight
  therefore delivers a negative `BMI`, banded `Underweight`. Every step follows
  the specification; the result is not a measurement (Q68).
- **The delivered table carries no provenance.** It records nothing about which
  build produced it, and it is written under a stable name with `replace = TRUE`.
  The decision to change that was taken on 2026-09-12 and deferred to the next
  cut, so for this cut the build identity recorded by hand is the only thing
  tying a result to a run (Q43, Q27).
