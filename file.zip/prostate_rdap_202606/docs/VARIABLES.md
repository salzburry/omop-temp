# Variables - what each one is, how the build derives it, and what we assumed

For anyone checking this data product against the program specification. It is
written to be read **beside the specification**, sheet by sheet and row by row,
so you can answer two separate questions for every variable:

1. **Was the specification read correctly?** Where a spec row was ambiguous,
   silent or self-contradictory, somebody made a choice. The Definition column
   states the reading the build implements, so you can compare it against the
   spec row directly.
2. **Was that reading implemented?** Section 5 lists all 190 delivered columns
   in specification order with the derivation as the code performs it and the
   block of code that performs it, so you can go from a spec row to the lines
   that implement it without reading the whole build.

You have three things: the build code under `code/`, this file, and
`FILES.md`, which says what every file here is. `SPEC.csv`
sits beside this file in machine-readable form: 231 rows, of which the 190
`Column` rows are these, one per delivered column. The `Convention` rows carry
the cross-cutting reading rules, including the six that record where the build
has NO ruling: source types, fractional ECOG, boolean encodings, unit and
granularity matching, duplicate mortality rows and event chronology.

**Two cautions before you read a number out of the table.** Every delivered
figure quoted here predates the study-team ruling of 2026-09-11, because the
table was last built on 2026-08-08 and that ruling changed the death date, the
follow-up end date and cohort membership - section 7. And the Definition column
states what the build was told to do, not evidence that it does it: for that,
read the checks under `validation/` and `qc/`.

---

## 1. How to check this against the specification

Work one sheet at a time. For each spec row:

| Step | Where to look |
|---|---|
| Find the variable | Section 5, grouped by spec sheet, in spec order. Names are upper-case as delivered; the code uses lower-case. |
| Compare the definition | The **Definition as implemented** column. Where it differs from the spec text, the difference is the reading the build was given, stated in full so you can accept or reject it. |
| Read the code | The block named in **Built in**. Where the definition and the spec text disagree, that block is what actually decides. |
| Find the code | The **Built in** column names the module and the block inside it. Section 4 maps blocks to spec row ranges. |
| Check the window | Variables with a time period carry it in italics after the name - `[PRE_INT]`, `[FU]`, `[INDEX]`. Section 3 defines each. |

Two things that are easy to miss:

- **A variable can be delivered and still be interim.** The spec keeps several
  working dates in the output. Section 6 lists every intermediate the build
  creates and says which are delivered and which only feed something else.
- **`TTNTFL` is derived and NOT delivered.** The spec strikes it out, but its
  active definition still reads it, so the build computes it internally and the
  190-column contract excludes it.

The `Label`, `Permitted values` and `Definition as implemented` columns in
section 5 restate what `SPEC.csv` holds. The release check compares the two
LISTS, not their text: a variable in one and not the other, or a row numbered
with the wrong delivered position, fails it, but wording that has drifted
between the two does not. Read them side by side. The `#` column is
the column's position in the delivered table, so the tables can be grouped by
specification sheet without losing the delivered order.

## 2. The shape of the delivered table

One row per patient per cohort. A patient who qualifies for several cohorts has
several rows, and everything time-anchored in each row is anchored on **that
cohort's** index date.

| | |
|---|---|
| Grain | patient x cohort |
| Cohorts | seven, numbered 1-7 |
| Columns | 190, in the order `SPEC.csv` gives |
| Key | `PATID`, `COHORTN` |

The seven cohorts, with what fixes the index date for each:

| # | Cohort | Setting | Index date |
|---|---|---|---|
| 1 | Overall mHSPC | mHSPC | `MHSPCDD`, the milestone date |
| 2 | Overall mCRPC | mCRPC | `MCRPCDD`, the milestone date |
| 3 | L1+ treated mHSPC | mHSPC | start date of the line with `NEW_LOT_N` = 1 |
| 4 | L1+ treated mCRPC | mCRPC | start date of the line with `NEW_LOT_N` = 1 |
| 5 | L2+ treated mCRPC | mCRPC | start date of the line with `NEW_LOT_N` = 2 |
| 6 | L3+ treated mCRPC | mCRPC | start date of the line with `NEW_LOT_N` = 3 |
| 7 | L4+ treated mCRPC | mCRPC | start date of the line with `NEW_LOT_N` = 4 |

**Inclusion.** The setting's milestone date must fall within `[MININDEX,
MAXINDEX]`, both bounds inclusive. For cohorts 3-7 the line start date must fall
in that window as well.

**Exclusion.** A patient whose index date for a cohort falls **after** their
death date is excluded from that cohort - **per cohort, not per patient**. The
same patient can hold their place in an early cohort and be dropped from a later
one whose line started after they died. See section 3.

## 3. Time windows and conventions

Every window is relative to the row's own index date. Nothing is anchored on a
calendar date.

| Window | Span |
|---|---|
| `PRE_INT` baseline | earliest available data through `INDEXDT`, inclusive |
| `INDEX` | `INDEXDT` itself |
| `FU` follow-up | after `INDEXDT` through `FUED`, inclusive |
| `LOT_ECOG` | `INDEXDT - 30` through `INDEXDT + 7` |
| `BIOMARKER` | `INDEXDT - 30` through `INDEXDT + 7` |
| `PSA_INDEX` | `INDEXDT - 14` through `INDEXDT` |

Two conventions apply throughout. **A derived date from two candidates** takes
the later of the two, uses whichever is present if one is missing, and never
imputes a missing date. **A coded variable with no documented residual level**
falls to `99`; where the permitted values name a residual, that one is used
instead.

Text comparison is **not** uniformly case-insensitive. `LINESETTING`,
`GLEASONSCORE` and `LABCOMPONENT` are compared literally, so a variant spelling
falls to the residual category or drops the row - which is why source gates
`B13`-`B16` exist to prove no variant spelling is present in the source.

## 4. Where each part of the table is built

The driver `code/prostate_rdap_202606.R` sources the modules in numbered order,
once per cohort, and writes 43 stage tables before selecting the 190 delivered
columns. Where a block header names spec rows, those are the rows it implements.

| Module | Block | Spec rows |
|---|---|---|
| `00_setup.R` | parameters, source-table handles, the frozen gene panels, and the shared helpers: `lot_tbl()` line numbering, `closest_value()`, `earliest_value()` | 3.Data Prep B and C |
| `01_studypop.R` | patient-level death date and follow-up end date | 5B.ClinChars 88-93 |
| `01_studypop.R` | `index_lot_cohort()` - one index table per cohort, with the death exclusion | 4.StudyPop B |
| `02_demographics.R` | `demographics_variable_addn()` | 5A.Demos |
| `03_clinical.R` | milestone dates, stage, Gleason, diagnosis PSA | 2-16, 62, 65-67 |
| `03_clinical.R` | baseline laboratory values - ten analytes, three columns each | 17-46 |
| `03_clinical.R` | baseline ECOG | 47-48 |
| `03_clinical.R` | blood pressure | 49-53 |
| `03_clinical.R` | concomitant medication flags | 54-56 |
| `03_clinical.R` | vitals: weight, height, BMI, BSA | 57-64 |
| `03_clinical.R` | PSA at the mCRPC milestone and at index | 68-69 |
| `03_clinical.R` | biomarker status at index - HRR, the olaparib label panel, BRCA | 70-77 |
| `03_clinical.R` | PSMA PET scan | 78-79 |
| `03_clinical.R` | sites of metastasis | 80-87 |
| `03_clinical.R` | follow-up end date and death date - joins the patient-level table | 88-93, 97 |
| `03_clinical.R` | `clin_char_master()` - combines the blocks, computes `FUDUR` and `INDEXYR` | 5B.ClinChars |
| `04_treatment.R` | `trt_lot_block()` per setting, `trt_prior_flags()`, `trt_var_creation()` | 5C.TreatVars |
| `05_outcomes.R` | `outcomes_tbl_var()` - OS, TTNT, rwPFS and their event flags | 6.Outcomes |
| `06_assemble.R` | `overall_ads_creation()` - the 190-column allowlist, the rename to delivered names, the write | - |

Three helpers in `00_setup.R` carry logic worth reading before any variable
that uses them:

- **`lot_tbl(setting)`** numbers lines within a patient and a setting by start
  date, producing `NEW_LOT_N`. Cohort membership for cohorts 3-7 and every
  `LOT*` variable depend on it.
- **`closest_value(src, lo, hi, out_value, out_date, agg)`** takes the record
  closest to an anchor date inside a window, breaking a same-day tie with the
  named aggregate. Labs, ECOG, blood pressure, vitals and biomarkers all use it,
  and the tie rule differs by variable.
- **`earliest_value(src, lo, hi, out_value)`** takes the earliest record in the
  window instead, with the maximum on that day. Only the two PSA variables use
  it, which is the spec's own asymmetry.

## 5. The delivered columns, by specification sheet

All 190 columns, grouped by specification sheet so you can work one sheet at a
time, and within a sheet in the order the spec gives them. The **#** column is
the column's position in the delivered table, which interleaves the sheets - so
`DATAV` is spec sheet 3 but delivered 187th.

Where the spec was ambiguous and a choice was made, the choice is stated in
**Definition as implemented** and the reasoning sits in the code block named in
**Built in**. There is no separate decision column: one carrying a dash on every
row said nothing while implying a trail this package does not carry.

### 5.1 3.Data Prep - Data preparation  (6 columns)

| # | Variable | Label | Permitted values | Definition as implemented | Built in |
|---|---|---|---|---|---|
| 1 | `PATID` | Patient identifier | Character | PatientID. | 06_assemble.R |
| 2 | `INDEXDT` *[INDEX]* | Index date | Date | Per the cohort table: the setting's milestone date for cohorts 1-2, the index line's StartDate for cohorts 3-7. | 06_assemble.R |
| 187 | `DATAV` | Data version | Character | Constant 20260630. | 06_assemble.R |
| 188 | `RAWRWD` | Data source | Character | Constant Flatiron Prostate Panoramic Dataset. | 06_assemble.R |
| 189 | `MININDEX` | Earliest potential index | Date | Constant 2011-01-01. | 06_assemble.R |
| 190 | `MAXINDEX` | Latest potential index | Date | Constant 2026-04-30. | 06_assemble.R |

### 5.2 4.StudyPop - Study population  (6 columns)

| # | Variable | Label | Permitted values | Definition as implemented | Built in |
|---|---|---|---|---|---|
| 19 | `ID_PD_MCRPC` *[PRE_INT]* | mCRPC milestone in the index window | 0; 1 | 1 if MCRPCDD is not null and falls in [MININDEX, MAXINDEX], else 0. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 20 | `ID_PD_MHSPC` *[PRE_INT]* | mHSPC milestone in the index window | 0; 1 | 1 if MHSPCDD is not null and falls in [MININDEX, MAXINDEX], else 0. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 183 | `COHORT` | Analysis cohort | Overall mHSPC; Overall mCRPC; L1+ treated mHSPC; L1+ treated mCRPC; L2+ treated mCRPC; L3+ treated mCRPC; L4+ treated mCRPC | Per the cohort table. | 06_assemble.R |
| 184 | `COHORTN` | Analysis cohort (N) | 1-7 | Numeric of COHORT, per the cohort table. | 06_assemble.R |
| 185 | `COHORTU` | Treated status within setting | Untreated mCRPC; Treated mCRPC; Untreated mHSPC; Treated mHSPC | Treated means the patient has at least one line of therapy in the cohort's setting. Combine with the setting to give the label. | 06_assemble.R |
| 186 | `COHORTUN` | Treated status within setting (N) | 1-4; 99 | Untreated mCRPC = 1, Treated mCRPC = 2, Untreated mHSPC = 3, Treated mHSPC = 4. | 06_assemble.R |

### 5.3 5A.Demos - Demographics  (19 columns)

| # | Variable | Label | Permitted values | Definition as implemented | Built in |
|---|---|---|---|---|---|
| 3 | `ID3MOSFU` | 3 months potential follow-up | 0; 1 | 1 if MAXINDEX - INDEXDT >= 91 days, else 0. | 02_demographics.R |
| 4 | `BIRTHYEAR` *[PRE_INT]* | Birth year | Numeric | BirthYear, as given. | 02_demographics.R |
| 5 | `AGE` *[INDEX]* | Age at index | Numeric | YEAR(INDEXDT) - BIRTHYEAR. | 02_demographics.R |
| 6 | `AGEGR1` *[INDEX]* | Age group | 0-18; 19-34; 35-49; 50-64; 65-74; 75-84; >=85; Unknown | Band AGE. Unknown where AGE is missing or negative. | 02_demographics.R |
| 7 | `AGEGR1N` *[INDEX]* | Age group (N) | 1-7; 99 | Numeric of AGEGR1 in the Values order. 99 for Unknown. | 02_demographics.R |
| 8 | `STATE` *[PRE_INT]* | State of residence | Character | State, as given. | 02_demographics.R |
| 9 | `REGION1` *[PRE_INT]* | Census region | Northeast; Midwest; South; West; Other region; Missing; Unknown | Map STATE to census region. PR is Other region. A null state is Missing. A state in no region is Unknown. | 02_demographics.R |
| 10 | `REGION1N` *[PRE_INT]* | Census region (N) | 1-6; 99 | Numeric of REGION1. 99 where the state is present but in no region. | 02_demographics.R |
| 11 | `RACE` *[PRE_INT]* | Race | Asian; Black or African American; White; Other Race; Unknown/Missing | From demographics. Hispanic or Latino recodes to Other Race. Anything else is Unknown/Missing. | 02_demographics.R |
| 12 | `RACEN` *[PRE_INT]* | Race (N) | 1-5 | Numeric of RACE in the Values order. Evaluated on the source categories, before RACE is recoded. | 02_demographics.R |
| 13 | `ETHNICITY` *[PRE_INT]* | Ethnicity, source value | Character | Ethnicity, as given. | 02_demographics.R |
| 14 | `ETH` *[PRE_INT]* | Ethnicity | Not Hispanic or Latino; Hispanic or Latino; Unknown/Missing | Hispanic or Latino if either RACE or ETHNICITY says so. Else Not Hispanic or Latino if ETHNICITY says so. Else Unknown/Missing. | 02_demographics.R |
| 15 | `ETHN` *[PRE_INT]* | Ethnicity (N) | 1; 2; 3 | Numeric of ETH in the Values order: 1 Not Hispanic, 2 Hispanic, 3 Unknown/Missing. | 02_demographics.R |
| 16 | `PRACTICN` *[PRE_INT/FU]* | Practice type (N) | 1; 2; 3; 99 | Numeric of PRACTIC. 99 where the patient has no practice record. | 02_demographics.R |
| 17 | `PRACTIC` *[PRE_INT/FU]* | Practice type | Academic only; Community only; Both academic and community; Missing | Aggregate the distinct practice types across all of the patient's practices. | 02_demographics.R |
| 18 | `SES` *[PRE_INT]* | Socioeconomic status | 1 = lowest; 2; 3; 4; 5 = highest; Null | SESIndex2015_2019, passed through unchanged. | 02_demographics.R |
| 34 | `STAGE` *[PRE_INT]* | Stage at initial diagnosis | 0; I; II; III; IV; Unknown/not documented | Prefix-match GroupStage longest first: IV, then III, then II, then I, then 0. Anything else is Unknown/not documented. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 35 | `STAGEN` *[PRE_INT]* | Stage (N) | 1-5; 99 | 0=1, I=2, II=3, III=4, IV=5. 99 where no group stage is recorded. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 122 | `DTHFUFL` *[FU]* | Acceptable death / follow-up gap | 0 = No; 1 = Yes; Null | 1 if DEATH_DT_preliminary - FU_ENDDT_preliminary <= 120 days, else 0. Null where there is no death date. | 01_studypop.R - patient-level death date and follow-up end date |

### 5.4 5B.ClinChars - Clinical characteristics  (102 columns)

| # | Variable | Label | Permitted values | Definition as implemented | Built in |
|---|---|---|---|---|---|
| 21 | `MCRPCDD` *[PRE_INT]* | mCRPC milestone date | Date | Later of MetastaticDiagnosisDate and CRPCDate. If one is missing, the other. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 22 | `MCRPCDDYR` *[PRE_INT]* | mCRPC milestone year | Numeric | YEAR(MCRPCDD). | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 23 | `MCRPCTYPE` *[PRE_INT]* | mCRPC evidence type | Character | CRPCType, as given. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 24 | `MHSPCDD` *[PRE_INT]* | mHSPC milestone date | Date | Later of MetastaticDiagnosisDate and HSPCDate. If one is missing, the other. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 25 | `MHSPCDDYR` *[PRE_INT]* | mHSPC milestone year | Numeric | YEAR(MHSPCDD). | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 26 | `MHSPCTYPE` *[PRE_INT]* | mHSPC evidence type | Character | HSPCType, as given. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 27 | `INIT` *[PRE_INT]* | Initial diagnosis date | Date | DiagnosisDate. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 28 | `INITYR` *[PRE_INT]* | Initial diagnosis year | Numeric | YEAR(INIT). | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 29 | `MPCDD` *[PRE_INT]* | Metastatic diagnosis date | Date | MetastaticDiagnosisDate. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 30 | `MPCDDYR` *[PRE_INT]* | Metastatic diagnosis year | Numeric | YEAR(MPCDD). | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 31 | `TTCRPC` *[PRE_INT]* | Time from initial diagnosis to CRPC | Numeric, months | DATEDIFF(CRPCDate, DiagnosisDate) / 30.4375. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 32 | `TTHSPC` *[PRE_INT]* | Time from initial diagnosis to HSPC | Numeric, months | DATEDIFF(HSPCDate, DiagnosisDate) / 30.4375. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 33 | `TINTCRPCHSPC` *[PRE_INT]* | Time from HSPC to CRPC | Numeric, months | DATEDIFF(CRPCDate, HSPCDate) / 30.4375. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 36 | `GLEASON` *[PRE_INT]* | Gleason score group | <8; >=8; Unknown/Missing | GleasonScore in {Less than or equal to 6, 3 + 4 = 7, 4 + 3 = 7, 7 (not documented), 7 (when breakdown not available)} is <8. In {8, 9, 10} is >=8. Anything else is Unknown/Missing. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 37 | `GLEASONN` *[PRE_INT]* | Gleason score group (N) | 1; 2; 3 | <8 = 1, >=8 = 2, Unknown/Missing = 3. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 38 | `PSADIAG_INIT` *[PRE_INT]* | PSA at initial diagnosis | Numeric | PSAInitialDiagnosis, as given. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 39 | `PSADIAG_MET` *[PRE_INT]* | PSA at metastatic diagnosis | Numeric | PSAMetDiagnosis, as given. | 03_clinical.R - milestone dates, stage, Gleason, diagnosis PSA (rows 2-16, 62, 65-67) |
| 40 | `ECOG` *[LOT_ECOG]* | ECOG at baseline | 0; 1; 2; 3; 4; Unknown/Missing | Cohorts 1-2: baseline and longitudinal ECOG pooled, the record closest to the raw HSPCDate (cohort 1) or CRPCDate (cohort 2), within [INDEXDT-30, INDEXDT+7]. Cohorts 3-7: baseline ECOG matched on the index line's LineNumber and LineStartDate, the same window, the record closest to INDEXDT. Ties on distance take the earlier record; several on that date take the highest value. Any value outside 0-4 is Unknown/Missing. | 03_clinical.R - baseline ECOG (rows 47-48) |
| 41 | `ECOGN` *[LOT_ECOG]* | ECOG at baseline (N) | 1-6 | 0=1, 1=2, 2=3, 3=4, 4=5, Unknown/Missing=6. | 03_clinical.R - baseline ECOG (rows 47-48) |
| 42 | `LABNEU` *[PRE_INT]* | Neutrophils, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'neutrophils', TRIM(TestUnitsCleaned) = '10*9/L', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no neutrophils record at any date. Otherwise Unknown. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 43 | `LABNEUV` *[PRE_INT]* | Neutrophils, value (10*9/L) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the lowest value. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 44 | `LABNEUDT` *[PRE_INT]* | Neutrophils, test date | Date | The later of TestDate and ResultDate on the record behind LABNEUV. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 45 | `LABPLA` *[PRE_INT]* | Platelets, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'platelets', TRIM(TestUnitsCleaned) = '10*9/L', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no platelets record at any date. Otherwise Unknown. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 46 | `LABPLAV` *[PRE_INT]* | Platelets, value (10*9/L) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the lowest value. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 47 | `LABPLAVDT` *[PRE_INT]* | Platelets, test date | Date | The later of TestDate and ResultDate on the record behind LABPLAV. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 48 | `LABHEM` *[PRE_INT]* | Hemoglobin, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'hemoglobin', TRIM(TestUnitsCleaned) = 'g/dL', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no hemoglobin record at any date. Otherwise Unknown. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 49 | `LABHEMV` *[PRE_INT]* | Hemoglobin, value (g/dL) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the lowest value. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 50 | `LABHEMDT` *[PRE_INT]* | Hemoglobin, test date | Date | The later of TestDate and ResultDate on the record behind LABHEMV. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 51 | `LABCRE` *[PRE_INT]* | Creatinine, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'creatinine' and LabComponent = 'Creatinine, serum', TRIM(TestUnitsCleaned) = 'mg/dL', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no creatinine record at any date. Otherwise Unknown. The LabComponent filter applies to the Missing test as well as the Present one, so a patient whose only records carry a different component reads Missing. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 52 | `LABCREV` *[PRE_INT]* | Creatinine, value (mg/dL) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the lowest value. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 53 | `LABCREDT` *[PRE_INT]* | Creatinine, test date | Date | The later of TestDate and ResultDate on the record behind LABCREV. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 54 | `LABBIL` *[PRE_INT]* | Bilirubin, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'bilirubin', TRIM(TestUnitsCleaned) = 'mg/dL', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no bilirubin record at any date. Otherwise Unknown. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 55 | `LABBILV` *[PRE_INT]* | Bilirubin, value (mg/dL) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the highest value. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 56 | `LABBILDT` *[PRE_INT]* | Bilirubin, test date | Date | The later of TestDate and ResultDate on the record behind LABBILV. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 57 | `LABAST` *[PRE_INT]* | Aspartate aminotransferase, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'aspartate aminotransferase', TRIM(TestUnitsCleaned) = 'U/L', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no aspartate aminotransferase record at any date. Otherwise Unknown. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 58 | `LABASTV` *[PRE_INT]* | Aspartate aminotransferase, value (U/L) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the highest value. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 59 | `LABASTDT` *[PRE_INT]* | Aspartate aminotransferase, test date | Date | The later of TestDate and ResultDate on the record behind LABASTV. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 60 | `LABALT` *[PRE_INT]* | Alanine aminotransferase, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'alanine aminotransferase', TRIM(TestUnitsCleaned) = 'U/L', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no alanine aminotransferase record at any date. Otherwise Unknown. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 61 | `LABALTV` *[PRE_INT]* | Alanine aminotransferase, value (U/L) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the highest value. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 62 | `LABALTDT` *[PRE_INT]* | Alanine aminotransferase, test date | Date | The later of TestDate and ResultDate on the record behind LABALTV. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 63 | `LABALP` *[PRE_INT]* | Alkaline phosphatase, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'alkaline phosphatase', TRIM(TestUnitsCleaned) = 'U/L', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no alkaline phosphatase record at any date. Otherwise Unknown. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 64 | `LABALPV` *[PRE_INT]* | Alkaline phosphatase, value (U/L) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the highest value. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 65 | `LABALPDT` *[PRE_INT]* | Alkaline phosphatase, test date | Date | The later of TestDate and ResultDate on the record behind LABALPV. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 66 | `LABALB` *[PRE_INT]* | Albumin, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'albumin' and LabComponent = 'Albumin, serum', TRIM(TestUnitsCleaned) = 'g/L', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no albumin record at any date. Otherwise Unknown. The LabComponent filter applies to the Missing test as well as the Present one, so a patient whose only records carry a different component reads Missing. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 67 | `LABALBV` *[PRE_INT]* | Albumin, value (g/L) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the lowest value. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 68 | `LABALBDT` *[PRE_INT]* | Albumin, test date | Date | The later of TestDate and ResultDate on the record behind LABALBV. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 69 | `LABLYM` *[PRE_INT]* | Lymphocytes, record status | Present; Unknown; Missing | Present if a record with TestBaseName = 'lymphocytes', TRIM(TestUnitsCleaned) = '10*9/L', a non-null TestDate and TestResultCleaned > 0 falls on or before INDEXDT. Missing if the patient has no lymphocytes record at any date. Otherwise Unknown. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 70 | `LABLYMV` *[PRE_INT]* | Lymphocytes, value (10*9/L) | Numeric | TestResultCleaned from the qualifying record closest to INDEXDT. Several on that date take the highest value. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 71 | `LABLYMDT` *[PRE_INT]* | Lymphocytes, test date | Date | The later of TestDate and ResultDate on the record behind LABLYMV. | 03_clinical.R - baseline laboratory values (rows 17-46) |
| 72 | `BP` *[PRE_INT]* | Blood pressure, record status | Present; Unknown; Missing | Present if some TestDate on or before INDEXDT carries both a systolic and a diastolic reading and both are positive integers. Missing if the patient has no systolic and no diastolic record at any date. Otherwise Unknown. | 03_clinical.R - blood pressure (rows 49-53) |
| 73 | `BPN` *[PRE_INT]* | Blood pressure, record status (N) | 1; 2; 3 | Present = 1, Unknown = 2, Missing = 3. | 03_clinical.R - blood pressure (rows 49-53) |
| 74 | `BPDT` *[PRE_INT]* | Blood pressure date | Date | The qualifying date closest to INDEXDT. Ties take the earlier date. | 03_clinical.R - blood pressure (rows 49-53) |
| 75 | `BPSYS` *[PRE_INT]* | Systolic blood pressure | Numeric | Highest systolic reading on BPDT. | 03_clinical.R - blood pressure (rows 49-53) |
| 76 | `BPDIA` *[PRE_INT]* | Diastolic blood pressure | Numeric | Highest diastolic reading on BPDT. | 03_clinical.R - blood pressure (rows 49-53) |
| 77 | `CSF_PRE` *[PRE_INT]* | Growth factor before index | 0; 1 | 1 if a record with DetailedDrugCategory = 'growth factor' dated on or before INDEXDT appears in drug episodes, medication orders that are not cancelled, or medication administrations. | 03_clinical.R - concomitant medication flags (rows 54-56) |
| 78 | `CSF_FU` *[FU]* | Growth factor in follow-up | 0; 1 | The same three sources, dated after INDEXDT and on or before FUED. | 03_clinical.R - concomitant medication flags (rows 54-56) |
| 79 | `SS` *[PRE_INT]* | Steroid before index | 0; 1 | 1 if a record with DrugCategory = 'steroid' dated on or before INDEXDT appears in the same three sources. | 03_clinical.R - concomitant medication flags (rows 54-56) |
| 80 | `WEIGHT` *[PRE_INT]* | Weight (kg) | Numeric | Vitals 'body weight' in kg with a non-null TestResultCleaned. Take the latest vital date on or before INDEXDT, then the highest value on that date. | 03_clinical.R - vitals: weight, height, BMI, BSA (rows 57-64) |
| 81 | `WEIGHTDT` *[PRE_INT]* | Weight date | Date | The vital date behind WEIGHT. | 03_clinical.R - vitals: weight, height, BMI, BSA (rows 57-64) |
| 82 | `HEIGHT` *[PRE_INT]* | Height (cm) | Numeric | Vitals 'body height' in cm, by the same rule as WEIGHT. | 03_clinical.R - vitals: weight, height, BMI, BSA (rows 57-64) |
| 83 | `HEIGHTDT` *[PRE_INT]* | Height date | Date | The vital date behind HEIGHT. | 03_clinical.R - vitals: weight, height, BMI, BSA (rows 57-64) |
| 84 | `BMI` *[PRE_INT]* | Body mass index | Numeric | WEIGHT / (HEIGHT/100)^2. Null unless both are present and HEIGHT is not zero. | 03_clinical.R - vitals: weight, height, BMI, BSA (rows 57-64) |
| 85 | `BMIGR1` *[PRE_INT]* | BMI group | Underweight; Normal weight; Overweight; Obese; Missing | Under 18.5 Underweight; 18.5 to under 25 Normal weight; 25 to under 30 Overweight; 30 and over Obese; otherwise Missing. | 03_clinical.R - vitals: weight, height, BMI, BSA (rows 57-64) |
| 86 | `BMIGR1N` *[PRE_INT]* | BMI group (N) | 1-5 | Numeric of BMIGR1 in the Values order, Missing = 5. | 03_clinical.R - vitals: weight, height, BMI, BSA (rows 57-64) |
| 87 | `BSA` *[PRE_INT]* | Body surface area | Numeric | 0.007184 * HEIGHT^0.725 * WEIGHT^0.425. Null unless both are present and neither is negative. | 03_clinical.R - vitals: weight, height, BMI, BSA (rows 57-64) |
| 88 | `PSADIAG_CRPC` *[PRE_INT]* | PSA at the mCRPC milestone | Numeric | ScoreSerial from the earliest PSA result in [CRPCDate - 14, CRPCDate]. Several on that day take the highest. | 03_clinical.R - PSA at the mCRPC milestone and at index (rows 68-69) |
| 89 | `PSA_INDEX` *[PSA_INDEX]* | PSA at index | Numeric | ScoreSerial from the earliest PSA result in [INDEXDT - 14, INDEXDT]. Several on that day take the highest. | 03_clinical.R - PSA at the mCRPC milestone and at index (rows 68-69) |
| 90 | `HRR_INDEX` *[BIOMARKER]* | HRR status at index | Positive; Negative; VUS; Unknown/Not documented | One winning test date per patient: the biomarker test closest to INDEXDT within [INDEXDT-30, INDEXDT+7], taken over every gene and every test type, with equidistant ties going to the earlier test. On that date resolve within each HRR gene - Positive+Negative gives Unknown; Positive with Unknown or VUS gives Positive; Negative with Unknown or VUS gives Negative; VUS+Unknown gives Unknown - then roll up across genes best first: Positive, Negative, VUS, Unknown. | 03_clinical.R - biomarker status at index (rows 70-77) |
| 91 | `HRR_INDEXN` *[BIOMARKER]* | HRR status at index (N) | 1-4 | Positive = 1, Negative = 2, VUS = 3, Unknown/Not documented = 4. | 03_clinical.R - biomarker status at index (rows 70-77) |
| 92 | `HRR_LABEL_INDEX` *[BIOMARKER]* | HRR status, olaparib label panel | Positive; Negative; VUS; Unknown/Not documented | The same derivation as HRR_INDEX, over the 14 genes named on the olaparib label. | 03_clinical.R - biomarker status at index (rows 70-77) |
| 93 | `HRR_LABEL_INDEXN` *[BIOMARKER]* | HRR status, olaparib label panel (N) | 1-4 | Positive = 1, Negative = 2, VUS = 3, Unknown/Not documented = 4. | 03_clinical.R - biomarker status at index (rows 70-77) |
| 94 | `BRCA_INDEX` *[BIOMARKER]* | BRCA status at index | Positive; Negative; VUS; Unknown/Not documented | The same derivation over BRCA1 and BRCA2, on the same winning date as HRR_INDEX. | 03_clinical.R - biomarker status at index (rows 70-77) |
| 95 | `BRCA_INDEXN` *[BIOMARKER]* | BRCA status at index (N) | 1-4 | Positive = 1, Negative = 2, VUS = 3, Unknown/Not documented = 4. | 03_clinical.R - biomarker status at index (rows 70-77) |
| 96 | `HRR_INDEX_TEST` *[BIOMARKER]* | HRR test type | Unknown | Emitted as Unknown for every patient. | 03_clinical.R - biomarker status at index (rows 70-77) |
| 97 | `HRR_INDEX_TESTN` *[BIOMARKER]* | HRR test type (N) | 7 | Emitted as 7. | 03_clinical.R - biomarker status at index (rows 70-77) |
| 98 | `BRCA_INDEX_TEST` *[BIOMARKER]* | BRCA test type | Unknown | Emitted as Unknown for every patient. | 03_clinical.R - biomarker status at index (rows 70-77) |
| 99 | `BRCA_INDEX_TESTN` *[BIOMARKER]* | BRCA test type (N) | 7 | Emitted as 7. | 03_clinical.R - biomarker status at index (rows 70-77) |
| 100 | `PSMA_SCANDT` *[PRE_INT]* | Latest PSMA PET scan date | Date | Latest ScanDate on or before INDEXDT. | 03_clinical.R - PSMA PET scan (rows 78-79) |
| 101 | `PSMA_SCANRESULT` *[PRE_INT]* | PSMA PET disease evidence | Yes; No; Unknown/not documented | IsDiseaseEvidence on PSMA_SCANDT. Yes and No on the same date give Unknown/not documented; Yes with Unknown gives Yes; No with Unknown gives No. No scan gives Unknown/not documented. | 03_clinical.R - PSMA PET scan (rows 78-79) |
| 102 | `LUNG_METDT` *[PRE_INT/FU]* | Lung metastasis date | Date | Earliest DateOfMetastasis for site Lung, with no date bound; the date may postdate MAXINDEX. | 03_clinical.R - sites of metastasis (rows 80-87) |
| 103 | `LUNG_MET` *[PRE_INT]* | Lung metastasis at index | Yes; No | Yes if LUNG_METDT is on or before INDEXDT, else No. | 03_clinical.R - sites of metastasis (rows 80-87) |
| 104 | `ADRENAL_METDT` *[PRE_INT/FU]* | Adrenal metastasis date | Date | Earliest DateOfMetastasis for site Adrenal, with no date bound; the date may postdate MAXINDEX. | 03_clinical.R - sites of metastasis (rows 80-87) |
| 105 | `ADRENAL_MET` *[PRE_INT]* | Adrenal metastasis at index | Yes; No | Yes if ADRENAL_METDT is on or before INDEXDT, else No. | 03_clinical.R - sites of metastasis (rows 80-87) |
| 106 | `BONE_METDT` *[PRE_INT/FU]* | Bone metastasis date | Date | Earliest DateOfMetastasis for site Bone, with no date bound; the date may postdate MAXINDEX. | 03_clinical.R - sites of metastasis (rows 80-87) |
| 107 | `BONE_MET` *[PRE_INT]* | Bone metastasis at index | Yes; No | Yes if BONE_METDT is on or before INDEXDT, else No. | 03_clinical.R - sites of metastasis (rows 80-87) |
| 108 | `BRAIN_METDT` *[PRE_INT/FU]* | Brain metastasis date | Date | Earliest DateOfMetastasis for site Brain, with no date bound; the date may postdate MAXINDEX. | 03_clinical.R - sites of metastasis (rows 80-87) |
| 109 | `BRAIN_MET` *[PRE_INT]* | Brain metastasis at index | Yes; No | Yes if BRAIN_METDT is on or before INDEXDT, else No. | 03_clinical.R - sites of metastasis (rows 80-87) |
| 110 | `MIN_VST_DT` *[PRE_INT/FU]* | First visit date | Date | Earliest VisitDate. | 01_studypop.R - patient-level death date and follow-up end date |
| 111 | `MIN_VSTTELEMED_DT` *[PRE_INT/FU]* | First telemedicine visit date | Date | Earliest telemedicine VisitDate. | 01_studypop.R - patient-level death date and follow-up end date |
| 112 | `MIN_MEDORD_DT` *[PRE_INT/FU]* | First medication order date | Date | Earliest ExpectedStartDate among medication orders that are not cancelled. | 01_studypop.R - patient-level death date and follow-up end date |
| 113 | `MAX_VSTTELEMED_DT` *[PRE_INT/FU]* | Last telemedicine visit date | Date | Latest telemedicine VisitDate. | 01_studypop.R - patient-level death date and follow-up end date |
| 114 | `MAX_LOTEND_DT` *[PRE_INT/FU]* | Last line-of-therapy end date | Date | Latest line-of-therapy EndDate. | 01_studypop.R - patient-level death date and follow-up end date |
| 115 | `MAX_DRUG_EP_ABSTRACTED_DT` *[PRE_INT/FU]* | Last abstracted drug-episode date | Date | Latest EpisodeDate where EpisodeDataSource = 'Abstraction'. | 01_studypop.R - patient-level death date and follow-up end date |
| 116 | `FU_ENDDT_PRELIMINARY` *[FU]* | Last activity date | Date | Latest of four dates: last visit, last telemedicine visit, last line-of-therapy end, and last oral end date where the start-date granularity is not YEAR and the end date is present. | 01_studypop.R - patient-level death date and follow-up end date |
| 117 | `DATEOFDEATH` *[FU]* | Death date, source value | Character | DateOfDeath, as given. | 01_studypop.R - patient-level death date and follow-up end date |
| 118 | `DEATH_DT_PRELIMINARY` *[FU]* | Death date, imputed | Date | From DATEOFDEATH, imputed to the middle of the period and not adjusted again. Length 7 (YYYY-MM) imputes day 15; length 4 (YYYY) imputes 07-15. Any other length is NULL. | 01_studypop.R - patient-level death date and follow-up end date |
| 119 | `DTHDT` *[FU]* | Death date, final | Date | DEATH_DT_preliminary, unchanged. The row-92 promotion to the last day of the month is withdrawn. | 01_studypop.R - patient-level death date and follow-up end date |
| 120 | `DTHFL` *[FU]* | Death flag | 0 = No; 1 = Yes | 1 if DTHDT is not null, else 0. | 01_studypop.R - patient-level death date and follow-up end date |
| 121 | `FUED` *[FU]* | Follow-up end date | Date | DTHDT where a death date exists, otherwise FU_ENDDT_preliminary. NOT the earlier of the two. | 01_studypop.R - patient-level death date and follow-up end date |
| 123 | `DTH_BEFORE_FUED` *[FU]* | Death before follow-up end | 0; 1 | 1 if DTHDT and FUED are both present and DTHDT < FUED, else 0. | 01_studypop.R - patient-level death date and follow-up end date |
| 124 | `FUDUR` *[FU]* | Follow-up duration | Numeric, days | DATEDIFF(FUED, INDEXDT) + 1. | 03_clinical.R - master clinical: combine the pieces |
| 125 | `INDEXYR` *[INDEX]* | Index year | Numeric | YEAR(INDEXDT). | 03_clinical.R - master clinical: combine the pieces |

### 5.5 5C.TreatVars - Treatment  (44 columns)

| # | Variable | Label | Permitted values | Definition as implemented | Built in |
|---|---|---|---|---|---|
| 126 | `LOT1_MHSPC` *[PRE_INT/FU]* | Line 1 regimen, mHSPC | Character | LineName of the line with NEW_LOT_N = 1 in the mHSPC setting. NULL where the line does not exist. | 04_treatment.R |
| 127 | `LOT1SD_MHSPC` *[PRE_INT/FU]* | Line 1 start date, mHSPC | Date | StartDate of the line with NEW_LOT_N = 1 in the mHSPC setting. | 04_treatment.R |
| 128 | `LOT1ED_MHSPC` *[PRE_INT/FU]* | Line 1 end date, mHSPC | Date | Latest EpisodeDate in the drug-episode table for that line, matched on the source LineNumber within the mHSPC setting. | 04_treatment.R |
| 129 | `LOT1CAT_MHSPC` *[PRE_INT/FU]* | Line 1 category, mHSPC | 1 Abiraterone monotherapy; 2 Enzalutamide monotherapy; 3 Apalutamide monotherapy; 4 Darolutamide monotherapy; 5 NHA combination therapy; 6 Docetaxel monotherapy; 7 Docetaxel combination therapy; 8 Cabazitaxel-containing; 9 Other chemotherapy-containing; 10 Pluvicto-containing; 11 Radium 223-containing; 12 PARPi monotherapy; 13 Pembrolizumab-containing; 14 Sipuleucel-T-containing; 15 Clinical study drug-containing; 16 Any other therapy; 17 No treatment | Classify the line's LineName, first match wins, in the order the Values list gives. A monotherapy category is a whole-string match; a combination category needs the drug plus a comma or slash. Other chemotherapy-containing reads DetailedDrugCategory = 'chemotherapy' on the line's drug episodes. PARPi monotherapy is an anchored whole-string match on olaparib, talazoparib, niraparib and rucaparib with no other drug allowed. A null LineName is No treatment. | 04_treatment.R |
| 130 | `LOT1CATN_MHSPC` *[PRE_INT/FU]* | Line 1 category (N), mHSPC | 1-17 | Numeric of the category, per the Values list. | 04_treatment.R |
| 131 | `LOT2_MHSPC` *[PRE_INT/FU]* | Line 2 regimen, mHSPC | Character | LineName of the line with NEW_LOT_N = 2 in the mHSPC setting. NULL where the line does not exist. | 04_treatment.R |
| 132 | `LOT2SD_MHSPC` *[PRE_INT/FU]* | Line 2 start date, mHSPC | Date | StartDate of the line with NEW_LOT_N = 2 in the mHSPC setting. | 04_treatment.R |
| 133 | `LOT2ED_MHSPC` *[PRE_INT/FU]* | Line 2 end date, mHSPC | Date | Latest EpisodeDate in the drug-episode table for that line, matched on the source LineNumber within the mHSPC setting. | 04_treatment.R |
| 134 | `LOT2CAT_MHSPC` *[PRE_INT/FU]* | Line 2 category, mHSPC | 1 Abiraterone monotherapy; 2 Enzalutamide monotherapy; 3 Apalutamide monotherapy; 4 Darolutamide monotherapy; 5 NHA combination therapy; 6 Docetaxel monotherapy; 7 Docetaxel combination therapy; 8 Cabazitaxel-containing; 9 Other chemotherapy-containing; 10 Pluvicto-containing; 11 Radium 223-containing; 12 PARPi monotherapy; 13 Pembrolizumab-containing; 14 Sipuleucel-T-containing; 15 Clinical study drug-containing; 16 Any other therapy; 17 No treatment | Classify the line's LineName, first match wins, in the order the Values list gives. A monotherapy category is a whole-string match; a combination category needs the drug plus a comma or slash. Other chemotherapy-containing reads DetailedDrugCategory = 'chemotherapy' on the line's drug episodes. PARPi monotherapy is an anchored whole-string match on olaparib, talazoparib, niraparib and rucaparib with no other drug allowed. A null LineName is No treatment. | 04_treatment.R |
| 135 | `LOT2CATN_MHSPC` *[PRE_INT/FU]* | Line 2 category (N), mHSPC | 1-17 | Numeric of the category, per the Values list. | 04_treatment.R |
| 136 | `LOT1_MCRPC` *[PRE_INT/FU]* | Line 1 regimen, mCRPC | Character | LineName of the line with NEW_LOT_N = 1 in the mCRPC setting. NULL where the line does not exist. | 04_treatment.R |
| 137 | `LOT1SD_MCRPC` *[PRE_INT/FU]* | Line 1 start date, mCRPC | Date | StartDate of the line with NEW_LOT_N = 1 in the mCRPC setting. | 04_treatment.R |
| 138 | `LOT1ED_MCRPC` *[PRE_INT/FU]* | Line 1 end date, mCRPC | Date | Latest EpisodeDate in the drug-episode table for that line, matched on the source LineNumber within the mCRPC setting. | 04_treatment.R |
| 139 | `LOT1CAT_MCRPC` *[PRE_INT/FU]* | Line 1 category, mCRPC | 1 Abiraterone monotherapy; 2 Enzalutamide monotherapy; 3 Apalutamide monotherapy; 4 Darolutamide monotherapy; 5 NHA combination therapy; 6 Docetaxel monotherapy; 7 Docetaxel combination therapy; 8 Cabazitaxel-containing; 9 Other chemotherapy-containing; 10 Pluvicto-containing; 11 Radium 223-containing; 12 PARPi monotherapy; 13 Pembrolizumab-containing; 14 Sipuleucel-T-containing; 15 Clinical study drug-containing; 16 Any other therapy; 17 No treatment | Classify the line's LineName, first match wins, in the order the Values list gives. A monotherapy category is a whole-string match; a combination category needs the drug plus a comma or slash. Other chemotherapy-containing reads DetailedDrugCategory = 'chemotherapy' on the line's drug episodes. PARPi monotherapy is an anchored whole-string match on olaparib, talazoparib, niraparib and rucaparib with no other drug allowed. A null LineName is No treatment. | 04_treatment.R |
| 140 | `LOT1CATN_MCRPC` *[PRE_INT/FU]* | Line 1 category (N), mCRPC | 1-17 | Numeric of the category, per the Values list. | 04_treatment.R |
| 141 | `LOT2_MCRPC` *[PRE_INT/FU]* | Line 2 regimen, mCRPC | Character | LineName of the line with NEW_LOT_N = 2 in the mCRPC setting. NULL where the line does not exist. | 04_treatment.R |
| 142 | `LOT2SD_MCRPC` *[PRE_INT/FU]* | Line 2 start date, mCRPC | Date | StartDate of the line with NEW_LOT_N = 2 in the mCRPC setting. | 04_treatment.R |
| 143 | `LOT2ED_MCRPC` *[PRE_INT/FU]* | Line 2 end date, mCRPC | Date | Latest EpisodeDate in the drug-episode table for that line, matched on the source LineNumber within the mCRPC setting. | 04_treatment.R |
| 144 | `LOT2CAT_MCRPC` *[PRE_INT/FU]* | Line 2 category, mCRPC | 1 Abiraterone monotherapy; 2 Enzalutamide monotherapy; 3 Apalutamide monotherapy; 4 Darolutamide monotherapy; 5 NHA combination therapy; 6 Docetaxel monotherapy; 7 Docetaxel combination therapy; 8 Cabazitaxel-containing; 9 Other chemotherapy-containing; 10 Pluvicto-containing; 11 Radium 223-containing; 12 PARPi monotherapy; 13 Pembrolizumab-containing; 14 Sipuleucel-T-containing; 15 Clinical study drug-containing; 16 Any other therapy; 17 No treatment | Classify the line's LineName, first match wins, in the order the Values list gives. A monotherapy category is a whole-string match; a combination category needs the drug plus a comma or slash. Other chemotherapy-containing reads DetailedDrugCategory = 'chemotherapy' on the line's drug episodes. PARPi monotherapy is an anchored whole-string match on olaparib, talazoparib, niraparib and rucaparib with no other drug allowed. A null LineName is No treatment. | 04_treatment.R |
| 145 | `LOT2CATN_MCRPC` *[PRE_INT/FU]* | Line 2 category (N), mCRPC | 1-17 | Numeric of the category, per the Values list. | 04_treatment.R |
| 146 | `LOT3_MCRPC` *[PRE_INT/FU]* | Line 3 regimen, mCRPC | Character | LineName of the line with NEW_LOT_N = 3 in the mCRPC setting. NULL where the line does not exist. | 04_treatment.R |
| 147 | `LOT3SD_MCRPC` *[PRE_INT/FU]* | Line 3 start date, mCRPC | Date | StartDate of the line with NEW_LOT_N = 3 in the mCRPC setting. | 04_treatment.R |
| 148 | `LOT3ED_MCRPC` *[PRE_INT/FU]* | Line 3 end date, mCRPC | Date | Latest EpisodeDate in the drug-episode table for that line, matched on the source LineNumber within the mCRPC setting. | 04_treatment.R |
| 149 | `LOT3CAT_MCRPC` *[PRE_INT/FU]* | Line 3 category, mCRPC | 1 Abiraterone monotherapy; 2 Enzalutamide monotherapy; 3 Apalutamide monotherapy; 4 Darolutamide monotherapy; 5 NHA combination therapy; 6 Docetaxel monotherapy; 7 Docetaxel combination therapy; 8 Cabazitaxel-containing; 9 Other chemotherapy-containing; 10 Pluvicto-containing; 11 Radium 223-containing; 12 PARPi monotherapy; 13 Pembrolizumab-containing; 14 Sipuleucel-T-containing; 15 Clinical study drug-containing; 16 Any other therapy; 17 No treatment | Classify the line's LineName, first match wins, in the order the Values list gives. A monotherapy category is a whole-string match; a combination category needs the drug plus a comma or slash. Other chemotherapy-containing reads DetailedDrugCategory = 'chemotherapy' on the line's drug episodes. PARPi monotherapy is an anchored whole-string match on olaparib, talazoparib, niraparib and rucaparib with no other drug allowed. A null LineName is No treatment. | 04_treatment.R |
| 150 | `LOT3CATN_MCRPC` *[PRE_INT/FU]* | Line 3 category (N), mCRPC | 1-17 | Numeric of the category, per the Values list. | 04_treatment.R |
| 151 | `LOT4_MCRPC` *[PRE_INT/FU]* | Line 4 regimen, mCRPC | Character | LineName of the line with NEW_LOT_N = 4 in the mCRPC setting. NULL where the line does not exist. | 04_treatment.R |
| 152 | `LOT4SD_MCRPC` *[PRE_INT/FU]* | Line 4 start date, mCRPC | Date | StartDate of the line with NEW_LOT_N = 4 in the mCRPC setting. | 04_treatment.R |
| 153 | `LOT4ED_MCRPC` *[PRE_INT/FU]* | Line 4 end date, mCRPC | Date | Latest EpisodeDate in the drug-episode table for that line, matched on the source LineNumber within the mCRPC setting. | 04_treatment.R |
| 154 | `LOT4CAT_MCRPC` *[PRE_INT/FU]* | Line 4 category, mCRPC | 1 Abiraterone monotherapy; 2 Enzalutamide monotherapy; 3 Apalutamide monotherapy; 4 Darolutamide monotherapy; 5 NHA combination therapy; 6 Docetaxel monotherapy; 7 Docetaxel combination therapy; 8 Cabazitaxel-containing; 9 Other chemotherapy-containing; 10 Pluvicto-containing; 11 Radium 223-containing; 12 PARPi monotherapy; 13 Pembrolizumab-containing; 14 Sipuleucel-T-containing; 15 Clinical study drug-containing; 16 Any other therapy; 17 No treatment | Classify the line's LineName, first match wins, in the order the Values list gives. A monotherapy category is a whole-string match; a combination category needs the drug plus a comma or slash. Other chemotherapy-containing reads DetailedDrugCategory = 'chemotherapy' on the line's drug episodes. PARPi monotherapy is an anchored whole-string match on olaparib, talazoparib, niraparib and rucaparib with no other drug allowed. A null LineName is No treatment. | 04_treatment.R |
| 155 | `LOT4CATN_MCRPC` *[PRE_INT/FU]* | Line 4 category (N), mCRPC | 1-17 | Numeric of the category, per the Values list. | 04_treatment.R |
| 156 | `LOTN` *[PRE_INT/FU]* | Number of mCRPC lines | Numeric | Highest NEW_LOT_N in the mCRPC setting; 0 if the patient has none. | 04_treatment.R |
| 157 | `LOTNGR1` *[PRE_INT/FU]* | Number of mCRPC lines, grouped | 0; 1; 2; 3; 4; 5+ | Band LOTN. | 04_treatment.R |
| 158 | `LOTNGR1N` *[PRE_INT/FU]* | Number of mCRPC lines, grouped (N) | 1-6 | 0 = 1, 1 = 2, 2 = 3, 3 = 4, 4 = 5, 5+ = 6. | 04_treatment.R |
| 159 | `LOTN_MHSPC` *[PRE_INT/FU]* | Number of mHSPC lines | Numeric | Highest NEW_LOT_N in the mHSPC setting; 0 if the patient has none. | 04_treatment.R |
| 160 | `LOTNGR1_MHSPC` *[PRE_INT/FU]* | Number of mHSPC lines, grouped | 0; 1; 2; 3; 4; 5+ | Band LOTN_MHSPC. | 04_treatment.R |
| 161 | `LOTNGR1N_MHSPC` *[PRE_INT/FU]* | Number of mHSPC lines, grouped (N) | 1-6 | 0 = 1, 1 = 2, 2 = 3, 3 = 4, 4 = 5, 5+ = 6. | 04_treatment.R |
| 162 | `PRIOR_PLUVICTO` *[PRE_INT]* | Prior Pluvicto | Yes; No | Read from the drug-episode regimen names with EpisodeDate before INDEXDT, in any setting. Yes if a regimen contains vipivotide tetraxetan. | 04_treatment.R |
| 163 | `PRIOR_PARP` *[PRE_INT]* | Prior PARP inhibitor | Yes; No | Read from the drug-episode regimen names with EpisodeDate before INDEXDT, in any setting. Yes if a regimen is made up only of olaparib, talazoparib, niraparib or rucaparib, separated by comma or slash. | 04_treatment.R |
| 164 | `PRIOR_CHEMO` *[PRE_INT]* | Prior chemotherapy | Yes; No | Read from the drug-episode regimen names with EpisodeDate before INDEXDT, in any setting. Yes if any drug episode has DetailedDrugCategory = 'chemotherapy'. | 04_treatment.R |
| 165 | `PRIOR_NHA_ADT` *[PRE_INT]* | Prior NHA combination | Yes; No | Read from the drug-episode regimen names with EpisodeDate before INDEXDT, in any setting. Yes if a regimen contains an NHA - abiraterone, enzalutamide, apalutamide or darolutamide - and at least one further drug. | 04_treatment.R |
| 166 | `PRIOR_DOCETAXEL` *[PRE_INT]* | Prior docetaxel | Yes; No | Read from the drug-episode regimen names with EpisodeDate before INDEXDT, in any setting. Yes if a regimen contains docetaxel. | 04_treatment.R |
| 167 | `PRIOR_ABIRATERONE` *[PRE_INT]* | Prior abiraterone | Yes; No | Read from the drug-episode regimen names with EpisodeDate before INDEXDT, in any setting. Yes if a regimen contains abiraterone. | 04_treatment.R |
| 168 | `PRIOR_ARPI` *[PRE_INT]* | Prior ARPI | Yes; No | Read from the drug-episode regimen names with EpisodeDate before INDEXDT, in any setting. Yes if a regimen contains any NHA, alone or in combination. | 04_treatment.R |
| 169 | `CSD` *[PRE_INT/FU]* | Clinical study drug | 0; 1 | Cohorts 3-7: 1 if the index line's regimen name contains 'clinical study drug'. Cohorts 1-2: 1 if any line in the cohort's setting does. | 04_treatment.R |

### 5.6 6.Outcomes - Outcomes  (13 columns)

| # | Variable | Label | Permitted values | Definition as implemented | Built in |
|---|---|---|---|---|---|
| 170 | `OS` *[FU]* | Overall survival | Numeric, months | Dead: (DATEDIFF(DTHDT, INDEXDT) + 1) / 30.4375. Alive: (DATEDIFF(FUED, INDEXDT) + 1) / 30.4375. Null when DTH_BEFORE_FUED = 1. | 05_outcomes.R |
| 171 | `VIS120` *[FU]* | Visit 120 days after the index line | 0; 1 | Cohorts 3-7: 1 if a visit or telemedicine visit falls on or after the index line's end date plus 120 days, else 0. Null for cohorts 1-2, which have no index line. | 05_outcomes.R |
| 172 | `TTNT` *[FU]* | Time to next treatment | Numeric, months | Cohorts 3-6 with ID3MOSFU = 1. Next treatment is: cohort 3, the earlier of LOT2SD_MHSPC and LOT1SD_MCRPC; cohort 4, LOT2SD_MCRPC; cohort 5, LOT3SD_MCRPC; cohort 6, LOT4SD_MCRPC. Event, meaning a next treatment or a death is seen: (DATEDIFF(earlier of next treatment and DTHDT, INDEXDT) + 1) / 30.4375. Otherwise censored at FUED. Null when DTH_BEFORE_FUED = 1, and for cohorts 1, 2 and 7. | 05_outcomes.R |
| 173 | `ELIGPFS` *[FU]* | rwPFS eligibility | 0; 1 | 1 if ID3MOSFU = 1 and the last clinic note falls after INDEXDT, else 0. Null for cohorts 1-2. | 05_outcomes.R |
| 174 | `PFSFL` *[FU]* | rwPFS event flag | 0; 1 | Among eligible patients: 1 if an eligible progression is seen, or none is seen and the patient died; else 0. Null for cohorts 1-2. | 05_outcomes.R |
| 175 | `PFSDT` *[FU]* | rwPFS event date | Date | First progression dated on or after INDEXDT + 14 carrying any progression evidence other than pseudo-progression. Where no eligible progression is seen and the patient died, DTHDT. Missing when there is no event. | 05_outcomes.R |
| 176 | `PFS` *[FU]* | rwPFS | Numeric, months | Event: (DATEDIFF(PFSDT, INDEXDT) + 1) / 30.4375. Censored: (DATEDIFF(LastClinicNoteDate, INDEXDT) + 1) / 30.4375. Null for cohorts 1-2. | 05_outcomes.R |
| 177 | `PSA6MO` *[FU]* | PSA at 6 months | Numeric | Earliest ScoreSerial in [INDEXDT + 180, INDEXDT + 210]. Several on that day take the highest. | 05_outcomes.R |
| 178 | `PSA50_6MO` *[FU]* | PSA50 response at 6 months | Y; N | Y if (PSA6MO - PSA_INDEX) / PSA_INDEX <= -0.5, with PSA_INDEX > 0. Else N. | 05_outcomes.R |
| 179 | `PSAL6MO` *[FU]* | PSA under 0.2 at 6 months | Y; N | Y if PSA6MO < 0.2, else N. | 05_outcomes.R |
| 180 | `PSA12MO` *[FU]* | PSA at 12 months | Numeric | Earliest ScoreSerial in [INDEXDT + 365, INDEXDT + 395]. Several on that day take the highest. | 05_outcomes.R |
| 181 | `PSA50_12MO` *[FU]* | PSA50 response at 12 months | Y; N | Y if (PSA12MO - PSA_INDEX) / PSA_INDEX <= -0.5, with PSA_INDEX > 0. Else N. | 05_outcomes.R |
| 182 | `PSAL12MO` *[FU]* | PSA under 0.2 at 12 months | Y; N | Y if PSA12MO < 0.2, else N. | 05_outcomes.R |

## 6. Intermediate variables

Values the build creates on the way to a delivered column. Check these when a
delivered value looks wrong and its own definition looks right: most of the
specification's harder derivations are two or three steps, and the step that
went wrong is usually here rather than in the final column.

**Delivered** says whether the value reaches the ADS. Several do, because the
specification asks for its own working dates to be kept.

| Intermediate | Built in | What it is | Feeds | Delivered |
|---|---|---|---|---|
| `index_date` | `01_studypop.R`, `index_lot_cohort()` | The cohort's index date: the setting's milestone for cohorts 1-2, the index line's start date for 3-7. Every window in the row is relative to it | everything time-anchored | as `INDEXDT` |
| `new_lot_n` | `00_setup.R`, `lot_tbl()` | Line number within a patient and a setting, ordered by start date. **Not** the source's own line number | cohort membership 3-7, every `LOT*` column | no |
| `id_pd_mcrpc`, `id_pd_mhspc` | `03_clinical.R`, milestone block | Whether the setting's milestone falls inside `[MININDEX, MAXINDEX]` - the inclusion test | cohort membership | yes |
| `last_visitdate`, `last_televisitdate`, `last_lotenddate`, `last_oralenddate` | `01_studypop.R`, death and follow-up block | The four activity dates the spec lists at row 89. The oral end date is filtered to non-year granularity with an end date present | `FU_ENDDT_preliminary` | no |
| `min_vst_dt`, `min_vsttelemed_dt`, `min_medord_dt`, `max_drug_ep_abstracted_dt` | `01_studypop.R`, death and follow-up block | Row-88 interim dates. They play no part in the follow-up derivation; row 88 asks for them by name, so they are produced and carried through. `max_drug_ep_abstracted_dt` is null for every patient because its source value does not exist in this cut | nothing | yes |
| `fu_enddt_preliminary` | `01_studypop.R`, death and follow-up block | The latest of those four activity dates - the "last activity date" | `FUED`, `DTHFUFL` | yes |
| `dateofdeath_init` | `01_studypop.R`, death and follow-up block | `DATEOFDEATH` imputed to the middle of the period: day 15 for a month-and-year value, 15 July for a year-only value, NULL for any other length | `DEATH_DT_preliminary` | no |
| `death_dt_preliminary` | `01_studypop.R`, death and follow-up block | The imputed value itself, with nothing applied after it | `DTHDT`, `DTHFUFL` | yes |
| `dthfufl_dur` | `01_studypop.R`, death and follow-up block | `DEATH_DT_preliminary - FU_ENDDT_preliminary` in days, on the **preliminary** dates, not the final ones | `DTHFUFL` | no |
| `lotcat`, `lotcatn` | `04_treatment.R`, `lotcat_expr()` / `lotcatn_expr()` | The 17 treatment categories parsed from `LINENAME`, and their codes. A comma is taken as proof of a second drug; a slash binds inside one product name | every `LOT*CAT*` column | no |
| `csd_flag` | `04_treatment.R` | Whether the index line's own category is systemic | `CSD` | no |
| `treat_mhspc`, `treat_mcrpc` | `06_assemble.R` | Whether the patient has any line in that setting, used for the treated-status column | `COHORTU`, `COHORTUN` | no |
| `practicetype_agg` | `02_demographics.R` | Practice type collapsed to the spec's categories | `PRACTIC`, `PRACTICN` | no |
| `flatiron_all`, `olaparib_label`, `talapro2` | `00_setup.R` | The three frozen gene panels - 19 approved symbols, the 14-gene FDA olaparib label panel, the 12-gene TALAPRO-2 panel. Naming them in code pins the case definition | `HRR_INDEX`, `HRR_LABEL_INDEX`, `BRCA_INDEX` | no |
| `bpval` | `03_clinical.R`, blood pressure block | The castable blood-pressure reading before the whole-number test | `SBP`, `DBP` and their flags | no |
| `psabl` | `05_outcomes.R` | The baseline PSA the PSA50 response guard reads | the PSA response columns | no |
| `index_lot_ed` | `05_outcomes.R` | End date of the index line | `VIS120` - whether the last contact is at least 120 days after it | no |
| `next_trt_dt` | `05_outcomes.R` | The next-treatment date: for cohort 3 the earlier of the L2 mHSPC and L1 mCRPC starts, otherwise the next line in the same setting. **It is not constrained to follow the index date** | `TTNT`, `TTNTFL` | no |
| `ttntfl` | `05_outcomes.R` | The TTNT event flag. The spec strikes the variable out but its active definition still reads it, so it is derived and excluded from the 190 | `TTNT` | **no, by decision** |
| `first_progdt` | `05_outcomes.R` | First progression date after index | `PFSDT`, `PFS` | no |
| `last_contact_dt`, `lastclinicnotedate` | `05_outcomes.R` | The censoring anchors for the alive branches | `OS`, `PFS` | no |

## 7. Follow-up end date, death date, and cohort membership

This is the part of the build that changed most recently and the part most worth
reading before using an outcome. It implements a study-team ruling of
**2026-09-11**.

The ruling is four rules, labelled **RP1-RP4** here and cited by that label from
every program that implements or checks one:

| | Rule | Where it lives |
|---|---|---|
| **RP1** | The death date is imputed to the middle of the period - day 15 for a month-and-year value, 15 July for a year-only value - and **not adjusted again**. | `01_studypop.R`, `dateofdeath_init` -> `death_dt_preliminary` -> `dthdt` |
| **RP2** | `FUED` is the **death date where one exists**, and the last recorded activity date otherwise. Not the earlier of the two. | `01_studypop.R`, `fued = coalesce(dthdt, fu_enddt_preliminary)` |
| **RP3** | Both are derived **once per patient**, before any cohort is assigned and before any index date exists. | stage table `enh_pros_pano_pt_fu_death_tbl`, built ahead of the cohort loop; `03_clinical.R` joins it |
| **RP4** | A patient whose index date falls after their death date is excluded **from that cohort only**. | `index_lot_cohort()` in `01_studypop.R` |

**Why RP2 is not a minimum.** The first message of the ruling defined `FUED` as
the earlier of the death date and the last activity date. A clarification the
same day withdrew that, because a death recorded after the last activity would
then fall outside follow-up and an overall-survival analysis would drop the
event. A known death is the end of follow-up however stale the activity record.
The worked example was a death on 15 July 2025 against a last activity of
20 May 2025: under the minimum `FUED` was 20 May and the death was invisible;
under RP2 `FUED` is 15 July and the event is inside follow-up.

**Three behaviours the specification asked for are withdrawn by RP1**, labelled
**W1-W3**. Each has a different guard, and two of them cannot be seen from the
delivered columns at all:

| | Withdrawn behaviour | What would catch its return |
|---|---|---|
| **W1** | Pushing a year-only death to 31 December when the index fell after 15 July. It needed the index date, so RP3 alone makes it impossible. | Only a source re-derivation of the death date. No comparison of delivered columns can see it |
| **W2** | Promoting `DEATH_DT_preliminary` to month end when the death shared `FU_ENDDT_preliminary`'s month. | The same source re-derivation, for the same reason |
| **W3** | Promoting `DTHDT` to the last day of the month. | A comparison of `DTHDT` with `DEATH_DT_preliminary`, which the ruling makes equal |

W1 and W2 both acted on `DEATH_DT_preliminary` *before* `DTHDT` was set, so
their return leaves the two delivered columns equal and every gate green. C21 is
the only automated guard on either; treat a C21 mismatch as seriously as a
failed gate. **C21 and C22 ran clean on the 2026-09-13 build** - `qc/05` reports
MATCH on every check, with no row produced by one derivation and not the other
and no value disagreeing. W1 and W2 are therefore confirmed withdrawn from the
source, which no delivered-column comparison could have established; the
run writes `qc/qc05_rederivation_2026m06.csv`, which is NOT included here - it is a
runtime artefact, so the MATCH above is a result recorded here rather than
evidence shipped with the package. Retain that file with the release if the result is
to be auditable after the fact.

The specification's own cascade sat at 5B.ClinChars rows 88-93. Read the two
together - those rows are what the build did until 2026-09-11:

| Row | Column | What the ruling leaves |
|---|---|---|
| 88 | interim dates kept for the derivation | unchanged |
| 89 | `FU_ENDDT_preliminary` - latest of four activity dates | unchanged |
| 90 | `DATEOFDEATH` - two documented shapes, month-and-year and year-only | unchanged; any other length is NULL |
| 91 | `DEATH_DT_preliminary` | the imputation only; W1 and W2 withdrawn |
| 92 | `DTHDT` | equal to `DEATH_DT_preliminary`; W3 withdrawn |
| 93 | `FUED` | `COALESCE(DTHDT, FU_ENDDT_preliminary)`; the clamp withdrawn |

Row numbers are as the build cites them, and are still to be confirmed against
the workbook.

**Provenance of the ruling.** It arrived as two messages on the thread *"Followup
End date alignment across Data Products"*, 2026-09-11. What this repository holds
is a hand transcription with no sender identities, headers, export or hash, so it
cannot prove what was sent. That transcription was accepted as the record for
this cut by the data product owner on 2026-09-12, knowingly and in writing. It is
not authoritative, and the acceptance does not carry to the next cut.

### The ruling, transcribed

Two messages, the same day, on the thread *"Followup End date alignment across
Data Products"*. The second supersedes point 2 of the first. The wording is the
study team's, not ours, and this is a hand copy - see the provenance note above.

From the data product owner to the study team, 2026-09-11, summarising a call
held that morning.

> I'm summarizing the discussion points from our call earlier today. Please
> review and let me know if I missed anything or if my understanding is
> incorrect.
>
> 1. Per Flatiron's recommendation, death date will be imputed to the middle of
>    the month (or middle of the year, where only year-level granularity is
>    available), with no further adjustments applied.
>
> 2. Follow-up end date is defined as the earlier of the death date and the last
>    activity date. Below is an example.
>
>    | Raw DateofDeath | Death_dt  | last_act_dt | FUED      |
>    |-----------------|-----------|-------------|-----------|
>    | Jan-25          | 15-Jan-25 | 20-May-25   | 15-Jan-25 |
>    | 2025            | 15-Jul-25 | 20-May-25   | 20-May-25 |
>
> 3. Both death date and follow-up end date will be derived at the patient level
>    prior to cohort assignment and index date determination.
>
> 4. Patients whose index date falls after their death date will be excluded
>    from that specific cohort only.
>    Example: a patient may qualify for the Overall, L1, and L2 cohorts (index
>    dates preceding death date) while being excluded from the L3 cohort if the
>    L3 start date falls after their death date.
>    Edge case callout: a patient may be excluded from all cohorts entirely if
>    their index date for the Overall cohort (diagnosis date) falls after their
>    death date.
>
> Action Items:
> Pratyk to share worked examples comparing death date and follow-up end date
> assignment under the current rules vs. the previous rules, to illustrate the
> impact of the change.

**Clarification - supersedes point 2 above.**

Reply from the study statistician, later the same day.

> Thanks for the summary. For clarification, in the example you shared, in an OS
> analysis what would the time and event indicator be for this patient? If the
> patient died on July 15, 2025, but was derived to have a FUED of May 20, 2025,
> would the death event on July 15 2025 still be counted in the analysis? Or
> would it be excluded because it comes after the FUED? The event should not be
> excluded. Rather than specifying FUED as the minimum of the two, it would be
> more appropriate to have FUED be the death date when available, and the last
> activity in the absence of death.

**Effect on the worked table.** The clarification reverses its second row. Under
the minimum, a year-only death of `2025` against a last activity of 20-May-25
gave FUED = 20-May-25 and the July death fell outside follow-up. Under the
clarification it gives **FUED = 15-Jul-25**, and the death event is inside
follow-up where an OS analysis can count it. The first row is unchanged, because
there the death is already the earlier of the two.

### What the ruling does not say

Recorded here because each is a live limitation of a delivered value, not a
historical note.

- It removes the index floor on `FUED` as a consequence of RP3 - a patient-level
  value has no index date to be floored against - but says nothing about a
  patient whose last activity precedes their index date. **Their `FUED` precedes
  their index, and `FUDUR`, `OS` and `TTNT` can be negative.** The disposition is
  open.
- It does not say what `FUED` should be for a patient with neither a death date
  nor any recorded activity. `COALESCE` of two nulls is null, so **`FUED` and
  `FUDUR` are null** for them - newly possible, since the old floor guaranteed a
  value.
- RP4 says "falls after their death date". Implemented strictly: an index date
  **equal** to the death date is kept. The worked examples do not cover equality.
- An unparseable `DATEOFDEATH` yields a null death date, which cannot be
  compared with an index date, so RP4 silently cannot fire for that patient.
  A source gate counts them and must read zero before a build. Measured
  2026-09-12: **zero** - no such value exists in this cut.

### What this changed in the delivered values

| Column | Effect |
|---|---|
| `DTHDT` | Equal to `DEATH_DT_preliminary` on every row now. Month-granular deaths move up to 16 days **earlier** than before. |
| `FUED` | The death date wherever one exists, so it can now exceed `MAXINDEX`, precede the index date, or be null. |
| `FUDUR` | `DATEDIFF(FUED, INDEXDT) + 1`, so it can be zero or negative - only for a patient with no death date. |
| `DTH_BEFORE_FUED` | Unreachable, and delivered as a **constant 0**. With a death date `FUED` *is* `DTHDT`; without one `DTHDT` is null. It is kept because it is one of the 190 contracted columns, and it is no longer informative. |
| `OS`, `TTNT`, `PFS` | The null that `DTH_BEFORE_FUED` used to trigger is unreachable. The death branches cannot go negative, because `DTHDT >= INDEXDT` after the exclusion. The censored branches read `FUED` and can. |
| `CSF_FU` | Its window is bounded at `FUED`, so it moves **both ways**: wider for a patient who died after their last activity, narrower for one whose month-granular death used to be promoted to month end. Both are legitimate. |
| `DTHFUFL` | Reads the two *preliminary* dates, so its inputs moved while its value should not flip. |
| Cohort counts | Every cohort falls. Measured from source 2026-09-12: 196,549 / 133,299 / 78,635 / 50,327 / 28,865 / 16,007 / 8,582 - down 3,142 cohort memberships in total, every cohort between 0.35% and 0.73%. Accepted by the owner on 2026-09-12; the delivered table has still to reproduce them. |

## 8. What these values cannot tell you

- **`Unknown` in a lab or `BP` variable is not a data-quality signal.** It mixes
  a few percent with an unusable baseline record and about 39% who were simply
  tested later. `Present` is the only positive statement.
- **`PRIOR_NHA_ADT` is broader than its name.** Any NHA plus a second drug sets
  it, whether or not that drug is an ADT. An NHA with chemotherapy counts.
- **A cohort's index date can precede the milestone that admitted the patient.**
  10,148 patients, 6.2% of cohort 3 and 10.5% of cohort 4. Their baseline
  windows, `OS`, `TTNT` and `PFS` all anchor on that earlier date.
- **17.01% of cohort 1 index dates are not day-level.** A year-level milestone
  resolves to 1 January, so every index window can be up to a year early for
  those patients.
- **`PFS` can exceed `OS`.** A progression can be recorded after the death date;
  the specification says to treat it as a data limitation and take no action
 .
- **Height and weight are admitted at any non-null value.** A negative weight
  therefore delivers a negative `BMI`, banded `Underweight`. Every step follows
  the specification; the result is not a measurement.
- **The delivered table carries no provenance.** It records nothing about which
  build produced it, and it is written under a stable name with `replace = TRUE`.
  The decision to change that was taken on 2026-09-12 and deferred to the next
  cut, so for this cut the build identity recorded by hand is the only thing
  tying a result to a run.
