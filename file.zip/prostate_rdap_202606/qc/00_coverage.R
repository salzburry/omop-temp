# =============================================================================
# QC 00. DECISION COVERAGE
# =============================================================================
#   Rscript qc/00_coverage.R      (no database needed)
#
# Every deviation that changes a delivered value must be named by at least one
# check, so you can go from the decision to the query that proves it held.
#
# WHY. A decision can be checked by a query that never names it, which is
# coverage nobody can find - from outside it looks identical to no check at
# all. Requiring the id in the check text keeps the two distinguishable.
#
# TO COVER A ROW: put its id, such as Q47, in a comment or a rule label in any
# file under qc/ or validation/. Put it in the rule text where you can, so it
# shows up in the QC output and not only in the source.
#
# EXEMPTIONS below are decisions that are not about delivered data, each with a
# reason. An exemption without a reason is an untested decision with extra
# steps, so adding one should be harder than adding a check.
#
# The decisions are read from the register index table in docs/VARIABLES.md.
# =============================================================================

source("validation/read_deviations.R")

# Files that may carry a check. validation/ counts: a V-gate is a check.
CORPUS <- c(list.files("qc", pattern = "\\.(sql|R)$", full.names = TRUE),
            list.files("validation", pattern = "\\.(sql|R)$", full.names = TRUE))
CORPUS <- CORPUS[!grepl("00_coverage\\.R$", CORPUS)]   # not itself
# read_deviations.R names no decision; counting it would cover everything.
CORPUS <- CORPUS[!grepl("read_deviations\\.R$", CORPUS)]

# -----------------------------------------------------------------------------
# Exempt rows - not checkable by querying the delivered data
# -----------------------------------------------------------------------------
EXEMPT <- c(
  Q02 = "TTNTFL is an internal input to TTNT and is deliberately NOT delivered. Its absence is enforced by the 190-column allowlist, not by a data check.",
  Q08 = "Variable RENAME (PRIOR_DOCETAXEL). Enforced structurally by validation/00_column_contract.csv and validation/04_column_contract_check.R - a name that reverted would fail the contract, not a query.",
  Q14 = "Output table naming and location. A build-identity decision; the run manifest records it, no delivered value depends on it.",
  Q15 = "t_allprostate_pats is OUT OF SCOPE for this deliverable. There is nothing in the ADS to check.",
  Q17 = "Variable RENAME (LOT4CATN_MCRPC). Structural, as Q08.",
  Q21 = "Interim date columns RETAINED. Their presence is the decision, and the column contract enforces presence.",
  Q22 = "BIRTHYEAR retained. Presence is the decision; the column contract enforces it.",
  Q27 = "The build writes the deliverable directly with no staging copy. A process decision about WHEN validation runs, not a property of any row.",
  Q43 = "Stable table names with replace=TRUE and no unique build id. A build-identity decision; the run manifest is the record.",
  Q46 = "Variable RENAME (PRIOR_ABIRATERONE). Structural, as Q08.",
  Q54 = "Which SOURCE TABLE the orals feed reads. The spec named a colorectal table; the build reads the prostate one. Verified by validation/00_input_contract.csv and preflight A1/A2, not by a value.",
  Q70 = "Output TYPES. Checked by qc/07_type_contract.R, which cannot cite a register id in delivered output because it reports a schema, not rows. Listed here so the exemption is deliberate."
)

# -----------------------------------------------------------------------------
reg <- read_deviations()

bad_exempt <- setdiff(names(EXEMPT), reg$id)
if (length(bad_exempt)) {
  stop("EXEMPT names a register id that does not exist: ",
       paste(bad_exempt, collapse = ", "), call. = FALSE)
}

text <- setNames(lapply(CORPUS, function(f) paste(readLines(f, warn = FALSE), collapse = "\n")),
                 CORPUS)

cited_by <- function(id) {
  pat <- paste0("\\b", id, "\\b")
  basename(names(Filter(function(t) grepl(pat, t), text)))
}

reg$covered_by <- vapply(reg$id, function(i) paste(cited_by(i), collapse = ", "), character(1))
reg$n_checks   <- vapply(reg$id, function(i) length(cited_by(i)), integer(1))
reg$exempt     <- reg$id %in% names(EXEMPT)

reg$needs <- !reg$exempt & reg$affects %in% c("values", "columns")
gaps <- reg[reg$needs & reg$n_checks == 0L, , drop = FALSE]

cat("decision coverage\n")
cat("  register rows      ", nrow(reg), "\n", sep = "")
cat("  exempt (with reason)", sum(reg$exempt), "\n", sep = " ")
cat("  require a check    ", sum(reg$needs), "\n", sep = "")
cat("  covered            ", sum(reg$needs & reg$n_checks > 0L), "\n", sep = "")
cat("  UNCOVERED          ", nrow(gaps), "\n", sep = "")

# An exemption that is also checked is fine; an exemption that nothing checks
# rests entirely on its stated reason, so report those.
unchecked_exempt <- reg[reg$exempt & reg$n_checks == 0L, "id"]
if (length(unchecked_exempt)) {
  cat("\n  exempt and relying entirely on the stated reason: ",
      paste(unchecked_exempt, collapse = ", "), "\n", sep = "")
}

if (nrow(gaps)) {
  cat("\nFAIL - these decisions change delivered output and NOTHING names them:\n\n")
  for (i in seq_len(nrow(gaps))) {
    cat("  ", gaps$id[i], "  ", substr(gaps$variable[i], 1, 60), "\n", sep = "")
  }
  cat("\nEither add a check that names the row, or add it to EXEMPT in\n")
  cat("qc/00_coverage.R WITH A REASON. An exemption without one is an\n")
  cat("untested decision with extra steps.\n")
  quit(status = 1L)
}

# Being named by a check is not the same as being approved. Shipped code whose
# decision nobody signed is a separate failure, so it is checked separately.
#
# A NON-EMPTY approver cell is not a name. This tested `nzchar()` alone until
# 2026-09-13, so "UNASSIGNED - needs a named SME" counted as approved and the
# program printed that every decision was approved while one had no owner at
# all. A gate that certifies what it does not test is worse than no gate.
PLACEHOLDER <- "^(unassigned|tbd|tbc|pending|none|not approved|n/?a|[-?.]+)\\b"
is_person <- function(x) nzchar(trimws(x)) & !grepl(PLACEHOLDER, trimws(x),
                                                    ignore.case = TRUE)

out_affecting <- reg$affects %in% c("values", "columns")

unapproved <- reg[out_affecting & !is_person(reg$approved_by), , drop = FALSE]
if (nrow(unapproved)) {
  cat("\nFAIL - implemented but NOT APPROVED by a named person:\n\n")
  for (i in seq_len(nrow(unapproved)))
    cat("  ", unapproved$id[i], "  ",
        substr(unapproved$variable[i], 1, 44), "   approver: ",
        if (nzchar(trimws(unapproved$approved_by[i])))
          substr(unapproved$approved_by[i], 1, 30) else "(empty)", "\n", sep = "")
  cat("\nThe code already changes these values. Get a name against them.\n")
  quit(status = 1L)
}

# An OPEN decision is implemented and unruled. The code ships a value for it
# either way, so the register's own Status is a release condition, not a note.
open_rows <- reg[out_affecting & grepl("^OPEN\\b", trimws(reg$status)), , drop = FALSE]
if (nrow(open_rows)) {
  cat("\nFAIL - output-affecting decisions still OPEN in the register:\n\n")
  for (i in seq_len(nrow(open_rows)))
    cat("  ", open_rows$id[i], "  ", substr(open_rows$variable[i], 1, 60), "\n", sep = "")
  cat("\nThe build delivers a value for each of these and nobody has ruled on\n")
  cat("what that value should be. Rule, or record an interim decision with a\n")
  cat("name and a date against it.\n")
  quit(status = 1L)
}

cat("\nPASS - every output-affecting decision is named by a check, approved by a\n")
cat("named person, and ruled.\n")

out <- file.path("qc", "qc00_coverage.csv")
utils::write.csv(reg[, c("id", "variable", "affects", "exempt",
                         "n_checks", "covered_by")],
                 out, row.names = FALSE)
cat("wrote ", out, " - the decision-to-check map; retain it in the QC pack\n", sep = "")
