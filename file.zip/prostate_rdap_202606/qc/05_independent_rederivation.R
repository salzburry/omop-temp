# =============================================================================
# QC 05. INDEPENDENT RE-DERIVATION
# =============================================================================
#   Rscript qc/05_independent_rederivation.R      (run from the repo root)
#
# Rebuilds chosen variables from source in hand-written SQL, then compares them
# to the delivered table row by row.
#
# WHY. Every other check tests the output against itself, or against a rule
# someone wrote down. None of them can spot a build that computes the wrong
# thing consistently - a filter that drops a third of the source, a join on the
# wrong key, a window off by one day. Those give a table where every value is
# legal. The only defence is a second derivation that shares no code with the
# first. So this file uses no dplyr, no dbplyr, and none of the build helpers.
#
# Where the two agree, the number is confirmed twice. Where they differ, one of
# them is wrong. That is the finding, not a bug in this script.
#
# THIRTY-NINE CHECKS. C01 to C22, with C12 and C14 each expanding to ten
# analytes, and no C10.
#
# NOT COVERED, on purpose: OS, PFS, TTNT. PFS rests on the progression-evidence
# resolution and its collision rules, TTNT on the next-line search. A second
# hand-written version of either would disagree for reasons that are bugs in
# the copy, not evidence about the build. Rules R18-R24b in qc/03 check those
# against the delivered columns instead. What C21 and C22 add for them is the
# anchor underneath: OS measures from DTHDT or FUED, so an OS resting on a
# death date that never matched source is wrong whatever R18 says about the
# arithmetic.
#
# DTHDT AND FUED WERE ON THAT LIST, exempted because the death-date imputation
# cascade was judged too intricate to reproduce. The ruling (register Q82)
# voids that reason rather than answering it: under RP1 with W1-W3 withdrawn,
# DTHDT is a two-branch TRY_CAST over DATEOFDEATH, and under RP2 FUED is
# COALESCE(DTHDT, FU_ENDDT_preliminary). This file already writes that TRY_CAST for C03
# and for the idx CTE below, so the second copy is a few lines with no cascade
# left in it to get wrong. C21 and C22 re-derive them, and they are the only
# source-anchored proof that the build implements what the ruling specifies -
# every other check of the ruling reads the delivered columns and can therefore
# only confirm that those agree with each other.
#
# READING THE OUTPUT
#   n_ads_only     the build produced a row, this did not
#   n_indep_only   this produced a row, the build did not
#   n_value_mismatch  both produced it, values differ
#   MATCH          the two agree
#
# Reads only. Writes nothing to the database.
# RP1-RP4 and W1-W3 are the 2026-09-11 ruling's four rules and the three
# behaviours they withdraw, defined in docs/VARIABLES.md section 3.
# =============================================================================

if (!exists("con")) {
  message("no open connection - sourcing code/modules/00_setup.R")
  source("code/modules/00_setup.R")
}

stopifnot(exists("con"), exists("personal_schema"), exists("output_table"),
          exists("dbname"), exists("refresh"))

ADS <- paste0(personal_schema, ".", output_table)
SRC <- dbname
SFX <- paste0("_", refresh)
s   <- function(tbl) paste0(SRC, ".", tbl, SFX)

# Index window, restated here rather than read from the build's globals. If the
# build's index_start/index_end were wrong, importing them would import the bug
# into the audit as well.
IDX_LO <- "DATE'2011-01-01'"
IDX_HI <- "DATE'2026-04-30'"

# -----------------------------------------------------------------------------
# The seven cohorts, re-derived from 4.StudyPop section B
# -----------------------------------------------------------------------------
# This is itself the first re-derivation, and the most important one: if the
# cohort definition is wrong, every variable below is being compared on the
# wrong population.
#
# Membership now has two parts: eligibility (the milestone or line start inside
# the index window) and the per-cohort death exclusion of the 2026-09-11 ruling
# (register Q82). Both must be here. Roughly forty of the checks below join to
# `idx`, so an independent side that kept the patients the build correctly
# excluded would report every one of them as n_indep_only - a large spurious
# difference on C01 and on everything keyed on it, drowning any real finding.
idx_cte <- sprintf("
ms AS (
    SELECT patientid,
           GREATEST(metastaticdiagnosisdate, hspcdate) AS mhspcdd,
           GREATEST(metastaticdiagnosisdate, crpcdate) AS mcrpcdd
    FROM %s
),
lot AS (
    SELECT patientid, linesetting, linenumber, linename, startdate, enddate,
           ROW_NUMBER() OVER (PARTITION BY patientid, linesetting
                              ORDER BY startdate) AS new_lot_n
    FROM %s
    WHERE linesetting IN ('mHSPC', 'mCRPC')
),
dth AS (
    SELECT patientid,
           MAX(CASE WHEN LENGTH(dateofdeath) = 7 THEN TRY_CAST(CONCAT(dateofdeath, '-15') AS DATE)
                    WHEN LENGTH(dateofdeath) = 4 THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
                    ELSE NULL END) AS dthdt
    FROM %s
    GROUP BY patientid
),
idx AS (
    SELECT m.patientid, 1 AS cohortn, m.mhspcdd AS indexdt
    FROM ms m LEFT JOIN dth d ON d.patientid = m.patientid
    WHERE m.mhspcdd BETWEEN %s AND %s
      AND (d.dthdt IS NULL OR m.mhspcdd <= d.dthdt)
    UNION ALL
    SELECT m.patientid, 2, m.mcrpcdd
    FROM ms m LEFT JOIN dth d ON d.patientid = m.patientid
    WHERE m.mcrpcdd BETWEEN %s AND %s
      AND (d.dthdt IS NULL OR m.mcrpcdd <= d.dthdt)
    UNION ALL
    SELECT l.patientid,
           CASE WHEN l.linesetting = 'mHSPC' THEN 3
                WHEN l.new_lot_n = 1         THEN 4
                WHEN l.new_lot_n = 2         THEN 5
                WHEN l.new_lot_n = 3         THEN 6
                ELSE                              7 END,
           l.startdate
    FROM lot l
    JOIN ms  m ON m.patientid = l.patientid
    LEFT JOIN dth d ON d.patientid = l.patientid
    WHERE l.startdate BETWEEN %s AND %s
      AND ((l.linesetting = 'mHSPC' AND l.new_lot_n = 1
            AND m.mhspcdd BETWEEN %s AND %s)
        OR (l.linesetting = 'mCRPC' AND l.new_lot_n BETWEEN 1 AND 4
            AND m.mcrpcdd BETWEEN %s AND %s))
      AND (d.dthdt IS NULL OR l.startdate <= d.dthdt)
)",
  s("t_enh_prostate"), s("t_enh_prostate_lot"), s("t_mortality_v2"),
  IDX_LO, IDX_HI, IDX_LO, IDX_HI, IDX_LO, IDX_HI,
  IDX_LO, IDX_HI, IDX_LO, IDX_HI)
# `dth` is the whole of the 2026-09-11 imputation and nothing more: the middle
# of the month, the middle of the year for a year-only value, no further
# adjustment. Read from the mortality source, never from the ADS - the
# exclusion exists to check the build, so it cannot borrow the build's own
# answer for the date it filters on.
#
# TRY_CAST, never CAST. '2020-13' is seven characters long and is not a date;
# under ANSI mode a plain CAST aborts the whole query instead of reading NULL.
# Any other length falls to NULL by design (register Q66), and a NULL death
# date excludes nobody.
#
# MAX ... GROUP BY, not SELECT DISTINCT: this must be one row per patient. A
# patient carrying two mortality rows would otherwise multiply their idx rows
# through the LEFT JOIN and inflate n_indep_only on every check keyed on idx.
# C21 compares the collapsed value against the delivered DTHDT, so a patient
# whose mortality rows genuinely disagree surfaces there rather than as noise
# spread over forty checks.
#
# The test is STRICT - `indexdt <= dthdt` keeps an index ON the death date,
# because the ruling excludes an index falling AFTER the death, not on it. It is
# applied per cohort against that cohort's own index date, which is why it sits
# in each UNION ALL branch and not in a filter over the finished union: a
# patient can hold their place in Overall and L1 and be dropped from L3 when the
# third line starts after the death date. Comparison is against DTHDT, not
# DEATH_DT_preliminary; under Q82 the two are equal by construction anyway.

# -----------------------------------------------------------------------------
# Comparison harness
# -----------------------------------------------------------------------------
# Every check supplies a query producing (patid, cohortn, indexdt, qc_value).
# The harness full-outer-joins it to the ADS on the grain and classifies each
# row. `ads_expr` is the ADS column, or an expression over ADS columns, that
# the derivation is supposed to reproduce.
#
# Values are compared as strings after casting, so a DOUBLE/DECIMAL difference
# in storage type does not read as a mismatch.
#
# `ads_where` restricts the ADS side to the population the derivation covers.
# Without it, a check that legitimately produces no row for some cohorts reads
# every one of those rows as "ads only", burying any real difference.
#
# `numeric = TRUE` compares with a tolerance instead of as strings. Some ADS
# columns land as DOUBLE against an INT on this side (AGE, the line counts),
# and a string comparison then reads "65.0" against "65" as a mismatch on
# every row. The signature of this artefact, as opposed to a real
# disagreement: n_ads_only = 0 and n_indep_only = 0 with every shared value
# differing.
compare <- function(label, qc_sql, ads_expr, note = "", ads_where = NULL,
                    numeric = FALSE) {
  where <- if (is.null(ads_where)) "" else paste(" WHERE", ads_where)
  differs <- if (numeric)
    "ABS(CAST(a.ads_value AS DOUBLE) - CAST(qc.qc_value AS DOUBLE)) > 1e-9
              OR (a.ads_value IS NULL) <> (qc.qc_value IS NULL)"
  else
    "NOT (CAST(a.ads_value AS STRING) IS NOT DISTINCT FROM
                       CAST(qc.qc_value  AS STRING))"
  q <- sprintf("
WITH %s,
qc AS (%s),
a  AS (SELECT patid, cohortn, indexdt, %s AS ads_value FROM %s%s)
SELECT
    '%s'                                                        AS check_name,
    COUNT(*)                                                    AS n_union,
    SUM(CASE WHEN a.patid IS NOT NULL AND qc.patid IS NOT NULL THEN 1 ELSE 0 END) AS n_both,
    SUM(CASE WHEN qc.patid IS NULL  THEN 1 ELSE 0 END)          AS n_ads_only,
    SUM(CASE WHEN a.patid  IS NULL  THEN 1 ELSE 0 END)          AS n_indep_only,
    SUM(CASE WHEN a.patid IS NOT NULL AND qc.patid IS NOT NULL
              AND (%s)
             THEN 1 ELSE 0 END)                                 AS n_value_mismatch
FROM       a
FULL OUTER JOIN qc
  ON  a.patid = qc.patid AND a.cohortn = qc.cohortn AND a.indexdt = qc.indexdt",
    idx_cte, qc_sql, ads_expr, ADS, where, label, differs)

  out <- tryCatch(DBI::dbGetQuery(con, q), error = function(e) {
    message("  ERROR in ", label, ": ", conditionMessage(e)); NULL
  })
  if (is.null(out)) return(NULL)
  out$note <- note
  out$status <- with(out,
    ifelse(n_ads_only == 0 & n_indep_only == 0 & n_value_mismatch == 0,
           "MATCH", "DIFFER"))
  out
}

# Drill-in for anything that reports DIFFER: prints up to `n` disagreeing
# rows with both values side by side.
show_mismatches <- function(label, qc_sql, ads_expr, n = 20, ads_where = NULL) {
  where <- if (is.null(ads_where)) "" else paste(" WHERE", ads_where)
  q <- sprintf("
WITH %s,
qc AS (%s),
a  AS (SELECT patid, cohortn, indexdt, %s AS ads_value FROM %s%s)
SELECT COALESCE(a.patid, qc.patid)     AS patid,
       COALESCE(a.cohortn, qc.cohortn) AS cohortn,
       COALESCE(a.indexdt, qc.indexdt) AS indexdt,
       CAST(a.ads_value AS STRING)     AS ads_value,
       CAST(qc.qc_value AS STRING)     AS qc_value,
       CASE WHEN qc.patid IS NULL THEN 'ads only'
            WHEN a.patid  IS NULL THEN 'indep only'
            ELSE 'value differs' END   AS kind
FROM       a
FULL OUTER JOIN qc
  ON  a.patid = qc.patid AND a.cohortn = qc.cohortn AND a.indexdt = qc.indexdt
WHERE qc.patid IS NULL OR a.patid IS NULL
   OR NOT (CAST(a.ads_value AS STRING) IS NOT DISTINCT FROM
           CAST(qc.qc_value AS STRING))
LIMIT %d", idx_cte, qc_sql, ads_expr, ADS, where, n)
  DBI::dbGetQuery(con, q)
}

# -----------------------------------------------------------------------------
# The checks
# -----------------------------------------------------------------------------
CHECKS <- list(

  list(label = "C01 cohort grain and membership",
       note  = "the population itself - run this one first",
       qc    = "SELECT patientid AS patid, cohortn, indexdt, 1 AS qc_value FROM idx",
       ads   = "1"),

  list(label = "C02 AGE",
       note  = "index year minus birth year; catches join fan-out on demographics",
       numeric = TRUE,
       qc    = sprintf("
    SELECT i.patientid AS patid, i.cohortn, i.indexdt,
           YEAR(i.indexdt) - TRY_CAST(d.birthyear AS INT) AS qc_value
    FROM idx i JOIN %s d ON d.patientid = i.patientid", s("t_demographics")),
       ads   = "age"),

  # Q66 is part of the definition, not a detail: DTHFL is 1 when DTHDT is not
  # null, and DTHDT only exists for a death date of length 4 or 7 that casts.
  # Accepting any non-null DATEOFDEATH here would read every patient Q66
  # censors as an independent-vs-build mismatch, failing the check on exactly
  # the behaviour that was ruled.
  list(label = "C03 DTHFL (Q66 - only the two supported date shapes)",
       note  = "a populated death date of any other length is NOT a death here",
       qc    = sprintf("
    SELECT i.patientid AS patid, i.cohortn, i.indexdt,
           CASE WHEN m.patientid IS NOT NULL THEN 1 ELSE 0 END AS qc_value
    FROM idx i
    LEFT JOIN (SELECT DISTINCT patientid FROM %s
               WHERE dateofdeath IS NOT NULL
                 AND ((LENGTH(dateofdeath) = 7
                       AND TRY_CAST(CONCAT(dateofdeath, '-15') AS DATE) IS NOT NULL)
                   OR (LENGTH(dateofdeath) = 4
                       AND TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE) IS NOT NULL))) m
      ON m.patientid = i.patientid", s("t_mortality_v2")),
       ads   = "dthfl"),

  list(label = "C04 LOTN (mCRPC line count)",
       note  = "counts ALL mCRPC lines, not only the four the ADS displays",
       numeric = TRUE,
       qc    = "
    SELECT i.patientid AS patid, i.cohortn, i.indexdt,
           COALESCE(c.n_lines, 0) AS qc_value
    FROM idx i
    LEFT JOIN (SELECT patientid, COUNT(*) AS n_lines
               FROM lot WHERE linesetting = 'mCRPC'
               GROUP BY patientid) c
      ON c.patientid = i.patientid",
       ads   = "lotn"),

  list(label = "C05 LOTN_MHSPC (mHSPC line count, register Q06)",
       note  = "the pair added under Q06; nothing in the spec defined it",
       numeric = TRUE,
       qc    = "
    SELECT i.patientid AS patid, i.cohortn, i.indexdt,
           COALESCE(c.n_lines, 0) AS qc_value
    FROM idx i
    LEFT JOIN (SELECT patientid, COUNT(*) AS n_lines
               FROM lot WHERE linesetting = 'mHSPC'
               GROUP BY patientid) c
      ON c.patientid = i.patientid",
       ads   = "lotn_mhspc"),

  list(label = "C06 STAGE",
       note  = "groupstage prefix mapping",
       qc    = sprintf("
    SELECT i.patientid AS patid, i.cohortn, i.indexdt,
           CASE WHEN p.groupstage LIKE 'IV%%'  THEN 'IV'
                WHEN p.groupstage LIKE 'III%%' THEN 'III'
                WHEN p.groupstage LIKE 'II%%'  THEN 'II'
                WHEN p.groupstage LIKE 'I%%'   THEN 'I'
                WHEN p.groupstage LIKE '0%%'   THEN '0'
                ELSE 'Unknown/not documented' END AS qc_value
    FROM idx i JOIN %s p ON p.patientid = i.patientid", s("t_enh_prostate")),
       ads   = "stage"),

  list(label = "C07 GLEASON (Q61 three categories; Q75 source spellings)",
       note  = "confirms the three-category mapping the owner ruled on 2026-08-08",
       qc    = sprintf("
    SELECT i.patientid AS patid, i.cohortn, i.indexdt,
           CASE WHEN p.gleasonscore IN ('Less than or equal to 6', '3 + 4 = 7',
                                        '4 + 3 = 7', '7 (not documented)',
                                        '7 (when breakdown not available)') THEN '<8'
                WHEN p.gleasonscore IN ('8', '9', '10')                     THEN '>=8'
                ELSE 'Unknown/Missing' END AS qc_value
    FROM idx i JOIN %s p ON p.patientid = i.patientid", s("t_enh_prostate")),
       ads   = "gleason"),

  list(label = "C08 PRIOR_DOCETAXEL",
       note  = "any docetaxel-containing regimen with episodedate < index",
       qc    = sprintf("
    SELECT i.patientid AS patid, i.cohortn, i.indexdt,
           CASE WHEN EXISTS (
                  SELECT 1 FROM %s d
                  WHERE d.patientid = i.patientid
                    AND d.episodedate < i.indexdt
                    AND LOWER(d.linename) LIKE '%%docetaxel%%')
                THEN 'Yes' ELSE 'No' END AS qc_value
    FROM idx i", s("t_enh_prostate_drg_epsode")),
       ads   = "prior_docetaxel"),

  list(label = "C09 PSA_INDEX (PSABL, register Q62)",
       note  = "earliest ScoreSerial in [INDEX-14, INDEX], max on that date; anchored on INDEXDT per Q62",
       qc    = sprintf("
    SELECT w.patid, w.cohortn, w.indexdt, MAX(w.scoreserial) AS qc_value
    FROM (
      SELECT i.patientid AS patid, i.cohortn, i.indexdt, p.resultdate, p.scoreserial,
             MIN(p.resultdate) OVER (PARTITION BY i.patientid, i.cohortn, i.indexdt)
               AS first_dt
      FROM idx i
      JOIN %s p ON p.patientid = i.patientid
      WHERE p.scoreserial IS NOT NULL
        AND p.resultdate BETWEEN DATE_SUB(i.indexdt, 14) AND i.indexdt
    ) w
    WHERE w.resultdate = w.first_dt
    GROUP BY w.patid, w.cohortn, w.indexdt", s("t_enh_prostate_psa")),
       # The derivation only emits a row where a qualifying PSA exists, so the
       # ADS side is restricted the same way; otherwise every row with no
       # baseline PSA reads "ads only". A genuine disagreement still surfaces:
       # a PSA the build found and this did not is ads_only, and the reverse
       # is indep_only.
       ads_where = "psa_index IS NOT NULL",
       numeric   = TRUE,
       ads       = "psa_index"),

  # Production reads the source value with TRY_CAST, takes the MAX over the
  # winning date, then calls anything outside 0-4 'Unknown/Missing' (Q71). The
  # ADS side below excludes those, so this side has to as well - hence TRY_CAST
  # and the HAVING. A raw MAX(ecogvalue) would read a malformed or out-of-range
  # winning value as an independent-only difference on a correct build.
  list(label = "C11 baseline ECOG, treated cohorts (Q56 window, Q71 clamp)",
       note  = "line match, then [INDEX-30, INDEX+7], closest to index, then max of 0-4",
       qc    = sprintf("
    SELECT m.patid, m.cohortn, m.indexdt,
           CAST(MAX(m.ecogvalue) AS STRING) AS qc_value
    FROM (
      -- Production breaks an equidistant tie on the earlier date, then takes
      -- the highest value on that date. Ranking on gap alone would let a
      -- later date at the same distance contribute its value too.
      SELECT i.patientid AS patid, i.cohortn, i.indexdt,
             TRY_CAST(e.ecogvalue AS INT) AS ecogvalue,
             ABS(DATEDIFF(e.ecogdate, i.indexdt)) AS gap,
             MIN(ABS(DATEDIFF(e.ecogdate, i.indexdt)))
               OVER (PARTITION BY i.patientid, i.cohortn, i.indexdt) AS min_gap,
             e.ecogdate,
             MIN(e.ecogdate) OVER (
               PARTITION BY i.patientid, i.cohortn, i.indexdt,
                            ABS(DATEDIFF(e.ecogdate, i.indexdt))) AS win_dt
      FROM idx i
      JOIN lot l
        ON l.patientid = i.patientid AND l.startdate = i.indexdt
       AND ((i.cohortn = 3 AND l.linesetting = 'mHSPC' AND l.new_lot_n = 1)
         OR (i.cohortn = 4 AND l.linesetting = 'mCRPC' AND l.new_lot_n = 1)
         OR (i.cohortn = 5 AND l.linesetting = 'mCRPC' AND l.new_lot_n = 2)
         OR (i.cohortn = 6 AND l.linesetting = 'mCRPC' AND l.new_lot_n = 3)
         OR (i.cohortn = 7 AND l.linesetting = 'mCRPC' AND l.new_lot_n = 4))
      JOIN %s e
        ON e.patientid = l.patientid AND e.linenumber = l.linenumber
       AND e.linestartdate = l.startdate
      WHERE i.cohortn BETWEEN 3 AND 7
        AND e.ecogdate BETWEEN DATE_SUB(i.indexdt, 30) AND DATE_ADD(i.indexdt, 7)
    ) m
    WHERE m.gap = m.min_gap AND m.ecogdate = m.win_dt
    GROUP BY m.patid, m.cohortn, m.indexdt
    HAVING MAX(m.ecogvalue) BETWEEN 0 AND 4", s("t_enh_prostate_bsln_ecog")),
       # Cohorts 1-2 have no baseline-ECOG row in this derivation, and neither
       # does a treated-cohort patient whose ECOG is Unknown/Missing. A CASE
       # returning NULL on the QC side would null the value but leave the row,
       # which still reads "ads only" - the restriction has to be on the ADS
       # side.
       ads_where = "cohortn BETWEEN 3 AND 7 AND ecog <> 'Unknown/Missing'",
       ads       = "ecog")
)

# -----------------------------------------------------------------------------
# C12a-C12j - the ten lab presence flags (register Q58)
# -----------------------------------------------------------------------------
# These are the only delivered-side checks of the Q58 ruling. S1 in
# validation/05_sizing_queries.sql cannot serve that purpose: it reads only
# the source tables and rebuilds the cohort rows itself, never touching the
# ADS, so it returns the same numbers whether the Q58 change shipped
# correctly, shipped backwards, or did not ship at all. It predicts what
# should flip; it cannot confirm what did.
#
# Each check re-derives the three-way flag from source under the Q58
# semantics and compares it to the delivered column patient by patient, so a
# broken implementation shows up as n_value_mismatch.
#
# Independence: the analyte names, units and components below are copied from
# the build's lab_spec, deliberately. They are spec facts carrying their own
# register rulings (Q07's LABBIL unit, Q25's albumin g/L, Q55's platelets),
# not derivation logic. What is re-derived independently is the part that can
# be wrong: whether a record makes the analyte Present, Unknown or Missing,
# and against which date bound.
LAB_SPEC <- list(
  list(flag = "labneu", test = "neutrophils",                unit = "10*9/L", comp = NA),
  list(flag = "labpla", test = "platelets",                  unit = "10*9/L", comp = NA),
  list(flag = "labhem", test = "hemoglobin",                 unit = "g/dL",   comp = NA),
  list(flag = "labcre", test = "creatinine",                 unit = "mg/dL",  comp = "Creatinine, serum"),
  list(flag = "labbil", test = "bilirubin",                  unit = "mg/dL",  comp = NA),
  list(flag = "labast", test = "aspartate aminotransferase", unit = "U/L",    comp = NA),
  list(flag = "labalt", test = "alanine aminotransferase",   unit = "U/L",    comp = NA),
  list(flag = "labalp", test = "alkaline phosphatase",       unit = "U/L",    comp = NA),
  list(flag = "labalb", test = "albumin",                    unit = "g/L",    comp = "Albumin, serum"),
  list(flag = "lablym", test = "lymphocytes",                unit = "10*9/L", comp = NA)
)

for (i in seq_along(LAB_SPEC)) {
  L <- LAB_SPEC[[i]]
  # The component filter, where the spec states one, applies to both the
  # Present test and the existence test - the build scopes it that way and so
  # must any check of the build.
  comp_pred <- if (is.na(L$comp)) "" else sprintf(" AND l.labcomponent = '%s'", L$comp)
  CHECKS[[length(CHECKS) + 1L]] <- list(
    label = sprintf("C12%s %s flag (Q58 - Missing test NOT time-bounded)",
                    letters[i], toupper(L$flag)),
    note  = "Present needs a qualifying record AT OR BEFORE index; Unknown needs a record at ANY date",
    qc    = sprintf("
    SELECT i.patientid AS patid, i.cohortn, i.indexdt,
           CASE WHEN EXISTS (
                  SELECT 1 FROM %1$s l
                  WHERE l.patientid = i.patientid
                    AND LOWER(l.testbasename) = '%2$s'%3$s
                    AND l.testdate IS NOT NULL
                    AND l.testresultcleaned > 0
                    AND TRIM(l.testunitscleaned) = '%4$s'
                    AND GREATEST(l.testdate, l.resultdate) <= i.indexdt)
                THEN 'Present'
                -- Q58: no date bound here. A record at any date, including
                -- years after index, makes the analyte Unknown rather than
                -- Missing.
                WHEN EXISTS (
                  SELECT 1 FROM %1$s l
                  WHERE l.patientid = i.patientid
                    AND LOWER(l.testbasename) = '%2$s'%3$s)
                THEN 'Unknown'
                ELSE 'Missing' END AS qc_value
    FROM idx i", s("t_lab"), L$test, comp_pred, L$unit),
    ads   = L$flag)
}

# -----------------------------------------------------------------------------
# C13 - the BP presence flag (register Q58, the other half)
# -----------------------------------------------------------------------------
# Q58 changes BP as well as the labs - 144,079 rows predicted to move from
# Missing to Unknown - and the lab loop above does not cover it, because BP
# has a different source table and a two-arm same-date rule.
#
# BP is Present only when a systolic and a diastolic reading share a TESTDATE
# and both are positive. TESTRESULT, not TESTRESULTCLEANED - the spec is
# explicit that the cleaned column is mostly unpopulated for vitals.
CHECKS[[length(CHECKS) + 1L]] <- list(
  label = "C13 BP flag (Q58 - the BP half of the ruling)",
  note  = "Present needs systolic AND diastolic on one date at or before index, both positive",
  qc    = sprintf("
    SELECT i.patientid AS patid, i.cohortn, i.indexdt,
           CASE WHEN EXISTS (
                  SELECT 1
                  FROM %1$s v
                  WHERE v.patientid = i.patientid
                    AND LOWER(v.test) IN ('systolic blood pressure',
                                          'diastolic blood pressure')
                    AND v.testdate <= i.indexdt
                  GROUP BY v.testdate
                  -- Positive integer, matching Q67 - a fractional reading
                  -- does not qualify. TRY_CAST, not CAST, so malformed text
                  -- gives NULL instead of aborting the check.
                  HAVING MAX(CASE WHEN LOWER(v.test) = 'systolic blood pressure'
                                   AND TRY_CAST(v.testresult AS DOUBLE) > 0
                                   AND TRY_CAST(v.testresult AS DOUBLE)
                                       = ROUND(TRY_CAST(v.testresult AS DOUBLE), 0)
                                  THEN 1 ELSE 0 END) = 1
                     AND MAX(CASE WHEN LOWER(v.test) = 'diastolic blood pressure'
                                   AND TRY_CAST(v.testresult AS DOUBLE) > 0
                                   AND TRY_CAST(v.testresult AS DOUBLE)
                                       = ROUND(TRY_CAST(v.testresult AS DOUBLE), 0)
                                  THEN 1 ELSE 0 END) = 1)
                THEN 'Present'
                -- Q58: no date bound, and either arm alone is enough to make
                -- the analyte Unknown rather than Missing.
                WHEN EXISTS (
                  SELECT 1 FROM %1$s v
                  WHERE v.patientid = i.patientid
                    AND LOWER(v.test) IN ('systolic blood pressure',
                                          'diastolic blood pressure'))
                THEN 'Unknown'
                ELSE 'Missing' END AS qc_value
    FROM idx i", s("t_vitals")),
  ads   = "bp")

# -----------------------------------------------------------------------------
# C14-C20 - decisions that only a source join can verify
# -----------------------------------------------------------------------------
# Each is a registered divergence flagged by the qc/00_coverage.R gate whose
# delivered consequence cannot be seen from the ADS alone, because the ADS
# keeps no trace of the source rows that were considered and rejected.

# Q13 - per-analyte tie direction. 3.Data Prep note #5 gives lowest for
# albumin, neutrophils, platelets, hemoglobin and serum creatinine, and highest
# for the rest; LABNEUV's own row contradicts that note and is erratum E16.
# This re-derives the winning value on the delivered date and compares, so the
# direction that shipped is tested directly.
LAB_TIE <- list(
  list(flag="labneu", v="labneuv",  dt="labneudt",  test="neutrophils",                unit="10*9/L", comp=NA, tie="MIN"),
  list(flag="labpla", v="labplav",  dt="labplavdt", test="platelets",                  unit="10*9/L", comp=NA, tie="MIN"),
  list(flag="labhem", v="labhemv",  dt="labhemdt",  test="hemoglobin",                 unit="g/dL",   comp=NA, tie="MIN"),
  list(flag="labcre", v="labcrev",  dt="labcredt",  test="creatinine",                 unit="mg/dL",  comp="Creatinine, serum", tie="MIN"),
  list(flag="labalb", v="labalbv",  dt="labalbdt",  test="albumin",                    unit="g/L",    comp="Albumin, serum",    tie="MIN"),
  list(flag="labbil", v="labbilv",  dt="labbildt",  test="bilirubin",                  unit="mg/dL",  comp=NA, tie="MAX"),
  list(flag="labast", v="labastv",  dt="labastdt",  test="aspartate aminotransferase", unit="U/L",    comp=NA, tie="MAX"),
  list(flag="labalt", v="labaltv",  dt="labaltdt",  test="alanine aminotransferase",   unit="U/L",    comp=NA, tie="MAX"),
  list(flag="labalp", v="labalpv",  dt="labalpdt",  test="alkaline phosphatase",       unit="U/L",    comp=NA, tie="MAX"),
  list(flag="lablym", v="lablymv",  dt="lablymdt",  test="lymphocytes",                unit="10*9/L", comp=NA, tie="MAX"))

for (i in seq_along(LAB_TIE)) {
  L <- LAB_TIE[[i]]
  comp_pred <- if (is.na(L$comp)) "" else sprintf(" AND l.labcomponent = '%s'", L$comp)
  CHECKS[[length(CHECKS) + 1L]] <- list(
    label = sprintf("C14%s %s tie direction is %s (Q13, E16)", letters[i],
                    toupper(L$v), L$tie),
    note  = "the value on the DELIVERED date, taken by the analyte's own tie rule",
    qc    = sprintf("
    SELECT a.patid, a.cohortn, a.indexdt, %5$s(l.testresultcleaned) AS qc_value
    FROM %6$s a
    JOIN %1$s l
      ON l.patientid = a.patid
     AND LOWER(l.testbasename) = '%2$s'%3$s
     AND TRIM(l.testunitscleaned) = '%4$s'
     AND l.testdate IS NOT NULL
     AND l.testresultcleaned > 0
     AND GREATEST(l.testdate, l.resultdate) = a.%7$s
    WHERE a.%7$s IS NOT NULL
    GROUP BY a.patid, a.cohortn, a.indexdt",
      s("t_lab"), L$test, comp_pred, L$unit, L$tie, ADS, L$dt),
    ads_where = sprintf("%s IS NOT NULL", L$dt),
    numeric   = TRUE,
    ads       = L$v)
}

# Q20 - the biomarker [-30, +7] window comes from the Additional Notes, not the
# definition body, so it is an interpretation and needs proving.
#
# This is a falsification test, not a re-derivation. Rebuilding the whole
# biomarker cascade - panel filter, status resolution, shared winning date,
# collision table - in a second implementation would disagree with the build
# for reasons that are bugs in the copy, the same argument that keeps FUED and
# OS out of this file.
#
# The question asked instead: a patient whose HRR call is not Unknown must
# have at least one panel-gene record inside the window. A violation cannot
# occur if the window is applied, and asking this needs no second cascade.
#
# The QC side is drawn from the same population as the ADS side - non-Unknown
# calls - and then narrowed to those with an in-window record. It is therefore
# always a subset, and every "ads only" row is a real violation. Selecting
# every patient with an in-window panel record regardless of their call would
# read an ordinary in-window Unknown result as an "indep only" difference and
# fail a correct build.
CHECKS[[length(CHECKS) + 1L]] <- list(
  label = "C15 no HRR call without a panel-gene test inside [-30,+7] (Q20)",
  note  = "falsification test - a non-Unknown call with no in-window panel record",
  qc    = sprintf("
    SELECT a.patid, a.cohortn, a.indexdt, 1 AS qc_value
    FROM %s a
    WHERE a.hrr_index <> 'Unknown/Not documented'
      AND EXISTS (
        SELECT 1 FROM %s b
        WHERE b.patientid = a.patid
          AND UPPER(b.biomarkername) IN (%s)
          AND GREATEST(b.specimencollecteddate, b.resultdate)
                BETWEEN DATE_SUB(a.indexdt, 30) AND DATE_ADD(a.indexdt, 7))",
    ADS, s("t_enh_prostate_biomarker"),
    paste0("'", paste(hrr_genes, collapse = "', '"), "'")),
  ads_where = "hrr_index <> 'Unknown/Not documented'",
  ads       = "1")

# Q39 - CSF_FU counts growth-factor records after index and not beyond FUED;
# the upper bound is the substance of the Q39 ruling.
#
# A full re-derivation, over all three sources the build reads. Medication
# orders alone, without the growth-factor category and cancellation filters,
# would select any patient with any order in the window and disagree with a
# correct build in both directions.
CHECKS[[length(CHECKS) + 1L]] <- list(
  label = "C16 CSF_FU is growth factor, after index, bounded above by FUED (Q39)",
  note  = "drug episodes, non-cancelled orders and administrations, all three",
  qc    = sprintf("
    SELECT a.patid, a.cohortn, a.indexdt, 1 AS qc_value
    FROM %s a
    JOIN (
      SELECT patientid, episodedate AS dt
        FROM %s WHERE LOWER(detaileddrugcategory) = 'growth factor'
      UNION ALL
      SELECT patientid, expectedstartdate
        FROM %s WHERE LOWER(detaileddrugcategory) = 'growth factor'
          AND (iscanceled IS NULL OR LOWER(iscanceled) <> 'true')
      UNION ALL
      SELECT patientid, administereddate
        FROM %s WHERE LOWER(detaileddrugcategory) = 'growth factor'
    ) g ON g.patientid = a.patid
    WHERE g.dt > a.indexdt AND g.dt <= a.fued
    GROUP BY a.patid, a.cohortn, a.indexdt",
    ADS, s("t_enh_prostate_drg_epsode"), s("t_medicationorder"), s("t_medicationadmin")),
  ads_where = "csf_fu = 1",
  ads       = "1")

# Q40 - FU_ENDDT_preliminary is the latest of exactly four sources: visit,
# telemedicine, line end, oral end. The 202603 build also folds in alpha/beta
# emitters and Provenge; 202606 excludes them, which can shorten follow-up.
# This re-derives the maximum from the four named tables.
CHECKS[[length(CHECKS) + 1L]] <- list(
  label = "C17 FU_ENDDT_preliminary is the max of exactly four sources (Q40)",
  note  = "visit, telemedicine, line end, oral end - and nothing else",
  qc    = sprintf("
    SELECT patientid AS patid, cohortn, indexdt, MAX(dt) AS qc_value
    FROM (
      SELECT i.patientid, i.cohortn, i.indexdt, v.visitdate AS dt
        FROM idx i JOIN %s v ON v.patientid = i.patientid
      UNION ALL
      SELECT i.patientid, i.cohortn, i.indexdt, t.visitdate
        FROM idx i JOIN %s t ON t.patientid = i.patientid
      UNION ALL
      SELECT i.patientid, i.cohortn, i.indexdt, l.enddate
        FROM idx i JOIN %s l ON l.patientid = i.patientid
      UNION ALL
      SELECT i.patientid, i.cohortn, i.indexdt, o.enddate
        FROM idx i JOIN %s o ON o.patientid = i.patientid
        WHERE o.enddate IS NOT NULL
          AND LOWER(COALESCE(o.startdategranularity, '')) <> 'year'
    ) u
    WHERE dt IS NOT NULL
    GROUP BY patientid, cohortn, indexdt",
    s("t_visit"), s("t_telemedicine"), s("t_enh_prostate_lot"), s("t_enh_prostate_orals")),
  ads_where = "fu_enddt_preliminary IS NOT NULL",
  ads       = "fu_enddt_preliminary")

# Q41 - a pseudo-progression mention must not veto other progression evidence.
# The event is any of the six evidence flags on or after index + 14. Pseudo
# progression is simply not one of them, so a row carrying both a pseudo
# mention and, say, radiographic evidence still counts.
#
# The derivation must require one of the six flags without filtering pseudo
# rows out: a row with no evidence flag never counts, and a row carrying
# pseudo plus a real flag - the case Q41 rules on - always does.
#
# PFSFL = 1 exactly when the patient is eligible AND (a qualifying progression
# exists OR they died), so the QC side carries both limbs and the two sides
# should match row for row.
CHECKS[[length(CHECKS) + 1L]] <- list(
  label = "C18 an eligible progression event always sets PFSFL (Q41)",
  note  = "a pseudo mention alongside real evidence must not suppress it",
  qc    = sprintf("
    SELECT a.patid, a.cohortn, a.indexdt, 1 AS qc_value
    FROM %s a
    WHERE a.eligpfs = 1
      AND (a.dthfl = 1
        OR EXISTS (
          SELECT 1 FROM %s p
          WHERE p.patientid = a.patid
            AND p.progressiondate >= DATE_ADD(a.indexdt, 14)
            AND (LOWER(p.isradiographicevidence)   = 'true'
              OR LOWER(p.ispathologicevidence)     = 'true'
              OR LOWER(p.ismixedresponsementioned) = 'true'
              OR LOWER(p.isphysicalexamevidence)   = 'true'
              OR LOWER(p.istumormarkerevidence)    = 'true'
              OR LOWER(p.ispsaincreased)           = 'true')))",
    ADS, s("t_enh_prostate_prog_scled")),
  ads_where = "eligpfs = 1 AND pfsfl = 1",
  ads       = "1")

# Q49 - CSD matches the literal phrase "Clinical Study Drug". The spec's
# pseudo-code searches for the three letters "CSD", which never occur, so the
# column would be 0 for every patient (errata E3). This proves the corrected
# match shipped.
#
# Both halves of the definition, because CSD reads different things per
# cohort: any line in the setting for cohorts 1-2, the index line only for
# 3-7. The treated cohorts are where a wrong line pick would surface.
CHECKS[[length(CHECKS) + 1L]] <- list(
  label = "C19 CSD matches the phrase, not the letters (Q49, errata E3)",
  note  = "any line in the setting for cohorts 1-2; the index line only for 3-7",
  qc    = "
    SELECT patid, cohortn, indexdt, 1 AS qc_value
    FROM (
      SELECT i.patientid AS patid, i.cohortn, i.indexdt
      FROM idx i
      JOIN lot l
        ON l.patientid = i.patientid
       AND ((i.cohortn = 1 AND l.linesetting = 'mHSPC')
         OR (i.cohortn = 2 AND l.linesetting = 'mCRPC'))
      WHERE LOWER(l.linename) LIKE '%clinical study drug%'
      UNION ALL
      SELECT i.patientid, i.cohortn, i.indexdt
      FROM idx i
      JOIN lot l
        ON l.patientid = i.patientid
       AND l.startdate = i.indexdt
       AND ((i.cohortn = 3 AND l.linesetting = 'mHSPC' AND l.new_lot_n = 1)
         OR (i.cohortn = 4 AND l.linesetting = 'mCRPC' AND l.new_lot_n = 1)
         OR (i.cohortn = 5 AND l.linesetting = 'mCRPC' AND l.new_lot_n = 2)
         OR (i.cohortn = 6 AND l.linesetting = 'mCRPC' AND l.new_lot_n = 3)
         OR (i.cohortn = 7 AND l.linesetting = 'mCRPC' AND l.new_lot_n = 4))
      WHERE LOWER(l.linename) LIKE '%clinical study drug%'
    ) u
    GROUP BY patid, cohortn, indexdt",
  ads_where = "csd = 1",
  ads       = "1")

# Q60 - PRIOR_NHA_ADT follows the definition (an NHA plus any second drug),
# not its label (NHA plus an ADT). The flag is therefore broader than its
# name, and that is the ruling. This re-derives the definition so the breadth
# is confirmed rather than assumed.
CHECKS[[length(CHECKS) + 1L]] <- list(
  label = "C20 PRIOR_NHA_ADT follows the definition, not the label (Q60)",
  note  = "an NHA plus ANY second drug sets the flag, whether or not that drug is an ADT",
  qc    = sprintf("
    SELECT i.patientid AS patid, i.cohortn, i.indexdt,
           CASE WHEN EXISTS (
             SELECT 1 FROM %s d
             WHERE d.patientid = i.patientid
               AND d.episodedate < i.indexdt
               AND (LOWER(d.linename) LIKE '%%abiraterone%%'
                 OR LOWER(d.linename) LIKE '%%enzalutamide%%'
                 OR LOWER(d.linename) LIKE '%%apalutamide%%'
                 OR LOWER(d.linename) LIKE '%%darolutamide%%')
               AND (d.linename LIKE '%%,%%' OR d.linename LIKE '%%/%%'))
           THEN 'Yes' ELSE 'No' END AS qc_value
    FROM idx i", s("t_enh_prostate_drg_epsode")),
  ads       = "prior_nha_adt")

# -----------------------------------------------------------------------------
# C21-C22 - the 2026-09-11 follow-up ruling, from source  (register Q82)
# -----------------------------------------------------------------------------
# The two columns this file used to exempt. See the header for why the
# exemption no longer holds: there is no cascade left to reproduce, only a
# two-branch TRY_CAST and a COALESCE.
#
# Why bother, when qc/03 R11-R19 and gates V44-V47 already test both columns?
# Because every one of those reads the delivered table. R11 proves DTHFL agrees
# with DTHDT, V44 proves DTHDT agrees with DEATH_DT_preliminary, V47 proves FUED
# agrees with COALESCE(DTHDT, FU_ENDDT_preliminary) - all true of a build that
# imputed every death date to the wrong day, or read the wrong source column,
# entirely self-consistently. Only a derivation that starts at DATEOFDEATH can
# tell the difference, and these two do.

# C21. DTHDT against the mortality source.
#
# Every idx row is emitted, not only the deaths, and the comparison is
# null-safe (IS NOT DISTINCT FROM in the harness), so this is a two-sided
# check: a delivered DTHDT where source has no usable date reads as a mismatch,
# and so does a missing one where source has a date. That second direction is
# the Q66 boundary - a DATEOFDEATH of any length but 4 or 7 must deliver NULL.
#
# LEFT JOIN, because `dth` only has rows for patients present in the mortality
# table at all; an inner join would silently drop every patient who never died
# and reduce the check to the death-dated population.
CHECKS[[length(CHECKS) + 1L]] <- list(
  label = "C21 DTHDT is the imputed source death date and nothing further (Q82, Q66)",
  note  = "middle of the month, middle of the year, no further adjustment - and NULL for any other length",
  qc    = "
    SELECT i.patientid AS patid, i.cohortn, i.indexdt, d.dthdt AS qc_value
    FROM idx i
    LEFT JOIN dth d ON d.patientid = i.patientid",
  ads   = "dthdt")

# C22. FUED against source, end to end.
#
# FUED = COALESCE(DTHDT, FU_ENDDT_preliminary). NOT the minimum of the two: the
# 2026-09-11 call summary first specified a minimum and the clarification the
# same day withdrew it, because a death falling after the last recorded
# activity would then sit outside follow-up and an OS analysis would drop the
# event. A known death IS the end of follow-up. So the derivation below takes
# the death date outright whenever there is one, however stale the activity
# record, and a MIN or a GREATEST here would fail a correct build.
#
# The four-source maximum is re-derived rather than taken from the delivered
# FU_ENDDT_preliminary, which is what makes this source-anchored: C17 already
# proves that column against the same four tables, but a check reading it back
# would inherit any error in it. Derived at PATIENT level and then joined to
# idx, matching the ruling's own grain - FUED is fixed before a cohort is
# assigned, so the same patient must carry the same FUED in all seven cohorts,
# and a per-cohort derivation here could not detect a build that varied it.
#
# No ads_where. Every idx row is compared, including the rows where this side
# produces NULL - no death date and no activity in any of the four sources.
# That row is newly possible under Q82 (the old index floor made it
# unreachable) and is accepted and delivered rather than defaulted, so a NULL
# on one side against a floored or defaulted date on the other is exactly the
# drift worth catching.
#
# This is also the corroboration the unruled residue needs. R12 in qc/03 and
# gate V46 SIZE the rows where FUED precedes INDEXDT, and V46's count is only
# worth acting on if those FUEDs are what the source says (register Q83). A
# MATCH here says they are: the short follow-up is a real last-activity date
# with no death date beside it, not an artefact of this build.
CHECKS[[length(CHECKS) + 1L]] <- list(
  label = "C22 FUED is COALESCE(DTHDT, FU_ENDDT_preliminary) from source - not the minimum (Q82)",
  note  = "the death date where there is one, else the last of visit/telemedicine/line end/oral end; NULL is a legal answer",
  qc    = sprintf("
    SELECT i.patientid AS patid, i.cohortn, i.indexdt,
           COALESCE(d.dthdt, p.fu_enddt_prelim) AS qc_value
    FROM idx i
    LEFT JOIN dth d ON d.patientid = i.patientid
    LEFT JOIN (
      SELECT patientid, MAX(dt) AS fu_enddt_prelim
      FROM (
        SELECT patientid, visitdate AS dt FROM %s
        UNION ALL
        SELECT patientid, visitdate     FROM %s
        UNION ALL
        SELECT patientid, enddate       FROM %s
        UNION ALL
        SELECT patientid, enddate       FROM %s
          WHERE enddate IS NOT NULL
            AND LOWER(COALESCE(startdategranularity, '')) <> 'year'
      ) u
      WHERE dt IS NOT NULL
      GROUP BY patientid
    ) p ON p.patientid = i.patientid",
    s("t_visit"), s("t_telemedicine"), s("t_enh_prostate_lot"),
    s("t_enh_prostate_orals")),
  ads   = "fued")

# -----------------------------------------------------------------------------
# Run
# -----------------------------------------------------------------------------
cat("\n=============================================================\n")
cat("QC 05 INDEPENDENT RE-DERIVATION\n")
cat("  ADS    : ", ADS, "\n", sep = "")
cat("  source : ", SRC, " (snapshot ", refresh, ")\n", sep = "")
cat("=============================================================\n\n")

results <- list()
errored <- character()
for (ck in CHECKS) {
  cat("running ", ck$label, " ...\n", sep = "")
  r <- compare(ck$label, ck$qc, ck$ads, ck$note,
               ads_where = ck$ads_where, numeric = isTRUE(ck$numeric))
  if (is.null(r)) errored <- c(errored, ck$label)
  else            results[[length(results) + 1L]] <- r
}

if (length(results)) {
  tab <- do.call(rbind, results)
  cat("\n---- summary ------------------------------------------------\n")
  print(tab[, c("check_name", "n_both", "n_ads_only", "n_indep_only",
                "n_value_mismatch", "status")], row.names = FALSE)

  bad <- tab[tab$status == "DIFFER", , drop = FALSE]
  if (nrow(bad)) {
    cat("\n", nrow(bad), " check(s) DIFFER. Drill in with:\n\n", sep = "")
    cat("  ck <- CHECKS[[<n>]]\n")
    cat("  show_mismatches(ck$label, ck$qc, ck$ads)\n\n")
    cat("A difference is a FINDING, not a script error - one of the two\n")
    cat("derivations is wrong and which one is the question to answer.\n")
  } else if (!length(errored)) {
    cat("\nAll checks MATCH. Every variable above is now corroborated by two\n")
    cat("independent derivations rather than by one.\n")
  }

  # A check that throws is caught and dropped from `results`, so the remaining
  # checks alone could still print "All checks MATCH" - a clean bill of health
  # for a suite that did not fully run. An error is an unknown, not a pass,
  # and is reported as loudly as a difference.
  if (length(errored)) {
    cat("\n", length(errored), " check(s) DID NOT RUN:\n", sep = "")
    for (e in errored) cat("  ERROR  ", e, "\n", sep = "")
    cat("These are NOT passes. Fix them and re-run before treating this pack\n")
    cat("as evidence - a variable nobody checked is not a variable that agreed.\n")
  }

  # This CSV is the retained evidence for qc/05 - the program writes no qcr_*
  # table and therefore no stamp, so the identity goes into the export itself.
  # Repeated on every row so a row lifted out of the file is still attributable.
  # Without it the CSV records what agreed but not which code checked it (Q43).
  source("validation/00_build_identity.R")
  .id <- build_identity()
  tab <- cbind(tab,
               checker_commit = .id$checker_commit,
               checker_dirty  = .id$checker_dirty,
               refresh        = .id$refresh,
               hrr_panel      = .id$hrr_panel,
               checked_at     = format(Sys.time(), "%Y-%m-%d %H:%M:%S"))

  out_csv <- file.path("qc", paste0("qc05_rederivation_", refresh, ".csv"))
  utils::write.csv(tab, out_csv, row.names = FALSE)
  cat("\nwrote ", out_csv, " - retain this in the QC pack\n", sep = "")
  if (length(errored) || nrow(bad)) quit(status = 1L)
} else {
  cat("no checks completed - see the errors above\n")
  quit(status = 1L)
}
