-- =============================================================================
-- QC 02. LABEL / CODE AGREEMENT - EVERY PAIR, BOTH DIRECTIONS
-- =============================================================================
-- GENERATED FILE. Do not edit by hand.
--   source    : validation/00_column_contract.csv (pairs discovered, not typed)
--   generator : qc/make_qc_sql.R
--   enforced  : validation/02_offline_build_check.R regenerates and diffs this
--
-- Substitute ${catalog} / ${schema} / ${ads} before running.
--
-- 25 pairs. Every RWD spec in this family defines coded variables twice -
-- once as a label and once as a number - in two separate case_when blocks that
-- nothing forces to agree. When a category is added, renamed or reordered in
-- one block and not the other, the two silently diverge and every downstream
-- frequency table splits. This is the single highest-yield mechanical check in
-- the QC pack, and it needs no expected values: the invariant is structural.
--
-- The register already holds two near-misses of exactly this kind. Q23 changed
-- ECOG from seven categories to six, which required ECOG and ECOGN to move
-- together. Under Q50 the residual codes were unified on 99, which touched
-- AGEGR1N, REGION1N, PRACTICN and COHORTUN but NOT their labels - correct, but
-- only because the labels have no residual to unify. Nothing checked either.
--
-- HOW TO READ IT
--   status = 'PASS'          the mapping is 1:1 in both directions
--   status = 'FAIL 1:many'   one label carries more than one code, or one code
--                            carries more than one label. n_distinct_pairs
--                            exceeds both n_labels and n_codes when it is
--                            many:many. Drill in with the template at the
--                            bottom of this file.
--   status = 'FAIL half-null' one side is populated where the other is not.
--                            A label with no code, or a code with no label.
--
-- Rows where BOTH sides are null are excluded - that is a variable that does
-- not apply to the patient, not a disagreement. The per-cohort profile in
-- qc/01_variable_profile.sql is where absence is judged.
-- =============================================================================

USE CATALOG ${catalog};

WITH pairs AS (
SELECT 'agegr1' AS label_col, 'agegr1n' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(agegr1 AS STRING), CAST(agegr1n AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(agegr1 AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(agegr1n AS STRING))                         AS n_codes,
       SUM(CASE WHEN (agegr1 IS NULL) <> (agegr1n IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  agegr1 IS NOT NULL OR agegr1n IS NOT NULL
UNION ALL

SELECT 'region1' AS label_col, 'region1n' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(region1 AS STRING), CAST(region1n AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(region1 AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(region1n AS STRING))                         AS n_codes,
       SUM(CASE WHEN (region1 IS NULL) <> (region1n IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  region1 IS NOT NULL OR region1n IS NOT NULL
UNION ALL

SELECT 'race' AS label_col, 'racen' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(race AS STRING), CAST(racen AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(race AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(racen AS STRING))                         AS n_codes,
       SUM(CASE WHEN (race IS NULL) <> (racen IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  race IS NOT NULL OR racen IS NOT NULL
UNION ALL

SELECT 'eth' AS label_col, 'ethn' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(eth AS STRING), CAST(ethn AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(eth AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(ethn AS STRING))                         AS n_codes,
       SUM(CASE WHEN (eth IS NULL) <> (ethn IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  eth IS NOT NULL OR ethn IS NOT NULL
UNION ALL

SELECT 'practic' AS label_col, 'practicn' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(practic AS STRING), CAST(practicn AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(practic AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(practicn AS STRING))                         AS n_codes,
       SUM(CASE WHEN (practic IS NULL) <> (practicn IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  practic IS NOT NULL OR practicn IS NOT NULL
UNION ALL

SELECT 'stage' AS label_col, 'stagen' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(stage AS STRING), CAST(stagen AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(stage AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(stagen AS STRING))                         AS n_codes,
       SUM(CASE WHEN (stage IS NULL) <> (stagen IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  stage IS NOT NULL OR stagen IS NOT NULL
UNION ALL

SELECT 'gleason' AS label_col, 'gleasonn' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(gleason AS STRING), CAST(gleasonn AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(gleason AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(gleasonn AS STRING))                         AS n_codes,
       SUM(CASE WHEN (gleason IS NULL) <> (gleasonn IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  gleason IS NOT NULL OR gleasonn IS NOT NULL
UNION ALL

SELECT 'ecog' AS label_col, 'ecogn' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(ecog AS STRING), CAST(ecogn AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(ecog AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(ecogn AS STRING))                         AS n_codes,
       SUM(CASE WHEN (ecog IS NULL) <> (ecogn IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  ecog IS NOT NULL OR ecogn IS NOT NULL
UNION ALL

SELECT 'bp' AS label_col, 'bpn' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(bp AS STRING), CAST(bpn AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(bp AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(bpn AS STRING))                         AS n_codes,
       SUM(CASE WHEN (bp IS NULL) <> (bpn IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  bp IS NOT NULL OR bpn IS NOT NULL
UNION ALL

SELECT 'bmigr1' AS label_col, 'bmigr1n' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(bmigr1 AS STRING), CAST(bmigr1n AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(bmigr1 AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(bmigr1n AS STRING))                         AS n_codes,
       SUM(CASE WHEN (bmigr1 IS NULL) <> (bmigr1n IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  bmigr1 IS NOT NULL OR bmigr1n IS NOT NULL
UNION ALL

SELECT 'hrr_index' AS label_col, 'hrr_indexn' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(hrr_index AS STRING), CAST(hrr_indexn AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(hrr_index AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(hrr_indexn AS STRING))                         AS n_codes,
       SUM(CASE WHEN (hrr_index IS NULL) <> (hrr_indexn IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  hrr_index IS NOT NULL OR hrr_indexn IS NOT NULL
UNION ALL

SELECT 'hrr_label_index' AS label_col, 'hrr_label_indexn' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(hrr_label_index AS STRING), CAST(hrr_label_indexn AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(hrr_label_index AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(hrr_label_indexn AS STRING))                         AS n_codes,
       SUM(CASE WHEN (hrr_label_index IS NULL) <> (hrr_label_indexn IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  hrr_label_index IS NOT NULL OR hrr_label_indexn IS NOT NULL
UNION ALL

SELECT 'brca_index' AS label_col, 'brca_indexn' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(brca_index AS STRING), CAST(brca_indexn AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(brca_index AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(brca_indexn AS STRING))                         AS n_codes,
       SUM(CASE WHEN (brca_index IS NULL) <> (brca_indexn IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  brca_index IS NOT NULL OR brca_indexn IS NOT NULL
UNION ALL

SELECT 'hrr_index_test' AS label_col, 'hrr_index_testn' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(hrr_index_test AS STRING), CAST(hrr_index_testn AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(hrr_index_test AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(hrr_index_testn AS STRING))                         AS n_codes,
       SUM(CASE WHEN (hrr_index_test IS NULL) <> (hrr_index_testn IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  hrr_index_test IS NOT NULL OR hrr_index_testn IS NOT NULL
UNION ALL

SELECT 'brca_index_test' AS label_col, 'brca_index_testn' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(brca_index_test AS STRING), CAST(brca_index_testn AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(brca_index_test AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(brca_index_testn AS STRING))                         AS n_codes,
       SUM(CASE WHEN (brca_index_test IS NULL) <> (brca_index_testn IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  brca_index_test IS NOT NULL OR brca_index_testn IS NOT NULL
UNION ALL

SELECT 'lot1cat_mhspc' AS label_col, 'lot1catn_mhspc' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(lot1cat_mhspc AS STRING), CAST(lot1catn_mhspc AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(lot1cat_mhspc AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(lot1catn_mhspc AS STRING))                         AS n_codes,
       SUM(CASE WHEN (lot1cat_mhspc IS NULL) <> (lot1catn_mhspc IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  lot1cat_mhspc IS NOT NULL OR lot1catn_mhspc IS NOT NULL
UNION ALL

SELECT 'lot2cat_mhspc' AS label_col, 'lot2catn_mhspc' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(lot2cat_mhspc AS STRING), CAST(lot2catn_mhspc AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(lot2cat_mhspc AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(lot2catn_mhspc AS STRING))                         AS n_codes,
       SUM(CASE WHEN (lot2cat_mhspc IS NULL) <> (lot2catn_mhspc IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  lot2cat_mhspc IS NOT NULL OR lot2catn_mhspc IS NOT NULL
UNION ALL

SELECT 'lot1cat_mcrpc' AS label_col, 'lot1catn_mcrpc' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(lot1cat_mcrpc AS STRING), CAST(lot1catn_mcrpc AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(lot1cat_mcrpc AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(lot1catn_mcrpc AS STRING))                         AS n_codes,
       SUM(CASE WHEN (lot1cat_mcrpc IS NULL) <> (lot1catn_mcrpc IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  lot1cat_mcrpc IS NOT NULL OR lot1catn_mcrpc IS NOT NULL
UNION ALL

SELECT 'lot2cat_mcrpc' AS label_col, 'lot2catn_mcrpc' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(lot2cat_mcrpc AS STRING), CAST(lot2catn_mcrpc AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(lot2cat_mcrpc AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(lot2catn_mcrpc AS STRING))                         AS n_codes,
       SUM(CASE WHEN (lot2cat_mcrpc IS NULL) <> (lot2catn_mcrpc IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  lot2cat_mcrpc IS NOT NULL OR lot2catn_mcrpc IS NOT NULL
UNION ALL

SELECT 'lot3cat_mcrpc' AS label_col, 'lot3catn_mcrpc' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(lot3cat_mcrpc AS STRING), CAST(lot3catn_mcrpc AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(lot3cat_mcrpc AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(lot3catn_mcrpc AS STRING))                         AS n_codes,
       SUM(CASE WHEN (lot3cat_mcrpc IS NULL) <> (lot3catn_mcrpc IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  lot3cat_mcrpc IS NOT NULL OR lot3catn_mcrpc IS NOT NULL
UNION ALL

SELECT 'lot4cat_mcrpc' AS label_col, 'lot4catn_mcrpc' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(lot4cat_mcrpc AS STRING), CAST(lot4catn_mcrpc AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(lot4cat_mcrpc AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(lot4catn_mcrpc AS STRING))                         AS n_codes,
       SUM(CASE WHEN (lot4cat_mcrpc IS NULL) <> (lot4catn_mcrpc IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  lot4cat_mcrpc IS NOT NULL OR lot4catn_mcrpc IS NOT NULL
UNION ALL

SELECT 'lotngr1' AS label_col, 'lotngr1n' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(lotngr1 AS STRING), CAST(lotngr1n AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(lotngr1 AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(lotngr1n AS STRING))                         AS n_codes,
       SUM(CASE WHEN (lotngr1 IS NULL) <> (lotngr1n IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  lotngr1 IS NOT NULL OR lotngr1n IS NOT NULL
UNION ALL

SELECT 'lotngr1_mhspc' AS label_col, 'lotngr1n_mhspc' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(lotngr1_mhspc AS STRING), CAST(lotngr1n_mhspc AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(lotngr1_mhspc AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(lotngr1n_mhspc AS STRING))                         AS n_codes,
       SUM(CASE WHEN (lotngr1_mhspc IS NULL) <> (lotngr1n_mhspc IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  lotngr1_mhspc IS NOT NULL OR lotngr1n_mhspc IS NOT NULL
UNION ALL

SELECT 'cohort' AS label_col, 'cohortn' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(cohort AS STRING), CAST(cohortn AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(cohort AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(cohortn AS STRING))                         AS n_codes,
       SUM(CASE WHEN (cohort IS NULL) <> (cohortn IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  cohort IS NOT NULL OR cohortn IS NOT NULL
UNION ALL

SELECT 'cohortu' AS label_col, 'cohortun' AS code_col,
       COUNT(*)                                                     AS n_rows_either_side,
       COUNT(DISTINCT CONCAT_WS('|', CAST(cohortu AS STRING), CAST(cohortun AS STRING))) AS n_distinct_pairs,
       COUNT(DISTINCT CAST(cohortu AS STRING))                         AS n_labels,
       COUNT(DISTINCT CAST(cohortun AS STRING))                         AS n_codes,
       SUM(CASE WHEN (cohortu IS NULL) <> (cohortun IS NULL) THEN 1 ELSE 0 END) AS n_half_null
FROM   ${schema}.${ads}
WHERE  cohortu IS NOT NULL OR cohortun IS NOT NULL

)
SELECT label_col, code_col, n_rows_either_side, n_labels, n_codes,
       n_distinct_pairs, n_half_null,
       CASE WHEN n_half_null > 0                            THEN 'FAIL half-null'
            WHEN n_distinct_pairs > GREATEST(n_labels, n_codes) THEN 'FAIL many:many'
            WHEN n_distinct_pairs > n_labels                THEN 'FAIL label 1:many'
            WHEN n_distinct_pairs > n_codes                 THEN 'FAIL code 1:many'
            ELSE 'PASS' END AS status
FROM   pairs
ORDER  BY CASE WHEN n_half_null > 0 THEN 0
               WHEN n_distinct_pairs > LEAST(n_labels, n_codes) THEN 1
               ELSE 2 END,
          label_col;


-- =============================================================================
-- DRILL-IN TEMPLATE - run this for any pair that did not read PASS
-- =============================================================================
-- Replace <label> and <code> with the failing pair. It lists every distinct
-- combination with its row count, so the offending category is visible
-- immediately rather than inferred from counts.
--
-- SELECT <label>, <code>, COUNT(*) AS n_rows,
--        COUNT(DISTINCT patid) AS n_pts,
--        CONCAT_WS(',', SORT_ARRAY(COLLECT_SET(cohort))) AS cohorts
-- FROM   ${schema}.${ads}
-- WHERE  <label> IS NOT NULL OR <code> IS NOT NULL
-- GROUP  BY <label>, <code>
-- ORDER  BY <code>, <label>;
