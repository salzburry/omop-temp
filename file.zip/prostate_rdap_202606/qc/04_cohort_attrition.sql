-- =============================================================================
-- QC 04. COHORT ATTRITION WATERFALL
-- =============================================================================
-- Substitute ${catalog} / ${schema} / ${ads} and ${src} (the source namespace,
-- normally clnprw_flatiron_pano_pros_use) before running.
--
-- WHAT THIS ANSWERS
--   How many patients does each filter in 4.StudyPop section B remove, and does
--   the number that survive equal the number the ADS actually delivers?
--
--   Every other number in the QC pack describes rows that are present. The
--   final comparison is the only check that asks whether rows went missing
--   between the source and the deliverable - the failure mode where the ADS
--   is internally consistent yet incomplete.
--
-- HOW TO READ IT
--   Read `n_patients` down each cohort block. Every drop should have a stated
--   cause in the `step` column. The last two rows of each block must agree:
--   the Q82 death-exclusion step and `delivered in ADS`.
--
--   The drop INTO that step - step 4 to step 5 - is the headline impact of the
--   2026-09-11 follow-up ruling (register Q82): the patients each cohort loses
--   because its own index date falls after their death date. It is applied per
--   cohort, so the same patient can survive in one block and be dropped from
--   the next - an L1 start before the death date and an L3 start after it.
--
--   `pct_of_previous` exposes an unintended near-total filter. A step that
--   removes 99% is either wrong or belongs in the release note.
--
-- This file makes no pass/fail claim except on the final comparison, emitted
-- at the bottom as a single PASS/FAIL row.
-- RP1-RP4 and W1-W3 are the 2026-09-11 ruling's four rules and the three
-- behaviours they withdraw, defined in docs/VARIABLES.md section 3.
-- =============================================================================

USE CATALOG ${catalog};

WITH ms AS (
    SELECT patientid,
           metastaticdiagnosisdate,
           hspcdate,
           crpcdate,
           GREATEST(metastaticdiagnosisdate, hspcdate) AS mhspcdd,
           GREATEST(metastaticdiagnosisdate, crpcdate) AS mcrpcdd
    FROM ${src}.t_enh_prostate_2026m06
),
lot AS (
    SELECT patientid, linesetting, startdate,
           ROW_NUMBER() OVER (PARTITION BY patientid, linesetting
                              ORDER BY startdate) AS new_lot_n
    FROM ${src}.t_enh_prostate_lot_2026m06
    WHERE linesetting IN ('mHSPC', 'mCRPC')
),
-- ---- patient-level death date, straight from source  (register Q82) ---------
-- Rule RP1, with W1-W3 withdrawn, so DTHDT is the imputed value itself and this
-- CTE is the whole derivation rather than a first stage of it.
--
-- Re-derived from the mortality source rather than read back from the ADS. The
-- exclusion step below exists to check the build, so it cannot borrow the
-- build's own answer for the date it filters on.
--
-- TRY_CAST, never CAST. '2020-13' is seven characters long and is not a date;
-- under ANSI mode a plain CAST aborts the query instead of reading NULL. Any
-- other length falls to NULL by design (register Q66); qc/08 sizes that.
--
-- DISTINCT so a patient with more than one mortality row cannot multiply the
-- rows of whatever joins this.
dth AS (
    SELECT DISTINCT patientid,
           CASE WHEN LENGTH(dateofdeath) = 7 THEN TRY_CAST(CONCAT(dateofdeath, '-15') AS DATE)
                WHEN LENGTH(dateofdeath) = 4 THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
                ELSE NULL END AS dthdt
    FROM ${src}.t_mortality_v2_2026m06
),

steps AS (

-- ---- shared starting point --------------------------------------------------
SELECT 0 AS step_no, 'ALL' AS cohort, 'patients in t_enh_prostate' AS step,
       COUNT(DISTINCT patientid) AS n_patients
FROM ms
UNION ALL
SELECT 1, 'ALL', 'has a metastatic diagnosis date', COUNT(DISTINCT patientid)
FROM ms WHERE metastaticdiagnosisdate IS NOT NULL

-- ---- cohort 1, Overall mHSPC -------------------------------------------------
UNION ALL
SELECT 2, '1 Overall mHSPC', 'has an mHSPC milestone (metdx or hspcdate)',
       COUNT(DISTINCT patientid) FROM ms WHERE mhspcdd IS NOT NULL
UNION ALL
SELECT 3, '1 Overall mHSPC', 'milestone within [2011-01-01, 2026-04-30]',
       COUNT(DISTINCT patientid) FROM ms
WHERE mhspcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
UNION ALL
SELECT 4, '1 Overall mHSPC', 'eligible at source', COUNT(DISTINCT patientid) FROM ms
WHERE mhspcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
UNION ALL
-- The Q82 exclusion. For cohorts 1 and 2 the index date IS the milestone date,
-- so the test runs against mhspcdd / mcrpcdd. Strict: a death ON the index date
-- keeps the patient, because the ruling excludes an index AFTER the death.
-- `dthdt IS NULL` keeps every patient with no usable death date.
SELECT 5, '1 Overall mHSPC',
       'index on or before death date - the Q82 exclusion (headline drop)',
       COUNT(DISTINCT m.patientid)
FROM ms m LEFT JOIN dth d ON d.patientid = m.patientid
WHERE m.mhspcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
  AND (d.dthdt IS NULL OR m.mhspcdd <= d.dthdt)
UNION ALL
SELECT 6, '1 Overall mHSPC', 'delivered in ADS', COUNT(DISTINCT patid)
FROM ${schema}.${ads} WHERE cohortn = 1

-- ---- cohort 2, Overall mCRPC -------------------------------------------------
UNION ALL
SELECT 2, '2 Overall mCRPC', 'has an mCRPC milestone (metdx or crpcdate)',
       COUNT(DISTINCT patientid) FROM ms WHERE mcrpcdd IS NOT NULL
UNION ALL
SELECT 3, '2 Overall mCRPC', 'milestone within [2011-01-01, 2026-04-30]',
       COUNT(DISTINCT patientid) FROM ms
WHERE mcrpcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
UNION ALL
SELECT 4, '2 Overall mCRPC', 'eligible at source', COUNT(DISTINCT patientid) FROM ms
WHERE mcrpcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
UNION ALL
SELECT 5, '2 Overall mCRPC',
       'index on or before death date - the Q82 exclusion (headline drop)',
       COUNT(DISTINCT m.patientid)
FROM ms m LEFT JOIN dth d ON d.patientid = m.patientid
WHERE m.mcrpcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
  AND (d.dthdt IS NULL OR m.mcrpcdd <= d.dthdt)
UNION ALL
SELECT 6, '2 Overall mCRPC', 'delivered in ADS', COUNT(DISTINCT patid)
FROM ${schema}.${ads} WHERE cohortn = 2

-- ---- cohorts 3-7, the line-of-therapy cohorts --------------------------------
-- NEW_LOT_N is derived: it restarts at 1 within each setting, ordered by start
-- date, and is not the source LINENUMBER. That difference is why register Q06
-- and Q52 exist. The window here reproduces the build's exactly.
UNION ALL
SELECT 2,
       CASE WHEN linesetting = 'mHSPC' THEN '3 L1+ mHSPC'
            WHEN new_lot_n = 1         THEN '4 L1+ mCRPC'
            WHEN new_lot_n = 2         THEN '5 L2+ mCRPC'
            WHEN new_lot_n = 3         THEN '6 L3+ mCRPC'
            ELSE                            '7 L4+ mCRPC' END,
       'has a line at this position in this setting',
       COUNT(DISTINCT patientid)
FROM lot
WHERE (linesetting = 'mHSPC' AND new_lot_n = 1)
   OR (linesetting = 'mCRPC' AND new_lot_n BETWEEN 1 AND 4)
GROUP BY 2
UNION ALL
SELECT 3,
       CASE WHEN l.linesetting = 'mHSPC' THEN '3 L1+ mHSPC'
            WHEN l.new_lot_n = 1         THEN '4 L1+ mCRPC'
            WHEN l.new_lot_n = 2         THEN '5 L2+ mCRPC'
            WHEN l.new_lot_n = 3         THEN '6 L3+ mCRPC'
            ELSE                              '7 L4+ mCRPC' END,
       'line start within [2011-01-01, 2026-04-30]',
       COUNT(DISTINCT l.patientid)
FROM lot l
WHERE ((l.linesetting = 'mHSPC' AND l.new_lot_n = 1)
    OR (l.linesetting = 'mCRPC' AND l.new_lot_n BETWEEN 1 AND 4))
  AND l.startdate BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
GROUP BY 2
UNION ALL
SELECT 4,
       CASE WHEN l.linesetting = 'mHSPC' THEN '3 L1+ mHSPC'
            WHEN l.new_lot_n = 1         THEN '4 L1+ mCRPC'
            WHEN l.new_lot_n = 2         THEN '5 L2+ mCRPC'
            WHEN l.new_lot_n = 3         THEN '6 L3+ mCRPC'
            ELSE                              '7 L4+ mCRPC' END,
       'eligible at source',
       COUNT(DISTINCT l.patientid)
FROM lot l
JOIN ms m ON m.patientid = l.patientid
WHERE ((l.linesetting = 'mHSPC' AND l.new_lot_n = 1)
    OR (l.linesetting = 'mCRPC' AND l.new_lot_n BETWEEN 1 AND 4))
  AND l.startdate BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
  AND ((l.linesetting = 'mHSPC' AND m.mhspcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30')
    OR (l.linesetting = 'mCRPC' AND m.mcrpcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'))
GROUP BY 2
UNION ALL
-- The Q82 exclusion for cohorts 3-7, and the place where it actually bites:
-- here the index date is the LINE START date, so a patient can pass the test at
-- L1 and fail it at L3 when the later line starts after the death date. Read
-- this drop per block, not in total - the same patient can be in the 4 L1+
-- count and out of the 6 L3+ count.
SELECT 5,
       CASE WHEN l.linesetting = 'mHSPC' THEN '3 L1+ mHSPC'
            WHEN l.new_lot_n = 1         THEN '4 L1+ mCRPC'
            WHEN l.new_lot_n = 2         THEN '5 L2+ mCRPC'
            WHEN l.new_lot_n = 3         THEN '6 L3+ mCRPC'
            ELSE                              '7 L4+ mCRPC' END,
       'index on or before death date - the Q82 exclusion (headline drop)',
       COUNT(DISTINCT l.patientid)
FROM lot l
JOIN ms m ON m.patientid = l.patientid
LEFT JOIN dth d ON d.patientid = l.patientid
WHERE ((l.linesetting = 'mHSPC' AND l.new_lot_n = 1)
    OR (l.linesetting = 'mCRPC' AND l.new_lot_n BETWEEN 1 AND 4))
  AND l.startdate BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
  AND ((l.linesetting = 'mHSPC' AND m.mhspcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30')
    OR (l.linesetting = 'mCRPC' AND m.mcrpcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'))
  AND (d.dthdt IS NULL OR l.startdate <= d.dthdt)
GROUP BY 2
UNION ALL
SELECT 6,
       CASE cohortn WHEN 3 THEN '3 L1+ mHSPC' WHEN 4 THEN '4 L1+ mCRPC'
                    WHEN 5 THEN '5 L2+ mCRPC' WHEN 6 THEN '6 L3+ mCRPC'
                    ELSE        '7 L4+ mCRPC' END,
       'delivered in ADS',
       COUNT(DISTINCT patid)
FROM ${schema}.${ads} WHERE cohortn BETWEEN 3 AND 7 GROUP BY 2
)

SELECT cohort, step_no, step, n_patients,
       ROUND(100.0 * n_patients /
             NULLIF(LAG(n_patients) OVER (PARTITION BY cohort ORDER BY step_no), 0),
             1) AS pct_of_previous
FROM   steps
ORDER  BY cohort, step_no;


-- =============================================================================
-- THE ONE GATE IN THIS FILE: source eligibility after Q82 must equal delivered
-- =============================================================================
-- There is exactly one filter between "eligible at source" and the ADS: the
-- per-cohort death exclusion of the 2026-09-11 ruling (register Q82). Before
-- that ruling there was none, and this gate compared raw source eligibility
-- against the delivered count. It cannot do that any more - the build now drops
-- every row whose index date falls after the patient's death date, so the two
-- sides would differ for all seven cohorts on a CORRECT build.
--
-- So `expected` applies the same exclusion, against a death date derived from
-- the mortality source by the same rule. The gate is then like for like again:
-- PASS means the build's cohort membership is exactly source eligibility minus
-- the Q82 exclusion, and a difference once more means rows were lost or
-- duplicated inside the build rather than removed on purpose.
WITH ms AS (
    SELECT patientid,
           GREATEST(metastaticdiagnosisdate, hspcdate) AS mhspcdd,
           GREATEST(metastaticdiagnosisdate, crpcdate) AS mcrpcdd
    FROM ${src}.t_enh_prostate_2026m06
),
lot AS (
    SELECT patientid, linesetting, startdate,
           ROW_NUMBER() OVER (PARTITION BY patientid, linesetting
                              ORDER BY startdate) AS new_lot_n
    FROM ${src}.t_enh_prostate_lot_2026m06
    WHERE linesetting IN ('mHSPC', 'mCRPC')
),
-- Same imputation as the waterfall above, repeated because this is a separate
-- statement: middle of the month, middle of the year, nothing further, TRY_CAST
-- so a right-length wrong-shape value reads NULL instead of raising (Q82, Q66).
dth AS (
    SELECT DISTINCT patientid,
           CASE WHEN LENGTH(dateofdeath) = 7 THEN TRY_CAST(CONCAT(dateofdeath, '-15') AS DATE)
                WHEN LENGTH(dateofdeath) = 4 THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
                ELSE NULL END AS dthdt
    FROM ${src}.t_mortality_v2_2026m06
),
expected AS (
    -- Cohorts 1-2 index on the milestone date, so that is what the Q82 test
    -- compares; cohorts 3-7 index on the line start date. LEFT JOIN and
    -- `dthdt IS NULL` keep every patient with no usable death date, and the
    -- test is strict, so an index ON the death date stays in.
    SELECT 1 AS cohortn, COUNT(DISTINCT m.patientid) AS n_expected
    FROM ms m LEFT JOIN dth d ON d.patientid = m.patientid
    WHERE m.mhspcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND (d.dthdt IS NULL OR m.mhspcdd <= d.dthdt)
    UNION ALL
    SELECT 2, COUNT(DISTINCT m.patientid)
    FROM ms m LEFT JOIN dth d ON d.patientid = m.patientid
    WHERE m.mcrpcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND (d.dthdt IS NULL OR m.mcrpcdd <= d.dthdt)
    UNION ALL
    SELECT CASE WHEN l.linesetting = 'mHSPC' THEN 3
                WHEN l.new_lot_n = 1         THEN 4
                WHEN l.new_lot_n = 2         THEN 5
                WHEN l.new_lot_n = 3         THEN 6
                ELSE                              7 END,
           COUNT(DISTINCT l.patientid)
    FROM lot l JOIN ms m ON m.patientid = l.patientid
    LEFT JOIN dth d ON d.patientid = l.patientid
    WHERE ((l.linesetting = 'mHSPC' AND l.new_lot_n = 1)
        OR (l.linesetting = 'mCRPC' AND l.new_lot_n BETWEEN 1 AND 4))
      AND l.startdate BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND ((l.linesetting = 'mHSPC' AND m.mhspcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30')
        OR (l.linesetting = 'mCRPC' AND m.mcrpcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'))
      AND (d.dthdt IS NULL OR l.startdate <= d.dthdt)
    GROUP BY 1
),
delivered AS (
    SELECT cohortn, COUNT(DISTINCT patid) AS n_delivered, COUNT(*) AS n_rows
    FROM ${schema}.${ads} GROUP BY cohortn
)
SELECT e.cohortn, e.n_expected, d.n_delivered, d.n_rows,
       d.n_delivered - e.n_expected AS diff_patients,
       d.n_rows      - d.n_delivered AS extra_rows_beyond_one_per_patient,
       CASE WHEN d.n_delivered = e.n_expected AND d.n_rows = d.n_delivered
            THEN 'PASS' ELSE 'FAIL' END AS status
FROM       expected e
FULL OUTER JOIN delivered d ON d.cohortn = e.cohortn
ORDER BY e.cohortn;
