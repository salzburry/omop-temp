# =============================================================================
# QC 04. COHORT ATTRITION WATERFALL IN R - RUN IN DATABRICKS, NOTHING FETCHED
# =============================================================================
#   Rscript qc/04_cohort_attrition.R              (after a build, repo root)
#
# Same waterfall as qc/04_cohort_attrition.sql, written as dplyr. Every step
# runs inside Databricks and lands in the personal schema with
# createInPersonalSchema - the build's own write path. Nothing is fetched.
#
# Read the results in the SQL editor:
#   qcr_attrition_r       the waterfall. Read n_patients down each cohort
#                         block; every drop should have a stated cause in
#                         `step`. The last two rows of each block must agree:
#                         the death-exclusion step and `delivered in ADS`.
#                         The drop INTO that step - step 4 to step 5 - is the
#                         headline impact of the 2026-09-11 follow-up ruling:
#                         the patients each cohort loses
#                         because its own index date falls after their death
#                         date. It is applied per cohort, so the same patient
#                         can survive in one block and be dropped from the
#                         next - an L1 start before the death date and an L3
#                         start after it.
#                         pct_of_previous exposes an unintended near-total
#                         filter - a step that removes 99% is either wrong or
#                         belongs in the release note.
#   qcr_attrition_gate_r  the one gate, per cohort. Source eligibility AFTER
#                         the death exclusion must equal what was delivered,
#                         BY MEMBERSHIP and not only by count: the two
#                         anti-join columns must both read zero, so a build
#                         that swapped one patient for another fails even
#                         though the totals match. Every row must read PASS.
#
# The SQL runs as two statements and re-derives its ms/lot/dth CTEs in each;
# here the shared derivations are built once and both outputs read them.
# RP1-RP4 and W1-W3 are the 2026-09-11 ruling's four rules and the three
# behaviours they withdraw, defined in docs/VARIABLES.md section 3.
# =============================================================================

if (!exists("con")) {
  message("no open connection - sourcing validation/00_connect.R")
  source("validation/00_connect.R")
}
stopifnot(exists("con"), exists("personal_schema"), exists("output_table"),
          exists("source_schema"), exists("refresh"))

ads  <- dplyr::tbl(con, dbplyr::in_schema(personal_schema, output_table))
# rename_with(tolower): the driver reports source columns in stored case,
# which is not always lower - the build's own src() lowercases the same way.
src_ <- function(tb) dplyr::tbl(con, dbplyr::in_schema(
          source_schema, paste0(tb, "_", refresh))) %>%
  dplyr::rename_with(tolower)

IDX_LO <- as.Date("2011-01-01")
IDX_HI <- as.Date("2026-04-30")

# ---- shared derivations -----------------------------------------------------
# GREATEST skips NULLs in Spark; pmax(na.rm = TRUE) renders exactly that.
ms <- src_("t_enh_prostate") %>%
  dplyr::transmute(
    patientid, metastaticdiagnosisdate, hspcdate, crpcdate,
    mhspcdd = pmax(metastaticdiagnosisdate, hspcdate, na.rm = TRUE),
    mcrpcdd = pmax(metastaticdiagnosisdate, crpcdate, na.rm = TRUE))

# NEW_LOT_N is derived: it restarts at 1 within each setting, ordered by start
# date, and is not the source LINENUMBER. That difference matters, and the
# window here reproduces the build's exactly.
lot <- src_("t_enh_prostate_lot") %>%
  dplyr::filter(linesetting %in% c("mHSPC", "mCRPC")) %>%
  dplyr::select(patientid, linesetting, startdate) %>%
  dbplyr::window_order(startdate) %>%
  dplyr::group_by(patientid, linesetting) %>%
  dplyr::mutate(new_lot_n = dplyr::row_number()) %>%
  dplyr::ungroup()

# ---- patient-level death date, straight from source ---------
# Rule RP1, with W1-W3 withdrawn, so DTHDT is the imputed value itself and this
# is the whole derivation rather than a first stage of it.
#
# Re-derived from the mortality source rather than read back from the ADS. The
# exclusion step below exists to check the build, so it cannot borrow the
# build's own answer for the date it filters on.
#
# TRY_CAST, never CAST. '2020-13' is seven characters long and is not a date;
# under ANSI mode a plain CAST aborts the query instead of reading NULL. Any
# other length falls to NULL by design; qc/08 sizes that.
#
# The CASE has no dplyr translation, so it goes in as raw sql() - the same
# route qc/08 takes for its TRY_CAST predicates. distinct() so a patient with
# more than one mortality row cannot multiply the rows of anything joining it.
dth <- src_("t_mortality_v2") %>%
  dplyr::transmute(patientid, dthdt = sql(
    "CASE WHEN LENGTH(dateofdeath) = 7 THEN TRY_CAST(CONCAT(dateofdeath, '-15') AS DATE)
          WHEN LENGTH(dateofdeath) = 4 THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
          ELSE NULL END")) %>%
  dplyr::distinct()

# The label of the new step, written once so all seven blocks carry the same
# string - the SQL repeats the literal because a CTE cannot hold one.
DEATH_STEP <-
  "index on or before death date - the death exclusion (headline drop)"

# One waterfall row: the distinct patients surviving a step.
src_step <- function(tb, cohort, step_no, step) {
  tb %>% dplyr::summarise(n_patients = dplyr::n_distinct(patientid)) %>%
    dplyr::transmute(cohort = !!cohort, step_no = !!step_no, step = !!step,
                     n_patients)
}
ads_step <- function(tb, cohort, step_no, step) {
  tb %>% dplyr::summarise(n_patients = dplyr::n_distinct(patid)) %>%
    dplyr::transmute(cohort = !!cohort, step_no = !!step_no, step = !!step,
                     n_patients)
}

# Cohort label for a line at a derived position (cohorts 3-7). A NULL
# condition lands on the ELSE, never on NULL - same as the SQL CASE.
lot_label <- function(tb) {
  tb %>% dplyr::mutate(cohort = dplyr::case_when(
    linesetting == "mHSPC" ~ "3 L1+ mHSPC",
    new_lot_n == 1L        ~ "4 L1+ mCRPC",
    new_lot_n == 2L        ~ "5 L2+ mCRPC",
    new_lot_n == 3L        ~ "6 L3+ mCRPC",
    TRUE                   ~ "7 L4+ mCRPC"))
}
lot_step <- function(tb, step_no, step) {
  tb %>% dplyr::group_by(cohort) %>%
    dplyr::summarise(n_patients = dplyr::n_distinct(patientid),
                     .groups = "drop") %>%
    dplyr::transmute(cohort, step_no = !!step_no, step = !!step, n_patients)
}

# Lines at an eligible position in an eligible setting.
lot_in_scope <- lot %>% dplyr::filter(
  (linesetting == "mHSPC" & new_lot_n == 1L) |
  (linesetting == "mCRPC" & new_lot_n >= 1L & new_lot_n <= 4L))

# ... whose start is inside the window and whose patient's own milestone is
# inside the window too - 'eligible at source' for cohorts 3-7, and the base
# of the death exclusion step below.
lot_elig <- lot_in_scope %>%
  dplyr::inner_join(ms %>% dplyr::select(patientid, mhspcdd, mcrpcdd),
                    by = "patientid") %>%
  dplyr::filter(startdate >= !!IDX_LO & startdate <= !!IDX_HI) %>%
  dplyr::filter(
    (linesetting == "mHSPC" & mhspcdd >= !!IDX_LO & mhspcdd <= !!IDX_HI) |
    (linesetting == "mCRPC" & mcrpcdd >= !!IDX_LO & mcrpcdd <= !!IDX_HI))

# ... and then surviving the death exclusion - the last thing the build's
# index_lot_cohort() does before writing the cohort. For cohorts 3-7 the index
# date is the LINE START date, which is where the per-cohort behaviour actually
# bites: a patient can pass this test at L1 and fail it at L3 when the later
# line starts after the death date.
#
# left_join, not inner: a patient with no mortality row must not be dropped.
# `is.na(dthdt)` keeps everyone with no usable death date, and the test is
# strict - a death ON the index date keeps the patient, because the ruling
# excludes an index AFTER the death, not on it.
lot_elig_alive <- lot_elig %>%
  dplyr::left_join(dth, by = "patientid") %>%
  dplyr::filter(is.na(dthdt) | startdate <= dthdt)

# ---- the waterfall ----------------------------------------------------------
steps <- list(

  # ---- shared starting point ----
  src_step(ms, "ALL", 0L, "patients in t_enh_prostate"),
  src_step(ms %>% dplyr::filter(!is.na(metastaticdiagnosisdate)),
           "ALL", 1L, "has a metastatic diagnosis date"),

  # ---- cohort 1, Overall mHSPC ----
  src_step(ms %>% dplyr::filter(!is.na(mhspcdd)),
           "1 Overall mHSPC", 2L, "has an mHSPC milestone (metdx or hspcdate)"),
  src_step(ms %>% dplyr::filter(mhspcdd >= !!IDX_LO & mhspcdd <= !!IDX_HI),
           "1 Overall mHSPC", 3L, "milestone within [2011-01-01, 2026-04-30]"),
  src_step(ms %>% dplyr::filter(mhspcdd >= !!IDX_LO & mhspcdd <= !!IDX_HI),
           "1 Overall mHSPC", 4L, "eligible at source"),
  # The death exclusion. For cohorts 1 and 2 the index date IS the milestone
  # date, so the test runs against mhspcdd / mcrpcdd.
  src_step(ms %>% dplyr::filter(mhspcdd >= !!IDX_LO & mhspcdd <= !!IDX_HI) %>%
             dplyr::left_join(dth, by = "patientid") %>%
             dplyr::filter(is.na(dthdt) | mhspcdd <= dthdt),
           "1 Overall mHSPC", 5L, DEATH_STEP),
  ads_step(ads %>% dplyr::filter(cohortn == 1L),
           "1 Overall mHSPC", 6L, "delivered in ADS"),

  # ---- cohort 2, Overall mCRPC ----
  src_step(ms %>% dplyr::filter(!is.na(mcrpcdd)),
           "2 Overall mCRPC", 2L, "has an mCRPC milestone (metdx or crpcdate)"),
  src_step(ms %>% dplyr::filter(mcrpcdd >= !!IDX_LO & mcrpcdd <= !!IDX_HI),
           "2 Overall mCRPC", 3L, "milestone within [2011-01-01, 2026-04-30]"),
  src_step(ms %>% dplyr::filter(mcrpcdd >= !!IDX_LO & mcrpcdd <= !!IDX_HI),
           "2 Overall mCRPC", 4L, "eligible at source"),
  src_step(ms %>% dplyr::filter(mcrpcdd >= !!IDX_LO & mcrpcdd <= !!IDX_HI) %>%
             dplyr::left_join(dth, by = "patientid") %>%
             dplyr::filter(is.na(dthdt) | mcrpcdd <= dthdt),
           "2 Overall mCRPC", 5L, DEATH_STEP),
  ads_step(ads %>% dplyr::filter(cohortn == 2L),
           "2 Overall mCRPC", 6L, "delivered in ADS"),

  # ---- cohorts 3-7, the line-of-therapy cohorts ----
  lot_step(lot_in_scope %>% lot_label(),
           2L, "has a line at this position in this setting"),
  lot_step(lot_in_scope %>%
             dplyr::filter(startdate >= !!IDX_LO & startdate <= !!IDX_HI) %>%
             lot_label(),
           3L, "line start within [2011-01-01, 2026-04-30]"),
  lot_step(lot_elig %>% lot_label(), 4L, "eligible at source"),
  # Read this drop per block, not in total - the same patient can be in the
  # 4 L1+ count and out of the 6 L3+ count.
  lot_step(lot_elig_alive %>% lot_label(), 5L, DEATH_STEP),
  ads %>% dplyr::filter(cohortn >= 3L & cohortn <= 7L) %>%
    dplyr::mutate(cohort = dplyr::case_when(
      cohortn == 3L ~ "3 L1+ mHSPC",
      cohortn == 4L ~ "4 L1+ mCRPC",
      cohortn == 5L ~ "5 L2+ mCRPC",
      cohortn == 6L ~ "6 L3+ mCRPC",
      TRUE          ~ "7 L4+ mCRPC")) %>%
    dplyr::group_by(cohort) %>%
    dplyr::summarise(n_patients = dplyr::n_distinct(patid),
                     .groups = "drop") %>%
    dplyr::transmute(cohort, step_no = 6L, step = "delivered in ADS",
                     n_patients)
)

waterfall <- Reduce(dplyr::union_all, steps) %>%
  dplyr::group_by(cohort) %>%
  dbplyr::window_order(step_no) %>%
  dplyr::mutate(prev_n = dplyr::lag(n_patients)) %>%
  dplyr::ungroup() %>%
  dplyr::transmute(cohort, step_no, step, n_patients,
                   pct_of_previous =
                     round(100 * n_patients / dplyr::na_if(prev_n, 0L), 1)) %>%
  dplyr::arrange(cohort, step_no)

message("writing qcr_attrition_r (", length(steps), " union branches)")
createInPersonalSchema(waterfall, "qcr_attrition_r", replace = TRUE)

# =============================================================================
# THE ONE GATE IN THIS FILE: source eligibility after the ruling must equal delivered
# =============================================================================
# There is exactly one filter between "eligible at source" and the ADS: the
# per-cohort death exclusion of the 2026-09-11 ruling. Before
# that ruling there was none, and this gate compared raw source eligibility
# against the delivered count. It cannot do that any more - the build now
# drops every row whose index date falls after the patient's death date, so
# the two sides would differ for all seven cohorts on a CORRECT build.
#
# So `expected` applies the same exclusion, against a death date derived from
# the mortality source by the same rule. The gate is then like for like again:
# PASS means the build's cohort membership is exactly source eligibility minus
# the death exclusion, and a difference once more means rows were lost or
# duplicated inside the build rather than removed on purpose.
expected <- Reduce(dplyr::union_all, list(
  ms %>% dplyr::filter(mhspcdd >= !!IDX_LO & mhspcdd <= !!IDX_HI) %>%
    dplyr::left_join(dth, by = "patientid") %>%
    dplyr::filter(is.na(dthdt) | mhspcdd <= dthdt) %>%
    dplyr::summarise(n_expected = dplyr::n_distinct(patientid)) %>%
    dplyr::transmute(cohortn = 1L, n_expected),
  ms %>% dplyr::filter(mcrpcdd >= !!IDX_LO & mcrpcdd <= !!IDX_HI) %>%
    dplyr::left_join(dth, by = "patientid") %>%
    dplyr::filter(is.na(dthdt) | mcrpcdd <= dthdt) %>%
    dplyr::summarise(n_expected = dplyr::n_distinct(patientid)) %>%
    dplyr::transmute(cohortn = 2L, n_expected),
  # lot_elig_alive, not lot_elig: the same exclusion the waterfall's step 5
  # applies, on the line start date.
  lot_elig_alive %>%
    dplyr::mutate(cohortn = dplyr::case_when(
      linesetting == "mHSPC" ~ 3L,
      new_lot_n == 1L        ~ 4L,
      new_lot_n == 2L        ~ 5L,
      new_lot_n == 3L        ~ 6L,
      TRUE                   ~ 7L)) %>%
    dplyr::group_by(cohortn) %>%
    dplyr::summarise(n_expected = dplyr::n_distinct(patientid),
                     .groups = "drop")))

delivered <- ads %>% dplyr::group_by(cohortn) %>%
  dplyr::summarise(n_delivered = dplyr::n_distinct(patid),
                   n_rows      = dplyr::n(), .groups = "drop")

# ---- MEMBERSHIP, not just cardinality --------------------------------------
# Counting was never enough and the file used to say so: a build that admits
# one wrong patient and drops one right one keeps every count identical and
# passed. These are the same three derivations as `expected` above, kept as
# MEMBER SETS rather than collapsed to a count, so the two sides can be
# compared by identity.
#
# Both directions are needed. An anti-join one way finds patients the source
# says belong and the build did not deliver; the other way finds patients the
# build delivered that the source does not admit. Either alone can read zero
# while the other does not.
#
# Still inside Databricks - anti_join renders as a SQL anti-join, nothing is
# fetched, and the result is a count per cohort rather than a patient list,
# because the list belongs in a follow-up query and not in a gate row.
expected_members <- dplyr::union_all(
  dplyr::union_all(
    ms %>% dplyr::filter(mhspcdd >= !!IDX_LO & mhspcdd <= !!IDX_HI) %>%
      dplyr::left_join(dth, by = "patientid") %>%
      dplyr::filter(is.na(dthdt) | mhspcdd <= dthdt) %>%
      dplyr::transmute(patientid, cohortn = 1L),
    ms %>% dplyr::filter(mcrpcdd >= !!IDX_LO & mcrpcdd <= !!IDX_HI) %>%
      dplyr::left_join(dth, by = "patientid") %>%
      dplyr::filter(is.na(dthdt) | mcrpcdd <= dthdt) %>%
      dplyr::transmute(patientid, cohortn = 2L)),
  lot_elig_alive %>%
    dplyr::transmute(patientid, cohortn = dplyr::case_when(
      linesetting == "mHSPC" ~ 3L,
      new_lot_n == 1L        ~ 4L,
      new_lot_n == 2L        ~ 5L,
      new_lot_n == 3L        ~ 6L,
      TRUE                   ~ 7L))) %>%
  dplyr::distinct()

delivered_members <- ads %>%
  dplyr::transmute(patientid = patid, cohortn) %>%
  dplyr::distinct()

missing_from_build <- expected_members %>%
  dplyr::anti_join(delivered_members, by = c("patientid", "cohortn")) %>%
  dplyr::group_by(cohortn) %>%
  dplyr::summarise(n_expected_not_delivered = dplyr::n(), .groups = "drop")

extra_in_build <- delivered_members %>%
  dplyr::anti_join(expected_members, by = c("patientid", "cohortn")) %>%
  dplyr::group_by(cohortn) %>%
  dplyr::summarise(n_delivered_not_expected = dplyr::n(), .groups = "drop")

# full_join merges the key: cohortn reads COALESCE(expected, delivered), so a
# cohort present on one side only still shows its number. The SQL mirror
# coalesces the same two keys by hand, so both sides agree row for row.
gate <- dplyr::full_join(expected, delivered, by = "cohortn") %>%
  dplyr::left_join(missing_from_build, by = "cohortn") %>%
  dplyr::left_join(extra_in_build,     by = "cohortn") %>%
  dplyr::transmute(
    cohortn, n_expected, n_delivered, n_rows,
    diff_patients = n_delivered - n_expected,
    extra_rows_beyond_one_per_patient = n_rows - n_delivered,
    # A cohort with no discrepancy produces no row from either anti-join, so
    # the left joins give NULL and coalesce makes that the zero it means.
    n_expected_not_delivered = coalesce(n_expected_not_delivered, 0L),
    n_delivered_not_expected = coalesce(n_delivered_not_expected, 0L),
    status = dplyr::case_when(
      n_delivered == n_expected & n_rows == n_delivered &
        coalesce(n_expected_not_delivered, 0L) == 0L &
        coalesce(n_delivered_not_expected, 0L) == 0L ~ "PASS",
      TRUE ~ "FAIL")) %>%
  dplyr::arrange(cohortn)

message("writing qcr_attrition_gate_r")
createInPersonalSchema(gate, "qcr_attrition_gate_r", replace = TRUE)

if (exists("qcr_stamp")) qcr_stamp("qc04_cohort_attrition")

message("Results written. Read in the SQL editor:")
for (t in c("qcr_attrition_r", "qcr_attrition_gate_r"))
  message("  SELECT * FROM ", personal_schema, ".", t)

# FAIL-CLOSED, added 2026-09-13. This program wrote PASS/FAIL into a table and
# then exited zero whatever it found, so an attrition failure was a row someone
# had to notice rather than a run that stopped. That is the wrong way round for
# the only check that rebuilds cohort membership from source.
#
# IT NOW PROVES MEMBERSHIP, not just cardinality. Until 2026-09-13 the gate
# compared counts only, so a build that admitted one wrong patient and
# excluded one right one passed with the cardinality intact. The two anti-join
# columns close that: n_expected_not_delivered counts patients the source
# admits and the build did not deliver, n_delivered_not_expected the reverse.
# Both must read zero. What it still cannot see is a cohort absent
# from BOTH sides emits no row from the full join at all, so a treated cohort
# that vanished entirely is silently absent rather than failing - which is why
# the row count is asserted against the seven the contract requires.
v <- tryCatch(DBI::dbGetQuery(con, paste0(
       "SELECT COUNT(*) AS n_rows, ",
       "SUM(CASE WHEN status <> 'PASS' THEN 1 ELSE 0 END) AS n_bad ",
       "FROM ", personal_schema, ".qcr_attrition_gate_r")),
     error = function(e) NULL)
if (is.null(v)) {
  message("verdict fetch failed - read qcr_attrition_gate_r before trusting the run")
  quit(status = 2L, save = "no")
}
if (is.na(v$n_rows[1]) || v$n_rows[1] != 7L) {
  message("FAIL - the gate has ", v$n_rows[1], " rows, not 7. A cohort is missing ",
          "from both the source rebuild and the delivered table.")
  quit(status = 1L, save = "no")
}
if (is.na(v$n_bad[1]) || v$n_bad[1] > 0L) {
  message("FAIL - ", v$n_bad[1], " cohort(s) differ from the source rebuild. ",
          "See qcr_attrition_gate_r.")
  quit(status = 1L, save = "no")
}
message("PASS - all seven cohorts match a rebuild from source, on counts.")
