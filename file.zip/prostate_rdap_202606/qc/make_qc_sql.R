# =============================================================================
# Generator for the per-column QC SQL
# =============================================================================
# Writes two files, both derived from validation/00_column_contract.csv so that
# neither can drift from the delivered column set:
#
#   qc/01_variable_profile.sql       null rate and cardinality, by cohort
#   qc/02_code_label_agreement.sql   every label/code pair must be 1:1
#
#   Rscript qc/make_qc_sql.R
#
# validation/02_offline_build_check.R regenerates both and fails on any
# difference, exactly as it does for the null sweep, so a hand edit here cannot
# survive a run of the harness.
#
# WHY BY COHORT. The null sweep asks whether a column is empty across the whole
# table. It cannot see a column that is full overall and empty in one cohort.
# MCRPCDD and the LOT*_MCRPC family are meant to be sparse in the mHSPC
# cohorts; ECOG and the labs are not. Only a per-cohort view tells the two
# apart.
#
# WHY COUNT(DISTINCT) HERE. The sweep uses MIN/MAX because 190 distinct counts
# make Spark scan once per aggregate, and a release gate should not pay that.
# This runs once per cut on half a million rows, where the cost is minutes and
# the level count is what a reviewer actually wants.
# =============================================================================

CONTRACT <- "validation/00_column_contract.csv"
# Both outputs honour a pre-set value so the harness can redirect them. Without
# that, a "check" would rewrite the very files it is checking and could never
# report drift honestly.
if (!exists("OUT_PROFILE")) OUT_PROFILE <- "qc/01_variable_profile.sql"
if (!exists("OUT_PAIRS"))   OUT_PAIRS   <- "qc/02_code_label_agreement.sql"

cols <- utils::read.csv(CONTRACT, stringsAsFactors = FALSE)
cols <- cols[order(cols$ordinal), ]
nm   <- tolower(cols$column)

stopifnot(length(nm) > 0L, !anyDuplicated(nm),
          all(grepl("^[a-z][a-z0-9_]*$", nm)))

# -----------------------------------------------------------------------------
# Label / code pairs
# -----------------------------------------------------------------------------
# Discovered from the contract rather than typed out, because a typed list of
# 25 pairs is one more thing that drifts. Two naming rules are in play and the
# spec uses both:
#
#   rule 1  <label>N          RACE   -> RACEN,   COHORTU -> COHORTUN
#   rule 2  <stem>N_<setting> LOT1CAT_MCRPC -> LOT1CATN_MCRPC,
#                             LOTNGR1_MHSPC -> LOTNGR1N_MHSPC
#
# Rule 2 exists because the setting suffix stays last, so the N is infixed. A
# generator that only knew rule 1 would silently skip the six LOT category
# pairs and both LOTNGR1 pairs - the ones most likely to be miscoded, since
# they are generated per line and per setting.
pair_for <- function(label) {
  cand <- character()
  cand <- c(cand, paste0(label, "n"))                                  # rule 1
  m <- regmatches(label, regexec("^(.*)(_(?:mhspc|mcrpc))$", label))[[1]]
  if (length(m) == 3L) cand <- c(cand, paste0(m[2], "n", m[3]))        # rule 2
  hit <- cand[cand %in% nm]
  if (length(hit)) hit[1] else NA_character_
}

labels <- nm[!is.na(vapply(nm, pair_for, character(1)))]
codes  <- vapply(labels, pair_for, character(1))
pairs  <- data.frame(label = labels, code = unname(codes),
                     stringsAsFactors = FALSE)

# A code column that no rule paired is either a new naming convention or a
# genuine miss, and both need a human. Reported rather than swallowed.
EXPECTED_PAIRS <- 25L
if (nrow(pairs) != EXPECTED_PAIRS) {
  stop("label/code pair discovery found ", nrow(pairs), " pairs, expected ",
       EXPECTED_PAIRS, ".\nFound: ",
       paste(pairs$label, pairs$code, sep = "/", collapse = ", "),
       "\nIf the contract legitimately changed, update EXPECTED_PAIRS in ",
       "qc/make_qc_sql.R and say why in the release note.", call. = FALSE)
}

# -----------------------------------------------------------------------------
# 01 - per-cohort profile
# -----------------------------------------------------------------------------
agg <- sprintf("         COUNT(%1$s) n_%1$s, COUNT(DISTINCT %1$s) d_%1$s", nm)
agg <- c("         COUNT(*) n_rows,", paste0(agg, c(rep(",", length(agg) - 1L), "")))

stack_rows <- sprintf("      '%1$s', n_%1$s, d_%1$s", nm)
stack_rows <- paste0(stack_rows, c(rep(",", length(stack_rows) - 1L), ""))

profile <- c(
"-- =============================================================================",
"-- QC 01. PER-COHORT NULL RATE AND CARDINALITY - ALL COLUMNS",
"-- =============================================================================",
"-- GENERATED FILE. Do not edit by hand.",
"--   source: validation/00_column_contract.csv",
"--   generator: qc/make_qc_sql.R",
"--   enforced: validation/02_offline_build_check.R regenerates and diffs this",
"--",
"-- Substitute ${catalog} / ${schema} / ${ads} before running. They are TEXT",
"-- substitutions, not :param markers - a parameter marker binds a value, not an",
"-- object name.",
"--",
sprintf("-- Covers all %d contract columns across all 7 cohorts.", length(nm)),
"--",
"-- WHAT THIS ANSWERS THAT THE NULL SWEEP CANNOT",
"--   The sweep asks whether a column is empty or constant across the WHOLE",
"--   table. This asks it per cohort. A column that is fully populated overall",
"--   but empty in one cohort passes the sweep and is still a defect - unless",
"--   the biology explains it.",
"--",
"-- HOW TO READ IT - this file has NO pass/fail, on purpose",
"--   * pct_null near 100 in the mHSPC cohorts (1, 3) for MCRPCDD, TTCRPC,",
"--     PSADIAG_CRPC and the LOT*_MCRPC family is EXPECTED. A patient who has",
"--     not become castration-resistant has no mCRPC dates and no mCRPC lines.",
"--   * pct_null differing sharply between cohorts 4-7 for the SAME variable is",
"--     NOT expected. Those cohorts differ only in line number.",
"--   * n_distinct BELOW the level count in the spec's Values list means a",
"--     category never occurs; ABOVE it means an unmapped source value leaked",
"--     through. Both are worth a look; neither is automatically wrong.",
"--   * n_distinct = 1 on a clinical variable is the shape the sweep would have",
"--     caught only if it were constant across every cohort at once.",
"-- =============================================================================",
"",
"USE CATALOG ${catalog};",
"",
"WITH agg AS (",
"  SELECT",
"         cohort,",
agg,
"  FROM ${schema}.${ads}",
"  GROUP BY cohort",
"),",
"prof AS (",
"  SELECT cohort, n_rows,",
sprintf("    stack(%d,", length(nm)),
stack_rows,
"    ) AS (col, nonnull, n_distinct)",
"  FROM agg",
")",
"SELECT col,",
"       cohort,",
"       n_rows,",
"       nonnull,",
"       n_rows - nonnull                                     AS n_null,",
"       ROUND(100.0 * (n_rows - nonnull) / NULLIF(n_rows, 0), 2) AS pct_null,",
"       n_distinct",
"FROM   prof",
"ORDER  BY col, cohort;")

writeLines(profile, OUT_PROFILE)

# -----------------------------------------------------------------------------
# 02 - label/code agreement
# -----------------------------------------------------------------------------
# Each pair contributes one branch. The check is deliberately two-directional:
# one code carrying two labels and one label carrying two codes are different
# defects, and a single COUNT(DISTINCT) in one direction sees only one of them.
#
# NULL handling: a row where both sides are null is not a disagreement - it is
# a variable that does not apply to that patient, which the profile above
# reports properly. A row where exactly one side is null is a disagreement,
# counted here as n_half_null - the shape a case_when residual produces when
# the label branch and the code branch stop matching.
pair_sql <- sprintf(paste0(
"SELECT '%1$s' AS label_col, '%2$s' AS code_col,\n",
"       COUNT(*)                                                     AS n_rows_either_side,\n",
"       COUNT(DISTINCT CONCAT_WS('|', CAST(%1$s AS STRING), CAST(%2$s AS STRING))) AS n_distinct_pairs,\n",
"       COUNT(DISTINCT CAST(%1$s AS STRING))                         AS n_labels,\n",
"       COUNT(DISTINCT CAST(%2$s AS STRING))                         AS n_codes,\n",
"       SUM(CASE WHEN (%1$s IS NULL) <> (%2$s IS NULL) THEN 1 ELSE 0 END) AS n_half_null\n",
"FROM   ${schema}.${ads}\n",
"WHERE  %1$s IS NOT NULL OR %2$s IS NOT NULL"), pairs$label, pairs$code)

pair_block <- paste0(pair_sql, c(rep("\nUNION ALL\n", nrow(pairs) - 1L), "\n"))

agreement <- c(
"-- =============================================================================",
"-- QC 02. LABEL / CODE AGREEMENT - EVERY PAIR, BOTH DIRECTIONS",
"-- =============================================================================",
"-- GENERATED FILE. Do not edit by hand.",
"--   source: validation/00_column_contract.csv (pairs discovered, not typed)",
"--   generator: qc/make_qc_sql.R",
"--   enforced: validation/02_offline_build_check.R regenerates and diffs this",
"--",
"-- Substitute ${catalog} / ${schema} / ${ads} before running.",
"--",
sprintf("-- %d pairs. Every RWD spec in this family defines coded variables twice -", nrow(pairs)),
"-- once as a label and once as a number - in two separate case_when blocks that",
"-- nothing forces to agree. When a category is added, renamed or reordered in",
"-- one block and not the other, the two silently diverge and every downstream",
"-- frequency table splits. This is the single highest-yield mechanical check in",
"-- the QC pack, and it needs no expected values: the invariant is structural.",
"--",
"-- Two near-misses of exactly this kind are already on record. One changed",
"-- ECOG from seven categories to six, which required ECOG and ECOGN to move",
"-- together. The other unified the residual codes on 99, which touched",
"-- AGEGR1N, REGION1N, PRACTICN and COHORTUN but NOT their labels - correct, but",
"-- only because the labels have no residual to unify. Nothing checked either.",
"--",
"-- HOW TO READ IT",
"--   status = 'PASS'          the mapping is 1:1 in both directions",
"--   status = 'FAIL 1:many'   one label carries more than one code, or one code",
"--                            carries more than one label. n_distinct_pairs",
"--                            exceeds both n_labels and n_codes when it is",
"--                            many:many. Drill in with the template at the",
"--                            bottom of this file.",
"--   status = 'FAIL half-null' one side is populated where the other is not.",
"--                            A label with no code, or a code with no label.",
"--",
"-- Rows where BOTH sides are null are excluded - that is a variable that does",
"-- not apply to the patient, not a disagreement. The per-cohort profile in",
"-- qc/01_variable_profile.sql is where absence is judged.",
"-- =============================================================================",
"",
"USE CATALOG ${catalog};",
"",
"WITH pairs AS (",
pair_block,
")",
"SELECT label_col, code_col, n_rows_either_side, n_labels, n_codes,",
"       n_distinct_pairs, n_half_null,",
"       CASE WHEN n_half_null > 0                            THEN 'FAIL half-null'",
"            WHEN n_distinct_pairs > GREATEST(n_labels, n_codes) THEN 'FAIL many:many'",
"            WHEN n_distinct_pairs > n_labels                THEN 'FAIL label 1:many'",
"            WHEN n_distinct_pairs > n_codes                 THEN 'FAIL code 1:many'",
"            ELSE 'PASS' END AS status",
"FROM   pairs",
"ORDER  BY CASE WHEN n_half_null > 0 THEN 0",
"               WHEN n_distinct_pairs > LEAST(n_labels, n_codes) THEN 1",
"               ELSE 2 END,",
"          label_col;",
"",
"",
"-- =============================================================================",
"-- DRILL-IN TEMPLATE - run this for any pair that did not read PASS",
"-- =============================================================================",
"-- Replace <label> and <code> with the failing pair. It lists every distinct",
"-- combination with its row count, so the offending category is visible",
"-- immediately rather than inferred from counts.",
"--",
"-- SELECT <label>, <code>, COUNT(*) AS n_rows,",
"--        COUNT(DISTINCT patid) AS n_pts,",
"--        CONCAT_WS(',', SORT_ARRAY(COLLECT_SET(cohort))) AS cohorts",
"-- FROM   ${schema}.${ads}",
"-- WHERE  <label> IS NOT NULL OR <code> IS NOT NULL",
"-- GROUP  BY <label>, <code>",
"-- ORDER  BY <code>, <label>;")

writeLines(agreement, OUT_PAIRS)

cat("wrote ", OUT_PROFILE, " - ", length(nm), " columns x 7 cohorts\n",
    "wrote ", OUT_PAIRS,   " - ", nrow(pairs), " label/code pairs\n", sep = "")
