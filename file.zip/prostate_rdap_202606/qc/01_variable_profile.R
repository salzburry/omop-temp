# =============================================================================
# QC 01. PER-COHORT NULL RATE AND CARDINALITY IN R - NOTHING FETCHED
# =============================================================================
#   Rscript qc/01_variable_profile.R              (after a build, repo root)
#
# Same numbers as the generated qc/01_variable_profile.sql. All 190 contract
# columns, profiled per cohort in one pass. Both steps run inside Databricks.
# Nothing comes back to this session.
#
#   SELECT * FROM <schema>.qcr_profile_r ORDER BY col, cohortn
#
# Per column and cohort: row count, non-null count, null count and rate,
# distinct count - the same columns the SQL emits. Read it for columns that
# are emptier or flatter than the spec suggests.
# =============================================================================

if (!exists("con")) {
  message("no open connection - sourcing validation/00_connect.R")
  source("validation/00_connect.R")
}
stopifnot(exists("con"), exists("personal_schema"), exists("output_table"))

ads <- dplyr::tbl(con, dbplyr::in_schema(personal_schema, output_table))

contract <- utils::read.csv("validation/00_column_contract.csv",
                            stringsAsFactors = FALSE)
nm <- tolower(contract$column[order(contract$ordinal)])

# ---- pass 1: one scan, wide, grouped by cohort ------------------------------
agg <- c(list(n_rows = rlang::quo(dplyr::n())),
         stats::setNames(lapply(nm, function(cl) {
           s <- rlang::sym(cl)
           rlang::quo(sum(dplyr::case_when(!is.na(!!s) ~ 1L, TRUE ~ 0L), na.rm = TRUE))
         }), paste0("nn_", nm)),
         stats::setNames(lapply(nm, function(cl) {
           s <- rlang::sym(cl); rlang::quo(dplyr::n_distinct(!!s))
         }), paste0("nd_", nm)))

message("writing qcr_profile_wide_r (one grouped pass over the ADS)")
createInPersonalSchema(
  ads %>% dplyr::group_by(cohortn, cohort) %>% dplyr::summarise(!!!agg),
  "qcr_profile_wide_r", replace = TRUE)

# ---- pass 2: unpivot off the seven-row wide table ---------------------------
wide <- dplyr::tbl(con, dbplyr::in_schema(personal_schema, "qcr_profile_wide_r"))

one_col <- function(cl) {
  nn <- rlang::sym(paste0("nn_", cl))
  nd <- rlang::sym(paste0("nd_", cl))
  wide %>% dplyr::transmute(
    col = !!cl, cohortn, cohort, n_rows, nonnull = !!nn,
    n_null   = n_rows - !!nn,
    pct_null = round(100.0 * (n_rows - !!nn) / dplyr::na_if(n_rows, 0L), 2),
    n_distinct = !!nd)
}

message("writing qcr_profile_r (190 columns x 7 cohorts)")
createInPersonalSchema(Reduce(dplyr::union_all, lapply(nm, one_col)),
                       "qcr_profile_r", replace = TRUE)

if (exists("qcr_stamp")) qcr_stamp("qc01_variable_profile")

message("DONE - nothing was fetched. Read in the SQL editor:")
message("  SELECT * FROM ", personal_schema, ".qcr_profile_r ORDER BY col, cohortn")
