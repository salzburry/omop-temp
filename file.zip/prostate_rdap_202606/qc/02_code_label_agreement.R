# =============================================================================
# QC 02. LABEL / CODE AGREEMENT IN R - NOTHING FETCHED
# =============================================================================
#   Rscript qc/02_code_label_agreement.R          (after a build, repo root)
#
# Same pairs as the generated qc/02_code_label_agreement.sql. Every label
# column with an N sibling is listed with the code values it carries, and a
# second table gives the SQL's automatic verdict per pair - half-null,
# many:many, or 1:many in either direction all read FAIL. Runs inside
# Databricks. Nothing comes back to this session.
#
#   SELECT * FROM <schema>.qcr_pairs_gate_r ORDER BY status, pair
#   SELECT * FROM <schema>.qcr_pairs_r ORDER BY pair, label, code
#
# The pairs come from the contract, not a typed list, under the two naming
# rules the spec uses: RACE -> RACEN, and LOT1CAT_MCRPC -> LOT1CATN_MCRPC
# (the N goes before the setting suffix). The count is pinned at 25; a
# different count means the contract changed and somebody must look.
# =============================================================================

if (!exists("con")) {
  message("no open connection - sourcing validation/00_connect.R")
  source("validation/00_connect.R")
}
stopifnot(exists("con"), exists("personal_schema"), exists("output_table"))

ads <- dplyr::tbl(con, dbplyr::in_schema(personal_schema, output_table))

contract <- utils::read.csv("validation/00_column_contract.csv",
                            stringsAsFactors = FALSE)
nm <- tolower(contract$column[order(contract$ordinal)])

pair_for <- function(label) {
  cand <- paste0(label, "n")
  m <- regmatches(label, regexec("^(.*)(_(?:mhspc|mcrpc))$", label))[[1]]
  if (length(m) == 3L) cand <- c(cand, paste0(m[2], "n", m[3]))
  hit <- cand[cand %in% nm]
  if (length(hit)) hit[1] else NA_character_
}

labels <- nm[!is.na(vapply(nm, pair_for, character(1)))]
codes  <- vapply(labels, pair_for, character(1))
stopifnot(length(labels) == 25L)

one_pair <- function(lab, code) {
  L <- rlang::sym(lab); C <- rlang::sym(code)
  ads %>% dplyr::group_by(label = !!L, code = !!C) %>%
    dplyr::summarise(n = dplyr::n(), .groups = "drop") %>%
    dplyr::mutate(pair = !!paste0(lab, " / ", code)) %>%
    dplyr::select(pair, label, code, n)
}

message("writing qcr_pairs_r (25 pairs, every observed combination)")
createInPersonalSchema(
  Reduce(dplyr::union_all, Map(one_pair, labels, codes)),
  "qcr_pairs_r", replace = TRUE)

# The verdict off the combos just written: more combinations than labels
# means a label maps to two codes, and vice versa. The 25 pair names are the
# spine, so a wholly-null pair still gets its row (all zeros, PASS) instead
# of vanishing. Same tests and statuses as the SQL.
combos <- dplyr::tbl(con, dbplyr::in_schema(personal_schema, "qcr_pairs_r"))

message("writing qcr_pairs_gate_r (one verdict per pair, always 25 rows)")
createInPersonalSchema(
  dbplyr::copy_inline(con, data.frame(pair = paste0(labels, " / ", codes),
                                      stringsAsFactors = FALSE)) %>%
    dplyr::left_join(
      combos %>%
        dplyr::filter(!(is.na(label) & is.na(code))) %>%
        dplyr::group_by(pair) %>%
        dplyr::summarise(
          n_rows_either_side = sum(n, na.rm = TRUE),
          n_distinct_pairs   = dplyr::n(),
          n_labels           = dplyr::n_distinct(label),
          n_codes            = dplyr::n_distinct(code),
          n_half_null        = sum(dplyr::case_when(
                                 is.na(label) != is.na(code) ~ n, TRUE ~ 0L),
                                 na.rm = TRUE),
          .groups = "drop"),
      by = "pair") %>%
    dplyr::mutate(
      n_rows_either_side = coalesce(n_rows_either_side, 0),
      n_distinct_pairs   = coalesce(n_distinct_pairs, 0L),
      n_labels           = coalesce(n_labels, 0L),
      n_codes            = coalesce(n_codes, 0L),
      n_half_null        = coalesce(n_half_null, 0)) %>%
    dplyr::mutate(status = dplyr::case_when(
      n_half_null > 0                            ~ "FAIL half-null",
      n_distinct_pairs > pmax(n_labels, n_codes) ~ "FAIL many:many",
      n_distinct_pairs > n_labels                ~ "FAIL label 1:many",
      n_distinct_pairs > n_codes                 ~ "FAIL code 1:many",
      TRUE                                       ~ "PASS")),
  "qcr_pairs_gate_r", replace = TRUE)

if (exists("qcr_stamp")) qcr_stamp("qc02_code_label_agreement")

message("DONE - nothing was fetched. Read in the SQL editor:")
message("  SELECT * FROM ", personal_schema, ".qcr_pairs_gate_r ORDER BY status, pair")
message("  SELECT * FROM ", personal_schema, ".qcr_pairs_r ORDER BY pair, label, code")
