-- =============================================================================
-- QC 09. VITALS VALUE DOMAINS - what the  and  rulings cost
-- =============================================================================
-- Substitute ${catalog} / ${schema} / ${ads} / ${src} before running.
--
-- Two rulings of 2026-08-08 moved in opposite directions; both need a number
-- rather than an assumption:
--
--   BP tightened to the spec. 5B.ClinChars r186 requires "a positive
--        integer" and its Unknown clause repeats it - "0 or NOT A POSITIVE
--        INTEGER or is null then = Unknown". A positive but fractional
--        reading is therefore Unknown, not Present. K09a counts what the
--        integrality test moves.
--
--   Weight/height loosened to the spec. r194-197 qualifies a record on
--        "where TESTRESULTCLEANED is not null" and nothing else - no sign
--        test. Non-positive values therefore reach WEIGHT and HEIGHT. K09b
--        counts them, and K09c shows what they do downstream.
--
-- Read K09b first. If it returns zero, the ruling is value-neutral and
-- the division guards on BMI/BSA are purely defensive. If it returns rows,
-- those patients carry a weight or height that is not a measurement, and the
-- owner should see the number before this ships.
-- =============================================================================

USE CATALOG ${catalog};

-- =============================================================================
-- K09a.  - BP readings that are positive but not integral
-- =============================================================================
-- These rows are Unknown rather than Present and lose their BPSYS/BPDIA, as
-- the spec's Unknown clause instructs. Blood pressure is recorded in whole
-- millimetres of mercury in practice, so zero is the expected answer; review
-- a non-zero answer before anyone reads a BP frequency table.
--
-- The test is on the cast value: '120.0' casts to 120.0, which equals its own
-- ROUND, so a decimal point in the text does not by itself disqualify a row.
SELECT
    LOWER(test)                                                  AS arm,
    COUNT(*)                                                     AS n_rows,
    COUNT(DISTINCT patientid)                                    AS n_patients,
    SUM(CASE WHEN TRY_CAST(testresult AS DOUBLE) IS NULL
             THEN 1 ELSE 0 END)                                  AS n_uncastable,
    SUM(CASE WHEN TRY_CAST(testresult AS DOUBLE) <= 0
             THEN 1 ELSE 0 END)                                  AS n_non_positive,
    SUM(CASE WHEN TRY_CAST(testresult AS DOUBLE) > 0
              AND TRY_CAST(testresult AS DOUBLE)
                  <> ROUND(TRY_CAST(testresult AS DOUBLE), 0)
             THEN 1 ELSE 0 END)                                  AS n_positive_non_integral
FROM   ${src}.t_vitals_2026m06
WHERE  LOWER(test) IN ('systolic blood pressure', 'diastolic blood pressure')
GROUP  BY 1
ORDER  BY 1;


-- =============================================================================
-- K09b.  - height and weight records that are not positive
-- =============================================================================
-- Read n_zero and n_negative. Those are the values the spec admits: the spec's
-- clause is "TESTRESULTCLEANED is not null" and says nothing about sign.
-- n_rows is every height/weight record, not only the non-positive ones - it
-- is the denominator, not the finding.
SELECT
    LOWER(test)                                                  AS measure,
    testunitscleaned                                             AS unit,
    COUNT(*)                                                     AS n_rows,
    COUNT(DISTINCT patientid)                                    AS n_patients,
    SUM(CASE WHEN testresultcleaned = 0 THEN 1 ELSE 0 END)       AS n_zero,
    SUM(CASE WHEN testresultcleaned < 0 THEN 1 ELSE 0 END)       AS n_negative,
    MIN(testresultcleaned)                                       AS min_val,
    MAX(testresultcleaned)                                       AS max_val
FROM   ${src}.t_vitals_2026m06
WHERE  (LOWER(test) = 'body height' AND testunitscleaned = 'cm')
   OR  (LOWER(test) = 'body weight' AND testunitscleaned = 'kg')
GROUP  BY 1, 2
ORDER  BY 1, 2;


-- =============================================================================
-- K09c.  - what reaches the delivered table, and what BMI/BSA did with it
-- =============================================================================
-- The division guards on BMI and BSA are not part of the ruling: that
-- ruling is about which vitals records qualify. The guards exist because the
-- spec's own BMI formula divides by HEIGHT, and a zero height is a
-- DIVIDE_BY_ZERO under ANSI - a build failure, not a value. Under legacy
-- semantics the same expression yields NULL and BMIGR1 reads 'Missing', so the
-- guard delivers exactly what the spec's formula delivers and only removes the
-- crash. Same reasoning as the PSABL guard ruled separately.
--
-- This confirms that claim on real rows rather than asserting it.
SELECT
    CASE WHEN height IS NULL AND weight IS NULL THEN '1 neither recorded'
         WHEN height IS NULL                    THEN '2 weight only'
         WHEN weight IS NULL                    THEN '3 height only'
         WHEN height <= 0 OR weight <= 0        THEN '4 NON-POSITIVE - admitted by the specification'
         ELSE                                        '5 both positive' END AS shape,
    COUNT(*)                                                     AS n_rows,
    COUNT(DISTINCT patid)                                        AS n_patients,
    SUM(CASE WHEN bmi IS NULL THEN 1 ELSE 0 END)                 AS n_bmi_null,
    SUM(CASE WHEN bsa IS NULL THEN 1 ELSE 0 END)                 AS n_bsa_null,
    SUM(CASE WHEN bmigr1 = 'Missing' THEN 1 ELSE 0 END)          AS n_bmigr1_missing,
    -- NaN survives IS NULL and poisons any downstream mean, so it is counted
    -- separately. A non-zero figure here means a guard was missed.
    SUM(CASE WHEN ISNAN(bmi) THEN 1 ELSE 0 END)                  AS n_bmi_nan,
    SUM(CASE WHEN ISNAN(bsa) THEN 1 ELSE 0 END)                  AS n_bsa_nan,
    ROUND(MIN(height), 1)                                        AS min_height,
    ROUND(MIN(weight), 1)                                        AS min_weight
FROM   ${schema}.${ads}
GROUP  BY 1
ORDER  BY 1;


-- =============================================================================
-- K09d. Plausibility, report-only - not a ruling, and no code enforces it
-- =============================================================================
-- Nothing in the spec or the build bounds these beyond the conditions above, so
-- an extreme but positive value propagates into WEIGHT, HEIGHT, BMI and BSA
-- unchallenged. This is recorded as a known gap rather than fixed, because a
-- plausibility range is a clinical judgement nobody has made yet. The ranges
-- below are deliberately wide - they are meant to catch unit errors and data
-- entry slips, not to define a normal adult.
SELECT
    'height outside 50-250 cm'   AS flag,
    COUNT(*) AS n_rows, COUNT(DISTINCT patid) AS n_patients,
    ROUND(MIN(height), 1) AS min_val, ROUND(MAX(height), 1) AS max_val
FROM ${schema}.${ads} WHERE height IS NOT NULL AND (height < 50 OR height > 250)
UNION ALL
SELECT 'weight outside 20-400 kg',
    COUNT(*), COUNT(DISTINCT patid), ROUND(MIN(weight), 1), ROUND(MAX(weight), 1)
FROM ${schema}.${ads} WHERE weight IS NOT NULL AND (weight < 20 OR weight > 400)
UNION ALL
SELECT 'bmi outside 10-100',
    COUNT(*), COUNT(DISTINCT patid), ROUND(MIN(bmi), 1), ROUND(MAX(bmi), 1)
FROM ${schema}.${ads} WHERE bmi IS NOT NULL AND (bmi < 10 OR bmi > 100)
UNION ALL
SELECT 'systolic outside 50-300 mmHg',
    COUNT(*), COUNT(DISTINCT patid), ROUND(MIN(bpsys), 1), ROUND(MAX(bpsys), 1)
FROM ${schema}.${ads} WHERE bpsys IS NOT NULL AND (bpsys < 50 OR bpsys > 300)
UNION ALL
SELECT 'diastolic outside 20-200 mmHg',
    COUNT(*), COUNT(DISTINCT patid), ROUND(MIN(bpdia), 1), ROUND(MAX(bpdia), 1)
FROM ${schema}.${ads} WHERE bpdia IS NOT NULL AND (bpdia < 20 OR bpdia > 200)
UNION ALL
SELECT 'diastolic >= systolic',
    COUNT(*), COUNT(DISTINCT patid), NULL, NULL
FROM ${schema}.${ads} WHERE bpsys IS NOT NULL AND bpdia IS NOT NULL AND bpdia >= bpsys;
