-- =============================================================================
-- QC 03. CROSS-VARIABLE CONSISTENCY
-- =============================================================================
-- Substitute ${catalog} / ${schema} / ${ads} before running.
--
-- Each rule recomputes a delivered value from other delivered values, then
-- counts the rows where the two disagree. It reads no source tables, so anyone
-- holding only the extract can run it.
--
-- This catches what the release gates cannot: a value that is legal on its own
-- but wrong next to its inputs. A join that doubles a patient's rows leaves
-- every column legal. So does an AGE built from a birthyear a later join
-- overwrote.
--
-- GATE    must be 0. Arithmetic or definitional, so any count is a defect.
-- REVIEW  report only. Record the number; look again if it moves between cuts.
--
-- Rule numbers are stable. Append, never renumber, so packs stay comparable.
-- RP1-RP4 and W1-W3 are the 2026-09-11 ruling's four rules and the three
-- behaviours they withdraw, defined in docs/VARIABLES.md section 3.
-- =============================================================================

USE CATALOG ${catalog};

WITH ads AS (SELECT * FROM ${schema}.${ads}),

-- The ten analytes reshaped long so the flag/value/date coherence rules are
-- written once instead of ten times. LABPLA's date column is LABPLAVDT, not
-- LABPLADT - the spec names it that way and the build reproduces it verbatim,
-- so it is spelled out here rather than derived from a pattern.
lab_long AS (
  SELECT patid, cohort, indexdt, stack(10,
    'LABNEU', labneu, CAST(labneuv AS DOUBLE), CAST(labneudt  AS DATE),
    'LABPLA', labpla, CAST(labplav AS DOUBLE), CAST(labplavdt AS DATE),
    'LABHEM', labhem, CAST(labhemv AS DOUBLE), CAST(labhemdt  AS DATE),
    'LABCRE', labcre, CAST(labcrev AS DOUBLE), CAST(labcredt  AS DATE),
    'LABBIL', labbil, CAST(labbilv AS DOUBLE), CAST(labbildt  AS DATE),
    'LABAST', labast, CAST(labastv AS DOUBLE), CAST(labastdt  AS DATE),
    'LABALT', labalt, CAST(labaltv AS DOUBLE), CAST(labaltdt  AS DATE),
    'LABALP', labalp, CAST(labalpv AS DOUBLE), CAST(labalpdt  AS DATE),
    'LABALB', labalb, CAST(labalbv AS DOUBLE), CAST(labalbdt  AS DATE),
    'LABLYM', lablym, CAST(lablymv AS DOUBLE), CAST(lablymdt  AS DATE)
  ) AS (analyte, flag, val, dt)
  FROM ads
),

rules AS (

-- --- grain -------------------------------------------------------------------
-- One row per patient per cohort. A fan-out here silently multiplies every
-- count in every downstream table, and leaves all 190 columns individually
-- legal, so nothing else in the QC pack would notice.
SELECT 'R01' id, 'GATE' severity,
       'one row per (patid, cohort) - a case-variant fan-out shows here  (Q72)' rule,
       COUNT(*) n_applicable,
       COUNT(*) - COUNT(DISTINCT CONCAT_WS('|', patid, cohort)) n_violations
FROM ads
UNION ALL
SELECT 'R02', 'GATE', 'indexdt is identical within (patid, cohort)',
       COUNT(*), SUM(CASE WHEN n_dt > 1 THEN 1 ELSE 0 END)
FROM (SELECT patid, cohort, COUNT(DISTINCT indexdt) n_dt
      FROM ads GROUP BY patid, cohort) g

-- --- dates and derived years -------------------------------------------------
UNION ALL
SELECT 'R03', 'GATE', 'indexyr = YEAR(indexdt)',
       COUNT(*), SUM(CASE WHEN indexyr <> YEAR(indexdt) THEN 1 ELSE 0 END)
FROM ads WHERE indexdt IS NOT NULL AND indexyr IS NOT NULL
UNION ALL
SELECT 'R04', 'GATE', 'indexdt lies within [minindex, maxindex]',
       COUNT(*), SUM(CASE WHEN indexdt < minindex OR indexdt > maxindex
                          THEN 1 ELSE 0 END)
FROM ads WHERE indexdt IS NOT NULL
UNION ALL
-- IS DISTINCT FROM, not <>. With `<>` a populated date carrying a NULL year
-- yields NULL, which is not TRUE, so the row is silently not counted - the
-- exact defect this rule exists to catch.
SELECT 'R05', 'GATE', 'mcrpcddyr / mhspcddyr / mpcddyr / inityr each = YEAR(their date)  (Q09)',
       COUNT(*),
       SUM(CASE WHEN (mcrpcdd IS NOT NULL AND mcrpcddyr IS DISTINCT FROM YEAR(mcrpcdd))
                  OR (mhspcdd IS NOT NULL AND mhspcddyr IS DISTINCT FROM YEAR(mhspcdd))
                  OR (mpcdd   IS NOT NULL AND mpcddyr   IS DISTINCT FROM YEAR(mpcdd))
                  OR (init    IS NOT NULL AND inityr    IS DISTINCT FROM YEAR(init))
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- Both milestones are GREATEST(metastatic diagnosis, <milestone>), so neither
-- can precede the metastatic diagnosis date it was built from.
SELECT 'R06', 'GATE', 'mcrpcdd >= mpcdd and mhspcdd >= mpcdd',
       COUNT(*),
       SUM(CASE WHEN (mcrpcdd IS NOT NULL AND mpcdd IS NOT NULL AND mcrpcdd < mpcdd)
                  OR (mhspcdd IS NOT NULL AND mpcdd IS NOT NULL AND mhspcdd < mpcdd)
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- Castration resistance follows hormone sensitivity. A patient reaching mCRPC
-- before mHSPC is a source-data ordering problem, not a build problem, which
-- is why this is REVIEW and not GATE.
SELECT 'R07', 'REVIEW', 'mcrpcdd >= mhspcdd where both are present',
       SUM(CASE WHEN mcrpcdd IS NOT NULL AND mhspcdd IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN mcrpcdd IS NOT NULL AND mhspcdd IS NOT NULL
                 AND mcrpcdd < mhspcdd THEN 1 ELSE 0 END)
FROM ads

-- --- demographics ------------------------------------------------------------
UNION ALL
SELECT 'R08', 'GATE', 'age = indexyr - birthyear',
       COUNT(*), SUM(CASE WHEN age <> indexyr - birthyear THEN 1 ELSE 0 END)
FROM ads WHERE age IS NOT NULL AND birthyear IS NOT NULL AND indexyr IS NOT NULL
UNION ALL
SELECT 'R09', 'REVIEW', 'age is between 18 and 120',
       COUNT(*), SUM(CASE WHEN age < 18 OR age > 120 THEN 1 ELSE 0 END)
FROM ads WHERE age IS NOT NULL
UNION ALL
-- Prostate cancer. A female or unknown-sex record would indicate a cohort
-- definition reaching the wrong patients; there is no sex column in the ADS,
-- so the closest available check is that every patient is in exactly one
-- birth-year band consistent with AGEGR1.
SELECT 'R10', 'GATE', 'agegr1 band contains age; null age is Unknown (Q74)',
       COUNT(*),
       -- A null AGE must band as 'Unknown' (Q74). The old WHERE dropped null
       -- ages entirely, so a null age wrongly banded 0-18 passed unseen.
       SUM(CASE WHEN (age IS NULL AND agegr1 <> 'Unknown')
                  OR (agegr1 = '0-18'   AND NOT (age BETWEEN 0  AND 18))
                  OR (agegr1 = '19-34'  AND NOT (age BETWEEN 19 AND 34))
                  OR (agegr1 = '35-49'  AND NOT (age BETWEEN 35 AND 49))
                  OR (agegr1 = '50-64'  AND NOT (age BETWEEN 50 AND 64))
                  OR (agegr1 = '65-74'  AND NOT (age BETWEEN 65 AND 74))
                  OR (agegr1 = '75-84'  AND NOT (age BETWEEN 75 AND 84))
                  OR (agegr1 = '>=85'   AND NOT (age >= 85))
                  -- 'Unknown' is the approved label for a null or negative age
                  -- (Q74), so it is a violation only when AGE >= 0 - a real
                  -- band failure. Counting every 'Unknown' beside a non-null
                  -- age would fail a build doing exactly what Q74 approves.
                  OR (agegr1 = 'Unknown' AND age >= 0)
                THEN 1 ELSE 0 END)
FROM ads WHERE agegr1 IS NOT NULL

-- --- follow-up and death -----------------------------------------------------
UNION ALL
SELECT 'R11', 'GATE', 'dthfl = 1 exactly when dthdt is present',
       COUNT(*),
       SUM(CASE WHEN (dthfl = 1) <> (dthdt IS NOT NULL) THEN 1 ELSE 0 END)
FROM ads WHERE dthfl IS NOT NULL
UNION ALL
-- The index floor on FUED is GONE, so this is no longer an invariant. Spec
-- errata E1 read "If INDEXDT<FUED then FUED=INDEXDT", which is inverted, and
-- the build used to floor FUED at the index date instead (register Q45); the
-- 2026-09-11 ruling (Q82) defines FUED as COALESCE(dthdt,
-- fu_enddt_preliminary) with no floor, so gating the old direction would FAIL
-- a correct build. REVIEW, and a sizing of what the ruling opened.
-- A count here can only be a patient with NO death date: where a death date
-- exists FUED IS that date, and the per-cohort exclusion dropped any index
-- falling after it, so fued >= indexdt still holds for every death-dated
-- patient. Without one, FUED is a last activity date that nothing ties to the
-- index.
-- The checked population is unchanged from the gate form, so the number stays
-- comparable with earlier packs. Release gate V46 sizes the same rows.
SELECT 'R12', 'REVIEW', 'fued < indexdt - the index floor is gone; Q45 reversed by Q82, sized here and by V46, unruled: Q83',
       COUNT(*), SUM(CASE WHEN fued < indexdt THEN 1 ELSE 0 END)
FROM ads WHERE fued IS NOT NULL AND indexdt IS NOT NULL
UNION ALL
SELECT 'R13', 'GATE', 'fudur = DATEDIFF(fued, indexdt) + 1',
       COUNT(*),
       SUM(CASE WHEN fudur <> DATEDIFF(fued, indexdt) + 1 THEN 1 ELSE 0 END)
FROM ads WHERE fudur IS NOT NULL AND fued IS NOT NULL AND indexdt IS NOT NULL
UNION ALL
-- Still a correct definitional check, and kept as one. Note that under Q82 it
-- can only be satisfied as 0 = 0: where a death date exists FUED IS that date,
-- so dthdt < fued is unreachable and the expected value is always 0. It
-- therefore no longer proves the flag is a CONSTANT 0 - R58 below is the live
-- proof of that.
SELECT 'R14', 'GATE', 'dth_before_fued = 1 exactly when dthdt < fued',
       COUNT(*),
       SUM(CASE WHEN dth_before_fued <>
                     CASE WHEN dthdt IS NOT NULL AND fued IS NOT NULL AND dthdt < fued
                          THEN 1 ELSE 0 END
                THEN 1 ELSE 0 END)
FROM ads WHERE dth_before_fued IS NOT NULL
UNION ALL
-- Register Q57. DTHFUFL is computed from the preliminary dates, and its only
-- null rule is "no death date". The spec defines Values "0 = No; 1 = Yes"
-- with "else 0" - there is no third state, so a NULL for any other reason is
-- a defect. Keep this rule asserting the spec text, not the build code: the
-- offline check verifies that generated SQL matches the contract, and it
-- cannot know what a hand-written rule is supposed to assert.
SELECT 'R15', 'GATE',
       'dthfufl is NULL exactly when there is no death date  (Q57)',
       COUNT(*),
       SUM(CASE WHEN (dthfufl IS NULL) <> (death_dt_preliminary IS NULL)
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
SELECT 'R15b', 'GATE', 'dthfufl domain is {0,1} - the spec Values list  (Q57)',
       SUM(CASE WHEN dthfufl IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN dthfufl IS NOT NULL AND dthfufl NOT IN (0, 1) THEN 1 ELSE 0 END)
FROM ads
UNION ALL
SELECT 'R16', 'GATE',
       'dthfufl = 1 exactly when DATEDIFF(death_prelim, fu_end_prelim) <= 120  (Q57)',
       SUM(CASE WHEN dthfufl IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN dthfufl IS NOT NULL
                 AND dthfufl <> CASE WHEN DATEDIFF(death_dt_preliminary,
                                                   fu_enddt_preliminary) <= 120
                                     THEN 1 ELSE 0 END
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
SELECT 'R17', 'GATE', 'id3mosfu = 1 exactly when DATEDIFF(maxindex, indexdt) >= 91',
       COUNT(*),
       SUM(CASE WHEN id3mosfu <> CASE WHEN DATEDIFF(maxindex, indexdt) >= 91
                                      THEN 1 ELSE 0 END
                THEN 1 ELSE 0 END)
FROM ads WHERE id3mosfu IS NOT NULL AND indexdt IS NOT NULL AND maxindex IS NOT NULL

-- --- outcomes ----------------------------------------------------------------
UNION ALL
-- OS is recomputed exactly as 6.Outcomes defines it, including the
-- DTH_BEFORE_FUED exclusion - a dead branch under Q82, but still in the spec
-- and still in the build. A 1e-6 tolerance covers double rounding only.
SELECT 'R18', 'GATE', 'os = (DATEDIFF(event_dt, indexdt)+1)/30.4375, from DTHDT not DEATH_DT_prelim  (Q47)',
       SUM(CASE WHEN os IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN os IS NOT NULL
                 AND ABS(os - (DATEDIFF(CASE WHEN dthfl = 1 THEN dthdt ELSE fued END,
                                        indexdt) + 1) / 30.4375) > 1e-6
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- The old population - rows where DTH_BEFORE_FUED = 0 - is now every row,
-- because Q82 makes the flag a constant 0, and "OS is populated on EVERY row"
-- is false: the censored branch of OS measures to FUED, so OS is NULL exactly
-- where FUED is NULL, which Q82 now permits. Re-scoped to the rows OS has an
-- endpoint for - a death date, or a follow-up end - so the rule still asserts
-- something true and still catches a dropped OS.
SELECT 'R18b', 'GATE',
       'os is POPULATED wherever a death date or a follow-up end exists  (Q82)',
       SUM(CASE WHEN dthfl = 1 OR fued IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN (dthfl = 1 OR fued IS NOT NULL) AND os IS NULL
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- The old form - "OS is NULL whenever dth_before_fued = 1" - now has a zero
-- denominator under Q82 and so passes without proving anything. What is worth
-- asserting is the emptiness itself: the flag cannot be 1 at all, so a nonzero
-- count here is a loud failure rather than a silent pass. Checked over the
-- whole table, so the denominator is never zero. R58 is the null-safe
-- companion: this rule catches a 1, R58 catches a 1 or a NULL.
SELECT 'R19', 'GATE', 'dth_before_fued = 1 population is EMPTY by construction  (Q82)',
       COUNT(*), SUM(CASE WHEN dth_before_fued = 1 THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- Cohort applicability. The spec restricts three outcome blocks by cohort, and
-- each restriction is a place a case_when branch can be dropped without any
-- individual value looking wrong.
SELECT 'R20', 'GATE', 'eligpfs / pfsfl / pfsdt / pfs are all NULL in cohorts 1-2',
       SUM(CASE WHEN cohortn IN (1, 2) THEN 1 ELSE 0 END),
       SUM(CASE WHEN cohortn IN (1, 2)
                 AND (eligpfs IS NOT NULL OR pfsfl IS NOT NULL
                      OR pfsdt IS NOT NULL OR pfs IS NOT NULL)
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
SELECT 'R21', 'GATE', 'ttnt is NULL in cohorts 1, 2 and 7',
       SUM(CASE WHEN cohortn IN (1, 2, 7) THEN 1 ELSE 0 END),
       SUM(CASE WHEN cohortn IN (1, 2, 7) AND ttnt IS NOT NULL THEN 1 ELSE 0 END)
FROM ads
UNION ALL
SELECT 'R22', 'GATE', 'vis120 is NULL in cohorts 1-2',
       SUM(CASE WHEN cohortn IN (1, 2) THEN 1 ELSE 0 END),
       SUM(CASE WHEN cohortn IN (1, 2) AND vis120 IS NOT NULL THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- PFSDT is the event date only; it is never set to a censoring date. So it may
-- be null while PFS is populated, but it must never precede index.
SELECT 'R23', 'GATE', 'pfsdt >= indexdt where present',
       SUM(CASE WHEN pfsdt IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN pfsdt IS NOT NULL AND pfsdt < indexdt THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- COALESCE before comparing: within eligpfs = 1 the spec leaves no branch that
-- returns a NULL flag, so a NULL pfsfl is itself a defect. Written as `(pfsfl
-- = 1) <> ...` the comparison yields NULL and the row escapes counting.
SELECT 'R24', 'GATE', 'pfsfl = 1 exactly when pfsdt is present, within eligpfs = 1',
       SUM(CASE WHEN eligpfs = 1 THEN 1 ELSE 0 END),
       SUM(CASE WHEN eligpfs = 1
                 AND COALESCE(pfsfl = 1, FALSE) IS DISTINCT FROM (pfsdt IS NOT NULL)
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
SELECT 'R24b', 'GATE', 'pfsfl is never NULL within eligpfs = 1',
       SUM(CASE WHEN eligpfs = 1 THEN 1 ELSE 0 END),
       SUM(CASE WHEN eligpfs = 1 AND pfsfl IS NULL THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- Register Q59: the PSABL > 0 guard. This rule recomputes PSA50 including the
-- guard, so it confirms the guard is doing what Q59 concluded rather than
-- assuming it. R27 reports how many rows the guard touches on each cut.
SELECT 'R25', 'GATE', 'psa50_6mo = Y exactly when psabl > 0 and decline >= 50%  (Q59; missing input -> N per Q35)',
       COUNT(*),
       SUM(CASE WHEN psa50_6mo <>
                     CASE WHEN psa6mo IS NOT NULL AND psa_index IS NOT NULL
                           AND psa_index > 0
                           AND (psa6mo - psa_index) / psa_index <= -0.5
                          THEN 'Y' ELSE 'N' END
                THEN 1 ELSE 0 END)
FROM ads WHERE psa50_6mo IS NOT NULL
UNION ALL
SELECT 'R26', 'GATE', 'psa50_12mo = Y exactly when psabl > 0 and decline >= 50%  (Q59; missing input -> N per Q35)',
       COUNT(*),
       SUM(CASE WHEN psa50_12mo <>
                     CASE WHEN psa12mo IS NOT NULL AND psa_index IS NOT NULL
                           AND psa_index > 0
                           AND (psa12mo - psa_index) / psa_index <= -0.5
                          THEN 'Y' ELSE 'N' END
                THEN 1 ELSE 0 END)
FROM ads WHERE psa50_12mo IS NOT NULL
UNION ALL
SELECT 'R27', 'REVIEW', 'psa_index (PSABL) <= 0 - the rows the Q59 guard forces to N',
       SUM(CASE WHEN psa_index IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN psa_index <= 0 THEN 1 ELSE 0 END)
FROM ads

-- --- vitals ------------------------------------------------------------------
UNION ALL
SELECT 'R28', 'GATE', 'bmi = weight / (height/100)^2',
       SUM(CASE WHEN bmi IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN bmi IS NOT NULL AND weight IS NOT NULL AND height IS NOT NULL
                 AND ABS(bmi - weight / POWER(height / 100, 2)) > 1e-6
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- Q68 admits non-positive height and weight readings. Keep this test in step
-- with the production BMI guard, which is `height <> 0` and nothing else -
-- asserting `height > 0 AND weight > 0` here would fail every row with a
-- negative reading that production accepts.
SELECT 'R29', 'GATE', 'bmi is present exactly when height and weight are known and height is not zero  (Q68)',
       COUNT(*),
       SUM(CASE WHEN (bmi IS NOT NULL) <>
                     (weight IS NOT NULL AND height IS NOT NULL AND height <> 0)
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- The spec bands every BMI below 18.5 as Underweight, with no lower bound, so
-- a negative BMI bands as Underweight, never 'Missing'. 'Missing' means BMI
-- could not be computed, and nothing else; an extra `bmi > 0` test on the
-- band would break both statements.
SELECT 'R56', 'GATE', 'every non-null bmi below 18.5 is banded Underweight  (Q68)',
       SUM(CASE WHEN bmi IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN bmi IS NOT NULL AND bmi < 18.5
                 AND (bmigr1 <> 'Underweight' OR bmigr1n <> 1)
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
SELECT 'R30', 'GATE', 'bp = Present exactly when bpsys, bpdia and bpdt are all present',
       COUNT(*),
       SUM(CASE WHEN (bp = 'Present') <>
                     (bpsys IS NOT NULL AND bpdia IS NOT NULL AND bpdt IS NOT NULL)
                THEN 1 ELSE 0 END)
FROM ads WHERE bp IS NOT NULL
UNION ALL
SELECT 'R31', 'GATE', 'bpdt <= indexdt  (BP is a PRE_INT baseline variable)',
       SUM(CASE WHEN bpdt IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN bpdt IS NOT NULL AND bpdt > indexdt THEN 1 ELSE 0 END)
FROM ads
UNION ALL
SELECT 'R32', 'REVIEW', 'bpsys > bpdia where both present',
       SUM(CASE WHEN bpsys IS NOT NULL AND bpdia IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN bpsys IS NOT NULL AND bpdia IS NOT NULL
                 AND bpsys <= bpdia THEN 1 ELSE 0 END)
FROM ads

-- --- labs --------------------------------------------------------------------
UNION ALL
SELECT 'R33', 'GATE', 'lab flag = Present exactly when its value is populated',
       COUNT(*),
       SUM(CASE WHEN (flag = 'Present') <> (val IS NOT NULL) THEN 1 ELSE 0 END)
FROM lab_long WHERE flag IS NOT NULL
UNION ALL
SELECT 'R34', 'GATE', 'lab value and lab date are populated together  (Q12 - LAB*DT is a DATE, not a value)',
       COUNT(*),
       SUM(CASE WHEN (val IS NOT NULL) <> (dt IS NOT NULL) THEN 1 ELSE 0 END)
FROM lab_long
UNION ALL
-- Register Q58 moved only the Missing test; the value window is unchanged. A
-- lab date after index means the wrong filter was removed.
SELECT 'R35', 'GATE', 'lab date <= indexdt  (Q58 moved the Missing test, NOT the value)',
       SUM(CASE WHEN dt IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN dt IS NOT NULL AND dt > indexdt THEN 1 ELSE 0 END)
FROM lab_long
UNION ALL
SELECT 'R36', 'GATE', 'lab value > 0 where Present  (the spec Present criterion)',
       SUM(CASE WHEN val IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN val IS NOT NULL AND val <= 0 THEN 1 ELSE 0 END)
FROM lab_long
UNION ALL
SELECT 'R37', 'GATE', 'lab flag is one of Present / Unknown / Missing',
       COUNT(*),
       SUM(CASE WHEN flag NOT IN ('Present', 'Unknown', 'Missing') THEN 1 ELSE 0 END)
FROM lab_long WHERE flag IS NOT NULL

-- --- lines of therapy --------------------------------------------------------
UNION ALL
-- Covers both settings, not the four mCRPC lines alone. LOTnED feeds VIS120
-- and the follow-up end, so a reversed pair is not cosmetic.
SELECT 'R38', 'GATE', 'lotNsd <= lotNed within every line, both settings',
       COUNT(*),
       SUM(CASE WHEN (lot1sd_mcrpc IS NOT NULL AND lot1ed_mcrpc IS NOT NULL AND lot1sd_mcrpc > lot1ed_mcrpc)
                  OR (lot2sd_mcrpc IS NOT NULL AND lot2ed_mcrpc IS NOT NULL AND lot2sd_mcrpc > lot2ed_mcrpc)
                  OR (lot3sd_mcrpc IS NOT NULL AND lot3ed_mcrpc IS NOT NULL AND lot3sd_mcrpc > lot3ed_mcrpc)
                  OR (lot4sd_mcrpc IS NOT NULL AND lot4ed_mcrpc IS NOT NULL AND lot4sd_mcrpc > lot4ed_mcrpc)
                  OR (lot1sd_mhspc IS NOT NULL AND lot1ed_mhspc IS NOT NULL AND lot1sd_mhspc > lot1ed_mhspc)
                  OR (lot2sd_mhspc IS NOT NULL AND lot2ed_mhspc IS NOT NULL AND lot2sd_mhspc > lot2ed_mhspc)
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- Strictly increasing, so an equal pair is a violation too: two lines sharing
-- a start date is exactly what NEW_LOT_N is non-deterministic on. Gate B1
-- stops that at source; this rule proves it independently from the extract.
SELECT 'R39', 'GATE', 'line start dates strictly increasing by line number, both settings',
       COUNT(*),
       SUM(CASE WHEN (lot2sd_mcrpc IS NOT NULL AND lot1sd_mcrpc IS NOT NULL AND lot2sd_mcrpc <= lot1sd_mcrpc)
                  OR (lot3sd_mcrpc IS NOT NULL AND lot2sd_mcrpc IS NOT NULL AND lot3sd_mcrpc <= lot2sd_mcrpc)
                  OR (lot4sd_mcrpc IS NOT NULL AND lot3sd_mcrpc IS NOT NULL AND lot4sd_mcrpc <= lot3sd_mcrpc)
                  OR (lot2sd_mhspc IS NOT NULL AND lot1sd_mhspc IS NOT NULL AND lot2sd_mhspc <= lot1sd_mhspc)
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- Line existence is tested on the start date, not the name. Q73 accepts a
-- line that exists with a null LINENAME, so testing the name columns would
-- read an unnamed line 1 followed by a named line 2 as a gap and fail
-- behaviour the register approves. LOTnSD is present whenever the line is.
SELECT 'R40', 'GATE', 'no gaps: line N exists implies line N-1 exists (mCRPC)  (Q73)',
       COUNT(*),
       SUM(CASE WHEN (lot2sd_mcrpc IS NOT NULL AND lot1sd_mcrpc IS NULL)
                  OR (lot3sd_mcrpc IS NOT NULL AND lot2sd_mcrpc IS NULL)
                  OR (lot4sd_mcrpc IS NOT NULL AND lot3sd_mcrpc IS NULL)
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
SELECT 'R41', 'GATE', 'mHSPC line 2 exists implies line 1 exists  (Q73)',
       COUNT(*),
       SUM(CASE WHEN lot2sd_mhspc IS NOT NULL AND lot1sd_mhspc IS NULL THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- LOTN counts all mCRPC lines, so it is at least the number the ADS displays
-- (the ADS shows only the first four). Equality is not required and would be
-- wrong for a patient with five or more lines.
-- Line existence is the START DATE, not the name: under register Q73 a line
-- can exist with a NULL LINENAME, and counting names would let such a line
-- drop out of the displayed total and mask a real undercount. R40/R41 use the
-- same proxy for the same reason.
-- Equality, not >=: the ADS displays the first LEAST(lotn, 4) lines, so a
-- displayed count below that means a delivered line was dropped, and >= let
-- exactly that case pass.
SELECT 'R42', 'GATE', 'displayed mCRPC lines = LEAST(lotn, 4)  (Q73)',
       SUM(CASE WHEN lotn IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN lotn IS NOT NULL AND
                     (CASE WHEN lot1sd_mcrpc IS NOT NULL THEN 1 ELSE 0 END +
                      CASE WHEN lot2sd_mcrpc IS NOT NULL THEN 1 ELSE 0 END +
                      CASE WHEN lot3sd_mcrpc IS NOT NULL THEN 1 ELSE 0 END +
                      CASE WHEN lot4sd_mcrpc IS NOT NULL THEN 1 ELSE 0 END)
                     <> LEAST(lotn, 4)
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
SELECT 'R43', 'GATE', 'displayed mHSPC lines = LEAST(lotn_mhspc, 2)  (Q06, Q73)',
       SUM(CASE WHEN lotn_mhspc IS NOT NULL THEN 1 ELSE 0 END),
       SUM(CASE WHEN lotn_mhspc IS NOT NULL AND
                     (CASE WHEN lot1sd_mhspc IS NOT NULL THEN 1 ELSE 0 END +
                      CASE WHEN lot2sd_mhspc IS NOT NULL THEN 1 ELSE 0 END)
                     <> LEAST(lotn_mhspc, 2)
                THEN 1 ELSE 0 END)
FROM ads

-- --- cohort identity ---------------------------------------------------------
UNION ALL
-- Register Q11/Q19 and errata E12. Cohorts 3-7 are line-of-therapy cohorts, so
-- every patient in them is treated by construction. An "Untreated" label there
-- means the treated-status join lost rows.
SELECT 'R44', 'GATE', 'cohorts 3-7 are all Treated  (Q11/Q19, errata E12)',
       SUM(CASE WHEN cohortn BETWEEN 3 AND 7 THEN 1 ELSE 0 END),
       SUM(CASE WHEN cohortn BETWEEN 3 AND 7 AND cohortu NOT LIKE 'Treated%'
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
SELECT 'R45', 'GATE', 'cohortu setting matches the cohort setting',
       COUNT(*),
       SUM(CASE WHEN (cohortn IN (1, 3) AND cohortu NOT LIKE '%mHSPC')
                  OR (cohortn IN (2, 4, 5, 6, 7) AND cohortu NOT LIKE '%mCRPC')
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
SELECT 'R46', 'GATE', 'cohortn is 1..7 and every one of the seven is present',
       COUNT(*),
       SUM(CASE WHEN cohortn NOT BETWEEN 1 AND 7 THEN 1 ELSE 0 END)
         + CASE WHEN COUNT(DISTINCT cohortn) <> 7 THEN 1 ELSE 0 END
FROM ads
UNION ALL
-- The 99 residual sentinels (register Q50). Only one of the five is documented
-- as unreachable, so only that one is a gate. The other four are reachable by
-- design and their counts are informative, not defects:
--   AGEGR1N   99 needs a null or negative AGE, i.e. a missing birthyear
--   REGION1N  99 needs a state present but in no census region
--   PRACTICN  99 needs a patient with no practice record at all
--   STAGEN    99 needs no GROUPSTAGE recorded - the ordinary "not documented"
--             case, and the exact partner of STAGE = 'Unknown/not documented'
-- Gating all five would fail the run on STAGEN for every patient without a
-- recorded stage.
SELECT 'R47', 'GATE', 'cohortun = 99 is never reached  (Q50 - documented unreachable)',
       COUNT(*), SUM(CASE WHEN cohortun = 99 THEN 1 ELSE 0 END)
FROM ads
UNION ALL
SELECT 'R47b', 'REVIEW', 'reachable 99 sentinels: agegr1n / region1n / practicn / stagen  (Q50, Q31, Q32)',
       COUNT(*),
       SUM(CASE WHEN agegr1n = 99 OR region1n = 99 OR practicn = 99 OR stagen = 99
                THEN 1 ELSE 0 END)
FROM ads

-- --- ECOG --------------------------------------------------------------------
UNION ALL
-- Register Q23: six categories, ECOGN 1..6, with unknown and missing combined
-- into a single level. A seven-category split (unknown and missing separated)
-- is the regression this rule exists to catch.
SELECT 'R48', 'GATE', 'ecog is one of 0,1,2,3,4,Unknown/Missing and ecogn is 1..6  (Q23, Q71)',
       COUNT(*),
       SUM(CASE WHEN ecog NOT IN ('0','1','2','3','4','Unknown/Missing')
                  OR ecogn NOT BETWEEN 1 AND 6
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
SELECT 'R49', 'GATE', 'ecog is never NULL - absence is the Unknown/Missing level  (Q23)',
       COUNT(*), SUM(CASE WHEN ecog IS NULL OR ecogn IS NULL THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- Q73: a line that exists with a null LINENAME lands in the same place as a
-- line that does not exist - null name, category 17 "No treatment". In cohorts
-- 3-7 the index line exists by construction, so its own category can never
-- legitimately be "No treatment". Any count here is the gap Q73 describes.
SELECT 'R55', 'REVIEW', 'treated cohorts: the index line is not "No treatment"  (Q73)',
       SUM(CASE WHEN cohortn BETWEEN 3 AND 7 THEN 1 ELSE 0 END),
       SUM(CASE WHEN (cohortn = 3 AND lot1cat_mhspc = 'No treatment')
                  OR (cohortn = 4 AND lot1cat_mcrpc = 'No treatment')
                  OR (cohortn = 5 AND lot2cat_mcrpc = 'No treatment')
                  OR (cohortn = 6 AND lot3cat_mcrpc = 'No treatment')
                  OR (cohortn = 7 AND lot4cat_mcrpc = 'No treatment')
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- Register Q33 ruling: dates derived from source records are not clamped to
-- MAXINDEX. A visit, lab or scan recorded after the index window closes is
-- real data and is kept. REVIEW, not GATE - a non-zero count is expected and
-- is a property of the source, not a defect. It is reported so the delivered
-- consequence of the ruling is visible rather than assumed.
SELECT 'R51', 'REVIEW', 'delivered dates after MAXINDEX - accepted, not clamped  (Q33)',
       COUNT(*),
       SUM(CASE WHEN fued        > maxindex
                  OR dthdt       > maxindex
                  OR psma_scandt > maxindex
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- Q36: a line with no end date scores VIS120 = 0, not NULL - the same
-- missing-input-becomes-a-negative-result convention as Q35. R52 checks the
-- domain; R52b proves the no-end-date case directly, on the index line for
-- each treated cohort.
SELECT 'R52', 'GATE', 'vis120 is 0 or 1, never NULL, in the treated cohorts  (Q36)',
       SUM(CASE WHEN cohortn BETWEEN 3 AND 7 THEN 1 ELSE 0 END),
       SUM(CASE WHEN cohortn BETWEEN 3 AND 7
                 AND (vis120 IS NULL OR vis120 NOT IN (0, 1))
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
SELECT 'R52b', 'GATE', 'no index-line end date implies vis120 = 0  (Q36)',
       SUM(CASE WHEN (cohortn = 3 AND lot1ed_mhspc IS NULL)
                  OR (cohortn = 4 AND lot1ed_mcrpc IS NULL)
                  OR (cohortn = 5 AND lot2ed_mcrpc IS NULL)
                  OR (cohortn = 6 AND lot3ed_mcrpc IS NULL)
                  OR (cohortn = 7 AND lot4ed_mcrpc IS NULL)
                THEN 1 ELSE 0 END),
       SUM(CASE WHEN ((cohortn = 3 AND lot1ed_mhspc IS NULL)
                   OR (cohortn = 4 AND lot1ed_mcrpc IS NULL)
                   OR (cohortn = 5 AND lot2ed_mcrpc IS NULL)
                   OR (cohortn = 6 AND lot3ed_mcrpc IS NULL)
                   OR (cohortn = 7 AND lot4ed_mcrpc IS NULL))
                 AND vis120 IS DISTINCT FROM 0
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- Register Q48 ruling: the delivered COHORT labels are the exact strings
-- chosen for the study. A label that drifts breaks every downstream table
-- keyed on it, and nothing else in the pack pins the literal text.
SELECT 'R53', 'GATE', 'cohort labels are exactly the seven agreed strings  (Q48)',
       COUNT(*),
       SUM(CASE WHEN cohort NOT IN
                 ('Overall mHSPC', 'Overall mCRPC',
                  'L1+ treated mHSPC', 'L1+ treated mCRPC',
                  'L2+ treated mCRPC', 'L3+ treated mCRPC',
                  'L4+ treated mCRPC')
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- Register Q69 ruling: the unit filter compares trimmed values, so the spec's
-- ' g/dL' and the real 'g/dL' select the same rows. If the trim were lost,
-- LABHEM would read Missing for the entire study and LABHEMV would be wholly
-- NULL - the distinctive shape this rule catches.
SELECT 'R54', 'GATE', 'labhem is not uniformly Missing - the unit filter matches  (Q69)',
       COUNT(*),
       CASE WHEN SUM(CASE WHEN labhem = 'Present' THEN 1 ELSE 0 END) = 0
            THEN COUNT(*) ELSE 0 END
FROM ads

-- --- biomarkers --------------------------------------------------------------
UNION ALL
-- Register Q29/Q30: HRR and BRCA share one winning date per patient by
-- construction, because the date is chosen over the unfiltered biomarker table
-- before either gene set is applied. No biomarker date is delivered, so the
-- shared-date design is not observable from the ADS and cannot be asserted
-- here; a null-together comparison would also be vacuous, since
-- biomarker_status ends in a case_when TRUE branch and neither column is ever
-- NULL. R50 and R50b test what the extract can prove.
SELECT 'R50', 'GATE', 'hrr_index and brca_index are never NULL  (a dropped join would show here)',
       COUNT(*),
       SUM(CASE WHEN hrr_index IS NULL OR brca_index IS NULL
                  OR hrr_indexn IS NULL OR brca_indexn IS NULL
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- The observable consequence of the shared date: BRCA1/2 sit inside
-- every HRR panel option, so a BRCA-positive patient must be HRR-positive.
-- This mirrors output-validation V2c deliberately - V2c gates the release, this
-- one lets a partner holding only the extract reach the same verdict.
SELECT 'R50b', 'GATE', 'brca positive implies hrr positive  (Q29/Q37, mirrors V2c)',
       SUM(CASE WHEN brca_index = 'Positive' THEN 1 ELSE 0 END),
       SUM(CASE WHEN brca_index = 'Positive' AND hrr_index IS DISTINCT FROM 'Positive'
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- R57: sizes the Q74 approval - a negative AGE delivered as 'Unknown'. R10
-- deliberately passes these rows, so this is the count that shows how many
-- rows the approval actually covers.
SELECT 'R57', 'REVIEW', 'negative age delivered as Unknown  (Q74 sizing)',
       COUNT(*),
       SUM(CASE WHEN age < 0 AND agegr1 = 'Unknown' THEN 1 ELSE 0 END)
FROM ads WHERE age IS NOT NULL

-- --- the 2026-09-11 follow-up ruling  (register Q82) -------------------------
UNION ALL
-- R58-R60 check RP2 and W3 from delivered columns alone. Each would pass
-- silently if the old code came back: R14 is satisfied either way, R13 is
-- satisfied by any self-consistent FUED, and a reinstated promotion would move
-- DTHDT without breaking any other rule in this pack. They mirror
-- output-validation V45 / V44 / V47 - those gate the release, these let a
-- partner holding only the extract reach the same verdict.
--
-- W1 and W2 are NOT provable from here. Both moved DEATH_DT_preliminary before
-- DTHDT was set, so their return leaves the two columns equal and R59 passing.
-- Only qc/05 C21, which rebuilds the death date from the mortality source,
-- would see it.
SELECT 'R58', 'GATE',
       'dth_before_fued is 0 on every row - unreachable under Q82  (mirrors V45)',
       COUNT(*),
       SUM(CASE WHEN NOT COALESCE(dth_before_fued = 0, FALSE) THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- DEATH_DT_preliminary is the imputation and nothing else, so the two columns
-- are equal on every row, NULLs included. This is W3 only - see the note
-- above.
SELECT 'R59', 'GATE',
       'dthdt = death_dt_preliminary - the row-92 promotion stayed deleted  (Q82, mirrors V44)',
       COUNT(*),
       SUM(CASE WHEN dthdt IS DISTINCT FROM death_dt_preliminary
                THEN 1 ELSE 0 END)
FROM ads
UNION ALL
-- The death date wins wherever there is one; the preliminary follow-up end is
-- only the fallback. Not a minimum - a death after the last recorded activity
-- IS the end of follow-up (Q82). All three NULL counts as equal, which is the
-- FUED IS NULL case the ruling now permits.
SELECT 'R60', 'GATE',
       'fued = COALESCE(dthdt, fu_enddt_preliminary) - death date first  (Q82, mirrors V47)',
       COUNT(*),
       SUM(CASE WHEN NOT COALESCE(
                       fued = COALESCE(dthdt, fu_enddt_preliminary)
                    OR (fued IS NULL AND dthdt IS NULL
                        AND fu_enddt_preliminary IS NULL), FALSE)
                THEN 1 ELSE 0 END)
FROM ads

UNION ALL
-- Q83 sized exactly, not bounded. V46 counts `fued < indexdt`, which
-- OVERSTATES the harm: a FUED one day before the index gives FUDUR = 0, not a
-- negative. These four count the delivered values themselves. All REVIEW.
SELECT 'R61', 'REVIEW', 'negative FUDUR delivered  (Q83, exact)',
       COUNT(*), SUM(CASE WHEN fudur < 0 THEN 1 ELSE 0 END)
FROM   ${schema}.${ads}
UNION ALL
SELECT 'R62', 'REVIEW', 'negative OS delivered, alive branch  (Q83, exact)',
       SUM(CASE WHEN COALESCE(dthfl = 0, FALSE) THEN 1 ELSE 0 END),
       SUM(CASE WHEN COALESCE(dthfl = 0, FALSE) AND os < 0 THEN 1 ELSE 0 END)
FROM   ${schema}.${ads}
UNION ALL
-- Censored TTNT only; an event-derived negative is a defect, gated by V07.
-- The censored branch is REBUILT from delivered fields, not inferred from
-- TTNT's value. A death-driven event has DTHDT = FUED under Q82, so the event
-- and censored formulas collide numerically on every such row. TTNTFL is not
-- delivered (Q02). Mirrors qc/03_cross_variable_rules.R exactly.
SELECT 'R63', 'REVIEW', 'negative TTNT delivered, censored branch  (Q83, exact)',
       SUM(CASE WHEN cens THEN 1 ELSE 0 END),
       SUM(CASE WHEN cens AND ttnt < 0 THEN 1 ELSE 0 END)
FROM   (SELECT ttnt,
               cohortn IN (3,4,5,6)
                 AND COALESCE(id3mosfu = 1, FALSE)
                 AND COALESCE(dthfl = 0, FALSE)
                 AND CASE cohortn
                       WHEN 3 THEN LEAST(lot2sd_mhspc, lot1sd_mcrpc)
                       WHEN 4 THEN lot2sd_mcrpc
                       WHEN 5 THEN lot3sd_mcrpc
                       WHEN 6 THEN lot4sd_mcrpc END IS NULL AS cens
        FROM ${schema}.${ads})
UNION ALL
SELECT 'R64', 'REVIEW', 'FUDUR exactly 0 - fued is index minus one day  (Q83)',
       COUNT(*), SUM(CASE WHEN fudur = 0 THEN 1 ELSE 0 END)
FROM   ${schema}.${ads}
)

-- REVIEW rows are expected here - R12, R18b and R61-R64 size Q83 and carry
-- no pass condition. Only GATE rows must read zero.
-- @assert zero n_violations when severity=GATE
-- @assert none status in FAIL
SELECT id, severity, rule, n_applicable, n_violations,
       ROUND(100.0 * n_violations / NULLIF(n_applicable, 0), 4) AS pct,
       CASE WHEN severity = 'REVIEW'  THEN 'REVIEW'
            WHEN n_violations = 0     THEN 'PASS'
            ELSE 'FAIL' END AS status
FROM   rules
-- FAIL first, then REVIEW rows that found something, then everything else.
ORDER  BY CASE WHEN severity = 'GATE' AND n_violations > 0 THEN 0
               WHEN n_violations > 0                       THEN 1
               ELSE 2 END,
          id;
