-- =============================================================================
-- QC 06. GOLDEN PATIENTS - END-TO-END TRACE FOR MANUAL REVIEW
-- =============================================================================
-- Substitute ${catalog} / ${schema} / ${ads} / ${src} before running.
--
-- Every other file here produces counts. Counts show a rule holds across the
-- table. They cannot tell a clinician whether the numbers describe a real
-- patient correctly.
--
-- This picks a few patients whose profiles hit the hardest decisions, and puts
-- their delivered row next to the source records behind it. Sit down with a
-- clinician for an hour. It is the only check that catches a definition coded
-- exactly as written and still clinically wrong.
--
-- Patients are picked by profile, never at random, so a re-run after a refresh
-- traces the same kind of patient. A random sample would mostly return
-- unremarkable patients and would not compare between cuts.
--
--   P1  in all seven cohorts            - the grain and the cohort joins
--   P2  died, DTHFUFL = 0 - the follow-up flag rule
--   P3  PSABL = 0 - the PSA50 guard
--   P4  hemoglobin Unknown, no value - touches ~39% of the ADS
--   P5  HRR positive, BRCA negative - the biomarker collision rules
--   P6  ECOG present in a treated cohort- the [-30,+7] window
--   P7  four mCRPC lines                - the LOT block at full depth
--   P8  untreated mCRPC - errata E12
--   P9  died after the last activity    - the 2026-09-11 ruling, FUED takes the death date rather
--                                         than the earlier of the two
--   P10 follow-up ends before index     - the unruled residue left when the
--                                         index floor on FUED was removed
--
-- RUN ORDER: run STEP 1, copy the ten patids it returns, paste them into the
-- placeholder in STEP 2 and STEP 3. They are separate statements because
-- Databricks does not persist a WITH clause across statements.
-- RP1-RP4 and W1-W3 are the 2026-09-11 ruling's four rules and the three
-- behaviours they withdraw, defined in docs/VARIABLES.md section 3.
-- =============================================================================

USE CATALOG ${catalog};

-- =============================================================================
-- STEP 1. Pick the patients
-- =============================================================================
WITH ads AS (SELECT * FROM ${schema}.${ads}),
profiles AS (
    SELECT 'P1 in all seven cohorts' AS profile, patid,
           ROW_NUMBER() OVER (ORDER BY patid) AS rn
    FROM   ads GROUP BY patid HAVING COUNT(DISTINCT cohortn) = 7
    UNION ALL
    SELECT 'P2 died, dthfufl = 0', patid,
           ROW_NUMBER() OVER (ORDER BY patid)
    FROM   ads WHERE dthfl = 1 AND dthfufl = 0
    UNION ALL
    SELECT 'P3 psabl = 0', patid,
           ROW_NUMBER() OVER (ORDER BY patid)
    FROM   ads WHERE psa_index = 0
    UNION ALL
    -- By the accepted reading this reads Unknown rather than Missing. 'Unknown' covers two
    -- populations - a patient tested only after index, and a patient with a
    -- pre-index record that fails the Present criteria (wrong unit,
    -- non-positive value, no testdate). The ADS cannot tell them apart, so
    -- neither can this predicate. Use the lab block in STEP 3 to see which of
    -- the two this patient is - that is the point of the source trace.
    SELECT 'P4 hemoglobin Unknown, no baseline value', patid,
           ROW_NUMBER() OVER (ORDER BY patid)
    FROM   ads WHERE labhem = 'Unknown' AND labhemv IS NULL
    UNION ALL
    SELECT 'P5 HRR positive, BRCA negative', patid,
           ROW_NUMBER() OVER (ORDER BY patid)
    FROM   ads WHERE hrr_indexn = 1 AND brca_indexn = 2
    UNION ALL
    SELECT 'P6 ECOG present in a treated cohort', patid,
           ROW_NUMBER() OVER (ORDER BY patid)
    FROM   ads WHERE cohortn BETWEEN 3 AND 7 AND ecog <> 'Unknown/Missing'
    UNION ALL
    SELECT 'P7 four mCRPC lines', patid,
           ROW_NUMBER() OVER (ORDER BY patid)
    FROM   ads WHERE lot4_mcrpc IS NOT NULL
    UNION ALL
    SELECT 'P8 untreated mCRPC  (errata E12)', patid,
           ROW_NUMBER() OVER (ORDER BY patid)
    FROM   ads WHERE cohortu = 'Untreated mCRPC'
    UNION ALL
    -- The clarification's worked example: a death recorded after the last
    -- activity. FUED must read the DEATH date here, not the earlier activity
    -- date - the minimum first proposed would have put the death outside
    -- follow-up and an OS analysis would have dropped the event.
    SELECT 'P9 died after last activity, CSF_FU set in the opened window', patid,
           ROW_NUMBER() OVER (ORDER BY patid)
    FROM   ads WHERE dthfl = 1 AND fu_enddt_preliminary IS NOT NULL
                 AND fued > fu_enddt_preliminary AND csf_fu = 1
    UNION ALL
    -- Reachable only for a patient with NO death date, since FUED is the death
    -- date whenever one exists and the death exclusion puts that on or after the
    -- index. An empty P9 or P10 is itself a finding - see below.
    SELECT 'P10 negative FUDUR delivered', patid,
           ROW_NUMBER() OVER (ORDER BY patid)
    FROM   ads WHERE fudur < 0
)
SELECT profile, patid FROM profiles WHERE rn = 1 ORDER BY profile;

-- A profile returning no row is itself a finding. An empty P9 would mean no
-- patient in the study ever has a death recorded after their last activity,
-- which is the case the clarification was written for. An empty P10 is the
-- good outcome: nobody's follow-up ends before their index and the open follow-up disposition
-- exposure is nil on this cut. P8 empty would mean no
-- patient is ever labelled Untreated mCRPC, which is the exact defect errata
-- E12 describes in the spec's own COHORTU pseudo-code. P5 empty would mean the
-- HRR and BRCA calls never disagree, which would make one of them redundant.


-- =============================================================================
-- STEP 2. The delivered rows, all 190 columns
-- =============================================================================
-- Paste the patids from STEP 1. Read across: this is what ships.
SELECT *
FROM   ${schema}.${ads}
WHERE  patid IN ('<paste>', '<paste>', '<paste>', '<paste>', '<paste>',
                 '<paste>', '<paste>', '<paste>', '<paste>', '<paste>')
ORDER  BY patid, cohortn;


-- =============================================================================
-- STEP 3. The source records behind those rows
-- =============================================================================
-- One block per source table, same patids. Read each block against the
-- delivered row above and confirm the derivation by eye.
--
-- WHAT TO CHECK IN EACH BLOCK
--   milestones  MHSPCDD / MCRPCDD are GREATEST(metdx, hspcdate / crpcdate).
--               Confirm the delivered date is the later of the two, not the
--               earlier, and that INDEXDT equals it for cohorts 1-2.
--   lines       NEW_LOT_N is derived - it restarts at 1 within each setting,
--               ordered by start date, and is not the source LINENUMBER. For
--               cohorts 3-7, INDEXDT must equal the start date of the line at
--               that derived position.
--   labs        LAB<x>V is the qualifying record closest to index, ties broken
--               by the analyte's own rule. The flag is Present / Unknown /
--               Missing; by the accepted reading a post-index-only record gives Unknown.
--   ecog        Cohorts 1-2 anchor on the milestone; cohorts 3-7 on the line
--               start, matched on line number and start date, then bounded to
--               [INDEX-30, INDEX+7]. Closest to index wins, then highest value.
--   biomarker   One winning date per patient, chosen over all biomarker tests
--               before either gene set is applied - that is why HRR and BRCA
--               always share a date.
--   psa         PSA_INDEX is the earliest ScoreSerial in [INDEX-14, INDEX],
--               taking the maximum if several land on that earliest day.

-- ---- milestones and staging -------------------------------------------------
SELECT patientid, metastaticdiagnosisdate, hspcdate, crpcdate,
       diagnosisdate, groupstage, gleasonscore
FROM   ${src}.t_enh_prostate_2026m06
WHERE  patientid IN ('<paste>')
ORDER  BY patientid;

-- ---- lines of therapy, with the DERIVED position ----------------------------
SELECT patientid, linesetting, linenumber, linename, startdate, enddate,
       ROW_NUMBER() OVER (PARTITION BY patientid, linesetting
                          ORDER BY startdate) AS new_lot_n
FROM   ${src}.t_enh_prostate_lot_2026m06
WHERE  patientid IN ('<paste>')
ORDER  BY patientid, linesetting, startdate;

-- ---- labs, the ten analytes only --------------------------------------------
SELECT patientid, testbasename, labcomponent, testdate, resultdate,
       GREATEST(testdate, resultdate) AS derived_labdate,
       testresultcleaned, testunitscleaned
FROM   ${src}.t_lab_2026m06
WHERE  patientid IN ('<paste>')
  AND  LOWER(testbasename) IN ('neutrophils', 'platelets', 'hemoglobin',
                               'creatinine', 'bilirubin',
                               'aspartate aminotransferase',
                               'alanine aminotransferase',
                               'alkaline phosphatase', 'albumin', 'lymphocytes')
ORDER  BY patientid, testbasename, derived_labdate;

-- ---- baseline ECOG (treated cohorts) and general ECOG -----------------------
SELECT patientid, linenumber, linestartdate, ecogdate, ecogvalue
FROM   ${src}.t_enh_prostate_bsln_ecog_2026m06
WHERE  patientid IN ('<paste>')
ORDER  BY patientid, linestartdate, ecogdate;

SELECT patientid, ecogdate, ecogvalue
FROM   ${src}.t_ecog_2026m06
WHERE  patientid IN ('<paste>')
ORDER  BY patientid, ecogdate;

-- ---- biomarkers -------------------------------------------------------------
-- Column names per validation/00_input_contract.csv: BIOMARKERNAME (not
-- genename) and BIOMARKERSTATUS. There is no test-type column on this table,
-- which is why hard-codes HRR_INDEX_TEST and BRCA_INDEX_TEST to
-- 'Unknown'.
SELECT patientid, biomarkername, specimencollecteddate, resultdate,
       GREATEST(specimencollecteddate, resultdate) AS derived_biomarker_dt,
       biomarkerstatus
FROM   ${src}.t_enh_prostate_biomarker_2026m06
WHERE  patientid IN ('<paste>')
ORDER  BY patientid, derived_biomarker_dt;

-- ---- PSA --------------------------------------------------------------------
SELECT patientid, resultdate, scoreserial
FROM   ${src}.t_enh_prostate_psa_2026m06
WHERE  patientid IN ('<paste>')
ORDER  BY patientid, resultdate;

-- ---- death ------------------------------------------------------------------
-- dateofdeath is month- or year-level. Confirm the imputation the build applied
-- - 5B.ClinChars row 90 only, since rows 91-93 hold W1-W3 and all three are
-- withdrawn - by comparing DATEOFDEATH, DEATH_DT_preliminary and DTHDT on the
-- delivered row. The last two always agree now; a difference means W3 is back.
SELECT patientid, dateofdeath, LENGTH(dateofdeath) AS granularity_chars
FROM   ${src}.t_mortality_v2_2026m06
WHERE  patientid IN ('<paste>');

-- ---- follow-up sources ------------------------------------------------------
-- FU_ENDDT_preliminary is the latest of exactly four sources: last visit, last
-- telemedicine, last line end, last oral end (5B.ClinChars row 89). Unlike the
-- 202603 cut, 202606 does not fold in alpha/beta emitters or Provenge, so
-- follow-up ends can differ between cuts without being defects.
SELECT '1 visit' AS src, patientid, MAX(visitdate) AS last_dt
FROM ${src}.t_visit_2026m06 WHERE patientid IN ('<paste>') GROUP BY patientid
UNION ALL
SELECT '2 telemedicine', patientid, MAX(visitdate)
FROM ${src}.t_telemedicine_2026m06 WHERE patientid IN ('<paste>') GROUP BY patientid
UNION ALL
SELECT '3 line end', patientid, MAX(enddate)
FROM ${src}.t_enh_prostate_lot_2026m06 WHERE patientid IN ('<paste>') GROUP BY patientid
UNION ALL
-- Production drops oral rows whose end date is year-granular (5B.ClinChars
-- r89) and ignores null ends. Without those filters this block reports a
-- later date than the build used, and the trace looks wrong when it is not.
SELECT '4 oral end', patientid, MAX(enddate)
FROM ${src}.t_enh_prostate_orals_2026m06
WHERE patientid IN ('<paste>')
  AND enddate IS NOT NULL
  AND LOWER(COALESCE(startdategranularity, '')) <> 'year'
GROUP BY patientid
ORDER BY patientid, src;
