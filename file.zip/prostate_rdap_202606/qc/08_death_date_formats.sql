-- =============================================================================
-- QC 08. DEATH-DATE FORMATS - the cost of the spec's unhandled cases
-- =============================================================================
-- Substitute ${catalog} / ${schema} / ${ads} / ${src} before running.
--
-- WHY THIS EXISTS (register Q66, ruled 2026-08-08)
--   5B.ClinChars r90 describes exactly two DATEOFDEATH shapes: month-and-year
--   ("as the 15th of the month unless...") and year-only ("For patients with
--   DATEOFDEATH is year only..."). It gives no rule for anything else and no
--   "else missing" clause - the case is a hole in the spec, not a decision it
--   made.
--
--   The build implements the two documented cases and lets everything else
--   fall to NULL. That is spec-literal, ruled deliberately over inventing a
--   third branch.
--
-- THE COST, as the 2026-09-11 follow-up ruling leaves it (register Q82)
--   A populated death date that falls to NULL turns a dead patient into a
--   censored one, and that has two halves now rather than one.
--
--   OUTCOMES. DTHFL reads 0 and DTHDT is NULL, so FUED falls back to
--   FU_ENDDT_preliminary - the last recorded activity - instead of BEING the
--   death date. OS then measures follow-up rather than survival, and PFS loses
--   its death event.
--
--   MEMBERSHIP. The per-cohort death exclusion cannot fire. index_lot_cohort()
--   keeps a row when `dthdt IS NULL OR index_date <= dthdt`, so a NULL death
--   date lands on the first limb and the patient is excluded from nothing -
--   they hold cohort rows the ruling says they lose, and can ship an index date
--   after a death the source recorded.
--
--   The outcome half is measured, not gated: see whether the hole affects real
--   rows before changing the derivation. The membership half cannot be repaired
--   after the write, because the death date is the only thing the exclusion
--   reads, so it is GATED at source by preflight B18. The queries below measure
--   the outcome half and name the rows B18 would have stopped.
--
-- HOW TO READ IT
--   Q08a  is the length distribution over the whole mortality source - a
--         reading, not the closure test (validation/06 is the oracle).
--   Q08b  is the cost, in patients. Anything here is a patient the source says
--         died and the ADS says did not - and, under Q82, a patient the cohort
--         exclusion could not touch.
--   Q08c  is the same population's delivered outcome columns, so the effect on
--         OS and PFS is visible rather than inferred.
--
--   Closure is ADS-scoped: validation/06's qcr_q66_deaths_r at zero closes
--   Q66. Q08b/Q08c join the ADS; Q08a/Q08d are source-wide readings. That join
--   loses none of the affected population under Q82 - these are exactly the
--   patients the exclusion could not remove, so every one of them that
--   qualified for a cohort is still delivered in it.
--
--   Then read Q08a's n_chars, which is what the two lines below are about.
--   If it shows 10: that is a full YYYY-MM-DD. It needs no imputation - the
--         day is already there - and the fix is a third branch casting it
--         directly. Bring the Q08b count to the owner; it is their call.
--   If it shows anything else: the value is malformed. Do not guess at it in
--         the build. Raise it with the data provider.
-- =============================================================================

USE CATALOG ${catalog};

-- =============================================================================
-- Q08a. What lengths actually occur?
-- =============================================================================
-- Runs against the source, so it is valid before a build as well as after.
--
-- The year-only arm reads Jul-15 and nothing else. The 2026-09-11 ruling
-- (register Q82) deleted the same-year push to 31-Dec, so there is no path to a
-- December value any more and a label naming one would describe deleted code.
SELECT
    LENGTH(dateofdeath)                                 AS n_chars,
    CASE WHEN dateofdeath IS NULL     THEN 'absent'
         WHEN LENGTH(dateofdeath) = 7 THEN 'YYYY-MM  - spec case 1, imputed to the 15th'
         WHEN LENGTH(dateofdeath) = 4 THEN 'YYYY     - spec case 2, imputed to Jul-15'
         WHEN LENGTH(dateofdeath) = 10 THEN 'YYYY-MM-DD - NOT in the spec; currently DISCARDED'
         ELSE                              'UNEXPECTED - malformed; currently DISCARDED' END
                                                        AS shape,
    COUNT(*)                                            AS n_rows,
    COUNT(DISTINCT patientid)                           AS n_patients,
    MIN(dateofdeath)                                    AS example_min,
    MAX(dateofdeath)                                    AS example_max
FROM   ${src}.t_mortality_v2_2026m06
GROUP  BY 1, 2
ORDER  BY n_rows DESC;


-- =============================================================================
-- Q08b. Patients the source says died and the ADS says did not
-- =============================================================================
-- This is the number the ruling asked for. Every row here is a silent
-- censoring: a populated dateofdeath that the imputation could not use, so
-- DEATH_DT_preliminary is NULL, DTHDT is NULL and DTHFL reads 0 - and, under
-- Q82, the per-cohort exclusion had no date to test, so this patient was
-- excluded from no cohort at all.
--
-- The oracle's wrong-length slice: ADS-joined, so it reads zero whenever
-- validation/06's qcr_q66_deaths_r does. Above zero is a defect with a
-- known cause and fix; its size decides whether the fix is urgent. Preflight
-- B18 counts the same rows at source, before anything is written.
SELECT
    a.cohort,
    COUNT(*)                                            AS n_rows_affected,
    COUNT(DISTINCT a.patid)                             AS n_patients_affected,
    MIN(LENGTH(m.dateofdeath))                          AS min_len,
    MAX(LENGTH(m.dateofdeath))                          AS max_len,
    -- what the ADS currently says about these patients
    SUM(CASE WHEN a.dthfl = 0 THEN 1 ELSE 0 END)        AS n_reading_alive,
    SUM(CASE WHEN a.dthdt IS NULL THEN 1 ELSE 0 END)    AS n_dthdt_null
FROM       ${schema}.${ads} a
JOIN       ${src}.t_mortality_v2_2026m06 m ON m.patientid = a.patid
WHERE      m.dateofdeath IS NOT NULL
  AND      LENGTH(m.dateofdeath) NOT IN (4, 7)
GROUP  BY  a.cohort
ORDER  BY  a.cohort;


-- =============================================================================
-- Q08c. What it does to the delivered outcomes
-- =============================================================================
-- The same population, with the columns the silent censoring actually moves.
-- Read OS: with DTHDT NULL, FUED falls to FU_ENDDT_preliminary - the last
-- recorded activity - so OS is the follow-up duration and not survival.
-- DEATH_DT_preliminary and DTHDT both read NULL here, and under Q82 they carry
-- the same value on every row of the table, not only on these. Twenty rows is
-- enough to see the shape; drop the LIMIT if Q08b returns a large number.
SELECT
    a.patid,
    a.cohort,
    m.dateofdeath                                       AS source_dateofdeath,
    LENGTH(m.dateofdeath)                               AS n_chars,
    a.death_dt_preliminary,
    a.dthdt,
    a.dthfl,
    a.dthfufl,
    a.fued,
    a.os,
    a.pfsfl,
    a.pfsdt
FROM       ${schema}.${ads} a
JOIN       ${src}.t_mortality_v2_2026m06 m ON m.patientid = a.patid
WHERE      m.dateofdeath IS NOT NULL
  AND      LENGTH(m.dateofdeath) NOT IN (4, 7)
ORDER  BY  a.patid, a.cohort
LIMIT 20;


-- =============================================================================
-- Q08d. The other silent-conversion risk: right length, wrong content
-- =============================================================================
-- A 7-character value is CONCAT'd with '-15' and cast to DATE. If the value
-- is seven characters but not YYYY-MM - e.g. '2020-1 ' or '2020/03' - the
-- build's TRY_CAST turns it into a silent NULL, which is exactly the
-- censoring this file sizes - and, under Q82, exactly the row the cohort
-- exclusion cannot act on. The length checks
-- above cannot see this, because the length is right and only the content is
-- wrong. Same for the 4-character branch. Preflight B18 tests the build's own
-- CASE instead of a length, so it catches this shape and the wrong-length one
-- together.
SELECT
    'malformed 7-char (not YYYY-MM)'                    AS problem,
    COUNT(*)                                            AS n_rows,
    COUNT(DISTINCT patientid)                           AS n_patients
FROM   ${src}.t_mortality_v2_2026m06
WHERE  LENGTH(dateofdeath) = 7
  AND  NOT dateofdeath RLIKE '^[0-9]{4}-[0-9]{2}$'
UNION ALL
SELECT
    'malformed 4-char (not YYYY)',
    COUNT(*),
    COUNT(DISTINCT patientid)
FROM   ${src}.t_mortality_v2_2026m06
WHERE  LENGTH(dateofdeath) = 4
  AND  NOT dateofdeath RLIKE '^[0-9]{4}$'
UNION ALL
-- The imputed month must also be a real one. '2020-13' is seven characters,
-- matches the pattern, and CONCAT('2020-13', '-15') is not a date.
SELECT
    '7-char with an impossible month',
    COUNT(*),
    COUNT(DISTINCT patientid)
FROM   ${src}.t_mortality_v2_2026m06
WHERE  LENGTH(dateofdeath) = 7
  AND  dateofdeath RLIKE '^[0-9]{4}-[0-9]{2}$'
  AND  TRY_CAST(CONCAT(dateofdeath, '-15') AS DATE) IS NULL
UNION ALL
-- The 4-character branch's exact-conversion arm, kept for structural
-- symmetry: every regex-valid four-digit year should cast, so expect zero -
-- a nonzero here is itself a finding.
SELECT
    '4-char with an impossible year',
    COUNT(*),
    COUNT(DISTINCT patientid)
FROM   ${src}.t_mortality_v2_2026m06
WHERE  LENGTH(dateofdeath) = 4
  AND  dateofdeath RLIKE '^[0-9]{4}$'
  AND  TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE) IS NULL;
