# =============================================================================
# Index cohort definition
# =============================================================================
# 4.StudyPop section B - one index table per cohort.
# Sourced by the driver in numbered order. Not runnable on its own.
# =============================================================================

# --- patient-level death date and follow-up end date ---------
# Rules RP1-RP3 and the three behaviours they withdraw: see
# docs/VARIABLES.md section 3. What matters here is RP3 - DTHDT and
# FUED are derived ONCE PER PATIENT, before any cohort is assigned and before
# any index date exists, so neither may depend on an index date. Two things
# follow from that:
#
#   * the cohort filter below can read DTHDT, which is what makes the
#     per-cohort death exclusion possible at all;
#   * 03_clinical.R joins this table rather than re-deriving it, so there is
#     one definition instead of seven.
#
# is unchanged - a DATEOFDEATH of any other length still falls to
# NULL.
patient_fu_death_q <- enh_pros_pano %>%
  select(patientid) %>%
  distinct() %>%
  left_join(enh_pros_pano_visit %>% group_by(patientid) %>%
              summarise(last_visitdate = max(visitdate, na.rm = TRUE)) %>% distinct(),
            by = "patientid") %>%
  left_join(enh_pros_pano_telemed %>% group_by(patientid) %>%
              summarise(last_televisitdate = max(visitdate, na.rm = TRUE)) %>% distinct(),
            by = "patientid") %>%
  left_join(enh_pros_pano_lot %>% group_by(patientid) %>%
              summarise(last_lotenddate = max(enddate, na.rm = TRUE)) %>% distinct(),
            by = "patientid") %>%
  # DateGranularity is upper-case in the delivered data (DAY / MONTH / YEAR);
  # a comparison against mixed-case 'Year' never fires.
  left_join(enh_pros_pano_orals %>%
              filter((toupper(startdategranularity) != 'YEAR' |
                        is.na(startdategranularity)) & !is.na(enddate)) %>%
              group_by(patientid) %>%
              summarise(last_oralenddate = max(enddate, na.rm = TRUE)) %>% distinct(),
            by = "patientid") %>%
  # The remaining row-88 interim variables. The three minima and the
  # medication-order date play no part in the row-89 FU_ENDDT_preliminary
  # derivation, but row 88 asks for them by name ("Keep ... Add their
  # labels"), so they are produced and carried through to the ADS.
  left_join(enh_pros_pano_visit %>% group_by(patientid) %>%
              summarise(min_vst_dt = min(visitdate, na.rm = TRUE)) %>% distinct(),
            by = "patientid") %>%
  left_join(enh_pros_pano_telemed %>% group_by(patientid) %>%
              summarise(min_vsttelemed_dt = min(visitdate, na.rm = TRUE)) %>% distinct(),
            by = "patientid") %>%
  left_join(enh_pros_pano_medorder %>%
              filter(is.na(iscanceled) | tolower(iscanceled) != 'true') %>%
              group_by(patientid) %>%
              summarise(min_medord_dt = min(expectedstartdate, na.rm = TRUE)) %>%
              distinct(),
            by = "patientid") %>%
  # Interim variable kept per 5B.ClinChars row 88.
  # SPEC ISSUE: row 88 asks for EpisodeDataSource = 'Abstraction', but the 2026m06
  #   drug-episode table only carries 'Unstructured', 'Administrations' and
  #   'Orders'. As written this resolves to NULL for every patient - confirm
  #   which value replaced 'Abstraction'.
  left_join(enh_pros_pano_drugepisode %>%
              filter(episodedatasource == 'Abstraction') %>%
              group_by(patientid) %>%
              summarise(max_drug_ep_abstracted_dt = max(episodedate, na.rm = TRUE)) %>%
              distinct(),
            by = "patientid") %>%
  mutate(
    # 5B.ClinChars row 89 lists exactly four sources: visit, telemedicine,
    # lineoftherapy end and oral end. The 202603 definition also folded in the
    # alpha/beta-emitter and Provenge tables; those are not in the 202606
    # definition and are excluded here. This can shorten follow-up for
    # patients whose last recorded activity was a radioligand or Provenge
    # administration - confirm before release.
    #
    # This is the "last activity date" the 2026-09-11 ruling names.
    fu_enddt_preliminary = pmax(last_visitdate, last_televisitdate,
                                last_lotenddate, last_oralenddate,
                                na.rm = TRUE)
  ) %>%
  # Join death, imputing coarse-granularity dates
  left_join(
    enh_pros_pano_mortality %>%
      # spec-literal. 5B.ClinChars r90 describes exactly two
      # shapes, month-and-year and year-only, and gives no rule for anything
      # else - so only those two are implemented and every other length falls
      # to NULL. Do not add a third branch (e.g. full YYYY-MM-DD) without a
      # ruling.
      #
      # The risk is measured, not gated: a populated death date falling to
      # NULL turns a dead patient into a censored one (DTHFL 0, OS from FUED).
      # qc/08_death_date_formats.sql sizes it. Rows there mean revisit this.
      mutate(dateofdeath_init = dbplyr::sql(
        # TRY_CAST, not CAST. A value of the right length but the wrong
        # shape - '2020-13', '20x0' - raises under ANSI and stops the build.
        # It becomes NULL here instead, which qc/08 counts.
        #
        # Rule RP1. This is the whole of the imputation - nothing downstream
        # moves the value again.
        "CASE
           WHEN LENGTH(dateofdeath) = 7 THEN TRY_CAST(CONCAT(dateofdeath, '-15') AS DATE)
           WHEN LENGTH(dateofdeath) = 4 THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
           ELSE NULL END")) %>%
      select(patientid, dateofdeath, dateofdeath_init) %>% distinct(),
    by = "patientid") %>%
  mutate(
    # DEATH_DT_preliminary is the imputed value itself: W1 and W2 are
    # withdrawn. W1 needed the index date, so RP3 makes it impossible here
    # whatever the workbook says.
    death_dt_preliminary = dateofdeath_init
  ) %>%
  mutate(
    # W3 withdrawn, so the final death date is the preliminary one. Both
    # columns are in the delivered contract and both are kept; they now carry
    # the same value by construction (gate V44).
    dthdt = death_dt_preliminary
  ) %>%
  mutate(
    # Rule RP2: the death date when there is one, the last activity date
    # otherwise. NOT the earlier of the two - the clarification withdrew the
    # minimum the call summary first specified. docs/VARIABLES.md section 3
    # carries the worked example.
    #
    # So FUED >= INDEXDT holds for everyone who has a death date, because the
    # exclusion below guarantees DTHDT >= INDEXDT. It does NOT hold for a
    # patient with no death date, whose follow-up ends at an activity date that
    # nothing ties to the index - that residue is the open follow-up question, sized by V46.
    #
    # There is no floor at the index date either: FUED is a patient-level value
    # now, so there is no index date in scope to floor it at.
    fued = coalesce(dthdt, fu_enddt_preliminary)
  ) %>%
  mutate(
    dthfl = case_when(!is.na(dthdt) ~ 1L, TRUE ~ 0L),
    # 5A.Demos row 7. Not used to exclude patients (13-Mar-2025 TC), flag only.
    #
    # preliminary dates, not the final DTHDT/FUED. Under RP2 FUED
    # takes the death date outright instead of being clamped toward it, so this
    # flag once again measures a real gap: a death long after the last recorded
    # activity scores 0.
    #
    # The `<= 120` condition is still satisfied by a large negative
    # difference, so a death far BEFORE the last activity scores 1 like any
    # other death. That asymmetry is the spec's arithmetic, kept verbatim.
    dthfufl_dur = datediff(death_dt_preliminary, fu_enddt_preliminary)
  ) %>%
  mutate(
    # NULL only when there is no death date - nothing to compare. The
    # 2026-09-11 ruling did not change this.
    #
    # Do not add a second null case (e.g. for a missing
    # FU_ENDDT_preliminary): the spec's Values list is
    # "0 = No; 1 = Yes" ending "else 0", so there is no third state, and the
    # arithmetic already answers it - a NULL duration fails `<= 120` and the
    # ELSE gives 0. Gates V41 (null rule) and V43 (domain).
    dthfufl = case_when(
      is.na(death_dt_preliminary) ~ NA_integer_,
      dthfufl_dur <= 120          ~ 1L,
      TRUE                        ~ 0L),
    # Kept verbatim from the spec, and now unreachable: with a death date FUED
    # IS DTHDT, so DTHDT < FUED is false; without one DTHDT is NULL, so the
    # test is false again. Delivered as a constant 0 rather than dropped,
    # because it is one of the 190 contracted columns. Gate V45 proves it stays
    # 0; a nonzero count means the FUED rule has drifted.
    dth_before_fued = ifelse(!is.na(dthdt) & !is.na(fued) & dthdt < fued, 1, 0)
  ) %>%
  # Row 88's interim variables are emitted under the spec's own names.
  select(patientid,
         min_vst_dt, min_vsttelemed_dt, min_medord_dt,
         max_vsttelemed_dt = last_televisitdate,
         max_lotend_dt     = last_lotenddate,
         max_drug_ep_abstracted_dt,
         last_visitdate, last_oralenddate, fu_enddt_preliminary,
         dateofdeath, dateofdeath_init, death_dt_preliminary,
         dthdt, dthfl, fued, dthfufl_dur, dthfufl, dth_before_fued)

createInPersonalSchema(patient_fu_death_q,
                       stage_name("enh_pros_pano_pt_fu_death_tbl"), replace = TRUE)
# Rebind to the materialized table for the same reason the cohort stages do:
# seven cohorts each join this, and a lazy object would re-expand the whole
# aggregate stack into every one of them.
patient_fu_death <- tbl(con, in_schema(personal_schema,
                                       stage_name("enh_pros_pano_pt_fu_death_tbl")))
rm(patient_fu_death_q)

# Overall cohorts index on the metastatic milestone date. LOT cohorts index on
# the start date of the matching line within the setting. Every cohort also
# needs the milestone date itself inside the index window.
index_lot_cohort <- function(coh_flag) {
  ci      <- coh_info(coh_flag)
  setting <- ci$setting
  lot_n   <- ci$lot_n      # local, not ci$lot_n: dbplyr reads `ci$lot_n`
                           # inside a verb as a SQL column reference, not an
                           # R value, so `ci$...` must never appear in one.

  milestone <- enh_pros_pano %>%
    mutate(advanceddiagnosisdate = if (setting == "mHSPC") mhspcdd else mcrpcdd) %>%
    filter(advanceddiagnosisdate >= index_start & advanceddiagnosisdate <= index_end) %>%
    select(patientid, advanceddiagnosisdate)

  out <- if (is.na(ci$lot_n)) {
    # Overall mHSPC / Overall mCRPC
    milestone %>%
      mutate(index_date = as.Date(advanceddiagnosisdate)) %>%
      select(patientid, index_date, advanceddiagnosisdate)
  } else {
    lot_tbl(setting) %>%
      filter(startdate >= index_start & startdate <= index_end & new_lot_n == !!lot_n) %>%
      select(patientid, linename, linenumber, startdate, enddate, new_lot_n) %>%
      inner_join(milestone, by = "patientid") %>%
      mutate(index_date = as.Date(startdate)) %>%
      select(patientid, index_date, advanceddiagnosisdate,
             linenumber, linename, startdate, enddate, new_lot_n)
  }

  # --- death exclusion, per cohort ----------------------------
  # Rule RP4, with its worked example and its edge-case callout, is in the ruling
  # file. Per cohort, not per patient, falls out of where the test sits: each
  # cohort applies it independently, so a patient can hold Overall, L1 and L2
  # and still be dropped from L3.
  #
  # `index_date > dthdt` is the exclusion, so a death ON the index date keeps
  # the patient: RP4 excludes an index AFTER the death, not on it. A patient with
  # no death date is never excluded - case_when sends the NULL comparison to the
  # ELSE, which keeps them.
  out %>%
    left_join(patient_fu_death %>% select(patientid, dthdt), by = "patientid") %>%
    filter(case_when(is.na(dthdt) ~ TRUE,
                     index_date > dthdt ~ FALSE,
                     TRUE ~ TRUE)) %>%
    select(-dthdt)
}

for (coh_flag in coh_list) {
  var_name <- paste0("enh_pros_pano_", coh_flag, "_index_tbl")
  df <- index_lot_cohort(coh_flag)
  createInPersonalSchema(df, stage_name(var_name), replace = TRUE)
  # Rebind to the materialized table, not the lazy query. Keeping the lazy
  # object would make every downstream stage re-expand the whole upstream
  # query, so the final ADS would be one enormous nested SELECT and the
  # intermediate writes would be paid for without ever being used.
  assign(var_name, tbl(con, in_schema(personal_schema, stage_name(var_name))))
  rm(df)
}
