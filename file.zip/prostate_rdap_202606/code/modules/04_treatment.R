# =============================================================================
# Treatment variables
# =============================================================================
# 5C.TreatVars - per-line blocks and prior-exposure flags.
# Sourced by the driver in numbered order. Not runnable on its own.
# =============================================================================

# The 17-way therapy category runs once per (setting, line) pair, so it is
# factored out.
#
# These return unevaluated expressions. Splice them into mutate() with `!!`.
# Called as plain functions, dbplyr would try to translate `lotcat_expr()` into
# a SQL function call.
lotcat_expr <- function() rlang::expr(
  case_when(
    sql("LOWER(linename) = 'abiraterone'")  ~ "Abiraterone monotherapy",
    sql("LOWER(linename) = 'enzalutamide'") ~ "Enzalutamide monotherapy",
    sql("LOWER(linename) = 'apalutamide'")  ~ "Apalutamide monotherapy",
    sql("LOWER(linename) = 'darolutamide'") ~ "Darolutamide monotherapy",
    sql("(LOWER(linename) LIKE '%abiraterone%' OR LOWER(linename) LIKE '%enzalutamide%'
          OR LOWER(linename) LIKE '%apalutamide%' OR LOWER(linename) LIKE '%darolutamide%')
         AND (LOWER(linename) LIKE '%,%' OR LOWER(linename) LIKE '%/%')") ~ "NHA combination therapy",
    sql("LOWER(linename) = 'docetaxel'") ~ "Docetaxel monotherapy",
    sql("LOWER(linename) LIKE '%docetaxel%'
         AND (LOWER(linename) LIKE '%,%' OR LOWER(linename) LIKE '%/%')") ~ "Docetaxel combination therapy",
    sql("LOWER(linename) LIKE '%cabazitaxel%'") ~ "Cabazitaxel-containing",
    sql("LOWER(detaileddrugcategory) = 'chemotherapy'") ~ "Other chemotherapy-containing",
    sql("LOWER(linename) LIKE '%vipivotide tetraxetan%'") ~ "Pluvicto-containing",
    sql("LOWER(linename) LIKE '%radium-223%'") ~ "Radium 223-containing",
    # "with no other drugs allowed" (spec category 12), so this is an anchored
    # whole-string match rather than a LIKE. The separator class is [,/] to
    # match the combination rules above; a comma-only class would send a
    # slash-delimited PARPi regimen to "Any other therapy" while the same
    # formatting still counts as a combination in the NHA rule, and
    # slash-formatted LOT rows do occur in the source.
    sql("LOWER(linename) REGEXP '^(olaparib|talazoparib|niraparib|rucaparib)([,/](olaparib|talazoparib|niraparib|rucaparib))*$'") ~ "PARPi monotherapy",
    sql("LOWER(linename) LIKE '%pembrolizumab%'") ~ "Pembrolizumab-containing",
    sql("LOWER(linename) LIKE '%sipuleucel-t%'") ~ "Sipuleucel-T-containing",
    sql("LOWER(linename) LIKE '%clinical study drug%'") ~ "Clinical study drug-containing",
    sql("linename IS NULL") ~ "No treatment",
    TRUE ~ "Any other therapy")
)

lotcatn_expr <- function() rlang::expr(
  case_when(
    lotcat == "Abiraterone monotherapy" ~ 1, lotcat == "Enzalutamide monotherapy" ~ 2,
    lotcat == "Apalutamide monotherapy" ~ 3, lotcat == "Darolutamide monotherapy" ~ 4,
    lotcat == "NHA combination therapy" ~ 5, lotcat == "Docetaxel monotherapy" ~ 6,
    lotcat == "Docetaxel combination therapy" ~ 7, lotcat == "Cabazitaxel-containing" ~ 8,
    lotcat == "Other chemotherapy-containing" ~ 9, lotcat == "Pluvicto-containing" ~ 10,
    lotcat == "Radium 223-containing" ~ 11, lotcat == "PARPi monotherapy" ~ 12,
    lotcat == "Pembrolizumab-containing" ~ 13, lotcat == "Sipuleucel-T-containing" ~ 14,
    lotcat == "Clinical study drug-containing" ~ 15, lotcat == "Any other therapy" ~ 16,
    lotcat == "No treatment" ~ 17)
)

# Per-line block for one setting:
#   LOT<i>_<SET>      LINENAME from the LOT table
#   LOT<i>SD_<SET>    STARTDATE from the LOT table
#   LOT<i>ED_<SET>    max EPISODEDATE from drugepisode for that line (derived)
#   LOT<i>CAT_<SET> / LOT<i>CATN_<SET>
trt_lot_block <- function(indx_tbl, setting) {
  suffix  <- if (setting == "mHSPC") "_mhspc" else "_mcrpc"
  lot_set <- lot_tbl(setting)
  trt_lot_df <- NULL

  for (i in seq_len(lot_depth[[setting]])) {
    # The delivered end date is derived from drugepisode below, so the line's
    # own enddate is not carried.
    line_i <- lot_set %>%
      filter(new_lot_n == i) %>%
      select(patientid, linenumber, linename, startdate)

    # drugepisode carries linesetting/linenumber in 2026m06, so the episode
    # look-up is keyed on (patientid, linenumber) within the same setting.
    epi_i <- enh_pros_pano_drugepisode %>%
      filter(linesetting == setting) %>%
      inner_join(line_i %>% select(patientid, linenumber),
                 by = c("patientid", "linenumber"))

    last_epi <- epi_i %>%
      group_by(patientid) %>%
      summarise(lastdate = max(episodedate, na.rm = TRUE), .groups = "drop")

    chemo_i <- epi_i %>%
      # Lower-cased so the match agrees with lotcat_expr and the PRIOR_CHEMO
      # flag; a case-sensitive comparison would count 'Chemotherapy' rows
      # there but not here. Register Q72.
      filter(sql("LOWER(detaileddrugcategory) = 'chemotherapy'")) %>%
      # Collapse to the one value lotcat_expr tests for before distinct():
      # on the raw value a patient with mixed-case category spellings keeps
      # multiple rows and the left_join below fans out.
      mutate(detaileddrugcategory = "chemotherapy") %>%
      select(patientid, detaileddrugcategory) %>%
      distinct()

    trt_lot_interim_df <- indx_tbl %>%
      left_join(line_i,  by = "patientid") %>%
      left_join(last_epi, by = "patientid") %>%
      left_join(chemo_i,  by = "patientid") %>%
      mutate(
        # Register Q64: NULL where the line does not exist. 5C.TreatVars r220
        # is a lookup ("Value of LINENAME ... where NEW_LOT_N=1") typed
        # Character with no Values list, so a missing row yields missing.
        #
        # Do not substitute a placeholder here. The contrast with LOTnCAT is
        # deliberate: the category enumerates "17) No treatment", the name has
        # no such level. A literal would make qc/03 R40-R43 and golden profile
        # P7 vacuous, because all four absence tests use IS NULL.
        lotname = linename,
        lotsd   = startdate,
        loted   = lastdate,
        lotcat  = !!lotcat_expr()
      ) %>%
      mutate(lotcatn = !!lotcatn_expr()) %>%
      # Register Q17 (ruled 2026-08-07): delivered as LOT4CATN_MCRPC. The spec
      #   names it plainly "LOT4CATN", breaking the LOTnCATN_<SET> pattern every
      #   other line uses; the owner ruled to correct it rather than reproduce
      #   the slip, so the name is generated like all the others. Spec erratum
      #   E13.
      select(patientid, index_date,
             !!paste0("lot", i, suffix)       := lotname,
             !!paste0("lot", i, "sd", suffix) := lotsd,
             !!paste0("lot", i, "ed", suffix) := loted,
             !!paste0("lot", i, "cat", suffix) := lotcat,
             !!paste0("lot", i, "catn", suffix) := lotcatn)

    trt_lot_df <- if (i == 1) trt_lot_interim_df else
      trt_lot_df %>% left_join(trt_lot_interim_df, by = c("patientid", "index_date"))
  }
  trt_lot_df
}

# PRIOR_* exposure flags (rows 36-42). All are evaluated against the DrugEpisode
# regimen names with EPISODEDATE < INDEX, regardless of setting.
prior_spec <- list(
  list(name = "prior_pluvicto",    drugs = c("vipivotide tetraxetan"), mode = "any"),
  list(name = "prior_parp",        drugs = c("olaparib", "talazoparib", "niraparib", "rucaparib"), mode = "only"),
  list(name = "prior_chemo",       drugs = NULL,                       mode = "chemo"),
  list(name = "prior_nha_adt",     drugs = c("abiraterone", "enzalutamide", "apalutamide", "darolutamide"), mode = "combo"),
  list(name = "prior_docetaxel",   drugs = c("docetaxel"),             mode = "any"),
  list(name = "prior_abiraterone", drugs = c("abiraterone"),           mode = "any"),
  list(name = "prior_arpi",        drugs = c("abiraterone", "enzalutamide", "apalutamide", "darolutamide"), mode = "any")
)
# Register Q08/Q46 (ruled 2026-08-07): the spec spells these PRIOR_DOCITAXEL
#   (i, not e) and PRIOR+ABIRATERONE (plus sign, not underscore). The owner
#   ruled to correct both rather than reproduce the slips, so the delivered
#   names are PRIOR_DOCETAXEL and PRIOR_ABIRATERONE. Spec errata E13.
#   This diverges from the spec's column list deliberately - the spec is what
#   gets corrected. Anyone already coding against PRIOR_DOCITAXEL must change.

trt_prior_flags <- function(indx_tbl) {
  # regimen names are held on the drug-episode rows themselves
  base <- indx_tbl %>%
    left_join(enh_pros_pano_drugepisode %>%
                mutate(linename = tolower(linename)) %>%
                select(patientid, linename, episodedate, detaileddrugcategory),
              by = "patientid") %>%
    filter(episodedate < index_date)

  out <- indx_tbl
  for (spec in prior_spec) {
    # The predicates are built as plain strings and spliced in with !!.
    # Evaluating `spec$drugs` inside filter() would make dbplyr look for a
    # column called `drugs`.
    drug_alt  <- paste(spec$drugs, collapse = "|")
    like_pred <- if (is.null(spec$drugs)) NULL else like_any_sql(spec$drugs)
    # Separator class [,/], matching lotcat_expr's PARPi rule and the
    # combination predicate below; a comma-only class would make PRIOR_PARP
    # (the one flag using mode="only") miss slash-delimited PARPi regimens.
    only_pred <- paste0("LOWER(linename) REGEXP '^(", drug_alt, ")",
                        "([,/](", drug_alt, "))*$'")
    combo_sep <- "(LOWER(linename) LIKE '%,%' OR LOWER(linename) LIKE '%/%')"

    hit <- switch(spec$mode,
      # regimen contains the drug, alone or in combination
      any = base %>% filter(sql(!!like_pred)),
      # regimen is made up only of the listed drugs, no others allowed
      only = base %>% filter(sql(!!only_pred)),
      # any drug in a regimen flagged as chemotherapy
      chemo = base %>% filter(tolower(detaileddrugcategory) == 'chemotherapy'),
      # at least two drugs, at least one of which is an NHA
      combo = base %>% filter(sql(!!like_pred), sql(!!combo_sep))
    )

    hit <- hit %>%
      group_by(patientid, index_date) %>%
      summarise(hit_flag = 1L, .groups = "drop")

    out <- out %>%
      left_join(hit, by = c("patientid", "index_date")) %>%
      mutate(!!spec$name := ifelse(is.na(hit_flag), "No", "Yes")) %>%
      select(-hit_flag)
  }
  out
}

trt_var_creation <- function(input_ds, coh_flag) {
  ci       <- coh_info(coh_flag)
  indx_tbl <- input_ds %>% select(patientid, index_date) %>% distinct()

  # Line counts, one pair of variables per disease setting (register Q06, ruled
  # 2026-08-07). The spec's row 2 defines LOTN as the mCRPC count and its own
  # Additional Notes then asks "Do separate for mCRPC and mHSPC?" without
  # answering. The owner answered yes, so an mHSPC count is delivered alongside.
  #
  # mHSPC precedes mCRPC and not every patient progresses, so a cohort-1 or
  # cohort-3 patient who is on treatment but still hormone-sensitive has no
  # mCRPC lines and reads LOTN = 0. Without LOTN_MHSPC that line count is
  # absent from the ADS, and LOTN = 0 reads as "untreated" to anyone who does
  # not know the definition.
  #
  # Naming: the unsuffixed LOTN means mCRPC, because that is what the spec
  # named it. Only the new pair carries a suffix. Renaming LOTN to LOTN_MCRPC
  # would be more symmetrical but would break a name the spec gets right,
  # unlike the three corrected under Q08/Q46/Q17.
  lot_count_block <- function(lot_tbl_setting, sfx) {
    v_n   <- paste0("lotn", sfx)
    v_g   <- paste0("lotngr1", sfx)
    v_gn  <- paste0("lotngr1n", sfx)
    indx_tbl %>%
      left_join(lot_tbl_setting %>% select(patientid, new_lot_n), by = "patientid") %>%
      group_by(patientid, index_date) %>%
      summarise(n_lines = max(new_lot_n, na.rm = TRUE), .groups = "drop") %>%
      mutate(
        n_lines = ifelse(is.na(n_lines), 0, n_lines),
        !!v_n  := n_lines,
        !!v_g  := case_when(n_lines == 1 ~ '1', n_lines == 2 ~ '2',
                            n_lines == 3 ~ '3', n_lines == 4 ~ '4',
                            n_lines >= 5 ~ '5+', TRUE ~ '0'),
        !!v_gn := case_when(n_lines == 1 ~ 2, n_lines == 2 ~ 3,
                            n_lines == 3 ~ 4, n_lines == 4 ~ 5,
                            n_lines >= 5 ~ 6, TRUE ~ 1)
      ) %>%
      select(patientid, index_date, !!sym(v_n), !!sym(v_g), !!sym(v_gn))
  }

  lot_max_df <- lot_count_block(enh_pros_pano_lot_mcrpc, "") %>%
    left_join(lot_count_block(enh_pros_pano_lot_mhspc, "_mhspc"),
              by = c("patientid", "index_date"))

  # Both per-line blocks are built for every cohort, because TTNT for the
  # 1L mHSPC cohort reads LOT1SD_MCRPC.
  trt_lot_mhspc <- trt_lot_block(indx_tbl, "mHSPC")
  trt_lot_mcrpc <- trt_lot_block(indx_tbl, "mCRPC")

  trt_var_df <- indx_tbl %>%
    left_join(trt_lot_mhspc, by = c("patientid", "index_date")) %>%
    left_join(trt_lot_mcrpc, by = c("patientid", "index_date")) %>%
    left_join(lot_max_df,    by = c("patientid", "index_date")) %>%
    left_join(trt_prior_flags(indx_tbl), by = c("patientid", "index_date"))

  # CSD looks at the index line for the treated cohorts, and at any line in the
  # cohort's setting for the two overall cohorts (5C.TreatVars row 23).
  if (is.na(ci$lot_n)) {
    csd_hit <- indx_tbl %>%
      inner_join(lot_tbl(ci$setting) %>% select(patientid, linename), by = "patientid") %>%
      filter(sql("LOWER(linename) LIKE '%clinical study drug%'")) %>%
      group_by(patientid, index_date) %>%
      summarise(csd_flag = 1L, .groups = "drop")

    trt_var_df <- trt_var_df %>%
      left_join(csd_hit, by = c("patientid", "index_date")) %>%
      mutate(csd = ifelse(is.na(csd_flag), 0L, 1L)) %>%
      select(-csd_flag)
  } else {
    index_line_col <- paste0("lot", ci$lot_n,
                             if (ci$setting == "mHSPC") "_mhspc" else "_mcrpc")
    trt_var_df <- trt_var_df %>%
      mutate(csd = ifelse(
        sql(paste0("LOWER(", index_line_col, ") LIKE '%clinical study drug%'")),
        1L, 0L))
  }

  trt_var_df %>% distinct()
}

for (coh_flag in coh_list) {
  var_name <- paste0("enh_pros_pano_", coh_flag, "_trt_var_tbl")
  input_ds <- get(paste0("enh_pros_pano_", coh_flag, "_index_tbl"))
  df <- trt_var_creation(input_ds, coh_flag)
  createInPersonalSchema(df, stage_name(var_name), replace = TRUE)
  # Rebind to the materialized table, not the lazy query. Keeping the lazy
  # object would make every downstream stage re-expand the whole upstream
  # query, so the final ADS would be one enormous nested SELECT and the
  # intermediate writes would be paid for without ever being used.
  assign(var_name, tbl(con, in_schema(personal_schema, stage_name(var_name))))
  rm(df)
}
