# =============================================================================
# Clinical characteristics
# =============================================================================
# Implements sheet 5B.ClinChars.
# Sourced by the driver in numbered order. Not runnable on its own.
# RP1-RP4 and W1-W3 are the 2026-09-11 ruling's four rules and the three
# behaviours they withdraw, defined in docs/VARIABLES.md section 3.
# =============================================================================

# --- milestone dates, stage, Gleason, diagnosis PSA  (rows 2-16, 62, 65-67) --
clin_char_enh_pros_var <- function(input_ds) {
  input_ds %>%
    select(patientid, index_date) %>%
    left_join(enh_pros_pano, by = "patientid") %>%
    mutate(
      # mCRPC milestone
      mcrpcdd   = pmax(metastaticdiagnosisdate, crpcdate, na.rm = TRUE),
      mcrpcddyr = year(mcrpcdd),
      mcrpctype = crpctype,
      # mHSPC milestone (new in 202606)
      mhspcdd   = pmax(metastaticdiagnosisdate, hspcdate, na.rm = TRUE),
      mhspcddyr = year(mhspcdd),
      mhspctype = hspctype,
      # initial and metastatic diagnosis
      init    = diagnosisdate,
      inityr  = year(init),            # SPEC-Q: sheet prints Year(INITYR), self-referential
      mpcdd   = metastaticdiagnosisdate,
      mpcddyr = year(mpcdd),
      # time from initial diagnosis to each milestone, and the interval between
      ttcrpc = datediff(crpcdate, diagnosisdate) / days_per_month,
      tthspc = datediff(hspcdate, diagnosisdate) / days_per_month,
      # register Q10 (DECIDED): operands per the row's LABEL, not its printed
      #   formula, which was transposed. See the note at the parameters block.
      tintcrpchspc = datediff(crpcdate, hspcdate) / days_per_month,
      # STAGE is a prefix match, evaluated longest-first (5A.Demos row 12).
      # There is no 'CHECK' / 99 residual category in 202606.
      stage = case_when(
        sql("groupstage LIKE 'IV%'")  ~ 'IV',
        sql("groupstage LIKE 'III%'") ~ 'III',
        sql("groupstage LIKE 'II%'")  ~ 'II',
        sql("groupstage LIKE 'I%'")   ~ 'I',
        sql("groupstage LIKE '0%'")   ~ '0',
        TRUE ~ 'Unknown/not documented'),
      stagen = case_when(
        sql("groupstage LIKE '0%'")   ~ 1,
        sql("groupstage LIKE 'IV%'")  ~ 5,
        sql("groupstage LIKE 'III%'") ~ 4,
        sql("groupstage LIKE 'II%'")  ~ 3,
        sql("groupstage LIKE 'I%'")   ~ 2,
        TRUE ~ 99),  # no group stage recorded - fallthrough sentinel
      # GLEASON is banded in 202606 rather than carried as the raw score.
      # The source values are free text, not integers. The delivered value
      # for an unbroken-down 7 is "7 (not documented)"; the spec writes
      # "7 (when breakdown not available)", which appears nowhere in the data,
      # so both spellings are matched.
      gleason = case_when(
        gleasonscore %in% c('Less than or equal to 6', '3 + 4 = 7', '4 + 3 = 7',
                            '7 (not documented)',
                            '7 (when breakdown not available)') ~ '<8',
        gleasonscore %in% c('8', '9', '10') ~ '>=8',
        TRUE ~ 'Unknown/Missing'),
      # Register Q61 (RESOLVED 2026-08-08 by Onkar Kshirsagar): GLEASON has
      # exactly three categories - '<8', '>=8' and 'Unknown/Missing' - and
      # GLEASONN numbers them 1, 2, 3. Code 3 is the third real category, the
      # spec's own 'Unknown / Not documented', in the same way STAGEN's 5,
      # RACEN's 5 and ETHN's 3 are real categories.
      # Do not change this 3 to 99. The 99 convention (register Q50) is for
      # a fallthrough that no spec Values list provides - AGEGR1N, REGION1N,
      # PRACTICN, STAGEN's residual, COHORTUN. GLEASONN is not one of those:
      # its residual is enumerated, so 3 is a value and not a sentinel.
      gleasonn = case_when(
        gleason == '<8'   ~ 1,
        gleason == '>=8'  ~ 2,
        TRUE ~ 3),
      psadiag_init = psainitialdiagnosis,
      psadiag_met  = psametdiagnosis
    ) %>%
    # 4.StudyPop section A inclusion criteria. Naming follows the sheet's
    # 'TimePeriod_Variable' convention (time period ID_PD). Both bounds inclusive.
    mutate(
      id_pd_mcrpc = ifelse(!is.na(mcrpcdd) & mcrpcdd >= index_start &
                             mcrpcdd <= index_end, 1L, 0L),
      id_pd_mhspc = ifelse(!is.na(mhspcdd) & mhspcdd >= index_start &
                             mhspcdd <= index_end, 1L, 0L)
    ) %>%
    select(patientid, index_date, id_pd_mcrpc, id_pd_mhspc,
           mcrpcdd, mcrpcddyr, mcrpctype, mhspcdd, mhspcddyr, mhspctype,
           init, inityr, mpcdd, mpcddyr, ttcrpc, tthspc, tintcrpchspc,
           stage, stagen, gleason, gleasonn, psadiag_init, psadiag_met)
}

# --- PSA at the mCRPC milestone and at index  (rows 68-69) -------------------
# "the ScoreSerial that happens EARLIEST in a [-14, 0] day window" from the
# anchor, taking the maximum if several land on that earliest day.
clin_char_psa_var <- function(input_ds) {
  indx_tbl <- input_ds %>% select(patientid, index_date) %>% distinct()

  psadiag_crpc <- indx_tbl %>%
    left_join(enh_pros_pano %>% select(patientid, crpcdate), by = "patientid") %>%
    inner_join(enh_pros_pano_psa %>% select(patientid, scoreserial, resultdate),
               by = "patientid") %>%
    mutate(anch_dt = crpcdate, val_x = scoreserial, dt_x = resultdate) %>%
    earliest_value(-14, 0, "psadiag_crpc")

  psa_index <- indx_tbl %>%
    inner_join(enh_pros_pano_psa %>% select(patientid, scoreserial, resultdate),
               by = "patientid") %>%
    mutate(anch_dt = index_date, val_x = scoreserial, dt_x = resultdate) %>%
    earliest_value(-14, 0, "psa_index")

  indx_tbl %>%
    left_join(psadiag_crpc, by = c("patientid", "index_date")) %>%
    left_join(psa_index,    by = c("patientid", "index_date"))
}

# --- baseline ECOG  (rows 47-48) ---------------------------------------------
# 202606 splits this by cohort, because lines have been renumbered.
#
#   Cohorts 1-2 (overall): from either ECOG table, whichever record is closest
#     to the milestone date (HSPCDate or CRPCDate) - not to the index date.
#     Window [INDEX - 30, INDEX + 7]. Ties take the earlier record; several on
#     that day take the highest value.
#
#   Cohorts 3-7 (treated): from the baseline-ECOG table only, matched on the
#     cohort's own line number and line start date, then the same [-30, +7]
#     window (register Q56) and the record closest to index (Q30).
clin_char_ecog_var <- function(input_ds, coh_flag) {
  ci       <- coh_info(coh_flag)
  indx_tbl <- input_ds %>% select(patientid, index_date) %>% distinct()

  if (is.na(ci$lot_n)) {
    milestone_col <- if (ci$setting == "mHSPC") "hspcdate" else "crpcdate"

    pooled <- enh_pros_pano_bl_ecog %>%
      select(patientid, ecogdate, ecogvalue) %>%
      union_all(enh_pros_pano_ecog %>% select(patientid, ecogdate, ecogvalue))

    pull <- indx_tbl %>%
      inner_join(pooled, by = "patientid") %>%
      left_join(enh_pros_pano %>%
                  select(patientid, anchor_dt = !!sym(milestone_col)),
                by = "patientid") %>%
      filter(ecogdate >= dbplyr::sql("DATE_SUB(index_date, 30)"),
             ecogdate <= dbplyr::sql("DATE_ADD(index_date, 7)")) %>%
      # !! - see the note in 02_demographics.R. Without it dbplyr emits a
      # literal safe_int(...) call that Databricks cannot resolve.
      mutate(ecogvalue = !!safe_int(ecogvalue),
             gap = abs(datediff(ecogdate, anchor_dt)))

    min_gap <- pull %>%
      group_by(patientid, index_date) %>%
      summarise(min_gap = min(gap, na.rm = TRUE), .groups = "drop")

    # ties on the gap -> the earlier date, i.e. the record before the anchor
    winning_dt <- pull %>%
      inner_join(min_gap, by = c("patientid", "index_date")) %>%
      filter(gap == min_gap) %>%
      group_by(patientid, index_date) %>%
      summarise(ecogdate = min(ecogdate, na.rm = TRUE), .groups = "drop")

    ecog_value <- pull %>%
      inner_join(winning_dt, by = c("patientid", "index_date", "ecogdate")) %>%
      group_by(patientid, index_date, ecogdate) %>%
      summarise(ecogvalue = max(ecogvalue, na.rm = TRUE), .groups = "drop")

  } else {
    coh_lot_n <- ci$lot_n
    line_i <- lot_tbl(ci$setting) %>%
      filter(new_lot_n == !!coh_lot_n) %>%
      select(patientid, linenumber, line_startdate = startdate)

    matched <- indx_tbl %>%
      inner_join(line_i, by = "patientid") %>%
      inner_join(enh_pros_pano_bl_ecog %>%
                   select(patientid, linenumber, linestartdate, ecogdate, ecogvalue),
                 by = c("patientid", "linenumber")) %>%
      filter(linestartdate == line_startdate) %>%
      # The [INDEX-30, INDEX+7] window applies here too. 3.Data Prep defines the
      # time period LOT_ECOG as "ECOG assessment period [INDEX - 30 through
      # INDEX + 7]", and LOT_ECOG is the Time Period on the ECOG row for all
      # seven cohorts. Without this bound, a baseline ECOG recorded months
      # before the line would still count. Register Q56.
      filter(ecogdate >= dbplyr::sql("DATE_SUB(index_date, 30)"),
             ecogdate <= dbplyr::sql("DATE_ADD(index_date, 7)")) %>%
      mutate(ecogvalue = !!safe_int(ecogvalue))

    # Resolve the date first, then take the value on that date. Summarising the
    # date and max(ecogvalue) in one step would let the two come from different
    # records when a patient has several baseline rows for the line.
    #
    # Register Q30 (RULED 2026-08-07): closest to index, then highest value -
    # the same shape cohorts 1-2 use, so all seven cohorts share one date
    # rule. The spec states a date rule only for cohorts 1-2; for 3-7 it gives
    # just linenumber + linestartdate and assumes that match is unique. It is
    # not - the baseline-ECOG table has duplicates on that key. Ties on
    # distance take the earlier record, matching the tie-break the spec does
    # state for cohorts 1-2.
    matched <- matched %>%
      mutate(gap = abs(datediff(ecogdate, index_date)))

    ecog_dt <- matched %>%
      inner_join(matched %>%
                   group_by(patientid, index_date) %>%
                   summarise(min_gap = min(gap, na.rm = TRUE), .groups = "drop"),
                 by = c("patientid", "index_date")) %>%
      filter(gap == min_gap) %>%
      group_by(patientid, index_date) %>%
      summarise(ecogdate = min(ecogdate, na.rm = TRUE), .groups = "drop")

    ecog_value <- matched %>%
      inner_join(ecog_dt, by = c("patientid", "index_date", "ecogdate")) %>%
      group_by(patientid, index_date, ecogdate) %>%
      summarise(ecogvalue = max(ecogvalue, na.rm = TRUE), .groups = "drop")
  }

  # Label. The spec's ECOG Values are '0','1','2','3','4','Unknown/Missing' -
  # six categories, with unknown and missing combined - and ECOGN is 1..6.
  # Do not split Unknown (record exists with a null value) from Missing (no
  # record at all): the distinction is real but is not what the spec asks for.
  # Register Q23.
  ecog_value %>%
    # Only 0-4 are ECOG values. Anything else - a 5, a stray code - is
    # Unknown/Missing, not a new label. Without this clamp the label would
    # take any value while ECOGN maps it to 6, so ECOG="5" would ship
    # alongside ECOGN=6 (Unknown/Missing) and the pair would disagree.
    mutate(ecog = case_when(is.na(ecogvalue) ~ "Unknown/Missing",
                            ecogvalue < 0 | ecogvalue > 4 ~ "Unknown/Missing",
                            TRUE ~ as.character(ecogvalue))) %>%
    select(patientid, index_date, ecogdate, ecog) %>%
    right_join(indx_tbl, by = c("patientid", "index_date")) %>%
    mutate(
      ecog = case_when(is.na(ecog) ~ 'Unknown/Missing', TRUE ~ ecog),
      ecogn = case_when(
        ecog == '0' ~ 1, ecog == '1' ~ 2, ecog == '2' ~ 3,
        ecog == '3' ~ 4, ecog == '4' ~ 5,
        TRUE ~ 6)
    ) %>%
    select(patientid, index_date, ecogdate, ecog, ecogn)
}

# --- baseline laboratory values  (rows 17-46) --------------------------------
# Three variables per analyte: LAB<xxx> (Present/Unknown/Missing), LAB<xxx>V
# (value) and LAB<xxx>DT (date). The record closest to index wins; where several
# share that date the analyte's own tie rule applies. Time period is PRE_INT -
# all data up to and including index. testdate = max(resultdate, testdate).
lab_spec <- list(
  list(sfx = "neu", var = "labneu", vdt = "labneudt",   test = "neutrophils",                unit = "10*9/L", component = NA,                  tie = "min"),
  list(sfx = "pla", var = "labpla", vdt = "labplavdt",  test = "platelets",                  unit = "10*9/L", component = NA,                  tie = "min"),
  list(sfx = "hem", var = "labhem", vdt = "labhemdt",   test = "hemoglobin",                 unit = "g/dL",   component = NA,                  tie = "min"),
  list(sfx = "cre", var = "labcre", vdt = "labcredt",   test = "creatinine",                 unit = "mg/dL",  component = "Creatinine, serum", tie = "min"),
  list(sfx = "bil", var = "labbil", vdt = "labbildt",   test = "bilirubin",                  unit = "mg/dL",  component = NA,                  tie = "max"),
  list(sfx = "ast", var = "labast", vdt = "labastdt",   test = "aspartate aminotransferase", unit = "U/L",    component = NA,                  tie = "max"),
  list(sfx = "alt", var = "labalt", vdt = "labaltdt",   test = "alanine aminotransferase",   unit = "U/L",    component = NA,                  tie = "max"),
  list(sfx = "alp", var = "labalp", vdt = "labalpdt",   test = "alkaline phosphatase",       unit = "U/L",    component = NA,                  tie = "max"),
  # register Q25 (RESOLVED 2026-08-07): the spec's testunitscleaned='g/L'
  #   filter is applied, like every other analyte here. In t_lab,
  #   labcomponent='Albumin, serum' carries unit 'g/L' on 4,966,771 rows /
  #   308,946 patients, median 40, which is serum albumin in g/L (35-50);
  #   g/dL would read 3.5-5.0. The filter keeps the scale right by
  #   construction - a future row in a different unit is excluded instead
  #   of being silently averaged into a g/L column.
  #   labcomponent also keeps out the urine variants, which are mg/L and mg/d,
  #   and 'Albumin [mass/volume] in serum by electrophoresis' (181,577 rows,
  #   also g/L), which is a different assay.
  list(sfx = "alb", var = "labalb", vdt = "labalbdt",   test = "albumin",                    unit = "g/L",    component = "Albumin, serum",    tie = "min"),
  list(sfx = "lym", var = "lablym", vdt = "lablymdt",   test = "lymphocytes",                unit = "10*9/L", component = NA,                  tie = "max")
)
# LABPLA: no spec defect. Register Q55 (RESOLVED 2026-08-08 by Onkar
#   Kshirsagar): the owner confirmed against the spec text that the Present
#   clause reads testbasename='platelets', matching its own Missing clause.
#   The filter below is 'platelets'; no delivered value was affected.
# SPEC-Q: LABBIL's unit filter reads '10*9/L' while its label says mg/dL. This
#   limb of Q07 is corroborated by the spec text and by the data (bilirubin is
#   populated at mg/dL, 4,923,058 rows), so it is coded to the clinically
#   intended unit.
# SPEC-Q: the platelet date variable is named LABPLAVDT (not LABPLADT) in the
#   spec; reproduced verbatim.

# Every analyte must name a unit. clin_char_lab_one() applies the unit filter
# unconditionally, so an entry without one would build a filter against the
# string "NA" and quietly empty that analyte.
stopifnot(all(vapply(lab_spec, function(x) !is.na(x$unit), logical(1))))

clin_char_lab_one <- function(indx_tbl, spec) {
  v_flag <- spec$var
  v_val  <- paste0(spec$var, "v")
  v_dt   <- spec$vdt
  # Pulled out as locals and spliced with !!: dbplyr reads `spec$test` inside a
  # verb as a SQL column reference rather than an R value.
  s_test <- spec$test
  s_unit <- spec$unit
  s_comp <- spec$component

  # "Missing" means no record for the analyte at all. Where the spec's Present
  # clause is qualified by LABCOMPONENT, its Missing clause is too, so the same
  # component filter applies to both.
  analyte <- enh_pros_pano_lab %>% filter(tolower(testbasename) == !!s_test)
  if (!is.na(s_comp)) {
    analyte <- analyte %>% filter(labcomponent == !!s_comp)
  }

  # Register Q58: the Missing test is not time-bounded. The spec draws the
  # distinction inside one sentence - Present "in the time period" against
  # Missing "in the T_LAB_&DATE table" - and it is followed literally, so a
  # patient tested only after index reads 'Unknown', not 'Missing'.
  #
  # For the data dictionary: 'Unknown' is not a baseline quality signal. It
  # mixes a few percent with an unusable baseline record and ~39% who simply
  # tested later (182k-202k rows per analyte). 'Missing' means the strict
  # thing: never tested, at any date. LAB*V and LAB*DT stay windowed to index.
  any_rec <- indx_tbl %>%
    inner_join(analyte %>% distinct(patientid), by = "patientid") %>%
    mutate(has_any = 1L) %>%
    select(patientid, index_date, has_any)

  # Records additionally meeting the "Present" criteria. The unit filter
  # belongs here and not in any_rec above: the spec's Missing clause names
  # only testbasename and labcomponent, so a record in the wrong unit makes
  # the analyte 'Unknown', not 'Missing'.
  qualifying <- analyte %>%
    filter(!is.na(testdate), testresultcleaned > 0)
  # Every lab_spec entry names a unit, so the filter is unconditional; the
  # assertion at lab_spec makes a missing unit loud instead of silently
  # applying no unit filter at all.
  #
  # Register Q69 (2026-08-08): TRIM both sides. The spec writes hemoglobin's
  # unit as ' g/dL' with a leading space, alone among the ten analytes - the
  # others are '10*9/L', 'mg/dL', 'U/L', 'g/L'. Comparing trimmed values makes
  # the two readings of that cell select identical rows, so the question stops
  # needing an answer. It also guards the source side, which nothing else
  # checks: a stray space in testunitscleaned would silently empty an analyte,
  # and that failure looks exactly like "this lab was never done".
  # Applied to all ten analytes, not just hemoglobin - a robustness rule that
  # holds for one column and not its nine siblings is a trap, not a rule.
  qualifying <- qualifying %>%
    filter(sql(!!paste0("TRIM(testunitscleaned) = '", trimws(s_unit), "'")))

  # PRE_INT: all data through index, so no lower bound on the window
  value <- indx_tbl %>%
    inner_join(qualifying %>% select(patientid, testdate, resultdate, testresultcleaned),
               by = "patientid") %>%
    mutate(anch_dt = index_date,
           val_x   = testresultcleaned,
           dt_x    = pmax(testdate, resultdate, na.rm = TRUE)) %>%
    closest_value(NULL, 0, v_val, v_dt, agg = spec$tie)

  indx_tbl %>%
    left_join(any_rec, by = c("patientid", "index_date")) %>%
    left_join(value,   by = c("patientid", "index_date")) %>%
    mutate(!!v_flag := case_when(
      !is.na(!!sym(v_val)) ~ "Present",   # qualifying record found
      !is.na(has_any)      ~ "Unknown",   # record exists but fails the criteria
      TRUE                 ~ "Missing")) %>%
    select(patientid, index_date, !!sym(v_flag), !!sym(v_val), !!sym(v_dt))
}

clin_char_lab_var <- function(input_ds) {
  indx_tbl <- input_ds %>% select(patientid, index_date) %>% distinct()
  out <- indx_tbl
  for (spec in lab_spec) {
    out <- out %>%
      left_join(clin_char_lab_one(indx_tbl, spec), by = c("patientid", "index_date"))
  }
  out
}

# --- blood pressure  (rows 49-53) --------------------------------------------
# BP requires a systolic and a diastolic reading on the same TESTDATE, both
# positive. TESTRESULT is used, not TESTRESULTCLEANED (mostly unpopulated).
clin_char_bp_var <- function(input_ds) {
  indx_tbl <- input_ds %>% select(patientid, index_date) %>% distinct()

  bp_src <- enh_pros_pano_vitals %>%
    filter(tolower(test) %in% c('systolic blood pressure',
                                'diastolic blood pressure')) %>%
    select(patientid, test, testdate, testresult)

  # Any record at all, either arm, at any date -> not "Missing". Register Q58
  # (RULED 2026-08-08 by Onkar Kshirsagar), the same ruling applied to the labs
  # above: the spec's Missing clause ("If no record of diastolic and no record
  # of systolic") carries no time qualifier and is followed literally. 144,079
  # of 515,406 delivered rows (27.9%) move Missing -> Unknown as a result
  # (05_sizing_queries.sql S1b, 2026m06). BPDT, BPSYS and BPDIA are unaffected -
  # they come from bp_raw, which stays windowed to index.
  any_rec <- indx_tbl %>%
    inner_join(bp_src %>% distinct(patientid), by = "patientid") %>%
    mutate(has_any = 1L) %>%
    select(patientid, index_date, has_any)

  bp_raw <- indx_tbl %>%
    inner_join(bp_src, by = "patientid") %>%
    filter(testdate <= index_date) %>%
    mutate(bpval = !!safe_num(testresult))

  # Register Q67 (RULED 2026-08-08 by Onkar Kshirsagar): the spec requires a
  # positive integer, and states it twice - "TESETRESULT is a positive integer
  # and not NULL" for Present, and "If one of diastolic or systolic records is
  # 0 or NOT A POSITIVE INTEGER or is null then = Unknown". Testing only > 0
  # would let a fractional reading count as Present.
  #
  # The test is on the value, not on the text: TRY_CAST('120.0' AS DOUBLE) is
  # 120.0, which equals its own ROUND, so a value written with a decimal point
  # still qualifies. Only a genuinely fractional reading such as 120.5 moves,
  # and it moves to Unknown - which is what the Unknown clause says to do
  # with it.
  bp_ok <- function(tb) tb %>% filter(bpval > 0, bpval == round(bpval))

  # dates where both arms are present and both are positive integers
  valid_dates <- bp_raw %>%
    bp_ok() %>%
    mutate(
      is_sys = ifelse(tolower(test) == 'systolic blood pressure',  1L, 0L),
      is_dia = ifelse(tolower(test) == 'diastolic blood pressure', 1L, 0L)) %>%
    group_by(patientid, index_date, testdate) %>%
    summarise(n_sys = max(is_sys, na.rm = TRUE),
              n_dia = max(is_dia, na.rm = TRUE), .groups = "drop") %>%
    filter(n_sys > 0, n_dia > 0) %>%
    select(patientid, index_date, testdate)

  bpdt <- valid_dates %>%
    mutate(gap = abs(datediff(testdate, index_date))) %>%
    group_by(patientid, index_date) %>%
    summarise(min_gap = min(gap, na.rm = TRUE), .groups = "drop") %>%
    inner_join(valid_dates %>% mutate(gap = abs(datediff(testdate, index_date))),
               by = c("patientid", "index_date")) %>%
    filter(gap == min_gap) %>%
    group_by(patientid, index_date) %>%
    summarise(bpdt = min(testdate, na.rm = TRUE), .groups = "drop")

  # highest value on that date, per arm
  arm_value <- function(arm, out_name) {
    bp_raw %>%
      filter(tolower(test) == arm) %>%
      bp_ok() %>%
      inner_join(bpdt, by = c("patientid", "index_date")) %>%
      filter(testdate == bpdt) %>%
      group_by(patientid, index_date) %>%
      summarise(!!out_name := max(bpval, na.rm = TRUE), .groups = "drop")
  }

  indx_tbl %>%
    left_join(any_rec, by = c("patientid", "index_date")) %>%
    left_join(bpdt,    by = c("patientid", "index_date")) %>%
    left_join(arm_value('systolic blood pressure',  "bpsys"), by = c("patientid", "index_date")) %>%
    left_join(arm_value('diastolic blood pressure', "bpdia"), by = c("patientid", "index_date")) %>%
    mutate(
      bp = case_when(
        !is.na(bpdt)    ~ "Present",
        !is.na(has_any) ~ "Unknown",
        TRUE            ~ "Missing"),
      bpn = case_when(bp == "Present" ~ 1, bp == "Unknown" ~ 2, TRUE ~ 3)
    ) %>%
    select(patientid, index_date, bp, bpn, bpdt, bpsys, bpdia)
}

# --- concomitant medication flags  (rows 54-56) ------------------------------
# CSF_PRE / CSF_FU  - DETAILEDDRUGCATEGORY = 'growth factor'
# SS                - DRUGCATEGORY         = 'steroid'
# Sources: drugepisode, medicationorder (excluding cancelled), medicationadmin.
conmed_flag <- function(indx_tbl, category_col, category_val, window, out_name,
                        fu_bound = NULL) {
  cat_col <- sym(category_col)

  ep <- enh_pros_pano_drugepisode %>%
    filter(tolower(!!cat_col) == category_val) %>%
    select(patientid, dt = episodedate)
  mo <- enh_pros_pano_medorder %>%
    filter(tolower(!!cat_col) == category_val,
           is.na(iscanceled) | tolower(iscanceled) != 'true') %>%
    select(patientid, dt = expectedstartdate)
  ma <- enh_pros_pano_medadmin %>%
    filter(tolower(!!cat_col) == category_val) %>%
    select(patientid, dt = administereddate)

  joined <- indx_tbl %>%
    inner_join(ep %>% union_all(mo) %>% union_all(ma), by = "patientid")

  joined <- if (window == "pre") {
    joined %>% filter(dt <= index_date)
  } else {
    # Register Q39 (RULED 2026-08-07): the follow-up window is bounded at FUED.
    # An open-ended window would let a growth-factor order years after the
    # patient left follow-up set the flag - which no other FU variable does.
    #
    # Q82 changed what FUED can be, in three ways, and they do NOT all point
    # the same way.
    #
    # Two close the window. A NULL FUED makes `dt <= fued` UNKNOWN so no row
    # qualifies; a FUED before the index makes the window empty. Either way
    # the patient reads 0, which is right - there is no follow-up period to
    # have had a growth factor in.
    #
    # The third OPENS it, and is the larger effect. Before the ruling, a
    # patient whose death fell AFTER their last recorded activity kept
    # FU_ENDDT_preliminary as their FUED - the old clamp only pulled FUED
    # back, never forward. FUED is now DTHDT for that patient, which is
    # later, so the window extends and CSF_FU can move 0 -> 1. None of the
    # three growth-factor sources (drug episode, medication order, medication
    # admin) feeds FU_ENDDT_preliminary, so a qualifying record inside
    # (last activity, death] is ordinary rather than rare. This is the
    # population the 2026-09-11 clarification was written about; qc/06's P9
    # profile pulls it and register Q39 records the movement.
    joined %>%
      inner_join(fu_bound, by = c("patientid", "index_date")) %>%
      filter(dt > index_date, dt <= fued)
  }

  hit <- joined %>%
    group_by(patientid, index_date) %>%
    summarise(hit_flag = 1L, .groups = "drop")

  indx_tbl %>%
    left_join(hit, by = c("patientid", "index_date")) %>%
    mutate(!!out_name := ifelse(is.na(hit_flag), 0L, 1L)) %>%
    select(patientid, index_date, !!sym(out_name))
}

# fu_tbl is passed in, not re-derived. CSF_FU is bounded at the patient's own
# follow-up end (Q39). Since Q82 the derivation is a patient-level stage table
# rather than a per-cohort cascade, so the old reason for threading it - not
# rendering an intricate imputation twice - has shrunk to simply not joining
# the same stage twice. Threading it still costs nothing and keeps one
# definition, so it stays.
clin_char_conmed_var <- function(input_ds, fu_tbl) {
  indx_tbl <- input_ds %>% select(patientid, index_date) %>% distinct()
  fu_bound <- fu_tbl %>% select(patientid, index_date, fued)
  indx_tbl %>%
    left_join(conmed_flag(indx_tbl, "detaileddrugcategory", "growth factor", "pre", "csf_pre"),
              by = c("patientid", "index_date")) %>%
    left_join(conmed_flag(indx_tbl, "detaileddrugcategory", "growth factor", "fu",  "csf_fu", fu_bound),
              by = c("patientid", "index_date")) %>%
    left_join(conmed_flag(indx_tbl, "drugcategory", "steroid", "pre", "ss"),
              by = c("patientid", "index_date"))
}

# --- vitals: weight, height, BMI, BSA  (rows 57-64) --------------------------
clin_char_vitals_var <- function(input_ds) {
  indx_tbl <- input_ds %>% select(patientid, index_date) %>% distinct()

  bl_vitals_pull <- indx_tbl %>%
    inner_join(
      enh_pros_pano_vitals %>%
        # Register Q68 (RULED 2026-08-08 by Onkar Kshirsagar): spec-literal.
        # 5B.ClinChars r194-197 qualifies a vitals record on "where
        # TESTRESULTCLEANED is not null" and nothing else. Do not add a
        # `testresultcleaned > 0` filter - the spec does not state it, and
        # the owner ruled to implement what is written, the same call as Q66.
        # WEIGHT and HEIGHT therefore carry any non-null cleaned value.
        #
        # The division guard lives at BMI, where it belongs: see the note
        # there. Excluding the record and guarding the arithmetic are
        # different things, and only the second is forced.
        #
        # qc/09_vitals_domain.sql counts non-positive height and weight, so
        # the consequence of this ruling is measured rather than assumed.
        filter(((tolower(test) == 'body height' & testunitscleaned == "cm") |
                (tolower(test) == 'body weight' & testunitscleaned == "kg")) &
               !is.na(testresultcleaned)) %>%
        select(patientid, test, testdate, resultdate, testresultcleaned, testunitscleaned),
      by = "patientid") %>%
    # Group on the lower-cased name. The filter above is case-insensitive, so
    # grouping by the raw value would make "Body Height" and "body height" two
    # separate winners that both join back and fan the patient out.
    mutate(test = tolower(test),
           vitaldate = pmax(testdate, resultdate, na.rm = TRUE)) %>%
    filter(vitaldate <= index_date)

  bl_max_vitaldate <- bl_vitals_pull %>%
    group_by(patientid, index_date, test) %>%
    summarise(vitaldate = max(vitaldate, na.rm = TRUE), .groups = "drop")

  bl_vital_value <- bl_max_vitaldate %>%
    inner_join(bl_vitals_pull, by = c("patientid", "index_date", "test", "vitaldate")) %>%
    group_by(patientid, index_date, test, vitaldate) %>%
    summarise(vitalvalue = max(testresultcleaned, na.rm = TRUE), .groups = "drop")

  indx_tbl %>%
    left_join(bl_vital_value %>% filter(tolower(test) == 'body height') %>%
                select(patientid, index_date, heightdt = vitaldate, height = vitalvalue),
              by = c("patientid", "index_date")) %>%
    left_join(bl_vital_value %>% filter(tolower(test) == 'body weight') %>%
                select(patientid, index_date, weightdt = vitaldate, weight = vitalvalue),
              by = c("patientid", "index_date")) %>%
    mutate(
      # The guard is exactly the case where the spec's formula has no value:
      # height = 0, which divides by zero. Nothing else. Under ANSI that
      # raises and the build dies; here it gives NULL, BMIGR1 'Missing',
      # BMIGR1N 5 - what the formula delivers under legacy Spark. Same
      # reasoning as the PSABL > 0 guard ruled under Q59.
      #
      # Do not extend the guard to `height > 0 & weight > 0`: Q68 ruled
      # "do not filter on sign", and the formula is well defined for a
      # negative weight or height, so excluding them is an unapproved value
      # change. qc/09_vitals_domain.sql counts the non-positive readings,
      # which is where that question belongs.
      bmi = case_when(
        (!is.na(weight) & !is.na(height) & height != 0) ~
          (weight / (height / 100)^2),
        TRUE ~ NA),
      # The band is the spec's: below 18.5 is Underweight, with no lower bound.
      # Do not add `bmi > 0`: that is the same filter-on-sign Q68 rules
      # against, one level down, and it would send a negative BMI to 'Missing'
      # while BMI itself stays populated - the value and its band disagreeing
      # on a rule the spec does not state. 'Missing' means exactly one thing:
      # BMI could not be computed. R56 gates it, qc/09 counts the readings
      # that get here.
      bmigr1 = case_when(
        (bmi < 18.5)             ~ 'Underweight',
        (bmi >= 18.5 & bmi < 25) ~ 'Normal weight',
        (bmi >= 25 & bmi < 30)   ~ 'Overweight',
        (bmi >= 30)              ~ 'Obese',
        TRUE ~ 'Missing'),
      bmigr1n = case_when(
        (bmi < 18.5) ~ 1, (bmi >= 18.5 & bmi < 25) ~ 2,
        (bmi >= 25 & bmi < 30) ~ 3, (bmi >= 30) ~ 4, TRUE ~ 5),
      # Height and weight need not share a date (5B.ClinChars row 64 note).
      # The guard is again exactly the undefined case, but a different one:
      # POWER() of a negative base with a fractional exponent is NaN, not an
      # error, so an unguarded BSA would deliver NaN rather than fail. NaN is
      # worse than NULL - it survives the null sweep, IS NULL does not catch
      # it, and it poisons any downstream mean.
      # Zero is allowed through: POWER(0, 0.725) is 0, so BSA is defined.
      bsa = case_when(
        (!is.na(weight) & !is.na(height) & height >= 0 & weight >= 0) ~
          (0.007184 * (height)^0.725 * (weight)^0.425),
        TRUE ~ NA)
    ) %>%
    select(patientid, index_date, weight, weightdt, height, heightdt,
           bmi, bmigr1, bmigr1n, bsa)
}

# --- biomarker status at index  (rows 70-77) ---------------------------------
# Test date = max(specimencollecteddate, resultdate). Window [-30, +7] around
# index, from the Additional Notes; the definition body gives no bound. Ties
# prefer the test before index. Where several share the winning date the spec's
# collision table applies:
#   pos+neg -> Unknown | pos+neg+unk -> Unknown | pos+unk -> Positive
#   neg+unk -> Negative
# Register Q04: the spec says SPECIMENRECEIVEDDATE; the table has COLLECTED.
# BRCA panel. The HRR panel is a parameter and lives in the setup module.
brca_genes <- c("BRCA1", "BRCA2")

# What the panel restriction costs - genes present in the table but off the
# active panel - is reported by validation/01_preflight.R (qcr_hrr_excluded_r,
# Q44), not here.

biomarker_status <- function(indx_tbl, genes, prefix) {
  v_stat <- paste0(prefix, "_index")
  v_num  <- paste0(prefix, "_indexn")

  # Window: [-30, +7] around index. 5B.ClinChars carries this on both the
  # HRR_INDEX and BRCA_INDEX rows. 3.Data Prep Section C says "on or any time
  # prior to index date" instead; the two sheets contradict each other and the
  # owner ruled for the 5B window (register Q20, resolved 2026-08-07).
  win_lo <- dbplyr::sql("DATE_SUB(index_date, 30)")
  win_hi <- dbplyr::sql("DATE_ADD(index_date, 7)")

  # Winning test date (register Q37, SME ruling 2026-08-07): the biomarker test
  # closest to index, taken over all biomarker tests - every gene, every test
  # type. Test type is not a selection criterion, which is also why
  # HRR_INDEX_TEST / BRCA_INDEX_TEST stay 'Unknown' (Q03).
  #
  # One date per patient, computed on the unfiltered table so the HRR and BRCA
  # calls share it. Worked example from the SME: index 7 Feb, ATM Negative on
  # 30 Jan, BRCA Positive on 25 Jan -> 30 Jan wins (8 days out, against 13), so
  # HRR reads ATM and is Negative. BRCA has no result on 30 Jan, so BRCA_INDEX
  # is Unknown - not Positive. Sharing the date is what stops HRR and BRCA
  # contradicting each other, which is the invariant V2c gates: resolving the
  # date separately per panel gives HRR=Negative with BRCA=Positive on
  # exactly this shape.
  #
  # Equidistant before and after -> take the earlier, i.e. the pre-index test.
  # That tie-break is the spec's, on both the HRR_INDEX and BRCA_INDEX rows.
  win <- indx_tbl %>%
    inner_join(enh_pros_pano_biomark %>%
                 select(patientid, resultdate, specimencollecteddate),
               by = "patientid") %>%
    mutate(testdt = pmax(specimencollecteddate, resultdate, na.rm = TRUE)) %>%
    filter(testdt >= !!win_lo, testdt <= !!win_hi) %>%
    mutate(gap = abs(datediff(testdt, index_date)))

  win <- win %>%
    inner_join(win %>%
                 group_by(patientid, index_date) %>%
                 summarise(min_gap = min(gap, na.rm = TRUE), .groups = "drop"),
               by = c("patientid", "index_date")) %>%
    filter(gap == min_gap) %>%
    group_by(patientid, index_date) %>%
    summarise(win_dt = min(testdt, na.rm = TRUE), .groups = "drop")

  # Every caller passes a non-empty gene list: Q44 froze flatiron_all to
  # nineteen named symbols, so there is no NULL-means-every-gene branch;
  # an empty list is a mistake, not a wildcard.
  stopifnot(length(genes) > 0L)
  src <- enh_pros_pano_biomark %>% filter(toupper(biomarkername) %in% !!genes)

  # STEP A - resolve within each gene, on the shared winning date (Q29).
  # The spec gives four same-date collision rules, all reproduced below:
  #   Positive+Negative         -> Unknown
  #   Positive+Negative+Unknown -> Unknown
  #   Positive+Unknown          -> Positive
  #   Negative+Unknown          -> Negative
  # The spec never mentions VUS. The SME ruled two of the three VUS pairs
  # (2026-08-07): VUS+Unknown -> Unknown/Not documented, and Negative+VUS ->
  # Negative, on the same reasoning as Negative+Unknown - a definite negative
  # call is knowledge, a VUS is not. Positive+VUS -> Positive is still decided
  # here rather than ruled on. See Q29.
  per_gene <- indx_tbl %>%
    inner_join(src %>% mutate(biomarkername = toupper(biomarkername)) %>%
                 select(patientid, biomarkername, biomarkerstatus,
                              resultdate, specimencollecteddate),
               by = "patientid") %>%
    mutate(testdt = pmax(specimencollecteddate, resultdate, na.rm = TRUE)) %>%
    filter(testdt >= !!win_lo, testdt <= !!win_hi) %>%
    inner_join(win, by = c("patientid", "index_date")) %>%
    filter(testdt == win_dt) %>%
    mutate(
      # Delivered BIOMARKERSTATUS values are 'Positive', 'Negative', 'VUS' and
      # 'Unknown-not-documented'. The spec writes 'Mutation Negative', which
      # never occurs, so the match is on 'negative' (register Q18, approved).
      is_pos = ifelse(sql("LOWER(biomarkerstatus) LIKE '%positive%'"), 1L, 0L),
      is_neg = ifelse(sql("LOWER(biomarkerstatus) LIKE '%negative%'"), 1L, 0L),
      is_vus = ifelse(sql("LOWER(biomarkerstatus) LIKE '%vus%'"), 1L, 0L),
      is_unk = ifelse(sql("LOWER(biomarkerstatus) LIKE '%unknown%'"), 1L, 0L)) %>%
    group_by(patientid, index_date, biomarkername) %>%
    summarise(g_pos = max(is_pos, na.rm = TRUE),
              g_neg = max(is_neg, na.rm = TRUE),
              g_vus = max(is_vus, na.rm = TRUE),
              g_unk = max(is_unk, na.rm = TRUE), .groups = "drop") %>%
    mutate(gene_rank = case_when(
      g_pos == 1 & g_neg == 1 ~ 4L,   # spec: contradictory -> Unknown
      g_pos == 1              ~ 1L,   # spec: Pos+Unknown -> Pos; ours: Pos+VUS -> Pos
      g_neg == 1              ~ 2L,   # spec: Neg+Unknown -> Neg; SME: Neg+VUS -> Neg
      g_vus == 1 & g_unk == 1 ~ 4L,   # SME: VUS+Unknown -> Unknown/Not documented
      g_vus == 1              ~ 3L,   # VUS - ranks BELOW Negative (Q29, ruled)
      TRUE                    ~ 4L))  # Unknown / not documented

  # STEP B - roll up across genes, best (lowest) rank wins (register Q29).
  # Positive > Negative > VUS > Unknown, ruled 2026-08-07. The spec has no
  # cross-gene rollup at all - it assumed one aggregated value - so this step is
  # a decision, not a reading.
  # Ranking VUS above Negative would let a single VUS gene outrank several
  # clean negatives and contradict the within-gene ruling in STEP A, where
  # Negative+VUS resolves to Negative.
  # The ordering also matches the spec's own parsing cascade, Positive >
  # Negative > VUS - precedence for words inside one status string rather than
  # a rule for combining tests, but the only ordering the spec ever states.
  # The internal rank equals the delivered coding: 1=Positive, 2=Negative,
  # 3=VUS, 4=Unknown.
  collapsed <- per_gene %>%
    group_by(patientid, index_date) %>%
    summarise(best_rank = min(gene_rank, na.rm = TRUE), .groups = "drop")

  indx_tbl %>%
    left_join(collapsed, by = c("patientid", "index_date")) %>%
    mutate(
      !!v_stat := case_when(
        is.na(best_rank)  ~ "Unknown/Not documented",
        best_rank == 1    ~ "Positive",
        best_rank == 2    ~ "Negative",
        best_rank == 3    ~ "VUS",
        TRUE              ~ "Unknown/Not documented")) %>%
    mutate(
      !!v_num := case_when(
        !!sym(v_stat) == "Positive" ~ 1,
        !!sym(v_stat) == "Negative" ~ 2,
        !!sym(v_stat) == "VUS"      ~ 3,
        TRUE ~ 4)) %>%
    select(patientid, index_date, !!sym(v_stat), !!sym(v_num))
}

clin_char_biomarker_var <- function(input_ds) {
  indx_tbl <- input_ds %>% select(patientid, index_date) %>% distinct()

  indx_tbl %>%
    left_join(biomarker_status(indx_tbl, hrr_genes,  "hrr"),  by = c("patientid", "index_date")) %>%
    left_join(biomarker_status(indx_tbl, brca_genes, "brca"), by = c("patientid", "index_date")) %>%
    # HRR_LABEL_INDEX (register Q28, ruled 2026-08-07): the same status computed
    # over the 14-gene olaparib label set, shipped alongside the default all-19
    # HRR_INDEX the way BRCA_INDEX sits beside it, so the label-aligned view
    # and the default view appear in one dataset without a second build.
    # It is not affected by RDAP_HRR_PANEL: this column always means the
    # olaparib label, whatever panel the main HRR_INDEX is built from, or the
    # two would move together and the comparison would be lost.
    # The 14 are a subset of the 19, so HRR_LABEL_INDEX='Positive' implies
    # HRR_INDEX='Positive' under the default panel - gated as V2e.
    left_join(biomarker_status(indx_tbl, hrr_panel_olaparib, "hrr_label"),
              by = c("patientid", "index_date")) %>%
    # SPEC-Q: HRR_INDEX_TEST / BRCA_INDEX_TEST (IHC/FISH/PCR/NGS/...) have no
    # corresponding column in t_enh_prostate_biomarker_2026m06 - the table
    # carries only biomarkername, biomarkerstatus, dnatype and the two dates.
    # Emitted as Unknown pending confirmation of the source column.
    mutate(
      hrr_index_test    = "Unknown", hrr_index_testn  = 7,
      brca_index_test   = "Unknown", brca_index_testn = 7)
}

# --- PSMA PET scan  (rows 78-79) ---------------------------------------------
clin_char_psma_var <- function(input_ds) {
  indx_tbl <- input_ds %>% select(patientid, index_date) %>% distinct()

  latest <- indx_tbl %>%
    inner_join(enh_pros_pano_psmapet %>% select(patientid, scandate, isdiseaseevidence),
               by = "patientid") %>%
    filter(scandate <= index_date) %>%
    group_by(patientid, index_date) %>%
    summarise(psma_scandt = max(scandate, na.rm = TRUE), .groups = "drop")

  # Same-date conflicts, register Q26 (RULED 2026-08-07). 38 patients carry two
  # PSMA scans on the winning date with different IsDiseaseEvidence, 8 of them a
  # hard Yes/No contradiction. The spec gives no tie rule, so this mirrors the
  # one the spec does give, for biomarkers on a shared date:
  #   Yes + No       -> Unknown/not documented   (cf. Positive+Negative -> Unknown)
  #   Yes + Unknown  -> Yes                      (cf. Positive+Unknown  -> Positive)
  #   No  + Unknown  -> No                       (cf. Negative+Unknown  -> Negative)
  # Do not resolve with max() on the string: that resolves alphabetically and
  # silently favours "Yes" - an artefact of collation, not a clinical rule.
  result <- latest %>%
    inner_join(enh_pros_pano_psmapet %>% select(patientid, scandate, isdiseaseevidence),
               by = "patientid") %>%
    filter(scandate == psma_scandt) %>%
    mutate(
      is_yes = ifelse(sql("LOWER(isdiseaseevidence) = 'yes'"), 1L, 0L),
      is_no  = ifelse(sql("LOWER(isdiseaseevidence) = 'no'"),  1L, 0L)) %>%
    group_by(patientid, index_date, psma_scandt) %>%
    summarise(any_yes = max(is_yes, na.rm = TRUE),
              any_no  = max(is_no,  na.rm = TRUE), .groups = "drop") %>%
    mutate(psma_scanresult = case_when(
      any_yes == 1 & any_no == 1 ~ "Unknown/not documented",
      any_yes == 1               ~ "Yes",
      any_no  == 1               ~ "No",
      TRUE                       ~ "Unknown/not documented")) %>%
    select(patientid, index_date, psma_scandt, psma_scanresult)

  indx_tbl %>%
    left_join(result, by = c("patientid", "index_date")) %>%
    mutate(psma_scanresult = ifelse(is.na(psma_scanresult),
                                    "Unknown/not documented", psma_scanresult))
}

# --- sites of metastasis  (rows 80-87) ---------------------------------------
# <site>_METDT is the earliest recorded date for that site over the whole study
# period; <site>_MET is Yes when that date is on or before index.
met_sites <- list(lung = "Lung", adrenal = "Adrenal", bone = "Bone", brain = "Brain")

clin_char_met_var <- function(input_ds) {
  indx_tbl <- input_ds %>% select(patientid, index_date) %>% distinct()
  out <- indx_tbl

  for (sfx in names(met_sites)) {
    site   <- met_sites[[sfx]]
    v_flag <- paste0(sfx, "_met")
    v_dt   <- paste0(sfx, "_metdt")

    site_tbl <- indx_tbl %>%
      inner_join(enh_pros_pano_som %>%
                   filter(tolower(siteofmetastasis) == tolower(site)) %>%
                   select(patientid, dateofmetastasis),
                 by = "patientid") %>%
      group_by(patientid, index_date) %>%
      summarise(!!v_dt := min(dateofmetastasis, na.rm = TRUE), .groups = "drop")

    out <- out %>%
      left_join(site_tbl, by = c("patientid", "index_date")) %>%
      mutate(!!v_flag := ifelse(!is.na(!!sym(v_dt)) & !!sym(v_dt) <= index_date,
                                "Yes", "No"))
  }
  out
}

# --- follow-up end date & death date  (rows 88-93, 97) -----------------------
# The derivation itself now lives in 01_studypop.R, at patient level and ahead
# of cohort assignment (rule RP3, register Q82). Neither DTHDT nor FUED may
# depend on an index date, so there is nothing left to compute per cohort -
# only the join onto this cohort's index table. A patient who appears in
# several cohorts carries the same follow-up values in each, which is the
# point of RP3.
#
# FUDUR stays in clin_char_master(): it is a duration FROM the index date and
# is the one follow-up figure that is genuinely per cohort.
clin_char_fuend_dthdt_var <- function(input_ds) {
  input_ds %>%
    select(patientid, index_date) %>%
    distinct() %>%
    left_join(patient_fu_death, by = "patientid")
}

# --- master clinical: combine the pieces ------------------------------------
clin_char_master <- function(input_ds, coh_flag) {
  indx_tbl <- input_ds %>% select(patientid, index_date) %>% distinct()

  # Built once and threaded through, so there is one definition rather than two.
  # This is a lazy object, not a materialised table - dbplyr can still
  # inline the SQL at both use sites. Sharing it removes the second definition,
  # which could drift; it does not guarantee the planner reads it once.
  fu_tbl <- clin_char_fuend_dthdt_var(input_ds)

  indx_tbl %>%
    left_join(clin_char_enh_pros_var(input_ds),   by = c("patientid", "index_date")) %>%
    left_join(clin_char_ecog_var(input_ds, coh_flag), by = c("patientid", "index_date")) %>%
    left_join(clin_char_lab_var(input_ds),        by = c("patientid", "index_date")) %>%
    left_join(clin_char_bp_var(input_ds),         by = c("patientid", "index_date")) %>%
    left_join(clin_char_conmed_var(input_ds, fu_tbl), by = c("patientid", "index_date")) %>%
    left_join(clin_char_vitals_var(input_ds),     by = c("patientid", "index_date")) %>%
    left_join(clin_char_psa_var(input_ds),        by = c("patientid", "index_date")) %>%
    left_join(clin_char_biomarker_var(input_ds),  by = c("patientid", "index_date")) %>%
    left_join(clin_char_psma_var(input_ds),       by = c("patientid", "index_date")) %>%
    left_join(clin_char_met_var(input_ds),        by = c("patientid", "index_date")) %>%
    left_join(fu_tbl,                             by = c("patientid", "index_date")) %>%
    # 202603's PINDDUR and PFUDUR are not in the 202606 spec and are dropped;
    # ID3MOSFU (5A.Demos) now serves PFUDUR's purpose.
    mutate(
      fudur   = datediff(fued, index_date) + 1,   # 5B.ClinChars row 15
      indexyr = year(index_date)                  # 5B.ClinChars row 16
    )
}

for (coh_flag in coh_list) {
  var_name <- paste0("enh_pros_pano_", coh_flag, "_clin_tbl")
  input_ds <- get(paste0("enh_pros_pano_", coh_flag, "_index_tbl"))
  df <- clin_char_master(input_ds, coh_flag)
  createInPersonalSchema(df, stage_name(var_name), replace = TRUE)
  # Rebind to the materialized table, not the lazy query. Keeping the lazy
  # object would make every downstream stage re-expand the whole upstream
  # query, so the final ADS would be one enormous nested SELECT and the
  # intermediate writes would be paid for without ever being used.
  assign(var_name, tbl(con, in_schema(personal_schema, stage_name(var_name))))
  rm(df)
}
