# =============================================================================
# Setup: environment, parameters, source tables
# =============================================================================
# Spec sheets 3.Data Prep B and C, plus 4.StudyPop's cohort table.
# Sourced by the driver. Not runnable on its own.
# =============================================================================

# ---- Load libraries ---------------------------------------------------------
library(odbc)
library(DBI)
library(dbplyr)
library(dplyr)
library(lubridate)
# tidyr, purrr, stringr, sparklyr and gsklog are not used by this module.

# ---- Setup / helpers / connection ------------------------------------------
source('/mnt/code/intake/oncology/prostrate/202606/code/01_project_necessities/001_setup.R')
source('/mnt/code/intake/oncology/prostrate/202606/code/01_project_necessities/002_helper_functions.R')
source('/mnt/code/intake/oncology/prostrate/202606/code/helperScripts/databases/personalSchemaFunctions.R')

# The helper scripts above may define their own sql() - one site version
# issues DROP TABLE against the personal schema with its argument as the
# table name. Every sql() in these modules must mean dbplyr's raw-SQL
# literal, so rebind it here, after the helpers load. Same defence class as
# dplyr::count() below; qualifying the 50+ call sites instead would change
# how dbplyr parenthesises the rendered SQL and break the query manifest.
sql <- dbplyr::sql

con <- connect()

# =============================================================================
# Parameters  (3.Data Prep, section B)
# =============================================================================
datav   <- "20260630"                          # DATAV  - RWD data version
rawrwd  <- "Flatiron Prostate Panoramic Dataset"  # RAWRWD - RWD data source
refresh <- "2026m06"     # snapshot suffix carried by every t_* source table
# dbname / personal_schema come from 001_setup.R

index_start <- as.Date("2011-01-01")   # MININDEX - min potential index date
index_end   <- as.Date("2026-04-30")   # MAXINDEX - max potential index date
# STUDY_PD is "earliest available data through MAXINDEX" - a time period, not a
# constant, so it has no parameter of its own.

# the sheet prints MAXINDEX as "4/31/2026", which is not a real
# date. All six source tables max at 2026-04-30, so that is what is used.

# There is no run-tag suffix. To run two builds side by side, point them at
# different personal schemas; that isolates the stage tables too.

# Program version. Bump it on any logic change. It is a label, not proof - it
# cannot tell two runs of the same code apart.
#
# Entries summarise what changed for the next maintainer. Every decision is in
# docs/VARIABLES.md section 4 with its row id.
#   .3   SES keeps NULL; LABALB requires g/L; biomarker date closest to index
#        over one shared pool; residual codes standardised on 99
#   .4   cross-gene rollup Negative over VUS; PSMA same-day conflict -> Unknown;
#        ECOG closest-to-index for cohorts 3-7; CSF_FU bounded at FUED; HRR
#        panel frozen to 19 genes; LOTN_MHSPC and HRR_LABEL_INDEX added
#   .5   ECOG corrected to six categories, ECOGN 1..6
#   .6   ECOG [-30,+7] window extended to cohorts 3-7
#   .7   DTHFUFL onto the preliminary dates; labs/BP Missing test un-windowed,
#        moving 182k-202k rows per analyte and 144,079 BP rows to Unknown
#   .8   DTHFUFL's third null state removed; LOT names NULL, not 'None'; PARPi
#        accepts a slash separator
#   .9   BP must be a positive integer; WEIGHT/HEIGHT accept any non-null value;
#        lab unit comparisons trimmed; death dates back to spec-literal;
#        safe_num()/safe_int() rewritten so they cannot leak into SQL as
#        unresolvable function calls.
#  .10   No value change. Dead code and duplicated work removed.
#  .11   No value change. LINENAME contract gate widened to drug episodes.
#  .12   ECOG outside 0-4 now reads Unknown/Missing; vitals and biomarkers
#        group on a normalised name so case variants cannot fan out or escape
#        the conflict rule; death dates use TRY_CAST; LINENAME gates test an
#        allow-list instead of a list of rejected characters.
#  .13   No value change. LINENAME gate rejects separator-adjacent and outer
#        whitespace.
#  .14   Malformed year-only death dates use TRY_CAST throughout, so they
#        cannot abort the build under ANSI; chemotherapy category lower-cased
#        in the per-line block, matching the other two paths.
#  .15   BMI and BSA guard only what the arithmetic needs - BMI a zero height,
#        BSA a negative base. The extra positivity test on WEIGHT was a filter
#        on sign, which the specification forbids. Also a pre-write gate: the build refuses
#        to replace the live table if any cohort came out empty. The per-line
#        chemotherapy look-up matches a capitalised category without fanning
#        the patient out.
#  .16   No value change on clean data. Gates added for LINESETTING case or
#        whitespace variants, which silently drop a line out of its cohort,
#        and for a LINENAME naming the same drug twice, which reads as a
#        combination regimen. closest_value() rejects an unknown tie rule
#        instead of defaulting to the highest value.
#  .17   No value change. R29 aligned with .15: it still asserted the WEIGHT
#        positivity test that production dropped there. R56 added to count
#        the BMI band divergence that has no ruling yet. Unread columns
#        dropped from the per-line treatment block.
#  .18   LINENAME delivered raw - see the note where the LOT table is opened.
#        BMIGR1 drops the `bmi > 0` limb, so the band is the spec's: below
#        18.5 is Underweight. Input contract checked before the first write,
#        so a missing column cannot leave the schema half rebuilt. B17 scoped
#        to the settings the build parses.
#  .19   No value change. The standalone preflight SQL checked every LOT
#        setting for B17 while the build checked two, so the two could
#        disagree on the same data; both now scan the same two. window_order
#        on the raw LOT object removed - lot_tbl() sets its own order on
#        startdate.
#  .20   No code change. Accepted as they stand: the AGEGR1 Unknown
#        label, the Gleason source spellings, the substituted LOT uniqueness
#        key, the June 2026 source cut, and gates B15-B17 as preconditions.
#  .21   No production change. Four QC oracles brought in line with approved
#        behaviour: R10 counted the AGEGR1 'Unknown' that the specification approves,
#        R40/R41 read line existence off the NAME column the specification lets be
#        null, C11 took a raw MAX(ecogvalue) where production TRY_CASTs and
#        clamps to 0-4, and R39 tested < where it claims strictly increasing.
#  .22   B17 splits LINENAME on the comma only. The slash is not a regimen
#        separator in this source - it binds inside one product name
#        (Niraparib/Abiraterone, Decitabine/Cedazuridine).
#  .23   No value change. The lab and PSA lookups and the death cascade
#        referenced mutate()-made columns inside sql() strings, which dbplyr
#        cannot scope - see the note in closest_value(). Both rewritten in
#        dplyr verbs so the dependencies are visible. dplyr::count()
#        qualified against the site helpers' masking count(); site helper
#        paths updated; source_schema now clnprw_flatiron_pano_pros_use.
#  .24   No value change. sql rebound to dbplyr::sql after the helper
#        scripts load: a site helper version defines its own sql() that
#        drops a personal-schema table named by its argument, which turned
#        the B13 gate's predicate into a DROP statement. The rendered SQL
#        is byte-identical (manifest unchanged), so the delivered table
#        still matches this code with no rebuild.
#  .25   No value change. The build now only creates. The input contract,
#        the twelve preflight gates and the excluded-gene report moved to
#        validation/01_preflight.R, which must pass before every build; the
#        empty-cohort pre-write count moved out of 06_assemble.R - the V26
#        cohort counts in validation/03_output_validation.R cover it after
#        the write. Rendered stage SQL is unchanged.
#  .26   The 2026-09-11 follow-up ruling, RP1-RP4 (the rules and
#        what they withdraw are in docs/VARIABLES.md section 3).
#        What it changed in this build: DTHDT and FUED are derived once per
#        patient in 01_studypop.R and 03_clinical.R joins that table instead
#        of re-deriving; the index floor on FUED is gone, so FUED can precede
#        INDEXDT or be NULL and FUDUR/OS/TTNT can come out negative (unruled,
#        the open follow-up disposition); the per-cohort exclusion replaces the clamp (reversed);
#        DTH_BEFORE_FUED is now a constant 0; the contract stays at 190; new
#        preflight gate B18 catches a populated but unparseable DATEOFDEATH
#.
program_version <- "202606.26"

# The 19 approved HRR gene symbols, frozen. Naming them pins the case
# definition in code. With no list, a gene added in a future data cut would
# change who counts as HRR-positive with no code change and no warning.
# validation/01_preflight.R announces any gene in the table that is not here
# (qcr_hrr_excluded_r).
hrr_panel_flatiron19 <- c("ATM", "ATR", "BARD1", "BRCA1", "BRCA2", "BRIP1",
                          "CDK12", "CHEK1", "CHEK2", "FANCA", "FANCL", "MLH1",
                          "MRE11A", "NBN", "PALB2", "RAD51B", "RAD51C",
                          "RAD51D", "RAD54L")

hrr_panel_olaparib <- c("ATM", "BARD1", "BRCA1", "BRCA2", "BRIP1", "CDK12",
                        "CHEK1", "CHEK2", "FANCL", "PALB2", "RAD51B",
                        "RAD51C", "RAD51D", "RAD54L")
hrr_panel_talapro2 <- c("ATM", "ATR", "BRCA1", "BRCA2", "CDK12", "CHEK2",
                        "FANCA", "MLH1", "MRE11A", "NBN", "PALB2", "RAD51C")

hrr_panel_mode <- Sys.getenv("RDAP_HRR_PANEL", unset = "flatiron_all")
hrr_genes <- switch(hrr_panel_mode,
  flatiron_all   = hrr_panel_flatiron19,   # the 19 approved symbols
  olaparib_label = hrr_panel_olaparib,
  talapro2       = hrr_panel_talapro2,
  stop("RDAP_HRR_PANEL must be 'flatiron_all', 'olaparib_label' or ",
       "'talapro2', got: ", hrr_panel_mode, call. = FALSE))
message("HRR panel: ", hrr_panel_mode, " (", length(hrr_genes), " genes)")

# One output table, written directly. No staging copy, no publish step.
#
# The table is live the moment the build finishes. Run the output validation
# straight after, and rebuild or drop the table if it fails. The protection
# before a build is validation/01_preflight.R, which checks the source and
# must pass first.
#
# A non-default HRR panel gets its own name, so it cannot land on the governed
# one.
panel_suffix <- if (identical(hrr_panel_mode, "flatiron_all")) {
  ""
} else {
  paste0("_hrr_", hrr_panel_mode)
}
# Intermediate stages carry it as well. Naming only the final table would let
# two panels run over the same 43 intermediates and mix. (44 stages in total
# including the ADS: six per cohort across the seven cohorts, plus the
# patient-level enh_pros_pano_pt_fu_death_tbl that 01_studypop.R writes for the
# 2026-09-11 follow-up ruling.)
stage_name <- function(x) paste0(x, panel_suffix)

# Output location, set here rather than taken from the site helper so the
# destination is visible in this repo. The guard leaves the offline harness
# alone - it assigns "sim_personal" before sourcing this file.
if (!identical(get0("personal_schema"), "sim_personal")) {
  personal_schema <- "osk02156"
}

# Tables are written as schema.table, so the catalog comes from the connection.
# Running USE CATALOG in a SQL editor does not change this R connection - it is
# a different session - so set it here and fail loudly if that is not possible.
# Otherwise the build writes into whatever catalog ODBC happened to point at.
output_catalog <- "hive_metastore"
if (!identical(get0("personal_schema"), "sim_personal")) {
  tryCatch(DBI::dbExecute(con, paste0("USE CATALOG ", output_catalog)),
           error = function(e)
             stop("could not set catalog to ", output_catalog, " on the build ",
                  "connection: ", conditionMessage(e),
                  "\nRefusing to run - the output would land in an unknown ",
                  "catalog.", call. = FALSE))
}

output_table <- paste0("rwdp_pros_pano_", refresh, panel_suffix)

# Print the resolved target before anything is written.
message("output target: ", output_catalog, ".", personal_schema, ".", output_table)

days_per_month <- 30.4375   # 3.Data Prep section C item 1

# the TINTCRPCHSPC row's label says "Time from HSPC to CRPC" but
# its printed formula runs the other way, with divisor 30.4376 instead of the
# 30.4375 used everywhere else. The label is taken as the intent. One formula,
# no switch.
min_fu_days    <- 91        # 3 months of potential follow-up

# =============================================================================
# Cohort configuration  (4.StudyPop)
# =============================================================================
# One row per analysis cohort. Everything downstream loops over this table, so
# adding or dropping a cohort is a one-line change.
#   setting - LineSetting whose lines the cohort is numbered within
#   lot_n   - NEW_LOT_N used for the index date (NA for the "overall" cohorts)
coh_spec <- data.frame(
  coh_flag = c("overall_mhspc", "overall_mcrpc", "lot1_mhspc",
               "lot1_mcrpc", "lot2_mcrpc", "lot3_mcrpc", "lot4_mcrpc"),
  cohortn  = c(1L, 2L, 3L, 4L, 5L, 6L, 7L),
  cohort   = c("Overall mHSPC", "Overall mCRPC", "L1+ treated mHSPC",
               "L1+ treated mCRPC", "L2+ treated mCRPC", "L3+ treated mCRPC",
               "L4+ treated mCRPC"),
  setting  = c("mHSPC", "mCRPC", "mHSPC", "mCRPC", "mCRPC", "mCRPC", "mCRPC"),
  lot_n    = c(NA_integer_, NA_integer_, 1L, 1L, 2L, 3L, 4L),
  stringsAsFactors = FALSE
)
coh_list <- coh_spec$coh_flag

coh_info <- function(coh_flag) coh_spec[coh_spec$coh_flag == coh_flag, ]

# Lines carried per setting (5C.TreatVars rows 5-22: mHSPC L1-L2, mCRPC L1-L4)
lot_depth <- list(mHSPC = 2L, mCRPC = 4L)

# =============================================================================
# Source tables  (all suffixed _2026m06)
# =============================================================================
# Columns are lower-cased on open, because every definition below uses lower
# case.
#
# The source schema is set outside this repo. Output schema and catalog are
# pinned above, so this is the last way a run could silently read the wrong
# data. Assert it once, before any table opens.
source_schema <- "clnprw_flatiron_pano_pros_use"
if (!identical(get0("personal_schema"), "sim_personal") &&
    !identical(dbname, source_schema)) {
  stop("source schema is '", dbname, "' but this build expects '", source_schema,
       "'.\nRefusing to run - every derivation would read from the wrong place.",
       call. = FALSE)
}

src <- function(table) {
  tbl(con, in_schema(dbname, paste0(table, "_", refresh))) %>% rename_with(tolower)
}

# Enhanced prostate cohort. Carries both milestone dates, so the advanced
# diagnosis date is derived per setting rather than once.
enh_pros_pano <- src("t_enh_prostate") %>%
  mutate(
    mcrpcdd = pmax(metastaticdiagnosisdate, crpcdate, na.rm = TRUE),
    mhspcdd = pmax(metastaticdiagnosisdate, hspcdate, na.rm = TRUE)
  )

# Line of therapy table.
#
# LINENAME is delivered raw. Do not normalise it here: LOT1_MHSPC and its seven
# siblings are a straight copy of it, so any normalisation ships in the
# delivered regimen name. The spec says deliver LineName authorise
# normalising for parsing and grouping, which is a different thing.
#
# A source-level lower-case is not needed: every place that matches on the name
# lower-cases it in its own predicate - the 17 category rules, the prior-drug
# flags, CSD, like_any_sql(), and gate B17. The two format gates use a regex
# whose character class spans both cases.
#
# No window_order here: lot_tbl() sets its own, on startdate, which is what
# NEW_LOT_N is numbered by.
enh_pros_pano_lot <- src("t_enh_prostate_lot")

enh_pros_pano_dem       <- src("t_demographics")
enh_pros_pano_ses       <- src("t_socdetofhealth")
enh_pros_pano_practice  <- src("t_practice")
enh_pros_pano_visit     <- src("t_visit")
enh_pros_pano_telemed   <- src("t_telemedicine")

# Drug episodes carry linesetting, linename and linenumber directly, so per-line
# look-ups need no join back to the LOT table on linenumber alone.
enh_pros_pano_drugepisode <- src("t_enh_prostate_drg_epsode")

# Mortality (dateofdeath is month- or year-level and is imputed below)
enh_pros_pano_mortality <- src("t_mortality_v2")

enh_pros_pano_orals <- src("t_enh_prostate_orals")
# t_diagnosis, t_enh_prostate_alpbta_emt and t_enh_prostate_provenge are not
# opened: nothing here reads them, and an unread table is still a dependency
# that can fail the run.

enh_pros_pano_bl_ecog <- src("t_enh_prostate_bsln_ecog") %>%
  select(patientid, ecogdate, ecogvalue, linenumber, linestartdate)
enh_pros_pano_ecog   <- src("t_ecog") %>%
  select(patientid, ecogdate, ecogvalue)
enh_pros_pano_vitals <- src("t_vitals")

# ---- Labs, PSA, biomarkers, imaging, progression, medication ----------------
enh_pros_pano_lab      <- src("t_lab")
enh_pros_pano_psa      <- src("t_enh_prostate_psa")
enh_pros_pano_som      <- src("t_enh_prostate_som")
enh_pros_pano_biomark  <- src("t_enh_prostate_biomarker")
enh_pros_pano_psmapet  <- src("t_enh_prostate_psmapet")
enh_pros_pano_prog     <- src("t_enh_prostate_prog_scled")
enh_pros_pano_medorder <- src("t_medicationorder")
enh_pros_pano_medadmin <- src("t_medicationadmin")

# =============================================================================
# Lines of therapy, numbered within LineSetting  (3.Data Prep row 19, NEW_LOT_N)
# =============================================================================
# LineSetting takes the values LOCALIZED / nmHSPC / mHSPC / nmCRPC / mCRPC.
# NEW_LOT_N restarts at 1 in each of mHSPC and mCRPC, ordered by StartDate.
lot_by_setting <- function(setting) {
  enh_pros_pano_lot %>%
    filter(linesetting == setting) %>%
    window_order(patientid, startdate) %>%
    group_by(patientid) %>%
    mutate(new_lot_n = row_number()) %>%
    ungroup()
}

enh_pros_pano_lot_mhspc <- lot_by_setting("mHSPC")
enh_pros_pano_lot_mcrpc <- lot_by_setting("mCRPC")

# The preflight gates and the input contract live in
# validation/01_preflight.R and must pass before this script runs. The build
# itself only creates.

lot_tbl <- function(setting) {
  # Validated, not defaulted. A default arm would swallow any value - a typo, a
  # NULL, a LOCALIZED - and return the mCRPC table, so a misrouted lookup
  # produces a plausible-looking cohort built on the wrong setting.
  switch(setting,
         mHSPC = enh_pros_pano_lot_mhspc,
         mCRPC = enh_pros_pano_lot_mcrpc,
         stop("lot_tbl(): setting must be 'mHSPC' or 'mCRPC', got: ",
              paste(setting, collapse = ", "), call. = FALSE))
}

# =============================================================================
# Small shared helpers
# =============================================================================
# Value closest to an anchor date, within [lo, hi] days of it. lo = NULL means
# no lower bound. Ties resolve to the earlier record; several records on that
# date collapse with `agg` ("min" or "max").
#
# `src` must carry patientid, index_date, anch_dt, val_x and dt_x.
closest_value <- function(src, lo, hi, out_value, out_date, agg = "max") {
  # Validated, not defaulted. A fall-through to "max" would let a typo - "MIN",
  # "lowest" - silently apply the wrong tie rule to an analyte while every
  # value still looks legal. Same failure shape as the lot_tbl() switch.
  if (!agg %in% c("min", "max")) {
    stop("closest_value(agg=) must be 'min' or 'max', got: ", agg, call. = FALSE)
  }
  # The window is expressed as datediff(), not as a raw
  # sql("DATE_ADD(anch_dt, n)") fragment. The two are arithmetically identical -
  # dt_x <= anch_dt + hi is dt_x - anch_dt <= hi - but dbplyr can see a
  # datediff() and cannot see inside a sql() string.
  #
  # That matters because anch_dt is created by mutate() in the caller. When the
  # filter that uses it is opaque, dbplyr has no reason to push the mutate into
  # a subquery, so it can emit `SELECT index_date AS anch_dt ... WHERE dt_x <=
  # DATE_ADD(anch_dt, 0)` - and SQL does not let a WHERE clause reference an
  # alias defined in its own SELECT list; Spark raises UNRESOLVED_COLUMN on
  # anch_dt. Written as datediff() the dependency is visible and dbplyr wraps
  # correctly.
  pull <- src %>%
    filter(!is.na(anch_dt), !is.na(val_x), !is.na(dt_x))

  if (!is.null(lo)) {
    pull <- pull %>% filter(datediff(dt_x, anch_dt) >= !!lo)
  }
  pull <- pull %>%
    filter(datediff(dt_x, anch_dt) <= !!hi) %>%
    mutate(gap = abs(datediff(dt_x, anch_dt)))

  min_gap <- pull %>%
    group_by(patientid, index_date) %>%
    summarise(min_gap = min(gap, na.rm = TRUE), .groups = "drop")

  closest <- pull %>%
    inner_join(min_gap, by = c("patientid", "index_date")) %>%
    filter(gap == min_gap)

  # Equidistant before/after -> prefer the record prior to the anchor
  pref <- closest %>%
    group_by(patientid, index_date) %>%
    summarise(pref_dt = min(dt_x, na.rm = TRUE), .groups = "drop")

  winners <- closest %>%
    inner_join(pref, by = c("patientid", "index_date")) %>%
    filter(dt_x == pref_dt) %>%
    group_by(patientid, index_date)

  if (agg == "min") {
    winners %>% summarise(!!out_date := min(dt_x, na.rm = TRUE),
                          !!out_value := min(val_x, na.rm = TRUE), .groups = "drop")
  } else {
    winners %>% summarise(!!out_date := min(dt_x, na.rm = TRUE),
                          !!out_value := max(val_x, na.rm = TRUE), .groups = "drop")
  }
}

# Earliest value inside [lo, hi] days of an anchor date, taking the maximum when
# several share that date. Every PSA variable uses this. Not the same rule as
# closest_value() above.
earliest_value <- function(src, lo, hi, out_value) {
  # datediff(), not a raw DATE_ADD string - see the note in closest_value().
  pull <- src %>%
    filter(!is.na(anch_dt), !is.na(val_x), !is.na(dt_x)) %>%
    filter(datediff(dt_x, anch_dt) >= !!lo,
           datediff(dt_x, anch_dt) <= !!hi)

  first_dt <- pull %>%
    group_by(patientid, index_date) %>%
    summarise(first_dt = min(dt_x, na.rm = TRUE), .groups = "drop")

  pull %>%
    inner_join(first_dt, by = c("patientid", "index_date")) %>%
    filter(dt_x == first_dt) %>%
    group_by(patientid, index_date) %>%
    summarise(!!out_value := max(val_x, na.rm = TRUE), .groups = "drop")
}

# ANSI-safe casts. Under ANSI mode a CAST of a malformed string raises instead
# of giving NULL, so every free-text numeric (ECOG, blood pressure) goes through
# TRY_CAST. One bad row must not abort the build.
safe_int <- function(x)  sql(paste0("TRY_CAST(", rlang::as_label(rlang::enquo(x)), " AS INT)"))
safe_num <- function(x)  sql(paste0("TRY_CAST(", rlang::as_label(rlang::enquo(x)), " AS DOUBLE)"))

# "regimen name contains any of these drugs" as a SQL predicate
like_any_sql <- function(drugs, col = "linename") {
  paste0("(", paste0("LOWER(", col, ") LIKE '%", drugs, "%'", collapse = " OR "), ")")
}
