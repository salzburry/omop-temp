# =============================================================================
# Demographics
# =============================================================================
# 5A.Demos.
# Sourced by the driver in numbered order. Not runnable on its own.
# =============================================================================

# One aggregated practice-type row per patient. Spark SQL does not support
# STRING_AGG ... WITHIN GROUP; CONCAT_WS + SORT_ARRAY + COLLECT_SET gives a
# deterministic "ACADEMIC,COMMUNITY" ordering.
enh_pros_pano_practice_agg <- enh_pros_pano_practice %>%
  distinct(patientid, practicetype) %>%
  group_by(patientid) %>%
  summarize(practicetype_agg = sql(
    "CONCAT_WS(',', SORT_ARRAY(COLLECT_SET(UPPER(practicetype))))"))

demographics_variable_addn <- function(input_ds) {
  input_ds %>%
    left_join(enh_pros_pano_dem, by = "patientid") %>%
    left_join(enh_pros_pano_practice_agg, by = "patientid") %>%
    left_join(enh_pros_pano_ses, by = "patientid") %>%
    mutate(
      # ID3MOSFU: at least 3 months of potential follow-up after index
      id3mosfu = if_else(datediff(index_end, index_date) >= min_fu_days, 1L, 0L),
      year_index = year(index_date),
      # !! forces safe_num() to be evaluated in R. Written bare inside
      # mutate(), dbplyr does not recognise it and passes it through to SQL
      # as a literal `safe_num(birthyear)` function call, which does not
      # exist on Databricks and fails the query. Every call site of
      # safe_num/safe_int needs this; the offline harness checks for it.
      age = year_index - !!safe_num(birthyear),
      agegr1 = case_when(
        age >= 0  & age <= 18 ~ "0-18",
        age >= 19 & age <= 34 ~ "19-34",
        age >= 35 & age <= 49 ~ "35-49",
        age >= 50 & age <= 64 ~ "50-64",
        age >= 65 & age <= 74 ~ "65-74",
        age >= 75 & age <= 84 ~ "75-84",
        age >= 85             ~ ">=85",
        TRUE ~ "Unknown"),
      agegr1n = case_when(
        age >= 0  & age <= 18 ~ 1,
        age >= 19 & age <= 34 ~ 2,
        age >= 35 & age <= 49 ~ 3,
        age >= 50 & age <= 64 ~ 4,
        age >= 65 & age <= 74 ~ 5,
        age >= 75 & age <= 84 ~ 6,
        age >= 85             ~ 7,
        TRUE ~ 99),   # fallthrough sentinel, not an 8th age band
      region1 = case_when(
        state %in% c('ME','VT','NH','MA','RI','CT','NY','PA','NJ') ~ 'Northeast',
        state %in% c('ND','SD','NE','KS','MN','IA','MO','WI','IL','MI','IN','OH') ~ 'Midwest',
        state %in% c('TX','OK','AR','LA','KY','TN','MS','AL','MD','DE','DC','VA','WV','NC','SC','GA','FL') ~ 'South',
        state %in% c('CA','WA','OR','NV','AZ','UT','NM','CO','ID','MT','WY','HI','AK') ~ 'West',
        state == 'PR' ~ 'Other region',
        is.na(state) ~ 'Missing',
        TRUE ~ 'Unknown'),
      region1n = case_when(
        state %in% c('ME','VT','NH','MA','RI','CT','NY','PA','NJ') ~ 1,
        state %in% c('ND','SD','NE','KS','MN','IA','MO','WI','IL','MI','IN','OH') ~ 2,
        state %in% c('TX','OK','AR','LA','KY','TN','MS','AL','MD','DE','DC','VA','WV','NC','SC','GA','FL') ~ 3,
        state %in% c('CA','WA','OR','NV','AZ','UT','NM','CO','ID','MT','WY','HI','AK') ~ 4,
        state == 'PR' ~ 5,
        is.na(state) ~ 6,
        TRUE ~ 99),   # state present but in no census region (e.g. academic centre)
      eth = case_when(
        race == 'Hispanic or Latino' | ethnicity == 'Hispanic or Latino' ~ 'Hispanic or Latino',
        ethnicity == 'Not Hispanic or Latino' ~ 'Not Hispanic or Latino',
        TRUE ~ 'Unknown/Missing'),
      # ETHN follows the sheet's Values-list order (Not Hispanic, Hispanic,
      # Unknown/Missing), as RACEN / AGEGR1N / STAGEN do. This reverses the
      # 202603 coding (1 = Hispanic, 2 = Not Hispanic) - any comparison
      # against the prior cut must recode.
      ethn = case_when(
        race == 'Hispanic or Latino' | ethnicity == 'Hispanic or Latino' ~ 2,
        ethnicity == 'Not Hispanic or Latino' ~ 1,
        TRUE ~ 3),
      # racen is evaluated before race is overwritten, so the source categories
      # are still intact here.
      racen = case_when(
        race == 'Asian' ~ 1,
        race == 'Black or African American' ~ 2,
        race == 'White' ~ 3,
        race %in% c('Hispanic or Latino', 'Other Race') ~ 4,
        TRUE ~ 5),
      race = case_when(
        race == 'Asian' ~ 'Asian',
        race == 'Black or African American' ~ 'Black or African American',
        race == 'White' ~ 'White',
        race %in% c('Hispanic or Latino', 'Other Race') ~ 'Other Race',
        TRUE ~ 'Unknown/Missing'),
      practic = case_when(
        practicetype_agg == 'ACADEMIC' ~ 'Academic only',
        practicetype_agg == 'COMMUNITY' ~ 'Community only',
        practicetype_agg %in% c('ACADEMIC, COMMUNITY', 'ACADEMIC,COMMUNITY') ~ 'Both academic and community',
        TRUE ~ 'Missing'),
      practicn = case_when(
        practicetype_agg == 'ACADEMIC' ~ 1,
        practicetype_agg == 'COMMUNITY' ~ 2,
        practicetype_agg %in% c('ACADEMIC, COMMUNITY', 'ACADEMIC,COMMUNITY') ~ 3,
        # 99 = fallthrough, the house sentinel for "not a real category"
        # (register Q50). Fires only for a patient with no practice record:
        # t_practice holds exactly two values, COMMUNITY and ACADEMIC.
        TRUE ~ 99),
      # Passed through unchanged so an absent socialdeterminantsofhealth record
      # stays NULL. 5A.Demos row 22 lists "Null" as a value of SES in its own
      # right, alongside 1-5 (register Q51). Do not recode NULL to a string
      # such as 'Missing': that breaks "WHERE ses IS NULL" and would make SES
      # the only ADS column encoding absence as text rather than NULL.
      ses = sesindex2015_2019
    ) %>%
    # Q22: birthyear is kept - 5A.Demos r8 lists it under "keep these variables".
    select(patientid, index_date, advanceddiagnosisdate, id3mosfu,
           birthyear, age, agegr1, agegr1n, state, region1, region1n,
           race, racen, ethnicity, eth, ethn, practicn, practic, ses)
}

for (coh_flag in coh_list) {
  var_name <- paste0("enh_pros_pano_", coh_flag, "_dem_tbl")
  input_ds <- get(paste0("enh_pros_pano_", coh_flag, "_index_tbl"))
  df <- demographics_variable_addn(input_ds)
  createInPersonalSchema(df, stage_name(var_name), replace = TRUE)
  # Rebind to the materialized table, not the lazy query. Keeping the lazy
  # object would make every downstream stage re-expand the whole upstream
  # query, so the final ADS would be one enormous nested SELECT and the
  # intermediate writes would be paid for without ever being used.
  assign(var_name, tbl(con, in_schema(personal_schema, stage_name(var_name))))
  rm(df)
}
