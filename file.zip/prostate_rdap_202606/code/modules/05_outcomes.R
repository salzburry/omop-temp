# =============================================================================
# Outcomes
# =============================================================================
# 6.Outcomes - OS, VIS120, TTNT, rwPFS and PSA response.
# Sourced by the driver in numbered order. Not runnable on its own.
# =============================================================================

# TRTDIS, TTD, TSSTFL and TSST are struck out in the spec and are not built.
# VIS120 is not struck out and is still produced.
#
# TTNTFL is struck out too, but the active TTNT definition reads it. It is
# derived here as an internal helper and dropped before the ADS (register Q02).
outcomes_tbl_var <- function(input_ds, coh_flag) {
  ci       <- coh_info(coh_flag)
  cohortn  <- ci$cohortn
  indx_tbl <- input_ds %>% select(patientid, index_date) %>% distinct()

  clin_char_tbl <- get(paste0("enh_pros_pano_", coh_flag, "_clin_tbl"))
  trt_var_tbl   <- get(paste0("enh_pros_pano_", coh_flag, "_trt_var_tbl"))
  dem_tbl       <- get(paste0("enh_pros_pano_", coh_flag, "_dem_tbl"))

  # Last clinic note, used as the rwPFS censoring date
  lastnote_tbl <- indx_tbl %>%
    left_join(enh_pros_pano_prog %>%
                group_by(patientid) %>%
                summarise(lastclinicnotedate = max(lastclinicnotedate, na.rm = TRUE)) %>%
                distinct(),
              by = "patientid")

  base <- indx_tbl %>%
    left_join(clin_char_tbl %>% select(patientid, index_date, dthdt, dthfl, fued,
                                       dth_before_fued, psa_index),
              by = c("patientid", "index_date")) %>%
    left_join(dem_tbl %>% select(patientid, index_date, id3mosfu),
              by = c("patientid", "index_date")) %>%
    left_join(trt_var_tbl %>% select(patientid, index_date,
                                     lot2sd_mhspc, lot1sd_mcrpc,
                                     lot2sd_mcrpc, lot3sd_mcrpc, lot4sd_mcrpc),
              by = c("patientid", "index_date")) %>%
    left_join(lastnote_tbl, by = c("patientid", "index_date"))

  # --- VIS120 ----------------------------------------------------------------
  # A visit or telemedicine visit 120 days or more after the last episode date
  # of the index line of therapy. The overall cohorts have no index line, so it
  # is missing for them.
  vis120_tbl <- if (is.na(ci$lot_n)) {
    indx_tbl %>% mutate(vis120 = NA_integer_)
  } else {
    index_ed <- paste0("lot", ci$lot_n, "ed",
                       if (ci$setting == "mHSPC") "_mhspc" else "_mcrpc")

    last_contact <- indx_tbl %>%
      inner_join(enh_pros_pano_visit %>% select(patientid, visitdate) %>%
                   union_all(enh_pros_pano_telemed %>% select(patientid, visitdate)),
                 by = "patientid") %>%
      group_by(patientid, index_date) %>%
      summarise(last_contact_dt = max(visitdate, na.rm = TRUE), .groups = "drop")

    indx_tbl %>%
      left_join(trt_var_tbl %>% select(patientid, index_date, index_lot_ed = !!sym(index_ed)),
                by = c("patientid", "index_date")) %>%
      left_join(last_contact, by = c("patientid", "index_date")) %>%
      mutate(vis120 = ifelse(
        !is.na(last_contact_dt) & !is.na(index_lot_ed) &
          last_contact_dt >= sql("DATE_ADD(index_lot_ed, 120)"), 1L, 0L)) %>%
      select(patientid, index_date, vis120)
  }

  # --- TTNT ------------------------------------------------------------------
  # The "next treatment" date depends on the cohort. For 1L mHSPC a patient can
  # progress either to a second mHSPC line or into their first mCRPC line.
  # Overall cohorts (1, 2) and 4L mCRPC (7, no LOT5 is carried) are missing.
  ttnt_df <- base %>%
    mutate(
      next_trt_dt = case_when(
        cohortn == 3 ~ pmin(lot2sd_mhspc, lot1sd_mcrpc, na.rm = TRUE),
        cohortn == 4 ~ lot2sd_mcrpc,
        cohortn == 5 ~ lot3sd_mcrpc,
        cohortn == 6 ~ lot4sd_mcrpc,
        TRUE ~ NA),
      ttntfl = case_when(
        cohortn %in% c(1, 2, 7) ~ NA_integer_,
        id3mosfu == 1 ~ case_when(!is.na(next_trt_dt) | dthfl == 1 ~ 1L, TRUE ~ 0L),
        TRUE ~ NA_integer_),
      ttnt = case_when(
        dth_before_fued == 1 ~ NA,          # same guard as OS
        cohortn %in% c(1, 2, 7) ~ NA,
        id3mosfu == 1 & ttntfl == 1 ~
          (datediff(pmin(next_trt_dt, dthdt, na.rm = TRUE), index_date) + 1) / days_per_month,
        id3mosfu == 1 & ttntfl == 0 ~ (datediff(fued, index_date) + 1) / days_per_month,
        TRUE ~ NA)
    ) %>%
    select(patientid, index_date, ttntfl, ttnt)

  # --- rwPFS -----------------------------------------------------------------
  # Progression events: any progression flag other than
  # IsPseudoProgressionMentioned, dated on or after INDEXDT + 14. The 14-day gap
  # keeps the event attributable to the index treatment, not the prior one.
  # Death is the event when no eligible progression is seen.
  prog_events <- indx_tbl %>%
    inner_join(enh_pros_pano_prog %>%
                 select(patientid, progressiondate, isradiographicevidence,
                        ispathologicevidence, ismixedresponsementioned,
                        isphysicalexamevidence, istumormarkerevidence,
                        ispsaincreased),
               by = "patientid") %>%
    filter(progressiondate >= dbplyr::sql("DATE_ADD(index_date, 14)"),
           sql("(LOWER(isradiographicevidence) = 'true'
                 OR LOWER(ispathologicevidence) = 'true'
                 OR LOWER(ismixedresponsementioned) = 'true'
                 OR LOWER(isphysicalexamevidence) = 'true'
                 OR LOWER(istumormarkerevidence) = 'true'
                 OR LOWER(ispsaincreased) = 'true')")) %>%
    group_by(patientid, index_date) %>%
    summarise(first_progdt = min(progressiondate, na.rm = TRUE), .groups = "drop")

  pfs_df <- base %>%
    left_join(prog_events, by = c("patientid", "index_date")) %>%
    mutate(
      eligpfs = case_when(
        cohortn %in% c(1, 2) ~ NA_integer_,
        id3mosfu == 1 & !is.na(lastclinicnotedate) & lastclinicnotedate > index_date ~ 1L,
        TRUE ~ 0L),
      pfsfl = case_when(
        cohortn %in% c(1, 2) ~ NA_integer_,
        eligpfs == 1 & !is.na(first_progdt) ~ 1L,
        eligpfs == 1 & is.na(first_progdt) & dthfl == 1 ~ 1L,
        eligpfs == 1 & is.na(first_progdt) & dthfl == 0 ~ 0L,
        TRUE ~ NA_integer_),
      # PFSDT is the event date only. When there is neither an eligible
      # progression nor a death it is missing - it is not set to the censoring
      # date. PFS censors on LASTCLINICNOTEDATE instead.
      pfsdt = case_when(
        cohortn %in% c(1, 2) ~ NA,
        eligpfs == 1 & !is.na(first_progdt) ~ first_progdt,
        eligpfs == 1 & is.na(first_progdt) & dthfl == 1 ~ dthdt,
        TRUE ~ NA),
      pfs = case_when(
        cohortn %in% c(1, 2) ~ NA,
        eligpfs == 1 & pfsfl == 1 ~ (datediff(pfsdt, index_date) + 1) / days_per_month,
        eligpfs == 1 & pfsfl == 0 ~
          (datediff(lastclinicnotedate, index_date) + 1) / days_per_month,
        TRUE ~ NA)
    ) %>%
    select(patientid, index_date, eligpfs, pfsfl, pfsdt, pfs)

  # --- post-index PSA response ----------------------------------------------
  # "Take earliest result in this window. If multiple results on the same day,
  # take maximum." The windows are deliberately wide so a result that arrives
  # late still counts as the 6- or 12-month reading.
  psa_window <- function(lo, hi, out_name) {
    indx_tbl %>%
      inner_join(enh_pros_pano_psa %>% select(patientid, scoreserial, resultdate),
                 by = "patientid") %>%
      mutate(anch_dt = index_date, val_x = scoreserial, dt_x = resultdate) %>%
      earliest_value(lo, hi, out_name)
  }

  psa_df <- base %>%
    select(patientid, index_date, psabl = psa_index) %>%
    left_join(psa_window(180, 210, "psa6mo"),  by = c("patientid", "index_date")) %>%
    left_join(psa_window(365, 395, "psa12mo"), by = c("patientid", "index_date")) %>%
    mutate(
      psa50_6mo  = case_when(!is.na(psa6mo)  & !is.na(psabl) & psabl > 0 &
                               ((psa6mo  - psabl) / psabl) <= -0.5 ~ "Y", TRUE ~ "N"),
      psal6mo    = case_when(!is.na(psa6mo)  & psa6mo  < 0.2 ~ "Y", TRUE ~ "N"),
      psa50_12mo = case_when(!is.na(psa12mo) & !is.na(psabl) & psabl > 0 &
                               ((psa12mo - psabl) / psabl) <= -0.5 ~ "Y", TRUE ~ "N"),
      psal12mo   = case_when(!is.na(psa12mo) & psa12mo < 0.2 ~ "Y", TRUE ~ "N")
    ) %>%
    select(patientid, index_date, psa6mo, psa50_6mo, psal6mo,
           psa12mo, psa50_12mo, psal12mo)

  # --- assemble --------------------------------------------------------------
  indx_tbl %>%
    left_join(base %>% select(patientid, index_date, dthdt, dthfl, fued,
                              dth_before_fued, id3mosfu),
              by = c("patientid", "index_date")) %>%
    left_join(vis120_tbl, by = c("patientid", "index_date")) %>%
    left_join(ttnt_df,    by = c("patientid", "index_date")) %>%
    left_join(pfs_df,     by = c("patientid", "index_date")) %>%
    left_join(psa_df,     by = c("patientid", "index_date")) %>%
    mutate(
      # OS has no ID3MOSFU gate in the 202606 spec, unlike TTNT and rwPFS;
      # the only exclusion is DTH_BEFORE_FUED.
      #
      # That first branch is unreachable under the 2026-09-11 ruling (register
      # Q82): where a death date exists FUED IS that date, so DTHDT < FUED
      # cannot hold. It is kept because the spec still states it
      # and removing it would be an undocumented deviation. The work it used to
      # do - keeping a death-before-index patient out of the survival figures -
      # is now done upstream, by dropping that patient from the cohort.
      #
      # The dthfl == 1 arm cannot go negative: the cohort exclusion guarantees
      # DTHDT >= INDEXDT. The dthfl == 0 arm measures to FUED, which for a
      # patient with no death date is their last activity date - unconnected to
      # the index and no longer floored at it - so that arm can go negative.
      # Gate V46 sizes that population; it is unruled (register Q83).
      os = case_when(
        dth_before_fued == 1 ~ NA,
        dthfl == 1 ~ sql("(DATEDIFF(dthdt, index_date)+1)/30.4375"),
        dthfl == 0 ~ sql("(DATEDIFF(fued, index_date)+1)/30.4375"),
        TRUE ~ NA)
    ) %>%
    # ttntfl is dropped here per register Q02 (see header note).
    select(patientid, index_date, os, vis120, ttnt,
           eligpfs, pfsfl, pfsdt, pfs,
           psa6mo, psa50_6mo, psal6mo, psa12mo, psa50_12mo, psal12mo) %>%
    distinct()
}

for (coh_flag in coh_list) {
  var_name <- paste0("enh_pros_pano_", coh_flag, "_outcomes_var_tbl")
  input_ds <- get(paste0("enh_pros_pano_", coh_flag, "_index_tbl"))
  df <- outcomes_tbl_var(input_ds, coh_flag)
  createInPersonalSchema(df, stage_name(var_name), replace = TRUE)
  # Rebind to the materialized table, not the lazy query. Keeping the lazy
  # object would make every downstream stage re-expand the whole upstream
  # query, so the final ADS would be one enormous nested SELECT and the
  # intermediate writes would be paid for without ever being used.
  assign(var_name, tbl(con, in_schema(personal_schema, stage_name(var_name))))
  rm(df)
}
