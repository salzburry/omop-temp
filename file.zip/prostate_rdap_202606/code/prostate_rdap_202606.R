# =============================================================================
# Prostate PANO RWDP - build script
# Data cut 202606   (DATAV = 20260630, refresh suffix "2026m06")
# =============================================================================
# Built from the 202606 program specification, sheets 3.Data Prep, 4.StudyPop,
# 5A.Demos, 5B.ClinChars, 5C.TreatVars and 6.Outcomes. Supersedes the 202603
# build script.
#
# Output: 190 columns, one row per patient per cohort, seven cohorts. Lines of
# therapy are numbered within LineSetting, so every per-line variable is
# suffixed _MHSPC or _MCRPC.
#
#   1 Overall mHSPC      2 Overall mCRPC
#   3 L1+ treated mHSPC  4 L1+ treated mCRPC
#   5 L2+ treated mCRPC  6 L3+ treated mCRPC   7 L4+ treated mCRPC
#
# This file only sources the modules. Each module is one spec sheet, so a
# reviewer with a sheet open reads one file:
#
#   00_setup.R          3.Data Prep B and C, source tables
#   01_studypop.R       4.StudyPop B - index cohort definition
#   02_demographics.R   5A.Demos
#   03_clinical.R       5B.ClinChars
#   04_treatment.R      5C.TreatVars
#   05_outcomes.R       6.Outcomes
#   06_assemble.R       the 190-column allowlist, the union, the output write
#
# They share one environment and must run in this order. Later modules read
# objects the earlier ones define, so none runs on its own.
#
# Every object is a lazy tbl. Nothing is pulled into R memory. The SQL
# dialect is Spark SQL.
#
# This script only creates. Every check lives in validation/ and qc/: run
# validation/01_preflight.R before a build - it is a mandatory precondition
# (Q78) - and the output validation straight after.
#
# The corrected specification the build implements is docs/SPEC.csv. Where the
# spec was silent or contradicted itself, docs/VARIABLES.md holds the ruling.
# Comments cite it as "register Qnn" and do not repeat the argument.
# =============================================================================

RDAP_MODULES <- c(
  "00_setup.R",
  "01_studypop.R",
  "02_demographics.R",
  "03_clinical.R",
  "04_treatment.R",
  "05_outcomes.R",
  "06_assemble.R"
)

# Where the modules live. Resolved from THIS file's own location, so the driver
# works whatever the working directory is - sourced from a project root, from
# its own folder, or run with Rscript. Set RDAP_MODULE_DIR before sourcing to
# override for a deployed layout.
rdap_driver_dir <- function() {
  # source() records the file it is reading on its own frame.
  for (i in rev(seq_len(sys.nframe()))) {
    ofile <- sys.frame(i)$ofile
    if (!is.null(ofile) && nzchar(ofile)) return(dirname(normalizePath(ofile)))
  }
  # Rscript passes the script path on the command line.
  arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
  if (length(arg)) return(dirname(normalizePath(sub("^--file=", "", arg[1]))))
  NA_character_
}

if (!exists("RDAP_MODULE_DIR")) {
  here <- rdap_driver_dir()
  RDAP_MODULE_DIR <- if (!is.na(here)) file.path(here, "modules") else "modules"
}

# The manifest is written only when the run finishes. Delete any previous one
# first - before the module check, before the libraries, before the connection -
# so no failure can leave the last run's manifest sitting beside the last run's
# output table, looking current. No manifest means the run did not finish.
# Set RDAP_MANIFEST_FILE before sourcing to write it somewhere else.
if (!exists("RDAP_MANIFEST_FILE")) RDAP_MANIFEST_FILE <- "RUN_MANIFEST.txt"
manifest_file <- RDAP_MANIFEST_FILE
if (file.exists(manifest_file)) unlink(manifest_file)

missing <- RDAP_MODULES[!file.exists(file.path(RDAP_MODULE_DIR, RDAP_MODULES))]
if (length(missing)) {
  stop("cannot find module(s) ", paste(missing, collapse = ", "),
       " under '", RDAP_MODULE_DIR, "'. Set RDAP_MODULE_DIR to the folder ",
       "holding them and source this file again.", call. = FALSE)
}

for (rdap_module in RDAP_MODULES) {
  source(file.path(RDAP_MODULE_DIR, rdap_module))
}
