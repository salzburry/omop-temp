# =============================================================================
# Offline build check
# =============================================================================
#   Rscript validation/02_offline_build_check.R
#   Exit 0 = the pipeline builds. Non-zero = a real defect.
#
# Runs the real build script end to end against dbplyr's simulated Spark
# backend, with every source table replaced by an empty frame carrying the true
# column names. dbplyr resolves column references, join keys, tidy-eval and set
# operations while building the query, so this catches:
#
#   * a select/mutate/filter naming a column that does not exist
#   * tidy-eval mistakes (!!, :=, sym) that silently produce nothing
#   * a verb the Spark backend cannot translate
#   * joins whose .x/.y suffixes a later select cannot find
#   * union_all over frames whose columns do not line up
#   * an R helper leaking into SQL as an unresolvable function call
#
# WHAT IT DOES NOT PROVE:
#   * that any table or column exists. The frames come from the input contract,
#     which is an assertion about the source, not a reading of it.
#   * that Databricks accepts the SQL.
#   * that types line up - every simulated column here is character.
#   * that the connection or write helpers work.
#   * that joins keep cardinality, or that any value is correct.
# =============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(dbplyr)
})


DRIVER   <- "code/prostate_rdap_202606.R"
MODULES  <- "code/modules"
OUT_DIR  <- "validation/generated_sql"
MANIFEST <- "validation/generated_sql.md5"
REFRESH  <- "2026m06"

# -----------------------------------------------------------------------------
# 1. The source schema, read from the single authoritative input contract that
#    the README and the preflight SQL also use. Keep one copy: a table list
#    maintained here drifts from the one the preflight states.
# -----------------------------------------------------------------------------
contract <- utils::read.csv("validation/00_input_contract.csv", stringsAsFactors = FALSE)
schema   <- split(contract$column, contract$table)

cat("input contract:", length(schema), "tables /", nrow(contract), "columns\n")

source("validation/read_deviations.R")   # parser for the register in VARIABLES.md

# -----------------------------------------------------------------------------
# 2. Shims replacing the Databricks environment
# -----------------------------------------------------------------------------
sim_con <- simulate_spark_sql()

written <- new.env(parent = emptyenv())
written$tables <- list()

# Carries the schema qualifier through so shim_tbl can tell a source table from
# a stage the script has just written to the personal schema.
shim_in_schema <- function(schema, table) paste0(schema, ".", table)

shim_tbl <- function(src, from, ...) {
  parts <- strsplit(as.character(from), ".", fixed = TRUE)[[1]]
  sch   <- parts[1]
  nm    <- parts[2]

  if (identical(sch, "sim_personal")) {
    # A previously materialized stage. Its column set is whatever was written -
    # which is exactly what the real script will read back from Databricks.
    prev <- written$tables[[nm]]
    if (is.null(prev)) {
      stop("READ-BEFORE-WRITE: script read personal-schema table '", nm,
           "' before it was created", call. = FALSE)
    }
    cols <- prev$cols
  } else {
    base <- sub(paste0("_", REFRESH, "$"), "", nm)
    cols <- schema[[base]]
    if (is.null(cols)) {
      stop("SCHEMA MISS: build script opened '", nm,
           "' which is not in the 2026m06 profile", call. = FALSE)
    }
  }
  # An empty frame with the right columns is enough for dbplyr to resolve names.
  df <- as.data.frame(setNames(rep(list(character()), length(cols)), cols))
  tbl_lazy(df, con = sim_con, name = nm)
}

shim_write <- function(df, name, replace = TRUE, ...) {
  # Force the query to render. This is where a broken lazy chain blows up.
  sql <- tryCatch(as.character(dbplyr::remote_query(df)),
                  error = function(e) stop("RENDER FAILED for '", name, "': ",
                                           conditionMessage(e), call. = FALSE))
  written$tables[[name]] <- list(sql = sql, cols = colnames(df))
  invisible(df)
}

# -----------------------------------------------------------------------------
# 3. Run the real entry point
#
#    The driver is sourced for real: its path resolution, its existence check
#    and its source() loop all execute. Do not shortcut this by reading the
#    driver's RDAP_MODULES vector and concatenating the module files - that
#    exercises the module bodies but not the driver, and misses a driver that
#    cannot locate its own modules (RDAP_MODULE_DIR resolving relative to a
#    different working directory than the documented command uses). Only the
#    pieces that need a live connection are swapped out, through a source()
#    shim rather than by rewriting text.
# -----------------------------------------------------------------------------
NEEDS_CONNECTION <- c("^\\s*library\\(")

sourced <- character()

module_paths <- normalizePath(file.path(MODULES, list.files(MODULES, pattern = "\\.R$")),
                              mustWork = FALSE)

shim_source <- function(file, ...) {
  # Allowlist, not file.exists(): the site helper scripts do exist in the study
  # environment, and sourcing them there would let them redefine connect(),
  # createInPersonalSchema() or the schema names and quietly defeat the
  # simulation. Only the build's own modules are ever evaluated here.
  if (!normalizePath(file, mustWork = FALSE) %in% module_paths) {
    return(invisible(NULL))
  }

  sourced <<- c(sourced, basename(file))
  lines <- readLines(file, warn = FALSE)
  drop  <- Reduce(`|`, lapply(NEEDS_CONNECTION, grepl, x = lines))
  lines[drop] <- "## [harness] removed - needs a live connection"
  eval(parse(text = paste(lines, collapse = "\n")), envir = env)
  invisible(NULL)
}

env <- new.env(parent = globalenv())
# Redirect the manifest. The driver deletes any existing one and writes a fresh
# one; run in a live build directory, that would destroy the real run's
# evidence. Nothing this script does may touch the working tree.
assign("RDAP_MANIFEST_FILE", tempfile(fileext = ".txt"), envir = env)
assign("dbname",          "sim_db",       envir = env)
assign("personal_schema", "sim_personal", envir = env)
assign("tbl",             shim_tbl,       envir = env)
assign("in_schema",       shim_in_schema, envir = env)
assign("createInPersonalSchema", shim_write, envir = env)
assign("source",  shim_source,          envir = env)
assign("connect", function() sim_con,   envir = env)

cat("== building pipeline against simulated Spark SQL ==\n\n")
ok <- TRUE
tryCatch({
  source(DRIVER, local = env)     # the real entry point, real path resolution
}, error = function(e) {
  cat("BUILD FAILED\n  ", conditionMessage(e), "\n")
  ok <<- FALSE
})

# -----------------------------------------------------------------------------
# 4. Report
# -----------------------------------------------------------------------------
tabs <- written$tables
cat("stages rendered:", length(tabs), "\n\n")

if (length(tabs)) {
  # Identify the ADS by name. Taking the last write would assume the build's
  # write order: a stage written after the ADS - or an ADS never written
  # because the loop ended early - would be silently checked against the
  # contract as though it were the deliverable.
  ads_nm <- grep("^rwdp_pros_pano_[0-9a-z_]+$", names(tabs), value = TRUE)
  if (length(ads_nm) != 1L) {
    cat("ADS NOT IDENTIFIED: expected exactly one rwdp_pros_pano_* write, found",
        length(ads_nm), if (length(ads_nm)) paste0("(", paste(ads_nm, collapse = ", "), ")") else "",
        "\n")
    ok <- FALSE
    final <- tabs[[length(tabs)]]          # fall back so the rest still reports
  } else {
    if (!identical(ads_nm, names(tabs)[length(tabs)])) {
      cat("ORDER: the ADS", ads_nm, "is not the last write - a stage was written after it\n")
      ok <- FALSE
    }
    final <- tabs[[ads_nm]]
    cat("ADS identified by name:", ads_nm, "\n")
  }
  cat("final ADS column count:", length(final$cols), "\n")

  # Every per-cohort ADS frame must expose identical columns or union_all lies.
  # Stage names carry the run tag, so the pattern must not anchor at $.
  # Require exactly seven: a `> 1` check passes on any two frames, so a build
  # that produced three cohorts and dropped four would still compare clean.
  coh <- tabs[grepl("_coh_tbl(_|$)", names(tabs))]
  if (length(coh) != 7L) {
    cat("COHORT COUNT: found", length(coh), "cohort frames, expected exactly 7\n")
    ok <- FALSE
  }
  if (length(coh) > 1) {
    ref <- coh[[1]]$cols
    bad <- names(coh)[vapply(coh, function(x) !identical(x$cols, ref), logical(1))]
    if (length(bad)) {
      cat("UNION MISMATCH across cohort frames:", paste(bad, collapse = ", "), "\n")
      ok <- FALSE
    } else {
      cat("union check: all", length(coh), "cohort frames share an identical column set\n")
    }
  } else {
    # Fewer than two cohort frames means the pattern matched nothing. That is
    # a failure, not a pass.
    cat("UNION CHECK DID NOT RUN - fewer than 2 cohort frames to compare\n")
    ok <- FALSE
  }

  # Compare against the independent, hand-maintained contract - not against a
  # file this script regenerated a moment ago.
  contract_file <- "validation/00_column_contract.csv"
  if (file.exists(contract_file)) {
    want <- utils::read.csv(contract_file, stringsAsFactors = FALSE)$column
    if (!identical(want, final$cols)) {
      missing <- setdiff(want, final$cols)
      extra   <- setdiff(final$cols, want)
      if (length(missing)) cat("CONTRACT: missing ->", paste(missing, collapse = ", "), "\n")
      if (length(extra))   cat("CONTRACT: unexpected ->", paste(extra, collapse = ", "), "\n")
      if (!length(missing) && !length(extra)) cat("CONTRACT: same columns, WRONG ORDER\n")
      ok <- FALSE
    } else {
      cat("column contract: matches", contract_file, "exactly (name and order)\n")
    }
  } else {
    cat("column contract: ", contract_file, " NOT FOUND - contract not checked\n", sep = "")
    ok <- FALSE
  }

  # ---------------------------------------------------------------------------
  # Anti-drift. Three files restate the contracts in a form a human reads, and
  # a restatement that nothing checks is a copy waiting to go stale.
  # ---------------------------------------------------------------------------

  # (0) Every module on disk must actually have been sourced. The driver checks
  #     that what it declares exists; this checks the other direction, so a
  #     module added to the folder but never wired into RDAP_MODULES cannot sit
  #     there looking live.
  on_disk <- sort(basename(list.files(MODULES, pattern = "\\.R$")))
  ran     <- sort(intersect(sourced, on_disk))
  if (!identical(ran, on_disk)) {
    cat("MODULE DRIFT: on disk but never sourced ->",
        paste(setdiff(on_disk, ran), collapse = ", "), "\n")
    ok <- FALSE
  } else {
    cat("modules: all", length(on_disk), "sourced by the driver, in order:",
        paste(sourced[sourced %in% on_disk], collapse = " -> "), "\n")
  }

  # (a) The generated null sweep must still match the column contract.
  sweep_file <- "validation/03b_null_sweep.sql"
  if (file.exists("validation/make_null_sweep.R")) {
    have <- if (file.exists(sweep_file)) readLines(sweep_file, warn = FALSE) else character()
    tmp  <- tempfile(fileext = ".sql")
    gen  <- new.env(parent = globalenv())
    # OUT must be pre-set: without it the generator writes to its default
    # path, and this check would rewrite the very file it is checking.
    assign("OUT", tmp, envir = gen)
    suppressMessages(sys.source("validation/make_null_sweep.R", envir = gen))
    want_sweep <- readLines(tmp, warn = FALSE)
    if (!identical(have, want_sweep)) {
      cat("DRIFT:", sweep_file, "does not match the column contract.",
          "Run: Rscript validation/make_null_sweep.R, then commit it.\n")
      ok <- FALSE
    } else {
      cat("null sweep: ", sweep_file, " is in sync with the column contract\n", sep = "")
    }
  }

  # (a2) The generated QC SQL must also match the column contract. Same
  #      arrangement as the null sweep above, and for the same reason: both
  #      enumerate every delivered column, and a hand-maintained list that
  #      long drifts silently. qc/make_qc_sql.R additionally fails if
  #      label/code pair discovery stops finding 25 pairs, so a renamed coded
  #      variable is caught here rather than at QC time.
  if (file.exists("qc/make_qc_sql.R")) {
    qc_files <- c(profile = "qc/01_variable_profile.sql",
                  pairs   = "qc/02_code_label_agreement.sql")
    tmp_prof <- tempfile(fileext = ".sql")
    tmp_pair <- tempfile(fileext = ".sql")
    gen <- new.env(parent = globalenv())
    assign("OUT_PROFILE", tmp_prof, envir = gen)
    assign("OUT_PAIRS",   tmp_pair, envir = gen)
    gen_ok <- tryCatch({
      suppressMessages(sys.source("qc/make_qc_sql.R", envir = gen)); TRUE
    }, error = function(e) {
      cat("QC GENERATOR FAILED:", conditionMessage(e), "\n"); FALSE
    })
    if (!gen_ok) {
      ok <- FALSE
    } else {
      drifted <- character()
      for (k in names(qc_files)) {
        f    <- qc_files[[k]]
        want <- readLines(if (k == "profile") tmp_prof else tmp_pair, warn = FALSE)
        have <- if (file.exists(f)) readLines(f, warn = FALSE) else character()
        if (!identical(have, want)) drifted <- c(drifted, f)
      }
      if (length(drifted)) {
        cat("DRIFT:", paste(drifted, collapse = ", "),
            "does not match the column contract.",
            "Run: Rscript qc/make_qc_sql.R, then commit.\n")
        ok <- FALSE
      } else {
        cat("qc sql: both generated QC files are in sync with the column contract\n")
      }
    }
  }

  # (b) The preflight's A2 `-- expect:` comments must match the input contract.
  #     They exist so an analyst can diff DESCRIBE output by eye, which means
  #     they are a second copy of validation/00_input_contract.csv.
  pf <- "validation/01_preflight_databricks.sql"
  if (file.exists(pf)) {
    # The preflight reads SOURCE tables only, so its placeholders must be
    # ${catalog} and ${src} alone. run_sql.R substitutes ${schema} as the
    # personal OUTPUT schema across the whole corpus, so a ${schema} or ${ads}
    # in this file would aim every preflight check at the wrong namespace.
    pf_code <- paste(sub("--.*$", "", readLines(pf, warn = FALSE)), collapse = "\n")
    bad_tok <- setdiff(unique(unlist(regmatches(pf_code,
                 gregexpr("\\$\\{[a-z_]+\\}", pf_code)))),
               c("${catalog}", "${src}"))
    if (length(bad_tok)) {
      cat("PREFLIGHT NAMESPACE: ", pf, " uses ", paste(bad_tok, collapse = ", "),
          " - only ${catalog} and ${src} belong in a source-side file\n", sep = "")
      ok <- FALSE
    }
    lines <- grep("^DESCRIBE TABLE .*-- expect:", readLines(pf, warn = FALSE), value = TRUE)
    stated <- lapply(lines, function(l) {
      tab <- sub("^DESCRIBE TABLE\\s+([^;]+);.*$", "\\1", l)
      tab <- sub(paste0("_", REFRESH, "$"), "", trimws(tab))
      cols <- trimws(strsplit(sub("^.*-- expect:\\s*", "", l), ",")[[1]])
      list(table = tab, cols = cols)
    })
    names(stated) <- vapply(stated, `[[`, character(1), "table")

    drift <- character()
    if (!setequal(names(stated), names(schema))) {
      drift <- c(drift,
        paste("tables:", paste(setdiff(names(schema), names(stated)), collapse = ", "),
              "absent from A2;",
              paste(setdiff(names(stated), names(schema)), collapse = ", "),
              "in A2 but not the contract"))
    }
    for (t in intersect(names(stated), names(schema))) {
      if (!identical(stated[[t]]$cols, schema[[t]])) {
        drift <- c(drift, paste0(t, ": A2 comment does not match the contract"))
      }
    }
    if (length(drift)) {
      cat("DRIFT: ", pf, " section A2 has fallen behind the input contract\n", sep = "")
      for (d in drift) cat("  -", d, "\n")
      ok <- FALSE
    } else {
      cat("preflight A2: expectations match the input contract (",
          length(stated), " tables)\n", sep = "")
    }
  }

  # Clear first. Otherwise the directory accumulates stages from earlier runs
  # under names the current build no longer produces, and a diff against a
  # previous run silently compares files the build never wrote.
  unlink(OUT_DIR, recursive = TRUE)
  dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)
  for (nm in names(tabs)) {
    writeLines(tabs[[nm]]$sql, file.path(OUT_DIR, paste0(nm, ".sql")))
  }
  writeLines(final$cols, file.path(OUT_DIR, "_final_ads_columns.txt"))
  cat("generated SQL written to", OUT_DIR, "\n")

  # ---- R helper leaking into SQL --------------------------------------------
  # dbplyr passes an unknown function through to SQL as a literal function
  # call: `safe_num(testresult)` written bare inside mutate() becomes
  # `safe_num(testresult)` in the query, Databricks cannot resolve it, and the
  # build dies at that stage. The fix is `!!safe_num(testresult)`, which
  # forces local evaluation.
  #
  # The check: any function defined in the modules whose name then appears as
  # a function call in the generated SQL has leaked.
  helper_defs <- unique(unlist(lapply(
    list.files(MODULES, pattern = "\\.R$", full.names = TRUE),
    function(f) {
      ln <- readLines(f, warn = FALSE)
      m  <- regmatches(ln, regexpr("^\\s*([A-Za-z._][A-Za-z0-9._]*)\\s*<-\\s*function", ln))
      sub("\\s*<-\\s*function$", "", trimws(m))
    })))
  gen_sql <- unlist(lapply(list.files(OUT_DIR, pattern = "\\.sql$", full.names = TRUE),
                           readLines, warn = FALSE))
  leaked <- Filter(function(fn) any(grepl(paste0("\\b", fn, "\\("), gen_sql)), helper_defs)
  if (length(leaked)) {
    cat("R HELPER LEAKED INTO SQL:", paste(leaked, collapse = ", "), "\n")
    cat("  dbplyr emitted these as literal SQL function calls. Databricks\n")
    cat("  cannot resolve them and the build will fail at that stage.\n")
    cat("  Fix: splice with !! at the call site, e.g. !!safe_num(testresult).\n")
    ok <- FALSE
  } else {
    cat("sql helpers: no R helper leaked into the generated SQL as a function call\n")
  }

  # ---- helper columns leaking into raw SQL ----------------------------------
  # A column created by mutate() must never be named inside a sql() literal.
  # dbplyr cannot see into that string, so it has no reason to push the mutate
  # into a subquery - and SQL will not let a WHERE clause reference an alias
  # defined in its own SELECT list, so Spark fails with UNRESOLVED_COLUMN
  # (e.g. `sql("DATE_ADD(anch_dt, 0)")` compiles to a predicate on an alias
  # in scope).
  #
  # dbplyr backticks every identifier it generates, so a bare identifier is a
  # string somebody wrote by hand. That is what the scan looks for.
  HELPER_COLS <- c("anch_dt", "val_x", "dt_x", "gap", "min_gap",
                   "first_dt", "pref_dt", "win_dt", "has_any", "hit_flag")
  bare <- character()
  for (f in list.files(OUT_DIR, pattern = "\\.sql$", full.names = TRUE)) {
    txt <- paste(readLines(f, warn = FALSE), collapse = "\n")
    for (h in HELPER_COLS) {
      if (grepl(paste0("(?<!`)\\b", h, "\\b(?!`)"), txt, perl = TRUE)) {
        bare <- union(bare, paste0(h, "  (", basename(f), ")"))
      }
    }
  }
  if (length(bare)) {
    cat("HELPER COLUMN IN RAW SQL:\n")
    for (b in bare) cat("  ", b, "\n", sep = "")
    cat("  These appear unquoted, so they came from a sql() string, not from\n")
    cat("  dbplyr. Rewrite the predicate with dbplyr verbs - e.g.\n")
    cat("  datediff(dt_x, anch_dt) <= n instead of DATE_ADD(anch_dt, n) - so\n")
    cat("  the dependency is visible and the mutate gets its own subquery.\n")
    ok <- FALSE
  } else {
    cat("helper columns: none named inside a raw sql() literal\n")
  }

  # ---- relocated input contract ---------------------------------------------
  # validation/01_preflight.R carries the executable copy of the required
  # source columns; validation/00_input_contract.csv is the hand-maintained
  # statement. Two copies drift, so this is the check that stops them. The
  # list is read by parsing the file for its required_columns assignment -
  # running the program needs a live connection.
  emb <- NULL
  if (file.exists("validation/01_preflight.R")) {
    for (e in parse("validation/01_preflight.R")) {
      if (is.call(e) && identical(e[[1]], as.name("<-")) &&
          identical(e[[2]], as.name("required_columns"))) {
        emb <- eval(e[[3]], envir = baseenv())
        break
      }
    }
  }
  if (is.null(emb)) {
    cat("validation/01_preflight.R DOES NOT DEFINE required_columns -",
        "the input contract gate is gone\n")
    ok <- FALSE
  } else {
    want <- split(contract$column, contract$table)
    emb  <- emb[order(names(emb))]
    want <- want[order(names(want))]
    if (!identical(lapply(emb, sort), lapply(want, sort))) {
      cat("DRIFT: required_columns in validation/01_preflight.R does not match",
          "validation/00_input_contract.csv\n")
      cat("  preflight only: ", paste(setdiff(names(emb), names(want)), collapse = ", "), "\n", sep = "")
      cat("  contract only: ", paste(setdiff(names(want), names(emb)), collapse = ", "), "\n", sep = "")
      for (t in intersect(names(emb), names(want))) {
        d <- c(setdiff(emb[[t]], want[[t]]), setdiff(want[[t]], emb[[t]]))
        if (length(d)) cat("  ", t, ": ", paste(d, collapse = ", "), "\n", sep = "")
      }
      ok <- FALSE
    } else {
      cat("input contract: validation/01_preflight.R matches the CSV (",
          length(emb), " tables / ", length(unlist(emb)), " columns)\n", sep = "")
    }
  }

  # ---- HRR panel lists ------------------------------------------------------
  # The build classifies with the panel vectors in 00_setup.R; the preflight
  # reports exclusions with its own copy. If they drift, qcr_hrr_excluded_r
  # lies about what the build excludes.
  pf_panels <- NULL
  if (file.exists("validation/01_preflight.R")) {
    for (e in parse("validation/01_preflight.R")) {
      if (is.call(e) && identical(e[[1]], as.name("<-")) &&
          identical(e[[2]], as.name("hrr_panels"))) {
        pf_panels <- eval(e[[3]], envir = baseenv())
        break
      }
    }
  }
  build_panels <- list(flatiron_all   = get0("hrr_panel_flatiron19", envir = env),
                       olaparib_label = get0("hrr_panel_olaparib",   envir = env),
                       talapro2       = get0("hrr_panel_talapro2",   envir = env))
  if (is.null(pf_panels) ||
      !identical(lapply(pf_panels, sort), lapply(build_panels, sort))) {
    cat("DRIFT: hrr_panels in validation/01_preflight.R does not match the",
        "panel vectors in 00_setup.R\n")
    ok <- FALSE
  } else {
    cat("hrr panels: validation/01_preflight.R matches 00_setup.R (",
        length(pf_panels), " panels)\n", sep = "")
  }

  # ---- lab analyte expectations ---------------------------------------------
  # C10's expected analyte/unit/component list must be the one production
  # filters with (lab_spec in 03_clinical.R) - the two diverged once already,
  # on unit trimming. Units compare trimmed, matching the build's Q69 rule.
  # List-level only: the executable join and gate semantics are not compared.
  pf_labs <- NULL
  if (file.exists("validation/01_preflight.R")) {
    for (e in parse("validation/01_preflight.R")) {
      if (is.call(e) && identical(e[[1]], as.name("<-")) &&
          identical(e[[2]], as.name("lab_expected"))) {
        pf_labs <- eval(e[[3]], envir = baseenv())
        break
      }
    }
  }
  build_spec <- get0("lab_spec", envir = env)
  norm_labs <- function(test, unit, comp) {
    d <- data.frame(test = tolower(test), unit = trimws(unit),
                    component = ifelse(is.na(comp), "", comp),
                    stringsAsFactors = FALSE)
    d <- d[order(d$test), , drop = FALSE]
    rownames(d) <- NULL
    d
  }
  if (is.null(pf_labs) || is.null(build_spec)) {
    cat("LAB SPEC CHECK DID NOT RUN - lab_expected or lab_spec not found\n")
    ok <- FALSE
  } else {
    comp_of <- function(x) {
      cv <- x$component
      if (length(cv) != 1 || is.na(cv)) NA_character_ else as.character(cv)
    }
    a <- norm_labs(pf_labs$testbasename, pf_labs$unit, pf_labs$component)
    b <- norm_labs(vapply(build_spec, `[[`, character(1), "test"),
                   vapply(build_spec, `[[`, character(1), "unit"),
                   vapply(build_spec, comp_of, character(1)))
    if (!identical(a, b)) {
      cat("DRIFT: C10 lab_expected in validation/01_preflight.R does not match",
          "lab_spec in 03_clinical.R\n")
      ok <- FALSE
    } else {
      cat("lab analytes: C10 expectations match production lab_spec (",
          nrow(a), " analytes)\n", sep = "")
    }
  }

  # The canonical SQL's C10 must apply the same trimmed-unit rule. The R and
  # production copies are diffed above; without this the SQL copy could slip
  # back to a raw compare and refuse a source production accepts.
  pf_sql_lines <- readLines("validation/01_preflight_databricks.sql", warn = FALSE)
  c10_from <- grep("^-- C10\\.", pf_sql_lines)[1]
  c10_to   <- grep("^-- C10c", pf_sql_lines)[1]
  c10_body <- if (!is.na(c10_from) && !is.na(c10_to) && c10_to > c10_from) {
    pf_sql_lines[c10_from:c10_to]
  } else {
    character()   # section not found - the grepl below then fails, loudly
  }
  if (!any(grepl("TRIM\\(testunitscleaned\\)", c10_body))) {
    cat("DRIFT: canonical SQL C10 does not TRIM testunitscleaned -",
        "production compares trimmed units (Q69)\n")
    ok <- FALSE
  } else {
    cat("c10 sql: canonical preflight compares trimmed units\n")
  }

  # ---- corrected spec -------------------------------------------------------
  # docs/SPEC.csv is the specification the build implements. Its Column rows
  # must be the delivered columns, same names, same order. Without this the
  # spec can quietly stop describing what ships.
  spec <- utils::read.csv("docs/SPEC.csv", stringsAsFactors = FALSE)
  spec_cols <- spec$variable[spec$kind == "Column"]
  if (!identical(spec_cols, final$cols)) {
    cat("DRIFT: docs/SPEC.csv does not match the delivered columns.\n")
    cat("  in the spec, not delivered: ",
        paste(setdiff(spec_cols, final$cols), collapse = ", "), "\n", sep = "")
    cat("  delivered, not in the spec: ",
        paste(setdiff(final$cols, spec_cols), collapse = ", "), "\n", sep = "")
    if (setequal(spec_cols, final$cols)) cat("  same names, different order\n")
    ok <- FALSE
  } else {
    cat("corrected spec: docs/SPEC.csv describes all ", length(spec_cols),
        " delivered columns, in order\n", sep = "")
  }

  # ---- the variable tables in VARIABLES.md ----------------------------------
  # Section 5 of docs/VARIABLES.md restates each column's label, values and
  # definition so a reviewer can tally the build against the spec in one place.
  # Two copies of the same text drift, so the list and its order are checked
  # here. The text itself is not compared - it is meant to be readable prose -
  # but a variable that appears in one and not the other is caught.
  vmd <- readLines("docs/VARIABLES.md", warn = FALSE)
  s5 <- grep("^## 5\\. ", vmd)
  s6 <- grep("^## 6\\. ", vmd)
  if (length(s5) != 1L || length(s6) != 1L || s6 <= s5)
    stop("docs/VARIABLES.md: cannot locate section 5", call. = FALSE)
  vrows <- grep("^\\| [0-9]+ \\| `[A-Z][A-Z0-9_]*`", vmd[s5:s6], value = TRUE)
  vvars <- tolower(sub("^\\| [0-9]+ \\| `([A-Z0-9_]+)`.*$", "\\1", vrows))
  vpos  <- as.integer(sub("^\\| ([0-9]+) \\|.*$", "\\1", vrows))
  if (!setequal(vvars, spec_cols) || !identical(spec_cols[vpos], vvars)) {
    cat("DRIFT: docs/VARIABLES.md section 5 does not match docs/SPEC.csv.\n")
    cat("  in the spec, not tabulated: ",
        paste(setdiff(spec_cols, vvars), collapse = ", "), "\n", sep = "")
    cat("  tabulated, not in the spec: ",
        paste(setdiff(vvars, spec_cols), collapse = ", "), "\n", sep = "")
    if (setequal(vvars, spec_cols))
      cat("  same names; a row's number is not its delivered position\n")
    ok <- FALSE
  } else {
    cat("variable tables: docs/VARIABLES.md tabulates all ", length(vvars),
        " columns, each numbered with its delivered position\n", sep = "")
  }

  # Every column row needs a definition. A blank one is a column nobody wrote
  # a rule for, which is the thing this file exists to stop.
  blank <- spec_cols[!nzchar(trimws(spec$definition[spec$kind == "Column"]))]
  if (length(blank)) {
    cat("SPEC GAP: no definition for: ", paste(blank, collapse = ", "), "\n", sep = "")
    ok <- FALSE
  }

  # ---- deviations -----------------------------------------------------------
  # The register is hand-maintained and machine-read. Parse it here so a
  # broken table fails the harness rather than the coverage gate.
  dev <- try(read_deviations(), silent = TRUE)
  if (inherits(dev, "try-error")) {
    cat("THE REGISTER IN VARIABLES.md WILL NOT PARSE:\n  ", conditionMessage(attr(dev, "condition")), "\n")
    ok <- FALSE
  } else {
    cat("register: docs/VARIABLES.md parses, ", nrow(dev), " decisions\n", sep = "")
  }

  # ---- decision coverage ----------------------------------------------------
  # Every register row that changes a delivered value must be named by at
  # least one check. A check that covers a decision without citing it is
  # invisible coverage and rots the same way as none. qc/00_coverage.R makes
  # the naming a maintained property.
  if (file.exists("qc/00_coverage.R")) {
    cov <- suppressWarnings(system2("Rscript", "qc/00_coverage.R",
                                    stdout = TRUE, stderr = TRUE))
    if (!is.null(attr(cov, "status")) && attr(cov, "status") != 0L) {
      cat("DECISION COVERAGE FAILED:\n")
      cat(paste0("  ", cov, collapse = "\n"), "\n")
      ok <- FALSE
    } else {
      cat("decision coverage: ",
          sub("^\\s*", "", grep("covered", cov, value = TRUE)[1]),
          " of ", sub("^\\s*", "", grep("require a check", cov, value = TRUE)[1]),
          "\n", sep = "")
    }
  }

  # ---- documented column counts ---------------------------------------------
  # The column count is quoted in prose across the repo - README, the driver
  # header, the contract checker, the null-sweep generator, the preflight and
  # the output validator - and a stale figure there teaches a reader the wrong
  # number. Check every quoted figure against the contract.
  #
  # Matched tightly, on purpose: only a 3-digit number that directly qualifies
  # the word "column(s)" - "190 columns", "190-column", "all **190** columns" -
  # or follows "counting to". A looser pattern flags correct derived figures
  # ("out of 190. The other 159 could", where 159 is right), and a check that
  # cries wolf is a check someone switches off.
  pats <- c("\\b([0-9]{3})\\b(?=[*\\s-]{0,4}columns?\\b)",
            "counting to ([0-9]{3})")
  doc_files <- c(DRIVER,
                 file.path(MODULES, "06_assemble.R"),
                 "validation/04_column_contract_check.R",
                 "validation/make_null_sweep.R",
                 "validation/01_preflight_databricks.sql",
                 "validation/03_output_validation_databricks.sql")
  stale <- character()
  for (f in doc_files[file.exists(doc_files)]) {
    for (ln in readLines(f, warn = FALSE)) {
      for (pat in pats) {
        for (m in regmatches(ln, gregexpr(pat, ln, perl = TRUE))[[1]]) {
          n <- as.integer(regmatches(m, regexpr("[0-9]{3}", m)))
          if (!is.na(n) && n != length(final$cols))
            stale <- c(stale, sprintf("%s: '%s'", f, trimws(ln)))
        }
      }
    }
  }
  if (length(stale)) {
    ok <- FALSE
    cat("STALE COLUMN COUNT in prose - contract has", length(final$cols), "\n",
        paste(" ", unique(stale), collapse = "\n"), "\n")
  } else {
    cat("column count: every documented figure matches the contract (",
        length(final$cols), ")\n", sep = "")
  }

  # OUT_DIR is git-ignored - derived output, not source - so a git diff of it
  # is empty whatever the code does. The manifest is tracked, which makes
  # `git diff` on it a real signal: a commit that claims the query set is
  # unchanged has to show this file unchanged too, and a logic change shows
  # exactly which stages moved.
  files <- sort(list.files(OUT_DIR, full.names = TRUE))
  writeLines(
    sprintf("%s  %s", vapply(files, tools::md5sum, character(1)), basename(files)),
    MANIFEST)
  cat("query manifest written to", MANIFEST,
      "- commit it; a diff here means the delivered SQL moved\n")
}

cat("\n", if (ok) "PASS" else "FAIL", "\n", sep = "")
quit(status = if (ok) 0L else 1L)
