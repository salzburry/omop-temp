-- =============================================================================
-- PRE-RULING SNAPSHOT - METADATA RECOVERY.  RUN ONLY AFTER A2b STOPPED THE TAKE.
-- =============================================================================
-- WHEN TO USE THIS. 00a_pre_ruling_snapshot_TAKE.sql captured the snapshot in A1
-- and then stopped at A2b because the metadata row still carried its FILL IN
-- placeholders. A1's table is GOOD and must not be touched: if A2b reported
-- no_rows, no_patients, cohorts_missing and baseline_mismatch all zero, the
-- captured table IS the pre-ruling ADS, and it is the one thing here that
-- cannot be recreated once the rebuild starts. This file rebuilds only the
-- metadata row, then runs the checks that never got to run - A2b and A3.
--
-- WHY A SEPARATE FILE, and not START_AT. The runner refuses an offset on a
-- file that writes, and pasting A2/A2b into a SQL editor turns their
-- assertions into inert comments - which is exactly how an unattributed
-- snapshot would pass. So recovery has to be a file the runner executes from
-- the top:
--
--     Rscript validation/run_sql.R validation/00a_recover_metadata.sql
--
-- FILL THE THREE LITERALS BELOW FIRST or this stops where the first attempt
-- did. `build_version` must read like 202606.26 - the program_version of the build
-- that produced the table being snapshotted, not of the code running now.
--
-- IT DROPS ONLY THE METADATA TABLE. Read the DROP before running it. If A1's
-- own capture had failed, the answer would be to drop BOTH tables and run 00a
-- from the top instead - but A2b's zeros are what tell you it did not.
--
--   ${catalog} = hive_metastore
--   ${schema}  = your personal schema
--   ${ads}     = rwdp_pros_pano_2026m06
-- =============================================================================

USE CATALOG ${catalog};

-- ---------------------------------------------------------------------------
-- M0. OLD-NAME DETECTION.  MUST return no rows.
--
-- The snapshot tables were called pre_q82_ads and pre_q82_ads_meta until
-- 2026-09-13. A snapshot taken before that rename still carries the old names,
-- and every statement below looks for the new ones - so the old snapshot would
-- be invisible and this file would quietly capture a second one, or the
-- comparison would report nothing to compare.
--
-- This is a STATEMENT, not a comment, on purpose: a migration note written as
-- `--` text is stripped by validation/run_sql.R before the SQL is sent, so it
-- can never stop anything. This can, and the assertion below makes it stop.
--
-- If it returns a row, run these two once and then re-run this file:
--
--     ALTER TABLE ${schema}.pre_q82_ads      RENAME TO ${schema}.pre_ruling_ads;
--     ALTER TABLE ${schema}.pre_q82_ads_meta RENAME TO ${schema}.pre_ruling_ads_meta;
--
-- @assert no-rows
-- ---------------------------------------------------------------------------
SHOW TABLES IN ${schema} LIKE 'pre_q82_ads*';

-- The metadata row only. The snapshot itself is NOT dropped here and must not
-- be: it is the only copy of the pre-ruling table.
DROP TABLE IF EXISTS ${schema}.pre_ruling_ads_meta;

-- ---------------------------------------------------------------------------
-- A2. Provenance. Fill the three literals by hand BEFORE running - they are
-- the only proof of which build the snapshot came from, and nothing in the ADS
-- records it.
--
-- The counts are taken from the SNAPSHOT, not from the ADS. Counting the ADS
-- again here would describe whatever the source table holds at this moment,
-- which is not necessarily what A1 captured a second earlier - and the whole
-- point of the row is to describe the snapshot.
-- ---------------------------------------------------------------------------
CREATE TABLE ${schema}.pre_ruling_ads_meta AS
SELECT current_timestamp()                      AS captured_at,
       current_user()                           AS captured_by,
       '${ads}'                                 AS source_table,
       'PRE-RULING'                                AS state,
       'FILL IN: program_version of the build that produced ${ads}' AS build_version,
       'FILL IN: refresh, e.g. 2026m06'         AS refresh,
       'FILL IN: HRR panel, e.g. flatiron_all'  AS hrr_panel,
       (SELECT COUNT(*)              FROM ${schema}.pre_ruling_ads) AS rows_captured,
       (SELECT COUNT(DISTINCT patid) FROM ${schema}.pre_ruling_ads) AS patients_captured;

--                           do NOT loosen this to make a run pass.
--
--   PROVENANCE THAT MEANS SOMETHING
--     fill_in_left          a FILL IN literal survived.
--     version_malformed      not a program_version. A blank, a NULL or a note
--                           to self passed the FILL IN test and attributed
--                           nothing.
--     refresh_mismatch      the recorded refresh is not the one in the table
--                           name being captured.
--     panel_unknown         not one of the three names the build accepts.
--
-- @assert zero meta_empty
-- @assert zero rowcount_mismatch
-- @assert zero no_rows
-- @assert zero no_patients
-- @assert zero cohorts_missing
-- @assert zero baseline_mismatch
-- @assert zero fill_in_left
-- @assert zero version_malformed
-- @assert zero refresh_mismatch
-- @assert zero panel_unknown
-- ---------------------------------------------------------------------------
WITH snap AS (SELECT COUNT(*) AS n, COUNT(DISTINCT patid) AS p,
                     COUNT(DISTINCT cohortn) AS c
              FROM ${schema}.pre_ruling_ads),
meta AS (SELECT COUNT(*) AS n, MAX(rows_captured) AS rows_captured,
                MAX(build_version) AS build_version, MAX(refresh) AS refresh,
                MAX(hrr_panel) AS hrr_panel
         FROM ${schema}.pre_ruling_ads_meta),
-- the 2026-08-09 accepted counts; the snapshot should reproduce them exactly
baseline AS (SELECT * FROM VALUES
               (1,197903),(2,134281),(3,79051),(4,50502),
               (5,28980),(6,16073),(7,8616) AS t(cohortn, expected))
SELECT (SELECT CASE WHEN n = 0 THEN 1 ELSE 0 END FROM meta)          AS meta_empty,
       (SELECT CASE WHEN m.rows_captured IS DISTINCT FROM s.n
                    THEN 1 ELSE 0 END FROM meta m CROSS JOIN snap s) AS rowcount_mismatch,
       (SELECT CASE WHEN n = 0 THEN 1 ELSE 0 END FROM snap)          AS no_rows,
       (SELECT CASE WHEN p = 0 THEN 1 ELSE 0 END FROM snap)          AS no_patients,
       (SELECT 7 - c FROM snap)                                      AS cohorts_missing,
       (SELECT COUNT(*) FROM baseline b
        LEFT JOIN (SELECT cohortn, COUNT(DISTINCT patid) actual
                   FROM ${schema}.pre_ruling_ads GROUP BY cohortn) a
          ON a.cohortn = b.cohortn
        WHERE COALESCE(a.actual, 0) <> b.expected)                   AS baseline_mismatch,
       (SELECT COUNT(*) FROM ${schema}.pre_ruling_ads_meta
        WHERE build_version LIKE 'FILL IN%'
           OR refresh      LIKE 'FILL IN%'
           OR hrr_panel    LIKE 'FILL IN%')                          AS fill_in_left,
       (SELECT CASE WHEN build_version RLIKE '^[0-9]{6}\\.[0-9]+$'
                    THEN 0 ELSE 1 END FROM meta)                     AS version_malformed,
       (SELECT CASE WHEN '${ads}' LIKE CONCAT('%', refresh, '%')
                    THEN 0 ELSE 1 END FROM meta)                     AS refresh_mismatch,
       (SELECT CASE WHEN hrr_panel IN ('flatiron_all','olaparib_label','talapro2')
                    THEN 0 ELSE 1 END FROM meta)                     AS panel_unknown;

--
-- Do not reach for START_AT to skip A1 - the runner refuses an offset on a file
-- that writes, because replaying a CREATE collides with what the first attempt
-- left and skipping it leaves the rest reading a table that does not exist.
-- If A1 itself failed, drop BOTH tables and run the file from the top.
-- ---------------------------------------------------------------------------

-- A3. Grain assertion. Every comparison in part B joins on (patid, cohortn),
-- so a duplicate key would inflate its counts silently. V01 asserts this on a
-- delivered table, but the snapshot is a copy and nothing has re-checked it.
-- MUST return zero rows.
-- @assert no-rows
-- ---------------------------------------------------------------------------
SELECT patid, cohortn, COUNT(*) AS n
FROM   ${schema}.pre_ruling_ads
GROUP  BY patid, cohortn
HAVING COUNT(*) > 1;

-- ---------------------------------------------------------------------------
-- A4. Read this back and put it in the release evidence before rebuilding.
-- If build_version still says FILL IN, the snapshot cannot be attributed to a
-- build and is worth much less. Fix it now, not later.
-- ---------------------------------------------------------------------------
SELECT * FROM ${schema}.pre_ruling_ads_meta;
