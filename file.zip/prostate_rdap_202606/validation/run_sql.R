# =============================================================================
# RUN A .sql FILE FROM R, OVER THE BUILD'S OWN CONNECTION
# =============================================================================
#   Rscript validation/run_sql.R qc/08_death_date_formats.sql   (from repo root)
#   Rscript validation/run_sql.R qc/03_cross_variable_rules.sql qc/09_vitals_domain.sql
#
# The .sql files in qc/ and validation/ are written for the SQL editor, with
# ${catalog} / ${schema} / ${ads} / ${src} to substitute by hand. This runs
# them from R instead: same SQL, statement by statement, no rewriting. The
# placeholders are filled from the variables 00_setup.R itself sets, so this
# cannot check a different table from the one the build wrote.
#
# The namespace contract, which every .sql file must follow: ${schema} is the
# personal OUTPUT schema and qualifies only ${schema}.${ads}; ${src} is the
# SOURCE schema and qualifies only source tables. The offline harness fails
# if the preflight file breaks this.
#
# It does not translate SQL into dplyr: a translation is a second
# implementation that can disagree with the first; executing the same text
# cannot.
#
# RENDER_ONLY=1 skips the connection and prints the substituted statements,
# for pasting into the SQL editor with the schema already filled in.
#
# ASSERTIONS - why this runner can fail on a VALUE
#
# A .sql check whose comment says "MUST return zero" enforced nothing here: the
# runner printed the number and moved on, and exited nonzero only if the SQL
# itself errored. So a preflight gate could report a defect and the run would
# still look clean. A file now declares its pass condition where the condition
# lives, next to the statement, and this runner evaluates it:
#
#   -- @assert no-rows                    the statement must return no rows
#   -- @assert min-rows <n>               at least n rows
#   -- @assert zero <col>                 every value in <col> is 0
#   -- @assert zero <col> when <c>=<v>    ... only for rows where <c> = <v>
#   -- @assert positive <col>             every value in <col> is > 0
#   -- @assert none <col> in <V1>,<V2>    no row's <col> is any of these
#
# Directives attach to the NEXT statement, so write them in the comment block
# above it. Several may apply to one statement.
#
# A VIOLATION STOPS THE RUN. These are assertions, not measurements: if one
# fails, whatever the rest of the file assumes is no longer true. B0 in the
# snapshot comparison is the clearest case - every figure below it is
# meaningless if the snapshot is a copy of the new table. The result set is
# printed before the assertion is evaluated, so the numbers are on screen
# either way.
#
# A directive naming a column the result does not have is a VIOLATION, not a
# skip. Silently passing when a column is renamed is how a check stops
# checking without anyone noticing. A NULL is a violation too, wherever it
# lands: a filtered SUM over an empty relation returns NULL in Spark, and a
# NULL status is a row nothing has judged. "Not measured" and "no verdict" are
# both different claims from "passed".
#
# Directive SYNTAX is validated even under RENDER_ONLY, where nothing is
# evaluated - so a typo is caught without a database.
#
# TWO WAYS A RUN USED TO CONTINUE PAST SOMETHING IT SHOULD NOT
#
# START_AT=n resumes at statement n. It skips the row-returning statements
# before n - and it used to skip their assertions with them, so B0 or the
# mandatory preflight block could be stepped over while the queries depending
# on them still ran. It now REFUSES an offset that would skip an asserted
# statement, and refuses an offset at all when several files are given, which
# the old comment claimed but nothing enforced.
#
# A failed statement used to be counted and passed over. Everything after it
# then ran against state it was supposed to establish, and those results looked
# ordinary. The run now stops at the first error. ON_ERROR=continue restores the
# sweep for diagnosis: every later result is labelled UNTRUSTED and the run
# still exits nonzero.
# =============================================================================

files <- commandArgs(trailingOnly = TRUE)
if (!length(files) && exists("sql_files")) files <- sql_files
if (!length(files))
  stop("usage: Rscript validation/run_sql.R <file.sql> [<file.sql> ...]",
       call. = FALSE)
missing_files <- files[!file.exists(files)]
if (length(missing_files))
  stop("no such file: ", paste(missing_files, collapse = ", "), call. = FALSE)

render_only <- nzchar(Sys.getenv("RENDER_ONLY"))
# Default: a failed statement stops the run. ON_ERROR=continue sweeps the whole
# file for diagnosis instead, still exiting nonzero at the end.
on_error_continue <- identical(tolower(Sys.getenv("ON_ERROR")), "continue")
if (!render_only) {
  if (!exists("con")) {
    message("no open connection - sourcing code/modules/00_setup.R")
    source("code/modules/00_setup.R")
  }
  stopifnot(exists("con"), exists("output_catalog"), exists("personal_schema"),
            exists("output_table"), exists("source_schema"))
}

# In render mode there is no session to read, so fall back to the values
# 00_setup.R pins. If they move there, they move here.
SUBS <- c("${catalog}"    = get0("output_catalog",  ifnotfound = "hive_metastore"),
          "${schema}"     = get0("personal_schema", ifnotfound = "osk02156"),
          "${ads}"        = get0("output_table",    ifnotfound = "rwdp_pros_pano_2026m06"),
          "${src}"        = get0("source_schema",   ifnotfound = "clnprw_flatiron_pano_pros_use"))

# One statement ends where a line ends in ";". A ";" mid-line never terminates
# a statement here: across the corpus it occurs only inside quoted label text
# and in comments. Inline "--" comments occur only after code, never inside a
# quoted string, so stripping from "--" is safe.
# Directives are read BEFORE comments are stripped, and validated here so a
# malformed one is a hard error rather than an assertion that quietly does
# nothing. Returns a list per statement: $sql and $asserts.
ASSERT_FORMS <- c("no-rows", "min-rows", "zero", "positive", "none")

parse_assert <- function(spec, path) {
  p    <- strsplit(trimws(spec), "[[:space:]]+")[[1]]
  kind <- tolower(p[1])
  bad  <- function(why)
    stop(path, ": cannot read `-- @assert ", spec, "` - ", why,
         "\nForms: ", paste(ASSERT_FORMS, collapse = ", "), call. = FALSE)
  if (!kind %in% ASSERT_FORMS) bad("unknown form")
  if (kind == "no-rows") {
    if (length(p) != 1L) bad("takes no argument")
    list(kind = kind, spec = spec)
  } else if (kind == "min-rows") {
    if (length(p) != 2L) bad("needs a count")
    n <- suppressWarnings(as.integer(p[2]))
    if (is.na(n) || n < 0L) bad("count must be a non-negative integer")
    list(kind = kind, n = n, spec = spec)
  } else if (kind == "positive") {
    if (length(p) != 2L) bad("needs one column")
    list(kind = kind, col = tolower(p[2]), spec = spec)
  } else if (kind == "zero") {
    # zero <col>  |  zero <col> when <col>=<value>
    if (!length(p) %in% c(2L, 4L)) bad("needs `zero <col>` or `zero <col> when <col>=<value>`")
    a <- list(kind = kind, col = tolower(p[2]), spec = spec)
    if (length(p) == 4L) {
      if (tolower(p[3]) != "when") bad("third word must be `when`")
      kv <- strsplit(p[4], "=", fixed = TRUE)[[1]]
      if (length(kv) != 2L || !nzchar(kv[1]) || !nzchar(kv[2]))
        bad("the filter must read <col>=<value>")
      a$when_col <- tolower(kv[1]); a$when_val <- kv[2]
    }
    a
  } else {
    if (length(p) != 4L || tolower(p[3]) != "in")
      bad("needs `none <col> in <V1>,<V2>`")
    vals <- trimws(strsplit(p[4], ",", fixed = TRUE)[[1]])
    vals <- vals[nzchar(vals)]
    if (!length(vals)) bad("names no values")
    list(kind = kind, col = tolower(p[2]), vals = vals, spec = spec)
  }
}

# Statements safe to replay when resuming: they set connection state and nothing
# else. Anything outside this list is skipped rather than re-executed.
is_session_state <- function(first)
  grepl("^\\s*(USE|SET)\\b", toupper(trimws(first)))

read_statements <- function(path) {
  raw <- readLines(path, warn = FALSE)
  out <- list(); buf <- character(0); pend <- list()
  for (l in raw) {
    d <- regmatches(l, regexec("^\\s*--\\s*@assert\\s+(.+?)\\s*$", l))[[1]]
    if (length(d) == 2L) pend[[length(pend) + 1L]] <- parse_assert(d[2], path)
    code <- sub("--.*$", "", l)
    if (!nzchar(trimws(code))) next
    buf <- c(buf, code)
    if (grepl(";\\s*$", code)) {
      out[[length(out) + 1L]] <- list(
        sql     = sub(";\\s*$", "", paste(buf, collapse = "\n")),
        asserts = pend)
      buf <- character(0); pend <- list()
    }
  }
  if (length(buf))
    out[[length(out) + 1L]] <- list(sql = paste(buf, collapse = "\n"),
                                    asserts = pend)
  if (length(pend) && !length(buf))
    stop(path, ": @assert directives trail the last statement with nothing to ",
         "attach to - they apply to the statement BELOW them.", call. = FALSE)
  out
}

# Returns a character vector of violations - empty means the assertion held.
check_asserts <- function(res, asserts) {
  if (!length(asserts)) return(character(0))
  nms <- tolower(names(res))
  col <- function(name) {
    i <- match(name, nms)
    if (is.na(i)) return(NULL)
    res[[i]]
  }
  msgs <- character(0)
  for (a in asserts) {
    if (a$kind == "no-rows") {
      if (nrow(res) > 0L)
        msgs <- c(msgs, sprintf("`%s`: expected no rows, got %d", a$spec, nrow(res)))
      next
    }
    if (a$kind == "min-rows") {
      if (nrow(res) < a$n)
        msgs <- c(msgs, sprintf("`%s`: expected at least %d row(s), got %d",
                                a$spec, a$n, nrow(res)))
      next
    }
    v <- col(a$col)
    if (is.null(v)) {
      msgs <- c(msgs, sprintf("`%s`: no column `%s` in the result (has: %s)",
                              a$spec, a$col, paste(nms, collapse = ", ")))
      next
    }
    keep <- rep(TRUE, length(v))
    if (!is.null(a$when_col)) {
      w <- col(a$when_col)
      if (is.null(w)) {
        msgs <- c(msgs, sprintf("`%s`: no filter column `%s` in the result (has: %s)",
                                a$spec, a$when_col, paste(nms, collapse = ", ")))
        next
      }
      keep <- !is.na(w) & trimws(as.character(w)) == a$when_val
      if (!any(keep)) {
        # A filter matching nothing means the assertion tested nothing at all,
        # which is not the same as holding.
        msgs <- c(msgs, sprintf(
          "`%s`: the filter %s=%s matched no row, so the assertion tested nothing",
          a$spec, a$when_col, a$when_val))
        next
      }
    }
    v <- v[keep]
    if (!length(v)) {
      # Same rule as `zero` and `positive` below: an assertion over no rows has
      # tested nothing. `none` reached that conclusion by a different route -
      # `any(logical(0))` is FALSE - and was missed when the others were fixed.
      msgs <- c(msgs, sprintf(
        "`%s`: the result has no rows, so this assertion tested nothing", a$spec))
      next
    }
    if (a$kind == "none") {
      # A NULL verdict is a violation, for the same reason a NULL count is: the
      # column was asked for a decision and did not give one. Reading it as
      # "not one of the forbidden values" would pass a row nothing has judged.
      if (any(is.na(v)))
        msgs <- c(msgs, sprintf(
          "`%s`: %d of %d row(s) have a NULL %s - a missing verdict is not a pass",
          a$spec, sum(is.na(v)), length(v), a$col))
      hit <- !is.na(v) & trimws(as.character(v)) %in% a$vals
      if (any(hit))
        msgs <- c(msgs, sprintf("`%s`: %d row(s) carry %s", a$spec, sum(hit),
                                paste(unique(trimws(as.character(v[hit]))), collapse = ", ")))
      next
    }
    # B1.8: `any(numeric(0))` is FALSE, so a statement returning NO ROWS used to
    # satisfy both `zero` and `positive` - a B0 that returned nothing would have
    # passed `positive rows_only_in_snapshot`. An assertion over an empty result
    # has tested nothing, which is not the same as holding.
    if (!length(v)) {
      msgs <- c(msgs, sprintf(
        "`%s`: the result has no rows, so this assertion tested nothing", a$spec))
      next
    }
    num <- suppressWarnings(as.numeric(v))
    if (any(is.na(num))) {
      msgs <- c(msgs, sprintf(
        "`%s`: %d of %d value(s) are NULL or non-numeric - \"not measured\" is not \"zero\"",
        a$spec, sum(is.na(num)), length(num)))
      next
    }
    if (a$kind == "zero" && any(num != 0))
      msgs <- c(msgs, sprintf("`%s`: %d of %d row(s) are nonzero (max %s)",
                              a$spec, sum(num != 0), length(num), format(max(num))))
    if (a$kind == "positive" && any(num <= 0))
      msgs <- c(msgs, sprintf("`%s`: %d of %d row(s) are not > 0 (min %s)",
                              a$spec, sum(num <= 0), length(num), format(min(num))))
  }
  msgs
}

n_failed <- 0L
for (f in files) {
  cat("\n==== ", f, " ====\n", sep = "")
  parsed <- read_statements(f)
  stmts  <- vapply(parsed, `[[`, character(1), "sql")
  for (nm in names(SUBS)) stmts <- gsub(nm, SUBS[[nm]], stmts, fixed = TRUE)
  left <- unique(unlist(regmatches(stmts, gregexpr("\\$\\{[a-z_]+\\}", stmts))))
  if (length(left))
    stop(f, " uses a placeholder this runner does not know: ",
         paste(left, collapse = ", "), call. = FALSE)
  cat(length(stmts), " statement(s)\n", sep = "")

  # START_AT=n resumes a crashed run at statement n. USE statements before n
  # still execute, so the session lands in the right catalog and schema; only
  # the row-returning statements are skipped.
  #
  # IT CANNOT SKIP AN ASSERTED STATEMENT. Skipping one skips its assertion too,
  # which is how B0 or the mandatory preflight block could be stepped over while
  # the evidence queries that depend on them still ran. Resuming past a crash is
  # a fair need; resuming past a gate is not, so this refuses rather than warns.
  # Re-run from the top, or move the resume point back above the gate.
  start_at <- suppressWarnings(as.integer(Sys.getenv("START_AT", "1")))
  if (is.na(start_at) || start_at < 1L) start_at <- 1L
  if (start_at > 1L) {
    # The single-file rule was stated in a comment and enforced nowhere. An
    # offset means nothing across several files - statement 12 of which one?
    if (length(files) > 1L)
      stop("START_AT applies to a single file; ", length(files), " were given.",
           call. = FALSE)
    if (start_at > length(stmts))
      stop("START_AT=", start_at, " is past the end of ", f, ", which has ",
           length(stmts), " statement(s). Every result query would be skipped ",
           "and the run would still report success.", call. = FALSE)
    # A file that WRITES cannot be resumed: re-running a CREATE collides with
    # what the first attempt left, and skipping it leaves the rest reading a
    # table that does not exist. 00a is the case that matters - drop its tables
    # by hand and start over.
    writes <- which(vapply(stmts, function(x)
      grepl("^\\s*(CREATE|INSERT|DROP|ALTER|MERGE|UPDATE|DELETE|TRUNCATE|REPLACE)\\b",
            toupper(trimws(strsplit(x, "\n")[[1]][1]))), logical(1)))
    if (length(writes))
      stop("START_AT cannot be used on ", f, ": statement(s) ",
           paste(writes, collapse = ", "), " write. Resuming would either ",
           "re-run them or leave later statements reading what they never ",
           "created. Drop what the failed attempt left and run from the top.",
           call. = FALSE)
    gated <- which(vapply(parsed[seq_len(start_at - 1L)],
                          function(x) length(x$asserts) > 0L, logical(1)))
    if (length(gated))
      stop("START_AT=", start_at, " would skip statement(s) ",
           paste(gated, collapse = ", "), " of ", f,
           ", which carry assertions:\n  ",
           paste(unlist(lapply(parsed[gated],
                               function(x) vapply(x$asserts, `[[`, character(1), "spec"))),
                 collapse = "\n  "),
           "\nSkipping a statement skips its assertion. Re-run from the top, or ",
           "set START_AT at or below the first asserted statement.",
           call. = FALSE)
  }

  for (i in seq_along(stmts)) {
    s     <- stmts[[i]]
    first <- trimws(strsplit(s, "\n")[[1]][1])
    cat("\n-- [", i, "/", length(stmts), "] ", first, "\n", sep = "")
    if (render_only) { cat(s, ";\n", sep = ""); next }

    returns_rows <- grepl("^(SELECT|WITH|DESCRIBE|SHOW|EXPLAIN)\\b",
                          toupper(first))
    if (i < start_at) {
      # B1.9: only SESSION STATE is replayed. This used to execute every
      # non-row-returning statement, which re-ran the CREATE TABLEs in 00a and
      # collided with the tables the first attempt left behind - so the one file
      # most worth resuming was the one that could not be. DDL and DML are
      # skipped and named instead.
      if (is_session_state(first)) {
        DBI::dbExecute(con, s); cat("ok (session state)\n")
      } else if (!returns_rows) {
        cat("SKIPPED, not replayed (START_AT=", start_at, "): ", first, "\n", sep = "")
      } else {
        cat("skipped (START_AT=", start_at, ")\n", sep = "")
      }
      next
    }
    if (!returns_rows) {
      # USE and friends set connection state; running on after one fails would
      # aim every later statement at the wrong schema, so those stop hard.
      DBI::dbExecute(con, s)
      cat("ok\n")
      next
    }
    res <- tryCatch(DBI::dbGetQuery(con, s), error = function(e) e)
    if (inherits(res, "error")) {
      n_failed <- n_failed + 1L
      cat("FAILED: ", conditionMessage(res), "\n", sep = "")
      # Carrying on after an error runs the rest against state this statement
      # was supposed to establish, and the results look ordinary. Stop, unless
      # the operator has asked for a diagnostic sweep.
      if (!on_error_continue) {
        cat("\nStopping at the first error. Everything below this statement ",
            "would run against state it did not establish.\n",
            "Set ON_ERROR=continue for a diagnostic sweep - the run still ",
            "exits nonzero and every later result is marked untrusted.\n", sep = "")
        quit(status = 1L)
      }
      cat("ON_ERROR=continue - results below are UNTRUSTED\n")
      next
    }
    cat(nrow(res), " row(s)\n", sep = "")
    if (nrow(res)) print(utils::head(res, 100), row.names = FALSE)
    if (nrow(res) > 100)
      cat("... ", nrow(res) - 100, " more row(s) not shown - add a LIMIT or ",
          "tighten the WHERE if you need them all\n", sep = "")

    # The result is on screen above; now hold it to whatever the file declared.
    bad <- check_asserts(res, parsed[[i]]$asserts)
    if (length(bad)) {
      cat("\n*** ASSERTION FAILED - ", f, ", statement ", i, "\n", sep = "")
      for (m in bad) cat("    ", m, "\n", sep = "")
      cat("\nStopping. The statements below this one assume it held.\n")
      quit(status = 1L)
    }
    if (length(parsed[[i]]$asserts))
      cat("assertions held (", length(parsed[[i]]$asserts), ")\n", sep = "")
  }
}

if (!render_only) {
  cat("\n", if (n_failed) paste0("DONE - ", n_failed, " statement(s) FAILED\n")
            else "DONE - all statements ran\n", sep = "")
  if (n_failed) quit(status = 1L)
}
