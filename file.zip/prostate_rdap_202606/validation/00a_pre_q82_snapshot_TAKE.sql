-- =============================================================================
-- PRE-Q82 SNAPSHOT, PART A - TAKE IT.  RUN ONCE, BEFORE THE REBUILD.
-- =============================================================================
-- This file WRITES. Its companion 00b_pre_q82_snapshot_COMPARE.sql only reads.
-- They are separate files on purpose: an earlier single-file version could be
-- re-run after the rebuild, which replaced the snapshot with a copy of the NEW
-- table and made every difference read zero - a false "nothing moved" that
-- looks like a pass. Splitting them makes that mistake impossible rather than
-- merely discouraged. The runner also refuses START_AT on a file that writes,
-- so the offset cannot be used to step around either CREATE.
--
-- WHY IT EXISTS
-- The build writes with replace = TRUE onto the live table and keeps no
-- staging copy (register Q27), so the pre-ruling table is destroyed the moment
-- code/prostate_rdap_202606.R runs. Several release figures are before/after
-- comparisons and become permanently unmeasurable for this cut without this.
--
-- GUARD
-- CREATE TABLE, not CREATE OR REPLACE. If the snapshot already exists this
-- FAILS, which is the intended behaviour: a second run means either the
-- snapshot was already taken (nothing to do) or the rebuild has happened and
-- overwriting would destroy the only copy. Drop it by hand, deliberately, if
-- you genuinely need to retake it before a rebuild.
--
--   ${catalog} = hive_metastore
--   ${schema}  = your personal schema
--   ${ads}     = rwdp_pros_pano_2026m06
-- =============================================================================

USE CATALOG ${catalog};

-- ---------------------------------------------------------------------------
-- A1. The snapshot itself. Only the columns the comparisons need.
--
-- THE DATA IS WRITTEN BEFORE THE METADATA, and the order matters. These are two
-- statements and nothing can make them atomic here, so the question is which
-- way a partial failure should fall. Metadata first would leave provenance
-- describing a snapshot that does not exist - an empty claim that reads as a
-- successful capture. Data first leaves a snapshot with no metadata, which A2b
-- detects and which can still be documented by hand. Both orders lose
-- something; only one of them lies.
-- ---------------------------------------------------------------------------
CREATE TABLE ${schema}.pre_q82_ads AS
SELECT patid, cohortn, indexdt,
       dateofdeath, death_dt_preliminary, dthdt, dthfl,
       fu_enddt_preliminary, fued, fudur,
       dthfufl, dth_before_fued,
       os, ttnt, pfs, pfsdt, pfsfl, eligpfs,
       csf_fu, id3mosfu
FROM   ${schema}.${ads};

-- ---------------------------------------------------------------------------
-- A2. Provenance. Fill the three literals by hand BEFORE running - they are
-- the only proof of which build the snapshot came from, and nothing in the ADS
-- records it (Q43).
--
-- The counts are taken from the SNAPSHOT, not from the ADS. Counting the ADS
-- again here would describe whatever the source table holds at this moment,
-- which is not necessarily what A1 captured a second earlier - and the whole
-- point of the row is to describe the snapshot.
-- ---------------------------------------------------------------------------
CREATE TABLE ${schema}.pre_q82_ads_meta AS
SELECT current_timestamp()                      AS captured_at,
       current_user()                           AS captured_by,
       '${ads}'                                 AS source_table,
       'PRE-Q82'                                AS state,
       'FILL IN: git commit of the build that produced ${ads}' AS build_commit,
       'FILL IN: refresh, e.g. 2026m06'         AS refresh,
       'FILL IN: HRR panel, e.g. flatiron_all'  AS hrr_panel,
       (SELECT COUNT(*)              FROM ${schema}.pre_q82_ads) AS rows_captured,
       (SELECT COUNT(DISTINCT patid) FROM ${schema}.pre_q82_ads) AS patients_captured;

-- ---------------------------------------------------------------------------
-- A2b. Is this snapshot usable at all?  Every column MUST read zero.
--
-- The earlier version of this check compared the metadata's row count to the
-- snapshot's and stopped there, which an EMPTY snapshot satisfies: zero rows
-- captured, zero recorded, no duplicate keys, provenance filled in. Every
-- pre-rebuild check passed and B0 would only have caught it afterwards, with
-- the real pre-Q82 state already destroyed. So emptiness and shape are asserted
-- here, before the rebuild, where a failure is still recoverable.
--
--   AGREEMENT
--     meta_empty            the metadata table exists but holds no row. If A2
--                           failed outright the table does not exist and THIS
--                           STATEMENT ERRORS, which stops the run - louder and
--                           more accurate, so it is not worked around.
--     rowcount_mismatch     the metadata does not describe this snapshot.
--
--   NOT EMPTY, RIGHT SHAPE
--     no_rows / no_patients a snapshot of nothing passes every other check.
--     cohorts_missing       7 minus the distinct cohorts present. The ADS has
--                           seven by contract; a snapshot with fewer is a
--                           partial capture, not a pre-ruling copy.
--     baseline_mismatch     cohorts whose snapshot count differs from the
--                           2026-08-09 accepted figures. The snapshot IS the
--                           table those counts describe, so any difference
--                           means this is not that table - a different refresh,
--                           a different panel, or a build nobody recorded. B1-B5
--                           would then be comparing two things that were never
--                           a before/after pair. Retake the pair or accept that
--                           the B-figures cannot be attributed to the ruling;
--                           do NOT loosen this to make a run pass.
--
--   PROVENANCE THAT MEANS SOMETHING
--     fill_in_left          a FILL IN literal survived.
--     commit_malformed      not 7-40 hex characters. A blank, a NULL or a note
--                           to self passed the FILL IN test and attributed
--                           nothing.
--     refresh_mismatch      the recorded refresh is not the one in the table
--                           name being captured.
--     panel_unknown         not one of the three names the build accepts.
--
-- @assert zero meta_empty
-- @assert zero rowcount_mismatch
-- @assert zero no_rows
-- @assert zero no_patients
-- @assert zero cohorts_missing
-- @assert zero baseline_mismatch
-- @assert zero fill_in_left
-- @assert zero commit_malformed
-- @assert zero refresh_mismatch
-- @assert zero panel_unknown
-- ---------------------------------------------------------------------------
WITH snap AS (SELECT COUNT(*) AS n, COUNT(DISTINCT patid) AS p,
                     COUNT(DISTINCT cohortn) AS c
              FROM ${schema}.pre_q82_ads),
meta AS (SELECT COUNT(*) AS n, MAX(rows_captured) AS rows_captured,
                MAX(build_commit) AS build_commit, MAX(refresh) AS refresh,
                MAX(hrr_panel) AS hrr_panel
         FROM ${schema}.pre_q82_ads_meta),
-- the 2026-08-09 accepted counts; the snapshot should reproduce them exactly
baseline AS (SELECT * FROM VALUES
               (1,197903),(2,134281),(3,79051),(4,50502),
               (5,28980),(6,16073),(7,8616) AS t(cohortn, expected))
SELECT (SELECT CASE WHEN n = 0 THEN 1 ELSE 0 END FROM meta)          AS meta_empty,
       (SELECT CASE WHEN m.rows_captured IS DISTINCT FROM s.n
                    THEN 1 ELSE 0 END FROM meta m CROSS JOIN snap s) AS rowcount_mismatch,
       (SELECT CASE WHEN n = 0 THEN 1 ELSE 0 END FROM snap)          AS no_rows,
       (SELECT CASE WHEN p = 0 THEN 1 ELSE 0 END FROM snap)          AS no_patients,
       (SELECT 7 - c FROM snap)                                      AS cohorts_missing,
       (SELECT COUNT(*) FROM baseline b
        LEFT JOIN (SELECT cohortn, COUNT(DISTINCT patid) actual
                   FROM ${schema}.pre_q82_ads GROUP BY cohortn) a
          ON a.cohortn = b.cohortn
        WHERE COALESCE(a.actual, 0) <> b.expected)                   AS baseline_mismatch,
       (SELECT COUNT(*) FROM ${schema}.pre_q82_ads_meta
        WHERE build_commit LIKE 'FILL IN%'
           OR refresh      LIKE 'FILL IN%'
           OR hrr_panel    LIKE 'FILL IN%')                          AS fill_in_left,
       (SELECT CASE WHEN build_commit RLIKE '^[0-9a-f]{7,40}$'
                    THEN 0 ELSE 1 END FROM meta)                     AS commit_malformed,
       (SELECT CASE WHEN '${ads}' LIKE CONCAT('%', refresh, '%')
                    THEN 0 ELSE 1 END FROM meta)                     AS refresh_mismatch,
       (SELECT CASE WHEN hrr_panel IN ('flatiron_all','olaparib_label','talapro2')
                    THEN 0 ELSE 1 END FROM meta)                     AS panel_unknown;

-- ---------------------------------------------------------------------------
-- IF A2b STOPPED THE RUN
-- The snapshot from A1 is fine and must NOT be dropped - if A2b reported
-- no_rows, no_patients, cohorts_missing and baseline_mismatch all zero, the
-- captured table is the pre-ruling ADS and it is the one thing that cannot be
-- recreated. Only the metadata row needs rebuilding, and there is a file for
-- it, because there is no correct way to do it by hand:
--
--     Rscript validation/run_sql.R validation/00a_recover_metadata.sql
--
-- It drops the metadata table, rebuilds it from the literals you fill in, and
-- runs A2b and A3 - which never ran. Do NOT paste A2/A2b into a SQL editor
-- instead: the assertions become comments there, which is how an unattributed
-- snapshot passes. Do not reach for START_AT either - the runner refuses an
-- offset on a file that writes, because replaying a CREATE collides with what
-- the first attempt left.
--
-- If A1 ITSELF failed, that is the other case: drop BOTH tables and run this
-- file from the top.
-- ---------------------------------------------------------------------------

-- A3. Grain assertion. Every comparison in part B joins on (patid, cohortn),
-- so a duplicate key would inflate its counts silently. V01 asserts this on a
-- delivered table, but the snapshot is a copy and nothing has re-checked it.
-- MUST return zero rows.
-- @assert no-rows
-- ---------------------------------------------------------------------------
SELECT patid, cohortn, COUNT(*) AS n
FROM   ${schema}.pre_q82_ads
GROUP  BY patid, cohortn
HAVING COUNT(*) > 1;

-- ---------------------------------------------------------------------------
-- A4. Read this back and put it in the release evidence before rebuilding.
-- If build_commit still says FILL IN, the snapshot cannot be attributed to a
-- build and is worth much less. Fix it now, not later.
-- ---------------------------------------------------------------------------
SELECT * FROM ${schema}.pre_q82_ads_meta;
