# =============================================================================
# Fills the Commit column of the register index table in docs/VARIABLES.md
# =============================================================================
#   Rscript validation/make_traceability.R
#
# Every decision id is named in at least one commit message, so the mapping is
# derived from history rather than typed. The cell records the first commit to
# name the row, the last one to name it while changing code, and the tally.
#
# THE CELL NO LONGER CLAIMS A "SETTLING COMMIT". It cannot know one. A commit
# message naming Q82 may be the ruling that settled it, a QC mirror catching up,
# or a comment tidy-up that mentions it in passing - and all three touch the same
# directories, so no file-path rule separates them. Naming the newest commit as
# the one that settled a row would therefore let any later cleanup displace the
# real provenance. The cell reports only what history supports: the first commit
# to name the row, the last one to name it while changing code, and the tally.
# The settling commit, where it matters, is recorded by hand in the detail
# section, where a human can be right about it.
#
# The cells already in the register were written by an earlier version of this
# script and still carry the old wording. They are rewritten on the next
# successful run; nothing re-labels them in place.
#
# One-commit lag: this run cannot see the commit that will contain its own
# output, so a row settled in commit N is only recorded correctly after a
# re-run at commit N+1. Re-run whenever rows are resolved.
#
# QC evidence is not derived here. It is written by hand in the detail section
# when evidence exists, and reads PENDING until then - a blank field would read
# as "not applicable", which for a build that has never run is the wrong claim.
# =============================================================================

source("validation/read_deviations.R")

log <- system2("git", c("log", "--format=%H%x1f%B%x1e", "--reverse"), stdout = TRUE)
log <- paste(log, collapse = "\n")

# Does this commit touch anything that can settle a decision? A merge commit has
# no diff of its own against its first parent for this purpose, and returns
# FALSE, which is correct - the work landed in the commits it merges.
touches_code <- function(sha) {
  files <- suppressWarnings(system2("git",
    c("show", "--pretty=", "--name-only", sha), stdout = TRUE, stderr = FALSE))
  any(grepl("^(code|qc|validation)/", files))
}

chain <- list()   # every commit naming the row, for the tally
anchor <- list()  # only those that also changed code, for the settling position
for (rec in strsplit(log, "\x1e", fixed = TRUE)[[1]]) {
  if (!grepl("\x1f", rec, fixed = TRUE)) next
  parts <- strsplit(rec, "\x1f", fixed = TRUE)[[1]]
  sha   <- substr(trimws(parts[1]), 1L, 7L)
  body  <- if (length(parts) > 1L) parts[2] else ""
  ids   <- unique(regmatches(body, gregexpr("\\bQ[0-9]{2}\\b", body))[[1]])
  if (!length(ids)) next
  code_commit <- touches_code(sha)
  for (id in sort(ids)) {
    chain[[id]] <- c(chain[[id]], sha)
    if (code_commit) anchor[[id]] <- c(anchor[[id]], sha)
  }
}

ln  <- readLines(DEVIATIONS_MD, warn = FALSE)
reg <- read_deviations()

missing <- setdiff(reg$id, names(chain))
if (length(missing)) {
  stop("no commit message names these decisions: ", paste(missing, collapse = ", "),
       "\nName the row in a commit message, or record the commit by hand.",
       call. = FALSE)
}

changed <- 0L
for (i in seq_len(nrow(reg))) {
  cc  <- chain[[reg$id[i]]]
  ac  <- anchor[[reg$id[i]]]
  # The settling position is the newest CODE commit. With none - a row named only
  # in documentation commits - say so rather than promote a docs commit into the
  # slot, which would read as a code change that never happened.
  val <- if (length(cc) == 1L) cc[1] else
    if (!length(ac))
      sprintf("first %s; %d commits name this row, none changed code",
              cc[1], length(cc))
    else
      sprintf("first %s; last code change %s; %d commits name this row",
              cc[1], ac[length(ac)], length(cc))
  if (!identical(reg$commit[i], val)) changed <- changed + 1L
  ln[reg$line[i]] <- sprintf("| %s | %s | %s | %s | %s | %s |",
                             reg$id[i], reg$variable[i], reg$affects[i],
                             reg$approved_by[i], reg$status[i], val)
}

writeLines(ln, DEVIATIONS_MD)
cat("traceability: ", nrow(reg), " decisions, ", changed, " updated\n", sep = "")
cat("NOTE: the commit containing THIS run is not visible to it. Re-run after\n")
cat("committing if a row was resolved in the same commit as its backfill.\n")
