-- =============================================================================
-- 202606 Prostate PANO RWDP - OUTPUT VALIDATION
-- Run immediately after the build, against the delivered table.
-- =============================================================================
-- HOW TO SUPPLY THE NAMES BELOW
--   `${catalog}` / `${schema}` / `${ads}` are text-substitution placeholders,
--   not SQL parameter markers (`:param` binds values, not object names). Either:
--     * SQL editor / notebook where `${...}` still resolves (legacy from
--       DBR 15.2) - set the widgets and run as-is; or
--     * anywhere else - find-and-replace the tokens with the literals below.
--
--   ${catalog}    = hive_metastore
--   ${src} = clnprw_flatiron_pano_pros_use   <- source tables
--   ${schema}     = your personal schema            <- built tables
--   ${ads}        = rwdp_pros_pano_2026m06
--
-- The two schemas are not interchangeable: V4's X11 reads a source table
-- while everything else reads the built ADS.
--
-- RP1-RP4 and W1-W3 are the 2026-09-11 ruling's four rules and the three
-- behaviours they withdraw, defined in docs/VARIABLES.md section 3.
--
-- The catalog is selected below, not left to the operator. This script runs
-- in its own SQL session, so the catalog the build set on its R connection
-- does not carry over; a session pointing elsewhere would validate a
-- same-named table in the wrong catalog and report PASS on something that
-- is not the build's output.
--
-- V1 returns one row per check and every row must read PASS. It reports; it
-- does not block.
--
-- There is no staging copy. The build writes the deliverable directly, so this
-- table is already live when you run these checks. That is a deliberate
-- simplification - one table, one path, no publish step - and the cost is that
-- nothing stands between an unvalidated build and its consumers. Run these
-- checks immediately. A FAIL means fix the build and re-run it, or drop the
-- table; it does not mean "do not publish", because publication already
-- happened.
--
-- WHAT TO RUN, AND IN WHAT ORDER
--   V1   mandatory row-level gates          every row must read PASS
--   V1b  column contract                    -> Rscript 04_column_contract_check.R
--   V2   all-null / constant sweep          -> run validation/03b_null_sweep.sql
--   V2b  HRR panel distribution             read against RUN_MANIFEST.txt
--   V2c  HRR vs BRCA agreement              must read PASS
--   V2d  HRR:BRCA positive ratio            record it; D5b anchor is 2.80
--   V2e  HRR_LABEL vs HRR agreement         must read PASS  (register Q28)
--   V3   TINTCRPCHSPC sign                  pos_tint must dominate
--   V4   chronology quantification          numbers for the release record
--   V5   pointer to V1b
--
-- A non-default HRR panel writes to rwdp_pros_pano_2026m06_hrr_<panel>, stages
-- included, so it can never land on the governed name. Set ${ads} to the name
-- the build reported.
-- =============================================================================


-- =============================================================================
-- V1. MANDATORY GATES
-- =============================================================================
USE CATALOG ${catalog};

WITH
-- grain -----------------------------------------------------------------
c01 AS (SELECT COUNT(*) n FROM (
          SELECT patid, cohortn FROM ${schema}.${ads}
          GROUP BY patid, cohortn HAVING COUNT(*) > 1)),
-- exactly seven cohorts, correctly paired -------------------------------
c02 AS (SELECT ABS(COUNT(DISTINCT cohortn) - 7) n FROM ${schema}.${ads}),
c03 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (cohortn=1 AND cohort='Overall mHSPC')     OR
          (cohortn=2 AND cohort='Overall mCRPC')     OR
          (cohortn=3 AND cohort='L1+ treated mHSPC') OR
          (cohortn=4 AND cohort='L1+ treated mCRPC') OR
          (cohortn=5 AND cohort='L2+ treated mCRPC') OR
          (cohortn=6 AND cohort='L3+ treated mCRPC') OR
          (cohortn=7 AND cohort='L4+ treated mCRPC')) IS NOT TRUE),
c04 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (cohortun=1 AND cohortu='Untreated mCRPC') OR
          (cohortun=2 AND cohortu='Treated mCRPC')   OR
          (cohortun=3 AND cohortu='Untreated mHSPC') OR
          (cohortun=4 AND cohortu='Treated mHSPC')) IS NOT TRUE),
-- index anchor. `<>` returns UNKNOWN when either side is NULL, so a missing
-- anchor would slip through; IS DISTINCT FROM catches it.
c05 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE
          (cohortn=1 AND indexdt IS DISTINCT FROM mhspcdd)      OR
          (cohortn=2 AND indexdt IS DISTINCT FROM mcrpcdd)      OR
          (cohortn=3 AND indexdt IS DISTINCT FROM lot1sd_mhspc) OR
          (cohortn=4 AND indexdt IS DISTINCT FROM lot1sd_mcrpc) OR
          (cohortn=5 AND indexdt IS DISTINCT FROM lot2sd_mcrpc) OR
          (cohortn=6 AND indexdt IS DISTINCT FROM lot3sd_mcrpc) OR
          (cohortn=7 AND indexdt IS DISTINCT FROM lot4sd_mcrpc)),
c06 AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE indexdt IS NULL
           OR indexdt < DATE'2011-01-01' OR indexdt > DATE'2026-04-30'),
-- time-to-event sanity ---------------------------------------------------
-- Under the 2026-09-11 follow-up ruling (register Q82) the per-cohort death
-- exclusion guarantees DTHDT >= INDEXDT, so the Q38 negative-rwPFS population
-- is gone at the source: c07b and c08b are strict proofs the exclusion held,
-- not sizings. FUED >= INDEXDT holds for every patient WITH a death date,
-- because FUED IS that date; it does not hold for a patient with none, whose
-- FUED is a last activity date nothing ties to the index. c46 sizes that
-- residue as REVIEW (register Q83), c46b fails if a death-dated patient ever
-- appears in it, and c07 fails on any negative c46 does not account for.
-- The exemption is per metric AND per branch. Two traps:
-- (1) The branch cannot be inferred from TTNT's VALUE - a death-driven event
--     has DTHDT = FUED under Q82, so the event and censored formulas give the
--     identical number on every such row. TTNTFL is not delivered (Q02), so
--     the branch is rebuilt from the cohort's next-treatment date and DTHFL,
--     exactly as 05_outcomes.R derives it.
-- (2) `fued < indexdt` is not "the duration is negative": a FUED one day
--     before the index gives DATEDIFF + 1 = 0. The exemption tests the
--     EXPECTED duration instead.
c07 AS (SELECT COUNT(*) n FROM (
          SELECT os, ttnt, fudur, dthfl,
                 (DATEDIFF(fued, indexdt) + 1) < 0                  AS short_fu,
                 cohortn IN (3,4,5,6)
                   AND COALESCE(id3mosfu = 1, FALSE)
                   AND COALESCE(dthfl = 0, FALSE)
                   AND CASE cohortn
                         WHEN 3 THEN LEAST(lot2sd_mhspc, lot1sd_mcrpc)
                         WHEN 4 THEN lot2sd_mcrpc
                         WHEN 5 THEN lot3sd_mcrpc
                         WHEN 6 THEN lot4sd_mcrpc END IS NULL       AS ttnt_cens
          FROM ${schema}.${ads})
        WHERE (fudur < 0 AND NOT COALESCE(short_fu, FALSE))
           OR (os    < 0 AND (COALESCE(dthfl = 1, FALSE)
                              OR NOT COALESCE(short_fu, FALSE)))
           OR (ttnt  < 0 AND (NOT COALESCE(ttnt_cens, FALSE)
                              OR NOT COALESCE(short_fu, FALSE)))),
c07b AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE pfs < 0),
c08 AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE (dthdt IS NOT NULL AND dthdt < indexdt)
           OR (pfsdt IS NOT NULL AND pfsdt < indexdt)),
c08b AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE dthdt IS NOT NULL AND indexdt > dthdt),
-- RP2 and W3 hold, and the exposure the ruling opened is measured rather than
-- gated. W1 and W2 are invisible here - both moved DEATH_DT_preliminary before
-- DTHDT was set, so c44 stays zero if either returns. qc/05 C21 is the only
-- guard on those.
c44 AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE dthdt IS DISTINCT FROM death_dt_preliminary),
c45 AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE NOT COALESCE(dth_before_fued = 0, FALSE)),
c46 AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE fued < indexdt),
c46b AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE fued < indexdt AND dthdt IS NOT NULL),
-- Q83's OTHER population: a NULL FUED makes c46's predicate UNKNOWN, so c46
-- cannot see it and the null sweep only judges all-null or constant columns.
c46c AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE fued IS NULL),
c47 AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE NOT COALESCE(
                fued = COALESCE(dthdt, fu_enddt_preliminary)
             OR (fued IS NULL AND dthdt IS NULL
                 AND fu_enddt_preliminary IS NULL), FALSE)),
-- code/label mappings ---------------------------------------------------
-- Every one of these is written `WHERE (<the whole mapping>) IS NOT TRUE`, not
-- `WHERE NOT (<mapping>)`. In three-valued logic a NULL label or a NULL code
-- makes each disjunct UNKNOWN, the OR of UNKNOWNs is UNKNOWN, and NOT UNKNOWN
-- is UNKNOWN - so `WHERE NOT (...)` silently excludes the unmapped rows and the
-- gate passes on exactly the pairs it exists to catch. `IS NOT TRUE` counts
-- both FALSE and UNKNOWN, so a NULL on either side is a FAIL.
c09 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (agegr1='0-18'  AND agegr1n=1) OR (agegr1='19-34' AND agegr1n=2) OR
          (agegr1='35-49' AND agegr1n=3) OR (agegr1='50-64' AND agegr1n=4) OR
          (agegr1='65-74' AND agegr1n=5) OR (agegr1='75-84' AND agegr1n=6) OR
          (agegr1='>=85'  AND agegr1n=7) OR (agegr1='Unknown' AND agegr1n=99)) IS NOT TRUE),
c10 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (eth='Not Hispanic or Latino' AND ethn=1) OR
          (eth='Hispanic or Latino'     AND ethn=2) OR
          (eth='Unknown/Missing'        AND ethn=3)) IS NOT TRUE),
c11 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (race='Asian' AND racen=1) OR
          (race='Black or African American' AND racen=2) OR
          (race='White' AND racen=3) OR (race='Other Race' AND racen=4) OR
          (race='Unknown/Missing' AND racen=5)) IS NOT TRUE),
c12 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (region1='Northeast' AND region1n=1) OR (region1='Midwest' AND region1n=2) OR
          (region1='South' AND region1n=3) OR (region1='West' AND region1n=4) OR
          (region1='Other region' AND region1n=5) OR (region1='Missing' AND region1n=6) OR
          (region1='Unknown' AND region1n=99)) IS NOT TRUE),
c13 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (practic='Academic only' AND practicn=1) OR
          (practic='Community only' AND practicn=2) OR
          (practic='Both academic and community' AND practicn=3) OR
          (practic='Missing' AND practicn=99)) IS NOT TRUE),
c14 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (stage='0' AND stagen=1) OR (stage='I' AND stagen=2) OR
          (stage='II' AND stagen=3) OR (stage='III' AND stagen=4) OR
          (stage='IV' AND stagen=5) OR
          (stage='Unknown/not documented' AND stagen=99)) IS NOT TRUE),
c15 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (ecog='0' AND ecogn=1) OR (ecog='1' AND ecogn=2) OR (ecog='2' AND ecogn=3) OR
          (ecog='3' AND ecogn=4) OR (ecog='4' AND ecogn=5) OR
          (ecog='Unknown/Missing' AND ecogn=6)) IS NOT TRUE),
c16 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (gleason='<8' AND gleasonn=1) OR (gleason='>=8' AND gleasonn=2) OR
          (gleason='Unknown/Missing' AND gleasonn=3)) IS NOT TRUE),
c17 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (bmigr1='Underweight' AND bmigr1n=1) OR (bmigr1='Normal weight' AND bmigr1n=2) OR
          (bmigr1='Overweight' AND bmigr1n=3) OR (bmigr1='Obese' AND bmigr1n=4) OR
          (bmigr1='Missing' AND bmigr1n=5)) IS NOT TRUE),
c18 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (hrr_index='Positive' AND hrr_indexn=1) OR (hrr_index='Negative' AND hrr_indexn=2) OR
          (hrr_index='VUS' AND hrr_indexn=3) OR
          (hrr_index='Unknown/Not documented' AND hrr_indexn=4)) IS NOT TRUE),
c19 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (brca_index='Positive' AND brca_indexn=1) OR (brca_index='Negative' AND brca_indexn=2) OR
          (brca_index='VUS' AND brca_indexn=3) OR
          (brca_index='Unknown/Not documented' AND brca_indexn=4)) IS NOT TRUE),
c20 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (lotngr1='0' AND lotngr1n=1) OR (lotngr1='1' AND lotngr1n=2) OR
          (lotngr1='2' AND lotngr1n=3) OR (lotngr1='3' AND lotngr1n=4) OR
          (lotngr1='4' AND lotngr1n=5) OR (lotngr1='5+' AND lotngr1n=6)) IS NOT TRUE),
-- The column-level gates (V21 struck-out columns absent, V27 column count)
-- live in section V1b, not here. They need
-- `${schema}.information_schema.columns`, which does not exist on the legacy
-- metastore this cut lives in - information_schema is Unity-Catalog-only and
-- is a catalog-level schema, never a schema-level one. As CTEs inside V1 they
-- would abort the whole statement before a single PASS/FAIL row is returned,
-- leaving every gate unread.
--
-- cohort applicability. Asserted in both directions: the overall cohorts must
-- be missing, and the treated cohorts must be populated - otherwise a build
-- that produced nothing at all would pass.
c22 AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE cohortn IN (1,2) AND (ttnt IS NOT NULL OR vis120 IS NOT NULL
                                    OR eligpfs IS NOT NULL OR pfsfl IS NOT NULL
                                    OR pfsdt IS NOT NULL OR pfs IS NOT NULL)),
c23 AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE cohortn = 7 AND ttnt IS NOT NULL),   -- no LOT5 is carried
-- Per cohort, not pooled. `COUNT(ttnt) > 0 FROM ads WHERE cohortn IN (3,4,5,6)`
-- passes as long as one of the four has any TTNT, leaving an entirely empty or
-- entirely-null cohort invisible. The LEFT JOIN from a literal cohort
-- list also catches a cohort that produced no rows at all, which a
-- `FROM ads GROUP BY cohortn` form cannot.  n = number of cohorts with none.
c24 AS (SELECT COUNT(*) n FROM (
          SELECT k.cohortn
          FROM  (SELECT explode(ARRAY(3,4,5,6)) cohortn) k
          LEFT JOIN ${schema}.${ads} a
                 ON a.cohortn = k.cohortn AND a.ttnt IS NOT NULL
          GROUP BY k.cohortn HAVING COUNT(a.ttnt) = 0)),
c25 AS (SELECT COUNT(*) n FROM (
          SELECT k.cohortn
          FROM  (SELECT explode(ARRAY(3,4,5,6,7)) cohortn) k
          LEFT JOIN ${schema}.${ads} a
                 ON a.cohortn = k.cohortn AND a.pfs IS NOT NULL
          GROUP BY k.cohortn HAVING COUNT(a.pfs) = 0)),
-- The blood-pressure pair, the two biomarker test-type pairs, and all six LOT
-- category pairs. The LOT pairs are 17 categories x 6 columns and are the
-- columns most likely to drift, since the category list is the longest in the
-- spec.
c28 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (bp='Present' AND bpn=1) OR (bp='Unknown' AND bpn=2) OR
          (bp='Missing' AND bpn=3)) IS NOT TRUE),
-- Constant by construction today (register Q03); pinned so that if a test-type
-- column ever appears and this is wired up, the pairing must still hold.
c29 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (hrr_index_test='Unknown' AND hrr_index_testn=7)) IS NOT TRUE),
c30 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (brca_index_test='Unknown' AND brca_index_testn=7)) IS NOT TRUE),
-- V31-V36 must not exclude rows where both the label and its code are null:
-- LOTnCAT is computed after the left join to the index table, and its
-- case_when maps a null LINENAME to 'No treatment'/17, so neither column can
-- legitimately be null. A both-null pair is a real defect - a dropped join or
-- a lost column. A null label makes the mapping expression NULL, which
-- IS NOT TRUE already counts.
c31 AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE (((lot1cat_mhspc='Abiraterone monotherapy' AND lot1catn_mhspc=1) OR
          (lot1cat_mhspc='Enzalutamide monotherapy' AND lot1catn_mhspc=2) OR
          (lot1cat_mhspc='Apalutamide monotherapy' AND lot1catn_mhspc=3) OR
          (lot1cat_mhspc='Darolutamide monotherapy' AND lot1catn_mhspc=4) OR
          (lot1cat_mhspc='NHA combination therapy' AND lot1catn_mhspc=5) OR
          (lot1cat_mhspc='Docetaxel monotherapy' AND lot1catn_mhspc=6) OR
          (lot1cat_mhspc='Docetaxel combination therapy' AND lot1catn_mhspc=7) OR
          (lot1cat_mhspc='Cabazitaxel-containing' AND lot1catn_mhspc=8) OR
          (lot1cat_mhspc='Other chemotherapy-containing' AND lot1catn_mhspc=9) OR
          (lot1cat_mhspc='Pluvicto-containing' AND lot1catn_mhspc=10) OR
          (lot1cat_mhspc='Radium 223-containing' AND lot1catn_mhspc=11) OR
          (lot1cat_mhspc='PARPi monotherapy' AND lot1catn_mhspc=12) OR
          (lot1cat_mhspc='Pembrolizumab-containing' AND lot1catn_mhspc=13) OR
          (lot1cat_mhspc='Sipuleucel-T-containing' AND lot1catn_mhspc=14) OR
          (lot1cat_mhspc='Clinical study drug-containing' AND lot1catn_mhspc=15) OR
          (lot1cat_mhspc='Any other therapy' AND lot1catn_mhspc=16) OR
          (lot1cat_mhspc='No treatment' AND lot1catn_mhspc=17)) IS NOT TRUE)),
c32 AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE (((lot2cat_mhspc='Abiraterone monotherapy' AND lot2catn_mhspc=1) OR
          (lot2cat_mhspc='Enzalutamide monotherapy' AND lot2catn_mhspc=2) OR
          (lot2cat_mhspc='Apalutamide monotherapy' AND lot2catn_mhspc=3) OR
          (lot2cat_mhspc='Darolutamide monotherapy' AND lot2catn_mhspc=4) OR
          (lot2cat_mhspc='NHA combination therapy' AND lot2catn_mhspc=5) OR
          (lot2cat_mhspc='Docetaxel monotherapy' AND lot2catn_mhspc=6) OR
          (lot2cat_mhspc='Docetaxel combination therapy' AND lot2catn_mhspc=7) OR
          (lot2cat_mhspc='Cabazitaxel-containing' AND lot2catn_mhspc=8) OR
          (lot2cat_mhspc='Other chemotherapy-containing' AND lot2catn_mhspc=9) OR
          (lot2cat_mhspc='Pluvicto-containing' AND lot2catn_mhspc=10) OR
          (lot2cat_mhspc='Radium 223-containing' AND lot2catn_mhspc=11) OR
          (lot2cat_mhspc='PARPi monotherapy' AND lot2catn_mhspc=12) OR
          (lot2cat_mhspc='Pembrolizumab-containing' AND lot2catn_mhspc=13) OR
          (lot2cat_mhspc='Sipuleucel-T-containing' AND lot2catn_mhspc=14) OR
          (lot2cat_mhspc='Clinical study drug-containing' AND lot2catn_mhspc=15) OR
          (lot2cat_mhspc='Any other therapy' AND lot2catn_mhspc=16) OR
          (lot2cat_mhspc='No treatment' AND lot2catn_mhspc=17)) IS NOT TRUE)),
c33 AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE (((lot1cat_mcrpc='Abiraterone monotherapy' AND lot1catn_mcrpc=1) OR
          (lot1cat_mcrpc='Enzalutamide monotherapy' AND lot1catn_mcrpc=2) OR
          (lot1cat_mcrpc='Apalutamide monotherapy' AND lot1catn_mcrpc=3) OR
          (lot1cat_mcrpc='Darolutamide monotherapy' AND lot1catn_mcrpc=4) OR
          (lot1cat_mcrpc='NHA combination therapy' AND lot1catn_mcrpc=5) OR
          (lot1cat_mcrpc='Docetaxel monotherapy' AND lot1catn_mcrpc=6) OR
          (lot1cat_mcrpc='Docetaxel combination therapy' AND lot1catn_mcrpc=7) OR
          (lot1cat_mcrpc='Cabazitaxel-containing' AND lot1catn_mcrpc=8) OR
          (lot1cat_mcrpc='Other chemotherapy-containing' AND lot1catn_mcrpc=9) OR
          (lot1cat_mcrpc='Pluvicto-containing' AND lot1catn_mcrpc=10) OR
          (lot1cat_mcrpc='Radium 223-containing' AND lot1catn_mcrpc=11) OR
          (lot1cat_mcrpc='PARPi monotherapy' AND lot1catn_mcrpc=12) OR
          (lot1cat_mcrpc='Pembrolizumab-containing' AND lot1catn_mcrpc=13) OR
          (lot1cat_mcrpc='Sipuleucel-T-containing' AND lot1catn_mcrpc=14) OR
          (lot1cat_mcrpc='Clinical study drug-containing' AND lot1catn_mcrpc=15) OR
          (lot1cat_mcrpc='Any other therapy' AND lot1catn_mcrpc=16) OR
          (lot1cat_mcrpc='No treatment' AND lot1catn_mcrpc=17)) IS NOT TRUE)),
c34 AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE (((lot2cat_mcrpc='Abiraterone monotherapy' AND lot2catn_mcrpc=1) OR
          (lot2cat_mcrpc='Enzalutamide monotherapy' AND lot2catn_mcrpc=2) OR
          (lot2cat_mcrpc='Apalutamide monotherapy' AND lot2catn_mcrpc=3) OR
          (lot2cat_mcrpc='Darolutamide monotherapy' AND lot2catn_mcrpc=4) OR
          (lot2cat_mcrpc='NHA combination therapy' AND lot2catn_mcrpc=5) OR
          (lot2cat_mcrpc='Docetaxel monotherapy' AND lot2catn_mcrpc=6) OR
          (lot2cat_mcrpc='Docetaxel combination therapy' AND lot2catn_mcrpc=7) OR
          (lot2cat_mcrpc='Cabazitaxel-containing' AND lot2catn_mcrpc=8) OR
          (lot2cat_mcrpc='Other chemotherapy-containing' AND lot2catn_mcrpc=9) OR
          (lot2cat_mcrpc='Pluvicto-containing' AND lot2catn_mcrpc=10) OR
          (lot2cat_mcrpc='Radium 223-containing' AND lot2catn_mcrpc=11) OR
          (lot2cat_mcrpc='PARPi monotherapy' AND lot2catn_mcrpc=12) OR
          (lot2cat_mcrpc='Pembrolizumab-containing' AND lot2catn_mcrpc=13) OR
          (lot2cat_mcrpc='Sipuleucel-T-containing' AND lot2catn_mcrpc=14) OR
          (lot2cat_mcrpc='Clinical study drug-containing' AND lot2catn_mcrpc=15) OR
          (lot2cat_mcrpc='Any other therapy' AND lot2catn_mcrpc=16) OR
          (lot2cat_mcrpc='No treatment' AND lot2catn_mcrpc=17)) IS NOT TRUE)),
c35 AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE (((lot3cat_mcrpc='Abiraterone monotherapy' AND lot3catn_mcrpc=1) OR
          (lot3cat_mcrpc='Enzalutamide monotherapy' AND lot3catn_mcrpc=2) OR
          (lot3cat_mcrpc='Apalutamide monotherapy' AND lot3catn_mcrpc=3) OR
          (lot3cat_mcrpc='Darolutamide monotherapy' AND lot3catn_mcrpc=4) OR
          (lot3cat_mcrpc='NHA combination therapy' AND lot3catn_mcrpc=5) OR
          (lot3cat_mcrpc='Docetaxel monotherapy' AND lot3catn_mcrpc=6) OR
          (lot3cat_mcrpc='Docetaxel combination therapy' AND lot3catn_mcrpc=7) OR
          (lot3cat_mcrpc='Cabazitaxel-containing' AND lot3catn_mcrpc=8) OR
          (lot3cat_mcrpc='Other chemotherapy-containing' AND lot3catn_mcrpc=9) OR
          (lot3cat_mcrpc='Pluvicto-containing' AND lot3catn_mcrpc=10) OR
          (lot3cat_mcrpc='Radium 223-containing' AND lot3catn_mcrpc=11) OR
          (lot3cat_mcrpc='PARPi monotherapy' AND lot3catn_mcrpc=12) OR
          (lot3cat_mcrpc='Pembrolizumab-containing' AND lot3catn_mcrpc=13) OR
          (lot3cat_mcrpc='Sipuleucel-T-containing' AND lot3catn_mcrpc=14) OR
          (lot3cat_mcrpc='Clinical study drug-containing' AND lot3catn_mcrpc=15) OR
          (lot3cat_mcrpc='Any other therapy' AND lot3catn_mcrpc=16) OR
          (lot3cat_mcrpc='No treatment' AND lot3catn_mcrpc=17)) IS NOT TRUE)),
c36 AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE (((lot4cat_mcrpc='Abiraterone monotherapy' AND lot4catn_mcrpc=1) OR
          (lot4cat_mcrpc='Enzalutamide monotherapy' AND lot4catn_mcrpc=2) OR
          (lot4cat_mcrpc='Apalutamide monotherapy' AND lot4catn_mcrpc=3) OR
          (lot4cat_mcrpc='Darolutamide monotherapy' AND lot4catn_mcrpc=4) OR
          (lot4cat_mcrpc='NHA combination therapy' AND lot4catn_mcrpc=5) OR
          (lot4cat_mcrpc='Docetaxel monotherapy' AND lot4catn_mcrpc=6) OR
          (lot4cat_mcrpc='Docetaxel combination therapy' AND lot4catn_mcrpc=7) OR
          (lot4cat_mcrpc='Cabazitaxel-containing' AND lot4catn_mcrpc=8) OR
          (lot4cat_mcrpc='Other chemotherapy-containing' AND lot4catn_mcrpc=9) OR
          (lot4cat_mcrpc='Pluvicto-containing' AND lot4catn_mcrpc=10) OR
          (lot4cat_mcrpc='Radium 223-containing' AND lot4catn_mcrpc=11) OR
          (lot4cat_mcrpc='PARPi monotherapy' AND lot4catn_mcrpc=12) OR
          (lot4cat_mcrpc='Pembrolizumab-containing' AND lot4catn_mcrpc=13) OR
          (lot4cat_mcrpc='Sipuleucel-T-containing' AND lot4catn_mcrpc=14) OR
          (lot4cat_mcrpc='Clinical study drug-containing' AND lot4catn_mcrpc=15) OR
          (lot4cat_mcrpc='Any other therapy' AND lot4catn_mcrpc=16) OR
          (lot4cat_mcrpc='No treatment' AND lot4catn_mcrpc=17)) IS NOT TRUE)),
-- Run stamps, by exact value. The null sweep checks a column's shape and would
-- read a wrong-but-constant stamp as WAIVED, so a table mislabelled with the
-- previous cut's DATAV would look clean there. These four are the only columns
-- whose correct value is knowable without the source data, so they are the only
-- ones that can be asserted this way.
c37 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          datav    = '20260630'                          AND
          rawrwd   = 'Flatiron Prostate Panoramic Dataset' AND
          minindex = DATE'2011-01-01'                    AND
          maxindex = DATE'2026-04-30') IS NOT TRUE),
c38 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (hrr_label_index='Positive' AND hrr_label_indexn=1) OR
          (hrr_label_index='Negative' AND hrr_label_indexn=2) OR
          (hrr_label_index='VUS' AND hrr_label_indexn=3) OR
          (hrr_label_index='Unknown/Not documented' AND hrr_label_indexn=4)) IS NOT TRUE),
c39 AS (SELECT COUNT(*) n FROM ${schema}.${ads} WHERE (
          (lotngr1_mhspc='0' AND lotngr1n_mhspc=1) OR
          (lotngr1_mhspc='1' AND lotngr1n_mhspc=2) OR
          (lotngr1_mhspc='2' AND lotngr1n_mhspc=3) OR
          (lotngr1_mhspc='3' AND lotngr1n_mhspc=4) OR
          (lotngr1_mhspc='4' AND lotngr1n_mhspc=5) OR
          (lotngr1_mhspc='5+' AND lotngr1n_mhspc=6)) IS NOT TRUE),
-- DTHFL. The spec reads `if DTHDT>. then 1, else 0`, which is complete SAS -
-- `.` is the numeric-missing literal and `> .` is the standard idiom for "is
-- not missing", so the build's `dthdt IS NOT NULL` is a direct reading of it,
-- not an interpretation of truncated text (errata E11, closed as register
-- Q53). DTHFL decides whether OS and PFS treat a patient as an event or a
-- censor.
c40 AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE dthfl IS DISTINCT FROM (CASE WHEN dthdt IS NOT NULL THEN 1 ELSE 0 END)),
-- DTHFUFL, register Q57 (ruled 2026-08-08). The flag reads
-- DEATH_DT_preliminary / FU_ENDDT_preliminary rather than the final dates,
-- because FUED is clamped toward the death date before the flag is computed,
-- which closes the discrepancy the flag exists to detect. Three gates:
--   c41  the only null rule - NULL exactly when there is no death date. The
--        spec's Values list is "0 = No; 1 = Yes" with "else 0" and defines no
--        third state, so an absent FU_ENDDT_preliminary must yield 0, never
--        NULL; this gate enforces that.
--   c42  the arithmetic, deliberately kept at the spec's `<= 120` polarity
--   c43  the domain, {0, 1} - the spec's Values list, asserted directly
-- All three columns are in the 190-column contract.
c41 AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE (dthfufl IS NULL) IS DISTINCT FROM (death_dt_preliminary IS NULL)),
c42 AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE dthfufl IS NOT NULL
          AND dthfufl IS DISTINCT FROM
              (CASE WHEN DATEDIFF(death_dt_preliminary, fu_enddt_preliminary) <= 120
                    THEN 1 ELSE 0 END)),
c43 AS (SELECT COUNT(*) n FROM ${schema}.${ads}
        WHERE dthfufl IS NOT NULL AND dthfufl NOT IN (0, 1)),
-- reference cohort counts against the PRE-Q82 baseline ----------------------
-- The 2026-08-09 accepted counts, taken before the 2026-09-11 ruling added the
-- per-cohort death exclusion. They are stale BY CONSTRUCTION now, so this row
-- reads REVIEW rather than FAIL: n is the number of cohorts whose count moved,
-- and that movement is the impact figure the study team asked for. Refresh the
-- literals once the new counts are accepted. Preflight D8 now applies the same
-- exclusion, so D8 and the ADS agree with each other; it is only this frozen
-- baseline they both differ from.
-- The baseline is the DRIVING side, and the join is a LEFT JOIN from it. A
-- cohort that came out empty has nothing to group, so an inner join from the
-- observed side would drop it and this gate would read "that cohort did not
-- move" - the loudest possible failure reported as a pass. The R form
-- right-joins the baseline and coalesces a missing cohort to 0; this matches it.
c26 AS (SELECT COUNT(*) n FROM (
          -- the counts accepted 2026-09-12 as the ones Q82 produces; the
          -- 2026-08-09 figures they replaced survive only in 00a's
          -- baseline_mismatch, which proves the snapshot is the OLD table
          SELECT e.cohortn FROM (SELECT * FROM VALUES
                  (1,196549),(2,133299),(3,78635),(4,50327),
                  (5,28865),(6,16007),(7,8582) AS t(cohortn, expected)) e
          LEFT JOIN (
            SELECT cohortn, COUNT(DISTINCT patid) actual
            FROM ${schema}.${ads} GROUP BY cohortn) a
            ON a.cohortn = e.cohortn
          WHERE COALESCE(a.actual, 0) <> e.expected))
-- @assert none status in FAIL
SELECT 'V01' id,'one row per patid+cohortn'                 what, n failed, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END status FROM c01
UNION ALL SELECT 'V02','exactly 7 cohorts',                       n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c02
UNION ALL SELECT 'V03','cohortn/cohort labels paired',            n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c03
UNION ALL SELECT 'V04','cohortun/cohortu paired',                 n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c04
UNION ALL SELECT 'V05','index anchor matches cohort (null-safe)', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c05
UNION ALL SELECT 'V06','index inside study window',               n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c06
UNION ALL SELECT 'V07','no negative time-to-event unexplained by short follow-up', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c07
UNION ALL SELECT 'V07b','no negative rwPFS  (Q82 removes the Q38 cause)', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c07b
UNION ALL SELECT 'V08','date ordering invariants',                n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c08
UNION ALL SELECT 'V08b','index date after death date  (the Q82 exclusion held)', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c08b
UNION ALL SELECT 'V44','dthdt equals death_dt_preliminary - no row-92 promotion (Q82)', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c44
UNION ALL SELECT 'V45','dth_before_fued is constant 0 - unreachable under Q82',        n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c45
UNION ALL SELECT 'V46','follow-up ends before index - negative FUDUR/OS/TTNT (Q83, unruled)', n, CASE WHEN n=0 THEN 'PASS' ELSE 'REVIEW' END FROM c46
UNION ALL SELECT 'V46b','no death-dated patient has follow-up before index (Q82)', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c46b
UNION ALL SELECT 'V46c','follow-up end is NULL - no death date and no activity (Q83, unruled)', n, CASE WHEN n=0 THEN 'PASS' ELSE 'REVIEW' END FROM c46c
UNION ALL SELECT 'V47','fued is dthdt when present, else fu_enddt_preliminary (Q82)', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c47
UNION ALL SELECT 'V09','agegr1 mapping',   n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c09
UNION ALL SELECT 'V10','eth mapping',      n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c10
UNION ALL SELECT 'V11','race mapping',     n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c11
UNION ALL SELECT 'V12','region1 mapping',  n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c12
UNION ALL SELECT 'V13','practic mapping',  n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c13
UNION ALL SELECT 'V14','stage mapping',    n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c14
UNION ALL SELECT 'V15','ecog mapping',     n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c15
UNION ALL SELECT 'V16','gleason mapping',  n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c16
UNION ALL SELECT 'V17','bmigr1 mapping',   n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c17
UNION ALL SELECT 'V18','hrr mapping',      n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c18
UNION ALL SELECT 'V19','brca mapping',     n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c19
UNION ALL SELECT 'V20','lotngr1 mapping',  n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c20
UNION ALL SELECT 'V22','overall cohorts missing ttnt/pfs/vis120', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c22
UNION ALL SELECT 'V23','cohort 7 has no ttnt',                    n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c23
UNION ALL SELECT 'V24','EVERY treated cohort has ttnt (per cohort)', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c24
UNION ALL SELECT 'V25','EVERY treated cohort has pfs (per cohort)',  n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c25
UNION ALL SELECT 'V26','cohort counts vs the pre-Q82 baseline (expect a drop)', n, CASE WHEN n=0 THEN 'PASS' ELSE 'REVIEW' END FROM c26
UNION ALL SELECT 'V37','run stamps carry their exact values',     n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c37
UNION ALL SELECT 'V38','hrr_label_index/hrr_label_indexn mapping', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c38
UNION ALL SELECT 'V39','lotngr1_mhspc/lotngr1n_mhspc mapping',     n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c39
UNION ALL SELECT 'V40','dthfl agrees with dthdt',                  n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c40
UNION ALL SELECT 'V41','dthfufl null iff there is no death date (Q57)', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c41
UNION ALL SELECT 'V42','dthfufl = 1 iff death_prelim - fu_end_prelim <= 120 (Q57)', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c42
UNION ALL SELECT 'V43','dthfufl domain is {0,1} - the spec Values list (Q57)', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c43
UNION ALL SELECT 'V28','bp mapping',                             n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c28
UNION ALL SELECT 'V29','hrr_index_test mapping',                 n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c29
UNION ALL SELECT 'V30','brca_index_test mapping',                n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c30
UNION ALL SELECT 'V31','lot1cat_mhspc/lot1catn_mhspc mapping', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c31
UNION ALL SELECT 'V32','lot2cat_mhspc/lot2catn_mhspc mapping', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c32
UNION ALL SELECT 'V33','lot1cat_mcrpc/lot1catn_mcrpc mapping', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c33
UNION ALL SELECT 'V34','lot2cat_mcrpc/lot2catn_mcrpc mapping', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c34
UNION ALL SELECT 'V35','lot3cat_mcrpc/lot3catn_mcrpc mapping', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c35
UNION ALL SELECT 'V36','lot4cat_mcrpc/lot4catn_mcrpc mapping', n, CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM c36
ORDER BY id;

-- ---------------------------------------------------------------------------
-- V26 detail. The gate row above carries one scalar - the number of cohorts
-- whose count moved - which is not what the owner needs to accept the new
-- sizes. This is: actual, the frozen pre-Q82 baseline, and the drop per
-- cohort. The R program writes the same thing to qcr_v26_cohorts_r.
-- NOT in qcr_v4_xcounts_r: that holds X01-X11 chronology counts only.
-- ---------------------------------------------------------------------------
-- LEFT JOIN from the baseline, so a cohort that produced no rows reports
-- actual = 0 and a 100% drop rather than vanishing from the result.
SELECT b.cohortn, COALESCE(a.actual, 0)                           AS actual, b.expected,
       b.expected - COALESCE(a.actual, 0)                         AS dropped,
       ROUND(100.0 * (b.expected - COALESCE(a.actual, 0)) / b.expected, 3) AS pct_dropped
FROM   (SELECT * FROM VALUES (1,196549),(2,133299),(3,78635),(4,50327),
                             (5,28865),(6,16007),(7,8582)
        AS t(cohortn, expected)) b
LEFT   JOIN (SELECT cohortn, COUNT(DISTINCT patid) actual
             FROM ${schema}.${ads} GROUP BY cohortn) a
  ON   a.cohortn = b.cohortn
ORDER  BY b.cohortn;
-- V21 and V27 are in section V1b - they need table metadata, which is not
-- queryable on the legacy metastore.


-- =============================================================================
-- V1b. COLUMN CONTRACT  (V21 / V27)
-- =============================================================================
-- These two gates are about the table's shape, not its rows, and the shape is
-- not readable from SQL on hive_metastore. Run one of the two forms below.
--
--   V21  no struck-out 202606 variable was emitted
--   V27  the delivered columns are exactly validation/00_column_contract.csv -
--        same names, same order. A count-only form passes for any 190 columns,
--        including 190 wrong ones in the wrong order, so names and order are
--        both compared.
--
-- PREFERRED - automated, portable, and the only form that checks order:
--     Rscript validation/04_column_contract_check.R <table_name>
--   It reads the delivered column list over the live connection, compares it
--   name-by-name and position-by-position with the contract, and exits nonzero
--   on any difference. Keep its output with the release record.
--
-- FALLBACK - eyeball, if R is not available at QC time. Diff col_name against
-- validation/00_column_contract.csv in order; confirm none of trtdis, ttd, ttntfl,
-- tsstfl, tsst, pinddur, pfudur, birthsex or advanceddiagnosisdate appears.
DESCRIBE TABLE ${schema}.${ads};

-- UC form, if this cut is ever migrated to Unity Catalog. The catalog
-- qualifier matters: information_schema is never schema-level.
-- WITH delivered AS (
--   SELECT LOWER(column_name) col, ordinal_position pos
--   FROM   ${catalog}.information_schema.columns
--   WHERE  table_schema='${schema}' AND table_name='${ads}')
-- SELECT 'V21' id, 'struck-out variables absent' what, COUNT(*) failed,
--        CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END status
-- FROM   delivered
-- WHERE  col IN ('trtdis','ttd','ttntfl','tsstfl','tsst','pinddur','pfudur',
--                'birthsex','advanceddiagnosisdate');


-- =============================================================================
-- V2. ALL-NULL AND CONSTANT-VALUE SWEEP
-- =============================================================================
-- An all-null or single-valued column is either a defect or needs a formal
-- waiver. It must not ship looking like a completed deliverable.
--
-- Run the generated, complete sweep - it covers all 190 columns and returns a
-- status per column:
--
--     validation/03b_null_sweep.sql
--
-- It is generated from validation/00_column_contract.csv by
-- validation/make_null_sweep.R, and validation/02_offline_build_check.R fails
-- if the two have drifted, so it cannot silently fall behind the contract.
-- It carries the waiver list below as data.
--
-- WAIVED (expected all-null or constant; every other such column is a defect):
--   hrr_index_test / hrr_index_testn / brca_index_test / brca_index_testn
--       - hard-coded 'Unknown' / 7; no source column exists (register Q03)
--   max_drug_ep_abstracted_dt
--       - EpisodeDataSource='Abstraction' absent from 2026m06 (register Q16)
--   datav / rawrwd / minindex / maxindex
--       - run-stamp constants, one value by construction
--   (labalb / labalbv / labalbdt are not waived: Q25's unit-filter decision is
--    implemented, so they must be populated - all-null is a defect. Q25 is
--    decided in part; the delivered scale is a separate, unresolved question
--    that this sweep does not touch.)


-- =============================================================================
-- V2b. HRR PANEL - ACCEPTANCE GATE  (register Q05)
-- =============================================================================
-- The build does not stop on an unclassified gene; it warns and carries on, so
-- the panel has to be confirmed here. The build writes RUN_MANIFEST.txt and
-- echoes it to the log; its `hrr_panel (Q05)` line records which panel produced
-- this ADS. The default, 'flatiron_all', is the nineteen named symbols frozen
-- under Q44, not "every gene in the table". Confirm the manifest line reads
-- `flatiron_all (19 genes)` before anyone reads the table.
--
-- WHAT THIS IS NOT. It prints a distribution for a human; it does not verify
-- the panel: HRR_INDEX is a collapsed status and looks equally plausible under
-- all three panels, so the table cannot tell you this. The manifest is the
-- only record, and it is a mutable file beside a mutable table - see Q43.
--
-- WHAT TO EXPECT. Preflight D5b's 16011 HRR-positive is all-time and
-- patient-level; the ADS applies the [-30,+7] window around each index date,
-- so its absolute positive count will be substantially lower. Do not read a
-- smaller number here as a defect - the comparable quantity is the HRR:BRCA
-- ratio, which V2d reports.
SELECT hrr_index, COUNT(*) n, ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (), 2) pct
FROM ${schema}.${ads} GROUP BY hrr_index ORDER BY n DESC;

-- V2c. HRR vs BRCA AGREEMENT - mandatory.
-- BRCA1 and BRCA2 sit inside every panel option, so a BRCA-positive patient
-- must be HRR-positive. The invariant holds by construction: the date and the
-- status of a BRCA gene are resolved identically inside both calls - both the
-- cross-gene status roll-up (register Q29) and the panel-level winning date
-- (register Q37), where the two panels could otherwise draw their winning
-- date from different candidate pools and land on different reports. On a
-- FAIL, look for a place where the two panels are allowed to diverge - do not
-- relax the gate.
SELECT 'V2c' id, 'brca positive implies hrr positive' what, COUNT(*) failed,
       CASE WHEN COUNT(*)=0 THEN 'PASS' ELSE 'FAIL' END status
FROM   ${schema}.${ads}
WHERE  brca_index = 'Positive' AND hrr_index IS DISTINCT FROM 'Positive';

-- V2e. The same invariant for the label-aligned sibling (register Q28). The
-- 14 olaparib-label genes are a subset of the default 19, so a patient positive
-- on the label panel must be positive on the full one. A non-zero count means
-- the two panels have drifted out of subset relation - which can only happen if
-- the gene lists were edited without checking, since both calls share one
-- winning test date.
--
-- THE INVARIANT DOES NOT HOLD FOR EVERY PANEL, and this file cannot read the
-- environment to find out which one ran. validation/03_output_validation.R
-- skips V2e when RDAP_HRR_PANEL is `talapro2`, because that panel's 12 genes
-- are NOT a superset of the label's 14 - so a label-positive patient can
-- legitimately read HRR-negative and the R would report a failure that is not
-- one. Left unconditional here, the SQL mirror fails on a talapro2 build where
-- the R passes: a parity gap that looks like a defect in the data.
--
-- The panel is read from the TABLE NAME, which is where it is already
-- recorded: a non-default panel writes to `..._hrr_<panel>` and can never land
-- on the governed name (Q05), so `${ads}` substitutes to a string that names
-- the panel. The delivered COLUMNS cannot answer this - BRCA1/BRCA2 belong to
-- all three panels, so no comparison against BRCA_INDEX distinguishes them.
SELECT 'V2e' id, 'hrr_label positive implies hrr positive' what, COUNT(*) n,
       CASE WHEN '${ads}' LIKE '%\\_hrr\\_talapro2' ESCAPE '\\'
              THEN 'NOT_APPLICABLE - talapro2 is narrower than the label panel, so the implication does not hold; validation/03_output_validation.R skips this check on the same build'
            WHEN COUNT(*) = 0 THEN 'PASS'
            ELSE 'FAIL' END verdict
FROM   ${schema}.${ads}
WHERE  hrr_label_index = 'Positive' AND hrr_index IS DISTINCT FROM 'Positive';

-- V2d. The same relationship as a magnitude, for the release record. Preflight
-- D5b puts the all-time patient-level ratio at 16011/5715 = 2.80. Near 1.0
-- would mean the panel had collapsed to BRCA1/2; far above 2.80 would mean HRR
-- is picking up markedly more than BRCA. Not a gate - the ADS is windowed and
-- D5b is not, so the two are not required to agree, only to be explicable.
SELECT SUM(CASE WHEN hrr_index  = 'Positive' THEN 1 ELSE 0 END) hrr_positive,
       SUM(CASE WHEN brca_index = 'Positive' THEN 1 ELSE 0 END) brca_positive,
       ROUND(SUM(CASE WHEN hrr_index  = 'Positive' THEN 1 ELSE 0 END) /
             NULLIF(SUM(CASE WHEN brca_index = 'Positive' THEN 1 ELSE 0 END), 0),
             2) AS hrr_per_brca_d5b_is_2_80
FROM   ${schema}.${ads};


-- =============================================================================
-- V3. TINTCRPCHSPC SIGN  (register Q10)
-- =============================================================================
-- Q10 is decided: the direction follows the label, (CRPCDate - HSPCDate), so
-- pos_tint should dominate (~72543 of 73026 per preflight D2). There is one
-- formula in the build and no switch, so neg_tint dominating here would mean
-- the formula itself was changed, not that a run used a different setting.
-- Treat that as a code defect, not a config question.
SELECT SUM(CASE WHEN tintcrpchspc < 0 THEN 1 ELSE 0 END) neg_tint,
       SUM(CASE WHEN tintcrpchspc > 0 THEN 1 ELSE 0 END) pos_tint,
       COUNT(tintcrpchspc) non_null
FROM ${schema}.${ads};


-- =============================================================================
-- V4. CHRONOLOGY - QUANTIFY, DO NOT ASSUME
-- =============================================================================
-- V1's c08 asserts that nothing precedes the index date. It says nothing about
-- the other end, or about events that are impossible relative to each other.
-- None of these is fail-closed: each is a construct the spec does not define,
-- so the honest position is to measure it, record the number with the release,
-- and let the SME rule. A silent zero is a real result; a large number is a
-- decision the register is missing.
SELECT 'X01 fued after MAXINDEX'                    what, COUNT(*) n FROM ${schema}.${ads} WHERE fued  > DATE'2026-04-30'
UNION ALL SELECT 'X02 dthdt after MAXINDEX',              COUNT(*)   FROM ${schema}.${ads} WHERE dthdt > DATE'2026-04-30'
UNION ALL SELECT 'X03 pfsdt after dthdt (ADS rows)',      COUNT(*)   FROM ${schema}.${ads} WHERE pfsdt > dthdt
-- The ADS is one row per patient per cohort, so a patient can appear in two
-- rows (Overall plus their LOT cohort) and COUNT(*) overstates the affected
-- population. Q34 needs the patient count, so both are reported.
UNION ALL SELECT 'X03b pfsdt after dthdt (distinct patients)',
       COUNT(DISTINCT patid) FROM ${schema}.${ads} WHERE pfsdt > dthdt
UNION ALL SELECT 'X04 pfsdt after fued',                  COUNT(*)   FROM ${schema}.${ads} WHERE pfsdt > fued
-- X05 is unreachable since Q82: FUED is DTHDT wherever a death date exists.
UNION ALL SELECT 'X05 fued after dthdt (unreachable under Q82)', COUNT(*)   FROM ${schema}.${ads} WHERE fued  > dthdt
UNION ALL SELECT 'X06 psma_scandt after MAXINDEX',        COUNT(*)   FROM ${schema}.${ads} WHERE psma_scandt > DATE'2026-04-30'
UNION ALL SELECT 'X07 os censored (dthfl=0) but fued < indexdt', COUNT(*)
       FROM ${schema}.${ads} WHERE dthfl = 0 AND fued < indexdt
-- X08/X09 are the place a missing input silently becomes a negative result
-- rather than a missing one: psa50_* / psal* are built with `case_when(... ~
-- 'Y', TRUE ~ 'N')`, so no PSA at all reads as "did not respond". Whether that
-- is intended is a register item, not a defect on its own - but the size of it
-- has to be on the record, because it is the difference between a 'N' that
-- means "measured, no response" and one that means "never measured".
UNION ALL SELECT 'X08 psa50_6mo=N with no 6mo PSA or no baseline',  COUNT(*)
       FROM ${schema}.${ads} WHERE psa50_6mo  = 'N' AND (psa6mo  IS NULL OR psa_index IS NULL)
UNION ALL SELECT 'X09 psa50_12mo=N with no 12mo PSA or no baseline', COUNT(*)
       FROM ${schema}.${ads} WHERE psa50_12mo = 'N' AND (psa12mo IS NULL OR psa_index IS NULL)
-- X10: same shape for VIS120. It is `ifelse(... , 1L, 0L)`, so a patient whose
-- index line has no end date scores 0 - "no visit 120+ days after treatment
-- ended" - when the truth is that the treatment end date is unknown. The end
-- date is cohort-specific, so this has to branch on cohortn, not COALESCE.
UNION ALL SELECT 'X10 vis120=0 while the INDEX line has no end date', COUNT(*)
       FROM ${schema}.${ads}
       WHERE  vis120 = 0
       AND    CASE cohortn WHEN 3 THEN lot1ed_mhspc
                           WHEN 4 THEN lot1ed_mcrpc
                           WHEN 5 THEN lot2ed_mcrpc
                           WHEN 6 THEN lot3ed_mcrpc
                           WHEN 7 THEN lot4ed_mcrpc END IS NULL
-- X11 closes the third limb of register Q34. X03 and X04 cover progression
-- after death and after end of follow-up; this covers progression after the
-- last clinic note, which is what PFS censors on. LASTCLINICNOTEDATE is not a
-- delivered column, but it does not need to be: it is a per-patient max over
-- the progression source, exactly as the build derives it, so it can be
-- re-derived here and compared with the delivered PFSDT. Preflight D9 counts
-- the same shape at source over all raw progression rows; this counts it on the
-- rows that actually became the deliverable, so the two are not the same number
-- and this is the one to record against Q34.
-- PFSDT is the first qualifying progression, or DTHDT when there is no
-- progression and the patient died. Counting pfsdt > lastnote without excluding
-- the death-derived rows measures both things at once and reads as if they were
-- all progressions. Death legitimately falls after the last clinic note, so
-- those rows are not anomalies. Restricted to rows whose PFSDT is not the death
-- date. Imperfect where a progression coincides exactly with DTHDT, which is
-- rare and errs toward under-counting rather than over.
UNION ALL SELECT 'X11 pfsdt (progression-derived) after the last clinic note', COUNT(*)
       FROM ${schema}.${ads} a
       JOIN  (SELECT patientid, MAX(lastclinicnotedate) lastnote
              -- Source schema, not ${schema}. ${schema} is the personal output
              -- schema and holds only built tables; the progression source lives
              -- in the Flatiron schema. Qualifying it with ${schema} makes the
              -- table unresolvable, and V4 is one UNION ALL chain, so the whole
              -- section fails - including X03, which Q34 depends on.
              FROM   ${src}.t_enh_prostate_prog_scled_2026m06
              GROUP  BY patientid) p ON p.patientid = a.patid
       WHERE a.pfsdt > p.lastnote
         AND (a.dthdt IS NULL OR a.pfsdt <> a.dthdt)
ORDER BY what;


-- =============================================================================
-- V5. EXACT COLUMN CONTRACT
-- =============================================================================
-- See V1b. Not runnable as SQL on hive_metastore; use
--     Rscript validation/04_column_contract_check.R <table_name>
-- which compares delivered name and ordinal position against
-- validation/00_column_contract.csv - maintained by hand from the program spec, not
-- regenerated from the code, so it is an independent check rather than a
-- restatement of the implementation.
