# =============================================================================
# CLOSING COUNTS IN R - RUN IN DATABRICKS, NOTHING FETCHED
# =============================================================================
#   Rscript validation/06_closing_counts.R        (after a build, repo root)
#
# Four open decisions each need one number before they can be closed. Each
# runs inside Databricks and lands as a table in the personal schema.
# Nothing comes back to this session. Read the tables in the SQL editor.
#
#   qcr_k69_labhem_r   R54. failed = 0 closes it.
#   qcr_k66_deaths_r   K08b + K08d: deaths whose date the build cannot parse -
#                      the wrong length, or the right length with impossible
#                      content. Both read as censored. An empty table closes
#
#   qcr_k67_bp_r       K09a: BP readings per arm. n_positive_non_integral = 0
#                      closes it.
#   qcr_k68_hw_r       K09b: zero or negative height and weight - the numbers
#                      the question needs.
# =============================================================================

if (!exists("con")) {
  message("no open connection - sourcing validation/00_connect.R")
  source("validation/00_connect.R")
}
stopifnot(exists("con"), exists("personal_schema"), exists("output_table"),
          exists("source_schema"), exists("refresh"))

ads  <- dplyr::tbl(con, dbplyr::in_schema(personal_schema, output_table))
# rename_with(tolower): the driver reports source columns in stored case,
# which is not always lower - the build's own src() lowercases the same way.
src_ <- function(tb) dplyr::tbl(con, dbplyr::in_schema(
          source_schema, paste0(tb, "_", refresh))) %>%
  dplyr::rename_with(tolower)

# ---- R54: LABHEM is not uniformly Missing -----------------------------
# If no row reads Present, the unit filter matched nothing. failed = every
# row then, else 0 - the same shape as the SQL gate.
message("writing qcr_k69_labhem_r")
createInPersonalSchema(
  ads %>% dplyr::summarise(
    n_rows    = dplyr::n(),
    n_present = sum(dplyr::case_when(labhem == "Present" ~ 1L, TRUE ~ 0L),
                    na.rm = TRUE)) %>%
    dplyr::transmute(
      check  = "R54 labhem not uniformly Missing",
      failed = dplyr::case_when(n_present == 0L ~ n_rows, TRUE ~ 0L)),
  "qcr_k69_labhem_r", replace = TRUE)

# ---- deaths the build cannot parse -------------------------------------
# Replays the build's own parse (7-char + '-15', 4-char + '-07-15', else
# NULL; TRY_CAST also nulls impossible content) and flags every row it
# nulls - both failure shapes, not length alone.
message("writing qcr_k66_deaths_r")
createInPersonalSchema(
  # src_dod, not dateofdeath: the ADS has its own dateofdeath column, and an
  # unrenamed join would suffix both.
  ads %>%
    dplyr::inner_join(src_("t_mortality_v2") %>%
                        dplyr::select(patientid, src_dod = dateofdeath),
                      by = c("patid" = "patientid")) %>%
    dplyr::filter(!is.na(src_dod)) %>%
    dplyr::filter(sql("CASE
           WHEN LENGTH(src_dod) = 7 THEN TRY_CAST(CONCAT(src_dod, '-15') AS DATE)
           WHEN LENGTH(src_dod) = 4 THEN TRY_CAST(CONCAT(src_dod, '-07-15') AS DATE)
         END IS NULL")) %>%
    dplyr::group_by(cohort) %>%
    dplyr::summarise(
      n_rows_affected     = dplyr::n(),
      n_patients_affected = dplyr::n_distinct(patid),
      n_bad_content       = sum(dplyr::case_when(
                              nchar(src_dod) %in% c(4L, 7L) ~ 1L, TRUE ~ 0L),
                              na.rm = TRUE),
      min_len             = min(nchar(src_dod), na.rm = TRUE),
      max_len             = max(nchar(src_dod), na.rm = TRUE),
      n_reading_alive     = sum(dplyr::case_when(dthfl == 0L ~ 1L, TRUE ~ 0L),
                                na.rm = TRUE),
      n_dthdt_null        = sum(dplyr::case_when(is.na(dthdt) ~ 1L, TRUE ~ 0L),
                                na.rm = TRUE),
      .groups = "drop"),
  "qcr_k66_deaths_r", replace = TRUE)

# ---- K09a: blood-pressure readings per arm ----------------------------
message("writing qcr_k67_bp_r")
createInPersonalSchema(
  src_("t_vitals") %>%
    dplyr::filter(tolower(test) %in% c("systolic blood pressure",
                                       "diastolic blood pressure")) %>%
    dplyr::mutate(v = !!safe_num(testresult)) %>%
    dplyr::group_by(arm = tolower(test)) %>%
    dplyr::summarise(
      n_rows       = dplyr::n(),
      n_patients   = dplyr::n_distinct(patientid),
      n_uncastable = sum(dplyr::case_when(is.na(v) ~ 1L, TRUE ~ 0L), na.rm = TRUE),
      n_non_positive = sum(dplyr::case_when(v <= 0 ~ 1L, TRUE ~ 0L), na.rm = TRUE),
      n_positive_non_integral =
        sum(dplyr::case_when(v > 0 & v != round(v, 0L) ~ 1L, TRUE ~ 0L),
            na.rm = TRUE),
      .groups = "drop"),
  "qcr_k67_bp_r", replace = TRUE)

# ---- K09b: zero and negative height / weight --------------------------
message("writing qcr_k68_hw_r")
createInPersonalSchema(
  src_("t_vitals") %>%
    dplyr::filter((tolower(test) == "body height" & testunitscleaned == "cm") |
                  (tolower(test) == "body weight" & testunitscleaned == "kg")) %>%
    dplyr::group_by(measure = tolower(test), unit = testunitscleaned) %>%
    dplyr::summarise(
      n_rows     = dplyr::n(),
      n_patients = dplyr::n_distinct(patientid),
      n_zero     = sum(dplyr::case_when(testresultcleaned == 0 ~ 1L, TRUE ~ 0L),
                       na.rm = TRUE),
      n_negative = sum(dplyr::case_when(testresultcleaned < 0 ~ 1L, TRUE ~ 0L),
                       na.rm = TRUE),
      min_val    = min(testresultcleaned, na.rm = TRUE),
      max_val    = max(testresultcleaned, na.rm = TRUE),
      .groups = "drop"),
  "qcr_k68_hw_r", replace = TRUE)

if (exists("qcr_stamp")) qcr_stamp("06_closing_counts")

message("DONE - nothing was fetched. Read in the SQL editor:")
for (t in c("qcr_k69_labhem_r", "qcr_k66_deaths_r", "qcr_k67_bp_r", "qcr_k68_hw_r"))
  message("  SELECT * FROM ", personal_schema, ".", t)
