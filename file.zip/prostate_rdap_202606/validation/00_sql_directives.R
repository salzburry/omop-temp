# =============================================================================
# THE `-- @assert` DIRECTIVE SYNTAX, IN ONE PLACE - SOURCED, NOT RUN
# =============================================================================
# Both .sql runners read these directives out of the comment blocks above a
# statement. run_sql.R then EVALUATES them; materialize_checks.R never reads a
# result, so it can only report the ones it passed over. Both must agree on
# what a directive MEANS and on which ones are malformed - a typo caught by one
# runner and silently echoed by the other is worse than no check, because the
# echoed line reads like an assertion somebody could verify by hand.
#
# So the grammar lives here and both source it. A malformed directive is a hard
# error in either runner, with or without a database.
#
#   -- @assert no-rows                    the statement must return no rows
#   -- @assert min-rows <n>               at least n rows
#   -- @assert zero <col>                 every value in <col> is 0
#   -- @assert zero <col> when <c>=<v>    ... only for rows where <c> = <v>
#   -- @assert positive <col>             every value in <col> is > 0
#   -- @assert none <col> in <V1>,<V2>    no row's <col> is any of these
#
# Sourced by validation/run_sql.R and validation/materialize_checks.R.
# =============================================================================

ASSERT_FORMS <- c("no-rows", "min-rows", "zero", "positive", "none")

parse_assert <- function(spec, path) {
  p    <- strsplit(trimws(spec), "[[:space:]]+")[[1]]
  kind <- tolower(p[1])
  bad  <- function(why)
    stop(path, ": cannot read `-- @assert ", spec, "` - ", why,
         "\nForms: ", paste(ASSERT_FORMS, collapse = ", "), call. = FALSE)
  if (!kind %in% ASSERT_FORMS) bad("unknown form")
  if (kind == "no-rows") {
    if (length(p) != 1L) bad("takes no argument")
    list(kind = kind, spec = spec)
  } else if (kind == "min-rows") {
    if (length(p) != 2L) bad("needs a count")
    n <- suppressWarnings(as.integer(p[2]))
    if (is.na(n) || n < 0L) bad("count must be a non-negative integer")
    list(kind = kind, n = n, spec = spec)
  } else if (kind == "positive") {
    if (length(p) != 2L) bad("needs one column")
    list(kind = kind, col = tolower(p[2]), spec = spec)
  } else if (kind == "zero") {
    # zero <col>  |  zero <col> when <col>=<value>
    if (!length(p) %in% c(2L, 4L)) bad("needs `zero <col>` or `zero <col> when <col>=<value>`")
    a <- list(kind = kind, col = tolower(p[2]), spec = spec)
    if (length(p) == 4L) {
      if (tolower(p[3]) != "when") bad("third word must be `when`")
      kv <- strsplit(p[4], "=", fixed = TRUE)[[1]]
      if (length(kv) != 2L || !nzchar(kv[1]) || !nzchar(kv[2]))
        bad("the filter must read <col>=<value>")
      a$when_col <- tolower(kv[1]); a$when_val <- kv[2]
    }
    a
  } else {
    if (length(p) != 4L || tolower(p[3]) != "in")
      bad("needs `none <col> in <V1>,<V2>`")
    vals <- trimws(strsplit(p[4], ",", fixed = TRUE)[[1]])
    vals <- vals[nzchar(vals)]
    if (!length(vals)) bad("names no values")
    list(kind = kind, col = tolower(p[2]), vals = vals, spec = spec)
  }
}
