# =============================================================================
# PREFLIGHT IN R - SOURCE GATES, RUN IN DATABRICKS BEFORE EVERY BUILD
# =============================================================================
#   Rscript validation/01_preflight.R             (before a build, repo root)
#
# The build only creates. These checks used to run inside
# code/modules/00_setup.R; they are still mandatory preconditions - a
# failure here means DO NOT BUILD. Section B of
# validation/01_preflight_databricks.sql is the canonical, reviewed statement
# of the same gates.
#
# Each gate guards a silent corruption. A duplicate row fans out the clinical
# block. A non-deterministic NEW_LOT_N moves cohort membership, index dates,
# ECOG matching and TTNT between runs of the same code. An unparseable
# death date disables the per-cohort death exclusion for that patient (B18,
#). None of them shows in the finished table, so the answer has to
# come before the build.
#
# Every check runs inside Databricks and lands as a table in the personal
# schema. The only fetches are the per-table column listings for the input
# contract and the one-row verdict at the end.
#
#   qcr_contract_r      one row per source table - required columns present?
#   qcr_preflight_r     the thirteen B-gates plus C10 and C10c. Every failed count must
#                       be 0.
#   qcr_c10_labs_r      the expected lab analyte/unit combinations and the
#                       rows found for each. C10 fails on any zero.
#   qcr_hrr_excluded_r  HRR panel drift, both directions: a gene in
#                       the table but off the active panel classifies as
#                       not-HRR; a panel gene absent from the cut narrows
#                       the case definition. A reading, not a gate. Under
#                       flatiron_all, empty means no drift; under a smaller
#                       panel the deliberately omitted genes also appear as
#                       EXCLUDED - expected, not drift.
#
# Exit 0 = clear to build. Exit 1 = the contract or a gate failed. Exit 2 =
# results written but the verdict could not be fetched; read qcr_preflight_r
# before building.
# RP1-RP4 and W1-W3 are the 2026-09-11 ruling's four rules and the three
# behaviours they withdraw, defined in docs/VARIABLES.md section 3.
# =============================================================================

if (!exists("con")) {
  message("no open connection - sourcing validation/00_connect.R")
  source("validation/00_connect.R")
}
stopifnot(exists("con"), exists("personal_schema"), exists("source_schema"),
          exists("refresh"), exists("hrr_panel_mode"))

# rename_with(tolower): the driver reports source columns in stored case,
# which is not always lower - the build's own src() lowercases the same way.
src_ <- function(tb) dplyr::tbl(con, dbplyr::in_schema(
          source_schema, paste0(tb, "_", refresh))) %>%
  dplyr::rename_with(tolower)

# ---- input contract  (3.Data Prep, section A) -------------------------------
# Every source column the build reads, by table. Checked before the build, so
# a missing column stops the run before it starts instead of failing partway -
# which would leave the personal schema holding a mixture of this run's stages
# and the last one's. The offline harness diffs this list against
# validation/00_input_contract.csv, so the two cannot drift.
required_columns <- list(
  t_demographics = c("patientid", "birthyear", "race", "ethnicity", "state"),
  t_ecog = c("patientid", "ecogdate", "ecogvalue"),
  t_enh_prostate = c(
    "patientid", "diagnosisdate", "groupstage", "gleasonscore",
    "metastaticdiagnosisdate", "crpcdate", "crpctype", "hspcdate",
    "hspctype", "psainitialdiagnosis", "psametdiagnosis"),
  t_enh_prostate_biomarker = c(
    "patientid", "biomarkername", "biomarkerstatus", "resultdate",
    "specimencollecteddate"),
  t_enh_prostate_bsln_ecog = c(
    "patientid", "ecogdate", "ecogvalue", "linenumber",
    "linestartdate"),
  t_enh_prostate_drg_epsode = c(
    "patientid", "linename", "linenumber", "linesetting",
    "episodedate", "episodedatasource", "drugcategory",
    "detaileddrugcategory"),
  t_enh_prostate_lot = c(
    "patientid", "linename", "linenumber", "linesetting",
    "startdate", "enddate"),
  t_enh_prostate_orals = c("patientid", "startdategranularity", "enddate"),
  t_enh_prostate_prog_scled = c(
    "patientid", "progressiondate", "lastclinicnotedate",
    "isradiographicevidence", "ispathologicevidence",
    "ismixedresponsementioned", "ispseudoprogressionmentioned",
    "isphysicalexamevidence", "istumormarkerevidence",
    "ispsaincreased"),
  t_enh_prostate_psa = c("patientid", "scoreserial", "resultdate"),
  t_enh_prostate_psmapet = c("patientid", "scandate", "isdiseaseevidence"),
  t_enh_prostate_som = c("patientid", "siteofmetastasis", "dateofmetastasis"),
  t_lab = c(
    "patientid", "testbasename", "labcomponent", "testdate",
    "resultdate", "testresultcleaned", "testunitscleaned"),
  t_medicationadmin = c(
    "patientid", "administereddate", "drugcategory",
    "detaileddrugcategory"),
  t_medicationorder = c(
    "patientid", "expectedstartdate", "iscanceled",
    "drugcategory", "detaileddrugcategory"),
  t_mortality_v2 = c("patientid", "dateofdeath"),
  t_practice = c("patientid", "practicetype"),
  t_socdetofhealth = c("patientid", "sesindex2015_2019"),
  t_telemedicine = c("patientid", "visitdate"),
  t_visit = c("patientid", "visitdate"),
  t_vitals = c(
    "patientid", "test", "testdate", "resultdate", "testresult",
    "testresultcleaned", "testunitscleaned")
)

message("checking the input contract (", length(required_columns), " tables / ",
        length(unlist(required_columns)), " columns)")
contract_gap <- character(0)
for (t in names(required_columns)) {
  have <- tryCatch(colnames(src_(t)), error = function(e) NULL)
  contract_gap[t] <- if (is.null(have)) {
    "TABLE NOT READABLE"
  } else {
    gap <- setdiff(required_columns[[t]], tolower(have))
    if (length(gap)) paste("missing:", paste(gap, collapse = ", ")) else "ok"
  }
}

message("writing qcr_contract_r")
createInPersonalSchema(
  dbplyr::copy_inline(con, data.frame(
    tab        = names(required_columns),
    n_required = as.integer(lengths(required_columns)),
    status     = unname(contract_gap),
    stringsAsFactors = FALSE)),
  "qcr_contract_r", replace = TRUE)
contract_ok <- all(contract_gap == "ok")

# ---- the thirteen B-gates ---------------------------------------------------
lot_all <- src_("t_enh_prostate_lot")
lot     <- lot_all %>% dplyr::filter(linesetting %in% c("mHSPC", "mCRPC"))
drugep  <- src_("t_enh_prostate_drg_epsode")

# dplyr:: qualified - the site helpers sourced by 00_connect.R mask count().
dup <- function(tb, ...) tb %>% dplyr::count(...) %>%
  dplyr::filter(n > 1) %>% dplyr::tally()

gate <- function(q, id, what, why) {
  q %>% dplyr::transmute(gate = !!id, what = !!what, why = !!why,
                         failed = as.integer(n))
}

# The LINENAME allow-list (B13/B14): a token is letters, digits, dots,
# brackets and hyphens, with single internal spaces (Clinical Study Drug,
# Radium-223). Tokens join with a bare comma or slash. Anything else - an
# outer space, a spaced separator, a trailing comma, an empty token - the
# anchored category parser cannot read: the regimen reads as one drug name,
# matches no rule, and lands in category 16 with nothing reporting it.
# An allow-list, not a reject-list - a reject-list only catches the
# characters somebody thought of.
LINENAME_OK <- "'^[A-Za-z0-9.()-]+( [A-Za-z0-9.()-]+)*([,/][A-Za-z0-9.()-]+( [A-Za-z0-9.()-]+)*)*$'"

gates <- list(
  gate(lot %>% dplyr::filter(is.na(startdate)) %>% dplyr::tally(),
       "B12", "NULL line start dates",
       "NEW_LOT_N ordering is not well defined"),
  gate(dup(lot, patientid, linesetting, startdate),
       "B1", "same-day line-of-therapy ties",
       "NEW_LOT_N is non-deterministic"),
  gate(dup(lot, patientid, linesetting, linenumber),
       "B6", "duplicate LineNumbers per patient and setting",
       "baseline ECOG would join to the wrong line"),
  # Each table is tested at the grain the clinical block joins it on.
  # Pre-aggregating here would make a duplicate impossible and the gate
  # useless. Mortality is joined through a distinct(), so its gate matches.
  gate(dup(src_("t_enh_prostate"), patientid),
       "B2", "t_enh_prostate patients with >1 row", "joins fan out"),
  gate(dup(src_("t_demographics"), patientid),
       "B4", "t_demographics patients with >1 row", "joins fan out"),
  gate(dup(src_("t_socdetofhealth"), patientid),
       "B5", "t_socdetofhealth patients with >1 row", "joins fan out"),
  gate(dup(src_("t_mortality_v2") %>%
             dplyr::select(patientid, dateofdeath) %>% dplyr::distinct(),
           patientid),
       "B3", "patients with conflicting death dates", "joins fan out"),
  gate(lot %>%
         dplyr::filter(sql(paste0("linename IS NOT NULL
                     AND NOT linename RLIKE ", LINENAME_OK))) %>%
         dplyr::tally(),
       "B13", "LOT LINENAME separator/whitespace contract",
       "the regimen parser reads them as one drug -> category 16"),
  # Same contract on the drug-episode table: PRIOR_PARP and PRIOR_NHA_ADT
  # parse LINENAME from drug episodes, so an unexpected separator there
  # changes a delivered flag while B13 passes.
  gate(drugep %>%
         dplyr::filter(sql(paste0("linename IS NOT NULL
                     AND NOT linename RLIKE ", LINENAME_OK))) %>%
         dplyr::tally(),
       "B14", "drugepisode LINENAME separator/whitespace contract",
       "PRIOR_PARP and PRIOR_NHA_ADT parse the same names"),
  # LINESETTING is matched exactly in the build. A near-miss - mhspc, an
  # outer space - does not raise anything there: the row simply is not
  # selected, the line vanishes from its cohort, and the table still looks
  # complete. Catch the near-miss; a value that reads as neither setting is
  # out of the study by design.
  gate(lot_all %>%
         dplyr::filter(sql("linesetting IS NOT NULL
                     AND LOWER(TRIM(linesetting)) IN ('mhspc', 'mcrpc')
                     AND linesetting NOT IN ('mHSPC', 'mCRPC')")) %>%
         dplyr::tally(),
       "B15", "LOT LINESETTING case or whitespace variants",
       "the setting filter is exact - the line vanishes from its cohort"),
  gate(drugep %>%
         dplyr::filter(sql("linesetting IS NOT NULL
                     AND LOWER(TRIM(linesetting)) IN ('mhspc', 'mcrpc')
                     AND linesetting NOT IN ('mHSPC', 'mCRPC')")) %>%
         dplyr::tally(),
       "B16", "drugepisode LINESETTING case or whitespace variants",
       "the per-line episode look-up filters on the same exact value"),
  # A comma is taken as proof of a second drug, so 'abiraterone,abiraterone'
  # reads as an NHA combination rather than a monotherapy, and B13 passes it
  # because the format is legal. Split on the comma only: the slash binds
  # inside one co-formulated product name (Niraparib/Abiraterone), it does
  # not separate regimen components.
  gate(lot %>%
         dplyr::select(patientid, linename) %>%
         dplyr::union_all(drugep %>% dplyr::select(patientid, linename)) %>%
         dplyr::filter(sql("linename IS NOT NULL
                     AND SIZE(SPLIT(LOWER(linename), ','))
                         <> SIZE(ARRAY_DISTINCT(SPLIT(LOWER(linename), ',')))")) %>%
         dplyr::tally(),
       "B17", "LINENAME with the same drug listed twice",
       "a repeat reads as a combination regimen, not a monotherapy"),
  # B18. A populated DATEOFDEATH that the imputation cannot use.
  # keeps the derivation spec-literal - 5B.ClinChars r90 documents
  # month-and-year and year-only and nothing else, so any other length falls to
  # NULL - and until now that hole only MEASURED badly: a dead patient read as
  # censored, DTHFL 0, OS taken to the follow-up end. qc/08_death_date_formats.R
  # sizes exactly that.
  #
  # SOURCE-WIDE BY NECESSITY, not by oversight. This gate runs at preflight,
  # before the build, so no cohort exists to scope it to - the population it
  # protects cannot be named yet. The count is therefore an upper bound on the
  # membership exposure: some of these patients will fall outside all seven
  # cohorts for unrelated reasons and cost nothing. Read it as "the exclusion
  # is blind on this many source rows"; validation/06's ADS-scoped oracle is
  # what narrows it to delivered patients after a build.
  #
  # Rule RP4 promotes it to a MEMBERSHIP defect, which is why it
  # is a gate now and was not before. index_lot_cohort() spells RP4 as
  # `dthdt IS NULL OR index_date <= dthdt`. An
  # unparseable DATEOFDEATH lands on the first limb, so the patient is silently
  # NOT excluded anywhere: they keep cohort rows the ruling says they lose, and
  # the ADS ships an index date after a death the source recorded. Nothing
  # downstream can recover the exclusion, because the death date is the only
  # thing it reads.
  #
  # The test is the build's own CASE rather than a LENGTH() test, so it catches
  # both shapes at once: the wrong length (the hole) and the right length with
  # unusable content - '2020-13', '2020/03'. TRY_CAST(... AS DATE) has no dplyr
  # translation (safe_num/safe_int cover DOUBLE and INT only), so the predicate
  # goes in as raw sql() - the same route the LINENAME gates above take. The
  # CASE is the one 01_studypop.R evaluates, arm for arm; if that derivation is
  # ever changed, change it here too or the gate stops describing the build.
  gate(src_("t_mortality_v2") %>%
         dplyr::filter(sql(
           "dateofdeath IS NOT NULL
            AND CASE
              WHEN LENGTH(dateofdeath) = 7
                THEN TRY_CAST(CONCAT(dateofdeath, '-15') AS DATE)
              WHEN LENGTH(dateofdeath) = 4
                THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
              ELSE NULL END IS NULL")) %>%
         dplyr::tally(),
       "B18", "DATEOFDEATH populated but unparseable",
       "the per-cohort death exclusion cannot fire on a NULL death date")
)

# ---- C10: expected lab analytes exist  (mandatory) -----------------------
# An absent combination empties its analyte (values and dates NULL), so this
# is a gate. NA component = no component filter. Compared the way the build
# compares: lower-cased name, trimmed unit, exact component - a raw
# compare would refuse a source the build accepts.
lab_expected <- data.frame(
  testbasename = c("neutrophils", "platelets", "hemoglobin", "creatinine",
                   "bilirubin", "aspartate aminotransferase",
                   "alanine aminotransferase", "alkaline phosphatase",
                   "albumin", "lymphocytes"),
  unit = c("10*9/L", "10*9/L", "g/dL", "mg/dL", "mg/dL", "U/L", "U/L",
           "U/L", "g/L", "10*9/L"),
  component = c(NA, NA, NA, "Creatinine, serum", NA, NA, NA, NA,
                "Albumin, serum", NA),
  stringsAsFactors = FALSE)

lab_found <- src_("t_lab") %>%
  dplyr::group_by(tb = tolower(testbasename), u = trimws(testunitscleaned),
                  lc = labcomponent) %>%
  dplyr::summarise(n = dplyr::n(), .groups = "drop")

lab_matches <- dbplyr::copy_inline(con, lab_expected) %>%
  dplyr::inner_join(lab_found, by = c("testbasename" = "tb")) %>%
  dplyr::filter(u == unit, is.na(component) | lc == component) %>%
  dplyr::group_by(testbasename, unit, component) %>%
  dplyr::summarise(found_rows = sum(n, na.rm = TRUE), .groups = "drop")

c10 <- dbplyr::copy_inline(con, lab_expected) %>%
  dplyr::left_join(lab_matches, by = c("testbasename", "unit", "component"),
                   na_matches = "na") %>%
  dplyr::mutate(found_rows = coalesce(found_rows, 0),
                status = dplyr::case_when(found_rows > 0 ~ "PASS",
                                          TRUE ~ "FAIL"))

message("writing qcr_c10_labs_r")
createInPersonalSchema(c10, "qcr_c10_labs_r", replace = TRUE)

gates <- c(gates, list(
  gate(c10 %>% dplyr::summarise(
         n = sum(dplyr::case_when(found_rows == 0 ~ 1L, TRUE ~ 0L),
                 na.rm = TRUE)),
       "C10", "expected lab analyte/unit combinations all present",
       "an absent combination empties its analyte - values and dates all NULL")))

# ---- C10c: serum albumin is on the g/L SCALE  (mandatory) ----------------
# B2.12. C10 above checks only that the albumin/g/L COMBINATION EXISTS. One
# qualifying row satisfies it, so a source that had drifted to g/dL - 99% of
# values near 4 rather than 40, with a handful still labelled g/L - would pass
# while production's g/L filter discarded almost every albumin record. The
# canonical SQL had a C10c for exactly this and the R had no equivalent, so the
# enforcing copy was the weaker of the two.
#
# 3.5-5.0 g/dL == 35-50 g/L is a clean 10x with no overlap, so a row lands in
# exactly one band and a mixture cannot hide inside a single median. The g/L
# band specifically must hold >= 99%: "some band holds 99%" is what let the
# g/dL case through in the SQL.
#
# The 2026-09-12 cut reads 99.91% g/L, so this is refresh-drift protection, not
# a claim about today's data. It does NOT bound the values forbids
# filtering on one - which is what S7 in validation/05_sizing.R sizes instead.
alb_bands <- src_("t_lab") %>%
  dplyr::filter(tolower(testbasename) == "albumin",
                labcomponent == "Albumin, serum",
                !!safe_num(testresultcleaned) > 0) %>%
  dplyr::summarise(
    n_total = dplyr::n(),
    n_gl    = sum(dplyr::case_when(!!safe_num(testresultcleaned) >= 15 &
                                   !!safe_num(testresultcleaned) <= 70 ~ 1L,
                                   TRUE ~ 0L), na.rm = TRUE))

message("writing qcr_c10c_albumin_scale_r")
createInPersonalSchema(
  alb_bands %>% dplyr::mutate(
    pct_gl = round(100 * n_gl / n_total, 4),
    status = dplyr::case_when(n_total == 0 ~ "FAIL",
                              100 * n_gl >= 99 * n_total ~ "PASS",
                              TRUE ~ "FAIL")),
  "qcr_c10c_albumin_scale_r", replace = TRUE)

# n_total == 0 has to FAIL, not pass. With no qualifying albumin row at all,
# `100 * 0 < 99 * 0` is FALSE and the gate read zero failures - it passed
# loudest exactly where production would deliver no albumin. A population this
# check cannot see is not a population it has cleared.
gates <- c(gates, list(
  gate(alb_bands %>% dplyr::summarise(
         n = sum(dplyr::case_when(n_total == 0 ~ 1L,
                                  100 * n_gl < 99 * n_total ~ 1L, TRUE ~ 0L),
                 na.rm = TRUE)),
       "C10c", "serum albumin is on the g/L scale (>= 99% of rows)",
       "production filters on the spec's g/L unit; a source on g/dL would deliver almost no albumin")))

message("writing qcr_preflight_r (", length(gates), " gates)")
createInPersonalSchema(Reduce(dplyr::union_all, gates), "qcr_preflight_r",
                       replace = TRUE)

# ---- HRR panel drift, both directions --------------------------------
# A gene in the table but off the panel classifies as not-HRR; a panel gene
# missing from the cut narrows the case definition. Both land here. Under
# flatiron_all, empty = no drift; smaller panels also list their deliberate
# omissions as EXCLUDED. Canonical B7b always compares the frozen 19.
hrr_panels <- list(
  flatiron_all   = c("ATM", "ATR", "BARD1", "BRCA1", "BRCA2", "BRIP1",
                     "CDK12", "CHEK1", "CHEK2", "FANCA", "FANCL", "MLH1",
                     "MRE11A", "NBN", "PALB2", "RAD51B", "RAD51C",
                     "RAD51D", "RAD54L"),
  olaparib_label = c("ATM", "BARD1", "BRCA1", "BRCA2", "BRIP1", "CDK12",
                     "CHEK1", "CHEK2", "FANCL", "PALB2", "RAD51B",
                     "RAD51C", "RAD51D", "RAD54L"),
  talapro2       = c("ATM", "ATR", "BRCA1", "BRCA2", "CDK12", "CHEK2",
                     "FANCA", "MLH1", "MRE11A", "NBN", "PALB2", "RAD51C"))
hrr_genes <- hrr_panels[[hrr_panel_mode]]

hrr_actual <- src_("t_enh_prostate_biomarker") %>%
  dplyr::mutate(gene = toupper(biomarkername)) %>%
  dplyr::group_by(gene) %>%
  dplyr::summarise(n_results = dplyr::n(),
                   n_patients = dplyr::n_distinct(patientid),
                   .groups = "drop")

message("writing qcr_hrr_excluded_r (panel: ", hrr_panel_mode, ", ",
        length(hrr_genes), " genes)")
createInPersonalSchema(
  hrr_actual %>%
    dplyr::full_join(dbplyr::copy_inline(con, data.frame(
                       gene = hrr_genes, on_panel = 1L,
                       stringsAsFactors = FALSE)),
                     by = "gene") %>%
    dplyr::filter(is.na(on_panel) | is.na(n_results)) %>%
    dplyr::transmute(
      gene,
      n_results  = coalesce(n_results, 0L),
      n_patients = coalesce(n_patients, 0L),
      drift = dplyr::case_when(
        is.na(on_panel) ~
          "EXCLUDED - in the table, off the panel; classifies as not-HRR",
        TRUE ~
          "MISSING - on the panel, absent from the cut; narrows the case definition")),
  "qcr_hrr_excluded_r", replace = TRUE)

if (exists("qcr_stamp")) qcr_stamp("01_preflight")

# qcr_c10c_albumin_scale_r belongs in this list. It was written but not named,
# so a reader following the printout never saw it - and it is the one table
# here that a PASS does not speak for on its own: the C10c gate reads zero
# both when albumin is on the g/L scale and, before the n_total = 0 repair,
# when there was no albumin to weigh. Reading n_total and status directly is
# how you tell those apart.
message("Results written. Read in the SQL editor:")
for (t in c("qcr_contract_r", "qcr_preflight_r", "qcr_c10_labs_r",
            "qcr_c10c_albumin_scale_r", "qcr_hrr_excluded_r"))
  message("  SELECT * FROM ", personal_schema, ".", t)

if (!contract_ok) {
  bad <- names(contract_gap)[contract_gap != "ok"]
  message("FAIL - input contract: ",
          paste0(bad, " (", contract_gap[bad], ")", collapse = "; "),
          ". DO NOT BUILD.")
  quit(status = 1L, save = "no")
}

# Fail-closed: a verdict that cannot be fetched is not a pass. The tables are
# already written, so exit 2 and read qcr_preflight_r yourself.
v <- tryCatch(DBI::dbGetQuery(con, paste0(
       "SELECT COUNT(*) AS n FROM ", personal_schema,
       ".qcr_preflight_r WHERE failed IS NULL OR failed > 0")),
     error = function(e) NULL)
if (is.null(v)) {
  message("verdict fetch failed - read qcr_preflight_r before building")
  quit(status = 2L, save = "no")
}
if (v$n[1] > 0) {
  message("FAIL - ", v$n[1], " gate(s) hit. See qcr_preflight_r. DO NOT BUILD.")
  quit(status = 1L, save = "no")
}
message("PASS - the input contract holds and every gate reads 0. ",
        "Clear to build.")
