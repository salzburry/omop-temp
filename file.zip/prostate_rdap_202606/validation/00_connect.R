# =============================================================================
# CONNECTION-ONLY BOOTSTRAP FOR THE VALIDATION AND QC PROGRAMS
# =============================================================================
# The build's 00_setup.R connects for the build and nothing else - every
# check lives in this folder and qc/. Each program sources this file for the
# connection and the names, so none carries its own copy. Keep the pins in
# step with code/modules/00_setup.R.

source('/mnt/code/intake/oncology/prostrate/202606/code/01_project_necessities/001_setup.R')
source('/mnt/code/intake/oncology/prostrate/202606/code/01_project_necessities/002_helper_functions.R')
source('/mnt/code/intake/oncology/prostrate/202606/code/helperScripts/databases/personalSchemaFunctions.R')

# A site helper version defines its own sql() that drops tables. Same defence
# as 00_setup.R: every sql() below this line is dbplyr's raw-SQL literal.
sql <- dbplyr::sql

con <- connect()

output_catalog  <- "hive_metastore"
personal_schema <- "osk02156"
refresh         <- "2026m06"
source_schema   <- "clnprw_flatiron_pano_pros_use"

# A non-default HRR panel builds under a suffixed table name (00_setup.R), so
# the checks must aim at the same name - otherwise a talapro2 run validates
# the governed table and calls it evidence.
hrr_panel_mode <- Sys.getenv("RDAP_HRR_PANEL", unset = "flatiron_all")
if (!hrr_panel_mode %in% c("flatiron_all", "olaparib_label", "talapro2")) {
  stop("RDAP_HRR_PANEL must be 'flatiron_all', 'olaparib_label' or ",
       "'talapro2', got: ", hrr_panel_mode, call. = FALSE)
}
output_table <- paste0("rwdp_pros_pano_", refresh,
                       if (identical(hrr_panel_mode, "flatiron_all")) ""
                       else paste0("_hrr_", hrr_panel_mode))

DBI::dbExecute(con, paste0("USE CATALOG ", output_catalog))

# ANSI-safe casts, same definitions as the build's: TRY_CAST so a malformed
# free-text numeric reads NULL instead of aborting the query.
safe_int <- function(x)  sql(paste0("TRY_CAST(", rlang::as_label(rlang::enquo(x)), " AS INT)"))
safe_num <- function(x)  sql(paste0("TRY_CAST(", rlang::as_label(rlang::enquo(x)), " AS DOUBLE)"))

# Every validator stamps what it checked and when, server-side, so the qcr_*
# evidence carries a target, a clock and - as of 2026-09-12 - the identity of
# the code that produced it. See validation/00_build_identity.R for what the
# identity does and does not claim; it does NOT close Q43, which also asks
# about writing the deliverable under a stable name with no atomic promotion.
source("validation/00_build_identity.R")

qcr_stamp <- function(program) {
  id <- build_identity()
  createInPersonalSchema(
    dplyr::tbl(con, sql("SELECT current_timestamp() AS checked_at")) %>%
      dplyr::mutate(program        = !!program,
                    target         = !!paste0(personal_schema, ".", output_table),
                    checker_commit = !!id$checker_commit,
                    checker_dirty  = !!id$checker_dirty,
                    refresh        = !!id$refresh,
                    hrr_panel      = !!id$hrr_panel),
    paste0("qcr_stamp_", gsub("[^a-z0-9]+", "_", tolower(program)), "_r"),
    replace = TRUE)
}
