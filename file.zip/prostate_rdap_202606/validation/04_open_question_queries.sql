-- =============================================================================
-- Queries that close five open questions without a judgement call
-- =============================================================================
-- LABALB delivered scale        <- run this one FIRST
-- Index-date granularity  (Overall cohorts 1-2)
-- progression-date chronology
-- next-treatment date vs index      (within setting)
-- K42b next-treatment date vs index      (CROSS setting - cohort 3 only)
-- index line starting before its milestone
--
-- Schema below is the one the preflight resolved against. Change it in one
-- place if the run environment differs.
--
-- One assumption, worth a DESCRIBE before running:
--   reads METASTATICDIAGNOSISDATEGRANULARITY, HSPCDATEGRANULARITY and
--   CRPCDATEGRANULARITY from t_enh_prostate. Those names come from the data
--   profiler, not from validation/00_input_contract.csv, because the build
--   does not read them. If they error, DESCRIBE the table and use its names.
--
-- t_enh_prostate_lot has no granularity column, so index-date precision for
--   cohorts 3-7 cannot be sized from the source covers cohorts 1-2 only
--   (details in the header above).
--
-- NEW_LOT_N is derived, not stored: it restarts at 1 within each of mHSPC and
-- mCRPC, ordered by StartDate. Every query below reproduces that with the same
-- window the build uses, so the numbers describe the delivered cohorts rather
-- than the raw table.
--
-- Describing the delivered cohorts also means applying the per-cohort death
-- exclusion (study-team ruling 2026-09-11): a patient whose index
-- date for a cohort falls after their death date is excluded from that cohort.
-- rebuild cohort membership and so carry it; without it their
-- counts and percentages over-state the delivered population. The test is
-- strict - an index ON the death date is kept, only a strictly later one is
-- dropped - and a patient with no death date is never excluded, which is why
-- the IS NULL arm is written out rather than left to a comparison against NULL.
-- count source records, not cohort rows, and take no cohort
-- filter.
--
-- The death date is imputed the way the build imputes it
-- (code/modules/01_studypop.R): middle of the month for 'YYYY-MM', middle of
-- the year for 'YYYY', NULL for any other length (unchanged),
-- TRY_CAST so a value of the right length with impossible content nulls instead
-- of raising, and nothing promotes the result afterwards. That last part is why
-- below no longer compares against a month end: with W2 and W3 withdrawn
-- the mid-month value is the only death date the build ever produces.
-- RP1-RP4 and W1-W3 are the 2026-09-11 ruling's four rules and the three
-- behaviours they withdraw, defined in docs/VARIABLES.md section 3.
-- =============================================================================

USE CATALOG hive_metastore;
USE SCHEMA  clnprw_flatiron_pano_pros_use;

-- Shared definitions -----------------------------------------------------------
-- (Databricks does not persist WITH across statements, so each query repeats
--  these. They are identical everywhere - do not let them drift.)


-- =============================================================================
-- LABALB / LABALBV - is the delivered value g/L or g/dL?
-- =============================================================================
-- WHY IT MATTERS: the spec labels LABALBV "g/L" and filters on
-- testunitscleaned='g/L', but no albumin row carries that unit, so the filter
-- was dropped. If the underlying values are g/dL the delivered
-- column is out by a factor of ten.
--
-- HOW TO READ IT: serum albumin is ~3.5-5.0 g/dL, or ~35-50 g/L. The median
-- settles it on sight. No judgement required.
SELECT
    labcomponent,
    COALESCE(testunitscleaned, '<NULL>')                    AS unit,
    COUNT(*)                                                AS n_rows,
    COUNT(DISTINCT patientid)                               AS n_pts,
    ROUND(MIN(testresultcleaned), 2)                        AS min_val,
    ROUND(PERCENTILE_APPROX(testresultcleaned, 0.25), 2)    AS p25,
    ROUND(PERCENTILE_APPROX(testresultcleaned, 0.50), 2)    AS median,
    ROUND(PERCENTILE_APPROX(testresultcleaned, 0.75), 2)    AS p75,
    ROUND(MAX(testresultcleaned), 2)                        AS max_val
FROM t_lab_2026m06
WHERE LOWER(testbasename) = 'albumin'
  AND testresultcleaned IS NOT NULL
GROUP BY labcomponent, COALESCE(testunitscleaned, '<NULL>')
ORDER BY n_rows DESC;


-- =============================================================================
-- Index-date granularity  (Overall cohorts 1-2 only)
-- =============================================================================
-- t_enh_prostate_lot has no `startdategranularity` column; Databricks replies
--   [UNRESOLVED_COLUMN.WITH_SUGGESTION] ... Did you mean one of the following?
--   [`StartDate_sasdt`,`StartDate_year`,`StartDate_day`,`StartDate_month`,`StartDate`]
-- The LOT table records the date and its numeric parts, and nothing about
-- how precisely it was known. Index-date precision for cohorts 3-7 is not
-- answerable from the source - not "unknown pending a query", but not recorded.
--
-- What can be checked is cohorts 1 and 2, whose index date is
--   cohort 1: max(MetastaticDiagnosisDate, HSPCDate)
--   cohort 2: max(MetastaticDiagnosisDate, CRPCDate)
-- Both components carry a granularity column on t_enh_prostate. The profiler
-- gives each column separately (hspcdate DAY 701 / MONTH 197 / YEAR 155); what
-- it cannot give is the granularity of the component that wins the max(),
-- which is the only one that becomes INDEXDT.
--
-- The population is the DELIVERED cohort 1 / cohort 2, so the per-cohort
-- death exclusion applies in both branches: a patient whose milestone index
-- date falls after their death date is not in the cohort, and their index-date
-- granularity is not a delivered granularity.
SELECT cohortn,
       win_granularity,
       COUNT(*)                                                              AS n_pts,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (PARTITION BY cohortn), 2) AS pct
FROM (
    SELECT 1 AS cohortn,
           CASE WHEN p.hspcdate IS NULL
                THEN COALESCE(p.metastaticdiagnosisdategranularity, '<NULL>')
                -- Equal dates: neither component 'wins', so report the pair. A tie
                -- whose two granularities differ is the only ambiguous case and is
                -- broken out rather than silently assigned to one side.
                WHEN p.metastaticdiagnosisdate = p.hspcdate
                 AND COALESCE(p.metastaticdiagnosisdategranularity,'x')
                   = COALESCE(p.hspcdategranularity,'x')
                THEN COALESCE(p.metastaticdiagnosisdategranularity, '<NULL>')
                WHEN p.metastaticdiagnosisdate = p.hspcdate
                THEN CONCAT('TIE:', COALESCE(p.metastaticdiagnosisdategranularity,'<NULL>'),
                            '/',   COALESCE(p.hspcdategranularity,'<NULL>'))
                WHEN p.metastaticdiagnosisdate > p.hspcdate
                THEN COALESCE(p.metastaticdiagnosisdategranularity, '<NULL>')
                ELSE COALESCE(p.hspcdategranularity,                '<NULL>')
           END AS win_granularity
    FROM t_enh_prostate_2026m06 p
    LEFT JOIN (
        SELECT DISTINCT patientid,
               CASE WHEN LENGTH(dateofdeath) = 7
                         THEN TRY_CAST(CONCAT(dateofdeath, '-15')    AS DATE)
                    WHEN LENGTH(dateofdeath) = 4
                         THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
                    ELSE NULL END                          AS dthdt
        FROM t_mortality_v2_2026m06
    ) d ON d.patientid = p.patientid
    WHERE GREATEST(p.metastaticdiagnosisdate, p.hspcdate)
          BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND (d.dthdt IS NULL
           OR GREATEST(p.metastaticdiagnosisdate, p.hspcdate) <= d.dthdt)
    UNION ALL
    SELECT 2 AS cohortn,
           CASE WHEN p.crpcdate IS NULL
                THEN COALESCE(p.metastaticdiagnosisdategranularity, '<NULL>')
                -- Equal dates: same tie handling as cohort 1 above.
                WHEN p.metastaticdiagnosisdate = p.crpcdate
                 AND COALESCE(p.metastaticdiagnosisdategranularity,'x')
                   = COALESCE(p.crpcdategranularity,'x')
                THEN COALESCE(p.metastaticdiagnosisdategranularity, '<NULL>')
                WHEN p.metastaticdiagnosisdate = p.crpcdate
                THEN CONCAT('TIE:', COALESCE(p.metastaticdiagnosisdategranularity,'<NULL>'),
                            '/',   COALESCE(p.crpcdategranularity,'<NULL>'))
                WHEN p.metastaticdiagnosisdate > p.crpcdate
                THEN COALESCE(p.metastaticdiagnosisdategranularity, '<NULL>')
                ELSE COALESCE(p.crpcdategranularity,                '<NULL>')
           END AS win_granularity
    FROM t_enh_prostate_2026m06 p
    LEFT JOIN (
        SELECT DISTINCT patientid,
               CASE WHEN LENGTH(dateofdeath) = 7
                         THEN TRY_CAST(CONCAT(dateofdeath, '-15')    AS DATE)
                    WHEN LENGTH(dateofdeath) = 4
                         THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
                    ELSE NULL END                          AS dthdt
        FROM t_mortality_v2_2026m06
    ) d ON d.patientid = p.patientid
    WHERE GREATEST(p.metastaticdiagnosisdate, p.crpcdate)
          BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND (d.dthdt IS NULL
           OR GREATEST(p.metastaticdiagnosisdate, p.crpcdate) <= d.dthdt)
) x
GROUP BY cohortn, win_granularity
ORDER BY cohortn, n_pts DESC;
-- Reading it: YEAR on the winning component means INDEXDT is almost certainly
-- 1 January of that year. If YEAR is ~0%, close the row.
-- If the granularity names error, see the file header: DESCRIBE the table and
-- use its names.


-- =============================================================================
-- Does progression get recorded after death or after the last note?
-- =============================================================================
-- WHY IT MATTERS: the build takes PFSDT as recorded, with no clamping and no
-- exclusion. If these counts are zero the row closes with no decision at all.
--
-- THE COMPARATOR IS THE IMPUTED DTHDT, NOT LAST_DAY(DateOfDeath). It used to be
-- the month end because DEATH_DT_preliminary could itself be promoted there;
-- with W2 and W3 withdrawn a month-end comparator now tests against a date the
-- build never produces and understates the count.
-- Comparing against the imputed date is comparing against the value PFSDT is
-- actually checked against.
--
-- CAVEAT, unchanged in substance: DateOfDeath is month/year granular in the
-- source, so the imputed date is the middle of the interval the death really
-- falls in and a progression up to about two weeks past it can still be inside
-- the death month. Treat a small non-zero count as "check the individual rows",
-- not as proof.
-- The evidence filter matches the build: any flag except pseudo-progression.
WITH prog AS (
    SELECT patientid, progressiondate, lastclinicnotedate
    FROM t_enh_prostate_prog_scled_2026m06
    WHERE progressiondate IS NOT NULL
      AND (   LOWER(isradiographicevidence)    = 'true'
           OR LOWER(ispathologicevidence)      = 'true'
           OR LOWER(ismixedresponsementioned)  = 'true'
           OR LOWER(isphysicalexamevidence)    = 'true'
           OR LOWER(istumormarkerevidence)     = 'true'
           OR LOWER(ispsaincreased)            = 'true')
)
SELECT
    COUNT(*)                                                            AS n_qualifying_prog_rows,
    COUNT(DISTINCT p.patientid)                                         AS n_pts,
    SUM(CASE WHEN p.lastclinicnotedate IS NOT NULL
              AND p.progressiondate > p.lastclinicnotedate
             THEN 1 ELSE 0 END)                                         AS n_after_last_note,
    SUM(CASE WHEN d.dthdt IS NOT NULL
              AND p.progressiondate > d.dthdt
             THEN 1 ELSE 0 END)                                         AS n_after_death
FROM prog p
LEFT JOIN (
    SELECT DISTINCT patientid,
           CASE WHEN LENGTH(dateofdeath) = 7
                     THEN TRY_CAST(CONCAT(dateofdeath, '-15')    AS DATE)
                WHEN LENGTH(dateofdeath) = 4
                     THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
                ELSE NULL END                          AS dthdt
    FROM t_mortality_v2_2026m06
) d ON d.patientid = p.patientid;


-- =============================================================================
-- Can the next-treatment date fall on or before the index date?
-- =============================================================================
-- WHY IT MATTERS: TTNT takes the next line's start date with no requirement
-- that it be after index. Because NEW_LOT_N is ordered by startdate, line n+1
-- can only precede line n if the two share a start date - which is also the
-- tie condition. A zero here closes it.
WITH lot AS (
    SELECT patientid, linesetting, startdate,
           LEAD(startdate) OVER (PARTITION BY patientid, linesetting
                                 ORDER BY startdate)        AS next_startdate
    FROM t_enh_prostate_lot_2026m06
    WHERE linesetting IN ('mHSPC', 'mCRPC')
)
SELECT
    linesetting,
    COUNT(*)                          AS n_consecutive_pairs_same_or_earlier,
    COUNT(DISTINCT patientid)         AS n_pts
FROM lot
WHERE next_startdate IS NOT NULL
  AND next_startdate <= startdate
GROUP BY linesetting
ORDER BY linesetting;


-- =============================================================================
-- K42b  The cross-setting half, which  above does not cover
-- =============================================================================
-- checks consecutive lines within a setting. Cohort 3 does not use a
-- within-setting pair: its next treatment is
--
--     min(mHSPC LOT2 start, mCRPC LOT1 start)
--
-- so the chronology that matters there is mHSPC LOT1 against mCRPC LOT1 - two
-- different settings, which LEAD() over a setting partition can never see.
-- That is why  was reopened: the row was closed on evidence that did not
-- test the case it was about.
--
-- WHY IT MATTERS. Cohort 3's index date is the mHSPC LOT1 start. If a patient's
-- first mCRPC line begins on or before it, TTNT is zero or negative months for
-- that patient, and nothing downstream rejects it.
--
-- The population is the delivered cohort 3, not every patient with an mHSPC
-- line: both the line start and the mHSPC milestone must fall in the index
-- window, and the line must not start after the patient's death date, exactly
-- as 01_studypop.R requires.
--
-- PASS: n_le = 0; that closes it on evidence that tests the case.
-- Read n_before and n_same separately - a same-day start gives TTNT of one day,
-- which is degenerate rather than impossible, and is the milder finding.
WITH lot AS (
    SELECT patientid, linesetting, startdate,
           ROW_NUMBER() OVER (PARTITION BY patientid, linesetting
                              ORDER BY startdate) AS new_lot_n
    FROM   t_enh_prostate_lot_2026m06
    WHERE  linesetting IN ('mHSPC', 'mCRPC')
),
ms AS (
    -- dthdt rides along with the milestone, so coh3 applies the death exclusion
    -- from this one join (see header).
    SELECT p.patientid,
           GREATEST(p.metastaticdiagnosisdate, p.hspcdate) AS mhspcdd,
           d.dthdt
    FROM   t_enh_prostate_2026m06 p
    LEFT JOIN (
        SELECT DISTINCT patientid,
               CASE WHEN LENGTH(dateofdeath) = 7
                         THEN TRY_CAST(CONCAT(dateofdeath, '-15')    AS DATE)
                    WHEN LENGTH(dateofdeath) = 4
                         THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
                    ELSE NULL END                          AS dthdt
        FROM t_mortality_v2_2026m06
    ) d ON d.patientid = p.patientid
),
coh3 AS (                                   -- the delivered L1+ treated mHSPC
    SELECT l.patientid, l.startdate AS indexdt
    FROM   lot l
    JOIN   ms  m ON m.patientid = l.patientid
    WHERE  l.linesetting = 'mHSPC'
      AND  l.new_lot_n   = 1
      AND  l.startdate BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND  m.mhspcdd   BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND  (m.dthdt IS NULL OR l.startdate <= m.dthdt)
),
-- Not filtered by the ruling: this is the next-treatment date, a source fact about
-- the patient, not a cohort membership. Only coh3 above is.
crpc1 AS (                                  -- their first mCRPC line, if any
    SELECT patientid, startdate AS crpc1_start
    FROM   lot
    WHERE  linesetting = 'mCRPC' AND new_lot_n = 1
)
SELECT
    COUNT(*)                                                  AS n_cohort3,
    SUM(CASE WHEN c.crpc1_start IS NOT NULL THEN 1 ELSE 0 END) AS n_with_mcrpc_l1,
    SUM(CASE WHEN c.crpc1_start <= k.indexdt THEN 1 ELSE 0 END) AS n_le,
    SUM(CASE WHEN c.crpc1_start <  k.indexdt THEN 1 ELSE 0 END) AS n_before,
    SUM(CASE WHEN c.crpc1_start =  k.indexdt THEN 1 ELSE 0 END) AS n_same,
    MIN(DATEDIFF(c.crpc1_start, k.indexdt))                    AS worst_gap_days
FROM       coh3  k
LEFT JOIN  crpc1 c ON c.patientid = k.patientid;


-- =============================================================================
-- How often does the index LINE start before the MILESTONE it is joined to?
-- =============================================================================
-- WHY IT MATTERS: the cohort join matches on patientid only and enforces no
-- chronology, so a patient can be indexed on an mCRPC line that started before
-- they were mCRPC. This sizes it before the SME is asked to rule.
--
-- n_pts_in_cohort is a delivered cohort size and pct is a share of it, so the
-- per-cohort death exclusion applies here too - without it the denominator
-- and the percentage both describe a population larger than the one that
-- ships. Per cohort, not per patient: a patient can be counted in cohort 4 and
-- dropped from cohort 6 by the same predicate.
WITH lot AS (
    SELECT patientid, linesetting, startdate,
           ROW_NUMBER() OVER (PARTITION BY patientid, linesetting
                              ORDER BY startdate)           AS new_lot_n
    FROM t_enh_prostate_lot_2026m06
    WHERE linesetting IN ('mHSPC', 'mCRPC')
),
ms AS (
    -- dthdt rides along with the milestones for the death exclusion in the WHERE
    -- clause below (see header).
    SELECT p.patientid,
           GREATEST(p.metastaticdiagnosisdate, p.hspcdate) AS mhspcdd,
           GREATEST(p.metastaticdiagnosisdate, p.crpcdate) AS mcrpcdd,
           d.dthdt
    FROM t_enh_prostate_2026m06 p
    LEFT JOIN (
        SELECT DISTINCT patientid,
               CASE WHEN LENGTH(dateofdeath) = 7
                         THEN TRY_CAST(CONCAT(dateofdeath, '-15')    AS DATE)
                    WHEN LENGTH(dateofdeath) = 4
                         THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
                    ELSE NULL END                          AS dthdt
        FROM t_mortality_v2_2026m06
    ) d ON d.patientid = p.patientid
)
SELECT
    CASE WHEN l.linesetting = 'mHSPC' AND l.new_lot_n = 1 THEN '3 L1+ mHSPC'
         WHEN l.linesetting = 'mCRPC' AND l.new_lot_n = 1 THEN '4 L1+ mCRPC'
         WHEN l.linesetting = 'mCRPC' AND l.new_lot_n = 2 THEN '5 L2+ mCRPC'
         WHEN l.linesetting = 'mCRPC' AND l.new_lot_n = 3 THEN '6 L3+ mCRPC'
         WHEN l.linesetting = 'mCRPC' AND l.new_lot_n = 4 THEN '7 L4+ mCRPC'
    END                                                     AS cohort,
    COUNT(DISTINCT l.patientid)                             AS n_pts_in_cohort,
    COUNT(DISTINCT CASE
        WHEN (l.linesetting = 'mHSPC' AND l.startdate < m.mhspcdd)
          OR (l.linesetting = 'mCRPC' AND l.startdate < m.mcrpcdd)
        THEN l.patientid END)                               AS n_pts_line_before_milestone,
    ROUND(100.0 * COUNT(DISTINCT CASE
        WHEN (l.linesetting = 'mHSPC' AND l.startdate < m.mhspcdd)
          OR (l.linesetting = 'mCRPC' AND l.startdate < m.mcrpcdd)
        THEN l.patientid END) / NULLIF(COUNT(DISTINCT l.patientid), 0), 1) AS pct
FROM lot l
JOIN ms  m ON m.patientid = l.patientid
WHERE l.startdate BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
  AND (   (l.linesetting = 'mHSPC' AND m.mhspcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30')
       OR (l.linesetting = 'mCRPC' AND m.mcrpcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'))
  AND (   (l.linesetting = 'mHSPC' AND l.new_lot_n = 1)
       OR (l.linesetting = 'mCRPC' AND l.new_lot_n BETWEEN 1 AND 4))
  AND (m.dthdt IS NULL OR l.startdate <= m.dthdt)
GROUP BY 1
ORDER BY 1;
