# =============================================================================
# Column contract check
# =============================================================================
#   Rscript validation/04_column_contract_check.R
#
# Compares the delivered table against validation/00_column_contract.csv: same
# columns, same order, nothing extra, nothing missing.
#
# The contract is maintained by hand from the program specification. It is not
# generated from the code, on purpose - a contract generated from the thing it
# checks would agree with any mistake.
# =============================================================================

suppressPackageStartupMessages({
  library(DBI)
  library(odbc)
})

# No argument: check the table the current panel builds, the same way
# 00_setup.R names it - a talapro2 run must not contract-check the governed
# table and call it evidence. An explicit table name still overrides.
args <- commandArgs(trailingOnly = TRUE)
if (length(args) >= 1L) {
  ads_table <- args[[1]]
} else {
  hrr_panel_mode <- Sys.getenv("RDAP_HRR_PANEL", unset = "flatiron_all")
  if (!hrr_panel_mode %in% c("flatiron_all", "olaparib_label", "talapro2")) {
    stop("RDAP_HRR_PANEL must be 'flatiron_all', 'olaparib_label' or ",
         "'talapro2', got: ", hrr_panel_mode, call. = FALSE)
  }
  ads_table <- paste0("rwdp_pros_pano_2026m06",
                      if (identical(hrr_panel_mode, "flatiron_all")) ""
                      else paste0("_hrr_", hrr_panel_mode))
  cat("no table argument - checking ", ads_table,
      " (RDAP_HRR_PANEL = ", hrr_panel_mode, ")\n", sep = "")
}

CONTRACT <- "validation/00_column_contract.csv"

# The 202606 spec strikes these out, and 202603 emitted several of them. The
# build selects against an explicit allowlist so none can reappear by accident,
# but "cannot happen by construction" is the claim this check exists to test.
STRUCK_OUT <- c("trtdis", "ttd", "ttntfl", "tsstfl", "tsst",
                "pinddur", "pfudur", "birthsex", "advanceddiagnosisdate")

# -----------------------------------------------------------------------------
# Connect exactly the way the build script does, so this checks the table the
# build actually wrote rather than one reachable by some other route.
# -----------------------------------------------------------------------------
source('/mnt/code/intake/oncology/prostrate/202606/code/01_project_necessities/001_setup.R')
source('/mnt/code/intake/oncology/prostrate/202606/code/01_project_necessities/002_helper_functions.R')
source('/mnt/code/intake/oncology/prostrate/202606/code/helperScripts/databases/personalSchemaFunctions.R')

con <- connect()
on.exit(try(DBI::dbDisconnect(con), silent = TRUE), add = TRUE)

# Resolve the target the way the build resolves it, not the way the site helper
# does. 00_setup.R sets personal_schema explicitly and sets the catalog on its
# own connection; taking 001_setup.R's value here would let this script check a
# different table from the one that was written and still report PASS - the one
# failure mode a contract checker must not have.
output_catalog  <- "hive_metastore"
personal_schema <- "osk02156"
tryCatch(DBI::dbExecute(con, paste0("USE CATALOG ", output_catalog)),
         error = function(e)
           stop("could not set catalog to ", output_catalog, ": ",
                conditionMessage(e),
                "\nRefusing to check - this would read from an unknown catalog.",
                call. = FALSE))
cat("checking  :", output_catalog, ".", personal_schema, ".", ads_table, "\n", sep = "")

# dbListFields is the portable route, but ODBC drivers vary in how they handle a
# qualified Id(). A zero-row SELECT gets the same answer through the query path,
# in the same order, from any driver - so fall back rather than fail.
delivered <- tryCatch(
  DBI::dbListFields(con, DBI::Id(schema = personal_schema, table = ads_table)),
  error = function(e) {
    message("dbListFields failed (", conditionMessage(e),
            "); falling back to a zero-row SELECT")
    names(DBI::dbGetQuery(con, sprintf("SELECT * FROM %s.%s LIMIT 0",
                                       personal_schema, ads_table)))
  })

if (!length(delivered)) {
  stop("could not read a column list for ", personal_schema, ".", ads_table,
       " - the table may not exist. Treat the run as failed and do not let ",
       "consumers read it.", call. = FALSE)
}
delivered <- tolower(delivered)

want <- utils::read.csv(CONTRACT, stringsAsFactors = FALSE)
want <- want[order(want$ordinal), ]
expected <- tolower(want$column)

cat("contract :", CONTRACT, "-", length(expected), "columns\n")
cat("delivered:", length(delivered), "columns\n\n")

ok <- TRUE

# --- V27: exact names, exact order -------------------------------------------
if (identical(delivered, expected)) {
  cat("V27 PASS  delivered columns match the contract exactly (name and order)\n")
} else {
  ok <- FALSE
  missing <- setdiff(expected, delivered)
  extra   <- setdiff(delivered, expected)
  cat("V27 FAIL  delivered columns do not match the contract\n")
  if (length(missing)) cat("          missing   :", paste(missing, collapse = ", "), "\n")
  if (length(extra))   cat("          unexpected:", paste(extra,   collapse = ", "), "\n")
  if (!length(missing) && !length(extra)) {
    # Same set, wrong order. Report the positions: a positional read of the
    # ADS by any downstream consumer silently takes the wrong column.
    n <- min(length(delivered), length(expected))
    bad <- which(delivered[seq_len(n)] != expected[seq_len(n)])
    cat("          same columns, WRONG ORDER. First divergence at position ",
        bad[1], ": expected '", expected[bad[1]], "', got '", delivered[bad[1]],
        "'. ", length(bad), " positions differ.\n", sep = "")
  }
}

# --- V21: struck-out variables absent ----------------------------------------
found <- intersect(STRUCK_OUT, delivered)
if (!length(found)) {
  cat("V21 PASS  no struck-out 202606 variable was emitted\n")
} else {
  ok <- FALSE
  cat("V21 FAIL  struck-out variables present:", paste(found, collapse = ", "), "\n")
}

cat("\n", if (ok) "PASS" else "FAIL", "\n", sep = "")
quit(status = if (ok) 0L else 1L)
