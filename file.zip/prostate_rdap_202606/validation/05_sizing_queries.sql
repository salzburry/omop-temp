-- =============================================================================
-- Sizing queries for open register rows that must be counted
-- before anyone can rule on them
-- =============================================================================
--   S1  Q58   labs + BP: "Missing" vs "Unknown" when every record is post-index
--   S2  Q63   labs: does "testdate is not missing" mean the RAW or DERIVED date?
--   S3  Q59   PSA50: is the PSABL > 0 guard ever load-bearing?
--   S4  Q56   ECOG: how much does the [INDEX-30, INDEX+7] window cost cohorts 3-7?
--   S5  Q57   DTHFUFL: the four-way split of its two preliminary input dates
--   S6  Q73   lines that exist with no LINENAME
--
-- S1-S4 read the source tables and rebuild the cohort rows themselves, so they
-- predict what a build should produce. They cannot confirm what one did - they
-- return the same numbers whether a ruling shipped, shipped backwards, or did
-- not ship. Delivered-side confirmation lives in qc/, and for Q58 specifically
-- in qc/05 C12a-C12j.
--
-- S5 is the exception: it reads the delivered ADS, because DEATH_DT_preliminary
-- and FU_ENDDT_preliminary are output columns.
--
-- REBUILDING THE COHORT ROWS MEANS REPRODUCING THE DEATH EXCLUSION. Under the
-- 2026-09-11 study-team ruling (register Q82) a patient whose index date for a
-- cohort falls after their death date is excluded from that cohort, so the ms
-- CTE below carries the patient-level imputed death date and every index
-- branch tests its own index date against it. Without that predicate every
-- count here over-states the delivered population. The test is strict - an
-- index ON the death date is kept, only a strictly later one is dropped - and a
-- patient with no death date is never excluded, which is why the IS NULL arm is
-- written out instead of being left to a comparison against NULL.
--
-- The imputation is the build's, verbatim (code/modules/01_studypop.R): middle
-- of the month for 'YYYY-MM', middle of the year for 'YYYY', NULL for any other
-- length (register Q66, unchanged), TRY_CAST so impossible content nulls rather
-- than raising, and no promotion afterwards - the ruling withdrew all three of
-- the earlier adjustments. The ms block appears FOUR times below (S1, S1b, S3
-- step 2 and S4) and all four must stay identical; validation/05_sizing.R
-- defines it once, so a missed copy here disagrees with the R silently.
--
-- These are descriptive. None of them presumes an answer; each one produces the
-- number that makes the ruling either obvious or unnecessary. Several rows can
-- close with no code change if the count comes back zero.
--
-- Snapshot suffix is _2026m06 throughout (code/modules/00_setup.R: refresh).
-- Index window is [2011-01-01, 2026-04-30] (index_start / index_end).
--
-- GREATEST: Spark's GREATEST ignores NULL arguments and returns NULL
-- only when every argument is NULL. That is the same semantics as the build's
-- pmax(testdate, resultdate, na.rm = TRUE), so the derived lab date below
-- matches what the build computes.
-- =============================================================================

USE CATALOG hive_metastore;
USE SCHEMA  clnprw_flatiron_pano_pros_use;


-- =============================================================================
-- S1  Q58 - labs: how many delivered rows would flip from Missing to Unknown?
-- =============================================================================
-- WHY IT MATTERS: the spec's Missing clause ("no record with testbasename = X
-- is present in t_lab") carries no time qualifier; the build tests for a record
-- only after restricting to labdate <= index_date. A patient whose only
-- neutrophil result is post-index is therefore scored Missing today, but under
-- the spec's literal wording has a record and should read Unknown.
--
-- HOW TO READ IT: n_flip is the number of delivered rows that change label if
-- the Missing test is un-windowed. LAB*V and LAB*DT do not move either way -
-- only the three-way Present/Unknown/Missing flag. If n_flip is ~0 the
-- distinction is academic and Q58 closes with no change.
WITH ms AS (
    -- dthdt rides along with the milestones so that every index branch can
    -- apply the Q82 per-cohort death exclusion from this one join (see header).
    SELECT p.patientid,
           GREATEST(p.metastaticdiagnosisdate, p.hspcdate) AS mhspcdd,
           GREATEST(p.metastaticdiagnosisdate, p.crpcdate) AS mcrpcdd,
           d.dthdt
    FROM t_enh_prostate_2026m06 p
    LEFT JOIN (
        SELECT DISTINCT patientid,
               CASE WHEN LENGTH(dateofdeath) = 7
                         THEN TRY_CAST(CONCAT(dateofdeath, '-15')    AS DATE)
                    WHEN LENGTH(dateofdeath) = 4
                         THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
                    ELSE NULL END                          AS dthdt
        FROM t_mortality_v2_2026m06
    ) d ON d.patientid = p.patientid
),
lot AS (
    SELECT patientid, linesetting, linenumber, startdate,
           ROW_NUMBER() OVER (PARTITION BY patientid, linesetting
                              ORDER BY startdate)           AS new_lot_n
    FROM t_enh_prostate_lot_2026m06
    WHERE linesetting IN ('mHSPC', 'mCRPC')
),
-- One row per delivered (cohort, patient) index row. Each branch carries the
-- Q82 exclusion against its own index date - per cohort, not per patient, so a
-- patient can survive the Overall branches and still be dropped from a line.
idx AS (
    SELECT patientid, '1 Overall mHSPC' AS cohort, mhspcdd AS index_date
    FROM ms WHERE mhspcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND (dthdt IS NULL OR mhspcdd <= dthdt)
    UNION ALL
    SELECT patientid, '2 Overall mCRPC', mcrpcdd
    FROM ms WHERE mcrpcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND (dthdt IS NULL OR mcrpcdd <= dthdt)
    UNION ALL
    SELECT l.patientid,
           CASE WHEN l.linesetting = 'mHSPC' THEN '3 L1+ mHSPC'
                WHEN l.new_lot_n = 1         THEN '4 L1+ mCRPC'
                WHEN l.new_lot_n = 2         THEN '5 L2+ mCRPC'
                WHEN l.new_lot_n = 3         THEN '6 L3+ mCRPC'
                ELSE                              '7 L4+ mCRPC' END,
           l.startdate
    FROM lot l
    JOIN ms  m ON m.patientid = l.patientid
    WHERE l.startdate BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND ((l.linesetting = 'mHSPC' AND l.new_lot_n = 1
            AND m.mhspcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30')
        OR (l.linesetting = 'mCRPC' AND l.new_lot_n BETWEEN 1 AND 4
            AND m.mcrpcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'))
      AND (m.dthdt IS NULL OR l.startdate <= m.dthdt)
),
-- The ten analytes exactly as lab_spec defines them, component filter included.
lab AS (
    SELECT patientid,
           CASE WHEN LOWER(testbasename) = 'neutrophils'                 THEN 'LABNEU'
                WHEN LOWER(testbasename) = 'platelets'                   THEN 'LABPLA'
                WHEN LOWER(testbasename) = 'hemoglobin'                  THEN 'LABHEM'
                WHEN LOWER(testbasename) = 'creatinine'
                     AND labcomponent = 'Creatinine, serum'              THEN 'LABCRE'
                WHEN LOWER(testbasename) = 'bilirubin'                   THEN 'LABBIL'
                WHEN LOWER(testbasename) = 'aspartate aminotransferase'  THEN 'LABAST'
                WHEN LOWER(testbasename) = 'alanine aminotransferase'    THEN 'LABALT'
                WHEN LOWER(testbasename) = 'alkaline phosphatase'        THEN 'LABALP'
                WHEN LOWER(testbasename) = 'albumin'
                     AND labcomponent = 'Albumin, serum'                 THEN 'LABALB'
                WHEN LOWER(testbasename) = 'lymphocytes'                 THEN 'LABLYM'
           END                                          AS analyte,
           GREATEST(testdate, resultdate)               AS labdate
    FROM t_lab_2026m06
),
-- One row per patient per analyte. first_labdate is NULL only when every
-- record for that analyte is undated - which is also a flip, because such a
-- record exists but can never satisfy labdate <= index_date.
pa AS (
    SELECT patientid, analyte,
           MIN(labdate) AS first_labdate,
           COUNT(*)     AS n_records
    FROM lab
    WHERE analyte IS NOT NULL
    GROUP BY patientid, analyte
),
denom AS (SELECT COUNT(*) AS n_index_rows FROM idx)
SELECT
    pa.analyte,
    (SELECT n_index_rows FROM denom)                    AS n_index_rows_all,
    COUNT(*)                                            AS n_index_rows_with_any_record,
    SUM(CASE WHEN pa.first_labdate IS NULL
                  OR pa.first_labdate > i.index_date
             THEN 1 ELSE 0 END)                         AS n_flip_missing_to_unknown,
    SUM(CASE WHEN pa.first_labdate IS NULL
             THEN 1 ELSE 0 END)                         AS n_flip_all_records_undated,
    ROUND(100.0 * SUM(CASE WHEN pa.first_labdate IS NULL
                                OR pa.first_labdate > i.index_date
                           THEN 1 ELSE 0 END)
          / NULLIF((SELECT n_index_rows FROM denom), 0), 3) AS pct_of_all_index_rows
FROM idx i
JOIN pa ON pa.patientid = i.patientid
GROUP BY pa.analyte
ORDER BY n_flip_missing_to_unknown DESC;


-- =============================================================================
-- S1b  Q58 - the same question for BP
-- =============================================================================
-- BP scores Missing when no systolic OR diastolic vitals record exists at all;
-- the build applies testdate <= index_date first, exactly as with the labs.
WITH ms AS (
    -- dthdt rides along with the milestones so that every index branch can
    -- apply the Q82 per-cohort death exclusion from this one join (see header).
    SELECT p.patientid,
           GREATEST(p.metastaticdiagnosisdate, p.hspcdate) AS mhspcdd,
           GREATEST(p.metastaticdiagnosisdate, p.crpcdate) AS mcrpcdd,
           d.dthdt
    FROM t_enh_prostate_2026m06 p
    LEFT JOIN (
        SELECT DISTINCT patientid,
               CASE WHEN LENGTH(dateofdeath) = 7
                         THEN TRY_CAST(CONCAT(dateofdeath, '-15')    AS DATE)
                    WHEN LENGTH(dateofdeath) = 4
                         THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
                    ELSE NULL END                          AS dthdt
        FROM t_mortality_v2_2026m06
    ) d ON d.patientid = p.patientid
),
lot AS (
    SELECT patientid, linesetting, linenumber, startdate,
           ROW_NUMBER() OVER (PARTITION BY patientid, linesetting
                              ORDER BY startdate)           AS new_lot_n
    FROM t_enh_prostate_lot_2026m06
    WHERE linesetting IN ('mHSPC', 'mCRPC')
),
-- One row per delivered (cohort, patient) index row. Each branch carries the
-- Q82 exclusion against its own index date - per cohort, not per patient, so a
-- patient can survive the Overall branches and still be dropped from a line.
idx AS (
    SELECT patientid, '1 Overall mHSPC' AS cohort, mhspcdd AS index_date
    FROM ms WHERE mhspcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND (dthdt IS NULL OR mhspcdd <= dthdt)
    UNION ALL
    SELECT patientid, '2 Overall mCRPC', mcrpcdd
    FROM ms WHERE mcrpcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND (dthdt IS NULL OR mcrpcdd <= dthdt)
    UNION ALL
    SELECT l.patientid,
           CASE WHEN l.linesetting = 'mHSPC' THEN '3 L1+ mHSPC'
                WHEN l.new_lot_n = 1         THEN '4 L1+ mCRPC'
                WHEN l.new_lot_n = 2         THEN '5 L2+ mCRPC'
                WHEN l.new_lot_n = 3         THEN '6 L3+ mCRPC'
                ELSE                              '7 L4+ mCRPC' END,
           l.startdate
    FROM lot l
    JOIN ms  m ON m.patientid = l.patientid
    WHERE l.startdate BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND ((l.linesetting = 'mHSPC' AND l.new_lot_n = 1
            AND m.mhspcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30')
        OR (l.linesetting = 'mCRPC' AND l.new_lot_n BETWEEN 1 AND 4
            AND m.mcrpcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'))
      AND (m.dthdt IS NULL OR l.startdate <= m.dthdt)
),
bp AS (
    SELECT patientid, MIN(testdate) AS first_bpdate, COUNT(*) AS n_records
    FROM t_vitals_2026m06
    WHERE LOWER(test) IN ('systolic blood pressure', 'diastolic blood pressure')
    GROUP BY patientid
)
SELECT
    'BP'                                                AS variable,
    (SELECT COUNT(*) FROM idx)                          AS n_index_rows_all,
    COUNT(*)                                            AS n_index_rows_with_any_record,
    SUM(CASE WHEN bp.first_bpdate IS NULL
                  OR bp.first_bpdate > i.index_date
             THEN 1 ELSE 0 END)                         AS n_flip_missing_to_unknown
FROM idx i
JOIN bp ON bp.patientid = i.patientid;


-- =============================================================================
-- S2  Q63 - labs: raw testdate or derived max(testdate, resultdate)?
-- =============================================================================
-- Step 1, and it may be the only step. The reading matters only for rows where
-- testdate is null but resultdate is populated. If this returns nothing, Q63
-- closes with no code change and no argument about interpretation.
SELECT
    CASE WHEN LOWER(testbasename) = 'neutrophils'                 THEN 'LABNEU'
         WHEN LOWER(testbasename) = 'platelets'                   THEN 'LABPLA'
         WHEN LOWER(testbasename) = 'hemoglobin'                  THEN 'LABHEM'
         WHEN LOWER(testbasename) = 'creatinine'
              AND labcomponent = 'Creatinine, serum'              THEN 'LABCRE'
         WHEN LOWER(testbasename) = 'bilirubin'                   THEN 'LABBIL'
         WHEN LOWER(testbasename) = 'aspartate aminotransferase'  THEN 'LABAST'
         WHEN LOWER(testbasename) = 'alanine aminotransferase'    THEN 'LABALT'
         WHEN LOWER(testbasename) = 'alkaline phosphatase'        THEN 'LABALP'
         WHEN LOWER(testbasename) = 'albumin'
              AND labcomponent = 'Albumin, serum'                 THEN 'LABALB'
         WHEN LOWER(testbasename) = 'lymphocytes'                 THEN 'LABLYM'
    END                                                 AS analyte,
    COUNT(*)                                            AS n_rows_testdate_null_resultdate_present,
    COUNT(DISTINCT patientid)                           AS n_patients,
    SUM(CASE WHEN testresultcleaned > 0 THEN 1 ELSE 0 END) AS n_rows_also_value_positive
FROM t_lab_2026m06
WHERE testdate IS NULL
  AND resultdate IS NOT NULL
GROUP BY 1
HAVING analyte IS NOT NULL
ORDER BY n_rows_testdate_null_resultdate_present DESC;


-- =============================================================================
-- S3  Q59 - is the PSABL > 0 guard ever load-bearing?
-- =============================================================================
-- Step 1, and again it may be the only step. PSABL is PSA_INDEX, taken from
-- ScoreSerial. If no PSA record in the whole table is <= 0, the guard can never
-- fire and Q59 closes as a free defensive condition.
SELECT
    COUNT(*)                                                     AS n_psa_rows,
    SUM(CASE WHEN scoreserial IS NULL  THEN 1 ELSE 0 END)        AS n_null,
    SUM(CASE WHEN scoreserial =  0     THEN 1 ELSE 0 END)        AS n_zero,
    SUM(CASE WHEN scoreserial <  0     THEN 1 ELSE 0 END)        AS n_negative,
    COUNT(DISTINCT CASE WHEN scoreserial <= 0 THEN patientid END) AS n_patients_le_zero,
    MIN(scoreserial)                                             AS min_scoreserial
FROM t_enh_prostate_psa_2026m06;

-- Step 2 - run this only if step 1 shows scoreserial <= 0 somewhere.
-- Reproduces PSA_INDEX exactly (earliest ScoreSerial in [INDEX-14, INDEX], max
-- value on that earliest date) and counts the delivered rows whose PSABL is
-- <= 0, i.e. the rows where the guard actually changes PSA50_6MO / PSA50_12MO
-- from a computed answer to a forced 'N'.
WITH ms AS (
    -- dthdt rides along with the milestones so that every index branch can
    -- apply the Q82 per-cohort death exclusion from this one join (see header).
    SELECT p.patientid,
           GREATEST(p.metastaticdiagnosisdate, p.hspcdate) AS mhspcdd,
           GREATEST(p.metastaticdiagnosisdate, p.crpcdate) AS mcrpcdd,
           d.dthdt
    FROM t_enh_prostate_2026m06 p
    LEFT JOIN (
        SELECT DISTINCT patientid,
               CASE WHEN LENGTH(dateofdeath) = 7
                         THEN TRY_CAST(CONCAT(dateofdeath, '-15')    AS DATE)
                    WHEN LENGTH(dateofdeath) = 4
                         THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
                    ELSE NULL END                          AS dthdt
        FROM t_mortality_v2_2026m06
    ) d ON d.patientid = p.patientid
),
lot AS (
    SELECT patientid, linesetting, linenumber, startdate,
           ROW_NUMBER() OVER (PARTITION BY patientid, linesetting
                              ORDER BY startdate)           AS new_lot_n
    FROM t_enh_prostate_lot_2026m06
    WHERE linesetting IN ('mHSPC', 'mCRPC')
),
-- One row per delivered (cohort, patient) index row. Each branch carries the
-- Q82 exclusion against its own index date - per cohort, not per patient, so a
-- patient can survive the Overall branches and still be dropped from a line.
idx AS (
    SELECT patientid, '1 Overall mHSPC' AS cohort, mhspcdd AS index_date
    FROM ms WHERE mhspcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND (dthdt IS NULL OR mhspcdd <= dthdt)
    UNION ALL
    SELECT patientid, '2 Overall mCRPC', mcrpcdd
    FROM ms WHERE mcrpcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND (dthdt IS NULL OR mcrpcdd <= dthdt)
    UNION ALL
    SELECT l.patientid,
           CASE WHEN l.linesetting = 'mHSPC' THEN '3 L1+ mHSPC'
                WHEN l.new_lot_n = 1         THEN '4 L1+ mCRPC'
                WHEN l.new_lot_n = 2         THEN '5 L2+ mCRPC'
                WHEN l.new_lot_n = 3         THEN '6 L3+ mCRPC'
                ELSE                              '7 L4+ mCRPC' END,
           l.startdate
    FROM lot l
    JOIN ms  m ON m.patientid = l.patientid
    WHERE l.startdate BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND ((l.linesetting = 'mHSPC' AND l.new_lot_n = 1
            AND m.mhspcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30')
        OR (l.linesetting = 'mCRPC' AND l.new_lot_n BETWEEN 1 AND 4
            AND m.mcrpcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'))
      AND (m.dthdt IS NULL OR l.startdate <= m.dthdt)
),
win AS (
    SELECT i.cohort, i.patientid, i.index_date, p.resultdate, p.scoreserial
    FROM idx i
    JOIN t_enh_prostate_psa_2026m06 p ON p.patientid = i.patientid
    WHERE p.resultdate BETWEEN DATE_SUB(i.index_date, 14) AND i.index_date
),
first_dt AS (
    SELECT cohort, patientid, index_date, MIN(resultdate) AS psa_dt
    FROM win GROUP BY cohort, patientid, index_date
),
psabl AS (
    SELECT w.cohort, w.patientid, w.index_date, MAX(w.scoreserial) AS psabl
    FROM win w
    JOIN first_dt f
      ON f.cohort = w.cohort AND f.patientid = w.patientid
     AND f.index_date = w.index_date AND f.psa_dt = w.resultdate
    GROUP BY w.cohort, w.patientid, w.index_date
)
SELECT
    cohort,
    COUNT(*)                                                AS n_rows_with_psabl,
    SUM(CASE WHEN psabl <= 0 THEN 1 ELSE 0 END)             AS n_psabl_le_zero,
    SUM(CASE WHEN psabl =  0 THEN 1 ELSE 0 END)             AS n_psabl_zero,
    SUM(CASE WHEN psabl <  0 THEN 1 ELSE 0 END)             AS n_psabl_negative
FROM psabl
GROUP BY cohort
ORDER BY cohort;


-- =============================================================================
-- S4  Q56 - what does the [INDEX-30, INDEX+7] ECOG window cost cohorts 3-7?
-- =============================================================================
-- WHY IT MATTERS: the window applies to all seven cohorts because 3.Data Prep
-- defines LOT_ECOG that way for the single ECOG row. The old rule matched
-- Flatiron's baseline ECOG for cohorts 3-7 on line number and line start date
-- with no date bound, so a baseline assessment recorded months before the line
-- still counted; under the window every such row reads Unknown/Missing
-- (ECOGN = 6).
--
-- HOW TO READ IT: n_lost is the number of delivered rows that have a baseline
-- ECOG under the old rule and none under the new one. pct_lost is the headline
-- for the ECOG completeness change in cohorts 3-7.
WITH ms AS (
    -- dthdt rides along with the milestones so that every index branch can
    -- apply the Q82 per-cohort death exclusion from this one join (see header).
    SELECT p.patientid,
           GREATEST(p.metastaticdiagnosisdate, p.hspcdate) AS mhspcdd,
           GREATEST(p.metastaticdiagnosisdate, p.crpcdate) AS mcrpcdd,
           d.dthdt
    FROM t_enh_prostate_2026m06 p
    LEFT JOIN (
        SELECT DISTINCT patientid,
               CASE WHEN LENGTH(dateofdeath) = 7
                         THEN TRY_CAST(CONCAT(dateofdeath, '-15')    AS DATE)
                    WHEN LENGTH(dateofdeath) = 4
                         THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
                    ELSE NULL END                          AS dthdt
        FROM t_mortality_v2_2026m06
    ) d ON d.patientid = p.patientid
),
lot AS (
    SELECT patientid, linesetting, linenumber, startdate,
           ROW_NUMBER() OVER (PARTITION BY patientid, linesetting
                              ORDER BY startdate)           AS new_lot_n
    FROM t_enh_prostate_lot_2026m06
    WHERE linesetting IN ('mHSPC', 'mCRPC')
),
-- cohorts 3-7 only, carrying the line identity the ECOG match needs. Same Q82
-- exclusion as the idx CTE's third branch, against the line start date.
idx_lot AS (
    SELECT CASE WHEN l.linesetting = 'mHSPC' THEN '3 L1+ mHSPC'
                WHEN l.new_lot_n = 1         THEN '4 L1+ mCRPC'
                WHEN l.new_lot_n = 2         THEN '5 L2+ mCRPC'
                WHEN l.new_lot_n = 3         THEN '6 L3+ mCRPC'
                ELSE                              '7 L4+ mCRPC' END AS cohort,
           l.patientid, l.linenumber,
           l.startdate AS index_date
    FROM lot l
    JOIN ms  m ON m.patientid = l.patientid
    WHERE l.startdate BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND ((l.linesetting = 'mHSPC' AND l.new_lot_n = 1
            AND m.mhspcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30')
        OR (l.linesetting = 'mCRPC' AND l.new_lot_n BETWEEN 1 AND 4
            AND m.mcrpcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'))
      AND (m.dthdt IS NULL OR l.startdate <= m.dthdt)
),
matched AS (
    SELECT i.cohort, i.patientid, i.index_date, e.ecogdate,
           DATEDIFF(e.ecogdate, i.index_date) AS gap_days
    FROM idx_lot i
    JOIN t_enh_prostate_bsln_ecog_2026m06 e
      ON e.patientid     = i.patientid
     AND e.linenumber    = i.linenumber
     AND e.linestartdate = i.index_date
),
per_row AS (
    SELECT cohort, patientid, index_date,
           MAX(CASE WHEN gap_days BETWEEN -30 AND 7 THEN 1 ELSE 0 END) AS in_window,
           MIN(gap_days) AS earliest_gap,
           MAX(gap_days) AS latest_gap
    FROM matched
    GROUP BY cohort, patientid, index_date
)
SELECT
    cohort,
    COUNT(*)                                            AS n_rows_with_baseline_ecog_old_rule,
    SUM(in_window)                                      AS n_rows_kept_new_rule,
    SUM(1 - in_window)                                  AS n_lost,
    ROUND(100.0 * SUM(1 - in_window) / NULLIF(COUNT(*), 0), 1) AS pct_lost,
    -- where the lost assessments sit relative to index, to show whether the
    -- window is discarding stale readings or plausible baselines
    SUM(CASE WHEN in_window = 0 AND latest_gap  <  -30 THEN 1 ELSE 0 END) AS n_lost_all_before_minus30,
    SUM(CASE WHEN in_window = 0 AND earliest_gap >    7 THEN 1 ELSE 0 END) AS n_lost_all_after_plus7,
    MIN(earliest_gap)                                   AS min_gap_days,
    MAX(latest_gap)                                     AS max_gap_days
FROM per_row
GROUP BY cohort
ORDER BY cohort;


-- =============================================================================
-- S5  Q57 - the four-way split of the DTHFUFL inputs
-- =============================================================================
-- WHY IT MATTERS: DTHFUFL is computed from DEATH_DT_preliminary and
-- FU_ENDDT_preliminary. The spec's Values list is "0 = No; 1 = Yes" with
-- "else 0" and defines no third state, so every row must land on 0 or 1 unless
-- there is no death date at all. This query sizes each of the four input
-- combinations so that rule is checked against a population rather than
-- assumed.
--
-- HOW TO READ IT
--   both present      -> DTHFUFL is 0 or 1 by the arithmetic
--   death, no FU end  -> DATEDIFF is NULL, NULL <= 120 is NULL, ELSE gives 0.
--                        The Q57 ruling (ruled 2026-08-08) did not cover this
--                        row; the spec defines no third state, so it scores 0
--                        rather than NULL. If this count is non-zero, the
--                        owner should confirm that scoring them 0 is wanted.
--   no death          -> DTHFUFL is NULL - the only null case (register Q57).
--   neither           -> also NULL, same rule.
--
-- Run this against the delivered ADS, not the source: the preliminary dates are
-- delivered columns, so this is a post-build query. Substitute ${schema} and
-- ${ads}.
SELECT
    CASE WHEN death_dt_preliminary IS NOT NULL
          AND fu_enddt_preliminary IS NOT NULL THEN '1 both present'
         WHEN death_dt_preliminary IS NOT NULL THEN '2 death, no FU end'
         WHEN fu_enddt_preliminary IS NOT NULL THEN '3 FU end, no death'
         ELSE                                       '4 neither' END AS inputs,
    COUNT(*)                                                   AS n_rows,
    COUNT(DISTINCT patid)                                      AS n_patients,
    SUM(CASE WHEN dthfufl IS NULL THEN 1 ELSE 0 END)           AS n_dthfufl_null,
    SUM(CASE WHEN dthfufl = 0    THEN 1 ELSE 0 END)            AS n_dthfufl_0,
    SUM(CASE WHEN dthfufl = 1    THEN 1 ELSE 0 END)            AS n_dthfufl_1,
    SUM(CASE WHEN dthfufl IS NOT NULL AND dthfufl NOT IN (0,1)
             THEN 1 ELSE 0 END)                                AS n_out_of_domain
FROM ${schema}.${ads}
GROUP BY 1
ORDER BY 1;


-- =============================================================================
-- S6  Q73 - lines that exist with no LINENAME
-- =============================================================================
-- Q64 settled the line that does not exist: NULL name, category 17 "No
-- treatment". A line that does exist with a null name lands in the same place,
-- so a patient in a treated cohort can read "No treatment". The owner ruled to
-- size it before deciding.
--
-- qc/03 R55 counts the delivered contradiction. This counts the source
-- population, which is the number that decides what to do:
--   zero            close Q73, no change, re-run at each refresh
--   small           map to category 16, or gate it - either is cheap
--   large           the source has a real gap and the fix is upstream
--
-- Reads source only, so it is valid before a build as well as after.
SELECT
    linesetting,
    COUNT(*)                                                    AS n_lines,
    COUNT(DISTINCT patientid)                                   AS n_patients,
    SUM(CASE WHEN linename IS NULL THEN 1 ELSE 0 END)           AS n_null_name,
    SUM(CASE WHEN linename IS NOT NULL AND TRIM(linename) = ''
             THEN 1 ELSE 0 END)                                 AS n_blank_name,
    COUNT(DISTINCT CASE WHEN linename IS NULL
                          OR TRIM(linename) = '' THEN patientid END) AS n_patients_affected
FROM   t_enh_prostate_lot_2026m06
WHERE  linesetting IN ('mHSPC', 'mCRPC')
GROUP  BY linesetting
ORDER  BY linesetting;

-- A blank string is the same problem in a different shape: it is not NULL,
-- so lotcat_expr's `linename IS NULL` branch misses it and it falls to category
-- 16 "Any other therapy" instead. Two source shapes, two different delivered
-- answers, neither of them a real treatment. Count both.

-- =============================================================================
-- S7 / Q25. Is the DELIVERED albumin value clinically plausible?
-- =============================================================================
-- Q25 settled the UNIT, not the values. C10c put 99.91% of source rows in the
-- g/L band and the spec's `g/L` label is correct - but the 2026-09-12 run also
-- showed the g/L group reaching 42,010 and 3,878 positive serum-albumin rows
-- falling outside both scale bands, and production admits any positive
-- qualifying result with no range filter (Q68 forbids filtering on value).
--
-- So a delivered LABALBV can be far outside anything physiological and nothing
-- has measured how many. Serum albumin runs about 35-50 g/L; 15-70 is generous
-- on both sides, which is the point - a row outside THAT is not a borderline
-- reading, it is unusable. Below 15 is the g/dL-scale shape: a value near 4
-- that was never rescaled.
--
-- SIZING ONLY, NO ASSERTION. The decision is register Q84 - not Q68, which
-- governs height and weight and says nothing about labs. Q68's reasoning does
-- carry over (a filter on value is one the spec does not authorise), so gating
-- this would pre-empt the ruling rather than implement it. Q84 is unassigned.
-- This is the one item in this file that reads the DELIVERED table; S1-S6 all
-- rebuild from source.
-- =============================================================================
-- Seven-cohort spine: a cohort with NO albumin must report zero, not vanish.
-- n_below_15_other is below 15 but outside the g/dL band too - in no band at
-- all. C10c's g/dL band is 1.5-7.0, so 7-15 is not g/dL-shaped and naming the
-- whole sub-15 group that way overstated it.
SELECT s.cohortn,
       COALESCE(a.n_with_value, 0)     AS n_with_value,
       COALESCE(a.n_plausible, 0)      AS n_plausible,
       COALESCE(a.n_implausible, 0)    AS n_implausible,
       COALESCE(a.n_in_gdl_band, 0)    AS n_in_gdl_band,
       COALESCE(a.n_below_15_other, 0) AS n_below_15_other,
       COALESCE(a.n_above_70, 0)       AS n_above_70,
       a.min_val, a.max_val, a.pct_implausible
FROM   (SELECT explode(array(1,2,3,4,5,6,7)) AS cohortn) s
LEFT   JOIN (
  SELECT cohortn,
         COUNT(*)                                                      AS n_with_value,
         SUM(CASE WHEN labalbv BETWEEN 15 AND 70 THEN 1 ELSE 0 END)    AS n_plausible,
         SUM(CASE WHEN labalbv < 15 OR labalbv > 70 THEN 1 ELSE 0 END) AS n_implausible,
         SUM(CASE WHEN labalbv BETWEEN 1.5 AND 7 THEN 1 ELSE 0 END)    AS n_in_gdl_band,
         SUM(CASE WHEN labalbv > 0 AND labalbv < 15
                       AND NOT (labalbv BETWEEN 1.5 AND 7)
                  THEN 1 ELSE 0 END)                                   AS n_below_15_other,
         SUM(CASE WHEN labalbv > 70 THEN 1 ELSE 0 END)                 AS n_above_70,
         MIN(labalbv)                                                  AS min_val,
         MAX(labalbv)                                                  AS max_val,
         ROUND(100.0 * SUM(CASE WHEN labalbv < 15 OR labalbv > 70
                                THEN 1 ELSE 0 END) / COUNT(*), 4)      AS pct_implausible
  FROM   ${schema}.${ads}
  WHERE  labalbv IS NOT NULL
  GROUP  BY cohortn) a
  ON   a.cohortn = s.cohortn
ORDER  BY s.cohortn;
