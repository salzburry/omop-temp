-- =============================================================================
-- Q83 - WHY do these patients have no activity after their index?
-- =============================================================================
-- READ 11_q83_decision_pack.sql FIRST. That file says how big the problem is.
-- This one asks whether it is a problem about these patients or a problem about
-- the definition, and the answer decides which of Q83's four options is even
-- the right kind of answer.
--
-- WHAT PROMPTED IT. The exposure is confined to cohorts 1 and 2 - 492 and 567
-- rows, with cohorts 3 to 7 reporting nothing at all. That is not luck, and
-- the mechanism is visible in the code:
--
--   fu_enddt_preliminary = pmax(last_visitdate, last_televisitdate,
--                               last_lotenddate, last_oralenddate)
--
-- Four sources, and 5B.ClinChars row 89 lists exactly those four. Cohorts 3-7
-- index on a line-of-therapy START, and that line's END date is one of the
-- four, so their follow-up can never precede their index - it is structurally
-- impossible, not merely unobserved. Cohorts 1 and 2 index on
-- ADVANCEDDIAGNOSISDATE (MHSPCDD / MCRPCDD), which feeds NOTHING in that
-- expression. So the whole of Q83 is patients whose advanced-diagnosis
-- milestone post-dates every visit, telemedicine contact, line-of-therapy end
-- and oral end they have.
--
-- THE QUESTION THAT FOLLOWS. An advanced-diagnosis date is derived from
-- clinical data - a PSA rise, imaging, a recorded progression. Those are
-- records, with dates, in tables this definition does not read. So for each
-- affected patient there are three possible worlds, and they need different
-- fixes:
--
--   (a) NOTHING ANYWHERE. No record in any source after the index. The patient
--       genuinely has no observation time in that cohort. Zero follow-up is
--       then the truth, and the honest dispositions are to exclude them or to
--       null the durations - not to invent a number.
--
--   (b) A RECORD IN A SOURCE 202606 DROPPED. Register Q40: 202603 folded the
--       alpha/beta-emitter and Provenge tables into follow-up and the 202606
--       sheet does not list them. Q40 is RESOLVED as spec-faithful, but its own
--       text asks to "confirm the omission is intended rather than an editing
--       slip" and warns it SHORTENS follow-up. A patient here is not a Q83
--       case at all - they are a Q40 consequence, and the fix is to reopen Q40.
--
--   (c) A RECORD IN A SOURCE NEITHER CUT READ. Labs, PSA, vitals, ECOG,
--       medication administrations, PSMA PET. The patient was observed; the
--       four-source definition simply cannot see it. The fix is then to the
--       follow-up definition, which needs a spec departure - and it is the only
--       fix that makes the data right rather than tidier.
--
-- Ruling on the disposition before knowing this split risks signing a rule for
-- 594 patients when the actual defect is a follow-up definition missing a
-- source, in which case all four of Q83's options are wrong.
--
--     Rscript validation/run_sql.R validation/12_q83_why_no_activity.sql
--
-- Read-only. Reads the delivered table and the source schema together, so it
-- runs after the build and writes nothing.
--
--   ${catalog} = hive_metastore
--   ${schema}  = your personal schema
--   ${ads}     = rwdp_pros_pano_2026m06
--   ${src}     = clnprw_flatiron_pano_pros_use
--
-- ONE ORDERING NOTE. The two tables register Q40 dropped are read in the LAST
-- statement on purpose. They are not part of the 202606 definition, so they may
-- not have been carried into this refresh's schema at all. If that statement
-- errors with a missing table, that is itself the answer to (b) - the source is
-- gone, not merely unread - and every statement before it has already returned.
-- =============================================================================

USE CATALOG ${catalog};

-- ---------------------------------------------------------------------------
-- Q83W.1. IS THE DELIVERED FUED CORRECT?  Settle this before asking anything
-- else, because the rest of the file assumes it.
--
-- Recomputes FU_ENDDT_preliminary for the affected patients straight from the
-- four sources 5B.ClinChars row 89 names, and compares it to what shipped. If
-- these disagree the problem is a derivation bug and Q83's four options are all
-- premature; if they agree - which is what is expected - then the delivered
-- value is a faithful reading of a definition that cannot see these patients,
-- and the question is about the definition.
--
-- GREATEST skips nulls in Spark, matching pmax(..., na.rm = TRUE), so a patient
-- with only one of the four sources still recomputes correctly.
--
-- FUED is patient-level under RP3 - derived once, before any cohort exists - so
-- MAX(fued) over a patient's rows is just that patient's FUED, not an
-- aggregation across differing values. The same is not true of INDEXDT, which
-- is why the first and last affected index dates are carried separately below.
--
-- @assert zero fued_mismatch
-- @assert positive patients_checked
-- ---------------------------------------------------------------------------
WITH affected AS (
  SELECT patid,
         MIN(indexdt) AS first_index,
         MAX(indexdt) AS last_index,
         MAX(fued)    AS fued
  FROM   ${schema}.${ads}
  WHERE  fued < indexdt
  GROUP  BY patid),
recomputed AS (
  SELECT a.patid, a.fued,
         GREATEST(v.d, t.d, l.d, o.d) AS four_source_max
  FROM   affected a
  LEFT JOIN (SELECT patientid, MAX(visitdate) AS d FROM ${src}.t_visit_2026m06
             WHERE patientid IN (SELECT patid FROM affected) GROUP BY patientid) v
         ON v.patientid = a.patid
  LEFT JOIN (SELECT patientid, MAX(visitdate) AS d FROM ${src}.t_telemedicine_2026m06
             WHERE patientid IN (SELECT patid FROM affected) GROUP BY patientid) t
         ON t.patientid = a.patid
  LEFT JOIN (SELECT patientid, MAX(enddate) AS d FROM ${src}.t_enh_prostate_lot_2026m06
             WHERE patientid IN (SELECT patid FROM affected) GROUP BY patientid) l
         ON l.patientid = a.patid
  LEFT JOIN (SELECT patientid, MAX(enddate) AS d FROM ${src}.t_enh_prostate_orals_2026m06
             WHERE patientid IN (SELECT patid FROM affected) GROUP BY patientid) o
         ON o.patientid = a.patid)
SELECT COUNT(*)                                                          AS patients_checked,
       COALESCE(SUM(CASE WHEN fued IS DISTINCT FROM four_source_max
                         THEN 1 ELSE 0 END), 0)                          AS fued_mismatch
FROM   recomputed;

-- ---------------------------------------------------------------------------
-- Q83W.2. THE ANSWER.  For each affected patient, is there a record ANYWHERE
-- after the index date their follow-up precedes?
--
-- Counted against FIRST_INDEX - the earliest index date at which the patient is
-- affected. That is the generous test: a record after the earliest affected
-- index proves the patient was observed within at least one of the cohorts
-- whose follow-up says they were not. Using the latest index instead would
-- undercount real observation.
--
-- Each column is "how many of the affected patients have at least one record in
-- this source strictly after that index date". They overlap; the last column is
-- the one that matters, because it is the patients for whom NO source of any
-- kind shows contact.
--
--   t_lab takes the later of testdate and resultdate, which is how the build
--   itself dates a lab record.
-- ---------------------------------------------------------------------------
WITH affected AS (
  SELECT patid, MIN(indexdt) AS first_index
  FROM   ${schema}.${ads}
  WHERE  fued < indexdt
  GROUP  BY patid),
latest AS (
  SELECT a.patid, a.first_index,
         (SELECT MAX(GREATEST(x.testdate, x.resultdate)) FROM ${src}.t_lab_2026m06 x
          WHERE x.patientid = a.patid)                                   AS lab_dt,
         (SELECT MAX(x.resultdate) FROM ${src}.t_enh_prostate_psa_2026m06 x
          WHERE x.patientid = a.patid)                                   AS psa_dt,
         (SELECT MAX(x.testdate) FROM ${src}.t_vitals_2026m06 x
          WHERE x.patientid = a.patid)                                   AS vitals_dt,
         (SELECT MAX(x.ecogdate) FROM ${src}.t_ecog_2026m06 x
          WHERE x.patientid = a.patid)                                   AS ecog_dt,
         (SELECT MAX(x.administereddate) FROM ${src}.t_medicationadmin_2026m06 x
          WHERE x.patientid = a.patid)                                   AS medadmin_dt,
         (SELECT MAX(x.scandate) FROM ${src}.t_enh_prostate_psmapet_2026m06 x
          WHERE x.patientid = a.patid)                                   AS psmapet_dt,
         -- LASTCLINICNOTEDATE. Added 2026-09-13, and it is the most direct
         -- evidence in the source that a patient was still being seen - it is
         -- the date of the last clinical note, not an inference from one. The
         -- first version of this file omitted it, which understated how many
         -- of the 594 were observed.
         --
         -- It is also not a new source to this product. 05_outcomes.R ALREADY
         -- reads it: rwPFS censors on LASTCLINICNOTEDATE. So the delivered
         -- table already treats it as a valid end-of-observation anchor for
         -- one outcome while FUED - and therefore OS, FUDUR and TTNT - cannot
         -- see it. That inconsistency is internal to the product and does not
         -- need a source argument to justify fixing.
         (SELECT MAX(x.lastclinicnotedate) FROM ${src}.t_enh_prostate_prog_scled_2026m06 x
          WHERE x.patientid = a.patid)                                   AS lastnote_dt
  FROM   affected a)
SELECT COUNT(*)                                                          AS patients_affected,
       COALESCE(SUM(CASE WHEN lab_dt      > first_index THEN 1 ELSE 0 END), 0) AS lab_after_index,
       COALESCE(SUM(CASE WHEN psa_dt      > first_index THEN 1 ELSE 0 END), 0) AS psa_after_index,
       COALESCE(SUM(CASE WHEN vitals_dt   > first_index THEN 1 ELSE 0 END), 0) AS vitals_after_index,
       COALESCE(SUM(CASE WHEN ecog_dt     > first_index THEN 1 ELSE 0 END), 0) AS ecog_after_index,
       COALESCE(SUM(CASE WHEN medadmin_dt > first_index THEN 1 ELSE 0 END), 0) AS medadmin_after_index,
       COALESCE(SUM(CASE WHEN psmapet_dt  > first_index THEN 1 ELSE 0 END), 0) AS psmapet_after_index,
       COALESCE(SUM(CASE WHEN lastnote_dt > first_index THEN 1 ELSE 0 END), 0) AS lastnote_after_index,
       COALESCE(SUM(CASE WHEN GREATEST(lab_dt, psa_dt, vitals_dt, ecog_dt,
                                       medadmin_dt, psmapet_dt, lastnote_dt)
                              > first_index
                         THEN 1 ELSE 0 END), 0)                          AS any_source_after_index,
       COALESCE(SUM(CASE WHEN COALESCE(GREATEST(lab_dt, psa_dt, vitals_dt, ecog_dt,
                                                medadmin_dt, psmapet_dt, lastnote_dt)
                                       > first_index, FALSE)
                         THEN 0 ELSE 1 END), 0)                          AS no_source_after_index
FROM   latest;

-- ---------------------------------------------------------------------------
-- Q83W.3. HOW MUCH observation is being missed, for those who have some.
--
-- A record one day after the index is a different finding from a record three
-- years after it. If the recoverable follow-up is substantial, the four-source
-- definition is not merely narrow for these patients - it is discarding most of
-- what is known about them.
--
-- recoverable_days is measured from the index date to the latest record in any
-- unread source, so it is the follow-up that a wider definition would restore.
-- ---------------------------------------------------------------------------
WITH affected AS (
  SELECT patid, MIN(indexdt) AS first_index
  FROM   ${schema}.${ads}
  WHERE  fued < indexdt
  GROUP  BY patid),
latest AS (
  SELECT a.patid, a.first_index,
         GREATEST(
           (SELECT MAX(GREATEST(x.testdate, x.resultdate)) FROM ${src}.t_lab_2026m06 x
            WHERE x.patientid = a.patid),
           (SELECT MAX(x.resultdate) FROM ${src}.t_enh_prostate_psa_2026m06 x
            WHERE x.patientid = a.patid),
           (SELECT MAX(x.testdate) FROM ${src}.t_vitals_2026m06 x
            WHERE x.patientid = a.patid),
           (SELECT MAX(x.ecogdate) FROM ${src}.t_ecog_2026m06 x
            WHERE x.patientid = a.patid),
           (SELECT MAX(x.administereddate) FROM ${src}.t_medicationadmin_2026m06 x
            WHERE x.patientid = a.patid),
           (SELECT MAX(x.scandate) FROM ${src}.t_enh_prostate_psmapet_2026m06 x
            WHERE x.patientid = a.patid),
           (SELECT MAX(x.lastclinicnotedate)
            FROM ${src}.t_enh_prostate_prog_scled_2026m06 x
            WHERE x.patientid = a.patid))                                AS unread_dt
  FROM   affected a)
SELECT CASE WHEN unread_dt IS NULL OR unread_dt <= first_index
                                               THEN '0. nothing after the index'
            WHEN DATEDIFF(unread_dt, first_index) <=   30 THEN '1. up to a month'
            WHEN DATEDIFF(unread_dt, first_index) <=   90 THEN '2. up to a quarter'
            WHEN DATEDIFF(unread_dt, first_index) <=  365 THEN '3. up to a year'
            WHEN DATEDIFF(unread_dt, first_index) <= 1095 THEN '4. one to three years'
            ELSE                                               '5. over three years'
       END                                                               AS recoverable,
       COUNT(*)                                                          AS patients,
       MIN(DATEDIFF(unread_dt, first_index))                             AS min_days,
       MAX(DATEDIFF(unread_dt, first_index))                             AS max_days
FROM   latest
GROUP  BY 1
ORDER  BY 1;

-- ---------------------------------------------------------------------------
-- Q83W.4. THE TWO SOURCES REGISTER Q40 DROPPED.  Last, because these tables
-- are not part of the 202606 definition and may not exist in this schema - see
-- the ordering note in the header. A missing-table error here IS the answer.
--
-- A patient appearing here was receiving a radioligand or Provenge, which is
-- about as clear a record of being alive and in care as this data holds. If
-- this count is nonzero, those patients are a Q40 consequence rather than a
-- Q83 case, and Q40 should be reopened rather than a Q83 disposition applied
-- on top of it.
-- ---------------------------------------------------------------------------
WITH affected AS (
  SELECT patid, MIN(indexdt) AS first_index
  FROM   ${schema}.${ads}
  WHERE  fued < indexdt
  GROUP  BY patid)
SELECT COUNT(*)                                                          AS patients_affected,
       COALESCE(SUM(CASE WHEN alpha_dt > first_index THEN 1 ELSE 0 END), 0) AS alphabeta_after_index,
       COALESCE(SUM(CASE WHEN prov_dt  > first_index THEN 1 ELSE 0 END), 0) AS provenge_after_index,
       COALESCE(SUM(CASE WHEN GREATEST(alpha_dt, prov_dt) > first_index
                         THEN 1 ELSE 0 END), 0)                          AS either_after_index
FROM  (SELECT a.patid, a.first_index,
              (SELECT MAX(x.administrationdate)
               FROM ${src}.t_enh_prostate_alpbta_emt_2026m06 x
               WHERE x.patientid = a.patid)                              AS alpha_dt,
              (SELECT MAX(x.startdate)
               FROM ${src}.t_enh_prostate_provenge_2026m06 x
               WHERE x.patientid = a.patid)                              AS prov_dt
       FROM   affected a) z;

-- =============================================================================
-- HOW TO READ THE RESULT
-- =============================================================================
--   Q83W.1 mismatch nonzero      Stop. The delivered FUED is not the four-source
--                                maximum, which is a derivation defect and a
--                                different problem from Q83. Nothing below is
--                                meaningful until it is explained.
--
--   no_source_after_index high   World (a). These patients really have no
--                                observation time. Flooring and shipping the
--                                negative are both indefensible; the choice is
--                                between excluding them and nulling the
--                                durations, and exclusion is what a survival
--                                analysis does with zero follow-up anyway.
--
--   any_source_after_index high  World (c). The patients were observed and the
--                                definition cannot see it. No disposition rule
--                                fixes this - only a wider FU_ENDDT_preliminary
--                                does, and that is a departure from
--                                5B.ClinChars row 89 which needs the owner and
--                                the study team, not a disposition ruling.
--                                Q83W.3 says how much follow-up is at stake.
--
--   either_after_index nonzero   World (b). Register Q40, not Q83. Reopen Q40.
--
-- These are not exclusive: a realistic result splits the 594 across all three,
-- and then each group needs its own answer rather than one rule for all of
-- them. That is the point of running this before ruling.
--
-- WITHDRAWN. An earlier version of this block said 874 of the 1,059 rows
-- carry a contradictory ID3MOSFU = 1 and that it needed its own decision
-- whatever was chosen above. That was wrong. 5A.Demos defines ID3MOSFU as
-- "1 if MAXINDEX - INDEXDT >= 91 days" and the build implements exactly that
-- against the study constant 2026-04-30, so it measures POTENTIAL follow-up
-- and never reads FUED, the death date or any activity. There is no
-- contradiction and nothing to rule on.
-- =============================================================================
