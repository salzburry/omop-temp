-- =============================================================================
-- Q83 - WHY do these patients have no activity after their index?
-- =============================================================================
-- READ 11_q83_decision_pack.sql FIRST. That file says how big the problem is.
-- This one asks whether it is a problem about these patients or a problem about
-- the definition, and the answer decides which of Q83's four options is even
-- the right kind of answer.
--
-- WHAT PROMPTED IT. The exposure is confined to cohorts 1 and 2 - 492 and 567
-- rows, with cohorts 3 to 7 reporting nothing at all. That is not luck, and
-- the mechanism is visible in the code:
--
--   fu_enddt_preliminary = pmax(last_visitdate, last_televisitdate,
--                               last_lotenddate, last_oralenddate)
--
-- Four sources, and 5B.ClinChars row 89 lists exactly those four. Cohorts 3-7
-- index on a line-of-therapy START, and that line's END date is one of the
-- four, so their follow-up can never precede their index - it is structurally
-- impossible, not merely unobserved. Cohorts 1 and 2 index on
-- ADVANCEDDIAGNOSISDATE (MHSPCDD / MCRPCDD), which feeds NOTHING in that
-- expression. So the whole of Q83 is patients whose advanced-diagnosis
-- milestone post-dates every visit, telemedicine contact, line-of-therapy end
-- and oral end they have.
--
-- THE QUESTION THAT FOLLOWS. An advanced-diagnosis date is derived from
-- clinical data - a PSA rise, imaging, a recorded progression. Those are
-- records, with dates, in tables this definition does not read. So for each
-- affected patient there are three possible worlds, and they need different
-- fixes:
--
--   (a) NOTHING ANYWHERE. No record in any source after the index. The patient
--       genuinely has no observation time in that cohort. Zero follow-up is
--       then the truth, and the honest dispositions are to exclude them or to
--       null the durations - not to invent a number.
--
--   (b) A RECORD IN A SOURCE 202606 DROPPED. Register Q40: 202603 folded the
--       alpha/beta-emitter and Provenge tables into follow-up and the 202606
--       sheet does not list them. Q40 is RESOLVED as spec-faithful, but its own
--       text asks to "confirm the omission is intended rather than an editing
--       slip" and warns it SHORTENS follow-up. A patient here is not a Q83
--       case at all - they are a Q40 consequence, and the fix is to reopen Q40.
--
--   (c) A RECORD IN A SOURCE NEITHER CUT READ. The patient was observed and the
--       four-source definition cannot see it. No disposition rule fixes that;
--       only a wider FU_ENDDT_preliminary would, and that is a specification
--       change rather than something this release can decide.
--
-- THIS FILE IS DIAGNOSIS, NOT A MENU. It answers one question - do these
-- patients have records anywhere after their index - because that decides
-- whether Q83 is a data-absence problem or a definition problem. It is NOT a
-- proposal to read eighteen sources, and nobody should infer one from the fact
-- that it reads eighteen to find out.
--
-- Nothing here is implied by the 2026-09-11 ruling. Ben's clarification
-- changes WHICH of two existing dates wins and uses "the last activity" as a
-- given; it does not define activity or question its sources, and neither does
-- Pratyk's proposal. That rule is implemented and gate V47 passes on it. The
-- four-source list stands for this release; widening it is a next-cut question
-- for the study team, and the sizing in 13_fued_activity_sizing.sql already
-- argues against the version of it that was proposed.
--
-- EXHAUSTIVE SINCE 2026-09-13, and it was not before. The first two versions of
-- this file hand-picked candidate sources - six, then seven once
-- LASTCLINICNOTEDATE was added - and both understated how many of the 594 were
-- observed, because a hand-picked list is an argument about which sources
-- matter dressed up as a measurement. It now reads EVERY dated column in
-- validation/00_input_contract.csv, so "no record anywhere" means the contract
-- and not a shortlist. Earlier figures from this file (476, then 466 with
-- nothing after the index) are superseded by whatever this run reports.
--
-- WHAT IS DELIBERATELY EXCLUDED, and why, because an exhaustive check has to
-- say what it leaves out:
--   t_enh_prostate crpcdate / hspcdate / metastaticdiagnosisdate /
--     diagnosisdate - these are the milestone dates that DEFINE the index for
--     cohorts 1 and 2. Counting them as evidence of follow-up after the index
--     would be circular: the index IS one of them.
--   t_mortality_v2 dateofdeath - that is death, not activity, and FUED takes
--     it directly under RP2. The whole population here has no death date.
--   t_enh_prostate_orals startdategranularity - a granularity label, not a date.
--
--     Rscript validation/run_sql.R validation/12_q83_why_no_activity.sql
--
-- Read-only. Reads the delivered table and the source schema together, so it
-- runs after the build and writes nothing.
--
--   ${catalog} = hive_metastore    ${schema} = your personal schema
--   ${ads}     = rwdp_pros_pano_2026m06
--   ${src}     = clnprw_flatiron_pano_pros_use
--
-- ONE ORDERING NOTE. The two tables register Q40 dropped are read in the LAST
-- statement on purpose. They are not part of the 202606 definition, so they may
-- not have been carried into this refresh's schema at all. If that statement
-- errors with a missing table, that is itself the answer to (b) - the source is
-- gone, not merely unread - and every statement before it has already returned.
-- =============================================================================

USE CATALOG ${catalog};

-- ---------------------------------------------------------------------------
-- Q83W.1. IS THE DELIVERED FUED CORRECT?  Settle this before asking anything
-- else, because the rest of the file assumes it.
--
-- Recomputes FU_ENDDT_preliminary for the affected patients straight from the
-- four sources 5B.ClinChars row 89 names, and compares it to what shipped. If
-- these disagree the problem is a derivation bug and Q83's four options are all
-- premature; if they agree - which is what is expected - then the delivered
-- value is a faithful reading of a definition that cannot see these patients,
-- and the question is about the definition.
--
-- GREATEST skips nulls in Spark, matching pmax(..., na.rm = TRUE), so a patient
-- with only one of the four sources still recomputes correctly.
--
-- FUED is patient-level under RP3 - derived once, before any cohort exists - so
-- MAX(fued) over a patient's rows is just that patient's FUED, not an
-- aggregation across differing values. The same is not true of INDEXDT, which
-- is why the first and last affected index dates are carried separately below.
--
-- @assert zero fued_mismatch
-- @assert positive patients_checked
-- ---------------------------------------------------------------------------
WITH affected AS (
  SELECT patid,
         MIN(indexdt) AS first_index,
         MAX(indexdt) AS last_index,
         MAX(fued)    AS fued
  FROM   ${schema}.${ads}
  WHERE  fued < indexdt
  GROUP  BY patid),
recomputed AS (
  SELECT a.patid, a.fued,
         GREATEST(v.d, t.d, l.d, o.d) AS four_source_max
  FROM   affected a
  LEFT JOIN (SELECT patientid, MAX(visitdate) AS d FROM ${src}.t_visit_2026m06
             WHERE patientid IN (SELECT patid FROM affected) GROUP BY patientid) v
         ON v.patientid = a.patid
  LEFT JOIN (SELECT patientid, MAX(visitdate) AS d FROM ${src}.t_telemedicine_2026m06
             WHERE patientid IN (SELECT patid FROM affected) GROUP BY patientid) t
         ON t.patientid = a.patid
  LEFT JOIN (SELECT patientid, MAX(enddate) AS d FROM ${src}.t_enh_prostate_lot_2026m06
             WHERE patientid IN (SELECT patid FROM affected) GROUP BY patientid) l
         ON l.patientid = a.patid
  LEFT JOIN (SELECT patientid, MAX(enddate) AS d FROM ${src}.t_enh_prostate_orals_2026m06
             WHERE patientid IN (SELECT patid FROM affected) GROUP BY patientid) o
         ON o.patientid = a.patid)
SELECT COUNT(*)                                                          AS patients_checked,
       COALESCE(SUM(CASE WHEN fued IS DISTINCT FROM four_source_max
                         THEN 1 ELSE 0 END), 0)                          AS fued_mismatch
FROM   recomputed;

-- ---------------------------------------------------------------------------
-- Q83W.2. THE ANSWER, per source.  For each dated column in the contract, how
-- many of the affected patients have a record in it after the index date their
-- follow-up precedes?
--
-- Counted against FIRST_INDEX - the earliest index date at which the patient is
-- affected. That is the generous test: a record after the earliest affected
-- index proves the patient was observed within at least one of the cohorts
-- whose follow-up says they were not. Using the latest index instead would
-- undercount real observation.
--
-- `in_spec` marks the four sources 5B.ClinChars row 89 already names. Those
-- rows must read zero by construction - if a spec source had a record after
-- the index, FU_ENDDT_preliminary would have picked it up and the patient
-- would not be in this population at all. They are listed anyway, because a
-- nonzero there would mean the derivation is broken rather than narrow, and
-- that is worth seeing rather than assuming.
--
-- The sources that are NOT in the spec are the finding. Sorted by patient
-- count, so the ones that would recover the most follow-up come first.
-- ---------------------------------------------------------------------------
WITH affected AS (
  SELECT patid, MIN(indexdt) AS first_index
  FROM   ${schema}.${ads}
  WHERE  fued < indexdt
  GROUP  BY patid),
acts AS (
  SELECT 'visit'              AS source, 1 AS in_spec, patientid, visitdate                      AS dt FROM ${src}.t_visit_2026m06
  UNION ALL SELECT 'telemedicine',       1, patientid, visitdate                                 FROM ${src}.t_telemedicine_2026m06
  UNION ALL SELECT 'lot_end',            1, patientid, enddate                                   FROM ${src}.t_enh_prostate_lot_2026m06
  UNION ALL SELECT 'oral_end',           1, patientid, enddate                                   FROM ${src}.t_enh_prostate_orals_2026m06
  UNION ALL SELECT 'lot_start',          0, patientid, startdate                                 FROM ${src}.t_enh_prostate_lot_2026m06
  UNION ALL SELECT 'drug_episode',       0, patientid, episodedate                               FROM ${src}.t_enh_prostate_drg_epsode_2026m06
  UNION ALL SELECT 'med_admin',          0, patientid, administereddate                          FROM ${src}.t_medicationadmin_2026m06
  UNION ALL SELECT 'med_order',          0, patientid, expectedstartdate                         FROM ${src}.t_medicationorder_2026m06
  UNION ALL SELECT 'lab',                0, patientid, GREATEST(testdate, resultdate)            FROM ${src}.t_lab_2026m06
  UNION ALL SELECT 'vitals',             0, patientid, GREATEST(testdate, resultdate)            FROM ${src}.t_vitals_2026m06
  UNION ALL SELECT 'psa',                0, patientid, resultdate                                FROM ${src}.t_enh_prostate_psa_2026m06
  UNION ALL SELECT 'ecog',               0, patientid, ecogdate                                  FROM ${src}.t_ecog_2026m06
  UNION ALL SELECT 'baseline_ecog',      0, patientid, ecogdate                                  FROM ${src}.t_enh_prostate_bsln_ecog_2026m06
  UNION ALL SELECT 'baseline_line_start', 0, patientid, linestartdate                          FROM ${src}.t_enh_prostate_bsln_ecog_2026m06
  UNION ALL SELECT 'biomarker',          0, patientid, GREATEST(resultdate, specimencollecteddate) FROM ${src}.t_enh_prostate_biomarker_2026m06
  UNION ALL SELECT 'psma_pet',           0, patientid, scandate                                  FROM ${src}.t_enh_prostate_psmapet_2026m06
  UNION ALL SELECT 'progression',        0, patientid, progressiondate                           FROM ${src}.t_enh_prostate_prog_scled_2026m06
  UNION ALL SELECT 'last_clinic_note',   0, patientid, lastclinicnotedate                        FROM ${src}.t_enh_prostate_prog_scled_2026m06
  UNION ALL SELECT 'metastasis_som',     0, patientid, dateofmetastasis                          FROM ${src}.t_enh_prostate_som_2026m06)
SELECT c.source,
       MAX(c.in_spec)                                                    AS in_spec,
       COUNT(DISTINCT CASE WHEN c.dt > a.first_index THEN a.patid END)   AS patients_after_index,
       MAX(CASE WHEN c.dt > a.first_index
                THEN DATEDIFF(c.dt, a.first_index) END)                  AS max_days_after
FROM   affected a
JOIN   acts c ON c.patientid = a.patid
GROUP  BY c.source
ORDER  BY patients_after_index DESC, c.source;

-- ---------------------------------------------------------------------------
-- Q83W.3. THE HEADLINE.  Across ALL contract sources at once - how many of the
-- 594 were observed after their index, and how many were not?
--
-- This supersedes the hand-picked counts the earlier versions of this file
-- produced. `no_source_after_index` is now a statement about the whole input
-- contract: those patients have no dated record of any kind after the date
-- they entered the cohort, and no widening of the activity definition can
-- reach them.
--
-- recoverable_days is measured to the latest record in any NON-SPEC source,
-- so it is the follow-up a wider definition would restore - not the follow-up
-- the patient has.
-- ---------------------------------------------------------------------------
WITH affected AS (
  SELECT patid, MIN(indexdt) AS first_index
  FROM   ${schema}.${ads}
  WHERE  fued < indexdt
  GROUP  BY patid),
acts AS (
  SELECT patientid, startdate                                  AS dt FROM ${src}.t_enh_prostate_lot_2026m06
  UNION ALL SELECT patientid, episodedate                             FROM ${src}.t_enh_prostate_drg_epsode_2026m06
  UNION ALL SELECT patientid, administereddate                        FROM ${src}.t_medicationadmin_2026m06
  UNION ALL SELECT patientid, expectedstartdate                       FROM ${src}.t_medicationorder_2026m06
  UNION ALL SELECT patientid, GREATEST(testdate, resultdate)          FROM ${src}.t_lab_2026m06
  UNION ALL SELECT patientid, GREATEST(testdate, resultdate)          FROM ${src}.t_vitals_2026m06
  UNION ALL SELECT patientid, resultdate                              FROM ${src}.t_enh_prostate_psa_2026m06
  UNION ALL SELECT patientid, ecogdate                                FROM ${src}.t_ecog_2026m06
  UNION ALL SELECT patientid, ecogdate                                FROM ${src}.t_enh_prostate_bsln_ecog_2026m06
  UNION ALL SELECT patientid, linestartdate                           FROM ${src}.t_enh_prostate_bsln_ecog_2026m06
  UNION ALL SELECT patientid, GREATEST(resultdate, specimencollecteddate) FROM ${src}.t_enh_prostate_biomarker_2026m06
  UNION ALL SELECT patientid, scandate                                FROM ${src}.t_enh_prostate_psmapet_2026m06
  UNION ALL SELECT patientid, progressiondate                         FROM ${src}.t_enh_prostate_prog_scled_2026m06
  UNION ALL SELECT patientid, lastclinicnotedate                      FROM ${src}.t_enh_prostate_prog_scled_2026m06
  UNION ALL SELECT patientid, dateofmetastasis                        FROM ${src}.t_enh_prostate_som_2026m06),
best AS (
  SELECT a.patid, a.first_index,
         MAX(CASE WHEN c.dt > a.first_index THEN c.dt END) AS unread_dt
  FROM   affected a
  LEFT JOIN acts c ON c.patientid = a.patid
  GROUP  BY a.patid, a.first_index)
SELECT COUNT(*)                                                          AS patients_affected,
       COALESCE(SUM(CASE WHEN unread_dt IS NOT NULL THEN 1 ELSE 0 END), 0) AS any_source_after_index,
       COALESCE(SUM(CASE WHEN unread_dt IS NULL THEN 1 ELSE 0 END), 0)   AS no_source_after_index,
       ROUND(100.0 * COALESCE(SUM(CASE WHEN unread_dt IS NULL THEN 1 ELSE 0 END), 0)
             / NULLIF(COUNT(*), 0), 2)                                   AS pct_truly_unobserved
FROM   best;

-- ---------------------------------------------------------------------------
-- Q83W.4. HOW MUCH observation is being missed, for those who have some.
--
-- A record one day after the index is a different finding from a record three
-- years after it. If the recoverable follow-up is substantial, the four-source
-- definition is not merely narrow for these patients - it is discarding most
-- of what is known about them.
-- ---------------------------------------------------------------------------
WITH affected AS (
  SELECT patid, MIN(indexdt) AS first_index
  FROM   ${schema}.${ads}
  WHERE  fued < indexdt
  GROUP  BY patid),
acts AS (
  SELECT patientid, startdate                                  AS dt FROM ${src}.t_enh_prostate_lot_2026m06
  UNION ALL SELECT patientid, episodedate                             FROM ${src}.t_enh_prostate_drg_epsode_2026m06
  UNION ALL SELECT patientid, administereddate                        FROM ${src}.t_medicationadmin_2026m06
  UNION ALL SELECT patientid, expectedstartdate                       FROM ${src}.t_medicationorder_2026m06
  UNION ALL SELECT patientid, GREATEST(testdate, resultdate)          FROM ${src}.t_lab_2026m06
  UNION ALL SELECT patientid, GREATEST(testdate, resultdate)          FROM ${src}.t_vitals_2026m06
  UNION ALL SELECT patientid, resultdate                              FROM ${src}.t_enh_prostate_psa_2026m06
  UNION ALL SELECT patientid, ecogdate                                FROM ${src}.t_ecog_2026m06
  UNION ALL SELECT patientid, ecogdate                                FROM ${src}.t_enh_prostate_bsln_ecog_2026m06
  UNION ALL SELECT patientid, linestartdate                           FROM ${src}.t_enh_prostate_bsln_ecog_2026m06
  UNION ALL SELECT patientid, GREATEST(resultdate, specimencollecteddate) FROM ${src}.t_enh_prostate_biomarker_2026m06
  UNION ALL SELECT patientid, scandate                                FROM ${src}.t_enh_prostate_psmapet_2026m06
  UNION ALL SELECT patientid, progressiondate                         FROM ${src}.t_enh_prostate_prog_scled_2026m06
  UNION ALL SELECT patientid, lastclinicnotedate                      FROM ${src}.t_enh_prostate_prog_scled_2026m06
  UNION ALL SELECT patientid, dateofmetastasis                        FROM ${src}.t_enh_prostate_som_2026m06),
best AS (
  SELECT a.patid, a.first_index,
         MAX(CASE WHEN c.dt > a.first_index THEN c.dt END) AS unread_dt
  FROM   affected a
  LEFT JOIN acts c ON c.patientid = a.patid
  GROUP  BY a.patid, a.first_index)
SELECT CASE WHEN unread_dt IS NULL                        THEN '0. nothing after the index'
            WHEN DATEDIFF(unread_dt, first_index) <=   30 THEN '1. up to a month'
            WHEN DATEDIFF(unread_dt, first_index) <=   90 THEN '2. up to a quarter'
            WHEN DATEDIFF(unread_dt, first_index) <=  365 THEN '3. up to a year'
            WHEN DATEDIFF(unread_dt, first_index) <= 1095 THEN '4. one to three years'
            ELSE                                               '5. over three years'
       END                                                               AS recoverable,
       COUNT(*)                                                          AS patients,
       MIN(DATEDIFF(unread_dt, first_index))                             AS min_days,
       MAX(DATEDIFF(unread_dt, first_index))                             AS max_days
FROM   best
GROUP  BY 1
ORDER  BY 1;

-- ---------------------------------------------------------------------------
-- Q83W.5. THE TWO SOURCES REGISTER Q40 DROPPED.  Last, because these tables
-- are not part of the 202606 definition and may not exist in this schema - see
-- the ordering note in the header. A missing-table error here IS the answer.
--
-- A patient appearing here was receiving a radioligand or Provenge, which is
-- about as clear a record of being alive and in care as this data holds. If
-- this count is nonzero, those patients are a Q40 consequence rather than a
-- Q83 case, and Q40 should be reopened rather than a Q83 disposition applied
-- on top of it. Measured 2026-09-13 as zero on both; re-run confirms it.
-- ---------------------------------------------------------------------------
WITH affected AS (
  SELECT patid, MIN(indexdt) AS first_index
  FROM   ${schema}.${ads}
  WHERE  fued < indexdt
  GROUP  BY patid)
SELECT COUNT(*)                                                          AS patients_affected,
       COALESCE(SUM(CASE WHEN alpha_dt > first_index THEN 1 ELSE 0 END), 0) AS alphabeta_after_index,
       COALESCE(SUM(CASE WHEN prov_dt  > first_index THEN 1 ELSE 0 END), 0) AS provenge_after_index,
       COALESCE(SUM(CASE WHEN GREATEST(alpha_dt, prov_dt) > first_index
                         THEN 1 ELSE 0 END), 0)                          AS either_after_index
FROM  (SELECT a.patid, a.first_index,
              (SELECT MAX(x.administrationdate)
               FROM ${src}.t_enh_prostate_alpbta_emt_2026m06 x
               WHERE x.patientid = a.patid)                              AS alpha_dt,
              (SELECT MAX(x.startdate)
               FROM ${src}.t_enh_prostate_provenge_2026m06 x
               WHERE x.patientid = a.patid)                              AS prov_dt
       FROM   affected a) z;

-- =============================================================================
-- HOW TO READ THE RESULT
-- =============================================================================
--   Q83W.1 mismatch nonzero      Stop. The delivered FUED is not the four-source
--                                maximum, which is a derivation defect and a
--                                different problem from Q83. Nothing below is
--                                meaningful until it is explained.
--
--   Q83W.2 any in_spec = 1 row   reading nonzero would be the same defect seen
--                                from the other end - a spec source with a
--                                record after the index means FU_ENDDT_
--                                preliminary should already have caught it.
--
--   Q83W.2 non-spec rows         the finding, ranked. The top source is the one
--                                that would recover the most follow-up if the
--                                activity definition were widened to include
--                                it. Drug episode and medication order are the
--                                ones to look at hardest: a patient receiving
--                                or being prescribed therapy is unambiguously
--                                in care, and neither is in the row 89 list.
--
--   Q83W.3 no_source_after_index the patients no definition change can reach.
--                                They have no dated record of any kind in the
--                                whole input contract after the date they
--                                entered the cohort. Whatever this number is,
--                                those rows need a Q83 disposition - deliver
--                                the negative or null the durations, exclusion
--                                and flooring both being ruled out.
--
--   Q83W.5 either_after_index    nonzero would mean register Q40, not Q83.
-- =============================================================================
