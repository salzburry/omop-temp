-- =============================================================================
-- PRE-RULING SNAPSHOT, PART B - COMPARE.  RUN AFTER THE REBUILD.
-- =============================================================================
-- READ-ONLY. Nothing here writes, so running it at the wrong moment costs a
-- query and nothing else. Its companion 00a_pre_ruling_snapshot_TAKE.sql is the
-- one that writes, and it must have been run BEFORE the rebuild.
--
-- B0 checks that. Run it first and stop if it fails - every number below is
-- meaningless if the snapshot is a copy of the new table rather than the old.
--
-- GRAIN: every comparison joins on (patid, cohortn). Part A's A3 asserts the
-- snapshot side; V01 asserts the delivered side. If either was skipped the
-- counts below can be inflated by duplicate keys.
--
-- RETAINED ROWS ONLY: the join drops any patient the death exclusion removed,
-- because they have no new row. That is deliberate - the exclusion is measured
-- by qc/04 and qcr_v26_cohorts_r. These measure patients who STAYED and whose
-- values moved anyway.
--
--   ${catalog} = hive_metastore
--   ${schema}  = your personal schema
--   ${ads}     = rwdp_pros_pano_2026m06
--
-- RP1-RP4 and W1-W3 are the 2026-09-11 ruling's four rules and the three
-- behaviours they withdraw, defined in docs/VARIABLES.md section 3.
-- =============================================================================

USE CATALOG ${catalog};

-- ---------------------------------------------------------------------------
-- M0. OLD-NAME DETECTION.  MUST return no rows.
--
-- The snapshot tables were called pre_q82_ads and pre_q82_ads_meta until
-- 2026-09-13. A snapshot taken before that rename still carries the old names,
-- and every statement below looks for the new ones - so the old snapshot would
-- be invisible and this file would quietly capture a second one, or the
-- comparison would report nothing to compare.
--
-- This is a STATEMENT, not a comment, on purpose: a migration note written as
-- `--` text is stripped by validation/run_sql.R before the SQL is sent, so it
-- can never stop anything. This can, and the assertion below makes it stop.
--
-- If it returns a row, run these two once and then re-run this file:
--
--     ALTER TABLE ${schema}.pre_q82_ads      RENAME TO ${schema}.pre_ruling_ads;
--     ALTER TABLE ${schema}.pre_q82_ads_meta RENAME TO ${schema}.pre_ruling_ads_meta;
--
-- @assert no-rows
-- ---------------------------------------------------------------------------
SHOW TABLES IN ${schema} LIKE 'pre_q82_ads*';

-- ---------------------------------------------------------------------------
-- B0. IS THE SNAPSHOT STILL THE OLD TABLE?  Run this first.
-- If the snapshot were accidentally retaken after the rebuild it would be
-- row-for-row identical to the ADS, and every difference below would read zero
-- - which looks exactly like "the ruling changed nothing". These two readings
-- separate that from the truth.
--
--   rows_only_in_snapshot > 0  ->  good. Those should be the exclusions.
--   rows_only_in_snapshot = 0  ->  STOP. Either the ruling excluded nobody
--                                  (check qcr_v26_cohorts_r) or the snapshot
--                                  is a copy of the new table and is useless.
--
-- A POSITIVE COUNT IS NOT ENOUGH. "Some rows disappeared" is satisfied by a
-- stale snapshot, a snapshot of a different refresh, or any other cause of row
-- loss - all of which would let B1-B5 run on an incomparable pair. So each
-- old-only row is held to the predicate the ruling actually specifies:
-- its index date must fall strictly AFTER its death date.
--
-- THE SNAPSHOT'S OWN DTHDT CANNOT BE USED FOR THIS. It is the PRE-ruling death
-- date, still carrying W1-W3, so testing against it would assert the wrong
-- predicate and could both excuse a real defect and flag a correct exclusion.
-- What the exclusion reads is the POST-ruling date, and that is recoverable
-- from the snapshot without the snapshot having anticipated this check:
-- DATEOFDEATH is captured raw, so RP1 is re-applied below, identical to
-- 01_studypop.R.
--
-- The four breakdown columns partition the unexplained set, so a nonzero is
-- immediately actionable rather than just alarming:
--
--   no_death_date              the row had no death date at all, so nothing
--                              could have excluded it. Membership defect.
--   death_unparseable          populated DATEOFDEATH that imputes to NULL.
--                              Preflight B18 should have caught this before
--                              the build; a hit here means it did not run.
--   null_index_date            a usable death date but no index. V06 gates
--                              this on the delivered table, but the snapshot
--                              predates the assertion, so it is counted.
--   index_on_or_before_death   the equality or earlier case, which the ruling
--                              RETAINS. Dropping it is the opposite error.
--
-- The four are mutually exclusive and sum to old_only_unexplained: the first
-- two are every way the death date can be unusable, the last two every way a
-- usable one can still fail the test. If they do not sum, the partition has a
-- hole and the total is the figure to trust.
--
-- This check is deliberately strict, and a failure means "these two tables are
-- not a before/after pair" rather than "loosen the predicate". If the source
-- cut moved between the snapshot and the rebuild, rows leave for reasons the
-- ruling never mentioned and this is exactly what should catch it. Do not
-- relax it to make a run pass - retake the pair, or accept that B1-B5 cannot
-- be attributed to the ruling.
--
-- MEMBERSHIP IS KEYED ON (patid, cohortn), WHICH LEAVES ONE BLIND SPOT. A
-- patient in both tables under the same cohort is "retained" however much the
-- row changed underneath, so an INDEX DATE that moved is invisible to the two
-- anti-joins above: the row is not old-only and not new-only. The ruling did
-- not touch index dates, so any movement means the source cut shifted and the
-- pair is not a before/after pair - the same conclusion B0 draws, reached a
-- different way. index_moved_INVESTIGATE counts it and must read zero.
--
-- @assert positive rows_only_in_snapshot
-- @assert zero rows_only_in_current_UNEXPECTED
-- @assert zero old_only_unexplained_INVESTIGATE
-- @assert zero index_moved_INVESTIGATE
-- ---------------------------------------------------------------------------
WITH old_only AS (
  SELECT o.indexdt,
         CASE
           WHEN LENGTH(o.dateofdeath) = 7 THEN TRY_CAST(CONCAT(o.dateofdeath, '-15') AS DATE)
           WHEN LENGTH(o.dateofdeath) = 4 THEN TRY_CAST(CONCAT(o.dateofdeath, '-07-15') AS DATE)
           ELSE NULL END AS dthdt_ruling,
         o.dateofdeath
  FROM   ${schema}.pre_ruling_ads o
  LEFT   JOIN ${schema}.${ads} n
    ON   o.patid = n.patid AND o.cohortn = n.cohortn
  WHERE  n.patid IS NULL),
new_only AS (
  SELECT n.patid
  FROM   ${schema}.${ads} n
  LEFT   JOIN ${schema}.pre_ruling_ads o
    ON   o.patid = n.patid AND o.cohortn = n.cohortn
  WHERE  o.patid IS NULL),
-- Retained rows whose index date moved. IS DISTINCT FROM so a date that
-- appeared or disappeared counts alongside one that changed value.
index_moved AS (
  SELECT n.patid
  FROM   ${schema}.${ads} n
  JOIN   ${schema}.pre_ruling_ads o
    ON   o.patid = n.patid AND o.cohortn = n.cohortn
  WHERE  o.indexdt IS DISTINCT FROM n.indexdt)
SELECT (SELECT COUNT(*) FROM ${schema}.pre_ruling_ads)  AS snapshot_rows,
       (SELECT COUNT(*) FROM ${schema}.${ads})       AS current_rows,
       (SELECT COUNT(*) FROM old_only)               AS rows_only_in_snapshot,
       (SELECT COUNT(*) FROM new_only)               AS rows_only_in_current_UNEXPECTED,
       (SELECT COUNT(*) FROM index_moved)            AS index_moved_INVESTIGATE,
       -- every old-only row the ruling does NOT account for
       (SELECT COUNT(*) FROM old_only
        WHERE dthdt_ruling IS NULL OR indexdt IS NULL
           OR indexdt <= dthdt_ruling)                  AS old_only_unexplained_INVESTIGATE,
       (SELECT COUNT(*) FROM old_only
        WHERE dateofdeath IS NULL)                   AS no_death_date,
       (SELECT COUNT(*) FROM old_only
        WHERE dateofdeath IS NOT NULL
          AND dthdt_ruling IS NULL)                     AS death_unparseable,
       (SELECT COUNT(*) FROM old_only
        WHERE dthdt_ruling IS NOT NULL
          AND indexdt IS NULL)                       AS null_index_date,
       (SELECT COUNT(*) FROM old_only
        WHERE dthdt_ruling IS NOT NULL AND indexdt IS NOT NULL
          AND indexdt <= dthdt_ruling)                  AS index_on_or_before_death;

SELECT * FROM ${schema}.pre_ruling_ads_meta;

-- ---------------------------------------------------------------------------
-- B1. DTHFUFL movement
--
-- EXPECTATION: zero flips, in either direction, among RETAINED rows.
-- W2 fired only when the death shared FU_ENDDT_preliminary's month, so old and
-- new death dates both sit inside that month and |death - activity| stays well
-- under 120 days either way - the flag reads 1 before and after. W1 moved the
-- date much further, but those patients now die on 15 July, before an index
-- that fell later in the same year, so the exclusion removes them and they are
-- not in this join at all.
--
-- So a nonzero flip count in EITHER direction is a finding, not a measurement:
-- it means the movement is not what the specification describes. Read days_moved beside it -
-- dates moving with no flag flipping is the expected shape.
--
-- @assert zero flipped_0_to_1_INVESTIGATE
-- @assert zero flipped_1_to_0_INVESTIGATE
-- ---------------------------------------------------------------------------
SELECT COUNT(*)                                                         AS retained_death_rows,
       SUM(CASE WHEN o.dthfufl = 0 AND n.dthfufl = 1 THEN 1 ELSE 0 END) AS flipped_0_to_1_INVESTIGATE,
       SUM(CASE WHEN o.dthfufl = 1 AND n.dthfufl = 0 THEN 1 ELSE 0 END) AS flipped_1_to_0_INVESTIGATE,
       SUM(CASE WHEN o.death_dt_preliminary IS DISTINCT FROM
                     n.death_dt_preliminary THEN 1 ELSE 0 END)          AS death_date_moved,
       MAX(DATEDIFF(o.death_dt_preliminary, n.death_dt_preliminary))    AS max_days_earlier
FROM   ${schema}.pre_ruling_ads o
JOIN   ${schema}.${ads}      n
  ON   o.patid = n.patid AND o.cohortn = n.cohortn
WHERE  o.dthfl = 1;

-- ---------------------------------------------------------------------------
-- B2. Death-derived TTNT and rwPFS movement
--
-- Restricted to rows whose death date actually moved AND whose outcome was
-- death-DERIVED, because only those can shift. Without the branch restriction
-- the means would be diluted by next-treatment and progression events that the
-- ruling did not touch.
--
-- THE BRANCH CANNOT BE READ OFF THE VALUE, and it is not "no next treatment".
-- 05_outcomes.R takes LEAST(next_trt_dt, dthdt) on the event branch, so death
-- drives the number whenever it is the EARLIER of the two - including where a
-- later next treatment exists. It is rebuilt here exactly as production does
-- it, from the cohort's own next-treatment date, ID3MOSFU and DTHFL:
--
--   cohort 3-6 only          TTNT is NULL in 1, 2 and 7, so a dead patient
--                            there must not be counted.
--   ID3MOSFU = 1             production's precondition for any TTNT at all.
--   next_trt OR DTHFL = 1    TTNTFL = 1, the event branch. TTNTFL is not
--                            delivered, hence the rebuild.
--   death is the LEAST       DTHDT <= next_trt, or no next_trt.
--
-- Derived on BOTH tables, so a row that SWITCHED branch because the new DTHDT
-- crossed its next-treatment date is visible rather than silently dropped.
--
-- THE NEXT-TREATMENT DATES COME FROM THE CURRENT TABLE FOR BOTH FLAGS, and
-- that is deliberate. 00a's A2 captures 20 columns and no LOT start date among
-- them, so reading them from pre_ruling_ads would fail on an unresolved column -
-- and the snapshot is one-shot, so it cannot be retaken to add them. It does
-- not need to be: the ruling moves death dates, follow-up dates and cohort
-- membership, never a line start date, and the join below keeps only rows
-- present in BOTH tables. For every such row the current LOT date IS the
-- snapshot's LOT date. Anything the ruling DOES move - DTHDT, DTHFL, ID3MOSFU -
-- is taken from its own table, o for old and n for new.
--
-- TIES ARE SPLIT OUT, not merely reported. Where death and the next treatment
-- fall on the same date, LEAST returns that date whichever drives it, so the
-- value cannot have moved. Such a row inside a mean of movement only dilutes
-- it, and it can never be a branch SWITCH either, since it is death-driven on
-- both sides by construction. The `_moving` count excludes ties, the tie count
-- sits beside it, and the two sum to `_total`.
--
-- rwPFS needs no branch. A progression date is a source date the ruling does
-- not move, so PFSDT can only change if it IS the death date: pfsdt_moved is
-- therefore exact. The `PFSDT = DTHDT` population is a BOUND, because a genuine
-- progression falling on the death date satisfies it too (production gives
-- progression priority) - so every figure derived from it carries a `_BOUND`
-- suffix and is restricted to rows whose PFSDT actually moved, which keeps a
-- zero-movement collision out of the mean without pretending the population is
-- exact.
--
-- Every SUM is COALESCEd to 0. A filtered SUM over an empty relation returns
-- NULL in Spark, and a NULL count reads as "not measured" when the honest
-- answer is "none". The AVG and MAX stay NULL on purpose - there is no mean of
-- nothing, and 0 would be a lie.
-- NULL-safe throughout: IS DISTINCT FROM, not <>.
-- ---------------------------------------------------------------------------
WITH lot AS (            -- ruling-invariant, so one read serves both flags
  SELECT patid, cohortn,
         CASE cohortn                          -- Spark LEAST skips NULLs,
           WHEN 3 THEN LEAST(lot2sd_mhspc, lot1sd_mcrpc)  -- as pmin(na.rm)
           WHEN 4 THEN lot2sd_mcrpc
           WHEN 5 THEN lot3sd_mcrpc
           WHEN 6 THEN lot4sd_mcrpc
           ELSE NULL END AS next_trt
  FROM   ${schema}.${ads}),
cmp AS (                 -- one row per retained row whose death date moved
  SELECT o.ttnt AS o_ttnt, n.ttnt AS n_ttnt,
         o.pfs  AS o_pfs,  n.pfs  AS n_pfs,
         o.pfsdt AS o_pfsdt, n.pfsdt AS n_pfsdt,
         n.dthdt AS n_dthdt, l.next_trt,
         n.cohortn IN (3, 4, 5, 6)
           AND COALESCE(n.dth_before_fued = 0, TRUE)
           AND COALESCE(n.id3mosfu = 1, FALSE)
           AND (l.next_trt IS NOT NULL OR COALESCE(n.dthfl = 1, FALSE))
           AND n.dthdt IS NOT NULL
           AND (l.next_trt IS NULL OR n.dthdt <= l.next_trt)  AS n_ttnt_death,
         -- B2.10: production returns NULL for dth_before_fued = 1 BEFORE any
         -- branch test (05_outcomes.R:86), so a row guarded there has no TTNT
         -- to have been driven by anything. The snapshot captures the column,
         -- so the OLD side applies it exactly. On the new side it is a constant
         -- 0 under the ruling and the term is a no-op - written anyway, so the two
         -- predicates stay visibly identical.
         o.cohortn IN (3, 4, 5, 6)
           AND COALESCE(o.dth_before_fued = 0, TRUE)
           AND COALESCE(o.id3mosfu = 1, FALSE)
           AND (l.next_trt IS NOT NULL OR COALESCE(o.dthfl = 1, FALSE))
           AND o.dthdt IS NOT NULL
           AND (l.next_trt IS NULL OR o.dthdt <= l.next_trt)  AS o_ttnt_death,
         n.pfsdt IS NOT NULL AND n.pfsdt = n.dthdt            AS n_pfs_death,
         l.next_trt IS NOT NULL AND n.dthdt = l.next_trt      AS tie,
         -- B2.11: the ruling reaches these three more directly than TTNT or
         -- PFS, and the snapshot captures all of them.
         o.fued AS o_fued, n.fued AS n_fued,
         o.fudur AS o_fudur, n.fudur AS n_fudur,
         o.os AS o_os, n.os AS n_os
  FROM   ${schema}.pre_ruling_ads o
  JOIN   ${schema}.${ads}      n
    ON   o.patid = n.patid AND o.cohortn = n.cohortn
  JOIN   lot l ON l.patid = n.patid AND l.cohortn = n.cohortn
  WHERE  o.dthdt IS DISTINCT FROM n.dthdt)
SELECT -- TTNT. `_moving` excludes the same-day tie: where death and the next
       -- treatment fall on one date, production's LEAST returns that date
       -- whichever drives it, so the value cannot have moved and the row would
       -- only dilute a mean of movement. The tie count is reported beside it,
       -- and the two sum to every death-driven row.
       COALESCE(SUM(CASE WHEN n_ttnt_death AND NOT tie THEN 1 ELSE 0 END), 0) AS ttnt_death_driven_moving,
       COALESCE(SUM(CASE WHEN n_ttnt_death AND tie THEN 1 ELSE 0 END), 0)     AS ttnt_death_ties_next_trt,
       COALESCE(SUM(CASE WHEN n_ttnt_death THEN 1 ELSE 0 END), 0)             AS ttnt_death_driven_total,
       COALESCE(SUM(CASE WHEN n_ttnt_death AND NOT tie AND n_ttnt < o_ttnt
                         THEN 1 ELSE 0 END), 0)                               AS ttnt_shortened,
       ROUND(AVG(CASE WHEN n_ttnt_death AND NOT tie
                       THEN o_ttnt - n_ttnt END), 4)                          AS ttnt_mean_months_lost,
       MAX(CASE WHEN n_ttnt_death AND NOT tie THEN o_ttnt - n_ttnt END)       AS ttnt_max_months_lost,
       -- B2.9. A tie is death-driven on the NEW side by construction - NOT on
       -- both. The old promoted death could sit AFTER the next treatment, so the
       -- old branch was treatment-driven and the ruling switched it. The value
       -- does not move (LEAST returns the treatment date either way), which is
       -- why ties stay out of the MEAN - but excluding them from the switch
       -- count dropped exactly the switches the ruling caused. Counted now,
       -- with the value-silent ones reported separately.
       COALESCE(SUM(CASE WHEN n_ttnt_death AND NOT o_ttnt_death
                         THEN 1 ELSE 0 END), 0)                               AS ttnt_branch_switched_to_death,
       COALESCE(SUM(CASE WHEN n_ttnt_death AND NOT o_ttnt_death AND tie
                         THEN 1 ELSE 0 END), 0)                               AS ttnt_switched_silently_tie,
       -- rwPFS. pfsdt_moved_EXACT is the only exact figure here: a progression
       -- date is a source date the ruling never moves, so PFSDT can change only
       -- if it IS the death date. The `_BOUND` columns are computed on the
       -- pfsdt = dthdt population, which a genuine progression falling on the
       -- death date also satisfies, and are restricted to rows whose PFSDT
       -- actually moved so a zero-movement collision cannot dilute them. They
       -- remain bounds, not measurements - the suffix says so.
       COALESCE(SUM(CASE WHEN o_pfsdt IS DISTINCT FROM n_pfsdt
                         THEN 1 ELSE 0 END), 0)                               AS pfsdt_moved_EXACT,
       COALESCE(SUM(CASE WHEN n_pfs_death THEN 1 ELSE 0 END), 0)              AS pfs_death_driven_rows_BOUND,
       COALESCE(SUM(CASE WHEN n_pfs_death AND o_pfsdt IS DISTINCT FROM n_pfsdt
                              AND n_pfs < o_pfs THEN 1 ELSE 0 END), 0)        AS pfs_shortened_BOUND,
       ROUND(AVG(CASE WHEN n_pfs_death AND o_pfsdt IS DISTINCT FROM n_pfsdt
                       THEN o_pfs - n_pfs END), 4)                            AS pfs_mean_months_lost_BOUND,
       MAX(CASE WHEN n_pfs_death AND o_pfsdt IS DISTINCT FROM n_pfsdt
                THEN o_pfs - n_pfs END)                                       AS pfs_max_months_lost_BOUND
FROM   cmp;

-- ---------------------------------------------------------------------------
-- B2b. FUED, FUDUR and OS movement
--
-- EVERY RETAINED ROW, not only the rows whose death date moved. B2 above is
-- filtered to `o.dthdt IS DISTINCT FROM n.dthdt` because TTNT and PFS move
-- through the death date; these three do not, and measuring them under that
-- filter was wrong. It excluded the exact population the ruling's OTHER change
-- lands on: a patient with NO death date has NULL on both sides, so the filter
-- drops them - and their FUED moved anyway, because RP2 removed the index
-- floor. That is the whole of the open follow-up disposition exposure, and it was invisible here
-- until 2026-09-13.
--
-- Once the snapshot is dropped none of this can be recovered for this cut.
--
--   fued_moved / fudur_moved / os_moved   how many rows changed at all
--   *_mean_lost / *_max_lost              size of the change, old minus new
--   *_became_null                         newly possible under RP2: no death
--                                         date and no activity gives a NULL
--                                         FUED, and FUDUR and OS follow it
--   fudur_now_negative / fudur_now_zero   the open follow-up disposition population, counted here
--                                         because these rows are why the
--                                         disposition question exists
-- ---------------------------------------------------------------------------
SELECT COUNT(*)                                                          AS retained_rows,
       COALESCE(SUM(CASE WHEN o.fued IS DISTINCT FROM n.fued
                         THEN 1 ELSE 0 END), 0)                          AS fued_moved,
       MAX(ABS(DATEDIFF(n.fued, o.fued)))                                AS fued_max_days_moved,
       ROUND(AVG(CASE WHEN o.fued IS DISTINCT FROM n.fued
                       THEN ABS(DATEDIFF(n.fued, o.fued)) END), 4)       AS fued_mean_days_moved,
       COALESCE(SUM(CASE WHEN o.fued IS NOT NULL AND n.fued IS NULL
                         THEN 1 ELSE 0 END), 0)                          AS fued_became_null,
       COALESCE(SUM(CASE WHEN o.fudur IS DISTINCT FROM n.fudur
                         THEN 1 ELSE 0 END), 0)                          AS fudur_moved,
       ROUND(AVG(CASE WHEN o.fudur IS DISTINCT FROM n.fudur
                       THEN o.fudur - n.fudur END), 4)                   AS fudur_mean_lost,
       MAX(o.fudur - n.fudur)                                            AS fudur_max_lost,
       COALESCE(SUM(CASE WHEN o.fudur IS NOT NULL AND n.fudur IS NULL
                         THEN 1 ELSE 0 END), 0)                          AS fudur_became_null,
       COALESCE(SUM(CASE WHEN n.fudur < 0 THEN 1 ELSE 0 END), 0)         AS fudur_now_negative,
       COALESCE(SUM(CASE WHEN n.fudur = 0 THEN 1 ELSE 0 END), 0)         AS fudur_now_zero,
       COALESCE(SUM(CASE WHEN o.os IS DISTINCT FROM n.os
                         THEN 1 ELSE 0 END), 0)                          AS os_moved,
       ROUND(AVG(CASE WHEN o.os IS DISTINCT FROM n.os
                       THEN o.os - n.os END), 4)                         AS os_mean_lost,
       MAX(o.os - n.os)                                                  AS os_max_lost,
       COALESCE(SUM(CASE WHEN o.os IS NOT NULL AND n.os IS NULL
                         THEN 1 ELSE 0 END), 0)                          AS os_became_null,
       COALESCE(SUM(CASE WHEN n.os < 0 THEN 1 ELSE 0 END), 0)            AS os_now_negative
FROM   ${schema}.pre_ruling_ads o
JOIN   ${schema}.${ads}      n
  ON   o.patid = n.patid AND o.cohortn = n.cohortn;

-- ---------------------------------------------------------------------------
-- B3. CSF_FU movement
--
-- BOTH DIRECTIONS ARE LEGITIMATE has FUED moving both ways. Do not read
-- 1 -> 0 as a defect; it would stop a correct build.
--
--   WIDER  - a patient who died after their last recorded activity: FUED was
--            the activity date, it is now the later death date, so a growth
--            factor in between newly qualifies.  0 -> 1.
--   NARROWER - a patient whose month-granular death used to be promoted to
--            month end while their activity fell later in that same month:
--            old FUED was the activity date, new FUED is the day-15 death,
--            which is EARLIER. A growth factor between the two no longer
--            qualifies.  1 -> 0.
--
-- Record both. Neither is a defect; both belong in the data dictionary.
-- window_narrowed and window_widened are the denominators that explain them.
--
-- THE NULL TRANSITION IS A THIRD CASE, and `<` / `>` cannot see it: the 2026-09-11 ruling removed
-- the index floor, so a patient with neither a death date nor recorded activity
-- now delivers a NULL FUED. Comparing NULL with either operator yields unknown,
-- so such a row would fall into neither denominator and the two would fail to
-- account for their own flips. window_became_null is that residue. It belongs
-- with the open follow-up disposition, not  - the window did not narrow, it ceased to exist.
--
-- The four direction columns partition the moved rows by arithmetic, so their
-- completeness is not worth asserting. What IS asserted is the other
-- direction: every flip must be explained by a movement, and FUED can never
-- gain a value it did not have.
-- ---------------------------------------------------------------------------
SELECT COUNT(*)                                                    AS retained_rows,
       SUM(CASE WHEN o.csf_fu = 0 AND n.csf_fu = 1 THEN 1 ELSE 0 END) AS flipped_0_to_1,
       SUM(CASE WHEN o.csf_fu = 1 AND n.csf_fu = 0 THEN 1 ELSE 0 END) AS flipped_1_to_0,
       SUM(CASE WHEN n.fued > o.fued THEN 1 ELSE 0 END)             AS window_widened,
       SUM(CASE WHEN n.fued < o.fued THEN 1 ELSE 0 END)             AS window_narrowed,
       SUM(CASE WHEN o.fued IS NOT NULL AND n.fued IS NULL
                THEN 1 ELSE 0 END)                                  AS window_became_null,
       -- Old FUED null, new FUED not. RP2 removed the index floor and added no
       -- source, so FUED can lose a value and never gain one. A nonzero here
       -- means the derivation is not what section 7 describes.
       -- @assert zero window_gained_UNEXPECTED
       SUM(CASE WHEN o.fued IS NULL AND n.fued IS NOT NULL
                THEN 1 ELSE 0 END)                                  AS window_gained_UNEXPECTED,
       -- RECONCILE THE FLIPS AGAINST THE MOVEMENT, which is the part that can
       -- actually fail. The four direction columns above partition every moved
       -- FUED by arithmetic - two distinct non-null dates must compare one way
       -- or the other, and a null lands in one of the null columns - so a
       -- residue over them is identically zero and asserting it proved nothing.
       -- This file asserted exactly that until 2026-09-12.
       --
       -- What is falsifiable: the source and the index date are fixed between
       -- the two tables, so the ONLY thing that can move CSF_FU is the FUED
       -- bound. A window that newly qualifies a record must have widened; one
       -- that stopped qualifying must have narrowed or ceased to exist. A flip
       -- with no matching movement means either the source moved under the
       -- comparison - which B0 should have caught - or CSF_FU changed for a
       -- reason the ruling does not explain. Either way, stop.
       -- @assert zero flipped_0_to_1_without_widening_INVESTIGATE
       -- @assert zero flipped_1_to_0_without_narrowing_INVESTIGATE
       -- COALESCE, not a bare NOT: `n.fued > o.fued` is NULL when either side
       -- is NULL, and `CASE WHEN NULL` takes the ELSE, so a flip with a null
       -- endpoint would have counted as explained. It is the opposite - a flip
       -- whose window has no bound on one side is exactly what a person needs
       -- to look at - so an unknown comparison counts as unexplained.
       SUM(CASE WHEN o.csf_fu = 0 AND n.csf_fu = 1
                     AND NOT COALESCE(n.fued > o.fued, FALSE)
                THEN 1 ELSE 0 END)                     AS flipped_0_to_1_without_widening_INVESTIGATE,
       SUM(CASE WHEN o.csf_fu = 1 AND n.csf_fu = 0
                     AND NOT COALESCE(n.fued < o.fued
                                      OR (o.fued IS NOT NULL AND n.fued IS NULL), FALSE)
                THEN 1 ELSE 0 END)                     AS flipped_1_to_0_without_narrowing_INVESTIGATE
FROM   ${schema}.pre_ruling_ads o
JOIN   ${schema}.${ads}      n
  ON   o.patid = n.patid AND o.cohortn = n.cohortn;

-- ---------------------------------------------------------------------------
-- B4. Non-vacuity for the equality case
-- The ruling excludes an index AFTER the death date, so an index EXACTLY ON it
-- is retained. qc/05 would catch a delivery mismatch, but only if such patients
-- exist. Zero here means the equality rule is UNTESTED, not upheld.
--
-- Built on a seven-cohort spine so an empty result prints seven explicit zeros.
-- A bare GROUP BY returns NO ROWS when nothing matches, and "no rows" is
-- indistinguishable from "I forgot to run it" - which is the opposite of what a
-- non-vacuity check is for.
-- ---------------------------------------------------------------------------
SELECT s.cohortn,
       COALESCE(m.rows_index_equals_death, 0) AS rows_index_equals_death,
       COALESCE(m.patients, 0)                AS patients
FROM   (SELECT explode(array(1,2,3,4,5,6,7)) AS cohortn) s
LEFT   JOIN (
  SELECT cohortn,
         COUNT(*)              AS rows_index_equals_death,
         COUNT(DISTINCT patid) AS patients
  FROM   ${schema}.${ads}
  WHERE  dthdt IS NOT NULL AND indexdt = dthdt
  GROUP  BY cohortn) m
  ON   m.cohortn = s.cohortn
ORDER  BY s.cohortn;

-- ---------------------------------------------------------------------------
-- B5. the stale shares on the new denominator.
-- All ten analytes plus BP, because  quotes the set, not a sample.
-- ---------------------------------------------------------------------------
SELECT 'bp' AS col, bp AS value, COUNT(*) AS n,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (PARTITION BY 'bp'), 3) AS pct
FROM ${schema}.${ads} GROUP BY bp
UNION ALL SELECT 'labneu',  labneu,  COUNT(*), ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (PARTITION BY 'labneu'),  3) FROM ${schema}.${ads} GROUP BY labneu
UNION ALL SELECT 'labpla',  labpla,  COUNT(*), ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (PARTITION BY 'labpla'),  3) FROM ${schema}.${ads} GROUP BY labpla
UNION ALL SELECT 'labhem',  labhem,  COUNT(*), ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (PARTITION BY 'labhem'),  3) FROM ${schema}.${ads} GROUP BY labhem
UNION ALL SELECT 'labcre',  labcre,  COUNT(*), ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (PARTITION BY 'labcre'),  3) FROM ${schema}.${ads} GROUP BY labcre
UNION ALL SELECT 'labbil',  labbil,  COUNT(*), ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (PARTITION BY 'labbil'),  3) FROM ${schema}.${ads} GROUP BY labbil
UNION ALL SELECT 'labast',  labast,  COUNT(*), ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (PARTITION BY 'labast'),  3) FROM ${schema}.${ads} GROUP BY labast
UNION ALL SELECT 'labalt',  labalt,  COUNT(*), ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (PARTITION BY 'labalt'),  3) FROM ${schema}.${ads} GROUP BY labalt
UNION ALL SELECT 'labalp',  labalp,  COUNT(*), ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (PARTITION BY 'labalp'),  3) FROM ${schema}.${ads} GROUP BY labalp
UNION ALL SELECT 'labalb',  labalb,  COUNT(*), ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (PARTITION BY 'labalb'),  3) FROM ${schema}.${ads} GROUP BY labalb
UNION ALL SELECT 'lablym',  lablym,  COUNT(*), ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (PARTITION BY 'lablym'),  3) FROM ${schema}.${ads} GROUP BY lablym
ORDER  BY col, n DESC;

-- ---------------------------------------------------------------------------
-- Cleanup, ONLY once every number above is written into the release evidence.
--   DROP TABLE ${schema}.pre_ruling_ads;
--   DROP TABLE ${schema}.pre_ruling_ads_meta;
-- Neither can be rebuilt. Do not drop them to tidy up.
-- ---------------------------------------------------------------------------
