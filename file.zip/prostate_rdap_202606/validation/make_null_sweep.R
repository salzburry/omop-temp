# =============================================================================
# Builds validation/03b_null_sweep.sql
# =============================================================================
#   Rscript validation/make_null_sweep.R
#
# A complete sweep has to name all 190 columns, and 190 hand-written branches
# drift from the contract. So it is generated from
# validation/00_column_contract.csv, and the offline harness regenerates and
# diffs it - a hand edit cannot survive a run.
#
# MIN/MAX rather than COUNT(DISTINCT): a column is constant when MIN = MAX over
# its non-null values. MIN/MAX is one scan, is exact, and shows the reviewer the
# value range. 190 distinct counts make Spark scan once per aggregate.
#
# Re-run whenever the column contract changes, and keep both.
# =============================================================================

CONTRACT <- "validation/00_column_contract.csv"
# The offline check runs this generator with OUT redirected and diffs the
# result against the kept file; writing straight to the delivered path
# would rewrite the file being checked, and drift could never be reported.
if (!exists("OUT")) OUT <- "validation/03b_null_sweep.sql"

# Columns that are legitimately all-null or single-valued. Everything not on
# this list is a defect if it comes back empty or constant.
#
# Each waiver names the shape it expects, because the two are not
# interchangeable: a shapeless flag would pass an expected-null column carrying
# a repeated value, or an expected-constant stamp arriving all-null. A waiver
# that no longer describes the data reports REVIEW instead of passing.
#
#   null     expect no values at all
#   const    expect one repeated value on every row, no nulls - a column that
#            is 99% one value and 1% null is neither null nor constant.
WAIVED <- list(
  hrr_index_test            = c("const", "hard-coded Unknown; no test-type column exists"),
  hrr_index_testn           = c("const", "hard-coded 7; no test-type column exists"),
  brca_index_test           = c("const", "hard-coded Unknown; no test-type column exists"),
  brca_index_testn          = c("const", "hard-coded 7; no test-type column exists"),
  max_drug_ep_abstracted_dt = c("null",  "EpisodeDataSource=Abstraction absent from 2026m06"),
  # dth_before_fued is 0 on every row by construction under the 2026-09-11
  # follow-up ruling. FUED = COALESCE(dthdt, fu_enddt_preliminary),
  # so where a death date exists FUED IS that date and DTHDT < FUED is false;
  # where it does not, DTHDT is NULL and the test is false again. The flag is
  # structurally unreachable, not broken, and it stays in the 190-column
  # contract as a constant 0.
  #
  # THE TENSION, so that nobody "fixes" it later: output validation gate V45
  # FAILS unless dth_before_fued is constant 0, while this sweep would FAIL a
  # correct build precisely BECAUSE it is constant. This waiver is what
  # reconciles them - it turns the constant into WAIVED and keeps the shape
  # under test, so a flag that stopped being constant reads REVIEW. Delete the
  # waiver and a correct build can no longer ship; delete V45 and a reinstated
  # clamp ships unnoticed. Both stay.
  dth_before_fued           = c("const", "the 2026-09-11 ruling unreachable - FUED is the death date, so the flag is 0 on every row"),
  datav                     = c("const", "run stamp - one value by construction"),
  rawrwd                    = c("const", "run stamp - one value by construction"),
  minindex                  = c("const", "run stamp - one value by construction"),
  maxindex                  = c("const", "run stamp - one value by construction")
)
# labalb / labalbv / labalbdt are deliberately not waived: the spec's g/L
# unit filter is applied and the data carries it on
# ~5M rows, so these must be populated. All-null would mean the filter matched
# nothing - a defect, and preflight C10 stops that before the build runs.
#
# fued / fudur are deliberately NOT waived either, and their expectation is
# UNCHANGED, even though the 2026-09-11 ruling made them
# nullable: FUED is COALESCE(dthdt, fu_enddt_preliminary) with no index floor,
# so a patient with no death date and no activity in any of the four sources
# now gets a NULL FUED and, with it, a NULL FUDUR. That was impossible while
# the floor stood. Nothing is needed here because this sweep judges only two
# shapes - entirely null, and constant on every row - and a column that is
# partly null is neither, so it still reads PASS however the null rate moves.
# The size of that new null population is reported by qc/01_variable_profile.R
# (n_null / pct_null per column and cohort), and its legitimacy is gated by
# qc/07_type_contract.R, which fails if FUED is NULL while either source date
# is present or if FUDUR and FUED are not NULL together. An ENTIRELY null fued
# or fudur would mean all four source dates are missing for every patient - a
# real defect - so it must keep reporting FAIL, which is why no waiver is added
# and no expectation is relaxed.

cols <- utils::read.csv(CONTRACT, stringsAsFactors = FALSE)
cols <- cols[order(cols$ordinal), ]
nm   <- tolower(cols$column)

stopifnot(length(nm) > 0L, !anyDuplicated(nm),
          all(grepl("^[a-z][a-z0-9_]*$", nm)))   # bare identifiers, no quoting

unknown <- setdiff(names(WAIVED), nm)
if (length(unknown)) {
  stop("WAIVED names a column that is not in the contract: ",
       paste(unknown, collapse = ", "), call. = FALSE)
}

# --- one single-pass aggregate over the ADS ----------------------------------
agg <- sprintf(
  "         COUNT(%1$s) n_%1$s, CAST(MIN(%1$s) AS STRING) lo_%1$s, CAST(MAX(%1$s) AS STRING) hi_%1$s",
  nm)
# Row count travels with every column so "constant" can mean fully populated.
agg <- c("         COUNT(*) n_rows,", paste0(agg, c(rep(",", length(agg) - 1L), "")))

# --- transpose that one row into 190 rows ------------------------------------
shape  <- vapply(nm, function(x) if (x %in% names(WAIVED)) WAIVED[[x]][1] else "", character(1))
reason <- vapply(nm, function(x) if (x %in% names(WAIVED)) WAIVED[[x]][2] else "", character(1))
stack_rows <- sprintf("    '%1$s', n_%1$s, n_rows, lo_%1$s, hi_%1$s, '%2$s', '%3$s'",
                      nm, shape, reason)
stack_rows <- paste0(stack_rows, c(rep(",", length(stack_rows) - 1L), ""))

out <- c(
"-- =============================================================================",
"-- 03b. ALL-NULL AND CONSTANT-VALUE SWEEP - COMPLETE",
"-- =============================================================================",
"-- GENERATED FILE. Do not edit by hand.",
"--   (the offline harness regenerates and diffs it, so a hand edit fails)",
"--   source: validation/00_column_contract.csv",
"--   generator: validation/make_null_sweep.R",
"--   substitute: ${catalog} / ${schema} / ${ads} before running",
"-- ",
"-- Catalog is pinned below. A validator runs in its OWN SQL session, so the",
"-- catalog the BUILD set on its R connection does not carry over; without this",
"-- a session pointing elsewhere sweeps a same-named table in the wrong catalog",
"-- and reports clean on something that is not the build output.",
"",
"USE CATALOG ${catalog};",
"",
"--   enforced: validation/02_offline_build_check.R regenerates this and fails",
"--               if this copy has drifted from the contract.",
"--",
"-- ${schema} / ${ads} are TEXT-SUBSTITUTION placeholders, not :param markers -",
"-- parameter markers bind values, not object names. Set them as widgets where",
"-- ${...} still resolves (deprecated from DBR 15.2), or find-and-replace with",
"--   ${schema} = <personal schema>   ${ads} = <the ADS table the build wrote>",
"--",
sprintf("-- Covers all %d contract columns. The predecessor listed 31 of them and", length(nm)),
sprintf("-- returned no status, so the other %d could arrive entirely NULL unnoticed.", length(nm) - 31L),
"--",
"-- One pass of COUNT/MIN/MAX answers both questions this sweep asks, exactly,",
"-- and shows the value range as well.",
"--",
"-- NOTE: this checks the SHAPE of a column, never its value. A run stamp",
"-- carrying the WRONG constant reads WAIVED here. Their exact values are",
"-- asserted by V37 in the output validation instead.",
"--",
"-- dth_before_fued is WAIVED as a constant, and gate V45 in the",
"-- output validation FAILS unless it is constant 0. That pair is deliberate,",
"-- not a contradiction: the flag is unreachable by construction, so this sweep",
"-- must not read it as a defect, while V45 keeps proving it never moves.",
"--",
"-- HOW TO READ IT",
"--   status = 'PASS'    populated, and not a single repeated value",
"--   status = 'WAIVED'  exactly the shape its waiver predicts (see `expect`)",
"--   status = 'REVIEW'  waived, but the data no longer matches that shape -",
"--                      an all-null waiver holding a value, or a constant",
"--                      waiver that is empty, partly null, or now varies.",
"--   status = 'FAIL'    all-null, or constant, with no waiver. A defect.",
"--",
"-- Rows sort FAIL first. Do not waive a FAIL by hand here - add it to WAIVED in",
"-- validation/make_null_sweep.R with a reason, and regenerate.",
"-- =============================================================================",
"",
"WITH agg AS (",
"  SELECT",
agg,
"  FROM ${schema}.${ads}",
"),",
"sweep AS (",
sprintf("  SELECT stack(%d,", length(nm)),
stack_rows,
"  ) AS (col, nonnull, n_rows, min_val, max_val, expect, waiver)",
"  FROM agg",
"),",
"-- The waiver is applied AFTER looking at the data, and it must match the SHAPE",
"-- the waiver claims. A waiver that no longer describes the data is REVIEW, not",
"-- a pass - that is precisely when somebody needs to look at it.",
"judged AS (",
"  SELECT col, nonnull, n_rows, min_val, max_val, expect, waiver,",
"         (nonnull = 0) AS is_null,",
"         -- Constant means one value on EVERY row. A column that is 99% one",
"         -- value and 1% null is neither null nor constant, and a waiver that",
"         -- claims constant no longer describes it.",
"         (nonnull = n_rows AND nonnull > 0",
"          AND min_val IS NOT DISTINCT FROM max_val) AS is_const",
"  FROM sweep)",
"-- Fail-closed on REVIEW as well as FAIL, matching validation/03b_null_sweep.R:",
"-- a waiver whose shape the data no longer matches is not a pass.",
"-- @assert none status in FAIL,REVIEW",
"SELECT col, nonnull, n_rows, min_val, max_val, expect, waiver,",
"       CASE WHEN expect = 'null'  AND is_null  THEN 'WAIVED'",
"            WHEN expect = 'const' AND is_const THEN 'WAIVED'",
"            WHEN expect <> ''                  THEN 'REVIEW'",
"            WHEN is_null OR is_const           THEN 'FAIL'",
"            ELSE 'PASS' END AS status",
"FROM   judged",
"-- FAIL first, then REVIEW, then WAIVED, then PASS.",
"ORDER  BY CASE WHEN expect = 'null'  AND is_null  THEN 2",
"               WHEN expect = 'const' AND is_const THEN 2",
"               WHEN expect <> ''                  THEN 1",
"               WHEN is_null OR is_const           THEN 0",
"               ELSE 3 END,",
"          nonnull, col;")

writeLines(out, OUT)
cat("wrote ", OUT, " - ", length(nm), " columns, ",
    sum(nm %in% names(WAIVED)), " waived\n", sep = "")
