# =============================================================================
# MATERIALIZE THE .sql CHECKS AS TABLES - NOTHING IS PULLED INTO THIS SESSION
# =============================================================================
#   Rscript validation/materialize_checks.R                      (delivery set)
#   Rscript validation/materialize_checks.R qc/06_golden_patients.sql   (any files)
#
# The ODBC driver is stable for statements that return no rows - the build's
# 43 stage writes prove it - and crashes on result fetches. So this runs each
# check as CREATE OR REPLACE TABLE ... AS <the check's own SQL>, written into
# the personal schema exactly like a build stage, and fetches nothing. Read
# the results in the Databricks SQL editor: every table is named qcr_<file>_<n>
# and is tiny (gate counts, not patient rows).
#
# The SQL text is not rewritten - the same statements the SQL editor would
# run, wrapped in a CTAS. Drop the qcr_* tables whenever you are done.
#
# THIS UTILITY DOES NOT ENFORCE `-- @assert` DIRECTIVES, AND CANNOT.
# An assertion is evaluated by reading the result, which is the one thing this
# file exists to avoid. It used to strip the directives with the rest of the
# comments, so a file whose assertions bind through run_sql.R came through here
# as a set of tables with nothing checked and no sign that anything had been
# skipped. It now collects every directive it passes over, prints it beside the
# table that would have been tested, and lists them all again at the end.
#
# So: use validation/run_sql.R when you want the check to BIND. Use this when
# the driver cannot fetch and you will read the tables yourself.
# =============================================================================

DELIVERY_SET <- c("validation/03_output_validation_databricks.sql",
                  "validation/03b_null_sweep.sql",
                  "qc/03_cross_variable_rules.sql",
                  "qc/08_death_date_formats.sql",
                  "qc/09_vitals_domain.sql")

files <- commandArgs(trailingOnly = TRUE)
if (!length(files)) files <- DELIVERY_SET
missing_files <- files[!file.exists(files)]
if (length(missing_files))
  stop("no such file: ", paste(missing_files, collapse = ", "), call. = FALSE)

# RENDER_ONLY's reading and the placeholder fallbacks are shared with
# run_sql.R. Written separately here, this file read RENDER_ONLY as "set to
# anything" (so RENDER_ONLY=0 turned rendering ON) and ignored RDAP_HRR_PANEL
# in its ${ads} fallback - both already fixed in the sibling, both still here.
source("validation/00_render_names.R")
# The directive grammar, shared with run_sql.R. Collecting a directive without
# validating it is worse than not collecting it: the "NOT CHECKED" line below
# would then print a typo as though it were a condition somebody could verify.
source("validation/00_sql_directives.R")

render_only <- render_only_requested()
if (!render_only) {
  if (!exists("con")) {
    message("no open connection - sourcing validation/00_connect.R")
    source("validation/00_connect.R")
  }
  stopifnot(exists("con"), exists("output_catalog"), exists("personal_schema"),
            exists("output_table"), exists("source_schema"))
}

SUBS <- render_subs()
PSCHEMA <- SUBS[["${schema}"]]

# Returns $sql (one entry per statement) and $asserts (a character vector per
# statement, empty where there are none). Directives are read BEFORE comments
# are stripped - reading them after is how they used to disappear - and they
# attach to the NEXT statement, exactly as run_sql.R binds them.
read_statements <- function(path) {
  raw <- readLines(path, warn = FALSE)
  stmts <- character(0); asserts <- list(); buf <- character(0)
  pend <- character(0)
  for (l in raw) {
    d <- regmatches(l, regexec("^\\s*--\\s*@assert\\s+(.+?)\\s*$", l))[[1]]
    if (length(d) == 2L) {
      parse_assert(d[2], path)          # hard error on a malformed directive
      pend <- c(pend, trimws(d[2])); next
    }
    code <- sub("--.*$", "", l)
    if (!nzchar(trimws(code))) next
    buf <- c(buf, code)
    if (grepl(";\\s*$", code)) {
      stmts <- c(stmts, sub(";\\s*$", "", paste(buf, collapse = "\n")))
      asserts[[length(stmts)]] <- pend
      buf <- character(0); pend <- character(0)
    }
  }
  if (length(buf)) {
    stmts <- c(stmts, paste(buf, collapse = "\n"))
    asserts[[length(stmts)]] <- pend
  } else if (length(pend)) {
    stop(path, ": @assert directives trail the last statement with nothing to ",
         "attach to", call. = FALSE)
  }
  list(sql = stmts, asserts = asserts)
}

made <- character(0)
# Every assertion this run passed over, as "table  <-  directive", so the
# closing summary can name what is unchecked and where to look.
unchecked <- character(0)
for (f in files) {
  tag   <- gsub("[^a-z0-9]", "", sub("_.*$", "", basename(f)))
  tag   <- paste0(if (grepl("^validation/", f)) "val" else "qc", tag)
  parsed  <- read_statements(f)
  stmts   <- parsed$sql
  st_asrt <- parsed$asserts
  for (nm in names(SUBS)) stmts <- gsub(nm, SUBS[[nm]], stmts, fixed = TRUE)
  cat("\n==== ", f, " (", length(stmts), " statements) ====\n", sep = "")

  for (i in seq_along(stmts)) {
    s     <- stmts[[i]]
    first <- toupper(trimws(strsplit(s, "\n")[[1]][1]))
    if (grepl("^(USE)\\b", first)) {
      cat("[", i, "] ", trimws(strsplit(s, "\n")[[1]][1]), "\n", sep = "")
      if (!render_only) DBI::dbExecute(con, s)
      next
    }
    # Only SELECT/WITH can be wrapped in a CTAS. SHOW, DESCRIBE and EXPLAIN
    # return rows but cannot be, so they are skipped - and they CARRY
    # ASSERTIONS: the snapshot files guard migration with `-- @assert no-rows`
    # on a SHOW TABLES. Skipping used to drop those directives before the
    # reporting below ever saw them, which is the one case where this utility
    # both failed to run a check and failed to say so. Report first, skip after.
    a <- if (i <= length(st_asrt)) st_asrt[[i]] else character(0)
    if (!grepl("^(SELECT|WITH)\\b", first)) {
      cat("[", i, "] skipped (", substr(first, 1, 12),
          ") - cannot be wrapped in a CTAS; run it in the SQL editor\n", sep = "")
      if (length(a)) {
        for (one in a) cat("      NOT CHECKED: @assert ", one, "\n", sep = "")
        unchecked <- c(unchecked,
                       sprintf("%s [%d] (%s, not materialized)  @assert %s",
                               f, i, substr(first, 1, 8), a))
      }
      next
    }
    tname <- sprintf("qcr_%s_%02d", tag, i)
    ddl   <- paste0("CREATE OR REPLACE TABLE ", PSCHEMA, ".", tname, " AS\n", s)
    cat("[", i, "] -> ", PSCHEMA, ".", tname, "\n", sep = "")
    if (length(a)) {
      for (one in a) cat("      NOT CHECKED: @assert ", one, "\n", sep = "")
      unchecked <- c(unchecked, sprintf("%s.%s  @assert %s", PSCHEMA, tname, a))
    }
    if (render_only) next
    DBI::dbExecute(con, ddl)
    made <- c(made, paste0(PSCHEMA, ".", tname))
  }
}

if (!render_only) {
  cat("\nDONE - ", length(made), " result table(s) written, nothing fetched.\n",
      "Read them in the Databricks SQL editor / Catalog:\n  ",
      paste(made, collapse = "\n  "), "\n", sep = "")
  dir.create("qc_outputs", showWarnings = FALSE)
  writeLines(made, "qc_outputs/materialized_tables.txt")
}

# The point of the summary: a clean finish here is NOT a pass. Say so, every
# time, with the list - otherwise the absence of a complaint reads as one.
if (length(unchecked)) {
  cat("\n", strrep("-", 72), "\n",
      length(unchecked), " ASSERTION(S) WERE NOT EVALUATED. This utility cannot\n",
      "evaluate them - it never reads a result. Nothing above is a pass:\n\n  ",
      paste(unchecked, collapse = "\n  "),
      "\n\nRun `Rscript validation/run_sql.R <file.sql>` to have these bind, or\n",
      "read each table listed above and check the condition by eye.\n",
      strrep("-", 72), "\n", sep = "")
} else {
  cat("\nNo @assert directives in the file(s) given - nothing was skipped.\n")
}
