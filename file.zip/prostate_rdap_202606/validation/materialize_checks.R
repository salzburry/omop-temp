# =============================================================================
# MATERIALIZE THE .sql CHECKS AS TABLES - NOTHING IS PULLED INTO THIS SESSION
# =============================================================================
#   Rscript validation/materialize_checks.R                      (delivery set)
#   Rscript validation/materialize_checks.R qc/06_golden_patients.sql   (any files)
#
# The ODBC driver is stable for statements that return no rows - the build's
# 43 stage writes prove it - and crashes on result fetches. So this runs each
# check as CREATE OR REPLACE TABLE ... AS <the check's own SQL>, written into
# the personal schema exactly like a build stage, and fetches nothing. Read
# the results in the Databricks SQL editor: every table is named qcr_<file>_<n>
# and is tiny (gate counts, not patient rows).
#
# The SQL text is not rewritten - the same statements the SQL editor would
# run, wrapped in a CTAS. Drop the qcr_* tables whenever you are done.
# =============================================================================

DELIVERY_SET <- c("validation/03_output_validation_databricks.sql",
                  "validation/03b_null_sweep.sql",
                  "qc/03_cross_variable_rules.sql",
                  "qc/08_death_date_formats.sql",
                  "qc/09_vitals_domain.sql")

files <- commandArgs(trailingOnly = TRUE)
if (!length(files)) files <- DELIVERY_SET
missing_files <- files[!file.exists(files)]
if (length(missing_files))
  stop("no such file: ", paste(missing_files, collapse = ", "), call. = FALSE)

render_only <- nzchar(Sys.getenv("RENDER_ONLY"))
if (!render_only) {
  if (!exists("con")) {
    message("no open connection - sourcing validation/00_connect.R")
    source("validation/00_connect.R")
  }
  stopifnot(exists("con"), exists("output_catalog"), exists("personal_schema"),
            exists("output_table"), exists("source_schema"))
}

SUBS <- c("${catalog}" = get0("output_catalog",  ifnotfound = "hive_metastore"),
          "${schema}"  = get0("personal_schema", ifnotfound = "osk02156"),
          "${ads}"     = get0("output_table",    ifnotfound = "rwdp_pros_pano_2026m06"),
          "${src}"     = get0("source_schema",   ifnotfound = "clnprw_flatiron_pano_pros_use"))
PSCHEMA <- SUBS[["${schema}"]]

read_statements <- function(path) {
  ln <- sub("--.*$", "", readLines(path, warn = FALSE))
  ln <- ln[nzchar(trimws(ln))]
  stmts <- character(0); buf <- character(0)
  for (l in ln) {
    buf <- c(buf, l)
    if (grepl(";\\s*$", l)) {
      stmts <- c(stmts, sub(";\\s*$", "", paste(buf, collapse = "\n")))
      buf <- character(0)
    }
  }
  if (length(buf)) stmts <- c(stmts, paste(buf, collapse = "\n"))
  stmts
}

made <- character(0)
for (f in files) {
  tag   <- gsub("[^a-z0-9]", "", sub("_.*$", "", basename(f)))
  tag   <- paste0(if (grepl("^validation/", f)) "val" else "qc", tag)
  stmts <- read_statements(f)
  for (nm in names(SUBS)) stmts <- gsub(nm, SUBS[[nm]], stmts, fixed = TRUE)
  cat("\n==== ", f, " (", length(stmts), " statements) ====\n", sep = "")

  for (i in seq_along(stmts)) {
    s     <- stmts[[i]]
    first <- toupper(trimws(strsplit(s, "\n")[[1]][1]))
    if (grepl("^(USE)\\b", first)) {
      cat("[", i, "] ", trimws(strsplit(s, "\n")[[1]][1]), "\n", sep = "")
      if (!render_only) DBI::dbExecute(con, s)
      next
    }
    if (!grepl("^(SELECT|WITH)\\b", first)) {
      cat("[", i, "] skipped (", substr(first, 1, 12),
          ") - run it in the SQL editor if needed\n", sep = "")
      next
    }
    tname <- sprintf("qcr_%s_%02d", tag, i)
    ddl   <- paste0("CREATE OR REPLACE TABLE ", PSCHEMA, ".", tname, " AS\n", s)
    cat("[", i, "] -> ", PSCHEMA, ".", tname, "\n", sep = "")
    if (render_only) next
    DBI::dbExecute(con, ddl)
    made <- c(made, paste0(PSCHEMA, ".", tname))
  }
}

if (!render_only) {
  cat("\nDONE - ", length(made), " result table(s) written, nothing fetched.\n",
      "Read them in the Databricks SQL editor / Catalog:\n  ",
      paste(made, collapse = "\n  "), "\n", sep = "")
  dir.create("qc_outputs", showWarnings = FALSE)
  writeLines(made, "qc_outputs/materialized_tables.txt")
}
