-- =============================================================================
-- 202606 prostate PANO RWDP - source-only question pack
-- =============================================================================
-- Everything in this file reads the SOURCE tables. Nothing reads the delivered
-- table, so it runs BEFORE the rebuild and its answers do not change when the
-- rebuild happens. Paste it whole into the SQL editor, or:
--
--     Rscript validation/run_sql.R <this file>
--
-- Assembled from validation/01_preflight_databricks.sql and
-- validation/04_open_question_queries.sql - those two remain the originals. If
-- you change a query, change it there and re-assemble, or the two will drift.
--
-- Catalog, schema and source are written as literals below. Change these three
-- lines if you point at a different cut:
--     catalog hive_metastore
--     schema  osk02156    (not read by this file - no output is written)
--     source  clnprw_flatiron_pano_pros_use
--
-- Nothing here writes. Every statement is a SELECT, so it is safe to re-run.
--
-- WHAT IT ANSWERS, and the ONE result that must be zero
--
--   Part 1  B1-B18 preflight gates. Every row marked MANDATORY must read PASS.
--           B18 MUST READ ZERO - a populated but unparseable DATEOFDEATH. Under
--           the 2026-09-11 ruling those patients escape the per-cohort death
--           exclusion entirely. A nonzero B18 is BOTH a membership and a
--           censoring defect - the exclusion cannot fire AND DTHFL reads 0, so
--           the patient ships as censored with OS measuring follow-up rather
--           than survival. The right time to catch it is now, before the build.
--   Part 2  B10 PSMA same-date conflicts. NOT a gate - a reading. It counts
--           conflicts on ANY scan date, not only the winning pre-index one, so
--           treat it as an upper bound.
--   Part 3  C10 / C10c / C10d lab analytes and the albumin scale.
--   Part 4  D8 reference cohort counts, derived from source WITH the 2026-09-11
--           exclusion applied. Expect these BELOW the frozen 2026-08-09
--           baseline of 197,903 / 134,281 / 79,051 / 50,502 / 28,980 / 16,073 /
--           8,616. Every cohort is expected to fall; the question is whether
--           the exclusion explains all of it.
--   Part 5  Queries that rebuild cohort
--           membership from source and CARRY the exclusion, so their counts and
--           percentages describe the post-ruling population. This is what
--           re-measures the 10,170 / 6.1% / 10.5% and the ~17%.
--
-- WHAT IT CANNOT ANSWER
--   Anything comparing the old table against the new one (00b B0-B5), anything
--   reading the delivered table (V-gates, null sweep, qc/01-03, sizing), and
--   the four decisions that are rulings rather than measurements: the open follow-up disposition
--   acceptance.
--
-- Part 1 carries `-- @assert` directives, so under validation/run_sql.R a
-- nonzero MANDATORY gate - B18 included - prints the table and then STOPS the
-- run with a nonzero exit. Pasted into the SQL editor instead, the directives
-- are ordinary comments and enforce nothing: read the failed column yourself.
-- RP1-RP4 and W1-W3 are the 2026-09-11 ruling's four rules and the three
-- behaviours they withdraw, defined in docs/VARIABLES.md section 3.
-- =============================================================================

USE CATALOG hive_metastore;
USE SCHEMA  clnprw_flatiron_pano_pros_use;


-- -----------------------------------------------------------------------------
-- PART 1  Preflight gates B1-B18   (B18 must read zero)
--
-- @assert zero failed when severity=MANDATORY
-- @assert none status in FAIL
-- -----------------------------------------------------------------------------
WITH
b1 AS (SELECT COUNT(*) AS n FROM (
         SELECT patientid, linesetting, startdate
         FROM   clnprw_flatiron_pano_pros_use.t_enh_prostate_lot_2026m06
         WHERE  linesetting IN ('mHSPC','mCRPC')
         GROUP  BY patientid, linesetting, startdate HAVING COUNT(*) > 1)),
b2 AS (SELECT COUNT(*) AS n FROM (
         SELECT patientid FROM clnprw_flatiron_pano_pros_use.t_enh_prostate_2026m06
         GROUP BY patientid HAVING COUNT(*) > 1)),
-- B3/B4/B5 must each mirror the shape the BUILD actually joins on, or the SQL
-- gate and the R gate disagree about what counts as a duplicate.
--   B3 mortality  - joined as SELECT DISTINCT patientid, dateofdeath, <derived>,
--                   so an exact duplicate row is collapsed before the join and
--                   only conflicting death dates fan out. DISTINCT is correct.
--   B4 demographics and B5 social determinants - joined raw, so any duplicate
--                   row fans the clinical block out. No DISTINCT: de-duplicating
--                   first blinds the check to exact-duplicate rows.
b3 AS (SELECT COUNT(*) AS n FROM (
         SELECT patientid FROM (
           SELECT DISTINCT patientid, dateofdeath FROM clnprw_flatiron_pano_pros_use.t_mortality_v2_2026m06)
         GROUP BY patientid HAVING COUNT(*) > 1)),
b4 AS (SELECT COUNT(*) AS n FROM (
         SELECT patientid FROM clnprw_flatiron_pano_pros_use.t_demographics_2026m06
         GROUP BY patientid HAVING COUNT(*) > 1)),
b5 AS (SELECT COUNT(*) AS n FROM (
         SELECT patientid FROM clnprw_flatiron_pano_pros_use.t_socdetofhealth_2026m06
         GROUP BY patientid HAVING COUNT(*) > 1)),
b6 AS (SELECT COUNT(*) AS n FROM (
         SELECT patientid, linesetting, linenumber
         FROM   clnprw_flatiron_pano_pros_use.t_enh_prostate_lot_2026m06
         WHERE  linesetting IN ('mHSPC','mCRPC')
         GROUP  BY patientid, linesetting, linenumber HAVING COUNT(*) > 1)),
-- B7. GENE-INVENTORY DRIFT. The 19 symbols below are the D5pre inventory on
-- the 2026-08 cut - the exact union of the FDA olaparib mCRPC label panel
-- (14) and TALAPRO-2 (12).
--
-- WARN, not a build stop: HRR is 4 of 190 columns and the build should still
-- produce the ADS. The build freezes `flatiron_all` to these 19 named symbols, so a
-- gene added to a future cut is excluded rather than absorbed - it
-- classifies as not-HRR and the build announces it on startup. Either way the
-- case definition moves, which is what this check surfaces.
-- Nothing downstream gates on it: V2b asks a reader to confirm the panel
-- against the manifest, and there is no publication step it could block.
b7 AS (SELECT COUNT(DISTINCT UPPER(biomarkername)) AS n
       FROM   clnprw_flatiron_pano_pros_use.t_enh_prostate_biomarker_2026m06
       WHERE  UPPER(biomarkername) NOT IN
              ('ATM','BARD1','BRCA1','BRCA2','BRIP1','CDK12','CHEK1','CHEK2',
               'FANCL','PALB2','RAD51B','RAD51C','RAD51D','RAD54L',
               'ATR','FANCA','MLH1','MRE11A','NBN')),
-- Values that would raise under ANSI CAST. The script uses TRY_CAST, so these
-- become NULL rather than aborting; a nonzero count is a data-quality warning,
-- not a build stop.
b8 AS (SELECT COUNT(*) AS n FROM clnprw_flatiron_pano_pros_use.t_ecog_2026m06
       WHERE ecogvalue IS NOT NULL AND TRY_CAST(ecogvalue AS INT) IS NULL),
b9 AS (SELECT COUNT(*) AS n FROM clnprw_flatiron_pano_pros_use.t_vitals_2026m06
       WHERE LOWER(test) LIKE '%blood pressure%'
         AND testresult IS NOT NULL AND TRY_CAST(testresult AS DOUBLE) IS NULL),
-- B12. NEW_LOT_N is ROW_NUMBER() OVER (... ORDER BY startdate). A NULL
-- startdate has no defined position in that ordering, so the line numbering -
-- and therefore the index date of every treated cohort - would be arbitrary.
-- B1 catches ties only; it cannot see a lone NULL startdate. MANDATORY.
b12 AS (SELECT COUNT(*) AS n FROM clnprw_flatiron_pano_pros_use.t_enh_prostate_lot_2026m06
        WHERE linesetting IN ('mHSPC','mCRPC') AND startdate IS NULL),
-- B13. The 17 treatment categories are decided by parsing LINENAME, and the
-- parser knows exactly two separators: comma and slash. A regimen joined by a
-- semicolon, a plus or a pipe is not rejected - it is read as one drug name,
-- matches no monotherapy test and no combination test, and lands silently in
-- category 16 "Any other therapy". LOTnCAT is a headline variable and nothing
-- downstream would report the misclassification. MANDATORY
-- (ruled 2026-08-08).
--
-- Deliberately narrow: separator punctuation only. Drug names legitimately
-- contain hyphens (Radium-223, Sipuleucel-T) and spaces (Clinical Study Drug),
-- so those are not flagged.
b13 AS (SELECT COUNT(*) AS n FROM clnprw_flatiron_pano_pros_use.t_enh_prostate_lot_2026m06
        WHERE linesetting IN ('mHSPC','mCRPC')
          AND linename IS NOT NULL
          AND NOT linename RLIKE '^[A-Za-z0-9.()-]+( [A-Za-z0-9.()-]+)*([,/][A-Za-z0-9.()-]+( [A-Za-z0-9.()-]+)*)*$'),
-- B14. The same contract on the drug-episode table. B13 covers only the LOT
-- table; PRIOR_PARP and PRIOR_NHA_ADT parse LINENAME from drug episodes, so
-- an unexpected separator there changes a delivered flag without tripping B13.
-- MANDATORY.
b14 AS (SELECT COUNT(*) AS n FROM clnprw_flatiron_pano_pros_use.t_enh_prostate_drg_epsode_2026m06
        WHERE linename IS NOT NULL
          AND NOT linename RLIKE '^[A-Za-z0-9.()-]+( [A-Za-z0-9.()-]+)*([,/][A-Za-z0-9.()-]+( [A-Za-z0-9.()-]+)*)*$'),
-- B15/B16. LINESETTING is matched exactly in the build - `IN ('mHSPC','mCRPC')`
-- for the cohorts and `= setting` for the per-line episode look-up. A variant
-- spelling or a stray space raises nothing: the row is simply not selected, so
-- the line disappears from its cohort, from NEW_LOT_N and from every LOTn
-- variable, while the table still looks complete. MANDATORY, both tables.
b15 AS (SELECT COUNT(*) AS n FROM clnprw_flatiron_pano_pros_use.t_enh_prostate_lot_2026m06
        WHERE linesetting IS NOT NULL
          AND LOWER(TRIM(linesetting)) IN ('mhspc','mcrpc')
          AND linesetting NOT IN ('mHSPC','mCRPC')),
b16 AS (SELECT COUNT(*) AS n FROM clnprw_flatiron_pano_pros_use.t_enh_prostate_drg_epsode_2026m06
        WHERE linesetting IS NOT NULL
          AND LOWER(TRIM(linesetting)) IN ('mhspc','mcrpc')
          AND linesetting NOT IN ('mHSPC','mCRPC')),
-- B17. The parser takes a comma as proof of a second drug, so
-- 'abiraterone,abiraterone' reads as an NHA combination rather than abiraterone
-- monotherapy. B13 and B14 pass it, because the format is legal. Detect the
-- repeated token instead. MANDATORY, both tables.
--
-- Split on comma only. The slash is not a regimen separator here - it binds
-- inside one product name (Niraparib/Abiraterone, Decitabine/Cedazuridine,
-- Daratumumab/Hyaluronidase-Fihj), so splitting on [,/] misreads
-- 'Abiraterone,Leuprolide,Niraparib/Abiraterone' as a repeated abiraterone and
-- flags ordinary rows.
-- Scope must match the R gate exactly: the two settings on the LOT table,
-- because only those feed the categories, and every drug-episode row, because
-- the prior-drug flags read those whatever the setting. A wider scan (e.g. all
-- LOT settings) fails rows the build never parses, so this check and the build
-- disagree.
b17 AS (SELECT COUNT(*) AS n FROM (
          SELECT linename FROM clnprw_flatiron_pano_pros_use.t_enh_prostate_lot_2026m06
           WHERE linesetting IN ('mHSPC','mCRPC')
          UNION ALL
          SELECT linename FROM clnprw_flatiron_pano_pros_use.t_enh_prostate_drg_epsode_2026m06) u
        WHERE linename IS NOT NULL
          AND SIZE(SPLIT(LOWER(linename), ','))
              <> SIZE(ARRAY_DISTINCT(SPLIT(LOWER(linename), ',')))),
-- B18. DATEOFDEATH populated but unparseable. keeps the
-- derivation spec-literal - 5B.ClinChars r90 documents month-and-year and
-- year-only and nothing else, so any other length falls to NULL - and that
-- hole used only to MEASURE badly: a dead patient read as censored, DTHFL 0
-- and OS taken to the follow-up end. qc/08_death_date_formats.sql sizes that.
--
-- Rule RP4 promotes it to a MEMBERSHIP defect, which is why it
-- is a gate now and was not before. The build keeps a cohort row when
-- `dthdt IS NULL OR index_date <= dthdt`, and an unparseable
-- DATEOFDEATH lands on that first limb, so the patient is silently NOT
-- excluded anywhere: they keep cohort rows the ruling says they should lose,
-- and the ADS carries an index date after a death the source recorded. No
-- output check can recover the exclusion once the date is gone, because the
-- date is the only thing the exclusion reads.
--
-- Both failure shapes count: the wrong length (the own hole) and the right
-- length with unusable content ('2020-13', '2020/03'), which is why the test
-- is the build's own CASE rather than a LENGTH() test. MANDATORY.
b18 AS (SELECT COUNT(*) AS n FROM clnprw_flatiron_pano_pros_use.t_mortality_v2_2026m06
        WHERE dateofdeath IS NOT NULL
          AND CASE
                WHEN LENGTH(dateofdeath) = 7 THEN TRY_CAST(CONCAT(dateofdeath, '-15') AS DATE)
                WHEN LENGTH(dateofdeath) = 4 THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
                ELSE NULL END IS NULL)
SELECT 'B1' AS check_id, 'no same-day LOT ties (NEW_LOT_N determinism)' AS what,
       n AS failed, 'MANDATORY' AS severity,
       CASE WHEN n = 0 THEN 'PASS' ELSE 'FAIL' END AS status FROM b1
UNION ALL SELECT 'B2','t_enh_prostate one row per patient',        n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b2
UNION ALL SELECT 'B3','t_mortality_v2 one row per patient',        n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b3
UNION ALL SELECT 'B4','t_demographics one row per patient',        n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b4
UNION ALL SELECT 'B5','t_socdetofhealth one row per patient',      n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b5
UNION ALL SELECT 'B6','linenumber unique per patient+setting',     n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b6
UNION ALL SELECT 'B7','gene inventory unchanged from the frozen 19', n,'WARN', CASE WHEN n=0 THEN 'PASS' ELSE 'WARN' END FROM b7
UNION ALL SELECT 'B8','ECOG values castable to INT',               n,'WARN',     CASE WHEN n=0 THEN 'PASS' ELSE 'WARN' END FROM b8
UNION ALL SELECT 'B9','BP results castable to DOUBLE',             n,'WARN',     CASE WHEN n=0 THEN 'PASS' ELSE 'WARN' END FROM b9
UNION ALL SELECT 'B12','no NULL LOT StartDate in mHSPC/mCRPC',     n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b12
UNION ALL SELECT 'B13','LOT LINENAME separator/whitespace contract', n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b13
UNION ALL SELECT 'B14','drugepisode LINENAME separator/whitespace contract', n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b14
UNION ALL SELECT 'B15','LOT LINESETTING exact form (no case or space variants)', n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b15
UNION ALL SELECT 'B16','drugepisode LINESETTING exact form',       n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b16
UNION ALL SELECT 'B17','no LINENAME with a repeated drug token',   n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b17
UNION ALL SELECT 'B18','DATEOFDEATH populated but unparseable - the death exclusion cannot fire', n,'MANDATORY',CASE WHEN n=0 THEN 'PASS' ELSE 'FAIL' END FROM b18
ORDER BY check_id;

-- -----------------------------------------------------------------------------
-- PART 2  B10  PSMA same-date conflicts - a reading, not a gate
-- -----------------------------------------------------------------------------
-- B10. Not a gate: PSMA scans on the same date with conflicting evidence.
--      These occur. The build rules that a Yes and a No on the same date give
--      'Unknown/not documented', not MAX(isdiseaseevidence).
SELECT patientid, scandate, COUNT(*) n, COLLECT_SET(isdiseaseevidence) results
FROM   clnprw_flatiron_pano_pros_use.t_enh_prostate_psmapet_2026m06
GROUP  BY patientid, scandate
HAVING COUNT(DISTINCT isdiseaseevidence) > 1
LIMIT  50;

-- -----------------------------------------------------------------------------
-- PART 3  C10 / C10c / C10d  lab analytes and the albumin scale
-- -----------------------------------------------------------------------------
-- C10. Lab analytes: expected vs found. Mandatory.
--      Mandatory means it binds: a missing analyte stops the run.
-- @assert none status in FAIL
--      Reporting only what exists cannot surface an analyte that is entirely
--      absent, so the expected combinations are listed and LEFT JOINed.
--      PASS: every row has found_rows > 0.
--      A NULL in the `unit` column means "any unit" - the analyte must exist,
--      but the build applies no unit filter to it.
--      the build filters albumin to g/L. On the 2026-08 cut,
--      labcomponent='Albumin, serum' carries testunitscleaned='g/L' on
--      4,966,771 rows / 308,946 patients, median 40 - the g/L range (35-50),
--      not g/dL (3.5-5.0). If albumin/g/L returns 0 rows here, LABALBV and
--      LABALBDT deliver NULL everywhere (the status reads Missing/Unknown),
--      so the run must stop.
WITH expected AS (
  SELECT * FROM VALUES
    ('neutrophils','10*9/L',NULL),
    ('platelets','10*9/L',NULL),
    ('hemoglobin','g/dL',NULL),
    ('creatinine','mg/dL','Creatinine, serum'),
    ('bilirubin','mg/dL',NULL),
    ('aspartate aminotransferase','U/L',NULL),
    ('alanine aminotransferase','U/L',NULL),
    ('alkaline phosphatase','U/L',NULL),
    ('albumin','g/L','Albumin, serum'),
    ('lymphocytes','10*9/L',NULL)
  AS t(testbasename, unit, component)
),
found AS (
  -- TRIM, matching production's unit rule: the build compares trimmed
  -- units for all ten analytes, so a raw compare here would refuse a source
  -- the build accepts.
  SELECT LOWER(testbasename) tb, TRIM(testunitscleaned) u, labcomponent lc, COUNT(*) n
  FROM   clnprw_flatiron_pano_pros_use.t_lab_2026m06 GROUP BY 1,2,3
)
SELECT e.testbasename, COALESCE(e.unit,'(any unit)') unit, e.component,
       COALESCE(SUM(f.n), 0) AS found_rows,
       CASE WHEN COALESCE(SUM(f.n),0) > 0 THEN 'PASS' ELSE 'FAIL' END AS status
FROM   expected e
LEFT JOIN found f
       ON f.tb = e.testbasename
      AND (e.unit      IS NULL OR f.u  = e.unit)
      AND (e.component IS NULL OR f.lc = e.component)
GROUP  BY e.testbasename, e.unit, e.component
ORDER  BY status, e.testbasename;

-- @assert none status in FAIL
-- C10c. ALBUMIN SCALE - a reading, kept as the evidence behind  (the build
--       applies the spec's g/L filter, so LABALBV is g/L by construction).
--       Classify each row by value to see which scale the source is on.
--       Grouping by unit gives one group and one median, which cannot see a
--       mixture living inside it: 50/50 g/dL and g/L medians around 17-20,
--       and 90/10 medians inside the majority band and hides the rest.
--       Classifying each row does see it. 3.5-5.0 g/dL == 35-50 g/L is a clean
--       10x with no overlap, so a row lands in exactly one band.
--       PASS: one band holds >= 99% of rows. Read C10d as well.
WITH banded AS (
  SELECT CASE WHEN testresultcleaned BETWEEN  1.5 AND  7.0 THEN 'g/dL'
              WHEN testresultcleaned BETWEEN 15.0 AND 70.0 THEN 'g/L'
              ELSE 'OUT OF BOTH BANDS' END AS band
  FROM   clnprw_flatiron_pano_pros_use.t_lab_2026m06
  WHERE  LOWER(testbasename) = 'albumin' AND labcomponent = 'Albumin, serum'
  AND    testresultcleaned > 0),
tally AS (
  SELECT band, COUNT(*) n, SUM(COUNT(*)) OVER () total FROM banded GROUP BY band)
SELECT 'C10c' check_id,
       'serum albumin on ONE scale (row-level)' what,
       CONCAT_WS(', ', SORT_ARRAY(COLLECT_LIST(
         CONCAT(band, '=', CAST(ROUND(100.0*n/total, 2) AS STRING), '%')))) distribution,
       -- B2.12: the band that holds >= 99% must be **g/L**, not merely SOME
       -- band. `MAX over any non-out-of-bands band` passed a source that was
       -- 99% g/dL - and production filters on the spec's g/L unit, so it would
       -- have discarded almost every albumin record while this gate read PASS.
       -- The current cut is 99.91% g/L, so this is refresh-drift protection,
       -- not a claim that today's LABALBV is wrong.
       CASE WHEN MAX(CASE WHEN band = 'g/L' THEN 100.0*n/total ELSE 0 END) >= 99.0
            THEN 'PASS' ELSE 'FAIL' END status
FROM   tally;

-- C10d. If C10c passes, this names the winning scale so it can be compared
--       with the LABALBV label (which reads g/L). Recorded with the release.
SELECT CASE WHEN testresultcleaned BETWEEN  1.5 AND  7.0 THEN 'g/dL'
            WHEN testresultcleaned BETWEEN 15.0 AND 70.0 THEN 'g/L'
            ELSE 'OUT OF BOTH BANDS' END AS delivered_scale,
       COUNT(*) n,
       MIN(testresultcleaned) min_val,
       PERCENTILE(testresultcleaned, 0.5) median_val,
       MAX(testresultcleaned) max_val
FROM   clnprw_flatiron_pano_pros_use.t_lab_2026m06
WHERE  LOWER(testbasename) = 'albumin' AND labcomponent = 'Albumin, serum'
AND    testresultcleaned > 0
GROUP  BY 1 ORDER BY n DESC;

-- -----------------------------------------------------------------------------
-- PART 4  D8  reference cohort counts, exclusion applied   (the 2026-09-11 ruling)
-- -----------------------------------------------------------------------------
-- D8. REFERENCE COHORT COUNTS. Derived independently of the R build; V26 in
--     03_output_validation_databricks.sql compares the ADS against these. (Not
--     V12 - that is the REGION1/REGION1N mapping gate and has nothing to do
--     with cohort sizes.)
--
--     PRE-RULING BASELINE - these numbers are NOT current. They were taken on the
--     2026-08 cut, before the 2026-09-11 follow-up ruling added the per-cohort
--     death exclusion applied below, so every one of them is a pre-exclusion
--     figure and each can only fall:
--       1 Overall mHSPC     197903      5 L2+ treated mCRPC  28980
--       2 Overall mCRPC     134281      6 L3+ treated mCRPC  16073
--       3 L1+ treated mHSPC  79051      7 L4+ treated mCRPC   8616
--       4 L1+ treated mCRPC  50502      TOTAL ADS ROWS      515406
--     Re-run this query for the current reference counts; the gap against the
--     figures above is the impact of the ruling, and D9 sizes the same drop
--     from the other side for cohorts 3-7.
--
--     THE DEATH EXCLUSION IS PART OF THE DERIVATION. Without
--     it this query would hand V26 a pre-exclusion number in perpetuity, and
--     V26 would read FAIL on a correct build for as long as the ruling stands.
--     The rule: drop the patient from a cohort when that cohort's index date
--     falls AFTER their death date. Per cohort, not per patient - a patient can
--     hold their place in Overall, L1 and L2 and still be dropped from L3 when
--     the third line starts after the death date, so the test is written into
--     each branch against that branch's own index date (the milestone for
--     cohorts 1-2, the line start for cohorts 3-7).
WITH ms AS (
  SELECT patientid,
         GREATEST(metastaticdiagnosisdate, hspcdate) mhspcdd,
         GREATEST(metastaticdiagnosisdate, crpcdate) mcrpcdd
  FROM   clnprw_flatiron_pano_pros_use.t_enh_prostate_2026m06),
lot AS (
  SELECT patientid, linesetting, startdate,
         ROW_NUMBER() OVER (PARTITION BY patientid, linesetting ORDER BY startdate) new_lot_n
  FROM   clnprw_flatiron_pano_pros_use.t_enh_prostate_lot_2026m06
  WHERE  linesetting IN ('mHSPC','mCRPC')),
-- The whole of the imputation: the middle of the month, the middle of the
-- year for a year-only value, nothing further. Derived here from the mortality
-- source rather than read back from the build, because this query exists to be
-- an independent derivation. TRY_CAST, never CAST - '2020-13' is seven
-- characters and is not a date, and under ANSI a plain CAST would abort the
-- query rather than read NULL. Any other length falls to NULL by design
--, which B18 above gates precisely because a NULL here cannot
-- exclude anybody.
--
-- DISTINCT so a patient carrying more than one mortality row cannot fan the
-- joins out; B3 is the gate that the rows do not disagree. COUNT(DISTINCT
-- patientid) below is fan-out-proof in any case.
dth AS (
  SELECT DISTINCT patientid,
         CASE
           WHEN LENGTH(dateofdeath) = 7 THEN TRY_CAST(CONCAT(dateofdeath, '-15') AS DATE)
           WHEN LENGTH(dateofdeath) = 4 THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
           ELSE NULL END AS dthdt
  FROM   clnprw_flatiron_pano_pros_use.t_mortality_v2_2026m06)
-- LEFT JOIN, not JOIN: a patient with no mortality row must not be dropped.
-- `d.dthdt IS NULL OR <index> <= d.dthdt` keeps everyone with no usable death
-- date, and the test is strict - a death ON the index date KEEPS the patient,
-- because the ruling excludes an index after the death, not on it.
SELECT 1 cohortn, 'Overall mHSPC' cohort, COUNT(DISTINCT m.patientid) n
FROM   ms m LEFT JOIN dth d ON d.patientid = m.patientid
WHERE  m.mhspcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
AND   (d.dthdt IS NULL OR m.mhspcdd <= d.dthdt)
UNION ALL
SELECT 2, 'Overall mCRPC', COUNT(DISTINCT m.patientid)
FROM   ms m LEFT JOIN dth d ON d.patientid = m.patientid
WHERE  m.mcrpcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
AND   (d.dthdt IS NULL OR m.mcrpcdd <= d.dthdt)
UNION ALL
SELECT 3, 'L1+ treated mHSPC', COUNT(DISTINCT l.patientid)
FROM   lot l JOIN ms m ON m.patientid = l.patientid
       LEFT JOIN dth d ON d.patientid = l.patientid
WHERE  l.linesetting='mHSPC' AND l.new_lot_n=1
AND    l.startdate BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
AND    m.mhspcdd  BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
AND   (d.dthdt IS NULL OR l.startdate <= d.dthdt)
UNION ALL
SELECT 3 + n.k, CONCAT('L', n.k, '+ treated mCRPC'), COUNT(DISTINCT l.patientid)
FROM   lot l JOIN ms m ON m.patientid = l.patientid
       JOIN (SELECT explode(ARRAY(1,2,3,4)) k) n ON n.k = l.new_lot_n
       LEFT JOIN dth d ON d.patientid = l.patientid
WHERE  l.linesetting='mCRPC'
AND    l.startdate BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
AND    m.mcrpcdd  BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
AND   (d.dthdt IS NULL OR l.startdate <= d.dthdt)
GROUP  BY n.k
ORDER  BY cohortn;

-- -----------------------------------------------------------------------------
-- PART 5  Open questions
-- -----------------------------------------------------------------------------
-- Shared definitions -----------------------------------------------------------
-- (Databricks does not persist WITH across statements, so each query repeats
--  these. They are identical everywhere - do not let them drift.)


-- =============================================================================
-- LABALB / LABALBV - is the delivered value g/L or g/dL?
-- =============================================================================
-- WHY IT MATTERS: the spec labels LABALBV "g/L" and filters on
-- testunitscleaned='g/L', but no albumin row carries that unit, so the filter
-- was dropped. If the underlying values are g/dL the delivered
-- column is out by a factor of ten.
--
-- HOW TO READ IT: serum albumin is ~3.5-5.0 g/dL, or ~35-50 g/L. The median
-- settles it on sight. No judgement required.
SELECT
    labcomponent,
    COALESCE(testunitscleaned, '<NULL>')                    AS unit,
    COUNT(*)                                                AS n_rows,
    COUNT(DISTINCT patientid)                               AS n_pts,
    ROUND(MIN(testresultcleaned), 2)                        AS min_val,
    ROUND(PERCENTILE_APPROX(testresultcleaned, 0.25), 2)    AS p25,
    ROUND(PERCENTILE_APPROX(testresultcleaned, 0.50), 2)    AS median,
    ROUND(PERCENTILE_APPROX(testresultcleaned, 0.75), 2)    AS p75,
    ROUND(MAX(testresultcleaned), 2)                        AS max_val
FROM t_lab_2026m06
WHERE LOWER(testbasename) = 'albumin'
  AND testresultcleaned IS NOT NULL
GROUP BY labcomponent, COALESCE(testunitscleaned, '<NULL>')
ORDER BY n_rows DESC;


-- =============================================================================
-- Index-date granularity  (Overall cohorts 1-2 only)
-- =============================================================================
-- t_enh_prostate_lot has no `startdategranularity` column; Databricks replies
--   [UNRESOLVED_COLUMN.WITH_SUGGESTION] ... Did you mean one of the following?
--   [`StartDate_sasdt`,`StartDate_year`,`StartDate_day`,`StartDate_month`,`StartDate`]
-- The LOT table records the date and its numeric parts, and nothing about
-- how precisely it was known. Index-date precision for cohorts 3-7 is not
-- answerable from the source - not "unknown pending a query", but not recorded.
--
-- What can be checked is cohorts 1 and 2, whose index date is
--   cohort 1: max(MetastaticDiagnosisDate, HSPCDate)
--   cohort 2: max(MetastaticDiagnosisDate, CRPCDate)
-- Both components carry a granularity column on t_enh_prostate. The profiler
-- gives each column separately (hspcdate DAY 701 / MONTH 197 / YEAR 155); what
-- it cannot give is the granularity of the component that wins the max(),
-- which is the only one that becomes INDEXDT.
--
-- The population is the DELIVERED cohort 1 / cohort 2, so the per-cohort
-- death exclusion applies in both branches: a patient whose milestone index
-- date falls after their death date is not in the cohort, and their index-date
-- granularity is not a delivered granularity.
SELECT cohortn,
       win_granularity,
       COUNT(*)                                                              AS n_pts,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (PARTITION BY cohortn), 2) AS pct
FROM (
    SELECT 1 AS cohortn,
           CASE WHEN p.hspcdate IS NULL
                THEN COALESCE(p.metastaticdiagnosisdategranularity, '<NULL>')
                -- Equal dates: neither component 'wins', so report the pair. A tie
                -- whose two granularities differ is the only ambiguous case and is
                -- broken out rather than silently assigned to one side.
                WHEN p.metastaticdiagnosisdate = p.hspcdate
                 AND COALESCE(p.metastaticdiagnosisdategranularity,'x')
                   = COALESCE(p.hspcdategranularity,'x')
                THEN COALESCE(p.metastaticdiagnosisdategranularity, '<NULL>')
                WHEN p.metastaticdiagnosisdate = p.hspcdate
                THEN CONCAT('TIE:', COALESCE(p.metastaticdiagnosisdategranularity,'<NULL>'),
                            '/',   COALESCE(p.hspcdategranularity,'<NULL>'))
                WHEN p.metastaticdiagnosisdate > p.hspcdate
                THEN COALESCE(p.metastaticdiagnosisdategranularity, '<NULL>')
                ELSE COALESCE(p.hspcdategranularity,                '<NULL>')
           END AS win_granularity
    FROM t_enh_prostate_2026m06 p
    LEFT JOIN (
        SELECT DISTINCT patientid,
               CASE WHEN LENGTH(dateofdeath) = 7
                         THEN TRY_CAST(CONCAT(dateofdeath, '-15')    AS DATE)
                    WHEN LENGTH(dateofdeath) = 4
                         THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
                    ELSE NULL END                          AS dthdt
        FROM t_mortality_v2_2026m06
    ) d ON d.patientid = p.patientid
    WHERE GREATEST(p.metastaticdiagnosisdate, p.hspcdate)
          BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND (d.dthdt IS NULL
           OR GREATEST(p.metastaticdiagnosisdate, p.hspcdate) <= d.dthdt)
    UNION ALL
    SELECT 2 AS cohortn,
           CASE WHEN p.crpcdate IS NULL
                THEN COALESCE(p.metastaticdiagnosisdategranularity, '<NULL>')
                -- Equal dates: same tie handling as cohort 1 above.
                WHEN p.metastaticdiagnosisdate = p.crpcdate
                 AND COALESCE(p.metastaticdiagnosisdategranularity,'x')
                   = COALESCE(p.crpcdategranularity,'x')
                THEN COALESCE(p.metastaticdiagnosisdategranularity, '<NULL>')
                WHEN p.metastaticdiagnosisdate = p.crpcdate
                THEN CONCAT('TIE:', COALESCE(p.metastaticdiagnosisdategranularity,'<NULL>'),
                            '/',   COALESCE(p.crpcdategranularity,'<NULL>'))
                WHEN p.metastaticdiagnosisdate > p.crpcdate
                THEN COALESCE(p.metastaticdiagnosisdategranularity, '<NULL>')
                ELSE COALESCE(p.crpcdategranularity,                '<NULL>')
           END AS win_granularity
    FROM t_enh_prostate_2026m06 p
    LEFT JOIN (
        SELECT DISTINCT patientid,
               CASE WHEN LENGTH(dateofdeath) = 7
                         THEN TRY_CAST(CONCAT(dateofdeath, '-15')    AS DATE)
                    WHEN LENGTH(dateofdeath) = 4
                         THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
                    ELSE NULL END                          AS dthdt
        FROM t_mortality_v2_2026m06
    ) d ON d.patientid = p.patientid
    WHERE GREATEST(p.metastaticdiagnosisdate, p.crpcdate)
          BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND (d.dthdt IS NULL
           OR GREATEST(p.metastaticdiagnosisdate, p.crpcdate) <= d.dthdt)
) x
GROUP BY cohortn, win_granularity
ORDER BY cohortn, n_pts DESC;
-- Reading it: YEAR on the winning component means INDEXDT is almost certainly
-- 1 January of that year. If YEAR is ~0%, close the row.
-- If the granularity names error, see the file header: DESCRIBE the table and
-- use its names.


-- =============================================================================
-- Does progression get recorded after death or after the last note?
-- =============================================================================
-- WHY IT MATTERS: the build takes PFSDT as recorded, with no clamping and no
-- exclusion. If these counts are zero the row closes with no decision at all.
--
-- THE COMPARATOR IS THE IMPUTED DTHDT, NOT LAST_DAY(DateOfDeath). It used to be
-- the month end because DEATH_DT_preliminary could itself be promoted there;
-- with W2 and W3 withdrawn a month-end comparator now tests against a date the
-- build never produces and understates the count.
-- Comparing against the imputed date is comparing against the value PFSDT is
-- actually checked against.
--
-- CAVEAT, unchanged in substance: DateOfDeath is month/year granular in the
-- source, so the imputed date is the middle of the interval the death really
-- falls in and a progression up to about two weeks past it can still be inside
-- the death month. Treat a small non-zero count as "check the individual rows",
-- not as proof.
-- The evidence filter matches the build: any flag except pseudo-progression.
WITH prog AS (
    SELECT patientid, progressiondate, lastclinicnotedate
    FROM t_enh_prostate_prog_scled_2026m06
    WHERE progressiondate IS NOT NULL
      AND (   LOWER(isradiographicevidence)    = 'true'
           OR LOWER(ispathologicevidence)      = 'true'
           OR LOWER(ismixedresponsementioned)  = 'true'
           OR LOWER(isphysicalexamevidence)    = 'true'
           OR LOWER(istumormarkerevidence)     = 'true'
           OR LOWER(ispsaincreased)            = 'true')
)
SELECT
    COUNT(*)                                                            AS n_qualifying_prog_rows,
    COUNT(DISTINCT p.patientid)                                         AS n_pts,
    SUM(CASE WHEN p.lastclinicnotedate IS NOT NULL
              AND p.progressiondate > p.lastclinicnotedate
             THEN 1 ELSE 0 END)                                         AS n_after_last_note,
    SUM(CASE WHEN d.dthdt IS NOT NULL
              AND p.progressiondate > d.dthdt
             THEN 1 ELSE 0 END)                                         AS n_after_death
FROM prog p
LEFT JOIN (
    SELECT DISTINCT patientid,
           CASE WHEN LENGTH(dateofdeath) = 7
                     THEN TRY_CAST(CONCAT(dateofdeath, '-15')    AS DATE)
                WHEN LENGTH(dateofdeath) = 4
                     THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
                ELSE NULL END                          AS dthdt
    FROM t_mortality_v2_2026m06
) d ON d.patientid = p.patientid;


-- =============================================================================
-- Can the next-treatment date fall on or before the index date?
-- =============================================================================
-- WHY IT MATTERS: TTNT takes the next line's start date with no requirement
-- that it be after index. Because NEW_LOT_N is ordered by startdate, line n+1
-- can only precede line n if the two share a start date - which is also the
-- tie condition. A zero here closes it.
WITH lot AS (
    SELECT patientid, linesetting, startdate,
           LEAD(startdate) OVER (PARTITION BY patientid, linesetting
                                 ORDER BY startdate)        AS next_startdate
    FROM t_enh_prostate_lot_2026m06
    WHERE linesetting IN ('mHSPC', 'mCRPC')
)
SELECT
    linesetting,
    COUNT(*)                          AS n_consecutive_pairs_same_or_earlier,
    COUNT(DISTINCT patientid)         AS n_pts
FROM lot
WHERE next_startdate IS NOT NULL
  AND next_startdate <= startdate
GROUP BY linesetting
ORDER BY linesetting;


-- =============================================================================
-- K42b  The cross-setting half, which  above does not cover
-- =============================================================================
-- checks consecutive lines within a setting. Cohort 3 does not use a
-- within-setting pair: its next treatment is
--
--     min(mHSPC LOT2 start, mCRPC LOT1 start)
--
-- so the chronology that matters there is mHSPC LOT1 against mCRPC LOT1 - two
-- different settings, which LEAD() over a setting partition can never see.
-- That is why  was reopened: the row was closed on evidence that did not
-- test the case it was about.
--
-- WHY IT MATTERS. Cohort 3's index date is the mHSPC LOT1 start. If a patient's
-- first mCRPC line begins on or before it, TTNT is zero or negative months for
-- that patient, and nothing downstream rejects it.
--
-- The population is the delivered cohort 3, not every patient with an mHSPC
-- line: both the line start and the mHSPC milestone must fall in the index
-- window, and the line must not start after the patient's death date, exactly
-- as 01_studypop.R requires.
--
-- PASS: n_le = 0; that closes it on evidence that tests the case.
-- Read n_before and n_same separately - a same-day start gives TTNT of one day,
-- which is degenerate rather than impossible, and is the milder finding.
WITH lot AS (
    SELECT patientid, linesetting, startdate,
           ROW_NUMBER() OVER (PARTITION BY patientid, linesetting
                              ORDER BY startdate) AS new_lot_n
    FROM   t_enh_prostate_lot_2026m06
    WHERE  linesetting IN ('mHSPC', 'mCRPC')
),
ms AS (
    -- dthdt rides along with the milestone, so coh3 applies the death exclusion
    -- from this one join (see header).
    SELECT p.patientid,
           GREATEST(p.metastaticdiagnosisdate, p.hspcdate) AS mhspcdd,
           d.dthdt
    FROM   t_enh_prostate_2026m06 p
    LEFT JOIN (
        SELECT DISTINCT patientid,
               CASE WHEN LENGTH(dateofdeath) = 7
                         THEN TRY_CAST(CONCAT(dateofdeath, '-15')    AS DATE)
                    WHEN LENGTH(dateofdeath) = 4
                         THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
                    ELSE NULL END                          AS dthdt
        FROM t_mortality_v2_2026m06
    ) d ON d.patientid = p.patientid
),
coh3 AS (                                   -- the delivered L1+ treated mHSPC
    SELECT l.patientid, l.startdate AS indexdt
    FROM   lot l
    JOIN   ms  m ON m.patientid = l.patientid
    WHERE  l.linesetting = 'mHSPC'
      AND  l.new_lot_n   = 1
      AND  l.startdate BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND  m.mhspcdd   BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
      AND  (m.dthdt IS NULL OR l.startdate <= m.dthdt)
),
-- Not filtered by the ruling: this is the next-treatment date, a source fact about
-- the patient, not a cohort membership. Only coh3 above is.
crpc1 AS (                                  -- their first mCRPC line, if any
    SELECT patientid, startdate AS crpc1_start
    FROM   lot
    WHERE  linesetting = 'mCRPC' AND new_lot_n = 1
)
SELECT
    COUNT(*)                                                  AS n_cohort3,
    SUM(CASE WHEN c.crpc1_start IS NOT NULL THEN 1 ELSE 0 END) AS n_with_mcrpc_l1,
    SUM(CASE WHEN c.crpc1_start <= k.indexdt THEN 1 ELSE 0 END) AS n_le,
    SUM(CASE WHEN c.crpc1_start <  k.indexdt THEN 1 ELSE 0 END) AS n_before,
    SUM(CASE WHEN c.crpc1_start =  k.indexdt THEN 1 ELSE 0 END) AS n_same,
    MIN(DATEDIFF(c.crpc1_start, k.indexdt))                    AS worst_gap_days
FROM       coh3  k
LEFT JOIN  crpc1 c ON c.patientid = k.patientid;


-- =============================================================================
-- How often does the index LINE start before the MILESTONE it is joined to?
-- =============================================================================
-- WHY IT MATTERS: the cohort join matches on patientid only and enforces no
-- chronology, so a patient can be indexed on an mCRPC line that started before
-- they were mCRPC. This sizes it before the SME is asked to rule.
--
-- n_pts_in_cohort is a delivered cohort size and pct is a share of it, so the
-- per-cohort death exclusion applies here too - without it the denominator
-- and the percentage both describe a population larger than the one that
-- ships. Per cohort, not per patient: a patient can be counted in cohort 4 and
-- dropped from cohort 6 by the same predicate.
WITH lot AS (
    SELECT patientid, linesetting, startdate,
           ROW_NUMBER() OVER (PARTITION BY patientid, linesetting
                              ORDER BY startdate)           AS new_lot_n
    FROM t_enh_prostate_lot_2026m06
    WHERE linesetting IN ('mHSPC', 'mCRPC')
),
ms AS (
    -- dthdt rides along with the milestones for the death exclusion in the WHERE
    -- clause below (see header).
    SELECT p.patientid,
           GREATEST(p.metastaticdiagnosisdate, p.hspcdate) AS mhspcdd,
           GREATEST(p.metastaticdiagnosisdate, p.crpcdate) AS mcrpcdd,
           d.dthdt
    FROM t_enh_prostate_2026m06 p
    LEFT JOIN (
        SELECT DISTINCT patientid,
               CASE WHEN LENGTH(dateofdeath) = 7
                         THEN TRY_CAST(CONCAT(dateofdeath, '-15')    AS DATE)
                    WHEN LENGTH(dateofdeath) = 4
                         THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
                    ELSE NULL END                          AS dthdt
        FROM t_mortality_v2_2026m06
    ) d ON d.patientid = p.patientid
)
SELECT
    CASE WHEN l.linesetting = 'mHSPC' AND l.new_lot_n = 1 THEN '3 L1+ mHSPC'
         WHEN l.linesetting = 'mCRPC' AND l.new_lot_n = 1 THEN '4 L1+ mCRPC'
         WHEN l.linesetting = 'mCRPC' AND l.new_lot_n = 2 THEN '5 L2+ mCRPC'
         WHEN l.linesetting = 'mCRPC' AND l.new_lot_n = 3 THEN '6 L3+ mCRPC'
         WHEN l.linesetting = 'mCRPC' AND l.new_lot_n = 4 THEN '7 L4+ mCRPC'
    END                                                     AS cohort,
    COUNT(DISTINCT l.patientid)                             AS n_pts_in_cohort,
    COUNT(DISTINCT CASE
        WHEN (l.linesetting = 'mHSPC' AND l.startdate < m.mhspcdd)
          OR (l.linesetting = 'mCRPC' AND l.startdate < m.mcrpcdd)
        THEN l.patientid END)                               AS n_pts_line_before_milestone,
    ROUND(100.0 * COUNT(DISTINCT CASE
        WHEN (l.linesetting = 'mHSPC' AND l.startdate < m.mhspcdd)
          OR (l.linesetting = 'mCRPC' AND l.startdate < m.mcrpcdd)
        THEN l.patientid END) / NULLIF(COUNT(DISTINCT l.patientid), 0), 1) AS pct
FROM lot l
JOIN ms  m ON m.patientid = l.patientid
WHERE l.startdate BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'
  AND (   (l.linesetting = 'mHSPC' AND m.mhspcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30')
       OR (l.linesetting = 'mCRPC' AND m.mcrpcdd BETWEEN DATE'2011-01-01' AND DATE'2026-04-30'))
  AND (   (l.linesetting = 'mHSPC' AND l.new_lot_n = 1)
       OR (l.linesetting = 'mCRPC' AND l.new_lot_n BETWEEN 1 AND 4))
  AND (m.dthdt IS NULL OR l.startdate <= m.dthdt)
GROUP BY 1
ORDER BY 1;
