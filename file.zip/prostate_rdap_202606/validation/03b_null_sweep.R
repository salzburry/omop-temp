# =============================================================================
# NULL / CONSTANT SWEEP IN R - RUN IN DATABRICKS, NOTHING FETCHED
# =============================================================================
#   Rscript validation/03b_null_sweep.R           (after a build, repo root)
#
# Same checks as validation/03b_null_sweep.sql. One pass profiles all 190
# contract columns into a wide table. A second pass judges each column.
# Both passes run inside Databricks. Nothing comes back to this session.
#
#   SELECT * FROM <schema>.qcr_nullsweep_r ORDER BY status, col
#
#   PASS    populated, and not one repeated value
#   WAIVED  exactly the shape its waiver predicts
#   REVIEW  waived, but the data no longer fits that shape
#   FAIL    all-null or constant with no waiver - a defect
#
# The waiver list mirrors validation/make_null_sweep.R. Do not add a waiver
# here alone - add it there too, with a register id.
# =============================================================================

if (!exists("con")) {
  message("no open connection - sourcing validation/00_connect.R")
  source("validation/00_connect.R")
}
stopifnot(exists("con"), exists("personal_schema"), exists("output_table"))

ads <- dplyr::tbl(con, dbplyr::in_schema(personal_schema, output_table))

# shape + reason, mirroring validation/make_null_sweep.R word for word.
WAIVED <- list(
  hrr_index_test            = c("const", "Q03 hard-coded Unknown; no test-type column exists"),
  hrr_index_testn           = c("const", "Q03 hard-coded 7; no test-type column exists"),
  brca_index_test           = c("const", "Q03 hard-coded Unknown; no test-type column exists"),
  brca_index_testn          = c("const", "Q03 hard-coded 7; no test-type column exists"),
  max_drug_ep_abstracted_dt = c("null",  "Q16 EpisodeDataSource=Abstraction absent from 2026m06"),
  # dth_before_fued is constant 0 by construction under the 2026-09-11 ruling
  # (register Q82): FUED = COALESCE(dthdt, fu_enddt_preliminary), so with a
  # death date FUED IS that date and DTHDT < FUED is false, and without one
  # DTHDT is NULL and the test is false again. Unreachable, not broken.
  #
  # THE TENSION, so that nobody "fixes" it later: gate V45 in
  # validation/03_output_validation.R FAILS unless dth_before_fued is constant
  # 0, while this sweep would FAIL a correct build precisely BECAUSE it is
  # constant. The waiver reconciles them and keeps the shape under test - a
  # flag that stopped being constant reads REVIEW here. Remove the waiver and a
  # correct build cannot ship; remove V45 and a reinstated clamp ships
  # unnoticed. Both stay.
  dth_before_fued           = c("const", "Q82 unreachable - FUED is the death date, so the flag is 0 on every row"),
  datav    = c("const", "run stamp - one value by construction"),
  rawrwd   = c("const", "run stamp - one value by construction"),
  minindex = c("const", "run stamp - one value by construction"),
  maxindex = c("const", "run stamp - one value by construction"))

# fued / fudur are deliberately NOT waived, and their expectation is UNCHANGED,
# even though the 2026-09-11 ruling (register Q82) made them nullable: FUED is
# COALESCE(dthdt, fu_enddt_preliminary) with no index floor, so a patient with
# no death date and no activity in any of the four sources now gets a NULL FUED
# and a NULL FUDUR with it - impossible while the floor stood. This sweep
# judges only two shapes, entirely null and constant on every row, so a partly
# null column is neither and still reads PASS however the null rate moves. The
# size of that population is reported by qc/01_variable_profile.R (n_null /
# pct_null), and qc/07_type_contract.R fails if FUED is NULL while either
# source date is present, or if FUDUR and FUED are not NULL together. An
# ENTIRELY null fued or fudur would be a real defect - all four source dates
# missing for every patient - so it must keep reporting FAIL.

contract <- utils::read.csv("validation/00_column_contract.csv",
                            stringsAsFactors = FALSE)
nm <- tolower(contract$column[order(contract$ordinal)])
stopifnot(all(names(WAIVED) %in% nm))

# ---- pass 1: one scan, wide -------------------------------------------------
# Per column: non-null count, min, max. One row carries all 190 columns.
agg <- c(list(n_rows = rlang::quo(dplyr::n())),
         stats::setNames(lapply(nm, function(cl) {
           s <- rlang::sym(cl)
           rlang::quo(sum(dplyr::case_when(!is.na(!!s) ~ 1L, TRUE ~ 0L), na.rm = TRUE))
         }), paste0("nn_", nm)),
         stats::setNames(lapply(nm, function(cl) {
           s <- rlang::sym(cl); rlang::quo(min(!!s, na.rm = TRUE))
         }), paste0("mn_", nm)),
         stats::setNames(lapply(nm, function(cl) {
           s <- rlang::sym(cl); rlang::quo(max(!!s, na.rm = TRUE))
         }), paste0("mx_", nm)))

message("writing qcr_sweep_wide_r (one pass over the ADS)")
createInPersonalSchema(ads %>% dplyr::summarise(!!!agg),
                       "qcr_sweep_wide_r", replace = TRUE)

# ---- pass 2: judge each column off the one-row wide table -------------------
# Constant means one value on every row. A column that is mostly one value
# but partly null is neither null nor constant - same rule as the SQL.
wide <- dplyr::tbl(con, dbplyr::in_schema(personal_schema, "qcr_sweep_wide_r"))

judge_one <- function(cl) {
  nn <- rlang::sym(paste0("nn_", cl))
  mn <- rlang::sym(paste0("mn_", cl))
  mx <- rlang::sym(paste0("mx_", cl))
  expect <- if (cl %in% names(WAIVED)) WAIVED[[cl]][1] else ""
  why    <- if (cl %in% names(WAIVED)) WAIVED[[cl]][2] else ""
  wide %>% dplyr::transmute(
    col      = !!cl,
    nonnull  = !!nn,
    n_rows   = n_rows,
    min_val  = as.character(!!mn),
    max_val  = as.character(!!mx),
    expect   = !!expect,
    waiver   = !!why,
    is_null  = (!!nn == 0L),
    is_const = (!!nn == n_rows & !!nn > 0L & coalesce(!!mn == !!mx, FALSE)))
}

sweep <- Reduce(dplyr::union_all, lapply(nm, judge_one)) %>%
  dplyr::mutate(status = dplyr::case_when(
    expect == "null"  & is_null            ~ "WAIVED",
    expect == "const" & is_const           ~ "WAIVED",
    expect != ""                           ~ "REVIEW",
    is_null | is_const                     ~ "FAIL",
    TRUE                                   ~ "PASS")) %>%
  dplyr::select(col, nonnull, n_rows, min_val, max_val, expect, waiver, status)

message("writing qcr_nullsweep_r (190 columns judged)")
createInPersonalSchema(sweep, "qcr_nullsweep_r", replace = TRUE)

if (exists("qcr_stamp")) qcr_stamp("03b_null_sweep")

message("Results written. Read in the SQL editor:")
message("  SELECT * FROM ", personal_schema,
        ".qcr_nullsweep_r ORDER BY status, col")

# Fail-closed: one tiny verdict fetch. A verdict that cannot be fetched is
# not a pass - the table is already written, so exit 2 and read
# qcr_nullsweep_r yourself.
v <- tryCatch(DBI::dbGetQuery(con, paste0(
       "SELECT COUNT(*) AS n FROM ", personal_schema,
       ".qcr_nullsweep_r WHERE status IN ('FAIL', 'REVIEW')")),
     error = function(e) NULL)
if (is.null(v)) {
  message("verdict fetch failed - read qcr_nullsweep_r before trusting the run")
  quit(status = 2L, save = "no")
} else if (v$n[1] > 0) {
  message("FAIL - ", v$n[1], " column(s) read FAIL or REVIEW. See qcr_nullsweep_r.")
  quit(status = 1L, save = "no")
} else {
  message("PASS - no FAIL or REVIEW column")
}
