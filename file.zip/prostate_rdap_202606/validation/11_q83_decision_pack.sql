-- =============================================================================
-- Q83 DECISION PACK - the follow-up-before-index population, characterised
-- =============================================================================
-- WHY THIS FILE EXISTS. Q83 has been open since the 2026-09-11 ruling with no
-- number attached to it. Rule RP2 removed the index floor on FUED, so for a
-- patient with no death date FUED is their last activity date, unconnected to
-- the cohort's index date and free to fall before it. Gate V46 sizes that
-- population; on the 2026-09-13 build it reads 1,059 rows. A count is enough
-- to know the question is live. It is NOT enough to rule on it, because the
-- ruling has to choose what those rows should carry, and that choice depends
-- on how far before the index they fall and what they drag with them.
--
-- This file answers that. It reads the DELIVERED table and writes nothing, so
-- it is safe to re-run and safe to run at any point after the build.
--
--     Rscript validation/run_sql.R validation/11_q83_decision_pack.sql
--
-- Run it through run_sql.R, not the SQL editor. Statement 1 carries assertions
-- that establish the population is what this pack says it is; in an editor
-- they are comments and a mis-scoped pack reads as a finished answer.
--
--   ${catalog} = hive_metastore
--   ${schema}  = your personal schema
--   ${ads}     = rwdp_pros_pano_2026m06
--
-- WHAT IT DOES NOT DO. It does not rule. Every statement is a measurement; the
-- decision belongs to a named clinician and goes in docs/VARIABLES.md section
-- 8 under Q83, with their name and the date. The four options and what each
-- one costs are written at the foot of this file so the choice is made against
-- the same numbers the pack produces.
-- =============================================================================

USE CATALOG ${catalog};

-- ---------------------------------------------------------------------------
-- Q83.0. IS THIS THE POPULATION THE PACK CLAIMS?  Every column MUST read zero.
--
-- These are not findings. They are the assumptions every later statement rests
-- on, asserted once so that a pack built on a different population stops here
-- instead of producing a confident answer to the wrong question.
--
--   with_death_date       V46b restated against this population. A patient
--                         with a death date CANNOT be here: the per-cohort
--                         exclusion guarantees DTHDT >= INDEXDT. If one is,
--                         the exclusion or the FUED rule has broken and this
--                         is a defect, not the Q83 residue.
--   dthfl_set             every row must have taken the `dthfl = 0` arm of OS.
--                         This is what makes the OS figures below readable:
--                         that arm measures to FUED, so a negative FUED gap
--                         propagates into OS. If any row took the `dthfl = 1`
--                         arm, OS is measuring something else entirely.
--   dth_before_fued_set   V45 asserts this column is constant 0 and unreachable
--                         under Q82. Restated here because it is the NA guard
--                         on both OS and TTNT - if it ever fires, the rows
--                         below carry NULL rather than a negative number and
--                         the whole exposure changes shape.
--   fued_not_preliminary  with no death date, FUED must be
--                         FU_ENDDT_PRELIMINARY exactly (V47's second arm). If
--                         it is not, FUED came from somewhere this pack has
--                         not accounted for.
--   fudur_positive        FUDUR is DATEDIFF(FUED, INDEXDT) + 1, so FUED before
--                         the index gives FUDUR <= 0, never above it. Note the
--                         `+ 1`: FUED exactly one day before the index yields
--                         FUDUR = 0, NOT a negative number. That is why the
--                         split below is `< 0` and `= 0` separately rather
--                         than one "negative" bucket - they are different
--                         clinical statements and may deserve different rules.
--
-- @assert zero with_death_date
-- @assert zero dthfl_set
-- @assert zero dth_before_fued_set
-- @assert zero fued_not_preliminary
-- @assert zero fudur_positive
-- ---------------------------------------------------------------------------
SELECT COALESCE(SUM(CASE WHEN dthdt IS NOT NULL           THEN 1 ELSE 0 END), 0) AS with_death_date,
       COALESCE(SUM(CASE WHEN dthfl <> 0                  THEN 1 ELSE 0 END), 0) AS dthfl_set,
       COALESCE(SUM(CASE WHEN dth_before_fued <> 0        THEN 1 ELSE 0 END), 0) AS dth_before_fued_set,
       COALESCE(SUM(CASE WHEN fued IS DISTINCT FROM fu_enddt_preliminary
                                                          THEN 1 ELSE 0 END), 0) AS fued_not_preliminary,
       COALESCE(SUM(CASE WHEN fudur > 0                   THEN 1 ELSE 0 END), 0) AS fudur_positive
FROM   ${schema}.${ads}
WHERE  fued < indexdt;

-- ---------------------------------------------------------------------------
-- Q83.1. HOW BIG IS IT.  The headline for the ruling note.
--
-- Rows and patients are counted separately because the ADS grain is one row
-- per patient per cohort: a patient meeting four cohort definitions appears
-- four times and would be counted four times by V46. The number that belongs
-- in a clinical sentence is the patient count, not the row count.
--
-- zero_fudur is split out because FUDUR = 0 is a patient whose last activity
-- is the day before their index - a zero-length follow-up rather than a
-- backwards one. Several of the options below would treat those two
-- differently.
-- ---------------------------------------------------------------------------
SELECT COUNT(*)                                                          AS rows_affected,
       COUNT(DISTINCT patid)                                             AS patients_affected,
       COALESCE(SUM(CASE WHEN fudur <  0 THEN 1 ELSE 0 END), 0)          AS rows_negative_fudur,
       COALESCE(SUM(CASE WHEN fudur =  0 THEN 1 ELSE 0 END), 0)          AS rows_zero_fudur,
       (SELECT COUNT(*)            FROM ${schema}.${ads})                AS rows_delivered,
       (SELECT COUNT(DISTINCT patid) FROM ${schema}.${ads})              AS patients_delivered,
       ROUND(100.0 * COUNT(*) /
             NULLIF((SELECT COUNT(*) FROM ${schema}.${ads}), 0), 4)      AS pct_of_rows,
       ROUND(100.0 * COUNT(DISTINCT patid) /
             NULLIF((SELECT COUNT(DISTINCT patid)
                     FROM ${schema}.${ads}), 0), 4)                      AS pct_of_patients
FROM   ${schema}.${ads}
WHERE  fued < indexdt;

-- ---------------------------------------------------------------------------
-- Q83.2. WHERE IT LANDS.  Per cohort, against that cohort's delivered size.
--
-- A ruling can legitimately differ by cohort - the L4+ mCRPC cohort is small
-- and late-line, and a 1% exposure there is a different conversation from the
-- same 1% in Overall mHSPC. The percentage is of the cohort, not of the whole
-- table, because that is the denominator a cohort-level statement uses.
-- ---------------------------------------------------------------------------
WITH sizes AS (SELECT cohortn, COUNT(DISTINCT patid) AS cohort_patients
               FROM   ${schema}.${ads}
               GROUP  BY cohortn)
SELECT a.cohortn,
       MAX(a.cohort)                                                     AS cohort,
       COUNT(*)                                                          AS rows_affected,
       COUNT(DISTINCT a.patid)                                           AS patients_affected,
       MAX(s.cohort_patients)                                            AS cohort_patients,
       ROUND(100.0 * COUNT(DISTINCT a.patid) /
             NULLIF(MAX(s.cohort_patients), 0), 4)                       AS pct_of_cohort,
       MIN(a.fudur)                                                      AS worst_fudur_days,
       MAX(a.fudur)                                                      AS best_fudur_days
FROM   ${schema}.${ads} a
JOIN   sizes s ON s.cohortn = a.cohortn
WHERE  a.fued < a.indexdt
GROUP  BY a.cohortn
ORDER  BY a.cohortn;

-- ---------------------------------------------------------------------------
-- Q83.3. HOW FAR BACK.  The shape of the gap, which is what the ruling turns on.
--
-- A last activity one day before the index is a data-entry boundary. A last
-- activity two years before it is a patient who was indexed on a treatment
-- record with no surrounding activity, and means something quite different.
-- If the mass sits in the first band, flooring is defensible; if it is spread
-- out, it is not, because flooring would be inventing follow-up that the
-- record does not support.
--
-- Bands are on FUDUR, in days, inclusive at both ends. Remember the `+ 1`:
-- FUDUR = 0 is one calendar day before the index, FUDUR = -1 is two.
-- ---------------------------------------------------------------------------
SELECT CASE WHEN fudur =  0                        THEN '1. fudur = 0 (1 day before index)'
            WHEN fudur >= -7                       THEN '2. fudur -1 to -7 (within a week)'
            WHEN fudur >= -30                      THEN '3. fudur -8 to -30 (within a month)'
            WHEN fudur >= -90                      THEN '4. fudur -31 to -90 (within a quarter)'
            WHEN fudur >= -365                     THEN '5. fudur -91 to -365 (within a year)'
            ELSE                                        '6. fudur below -365 (over a year)'
       END                                                               AS band,
       COUNT(*)                                                          AS rows_affected,
       COUNT(DISTINCT patid)                                             AS patients_affected,
       MIN(fudur)                                                        AS min_fudur_days,
       MAX(fudur)                                                        AS max_fudur_days
FROM   ${schema}.${ads}
WHERE  fued < indexdt
GROUP  BY 1
ORDER  BY 1;

-- ---------------------------------------------------------------------------
-- Q83.4. WHAT IT DRAGS WITH IT.  The downstream columns, on the same rows.
--
-- This is the half of Q83 that the V46 count does not show. FUDUR is a
-- reported variable, but OS and TTNT are derived through FUED as well, so a
-- backwards follow-up window does not stay in one column. Anyone ruling on
-- Q83 is ruling on these too, whether or not they are named in the ruling.
--
--   os_negative / os_zero     OS for these rows is (DATEDIFF(FUED, INDEXDT)+1)
--                             / 30.4375 - the dthfl = 0 arm, asserted above.
--                             A negative OS is an analysable-looking number
--                             that is not survival.
--   ttnt_negative             TTNT is NULL by construction for cohorts 1, 2
--                             and 7 and needs ID3MOSFU = 1, so its exposure is
--                             narrower than OS's. Counted, not assumed.
--   pfs_negative              rwPFS runs off its own progression dating, so it
--                             may or may not follow. Counted for the same
--                             reason.
--   id3mosfu_1                patients flagged as having three months of
--                             follow-up while their follow-up ends before the
--                             index. If this is nonzero, the flag and the
--                             window disagree and that disagreement ships.
--   eligpfs_1 / csf_fu_1      the two membership-ish flags that a downstream
--                             analysis would filter on. A row that is
--                             eligible-for-PFS with a backwards window enters
--                             an analysis silently.
--   dthfufl_1                 sanity: death-or-follow-up flag on rows with no
--                             death date.
-- ---------------------------------------------------------------------------
SELECT COUNT(*)                                                          AS rows_affected,
       COALESCE(SUM(CASE WHEN os   <  0 THEN 1 ELSE 0 END), 0)           AS os_negative,
       COALESCE(SUM(CASE WHEN os   =  0 THEN 1 ELSE 0 END), 0)           AS os_zero,
       COALESCE(SUM(CASE WHEN os IS NULL THEN 1 ELSE 0 END), 0)          AS os_null,
       COALESCE(SUM(CASE WHEN ttnt <  0 THEN 1 ELSE 0 END), 0)           AS ttnt_negative,
       COALESCE(SUM(CASE WHEN ttnt IS NULL THEN 1 ELSE 0 END), 0)        AS ttnt_null,
       COALESCE(SUM(CASE WHEN pfs  <  0 THEN 1 ELSE 0 END), 0)           AS pfs_negative,
       COALESCE(SUM(CASE WHEN pfs IS NULL THEN 1 ELSE 0 END), 0)         AS pfs_null,
       COALESCE(SUM(CASE WHEN id3mosfu = 1 THEN 1 ELSE 0 END), 0)        AS id3mosfu_1,
       COALESCE(SUM(CASE WHEN eligpfs  = 1 THEN 1 ELSE 0 END), 0)        AS eligpfs_1,
       COALESCE(SUM(CASE WHEN csf_fu   = 1 THEN 1 ELSE 0 END), 0)        AS csf_fu_1,
       COALESCE(SUM(CASE WHEN dthfufl  = 1 THEN 1 ELSE 0 END), 0)        AS dthfufl_1
FROM   ${schema}.${ads}
WHERE  fued < indexdt;

-- ---------------------------------------------------------------------------
-- Q83.5. ONE PATIENT OR MANY COHORTS.  How the rows distribute over patients.
--
-- A patient affected in every cohort they belong to is one clinical story
-- counted several times; a patient affected in one cohort of four is a story
-- about that cohort's index date rather than about the patient. The ruling
-- reads differently under each, so it is measured rather than assumed.
-- ---------------------------------------------------------------------------
-- Two grouped CTEs joined, rather than a correlated subquery for the
-- denominator. Spark rejects a correlated scalar subquery in the select list
-- of a grouped query outright - SCALAR_SUBQUERY_IS_IN_GROUP_BY_OR_AGGREGATE_
-- FUNCTION - so the per-patient cohort total has to be aggregated separately
-- and joined, not looked up row by row.
WITH totals AS (
  SELECT patid, COUNT(*) AS total_cohorts
  FROM   ${schema}.${ads}
  GROUP  BY patid),
affected AS (
  SELECT patid, COUNT(*) AS affected_cohorts
  FROM   ${schema}.${ads}
  WHERE  fued < indexdt
  GROUP  BY patid)
SELECT a.affected_cohorts,
       COUNT(*)                                                          AS patients,
       COALESCE(SUM(CASE WHEN a.affected_cohorts = t.total_cohorts
                         THEN 1 ELSE 0 END), 0)                          AS affected_in_every_cohort_they_are_in
FROM   affected a
JOIN   totals   t ON t.patid = a.patid
GROUP  BY a.affected_cohorts
ORDER  BY a.affected_cohorts;

-- ---------------------------------------------------------------------------
-- Q83.6. THE WORST 25, for eyeballing. Not evidence - orientation.
--
-- A ruling made only on aggregates can miss that the extreme rows share an
-- obvious feature. Read them, then go back to the aggregates.
-- ---------------------------------------------------------------------------
SELECT patid, cohortn, cohort, indexdt, fued, fu_enddt_preliminary,
       fudur, os, ttnt, pfs, id3mosfu, eligpfs, csf_fu
FROM   ${schema}.${ads}
WHERE  fued < indexdt
ORDER  BY fudur ASC
LIMIT  25;

-- =============================================================================
-- WHAT THE 2026-09-13 RUN FOUND
-- =============================================================================
-- Recorded here so the options below are read against the numbers rather than
-- in the abstract. Re-run the pack on a later build; these are this build's.
--
--   1,059 rows on 594 patients - 0.21% of rows, 0.29% of patients.
--   Confined to cohorts 1 and 2. Cohorts 3-7 report nothing, because a treated
--   cohort requires a treatment record and that record is itself activity.
--   1,023 negative FUDUR, 36 at exactly zero.
--   Distance: 36 at the one-day boundary, 143 within a week, 218 within a
--   month, 132 within a quarter, 165 within a year, and 365 - a third of the
--   population - MORE THAN A YEAR before the index, worst -5,373 days.
--   OS negative on 1,023 and zero on 36: every row. TTNT and PFS null
--   throughout, but only because cohorts 1 and 2 null TTNT by construction.
--   ID3MOSFU = 1 on 874 of them - which is CORRECT and not a finding; see
--   below. ELIGPFS and CSF_FU zero throughout.
--
-- One of those bears directly on the choice. The distance distribution is NOT
-- the boundary artefact that would make flooring defensible - a third of the
-- rows would need up to fourteen years of follow-up invented for them.
--
-- ID3MOSFU IS NOT A FINDING, and an earlier version of this file said it was.
-- It claimed the 874 rows carrying ID3MOSFU = 1 contradict a follow-up window
-- that ended before the index, and that the ruling therefore had to cover the
-- flag. That misreads the variable. 5A.Demos defines it as "1 if MAXINDEX -
-- INDEXDT >= 91 days" and 02_demographics.R implements exactly that, against
-- the study constant 2026-04-30. It measures POTENTIAL follow-up - whether the
-- calendar left room - and never reads FUED, the death date or any activity.
-- An index date 91 days before MAXINDEX gives ID3MOSFU = 1 whether the patient
-- was seen again or not. Nothing to rule on.
--
-- The guards that DO test observation behave correctly here: ELIGPFS requires
-- lastclinicnotedate > index_date and reads 0 on all 1,059, CSF_FU reads 0,
-- and TTNT is null because cohorts 1 and 2 null it by construction.
--
-- WHAT THESE ROWS CARRIED BEFORE, because it reframes the whole question.
-- These are not new patients. The pre-ruling program floored FUED at the index
-- date - `CASE WHEN fu_enddt > index_date THEN fu_enddt ELSE index_date END` -
-- and for a patient with no death date nothing else in that expression
-- applied, so the floor was the only thing acting. All 594 were in the old
-- table already, shipping FUDUR = 1: one manufactured day of follow-up, with
-- OS about 0.03 months to match. The ruling did not create this population. It
-- stopped the floor from concealing it, exactly as it stopped the same clamp
-- concealing the death-side rows that RP4 now excludes.
--
-- So option A is not "ship a wrong number where a right one used to be". The
-- honest comparison is a visibly unusable number against a quietly wrong one,
-- and that is the ground the disposition should be argued on. 00b's B2b
-- measures the swap: fudur_max_lost should read about 5,374, being 1 - -5,373.
-- =============================================================================

-- =============================================================================
-- THE DECISION, and what each option costs
-- =============================================================================
-- Q83 is not a defect to be fixed. It is a consequence of a ruling that was
-- made deliberately: RP2 removed the index floor on FUED because the floor was
-- inventing follow-up for patients who had none. These rows are that invention
-- no longer happening. The question is what should ship in its place.
--
--   A. SHIP AS DELIVERED. Negative FUDUR, OS and TTNT reach the analyst.
--      Cost: a number that looks analysable and is not. Any downstream mean or
--      median silently absorbs it. Choose this only with a documented
--      instruction to the analyst, not on the grounds that it is the default.
--
--   B. NULL THE DURATIONS. FUDUR, OS and TTNT become NULL where FUED < INDEXDT.
--      Cost: the patient stays in the cohort and the count is unchanged, but
--      the outcome is missing rather than wrong. Honest, and it makes the
--      exposure visible in any completeness table. Does NOT fix the flags -
--      ID3MOSFU and ELIGPFS would need the same treatment or they will
--      disagree with the durations they describe.
--
--   C. FLOOR AT THE INDEX. FUED becomes MAX(FUED, INDEXDT), restoring the
--      behaviour RP2 withdrew for this subset only.
--      Cost: it re-introduces exactly what the ruling removed, and it asserts
--      follow-up the record does not support. Only defensible if Q83.3 shows
--      the mass at FUDUR = 0 - a boundary artefact - and not if the gap runs
--      to months. It also needs the ruling amended, because as written RP2
--      does not permit it.
--
--   D. EXCLUDE FROM THE COHORT. The rows leave the delivered table.
--      Cost: the cohort counts move, which means the Q82 acceptance signed on
--      2026-09-12 no longer describes the delivered table and V26's seven
--      figures need re-signing. This is the largest change and needs the
--      owner, not only a clinician.
--
-- WHOEVER RULES: record the option, the reason, the name and the date in
-- docs/VARIABLES.md section 8 under Q83, and set the Status cell to something
-- other than OPEN. qc/00_coverage.R reads that cell and will keep exiting
-- nonzero until it changes - which is the intended behaviour, not a nuisance
-- to work around.
-- =============================================================================
