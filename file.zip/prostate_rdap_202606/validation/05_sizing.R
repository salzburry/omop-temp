# =============================================================================
# SIZING QUERIES IN R - RUN IN DATABRICKS, NOTHING FETCHED
# =============================================================================
#   Rscript validation/05_sizing.R                (repo root)
#
# Same queries as validation/05_sizing_queries.sql, written as dplyr. Each
# sizes an open register row before anyone rules on it. Every query runs
# inside Databricks and lands as a table in the personal schema with
# createInPersonalSchema - nothing comes back to this session. Read the
# tables in the SQL editor.
#
#   qcr_s1_r   Q58. Labs: delivered rows that flip Missing -> Unknown if the
#              Missing test is un-windowed. n_flip ~0 closes the row.
#   qcr_s1b_r  Q58. The same question for BP.
#   qcr_s2_r   Q63. Labs with testdate null but resultdate present - the only
#              rows where RAW vs DERIVED date matters. Empty closes Q63.
#   qcr_s3_r   Q59 step 1. ScoreSerial <= 0 anywhere? If not, the PSABL > 0
#              guard can never fire and Q59 closes as a free condition.
#   qcr_s3b_r  Q59 step 2. PSABL rebuilt exactly; rows where the guard forces
#              'N'. Only meaningful if qcr_s3_r shows scoreserial <= 0.
#   qcr_s4_r   Q56. What the [INDEX-30, INDEX+7] ECOG window costs cohorts
#              3-7. pct_lost is the headline.
#   qcr_s5_r   Q57. Four-way split of the DTHFUFL inputs - reads the
#              delivered ADS, because the preliminary dates are outputs.
#   qcr_s6_r   Q73. Lines that exist with no LINENAME, null or blank.
#
# S1-S4 read the source and rebuild the cohort rows, so they predict what a
# build should produce, not what one did - delivered-side confirmation lives
# in qc/. S5 is the exception and reads the delivered ADS. These are
# descriptive; several rows close with no code change if a count is zero.
#
# Rebuilding the cohort rows means reproducing the per-cohort death exclusion
# (register Q82, study-team ruling 2026-09-11): a patient whose index date for
# a cohort falls after their death date is not in that cohort, so counting them
# here would over-state the delivered population. The exclusion is carried on
# the shared ms definition - one mortality join, one predicate per index branch
# - so every figure built on idx or idx_lot picks it up: S1, S1b, S3b, S4 and
# the shared denominator. S2, S5 and S6 read no cohort rows and are unaffected.
#
# Snapshot suffix and index window come from 00_setup (refresh, index dates).
# The shared CTEs (ms, lot, idx) are repeated verbatim in each SQL query
# because WITH does not persist across statements; here each is defined once,
# so they cannot drift.
#
# The SQL's NULL rules carry over exactly:
#   `CASE WHEN c THEN x ELSE y`  ->  case_when(c ~ x, TRUE ~ y)
#   SUM(CASE WHEN ...)           ->  sum(case_when(...), na.rm = TRUE)
#   GREATEST(a, b)               ->  pmax(a, b, na.rm = TRUE), null-skipping,
#       the same semantics as the build's derived lab date.
# =============================================================================

if (!exists("con")) {
  message("no open connection - sourcing validation/00_connect.R")
  source("validation/00_connect.R")
}
stopifnot(exists("con"), exists("personal_schema"), exists("output_table"),
          exists("source_schema"), exists("refresh"))

ads  <- dplyr::tbl(con, dbplyr::in_schema(personal_schema, output_table))
# rename_with(tolower): the driver reports source columns in stored case,
# which is not always lower - the build's own src() lowercases the same way.
src_ <- function(tb) dplyr::tbl(con, dbplyr::in_schema(
          source_schema, paste0(tb, "_", refresh))) %>%
  dplyr::rename_with(tolower)

# S7 is the only item here that reads the DELIVERED table; S1-S6 all rebuild
# from source. Kept separate so it is obvious which side a figure came from.
ads_ <- function() dplyr::tbl(con, dbplyr::in_schema(personal_schema, output_table)) %>%
  dplyr::rename_with(tolower)

IDX_LO <- as.Date("2011-01-01")
IDX_HI <- as.Date("2026-04-30")

# ---- Shared: milestones, numbered lines, one index row per cohort -----------
# ms carries the patient-level imputed death date alongside the two milestone
# dates, because the Q82 per-cohort death exclusion has to be applied to every
# index branch below and ms is the one definition all of them read. Joining
# mortality here rather than once per cohort is what stops the four index
# branches - two Overall, the LOT union inside idx, and idx_lot - from drifting
# apart.
#
# The imputation is the build's, verbatim (code/modules/01_studypop.R): middle
# of the month for a 'YYYY-MM' value, middle of the year for a 'YYYY' one, and
# NULL for any other length (register Q66, unchanged). TRY_CAST rather than
# CAST, so a value of the right length with impossible content nulls instead of
# raising. Nothing promotes the value afterwards - the 2026-09-11 ruling
# withdrew all three of the earlier adjustments, so there is no month-end or
# year-end push to reproduce here.
ms <- src_("t_enh_prostate") %>%
  dplyr::transmute(
    patientid,
    mhspcdd = pmax(metastaticdiagnosisdate, hspcdate, na.rm = TRUE),
    mcrpcdd = pmax(metastaticdiagnosisdate, crpcdate, na.rm = TRUE)) %>%
  dplyr::left_join(
    src_("t_mortality_v2") %>%
      dplyr::mutate(dthdt = dbplyr::sql(
        "CASE
           WHEN LENGTH(dateofdeath) = 7 THEN TRY_CAST(CONCAT(dateofdeath, '-15') AS DATE)
           WHEN LENGTH(dateofdeath) = 4 THEN TRY_CAST(CONCAT(dateofdeath, '-07-15') AS DATE)
           ELSE NULL END")) %>%
      # distinct, as the build's own mortality join is: one row per patient, so
      # the left join cannot fan an index row out into two.
      dplyr::select(patientid, dthdt) %>%
      dplyr::distinct(),
    by = "patientid")

lot <- src_("t_enh_prostate_lot") %>%
  dplyr::filter(linesetting %in% c("mHSPC", "mCRPC")) %>%
  dplyr::group_by(patientid, linesetting) %>%
  dbplyr::window_order(startdate) %>%
  dplyr::mutate(new_lot_n = dplyr::row_number()) %>%
  dplyr::ungroup() %>%
  dplyr::select(patientid, linesetting, linenumber, startdate, new_lot_n)

# Cohorts 3-7, carrying the line identity the S4 ECOG match needs.
idx_lot <- lot %>%
  dplyr::inner_join(ms, by = "patientid") %>%
  dplyr::filter(
    dplyr::between(startdate, !!IDX_LO, !!IDX_HI) &
    ((linesetting == "mHSPC" & new_lot_n == 1L &
        dplyr::between(mhspcdd, !!IDX_LO, !!IDX_HI)) |
     (linesetting == "mCRPC" & dplyr::between(new_lot_n, 1L, 4L) &
        dplyr::between(mcrpcdd, !!IDX_LO, !!IDX_HI))) &
    # Q82 per-cohort death exclusion, against the line start date that becomes
    # this cohort's index. Strict: an index ON the death date is kept, only a
    # strictly later one is dropped. The NULL arm is written out rather than
    # left to the comparison, because `startdate <= NULL` is UNKNOWN and would
    # silently drop every patient with no death date.
    (is.na(dthdt) | startdate <= dthdt)) %>%
  dplyr::transmute(
    cohort = dplyr::case_when(
      linesetting == "mHSPC" ~ "3 L1+ mHSPC",
      new_lot_n == 1L        ~ "4 L1+ mCRPC",
      new_lot_n == 2L        ~ "5 L2+ mCRPC",
      new_lot_n == 3L        ~ "6 L3+ mCRPC",
      TRUE                   ~ "7 L4+ mCRPC"),
    patientid, linenumber, index_date = startdate)

# All seven cohorts, one row per delivered (cohort, patient) index row. Each
# Overall branch applies the same Q82 exclusion against its own milestone
# index date; idx_lot already carries it for cohorts 3-7. Per cohort, not per
# patient - a patient can survive here and still be dropped from a later line.
idx <- ms %>%
  dplyr::filter(dplyr::between(mhspcdd, !!IDX_LO, !!IDX_HI) &
                (is.na(dthdt) | mhspcdd <= dthdt)) %>%
  dplyr::transmute(patientid, cohort = "1 Overall mHSPC",
                   index_date = mhspcdd) %>%
  dplyr::union_all(
    ms %>%
      dplyr::filter(dplyr::between(mcrpcdd, !!IDX_LO, !!IDX_HI) &
                    (is.na(dthdt) | mcrpcdd <= dthdt)) %>%
      dplyr::transmute(patientid, cohort = "2 Overall mCRPC",
                       index_date = mcrpcdd)) %>%
  dplyr::union_all(idx_lot %>%
                     dplyr::select(patientid, cohort, index_date))

denom <- idx %>% dplyr::summarise(n_index_rows_all = dplyr::n())

# ---- S1 / Q58: labs - delivered rows that flip Missing -> Unknown -----------
# The build tests "has a record" only after labdate <= index; the spec's
# Missing clause has no time qualifier. n_flip is the rows that change label.
# The ten analytes exactly as lab_spec defines them, component filter included.
lab <- src_("t_lab") %>%
  dplyr::transmute(
    patientid,
    analyte = dplyr::case_when(
      tolower(testbasename) == "neutrophils"                ~ "LABNEU",
      tolower(testbasename) == "platelets"                  ~ "LABPLA",
      tolower(testbasename) == "hemoglobin"                 ~ "LABHEM",
      tolower(testbasename) == "creatinine" &
        labcomponent == "Creatinine, serum"                 ~ "LABCRE",
      tolower(testbasename) == "bilirubin"                  ~ "LABBIL",
      tolower(testbasename) == "aspartate aminotransferase" ~ "LABAST",
      tolower(testbasename) == "alanine aminotransferase"   ~ "LABALT",
      tolower(testbasename) == "alkaline phosphatase"       ~ "LABALP",
      tolower(testbasename) == "albumin" &
        labcomponent == "Albumin, serum"                    ~ "LABALB",
      tolower(testbasename) == "lymphocytes"                ~ "LABLYM"),
    labdate = pmax(testdate, resultdate, na.rm = TRUE))

# One row per patient per analyte. first_labdate NULL means every record is
# undated - also a flip, because such a record can never pass the window.
pa <- lab %>%
  dplyr::filter(!is.na(analyte)) %>%
  dplyr::group_by(patientid, analyte) %>%
  dplyr::summarise(first_labdate = min(labdate, na.rm = TRUE),
                   n_records = dplyr::n(), .groups = "drop")

message("writing qcr_s1_r")
createInPersonalSchema(
  idx %>%
    dplyr::inner_join(pa, by = "patientid") %>%
    dplyr::group_by(analyte) %>%
    dplyr::summarise(
      n_index_rows_with_any_record = dplyr::n(),
      n_flip_missing_to_unknown = sum(dplyr::case_when(
        is.na(first_labdate) | first_labdate > index_date ~ 1L,
        TRUE ~ 0L), na.rm = TRUE),
      n_flip_all_records_undated = sum(dplyr::case_when(
        is.na(first_labdate) ~ 1L, TRUE ~ 0L), na.rm = TRUE),
      .groups = "drop") %>%
    dplyr::cross_join(denom) %>%
    dplyr::mutate(pct_of_all_index_rows = round(
      100 * n_flip_missing_to_unknown /
        dplyr::na_if(n_index_rows_all, 0L), 3)) %>%
    dplyr::select(analyte, n_index_rows_all, n_index_rows_with_any_record,
                  n_flip_missing_to_unknown, n_flip_all_records_undated,
                  pct_of_all_index_rows) %>%
    dplyr::arrange(dplyr::desc(n_flip_missing_to_unknown)),
  "qcr_s1_r", replace = TRUE)

# ---- S1b / Q58: the same question for BP ------------------------------------
# BP scores Missing when no systolic OR diastolic vitals record exists at
# all; the build applies testdate <= index first, exactly as with the labs.
bp <- src_("t_vitals") %>%
  dplyr::filter(tolower(test) %in% c("systolic blood pressure",
                                     "diastolic blood pressure")) %>%
  dplyr::group_by(patientid) %>%
  dplyr::summarise(first_bpdate = min(testdate, na.rm = TRUE),
                   n_records = dplyr::n(), .groups = "drop")

message("writing qcr_s1b_r")
createInPersonalSchema(
  idx %>%
    dplyr::inner_join(bp, by = "patientid") %>%
    dplyr::summarise(
      n_index_rows_with_any_record = dplyr::n(),
      n_flip_missing_to_unknown = sum(dplyr::case_when(
        is.na(first_bpdate) | first_bpdate > index_date ~ 1L,
        TRUE ~ 0L), na.rm = TRUE)) %>%
    dplyr::cross_join(denom) %>%
    dplyr::transmute(variable = "BP", n_index_rows_all,
                     n_index_rows_with_any_record, n_flip_missing_to_unknown),
  "qcr_s1b_r", replace = TRUE)

# ---- S2 / Q63: labs where the RAW vs DERIVED date reading matters -----------
# Only rows with testdate null and resultdate present can differ. If this
# comes back empty, Q63 closes with no code change.
message("writing qcr_s2_r")
createInPersonalSchema(
  src_("t_lab") %>%
    dplyr::filter(is.na(testdate) & !is.na(resultdate)) %>%
    dplyr::transmute(
      patientid, testresultcleaned,
      analyte = dplyr::case_when(
        tolower(testbasename) == "neutrophils"                ~ "LABNEU",
        tolower(testbasename) == "platelets"                  ~ "LABPLA",
        tolower(testbasename) == "hemoglobin"                 ~ "LABHEM",
        tolower(testbasename) == "creatinine" &
          labcomponent == "Creatinine, serum"                 ~ "LABCRE",
        tolower(testbasename) == "bilirubin"                  ~ "LABBIL",
        tolower(testbasename) == "aspartate aminotransferase" ~ "LABAST",
        tolower(testbasename) == "alanine aminotransferase"   ~ "LABALT",
        tolower(testbasename) == "alkaline phosphatase"       ~ "LABALP",
        tolower(testbasename) == "albumin" &
          labcomponent == "Albumin, serum"                    ~ "LABALB",
        tolower(testbasename) == "lymphocytes"                ~ "LABLYM")) %>%
    dplyr::filter(!is.na(analyte)) %>%
    dplyr::group_by(analyte) %>%
    dplyr::summarise(
      n_rows_testdate_null_resultdate_present = dplyr::n(),
      n_patients = dplyr::n_distinct(patientid),
      n_rows_also_value_positive = sum(dplyr::case_when(
        testresultcleaned > 0 ~ 1L, TRUE ~ 0L), na.rm = TRUE),
      .groups = "drop") %>%
    dplyr::arrange(dplyr::desc(n_rows_testdate_null_resultdate_present)),
  "qcr_s2_r", replace = TRUE)

# ---- S3 / Q59 step 1: is ScoreSerial ever <= 0? -----------------------------
# PSABL is PSA_INDEX, taken from ScoreSerial. If nothing is <= 0 the guard
# can never fire and Q59 closes as a free defensive condition.
message("writing qcr_s3_r")
createInPersonalSchema(
  src_("t_enh_prostate_psa") %>%
    dplyr::summarise(
      n_psa_rows = dplyr::n(),
      n_null     = sum(dplyr::case_when(is.na(scoreserial) ~ 1L,
                                        TRUE ~ 0L), na.rm = TRUE),
      n_zero     = sum(dplyr::case_when(scoreserial == 0 ~ 1L,
                                        TRUE ~ 0L), na.rm = TRUE),
      n_negative = sum(dplyr::case_when(scoreserial < 0 ~ 1L,
                                        TRUE ~ 0L), na.rm = TRUE),
      n_patients_le_zero = dplyr::n_distinct(dplyr::case_when(
        scoreserial <= 0 ~ patientid)),
      min_scoreserial = min(scoreserial, na.rm = TRUE)),
  "qcr_s3_r", replace = TRUE)

# ---- S3b / Q59 step 2: rows where the PSABL > 0 guard actually fires --------
# Reproduces PSA_INDEX exactly (earliest ScoreSerial in [INDEX-14, INDEX],
# max value on that earliest date). Meaningful only if qcr_s3_r shows
# scoreserial <= 0 somewhere.
win <- idx %>%
  dplyr::inner_join(src_("t_enh_prostate_psa") %>%
                      dplyr::select(patientid, resultdate, scoreserial),
                    by = "patientid") %>%
  dplyr::filter(dplyr::between(resultdate, date_sub(index_date, 14L),
                               index_date)) %>%
  dplyr::select(cohort, patientid, index_date, resultdate, scoreserial)

first_dt <- win %>%
  dplyr::group_by(cohort, patientid, index_date) %>%
  dplyr::summarise(psa_dt = min(resultdate, na.rm = TRUE), .groups = "drop")

psabl <- win %>%
  dplyr::inner_join(first_dt, by = c("cohort", "patientid", "index_date",
                                     "resultdate" = "psa_dt")) %>%
  dplyr::group_by(cohort, patientid, index_date) %>%
  dplyr::summarise(psabl = max(scoreserial, na.rm = TRUE), .groups = "drop")

message("writing qcr_s3b_r")
createInPersonalSchema(
  psabl %>%
    dplyr::group_by(cohort) %>%
    dplyr::summarise(
      n_rows_with_psabl = dplyr::n(),
      n_psabl_le_zero = sum(dplyr::case_when(psabl <= 0 ~ 1L,
                                             TRUE ~ 0L), na.rm = TRUE),
      n_psabl_zero    = sum(dplyr::case_when(psabl == 0 ~ 1L,
                                             TRUE ~ 0L), na.rm = TRUE),
      n_psabl_negative = sum(dplyr::case_when(psabl < 0 ~ 1L,
                                              TRUE ~ 0L), na.rm = TRUE),
      .groups = "drop") %>%
    dplyr::arrange(cohort),
  "qcr_s3b_r", replace = TRUE)

# ---- S4 / Q56: what the [INDEX-30, INDEX+7] ECOG window costs cohorts 3-7 ---
# The old rule matched baseline ECOG on line number and start date with no
# date bound; under the window every out-of-window row reads Unknown/Missing.
# n_lost has a baseline under the old rule and none under the new one.
matched <- idx_lot %>%
  dplyr::inner_join(src_("t_enh_prostate_bsln_ecog") %>%
                      dplyr::select(patientid, linenumber, linestartdate,
                                    ecogdate),
                    by = c("patientid", "linenumber",
                           "index_date" = "linestartdate")) %>%
  dplyr::mutate(gap_days = datediff(ecogdate, index_date))

per_row <- matched %>%
  dplyr::group_by(cohort, patientid, index_date) %>%
  dplyr::summarise(
    in_window = max(dplyr::case_when(
      dplyr::between(gap_days, -30L, 7L) ~ 1L, TRUE ~ 0L), na.rm = TRUE),
    earliest_gap = min(gap_days, na.rm = TRUE),
    latest_gap   = max(gap_days, na.rm = TRUE),
    .groups = "drop")

message("writing qcr_s4_r")
createInPersonalSchema(
  per_row %>%
    dplyr::group_by(cohort) %>%
    dplyr::summarise(
      n_rows_with_baseline_ecog_old_rule = dplyr::n(),
      n_rows_kept_new_rule = sum(in_window, na.rm = TRUE),
      n_lost               = sum(1L - in_window, na.rm = TRUE),
      # where the lost assessments sit relative to index - stale readings or
      # plausible baselines
      n_lost_all_before_minus30 = sum(dplyr::case_when(
        in_window == 0L & latest_gap < -30L ~ 1L, TRUE ~ 0L), na.rm = TRUE),
      n_lost_all_after_plus7 = sum(dplyr::case_when(
        in_window == 0L & earliest_gap > 7L ~ 1L, TRUE ~ 0L), na.rm = TRUE),
      min_gap_days = min(earliest_gap, na.rm = TRUE),
      max_gap_days = max(latest_gap, na.rm = TRUE),
      .groups = "drop") %>%
    dplyr::mutate(pct_lost = round(
      100 * n_lost / dplyr::na_if(n_rows_with_baseline_ecog_old_rule, 0L), 1)) %>%
    dplyr::select(cohort, n_rows_with_baseline_ecog_old_rule,
                  n_rows_kept_new_rule, n_lost, pct_lost,
                  n_lost_all_before_minus30, n_lost_all_after_plus7,
                  min_gap_days, max_gap_days) %>%
    dplyr::arrange(cohort),
  "qcr_s4_r", replace = TRUE)

# ---- S5 / Q57: four-way split of the DTHFUFL inputs -------------------------
# Reads the delivered ADS - the preliminary dates are output columns. Death
# with no FU end scores 0, not NULL (spec has no third state); no death is
# the only NULL case. n_out_of_domain must be 0.
message("writing qcr_s5_r")
createInPersonalSchema(
  ads %>%
    dplyr::mutate(inputs = dplyr::case_when(
      !is.na(death_dt_preliminary) &
        !is.na(fu_enddt_preliminary) ~ "1 both present",
      !is.na(death_dt_preliminary)   ~ "2 death, no FU end",
      !is.na(fu_enddt_preliminary)   ~ "3 FU end, no death",
      TRUE                           ~ "4 neither")) %>%
    dplyr::group_by(inputs) %>%
    dplyr::summarise(
      n_rows     = dplyr::n(),
      n_patients = dplyr::n_distinct(patid),
      n_dthfufl_null = sum(dplyr::case_when(is.na(dthfufl) ~ 1L,
                                            TRUE ~ 0L), na.rm = TRUE),
      n_dthfufl_0 = sum(dplyr::case_when(dthfufl == 0 ~ 1L,
                                         TRUE ~ 0L), na.rm = TRUE),
      n_dthfufl_1 = sum(dplyr::case_when(dthfufl == 1 ~ 1L,
                                         TRUE ~ 0L), na.rm = TRUE),
      n_out_of_domain = sum(dplyr::case_when(
        !is.na(dthfufl) & !(dthfufl %in% c(0L, 1L)) ~ 1L,
        TRUE ~ 0L), na.rm = TRUE),
      .groups = "drop") %>%
    dplyr::arrange(inputs),
  "qcr_s5_r", replace = TRUE)

# ---- S6 / Q73: lines that exist with no LINENAME ----------------------------
# A null name lands in category 17 "No treatment" (Q64); a blank name misses
# that branch and falls to 16 "Any other therapy". Two source shapes, two
# different delivered answers, neither a real treatment - count both.
message("writing qcr_s6_r")
createInPersonalSchema(
  src_("t_enh_prostate_lot") %>%
    dplyr::filter(linesetting %in% c("mHSPC", "mCRPC")) %>%
    dplyr::group_by(linesetting) %>%
    dplyr::summarise(
      n_lines    = dplyr::n(),
      n_patients = dplyr::n_distinct(patientid),
      n_null_name = sum(dplyr::case_when(is.na(linename) ~ 1L,
                                         TRUE ~ 0L), na.rm = TRUE),
      n_blank_name = sum(dplyr::case_when(
        !is.na(linename) & trimws(linename) == "" ~ 1L,
        TRUE ~ 0L), na.rm = TRUE),
      n_patients_affected = dplyr::n_distinct(dplyr::case_when(
        is.na(linename) | trimws(linename) == "" ~ patientid)),
      .groups = "drop") %>%
    dplyr::arrange(linesetting),
  "qcr_s6_r", replace = TRUE)

# ---- S7 / Q25: is the DELIVERED albumin value clinically plausible? ---------
# Q25 settled the UNIT, not the values. C10c put 99.91% of source rows in the
# g/L band and the spec's `g/L` label is correct - but the 2026-09-12 run also
# showed the g/L group reaching 42,010 and 3,878 positive serum-albumin rows
# falling outside both scale bands, and production admits any positive
# qualifying result with no range filter (Q68 forbids filtering on value).
#
# So a delivered LABALBV can be far outside anything physiological, and nothing
# so far has measured how many. Serum albumin runs about 35-50 g/L; 15-70 is
# generous on both sides, which is the point - a row outside THAT is not a
# borderline reading, it is unusable.
#
# SIZING ONLY, and the decision is register Q84 - not Q68. Q68 governs HEIGHT
# and WEIGHT; it says nothing about labs, and pointing at it left the albumin
# question with a measurement and no owner. Q84 owns it now and is unassigned.
# Q68's reasoning does carry over - a filter on value is one the spec does not
# authorise - so gating this would pre-empt the ruling rather than implement it.
message("writing qcr_s7_r")
# B2.13. Built on a seven-cohort spine. Filtering to populated LABALBV and then
# grouping made a cohort with NO albumin vanish rather than report zero, which
# reads as "nothing to see" when it is the more alarming answer.
#
# And the bands are named for what they are. `n_below_15` is not evidence of a
# g/dL scale: C10c's g/dL band is 1.5-7.0, so 7-15 is in NEITHER band and is
# simply unusable. Calling the whole sub-15 group g/dL-shaped overstated it, so
# the g/dL band is counted separately and the rest is `n_below_15_other`.
s7_spine <- data.frame(cohortn = 1:7)
s7_vals <- ads_() %>%
  dplyr::filter(!is.na(labalbv)) %>%
  dplyr::group_by(cohortn) %>%
  dplyr::summarise(
    n_with_value = dplyr::n(),
    n_plausible  = sum(dplyr::case_when(
      labalbv >= 15 & labalbv <= 70 ~ 1L, TRUE ~ 0L), na.rm = TRUE),
    n_implausible = sum(dplyr::case_when(
      labalbv < 15 | labalbv > 70 ~ 1L, TRUE ~ 0L), na.rm = TRUE),
    # the actual g/dL band, per C10c - a value near 4 that was never rescaled
    n_in_gdl_band = sum(dplyr::case_when(
      labalbv >= 1.5 & labalbv <= 7 ~ 1L, TRUE ~ 0L), na.rm = TRUE),
    # below 15 but not g/dL either: in no band at all
    n_below_15_other = sum(dplyr::case_when(
      labalbv > 0 & labalbv < 15 & !(labalbv >= 1.5 & labalbv <= 7) ~ 1L,
      TRUE ~ 0L), na.rm = TRUE),
    n_above_70    = sum(dplyr::case_when(
      labalbv > 70 ~ 1L, TRUE ~ 0L), na.rm = TRUE),
    min_val       = min(labalbv, na.rm = TRUE),
    max_val       = max(labalbv, na.rm = TRUE),
    .groups = "drop")

createInPersonalSchema(
  dbplyr::copy_inline(con, s7_spine) %>%
    dplyr::left_join(s7_vals, by = "cohortn") %>%
    dplyr::mutate(
      n_with_value     = coalesce(n_with_value, 0L),
      n_plausible      = coalesce(n_plausible, 0L),
      n_implausible    = coalesce(n_implausible, 0L),
      n_in_gdl_band    = coalesce(n_in_gdl_band, 0L),
      n_below_15_other = coalesce(n_below_15_other, 0L),
      n_above_70       = coalesce(n_above_70, 0L),
      pct_implausible  = dplyr::case_when(
        n_with_value > 0 ~ round(100 * n_implausible / n_with_value, 4),
        TRUE ~ NA)) %>%
    dplyr::arrange(cohortn),
  "qcr_s7_r", replace = TRUE)

if (exists("qcr_stamp")) qcr_stamp("05_sizing")

message("DONE - nothing was fetched. Read in the SQL editor:")
for (t in c("qcr_s1_r", "qcr_s1b_r", "qcr_s2_r", "qcr_s3_r", "qcr_s3b_r",
            "qcr_s4_r", "qcr_s5_r", "qcr_s6_r", "qcr_s7_r"))
  message("  SELECT * FROM ", personal_schema, ".", t)
