-- =============================================================================
-- WHAT IF "LAST ACTIVITY" MEANS THE LAST CLINICIAN NOTE?
-- =============================================================================
-- WHY THIS EXISTS. Ben's counter of 2026-09-11 defines FUED as "the death date
-- when available, and the last activity in the absence of death". It settles
-- WHICH of the two dates wins. It does not say what counts as activity, and
-- neither does Pratyk's proposal that it superseded. So the build still uses
-- the specification's first-iteration list - 5B.ClinChars row 89, four sources:
--
--   fu_enddt_preliminary = pmax(last_visitdate, last_televisitdate,
--                               last_lotenddate, last_oralenddate)
--
-- The owner states (2026-09-13) that activity means the LAST CLINICIAN NOTE.
-- If that is the intent, the delivered follow-up end is wrong, and wrong for
-- every patient without a death date rather than only for register Q83's 594.
--
-- LASTCLINICNOTEDATE is already in this product. 05_outcomes.R reads it and
-- rwPFS censors on it. So one delivered outcome already treats it as the
-- end of observation while FUED - and therefore OS, FUDUR and TTNT - does not.
--
-- THIS FILE DOES NOT CHANGE ANYTHING. It sizes the change so it can be decided
-- and proposed on numbers. Read-only, runs after the build.
--
--     Rscript validation/run_sql.R validation/13_fued_activity_sizing.sql
--
--   ${catalog} = hive_metastore    ${schema} = your personal schema
--   ${ads}     = rwdp_pros_pano_2026m06
--   ${src}     = clnprw_flatiron_pano_pros_use
--
-- TWO READINGS ARE SIZED SEPARATELY, because they are not the same proposal
-- and one of them can LOSE follow-up:
--
--   ADD      fu_enddt_preliminary becomes the latest of the four sources AND
--            the last clinician note. Follow-up can only lengthen or stay. No
--            patient loses anything, and nobody's FUED becomes NULL who did
--            not already have one.
--
--   REPLACE  fu_enddt_preliminary becomes the last clinician note, full stop,
--            and the four sources are dropped. This reads more literally as
--            "activity IS the clinician note" - but it SHORTENS follow-up for
--            any patient whose last visit or therapy end post-dates their last
--            note, and makes FUED NULL for any patient with no note at all.
--            Against the owner's stated priority of losing nothing, that is a
--            cost that has to be seen before it is chosen.
--
-- SCOPE. FUED is COALESCE(DTHDT, FU_ENDDT_preliminary), so changing the
-- activity date moves FUED only for patients with NO death date. Everyone with
-- one keeps the death date under either reading. That bounds the blast radius
-- before a single row is counted, and S2 measures it.
-- =============================================================================

USE CATALOG ${catalog};

-- ---------------------------------------------------------------------------
-- S1. COVERAGE. Does the last clinician note exist for the patients it would
-- govern?  A definition that is NULL for a large share of the no-death
-- population fails under REPLACE however well it reads.
--
-- @assert positive patients_total
-- ---------------------------------------------------------------------------
WITH pt AS (
  SELECT patid,
         MAX(dthdt)                AS dthdt,
         MAX(fu_enddt_preliminary) AS four_src
  FROM   ${schema}.${ads}
  GROUP  BY patid),
j AS (
  SELECT p.*, n.lastnote
  FROM   pt p
  LEFT JOIN (SELECT patientid, MAX(lastclinicnotedate) AS lastnote
             FROM   ${src}.t_enh_prostate_prog_scled_2026m06
             GROUP  BY patientid) n
         ON n.patientid = p.patid)
SELECT COUNT(*)                                                          AS patients_total,
       COALESCE(SUM(CASE WHEN dthdt IS NOT NULL THEN 1 ELSE 0 END), 0)   AS with_death_date,
       COALESCE(SUM(CASE WHEN dthdt IS NULL THEN 1 ELSE 0 END), 0)       AS no_death_date,
       COALESCE(SUM(CASE WHEN lastnote IS NOT NULL THEN 1 ELSE 0 END), 0) AS have_a_note,
       COALESCE(SUM(CASE WHEN dthdt IS NULL AND lastnote IS NULL
                         THEN 1 ELSE 0 END), 0)                          AS no_death_and_no_note,
       COALESCE(SUM(CASE WHEN dthdt IS NULL AND four_src IS NULL
                         THEN 1 ELSE 0 END), 0)                          AS no_death_and_no_four_source
FROM   j;

-- ---------------------------------------------------------------------------
-- S2. THE BLAST RADIUS.  How many patients' FUED actually moves, under each
-- reading, and in which direction.
--
-- Only the no-death population can move - see SCOPE in the header. The two
-- readings are counted side by side so the difference between them is a
-- number rather than an argument.
--
--   add_moves_later        follow-up lengthens. The note post-dates all four.
--   repl_moves_later       same under REPLACE.
--   repl_moves_earlier     follow-up SHORTENS - a visit or therapy end
--                          post-dates the last note, and REPLACE discards it.
--   repl_becomes_null      the patient has no note, so REPLACE leaves FUED
--                          NULL and FUDUR, OS and the CSF_FU window with it.
--                          ADD cannot do this.
-- ---------------------------------------------------------------------------
WITH pt AS (
  SELECT patid,
         MAX(dthdt)                AS dthdt,
         MAX(fu_enddt_preliminary) AS four_src
  FROM   ${schema}.${ads}
  GROUP  BY patid),
j AS (
  SELECT p.patid, p.four_src, n.lastnote
  FROM   pt p
  LEFT JOIN (SELECT patientid, MAX(lastclinicnotedate) AS lastnote
             FROM   ${src}.t_enh_prostate_prog_scled_2026m06
             GROUP  BY patientid) n
         ON n.patientid = p.patid
  WHERE  p.dthdt IS NULL)
SELECT COUNT(*)                                                          AS no_death_patients,
       COALESCE(SUM(CASE WHEN GREATEST(four_src, lastnote) IS DISTINCT FROM four_src
                         THEN 1 ELSE 0 END), 0)                          AS add_moves_later,
       ROUND(AVG(CASE WHEN GREATEST(four_src, lastnote) IS DISTINCT FROM four_src
                      THEN DATEDIFF(GREATEST(four_src, lastnote), four_src) END), 2)
                                                                         AS add_mean_days_gained,
       MAX(CASE WHEN GREATEST(four_src, lastnote) IS DISTINCT FROM four_src
                THEN DATEDIFF(GREATEST(four_src, lastnote), four_src) END)
                                                                         AS add_max_days_gained,
       COALESCE(SUM(CASE WHEN lastnote > four_src THEN 1 ELSE 0 END), 0)  AS repl_moves_later,
       COALESCE(SUM(CASE WHEN lastnote < four_src THEN 1 ELSE 0 END), 0)  AS repl_moves_earlier,
       ROUND(AVG(CASE WHEN lastnote < four_src
                      THEN DATEDIFF(four_src, lastnote) END), 2)         AS repl_mean_days_lost,
       MAX(CASE WHEN lastnote < four_src
                THEN DATEDIFF(four_src, lastnote) END)                   AS repl_max_days_lost,
       COALESCE(SUM(CASE WHEN lastnote IS NULL AND four_src IS NOT NULL
                         THEN 1 ELSE 0 END), 0)                          AS repl_becomes_null
FROM   j;

-- ---------------------------------------------------------------------------
-- S3. HOW FAR things move under ADD, banded. A change that shifts a hundred
-- thousand patients by a day is not the same proposal as one that shifts two
-- thousand by a year, and the aggregate mean in S2 hides which it is.
-- ---------------------------------------------------------------------------
WITH pt AS (
  SELECT patid, MAX(dthdt) AS dthdt, MAX(fu_enddt_preliminary) AS four_src
  FROM   ${schema}.${ads} GROUP BY patid),
j AS (
  SELECT p.four_src, n.lastnote
  FROM   pt p
  LEFT JOIN (SELECT patientid, MAX(lastclinicnotedate) AS lastnote
             FROM   ${src}.t_enh_prostate_prog_scled_2026m06
             GROUP  BY patientid) n
         ON n.patientid = p.patid
  WHERE  p.dthdt IS NULL)
SELECT CASE WHEN lastnote IS NULL OR NOT lastnote > four_src
                                                 THEN '0. no change'
            WHEN DATEDIFF(lastnote, four_src) <=   30 THEN '1. up to a month'
            WHEN DATEDIFF(lastnote, four_src) <=   90 THEN '2. up to a quarter'
            WHEN DATEDIFF(lastnote, four_src) <=  365 THEN '3. up to a year'
            WHEN DATEDIFF(lastnote, four_src) <= 1095 THEN '4. one to three years'
            ELSE                                           '5. over three years'
       END                                                               AS gained,
       COUNT(*)                                                          AS patients,
       MIN(DATEDIFF(lastnote, four_src))                                 AS min_days,
       MAX(DATEDIFF(lastnote, four_src))                                 AS max_days
FROM   j
GROUP  BY 1
ORDER  BY 1;

-- ---------------------------------------------------------------------------
-- S4. DOES IT ACTUALLY FIX Q83?  The row-level question, on the 1,059.
--
-- A row is resolved when its new follow-up end reaches its index date, which
-- is FUDUR >= 1. Reaching exactly the day before - FUDUR = 0 - is counted
-- separately, because a zero-length window is still not a positive one.
--
-- Counted per ROW, not per patient, because a patient in cohorts 1 and 2 has
-- two index dates and a note can clear one without clearing the other.
-- ---------------------------------------------------------------------------
WITH aff AS (
  SELECT a.patid, a.cohortn, a.indexdt, a.fued, a.fu_enddt_preliminary AS four_src
  FROM   ${schema}.${ads} a
  WHERE  a.fued < a.indexdt),
j AS (
  SELECT f.*, n.lastnote
  FROM   aff f
  LEFT JOIN (SELECT patientid, MAX(lastclinicnotedate) AS lastnote
             FROM   ${src}.t_enh_prostate_prog_scled_2026m06
             GROUP  BY patientid) n
         ON n.patientid = f.patid)
SELECT COUNT(*)                                                          AS q83_rows,
       COUNT(DISTINCT patid)                                             AS q83_patients,
       COALESCE(SUM(CASE WHEN lastnote IS NOT NULL THEN 1 ELSE 0 END), 0) AS rows_with_a_note,
       COALESCE(SUM(CASE WHEN GREATEST(four_src, lastnote) >= indexdt
                         THEN 1 ELSE 0 END), 0)                          AS rows_resolved,
       COUNT(DISTINCT CASE WHEN GREATEST(four_src, lastnote) >= indexdt
                           THEN patid END)                               AS patients_resolved,
       COALESCE(SUM(CASE WHEN GREATEST(four_src, lastnote)
                              = DATE_ADD(indexdt, -1)
                         THEN 1 ELSE 0 END), 0)                          AS rows_reaching_fudur_zero,
       COALESCE(SUM(CASE WHEN COALESCE(GREATEST(four_src, lastnote) >= indexdt, FALSE)
                         THEN 0 ELSE 1 END), 0)                          AS rows_still_broken
FROM   j;

-- =============================================================================
-- HOW TO READ IT
-- =============================================================================
--   S2 add_moves_later is the number the study team will ask for first: how
--   many patients' follow-up changes to fix Q83's 594. If it is small, this is
--   a targeted correction. If it is most of the no-death population, it is a
--   change to the whole product's follow-up and every delivered survival
--   figure moves with it. Both are defensible; they are not the same ask, and
--   the register should not describe one as the other.
--
--   S2 repl_moves_earlier and repl_becomes_null are the cost of the literal
--   reading. ADD cannot produce either. If REPLACE is what is meant, these
--   patients lose follow-up they currently have, which runs against the
--   owner's stated priority - so the reading needs confirming explicitly
--   rather than being inferred from the phrase "activity is the clinician
--   note".
--
--   S4 rows_still_broken is what survives even after the change. Those rows
--   need a Q83 disposition regardless, and their number is the real size of
--   the ruling still owed.
--
-- WHAT THIS FILE CANNOT SETTLE. Whether the last clinician note is the RIGHT
-- definition. It is already the censoring anchor for rwPFS, which is an
-- argument from internal consistency; it is not one of the four sources
-- 5B.ClinChars row 89 lists, which is an argument the other way. That is a
-- study-team decision, and it should be recorded in section 7 beside the two
-- messages of 2026-09-11 rather than settled in a mail thread.
-- =============================================================================
