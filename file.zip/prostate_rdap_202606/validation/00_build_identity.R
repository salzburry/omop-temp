# =============================================================================
# WHICH CODE PRODUCED THIS EVIDENCE
# =============================================================================
# The complaint was that a QC result recorded only a time, so an old
# build's results and a fresh build's were indistinguishable and the release
# checklist's freshness box was a heuristic rather than a check. These fields
# make a result attributable: two runs of different code can no longer look
# identical.
#
# It lives in its own file because the programs that need it bootstrap
# differently - validation/00_connect.R for most, code/modules/00_setup.R for
# qc/05 - and neither sources the other. One definition, sourced by both, beats
# two copies that can drift.
#
# THE IDENTITY IS `program_version`, read out of code/modules/00_setup.R. That
# is a label the author bumps on a logic change, not a content hash: it proves
# nothing on its own, and a logic change made without bumping it is invisible
# here. It is recorded because a result that names no version at all cannot be
# attributed even in principle.
#
# It is read from the FILE rather than from the session, because the check
# programs bootstrap through 00_connect.R, which does not define it. Reading
# the file means the stamp describes the code on disk beside the check.
#
# WHAT IT DOES NOT CLAIM. This describes the CHECKER: the code the check ran
# from. In an ordinary run that is the same code as the build, but it is not
# the same statement as "the build that wrote this table was at this version" -
# nothing in the delivered table records that, which is exactly what is still
# open. Run the checks from the same directory as the build.
# =============================================================================

SETUP_FILE <- "code/modules/00_setup.R"

build_identity <- function() {
  # NA, not an error: an unattributable result is still a result, and a check
  # must not fail because it cannot find a label.
  ver <- tryCatch({
    ln <- readLines(SETUP_FILE, warn = FALSE)
    m  <- regmatches(
      ln, regexec('^\\s*program_version\\s*<-\\s*"([^"]+)"', ln))
    hit <- Filter(function(x) length(x) == 2L, m)
    if (length(hit)) hit[[1]][2] else NA_character_
  }, error = function(e) NA_character_)

  list(
    checker_version = ver,
    refresh         = get0("refresh",        ifnotfound = NA_character_),
    hrr_panel       = get0("hrr_panel_mode", ifnotfound = NA_character_))
}
