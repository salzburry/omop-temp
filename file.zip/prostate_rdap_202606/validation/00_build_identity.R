# =============================================================================
# WHICH CODE PRODUCED THIS EVIDENCE
# =============================================================================
# Register Q43's complaint was that a QC result recorded only a time, so an old
# build's results and a fresh build's were indistinguishable and the release
# checklist's freshness box was a heuristic rather than a check. These four
# fields make a result attributable: two runs of different code can no longer
# look identical.
#
# It lives in its own file because the programs that need it bootstrap
# differently - validation/00_connect.R for most, code/modules/00_setup.R for
# qc/05 - and neither sources the other. One definition, sourced by both, beats
# two copies that can drift.
#
# WHAT IT DOES NOT CLAIM. The commit describes the CHECKER: the checkout the
# check ran from. In an ordinary run that is the same checkout as the build, but
# it is not the same statement as "the build that wrote this table was at this
# commit" - nothing in the delivered table records that, which is exactly what
# Q43 is still open about. `checker_dirty` is the honest half: a result produced
# from a modified working tree names a commit that does not describe the code
# that ran, so it says so rather than implying reproducibility.
#
# Run it from the repo root. Outside a git checkout the commit reads NA and the
# result is simply less attributable - it does not fail.
# =============================================================================

build_identity <- function() {
  git <- function(...) suppressWarnings(tryCatch(
    system2("git", c(...), stdout = TRUE, stderr = FALSE),
    error = function(e) character(0)))
  sha   <- git("rev-parse", "--short", "HEAD")
  dirty <- git("status", "--porcelain")
  list(
    checker_commit = if (length(sha) && !is.na(sha[1])) trimws(sha[1]) else NA_character_,
    checker_dirty  = as.integer(length(dirty) > 0L),
    refresh        = get0("refresh",        ifnotfound = NA_character_),
    hrr_panel      = get0("hrr_panel_mode", ifnotfound = NA_character_))
}
