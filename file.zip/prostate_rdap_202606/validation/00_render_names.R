# =============================================================================
# THE PLACEHOLDER VALUES, IN ONE PLACE - SOURCED, NOT RUN
# =============================================================================
# Both .sql runners substitute ${catalog} / ${schema} / ${ads} / ${src}, and
# both need a fallback for the case where no session has been sourced. Those
# fallbacks were written twice and drifted twice: run_sql.R learned to read
# RENDER_ONLY as an off-switch and to honour RDAP_HRR_PANEL, and
# materialize_checks.R did not, so the same two defects survived in the sibling
# file both times they were fixed. They live here now, once.
#
# Sourced by validation/run_sql.R and validation/materialize_checks.R.
# =============================================================================

# RENDER_ONLY skips the database and prints the statements. Read as "set to
# anything", RENDER_ONLY=0 turns rendering ON and every assertion in the file
# silently never runs - a fail-quiet, because the run then looks clean having
# checked nothing. The obvious off-switches mean off.
render_only_requested <- function()
  !tolower(trimws(Sys.getenv("RENDER_ONLY"))) %in%
    c("", "0", "false", "no", "off")

# The delivered table's name, including the HRR panel suffix. This is only
# reached when no session is open, because a session's own output_table is
# always preferred. It must REJECT a panel 00_setup.R would reject, spelled the
# same way: an unvalidated value builds a table name that does not exist, and
# rendered SQL is written to be pasted into an editor and run.
HRR_PANELS <- c("flatiron_all", "olaparib_label", "talapro2")

render_ads_name <- function() {
  panel <- Sys.getenv("RDAP_HRR_PANEL", unset = "flatiron_all")
  if (!panel %in% HRR_PANELS)
    stop("RDAP_HRR_PANEL must be one of ",
         paste(sQuote(HRR_PANELS), collapse = ", "), ", got: ", panel,
         call. = FALSE)
  paste0("rwdp_pros_pano_2026m06",
         if (identical(panel, "flatiron_all")) "" else paste0("_hrr_", panel))
}

# The four substitutions, session values preferred over the pinned fallbacks.
render_subs <- function()
  c("${catalog}" = get0("output_catalog",  ifnotfound = "hive_metastore"),
    "${schema}"  = get0("personal_schema", ifnotfound = "osk02156"),
    "${ads}"     = get0("output_table",    ifnotfound = render_ads_name()),
    "${src}"     = get0("source_schema",
                        ifnotfound = "clnprw_flatiron_pano_pros_use"))
