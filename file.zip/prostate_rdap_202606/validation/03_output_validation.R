# =============================================================================
# OUTPUT VALIDATION IN R - THE V-GATES, RUN IN DATABRICKS, NOTHING FETCHED
# =============================================================================
#   Rscript validation/03_output_validation.R      (after a build, repo root)
#
# Same checks as validation/03_output_validation_databricks.sql, written as
# dplyr. Every check runs inside Databricks. Every result is written to the
# personal schema with createInPersonalSchema - the build's own write path.
# Nothing comes back to this session, so the driver's fetch crashes cannot
# happen here. X11 is the one check that also reads the progression source.
#
# Read the results in the SQL editor:
#   qcr_vgates_r     one row per gate. Every row must read PASS.
#                    V21/V27 live in validation/04_column_contract_check.R.
#   qcr_v2b_hrr_r    HRR_INDEX distribution. A reading, not a gate.
#   qcr_v2d_ratio_r  HRR vs BRCA positives. The D5b reference is about 2.80.
#   qcr_v3_tint_r    TINTCRPCHSPC signs. Positive must dominate.
#   qcr_v4_xcounts_r X01-X11 chronology counts. Record them with the release.
#   qcr_v26_cohorts_r  per-cohort actual vs the accepted figures, with the
#                    dropped count and percentage. This is what the owner reads
#                    to accept the new cohort sizes; the V26 gate
#                    row only says HOW MANY cohorts moved.
#
# The SQL's NULL rules carry over exactly:
#   `(mapping) IS NOT TRUE`  ->  filter(!coalesce(mapping, FALSE))
#       A NULL label or code fails the gate, same as the SQL.
#   `a IS DISTINCT FROM b`   ->  coalesce(a != b, TRUE) & !(is.na(a) & is.na(b))
#       True when the values differ, or one side is NULL and the other is not.
#   `CASE WHEN c THEN x ELSE y`  ->  case_when(c ~ x, TRUE ~ y)
#       A NULL condition lands on the ELSE, never on NULL.
# RP1-RP4 and W1-W3 are the 2026-09-11 ruling's four rules and the three
# behaviours they withdraw, defined in docs/VARIABLES.md section 3.
# =============================================================================

if (!exists("con")) {
  message("no open connection - sourcing validation/00_connect.R")
  source("validation/00_connect.R")
}
stopifnot(exists("con"), exists("personal_schema"), exists("output_table"),
          exists("source_schema"), exists("refresh"))

ads <- dplyr::tbl(con, dbplyr::in_schema(personal_schema, output_table))

IDX_LO <- as.Date("2011-01-01")
IDX_HI <- as.Date("2026-04-30")

# One gate row: id, what, and the failing-row count.
gate <- function(id, what, tb) {
  tb %>% dplyr::summarise(n = dplyr::n()) %>%
    dplyr::transmute(id = !!id, what = !!what, failed = as.integer(n))
}

# Label/code pair gate. A row passes only when some (label, code) pair
# matches exactly. A NULL on either side fails, same as IS NOT TRUE.
pair_gate <- function(id, what, label_col, code_col, pairs) {
  L <- rlang::sym(label_col); C <- rlang::sym(code_col)
  ors <- Map(function(l, c) rlang::expr((!!L == !!l & !!C == !!c)),
             pairs$label, pairs$code)
  cond <- Reduce(function(a, b) rlang::expr(!!a | !!b), ors)
  gate(id, what, ads %>% dplyr::filter(!coalesce(!!cond, FALSE)))
}

# a IS DISTINCT FROM b, as an expression for filter().
isd <- function(a, b) {
  a <- rlang::ensym(a); b <- rlang::ensym(b)
  rlang::expr(coalesce(!!a != !!b, TRUE) & !(is.na(!!a) & is.na(!!b)))
}

# Every listed cohort must hold at least one value of `col`. Count the
# cohorts that do; the gate fails by however many are short. A cohort with
# no rows at all cannot appear in the count, so it fails too - same as the
# SQL's left join from a literal cohort list.
cohort_missing <- function(id, what, col, ks) {
  s <- rlang::sym(col)
  ads %>% dplyr::filter(cohortn %in% !!ks & !is.na(!!s)) %>%
    dplyr::summarise(have = dplyr::n_distinct(cohortn)) %>%
    dplyr::transmute(id = !!id, what = !!what,
                     failed = as.integer(!!length(ks) - have))
}

# ---- the pair tables --------------------------------------------------------
P_AGE    <- list(label = c("0-18","19-34","35-49","50-64","65-74","75-84",">=85","Unknown"),
                 code  = c(1L,2L,3L,4L,5L,6L,7L,99L))
P_ETH    <- list(label = c("Not Hispanic or Latino","Hispanic or Latino","Unknown/Missing"),
                 code  = c(1L,2L,3L))
P_RACE   <- list(label = c("Asian","Black or African American","White","Other Race","Unknown/Missing"),
                 code  = c(1L,2L,3L,4L,5L))
P_REGION <- list(label = c("Northeast","Midwest","South","West","Other region","Missing","Unknown"),
                 code  = c(1L,2L,3L,4L,5L,6L,99L))
P_PRAC   <- list(label = c("Academic only","Community only","Both academic and community","Missing"),
                 code  = c(1L,2L,3L,99L))
P_STAGE  <- list(label = c("0","I","II","III","IV","Unknown/not documented"),
                 code  = c(1L,2L,3L,4L,5L,99L))
P_ECOG   <- list(label = c("0","1","2","3","4","Unknown/Missing"), code = c(1L,2L,3L,4L,5L,6L))
P_GLEA   <- list(label = c("<8",">=8","Unknown/Missing"),          code = c(1L,2L,3L))
P_BMI    <- list(label = c("Underweight","Normal weight","Overweight","Obese","Missing"),
                 code  = c(1L,2L,3L,4L,5L))
P_BIO    <- list(label = c("Positive","Negative","VUS","Unknown/Not documented"),
                 code  = c(1L,2L,3L,4L))
P_LOTGR  <- list(label = c("0","1","2","3","4","5+"), code = c(1L,2L,3L,4L,5L,6L))
P_BP     <- list(label = c("Present","Unknown","Missing"), code = c(1L,2L,3L))
P_TEST   <- list(label = "Unknown", code = 7L)
P_CAT17  <- list(label = c("Abiraterone monotherapy","Enzalutamide monotherapy",
                           "Apalutamide monotherapy","Darolutamide monotherapy",
                           "NHA combination therapy","Docetaxel monotherapy",
                           "Docetaxel combination therapy","Cabazitaxel-containing",
                           "Other chemotherapy-containing","Pluvicto-containing",
                           "Radium 223-containing","PARPi monotherapy",
                           "Pembrolizumab-containing","Sipuleucel-T-containing",
                           "Clinical study drug-containing","Any other therapy",
                           "No treatment"),
                 code  = 1:17)

# ---- V26's comparison, kept as a table rather than a scalar -----------------
# The gate row can only carry a count of differing cohorts. The owner's
# acceptance needs the actual and the delta per cohort, so the comparison is
# built once here, written to its own table, and reused by the gate.
# The counts the owner accepted on 2026-09-12 as the ones the ruling
# produces. They replaced the 2026-08-09 figures, which described the cut
# before the per-cohort death exclusion. A delivered count that differs from
# these is now a defect rather than a new baseline.
#
# The 2026-08-09 figures survive in exactly one place - the snapshot capture's
# `baseline_mismatch` - because that check proves the snapshot is the PRE-ruling
# table. Do not "fix" those to match these.
v26_baseline <- dbplyr::copy_inline(con, data.frame(
  cohortn  = 1:7,
  expected = c(196549L, 133299L, 78635L, 50327L, 28865L, 16007L, 8582L)))

# right_join from the baseline, not inner_join: a cohort that produced NO rows
# at all has nothing to group, so an inner join would drop it silently and the
# gate would read "this cohort did not move". It must report actual = 0 and a
# 100% drop instead, which is the loudest row in the table.
v26_cmp <- ads %>%
  dplyr::group_by(cohortn) %>%
  dplyr::summarise(actual = dplyr::n_distinct(patid), .groups = "drop") %>%
  dplyr::right_join(v26_baseline, by = "cohortn") %>%
  dplyr::mutate(actual      = coalesce(actual, 0L),
                dropped     = expected - actual,
                pct_dropped = round(100 * (expected - actual) / expected, 3))

message("writing qcr_v26_cohorts_r")
createInPersonalSchema(v26_cmp, "qcr_v26_cohorts_r", replace = TRUE)

# ---- V1: the gates ----------------------------------------------------------
gates <- list(

  gate("V01", "one row per patid+cohortn",
       ads %>% dplyr::group_by(patid, cohortn) %>%
         dplyr::summarise(k = dplyr::n(), .groups = "drop") %>%
         dplyr::filter(k > 1L)),

  # V01b: the key itself. V01 counts duplicate (patid, cohortn) pairs, and a
  # NULL or blank patid groups as happily as a real one - one row per key, key
  # unusable, gate green. Every join in the QC pack and every downstream
  # analysis keys on this column, so it has to be present and non-blank.
  # TRIM catches the whitespace-only case that IS NOT NULL alone would pass.
  gate("V01b", "patid is present and not blank",
       ads %>% dplyr::filter(is.na(patid) | trimws(patid) == "")),

  ads %>% dplyr::summarise(n = abs(dplyr::n_distinct(cohortn) - 7L)) %>%
    dplyr::transmute(id = "V02", what = "exactly 7 cohorts", failed = as.integer(n)),

  gate("V03", "cohortn/cohort labels paired",
       ads %>% dplyr::filter(!coalesce(
         (cohortn == 1L & cohort == "Overall mHSPC")     |
         (cohortn == 2L & cohort == "Overall mCRPC")     |
         (cohortn == 3L & cohort == "L1+ treated mHSPC") |
         (cohortn == 4L & cohort == "L1+ treated mCRPC") |
         (cohortn == 5L & cohort == "L2+ treated mCRPC") |
         (cohortn == 6L & cohort == "L3+ treated mCRPC") |
         (cohortn == 7L & cohort == "L4+ treated mCRPC"), FALSE))),

  gate("V04", "cohortun/cohortu paired",
       ads %>% dplyr::filter(!coalesce(
         (cohortun == 1L & cohortu == "Untreated mCRPC") |
         (cohortun == 2L & cohortu == "Treated mCRPC")   |
         (cohortun == 3L & cohortu == "Untreated mHSPC") |
         (cohortun == 4L & cohortu == "Treated mHSPC"), FALSE))),

  gate("V05", "index anchor matches cohort (null-safe)",
       ads %>% dplyr::filter(
         (cohortn == 1L & !!isd(indexdt, mhspcdd))      |
         (cohortn == 2L & !!isd(indexdt, mcrpcdd))      |
         (cohortn == 3L & !!isd(indexdt, lot1sd_mhspc)) |
         (cohortn == 4L & !!isd(indexdt, lot1sd_mcrpc)) |
         (cohortn == 5L & !!isd(indexdt, lot2sd_mcrpc)) |
         (cohortn == 6L & !!isd(indexdt, lot3sd_mcrpc)) |
         (cohortn == 7L & !!isd(indexdt, lot4sd_mcrpc)))),

  gate("V06", "index inside study window",
       ads %>% dplyr::filter(is.na(indexdt) | indexdt < !!IDX_LO | indexdt > !!IDX_HI)),

  # V07/V08 under the 2026-09-11 follow-up ruling. The
  # per-cohort death exclusion guarantees DTHDT >= INDEXDT, so every
  # death-derived date orders correctly and the negative-rwPFS population
  # is gone at the source - V07b and V08b are now strict proofs that the
  # exclusion held, not sizings.
  #
  # FUED >= INDEXDT holds for every patient WITH a death date, because FUED is
  # that death date and the exclusion put it on or after the index. It does not
  # hold for a patient with NO death date: FUED is then the last activity date,
  # which nothing ties to the index, so a negative FUDUR - and on that same
  # branch a negative OS and TTNT - is possible. V46 sizes that residue; it is
  # unruled. V07 fails on any negative V46 does not account for.
  # The exemption is per metric AND per branch, because only some branches read
  # FUED. Two traps here:
  #
  # (1) The branch cannot be inferred from TTNT's VALUE. A death-driven event
  #     has DTHDT = FUED - FUED IS the death date under the ruling - so the event
  #     formula and the censored formula produce the identical number on every
  #     death-driven row. Numeric equality would classify all of them as
  #     censored and exempt them. TTNTFL is not delivered, so the branch
  #     is rebuilt from delivered fields instead: the cohort's own
  #     next-treatment date and DTHFL, exactly as 05_outcomes.R derives TTNTFL.
  #
  # (2) `fued < indexdt` is not the same as "the duration is negative". A FUED
  #     exactly one day before the index gives DATEDIFF + 1 = 0, so a genuine
  #     arithmetic regression delivering a negative there would be excused.
  #     The exemption tests the EXPECTED duration, not the date ordering.
  gate("V07", "no negative time-to-event unexplained by short follow-up",
       ads %>% dplyr::mutate(
         # the censored value the spec would produce for this row
         expect_cens = datediff(fued, indexdt) + 1,
         short_fu    = coalesce(expect_cens < 0, FALSE),
         next_trt    = dplyr::case_when(
           cohortn == 3L ~ pmin(lot2sd_mhspc, lot1sd_mcrpc, na.rm = TRUE),
           cohortn == 4L ~ lot2sd_mcrpc,
           cohortn == 5L ~ lot3sd_mcrpc,
           cohortn == 6L ~ lot4sd_mcrpc,
           TRUE ~ NA),
         # TTNTFL rebuilt: an event is a next treatment or a death
         ttnt_cens   = cohortn %in% 3:6 & coalesce(id3mosfu == 1L, FALSE) &
                         is.na(next_trt) & coalesce(dthfl == 0L, FALSE)) %>%
         dplyr::filter(
           (fudur < 0 & !short_fu) |
           (os    < 0 & (coalesce(dthfl == 1L, FALSE) | !short_fu)) |
           (ttnt  < 0 & (!ttnt_cens | !short_fu)))),

  gate("V07b", "no negative rwPFS  (the 2026-09-11 ruling removes the cause)",
       ads %>% dplyr::filter(pfs < 0)),

  gate("V08", "date ordering invariants",
       ads %>% dplyr::filter((!is.na(dthdt) & dthdt < indexdt) |
                             (!is.na(pfsdt) & pfsdt < indexdt))),

  gate("V08b", "index date after death date  (the death exclusion held)",
       ads %>% dplyr::filter(!is.na(dthdt) & indexdt > dthdt)),

  pair_gate("V09", "agegr1 mapping",  "agegr1",  "agegr1n",  P_AGE),
  pair_gate("V10", "eth mapping",     "eth",     "ethn",     P_ETH),
  pair_gate("V11", "race mapping",    "race",    "racen",    P_RACE),
  pair_gate("V12", "region1 mapping", "region1", "region1n", P_REGION),
  pair_gate("V13", "practic mapping", "practic", "practicn", P_PRAC),
  pair_gate("V14", "stage mapping",   "stage",   "stagen",   P_STAGE),
  pair_gate("V15", "ecog mapping",    "ecog",    "ecogn",    P_ECOG),
  pair_gate("V16", "gleason mapping", "gleason", "gleasonn", P_GLEA),
  pair_gate("V17", "bmigr1 mapping",  "bmigr1",  "bmigr1n",  P_BMI),
  pair_gate("V18", "hrr mapping",     "hrr_index",  "hrr_indexn",  P_BIO),
  pair_gate("V19", "brca mapping",    "brca_index", "brca_indexn", P_BIO),
  pair_gate("V20", "lotngr1 mapping", "lotngr1", "lotngr1n", P_LOTGR),

  gate("V22", "overall cohorts missing ttnt/pfs/vis120",
       ads %>% dplyr::filter(cohortn %in% c(1L, 2L) &
         (!is.na(ttnt) | !is.na(vis120) | !is.na(eligpfs) |
          !is.na(pfsfl) | !is.na(pfsdt) | !is.na(pfs)))),

  gate("V23", "cohort 7 has no ttnt",
       ads %>% dplyr::filter(cohortn == 7L & !is.na(ttnt))),

  cohort_missing("V24", "EVERY treated cohort has ttnt (per cohort)", "ttnt", 3:6),
  cohort_missing("V25", "EVERY treated cohort has pfs (per cohort)",  "pfs",  3:7),

  # V26: distinct-patient counts per cohort against the accepted figures. These
  # are the post-ruling counts, accepted after the 2026-09-11 follow-up ruling
  # added the per-cohort death exclusion, so they are the figures a correct
  # build must reproduce EXACTLY. A difference is a DEFECT and this row FAILS.
  # It read REVIEW only while the literals were the stale 2026-08-09 pre-ruling
  # baseline, which they no longer are.
  #
  # `failed` here is only the NUMBER of cohorts whose count moved - a gate row
  # carries one scalar and cannot hold seven. The magnitudes the owner needs in
  # order to accept are written separately, to qcr_v26_cohorts_r below. Do not
  # send a reader to qcr_v4_xcounts_r for them; that table holds X01-X11
  # chronology counts and nothing per cohort.
  gate("V26", "cohort counts vs the accepted post-ruling figures - a difference is a DEFECT",
       v26_cmp %>% dplyr::filter(actual != expected)),

  pair_gate("V28", "bp mapping", "bp", "bpn", P_BP),
  pair_gate("V29", "hrr_index_test mapping",  "hrr_index_test",  "hrr_index_testn",  P_TEST),
  pair_gate("V30", "brca_index_test mapping", "brca_index_test", "brca_index_testn", P_TEST),

  pair_gate("V31", "lot1cat_mhspc/lot1catn_mhspc mapping", "lot1cat_mhspc", "lot1catn_mhspc", P_CAT17),
  pair_gate("V32", "lot2cat_mhspc/lot2catn_mhspc mapping", "lot2cat_mhspc", "lot2catn_mhspc", P_CAT17),
  pair_gate("V33", "lot1cat_mcrpc/lot1catn_mcrpc mapping", "lot1cat_mcrpc", "lot1catn_mcrpc", P_CAT17),
  pair_gate("V34", "lot2cat_mcrpc/lot2catn_mcrpc mapping", "lot2cat_mcrpc", "lot2catn_mcrpc", P_CAT17),
  pair_gate("V35", "lot3cat_mcrpc/lot3catn_mcrpc mapping", "lot3cat_mcrpc", "lot3catn_mcrpc", P_CAT17),
  pair_gate("V36", "lot4cat_mcrpc/lot4catn_mcrpc mapping", "lot4cat_mcrpc", "lot4catn_mcrpc", P_CAT17),

  gate("V37", "run stamps carry their exact values",
       ads %>% dplyr::filter(!coalesce(
         datav == "20260630" &
         rawrwd == "Flatiron Prostate Panoramic Dataset" &
         minindex == !!IDX_LO & maxindex == !!IDX_HI, FALSE))),

  pair_gate("V38", "hrr_label_index/hrr_label_indexn mapping",
            "hrr_label_index", "hrr_label_indexn", P_BIO),
  pair_gate("V39", "lotngr1_mhspc/lotngr1n_mhspc mapping",
            "lotngr1_mhspc", "lotngr1n_mhspc", P_LOTGR),

  gate("V40", "dthfl agrees with dthdt",
       ads %>% dplyr::mutate(expect = dplyr::case_when(!is.na(dthdt) ~ 1L, TRUE ~ 0L)) %>%
         dplyr::filter(!!isd(dthfl, expect))),

  gate("V41", "dthfufl null iff there is no death date",
       ads %>% dplyr::filter(is.na(dthfufl) != is.na(death_dt_preliminary))),

  gate("V42", "dthfufl = 1 iff death_prelim - fu_end_prelim <= 120",
       ads %>% dplyr::mutate(expect = dplyr::case_when(
                 datediff(death_dt_preliminary, fu_enddt_preliminary) <= 120L ~ 1L,
                 TRUE ~ 0L)) %>%
         dplyr::filter(!is.na(dthfufl) & !!isd(dthfufl, expect))),

  gate("V43", "dthfufl domain is {0,1} - the spec Values list",
       ads %>% dplyr::filter(!is.na(dthfufl) & !(dthfufl %in% c(0L, 1L)))),

  # --- the 2026-09-11 follow-up ruling -------------------
  # V44/V45/V47 check RP2 and W3. Each would pass silently if the old code came
  # back, so they are worth their cost: a reinstated promotion or clamp is
  # exactly the kind of drift that reads as plausible in review. W1 and W2
  # cannot be reached from delivered columns at all - both moved
  # DEATH_DT_preliminary before DTHDT was set, so V44 stays green if either
  # returns, and qc/05 C21 is the only guard.
  gate("V44", "dthdt equals death_dt_preliminary - no row-92 promotion",
       ads %>% dplyr::filter(!!isd(dthdt, death_dt_preliminary))),

  gate("V45", "dth_before_fued is constant 0 - unreachable under the ruling",
       ads %>% dplyr::filter(!coalesce(dth_before_fued == 0L, FALSE))),

  # REVIEW, not FAIL: this is the exposure the ruling opened and has not yet
  # ruled on. Removing the index floor on FUED means follow-up can end before
  # the cohort's index date, which delivers a negative FUDUR and, for a patient
  # with no death date, a negative OS and TTNT. Read the count, then decide
  #. A nonzero count does not stop the run.
  gate("V46", "follow-up ends before index - negative FUDUR/OS/TTNT (the open follow-up disposition, unruled)",
       ads %>% dplyr::filter(fued < indexdt)),

  # V46 can only fire on a patient with no death date. If it ever reports rows
  # that HAVE one, the exclusion or the FUED rule has broken, and that is a
  # failure rather than the open follow-up disposition residue - hence the separate strict gate.
  gate("V46b", "no death-dated patient has follow-up before index",
       ads %>% dplyr::filter(fued < indexdt & !is.na(dthdt))),

  # the open follow-up disposition's OTHER population. A NULL FUED makes V46's `fued < indexdt` UNKNOWN,
  # so V46 cannot see it, and the null sweep only judges all-null or constant
  # columns - so without this row the second half of the open follow-up disposition reaches nobody.
  gate("V46c", "follow-up end is NULL - no death date and no activity (the open follow-up disposition, unruled)",
       ads %>% dplyr::filter(is.na(fued))),

  gate("V47", "fued is dthdt when present, else fu_enddt_preliminary",
       ads %>% dplyr::filter(!coalesce(
         fued == coalesce(dthdt, fu_enddt_preliminary) |
           (is.na(fued) & is.na(dthdt) & is.na(fu_enddt_preliminary)), FALSE))),

  # V2c is a gate too, so it sits in the same table.
  gate("V2c", "brca positive implies hrr positive",
       ads %>% dplyr::filter(brca_index == "Positive" &
                             coalesce(hrr_index != "Positive", TRUE)))
)

# V2e holds only when the built panel is at least the label panel. A talapro2
# build is narrower, so the gate is skipped there - same instruction as the
# SQL. The panel comes from RDAP_HRR_PANEL, default flatiron_all.
if (!identical(Sys.getenv("RDAP_HRR_PANEL", "flatiron_all"), "talapro2")) {
  gates <- c(gates, list(
    gate("V2e", "hrr_label positive implies hrr positive",
         ads %>% dplyr::filter(hrr_label_index == "Positive" &
                               coalesce(hrr_index != "Positive", TRUE)))))
} else {
  message("V2e skipped: talapro2 panel is narrower than the label panel")
}

# V26 IS A GATE, NOT A REVIEW ROW, and was wrongly the latter until 2026-09-13.
# It was classed REVIEW when the accepted counts were still provisional. They
# were signed on 2026-09-12, so a delivered count that differs from them is now
# a DEFECT and must stop the run - and while V26 sat in this list the verdict
# below excluded it, so any mismatch exited zero under a printed PASS.
#
# V46 and V46c stay REVIEW because they remain genuinely unruled: they size a
# population nobody has decided the disposition of, and a count there is a
# reading rather than a failure.
vgates <- Reduce(dplyr::union_all, gates) %>%
  dplyr::mutate(status = dplyr::case_when(
    failed == 0L ~ "PASS",
    id %in% c("V46", "V46c") ~ "REVIEW",
    TRUE ~ "FAIL"))

message("writing qcr_vgates_r (", length(gates), " gates)")
createInPersonalSchema(vgates, "qcr_vgates_r", replace = TRUE)

# ---- V2b / V2d / V3: informational tables -----------------------------------
message("writing qcr_v2b_hrr_r")
createInPersonalSchema(
  ads %>% dplyr::group_by(hrr_index) %>%
    dplyr::summarise(n = dplyr::n(), .groups = "drop") %>%
    dplyr::mutate(pct = round(100 * n / sum(n, na.rm = TRUE), 2)),
  "qcr_v2b_hrr_r", replace = TRUE)

message("writing qcr_v2d_ratio_r")
createInPersonalSchema(
  ads %>% dplyr::summarise(
    hrr_positive  = sum(dplyr::case_when(hrr_index  == "Positive" ~ 1L, TRUE ~ 0L), na.rm = TRUE),
    brca_positive = sum(dplyr::case_when(brca_index == "Positive" ~ 1L, TRUE ~ 0L), na.rm = TRUE)) %>%
    dplyr::mutate(hrr_per_brca = round(
      hrr_positive / dplyr::na_if(brca_positive, 0L), 2)),
  "qcr_v2d_ratio_r", replace = TRUE)

message("writing qcr_v3_tint_r")
createInPersonalSchema(
  ads %>% dplyr::summarise(
    neg_tint = sum(dplyr::case_when(tintcrpchspc < 0 ~ 1L, TRUE ~ 0L), na.rm = TRUE),
    pos_tint = sum(dplyr::case_when(tintcrpchspc > 0 ~ 1L, TRUE ~ 0L), na.rm = TRUE),
    non_null = sum(dplyr::case_when(!is.na(tintcrpchspc) ~ 1L, TRUE ~ 0L), na.rm = TRUE)),
  "qcr_v3_tint_r", replace = TRUE)

# ---- V4: the X chronology counts --------------------------------------------
xcount <- function(id, tb) {
  tb %>% dplyr::summarise(n = dplyr::n()) %>%
    dplyr::transmute(what = !!id, n = as.integer(n))
}

prog_last <- dplyr::tbl(con, dbplyr::in_schema(
                source_schema, paste0("t_enh_prostate_prog_scled_", refresh))) %>%
  # the driver reports source columns in stored case, not always lower
  dplyr::rename_with(tolower) %>%
  dplyr::group_by(patientid) %>%
  dplyr::summarise(lastnote = max(lastclinicnotedate, na.rm = TRUE), .groups = "drop")

xcounts <- list(
  xcount("X01 fued after MAXINDEX",  ads %>% dplyr::filter(fued  > !!IDX_HI)),
  xcount("X02 dthdt after MAXINDEX", ads %>% dplyr::filter(dthdt > !!IDX_HI)),
  xcount("X03 pfsdt after dthdt (ADS rows)", ads %>% dplyr::filter(pfsdt > dthdt)),
  ads %>% dplyr::filter(pfsdt > dthdt) %>%
    dplyr::summarise(n = dplyr::n_distinct(patid)) %>%
    dplyr::transmute(what = "X03b pfsdt after dthdt (distinct patients)", n = as.integer(n)),
  xcount("X04 pfsdt after fued", ads %>% dplyr::filter(pfsdt > fued)),
  # X05 is unreachable since the ruling: FUED is DTHDT wherever a death date exists
  # and NULL-vs-NULL cannot satisfy `>`, so this can only ever read 0. Kept as
  # a standing proof of the COALESCE rule from the other direction to V47.
  xcount("X05 fued after dthdt (unreachable under the ruling)",
         ads %>% dplyr::filter(fued > dthdt)),
  xcount("X06 psma_scandt after MAXINDEX", ads %>% dplyr::filter(psma_scandt > !!IDX_HI)),
  xcount("X07 os censored (dthfl=0) but fued < indexdt",
         ads %>% dplyr::filter(dthfl == 0L & fued < indexdt)),
  xcount("X08 psa50_6mo=N with no 6mo PSA or no baseline",
         ads %>% dplyr::filter(psa50_6mo == "N" & (is.na(psa6mo) | is.na(psa_index)))),
  xcount("X09 psa50_12mo=N with no 12mo PSA or no baseline",
         ads %>% dplyr::filter(psa50_12mo == "N" & (is.na(psa12mo) | is.na(psa_index)))),
  xcount("X10 vis120=0 while the INDEX line has no end date",
         ads %>% dplyr::mutate(index_ed = dplyr::case_when(
                   cohortn == 3L ~ lot1ed_mhspc,
                   cohortn == 4L ~ lot1ed_mcrpc,
                   cohortn == 5L ~ lot2ed_mcrpc,
                   cohortn == 6L ~ lot3ed_mcrpc,
                   cohortn == 7L ~ lot4ed_mcrpc)) %>%
           dplyr::filter(vis120 == 0L & is.na(index_ed))),
  xcount("X11 pfsdt (progression-derived) after the last clinic note",
         ads %>% dplyr::inner_join(prog_last, by = c("patid" = "patientid")) %>%
           dplyr::filter(pfsdt > lastnote & (is.na(dthdt) | pfsdt != dthdt)))
)

message("writing qcr_v4_xcounts_r")
createInPersonalSchema(Reduce(dplyr::union_all, xcounts), "qcr_v4_xcounts_r",
                       replace = TRUE)

if (exists("qcr_stamp")) qcr_stamp("03_output_validation")

# qcr_v26_cohorts_r belongs in this list. The PASS branch below names it, but
# that is the wrong place to name it alone: a run that FAILS never reaches
# that message, and a failing V26 is exactly when the per-cohort sizes are the
# thing to read.
message("All results written. Read in the SQL editor:")
for (t in c("qcr_vgates_r", "qcr_v26_cohorts_r", "qcr_v2b_hrr_r",
            "qcr_v2d_ratio_r", "qcr_v3_tint_r", "qcr_v4_xcounts_r"))
  message("  SELECT * FROM ", personal_schema, ".", t)

# Fail-closed: one tiny verdict fetch. A verdict that cannot be fetched is
# not a pass - every table above is already written, so exit 2 and read
# qcr_vgates_r yourself.
v <- tryCatch(DBI::dbGetQuery(con, paste0(
       "SELECT COUNT(*) AS n FROM ", personal_schema,
       ".qcr_vgates_r WHERE failed IS NULL OR status IS NULL",
       " OR (failed > 0 AND status <> 'REVIEW')")),
     error = function(e) NULL)
if (is.null(v)) {
  message("verdict fetch failed - read qcr_vgates_r before trusting the run")
  quit(status = 2L, save = "no")
} else if (v$n[1] > 0) {
  message("FAIL - ", v$n[1], " gate(s) failing. See qcr_vgates_r.")
  quit(status = 1L, save = "no")
} else {
  message("PASS - no gate failing. V26 is a gate now, not a reading, so the ",
          "cohort counts match the accepted figures. TWO advisory rows remain ",
          "in qcr_vgates_r: V46 and V46c size the unruled follow-up ",
          "populations - follow-up before the index, and follow-up NULL. ",
          "Per-cohort sizes are in qcr_v26_cohorts_r, NOT qcr_v4_xcounts_r, ",
          "which holds X01-X11 only.")
}
