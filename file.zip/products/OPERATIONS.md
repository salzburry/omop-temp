# Operations: refresh lifecycle, QC, and TFLs

How an RWDP goes from a new data cut to a signed-off, delivered set of tables — and how git tracks
all of it. Complements `ROADMAP.md` (the build framework) with the **delivery + governance** layer.

## The lifecycle (per tumor, per refresh)

```
  new refresh (data cut)                       e.g. 2026q1 -> 2026q2
        │
        ▼
  build STAGING    databricks bundle run rwdp_build --var tumor_slug=… --var refresh=…
        │          (shared engine: validate -> preflight -> build; rows stamped spec_version+data_refresh)
        ▼
  semantic QC      engine/qc.run_qc(staged) -> engine/qc.qc_gate(report, thresholds)
        │          (null-rates, treatment catch-all rate, unmapped-stage rate, date-castability)
        ▼
  golden compare   engine/golden.run_golden(staged, reference_ads) -> golden_gate
        │          (row/cohort deltas, lotcat distributions, OS summary; either gate fails -> no publish)
        ▼
  deliverables     engine/tfl.generate(staged,…) + engine/dictionary (.md + .xlsx) + engine/dashboard
        │          (the dashboard MANIFEST contract; a REQUIRED one failing blocks publish)
        ▼
  durable ledger   engine/refresh.build_manifest(...) -> artifact_root manifest + QC  (BEFORE publish, fail-loud)
        │          (spec_version, git_commit, counts, qc+golden gates, per-deliverable status, release pointer)
        ▼
  publish          versioned + view pointer: write IMMUTABLE {final}__{refresh}__{build_id}[ __tfl_<id>]
        │          (build_id = git sha + run id/timestamp, UNIQUE PER RUN -> a rerun mints a NEW version,
        │          never overwriting a live one; a versioned-table collision fails loud). All versioned
        │          writes first, THEN swap public VIEWS — TFLs first, ADS LAST (the commit anchor);
        │          staging dropped only after; published_at only after the swap (engine/release.py). Not a
        │          single-transaction set swap: CONSUMERS SHOULD ANCHOR ON THE ADS VIEW (swapped last) —
        │          a direct TFL reader could momentarily see a new TFL before the ADS view flips.
        │
        ▼
  release          promote manifest -> refreshes/<family>/<product>/<spec_version>/<refresh>.yaml (COMMIT); status: released + sign-off; tag
```

> **Consuming a release.** Read the ADS through its public view (the commit anchor, swapped last) and
> TFLs through `release.tfls` in the manifest — not by globbing `{final}__tfl_*` directly. A TFL that a
> later spec stops producing leaves its old public view live (the runner records these as `retired_tfls`
> and warns); retire it manually — the engine never auto-drops a consumer-readable view. A manifest with
> `status: released` is guaranteed to carry `published_at` + a valid `release` block (validated).

## Git architecture (refreshes tracked)

- **Spec/engine changes** → feature branch → PR → `main` (reviewed config diff; CI lints every
  tumor config + runs the pure-Python tests).
- **A refresh** (data cut only, no code change) → a `--var refresh=…` run + a committed
  `refreshes/<family>/<product>/<spec_version>/<refresh>.yaml` manifest. The manifest's `git_commit` pins the exact
  engine + spec, so the ADS is **reproducible**: checkout the tag, re-run the same config.
- **Release tag**: `release/<registry_code>/<spec_version>/<refresh>` (e.g. `release/mcrpc/202606/2026q1`) — the
  `spec_version` segment avoids cross-version collisions (see `../docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md` §G);
  none cut yet. The ADS rows carry matching `spec_version` + `data_refresh` stamps (added in `assemble`).
- **Audit**: git history of `refreshes/` is the ledger — who built/QC'd/released what, when, from
  which commit. Superseded refreshes are kept (`status: superseded`).

See `../refreshes/README.md` (+ `REFRESH_TEMPLATE.yaml`) for the manifest, and `_reporting/tfl/README.md` for TFLs.

## Side-by-side R validation (optional — NOT a governed run)

The R engine (`../platform/engine-r/`) reads the **same config** and builds the same ADS, for the
R-proficient team to cross-check the Python build. It is a **validation aid, not part of the lifecycle
above**: it has no source-QC/golden/release gates, no manifest, and no view swap — it writes the table
**directly**, so it must target a **separate `_r` schema**, never the governed `output_schema`. On a
Databricks cluster (or Domino→Databricks via sparklyr), from the repo root:

```bash
Rscript platform/engine-r/run_rwdp.R --allow_direct_write=true \
  --config_path=products/oncology/<product>/<spec_version>/config/data_product.yaml \
  --refresh=<cut> --source_schema=<src> --output_schema=<out>_r
```

Then close the loop with the **same `engine/golden.py` gate** the lifecycle uses: re-run the Python
build pointing `--var reference_table=<out>_r.<ads_table>`, so the R ADS is golden-compared against the
governed Python ADS (row/cohort counts, lotcat distribution, OS summary, column diff). `--allow_direct_write=true`
is required (fail-closed); full Domino→Databricks connection detail + caveats: `../platform/engine-r/README.md`.

## What's built vs next

- **Built + tested (pure-Python cores):** refresh manifest build/validate/**write** + `artifacts`
  (`engine/refresh.py`); the **source QC gate** + ADS QC gate + thresholds + **QC report**
  (`engine/qc.py`, `engine/qc_report.py`); the **data dictionary** per neutral audience —
  internal/partner/customer, `partner` replacing the old "sales", with PII drop + `.xlsx`
  (`engine/dictionary.py`); the TFL spec + producibility planner + **product-limit KM** table
  (`engine/tfl.py`); all with catalog cross-checks.
- **R cross-validation engine** (`engine-r/`): a side-by-side R implementation on the **same
  config/YAML**, for the R-proficient team to validate logic and cross-check the build. The
  config→Spark-SQL compilers are **proven byte-identical** to PySpark in CI
  (`tests/test_r_parity.py`); the sparklyr build is review-only and its **acceptance gate is the
  golden-compare** of the R ADS vs the Python ADS (`engine/golden.py`). See `engine-r/README.md`.
- **Runner wired end-to-end** (`databricks/run_rwdp.py`, Spark/cluster-only): preflight →
  **source-QC gate** → build → staging → **ADS QC gate + golden gate** (either failing keeps
  staging, no publish) → **required deliverables** (dictionary + TFLs, each required/optional/skip
  per the config `deliverables:` block; a **required** one that fails blocks publish, status
  recorded) → **durable release ledger** (manifest + QC report written to `artifact_root`,
  **fail-loud**) → **temp-then-swap publish**. The ledger is written BEFORE the swap so a publish
  can never happen without a durable record; `artifact_root` is **writability-probed up front**
  (hard-fail in prod, warn in dev). The pre-swap manifest carries `published_at: null`; it is stamped
  with `published_at` and re-written only AFTER a successful swap, so a null `published_at` can never
  be mistaken for a successful publish. The manifest carries the full source-QC **report + gate**, the
  **golden gate**, and per-deliverable status. A **promote** step commits the manifest from
  `artifact_root` into `refreshes/` (a job can't push to git). Spark execution
  (`run_qc`/`run_golden`/`tfl.generate`/stages) is cluster-only.
- **Next (a lot more):**
  - confirm a first end-to-end cluster run (the bundle has notifications + UC + temp-swap; retries are
    disabled — deterministic QC/golden/source-QC gate failures should not be re-run blindly);
  - figures (KM curve render) + listings export in `tfl.generate`; per-tumor TFL overlays;
  - extend proven R↔Python parity to the inline clinical/OS SQL (death imputation, OS anchor) — see
    `engine-r/README.md` "Next";
  - tumor-class modules (heme Ann Arbor/IPI/Lugano-EFS) — `ROADMAP.md` Phase 7;
  - access control / PII suppression on dashboard + listings.
