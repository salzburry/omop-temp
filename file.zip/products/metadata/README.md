# Master variable spec (`metadata/`)

The cross-tumor variable governance source.

- `the program-spec (Teams; scans retired)` — master variable catalog (Category · Variable ·
  Label · naming · per-tumor applicability sheets: NSCLC/OC/EC/mCRC/SCLC/DLBCL/mCRPC). Scanned photos.
- `the program-spec (Teams; scans retired)` — per-tumor variable definitions (Category ·
  Variable · Label · Cohort · Definition · Notes). Scanned, 49 pages.
- `catalog.yaml` — **machine-readable** form the tumor packs validate against. **Status: seed** —
  populated with the variables the prostate pack already emits (correct, working). Full population
  (every row + all tumor applicability) still needs transcription from the two PDFs above.

`catalog.yaml` is cross-checked by `platform/tests/test_catalog.py`: it is well-formed, its tumor
codes match `../registry.yaml`, and — already enforced in CI, not deferred — **every variable a tumor
pack emits must resolve to a catalog entry** (`test_catalog_documents_every_emitted_variable`, all four
tumors). So naming/completeness governance is live today. What Phase 4 still owes is **reconciliation**:
fold `variable-specs/` and `oncology/packs/` into this one catalog (not three), and finish transcribing
every row + all tumor-applicability from the two PDFs above (the catalog is still a seed).
