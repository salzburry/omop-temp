# Dashboard layer (`dashboard/`)

Consumer-facing dashboard variables for the RWDPs.

- `the program-spec (Teams; scans retired) vars.pdf` — the source spec (scanned, 9 pages; consolidated
  with the other uploaded scans under the repo-root `the program-spec (Teams; scans retired)`).
- `dashboard_vars.yaml` — **machine-readable** panel/variable layout. **Status: seed** — a
  representative set whose variables reference codes in `../metadata/catalog.yaml`; the full
  set needs transcription from the PDF.

Cross-checked by `platform/tests/test_catalog.py` (every dashboard variable resolves to a catalog
code). Phase 5 will generate the consumer data dictionary from this + the catalog (reuse
`rwddataproduct_example/build_dictionary` patterns).
