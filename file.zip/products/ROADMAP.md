# RWDP multi-tumor framework — roadmap & way forward

> **⚠ Post-migration note.** The physical restructure is **done**: the shared engine is **`platform/`**
> and products live under **`products/oncology/<product>/`** (NOT `current data products/` / `_framework/`).
> The "Target architecture" tree and any `_framework/` / `current data products/` paths **below are the
> historical plan** — for the realized layout see [`../README.md`](../README.md) and
> [`../docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md`](../docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md). This page
> is kept for the *way-forward* narrative (phases, tumor onboarding), not as the structural source of truth.

Status: in progress. Owner: RWP/RWDE. Integrates to `main`; spec/engine changes land via short-lived
feature branches + PR.

This plan turns the per-tumor RWDP scripts + variable specs in `products/oncology/` into one
**config-driven, multi-tumor framework** — building on the prostate (mCRPC) engine already in
`prostate/` and the spec frameworks already in the repo (`variable-specs/`, `oncology/packs/`).

> The **delivery + governance** layer — git-tracked refreshes, the QC gate, and TFL generation —
> is documented in [`OPERATIONS.md`](OPERATIONS.md) (`refreshes/`, `engine/qc.py` gate,
> `tfl/`). The pure-Python cores AND the Spark runner are built + tested (R-parity green); the one
> remaining step is the real Databricks dev smoke on Panoramic data.
>
> A second engine in **R** (`platform/engine-r/`) runs **side by side** with PySpark on the
> **same config/YAML**, so the R-proficient team can read/validate the logic and the two engines
> cross-check. The config→SQL compilers are **proven byte-identical** in CI
> (`platform/tests/test_r_parity.py`); see [`engine-r/README.md`](../platform/engine-r/README.md).

---

## 1. What's in the repo now (inventory)

> **[HISTORICAL — pre-migration inventory + plan.]** §1–§6 below describe the repo *before* the executed
> restructure and use the OLD layout (`current data products/`, `_framework/`, top-level `variable-specs/`
> / `oncology/` / `rwddataproduct_example/`). The realized layout is **`platform/`** (engine) +
> **`products/`** (configs); the prior reference material has since been removed from the repo — see
> [`../README.md`](../README.md)
> and [`../docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md`](../docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md).

### Scanned source material (photographed PDFs — image only, no clean text layer)
The uploaded scans are consolidated under the repo-root [`the program-spec (Teams; scans retired)`](../the program-spec (Teams; scans retired));
paths below are relative to it.
| Path (under `the program-spec (Teams; scans retired)`) | What it is |
|---|---|
| `metadata/masterspec.pdf` (13pp) | **Master variable catalog**, cross-tumor. Columns: Category · Variable (code) · Label · General notes · For-Search naming · Value. Tumor sheets: **NSCLC, OC, EC, mCRC, SCLC, DLBCL, mCRPC**. The naming/governance source of truth. |
| `metadata/tumorspecs.pdf` (49pp) | **Per-tumor variable specs** (detailed). Columns: Category · Variable · Label · Cohort · Definition · Notes. Same tumor tabs. The definition source of truth. |
| `dashboard/dashboard vars.pdf` (9pp) | **Dashboard (consumer-facing) variable** definitions. |
| `oc/ocrdap.pdf`, `oc/onfunc.pdf` | **Ovarian (OC)** RWDP R/dbplyr script + helper functions (`t_enh_ov_*` tables). |
| `endometrial/ecscan{1,2,3,6}.pdf` | **Endometrial (EC)** RWDP R code + helpers (split across files). |
| `prostate/prostate rdap.pdf` | **Prostate (mCRPC)** RWDP R code (already ported — see below). |

Every tumor follows the **same pattern**: an R/dbplyr script reads `t_enh_<tumor>_*` Databricks
tables, builds a patient-level ADS (demographics → clinical characteristics → treatment/LOT →
outcomes OS/TTD/TTNT → cohort labels) and writes `rwdp_<tumor>_pano_<YYYYMM>`.

### Already built — the template
`prostate/` is the **config-driven PySpark port** of the mCRPC script: locked engine + YAML config
(`config/`, `variables/`, `codelists/`), a Databricks Asset Bundle, a validator + source preflight,
and 20 pure-Python tests + Spark tests. This is the executable template every other tumor reuses.

### Existing spec frameworks in the repo (to reconcile, not duplicate)
- **`variable-specs/`** — "single source of truth for variable definitions: spec-driven,
  config-only, version-controlled." JSON-Schema-validated YAML, an engine (`validate` /
  `build_dictionary` / `derive`), variable types (gold_standard / parameterised / assembled).
- **`oncology/packs/`** — cohort + variable YAML packs already scaffolded for
  `flatiron_ovarian`, `flatiron_endometrial`, `flatiron_prostate`, `flatiron_nsclc`,
  `flatiron_sclc`, … plus `concept_sets/`. **OC and EC scaffolds already exist here.**
- **`rwddataproduct_example/`** — data-dictionary / dashboard build tooling (`build_dictionary`,
  `packs`, `audiences`).

> The master/tumor specs are the **human-authored source** that these machine-readable frameworks
> should be generated from. Today we have three partial frameworks + scanned source; the plan
> below unifies them.

---

## 2. Target architecture

> **[HISTORICAL]** The `current data products/` / `_framework/` tree below was the *original proposal*;
> the realized end-state is `platform/` + `products/` (see the §1 note).

```
current data products/
  _framework/                 # NEW: shared, tumor-agnostic engine (promoted from prostate/engine)
    engine/                   #   locked PySpark: sources, index, demographics, clinical,
                              #   treatment, outcomes, assemble, validate, codelists
    databricks/               #   ONE Asset Bundle, parameterised by `tumor`
  metadata/
    catalog.yaml              # NEW: machine-readable master catalog (from the scanned specs)
  <tumor>/                    # one folder per tumor (mcrpc, oc, ec, nsclc, …)
    <tumor> rdap.pdf          #   original scan (kept for provenance)
    config/data_product.yaml  #   run params, cohorts, source-table map, index rule
    variables/                #   tunable derivation params (this tumor's slice of the catalog)
    codelists/                #   treatment categories etc.
  dashboard/
    dashboard_vars.yaml       # NEW: consumer variables -> data dictionary
```

Principle (unchanged): **code locked, config driven.** The engine is shared and stable; each
tumor is a reviewed config diff. A new tumor = a new config pack, not new engine code.

**Vendor- and class-aware:** `engine/vendors.py` resolves table names per data vendor — **Flatiron**
(solid) vs **COTA** (heme: DLBCL/CLL/MDS). Config declares `vendor` + `tumor_class` (solid|heme),
the LOT line-setting filter is config-driven, and **sources are optional** so heme/COTA products
(no provenge/alphabet/vitals) validate and run on the same engine.

---

## 3. Gap analysis (per tumor)

| Tumor | R source | Onc pack scaffold | Config pack | Engine port | State |
|---|---|---|---|---|---|
| **mCRPC** (prostate) | ✓ | `flatiron_prostate` | ✓ `prostate/` | core ADS built (incl. vis120/TTD/TTNT/trtdis) | needs cluster run + golden comparison; additive TODO (prior-taxane flags) |
| **OC** (ovarian) | ✓ `oc/` | `flatiron_ovarian` | ✓ scaffold | shared | lint-clean pack; verify-vs-scan |
| **EC** (endometrial) | ✓ `endometrial/` | `flatiron_endometrial` | ✓ scaffold | shared | lint-clean pack; verify-vs-scan |
| NSCLC, SCLC, mCRC (Flatiron solid) | not yet | partial packs | — | shared | planned (in master spec) |
| **DLBCL** (COTA heme) | oncology pack | `cota_dlbcl` | ✓ scaffold | shared (vendor=cota) | lint-clean heme proof; needs heme modules |
| **MDS** (COTA heme) | from DLBCL template | — | ✓ scaffold | shared (vendor=cota) | lint-clean heme scaffold; needs heme modules |
| CLL (COTA heme, upcoming) | not yet | — | — | shared | planned |

---

## 4. Phased roadmap

### Phase 0 — Specs → machine-readable catalog  ◐ SEED  *(foundation)*
Transcribe `masterspec.pdf` + `tumorspecs.pdf` into one structured `metadata/catalog.yaml`:
`category · variable_code · label · definition · per-tumor applicability · naming`. **Blocker:**
these are photographed spreadsheets (same OCR problem as the prostate PDF) — accurate transcription
needs the **original Excel** if it exists (see Decisions). Output anchors all validation.

### Phase 1 — Shared engine  ✅ DONE
The engine moved `prostate/engine` → `platform/engine` (tumor-agnostic, unchanged behaviour).
`prostate/` is now a pure config pack. Added: `registry.yaml` (the tumor list — `active` /
`scaffold` / `planned`, with HNSCC/GIST/… already slotted in as `planned`),
`platform/TUMOR_TEMPLATE/` (copy-me skeleton), `platform/databricks/run_rwdp.py` (generic
runner) + one `databricks.yml` parameterised by `tumor_slug` (syncs the whole tree, excludes
scans), `platform/README.md` (the *add-a-tumor* recipe), and `test_registry.py` (auto-validates
every active tumor). All engine tests pass from `platform/tests` against the reference tumor.

### Phase 2 — Port OC (ovarian)  ◐ scaffold (lint-clean; verify-vs-scan)
From `the program-spec (Teams; scans retired)` + `the program-spec (Teams; scans retired)` + `tumorspecs` (OC tab) + `oncology/packs/*ovarian`:
build `oc/config|variables|codelists`, wire to the shared engine, add the OC source-table map
(`t_enh_ov_*`), OC cohorts/index, OC treatment codelist, and Spark tests. Same fail-fast preflight.

### Phase 3 — Port EC (endometrial)  ◐ scaffold (lint-clean; verify-vs-scan)
Same recipe from `the program-spec (Teams; scans retired)` + `tumorspecs` (EC tab) + `*endometrial` pack.

### Phase 4 — Catalog integration & cross-tumor validation  ◐ catalog + cross-checks
Extend the validator so every product variable resolves to a `catalog.yaml` entry (naming
governance), and reconcile with `variable-specs/` + `oncology/packs/` so there's **one** catalog,
not three. CI lints every tumor pack against the catalog.

### Phase 5 — Dashboard layer  ◐ seed
Encode `dashboard vars.pdf` → `dashboard/dashboard_vars.yaml`; generate the consumer data
dictionary (reuse `rwddataproduct_example/build_dictionary` patterns), keyed to the catalog.

### Phase 7 — Heme modules (tumor_class: heme)  ◐ vendor+optional-sources done; modules pending
Selected by `tumor_class: heme`: Ann Arbor staging + IPI (vs AJCC/FIGO), Lugano/IWG response + EFS
(vs OS-only), transplant/CAR-T/bispecific exposure, cell-of-origin. The vendor layer, optional
sources, and a lint-clean COTA `dlbcl/` scaffold are in place; the heme clinical/outcome modules
are the additive next step. CLL + MDS slot in once specced.

### Phase 8 — Fold the EC/OC reconstructions into config + engine  ✅ DONE
From [`TUMOR_COMPARISON.md`](TUMOR_COMPARISON.md) (built by reconstructing the original EC/OC scripts
into `endometrial/endometrial_rdap.R` + `oc/ovarian_rdap.R`). Each item is an additive, config-driven
block + a pure (R↔Python parity-testable) compiler:
1. ✅ **Sources union** (`sources.union`): EC = Flatiron EDM ∪ Dostarlimab registry (`db=EDM/DOS`).
2. ✅ **Cohort model**: per-cohort `index`/`lot_number`/`maintenance`/`line_setting` (EC `lota/lot1m`,
   OC `lot1m/lot2m`); plus `derived_cohorts` (OC PROC = 2L+ platinum-resistant, cohortn 9, `pick:first`).
3. ✅ **Clinical sub-blocks** (CASE / closest-to-index compilers like `stage_case`): grade, histology,
   TNM, invasion, residual, biomarker-panel, lab-panel, tumor_markers (Gleason/PSA; CA-125 via
   lab-panel), **surgery** (PCS/ICS + neoadj + `tt_first_tx_diag`), **EC radiation** + recurrence-date
   pass-throughs. The enhanced pass-through is now a config-driven `passthrough` (columns + presence
   `flags`) block — no more prostate-hardcoded list.
4. ✅ **ECOG closest-to-index** (window `[-30,+7]`; 6-step nearest-record incl. max-grade tie-break).
5. ✅ **Outcomes**: `line_outcomes` (vis120/TTD/TTNT/trtdis); progression/PFS (+PFS2) from evidence
   flags; OC platinum-sensitivity (PFI). OC follow-up/death already shared with `follow_up_and_death`.
6. ✅ **`minavaildate`/`basedur`** data-availability floor.
Done so far: OC treatment-codelist drug classes confirmed vs scan (`oc/codelists/`).

### Phase 6 — Run, QC, golden comparison  ◐ tools built + gated; cluster run pending  *(per tumor)*
The **semantic QC layer** (`engine/qc.py`), **golden comparison** (`engine/golden.py`) and their
**publish gates**, plus prod bundle hardening (`databricks.yml`: per-env schemas, notifications,
retries, cluster policy, Unity Catalog, write-temp-then-swap), are built + unit-tested. What remains
is the first end-to-end **cluster run** per tumor: run the bundle, golden-compare vs the original R
ADS for a known refresh, and sign off the manifest.

---

## 5. Decisions needed (these shape everything)

1. **Do the original (non-scanned) source files exist?** The Excel behind
   `masterspec`/`tumorspecs`/`dashboard vars`, and the `.R` files behind `oc`/`endometrial`. If yes,
   Phase 0 + the OC/EC ports become accurate and fast (vs transcribing photos). **This is the single
   biggest lever.**
2. **Framework location & reconciliation** — promote `prostate/engine` to a shared `_framework/`,
   and make the master catalog live in (a) `variable-specs/`, (b) `oncology/packs/`, or (c) a new
   `metadata/`? Avoid keeping three parallel variable frameworks.
3. **Language for OC/EC** — PySpark (recommended; matches prostate + the shared engine) or keep R.
4. **Priority/order** — OC then EC (both have code) before the no-code tumors (NSCLC/SCLC/mCRC/DLBCL)?

---

## 6. Immediate next steps
1. ~~Phase 1: extract the shared engine~~ — **done** (see `platform/`).
2. Phase 2: scaffold the OC config pack (`cp -r platform/TUMOR_TEMPLATE products/oncology/oc/<YYYYMM>`) and port the
   ovarian cohort/index/treatment/outcomes from `the program-spec (Teams; scans retired)` + `the program-spec (Teams; scans retired)`; flip OC to
   `active` in `registry.yaml` once it lints + tests clean.
3. Phase 3: same for EC. Then Phase 0 (machine-readable master catalog) + Phase 6 (QC/golden) per
   tumor. Source files are scans only, so OC/EC are reconstructed from the photos (flagged for
   verification, as with prostate).

Pending prostate items (carry forward into Phase 6): cluster run, semantic QC layer, golden
comparison; additive column TODOs noted in `prostate/README.md`.
