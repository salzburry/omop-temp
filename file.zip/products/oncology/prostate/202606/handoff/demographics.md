# Demographics — handoff

*The RWB "5A. Demos" tab with the gaps filled. One row per output. See `README.md` for the columns
and the ✅ / ⛔ / 🔍 legend.*

> **Before any row below — the study window.** RWB says start = **2011-01-01**; the live config says
> **2020-01-01**. That's a config change (`config/data_product.yaml → study.index_start`) and it is
> **not aligned yet** — so cohort counts and `ID3MOSFU` aren't final until it's fixed.
> `⛔ decision: STUDY-WINDOW`

| # | Output (ADS col) | Means | From | Rule + filled gaps | Status |
|---|---|---|---|---|---|
| 1 | `AGE` (age) | approx age at index | `demographics.birthyear` | `year(index) − birthyear`. **Approximate** — only birth *year* is delivered. Blank → age null → Unknown band. | 🔍 |
| 2 | `AGEGR1 / AGEGR1N` (agegrl / agegrln) | age band | from `AGE` | bands 0-18·19-34·35-49·50-64·65-74·75-84·≥85; blank/none → Unknown (99). *Confirm label `>=85` vs `≥85`.* | 🔍 |
| 3 | `REGION1 / REGION1N` (regionl / regionln) | US region from state | `demographics.state` | NE / MW / S / W / Other (PR) / Missing state-lists; blank state → Missing. **Spec-resolved (`demos.md`): academic-only sites → REGION1 = Unknown** — an engine change (needs practice/site context; current logic uses state alone), not a decision (ENGINE_GAPS). | 🔍 |
| 4 | `RACE / RACEN` (race / racen) | reported race | `demographics.race` | map values; `Hispanic or Latino` → `Other Race`; unmapped → Unknown/Missing. *Codes come from config, not yet RWB-confirmed.* | 🔍 |
| 5 | `ETH / ETHN` (eth / ethn) | Hispanic ethnicity | `demographics.race` + `ethnicity` | Hispanic if race=Hispanic **OR** ethnicity=Hispanic; else map ethnicity; blank → Unknown/Missing. *Engine today reads ethnicity only → engine change.* | 🔍 |
| 6 | `PRACTIC / PRACTICN` (practic / practicn) | academic / community | `practice.practicetype` | Academic-only / Community-only / Both. *No practice rows → Missing (99) — confirm this is intended (⛔ PRACTICE-MISSING-CODE).* | 🔍 |
| 7 | `SES` (ses) | SES index | `ses.sesindex2015_2019` | pass through; blank → Missing. | 🔍 |
| 8 | `ID3MOSFU` (id3mosfu) | ≥3 mo potential follow-up | index + study window | `MAXINDEX − INDEXDT ≥ 91` → 1 else 0. Depends on the **study window** (above), not demographics data. | ⛔ STUDY-WINDOW |
| 9 | `DTHFUFL` (dthfufl) | QC: activity after death | death + follow-up dates | flag implausible post-death activity (≥120 days). **Confirmed engine bug:** the engine caps follow-up at death first, then measures `datediff(dthdt, fued) ≤ 120` — wrong direction, on an already-death-capped FUED, so post-death activity is erased before measurement; run the QC on the **uncapped** preliminary values. The 120-day threshold + 1/0 output are known; only the operands/direction/absent-death handling are open (see dataprep row 17). | ⛔ DTHFUFL-RULE |

**Where it stands:** see the Status column per row. ⛔ decisions on this tab: **STUDY-WINDOW** (ID3MOSFU),
**DTHFUFL-RULE**. REGION1 academic→Unknown moved to `ENGINE_GAPS.md` (spec-resolved requirement). No row is ready for implementation until it is ✅ (RWP finalizes the
YAML; RWDE implements any shared-engine gap). Run the profiler on the `2026m06` cut to clear the 🔍s; close
the named decisions to clear the ⛔s.

*(STAGE / STAGEN appear on this RWB tab but are built in the Clinical tab — handed off there.)*
