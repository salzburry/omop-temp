# RWB → RWP → RWDE — the handover workflow

How a requirement travels from **RWB** (the science) through **RWP** (interpretation, profiling, the
YAML) to **RWDE** (the shared engine) — with the exact file at each step and what to do with it.

> **Ownership in one line:** RWB owns the scientific/statistical *intent*. RWP owns the *interpretation,
> the data profiling, and the executable YAML*. RWDE owns the *shared engine and the build*.

```mermaid
flowchart TD
  classDef rwb  fill:#e8f0ff,stroke:#3b6,stroke-width:1px,color:#111
  classDef rwp  fill:#fff4e6,stroke:#e8a,stroke-width:1px,color:#111
  classDef dec  fill:#fde8e8,stroke:#d66,stroke-width:1px,color:#111
  classDef rwde fill:#eafaf0,stroke:#4a4,stroke-width:1px,color:#111
  classDef out  fill:#f0f0f5,stroke:#88a,stroke-width:1px,color:#111

  A["RWB approved program spec<br/><b>PROG_SPEC_..._202606_rXX_APPROVED.xlsx</b><br/>(Excel · SharePoint/Teams · versioned)"]:::rwb

  S1["1 · Intake and version<br/>record the exact approved workbook<br/>out: <b>source_refs.yaml</b>"]:::rwp
  S2["2 · Interpret and decompose<br/>one row per output: meaning + source + rule,<br/>flag decisions<br/>out: <b>handoff/*.md</b> (draft)"]:::rwp
  S3["3 · Profile the delivered cut<br/>data_profiler.R (inventory to sampled to exact)<br/>then profile_facts.py<br/>out: <b>profile/*.tsv</b> + <b>PROFILE_FACTS_&lt;cut&gt;.md</b>"]:::rwp
  S4["4 · Finalize spec and update YAML<br/>close decisions, set stems/windows/codes<br/>out: <b>config/ variables/ codelists/*.yaml</b><br/>+ finalize <b>handoff/*.md</b> with status"]:::rwp

  D["RWB / BIO answer decisions<br/>study window, rwPFS event, CODE-ALIGN, ...<br/>out: decision log"]:::dec

  S5["5 · Implement engine gaps<br/><b>platform/engine/</b> (only rows on the engine-gap list)"]:::rwde
  S6["6 · Build + verify<br/>config to ADS; preflight, tests, QC, golden compare"]:::rwde
  R["7 · RWP validates output · RWB signs methodology<br/>8 · governed release"]:::out

  A -->|"the .xlsx (evidence, NOT a build input)"| S1
  S1 --> S2
  S2 -->|"open decisions"| D
  D -->|"resolved values"| S4
  S2 --> S3
  S3 -->|"facts are evidence; RWP clears a data-check row after review"| S4
  S4 ==>|"FORMAL HANDOFF<br/>handoff/*.md (ready rows) + config/ + variables/ + codelists/<br/>+ PROFILE_FACTS + acceptance cases + engine-gap list"| S5
  S5 --> S6
  S6 --> R
  R -.->|"change request / next refresh"| S2
```

## What RWP receives, produces, and hands over — step by step

| # | Step | Owner | Input file | What to do (instruction) | Output file (type) |
|---|---|---|---|---|---|
| — | **Approved spec** | RWB | — | Approve and version the program spec; keep it in SharePoint/Teams | `PROG_SPEC_…_202606_rXX_APPROVED.xlsx` *(Excel — evidence, not a build input)* |
| 1 | **Intake & version** | RWP | the `.xlsx` | Record the exact workbook identity: filename, `spec_version` (202606), document revision (rXX), stable link, approver, approval date. Note the `data_refresh` (2026m06) separately | `source_refs.yaml` *(YAML)* |
| 2 | **Interpret & decompose** | RWP | the Excel rows (6 tabs: Data Prep · Study Pop · Demographics · ClinChars · TreatVars · Outcomes) | One row per output, grouped by derivation: plain-English **meaning**, **source** `table.column`, the **rule with the gaps filled** (missing behavior, inclusive/exclusive, codes). Flag anything unsettled as `⛔ decision:<NAME>` | `handoff/dataprep.md · studypop.md · demographics.md · clinical.md · treatment.md · outcomes.md` *(Markdown — one table each)* |
| 3 | **Profile the delivered cut** | **RWP** (owns conclusions; RWP or RWDE may run the job) | the live `2026m06` Databricks cut + the config `sources:` map | Run `data_profiler.R` cheap→expensive: **`DC_INVENTORY_ONLY=1`** (confirm stems, no data pulled) → **sampled over ALL product sources in one run** (`DC_SAMPLE_N=2000`, screening — feed THIS full-scope TSV to `profile_facts.py`) → **targeted exact** only for specific checks (complete value sets, grain, duplicate keys, joins, same-day ties, window/unit/component), each with a **unique `DC_OUT_DIR`**. Do **not** feed a one-table exact TSV to the full-product reporter — it marks every other source missing (the reporter now labels that PARTIAL PRODUCT SCOPE). Confirm stems, columns, types, value sets, null rates (grain/duplicates/joins/ties/window need targeted SQL — the reporter can't establish them) | `profile/inventory_<cut>.txt`, `profile/profile_<cut>.tsv` *(TSV)*, `profile/PROFILE_FACTS_<cut>.md` *(Markdown)* |
| 4 | **Finalize spec + update YAML** | RWP | interpreted rows + profile facts + closed decisions | Set source stems / windows / codes from the profile and the decisions; update the **executable** config. Mark each handoff row `✅ ready` · `⛔ decision` · `🔍 needs data`; note engine gaps in the rule text and a shared **engine-gap list** (not a 4th status). **This is the file RWP maintains for versioning** | `config/data_product.yaml`, `variables/*.yaml`, `codelists/*.yaml` *(YAML)* + finalized `handoff/*.md` |
| ↺ | **Decisions** | RWB / BIO | the `⛔` rows | Answer methodology/scope questions (study window, MAXINDEX, rwPFS event date, biomarker window, `CODE-ALIGN`, …). RWP feeds the answer back into step 4 | decision log *(in `handoff/` / `CHANGELOG.md`)* |
| ═ | **FORMAL HANDOFF → RWDE** | RWP → RWDE | — | Hand over: the **`✅` handoff rows** + the updated `config/` + `variables/` + `codelists/` + `PROFILE_FACTS` + acceptance cases + the **engine-gap list**. **Only `✅` rows are ready to implement** — `⛔`/`🔍` stay with RWP | *(the files above)* |
| 5 | **Implement engine gaps** | RWDE | the engine-gap list (rows whose rule text flags an engine change) | Add the shared-engine capability only where the config can't express the rule (e.g. a per-site metastasis date). Config-only rows need no engine work | `platform/engine/*.py` (+ `engine-r/`) |
| 6 | **Build + verify** | RWDE | config + engine | `config → ADS`; run `validate.py` + source preflight + tests + semantic QC + **golden compare** | ADS table + build/QC evidence |
| 7 | **Accept** | RWP + RWB | the built ADS | RWP checks the output against the functional contract; RWB signs methodology-sensitive results | acceptance record |
| 8 | **Release** | RWDE | — | Governed release stamped with `spec_version` + `data_refresh` + git commit | release manifest |

## File-type legend

| Type | Files | Role |
|---|---|---|
| **Excel** `.xlsx` | RWB program spec | scientific requirement (evidence; *never* a build input) |
| **YAML** `.yaml` | `config/` · `variables/` · `codelists/` · `source_refs.yaml` | **executable** product (RWP-maintained) + provenance |
| **Markdown** `.md` | `handoff/*.md` · `PROFILE_FACTS_*.md` | the RWP→RWDE functional contract + profiling evidence (generated/authored, *not* run) |
| **TSV** `.tsv` | `profile/profile_<cut>.tsv` | machine-readable profile metrics |
| **Tools** `.R` / `.py` | `data_profiler.R` · `profile_facts.py` | RWP profiling + facts reporting (deterministic, read-only) |
| **Engine** `.py` | `platform/engine/` (+ `engine-r/`) | shared, locked build engine (RWDE-owned) |

**The one rule that keeps it clean:** the **YAML is the authoritative record of the current executable
implementation**; the **approved RWB spec + closed decisions** govern the intended requirement; the
**handoff** carries meaning, evidence, decisions, and examples — it is not itself run by the engine.
