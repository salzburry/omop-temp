# Clinical example — bone metastasis (worked)

*Same format, one derivation, to show an **independent** flag + date pair. See `README.md` for the
columns and legend.*

| Output (ADS col) | Means | From | Rule + filled gaps | Status |
|---|---|---|---|---|
| `BONE_MET / BONE_METDT` (bone_met / —) | bone-met presence at index + earliest date | `metastasis.siteofmetastasis`, `dateofmetastasis` | Flag and date are **independent**: `BONE_METDT` = earliest `dateofmetastasis` where site=`bone` (case-insensitive), **regardless of index**; `BONE_MET` = Yes iff any such record is dated **`≤ INDEXDT`** (spec `≤`), else No. No bone record → No / null; a null date → not counted for the flag. | 🔍 |

**Two things to fix (both spec-resolved — not decisions):**
- **Flag/date are independent (spec `linvars.md` 84–85):** `BONE_METDT` (a STUDY_PD variable) is the earliest
  bone-met date whether or not it precedes index; `BONE_MET` (a PRE_INT variable) is the `≤ INDEXDT` test. A
  met dated *after* index → `BONE_MET`=No **but `BONE_METDT` still holds that date**.
- **Engine bugs:** the engine emits the flag but **not** the `BONE_METDT` date at all, and its flag uses strict
  `<` (spec `≤` — on-index counts). Source stem is resolved (`t_enh_prostate_som`); `bone` lowercase-matches.

**Acceptance cases** — RWP says the answer; RWDE turns them into tests:

| index = 2022-03-01 | expected (BONE_MET / BONE_METDT) |
|---|---|
| bone, `2021-06-10` | `Yes` / `2021-06-10` |
| bone, `2022-03-02` (after index) | `No` / **`2022-03-02`** (date is independent of the flag) |
| bone, `2022-03-01` (on index) | `Yes` / `2022-03-01` (spec `≤` — on-index counts) |
| bone twice: `2020-01-05`, `2021-06-10` | `Yes` / `2020-01-05` (earliest) |
| bone twice: `2022-04-01`, `2023-01-10` (both after index) | `No` / **`2022-04-01`** (earliest, still emitted) |
| bone, `null` date | `No` / `null` |

*Ready for implementation once the engine emits `BONE_METDT` (independent of the flag), uses `≤` for the flag, and the source is profiled on the live cut.*
