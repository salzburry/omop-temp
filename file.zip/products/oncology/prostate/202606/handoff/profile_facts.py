#!/usr/bin/env python3
"""Profile FACTS reporter — deterministic, read-only.

Reads a product's config `sources:` map + a data_profiler.R `profile_<cut>.tsv` and writes
PROFILE_FACTS_<cut>.md next to the TSV: per-source metrics + a few mechanical notes. Every number is
copied from the TSV; nothing is inferred.

IT DOES NOT: edit the handoff, flip any status, approve a source, or decide a rule.
It reports facts; RWP reviews them and updates the YAML/status BY HAND.

  python3 profile_facts.py <product_dir> <profile_tsv> [--out FILE]

Required TSV columns (data_profiler.R contract): table, table_base, column, kind, sampled, n_rows,
n_rows_total, pct_missing, distinct, date_min, date_max, top_values.

Honest limits: per-column metrics only — it can't establish composite grain, duplicates, join
coverage, same-day ties or window coverage (those need targeted RWP queries). Sources are read from
the raw `sources:` block (no data-format overlay resolution) — fine for an EDM product.
"""
import sys, os, csv, re, html, math, argparse, yaml

CUT = re.compile(r'_(20\d{2}(m\d{2}|q\d|\d{2})?)$')
IDENTITY = ['table', 'table_base', 'column']
REQUIRED = ['kind', 'sampled', 'n_rows', 'n_rows_total', 'pct_missing', 'distinct',
            'date_min', 'date_max', 'top_values']
BOOLS = {'TRUE', 'FALSE', 'T', 'F', '1', '0', 'YES', 'NO'}
TRUE = {'TRUE', 'T', '1', 'YES'}


def tbase(row):
    return (row.get('table_base') or '').strip() or CUT.sub('', (row.get('table') or '').strip())


def num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def load(path):
    with open(path, newline='', encoding='utf-8') as fh:
        rd = csv.DictReader(fh, delimiter='\t')
        hdr = rd.fieldnames or []
        for c in IDENTITY:
            if c not in hdr:
                sys.exit(f"ERROR: {path} missing identity column '{c}'. Got {hdr}")
        miss = [c for c in REQUIRED if c not in hdr]
        if miss:
            sys.exit(f"ERROR: {path} is missing required profiler columns: {', '.join(miss)}. "
                     "Regenerate it with the current data_profiler.R (full contract).")
        tables, dups, cuts = {}, [], set()
        for i, row in enumerate(rd, start=2):        # header is line 1
            if (row.get('sampled') or '').strip().upper() not in BOOLS:
                sys.exit(f"ERROR line {i}: sampled={row.get('sampled')!r} is not a boolean.")
            nr, nt = num(row.get('n_rows')), num(row.get('n_rows_total'))
            for name, v in (('n_rows', nr), ('n_rows_total', nt)):
                if v is None or not math.isfinite(v) or v < 0 or v != int(v):
                    sys.exit(f"ERROR line {i}: {name}={row.get(name)!r} must be a non-negative whole number.")
            if nr > nt:
                sys.exit(f"ERROR line {i}: n_rows ({nr:g}) > n_rows_total ({nt:g}).")
            pmraw = (row.get('pct_missing') or '').strip()
            if not (nr == 0 and pmraw == ''):            # zero-row table: profiler writes pct_missing=NA as ""
                pm = num(pmraw)
                if pm is None or not math.isfinite(pm) or pm < 0 or pm > 100:
                    sys.exit(f"ERROR line {i}: pct_missing={pmraw!r} must be a number in 0..100.")
            m = CUT.search((row.get('table') or '').strip())
            if m:
                cuts.add(m.group(1))
            tb, col = tbase(row), (row.get('column') or '').strip()
            if not tb or not col:
                continue
            if col in tables.get(tb, {}):
                dups.append(f"{tb}.{col}")
            tables.setdefault(tb, {})[col] = row
        if dups:
            sys.exit("ERROR: duplicate (table,column) rows (merged / multi-cut TSV?):\n  "
                     + "\n  ".join(sorted(set(dups))))
        if not tables:
            sys.exit(f"ERROR: {path} has no table/column rows — empty or malformed profile.")
        return tables, cuts


def sampling_status(tables):
    """Primary signal: the profiler's per-table `sampled` flag; n_rows<n_rows_total is a consistency check."""
    sampled = False
    for cols in tables.values():
        for m in cols.values():
            if (m.get('sampled') or '').strip().upper() in TRUE:
                sampled = True
            nt, nr = num(m.get('n_rows_total')), num(m.get('n_rows'))
            if nt is not None and nr is not None and nr < nt:
                sampled = True
    return "SAMPLED_METRICS — SCREENING ONLY (can miss rare values)" if sampled else "EXACT_METRICS (full-table counts)"


def resolve(stem, bases):
    if stem in bases:
        return stem, []
    toks = stem.split('_')[:3]
    return None, [b for b in sorted(bases) if b.split('_')[:3] == toks and b != stem][:3]


def render_value(m):
    if m.get('kind') == 'date':
        dmin, dmax = (m.get('date_min') or '').strip(), (m.get('date_max') or '').strip()
        return f"{dmin} .. {dmax}" if (dmin or dmax) else "n/a"       # zero-row date column -> n/a
    toks = (m.get('top_values') or '').split('|')[:8]        # `count:value` items; value is pipe-free
    return '<br>'.join(html.escape(t) for t in toks)         # escape <, >, & AND the split pipes


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('product_dir')
    ap.add_argument('profile_tsv')
    ap.add_argument('--out')
    ap.add_argument('--strict', action='store_true',
                    help='exit non-zero if any configured source is missing (partial-scope profile)')
    a = ap.parse_args()

    fn = os.path.basename(a.profile_tsv)
    if 'profile_new' in fn or 'inventory' in fn:
        sys.exit(f"ERROR: {fn} looks PARTIAL (new-only / inventory). Use a full-scope profile_<cut>.tsv "
                 "over ALL configured sources (sampling is fine for screening; targeted exact runs are for final checks).")

    root = yaml.safe_load(open(os.path.join(a.product_dir, 'config', 'data_product.yaml'), encoding='utf-8')) or {}
    sources = root.get('sources', {})
    tables, cuts = load(a.profile_tsv)
    if len(cuts) > 1:
        sys.exit(f"ERROR: the TSV mixes cuts {sorted(cuts)} — profile one cut at a time.")
    cut = next(iter(cuts)) if cuts else None
    status = sampling_status(tables)
    spec_ver = str(root.get('version', '')).split('{snapshot}')[0].rstrip('._-/ ') or '?'
    tbset = set(tables)

    per, notes, found = [], [], 0
    for logical, stem in sorted(sources.items()):
        tb, sugg = resolve(stem, tbset)
        if tb:
            found += 1
            per.append(f"\n### ✓ table stem matched · `{logical}` → `{tb}`")
            per.append("| column | kind | null% | distinct | values / date range |")
            per.append("|---|---|---|---|---|")
            for m in tables[tb].values():
                pmv = (m.get('pct_missing') or '').strip()
                per.append(f"| `{m.get('column', '')}` | {m.get('kind', '')} | {pmv + '%' if pmv else 'n/a'} "
                           f"| {m.get('distinct', '')} | {render_value(m)} |")
        else:
            hint = f" — same-prefix tables present: {', '.join('`' + s + '`' for s in sugg)}" if sugg else ""
            per.append(f"\n### ✗ `{logical}` → config stem `{stem}` NOT FOUND{hint}")
            notes.append(f"TABLE NOT FOUND: `{logical}` stem `{stem}` absent from this profile."
                         + (f" Same-prefix tables present: {', '.join(sugg)}." if sugg else ""))

    total = len(sources)
    partial = bool(total and found < total)
    scope = "PARTIAL CONFIGURED-TABLE SCOPE" if partial else "FULL CONFIGURED-TABLE SCOPE"
    guard = []
    if total and found / total < 0.3:
        guard.append(f"⚠ ONLY {found}/{total} configured source stems matched — wrong product / cut, or a "
                     "partial (subset) profile? Treat every 'not found' below as UNKNOWN, not absent.")
    elif partial:
        guard.append(f"⚠ PARTIAL CONFIGURED-TABLE SCOPE — {found}/{total} configured source stems present. "
                     "This is a SUBSET profile (e.g. separate one-table runs); missing stems are listed under "
                     "Notes. Do NOT read a missing stem as a finding, and do NOT accept the product on this "
                     "profile — re-run over ALL configured sources in one job.")

    out = [f"# Profile FACTS — {fn}\n",
           "_Read-only, deterministic. RWP reviews these facts and updates the YAML / handoff status "
           "BY HAND. This tool never edits the handoff or approves a source._\n",
           f"- **Product:** {root.get('data_product_id', '?')}",
           f"- **Spec version:** {spec_ver} · **data cut:** {cut or 'unknown'} · input `{fn}`",
           f"- **Metric coverage:** {status}",
           f"- **Table scope:** {scope} ({found}/{total} configured table stems present — stem presence ONLY, not column/grain/join/approval coverage)",
           "- **Source approval:** not assessed by this tool",
           f"- **Sources matched:** {found}/{total} · notes: {len(notes)}", ""]
    out += [f"> {g}" for g in guard]
    out += ["\n## Notes (mechanical — a human decides if they matter)\n"]
    out += [f"- {n}" for n in notes] or ["- none"]
    out += per

    name = f"PROFILE_FACTS_{cut}.md" if cut else "PROFILE_FACTS.md"
    dest = a.out or os.path.join(os.path.dirname(os.path.abspath(a.profile_tsv)), name)
    with open(dest, 'w', encoding='utf-8') as fh:
        fh.write("\n".join(out) + "\n")
    print(f"wrote {dest}  ({found}/{total} sources, {len(notes)} notes, coverage={status.split()[0]}, scope={scope})")
    if a.strict and partial:
        sys.exit(f"ERROR (--strict): PARTIAL CONFIGURED-TABLE SCOPE — only {found}/{total} configured source "
                 "stems present. Re-run over all configured sources in one job, or drop --strict.")


if __name__ == '__main__':
    main()
