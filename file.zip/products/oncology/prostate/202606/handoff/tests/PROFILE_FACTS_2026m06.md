# Profile FACTS — profile_sample.tsv

_Read-only, deterministic. RWP reviews these facts and updates the YAML / handoff status BY HAND. This tool never edits the handoff or approves a source._

- **Product:** prostate_mcrpc_rwdp
- **Spec version:** 202606 · **data cut:** 2026m06 · input `profile_sample.tsv`
- **Metric coverage:** EXACT_METRICS (full-table counts)
- **Source approval:** not assessed by this tool
- **Sources matched:** 21/21 · notes: 0


## Notes (mechanical — a human decides if they matter)

- none

### ✓ table stem matched · `alphabet` → `t_enh_prostate_alpbta_emt`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `administrationdate` | date | 0.5% | 8 | 2011-01-20 .. 2026-06-22 |

### ✓ table stem matched · `baseline_ecog` → `t_baseline_ecog`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `ecogvalue` | categorical | 0.5% | 6 | 13600:0<br>16400:1<br>6000:2 |

### ✓ table stem matched · `biomarkers` → `t_enh_prostate_biomarker`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `biomarkername` | categorical | 0.5% | 25 | 7200:BRCA2<br>4800:ATM |

### ✓ table stem matched · `demographics` → `t_demographics`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `birthyear` | numeric | 0.1% | 74 |  |
| `state` | categorical | 2.3% | 51 | 4400:CA<br>3600:FL<br>3200:TX |
| `race` | categorical | 6.7% | 6 | 24800:White<br>6800:Black or African American<br>2000:Hispanic or Latino |
| `ethnicity` | categorical | 12.0% | 3 | 28400:Not Hispanic or Latino<br>3200:Hispanic or Latino |

### ✓ table stem matched · `diagnosis` → `t_diagnosis`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `diagnosisdate` | date | 0.5% | 8 | 2009-01-05 .. 2026-06-20 |

### ✓ table stem matched · `drug_episode` → `t_enh_prostate_drg_epsode`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `episodedate` | date | 0.5% | 8 | 2011-02-01 .. 2026-06-25 |

### ✓ table stem matched · `ecog` → `t_ecog`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `ecogvalue` | categorical | 0.5% | 6 | 12000:0<br>17600:1<br>6400:2 |

### ✓ table stem matched · `enhanced` → `t_enh_prostate`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `groupstage` | categorical | 0.5% | 8 | 12000:II<br>11000:III<br>9000:IV |

### ✓ table stem matched · `lab` → `t_enh_prostate_lab`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `testbasename` | categorical | 0.5% | 30 | 5600:Neutrophils<br>5200:Hemoglobin |

### ✓ table stem matched · `lot` → `t_enh_prostate_lot`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `linename` | categorical | 0.5% | 60 |  |

### ✓ table stem matched · `metastasis` → `t_enh_prostate_metastasis`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `siteofmetastasis` | categorical | 0.4% | 11 | 15200:bone<br>8400:lymph node<br>4800:liver |
| `dateofmetastasis` | date | 5.1% | 8 | 2011-02-03 .. 2026-06-22 |

### ✓ table stem matched · `mortality` → `t_mortality_v2`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `dateofdeath` | date | 0% | 8 | 2011-03-01 .. 2026-06-15 |

### ✓ table stem matched · `orals` → `t_enh_prostate_orals`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `enddate` | date | 0.5% | 8 | 2011-04-01 .. 2026-06-10 |

### ✓ table stem matched · `practice` → `t_practice`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `practicetype` | categorical | 0.5% | 2 | 31200:COMMUNITY<br>8800:ACADEMIC |

### ✓ table stem matched · `progression` → `t_enh_prostate_progression`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `progressiondate` | date | 3.0% | 8 | 2011-05-01 .. 2026-06-18 |

### ✓ table stem matched · `provenge` → `t_enh_prostate_provenge`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `startdate` | date | 0.5% | 8 | 2011-06-01 .. 2026-05-30 |

### ✓ table stem matched · `psa` → `t_enh_prostate_psa`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `scoreserial` | numeric | 1.2% | 9000 |  |

### ✓ table stem matched · `ses` → `t_socdetofhealth`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `sesindex2015_2019` | categorical | 41.0% | 5 | 8400:Q1<br>8000:Q2 |

### ✓ table stem matched · `telemed` → `t_telemedicine`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `visitdate` | date | 0.5% | 8 | 2016-02-01 .. 2026-06-28 |

### ✓ table stem matched · `visit` → `t_visit`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `visitdate` | date | 0.5% | 8 | 2011-01-03 .. 2026-06-29 |

### ✓ table stem matched · `vitals` → `t_vitals`
| column | kind | null% | distinct | values / date range |
|---|---|---|---|---|
| `test` | categorical | 0.5% | 40 | 8800:BODY WEIGHT<br>8400:BODY HEIGHT |
