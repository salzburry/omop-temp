#!/usr/bin/env python3
"""Product config regression test — guards categorical codes + Package-1 values.

stdlib + PyYAML. Locks in:
- CODE-ALIGN: BMIGR1N Missing=5, HRR/BRCA Unknown=4; demos-tab fallbacks stay 99.
- left-distinct: STAGEN CHECK=99, REGION1N state-null=6, ECOGN Unknown=6 / Missing=7.
- Package-1 config edits: PSA_INDEX pick=earliest, adrenal match, stage-0 group,
  biomarker Negative includes "Mutation Negative".
Run with `python3`. Targets named blocks (not "any list with VUS") so it stays precise.
"""
import os, sys, yaml

HERE = os.path.dirname(os.path.abspath(__file__))
PROD = os.path.dirname(os.path.dirname(HERE))          # .../202606
VARS = os.path.join(PROD, "variables")


def load(name):
    with open(os.path.join(VARS, name), encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def dicts_with(root, key):
    """Every dict in the tree that has `key`."""
    out = []
    if isinstance(root, dict):
        if key in root:
            out.append(root)
        for v in root.values():
            out += dicts_with(v, key)
    elif isinstance(root, list):
        for x in root:
            out += dicts_with(x, key)
    return out


def named(root, name, must_have):
    """The single dict with name==`name` that also carries `must_have`."""
    hits = [d for d in dicts_with(root, "name") if d.get("name") == name and must_have in d]
    return hits[0] if hits else None


def fallthrough(codelist):
    codes = [it["code"] for it in codelist if it.get("when") == "fallthrough"]
    assert len(codes) == 1, f"expected exactly one `when: fallthrough`, got {codes}"
    return codes[0]


def codelist_with(root, needle):
    hits = []
    for lst in _all_codelists(root):
        if needle.lower() in " | ".join(str(i.get("label", "")).lower() for i in lst):
            hits.append(lst)
    assert hits, f"no code-list with a label ~ {needle!r}"
    return hits[0]


def _all_codelists(obj):
    out = []
    if isinstance(obj, dict):
        for v in obj.values():
            out += _all_codelists(v)
    elif isinstance(obj, list):
        if obj and all(isinstance(x, dict) and "code" in x for x in obj):
            out.append(obj)
        for x in obj:
            out += _all_codelists(x)
    return out


CHECKS = []


def check(desc, got, want):
    ok = got == want
    CHECKS.append(ok)
    print(f"  {'ok ' if ok else 'FAIL'}  {desc}: got {got!r}, want {want!r}")


def main():
    clin = load("clinical.yaml")
    demo = load("demographics.yaml")

    # --- CODE-ALIGN reversals (codes visible in linvars.md) ---
    check("BMIGR1N Missing fallthrough = 5", fallthrough(codelist_with(clin, "Obese")), 5)
    for nm in ("hrr_index", "brca_index"):
        d = named(clin, nm, "groups")
        check(f"{nm} Unknown fallthrough = 4", fallthrough(d["groups"]) if d else None, 4)

    # --- demographics-tab fallbacks that stay 99 (CODE-ALIGN) ---
    check("AGEGR1N fallthrough = 99", fallthrough(codelist_with(demo, "0-18")), 99)
    check("REGION1N fallthrough = 99", fallthrough(codelist_with(demo, "other region")), 99)
    check("RACEN fallthrough = 99", fallthrough(codelist_with(demo, "other race")), 99)
    check("ETHN fallthrough = 99", fallthrough(codelist_with(demo, "not hispanic")), 99)
    check("PRACTICN fallthrough = 99", fallthrough(codelist_with(demo, "community only")), 99)

    # --- left distinct by design ---
    check("STAGEN CHECK fallthrough = 99 (QC surfacer)", fallthrough(codelist_with(clin, "check")), 99)
    region = codelist_with(demo, "other region")
    check("REGION1N Missing (state null) = 6",
          [it["code"] for it in region if it.get("when") == "state_is_null"], [6])
    ecog = next(iter(dicts_with(clin, "missing_code")), {})
    check("ECOGN Unknown = 6", (ecog.get("value_codes") or {}).get("Unknown"), 6)
    check("ECOGN Missing = 7", ecog.get("missing_code"), 7)

    # --- Package-1 config edits (guard against accidental reversal) ---
    psa = named(clin, "psa_index", "pick")
    check("PSA_INDEX pick = earliest", (psa or {}).get("pick"), "earliest")
    adr = named(clin, "adrenal_met", "match")
    check("adrenal_met match = adrenal", (adr or {}).get("match"), "adrenal")
    stage = next((d for d in dicts_with(clin, "groups")
                  if any(g.get("label") == "I" for g in d["groups"])), {"groups": []})
    check("stage map has a 0 group", any(g.get("code") == 0 for g in stage["groups"]), True)
    hrr = named(clin, "hrr_index", "groups") or {"groups": []}
    neg = next((g for g in hrr["groups"] if g.get("code") == 2), {})
    check("biomarker Negative includes 'Mutation Negative'",
          "Mutation Negative" in (neg.get("from_equals_ci") or []), True)

    n, passed = len(CHECKS), sum(CHECKS)
    print(f"\n{passed}/{n} passed")
    sys.exit(0 if passed == n else 1)


if __name__ == "__main__":
    main()
