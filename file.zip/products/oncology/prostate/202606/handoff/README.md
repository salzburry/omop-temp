# RWP → RWDE Handoff (plain version)

**What it is:** the RWB Excel spec with each implementation gap identified (and resolved where available) — the functional contract **RWP works from
to maintain the product YAML**, and that **RWDE reads when a shared-engine capability or technical change
is needed**. No prostate or Flatiron knowledge required to read it.

**Why it exists:** RWP translates the RWB spec, profiles the data, resolves the functional details, and
maintains `config/` + `variables/` + `codelists/`. The unspoken answers RWP used to just *know* — which
column, what "missing" means, whether a boundary is inclusive — are written down here so nothing is inferred.

## The format — one table, one row per derivation (related outputs grouped)

| Column | What goes in it |
|---|---|
| **Output** | the ADS name(s): published / physical — e.g. `AGEGR1 (agegrl)` |
| **Means** | one plain-English line |
| **From** | source `table.column` |
| **Rule + filled gaps** | the calculation, **plus** what to do when blank, inclusive/exclusive, and the codes |
| **Status** | `✅` · `⛔ decision:<NAME>` · `🔍 needs data check` |

**Status legend:**
- **✅ Ready for implementation** — requirement + data checks complete; RWP finalizes the YAML, RWDE implements any shared-engine change.
- **⛔ decision:<NAME>** — a human (BIO/RWP) must decide something first.
- **🔍 needs data check** — someone must look at the real `2026m06` data (run `data_profiler.R`) to
  confirm the values/blanks before it's final.

## Conventions & open policy

- **Categorical missing/unknown → code `99`** (`CODE-ALIGN`): applies to the **demos-tab** fallthroughs **only** —
  `AGEGR1N`, `REGION1N` (fallthrough), `RACEN`, `ETHN`, `PRACTICN` — whose RWB "Values" columns were genuinely hidden
  (`demos.md` notes sheet cols C–D were not photographed), so these numeric codes are config-inferred and
  **flagged for RWB confirmation**. **Corrected (previously wrongly forced to 99):** the linvars-tab codes ARE
  visible in the spec — `BMIGR1N` Missing = **5**, `HRR_INDEXN` / `BRCA_INDEXN` Unknown/Not documented = **4**
  (`linvars.md` rows 62 / 71 / 75); the engine now uses those, not 99. Left distinct: `REGION1N` null-state
  `Missing = 6`, `ECOGN` `Unknown = 6` / `Missing = 7`, `STAGEN` `CHECK = 99` (QC). Continuous missing stays
  `null`. Until RWB confirms the remaining demos-tab codes, treat those `99`s as provisional — **affected rows
  cannot be marked ✅ until CODE-ALIGN is closed.**
- **The YAML is the authoritative record of the current executable implementation** (numeric codes, thresholds, source stems); the approved RWB spec + closed decisions govern the intended requirement (some current YAML values are provisional — e.g. the study window). The handoff
  records meaning, decisions, missing behavior and examples; where it cites a code it's for context, not a
  second source of truth.

## Replicating to another tumor or dataset

Copy the table, fill one row per derivation. **The columns never change — only the rows do.** No code,
no framework, no second YAML. That's the whole point: a plain table travels; a framework doesn't.

## Files

- `dataprep.md · studypop.md · demographics.md · clinical.md · treatment.md · outcomes.md` — the six tabs, one table each.
- `DECISIONS.md` — every open ⛔ decision in one index (what a human must answer).
- `ENGINE_GAPS.md` — every config/engine deviation from the RWB spec, with acceptance cases + the bounded implementation packages.
- `WORKFLOW.md` — how a requirement travels RWB → RWP → RWDE (with the file at each step).
- `clinical_metastatic_bone.md` — one worked example (an independent flag + date pair).
- `profile_facts.py` — the deterministic profile-facts **reporter** (below).

## Profile facts (deterministic reporter — for later)

This does **one** thing, read-only: turn a profiler TSV into a facts report RWP reads. **No AI. It does
NOT edit the handoff, flip any `🔍`/`⛔`, or approve a source** — RWP reviews the facts and updates the
YAML/status by hand.

1. **RWP or RWDE** runs `data_profiler.R` over **all configured sources in one run** → a full-scope
   `profile_<cut>.tsv` (see `WORKFLOW.md`: `DC_SAMPLE_N=2000` sampled is fine for **screening**; targeted
   exact runs are for **final** value/grain/tie checks). *(RWP owns the scope + conclusions, whoever runs the job.)*
2. Drop it in `profile/`.
3. Run `python3 handoff/profile_facts.py . profile/profile_<cut>.tsv` → writes `profile/PROFILE_FACTS_<cut>.md`:
   per-source metrics + mechanical notes (a configured table stem not present in the profile, with a
   same-prefix hint), stamped `EXACT_METRICS` or `SAMPLED_METRICS` (a sampled profile can only screen, not verify).
   *(Categorical value-set confirmation is a targeted RWP query, not reporter behavior.)*

**What it can't do** (needs targeted RWP queries, not this tool): composite grain, duplicates, join
coverage, same-day ties, window coverage. And the `⛔` decisions are never touched — those need a human.

*The executable rules live only in `config/` + `variables/` + `codelists/` — **RWP maintains those**
for versioning. This handoff is what RWP works from (and what RWDE reads for shared-engine gaps) —
it is not itself run by the engine.*
