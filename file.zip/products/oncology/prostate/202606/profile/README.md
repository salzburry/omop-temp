# profile/ — live profiling evidence

Drop the real profiler output here: a **full-scope** `profile_<cut>.tsv` from `data_profiler.R` covering
**all configured sources in one run** (see `../handoff/WORKFLOW.md`). A **`DC_SAMPLE_N=2000` sampled** run is
fine for screening common values/schema; **targeted exact** runs (unique `DC_OUT_DIR`) are for final
value-set / grain / tie / window checks. Don't feed a one-table exact TSV to the reporter — it will read as
partial scope.

Then generate the facts report:

```bash
python3 ../handoff/profile_facts.py .. profile_<cut>.tsv          # writes PROFILE_FACTS_<cut>.md here
python3 ../handoff/profile_facts.py .. profile_<cut>.tsv --strict # fail if any configured stem is missing
```

**State of the evidence:**
- A **2,000-row OCR reconstruction** exists at `../ref/profile_2026m06_OCR.txt` — screening only. It is a
  photographed-and-retyped sample (may contain OCR errors) and is **NOT** a clean profiler TSV, so it
  cannot feed `profile_facts.py`. Use it for schema + common-value screening, not to clear final checks.
- **No clean full-scope TSV / generated `PROFILE_FACTS` is attached yet**, and no targeted exact evidence.
  Until those exist, every `🔍` row in the handoff is unverified.
