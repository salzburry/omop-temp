# Prostate 202606 — Databricks dev-smoke runbook

The point of this run: move prostate from **asserted** (unit tests + R-parity pass; never executed on a
cluster) to **verified** (a real ADS builds end-to-end on real Flatiron/Panoramic tables). Static review
won't get there — this run is what does. Needs a Databricks workspace with the Panoramic source schema.

Identity for this product (from `config/data_product.yaml` + `../../../registry.yaml`):

| | |
|---|---|
| tumor_slug | `prostate` · registry code `mcrpc` · family `oncology` |
| spec_version | `202606` (CalVer) · data cut = `--var refresh=…` |
| output ADS | `<output_schema>.rwdp_pros_pano_202606` |
| cohorts (7) | overall_mhspc · overall_mcrpc · lot1_mhspc · lot1_mcrpc · lot2_mcrpc · lot3_mcrpc · lot4_mcrpc |

---

## 0. Validate source naming FIRST (cheapest failure to hit)

The config runs on **EDM-normalized lowercase logical names** and resolves each source to
`{source_schema}.<stem>_<refresh>`. If Panoramic ships different physical names, the **preflight** fails
fast (a schema gate, by design) — better to know before a cluster spins up. Run these in a SQL editor:

```sql
-- a) do the declared source stems exist for this refresh?
SHOW TABLES IN <source_schema> LIKE '*prostate*';   -- expect t_enh_prostate, _lot, _biomarker, _psa, _som, _prog_scled, _bsln_ecog, _drg_epsode, _orals, _alpbta_emt, _provenge, _psmapet
SHOW TABLES IN <source_schema> LIKE 't_lab*';       -- labs are t_lab (NOT t_enh_prostate_lab) per the June inventory
SHOW TABLES IN <source_schema> LIKE 't_mortality*';

-- b) the verify-vs-scan VALUE strings the derivations branch on:
SELECT DISTINCT linesetting   FROM <source_schema>.t_enh_prostate_lot_<refresh>;     -- expect mHSPC / mCRPC spelling the config's line_setting + cohorts use
SELECT DISTINCT biomarkername FROM <source_schema>.t_enh_prostate_biomarker_<refresh>;-- HRR / BRCA names + status strings (clinical.yaml match_any)
SELECT DISTINCT testbasename  FROM <source_schema>.t_lab_<refresh>;                   -- the 10-lab panel names (June table is t_lab)
-- c) columns the engine expects as logical/EDM names:
DESCRIBE <source_schema>.t_enh_prostate_<refresh>;          -- metastaticdiagnosisdate, crpcdate, hspcdate (advanceddiagnosisdate is engine-DERIVED, not a physical column)
DESCRIBE <source_schema>.t_enh_prostate_psa_<refresh>;      -- PSA ScoreSerial column(s)
```

If physical names differ → add a `formats.Panoramic:` overlay (sources + column renames) to the config and
set `run.data_format: Panoramic`; the engine still only ever sees the logical names. **Do not guess** — set
the overlay from what these queries actually return.

## 1. Deploy + run the dev smoke

```bash
databricks bundle deploy -t dev

databricks bundle run rwdp_build -t dev \
  --var tumor_slug=prostate --var spec_version=202606 \
  --var refresh=<snapshot> \
  --var source_schema=<panoramic_or_edm_source_schema> \
  --var output_schema=<dev_output_schema> \
  --var artifact_root=/Volumes/<catalog>/<schema>/<volume>/rwdp/artifacts
```

The bundle **provisions its own job cluster** (DBR 15.4 LTS, SINGLE_USER, 2 workers) — you don't need a
running cluster, only permission to create the configured one.

Dev is lenient on golden-compare (skips without `reference_table`) and deliverables, **but `artifact_root`
must be a real, writable location** — a placeholder only *warns up front*, then the pre-publish manifest/QC
write (`dbutils.fs.put`, `run_rwdp.py`) **raises**, so a bad `artifact_root` lets the expensive build run and
then fails before publish. Use a **dedicated disposable dev output schema**: the runner creates
staging/versioned tables and **swaps the public view even in dev**, and an existing *table* (not view) at the
public ADS name fails `_assert_swappable`. The job prints the resolved source FQNs, cohorts, and output FQN up
front — eyeball those before it builds.

## 2. Post-build ADS sanity — operator ACCEPTANCE checks

*(These confirm the run **structurally** completed — cohorts present, both settings fired, provenance
stamped. They are NOT proof the derivations are scientifically correct; that needs Packages 1–4 done + QC +
golden compare. Do not interpret the ADS scientifically off the first smoke.)*

```sql
-- 7 cohorts present, with rows
SELECT cohortn, cohort, count(*) FROM <output_schema>.rwdp_pros_pano_202606 GROUP BY cohortn, cohort ORDER BY cohortn;
-- expect cohortn 1..7; non-trivial counts for overall_mhspc (1) + overall_mcrpc (2)

-- BOTH settings' treated/untreated labels appear (the dual-setting split actually fired)
SELECT DISTINCT cohortu, cohortun FROM <output_schema>.rwdp_pros_pano_202606 ORDER BY cohortun;
-- expect: Untreated mCRPC=1, Treated mCRPC=2, Untreated mHSPC=3, Treated mHSPC=4

-- provenance stamps are correct (the audit contract)
SELECT DISTINCT data_product_id, spec_version, data_refresh FROM <output_schema>.rwdp_pros_pano_202606;
-- expect exactly: prostate_mcrpc_rwdp | 202606 | <snapshot>   (spec_version must NOT carry the snapshot)

-- spot-check the signature 202606 variables actually populate (not all-null)
SELECT
  count(hrr_index) hrr, count(brca_index) brca, count(tsst) tsst, count(eligpfs) eligpfs,
  count(os) os, count(pfs) pfs, count(pfsfl) pfsfl   -- rwPFS is emitted as pfs / pfsfl / pfsdt (not "rwpfs")
FROM <output_schema>.rwdp_pros_pano_202606;
```

Red flags: only mCRPC `cohortu` labels (the mHSPC path didn't fire); `spec_version` = `202606.<snap>`
(the two version axes duplicated); a signature column 100% null (a source/derivation gap).

## 3. Decisions this run forces (can't be settled from the repo)

Capture answers as you inspect §0/§2 — these gate the *governed* release, not the dev smoke:

- **LineSetting** exact spelling (mHSPC vs MHSPC vs Metastatic hormone-sensitive…) → may need a config value tweak.
- **HRR/BRCA** `biomarkername` + status strings → confirm `clinical.yaml` `match_any` lists match the feed.
- **Conmed flags** (`conmed_*`) — do they materialize (depend on `drug_episode.drugname`)? Required or conditional? (See `DECISIONS.md` CONMED-INCLUDE.)

*(No longer open — now specified requirements in `ENGINE_GAPS.md`, not smoke-time questions: **PSMA** is an RWB-required output; **PSADIAG_CRPC** is a required PSA-table derivation; **setting-suffixed LOT** is 2 mHSPC / 4 mCRPC. The smoke exercises the CURRENT implementation, which does not yet emit these.)*

## 4. Then: governed prod

Only after a clean dev smoke + a known-good **golden reference** ADS:

```bash
databricks bundle run rwdp_build -t prod \
  --var tumor_slug=prostate --var spec_version=202606 --var refresh=<snap> \
  --var source_schema=<src> --var output_schema=<out> \
  --var git_commit=$(git rev-parse HEAD) --var reference_table=<known-good ADS>
```

Prod is strict: `git_commit` + `reference_table` are required (or `--var allow_governed_waiver=true`), a
placeholder `artifact_root` HARD-fails, required deliverables (incl. the **enforced** TFL QC gate) block
publish on failure, and the released manifest must carry `published_at` + the release pointer +
`tfl_promotion.passed`. CODEOWNERS now routes every governed path to `@salzburry` (the sole owner); stand up
real GitHub teams + branch protection before relying on it for separation-of-duties review-gating.

## 5. (Optional) Cross-check with the R engine

The R engine builds the **same ADS from the same config** — a useful independent check for the
R-proficient team. It is **validation, not a governed run** (no QC/golden/release lifecycle; it writes
directly), so point it at a **separate `_r` schema**, never `<output_schema>`. On the same cluster (or
Domino→Databricks via sparklyr), from the repo root:

```bash
Rscript platform/engine-r/run_rwdp.R --allow_direct_write=true \
  --config_path=products/oncology/prostate/202606/config/data_product.yaml \
  --refresh=<snapshot> --source_schema=<src> --output_schema=<out>_r
```

Then **golden-compare** R vs the Python ADS by re-running the dev build with the R table as the
reference (the same gate §2 would use against a known-good ADS):

```bash
databricks bundle run rwdp_build -t dev --var tumor_slug=prostate --var spec_version=202606 \
  --var refresh=<snapshot> --var source_schema=<src> --var output_schema=<out> \
  --var reference_table=<out>_r.rwdp_pros_pano_202606
```

`--allow_direct_write=true` is required (fail-closed); full Domino→Databricks connection detail is in
`../../../../platform/engine-r/README.md`.
