# Prostate v1 — 202603 (mCRPC-only)

The **original** mCRPC-only contract (`coh_list = c("overall","lot1","lot2","lot3")`), kept as a
buildable, auditable spec version alongside v2 (`../202606/`). **Superseded by 202606** (the 7-cohort
mHSPC + mCRPC expansion) — see `../CHANGELOG.md` and `../../../registry.yaml` lineage.

- **Cohorts:** Overall + L1/L2/L3 mCRPC (COHORTN 1–4), anchored on `advanceddiagnosisdate`.
- **Public ADS:** `rwdp_pros_pano_202603`.
- **Build it:** `--var tumor_slug=prostate --var spec_version=202603` (independent of v2).

> **Reconstruction note.** The cohorts / index / output AND the **variable packs** are now the authentic
> v1 scope: the 202606 additions (HRR/BRCA, labs, PSA timepoints, metastatic sites, year/duration, BSA,
> rwPFS/TSST, conmed, generic prior-treatment, setting-suffixed LOT) have been **pruned out** — **76**
> emitted variables vs **153** in 202606 (`diff` the `variables/` folders to see the contract delta).
> Reconstructed from the 202606 pack + the original R script `../prostate_rdap.py` + CHANGELOG; like
> 202606 it still needs the real-data smoke + verify-vs-scan before a governed release.
