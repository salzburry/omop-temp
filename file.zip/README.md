# RWD Data Products — GSK Oncology

Real-world oncology **analytic data products (RWDPs)** built on a **locked PySpark engine + per-product
YAML config**. One config-driven engine turns a tumor's `config/` + `variables/` + `codelists/` into a
patient-level analytic dataset (ADS), its data dictionary, and its dashboard / TFL contracts — runnable on
Databricks, governed by a refresh-manifest ledger and a QC + golden-compare publish gate. *Code is locked;
what an analyst tunes is reviewed YAML.*

## Start here

The runnable, governed system is **`platform/`** (the shared engine) + **`products/`** (the governed
product configs).

| To… | Read |
|---|---|
| Understand the repo + the **target production structure** | [`docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md`](./docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md) |
| Configure a new tumor (the add-a-tumor recipe) | [`platform/README.md`](<platform/README.md>) |
| Roadmap / way-forward (phases, onboarding — *historical plan*) | [`products/ROADMAP.md`](<products/ROADMAP.md>) |
| Run / release a refresh (lifecycle, QC, publish, ledger) | [`products/OPERATIONS.md`](<products/OPERATIONS.md>) |
| The **reference product** — prostate 202606 (mHSPC + mCRPC) | [`products/oncology/prostate/README.md`](<products/oncology/prostate/README.md>) |

## Architecture — locked engine, config-driven

```
rwddataproduct/
├── platform/                     the locked, tumor-agnostic engine (shared by every product)
│   ├── VERSION                   the engine SemVer a product pins
│   ├── engine/                   PySpark stages (sources → … → assemble) + validate/QC/golden/release/audit
│   ├── engine-r/                 a side-by-side R (sparklyr/dbplyr) engine on the SAME YAML — byte-identical in CI
│   ├── databricks/run_rwdp.py    the one tumor-agnostic job entry point
│   └── tests/                    pure-Python suite (CI) + synthetic-Spark + R-parity + governance
├── products/
│   ├── registry.yaml             tumor registry + per-product spec-version lineage
│   ├── metadata/catalog.yaml     cross-tumor master variable catalog (completeness-enforced in CI)
│   ├── _reporting/               shared dashboard / dictionary / tfl contracts
│   ├── oncology/<tumor>/         prostate / oc / endometrial / dlbcl — config + variables + codelists
│   └── OPERATIONS.md · ROADMAP.md   lifecycle + build-framework docs
├── refreshes/                    one committed manifest per (family, product, spec_version, refresh) — the audit ledger
├── releases/                     immutable per-build evidence bundles
├── governance/                   ADR-001 · VERSIONING.md · JSON schemas (the operating contract)
└── databricks.yml                one Asset Bundle, parameterised by `tumor_slug`
```

- **Two version axes** — `spec_version` is the **contract** (CalVer `YYYYMM`, e.g. `202606`); `data_refresh`
  is the **data cut** (e.g. `2026q1`). Every ADS row + manifest is stamped with both.
- **Governed release** — preflight → source-QC → build → ADS-QC + golden-compare → deliverables → durable
  manifest → immutable versioned tables → sequential view swap (TFLs first, ADS last). A released manifest
  requires `published_at`, a release pointer, and `tfl_promotion.passed`.
- **Reproducible** — a refresh manifest pins the exact `git_commit`; checkout the tag, re-run the config.

Switch tumor by pointing the job at another `config/`; switch data cut via `--var refresh=…`. No code change.

## Portfolio

Status mirrors [`products/registry.yaml`](<products/registry.yaml>) (test-enforced).

| Family | Product | Source | Registry status |
|---|---|---|---|
| Prostate | **Prostate (mHSPC + mCRPC)** | Flatiron | **active** — reference product, spec `202606` |
| Gynecologic | Ovarian | Flatiron | scaffold |
| Gynecologic | Endometrial | Flatiron | scaffold |
| Lymphoma | DLBCL | COTA | scaffold |
| Lung | NSCLC · SCLC | Flatiron | planned |
| GI / rare solid | mCRC · GIST · HNSCC | Flatiron | planned |
| Myeloid | **MDS** | COTA | scaffold |
| Myeloid | CLL | COTA | planned |

The job is to migrate these existing R-coded products onto the one shared, config-driven engine — not to
rebuild them. Prostate is the most-built pack and the one the engine is validated against — several
RWB-required outputs and methodology decisions still remain (see its
[`202606/handoff/`](<products/oncology/prostate/202606/handoff/>)); the next step is a Databricks dev
smoke on real Flatiron/Panoramic tables.

> **The structure + how it got here:** [`docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md`](./docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md).
