"""Golden comparison: diff a newly-built ADS against the original (R) ADS for a known refresh.

The reference table (the original `rwdp_<tumor>_pano_<YYYYMM>`, e.g. rwdp_pros_pano_202603) is a
PARAMETER — supply it when the team has one. `compare_columns`/`summarise_diff`/`_dist_columns` are pure-Python (unit-tested);
`run_golden` executes the row/cohort/distribution/time-to-event (OS, PFS, PFS2) comparison on Spark
(cluster only). Returns a report dict; it never writes.
"""
from __future__ import annotations


def compare_columns(new_cols, ref_cols) -> dict:
    n, r = set(new_cols), set(ref_cols)
    return {"only_in_new": sorted(n - r), "only_in_ref": sorted(r - n), "shared": sorted(n & r)}


def summarise_diff(new_counts: dict, ref_counts: dict) -> dict:
    """Per-key count delta (e.g. per cohort): {key: {new, ref, delta, pct}}. Pure Python."""
    out = {}
    for k in sorted(set(new_counts) | set(ref_counts)):
        a, b = new_counts.get(k, 0), ref_counts.get(k, 0)
        out[k] = {"new": a, "ref": b, "delta": a - b,
                  "pct": (round(100 * (a - b) / b, 2) if b else None)}
    return out


def _dist_columns(new_cols, ref_cols) -> list:
    """Categorical columns to compare for distribution drift, present on BOTH tables. Treatment
    category prefers the cohort-indexed `lotcat` (what TFL/dashboard use) and falls back to `lot1cat`
    only for a legacy ADS built before it existed — mirroring tfl.generate(). Comparing lot1cat for an
    L2/L3/maintenance cohort would miss drift in its actual line category."""
    shared = set(new_cols) & set(ref_cols)
    cols = [c for c in ("stage", "ecog", "race", "regionl", "plat_sen_v1") if c in shared]
    lot = "lotcat" if "lotcat" in shared else ("lot1cat" if "lot1cat" in shared else None)
    if lot:
        cols.append(lot)
    return cols


def run_golden(spark, new_fqn: str, ref_fqn: str, cfg=None,
               cohort_col: str = "cohort", os_col: str = "os") -> dict:
    """Compare new vs reference ADS tables. Spark-side (cluster only)."""
    from pyspark.sql import functions as F

    new, ref = spark.table(new_fqn), spark.table(ref_fqn)
    report = {"new": new_fqn, "ref": ref_fqn}

    # column set diff
    report["columns"] = compare_columns(new.columns, ref.columns)

    # row counts
    report["n_rows"] = {"new": new.count(), "ref": ref.count()}

    # cohort counts (delta per cohort)
    if cohort_col in new.columns and cohort_col in ref.columns:
        nc = {r[cohort_col]: r["n"] for r in
              new.groupBy(cohort_col).agg(F.count(F.lit(1)).alias("n")).collect()}
        rc = {r[cohort_col]: r["n"] for r in
              ref.groupBy(cohort_col).agg(F.count(F.lit(1)).alias("n")).collect()}
        report["cohort_counts"] = summarise_diff(nc, rc)

    # categorical distributions on shared columns (lotcat / stage / ecog / race …)
    report["distributions"] = {}
    for c in _dist_columns(new.columns, ref.columns):
        nd = {str(r[c]): r["n"] for r in new.groupBy(c).agg(F.count(F.lit(1)).alias("n")).collect()}
        rd = {str(r[c]): r["n"] for r in ref.groupBy(c).agg(F.count(F.lit(1)).alias("n")).collect()}
        report["distributions"][c] = summarise_diff(nd, rd)

    # Numeric time-to-event summaries (count / mean / median / quartiles), both sides — one per
    # endpoint present on BOTH tables: OS always, PFS/PFS2 for OC/EC. Stored as <col>_summary.
    def summ(df, col):
        q = df.approxQuantile(col, [0.25, 0.5, 0.75], 0.01) if df.count() else [None] * 3
        row = df.select(F.count(col).alias("n"), F.avg(col).alias("mean")).collect()[0]
        return {"n": row["n"], "mean": row["mean"], "q25": q[0], "median": q[1], "q75": q[2]}
    for col in dict.fromkeys([os_col, "pfs", "pfs2"]):       # os first; dedup, preserve order
        if col in new.columns and col in ref.columns:
            report[f"{col}_summary"] = {"new": summ(new, col), "ref": summ(ref, col)}

    return report


# --- golden gate: turn a run_golden() summary into a pass/fail decision (pure Python) ----------
# A reference ADS is OPTIONAL; when none is supplied the gate SKIPS (passes). When one is supplied,
# gross drift vs the reference (original R ADS, or the prior refresh) blocks publish — mirroring the
# QC gate. Thresholds are tunable per tumor via a `golden.thresholds` config block.
DEFAULT_GOLDEN_THRESHOLDS = {
    "max_row_delta_pct": 10.0,           # |new-ref| / |ref| total rows
    "max_cohort_delta_pct": 15.0,        # worst per-cohort row drift
    "max_os_median_delta_pct": 15.0,     # OS median drift (new vs ref)
    "max_pfs_median_delta_pct": 15.0,    # PFS median drift (OC/EC)
    "max_pfs2_median_delta_pct": 15.0,   # PFS2 median drift (OC/EC)
    "max_distribution_delta_pct": 25.0,  # worst per-category drift within a categorical distribution
    "min_distribution_ref_count": 30,    # ignore tiny reference categories (drift % is noise there)
    "allow_new_columns": True,           # extra columns in new are OK; columns DROPPED vs ref never are
}


def golden_thresholds(cfg) -> dict:
    """Framework defaults merged with an optional per-tumor `golden.thresholds` config block."""
    t = dict(DEFAULT_GOLDEN_THRESHOLDS)
    if cfg is not None:
        t.update((cfg.raw.get("golden") or {}).get("thresholds", {}))
    return t


def _abs_pct(new, ref):
    """|new - ref| / |ref| as a percent, or None when ref is missing/zero (can't compute drift)."""
    if new is None or ref in (None, 0):
        return None
    return round(abs(new - ref) / abs(ref) * 100, 2)


def golden_gate(summary: dict | None, thresholds: dict | None = None) -> dict:
    """Gate a run_golden() summary against drift thresholds. Returns {passed, failures[, skipped]}.

    `summary` is the dict run_golden() returns (NOT the {reference, summary} wrapper). Pure data.
    """
    if not summary:
        return {"passed": True, "failures": [], "skipped": "no reference ADS"}
    t = {**DEFAULT_GOLDEN_THRESHOLDS, **(thresholds or {})}
    failures = []

    nr = summary.get("n_rows") or {}
    d = _abs_pct(nr.get("new"), nr.get("ref"))
    if d is not None and d > t["max_row_delta_pct"]:
        failures.append(f"row-count drift {d}% > {t['max_row_delta_pct']}%")

    for coh, c in (summary.get("cohort_counts") or {}).items():
        p = c.get("pct")
        if p is not None and abs(p) > t["max_cohort_delta_pct"]:
            failures.append(f"cohort '{coh}' drift {abs(p)}% > {t['max_cohort_delta_pct']}%")

    # categorical distribution drift (lot1cat / stage / ecog / race / regionl) — worst per-category,
    # ignoring tiny reference categories where a % delta is just noise.
    for col, dist in (summary.get("distributions") or {}).items():
        for val, c in (dist or {}).items():
            p = c.get("pct")
            if (c.get("ref") or 0) >= t["min_distribution_ref_count"] and p is not None \
                    and abs(p) > t["max_distribution_delta_pct"]:
                failures.append(
                    f"{col}='{val}' distribution drift {abs(p)}% > {t['max_distribution_delta_pct']}%")

    # time-to-event median drift — OS always; PFS/PFS2 when the summary is present (OC/EC).
    for col in ("os", "pfs", "pfs2"):
        s = summary.get(f"{col}_summary") or {}
        d = _abs_pct((s.get("new") or {}).get("median"), (s.get("ref") or {}).get("median"))
        thr = t.get(f"max_{col}_median_delta_pct", t["max_os_median_delta_pct"])
        if d is not None and d > thr:
            failures.append(f"{col.upper()} median drift {d}% > {thr}%")

    cols = summary.get("columns") or {}
    if cols.get("only_in_ref"):
        failures.append(f"columns missing vs reference: {cols['only_in_ref']}")
    if not t.get("allow_new_columns", True) and cols.get("only_in_new"):
        failures.append(f"unexpected new columns vs reference: {cols['only_in_new']}")

    return {"passed": not failures, "failures": failures}
