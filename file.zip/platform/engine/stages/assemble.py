"""Stage: assemble one cohort's ADS. Ports overall_ads_creation() (per cohort).

Left-joins index + demographics + clinical + treatment + outcomes on (patientid, index_date),
adds the cohort label columns from config (cohort / cohortn / cohortu / cohortun), and returns
one cohort's rows. build_ads.build() unions these across cohorts.
"""
from __future__ import annotations


def build(idx, dem, clin, trt, out, cfg, cohort, treated):
    from pyspark.sql import functions as F

    keys = ["patientid", "index_date"]
    ads = (idx
           .join(dem, keys, "left")
           .join(clin, keys, "left")
           .join(trt, keys, "left")
           .join(out, keys, "left"))

    # treat_flag comes from actual treatment evidence (patients with >=1 LOT row), derived
    # once in build_ads — NOT from trt, which carries every indexed patient (incl. untreated).
    ads = ads.join(treated, "patientid", "left")

    ts = cfg.treatment_status
    # COHORTU/COHORTUN: treated-vs-untreated label + code. A dual-setting product sets
    # treatment_status.by_setting.<setting> (keyed by the cohort's lower-cased line_setting) so each
    # setting gets its own labels/codes (Untreated mCRPC=1 / Treated mCRPC=2 / Untreated mHSPC=3 /
    # Treated mHSPC=4); a single-setting tumor uses the flat treated_label/untreated_label (codes 1/2).
    by = (ts.get("by_setting") or {}) if isinstance(ts, dict) else {}
    sts = by.get(str(cohort.get("line_setting", "")).lower(), ts)
    tlabel, ulabel = sts.get("treated_label"), sts.get("untreated_label")
    tcode, ucode = sts.get("treated_code", 1), sts.get("untreated_code", 2)
    # Cohort-indexed line-of-therapy category: one lotcat/lotcatn = the category of the line THIS
    # cohort indexes on — lotN for a line cohort, lotNm for a maintenance cohort, line 1 for overall —
    # so TFLs/dashboard summarise the right line per cohort instead of always lot1cat.
    ln = cohort.get("lot_number")
    suffix = "m" if cohort.get("maintenance") else ""
    cat_col = f"lot{ln}{suffix}cat" if ln is not None else "lot1cat"
    catn_col = f"lot{ln}{suffix}catn" if ln is not None else "lot1catn"
    ads = (ads
           .withColumn("cohort", F.lit(cohort["label"]))
           .withColumn("cohortn", F.lit(cohort["cohortn"]))
           .withColumn("cohortu", F.when(F.col("treat_flag").isNotNull(),
                                         F.lit(tlabel)).otherwise(F.lit(ulabel)))
           .withColumn("cohortun", F.when(F.col("treat_flag").isNotNull(), F.lit(tcode))
                                    .otherwise(F.lit(ucode)))
           # QC/provenance: each row self-identifies its product + contract + cut. data_product_id is the
           # stable product id; spec_version (CalVer 202606) and data_refresh (2026q1) are two DISTINCT
           # axes (spec_version must NOT carry the refresh). Build-level provenance (engine_version /
           # git_commit / build_id) lives in the manifest, keyed by these stamps.
           .withColumn("data_product_id", F.lit(cfg.data_product_id))
           .withColumn("spec_version", F.lit(cfg.spec_version))
           .withColumn("data_refresh", F.lit(cfg.refresh)))
    if cat_col in ads.columns:                       # treatment emits this line's category column
        ads = ads.withColumn("lotcat", F.col(cat_col)).withColumn("lotcatn", F.col(catn_col))
    return ads.distinct()
