"""Stage: load source tables. Ports the block of `tbl(con, in_schema(...))` reads.

Loads ONLY the sources the tumor declares (cfg.sources), with columns lower-cased. Table names
are vendor-resolved via cfg.table(name), so the snapshot AND the vendor (Flatiron / COTA / …) are
config, not code. Robust to tumors that omit `enhanced` or use an N-column advanced-diagnosis rule.

When `source_union` is configured, each source is read from EVERY member schema, tagged with the
`discriminator` column, and unioned — the engine equivalent of the EC `union_func` (Flatiron EDM ∪
Dostarlimab registry, db = EDM/DOS).
"""
from __future__ import annotations


def _union_members(spark, cfg, name, union, F):
    """Read `name` from each union member schema, tag with the discriminator flag, and unionByName.

    `allowMissingColumns=True` so a registry table with a slightly different column set still unions
    (the engine then sees the superset). Mirrors EC's `edm %>% mutate(db='EDM') %>% union_all(dos…)`.
    """
    from functools import reduce
    disc = union.get("discriminator", "db")
    parts = [spark.table(cfg.table_in(name, m["schema"])).withColumn(disc, F.lit(m["flag"]))
             for m in union.get("members", [])]
    if not parts:
        raise ValueError(f"source_union for '{name}' has no members")
    return reduce(lambda a, b: a.unionByName(b, allowMissingColumns=True), parts)


def load(spark, cfg) -> dict:
    from pyspark.sql import functions as F

    union = cfg.source_union
    src = {}
    for name in cfg.sources:                      # declared sources only
        df = (_union_members(spark, cfg, name, union, F) if union
              else spark.table(cfg.table(name)))
        for col in df.columns:                    # lower-case all columns (R: rename_with(tolower))
            if col != col.lower():
                df = df.withColumnRenamed(col, col.lower())
        # Per-format column renames (e.g. Panoramic physical -> logical/EDM names) so the engine always
        # sees the logical names. Applied after lower-casing; absent columns are a no-op. Empty for EDM.
        for phys, logical in (cfg.source_renames.get(name) or {}).items():
            p, lo = phys.lower(), logical.lower()
            if p in df.columns and p != lo:
                df = df.withColumnRenamed(p, lo)
        src[name] = df

    # Materialize each index_dates model as a column on the configured INDEX SOURCE (default
    # 'enhanced'; heme sets advanced_diagnosis_date.source: diagnosis). Column name = the model key
    # with underscores removed, so `advanced_diagnosis_date` -> advanceddiagnosisdate (unchanged). A
    # dual-setting product adds e.g. hspc_diagnosis_date / crpc_diagnosis_date so each overall cohort
    # can index off ITS setting's diagnosis date. Materialized only where the rule's columns exist.
    isrc = cfg.index_source
    if isrc in src:
        for key, rule in (cfg.index_dates or {}).items():
            if not isinstance(rule, dict):
                continue
            of = [c.lower() for c in rule.get("of", [])]
            present = [c for c in of if c in src[isrc].columns]
            if not present:
                continue
            # max over the present inputs; greatest needs >=2 args, so a single present column IS the max.
            expr = (F.greatest(*[F.col(c) for c in present])
                    if rule.get("method", "max") == "max" and len(present) > 1
                    else F.col(present[0]))
            src[isrc] = src[isrc].withColumn(key.replace("_", ""), expr)
    return src
