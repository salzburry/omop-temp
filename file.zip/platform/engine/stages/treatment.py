"""Stage: treatment variables. Ports trt_var_creation().

The per-line category (lotcat / lotcatn) is compiled from codelists/treatment_categories.yaml
via engine.codelists.compile_case — first-match-wins, exactly like the R case_when. new_lot_n
comes from the shared lot stage. Line-count banding and prior-taxane params live in
variables/treatment.yaml.

Built per cohort against that cohort's index rows: `base` is one row per patient per cohort
(overall -> 1 index/patient; lotN -> the line-N index), so the per-line frames (one row per
patient after de-dup) are attached on patientid without leaking lines across cohort index rows.
"""
from __future__ import annotations

from ..codelists import compile_case
from . import lot as lot_stage


def _lot_bands_case(bands, col, key="label"):
    """CASE over lot_count_bands (eq/ge with a fallthrough). Builds lotngrl / lotngrln."""
    def q(s):
        return "'" + str(s).replace("'", "''") + "'"
    whens, default = [], None
    for b in bands:
        out = q(b[key]) if key == "label" else str(b[key])
        if b.get("when") == "fallthrough":
            default = out
            continue
        conds = []
        if "eq" in b:
            conds.append(f"{col} = {b['eq']}")
        if "ge" in b:
            conds.append(f"{col} >= {b['ge']}")
        if conds:
            whens.append(f"WHEN {' AND '.join(conds)} THEN {out}")
    tail = f" ELSE {default}" if default is not None else ""
    return "CASE " + " ".join(whens) + tail + " END"


def categorize_line(df, codelist, label_col="lotcat", code_col="lotcatn"):
    """Add lotcat/lotcatn columns to a per-line DataFrame using the compiled CASE."""
    from pyspark.sql import functions as F
    label_sql, code_sql = compile_case(codelist)
    return (df.withColumn(label_col, F.expr(label_sql))
              .withColumn(code_col, F.expr(code_sql)))


def line_cols(i, maint=False):
    """Per-line column names emitted by build() for line i — the SINGLE source of truth so consumers
    (engine/stages/outcomes.py line outcomes) reference the SAME names. Mirrored in engine-r/stages.R.

      name     lot{i}     linename
      start    lot{i}sd   line start (startdate)
      end      lot{i}ld   line end (enddate)
      lastdate lot{i}ed   line "last activity" = max drug-episode date (R `loted`); the time-to-event
                          outcomes (vis120/TTD/TTNT) key off THIS, not the enddate.

    `maint=True` returns the MAINTENANCE-line variants (lot{i}m / lot{i}msd / lot{i}mld / lot{i}med),
    emitted only for tumors with maintenance cohorts so a lot{i}m cohort's maintenance line is
    described by its own columns (the non-maintenance lot{i}* prefers the non-maintenance row).
    """
    s = "m" if maint else ""
    return {"name": f"lot{i}{s}", "start": f"lot{i}{s}sd",
            "end": f"lot{i}{s}ld", "lastdate": f"lot{i}{s}ed", "dur": f"lot{i}{s}dur",
            "cat": f"lot{i}{s}cat", "catn": f"lot{i}{s}catn"}


def emitted_line_columns(cfg):
    """Every per-line lot{i}* column the treatment stage emits for a tumor: the base set (name / start /
    end / last-activity / category / category-code) for lines 1..max_lines, plus the lot{i}m* maintenance
    variants when the tumor has maintenance cohorts. SINGLE source of truth shared by build()'s per-line
    loop, validate.emitted_variables, and the catalog `line_template` expansion (tests/test_catalog.py),
    so the ADS contract for these columns can't drift from what the engine emits."""
    maxl = int(cfg.pack("treatment").get("max_lines", 0))
    maint = any(c.get("maintenance") is not None for c in cfg.cohorts)
    cols = []
    for i in range(1, maxl + 1):
        cols += list(line_cols(i, False).values())
        if maint:
            cols += list(line_cols(i, True).values())
    return cols


def _line_frame(F, Window, rows, i, maint, mc, epi, codelist):
    """One deterministic per-line frame: pick a single line-i row (prefer non-maintenance then
    earliest start for the lot{i}* set; maintenance rows only for lot{i}m*), attach the last-activity
    date (lot{i}ed), and emit name/start/end/lastdate/cat/catn under the maint-aware names."""
    c = line_cols(i, maint)
    order = []
    if not maint and mc in rows.columns:
        order.append(F.col(mc).asc_nulls_last())          # 'False' < 'True' -> non-maintenance first
    order += [F.col("startdate").asc_nulls_last(), F.col("enddate").asc_nulls_last(),
              F.col("linename").asc_nulls_last()]
    pick = (rows.withColumn("_rn", F.row_number().over(Window.partitionBy("patientid").orderBy(*order)))
            .filter(F.col("_rn") == 1))
    if epi is not None and "linenumber" in pick.columns:
        # epi is already scoped to this cohort's setting (build() filters drug_episode before aggregating),
        # and lot_norm is single-setting too, so the join keys on (patientid, linenumber) — the same grain
        # the pre-B1 loted join used. Drop the LOT-native category ONLY when the episode aggregate supplies
        # its own (avoids an ambiguous column AND lets episode win); if epi carries no category — a pack
        # whose drug_episode lacks detaileddrugcategory — keep the LOT-native one instead of losing it.
        if "detaileddrugcategory" in epi.columns and "detaileddrugcategory" in pick.columns:
            pick = pick.drop("detaileddrugcategory")
        pick = pick.join(epi, ["patientid", "linenumber"], "left")
        lastdate = F.coalesce(F.col("_lastdate"), F.col("enddate"))
    else:
        lastdate = F.col("enddate")
    # detaileddrugcategory feeds the (unchanged) category classifier; source it from the episode join when
    # present, else a typed null so the compiled CASE stays valid for a tumor without drug-episode data.
    cat_col = (F.col("detaileddrugcategory") if "detaileddrugcategory" in pick.columns
               else F.lit(None).cast("string"))
    line = pick.select("patientid",
                       F.col("linename").alias(c["name"]),
                       F.col("startdate").alias(c["start"]),
                       F.col("enddate").alias(c["end"]),
                       lastdate.alias(c["lastdate"]),
                       # lot{i}dur (days) keys off lot{i}ed (last-activity), which falls back to the line
                       # enddate when the line has no drug-episode row — so dur is enddate-based, not null,
                       # in that case (deliberate, same fallback as lot{i}ed; the spec computes it from loted).
                       (F.datediff(lastdate, F.col("startdate")) + 1).alias(c["dur"]),
                       "linename", cat_col.alias("detaileddrugcategory"))
    line = categorize_line(line, codelist, label_col=c["cat"], code_col=c["catn"])
    return line.drop("linename", "detaileddrugcategory")


def _taxane_pred(likes):
    """SQL predicate: linename matches ANY taxane LIKE pattern (lower-cased). Mirrored in cases.R
    (taxane_pred) and proven byte-identical in tests/test_r_parity.py."""
    return " OR ".join(f"lower(linename) LIKE '{str(x).lower()}'" for x in likes)


def _prior_taxane(F, trt, idx, lot_norm, src, pt, cohort):
    """prior_tax_mcrpc (cohort-aware) [+ prior_tax_pre_mcrpc when a pre-mCRPC line source is set].

    prior_tax_mcrpc: for a line cohort N>=2, 'Yes' if any PRIOR mCRPC line (new_lot_n in 1..N-1) is a
    taxane, else 'No'; the 1L cohort is NA (no prior line); the overall cohort is 'No'. (R keys a
    case_when on coh_flag x new_lot_n, then fills NA->No for non-1L — this computes the filled value
    directly. new_lot_n < N already implies the line started on/before the line-N index.)
    prior_tax_pre_mcrpc (optional): 'Yes' if any line in the configured pre-mCRPC line source started
    on/before index and is a taxane, else 'No'. Skipped unless `pre_mcrpc_source` names a declared
    source (the R's enh_pros_pano_non_mcrpc) — so other tumors / an unmapped source simply omit it.
    """
    yes, no = pt.get("yes_label", "Yes"), pt.get("no_label", "No")
    pred = _taxane_pred(pt["drug_name_like_any"])
    ln = (cohort or {}).get("lot_number")
    if ln is None:                                       # overall cohort -> No
        trt = trt.withColumn("prior_tax_mcrpc", F.lit(no))
    elif ln == 1:                                        # 1L cohort -> not applicable (NA)
        trt = trt.withColumn("prior_tax_mcrpc", F.lit(None).cast("string"))
    else:                                                # N>=2: any prior line (1..N-1) a taxane?
        prior = (lot_norm.filter((F.col("new_lot_n") >= 1) & (F.col("new_lot_n") < ln))
                 .filter(F.expr(f"({pred})"))
                 .select("patientid").distinct().withColumn("_ptm", F.lit(1)))
        trt = (trt.join(prior, "patientid", "left")
               .withColumn("prior_tax_mcrpc",
                           F.when(F.col("_ptm").isNotNull(), F.lit(yes)).otherwise(F.lit(no)))
               .drop("_ptm"))

    pre_name = pt.get("pre_mcrpc_source")
    if pre_name and pre_name in src:                     # optional pre-mCRPC lines table
        pre = src[pre_name].select("patientid", "linename", "startdate")
        ppt = (idx.select("patientid", "index_date").join(pre, "patientid", "inner")
               .filter(F.col("startdate") <= F.col("index_date"))
               .filter(F.expr(f"({pred})"))
               .select("patientid").distinct().withColumn("_ptp", F.lit(1)))
        trt = (trt.join(ppt, "patientid", "left")
               .withColumn("prior_tax_pre_mcrpc",
                           F.when(F.col("_ptp").isNotNull(), F.lit(yes)).otherwise(F.lit(no)))
               .drop("_ptp"))
    return trt


def _prior_pred(fl):
    """SQL predicate for a generic prior-treatment flag: `like_any` (OR of linename LIKE) or `all_of`
    (AND of like_any groups — e.g. NHA AND ADT present in the same line). linename is lower-cased.
    Mirrored in engine-r/stages.R::prior_pred."""
    def likes(xs):
        return " OR ".join(f"lower(linename) LIKE '{str(x).lower()}'" for x in xs)
    if fl.get("all_of"):
        return " AND ".join(f"({likes(grp)})" for grp in fl["all_of"])
    return likes(fl["like_any"])


def _prior_treatments(F, trt, idx, src, cfg, ptcfg):
    """Generic prior-treatment Yes/No flags (prostate PRIOR_PLUVICTO / PARP / CHEMO / DOCETAXEL /
    ABIRATERONE / ARPI / NHA_ADT): for each flag, Yes if the patient has ANY line of therapy (ANY
    setting) that started on/before index and matches the flag's predicate, else No. Cohort-independent
    — 'prior to index' spans both the mHSPC and mCRPC settings, so the LOT model is read with NO setting
    filter. == engine-r/stages.R::treatment_prior_treatments.
    """
    from . import lot as lot_stage
    yes, no = ptcfg.get("yes_label", "Yes"), ptcfg.get("no_label", "No")
    lot_all = lot_stage.normalized(src, None,            # ALL settings (prior tx spans mHSPC + mCRPC)
                                   exclude_settings=cfg.lot_exclude_settings,
                                   line_number_col=cfg.lot_line_number_col,
                                   maintenance_column=cfg.lot_maintenance_column)
    pre = (idx.select("patientid", "index_date").join(lot_all, "patientid", "inner")
           .filter(F.col("startdate") <= F.col("index_date")))
    for fl in ptcfg["flags"]:
        hit = (pre.filter(F.expr(f"({_prior_pred(fl)})")).select("patientid", "index_date").distinct()
               .withColumn("_h", F.lit(1)))
        trt = (trt.join(hit, ["patientid", "index_date"], "left")
               .withColumn(fl["name"], F.when(F.col("_h").isNotNull(), F.lit(yes)).otherwise(F.lit(no)))
               .drop("_h"))
    return trt


def _conmed_exposures(F, trt, idx, src, ccfg):
    """Concomitant / supportive-care medication exposure Yes/No flags (prostate BP / CSF / STEROID):
    for each flag, Yes if the patient has ANY matching medication record (optionally within window_days
    of index; null/null = any time), else No — by drug-name LIKE patterns over a medication source. The
    whole block is skipped if the source or its name column is absent (config-level, so all cohorts in a
    product agree -> column-aligned). == engine-r/stages.R::treatment_conmed_exposures.
    """
    csrc = src.get(ccfg.get("source"))
    nc, dc = ccfg.get("name_column"), ccfg.get("date_column")
    if csrc is None or nc not in csrc.columns:
        return trt
    yes, no = ccfg.get("yes_label", "Yes"), ccfg.get("no_label", "No")
    lo, hi = (ccfg.get("window_days") or [None, None])
    pulled = idx.select("patientid", "index_date").join(csrc, "patientid", "inner")
    if dc in csrc.columns and lo is not None:
        pulled = pulled.filter(F.col(dc) >= F.expr(f"date_add(index_date, {lo})"))
    if dc in csrc.columns and hi is not None:
        pulled = pulled.filter(F.col(dc) <= F.expr(f"date_add(index_date, {hi})"))
    for fl in ccfg["flags"]:
        pred = " OR ".join(f"lower({nc}) LIKE '{str(p).lower()}'" for p in fl["like_any"])
        hit = (pulled.filter(F.expr(f"({pred})")).select("patientid", "index_date").distinct()
               .withColumn("_h", F.lit(1)))
        trt = (trt.join(hit, ["patientid", "index_date"], "left")
               .withColumn(fl["name"], F.when(F.col("_h").isNotNull(), F.lit(yes)).otherwise(F.lit(no)))
               .drop("_h"))
    return trt


def _setting_line_columns(F, src, idx, cfg, slc):
    """Per-SETTING line columns (LOT*_MHSPC / LOT*_MCRPC): for each configured setting, the chosen line
    attributes (sd=start / ed=end / name) per line number, suffixed _<setting-lowercased>, so EVERY
    cohort carries both settings' line detail regardless of its own setting. The LOT is renumbered within
    each setting (the same per-setting model the line cohorts use). == engine-r/stages.R::
    treatment_setting_line_columns.
    """
    from . import lot as lot_stage
    col_map = {"sd": "startdate", "ed": "enddate", "name": "linename"}
    attrs = [a for a in slc.get("attributes", ["sd", "name"]) if a in col_map]
    out = idx.select("patientid", "index_date")
    for setting in slc.get("settings", []):
        suffix = str(setting).lower()
        norm = lot_stage.normalized(src, setting, exclude_settings=cfg.lot_exclude_settings,
                                    line_number_col=cfg.lot_line_number_col,
                                    maintenance_column=cfg.lot_maintenance_column)
        for i in range(1, int(slc.get("lines", 2)) + 1):
            sels = [F.col("patientid")] + [F.col(col_map[a]).alias(f"lot{i}{a}_{suffix}") for a in attrs]
            li = norm.filter(F.col("new_lot_n") == i).select(*sels).dropDuplicates(["patientid"])
            out = out.join(li, "patientid", "left")
    return out


def build(src, idx, cfg, cohort=None):
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window

    trt_cfg = cfg.pack("treatment")
    codelist = cfg.codelist("treatment_categories")

    base = idx.select("patientid", "index_date")        # 1 row / patient within this cohort
    # Same LOT model as the index stage (line_number / exclude_settings) so the per-line lot<i>*
    # columns are numbered the same way the line cohorts are. No maintenance filter here (all lines).
    line_setting = (cohort or {}).get("line_setting", cfg.lot_line_setting)   # effective setting (or None)
    lot_norm = lot_stage.normalized(src, line_setting,
                                    exclude_settings=cfg.lot_exclude_settings,    # per-cohort setting
                                    line_number_col=cfg.lot_line_number_col,      # (dual-setting products)
                                    maintenance_column=cfg.lot_maintenance_column)

    # Per-line drug-episode aggregate (one row per patient+linenumber), feeding TWO things:
    #   * loted -> lot{i}ed : the latest drug-episode date within the line (max episodedate), which the
    #     outcomes time-to-event family keys off; and
    #   * detaileddrugcategory : the delivered data carries the drug category on the DrugEpisode table,
    #     NOT on LOT, so the per-line chemotherapy indicator (does ANY episode on this line have
    #     detaileddrugcategory='chemotherapy'?) is aggregated here and joined onto the line. That single
    #     synthesized column feeds lotcatn=9 "Other chemotherapy-containing" via the UNCHANGED codelist
    #     `category_equals: chemotherapy` (LOWER(detaileddrugcategory)='chemotherapy').
    # SETTING GRAIN (config-driven, not physical-column-driven): the aggregate must be scoped to the SAME
    # setting model as lot_norm, or an mHSPC line and an mCRPC line that share a linenumber would collide.
    # When a line setting is configured, FILTER drug_episode to it (mirroring lot_norm) and aggregate by
    # (patientid, linenumber); lot_norm is already single-setting, so the join keys on (patientid,
    # linenumber). When NO setting is configured (heme/COTA), aggregate + join on (patientid, linenumber)
    # as before — do NOT introduce linesetting just because the physical source happens to carry it (that
    # would fan out against a LOT frame that lacks it). OPTIONAL: without the drug_episode source (or its
    # columns) lot{i}ed falls back to the line enddate and the category is null, so a tumor/vendor lacking
    # drug-episode data still builds. Filtering before groupBy also shrinks the scan per cohort.
    de = src.get("drug_episode")
    epi = None
    if de is not None and {"linenumber", "episodedate"} <= set(de.columns):
        de_cols = set(de.columns)
        if line_setting is not None:
            # a setting IS configured -> the aggregate MUST be scoped to it. Fail loudly rather than
            # silently combine episodes across settings (preflight normally catches this, but stages can
            # be invoked directly, bypassing it).
            if "linesetting" not in de_cols:
                raise ValueError(
                    f"treatment stage: line setting {line_setting!r} is configured but drug_episode has "
                    "no 'linesetting' column to scope the per-line aggregate — this would combine episodes "
                    "across settings. Add linesetting to drug_episode, or clear the line setting.")
            de = de.filter(F.col("linesetting") == line_setting)   # scope to this cohort's setting
        aggs = [F.max("episodedate").alias("_lastdate")]
        if "detaileddrugcategory" in de_cols:
            # per-line chemotherapy indicator, matched EXACTLY as the codelist's category_equals does
            # (LOWER(detaileddrugcategory)='chemotherapy', no trim) so a flagged line is guaranteed to
            # satisfy category 9's compiled predicate once the synthesized value is joined on.
            aggs.append(F.max(F.when(F.lower(F.col("detaileddrugcategory")) == "chemotherapy",
                                     F.lit(1)).otherwise(F.lit(0))).alias("_has_chemo"))
        epi = de.groupBy("patientid", "linenumber").agg(*aggs)
        if "detaileddrugcategory" in de_cols:
            epi = (epi.withColumn("detaileddrugcategory",
                                  F.when(F.col("_has_chemo") == 1, F.lit("chemotherapy"))
                                   .otherwise(F.lit(None).cast("string")))
                   .drop("_has_chemo"))
        # When drug_episode has NO detaileddrugcategory, epi carries only _lastdate (no category column),
        # so _line_frame keeps any LOT-native category instead of nulling it — the episode aggregate is
        # authoritative for the category ONLY when it actually sources one.

    # max LOT count per patient (lotn) + banding (lotngrl/lotngrln from config lot_count_bands).
    w = Window.partitionBy("patientid")
    lotn = (base.join(lot_norm.select("patientid", "new_lot_n"), "patientid", "left")
                .withColumn("lotn", F.max("new_lot_n").over(w))
                .select("patientid", "index_date", "lotn").distinct())
    bands = trt_cfg.get("lot_count_bands")
    if bands:
        lotn = (lotn.withColumn("lotngrl", F.expr(_lot_bands_case(bands, "lotn", "label")))
                    .withColumn("lotngrln", F.expr(_lot_bands_case(bands, "lotn", "code"))))

    # Per-line columns lot1..lot{max_lines}. For the linenumber model (OC/EC) a single line N can
    # have BOTH a non-maintenance and a maintenance row. lot{i}* picks ONE DETERMINISTICALLY (prefer
    # non-maintenance, then earliest start) — backward-compatible and stable. For tumors WITH
    # maintenance cohorts we ALSO emit lot{i}m* describing the maintenance row, so a lot{i}m cohort
    # (which indexes off the maintenance line) is described by its own columns instead of the
    # non-maintenance line's. (For the prostate new_lot_n model there's one row/line and no
    # maintenance column, so this is the same single lot{i}* as before.)
    mc = cfg.lot_maintenance_column
    emit_maint = mc in lot_norm.columns and any(c.get("maintenance") is not None for c in cfg.cohorts)
    trt = base
    for i in range(1, trt_cfg["max_lines"] + 1):
        li = lot_norm.filter(F.col("new_lot_n") == i)
        trt = trt.join(_line_frame(F, Window, li, i, False, mc, epi, codelist), "patientid", "left")
        if emit_maint:
            li_m = li.filter(F.col(mc) == "True")
            trt = trt.join(_line_frame(F, Window, li_m, i, True, mc, epi, codelist), "patientid", "left")

    # prior taxane (docetaxel/cabazitaxel) flags — cohort-aware, prostate-specific (optional config).
    pt = trt_cfg.get("prior_taxane")
    if pt and cohort is not None:
        trt = _prior_taxane(F, trt, idx, lot_norm, src, pt, cohort)

    # Generic prior-treatment flags (PRIOR_*) — cohort-independent (any prior line, any setting). Optional.
    ptm = trt_cfg.get("prior_treatments")
    if ptm and ptm.get("flags"):
        trt = _prior_treatments(F, trt, idx, src, cfg, ptm)

    # Concomitant/supportive-med exposure flags (BP / CSF / STEROID) — cohort-independent. Optional.
    cm = trt_cfg.get("conmed_exposures")
    if cm and cm.get("flags"):
        trt = _conmed_exposures(F, trt, idx, src, cm)

    # Per-setting line columns (LOT*_MHSPC / LOT*_MCRPC) — cohort-independent (both settings). Optional.
    slc = trt_cfg.get("setting_line_columns")
    if slc and slc.get("settings"):
        trt = trt.join(_setting_line_columns(F, src, idx, cfg, slc), ["patientid", "index_date"], "left")

    return trt.join(lotn, ["patientid", "index_date"], "left")
