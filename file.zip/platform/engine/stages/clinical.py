"""Stage: clinical characteristics. Ports clin_char_master() and its sub-functions.

Implemented: baseline ECOG (clin_char_ecog_var); the follow-up-end / death-date anchors
(clin_char_fuend_dthdt_var) that OS depends on; enhanced vars — stage grouping plus the generic
value->group categoricals (grade/histology/TNM/…); closest-to-index biomarker & lab PANELS
(numeric lab bands use a try_cast numeric expression); vitals (BMI, + BSA when configured); and the prostate-specific
gleason/PSA/mCRPC pass-throughs. Every window, band, grouping and imputation rule comes from
variables/clinical.yaml so it is reviewable config, and each block is added only when its source
columns exist — a tumor that doesn't declare a block simply omits those columns.

NOTE on the death/follow-up port: the original R for this section carried author "Before/After"
and "seem to be wrong" comments and was mid-revision. This is a faithful port of the
straightforward interpretation (coarse-date imputation from config; cap follow-up at death;
snap a same-month death to month end alongside last_lotenddate). Confirm against the original
R ADS in the golden comparison before treating OS as final.
"""
from __future__ import annotations


def _q(s: str) -> str:
    return "'" + str(s).replace("'", "''") + "'"


def _num_bands_case(bands, col, key="label"):
    """CASE over numeric bands with a fallthrough (BMI groups; lab value bands).

    Per band, any of: min (>=), min_excl (>), max_excl (<), max (<=). Conditions are emitted in
    this fixed order so the R compiler (cases.R::num_bands_case) stays byte-identical. min_excl lets
    a band express a strict lower bound (e.g. a lab `value > 0` "Measured" status).
    """
    whens = []
    for b in bands:
        if b.get("when") == "fallthrough":
            continue
        out = _q(b[key]) if key == "label" else str(b[key])
        conds = []
        if "min" in b:
            conds.append(f"{col} >= {b['min']}")
        if "min_excl" in b:
            conds.append(f"{col} > {b['min_excl']}")
        if "max_excl" in b:
            conds.append(f"{col} < {b['max_excl']}")
        if "max" in b:
            conds.append(f"{col} <= {b['max']}")
        if conds:
            whens.append(f"WHEN {' AND '.join(conds)} THEN {out}")
    default = next((b for b in bands if b.get("when") == "fallthrough"), None)
    tail = f" ELSE {_q(default[key]) if key == 'label' else default[key]}" if default else ""
    return "CASE " + " ".join(whens) + tail + " END"


def _stage_case(groups, col, key="label"):
    """CASE mapping a raw group-stage value to the configured grouping (AJCC/FIGO/Ann Arbor),
    with from_prefixes (exact values), from_equals_ci, and a fallthrough (e.g. 'CHECK')."""
    whens = []
    for g in groups:
        if g.get("when") == "fallthrough":
            continue
        out = _q(g[key]) if key == "label" else str(g[key])
        conds = []
        if g.get("from_prefixes"):
            conds.append(f"{col} IN ({', '.join(_q(v) for v in g['from_prefixes'])})")
        if g.get("from_equals_ci"):
            conds.append(f"LOWER({col}) IN ({', '.join(_q(str(v).lower()) for v in g['from_equals_ci'])})")
        if conds:
            whens.append(f"WHEN ({' OR '.join(conds)}) THEN {out}")
    default = next((g for g in groups if g.get("when") == "fallthrough"), None)
    tail = f" ELSE {_q(default[key]) if key == 'label' else default[key]}" if default else ""
    return "CASE " + " ".join(whens) + tail + " END"


def _categorical_pick(F, Window, src_df, column, groups, name, date_column=None, pick="latest"):
    """One deterministic row per patient of `column`, mapped via _stage_case -> name / <name>n.

    Generalises the staging pick (stage IS the categorical named 'stage' on 'groupstage') so any
    value->group clinical characteristic (grade / histology / …) reuses the SAME parity-proven
    _stage_case compiler. Tie-break: by date_column (latest/earliest) when present, then the value.
    """
    order, sel = [], ["patientid", column]
    if date_column and date_column in src_df.columns:
        order.append(F.col(date_column).desc() if pick == "latest" else F.col(date_column).asc())
        sel.append(date_column)
    order.append(F.col(column).asc_nulls_last())                # deterministic tiebreak
    w = Window.partitionBy("patientid").orderBy(*order)
    return (src_df.select(*sel).withColumn("_rn", F.row_number().over(w)).filter(F.col("_rn") == 1)
            .withColumn(name, F.expr(_stage_case(groups, column, "label")))
            .withColumn(name + "n", F.expr(_stage_case(groups, column, "code")))
            .select("patientid", name, name + "n"))


def _band_value_expr(val_col, item, blk):
    """The numeric expression a `bands` panel item compares: try_cast(<value_column> AS <type>).

    Numeric lab bands must compare a NUMBER, never the raw string column (a dirty/non-numeric value
    would otherwise make `testresultcleaned <= 35` a string comparison). try_cast yields NULL for a
    non-numeric value, so it falls through to the configured Missing band. The cast type is config
    (item.value_cast | block.value_cast, default DOUBLE). Built identically in engine-r/stages.R so
    the num_bands_case input — and thus the compiled CASE — stays byte-identical across engines.
    """
    cast = (item.get("value_cast") or blk.get("value_cast") or "double")
    return f"try_cast({val_col} AS {cast.upper()})"


def _closest_panel(F, Window, src_df, blk, idx):
    """Closest-to-index PANEL: for each item, filter the long table to its row(s) (name_column ==
    match), keep records within window_days of index, pick the one closest to index (tie: earliest
    date), and map its value -> name / <name>n. Returns (patientid, index_date) + one column pair
    per item. Used for biomarker / lab panels; reuses the parity-proven _stage_case/_num_bands_case.

    Config block: { source, name_column, value_column, date_column, window_days: [lo, hi],
                    value_cast?, unit_column?, panel: [{name, match, groups | bands,
                    value_cast?, units?}] }. lo/hi may be null (open-ended). A numeric `bands` item
    compares try_cast(value_column AS value_cast|DOUBLE) (see _band_value_expr) so a dirty value
    can't string-compare. An optional unit_column + per-item `units` restrict that item to matching
    units (case-insensitive) — so e.g. a CA-125 in the wrong unit doesn't get banded.
    """
    name_col, val_col, date_col = blk["name_column"], blk["value_column"], blk["date_column"]
    lo, hi = (blk.get("window_days") or [None, None])
    unit_col = blk.get("unit_column")
    base = idx.select("patientid", "index_date")
    pulled = base.join(src_df, "patientid", "inner")
    if lo is not None:
        pulled = pulled.filter(F.col(date_col) >= F.expr(f"date_add(index_date, {lo})"))
    if hi is not None:
        pulled = pulled.filter(F.col(date_col) <= F.expr(f"date_add(index_date, {hi})"))
    pulled = pulled.withColumn("_gap", F.abs(F.datediff(F.col(date_col), F.col("index_date"))))
    out = base
    for item in blk["panel"]:
        name = item["name"]
        if item.get("bands"):                       # numeric value -> num_bands_case (e.g. CA-125)
            num_col = _band_value_expr(val_col, item, blk)
            label_sql = _num_bands_case(item["bands"], num_col, "label")
            code_sql = _num_bands_case(item["bands"], num_col, "code")
        else:                                        # categorical value -> stage_case
            label_sql = _stage_case(item["groups"], val_col, "label")
            code_sql = _stage_case(item["groups"], val_col, "code")
        names = item.get("match_any") or [item["match"]]   # match_any: a multi-name set (e.g. HRR gene panel)
        rows = pulled.filter(F.upper(F.col(name_col)).isin([str(n).upper() for n in names]))
        units = item.get("units")
        if unit_col and units:                      # restrict to the configured measurement units
            rows = rows.filter(F.lower(F.col(unit_col)).isin([str(u).lower() for u in units]))
        if item.get("aggregate") == "priority":
            # Priority AGGREGATION across ALL in-window records (ANY Positive -> Positive; else VUS; else
            # Unknown; else Negative), by the `priority` label order — NOT the single nearest record. Used
            # for HRR/BRCA, where multiple gene rows in the window must roll up to the worst-case status.
            prio = item.get("priority") or [g.get("label") for g in (item.get("groups") or [])]
            rank_sql = "CASE " + " ".join(
                f"WHEN ({label_sql}) = {_q(str(lab))} THEN {i}" for i, lab in enumerate(prio)
            ) + f" ELSE {len(prio)} END"
            order = [F.expr(rank_sql).asc(), F.col(date_col).asc()]    # best status (tie: earliest)
        else:
            order = [F.col("_gap").asc(), F.col(date_col).asc()]       # nearest to index (tie: earliest)
        w_item = Window.partitionBy("patientid", "index_date").orderBy(*order)
        nearest = (rows.withColumn("_rn", F.row_number().over(w_item)).filter(F.col("_rn") == 1)
                   .withColumn(name, F.expr(label_sql))
                   .withColumn(name + "n", F.expr(code_sql))
                   .select("patientid", "index_date", name, name + "n"))
        out = out.join(nearest, ["patientid", "index_date"], "left")
    return out


def _closest_values_panel(F, Window, src_df, blk, idx):
    """Closest-to-index raw-VALUE panel (prostate ClinChars lab values LABNEU/LABNEUV/LABNEUDT …): for
    each item, the record nearest index within window_days — ties broken by the item's `tiebreak`
    (lowest|highest value), then earliest date — emits <name> (Present/Missing flag, or the optional
    3-state Present/Unknown/Missing when `unknown_label` is set), <name>v (numeric
    value) and <name>dt (date). Unlike _closest_panel (which maps the value to a group) this carries the
    raw value + date. Config: { source, name_column, value_column, date_column, window_days, value_cast?,
    unit_column?, present_label?, missing_label?, panel: [{name, match, tiebreak?, units?}] }. The base
    <name> is the cataloged code; <name>v/<name>dt are its parallel value/date columns (like the -n cols).
    == engine-r/stages.R::clinical_closest_values_panel.
    """
    name_col, val_col, date_col = blk["name_column"], blk["value_column"], blk["date_column"]
    lo, hi = (blk.get("window_days") or [None, None])
    unit_col = blk.get("unit_column")
    cast = (blk.get("value_cast") or "double").upper()
    present, missing = blk.get("present_label", "Present"), blk.get("missing_label", "Missing")
    base = idx.select("patientid", "index_date")
    pulled = base.join(src_df, "patientid", "inner")
    if lo is not None:
        pulled = pulled.filter(F.col(date_col) >= F.expr(f"date_add(index_date, {lo})"))
    if hi is not None:
        pulled = pulled.filter(F.col(date_col) <= F.expr(f"date_add(index_date, {hi})"))
    pulled = (pulled.withColumn("_gap", F.abs(F.datediff(F.col(date_col), F.col("index_date"))))
              .withColumn("_v", F.expr(f"try_cast({val_col} AS {cast})")))
    unknown = blk.get("unknown_label")               # optional 3-state: Present / Unknown / Missing
    out = base
    for item in blk["panel"]:
        name = item["name"]
        named = pulled.filter(F.upper(F.col(name_col)) == str(item["match"]).upper())  # any matching test
        rows = named
        units = item.get("units")
        if unit_col and units:                       # restrict to the configured measurement units
            rows = rows.filter(F.lower(F.col(unit_col)).isin([str(u).lower() for u in units]))
        rows = rows.filter(F.col("_v").isNotNull())  # a real numeric result = a "Present" value
        vorder = (F.col("_v").desc() if item.get("tiebreak", "lowest") == "highest"
                  else F.col("_v").asc())            # same-day ties: lowest (default) or highest value
        w = Window.partitionBy("patientid", "index_date").orderBy(
            F.col("_gap").asc(), F.col(date_col).asc(), vorder)
        nearest = (rows.withColumn("_rn", F.row_number().over(w)).filter(F.col("_rn") == 1)
                   .select("patientid", "index_date", F.col("_v").alias(name + "v"),
                           F.col(date_col).alias(name + "dt"), F.lit(present).alias(name)))
        out = out.join(nearest, ["patientid", "index_date"], "left")
        if unknown:
            # 3-state: a matching test EXISTS in the window but yielded no usable value -> Unknown; no
            # matching test at all -> Missing. (2-state when unknown_label is unset: OC/EC byte-identical.)
            anyrec = named.select("patientid", "index_date").distinct().withColumn("_any", F.lit(1))
            out = (out.join(anyrec, ["patientid", "index_date"], "left")
                   .withColumn(name, F.coalesce(F.col(name),
                               F.when(F.col("_any").isNotNull(), F.lit(unknown)).otherwise(F.lit(missing))))
                   .drop("_any"))
        else:
            out = out.withColumn(name, F.coalesce(F.col(name), F.lit(missing)))   # no record -> Missing
    return out


def _psa_timepoints(F, Window, src_df, blk, idx):
    """Windowed PSA values relative to index + PSA-response endpoints (prostate 6.Outcomes). For each
    point, the PSA (value_column) whose date is within [index+lo, index+hi] — picked CLOSEST to index
    (pick: closest) or EARLIEST in the window (pick: earliest; same-day ties -> max value, per the spec)
    — is emitted as <name>. Response endpoints per `response`: psa50 = (point-baseline)/baseline <=
    threshold -> 'Y' (else 'N'); undetectable = point < threshold -> 'Y'. baseline is one of the points
    (PSA at index = PSABL). Config: { source, value_column, date_column, value_cast?, points: [{name,
    window_days:[lo,hi], pick}], response?: {baseline, psa50_threshold, undetectable_threshold, points:
    [{value, psa50, undetectable}]} }. == engine-r/stages.R::clinical_psa_timepoints.
    """
    val_col, date_col = blk["value_column"], blk["date_column"]
    cast = (blk.get("value_cast") or "double").upper()
    base = idx.select("patientid", "index_date")
    pulled = (base.join(src_df, "patientid", "inner")
              .withColumn("_v", F.expr(f"try_cast({val_col} AS {cast})")).filter(F.col("_v").isNotNull()))
    out = base
    for p in blk["points"]:
        lo, hi = p["window_days"]
        rows = pulled.filter((F.col(date_col) >= F.expr(f"date_add(index_date, {lo})")) &
                             (F.col(date_col) <= F.expr(f"date_add(index_date, {hi})")))
        if p.get("pick") == "earliest":
            order = [F.col(date_col).asc(), F.col("_v").desc()]    # earliest result; same-day -> max value
        else:                                                      # closest to index
            rows = rows.withColumn("_g", F.abs(F.datediff(F.col(date_col), F.col("index_date"))))
            order = [F.col("_g").asc(), F.col(date_col).asc()]
        w = Window.partitionBy("patientid", "index_date").orderBy(*order)
        near = (rows.withColumn("_rn", F.row_number().over(w)).filter(F.col("_rn") == 1)
                .select("patientid", "index_date", F.col("_v").alias(p["name"])))
        out = out.join(near, ["patientid", "index_date"], "left")
    resp = blk.get("response")
    if resp:
        bl = resp["baseline"]
        p50, pun = resp.get("psa50_threshold", -0.5), resp.get("undetectable_threshold", 0.2)
        for pt in resp.get("points", []):
            v = pt["value"]
            out = out.withColumn(pt["psa50"], F.expr(   # NULL = not evaluable (no baseline, zero baseline,
                f"CASE WHEN {bl} IS NULL OR {bl} = 0 OR {v} IS NULL THEN NULL "   # or no follow-up value)
                f"WHEN ({v} - {bl})/{bl} <= {p50} THEN 'Y' ELSE 'N' END"))
            out = out.withColumn(pt["undetectable"], F.expr(
                f"CASE WHEN {v} IS NOT NULL AND {v} < {pun} THEN 'Y' "
                f"WHEN {v} IS NOT NULL THEN 'N' ELSE NULL END"))
    return out


def vitals(src, idx, vcfg):
    """clin_char_vitals_var: baseline BMI (+ BSA, Du Bois, when `bsa_formula` is set) from the
    height/weight closest to (and on/before) index."""
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window

    ht, wt = vcfg["height_test"].upper(), vcfg["weight_test"].upper()
    base = idx.select("patientid", "index_date")
    pull = (base.join(src["vitals"], "patientid", "inner")
            .withColumn("test_u", F.upper(F.col("test")))
            .filter((((F.col("test_u") == ht) & (F.col("testunitscleaned") == "cm")) |
                     ((F.col("test_u") == wt) & (F.col("testunitscleaned") == "kg"))) &
                    (F.col("testresultcleaned") > 0))
            .withColumn("vitaldate", F.greatest("testdate", "resultdate"))
            .filter(F.col("vitaldate") <= F.col("index_date")))
    w = Window.partitionBy("patientid", "index_date", "test_u").orderBy(F.col("vitaldate").desc())
    closest = (pull.withColumn("rn", F.row_number().over(w)).filter(F.col("rn") == 1))
    h = closest.filter(F.col("test_u") == ht).select(
        "patientid", "index_date", F.col("testresultcleaned").alias("height"))
    g = closest.filter(F.col("test_u") == wt).select(
        "patientid", "index_date", F.col("testresultcleaned").alias("weight"))
    out = (base.join(h, ["patientid", "index_date"], "left").join(g, ["patientid", "index_date"], "left")
           .withColumn("bmi", F.expr("CASE WHEN weight IS NOT NULL AND height > 0 "
                                     "THEN weight / pow(height/100, 2) ELSE NULL END"))
           .withColumn("bmigrl", F.expr(_num_bands_case(vcfg["bmi_bands"], "bmi", "label")))
           .withColumn("bmigrln", F.expr(_num_bands_case(vcfg["bmi_bands"], "bmi", "code"))))
    keep = ["patientid", "index_date", "height", "weight", "bmi", "bmigrl", "bmigrln"]
    if vcfg.get("bsa_formula"):           # BSA (Du Bois): 0.007184 * height(cm)^0.725 * weight(kg)^0.425
        out = out.withColumn("bsa", F.expr("CASE WHEN weight IS NOT NULL AND height > 0 "
                                           "THEN 0.007184 * pow(height, 0.725) * pow(weight, 0.425) ELSE NULL END"))
        keep.append("bsa")
    return out.select(*keep)


# Allowed mortality conflict-resolution policies (config: death_date_imputation.conflict_resolution).
# Keep in sync with the same-named set in engine/validate.py.
DEATH_CONFLICT_POLICIES = ("most_specific_then_earliest", "earliest", "latest")


def _death_conflict_order(F, dod, policy):
    """Window ordering that selects ONE mortality row per (patientid, index_date).

    `dod` is the cast-to-string dateofdeath SQL expression; longer string = finer granularity
    (full date > YYYY-MM > YYYY). `dateofdeath_init` must already be computed (index-aware).
    """
    specific = F.length(F.expr(dod)).desc_nulls_last()      # full > YYYY-MM > YYYY
    earliest = F.col("dateofdeath_init").asc_nulls_last()
    latest = F.col("dateofdeath_init").desc_nulls_last()
    tiebreak = F.expr(dod).asc_nulls_last()                 # deterministic final tiebreak
    if policy == "most_specific_then_earliest":
        return [specific, earliest, tiebreak]
    if policy == "earliest":
        return [earliest, specific, tiebreak]
    if policy == "latest":
        return [latest, specific, tiebreak]
    raise ValueError(f"unknown death_date_imputation.conflict_resolution: {policy!r} "
                     f"(allowed: {', '.join(DEATH_CONFLICT_POLICIES)})")


def baseline_ecog(src, idx, ecog_cfg):
    """clin_char_ecog_var: ECOG closest to index within window_days, ties -> earliest.

    A baseline record that EXISTS but has a null/"Unknown" value -> "Unknown" (code from
    value_codes), NOT "Missing". "Missing" is reserved for patients with NO baseline record.
    The numeric path is RLIKE-guarded so ANSI casting can't fail on a non-numeric value.
    """
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window

    lo, hi = ecog_cfg["window_days"]
    code_map = ecog_cfg["value_codes"]
    miss, miss_code = ecog_cfg["missing_label"], ecog_cfg["missing_code"]

    ecog = src["baseline_ecog"].select("patientid", "ecogdate", "ecogvalue")
    pulled = (idx.select("patientid", "index_date")
              .join(ecog, "patientid", "inner")
              .filter((F.col("ecogdate") >= F.expr(f"date_add(index_date, {lo})")) &
                      (F.col("ecogdate") <= F.expr(f"date_add(index_date, {hi})")))
              .withColumn("gap", F.abs(F.datediff("ecogdate", "index_date")))
              # 6-step nearest-record final tie-break: among records at the same gap AND same date,
              # the WORST (max) ECOG wins; Unknown/non-numeric ranks last so a real grade is preferred.
              # (The reconstruction documents this max-ecogvalue step but its summarise drops the value.)
              .withColumn("_rank", F.expr(
                  "CASE WHEN cast(ecogvalue as string) rlike '^[0-9]+([.]0+)?$' "
                  "THEN cast(cast(ecogvalue as double) as int) ELSE -1 END")))
    # tie_break selects the date direction among same-gap records (earliest_date default; latest_date
    # supported), then the worst-grade rank breaks a same-date tie.
    dt_order = (F.col("ecogdate").desc() if ecog_cfg.get("tie_break") == "latest_date"
                else F.col("ecogdate").asc())
    w = Window.partitionBy("patientid", "index_date").orderBy(
        F.col("gap").asc(), dt_order, F.col("_rank").desc())
    # Resolve the label on records that exist (present null/Unknown -> "Unknown").
    label = (
        "CASE WHEN ecogvalue IS NULL THEN 'Unknown' "
        "WHEN lower(trim(cast(ecogvalue as string))) = 'unknown' THEN 'Unknown' "
        "WHEN cast(ecogvalue as string) rlike '^[0-9]+([.]0+)?$' "
        "  THEN cast(cast(cast(ecogvalue as double) as int) as string) "
        "ELSE 'Unknown' END")
    nearest = (pulled.withColumn("rn", F.row_number().over(w))
                     .filter(F.col("rn") == 1)
                     .withColumn("ecog", F.expr(label))
                     .select("patientid", "index_date", "ecog"))

    code_when = " ".join(f"WHEN ecog = {_q(k)} THEN {v}" for k, v in code_map.items())
    return (idx.select("patientid", "index_date")
            .join(nearest, ["patientid", "index_date"], "left")
            .withColumn("ecog", F.coalesce(F.col("ecog"), F.lit(miss)))    # no record -> Missing
            .withColumn("ecogn", F.expr(f"CASE {code_when} ELSE {miss_code} END"))
            .select("patientid", "index_date", "ecog", "ecogn"))


def _last_date(df, datecol, alias, filt_sql=None):
    """max(datecol) per patient, optionally filtered. Helper for the follow-up-end maxima."""
    from pyspark.sql import functions as F
    d = df.filter(F.expr(filt_sql)) if filt_sql else df
    return d.groupBy("patientid").agg(F.max(F.col(datecol)).alias(alias))


# (logical source, date column, output alias, optional filter). fu_enddt is the latest of these
# that are PRESENT — heme/COTA tumors lacking alphabet/provenge simply contribute fewer.
FOLLOWUP_SOURCES = [
    ("visit",    "visitdate",          "last_visitdate",     None),
    ("telemed",  "visitdate",          "last_televisitdate", None),
    ("lot",      "enddate",            "last_lotenddate",    None),
    ("orals",    "enddate",            "last_oralenddate",
     "(startdategranularity <> 'Year' OR startdategranularity IS NULL) AND enddate IS NOT NULL"),
    ("alphabet", "administrationdate", "last_alphadate",     None),
    ("provenge", "startdate",          "last_provdate",      None),
]


def follow_up_and_death(src, idx, clin_cfg):
    """clin_char_fuend_dthdt_var: derive the follow-up-end / death anchors.

    Emits f_death, dthdt, dthfl, fu_enddt, fued, plus dthfufl_dur / dthfufl / dth_before_fued.
    fu_enddt_preliminary = latest of last visit / televisit / LOT end / oral end / alphabet /
    provenge dates. Death date is imputed from coarse granularity per config, then follow-up is
    capped at death and dates are snapped to month end where the R did.
    """
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window

    imp = clin_cfg["death_date_imputation"]
    month_day = int(imp["month_level_day"])          # 15
    year_md = str(imp["year_level_monthday"])        # "07-15"
    year_late = str(imp.get("year_level_late_monthday", year_md))   # "12-31"
    year_month = int(year_md.split("-")[0])          # 7 (month of the year-level default)
    conflict = str(imp.get("conflict_resolution", DEATH_CONFLICT_POLICIES[0]))
    dth_window = int(imp["death_followup_window_days"])   # 120

    fu = idx.select("patientid", "index_date")
    # follow_up_sources (config, optional):
    #   - omitted  -> the engine default set (FOLLOWUP_SOURCES), present-only
    #   - [names]  -> restrict the default set to these logical sources
    #   - [{source, date_column, alias[, filter]}] -> full override (a tumor whose follow-up table
    #     uses a different date column declares it here)
    spec = imp.get("follow_up_sources")
    if spec and isinstance(spec[0], dict):
        fu_spec = [(s["source"], s["date_column"],
                    s.get("alias", f"last_{s['source']}date"), s.get("filter")) for s in spec]
    else:
        fu_spec = FOLLOWUP_SOURCES
        if spec is not None:
            fu_spec = [t for t in FOLLOWUP_SOURCES if t[0] in set(spec)]

    added = []
    for srcname, datecol, alias, filt in fu_spec:
        if srcname not in src:                       # tumor/vendor doesn't have this table
            continue
        fu = fu.join(_last_date(src[srcname], datecol, alias, filt), "patientid", "left")
        added.append(alias)

    fu = fu.withColumn("fu_enddt_preliminary",
                       F.greatest(*added) if added else F.lit(None).cast("date"))
    if "last_lotenddate" not in added:              # referenced by the reconciliation below
        fu = fu.withColumn("last_lotenddate", F.lit(None).cast("date"))

    # Death from mortality (cast to string so a date- or string-typed dateofdeath both work:
    # a real date stringifies to length-10 -> direct cast).
    dod = "cast(dateofdeath as string)"
    # Join ALL mortality rows (do NOT pre-dedupe). The imputation below is index-aware, so the
    # "best" death row can only be chosen AFTER imputation, per (patientid, index_date).
    fu = fu.join(src["mortality"].select("patientid", "dateofdeath"), "patientid", "left")

    # Index-aware imputation: month-level -> day-`month_day`; a year-only (YYYY) death in the SAME
    # year as an on/after-`year_month` index -> `year_late` (e.g. Dec 31) so it can't precede the
    # index and yield negative OS. (Mirrors the original R index-year logic.)
    fu = fu.withColumn("dateofdeath_init", F.expr(
        f"CASE WHEN length({dod})=7 THEN cast(concat({dod},'-{month_day:02d}') as date) "
        f"WHEN length({dod})=4 THEN "
        f"  CASE WHEN cast({dod} as int) = year(index_date) AND month(index_date) >= {year_month} "
        f"       THEN cast(concat({dod},'-{year_late}') as date) "
        f"       ELSE cast(concat({dod},'-{year_md}') as date) END "
        f"WHEN length({dod})=10 THEN cast(dateofdeath as date) ELSE NULL END"))
    fu = fu.withColumn("f_death", F.expr("CASE WHEN dateofdeath IS NOT NULL THEN 1 ELSE 0 END"))

    # Collapse to ONE death row per (patientid, index_date) AFTER imputation. A patient dies once;
    # multiple mortality rows would otherwise fan out the ADS / distort OS. The tie-break policy
    # is config-driven (death_date_imputation.conflict_resolution) so it's a reviewed choice.
    mw = Window.partitionBy("patientid", "index_date").orderBy(
        *_death_conflict_order(F, dod, conflict))
    fu = (fu.withColumn("_rn", F.row_number().over(mw))
          .filter(F.col("_rn") == 1).drop("_rn"))

    # Month-level death in the FU-end month -> last day of that month.
    fu = fu.withColumn("death_dt_preliminary", F.expr(
        f"CASE WHEN length({dod})=7 "
        f"  AND substr(cast(fu_enddt_preliminary as string),1,7) = substr({dod},1,7) "
        f"  THEN last_day(dateofdeath_init) ELSE dateofdeath_init END"))

    # Cap follow-up at death; snap to last_lotenddate when in the same month (R reconciliation).
    fu = fu.withColumn("fu_enddt", F.expr(
        "CASE WHEN death_dt_preliminary IS NOT NULL "
        "  AND fu_enddt_preliminary > death_dt_preliminary THEN "
        "  CASE WHEN substr(cast(death_dt_preliminary as string),1,7) "
        "       = substr(cast(last_lotenddate as string),1,7) "
        "       THEN last_lotenddate ELSE death_dt_preliminary END "
        "ELSE fu_enddt_preliminary END"))
    fu = fu.withColumn("dthdt", F.expr(
        "CASE WHEN substr(cast(death_dt_preliminary as string),1,7) "
        "       = substr(cast(last_lotenddate as string),1,7) "
        "     THEN cast(last_day(death_dt_preliminary) as date) ELSE death_dt_preliminary END"))
    fu = fu.withColumn("dthfl", F.expr("CASE WHEN dthdt IS NOT NULL THEN 1 ELSE 0 END"))
    fu = fu.withColumn("fued", F.expr(
        "CASE WHEN fu_enddt > index_date THEN fu_enddt ELSE index_date END"))

    # Death within the follow-up window (R: dthfufl_dur / dthfufl / dth_before_fued).
    fu = fu.withColumn("dthfufl_dur", F.datediff("dthdt", "fued"))
    fu = fu.withColumn("dthfufl", F.expr(
        f"CASE WHEN dthdt IS NULL THEN 'Missing' "
        f"WHEN dthfufl_dur <= {dth_window} THEN '1' "
        f"WHEN dthfufl_dur > {dth_window} THEN '0' ELSE NULL END"))
    fu = fu.withColumn("dth_before_fued", F.expr(
        "CASE WHEN dthdt IS NOT NULL AND fued IS NOT NULL AND dthdt < fued THEN 1 ELSE 0 END"))

    return fu.select("patientid", "index_date", "f_death", "dthdt", "dthfl", "fu_enddt", "fued",
                     "dthfufl_dur", "dthfufl", "dth_before_fued")


def _surgery_sql(scfg) -> dict:
    """The fixed OC surgery-classification CASEs, parameterised by column names + labels. The 1L window
    columns _line1_start / _line1_end are joined by _surgery. Mirrored in cases.R::surgery_sql
    (parity-tested). PCS = surgery before 1L chemo (or flagged with no date); ICS = surgery at/after
    1L start; neoadj = surgery during the 1L window. (verify-vs-scan: the reconstruction's final
    select aliased issurg=issurgery / surgn=stagen — copy-paste slips; this emits the mutate intent.)
    """
    fl, dt = scfg["surgery_flag_column"], scfg["surgery_date_column"]
    yes, no = scfg.get("yes_value", "Yes"), scfg.get("no_value", "No")
    pcs, ics, none = scfg["pcs_label"], scfg["ics_label"], scfg["none_label"]
    # surg/surgn/neoadj only classify when a surgery actually occurred (issurgery = Yes) — a stray
    # surgery date on a No/Unknown/Missing row must NOT become PCS/ICS/neoadj. Within Yes: no date or
    # before 1L start -> Primary (PCS); at/after 1L start -> Interval (ICS).
    typ = (f"CASE WHEN {dt} IS NULL OR {dt} < _line1_start THEN '{pcs}' "
           f"WHEN {dt} >= _line1_start THEN '{ics}' ELSE '{none}' END")
    typn = (f"CASE WHEN {dt} IS NULL OR {dt} < _line1_start THEN 1 "
            f"WHEN {dt} >= _line1_start THEN 2 ELSE 3 END")
    return {
        "issurg": (f"CASE WHEN {fl} = '{yes}' THEN 'Yes' WHEN {fl} = '{no}' THEN '{none}' "
                   f"WHEN {fl} != '{yes}' AND {dt} IS NULL THEN 'Unknown' ELSE 'Missing' END"),
        "surg": f"CASE WHEN {fl} = '{yes}' THEN ({typ}) ELSE '{none}' END",
        "surgn": f"CASE WHEN {fl} = '{yes}' THEN ({typn}) ELSE 3 END",
        "neoadj": (f"CASE WHEN {fl} = '{yes}' AND {dt} >= _line1_start AND {dt} <= _line1_end "
                   f"THEN 'Yes' ELSE 'No' END"),
    }


def _surgery(F, src, idx, scfg):
    """OC surgery sub-block: issurg / surg / surgn / neoadj (+ tt_first_tx_diag) from the enhanced
    surgery fields and the 1L (linenumber 1, non-maintenance) line window. Cohort-independent — surgery
    is a baseline characteristic relative to 1L. Returns None when a required source is absent."""
    from pyspark.sql.window import Window
    enh, lot = src.get(scfg["source"]), src.get(scfg.get("line_source", "lot"))
    if enh is None or lot is None:
        return None
    base = idx.select("patientid", "index_date")
    fl, dt = scfg["surgery_flag_column"], scfg["surgery_date_column"]
    init, size = scfg.get("init_date_column", "diagnosisdate"), scfg.get("size_column")

    def _first(df, order_col):    # one DETERMINISTIC row per patient (== R window_order+row_number)
        w = Window.partitionBy("patientid").orderBy(F.col(order_col).asc())
        return df.withColumn("_rn", F.row_number().over(w)).filter(F.col("_rn") == 1).drop("_rn")

    e = _first(enh.select(*[c for c in ("patientid", fl, dt, init, size) if c and c in enh.columns]), dt)
    l1 = lot.filter(F.col(scfg.get("line_number_column", "linenumber")) == 1)
    mnt = scfg.get("maintenance_column")
    if mnt and mnt in lot.columns:
        l1 = l1.filter(f"lower(cast({mnt} as string)) != 'true'")    # non-maintenance 1L
    l1 = _first(l1.select("patientid", F.col(scfg["line_start_column"]).alias("_line1_start"),
                          F.col(scfg["line_end_column"]).alias("_line1_end")), "_line1_start")
    j = base.join(e, "patientid", "left").join(l1, "patientid", "left")
    sql = _surgery_sql(scfg)
    for name, expr in sql.items():
        j = j.withColumn(name, F.expr(expr))
    keep = ["patientid", "index_date", "issurg", "surg", "surgn", "neoadj"]
    if init in j.columns:                       # tt_first_tx_diag = days from diagnosis to first tx
        j = j.withColumn("tt_first_tx_diag", F.expr(f"datediff(least({dt}, _line1_start), {init})"))
        keep.append("tt_first_tx_diag")
    if size and size in j.columns:
        keep.append(size)
    return j.select(*keep)


def _min_avail_date(F, src, idx, blk, index_source):
    """Data-availability floor: minavaildate = the EARLIEST of the configured base date(s) and the
    first (min) date seen in each source; basedur = datediff(index_date, minavaildate). least()/min()
    skip nulls, so a patient absent from a source just doesn't lower the floor. == stages.R
    clinical_min_avail_date. Config: { base_columns?: [..], sources: [{source, date_column |
    date_columns:[..]}] }.
    """
    base = idx.select("patientid", "index_date")
    parts, cols = base, []
    isrc = src.get(index_source)
    for bc in (blk.get("base_columns") or []):           # per-patient base date(s) (e.g. diagnosis)
        if isrc is not None and bc in isrc.columns:
            parts = parts.join(isrc.select("patientid", F.col(bc).alias(f"_b_{bc}"))
                               .dropDuplicates(["patientid"]), "patientid", "left")
            cols.append(f"_b_{bc}")
    for i, s in enumerate(blk.get("sources") or []):      # first (min) date per source
        sd = src.get(s.get("source"))
        if sd is None:
            continue
        dcs = [d for d in (s.get("date_columns") or [s.get("date_column")]) if d and d in sd.columns]
        if not dcs:
            continue
        row_date = f"least({', '.join(dcs)})" if len(dcs) > 1 else dcs[0]   # row-wise min (e.g. test/result)
        parts = parts.join(sd.groupBy("patientid").agg(F.min(F.expr(row_date)).alias(f"_f{i}")),
                           "patientid", "left")
        cols.append(f"_f{i}")
    if not cols:
        return None
    return (parts.withColumn("minavaildate", F.expr(f"least({', '.join(cols)})"))
            .withColumn("basedur", F.expr("datediff(index_date, minavaildate)"))
            .select("patientid", "index_date", "minavaildate", "basedur"))


def _presence_flag_sql(fl) -> str:
    """A presence flag CASE: <from> IS NULL -> `absent` label, else `present` label (e.g. EC
    radiation_flag from radiationtherapydate). Mirrored in cases.R::presence_flag_sql (parity-tested)."""
    return f"CASE WHEN {fl['from']} IS NULL THEN '{fl['absent']}' ELSE '{fl['present']}' END"


def _passthrough(F, src, idx, blk, index_source):
    """Config-driven enhanced pass-through + presence flags (retires the former prostate-hardcoded
    gleason/PSA list; also carries EC radiation/recurrence columns). `columns: [{column, as?}]` aliases
    raw index-source columns; `flags: [{name, from, absent, present}]` adds a presence flag. Any column
    or flag whose source column is absent is skipped. == engine-r/stages.R::clinical_passthrough.
    """
    isrc = src.get(blk.get("source") or index_source)
    if isrc is None:
        return None
    cols = [c for c in (blk.get("columns") or []) if c["column"] in isrc.columns]
    flags = [f for f in (blk.get("flags") or []) if f["from"] in isrc.columns]
    if not cols and not flags:
        return None
    raw = sorted({c["column"] for c in cols} | {f["from"] for f in flags})
    e = isrc.select("patientid", *raw).dropDuplicates(["patientid"])    # enhanced = one row per patient
    out = idx.select("patientid", "index_date").join(e, "patientid", "left")
    keep = ["patientid", "index_date"]
    for c in cols:
        nm = c.get("as", c["column"])
        if c.get("bands"):                       # categorize a numeric enhanced column (e.g. Gleason score)
            out = (out.withColumn(nm, F.expr(_num_bands_case(c["bands"], c["column"], "label")))
                   .withColumn(nm + "n", F.expr(_num_bands_case(c["bands"], c["column"], "code"))))
            keep += [nm, nm + "n"]
        else:
            out = out.withColumn(nm, F.col(c["column"]))
            keep.append(nm)
    for f in flags:
        out = out.withColumn(f["name"], F.expr(_presence_flag_sql(f)))
        keep.append(f["name"])
    return out.select(*keep)


def _durations(F, src, idx, blk, index_source):
    """Config-driven derived durations: datediff between two dated milestones, in months (default) or
    days. `from`/`to` are enhanced-source date columns or the literal 'index_date'; each item is emitted
    only when BOTH its date columns are available (an absent enhanced column -> the item is skipped).
    Config: durations: { source?, days_per_month?, items: [{name, from, to, unit?: months|days}] }.
    == engine-r/stages.R::clinical_durations.
    """
    isrc = src.get(blk.get("source") or index_source)
    if isrc is None:
        return None
    dpm = float(blk.get("days_per_month", 30.4375))
    avail = lambda c: c == "index_date" or c in isrc.columns          # noqa: E731
    items = [it for it in (blk.get("items") or []) if avail(it.get("from")) and avail(it.get("to"))]
    if not items:
        return None
    cols = sorted({it[k] for it in items for k in ("from", "to")} - {"index_date"})
    e = isrc.select("patientid", *cols).dropDuplicates(["patientid"])  # enhanced = one row per patient
    out = idx.select("patientid", "index_date").join(e, "patientid", "left")
    for it in items:
        days = f"datediff({it['to']}, {it['from']})"
        out = out.withColumn(it["name"], F.expr(days if it.get("unit") == "days" else f"({days})/{dpm}"))
    return out.select("patientid", "index_date", *[it["name"] for it in items])


def _metastatic_sites(F, src, idx, blk):
    """Per-site Yes/No presence flags at index (prostate ClinChars: HEPATIC/LUNG/ADRENAL/BONE/BRAIN_MET):
    Yes if the patient has a metastasis record at the site dated BEFORE index (DateOfMetastasis <
    index_date AND SiteOfMetastasis == match), else No. blk: { source, site_column, date_column,
    yes_label?, no_label?, sites: [{name, match}] }. Presence = max() over the metastasis rows in the
    (patientid, index_date) group. == engine-r/stages.R::clinical_metastatic_sites.
    """
    s = src.get(blk["source"])
    if s is None:
        return None
    site_col, date_col = blk["site_column"], blk["date_column"]
    if site_col not in s.columns or date_col not in s.columns:
        return None
    yes, no = blk.get("yes_label", "Yes"), blk.get("no_label", "No")
    base = idx.select("patientid", "index_date")
    j = base.join(s.select("patientid", site_col, date_col), "patientid", "left")
    aggs = [F.max(F.expr(
        f"CASE WHEN lower({site_col}) = {_q(str(it['match']).lower())} AND {date_col} < index_date "
        f"THEN 1 ELSE 0 END")).alias("_" + it["name"]) for it in blk["sites"]]
    g = j.groupBy("patientid", "index_date").agg(*aggs)
    for it in blk["sites"]:
        g = (g.withColumn(it["name"], F.expr(f"CASE WHEN _{it['name']} = 1 THEN {_q(yes)} ELSE {_q(no)} END"))
             .drop("_" + it["name"]))
    return g


def _derived(F, clin, items, study):
    """Config-driven derived columns over the ASSEMBLED clinical frame + study constants — the spec
    master mutate (INDEXYR / INITYR / MCRPCDDYR / MPCDDYR / PINDDUR / FUDUR / PFUDUR). Each item is emitted
    only when all its `requires` columns are present (graceful — so a tumor lacking mcrpcdd/fued simply
    omits the dependent variable). `{index_start}` / `{index_end}` in the expr are substituted from study
    config. == engine-r/stages.R::clinical_derived.
    """
    cols = set(clin.columns)
    for it in (items or []):
        if not all(c in cols for c in (it.get("requires") or [])):
            continue
        expr = (it["expr"].replace("{index_start}", f"date('{study['index_start']}')")
                .replace("{index_end}", f"date('{study['index_end']}')"))
        clin = clin.withColumn(it["name"], F.expr(expr))
    return clin


def build(src, idx, cfg):
    from pyspark.sql import functions as F
    clin_cfg = cfg.pack("clinical")
    base = idx.select("patientid", "index_date")

    # Baseline ECOG is OPTIONAL: a tumor/vendor without a baseline_ecog table lints clean and
    # gets the configured Missing value rather than a KeyError.
    ecog_cfg = clin_cfg["baseline_ecog"]
    if "baseline_ecog" in src:
        ecog = baseline_ecog(src, idx, ecog_cfg)
    else:
        ecog = (base
                .withColumn("ecog", F.lit(ecog_cfg["missing_label"]))
                .withColumn("ecogn", F.lit(ecog_cfg["missing_code"])))

    clin = (base
            .join(ecog, ["patientid", "index_date"], "left")
            .join(follow_up_and_death(src, idx, clin_cfg),
                  ["patientid", "index_date"], "left"))

    # Stage (config-driven grouping) from `groupstage`. The source/date/priority are configurable
    # (staging.source / staging.date_column / staging.pick) so a patient with multiple stage rows
    # is resolved DETERMINISTICALLY (latest/earliest by date, then stable tiebreak) — not an
    # arbitrary dropDuplicates pick. Defaults: index source, latest, groupstage tiebreak.
    from pyspark.sql.window import Window
    stcfg = clin_cfg.get("staging") or {}
    groups = stcfg.get("groups")
    st_src = src.get(stcfg.get("source", cfg.index_source))
    if st_src is not None and groups and "groupstage" in st_src.columns:
        st = _categorical_pick(F, Window, st_src, "groupstage", groups, "stage",
                               stcfg.get("date_column"), stcfg.get("pick", "latest"))
        clin = clin.join(st, "patientid", "left")

    # Generic categorical clinical characteristics (grade / histology / …): the same value->group
    # CASE as staging, on any source column, picked deterministically per patient. Reuses the
    # parity-proven _stage_case compiler. Config: clinical.categoricals:
    #   [{name, column, source?, date_column?, pick?, groups: [...]}].
    for cat in (clin_cfg.get("categoricals") or []):
        cat_src = src.get(cat.get("source", cfg.index_source))
        col, cgroups, cname = cat.get("column"), cat.get("groups"), cat.get("name")
        if cat_src is None or not cgroups or not col or not cname or col not in cat_src.columns:
            continue
        clin = clin.join(
            _categorical_pick(F, Window, cat_src, col, cgroups, cname,
                              cat.get("date_column"), cat.get("pick", "latest")),
            "patientid", "left")

    # Closest-to-index PANELS (biomarkers / labs): each item picks the record nearest index within
    # its window and maps the value via the shared _stage_case compiler. Optional per tumor.
    for blk_key in ("biomarkers", "labs"):
        blk = clin_cfg.get(blk_key)
        if blk and blk.get("source") in src and blk.get("panel"):
            clin = clin.join(_closest_panel(F, Window, src[blk["source"]], blk, idx),
                             ["patientid", "index_date"], "left")

    # Metastatic-site presence flags at index (hepatic/lung/adrenal/bone/brain) — optional, config-gated.
    msblk = clin_cfg.get("metastatic_sites")
    if msblk and msblk.get("source") in src and msblk.get("sites"):
        ms = _metastatic_sites(F, src, idx, msblk)
        if ms is not None:
            clin = clin.join(ms, ["patientid", "index_date"], "left")

    # Closest-to-index raw lab VALUES (LABNEU present flag + LABNEUv value + LABNEUdt date) — optional.
    lvblk = clin_cfg.get("lab_values")
    if lvblk and lvblk.get("source") in src and lvblk.get("panel"):
        clin = clin.join(_closest_values_panel(F, Window, src[lvblk["source"]], lvblk, idx),
                         ["patientid", "index_date"], "left")

    # Windowed PSA timepoints + PSA-response endpoints (PSA at index / 6mo / 12mo; PSA50 / undetectable).
    psablk = clin_cfg.get("psa_timepoints")
    if psablk and psablk.get("source") in src and psablk.get("points"):
        clin = clin.join(_psa_timepoints(F, Window, src[psablk["source"]], psablk, idx),
                         ["patientid", "index_date"], "left")

    # OC surgery sub-block (issurg / surg / surgn / neoadj + tt_first_tx_diag) — optional, config-gated.
    scfg = clin_cfg.get("surgery")
    if scfg and scfg.get("source") in src:
        sg = _surgery(F, src, idx, scfg)
        if sg is not None:
            clin = clin.join(sg, ["patientid", "index_date"], "left")

    # minavaildate / basedur (data-availability floor) — optional, config-gated (OC/EC).
    mblk = clin_cfg.get("min_avail_date")
    if mblk and (mblk.get("sources") or mblk.get("base_columns")):
        mad = _min_avail_date(F, src, idx, mblk, cfg.index_source)
        if mad is not None:
            clin = clin.join(mad, ["patientid", "index_date"], "left")

    # Baseline BMI from vitals — optional (a tumor without a vitals table just omits these columns).
    if "vitals" in src and clin_cfg.get("vitals"):
        clin = clin.join(vitals(src, idx, clin_cfg["vitals"]), ["patientid", "index_date"], "left")

    # Config-driven enhanced pass-through + presence flags (EC radiation/recurrence; prostate
    # gleason/PSA) — see clinical.passthrough. Replaces the former hardcoded gleason/PSA list.
    pblk = clin_cfg.get("passthrough")
    if pblk:
        pt = _passthrough(F, src, idx, pblk, cfg.index_source)
        if pt is not None:
            clin = clin.join(pt, ["patientid", "index_date"], "left")

    # Derived durations (months/days between two dated milestones, e.g. diagnosis->metastasis) — optional.
    dblk = clin_cfg.get("durations")
    if dblk and dblk.get("items"):
        du = _durations(F, src, idx, dblk, cfg.index_source)
        if du is not None:
            clin = clin.join(du, ["patientid", "index_date"], "left")

    # mCRPC index-window flag + MCRPCDD date — config-gated (clinical.mcrpc_window): greatest(columns)
    # within the study window. Emitted when all configured date columns exist on the index source.
    mcw = clin_cfg.get("mcrpc_window")
    isrc = src.get(cfg.index_source)
    if mcw and isrc is not None and set(mcw.get("columns") or []) <= set(isrc.columns):
        start = F.lit(cfg.study["index_start"]).cast("date")
        end = F.lit(cfg.study["index_end"]).cast("date")
        dnm, fnm = mcw.get("date_as", "mcrpcdd"), mcw.get("flag_as", "mcrpc")
        mc = (isrc.select("patientid", F.greatest(*mcw["columns"]).alias(dnm))
              .dropDuplicates(["patientid"])          # enhanced index source = one row per patient
              .withColumn(fnm, F.when((F.col(dnm) >= start) & (F.col(dnm) <= end),
                                      F.lit(1)).otherwise(F.lit(0))))
        clin = clin.join(mc, "patientid", "left")

    # Derived columns over the assembled frame (spec master mutate: INDEXYR / diagnosis-years / durations).
    dvb = clin_cfg.get("derived")
    if dvb:
        clin = _derived(F, clin, dvb, cfg.study)
    return clin
