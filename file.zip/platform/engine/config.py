"""Config loader for a tumor RWDP. Pure Python (stdlib + PyYAML) — no Spark.

Loads config/data_product.yaml, applies dotted-key overrides (so a Databricks job can pass
`run.refresh=2026q2` with no code change), and resolves what the locked, tumor-agnostic engine
needs: vendor-aware source table names, the cohort list, and the referenced variable/codelist packs.
"""
from __future__ import annotations

from pathlib import Path
import copy
import yaml

try:                    # works whether config is imported as engine.config or as top-level config
    from . import vendors
except ImportError:
    import vendors


def load_yaml(path) -> dict:
    with open(path, encoding="utf-8") as fh:      # explicit UTF-8 so YAML with non-ASCII loads on Windows (cp1252)
        return yaml.safe_load(fh)


def product_dir(products_root, slug, spec_version=None, registry=None):
    """Resolve a product's SPEC-VERSIONED pack dir: `<products_root>/<family>/<slug>/<spec_version>/`
    (which holds config/, variables/, codelists/, source_refs.yaml). Every product keeps one folder per
    spec version, so v1 and v2 coexist as independently buildable + diffable + auditable contracts.

    `spec_version` defaults to the registry's `current_spec_version` for that slug. Pass an explicit one
    (e.g. a superseded version like '202603') to target it — but it must be a version the registry
    actually DECLARES for the slug (`current_spec_version` + `lineage[].spec_version`); an unknown
    explicit version is treated as a typo and raises `KeyError` (naming the known set) rather than
    silently resolving to a missing dir that 404s deep in the load. Family comes from the registry
    (default 'oncology')."""
    from pathlib import Path
    products_root = Path(products_root)
    reg = registry if registry is not None else load_yaml(str(products_root / "registry.yaml"))
    entry = next((t for t in (reg.get("tumors") or []) if t.get("slug") == slug), {}) or {}
    family = entry.get("family", "oncology")
    sv = spec_version if spec_version is not None else entry.get("current_spec_version")
    if not sv:
        raise KeyError(f"slug '{slug}': no spec_version given and no current_spec_version in registry")
    # An EXPLICIT version must be one the registry declares for this slug — fail a typo'd '202609'
    # loudly here (with the known set) instead of building a path that 404s deep in the load. The
    # None default is exempt: it IS the current version by construction. A 'YYYYMM' scaffold
    # placeholder is not a real version, so it never constrains.
    if spec_version is not None:
        known = {entry.get("current_spec_version")} | {
            str(v.get("spec_version")) for v in (entry.get("lineage") or []) if v.get("spec_version")}
        known = {k for k in known if k and k != "YYYYMM"}
        if known and str(sv) not in known:
            raise KeyError(
                f"slug '{slug}': spec_version '{sv}' is not declared in the registry "
                f"(known: {sorted(known)}) — add a lineage row or fix the typo.")
    return products_root / family / slug / str(sv)


def product_config(products_root, slug, spec_version=None, registry=None):
    """The `config/data_product.yaml` for a product's (current or given) spec version (see product_dir)."""
    return product_dir(products_root, slug, spec_version, registry) / "config" / "data_product.yaml"


def _set_dotted(d: dict, dotted_key: str, value):
    """Set value at a dotted path, e.g. 'run.refresh' -> d['run']['refresh']."""
    parts = dotted_key.split(".")
    node = d
    for p in parts[:-1]:
        node = node.setdefault(p, {})
    node[parts[-1]] = value


class Config:
    """Resolved view over data_product.yaml. Attribute access for the common knobs,
    plus helpers the engine uses (table resolution, cohort lookup, pack access)."""

    def __init__(self, raw: dict, root: Path):
        self.raw = raw
        self.root = root
        self.run = raw.get("run", {})
        self.study = raw.get("study", {})
        self.cohorts = raw.get("cohorts", [])
        # Data format (Flatiron EDM | Panoramic …). Selects a per-format overlay over the base
        # `sources` map + table-name layout + column renames, so the SAME engine + variable logic runs
        # on either delivery. EDM is the default; a `formats:` block declares the alternatives. The
        # engine only ever sees the logical/EDM column names (Panoramic renames apply at source load).
        self.data_format = self.run.get("data_format") or raw.get("data_format") or "EDM"
        self._format_block = (raw.get("formats") or {}).get(self.data_format, {})
        self.sources = {**raw.get("sources", {}), **(self._format_block.get("sources") or {})}
        self.index_dates = raw.get("index_dates", {})
        self.treatment_status = raw.get("treatment_status", {})
        self.vendor = raw.get("vendor", "flatiron")        # flatiron | cota | …
        self.tumor_class = raw.get("tumor_class", "solid")  # solid | heme
        # Lazily-loaded packs/codelists (loaded on first access).
        self._packs = None
        self._packs_by_role = None
        self._codelists = None

    # --- run/output -------------------------------------------------------
    @property
    def refresh(self) -> str:
        return self.run["refresh"]

    @property
    def source_schema(self) -> str:
        return self.run["source_schema"]

    @property
    def output_schema(self) -> str:
        return self.run["output_schema"]

    @property
    def output_table(self) -> str:
        return self.run["output_table"]

    @property
    def data_product_id(self) -> str:
        """Stable product identifier (e.g. prostate_mcrpc_rwdp) — stamped on every ADS row so a row
        self-identifies its product, alongside spec_version + data_refresh. Build-level provenance
        (engine_version / git_commit / build_id) lives in the manifest, keyed by these stamps."""
        return str(self.raw.get("data_product_id", ""))

    @property
    def output_fqn(self) -> str:
        return f"{self.output_schema}.{self.output_table}"

    @property
    def write_mode(self) -> str:
        return self.run.get("write_mode", "overwrite")

    @property
    def version(self) -> str:
        """Full product version with {snapshot} filled from the refresh (e.g. 202606.2026q1) — a
        human-readable spec+cut label for logs/QC reports. The audit STAMP is `spec_version`, not this."""
        return str(self.raw.get("version", "")).replace("{snapshot}", str(self.refresh))

    @property
    def spec_version(self) -> str:
        """The contract version alone (CalVer YYYYMM, e.g. 202606) — `version` with the data-refresh
        snapshot stripped. THIS is what stamps ADS rows + manifests and what
        registry.current_spec_version tracks; the data cut is carried separately as `data_refresh`, so
        the two axes never duplicate. (template 202606.{snapshot} -> spec_version 202606.)"""
        return str(self.raw.get("version", "")).split("{snapshot}")[0].rstrip("._-/ ")

    @property
    def source_layout(self):
        """Vendor table-name template override: the active data format's, else a run-level override."""
        return self._format_block.get("source_layout") or self.run.get("source_layout")

    @property
    def source_renames(self):
        """Per-source column renames {source: {physical: logical}} for the active data format, applied
        at source load so the engine always sees the logical/EDM column names. Empty for EDM."""
        return self._format_block.get("rename") or {}

    @property
    def source_union(self):
        """Optional multi-schema union: read each declared source from EVERY member schema, tag it
        with a `discriminator` column, and union the members. None = single schema (run.source_schema).
        EC uses this for Flatiron EDM ∪ Dostarlimab registry (db = EDM/DOS)."""
        return self.raw.get("source_union")

    @property
    def lot_line_setting(self):
        """LOT line-setting filter for new_lot_n (e.g. mCRPC for prostate). None = no filter."""
        return self.raw.get("lot", {}).get("line_setting")

    @property
    def lot_exclude_settings(self):
        """Line settings to DROP before numbering (e.g. EC drops 'ADVANCED'). [] = drop none."""
        return self.raw.get("lot", {}).get("exclude_settings") or []

    @property
    def lot_line_number_col(self):
        """How a cohort's 'line N' is identified: 'new_lot_n' (a derived row_number over the
        kept lines — the default; prostate/NSCLC) or 'linenumber' (the raw LOT line number;
        OC/EC index off raw linenumber + the maintenance flag)."""
        return self.raw.get("lot", {}).get("line_number", "new_lot_n")

    @property
    def lot_maintenance_column(self):
        """Column carrying the maintenance flag (OC/EC: ismaintenancetherapy). Only consulted when
        a cohort sets `maintenance:`; tumors without maintenance lines (prostate/NSCLC) never do."""
        return self.raw.get("lot", {}).get("maintenance_column", "ismaintenancetherapy")

    @property
    def index_source(self):
        """Logical source the 'overall' index date is built from. Default 'enhanced'; heme tumors
        index off 'diagnosis' (set index_dates.advanced_diagnosis_date.source)."""
        return self.index_dates.get("advanced_diagnosis_date", {}).get("source", "enhanced")

    # --- sources ----------------------------------------------------------
    def table(self, name: str) -> str:
        """Resolve a logical source name to a physical table, vendor-aware.

        Flatiron -> `{schema}.{stem}_{refresh}`; other vendors via engine/vendors.py (or a
        `run.source_layout` override). Mirrors the R `in_schema(dbname, paste0(...))`.
        """
        if name not in self.sources:
            raise KeyError(f"unknown source '{name}'. Known: {sorted(self.sources)}")
        return vendors.resolve(self.vendor, self.source_layout,
                               self.source_schema, self.sources[name], self.refresh)

    def table_in(self, name: str, schema: str) -> str:
        """Resolve a source to a physical table in a SPECIFIC schema (for multi-schema unions)."""
        if name not in self.sources:
            raise KeyError(f"unknown source '{name}'. Known: {sorted(self.sources)}")
        return vendors.resolve(self.vendor, self.source_layout, schema, self.sources[name], self.refresh)

    def source_fqns(self, name: str) -> list:
        """Every physical table a source resolves to: one normally, or one per `source_union` member
        schema. Preflight checks all of them, so a missing member table fails fast."""
        u = self.source_union
        if u:
            return [self.table_in(name, m["schema"]) for m in u.get("members", [])]
        return [self.table(name)]

    def all_tables(self) -> dict:
        return {name: self.table(name) for name in self.sources}

    # --- cohorts ----------------------------------------------------------
    def cohort(self, cohort_id: str) -> dict:
        for c in self.cohorts:
            if c["id"] == cohort_id:
                return c
        raise KeyError(f"unknown cohort '{cohort_id}'")

    # --- variable packs / codelists --------------------------------------
    def packs(self) -> dict:
        """{pack_id: pack_dict} for every variables/*.yaml referenced in config."""
        if self._packs is None:
            self._packs = {}
            for rel in self.raw.get("variables", []):
                pack = load_yaml(self.root / rel)
                self._packs[pack["pack_id"]] = pack
        return self._packs

    def _packs_by_role_map(self) -> dict:
        if self._packs_by_role is None:
            self._packs_by_role = {Path(rel).stem: load_yaml(self.root / rel)
                                   for rel in self.raw.get("variables", [])}
        return self._packs_by_role

    def pack(self, role: str) -> dict:
        """Variable pack by ROLE — the file stem (demographics / clinical / treatment / outcomes).

        This keeps the shared engine tumor-agnostic: stages look up by role, so `pack_id` is just
        a label and each tumor names its packs however it likes.
        """
        packs = self._packs_by_role_map()
        if role not in packs:
            raise KeyError(f"no variable pack for role '{role}'; have {sorted(packs)}")
        return packs[role]

    def roles(self) -> set:
        """The set of pack roles (file stems) this product provides."""
        return set(self._packs_by_role_map())

    def codelist(self, key: str) -> dict:
        """Load a referenced codelist by its config key (e.g. 'treatment_categories')."""
        if self._codelists is None:
            self._codelists = {}
        if key not in self._codelists:
            rel = self.raw.get("codelists", {})[key]
            self._codelists[key] = load_yaml(self.root / rel)
        return self._codelists[key]


def load_config(path, overrides: dict | None = None) -> Config:
    """Load a Config from data_product.yaml.

    `overrides` is a flat dict of dotted keys, e.g. {"run.refresh": "2026q2"}; empty-string
    values are ignored so a job can pass through blanks harmlessly.
    """
    path = Path(path)
    raw = load_yaml(path)
    raw = copy.deepcopy(raw)
    for k, v in (overrides or {}).items():
        if v is None or v == "":
            continue
        _set_dotted(raw, k, v)
    # Product root is the folder that contains config/ (one level up from the yaml).
    root = path.resolve().parent.parent
    return Config(raw, root)
