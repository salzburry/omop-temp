"""Refresh governance — per-refresh manifests so git IS the refresh ledger.

Each released data cut (a `refresh`, e.g. 2026q1) writes a manifest under
`refreshes/<family>/<product>/<spec_version>/<refresh>.yaml`, committed to git. The manifest records exactly what produced
the ADS (spec version, git commit, run params, row/cohort counts, QC result, golden summary) and
its sign-off — so any number is reproducible (checkout the commit/tag, re-run the same config).

Pure Python (no Spark): build_manifest() assembles the manifest; validate_manifest() checks it.
The Databricks runner can write it after build+QC; sign-off fields are filled by a reviewed commit.
"""
from __future__ import annotations

from datetime import datetime, timezone

try:                       # engine version stamp (build-level provenance); cheap, no Spark
    from .version import ENGINE_VERSION
except Exception:          # noqa: BLE001 - keep manifest buildable even if VERSION is unreadable
    ENGINE_VERSION = "unknown"

STATUSES = ["qc_pending", "qc_passed", "released", "superseded"]
REQUIRED = ["tumor", "refresh", "spec_version", "built_at", "status", "counts"]


def build_manifest(cfg, *, tumor, family="oncology", git_commit=None, counts=None, qc=None, golden=None,
                   source_qc=None, source_qc_gate=None, deliverables=None, artifacts=None,
                   published_at=None) -> dict:
    """Assemble a refresh manifest from the resolved config + the run's outputs.

    `source_qc` is the full pre-build source-QC REPORT (mortality granularity + death-conflict
    counts); `source_qc_gate` is its pass/fail decision. `deliverables` records per-artifact status
    (dictionary / TFLs: ok | empty | failed | skipped) so the ledger shows whether the refresh's
    deliverables are complete.

    `published_at` is None for the PRE-publish ledger (written before the temp-then-swap) and is set
    to the swap timestamp only AFTER a successful publish. So `status: qc_passed` with a null
    `published_at` means "cleared QC, NOT yet published" and can never be mistaken for a successful
    publish (e.g. if the swap failed after the pre-publish ledger was written).
    """
    return {
        "tumor": tumor,
        "family": family,                       # product family (oncology) — first segment of the ledger path
        "refresh": cfg.refresh,
        "spec_version": cfg.spec_version,       # CalVer contract (e.g. 202606); the cut is `refresh`
        "data_product_id": cfg.data_product_id, # stable product id (also stamped on every ADS row)
        "engine_version": ENGINE_VERSION,       # build-level provenance: which engine produced this
        "vendor": cfg.vendor,
        "tumor_class": cfg.tumor_class,
        "built_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "git_commit": git_commit,
        "source_schema": cfg.source_schema,
        "source_union": cfg.source_union,      # the member schemas+flags that produced the build (EC);
                                               # None for a single-schema source. source_schema is
                                               # unused under a union, so this is the real provenance.
        "output_table": cfg.output_fqn,
        "status": "qc_passed" if (qc or {}).get("passed") else "qc_pending",
        "published_at": published_at,          # None until the swap succeeds (set post-publish)
        "counts": counts or {},
        "source_qc": source_qc or {},          # full report (granularity, conflict counts)
        "source_qc_gate": source_qc_gate or {},  # pass/fail decision
        "qc": qc or {},
        "golden": golden or {"reference": "none"},
        "deliverables": deliverables or {},    # {dictionary: {...}, tfls: {...}} status
        "artifacts": artifacts or {},   # durable paths: qc_report, dictionary, tfl_dir
        "sign_off": {"qc_by": "", "qc_date": "", "released_by": "", "released_date": ""},
    }


def manifest_path(manifest: dict, root) -> "Path":
    """The SPEC-VERSIONED ledger path for a manifest:
    `<root>/refreshes/<family>/<product>/<spec_version>/<refresh>.yaml`. The spec_version segment lets two
    contracts of the same product (e.g. 202603 and 202606) coexist for the same refresh without colliding.
    `<product>` is the registry CODE (the durable identity, == the release-tag segment)."""
    from pathlib import Path
    return (Path(root) / "refreshes" / str(manifest.get("family", "oncology")) / str(manifest["tumor"])
            / str(manifest["spec_version"]) / f"{manifest['refresh']}.yaml")


def release_dir(root, manifest: dict, build_id: str) -> "Path":
    """The matching immutable evidence dir for a build:
    `<root>/releases/<family>/<product>/<spec_version>/<refresh>/<build_id>/` (engine/audit.py bundle)."""
    from pathlib import Path
    return (Path(root) / "releases" / str(manifest.get("family", "oncology")) / str(manifest["tumor"])
            / str(manifest["spec_version"]) / str(manifest["refresh"]) / str(build_id))


def write_manifest(manifest: dict, root) -> str:
    """Write a VALID manifest to the spec-versioned ledger path (see manifest_path). Returns the path.

    Refuses to write an invalid manifest. (The runner calls this best-effort; the manifest is then
    committed to git — that commit is the audited refresh record.)
    """
    import yaml
    probs = validate_manifest(manifest)
    if probs:
        raise ValueError("refusing to write an invalid manifest:\n  - " + "\n  - ".join(probs))
    path = manifest_path(manifest, root)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as fh:
        yaml.safe_dump(manifest, fh, sort_keys=False, default_flow_style=False)
    return str(path)


def validate_manifest(m: dict) -> list:
    """Return a list of problems with a manifest (empty = valid). Pure data check."""
    out = []
    for k in REQUIRED:
        if k not in m or m[k] in (None, ""):
            out.append(f"manifest missing '{k}'")
    if m.get("status") not in STATUSES:
        out.append(f"status '{m.get('status')}' not one of {STATUSES}")
    if m.get("status") == "released":
        if not m.get("sign_off", {}).get("released_by"):
            out.append("status 'released' requires sign_off.released_by")
        if not m.get("git_commit"):
            out.append("status 'released' requires git_commit (reproducibility)")
        # 'released' is set only AFTER a successful publish (refreshes/README.md step 5) -> it must carry
        # the publish timestamp, the release pointer (the versioned set that went live), AND a passed
        # tfl_promotion (the public views were swapped) — not just QC. The runner sets passed False on a
        # release-phase failure and True only after every public view swaps, so this rejects a released
        # manifest whose swap never completed.
        if not m.get("published_at"):
            out.append("status 'released' requires published_at (a released refresh was published)")
        if m.get("release") is None:
            out.append("status 'released' requires a release pointer (the versioned set that went live)")
        if not (m.get("tfl_promotion") or {}).get("passed"):
            out.append("status 'released' requires tfl_promotion.passed True (the public views swapped)")
    counts = m.get("counts") or {}
    if "total_rows" in counts and not isinstance(counts["total_rows"], int):
        out.append("counts.total_rows must be an integer")
    su = m.get("source_union")
    if su is not None and not (isinstance(su, dict) and su.get("members")):
        out.append("source_union must carry members when present")
    tp = m.get("tfl_promotion")
    if tp is not None and (not isinstance(tp, dict) or "passed" not in tp):
        out.append("tfl_promotion must record a 'passed' flag when present")
    rel = m.get("release")
    if rel is not None:
        if not isinstance(rel, dict):
            out.append("release must be a mapping when present")
        else:
            miss = [k for k in ("public", "version", "build_id", "ads", "views") if not rel.get(k)]
            if miss:
                out.append(f"release missing {miss} (public/version/build_id/ads/views required when present)")
            elif not isinstance(rel["views"], dict) or rel["views"].get(rel["public"]) != rel["ads"]:
                out.append("release.views must map the public name to release.ads "
                           "(views[public] == ads, the ADS view is the commit anchor)")
    if m.get("published_at") and rel is None:
        out.append("a published manifest (published_at set) must carry a release pointer")
    return out
