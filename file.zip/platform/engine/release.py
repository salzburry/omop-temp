"""Atomic-ish release pointer — publish a CONSISTENT (ADS + TFLs) release behind stable consumer names.

Each BUILD writes IMMUTABLE versioned tables ({final}__{refresh}__{build_id}[ __tfl_{tid}]) — the
build_id (a git SHA or run timestamp) makes a same-refresh rerun a NEW physical table, never an
overwrite of the table a live view already points at. The stable public names consumers read ({final},
{final}__tfl_{tid}) are VIEWS.

The swap is sequential, TFLs FIRST then the ADS LAST: the ADS view is the commit anchor, so a failure
before it leaves the ADS pointing at the previous build (a consumer keying off the ADS sees the prior,
consistent release). published_at is set ONLY after every view — ending with the ADS — has swapped;
on failure the manifest records `release_swap_failed_at`, not published_at. (A single one-row release
pointer that consumers resolve through would be fully atomic across the set — the `release_pointer`
record below is exactly that data, ready for a consumer that wants it; switching to it is future work.)

Pure Python: naming + swap SQL + the pointer record. The runner executes the SQL on Spark.
"""
from __future__ import annotations


def versioned_ads(final: str, refresh: str, build_id: str) -> str:
    return f"{final}__{refresh}__{build_id}"


def versioned_tfl(final: str, refresh: str, build_id: str, tid: str) -> str:
    return f"{final}__{refresh}__{build_id}__tfl_{tid}"


def public_tfl(final: str, tid: str) -> str:
    return f"{final}__tfl_{tid}"


def view_swap_sql(public: str, versioned: str) -> str:
    """SQL to point the stable public name at a versioned table — non-destructive + idempotent.

    CREATE OR REPLACE VIEW atomically replaces the view definition. (One-time migration: if a public
    name currently exists as a TABLE from a pre-pointer deployment it must be dropped once so the view
    can take the name — the runner preflights this; a brand-new product has no such table.)
    """
    return f"CREATE OR REPLACE VIEW {public} AS SELECT * FROM {versioned}"


def stale_public_tfls(existing_public, final: str, current_ids) -> list:
    """Public TFL view names that EXIST but are NOT in the current release (a spec dropped the TFL) —
    their views would keep serving the PREVIOUS build's data. The runner records these as `retired_tfls`
    so the ledger is honest; it never auto-drops a consumer-readable view. `existing_public` is the set
    of public TFL view names currently in the schema (e.g. from SHOW TABLES). Pure set difference."""
    current = {public_tfl(final, tid) for tid in (current_ids or [])}
    return sorted(n for n in (existing_public or []) if n not in current)


def swap_plan(final: str, refresh: str, build_id: str, tfl_ids) -> list:
    """Ordered (public, versioned, sql) view swaps — TFLs FIRST, the ADS LAST (the commit anchor)."""
    pairs = [(public_tfl(final, tid), versioned_tfl(final, refresh, build_id, tid))
             for tid in (tfl_ids or [])]
    pairs.append((final, versioned_ads(final, refresh, build_id)))      # ADS view swapped last
    return [(pub, ver, view_swap_sql(pub, ver)) for pub, ver in pairs]


def release_pointer(final: str, refresh: str, build_id: str, tfl_ids, *,
                    manifest=None, spec_version=None) -> dict:
    """The consistent release set for this build — recorded in the manifest as the durable pointer."""
    return {"public": final, "version": refresh, "build_id": build_id, "spec_version": spec_version,
            "ads": versioned_ads(final, refresh, build_id),
            "tfls": {tid: versioned_tfl(final, refresh, build_id, tid) for tid in (tfl_ids or [])},
            "views": {pub: ver for pub, ver, _ in swap_plan(final, refresh, build_id, tfl_ids)},
            "manifest": manifest}
