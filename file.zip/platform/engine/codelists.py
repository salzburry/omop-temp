"""Compile the treatment-category codelist into Spark SQL CASE expressions. Pure Python.

The R script classified each line of therapy with a 17-way `case_when` (lotcat / lotcatn).
That logic now lives in codelists/treatment_categories.yaml. This module turns the ordered
list into two Spark SQL CASE expressions — one for the label, one for the numeric code —
preserving first-match-wins. The engine wraps them with F.expr(); the strings are also
trivially unit-testable without Spark.
"""
from __future__ import annotations


def _sql_str(s: str) -> str:
    """Single-quote and escape a string literal for SQL."""
    return "'" + str(s).replace("'", "''") + "'"


def compile_match(match: dict, name_col: str, cat_col: str) -> str:
    """Compile one match dict into a SQL boolean predicate.

    Comparisons are case-insensitive (LOWER(col)), matching the R `tolower(...)`/`LOWER(...)`.
    """
    if not isinstance(match, dict) or len(match) != 1:
        raise ValueError(f"each match needs exactly one operator, got: {match!r}")
    (op, val), = match.items()
    name = f"LOWER({name_col})"
    cat = f"LOWER({cat_col})"

    if op == "equals":
        return f"{name} = {_sql_str(str(val).lower())}"
    if op == "like_any":
        return "(" + " OR ".join(f"{name} LIKE {_sql_str(str(p).lower())}" for p in val) + ")"
    if op == "regexp":
        return f"{name} REGEXP {_sql_str(val)}"
    if op == "category_equals":
        return f"{cat} = {_sql_str(str(val).lower())}"
    if op == "is_null":
        return f"{name_col} IS NULL" if val else "FALSE"
    if op == "all_of":
        return "(" + " AND ".join(compile_match(m, name_col, cat_col) for m in val) + ")"
    if op == "any_of":
        return "(" + " OR ".join(compile_match(m, name_col, cat_col) for m in val) + ")"
    if op == "always":
        return "TRUE" if val else "FALSE"
    raise ValueError(f"unknown match operator: {op!r}")


def compile_case(codelist: dict) -> tuple[str, str]:
    """Return (label_case_sql, code_case_sql) for a treatment_categories codelist.

    Order of `categories` is the CASE WHEN order, so first match wins — same as case_when.
    """
    name_col = codelist.get("match_on", {}).get("name_column", "linename")
    cat_col = codelist.get("match_on", {}).get("drug_category_column", "detaileddrugcategory")
    cats = codelist["categories"]
    if not cats:
        raise ValueError("treatment_categories has no categories")

    label_whens, code_whens = [], []
    for c in cats:
        pred = compile_match(c["match"], name_col, cat_col)
        label_whens.append(f"WHEN {pred} THEN {_sql_str(c['label'])}")
        code_whens.append(f"WHEN {pred} THEN {int(c['code'])}")

    label_sql = "CASE " + " ".join(label_whens) + " END"
    code_sql = "CASE " + " ".join(code_whens) + " END"
    return label_sql, code_sql
