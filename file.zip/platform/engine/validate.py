#!/usr/bin/env python3
"""Validate the prostate RWDP config + codelists before a build. Pure Python (no Spark).

Two entry points:
  * problems(cfg, strict=...) -> list[str]   collect issues (lint / tests)
  * check(cfg, strict=True)                  raise RuntimeError on the first build run

`strict=True` (the default for check) treats unfilled REPLACE_ME placeholders as errors, so the
Databricks job fails fast with an actionable message instead of resolving tables like
`REPLACE_ME.t_enh_prostate_REPLACE_ME`.

CLI (lint mode, placeholders allowed):
    python engine/validate.py config/data_product.yaml
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from config import load_config            # noqa: E402
from codelists import compile_case        # noqa: E402

PLACEHOLDER = "REPLACE_ME"
REQUIRED_RUN_KEYS = ["refresh", "source_schema", "output_schema", "output_table"]
# Pack ROLES (file stems) the shared engine requires — tumor-agnostic (pack_id is just a label).
EXPECTED_ROLES = {"demographics", "clinical", "treatment", "outcomes"}
# Source mappings the shared engine genuinely REQUIRES (index/LOT/demographics/follow-up+death).
# Everything else is OPTIONAL — a tumor declares only the sources it has, so heme/COTA products
# without provenge/alphabet/vitals still validate. The engine + preflight handle declared-only.
REQUIRED_SOURCES = {"enhanced", "lot", "demographics", "mortality"}
KNOWN_VENDORS = {"flatiron", "cota"}
KNOWN_TUMOR_CLASSES = {"solid", "heme"}
# Allowed mortality conflict-resolution policies. Keep in sync with engine/stages/clinical.py.
DEATH_CONFLICT_POLICIES = {"most_specific_then_earliest", "earliest", "latest"}
# Banded lists that need exactly one `when: fallthrough` row, else out-of-range values become
# null instead of the intended catch-all (e.g. age "Unknown"/8). (pack ROLE, key-path).
BANDED_LISTS = [
    ("demographics", ("age_bands",)),
    ("clinical", ("vitals", "bmi_bands")),
    ("treatment", ("lot_count_bands",)),
]
# Columns the ported engine dereferences by exact (lower-cased) name, per source. Sources not
# listed are checked for existence only (loaded but not yet read by a ported stage). `enhanced`
# also needs the index-date `of` columns — added dynamically in required_columns().
REQUIRED_COLUMNS = {
    # detaileddrugcategory is NOT here: the delivered data carries the drug category on drug_episode,
    # not LOT (the treatment stage aggregates it per line). Required on drug_episode below, gated on the
    # codelist actually using category_equals.
    "lot": ["patientid", "linename", "linesetting", "startdate", "enddate", "linenumber"],
    "demographics": ["patientid", "birthyear", "race", "ethnicity", "state"],   # state -> regionl
    "baseline_ecog": ["patientid", "ecogdate", "ecogvalue"],
    "visit": ["patientid", "visitdate"],
    "telemed": ["patientid", "visitdate"],
    "orals": ["patientid", "enddate", "startdategranularity"],
    "alphabet": ["patientid", "administrationdate"],
    "provenge": ["patientid", "startdate"],
    "mortality": ["patientid", "dateofdeath"],
}


def problems(cfg, strict: bool = False) -> list[str]:
    out: list[str] = []

    # --- run / output -----------------------------------------------------
    for k in REQUIRED_RUN_KEYS:
        if not cfg.run.get(k):
            out.append(f"run.{k} is missing or empty")
        elif strict and PLACEHOLDER in str(cfg.run.get(k)):
            out.append(f"run.{k} = '{cfg.run.get(k)}' still contains the '{PLACEHOLDER}' "
                       f"placeholder — set a real value before running (prod values like "
                       f"'{PLACEHOLDER}_prod_source' are NOT real schemas)")

    # --- study window -----------------------------------------------------
    for k in ("index_start", "index_end"):
        if not cfg.study.get(k):
            out.append(f"study.{k} is missing")

    # --- cohorts ----------------------------------------------------------
    if not cfg.cohorts:
        out.append("cohorts is empty")
    ids, ns = set(), set()
    for c in cfg.cohorts:
        for f in ("id", "label", "cohortn", "index"):
            if f not in c:
                out.append(f"cohort {c.get('id', '?')} missing '{f}'")
        if c.get("id") in ids:
            out.append(f"duplicate cohort id '{c.get('id')}'")
        ids.add(c.get("id"))
        if c.get("cohortn") in ns:
            out.append(f"duplicate cohortn {c.get('cohortn')}")
        ns.add(c.get("cohortn"))
        idx = c.get("index")
        if idx and idx != "lot_start_date" and idx not in cfg.index_dates:
            out.append(f"cohort {c.get('id')} index '{idx}' not in index_dates and != lot_start_date")
        m = c.get("maintenance")
        if m is not None and not isinstance(m, bool):
            out.append(f"cohort {c.get('id')} maintenance must be true/false, got {m!r}")

    # --- LOT model (config-driven line numbering; defaults reproduce prostate) -------------
    ln = (cfg.raw.get("lot") or {}).get("line_number")
    if ln is not None and ln not in ("new_lot_n", "linenumber"):
        out.append(f"lot.line_number '{ln}' must be 'new_lot_n' or 'linenumber'")

    # --- sources (only the core set is required; the rest are optional per tumor) ----------
    if not cfg.sources:
        out.append("sources is empty")
    else:
        for missing in sorted(REQUIRED_SOURCES - set(cfg.sources)):
            out.append(f"sources is missing required mapping '{missing}'")

    # --- data format / formats overlay (EDM | Panoramic …) --------------------
    fmts = cfg.raw.get("formats") or {}
    if cfg.data_format != "EDM" and cfg.data_format not in fmts:
        out.append(f"data_format '{cfg.data_format}' has no `formats.{cfg.data_format}` overlay — "
                   "it would silently run on the base (EDM) sources")
    for fname, fblk in fmts.items():
        if not isinstance(fblk, dict):
            out.append(f"formats.{fname} must be a mapping")
            continue
        avail = {**(cfg.raw.get("sources") or {}), **(fblk.get("sources") or {})}
        for s in (fblk.get("rename") or {}):
            if s not in avail:
                out.append(f"formats.{fname}.rename references undeclared source '{s}'")

    # --- source_union (optional multi-schema union: EC = Flatiron EDM ∪ Dostar registry) --------
    u = cfg.source_union
    if u is not None:
        members = u.get("members") or []
        if not members:
            out.append("source_union.members is empty")
        for i, m in enumerate(members):
            for f in ("schema", "flag"):
                if not (isinstance(m, dict) and m.get(f)):
                    out.append(f"source_union.members[{i}] missing '{f}'")
            if strict and isinstance(m, dict) and PLACEHOLDER in str(m.get("schema")):
                out.append(f"source_union.members[{i}].schema '{m.get('schema')}' still "
                           f"contains the '{PLACEHOLDER}' placeholder")

    # --- vendor / tumor class --------------------------------------------
    if cfg.vendor not in KNOWN_VENDORS and not cfg.source_layout:
        out.append(f"vendor '{cfg.vendor}' is unknown and no run.source_layout override is set "
                   f"(known vendors: {sorted(KNOWN_VENDORS)})")
    if cfg.tumor_class not in KNOWN_TUMOR_CLASSES:
        out.append(f"tumor_class '{cfg.tumor_class}' not one of {sorted(KNOWN_TUMOR_CLASSES)}")

    # the index-date source must itself be a declared source
    if cfg.index_dates.get("advanced_diagnosis_date") and cfg.index_source not in cfg.sources:
        out.append(f"index source '{cfg.index_source}' "
                   f"(index_dates.advanced_diagnosis_date.source) is not a declared source")

    # --- variable packs (by role / file stem) ----------------------------
    try:
        roles = cfg.roles()
        for missing in sorted(EXPECTED_ROLES - roles):
            out.append(f"variable pack for role '{missing}' not found "
                       f"(expected variables/{missing}.yaml)")
    except Exception as e:  # noqa: BLE001 - surface any load/parse error as a problem
        out.append(f"failed to load variable packs: {e}")

    # --- banded lists need a catch-all -----------------------------------
    out += _bands_problems(cfg)

    # --- clinical categoricals (grade/histology/…): each needs name/column/groups -----------
    try:
        clin_pack = cfg.pack("clinical")
        # clinical.staging.source (when set) must be a declared source — else `stage` is silently
        # dropped at runtime (the stage uses src.get(...)). No source -> the index source.
        ss = (clin_pack.get("staging") or {}).get("source")
        if ss and ss not in cfg.sources:
            out.append(f"clinical.staging.source '{ss}' is not a declared source")
        for i, cat in enumerate(clin_pack.get("categoricals") or []):
            for f in ("name", "column", "groups"):
                if not cat.get(f):
                    out.append(f"clinical.categoricals[{i}] missing '{f}'")
            # An explicit source must be a declared source — a typo (source: enhnaced) would
            # otherwise lint clean, be skipped by required_columns()/preflight, and silently omit
            # the variable at runtime. (No source -> the index source, validated above.)
            cs = cat.get("source")
            if cs and cs not in cfg.sources:
                out.append(f"clinical.categoricals[{i}].source '{cs}' is not a declared source")
        # closest-to-index panels (biomarkers / labs): block + each panel item need their fields
        for blk_key in ("biomarkers", "labs"):
            blk = clin_pack.get(blk_key)
            if not blk:
                continue
            for f in ("source", "name_column", "value_column", "date_column", "panel"):
                if not blk.get(f):
                    out.append(f"clinical.{blk_key} missing '{f}'")
            for i, item in enumerate(blk.get("panel") or []):
                if not item.get("name"):
                    out.append(f"clinical.{blk_key}.panel[{i}] missing 'name'")
                if not item.get("match") and not item.get("match_any"):   # scalar match OR a multi-name set
                    out.append(f"clinical.{blk_key}.panel[{i}] needs 'match' or 'match_any'")
                if not item.get("groups") and not item.get("bands"):
                    out.append(f"clinical.{blk_key}.panel[{i}] needs 'groups' or 'bands'")
            if blk.get("source") and blk["source"] not in cfg.sources:
                out.append(f"clinical.{blk_key}.source '{blk['source']}' is not a declared source")
    except Exception:  # noqa: BLE001 - pack load problems reported elsewhere
        pass

    # --- mortality conflict-resolution policy ----------------------------
    try:
        imp = cfg.pack("clinical").get("death_date_imputation", {})
        cr = imp.get("conflict_resolution")
        if cr is not None and cr not in DEATH_CONFLICT_POLICIES:
            out.append("clinical.death_date_imputation.conflict_resolution "
                       f"'{cr}' not one of {sorted(DEATH_CONFLICT_POLICIES)}")
    except Exception:  # noqa: BLE001 - pack load problems reported elsewhere
        pass

    # --- treatment prior-taxane (optional pre-mCRPC line source) ---------
    try:
        pt = cfg.pack("treatment").get("prior_taxane") or {}
        pre = pt.get("pre_mcrpc_source")
        if pre and pre not in cfg.sources:
            out.append(f"treatment.prior_taxane.pre_mcrpc_source '{pre}' is not a declared source")
    except Exception:  # noqa: BLE001 - pack load problems reported elsewhere
        pass

    # --- outcomes progression / PFS (optional) ---------------------------
    try:
        pcfg = cfg.pack("outcomes").get("progression")
        if pcfg:
            if pcfg.get("source") and pcfg["source"] not in cfg.sources:
                out.append(f"outcomes.progression.source '{pcfg['source']}' is not a declared source")
            for f in ("source", "date_column", "evidence_columns", "pseudoprogression_column"):
                if not pcfg.get(f):
                    out.append(f"outcomes.progression missing '{f}'")
    except Exception:  # noqa: BLE001 - pack load problems reported elsewhere
        pass

    # --- outcomes platinum_sensitivity / PROC (optional: OC) -------------
    try:
        psc = cfg.pack("outcomes").get("platinum_sensitivity")
        if psc:
            if psc.get("source") and psc["source"] not in cfg.sources:
                out.append(f"outcomes.platinum_sensitivity.source '{psc['source']}' is not a declared source")
            for f in ("source", "line_number_column", "name_column", "start_column", "end_column",
                      "platinum_agents"):
                if not psc.get(f):
                    out.append(f"outcomes.platinum_sensitivity missing '{f}'")
    except Exception:  # noqa: BLE001 - pack load problems reported elsewhere
        pass

    # --- derived cohorts (optional: OC PROC split) -----------------------
    try:
        ids = {c.get("id") for c in cfg.cohorts}
        base_ns = {c.get("cohortn") for c in cfg.cohorts}
        for dc in (cfg.raw.get("derived_cohorts") or []):
            for f in ("id", "cohortn", "label", "from", "where"):
                if not dc.get(f):
                    out.append(f"derived_cohorts entry missing '{f}'")
            for frm in (dc.get("from") or []):
                if frm not in ids:
                    out.append(f"derived_cohorts '{dc.get('id')}' from-cohort '{frm}' is not a declared cohort")
            if dc.get("cohortn") in base_ns:
                out.append(f"derived_cohorts '{dc.get('id')}' cohortn {dc.get('cohortn')} collides with a base cohort")
    except Exception:  # noqa: BLE001 - pack load problems reported elsewhere
        pass

    # --- clinical surgery sub-block (optional: OC) -----------------------
    try:
        scfg = cfg.pack("clinical").get("surgery")
        if scfg:
            for s in (scfg.get("source"), scfg.get("line_source", "lot")):
                if s and s not in cfg.sources:
                    out.append(f"clinical.surgery source '{s}' is not a declared source")
            for f in ("source", "surgery_flag_column", "surgery_date_column", "line_start_column",
                      "line_end_column", "pcs_label", "ics_label", "none_label"):
                if not scfg.get(f):
                    out.append(f"clinical.surgery missing '{f}'")
    except Exception:  # noqa: BLE001 - pack load problems reported elsewhere
        pass

    # --- treatment codelist ----------------------------------------------
    out += _codelist_problems(cfg)

    return out


def _bands_problems(cfg) -> list[str]:
    out: list[str] = []
    for role, path in BANDED_LISTS:
        try:
            node = cfg.pack(role)
        except Exception:           # missing pack reported by the roles check
            continue
        for key in path:
            node = node.get(key) if isinstance(node, dict) else None
        if not isinstance(node, list):
            continue
        n = sum(1 for b in node if isinstance(b, dict) and b.get("when") == "fallthrough")
        if n != 1:
            out.append(f"{role}.{'.'.join(path)} needs exactly one 'when: fallthrough' "
                       f"catch-all band, found {n}")
    return out


def _codelist_problems(cfg) -> list[str]:
    out: list[str] = []
    try:
        cl = cfg.codelist("treatment_categories")
    except Exception as e:  # noqa: BLE001
        return [f"failed to load treatment_categories codelist: {e}"]

    cats = cl.get("categories") or []
    if not cats:
        return ["treatment_categories has no categories"]

    codes = []
    catchalls = []
    for i, c in enumerate(cats):
        for f in ("code", "label", "match"):
            if f not in c:
                out.append(f"treatment category #{i} missing '{f}'")
        codes.append(c.get("code"))
        if c.get("match") == {"always": True}:
            catchalls.append(i)
    dup = {x for x in codes if codes.count(x) > 1}
    if dup:
        out.append(f"treatment category codes not unique: {sorted(dup)}")
    if len(catchalls) != 1:
        out.append(f"treatment_categories needs exactly one always-true catch-all, found {len(catchalls)}")
    elif catchalls[0] != len(cats) - 1:
        out.append("the always-true catch-all must be the LAST category (case_when order)")

    try:
        compile_case(cl)   # exercises the match DSL compiler on every entry
    except Exception as e:  # noqa: BLE001
        out.append(f"treatment_categories failed to compile: {e}")
    return out


def check(cfg, strict: bool = True) -> None:
    """Raise RuntimeError listing all problems, or return None if the config is clean."""
    probs = problems(cfg, strict=strict)
    if probs:
        raise RuntimeError("config validation failed:\n  - " + "\n  - ".join(probs))


def required_columns(cfg) -> dict:
    """Per-source required columns for the sources this tumor DECLARES.

    Includes the index-date `of` columns on the CONFIGURED index source (not always `enhanced`),
    and the date columns of any custom follow-up sources (dict-form follow_up_sources), so preflight
    catches a missing column on the right table.
    """
    req = {k: list(v) for k, v in REQUIRED_COLUMNS.items() if k in cfg.sources}

    # A product "uses a line-setting model" if the GLOBAL lot.line_setting is set OR ANY cohort declares
    # its own line_setting — because the treatment/index stages resolve `cohort.line_setting` first and
    # only fall back to the global. So both `lot.linesetting` and the drug_episode aggregation below must
    # gate on this combined condition, not the global alone (else a cohort-setting product with no global
    # would pass preflight while the runtime filters on a `linesetting` column that isn't required).
    uses_line_setting = bool(cfg.lot_line_setting or
                             any(c.get("line_setting") is not None for c in cfg.cohorts))
    # `lot.linesetting` is only read when a line setting is configured (e.g. prostate mCRPC). COTA/heme
    # tumors (DLBCL/CLL/MDS) have no such column and no line setting -> don't require it.
    if "lot" in req and not uses_line_setting and "linesetting" in req["lot"]:
        req["lot"].remove("linesetting")
    # If any cohort filters on the maintenance flag (OC/EC), the LOT table must carry that column.
    if "lot" in req and any(c.get("maintenance") is not None for c in cfg.cohorts):
        mc = cfg.lot_maintenance_column
        if mc and mc not in req["lot"]:
            req["lot"].append(mc)

    def _need(source, cols):
        if source not in cfg.sources:
            return
        req.setdefault(source, ["patientid"])
        for c in cols:
            if c and c not in req[source]:
                req[source].append(c)

    # index date is built on cfg.index_source from EACH index_dates model's `of` columns — require ALL
    # of them (not just advanced_diagnosis_date) so a column a cohort indexes off (e.g. the mHSPC
    # cohort's hspc_diagnosis_date -> hspcdate) that is missing/typoed fails preflight, instead of
    # sources.load silently materializing the model from whatever `of` columns happen to be present.
    for _rule in (cfg.index_dates or {}).values():
        if isinstance(_rule, dict):
            _need(_rule.get("source", cfg.index_source), ["patientid"] + list(_rule.get("of", [])))

    # custom follow-up sources (dict form) declare their own date column AND any columns their
    # filter SQL references (filter_columns) -> require all of them, so a filter can't reference a
    # column that passes preflight then fails at runtime in F.expr().
    try:
        fus = cfg.pack("clinical").get("death_date_imputation", {}).get("follow_up_sources")
        if fus and isinstance(fus[0], dict):
            for s in fus:
                _need(s.get("source"), [s.get("date_column")] + list(s.get("filter_columns") or []))
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # clinical sub-blocks dereference specific source columns — require them so a typo'd/absent
    # column fails preflight up front, not deep inside a Spark stage (categoricals would otherwise
    # silently skip; biomarker/lab panels would fail at runtime).
    try:
        cp = cfg.pack("clinical")
        st = cp.get("staging")        # `stage` is grouped from `groupstage`; require it so a source
        if st and st.get("groups"):   # lacking groupstage fails preflight instead of dropping `stage`.
            _need(st.get("source", cfg.index_source), ["groupstage"])
        for cat in cp.get("categoricals") or []:
            _need(cat.get("source", cfg.index_source), [cat.get("column"), cat.get("date_column")])
        for blk_key in ("biomarkers", "labs", "lab_values"):     # all closest-to-index panels (name/value/date)
            blk = cp.get(blk_key)
            if blk:
                # unit_column is only dereferenced when an item declares `units` to filter on.
                unit_col = blk.get("unit_column") if any(
                    it.get("units") for it in (blk.get("panel") or [])) else None
                _need(blk.get("source"), [blk.get("name_column"), blk.get("value_column"),
                                          blk.get("date_column"), unit_col])
        ms = cp.get("metastatic_sites")     # per-site flags from a SiteOfMetastasis/DateOfMetastasis table
        if ms:
            _need(ms.get("source"), [ms.get("site_column"), ms.get("date_column")])
        psa = cp.get("psa_timepoints")      # windowed PSA values from a value/date table
        if psa:
            _need(psa.get("source"), [psa.get("value_column"), psa.get("date_column")])
        if cp.get("vitals") and "vitals" in cfg.sources:   # BMI/BSA reads test/units/result/dates
            _need("vitals", ["test", "testunitscleaned", "testresultcleaned", "testdate", "resultdate"])
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # demographics.practice_map reads `practicetype` from the practice source; demographics.ses reads its
    # source_column from the ses source — both source-gated (the stage uses src.get / "in src").
    try:
        dem = cfg.pack("demographics")
        if dem.get("practice_map") and "practice" in cfg.sources:
            _need("practice", ["practicetype"])
        ses = dem.get("ses") or {}
        if ses.get("source_column") and "ses" in cfg.sources:
            _need("ses", [ses["source_column"]])
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # outcomes.line_outcomes (vis120) reads a date column from each DECLARED visit source. Visit
    # sources are OPTIONAL (vis120 degrades to 0 when absent), so _need skips undeclared ones —
    # but a declared visit source must expose the configured date column.
    try:
        lo = cfg.pack("outcomes").get("line_outcomes")
        if lo:
            vdate = lo.get("visit_date_column", "visitdate")
            for s in (lo.get("visit_sources") or []):
                _need(s, [vdate])
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # treatment.prior_taxane.pre_mcrpc_source (when set + declared) is read for linename/startdate.
    try:
        pt = cfg.pack("treatment").get("prior_taxane") or {}
        _need(pt.get("pre_mcrpc_source"), ["linename", "startdate"])
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # drug_episode powers lot{i}ed (each line's last-activity date). The treatment stage falls back to
    # the line enddate when its columns are absent — harmless UNLESS the line outcomes consume lot{i}ed
    # (vis120/TTD/TTNT), where a silent fallback would shift results. So require its key columns only
    # when drug_episode is declared AND outcomes.line_outcomes is enabled (catches the prostate case
    # without forcing the columns on COTA/other tumors that declare drug_episode but don't use it).
    # `linesetting` too when a setting model is used, since the aggregate that feeds lot{i}ed is filtered
    # to the cohort's setting (without the column it would silently combine episode dates across settings).
    try:
        if "drug_episode" in cfg.sources and cfg.pack("outcomes").get("line_outcomes"):
            _need("drug_episode", ["linenumber", "episodedate"] +
                  (["linesetting"] if uses_line_setting else []))
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # The per-line category classifier (lotcatn) detects "Other chemotherapy-containing" via the
    # codelist's category_equals, which reads the drug-category column. That column lives on drug_episode
    # in the delivered data (the treatment stage filters drug_episode to the cohort's setting, then
    # aggregates a per-line chemo indicator by patient+linenumber). So require it — plus linesetting to
    # scope the filter (only when a setting model is used), and episodedate because the runtime only
    # BUILDS that per-line aggregate when episodedate is present
    # (without it the category would silently fall to NULL) — only when drug_episode is declared AND the
    # treatment codelist actually uses category_equals (so a tumor whose classifier never references the
    # drug category isn't forced to carry it).
    def _uses_category_equals(m):
        if not isinstance(m, dict):
            return False
        if "category_equals" in m:
            return True
        return any(_uses_category_equals(sub) for k in ("all_of", "any_of") for sub in (m.get(k) or []))

    try:
        if "drug_episode" in cfg.sources:
            cl = cfg.codelist("treatment_categories") or {}
            if any(_uses_category_equals(c.get("match")) for c in cl.get("categories", [])):
                cat_col = (cl.get("match_on") or {}).get("drug_category_column", "detaileddrugcategory")
                need = ["linenumber", "episodedate", cat_col]
                # linesetting is only read when a line-setting model is configured (the treatment stage
                # filters drug_episode to the cohort's setting). Products with no line setting (heme/COTA)
                # aggregate on patient+linenumber and must NOT be forced to carry linesetting — use the
                # combined global-or-cohort gate (the same one lot.linesetting uses above).
                if uses_line_setting:
                    need.append("linesetting")
                _need("drug_episode", need)
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # outcomes.progression (PFS) reads the progression date, the evidence flags, and the
    # pseudo-progression column from its declared source.
    try:
        pcfg = cfg.pack("outcomes").get("progression")
        if pcfg:
            _need(pcfg.get("source"), [pcfg.get("date_column"), pcfg.get("pseudoprogression_column")]
                  + list(pcfg.get("evidence_columns") or []))
            cc = pcfg.get("censor")          # rwPFS censor (LASTCLINICNOTEDATE) source/date column
            if cc:
                _need(cc.get("source"), [cc.get("date_column")])
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # outcomes.platinum_sensitivity reads the line number / name / start / end from its source (lot).
    try:
        psc = cfg.pack("outcomes").get("platinum_sensitivity")
        if psc:
            _need(psc.get("source"), [psc.get("line_number_column"), psc.get("name_column"),
                                      psc.get("start_column"), psc.get("end_column")])
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # clinical.surgery reads the surgery flag/date from its source + the 1L line start/end.
    try:
        scfg = cfg.pack("clinical").get("surgery")
        if scfg:
            _need(scfg.get("source"), [scfg.get("surgery_flag_column"), scfg.get("surgery_date_column")])
            _need(scfg.get("line_source", "lot"), [scfg.get("line_number_column", "linenumber"),
                  scfg.get("line_start_column"), scfg.get("line_end_column")])
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # clinical.min_avail_date: the runtime consumes EVERY configured base column and date column that
    # exists (least-of-present), so require them all on their declared sources -> a typo fails preflight
    # instead of silently shifting the floor. _need skips undeclared sources, so a refresh legitimately
    # missing one stays graceful (configs list only real columns, so no `optional` metadata is needed).
    try:
        mblk = cfg.pack("clinical").get("min_avail_date") or {}
        _need(cfg.index_source, list(mblk.get("base_columns") or []))
        for s in (mblk.get("sources") or []):
            _need(s.get("source"), list(s.get("date_columns") or [s.get("date_column")]))
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass

    # clinical.passthrough: every aliased column and every flag's source column is dereferenced, so a
    # typo would otherwise be silently skipped -> require them all on the pass-through source. EXCEPT
    # columns/flags marked `optional: true` (genuinely feed-dependent, e.g. PSA-at-diagnosis): the engine
    # already skips those gracefully when absent, so preflight must not hard-require them (it would
    # contradict the graceful contract and fail a legitimate cut that simply lacks the column).
    try:
        pblk = cfg.pack("clinical").get("passthrough") or {}
        cols = [c.get("column") for c in (pblk.get("columns") or []) if not c.get("optional")]
        cols += [f.get("from") for f in (pblk.get("flags") or []) if not f.get("optional")]
        _need(pblk.get("source") or cfg.index_source, cols)
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass
    return req


def emitted_variables(cfg) -> set:
    """The label-level variable codes a tumor's packs emit (excluding the parallel -n code columns,
    which the catalog documents via their label, like stage/stagen). Covers demographics / ECOG / BMI /
    staging / categoricals / biomarker+lab panels / passthrough / surgery / min_avail / cohort
    provenance / outcomes `emits`. Used to assert the master catalog documents every emitted variable
    per tumor (cross-tumor completeness — tests/test_catalog.py)."""
    # always emitted: cohort/cohortu/stamps by assemble, advanceddiagnosisdate (setting diagnosis anchor)
    # by the index stage. Enumerating it here makes the catalog-completeness test cover it too.
    em: set = {"cohort", "cohortu", "data_product_id", "data_refresh", "spec_version", "advanceddiagnosisdate"}
    try:
        dem = cfg.pack("demographics")
        for block, name in (("age_bands", "agegrl"), ("regions", "regionl"), ("race_map", "race"),
                            ("ethnicity_map", "eth")):
            if dem.get(block):
                em.add(name)
        if dem.get("age_bands"):
            em.add("age")
        # SOURCE-aware: practic/ses are emitted only when their (optional) source is declared — so the
        # guard matches what the stage actually emits, not what a pack block merely mentions (e.g. a
        # heme scaffold may carry a ses block but no ses source).
        if dem.get("practice_map") and "practice" in cfg.sources:
            em.add("practic")
        if dem.get("ses") and "ses" in cfg.sources:
            em.add("ses")
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass
    try:
        clin = cfg.pack("clinical")
        em.add("ecog")                                  # always emitted (baseline_ecog or Missing)
        if clin.get("vitals") and "vitals" in cfg.sources:
            em.add("bmi")
            if clin["vitals"].get("bsa_formula"):
                em.add("bsa")
        if clin.get("staging"):
            em.add("stage")
        for c in clin.get("categoricals") or []:
            em.add(c.get("name"))
        for blk in ("biomarkers", "labs"):
            for it in (clin.get(blk) or {}).get("panel") or []:
                em.add(it.get("name"))
        pt = clin.get("passthrough") or {}
        for c in pt.get("columns") or []:
            em.add(c.get("as", c.get("column")))
        for f in pt.get("flags") or []:
            em.add(f.get("name"))
        s = clin.get("surgery")
        if s:
            em |= {"issurg", "surg", "neoadj", "tt_first_tx_diag"}
            if s.get("size_column"):
                em.add(s["size_column"])
        for it in (clin.get("metastatic_sites") or {}).get("sites") or []:
            em.add(it.get("name"))                          # hepatic_met / lung_met / … presence flags
        for it in (clin.get("lab_values") or {}).get("panel") or []:
            nm = it.get("name")
            if nm:
                em |= {nm, nm + "v", nm + "dt"}             # present flag + numeric value + date (all cataloged)
        psa = clin.get("psa_timepoints") or {}
        for p in psa.get("points") or []:
            em.add(p.get("name"))                           # psa_index / psa6mo / psa12mo
        for pt in (psa.get("response") or {}).get("points") or []:
            em.add(pt.get("psa50")); em.add(pt.get("undetectable"))   # psa50_6mo / psal6mo / …
        for it in (clin.get("durations") or {}).get("items") or []:
            em.add(it.get("name"))                          # generic durations (if a tumor configures them)
        for it in clin.get("derived") or []:
            em.add(it.get("name"))                          # INDEXYR / INITYR / MCRPCDDYR / PINDDUR / FUDUR / …
        mcw = clin.get("mcrpc_window")                      # mCRPC index-window flag + MCRPCDD date
        if mcw:
            em.add(mcw.get("flag_as", "mcrpc")); em.add(mcw.get("date_as", "mcrpcdd"))
        if clin.get("min_avail_date"):
            em |= {"minavaildate", "basedur"}
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass
    try:
        trt = cfg.pack("treatment")
        from .stages import treatment as _t                 # per-line lot{i}* family (template-documented)
        em |= set(_t.emitted_line_columns(cfg))
        for fl in (trt.get("prior_treatments") or {}).get("flags") or []:
            em.add(fl.get("name"))                          # prior_pluvicto / prior_parp / …
        for fl in (trt.get("conmed_exposures") or {}).get("flags") or []:
            em.add(fl.get("name"))                          # conmed_bp / conmed_csf / conmed_steroid
        pt = trt.get("prior_taxane") or {}                  # cohort-aware prior-taxane flags
        if pt:
            em.add("prior_tax_mcrpc")                       # always emitted when prior_taxane is configured
            if pt.get("pre_mcrpc_source") in cfg.sources:   # optional: only when pre-mCRPC source declared
                em.add("prior_tax_pre_mcrpc")
        slc = trt.get("setting_line_columns") or {}         # lot{i}{sd|name}_{setting} per setting
        for s in slc.get("settings") or []:
            for i in range(1, int(slc.get("lines", 2)) + 1):
                for a in slc.get("attributes", ["sd", "name"]):
                    em.add(f"lot{i}{a}_{str(s).lower()}")
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass
    try:
        em |= set(cfg.pack("outcomes").get("emits") or [])
    except Exception:  # noqa: BLE001 - pack problems reported elsewhere
        pass
    em.discard(None)
    return em


def preflight(spark, cfg, _table_reader=None) -> bool:
    """Spark preflight: every DECLARED source TABLE resolves and has its required COLUMNS.

    Run on the cluster before build() so a missing table/column fails fast with a clear list
    instead of deep inside a Spark stage. `_table_reader(fqn) -> list[col]` is injectable for
    unit tests; by default it reads `spark.table(fqn).columns`. Only declared sources are checked.
    """
    read = _table_reader or (lambda fqn: spark.table(fqn).columns)
    req = required_columns(cfg)
    problems: list[str] = []
    for name in sorted(cfg.sources):
        # Under a non-EDM data format, columns arrive with PHYSICAL names that source load renames to the
        # required LOGICAL names — so a required logical column is satisfied by its physical name too.
        phys_for = {lo.lower(): ph.lower() for ph, lo in (cfg.source_renames.get(name) or {}).items()}
        for fqn in cfg.source_fqns(name):        # 1 normally; one per member schema under a source_union
            try:
                cols = {c.lower() for c in read(fqn)}
            except Exception as e:  # noqa: BLE001 - any read failure is a preflight problem
                problems.append(f"source '{name}' table {fqn} not readable: {e}")
                continue
            for c in req.get(name, ["patientid"]):
                cl = c.lower()
                if cl not in cols and phys_for.get(cl) not in cols:
                    problems.append(f"source '{name}' table {fqn} missing column '{c}'")
    if problems:
        raise RuntimeError("source preflight failed:\n  - " + "\n  - ".join(problems))
    return True


def main(argv):
    if len(argv) != 2:
        print("usage: python engine/validate.py <path-to-data_product.yaml>")
        return 2
    cfg = load_config(argv[1])
    probs = problems(cfg, strict=False)   # lint mode: REPLACE_ME placeholders allowed
    if probs:
        print(f"{len(probs)} problem(s):")
        for p in probs:
            print(f"  - {p}")
        return 1
    print("config OK (lint mode — REPLACE_ME placeholders allowed)")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
