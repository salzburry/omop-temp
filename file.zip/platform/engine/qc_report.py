"""Render a human-readable QC report (markdown) for a refresh.

Takes the run_qc() report + qc_gate() decision + golden summary + refresh manifest and produces a
sign-off-ready report. Pure Python — the runner prints it (job log) and it can be saved next to the
refresh manifest. Keeps QC auditable per refresh.
"""
from __future__ import annotations


def _rate_table(title, d, hdr):
    if not d:
        return []
    out = [f"## {title}", "", f"| {hdr} | rate |", "|---|---|"]
    out += [f"| {k} | {v} |" for k, v in d.items()]
    return out + [""]


def render(report: dict, gate: dict, golden: dict | None = None, manifest: dict | None = None) -> str:
    m = manifest or {}
    L = [f"# QC report — {m.get('tumor', '?')} {m.get('refresh', report.get('refresh', '?'))}", ""]
    L += [f"- spec_version: {m.get('spec_version', report.get('version', ''))}",
          f"- git_commit: {m.get('git_commit', '') or ''}",
          f"- built_at: {m.get('built_at', '')}",
          f"- output_table: {m.get('output_table', '')}", ""]

    L += [f"## QC gate: {'PASS' if gate.get('passed') else 'FAIL'}", ""]
    if gate.get("failures"):
        L += ["Failures:"] + [f"- {f}" for f in gate["failures"]] + [""]

    L += ["## Counts", "", f"- total rows: {report.get('n_rows', '?')}", ""]
    coh = report.get("cohorts") or {}
    if coh:
        L += ["| cohort | n |", "|---|---|"] + [f"| {k} | {v} |" for k, v in coh.items()] + [""]

    L += _rate_table("Treatment catch-all rate (taxonomy gaps)", report.get("catchall_rate"), "lot column")
    if report.get("stage_check_rate") is not None:
        L += ["## Unmapped-stage rate", "", f"stage == 'CHECK': {report['stage_check_rate']}", ""]
    L += _rate_table("Uncastable-date rate", report.get("uncastable_date_rate"), "date column")
    L += _rate_table("Null rate (non-zero columns)", report.get("null_rate"), "column")

    if golden and golden.get("reference") not in (None, "none"):
        L += [f"## Golden comparison vs `{golden['reference']}`", "",
              "```", str(golden.get("summary", {}))[:2000], "```", ""]

    L += ["## Sign-off", "", "- QC reviewer: __________  date: ______",
          "- Released by:  __________  date: ______", ""]
    return "\n".join(L)
