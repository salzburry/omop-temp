"""Dashboard manifest exporter — the generated CONTRACT a dashboard reads instead of hard-coding.

A dashboard should get the analysis-dataset VALUES from the ADS and everything else — labels, types,
value sets, units, and time-to-event pairings — from this manifest, so a spec change flows to the
dashboard without a code change (the same single-source-of-truth idea as the data dictionary).

Built from the master catalog (labels/category/applies_to, filtered to the tumor) enriched with the
value sets the variable packs already declare (demographics maps, staging, categoricals, biomarker/lab
panels) and a small type model. Pure Python (no Spark) — `render_json()` writes the artifact.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone

try:
    from .dictionary import _applies          # tumor applicability (reused so behaviour matches the dict)
except ImportError:                            # pragma: no cover - script/relative import fallback
    from dictionary import _applies

# Time-to-event metric -> its companion event flag (so the dashboard can render a KM/curve correctly).
TIME_TO_EVENT = {"os": "dthfl", "pfs": "pfsfl", "pfs2": "pfs2fl", "ttnt": "ttntfl", "ttd": "trtdis",
                 "tsst": "tsstfl"}
# Continuous numerics that aren't time-to-event.
NUMERIC = {"age", "bmi", "lotn", "pfi", "basedur", "tt_first_tx_diag", "sizeofresidualdisease",
           "psadiag_init", "psadiag_met"}
# 0/1 (or yes/no) flags whose names don't end in 'fl'/'_flag'.
FLAGS = {"id3mosfu", "pcycled", "mcrpc", "vis120", "trtdis", "neoadj"}


def _value_sets(cfg) -> dict:
    """{code: [labels]} for the categorical variables whose value set the packs already declare —
    demographics crosswalks, staging, clinical categoricals, and biomarker/lab panels."""
    vs: dict = {}

    def _labels(groups):
        return [g["label"] for g in (groups or []) if isinstance(g, dict) and g.get("label")]

    try:
        dem = cfg.pack("demographics")
        for block, code in (("age_bands", "agegrl"), ("regions", "regionl"), ("race_map", "race"),
                            ("ethnicity_map", "eth"), ("practice_map", "practic")):
            lab = _labels(dem.get(block))
            if lab:
                vs[code] = lab
    except Exception:  # noqa: BLE001 - pack problems reported by the validator
        pass
    try:
        clin = cfg.pack("clinical")
        ec = clin.get("baseline_ecog") or {}
        if ec.get("value_codes"):     # baseline ECOG is categorical (0..4 / Unknown / Missing)
            vs["ecog"] = list(ec["value_codes"].keys()) + [ec.get("missing_label", "Missing")]
        st = clin.get("staging") or {}
        if _labels(st.get("groups")):
            vs["stage"] = _labels(st["groups"])
        for cat in clin.get("categoricals") or []:
            if cat.get("name") and _labels(cat.get("groups")):
                vs[cat["name"]] = _labels(cat["groups"])
        for blk in ("biomarkers", "labs"):
            for it in (clin.get(blk) or {}).get("panel") or []:
                lab = _labels(it.get("groups") or it.get("bands"))
                if it.get("name") and lab:
                    vs[it["name"]] = lab
        lv = clin.get("lab_values") or {}            # prostate labs -> Present /(Unknown)/ Missing categorical
        if lv.get("panel"):
            pm = ([lv.get("present_label", "Present")]
                  + ([lv["unknown_label"]] if lv.get("unknown_label") else [])
                  + [lv.get("missing_label", "Missing")])
            for it in lv["panel"]:
                if it.get("name"):
                    vs[it["name"]] = pm
        for c in (clin.get("passthrough") or {}).get("columns") or []:
            lab = _labels(c.get("bands"))            # categorized pass-through (e.g. gleason_cat) -> bands
            if c.get("as") and lab:
                vs[c["as"]] = lab
    except Exception:  # noqa: BLE001
        pass
    # Cohort label sets: the cohort list + the per-setting treated/untreated (COHORTU) labels.
    try:
        clabels = [c.get("label") for c in cfg.cohorts if c.get("label")]
        if clabels:
            vs["cohort"] = list(dict.fromkeys(clabels))
        bs = (cfg.raw.get("treatment_status") or {}).get("by_setting") or {}
        ulabels: list = []
        for s in bs.values():
            for k in ("untreated_label", "treated_label"):
                if s.get(k) and s[k] not in ulabels:
                    ulabels.append(s[k])
        if ulabels:
            vs["cohortu"] = ulabels
    except Exception:  # noqa: BLE001
        pass
    # Line-of-therapy category (lotcat / per-line lot{i}cat): value set = the treatment codelist's
    # ordered category labels (the 17-way lotcat classifier), so the category renders as categorical.
    try:
        clname = cfg.pack("treatment").get("line_category_codelist")
        cats = cfg.codelist(clname).get("categories") if clname else None
        labs = [c["label"] for c in (cats or []) if c.get("label")]
        if labs:
            vs["lotcat"] = labs
    except Exception:  # noqa: BLE001
        pass
    return vs


def _vtype(code: str, value_sets: dict, explicit: str | None = None) -> str:
    if explicit:                       # an explicit catalog `type:` wins over the naming heuristics
        return explicit
    if code in value_sets:
        return "categorical"
    if code in TIME_TO_EVENT:
        return "time_to_event"
    if code.endswith("fl") or code.endswith("_flag") or code in FLAGS:
        return "flag"
    if code.endswith("dt") or code.endswith("date"):
        return "date"
    if code in NUMERIC:
        return "numeric"
    return "string"


def build_manifest(cfg, catalog: dict, tumor: str, dashboard: dict | None = None,
                   stats: dict | None = None, columns=None) -> dict:
    """The dashboard manifest for one tumor: product metadata + per-variable contract + panel layout.

    `dashboard` is the (optional) panel layout (dashboard/dashboard_vars.yaml); `stats` is an optional
    {code: {...}} of observed values/percentages from the ADS. `columns` (the ACTUAL built-ADS columns,
    passed by the runner) restricts the manifest to what is genuinely emitted — so a catalog-applicable
    but source-absent variable (e.g. DLBCL `stage`/`bmi`) is NOT advertised. Without it the manifest is
    catalog-applicability based (the static/test view).
    """
    vs = _value_sets(cfg)
    allowed = {c.lower() for c in columns} if columns is not None else None
    variables = []
    for v in catalog.get("variables", []):
        code = v.get("code")
        if v.get("line_template"):     # per-line family doc row (lotN/…); not a single dashboard variable
            continue
        if not _applies(v, tumor):
            continue
        if allowed is not None and code.lower() not in allowed:   # not actually emitted in this ADS
            continue
        entry = {"code": code, "label": v.get("label"), "category": v.get("category"),
                 "type": _vtype(code, vs, v.get("type"))}
        if code in vs:
            entry["values"] = vs[code]
        if code in TIME_TO_EVENT:
            entry["unit"] = "months"
            entry["event_flag"] = TIME_TO_EVENT[code]
        if stats and code in stats:
            entry["stats"] = stats[code]
        variables.append(entry)

    cataloged = {e["code"] for e in variables}
    panels = []
    for p in (dashboard or {}).get("panels", []):
        # keep only variables the manifest actually carries for this tumor (so the layout can't point
        # at a code that isn't applicable/cataloged here)
        keep = [c for c in p.get("variables", []) if c in cataloged]
        panels.append({**{k: p[k] for k in ("id", "title") if k in p}, "variables": keep})

    return {"dashboard_id": (dashboard or {}).get("dashboard_id", "rwdp_dashboard"),
            "tumor": tumor, "spec_version": cfg.spec_version, "refresh": cfg.refresh,
            "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "summary": {"n_variables": len(variables),
                        "categories": sorted({e["category"] for e in variables if e.get("category")})},
            "variables": variables, "panels": panels}


def render_json(manifest: dict) -> str:
    return json.dumps(manifest, indent=2, default=str)
