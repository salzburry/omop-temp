# RWDP shared engine (`platform/`)

The **locked, tumor-agnostic engine** every tumor RWDP runs on. Code lives here; behaviour lives
in each tumor's config pack under `../products/`. Adding a tumor (OC, EC, HNSCC, GIST, …) is
**config only — no engine change.**

## Layout

```
platform/
  VERSION                 the engine SemVer a product pins (governance/VERSIONING.md)
  engine/                 locked PySpark, shared by every tumor
    config.py             load a tumor's data_product.yaml + dotted overrides   (pure Python)
    codelists.py          compile a treatment codelist -> Spark SQL CASE         (pure Python)
    validate.py           config validator + Spark source preflight             (pure Python)
    build_ads.py          orchestrator: per cohort build -> assemble -> union
    stages/               sources · lot · index · demographics · clinical · treatment · outcomes · assemble
  engine-r/               side-by-side R (sparklyr/dbplyr) engine — compiles byte-identical codelist/derivation SQL to PySpark (checked in CI r-parity); stage dataflow mirrored by convention
  databricks/run_rwdp.py  generic notebook entry point (any tumor via config_path)
  tests/                  engine tests, run against the reference tumor (prostate) + the registry
  TUMOR_TEMPLATE/         copy-me skeleton for a new tumor
  requirements.txt
../databricks.yml         ONE Asset Bundle (repo root), parameterised by `tumor_slug`
../products/registry.yaml the list of tumors the framework knows about
```

Each tumor is a folder under `../products/oncology/` (`prostate/`, `oc/`, `endometrial/`, …)
containing only `config/`, `variables/`, `codelists/`. The engine resolves everything from the
config: source tables (`{source_schema}.<stem>_<refresh>`), cohorts, index rule, the 4 variable
packs, and the treatment codelist.

## Vendors & tumor classes

Tumors come from different vendors with different table layouts, handled by `engine/vendors.py`:
- **Flatiron** (solid: NSCLC, SCLC, mCRC, OC, EC, mCRPC) — `{schema}.{stem}_{refresh}`.
- **COTA** (heme: DLBCL, CLL, MDS) — different schema; `run.source_layout` overrides if needed.

Config declares `vendor:` and `tumor_class:` (solid | heme). `cfg.table()` resolves names per
vendor; the LOT filter is config-driven (`lot.line_setting`, e.g. mCRPC for prostate, omitted
elsewhere); and **sources are optional** — a tumor declares only the tables it has, so heme/COTA
products without `provenge`/`alphabet`/`vitals` validate and run.

## The framework contract

Every tumor config must provide (the validator enforces it):
- `run.{refresh, source_schema, output_schema, output_table}`, `study.{index_start, index_end}`,
  a known `vendor` (or `run.source_layout`), and a `tumor_class` of solid|heme
- `sources:` for at least the REQUIRED core (`enhanced`, `lot`, `demographics`, `mortality`);
  other sources are optional and checked only if declared (see `validate.REQUIRED_SOURCES`).
  Absent optional sources are genuinely handled: follow-up uses only present sources (and accepts a
  full `follow_up_sources` override), and `baseline_ecog` degrades to the configured Missing value.
  Don't map an absent source to an unrelated table — OMIT it.
- the index date can be sourced from any declared table via
  `index_dates.advanced_diagnosis_date.source` (default `enhanced`; heme indexes off `diagnosis`).
  The treated/untreated flag is derived from the SAME normalized LOT model the index/treatment
  stages use (line setting + `lot.exclude_settings` + `lot.line_number`), minus the cohort-specific
  maintenance filter — so a line a cohort excludes never labels a patient "Treated".
- 4 variable packs by ROLE — `variables/{demographics,clinical,treatment,outcomes}.yaml`
  (pack_id is a free label) — with the keys the engine reads (age bands incl. a `when: fallthrough`,
  ECOG window, BMI bands, death-date imputation incl. a valid `conflict_resolution`, etc.)
- a `treatment_categories` codelist ending in an `always: true` catch-all

## Add a tumor — recipe

1. `cp -r platform/TUMOR_TEMPLATE products/oncology/<slug>/<YYYYMM>` (e.g. `oc/202606`) — packs are
   SPEC-VERSIONED (`products/oncology/<slug>/<spec_version>/config/...`), so the copy goes in a `YYYYMM`
   folder, NOT the product root. (Or copy an existing version and edit.)
2. Fill in `<YYYYMM>/config/data_product.yaml` (source stems, index rule, cohorts, output table) and the
   tumor-specific parts of `variables/clinical.yaml` (staging), `variables/treatment.yaml`
   (prior-therapy flags) and `codelists/treatment_categories.yaml` (the line taxonomy).
   Demographics / ECOG / vitals / outcomes defaults are tumor-agnostic — usually leave them.
3. Add the tumor to `../products/registry.yaml` with `current_spec_version: <YYYYMM>` matching the folder
   (`status: scaffold` while WIP, then `active` = the current supported/default pack — NOT a validation claim; release-readiness is gated separately) — the resolver reads it to find the pack.
4. Lint:  `python3 platform/engine/validate.py products/oncology/<slug>/<YYYYMM>/config/data_product.yaml`
5. Run:   `databricks bundle run rwdp_build --var tumor_slug=<slug> --var refresh=<cut> \
             --var source_schema=... --var output_schema=...`

> **Or run it on the R engine (side-by-side validation).** The same config also drives the R engine
> (`engine-r/`) — same YAML in, same ADS out — for the R-proficient team. It's a *validation* path, not
> the governed lifecycle: it writes directly, so target a **separate `_r` schema** and then
> golden-compare against the Python ADS. From a Spark-connected R session (Databricks, or
> Domino→Databricks via sparklyr):
> ```bash
> Rscript platform/engine-r/run_rwdp.R --allow_direct_write=true \
>   --config_path=products/oncology/<slug>/<YYYYMM>/config/data_product.yaml \
>   --refresh=<cut> --source_schema=... --output_schema=..._r
> ```
> `--allow_direct_write=true` is required (fail-closed). Full Domino→Databricks options: `engine-r/README.md`.

## Run the tests (no Spark / cluster needed)

```bash
pip install -r platform/requirements.txt     # PyYAML (required even for the pure-Python tests)
python3 platform/tests/test_config.py         # engine vs the reference tumor (prostate)
python3 platform/tests/test_validate.py       # validator + source preflight
python3 platform/tests/test_registry.py       # every configured tumor's config lints clean
python3 platform/tests/test_vendors.py        # vendor resolution + vendor-aware config
python3 platform/tests/test_catalog.py        # master catalog <-> registry <-> dashboard
python3 platform/tests/test_r_parity.py        # Python≡R compiler parity (skips if Rscript absent)
python3 platform/tests/test_qc_golden.py       # QC + golden-comparison cores
# Spark-only (skip without PySpark; run on a cluster):
python3 platform/tests/test_stages_spark.py   # per-stage Spark tests
python3 platform/tests/test_smoke_spark.py    # builds the ADS for EVERY tumor on synthetic data
```
