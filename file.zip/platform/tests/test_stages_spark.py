"""Spark in-memory tests for the engine stages.

Run on a Spark runtime (Databricks, or anywhere pyspark is installed):

    python3 tests/test_stages_spark.py      # skips cleanly if pyspark is unavailable

NOTE: these could NOT be executed in the authoring sandbox (pyspark would not build there),
so they are verified by review only — run them on a Spark runtime before relying on them.

Covers the behaviours called out in review: the treated/untreated split, deterministic
new_lot_n (incl. start-date ties), index windowing, treatment categorisation, and the
spec-version stamp.
"""
import sys
from datetime import date
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent   # _framework/ (the shared engine lives here)
sys.path.insert(0, str(FRAMEWORK))

try:
    from pyspark.sql import SparkSession
except Exception:                       # pyspark not installed -> tests skip
    SparkSession = None

# Stage modules import without pyspark OR pyyaml (spark imports are lazy; no yaml at module load).
# engine.config (which needs pyyaml) is imported lazily in _cfg() so this file imports cleanly in
# a runtime that has neither, and reaches the pyspark skip instead of a ModuleNotFoundError.
from engine.stages import lot as lot_stage, index as index_stage          # noqa: E402
from engine.stages import treatment as treatment_stage, assemble as assemble_stage  # noqa: E402
from engine.stages import clinical as clinical_stage, outcomes as outcomes_stage    # noqa: E402
from engine.stages import proc as proc_stage                                        # noqa: E402
from engine.config import product_config, product_dir                               # noqa: E402

try:                                    # proper pytest skip when pytest is driving
    import pytest
    pytestmark = pytest.mark.skipif(SparkSession is None, reason="pyspark not installed")
except Exception:
    pytest = None

CONFIG = product_config(FRAMEWORK.parent / "products", "prostate")   # reference tumor
GOOD = {"run.refresh": "2026q1", "run.source_schema": "rwd", "run.output_schema": "out"}
_SPARK = None


def _spark():
    global _SPARK
    if _SPARK is None:
        _SPARK = (SparkSession.builder.master("local[1]").appName("prostate-tests")
                  .config("spark.sql.shuffle.partitions", "1").getOrCreate())
    return _SPARK


def _cfg():
    from engine.config import load_config        # deferred: needs pyyaml
    return load_config(CONFIG, overrides=GOOD)


def test_lot_normalized_mcrpc_only_and_deterministic():
    if SparkSession is None:
        return
    lot = _spark().createDataFrame([
        ("p1", "Abiraterone", "mCRPC", date(2020, 1, 1), 1, date(2020, 6, 1)),
        ("p1", "Docetaxel",   "mCRPC", date(2020, 1, 1), 2, date(2020, 9, 1)),  # tie on startdate
        ("p1", "ADT",         "HSPC",  date(2019, 1, 1), 1, date(2019, 6, 1)),  # non-mCRPC dropped
    ], ["patientid", "linename", "linesetting", "startdate", "linenumber", "enddate"])
    rows = lot_stage.normalized({"lot": lot}, line_setting="mCRPC").collect()   # config-driven filter
    assert all(r["linesetting"] == "mCRPC" for r in rows)            # HSPC dropped
    by_n = {r["new_lot_n"]: r["linename"] for r in rows}
    assert by_n[1] == "abiraterone" and by_n[2] == "docetaxel"      # lowercased + tie broken by linenumber
    assert len({(r["patientid"], r["new_lot_n"]) for r in rows}) == len(rows)  # unique per (patient, line)
    # With no line_setting, ALL lines are kept (the non-prostate / heme behaviour)
    assert lot_stage.normalized({"lot": lot}).count() == 3


def test_index_overall_windowed():
    if SparkSession is None:
        return
    enh = _spark().createDataFrame([
        ("p1", date(2020, 1, 1)),
        ("p2", date(2010, 1, 1)),   # before index_start -> excluded
    ], ["patientid", "advanceddiagnosisdate"])
    cfg = _cfg()
    rows = index_stage.build({"enhanced": enh}, cfg, cfg.cohort("overall_mcrpc")).collect()
    assert {r["patientid"] for r in rows} == {"p1"}
    assert rows[0]["index_date"] == date(2020, 1, 1)


def test_index_lot1_uses_line_start():
    if SparkSession is None:
        return
    cfg = _cfg()
    # advanceddiagnosisdate must be IN the study window: a line cohort gates on BOTH the setting
    # diagnosis date AND the line start (index.py). Here it's 2020-01-15 (in window) but DISTINCT from
    # the line-1 start (2020-01-01), so index_date==line start proves the cohort indexes off the LINE
    # START, not the diagnosis date.
    enh = _spark().createDataFrame([("p1", date(2020, 1, 15))],
                                   ["patientid", "advanceddiagnosisdate"])
    lot = _spark().createDataFrame([
        ("p1", "Abiraterone", "mCRPC", date(2020, 1, 1), 1, date(2020, 6, 1)),
        ("p1", "Docetaxel",   "mCRPC", date(2020, 7, 1), 2, date(2020, 12, 1)),
    ], ["patientid", "linename", "linesetting", "startdate", "linenumber", "enddate"])
    rows = index_stage.build({"enhanced": enh, "lot": lot}, cfg, cfg.cohort("lot1_mcrpc")).collect()
    assert len(rows) == 1
    assert rows[0]["index_date"] == date(2020, 1, 1) and rows[0]["new_lot_n"] == 1


def test_treatment_categorises_line():
    if SparkSession is None:
        return
    cfg = _cfg()
    idx = _spark().createDataFrame([("p1", date(2020, 1, 1))], ["patientid", "index_date"])
    lot = _spark().createDataFrame([
        ("p1", "Abiraterone", "mCRPC", date(2020, 1, 1), 1, date(2020, 6, 1)),
    ], ["patientid", "linename", "linesetting", "startdate", "linenumber", "enddate"])
    rows = treatment_stage.build({"lot": lot}, idx, cfg).collect()
    assert len(rows) == 1                                   # one row per patient
    # category 1 matches on linename (equals abiraterone) — no drug_episode needed here
    assert rows[0]["lot1cat"] == "Abiraterone monotherapy" and rows[0]["lot1catn"] == 1


def test_prior_taxane_mcrpc_cohort_behaviour():
    if SparkSession is None:
        return
    cfg = _cfg()
    idx = _spark().createDataFrame([("p1", date(2020, 6, 1))], ["patientid", "index_date"])
    lot = _spark().createDataFrame([
        ("p1", "Docetaxel",    "mCRPC", date(2020, 1, 1), 1, date(2020, 5, 1)),
        ("p1", "Enzalutamide", "mCRPC", date(2020, 6, 1), 2, date(2020, 9, 1)),
    ], ["patientid", "linename", "linesetting", "startdate", "linenumber", "enddate"])

    def ptm(coh):
        return (treatment_stage.build({"lot": lot}, idx, cfg, cfg.cohort(coh))
                .collect()[0]["prior_tax_mcrpc"])

    assert ptm("lot2_mcrpc") == "Yes"     # line 1 (the prior mCRPC line) was a taxane (linename LIKE)
    assert ptm("lot1_mcrpc") is None      # 1L cohort: no prior line -> not applicable
    assert ptm("overall_mcrpc") == "No"   # not a line cohort -> No


def test_treatment_chemo_category_from_drug_episode():
    """B1: the drug category lives on drug_episode, not LOT. drug_episode is filtered to the cohort's
    setting, then the per-line chemotherapy indicator is aggregated per (patientid, linenumber) and joined
    on (patientid, linenumber), so lotcatn=9 ("Other chemotherapy-containing") is episode-driven, stays one
    row per patient (no LOT inflation), and does NOT leak across settings (mHSPC line-1 and mCRPC line-1
    share a linenumber but are in different settings, so each cohort sees only its own setting's episodes)."""
    if SparkSession is None:
        return
    cfg = _cfg()
    idx = _spark().createDataFrame([("p1", date(2020, 1, 1))], ["patientid", "index_date"])
    # 'Carboplatin' matches no named linename category (1-8, 10-15), so its category is decided ONLY by
    # the drug-episode detaileddrugcategory (=chemotherapy -> lotcatn 9) — and only in the setting whose
    # line actually has a chemotherapy episode.
    lot = _spark().createDataFrame([
        ("p1", "Carboplatin", "mCRPC", date(2020, 1, 1), 1, date(2020, 6, 1)),
        ("p1", "Carboplatin", "mHSPC", date(2019, 1, 1), 1, date(2019, 6, 1)),
    ], ["patientid", "linename", "linesetting", "startdate", "linenumber", "enddate"])
    # many episodes per line; a chemotherapy episode exists ONLY under mCRPC line 1.
    de = _spark().createDataFrame([
        ("p1", "mCRPC", 1, date(2020, 2, 1), "chemotherapy"),
        ("p1", "mCRPC", 1, date(2020, 3, 1), "targeted/non-biologic"),
        ("p1", "mHSPC", 1, date(2019, 2, 1), "hormonal"),
    ], ["patientid", "linesetting", "linenumber", "episodedate", "detaileddrugcategory"])
    src = {"lot": lot, "drug_episode": de}

    mcrpc = treatment_stage.build(src, idx, cfg, cfg.cohort("overall_mcrpc")).collect()
    mhspc = treatment_stage.build(src, idx, cfg, cfg.cohort("overall_mhspc")).collect()
    assert len(mcrpc) == 1 and len(mhspc) == 1              # one row per patient (setting-scoped aggregate, no fan-out)
    assert mcrpc[0]["lot1catn"] == 9                        # mCRPC L1 chemo episode -> "Other chemotherapy-containing"
    assert mhspc[0]["lot1catn"] != 9                        # mHSPC L1 has no chemo episode -> no cross-setting leak
    # the episode-DATE aggregate (lot1ed) is ALSO setting-scoped: each setting's line-1 gets its own
    # max(episodedate), never the other setting's — proving drug_episode is filtered to the cohort setting.
    assert mcrpc[0]["lot1ed"] == date(2020, 3, 1)          # max mCRPC L1 episode date
    assert mhspc[0]["lot1ed"] == date(2019, 2, 1)          # max mHSPC L1 episode date (not the mCRPC max)


def test_treatment_category_falls_back_to_lot_when_episode_lacks_category():
    """B1 fallback: when drug_episode has line/date fields but NO detaileddrugcategory, the line keeps any
    LOT-native category instead of losing it (the episode aggregate is authoritative for the category only
    when it actually sources one). loted still comes from the episode date."""
    if SparkSession is None:
        return
    cfg = _cfg()
    idx = _spark().createDataFrame([("p1", date(2020, 1, 1))], ["patientid", "index_date"])
    lot = _spark().createDataFrame([
        ("p1", "Carboplatin", "mCRPC", date(2020, 1, 1), 1, date(2020, 6, 1), "chemotherapy"),
    ], ["patientid", "linename", "linesetting", "startdate", "linenumber", "enddate",
        "detaileddrugcategory"])                          # LOT-native category present
    de = _spark().createDataFrame([
        ("p1", "mCRPC", 1, date(2020, 2, 1)),
    ], ["patientid", "linesetting", "linenumber", "episodedate"])   # dates only, NO category column
    rows = treatment_stage.build({"lot": lot, "drug_episode": de}, idx, cfg,
                                 cfg.cohort("overall_mcrpc")).collect()
    assert len(rows) == 1
    assert rows[0]["lot1catn"] == 9                        # LOT-native 'chemotherapy' preserved -> Other-chemo
    assert rows[0]["lot1ed"] == date(2020, 2, 1)          # loted still from the episode date


def test_treatment_no_setting_model_aggregates_across_settings():
    """B1 non-setting path: with NO line-setting model (global cleared, cohort=None), drug_episode is NOT
    filtered by setting — same-numbered lines aggregate together on (patientid, linenumber), one row per
    patient (no fan-out). This is the intended behaviour for heme/COTA products with no setting model."""
    if SparkSession is None:
        return
    cfg = _cfg()
    cfg.raw.setdefault("lot", {})["line_setting"] = None   # clear the global setting model
    idx = _spark().createDataFrame([("p1", date(2020, 1, 1))], ["patientid", "index_date"])
    lot = _spark().createDataFrame([
        ("p1", "Carboplatin", "mCRPC", date(2020, 1, 1), 1, date(2020, 6, 1)),
    ], ["patientid", "linename", "linesetting", "startdate", "linenumber", "enddate"])
    # two settings share linenumber=1; with no setting model they collapse into one (patientid, linenumber)
    # aggregate — the mCRPC chemo episode makes _has_chemo=1 for line 1.
    de = _spark().createDataFrame([
        ("p1", "mCRPC", 1, date(2020, 2, 1), "chemotherapy"),
        ("p1", "mHSPC", 1, date(2019, 2, 1), "hormonal"),
    ], ["patientid", "linesetting", "linenumber", "episodedate", "detaileddrugcategory"])
    rows = treatment_stage.build({"lot": lot, "drug_episode": de}, idx, cfg).collect()   # cohort=None
    assert len(rows) == 1                                  # one row per patient (no fan-out)
    assert rows[0]["lot1catn"] == 9                        # line-1 collapse across settings -> Other-chemo


def test_assemble_treated_untreated_split_and_stamp():
    if SparkSession is None:
        return
    cfg = _cfg()
    keys = _spark().createDataFrame(
        [("p1", date(2020, 1, 1)), ("p2", date(2020, 1, 1))], ["patientid", "index_date"])
    treated = _spark().createDataFrame([("p1", 1)], ["patientid", "treat_flag"])  # only p1 treated
    rows = assemble_stage.build(keys, keys, keys, keys, keys, cfg,
                                cfg.cohort("overall_mcrpc"), treated).collect()
    by = {r["patientid"]: r for r in rows}
    # per-setting COHORTUN (4.StudyPop): Treated mCRPC = 2, Untreated mCRPC = 1
    assert by["p1"]["cohortu"] == "Treated mCRPC" and by["p1"]["cohortun"] == 2
    assert by["p2"]["cohortu"] == "Untreated mCRPC" and by["p2"]["cohortun"] == 1
    assert by["p1"]["cohort"] == "Overall mCRPC"
    # spec_version stamp is the CalVer contract alone (cfg.spec_version = 202606), NOT cfg.version
    # (202606.2026q1) — the data cut is the separate data_refresh axis.
    assert by["p1"]["spec_version"] == cfg.spec_version and by["p1"]["data_refresh"] == "2026q1"
    assert by["p1"]["spec_version"] == "202606"
    # row self-identifies its product (build-level provenance lives in the manifest)
    assert by["p1"]["data_product_id"] == cfg.data_product_id == "prostate_mcrpc_rwdp"


def test_baseline_ecog_unknown_vs_missing():
    if SparkSession is None:
        return
    cfg = _cfg()
    idx = _spark().createDataFrame(
        [("p1", date(2020, 1, 1)), ("p2", date(2020, 1, 1)), ("p3", date(2020, 1, 1))],
        ["patientid", "index_date"])
    becog = _spark().createDataFrame([
        ("p1", "1",       date(2020, 1, 5)),     # numeric -> "1" / code 2
        ("p2", "Unknown", date(2020, 1, 3)),     # explicit unknown -> "Unknown" / code 6
    ], ["patientid", "ecogvalue", "ecogdate"])   # p3 has no record -> "Missing" / code 7
    rows = clinical_stage.baseline_ecog(
        {"baseline_ecog": becog}, idx, cfg.pack("clinical")["baseline_ecog"]).collect()
    by = {r["patientid"]: r for r in rows}
    assert by["p1"]["ecog"] == "1" and by["p1"]["ecogn"] == 2
    assert by["p2"]["ecog"] == "Unknown" and by["p2"]["ecogn"] == 6     # NOT "Missing"
    assert by["p3"]["ecog"] == "Missing" and by["p3"]["ecogn"] == 7


def test_follow_up_and_death():
    if SparkSession is None:
        return
    s, cfg = _spark(), _cfg()
    idx = s.createDataFrame(
        [("p1", date(2020, 1, 1)), ("p2", date(2020, 1, 1)), ("p3", date(2020, 1, 1))],
        ["patientid", "index_date"])
    src = {
        "visit":     s.createDataFrame([("p1", date(2021, 3, 1))], ["patientid", "visitdate"]),
        "telemed":   s.createDataFrame([("p1", date(2021, 1, 1))], ["patientid", "visitdate"]),
        "lot":       s.createDataFrame([("p1", date(2021, 2, 1))], ["patientid", "enddate"]),
        "orals":     s.createDataFrame([("p1", "Month", date(2021, 2, 15))],
                                       ["patientid", "startdategranularity", "enddate"]),
        "alphabet":  s.createDataFrame([("p1", date(2021, 1, 15))], ["patientid", "administrationdate"]),
        "provenge":  s.createDataFrame([("p1", date(2020, 6, 1))], ["patientid", "startdate"]),
        # p2 one death; p3 has TWO death rows -> must collapse to one (earliest), no fan-out.
        "mortality": s.createDataFrame(
            [("p2", "2020-06"), ("p3", "2021-01"), ("p3", "2020-03")], ["patientid", "dateofdeath"]),
    }
    rows = clinical_stage.follow_up_and_death(src, idx, cfg.pack("clinical")).collect()
    assert len(rows) == 3                                                    # P1: no mortality fan-out
    by = {r["patientid"]: r for r in rows}
    assert by["p1"]["dthfl"] == 0 and by["p1"]["fued"] == date(2021, 3, 1)   # latest activity date
    assert by["p1"]["dthfufl"] == "Missing" and by["p1"]["dth_before_fued"] == 0
    assert by["p2"]["dthfl"] == 1 and by["p2"]["dthdt"] == date(2020, 6, 15) # imputed 15th
    assert by["p2"]["fued"] == date(2020, 1, 1)                              # never before index
    assert by["p2"]["dthfufl_dur"] == 166 and by["p2"]["dthfufl"] == "0"     # 166 > 120-day window
    assert by["p3"]["dthfl"] == 1 and by["p3"]["dthdt"] == date(2020, 3, 15) # earliest of the two


def test_mortality_dedup_prefers_specific():
    if SparkSession is None:
        return
    s, cfg = _spark(), _cfg()
    idx = s.createDataFrame([("p1", date(2020, 1, 1))], ["patientid", "index_date"])
    empty = lambda ddl: s.createDataFrame([], ddl)
    src = {
        "visit":     empty("patientid string, visitdate date"),
        "telemed":   empty("patientid string, visitdate date"),
        "lot":       empty("patientid string, enddate date"),
        "orals":     empty("patientid string, startdategranularity string, enddate date"),
        "alphabet":  empty("patientid string, administrationdate date"),
        "provenge":  empty("patientid string, startdate date"),
        # one year-only AND one more-specific month-level row for the same patient
        "mortality": s.createDataFrame([("p1", "2020"), ("p1", "2020-11")],
                                       "patientid string, dateofdeath string"),
    }
    rows = clinical_stage.follow_up_and_death(src, idx, cfg.pack("clinical")).collect()
    assert len(rows) == 1                              # one death row per patient/index
    assert rows[0]["dthdt"] == date(2020, 11, 15)      # specific "2020-11" beats year-only "2020"


def test_mortality_conflict_policy_earliest():
    if SparkSession is None:
        return
    s, cfg = _spark(), _cfg()
    pack = cfg.pack("clinical")
    pack["death_date_imputation"]["conflict_resolution"] = "earliest"   # override the policy
    idx = s.createDataFrame([("p1", date(2020, 1, 1))], ["patientid", "index_date"])
    empty = lambda ddl: s.createDataFrame([], ddl)
    src = {
        "visit":     empty("patientid string, visitdate date"),
        "telemed":   empty("patientid string, visitdate date"),
        "lot":       empty("patientid string, enddate date"),
        "orals":     empty("patientid string, startdategranularity string, enddate date"),
        "alphabet":  empty("patientid string, administrationdate date"),
        "provenge":  empty("patientid string, startdate date"),
        # a more specific later row vs an earlier coarse row
        "mortality": s.createDataFrame([("p1", "2020-11"), ("p1", "2019")],
                                       "patientid string, dateofdeath string"),
    }
    rows = clinical_stage.follow_up_and_death(src, idx, pack).collect()
    assert len(rows) == 1
    # 'earliest' picks the 2019 death (2019-07-15), NOT the more-specific later 2020-11.
    assert rows[0]["dthdt"] == date(2019, 7, 15)


def test_year_level_death_index_aware():
    if SparkSession is None:
        return
    s, cfg = _spark(), _cfg()
    # p1: index Oct (>= July) -> a same-year YYYY death snaps to Dec 31, NOT Jul 15 (pre-index).
    # p2: index Mar (< July)  -> a same-year YYYY death stays Jul 15.
    idx = s.createDataFrame([("p1", date(2020, 10, 1)), ("p2", date(2020, 3, 1))],
                            ["patientid", "index_date"])
    empty = lambda ddl: s.createDataFrame([], ddl)
    src = {
        "visit":     empty("patientid string, visitdate date"),
        "telemed":   empty("patientid string, visitdate date"),
        "lot":       empty("patientid string, enddate date"),
        "orals":     empty("patientid string, startdategranularity string, enddate date"),
        "alphabet":  empty("patientid string, administrationdate date"),
        "provenge":  empty("patientid string, startdate date"),
        "mortality": s.createDataFrame([("p1", "2020"), ("p2", "2020")],
                                       "patientid string, dateofdeath string"),
    }
    by = {r["patientid"]: r for r in
          clinical_stage.follow_up_and_death(src, idx, cfg.pack("clinical")).collect()}
    assert by["p1"]["dthdt"] == date(2020, 12, 31)   # same-year, index >= July -> Dec 31
    assert by["p1"]["fued"] == date(2020, 10, 1)      # death no longer precedes index
    assert by["p1"]["dthdt"] >= by["p1"]["fued"]      # so OS will be non-negative
    assert by["p2"]["dthdt"] == date(2020, 7, 15)     # index < July -> default Jul 15


def test_outcomes_os():
    if SparkSession is None:
        return
    from pyspark.sql.types import (StructType, StructField, StringType, DateType, IntegerType)
    s, cfg = _spark(), _cfg()
    idx = s.createDataFrame([("p1", date(2020, 1, 1)), ("p2", date(2020, 1, 1))],
                            ["patientid", "index_date"])
    schema = StructType([
        StructField("patientid", StringType()), StructField("index_date", DateType()),
        StructField("dthfl", IntegerType()), StructField("dthdt", DateType()),
        StructField("fued", DateType())])
    clin = s.createDataFrame([
        ("p1", date(2020, 1, 1), 1, date(2021, 1, 1), date(2021, 1, 1)),   # died ~12 months
        ("p2", date(2020, 1, 1), 0, None, date(2020, 7, 1)),               # censored ~6 months
    ], schema)
    rows = outcomes_stage.build({}, idx, clin, None, cfg).collect()
    by = {r["patientid"]: r for r in rows}
    assert by["p1"]["id3mosfu"] == 1 and by["p2"]["id3mosfu"] == 1         # index_end is 2025
    assert round(by["p1"]["os"], 1) == round(367 / 30.4375, 1)            # (datediff+1)/days_per_month
    assert round(by["p2"]["os"], 1) == round(183 / 30.4375, 1)


def test_line_outcomes_maintenance_cohort_keys_off_maintenance_line():
    # A lot{N}m cohort indexes the maintenance line, so vis120/TTD must key off lot{N}m* (lot1med),
    # NOT the non-maintenance lot{N}* (lot1ed). OC/EC keep line_outcomes off, so enable it here.
    if SparkSession is None:
        return
    from pyspark.sql.types import StructType, StructField, StringType, DateType, IntegerType
    s, cfg = _spark(), _cfg()
    cfg.pack("outcomes")["line_outcomes"] = {
        "visit_sources": ["visit", "telemed"], "visit_date_column": "visitdate", "ttd_from_line": 1}
    idx = s.createDataFrame([("p1", date(2020, 1, 1))], ["patientid", "index_date"])
    clin = s.createDataFrame(
        [("p1", date(2020, 1, 1), 0, None, date(2021, 1, 1))],
        StructType([StructField("patientid", StringType()), StructField("index_date", DateType()),
                    StructField("dthfl", IntegerType()), StructField("dthdt", DateType()),
                    StructField("fued", DateType())]))
    # line-1 maintenance last-activity (lot1med, 2020-06-01) is LATER than the non-maintenance line-1
    # end (lot1ed, 2020-03-01); the lot1m cohort's ttd must use lot1med.
    trt = s.createDataFrame(
        [("p1", date(2020, 1, 1), 1, date(2020, 3, 1), date(2020, 1, 1), date(2020, 6, 1))],
        StructType([StructField("patientid", StringType()), StructField("index_date", DateType()),
                    StructField("lotn", IntegerType()), StructField("lot1ed", DateType()),
                    StructField("lot1msd", DateType()), StructField("lot1med", DateType())]))
    cohort = {"id": "lot1m", "cohortn": 3, "label": "L1m", "lot_number": 1, "maintenance": True}
    row = outcomes_stage.build({}, idx, clin, trt, cfg, cohort).collect()[0]
    assert row["id3mosfu"] == 1
    assert round(row["ttd"], 1) == round(152 / 30.4375, 1)    # datediff(lot1med 2020-06-01) -> ~5.0
    assert round(row["ttd"], 1) != round(60 / 30.4375, 1)     # NOT lot1ed 2020-03-01 -> ~2.0


def test_progression_pfs_event_and_censor():
    # Real-world PFS: a qualifying progression (evidence 'Yes', not pseudo, after index) is the event;
    # no progression + no death -> censored at follow-up end.
    if SparkSession is None:
        return
    from pyspark.sql.types import StructType, StructField, StringType, DateType, IntegerType
    s, cfg = _spark(), _cfg()
    cfg.pack("outcomes")["progression"] = {
        "source": "progression", "date_column": "progressiondate",
        "evidence_columns": ["isradiographicevidence"],
        "pseudoprogression_column": "ispseudoprogressionmentioned",
        "yes_value": "Yes", "no_value": "No", "pfs2": True}
    idx = s.createDataFrame([("p1", date(2020, 1, 1)), ("p2", date(2020, 1, 1)),
                             ("p3", date(2099, 1, 1))], ["patientid", "index_date"])
    clin = s.createDataFrame(
        [("p1", date(2020, 1, 1), 0, None, date(2021, 1, 1)),
         ("p2", date(2020, 1, 1), 0, None, date(2020, 7, 1)),    # p2 censored at fu-end 2020-07-01
         ("p3", date(2099, 1, 1), 0, None, date(2099, 7, 1))],   # p3 indexes after study end -> id3mosfu=0
        StructType([StructField("patientid", StringType()), StructField("index_date", DateType()),
                    StructField("dthfl", IntegerType()), StructField("dthdt", DateType()),
                    StructField("fued", DateType())]))
    prog = s.createDataFrame(   # p1 and p3 progress (radiographic, not pseudo, after index); p2 does not
        [("p1", date(2020, 4, 1), "Yes", "No"), ("p3", date(2099, 4, 1), "Yes", "No")],
        StructType([StructField("patientid", StringType()), StructField("progressiondate", DateType()),
                    StructField("isradiographicevidence", StringType()),
                    StructField("ispseudoprogressionmentioned", StringType())]))
    by = {r["patientid"]: r for r in
          outcomes_stage.build({"progression": prog}, idx, clin, None, cfg).collect()}
    assert by["p1"]["pfsfl"] == 1 and round(by["p1"]["pfs"], 1) == round(92 / 30.4375, 1)   # to progression
    assert by["p2"]["pfsfl"] == 0 and round(by["p2"]["pfs"], 1) == round(183 / 30.4375, 1)  # censored at fued
    # p3 has a qualifying progression but is ineligible (id3mosfu=0) -> the whole family is gated to null.
    assert by["p3"]["id3mosfu"] == 0 and by["p3"]["pfsfl"] is None and by["p3"]["pfsdt"] is None


def test_progression_pfs2_dedupes_same_day_evidence():
    # Two qualifying progression rows on the SAME date are one event, not two: PFS2 must not fire on
    # the duplicate. A genuinely distinct second date DOES drive PFS2.
    if SparkSession is None:
        return
    from pyspark.sql.types import StructType, StructField, StringType, DateType, IntegerType
    s, cfg = _spark(), _cfg()
    cfg.pack("outcomes")["progression"] = {
        "source": "progression", "date_column": "progressiondate",
        "evidence_columns": ["isradiographicevidence"],
        "pseudoprogression_column": "ispseudoprogressionmentioned",
        "yes_value": "Yes", "no_value": "No", "pfs2": True}
    idx = s.createDataFrame([("dup", date(2020, 1, 1)), ("two", date(2020, 1, 1))],
                            ["patientid", "index_date"])
    clin = s.createDataFrame(
        [("dup", date(2020, 1, 1), 0, None, date(2022, 1, 1)),
         ("two", date(2020, 1, 1), 0, None, date(2022, 1, 1))],
        StructType([StructField("patientid", StringType()), StructField("index_date", DateType()),
                    StructField("dthfl", IntegerType()), StructField("dthdt", DateType()),
                    StructField("fued", DateType())]))
    prog = s.createDataFrame(
        [("dup", date(2020, 4, 1), "Yes", "No"), ("dup", date(2020, 4, 1), "Yes", "No"),   # same day x2
         ("two", date(2020, 4, 1), "Yes", "No"), ("two", date(2020, 8, 1), "Yes", "No")],   # two distinct
        StructType([StructField("patientid", StringType()), StructField("progressiondate", DateType()),
                    StructField("isradiographicevidence", StringType()),
                    StructField("ispseudoprogressionmentioned", StringType())]))
    by = {r["patientid"]: r for r in
          outcomes_stage.build({"progression": prog}, idx, clin, None, cfg).collect()}
    # 'dup' progressed once (the two same-day rows collapse) -> no real 2nd progression, PFS2 censored.
    assert by["dup"]["pfsfl"] == 1 and by["dup"]["pfs2fl"] == 0
    # 'two' has a genuine 2nd progression on 2020-08-01 -> PFS2 fires there (~7.0 months).
    assert by["two"]["pfs2fl"] == 1 and round(by["two"]["pfs2"], 1) == round(214 / 30.4375, 1)


def test_derived_cohorts_appends_filtered_relabeled():
    # A derived cohort splits rows out of its `from` cohorts (by cohortn) matching `where`, relabeled.
    if SparkSession is None:
        return
    from pyspark.sql import functions as F, Window
    from engine.build_ads import _apply_derived_cohorts
    s = _spark()
    ads = s.createDataFrame(
        [("p1", 4, "L2", "Resistant"), ("p2", 4, "L2", "Sensitive"),     # cohortn 4 = lot2
         ("p3", 6, "L3", "Resistant"), ("p4", 2, "L1", "Resistant")],    # p4 cohortn 2 not in `from`
        ["patientid", "cohortn", "cohort", "plat_sen_v1"])

    class _Cfg:                                                          # _apply_derived_cohorts needs only these
        cohorts = [{"id": "lot1", "cohortn": 2}, {"id": "lot2", "cohortn": 4}, {"id": "lot3", "cohortn": 6}]
        raw = {"derived_cohorts": [{"id": "proc", "cohortn": 9, "label": "2L+ PROC",
                                    "from": ["lot2", "lot3"], "where": "plat_sen_v1 = 'Resistant'"}]}

    out = _apply_derived_cohorts(ads, _Cfg(), F, Window)
    proc = [r for r in out.collect() if r["cohortn"] == 9]
    assert {r["patientid"] for r in proc} == {"p1", "p3"}    # resistant 2L/3L only (p2 sensitive, p4 1L)
    assert all(r["cohort"] == "2L+ PROC" for r in proc)
    assert out.count() == 6                                  # 4 original rows + 2 PROC rows


def test_derived_cohorts_pick_first_one_row_per_patient():
    # pick: first keeps only the EARLIEST qualifying line per patient (PROC = first platinum resistance).
    if SparkSession is None:
        return
    from pyspark.sql import functions as F, Window
    from engine.build_ads import _apply_derived_cohorts
    s = _spark()
    ads = s.createDataFrame(
        [("multi", 4, "L2", date(2020, 1, 1), "Resistant"),
         ("multi", 6, "L3", date(2021, 1, 1), "Resistant"),    # same patient, LATER resistant line
         ("single", 4, "L2", date(2020, 6, 1), "Resistant")],
        ["patientid", "cohortn", "cohort", "index_date", "plat_sen_v1"])

    class _Cfg:
        cohorts = [{"id": "lot2", "cohortn": 4}, {"id": "lot3", "cohortn": 6}]
        raw = {"derived_cohorts": [{"id": "proc", "cohortn": 9, "label": "PROC", "pick": "first",
                                    "from": ["lot2", "lot3"], "where": "plat_sen_v1 = 'Resistant'"}]}

    proc = [r for r in _apply_derived_cohorts(ads, _Cfg(), F, Window).collect() if r["cohortn"] == 9]
    assert sorted(r["patientid"] for r in proc) == ["multi", "single"]    # one PROC row per patient
    multi = next(r for r in proc if r["patientid"] == "multi")
    assert multi["index_date"] == date(2020, 1, 1)                        # the EARLIEST resistant line


def test_platinum_sensitivity_classifies_pfi():
    # PFI from the prior platinum line's end to the current line's start: >= threshold -> Sensitive,
    # < threshold -> Resistant. Attaches plat_sen_v1 to the 2L line cohort.
    if SparkSession is None:
        return
    from pyspark.sql import functions as F
    s, cfg = _spark(), _cfg()
    cfg.pack("outcomes")["platinum_sensitivity"] = {
        "source": "lot", "line_number_column": "linenumber", "name_column": "linename",
        "start_column": "startdate", "end_column": "enddate",
        "platinum_agents": ["%carboplatin%", "%cisplatin%"], "threshold_months": 6,
        "pfi_window_days": 14, "from_line": 2}
    lot = s.createDataFrame(
        [("sens", 1, "Carboplatin", date(2020, 1, 1), date(2020, 4, 1)),   # platinum L1
         ("sens", 2, "Doxorubicin", date(2021, 1, 1), date(2021, 6, 1)),   # L2 ~9 mo later -> Sensitive
         ("res",  1, "Carboplatin", date(2020, 1, 1), date(2020, 4, 1)),
         ("res",  2, "Doxorubicin", date(2020, 6, 1), date(2020, 9, 1))],  # L2 ~2 mo later -> Resistant
        ["patientid", "linenumber", "linename", "startdate", "enddate"])
    idx = s.createDataFrame([("sens", date(2021, 1, 1)), ("res", date(2020, 6, 1))],
                            ["patientid", "index_date"])
    by = {r["patientid"]: r for r in
          proc_stage.build(F, {"lot": lot}, idx, cfg, {"lot_number": 2}).collect()}
    assert by["sens"]["plat_sen_v1"] == "Sensitive" and round(by["sens"]["pfi"], 1) == round(275 / 30.4375, 1)
    assert by["res"]["plat_sen_v1"] == "Resistant" and round(by["res"]["pfi"], 1) == round(61 / 30.4375, 1)
    assert by["res"]["pcycled"] == 0                       # L2 is non-platinum -> not a re-challenge


def test_surgery_pcs_vs_ics_classification():
    # Surgery before 1L chemo -> Primary (PCS); at/after 1L start -> Interval (ICS); neoadj when during
    # the 1L window. tt_first_tx_diag = days from diagnosis to the earlier of surgery / 1L start.
    if SparkSession is None:
        return
    from pyspark.sql import functions as F
    from engine.stages.clinical import _surgery
    s = _spark()
    enh = s.createDataFrame(
        [("pcs", "Yes", date(2019, 12, 1), date(2019, 10, 1)),    # surgery BEFORE 1L -> PCS
         ("ics", "Yes", date(2020, 3, 1), date(2019, 10, 1)),     # surgery AFTER 1L start -> ICS
         ("no", "No", date(2019, 12, 1), date(2019, 10, 1))],     # No surgery + stray date -> No Surgery
        ["patientid", "issurgery", "surgerydate", "diagnosisdate"])
    lot = s.createDataFrame(
        [("pcs", 1, "False", date(2020, 1, 1), date(2020, 6, 1)),
         ("ics", 1, "False", date(2020, 1, 1), date(2020, 6, 1)),
         ("no", 1, "False", date(2020, 1, 1), date(2020, 6, 1))],
        ["patientid", "linenumber", "ismaintenancetherapy", "startdate", "enddate"])
    idx = s.createDataFrame([("pcs", date(2020, 1, 1)), ("ics", date(2020, 1, 1)),
                             ("no", date(2020, 1, 1))], ["patientid", "index_date"])
    scfg = {"source": "enhanced", "surgery_flag_column": "issurgery", "surgery_date_column": "surgerydate",
            "init_date_column": "diagnosisdate", "line_source": "lot", "line_number_column": "linenumber",
            "line_start_column": "startdate", "line_end_column": "enddate",
            "maintenance_column": "ismaintenancetherapy", "yes_value": "Yes", "no_value": "No",
            "pcs_label": "Primary cytoreductive surgery (PCS)",
            "ics_label": "Interval cytoreductive surgery (ICS)", "none_label": "No Surgery"}
    by = {r["patientid"]: r for r in _surgery(F, {"enhanced": enh, "lot": lot}, idx, scfg).collect()}
    assert by["pcs"]["surgn"] == 1 and "PCS" in by["pcs"]["surg"] and by["pcs"]["neoadj"] == "No"
    assert by["ics"]["surgn"] == 2 and "ICS" in by["ics"]["surg"] and by["ics"]["neoadj"] == "Yes"
    assert by["ics"]["tt_first_tx_diag"] == 92             # diagnosis 2019-10-01 -> 1L start 2020-01-01
    # issurgery='No' with a stray date must NOT be classified as PCS/neoadj (gated on the flag).
    assert by["no"]["surg"] == "No Surgery" and by["no"]["surgn"] == 3 and by["no"]["neoadj"] == "No"


def test_baseline_ecog_same_date_tie_picks_worst_known():
    # 6-step final tie-break: among same-gap + same-date records the WORST (max) ECOG wins, and a real
    # grade beats Unknown (which ranks last).
    if SparkSession is None:
        return
    from engine.stages.clinical import baseline_ecog
    s, cfg = _spark(), _cfg()
    ecfg = cfg.pack("clinical")["baseline_ecog"]
    idx = s.createDataFrame([("p1", date(2020, 1, 10)), ("p2", date(2020, 1, 10))],
                            ["patientid", "index_date"])
    ec = s.createDataFrame(
        [("p1", date(2020, 1, 8), "1"), ("p1", date(2020, 1, 8), "3"),         # tie -> max grade 3
         ("p2", date(2020, 1, 8), "2"), ("p2", date(2020, 1, 8), "Unknown")],  # tie -> grade 2 beats Unknown
        ["patientid", "ecogdate", "ecogvalue"])
    by = {r["patientid"]: r for r in baseline_ecog({"baseline_ecog": ec}, idx, ecfg).collect()}
    assert by["p1"]["ecog"] == "3" and by["p2"]["ecog"] == "2"


def test_min_avail_date_earliest_across_sources():
    # minavaildate = earliest of the base date and the first date in each source; basedur = index - it.
    if SparkSession is None:
        return
    from pyspark.sql import functions as F
    from engine.stages.clinical import _min_avail_date
    s = _spark()
    idx = s.createDataFrame([("p1", date(2021, 1, 1))], ["patientid", "index_date"])
    src = {
        "enh": s.createDataFrame([("p1", date(2020, 6, 1))], ["patientid", "diagnosisdate"]),
        "visit": s.createDataFrame([("p1", date(2020, 3, 1)), ("p1", date(2020, 9, 1))],
                                   ["patientid", "visitdate"]),
        "lot": s.createDataFrame([("p1", date(2020, 12, 1))], ["patientid", "startdate"]),
    }
    blk = {"base_columns": ["diagnosisdate"],
           "sources": [{"source": "visit", "date_column": "visitdate"},
                       {"source": "lot", "date_column": "startdate"}]}
    row = _min_avail_date(F, src, idx, blk, "enh").collect()[0]
    assert row["minavaildate"] == date(2020, 3, 1)    # earliest: visit 2020-03 < diagnosis 2020-06 < lot 2020-12
    assert row["basedur"] == 306                       # datediff(2021-01-01, 2020-03-01)


def test_passthrough_columns_and_presence_flag():
    # Config-driven enhanced pass-through: alias raw columns + a presence flag (EC radiation).
    if SparkSession is None:
        return
    from pyspark.sql import functions as F
    from engine.stages.clinical import _passthrough
    s = _spark()
    enh = s.createDataFrame(
        [("p1", "EBRT", date(2020, 5, 1)), ("p2", None, None)],     # p2 has no radiation date
        ["patientid", "radiationtype", "radiationtherapydate"])
    idx = s.createDataFrame([("p1", date(2021, 1, 1)), ("p2", date(2021, 1, 1))],
                            ["patientid", "index_date"])
    blk = {"source": "enh",
           "columns": [{"column": "radiationtype", "as": "radiation_type"},
                       {"column": "radiationtherapydate", "as": "radiationdt"}],
           "flags": [{"name": "radiation_flag", "from": "radiationtherapydate",
                      "absent": "No/unknown", "present": "Yes"}]}
    by = {r["patientid"]: r for r in _passthrough(F, {"enh": enh}, idx, blk, "enh").collect()}
    assert by["p1"]["radiation_type"] == "EBRT" and by["p1"]["radiation_flag"] == "Yes"
    assert by["p2"]["radiationdt"] is None and by["p2"]["radiation_flag"] == "No/unknown"


def test_tfl_generate_skips_inapplicable_table():
    # A TFL whose columns aren't in the ADS (the OC platinum table on a prostate-like ADS) must be
    # SKIPPED, not error on the unresolved `where` column — otherwise it fails the (now required) TFL
    # deliverable on prostate.
    if SparkSession is None:
        return
    from engine import tfl as tfl_engine
    s = _spark()
    ads = s.createDataFrame([("A", "1L"), ("A", "2L"), ("B", "1L")], ["cohort", "lot1cat"])
    specs = {"tfls": [
        {"id": "t4_platinum", "kind": "table", "by": "cohort", "summarise": ["plat_sen_v1"],
         "where": "plat_sen_v1 IS NOT NULL", "where_columns": ["plat_sen_v1"]},
        {"id": "t3", "kind": "table", "by": "cohort", "summarise": ["lotcat"]}]}
    out = tfl_engine.generate(s, ads, specs)
    assert "t4_platinum" not in out      # skipped (no unresolved-column error)
    assert "t3" in out                   # the producible table still generates (lotcat -> lot1cat)


if __name__ == "__main__":
    if SparkSession is None:
        print("SKIP: pyspark not installed — run on a Spark runtime.")
        sys.exit(0)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    _spark().stop()
    print(f"\n{len(fns)} tests passed")
