"""Registry-driven Spark smoke test: build the ADS for EVERY configured tumor on tiny synthetic
data. This is the multi-tumor execution coverage the pure-Python lint can't give — it exercises
optional sources (OC/EC drop alphabet/provenge), the index-SOURCE shape (DLBCL indexes off
diagnosis), and the config-driven LOT line-setting.

Spark-only -> skips without pyspark (the pure-Python CI runner). Has been run locally on a real
Spark (pyspark in a venv); install pyspark to execute it, or it skips.
"""
import sys
from datetime import date
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))
PRODUCTS = FRAMEWORK.parent / "products"

try:
    from pyspark.sql import SparkSession
except Exception:
    SparkSession = None

# Stage modules are import-safe without pyspark OR pyyaml. engine.config needs pyyaml, so it is
# imported LAZILY inside the test — this file reaches the pyspark skip even when neither is present.
from engine.stages import (index as index_stage, demographics as dem_stage,         # noqa: E402
                           clinical as clin_stage, treatment as trt_stage,
                           outcomes as out_stage, assemble as asm_stage, lot as lot_stage)

try:
    import pytest
    pytestmark = pytest.mark.skipif(SparkSession is None, reason="pyspark not installed")
except Exception:
    pytest = None

GOOD = {"run.refresh": "v", "run.source_schema": "s", "run.output_schema": "o"}
_SPARK = None


def _spark():
    global _SPARK
    if _SPARK is None:
        _SPARK = (SparkSession.builder.master("local[1]").appName("smoke")
                  .config("spark.sql.shuffle.partitions", "1")
                  .config("spark.driver.memory", "3g")   # the 7-cohort unioned plan needs driver headroom
                  .getOrCreate())
    return _SPARK


# Columns each declared source must expose for the stages to run (a superset is harmless). The core
# sources carry MEANINGFUL values (the line setting / race / death granularity that stage logic keys
# on); EVERY other required column — including the OC/EC biomarker & lab panel columns and the
# enhanced categorical/staging columns — is synthesised from the preflight contract required_columns(),
# so the closest-to-index panel paths actually execute (a date-named column gets a date, else "1").
def _augment(df, cols, d1):
    from pyspark.sql import functions as F
    have = {c.lower() for c in df.columns}
    for c in cols:
        if c.lower() not in have:
            # a date-named column gets a date (covers dateofmetastasis / *date), else "1"
            is_date = "date" in c.lower() and "granularity" not in c.lower()
            df = df.withColumn(c, F.lit(d1) if is_date else F.lit("1"))
    return df


def _synth_src(s, cfg):
    from pyspark.sql import functions as F
    from engine.validate import required_columns        # deferred: needs pyyaml (present by now)
    d1, d2 = date(2020, 1, 1), date(2020, 6, 1)
    # one LOT line per DISTINCT cohort line_setting, so a dual-setting product's mHSPC AND mCRPC line
    # cohorts each have data (a single global-setting line would never exercise lot1_mhspc indexing).
    settings = sorted({c.get("line_setting") for c in cfg.cohorts} - {None}) or [cfg.lot_line_setting or "x"]
    table = {
        "lot": (["patientid", "linename", "linesetting", "startdate", "linenumber", "enddate",
                 "detaileddrugcategory"],
                [("p1", "drug", st, d1, 1, d2, "chemotherapy") for st in settings]),
        "demographics": (["patientid", "birthyear", "race", "ethnicity"],
                         [("p1", "1960", "White", "Not Hispanic or Latino")]),
        "mortality": (["patientid", "dateofdeath"], [("p1", "2021-01")]),
        "baseline_ecog": (["patientid", "ecogdate", "ecogvalue"], [("p1", d1, "1")]),
        "visit": (["patientid", "visitdate"], [("p1", d2)]),
        "telemed": (["patientid", "visitdate"], [("p1", d2)]),
        "orals": (["patientid", "enddate", "startdategranularity"], [("p1", d2, "Month")]),
        "alphabet": (["patientid", "administrationdate"], [("p1", d2)]),
        "provenge": (["patientid", "startdate"], [("p1", d2)]),
    }
    req = required_columns(cfg)
    # staging reads `groupstage` from its source (default the index source); required_columns()
    # doesn't list it, so make sure that source carries it too.
    stcfg = cfg.pack("clinical").get("staging") or {}
    if stcfg.get("groups"):
        st_src = stcfg.get("source", cfg.index_source)
        req.setdefault(st_src, ["patientid"]).append("groupstage")

    src = {}
    for name in cfg.sources:
        cols, rows = table.get(name, (["patientid"], [("p1",)]))
        df = _augment(s.createDataFrame(rows, cols), req.get(name, []), d1)
        src[name] = df

    # Index source: patientid + the union of every index_dates model's `of` columns, with EACH model
    # materialized as a column (advanceddiagnosisdate / hspcdiagnosisdate / …) exactly as sources.load
    # does — so a dual-setting product's mHSPC cohorts resolve their setting-specific anchor.
    isrc = cfg.index_source
    allof = sorted({c.lower() for rule in (cfg.index_dates or {}).values() for c in (rule.get("of") or [])})
    idf = s.createDataFrame([tuple(["p1"] + [d1] * len(allof))], ["patientid"] + allof)
    for key, rule in (cfg.index_dates or {}).items():
        cols = [c.lower() for c in (rule.get("of") or [])]
        if cols:
            expr = F.greatest(*[F.col(c) for c in cols]) if len(cols) > 1 else F.col(cols[0])
            idf = idf.withColumn(key.replace("_", ""), expr)
    src[isrc] = _augment(idf, req.get(isrc, []), d1)
    return src


def _build_all_cohorts(cfg):
    from pyspark.sql import functions as F
    s = _spark()
    src = _synth_src(s, cfg)
    total = 0
    for cohort in cfg.cohorts:
        # treated derived PER COHORT off its line_setting (== build_ads.py), so the dual-setting mHSPC
        # path (treated/untreated mHSPC) is actually exercised, not just the global mCRPC setting.
        treated = (lot_stage.normalized(src, cohort.get("line_setting", cfg.lot_line_setting),
                                        exclude_settings=cfg.lot_exclude_settings,
                                        line_number_col=cfg.lot_line_number_col,
                                        maintenance_column=cfg.lot_maintenance_column)
                   .select("patientid").distinct().withColumn("treat_flag", F.lit(1)))
        idx = index_stage.build(src, cfg, cohort)
        dem = dem_stage.build(src, idx, cfg)
        clin = clin_stage.build(src, idx, cfg)
        trt = trt_stage.build(src, idx, cfg, cohort)
        out = out_stage.build(src, idx, clin, trt, cfg, cohort)
        ads = asm_stage.build(idx, dem, clin, trt, out, cfg, cohort, treated)
        assert "cohort" in ads.columns and "spec_version" in ads.columns
        total += ads.count()
    return total


def test_smoke_every_configured_tumor():
    if SparkSession is None:
        return
    from engine.config import load_yaml, load_config, product_config, product_dir   # deferred: needs pyyaml
    checked = 0
    for t in load_yaml(PRODUCTS / "registry.yaml")["tumors"]:
        cfg_path = product_config(PRODUCTS, t["slug"])
        if not cfg_path.exists():
            continue
        cfg = load_config(cfg_path, overrides=GOOD)
        _build_all_cohorts(cfg)        # end-to-end build must not error for any tumor
        checked += 1
    assert checked >= 2, "expected at least 2 configured tumors (prostate + one more)"


def test_smoke_prostate_production_union_path():
    # Exercise the REAL production entrypoint (build_ads.build_from_sources -> per-cohort stages,
    # unionByName, derived cohorts) on synthetic prostate sources — not the per-cohort loop. Asserts the
    # 7-cohort dual-setting ADS unions and carries BOTH per-setting COHORTU labels.
    if SparkSession is None:
        return
    from engine.config import load_config, product_config
    from engine import build_ads
    cfg = load_config(product_config(PRODUCTS, "prostate"), overrides=GOOD)
    ads = build_ads.build_from_sources(_synth_src(_spark(), cfg), cfg)
    assert {"cohort", "cohortu", "spec_version"} <= set(ads.columns)
    us = {r["cohortu"] for r in ads.select("cohortu").distinct().collect() if r["cohortu"]}
    assert any("mHSPC" in u for u in us) and any("mCRPC" in u for u in us), us  # both settings present


if __name__ == "__main__":
    if SparkSession is None:
        print("SKIP: pyspark not installed — run on a Spark runtime.")
        sys.exit(0)
    test_smoke_every_configured_tumor()
    print("ok  test_smoke_every_configured_tumor")
    test_smoke_prostate_production_union_path()
    print("ok  test_smoke_prostate_production_union_path")
