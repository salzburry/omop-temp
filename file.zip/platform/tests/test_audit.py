"""Step-4 governance: the TFL QC gate (skip semantics) + the consolidated release bundle. Pure Python.

Run: python3 tests/test_audit.py (or pytest).
"""
import json
import sys
import tempfile
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))

from engine import audit, tfl            # noqa: E402


def test_tfl_qc_skip_semantics():
    specs = {"tfls": [
        {"id": "t_req_ok",   "kind": "table"},                       # required (default), producible
        {"id": "t_req_miss", "kind": "table"},                       # required, NOT producible -> failure
        {"id": "t_opt_miss", "kind": "figure", "required": False},   # optional, not producible -> warning
        {"id": "t_na",       "kind": "table",  "applicable": False}, # not applicable -> ok
    ]}
    plan = {"t_req_ok": [], "t_req_miss": ["os"], "t_opt_miss": ["pfs"], "t_na": ["x"]}
    qc = tfl.tfl_qc(specs, plan, generated_at="2026-01-01T00:00:00+00:00")
    by = {r["id"]: r for r in qc["tfls"]}
    assert by["t_req_ok"]["status"] == "ok" and by["t_req_ok"]["produced"]
    assert by["t_req_miss"]["status"] == "failure"
    assert by["t_opt_miss"]["status"] == "warning"
    assert by["t_na"]["status"] == "ok" and not by["t_na"]["applicable"]
    assert qc["passed"] is False                                     # one failure -> gate fails


def test_tfl_qc_passes_when_no_failure():
    specs = {"tfls": [{"id": "a"}, {"id": "b", "required": False}]}
    qc = tfl.tfl_qc(specs, {"a": [], "b": ["missing"]})              # a ok, b warning
    assert qc["passed"] is True and {r["status"] for r in qc["tfls"]} == {"ok", "warning"}


def test_tfl_qc_reconciles_actually_generated():
    # column-producible != actually generated: a REQUIRED TFL that generate() silently skipped (not in
    # `generated`) is a FAILURE, not a false ok; an OPTIONAL one only warns. (Closes the gap where a
    # required table with all-absent summarise columns passed QC but emitted nothing.)
    specs = {"tfls": [{"id": "t_req"}, {"id": "t_opt", "required": False}]}
    plan = {"t_req": [], "t_opt": []}                                # BOTH column-producible
    qc = tfl.tfl_qc(specs, plan, generated={"t_opt"})                # generate() emitted only t_opt
    by = {r["id"]: r for r in qc["tfls"]}
    assert by["t_req"]["status"] == "failure" and not by["t_req"]["produced"]
    assert by["t_opt"]["status"] == "ok" and qc["passed"] is False
    assert tfl.tfl_qc(specs, plan, generated={"t_req", "t_opt"})["passed"] is True   # both emitted -> ok
    none_emitted = {r["id"]: r["status"] for r in tfl.tfl_qc(specs, plan, generated=set())["tfls"]}
    assert none_emitted == {"t_req": "failure", "t_opt": "warning"}


def _manifest():
    return {
        "tumor": "mcrpc", "spec_version": "202606", "refresh": "2026q1", "status": "released",
        "data_product_id": "prostate_mcrpc_rwdp", "engine_version": "1.0.0", "git_commit": "abc123",
        "output_table": "out.rwdp_pros_pano_202606", "published_at": "2026-01-02T00:00:00+00:00",
        "counts": {"total_rows": 100}, "qc": {"passed": True}, "golden": {"reference": "none"},
        "source_qc": {"granularity": "ok"}, "release": {"build_id": "abc123_run42", "ads": "out.x__2026q1__abc123_run42"},
        "tfl_promotion": {"passed": True}, "sign_off": {"released_by": "qa@x"},
    }


def test_build_bundle_splits_qc():
    b = audit.build_bundle(_manifest(), tfl_qc={"passed": True, "tfls": []})
    assert set(b) == {"release.json", "audit_report.md", "source_qc.json", "ads_qc.json", "golden.json", "tfl_qc.json"}
    assert b["release.json"]["spec_version"] == "202606"             # release.json IS the record
    assert b["source_qc.json"] == {"granularity": "ok"}             # QC split out of the manifest
    assert "Release audit — mcrpc 202606 / 2026q1" in b["audit_report.md"]
    assert "1.0.0" in b["audit_report.md"]                          # engine version surfaced


def test_audit_report_reads_real_signoff_fields():
    # Guard sign-off field-name drift: the audit report must read the SAME keys engine.refresh writes
    # (qc_by / released_by), not aliases like qc_reviewed_by — else the reviewer shows as (none).
    m = _manifest()
    m["sign_off"] = {"qc_by": "qc@x", "qc_date": "d1", "released_by": "rel@x", "released_date": "d2"}
    md = audit.audit_report_md(m)
    assert "qc@x" in md and "rel@x" in md


def test_write_bundle_roundtrip():
    d = tempfile.mkdtemp()
    written = audit.write_bundle(_manifest(), d, tfl_qc={"passed": True, "tfls": []})
    assert any(p.endswith("release.json") for p in written)
    rec = json.loads((Path(d) / "release.json").read_text())
    assert rec["data_product_id"] == "prostate_mcrpc_rwdp"
    assert (Path(d) / "audit_report.md").exists() and (Path(d) / "tfl_qc.json").exists()


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
