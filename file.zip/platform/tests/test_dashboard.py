"""Dashboard-manifest exporter + atomic release pointer (pure Python, no Spark).
Run: python3 test_dashboard.py (or pytest).
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))
PRODUCTS = FRAMEWORK.parent / "products"

from engine.config import load_yaml, load_config   # noqa: E402
from engine.config import product_config, product_dir  # noqa: E402
from engine import dashboard, release              # noqa: E402

CATALOG = PRODUCTS / "metadata" / "catalog.yaml"
DASH = PRODUCTS / "_reporting" / "dashboard" / "dashboard_vars.yaml"
PROSTATE = product_config(PRODUCTS, "prostate")


def _manifest(tumor="mcrpc"):
    return dashboard.build_manifest(load_config(PROSTATE), load_yaml(CATALOG), tumor,
                                    dashboard=load_yaml(DASH))


def test_manifest_carries_tumor_specific_variables_and_types():
    by = {v["code"]: v for v in _manifest()["variables"]}
    # prostate-specific (applies_to:[mcrpc]) variables are present -> proves code-based filtering
    assert "gleason" in by and "mcrpc" in by and "ttd" in by
    # type model
    os_ = by["os"]
    assert os_["type"] == "time_to_event" and os_["event_flag"] == "dthfl" and os_["unit"] == "months"
    assert by["stage"]["type"] == "categorical" and by["stage"]["values"]      # value set from the pack
    assert by["ecog"]["type"] == "categorical" and by["ecog"]["values"]
    assert by["dthfl"]["type"] == "flag"
    assert by["dthdt"]["type"] == "date"
    assert by["age"]["type"] == "numeric"
    # 0/1 flags that don't end in 'fl', and PSA numerics — no longer misclassified as 'string'
    assert by["mcrpc"]["type"] == "flag" and by["vis120"]["type"] == "flag" and by["trtdis"]["type"] == "flag"
    assert by["psadiag_init"]["type"] == "numeric" and by["psadiag_met"]["type"] == "numeric"

    # --- v2 (mHSPC + mCRPC full-spec) variable typing — regression guard for the whole new var set ----
    # TSST is time-to-event (paired with its event flag); windowed PSA values are numeric.
    assert by["tsst"]["type"] == "time_to_event" and by["tsst"]["event_flag"] == "tsstfl"
    assert by["psa_index"]["type"] == "numeric" and by["psa6mo"]["type"] == "numeric"
    # prior-treatment / metastatic-site / PSA-response flags. prior_nha_adt must NOT be 'date' (ends 'adt').
    for f in ("prior_pluvicto", "prior_nha_adt", "bone_met", "brain_met", "psa50_6mo", "psal12mo", "eligpfs"):
        assert by[f]["type"] == "flag", f
    # closest-to-index labs are Present/Unknown/Missing categoricals (3-state value set from the pack);
    # v/dt are numeric/date
    assert by["labneu"]["type"] == "categorical" and by["labneu"]["values"] == ["Present", "Unknown", "Missing"]
    assert by["labneuv"]["type"] == "numeric" and by["labneudt"]["type"] == "date"
    # diagnosis-date pass-throughs are dates (init/mpcdd don't end in 'dt')
    assert by["init"]["type"] == "date" and by["mpcdd"]["type"] == "date"
    # cohort labels carry their value sets (the 7 cohorts; the per-setting treated/untreated split)
    assert by["cohort"]["type"] == "categorical" and len(by["cohort"]["values"]) == 7
    assert by["cohortu"]["type"] == "categorical" and "Treated mCRPC" in by["cohortu"]["values"]
    assert by["gleason"]["type"] == "categorical" and by["ses"]["type"] == "categorical"
    # categorized pass-through (gleason_cat bands), LoT category (lotcat from the 17-way codelist), and the
    # cohort-aware prior-taxane flag — locks the value-set extraction added for these.
    assert by["gleason_cat"]["type"] == "categorical" and by["gleason_cat"]["values"] == ["<=6", "7", "8", "9-10"]
    assert (by["lotcat"]["type"] == "categorical" and len(by["lotcat"]["values"]) == 17
            and "Docetaxel monotherapy" in by["lotcat"]["values"])
    assert by["prior_tax_mcrpc"]["type"] == "flag"


def test_manifest_columns_filter_excludes_non_emitted():
    # With `columns` (the actual ADS columns) the manifest advertises ONLY what is emitted.
    m = dashboard.build_manifest(load_config(PROSTATE), load_yaml(CATALOG), "mcrpc",
                                 dashboard=load_yaml(DASH), columns=["cohort", "os", "dthfl", "age"])
    codes = {v["code"] for v in m["variables"]}
    assert codes == {"cohort", "os", "dthfl", "age"} and "gleason" not in codes


def test_manifest_excludes_other_tumor_variables():
    codes = {v["code"] for v in _manifest()["variables"]}
    assert "brca" not in codes and "plat_sen_v1" not in codes   # OC-only, not applicable to mcrpc


def test_manifest_panels_keep_only_applicable_variables():
    m = _manifest()
    cataloged = {v["code"] for v in m["variables"]}
    assert m["panels"], "expected panels from the dashboard layout"
    for p in m["panels"]:
        assert all(c in cataloged for c in p["variables"])
    assert m["summary"]["n_variables"] == len(m["variables"]) and m["tumor"] == "mcrpc"


def test_render_json_roundtrips():
    import json
    m = _manifest()
    assert json.loads(dashboard.render_json(m))["tumor"] == "mcrpc"


def test_release_pointer_and_swap_plan():
    # synthetic FQN + spec_version — these exercise the naming/swap-plan/pointer LOGIC only; they are
    # NOT the prostate product contract (that's rwdp_pros_pano_202606 / spec_version 202606).
    final, bid = "out.demo_ads", "abc123def456"
    # build_id makes versioned tables unique per run -> a same-refresh rerun never overwrites the live one
    assert release.versioned_ads(final, "2026q1", bid) == f"{final}__2026q1__{bid}"
    assert release.versioned_tfl(final, "2026q1", bid, "t1") == f"{final}__2026q1__{bid}__tfl_t1"
    plan = release.swap_plan(final, "2026q1", bid, ["t1", "f1"])
    assert plan[-1][0] == final and plan[-1][1] == f"{final}__2026q1__{bid}"   # ADS view swapped LAST
    assert plan[0][0] == release.public_tfl(final, "t1")                       # TFLs first
    assert all(sql.startswith("CREATE OR REPLACE VIEW") for _, _, sql in plan)
    ptr = release.release_pointer(final, "2026q1", bid, ["t1"], spec_version="1.0")
    assert ptr["build_id"] == bid and ptr["ads"] == f"{final}__2026q1__{bid}"
    assert ptr["tfls"]["t1"] == f"{final}__2026q1__{bid}__tfl_t1" and ptr["views"][final] == ptr["ads"]


def test_stale_public_tfls_detects_removed():
    final = "out.demo_ads"                       # synthetic FQN (see test_release_pointer_and_swap_plan)
    existing = [release.public_tfl(final, t) for t in ("t1", "t3_old")]
    # the current release produces only t1 -> t3_old's public view is now stale (a spec dropped it)
    assert release.stale_public_tfls(existing, final, ["t1"]) == [release.public_tfl(final, "t3_old")]
    assert release.stale_public_tfls(existing, final, ["t1", "t3_old"]) == []   # all current -> none stale
    assert release.stale_public_tfls([], final, ["t1"]) == []                   # clean schema -> none


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
