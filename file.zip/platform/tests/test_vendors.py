"""Vendor adapter + vendor-aware config tests (pure Python, no Spark).
Run: python3 test_vendors.py (or pytest).
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))

from engine import vendors             # noqa: E402
from engine.config import load_config  # noqa: E402
from engine.config import product_config, product_dir  # noqa: E402

PROSTATE = product_config(FRAMEWORK.parent / "products", "prostate")
DLBCL = product_config(FRAMEWORK.parent / "products", "dlbcl")
GOOD = {"run.refresh": "2026q1", "run.source_schema": "rwd", "run.output_schema": "out"}


def test_flatiron_layout():
    assert vendors.resolve("flatiron", None, "sch", "t_enh_prostate", "2026q1") \
        == "sch.t_enh_prostate_2026q1"


def test_layout_override():
    assert vendors.resolve("cota", "{schema}.{stem}__{refresh}", "c", "dlbcl", "v1") == "c.dlbcl__v1"


def test_unknown_vendor_without_override_raises():
    try:
        vendors.resolve("acme", None, "s", "x", "r")
    except KeyError:
        return
    raise AssertionError("expected KeyError for an unknown vendor with no override")


def test_prostate_config_is_flatiron_solid_mcrpc():
    cfg = load_config(PROSTATE, overrides=GOOD)
    assert cfg.vendor == "flatiron" and cfg.tumor_class == "solid"
    assert cfg.lot_line_setting == "mCRPC"
    assert cfg.table("enhanced") == "rwd.t_enh_prostate_2026q1"   # vendor-resolved


def test_dlbcl_config_is_cota_heme_no_prostate_sources():
    cfg = load_config(DLBCL, overrides={"run.refresh": "v1", "run.source_schema": "cs",
                                        "run.output_schema": "out"})
    assert cfg.vendor == "cota" and cfg.tumor_class == "heme"
    assert cfg.lot_line_setting is None                          # all lines counted
    assert "alphabet" not in cfg.sources and "provenge" not in cfg.sources   # optional, omitted
    assert cfg.index_source == "diagnosis"                       # heme indexes off diagnosis, not enhanced


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
