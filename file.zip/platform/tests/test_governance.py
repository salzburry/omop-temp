"""Wave-1 governance checks (pure Python, no jsonschema lib needed). These make the governance/
artifacts REAL — CI fails if the engine VERSION isn't SemVer, a schema is malformed, an active product
lacks a presence-valid source_refs.yaml, or the root CODEOWNERS stops routing governance.

Run: python3 tests/test_governance.py (or pytest). See governance/ + migration doc §H.
"""
import json
import re
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent      # _framework/
sys.path.insert(0, str(FRAMEWORK))
PRODUCTS = FRAMEWORK.parent / "products"                             # products/
REPO = PRODUCTS.parent                                  # repo root
GOV = REPO / "governance"

from engine.config import load_yaml                     # noqa: E402
from engine.config import product_config, product_dir  # noqa: E402
from engine.version import ENGINE_VERSION, engine_version  # noqa: E402

SEMVER = re.compile(r"^\d+\.\d+\.\d+$")
YYYYMM = re.compile(r"^\d{6}$")


def test_engine_version_is_semver():
    v = (FRAMEWORK / "VERSION").read_text(encoding="utf-8").strip()
    assert SEMVER.match(v), f"platform/VERSION is not SemVer: {v!r}"
    assert engine_version() == v and ENGINE_VERSION == v, "engine.version disagrees with the VERSION file"


def test_schemas_well_formed():
    schemas = sorted((GOV / "schemas").glob("*.json"))
    assert schemas, "no governance/schemas/*.json found"
    for s in schemas:
        doc = json.loads(s.read_text(encoding="utf-8"))                  # must be valid JSON
        assert str(doc.get("$schema", "")).startswith("https://json-schema.org/"), f"{s.name}: no $schema"
        assert "type" in doc and ("required" in doc or "properties" in doc), f"{s.name}: not a schema"


def test_active_products_have_valid_source_refs():
    schema = json.loads((GOV / "schemas" / "source_refs.schema.json").read_text(encoding="utf-8"))
    top_req = schema["required"]                                          # product, spec_version, source_materials
    item_req = schema["properties"]["source_materials"]["items"]["required"]   # path_or_link, role, status
    status_enum = set(schema["properties"]["source_materials"]["items"]["properties"]["status"]["enum"])
    try:
        import jsonschema   # CI installs it (platform/requirements.txt); optional locally
    except ImportError:
        jsonschema = None
    actives = [t for t in load_yaml(PRODUCTS / "registry.yaml")["tumors"] if t.get("status") == "active"]
    assert actives, "no active products in registry"
    for t in actives:
        # EVERY on-disk spec version of an active product (registry-current AND superseded-but-buildable
        # lineage, e.g. prostate 202603 AND 202606) must carry a valid source_refs.yaml — the audit promise
        # covers the buildable prior contracts too, not only the current one.
        pack_root = product_dir(PRODUCTS, t["slug"]).parent
        versions = sorted(d.name for d in pack_root.iterdir()
                          if (d / "config" / "data_product.yaml").exists())
        assert versions, f"active product {t['code']}: no spec-version pack on disk under {pack_root}"
        for sv in versions:
            sr_path = product_dir(PRODUCTS, t["slug"], spec_version=sv) / "source_refs.yaml"
            assert sr_path.exists(), f"active product {t['code']}/{sv} is missing source_refs.yaml (required — doc §C)"
            sr = load_yaml(sr_path)
            # FULL schema validation when jsonschema is present (CI) — required + minItems + status enum +
            # pattern, straight from the schema so this test can't drift from it. (Without it, the manual
            # floor below still catches the named gaps: empty source_materials, a typo'd status.)
            if jsonschema is not None:
                jsonschema.validate(sr, schema)
            assert sr.get("source_materials"), f"{t['code']}/{sv}: source_materials is empty (schema minItems: 1)"
            for k in top_req:
                assert k in sr, f"{t['code']}/{sv} source_refs.yaml missing top-level '{k}'"
            assert YYYYMM.match(str(sr["spec_version"])), f"{t['code']}/{sv}: source_refs spec_version not YYYYMM"
            # BIND the file to its folder + product: a 202606 source_refs copied under 202603/ must FAIL.
            assert str(sr["spec_version"]) == sv, \
                f"{t['code']}/{sv}: source_refs spec_version '{sr['spec_version']}' != its folder '{sv}'"
            assert str(sr.get("product")) == str(t["code"]), \
                f"{t['code']}/{sv}: source_refs product '{sr.get('product')}' != registry code '{t['code']}'"
            for m in sr["source_materials"]:
                for k in item_req:
                    assert k in m, f"{t['code']}/{sv} source material missing '{k}': {m}"
                assert m["status"] in status_enum, \
                    f"{t['code']}/{sv}: invalid status '{m.get('status')}' (allowed: {sorted(status_enum)})"
                # presence: ANY in-repo (local, non-URL, non-TBD) path must exist — REGARDLESS of status.
                # A `reference_only` in-repo SNAPSHOT (e.g. the 202606 spec PDFs under the program-spec (Teams; scans retired))
                # is governed provenance too, so an accidental deletion must FAIL CI, not slip through. (External
                # http(s) links and `TBD` placeholders are intentionally not presence-checked.)
                p = str(m["path_or_link"])
                local = "://" not in p and not p.strip().upper().startswith("TBD")
                if local:
                    assert (REPO / p).exists(), \
                        f"{t['code']}/{sv}: source material missing on disk: {p} (status={m.get('status')})"


def test_codeowners_present_and_routes_governance():
    co = REPO / "CODEOWNERS"
    assert co.exists(), "root CODEOWNERS is missing"
    text = co.read_text(encoding="utf-8")
    assert "/governance/" in text and "/docs/" in text, "CODEOWNERS does not route /governance/ + /docs/"


def test_changelog_documents_active_spec_version():
    # Version-bump governance triangle: config spec_version <-> registry current_spec_version (the
    # lineage test) <-> CHANGELOG. Here: every active product's CHANGELOG must mention its current
    # spec_version, so a contract bump can't land without a documented entry.
    for t in load_yaml(PRODUCTS / "registry.yaml")["tumors"]:
        if t.get("status") != "active":
            continue
        sv = str(t.get("current_spec_version", ""))
        assert YYYYMM.match(sv), f"active {t['code']}: registry current_spec_version not YYYYMM: {sv!r}"
        ch = PRODUCTS / "oncology" / t["slug"] / "CHANGELOG.md"
        assert ch.exists(), f"active {t['code']} missing CHANGELOG.md"
        assert sv in ch.read_text(encoding="utf-8"), f"{t['code']} CHANGELOG.md does not document spec_version {sv}"


def test_governance_docs_fences_balanced():
    # Cheap doc-integrity gate (replaces a heavyweight markdown-lint action): code fences are balanced
    # and every ```mermaid block is closed, across the governed docs — so a bad edit can't corrupt them.
    docs = [REPO / "docs" / "REPO_STRUCTURE_AND_PROD_MIGRATION.md"]
    docs += sorted((REPO / "governance").rglob("*.md"))
    for d in docs:
        text = d.read_text(encoding="utf-8")
        fences = text.count("```")
        assert fences % 2 == 0, f"{d.name}: unbalanced ``` fences ({fences})"
        assert text.count("```mermaid") <= fences // 2, f"{d.name}: a ```mermaid block is unclosed"


def test_release_schema_signoff_matches_manifest():
    # release.schema.json sign_off properties must mirror engine.refresh.build_manifest's sign_off keys
    # exactly (catches the qc_reviewed_by/released_at drift) — manifest is the source of truth.
    from engine.refresh import build_manifest
    from engine.config import load_config
    schema = json.loads((GOV / "schemas" / "release.schema.json").read_text(encoding="utf-8"))
    schema_keys = set(schema["properties"]["sign_off"]["properties"])
    cfg = load_config(product_config(PRODUCTS, "prostate"),
                      overrides={"run.refresh": "2026q1", "run.source_schema": "s", "run.output_schema": "o"})
    m = build_manifest(cfg, tumor="mcrpc")
    assert set(m["sign_off"]) == schema_keys, f"sign_off drift: manifest {set(m['sign_off'])} vs schema {schema_keys}"


def test_release_schema_block_matches_validator():
    # the schema's release-block required fields must match what engine.refresh.validate_manifest enforces
    # at runtime (public/version/build_id/ads/views) — else a record can pass schema review but fail the
    # runtime validator. (The views[public] == ads condition stays a runtime check.)
    schema = json.loads((GOV / "schemas" / "release.schema.json").read_text(encoding="utf-8"))
    assert set(schema["properties"]["release"]["required"]) == {"public", "version", "build_id", "ads", "views"}


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
