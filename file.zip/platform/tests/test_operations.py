"""Tests for the operational layer cores (pure Python, no Spark): refresh manifests, the QC gate,
and the TFL plan + catalog cross-check. Run: python3 test_operations.py (or pytest).
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))
PRODUCTS = FRAMEWORK.parent / "products"

from engine.config import load_yaml, load_config   # noqa: E402
from engine.config import product_config, product_dir  # noqa: E402
from engine import refresh, qc, tfl                 # noqa: E402

PROSTATE = product_config(PRODUCTS, "prostate")
CATALOG = PRODUCTS / "metadata" / "catalog.yaml"
TFL = PRODUCTS / "_reporting" / "tfl" / "tfl_specs.yaml"
GOOD = {"run.refresh": "2026q1", "run.source_schema": "rwd", "run.output_schema": "out"}


# ---- refresh manifests -------------------------------------------------
def test_build_manifest_valid():
    cfg = load_config(PROSTATE, overrides=GOOD)
    m = refresh.build_manifest(cfg, tumor="mcrpc", git_commit="abc123",
                               counts={"total_rows": 100, "cohorts": {"Overall mCRPC": 100}},
                               qc={"passed": True, "failures": []})
    assert refresh.validate_manifest(m) == []
    # spec_version is the CalVer contract alone (202606), NOT the snapshot-filled 202606.2026q1 — the
    # data cut lives in `refresh`, so the manifest's two version axes don't duplicate.
    assert m["spec_version"] == "202606" and m["refresh"] == "2026q1" and m["status"] == "qc_passed"
    assert m["output_table"] == "out.rwdp_pros_pano_202606"
    # build-level provenance: engine version + product id in the manifest (keyed by spec_version+refresh)
    import re as _re
    assert _re.match(r"^\d+\.\d+\.\d+$", m["engine_version"]) and m["data_product_id"] == "prostate_mcrpc_rwdp"


def test_manifest_published_at_marks_publish():
    # The PRE-publish ledger has published_at=None (QC passed but NOT published); the runner sets it
    # only AFTER a successful swap. A null published_at must never look like a successful publish.
    cfg = load_config(PROSTATE, overrides=GOOD)
    pre = refresh.build_manifest(cfg, tumor="mcrpc", counts={"total_rows": 1}, qc={"passed": True})
    assert pre["status"] == "qc_passed" and pre["published_at"] is None
    post = refresh.build_manifest(cfg, tumor="mcrpc", counts={"total_rows": 1}, qc={"passed": True},
                                  published_at="2026-06-03T16:00:00+00:00")
    post["release"] = {"public": "out.x", "version": "2026q1", "build_id": "abc123",
                       "ads": "out.x__2026q1__abc123", "views": {"out.x": "out.x__2026q1__abc123"}}
    assert post["published_at"] == "2026-06-03T16:00:00+00:00"
    assert refresh.validate_manifest(pre) == [] and refresh.validate_manifest(post) == []
    # a published manifest WITHOUT a release pointer is invalid
    no_rel = {**post}; no_rel.pop("release")
    assert any("release pointer" in p for p in refresh.validate_manifest(no_rel))
    # a release pointer MISSING build_id (or whose views[public] != ads) is invalid
    bad_bid = {**post, "release": {k: v for k, v in post["release"].items() if k != "build_id"}}
    assert any("build_id" in p for p in refresh.validate_manifest(bad_bid))
    bad_anchor = {**post, "release": {**post["release"], "views": {"out.x": "out.x__2026q1__WRONG"}}}
    assert any("views[public]" in p for p in refresh.validate_manifest(bad_anchor))


def test_manifest_missing_fields_flagged():
    assert any("missing" in p for p in refresh.validate_manifest({"tumor": "x"}))


def test_write_manifest_roundtrip():
    import tempfile
    cfg = load_config(PROSTATE, overrides=GOOD)
    m = refresh.build_manifest(cfg, tumor="mcrpc", counts={"total_rows": 5}, qc={"passed": True})
    path = refresh.write_manifest(m, tempfile.mkdtemp())
    # SPEC-VERSIONED ledger path: refreshes/<family>/<product>/<spec_version>/<refresh>.yaml — so 202603
    # and 202606 manifests for the same refresh never collide.
    assert path.replace("\\", "/").endswith("refreshes/oncology/mcrpc/202606/2026q1.yaml")
    back = load_yaml(path)
    assert back["tumor"] == "mcrpc" and back["family"] == "oncology" and back["spec_version"] == "202606"


def test_spec_versioned_ledger_paths():
    # The refreshes/ manifest and releases/ evidence dirs are spec-versioned + family-scoped, so two
    # contracts of the same product (202603 vs 202606) never collide for the same refresh.
    cfg = load_config(PROSTATE, overrides=GOOD)
    m = refresh.build_manifest(cfg, tumor="mcrpc", counts={"total_rows": 1}, qc={"passed": True})
    assert refresh.manifest_path(m, "/r").as_posix() == "/r/refreshes/oncology/mcrpc/202606/2026q1.yaml"
    assert refresh.release_dir("/r", m, "abc_run1").as_posix() == "/r/releases/oncology/mcrpc/202606/2026q1/abc_run1"


def test_write_manifest_refuses_invalid():
    try:
        refresh.write_manifest({"tumor": "x"}, "/tmp")
    except ValueError:
        return
    raise AssertionError("expected write_manifest to refuse an invalid manifest")


def test_released_requires_signoff():
    cfg = load_config(PROSTATE, overrides=GOOD)
    m = refresh.build_manifest(cfg, tumor="mcrpc", counts={"total_rows": 1},
                               qc={"passed": True})
    m["status"] = "released"
    assert any("released" in p for p in refresh.validate_manifest(m))


def test_released_requires_git_commit():
    cfg = load_config(PROSTATE, overrides=GOOD)
    m = refresh.build_manifest(cfg, tumor="mcrpc", git_commit=None, counts={"total_rows": 1},
                               qc={"passed": True})
    m["status"] = "released"
    m["sign_off"]["released_by"] = "qa"     # isolate the git_commit requirement
    assert any("git_commit" in p for p in refresh.validate_manifest(m))
    m["git_commit"] = "abc123"
    # a released manifest must ALSO carry published_at + a release pointer + a passed tfl_promotion
    # (it was published, with the public views swapped, at run time)
    m["published_at"] = "2026-06-03T16:00:00+00:00"
    m["release"] = {"public": "out.x", "version": "2026q1", "build_id": "abc123",
                    "ads": "out.x__2026q1__abc123", "views": {"out.x": "out.x__2026q1__abc123"}}
    m["tfl_promotion"] = {"passed": True, "promoted": []}
    assert refresh.validate_manifest(m) == []


def test_released_requires_published_and_release():
    # 'released' is set only after a successful publish -> published_at + a release pointer are required,
    # not just QC + sign-off (a manifest can't be marked released while still showing published_at=null).
    cfg = load_config(PROSTATE, overrides=GOOD)
    m = refresh.build_manifest(cfg, tumor="mcrpc", git_commit="abc123", counts={"total_rows": 1},
                               qc={"passed": True})
    m["status"] = "released"; m["sign_off"]["released_by"] = "qa"
    probs = refresh.validate_manifest(m)   # has git_commit + sign-off but NOT published_at/release/promotion
    assert any("published_at" in p for p in probs) and any("release pointer" in p for p in probs)
    assert any("tfl_promotion" in p for p in probs)


def test_manifest_validates_source_union_and_tfl_promotion():
    cfg = load_config(PROSTATE, overrides=GOOD)
    base = refresh.build_manifest(cfg, tumor="mcrpc", git_commit="abc", counts={"total_rows": 1},
                                  qc={"passed": True})
    assert refresh.validate_manifest(base) == []                          # prostate: source_union None
    assert any("source_union" in p for p in
               refresh.validate_manifest({**base, "source_union": {"discriminator": "db"}}))  # no members
    assert any("tfl_promotion" in p for p in
               refresh.validate_manifest({**base, "tfl_promotion": {"promoted": []}}))         # no 'passed'
    assert refresh.validate_manifest(
        {**base, "source_union": {"members": [{"schema": "s", "flag": "EDM"}]},
         "tfl_promotion": {"passed": True, "promoted": ["t1"]}}) == []


# ---- QC gate -----------------------------------------------------------
def test_qc_gate_passes_clean_report():
    rep = {"n_rows": 100, "catchall_rate": {"lot1cat": 0.1}, "stage_check_rate": 0.0}
    assert qc.qc_gate(rep)["passed"]


def test_qc_gate_fails_on_smells():
    rep = {"n_rows": 0, "catchall_rate": {"lot1cat": 0.9}, "stage_check_rate": 0.5,
           "uncastable_date_rate": {"dthdt": 0.2}}
    g = qc.qc_gate(rep)
    assert not g["passed"] and len(g["failures"]) >= 3


def test_source_qc_gate():
    assert qc.source_qc_gate({"patients_with_conflicting_death_dates": 5})["passed"]   # no threshold
    assert not qc.source_qc_gate({"mortality_qc_error": "boom"})["passed"]            # read error
    g = qc.source_qc_gate({"patients_with_conflicting_death_dates": 5}, {"max_death_conflicts": 0})
    assert not g["passed"] and "conflicting" in g["failures"][0]


def test_manifest_carries_artifacts():
    cfg = load_config(PROSTATE, overrides=GOOD)
    m = refresh.build_manifest(cfg, tumor="mcrpc", counts={"total_rows": 1}, qc={"passed": True},
                               artifacts={"qc_report": "/x/qc.md", "dictionary": "/x/dict.md"})
    assert refresh.validate_manifest(m) == []
    assert m["artifacts"]["qc_report"] == "/x/qc.md"


def test_manifest_carries_source_qc_and_deliverables():
    cfg = load_config(PROSTATE, overrides=GOOD)
    m = refresh.build_manifest(
        cfg, tumor="mcrpc", counts={"total_rows": 1}, qc={"passed": True},
        source_qc={"mortality_granularity": {"10": 90, "7": 10},
                   "patients_with_conflicting_death_dates": 3},
        source_qc_gate={"passed": True, "failures": []},
        deliverables={"dictionary": {"status": "ok", "audiences": ["internal"]},
                      "tfls": {"status": "empty", "tfls": []}})
    assert refresh.validate_manifest(m) == []
    # full source-QC REPORT preserved in the ledger, not just the gate
    assert m["source_qc"]["mortality_granularity"]["7"] == 10
    assert m["source_qc"]["patients_with_conflicting_death_dates"] == 3
    assert m["source_qc_gate"]["passed"] is True
    assert m["deliverables"]["dictionary"]["status"] == "ok"


def test_qc_thresholds_merge_config():
    cfg = load_config(PROSTATE, overrides=GOOD)
    assert qc.qc_thresholds(cfg)["min_rows"] == 1   # framework default present


# ---- TFL ---------------------------------------------------------------
def test_tfl_variables_resolve_to_catalog():
    catalog = {v["code"] for v in load_yaml(CATALOG)["variables"]}
    for t in tfl.load_specs(TFL)["tfls"]:
        for v in tfl.tfl_variables(t):
            assert v in catalog, f"TFL {t['id']} references unknown variable '{v}'"


def test_tfl_platinum_table_not_producible_without_plat_sen():
    # The OC-only platinum table (where plat_sen_v1 IS NOT NULL) is not producible on a prostate-like
    # ADS — so generate() skips it instead of erroring on the unresolved `where` column.
    specs = tfl.load_specs(TFL)
    prostate_cols = ["cohort", "lot1cat", "os", "dthfl", "ecog", "bmi", "stage"]
    assert tfl.tfl_plan(specs, prostate_cols)["t4_platinum"]            # missing plat_sen_v1 -> skip
    assert tfl.tfl_plan(specs, prostate_cols + ["plat_sen_v1"])["t4_platinum"] == []   # OC: producible


def test_every_tfl_with_where_declares_where_columns():
    # Keep the standard safe as TFLs expand: a `where` without `where_columns` could reintroduce the
    # unresolved-column failure (generate() can only pre-check columns it's told about).
    for t in tfl.load_specs(TFL)["tfls"]:
        if t.get("where"):
            assert t.get("where_columns"), f"TFL {t['id']} has `where` but no `where_columns`"


def test_tfl_plan_missing_and_lotcat_resolution():
    specs = tfl.load_specs(TFL)
    assert tfl.tfl_plan(specs, ["cohort", "agegrl"])["t1_demographics"]   # still missing some vars
    # catalog 'lotcat' is satisfied by a per-line lot<i>cat column
    assert tfl.tfl_plan(specs, ["cohort", "lot1cat"])["t3_treatment"] == []


def test_tfl_qc_gate_required_vs_optional_split():
    # The TFL QC gate (enforced in the runner) must NOT block a governed publish for a TFL the product
    # legitimately doesn't produce. The tumor-specific TFLs are required: false (warn, not fail); the
    # core ones default required (fail if unproducible). Guards the spec config so a future edit can't
    # silently make a conditional TFL required and block every non-OC / non-PFS product.
    specs = tfl.load_specs(TFL)
    by_id = {t["id"]: t for t in specs["tfls"]}
    for opt in ("t4_platinum", "f2_pfs_km", "f3_pfs2_km"):
        assert by_id[opt].get("required") is False, f"{opt} must be required: false (conditional TFL)"
    for req in ("t1_demographics", "t2_clinical", "t3_treatment", "f1_os_km", "l1_patient"):
        assert by_id[req].get("required", True) is True, f"{req} must be required (core TFL)"
    # a prostate-like ADS (core columns + OS + PFS, but no platinum / PFS2) -> gate PASSES (the missing
    # OC/PFS2 TFLs only WARN); flip a core column out and it FAILS.
    cols = ["cohort", "agegrl", "regionl", "race", "eth", "practic", "ses", "ecog", "bmi", "stage",
            "lot1cat", "os", "dthfl", "pfs", "pfsfl", "lotn"]
    gate = tfl.tfl_qc(specs, tfl.tfl_plan(specs, cols, hard=True))
    assert gate["passed"], [r for r in gate["tfls"] if r["status"] == "failure"]
    assert {r["status"] for r in gate["tfls"] if r["id"] in ("t4_platinum", "f3_pfs2_km")} == {"warning"}
    bad = tfl.tfl_qc(specs, tfl.tfl_plan(specs, [c for c in cols if c != "os"], hard=True))   # drop a required input
    assert not bad["passed"]


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
