"""Tests for the pure-Python cores of the QC layer and golden-comparison harness (no Spark).
Run: python3 test_qc_golden.py (or pytest). The Spark execution paths are cluster-only.
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))

from engine.config import load_config, product_config, product_dir   # noqa: E402
from engine import qc, golden           # noqa: E402

CONFIG = product_config(FRAMEWORK.parent / "products", "prostate")   # reference tumor


def test_qc_spec_from_config():
    spec = qc.qc_spec(load_config(CONFIG))
    assert "cohort" in spec["categorical"]
    assert "lot1cat" in spec["treatment_catchall"]["columns"]
    assert spec["treatment_catchall"]["label"] == "Any other therapy"
    assert spec["stage_check"]["label"] == "CHECK"
    assert "index_date" in spec["date_columns"]


def test_compare_columns():
    d = golden.compare_columns(["a", "b", "c"], ["b", "c", "d"])
    assert d["only_in_new"] == ["a"]
    assert d["only_in_ref"] == ["d"]
    assert d["shared"] == ["b", "c"]


def test_summarise_diff():
    d = golden.summarise_diff({"overall": 110, "lot1": 5}, {"overall": 100})
    assert d["overall"]["delta"] == 10 and d["overall"]["pct"] == 10.0
    assert d["lot1"]["ref"] == 0 and d["lot1"]["pct"] is None   # divide-by-zero guarded


def test_golden_gate_skips_without_reference():
    g = golden.golden_gate(None)
    assert g["passed"] and g.get("skipped")           # no reference -> skip (pass)


def test_golden_gate_passes_small_drift():
    summary = {
        "n_rows": {"new": 1020, "ref": 1000},                              # +2%
        "cohort_counts": {"overall": {"new": 1020, "ref": 1000, "pct": 2.0}},
        "os_summary": {"new": {"median": 12.0}, "ref": {"median": 12.5}},  # ~4%
        "columns": {"only_in_new": ["extra"], "only_in_ref": []},          # extra new col is OK
    }
    assert golden.golden_gate(summary)["passed"]


def test_golden_gate_fails_on_big_drift_and_dropped_columns():
    summary = {
        "n_rows": {"new": 1500, "ref": 1000},                              # +50%
        "cohort_counts": {"lot1": {"new": 400, "ref": 100, "pct": 300.0}},
        "os_summary": {"new": {"median": 20.0}, "ref": {"median": 10.0}},  # +100%
        "columns": {"only_in_new": [], "only_in_ref": ["dthdt"]},          # dropped a column
    }
    g = golden.golden_gate(summary)
    assert not g["passed"] and len(g["failures"]) >= 4


def test_golden_gate_flags_pfs_median_drift():
    # PFS / PFS2 median drift is gated exactly like OS, and is a no-op when the summary is absent.
    base = {"n_rows": {"new": 100, "ref": 100}}
    assert golden.golden_gate(base)["passed"]                                       # no tte summaries
    pfs = {**base, "pfs_summary": {"new": {"median": 18.0}, "ref": {"median": 9.0}}}   # +100%
    g = golden.golden_gate(pfs)
    assert not g["passed"] and any("PFS median drift" in f for f in g["failures"])
    pfs2 = {**base, "pfs2_summary": {"new": {"median": 20.0}, "ref": {"median": 10.0}}}
    assert any("PFS2 median drift" in f for f in golden.golden_gate(pfs2)["failures"])


def test_golden_gate_flags_distribution_drift():
    summary = {
        "n_rows": {"new": 1000, "ref": 1000},
        "distributions": {"lot1cat": {
            "Docetaxel monotherapy": {"new": 300, "ref": 100, "pct": 200.0},  # ref>=30 -> flagged
            "rare": {"new": 5, "ref": 1, "pct": 400.0},                        # ref<30 -> ignored (noise)
        }},
        "columns": {"only_in_new": [], "only_in_ref": []},
    }
    g = golden.golden_gate(summary)
    assert not g["passed"]
    assert any("lot1cat='Docetaxel monotherapy'" in f for f in g["failures"])
    assert not any("rare" in f for f in g["failures"])   # tiny reference category ignored


def test_golden_prefers_cohort_indexed_lotcat():
    # distribution drift must compare the cohort-indexed `lotcat` (not first-line lot1cat) whenever
    # both tables share it; lot1cat is only a legacy fallback — mirrors tfl.generate().
    base = ["stage", "ecog", "race", "regionl"]
    both = base + ["lotcat", "lot1cat"]
    cols = golden._dist_columns(both, both)
    assert "lotcat" in cols and "lot1cat" not in cols
    legacy = base + ["lot1cat"]                                            # pre-lotcat ADS
    assert golden._dist_columns(legacy, legacy)[-1] == "lot1cat"
    mixed = golden._dist_columns(base + ["lotcat"], base + ["lot1cat"])    # names differ -> not shared
    assert "lotcat" not in mixed and "lot1cat" not in mixed


def test_golden_thresholds_merge_config():
    cfg = load_config(CONFIG)
    assert golden.golden_thresholds(cfg)["max_row_delta_pct"] == 10.0   # framework default present


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
