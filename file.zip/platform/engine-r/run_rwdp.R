# R (sparklyr) entry point for the RWDP build — the side-by-side twin of databricks/run_rwdp.py.
#
# Runs ANY tumor on the SHARED, config-driven R engine: read params, load that tumor's
# config/data_product.yaml (same file the Python engine uses), build the ADS, write it. Behaviour
# lives in config/ + variables/ + codelists/ — switch tumor by pointing config_path elsewhere;
# switch snapshot via refresh. No code change.
#
# REVIEW-ONLY here (needs sparklyr + a Spark cluster + the `yaml` package). On Databricks run with
# the R kernel (the bundle deploys engine-r/ alongside platform/engine/). ACCEPTANCE GATE: the
# R ADS must golden-compare clean against the Python ADS (engine/golden.py) before it is relied on.
#
# ENVIRONMENT-AGNOSTIC connection: defaults to a Databricks-managed cluster, but runs on Domino /
# YARN / standalone / local Spark too — pass --spark_method / --spark_master (or env SPARK_METHOD /
# SPARK_MASTER / SPARK_VERSION). The engine reads/writes CATALOG tables, so any Spark whose metastore
# exposes the {source_schema} source tables and accepts the {output_schema} write works unchanged
# (see README "Running on Domino / generic Spark").
#
# Usage (FULL versioned config path; --allow_direct_write=true acknowledges the direct, non-governed
# write — point --output_schema at a SEPARATE validation schema, never the governed Python one):
#   # Databricks (default — managed cluster injects the master):
#   Rscript run_rwdp.R --allow_direct_write=true \
#     --config_path=/Workspace/<bundle>/products/oncology/prostate/202606/config/data_product.yaml \
#     --refresh=2026q1 --source_schema=<src> --output_schema=<out>_r
#   # Domino / generic Spark (YARN, standalone, or local[*] for a single node):
#   Rscript run_rwdp.R --spark_master=yarn --allow_direct_write=true \
#     --config_path=/mnt/code/products/oncology/prostate/202606/config/data_product.yaml \
#     --refresh=2026q1 --source_schema=<src> --output_schema=<out>_r

suppressPackageStartupMessages({
  library(sparklyr); library(dplyr); library(dbplyr)
})

# --- locate engine-r/ and source the shared logic (PROVEN compilers + review-only orchestration) --
.engine_dir <- function() {
  # Rscript: derive from --file=; sourced: from sys.frame ofile; else cwd.
  a <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (length(a)) return(dirname(normalizePath(sub("^--file=", "", a[1]))))
  if (!is.null(sys.frame(1)$ofile)) return(dirname(normalizePath(sys.frame(1)$ofile)))
  normalizePath(".")
}
ENGINE_R <- Sys.getenv("ENGINE_R_DIR", unset = .engine_dir())
for (f in c("vendors.R", "config.R", "codelists.R", "cases.R", "stages.R", "build_ads.R"))
  source(file.path(ENGINE_R, f))

# --- parse --key=value args (Databricks job params / notebook widgets map to these) --------------
.parse_args <- function() {
  kv <- list()
  for (a in grep("^--", commandArgs(TRUE), value = TRUE)) {
    p <- sub("^--", "", a); i <- regexpr("=", p)
    if (i > 0) kv[[substr(p, 1, i - 1)]] <- substr(p, i + 1, nchar(p))
  }
  kv
}
args <- .parse_args()
config_path <- args[["config_path"]] %||% Sys.getenv("CONFIG_PATH", "")
if (!nzchar(config_path)) stop("config_path is required (a tumor's config/data_product.yaml).")

overrides <- list("run.refresh"       = args[["refresh"]]       %||% "",
                  "run.source_schema" = args[["source_schema"]] %||% "",
                  "run.output_schema" = args[["output_schema"]] %||% "")
cfg <- load_config(config_path, overrides)   # yaml::read_yaml + dotted overrides (config.R)

message(sprintf("Product : %s  version %s", cfg$raw[["name"]], cfg_version(cfg)))
message(sprintf("Engine  : %s (R/sparklyr)", ENGINE_R))
message(sprintf("Refresh : %s", cfg_refresh(cfg)))
message("Sources :")
tabs <- cfg_all_tables(cfg)
for (nm in names(tabs)) message(sprintf("          %-14s %s", nm, tabs[[nm]]))
message(sprintf("Output  : %s  (mode=%s)", cfg_output_fqn(cfg), cfg_write_mode(cfg)))
# SAFETY: this R runner is a side-by-side VALIDATION build — it writes the ADS table DIRECTLY (no
# staging/swap, no release pointer, no manifest; those are the Python governed runner). Point
# --output_schema at a SEPARATE validation schema (e.g. <dev>_r): writing to the schema the governed
# Python path publishes to would OVERWRITE the public ADS. Then golden-compare R vs Python.
message(sprintf("WARNING : direct %s write of %s (no governed-release safety) — use a SEPARATE",
                cfg_write_mode(cfg), cfg_output_fqn(cfg)))
message("          --output_schema for R validation; never the governed Python output schema.")

# FAIL CLOSED on the direct write — a printed WARNING is too easy to miss in a batch run, and this
# runner can overwrite a governed ADS. Require an explicit acknowledgement: --allow_direct_write=true
# (or env R_ALLOW_DIRECT_WRITE=true). Re-run with it set AND --output_schema pointed at a SEPARATE
# validation schema. Checked BEFORE the Spark connect so a missing ack costs nothing.
allow_direct <- tolower(args[["allow_direct_write"]] %||% Sys.getenv("R_ALLOW_DIRECT_WRITE", "")) %in% c("1", "true", "yes")
if (!allow_direct) {
  stop(sprintf(paste0("REFUSING to run: this R runner writes %s DIRECTLY (no governed staging/swap/",
    "release pointer) and could overwrite a governed ADS. Re-run with --allow_direct_write=true to ",
    "acknowledge, and set --output_schema to a SEPARATE validation schema (never the governed Python ",
    "output schema)."), cfg_output_fqn(cfg)))
}

# --- connect (environment-agnostic), build, write -----------------------------------------------
# Default = Databricks-managed; override for Domino/YARN/standalone/local via --spark_method /
# --spark_master (env: SPARK_METHOD / SPARK_MASTER / SPARK_VERSION). connect_spark() lives in
# build_ads.R so a Databricks R notebook can reuse the same seam.
spark_method  <- args[["spark_method"]]  %||% Sys.getenv("SPARK_METHOD",  "databricks")
spark_master  <- args[["spark_master"]]  %||% Sys.getenv("SPARK_MASTER",  "")
spark_version <- args[["spark_version"]] %||% Sys.getenv("SPARK_VERSION", "")
message(sprintf("Spark   : method=%s master=%s", spark_method,
                if (nzchar(spark_master)) spark_master else "(managed)"))
sc <- connect_spark(spark_method, spark_master, spark_version)
on.exit(try(sparklyr::spark_disconnect(sc), silent = TRUE), add = TRUE)  # ALWAYS close (even on build/write error) — no leaked session
ads <- build_ads(sc, cfg)
fqn <- write_ads(sc, ads, cfg)
message(sprintf("Published to %s", fqn))

# NOTE: source/ADS QC gates, golden-compare, manifest, dictionary + TFLs are driven from the Python
# runner (databricks/run_rwdp.py), which is the production lifecycle. This R runner is the
# cross-validation build: produce the R ADS, then golden-compare it against the Python ADS.
