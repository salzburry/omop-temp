# `engine-r/` — the R engine, side by side with PySpark

A second implementation of the RWDP engine in **R**, sharing the **same config/YAML** as the
PySpark engine (`platform/engine/`). The team is R-proficient, so this lets you **read and
validate the logic in R**, and lets the two engines **cross-check** each other: same config in →
the same Spark SQL / ADS out.

> **One source of truth for behaviour.** Both engines read the identical `config/`, `variables/`,
> `codelists/` for each tumor. There is no second copy of the rules — only a second engine that
> interprets them. A spec change is one YAML edit, reviewed once, honoured by both.

---

## The parity contract — what's PROVEN vs what's REVIEW-ONLY

The engine is *code-locked, config-driven*: all the business logic lives in config and is turned
into Spark SQL by a small set of **pure compiler functions**. Those compilers are the part where
bugs hide — and they are **proven byte-identical** between R and Python.

### ✅ Proven identical (executed in CI by `platform/tests/test_r_parity.py`)

`test_r_parity.py` loads each real tumor's config, runs **both** the Python compiler and the R
compiler (via `Rscript`) on the **same parsed input**, and asserts the emitted Spark SQL matches
**character for character**:

| R file | mirrors | what's proven |
|---|---|---|
| `codelists.R` | `engine/codelists.py` | the 17-way treatment-category `CASE` (lotcat/lotcatn) for prostate / oc / endometrial / dlbcl / mds + a synthetic fixture covering every operator (`equals`, `like_any`, `regexp`, `category_equals`, `is_null`, `all_of`, `any_of`, `always`) and single-quote escaping |
| `vendors.R` + `config.R` | `engine/vendors.py` + `engine/config.py` | vendor-aware **table FQN** resolution (flatiron **and** cota), `source_layout` override, index source, lot line-setting, output FQN, version-snapshot substitution |
| `cases.R` | `engine/stages/{demographics,clinical,treatment}.py` helpers | age bands, region (state→region), race/ethnicity/practice crosswalks, BMI bands, AJCC/FIGO stage groups, line-count bands — **both** the label `CASE` and the numeric-code `CASE` |

Run it locally:

```bash
cd "platform"
python3 tests/test_r_parity.py     # 28 checks; skips cleanly if Rscript isn't installed
```

### 🔬 Review-only (faithful mirror; not executable in the authoring sandbox)

The Spark **orchestration** — reads, joins, windows, writes — needs a Spark connection
(`sparklyr`) and the `yaml` package, neither of which installs offline. These files mirror the
PySpark stages 1:1 in the team's native **sparklyr/dbplyr** idiom (the original RWDP was R/dbplyr)
and **source the proven compilers above**, so the business logic they apply is the verified logic.

| R file | mirrors |
|---|---|
| `stages.R` | `engine/stages/*.py` (sources, lot, index, demographics, clinical, treatment, outcomes, assemble) |
| `build_ads.R` | `engine/build_ads.py` (per-cohort build → union) |
| `run_rwdp.R` | `databricks/run_rwdp.py` (the tumor-agnostic entry point) |

Where a Python stage builds an **inline** SQL string (the clinical death/follow-up imputation, the
OS anchor, the ECOG code map, BMI), the R file builds the **same string line-for-line** so a
reviewer can diff R vs Python directly. These inline expressions are **not yet** independently
parity-tested (they're embedded in the stage builders, not in the pure compilers) — see *Next* below.

> **Acceptance gate for the R engine:** run it on Databricks and **golden-compare** the R ADS
> against the Python ADS with `engine/golden.py` (row/cohort counts, lotcat distribution, OS
> summary, column diff). Treat the R ADS as validated only once that diff is clean. This is the
> same gate every refresh already passes (see `OPERATIONS.md`).

---

## File map & load order

```
engine-r/
  vendors.R     # vendor → table-layout template            (pure, proven)
  config.R      # resolved view over data_product.yaml       (pure helpers proven; load_config review-only)
  codelists.R   # treatment-category CASE compiler           (pure, proven)
  cases.R       # banding/mapping/stage CASE compilers        (pure, proven)
  stages.R      # sparklyr/dbplyr stage builders              (review-only)
  build_ads.R   # per-cohort orchestration + write           (review-only)
  run_rwdp.R   # entry point: Databricks OR Domino/generic   (review-only)
```

Source order (dependencies first):

```r
source("vendors.R"); source("config.R")          # config + vendor resolution
source("codelists.R"); source("cases.R")          # the proven SQL compilers
source("stages.R"); source("build_ads.R")         # Spark orchestration (needs sparklyr at run time)
```

`run_rwdp.R` does this for you and then `load_config()` → `build_ads()` → `write_ads()`.

## Running the R engine

**Databricks** (default — the managed cluster injects the master):

```bash
Rscript run_rwdp.R --allow_direct_write=true \
  --config_path=/Workspace/<bundle>/products/oncology/prostate/202606/config/data_product.yaml \
  --refresh=2026q1 --source_schema=<src> --output_schema=<out>_r
```

**Domino / generic Spark** (YARN, standalone, or `local[*]` for a single node) — the connection is a
single seam (`connect_spark()` in `build_ads.R`), so only the Spark *connection* changes, never the
engine logic:

```bash
# YARN (typical Domino on-demand Spark):
Rscript run_rwdp.R --spark_master=yarn --allow_direct_write=true \
  --config_path=/mnt/code/products/oncology/prostate/202606/config/data_product.yaml \
  --refresh=2026q1 --source_schema=<src> --output_schema=<out>_r

# Local single node (smoke a small cut):
Rscript run_rwdp.R --spark_master='local[*]' --allow_direct_write=true \
  --config_path=/mnt/code/products/oncology/prostate/202606/config/data_product.yaml \
  --refresh=2026q1 --source_schema=<src> --output_schema=<out>_r
```

> **`--allow_direct_write=true` is required (fail-closed).** The R runner writes the ADS *directly* —
> no governed staging/swap/release pointer — so it **refuses to run** without this acknowledgement, and
> `--output_schema` should be a **separate** validation schema (the `_r` suffix above), never the
> governed Python output schema. Then golden-compare the R ADS against the Python ADS.

Override the connection with `--spark_method` / `--spark_master` / `--spark_version` (or env
`SPARK_METHOD` / `SPARK_MASTER` / `SPARK_VERSION`); the default stays `method=databricks`.

> **Catalog prerequisite — the one thing the runner can't infer.** The engine reads and writes
> **catalog tables** by FQN (`dplyr::tbl(sc, "{source_schema}.{stem}_{refresh}")` and
> `spark_write_table("{output_schema}.{output_table}")`). A non-Databricks Spark therefore needs a
> metastore (Hive / Unity / Glue) whose catalog exposes the `{source_schema}` source tables and
> accepts the `{output_schema}` write. If on Domino the data lives as **files** rather than catalog
> tables, register them as external/temp views first (or add a file-based reader) — the *connection*
> seam is parameterized; the data **layout** is the remaining environmental requirement.

Uses the same product **config** and the `--refresh` / `--source_schema` / `--output_schema`
overrides — but **not** the Python runner's release/governance widgets (`tumor_slug`, `spec_version`,
`artifact_root`, `reference_table`, `git_commit`, `run_id`, waiver): the R runner builds and writes the
ADS, it is **not** the governed lifecycle. Switch tumor/version by pointing `--config_path` at another
pack; switch snapshot via `--refresh`. Then golden-compare against the Python ADS — writing into a
**separate** output schema (the R runner warns about this; never target the governed Python schema).

## How parity is kept honest

- **CI** runs `test_r_parity.py` on every PR that touches `platform/**` or `products/**` (a dedicated
  job installs R), so a config change that would make the two engines diverge fails the build.
- Adding a new tumor: drop its config in, add it to `test_r_parity.py`'s tumor list — parity is
  then enforced for it too. (Config/vendor parity already iterates every registered tumor.)

## Next (extend proven parity)

The inline SQL in `clinical.R`/`outcomes.R` (death-date imputation, OS, ECOG code map, BMI) is a
faithful mirror but is **only review-verified** today. To bring it under the proven umbrella,
extract each inline builder into a pure function in **both** engines (e.g. `engine/sql_expr.py` ↔
`engine-r/sql_expr.R`) and add a parity case — exactly as was done for the codelist and the six
banding/stage compilers. The intricate death/follow-up imputation should be extracted carefully and
golden-compared (it was mid-revision in the original R).
