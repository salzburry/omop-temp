# R mirror of the pure CASE-expression compilers in engine/stages/{demographics,clinical,treatment}.py
# (the `_bands_case` / `_map_case` / `_region_case` / `_num_bands_case` / `_stage_case` /
# `_lot_bands_case` helpers). These turn reviewed config (age bands, region/race/ethnicity/practice
# crosswalks, BMI bands, stage groupings, line-count bands) into Spark SQL CASE strings.
#
# Pure (no IO, no Spark). Parity with the Python helpers is enforced byte-for-byte by
# tests/test_r_parity.py for BOTH the label CASE and the numeric-code CASE.

if (!exists("%||%")) `%||%` <- function(a, b) if (is.null(a)) b else a   # self-contained for parity

.q <- function(s) paste0("'", gsub("'", "''", as.character(s), fixed = TRUE), "'")

# out value for a band/row: quoted label, or the raw code as a string.
.out_val <- function(item, key) if (identical(key, "label")) .q(item[[key]]) else as.character(item[[key]])

# first item whose `when` == w, else NULL.
.first_when <- function(items, w) {
  for (it in items) if (identical(it[["when"]], w)) return(it)
  NULL
}

# demographics: CASE over numeric bands with eq/ge/min/max/max_excl bounds + fallthrough (agegrl…).
bands_case <- function(bands, value_expr, key = "label") {
  whens <- character(0)
  for (b in bands) {
    out <- .out_val(b, key)
    if (identical(b[["when"]], "fallthrough")) next
    conds <- character(0)
    if (!is.null(b[["eq"]]))       conds <- c(conds, sprintf("%s = %s",  value_expr, as.character(b[["eq"]])))
    if (!is.null(b[["ge"]]))       conds <- c(conds, sprintf("%s >= %s", value_expr, as.character(b[["ge"]])))
    if (!is.null(b[["min"]]))      conds <- c(conds, sprintf("%s >= %s", value_expr, as.character(b[["min"]])))
    if (!is.null(b[["max"]]))      conds <- c(conds, sprintf("%s <= %s", value_expr, as.character(b[["max"]])))
    if (!is.null(b[["max_excl"]])) conds <- c(conds, sprintf("%s < %s",  value_expr, as.character(b[["max_excl"]])))
    if (length(conds) > 0)
      whens <- c(whens, sprintf("WHEN %s THEN %s", paste(conds, collapse = " AND "), out))
  }
  default <- .first_when(bands, "fallthrough")
  tail <- if (!is.null(default)) paste0(" ELSE ", .out_val(default, key)) else ""
  paste0("CASE ", paste(whens, collapse = " "), tail, " END")
}

# demographics: CASE over a source-value -> reported-value crosswalk (race/ethnicity/practice).
map_case <- function(rows, value_expr, key = "label") {
  whens <- character(0)
  for (r in rows) {
    out <- .out_val(r, key)
    if (!is.null(r[["from"]])) {
      vals <- paste(vapply(r[["from"]], function(v) .q(tolower(as.character(v))), ""), collapse = ", ")
      whens <- c(whens, sprintf("WHEN LOWER(%s) IN (%s) THEN %s", value_expr, vals, out))
    }
  }
  default <- .first_when(rows, "fallthrough")
  tail <- if (!is.null(default)) paste0(" ELSE ", .out_val(default, key)) else ""
  paste0("CASE ", paste(whens, collapse = " "), tail, " END")
}

# demographics: CASE over state -> region, with state_is_null -> Missing (leading) and fallthrough.
region_case <- function(rows, col, key = "label") {
  whens <- character(0); missing <- NULL; default <- NULL
  for (r in rows) {
    out <- .out_val(r, key)
    if (identical(r[["when"]], "state_is_null")) {
      missing <- out
    } else if (identical(r[["when"]], "fallthrough")) {
      default <- out
    } else if (!is.null(r[["states"]])) {
      vals <- paste(vapply(r[["states"]], function(s) .q(s), ""), collapse = ", ")
      whens <- c(whens, sprintf("WHEN %s IN (%s) THEN %s", col, vals, out))
    }
  }
  pre  <- if (!is.null(missing)) sprintf("WHEN %s IS NULL THEN %s ", col, missing) else ""
  tail <- if (!is.null(default)) paste0(" ELSE ", default) else ""
  paste0("CASE ", pre, paste(whens, collapse = " "), tail, " END")
}

# clinical: CASE over numeric bands (min/max_excl/max) + fallthrough. Used for BMI groups.
num_bands_case <- function(bands, col, key = "label") {
  whens <- character(0)
  for (b in bands) {
    if (identical(b[["when"]], "fallthrough")) next
    out <- .out_val(b, key)
    conds <- character(0)
    if (!is.null(b[["min"]]))      conds <- c(conds, sprintf("%s >= %s", col, as.character(b[["min"]])))
    if (!is.null(b[["min_excl"]])) conds <- c(conds, sprintf("%s > %s",  col, as.character(b[["min_excl"]])))
    if (!is.null(b[["max_excl"]])) conds <- c(conds, sprintf("%s < %s",  col, as.character(b[["max_excl"]])))
    if (!is.null(b[["max"]]))      conds <- c(conds, sprintf("%s <= %s", col, as.character(b[["max"]])))
    if (length(conds) > 0)
      whens <- c(whens, sprintf("WHEN %s THEN %s", paste(conds, collapse = " AND "), out))
  }
  default <- .first_when(bands, "fallthrough")
  tail <- if (!is.null(default)) paste0(" ELSE ", .out_val(default, key)) else ""
  paste0("CASE ", paste(whens, collapse = " "), tail, " END")
}

# clinical: CASE mapping a raw group-stage value to the configured grouping (AJCC/FIGO/Ann Arbor),
# with from_prefixes (exact values), from_equals_ci, and a fallthrough (e.g. 'CHECK').
stage_case <- function(groups, col, key = "label") {
  whens <- character(0)
  for (g in groups) {
    if (identical(g[["when"]], "fallthrough")) next
    out <- .out_val(g, key)
    conds <- character(0)
    if (length(g[["from_prefixes"]]) > 0)
      conds <- c(conds, sprintf("%s IN (%s)", col,
                 paste(vapply(g[["from_prefixes"]], function(v) .q(v), ""), collapse = ", ")))
    if (length(g[["from_equals_ci"]]) > 0)
      conds <- c(conds, sprintf("LOWER(%s) IN (%s)", col,
                 paste(vapply(g[["from_equals_ci"]], function(v) .q(tolower(as.character(v))), ""), collapse = ", ")))
    if (length(conds) > 0)
      whens <- c(whens, sprintf("WHEN (%s) THEN %s", paste(conds, collapse = " OR "), out))
  }
  default <- .first_when(groups, "fallthrough")
  tail <- if (!is.null(default)) paste0(" ELSE ", .out_val(default, key)) else ""
  paste0("CASE ", paste(whens, collapse = " "), tail, " END")
}

# treatment: CASE over lot_count_bands (eq/ge with a fallthrough). Builds lotngrl / lotngrln.
lot_bands_case <- function(bands, col, key = "label") {
  whens <- character(0); default <- NULL
  for (b in bands) {
    out <- .out_val(b, key)
    if (identical(b[["when"]], "fallthrough")) {
      default <- out
      next
    }
    conds <- character(0)
    if (!is.null(b[["eq"]])) conds <- c(conds, sprintf("%s = %s",  col, as.character(b[["eq"]])))
    if (!is.null(b[["ge"]])) conds <- c(conds, sprintf("%s >= %s", col, as.character(b[["ge"]])))
    if (length(conds) > 0)
      whens <- c(whens, sprintf("WHEN %s THEN %s", paste(conds, collapse = " AND "), out))
  }
  tail <- if (!is.null(default)) paste0(" ELSE ", default) else ""
  paste0("CASE ", paste(whens, collapse = " "), tail, " END")
}

# treatment: per-line column-name scheme (lot{i}* / lot{i}m*). Byte-identical to
# engine/stages/treatment.py::line_cols so the producer (treatment) and consumers (outcomes) cannot
# drift across engines; line_cols_canon joins the names for the parity fixture (test_r_parity.py).
line_cols <- function(i, maint = FALSE) {
  s <- if (isTRUE(maint)) "m" else ""
  list(name = paste0("lot", i, s), start = paste0("lot", i, s, "sd"),
       end = paste0("lot", i, s, "ld"), lastdate = paste0("lot", i, s, "ed"),
       dur = paste0("lot", i, s, "dur"),
       cat = paste0("lot", i, s, "cat"), catn = paste0("lot", i, s, "catn"))
}
line_cols_canon <- function(i, maint = FALSE) {
  lc <- line_cols(i, maint)
  paste(c(lc$name, lc$start, lc$end, lc$lastdate, lc$dur, lc$cat, lc$catn), collapse = "|")
}

# outcomes: per-line time-to-event CASE expressions (parameterised by the line number N). Byte-
# identical to engine/stages/outcomes.py (_trtdis_sql / _ttntfl_sql / _ttd_sql / _ttnt_sql) so the
# line outcomes are R<->Python parity-proven (tests/test_r_parity.py). dpm = days_per_month.
trtdis_sql <- function(n) {
  sprintf("CASE WHEN lotn > %s OR (lotn = %s AND dthdt IS NOT NULL) OR vis120 = 1 THEN 1 ELSE 0 END", n, n)
}
ttntfl_sql <- function(n) {
  sprintf("CASE WHEN lotn > %s OR dthfl = 1 THEN 1 ELSE 0 END", n)
}
ttd_sql <- function(n, dpm, maint = FALSE) {
  sprintf("datediff(%s, index_date)/%s", line_cols(n, maint)$lastdate, dpm)
}
ttnt_sql <- function(n, dpm, has_next) {
  nxt <- if (isTRUE(has_next)) sprintf("least(lot%ssd, dthdt)", n + 1) else "dthdt"
  sprintf(paste0("CASE WHEN ttntfl = 1 THEN (datediff(%s, index_date)+1)/%s ",
                 "WHEN ttntfl = 0 THEN (datediff(fued, index_date)+1)/%s ELSE 0 END"),
          nxt, dpm, dpm)
}
tsstfl_sql <- function(n) {
  sprintf("CASE WHEN lotn > %s OR dthfl = 1 THEN 1 ELSE 0 END", n + 1)
}
tsst_sql <- function(n, dpm, has_n2) {
  nxt <- if (isTRUE(has_n2)) sprintf("least(lot%ssd, dthdt)", n + 2) else "dthdt"
  sprintf(paste0("CASE WHEN tsstfl = 1 THEN (datediff(%s, index_date)+1)/%s ",
                 "WHEN tsstfl = 0 THEN (datediff(fued, index_date)+1)/%s ELSE 0 END"),
          nxt, dpm, dpm)
}

# treatment: SQL predicate matching a taxane line name (prior-taxane flags). Byte-identical to
# engine/stages/treatment.py::_taxane_pred (proven in tests/test_r_parity.py).
taxane_pred <- function(likes) {
  paste(vapply(likes, function(x) sprintf("lower(linename) LIKE '%s'", tolower(as.character(x))), ""),
        collapse = " OR ")
}

# outcomes: a progression EVENT predicate (any evidence flag == yes AND not pseudo-progression).
# Byte-identical to engine/stages/outcomes.py::_progression_pred (proven in tests/test_r_parity.py).
progression_pred <- function(evidence_cols, pseudo_col, yes = "Yes", no = "No") {
  ev <- paste(vapply(evidence_cols, function(c) sprintf("%s = '%s'", c, yes), ""), collapse = " OR ")
  sprintf("(%s) AND %s = '%s'", ev, pseudo_col, no)
}

# proc: SQL predicate matching a platinum agent in the line name. Byte-identical to
# engine/stages/proc.py::_platinum_pred (proven in tests/test_r_parity.py).
platinum_pred <- function(agents, name_col = "linename") {
  paste(vapply(agents, function(a) sprintf("lower(%s) LIKE '%s'", name_col, tolower(as.character(a))), ""),
        collapse = " OR ")
}

# proc: CASE mapping the platinum-free interval (months) to Sensitive/Resistant. Byte-identical to
# engine/stages/proc.py::_sensitivity_case (proven in tests/test_r_parity.py).
sensitivity_case <- function(threshold_months, pfi_col = "pfi") {
  sprintf("CASE WHEN %s IS NULL THEN NULL WHEN %s < %s THEN 'Resistant' ELSE 'Sensitive' END",
          pfi_col, pfi_col, threshold_months)
}

# clinical: a presence-flag CASE (column NULL -> absent label, else present label). Byte-identical to
# engine/stages/clinical.py::_presence_flag_sql (proven in tests/test_r_parity.py).
presence_flag_sql <- function(fl) {
  sprintf("CASE WHEN %s IS NULL THEN '%s' ELSE '%s' END", fl[["from"]], fl[["absent"]], fl[["present"]])
}

# clinical: OC surgery-classification CASEs (issurg/surg/surgn/neoadj). Byte-identical to
# engine/stages/clinical.py::_surgery_sql (proven in tests/test_r_parity.py).
surgery_sql <- function(scfg) {
  fl <- scfg[["surgery_flag_column"]]; dt <- scfg[["surgery_date_column"]]
  yes <- scfg[["yes_value"]] %||% "Yes"; no <- scfg[["no_value"]] %||% "No"
  pcs <- scfg[["pcs_label"]]; ics <- scfg[["ics_label"]]; none <- scfg[["none_label"]]
  typ <- sprintf(paste0("CASE WHEN %s IS NULL OR %s < _line1_start THEN '%s' ",
                        "WHEN %s >= _line1_start THEN '%s' ELSE '%s' END"), dt, dt, pcs, dt, ics, none)
  typn <- sprintf("CASE WHEN %s IS NULL OR %s < _line1_start THEN 1 WHEN %s >= _line1_start THEN 2 ELSE 3 END",
                  dt, dt, dt)
  list(
    issurg = sprintf(paste0("CASE WHEN %s = '%s' THEN 'Yes' WHEN %s = '%s' THEN '%s' ",
                            "WHEN %s != '%s' AND %s IS NULL THEN 'Unknown' ELSE 'Missing' END"),
                     fl, yes, fl, no, none, fl, yes, dt),
    surg = sprintf("CASE WHEN %s = '%s' THEN (%s) ELSE '%s' END", fl, yes, typ, none),
    surgn = sprintf("CASE WHEN %s = '%s' THEN (%s) ELSE 3 END", fl, yes, typn),
    neoadj = sprintf(paste0("CASE WHEN %s = '%s' AND %s >= _line1_start AND %s <= _line1_end ",
                            "THEN 'Yes' ELSE 'No' END"), fl, yes, dt, dt))
}
