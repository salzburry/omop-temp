#!/usr/bin/env python3
"""Pack this git repo into ONE text file — and unpack it back into a directory tree.
For copy/paste or transfer when zip / folder upload is blocked.

PACK (default): a header + file tree, then every tracked TEXT file inlined between
`==== BEGIN FILE: <path> ====` / `==== END FILE: <path> ====` markers (binaries are listed,
not inlined). TRACKED files only, so .gitignore'd / untracked and already-removed material
(e.g. the old nonprod/) are naturally excluded.

    python3 tools/export_repo.py                       # whole repo  -> repo_export.txt
    python3 tools/export_repo.py -o out.txt            # custom output path
    python3 tools/export_repo.py platform products      # only these paths (smaller, code-focused)

UNPACK: reconstruct the tree from a packed file. Byte-exact for the inlined text files;
binaries can't be restored (they were never inlined — see the BINARY list in the header).

    python3 tools/export_repo.py --unpack repo_export.txt --into ./restored

The default `repo_export.txt` is git-ignored scratch (see .gitignore). To keep a copy IN the repo,
pack to a NON-ignored path (e.g. `-o tools/repo_snapshot.txt`) and commit that — packing never
inlines its own output, so re-packing over a committed snapshot won't nest copies.
"""
import argparse
import datetime
import os
import re
import subprocess
import sys

BEGIN = "==== BEGIN FILE: {} ===="
END = "==== END FILE: {} ===="
BEGIN_RE = re.compile(r"^==== BEGIN FILE: (.+) ====$")


def git(*args, cwd="."):
    return subprocess.check_output(["git", *args], cwd=cwd, text=True)


def pack(pathspec, out):
    try:
        root = git("rev-parse", "--show-toplevel").strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        sys.exit("error: not inside a git repository (or git not found)")

    files = sorted(f for f in git("ls-files", "--", *pathspec, cwd=root).splitlines() if f.strip())
    if not files:
        sys.exit("error: no tracked files matched the given pathspec")
    try:
        sha = git("rev-parse", "--short", "HEAD", cwd=root).strip()
        branch = git("rev-parse", "--abbrev-ref", "HEAD", cwd=root).strip()
    except subprocess.CalledProcessError:
        sha, branch = "?", "?"
    name = os.path.basename(root)

    out_path = os.path.abspath(out)
    out_rel = os.path.relpath(out_path, root)        # never inline the export into itself

    text_files, binary_files, contents = [], [], {}
    for f in files:
        if f == out_rel:                             # skip our own output file if it's tracked
            continue
        try:
            raw = open(os.path.join(root, f), "rb").read()
        except OSError:
            continue
        if b"\x00" in raw:                           # NUL byte => binary; list it, don't inline
            binary_files.append((f, len(raw)))
            continue
        try:
            contents[f] = raw.decode("utf-8")
        except UnicodeDecodeError:
            contents[f] = raw.decode("latin-1")
        text_files.append(f)

    # newline="" => write exactly the bytes we hold (no platform newline translation), so unpack
    # reproduces each file verbatim.
    with open(out_path, "w", encoding="utf-8", newline="") as o:
        scope = " ".join(pathspec) if pathspec else "(whole repo)"
        o.write("=" * 80 + "\n")
        o.write(f"REPO EXPORT - {name}\n")
        o.write(f"Commit : {sha} ({branch})\n")
        o.write(f"Date   : {datetime.date.today().isoformat()}\n")
        o.write(f"Scope  : {scope}\n")
        o.write(f"Files  : {len(text_files)} text inlined, {len(binary_files)} binary skipped\n")
        o.write("Format : each file is between '==== BEGIN FILE: <path> ====' and '==== END FILE: <path> ===='\n")
        o.write("Unpack : python3 export_repo.py --unpack <this file> --into <dir>\n")
        o.write("=" * 80 + "\n\n")
        o.write("FILE TREE (tracked text files)\n" + "-" * 40 + "\n")
        for f in text_files:
            o.write(f + "\n")
        if binary_files:
            o.write("\nBINARY / SKIPPED (not inlined; cannot be unpacked)\n" + "-" * 40 + "\n")
            for f, n in binary_files:
                o.write(f"{f}  ({n} bytes)\n")
        o.write("\n" + "=" * 80 + "\n")
        for f in text_files:
            # Always a newline before END; unpack joins the in-between lines with "\n", which
            # consumes exactly that added newline -> verbatim round-trip whether or not the file
            # ended in a newline.
            o.write(f"\n{BEGIN.format(f)}\n")
            o.write(contents[f])
            o.write(f"\n{END.format(f)}\n")

    size = os.path.getsize(out_path)
    print(f"packed {len(text_files)} text files ({len(binary_files)} binary skipped) -> {out_path}")
    print(f"  {size:,} bytes ({size / 1024:.1f} KiB), ~{size // 4:,} tokens (rough, chars/4)")


def unpack(src, into):
    # Tolerate CRLF / CR endings: a packed file often picks up Windows line endings in transit
    # (git autocrlf, an editor, copy-paste). Normalize to "\n" so the markers still match —
    # otherwise a stray "\r" after "====" breaks the regex and you get "no BEGIN blocks found".
    with open(src, "r", encoding="utf-8", newline="") as fh:
        lines = fh.read().replace("\r\n", "\n").replace("\r", "\n").split("\n")
    into_abs = os.path.abspath(into)
    os.makedirs(into_abs, exist_ok=True)
    n, i = 0, 0
    while i < len(lines):
        m = BEGIN_RE.match(lines[i])
        if not m:
            i += 1
            continue
        path = m.group(1)
        end_marker = END.format(path)
        i += 1
        body = []
        while i < len(lines) and lines[i] != end_marker:
            body.append(lines[i])
            i += 1
        if i >= len(lines):
            sys.exit(f"error: no END marker for {path!r} — the packed file is truncated/corrupt")
        i += 1                                       # consume the END line
        dest = os.path.abspath(os.path.join(into_abs, path))
        if os.path.commonpath([into_abs, dest]) != into_abs:   # refuse path-escape (../)
            sys.exit(f"error: refusing to write outside {into_abs}: {path!r}")
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "w", encoding="utf-8", newline="") as o:
            o.write("\n".join(body))
        n += 1
    if n == 0:
        sys.exit("error: no '==== BEGIN FILE: ... ====' blocks found — is this a packed export?")
    print(f"unpacked {n} files into {into_abs}")


def main():
    ap = argparse.ArgumentParser(description="Pack a git repo into one text file, or unpack it back.")
    ap.add_argument("pathspec", nargs="*", help="(pack) optional git pathspec(s) to limit the export")
    ap.add_argument("-o", "--out", default="repo_export.txt",
                    help="(pack) output file (default: repo_export.txt in the current directory)")
    ap.add_argument("--unpack", metavar="FILE", help="reconstruct the tree from a packed export FILE")
    ap.add_argument("--into", default="restored",
                    help="(unpack) target directory to write the tree into (default: ./restored)")
    args = ap.parse_args()

    if args.unpack:
        unpack(args.unpack, args.into)
    else:
        pack(args.pathspec, args.out)


if __name__ == "__main__":
    main()
