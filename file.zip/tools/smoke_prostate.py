#!/usr/bin/env python3
"""Local synthetic smoke for prostate 202606 — build the ADS on a LOCAL Spark (no cluster) and print it.

Proves the shared engine assembles a prostate ADS end-to-end
(sources -> LOT -> index -> demographics -> clinical -> treatment -> outcomes -> assemble -> 7-cohort
union) with NO Databricks/UC, using tiny synthetic source tables. The real-data run is the SAME engine
+ config pointed at real Panoramic tables via the Databricks bundle
(see products/oncology/prostate/202606/DEV_SMOKE.md).

Run from the repo root:
    pip install pyspark pyyaml          # pyspark = a local, in-process Spark; needs Java 11/17/21 on PATH
    python3 tools/smoke_prostate.py

The synthetic-source builders (_augment / _synth_src) are copied verbatim from
platform/tests/test_smoke_spark.py so this stays a faithful, standalone demo.
"""
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "platform"))      # so `engine` imports
PRODUCTS = ROOT / "products"
SLUG = "prostate"

try:
    from pyspark.sql import SparkSession, functions as F
except ImportError:
    sys.exit("pyspark not installed — run:  pip install pyspark pyyaml   (needs Java 11/17/21 on PATH)")

from engine.config import load_config, product_config          # noqa: E402
from engine.validate import required_columns                   # noqa: E402
from engine import build_ads                                    # noqa: E402


# ---- synthetic source tables (verbatim from platform/tests/test_smoke_spark.py) -------------------
def _augment(df, cols, d1):
    have = {c.lower() for c in df.columns}
    for c in cols:
        if c.lower() not in have:
            is_date = "date" in c.lower() and "granularity" not in c.lower()
            df = df.withColumn(c, F.lit(d1) if is_date else F.lit("1"))
    return df


def _synth_src(s, cfg):
    d1, d2 = date(2020, 1, 1), date(2020, 6, 1)
    settings = sorted({c.get("line_setting") for c in cfg.cohorts} - {None}) or [cfg.lot_line_setting or "x"]
    table = {
        "lot": (["patientid", "linename", "linesetting", "startdate", "linenumber", "enddate",
                 "detaileddrugcategory"],
                [("p1", "drug", st, d1, 1, d2, "chemotherapy") for st in settings]),
        "demographics": (["patientid", "birthyear", "race", "ethnicity"],
                         [("p1", "1960", "White", "Not Hispanic or Latino")]),
        "mortality": (["patientid", "dateofdeath"], [("p1", "2021-01")]),
        "baseline_ecog": (["patientid", "ecogdate", "ecogvalue"], [("p1", d1, "1")]),
        "visit": (["patientid", "visitdate"], [("p1", d2)]),
        "telemed": (["patientid", "visitdate"], [("p1", d2)]),
        "orals": (["patientid", "enddate", "startdategranularity"], [("p1", d2, "Month")]),
        "alphabet": (["patientid", "administrationdate"], [("p1", d2)]),
        "provenge": (["patientid", "startdate"], [("p1", d2)]),
    }
    req = required_columns(cfg)
    stcfg = cfg.pack("clinical").get("staging") or {}
    if stcfg.get("groups"):
        st_src = stcfg.get("source", cfg.index_source)
        req.setdefault(st_src, ["patientid"]).append("groupstage")
    src = {}
    for name in cfg.sources:
        cols, rows = table.get(name, (["patientid"], [("p1",)]))
        df = _augment(s.createDataFrame(rows, cols), req.get(name, []), d1)
        src[name] = df
    isrc = cfg.index_source
    allof = sorted({c.lower() for rule in (cfg.index_dates or {}).values() for c in (rule.get("of") or [])})
    idf = s.createDataFrame([tuple(["p1"] + [d1] * len(allof))], ["patientid"] + allof)
    for key, rule in (cfg.index_dates or {}).items():
        cols = [c.lower() for c in (rule.get("of") or [])]
        if cols:
            expr = F.greatest(*[F.col(c) for c in cols]) if len(cols) > 1 else F.col(cols[0])
            idf = idf.withColumn(key.replace("_", ""), expr)
    src[isrc] = _augment(idf, req.get(isrc, []), d1)
    return src


def main():
    spark = (SparkSession.builder.master("local[*]").appName("prostate-202606-smoke")
             .config("spark.sql.shuffle.partitions", "1")
             .config("spark.driver.memory", "3g").getOrCreate())
    spark.sparkContext.setLogLevel("ERROR")

    cfg = load_config(product_config(PRODUCTS, SLUG),
                      overrides={"run.refresh": "2026q1", "run.source_schema": "synth",
                                 "run.output_schema": "synth"})
    print("=" * 72)
    print(f"product : {cfg.raw.get('name')}")
    print(f"spec    : {cfg.spec_version}   output table: {cfg.output_table}")
    print(f"vendor  : {cfg.raw.get('vendor')} / {cfg.raw.get('tumor_class')}")
    print(f"cohorts : {len(cfg.cohorts)} -> {[c['id'] for c in cfg.cohorts]}")
    print(f"sources : {sorted(cfg.sources)}")
    print("=" * 72)

    src = _synth_src(spark, cfg)
    ads = build_ads.build_from_sources(src, cfg)        # the real production build path

    print("\n### ADS BUILT — synthetic data, local Spark, NO cluster ###")
    print(f"rows    : {ads.count()}")
    print(f"columns : {len(ads.columns)}")
    print("\ncohort breakdown (expect cohortn 1..7):")
    ads.groupBy("cohortn", "cohort").count().orderBy("cohortn").show(truncate=False)
    print("treated/untreated labels by setting (proves the dual mHSPC + mCRPC split fired):")
    ads.select("cohortu", "cohortun").distinct().orderBy("cohortun").show(truncate=False)
    print("provenance stamps:")
    ads.select("data_product_id", "spec_version", "data_refresh").distinct().show(truncate=False)
    print("first 30 ADS columns:")
    print("  " + ", ".join(ads.columns[:30]))
    print(f"\nOK — prostate {cfg.spec_version} built end-to-end on synthetic data.")
    print("Same engine + config runs on real Panoramic tables via the Databricks bundle "
          "(products/oncology/prostate/202606/DEV_SMOKE.md).")
    spark.stop()


if __name__ == "__main__":
    main()
