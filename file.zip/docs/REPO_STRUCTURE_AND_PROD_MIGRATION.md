# Repo Structure & Production Migration — Review Document

> ## ✅ MIGRATION EXECUTED (this branch)
> The **target structure (§A2) is now realized**: the engine is in **`platform/`**, the governed products
> in **`products/oncology/<product>/`** (+ `products/metadata/`, `products/_reporting/`, `products/registry.yaml`),
> the ledgers at the repo root (**`refreshes/`**, **`releases/`**), governance in **`governance/`**, and the
> space-containing dir is **gone** (issue C3 resolved — `CODEOWNERS` now routes the governed tree). The
> Databricks bundle, CI, and every test path were updated; the pure-Python + R-parity suites stay green.
> §A1 and the C-issues below describe the **pre-migration** state (historical); §H records the phased plan
> that was followed (Wave 1 governance → step 6 physical move, both **DONE**). The one thing the sandbox
> can't verify is `databricks bundle deploy` on a real workspace — paths are consistent + YAML-valid, but a
> dev smoke is still the post-move confirmation.

> **Status: DRAFT for review** — and the **authoritative** repo-level blueprint.
> (`products/docs/repo-architecture.md` is marked superseded by this doc.) Wave 1 governance landed
> non-disruptively (`governance/`, root `CODEOWNERS`, `.github/pull_request_template.md`, engine `VERSION`
> `1.0.0`, `source_refs.yaml`), then the §H step-6 physical restructure was executed (see the banner above).
>
> **Compatibility:** `products/OPERATIONS.md` is authoritative for the runnable lifecycle. Now that
> Phase 6 is executed, it and this doc describe the **same** realized `platform/` + `products/` structure —
> there is no longer a current-vs-target divergence (this doc retains the historical §A1 for audit).
>
> **Precision legend** — every non-obvious claim is tagged so reviewers never assume future governance
> already exists:
>
> | Tag | Meaning |
> |---|---|
> | `[CURRENT]` | works today (post-move: `platform/` + `products/`; pre-move it was `current data products/`) |
> | `[TARGET]` | proposed end-state |
> | `[ADD]` | a concrete addition in the migration plan (§H) |
> | `[DEFER]` | intentionally out of scope this phase |
>
> **Two guiding constraints:** (1) **non-disruptive migration** — add governance *around* what works,
> defer physical moves to a late optional phase; (2) **no spec-ingestion platform** — Excel/Word/PDF
> stay human source material, not build inputs (`[DEFER]`: no parser/extraction/checksums/Excel CI).

---

## A1. Repo zones — PRE-MIGRATION state (HISTORICAL)

> **Historical.** This section + the C-issues describe the repo *before* the §H step-6 move (when the
> governed system lived under the space-containing `current data products/`). The realized layout is §A2.
> The `[CURRENT]` tags below were true pre-move; today they read as `platform/` + `products/`.

The pre-migration top-level areas, two parallel framework iterations:

```
rwddataproduct/                       (repo root)
├── current data products/   ★ GOVERNED, RUNNABLE — the oncology RWDP system (prostate 202606 etc.)
│   ├── _framework/                   engine/ (PySpark) + engine-r/ (parity) + databricks/ + tests/
│   ├── <tumor>/                      prostate / oc / endometrial / dlbcl  (config + variables + codelists)
│   ├── metadata/catalog.yaml         master variable catalog
│   ├── dashboard/ · dictionary/ · tfl/   reporting contracts
│   ├── refreshes/                    per-refresh manifests (the audit ledger)
│   ├── registry.yaml                 tumor registry + 202603→202606 lineage
│   ├── databricks.yml                Asset Bundle (root) → platform/databricks/run_rwdp.py
│   └── OPERATIONS.md · ROADMAP.md    governance + lifecycle docs
│
├── variable-specs/          ⚠ PARALLEL framework — self-contained ("lift into its own repo when ready")
├── oncology/                ▽ design/reference scaffold (older packs)
├── rwddataproduct_example/  ▽ example/reference structure
├── source-materials/        ▽ original spec PDFs (prostate rdap, oc, ec, dashboard) + metadata/ (masterspec, tumorspecs)
├── upcoming prostate spec/ ▽ prostate Panoramic spec workbook PDFs (studypop, clincars, treatvars, outcomes, demo, dataprep)
├── programmePlan/           ▽ programme planning
├── docs/                    ◆ operating model: RACI, request-types, refresh-schedule, adoption
└── .github/                 ◆ CI (rwdp-ci, specs-ci, refresh-cadence) + 7 issue templates + labels
```
★ governed/runnable · ⚠ needs a decision · ▽ reference/design · ◆ governance

> **Inventory note.** The ★/⚠/◆ areas (the governed system + its decisions) are the migration targets and
> are identical across branches. The ▽ peripheral source PDFs were a guiding reference and have since been
> **removed from the repo** (no scanned PDFs in prod); source provenance is now linked externally — the Excel
> program-spec on Teams (see a product's `source_refs.yaml`). ADR-001 (§H step 0) records the disposition.

**Strengths today `[CURRENT]` (don't rebuild):**
- Locked-engine / config-driven — behaviour changes are reviewed YAML diffs.
- Refreshes git-tracked as the ledger; row-level `spec_version`/`data_refresh` stamps; **sequential ADS-anchored** publish (TFL views first, ADS last) + release pointer + TFL promotion in `engine/release.py`.
- Real QC + publish gate (source-QC → build → ADS-QC + golden) + R parity; manifest validator requires `published_at` + release pointer + `tfl_promotion.passed`.
- Operating model: RACI, request types, structured GitHub intake, path-scoped CI.

> **Landed (this branch, CI-enforced):** root `CODEOWNERS` (now routes the governed tree `platform/**` +
> `products/**` — the C3 space is gone), `governance/VERSIONING.md`, the `release`/`tfl_qc`/`source_refs`
> **JSON schemas**, engine `VERSION`, `source_refs.yaml`, the `introduced_in`/`status` catalog ledger,
> `data_product_id` row-stamping + `engine_version` in the manifest, and the `release.json`/`audit_report.md`
> evidence bundle written to the spec-versioned `releases/`. **Still `[ADD]`:** `release/*` git tags
> (**none cut yet**), per-row `git_commit`/`build_id` (manifest-level today), and auto `contract_delta`.

**Issues identified in the pre-migration review** — C1–C5 are now **RESOLVED** by the executed restructure (see the top banner + §6: `current data products/`→`products/`, the parallel `variable-specs/` + reference scaffolds removed, spaces gone, engine in `platform/`, §F evidence bundle). Kept for the audit trail:
| # | Issue | Why it matters |
|---|---|---|
| C1 | **Two framework iterations** (`variable-specs/` vs `current data products/`) | Prod needs ONE source of truth — the runnable system is `current data products/`. |
| C2 | **Governed code mixed with scaffolds** at top level | Auditors can't tell released vs exploratory. |
| C3 | **Spaces in dir name** (`current data products/`) | Break paths, scripts, bundle refs, CI globs. |
| C4 | **Engine nested in the oncology-oriented tree** | A second family (claims) can't cleanly share it. |
| C5 | **Release evidence partial** | Manifest + release pointer + TFL promotion exist; a consolidated immutable per-build evidence bundle does not (§F). |

---

## A2. Repo zones — target structure `[TARGET]`

```
rwddataproduct/
├── platform/                         # SHARED ENGINE — semver'd; the only "code"  [TARGET]
│   ├── VERSION                       #   engine version a product pins  ([ADD] engine-local VERSION first, §H)
│   ├── engine/  engine-r/  databricks/  tests/
│
├── products/                         # ALL GOVERNED DATA PRODUCTS (config + specs only — no engine)
│   ├── registry.yaml                 #   family · product_slug · registry_code · current_spec_version · lineage
│   ├── metadata/catalog.yaml         #   single cross-product variable ledger (KEEPS today's name; introduced_in / deprecated_in)
│   ├── _reporting/                   #   SHARED dashboard / dictionary / tfl contracts (common TFLs)
│   ├── oncology/                     #   product FAMILY
│   │   ├── prostate/  ovarian/ …     #     a product (see §C)
│   └── claims/                       #   future family — same shape, same engine
│
├── refreshes/  <family>/<product>/<spec_version>/<refresh>.yaml          # per-cut manifest ledger (authoritative)
├── releases/   <family>/<product>/<spec_version>/<refresh>/<build_id>/   # immutable evidence bundle  [ADD] §F
│
├── governance/                       # operating model (RACI, request-types, this doc, versioning policy, ADRs)
├── reference/                        # NON-governed: source-materials (PDFs), design scaffolds, examples
└── .github/                          # CI + issue templates + CODEOWNERS
```

```mermaid
flowchart TB
  subgraph G[" GOVERNED (audited, released) "]
    PLAT[platform/ — shared engine, semver]
    PROD[products/ — registry + catalog + per-product config]
    LED[refreshes/ + releases/ — the ledgers]
  end
  subgraph N[" NON-GOVERNED "]
    REFr[reference/ — spec PDFs, scaffolds, exploration]
  end
  PLAT --> PROD --> LED
  REFr -. informs .-> PROD
```

**Why:** engine shared *above* the products → a new family reuses it with zero forks; every governed
artifact in `platform/ products/ refreshes/ releases/`; exploratory work visibly in `reference/`.

---

## B. Developer workflow

```mermaid
flowchart LR
  I[GitHub issue: variable-change / cohort-intake / data-refresh] --> B[branch]
  B --> PR[pull request]
  PR --> CO[CODEOWNERS routes review]
  CO --> CI{CI gates}
  CI -->|green| M[merge to main]
  CI -->|red| B
  M --> REL[refresh run -> release record -> tag]
```

- `[CURRENT]` **Structured intake** — every change is a typed issue (7 templates in repo); **branch → PR → review → merge** is the documented process. *(Branch protection requiring CODEOWNER review is still `[ADD]` — needs branch-protection config + a distinct approver, see below.)*
- `[DONE]` **Root `CODEOWNERS`** routes the governed tree: `platform/**` → engine owners (parity required); `products/oncology/**` → product owner + biostats; `products/metadata` + `registry.yaml` → catalog steward; `products/_reporting/**` → biostats/TFL owner; `refreshes/**` + `releases/**` → release approver (**≠ author**); `governance/**` + `docs/**` → governance owner. **Still `[ADD]`:** every line currently routes to the sole owner `@salzburry` (the intended role kept as a `# role:` tag); stand up real per-role GitHub teams + branch protection to enforce separation-of-duties (approver ≠ author).
- `[CURRENT]` PR description **links the source doc/issue** that motivated the change. No Excel parsing.
- `[CURRENT]` **Local loop:** edit YAML → `validate.py` → pure-Python suite (incl. **Python≡R parity**,
  `test_r_parity.py`) → optional local Spark smoke (synthetic). The same config also runs on the **R engine**
  (`platform/engine-r/`) as a side-by-side validation build — separate `_r` schema → golden-compare vs the
  Python ADS (not a governed run); see `platform/engine-r/README.md`.

---

## C. Product spec structure & source materials

**Identity — three distinct concepts** (don't conflate): `family: oncology` · `product_slug: prostate`
· `registry_code: mcrpc` (stable, kept across 202603→202606). *The current folder/slug is `prostate` and stays
until the Phase-6 restructure (where it may be corrected to `prostate`) — don't rename it early.* Layout:

```
products/oncology/prostate/        (product_slug=prostate, registry_code=mcrpc)
├── README.md  CHANGELOG.md  OWNERS
├── config/data_product.yaml       # cohorts, sources, windows, spec_version, run, release
├── variables/*.yaml  codelists/*.yaml
├── tfl/tfl_specs.yaml             # product-specific TFLs (§D)
└── source_refs.yaml               # [ADD] lightweight link to source materials (active products only)
```

### Source materials `[DEFER automation]`

Excel/Word/PDF are **human reference material, not executable build inputs this phase.** The governed
implementation is the Git-tracked config: `config/`, `variables/`, `codelists/`, catalog rows,
`tfl_specs.yaml`, dashboard rules, tests, manifests. A PR links the source/issue; **CI does not parse
Excel/PDF.** Optional `source_refs.yaml` — **required for active/governed products, optional for
scaffolds**, tiny schema, no checksums/extracts/traceability-CSV:

```yaml
product: mcrpc
spec_version: "202606"
source_materials:
  - { path_or_link: "TBD — Teams/SharePoint link to the program-spec (Excel)", role: "program-spec source", status: pending, issue_or_pr: "#123" }
notes: ["Excel/PDF not parsed; YAML + catalog are the governed implementation."]
```
> Source PDFs are NOT kept in the repo — provenance is an external link (e.g. the Excel program-spec on Teams).
> The CI check (`test_governance`) is **presence** for active products (schema-valid AND every *in-repo*
> `path_or_link` exists on disk; external links / `TBD` are not presence-checked) — CI does **not** parse the materials.

---

## D. TFL governance

TFLs are a **release-gating deliverable**, not a side output.

- `[CURRENT]` The runner **generates** TFLs, runs a **producibility planner**, handles `where_columns`
  safely, **skips a TFL whose input columns are absent**, and gates publish at the **deliverable level**
  (a required deliverable that fails blocks publish). `tfl/tfl_specs.yaml` is a seed/global spec
  (Table 1, clinical/treatment/platinum tables, OS/PFS/PFS2 KM, patient listing).
- `[TARGET]` Add **per-TFL** `required_for_release` / `allow_empty` / `min_rows` / `applies_to` /
  `spec_version_introduced` / `owner` / `status`, split **shared** (`products/_reporting/tfl/`) from
  **product-specific** (`<product>/tfl/`), and add a dedicated **TFL QC gate** (below).

```yaml
# [TARGET] per-TFL spec
id: t1_demographics
title: "Table 1. Baseline demographics"
status: active            # active | exploratory | retired
required_for_release: true
applies_to: [mcrpc]
spec_version_introduced: "202606"
owner: biostats
inputs: { variables: [agegrl, race, eth, cohort], cohorts: all }
output: { format: delta, public_view: true }
qc:     { min_rows: 1, required_columns: [cohort], allow_empty: false }
```

**`[ADD]` TFL QC gate** — `platform/engine/tfl_qc.py` → `tfl_qc.json`, in **two stages**:
- **pre-publish (generation QC, blocks publish):** each required TFL generated · nonempty unless `allow_empty` · inputs in **catalog AND ADS** · cohort labels + denominators match ADS. **Skip states:** required TFL skipped for a missing input → **failure**; optional TFL skipped → **warning**; not-applicable (`applies_to` excludes the product) → **ok**.
- **post-swap (release/pointer QC):** each public TFL view points at the **same `build_id`** as the ADS · no stale public TFL left unreviewed.

> **Current scope vs deferred (tracked decision, not a hidden gap).** What is **enforced today**
> (`engine.tfl.tfl_qc`, in the runner): per-TFL **applicability + required/optional** skip states +
> **producibility** (hard input columns present) + **actual emission** (a required TFL `generate()`
> silently skipped → failure). **`[DEFER]` to after the first real run** (they need real ADS data +
> product-set thresholds): the **semantic** checks above — nonzero rows / `min_rows` / `allow_empty`,
> cohort-label + **denominator** matching vs the ADS, percentage sanity, the **post-swap pointer** check —
> and the **per-product TFL metadata** (`applies_to`/`owner`/`status`/`min_rows`). This is a recorded
> decision: generation-level QC gates dev + first release; the semantic pass is added once a real run
> exists to calibrate it. Owner: biostats/TFL + RWP.

Shape:
```yaml
passed: true
tfls:
  t1_demographics: { status: generated, rows: 28, input_columns_present: true, nonempty: true, denominators_match_ads: true }
  f2_pfs_km:       { status: skipped, reason: "pfs/pfsfl not emitted" }
failures: []
```

---

## E. QC & validation — the gate stack

`[CURRENT]` unless tagged. **A red gate never publishes.**

```mermaid
flowchart TB
  A[PR] --> CI[CI: lint · pure-Python suite · catalog-completeness · Python≡R parity · version-bump check ADD]
  CI --> PF[preflight: required source columns exist]
  PF --> SQC[source QC gate]
  SQC --> BLD[build ADS · stamp provenance]
  BLD --> AQC[ADS QC + GOLDEN compare]
  AQC --> TQC[TFL QC gate ADD]
  TQC --> DEL[deliverables: dictionary · dashboard manifest · TFLs]
  DEL --> PREP[release-prepared manifest · published_at=null]
  PREP --> PUB[publish: sequential — TFL views first, ADS view last as commit anchor]
  PUB --> SIGN[released manifest + sign-off + tag ADD]
  CI & PF & SQC & AQC & TQC & DEL -->|fail| STOP[BLOCK publish · staging retained · reason recorded]
```

| Gate | Status |
|---|---|
| Config lint + pure-Python suite · catalog-completeness · **Py≡R parity** | `[CURRENT]` (CI `rwdp-ci`) |
| **Version-bump check** | `[ADD]` (rule below) |
| Preflight · source QC · ADS QC · **golden** | `[CURRENT]` |
| **TFL QC** (§D) · **dashboard/dictionary QC** | `[ADD]` |
| Release sign-off (`approver ≠ author`) | `[ADD]` (§F) |

**`[ADD]` Version-bump rule:** a PR touching a product's config / variables / codelists / catalog /
`tfl/*.yaml`, or output-changing engine logic, must carry **either** a `spec_version` bump (to the
current `YYYYMM`) + a CHANGELOG entry **or** an explicit `no-contract-change` waiver (a **PR-checklist
field/comment** — there is no such *label* in `.github/labels.yml` today). **Paths:** *before* Phase 6
these are under `current data products/**`; *after* the move, under `products/**` + `platform/**`. The
CHANGELOG entry classifies the change: **breaking** (cohort redefined · variable removed/renamed ·
derivation changed · table identity changed) / **additive** (new variable / optional TFL / dashboard
var / codelist value) / **none** (data cut · typo · test refactor · perf). **`[ADD]` Dashboard/dictionary QC:** dictionary count matches
catalog∩ADS · PII audience filtering applied · `dashboard_manifest` advertises only actual ADS columns
· types/value-sets valid. **`[DONE]` CI path coverage:** `rwdp-ci` now covers `platform/** products/** refreshes/** releases/** governance/** docs/**` (extended at the move; the parallel `variable-specs/` framework has since been removed from the repo).

---

## F. Audit & release artifacts

**`[ADD]` Consolidated evidence bundle.** Reconciling with `[CURRENT]`: the runner writes build-scoped
evidence to `artifact_root/<tumor>/<refresh>/<build_id>/manifest.yaml`, then **promotes** to
`refreshes/<family>/<product>/<spec_version>/<refresh>.yaml`. The flow stays:

```
artifact_root/<tumor_slug>/<refresh>/<build_id>/  = ALL build attempts (incl. failed gates)  [CURRENT]
   (TARGET path: artifact_root/<family>/<product>/<spec_version>/<refresh>/<build_id>/)
refreshes/.../<refresh>.yaml    = the PROMOTED, authoritative ledger entry  [CURRENT]
releases/.../<build_id>/        = an immutable, git-committed COPY of the SUCCESSFUL build's
                                  AUDIT METADATA (references the manifest; not a competing store)  [ADD]
```
> **Who writes what:** the runner writes `artifact_root`; **git promotion** (one job — a Databricks run
> can't push to git, per `refreshes/README.md`) copies `artifact_root/manifest.yaml` into `refreshes/`
> AND the successful build's audit metadata into `releases/<…>/<build_id>/`.
> `releases/` holds only the **small audit/QC metadata** (the JSON/MD below) — **never** ADS/TFL data,
> Delta tables, or large outputs. Data lives as versioned UC tables referenced *by name*; the bundle
> records the names + the QC evidence, not the bytes.

**Artifact status matrix:**
| Artifact | Status |
|---|---|
| `manifest.yaml` | `[CURRENT]` — authoritative refresh ledger |
| `qc_report.md` · dictionaries · `dashboard_manifest.json` · TFL table/view **names + promotion metadata** (Delta tables stay in UC) · release-pointer | `[CURRENT]` |
| `source_qc.json` / `ads_qc.json` | `[CURRENT]` embedded in QC report → `[ADD]` split out |
| `release.json` · `audit_report.md` · `tfl_qc.json` · `dictionary_qc.json` · `dashboard_manifest_qc.json` | `[ADD]` generated per build |

**`[ADD]` Generated `audit_report.md` summarises:** identity (product_code · product_name ·
spec_version · data_refresh · engine_version · git_commit · build_id · **source_schema · output_schema
· data_format · reference_table · Databricks run URL**) · source QC · ADS QC · golden drift ·
deliverables · release (tables/views · `tfl_promotion.passed` · `published_at` · approver).

**Sign-off — current + target.** `[CURRENT]` the refresh manifest already carries a `sign_off` block
(`qc_by` / `released_by` / dates), and `engine/refresh.py` **requires** `sign_off.released_by` +
`git_commit` + `published_at` before a manifest can be `status: released` (set only *after* a successful
swap). So approval is recorded **on the manifest at release time** — not invented later. `[ADD]`
`release.json` is a consolidated audit **copy** of that same approval, not a second sign-off. **Roles:**
`built_by` (engineer / service principal) · `reviewed_by` (QC / RWDE) · `released_by` (data-product
owner / RWP lead) — distinct from biostats *spec/TFL* sign-off (biostats approves the definition; the
data-product owner approves the release). **Enforcement:** P1 PR checklist → P2 manifest validator
(already requires `released_by`) → P3 CI asserts `released_by ≠ git author`.
```yaml
sign_off: { qc_by: <qc>, released_by: <owner>, released_date: <ts>, approver_role: "RWP Lead / Data Product Owner", approver_not_author: true }
```
> **Biostats/spec/TFL approval** (the *definition*) lives in the PR approval + the product
> CHANGELOG/`source_refs.yaml` note; the release `sign_off` confirms the *built artifact* is approved for
> publication. A dedicated `spec_sign_off` block is target-only — don't overbuild it now.

**Traceability (catalog-driven, no Excel):** a column traces back `dictionary/dashboard/TFL → ADS →
emitted_variables → catalog (introduced_in) → commit/spec`. Each variable may carry a catalog
**status** — `implemented | conditional | not_derivable | deferred | waived | removed` — so PSMA /
PSA-at-diagnosis / conmeds / CSD are recorded once, not rediscovered.

---

## G. Versioning & lineage

**Three axes** — every published row's *target* identity is product · contract · data · code.

| Axis | Example | Lives in | Bumps when |
|---|---|---|---|
| Engine version | `1.0.0` | `[CURRENT]` engine-local `platform/VERSION` (→ `platform/VERSION` at Phase 6) | engine behaviour changes (SemVer) |
| **Spec version** `YYYYMM` (CalVer) | `202606` | product config `[CURRENT]` | any contract change → the current month/year (e.g. `rwdp_pros_pano_202606`) |
| Data refresh | `2026q2` | refresh manifest `[CURRENT]` | new data cut, same spec |

- **Row stamps:** `spec_version` + `data_refresh` `[CURRENT]`; `data_product_id` + `git_commit` + `build_id` `[ADD]`.
- **Catalog ledger `[ADD]`:** each variable `introduced_in: {product: spec_version}` (+ optional `deprecated_in` / `status`); a refresh's `contract_delta` is **auto-derived**. *Backfill rule:* absence of `introduced_in` = "present before ledger adoption" (backfill only active prostate 202606 if the first governed release needs it). E.g. `{ code: tsst, introduced_in: {mcrpc: "202606"}, status: implemented }`; `{ code: age }` (no `introduced_in` → pre-ledger).
- **Change classification `[TARGET]`:** CalVer doesn't encode breaking-vs-additive, so the **CHANGELOG** records it — **breaking** (cohort/derivation/rename/remove) vs **additive** (new variable/TFL/codelist value) vs **none** (data cut / typo). Any contract change → a new `YYYYMM` spec_version + a classified CHANGELOG entry.
- **Release tags `[ADD]`:** `release/<registry_code>/<spec_version>/<refresh>` (e.g. `release/mcrpc/202606/2026q2`) — the spec_version segment avoids cross-version collisions. *(None cut yet.)*

```mermaid
flowchart LR
  COMMIT[git commit + release tag] --> MAN[refreshes/.../<refresh>.yaml]
  MAN --> REC[releases/.../<build_id>/ — release.json + audit_report + QC jsons]
  REC --> ROW[ADS rows stamp spec_version · data_refresh · git_commit · build_id]
  ROW --> CHG[CHANGELOG.md + registry lineage]
```
Publish is a **sequential, ADS-anchored swap** (TFL views first, ADS last as commit anchor) — a single
view replacement is atomic, but the release *set* is sequential, so a half-published refresh is never
seen complete (`OPERATIONS.md` / `release.py`). `[CURRENT]`

---

## H. Migration plan (non-disruptive, phased)

The plan that was followed: phases 1–5 added governance **without moving working code**, then phase 6
did the physical move. **All six are now `[DONE]`** (see the status tags + the MIGRATION EXECUTED banner);
the governance checks are CI-enforced by `platform/tests/test_governance.py`.

0. **`[DONE]` ADR-001 — canonical framework** (`governance/decisions/ADR-001-canonical-framework.md`): `current data products/` is prod; `variable-specs/`, `oncology/`, examples → reference. Records rationale + approvers + date.
1. **`[DONE]` Root `CODEOWNERS`** (`/CODEOWNERS`) + a `.github/pull_request_template.md` (change-type + versioning + waiver checklist). *(Post-move, CODEOWNERS routes the full governed tree — `platform/**` + `products/**` + the ledgers; owners currently route to the sole owner `@salzburry` (intended role kept as a `# role:` tag) — real per-role teams + branch protection are the remaining `[ADD]`. Per-type PR templates can be split out later.)*
2. **`[DONE]` CI gates** — `rwdp-ci` triggers on `governance/**`+`docs/**`+`CODEOWNERS` and runs `test_governance.py`: the version-bump triangle (config ↔ registry ↔ CHANGELOG, `test_changelog_documents_active_spec_version`) + a doc-integrity (fence / mermaid) check (a lightweight stand-in for a markdown-lint action).
3. **`[DONE]` Catalog ledger + source refs** — `source_refs.yaml` for active products + the CI presence check; `introduced_in` + `status` on go-forward catalog variables (tsst, eligpfs @ 202606), form-validated, with the backfill rule documented.
4. **`[DONE]` Consolidated release record** — the `release.json`/`tfl_qc.json` **JSON schemas** + `engine/audit.py` (release.json + audit_report.md + split QC JSONs + tfl_qc.json), written to `artifact_root` AND the spec-versioned git `releases/<…>/<build_id>/` (`engine.refresh.release_dir`, runner dev-convenience / promote on Databricks). The TFL QC gate (`engine.tfl.tfl_qc`) is now **enforced** (a required+applicable TFL that isn't producible FAILS the tfls deliverable → blocks a governed publish).
5. **`[DONE]` Engine `VERSION` + row provenance** — engine-local `platform/VERSION` (read by `engine/version.py`); `data_product_id` stamped on every ADS row (Python + R), `engine_version` + `git_commit` + `build_id` in the manifest.
6. **`[DONE]` Physical restructure** — engine lifted to `platform/` (with `platform/VERSION`), products regrouped under `products/oncology/<product>/`, reporting under `products/_reporting/`, ledgers (`refreshes/`, `releases/`) at the repo root, the space-containing dir **removed**. **Databricks bundle:** `databricks.yml` (now repo root) `notebook_path` → `platform/databricks/run_rwdp.py`, `framework_root` → `platform`, `config_path` → `products/oncology/${tumor_slug}/${spec_version}/config/…`, sync scoped to `platform/`+`products/` (reference zones excluded). **CI:** `rwdp-ci` `working-directory` → `platform`, path filters → `platform/**`+`products/**`+`refreshes/**`+`governance/**`. Pure-Python + R-parity green; **still `[ADD]`:** `databricks bundle deploy -t dev` + a real-data dev smoke (needs a workspace). The spec-versioned ledger path `refreshes/<family>/<product>/<spec_version>/<refresh>.yaml` is now **`[DONE]`** (write_manifest); `releases/` mirrors it via `engine.refresh.release_dir`.

> Product *content* (prostate 202606 etc.) is unaffected throughout — structure + metadata only.

---

## Open decisions for the review

1. **Canonical framework (C1):** ✅ **resolved** — ADR-001 records `current data products/`→`products/` as prod; the parallel `variable-specs/` / `oncology/` / examples were removed from the repo.
2. **Authoritative doc** *(decided, pending sign-off):* this repo-level doc supersedes `repo-architecture.md` (banner added). On sign-off, drop from this list and record in ADR-001.
3. **Multi-product scope (C4):** plan `products/<family>/` (claims) now, or stay oncology-flat?
4. **Release evidence (C5/§F):** `releases/<build_id>/` = committed copy of the successful build's `artifact_root` evidence — confirm (vs index/pointer).
5. **Sign-off model (§F):** approver, where recorded, enforcement phase (P1 process → P3 CI `approver ≠ author`).
6. **Physical restructure (C3/§H6):** ✅ **resolved** — executed (governance landed first, then the step-6 move to `platform/` + `products/`; see the top banner).
7. **Reference zone:** ✅ **done** — `oncology/`, `variable-specs/`, `rwddataproduct_example/`, the source
   PDFs, the programme plan, and the demo docs served as a guiding reference and have since been **removed
   from the repo**; the repo is now prod-only (`platform/` + `products/` + `governance/` + ledgers).

---

### One-line summary
> **Shared engine + governed config-only products + git-tracked refresh & release ledgers + first-class
> TFL/QC/audit artifacts**, every claim tagged CURRENT/TARGET/ADD/DEFER, migrated in additive phases so
> nothing that works has to move — Excel/PDF kept as source material, not a build input.
