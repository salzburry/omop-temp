@echo off
setlocal
rem Double-clicking a .cmd file does not guarantee that its folder is the
rem current directory. Anchor all relative paths to this checkout so the
rem launcher cannot accidentally start from another folder.
cd /d "%~dp0"
if defined RWD_PORTAL_PYTHON goto selected_environment
if exist "%~dp0.venv313\Scripts\python.exe" (
    set "rwd_portal_python=%~dp0.venv313\Scripts\python.exe"
    goto launch
)
if exist "%~dp0.venv\Scripts\python.exe" (
    set "rwd_portal_python=%~dp0.venv\Scripts\python.exe"
    goto launch
)
py -3.13 "%~dp0experiments\portal\launch_portal.py" %*
set "rwd_portal_exit=%ERRORLEVEL%"
if not "%rwd_portal_exit%"=="0" goto missing_environment
exit /b 0

:selected_environment
set "rwd_portal_python=%RWD_PORTAL_PYTHON%"
if not exist "%rwd_portal_python%" goto missing_environment

:launch
"%rwd_portal_python%" "%~dp0experiments\portal\launch_portal.py" %*
set "rwd_portal_exit=%ERRORLEVEL%"
if "%rwd_portal_exit%"=="0" exit /b 0
for %%A in (%*) do if /I "%%~A"=="--json" goto launch_no_pause
for %%A in (%*) do if /I "%%~A"=="--check-only" goto launch_no_pause
pause
:launch_no_pause
exit /b %rwd_portal_exit%

:missing_environment
for %%A in (%*) do if /I "%%~A"=="--json" goto missing_environment_no_pause
for %%A in (%*) do if /I "%%~A"=="--check-only" goto missing_environment_no_pause
echo The selected supported Python environment could not be used.
echo Ask your data expert to open PowerShell in this repository and run these once:
echo.
echo py -3.13 -m venv .venv313
echo If that launcher tag is unavailable, run py -0p and use a listed Python 3.13 executable's full path.
echo .\.venv313\Scripts\python.exe -m pip install -c experiments/portal/environment.constraints.txt -e ".[portal]"
echo To use your existing environment, set RWD_PORTAL_PYTHON to its python.exe path.
echo In VS Code, select that interpreter and use a RWD Portal launch configuration.
echo Use a short local checkout path outside synchronized folders.
echo Stop if environment creation fails. See README.md and docs\RESEARCHER_QUICK_START.md for recovery.
echo These requirements include the test runner used by the workflow's checks.
echo.
echo Then double-click Start-RwdPortal.cmd again.
echo No packages have been installed or changed by this launcher.
pause
:missing_environment_no_pause
exit /b 1
