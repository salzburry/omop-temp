#!/usr/bin/env bash
# Domino app entry point. Serves the READ-ONLY governance surfaces from the checked-out commit.
# Domino proxies and authenticates; the app performs no governed act — see docs/DOMINO.md.
# The hosting environment must first install the project requirements.
exec python3 -I -m rwd_board.serve
