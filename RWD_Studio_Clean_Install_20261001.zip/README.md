# RWD Studio clean installation

This source package starts with empty product, fixture, activation and reviewer
registries. It includes the application, engine, master library, schemas and
dependency specifications. It confers no scientific approval or production release.
Extract into a new, short local directory; do not overlay an existing workspace.

Install supported Python (3.11–3.13; the declared reference environment is 3.13)
and Git through your organisation. From the extracted directory in PowerShell:

```powershell
py -3.13 -m venv .venv313
.\.venv313\Scripts\python.exe -m pip install -c experiments/portal/environment.constraints.txt -e ".[portal]"
.\.venv313\Scripts\python.exe -m pip check
```

## Start Studio

Use the new Studio interface for product setup, definitions, source mapping and
build previews. Run this from the extracted directory, then leave the terminal open:

```powershell
.\.venv313\Scripts\python.exe -m rwd_services.studio_server --workspace . --port 18986
```

Open **http://127.0.0.1:18986/** on that computer. Press Ctrl+C in the terminal to
stop it. The installed `rwd-studio` command is equivalent. All web assets are
included; there is no separate frontend installation or external CDN.

The initial product list is empty. Choose **New product** and supply your workbook
and source tables. The master library and disease catalogue remain available;
example products and their approvals are not installed. AI needs an explicit
destination model connection. Source imports and synthetic builds require the
additional Spark prerequisites below; installing the interface alone does not
install an ADS execution runtime.

Studio currently supports one authoring host and binds to loopback only. It uses
local Git attribution, not authenticated sign-in. For testing on another server,
open it in that server's desktop session or use an organisation-approved SSH
tunnel to its loopback port. Do not expose this local transport as a shared
production service. Hosted authentication, access controls and release approval
remain destination setup work.

## Operator console

The existing console provides specialist checks, identity enrollment, signing
and release promotion. It is installed by the same command above. Check its
environment before starting it:

```powershell
.\Start-RwdPortal.cmd --check-only --json
```

For a synthetic rehearsal, start its demo mode explicitly:

```powershell
.\Start-RwdPortal.cmd --demo
```

Demo names are local labels, not authenticated identities. Import your test inputs
into a new product and perform fresh reviews; no saved approvals are inherited.
This rehearsal can begin before Git initialization. The default
`Start-RwdPortal.cmd` starts governed mode, which requires the destination's own
Git repository and identity setup before governed work. Branch checkpoints require
Git in either mode.

Stop if a command fails and follow its named recovery action. The launcher does
not install dependencies. It uses the selected workspace, opens a loopback URL,
and reuses its own running instance. `Start-RwdPortal.cmd --stop` stops only that
instance. See `docs/RESEARCHER_QUICK_START.md` for the research workflow.

## ADS runtime and model setup

Local ADS execution additionally needs Java 17 or 21 and the selected supported
Spark runtime. The repository's local reference is `pyspark==4.0.4`; optional
Delta uses `delta-spark==4.0.0` installed with `--no-deps`. These are not bundled.
Install and verify them in the same persistent Python environment used by the
launcher. The package is not an offline dependency wheelhouse.

On Windows, creating and profiling uploaded runtime tables also requires the
native Hadoop helper (`winutils.exe`) under `HADOOP_HOME/bin`. Ask IT to provide
an approved compatible helper, or use the configured server Spark runtime.
The launcher dependency probe alone does not verify this native prerequisite.

Verify ADS execution with your destination runtime and reviewed source bindings.
An installation probe does not establish clinical validity, live model quality
or production-runtime readiness.

The optional VS Code bridge is source under `experiments/vscode-model-bridge`.
Build it with `python experiments/vscode-model-bridge/package_extension.py`,
review/install the resulting VSIX, reload VS Code, and explicitly select the
available model through **RWD Portal: Connect Chat Model**. Provider access is
configured at the destination. No credentials, bridge descriptor or conversation
history are supplied. Preserve the component's existing licensing metadata.

When included, `guides/workflow.html` is a static offline guide. `demo-kit/` holds
synthetic workbook, TSV sources and independent expected results for a new demo.
The kit is inert: import its inputs through the normal workflow and perform new
reviews. It contains no installed product, saved approval, executable product
configuration or release. A synthetic result is not clinical validation.

Before governed collaboration, initialize your organisation's repository and
configure destination identities, storage and reviewer enrollment. Local names
and emails provide attribution, not authenticated approval. Do not inherit another
installation's signing registrations or generate approvals to satisfy setup.

## Build and verify a clean source ZIP

The maintainer runs the following from the reviewed source checkout, after the
fresh workbook → AI → ADS trial and the required regressions pass:

```powershell
.\.venv\Scripts\python.exe -I -m rwd_tools.source_transfer --root . --clean-install --personal-markers <external-markers.json> --out <new-outside-checkout.zip>
.\.venv\Scripts\python.exe -I -m rwd_tools.source_transfer --verify <new-outside-checkout.zip> --personal-markers <external-markers.json>
```

Optional `--demo-kit <directory>` and `--guide <static.html>` inputs are snapshotted
and checked for changes before export. The marker file is a nonempty JSON list
of explicit personal names, emails and repository/branding strings to refuse.
It stays outside the source and archive; only its SHA-256 is recorded. Verification
without that file checks structural/content integrity but explicitly reports that
the personal-marker scan was not repeated. Never interpret it as privacy sign-off.
Embedded screenshot pixels require independent visual review.

`SOURCE_MANIFEST.json` records every delivered file, declared package closure,
preserved master/policy/licensing hashes and each initialization transformation.
The ZIP and checksum sidecar are never overwritten. Archive verification does
not execute installation tests or establish workflow success. Test a fresh
extraction with its own environment, launcher and actual workflow before delivery.

The demo directory must contain `DEMO_KIT.json` with this shape:

```json
{
  "version": 1,
  "synthetic": true,
  "notice": "Synthetic demonstration inputs only; no scientific approval or release.",
  "files": [
    {"path": "specification.xlsx", "role": "workbook", "sha256": "<64 lowercase hex characters>"},
    {"path": "sources/enhanced.tsv", "role": "source", "sha256": "<64 lowercase hex characters>"},
    {"path": "expected.json", "role": "oracle", "sha256": "<64 lowercase hex characters>"},
    {"path": "README.md", "role": "readme", "sha256": "<64 lowercase hex characters>"}
  ]
}
```

Only the declared regular files are accepted: workbook `.xlsx` without formulas,
macros or external connections; source `.tsv`; oracle `.json`, `.csv` or `.tsv`;
readme `.md` or `.txt`. At most 64 files, 8 MiB each and 32 MiB total are permitted.
No executable scripts, configuration, review, approval, registry or runtime files
are allowed. The guide must be static HTML with embedded PNG/JPEG/WebP images,
anchor links or explicit web citations, without scripts, external styles or local
file references. Original research evidence is not silently redacted or rewritten.
