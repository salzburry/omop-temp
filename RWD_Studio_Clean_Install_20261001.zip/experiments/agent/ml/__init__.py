"""Assistant model tooling; no model is loaded by importing this namespace."""
