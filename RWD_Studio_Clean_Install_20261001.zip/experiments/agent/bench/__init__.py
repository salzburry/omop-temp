"""Assistant evaluation tools; benchmarks run only when explicitly invoked."""
