"""Assistant evaluation cases; no evaluations run at package import."""
