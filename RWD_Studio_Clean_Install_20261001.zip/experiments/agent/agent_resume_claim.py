"""OS-owned resume claims survive crashes without leaving an unrecoverable sentinel."""
from contextlib import contextmanager
from pathlib import Path
import re
import sys


def _locks():
    portal = str(Path(__file__).resolve().parents[1] / "portal")
    from experiments.portal import local_process_lock
    return local_process_lock


def _paths(runs, run_id):
    if not isinstance(run_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,80}", run_id):
        raise ValueError("Choose a saved run identifier.")
    directory = Path(runs).absolute()
    if directory.resolve() != directory:
        raise ValueError("The run claim directory must be canonical.")
    return directory, directory / (run_id + ".answer.guard"), directory / (run_id + ".answer.lock")


@contextmanager
def claimed(runs, run_id):
    directory, guard, legacy = _paths(runs, run_id)
    directory.mkdir(parents=True, exist_ok=True)
    if legacy.exists():
        raise ValueError("A legacy answer claim has no verifiable process identity. Preserve it and inspect the previous run before recovery.")
    # A dead owner's guard is recovered only after obtaining its OS lock and
    # verifying its PID/start identity. An active/uncertain owner remains blocked.
    with _locks().locked(guard, directory):
        if legacy.exists():
            raise ValueError("A legacy answer process claimed this run. Wait for it to finish.")
        yield


def status(runs, run_id):
    directory, guard, legacy = _paths(runs, run_id)
    if legacy.exists():
        return {"state": "uncertain", "recovery_allowed": False,
                "reason": "A legacy answer claim has no verifiable process identity; preserve it for inspection."}
    return _locks().lock_status(guard, directory)


def recover(runs, run_id, *, confirmed=False):
    directory, guard, legacy = _paths(runs, run_id)
    if legacy.exists():
        raise ValueError("Preserve the unverifiable legacy answer claim for inspection.")
    return _locks().recover_lock(guard, directory, confirmed=confirmed)
