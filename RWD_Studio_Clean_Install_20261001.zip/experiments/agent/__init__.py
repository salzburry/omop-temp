"""Assistant workflow modules; import individual operations explicitly."""
