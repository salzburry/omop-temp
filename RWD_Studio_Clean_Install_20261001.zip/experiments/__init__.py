"""Application packages; importing this namespace performs no setup or I/O."""
