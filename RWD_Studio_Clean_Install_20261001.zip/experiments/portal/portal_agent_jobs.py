"""Durable governed Agent requests over the portal's existing worker journal.

The journal pins a run identifier and connection descriptor, never a client or
credential. Finished transcripts can repair a lost receipt without replaying
model/tool calls; incomplete transcripts require a newly reviewed request.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
from types import SimpleNamespace
import sys

from experiments.portal import identity
from experiments.portal import portal_agent_connection as connection
from experiments.portal import portal_jobs
from experiments.portal import portal_runtime

AGENT_ROLES = {"admin", "initiator", "reviewer"}


def _modules():
    from experiments.agent import state
    from experiments.agent import orchestrator
    return state, orchestrator


def _actor_id(actor):
    return actor.get("email") or actor.get("name")


def _authorize(root, actor_id, request, allowed_packs):
    from experiments.portal.portal_job_authority import authorize
    return authorize(root, actor_id, mode=request["mode"], primary_pack=request.get("primary_pack"),
        allowed_packs=allowed_packs, roles=AGENT_ROLES, action="Agent checks")


def _caps(value):
    if not isinstance(value, dict) or set(value) != {"steps", "usd", "seconds"}:
        raise ValueError("Use the current bounded Agent limits.")
    for key, limit in (("steps", 1000), ("usd", 10000), ("seconds", 86400)):
        item = value[key]
        if isinstance(item, bool) or not isinstance(item, (int, float)) or not math.isfinite(item) or not 0 < item <= limit:
            raise ValueError("Use finite positive Agent limits within the supported bounds.")
    if not isinstance(value["steps"], int):
        raise ValueError("The Agent step limit must be an integer.")
    return value


def start(root, actor, *, pack, goal, selected_connection, caps, allowed_packs,
          can_write=False, label="question", resume_run_id=None, answer=None):
    if can_write is not True:
        raise ValueError("Agent execution requires the current user's permission.")
    actor_id = _actor_id(actor)
    from experiments.portal import authoring_session
    current = authoring_session.CURRENT.get()
    if current is not None:
        authoring_session.check_scope(root, pack, actor_id)
        if "agent" not in current.permissions:
            raise ValueError("This authenticated session cannot start Agent checks.")
    elif identity.mode(os.environ) == "hosted":
        raise ValueError("Start hosted Agent checks from an authenticated application session.")
    connection.check_input(answer if resume_run_id else goal)
    state, orchestrator = _modules()
    arguments = {"mode": identity.mode(os.environ), "primary_pack": pack, "goal": str(goal),
        "label": str(label)[:120], "run_id": state.new_run_id(), "caps": dict(_caps(caps)),
        "connection": {key: selected_connection.get(key) for key in ("ok", "provider_id", "model", "connection_id")},
        "actor": {key: actor[key] for key in ("name", "email", "principal", "role", "owns", "packs") if key in actor}}
    if not arguments["connection"]["ok"]:
        raise ValueError("Choose an available assistant connection before starting.")
    action = "agent_resume" if resume_run_id else "agent_run"
    if resume_run_id:
        arguments.update(resume_run_id=resume_run_id, answer=str(answer or ""))
    resolved = _authorize(root, actor_id, arguments, allowed_packs)
    if resume_run_id:
        previous = state.RunState.resume(resume_run_id)
        if previous.primary_pack != pack or pack not in allowed_packs:
            raise ValueError("This saved run has a different or missing product binding. Open Agent for the intended product and start a scoped request.")
        eligibility, why = orchestrator._eligibility(resolved["name"], orchestrator._asked_owner(previous), set(resolved.get("owns") or []))
        if eligibility == "refused":
            raise ValueError("REFUSED — " + why)
        if (previous.outcome or {}).get("status") != "escalated" or orchestrator._answered_step(previous):
            raise ValueError("This question is already answered or no longer waiting. Refresh the saved run.")
    return portal_jobs.start(root, actor_id, action=action, arguments=arguments,
        job_key=key(pack, resume_run_id), confirmed=True, can_write=True, allowed_packs=allowed_packs)


def key(pack, resume_run_id=None):
    return "agent-resume:" + resume_run_id if resume_run_id else "agent:" + pack


def _saved_run(arguments, allowed_packs):
    state, _ = _modules()
    path = Path(state.RunState("", run_id=arguments["run_id"]).path)
    if not path.exists():
        return None
    if path.resolve() != path.absolute() or path.stat().st_size > portal_jobs.MAX_BYTES:
        raise ValueError("The retained Agent transcript is unavailable or too large.")
    result = state.RunState.resume(arguments["run_id"])
    if result.primary_pack != arguments["primary_pack"] or result.primary_pack not in (allowed_packs or []):
        raise ValueError("The retained transcript has a different product scope.")
    if not arguments.get("resume_run_id") and (result.goal != arguments["goal"] or _actor_id(result.actor or {}) != _actor_id(arguments["actor"])):
        raise ValueError("The retained transcript belongs to another request or actor.")
    return result


def _payload(result):
    return {"run_id": result.run_id, "goal": result.goal, "actor": result.actor, "primary_pack": result.primary_pack,
            "steps": result.steps, "outcome": result.outcome, "metrics": result.metrics,
            "model_id": result.model_id, "path": result.path,
            "workflow_continuations": result.workflow_continuations, "execution": result.execution}


def retry_guidance(root, value):
    try:
        _authorize(root, value["actor"], value["arguments"], value["allowed_packs"])
        result = _saved_run(value["arguments"], value["allowed_packs"])
    except (OSError, ValueError, KeyError) as error:
        return {"allowed": False, "reason": str(error)}
    if result is not None and not result.outcome:
        return {"allowed": False, "reason": "This request has an incomplete transcript. Inspect its saved steps below and send a newly reviewed request; completed tool calls are never replayed automatically."}
    return {"allowed": True, "reason": "A finished transcript will restore its receipt without repeating calls. If execution never began, retry starts the unchanged reviewed request."}


def execute(value):
    try:
        return _execute(value)
    except (ValueError, OSError) as error:
        return {"ok": False, "changed": False, "errors": [str(error)]}


def _execute(value):
    root, actor_id, arguments = value["root"], value["actor"], value["arguments"]
    allowed = value["allowed_packs"]
    current = _authorize(root, actor_id, arguments, allowed)
    caps = _caps(arguments["caps"])
    state, orchestrator = _modules()
    saved = _saved_run(arguments, allowed)
    if saved is not None and not saved.outcome:
        raise ValueError("The previous attempt has incomplete recorded work. Inspect it before starting a newly reviewed request.")
    if saved is not None and value["action"] == "agent_run":
        return {"ok": True, "changed": False, "recovered_receipt": True, "run": _payload(saved)}
    connection.check_input(arguments.get("answer") if value["action"] == "agent_resume" else arguments["goal"])
    model = connection.model(root, expected=arguments["connection"])
    from experiments.portal import authoring_session
    token = authoring_session.bind(root, actor_id, allowed, {"view", "agent"}, mode=arguments["mode"])
    def on_step(step):
        # RunState saved the complete step atomically before invoking this callback.
        portal_runtime.job_progress("Step " + str(step.get("n", "")) + ": " + str(step.get("kind", "check")))
    try:
        common = dict(model=model, max_steps=caps["steps"], cost_ceiling=caps["usd"], max_seconds=caps["seconds"],
                      scope=set(allowed), on_step=on_step, cancelled=portal_runtime.job_cancelled)
        if value["action"] == "agent_resume":
            previous = state.RunState.resume(arguments["resume_run_id"])
            if previous.primary_pack not in allowed or previous.primary_pack != arguments["primary_pack"]:
                raise ValueError("The answered run is outside the current product scope.")
            result = orchestrator.resume_run(arguments["resume_run_id"], arguments["answer"], current["name"],
                answerer_owns=set(current.get("owns") or []), successor_run_id=arguments["run_id"], **common)
        else:
            result = orchestrator.run(goal=arguments["goal"], actor=current, primary_pack=arguments["primary_pack"],
                                      run_id=arguments["run_id"], **common)
        return {"ok": True, "changed": True, "run": _payload(result)}
    except SystemExit as error:
        return {"ok": False, "changed": False, "errors": [str(error)]}
    finally:
        authoring_session.CURRENT.reset(token)


class JobView:
    """Compatibility view for the existing result renderer; no in-memory worker."""
    def __init__(self, value):
        self.value, self.id = value, value["id"]
        self.label = value["arguments"].get("label", "check")
        self.done = value["status"] in portal_jobs.TERMINAL
        self.error = None
        self.result = None
        payload = (value.get("result") or {}).get("run")
        if payload:
            self.result = SimpleNamespace(**payload)
        elif self.done:
            self.error = "; ".join((value.get("result") or {}).get("errors") or [value["progress"]])
        self._steps = self.result.steps if self.result else []
        if not self.result:
            try:
                saved = _saved_run(value["arguments"], value["allowed_packs"])
                if saved:
                    self._steps = saved.steps
            except (ValueError, OSError, KeyError):
                pass

    def snapshot(self):
        return list(self._steps)

    @property
    def elapsed(self):
        begin = datetime.fromisoformat(self.value["created_at"])
        end = datetime.fromisoformat(self.value["updated_at"]) if self.done else datetime.now(timezone.utc)
        return max(0, (end - begin).total_seconds())


def latest(root, actor_id, *, pack, allowed_packs, resume_run_id=None):
    action = "agent_resume" if resume_run_id else "agent_run"
    rows = portal_jobs.recent(root, actor_id, action=action, job_key=key(pack, resume_run_id), allowed_packs=allowed_packs)
    return JobView(rows[0]) if rows else None
