"""Atomic publication tolerating a short Windows reader/antivirus sharing lock."""
import os
import time


def replace(source, destination, *, timeout_s=2):
    """Never remove the destination as a fallback; permission errors stay errors."""
    deadline = time.monotonic() + timeout_s
    while True:
        try:
            os.replace(source, destination)
            return
        except PermissionError as error:
            if getattr(error, 'winerror', None) not in {5, 32, 33} or time.monotonic() >= deadline:
                raise
            time.sleep(.015)
