"""One guided source provisioning/profile action before adapter review."""
import hashlib
import json
import re

import streamlit as st

from experiments.portal import portal_jobs
from experiments.portal import portal_jobs_page
from experiments.portal import source_provisioning as backend
from experiments.portal import page_assistant_context as chat_context
from experiments.portal import page_assistant_summaries as chat_summary


def _local_build_key(root, pack, actor):
    return 'local_source_build_' + hashlib.sha256((str(root) + pack + actor).encode()).hexdigest()[:16]


def _current_receipt(table, receipt):
    """Restore form defaults only from an intact receipt for this exact upload."""
    if receipt is None:
        return None, ''
    if (isinstance(receipt, dict) and isinstance(table.get('sha256'), str)
            and re.fullmatch(r'[0-9a-f]{64}', table['sha256'])
            and receipt.get('upload_sha256') != table['sha256']):
        return None, 'This upload changed after the last profile. Review its columns and profile it again before building.'
    try:
        if (not isinstance(receipt, dict) or not isinstance(table.get('sha256'), str)
                or not re.fullmatch(r'[0-9a-f]{64}', table['sha256'])
                or receipt.get('upload_sha256') != table['sha256']):
            raise ValueError()
        columns = backend.mapping(table['columns'], receipt.get('columns'))
        target = backend.intake._text_name(receipt.get('runtime_table'), 'Runtime table', table=True)
        if (columns != receipt['columns'] or type(receipt.get('rows')) is not int or receipt['rows'] < 0
                or receipt.get('identity') != backend._digest({'upload': table['sha256'], 'columns': columns, 'table': target})):
            raise ValueError()
        return receipt, ''
    except (ValueError, TypeError, KeyError):
        return None, 'The saved source profile does not contain an intact mapping for this upload. Review the column names and types and profile it again; saved defaults were not reused.'


def render(root, pack, actor, *, allowed_packs, can_write):
    try:
        report = backend.describe(root, pack, actor, allowed_packs=allowed_packs)
    except (ValueError, OSError) as error:
        report = {'ok': False, 'errors': [str(error)]}
    if not report.get('ok'):
        chat_context.publish_surface(st.session_state, 'source_provisioning', root=root, pack=pack, actor_id=actor,
            allowed_packs=allowed_packs, summary=chat_summary.provisioning(report, errors=report.get('errors')))
        for error in report.get('errors') or ['Source details could not be read. Reload the source tables and try again.']:
            st.warning(str(error))
        return
    if not report['tables']:
        chat_context.publish_surface(st.session_state, 'source_provisioning', root=root, pack=pack, actor_id=actor,
            allowed_packs=allowed_packs, summary=chat_summary.provisioning(report))
        # Removing an import must not hide the candidate from a completed job.
        # Keep the empty intake simple unless this author has saved build work.
        try:
            previous = portal_jobs.recent(root, actor, action='local_source_build',
                job_key=_local_build_key(root, pack, actor), allowed_packs=allowed_packs)
        except (ValueError, OSError):
            previous = []
        if previous:
            _local_candidate(root, pack, actor, allowed_packs=allowed_packs, can_write=can_write)
        return
    scope = hashlib.sha256(repr((str(root), pack, actor, tuple(sorted(allowed_packs or [])))).encode()).hexdigest()[:16]
    with st.expander('Make a source available for execution'):
        choices = {item['physical_table']: item for item in report['tables']}
        selection_key = 'provision_source_' + scope
        if st.session_state.get(selection_key) not in choices:
            st.session_state.pop(selection_key, None)
        selected = st.selectbox('Imported table', list(choices), key=selection_key)
        table = choices[selected]
        # Changing an upload invalidates its editable column mapping, even when
        # the replacement has the same table name and identical column labels.
        token = hashlib.sha256((scope + json.dumps(table, sort_keys=True)).encode()).hexdigest()[:16]
        receipt, receipt_warning = _current_receipt(table, report['receipts'].get(table['physical_table']))
        if receipt_warning:
            st.warning(receipt_warning)
        if receipt:
            st.success(f"{receipt['runtime_table']} · {receipt['rows']} rows profiled")
            st.caption('Next: choose these source columns in the variable review and confirm the source mapping.')
        if not can_write:
            st.caption('A product editor can create or profile this source. You can inspect its saved progress here.')
        profile_only = table['format'] == 'catalog' or table['imported_by'] != actor
        existing = st.radio('Where is the data?', ['Create a runtime table from this upload', 'Use an existing runtime table'],
            index=1 if profile_only else 0, key='provision_existing_' + token,
            disabled=not can_write or profile_only) == 'Use an existing runtime table'
        if table['imported_by'] != actor:
            st.caption('The original upload stays private to its owner. Use its provisioned runtime table, or ask the owner to create that table first.')
        target_key = 'provision_target_' + token
        st.session_state.setdefault(target_key, receipt['runtime_table'] if receipt else table['physical_table'])
        target = st.text_input('Runtime table name', key=target_key, disabled=not can_write)
        suggestions = []
        for c in table['columns']:
            name = re.sub(r'[^A-Za-z0-9_]', '_', c['name']).strip('_') or 'column'
            if name[0].isdigit():
                name = 'column_' + name
            suggestions.append({'source': c['name'], 'name': name, 'type': c['type'] or 'string'})
        columns_key = 'provision_columns_' + token
        defaults_key = columns_key + '_defaults'
        if columns_key not in st.session_state:
            st.session_state[defaults_key] = receipt['columns'] if receipt else suggestions
        elif defaults_key not in st.session_state:
            # Preserve deltas in an already-open form created before receipt
            # defaults were supported; they refer to the inferred input rows.
            st.session_state[defaults_key] = suggestions
        # Keep the editor's base rows stable while its unsaved deltas are active.
        # Switching away removes the widget; returning uses the latest receipt.
        columns = st.data_editor([dict(row) for row in st.session_state[defaults_key]], hide_index=True, width='stretch', num_rows='fixed',
            disabled=True if not can_write else ['source'], key=columns_key,
            column_config={'source': st.column_config.TextColumn('Uploaded column'),
                           'name': st.column_config.TextColumn('Runtime column'),
                           'type': st.column_config.SelectboxColumn('Data type', options=list(backend.TYPES), required=True)})
        errors = []
        st.caption('Confirm column names and types here. Invalid values stop with their row and column; existing tables are never overwritten.')
        key = 'source:' + hashlib.sha256((pack + table['physical_table']).encode()).hexdigest()[:24]
        if st.button('Profile existing source' if existing else 'Create and profile source', key='provision_start_' + token, disabled=not can_write):
            try:
                selected = backend.mapping(table['columns'], list(columns))
                portal_jobs.start(root, actor, action='source_provisioning', job_key=key, arguments={
                    'pack': pack, 'physical_table': table['physical_table'], 'runtime_table': target,
                    'columns': selected, 'expected_inventory_digest': report['digest'],
                    'expected_provisioning_digest': report['provisioning_digest'], 'existing': existing},
                    confirmed=True, can_write=can_write, allowed_packs=allowed_packs)
                st.rerun()
            except (ValueError, OSError) as error:
                st.error(str(error))
                errors.append(str(error))
        chat_context.publish_surface(st.session_state, 'source_provisioning', root=root, pack=pack, actor_id=actor,
            allowed_packs=allowed_packs, summary=chat_summary.provisioning(report, table, columns=list(columns),
                target=target, existing=existing, can_write=can_write, receipt=receipt, errors=errors),
            selectors=[selection_key, 'provision_existing_' + token, 'provision_target_' + token, 'provision_columns_' + token])
        portal_jobs_page.render(root, actor, action='source_provisioning', job_key=key,
            allowed_packs=allowed_packs, can_write=can_write, key='provision_job_' + token)
    _local_candidate(root, pack, actor, allowed_packs=allowed_packs, can_write=can_write)


def uploaded_profile(root, pack, actor, *, allowed_packs, can_write):
    """Explicit durable profiling; returns only a currently bound private token."""
    import os
    from experiments.portal import identity
    if identity.mode(os.environ) not in {'local', 'demo'} or os.environ.get('SPARK_REMOTE'):
        return ''
    token = 'uploaded_profile_' + hashlib.sha256((str(root) + pack + actor).encode()).hexdigest()[:16]
    st.caption('Measure the actual runtime tables created from your TSVs. This private profile supports local mapping review, not production source qualification or approval.')
    ready = backend.local_profile_preview(root, pack, actor, allowed_packs=allowed_packs)
    for error in ready.get('errors') or []:
        st.info(error)
    if st.button('Prepare full profile from uploaded sources', key=token + '_start',
                 disabled=not can_write or not ready['ok']):
        try:
            portal_jobs.start(root, actor, action='uploaded_source_profile', job_key=token,
                arguments={'pack': pack, 'expected_digest': ready['digest']},
                confirmed=True, can_write=can_write, allowed_packs=allowed_packs)
            st.rerun()
        except (ValueError, OSError) as error:
            st.error(str(error))
    portal_jobs_page.render(root, actor, action='uploaded_source_profile', job_key=token,
        allowed_packs=allowed_packs, can_write=can_write, key=token + '_job')
    try:
        attempts = portal_jobs.recent(root, actor, action='uploaded_source_profile', job_key=token,
                                      allowed_packs=allowed_packs)
        completed = [row for row in attempts if row.get('status') == 'completed'
                     and isinstance(row.get('result'), dict) and row['result'].get('ok')]
        for row in completed:
            name = row['result'].get('profile')
            try:
                backend.read_local_profile(root, pack, actor, name, allowed_packs=allowed_packs)
            except (ValueError, OSError, KeyError, TypeError, SystemExit):
                continue
            st.success(f"Full uploaded-source profile available: {row['result']['tables']} tables · {row['result']['columns']} columns. Mapping review is still pending.")
            return name
        if completed:
            st.info('The retained profile no longer matches the current delivery. Prepare it again after completing the source changes.')
    except (ValueError, OSError):
        st.warning('Saved profile status could not be read. Refresh this page to recover it.')
    return ''


def _local_candidate(root, pack, actor, *, allowed_packs, can_write):
    """A separate source-backed action; the synthetic build retains its own label."""
    import json
    from experiments.portal import authoring_session, identity
    import os
    if identity.mode(os.environ) not in {'local', 'demo'}:
        return
    authority = authoring_session.CURRENT.get()
    permitted = can_write and (authority is None or 'run_gates' in authority.permissions)
    token = _local_build_key(root, pack, actor)
    with st.expander('Build an ADS from uploaded source tables'):
        st.caption(backend.LOCAL_BUILD_NOTICE)
        st.write('Review every variable and source mapping first. This build reads your provisioned tables and keeps its dataset and dictionary privately with this profile.')
        if st.button('Check local build readiness', key=token + '_check', disabled=not permitted,
                     help=None if permitted else 'A data expert with run-check access can start this build.'):
            st.session_state[token + '_preview'] = backend.local_build_preview(root, pack, actor, allowed_packs=allowed_packs)
        preview = st.session_state.get(token + '_preview')
        if preview:
            if not preview['ok']:
                for error in preview['errors']:
                    st.warning(error)
            else:
                st.dataframe(preview['sources'], hide_index=True, width='stretch')
                st.caption(f"{preview['cohorts']} configured cohort(s). No source is replaced by generated example rows.")
                if st.button('Build local candidate', key=token + '_start', type='primary', disabled=not permitted):
                    try:
                        portal_jobs.start(root, actor, action='local_source_build', job_key=token,
                            arguments={'pack': pack, 'expected_digest': preview['digest']},
                            confirmed=True, can_write=permitted, allowed_packs=allowed_packs)
                        st.rerun()
                    except (ValueError, OSError) as error:
                        st.error(str(error))
        portal_jobs_page.render(root, actor, action='local_source_build', job_key=token,
            allowed_packs=allowed_packs, can_write=permitted, key=token + '_job')
        try:
            attempts = portal_jobs.recent(root, actor, action='local_source_build', job_key=token,
                allowed_packs=allowed_packs)
        except (ValueError, OSError):
            attempts = []
            st.warning('Saved candidate status could not be read. Refresh this page to recover its recorded files.')
        candidates = {row['result']['build_id']: row for row in attempts
            if row.get('status') == 'completed' and isinstance(row.get('result'), dict)
            and row['result'].get('ok') and row['result'].get('build_id')}
        # An ok payload alone is not completion: cancellation or interruption
        # may have won the final journal update. Only completed attempts count.
        latest = attempts[0] if attempts else {}
        latest_result = latest.get('result') or {}
        latest_id = latest_result.get('build_id') if (latest.get('status') == 'completed'
            and isinstance(latest_result, dict) and latest_result.get('ok')) else None
        result = candidates[latest_id]['result'] if latest_id in candidates else None
        if candidates and (len(candidates) > 1 or latest_id not in candidates):
            selection_key = token + '_candidate'
            if st.session_state.get(selection_key) not in candidates:
                st.session_state.pop(selection_key, None)
            selected = st.selectbox('Completed candidate to download', list(candidates), key=selection_key,
                format_func=lambda key: f"{candidates[key].get('created_at', '')[:19]} · {candidates[key]['result']['rows']:,} rows")
            result = candidates[selected]['result']
            if selected != latest_id:
                st.info('Showing a previously completed candidate. Its files are kept separately from the latest attempt.')
        if result and result.get('ok') and result.get('build_id'):
            st.success(f"Recorded local candidate: {result['rows']:,} rows · {result['columns']} columns")
            st.caption('This retained result belongs to its recorded inputs. Check local build readiness after edits to compare them again.')
            if preview and (not preview['ok'] or preview['digest'] != result.get('inputs_sha256')):
                st.warning('The last readiness check does not match this candidate. Review the current inputs and build again; the recorded files remain available below.')
            kinds = {'Dictionary': ('dictionary.md', 'text/markdown'),
                     'Manifest': ('manifest.json', 'application/json'),
                     'Output checks': ('output-contract.json', 'application/json'),
                     'Source checks': ('source-checks.json', 'application/json'),
                     'Dataset checks': ('dataset-checks.json', 'application/json'),
                     'Dataset (Parquet)': ('ads.parquet', 'application/octet-stream')}
            choice = st.selectbox('Candidate file', list(kinds), key=token + '_file')
            filename, mime = kinds[choice]
            try:
                raw = backend.local_build_file(root, pack, actor, result['build_id'], filename,
                    expected_manifest_sha256=result['manifest_sha256'], allowed_packs=allowed_packs)
                st.download_button('Download ' + choice.lower(), raw, file_name=filename, mime=mime, key=token + '_download')
                if choice == 'Dictionary':
                    st.markdown(raw.decode('utf-8'))
                elif choice in {'Manifest', 'Output checks', 'Source checks', 'Dataset checks'}:
                    st.json(json.loads(raw))
            except (ValueError, OSError, KeyError) as error:
                st.error(str(error))
