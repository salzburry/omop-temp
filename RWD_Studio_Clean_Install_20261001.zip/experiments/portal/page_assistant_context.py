"""Bounded page facts for explanatory chat; never an editable widget catalogue."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone


KEY = "page_assistant_variable"
MAX_VALUE_BYTES = 2800
MAX_SNAPSHOT_BYTES = 14000
SURFACES_KEY = "page_assistant_surfaces"
SURFACES = {"knowledge", "semantic_graph", "semantic_export", "source_provisioning", "reviewer_enrollment", "job"}
ANSWER_PATHS = (
    "variable_id", "master_name", "derivation", "grain", "anchor", "window",
    "record_selection", "units", "source.kind", "source.value", "source.logical_table",
    "source.columns", "source.parameters", "output.type", "output.codes", "output.nullable",
    "output.physical_name", "output.target_table", "publish.ads", "publish.dictionary", "publish.dashboard",
)


def _identity(root, pack, actor_id, allowed_packs):
    return [str(Path(root).resolve()), pack, actor_id, sorted(set(allowed_packs or []))]


def _get(value, path):
    for key in path.split("."):
        if not isinstance(value, dict) or key not in value:
            return None
        value = value[key]
    return value


def _bounded(value):
    """Omit whole oversized values; a clipped formula can reverse its meaning."""
    try:
        encoded = json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (ValueError, TypeError, RecursionError):
        return {"omitted": True, "reason": "This value is not a finite JSON value."}
    if len(encoded) > MAX_VALUE_BYTES:
        return {"omitted": True, "reason": "Read the complete value in the editor; it exceeds the chat context limit.",
                "bytes": len(encoded), "sha256": hashlib.sha256(encoded).hexdigest()}
    return deepcopy(value)


def _answers(values, updates=None):
    updates = updates or {}
    return {path: _bounded(updates[path] if path in updates else _get(values, path))
            for path in ANSWER_PATHS
            if path in updates or _get(values, path) is not None}


def clear_variable(state):
    state.pop(KEY, None)


def publish_variable(state, *, root, pack, actor_id, allowed_packs, report, row, phase,
                     updates, typed=None, issues=()):
    """Publish the editor's actual computed proposal after a completed render.

    Only scientific/source/output metadata is retained. Source data rows, physical
    file paths, identity keys, approval controls and arbitrary session state are not
    part of this interface. No inference from widget names is needed.
    """
    if pack not in (allowed_packs or []):
        clear_variable(state)
        return
    values = row.get("values") or {}
    snapshot = {
        "item_id": row["item_id"], "variable": row["variable_id"], "phase": phase,
        "original_specification": {"wording": _bounded(row.get("definition", "")),
                                   "values": _bounded(row.get("spec_values", ""))},
        "saved_answers": _answers(values),
        "displayed_proposal": _answers(values, updates),
        "calculation": _bounded(updates.get("clinical_rule", row.get("clinical_rule") or {})),
        "treatment_family": _bounded(updates.get("family", row.get("family") or {})),
        "typed_values": _bounded((typed or {}).get("value") or
                                 (row.get("value_interpretation") or {}).get("value")),
        "typed_values_confirmed_in_editor": bool((typed or {}).get("confirmed")),
        "displayed_issues": _bounded(list(dict.fromkeys(str(value) for value in issues if value))),
        "saved_status": _bounded((row.get("phase_status") or {}).get(phase)),
        "rule": "Displayed proposals are unsaved editor answers, not evidence of approval or execution. "
                "Explain this row and its visible controls. Change only fields explicitly offered in editable_form; "
                "Do not change any other widget, identity, review confirmation or application state. "
                "The user saves the row and completes the existing review actions.",
    }
    # The whole snapshot remains bounded without silently dropping qualifications.
    if len(json.dumps(snapshot, ensure_ascii=False).encode("utf-8")) > MAX_SNAPSHOT_BYTES:
        for name in ("saved_answers", "displayed_proposal", "original_specification", "calculation", "treatment_family", "typed_values"):
            snapshot[name] = {"omitted": True, "reason": "The combined row context is too large; inspect this field in the editor."}
    state[KEY] = {"identity": _identity(root, pack, actor_id, allowed_packs),
                  "basis": [report.get("input_digest"), report.get("state_digest")], "snapshot": snapshot}


def variable_context(state, *, root, pack, actor_id, allowed_packs, report):
    """Return only a current selected row; stale/cross-profile snapshots are absent."""
    record = state.get(KEY)
    if not isinstance(record, dict) or pack not in (allowed_packs or []):
        return None
    if record.get("identity") != _identity(root, pack, actor_id, allowed_packs):
        return None
    if record.get("basis") != [report.get("input_digest"), report.get("state_digest")]:
        return None
    snapshot = record.get("snapshot") or {}
    navigation = state.get("variable_review_page_draft") or {}
    if (navigation.get("phase"), navigation.get("item_id")) != (snapshot.get("phase"), snapshot.get("item_id")):
        return None
    if not any(row.get("item_id") == snapshot.get("item_id") for row in report.get("rows") or []):
        return None
    return deepcopy(snapshot)


def task_context(meta, route, params=None):
    """Describe an already scope-checked route without leaking artifact paths."""
    result = {"route": route, "title": meta.title, "purpose": meta.purpose}
    for name in ("variable", "item_id", "study"):
        value = (params or {}).get(name)
        if isinstance(value, str) and value:
            result[name] = _bounded(value)
    return result


def _signature(value):
    try:
        raw = json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False, default=str).encode("utf-8")
    except (ValueError, TypeError, RecursionError):
        return None
    return hashlib.sha256(raw).hexdigest()


def _page_binding(state):
    return _signature([state.get("section"), state.get("connected_workflow"), state.get("flow_resolution_action"),
                       state.get("variable_review_phase"), state.get("variable_review_source_tables_open")])


def _authority_binding(root, actor_id, allowed_packs):
    from experiments.portal import authoring_session
    current = authoring_session.CURRENT.get()
    if current is None:
        return "unbound-local-page"
    if (current.root != str(Path(root).resolve()) or current.actor != actor_id
            or not set(allowed_packs or []) <= current.packs):
        return None
    return _signature([current.mode, sorted(current.permissions), sorted(current.packs)])


def clear_surface(state, surface):
    records = dict(state.get(SURFACES_KEY) or {})
    records.pop(surface, None)
    state[SURFACES_KEY] = records


def publish_surface(state, surface, *, root, pack, actor_id, allowed_packs, summary, selectors=()):
    """Capture only a page's explicitly allowlisted read-only summary.

    Selection hashes stay inside session state. They are never model context.
    This is the last rendered observation, not a fresh validation or permission.
    """
    if surface not in SURFACES:
        raise ValueError("Use an explicitly supported page context surface.")
    authority = _authority_binding(root, actor_id, allowed_packs)
    if pack not in (allowed_packs or []) or authority is None:
        clear_surface(state, surface)
        return
    try:
        raw = json.dumps(summary, sort_keys=True, ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (ValueError, TypeError, RecursionError):
        clear_surface(state, surface)
        return
    if len(raw) > 5000:
        summary = {"details_omitted": "This page summary exceeds the context limit; inspect its full details in the page."}
    records = dict(state.get(SURFACES_KEY) or {})
    records[surface] = {"identity": _identity(root, pack, actor_id, allowed_packs),
        "authority": authority, "page": _page_binding(state),
        "selectors": {key: _signature(state.get(key)) for key in selectors},
        "snapshot": {"observed_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                     "support": "Read-only last displayed metadata. Explain its controls and recorded problems. "
                                "This does not establish current approval, execution or permission; use the page's explicit actions to refresh or change it.",
                     **deepcopy(summary)}}
    state[SURFACES_KEY] = records


def surface_contexts(state, *, root, pack, actor_id, allowed_packs):
    if pack not in (allowed_packs or []):
        return {}
    identity = _identity(root, pack, actor_id, allowed_packs)
    authority = _authority_binding(root, actor_id, allowed_packs)
    result = {}
    for surface, record in (state.get(SURFACES_KEY) or {}).items():
        if (surface not in SURFACES or not isinstance(record, dict) or authority is None
                or record.get("identity") != identity or record.get("authority") != authority
                or record.get("page") != _page_binding(state)
                or any(_signature(state.get(key)) != value for key, value in (record.get("selectors") or {}).items())):
            continue
        result[surface] = deepcopy(record["snapshot"])
    if len(json.dumps(result, ensure_ascii=False).encode("utf-8")) > 12000:
        return {"details_omitted": "Several technical panels are open. Inspect their complete details in the page."}
    return result


def embedded_help(route):
    """Capabilities, not a claim that a table/job/enrollment was inspected."""
    result = {}
    if route == "variable_review":
        result["source_runtime"] = {
            "help": "In Source mapping, or Add or inspect source tables (optional), the user can import column metadata "
                    "and use Make a source available for execution. They choose a runtime table and names/types, "
                    "then explicitly create/profile it. Uploading alone does not provision or map a source.",
            "support": "Explanatory only. No source rows, provisioning selection or job result was supplied here; "
                       "do not claim to have read them or that provisioning succeeded.",
        }
    if route in {"g1_review", "g1_classify", "g2_review", "g3_review", "g4_review", "g5_review", "g6_review",
                 "g1_commit", "g2_commit", "g3_commit", "g4_commit", "g5_commit", "g6_commit"}:
        result["reviewer_identity"] = {
            "help": "The review/signing step exposes Reviewer identity enrollment in hosted mode. A different "
                    "authenticated administrator enrolls a reviewer's registered public-key fingerprint. "
                    "The reviewer still confirms and signs their own exact review.",
            "support": "Explanatory only. No roster, selected key, enrollment record or signature was supplied; "
                       "chat cannot enroll, impersonate, attest, sign or approve.",
        }
    return result


def enrich_card(card, *, root, pack, actor_id, allowed_packs, section, state, variable_details=True):
    """Use the same specialized context when a route is opened from Home or a tab."""
    from experiments.portal import connected_workflow
    from experiments.portal import connected_workflow_page

    if pack not in (allowed_packs or []):
        return card
    context = state.get(connected_workflow_page.KEY)
    valid = connected_workflow.valid(context, pack=pack, actor_id=actor_id,
                                    section=section, allowed_packs=allowed_packs)
    params = (context.get("params") or {}) if valid else None
    route = (card.get("current_task") or {}).get("route", "")
    # A card for another route cannot borrow this workspace's form selection.
    if valid and context["route"] != route:
        params = None
        valid = False
    if route == "plan_changes" and valid or section == "Plan changes" and not route:
        from experiments.portal import flow_assistant
        card = flow_assistant.plan_context(card, root=root, pack=pack, actor_id=actor_id,
            allowed_packs=allowed_packs, state=state, params=params)
    if route in {"source_requirements", "source_delivery", "source_evidence", "source_mapping"} and valid:
        from experiments.portal import source_workspace_page
        source = source_workspace_page.source_chat_context(root, pack, actor_id,
            allowed_packs=allowed_packs, route=route)
        if source.get("ok"):
            card.update(source["context"])
    if route in {"study_refresh", "study_protocol", "study_runs"} and valid:
        from experiments.portal import lifecycle_workspace_page
        card.update(lifecycle_workspace_page.assistant_context(root, pack, actor_id,
            allowed_packs=allowed_packs, route=route, params=params))
    if route == "variable_review" and valid:
        from experiments.portal import variable_review_workflow_page
        variable_review_workflow_page.begin_run()
        if variable_details:
            card["variable_workflow"] = variable_review_workflow_page.assistant_context(root, pack, actor_id,
                allowed_packs=allowed_packs, params=params)
        selected = (card.get("variable_workflow") or {}).get("selected_row")
        if selected:
            card["current_task"].update({"variable": selected["variable"], "item_id": selected["item_id"]})
        else:
            # An incoming citation is not evidence that this row is still selected.
            card["current_task"].pop("variable", None)
            card["current_task"].pop("item_id", None)
    extra = embedded_help(route)
    if extra:
        card["embedded_workflows"] = extra
    observed_route = (context or {}).get("route") if isinstance(context, dict) else None
    action_route = ((context or {}).get("params") or {}).get("action_id") if observed_route == "progress" else None
    route_matches = not route or route in {observed_route, action_route, state.get("flow_resolution_action")}
    observations = surface_contexts(state, root=root, pack=pack, actor_id=actor_id, allowed_packs=allowed_packs) if route_matches else {}
    if observations:
        card["page_observations"] = observations
        embedded = card.get("embedded_workflows") or {}
        if "source_provisioning" in observations and "source_runtime" in embedded:
            embedded["source_runtime"]["support"] = "Read-only displayed source readiness is in page_observations. No source data rows or command execution are supplied; provisioning remains an explicit UI action."
        if "reviewer_enrollment" in observations and "reviewer_identity" in embedded:
            embedded["reviewer_identity"]["support"] = "Read-only role/count/status context is in page_observations. No identities, fingerprints or attestation are supplied; chat cannot enroll, impersonate, attest, sign or approve."
    return card
