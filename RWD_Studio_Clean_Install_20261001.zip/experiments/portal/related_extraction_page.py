"""Inspect a typed specification snapshot and its explicit object relationships."""
from __future__ import annotations

import json
from pathlib import Path

import streamlit as st

from experiments.portal import related_extraction_workspace as backend


PREFIX = "related_extraction_"


def clear():
    for key in list(st.session_state):
        if str(key).startswith(PREFIX):
            st.session_state.pop(key, None)


def _text(value):
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, default=str)
    return str(value)


def _label(item):
    return f"{item.get('type', 'Record')} · {item.get('key') or item.get('id', '')}"


def _citation_rows(citations):
    return [{"Specification row": _text(item.get("item_id")), "Sheet": _text(item.get("tab")),
             "Row": _text(item.get("row")), "Field": _text(item.get("field"))}
            for item in citations or []]


def _intake_button():
    if st.button("Open specification intake", key=PREFIX + "intake",
                 help="Review the source and sheet/column mapping, then prepare the extraction again."):
        return {"route": "progress", "params": {"action_id": "g1_extract"}}
    return None


def _enumeration_evidence(report):
    evidence = report.get("enumeration_evidence")
    if not isinstance(evidence, dict):
        return None
    candidates, unparsed = evidence.get("candidates", []), evidence.get("unparsed", [])
    pending = [item for item in candidates if item.get("review_required")]
    st.caption(f"Value lists: {len(candidates)} candidate(s) retained · {len(pending)} literal list(s) need review · "
               f"{len(unparsed)} unparsed list(s). These parser counts do not report the saved scientific review status.")
    if not (candidates or unparsed):
        return None
    if pending or unparsed:
        st.warning(f"{len(pending) + len(unparsed)} specification value list(s) need review. "
                   "Source labels, numbers and ranges do not by themselves define output codes or calculation rules.")
    with st.expander("Specification value-list evidence"):
        entries = [{**item, "status": "Needs review" if item.get("review_required") else "Explicit mapping evidence"}
                   for item in candidates] + [{**item, "status": "Unparsed — needs review"} for item in unparsed]
        st.dataframe([{"Variable": item.get("variable", ""), "Specification row": item.get("item_id", ""),
                       "Status": item["status"], "Original Values cell": item.get("values_cell", ""),
                       "Candidate values": _text(item.get("values", [])), "Review guidance": item.get("why", "")}
                      for item in entries], hide_index=True, width="stretch")
        needs = [item for item in entries if item["status"] != "Explicit mapping evidence"]
        if needs:
            lookup = {item["item_id"]: item for item in needs}
            key = PREFIX + "enumeration_row"
            if st.session_state.get(key) not in lookup:
                st.session_state[key] = next(iter(lookup))
            selected = st.selectbox("Value list to review", list(lookup), key=key,
                                    format_func=lambda value: f"{lookup[value]['variable']} · {value}")
            st.caption("Confirm categories or bands in this variable's Values editor. Original source text remains unchanged; "
                       "a retained literal list continues to be source evidence after you record an interpretation.")
            if st.button("Review these values", key=PREFIX + "enumeration_review"):
                return {"route": "variable_review", "params": {"phase": "science", "item_id": selected}}
    return None


def _show_report(report):
    objects = report.get("objects") or []
    links = report.get("relationships") or []
    issues = report.get("issues") or []
    context_rows = report.get("context_rows") or []
    current_context = {row["item_id"] for row in context_rows if not row.get("context_stale")}
    by_id = {item["id"]: item for item in objects}
    counts = report.get("counts") or {}
    st.caption(f"{len(objects)} records · {len(links)} relationships · "
               f"{counts.get('resolved', sum(link.get('status') == 'resolved' for link in links))} resolved relationships")
    if issues:
        st.warning(f"{len(issues)} structure finding{'s' if len(issues) != 1 else ''} in the original specification.")
        st.dataframe([{"Finding": _text(issue.get("message")),
                       "Record": _label(by_id[issue["object_id"]]) if issue.get("object_id") in by_id else "",
                       "Specification row": _text(issue.get("item_id")), "Field": _text(issue.get("field")),
                       "Severity": _text(issue.get("severity"))} for issue in issues],
                     hide_index=True, width="stretch")
    elif not objects:
        if current_context:
            st.info("No clinical variables to check: the current rows are recorded as document metadata. "
                    "No variable structure checks remain; this is not a completed variable review.")
        else:
            st.warning("Not checkable: no typed specification records were found.")
    elif report.get("valid"):
        st.success("No structure findings in this source extraction snapshot.")
    else:
        st.warning("This source extraction snapshot did not pass its structure checks.")
    st.caption("Structure checks do not settle scientific decisions or validate source-table mappings. "
               "Review definitions and product values in the variable review.")
    value_route = _enumeration_evidence(report)
    if value_route:
        return value_route
    if issues:
        st.info("These findings refer to the original source cells and links. Saving a scientific interpretation "
                "does not change this snapshot or clear its source findings. Correct the listed source cells or "
                "sheet/column mapping in specification intake, prepare the extraction again, then check again.")
        route = _intake_button()
        if route:
            return route
    if context_rows:
        with st.expander(f"Document metadata and source citations ({len(context_rows)})"):
            st.caption("These classifications retain the original specification rows. Inspect or restore them in the variable list's Document metadata section.")
            st.dataframe([{"Specification row": row["item_id"], "Sheet": row.get("tab", ""),
                           "Row": row.get("row", ""), "Source text": row.get("variable_id", ""),
                           "Reason": row.get("context_reason", ""), "Recorded by": row.get("context_handled_by", ""),
                           "Status": "Source changed — review again" if row.get("context_stale") else "Document metadata"}
                          for row in context_rows], hide_index=True, width="stretch")
            if any(row.get("context_stale") for row in context_rows):
                st.warning("A metadata classification refers to older source text. That row is included in the current variable checks again.")
    if not objects:
        if current_context:
            if st.button("Review document metadata", key=PREFIX + "metadata"):
                return {"route": "variable_review", "params": {"phase": "science"}}
        else:
            st.info("Open specification intake to confirm that the source includes variable rows, review its "
                    "sheet/column mapping and prepare the extraction again.")
            if not issues:
                route = _intake_button()
                if route:
                    return route
    else:
        issue_ids = {issue.get("object_id") for issue in issues}
        ordered = sorted(objects, key=lambda item: (item["id"] not in issue_ids, _label(item).casefold()))
        options = [item["id"] for item in ordered]
        if st.session_state.get(PREFIX + "object") not in options:
            st.session_state[PREFIX + "object"] = options[0]
        selected = st.selectbox("Inspect a specification record", options, key=PREFIX + "object",
                                format_func=lambda value: _label(by_id[value]))
        item = by_id[selected]
        fields, raw = item.get("fields") or {}, item.get("raw_fields") or {}
        st.dataframe([{"Field": field, "Specification text": _text(raw.get(field)),
                       "Parsed value": _text(fields.get(field))} for field in dict.fromkeys([*raw, *fields])],
                     hide_index=True, width="stretch")
        if item.get("citations"):
            st.caption("Original specification citations")
            st.dataframe(_citation_rows(item["citations"]), hide_index=True, width="stretch")
        related = [link for link in links if selected in (link.get("source_id"), link.get("target_id"))]
        if related:
            st.caption("Related records")
            st.dataframe(_link_rows(related, by_id), hide_index=True, width="stretch")
        item_ids = list(dict.fromkeys(citation["item_id"] for citation in item.get("citations") or []
                                     if citation.get("item_id")))
        variable_rows = {citation["item_id"] for variable in objects
                         if str(variable.get("type", "")).casefold() == "variable"
                         for citation in variable.get("citations") or [] if citation.get("item_id")}
        variable_rows -= current_context
        if len(item_ids) == 1 and item_ids[0] in variable_rows:
            if st.button("Edit scientific interpretation", key=PREFIX + "review",
                         help="Edit this product's scientific meaning. Original specification cells and their findings stay unchanged."):
                return {"route": "variable_review", "params": {"phase": "science", "item_id": item_ids[0]}}
        with st.expander("All specification records and relationships"):
            st.dataframe([{"Record": _label(item), "ID": item["id"],
                           "Specification row": ", ".join(dict.fromkeys(str(citation.get("item_id", ""))
                               for citation in item.get("citations") or []))} for item in objects],
                         hide_index=True, width="stretch")
            if links:
                st.dataframe(_link_rows(links, by_id), hide_index=True, width="stretch")
    st.download_button("Download structure report", json.dumps(report, indent=2, ensure_ascii=False, default=str),
                       file_name="specification-structure.json", mime="application/json", key=PREFIX + "download")
    return None


def _link_rows(links, by_id):
    return [{"From": _label(by_id[link["source_id"]]) if link.get("source_id") in by_id else _text(link.get("source_id")),
             "Relationship": _text(link.get("kind")),
             "To": _label(by_id[link["target_id"]]) if link.get("target_id") in by_id else _text(link.get("reference")),
             "Status": _text(link.get("status")),
             "Possible matches": ", ".join(_label(by_id[candidate]) if candidate in by_id else str(candidate)
                                            for candidate in link.get("candidates") or [])} for link in links]


def render(root, pack, actor_id, *, can_view=True, allowed_packs=None):
    """Return a review navigation request; inspect only after an explicit check."""
    if not can_view:
        clear()
        return None
    allowed_packs = [pack] if allowed_packs is None else allowed_packs
    owner = (str(Path(root).resolve()), pack, actor_id, tuple(sorted(allowed_packs)))
    old_owner = st.session_state.get(PREFIX + "owner")
    if old_owner != owner:
        clear()
        st.session_state[PREFIX + "owner"] = owner
    current = backend.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    digest = current.get("input_digest")
    previous = st.session_state.get(PREFIX + "digest")
    changed = previous is not None and previous != digest
    if changed or not current.get("ok"):
        st.session_state.pop(PREFIX + "preview", None)
        st.session_state.pop(PREFIX + "object", None)
    st.session_state[PREFIX + "digest"] = digest
    with st.expander("Variables and related specification records"):
        st.caption("Inspect variables, product values, time windows and their explicit links in the extracted specification.")
        if current.get("notice"):
            st.caption(str(current["notice"]))
        if changed:
            st.info("The specification or structure schema changed, or a row classification or contract citation was updated. Check again to see the current records.")
        if not current.get("ok"):
            for error in current.get("errors") or ["The current specification snapshot could not be read."]:
                st.info(str(error))
            return _intake_button()
        if st.button("Check specification structure", key=PREFIX + "check"):
            with st.spinner("Checking specification records and relationships…"):
                result = backend.preview(root, pack, actor_id, expected_digest=digest, allowed_packs=allowed_packs)
            st.session_state.pop(PREFIX + "object", None)
            if result.get("ok") and result.get("input_digest") != digest:
                result = {"ok": False, "errors": ["The specification changed during the check. Check again to see current records."]}
            st.session_state[PREFIX + "preview"] = result
        checked = st.session_state.get(PREFIX + "preview")
        if checked:
            if not checked.get("ok"):
                for error in checked.get("errors") or ["The specification structure could not be checked."]:
                    st.error(str(error))
                return _intake_button()
            elif isinstance(checked.get("report"), dict):
                return _show_report(checked["report"])
        else:
            st.caption("Run this check when you want to inspect the current extraction. It does not save changes or run an AI model.")
    return None
