"""One product-wide review at a time, with edits owned by each review role."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json

import streamlit as st

from experiments.portal import variable_review_workflow as workflow
from experiments.portal import definition_reuse_logic as reuse_logic
from experiments.portal import variable_review_controls as controls
from experiments.portal import variable_review_consistency as consistency
from experiments.portal import variable_review_requirements as requirements
from experiments.portal import ui_text
from experiments.portal import theme


PREFIX = "variable_review_"
PHASES = ("science", "source", "output")
LABELS = {"science": "Scientific review", "source": "Source mapping", "output": "Output review"}
ROLES = {"science": "Scientific reviewer", "source": "Data expert", "output": "Output owner"}
SOURCE_KINDS = {"": "Choose a source", "vendor": "Delivered data column",
                "derived": "Calculated from other variables", "parameter": "Product setting",
                "constant": "Fixed value", "unavailable": "Unavailable",
                "pending_mapping": "Source mapping still needed"}
PUBLISH = ("undecided", "proposed", "required", "configured", "excluded")
READ_CACHE = "_variable_review_run_reports"


def begin_run():
    """Called once by the app before chat and the page share this run's read."""
    st.session_state[READ_CACHE] = {}


def _describe(root, pack, actor_id, allowed_packs):
    cache = st.session_state.get(READ_CACHE)
    refresh = bool(st.session_state.pop(PREFIX + "refresh_table", False))
    if cache is None:
        return workflow.describe(root, pack, actor_id, allowed_packs=allowed_packs, **({"refresh": True} if refresh else {}))
    key = _digest([str(root), pack, actor_id, allowed_packs])
    if key not in cache or refresh:
        cache[key] = workflow.describe(root, pack, actor_id, allowed_packs=allowed_packs, **({"refresh": True} if refresh else {}))
    return cache[key]


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, default=str).encode()).hexdigest()[:16]


def _get(values, path, default=""):
    value = values
    for part in path.split("."):
        if not isinstance(value, dict):
            return default
        value = value.get(part, default)
    return default if value is None else value


def _text(value):
    if value is None:
        return ""
    if isinstance(value, dict):
        return "\n".join(f"{key} = {_text(item)}" for key, item in value.items())
    if isinstance(value, (list, tuple)):
        return "\n".join(_text(item) for item in value)
    return str(value)


def _blank_placeholder(value):
    text = _text(value)
    return "" if text.strip() in {"TODO", "REPLACE_ME"} else text


def _lines(value):
    return list(dict.fromkeys(line.strip() for line in value.splitlines() if line.strip()))


def _spec_values(value):
    if not isinstance(value, dict):
        return _text(value)
    return _text({key: item for key, item in value.items()
                  if str(key).strip().lower().replace("_", " ") in
                  {"value", "values", "codes", "allowed values", "time period"}
                  and item not in (None, "")})


def _issue_text(issue):
    if isinstance(issue, dict) and "message" in issue:
        return (str(issue["variable_id"]) + ": " if issue.get("variable_id") else "") + str(issue["message"])
    return _text(issue)


def _changed_updates(row, updates):
    changed = {}
    for path, value in updates.items():
        original = row.get(path, "") if path in workflow.META_FIELDS else _get(row.get("values") or {}, path)
        if value != original and _blank_placeholder(value) != _blank_placeholder(original):
            changed[path] = value
    # A changed master is reviewed with the displayed interpretation. The backend
    # must not replace that interpretation with an unseen master default.
    if "master_name" in changed:
        changed["derivation"] = updates.get("derivation", _get(row.get("values") or {}, "derivation"))
    if row.get("status") in {"ambiguous", "unmapped"} and "master_name" in updates:
        changed["master_name"] = updates["master_name"]
        changed["derivation"] = updates.get("derivation", _get(row.get("values") or {}, "derivation"))
    return changed


def _columns(value):
    result = {}
    for number, line in enumerate(value.splitlines(), 1):
        if not line.strip():
            continue
        role, separator, column = line.partition("=")
        role, column = role.strip(), column.strip()
        if not separator or not role or not column:
            raise ValueError(f"Source columns, line {number}: enter role = column.")
        if role in result:
            raise ValueError(f"Source columns, line {number}: '{role}' is repeated. Use one column per role.")
        result[role] = column
    return result


def _errors(result, *, focus=False):
    if focus:
        st.subheader("Changes need attention", anchor="rwd-variable-feedback")
        theme.queue_focus(st.session_state, "rwd-variable-feedback")
        st.html(theme.take_focus_markup(st.session_state, "rwd-variable-feedback"))
    errors = result.get("errors") or result.get("issues") or [result.get("message") or "The change could not be saved. Review the details and try again."]
    if isinstance(errors, str):
        errors = [errors]
    for error in errors:
        st.error(_text(error))


def _missing_scientific_answers(values, updates=None):
    updates = updates or {}
    return [label for path, label in (("derivation", "definition / logic / formula"), ("output.type", "data type"))
            if not workflow._answered(updates.get(path, _get(values, path)))]


def _science_save_label(*, missing=(), issues=(), clinical_issues=(), typed=None, custom=False):
    if missing or issues or clinical_issues:
        return "Save unfinished draft"
    if typed and typed.get("active"):
        return "Save variable"
    return "Save changes" if custom else "Use this definition"


def _definition_details_needed(row, values, masters, updates=None):
    trial = deepcopy(row)
    trial["values"] = deepcopy(values)
    for path, value in (updates or {}).items():
        if path not in workflow.META_FIELDS:
            workflow._put(trial["values"], path, value)
    master = next((item for item in masters if item.get("variable_id") == row.get("master_name")), None)
    return bool(not workflow._answered(trial["values"].get("derivation"))
                or row.get("status") in {"unmapped", "ambiguous"}
                or requirements.issues(trial, master))


def _saved_row_notice(report, selection):
    """Explain completion from the fresh dashboard, rather than the write result."""
    phase = selection.get("phase")
    saved = next((row for row in report.get("rows") or [] if row["item_id"] == selection.get("item_id")), None)
    if not saved or phase not in PHASES:
        st.info("Your changes were saved. Reload the table to check what remains.")
        return
    name = saved["variable_id"]
    if saved.get("phase_status", {}).get(phase) == "ready":
        st.success(f"{name} resolved for {LABELS[phase].lower()}. The dashboard is updated.")
        return
    missing = _missing_scientific_answers(saved.get("values") or {}) if phase == "science" else []
    details = ", ".join(missing) if missing else "; ".join(
        _issue_text(issue).rstrip(".") for issue in (saved.get("phase_issues") or {}).get(phase) or [])
    st.warning(f"{name} saved as an unfinished draft. " +
               ("Still needed: " + details + ". " if details else "") +
               "It stays in the attention list until these answers are complete.")


def _next_unfinished(rows, phase, item_id, order, pending=()):
    """Use the displayed order, but decide completion from the fresh saved rows."""
    lookup = {row["item_id"]: row for row in rows}
    current = lookup.get(item_id)
    if not current or current.get("phase_status", {}).get(phase) != "ready" or item_id in pending:
        return item_id if current else None
    ordered = list(dict.fromkeys([*order, *lookup]))
    position = ordered.index(item_id)
    following = ordered[position + 1:] + ordered[:position]
    return next((identity for identity in following if identity in lookup
                 and (lookup[identity].get("phase_status", {}).get(phase) != "ready" or identity in pending)), None)


def _save_actions(label, key, *, disabled, reason=""):
    if disabled:
        st.caption(reason or "Complete the highlighted answers before saving.")
    save_column, next_column = st.columns(2, gap="small")
    save = save_column.button(label, key=key + "save", type="primary", disabled=disabled,
        help=reason if disabled else None)
    advance = next_column.button("Save and next", key=key + "save_next", disabled=disabled,
        help=reason if disabled else "Save this variable, then open the next unfinished variable in this phase. Incomplete answers stay open.")
    return save or advance, advance


def _status(row, phase):
    if row.get("contract_choice_error"):
        return "Choose the existing output to review"
    if phase == "science" and row.get("identifier_error"):
        return "Fix definition identifier"
    if row.get("phase_status", {}).get(phase) == "ready":
        return "Ready for review"
    if phase == "science" and any("specification" in message.lower() for message in consistency.issues(row)):
        return "Data type conflicts with Excel"
    if phase == "science" and row.get("family"):
        from experiments.portal import variable_review_family
        issues = variable_review_family.issues(row)
        if issues:
            return issues[0] if len(issues[0]) <= 80 else issues[0][:77] + "..."
    if phase == "science" and row.get("master_name") and not row.get("master_missing"):
        missing = _missing_scientific_answers(row.get("values") or {})
        if len(missing) == 2:
            return "Definition and data type needed"
        if missing == ["definition / logic / formula"]:
            return "Definition / logic needed"
    if phase == "science" and row.get("status") == "unmapped":
        return "Choose a master or custom logic"
    if phase == "science" and row.get("status") == "ambiguous":
        return "Review ambiguous logic"
    issues = (row.get("phase_issues") or {}).get(phase) or []
    if phase == "science" and any("data type" in _issue_text(issue).lower() for issue in issues):
        return "Data type needed"
    if issues:
        issue = _issue_text(issues[0]).rstrip(".")
        return issue if len(issue) <= 80 else issue[:77] + "..."
    return "Needs attention"


def _rule_summary(row):
    rule = row.get("clinical_rule") or {}
    item = rule.get("native") or {}
    if "window" in item:
        w = item["window"]
        bounds = ("[" if w.get("include_start") else "(") + str(w.get("start", "?")) + ", " + str(w.get("end", "?")) + ("]" if w.get("include_end") else ")")
        bounds = bounds.replace("None", "unbounded")
        return (f"{item.get('select', 'Choose selection')} {item.get('value', {}).get('column', '')}",
                f"{w.get('anchor', 'Choose anchor')} {bounds} days")
    if "events" in item:
        return ("Time to " + ", ".join(e.get("name", "?") for e in item["events"]),
                f"{item.get('start', '?')} → event / censor; {item.get('time_unit', '?')}")
    return (_blank_placeholder(_get(row.get("values") or {}, "derivation")) or "Define this variable", "Choose a typed calculation")


def _review_grid(root, pack, actor_id, shown, report, *, permitted, local_demo, allowed_packs, key):
    labels = {"pending": "Not reviewed", "accepted": "Accept", "rejected": "Reject"}
    data = []
    for row, details in zip(shown, dashboard_rows(shown, "science")):
        rule, timeline = _rule_summary(row)
        data.append({**details, "Variable": row["variable_id"], "Specification": row.get("definition", ""),
            "Rule": rule, "Timeline": timeline, "Review": labels[row.get("review_choice", "pending")],
            "Comment": row.get("review_comment", ""), "Workbook row": row["item_id"]})
    with st.form(key + "review_form"):
        edited = st.data_editor(data, hide_index=True, width="stretch", height=min(420, 36 + 35 * max(1, len(data))),
            disabled=True if not permitted else [column for column in (data[0] if data else {}) if column not in {"Review", "Comment"}],
            column_order=["Variable", "Review", "Specification", "Rule", "Timeline", "Comment"],
            column_config={"Review": st.column_config.SelectboxColumn(options=list(labels.values()), required=True, width="small"),
                "Comment": st.column_config.TextColumn(max_chars=2000, width="medium"),
                "Variable": st.column_config.TextColumn(width=100),
                "Specification": st.column_config.TextColumn(width="medium"), "Rule": st.column_config.TextColumn(width="medium"),
                "Timeline": st.column_config.TextColumn(width="medium")}, key=key + "review_grid")
        submit = st.form_submit_button("Save review choices", disabled=not permitted)
    if submit:
        reverse = {label: choice for choice, label in labels.items()}
        result = workflow.review_rows(root, pack, actor_id,
            [{"item_id": row["Workbook row"], "choice": reverse.get(row["Review"], "invalid"), "comment": row.get("Comment") or ""} for row in edited],
            expected_input_digest=report["input_digest"], expected_state_digest=report["state_digest"],
            local_demo=local_demo, can_write=permitted, allowed_packs=allowed_packs)
        if result["ok"]:
            st.session_state[PREFIX + "notice"] = "Review choices saved."
            st.rerun()
        _errors(result, focus=True)


def dashboard_rows(rows, phase):
    """A phase's final review includes every variable, including automatic matches."""
    result = []
    for row in rows:
        values = row.get("values") or {}
        item = {"Variable": row.get("variable_id", ""), "Status": _status(row, phase),
                "Workbook row": row.get("item_id", "")}
        if phase == "science":
            item["Definition identifier"] = _get(values, "variable_id", row.get("variable_id", ""))
        if phase == "science":
            from experiments.portal import variable_review_lineage_page
            item["Master link"] = variable_review_lineage_page.label(row.get("master_tracking"))
            item.update({"Specification wording": row.get("definition", ""),
                         "Master": row.get("master_name") or _get(values, "master_name") or "Custom / not mapped",
                         "Definition / logic / formula": _blank_placeholder(_get(values, "derivation")) or "Not yet defined",
                         "Data type": _get(values, "output.type"),
                         "Variable kind": SOURCE_KINDS.get(_get(values, "source.kind"), _get(values, "source.kind")),
                         "Product value": _blank_placeholder(_text(_get(values, "source.value"))),
                         "Specification values / codes": _spec_values(row.get("spec_values")),
                         "Output codes": _blank_placeholder(_text(_get(values, "output.codes")))})
            record = row.get("value_interpretation") or {}
            typed = record.get("value") or (row.get("value_proposal") or {}).get("value") or {}
            item["Type of value"] = {"bands": "Categories", "codes": "Categories", "ordinal": "Ordered categories",
                "flag": "Yes or no", "continuous": "Number", "date": "Date", "text": "Text"}.get(
                    typed.get("kind"), _blank_placeholder(item["Data type"]) or "Choose type")
            item["Values"] = _value_summary(typed) or item["Output codes"] or item["Product value"] or item["Specification values / codes"]
            if row.get("family"):
                family = row["family"]
                item.update({"Treatment line": family.get("line_number"),
                             "Line attribute": family.get("attribute", "").replace("_", " "),
                             "Line numbering": family.get("numbering", "")})
        elif phase == "source":
            item.update({"Source": SOURCE_KINDS.get(_get(values, "source.kind"), _get(values, "source.kind")),
                         "Source alias": _get(values, "source.logical_table"),
                         "Table": _get(values, "source.physical_stem"),
                         "Columns": _text(_get(values, "source.columns")),
                         "Inputs": _text(_get(values, "source.inputs")),
                         "Dependencies": _text(_get(values, "depends_on"))})
        else:
            item.update({"Output column": _get(values, "output.physical_name"),
                         "Published name": _get(values, "output.target_published_name"),
                         "Role": _get(values, "output.role"),
                         "Analysis dataset": _get(values, "publish.ads"),
                         "Data dictionary": _get(values, "publish.dictionary"),
                         "Dashboard": _get(values, "publish.dashboard"),
                         "Tables, figures and listings": _get(values, "publish.tfl")})
        result.append(item)
    return result


def _value_summary(value):
    """Readable review-table values, including saved category boundaries."""
    if value.get("kind") == "bands":
        parts = []
        for band in value.get("bands") or []:
            lower, upper = band.get("lower"), band.get("upper")
            bounds = []
            if lower is not None:
                bounds.append(("≥ " if band.get("lower_inclusive") else "> ") + str(lower))
            if upper is not None:
                bounds.append(("≤ " if band.get("upper_inclusive") else "< ") + str(upper))
            parts.append(str(band.get("label") or "Category") + ": " + " and ".join(bounds))
        return "; ".join(parts)
    if value.get("codes"):
        return "; ".join(str(item.get("code", "")) +
            (" — " + str(item["label"]) if item.get("label") and str(item["label"]) != str(item.get("code")) else "")
            for item in value["codes"])
    if value.get("kind") == "date":
        return str(value.get("literal") or "Date")
    if value.get("kind") == "continuous":
        return " · ".join(str(item) for item in [value.get("unit"),
            ("Minimum " + str(value["minimum"])) if value.get("minimum") is not None else None,
            ("Maximum " + str(value["maximum"])) if value.get("maximum") is not None else None] if item) or "Number · no limits set"
    return "Free text" if value.get("kind") == "text" else ""


def _input(label, values, path, key, *, multiline=False, disabled=False, options=None):
    from experiments.portal import form_assistance
    choices = controls.choices_for(path) if options is None else options
    if choices or options is not None:
        if not isinstance(choices, dict):
            choices = {str(value): value for value in choices}
        current = _get(values, path)
        if isinstance(current, str) and not _blank_placeholder(current):
            current = ""
        value = controls.render_choice(label, current, choices, key=key + path,
            multiline=multiline, disabled=disabled, assist=not path.startswith('publish.') and path != 'output.name_status')
        return "" if value is None else value
    method = st.text_area if multiline else st.text_input
    return form_assistance.field(method, label, value=_blank_placeholder(_get(values, path)), key=key + path, disabled=disabled)


def _choice(label, values, path, options, key, *, disabled=False, labels=None):
    from experiments.portal import form_assistance
    current = _get(values, path)
    options = list(options)
    if current not in options:
        options.insert(0, current)
    return form_assistance.field(st.selectbox, label, options, index=options.index(current), key=key + path,
                        format_func=lambda value: (labels or {}).get(value, value or "Choose an answer"),
                        disabled=disabled)


def _science_fields(row, values, key, permitted, managed_fields=()):
    updates = {
        "derivation": _input("Definition / logic / formula", values, "derivation", key, multiline=True, disabled=not permitted),
    }
    if "source.kind" not in managed_fields:
        updates["source.kind"] = _choice("Variable kind", values, "source.kind", SOURCE_KINDS, key,
                                        labels=SOURCE_KINDS, disabled=not permitted)
    if "source.value" not in managed_fields:
        updates["source.value"] = _input("Value for this product", values, "source.value", key, disabled=not permitted)
    if "output.type" not in managed_fields:
        updates["output.type"] = _input("Data type", values, "output.type", key, disabled=not permitted)
    st.caption("Keep dates, cutoffs and study-specific values in the product value field. The reusable logic describes how to use them.")
    with st.expander("Scientific details"):
        for path, label in (
            ("grain", "One value per"), ("anchor", "Anchor date or event"),
            ("window", "Eligible time window"), ("record_selection", "Which records qualify"),
            ("tie_break", "Precedence and tie-breaking"), ("cohort_applicability", "Applicable population"),
            ("missing", "Missing / no-record behaviour"), ("units", "Units"),
            ("acceptance", "Example or acceptance criterion"), ("notes", "Review notes"),
            ("output.codes", "Output codes"),
        ):
            if path not in managed_fields:
                updates[path] = _input(label, values, path, key, multiline=True, disabled=not permitted)
        nullable = _get(values, "output.nullable", "")
        nullable_text = "true" if nullable is True else "false" if nullable is False else _text(nullable)
        if "output.nullable" not in managed_fields:
            choice = _choice("Can the result be missing?", {"nullable": nullable_text}, "nullable", ("", "true", "false"), key,
                             labels={"": "Choose an answer", "true": "Yes", "false": "No"}, disabled=not permitted)
            updates["output.nullable"] = {"true": True, "false": False}.get(choice, choice)
    return updates


def _source_fields(values, key, permitted, options=None, row=None):
    options = options or {}
    updates = {"source.kind": _choice("Source kind", values, "source.kind", SOURCE_KINDS, key,
                                      labels=SOURCE_KINDS, disabled=not permitted)}
    st.caption("Changing an already reviewed variable kind reopens the scientific review.")
    kind = updates["source.kind"]
    updates.update({"source.logical_table": deepcopy(_get(values, "source.logical_table")),
        "source.physical_stem": deepcopy(_get(values, "source.physical_stem")),
        "source.columns": deepcopy(_get(values, "source.columns", {})),
        "source.inputs": deepcopy(_get(values, "source.inputs", {})),
        "source.parameters": deepcopy(_get(values, "source.parameters", [])),
        "depends_on": deepcopy(_get(values, "depends_on", [])), "_column_errors": []})
    obsolete = {
        "vendor": ("source.parameters",),
        "derived": ("source.inputs", "source.parameters", "source.physical_stem", "source.columns", "source.logical_table"),
        "constant": ("source.inputs", "source.parameters", "source.physical_stem", "source.columns", "source.logical_table", "depends_on"),
        "unavailable": ("source.inputs", "source.parameters", "source.columns", "source.logical_table", "depends_on"),
        "pending_mapping": ("source.inputs", "source.parameters", "source.columns", "source.logical_table", "depends_on"),
        "parameter": ("source.inputs", "source.columns", "source.logical_table", "depends_on"),
    }.get(kind, ())
    if any(workflow._answered(_get(values, path)) for path in obsolete):
        st.caption("Saving as " + SOURCE_KINDS.get(kind, kind) +
                   " removes the previous source fields that do not apply to this kind.")
    for path in obsolete:
        updates[path] = {} if path in {"source.inputs", "source.columns"} else [] if path in {"source.parameters", "depends_on"} else ""
    current_inputs = _get(values, "source.inputs")
    if kind == "vendor":
        updates["source.logical_table"] = _input("Source alias", values, "source.logical_table", key,
            options=options.get("aliases", []), disabled=not permitted)
        alias = updates["source.logical_table"]
        table_definition = next((table for table in options.get("tables", []) if table.get("alias") == alias), {})
        table_names = table_definition.get("table_stems") or options.get("table_stems", [])
        updates["source.physical_stem"] = _input("Source table name", values, "source.physical_stem", key,
            options=table_names, disabled=not permitted)
        chosen_table = updates["source.physical_stem"]
        known_columns = options.get("columns_by_table", {}).get(chosen_table or alias, [])
        known_roles = (options.get("roles_by_table", {}).get(alias)
                       or options.get("roles_by_table", {}).get(chosen_table)
                       or options.get("column_roles", []))
        if row and row.get("family"):
            from experiments.portal import variable_review_family
            needed_roles = variable_review_family.source_roles(row)
            if needed_roles:
                st.caption("This treatment-line variable needs these column roles: " + ", ".join(needed_roles) + ".")
                known_roles = list(dict.fromkeys([*needed_roles, *known_roles]))
        from experiments.portal.variable_review_source_controls import render_columns
        updates["source.columns"], updates["_column_errors"] = render_columns(
            _get(values, "source.columns", {}), key=key, roles=known_roles,
            columns=known_columns, disabled=not permitted)
        from experiments.portal.variable_review_linked_sources import render as render_linked_sources
        # Inputs takes precedence over the primary mapping in canonical checks.
        # Show linked tables separately, then explicitly include the main table.
        previous_alias = _get(values, "source.logical_table")
        linked = deepcopy(current_inputs)
        if isinstance(linked, dict) and linked.get(previous_alias) == _get(values, "source.columns"):
            linked.pop(previous_alias, None)
        linked, unfinished = render_linked_sources(linked, options, key=key + "linked", permitted=permitted)
        updates["_column_errors"].extend(unfinished)
        if linked:
            if alias in linked and linked[alias] != updates["source.columns"]:
                updates["_column_errors"].append("This input repeats the main source with different columns. Remove it and edit the main mapping above.")
            elif workflow._answered(alias) and updates["source.columns"]:
                linked[alias] = deepcopy(updates["source.columns"])
                st.caption("The main source and its column mappings above are included with these linked inputs.")
            else:
                updates["_column_errors"].append("Complete the main source alias and columns before saving linked sources.")
        updates["source.inputs"] = linked
    elif kind == "parameter":
        updates["source.parameters"] = controls.render_multi("Product settings used", _get(values, "source.parameters"),
            options.get("configured_parameters", options.get("parameters", [])), key=key + "source.parameters", disabled=not permitted)
        st.caption("Use this product's configuration paths. The product value is reviewed in the scientific table.")
    elif kind == "constant":
        st.write("Fixed value for this product: " + (_text(_get(values, "source.value")) or "Not decided"))
        st.caption("Edit the fixed value in the scientific table.")
    elif kind == "derived":
        st.caption("Select the defined variables used by this calculation.")
    elif kind in {"unavailable", "pending_mapping"}:
        if kind == "pending_mapping":
            st.info("This mapping stays unfinished until a source kind and its required fields are resolved.")
        updates["source.physical_stem"] = _input("Source table reference (optional)", values, "source.physical_stem", key,
            options=options.get("table_stems", []), disabled=not permitted)
        reasons = ["Not supplied by this data provider", "Not collected for this population",
                   "Unavailable for the selected data period", "The existing source lacks the required information"] if kind == "unavailable" else [
                   "The source table has not been identified", "The column mapping needs a data expert",
                   "Awaiting delivery metadata", "A new source adapter is required"]
        updates["source.reason"] = _input("Why is this source unavailable?" if kind == "unavailable" else "What needs to be resolved?",
            values, "source.reason", key, options=reasons, multiline=True, disabled=not permitted)
    else:
        st.info("Choose a source kind to see the fields it needs.")
    if kind in {"vendor", "derived"}:
        updates["depends_on"] = controls.render_multi("Dependencies", _get(values, "depends_on"),
            options.get("input_variables", []), key=key + "depends_on", disabled=not permitted)
    with st.expander("Source details"):
        if kind == "parameter":
            updates["source.physical_stem"] = _input("Source table reference (optional)", values, "source.physical_stem", key,
                options=options.get("table_stems", []), disabled=not permitted)
        updates["source.spec_identifiers"] = controls.render_multi("Specification identifiers", _get(values, "source.spec_identifiers"),
            options.get("spec_identifiers", []), key=key + "source.spec_identifiers", disabled=not permitted)
        updates["implementation_refs"] = _input("Implementation references (one per line)", values,
            "implementation_refs", key, multiline=True, disabled=not permitted)
        if kind not in {"unavailable", "pending_mapping"}:
            updates["source.reason"] = _input("Mapping explanation", values, "source.reason", key, multiline=True, disabled=not permitted)
    return updates


def _output_fields(values, key, permitted, options=None):
    options = options or {}
    updates = {}
    for path, label in (("output.physical_name", "Output column name"), ("output.target_published_name", "Published variable name")):
        updates[path] = _input(label, values, path, key, disabled=not permitted,
            options=options.get("output_names" if path == "output.physical_name" else "published_names", []))
    updates["output.role"] = _choice("Output role", values, "output.role", ("", "published", "internal", "metadata", "excluded"), key, disabled=not permitted)
    updates["output.name_status"] = _choice("Naming decision", values, "output.name_status", ("", "undecided", "aligned"), key, disabled=not permitted)
    st.write("**Where should this variable be included?**")
    for path, label in (("publish.ads", "Analysis dataset"), ("publish.dictionary", "Data dictionary"),
                        ("publish.dashboard", "Dashboard"), ("publish.tfl", "Tables, figures and listings")):
        updates[path] = _choice(label, values, path, PUBLISH, key, disabled=not permitted)
    return updates


def _master_fields(row, candidate, comparison, values, key, permitted, managed_fields=()):
    required_paths = {slot["field"] for slot in requirements.fields(row, candidate) if slot["required"]}
    fields = []
    for original in comparison.get("fields") or []:
        field = dict(original)
        field["has_excel"] = bool(field.get("has_excel") and _blank_placeholder(field.get("excel_value")).strip())
        if not field["has_excel"]:
            field["excel_value"] = None
        field["master_options"] = [option for option in field.get("master_options") or []
                                   if _blank_placeholder(option.get("value")).strip()]
        if not _blank_placeholder(field.get("master_value")).strip():
            field["master_value"] = None
        field["has_master"] = bool(field.get("master_value") is not None or field["master_options"])
        fields.append(field)
    st.dataframe([{"Field": "Name", "Excel": row["variable_id"], "Master": candidate["variable_id"]},
        *[{"Field": "Specification wording (reference)" if field["path"] == "definition" else field["label"], "Excel": ui_text.display_line_breaks(_text(field.get("excel_value"))) or
           ("No separate formula supplied; see specification wording" if field["path"] == "derivation" and row.get("definition") else "Not declared"),
           "Master": ui_text.display_line_breaks(_text(field.get("master_value"))) or " / ".join(ui_text.display_line_breaks(_text(option.get("value"))) for option in field.get("master_options") or []) or "Not declared"}
          for field in fields if field.get("has_excel") or field.get("has_master") or field.get("master_options")]],
        hide_index=True, width="stretch")
    st.caption("Excel values are kept by default. Choose Master for a field only when that declared value fits this product, or choose Edit.")
    updates, choices = {}, {}
    for field in fields:
        path = field["path"]
        if field.get("editable") is False or path == "definition" or path in managed_fields:
            continue
        current_text = _blank_placeholder(field.get("current_value", _get(values, path))).strip()
        has_value = bool(current_text and current_text.casefold() not in {"n/a", "not applicable"})
        declared = field.get("has_excel") or field.get("has_master") or field.get("master_options")
        product_setting = path == "source.value" and (updates.get("source.kind") or _get(values, "source.kind") or candidate.get("declared_source_kind")) in {"parameter", "constant"}
        if path not in {"derivation", "output.type", "source.kind"} and path not in required_paths and not (declared or has_value or product_setting):
            continue
        label = {"derivation": "Definition / logic / formula", "source.value": "Value for this product", "output.type": "Data type",
                 "source.kind": "Variable kind", "output.codes": "Output codes", "window": "Baseline / eligible window"}.get(path, field["label"])
        options = [*(["excel"] if field.get("has_excel") else []), *(["master"] if field.get("has_master") or field.get("master_options") else []), "edit"]
        saved = (row.get("field_choices") or {}).get(path)
        default = saved or field.get("default_choice") or ("excel" if field.get("has_excel") else "master" if path == "derivation" and "master" in options else "edit")
        if path == "derivation" and not saved and not field.get("has_excel") and candidate["variable_id"] != row.get("master_name") and "master" in options and candidate.get("reuse_readiness") == "ready":
            default = "master"
        if default not in options:
            default = "edit"
        source = st.selectbox("Use for " + label, options, index=options.index(default), key=key + "choose_" + candidate["variable_id"] + "_" + path,
            format_func=lambda choice: {"excel": "Excel", "master": "Master", "edit": "Edit"}[choice], disabled=not permitted)
        choices[path] = source
        if source == "master":
            if path == "derivation" and candidate.get("reuse_readiness") == "needs_edit":
                st.caption("This is the master's recorded wording and needs review. Choose Edit to resolve product-specific values or literals.")
            variants = field.get("master_options") or []
            if variants:
                previous = next((index for index, option in enumerate(variants) if option.get("value") == field.get("current_value")), None) if saved == "master" else None
                option = st.selectbox("Master option for " + label, list(range(len(variants))), index=previous,
                    key=key + "option_" + candidate["variable_id"] + "_" + path,
                    format_func=lambda index: " · ".join(str(part) for part in (
                        "Illustrative" if variants[index].get("illustrative") else "",
                        variants[index].get("variant") or variants[index].get("label"), _text(variants[index].get("value"))) if part),
                    placeholder="Choose the declared master option", disabled=not permitted)
                if option is None:
                    st.info("Choose a master option for " + label.lower() + ".")
                    updates[path] = None
                    continue
                updates[path] = variants[option]["value"]
                provenance = " · ".join(str(part) for part in (variants[option].get("source_path"), variants[option].get("variant")) if part)
                if provenance:
                    st.caption("Master source: " + _text(provenance))
            else:
                updates[path] = field.get("master_value", "")
            st.text(label + ": " + _text(updates[path]))
        elif source == "excel":
            updates[path] = field.get("excel_value", "")
            st.text(label + ": " + (_text(updates[path]) or "Not declared in Excel"))
        elif path == "source.kind":
            updates[path] = _choice(label, values, path, SOURCE_KINDS, key, labels=SOURCE_KINDS, disabled=not permitted)
        else:
            updates[path] = _input(label, values, path, key, multiline=path not in {"output.type", "source.value", "units"}, disabled=not permitted)
            if path in getattr(workflow, "LIST_FIELDS", set()):
                updates[path] = _lines(updates[path])
    updates["field_choices"] = choices
    return updates


def _logic_choice(row, values, candidate, updates, key, permitted, *, input_digest=""):
    """Put the service's required confirmation beside Save, bound to this rule.

    A checkbox is useful only if that confirmation resolves the real guard.
    Calendar literals and other non-confirmable errors still require an edit.
    """
    trial = deepcopy(row)
    trial.setdefault("existing_contract", False)
    trial["values"] = deepcopy(values)
    for path, value in updates.items():
        if path in workflow.META_FIELDS:
            trial[path] = value
        else:
            workflow._put(trial["values"], path, value)
    interpretation = _get(trial["values"], "derivation") or ""
    unchanged = (interpretation == _get(row["values"], "derivation")
        and trial.get("master_name", "") == row.get("master_name", "")
        and trial["values"].get("source") == row["values"].get("source"))
    trial["logic_changed"] = row.get("logic_changed") or not unchanged
    binding = _digest([input_digest, trial.get("master_name"), interpretation,
                      trial["values"].get("source"), (candidate or {}).get("record")])
    state_key = key + "logic_review_binding"
    previous = st.session_state.get(state_key)
    changed = previous is not None and previous != binding
    if changed:
        # Returning to earlier text is another edit, not permission to revive
        # a checkbox that was checked before the intervening change.
        for name in list(st.session_state):
            if str(name).startswith(key + "logic_reviewed_"):
                del st.session_state[name]
    st.session_state[state_key] = binding
    if not workflow._answered(interpretation):
        return []  # Unfinished definitions may still be saved as drafts.
    masters = [candidate] if candidate else []
    pending = workflow._logic_issues({**trial, "logic_reviewed": False}, masters)
    confirmed = workflow._logic_issues({**trial, "logic_reviewed": True}, masters)
    if pending and not confirmed:
        st.caption("Confirm that the thresholds and time windows in this rule are intended before saving.")
        st.text("Rule to confirm: " + interpretation)
        updates["logic_reviewed"] = st.checkbox("I reviewed the thresholds and time windows in this reusable logic.",
            value=bool(row.get("logic_reviewed") and unchanged and not changed),
            key=key + "logic_reviewed_" + binding, disabled=not permitted)
        return [] if updates["logic_reviewed"] else pending
    if pending:
        st.text("Rule to edit: " + interpretation)
        for issue in pending:
            st.warning(issue)
    return pending


def _save_to_library(root, pack, actor_id, row, updates, *, local_demo, permitted, allowed_packs):
    key = PREFIX + "library_" + _digest([str(root), pack, actor_id, row["item_id"]]) + "_"
    if st.session_state.get(key + "saved"):
        st.success(st.session_state[key + "saved"] + " is available as a draft master definition.")
        return
    if not st.checkbox("Save this definition to the master library for future products", key=key + "show", disabled=not permitted):
        return
    if _changed_updates(row, updates):
        st.info("Save the definition for this product first. Then review the reusable library entry here.")
        return
    from experiments.portal import master_definition_drafts as library_drafts
    context = library_drafts.describe(root, pack, actor_id, item_id=row["item_id"], allowed_packs=allowed_packs)
    if not context.get("ok"):
        _errors(context)
        return
    binding = {name: context[name] for name in ("input_digest", "state_digest", "library_digest")}
    if key + "loaded" not in st.session_state:
        st.session_state[key + "loaded"] = binding
    displayed = st.session_state[key + "loaded"]
    stale = displayed != binding
    if stale:
        st.warning("The product or master library changed while this form was open. Reload its source before saving.")
        if st.button("Reload library source", key=key + "reload"):
            st.session_state[key + "loaded"] = binding
            st.rerun()
    values = row["values"]
    st.caption("This creates a draft library template. Product dates, values and example settings stay with the product.")
    st.caption("Its origin, recorded master version and scientific changes are retained as history when later products reuse it. Give a product-specific variant a distinct library name.")
    name = st.text_input("New master variable name", value=row["variable_id"], key=key + "name")
    label = st.text_input("Master definition label", value=row["variable_id"], key=key + "label")
    definition = st.text_area("Reusable definition", value=_text(row.get("definition")), key=key + "definition")
    st.text("Saved reusable logic: " + _text(values.get("derivation")))
    st.text("Data type: " + _text(_get(values, "output.type")))
    raw_slots = st.text_area("Product setting slots (name = description, one per line)", key=key + "slots",
                             help="Describe each setting that a future product must supply. Keep actual values in the product.")
    if st.button("Save new master definition", key=key + "save", disabled=not permitted or stale) and not stale:
        try:
            try:
                slots = [{"name": name, "description": description} for name, description in _columns(raw_slots).items()]
            except ValueError as error:
                raise ValueError(str(error).replace("Source columns", "Product setting slots").replace("role = column", "name = description")) from error
            result = library_drafts.save(root, pack, actor_id, item_id=row["item_id"], name=name, label=label,
                definition=definition, logic=values.get("derivation", ""), data_type=_get(values, "output.type"),
                source_kind=_get(values, "source.kind"), parameter_slots=slots,
                expected_input_digest=displayed["input_digest"], expected_state_digest=displayed["state_digest"],
                expected_library_digest=displayed["library_digest"], allowed_packs=allowed_packs,
                local_demo=local_demo, can_write=permitted, confirmed=True)
        except (ValueError, OSError) as error:
            st.error(str(error))
            return
        if not result.get("ok"):
            _errors(result)
            return
        st.session_state[key + "saved"] = result.get("name", name)
        st.session_state[PREFIX + "notice"] = "Saved " + result.get("name", name) + " as a draft master definition for future products."
        st.rerun()


def _shared_source(root, pack, actor_id, report, row, updates, *, key, permitted, local_demo, allowed_packs):
    """Preview an explicit group edit; diagnosis sources are never inferred."""
    from experiments.portal import variable_review_source_batch as source_batch
    attributes = {"regimen", "start_date", "delivered_end_date", "last_activity_date"}
    family = row.get("family") or {}
    if family.get("name") != "treatment_line" or family.get("attribute") not in attributes:
        return
    siblings = [item for item in report["rows"] if item["item_id"] != row["item_id"]
                and (item.get("family") or {}).get("name") == "treatment_line"
                and item["family"].get("attribute") in attributes]
    if not siblings:
        return
    with st.expander("Reuse this source for other treatment-line variables"):
        lookup = {item["item_id"]: item for item in siblings}
        selected = st.multiselect("Also apply this source to", list(lookup), key=key + "source_siblings",
            format_func=lambda item_id: lookup[item_id]["variable_id"], disabled=not permitted)
        st.caption("Share the table and role-to-column mapping. Each variable keeps its own line, attribute and scientific definition.")
        if not selected:
            return
        shared_fields = {"source.kind", "source.logical_table", "source.physical_stem", "source.columns"}
        shared = {path: deepcopy(updates[path]) for path in shared_fields}
        extras = {path: value for path, value in updates.items() if path not in shared_fields and path != "_column_errors"}
        trial = deepcopy(row["values"])
        for path, value in shared.items():
            workflow._put(trial, path, value)
        try:
            synchronized = source_batch._sync_primary_input(row, trial)
        except ValueError:
            synchronized = None  # The batch reports the conflicting row before writing.
        if synchronized is not None and extras.get("source.inputs") == synchronized:
            # Updating the redundant main input is part of the shared edit.
            # Actual changes to linked tables still require a separate row save.
            extras.pop("source.inputs", None)
        for path in ("source.parameters", "source.spec_identifiers", "depends_on", "implementation_refs"):
            if isinstance(extras.get(path), str):
                extras[path] = _lines(extras[path])
        pending = bool(_changed_updates(row, extras))
        if pending:
            st.info("Save this variable's other source edits first, then apply its shared mapping.")
        st.dataframe([{"Variable": item["variable_id"], "Source alias": shared["source.logical_table"],
                       "Table": shared["source.physical_stem"], "Columns": _text(shared["source.columns"])}
                      for item in [row, *(lookup[item_id] for item_id in selected)]], hide_index=True, width="stretch")
        if st.button("Apply source to selected variables", key=key + "apply_source", disabled=not permitted or pending):
            if updates.get("_column_errors"):
                _errors({"errors": updates["_column_errors"]})
                return
            result = source_batch.save_rows(root, pack, actor_id, [row["item_id"], *selected], shared,
                expected_input_digest=report["input_digest"], expected_state_digest=report["state_digest"],
                allowed_packs=allowed_packs, local_demo=local_demo, can_write=permitted)
            if not result.get("ok"):
                _errors(result)
                return
            _continue_row_entries(root, pack, actor_id, report, phase="source",
                saved_ids=[row["item_id"], *selected], allowed_packs=allowed_packs)
            st.session_state[PREFIX + "notice"] = "Source mapping saved for " + ", ".join(result["variable_ids"]) + "."
            st.session_state.setdefault("flow_result", {}).pop(pack, None)
            st.rerun()


def _identifier_controls(root, pack, actor_id, report, row, key, *, permitted, local_demo, allowed_packs, attention_view):
    current = _get(row.get("values") or {}, "variable_id", row["variable_id"])
    issue = row.get("identifier_error") or workflow.definitions.identifier_problem(current)
    with st.expander("Definition identifier", expanded=bool(issue)):
        if issue:
            st.warning(issue)
        existing = bool(row.get("existing_contract"))
        proposed = st.text_input("Definition identifier", value=str(current), key=key + "identifier",
            disabled=not permitted or existing,
            help="Use 1–80 characters: start with a letter, then use letters, digits or underscores. Example: LOT1_DATE. The original specification label and citation are kept.")
        problem = workflow.definitions.identifier_problem(proposed)
        if problem and proposed != current:
            st.error(problem)
        if existing:
            st.caption("This identifier belongs to an existing contract record. Use the definition editor's revision workflow to change that record.")
            original = row.get("contract_variable_id")
            if original == current or workflow.definitions.identifier_problem(original):
                return
            proposed = original
            save_identifier = st.button("Restore existing identifier", key=key + "save_identifier",
                disabled=not permitted, help="Restore this draft's original contract identifier and keep its other answers.")
        else:
            save_identifier = st.button("Save identifier", key=key + "save_identifier",
                disabled=not permitted or bool(problem) or proposed == current)
        if save_identifier:
            result = workflow.save_row(root, pack, actor_id, row["item_id"], "science", {"variable_id": proposed},
                expected_input_digest=report["input_digest"], expected_state_digest=report["state_digest"],
                allowed_packs=allowed_packs, local_demo=local_demo, can_write=permitted)
            if not result.get("ok"):
                _errors(result)
                return
            _continue_row_entries(root, pack, actor_id, report, phase="science",
                saved_ids=[row["item_id"]], allowed_packs=allowed_packs, identifier_only=True)
            st.session_state[PREFIX + "notice"] = "Definition identifier saved. The specification wording and citation are kept."
            st.session_state[PREFIX + "saved_selection"] = {"phase": "science", "item_id": row["item_id"], "attention": attention_view}
            st.session_state.setdefault("flow_result", {}).pop(pack, None)
            st.rerun()


def _row_entry_keys(prefix):
    actions = {"save", "save_next", "family", "custom", "search", "apply_source", "save_identifier",
               "lineage_usage", "lineage_refresh_master", "lineage_history_load",
               "clinical_ecog_compact_use_product", "clinical_ecog_compact_use_index", "clinical_ecog_compact_edit"}
    return [name for name in list(st.session_state)
            if str(name).startswith(prefix) and str(name)[len(prefix):] not in actions
            and not str(name).endswith(("_remove", "_mapping_add", "_source_add", "typed_suggest", "typed_discard", "_table_widget", "_apply_type"))]


def _retain_row_entries():
    # Keep editable widget values while a row is unselected or another row is
    # open. Action buttons are transient events and must never be restored.
    navigation = st.session_state.get(PREFIX + "page_draft", {})
    for suffix, field in (("phase", "phase"), ("science_view", "view")):
        if PREFIX + suffix not in st.session_state and navigation.get(field):
            st.session_state[PREFIX + suffix] = navigation[field]
    if (PREFIX + "workbook_draft_open" not in st.session_state
            and type(navigation.get("workbook_draft_open")) is bool):
        st.session_state[PREFIX + "workbook_draft_open"] = navigation["workbook_draft_open"]
    prefix = PREFIX + "row_"
    row_prefixes = {str(name)[:len(prefix) + 17] for name in st.session_state
                   if str(name).startswith(prefix) and len(str(name)) > len(prefix) + 16
                   and str(name)[len(prefix) + 16] == "_"}
    for row_prefix in row_prefixes:
        for name in _row_entry_keys(row_prefix):
            st.session_state[name] = st.session_state[name]
    for entry in st.session_state.get(PREFIX + "row_entries", {}).values():
        if entry.get("conflict"):
            continue
        # Draft data survives navigation independently of widget lifetimes.
        # Recreate absent controls from the draft, without replacing live input.
        for suffix, value in entry.get("fields", {}).items():
            if entry["key"] + suffix not in st.session_state:
                st.session_state[entry["key"] + suffix] = deepcopy(value)
        fields = _entry_fields(entry["key"])
        if fields and fields != entry["fields"]:
            entry["dirty"] = True
            entry["fields"] = fields


def suspend():
    """Capture the current draft before navigation; no reads, saves or approval."""
    _retain_row_entries()


def _entry_fields(key):
    return {str(name)[len(key):]: deepcopy(st.session_state[name]) for name in _row_entry_keys(key)}


def _forget_row_entry_field(item_id, phase, field_key):
    """Do not restore an explicitly discarded field before the next render."""
    entry = st.session_state.get(PREFIX + "row_entries", {}).get((item_id, phase))
    if entry and field_key.startswith(entry["key"]):
        entry.get("fields", {}).pop(field_key[len(entry["key"]):], None)


def _entry_key(pack, actor_id, item_id, phase, report):
    from experiments.portal.variable_review_draft import DraftIdentity
    identity = DraftIdentity(pack, actor_id, item_id, phase)
    generation = st.session_state.get(PREFIX + "draft_generations", {}).get(identity.key(), 0)
    return PREFIX + "row_" + identity.key(generation) + "_"


def _reset_entry_widgets(entry, pack, actor_id):
    from experiments.portal.variable_review_draft import DraftIdentity
    for name in list(st.session_state):
        if str(name).startswith(entry["key"]):
            del st.session_state[name]
    identity = DraftIdentity(pack, actor_id, entry["row"]["item_id"], entry["phase"]).key()
    generations = st.session_state.setdefault(PREFIX + "draft_generations", {})
    generations[identity] = generations.get(identity, 0) + 1


def _entry_basis(report):
    return (report.get("input_digest"), report.get("state_digest"))


def _calculation_fingerprint(state, key):
    """Bind the composed rule to raw controls too, without parsing grid diffs."""
    excluded = {key + "assistant_calculation", key + "save", key + "save_next"}
    # Data-editor mount inputs normalize integer cells to floats on rerender.
    # Bind its raw widget deltas and composed current rows, not that cache.
    empty_grid = {"edited_rows": {}, "added_rows": [], "deleted_rows": []}
    widgets = {str(name)[len(key):]: value for name, value in state.items()
               if str(name).startswith(key) and name not in excluded and not str(name).endswith("_table_basis")
               and not (str(name).endswith("_table_widget") and value == empty_grid)}
    return _digest([state.get(PREFIX + "context"), state.get(PREFIX + "page_draft"), widgets])


def _calculation_value(payload, row, typed_value):
    """Project the same output type/mapping as the manual calculation editor."""
    from experiments.portal import variable_clinical_rules as rules
    from experiments.portal import variable_clinical_value_page as mapping
    from experiments.portal import variable_review_values_page as values_page
    from experiments.portal import variable_review_family as families
    current = deepcopy(typed_value or values_page.current_value(row))
    nullable = current.get("missing_allowed")
    if "clinical_rule" in payload:
        rule = payload["clinical_rule"]
        if mapping.manages(rule):
            return mapping.output_value(rule, missing_allowed=nullable)
        generated = rules.scientific_updates(rule)
        emitted = next((item for item in rules.emitted_columns(rule) if item["result"] == rule.get("result")), None)
        if emitted:
            generated["output.type"] = emitted["type"]
            if emitted["type"] in {"integer", "long", "double"}:
                if rule.get("operator") == "lab_value":
                    units = rule.get("units") or []
                    generated["units"] = units[0] if len(units) == 1 else ""
                elif (rule.get("native") or {}).get("unit"):
                    generated["units"] = rule["native"]["unit"]
    else:
        generated = families.scientific_updates(payload["family"])
    datatype = consistency.canonical_type(generated.get("output.type"))
    if not datatype:
        return current
    if consistency.canonical_type(current.get("data_type")) == datatype and current.get("kind") != "unknown":
        if current.get("kind") == "continuous" and "units" in generated:
            current["unit"] = generated["units"]
        return current
    values = deepcopy(row.get("values") or {})
    values["output"] = {"type": datatype, "nullable": nullable}
    if "units" in generated:
        values["units"] = generated["units"]
    return values_page.current_value({"values": values})


def _adopt_calculation(state, key, item_id, payload, *, row, typed_value=None):
    """Prepare one row's controls only; the normal Save owns all persistence."""
    from experiments.portal import variable_clinical_rule_page as clinical
    from experiments.portal import variable_clinical_value_page as mapping
    entry = deepcopy(state[PREFIX + "row_entries"][(item_id, "science")])
    if entry.get("key") != key or entry.get("conflict"):
        raise ValueError("This variable draft changed. Review its current calculation and ask again.")
    value = _calculation_value(payload, row, typed_value)
    rule = payload.get("clinical_rule")
    template = next((name for name, (operator, family, _) in clinical.TEMPLATES.items()
                     if rule and operator == rule.get("operator") and family == rule.get("family")), None)
    if rule and not template:
        raise ValueError("Select a supported calculation in the existing editor first.")
    drafts = deepcopy(state.get(key + "clinical_drafts", {}))
    names = sorted((name for name in clinical.TEMPLATES if name), key=len, reverse=True)

    def owned(suffix):
        if suffix.startswith(("typed_", "clinical_values_")):
            return True
        if suffix in {"last_typed_value", "value_editor_owner", "clinical_selection", "assistant_value_seed"}:
            return True
        if not rule:
            return suffix.startswith("family_")
        if suffix in {"clinical_template", "clinical_cleared"}:
            return True
        if template == "ecog" and suffix.startswith("clinical_ecog_compact_"):
            return True
        if suffix.startswith("clinical_"):
            tail = suffix[len("clinical_"):]
            return next((name for name in names if tail.startswith(name)), None) == template
        return False

    for name in list(state):
        if str(name).startswith(key) and owned(str(name)[len(key):]):
            del state[name]
    entry["fields"] = {suffix: value for suffix, value in entry.get("fields", {}).items() if not owned(suffix)}
    entry.setdefault("recovered_updates", {}).update(deepcopy(payload))
    entry.setdefault("updates", {}).update(deepcopy(payload))
    entry["dirty"] = True
    if rule:
        drafts[template] = deepcopy(rule)
        state[key + "clinical_drafts"] = drafts
        state[key + "clinical_template"] = template
        state[key + "clinical_selection"] = (template, rule.get("result", ""))
        state[key + "value_editor_owner"] = "clinical" if mapping.manages(rule) else "values"
        if template == "ecog":
            # A complete proposed rule is reviewed in the ordinary detailed
            # editor, not replaced by the compact product-rule suggestion.
            state[key + "clinical_ecog_compact_details"] = True
    if value is not None:
        state[key + "last_typed_value"] = deepcopy(value)
        state[key + "assistant_value_seed"] = {"payload": deepcopy(payload), "value": deepcopy(value)}
        if rule and mapping.manages(rule):
            missing = value.get("missing_allowed")
            state[key + "clinical_values_missing"] = "allowed" if missing is True else "not_allowed" if missing is False else "unspecified"
    entry["fields"].update({str(name)[len(key):]: deepcopy(value) for name, value in state.items()
                            if str(name).startswith(key) and owned(str(name)[len(key):])})
    if rule:
        entry["fields"]["clinical_drafts"] = deepcopy(drafts)
    state[PREFIX + "row_entries"][(item_id, "science")] = entry


def _assistant_calculation(root, pack, actor_id, report, row, key, updates, typed, *, permitted, allowed_packs):
    from experiments.portal import form_assistance
    from experiments.portal import variable_clinical_rules as rules
    from experiments.portal import variable_review_values_page as values_page
    if not st.session_state.get(form_assistance.KEY + "enabled"):
        return
    choices = {name: deepcopy(updates[name]) for name in ("clinical_rule", "family") if updates.get(name)}
    if len(choices) != 1:
        return
    try:
        contract = rules.assistant_contract(choices)
    except ValueError as error:
        st.caption(str(error))
        return
    if not contract:
        return
    current_value = deepcopy((typed or {}).get("value") or values_page.current_value(row))
    if "missing_allowed" in (typed or {}):
        current_value["missing_allowed"] = typed["missing_allowed"]
    expected = _calculation_fingerprint(st.session_state, key)
    identity = (row.get("contract_choice"), row.get("contract_variable_id"), row.get("contract_record_key"))
    basis = _entry_basis(report)
    target = key + "assistant_calculation"

    def validate(value):
        if not permitted or pack not in (allowed_packs or []):
            raise ValueError("This profile cannot edit this variable.")
        if _calculation_fingerprint(st.session_state, key) != expected:
            raise ValueError("A variable field changed after this suggestion. Your edits were kept; let the editor update, then ask again.")
        fresh = workflow.describe(root, pack, actor_id, allowed_packs=allowed_packs)
        current_row = next((item for item in fresh.get("rows", []) if item["item_id"] == row["item_id"]), None)
        if (not fresh.get("ok") or _entry_basis(fresh) != basis or current_row is None
                or (current_row.get("contract_choice"), current_row.get("contract_variable_id"), current_row.get("contract_record_key")) != identity):
            raise ValueError("The specification or selected definition changed. Reload this variable before requesting a calculation.")
        rules.validate_assistant_update(value, current=choices)

    def adopt():
        value = st.session_state[target]
        validate(value)
        _adopt_calculation(st.session_state, key, row["item_id"], value, row=row,
                           typed_value=current_value)

    def difference(before, after):
        rows = rules.assistant_diff(before, after)
        prior = current_value
        projected = _calculation_value(after, row, prior) or {}
        types = {"string": "Text", "integer": "Whole number", "long": "Whole number (64-bit)",
                 "double": "Number", "float": "Number", "date": "Date", "boolean": "Yes / no"}
        rows.append({"Field": "Resulting output type", "Current": types.get(prior.get("data_type"), "Not decided"),
                     "Suggested": types.get(projected.get("data_type"), "Not decided")})
        old_codes, new_codes = prior.get("codes") or [], projected.get("codes") or []
        if old_codes == new_codes and new_codes:
            rows.append({"Field": "Output categories", "Current": f"{len(old_codes)} categories",
                         "Suggested": "Unchanged"})
        elif old_codes != new_codes:
            rows.extend(rules.assistant_diff({"Output categories": old_codes}, {"Output categories": new_codes}))
        if prior.get("unit") or projected.get("unit"):
            rows.append({"Field": "Resulting output units", "Current": prior.get("unit") or "Not specified",
                         "Suggested": projected.get("unit") or "Not specified — review units"})
        if prior.get("missing_allowed") != projected.get("missing_allowed"):
            labels = {True: "Allowed", False: "Not allowed", None: "Not decided"}
            rows.append({"Field": "Missing values", "Current": labels[prior.get("missing_allowed")],
                         "Suggested": labels[projected.get("missing_allowed")]})
        rule = after.get("clinical_rule") or {}
        from experiments.portal import variable_native_instruments as native
        required = "derived" if rule.get("operator") in native.DERIVED else "vendor"
        source = updates.get("source.kind", _get(row.get("values") or {}, "source.kind"))
        rows.append({"Field": "Source origin", "Current": SOURCE_KINDS.get(source, source) or "Not decided",
                     "Suggested": "Unchanged"})
        if source != required:
            rows.append({"Field": "Source origin needed (separate review)", "Current": "Not yet matched",
                         "Suggested": SOURCE_KINDS[required]})
        return rows

    form_assistance.structured("Complete calculation", key=target, value=choices, contract=contract,
        validate=validate, on_change=adopt, binding=[key, basis, identity, expected],
        disabled=not permitted, diff=difference)


def _remember_row_entries(report, row, phase, key, updates):
    proposed = {path: value for path, value in updates.items() if not path.startswith("_")}
    for path in workflow.LIST_FIELDS:
        if isinstance(proposed.get(path), str):
            proposed[path] = _lines(proposed[path])
    identifier = st.session_state.get(key + "identifier", _get(row.get("values") or {}, "variable_id", row["variable_id"]))
    if phase == "science" and identifier != _get(row.get("values") or {}, "variable_id", row["variable_id"]):
        proposed["variable_id"] = identifier
    changed = _changed_updates(row, proposed)
    entries = st.session_state.setdefault(PREFIX + "row_entries", {})
    previous = entries.get((row["item_id"], phase), {})
    recovered = previous.get("recovered_updates")
    fields = _entry_fields(key)
    baseline = deepcopy(previous.get("baseline_fields", fields))
    for name, value in fields.items():
        baseline.setdefault(name, deepcopy(value))
    initial_changes = previous.get("baseline_updates", changed)
    edited = {path: value for path, value in changed.items()
              if path not in initial_changes or value != initial_changes[path]}
    entries[(row["item_id"], phase)] = {
        "key": key, "row": deepcopy(row), "phase": phase, "basis": _entry_basis(report),
        "fields": fields, "baseline_fields": deepcopy(baseline), "baseline_updates": deepcopy(initial_changes),
        "updates": deepcopy(edited), "dirty": bool(edited) or bool(updates.get("_column_errors") and fields != baseline)
            or any(name.startswith("typed_") and value != baseline.get(name) for name, value in fields.items()),
        "recovered_updates": deepcopy(edited) if recovered else {},
    }


def _continue_row_entries(root, pack, actor_id, report, *, phase, saved_ids, allowed_packs, identifier_only=False):
    """Bind a local save's continuation to a fresh read; external changes stay conflicts."""
    entries = st.session_state.get(PREFIX + "row_entries", {})
    pending_identifiers = set()
    for identity in list(entries):
        if identity[0] in saved_ids and identity[1] == phase and not identifier_only:
            entry = entries[identity]
            if phase == "science" and "variable_id" in entry["updates"]:
                entry["fields"] = {"identifier": entry["updates"]["variable_id"]}
                entry["updates"] = {"variable_id": entry["updates"]["variable_id"]}
                pending_identifiers.add(identity)
            elif identity[0] == saved_ids[0]:
                _reset_entry_widgets(entry, pack, actor_id)
                del entries[identity]
            # A batch changes only the shared source fields. Any unfinished
            # sibling edits need a comparison before that row can be rebased.
    fresh = workflow.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not fresh.get("ok") or fresh.get("input_digest") != report.get("input_digest"):
        return
    if fresh.get("state_digest") != report.get("state_digest"):
        before_history, after_history = report.get("history", []), fresh.get("history", [])
        before_count = report.get("history_count", len(before_history))
        after_count = fresh.get("history_count", len(after_history))
        if after_count != before_count + 1 or not after_history or (len(after_history) > 1 and after_history[:-1] != before_history[-(len(after_history) - 1):]):
            return
        event = after_history[-1]
        event_items = event.get("item_ids") or [event.get("item_id")]
        if (event.get("action") not in {"save_row", "save_source_rows", "choose_contract_record"}
                or event.get("actor_id") != actor_id.strip() or event.get("phase") != phase
                or set(event_items) != set(saved_ids)):
            return
    lookup = {row["item_id"]: row for row in fresh.get("rows", [])}
    allowed = []
    for identity, entry in entries.items():
        current = lookup.get(identity[0])
        if not current or entry["basis"] != _entry_basis(report):
            continue
        if identity[0] not in saved_ids and entry["row"] == current:
            allowed.append(identity)
        elif identity in pending_identifiers and _get(entry["row"].get("values") or {}, "variable_id") == _get(current.get("values") or {}, "variable_id"):
            allowed.append(identity)
        elif identifier_only and identity == (saved_ids[0], "science"):
            # Only the identifier was submitted by this control. Other entries
            # remain drafts; no scientific approval is carried forward.
            prior_values = deepcopy(entry["row"].get("values") or {})
            current_values = deepcopy(current.get("values") or {})
            prior_values.pop("variable_id", None)
            current_values.pop("variable_id", None)
            if prior_values == current_values:
                entry["fields"].pop("identifier", None)
                entry["updates"].pop("variable_id", None)
                entry["dirty"] = bool(entry["updates"])
                allowed.append(identity)
    st.session_state[PREFIX + "entry_continuation"] = {
        "before": _entry_basis(report), "after": _entry_basis(fresh), "allowed": allowed,
    }


def _restore_row_entries(entry, row, report, pack, actor_id, *, reviewed=False):
    if reviewed:
        _reset_entry_widgets(entry, pack, actor_id)
    key = _entry_key(pack, actor_id, row["item_id"], entry["phase"], report)
    if reviewed:
        # Bring back only fields the person edited. Restoring every former
        # widget would overwrite another reviewer's unchanged-by-us answers.
        baseline = entry.get("baseline_fields", {})
        entry["fields"] = {name: value for name, value in entry["fields"].items()
                           if name not in baseline or value != baseline[name]}
    for suffix, value in entry["fields"].items():
        st.session_state[key + suffix] = deepcopy(value)
    entry.update(key=key, row=deepcopy(row), basis=_entry_basis(report), conflict=False)
    if reviewed:
        entry["recovered_updates"] = deepcopy(entry["updates"])
    if entry["phase"] == "output" and entry["dirty"]:
        st.session_state.setdefault(PREFIX + "output_dirty_rows", {})[row["item_id"]] = row["variable_id"]


def _reconcile_row_entries(report, pack, actor_id):
    from experiments.portal.variable_review_draft import rebase_kind
    entries = st.session_state.get(PREFIX + "row_entries", {})
    continuation = st.session_state.pop(PREFIX + "entry_continuation", {})
    lookup = {row["item_id"]: row for row in report.get("rows", [])}
    for identity, entry in list(entries.items()):
        authorized = (identity in continuation.get("allowed", []) and identity[0] in lookup
                and entry["basis"] == continuation.get("before")
                and _entry_basis(report) == continuation.get("after"))
        action = rebase_kind(entry, lookup.get(identity[0]), _entry_basis(report), authorized_continuation=authorized)
        if action == "rebase":
            _restore_row_entries(entry, lookup[identity[0]], report, pack, actor_id)
        elif action == "conflict":
            entry["conflict"] = True
        elif action == "reset":
            _reset_entry_widgets(entry, pack, actor_id)
            del entries[identity]


def _pending_row_entries(report, pack, actor_id):
    entries = st.session_state.get(PREFIX + "row_entries", {})
    pending = {identity: entry for identity, entry in entries.items() if entry.get("conflict") and entry["dirty"]}
    if not pending:
        return False
    st.warning("Saved information changed while you had unfinished edits. Review or discard those edits before continuing; your entries are still available.")
    if st.session_state.get(PREFIX + "entry_conflict") not in pending:
        st.session_state[PREFIX + "entry_conflict"] = next(iter(pending))
    selected = st.selectbox("Unfinished draft to resolve", list(pending), key=PREFIX + "entry_conflict",
        format_func=lambda identity: pending[identity]["row"]["variable_id"] + " · " + LABELS[identity[1]])
    entry = pending[selected]
    current = next((row for row in report["rows"] if row["item_id"] == selected[0]), None)
    if current:
        st.text("Current specification: " + _text(current.get("definition")))
        st.text("Current specification values: " + _spec_values(current.get("spec_values")))
        comparison = [{"Field": path.replace(".", " / ").replace("_", " "),
            "Earlier saved answer": _text(_get(entry["row"].get("values") or {}, path)),
            "Current saved answer": _text(_get(current.get("values") or {}, path)),
            "Your unfinished answer": _text(value)} for path, value in entry["updates"].items()]
        if comparison:
            st.dataframe(comparison, hide_index=True, width="stretch")
        st.caption("Keeping your entries reloads the current source for another review. It does not save, confirm or approve them.")
        if st.button("Reload current row and keep my entries", key=PREFIX + "entry_reload"):
            _restore_row_entries(entry, current, report, pack, actor_id, reviewed=True)
            st.session_state[PREFIX + "next_phase"] = entry["phase"]
            st.session_state[PREFIX + "incoming_item"] = {"phase": entry["phase"], "item_id": selected[0]}
            st.rerun()
    else:
        st.info("This specification row is no longer present. Its unfinished entries have not been applied to another variable.")
    if st.button("Discard this unfinished draft", key=PREFIX + "entry_discard"):
        _reset_entry_widgets(entry, pack, actor_id)
        del entries[selected]
        st.rerun()
    return True


def _contract_mapping(root, pack, actor_id, report, row, phase, *, permitted, local_demo, allowed_packs):
    related = row.get("related_contracts") or []
    if not related and not row.get("contract_choice_error"):
        return False
    with st.expander("Existing outputs linked to this specification row", expanded=bool(row.get("contract_choice_error"))):
        st.caption("One requirement can feed several outputs, such as a treatment line, its date and its diagnosis. "
                   "Choose the definition this row will review. Other outputs retain their own recorded review status.")
        st.dataframe([{"Output": item["variable_id"], "Definition / logic": item["derivation"],
                       "Output details": item["output"], "Recorded status": item["status"],
                       "This row": "Selected" if item["variable_id"] == row.get("contract_choice") else "Not reviewed here"}
                      for item in related], hide_index=True, width="stretch")
        if row.get("contract_choice_error"):
            st.info(row["contract_choice_error"])
        names = list(dict.fromkeys(item["variable_id"] for item in related))
        current = row.get("contract_choice", "")
        choices = ["", *names]
        key = PREFIX + "contract_mapping_" + _digest([pack, actor_id, row["item_id"], report["state_digest"]])
        dirty = any(identity[0] == row["item_id"] and entry.get("dirty")
                    for identity, entry in st.session_state.get(PREFIX + "row_entries", {}).items())
        fixed = row.get("contract_choice_has_edits") or dirty
        selected = st.selectbox("Existing definition to review", choices,
            index=choices.index(current) if current in choices else 0,
            format_func=lambda name: name or "Choose later", key=key,
            disabled=not permitted or phase != "science" or bool(fixed))
        if fixed:
            st.caption("Keep this mapping while this row has edits. Those edits belong to the selected output and cannot be reassigned to another output.")
        if row.get("contract_choice_error") and current and row.get("contract_choice_has_edits"):
            st.caption("Review the current definition above, then use it again to compare your retained saved edits with its current evidence. Save or clear any unfinished form edits first.")
        mapping_reason = ("An author with write access must change this definition mapping." if not permitted
            else "Open Scientific review to choose the definition linked to this requirement." if phase != "science"
            else "Save or discard this row's unfinished edits before changing its definition mapping." if dirty
            else "Keep the existing mapping for this row's saved edits." if fixed and selected != current
            else "This definition is already selected. Choose a different definition only if the requirement needs it."
                 if selected == current and not row.get("contract_choice_error") else "")
        if mapping_reason:
            st.caption(mapping_reason)
        if st.button("Use selected definition", key=key + "_save", disabled=bool(mapping_reason),
                     help=mapping_reason or None):
            result = workflow.choose_contract_record(root, pack, actor_id, row["item_id"], selected,
                expected_input_digest=report["input_digest"], expected_state_digest=report["state_digest"],
                allowed_packs=allowed_packs, local_demo=local_demo, can_write=permitted)
            if not result.get("ok"):
                _errors(result)
                return True
            _continue_row_entries(root, pack, actor_id, report, phase="science", saved_ids=[row["item_id"]], allowed_packs=allowed_packs)
            st.session_state[PREFIX + "notice"] = "Definition mapping saved. Related outputs and their approvals are unchanged."
            st.rerun()
    return bool(row.get("contract_choice_error"))


@st.fragment
def _editor(root, pack, actor_id, report, row, phase, *, permitted, local_demo, allowed_packs, attention_view=False, navigation_order=None):
    st.subheader(f"Edit {row['variable_id']}", anchor="rwd-variable-editor")
    if focus_markup := theme.take_focus_markup(st.session_state, "rwd-variable-editor"):
        st.html(focus_markup)
    if _contract_mapping(root, pack, actor_id, report, row, phase, permitted=permitted, local_demo=local_demo, allowed_packs=allowed_packs):
        return
    key = _entry_key(pack, actor_id, row["item_id"], phase, report)
    values = deepcopy(row.get("values") or {})
    recovered = st.session_state.get(PREFIX + "row_entries", {}).get((row["item_id"], phase), {}).get("recovered_updates", {})
    for path, value in recovered.items():
        if path not in workflow.META_FIELDS:
            workflow._put(values, path, deepcopy(value))
    st.caption(ui_text.display_line_breaks(_text(row.get("definition"))).replace("\n", "  \n"))
    if phase != "science" and _spec_values(row.get("spec_values")):
        st.text("Current specification values / codes: " + ui_text.display_line_breaks(_spec_values(row["spec_values"])))
    if phase != "science":
        for issue in (row.get("phase_issues") or {}).get(phase, row.get("issues") or []):
            st.caption(_issue_text(issue))
    selected_master = row.get("master_name") or _get(values, "master_name") or ""
    candidate = None
    typed = None
    clinical_updates = {}
    origin = None
    source_link = None
    change_reason = ""
    custom_key = PREFIX + "custom_" + _digest([str(root), pack, actor_id, row["item_id"]])
    if phase == "science":
        from experiments.portal import variable_origin_page
        from experiments.portal import variable_clinical_rule_page
        origin_row = deepcopy(row)
        origin_row["values"] = deepcopy(values)
        ecog_choice = None
        incoming_template = st.session_state.get(key + "clinical_template")
        if incoming_template == "ecog" or incoming_template is None and (row.get("clinical_rule") or {}).get("operator") == "baseline_ecog":
            from experiments.portal import variable_review_options
            metadata = variable_review_options.describe(root, pack, actor_id, allowed_packs=allowed_packs)
            ecog_choice = metadata.get("ecog_choice") or {"ready": False, "issues": metadata.get("errors", [])}
        if variable_clinical_rule_page.ecog_source_compatible(values.get("source"), ecog_choice):
            # The compact editor displays this exact mapping. It is staged only
            # after the user explicitly reuses a product rule, never from a name.
            origin = {"updates": {}, "source_link": None, "issues": [], "managed_kind": True}
            pending_ecog_source = st.session_state.get(key + "clinical_ecog_compact_source")
            if pending_ecog_source:
                if pending_ecog_source != ecog_choice.get("source"):
                    origin["issues"].append("The configured ECOG mapping changed. Reload the current row before saving.")
                else:
                    origin["updates"]["source.kind"] = pending_ecog_source["kind"]
                    origin["source_link"] = {"source." + name: deepcopy(pending_ecog_source[name])
                        for name in ("logical_table", "physical_stem", "columns")}
        else:
            origin = variable_origin_page.render(root, pack, actor_id, origin_row, key=key + "origin_",
                permitted=permitted, allowed_packs=allowed_packs)
        for path, value in origin.get("updates", {}).items():
            workflow._put(values, path, value)
            workflow._put(origin_row["values"], path, value)
        source_link = origin.get("source_link")
        for path, value in ((source_link or {}) if ecog_choice else {}).items():
            workflow._put(values, path, deepcopy(value))
            workflow._put(origin_row["values"], path, deepcopy(value))
        link_fields = ("source.logical_table", "source.physical_stem", "source.columns")
        if source_link is None and any(path in recovered for path in link_fields):
            recovered_link = {path: deepcopy(_get(values, path)) for path in link_fields}
            if any(value != _get(row["values"], path) for path, value in recovered_link.items()):
                source_link = recovered_link
        if origin.get("updates", {}).get("source.kind", _get(row["values"], "source.kind")) != _get(row["values"], "source.kind") and _get(values, "source.kind") != "vendor":
            source_link = {"source.logical_table": "", "source.physical_stem": "", "source.columns": {}}
        from experiments.portal import variable_review_values_page
        # Reserve the value/evidence position, then use the selected calculation
        # to decide whether its mapping owns the output categories.
        value_panel, calculation_panel = st.container(), st.container()
        from experiments.portal import variable_clinical_rule_page
        from experiments.portal import variable_clinical_value_page
        clinical_row = deepcopy(origin_row)
        if "clinical_rule" in recovered:
            clinical_row["clinical_rule"] = deepcopy(recovered["clinical_rule"])
        if source_link:
            for path, value in source_link.items():
                workflow._put(clinical_row["values"], path, deepcopy(value))
        incoming_template = st.session_state.get(key + "clinical_template", "")
        incoming_result = st.session_state.get(key + "clinical_" + incoming_template + "result", "")
        if incoming_template == "ecog" and not st.session_state.get(key + "clinical_ecog_compact_details"):
            incoming_result = st.session_state.get(key + "clinical_ecog_compact_result", incoming_result)
        incoming_selection = (incoming_template, incoming_result)
        previous_selection = st.session_state.get(key + "clinical_selection")
        incoming_operator = variable_clinical_rule_page.TEMPLATES.get(incoming_template, ("", "", ""))[0]
        incoming_shared = variable_clinical_value_page.manages({"operator": incoming_operator, "result": incoming_result})
        template_mapping = variable_clinical_value_page.manages({"operator": incoming_operator, "result": "label"})
        from experiments.portal.variable_review_draft import editor_transition, compose_science
        transition = editor_transition(previous_owner=st.session_state.get(key + "value_editor_owner"),
            previous_selection=previous_selection, incoming_selection=incoming_selection,
            mapping_template=template_mapping, shared_mapping=incoming_shared)
        if transition.consume_previous:
            # A grid edit and a template/result selection can arrive together.
            # Consume the old editor's pending widget edits before the new
            # mapping is seeded. One guarded rerun keeps one visible editor and
            # uses Streamlit's own table-diff handling rather than a second parser.
            with value_panel:
                pending_typed = variable_review_values_page.render(origin_row, key=key + "typed_", permitted=permitted,
                    root=root, pack=pack, actor_id=actor_id, report=report, allowed_packs=allowed_packs, local_demo=local_demo,
                    requested_type=origin.get("suggested_type") if origin.get("type_requested") else None,
                    on_discard_suggestion=lambda: _forget_row_entry_field(row["item_id"], phase, key + "typed_model_suggestion"))
            if pending_typed and pending_typed.get("value"):
                st.session_state[key + "last_typed_value"] = deepcopy(pending_typed["value"])
                if "missing_allowed" in pending_typed["value"]:
                    st.session_state[key + "last_missingness"] = {"value": pending_typed["value"]["missing_allowed"]}
            st.session_state[key + "clinical_selection"] = incoming_selection
            st.rerun()
        seed_value = st.session_state.get(key + "last_typed_value") or variable_review_values_page.current_value(origin_row)
        with calculation_panel:
            clinical_updates = variable_clinical_rule_page.render(clinical_row, key=key + "clinical_",
                permitted=permitted, typed_value=seed_value, shared_values=True, ecog_choice=ecog_choice)
        preset_source = clinical_updates.pop("_ecog_source", None)
        if preset_source:
            origin["updates"]["source.kind"] = preset_source["kind"]
            source_link = {"source." + name: deepcopy(preset_source[name])
                for name in ("logical_table", "physical_stem", "columns")}
            for path, value in {"source.kind": preset_source["kind"], **source_link}.items():
                workflow._put(values, path, deepcopy(value))
                workflow._put(origin_row["values"], path, deepcopy(value))
        selected_rule = clinical_updates.get("clinical_rule") or {}
        st.session_state[key + "clinical_selection"] = (
            st.session_state.get(key + "clinical_template", ""), selected_rule.get("result", ""))
        shared_mapping = variable_clinical_value_page.manages(selected_rule)
        previous_owner = st.session_state.get(key + "value_editor_owner")
        transition = editor_transition(previous_owner=previous_owner, previous_selection=previous_selection,
            incoming_selection=(st.session_state.get(key + "clinical_template", ""), selected_rule.get("result", "")),
            mapping_template=template_mapping, shared_mapping=shared_mapping)
        owner = transition.owner
        pending_missingness = st.session_state.get(key + "last_missingness")
        transfer_missingness = ({"requested_missingness": pending_missingness["value"]}
            if transition.transfer_missingness and pending_missingness is not None else {})
        with value_panel:
            if shared_mapping:
                typed = variable_clinical_value_page.render(origin_row, selected_rule,
                    key=key + "clinical_values_", permitted=permitted, seed_value=seed_value, **transfer_missingness)
            elif selected_rule.get("operator") == "baseline_ecog" and (ecog_choice or {}).get("ready") and not st.session_state.get(key + "clinical_ecog_compact_details"):
                variable_review_values_page.render_source_details(origin_row)
                st.caption("Choose the ECOG result below; its type and allowed values come from the displayed rule.")
                typed = {"active": False, "fields": {}, "confirmed": False, "issues": []}
            else:
                prepared_value = st.session_state.get(key + "assistant_value_seed") or {}
                prepared_payload = prepared_value.get("payload") or {}
                prepared_rule = prepared_payload.get("clinical_rule")
                prepared_family = prepared_payload.get("family")
                current_family = recovered.get("family", row.get("family") or {})
                prepared_current = (prepared_rule == selected_rule if prepared_rule else
                                    bool(prepared_family) and prepared_family == current_family)
                typed = variable_review_values_page.render(origin_row, key=key + "typed_", permitted=permitted,
                    root=root, pack=pack, actor_id=actor_id, report=report, allowed_packs=allowed_packs, local_demo=local_demo,
                    requested_type=origin.get("suggested_type") if origin.get("type_requested") else None,
                    requested_value=prepared_value.get("value") if prepared_current else None,
                    on_discard_suggestion=lambda: _forget_row_entry_field(row["item_id"], phase, key + "typed_model_suggestion"), **transfer_missingness)
        st.session_state[key + "value_editor_owner"] = owner
        if typed and "missing_allowed" in typed:
            st.session_state[key + "last_missingness"] = {"value": typed["missing_allowed"]}
        elif typed and "missing_allowed" in (typed.get("value") or {}):
            st.session_state[key + "last_missingness"] = {"value": typed["value"]["missing_allowed"]}
        clinical_ui_issues = clinical_updates.pop("_ui_issues", [])
        if typed and typed.get("value"):
            st.session_state[key + "last_typed_value"] = deepcopy(typed["value"])
        if selected_rule and not shared_mapping and typed and typed.get("active"):
            from experiments.portal import variable_clinical_rules
            try:
                expected_result = next((result for result in variable_clinical_rules.emitted_columns(selected_rule)
                    if result["result"] == selected_rule.get("result")), None)
                actual_type = (typed.get("value") or {}).get("data_type")
                if expected_result and actual_type and consistency.canonical_type(actual_type) != expected_result["type"]:
                    clinical_ui_issues.append("This calculation returns " + expected_result["type"] +
                        ". Choose that type of value above, or change the calculation's result before saving.")
            except ValueError:
                pass  # The calculation editor reports its structural findings.
        if clinical_updates.get("clinical_rule") and typed and typed.get("value"):
            from experiments.portal import variable_clinical_value_consistency
            clinical_ui_issues.extend(variable_clinical_value_consistency.issues(clinical_updates["clinical_rule"], typed["value"]))
        if not typed:
            variable_review_values_page.render_source_details(row)
        _identifier_controls(root, pack, actor_id, report, row, key, permitted=permitted,
            local_demo=local_demo, allowed_packs=allowed_packs, attention_view=attention_view)
        from experiments.portal import specification_row_context_page
        if specification_row_context_page.render(root, pack, actor_id, row,
                local_demo=local_demo, can_write=permitted, allowed_packs=allowed_packs):
            st.session_state[PREFIX + "notice"] = "Row kept as document metadata. Use the Document metadata section to inspect or restore it."
            st.session_state.setdefault("flow_result", {}).pop(pack, None)
            st.rerun()
        managed = set(typed.get("fields") or {}) if typed and typed.get("active") else set()
        if shared_mapping:
            managed.update({"output.type", "output.codes", "output.nullable"})
        managed.update(path for path in clinical_updates if path not in workflow.META_FIELDS)
        if origin.get("managed_kind", bool(origin.get("updates", {}).get("source.kind"))):
            managed.add("source.kind")
        if _get(values, "source.kind") not in {"constant", "parameter"}:
            managed.discard("source.value")
        detail_updates = {**((typed or {}).get("fields") or {}), **clinical_updates}
        definition_needed = _definition_details_needed(row, values, report.get("master_candidates") or [], detail_updates)
        with st.expander("Definition and master match", key=key + "master_details", on_change="rerun",
                         expanded=definition_needed):
            from experiments.portal import variable_review_family as families
            from experiments.portal import variable_review_family_page as family_page
            candidates = report.get("master_candidates") or []
            by_name = {str(candidate.get("variable_id") or candidate.get("name")): candidate for candidate in candidates}
            options = ["", *by_name]
            if selected_master and selected_master not in options:
                options.append(selected_master)
            family_request = PREFIX + "family_request_" + _digest([pack, actor_id, row["item_id"]])
            if st.session_state.pop(family_request, False) and "LINE_OF_THERAPY" in by_name:
                st.session_state[key + "master"] = "LINE_OF_THERAPY"
                st.session_state[custom_key] = False
            selected_master = st.selectbox("Master variable definition", options, index=options.index(selected_master),
                key=key + "master", disabled=not permitted,
                format_func=lambda name: f"{name} · " + ("Draft library definition" if "CUSTOM_LOGIC.yaml" in str(by_name.get(name, {}).get("source_path", "")) else "Library template") if name else "Search the master variable list")
            candidate = by_name.get(selected_master)
            if selected_master and candidate is None:
                st.warning("The chosen master is no longer in the library. Select an available master or create a definition below.")
            family_mode = bool(selected_master == "LINE_OF_THERAPY" or row.get("family") and selected_master == row.get("master_name"))
            if not family_mode and families.matches(row, candidate) and "LINE_OF_THERAPY" in by_name:
                if st.button("Set up treatment-line variable", key=key + "family", disabled=not permitted):
                    st.session_state[family_request] = True
                    st.rerun()
            if st.button("No suitable match — create a definition", key=key + "custom", disabled=not permitted):
                st.session_state[custom_key] = True
            custom = st.session_state.get(custom_key, False)
            if custom:
                if st.button("Return to master search", key=key + "search"):
                    st.session_state[custom_key] = False
                    st.rerun()
                st.caption("Start from this product's Excel values and the answers already entered. Keep reusable logic and product-specific values separate.")
                selected_master, candidate = "", None
                comparison = workflow.comparison_from_report(report, row["item_id"], "")
                if comparison.get("ok"):
                    for field in comparison.get("fields") or []:
                        current = _get(values, field["path"])
                        if field.get("editable") and field.get("has_excel") and current in (None, "", "TODO", "undecided"):
                            parts, target = field["path"].split("."), values
                            for part in parts[:-1]:
                                if not isinstance(target.get(part), dict):
                                    target[part] = {}
                                target = target[part]
                            target[parts[-1]] = deepcopy(field["excel_value"])
                if not _blank_placeholder(_get(values, "derivation")).strip():
                    values["derivation"] = _text(row.get("definition"))
                updates = _science_fields(row, values, key, permitted, managed_fields=managed)
                updates["master_name"] = selected_master
                if row.get("family"):
                    updates["family"] = {}
            elif family_mode:
                family_row = deepcopy(row)
                if "family" in recovered:
                    family_row["family"] = deepcopy(recovered["family"])
                updates = family_page.render(family_row, values, key=key + "family_", permitted=permitted)
                adopted = (st.session_state.get(key + "assistant_value_seed") or {}).get("payload") or {}
                if adopted.get("family") == updates.get("family"):
                    # Adopting calculation parameters is not a source-origin
                    # decision. Keep that separate, existing control explicit.
                    updates.pop("source.kind", None)
                updates["master_name"] = selected_master
                if "derivation" in updates:
                    updates["logic_reviewed"] = True
            elif candidate:
                comparison = workflow.comparison_from_report(report, row["item_id"], selected_master)
                if not comparison.get("ok"):
                    _errors(comparison)
                    return
                if any(comparison.get(name) != report.get(name) for name in ("input_digest", "state_digest")):
                    st.warning("The table changed while this comparison opened. Refresh it before choosing values.")
                    return
                updates = _master_fields(row, candidate, comparison, values, key, permitted, managed_fields=managed)
                updates["master_name"] = selected_master
                if row.get("family"):
                    updates["family"] = {}
            else:
                st.info("Search and select a master definition to compare its fields with this product's Excel specification.")
                if not typed or not typed.get("active"):
                    st.caption("You can save the source choice now and finish the definition later.")
                updates = {}
        updates = compose_science(answers=updates, origin=origin.get("updates"), typed=typed,
            clinical=clinical_updates, shared_mapping=shared_mapping, source_kind=_get(values, "source.kind"))
        missing = _missing_scientific_answers(values, updates)
        trial = deepcopy(row)
        for path, value in updates.items():
            if path in workflow.META_FIELDS:
                trial[path] = value
            else:
                workflow._put(trial["values"], path, value)
        issues = consistency.issues(trial) + families.issues(trial) + requirements.issues(trial, candidate)
        if trial.get("family"):
            from experiments.portal import variable_review_family_binding
            issues.extend(variable_review_family_binding.coherence_issues(trial))
            if trial.get("clinical_rule"):
                issues.append("Choose one calculation template for this variable: treatment line or clinical measurement.")
        issues = list(dict.fromkeys(issues))
        clinical_issues = []
        if trial.get("clinical_rule"):
            from experiments.portal import variable_clinical_rules
            # The calculation editor already displays its unanswered choices.
            # Keep them in the save state without repeating the whole list.
            clinical_issues = variable_clinical_rules.issues(trial)
        for issue in issues:
            st.warning(issue)
        if missing:
            st.info("To resolve this variable, complete: " + ", ".join(missing) + ".")
        values_blocked = bool(typed and typed.get("active") and (typed.get("issues") or not typed.get("confirmed"))) or bool(origin.get("issues")) or bool(clinical_ui_issues)
        for issue in clinical_ui_issues:
            st.warning(issue)
        logic_issues = _logic_choice(row, values, candidate, updates, key, permitted,
            input_digest=report.get("input_digest", "")) if custom or candidate and not family_mode else []
        issues.extend(logic_issues)
        values_blocked = values_blocked or bool(logic_issues)
        save_label = _science_save_label(missing=missing, issues=issues,
            clinical_issues=clinical_issues, typed=typed, custom=custom)
        if logic_issues:
            st.caption("Review the rule shown above before saving.")
        elif values_blocked:
            st.caption("Fix the highlighted values before saving.")
        elif clinical_issues:
            st.caption("Save keeps these unfinished calculation choices so you can return to them.")
        elif missing or issues:
            st.caption("Save keeps your answers as an unfinished draft. Complete the answers listed above to remove this variable from the attention list.")
        elif typed and typed.get("active"):
            st.caption("Save confirms these values. Scientific approval follows after the whole table is ready.")
        save, save_next = _save_actions(save_label, key, disabled=not permitted or values_blocked,
            reason="Your current profile can read this variable. An author with write access must save changes." if not permitted
            else "Review the rule shown above before saving." if logic_issues else "Complete and confirm the highlighted value choices before saving.")
        from experiments.portal import variable_review_lineage_page
        change_reason = variable_review_lineage_page.render(root, pack, actor_id, report, row,
            key=key + "lineage_", permitted=permitted, local_demo=local_demo, allowed_packs=allowed_packs)
    else:
        from experiments.portal import variable_review_lineage_page
        change_reason = variable_review_lineage_page.render(root, pack, actor_id, report, row,
            key=key + "lineage_", permitted=permitted, local_demo=local_demo, allowed_packs=allowed_packs)
        from experiments.portal import variable_review_options
        options = variable_review_options.describe(root, pack, actor_id, allowed_packs=allowed_packs)
        options["input_variables"] = sorted(set(options.get("input_variables", [])) | set(report.get("source_input_variables", [])), key=str.casefold)
        if not options.get("ok"):
            with st.expander("Dropdown metadata details"):
                for error in options.get("errors") or []:
                    st.caption(str(error))
            options = {}
        updates = _source_fields(values, key, permitted, options, row=row) if phase == "source" else _output_fields(values, key, permitted, options)
        trial = deepcopy(row)
        for path, value in updates.items():
            if not path.startswith("_"):
                workflow._put(trial["values"], path, value)
        if phase == "source":
            from experiments.portal import variable_review_source_validation
            source_trial = deepcopy(trial)
            for path in workflow.LIST_FIELDS:
                value = workflow._get(source_trial["values"], path)
                if isinstance(value, str):
                    workflow._put(source_trial["values"], path, _lines(value))
            preview_issues = variable_review_source_validation.issues(source_trial, options)
        else:
            proposed_rows = [trial if item["item_id"] == row["item_id"] else item for item in report["rows"]]
            preview_issues = consistency.report_issues(proposed_rows).get(row["item_id"], [])
        for issue in preview_issues:
            st.warning(issue)
        if phase == "source":
            _shared_source(root, pack, actor_id, report, row, updates, key=key,
                           permitted=permitted, local_demo=local_demo, allowed_packs=allowed_packs)
        save, save_next = _save_actions("Save unfinished draft" if preview_issues else "Save changes", key, disabled=not permitted,
            reason="Your current profile can read this variable. An author with write access must save changes.")
    _remember_row_entries(report, row, phase, key, {**updates, **(source_link or {})})
    # This editor is a Streamlit fragment. Its widget events do not reach the
    # app footer, so checkpoint the unfinished row here as well as on navigation.
    if st.session_state.get("_browser_continuation_owner"):
        from experiments.portal import session_drafts
        try:
            session_drafts.browser_checkpoint(root, actor_id, st.session_state, allowed_packs=allowed_packs)
            st.session_state.pop("_browser_continuation_error", None)
        except (ValueError, OSError, TypeError) as error:
            st.session_state["_browser_continuation_error"] = str(error)
            st.warning("Unfinished edits are still on this page. " + str(error))
    from experiments.portal import page_assistant_context
    page_assistant_context.publish_variable(st.session_state, root=root, pack=pack, actor_id=actor_id,
        allowed_packs=allowed_packs, report=report, row=row, phase=phase,
        updates={**updates, **(source_link or {})}, typed=typed,
        issues=([*issues, *clinical_issues, *clinical_ui_issues, *((typed or {}).get("issues") or []),
                 *((origin or {}).get("issues") or [])] if phase == "science" else preview_issues))
    if phase == "output":
        dirty_rows = st.session_state.setdefault(PREFIX + "output_dirty_rows", {})
        if st.session_state[PREFIX + "row_entries"][(row["item_id"], phase)]["dirty"]:
            dirty_rows[row["item_id"]] = row["variable_id"]
        else:
            dirty_rows.pop(row["item_id"], None)
        st.session_state[PREFIX + "output_editor_dirty"] = bool(dirty_rows)
    if save:
        try:
            if phase == "science" and any(value is None for value in updates.values()):
                st.error("Choose the master options shown above before using this definition.")
                return
            if phase == "source":
                column_errors = updates.pop("_column_errors", [])
                if column_errors:
                    raise ValueError(" ".join(column_errors))
                for path in ("source.parameters", "source.spec_identifiers", "depends_on", "implementation_refs"):
                    if isinstance(updates[path], str):
                        updates[path] = _lines(updates[path])
            updates = _changed_updates(row, updates)
            typed_save = bool(typed and typed.get("active") and typed.get("confirmed"))
            if phase == "science" and row.get("master_name") and not row.get("master_link") and not updates and not typed_save:
                updates.setdefault("master_name", row["master_name"])
                updates.setdefault("derivation", _get(row["values"], "derivation"))
            if not updates and not typed_save and (source_link is None or all(value == _get(row["values"], path) for path, value in source_link.items())):
                if save_next:
                    st.session_state[PREFIX + "saved_selection"] = {"phase": phase, "item_id": row["item_id"],
                        "attention": attention_view, "advance": True,
                        "order": navigation_order or [item["item_id"] for item in report["rows"]]}
                    st.rerun()
                st.info("No changes to save. The current values are already on the dashboard.")
                return
            changed_link = source_link is not None and any(value != _get(row["values"], path) for path, value in source_link.items())
            result = workflow.save_row(root, pack, actor_id, row["item_id"], phase, updates,
                expected_input_digest=report["input_digest"], expected_state_digest=report["state_digest"],
                allowed_packs=allowed_packs, local_demo=local_demo, can_write=permitted,
                change_reason=change_reason,
                **({"source_link": source_link} if changed_link else {}),
                **({"typed_value": typed["value"], "typed_value_confirmed": True,
                    "typed_model_proposal": typed.get("model_proposal")} if typed_save else {}))
        except (ValueError, OSError) as error:
            _errors({"errors": [str(error)]}, focus=True)
            return
        if not result.get("ok"):
            _errors(result, focus=True)
            return
        _continue_row_entries(root, pack, actor_id, report, phase=phase,
            saved_ids=[row["item_id"]], allowed_packs=allowed_packs)
        st.session_state[PREFIX + "saved_selection"] = {"phase": phase, "item_id": row["item_id"], "attention": attention_view,
            "advance": save_next, "order": navigation_order or [item["item_id"] for item in report["rows"]]}
        st.session_state.setdefault("flow_result", {}).pop(pack, None)
        st.rerun()
    if phase == "science":
        with st.expander("Reuse this definition in another product"):
            _save_to_library(root, pack, actor_id, row, updates, local_demo=local_demo,
                             permitted=permitted, allowed_packs=allowed_packs)
        _assistant_calculation(root, pack, actor_id, report, row, key, updates, typed,
                               permitted=permitted, allowed_packs=allowed_packs)


def _transfer(root, pack, actor_id, report, *, local_demo, can_write, allowed_packs):
    if not all(report["phases"][phase].get("confirmed") for phase in PHASES):
        return
    st.write("**Continue with the reviewed definitions**")
    st.caption("Copy this reviewed table into your definition drafts for the existing validation and contract workflow.")
    key = PREFIX + "transfer_" + _digest([actor_id, report["input_digest"], report["state_digest"]])
    permitted = bool(local_demo and can_write)
    confirmed = st.checkbox("Copy these reviewed variables into my definition drafts.", key=key, disabled=not permitted)
    if st.button("Prepare definition drafts", key=key + "_save", disabled=not permitted or not confirmed):
        try:
            result = workflow.transfer_to_drafts(root, pack, actor_id,
                expected_input_digest=report["input_digest"], expected_state_digest=report["state_digest"],
                confirmed=confirmed, allowed_packs=allowed_packs, local_demo=local_demo, can_write=permitted)
        except (ValueError, OSError) as error:
            st.error(str(error))
            return
        if result.get("ok"):
            transferred = result.get("transferred") or []
            st.session_state[PREFIX + "notice"] = "The reviewed variables are ready in your definition drafts."
            return {"route": "scientific_draft", "params": {"item_id": transferred[0]} if transferred else {}, "changed": True}
        _errors(result)
        if result.get("transferred"):
            st.warning("Some definition drafts were prepared before the operation stopped: " + ", ".join(result["transferred"]))
        st.session_state[key + "_conflicts"] = result.get("conflicts") or []
    conflicts = st.session_state.get(key + "_conflicts") or []
    if conflicts:
        st.info("A definition draft already contains different work. Review that draft before trying the copy again.")
        if st.button("Open the existing definition draft", key=key + "_existing"):
            return {"route": "scientific_draft", "params": {"item_id": conflicts[0]}}


def _confirmation(root, pack, actor_id, report, phase, *, local_demo, can_review, can_write, allowed_packs):
    state = report["phases"][phase]
    if state.get("blocked_by"):
        previous = state["blocked_by"] if isinstance(state["blocked_by"], list) else [state["blocked_by"]]
        st.info("Confirm " + ", ".join(LABELS.get(name, str(name)).lower() for name in previous) + " before confirming this phase.")
        return
    if state.get("confirmed"):
        review = state.get("review") or {}
        st.success(f"{LABELS[phase]} confirmed" + (f" by {review['actor_id']}" if review.get("actor_id") else "") + ".")
        index = PHASES.index(phase)
        if index < len(PHASES) - 1:
            next_phase = PHASES[index + 1]
            if st.button("Continue to " + LABELS[next_phase].lower(), key=PREFIX + "continue_" + phase):
                st.session_state[PREFIX + "next_phase"] = next_phase
                st.rerun()
        else:
            st.success("All three variable review phases are complete.")
            return _transfer(root, pack, actor_id, report, local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
        return
    if not state.get("ready"):
        count = state.get("total_count", len(report["rows"])) - state.get("ready_count", 0)
        st.info(f"Resolve the remaining {count} variable{'s' if count != 1 else ''} before confirming {LABELS[phase].lower()}.")
        if st.button("Resolve remaining variables", key=PREFIX + "resolve_" + phase):
            if phase == "science":
                st.session_state[PREFIX + "next_science_view"] = "attention"
            else:
                incomplete = next((row for row in report["rows"] if row.get("phase_status", {}).get(phase) != "ready"), None)
                if incomplete:
                    st.session_state[PREFIX + "incoming_item"] = {"phase": phase, "item_id": incomplete["item_id"]}
            st.rerun()
        if state.get("issues"):
            with st.expander("Remaining review details", expanded=False):
                for issue in state["issues"]:
                    st.caption(_issue_text(issue))
        return
    if not can_review:
        st.info(f"The dashboard is ready. A permitted {ROLES[phase].lower()} can confirm this phase.")
    key = PREFIX + "confirm_" + _digest([phase, report["input_digest"], report["state_digest"]])
    confirmed = st.checkbox("I have reviewed all variables in this phase.", key=key, disabled=not can_review)
    if st.button("Confirm " + LABELS[phase].lower(), key=key + "_save", type="primary", disabled=not can_review or not confirmed):
        try:
            result = workflow.confirm_phase(root, pack, actor_id, phase,
                expected_input_digest=report["input_digest"], expected_state_digest=report["state_digest"],
                confirmed=confirmed, allowed_packs=allowed_packs, local_demo=local_demo, can_review=can_review)
        except (ValueError, OSError) as error:
            st.error(str(error))
            return
        if not result.get("ok"):
            _errors(result)
            return
        st.session_state[PREFIX + "notice"] = LABELS[phase] + " confirmed."
        st.session_state.setdefault("flow_result", {}).pop(pack, None)
        st.rerun()


def assistant_context(root, pack, actor_id, *, allowed_packs=None, params=None):
    """Give chat the same phase and current blockers as the visible dashboard."""
    report = _describe(root, pack, actor_id, allowed_packs)
    context = st.session_state.get(PREFIX + "context") or []
    current_context = context[:4] == [str(root), pack, actor_id, allowed_packs]
    phase = st.session_state.get(PREFIX + "phase") if current_context else None
    requested = (params or {}).get("phase")
    if st.session_state.get(PREFIX + "incoming") != _digest(params or {}) and requested in PHASES:
        phase = requested
    if phase not in PHASES:
        phase = (params or {}).get("phase") or report.get("current_phase") or "science"
    if phase == "complete":
        phase = "output"
    if phase not in PHASES:
        phase = "science"
    state = (report.get("phases") or {}).get(phase, {})
    blockers = [_text(issue) for issue in report.get("errors") or []]
    blocked_by = state.get("blocked_by") or []
    if isinstance(blocked_by, str):
        blocked_by = [blocked_by]
    blockers.extend("Confirm " + LABELS.get(name, str(name)).lower() + " first." for name in blocked_by)
    blockers.extend(_issue_text(issue) for issue in state.get("issues") or [])
    for row in report.get("rows") or []:
        if row.get("phase_status", {}).get(phase) != "ready":
            blockers.append(f"{row.get('variable_id', '')}: {_status(row, phase)}")
    from experiments.portal import page_assistant_context
    selected = page_assistant_context.variable_context(st.session_state, root=root, pack=pack, actor_id=actor_id,
        allowed_packs=allowed_packs, report=report)
    return {"phase": phase, "blockers": list(dict.fromkeys(blockers)),
            "row_count": len(report.get("rows") or []), "ready_count": state.get("ready_count", 0),
            **({"selected_row": selected} if selected and selected.get("phase") == phase else {})}


def render(root, pack, actor_id, params=None, local_demo=False, can_write=False,
           can_view=True, can_review=False, allowed_packs=None):
    if not can_view:
        from experiments.portal import related_extraction_page
        related_extraction_page.clear()
        from experiments.portal import source_table_intake_page
        source_table_intake_page.clear()
        st.info("You need access to this product to review its variables.")
        return True
    context = [str(root), pack, actor_id, allowed_packs, local_demo, can_write, can_review]
    if st.session_state.get(PREFIX + "context") != context:
        for key in list(st.session_state):
            if str(key).startswith(PREFIX):
                del st.session_state[key]
        st.session_state[PREFIX + "context"] = context
        from experiments.portal import session_drafts
        session_drafts.restore_variable_browser(st.session_state, context)
    _retain_row_entries()
    try:
        report = _describe(root, pack, actor_id, allowed_packs)
    except (ValueError, OSError) as error:
        st.error(str(error))
        return True
    if not report.get("ok"):
        _errors(report)
        if report.get("code") == "review_snapshot_changed" and report.get("retryable") is True:
            st.info("The table could not finish reading its current evidence. Reload it here; your unfinished entries are retained and any changed source will still need review.")
            if st.button("Reload current table", key=PREFIX + "reload_table"):
                st.session_state[PREFIX + "refresh_table"] = True
                st.rerun()
            return True
        recovery = report.get("recovery")
        if isinstance(recovery, dict) and recovery.get("route") == "scientific_draft":
            st.info("A saved definition needs a correction. Open the named row to edit it; your specification and other definitions are retained.")
            if st.button("Repair this definition", key=PREFIX + "repair_definition"):
                return recovery
            return True
        if st.button("Open specification intake", key=PREFIX + "intake"):
            return {"route": "progress", "params": {"action_id": "g1_extract"}}
        return True
    _reconcile_row_entries(report, pack, actor_id)
    from experiments.portal import variable_review_history_page
    if variable_review_history_page.render(root, pack, actor_id, report, allowed_packs=allowed_packs,
            local_demo=local_demo, can_write=can_write):
        st.rerun()
    if st.session_state.get(PREFIX + "notice"):
        st.success(st.session_state.pop(PREFIX + "notice"))
    if st.session_state.get(PREFIX + "saved_selection"):
        _saved_row_notice(report, st.session_state[PREFIX + "saved_selection"])
    if not local_demo:
        st.info("This shared review can be edited and confirmed in development mode.")
    for warning in report.get("warnings") or []:
        st.warning(str(warning))
    rows = report.get("rows") or []
    context_rows = report.get("context_rows") or []
    if context_rows:
        from experiments.portal import specification_row_context_page
        if specification_row_context_page.render_context_rows(root, pack, actor_id, context_rows,
                local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs):
            st.session_state[PREFIX + "notice"] = "Row restored to the variable list."
            st.session_state.setdefault("flow_result", {}).pop(pack, None)
            st.rerun()
    identifier_rows = [row for row in rows if row.get("identifier_error")]
    if identifier_rows:
        st.warning(f"{len(identifier_rows)} variable identifier(s) need correction. Choose a row marked 'Fix definition identifier' to edit its name; the other variables remain available.")
    if not rows:
        if context_rows:
            st.info("All extracted rows are classified as document metadata. Use Document metadata above to inspect a row or restore it as a variable.")
            return True
        st.info("No variables are available to review yet. Extract and check the product specification first.")
        if st.button("Open specification intake", key=PREFIX + "intake"):
            return {"route": "progress", "params": {"action_id": "g1_extract"}}
        return True
    requested = (params or {}).get("phase")
    incoming = _digest(params or {})
    if st.session_state.get(PREFIX + "incoming") != incoming:
        st.session_state[PREFIX + "incoming"] = incoming
        st.session_state.pop(PREFIX + "incoming_item", None)
        if (params or {}).get("close_workbook_draft") is True:
            st.session_state[PREFIX + "workbook_draft_open"] = False
            st.session_state.setdefault(PREFIX + "page_draft", {})["workbook_draft_open"] = False
        if requested in PHASES:
            st.session_state[PREFIX + "phase"] = requested
        if (params or {}).get("action") == "review":
            st.session_state[PREFIX + "science_view"] = "all"
            st.session_state.pop(PREFIX + "incoming_item", None)
        else:
            item_id = (params or {}).get("item_id")
            matches = [row for row in rows if row["item_id"] == item_id] if item_id else [
                row for row in rows if str(row["variable_id"]).casefold() == str((params or {}).get("variable", "")).casefold()]
            if len(matches) == 1:
                st.session_state[PREFIX + "phase"] = requested if requested in PHASES else "science"
                st.session_state[PREFIX + "incoming_item"] = {"item_id": matches[0]["item_id"],
                    "phase": requested if requested in PHASES else "science"}
                st.session_state[PREFIX + "science_view"] = "all"
    if PREFIX + "next_science_view" in st.session_state:
        st.session_state[PREFIX + "science_view"] = st.session_state.pop(PREFIX + "next_science_view")
    if PREFIX + "next_phase" in st.session_state:
        st.session_state[PREFIX + "phase"] = st.session_state.pop(PREFIX + "next_phase")
    if st.session_state.get(PREFIX + "phase") not in PHASES:
        st.session_state[PREFIX + "phase"] = report.get("current_phase") if report.get("current_phase") in PHASES else "output" if report.get("current_phase") == "complete" else "science"
    phase = st.radio("Review phase", PHASES, key=PREFIX + "phase", horizontal=True,
        format_func=lambda name: f"{PHASES.index(name) + 1}. {LABELS[name]}" + (" · Confirmed" if report["phases"][name].get("confirmed") else ""))
    # A phase can be viewed before its prerequisites permit edits. Keep that
    # navigation choice even when the blocked phase returns before its table.
    st.session_state.setdefault(PREFIX + "page_draft", {})["phase"] = phase
    from experiments.portal import connected_workflow_page
    connected_workflow_page.select_context(pack, actor_id, phase=phase)
    state = report["phases"][phase]
    st.write(f"**{ROLES[phase]} · {len(rows)} {'variable' if len(rows) == 1 else 'variables'}**")
    if state.get("blocked_by"):
        blockers = state["blocked_by"] if isinstance(state["blocked_by"], list) else [state["blocked_by"]]
        prerequisite = next((name for name in PHASES if name in blockers), "science")
        st.info("Finish " + LABELS[prerequisite].lower() + " first. Your saved answers will stay here.")
        if st.button("Continue " + LABELS[prerequisite].lower(), key=PREFIX + "finish_previous", type="primary"):
            st.session_state[PREFIX + "next_phase"] = prerequisite
            if prerequisite == "science":
                st.session_state[PREFIX + "next_science_view"] = "all" if report["phases"][prerequisite].get("ready") else "attention"
            st.rerun()
        return True
    st.caption({"science": "Choose what each variable means, check its values, then save.",
                "source": "Choose the table and columns that supply each variable, then save.",
                "output": "Choose the final column name and where to include it, then save."}[phase])
    if phase == "science":
        def remember_workbook_view():
            # Visibility is navigation, never a request to start/resume a job.
            st.session_state.setdefault(PREFIX + "page_draft", {})["workbook_draft_open"] = st.session_state[PREFIX + "workbook_draft_open"]
        if st.toggle("Draft the whole workbook with AI", key=PREFIX + "workbook_draft_open", on_change=remember_workbook_view):
            from experiments.portal import configuration_proposal_page
            workbook_route = configuration_proposal_page.render_workbook_drafting(root, pack, actor_id,
                local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
            if workbook_route:
                return workbook_route
    # Scientific review can describe parameters and calculations without a
    # delivered TSV. Import is optional here and available before source mapping.
    import_open = st.session_state.get(PREFIX + "source_tables_open", False)
    if phase == "science":
        def toggle_source_tables():
            st.session_state[PREFIX + "source_tables_open"] = not st.session_state.get(PREFIX + "source_tables_open", False)
        st.button("Hide source tables" if import_open else "Add or inspect source tables (optional)",
            key=PREFIX + "source_tables_toggle", on_click=toggle_source_tables)
    if phase == "source" or phase == "science" and import_open:
        from experiments.portal import source_table_intake_page
        if source_table_intake_page.render(root, pack, actor_id, local_demo=local_demo,
                can_write=can_write, can_view=can_view, allowed_packs=allowed_packs):
            st.session_state.setdefault("flow_result", {}).pop(pack, None)
            st.rerun()
    permitted = bool(local_demo and can_write)
    if not permitted:
        st.info("You can review this dashboard. Editing requires permission to change this product.")
    attention = [row for row in rows if row.get("phase_status", {}).get(phase) != "ready"]
    if phase == "science":
        attention.sort(key=lambda row: ({"unmapped": 0, "ambiguous": 1}.get(row.get("status"), 2), row.get("variable_id", "")))
        if attention:
            st.write(f"{len(attention)} of {len(rows)} variables need attention.")
            view = st.radio("Scientific review view", ("attention", "all"), horizontal=True, key=PREFIX + "science_view",
                            format_func=lambda value: "Resolve variables needing attention" if value == "attention" else "Review all variables")
        else:
            view = "all"
            st.success("Every variable is prepared. Review the complete dashboard, then confirm once.")
    else:
        view = "all"
    shown = attention if view == "attention" else rows
    editor_options = [row["item_id"] for row in shown]
    lookup = {row["item_id"]: row for row in shown}
    selected_key = PREFIX + "selected_" + _digest([phase, view, editor_options])
    if selected_key not in st.session_state:
        navigation = st.session_state.get(PREFIX + "page_draft", {})
        previous = navigation.get("item_id") if navigation.get("phase") == phase and navigation.get("view") == view else None
        st.session_state[selected_key] = previous if previous in lookup else editor_options[0] if view == "attention" and editor_options else None
    incoming_item = st.session_state.get(PREFIX + "incoming_item") or {}
    if incoming_item.get("phase") == phase and incoming_item.get("item_id") in lookup:
        st.session_state[selected_key] = incoming_item["item_id"]
        st.session_state.pop(PREFIX + "incoming_item", None)
    saved_selection = st.session_state.pop(PREFIX + "saved_selection", None) or {}
    if saved_selection.get("phase") == phase and saved_selection.get("advance"):
        pending = {identity[0] for identity, entry in st.session_state.get(PREFIX + "row_entries", {}).items()
                   if identity[1] == phase and entry.get("dirty")}
        following = _next_unfinished(rows, phase, saved_selection["item_id"], saved_selection.get("order") or editor_options, pending)
        if following in pending and following not in lookup and phase == "science":
            # A previously complete row may still have an unsaved local edit.
            # Show it in the full table instead of skipping that unfinished work.
            st.session_state[PREFIX + "next_science_view"] = "all"
            st.session_state[PREFIX + "incoming_item"] = {"phase": phase, "item_id": following}
            st.rerun()
        st.session_state[selected_key] = following if following in lookup else None
        if following in lookup:
            theme.queue_focus(st.session_state, "rwd-variable-editor")
        st.session_state[PREFIX + "table_generation"] = st.session_state.get(PREFIX + "table_generation", 0) + 1
        if following is None:
            if any(item["item_id"] == saved_selection["item_id"] for item in rows):
                st.subheader("Variables ready for review", anchor="rwd-variable-feedback")
                theme.queue_focus(st.session_state, "rwd-variable-feedback")
                st.html(theme.take_focus_markup(st.session_state, "rwd-variable-feedback"))
                st.info("No unfinished variables remain in this phase. Review the table, then confirm it when you are ready.")
            else:
                st.warning("The saved variable is no longer in the current specification. Choose a variable from the refreshed table.")
    elif saved_selection.get("phase") == phase and saved_selection.get("item_id") in lookup:
        saved_row = lookup[saved_selection["item_id"]]
        if not saved_selection.get("attention") or saved_row.get("phase_status", {}).get(phase) != "ready":
            st.session_state[selected_key] = saved_row["item_id"]

    table_key = PREFIX + "table_" + _digest([phase, view, editor_options,
        report.get("input_digest"), report.get("state_digest"), st.session_state.get(PREFIX + "table_generation", 0)])

    def select_table_row():
        from experiments.portal import page_assistant_context
        page_assistant_context.clear_variable(st.session_state)
        selection = st.session_state.get(table_key, {}).get("selection", {}).get("rows", [])
        position = selection[0] if len(selection) == 1 else None
        st.session_state[selected_key] = editor_options[position] if type(position) is int and 0 <= position < len(editor_options) else None
        if st.session_state[selected_key] is not None:
            theme.queue_focus(st.session_state, "rwd-variable-editor")

    def reset_table_selection():
        from experiments.portal import page_assistant_context
        page_assistant_context.clear_variable(st.session_state)
        st.session_state[PREFIX + "table_generation"] = st.session_state.get(PREFIX + "table_generation", 0) + 1
        if st.session_state.get(selected_key) is not None:
            theme.queue_focus(st.session_state, "rwd-variable-editor")

    current = st.session_state.get(selected_key)
    with st.container(key="rwd_variable_review_layout"):
        # Keep the complete table readable; edit the selected variable below it.
        list_panel, detail_panel = st.container(), st.container()
    with list_panel:
        selected = st.selectbox("Resolve a variable" if view == "attention" else "Edit a variable (optional)",
            editor_options, index=None, placeholder="Type a variable name or choose a row below", key=selected_key,
            on_change=reset_table_selection,
            format_func=lambda item_id: f"{lookup[item_id]['variable_id']} · {_status(lookup[item_id], phase)}")
        st.caption("Search by name or select a table row. The editor opens below; Save updates this list.")
        if phase == 'science':
            _review_grid(root, pack, actor_id, shown, report, permitted=permitted, local_demo=local_demo,
                allowed_packs=allowed_packs, key=table_key)
        else:
            st.dataframe(dashboard_rows(shown, phase), hide_index=True, width="stretch",
                column_order=("Variable", "Definition / logic / formula", "Values", "Type of value", "Status", "Workbook row") if phase == "science" else None,
                column_config={"Variable": st.column_config.TextColumn(width=110),
                               "Definition / logic / formula": st.column_config.TextColumn("Meaning / rule", width=190),
                               "Values": st.column_config.TextColumn(width=150),
                               "Type of value": st.column_config.TextColumn("Type", width=100),
                               "Status": st.column_config.TextColumn(width=160),
                               "Workbook row": st.column_config.TextColumn(help="The original specification section and row. Select the variable to read its source wording.")},
                height=min(340 if current in editor_options else 480, 36 + 35 * max(1, len(shown)))
                    if phase == "science" else 280 if current in editor_options else "auto",
                key=table_key, on_select=select_table_row, selection_mode="single-row",
                selection_default={"selection": {"rows": [editor_options.index(current)] if current in editor_options else [], "columns": [], "cells": []}})
    st.session_state.setdefault(PREFIX + "page_draft", {}).update(phase=phase, view=view, item_id=selected)
    from experiments.portal import connected_workflow_page
    connected_workflow_page.select_context(pack, actor_id, phase=phase, item_id=selected)
    # The connected route shares this params mapping. Its updated selection is
    # already displayed, not a new incoming request to reopen on the next rerun.
    st.session_state[PREFIX + "incoming"] = _digest(params or {})
    def clear_selection():
        st.session_state[selected_key] = None
        reset_table_selection()
    with list_panel:
        previous, following, close = st.columns(3)
    def move_selection(offset):
        current_item = st.session_state.get(selected_key)
        if current_item in editor_options:
            position = editor_options.index(current_item) + offset
            if 0 <= position < len(editor_options):
                st.session_state[selected_key] = editor_options[position]
                reset_table_selection()
    position = editor_options.index(selected) if selected in editor_options else -1
    previous.button("Previous variable", key=PREFIX + "previous_variable", on_click=move_selection, args=(-1,),
        disabled=position <= 0, shortcut="Alt+Shift+ArrowLeft", help="Open the previous visible row. Unfinished edits are kept.")
    following.button("Next variable", key=PREFIX + "next_variable", on_click=move_selection, args=(1,),
        disabled=position < 0 or position >= len(editor_options) - 1, shortcut="Alt+Shift+ArrowRight", help="Open the next visible row. Unfinished edits are kept; this does not save or approve them.")
    close.button("Clear selected variable", key=PREFIX + "clear_selection", on_click=clear_selection,
        disabled=selected is None,
        help="Closes the editor without removing the variable. Unsaved entries stay in this session; select the row again to continue.")
    output_snapshot = _digest([pack, actor_id, report.get("input_digest"), report.get("state_digest")])
    if st.session_state.get(PREFIX + "output_dirty_snapshot") != output_snapshot:
        st.session_state[PREFIX + "output_dirty_snapshot"] = output_snapshot
        st.session_state[PREFIX + "output_dirty_rows"] = {
            identity[0]: entry["row"]["variable_id"]
            for identity, entry in st.session_state.get(PREFIX + "row_entries", {}).items()
            if identity[1] == "output" and entry["dirty"] and entry["basis"] == _entry_basis(report)
        }
    st.session_state[PREFIX + "output_editor_dirty"] = bool(st.session_state[PREFIX + "output_dirty_rows"])
    if _pending_row_entries(report, pack, actor_id):
        return True
    if selected:
        with detail_panel:
            _editor(root, pack, actor_id, report, lookup[selected], phase,
                    permitted=permitted, local_demo=local_demo, allowed_packs=allowed_packs, attention_view=view == "attention",
                    navigation_order=editor_options)
    elif phase == "science":
        detail_panel.info("Choose a variable from the list to review where it comes from and what its values mean.")
    from experiments.portal import related_extraction_page
    related_route = related_extraction_page.render(root, pack, actor_id, can_view=can_view,
        allowed_packs=allowed_packs)
    if related_route:
        return related_route
    if phase == "output" and st.session_state[PREFIX + "output_editor_dirty"]:
        dirty_rows = dict(st.session_state[PREFIX + "output_dirty_rows"])
        st.info("Save or discard the output edits before confirming the table or preparing executable settings. "
                "Unsaved variables: " + ", ".join(dirty_rows.values()) + ". Select a variable to continue editing it.")
        if st.button("Discard unsaved output edits", key=PREFIX + "discard_output", disabled=not permitted):
            st.session_state[PREFIX + "output_dirty_rows"] = {}
            st.session_state[PREFIX + "output_editor_dirty"] = False
            entries = st.session_state.get(PREFIX + "row_entries", {})
            for item_id in dirty_rows:
                entry = entries.get((item_id, "output"))
                if entry:
                    _reset_entry_widgets(entry, pack, actor_id)
                entries.pop((item_id, "output"), None)
            st.session_state[PREFIX + "notice"] = "Unsaved output edits discarded. The saved review table is unchanged."
            st.rerun()
        return True
    if view == "all":
        action = _confirmation(root, pack, actor_id, report, phase, local_demo=local_demo,
                      can_review=bool(local_demo and can_review), can_write=permitted, allowed_packs=allowed_packs)
        if action:
            return action
    if phase == "output":
        from experiments.portal import variable_execution_bridge_page
        action = variable_execution_bridge_page.render(root, pack, actor_id,
            local_demo=local_demo, can_write=permitted, allowed_packs=allowed_packs)
        if action:
            return action
    return True
