"""One compact structure editor shared by intake and specification repair."""
from __future__ import annotations

import hashlib
import streamlit as st
from rwd_tools import spec_extract

LABELS = {"variable": "Variable name", "label": "Label", "definition": "Definition / formula",
          "time_period": "Time period", "values": "Values / codes", "source": "Source",
          "notes": "Notes", "section": "Section", "codelist_group": "Code list group"}


def render(inspection, *, prefix, editable, enabled=True, proposed=None):
    """Return only explicitly opened/confirmed column choices; no source writes."""
    result = {}
    editable = set(editable)
    for sheet in inspection:
        name = sheet["name"]
        if name not in editable:
            continue
        key = prefix + hashlib.sha256(name.encode()).hexdigest()[:14]
        suggestion = (proposed or {}).get(name)
        with st.expander("Column meanings · " + name):
            st.caption("Original headers are kept. Turn on Confirm or correct columns to edit the header row and column meanings. "
                       "You can reopen this panel to change them; changed choices need a new preview.")
            customize = st.checkbox("Confirm or correct columns for " + name, key=key + "_use",
                                    value=bool(suggestion), disabled=not enabled)
            if not customize:
                st.dataframe([{"Excel column": c["letter"], "Original header": c["header"],
                               "Meaning": LABELS.get(c.get("suggested"), "Not assigned")}
                              for c in sheet["columns"]], hide_index=True, width="stretch")
                continue
            initial = (suggestion or {}).get("header_row") or sheet.get("header_row") or 1
            candidates = {r["row"]: r["cells"] for r in sheet.get("preview_rows", sheet.get("header_candidates", []))}
            candidates.setdefault(initial, [])
            header = st.selectbox("Header row · " + name, sorted(candidates),
                index=sorted(candidates).index(initial), key=key + "_header", disabled=not enabled,
                format_func=lambda n: str(n) + " · " + " / ".join(str(v) for v in candidates[n] if v)[:120])
            selected = (suggestion or {}).get("columns") or {c["suggested"]: c["letter"] for c in sheet["columns"] if c.get("suggested")}
            labels = {c["letter"]: c["header"] for c in sheet["columns"]}
            if candidates.get(header):
                labels = {spec_extract._column_letter(i + 1): str(v) for i, v in enumerate(candidates[header]) if v}
            columns = {}
            for field, label in LABELS.items():
                options = ["", *labels]
                choice = selected.get(field, "")
                chosen = st.selectbox(label + " column · " + name, options,
                    index=options.index(choice) if choice in options else 0,
                    key=key + "_" + str(header) + "_" + field, disabled=not enabled,
                    format_func=lambda col: f"{col} · {labels[col]}" if col else "Not present / not assigned")
                if chosen:
                    columns[field] = chosen
            result[name] = {"header_row": header, "columns": columns}
    return result
