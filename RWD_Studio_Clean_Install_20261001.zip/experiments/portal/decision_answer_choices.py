"""Question-bound drafting choices; nothing selects or records a scientific ruling."""
from __future__ import annotations
import hashlib
from copy import deepcopy
import streamlit as st
from rwd_tools import decision_choice as payload
from rwd_tools.decision_choice import CUSTOM, UNSURE, COMPLETE, PARTS, _MATRIX, describe, derived_alternatives

def prefix(decision_id):
    return f"decision_answer_{decision_id}_"


def use_answer(decision_id, answer):
    """Called before this question's widgets render, including an explicit AI copy."""
    base = prefix(decision_id)
    st.session_state.pop(base + "answer_choice", None)
    st.session_state[base + "answer"] = answer
    st.session_state[base + "approach"] = CUSTOM
    st.session_state[base + "previous_approach"] = CUSTOM
    st.session_state[base + "custom_answer"] = answer


def note_edit(decision_id):
    base = prefix(decision_id)
    st.session_state.pop(base + "answer_choice", None)
    st.session_state[base + "approach"] = CUSTOM
    st.session_state[base + "previous_approach"] = CUSTOM
    st.session_state[base + "custom_answer"] = st.session_state.get(base + "answer", "")


def render(decision_id, question, *, enabled, remember, form=None):
    base = prefix(decision_id)
    guide = describe(question)
    form = form or {"question": question}
    signature = payload._sha([question, form.get("evidence"), form.get("question_sha256"), form.get("records_sha256")])
    if st.session_state.get(base + "guide") not in (None, signature):
        # Keep authored text but do not reuse a choice from a different question.
        st.session_state[base + "approach"] = CUSTOM if st.session_state.get(base + "answer") else None
        st.session_state[base + "previous_approach"] = st.session_state[base + "approach"]
        st.session_state.pop(base + "choice_explanation", None)
        st.session_state.pop(base + "answer_choice", None)
        remember(decision_id)
    st.session_state[base + "guide"] = signature
    raw = st.session_state.get(base + "answer", "")
    if base + "approach" not in st.session_state:
        prior = st.session_state.get(base + "previous_approach")
        st.session_state[base + "approach"] = prior if prior in (*guide["options"], CUSTOM, UNSURE) else CUSTOM if raw else None
        st.session_state[base + "previous_approach"] = st.session_state[base + "approach"]

    def changed():
        st.session_state.pop(base + "answer_choice", None)
        old = st.session_state.get(base + "previous_approach")
        previous_answer = st.session_state.get(base + "answer", "")
        if old in (None, CUSTOM):
            st.session_state[base + "custom_answer"] = previous_answer
        mode = st.session_state[base + "approach"]
        if mode != old and str(mode).startswith("Consider: "):
            st.session_state.pop(base + "choice_explanation", None)
        if mode in guide["options"]:
            if not mode.startswith("Consider: "):
                st.session_state[base + "answer"] = guide["options"][mode]
        elif mode == UNSURE:
            st.session_state[base + "answer"] = "TODO: Not sure yet. Record what needs discussion and which evidence is still needed."
        elif mode == CUSTOM:
            st.session_state[base + "answer"] = st.session_state.get(base + "custom_answer", previous_answer)
        elif mode is None and previous_answer:
            st.session_state[base + "approach"] = CUSTOM
        st.session_state[base + "previous_approach"] = st.session_state[base + "approach"]
        remember(decision_id)

    st.selectbox("How would you like to draft the answer?", [*guide["options"], CUSTOM, UNSURE],
                 index=None, key=base + "approach", placeholder="Choose a starting point, or type your own answer below",
                 disabled=not enabled, on_change=changed,
                  help="Nothing is selected automatically. Quoted alternatives come from this exact question. Add your explanation, then explicitly copy the choice into your draft before reviewing it.")
    mode = st.session_state.get(base + "approach")
    guide["pending_choice"] = bool(mode in guide["options"] and str(mode).startswith("Consider: "))
    if guide["pending_choice"]:
        phrase = guide["options"][mode]
        st.info("Next: explain where this choice applies and why the evidence supports it. Then use it in your draft and review the full answer below.")
        explanation = st.text_area("Why this choice, and where does it apply?", key=base + "choice_explanation",
            max_chars=2500, disabled=not enabled,
            help="One or two sentences can be enough. State the population or fields, the complete rule and its source. Include any limits or exceptions; if still unresolved, keep the question open.")
        from experiments.portal import decision_answers
        ready = bool(explanation.strip()) and not decision_answers.unresolved_answer(explanation)
        composed = payload.compose(question, phrase, explanation)
        if len(composed) > 4000:
            ready = False
            st.warning("Shorten the explanation so the complete answer fits the 4,000-character decision record; cite longer evidence separately.")
        def use_choice():
            # An explicit draft action, never attribution, application or scientific approval.
            use_answer(decision_id, composed)
            option = next(item for item in payload.option_catalog(question) if item["value"] == phrase)
            st.session_state[base + "answer_choice"] = payload.selection(form, option["id"], explanation, composed)
            remember(decision_id)
        st.button("Use choice and explanation in my draft", key=base + "use_choice", disabled=not enabled or not ready,
                  on_click=use_choice)
    chosen = st.session_state.get(base + "answer_choice")
    if chosen:
        st.caption("Selected answer: " + str(chosen["selected_value"]) + ". Editing the answer below changes it to a free-text answer.")
    if guide["alternatives"] == ["Yes", "No"]:
        st.caption("This reads as a yes or no question. Your explanation supplies the rule, scope and reason. The question stays open until you explicitly save the reviewed answer.")
    elif guide["alternatives"]:
        st.caption("The quoted alternatives are stated in this question. Selecting one does not change your answer until you choose Use choice and explanation in my draft.")
    elif guide["components"]:
        st.caption("This question has several parts. Use the structured starting point and answer every applicable part; one yes/no choice would leave the ruling incomplete.")
    else:
        st.caption("This question does not supply a complete set of selectable rulings. The choices organize your draft; they do not invent scientific answers.")
    with st.expander("What to put in this answer"):
        if guide["components"]:
            for component in guide["components"]:
                st.text(component)
        st.write("State the rule, the population or outputs it applies to, and why the cited evidence supports it. For several decisions in one question, address each part and reference any detailed matrix or reviewed artifact.")
        st.caption("Illustrative format: Decision: [your reviewed rule]; Scope: [affected population or fields]; Rationale: [evidence and reasoning]; Open points: [anything still unresolved]. Replace the placeholders with your own judgment.")
    return guide
