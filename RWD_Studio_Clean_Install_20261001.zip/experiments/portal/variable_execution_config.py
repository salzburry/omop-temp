"""Resolve reviewed source adapters for the same configuration used at runtime."""
from pathlib import Path
from copy import deepcopy

from engine.config import load_config


def bind_reviewed_sources(cfg, product):
    """Read existing review evidence; never create, approve or repair an adapter."""
    from rwd_tools import source_adapter
    try:
        plan = source_adapter.compiled(str(product))
    except (AttributeError, TypeError, KeyError) as error:
        raise ValueError("Repair config/source_adapters.yaml in Sources: declare an adapters list, "
                         "with one mapping per adapter and mappings for its columns, join and review.") from error
    if plan.get("state") == "no_claim":
        return cfg
    if plan.get("state") != "compiled" or plan.get("problems"):
        raise ValueError("Resolve Source adapters before preparing executable variables: " +
                         "; ".join(plan.get("problems") or ["the declared adapter set could not be compiled"]))
    try:
        delivery = (("schema", cfg.source_schema), ("cut", cfg.refresh))
    except (KeyError, TypeError) as error:
        raise ValueError("Set run.source_schema and run.refresh in Configuration before binding a reviewed source adapter.") from error
    for key, actual in delivery:
        if plan.get(key) and str(plan[key]) != str(actual):
            raise ValueError(f"The reviewed adapter {key} differs from this delivery. Resolve it in Sources.")
    if cfg.source_union:
        raise ValueError("A single reviewed adapter set cannot bind a multi-schema source union.")
    for role, table in plan["bindings"].items():
        if role in cfg.sources and str(table) != str(cfg.table(role)):
            raise ValueError(f"The reviewed adapter and product configuration name different physical tables for {role}. Resolve them in Sources.")
    trial = deepcopy(cfg)
    trial.bind_sources(plan["bindings"], plan["digest"], plan["dataset"], roles=plan.get("roles"),
                       mapping_digest=plan.get("mapping_digest"))
    from engine.validate import adapter_rename_conflicts
    conflicts = adapter_rename_conflicts(trial)
    if conflicts:
        raise ValueError("Resolve the competing source renames: " + "; ".join(conflicts))
    cfg.bind_sources(plan["bindings"], plan["digest"], plan["dataset"], roles=plan.get("roles"),
                     mapping_digest=plan.get("mapping_digest"))
    return cfg


def load(product):
    product = Path(product)
    return bind_reviewed_sources(load_config(product / "config/data_product.yaml"), product)
