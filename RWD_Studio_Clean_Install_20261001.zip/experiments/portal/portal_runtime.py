"""Portal subprocesses return failures as results, including timeouts, never page tracebacks."""
from __future__ import annotations

import hashlib
import os
import subprocess
import time
from contextvars import ContextVar
from pathlib import Path
from typing import Literal

_JOB_CALLBACKS = ContextVar("portal_job_callbacks", default=(None, None))
_PROCESS_OBSERVER = ContextVar("portal_process_observer", default=None)
CANCELLED_EXIT = 130
CANCELLED_MESSAGE = "Cancellation requested. The local check stopped; inspect the retained workflow result before retrying."


class CommandResult(subprocess.CompletedProcess):
    """A process result with a runner-owned failure classification."""

    def __init__(self, args, returncode, stdout="", stderr="", *,
                 failure_kind: Literal["timeout", "start", "cancelled"] | None = None):
        if failure_kind not in {None, "timeout", "start", "cancelled"}:
            raise ValueError("Unknown command failure classification.")
        super().__init__(args, returncode, stdout, stderr)
        self.failure_kind = failure_kind


def job_callbacks(cancelled=None, progress=None):
    """Install callbacks only inside the detached, explicitly requested worker."""
    return _JOB_CALLBACKS.set((cancelled, progress))


def reset_job_callbacks(token):
    _JOB_CALLBACKS.reset(token)


def has_job_callbacks():
    return _JOB_CALLBACKS.get()[0] is not None


def job_cancelled():
    callback, _ = _JOB_CALLBACKS.get()
    return bool(callback and callback())


def job_progress(message):
    _, callback = _JOB_CALLBACKS.get()
    if callback:
        callback(message)


def process_observer(callback):
    return _PROCESS_OBSERVER.set(callback)


def reset_process_observer(token):
    _PROCESS_OBSERVER.reset(token)


def snapshot_path(root, state_dir, portal_dir):
    """Default status artifacts live outside the checkout, with one namespace per repository."""
    explicit = os.environ.get("RWDP_GOVERNANCE_SNAPSHOT")
    if explicit:
        return os.path.realpath(explicit)
    if os.path.realpath(state_dir) == os.path.realpath(portal_dir):
        identifier = hashlib.sha256(os.path.normcase(os.path.realpath(root)).encode("utf-8")).hexdigest()[:12]
        state_dir = os.path.join(os.path.expanduser("~"), "rwdp-out", "portal", identifier)
    return os.path.realpath(os.path.join(state_dir, "snapshot.json"))


def within_packs(path, root, packs):
    """A file belongs to an assigned pack only when its resolved path stays inside it."""
    candidate = os.path.normcase(os.path.realpath(os.path.join(root, path)))
    for pack in packs:
        parent = os.path.normcase(os.path.realpath(os.path.join(root, pack)))
        try:
            if os.path.commonpath((candidate, parent)) == parent:
                return True
        except ValueError:
            continue
    return False


def timeout(name, default):
    try:
        value = int(os.environ.get(name, str(default)))
        return value if 1 <= value <= 3600 else default
    except (TypeError, ValueError):
        return default


TIMEOUT_EXIT = 124
CANNOT_START_EXIT = 126
# THE ONE SEAM A TEST REPLACES. The runner starts its own processes (subprocess.run cannot stop a
# grandchild), so a journey test that used to intercept subprocess.run intercepts this factory
# instead and hands back a double with start_tree()/close_tree() as well as the
# usual communicate()/poll()/wait()/kill(). Detached worker launches do not opt in.
from experiments.portal.process_lifetime import popen as _popen


def _timeout_message(timeout_s):
    return (f"This action exceeded {timeout_s}s. Your form is retained. "
            "Check the product's current state before retrying a write; an interrupted action may need recovery. "
            "Give these details to your data expert if it happens again.")


def _cannot_start_message(exc):
    return (f"The action could not start ({type(exc).__name__}). Your form is retained. "
            "Your data expert can check the runtime installation.")


def failure_kind(result):
    """Read runner metadata; a tool's exit code or wording cannot invent it."""
    value = getattr(result, "failure_kind", None)
    return value if value in {"timeout", "start", "cancelled"} else None


def display_result(result):
    """Format a typed result for people; callers keep its outcome separate from this text."""
    if not isinstance(result, CommandResult):
        raise TypeError("A command result is required.")
    support = " Support reference: " + result.diagnostic_id if getattr(result, "diagnostic_id", None) else ""
    kind = failure_kind(result)
    if kind == "timeout":
        duration = getattr(result, "timeout_s", None)
        limit = f"{duration}s" if duration is not None else "its time limit"
        return (f"This check exceeded {limit}. Your draft is retained. "
                "Check the product's current state before retrying; give the check details to your data expert." + support)
    if kind == "start":
        return ("The check could not start. Your draft is retained. "
                "Ask your data expert to check the runtime installation." + support)
    output = ((result.stdout or "") + (result.stderr or "")).strip() or "(no output)"
    output = "\n".join(line for line in output.splitlines()
                       if not line.startswith("SUCCESS: The process with PID")
                       and not line.startswith("ERROR: The process")).strip() or "(no output)"
    return output + f"\n\nexit {result.returncode}"


def _terminate_tree(process, kill_tree):
    """Stop everything the command started, not only the direct child.

    Killing the child alone leaves a grandchild (a tool that spawns another python) running after the
    portal has already told the person the action failed; that survivor may still write into the pack.
    The child runs in its own process group so the whole group can be stopped together."""
    if kill_tree:
        # Ownership outlives the direct child. The guard/job/group also contains
        # grandchildren whose original parent already exited.
        process.close_tree()
    elif process.poll() is None:
        process.kill()
    try:
        process.wait(timeout=15)
    except subprocess.TimeoutExpired:
        pass


def run(argv, *, cwd, timeout_s, kill_tree=True, extra_env=None):
    from experiments.portal import operational_logging as diagnostics
    operation_id = diagnostics.identifier()
    began = time.monotonic()
    diagnostics.event(operation_id, 'command_started', executable=os.path.basename(str(argv[0])),
        timeout_seconds=timeout_s, argument_count=len(argv))
    try:
        result = _run_impl(argv, cwd=cwd, timeout_s=timeout_s, kill_tree=kill_tree, extra_env=extra_env)
    except BaseException as error:
        diagnostics.exception(operation_id, error)
        raise
    result.diagnostic_id = operation_id
    if getattr(result, 'start_error', None) is not None:
        diagnostics.exception(operation_id, result.start_error)
    diagnostics.event(operation_id, 'command_finished', returncode=result.returncode,
        failure_kind=failure_kind(result), elapsed_seconds=round(time.monotonic() - began, 3),
        stdout=diagnostics.output_identity(result.stdout), stderr=diagnostics.output_identity(result.stderr))
    return result


def _run_impl(argv, *, cwd, timeout_s, kill_tree=True, extra_env=None):
    """One bounded command whose failure is a result the page can show, never a traceback.

    A fixed guard joins its owned OS lifetime before starting the command. Timeouts and worker
    death stop the whole tree, including children whose original parent already exited.
    kill_tree=False stops only the direct child, for callers that own their descendants."""
    from rwd_services import python_module_command
    argv = python_module_command(argv, root=cwd)
    env = {**os.environ, "PYTHONUTF8": "1", "RWD_PORTAL_WORKSPACE_ROOT": str(Path(cwd).resolve()), **(extra_env or {})}
    options = {}
    if kill_tree:
        options = ({"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW} if os.name == "nt"
                   else {"start_new_session": True})
    try:
        process = _popen(argv, cwd=cwd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace",
                         env=env, _owned_tree=kill_tree, **options)
    except OSError as exc:
        result = CommandResult(argv, CANNOT_START_EXIT, "", _cannot_start_message(exc), failure_kind="start")
        result.start_error = exc
        return result
    observer = _PROCESS_OBSERVER.get()
    observed = False
    try:
        if observer:
            observer(process, True)
            observed = True
        if kill_tree:
            process.start_tree()
    except BaseException as error:
        # Even an unexpected observer failure must not strand an inactive guard.
        try:
            _terminate_tree(process, kill_tree)
        finally:
            if observed:
                observer(process, False)
        if not isinstance(error, (OSError, ValueError)):
            raise
        return CommandResult(argv, CANNOT_START_EXIT, "",
            "The action could not start (ProcessOwnershipError). The local process group could not be bound "
            "before execution. Inspect the retained action before retrying.", failure_kind="start")
    try:
        return _communicate(process, argv, timeout_s, kill_tree)
    finally:
        try:
            if kill_tree:
                process.close_tree()
        finally:
            if observed:
                observer(process, False)


def _communicate(process, argv, timeout_s, kill_tree):
    try:
        if _JOB_CALLBACKS.get()[0] is None:
            stdout, stderr = process.communicate(timeout=timeout_s)
        else:
            deadline = time.monotonic() + timeout_s
            while True:
                if job_cancelled():
                    _terminate_tree(process, kill_tree)
                    return CommandResult(argv, CANCELLED_EXIT, "", CANCELLED_MESSAGE, failure_kind="cancelled")
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise subprocess.TimeoutExpired(argv, timeout_s)
                try:
                    stdout, stderr = process.communicate(timeout=min(1, remaining))
                    break
                except subprocess.TimeoutExpired:
                    if time.monotonic() >= deadline:
                        raise
    except subprocess.TimeoutExpired:
        _terminate_tree(process, kill_tree)
        try:
            process.communicate(timeout=15)
        except (subprocess.TimeoutExpired, OSError, ValueError):
            pass
        return CommandResult(argv, TIMEOUT_EXIT, "", _timeout_message(timeout_s), failure_kind="timeout")
    startup = getattr(process, "startup_result", None) if kill_tree else None
    if callable(startup):
        try:
            state = startup()
        except ValueError:
            message = "Runtime startup could not be verified. Your form is retained. Inspect the action details before retrying."
            return CommandResult(argv, CANNOT_START_EXIT, stdout,
                ((stderr or "").rstrip() + "\n" + message).lstrip(), failure_kind="start")
        if state["state"] == "failed":
            return CommandResult(argv, CANNOT_START_EXIT, stdout, stderr, failure_kind="start")
    return CommandResult(argv, process.returncode, stdout, stderr)
