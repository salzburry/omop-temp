"""Pure, bounded translation of explicit reviewed choices into engine settings.

Support describes an existing translation, not approval or successful execution.
No source examples, master values, arbitrary prose or variable-name guesses are
compiled. The caller rechecks the review snapshot and stages these proposals.
"""
from __future__ import annotations

from datetime import date
import math
import re

from engine.stages.treatment import line_cols
from engine.config import index_period_start, index_period_end, observation_end, data_cutoff
from experiments.portal import variable_review_consistency as consistency
from experiments.portal import variable_review_family as family


MAX_AUTO_LINES = 100
MAX_LINES_REF = "variables/treatment.yaml#/max_lines"
NUMBERING_REF = "config/data_product.yaml#/lot/line_number"
START_REF = "config/data_product.yaml#/study/index_start"
END_REF = "config/data_product.yaml#/study/index_end"
PERIOD_START_REF = "config/data_product.yaml#/study/index_period_start"
PERIOD_END_REF = "config/data_product.yaml#/study/index_period_end"
DATE_REFS = (START_REF, END_REF, PERIOD_START_REF, PERIOD_END_REF)
_KINDS = {
    **{ref: "date" for ref in DATE_REFS},
    "variables/outcomes.yaml#/min_followup_days": "integer",
    "variables/outcomes.yaml#/visit_recency_days": "integer",
    "variables/outcomes.yaml#/days_per_month": "number",
    MAX_LINES_REF: "positive_integer", NUMBERING_REF: "lot_numbering",
    "config/pipeline.yaml#/run/source_schema": "text",
    "config/pipeline.yaml#/run/refresh": "text",
}
_ALIASES = {"study.index_start": START_REF, "study.index_end": END_REF,
            "study.index_period_start": PERIOD_START_REF, "study.index_period_end": PERIOD_END_REF,
            "treatment.max_lines": MAX_LINES_REF, "lot.line_number": NUMBERING_REF,
            "run.source_schema": "config/pipeline.yaml#/run/source_schema",
            "run.refresh": "config/pipeline.yaml#/run/refresh"}
_ALIASES.update({"outcomes." + name: "variables/outcomes.yaml#/" + name
                 for name in ("min_followup_days", "visit_recency_days", "days_per_month")})
_ATTRIBUTES = {"regimen": "name", "start_date": "start",
               "delivered_end_date": "end", "last_activity_date": "lastdate"}
_MONTHS = {name: n for n, name in enumerate(
    ("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"), 1)}


def _normalize(kind, value):
    """Accept explicit unambiguous scalar input, and produce editor-safe types."""
    if kind == "date":
        if type(value) is date:
            return value.isoformat()
        if not isinstance(value, str):
            raise ValueError("Enter a date as YYYY-MM-DD or dd-Mon-YYYY, with a four-digit year.")
        value = value.strip()
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
            try:
                return date.fromisoformat(value).isoformat()
            except ValueError:
                pass
        match = re.fullmatch(r"(\d{2})-([A-Za-z]{3})-(\d{4})", value)
        if match and match[2].lower() in _MONTHS:
            try:
                return date(int(match[3]), _MONTHS[match[2].lower()], int(match[1])).isoformat()
            except ValueError:
                pass
        raise ValueError("Enter a real calendar date as YYYY-MM-DD or dd-Mon-YYYY, with a four-digit year.")
    if kind in {"integer", "positive_integer"}:
        if isinstance(value, str) and re.fullmatch(r"[0-9]+", value.strip()):
            value = int(value.strip())
        if type(value) is not int or value < (1 if kind == "positive_integer" else 0):
            raise ValueError("Enter a positive whole number." if kind == "positive_integer" else
                             "Enter a non-negative whole number of days.")
        return value
    if kind == "number":
        if isinstance(value, str) and re.fullmatch(r"[+]?(?:\d+(?:\.\d*)?|\.\d+)", value.strip()):
            value = float(value.strip())
        if type(value) not in {int, float} or not math.isfinite(value) or value <= 0:
            raise ValueError("Enter a finite positive number.")
        return value
    if kind == "lot_numbering":
        if value not in ("linenumber", "new_lot_n"):
            raise ValueError("Choose linenumber or new_lot_n for treatment-line numbering.")
        return value
    if kind == "text":
        if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.\-]{0,79}", value.strip()) or "REPLACE_ME" in value:
            raise ValueError("Enter a schema or cut name using letters, digits, underscores, dots or hyphens (up to 80 characters).")
        return value.strip()
    raise ValueError("This setting has no supported scalar translation.")


def _type_matches(kind, declared):
    actual = consistency.canonical_type(declared)
    return actual in ({"date"} if kind == "date" else
                      {"integer", "long"} if kind in {"integer", "positive_integer"} else
                      {"integer", "long", "double"} if kind == "number" else {"string"})


def _active(ref, raw):
    relative = ref.split("#/", 1)[0]
    return not relative.startswith("variables/") or relative in raw.get("variables", [])


def study_date_issues(study, *, before=None):
    """Use the engine's fallback chain without rewriting any related date.

    The explicit and legacy enrollment names must also agree, as required by
    engine.validate. A period-only edit must not silently move observation or
    the data cut through the separate legacy-end fallback.
    """
    dates, issues = {}, []
    separate_period = bool(study.get("index_period_start") or study.get("index_period_end"))
    names = ("index_start", "index_end", "index_period_start", "index_period_end")
    if separate_period:
        names += ("observation_end", "data_cutoff")
    for name in names:
        value = study.get(name)
        if value is None or value == "":
            continue
        try:
            dates[name] = _normalize("date", value)
        except (ValueError, TypeError, OverflowError):
            issues.append(f"Check study.{name} in Configuration; it must be a real date before changing the enrollment interval.")
    if issues:
        return issues
    for explicit, legacy in (("index_period_start", "index_start"), ("index_period_end", "index_end")):
        if dates.get(explicit) and dates.get(legacy) and dates[explicit] != dates[legacy]:
            issues.append(f"study.{explicit} overrides study.{legacy}, but their values disagree. "
                          "The engine requires both declarations to agree; align both explicitly in Configuration. "
                          f"Use study.{explicit} for the variable's parameter reference in Sources.")
    start, end = index_period_start(dates), index_period_end(dates)
    if not start or not end:
        issues.append("The complete study date interval cannot be validated. Check both effective index dates in Configuration.")
    elif start > end:
        issues.append("Study index start is after index end using the effective enrollment bounds. Resolve the product date interval before staging.")
    if dates.get("index_start") and dates.get("index_end") and dates["index_start"] > dates["index_end"]:
        issues.append("Study index start must be on or before study index end; the legacy declarations also need a valid interval.")
    if not separate_period:
        return issues  # Preserve the existing legacy-only proposal behavior.
    observed, cutoff = observation_end(dates), data_cutoff(dates)
    if observed and end and observed < end:
        issues.append("Effective study.observation_end precedes the enrollment end. Review the enrollment and observation dates in Configuration.")
    if cutoff and observed and cutoff < observed:
        issues.append("Effective study.data_cutoff precedes study.observation_end. Review the delivery and observation dates in Configuration.")
    if before and (before.get("index_period_start") or before.get("index_period_end")) and dates.get("index_end") != str(before.get("index_end") or ""):
        moved = [name for name, resolver in (("observation_end", observation_end), ("data_cutoff", data_cutoff))
                 if not dates.get(name) and str(resolver(before) or "") != str(resolver(dates) or "")]
        if moved:
            issues.append("Changing the legacy enrollment end also moves effective " + ", ".join("study." + name for name in moved) +
                          " through date fallback. In Configuration > Supported shared-product settings, select Observation end and Data cutoff, "
                          "then explicitly confirm their intended dates in the same proposal before changing the enrollment period.")
    return issues


def build(report, cfg, parameters):
    """Return rows, typed configuration changes, structured blockers and warnings.

    Inputs are read-only. Clinical compilation may load the supplied Config's
    declared YAML packs. The bridge checks the input digest again after planning.
    Treatment scope comes from the supported_parameters snapshot.
    """
    raw = cfg.raw
    study = dict(raw.get("study") or {})
    for ref in DATE_REFS:
        name = ref.rsplit("/", 1)[-1]
        if name not in study and ref in parameters:
            study[name] = parameters[ref][2]
    result = {"rows": [], "configuration_changes": [], "blockers": [], "warnings": []}
    proposals = {}  # ref -> [(value, row-result)]; distinct explicit values conflict.
    line_requests = []
    family_numbering = []
    review_blocked = set()

    def block(item, message, ref=None):
        entry = {"item_id": item.get("item_id", ""), "variable_id": item.get("variable_id", ""), "message": message}
        if ref:
            entry["ref"] = ref
        if entry not in result["blockers"]:
            result["blockers"].append(entry)

    def engineering(item, message, ref=None):
        item["status"] = "engineering"
        item["message"] = message
        block(item, message, ref)

    def propose(ref, value, item):
        proposals.setdefault(ref, []).append((value, item))

    def warning(message):
        if message not in result["warnings"]:
            result["warnings"].append(message)

    current_max = parameters.get(MAX_LINES_REF, (None, None, None))[2]
    valid_max = type(current_max) is int and current_max > 0
    numbering = (raw.get("lot") or {}).get("line_number", "new_lot_n")
    clinical_rows = []
    for row in sorted(report["rows"], key=lambda row: (row["item_id"], row["variable_id"])):
        item = {"item_id": row["item_id"], "variable_id": row["variable_id"],
                "status": "supported", "engine_column": "", "message": "", "output_updates": {}}
        result["rows"].append(item)
        values = row.get("values") or {}
        source, output = values.get("source") or {}, values.get("output") or {}
        phase_issues = row.get("phase_issues") or {}
        has_review_issues = False
        for phase in sorted(phase_issues):
            for issue in phase_issues[phase]:
                block(item, f"{phase.capitalize()} review: {issue}")
                has_review_issues = True
        for phase, status in sorted((row.get("phase_status") or {}).items()):
            if status != "ready" and not phase_issues.get(phase):
                block(item, f"{phase.capitalize()} review is incomplete. Resolve and check this phase before execution preparation.")
                has_review_issues = True
        if has_review_issues:
            review_blocked.add(item["item_id"])

        # Parameter metadata is executable configuration even when no column is delivered.
        if source.get("kind") == "parameter":
            refs = source.get("parameters")
            if not isinstance(refs, list) or len(refs) != 1 or not isinstance(refs[0], str):
                engineering(item, "Select exactly one supported configuration parameter for this value; multiple references need an implementation handoff.")
                continue
            ref = _ALIASES.get(refs[0], refs[0])
            explicit = {START_REF: PERIOD_START_REF, END_REF: PERIOD_END_REF}.get(ref)
            if explicit and study.get(explicit.rsplit("/", 1)[-1]):
                engineering(item, f"This legacy date is not the effective enrollment bound; the engine uses {explicit}. "
                            "Select that explicit parameter in Sources. If both date names are declared, align them explicitly in Configuration; no reference is changed automatically.", ref)
                continue
            if ref not in _KINDS or ref not in parameters or not _active(ref, raw):
                engineering(item, "Choose an active supported configuration setting in Sources, or request an implementation handoff.", ref)
                continue
            kind = _KINDS[ref]
            if not _type_matches(kind, output.get("type")):
                engineering(item, f"Choose a data type compatible with the {kind.replace('_', ' ')} configuration value.", ref)
                continue
            try:
                value = _normalize(kind, source.get("value"))
            except (ValueError, TypeError, OverflowError) as error:
                engineering(item, str(error), ref)
                continue
            if ref == MAX_LINES_REF and (not valid_max or value < current_max):
                engineering(item, "The automatic bridge only increases the current treatment-line scope. Review reductions in Configuration.", ref)
                continue
            if ref == MAX_LINES_REF and value > current_max and value > MAX_AUTO_LINES:
                engineering(item, f"A new scope above {MAX_AUTO_LINES} treatment lines needs an engineering review.", ref)
                continue
            if output.get("role") not in {"metadata", "excluded"}:
                engineering(item, "This parameter translates to configuration only. Choose Metadata or Excluded, or request implementation of a delivered value column.", ref)
                continue
            item["message"] = "Explicit product value maps to " + ref + "; it does not emit a data column."
            if not has_review_issues:
                propose(ref, value, item)
            if ref == NUMBERING_REF and not has_review_issues:
                family_numbering.append((value, item))
            continue

        if output.get("role") == "excluded":
            item["message"] = "Excluded from output; no emitted column or new execution setting is required."
            continue
        if row.get("clinical_rule"):
            from experiments.portal import variable_clinical_rules as clinical
            if row.get("family"):
                engineering(item, "Choose one calculation: clinical rule or treatment-line rule.")
                continue
            if has_review_issues:
                engineering(item, "Complete the clinical rule's scientific, source and output reviews.")
                continue
            emitted = clinical.emitted_columns(row["clinical_rule"])
            selected_output = next((column for column in emitted if column["result"] == row["clinical_rule"].get("result")), None)
            if selected_output:
                item["engine_column"] = selected_output["name"]
                item["emitted_columns"] = emitted
                if output.get("physical_name") != selected_output["name"]:
                    item["status"] = "needs_output_binding"
                    item["output_updates"] = {"output.physical_name": selected_output["name"]}
                    item["message"] = "Choose native physical column " + selected_output["name"] + " for this clinical result."
                    block(item, item["message"])
                    continue
            clinical_rows.append(row)
            item["message"] = "The reviewed rule maps to a supported calculation stage. Review the generated YAML before execution."
            continue
        selected = family.selection(row)
        if not selected:
            engineering(item, "This definition needs an implementation handoff. A familiar output name or free-text rule does not establish an executable mapping.")
            continue
        issues = family.issues(row)
        if issues:
            engineering(item, " ".join(issues))
            continue
        if selected.get("attribute") not in _ATTRIBUTES:
            engineering(item, "Associated diagnoses and custom treatment-line attributes need an implementation handoff; no computation is inferred.")
            continue
        if source.get("kind") != "vendor":
            engineering(item, "The native treatment-line mapping requires the configured LOT vendor input; a derived or other source needs an implementation handoff.")
            continue
        expected_type = family.TYPES[selected["attribute"]]
        if consistency.canonical_type(output.get("type")) != expected_type:
            engineering(item, f"Choose data type {expected_type} for this treatment-line attribute.")
            continue
        if not valid_max or not _active(MAX_LINES_REF, raw):
            engineering(item, "Activate and configure the treatment variable pack before binding its native outputs.", MAX_LINES_REF)
            continue
        line = selected["line_number"]
        if line > current_max and line > MAX_AUTO_LINES:
            engineering(item, f"Line {line} would create a new scope above {MAX_AUTO_LINES} treatment lines; request an engineering review.", MAX_LINES_REF)
            continue
        chosen_numbering = selected["numbering"]
        if not has_review_issues:
            family_numbering.append((chosen_numbering, item))
        if NUMBERING_REF not in parameters and chosen_numbering != numbering:
            engineering(item, "The selected numbering has no supported configuration editor for this product.", NUMBERING_REF)
            continue
        native = line_cols(line)[_ATTRIBUTES[selected["attribute"]]]
        item["engine_column"] = native
        item["message"] = f"Explicit treatment-line choices map to native column {native}. Configuration and execution checks still apply."
        if str(output.get("physical_name") or "").strip().casefold() != native:
            item["status"] = "needs_output_binding"
            item["output_updates"] = {"output.physical_name": native}
            item["message"] = (f"Choose native physical column {native} to bind this definition. The reviewed published name is retained as metadata; "
                               "it does not rename the engine column. A different physical name needs an implementation handoff.")
            block(item, f"Choose whether to bind the physical output to {native}; the current name is not emitted by this rule.")
        projection = (raw.get("publication") or {}).get("columns")
        if isinstance(projection, list) and native not in {str(name).casefold() for name in projection}:
            engineering(item, f"Native column {native} is excluded by publication.columns. Review the publication list in Configuration; this bridge does not replace it.")
        if not has_review_issues:
            line_requests.append((line, item))
            if NUMBERING_REF in parameters:
                propose(NUMBERING_REF, chosen_numbering, item)

    if clinical_rows:
        compiled = clinical.compile_rows(clinical_rows, cfg)
        by_id = {item["item_id"]: item for item in result["rows"]}
        for finding in compiled["blockers"]:
            item = by_id.get(finding["item_id"], {})
            engineering(item, finding["message"])
        for operation in compiled["operations"]:
            result["configuration_changes"].append({"ref": operation["path"] + "#" + operation["pointer"], "value": operation["value"]})
        for row_result in compiled["rows"]:
            by_id[row_result["item_id"]]["read_roles"] = row_result["read_roles"]
        if compiled["blockers"]:
            for row in clinical_rows:
                item = by_id[row["item_id"]]
                if item["status"] == "supported":
                    engineering(item, "Resolve the clinical compilation findings before staging this shared clinical block.")

    # Numbering is shared with cohort indexing and outcomes, never per variable.
    if family_numbering:
        warning("Treatment-line numbering is a product-wide setting used by cohort indexing, treatment and outcomes. Review its impact on every line-dependent variable.")
        if len({value for value, _item in family_numbering}) > 1:
            block({}, "Treatment-line definitions request conflicting product-wide numbering. Choose one numbering model for the product.", NUMBERING_REF)
            proposals.pop(NUMBERING_REF, None)
            for _value, item in family_numbering:
                engineering(item, "Resolve the conflicting product-wide treatment-line numbering.", NUMBERING_REF)

    if line_requests:
        required = max(line for line, _item in line_requests)
        explicit = proposals.get(MAX_LINES_REF, [])
        if explicit and any(value < required for value, _item in explicit):
            block({}, "The explicit maximum treatment line is below a reviewed output's required line. Resolve the scope conflict.", MAX_LINES_REF)
            proposals.pop(MAX_LINES_REF, None)
            for _value, item in explicit + line_requests:
                engineering(item, "Resolve the conflict between the maximum treatment line and the reviewed line outputs.", MAX_LINES_REF)
        elif required > current_max and not explicit:
            propose(MAX_LINES_REF, required, next(item for line, item in line_requests if line == required))

    for ref in sorted(proposals):
        entries = proposals[ref]
        values = []
        for value, _item in entries:
            if value not in values:
                values.append(value)
        if len(values) > 1:
            block({}, "Reviewed variables request conflicting values for " + ref + ". Resolve this setting before staging.", ref)
            for _value, item in entries:
                engineering(item, "Resolve the conflicting values for this configuration setting.", ref)
            continue
        value = entries[0][0]
        try:
            current = _normalize(_KINDS[ref], parameters[ref][2])
        except (ValueError, TypeError, OverflowError):
            current = parameters[ref][2]
        if value != current:
            result["configuration_changes"].append({"ref": ref, "value": value})
            if ref == MAX_LINES_REF:
                warning(f"Increasing treatment scope to {value} emits the engine's native line fields through that line, including attributes beyond this reviewed list.")

    # A valid scalar date is insufficient if the combined cohort interval is reversed.
    changes = {item["ref"]: item["value"] for item in result["configuration_changes"]}
    if any(ref in changes for ref in DATE_REFS):
        candidate_study = {**study, **{ref.rsplit("/", 1)[-1]: value for ref, value in changes.items() if ref in DATE_REFS}}
        issues = study_date_issues(candidate_study, before=study)
        if issues:
            for issue in issues:
                block({}, issue, START_REF)
            result["configuration_changes"] = [item for item in result["configuration_changes"] if item["ref"] not in DATE_REFS]
            for ref in DATE_REFS:
                for _value, item in proposals.get(ref, []):
                    engineering(item, " ".join(issues), ref)
    for item in result["rows"]:
        if item["item_id"] in review_blocked:
            if item["status"] == "supported":
                item["status"] = "engineering"
            item["message"] += " Resolve the current review issues before execution preparation."

    # Product metadata travels with these same candidate bytes. Existing
    # treatment-only reviews retain their legacy shared-catalogue behavior.
    if any(row.get("clinical_rule") or ((row.get("values") or {}).get("publish") or {}).get("dictionary") == "configured"
           for row in report["rows"]) or raw.get("dictionary_overlay"):
        from experiments.portal import variable_dictionary_rules
        from engine.config import load_yaml, shared_asset
        catalog_path = shared_asset(cfg.root.parents[2], "catalog")
        catalog = load_yaml(catalog_path) if catalog_path.is_file() else {"variables": []}
        by_id = {item["item_id"]: item for item in result["rows"]}
        eligible = [row for row in report["rows"] if by_id[row["item_id"]]["status"] == "supported"]
        dictionary_plan = variable_dictionary_rules.compile_rows(eligible, cfg, catalog, pack=report.get("pack"))
        for finding in dictionary_plan["blockers"]:
            engineering(by_id.get(finding["item_id"], {}), finding["message"])
        if not dictionary_plan["blockers"]:
            overlay = dictionary_plan["overlay"]
            if overlay != raw.get("dictionary_overlay") and (overlay.get("variables") or raw.get("dictionary_overlay")):
                result["configuration_changes"].append({"ref": "config/data_product.yaml#/dictionary_overlay", "value": overlay})
                warning("New dictionary entries are scoped to this product and its internal audience. Existing master audience and privacy restrictions are retained.")
    return result
