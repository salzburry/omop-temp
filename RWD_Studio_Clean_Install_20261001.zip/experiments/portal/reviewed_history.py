"""Exact reviewed product bytes, isolated from unrelated staged or shared edits."""
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

from experiments.portal import branch_workspace


def _git(root, args, *, env=None, data=None, check=True):
    result = subprocess.run(["git", "--literal-pathspecs", "-C", str(root), *args],
        input=data, capture_output=True, timeout=120, env=env,
        **({"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}))
    if check and result.returncode:
        raise ValueError("Git could not record the reviewed files. Check Git identity and file locks, then refresh this review. " + result.stderr.decode("utf-8", "replace")[-300:])
    return result


def _bytes(path):
    if path.resolve() != path or path.exists() and (not path.is_file() or path.stat().st_size > 64 * 1024 * 1024):
        raise ValueError("A pending history file is redirected, not a file or too large. Review its canonical path before recording.")
    return path.read_bytes() if path.exists() else None


def snapshot(root, pack):
    base = Path(root).resolve()
    if not isinstance(pack, str) or not re.fullmatch(r"(?:products|fixtures)/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/[0-9]{6}", pack):
        raise ValueError("Choose one canonical product before reviewing history.")
    product = base / pack
    if product.resolve() != product or not product.is_dir():
        raise ValueError("The selected product does not have a canonical directory.")
    head = _git(base, ["rev-parse", "--verify", "HEAD"], check=False).stdout.decode().strip()
    branch = _git(base, ["symbolic-ref", "--quiet", "HEAD"], check=False).stdout.decode().strip()
    if not branch:
        raise ValueError("Choose a named Git branch before recording product history.")
    creation, creation_hash = branch_workspace._creation_manifest(base, product, pack)
    shared, warnings = [], []
    for row in (creation or {}).get("files", []):
        if row["kind"] not in {"shared_registration", "generated_report"}:
            continue
        raw = _bytes(base / row["path"])
        if raw is not None and sha256(raw).hexdigest() == row["sha256"]:
            shared.append(row["path"])
        else:
            warnings.append(row["path"] + " changed after product creation and is excluded. Review its complete diff using Save work to my branch before including it.")
    paths = [pack, *shared]
    changed = _git(base, ["diff", "--no-renames", "--name-only", "-z", "HEAD", "--", *paths]).stdout if head else b""
    staged = _git(base, ["diff", "--cached", "--no-renames", "--name-only", "-z", "--", *paths]).stdout
    untracked = _git(base, ["ls-files", "--others", "--exclude-standard", "-z", "--", *paths]).stdout
    candidates = sorted({p.decode("utf-8") for p in (changed + staged + untracked).split(b"\0") if p})
    records = []
    for relative in candidates:
        if relative not in shared:
            parts = Path(relative).relative_to(pack).parts
            if any(part.startswith(".") for part in parts):
                continue
        raw = _bytes(base / relative)
        tracked = _git(base, ["cat-file", "-e", "HEAD:" + relative], check=False).returncode == 0 if head else False
        records.append({"path": relative, "sha256": sha256(raw).hexdigest() if raw is not None else None,
            "state": "deleted" if raw is None else "changed" if tracked else "new"})
    basis = {"root": str(base), "pack": pack, "head": head, "branch": branch,
        "creation_sha256": creation_hash, "records": records}
    return {**basis, "digest": sha256(json.dumps(basis, sort_keys=True).encode()).hexdigest(), "warnings": warnings}


def _commit(root, pack, message, *, expected_digest, index_path, original_index, _snapshot=None):
    """Build an isolated index from captured bytes; move the branch with compare-and-swap."""
    take_snapshot = _snapshot or snapshot
    current = take_snapshot(root, pack)
    if current["digest"] != expected_digest:
        raise ValueError("The reviewed files or branch changed. Refresh the file review before recording.")
    if not current["records"]:
        raise ValueError("Nothing of this product is pending. There is nothing to record.")
    base = Path(root).resolve()
    captured = {r["path"]: _bytes(base / r["path"]) for r in current["records"]}
    if any((sha256(captured[r["path"]]).hexdigest() if captured[r["path"]] is not None else None) != r["sha256"] for r in current["records"]):
        raise ValueError("A reviewed file changed while being read. Refresh the file review.")
    with tempfile.TemporaryDirectory(prefix="rwd-reviewed-history-") as directory:
        env = dict(os.environ, GIT_INDEX_FILE=str(Path(directory) / "index"))
        _git(base, ["read-tree", current["head"]] if current["head"] else ["read-tree", "--empty"], env=env)
        for row in current["records"]:
            relative, raw = row["path"], captured[row["path"]]
            if raw is None:
                _git(base, ["update-index", "--force-remove", "--", relative], env=env)
            else:
                blob = _git(base, ["hash-object", "-w", "--stdin"], env=env, data=raw).stdout.decode().strip()
                prior = _git(base, ["ls-files", "--stage", "--", relative], env=env).stdout.decode().strip()
                mode = prior.split()[0] if prior else "100644"
                if mode not in {"100644", "100755"}:
                    raise ValueError("Only regular reviewed files can be recorded; links and submodules need a separate review.")
                _git(base, ["update-index", "--add", "--cacheinfo", mode + "," + blob + "," + relative], env=env)
        tree = _git(base, ["write-tree"], env=env).stdout.decode().strip()
        # Keep a changed worktree pending rather than claiming its new bytes were reviewed.
        if take_snapshot(base, pack)["digest"] != expected_digest:
            raise ValueError("The files changed while preparing history. Refresh and review; no branch update was made.")
        args = ["-c", "commit.gpgsign=false", "commit-tree", tree]
        if current["head"]:
            args += ["-p", current["head"]]
        revision = _git(base, args, env=env, data=(message + "\n").encode()).stdout.decode().strip()
        _git(base, ["update-ref", "-m", message, current["branch"], revision, current["head"] or "0" * 40])
    paths = [r["path"] for r in current["records"]]
    # The real index keeps all unrelated staged entries. Failure here cannot undo
    # a successful commit; expose a receipt and never ask the user to replay it.
    notice = ""
    # The real index lock is held by commit(). Build its replacement separately,
    # starting with the exact original index so unrelated staged entries survive.
    with tempfile.TemporaryDirectory(prefix="rwd-history-index-") as directory:
        replacement = Path(directory) / "index"
        if original_index is not None:
            replacement.write_bytes(original_index)
        cleanup_env = dict(os.environ, GIT_INDEX_FILE=str(replacement))
        reset = _git(base, ["reset", "-q", revision, "--", *paths], env=cleanup_env, check=False)
        current_index = index_path.read_bytes() if index_path.exists() else None
        same_branch = _git(base, ["symbolic-ref", "--quiet", "HEAD"], check=False).stdout.decode().strip() == current["branch"]
        same_head = _git(base, ["rev-parse", "HEAD"], check=False).stdout.decode().strip() == revision
        if reset.returncode or current_index != original_index or not (same_branch and same_head):
            notice = " The commit is saved; the index or branch changed concurrently. Review the saved commit and refresh these files before another record."
        else:
            # os.replace needs a sibling on the same volume. The canonical lock
            # prevents other Git writers while the complete replacement publishes.
            sibling = index_path.with_name(index_path.name + ".rwd-refresh")
            if sibling.exists():
                notice = " The commit is saved; a prior index refresh needs inspection before another record."
            else:
                try:
                    with sibling.open("xb") as handle:
                        handle.write(replacement.read_bytes()); handle.flush(); os.fsync(handle.fileno())
                    os.replace(sibling, index_path)
                finally:
                    sibling.unlink(missing_ok=True)
    return {"commit": revision, "files": paths, "notice": notice}


def commit(root, pack, message, *, expected_digest, _snapshot=None):
    """Own Git's real index lock; all reviewed-tree work uses an isolated index."""
    base = Path(root).resolve()
    raw = _git(base, ["rev-parse", "--git-path", "index"]).stdout.decode().strip()
    index_path = Path(raw) if Path(raw).is_absolute() else base / raw
    index_path = index_path.absolute()
    if index_path.resolve() != index_path:
        raise ValueError("Git's index redirects outside its canonical path. Repair it before recording.")
    lock = index_path.with_name(index_path.name + ".lock")
    try:
        fd = os.open(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        raise ValueError("Unable to create '" + str(lock) + "': File exists. Use the Git lock controls to inspect the active or interrupted process before recording.") from None
    os.close(fd)
    try:
        original = index_path.read_bytes() if index_path.exists() else None
        return _commit(base, pack, message, expected_digest=expected_digest, index_path=index_path, original_index=original,
                       _snapshot=_snapshot)
    finally:
        lock.unlink(missing_ok=True)
