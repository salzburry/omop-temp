"""Start this checkout's portal using a validated, explicitly selected Python runtime.

The launcher never installs packages, never stops a server it did not start, and never
assumes that an HTTP health response on an occupied port belongs to this repository. A
double-click reuses the portal this launcher already started for this checkout when that
server is still alive (its receipt's process still runs streamlit for this app on that
port and answers the health check); otherwise a launch chooses an available port and
waits for the new child's own startup log and health. `--stop` stops the servers this
launcher started, `--status` lists them (2026-09-07: seven forgotten servers were found
running on one laptop, one per double-click).
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import shlex
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
import uuid
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_PORT = 8517
MAX_RECEIPT_BYTES = 65536
ENDED_RETENTION_DAYS = 30
SUPPORTED_PYTHON = ((3, 11), (3, 12), (3, 13))
SUPPORTED_PYTHON_TEXT = "Python 3.11, 3.12 or 3.13"


def _platform_error():
    if sys.platform not in {"win32", "linux"}:
        return {"ok": False, "error": "Local process ownership currently supports Windows and Linux. This operating system needs an implemented and validated process-identity adapter before local startup is supported."}
    return None


def _workspace_preflight(root, app):
    """Reject an unseeded data workspace before Streamlit can show a broken page.

    A source checkout owns its governance files.  An installed wheel does not:
    its ``--workspace`` must contain the small, destination-owned authoring
    skeleton.  Checking only the installed-app route keeps local development
    and disposable test roots unchanged while turning a later FileNotFoundError
    into an actionable startup message.
    """
    try:
        workspace = Path(root).resolve()
        application = Path(app).resolve()
        if application.is_relative_to(workspace):
            return None
    except (OSError, ValueError, TypeError):
        return "The selected authoring workspace could not be inspected. Choose a normal local directory."
    required = ("products/registry.yaml", "governance", "platform/TUMOR_TEMPLATE",
                "docs/RESEARCHER_QUICK_START.md")
    missing = [item for item in required
               if not (workspace / item).exists()]
    if missing:
            return ("The authoring workspace is not initialized. Prepare it once by copying "
                "governance, products, platform/TUMOR_TEMPLATE and docs from the bundle "
                "into the workspace, then run the launcher again. Missing: "
                + ", ".join(missing) + ".")
    return None


def setup_instructions(*, windows=None):
    """Distinguish a source authoring install from an installed application's data."""
    if not (ROOT / "pyproject.toml").is_file():
        from importlib.metadata import PackageNotFoundError, version
        try:
            wheel = f"rwd_platform-{version('rwd-platform')}-py3-none-any.whl"
        except PackageNotFoundError:
            wheel = "rwd_platform-VERSION-py3-none-any.whl"
        return ("This is an installed application; its data workspace is not a Python project. "
                "Ask your data expert to open the reviewed release directory and use the selected Python 3.11, 3.12 or 3.13 environment:\n"
                f'  python -m pip install -c experiments/portal/environment.constraints.txt "./{wheel}[portal]"\n'
                "Use the exact supplied wheel filename if it differs. Then start rwd-portal with --workspace and your data directory. "
                "The launcher never downloads or installs packages automatically.")
    windows = os.name == "nt" if windows is None else windows
    create = "py -3.13" if windows else "python3.13"
    interpreter = ".\\.venv313\\Scripts\\python.exe" if windows else "./.venv313/bin/python"
    terminal = "PowerShell" if windows else "a terminal"
    start = ("double-click Start-RwdPortal.cmd" if windows else
             "run ./.venv313/bin/python experiments/portal/launch_portal.py")
    return (f"Ask your data expert to open {terminal} in this repository and run these once:\n"
            f"  {create} -m venv .venv313\n"
            f'  {interpreter} -m pip install -c experiments/portal/environment.constraints.txt -e ".[portal]"\n'
            "The requirements include pytest for the workflow's registered regression checks.\n"
            + ("If py -3.13 is unavailable, run py -0p and use the full path of a listed Python 3.11-3.13 executable with -m venv .venv313.\n" if windows else "")
            + "To use an existing Python 3.11, 3.12 or 3.13 environment, select it in VS Code or supply --python PATH or RWD_PORTAL_PYTHON. Older environments are left untouched.\n"
            + "Use a short local checkout path outside synchronized folders. If environment creation fails, stop and repair it before installing packages.\n"
            f"Then {start}. The launcher never installs packages automatically.")


SETUP = setup_instructions()

try:
    from experiments.portal import portal_environment, local_process_lock
except ModuleNotFoundError as error:
    if __name__ != "__main__":
        raise
    problem = {"ok": False,
        "error": "This Python environment does not have the installed RWD Portal and its required dependencies.",
        "missing_module": error.name, "setup": SETUP}
    print(json.dumps(problem, indent=2) if "--json" in sys.argv else problem["error"] + "\n\n" + SETUP)
    raise SystemExit(1)

_PROBE = """import importlib.util, importlib.metadata, json, platform, re, site, sys
packages = {}
for name in json.loads(sys.argv[1]):
    try:
        packages[name] = importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        packages[name] = None
missing = []
app = None
for name in ('streamlit','yaml','anthropic','openpyxl','jsonschema','pytest',
             'sqlglot','rdflib','owlrl','pyshacl','setuptools',
             'engine','rwd_tools','rwd_services','experiments.portal.app'):
    try:
        spec = importlib.util.find_spec(name)
    except (ModuleNotFoundError, ImportError):
        spec = None
    if spec is None:
        missing.append(name)
    elif name == 'experiments.portal.app':
        app = spec.origin
# The installed wheel can declare requirements newer than the measured profile.
# Presence is required; version drift remains a separate diagnostic. Evaluate
# portal extras in this interpreter so optional deployment extras stay optional.
try:
    from packaging.requirements import Requirement
except ImportError:
    missing.append('packaging')
else:
    pending = [Requirement('rwd-platform[portal]')]
    visited = {}
    while pending:
        requirement = pending.pop()
        name = re.sub(r'[-_.]+', '-', requirement.name).lower()
        extras = set(requirement.extras) | {''}
        if name in visited and extras <= visited[name]:
            continue
        visited.setdefault(name, set()).update(extras)
        try:
            packages[name] = importlib.metadata.version(name)
            requirements = importlib.metadata.requires(name) or []
        except importlib.metadata.PackageNotFoundError:
            missing.append(name)
            continue
        for value in requirements:
            child = Requirement(value)
            if child.marker and not any(child.marker.evaluate({'extra': extra}) for extra in visited[name]):
                continue
            child.marker = None
            pending.append(child)
# These UI imports are otherwise lazy: a working health endpoint does not prove
# that a dataframe can render. Catch incomplete native/transitive dependencies
# in the same interpreter and isolation mode before starting the server.
import_errors = {}
if not missing:
    for name in ('streamlit', 'pandas', 'pyarrow'):
        try:
            importlib.import_module(name)
        except Exception as error:
            import_errors[name] = type(error).__name__ + ': ' + str(error)
snapshot_dependencies = None
if not missing and not import_errors:
    from experiments.portal import portal_environment
    snapshot_dependencies = portal_environment.snapshot_dependency_report([*visited, 'pip'])
identity_setup = None
if len(sys.argv) > 2 and not missing and not import_errors:
    try:
        from rwd_tools import approval_identity
        identity_setup = approval_identity.setup_readiness(sys.argv[2])
    except Exception as error:
        identity_setup = {'ready': False, 'why': 'Identity setup could not be checked: ' + str(error)}
print(json.dumps({'version':list(sys.version_info[:3]), 'executable':sys.executable,
    'environment': {'python':platform.python_version(), 'system':platform.system(), 'machine':platform.machine()},
    'packages':packages, 'missing':sorted(set(missing)), 'import_errors':import_errors, 'app':app,
    'isolated':bool(sys.flags.isolated), 'user_site_enabled':site.ENABLE_USER_SITE, 'identity_setup':identity_setup,
    'snapshot_dependencies':snapshot_dependencies}))
"""


def _dependency_setup(interpreter):
    """Repair the selected runtime, never rely on a launcher-only user site."""
    selected = str(interpreter)
    invocation = ("& '" + selected.replace("'", "''") + "'" if os.name == 'nt' else shlex.quote(selected))
    if (ROOT / 'pyproject.toml').is_file():
        requirement = '-e ".[portal]"'
    else:
        from importlib.metadata import PackageNotFoundError, version
        try:
            wheel = f"rwd_platform-{version('rwd-platform')}-py3-none-any.whl"
        except PackageNotFoundError:
            wheel = "rwd_platform-VERSION-py3-none-any.whl"
        requirement = f'"./{wheel}[portal]"'
    return ("The portal runs Python with -I: user-site packages and PYTHONPATH are excluded. "
            "Staged product checks also exclude system-site packages and arbitrary .pth hooks. "
            "Install into the selected environment from the source checkout or reviewed release directory:\n"
            f'  {invocation} -I -m pip --isolated install --no-user --ignore-installed -c experiments/portal/environment.constraints.txt pip {requirement}\n'
            "The ignore-installed option puts the required dependency closure in this environment even when another site reports it already satisfied. "
            "If that environment is read-only, create a virtual environment and install there, then select its Python executable.\n\n" + SETUP)


def _interpreter_candidates(root, python=None):
    """An explicit selection is authoritative; otherwise inspect local runtimes first."""
    selected = python if python is not None else os.environ.get("RWD_PORTAL_PYTHON")
    if selected is not None:
        if not str(selected).strip():
            raise ValueError("The selected Python interpreter path is empty.")
        path = Path(selected).expanduser()
        return [(path if path.is_absolute() else root / path, "selected")]
    suffix = "Scripts/python.exe" if os.name == "nt" else "bin/python"
    candidates = [(root / name / suffix, name) for name in (".venv313", ".venv")]
    # Calling this file with an already-selected supported interpreter is intentional.
    # This never searches PATH or guesses another installed Python.
    if tuple(sys.version_info[:2]) in SUPPORTED_PYTHON:
        candidates.append((Path(sys.executable), "launcher"))
    return candidates


def inspect_environment(root=ROOT, *, python=None, environ=None):
    """Validate the selected supported Python runtime without installing or replacing it."""
    if unsupported := _platform_error():
        return unsupported
    root = Path(root).resolve()
    if not root.is_dir():
        return {"ok": False, "error": "The selected authoring workspace does not exist. Choose an existing workspace directory."}
    # A data-root is an explicit managed-installation boundary.  Do not let a
    # local launcher report a healthy runtime while the configured persistent
    # volume is empty or malformed; that would fail later inside Streamlit.
    launch_env = os.environ if environ is None else environ
    data_root = launch_env.get("RWDP_DATA_ROOT")
    if data_root and launch_env.get("RWD_PORTAL_HOSTED_AUTHORING") != "1":
        try:
            from experiments.portal import installation_storage
            installation_storage.layout(data_root)
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as error:
            return {"ok": False, "error": "RWDP_DATA_ROOT is configured but is not an initialized RWD Portal installation. Run installation_storage.py init on the persistent data root or clear RWDP_DATA_ROOT before starting a local workspace."}
    try:
        candidates = _interpreter_candidates(root, python)
    except (OSError, ValueError, TypeError):
        return {"ok": False, "error": "The selected Python interpreter path is invalid.", "setup": SETUP}
    if not any(path.is_file() for path, _source in candidates):
        return {"ok": False, "error": f"The selected Python environment is missing. Choose {SUPPORTED_PYTHON_TEXT} or create .venv313.", "setup": SETUP}
    try:
        options = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
        if environ is not None:
            options['env'] = environ
        for path, source in candidates:
            if not path.is_file():
                continue
            interpreter = path.absolute()
            command = [str(interpreter), "-I", "-c", _PROBE, json.dumps(portal_environment.package_names(root))]
            if launch_env.get('RWD_PORTAL_HOSTED_AUTHORING') == '1':
                # Read managed identity state inside the same configured process
                # environment as the server, without mutating this launcher's env.
                command.append(str(root))
            result = subprocess.run(command, cwd=str(root), capture_output=True,
                                    text=True, encoding="utf-8", errors="replace", timeout=40, **options)
            probe = json.loads(result.stdout) if result.returncode == 0 else {}
            if not isinstance(probe, dict) or tuple(probe.get("version", [])[:2]) not in SUPPORTED_PYTHON:
                continue
            if probe.get("missing"):
                return {"ok": False, "error": "Required portal packages are missing from the selected isolated Python runtime: " + ", ".join(probe["missing"]),
                        "interpreter": str(interpreter), "runtime_mode": "isolated", "missing_packages": probe["missing"],
                        "setup": _dependency_setup(interpreter)}
            if probe.get("import_errors"):
                errors = probe["import_errors"]
                return {"ok": False, "error": "Required portal imports failed in the selected isolated Python runtime: " + "; ".join(f"{name}: {error}" for name, error in errors.items()),
                        "interpreter": str(interpreter), "runtime_mode": "isolated", "import_errors": errors,
                        "setup": _dependency_setup(interpreter)}
            snapshot = probe.get("snapshot_dependencies")
            if isinstance(snapshot, dict) and snapshot.get("ok") is not True:
                detail = (", ".join(snapshot.get("missing") or []) or snapshot.get("error")
                          or "The staged dependency directories could not be checked.")
                return {"ok": False, "error": "Required packages are unavailable to staged product checks: " + detail,
                        "interpreter": str(interpreter), "runtime_mode": "isolated",
                        "snapshot_dependencies": snapshot, "setup": _dependency_setup(interpreter)}
            app = Path(probe.get("app") or "")
            if not app.is_absolute() or not app.is_file() or app.parts[-3:] != ("experiments", "portal", "app.py"):
                return {"ok": False, "error": "The selected interpreter did not identify its installed portal application.", "setup": SETUP}
            # A mocked or older probe may omit its environment block.  Do not
            # run the dependency marker resolver in that case: its packaging
            # fallback can query Windows platform metadata through a shell,
            # obscuring the actual interpreter probe and making startup tests
            # depend on the host shell.
            _observed_environment = probe.get("environment")
            _environment_profile = (portal_environment.report(root, observed=probe.get("packages", {}),
                observed_environment=_observed_environment)
                if isinstance(_observed_environment, dict) else
                {"status": "unavailable", "manifest": "experiments/portal/environment.manifest.json",
                 "reason": "The selected interpreter did not report its environment metadata."})
            if _environment_profile.get("missing"):
                missing = [row["package"] for row in _environment_profile["missing"]]
                return {"ok": False, "error": "Required portal dependencies are missing from the selected environment: " + ", ".join(missing),
                        "interpreter": str(interpreter), "runtime_mode": "isolated", "missing_packages": missing,
                        "setup": _dependency_setup(interpreter),
                        "environment_profile": _environment_profile}
            return {"ok": True, "root": str(root), "interpreter": str(interpreter), "interpreter_source": source, "app": str(app),
                    "runtime_mode": "isolated",
                    "snapshot_dependencies": snapshot,
                    "identity_setup": probe.get("identity_setup"),
                    "python_version": ".".join(str(v) for v in probe["version"]),
                    "environment_profile": _environment_profile}
        return {"ok": False, "error": f"This repository requires {SUPPORTED_PYTHON_TEXT}. The selected environment is a different version or could not start.", "setup": SETUP}
    except (OSError, ValueError, TypeError, subprocess.SubprocessError):
        return {"ok": False, "error": "The repository's Python environment could not be checked.", "setup": SETUP}


def available_port(preferred=DEFAULT_PORT):
    """Choose a free loopback port; an occupied server is never inspected or reused."""
    if type(preferred) is not int or not 1 <= preferred <= 65535:
        raise ValueError("The port must be an integer between 1 and 65535.")
    for port in range(preferred, min(preferred + 50, 65536)):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
                if os.name == "nt":
                    listener.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
                listener.bind(("127.0.0.1", port))
                return port
        except OSError:
            continue
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        listener.bind(("127.0.0.1", 0))
        return listener.getsockname()[1]


def _launch_directory(root):
    # Operational logs stay outside the source and product records.
    base = Path(os.environ.get("LOCALAPPDATA") or tempfile.gettempdir()) / "RwdPortal"
    namespace = hashlib.sha256(os.path.normcase(str(root)).encode("utf-8")).hexdigest()[:12]
    path = base / namespace / "launches"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _state_directory(root):
    """Return the default private state directory for a local checkout.

    Runtime drafts, chat history and model indexes are operational state, not
    product files.  Keeping them beside the launch receipts makes the default
    launcher safe to use from a clean checkout (including a synchronized
    folder) without relying on every caller to set an environment variable.
    """
    directory = _launch_directory(root).parent / "state"
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def _start_server(command, root, log, env):
    options = ({"creationflags": subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP}
               if os.name == "nt" else {"start_new_session": True})
    return subprocess.Popen(command, cwd=str(root), stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                            env=env, **options)


def _stop_owned(process):
    """Clean up only a child created by this invocation, never a PID read from disk."""
    if process is None or process.poll() is not None:
        return
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], capture_output=True,
                       timeout=10, creationflags=subprocess.CREATE_NO_WINDOW)
    else:
        process.terminate()
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)


def _healthy(url):
    try:
        # Do not route a local health check through a configured web proxy.
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(url + "/_stcore/health", timeout=1) as response:
            return response.status == 200 and response.read(32).strip().lower() == b"ok"
    except (OSError, ValueError, urllib.error.URLError):
        return False


def _command_line(pid):
    """The live process's command line, or '' when it is gone: a pid read from a receipt is never
    trusted on its own, because the number can belong to something else by now."""
    try:
        if os.name == "nt":
            r = subprocess.run(["powershell", "-NoProfile", "-Command",
                                f"(Get-CimInstance Win32_Process -Filter 'ProcessId={int(pid)}').CommandLine"],
                               capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=20,
                               creationflags=subprocess.CREATE_NO_WINDOW)
        else:
            r = subprocess.run(["ps", "-o", "args=", "-p", str(int(pid))], capture_output=True, text=True,
                               encoding="utf-8", errors="replace", timeout=20)
        return (r.stdout or "").strip() if r.returncode == 0 else ""
    except (OSError, ValueError, TypeError, subprocess.SubprocessError):
        return ""


def _arguments(line):
    """Parse the operating system's command line without losing quoted Windows paths."""
    if not isinstance(line, str) or not line:
        return []
    try:
        if os.name != "nt":
            return shlex.split(line)
        import ctypes
        from ctypes import wintypes
        shell = ctypes.WinDLL("shell32", use_last_error=True)
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        shell.CommandLineToArgvW.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_int)]
        shell.CommandLineToArgvW.restype = ctypes.POINTER(wintypes.LPWSTR)
        kernel.LocalFree.argtypes = [wintypes.HLOCAL]
        kernel.LocalFree.restype = wintypes.HLOCAL
        count = ctypes.c_int()
        args = shell.CommandLineToArgvW(line, ctypes.byref(count))
        if not args:
            return []
        try:
            return [args[index] for index in range(count.value)]
        finally:
            kernel.LocalFree(args)
    except (OSError, ValueError):
        return []


def _same_server(line, root, port):
    args = _arguments(line)
    if len(args) > 1 and args[1] == "-I":
        args = [args[0], *args[2:]]
    if len(args) < 6 or args[1:4] != ["-m", "streamlit", "run"]:
        return False
    try:
        app = os.path.normcase(str((Path(root) / "experiments/portal/app.py").resolve()))
        if not Path(args[4]).is_absolute():
            return False
        actual_path = Path(args[4]).resolve()
        actual = os.path.normcase(str(actual_path))
        selected = os.path.normcase(str(Path(root).resolve()))
    except (OSError, ValueError):
        return False
    ports = [value for value in args[5:] if value.startswith("--server.port")]
    if ports != [f"--server.port={port}"]:
        return False
    if "--" not in args[5:]:
        # Existing source-checkout servers retain their original ownership rule.
        return actual == app
    tail = args[args.index("--", 5) + 1:]
    if len(tail) != 1 or not tail[0].startswith("--rwd-workspace=") or not tail[0].partition("=")[2]:
        return False
    try:
        requested = Path(tail[0].partition("=")[2])
        if not requested.is_absolute():
            return False
        bound = os.path.normcase(str(requested.resolve()))
    except (OSError, ValueError):
        return False
    return bound == selected and actual_path.parts[-3:] == ("experiments", "portal", "app.py")


def _identity(pid):
    try:
        return local_process_lock.process_identity(pid)
    except (OSError, ValueError):
        return None


def _verified_dead(pid):
    """Use the shared cheap OS probe; an unreadable process is not a dead one."""
    try:
        return local_process_lock._process_start(pid) is False
    except (OSError, ValueError):
        return False


def _process_commands():
    """Read candidates only. A command match never grants permission to stop it."""
    try:
        if os.name == "nt":
            result = subprocess.run(["powershell", "-NoProfile", "-Command",
                "Get-CimInstance Win32_Process -Filter \"Name LIKE 'python%'\" | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress"],
                capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=10,
                creationflags=subprocess.CREATE_NO_WINDOW)
            if result.returncode or len(result.stdout) > 1_000_000:
                return []
            rows = json.loads(result.stdout or "[]")
            rows = [rows] if isinstance(rows, dict) else rows
            return [(row.get("ProcessId"), row.get("CommandLine")) for row in rows if isinstance(row, dict)]
        rows = []
        for directory in Path("/proc").iterdir():
            if not directory.name.isdigit():
                continue
            try:
                with (directory / "cmdline").open("rb") as handle:
                    raw = handle.read(65537)
                if len(raw) <= 65536:
                    rows.append((int(directory.name), shlex.join(raw.decode().rstrip("\0").split("\0"))))
            except (OSError, UnicodeError):
                continue
        return rows
    except (OSError, ValueError, TypeError, subprocess.SubprocessError):
        return []


def unreceipted_servers(root=ROOT, *, known=()):
    """Expose a matching live app without inventing a missing launch receipt."""
    known_pids = {server["pid"] for server in known}
    # Streamlit on Windows can leave a short-lived child with the same command
    # line and port as the receipt-owned process.  The port is already
    # represented safely by the verified owner; reporting that child as a
    # second server makes status and stop look duplicated.
    known_ports = {server.get("port") for server in known if isinstance(server, dict)}
    found = []
    for pid, line in _process_commands():
        if type(pid) is not int or pid in known_pids:
            continue
        args = _arguments(line)
        ports = [value.partition("=")[2] for value in args[5:] if value.startswith("--server.port=")]
        if len(ports) != 1 or not ports[0].isdigit() or not 1 <= int(ports[0]) <= 65535:
            continue
        port = int(ports[0])
        if port in known_ports:
            continue
        identity = _identity(pid)
        if (identity and _same_server(line, root, port)
                and _same_server(_command_line(pid), root, port)
                and local_process_lock.process_alive(identity) is True):
            found.append({"pid": pid, "port": port, "url": f"http://127.0.0.1:{port}",
                          "process_identity": identity, "ownership": "receipt_missing"})
            known_pids.add(pid)
    return found


def _archive_dead_receipt(receipt, raw, data, root):
    """Move only verified-dead, exact-checkout evidence; never trust a stored log path."""
    if data.get("root") != str(root) or receipt.is_symlink():
        return
    try:
        if receipt.read_bytes() != raw:
            return
        ended = receipt.parent / "ended"
        if ended.is_symlink():
            return
        ended.mkdir(exist_ok=True)
        target = ended / receipt.name
        if target.exists():
            return
        receipt.rename(target)
        log = receipt.with_suffix(".log")
        if log.is_file() and not log.is_symlink() and not (ended / log.name).exists():
            log.rename(ended / log.name)
    except OSError:
        pass


def _prune_ended_logs(directory):
    """Retain recent diagnostics; only discard old unreferenced startup/ended files."""
    cutoff = time.time() - ENDED_RETENTION_DAYS * 86400
    for parent, suffixes in ((directory, {".log"}), (directory / "ended", {".log", ".json"})):
        if not parent.is_dir() or parent.is_symlink():
            continue
        for path in parent.iterdir():
            try:
                if (path.suffix in suffixes and path.is_file() and not path.is_symlink()
                        and path.stat().st_mtime < cutoff
                        and (parent != directory or not path.with_suffix(".json").exists())):
                    path.unlink()
            except OSError:
                continue


def _write_receipt(path, result):
    temporary = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        with temporary.open("x", encoding="utf-8") as handle:
            json.dump(result, handle, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def owned_servers(root=ROOT, *, include_unhealthy=False):
    """Verified app/port receipts, oldest first; reuse additionally requires health.

    Status and stop include an unhealthy owned process so a failed server cannot hide
    from cleanup. New receipts also bind to OS process start identity; a recycled PID
    never inherits that receipt. Legacy receipts are bound to a current identity before
    they can be stopped, without rewriting or discarding their retained evidence.
    """
    root = Path(root).resolve()
    found, seen, processes = [], set(), {}
    try:
        directory = _launch_directory(root)
    except OSError:
        return found
    _prune_ended_logs(directory)
    for receipt in sorted(directory.glob("*.json")):
        try:
            if receipt.is_symlink():
                continue
            with receipt.open("rb") as handle:
                raw = handle.read(MAX_RECEIPT_BYTES + 1)
            if len(raw) > MAX_RECEIPT_BYTES:
                continue
            data = json.loads(raw)
        except (OSError, ValueError, UnicodeError, RecursionError):
            continue
        if not isinstance(data, dict):
            continue
        pid, port, url = data.get("pid"), data.get("port"), data.get("url")
        if not (type(pid) is int and 0 < pid <= 0xFFFFFFFF and type(port) is int and 1 <= port <= 65535
                and url == f"http://127.0.0.1:{port}"):
            continue
        if (pid, port) in seen:
            continue
        recorded = data.get("process_identity")
        if recorded is not None:
            alive = local_process_lock.process_alive(recorded) if isinstance(recorded, dict) and recorded.get("pid") == pid else None
            if alive is not True:
                if alive is False:
                    _archive_dead_receipt(receipt, raw, data, root)
                continue
        if pid not in processes:
            current = _identity(pid)
            # Legacy receipts have no recorded start identity. Their dead PIDs are
            # common after laptop restarts; do not start PowerShell for each one.
            processes[pid] = (None if current is None and _verified_dead(pid)
                              else (current, _command_line(pid)))
        process = processes[pid]
        if process is None:
            _archive_dead_receipt(receipt, raw, data, root)
            continue
        current, line = process
        identity = recorded or current
        if not _same_server(line, root, port):
            continue
        healthy = _healthy(url)
        if identity is not None and local_process_lock.process_alive(identity) is not True:
            continue
        if include_unhealthy or (healthy and identity is not None):
            seen.add((pid, port))
            found.append({"pid": pid, "port": port, "url": url, "receipt": str(receipt),
                          "launch_id": str(data.get("launch_id") or receipt.stem), "mode": data.get("mode", "demo"),
                          "interpreter": _arguments(line)[0], "python_version": data.get("python_version"),
                          "health": "ok" if healthy else "unhealthy", "process_identity": identity,
                          "receipt_sha256": hashlib.sha256(raw).hexdigest()})
    return found


def stop_servers(root=ROOT, *, details=False, timeout_s=5):
    """Recheck ownership and retain the receipt until the original process is proven gone."""
    stopped, failed = [], []
    for server in owned_servers(root, include_unhealthy=True):
        identity = server.get("process_identity")
        if not identity or local_process_lock.process_alive(identity) is not True:
            failed.append({**server, "reason": "The original process identity could not be verified; it was left alone."})
            continue
        if not _same_server(_command_line(server["pid"]), root, server["port"]):
            failed.append({**server, "reason": "The process command changed; it was left alone."})
            continue
        if local_process_lock.process_alive(identity) is not True:
            failed.append({**server, "reason": "Process ownership changed before stopping; it was left alone."})
            continue
        try:
            if os.name == "nt":
                result = subprocess.run(["taskkill", "/PID", str(server["pid"]), "/T", "/F"], capture_output=True, timeout=15,
                                        creationflags=subprocess.CREATE_NO_WINDOW)
                if result.returncode != 0:
                    raise OSError("The process stop command did not succeed.")
            else:
                import signal  # noqa: PLC0415
                os.kill(server["pid"], signal.SIGTERM)
        except (OSError, subprocess.SubprocessError):
            failed.append({**server, "reason": "Stopping failed; the receipt was preserved for retry."})
            continue
        deadline = time.monotonic() + timeout_s
        while local_process_lock.process_alive(identity) is not False:
            if time.monotonic() >= deadline:
                failed.append({**server, "reason": "Termination could not be confirmed; the receipt was preserved for retry."})
                break
            time.sleep(0.1)
        else:
            stopped.append(server)
            try:
                receipt = Path(server["receipt"])
                # A replacement receipt is not this stop's evidence to remove.
                if not receipt.is_symlink() and receipt.stat().st_size <= MAX_RECEIPT_BYTES:
                    if hashlib.sha256(receipt.read_bytes()).hexdigest() == server["receipt_sha256"]:
                        receipt.unlink()
            except OSError:
                pass
    return {"ok": not failed, "stopped": stopped, "failed": failed} if details else stopped


def _ready(process, url, log_path, timeout_s):
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        if process.poll() is not None:
            return False
        try:
            # A free-port probe has a race. The new child's own successful bind
            # message must appear before a health response can establish readiness.
            started = any(line.strip().endswith("URL: " + url)
                          for line in log_path.read_text(encoding="utf-8", errors="replace").splitlines())
        except OSError:
            started = False
        if started and _healthy(url) and process.poll() is None:
            return True
        time.sleep(0.2)
    return False


def launch(root=ROOT, *, preferred_port=DEFAULT_PORT, no_browser=False, check_only=False, timeout_s=40, reuse=True, demo=False, python=None):
    if unsupported := _platform_error():
        return unsupported
    if not isinstance(timeout_s, (int, float)) or not 1 <= timeout_s <= 120:
        return {"ok": False, "error": "The readiness timeout must be between 1 and 120 seconds."}
    options = dict(preferred_port=preferred_port, no_browser=no_browser, check_only=check_only,
                   timeout_s=timeout_s, reuse=reuse, demo=demo, python=python)
    if not reuse or check_only:
        return _launch(root, **options)
    # A receipt appears only after health is established. Serialize the default
    # inspect/reuse/start sequence so two double-clicks cannot both create servers.
    try:
        directory = _launch_directory(Path(root).resolve())
    except OSError as error:
        location = str(getattr(error, "filename", "") or "unavailable")
        return {"ok": False, "error": f"The local launch directory {location} could not be created or written: {error.strerror or error}. Check its permissions and available disk space.",
                "launch_directory": location}
    deadline = time.monotonic() + timeout_s
    while True:
        try:
            guard = local_process_lock.locked(directory / "launcher.lock", directory)
            guard.__enter__()
        except OSError as error:
            return {"ok": False, "error": f"The local launch directory {directory} could not be written: {error}. Check its permissions and available disk space.",
                    "launch_directory": str(directory)}
        except ValueError as error:
            state = local_process_lock.lock_status(directory / "launcher.lock", directory)
            # The first launcher may finish between failed acquisition and this
            # inspection. A now-released lock is a reason to retry, not an error.
            if state["state"] in {"active", "absent", "dead"} and time.monotonic() < deadline:
                time.sleep(0.1)
                continue
            detail = ("Another portal launch is in progress. Its startup wait expired; retry after it finishes."
                      if state["state"] == "active" else
                      "The launcher lock is unreadable or its owner cannot be verified. Waiting will not repair it; ask your data expert to inspect its contents and local process ownership before repairing it.")
            return {"ok": False, "error": f"{detail} Lock: {directory / 'launcher.lock'}. {error}",
                    "launch_directory": str(directory)}
        break
    try:
        return _launch(root, **options)
    except (OSError, ValueError) as error:
        return {"ok": False, "error": f"The portal launch check failed: {error}. Inspect the launch directory {directory} before retrying.",
                "launch_directory": str(directory)}
    finally:
        guard.__exit__(None, None, None)


def _launch(root=ROOT, *, preferred_port=DEFAULT_PORT, no_browser=False, check_only=False, timeout_s=40, reuse=True, demo=False, python=None):
    checked = inspect_environment(root, python=python) if python is not None else inspect_environment(root)
    if not checked["ok"]:
        return checked
    if workspace_error := _workspace_preflight(root, checked.get("app", "")):
        return {"ok": False, "error": workspace_error, "root": str(Path(root).resolve()),
                "app": checked.get("app"), "interpreter": checked.get("interpreter")}
    try:
        if not isinstance(timeout_s, (int, float)) or not 1 <= timeout_s <= 120:
            return {"ok": False, "error": "The readiness timeout must be between 1 and 120 seconds."}
        if reuse and not check_only:
            owned = owned_servers(checked["root"], include_unhealthy=True)
            running = [server for server in owned
                       if server.get("mode", "demo") == ("demo" if demo else "local")]
            if running:
                live = running[-1]
                selected_path = os.path.normcase(os.path.abspath(checked["interpreter"]))
                live_path = os.path.normcase(os.path.abspath(live.get("interpreter", "")))
                recorded_version = str(live.get("python_version") or "")
                selected_version = str(checked.get("python_version") or "")
                try:
                    compatible_version = bool(recorded_version and selected_version
                        and recorded_version.split(".")[:2] == selected_version.split(".")[:2]
                        and tuple(int(part) for part in recorded_version.split(".")[:2]) in SUPPORTED_PYTHON)
                except (TypeError, ValueError):
                    compatible_version = False
                if (live_path != selected_path
                        or (recorded_version and not compatible_version)):
                        return {"ok": False, "error": f"The portal at {live['url']} is running with a different Python environment. Run the launcher with --stop, then start it with your selected {SUPPORTED_PYTHON_TEXT} interpreter. No server was reused or changed.", "running": running}
                if live.get("health") == "unhealthy":
                    health_deadline = time.monotonic() + min(timeout_s, 3)
                    while not _healthy(live["url"]) and time.monotonic() < health_deadline:
                        time.sleep(0.2)
                    if not _healthy(live["url"]):
                        return {"ok": False, "error": f"Your portal on {live['url']} (process {live['pid']}) is not responding. Run the launcher with --stop, then launch again. Use --new only if you explicitly need another server.",
                                "running": running}
                    if (not live.get("process_identity")
                            or local_process_lock.process_alive(live["process_identity"]) is not True
                            or not _same_server(_command_line(live["pid"]), checked["root"], live["port"])):
                        return {"ok": False, "error": f"The portal process on {live['url']} changed while waiting for health. Inspect its current ownership before retrying; no server was reused or started."}
                result = {**checked, "port": live["port"], "url": live["url"], "check_only": False, "reused": True,
                          "pid": live["pid"], "launch_id": live["launch_id"], "receipt": live["receipt"], "health": "ok",
                          "browser_opened": False, "preferred_port_busy": live["port"] != preferred_port,
                          "validation": "An already running portal server was reused; nothing new was started."}
                if not no_browser:
                    try:
                        result["browser_opened"] = bool(webbrowser.open(live["url"], new=2))
                    except (OSError, webbrowser.Error):
                        result["browser_opened"] = False
                return result
            missing = unreceipted_servers(checked["root"], known=owned)
            if missing:
                locations = ", ".join(f"{server['url']} (process {server['pid']})" for server in missing)
                return {"ok": False, "error": f"This checkout is already running at {locations}, but its launch receipt is missing or unreadable. No duplicate was started. Ask your data expert to inspect the named process; --stop cannot claim ownership from a missing receipt. Use --new only to request a separate server.",
                        "unreceipted": missing}
        port = available_port(preferred_port)
        url = f"http://127.0.0.1:{port}"
        result = {**checked, "port": port, "url": url, "check_only": check_only,
                  "preferred_port_busy": port != preferred_port, "mode": "demo" if demo else "local"}
        if check_only:
            return result
        root = Path(checked["root"])
        directory = _launch_directory(root)
        launch_id = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8]
        log_path = directory / (launch_id + ".log")
        receipt = directory / (launch_id + ".json")
        from experiments.portal.theme import streamlit_arguments
        command = [checked["interpreter"], "-I", "-m", "streamlit", "run", checked["app"],
                   "--server.address=127.0.0.1", f"--server.port={port}", "--server.headless=true",
                   "--browser.gatherUsageStats=false", "--server.fileWatcherType=none", *streamlit_arguments(),
                   "--", "--rwd-workspace=" + str(root.resolve())]
        env = dict(os.environ, RWD_PORTAL_LOCAL_WORKSPACE="0" if demo else "1",
                   RWD_PORTAL_LOCAL_DEMO="1" if demo else "0", PYTHONUTF8="1", PYTHONUNBUFFERED="1",
                   RWDP_STATE_DIR=os.environ.get("RWDP_STATE_DIR") or str(_state_directory(root)),
                   RWD_PORTAL_WORKSPACE_ROOT=str(root.resolve()), RWD_PORTAL_PYTHON=checked["interpreter"], PYSPARK_PYTHON=checked["interpreter"],
                   PYSPARK_DRIVER_PYTHON=checked["interpreter"])
        # a JDK unpacked under the person's application-data folder lets the synthetic build run;
        # only the server's own environment carries it (no PATH or registry change, 2026-09-07)
        try:
            from rwd_tools import java_home  # noqa: PLC0415
            found = java_home.discover()
            if found and found != env.get("JAVA_HOME"):
                env["JAVA_HOME"] = found
                env["PATH"] = str(Path(found) / "bin") + os.pathsep + env.get("PATH", "")
            elif env.get("JAVA_HOME") and not java_home._valid(env["JAVA_HOME"]):
                # A moved/uninstalled JDK must not override Java discovered on PATH.
                # Only the child's environment changes; valid explicit settings remain.
                env.pop("JAVA_HOME", None)
        except Exception:  # noqa: BLE001 - the launcher never fails on the optional runtime
            pass
        process = None
        try:
            with log_path.open("wb") as log:
                process = _start_server(command, root, log, env)
            if not _ready(process, url, log_path, timeout_s):
                _stop_owned(process)
                return {"ok": False, "error": "The new portal server did not become ready. Your existing servers were left running.",
                        "log": str(log_path), "url": url}
            result.update({"pid": process.pid, "process_identity": _identity(process.pid),
                           "log": str(log_path), "receipt": str(receipt),
                           "launch_id": launch_id, "health": "ok", "browser_opened": False,
                           "validation": "Server startup and health only; product workflows need their own checks."})
            _write_receipt(receipt, result)
            if not no_browser:
                try:
                    result["browser_opened"] = bool(webbrowser.open(url, new=2))
                except (OSError, webbrowser.Error):
                    result["browser_opened"] = False
            return result
        except (OSError, ValueError, subprocess.SubprocessError):
            _stop_owned(process)
            return {"ok": False, "error": "The local portal could not start. Your existing servers were left running.", "log": str(log_path)}
    except (OSError, ValueError, TypeError):
        return {"ok": False, "error": "No usable local port or launch-log directory was available. Ask your data expert to check this machine."}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", metavar="PATH", help="Authoring workspace containing governance files and products; application code comes from the installed package. Required when using an installed launcher outside a source workspace.")
    parser.add_argument("--python", metavar="PATH", help=f"Use this {SUPPORTED_PYTHON_TEXT} executable; otherwise use RWD_PORTAL_PYTHON, .venv313, .venv, or the current supported launcher interpreter, in that order. An explicit selection never falls back.")
    parser.add_argument("--check-only", action="store_true", help="Check this environment and port availability without starting a server.")
    parser.add_argument("--doctor", action="store_true", help="Compare this checkout's Python dependencies with the measured manifest, without starting a server or installing anything.")
    parser.add_argument("--no-browser", action="store_true", help="Start the server without opening a browser.")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT, help="Preferred local port; a busy port is left alone and another is selected.")
    parser.add_argument("--timeout", type=float, default=40, help="Seconds to wait for the new server's startup and health.")
    parser.add_argument("--json", action="store_true", help="Print structured launch evidence for diagnostics.")
    parser.add_argument("--status", action="store_true", help="List the portal servers this launcher started that are still running, and exit.")
    parser.add_argument("--stop", action="store_true", help="Stop the portal servers this launcher started (no other process is touched), and exit.")
    parser.add_argument("--new", action="store_true", help="Start another server even when one this launcher started is still running.")
    parser.add_argument("--demo", action="store_true", help="Use synthetic rehearsal identities instead of the normal local Git workspace.")
    args = parser.parse_args(argv)
    if args.workspace is None and not (ROOT / "platform/tools").is_dir():
        parser.error("The installed launcher needs --workspace PATH to the authoring workspace.")
    root_args = {"root": Path(args.workspace).expanduser().resolve()} if args.workspace else {}
    if args.doctor:
        result = inspect_environment(**root_args, python=args.python) if args.python is not None else inspect_environment(**root_args)
        profile = result.get("environment_profile", {})
        if args.json:
            print(json.dumps(result, indent=2))
        elif not result["ok"]:
            print(result["error"])
            print(result.get("setup", ""))
        else:
            print("Measured environment: " + profile.get("status", "unavailable"))
            print("Selected interpreter: " + result.get("interpreter", "unavailable"))
            print("Portal application: " + result.get("app", "unavailable"))
            for row in profile.get("missing", []) + profile.get("mismatched", []):
                print(f"  {row['package']}: expected {row['expected']}; observed {row['observed'] or 'missing'}")
            if profile.get("expected_runtime") != profile.get("observed_runtime"):
                print("  Runtime expected: " + json.dumps(profile.get("expected_runtime")))
                print("  Runtime observed: " + json.dumps(profile.get("observed_runtime")))
            if profile.get("requirements_changed"):
                print("  The declared requirements changed after this profile was measured.")
            print(profile.get("reason", profile.get("notice", "")))
        return 0 if result["ok"] and profile.get("status") == "matched" else 1
    if args.status or args.stop:
        result = stop_servers(**root_args, details=True) if args.stop else {"ok": True, "running": owned_servers(**root_args, include_unhealthy=True)}
        servers = result["stopped" if args.stop else "running"]
        missing = unreceipted_servers(**root_args, known=servers + result.get("failed", []))
        if missing:
            result["unreceipted"] = missing
            if args.stop:
                result["ok"] = False
        if args.json:
            print(json.dumps(result, indent=2))
        elif not servers and not result.get("failed") and not missing:
            print("No portal server started by this launcher is running." if args.status
                  else "No portal server started by this launcher was running; nothing was stopped.")
        else:
            for server in servers:
                print(("Stopped " if args.stop else "Running: ") + server["url"] + f" (process {server['pid']})"
                      + (" [unhealthy]" if not args.stop and server.get("health") == "unhealthy" else ""))
            for server in result.get("failed", []):
                print(f"Could not confirm stopping process {server['pid']}: {server['reason']}")
            for server in missing:
                print(f"This checkout is running at {server['url']} (process {server['pid']}), but its launch receipt is missing or unreadable. Inspect this process with your data expert; no ownership or stop permission was inferred.")
        return 0 if result["ok"] else 1
    print(f"Checking the selected {SUPPORTED_PYTHON_TEXT} environment...", flush=True) if not args.json else None
    result = launch(**root_args, preferred_port=args.port, no_browser=args.no_browser, check_only=args.check_only, timeout_s=args.timeout, reuse=not args.new, demo=args.demo, python=args.python)
    if args.json:
        print(json.dumps(result, indent=2))
    elif result["ok"]:
        if result.get("environment_profile", {}).get("status") in {"mismatch", "unavailable"}:
            print("Dependency metadata differs from the measured setup or is unavailable. Use --doctor --json for expected/observed details; portal startup continues.")
        if result.get("interpreter"):
            print("Using Python: " + result["interpreter"])
        if result.get("app"):
            print("Portal code: " + result["app"])
        if result.get("reused"):
            print("The portal is already running from an earlier launch. Opening it again: " + result["url"])
            print("To stop it, run the launcher with --stop.")
            return 0
        if result.get("preferred_port_busy"):
            print(f"Port {args.port} is in use. Existing servers were left alone; selected port {result['port']}.")
        print(("Setup is ready. Available URL: " if args.check_only else "Portal server is ready: ") + result["url"])
        if result.get("log"):
            print("Startup log: " + result["log"])
        if not args.check_only and not args.no_browser and not result.get("browser_opened"):
            print("The browser could not open automatically. Open the URL above.")
    else:
        print(result["error"])
        if result.get("setup"):
            print("\n" + result["setup"])
        if result.get("log"):
            print("Startup log: " + result["log"])
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
