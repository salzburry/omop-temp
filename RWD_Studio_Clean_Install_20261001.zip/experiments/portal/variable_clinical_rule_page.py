"""Guided edits for native clinical calculations; returns proposals, never writes."""
from __future__ import annotations

from copy import deepcopy
from engine.record_windows import read_window, window_days, window_fields, RecordWindow

import pandas as pd
import streamlit as st

from experiments.portal import variable_review_controls as controls
from experiments.portal import variable_clinical_value_page
from experiments.portal import form_assistance
from experiments.portal.variable_review_values_page import _table_basis, _table_saved
from experiments.portal.variable_review_consistency import canonical_type


TEMPLATES = {
    "": ("", "", "No clinical calculation selected"),
    "characteristic": ("categorical", "categorical", "Patient characteristic · categories"),
    "biomarker": ("panel_categories", "biomarker", "Biomarker · categories"),
    "biomarker_ranges": ("panel_bands", "biomarker", "Biomarker · number ranges"),
    "lab_categories": ("panel_categories", "laboratory", "Measurement · categories"),
    "lab_groups": ("panel_bands", "laboratory", "Measurement · number ranges"),
    "lab_value": ("lab_value", "laboratory", "Measurement · numeric result and date"),
    "response": ("panel_categories", "response", "Recorded response · categories"),
    "response_ranges": ("panel_bands", "response", "Recorded response · number ranges"),
    "ecog": ("baseline_ecog", "performance_status", "Performance status · baseline ECOG"),
    "risk_score": ("risk_score", "risk_score", "Risk score · component points and categories"),
    "serial_marker": ("serial_marker", "serial_marker", "Serial measurements · confirmed change"),
    "rt_course": ("rt_course", "rt_course", "Radiotherapy · courses and dates"),
    "dose_exposure": ("dose_exposure", "dose_exposure", "Drug administrations · dose exposure"),
    "modality_relation": ("modality_relation", "modality_relation", "Dated episodes · relationship"),
    "value_in_window": ("value_in_window", "value_in_window", "Value in a time window · any date anchor"),
    "time_to_event": ("time_to_event", "time_to_event", "Time to an event · events and censoring"),
    "custom": ("custom", "custom", "Another clinical calculation"),
}
RESULTS = {"label": "Category name", "code": "Category number", "value": "Measured number",
           "date": "Selected record's date", "flag": "Whether a result is available"}


def _choose(label, current, choices, key, permitted):
    choices = dict(choices)
    if current and current not in choices:
        choices[current] = "Keep saved choice: " + str(current)
    return st.selectbox(label, list(choices), index=list(choices).index(current) if current in choices else None,
        format_func=lambda value: choices[value], placeholder="Choose an answer", key=key,
        disabled=not permitted) or ""


def _grid(rows, key, permitted, columns, *, numeric=(), boolean=()):
    """Keep one input basis while Streamlit applies the editor's accumulated diffs."""
    frame = pd.DataFrame(_table_basis(key, rows), columns=list(columns))
    for name in numeric:
        frame[name] = pd.to_numeric(frame[name], errors="coerce").astype("float64")
    for name in boolean:
        frame[name] = frame[name].fillna(False).astype(bool)
    edited = st.data_editor(frame, key=key + "_table_widget", num_rows="dynamic", hide_index=True,
        width="stretch", disabled=not permitted, column_config=columns)
    return _table_saved(key, edited)


def _advanced_mapping(items, allowed, *, bands=False):
    for item in items:
        if not isinstance(item, dict) or set(item) - allowed:
            return True
        if bands and ("min" in item and "min_excl" in item or "max" in item and "max_excl" in item):
            return True
        if not bands and "from_equals_ci" in item and not isinstance(item["from_equals_ci"], list):
            return True
        if item.get("when") and (set(item) - {"label", "code", "when"} or item["when"] not in {"missing", "fallthrough"}):
            return True
    return False


def _mapping(rule, typed, key, permitted, *, bands=False):
    """Display native mappings explicitly; never turn an unreviewed label into code."""
    items = rule.get("bands" if bands else "groups") or []
    allowed = {"label", "code", "min", "min_excl", "max", "max_excl", "when"} if bands else {"label", "code", "from_equals_ci", "when"}
    if _advanced_mapping(items, allowed, bands=bands):
        st.caption("This saved mapping has advanced or incomplete matching rules. Its complete details are preserved; review them in Configuration before execution.")
        st.json(items)
        return deepcopy(items)
    if bands:
        rows = []
        for item in rule.get("bands") or []:
            rows.append({"label": item.get("label", ""), "code": item.get("code"),
                "lower": item.get("min", item.get("min_excl")), "upper": item.get("max", item.get("max_excl")),
                "include_lower": "min" in item, "include_upper": "max" in item,
                "otherwise": item.get("when") == "fallthrough"})
        if not rows and typed and typed.get("kind") == "bands":
            rows = [{"label": item.get("label", ""), "code": None,
                "lower": item.get("lower"), "upper": item.get("upper"),
                "include_lower": item.get("lower_inclusive", False),
                "include_upper": item.get("upper_inclusive", False), "otherwise": False}
                for index, item in enumerate(typed.get("bands") or [])]
        rows = rows or [{"label": "", "code": None, "lower": None, "upper": None,
                        "include_lower": True, "include_upper": False, "otherwise": False}]
        edited = _grid(rows, key, permitted, {
                "label": st.column_config.TextColumn("Category name"),
                "code": st.column_config.NumberColumn("Category number", step=1),
                "lower": st.column_config.NumberColumn("From"), "upper": st.column_config.NumberColumn("To"),
                "include_lower": st.column_config.CheckboxColumn("Include From"),
                "include_upper": st.column_config.CheckboxColumn("Include To"),
                "otherwise": st.column_config.CheckboxColumn("All other values")},
            numeric=("code", "lower", "upper"), boolean=("include_lower", "include_upper", "otherwise"))
        result = []
        for item in edited:
            if not item.get("label") and all(item.get(name) is None for name in ("code", "lower", "upper")) and not item.get("otherwise"):
                continue
            record = {"label": str(item.get("label") or ""), "code": item.get("code")}
            if type(record["code"]) is float and record["code"].is_integer():
                record["code"] = int(record["code"])
            if item.get("otherwise"):
                record["when"] = "fallthrough"
            else:
                if item.get("lower") is not None:
                    record["min" if item.get("include_lower") else "min_excl"] = item["lower"]
                if item.get("upper") is not None:
                    record["max" if item.get("include_upper") else "max_excl"] = item["upper"]
            result.append(record)
        return result
    rows = []
    for group in rule.get("groups") or []:
        rows.append({"input": "\n".join(str(v) for v in group.get("from_equals_ci", [])),
            "label": group.get("label", ""), "code": group.get("code"),
            "special": group.get("when", "")})
    if not rows and typed and typed.get("codes"):
        rows = [{"input": str(item.get("code", "")), "label": item.get("label", ""),
                 "code": item.get("code") if type(item.get("code")) is int else None, "special": ""} for item in typed["codes"]]
    rows = rows or [{"input": "", "label": "", "code": None, "special": ""}]
    edited = _grid(rows, key, permitted, {
            "input": st.column_config.TextColumn("Source value(s), one per line"),
            "label": st.column_config.TextColumn("Category name"),
            "code": st.column_config.NumberColumn("Category number", step=1),
            "special": st.column_config.SelectboxColumn("Special case", options=["", "missing", "fallthrough"])}, numeric=("code",))
    result = []
    for item in edited:
        if not any(item.get(name) for name in ("input", "label", "special")) and item.get("code") is None:
            continue
        record = {"label": str(item.get("label") or ""), "code": item.get("code")}
        if type(record["code"]) is float and record["code"].is_integer():
            record["code"] = int(record["code"])
        if item.get("special"):
            record["when"] = item["special"]
        else:
            record["from_equals_ci"] = [line.strip() for line in str(item.get("input") or "").splitlines() if line.strip()]
        result.append(record)
    return result


def ecog_source_compatible(source, choice):
    """A shortcut may fill an empty mapping, never replace a different binding."""
    expected = (choice or {}).get("source") or {}
    source = source or {}
    if not (choice or {}).get("ready") or not expected:
        return False
    for name in ("kind", "logical_table", "physical_stem"):
        if source.get(name) and str(source[name]).casefold() != str(expected.get(name, "")).casefold():
            return False
    columns = source.get("columns") or {}
    if not isinstance(columns, dict):
        return False
    if any(str(value).casefold() != str(expected["columns"].get(name, "")).casefold()
           for name, value in columns.items() if value):
        return False
    return not any(source.get(name) for name in ("value", "parameters", "dependencies"))


def _ecog_summary(rule, source):
    lo, hi = window_days(rule)
    st.write("**ECOG on the index date**" if [lo, hi] == [0, 0] else f"**Nearest ECOG from day {lo} through day {hi} of index**")
    policy = ("Worse grade first, then earlier date" if rule["equidistant"] == "worst_value" else
              "Earlier date first" if rule["tie_break"] == "earliest_date" else "Later date first")
    st.caption(read_window(rule).describe() + ". Equal-distance records: " + policy + ". Same-date records: worse grade.")
    st.write("Grades and delivered codes: " + "; ".join(f"{grade} → {code}" for grade, code in rule["value_codes"].items()))
    st.caption(f"No eligible record: {rule['missing_label']} → {rule['missing_code']}. "
               "A present record without a usable grade is Unknown. "
               f"Unlisted numeric grades keep their grade label and use code {rule['missing_code']}. "
               "Outputs: ecog (name), ecogn (number).")
    columns = source["columns"]
    st.caption("Configured source: " + source["physical_stem"] + " · patient: " + columns["patientid"] +
               " · grade: " + columns["ecogvalue"] + " · assessment date: " + columns["ecogdate"] +
               ". Source review and live-data checks remain separate.")


def _ecog_compact(row, rule, choice, *, key, permitted, shared_values, typed_value):
    from experiments.portal import variable_clinical_rules as rules
    if not choice or not choice.get("ready") or not ecog_source_compatible((row.get("values") or {}).get("source"), choice):
        return None
    if st.session_state.get(key + "details"):
        return None
    try:
        complete = not rules.issues({"clinical_rule": rule})
    except ValueError:
        complete = False
    accepted = st.session_state.get(key + "accepted", False)
    # Partial custom choices cannot be replaced merely by opening the editor.
    if not complete and not accepted and set(rule) - {"version", "operator", "family"}:
        return None
    base = deepcopy(choice["rule"])
    selected = deepcopy(rule if complete or accepted else base)
    if not complete and not accepted:
        _ecog_summary(selected, choice["source"])
        st.caption("Reuse the settings shown above, or keep the same codes and tie policy but require an assessment on index day. This changes only your draft.")
        product_button, index_button = st.columns(2)
        use_product = product_button.button("Use product ECOG rule", key=key + "use_product", disabled=not permitted)
        use_index = index_button.button("Use ECOG on index day", key=key + "use_index", disabled=not permitted)
        if use_product or use_index:
            selected = base
            selected["result"] = ""
            if use_index:
                selected.pop("window", None)
                selected["window_days"] = [0, 0]
            st.session_state[key + "accepted"] = True
            st.session_state[key + "source"] = deepcopy(choice["source"])
            st.session_state[key + "rule"] = deepcopy(selected)
            # Defer the next controls until the new basis is visible together.
            st.rerun()
        if st.button("Edit ECOG details", key=key + "edit", disabled=not permitted):
            st.session_state[key + "details"] = True
            st.rerun()
        return {"clinical_rule": rule}
    selected = deepcopy(st.session_state.get(key + "rule") or selected)
    selected["result"] = _choose("Value to deliver", selected.get("result"),
        {"label": "ECOG grade name (ecog)", "code": "ECOG grade number (ecogn)"}, key + "result", permitted)
    window_basis = st.session_state.setdefault(key + "window_basis_v2", window_fields(selected))
    window_options = {"keep": "Keep this row's window " + str(window_days(window_basis)),
                      "product": "Use the product window " + str(window_days(base)),
                      "index": "On index date only [0, 0]"}
    window_choice = st.selectbox("Assessment window", list(window_options), format_func=window_options.get,
        key=key + "window", disabled=not permitted)
    selected.pop("window", None)
    selected.pop("window_days", None)
    selected.update(deepcopy({"keep": window_basis, "product": window_fields(base),
                              "index": {"window_days": [0, 0]}}[window_choice]))
    _ecog_summary(selected, choice["source"])
    if st.button("Edit ECOG details", key=key + "edit", disabled=not permitted):
        st.session_state[key + "details"] = True
        st.session_state[key + "rule"] = deepcopy(selected)
        st.rerun()
    st.session_state[key + "rule"] = deepcopy(selected)
    updates = rules.scientific_updates(selected)
    if st.session_state.get(key + "source"):
        pending_source = st.session_state[key + "source"]
        if pending_source != choice["source"]:
            updates["_ui_issues"] = ["The configured ECOG mapping changed. Reload the current row before saving these choices."]
        else:
            updates["_ecog_source"] = deepcopy(pending_source)
    expected = next((item for item in rules.emitted_columns(selected) if item["result"] == selected.get("result")), None)
    if expected:
        st.info("Required result type: " + controls.TYPE_LABELS.get(expected["type"], expected["type"]) + " (" + expected["type"] + ").")
        actual_type = (typed_value or {}).get("data_type") or (((row.get("values") or {}).get("output") or {}).get("type"))
        if actual_type and canonical_type(actual_type) != expected["type"] and not shared_values:
            updates.setdefault("_ui_issues", []).append("Choose " + expected["type"] + " in the value editor to agree with this calculation.")
    for issue in rules.issues({"clinical_rule": selected}):
        st.caption(issue)
    return updates


def _window_editor(rule, *, key, permitted):
    try:
        if "window" in rule:
            previous = RecordWindow(**rule["window"])
            if "window_days" in rule or previous.anchor != "index_date" or previous.unit != "day":
                raise ValueError("Review the conflicting window or unsupported anchor in this saved calculation.")
        else:
            lower, upper = rule.get("window_days", [None, None])
            previous = RecordWindow("index_date", lower, upper, "day", True, True)
        if any(value is not None and type(value) is not int for value in (previous.start, previous.end)):
            raise ValueError("Saved window boundaries must be whole days.")
        if any(type(value) is not bool for value in (previous.include_start, previous.include_end)):
            raise ValueError("Saved boundary choices must be true or false.")
    except (TypeError, ValueError) as exc:
        st.error(str(exc))
        if st.button("Replace this window", key=key + "replace_window", disabled=not permitted):
            rule.pop("window", None)
            rule.pop("window_days", None)
        else:
            return
        previous = None
    previous = previous or RecordWindow("index_date", None, None, "day", True, True)
    st.caption("Anchor: this cohort's index date. These day settings apply only to this calculation.")
    left, right = st.columns(2)
    lower = left.number_input("Days from index · earliest", value=previous.start, step=1,
        key=key + "lower", disabled=not permitted)
    upper = right.number_input("Days from index · latest", value=previous.end, step=1,
        key=key + "upper", disabled=not permitted)
    boundaries = {"both": (True, True), "start": (True, False), "end": (False, True), "neither": (False, False)}
    labels = {"both": "Include both boundary dates", "start": "Include start, exclude end",
              "end": "Exclude start, include end", "neither": "Exclude both boundary dates"}
    initial = next(k for k, v in boundaries.items() if v == (previous.include_start, previous.include_end))
    selected = st.selectbox("Boundary dates", list(boundaries), index=list(boundaries).index(initial),
        format_func=labels.get, key=key + "bounds", disabled=not permitted)
    include_start, include_end = boundaries[selected]
    # Keep existing inclusive drafts byte-compatible. A new or exclusive rule uses
    # the explicit shape; mere page rendering does not migrate saved evidence.
    if "window_days" in rule and selected == "both":
        rule["window_days"] = [lower, upper]
    else:
        rule.pop("window_days", None)
        rule["window"] = RecordWindow("index_date", lower, upper, "day", include_start, include_end).document()
    st.caption("Negative days are before index; positive days are after. Blank means no bound. Calendar months need a separate rule.")


def render(row, *, key, permitted, typed_value=None, shared_values=False, ecog_choice=None):
    from experiments.portal import variable_clinical_rules as rules
    saved = deepcopy(row.get("clinical_rule") or {})
    initial = next((name for name, (op, family, _label) in TEMPLATES.items()
                    if op == saved.get("operator") and family == saved.get("family")), "")
    templates = dict(TEMPLATES)
    if saved and not initial:
        initial = "saved_advanced"
        templates[initial] = (saved.get("operator", ""), saved.get("family", ""), "Keep the saved clinical calculation")
    drafts = deepcopy(st.session_state.get(key + "drafts", {}))
    with st.expander("Choose how this clinical value is prepared", expanded=bool(saved or st.session_state.get(key + "template"))):
        st.caption("Optional calculation templates for this variable. Choosing a template does not add a variable or supply patient data.")
        chosen = form_assistance.field(st.selectbox, "Clinical calculation", list(templates), index=list(templates).index(initial),
            format_func=lambda name: templates[name][2], key=key + "template", disabled=not permitted)
        if not chosen:
            had_rule = bool(saved or drafts)
            if saved or drafts:
                st.session_state[key + "drafts"] = {}
                st.session_state[key + "cleared"] = True
                for name in list(st.session_state):
                    if any(name.startswith(key + template) for template in templates if template):
                        st.session_state.pop(name, None)
            return {"clinical_rule": {}} if had_rule else {}
        if chosen == "saved_advanced":
            st.info("This saved calculation needs advanced review. Its complete rule is kept until you select a replacement or clear the calculation.")
            st.json(saved)
            return {"clinical_rule": saved}
        operator, family, _label = templates[chosen]
        from rwd_tools import review_capability_registry
        support = review_capability_registry.status(operator, family)
        if support["supported"]:
            st.caption(support["message"])
        else:
            st.info(support["message"])
        if operator == "baseline_ecog":
            st.caption("ECOG grades come from your linked source table. Edit their output codes below and choose which dated assessment counts as baseline.")
        # A different template begins with only compatible controls. Stale hidden
        # selectors must not become part of a different calculation.
        rule = deepcopy(drafts.get(chosen) or (saved if chosen == initial and not st.session_state.get(key + "cleared") else {}))
        if not rule:
            rule = {"version": 1, "operator": operator, "family": family}
        if operator == "baseline_ecog" and ecog_choice is not None:
            compact_key = key + "ecog_compact_"
            if st.session_state.get(compact_key + "rule"):
                rule = deepcopy(st.session_state[compact_key + "rule"])
            compact = _ecog_compact(row, rule, ecog_choice, key=compact_key, permitted=permitted,
                                    shared_values=shared_values, typed_value=typed_value)
            if compact is not None:
                drafts[chosen] = deepcopy(compact["clinical_rule"])
                st.session_state[key + "drafts"] = drafts
                return compact
            for issue in ecog_choice.get("issues") or []:
                st.info(issue)
        if rules.instruments.is_native(rule):
            from experiments.portal import variable_native_instrument_page
            updates = variable_native_instrument_page.render(row, rule, key=key + chosen, permitted=permitted)
            drafts[chosen] = deepcopy(updates["clinical_rule"])
            st.session_state[key + "drafts"] = drafts
            return updates
        if operator == "custom":
            rule["custom_notes"] = st.text_area("Describe the calculation you need", value=rule.get("custom_notes", ""),
                key=key + chosen + "notes", disabled=not permitted)
            st.info("This description can be saved. Execution needs a supported calculation and its tests.")
            drafts[chosen] = deepcopy(rule)
            st.session_state[key + "drafts"] = drafts
            return {"clinical_rule": rule}
        if (((row.get("values") or {}).get("source") or {}).get("kind")) != "vendor":
            st.info("This calculation selects or groups recorded observations. Choose Existing data column above and link its source fields. "
                    "Calculated from other fields is for formulas over existing variables.")
        stem = rule.get("output_stem") or str(row.get("variable_id") or "").lower()
        rule["output_stem"] = st.text_input("Output name for this calculation", value=stem,
            key=key + chosen + "stem", disabled=not permitted)
        results = ["label", "value", "date"] if operator == "lab_value" else ["label", "code"]
        if operator in {"panel_categories", "panel_bands"}:
            results.append("date")
        result_labels = {name: RESULTS[name] for name in results}
        if operator == "lab_value":
            result_labels["label"] = "Whether a numeric result is available"
        rule["result"] = _choose("Value to deliver", rule.get("result"), result_labels,
            key + chosen + "result", permitted)
        st.caption("Related fields share one selected source record. Review the generated field names in Outputs before execution.")
        _window_editor(rule, key=key + chosen, permitted=permitted)
        if operator == "lab_value":
            st.caption("This numeric-result template selects the nearest eligible date, preferring the earlier date when equally close.")
            if rule.get("pick") or rule.get("tie_break"):
                st.warning("The saved selection policy differs from this template. It is preserved and requires review before execution.")
            rule["value_tiebreak"] = _choose("Different numbers on the selected date", rule.get("value_tiebreak"),
                {"lowest": "Use the lower value", "highest": "Use the higher value"}, key + chosen + "value_tie", permitted)
            rule["positive_only"] = st.checkbox("Only values above zero are eligible", value=rule.get("positive_only", False),
                key=key + chosen + "positive", disabled=not permitted)
        elif operator == "baseline_ecog":
            rule["equidistant"] = _choose("ECOG selection policy", rule.get("equidistant"),
                {"date": "Choose by date first", "worst_value": "Choose the worse ECOG value when equally close"},
                key + chosen + "equi", permitted)
            if rule["equidistant"] != "worst_value":
                rule["tie_break"] = _choose("Equal-distance dates", rule.get("tie_break"),
                    {"earliest_date": "Earlier date", "latest_date": "Later date"}, key + chosen + "tie", permitted)
            else:
                st.caption("Among equally close records, the worse ECOG value comes first; if severity is equal, the earlier date is used.")
                rule["tie_break"] = _choose("If ECOG severity is equal", rule.get("tie_break"),
                    {"earliest_date": "Earlier date (required by this calculation)"}, key + chosen + "tie", permitted)
        else:
            rule["pick"] = _choose("Which eligible record", rule.get("pick"),
                {"nearest": "Closest to index", "earliest": "First in the window", "latest": "Last in the window"},
                key + chosen + "pick", permitted)
            if rule["pick"] in {"nearest", "priority"}:
                rule["tie_break"] = _choose("Equal-distance dates", rule.get("tie_break"),
                    {"prior": "Earlier date", "later": "Later date"}, key + chosen + "tie", permitted)
            rule["same_date_conflict"] = _choose("Different categories on the same date", rule.get("same_date_conflict"),
                {"refuse": "Stop and ask for a resolution"}, key + chosen + "conflict", permitted)
        if operator in {"panel_categories", "panel_bands", "lab_value"}:
            if rule.get("match_any"):
                rule["match_any"] = controls.render_multi("Test or assessment names in the source", rule["match_any"],
                    rule["match_any"], key=key + chosen + "match_any", disabled=not permitted)
            else:
                rule["match"] = st.text_input("Test or assessment name in the source", value=rule.get("match", ""),
                    key=key + chosen + "match", disabled=not permitted)
            if operator != "lab_value":
                rule["emit_date"] = st.checkbox("Keep the selected assessment date", value=rule.get("emit_date", False),
                    key=key + chosen + "emit_date", disabled=not permitted)
            units = controls.render_multi("Accepted measurement units", rule.get("units") or [],
                ["%", "ng/mL", "g/L", "mg/dL"], key=key + chosen + "units", disabled=not permitted,
                help="Choose all accepted units or type another. Empty means no unit restriction; values are not converted between units.")
            if units or "units" in rule:
                rule["units"] = units
        if operator in {"panel_bands", "lab_value"}:
            rule["value_cast"] = _choose("Number format in the source", rule.get("value_cast"),
                {"double": "Decimal number", "int": "Whole number", "bigint": "Large whole number"},
                key + chosen + "cast", permitted)
        ui_issues = []
        pending_result = shared_values and operator in {"categorical", "panel_categories", "panel_bands", "baseline_ecog"} and rule.get("result") not in results
        if pending_result:
            # Do not create a second provisional mapping from yesterday's
            # Values while the user is still choosing the delivered result.
            # Existing mapping fields remain in rule unchanged. Date outputs
            # still need their clinical mapping to select the source record.
            st.caption("Choose which result this variable should return before editing its categories or ranges.")
        elif operator in {"categorical", "panel_categories"}:
            st.caption("Map each source value to its delivered category. Numeric companion codes are shown explicitly and can be edited.")
            rule["groups"] = _mapping(rule, typed_value, key + chosen + "groups", permitted)
        elif operator == "panel_bands":
            rule["bands"] = _mapping(rule, typed_value, key + chosen + "bands", permitted, bands=True)
        elif operator == "baseline_ecog":
            code_rows = [{"value": str(value), "code": code} for value, code in (rule.get("value_codes") or {}).items()]
            edited = _grid(code_rows or [{"value": "", "code": None}], key + chosen + "ecog_codes", permitted,
                {"value": st.column_config.TextColumn("ECOG value"),
                 "code": st.column_config.NumberColumn("Delivered code", step=1)}, numeric=("code",))
            labels = [str(item["value"]).strip() for item in edited if item.get("value")]
            if len(labels) != len(set(labels)):
                ui_issues.append("Each ECOG value needs one row. Remove duplicate values before saving.")
            if any(not item.get("value") and item.get("code") is not None for item in edited):
                ui_issues.append("Add the ECOG value beside each entered code before saving.")
            rule["value_codes"] = {str(item["value"]): int(item["code"]) if item.get("code") is not None and float(item["code"]).is_integer()
                                   else item.get("code") for item in edited if item.get("value")}
            rule["missing_code"] = st.number_input("Code when no ECOG record is available", value=rule.get("missing_code"),
                step=1, key=key + chosen + "missing_code", disabled=not permitted)
        if operator in {"lab_value", "baseline_ecog"}:
            rule["missing_label"] = st.text_input("Label when no eligible result exists", value=rule.get("missing_label", ""),
                key=key + chosen + "missing_label", disabled=not permitted)
        if operator == "lab_value":
            rule["present_label"] = st.text_input("Label when a numeric result exists", value=rule.get("present_label", ""),
                key=key + chosen + "present_label", disabled=not permitted)
        role_map = rule.get("column_roles") or {}
        columns = ((row.get("values") or {}).get("source") or {}).get("columns") or {}
        columns = columns if isinstance(columns, dict) else {}
        with st.expander("Link the required source fields"):
            try:
                required = rules.required_roles(rule)
            except ValueError as error:
                st.caption(str(error))
                required = ["value", "date"]
                if operator in {"panel_categories", "panel_bands", "lab_value"}:
                    required.append("analyte")
                    if rule.get("units"):
                        required.append("unit")
            roles = list(dict.fromkeys([*required, *role_map]))
            for role in roles:
                options = {"": "Not linked yet", **{name: name for name in dict.fromkeys([role, *columns])}}
                role_map[role] = _choose(role.replace("_", " ").capitalize() + " source role",
                    role_map.get(role), options, key + chosen + "role_" + role, permitted)
            st.caption("The data reviewer maps these roles to physical columns in Sources.")
            if role_map.get("unit") and not rule.get("units"):
                st.caption("No units are selected. Clear the Unit source role above, or select the accepted units.")
        rule["column_roles"] = role_map
        updates = {"clinical_rule": rule}
        expected = None
        try:
            generated = rules.scientific_updates(rule)
            expected = next((item for item in rules.emitted_columns(rule) if item["result"] == rule.get("result")), None)
            if expected:
                dtype = expected["type"]
                st.info("Required result type: " + controls.TYPE_LABELS.get(dtype, dtype) + " (" + dtype + ").")
                selected_type = (typed_value or {}).get("data_type") or (((row.get("values") or {}).get("output") or {}).get("type"))
                # The owning review page checks the current typed editor after
                # this render; its seed can be from the previous rerun.
                if selected_type and canonical_type(selected_type) != dtype and not shared_values:
                    ui_issues.append("The value editor currently uses " + str(selected_type) + ". Choose " + dtype +
                                     " there to agree with this calculation before saving.")
            if generated.get("derivation"):
                st.write("**Rule generated from these choices**")
                st.text(generated["derivation"])
            updates.update(generated)
        except ValueError as error:
            st.caption(str(error))
        trial = deepcopy(row)
        trial["clinical_rule"] = rule
        if shared_values and variable_clinical_value_page.manages(rule) and expected:
            trial.setdefault("values", {}).setdefault("output", {})["type"] = expected["type"]
        for issue in rules.issues(trial):
            st.caption(issue)
        for issue in ui_issues:
            st.warning(issue)
        if ui_issues:
            updates["_ui_issues"] = ui_issues
        drafts[chosen] = deepcopy(rule)
        st.session_state[key + "drafts"] = drafts
        if operator == "baseline_ecog" and st.session_state.get(key + "ecog_compact_details"):
            st.session_state.pop(key + "ecog_compact_rule", None)
        return updates
