"""Portable metadata for the measured local Python environment; never an installer.

Capture follows only the declared portal/platform dependency closure plus pytest.
Normal startup reports drift without turning a different transitive version into a
product gate. Native runtimes remain explicit optional installations.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata as metadata
import json
import os
import platform
import re
import sys
from pathlib import Path

from rwd_services import workspace_root, package_asset, package_file_map
ROOT = workspace_root(__file__)
MANIFEST = "experiments/portal/environment.manifest.json"
CONSTRAINTS = "experiments/portal/environment.constraints.txt"
TEST_REQUIREMENT = "pytest==9.1.1"
NOTICE = ("Dependency metadata only. A matching environment is not a workflow, scientific, "
          "Spark or R test result. Optional native runtimes are installed and checked separately.")


def _requirement(text):
    from packaging.requirements import Requirement
    item = Requirement(text)
    if item.url or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", item.name):
        raise ValueError("Only named package requirements are included; direct URLs are not portable constraints.")
    return item


def _name(value):
    return re.sub(r"[-_.]+", "-", value).lower()


def roots(root):
    """Read the existing requirements, without pip options, URL sources or escapes."""
    root = Path(root).resolve()
    installed = package_file_map() if not (root / "requirements.txt").is_file() and not (root / "pyproject.toml").is_file() else None
    found, visited, active = {"pytest": TEST_REQUIREMENT}, set(), set()
    def read(relative, *, constraint=False):
        path = (root / relative).resolve()
        if not path.is_relative_to(root) or path in active:
            raise ValueError("Requirements include an unsafe or recursive include.")
        marker = (path, constraint)
        if marker in visited:
            return
        visited.add(marker)
        active.add(path)
        source = installed.get(path.relative_to(root).as_posix()) if installed is not None else path
        if source is None:
            raise ValueError("The installed dependency metadata is incomplete: " + path.relative_to(root).as_posix())
        for raw in source.read_text(encoding="utf-8").splitlines():
            line = raw.split("#", 1)[0].strip()
            if not line:
                continue
            if line.startswith("-r "):
                read(path.parent.joinpath(line[3:].strip()).relative_to(root), constraint=constraint)
                continue
            if line.startswith("-c "):
                read(path.parent.joinpath(line[3:].strip()).relative_to(root), constraint=True)
                continue
            local_project = re.fullmatch(r"\.(?:\[([A-Za-z0-9_,.-]+)\])?", line)
            if local_project:
                # The installed distribution uses these same files; read only
                # declarative metadata, never execute a build backend at startup.
                import tomllib
                project_path = installed["pyproject.toml"] if installed is not None else root / "pyproject.toml"
                project = tomllib.loads(project_path.read_text(encoding="utf-8"))
                dynamic = project["tool"]["setuptools"]["dynamic"]
                groups = [dynamic["dependencies"]]
                for extra in (local_project.group(1) or "").split(","):
                    if extra:
                        groups.append(dynamic["optional-dependencies"][extra])
                for group in groups:
                    files = group.get("file")
                    files = [files] if isinstance(files, str) else files
                    if not isinstance(files, list) or not files or not all(isinstance(value, str) for value in files):
                        raise ValueError("Project dependencies must name existing requirements files.")
                    for filename in files:
                        read(filename, constraint=constraint)
                continue
            requirement = _requirement(line)
            if constraint:
                continue  # Pins constrain a closure; they do not install roots.
            name = _name(requirement.name)
            canonical = str(requirement)
            if name in found and found[name] != canonical:
                raise ValueError("Requirements disagree for " + name)
            found[name] = canonical
        active.remove(path)
    read("requirements.txt")
    read("platform/requirements.txt")
    return dict(sorted(found.items()))


def _closure(root_requirements, get_record, environment=None):
    """Resolve markers and extras from metadata, without importing package code."""
    from packaging.markers import default_environment
    env = {**default_environment(), **(environment or {})}
    selected, extras_seen, pending = {}, {}, list(root_requirements.values())
    while pending:
        requirement = _requirement(pending.pop())
        if requirement.marker and not requirement.marker.evaluate({**env, "extra": ""}):
            continue
        name = _name(requirement.name)
        record = selected.setdefault(name, get_record(name))
        if not requirement.specifier.contains(record["version"], prereleases=True):
            raise ValueError("Installed dependency does not satisfy " + str(requirement))
        extras = set(requirement.extras) | {""}
        if name in extras_seen and extras <= extras_seen[name]:
            continue
        extras_seen.setdefault(name, set()).update(extras)
        for raw in record["requires"]:
            child = _requirement(raw)
            if child.marker is None or any(child.marker.evaluate({**env, "extra": extra}) for extra in extras_seen[name]):
                # The marker was evaluated in its parent's extras context. Keeping
                # it would incorrectly evaluate it again in the child's context.
                child.marker = None
                pending.append(str(child))
    return dict(sorted(selected.items()))


def capture(root=ROOT, *, distribution=None):
    distribution = distribution or metadata.distribution
    def get_record(name):
        dist = distribution(name)
        version = dist.version
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.!+_-]*", version):
            raise ValueError("Unusable package version metadata.")
        return {"version": version, "requires": sorted(str(_requirement(value)) for value in (dist.requires or []))}
    declared = roots(root)
    packages = _closure(declared, get_record)
    version = platform.python_version()
    profile = "local-python" + "".join(version.split(".")[:2]) + "-20260909"
    return {"schema_version": 1, "profile": profile, "python": version,
            "system": platform.system(), "machine": platform.machine(), "roots": declared, "packages": packages,
            "optional_runtime": {}, "optional_runtime_status": "not_checked",
            "evidence": "Python distribution metadata captured by portal_environment.capture; no native runtime tests were run.", "notice": NOTICE}


def load(root=ROOT):
    path = Path(root) / MANIFEST
    if not path.is_file():
        path = package_asset(MANIFEST)
    if path.stat().st_size > 512_000:
        raise ValueError("Environment manifest is too large.")
    doc = json.loads(path.read_text(encoding="utf-8"))
    if (not isinstance(doc, dict) or doc.get("schema_version") != 1 or not isinstance(doc.get("packages"), dict)
            or not 1 <= len(doc["packages"]) <= 300 or not isinstance(doc.get("roots"), dict)):
        raise ValueError("Environment manifest is malformed.")
    for name, record in doc["packages"].items():
        if (not isinstance(name, str) or name != _name(name) or not re.fullmatch(r"[a-z0-9][a-z0-9-]*", name)
                or not isinstance(record, dict) or set(record) != {"version", "requires"}
                or not isinstance(record["version"], str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.!+_-]*", record["version"])
                or not isinstance(record["requires"], list) or len(record["requires"]) > 300):
            raise ValueError("Environment package metadata is malformed.")
        for value in record["requires"]:
            _requirement(value)
    for name, value in doc["roots"].items():
        if _name(_requirement(value).name) != name:
            raise ValueError("Environment root metadata is malformed.")
    return doc


def package_names(root=ROOT):
    try:
        return list(load(root)["packages"])
    except (OSError, ValueError, TypeError, KeyError, RecursionError, ImportError):
        return []


def snapshot_dependency_report(required):
    """Check the dependency paths exposed by prepare_snapshot_runtime, without writes.

    System/user sites and arbitrary .pth hooks can satisfy the parent interpreter
    but are deliberately absent from its staged validators. Only the selected
    purelib/platlib and the helper's path-only receipts carry into that runtime.
    The project itself is rebuilt and installed there, so its parent location is
    not a dependency. Version drift remains the separate measured-profile check.
    """
    import sysconfig
    directories, visiting = [], set()

    def follow(value, depth=0):
        directory = Path(value)
        if (not directory.is_absolute() or directory.is_symlink() or not directory.is_dir()
                or "\n" in str(directory) or "\r" in str(directory) or depth > 8):
            raise ValueError("A staged dependency directory is invalid or its chain is too deep.")
        directory = directory.resolve()
        if directory in visiting:
            raise ValueError("The staged dependency directory chain contains a cycle.")
        if directory in directories:
            return
        if len(directories) >= 32:
            raise ValueError("The staged dependency directory chain is too large.")
        directories.append(directory)
        visiting.add(directory)
        receipt = directory / "reviewed-dependencies.pth"
        if receipt.exists():
            if receipt.is_symlink() or receipt.stat().st_size > 32768:
                raise ValueError("The staged dependency path receipt is not an ordinary bounded file.")
            for entry in receipt.read_text(encoding="utf-8").splitlines():
                if not entry or entry != entry.strip() or entry.startswith(("import ", "import\t", "#")):
                    raise ValueError("The staged dependency receipt must contain only absolute directory paths.")
                follow(entry, depth + 1)
        visiting.remove(directory)

    try:
        for key in ("purelib", "platlib"):
            follow(sysconfig.get_path(key))
        available = {_name(dist.metadata["Name"]) for dist in metadata.distributions(path=list(map(str, directories)))
                     if dist.metadata.get("Name")}
        missing = sorted({_name(name) for name in required} - {"rwd-platform"} - available)
        return {"ok": not missing, "missing": missing}
    except (OSError, ValueError, TypeError, KeyError):
        return {"ok": False, "missing": [],
                "error": "The selected environment's staged dependency directories or path receipts are invalid."}


def report(root=ROOT, *, observed=None, runtime=None, observed_environment=None):
    """Stable, path-free diagnostics suitable for the existing prerequisite receipt.

    Pass an interpreter probe's observed versions to inspect that interpreter;
    otherwise read metadata from this process. Unrelated site packages are ignored.
    """
    try:
        doc = load(root)
        # Keep the launcher probe side-effect free.  ``platform.system()`` can
        # invoke the Windows ``ver`` command on some Python builds; callers
        # that mock the probe (and installed launchers with restricted shells)
        # must not see that unrelated subprocess or lose the probe result.
        portable = observed_environment or {
            "python": ".".join(str(value) for value in sys.version_info[:3]),
            "system": {"win32": "Windows", "linux": "Linux", "darwin": "Darwin"}.get(sys.platform, sys.platform),
            # Avoid platform.machine() here too: on Windows it may shell out
            # to ``ver``/registry helpers.  The probe already supplies the
            # architecture when available; this fallback is only diagnostic.
            "machine": os.environ.get("PROCESSOR_ARCHITECTURE") or os.environ.get("HOSTTYPE") or "unknown",
        }
        portable = {key: portable.get(key) for key in ("python", "system", "machine")}
        marker_environment = {}
        if portable["python"]:
            marker_environment.update(python_full_version=portable["python"],
                                      python_version=".".join(portable["python"].split(".")[:2]))
        if portable["system"]:
            marker_environment["platform_system"] = portable["system"]
            marker_environment["sys_platform"] = {"Windows": "win32", "Linux": "linux", "Darwin": "darwin"}.get(portable["system"], sys.platform)
        if portable["machine"]:
            marker_environment["platform_machine"] = portable["machine"]
        selected = _closure(doc["roots"], lambda name: doc["packages"][name], marker_environment)
        current = {}
        for name in selected:
            if observed is not None:
                current[name] = observed.get(name)
            else:
                try:
                    current[name] = metadata.version(name)
                except metadata.PackageNotFoundError:
                    current[name] = None
        entries = [{"package": name, "expected": record["version"], "observed": current[name]} for name, record in selected.items()]
        missing = [item for item in entries if item["observed"] is None]
        mismatched = [item for item in entries if item["observed"] is not None and item["observed"] != item["expected"]]
        runtime_entries = []
        if runtime is not None:
            expected_native = doc.get("optional_runtime", {})
            for name in ("r_version", "pyspark", "java_version"):
                runtime_entries.append({"package": name, "expected": expected_native.get(name), "observed": runtime.get(name)})
            for name, expected in expected_native.get("r_packages", {}).items():
                runtime_entries.append({"package": "R:" + name, "expected": expected, "observed": runtime.get("r_packages", {}).get(name)})
        drift = roots(root) != doc["roots"]
        profile_matches = all(doc.get(key) == value for key, value in portable.items())
        return {"status": "matched" if not missing and not mismatched and not drift and profile_matches else "mismatch",
                "manifest": MANIFEST, "manifest_sha256": hashlib.sha256(json.dumps(doc, sort_keys=True).encode()).hexdigest(),
                "profile": doc["profile"], "expected_runtime": {key: doc[key] for key in portable}, "observed_runtime": portable,
                "requirements_changed": drift, "packages": entries, "missing": missing, "mismatched": mismatched,
                "optional_runtime": runtime_entries,
                "optional_runtime_status": ("not_checked" if runtime is None or not doc.get("optional_runtime") else
                    "matched" if all(item["expected"] == item["observed"] and item["expected"] is not None for item in runtime_entries) else "mismatch"),
                "notice": NOTICE}
    except (OSError, ValueError, TypeError, KeyError, RecursionError, ImportError):
        return {"status": "unavailable", "manifest": MANIFEST,
                "reason": "The measured environment manifest is missing, invalid, or does not cover this platform's dependency closure.", "notice": NOTICE}


def constraints(doc):
    minor = ".".join(doc["python"].split(".")[:2])
    return (f"# Measured local Python {minor} dependency closure; optional Spark/R are separate.\n"
            "# Constraints select versions; install the existing requirements plus pytest.\n" +
            "".join(name + "==" + record["version"] + "\n" for name, record in sorted(doc["packages"].items())))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--capture", action="store_true", help="Explicitly rewrite the measured manifest and constraints from the current dependency metadata; review the diff.")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    if args.capture:
        doc = capture()
        (ROOT / MANIFEST).write_text(json.dumps(doc, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        (ROOT / CONSTRAINTS).write_text(constraints(doc), encoding="utf-8")
    result = report()
    print(json.dumps(result, indent=2) if args.json else "Measured local environment: " + result["status"] + ". " + NOTICE)
    return 0 if result["status"] == "matched" else 1


if __name__ == "__main__":
    raise SystemExit(main())
