"""Scoped, on-demand structure checks over the saved specification extraction.

This is a source-evidence preview, not a new approval or configuration store.
The extractor and schema cannot change any product files through this module.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path

from experiments.portal import specification_details as details
from rwd_tools import related_extraction, spec_codelists

SCHEMA = "governance/schemas/rwd_related_extraction.yaml"
EXTRACTION = "spec_pipeline/out/extracted.json"
DISPOSITIONS = "handoff/spec_dispositions.yaml"
CONTRACT = "handoff/FUNCTIONAL_CONTRACT.md"
MAX_BYTES = 8 * 1024 * 1024
NOTICE = (
    "Checks original specification cells and their explicit links in the saved extraction. "
    "Scientific interpretations, source-table mappings and approval are checked separately."
)


def _fail(error):
    return {"ok": False, "errors": [str(error)], "notice": NOTICE}


def _read(path, *, optional=False):
    if path.resolve() != path:
        raise ValueError("A specification input redirects to another location. Check its registered location.")
    if optional and not path.exists():
        return b""
    if not path.is_file():
        raise ValueError("Prepare the specification extraction before checking its related records.")
    with path.open("rb") as handle:
        raw = handle.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise ValueError("A specification input exceeds the supported preview size of 8 MB.")
    return raw


def _inputs(root, pack, actor_id, allowed_packs):
    source, pack = details._paths(root, pack, allowed_packs)
    if not isinstance(actor_id, str) or not actor_id.strip() or len(actor_id) > 200:
        raise ValueError("Choose a profile before checking the specification.")
    base, product = Path(root).resolve(), source.parent
    schema = base / SCHEMA
    if not schema.exists():
        from rwd_services import package_asset
        schema = package_asset(SCHEMA)
    inputs = {
        EXTRACTION: _read(product / EXTRACTION),
        SCHEMA: _read(schema),
        "source_refs.yaml": _read(source, optional=True),
        "spec_pipeline/pipeline.conf": _read(product / "spec_pipeline/pipeline.conf", optional=True),
        DISPOSITIONS: _read(product / DISPOSITIONS, optional=True),
        CONTRACT: _read(product / CONTRACT, optional=True),
        "extractor": _read(Path(related_extraction.__file__).resolve()),
        "enumeration_extractor": _read(Path(spec_codelists.__file__).resolve()),
    }
    digest = hashlib.sha256()
    for name, raw in sorted(inputs.items()):
        digest.update(name.encode("utf-8") + b"\0" + hashlib.sha256(raw).digest())
    digest.update(json.dumps([str(base), pack, actor_id], ensure_ascii=True).encode("utf-8"))
    return pack, schema, inputs, digest.hexdigest()


def describe(root, pack, actor_id, *, allowed_packs=None):
    """Cheap byte identity for cache invalidation; does not run object extraction."""
    try:
        pack, _schema, _raw, digest = _inputs(root, pack, actor_id, allowed_packs)
        return {"ok": True, "pack": pack, "input_digest": digest, "errors": [], "notice": NOTICE}
    except (ValueError, OSError, TypeError) as error:
        return _fail(error)


def _unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("The saved extraction contains duplicate JSON fields. Prepare its extraction again.")
        result[key] = value
    return result


def preview(root, pack, actor_id, *, expected_digest, allowed_packs=None):
    """Validate exactly the displayed inputs, then recheck before returning a report."""
    try:
        pack, schema_path, inputs, digest = _inputs(root, pack, actor_id, allowed_packs)
        if not isinstance(expected_digest, str) or expected_digest != digest:
            raise ValueError("The specification or schema changed. Check the current specification again.")
        from rwd_tools import related_extraction

        data = json.loads(inputs[EXTRACTION].decode("utf-8"), object_pairs_hook=_unique_pairs)
        source_data = data
        context_rows = []
        if inputs[DISPOSITIONS].strip():
            from rwd_tools import contract_lint as cl
            from experiments.portal import specification_row_context as row_context
            product = Path(root).resolve() / pack
            normalized = row_context._known_rows(data)
            blocks = list(cl.records(inputs[CONTRACT].decode("utf-8")))
            _remaining, context_rows = row_context.apply_context_dispositions(root, product, normalized, blocks)
            current_context = {row["item_id"] for row in context_rows if not row.get("context_stale")}
            # The canonical extraction remains unchanged. Only this preview's
            # interpretation distinguishes explicitly classified metadata.
            data = deepcopy(data)
            data["rows"] = [row for row in data["rows"] if row_context.row_item_id(row) not in current_context]
        schema = related_extraction.load_schema(schema_path)
        report = related_extraction.extract(data, schema)
        from rwd_tools import spec_codelists
        # Reuse the pipeline's literal evidence reader over the same scoped
        # snapshot; do not load another product's generated candidates or write.
        candidates, unparsed = spec_codelists.extract(data["rows"])
        report["enumeration_evidence"] = {"coverage": spec_codelists.coverage(data["rows"], candidates, unparsed),
                                          "candidates": candidates, "unparsed": unparsed}
        if _inputs(root, pack, actor_id, allowed_packs)[3] != digest:
            raise ValueError("The specification changed during the check. Check the current specification again.")
        if not isinstance(report, dict) or not report.get("ok"):
            raise ValueError("The related-record check did not return a readable report.")
        report["source_fingerprint"] = related_extraction._hash(source_data)
        report["review_input_digest"] = digest
        report["context_rows"] = [
            {**row, "citations": [{"item_id": row["item_id"], "tab": row["tab"], "row": row["row"], "field": ""}]}
            for row in context_rows
        ]
        report["checkable"] = bool(report.get("objects"))
        report["check_status"] = ("checked" if report["checkable"] else
            "no_variables" if any(not row.get("context_stale") for row in context_rows) else "not_checkable")
        if report["check_status"] == "not_checkable":
            # An empty schema result does not establish that a product's
            # variables were extracted successfully. Preserve all source bytes.
            report["valid"] = False
        return {"ok": True, "pack": pack, "input_digest": digest, "report": report,
                "errors": [], "notice": NOTICE}
    except (ValueError, OSError, TypeError, KeyError, UnicodeError, RecursionError) as error:
        return _fail(error)
