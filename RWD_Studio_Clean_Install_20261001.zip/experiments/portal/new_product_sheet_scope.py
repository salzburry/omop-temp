"""Connect product registration to the existing per-product extraction scope.

Only sheet metadata reaches the form/chat. The selected workbook is never edited.
Selections are bound to its bytes and the current sheet map, not just its filename.
"""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path
import re

from rwd_tools import new_product
from experiments.portal import specification_attachment as attachment
from experiments.portal import ui_text as ui

SELECTION = "np_excluded_sheets"
REASON = "np_excluded_sheets_reason"
BINDING = "np_sheet_scope_binding"
HINT = "np_sheet_scope_hint"
HINT_MODE = "np_sheet_scope_hint_mode"
MAPPINGS = "np_sheet_domains"
MAPPING_REASON = "np_sheet_domain_reason"

SECTION_LABELS = {
    "study_period": "Study dates and preparation",
    "study_population": "Study population",
    "demographics": "Demographics",
    "clinical": "Clinical characteristics",
    "treatment": "Treatment",
    "outcomes": "Outcomes",
}


def section_label(value):
    return SECTION_LABELS.get(value, value.replace("_", " ").capitalize()) if value else "No section assigned"


def current_mappings(scope, state):
    """Use only choices for this workbook; widget values can precede render."""
    if not scope.get("binding") or state.get(BINDING) != scope["binding"]:
        return {}
    saved = state.get(MAPPINGS)
    saved = saved if isinstance(saved, dict) else {}
    domains = scope.get("mapping_domains", [])
    result = {}
    for sheet in scope.get("sheets", []):
        if sheet.get("mapping_selectable"):
            name = sheet["name"]
            value = state.get(mapping_key(name), saved.get(name, ""))
            if isinstance(value, str) and value and value in domains and value != sheet.get("domain"):
                result[name] = value
    return result


def sheet_overview(scope, state):
    """Display every tab without implying that a section verifies its disease."""
    mappings = current_mappings(scope, state)
    excluded = (state.get(SELECTION) or []) if state.get(BINDING) == scope.get("binding") else []
    rows = []
    for sheet in scope.get("sheets", []):
        name = sheet["name"]
        domain = mappings.get(name) or sheet.get("domain")
        if domain or sheet.get("kind") == "requirement":
            status = "Included"
            basis = "Your section choice" if name in mappings else "Existing worksheet mapping"
        elif name in excluded and sheet.get("selectable"):
            status, basis = "Left out", "Your scope choice"
        elif sheet.get("kind") == "ignored":
            status, basis = "Context only", "Existing worksheet mapping"
        else:
            status, basis = "Needs a choice", "Choose a section or leave it out"
        rows.append({"Worksheet": name, "Use": status,
                     "Specification section": section_label(domain) if domain else "—", "How assigned": basis})
    return rows


def mapping_key(sheet):
    return "np_sheet_domain_choice_" + hashlib.sha256(sheet.encode()).hexdigest()[:16]


def validate_hint(value):
    """A private continuation hint carries no paths, workbook cells or approval."""
    extra = {"sheet_mappings", "mapping_reason", "mapping_previous_pack"}
    if (not isinstance(value, dict) or set(value) not in (
            {"workbook_sha256", "sheets", "reason"}, {"workbook_sha256", "sheets", "reason"} | extra)
            or not isinstance(value["workbook_sha256"], str) or not re.fullmatch(r"[0-9a-f]{64}", value["workbook_sha256"])
            or not isinstance(value["sheets"], list) or not 0 <= len(value["sheets"]) <= 100
            or any(not isinstance(name, str) or not name.strip() or len(name) > 128 or any(ord(c) < 32 for c in name) for name in value["sheets"])
            or len(set(value["sheets"])) != len(value["sheets"])
            or not isinstance(value["reason"], str) or len(value["reason"]) > 1000 or any(ord(c) < 32 for c in value["reason"])):
        raise ValueError("The saved sheet-scope hint is malformed. Choose the sheets again for this workbook.")
    mappings = value.get("sheet_mappings") or {}
    previous_pack = value.get("mapping_previous_pack")
    valid_previous = isinstance(previous_pack, str) and (previous_pack == "" or re.fullmatch(
        r"products/[a-z0-9_]+/[a-z0-9_]+/[0-9]{6}", previous_pack) is not None)
    if (not isinstance(mappings, dict) or len(mappings) > 100 or (not value["sheets"] and not mappings)
            or any(not isinstance(name, str) or not name or len(name) > 128 or any(ord(c) < 32 for c in name)
                or not isinstance(domain, str) or not re.fullmatch(r"[a-z][a-z0-9_]*", domain)
                for name, domain in mappings.items())
            or (mappings and (not isinstance(value.get("mapping_reason"), str)
                or len(value["mapping_reason"]) > 1000 or any(ord(c) < 32 for c in value["mapping_reason"])
                or not valid_previous))):
        raise ValueError("The saved sheet mapping is malformed. Choose the sections again for this workbook.")
    return {**value, "sheets": list(value["sheets"])}


def capture_hint(root, state):
    """Snapshot current choices only while bound to their exact selected source."""
    scope = describe(root, state)
    if scope.get("ok") and state.get(BINDING) == scope["binding"] and (state.get(SELECTION) or state.get(MAPPINGS)):
        selected = state.get(SELECTION) or []
        selectable = {row["name"] for row in scope["sheets"] if row["selectable"]}
        if isinstance(selected, list) and all(name in selectable for name in selected):
            hint = {"workbook_sha256": scope["sha256"], "sheets": selected,
                    "reason": str(state.get(REASON) or "")}
            if state.get(MAPPINGS):
                hint.update(sheet_mappings=dict(state[MAPPINGS]), mapping_reason=str(state.get(MAPPING_REASON) or ""),
                            mapping_previous_pack=scope.get("previous_pack") or "")
            return validate_hint(hint)
    # A resumed setup may be saved again before its workbook is reselected.
    if not scope.get("available") and state.get(HINT) and state.get(HINT_MODE) == state.get("np_mode"):
        return validate_hint(state[HINT])
    return None


def hint_status(scope, state):
    hint = state.get(HINT)
    if not hint:
        return {"available": False}
    try:
        hint = validate_hint(hint)
    except ValueError as error:
        return {"available": True, "eligible": False, "reason": str(error)}
    if state.get(HINT_MODE) != state.get("np_mode"):
        return {"available": True, "eligible": False, "reason": "The starting point changed. Choose sheet sections and exclusions for this setup; the saved choices have not been applied."}
    if not scope.get("ok") or hint["workbook_sha256"] != scope.get("sha256"):
        return {"available": True, "eligible": False, "reason": "Saved sheet choices belong to a different workbook. Select the original workbook or choose sheets for this one."}
    options = {row["name"] for row in scope["sheets"] if row["selectable"]}
    if any(name not in options for name in hint["sheets"]):
        return {"available": True, "eligible": False, "reason": "Saved exclusions no longer match the current sheet mapping. Review the available sheets and choose their scope again."}
    mappings = hint.get("sheet_mappings") or {}
    choices = {row["name"] for row in scope["sheets"] if row.get("mapping_selectable")}
    if mappings and (hint.get("mapping_previous_pack") != (scope.get("previous_pack") or "")
            or any(name not in choices or domain not in scope.get("mapping_domains", []) for name, domain in mappings.items())
            or set(mappings) & set(hint["sheets"])):
        return {"available": True, "eligible": False, "reason": "Saved sheet sections no longer match this starting point and workbook. Review the current mappings again."}
    return {"available": True, "eligible": state.get(BINDING) == scope["binding"], "hint": hint}


def restore_hint(scope, state, *, confirmed):
    status = hint_status(scope, state)
    if confirmed is not True or not status.get("eligible"):
        raise ValueError("Review the saved sheet choices against the current workbook and sheet mapping before restoring them.")
    hint = status["hint"]
    state[SELECTION] = list(hint["sheets"])
    state[REASON] = hint["reason"]
    state[MAPPINGS] = dict(hint.get("sheet_mappings") or {})
    state[MAPPING_REASON] = hint.get("mapping_reason") or ""
    for sheet in scope.get("sheets", []):
        if sheet.get("mapping_selectable"):
            state.pop(mapping_key(sheet["name"]), None)
    for name, domain in state[MAPPINGS].items():
        state[mapping_key(name)] = domain
    state.pop("np_previewed", None)
    state.pop(HINT, None)
    state.pop(HINT_MODE, None)
    # Consumed hints must also leave the profile's navigation cache; otherwise
    # preserving a later page resurrects them as unapplied saved choices.
    retained = state.get("_form_drafts", {}).get(state.get("_draft_actor"), {})
    retained.pop(HINT, None)
    retained.pop(HINT_MODE, None)


def describe(root, state, *, allowed_packs=None):
    """Read the currently selected path/upload before chat and widgets render."""
    mode = state.get("np_mode")
    revised = mode == ui.NEW_PRODUCT_MODES[2]
    key = "np_wb" if revised else "np_wb2"
    pick = state.get(key)
    empty = {"ok": False, "available": False, "binding": "", "selected": [], "reason": ""}
    if not pick or pick == "(none)":
        return empty
    try:
        allow_macro_container = False
        if pick == "(upload a workbook)":
            upload = state.get(key + "_upload")
            if upload is None:
                return empty
            raw = upload.getvalue()
            source = upload.name
        else:
            chosen = state.get(key + "_path", "").strip() if pick == "(another file: type its path)" else pick
            if not chosen:
                return empty
            if allowed_packs is not None:
                from experiments.portal import portal_runtime
                if not portal_runtime.within_packs(chosen, root, allowed_packs):
                    raise ValueError("Choose a workbook within an assigned product.")
            path = Path(chosen)
            if not path.is_absolute():
                path = Path(root) / path
            source = str(path.resolve())
            # Existing local registration accepts XLSM paths. Inspect their bounded
            # metadata without keeping or executing VBA; uploads remain plain XLSX.
            allow_macro_container = path.suffix.lower() == ".xlsm"
            raw = attachment._bytes(path)
        digest = hashlib.sha256(raw).hexdigest()
        cache = state.get("np_wb_scope_cache") or {}
        if cache.get("sha256") == digest and cache.get("allow_macro_container") == allow_macro_container:
            metadata = cache["metadata"]
        else:
            metadata = attachment.validate_workbook(raw, allow_macro_container=allow_macro_container)
            state["np_wb_scope_cache"] = {"sha256": digest, "metadata": metadata,
                "allow_macro_container": allow_macro_container}
        # Keep structure inspection bound to workbook bytes. No cell content is
        # sent to a model during intake or ordinary widget reruns.
        column_inspection = state.get("np_wb_column_cache") or {}
        if column_inspection.get("sha256") != digest:
            from rwd_tools import spec_extract
            column_inspection = {"sha256": digest, "sheets": spec_extract.inspect_columns(io.BytesIO(raw))}
            state["np_wb_column_cache"] = column_inspection
        previous = state.get("np_old") if revised else None
        if previous and allowed_packs is not None and previous not in allowed_packs:
            raise ValueError("Choose an assigned previous product before selecting its revised sheets.")
        try:
            scope = new_product.sheet_scope_options(metadata["sheets"], root, previous_pack=previous)
        except OSError as error:
            previous_conf = Path(root) / str(previous or "") / "spec_pipeline/pipeline.conf"
            if not previous or not error.filename or Path(error.filename).resolve() != previous_conf.resolve():
                raise
            return {**empty, "available": True,
                    "error": "The selected previous cut's extraction configuration could not be read. "
                             "Choose another available previous cut or restore its extraction configuration before previewing.",
                    "missing_entry": "a previous cut with a readable extraction configuration"}
        registry_digest = hashlib.sha256((Path(root) / "governance/tumour_registry.yaml").read_bytes()).hexdigest()
        # A layout choice changes the evidence check, not the workbook identity.
        # Including it in binding would clear the user's choices on every rerun.
        binding = hashlib.sha256(json.dumps([str(Path(root).resolve()), source, digest, mode, previous, scope, registry_digest],
            sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        from rwd_tools import spec_extract
        domains = {spec_extract.sheet_key(row["name"]): row["domain"] for row in scope["sheets"] if row["domain"]}
        domains.update({spec_extract.sheet_key(name): domain
                        for name, domain in current_mappings({**scope, "binding": binding}, state).items()})
        population_key = [digest, registry_digest, domains]
        population_cache = state.get("np_wb_population_cache") or {}
        if population_cache.get("key") == population_key:
            population = population_cache["value"]
        else:
            population = new_product.workbook_population(io.BytesIO(raw), root, domains=domains)
            state["np_wb_population_cache"] = {"key": population_key, "value": population}
        return {**scope, "ok": True, "available": True, "sha256": digest, "binding": binding, "population": population,
                "previous_pack": previous,
                "selected": list(state.get(SELECTION) or []), "reason": str(state.get(REASON) or "")}
    except OSError:
        return {**empty, "available": True, "error": "The selected workbook or its required metadata could not be read. "
                "Check that the files are available and accessible, then try again."}
    except (ValueError, TypeError, KeyError, SystemExit) as error:
        return {**empty, "available": True, "error": str(error)}


def reconcile(state, scope):
    """Discard selections and preview authorization when their source changes."""
    binding = scope.get("binding", "")
    changed = state.get(BINDING, "") != binding
    if changed:
        had_choices = bool(state.get(SELECTION) or state.get(MAPPINGS))
        state[SELECTION] = []
        state[REASON] = ""
        state[MAPPINGS] = {}
        state[MAPPING_REASON] = ""
        for key in list(state):
            if str(key).startswith(("np_sheet_domain_choice_", "np_column_")):
                state.pop(key, None)
        state[BINDING] = binding
        state.pop("np_previewed", None)
        if had_choices:
            state["np_sheet_scope_notice"] = "The workbook or its sheet mapping changed. Review sheet sections and exclusions again for this specification."
    options = {sheet["name"] for sheet in scope.get("sheets", []) if sheet.get("selectable")}
    # A restored draft or a stale external widget state cannot name missing sheets.
    selected = state.get(SELECTION) or []
    if not isinstance(selected, list) or any(name not in options for name in selected):
        state[SELECTION] = []
        state.pop("np_previewed", None)
    scope["selected"] = list(state.get(SELECTION) or [])
    scope["reason"] = str(state.get(REASON) or "")
    return scope


def _render_sheets(scope):
    """Return canonical CLI arguments and missing entries from the shared form."""
    import streamlit as st
    from experiments.portal import form_assistance as forms
    notice = st.session_state.pop("np_sheet_scope_notice", None)
    if notice:
        st.info(notice)
    if not scope.get("available"):
        return [], []
    if not scope.get("ok"):
        st.warning(scope.get("error", "Choose a readable workbook to review its sheets."))
        return [], [scope.get("missing_entry", "a readable specification workbook")]
    options = [sheet["name"] for sheet in scope["sheets"] if sheet.get("selectable")]
    with st.expander("Choose which sheets belong in this product", expanded=True):
        st.caption(f"All {len(scope['sheets'])} worksheets are shown below. Several sheets can share one section. "
                   "Sections organize extraction; the study disease is checked separately.")
        overview = st.empty()
        st.caption("Included sheets are read together. Context-only and left-out sheets remain in the original workbook but do not supply variables.")
        saved = hint_status(scope, st.session_state)
        if saved.get("eligible"):
            st.info("Saved choices for this same workbook are ready for review. They have not been applied.")
            if saved["hint"]["sheets"]:
                st.write("Saved sheet exclusions: " + ", ".join(saved["hint"]["sheets"]))
            st.caption("Saved reason: " + (saved["hint"]["reason"] or "No reason entered yet."))
            if saved["hint"].get("sheet_mappings"):
                st.write("Saved sheet sections: " + "; ".join(f"{name}: {domain}" for name, domain in saved["hint"]["sheet_mappings"].items()))
                st.caption("Saved mapping reason: " + (saved["hint"].get("mapping_reason") or "No reason entered yet."))
            if st.session_state.get(SELECTION) or st.session_state.get(MAPPINGS):
                st.caption("Restoring replaces your current sheet sections and exclusions with the saved choices.")
            if st.button("Restore these sheet choices for review", key="np_sheet_scope_restore_hint"):
                restore_hint(scope, st.session_state, confirmed=True)
                st.session_state["np_sheet_scope_notice"] = "Saved sheet choices restored for review. Check the updated table before Preview."
                st.rerun()
        elif saved.get("available"):
            st.caption(saved.get("reason", "Review the current workbook before restoring saved sheet choices."))
        mappings = {}
        def choose_section(sheet):
            name = sheet["name"]
            existing = sheet.get("domain") or ""
            choices = list(scope["mapping_domains"]) if existing else ["", *scope["mapping_domains"]]
            domain = forms.field(st.selectbox, f"Specification section for {name}",
                choices, index=choices.index(existing), key=mapping_key(name), binding=scope["binding"],
                format_func=section_label,
                help="Choose the section described by this sheet. Several sheets may share a section. Corrections apply only to this product; original worksheet names and the shared template stay unchanged.")
            if domain and domain != existing:
                mappings[name] = domain
        for sheet in scope["sheets"]:
            if sheet.get("mapping_selectable") and not sheet.get("domain"):
                choose_section(sheet)
        detected = [sheet for sheet in scope["sheets"] if sheet.get("mapping_selectable") and sheet.get("domain")]
        if detected:
            with st.expander("Correct detected sheet sections"):
                st.caption("A recognized worksheet name supplies the initial section. Correct it here if this workbook uses that sheet differently.")
                for sheet in detected:
                    choose_section(sheet)
        st.session_state[MAPPINGS] = mappings
        mapping_reason = ""
        if mappings:
            mapping_reason = forms.field(st.text_input, "Why do these sheets belong to these sections?",
                key=MAPPING_REASON, binding=scope["binding"], max_chars=1000,
                help="Explain the specification's sheet layout. Preview shows these exact mappings before the product is created.").strip()
        options = [name for name in options if name not in mappings]
        if any(name not in options for name in st.session_state.get(SELECTION, [])):
            st.session_state[SELECTION] = [name for name in st.session_state.get(SELECTION, []) if name in options]
        if scope.get("inherited"):
            st.info("Previously left out: " + ", ".join(scope["inherited"]) + ". Select them again only if they are also out of scope for this revised specification.")
        if scope.get("missing_inherited"):
            st.caption("Previously excluded sheets absent from this workbook: " + ", ".join(scope["missing_inherited"]))
        selected, reason = [], ""
        if options:
            selected = forms.field(st.multiselect, "Sheets to leave out of this product", options,
                key=SELECTION, binding=scope["binding"],
                help="You can select several sheets. To leave out a sheet you assigned above, first choose No section assigned. Existing requirement sections remain included.")
            reason = forms.field(st.text_input, "Why are these sheets out of scope?", key=REASON,
                binding=scope["binding"], max_chars=1000,
                placeholder="For example: These sheets contain administrative notes, not product requirements.",
                help="This reason is required only when leaving out a sheet and appears in Preview.").strip()
        elif any(sheet.get("mapping_selectable") and not sheet.get("domain") for sheet in scope["sheets"]):
            st.caption("To leave out an additional sheet, first choose No section assigned in its dropdown above.")
        else:
            st.caption("All worksheets already have a place in the existing layout; no additional sheet choices are needed.")
        overview.table(sheet_overview(scope, st.session_state))
        st.caption("Existing requirement sections stay included; use Plan changes after creation to review changes to them. "
                   "A sheet choice does not approve definitions or change AI access.")
    args = [value for name in selected for value in ("--exclude-sheet", name)]
    if selected and reason:
        args.extend(["--exclude-sheet-reason", reason])
    args += [value for name, domain in mappings.items() for value in ("--sheet-domain", f"{name}={domain}")]
    if mappings and mapping_reason:
        args.extend(["--sheet-domain-reason", mapping_reason])
    missing = (["why the selected sheets are out of scope"] if selected and not reason else [])
    if mappings and not mapping_reason:
        missing.append("why the mapped sheets belong to the selected specification sections")
    return args, missing


def render(scope, *, root=None, actor_id=None, can_write=True, allowed_packs=None):
    """Review workbook layout with dropdowns before previewing registration."""
    import streamlit as st
    proposal = st.session_state.get("np_column_ai_proposal")
    if scope.get("ok") and root is not None:
        with st.expander("Ask the assistant to interpret this workbook layout"):
            st.caption("Suggest sheet sections and column meanings, then check them below. First complete the workbook's AI-access classification and reviewer name/date in this setup.")
            if st.button("Suggest this workbook's layout", key="np_layout_suggest", disabled=not can_write):
                from experiments.portal import workbook_mapping_ai
                with st.spinner("Preparing a workbook layout proposal…"):
                    result = workbook_mapping_ai.suggest_intake(root, actor_id, scope, st.session_state,
                        can_write=can_write, allowed_packs=allowed_packs)
                if result.get("ok"):
                    proposal = result["proposal"]
                    st.session_state["np_column_ai_proposal"] = proposal
                    selectable = {s["name"] for s in scope["sheets"] if s.get("mapping_selectable")}
                    for row in proposal["suggestions"]:
                        if row["domain"] and row["name"] in selectable:
                            st.session_state[mapping_key(row["name"])] = row["domain"]
                    st.session_state[MAPPING_REASON] = "Assistant-proposed worksheet sections, pending review in Preview."
                else:
                    for error in result.get("errors", []):
                        st.warning(error)
            if proposal:
                st.caption("Layout suggestion from " + str(proposal.get("model") or "the connected assistant") +
                           ". Section labels describe the layout; they do not verify the study disease.")
                st.table([{"Worksheet": row["name"], "Suggested section": section_label(row["domain"]),
                           "Why suggested": row["reason"]} for row in proposal["suggestions"]])
                if st.button("Discard suggestion and use detected columns", key="np_layout_discard", disabled=not can_write):
                    st.session_state.pop("np_column_ai_proposal", None)
                    st.session_state["np_column_confirmed"] = False
                    proposal = None
    args, missing = _render_sheets(scope)
    if not scope.get("ok"):
        return args, missing
    if root is not None:
        # Dropdown changes and AI suggestions occur after the first describe().
        # Recheck against the same bytes and current choices before setup renders.
        fresh = describe(root, st.session_state, allowed_packs=allowed_packs)
        if not fresh.get("ok") or fresh.get("binding") != scope.get("binding"):
            scope["ok"] = False
            scope["population"] = {}
            st.warning("The workbook changed or could not be read. Select it again and review its sheets before Preview.")
            return args, [*missing, "a current readable workbook and its sheet choices"]
        scope["population"] = fresh["population"]
    from rwd_tools import spec_extract
    from experiments.portal import workbook_column_editor
    with st.expander("Review workbook column meanings"):
        st.caption("Common headers are recognized automatically. Open a sheet below to correct its header row or column meanings. "
                   "You can reopen it before Preview. After creation, these settings remain editable under Definitions and sources → "
                   "Draft the scientific definition → Map workbook sheets to specification sections.")
        included = [s["name"] for s in scope["sheets"]
                    if (s.get("domain") or (st.session_state.get(MAPPINGS) or {}).get(s["name"]))
                    and s["name"] not in (st.session_state.get(SELECTION) or [])]
        # The public scope object is also used as chat metadata. Source cells
        # stay in this private, byte-bound UI cache and never enter that object.
        cached = st.session_state.get("np_wb_column_cache") or {}
        inspection = cached.get("sheets", []) if cached.get("sha256") == scope.get("sha256") else []
        choices = workbook_column_editor.render(inspection,
            prefix="np_column_" + (hashlib.sha256(json.dumps(proposal, sort_keys=True).encode()).hexdigest()[:10] if proposal else ""),
            editable=included, enabled=can_write,
            proposed={row["name"]: {"header_row": row["header_row"], "columns": row["columns"]}
                      for row in (proposal or {}).get("suggestions", [])})
        if choices:
            try:
                checked = spec_extract.parse_column_map(choices)
            except ValueError as error:
                st.error(str(error))
                missing.append("valid workbook column assignments")
            else:
                binding = hashlib.sha256(json.dumps(checked, sort_keys=True).encode()).hexdigest()
                prior = st.session_state.get("np_column_confirmed_digest")
                if prior and prior != binding:
                    st.session_state["np_column_confirmed"] = False
                    st.warning("The column choices changed. Review them in Preview before creating the product.")
                st.session_state["np_column_confirmed_digest"] = binding
                confirmed = st.checkbox("I checked these column meanings against the workbook.", key="np_column_confirmed")
                if confirmed:
                    args += ["--column-map", json.dumps(checked, ensure_ascii=True), "--column-map-reason",
                             "Confirmed the workbook header rows and column meanings in the intake preview."]
                    if proposal:
                        from experiments.portal import workbook_mapping_ai
                        try:
                            origin = workbook_mapping_ai.check_intake(proposal, root, actor_id, scope, st.session_state,
                                allowed_packs=allowed_packs)
                        except ValueError as error:
                            st.warning(str(error))
                            missing.append("a current workbook layout proposal")
                        else:
                            provenance = {name: origin[name] for name in ("kind", "provider", "model", "model_info", "proposal_sha256")}
                            args += ["--column-map-origin", json.dumps(provenance, ensure_ascii=True)]
                else:
                    missing.append("confirmation of the workbook column meanings")
    return args, missing
