"""Fresh authority checks for detached workers; saved attribution grants no access."""
from contextlib import contextmanager
from pathlib import Path
import os

from experiments.portal import authoring_session
from experiments.portal import identity

SOURCE_ROLES = {"admin", "initiator", "qc_programmer", "reviewer"}
WORKBOOK_ROLES = {"admin", "initiator", "reviewer"}


def capture_workbook(root, actor_id, pack, allowed_packs):
    """Bind model drafting to the requesting editor, not a worker's defaults."""
    current = authoring_session.CURRENT.get()
    mode = identity.mode(os.environ)
    if current is None and mode == "hosted":
        raise ValueError("Start workbook drafting from an authenticated application session.")
    if current is not None:
        authoring_session.check_scope(root, pack, actor_id)
        authoring_session.require_edit()
        if "agent" not in current.permissions or any(p not in current.packs for p in (allowed_packs or [])):
            raise ValueError("This session cannot request AI drafting for these products.")
        mode = current.mode
    authorize(root, actor_id, mode=mode, primary_pack=pack, allowed_packs=allowed_packs,
        roles=WORKBOOK_ROLES, action="workbook drafting")
    return {"mode": mode}


@contextmanager
def workbook_worker(value):
    saved = value.get("authority")
    if not isinstance(saved, dict) or set(saved) != {"mode"}:
        raise ValueError("This workbook request has no author binding. Start a fresh request.")
    authorize(value["root"], value["actor"], mode=saved["mode"],
        primary_pack=value["arguments"].get("pack"), allowed_packs=value["allowed_packs"],
        roles=WORKBOOK_ROLES, action="workbook drafting")
    token = authoring_session.bind(value["root"], value["actor"], value["allowed_packs"],
        {"view", "answer", "agent"}, mode=saved["mode"])
    try:
        yield
    finally:
        authoring_session.CURRENT.reset(token)


def authorize(root, actor_id, *, mode, primary_pack, allowed_packs, roles, action):
    selected = identity.mode(os.environ)
    if selected != mode:
        raise ValueError("The identity mode changed. Start a fresh request from the current session.")
    if selected == "local":
        current = identity.local_user(root)
        if (current.get("email") or current.get("name")) != actor_id:
            raise ValueError("The checkout owner changed. Review the request with the current owner.")
    else:
        path = Path(os.environ.get("RWDP_STATE_DIR") or Path(root) / "experiments/portal") / "users.json"
        roster, _ = identity.load_users(path, identity.default_users(selected == "demo",
            os.environ.get("RWD_PORTAL_BOOTSTRAP_ADMIN")))
        current = next((row for row in roster if (row.get("email") or row.get("name")) == actor_id), None)
        if current is None:
            raise ValueError("This requester is no longer in the current user roster.")
    if current.get("role") not in roles:
        raise ValueError("The current user role no longer permits " + action + ".")
    allowed = sorted(set(allowed_packs or []))
    if current.get("packs") and any(pack not in current["packs"] for pack in allowed):
        raise ValueError("Product access changed. Review the request within your current access.")
    if primary_pack not in allowed:
        raise ValueError("This request is outside your current product access.")
    return current


def capture_source(root, actor_id, pack, allowed_packs):
    current = authoring_session.CURRENT.get()
    if current is None:
        if identity.mode(os.environ) == "hosted":
            raise ValueError("Start hosted source creation from an authenticated application session.")
        return None  # Preserve explicit, unbound local CLI calls.
    authoring_session.check_scope(root, pack, actor_id)
    authoring_session.require_edit()
    if any(p not in current.packs for p in (allowed_packs or [])):
        raise ValueError("This request includes a product outside the authenticated session.")
    authorize(root, actor_id, mode=current.mode, primary_pack=pack,
        allowed_packs=allowed_packs, roles=SOURCE_ROLES, action="source editing")
    return {"mode": current.mode}


@contextmanager
def source_worker(value):
    saved = value.get("authority")
    if saved is None:
        if identity.mode(os.environ) == "hosted":
            raise ValueError("This saved source request has no authenticated binding. Review it and start a fresh request.")
        yield  # Historical local CLI calls do not acquire application authority.
        return
    mode = saved.get("mode") if isinstance(saved, dict) else None
    authorize(value["root"], value["actor"], mode=mode,
        primary_pack=value["arguments"].get("pack"), allowed_packs=value["allowed_packs"],
        roles=SOURCE_ROLES, action="source editing")
    token = authoring_session.bind(value["root"], value["actor"], value["allowed_packs"],
        {"view", "start"}, mode=mode)
    try:
        yield
    finally:
        authoring_session.CURRENT.reset(token)
