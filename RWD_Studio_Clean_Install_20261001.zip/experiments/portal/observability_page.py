"""Small administrator view over aggregate diagnostics, with no payload access."""
import streamlit as st
from rwd_services import observability


def render():
    current = observability.snapshot()
    st.caption('System health · ' + current['scope'])
    if not current['rows']:
        st.info('No instrumented operations have completed in this process yet.')
    else:
        st.dataframe([{ 'Operation': row['operation'], 'Result': row['outcome'], 'Count': row['count'],
                        'Average seconds': row['mean_seconds'], 'Longest seconds': row['max_seconds'],
                        '95% within seconds': row.get('p95_upper_seconds')} for row in current['rows']],
                      hide_index=True, width='stretch')
    st.caption(current['notice'])
    st.caption('A failed action shows a support identifier. Use it to find the matching hosting log entry.')
    st.download_button('Download aggregate metrics', observability.prometheus(),
                       file_name='rwd-metrics.txt', mime='text/plain', key='observability_export')
