"""Provision uploaded sources in Spark, with exact upload/mapping receipts.

Creating or profiling a runtime table never approves its scientific mapping.
The same functions accept an existing Spark session for execution tests and
connected deployments; the portal worker uses a persistent local catalog.
"""
from __future__ import annotations

import csv
from datetime import date, datetime, timezone
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re

from experiments.portal import source_table_intake as intake
from experiments.portal import source_workspace as workspace
from experiments.portal import scientific_definitions as definitions

STORE = 'config/source_provisioning.json'
TYPES = ('string', 'integer', 'long', 'double', 'boolean', 'date', 'timestamp')


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def _read(product):
    path = workspace._safe(product / STORE)
    if not path.exists():
        return {'version': 1, 'tables': {}}, ''
    raw = workspace._bytes(path)
    data = json.loads(raw)
    if data.get('version') != 1 or not isinstance(data.get('tables'), dict):
        raise ValueError('Restore the last valid source-provisioning record.')
    return data, hashlib.sha256(raw).hexdigest()


def describe(root, pack, actor_id, *, allowed_packs=None):
    info = intake.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not info['ok']:
        return info
    scope = workspace._scope(root, pack, actor_id, allowed_packs)
    data, digest = _read(scope[1])
    return {**info, 'provisioning_digest': digest, 'receipts': data['tables']}


def mapping(columns, choices):
    if not isinstance(choices, list) or len(choices) != len(columns):
        raise ValueError('Choose a runtime name and type for every uploaded column.')
    result, names = [], set()
    for source, choice in zip(columns, choices):
        if not isinstance(choice, dict) or choice.get('source') != source['name']:
            raise ValueError('The column mapping changed. Reload the imported headers.')
        target, dtype = choice.get('name'), choice.get('type')
        if (not isinstance(target, str) or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,127}', target)
                or target.casefold() in names or dtype not in TYPES):
            raise ValueError('Runtime names must be unique identifiers; choose one supported type per column.')
        names.add(target.casefold())
        result.append({'source': source['name'], 'name': target, 'type': dtype})
    return result


def _value(value, dtype):
    if value == '':
        return None
    if dtype == 'string':
        return value
    if dtype in {'integer', 'long'}:
        if not re.fullmatch(r'-?(?:0|[1-9][0-9]*)', value):
            raise ValueError()
        converted = int(value)
        bits = 32 if dtype == 'integer' else 64
        if not -(2 ** (bits - 1)) <= converted < 2 ** (bits - 1):
            raise ValueError()
        return converted
    if dtype == 'double':
        converted = float(value)
        if not math.isfinite(converted):
            raise ValueError()
        return converted
    if dtype == 'boolean':
        if value.casefold() not in {'true', 'false'}:
            raise ValueError()
        return value.casefold() == 'true'
    if dtype == 'date':
        return date.fromisoformat(value)
    if dtype == 'timestamp':
        return datetime.fromisoformat(value)
    raise ValueError()


def typed_rows(raw, columns):
    reader = csv.reader(io.StringIO(raw.decode('utf-8-sig')), delimiter='\t')
    headers = next(reader)
    if headers != [item['source'] for item in columns]:
        raise ValueError('The saved upload no longer matches its mapped headers.')
    rows = []
    for number, values in enumerate(reader, 2):
        if not values or all(value == '' for value in values):
            continue
        if len(values) != len(columns):
            raise ValueError(f'Row {number} does not match the uploaded headers.')
        record = []
        for cell, column in zip(values, columns):
            try:
                record.append(_value(cell, column['type']))
            except (ValueError, OverflowError):
                raise ValueError(f"Row {number}, column {column['source']}: the value does not fit {column['type']}. Edit its type or correct the source TSV.") from None
        rows.append(tuple(record))
    return rows


def runtime_session():
    from pyspark.sql import SparkSession
    if os.environ.get('SPARK_REMOTE'):
        return SparkSession.builder.getOrCreate()
    import sys
    from rwd_tools import java_home
    java_home.ensure()
    _windows_hadoop()
    base = Path(os.environ.get('RWDP_STATE_DIR') or Path(os.environ.get('LOCALAPPDATA') or Path.home()) / 'RwdPortal') / 'spark-runtime'
    base = base.resolve()
    base.mkdir(parents=True, exist_ok=True)
    (base / 'warehouse').mkdir(exist_ok=True)
    return (SparkSession.builder.master('local[1]').appName('rwd-source-provisioning')
        .config('spark.sql.warehouse.dir', (base / 'warehouse').as_uri())
        .config('spark.hadoop.javax.jdo.option.ConnectionURL', 'jdbc:derby:' + (base / 'metastore').as_posix() + ';create=true')
        .config('spark.sql.shuffle.partitions', '1').config('spark.sql.session.timeZone', 'UTC')
        .config('spark.ui.enabled', 'false').enableHiveSupport().getOrCreate())


def _windows_hadoop():
    """Find an already installed real helper before the JVM initializes Hive."""
    if os.name != 'nt':
        return
    import importlib.util
    spec = importlib.util.find_spec('pyspark')
    candidates = [Path(os.environ['HADOOP_HOME'])] if os.environ.get('HADOOP_HOME') else []
    if spec and spec.origin:
        candidates.append(Path(spec.origin).parent / 'tmp' / 'hadoop')
    for directory in candidates:
        if (directory / 'bin' / 'winutils.exe').is_file():
            os.environ['HADOOP_HOME'] = str(directory)
            return
    raise ValueError('Local Windows source profiling needs the native Hadoop helper for its persistent catalog. Ask IT to install the real winutils.exe under HADOOP_HOME/bin, or use the configured server Spark runtime. No table was created.')


def _quoted(name):
    intake._text_name(name, 'Runtime table', table=True)
    return '.'.join('`' + part + '`' for part in name.split('.'))


def _arrow_table(rows, columns):
    import pyarrow as pa
    types = {'string': pa.string(), 'integer': pa.int32(), 'long': pa.int64(), 'double': pa.float64(),
             'boolean': pa.bool_(), 'date': pa.date32(), 'timestamp': pa.timestamp('us')}
    schema = pa.schema([(c['name'], types[c['type']]) for c in columns])
    return pa.Table.from_pylist([dict(zip(schema.names, row)) for row in rows], schema=schema)


def _local_parquet(spark, target, rows, columns, identity, directory=None):
    """Write a small local upload portably, then register its typed Spark table.

    Arrow is already part of the pinned portal runtime. Using it for local
    Windows file creation avoids requiring native Hadoop binaries; all table
    reads, profiling, adapters and ADS calculations still execute in Spark.
    """
    import pyarrow.parquet as pq
    import tempfile
    base = Path(directory or os.environ.get('RWDP_STATE_DIR') or
                Path(os.environ.get('LOCALAPPDATA') or Path.home()) / 'RwdPortal')
    folder = workspace._safe(base / 'source-runtime' / identity)
    folder.mkdir(parents=True, exist_ok=True)
    frame = _arrow_table(rows, columns)
    path = folder / 'part-00000.parquet'
    if path.exists():
        if not pq.read_table(path).equals(frame):
            raise ValueError('The local source files changed. Choose a new runtime name and inspect the existing source.')
    else:
        fd, temporary = tempfile.mkstemp(prefix='.source-', suffix='.tmp', dir=folder)
        os.close(fd)
        try:
            pq.write_table(frame, temporary, compression='snappy', version='1.0')
            with open(temporary, 'r+b') as handle:
                os.fsync(handle.fileno())
            os.rename(temporary, path)
        finally:
            Path(temporary).unlink(missing_ok=True)
    sql_types = {'string': 'STRING', 'integer': 'INT', 'long': 'BIGINT', 'double': 'DOUBLE',
                 'boolean': 'BOOLEAN', 'date': 'DATE', 'timestamp': 'TIMESTAMP'}
    selection = ', '.join('CAST(`' + c['name'] + '` AS ' + sql_types[c['type']] + ') AS `' + c['name'] + '`' for c in columns)
    # Exact-file location avoids Hadoop's Windows native directory-listing
    # dependency; a source import is a single immutable small Parquet file.
    location = path.resolve().as_uri().replace('`', '``')
    # A persistent catalog view points at the exact file. Hive tables require a
    # directory location, which reintroduces Windows native directory access.
    spark.sql(f"CREATE VIEW {target} TBLPROPERTIES ('rwd.provisioning_identity'='{identity}') AS SELECT {selection} FROM parquet.`{location}`")
    return str(folder)


def materialize(spark, table, raw, columns, upload_digest, *, existing=False, local_directory=None):
    """Create once or profile an existing table. Never overwrite a runtime table."""
    from pyspark.sql import functions as F, types as T
    target = _quoted(table)
    identity = _digest({'upload': upload_digest, 'columns': columns, 'table': table})
    present = spark.catalog.tableExists(table)
    if existing:
        if not present:
            raise ValueError('The declared runtime table is unavailable. Create it from a data TSV or connect the correct runtime.')
        frame = spark.table(table)
        if frame.columns != [c['name'] for c in columns]:
            raise ValueError('The existing runtime table columns differ from this mapping. Update the column list or select the matching table.')
    else:
        if hashlib.sha256(raw).hexdigest() != upload_digest:
            raise ValueError('The saved upload changed; no runtime table was created.')
        rows = typed_rows(raw, columns)
        constructors = {'string': T.StringType, 'integer': T.IntegerType, 'long': T.LongType,
                        'double': T.DoubleType, 'boolean': T.BooleanType, 'date': T.DateType, 'timestamp': T.TimestampType}
        schema = T.StructType([T.StructField(c['name'], constructors[c['type']](), True) for c in columns])
        # Spark 4 consumes Arrow directly, without starting Python row workers
        # for a bounded upload or each idempotency comparison.
        expected_frame = spark.createDataFrame(_arrow_table(rows, columns), schema)
        if present:
            try:
                properties = {row['key']: row['value'] for row in spark.sql(f'SHOW TBLPROPERTIES {target}').collect()}
            except Exception:
                properties = {}
            if properties.get('rwd.provisioning_identity') != identity:
                raise ValueError('This runtime table already exists with another or unverified identity. Choose a new table name; existing data is never overwritten.')
            frame = spark.table(table)
            if (frame.schema.simpleString() != expected_frame.schema.simpleString()
                    or frame.exceptAll(expected_frame).limit(1).count()
                    or expected_frame.exceptAll(frame).limit(1).count()):
                raise ValueError('The previously provisioned table changed after its upload. Choose a new runtime table; the saved upload is not replaced.')
        else:
            frame = expected_frame
            # A failed post-create receipt leaves an unapproved table, never an
            # overwrite candidate. The table property binds safe explicit retry.
            if os.name == 'nt' and not os.environ.get('SPARK_REMOTE') and spark.sparkContext.master.startswith('local'):
                _local_parquet(spark, target, rows, columns, identity, local_directory)
            else:
                frame.write.mode('errorifexists').saveAsTable(table)
                spark.sql(f"ALTER TABLE {target} SET TBLPROPERTIES ('rwd.provisioning_identity'='{identity}')")
            frame = spark.table(table)
    observed = {field.name: field.dataType.simpleString() for field in frame.schema.fields}
    expected = {'integer': 'int', 'long': 'bigint', 'double': 'double', 'string': 'string',
                'boolean': 'boolean', 'date': 'date', 'timestamp': 'timestamp'}
    if any(observed.get(c['name']) != expected[c['type']] for c in columns):
        raise ValueError('Runtime types differ from the reviewed column mapping. Correct the declared types before profiling.')
    # Profile counts only; patient values do not enter shared metadata.
    counts = frame.select(F.count(F.lit(1)).alias('_rows'), *[
        F.sum(F.when(F.col('`' + c['name'] + '`').isNull(), 1).otherwise(0)).alias('_null_' + str(i)) for i, c in enumerate(columns)]).first().asDict()
    return {'runtime_table': table, 'identity': identity, 'upload_sha256': upload_digest,
            'columns': columns, 'rows': counts['_rows'], 'null_counts': {c['name']: counts['_null_' + str(i)] or 0 for i, c in enumerate(columns)},
            'observed_types': observed, 'stage': 'profiled', 'mapping_review': 'pending', 'existing_table': existing}


def execute(root, actor_id, *, pack, physical_table, runtime_table, columns, expected_inventory_digest,
            expected_provisioning_digest, existing=False, allowed_packs=None, spark=None):
    from experiments.portal import authoring_session
    authoring_session.require_edit()
    authoring_session.check_scope(root, pack, actor_id)
    scope = workspace._scope(root, pack, actor_id, allowed_packs)
    current = describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if (not current['ok'] or current['digest'] != expected_inventory_digest
            or current['provisioning_digest'] != expected_provisioning_digest):
        raise ValueError('Source inputs changed. Refresh the source table and review its mapping before starting.')
    table = next((t for t in current['tables'] if t['physical_table'] == physical_table), None)
    if table is None or (table['format'] == 'catalog' and not existing):
        raise ValueError('A column list describes an existing runtime table; upload data to create a new one.')
    selected = mapping(table['columns'], columns)
    raw = b''
    if not existing:
        if table['imported_by'] != actor_id:
            raise ValueError('Only the upload owner can create a table from these private bytes. Ask that person to create it, then choose Use an existing runtime table.')
        private = workspace._scope(root, pack, table['imported_by'], allowed_packs)[4]
        raw = workspace._bytes(private / 'table_uploads' / (table['sha256'] + '.tsv'))
    from experiments.portal.variable_review_workflow import _locked
    with _locked(scope[1] / STORE):
        latest = describe(root, pack, actor_id, allowed_packs=allowed_packs)
        if latest['digest'] != expected_inventory_digest or latest['provisioning_digest'] != expected_provisioning_digest:
            raise ValueError('Another source operation changed this mapping. Refresh before retrying.')
        owned = spark is None
        session = spark or runtime_session()
        try:
            receipt = materialize(session, runtime_table, raw, selected, table['sha256'], existing=existing)
        finally:
            if owned:
                session.stop()
        data, _digest_before = _read(scope[1])
        data['tables'][physical_table] = {**receipt, 'provisioned_by': actor_id,
            'provisioned_at': datetime.now(timezone.utc).isoformat(), 'source_mapping_approved': False}
        payload = json.dumps(data, indent=2, sort_keys=True, allow_nan=False).encode()
        def fresh():
            if intake._scope(root, pack, actor_id, allowed_packs)[3] != expected_inventory_digest or _read(scope[1])[1] != expected_provisioning_digest:
                raise ValueError('The source changed during execution. Runtime data remains unapproved; refresh and inspect it before retrying.')
        definitions._atomic(scope[1] / STORE, payload, check=fresh)
    return {'ok': True, 'changed': True, 'receipt': receipt, 'approval_created': False,
            'message': 'Runtime source is available and profiled. Complete its source-adapter review before ADS execution.'}


LOCAL_ADS_LIMIT = 100_000
LOCAL_BUILD_NOTICE = ('Local candidate from uploaded source tables. This is not a production release, '
                     'authenticated scientific approval or qualification of delivered data.')

LOCAL_PROFILE_PREFIX = 'uploaded:'


def _local_profile_inputs(root, pack, actor_id, allowed_packs):
    """Pin this private uploaded delivery without claiming a mapping or approval."""
    from experiments.portal import authoring_session, identity
    if identity.mode(os.environ) not in {'local', 'demo'} or os.environ.get('SPARK_REMOTE'):
        raise ValueError('Uploaded-source profiles are available only in the local development workspace.')
    authoring_session.check_scope(root, pack, actor_id)
    scope = workspace._scope(root, pack, actor_id, allowed_packs)
    cfg, identity_record = workspace._identity(scope[1])
    if cfg.source_union:
        raise ValueError('A source union needs its configured server profile.')
    if any(workspace._stem_unstated(identity_record[field]) for field in ('product_id', 'schema', 'cut')):
        raise ValueError('Declare the source delivery schema and cut before preparing its uploaded-source profile.')
    current = describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not current.get('ok') or not current.get('tables'):
        raise ValueError('; '.join(current.get('errors') or ['Import source TSVs first.']))
    sources, runtime_names = {}, set()
    for table in current['tables']:
        name = table['physical_table']
        receipt = current['receipts'].get(name) or {}
        if table['format'] != 'data' or table['imported_by'] != actor_id:
            raise ValueError(f'{name}: this local profile requires data TSVs owned by the current profile.')
        if (receipt.get('existing_table') is not False or receipt.get('upload_sha256') != table['sha256']
                or receipt.get('identity') != _digest({'upload': table['sha256'],
                    'columns': receipt.get('columns'), 'table': receipt.get('runtime_table')})):
            raise ValueError(f'{name}: create and profile the current upload before preparing the full profile.')
        columns = mapping(table['columns'], receipt.get('columns'))
        target = receipt.get('runtime_table')
        intake._text_name(target, 'Runtime table', table=True)
        qualified = target if '.' in target else 'default.' + target
        if qualified.rsplit('.', 1)[0] != identity_record['schema']:
            raise ValueError(f'{name}: its runtime table must belong to the declared delivery schema.')
        if qualified.casefold() in runtime_names:
            raise ValueError('Each uploaded table must have a distinct runtime table.')
        runtime_names.add(qualified.casefold())
        if type(receipt.get('rows')) is not int or not 0 <= receipt['rows'] <= LOCAL_ADS_LIMIT:
            raise ValueError(f'{name}: use the server profile above {LOCAL_ADS_LIMIT:,} rows.')
        raw = workspace._bytes(scope[4] / 'table_uploads' / (table['sha256'] + '.tsv'))
        if hashlib.sha256(raw).hexdigest() != table['sha256']:
            raise ValueError(f'{name}: the original uploaded file changed.')
        sources[name] = {'table': table, 'receipt': receipt, 'raw': raw,
                         'qualified_table': qualified, 'columns': columns}
    binding = {'root': str(scope[0]), 'pack': pack, 'owner': scope[3],
               'identity': identity_record, 'configuration': _digest(cfg.raw),
               'inventory': current['digest'], 'provisioning': current['provisioning_digest']}
    return scope, identity_record, sources, binding


def local_profile_preview(root, pack, actor_id, *, allowed_packs=None):
    try:
        _scope, _identity, sources, binding = _local_profile_inputs(root, pack, actor_id, allowed_packs)
        return {'ok': True, 'digest': _digest(binding), 'tables': len(sources), 'errors': []}
    except (ValueError, OSError, KeyError, TypeError) as error:
        return {'ok': False, 'digest': '', 'tables': 0, 'errors': [str(error)]}


def _local_profile_tsv(identity_record, sources, observed_rows):
    """Full column/row coverage; raw category labels remain private and omitted."""
    from rwd_tools import profile_io
    output = io.StringIO(newline='')
    writer = csv.DictWriter(output, fieldnames=profile_io.REQUIRED + profile_io.PROVENANCE + ['type', 'summary'],
                            delimiter='\t', lineterminator='\n')
    writer.writeheader()
    for name, item in sources.items():
        rows = observed_rows[name]
        for index, column in enumerate(item['columns']):
            values = [row[index] for row in rows if row[index] is not None]
            date_values = [(value.astimezone(timezone.utc).date() if isinstance(value, datetime) else value).isoformat()
                           for value in values] if column['type'] in {'date', 'timestamp'} else []
            kind = ('date' if column['type'] in {'date', 'timestamp'} else 'numeric'
                    if column['type'] in {'integer', 'long', 'double'} else 'categorical')
            writer.writerow({'table': item['qualified_table'],
                'table_base': profile_io.CUT.sub('', item['qualified_table'].rsplit('.', 1)[-1]),
                'column': column['name'], 'kind': kind, 'sampled': 'FALSE',
                'n_rows': len(rows), 'n_rows_total': len(rows),
                'pct_missing': 100 * (len(rows) - len(values)) / len(rows) if rows else '',
                'distinct': len(set(values)), 'date_min': min(date_values) if date_values else '',
                'date_max': max(date_values) if date_values else '', 'top_values': '',
                'profile_product_id': identity_record['product_id'], 'profile_schema': identity_record['schema'],
                'profile_cut': identity_record['cut'], 'profile_source_mode': 'local_uploaded',
                'profile_mode': 'full', 'type': item['receipt']['observed_types'][column['name']],
                'summary': 'All uploaded rows and columns measured; category labels withheld. Local mapping evidence only.'})
    return output.getvalue().encode('utf-8')


def prepare_local_profile(root, actor_id, *, pack, expected_digest, allowed_packs=None, spark=None):
    from experiments.portal import authoring_session, portal_runtime
    from rwd_tools import profile_io
    import uuid
    authoring_session.require_edit()
    scope, identity_record, sources, binding = _local_profile_inputs(root, pack, actor_id, allowed_packs)
    if _digest(binding) != expected_digest:
        raise ValueError('The uploaded sources or delivery changed. Check profile readiness again.')
    session, owned, snapshots = spark, spark is None, {}
    def fresh():
        if portal_runtime.job_cancelled():
            raise ValueError('Source profiling cancelled. No completed profile was recorded.')
        if _local_profile_inputs(root, pack, actor_id, allowed_packs)[3] != binding:
            raise ValueError('The uploaded sources or delivery changed during profiling. Prepare a fresh profile.')
    try:
        portal_runtime.job_progress('Checking every runtime row and type against the immutable uploaded sources.')
        session = session or runtime_session()
        _verify_local_sources(session, sources, snapshots=snapshots)
        fresh()
        portal_runtime.job_progress('Measuring every uploaded table and column for mapping review.')
        observed = {name: snapshots[item['receipt']['runtime_table']].collect() for name, item in sources.items()}
        raw = _local_profile_tsv(identity_record, sources, observed)
        if len(raw) > workspace.LIMIT:
            raise ValueError('This profile exceeds the local metadata limit. Use the configured server profiler.')
        identifier = uuid.uuid4().hex
        folder = workspace._safe(scope[4] / 'uploaded_profiles')
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / (identifier + '.tsv')
        definitions._atomic(path, raw, check=fresh)
        try:
            try:
                _tables, cuts = profile_io.load(str(path))
            except SystemExit:
                raise ValueError('The generated profile failed the canonical metadata checks; no completed profile was recorded.') from None
            if cuts and cuts != {identity_record['cut']}:
                raise ValueError('Runtime table suffixes do not match the declared delivery cut.')
            receipt = {'version': 1, 'id': identifier, 'binding': binding,
                       'profile_sha256': hashlib.sha256(raw).hexdigest(), 'source_mode': 'local_uploaded'}
            definitions._atomic(folder / (identifier + '.json'), json.dumps(receipt, sort_keys=True).encode(), check=fresh)
        except BaseException:
            path.unlink(missing_ok=True)
            raise
        return {'ok': True, 'profile': LOCAL_PROFILE_PREFIX + identifier, 'tables': len(sources),
                'columns': sum(len(item['columns']) for item in sources.values()),
                'approval_created': False, 'source_mode': 'local_uploaded',
                'message': 'Uploaded-source profile recorded. Review mappings next; production source evidence and approvals remain separate.'}
    finally:
        for frame in snapshots.values():
            frame.unpersist()
        if owned and session is not None:
            session.stop()


def read_local_profile(root, pack, actor_id, name, *, allowed_packs=None):
    from rwd_tools import profile_io
    if not isinstance(name, str) or not re.fullmatch(r'uploaded:[a-f0-9]{32}', name):
        raise ValueError('Choose a completed uploaded-source profile from this product.')
    scope, identity_record, _sources, binding = _local_profile_inputs(root, pack, actor_id, allowed_packs)
    identifier = name[len(LOCAL_PROFILE_PREFIX):]
    folder = workspace._safe(scope[4] / 'uploaded_profiles')
    record = json.loads(workspace._bytes(folder / (identifier + '.json')))
    path = folder / (identifier + '.tsv')
    raw = workspace._bytes(path)
    digest = hashlib.sha256(raw).hexdigest()
    if (not isinstance(record, dict) or record.get('version') != 1 or record.get('id') != identifier or record.get('binding') != binding
            or record.get('source_mode') != 'local_uploaded' or record.get('profile_sha256') != digest):
        raise ValueError('The uploaded-source profile no longer matches this product, delivery or source bytes. Prepare it again.')
    tables, cuts = profile_io.load(str(path))
    provenance = profile_io.provenance(tables)
    wanted = {key: identity_record[key] for key in ('product_id', 'schema', 'cut')}
    if (provenance != {**wanted, 'source_mode': 'local_uploaded', 'mode': 'full'}
            or cuts and cuts != {identity_record['cut']}):
        raise ValueError('The uploaded-source profile has a different product, schema, cut or provenance.')
    return path, tables, provenance, digest


def _local_review_errors(base, product, pack):
    """Require the existing bound review forms; this creates no approval claim."""
    from rwd_tools import product_gates as gates
    required = (gates.CONTRACT_APPROVAL, gates.CONFIGURATION_APPROVAL, gates.SPEC_QC,
                'spec_pipeline/out/extracted.json', 'spec_pipeline/out/COVERAGE.md', 'handoff/DECISIONS.md')
    missing = [name for name in required if not (product / name).is_file()]
    if missing:
        return ['Complete the scientific and configuration review forms first: ' + ', '.join(missing)]
    # Evaluate the actual bound forms at their intended level, even when the
    # separate maturity label has not been refreshed. No maturity file is changed.
    levels = {'contract': 'approved', 'configuration': 'approved'}
    return [str(error) for error in (
        gates.contract_approval_errors(str(product), pack, levels, root=str(base))
        + gates.configuration_approval_errors(str(product), pack, levels))]


def _local_build_inputs(root, pack, actor_id, allowed_packs):
    """Resolve the same configuration/adapter contracts as the native runner."""
    from experiments.portal import authoring_session, identity
    from engine.config import load_config
    from engine import validate
    from rwd_tools import contract_binding, contract_lint, decision_record, source_adapter
    if identity.mode(os.environ) not in {'local', 'demo'} or os.environ.get('SPARK_REMOTE'):
        raise ValueError('Uploaded-source candidate builds are available only in the local development workspace.')
    authoring_session.check_scope(root, pack, actor_id)
    scope = workspace._scope(root, pack, actor_id, allowed_packs)
    base, product = scope[:2]
    current = describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not current['ok']:
        raise ValueError('; '.join(current.get('errors') or ['Import the source tables first.']))
    cfg = load_config(product / 'config/data_product.yaml')
    validate.check(cfg, strict=True)
    plan = source_adapter.compiled(str(product))
    if plan.get('state') != 'compiled' or plan.get('problems'):
        raise ValueError('Review every source adapter before building: ' + '; '.join(
            plan.get('problems') or ['Map source tables and columns, then record the source review.']))
    if cfg.source_union:
        raise ValueError('This local build supports one uploaded delivery. A source union needs the configured server build.')
    if str(plan.get('schema')) != str(cfg.source_schema) or str(plan.get('cut')) != str(cfg.refresh):
        raise ValueError('The reviewed source adapter schema/cut differs from the current delivery. Correct the delivery or review its mapping again.')
    errors, stats = contract_binding.check(str(product), contract_binding.pack_yaml(str(product)),
                                          require_complete=True)
    if not stats.get('records'):
        errors.insert(0, 'Save the scientific definitions and bind their executable configuration first.')
    else:
        records = contract_lint.typed_records(contract_lint.read(str(product / 'handoff/FUNCTIONAL_CONTRACT.md')))
        unsettled = [record.variable_id for record in records if record.status.get('requirement') != 'approved']
        if unsettled:
            errors.append('Complete the explicit scientific requirement review: ' + ', '.join(unsettled[:12]))
    blocks = contract_binding.governed_blocks(str(product), contract_binding.pack_yaml(str(product)))
    parameters, _compared = contract_binding.compare_parameters(str(product), blocks)
    errors.extend(parameters)
    # Match the current-source comparison used by complete configuration review;
    # a saved enumeration draft is not the reviewed source for build admission.
    errors.extend(contract_binding.compare_enumerations(str(product), blocks, current_extraction=True))
    opened = contract_lint.open_decisions(str(product))
    if opened:
        errors.append('Answer the recorded scientific questions before building: ' + ', '.join(sorted(opened)))
    errors.extend(decision_record.check_bindings(pack, root=str(base)))
    if errors:
        raise ValueError('Review the scientific/configuration binding: ' + '; '.join(map(str, errors[:12])))
    reviews = _local_review_errors(base, product, pack)
    if reviews:
        raise ValueError('Review the current approval evidence: ' + '; '.join(reviews[:12]))
    tables = {item['physical_table']: item for item in current['tables']}
    sources = {}
    for role in cfg.sources:
        target = plan.get('bindings', {}).get(role)
        if not target or target != cfg.table(role):
            raise ValueError(f'{role}: the configuration and reviewed adapter must name the same runtime table.')
        matches = [(name, receipt) for name, receipt in current['receipts'].items()
                   if receipt.get('runtime_table') == target]
        if len(matches) != 1:
            raise ValueError(f'{role}: create and profile its uploaded source table before building.')
        name, receipt = matches[0]
        table = tables.get(name)
        if (not table or table.get('format') != 'data' or receipt.get('existing_table') is not False
                or receipt.get('upload_sha256') != table.get('sha256')
                or receipt.get('identity') != _digest({'upload': table['sha256'],
                    'columns': receipt.get('columns'), 'table': target})):
            raise ValueError(f'{role}: this runtime source does not have a current immutable upload binding. Import and provision it again under a new name.')
        if table['imported_by'] != actor_id:
            raise ValueError(f'{role}: its upload belongs to another profile. Run this private local candidate with the upload owner; shared deliveries require the configured server build.')
        if type(receipt.get('rows')) is not int or not 0 <= receipt['rows'] <= LOCAL_ADS_LIMIT:
            raise ValueError(f'{role}: use the server build for a source exceeding {LOCAL_ADS_LIMIT:,} rows.')
        private = workspace._scope(root, pack, table['imported_by'], allowed_packs)[4]
        raw = workspace._bytes(private / 'table_uploads' / (table['sha256'] + '.tsv'))
        if hashlib.sha256(raw).hexdigest() != table['sha256']:
            raise ValueError(f'{role}: the original upload changed; no candidate was built.')
        sources[role] = {'table': table, 'receipt': receipt, 'raw': raw}
    cfg.bind_sources(plan['bindings'], plan['digest'], plan['dataset'],
                     roles=plan['roles'], mapping_digest=plan.get('mapping_digest'))
    validate.check(cfg, strict=True)
    from rwd_tools import local_smoke
    # Reuse the code/config identity inventory only, never its synthetic source generator.
    inputs = {'engine': local_smoke.input_manifest(product, root=base),
              'workspace': workspace._inputs(base, product),
              'inventory': current['digest'], 'provisioning': current['provisioning_digest'],
              'source_identities': {role: value['receipt']['identity'] for role, value in sources.items()}}
    return scope, cfg, sources, inputs


def local_build_preview(root, pack, actor_id, *, allowed_packs=None):
    """No Spark startup and no approval write; admission is repeated by the worker."""
    try:
        scope, cfg, sources, inputs = _local_build_inputs(root, pack, actor_id, allowed_packs)
        return {'ok': True, 'digest': _digest(inputs), 'errors': [],
                'sources': [{'role': role, 'table': item['receipt']['runtime_table'],
                             'rows': item['receipt']['rows']} for role, item in sources.items()],
                'cohorts': len(cfg.cohorts), 'notice': LOCAL_BUILD_NOTICE}
    except (ValueError, OSError, KeyError, TypeError, RuntimeError) as error:
        return {'ok': False, 'digest': '', 'errors': [str(error)], 'notice': LOCAL_BUILD_NOTICE}


def _source_row_key(row, columns, *, observed=False):
    """Match timestamps by instant, including offsets in the original TSV."""
    from pyspark.sql.types import TimestampType
    values = []
    for value, column in zip(row, columns):
        if value is not None and column['type'] == 'timestamp':
            # Arrow provisions naive input timestamps in the session's UTC zone.
            # Spark's Python collector represents instants in host-local naive time.
            value = TimestampType().toInternal(value if observed or value.tzinfo else value.replace(tzinfo=timezone.utc))
        values.append(value)
    return tuple(values)


def _arrow_result(value, datatype):
    """Preserve native timestamp instants when retaining collected rows in Arrow."""
    from pyspark.sql import types as types
    if value is None:
        return None
    if isinstance(datatype, types.TimestampType):
        from datetime import timedelta
        return datetime(1970, 1, 1) + timedelta(microseconds=datatype.toInternal(value))
    if isinstance(datatype, types.StructType):
        values = value.asDict() if hasattr(value, 'asDict') else value
        return {field.name: _arrow_result(values[field.name], field.dataType) for field in datatype.fields}
    if isinstance(datatype, types.ArrayType):
        return [_arrow_result(item, datatype.elementType) for item in value]
    if isinstance(datatype, types.MapType):
        return {_arrow_result(key, datatype.keyType): _arrow_result(item, datatype.valueType) for key, item in value.items()}
    return value


def _verify_local_sources(spark, sources, *, snapshots=None):
    """Read the actual catalog tables and compare every row to the immutable uploads."""
    from collections import Counter
    lineage = {}
    for role, item in sources.items():
        receipt, raw = item['receipt'], item['raw']
        name, columns = receipt['runtime_table'], receipt['columns']
        if not spark.catalog.tableExists(name):
            raise ValueError(f'{role}: the provisioned runtime table is missing. Reopen Source tables; this build will not create or substitute one.')
        properties = {row['key']: row['value'] for row in spark.sql('SHOW TBLPROPERTIES ' + _quoted(name)).collect()}
        if properties.get('rwd.provisioning_identity') != receipt['identity']:
            raise ValueError(f'{role}: runtime source identity changed. Re-profile and review the changed delivery.')
        frame = spark.table(name)
        if snapshots is not None:
            # This eager native snapshot truncates the mutable catalog plan. Every
            # row checked below is the same row supplied to QC and the native loader.
            frame = frame.localCheckpoint(eager=True)
            snapshots[name] = frame  # Include a refused table in caller cleanup too.
        observed = {field.name: field.dataType.simpleString() for field in frame.schema.fields}
        expected_rows = typed_rows(raw, columns)
        if (frame.columns != [c['name'] for c in columns] or observed != receipt['observed_types']
                or Counter(_source_row_key(row, columns, observed=True) for row in frame.limit(LOCAL_ADS_LIMIT + 1).collect())
                   != Counter(_source_row_key(row, columns) for row in expected_rows)):
            raise ValueError(f'{role}: runtime source values or types changed after provisioning. No current candidate can be recorded.')
        lineage[role] = [{'fqn': name, 'upload_sha256': receipt['upload_sha256'],
                          'provisioning_identity': receipt['identity'], 'rows': len(expected_rows),
                          'observed_types': observed, 'kind': 'local_uploaded_table'}]
    return lineage


def local_build(root, actor_id, *, pack, expected_digest, allowed_packs=None, spark=None):
    """Build a private non-release candidate with the native loader, never fixtures."""
    import uuid
    import pyarrow as pa
    import pyarrow.parquet as pq
    from experiments.portal import authoring_session, portal_runtime
    from engine import build_ads, dictionary, output_contract, product_catalog, qc, refresh, validate
    from engine.config import load_yaml, shared_asset
    from rwd_tools import contract_binding
    authoring_session.require_edit()
    authoring_session.check_scope(root, pack, actor_id)
    scope, cfg, sources, inputs = _local_build_inputs(root, pack, actor_id, allowed_packs)
    if not isinstance(expected_digest, str) or _digest(inputs) != expected_digest:
        raise ValueError('The reviewed build inputs changed. Check local build readiness again before starting.')
    identifier = uuid.uuid4().hex
    directory = workspace._safe(scope[4] / 'local-builds' / identifier)
    owned, session = spark is None, None
    def checkpoint(message):
        if portal_runtime.job_cancelled():
            raise ValueError('Local candidate cancelled. No candidate is recorded as complete.')
        portal_runtime.job_progress(message)
    try:
        checkpoint('Checking the uploaded runtime tables against their recorded source bytes.')
        session = spark or runtime_session()
        build_ads._local_checkpoint_session(session)
        from types import SimpleNamespace
        from engine.stages import sources as source_loader
        snapshots = {}
        lineage = _verify_local_sources(session, sources, snapshots=snapshots)
        # A narrow table reader cannot fall back to the live catalog for an
        # undeclared name. The native loader still applies every reviewed cast,
        # rename and index model to the observed, frozen runtime rows.
        reader = SimpleNamespace(table=lambda name: snapshots[name])
        try:
            validate.preflight(session, cfg, _table_reader=lambda name: {
                field.name: field.dataType.simpleString() for field in snapshots[name].schema.fields})
        except RuntimeError as error:
            raise ValueError('Review the source adapter columns and types. ' + str(error)) from error
        checkpoint('Checking source values and the reviewed parsing rules.')
        source_report = qc.run_source_qc(reader, cfg)
        source_verdict = qc.source_qc_gate(source_report, (cfg.raw.get('qc') or {}).get('source_thresholds'))
        if not source_verdict.get('passed'):
            raise ValueError('Source quality needs review: ' + '; '.join(source_verdict.get('failures') or ['Source checks did not pass.']))
        checkpoint('Building the ADS from the reviewed uploaded tables.')
        ads = build_ads.build_from_sources(source_loader.load(reader, cfg), cfg, local_cohort_checkpoints=True)
        ads = ads.localCheckpoint(eager=False)
        rows = ads.limit(LOCAL_ADS_LIMIT + 1).collect()
        if len(rows) > LOCAL_ADS_LIMIT:
            raise ValueError(f'The local candidate exceeds {LOCAL_ADS_LIMIT:,} rows. Use the configured server build.')
        if not rows:
            raise ValueError('No patients matched this configuration. Review its index, eligibility and source coverage; this is not a completed candidate.')
        checkpoint('Checking the candidate output contract and preparing its dictionary.')
        report = output_contract.run_output_contract(session, ads, cfg)
        verdict = output_contract.output_contract_gate(report)
        if not verdict.get('passed'):
            raise ValueError('The output contract needs review: ' + json.dumps(verdict, default=str))
        quality = qc.run_qc(session, ads, cfg)
        quality_verdict = qc.qc_gate(quality, qc.qc_thresholds(cfg))
        if not quality_verdict.get('passed'):
            raise ValueError('Candidate quality needs review: ' + '; '.join(quality_verdict.get('failures') or ['Dataset checks did not pass.']))
        catalog = product_catalog.merge(cfg, load_yaml(str(shared_asset(scope[0] / 'products', 'catalog'))))
        missing_dictionary = product_catalog.dictionary_coverage(cfg, catalog, ads.columns,
            tumor=contract_binding.tumour_code(str(scope[1])))
        if missing_dictionary:
            raise ValueError('Complete the reviewed output dictionary for: ' + ', '.join(missing_dictionary))
        dictionary_doc = dictionary.build_dictionary(catalog, tumor=contract_binding.tumour_code(str(scope[1])),
                                                      columns=ads.columns)
        # Record the observed output schema even for emitted columns lacking catalogue prose.
        dictionary_doc['observed_schema'] = [{'name': f.name, 'type': f.dataType.simpleString(),
                                              'nullable': f.nullable} for f in ads.schema.fields]
        checkpoint('Rechecking source and configuration freshness before retaining the candidate.')
        _new_scope, _new_cfg, _new_sources, after = _local_build_inputs(root, pack, actor_id, allowed_packs)
        if _digest(after) != expected_digest or _verify_local_sources(session, _new_sources) != lineage:
            raise ValueError('Source or configuration changed while the build ran. Check readiness and build again.')
        checkpoint('Saving the private candidate and its unchanged input identities.')
        directory.mkdir(parents=True, exist_ok=False)
        # Native Spark computed every cell. Arrow only writes the bounded local result,
        # preserving the observed Spark schema through its own Arrow converter.
        from pyspark.sql.pandas.types import to_arrow_schema
        table = pa.Table.from_pylist([_arrow_result(row, ads.schema) for row in rows], schema=to_arrow_schema(ads.schema))
        pq.write_table(table, directory / 'ads.parquet')
        (directory / 'dictionary.json').write_text(json.dumps(dictionary_doc, indent=2, default=str), encoding='utf-8')
        schema_text = '\n\n## Observed output schema\n\nEvery retained column is listed below. Scientific descriptions come from the reviewed catalogue above.\n\n| Column | Runtime type | Nullable |\n| --- | --- | --- |\n'
        schema_text += '\n'.join('| ' + ' | '.join((field['name'].replace('|', '\\|'),
            field['type'].replace('|', '\\|'), str(field['nullable']))) + ' |' for field in dictionary_doc['observed_schema'])
        (directory / 'dictionary.md').write_text(dictionary.render_markdown(dictionary_doc) + schema_text, encoding='utf-8')
        (directory / 'output-contract.json').write_text(json.dumps(report, indent=2, default=str), encoding='utf-8')
        (directory / 'source-checks.json').write_text(json.dumps(source_report, indent=2, default=str), encoding='utf-8')
        (directory / 'dataset-checks.json').write_text(json.dumps(quality, indent=2, default=str), encoding='utf-8')
        files = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in directory.iterdir()}
        manifest = refresh.build_manifest(cfg, tumor=contract_binding.tumour_code(str(scope[1])),
            counts={'rows': len(rows), 'columns': len(ads.columns)}, output_contract=verdict,
            source_lineage=lineage, adapter_binding=cfg.adapter_binding, runtime=refresh.runtime_versions(session),
            source_qc=source_report, source_qc_gate=source_verdict,
            qc=quality_verdict,
            config_identity={'local_inputs_sha256': expected_digest},
            run_mode={'env': 'local', 'release_grade': False, 'source_mode': 'uploaded_tables'},
            artifacts=files, deliverables={'dictionary': {'status': 'ok', 'audiences': ['internal']}},
            content={'parquet_sha256': files['ads.parquet']})
        manifest.update(local_build_id=identifier, pack=pack, source_mode='uploaded_tables',
                        status='local_candidate', published_at=None, approval_created=False,
                        inputs=inputs, source_read_mode='eager_local_catalog_snapshots', notice=LOCAL_BUILD_NOTICE)
        checkpoint('Candidate files are ready; finalizing the local manifest.')
        payload = json.dumps(manifest, indent=2, default=str).encode()
        def still_current():
            checkpoint('Verifying the saved review inputs at candidate completion.')
            _scope_after, _cfg_after, _sources_after, final_inputs = _local_build_inputs(root, pack, actor_id, allowed_packs)
            if _digest(final_inputs) != expected_digest:
                raise ValueError('The reviewed inputs changed before candidate completion. Check readiness and build again.')
        definitions._atomic(directory / 'manifest.json', payload, check=still_current)
        return {'ok': True, 'changed': False, 'build_id': identifier, 'rows': len(rows),
                'columns': len(ads.columns), 'manifest_sha256': hashlib.sha256(payload).hexdigest(),
                'inputs_sha256': expected_digest,
                'source_mode': 'uploaded_tables', 'approval_created': False,
                'output': f'Local candidate built: {len(rows):,} rows, {len(ads.columns)} columns. ' + LOCAL_BUILD_NOTICE}
    finally:
        if owned and session is not None:
            gateway = session.sparkContext._gateway
            try:
                session.stop()
            finally:
                gateway.shutdown()


def local_build_file(root, pack, actor_id, build_id, filename, *, expected_manifest_sha256, allowed_packs=None):
    """Only this actor's completed private artifacts, verified against the manifest."""
    from experiments.portal import authoring_session
    authoring_session.check_scope(root, pack, actor_id)
    if not isinstance(build_id, str) or not re.fullmatch(r'[a-f0-9]{32}', build_id):
        raise ValueError('Choose a recorded local candidate.')
    if filename not in {'manifest.json', 'dictionary.json', 'dictionary.md', 'output-contract.json', 'source-checks.json', 'dataset-checks.json', 'ads.parquet'}:
        raise ValueError('Choose an available local candidate artifact.')
    folder = workspace._scope(root, pack, actor_id, allowed_packs)[4] / 'local-builds' / build_id
    manifest_raw = workspace._bytes(folder / 'manifest.json')
    if hashlib.sha256(manifest_raw).hexdigest() != expected_manifest_sha256:
        raise ValueError('The local candidate manifest changed after this job. Use its unchanged retained evidence.')
    manifest = json.loads(manifest_raw)
    if (manifest.get('local_build_id') != build_id or manifest.get('pack') != pack
            or manifest.get('source_mode') != 'uploaded_tables' or manifest.get('approval_created') is not False):
        raise ValueError('The candidate record does not match this product.')
    if filename == 'manifest.json':
        return manifest_raw
    path = workspace._safe(folder / filename)
    if not path.is_file() or path.stat().st_size > 128 * 1024 * 1024:
        raise ValueError('This candidate artifact is unavailable or too large for browser download.')
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != manifest['artifacts'].get(filename):
        raise ValueError('This candidate artifact changed after the build. Use the unchanged retained copy.')
    return raw
