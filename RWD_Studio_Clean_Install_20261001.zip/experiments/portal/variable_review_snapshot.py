"""Immutable read snapshots. Filesystem hints never authorize a write.

The authoring service still hashes every byte before and during a mutation.
Read snapshots use change metadata to avoid repeatedly parsing and hashing an
unchanged tree. A short maximum age also covers filesystems with coarse clocks.
"""
from collections import OrderedDict
from contextlib import contextmanager
from contextvars import ContextVar
from functools import lru_cache
import os
from pathlib import Path
from threading import RLock
from time import monotonic

_READING = ContextVar("variable_review_snapshot_reading", default=False)
_CACHE = OrderedDict()
_LOCK = RLock()
MAX_ENTRIES = 16
MAX_AGE_SECONDS = 3.0


class SnapshotChanged(ValueError):
    """An interrupted read can be retried; it never relaxes a write check."""
    code = "review_snapshot_changed"


@contextmanager
def read_scope():
    token = _READING.set(True)
    try:
        yield
    finally:
        _READING.reset(token)


@contextmanager
def verification_scope():
    token = _READING.set(False)
    try:
        yield
    finally:
        _READING.reset(token)


def clear(product=None):
    with _LOCK:
        if product is None:
            _CACHE.clear()
        else:
            _CACHE.pop(str(Path(product)), None)


@lru_cache(maxsize=1)
def _windows_api():
    import ctypes
    from ctypes import wintypes
    class BasicInfo(ctypes.Structure):
        _fields_ = [(name, ctypes.c_longlong) for name in
                    ("creation", "access", "write", "change")] + [("attributes", wintypes.DWORD)]
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
        ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    kernel.CreateFileW.restype = wintypes.HANDLE
    kernel.GetFileInformationByHandleEx.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    return kernel, BasicInfo


def _windows_change_time(path):
    """Windows st_ctime is creation time, not last metadata/content change."""
    if os.name != "nt":
        return None
    import ctypes
    kernel, BasicInfo = _windows_api()
    handle = kernel.CreateFileW(str(path), 0x80, 7, None, 3, 0x02000000, None)
    if handle == ctypes.c_void_p(-1).value:
        return None
    try:
        result = BasicInfo()
        return result.change if kernel.GetFileInformationByHandleEx(handle, 0, ctypes.byref(result), ctypes.sizeof(result)) else None
    finally:
        kernel.CloseHandle(handle)


def _stamp(path):
    try:
        stat = path.stat(follow_symlinks=False)
    except FileNotFoundError:
        return None
    # Links/reparse points are never eligible for a read shortcut. The full
    # scoped reader will reject them rather than following an unverified path.
    if path.is_symlink():
        raise ValueError("A review input redirects to another location. Restore its scoped file before continuing.")
    if getattr(stat, "st_file_attributes", 0) & 0x400:
        # Cloud placeholders and other reparse points need the full scoped
        # reader. Their presence alone does not establish an unsafe redirect.
        return None
    change = _windows_change_time(path) if os.name == "nt" else stat.st_ctime_ns
    if change is None:
        return None  # Caller fails open to full verification, never to cached data.
    return (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, change)


def revision(product, shared_paths):
    """A bounded read-cache hint, explicitly separate from a content digest."""
    result = []
    for folder, dirs, files in os.walk(product, followlinks=False):
        dirs[:] = sorted(name for name in dirs if name != ".portal-drafts")
        base = Path(folder)
        for name in dirs:
            stamp = _stamp(base / name)
            if stamp is None:
                return None
            result.append((str((base / name).relative_to(product)), stamp))
        for name in sorted(files):
            if name.endswith((".lock", ".tmp")):
                continue
            stamp = _stamp(base / name)
            if stamp is None:
                return None
            result.append((str((base / name).relative_to(product)), stamp))
    for path in shared_paths:
        stamp = _stamp(path)
        if stamp is None and path.exists():
            return None
        result.append((str(path), stamp))
    return tuple(result)


def digest(product, shared_paths, full_digest):
    if not _READING.get():
        return full_digest()
    key = str(product)
    before = revision(product, shared_paths)
    now = monotonic()
    with _LOCK:
        entry = _CACHE.get(key)
        if before is not None and entry and entry[0] == before and now - entry[2] < MAX_AGE_SECONDS:
            _CACHE.move_to_end(key)
            return entry[1]
    result = full_digest()
    after = revision(product, shared_paths)
    if before != after:
        raise SnapshotChanged("The product or master library changed while the table loaded. Reload the current table.")
    if before is not None:
        with _LOCK:
            _CACHE[key] = (before, result, monotonic())
            _CACHE.move_to_end(key)
            while len(_CACHE) > MAX_ENTRIES:
                _CACHE.popitem(last=False)
    return result
