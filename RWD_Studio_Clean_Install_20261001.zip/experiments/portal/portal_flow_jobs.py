"""Durable progress checks and reviewed gate commands, independent of rendering."""
from datetime import datetime
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import os
from pathlib import Path
import sys
import uuid

from experiments.portal import authoring_session
from experiments.portal import identity
from experiments.portal import portal_job_authority as authority
from experiments.portal import portal_jobs as jobs
from experiments.portal import portal_runtime

ROLES = authority.SOURCE_ROLES | {'viewer'}


class Pending(Exception):
    def __init__(self, job_id, kind='check', *, recheck_after_save=None):
        self.job_id, self.kind = job_id, kind
        self.recheck_after_save = recheck_after_save
        super().__init__('The saved ' + kind + ' continues in the background.')


def capture(root, actor, pack, allowed, action='flow_check'):
    context = authoring_session.CURRENT.get()
    if context is None:
        if identity.mode(os.environ) == 'hosted':
            raise ValueError('Start this hosted check from an authenticated application session.')
        return None
    authoring_session.check_scope(root, pack, actor)
    if 'view' not in context.permissions or any(p not in context.packs for p in allowed):
        raise ValueError('This check is outside the authenticated product access.')
    if action in {'synthetic_build', 'local_source_build', 'portfolio_snapshot'} and 'run_gates' not in context.permissions:
        raise ValueError('A data expert with run-check access must start this build.')
    authority.authorize(root, actor, mode=context.mode, primary_pack=pack,
        allowed_packs=allowed, roles=ROLES, action='product checks')
    return {'mode': context.mode}


def _authorize(value):
    saved = value.get('authority')
    if saved is None:
        if identity.mode(os.environ) == 'hosted':
            raise ValueError('This saved check has no authenticated binding. Start a fresh check.')
        return None
    return authority.authorize(value['root'], value['actor'], mode=saved.get('mode'),
        primary_pack=value['arguments']['pack'], allowed_packs=value['allowed_packs'],
        roles=ROLES, action='product checks')


def execute(value):
    root, pack = value['root'], value['arguments']['pack']
    user = _authorize(value)
    if pack not in value['allowed_packs'] or not portal_runtime.within_packs(pack, root, value['allowed_packs']):
        raise ValueError('This check is outside the requested product.')
    # A submitted boolean never enables the development gate bypass on a host.
    development = identity.mode(os.environ) in {'local', 'demo'}
    if value['action'] == 'portfolio_snapshot':
        if user is not None and (user.get('role') not in {'admin', 'qc_programmer'} or user.get('packs')):
            raise ValueError('Rebuilding the portfolio report requires run-check access to every product.')
        return _portfolio_snapshot(root)
    if value['action'] == 'synthetic_build':
        if not development or (user is not None and user.get('role') not in {'admin', 'qc_programmer'}):
            raise ValueError('Synthetic example builds require local development mode and run-check access.')
        if 'studio_review_digest' in value['arguments']:
            from experiments.portal import variable_execution_bridge
            current = variable_execution_bridge.pending_application(root, pack, value['actor'], allowed_packs=value['allowed_packs'])
            if current['pending'] or current['digest'] != value['arguments']['studio_review_digest']:
                raise ValueError('The variable reviews changed before this build started. Apply the current reviewed changes, then start a new build.')
        portal_runtime.job_progress('Building the selected product on synthetic sources.')
        # Keep the existing job/CLI seam, but return its typed build receipt to
        # both frontends. Presentation must never infer a dataset from stdout.
        from rwd_tools import local_smoke
        evidence_path = jobs._path(root, value['actor'], value['id']).with_suffix('.build.json')
        if evidence_path.exists():
            raise ValueError('This build already has a receipt. Start a fresh build instead of replacing its evidence.')
        result = _command(root, ['platform/tools/local_smoke.py', pack, '--evidence-out', str(evidence_path)], 'synthetic_build', False)
        if evidence_path.is_file():
            result['evidence'] = local_smoke.read_evidence(evidence_path)
        elif result['ok']:
            result.update(ok=False, errors=['The process ended without a readable build receipt. No dataset success is claimed.'])
        return result
    if value['action'] == 'local_source_build':
        if not development or (user is not None and user.get('role') not in {'admin', 'qc_programmer'}):
            raise ValueError('Uploaded-source candidate builds require local development mode and run-check access.')
        from experiments.portal import source_provisioning
        return source_provisioning.local_build(root, value['actor'], pack=pack,
            expected_digest=value['arguments'].get('expected_digest'), allowed_packs=value['allowed_packs'])
    from rwd_tools import flow
    portal_runtime.job_progress('Checking the current product evidence.')
    report = flow.flow(root, pack, development=development)
    report['checked_at'] = datetime.now().astimezone().strftime('%d %b, %H:%M:%S %Z')
    if value['action'] == 'flow_check':
        return {'ok': not report.get('error'), 'flow': report, 'changed': False}
    from experiments.portal import flow_guidance
    wanted = value['arguments']
    action = next((a for card in report.get('blockers', []) for a in card.get('fixes', [])
        if a.get('id') == wanted.get('action_id') and a.get('argv') == wanted.get('argv')), None)
    if action is None:
        from experiments.portal import flow_continuation
        continuation = flow_continuation.resolve(root, pack, value['actor'], wanted.get('action_id'),
            allowed_packs=value['allowed_packs'], can_view=True)
        if continuation.get('ok'):
            action = next((a for a in continuation.get('card', {}).get('fixes', [])
                if a.get('id') == wanted.get('action_id') and a.get('argv') == wanted.get('argv')), None)
    if not action or action.get('kind') not in {'read', 'write'}:
        raise ValueError('The proposed step changed or is no longer needed. Check current progress and choose its next step.')
    user = _authorize(value)  # Evaluation can be slow; recheck access at the command boundary.
    can_write = user is None or user.get('role') in {'admin', 'initiator', 'qc_programmer'}
    writable_mode = development or os.environ.get('RWD_PORTAL_HOSTED_AUTHORING') == '1'
    reason = flow_guidance.action_guard(root, pack, action, local_demo=writable_mode, can_write=can_write)
    if reason:
        raise ValueError(reason)
    argv = action['argv']
    if (user and user.get('packs') and '--check-receipts' in argv
            and Path(argv[0]).name == 'source_manifest.py'):
        raise ValueError('This receipt check covers all products. Ask a data expert with portfolio access to provide this product\'s result.')
    if not argv or not str(argv[0]).endswith('.py'):
        raise ValueError('This step needs its dedicated review form; no command was started.')
    portal_runtime.job_progress('Running the currently reviewed product step.')
    source_before = flow_guidance.source_revision(root, pack)
    outcome = _command(root, argv, action['id'], action['kind'] == 'write')
    outcome['source_digest'] = flow_guidance.source_revision(root, pack) if outcome.get('ok') else source_before
    return outcome


def _command(root, argv, action_id, changes):
    timeout = portal_runtime.timeout('RWD_PORTAL_BUILD_TIMEOUT_S', 1800) if Path(argv[0]).name == 'local_smoke.py' else 300
    from rwd_services import run_workflow_command
    name = Path(argv[0]).stem
    if name in {'run_spec_pipeline', 'spec_extract'}:
        result = run_workflow_command([sys.executable, *argv], issuer='rwd_tools.' + name,
                                     runner=portal_runtime.run, cwd=root, timeout_s=timeout)
    else:
        result = portal_runtime.run([sys.executable, *argv], cwd=root, timeout_s=timeout)
    ok = (result.returncode == 0 and portal_runtime.failure_kind(result) is None
          and getattr(result, 'workflow_outcome_verified', True))
    return {'ok': ok, 'returncode': result.returncode,
        'output': ((result.stdout or '') + (result.stderr or ''))[-60000:],
        'diagnostic_id': getattr(result, 'diagnostic_id', ''), 'action_id': action_id,
        'issues': [issue.to_dict() for issue in getattr(result, 'workflow_issues', ())],
        'workflow_protocol': 1, 'changed': changes and ok}


def _portfolio_snapshot(root):
    from rwd_tools import governance_snapshot as snapshots
    import json
    import tempfile
    state = os.environ.get('RWDP_STATE_DIR') or str(Path(os.environ.get('LOCALAPPDATA') or Path.home()) / 'RwdPortal')
    target = Path(portal_runtime.snapshot_path(root, state, str(Path(__file__).parent)))
    problems = snapshots.out_path_errors(str(target), root=root)
    if problems and not all(p.endswith(' does not exist') for p in problems):
        raise ValueError(' '.join(problems))
    if target.resolve() != target.absolute():
        raise ValueError('The report destination redirects elsewhere. Choose a canonical private state directory.')
    target.parent.mkdir(parents=True, exist_ok=True)
    problems = snapshots.out_path_errors(str(target), root=root)
    if problems or target.is_dir():
        raise ValueError('The report destination is unavailable. ' + ' '.join(problems))
    portal_runtime.job_progress('Checking all product evidence for the saved portfolio report.')
    report = snapshots.build(root)
    fd, temporary = tempfile.mkstemp(prefix='snapshot_', suffix='.tmp', dir=target.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            json.dump(report, handle)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    finally:
        Path(temporary).unlink(missing_ok=True)
    return {'ok': True, 'snapshot_path': str(target), 'output': 'The saved portfolio report is refreshed.', 'changed': False}


def key(pack):
    return 'flow:' + hashlib.sha256(pack.encode()).hexdigest()[:24]


class Evaluator:
    def __init__(self, root, pack, actor, allowed_packs, can_view):
        self.root, self.pack, self.actor = root, pack, actor
        self.allowed, self.can_view = list(allowed_packs), bool(can_view)
        self.binding = authoring_session.CURRENT.get()
        self.mode = identity.mode(os.environ)

    def access(self):
        if not self.can_view:
            raise ValueError('Product viewing access is required.')
        authoring_session.check_scope(self.root, self.pack, self.actor)
        if identity.mode(os.environ) != self.mode:
            raise ValueError('The identity mode changed. Reopen the product in the current session.')
        if self.binding is None and self.mode == 'hosted':
            raise ValueError('Reopen the product from an authenticated application session.')
        return _authorize({'root': self.root, 'actor': self.actor,
            'authority': {'mode': self.mode} if self.binding is not None else None,
            'allowed_packs': self.allowed, 'arguments': {'pack': self.pack}})

    @contextmanager
    def session(self):
        """Fragments retain their verified principal, while every use checks the roster."""
        user = self.access()
        token = None
        if self.binding is not None:
            permissions = set(self.binding.permissions)
            if user and user.get('role') not in {'admin', 'qc_programmer'}:
                permissions.discard('run_gates')
            token = authoring_session.bind(self.root, self.actor, self.allowed, permissions, mode=self.mode)
        try:
            yield user
        finally:
            if token is not None:
                authoring_session.CURRENT.reset(token)

    def control(self, action, user):
        return self.can_view and (action == 'flow_check' or user is None or
            user.get('role') in {'admin', 'qc_programmer', 'initiator'})

    def request(self, action, arguments, *, after_save=False, request_nonce=None):
        self.access()
        active = next((row for row in jobs.recent(self.root, self.actor, action=action,
            job_key=key(self.pack), allowed_packs=self.allowed) if row['status'] in {'queued', 'running'}), None)
        if active and action == 'flow_check' and after_save:
            # This check can already have read the pre-save inputs. Keep its
            # execution immutable, and journal a fresh check to follow it.
            changes = {'recheck_after_save': uuid.uuid4().hex}
            if arguments.get('requested'):
                changes['continuation'] = arguments['requested']
            with self.session():
                active = jobs._update(jobs._path(self.root, self.actor, active['id']), changes)
            raise Pending(active['id'], recheck_after_save=active['recheck_after_save'])
        if active and action == 'flow_check' and arguments.get('requested'):
            # Navigation does not change the running computation. Keep it in a
            # separate journal field, leaving execution arguments/hash intact.
            with self.session():
                jobs._update(jobs._path(self.root, self.actor, active['id']),
                    {'continuation': arguments['requested']})
        elif active and any(active['arguments'].get(k) != v for k, v in arguments.items()):
            raise ValueError('Another step is still running for this product. Open its progress before starting a different step.')
        if active is None:
            with self.session():
                active = jobs.start(self.root, self.actor, action=action,
                    arguments={'pack': self.pack, 'request_nonce': request_nonce or uuid.uuid4().hex, **arguments}, job_key=key(self.pack),
                    confirmed=True, can_write=True, allowed_packs=self.allowed)
        raise Pending(active['id'], 'check' if action == 'flow_check' else 'step',
                      recheck_after_save=active.get('recheck_after_save'))

    def _request_check(self, requested=None, *, after_save=False):
        import json
        if requested and (requested.get('pack') != self.pack or requested.get('actor') != self.actor):
            raise ValueError('The requested review belongs to another product or profile.')
        if requested and len(json.dumps(requested, allow_nan=False).encode()) > 16384:
            raise ValueError('Reopen this review from its current product page; the navigation context is too large.')
        return self.request('flow_check', {'requested': requested} if requested else {}, after_save=after_save)

    def __call__(self, requested=None):
        return self._request_check(requested)

    def after_save(self, requested=None):
        """Require a check started after this save; never duplicate a running one."""
        return self._request_check(requested, after_save=True)

    def recheck_after_save(self, nonce, requested=None):
        """Idempotently queue the journaled follow-up with fresh authority."""
        try:
            self.request('flow_check', {}, request_nonce=nonce)
        except Pending as pending:
            if requested:
                with self.session():
                    jobs._update(jobs._path(self.root, self.actor, pending.job_id), {'continuation': requested})
            raise

    def run_action(self, action):
        return self.request('flow_action', {'action_id': action['id'], 'argv': action['argv']})

    def build(self):
        # Existing callers explicitly offer a local synthetic build. Configuring
        # a remote deployment must not change that button's execution target.
        return self.request('synthetic_build', {})

    def snapshot(self):
        return self.request('portfolio_snapshot', {})

    def recover(self, *, completed=False):
        """Reconnect to owned work; optional completed reads are historical only.

        A saved successful check is a display snapshot, never current approval
        authority. Explicit requests still use request()/execute(), which check
        current inputs and access. Old navigation instructions are not replayed.
        """
        self.access()
        rows = [row for action in ('flow_check', 'flow_action')
            for row in jobs.recent(self.root, self.actor, action=action,
                job_key=key(self.pack), allowed_packs=self.allowed)]
        if not rows:
            return None
        row = max(rows, key=lambda item: item['created_at'])
        saved = row.get('result') or {}
        report = saved.get('flow')
        if (completed and row['action'] == 'flow_check' and row['status'] == 'completed'
                and saved.get('ok') is True and isinstance(report, dict)
                and not report.get('error') and not (row.get('orphan_recovery') or {}).get('present')
                and not row.get('recheck_after_save')):
            if (report.get('pack') != self.pack or row.get('arguments', {}).get('pack') != self.pack
                    or bool(report.get('development')) != (self.mode in {'local', 'demo'})):
                return None  # Re-evaluate when the identity/gate mode changed.
            result = deepcopy(report)
            result['historical_check'] = {'job_id': row['id'], 'completed_at': row['updated_at'],
                'actor': self.actor, 'pack': self.pack}
            return result
        return {'pending_job': row['id'], 'pending_kind': 'check' if row['action'] == 'flow_check' else 'step',
            'requested': row.get('continuation') or row.get('arguments', {}).get('requested'),
            **({'recheck_after_save': row['recheck_after_save']} if row.get('recheck_after_save') else {})}


def pending_from(error):
    return {'pending_job': error.job_id, 'pending_kind': error.kind,
            **({'recheck_after_save': error.recheck_after_save} if error.recheck_after_save else {})}


def render_pending(evaluate, pending):
    import streamlit as st
    from experiments.portal import portal_jobs_page
    @st.fragment(run_every=2)
    def progress():
        try:
            with evaluate.session() as user:
                job = jobs.read(evaluate.root, evaluate.actor, pending['pending_job'], allowed_packs=evaluate.allowed)
                portal_jobs_page.render(evaluate.root, evaluate.actor, action=job['action'], job_key=job['job_key'],
                    allowed_packs=evaluate.allowed, can_write=evaluate.control(job['action'], user), key='flow_job_' + job['id'], auto_refresh=True)
        except (ValueError, OSError) as error:
            st.error(str(error))
            return
        if job['status'] not in jobs.TERMINAL:
            return
        if (job.get('orphan_recovery') or {}).get('present'):
            return  # Keep owned-process recovery controls on screen until release.
        recheck = job.get('recheck_after_save') or pending.get('recheck_after_save')
        if job['action'] == 'flow_check' and recheck:
            requested = job.get('continuation') or pending.get('requested') or job.get('arguments', {}).get('requested')
            try:
                evaluate.recheck_after_save(recheck, requested)
            except Pending as queued:
                st.session_state.setdefault('flow_result', {})[evaluate.pack] = pending_from(queued)
            except (ValueError, OSError) as error:
                st.session_state.setdefault('flow_result', {})[evaluate.pack] = {'error': str(error)}
            st.rerun()
        result = job.get('result') or {}
        succeeded = job['status'] == 'completed' and result.get('ok') is True
        if job['action'] == 'flow_check':
            final = result.get('flow') if succeeded else None
            final = final or {'error': result.get('error') or '; '.join(result.get('errors', [])) or
                'The check is ' + job['status'] + '. ' + job['progress']}
            if result.get('diagnostic_id'):
                final['diagnostic_id'] = result['diagnostic_id']
            st.session_state.setdefault('flow_result', {})[evaluate.pack] = final
            requested = job.get('continuation') or pending.get('requested') or job.get('arguments', {}).get('requested')
            if requested and not final.get('error'):
                st.session_state['flow_checked_request'] = requested
        else:
            before = pending.get('feedback', {})
            st.session_state['flow_dialog_feedback'] = {**before, 'ok': succeeded,
                'source_digest': result.get('source_digest', before.get('source_digest')),
                'output': result.get('output') or result.get('error') or '; '.join(result.get('errors', [])) or job['progress'],
                'blockers': [item.get('message', '') for item in result.get('issues', []) if isinstance(item, dict)],
                'issues': result.get('issues', []), 'workflow_protocol': result.get('workflow_protocol', 1)}
            if result.get('diagnostic_id'):
                st.session_state['flow_dialog_feedback']['output'] += '\nSupport reference: ' + result['diagnostic_id']
            try:
                evaluate()
            except Pending as queued:
                st.session_state.setdefault('flow_result', {})[evaluate.pack] = pending_from(queued)
            except (ValueError, OSError) as error:
                st.session_state.setdefault('flow_result', {})[evaluate.pack] = {'error': str(error)}
        st.rerun()
    progress()


def render_build(evaluate, can_run, *, on_result=None, action='synthetic_build'):
    """Reconnect to retained build output without restarting the computation."""
    from rwd_services import databricks_jobs
    if action == 'synthetic_build' and databricks_jobs.configured():
        from rwd_services.databricks_jobs_page import render
        render(evaluate, can_run)
    import streamlit as st
    from experiments.portal import portal_jobs_page
    @st.fragment(run_every=2)
    def progress():
        try:
            with evaluate.session() as user:
                result = portal_jobs_page.render(evaluate.root, evaluate.actor, action=action,
                    job_key=key(evaluate.pack), allowed_packs=evaluate.allowed,
                    can_write=can_run and evaluate.control(action, user), key=action + '_' + key(evaluate.pack), auto_refresh=True)
        except (ValueError, OSError) as error:
            st.error(str(error))
            return
        if result:
            if result.get('snapshot_path'):
                try:
                    revision = Path(result['snapshot_path']).stat().st_mtime_ns
                    marker = 'snapshot_rendered_' + key(evaluate.pack)
                    if st.session_state.get(marker) != revision:
                        st.session_state[marker] = revision
                        st.rerun()
                except OSError:
                    st.warning('The saved report is no longer available. Request a fresh check.')
            text = result.get('output') or '; '.join(result.get('errors', []))
            st.code(text or 'No execution output was recorded.', language=None)
            if result.get('diagnostic_id'):
                st.caption('Support reference: ' + result['diagnostic_id'])
            if on_result:
                on_result(text)
    progress()
