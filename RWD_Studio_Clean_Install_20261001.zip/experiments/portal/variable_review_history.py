"""Content-addressed, append-only review history beside the current snapshot.

A new snapshot references immutable chunks only after their bytes exist. A
crash can leave an unreferenced chunk, but cannot publish a partial history.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re

TAIL_LIMIT = 250
KEEP_RECENT = 50
CHUNK_EVENTS = 250
MAX_CHUNK_BYTES = 4 * 1024 * 1024


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False, separators=(",", ":")).encode("utf-8")


def references(state):
    refs = state.get("history_archives", [])
    if not isinstance(refs, list):
        raise ValueError("Review history archive references must be a list.")
    seen = set()
    for ref in refs:
        if (not isinstance(ref, dict) or set(ref) != {"sha256", "count"}
                or not isinstance(ref["sha256"], str) or not re.fullmatch(r"[a-f0-9]{64}", ref["sha256"])
                or type(ref["count"]) is not int or not 0 < ref["count"] <= CHUNK_EVENTS
                or ref["sha256"] in seen):
            raise ValueError("A review history archive reference is invalid.")
        seen.add(ref["sha256"])
    return refs


def count(state):
    return sum(ref["count"] for ref in references(state)) + len(state["history"])


def chunks(path, state, read):
    previous = ""
    for ref in references(state):
        target = path.parent / "history" / (ref["sha256"] + ".json")
        raw = read(target)
        if len(raw) > MAX_CHUNK_BYTES or hashlib.sha256(raw).hexdigest() != ref["sha256"]:
            raise ValueError("A review history archive changed. Restore its recorded bytes before continuing.")
        chunk = json.loads(raw)
        if (not isinstance(chunk, dict) or set(chunk) != {"version", "pack", "previous", "events"}
                or chunk["version"] != 1 or chunk["pack"] != state["pack"] or chunk["previous"] != previous
                or not isinstance(chunk["events"], list) or len(chunk["events"]) != ref["count"]
                or any(not isinstance(event, dict) for event in chunk["events"])):
            raise ValueError("The review history archive chain is invalid.")
        if encoded(chunk) != raw:
            raise ValueError("A review history archive is not in its recorded canonical format.")
        yield chunk
        previous = ref["sha256"]


def events(path, state, read):
    for chunk in chunks(path, state, read):
        yield from chunk["events"]
    yield from state["history"]


def prepare(path, state, *, read, safe, force=False):
    """Verify old chunks; return a compact snapshot and immutable new chunks."""
    for _ in chunks(path, state, read):
        pass
    result = deepcopy(state)
    if len(result["history"]) <= TAIL_LIMIT and not force:
        return result, []
    amount = max(0, len(result["history"]) - KEEP_RECENT)
    if not amount:
        return result, []
    refs = deepcopy(references(result))
    pending = []
    remaining = result["history"][:amount]
    previous = refs[-1]["sha256"] if refs else ""
    while remaining:
        selected = remaining[:CHUNK_EVENTS]
        while True:
            chunk = {"version": 1, "pack": result["pack"], "previous": previous, "events": selected}
            raw = encoded(chunk)
            if len(raw) <= MAX_CHUNK_BYTES:
                break
            if len(selected) == 1:
                raise ValueError("One review event exceeds the archive limit. Export and inspect that event before continuing.")
            selected = selected[:max(1, len(selected) // 2)]
        digest = hashlib.sha256(raw).hexdigest()
        refs.append({"sha256": digest, "count": len(selected)})
        pending.append((safe(path.parent / "history" / (digest + ".json")), raw))
        previous = digest
        remaining = remaining[len(selected):]
    result.update(version=2, history_archives=refs, history=result["history"][amount:])
    return result, pending


def publish(pending, *, read, safe):
    """Called under the product's workflow lock, including on shared volumes."""
    for target, raw in pending:
        target.parent.mkdir(parents=True, exist_ok=True)
        safe(target.parent)
        import os
        import uuid
        temporary = safe(target.with_name("pending-" + uuid.uuid4().hex[:12] + ".tmp"))
        try:
            with temporary.open("xb") as handle:
                handle.write(raw)
                handle.flush()
                os.fsync(handle.fileno())
            try:
                os.link(temporary, target)
            except FileExistsError:
                if read(target) != raw:
                    raise ValueError("An immutable review archive already exists with different bytes.")
            except OSError as error:
                import errno
                if error.errno not in {errno.EPERM, errno.EXDEV, errno.ENOSYS, errno.ENOTSUP} and getattr(error, "winerror", None) not in {1, 50, 1314}:
                    raise
                # Some authoring volumes support atomic rename but not hard
                # links. The enclosing workflow lock serializes all writers.
                if target.exists():
                    if read(target) != raw:
                        raise ValueError("An immutable review archive already exists with different bytes.")
                else:
                    os.rename(temporary, target)
        finally:
            if temporary.exists():
                temporary.unlink()
