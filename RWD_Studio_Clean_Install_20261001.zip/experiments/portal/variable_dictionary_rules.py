"""Compile explicitly requested dictionaries from the authoritative reviewed rows."""
from __future__ import annotations

from copy import deepcopy
import re
from types import SimpleNamespace

from engine import product_catalog
from experiments.portal.variable_review_consistency import canonical_type


def _categories(row):
    rule = row.get("clinical_rule") or {}
    if rule.get("result") not in {"label", "code"}:
        return []
    if rule.get("operator") == "baseline_ecog":
        return [{"code": code, "label": label} for label, code in (rule.get("value_codes") or {}).items()] + [
            {"code": rule["missing_code"], "label": rule["missing_label"]}]
    if rule.get("operator") == "lab_value":
        return [{"code": rule[key], "label": rule[key]} for key in ("present_label", "unknown_label", "missing_label") if rule.get(key)]
    if rule.get("operator") == "risk_score":
        native = rule.get("native") or {}
        return [{"code": item["code"], "label": item["label"]} for item in native.get("categories", []) + [native["incomplete"]]]
    return [{"code": group["code"], "label": group["label"]} for group in rule.get("groups", rule.get("bands", []))]


def compile_rows(rows, cfg, catalog, *, pack=None):
    """Return overlay + blockers. No files, configuration or review values are changed."""
    raw = getattr(cfg, "raw", {}) or {}
    result = {"overlay": {"version": 1, "variables": []}, "blockers": []}

    def block(row, message):
        result["blockers"].append({"item_id": row.get("item_id", ""), "variable_id": row.get("variable_id", ""), "message": message})

    previous = raw.get("dictionary_overlay", {"version": 1, "variables": []})
    try:
        previous = product_catalog.validate_overlay(previous)
    except ValueError as error:
        block({}, str(error))
        return result
    ids = {row.get("item_id") for row in rows}
    # Existing entries for rows absent from this table survive. Explicitly
    # excluded/renamed dictionary rows replace their own prior metadata only.
    entries = [deepcopy(entry) for entry in previous["variables"] if entry["provenance"]["item_id"] not in ids]
    for row in rows:
        values = row.get("values") or {}
        output, publish = values.get("output") or {}, values.get("publish") or {}
        if publish.get("dictionary") != "configured" or output.get("role") not in {"published", "internal"}:
            continue
        code, dtype = output.get("physical_name"), canonical_type(output.get("type"))
        if not isinstance(code, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", code):
            block(row, "Choose the actual physical column identifier before preparing its dictionary entry.")
            continue
        if not dtype:
            block(row, f"Choose the actual storage type for dictionary variable {code}.")
            continue
        definition = str(values.get("derivation") or "").strip()
        if not definition:
            block(row, f"Write the reviewed scientific definition for dictionary variable {code}.")
            continue
        clinical = row.get("clinical_rule") or {}
        try:
            if clinical:
                from experiments.portal import variable_clinical_rules
                variable_clinical_rules.validate(clinical, allow_incomplete=False)
            categories = _categories(row)
            display_type = ("categorical" if categories else "numeric" if dtype in {"integer", "long", "double"}
                            else "flag" if dtype == "boolean" else dtype)
            master = product_catalog.matching_entry(catalog, code)
            label = str((master or {}).get("label") or row.get("definition") or row.get("variable_id") or code).strip()
            provenance = {"item_id": str(row.get("item_id") or ""), "variable_id": str(row.get("variable_id") or code),
                          "product_id": str(raw.get("data_product_id") or ""), "master_name": str(row.get("master_name") or ""),
                          "review_digest": product_catalog.digest({"values": values, "clinical_rule": clinical, "family": row.get("family") or {}})}
            pin = (row.get("master_link") or {}).get("content_digest")
            if pin:
                provenance["master_digest"] = pin
            native_rule = clinical.get("native") or {}
            units = deepcopy(clinical.get("units") or ([native_rule["unit"]] if native_rule.get("unit") else []))
            if clinical.get("operator") == "value_in_window" and clinical.get("result") == "value":
                converted_unit = (native_rule.get("value", {}).get("transform") or {}).get("output_unit")
                if converted_unit:
                    units = [converted_unit]
            elif clinical.get("operator") == "time_to_event" and clinical.get("result") == "time":
                units = [native_rule["time_unit"]]
            entry = {"code": code, "label": label, "category": "Treatment" if row.get("family") else "Clinical Chars",
                "type": display_type, "data_type": dtype, "definition": definition,
                "units": units, "codes": categories,
                "rule": {"clinical_rule": deepcopy(clinical)} if clinical else {"family": deepcopy(row.get("family") or {})},
                "provenance": provenance, "published_name": str(output.get("target_published_name") or ""),
                "audiences": ["internal"], "pii": True,
                "destinations": {"dictionary": "configured", "dashboard": publish.get("dashboard") or "excluded"}}
            if pack:
                from rwd_tools import reviewed_variable_record as reviewed
                complete_rule = reviewed.from_review(row, pack=pack)
                entry["rule"]["reviewed_variable"] = complete_rule
                provenance["rule_digest"] = reviewed.digest(complete_rule)
            if master is not None:
                entry.update(catalog_code=master["code"], catalog_digest=product_catalog.digest(master))
            entries.append(entry)
        except (ValueError, KeyError, TypeError) as error:
            block(row, str(error))
    result["overlay"] = {"version": 1, "variables": entries}
    try:
        result["overlay"] = product_catalog.validate_overlay(result["overlay"])
        product_catalog.merge(SimpleNamespace(raw={"dictionary_overlay": result["overlay"]}), catalog)
    except ValueError as error:
        block({}, str(error))
    return result
