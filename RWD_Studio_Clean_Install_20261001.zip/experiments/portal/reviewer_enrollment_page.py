"""Review the production identity binding and enroll existing personal public keys."""
import streamlit as st

from experiments.portal import authoring_session
from experiments.portal import reviewer_enrollment as backend
from rwd_tools import reviewer_identity_store as store
from rwd_tools import approval_identity
from experiments.portal import review_setup
from experiments.portal import page_assistant_context as chat_context
from experiments.portal import page_assistant_summaries as chat_summary


def _public_registration(root, reviewer, report, token):
    """Administrator-only public registration; kept separate from the enrollment form."""
    prefix = token + "_registration"
    basis = (str(root), reviewer["principal"])
    if st.session_state.get(prefix + "_basis") != basis:
        st.session_state[prefix + "_basis"] = basis
        st.session_state[prefix + "_revision"] = report["registry_revision"]
        for suffix in ("_public", "_reason", "_confirm", "_open"):
            st.session_state.pop(prefix + suffix, None)
    if reviewer["keys"] and not st.checkbox("Register another public key", key=prefix + "_open"):
        return
    st.write("Register a reviewer public key")
    st.caption("Paste the reviewer's existing Ed25519 public key. Keep their private key on their own computer. Registration does not enroll identity or approve a clinical decision.")
    public = st.text_area("Reviewer's public key", max_chars=32768, placeholder="ssh-ed25519 AAAA…", key=prefix + "_public")
    material = None
    if public:
        try:
            material = backend.public_key_preview(public)
        except ValueError as error:
            st.warning(str(error))
        else:
            st.caption("Check this fingerprint with the reviewer: " + material["key_id"])
    reason = st.text_input("How did you check this public key with the reviewer?", max_chars=1000, key=prefix + "_reason")
    confirmed = st.checkbox("I independently checked this public key and fingerprint with the selected reviewer, who is a different person from me.", key=prefix + "_confirm")
    if st.button("Register public key", disabled=material is None or not confirmed or len(reason.strip()) < 10,
                 key=prefix + "_save"):
        try:
            result = backend.register_public_key(root, reviewer_principal=reviewer["principal"], public_key=public,
                reason=reason, confirmed=confirmed, expected_registry_revision=st.session_state[prefix + "_revision"])
        except (ValueError, OSError) as error:
            st.error(str(error))
        else:
            st.session_state[prefix + "_revision"] = result["registry_revision"]
            st.session_state[prefix + "_notice"] = result["message"]
            st.session_state[token + "_requested_key"] = result["key_id"]
            st.session_state.pop(prefix + "_basis", None)
            st.rerun()
    if st.button("Refresh public key register", key=prefix + "_refresh"):
        st.session_state[prefix + "_revision"] = backend.describe(root)["registry_revision"]
        st.rerun()


def _registration_history(root, reviewer, key, token):
    """Finish the exact public registration before opening the separate enrollment form."""
    prefix = token + "_registration_history"
    try:
        report = backend.public_key_history(root, reviewer_principal=reviewer["principal"], key_id=key)
    except (ValueError, OSError) as error:
        st.warning(str(error))
        return False
    if report["recorded"]:
        st.caption("Public key recorded in Git history.")
        return True
    st.info("This public-key registration is saved but not yet recorded in history. Record this exact addition so another checkout can verify the reviewer's signatures.")
    st.code(report["diff"], language="diff")
    if st.session_state.get(prefix + "_digest") != report["digest"]:
        st.session_state[prefix + "_digest"] = report["digest"]
        st.session_state[prefix + "_confirm"] = False
    confirmed = st.checkbox("I reviewed this exact public-key addition and want to record it in history.", key=prefix + "_confirm")
    if st.button("Record public-key registration in history", disabled=not confirmed, key=prefix + "_save"):
        try:
            result = backend.record_public_key_history(root, reviewer_principal=reviewer["principal"], key_id=key,
                expected_digest=st.session_state[prefix + "_digest"], confirmed=confirmed)
        except (ValueError, OSError) as error:
            st.error(str(error))
        else:
            st.session_state[token + "_registration_notice"] = result["message"]
            st.rerun()
    return False


def render(root, pack, checkpoint, actor_id, *, can_view=True, expanded=False):
    if not can_view:
        chat_context.clear_surface(st.session_state, "reviewer_enrollment")
        return
    authority = authoring_session.CURRENT.get()
    allowed = list(authority.packs) if authority else [pack]
    token = "enrollment_" + checkpoint
    def publish(state, **details):
        selectors = ([token + "_person"] if details.get("reviewer_count") else [])
        if details.get("key_count"): selectors.append(token + "_key")
        if details.get("action"): selectors.append(token + "_action")
        chat_context.publish_surface(st.session_state, "reviewer_enrollment", root=root, pack=pack, actor_id=actor_id,
            allowed_packs=allowed, summary=chat_summary.enrollment(checkpoint=checkpoint, state=state, **details),
            selectors=selectors)
    with st.expander("Reviewer identity enrollment", expanded=expanded):
        st.caption("A different authenticated administrator verifies the reviewer's principal and existing public-key fingerprint. Each clinical decision still requires that reviewer's own verified Git signature.")
        try:
            path, _ = store.location(root)
            st.text("Protected identity store: " + str(path))
        except (ValueError, OSError, TypeError) as error:
            st.warning(str(error))
            publish("store_unavailable", errors=[str(error)])
            return
        authority = authoring_session.CURRENT.get()
        if not authority or authority.mode != "hosted" or "manage_users" not in authority.permissions:
            st.info("An authenticated administrator with Manage users access can enroll another reviewer here. Ask that administrator to open this same review page.")
            publish("administrator_required")
            return
        try:
            report = backend.describe(root)
        except (ValueError, OSError, TypeError) as error:
            st.warning(str(error))
            publish("registry_unavailable", can_manage=True, errors=[str(error)])
            return
        available = [u for u in report["reviewers"] if u["principal"] != authority.actor.casefold()]
        if not available:
            st.info("Add a separate reviewer principal in Manage users first. Administrators cannot enroll their own identity.")
            publish("separate_reviewer_required", can_manage=True)
            return
        token = "enrollment_" + checkpoint
        by_principal = {u["principal"]: u for u in available}
        previous_person = st.session_state.get(token + "_person")
        if isinstance(previous_person, dict):
            previous_person = previous_person.get("principal")
            if previous_person in by_principal:
                st.session_state[token + "_person"] = previous_person
            else:
                st.session_state.pop(token + "_person", None)
        elif previous_person is not None and previous_person not in by_principal:
            st.session_state.pop(token + "_person", None)
        principal = st.selectbox("Reviewer to enroll", list(by_principal),
            format_func=lambda value: by_principal[value]["name"] + " · " + value, key=token + "_person")
        reviewer = by_principal[principal]
        notice = st.session_state.pop(token + "_registration_notice", None)
        if notice:
            st.success(notice)
        _public_registration(root, reviewer, report, token)
        if not reviewer["keys"]:
            st.info("Register this reviewer's public key above, then continue with independent identity enrollment.")
            publish("public_key_registration_required", can_manage=True, reviewer_count=len(available), history_count=len(report["events"]))
            return
        requested = st.session_state.pop(token + "_requested_key", None)
        if requested in reviewer["keys"]:
            st.session_state[token + "_key"] = requested
        key = st.selectbox("Registered public-key fingerprint", reviewer["keys"], key=token + "_key")
        if not _registration_history(root, reviewer, key, token):
            publish("public_key_history_required", can_manage=True, reviewer_count=len(available),
                key_count=len(reviewer["keys"]), history_count=len(report["events"]))
            return
        basis = (str(path), reviewer["principal"], key)
        if st.session_state.get(token + "_basis") != basis:
            st.session_state[token + "_basis"] = basis
            st.session_state[token + "_revision"] = report["revision"]
        # Keep the displayed revision until an explicit refresh, even across form reruns.
        with st.form(token + "_form"):
            action = st.selectbox("Identity action", ["Enroll verified reviewer", "Revoke enrollment"], key=token + "_action")
            reason = st.text_input("How did you independently verify this principal and key?", key=token + "_reason")
            confirmed = st.checkbox("I verified this person's authenticated principal and public-key fingerprint independently. This is a different person from me.", key=token + "_confirm")
            submitted = st.form_submit_button("Save identity enrollment", key=token + "_save")
        errors = []
        recorded = False
        if submitted:
            try:
                backend.save(root, reviewer_principal=reviewer["principal"], key_id=key, reason=reason,
                    expected_revision=st.session_state[token + "_revision"], confirmed=confirmed,
                    revoke=action == "Revoke enrollment")
            except (ValueError, OSError) as error:
                st.error(str(error))
                errors.append(str(error))
            else:
                recorded = True
                st.session_state[token + "_revision"] = backend.describe(root)["revision"]
                st.session_state.setdefault("flow_result", {}).pop(pack, None)
                st.success("Identity enrollment recorded. Check again to re-evaluate the existing signatures; no clinical decision was changed.")
        matching = [event for event in report["events"] if event.get("principal") == reviewer["principal"] and event.get("key_id") == key]
        selected_status = ("revoked" if action == "Revoke enrollment" else "enrolled") if recorded else matching[-1].get("status") if matching else None
        publish("recorded" if recorded else "refused" if errors else "ready_for_review", can_manage=True,
            reviewer_count=len(available), key_count=len(reviewer["keys"]), history_count=len(report["events"]) + int(recorded),
            selected_status=selected_status, action=action, errors=errors)
        if st.button("Refresh identity enrollment", key=token + "_refresh"):
            st.session_state[token + "_revision"] = backend.describe(root)["revision"]
            st.rerun()
        if report["events"]:
            st.dataframe([{k: e[k] for k in ("name", "principal", "key_id", "status", "by", "at")} for e in report["events"]], hide_index=True, width="stretch")
        return recorded
