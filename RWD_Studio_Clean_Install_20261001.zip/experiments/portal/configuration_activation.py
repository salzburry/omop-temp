"""Use an accepted, validated configuration revision through journaled file writes.

This changes authoring inputs only. Scientific/source/configuration approvals,
Git history, built datasets and release pointers are never written here.
"""
from datetime import datetime, timezone
import json
from pathlib import Path
import tempfile

from experiments.portal import authoring_session
from experiments.portal import configuration_proposals as cp
from experiments.portal import review_inbox as inbox
from rwd_tools import new_product

NOTICE = ('The reviewed files become this product’s working configuration. Existing approvals stay recorded; '
          'changed digests require the normal checks and reviews again. No dataset is built or released.')


class _RecoveryRequired(ValueError):
    pass


def _scope(root, pack, actor, allowed, *, write=False):
    current = authoring_session.CURRENT.get()
    if current is None:
        raise ValueError('Use this action from an identified portal session.')
    authoring_session.check_scope(root, pack, actor)
    if write:
        authoring_session.require_edit()
    base, product, name, _directory = inbox._scope(root, pack, allowed)
    if not name.startswith('products/'):
        raise ValueError('Reference examples cannot become an active product configuration.')
    return base, product, name


def _allowed():
    return {ref.split('#/', 1)[0] for ref in (*cp.PARAMETERS, *cp.REVIEWED_BLOCK_REFS,
                                           *getattr(cp, 'CODELIST_REFS', {}),
                                           *getattr(cp, 'COHORT_REFS', {}))}


def _receipt_path(product, request_id):
    inbox._file(product / '.portal-drafts/reviews', request_id)
    return cp._safe(product / '.portal-drafts/activations' / (request_id + '.json'))


def _review_document(product, name, request_id):
    """Read preserved review evidence without comparing it to today's working files."""
    return inbox._read(inbox._file(product / '.portal-drafts/reviews', request_id), request_id, name)


def _receipt(product, request_id, *, pack):
    path = _receipt_path(product, request_id)
    if not path.exists():
        return None
    data = json.loads(cp._read(path))
    if (not isinstance(data, dict) or not inbox._intact(data, 'receipt_sha256')
            or data.get('version') != 1 or data.get('request_id') != request_id or data.get('pack') != pack
            or data.get('approved') is not False or data.get('released') is not False
            or not isinstance(data.get('files'), dict) or not data['files']
            or not set(data['files']) <= _allowed()):
        raise ValueError('The configuration-use receipt is incomplete. Preserve it for inspection.')
    # Activation legitimately changes the request's live baseline. Authenticate
    # this historical statement against its retained request and decision chain,
    # never against the current proposal state or today's configuration snapshot.
    doc = _review_document(product, pack, request_id)
    request, decisions = doc['request'], doc['decisions']
    accepted = next((item for item in reversed(decisions) if item['act'] == 'accepted'), None)
    applied = next((item for item in decisions if item['act'] == 'applied'), None)
    validated = next((item for item in reversed(decisions) if item['act'] == 'validated'), None)
    files = request['files']
    hashes = {entry['path']: cp._digest(entry['after'].encode('utf-8')) for entry in files}
    if (doc['status'] != 'validated' or not accepted or not applied or not validated
            or not files or len(files) != len(hashes) or not set(hashes) <= _allowed()
            or accepted['recorded_by']['owner'] == request['author']['owner']
            or hashes != request['candidate'] or hashes != accepted.get('candidate')
            or hashes != applied.get('applied_files') or hashes != validated.get('validated_files')
            or hashes != data['files'] or validated.get('passed') is not True
            or not _passing(validated.get('checks')) or not _passing(data.get('checks'))):
        raise ValueError('The configuration-use receipt does not match an independently accepted and validated revision. '
                         'Preserve the receipt and review history for inspection.')
    historical_basis = cp._digest(cp._encode({'request': request, 'decisions': decisions,
        'snapshot': request['base']['snapshot_sha256'], 'files': hashes}))
    revision = inbox._revision_dir(product, request_id)
    if (data.get('reviewed_basis') != historical_basis
            or any(cp._digest(cp._read(cp._safe(revision / rel))) != digest for rel, digest in hashes.items())):
        raise ValueError('The review history or validated revision behind this configuration-use receipt changed. '
                         'Preserve these records for inspection; do not treat the receipt as completed evidence.')
    matches = all(cp._digest(cp._read(cp._safe(product / rel))) == digest
                  for rel, digest in data['files'].items())
    return {**data, 'current_files_match': matches}


def _passing(checks):
    return (isinstance(checks, list) and len(checks) == len(cp.REQUIRED_VALIDATORS)
            and {item.get('validator') for item in checks if isinstance(item, dict)} == cp.REQUIRED_VALIDATORS
            and all(item.get('passed') is True and item.get('completed') is not False for item in checks))


def _no_pending_install(base):
    if new_product._install_path(base, new_product.INSTALL_JOURNAL).exists():
        raise _RecoveryRequired('An interrupted file update needs recovery. Choose Recover interrupted installation '
                                'in setup recovery before checking or changing configuration.')


def _write_party(request, actor):
    current = authoring_session.CURRENT.get()
    _actor, owner = inbox._actor(actor)
    if owner != request['author']['owner'] and (current is None or 'review' not in current.permissions):
        raise ValueError('Only the proposal author or an authorized reviewer can put this reviewed configuration into use.')


def _basis(base, product, name, request_id, actor, allowed):
    view = inbox.load_request(base, name, request_id=request_id, actor_id=actor, allowed_packs=allowed)
    if not view.get('ok'):
        raise ValueError('; '.join(view.get('errors', [])) or 'Open a current configuration review request.')
    if view['status'] != 'validated' or not view.get('validation', {}).get('passed'):
        raise ValueError('Have a second reviewer accept this revision, then apply and validate it before using it.')
    if not view['base_current'] or view['proposal_state'] != 'intact':
        raise ValueError('The product or reviewed proposal changed. Prepare and review a fresh revision.')
    request = view['request']
    accepted = next((item for item in reversed(view['decisions']) if item['act'] == 'accepted'), None)
    if (not accepted or accepted['recorded_by']['owner'] == request['author']['owner']
            or accepted.get('candidate') != request['candidate'] or not _passing(view['validation']['checks'])):
        raise ValueError('This exact revision needs independent acceptance and every required validation result.')
    files = request['files']
    if not files or any(item['path'] not in _allowed() for item in files):
        raise ValueError('This review has no supported configuration files to use.')
    compiled, unsupported = cp._compose(product, request['configuration_changes'])
    if unsupported or cp._encode(compiled) != cp._encode(files):
        raise ValueError('The reviewed files no longer match their supported configuration rules.')
    revision = inbox._revision_dir(product, request_id)
    hashes = {item['path']: cp._digest(item['after'].encode('utf-8')) for item in files}
    if (hashes != request['candidate'] or hashes != view['applied']['applied_files']
            or hashes != view['validation']['validated_files']
            or any(cp._digest(cp._read(cp._safe(revision / rel))) != digest for rel, digest in hashes.items())):
        raise ValueError('The accepted revision or its validation inputs changed. Nothing can be used until it is reviewed again.')
    token = cp._digest(cp._encode({'request': request, 'decisions': view['decisions'],
        'snapshot': cp._snapshot(base, product), 'files': hashes}))
    return view, files, token


def describe(root, pack, actor_id, *, request_id, allowed_packs):
    try:
        base, product, name = _scope(root, pack, actor_id, allowed_packs)
        _no_pending_install(base)
        receipt = _receipt(product, request_id, pack=name)
        if receipt:
            _no_pending_install(base)  # A worker may have started while the historical evidence was read.
            return {'ok': True, 'ready': False, 'used': True, 'receipt': receipt, 'notice': NOTICE, 'errors': []}
        view, files, token = _basis(base, product, name, request_id, actor_id, allowed_packs)
        return {'ok': True, 'ready': True, 'used': False, 'expected_digest': token,
                'files': [entry['path'] for entry in files], 'notice': NOTICE, 'errors': []}
    except (OSError, ValueError, KeyError, TypeError) as error:
        return {'ok': False, 'ready': False, 'used': False, 'errors': [str(error)],
                **({'recovery_required': True} if isinstance(error, _RecoveryRequired) else {})}


def use(root, pack, actor_id, *, request_id, allowed_packs, expected_digest, confirmed=False, can_write=False,
        _boundary=None):
    try:
        base, product, name = _scope(root, pack, actor_id, allowed_packs, write=True)
        if confirmed is not True or can_write is not True:
            raise ValueError('Review these exact changes and confirm that you want to use them for this product.')
        with new_product._standup_guard(base):
            _no_pending_install(base)
            _write_party(_review_document(product, name, request_id)['request'], actor_id)
            receipt = _receipt(product, request_id, pack=name)
            if receipt:
                return {'ok': True, 'changed': False, 'receipt': receipt, 'errors': [], 'notice': NOTICE}
            view, files, token = _basis(base, product, name, request_id, actor_id, allowed_packs)
            if token != expected_digest:
                raise ValueError('The displayed revision changed. Reload it and review the current differences.')
            checks = cp.validate_files(base, product, name, files)
            if not _passing(checks):
                return {'ok': False, 'changed': False, 'errors': ['The current candidate did not pass every required validator.'], 'checks': checks}
            _scope(base, name, actor_id, allowed_packs, write=True)
            _view, _files, after_check = _basis(base, product, name, request_id, actor_id, allowed_packs)
            _write_party(_view['request'], actor_id)
            if after_check != token:
                raise ValueError('The inputs changed while the candidate was checked. Review the fresh revision.')
            record = inbox._sealed({'version': 1, 'request_id': request_id, 'pack': name,
                'recorded_at': datetime.now(timezone.utc).isoformat(), 'actor': actor_id,
                'reviewed_basis': token, 'files': {entry['path']: cp._digest(entry['after'].encode('utf-8')) for entry in files},
                'checks': checks, 'approved': False, 'released': False, 'notice': NOTICE}, 'receipt_sha256')
            receipt_path = _receipt_path(product, request_id).relative_to(base).as_posix()
            expected = {name + '/' + entry['path']: cp._digest(entry['before'].encode('utf-8')) for entry in files}
            expected[receipt_path] = None
            with tempfile.TemporaryDirectory(prefix='rwd-reviewed-config-') as temporary:
                staged = Path(temporary).resolve()
                for entry in files:
                    target = staged / name / entry['path']
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(entry['after'].encode('utf-8'))
                target = staged / receipt_path
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(cp._encode(record))
                new_product.install(base, staged, list(expected), _guarded=True,
                                    expected_before=expected, _boundary=_boundary)
            return {'ok': True, 'changed': True, 'receipt': record, 'errors': [], 'notice': NOTICE}
    except (OSError, ValueError, KeyError, TypeError) as error:
        return {'ok': False, 'changed': False, 'errors': [str(error)]}
