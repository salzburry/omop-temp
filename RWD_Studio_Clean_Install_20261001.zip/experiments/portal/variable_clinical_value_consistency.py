"""Compare overlapping Values and clinical choices without changing either.

This supplements the two schema validators; it is not a clinical validator or
an equivalence engine. A banded Values representation describes the measurement
intervals used by a label-producing panel_bands rule. A codelist describes the
chosen output, not the raw source values or the measurement boundaries. A unit
describes a measured numeric output, not an integer category code. No unit
conversion, synonymous labels, missing-value inference or numerical limit
enforcement is assumed. Incomplete mapping blocks remain saveable drafts; their
own validators continue to prevent execution.
"""
from __future__ import annotations


def _ready_groups(rule):
    """A complete mapping block, independently of its source/window choices."""
    op = rule.get("operator")
    if op not in {"categorical", "panel_categories", "panel_bands"}:
        return None
    groups = rule.get("bands" if op == "panel_bands" else "groups") or []
    if not groups or any(not group.get("label") or group.get("code") is None for group in groups):
        return None
    markers = {group.get("when") for group in groups}
    if "fallthrough" not in markers or (op != "panel_bands" and "missing" not in markers):
        return None
    observed = [group for group in groups if not group.get("when")]
    if not observed:
        return None
    if op == "panel_bands" and any(not {"min", "min_excl", "max", "max_excl"}.intersection(group) for group in observed):
        return None
    if op != "panel_bands" and any(not any(group.get(key) for key in (
            "from_prefixes", "from_equals_ci", "from_startswith_ci", "from_contains_ci")) for group in observed):
        return None
    return groups


def _bands(rule, typed):
    if rule.get("operator") != "panel_bands" or rule.get("result") != "label":
        return []
    groups = _ready_groups(rule)
    if groups is None:
        return []
    # The Values schema has no fallthrough/missing row. Those explicit clinical
    # policies are intentionally not invented as numeric measurement intervals.
    # Inclusivity has no meaning at an open end; normalize it to false on
    # either representation rather than treating it as a clinical difference.
    expected = {item["label"]: (item["lower"], item["upper"],
                               item["lower"] is not None and item["lower_inclusive"],
                               item["upper"] is not None and item["upper_inclusive"])
                for item in typed["bands"]}
    actual = {item["label"]: (item.get("min", item.get("min_excl")), item.get("max", item.get("max_excl")),
                             "min" in item, "max" in item)
              for item in groups if not item.get("when")}
    messages = []
    if set(expected) != set(actual):
        only_values = ", ".join(sorted(set(expected) - set(actual))) or "none"
        only_rule = ", ".join(sorted(set(actual) - set(expected))) or "none"
        messages.append("Number-range category names disagree between Values and the clinical calculation "
                        f"(Values only: {only_values}; calculation only: {only_rule}). "
                        "Use the same category names in both number-range tables before saving.")
    fields = ("From", "To", "Include From", "Include To")
    for label in sorted(set(expected) & set(actual)):
        changed = [field for field, left, right in zip(fields, expected[label], actual[label]) if left != right]
        if changed:
            messages.append(f"Number range '{label}' disagrees in {', '.join(changed)} between Values and the clinical calculation. "
                            "Edit either number-range table so its limits and boundary choices agree before saving.")
    return messages


def _output_mapping(rule):
    """Return explicit (delivered value, meaning) pairs, or None for a draft."""
    result, op = rule.get("result"), rule.get("operator")
    if result not in {"label", "code"}:
        return None
    groups = _ready_groups(rule)
    if groups is not None:
        return [(group["label"] if result == "label" else group["code"], group["label"]) for group in groups]
    if op == "baseline_ecog":
        codes = rule.get("value_codes") or {}
        if (not codes or "Unknown" not in codes or any(code is None for code in codes.values())
                or not rule.get("missing_label") or rule.get("missing_code") is None):
            return None
        pairs = [*codes.items(), (rule["missing_label"], rule["missing_code"])]
        return [(label if result == "label" else code, label) for label, code in pairs]
    if op == "lab_value" and result == "label":
        if not rule.get("present_label") or not rule.get("missing_label"):
            return None
        labels = [rule[key] for key in ("present_label", "missing_label", "unknown_label") if rule.get(key)]
        return [(label, label) for label in labels]
    return None


def _identity(value):
    # Keep boolean, numeric and text codes distinct. Float/int equality is
    # harmless within a numeric codelist; text "1" is never numeric code 1.
    return ("bool" if type(value) is bool else "number" if type(value) in (int, float) else "text", value)


def _codes(rule, typed):
    pairs = _output_mapping(rule)
    if pairs is None:
        return []
    expected = {_identity(item["code"]): item["label"] for item in typed["codes"]}
    actual = {_identity(code): label for code, label in pairs}
    messages = []
    if set(expected) != set(actual):
        display = lambda values: ", ".join(repr(item[1]) for item in sorted(values, key=repr)) or "none"
        messages.append("Allowed output values disagree between Values and the clinical calculation "
                        f"(Values only: {display(set(expected) - set(actual))}; calculation only: {display(set(actual) - set(expected))}). "
                        "Align the Values codelist with the selected category-name or category-number result, "
                        "including its declared missing and all-other-values categories.")
    for code in sorted(set(expected) & set(actual), key=repr):
        if expected[code] != actual[code]:
            messages.append(f"Output value {code[1]!r} means {expected[code]!r} in Values but {actual[code]!r} in the clinical calculation. "
                            "Align the category names for this output value before saving.")
    return messages


def issues(rule, typed_value):
    """Return actionable disagreements for a raw typed representation.

    Call with value_interpretation['value'] when rechecking a saved Values
    interpretation. Source freshness and confirmation remain the caller's job.
    Invalid schemas are reported by their owning validators, not duplicated
    here. Empty/custom rules and absent Values interpretations are inert.
    """
    if not rule or not typed_value:
        return []
    from rwd_tools import spec_value_interpretation
    from experiments.portal import variable_clinical_rules
    try:
        rule = variable_clinical_rules.validate(rule)
        if spec_value_interpretation.validate(typed_value):
            return []
    except (ValueError, TypeError, KeyError):
        return []
    if rule.get("operator") in {None, "", "custom"}:
        return []
    kind = typed_value["kind"]
    if kind == "bands":
        return _bands(rule, typed_value)
    if kind in {"codes", "ordinal", "flag"}:
        return _codes(rule, typed_value)
    if kind == "continuous" and rule.get("operator") == "lab_value" and rule.get("result") == "value":
        unit = typed_value.get("unit")
        units = rule.get("units") or []
        if unit and units and any(item != unit for item in units):
            return [f"The measured output unit is {unit!r} in Values, but the clinical calculation accepts {', '.join(repr(item) for item in units)}. "
                    "Select the same single measurement unit in both editors before saving. Different units need an explicit conversion; this calculation does not convert them."]
    return []
