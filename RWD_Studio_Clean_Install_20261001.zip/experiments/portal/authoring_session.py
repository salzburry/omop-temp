"""Request-scoped authoring authority, independent of demo attribution."""
from contextvars import ContextVar
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Authority:
    root: str
    actor: str
    packs: frozenset[str]
    permissions: frozenset[str]
    mode: str


CURRENT = ContextVar('rwd_authoring_authority', default=None)


def bind(root, actor, packs, permissions, *, mode):
    if mode not in {'hosted', 'local', 'demo'} or not actor or not isinstance(actor, str):
        raise ValueError('An identified application session is required.')
    return CURRENT.set(Authority(str(Path(root).resolve()), actor.strip(), frozenset(packs), frozenset(permissions), mode))


def local_review(authoring_enabled):
    """A hosted write transport never selects development review confirmation."""
    current = CURRENT.get()
    return current.mode in {'local', 'demo'} if current is not None else bool(authoring_enabled)


@contextmanager
def resume(authority, *, root, pack, actor):
    """Restore the server-captured authority for a dialog-only Streamlit rerun.

    Dialog arguments survive a fragment rerun, while ContextVars do not. The
    authority comes from the authenticated full-page render, never form fields
    or browser session state. Sensitive services still recheck the live roster.
    """
    current = CURRENT.get()
    if current is not None and current != authority:
        raise ValueError('The dialog no longer matches the authenticated session. Reload the page.')
    if authority is not None:
        if (not isinstance(authority, Authority) or authority.root != str(Path(root).resolve())
                or actor != authority.actor or pack not in authority.packs):
            raise ValueError('The dialog no longer matches the authenticated session. Reload the page.')
    token = CURRENT.set(authority)
    try:
        yield
    finally:
        CURRENT.reset(token)


def check_scope(root, pack, actor=None):
    """CLI callers retain their explicit scope; hosted calls cannot substitute it."""
    current = CURRENT.get()
    if current is None:
        return
    from experiments.portal.installation_storage import logical_path
    if logical_path(root) != logical_path(current.root) or pack not in current.packs or (actor is not None and actor.strip() != current.actor):
        raise ValueError('This action is outside the authenticated user or product scope.')


def can_edit():
    current = CURRENT.get()
    return bool(current and current.permissions & {'start', 'answer', 'review', 'run_gates', 'pin'})


def require_edit():
    if CURRENT.get() is not None and not can_edit():
        raise ValueError('This authenticated session has read-only access; an editor must save the change.')
