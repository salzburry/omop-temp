"""One reviewed mapping supplies both clinical calculation and output categories."""
from copy import deepcopy

import streamlit as st

from rwd_tools import spec_value_interpretation as interpretation
from experiments.portal import variable_clinical_value_consistency as consistency
from experiments.portal import variable_review_values_page as values_page

_UNSET = object()

def manages(rule):
    return bool(rule and rule.get("operator") in {
        "categorical", "panel_categories", "panel_bands", "baseline_ecog"
    } and rule.get("result") in {"label", "code"})


def output_value(rule, *, missing_allowed=None):
    """Project only explicitly entered output pairs; incomplete rules stay drafts.

    Measurement thresholds and matching conditions remain in the clinical rule.
    The Values record describes its delivered categories, including explicit
    missing/fallthrough categories. No category codes or clinical rules are guessed.
    """
    if not manages(rule):
        return None
    pairs = consistency._output_mapping(rule)
    if pairs is None:
        return None
    return {"kind": "codes", "data_type": "string" if rule["result"] == "label" else "integer",
            "missing_allowed": missing_allowed,
            "codes": [{"code": deepcopy(code), "label": label} for code, label in pairs]}


def render(row, rule, *, key, permitted, seed_value=None, requested_missingness=_UNSET):
    """Keep evidence and missingness visible without a second editable table."""
    if not manages(rule):
        return None
    values_page.render_source_details(row, proposal=row.get("value_proposal"),
                                      saved=row.get("value_interpretation"))
    st.caption("Edit categories and thresholds once in the calculation table below. "
               "Saving also updates this variable's allowed output values and data type.")
    saved = (row.get("value_interpretation") or {}).get("value") or {}
    # Current row fields may include a newer unfinished choice than the last
    # confirmed Values record. Keep that answer visible for reconfirmation.
    nullable = ((row.get("values") or {}).get("output") or {}).get("nullable")
    if type(nullable) is not bool:
        nullable = saved.get("missing_allowed", (seed_value or {}).get("missing_allowed"))
    if requested_missingness is not _UNSET:
        st.session_state[key + "missing"] = ("allowed" if requested_missingness is True else
                                               "not_allowed" if requested_missingness is False else "unspecified")
    selected = st.selectbox("Can it be blank?", ["unspecified", "allowed", "not_allowed"],
        index=1 if nullable is True else 2 if nullable is False else 0,
        format_func=lambda value: {"unspecified": "Not decided — keep the current answer",
                                  "allowed": "Yes", "not_allowed": "No"}[value],
        key=key + "missing", disabled=not permitted)
    missing_allowed = {"unspecified": None, "allowed": True, "not_allowed": False}[selected]
    value = output_value(rule, missing_allowed=missing_allowed)
    if value is None:
        st.caption("Complete the category names, codes and special cases below. Unfinished calculations can be saved as drafts.")
        return {"active": False, "fields": {"output.nullable": missing_allowed} if missing_allowed is not None else {},
                "confirmed": False, "issues": [], "missing_allowed": missing_allowed}
    issues = interpretation.validate(value)
    if row.get("value_proposal_error"):
        issues.append(row["value_proposal_error"])
    for issue in issues:
        st.warning(issue)
    st.caption("Output: " + ("category names (text)" if value["data_type"] == "string" else "category numbers (whole numbers)"))
    return {"active": True, "mode": "categorical", "value": value,
            "missing_allowed": missing_allowed,
            "fields": interpretation.fields_for_value(value) if not issues else {},
            "confirmed": not issues, "issues": issues, "model_proposal": None}
