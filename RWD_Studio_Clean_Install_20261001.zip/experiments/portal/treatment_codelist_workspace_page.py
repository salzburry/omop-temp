"""An ordered category list with one explicit condition editor."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json

import streamlit as st
from experiments.portal import treatment_codelist_rules as rules
from experiments.portal import treatment_codelist_workspace as workspace
from experiments.portal import configuration_proposals as proposals


def render(root, pack, actor_id, *, allowed_packs, local_demo, can_write,
           can_review=False, route=None, params=None):
    prefix = "treatment_codes_" + hashlib.sha256(json.dumps([str(root), pack, actor_id,
        local_demo, can_write, sorted(allowed_packs)]).encode()).hexdigest()[:16]
    current = workspace.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not current["ok"]:
        for error in current["errors"]:
            st.error(error)
        return {}
    params = params or {}
    incoming = params.get("proposal_id") or params.get("packet_id")
    if incoming and st.session_state.get(prefix + "_incoming") != incoming:
        loaded = (proposals.load_shared(root, pack, packet_id=incoming, actor_id=actor_id, allowed_packs=allowed_packs)
                  if params.get("packet_id") else proposals.load(root, pack, proposal_id=incoming,
                      actor_id=actor_id, allowed_packs=allowed_packs))
        if not loaded.get("ok"):
            for error in loaded["errors"]:
                st.error(error)
            return {}
        proposal = (loaded.get("packet") or {}).get("proposal") or loaded.get("proposal") or {}
        prior = next((c["value"] for c in proposal.get("configuration_changes", []) if c["ref"] == rules.REF), None)
        if prior is None:
            st.error("This proposal contains no treatment code list. Open its supported settings instead.")
            return {}
        st.info("Load these saved categories as a new draft using the current product's source bindings. Review their compatibility and order again. Previous checks and approvals are not carried forward.")
        if st.button("Load this proposal into the editor", key=prefix + "_load_" + incoming):
            for entry in list(st.session_state):
                if str(entry).startswith(prefix):
                    del st.session_state[entry]
            st.session_state[prefix + "_draft"] = {**deepcopy(current["document"]),
                **{key: deepcopy(value) for key, value in prior.items() if key in rules.EDITABLE}}
            st.session_state[prefix + "_base"] = current["snapshot_sha256"]
            st.session_state[prefix + "_baseline"] = current["baseline_sha256"]
            st.session_state[prefix + "_generation"] = 0
            st.session_state[prefix + "_incoming"] = incoming
            st.rerun()
        return {}
    if prefix + "_draft" not in st.session_state:
        st.session_state[prefix + "_draft"] = deepcopy(current["document"])
        st.session_state[prefix + "_base"] = current["snapshot_sha256"]
        st.session_state[prefix + "_baseline"] = current["baseline_sha256"]
        st.session_state[prefix + "_generation"] = 0
    draft = st.session_state[prefix + "_draft"]
    generation = st.session_state[prefix + "_generation"]
    key = prefix + "_" + str(generation)
    st.caption("Treatment categories only. Conditions run from top to bottom; the first match wins. "
               "These rules generate treatment category labels and numeric codes. They do not create a cohort or verify terminology membership.")
    st.caption("Source columns and coding systems are kept from the data expert's configuration.")
    with st.expander("Current source bindings"):
        st.json(draft.get("match_on") or {})
    if current["snapshot_sha256"] != st.session_state[prefix + "_base"]:
        st.warning("The product changed. Reload its evidence before staging; your entries remain available.")
        def reload_evidence():
            st.session_state[prefix + "_base"] = current["snapshot_sha256"]
            st.session_state[prefix + "_baseline"] = current["baseline_sha256"]
            st.session_state[key + "_confirmed"] = False
        st.button("Reload evidence and keep my entries", key=key + "_reload", on_click=reload_evidence)
    cats = draft["categories"]
    st.dataframe([{"Order": index + 1, "Code": c.get("code"), "Category": c.get("label"),
        "Condition": json.dumps(c.get("match"), ensure_ascii=False)} for index, c in enumerate(cats)],
        width="stretch", hide_index=True)
    selected = st.selectbox("Category to edit", list(range(len(cats))), index=0 if cats else None,
        format_func=lambda i: f"{i + 1}. {cats[i].get('label') or 'New category'} · code {cats[i].get('code')}",
        key=key + "_selected", placeholder="Add a category below")
    writable = local_demo and can_write
    if st.button("Add a category", key=key + "_add", disabled=not writable):
        used = {c.get("code") for c in cats}
        code = next(i for i in range(len(cats) + 1) if i not in used)
        cats.append({"code": code, "label": "", "match": {"equals": ""}})
        st.session_state[prefix + "_generation"] += 1
        st.rerun()
    pending_condition = False
    if selected is not None:
        category = cats[selected]
        match = category.get("match") or {}
        operator = next(iter(match), "equals")
        options = dict(rules.OPERATORS)
        if not (draft.get("match_on") or {}).get("code_column"):
            options = {op: label for op, label in options.items() if not op.startswith("code_")}
        if operator not in options:
            options[operator] = "Keep existing advanced condition"
        field = key + f"_category_{selected}_"
        # Changing an operation immediately presents its input. The candidate
        # list changes only on the explicit Save condition action.
        chosen = st.selectbox("Match treatment when", list(options), index=list(options).index(operator),
            format_func=options.get, key=field + "op", disabled=not writable)
        with st.container():
            label = st.text_input("Category label", category.get("label", ""), key=field + "label", disabled=not writable)
            code = st.number_input("Output code", min_value=-(2**31), max_value=2**31 - 1,
                value=int(category.get("code", 0)), step=1, key=field + "code", disabled=not writable)
            position = st.number_input("Position in list", min_value=1, max_value=max(1, len(cats)),
                value=selected + 1, step=1, key=field + "position", disabled=not writable)
            value = match.get(chosen) if chosen == operator else None
            if chosen in {"always", "is_null"}:
                new_match = {chosen: True}
                st.caption("This condition needs no matching text.")
            elif chosen in {"like_any", "code_in", "code_prefix_any"}:
                text = st.text_area("Matching values · one per line", "\n".join(value or []), key=field + "values_" + chosen,
                    help="Patterns use % for any sequence and _ for one character. Codes are literal values.", disabled=not writable)
                new_match = {chosen: [v.strip() for v in text.splitlines() if v.strip()]}
            elif chosen in {"equals", "category_equals"}:
                suggestions = sorted({str(c.get("match", {}).get(chosen)) for c in cats
                    if isinstance(c.get("match", {}).get(chosen), str) and c["match"][chosen]
                    and "replace_me" not in c["match"][chosen].lower()})
                custom = "Enter another value…"
                choice = st.selectbox("Known matching values", [*suggestions, custom],
                    index=suggestions.index(value) if value in suggestions else len(suggestions),
                    key=field + "suggestion_" + chosen, disabled=not writable)
                text = (st.text_input("Matching value", value or "", key=field + "value_" + chosen, disabled=not writable)
                        if choice == custom else choice)
                new_match = {chosen: text}
            else:
                st.json(match)
                st.caption("This advanced condition is retained exactly. Choose a different match above to explicitly replace it.")
                new_match = deepcopy(match)
            pending_condition = (label != category.get("label", "") or int(code) != category.get("code")
                or new_match != match or int(position) != selected + 1)
            if st.button("Save condition to list", key=field + "save", disabled=not writable):
                updated = {**category, "label": label, "code": int(code), "match": new_match}
                cats.pop(selected)
                cats.insert(int(position) - 1, updated)
                st.session_state[prefix + "_generation"] += 1
                st.rerun()
        if pending_condition:
            st.info("Save this condition to the list, or discard its edits, before preparing the proposal.")
            if st.button("Discard condition edits", key=field + "discard"):
                st.session_state[prefix + "_generation"] += 1
                st.rerun()
        if st.button("Remove this category", key=field + "remove", disabled=not writable):
            cats.pop(selected)
            st.session_state[prefix + "_generation"] += 1
            st.rerun()
    st.caption("Save a condition to the list before staging. Removing or reordering categories changes which code a treatment receives.")
    # Stable keys keep these independent fields intact while category widgets change.
    draft["name"] = st.text_input("Code-list name", draft.get("name", ""), key=prefix + "_name", disabled=not writable)
    draft["description"] = st.text_area("What the categories mean", draft.get("description", ""), key=prefix + "_description", disabled=not writable)
    draft["version"] = st.text_input("Code-list version", str(draft.get("version", "")), key=prefix + "_version", disabled=not writable)
    sources = draft.get("review_sources") or {}
    citation = st.text_area("Source or specification citation", sources.get("source", ""), key=prefix + "_citation", disabled=not writable)
    rationale = st.text_area("Reason for this change", sources.get("rationale", ""), key=prefix + "_rationale", disabled=not writable)
    draft["review_sources"] = {"source": citation, "rationale": rationale}
    confirmed = st.checkbox("I reviewed every category and its order, including the final remaining-treatments rule.",
        key=key + "_confirmed", disabled=not writable)
    missing = [reason for ready, reason in (
        (writable, "Use a profile with local editing access."),
        (confirmed, "Review the categories and confirm their order above."),
        (not pending_condition, "Save the edited condition to the list, or discard its edits.")) if not ready]
    if missing:
        st.caption(" ".join(missing))
    if st.button("Prepare code-list proposal", key=key + "_stage", type="primary", disabled=bool(missing), help=" ".join(missing) or None):
        proposed = {**deepcopy(draft), "status": "active", "review_sources": {"source": citation, "rationale": rationale}}
        result = workspace.stage(root, pack, actor_id, document=proposed,
            expected_snapshot=st.session_state[prefix + "_base"], expected_baseline=st.session_state[prefix + "_baseline"],
            allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write)
        if not result.get("ok"):
            for error in result["errors"]:
                st.error(error)
        else:
            st.session_state[prefix + "_proposal"] = result["proposal_id"]
            st.success("Code-list proposal saved. Review its diff and run the configuration checks before requesting review. The active product and approvals are unchanged.")
    if st.session_state.get(prefix + "_proposal"):
        if st.button("Review and validate proposal", key=prefix + "_open"):
            return {"route": "plan_changes", "params": {"intent": "configuration", "proposal_id": st.session_state[prefix + "_proposal"]}}
    return {}
