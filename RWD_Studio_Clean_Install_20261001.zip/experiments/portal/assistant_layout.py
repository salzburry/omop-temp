"""Keep the assistant in a predictable rail beside the working page.

The assistant is deliberately laid out here rather than in each page.  That
gives every workflow screen the same place to find help and keeps the page
content in one main column.  The dedicated Agent route opts out and continues
to use the full-width conversation view.
"""
from contextlib import contextmanager, nullcontext
from contextvars import ContextVar
from functools import wraps

import streamlit as st


_dock = ContextVar("portal_assistant_dock", default=None)


@contextmanager
def workspace(*, enabled=True):
    """Render the page with a persistent assistant rail on the right.

    ``in_panel`` renderers are called while the main column is active, so the
    ContextVar lets them write into the rail without every caller having to
    know about the layout. The conversation stays open while a researcher
    works through a long form or a field update reruns the page.
    """
    token = _dock.set(None)
    try:
        if not enabled:
            yield
            return
        with st.container(key="rwd_workspace_layout"):
            # Keep the working form wide while making the assistant's location
            # obvious and stable.  The assistant is open by default so a
            # rerun caused by saving a field or changing pages does not hide
            # the conversation the researcher is using.
            with st.container(key="rwd_workspace_columns"):
                main, rail = st.columns([3.25, 1.15], gap="large",
                                        vertical_alignment="top")
                with rail:
                    with st.container(key="rwd_assistant_rail"):
                        with st.container(key="rwd_assistant_dock"):
                            slot = st.empty()
                _dock.set(slot)
                with main:
                    yield
    finally:
        _dock.reset(token)


@contextmanager
def panel(label, *, expanded=True):
    """Keep workspace chat visible; standalone callers retain their expander."""
    if _dock.get() is None:
        with st.expander(label, expanded=expanded):
            yield
    else:
        with st.container():
            st.subheader(label)
            yield


def in_panel(function=None, *, label=None, expanded=True):
    """Route chat to the dock; isolated pages/tests retain their natural layout.

    A row-specific conversation replaces the general guide in the same slot.
    The surrounding workspace and its unfinished widgets are not rerendered.
    """
    if function is None:
        return lambda renderer: in_panel(renderer, label=label, expanded=expanded)

    @wraps(function)
    def wrapped(*args, **kwargs):
        slot = _dock.get()
        with slot.container() if slot is not None else nullcontext():
            with panel(label, expanded=expanded) if slot is not None and label else nullcontext():
                return function(*args, **kwargs)
    return wrapped
