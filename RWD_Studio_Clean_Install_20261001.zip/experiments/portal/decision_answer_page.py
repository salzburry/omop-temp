"""A scientist's answer form over existing, pack-scoped issued questions."""
from datetime import date
from pathlib import Path
from copy import deepcopy

import streamlit as st

from experiments.portal import decision_answers as answers
from experiments.portal import decision_answer_choices as choices
from experiments.portal import form_assistance as form_help


def clear():
    from experiments.portal import decision_answer_ai_page
    decision_answer_ai_page._clear_feedback()
    for key in list(st.session_state):
        if str(key).startswith("decision_answer_"):
            st.session_state.pop(key, None)


def _remember(decision_id):
    """Keep typed text when Streamlit removes widgets on another workspace page."""
    drafts = dict(st.session_state.get("decision_answer_drafts") or {})
    drafts[decision_id] = {field: str(st.session_state.get(f"decision_answer_{decision_id}_{field}", "")) for field in answers.FIELDS}
    choice = st.session_state.get(f"decision_answer_{decision_id}_answer_choice")
    if choice:
        drafts[decision_id]["answer_choice"] = deepcopy(choice)
    st.session_state["decision_answer_drafts"] = drafts


def _fill(decision_id, field, value):
    """A button's click writes one field (the clicker's name, today's date) before the next run draws
    the input; nothing is filled in until the person clicks."""
    st.session_state[f"decision_answer_{decision_id}_{field}"] = str(value)
    _remember(decision_id)


def _answer_changed(decision_id):
    choices.note_edit(decision_id)
    _remember(decision_id)


def _field_mapping_draft(root, pack, actor_id, item, *, enabled):
    from rwd_tools import decision_choice
    did = item["id"]
    state_key = f"decision_answer_{did}_answer_choice"
    selected = st.session_state.get(state_key)
    if item["status"] != "OPEN" or not selected:
        return False
    if (decision_choice.follow_up_topic(item["question"]) or {}).get("kind") == "scope":
        st.caption("This choice records date scope. It cannot fill a variable formula automatically; the remaining date rules and implementation need separate review.")
        return False
    current = selected.get("field_binding") or {}
    key = f"decision_answer_{did}_map_{selected['selected_option_id']}_"
    with st.expander("Fill a variable from this choice", expanded=bool(current)):
        use = st.checkbox("Use this choice to fill a variable", value=bool(current), key=key + "use", disabled=not enabled)
        if not use:
            selected.pop("field_binding", None)
            _remember(did)
            return False
        context = answers.mapping_context(root, pack, actor_id, did, allowed_packs=[pack])
        if not context.get("ok") or not context.get("rows"):
            st.info("This question needs a linked variable in its evidence or decision citations before its answer can fill a field.")
            return True
        rows = {row["item_id"]: row for row in context["rows"]}
        ids = list(rows)
        item_id = st.selectbox("Variable to fill", ids, index=ids.index(current["item_id"]) if current.get("item_id") in ids else None,
            format_func=lambda value: rows[value]["variable_id"], key=key + "item", disabled=not enabled)
        if item_id is None:
            return True
        row = rows[item_id]
        if row.get("clinical_rule") or row.get("family"):
            fields = ["clinical_rule.pick"] if row.get("clinical_rule") and "pick" in row["clinical_rule"] else []
        else:
            fields = [field for field in decision_choice.BINDING_FIELDS if field != "clinical_rule.pick"]
        if not fields:
            st.info("Edit this variable's typed calculation settings in variable review; this question cannot map to an unsupported setting.")
            return True
        field = st.selectbox("Field to fill", fields, index=fields.index(current["field"]) if current.get("field") in fields else None,
            format_func=lambda value: decision_choice.BINDING_FIELDS[value], key=key + item_id + "field", disabled=not enabled)
        if field is None:
            return True
        from experiments.portal import variable_review_workflow as workflow
        before = row["clinical_rule"]["pick"] if field == "clinical_rule.pick" else workflow._get(row["values"], field)
        if field == "clinical_rule.pick":
            policies = ["nearest", "earliest", "latest"]
            value = st.selectbox("Value to put in this field", policies, index=policies.index(current["value"]) if current.get("value") in policies else None,
                key=key + item_id + field + "value", disabled=not enabled)
        else:
            value = st.text_area("Value to put in this field", value=current.get("value", selected["selected_value"]),
                max_chars=4000, key=key + item_id + field + "value", disabled=not enabled,
                help="Enter the exact field value. The starting text is the selected option, not a generated clinical rule.")
        scope = st.text_area("Scope of this field change", value=current.get("scope", ""), max_chars=1000, key=key + "scope", disabled=not enabled)
        rationale = st.text_area("Rationale for this field change", value=current.get("rationale", selected["explanation"]), max_chars=1500, key=key + "rationale", disabled=not enabled)
        st.dataframe([{"Field": decision_choice.BINDING_FIELDS[field], "Current": str(before or ""), "Proposed": str(value or "")}], hide_index=True, width="stretch")
        st.caption("Recording the answer retains this mapping. Review and apply the field change after the answer is recorded.")
        binding = {"schema_version": 1, "selected_option_id": selected["selected_option_id"], "item_id": item_id,
            "variable_id": row["variable_id"], "field": field, "value": value, "scope": scope, "rationale": rationale}
        try:
            selected["field_binding"] = decision_choice.field_binding(binding, selected["selected_option_id"])
            answers._mapping_row(context, selected["field_binding"])
        except ValueError as error:
            st.info(str(error))
            return True
        st.session_state[state_key] = selected
        _remember(did)
        return False


def _recorded_field_mapping(root, pack, actor_id, item, *, enabled, local_demo, can_write):
    selected = item["values"].get("answer_choice") or {}
    if item["status"] != "RESOLVED" or not selected.get("field_binding"):
        return
    from rwd_tools import decision_choice
    did = item["id"]
    key = f"decision_answer_{did}_application_"
    with st.expander("Apply this answer to its variable", expanded=True):
        if st.session_state.get(key + "notice"):
            st.success(st.session_state[key + "notice"])
        if st.button("Preview mapped field", key=key + "preview"):
            st.session_state[key + "draft"] = answers.preview_mapping(root, pack, actor_id, did, allowed_packs=[pack])
        preview = st.session_state.get(key + "draft")
        if not preview:
            st.caption("The recorded option includes a field mapping. Preview the current variable before applying it.")
            return
        if not preview.get("ok"):
            for error in preview.get("errors") or []:
                st.warning(error)
            return
        binding = preview["binding"]
        st.write(f"**{binding['variable_id']} · {decision_choice.BINDING_FIELDS[binding['field']]}**")
        st.dataframe([{"Current": str(preview["before"] or ""), "After applying": preview["after"]}], hide_index=True, width="stretch")
        st.text("Scope: " + binding["scope"])
        st.text("Rationale: " + binding["rationale"])
        confirmed = st.checkbox("I reviewed this field change.", key=key + preview["preview_digest"] + "review", disabled=not enabled)
        logic_reviewed = False
        if preview["logic_review_required"]:
            st.text("Rule to confirm: " + str(preview["updates"]["derivation"]))
            logic_reviewed = st.checkbox("I reviewed this rule's thresholds and time windows.", key=key + preview["preview_digest"] + "logic", disabled=not enabled)
        st.caption("Apply updates the scientific draft. It does not confirm the review phase, approve the contract or activate configuration.")
        if st.button("Apply to variable", key=key + "apply", disabled=not enabled or not confirmed or preview["logic_review_required"] and not logic_reviewed):
            result = answers.apply_mapping(root, pack, actor_id, did, expected_preview_digest=preview["preview_digest"], confirmed=confirmed,
                logic_reviewed=logic_reviewed, local_demo=local_demo, can_write=can_write, allowed_packs=[pack])
            if result.get("ok"):
                st.session_state[key + "notice"] = binding["variable_id"] + " updated from the recorded choice. Scientific review is still required."
                st.session_state.pop(key + "draft", None)
                st.rerun()
            for error in result.get("errors") or []:
                st.error(error)


def _question_owner(root, pack, decision_id):
    """Read the selected question's recorded owner through the scoped source reader."""
    try:
        _root, _pack, product = answers._paths(root, pack, [pack])
        text = answers._read(product / answers.dr.DECISIONS).decode("utf-8")
        row = answers.cl.decision_rows(text).get(decision_id)
        return str(answers.cl.decision_owner(row) or "").strip() if row else ""
    except (ValueError, OSError, TypeError, KeyError):
        return ""


RAISE_KEYS = ("decision_answer_raise_id", "decision_answer_raise_question", "decision_answer_raise_evidence", "decision_answer_raise_owner")


def _remember_raise():
    st.session_state["decision_answer_raise_draft"] = {key: st.session_state.get(key) for key in RAISE_KEYS}


def _use_question_draft(draft):
    st.session_state["decision_answer_raise_question"] = draft["question"]
    st.session_state["decision_answer_raise_evidence"] = draft["evidence"]
    st.session_state["decision_answer_raise_continuation"] = draft["signature"]
    st.session_state["decision_answer_raise_expanded"] = True
    _remember_raise()


def _question_continuation(pack, actor_id, incoming, *, enabled):
    if isinstance(incoming, dict) and isinstance(incoming.get("question"), str) and incoming["question"].strip():
        draft = {field: incoming.get(field) if isinstance(incoming.get(field), str) else ""
                 for field in ("question", "variable", "source", "context", "evidence")}
        signature = tuple(draft.values())
        if st.session_state.get("decision_answer_question_incoming") != signature:
            st.session_state["decision_answer_question_incoming"] = signature
            st.session_state["decision_answer_question_continuation"] = {**draft, "signature": signature}
    draft = st.session_state.get("decision_answer_question_continuation")
    if not draft:
        return None
    st.write("**Draft question from dataset comparison**" if draft["source"] == "dataset_comparison" else "**Draft question from the workflow**")
    if draft["variable"]:
        st.text("Variable: " + draft["variable"])
    if draft["context"]:
        st.text("Comparison: " + draft["context"])
    st.text(draft["question"])
    if draft["evidence"]:
        st.text("Suggested evidence: " + draft["evidence"])
    if draft.get("recorded_id"):
        st.info(f"Question {draft['recorded_id']} was recorded. Prepare or continue its answer draft below; creating the question does not establish pooling equivalence.")
    else:
        st.caption("This question is not in the register yet. Copy it into Raise a new question, review the wording and evidence, "
                   "then choose its identifier and owner before recording it as open. No answer or review details are supplied.")
        st.button("Use this question draft", key="decision_answer_use_question_draft", disabled=not enabled,
                  help="Copies the question and evidence into the unsaved form, replacing those two fields. Review them before raising the question.",
                  on_click=_use_question_draft, args=(draft,))
    if draft["source"] == "dataset_comparison":
        if st.button("Return to dataset comparison", key="decision_answer_return_comparison"):
            from experiments.portal import connected_workflow_page
            connected_workflow_page.open_route("dataset_comparison", pack, actor_id, params={"variable": draft["variable"]})
    return draft


def _refresh(pack, context, description, notice):
    """Show `notice` on the next render over the re-read questions; unsaved answer drafts stay.

    The snapshot is replaced, not dropped: a missing snapshot reads as a changed product and
    clears every widget, which would take the notice and the person's unsaved drafts with it.
    """
    st.session_state["decision_answer_snapshot"] = {"context": context, "description": description}
    st.session_state.setdefault("flow_result", {}).pop(pack, None)
    st.session_state["decision_answer_notice"] = notice
    st.rerun()


def _raise_form(root, pack, context, description, *, enabled, can_write, local_demo):
    """One open question appended to the register (2026-09-07, DL-03). No answer, name or date."""
    owners = description.get("owners") or []
    with st.expander("Raise a new question", expanded=bool(st.session_state.get("decision_answer_question_continuation") or st.session_state.get("decision_answer_raise_expanded"))):
        st.caption("Add one open question to the decision register. It records no answer, no name and no date; the owner is the role the question goes to.")
        if not owners:
            st.info("The register does not name any owner yet, so a new question has nobody to go to. Ask your data expert to record the first question.")
            return
        if not enabled:
            st.info("Raising a question requires product-author access in a local demo.")
        for key, value in (st.session_state.get("decision_answer_raise_draft") or {}).items():
            if key in RAISE_KEYS and value is not None:
                st.session_state.setdefault(key, value)
        form_help.field(st.text_input, "Question identifier", key="decision_answer_raise_id", disabled=not enabled, binding=description["digest"],
                      on_change=_remember_raise,
                      help="Capital letters, digits and dashes, for example LOT-NULL. Contract records cite this identifier.")
        form_help.field(st.text_area, "Question", key="decision_answer_raise_question", max_chars=1000, disabled=not enabled, binding=description["digest"],
                     on_change=_remember_raise,
                     help="One plain sentence. Avoid | because the register is a table; detail belongs in the answer form.")
        form_help.field(st.text_input, "Evidence", key="decision_answer_raise_evidence", disabled=not enabled, binding=description["digest"],
                      on_change=_remember_raise,
                      help="What the answerer should read: a specification row such as clinical:3, a finding identifier, or a file in the product.")
        form_help.field(st.selectbox, "Owner", owners, index=None, key="decision_answer_raise_owner", placeholder="Choose who answers this question", disabled=not enabled, binding=description["digest"],
                     on_change=_remember_raise,
                     help="The roles the register already uses. A question put to nobody is one nobody answers.")
        if st.button("Raise this question", key="decision_answer_raise", disabled=not enabled):
            values = {name: str(st.session_state.get(key) or "") for name, key in zip(answers.RAISE_FIELDS, RAISE_KEYS)}
            if not all(value.strip() for value in values.values()):
                st.warning("Enter the identifier, the question, its evidence and the owner before raising it.")
                return
            result = answers.raise_question(root, pack, values, expected_digest=description["digest"],
                                            local_demo=local_demo, can_write=can_write, allowed_packs=[pack])
            if result.get("ok"):
                continuation = st.session_state.get("decision_answer_question_continuation")
                if continuation and st.session_state.get("decision_answer_raise_continuation") == continuation["signature"]:
                    st.session_state["decision_answer_question_continuation"] = {**continuation, "recorded_id": result["raised"],
                        "question": values["question"], "evidence": values["evidence"]}
                for key in RAISE_KEYS:
                    st.session_state.pop(key, None)
                st.session_state.pop("decision_answer_raise_draft", None)
                st.session_state.pop("decision_answer_raise_continuation", None)
                _refresh(pack, context, result, f"Question {result['raised']} raised and recorded as open. Prepare its question draft when you are ready to answer it; nothing has been decided.")
            for error in result.get("errors") or ["The question could not be raised."]:
                st.error(str(error))
            if result.get("stale_lock"):
                st.session_state["decision_answer_stale_lock"] = True


def _recheck_worklist(root, pack, actor_id, context, *, enabled, can_write, local_demo):
    """Records that cite answered questions and still wait as decision_required (DL-04)."""
    waiting = answers.settled_records(root, pack, allowed_packs=[pack])
    if not waiting:
        return
    st.write("**Records waiting for a re-check**")
    st.caption("These contract records cite questions that are now answered. Re-checking applies each record's own judgments again through the contract checks so its status can move on. Nothing in the record is edited, and nothing is approved.")
    for entry in waiting:
        left, right = st.columns([3, 1])
        left.text(f"{entry['variable_id']} cites {', '.join(entry['decision_ids'])}")
        if right.button("Re-check record", key=f"decision_answer_recheck_{entry['variable_id']}", disabled=not enabled):
            result = answers.recheck_record(root, pack, actor_id, entry["variable_id"], local_demo=local_demo,
                                            can_write=can_write, allowed_packs=[pack])
            if result.get("ok"):
                _refresh(pack, context, answers.describe(root, pack, allowed_packs=[pack]),
                         f"{entry['variable_id']} re-checked. Its requirement status is now {result.get('requirement') or 'updated'}. "
                         "The definition still needs the answer written in and the named review; nothing is approved.")
            for error in result.get("errors") or ["The record could not be re-checked."]:
                st.error(str(error))
            if result.get("reopen"):
                st.session_state["decision_answer_reopen_offer"] = entry["variable_id"]
            if result.get("stale_lock"):
                st.session_state["decision_answer_stale_contract_lock"] = True
    offer = st.session_state.get("decision_answer_reopen_offer")
    if offer:
        # the act the record check names, on this page (walk NEW-7)
        st.info(f"{offer} changed after the contract was approved. Reopen the approval so the record can be re-checked; "
                "the approval form is then prepared again over the new contract.")
        if st.button("Reopen the contract approval and re-check", key="decision_answer_reopen_contract", disabled=not enabled):
            reopened = answers.reopen_contract(root, pack, actor_id, local_demo=local_demo, can_write=can_write, allowed_packs=[pack])
            for error in reopened.get("errors") or []:
                st.error(str(error))
            if reopened.get("ok"):
                st.session_state.pop("decision_answer_reopen_offer", None)
                again = answers.recheck_record(root, pack, actor_id, offer, local_demo=local_demo, can_write=can_write, allowed_packs=[pack])
                if again.get("ok"):
                    _refresh(pack, context, answers.describe(root, pack, allowed_packs=[pack]),
                             f"{reopened['message']} {offer} re-checked; its requirement status is now {again.get('requirement') or 'updated'}.")
                for error in again.get("errors") or []:
                    st.error(str(error))
    if st.session_state.get("decision_answer_stale_contract_lock"):
        st.warning("An earlier contract save left its lock behind. If nobody else is saving the contract, clear it and re-check again.")
        if st.button("Clear the stale lock", key="decision_answer_clear_contract_lock", disabled=not enabled):
            from experiments.portal import scientific_definitions
            cleared = scientific_definitions.clear_stale_lock(root, pack, actor_id, local_demo=local_demo, can_write=can_write, allowed_packs=[pack])
            st.session_state.pop("decision_answer_stale_contract_lock", None)
            if cleared.get("ok"):
                st.success("The stale lock was cleared. Re-check the record again.")
            for error in cleared.get("errors") or []:
                st.error(str(error))


def _prepare_linked_question(item_id, variable):
    st.session_state["decision_answer_raise_question"] = f"What rule should apply to {variable or item_id}?"
    st.session_state["decision_answer_raise_evidence"] = item_id
    st.session_state["decision_answer_raise_expanded"] = True
    _remember_raise()


def _disposition_worklist(root, pack, actor_id, context, *, enabled, can_write, local_demo):
    from experiments.portal import specification_row_context as links
    report = links.decision_links(root, pack, actor_id, allowed_packs=[pack])
    if not report.get("ok"):
        st.warning("Source-row question links need attention: " + " ".join(answers.plain(error) for error in report.get("errors", [])))
        return
    rows = report.get("rows", [])
    if not rows:
        return
    with st.expander("Requirements linked to questions", expanded=any(row["errors"] for row in rows)):
        st.caption("An answered question keeps its source-row link. It does not approve the requirement or implement its rule.")
        by_id = {row["item_id"]: row for row in rows}
        key = "decision_answer_linked_row"
        if st.session_state.get(key) not in by_id:
            st.session_state[key] = next(iter(by_id))
        selected = st.selectbox("Linked specification row", list(by_id), key=key,
            format_func=lambda item: f"{item} · {by_id[item]['variable']} · {by_id[item]['status'].lower()}")
        row = by_id[selected]
        st.text(f"{row['decision_id']} · {row['status'].lower()} · {row['disposition']}")
        if row["answer"] and not row["errors"]:
            st.write(row["answer"])
        if row["handled_by"]:
            st.caption("Handled by: " + row["handled_by"])
        for error in row["errors"]:
            st.warning(answers.plain(error))
        if row["errors"] and not row["cited"]:
            choices_by_id = {choice["id"]: choice for choice in row["choices"]}
            replacement = st.selectbox("Replacement question about this row", list(choices_by_id), index=None,
                key=f"decision_answer_relink_{selected}_{row['digest']}",
                format_func=lambda did: f"{did} · {choices_by_id[did]['status'].lower()} · {choices_by_id[did]['question']}",
                disabled=not enabled or not choices_by_id)
            confirmed = st.checkbox("I checked that this question addresses this specification row.",
                key=f"decision_answer_relink_confirm_{selected}_{row['digest']}_{replacement}", disabled=not enabled or not replacement)
            if st.button("Save replacement question link", key="decision_answer_save_link", disabled=not enabled or not confirmed):
                result = links.relink_decision(root, pack, actor_id, selected, replacement,
                    expected_digest=row["digest"], confirmed=confirmed, local_demo=local_demo,
                    can_write=can_write, allowed_packs=[pack])
                if result.get("ok"):
                    _refresh(pack, context, answers.describe(root, pack, allowed_packs=[pack]), result["message"])
                for error in result.get("errors", []):
                    st.error(answers.plain(error))
            st.button("Prepare a new question for this row", key="decision_answer_prepare_link_question", disabled=not enabled,
                help="Copies this row and a proposed question into Raise a new question below. Review them before recording it.",
                on_click=_prepare_linked_question, args=(selected, row["variable"]))
        if st.button("Review this requirement", key="decision_answer_review_linked_row"):
            from experiments.portal import connected_workflow_page
            connected_workflow_page.open_route("scientific_draft", pack, actor_id, params={"item_id": selected})


def _stale_lock_offer(root, pack, *, enabled, can_write, local_demo):
    """After a save met a lock older than ten minutes, let the person clear that one file (DL-06)."""
    if not st.session_state.get("decision_answer_stale_lock"):
        return
    st.warning("An earlier save left its lock behind. If nobody else is saving answers for this product, clear it and save again.")
    if st.button("Clear the stale lock", key="decision_answer_clear_lock", disabled=not enabled):
        cleared = answers.clear_stale_lock(root, pack, local_demo=local_demo, can_write=can_write, allowed_packs=[pack])
        st.session_state.pop("decision_answer_stale_lock", None)
        if cleared.get("ok"):
            st.success("The stale lock was cleared. Save your answer again.")
        for error in cleared.get("errors") or []:
            st.error(str(error))


def _follow_up_questions(description, *, enabled):
    """Surface independent scientific topics without creating or resolving a question."""
    from rwd_tools import decision_choice
    rows = []
    for item in description.get("registered_questions", description.get("items", [])):
        topic = decision_choice.follow_up_topic(item.get("question"))
        if topic:
            rows.append({"Question": item["id"], "Topic": topic["title"], "Status": item["status"],
                         "Owner": item.get("owner", ""), "kind": topic["kind"]})
    if not rows:
        return
    with st.expander("Follow-up and death-date choices", expanded=any(row["Status"] == "OPEN" for row in rows)):
        st.dataframe([{key: value for key, value in row.items() if key != "kind"} for row in rows],
                     hide_index=True, width="stretch")
        st.caption("Date scope, follow-up sources and caps, the death-flag formula, and outcome handling are separate decisions. Resolving one does not resolve the others.")
        if not any(row["kind"] == "scope" for row in rows):
            st.info("There is no separate date-scope question in this list. If this product needs FUED and DTHDT, confirm whether those dates are shared across a patient's index dates.")
            draft = decision_choice.follow_up_scope_draft()
            draft["context"] = "Check this product's follow-up and mortality requirements before adding a separate scope question."
            draft["signature"] = tuple(draft.values())
            st.button("Draft a date-scope question", key="decision_answer_draft_date_scope", disabled=not enabled,
                help="Copies an unanswered question into Raise a new question. Review its wording, identifier, evidence and owner before recording it.",
                on_click=_use_question_draft, args=(draft,))


def render(root, pack, actor_id, *, local_demo, can_write, can_view, initial_decision_id=None, actor_name=None, question_draft=None):
    """Return True only after a validated save. Names and dates are never inferred."""
    if not can_view:
        clear()
        st.warning("You no longer have access to this product's questions.")
        return False
    context = (str(Path(root).resolve()), pack, actor_id)
    cached = st.session_state.get("decision_answer_snapshot")
    context_changed = isinstance(cached, dict) and cached.get("context") != context
    if not isinstance(cached, dict) or cached.get("context") != context:
        clear()
        description = answers.describe(root, pack, allowed_packs=[pack])
        st.session_state["decision_answer_snapshot"] = {"context": context, "description": description}
    else:
        description = cached["description"]
    st.write("**Answer a question**")
    st.caption("Choose a question, write your answer and record it after review. Your unfinished answers stay here.")
    continuation = _question_continuation(pack, actor_id, question_draft,
        enabled=bool(local_demo and can_write and description.get("ok") and description.get("owners")))
    initial_decision_id = initial_decision_id or (continuation or {}).get("recorded_id")
    if not description.get("ok"):
        for error in description.get("errors") or ["The questions could not be read."]:
            st.warning(str(error))
        if st.button("Reload questions", key="decision_answer_reload"):
            clear()
            st.rerun()
        return False
    # The widgets were cleared above when the product or person changed, so the form is safe to
    # enable on this very render (it used to say 'requires product-author access' to a person who
    # had it, for one click, after every product switch).
    enabled = local_demo and can_write
    if not enabled:
        st.info("Saving answers requires product-author access in a local demo.")
    notice = st.session_state.pop("decision_answer_notice", None)
    if notice:
        st.success(str(notice))
    for error in st.session_state.pop("decision_answer_completion_errors", []):
        st.warning(str(error))
    with st.expander("Saved decision checks", expanded=False):
        if description.get("completion_pending_ids") or not description.get("report_current", True):
            st.caption("Refresh saved answers and their evidence. Unfinished answers stay open.")
            for problem in description.get("completion_problems", []):
                st.warning(str(problem))
            if st.button("Update saved decision evidence", key="decision_answer_complete", disabled=not enabled):
                result = answers.complete_saved(root, pack, expected_digest=description["digest"],
                    local_demo=local_demo, can_write=can_write and can_view, allowed_packs=[pack])
                if result.get("ok"):
                    st.session_state["decision_answer_snapshot"] = {"context": context, "description": result}
                    st.session_state["decision_answer_completion_errors"] = result.get("completion_errors", [])
                    if result.get("completion_ok"):
                        st.session_state["decision_answer_notice"] = "Saved decision evidence and ranked questions are current. Reviewer authentication is still a separate step."
                    st.session_state.setdefault("flow_result", {}).pop(pack, None)
                    st.rerun()
                for error in result.get("errors", []):
                    st.error(str(error))
        _recheck_worklist(root, pack, actor_id, context, enabled=enabled, can_write=can_write and can_view, local_demo=local_demo)
    _disposition_worklist(root, pack, actor_id, context, enabled=enabled, can_write=can_write and can_view, local_demo=local_demo)
    _follow_up_questions(description, enabled=enabled)
    _raise_form(root, pack, context, description, enabled=enabled, can_write=can_write and can_view, local_demo=local_demo)
    unissued = description.get("unissued_ids") or []
    if unissued:
        with st.expander("More open questions" if description.get("items") else "Start answering", expanded=not bool(description.get("items"))):
            st.caption(f"{len(unissued)} open question(s): " + ", ".join(unissued))
            st.caption("Open blank answer forms for these questions. Nothing is answered or approved.")
            if st.button("Start answering" if not description.get("items") else "Prepare remaining questions", key="decision_answer_prepare", disabled=not enabled, type="primary" if not description.get("items") else "secondary"):
                # the register may have changed since this page was drawn (a definition was just saved):
                # read it again here instead of refusing and sending the person to find Reload (walk UC3-P2-2)
                current = answers.describe(root, pack, allowed_packs=[pack])
                digest = current["digest"] if current.get("ok") else description["digest"]
                prepared = answers.prepare_forms(root, pack, expected_digest=digest,
                    local_demo=local_demo, can_write=can_write and can_view, allowed_packs=[pack])
                if prepared.get("ok"):
                    st.session_state["decision_answer_snapshot"] = {"context": context, "description": prepared}
                    st.success("Question drafts prepared. Choose a question and write your answer; no decision has been recorded.")
                    st.session_state["decision_answer_last_action"] = "prepared"
                    return True
                for error in prepared.get("errors") or ["Question drafts could not be prepared."]:
                    st.error(str(error))
    items = description.get("items") or []
    if not items:
        st.caption("Choose Start answering above to open these questions." if unissued else "There are no answer forms yet. Use Raise a new question to add one.")
        _stale_lock_offer(root, pack, enabled=enabled, can_write=can_write and can_view, local_demo=local_demo)
        return False
    editable = [item for item in items if item["editable"]]
    ordered = editable + [item for item in items if not item["editable"]]
    by_id = {item["id"]: item for item in ordered}
    if initial_decision_id in by_id and st.session_state.get("decision_answer_incoming") != initial_decision_id:
        st.session_state["decision_answer_selected"] = initial_decision_id
        st.session_state["decision_answer_incoming"] = initial_decision_id
    if st.session_state.get("decision_answer_selected") not in by_id:
        st.session_state["decision_answer_selected"] = next(iter(by_id))
    # Preserve another question's unsaved input when its widgets are not rendered.
    for key in list(st.session_state):
        if str(key).startswith("decision_answer_") and (any(str(key).endswith("_" + field) for field in answers.FIELDS) or str(key).endswith(("_approach", "_choice_explanation"))):
            st.session_state[key] = st.session_state[key]
    selected = st.selectbox("Question", list(by_id), format_func=lambda did: f"{did} · {by_id[did]['question'][:90]} · {by_id[did]['status'].lower()}", key="decision_answer_selected")
    item = by_id[selected]
    fresh = answers.describe(root, pack, allowed_packs=[pack])
    stale = not fresh.get("ok") or fresh.get("digest") != description["digest"]
    if stale:
        st.error("The questions, forms or contract changed while this page was open. Your entries are retained; reload and review the current question before recording a decision.")
        if st.button("Reload current questions and keep my drafts", key="decision_answer_reload_keep"):
            if all(f"decision_answer_{selected}_{field}" in st.session_state for field in answers.FIELDS):
                _remember(selected)
            st.session_state["decision_answer_snapshot"] = {"context": context, "description": fresh}
            for key in list(st.session_state):
                if str(key).startswith("decision_answer_ai_"):
                    del st.session_state[key]
            st.rerun()
    st.text(item["question"])
    from rwd_tools import decision_choice
    topic = decision_choice.follow_up_topic(item["question"])
    if topic:
        st.info(topic["explanation"])
        if topic["kind"] == "scope":
            st.warning(("Scientific scope is unresolved until its owner records an answer. " if item["status"] == "OPEN" else
                        "A recorded scope answer does not establish execution support or scientific approval. ") +
                       "The current engine supports per-index dates; that existing behavior is not an approval. A shared patient-level pair is not implemented and is refused at build time.")
            st.caption("A shared patient-level pair also needs a month-only death-date anchor and an explicit rule for any cohort whose index follows FUED. Record those dependent questions before an implementation handoff. Choosing per-index still leaves follow-up sources/caps and the death-flag formula to review.")
    owner = _question_owner(root, pack, selected)
    if owner:
        st.caption("Question owner: " + owner + (" · This question needs an engineering answer; record the responsible owner’s decision." if "engineer" in owner.casefold() else ""))
    st.text("Evidence: " + (item["evidence"] or "No evidence supplied."))
    if item["status"] == "OPEN" and str(item["values"].get("answer") or "").strip():
        st.caption("This question remains open. RESOLVED in a prepared answer file is its proposed outcome. "
                   "Review the draft, then choose Save this answer to record it; saving does not authenticate approval.")
    for error in item["errors"]:
        st.warning(str(error))
    if not item["editable"] and item["status"] != "OPEN":
        st.info("This question is already recorded. A changed ruling needs a new decision, preserving the earlier answer.")
    draft = (st.session_state.get("decision_answer_drafts") or {}).get(selected, item["values"])
    for field in answers.FIELDS:
        st.session_state.setdefault(f"decision_answer_{selected}_{field}", draft.get(field, item["values"][field]))
    if draft.get("answer_choice") and f"decision_answer_{selected}_answer_choice" not in st.session_state:
        st.session_state[f"decision_answer_{selected}_answer_choice"] = deepcopy(draft["answer_choice"])
    editable_here = enabled and item["editable"]
    # CHOICES FIRST, THEN HELP, THEN THE TEXT (2026-09-07): the product owner asked for questions that
    # are simple to answer - a choice to pick or an AI suggestion to accept - with free text as the
    # fallback. The choices quote the question's own alternatives; nothing here selects one.
    st.write("**Draft an answer**")
    # An AI copy accepted below lands here, before the choice widgets exist in this run: the copy
    # resets the drafting choice, and a widget's value cannot change once it has been drawn.
    pending = st.session_state.pop("decision_answer_pending_copy", None)
    if isinstance(pending, dict) and pending.get("id") == selected and editable_here:
        choices.use_answer(selected, str(pending.get("answer") or ""))
        _remember(selected)
    guide = choices.render(selected, item["question"], enabled=editable_here, remember=_remember,
        form={"question": item["question"], "evidence": item["evidence"],
              "question_sha256": item["question_digest"], "records_sha256": item.get("records_digest", "")})
    with st.expander("Suggest an answer with AI (optional; you review it before it is used)"):
        from experiments.portal import decision_answer_ai_page
        copied = decision_answer_ai_page.render(root, pack, actor_id, item,
            str(st.session_state.get(f"decision_answer_{selected}_answer", "")),
            expected_digest=description["digest"], local_demo=local_demo, can_write=editable_here and not stale,
            allowed_packs=[pack])
        if copied is not None and editable_here:
            st.session_state["decision_answer_pending_copy"] = {"id": selected, "answer": copied}
            st.session_state["decision_answer_notice"] = ("Option copied into your unsaved draft. Review and edit it below. "
                                                          "No decision maker, date or saved decision was changed.")
            st.rerun()
    form_help.field(st.text_area, "Draft answer", key=f"decision_answer_{selected}_answer", max_chars=4000, disabled=not editable_here, on_change=_answer_changed, args=(selected,), binding=description["digest"],
                 help="Example format: state your reviewed rule, its scope and rationale. Keep TODO for unresolved choices. Avoid | because the decision register is a table.")
    answer_text = str(st.session_state.get(f"decision_answer_{selected}_answer", ""))
    decision_answer_ai_page.offer_feedback(root, pack, actor_id, item, answer_text,
        expected_digest=description["digest"], can_write=editable_here and not stale, allowed_packs=[pack])
    unresolved = answers.unresolved_answer(answer_text)
    if unresolved:
        st.info("This answer is unfinished. Review each TODO or unresolved choice and edit the text when the decision has been made. No decision has been recorded.")
    mapping_pending = _field_mapping_draft(root, pack, actor_id, item, enabled=editable_here and not stale)
    with st.expander("Review and record the decision", expanded=bool(answer_text.strip()) and not unresolved):
        st.caption("Enter who actually made the decision and the date they made it. Draft choices and AI never fill these fields.")
        left, right = st.columns(2)
        with left:
            st.text_input("Decision maker's name", key=f"decision_answer_{selected}_answered_by", disabled=not editable_here, on_change=_remember, args=(selected,),
                          help="The person who made this decision; this is a typed attribution, not a signature.")
            # ONE CLICK, STILL THE PERSON'S ACT: the button writes the name of the person who clicked
            # it, nothing is filled in before they do, and a different decision maker is typed.
            # the click writes the field in an on_click callback: callbacks run before the widgets of the
            # next run are drawn, which is the only moment Streamlit lets a widget's value be set
            # (writing it after the input was drawn crashed the form: walk UC1-03, 2026-09-07)
            if actor_name and editable_here:
                st.button(f"I made this decision: {actor_name}", key=f"decision_answer_{selected}_me",
                          on_click=_fill, args=(selected, "answered_by", str(actor_name)))
        with right:
            st.text_input("Decision date", key=f"decision_answer_{selected}_answer_date", placeholder="YYYY-MM-DD", disabled=not editable_here, on_change=_remember, args=(selected,),
                          help="Enter the date the person made the decision, for example 2026-09-06. It is never inferred from today.")
            if editable_here:
                st.button("Decided today", key=f"decision_answer_{selected}_today",
                          on_click=_fill, args=(selected, "answer_date", date.today().isoformat()))
        st.caption(answers.NOTICE)
        save = st.button("Save this answer", key="decision_answer_save", type="primary", disabled=not editable_here or stale or unresolved or guide.get("pending_choice", False) or mapping_pending)
    if save:
        values = {field: str(st.session_state.get(f"decision_answer_{selected}_{field}", "")) for field in answers.FIELDS}
        if st.session_state.get(f"decision_answer_{selected}_answer_choice"):
            values["answer_choice"] = deepcopy(st.session_state[f"decision_answer_{selected}_answer_choice"])
        if not all(values[field].strip() for field in answers.FIELDS):
            st.warning("Enter the answer, decision maker and date before saving. Your other draft answers are retained.")
        else:
            result = answers.save(root, pack, {selected: values}, expected_digest=description["digest"], local_demo=local_demo,
                                  can_write=can_write and can_view, allowed_packs=[pack], actor_id=actor_id)
            if result.get("ok"):
                st.session_state["decision_answer_completion_errors"] = result.get("completion_errors", [])
                if result.get("completion_ok"):
                    st.session_state["decision_answer_notice"] = "Answer recorded, ledger evidence saved and ranked questions refreshed. Authenticate the decision maker during scientific review; other drafts are retained."
                else:
                    st.session_state["decision_answer_notice"] = "Answer recorded. Its evidence update still needs completion below; other drafts are retained."
                st.session_state["decision_answer_snapshot"] = {"context": context, "description": result}
                st.session_state["decision_answer_last_action"] = "saved"
                st.session_state.setdefault("flow_result", {}).pop(pack, None)
                return True
            for error in result.get("errors") or ["The answers could not be saved."]:
                st.error(str(error))
            if result.get("stale_lock"):
                st.session_state["decision_answer_stale_lock"] = True
    _stale_lock_offer(root, pack, enabled=enabled, can_write=can_write and can_view, local_demo=local_demo)
    _recorded_field_mapping(root, pack, actor_id, item, enabled=enabled, local_demo=local_demo, can_write=can_write and can_view)
    if st.button("Reload saved questions", key="decision_answer_reload", help="Discard unsaved entries and read current questions and evidence."):
        clear()
        st.rerun()
    return False
