"""Allowlisted technical-page metadata; no source rows, secrets or raw logs."""
from __future__ import annotations

from collections import Counter
import re


def text(value):
    if not isinstance(value, (str, int, float, bool)) or value is None:
        return None
    value = str(value)
    if len(value) > 600:
        return "[Complete text remains in the page; too long for chat context.]"
    if re.search(r"-----BEGIN|ssh-(?:rsa|ed25519)|private.key|password\s*[:=]|token\s*[:=]", value, re.I):
        return "[Credential-related text omitted.]"
    # Do not turn source paths, contact identities or raw URI identifiers into
    # model context. Logic text is kept whole unless a sensitive field is found.
    if re.search(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}|\b[A-Za-z]:[\\/]|\\\\|file:/{1,3}|(?:^|\s)/(?:[^\s/]+/)+|(?:products|fixtures|governance|config|handoff|runtime-logs)/", value, re.I):
        return "[Identity or source location omitted; inspect the page.]"
    return value


def local_name(value):
    if not isinstance(value, str):
        return None
    value = value.rstrip("/>").rsplit("#", 1)[-1].rsplit("/", 1)[-1].rsplit(":", 1)[-1]
    return value if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.-]{0,100}", value) else None


def problems(errors):
    """Classify a visible refusal without sending its interpolated data values."""
    result = []
    for error in list(errors or [])[:20]:
        message = str(error).lower()
        if any(word in message for word in ("changed", "stale", "refresh", "digest")):
            code = "inputs_changed: refresh and inspect current evidence before retrying"
        elif any(word in message for word in ("permission", "access", "authenticated", "administrator", "read-only")):
            code = "access_required: use an authorized account or ask the administrator"
        elif any(word in message for word in ("missing", "required", "no ", "not found", "unavailable", "install")):
            code = "prerequisite_missing: inspect the page's missing requirement"
        elif any(word in message for word in ("type", "column", "identifier", "mapping", "convert")):
            code = "mapping_or_type: review the declared name, column mapping and data type"
        elif any(word in message for word in ("confirm", "verify", "reason", "characters")):
            code = "review_required: complete the explicit review fields in this page"
        else:
            code = "action_refused: inspect the complete on-screen message before retrying"
        if code not in result:
            result.append(code)
    return result


def counts(value):
    return {str(key): amount for key, amount in (value or {}).items()
            if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_ -]{0,60}", str(key)) and type(amount) is int and 0 <= amount <= 10**12}


def knowledge(report, item=None, *, stale=False, errors=()):
    result = {"view": "Definitions and evidence", "search_ok": bool(report.get("ok")), "stale": bool(stale),
        "match_count": int(report.get("total") or 0), "selected": bool(item), "problems": problems(errors)}
    if item:
        kind = item.get("kind")
        result["item"] = {"kind": text(kind), "state": text(item.get("state")),
            "relationship_count": len(item.get("links") or []), "citation_count": len(item.get("citations") or []),
            "next_action_labels": [text(action.get("label")) for action in (item.get("actions") or [])[:6]]}
        # Decision records can contain named decision makers and private prose.
        # Their state/counts are useful, while definition/concept meaning is safe
        # only through these explicit non-identity fields.
        if kind in {"definition", "name", "clinical_concept"}:
            result["item"].update(title=text(item.get("title")), meaning=text(item.get("summary")))
    return result


def node(item):
    if not isinstance(item, dict):
        return None
    kind = str(item.get("type") or "")
    if re.search(r"Person|Agent|Reviewer|Patient|Subject|Encounter|Observation", kind, re.I):
        return {"kind": "Record details withheld because they may identify a person or source record"}
    allowed = {"label", "prefLabel", "definition", "meaning", "derivation", "dataType", "datatype", "type",
               "units", "grain", "anchor", "window", "recordSelection", "minCount", "maxCount", "minInclusive",
               "maxInclusive", "minExclusive", "maxExclusive", "path", "class", "nodeKind", "required"}
    properties = {}
    for key, value in (item.get("properties") or {}).items():
        name = local_name(key)
        if name not in allowed or len(properties) >= 12:
            continue
        if isinstance(value, dict):
            value = value.get("@value") if "@value" in value else local_name(value.get("@id"))
        if name in {"path", "class", "nodeKind", "type", "datatype", "dataType"}:
            value = local_name(value)
        clean = text(value)
        if clean is not None:
            properties[name] = clean
    return {"label": text(item.get("label")), "type": local_name(kind), "properties": properties}


def validation(value, *, stale=False):
    value = value or {}
    state = value.get("state")
    state = state if state in {"conforms", "unchecked", "not_run", "violations", "failed", "nonconforming", "invalid"} else "findings" if value else "not_run"
    result = {"state": "stale" if stale else state, "scope": "Graph structure and declared constraints; not scientific approval"}
    raw = str(value.get("report") or value.get("why") or "")
    findings = []
    for match in re.finditer(r"Constraint Violation in ([A-Za-z]+ConstraintComponent)(.*?)(?=Constraint Violation in |\Z)", raw, re.S):
        block = match.group(2)
        path = re.search(r"Result Path:\s*(\S+)", block)
        severity = re.search(r"Severity:\s*(\S+)", block)
        findings.append({"constraint": match.group(1), "property": local_name(path.group(1)) if path else None,
                         "severity": local_name(severity.group(1)) if severity else None})
        if len(findings) == 6:
            break
    result["constraint_findings"] = findings
    result["full_report_available_in_page"] = bool(raw)
    return result


def semantic(current, snapshot=None, *, source=None, selected_node=None, selected_shape=None, checked=None, stale=False, errors=()):
    result = {"view": "Semantic sources and graph", "metadata_ok": bool(current.get("ok")),
        "source_count": len(current.get("sources") or []), "binding_count": len(current.get("bindings") or []),
        "graph": "stale" if stale else "loaded" if snapshot else "not_loaded",
        "validation": validation(checked, stale=stale), "problems": problems(errors)}
    if source:
        result["selected_source"] = {key: text(source.get(key)) for key in ("label", "kind", "state", "status") if source.get(key) is not None}
    if snapshot:
        result["counts"] = {"nodes": len(snapshot.get("nodes") or []), "relationships": len(snapshot.get("edges") or []),
                            "shapes": len(snapshot.get("shape_nodes") or [])}
        result["withheld_counts"] = counts((snapshot.get("report") or {}).get("withheld"))
        if not stale:
            result["selected_record"] = node(selected_node)
            result["selected_constraint"] = node(selected_shape)
    return result


def provisioning(report, table=None, *, columns=(), target="", existing=False, can_write=False, receipt=None, errors=()):
    result = {"available": bool(report.get("ok")), "imported_table_count": len(report.get("tables") or []),
        "selected": bool(table), "can_edit_in_page": bool(can_write), "problems": problems(errors)}
    if table:
        result.update({"operation": "profile_existing" if existing else "create_and_profile_upload",
            "column_count": len(columns), "type_counts": dict(Counter(str(row.get("type")) for row in columns if row.get("type") in
                {"string", "integer", "int", "long", "double", "float", "date", "timestamp", "boolean", "decimal"})),
            "invalid_runtime_column_names": sum(not bool(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", str(row.get("name") or ""))) for row in columns),
            "duplicate_runtime_column_names": len(columns) - len({str(row.get("name") or "").casefold() for row in columns}),
            "runtime_name_entered": bool(target.strip()),
            "profile_receipt_present": bool(receipt),
            "profiled_row_count": receipt.get("rows") if receipt and type(receipt.get("rows")) is int else None,
            "next_step": "Complete and review the source adapter; an upload or profile is not an approved mapping."})
    return result


def enrollment(*, checkpoint, state, can_manage=False, reviewer_count=0, key_count=0, history_count=0, selected_status=None, action=None, errors=()):
    return {"checkpoint": checkpoint if checkpoint in {"spec", "source", "structure", "catalogue", "contract", "execution", "g1", "g2", "g3", "g4", "g5", "g6"} else "current review",
        "state": state, "can_manage_in_page": bool(can_manage), "eligible_other_reviewer_count": int(reviewer_count),
        "selected_reviewer_registered_key_count": int(key_count), "recorded_event_count": int(history_count),
        "selected_enrollment_status": selected_status if selected_status in {"enrolled", "revoked"} else "not_recorded",
        "proposed_action": action if action in {"Enroll verified reviewer", "Revoke enrollment"} else None,
        "problems": problems(errors), "boundary": "The administrator must use the existing verification form. Chat cannot choose an identity, verify a key, enroll, attest or sign."}


def job(current, *, action_label, attempts, can_write, errors=()):
    value = current or {}
    status = value.get("status")
    result = value.get("result") or {}
    if not isinstance(result, dict): result = {}
    recovery = value.get("orphan_recovery") or {}
    return {"action": text(action_label), "status": status if status in {"queued", "running", "completed", "failed", "cancelled", "interrupted"} else "unavailable",
        "attempt_count": attempts, "waiting_for_resources": value.get("resource_state") == "waiting",
        "cancel_requested": bool(value.get("cancel_requested")), "can_control_in_page": bool(can_write),
        "result_recorded": bool(result), "result_ok": result.get("ok") if type(result.get("ok")) is bool else None,
        "completed_successfully": status == "completed" and result.get("ok") is True,
        "error_count": len(result.get("errors") or []), "support_reference_available": bool(result.get("diagnostic_id")),
        "orphaned_processes_present": bool(recovery.get("present")), "owned_process_recovery_available": bool(recovery.get("can_stop")),
        "problems": problems([*errors, *([result["error"]] if result.get("error") else []), *(result.get("errors") or [])]),
        "boundary": "This journal is execution progress, not scientific approval. Inspect saved results before retrying; chat cannot replay, cancel or launch commands."}
