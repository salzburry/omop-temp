"""Pure draft transitions shared by the review widgets and their save command.

Widget identity and the version on which a draft is based are different things.
This layer owns field precedence; rendering code supplies explicit user choices.
"""
from copy import deepcopy
from dataclasses import dataclass
import hashlib
import json


@dataclass(frozen=True)
class DraftIdentity:
    pack: str
    actor_id: str
    item_id: str
    phase: str

    def key(self, generation=0):
        raw = json.dumps([self.pack, self.actor_id, self.item_id, self.phase, generation], ensure_ascii=False)
        return hashlib.sha256(raw.encode()).hexdigest()[:16]


@dataclass(frozen=True)
class EditorTransition:
    owner: str
    consume_previous: bool
    transfer_missingness: bool


def editor_transition(*, previous_owner, previous_selection, incoming_selection,
                      mapping_template, shared_mapping):
    owner = "clinical" if shared_mapping else "values"
    consume = bool(previous_owner == "values" and previous_selection is not None
        and tuple(incoming_selection) != tuple(previous_selection) and mapping_template
        and (incoming_selection[0] != previous_selection[0] or shared_mapping))
    return EditorTransition(owner, consume, previous_owner is not None and previous_owner != owner)


def compose_science(*, answers, origin, typed, clinical, shared_mapping, source_kind):
    """Produce one canonical proposed answer, without confirming or saving it."""
    result = deepcopy(answers)
    result.update(deepcopy(origin or {}))
    if typed and (typed.get("active") or shared_mapping):
        fields = deepcopy(typed.get("fields") or {})
        if result.get("source.kind", source_kind) not in {"constant", "parameter"}:
            fields.pop("source.value", None)
        result.update(fields)
    result.update(deepcopy(clinical or {}))
    return result


def rebase_kind(entry, row, basis, *, authorized_continuation=False):
    """Keep clean/unaffected drafts; require an explicit rebase of changed inputs."""
    if tuple(entry["basis"]) == tuple(basis):
        return "unchanged"
    if row is not None and (authorized_continuation or
            entry["basis"][0] == basis[0] and entry["row"] == row):
        return "rebase"
    return "conflict" if entry["dirty"] else "reset"
