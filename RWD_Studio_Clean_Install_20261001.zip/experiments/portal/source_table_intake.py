"""Local TSV intake and shared names-only inventory; no source approval or execution.

Exact uploads remain in the existing private source-workspace store. Only table
and column metadata enters the product. The inventory offers mapping choices;
it never changes configured source aliases or grants adapter/runtime authority.
"""
from __future__ import annotations

import csv
from datetime import date, datetime, timezone
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import tempfile

import yaml

from experiments.portal import source_workspace as workspace
from experiments.portal import scientific_definitions as definitions

INVENTORY = "config/source_table_inventory.json"
MAX_BYTES = 8 * 1024 * 1024
MAX_ROWS = 100000
MAX_COLUMNS = 256
MAX_TABLES = 64
MAX_INVENTORY_BYTES = 1024 * 1024
TYPE_SAMPLE_ROWS = 1000
TABLE_NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*")
COLUMN_IDENTIFIER = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
HASH = re.compile(r"[a-f0-9]{64}")
NOTICE = "TSV files stay in local application storage. Imported columns are choices for review; source mappings still need review before execution."
INPUT_ERRORS = (ValueError, OSError, TypeError, KeyError, AttributeError, RecursionError,
                yaml.YAMLError, definitions.dw._DraftError)


def _hash(raw):
    return hashlib.sha256(raw).hexdigest()


def _failure(error):
    return {"ok": False, "changed": False, "errors": [str(error)], "notice": NOTICE}


def _text_name(value, label, *, table=False):
    if not isinstance(value, str) or not value or value != value.strip() or len(value) > 128 or any(ord(c) < 32 or ord(c) == 127 for c in value):
        raise ValueError(f"{label} must be nonblank text of at most 128 characters, without surrounding spaces or control characters.")
    if table and not TABLE_NAME.fullmatch(value):
        raise ValueError("Use a table name containing letters, digits and underscores, optionally prefixed by its schema, for example clinical.ecog_results.")
    return value


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("The source-table inventory repeats a field. Restore its last valid copy before importing.")
        result[key] = value
    return result


def decode_inventory(raw):
    if raw is None:
        return {"version": 1, "tables": []}
    if len(raw) > MAX_INVENTORY_BYTES:
        raise ValueError("The source-table inventory exceeds its 1 MB limit.")
    data = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique)
    if not isinstance(data, dict) or set(data) != {"version", "tables"} or type(data["version"]) is not int or data["version"] != 1 or not isinstance(data["tables"], list) or len(data["tables"]) > MAX_TABLES:
        raise ValueError("The source-table inventory needs version 1 and at most 64 tables.")
    names = set()
    required = {"physical_table", "columns", "sha256", "filename", "bytes", "row_count", "format", "role_hint", "imported_by", "imported_at", "storage", "approval"}
    for table in data["tables"]:
        if not isinstance(table, dict) or set(table) != required:
            raise ValueError("A source-table inventory entry has unsupported fields.")
        name = _text_name(table["physical_table"], "Table name", table=True)
        if name.casefold() in names:
            raise ValueError("The source-table inventory repeats a table name.")
        names.add(name.casefold())
        if table["approval"] != "pending" or table["storage"] != "private_source_workspace" or not HASH.fullmatch(str(table["sha256"])):
            raise ValueError("Imported source tables must keep their exact upload identity and pending review status.")
        if table["format"] not in {"data", "catalog"} or type(table["bytes"]) is not int or not 0 < table["bytes"] <= MAX_BYTES or type(table["row_count"]) is not int or not 0 <= table["row_count"] <= MAX_ROWS:
            raise ValueError("An imported source table has invalid format or size metadata.")
        for key in ("filename", "role_hint", "imported_by", "imported_at"):
            if not isinstance(table[key], str) or len(table[key]) > 255 or any(ord(c) < 32 for c in table[key]):
                raise ValueError("An imported source table has invalid identity metadata.")
        columns = table["columns"]
        if not isinstance(columns, list) or not 0 < len(columns) <= MAX_COLUMNS:
            raise ValueError("Each imported table needs 1–256 columns.")
        used = set()
        for column in columns:
            if not isinstance(column, dict) or set(column) != {"name", "type", "type_basis"}:
                raise ValueError("An imported column has unsupported metadata.")
            name = _text_name(column["name"], "Column name")
            if name.casefold() in used:
                raise ValueError("An imported table repeats a column name.")
            used.add(name.casefold())
            if column["type"] not in {"", "string", "integer", "long", "double", "boolean", "date", "timestamp"} or column["type_basis"] not in {"sample", "uploaded_catalog", "unstated"}:
                raise ValueError("An imported column has unsupported type metadata.")
    return data


def _scope(root, pack, actor_id, allowed_packs):
    scope = workspace._scope(root, pack, actor_id, allowed_packs)
    product = scope[1]
    path = definitions._safe(product / INVENTORY)
    raw = definitions._read(path) if path.exists() else None
    inventory = decode_inventory(raw)
    config = definitions._read(definitions._safe(product / "config/data_product.yaml"))
    digest = _hash((raw or b"") + b"\0" + config)
    return scope, path, inventory, digest


def describe(root, pack, actor_id, *, allowed_packs=None):
    try:
        scope, _path, inventory, digest = _scope(root, pack, actor_id, allowed_packs)
        from engine.config import load_config
        cfg = load_config(scope[1] / "config/data_product.yaml")
        return {"ok": True, "tables": inventory["tables"], "digest": digest, "logical_roles": sorted(cfg.sources),
                "errors": [], "notice": NOTICE, "approval_created": False}
    except INPUT_ERRORS as error:
        return _failure(error)


def _observed_type(values):
    values = [value for value in values if value != ""]
    if not values:
        return ""
    if all(value.casefold() in {"true", "false"} for value in values):
        return "boolean"
    if all(re.fullmatch(r"-?(?:0|[1-9][0-9]*)", value) for value in values):
        numbers = [int(value) for value in values]
        if all(-(2**31) <= value < 2**31 for value in numbers):
            return "integer"
        return "long" if all(-(2**63) <= value < 2**63 for value in numbers) else "string"
    try:
        if all(re.fullmatch(r"-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?", value) and math.isfinite(float(value)) for value in values):
            return "double"
    except (ValueError, OverflowError):
        pass
    try:
        if all(re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", value) and date.fromisoformat(value) for value in values):
            return "date"
    except ValueError:
        pass
    return "string"


def _parse(upload_name, raw, mode):
    if not isinstance(upload_name, str) or len(upload_name) > 255 or any(c in upload_name for c in '/\\:\x00\n\r') or not upload_name.lower().endswith(".tsv"):
        raise ValueError("Choose a .tsv file with a filename, not a folder path.")
    if not isinstance(raw, bytes) or not 0 < len(raw) <= MAX_BYTES:
        raise ValueError("Choose a nonempty TSV file of at most 8 MB.")
    if mode not in {"data", "catalog"}:
        raise ValueError("Choose a source table or a table/column list.")
    try:
        text = raw.decode("utf-8-sig")
        if "\x00" in text:
            raise ValueError("Use a UTF-8 TSV file without binary content.")
        reader = csv.reader(io.StringIO(text, newline=""), delimiter="\t", strict=True)
        header = next(reader)
        if not 1 <= len(header) <= MAX_COLUMNS:
            raise ValueError("Use a TSV table with 1–256 header columns.")
        used = set()
        for name in header:
            _text_name(name, "Column header")
            if name.casefold() in used:
                raise ValueError("Two header columns have the same name. Give each header a unique name and upload again.")
            used.add(name.casefold())
        rows, count = [], 0
        for row in reader:
            if not row or all(cell == "" for cell in row):
                continue
            count += 1
            if count > MAX_ROWS:
                raise ValueError("This preview supports at most 100,000 rows. Import a header or metadata extract for larger sources.")
            if len(row) != len(header):
                raise ValueError(f"TSV row {reader.line_num} has {len(row)} cells; its header has {len(header)}. Correct the separators and upload again.")
            if mode == "catalog" or len(rows) < TYPE_SAMPLE_ROWS:
                rows.append(row)
    except (UnicodeError, csv.Error, StopIteration) as error:
        raise ValueError("The TSV could not be read. Use UTF-8 text, tab separators and one header row.") from error
    if mode == "data":
        columns = [{"name": name, "type": _observed_type([row[i] for row in rows]),
                    "type_basis": "sample" if rows else "unstated"} for i, name in enumerate(header)]
        return {"tables": [{"physical_table": "", "columns": columns}], "row_count": count,
                "sample_rows": len(rows), "sha256": _hash(raw), "bytes": len(raw), "filename": upload_name, "format": mode}
    positions = {name.casefold(): i for i, name in enumerate(header)}
    def field(names, required=True):
        matches = [positions[name] for name in names if name in positions]
        if len(matches) != 1 and (required or matches):
            raise ValueError("A table/column list needs one Table (or table_name), one Column (or column_name), and an optional Type (or data_type) header.")
        return matches[0] if matches else None
    table_pos, column_pos, type_pos = field(["table", "table_name"]), field(["column", "column_name"]), field(["type", "data_type"], False)
    tables, names = {}, {}
    from experiments.portal.variable_review_consistency import canonical_type
    for row in rows:
        table = _text_name(row[table_pos], "Table name", table=True)
        column = _text_name(row[column_pos], "Column name")
        folded = table.casefold()
        if folded in names and names[folded] != table:
            raise ValueError("Use consistent capitalization for each table name in the column list.")
        names[folded] = table
        columns = tables.setdefault(table, [])
        if any(item["name"].casefold() == column.casefold() for item in columns):
            raise ValueError(f"Table {table} repeats column {column}. Keep one entry per column.")
        stated_type = row[type_pos].strip() if type_pos is not None else ""
        dtype = canonical_type({"number": "double", "numeric": "double"}.get(stated_type.casefold(), stated_type)) if stated_type else ""
        if type_pos is not None and row[type_pos] and not dtype:
            raise ValueError(f"Column {column} has an unsupported type. Use text, integer, number, boolean, date or timestamp.")
        columns.append({"name": column, "type": dtype or "", "type_basis": "uploaded_catalog" if dtype else "unstated"})
        if len(tables) > MAX_TABLES or len(columns) > MAX_COLUMNS:
            raise ValueError("A column list supports at most 64 tables with 256 columns each.")
    if not tables:
        raise ValueError("The table/column list has no column rows.")
    return {"tables": [{"physical_table": name, "columns": columns} for name, columns in tables.items()],
            "row_count": count, "sample_rows": 0, "sha256": _hash(raw), "bytes": len(raw), "filename": upload_name, "format": mode}


def preview(root, pack, actor_id, upload_name, upload_bytes, *, mode="data", allowed_packs=None):
    try:
        _scope(root, pack, actor_id, allowed_packs)
        return {"ok": True, **_parse(upload_name, upload_bytes, mode), "errors": [], "notice": NOTICE}
    except INPUT_ERRORS as error:
        return _failure(error)


def _publish_private(folder, raw, digest):
    directory = workspace._safe(folder / "table_uploads")
    directory.mkdir(parents=True, exist_ok=True)
    target = workspace._safe(directory / (digest + ".tsv"))
    if target.exists():
        if _hash(workspace._bytes(target)) != digest:
            raise ValueError("The saved local TSV changed. Restore the original local file before importing again.")
        return target
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="wb", dir=directory, prefix=".tsv-", suffix=".tmp", delete=False) as handle:
            temporary = Path(handle.name)
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        workspace._safe(temporary)
        try:
            os.link(temporary, target)
        except FileExistsError:
            if _hash(workspace._bytes(target)) != digest:
                raise ValueError("A different local file occupies this upload identity. No source metadata was changed.")
        return target
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def import_table(root, pack, actor_id, upload_name, upload_bytes, *, expected_digest, expected_upload_digest,
                 physical_table="", role_hint="", mode="data", local_demo=False, can_write=False, allowed_packs=None):
    try:
        workspace._authorized(local_demo, can_write)
        scope, path, inventory, digest = _scope(root, pack, actor_id, allowed_packs)
        if expected_digest != digest:
            raise ValueError("Source choices changed. Reload the source-table section and review the import again.")
        parsed = _parse(upload_name, upload_bytes, mode)
        if parsed["sha256"] != expected_upload_digest:
            raise ValueError("The upload changed after preview. Preview the selected TSV again before importing.")
        if mode == "data":
            parsed["tables"][0]["physical_table"] = _text_name(physical_table, "Table name", table=True)
        known = describe(root, pack, actor_id, allowed_packs=allowed_packs)
        if not known["ok"]:
            raise ValueError(" ".join(known["errors"]))
        if role_hint and role_hint not in known["logical_roles"]:
            raise ValueError("Choose an existing source role or leave it undecided; importing a TSV does not create an engine role.")
        from experiments.portal.variable_review_workflow import _locked
        with _locked(path):
            current_scope, current_path, inventory, current_digest = _scope(root, pack, actor_id, allowed_packs)
            if current_digest != digest:
                raise ValueError("Another person changed source choices. Reload before importing.")
            by_name = {table["physical_table"].casefold(): table for table in inventory["tables"]}
            additions = []
            for table in parsed["tables"]:
                previous = by_name.get(table["physical_table"].casefold())
                if previous:
                    if previous["sha256"] == parsed["sha256"] and previous["columns"] == table["columns"]:
                        continue
                    raise ValueError(f"Table {table['physical_table']} already has an import. Enter a different table name to keep its existing columns and mappings.")
                additions.append({**table, "sha256": parsed["sha256"], "filename": upload_name, "bytes": len(upload_bytes),
                    "row_count": parsed["row_count"], "format": mode, "role_hint": role_hint,
                    "imported_by": actor_id, "imported_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                    "storage": "private_source_workspace", "approval": "pending"})
            if not additions:
                return {"ok": True, "changed": False, "errors": [], "tables": inventory["tables"], "notice": "This exact TSV and its columns are already imported."}
            updated = {"version": 1, "tables": inventory["tables"] + additions}
            raw = json.dumps(updated, indent=2, ensure_ascii=False, allow_nan=False).encode("utf-8")
            decode_inventory(raw)
            _publish_private(current_scope[4], upload_bytes, parsed["sha256"])
            def current():
                if _scope(root, pack, actor_id, allowed_packs)[3] != current_digest:
                    raise ValueError("Source choices changed during the import. Reload before trying again.")
            definitions._atomic(current_path, raw, check=current)
        return {"ok": True, "changed": True, "errors": [], "tables": updated["tables"], "imported_tables": len(additions),
                "notice": NOTICE, "approval_created": False, "runtime_source_created": False}
    except INPUT_ERRORS as error:
        return _failure(error)
