"""Turn explicit reviewed choices into the existing configuration proposal flow.

The compiler prepares supported settings and native output bindings. Explicit
application validates and writes the contract and configuration together. It
never interprets arbitrary scientific prose, installs code or grants approval.
The proposal retains its shared-review binding.
"""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import os
import tempfile

import yaml

from experiments.portal import configuration_proposals as proposals
from experiments.portal import variable_review_workflow as workflow
from engine.config import load_config


def _fail(error):
    return {"ok": False, "changed": False, "errors": [str(error)], "approved": False,
            "released": False, "implementation_created": False}


def _prepare(root, pack, actor_id, allowed_packs, *, pending_only=False):
    from experiments.portal import variable_execution_rules
    report, _state, _path, product = workflow._describe(root, pack, actor_id, allowed_packs)
    description = proposals.dw.describe(root, pack)
    if description["errors"]:
        raise ValueError(" ".join(description["errors"]))
    parameters = proposals.supported_parameters(root, pack)
    from experiments.portal import variable_execution_config
    cfg = variable_execution_config.load(product)
    if pending_only:
        pending = pending_application(root, pack, actor_id, allowed_packs=allowed_packs)['pending']
        report = {**report, 'rows': [r for r in report['rows'] if r['variable_id'] in pending]}
    plan = variable_execution_rules.build(report, cfg, parameters)
    files, unsupported = proposals._compose(product, plan["configuration_changes"]) if plan["configuration_changes"] else ([], [])
    for item in unsupported:
        plan["blockers"].append({"item_id": "", "variable_id": "", "message": item["reason"]})
    review_confirmed = report["current_phase"] == "complete"
    result = {**plan, "ok": True, "errors": [], "input_digest": report["input_digest"],
              "state_digest": report["state_digest"], "baseline_sha256": description["baseline_sha256"],
              "settings": [{"ref": change["ref"], "label": parameters[change["ref"]][0],
                            "current": parameters[change["ref"]][2], "proposed": change["value"]}
                           for change in plan["configuration_changes"] if change["ref"] in parameters],
              "files": files, "review_confirmed": review_confirmed,
              "can_stage": review_confirmed and bool(files or plan["blockers"]) and not unsupported,
              "draft_only": True, "approved": False, "released": False, "implementation_created": False}
    result["plan_digest"] = workflow.definitions._hash(result)
    # Refuse to display a combination of configuration and review versions.
    if workflow._input_digest(Path(root).resolve(), product) != report["input_digest"]:
        raise ValueError("The reviewed definitions or configuration changed while preparing these settings. Reload the preview.")
    return result, report, description


def describe(root, pack, actor_id, *, allowed_packs=None):
    try:
        return _prepare(root, pack, actor_id, allowed_packs)[0]
    except (ValueError, TypeError, KeyError, AttributeError, OSError, RecursionError, yaml.YAMLError) as error:
        return _fail(error)


def pending_application(root, pack, actor_id, *, allowed_packs=None):
    """A build cannot silently discard saved review edits. No gates run here."""
    from experiments.portal import scientific_definitions as science
    from rwd_tools import reviewed_variable_record as records
    product, _name, _owner, _folder = science._scope(root, pack, actor_id, allowed_packs)
    if not (product / workflow.STORE).exists():
        return {'ok': True, 'pending': [], 'digest': science._hash(None)}
    report, state, _path, product = workflow._describe(root, pack, actor_id, allowed_packs)
    text = science._read(product / 'handoff/FUNCTIONAL_CONTRACT.md').decode('utf-8')
    blocks = {science.cl._scalar(b, 'variable_id'): b for b in science.cl.records(text)}
    pending = []
    for row in report['rows']:
        if row['item_id'] not in state['rows']:
            continue
        block = blocks.get(row['variable_id'])
        values = {key: science.cl._scalar(block, key) or '' for key in science.FIELDS} if block else {}
        equal = records.same_values(row['values'], values)
        canonical = records.load(product, values.get('notes', ''), values=values, item_id=row['item_id']) if block else None
        if row.get('clinical_rule') or row.get('family'):
            equal = equal and bool(canonical) and canonical['clinical_rule'] == (row.get('clinical_rule') or {}) and canonical['family'] == (row.get('family') or {})
        if not equal:
            pending.append(row['variable_id'])
    return {'ok': True, 'pending': pending, 'digest': science._hash([report['input_digest'], report['state_digest']])}


def preview_application(root, pack, actor_id, *, allowed_packs=None):
    """Compose the reviewed contract and executable files on the same shadow.

    No model interpretation, approvals or status promotion occurs here. All
    scientific/source/output tables must have been explicitly confirmed.
    """
    from rwd_tools import contract_record, reviewed_variable_record
    from experiments.portal import scientific_definitions as science
    try:
        plan, report, _description = _prepare(root, pack, actor_id, allowed_packs, pending_only=True)
        product = Path(root).resolve() / pack
        errors = [b['message'] for b in plan['blockers']]
        if not plan['review_confirmed']:
            errors.insert(0, 'Confirm the definition, source and output reviews before preparing build changes.')
        if errors:
            return {**plan, 'can_apply': False, 'errors': errors, 'files': []}
        before = science._read(product / 'handoff/FUNCTIONAL_CONTRACT.md').decode('utf-8')
        blocks = list(science.cl.records(before))
        shape = science.cl.table_shape_errors(before)
        if shape or any(science.cl._fenced_blocks(before)):
            raise ValueError('The existing contract needs repair before applying reviewed changes. ' + ' '.join(shape))
        ids = [science.cl._scalar(b, 'variable_id') for b in blocks]
        if any(not name for name in ids) or len(set(name.casefold() for name in ids)) != len(ids):
            raise ValueError('Resolve duplicate contract variables before applying changes.')
        decision_path = product / 'handoff/DECISIONS.md'
        decisions = science.cl.decision_status(science._read(decision_path).decode('utf-8')) if decision_path.exists() else {}
        records, envelopes = [], []
        for row in report['rows']:
            values = science._values(row['values'])
            rec, problems = contract_record.merge_evidence(values, str(product), row['item_id'], reader='human')
            if problems:
                raise ValueError(' '.join(problems))
            old = next((b for b in blocks if science.cl._scalar(b, 'variable_id') == values['variable_id']), None)
            if old and science.cl._list(old, 'spec_refs') != [row['item_id']]:
                raise ValueError(values['variable_id'] + ': reconcile its source citations before replacing this record.')
            envelope = reviewed_variable_record.from_review(row, pack=pack)
            rec['notes'] = reviewed_variable_record.attach(rec.get('notes') or '', envelope)
            status = contract_record._status_map({'status': science.cl._scalar(old, 'status')}) if old else None
            rec, problems = contract_record.apply_status(rec, status, dec_open=decisions,
                reopen=bool(contract_record.requirement_changes(rec, old)))
            if problems:
                raise ValueError(' '.join(problems))
            # As in the workbook compiler, this prospective implementation claim
            # is admitted only after all native and complete binding checks pass.
            status = contract_record._status_map(rec)
            status['implementation'] = 'implemented' if any(ref != 'none' for ref in rec.get('implementation_refs') or []) else 'not_implemented'
            rec['status'] = status
            records.append(rec)
            envelopes.append(envelope)
        after = contract_record.upsert(before, records)
        files = [proposals._workbook_file(f['path'], f['before'], f['after']) for f in plan['files']]
        if after != before:
            files.append(proposals._workbook_file('handoff/FUNCTIONAL_CONTRACT.md', before, after))
        with tempfile.TemporaryDirectory(prefix='reviewed-build-') as temporary:
            staged_root = Path(temporary).resolve()
            staged = proposals._candidate(Path(root).resolve(), product, {'pack': pack, 'files': files}, staged_root)
            for record in envelopes:
                science._publish_reviewed_rule(staged, record)
            checks = proposals._run_validators(staged_root, staged)
            from rwd_tools import contract_binding
            complete_errors, complete_detail = contract_binding.check(str(staged), contract_binding.pack_yaml(str(staged)), require_complete=True)
            checks.append({'validator': 'Complete specification binding', 'completed': True, 'passed': not complete_errors,
                           'errors': complete_errors, 'detail': complete_detail})
        errors = [str(e) for c in checks if not c.get('passed') for e in (c.get('errors') or [c['validator'] + ' did not pass'])]
        result = {**plan, 'files': files, 'checks': checks, 'errors': errors, 'can_apply': not errors,
                  'rules': envelopes, 'approved': False, 'released': False}
        result['application_digest'] = science._hash(result)
        if workflow._input_digest(Path(root).resolve(), product) != plan['input_digest']:
            raise ValueError('The product changed during validation. Preview the current changes again.')
        return result
    except (ValueError, TypeError, KeyError, AttributeError, OSError, yaml.YAMLError) as error:
        return _fail(error)


def apply_application(root, pack, actor_id, *, expected_digest, confirmed=False,
                      local_demo=False, can_write=False, allowed_packs=None):
    from experiments.portal import scientific_definitions as science, delivery_binding
    descriptor, lock = None, None
    try:
        if not (confirmed is True and local_demo is True and can_write is True):
            raise ValueError('Review the proposed changes and confirm applying them.')
        product, _name, _owner, _folder = science._scope(root, pack, actor_id, allowed_packs)
        lock = science._contract_lock(product)
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with workflow._locked(product / workflow.STORE):
            fresh = preview_application(root, pack, actor_id, allowed_packs=allowed_packs)
            if not fresh.get('ok') or not fresh.get('can_apply'):
                return fresh
            if not expected_digest or fresh['application_digest'] != expected_digest:
                raise ValueError('The reviews or proposed files changed. Preview the current changes again.')
            # Immutable rule content is published first; only the atomic contract
            # reference makes it authoritative. Failed writes leave no approval.
            for record in fresh['rules']:
                science._publish_reviewed_rule(product, record)
            delivery_binding._replace_files(product, fresh['files'])
        return {'ok': True, 'changed': bool(fresh['files']), 'approved': False, 'released': False,
                'files': [f['path'] for f in fresh['files']], 'message': 'Reviewed definitions and build configuration saved together.'}
    except FileExistsError:
        return _fail('Another contract edit is running. Wait for it to finish, then preview again.')
    except (ValueError, TypeError, KeyError, AttributeError, OSError, yaml.YAMLError) as error:
        return _fail(error)
    finally:
        if descriptor is not None:
            os.close(descriptor)
            lock.unlink(missing_ok=True)


def _fresh(plan, expected_input_digest, expected_state_digest, expected_plan_digest):
    if any(not expected or plan.get(name) != expected for name, expected in (
            ("input_digest", expected_input_digest), ("state_digest", expected_state_digest),
            ("plan_digest", expected_plan_digest))):
        raise ValueError("The reviewed definitions or proposed settings changed. Reload and review the current preview.")


def stage(root, pack, actor_id, *, expected_input_digest, expected_state_digest, expected_plan_digest,
          confirmed=False, local_demo=False, can_write=False, allowed_packs=None):
    if not (confirmed is True and local_demo is True and can_write is True):
        return _fail("Preparing execution settings requires an authorized editor and the displayed preview choice.")
    try:
        plan, report, description = _prepare(root, pack, actor_id, allowed_packs)
        _fresh(plan, expected_input_digest, expected_state_digest, expected_plan_digest)
        if not plan["review_confirmed"]:
            raise ValueError("Confirm the scientific, source and output tables before staging their execution settings.")
        if not plan["can_stage"]:
            raise ValueError("There are no configuration changes or implementation items to stage. Continue with the existing configuration checks.")
        pending = sum(row["status"] != "supported" for row in plan["rows"])
        purpose = "Apply supported settings from the reviewed variable table."
        if pending:
            purpose += f" {pending} variable(s) still require output binding or implementation review."
        brief = proposals.dw.build_plan(description,
            retained=[row["variable_id"] for row in description["rows"]], additions=[], purpose=purpose,
            studies=[], target_source=description["source"]["vendor"], target_modality=description["source"]["modality"])
        result = proposals.stage(root, pack, brief, configuration_changes=deepcopy(plan["configuration_changes"]),
            study_exclusions=[], actor_id=actor_id, local_demo=True, can_write=True,
            expected_baseline=description["baseline_sha256"], allowed_packs=allowed_packs,
            variable_review_binding={"input_digest": report["input_digest"], "state_digest": report["state_digest"]})
        return {**result, "implementation_created": False, "approved": False, "released": False}
    except (ValueError, TypeError, KeyError, AttributeError, OSError, RecursionError, yaml.YAMLError) as error:
        return _fail(error)


def use_engine_output(root, pack, actor_id, item_id, *, expected_input_digest, expected_state_digest,
                      expected_plan_digest, confirmed=False, local_demo=False, can_write=False, allowed_packs=None):
    if not (confirmed is True and local_demo is True and can_write is True):
        return _fail("Choosing the engine output requires an authorized editor and the displayed binding choice.")
    try:
        plan, _report, _description = _prepare(root, pack, actor_id, allowed_packs)
        _fresh(plan, expected_input_digest, expected_state_digest, expected_plan_digest)
        row = next((row for row in plan["rows"] if row["item_id"] == item_id), None)
        if not row or row["status"] != "needs_output_binding" or not row["output_updates"]:
            raise ValueError("Choose a variable with an explicit native engine output suggestion.")
        return workflow.save_row(root, pack, actor_id, item_id, "output", deepcopy(row["output_updates"]),
            expected_input_digest=plan["input_digest"], expected_state_digest=plan["state_digest"],
            allowed_packs=allowed_packs, local_demo=True, can_write=True)
    except (ValueError, TypeError, KeyError, AttributeError, OSError, RecursionError, yaml.YAMLError) as error:
        return _fail(error)
