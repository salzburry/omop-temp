"""Import local TSV columns before the variable review screen."""
from __future__ import annotations

import hashlib
from pathlib import Path
import re

import streamlit as st

from experiments.portal import source_table_intake as backend
from experiments.portal.variable_review_controls import TYPE_LABELS

PREFIX = "source_table_intake_"


def clear():
    for key in list(st.session_state):
        if str(key).startswith(PREFIX):
            st.session_state.pop(key, None)


def _default_name(filename):
    stem = re.sub(r"[^A-Za-z0-9_]", "_", Path(filename).stem).strip("_")[:100] or "source_table"
    return stem if re.match(r"[A-Za-z_]", stem) else "table_" + stem


def render(root, pack, actor_id, *, local_demo=False, can_write=False, can_view=True, allowed_packs=None):
    """Return True only when an import changed the shared column inventory."""
    owner = (str(Path(root).resolve()), pack, actor_id, tuple(sorted(allowed_packs or [])))
    if not can_view:
        clear()
        return False
    if st.session_state.get(PREFIX + "owner") != owner:
        clear()
        st.session_state[PREFIX + "owner"] = owner
    permitted = local_demo is True and can_write is True
    current = backend.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    with st.expander("Source tables", expanded=current.get("ok", False) and not bool(current.get("tables"))):
        st.caption("Import your TSV first. Its table and column names will be available in the variable editors below.")
        if not permitted:
            st.caption("A product editor can import a TSV in an editable local workspace. You can review any saved columns and build results below.")
        if st.session_state.get(PREFIX + "saved"):
            st.success(st.session_state.pop(PREFIX + "saved"))
        if not current.get("ok"):
            for error in current.get("errors") or ["Source-table choices could not be read."]:
                st.info(str(error))
            return False
        if current["tables"]:
            st.dataframe([{"Table": item["physical_table"], "Columns": len(item["columns"]),
                           "Imported file": item["filename"], "Source mapping": "Needs review"}
                          for item in current["tables"]], hide_index=True, width="stretch")
        from experiments.portal import source_provisioning_page
        source_provisioning_page.render(root, pack, actor_id, allowed_packs=allowed_packs, can_write=permitted)
        modes = {"data": "Source table: the first row contains column names",
                 "catalog": "Column list: Table, Column and optional Type columns"}
        mode = st.selectbox("What is in the TSV?", list(modes), format_func=modes.get,
                            key=PREFIX + "mode", disabled=not permitted)
        uploaded = st.file_uploader("Import a source TSV", type=["tsv"], accept_multiple_files=False,
                                    key=PREFIX + "upload", disabled=not permitted, max_upload_size=8)
        st.caption("Up to 8 MB and 100,000 rows. For a larger source, upload its header row or a table/column list.")
        st.caption("The file is saved locally outside the product folder. Only column metadata is added to the product; creating a runtime source table and reviewing its mapping are separate steps.")
        if uploaded is None:
            return False
        raw = uploaded.getvalue()
        identity = (hashlib.sha256(raw).hexdigest(), mode, current["digest"])
        if st.session_state.get(PREFIX + "preview_identity") != identity:
            checked = backend.preview(root, pack, actor_id, uploaded.name, raw, mode=mode, allowed_packs=allowed_packs)
            st.session_state[PREFIX + "preview"] = checked
            st.session_state[PREFIX + "preview_identity"] = identity
        preview = st.session_state[PREFIX + "preview"]
        if not preview.get("ok"):
            for error in preview.get("errors") or ["This TSV could not be read."]:
                st.error(str(error))
            return False
        token = preview["sha256"][:16] + mode
        if mode == "data":
            table_name = st.text_input("Table name", value=_default_name(uploaded.name), key=PREFIX + "name_" + token,
                                       disabled=not permitted, help="Use the name of the source table, for example ecog_results or clinical.ecog_results.")
            selected = preview["tables"][0]
            st.caption(f"{preview['row_count']} data rows · {len(selected['columns'])} columns. Type suggestions use up to {backend.TYPE_SAMPLE_ROWS:,} rows; confirm them during review.")
        else:
            table_name = ""
            choices = {item["physical_table"]: item for item in preview["tables"]}
            chosen = st.selectbox("Preview table", list(choices), key=PREFIX + "catalog_table_" + token)
            selected = choices[chosen]
            st.caption(f"{len(choices)} table(s) found in the column list. Uploaded type declarations remain unreviewed.")
        st.dataframe([{"Column": column["name"], "Suggested type": TYPE_LABELS.get(column["type"], column["type"] or "Not stated")}
                      for column in selected["columns"]], hide_index=True, width="stretch")
        if any(not backend.COLUMN_IDENTIFIER.fullmatch(column["name"]) for column in selected["columns"]):
            st.info("Some headers contain spaces or punctuation. They are kept exactly as uploaded. Map those headers to supported column identifiers in Sources before saving an executable mapping.")
        label = "Import table and columns" if mode == "data" else "Import tables and columns"
        if st.button(label, key=PREFIX + "import", disabled=not permitted):
            result = backend.import_table(root, pack, actor_id, uploaded.name, raw,
                expected_digest=current["digest"], expected_upload_digest=preview["sha256"], physical_table=table_name,
                mode=mode, local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
            if result.get("ok"):
                message = "TSV saved locally. Its columns are now available below; review their source mapping before execution."
                if result.get("changed"):
                    st.session_state[PREFIX + "saved"] = message
                    return True
                st.info(result.get("notice") or message)
            else:
                for error in result.get("errors") or ["The TSV could not be imported."]:
                    st.error(str(error))
        return False
