"""Preserve a scientist's form across Streamlit widget cleanup without sharing it with another actor."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
from datetime import date, datetime, timezone
from copy import deepcopy

from experiments.portal import design_workspace as dw
from experiments.portal import new_product_form_defaults as setup_defaults


BROWSER_SECTIONS = {"Home", "Flow", "Status", "Open questions", "Search & definitions", "Plan changes",
    "Studies", "New product", "Waiting on a person", "Run gates", "Walkthrough", "Evidence packets", "Agent", "Eval corpus"}
MAX_CONTINUATION_BYTES = 2_000_000


def demo_profile_token(user):
    """Opaque bookmark for a selectable demo label, never an authentication token."""
    return dw._hash([user.get("name", ""), user.get("email", "")])[:24]


def restore_demo_profile(state, users, query):
    if "who" not in state:
        token = query.get("profile")
        selected = next((user for user in users if token == demo_profile_token(user)), None)
        if selected:
            state["who"] = selected["name"]


def remember_demo_profile(users, chosen, query):
    selected = next((user for user in users if user.get("name") == chosen), None)
    if selected:
        token = demo_profile_token(selected)
        if query.get("profile") != token:
            query["profile"] = token


def _browser_encode(value):
    if isinstance(value, datetime):
        return {"__rwd_browser_type__": "datetime", "value": value.isoformat()}
    if isinstance(value, date):
        return {"__rwd_browser_type__": "date", "value": value.isoformat()}
    if isinstance(value, dict):
        return {key: _browser_encode(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_browser_encode(item) for item in value]
    return value


def _browser_decode(value):
    if isinstance(value, dict):
        if set(value) == {"__rwd_browser_type__", "value"}:
            if value["__rwd_browser_type__"] == "date":
                return date.fromisoformat(value["value"])
            if value["__rwd_browser_type__"] == "datetime":
                return datetime.fromisoformat(value["value"])
        return {key: _browser_decode(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_browser_decode(item) for item in value]
    return value


def _browser_fields(fields):
    if not isinstance(fields, dict):
        return {}
    actions = {"save", "save_next", "custom", "family", "search", "save_identifier", "apply_source",
        "lineage_usage", "lineage_refresh_master", "lineage_history_load", "clinical_ecog_compact_edit"}
    return {key: value for key, value in fields.items() if isinstance(key, str)
        and not key.startswith(("logic_review", "typed_confirm", "clinical_ecog_compact_use_"))
        and key not in actions
        and not key.endswith(("_remove", "_mapping_add", "_source_add", "_apply_type", "typed_suggest", "typed_discard", "_table_widget"))}


def _continuation_path(root, actor, allowed_packs):
    from experiments.portal import authoring_session
    from experiments.portal.installation_storage import logical_path
    current = authoring_session.CURRENT.get()
    if current is not None:
        if (logical_path(root) != logical_path(current.root) or actor != current.actor
                or not set(allowed_packs) <= set(current.packs) or "view" not in current.permissions):
            raise ValueError("The unfinished workspace is outside this profile's current access.")
    scope, directory = _setup_scope(root, actor, allowed_packs)
    path = directory / "continuation" / dw._hash(scope["access"])[:16] / "latest.json"
    dw._check_storage_paths([path])
    return scope, path


def _continuation_value(state, actor, allowed_packs):
    """Only navigation and draft data; never a button, approval, job or authority."""
    from experiments.portal import connected_workflow as navigation
    pack = state.get("pack") if state.get("pack") in allowed_packs else ""
    section = state.get("section", "Home")
    section = section if section in BROWSER_SECTIONS else "Home"
    routes = {}
    for name, context in (state.get("connected_route_history") or {}).items():
        if name in BROWSER_SECTIONS and navigation.valid(context, pack=pack, actor_id=actor,
                section=name, allowed_packs=allowed_packs):
            routes[name] = deepcopy(context)
    active = state.get("connected_workflow")
    if isinstance(active, dict) and active.get("origin") in BROWSER_SECTIONS and navigation.valid(active,
            pack=pack, actor_id=actor, section=active["origin"], allowed_packs=allowed_packs):
        routes[active["origin"]] = deepcopy(active)
    if navigation.valid(active, pack=pack, actor_id=actor, section=section, allowed_packs=allowed_packs):
        routes[section] = deepcopy(active)
    # Cohort drafts already include the editor identity and input revision in
    # their key. Restoring them cannot make a stale baseline current.
    cohort = {key: deepcopy(value) for key, value in state.items()
        if pack and re.fullmatch(r"design_" + re.escape(pack) + r"_proposal_cohort_[a-f0-9]+_[a-f0-9]+_(draft|enabled|selected)", str(key))}
    variable = deepcopy(state.get("_browser_variable_restore") or {})
    if variable.get("context", [])[1:3] != [pack, actor]:
        variable = {}
    context = state.get("variable_review_context")
    if isinstance(context, (list, tuple)) and len(context) >= 3 and list(context[1:3]) == [pack, actor]:
        entries = []
        for identity, entry in (state.get("variable_review_row_entries") or {}).items():
            if not isinstance(identity, tuple) or len(identity) != 2:
                continue
            saved = deepcopy(entry)
            fields = saved.get("fields", {})
            # Widget updates arrive before the page recomposes its canonical
            # draft, including when the next event is sidebar navigation.
            fields.update({str(key)[len(saved["key"]):]: deepcopy(value) for key, value in state.items()
                if str(key).startswith(saved["key"]) and type(value) in (str, int, float, list, dict, tuple, bool, date, datetime, type(None))})
            for bucket in ("fields", "baseline_fields"):
                saved[bucket] = {key: value for key, value in fields.items()} if bucket == "fields" else saved.get(bucket, {})
                saved[bucket] = _browser_fields(saved[bucket])
            for bucket in ("updates", "baseline_updates", "recovered_updates"):
                saved[bucket] = {key: value for key, value in saved.get(bucket, {}).items()
                    if key not in {"logic_reviewed", "typed_value_confirmed"}}
            saved["dirty"] = bool(saved.get("dirty") or saved.get("fields") != saved.get("baseline_fields"))
            # A re-open must compare this original baseline to current evidence.
            saved.pop("conflict", None)
            entries.append({"identity": list(identity), "entry": saved})
        page = deepcopy(state.get("variable_review_page_draft", {}))
        opened = state.get("variable_review_workbook_draft_open", page.get("workbook_draft_open"))
        if type(opened) is bool:
            page["workbook_draft_open"] = opened
        else:
            page.pop("workbook_draft_open", None)
        variable = {"context": deepcopy(context), "entries": entries,
            "page": page,
            "incoming": state.get("variable_review_incoming"),
            "generations": deepcopy(state.get("variable_review_draft_generations", {})),
            "modes": {key: value for key, value in state.items()
                if re.fullmatch(r"variable_review_custom_[a-f0-9]{8,64}", str(key)) and type(value) is bool}}
    setup = {key: value for key, value in state.items() if key in SETUP_FIELDS and (value is None or isinstance(value, str))}
    provenance = setup_defaults.capture_provenance(state, actor)
    return _browser_encode({"pack": pack, "section": section, "routes": routes,
        "active": deepcopy(active) if navigation.valid(active, pack=pack, actor_id=actor, section=section, allowed_packs=allowed_packs) else None,
        "setup": setup, "cohort": cohort, "variable": variable,
        **({"setup_defaults": provenance} if provenance is not None else {})})


def _read_continuation(path, scope):
    if not path.exists():
        return None
    if path.stat().st_size > MAX_CONTINUATION_BYTES:
        raise ValueError("The saved unfinished workspace exceeds its supported size.")
    record = dw._json_read(path)
    if (not isinstance(record, dict) or set(record) != {"schema", "scope", "value", "updated_at", "digest"}
            or record["schema"] != 1 or not _setup_access_current(record["scope"], scope)
            or not isinstance(record["value"], dict)
            or not {"pack", "section", "routes", "active", "setup", "cohort", "variable"} <= set(record["value"])
            or not set(record["value"]) <= {"pack", "section", "routes", "active", "setup", "cohort", "variable", "setup_defaults"}
            or any(not isinstance(record["value"][name], dict) for name in ("routes", "setup", "cohort", "variable"))
            or record["digest"] != dw._hash({key: value for key, value in record.items() if key != "digest"})):
        raise ValueError("The unfinished workspace changed or belongs to a different profile or product access.")
    if "setup_defaults" in record["value"]:
        setup_defaults.validate_provenance(record["value"]["setup_defaults"])
    return record


def browser_begin(root, actor, state, *, allowed_packs):
    """Restore private unfinished work once before creating the page's widgets."""
    scope, path = _continuation_path(root, actor, allowed_packs)
    binding = dw._hash(scope)
    if state.get("_browser_continuation_owner") == binding:
        return False
    previous = state.get("_browser_continuation_owner")
    if previous:
        for key in list(state):
            if str(key).startswith(("variable_review_", "design_", "_browser_continuation_")) or key in {
                    "connected_workflow", "connected_route_history", "pack", "section"}:
                state.pop(key, None)
    state["_browser_continuation_owner"] = binding
    state["_browser_continuation_revision"] = None
    record = _read_continuation(path, scope)
    state["_browser_continuation_revision"] = record["digest"] if record else None
    if not record:
        return False
    value = _browser_decode(record["value"])
    # Validate navigation against current access again; a digest is not authority.
    from experiments.portal import connected_workflow as navigation
    pack = value.get("pack") if value.get("pack") in allowed_packs else ""
    if pack:
        state.setdefault("pack", pack)
    state.setdefault("section", value.get("section") if value.get("section") in BROWSER_SECTIONS else "Home")
    state["connected_route_history"] = {name: context for name, context in value.get("routes", {}).items()
        if name in BROWSER_SECTIONS and navigation.valid(context, pack=pack, actor_id=actor,
            section=name, allowed_packs=allowed_packs)}
    active = value.get("active")
    if navigation.valid(active, pack=pack, actor_id=actor, section=state["section"], allowed_packs=allowed_packs):
        state["connected_workflow"] = active
    for key, item in value.get("setup", {}).items():
        if key in SETUP_FIELDS and (item is None or isinstance(item, str)):
            if key == "np_mode":
                from experiments.portal import ui_text
                item = ui_text.new_product_mode(item)
            state.setdefault(key, item)
    setup_defaults.restore_provenance(state, actor, value.get("setup_defaults"))
    for key, item in value.get("cohort", {}).items():
        if pack and re.fullmatch(r"design_" + re.escape(pack) + r"_proposal_cohort_[a-f0-9]+_[a-f0-9]+_(draft|enabled|selected)", key):
            state[key] = item
    variable = value.get("variable") or {}
    if (isinstance(variable.get("context"), list) and variable["context"][1:3] == [pack, actor]
            and isinstance(variable.get("entries"), list)
            and all(isinstance(variable.get(name, {}), dict) for name in ("page", "generations", "modes"))):
        state["_browser_variable_restore"] = variable
    state["_browser_continuation_saved_at"] = record["updated_at"]
    state["_browser_continuation_restored"] = True
    return True


def restore_variable_browser(state, context):
    """Called after the variable page resets its product/permission context."""
    saved = state.pop("_browser_variable_restore", None)
    if not saved or saved.get("context", [])[:4] != context[:4]:
        return False
    from experiments.portal.variable_review_draft import DraftIdentity
    entries = {}
    generations = saved.get("generations", {})
    for row in saved.get("entries", []):
        if isinstance(row, dict) and isinstance(row.get("identity"), list) and len(row["identity"]) == 2:
            entry = row.get("entry", {})
            if not isinstance(entry, dict) or not isinstance(entry.get("row"), dict):
                continue
            identity = DraftIdentity(context[1], context[2], *row["identity"])
            generation = generations.get(identity.key(), 0)
            if (entry.get("phase") in {"science", "source", "output"} and entry.get("phase") == row["identity"][1]
                    and entry.get("row", {}).get("item_id") == row["identity"][0]
                    and type(generation) is int and 0 <= generation < 100_000
                    and entry.get("key") == "variable_review_row_" + identity.key(generation) + "_"):
                entry["basis"] = tuple(entry.get("basis", []))
                for bucket in ("fields", "baseline_fields"):
                    entry[bucket] = _browser_fields(entry.get(bucket))
                for bucket in ("updates", "baseline_updates", "recovered_updates"):
                    entry[bucket] = {key: value for key, value in entry.get(bucket, {}).items()
                        if key not in {"logic_reviewed", "typed_value_confirmed"}}
                entries[tuple(row["identity"])] = entry
    state["variable_review_row_entries"] = entries
    page = deepcopy(saved.get("page", {}))
    if type(page.get("workbook_draft_open")) is not bool:
        page.pop("workbook_draft_open", None)
    state["variable_review_page_draft"] = page
    state["variable_review_draft_generations"] = saved.get("generations", {})
    if isinstance(saved.get("incoming"), str) and re.fullmatch(r"[a-f0-9]{8,64}", saved["incoming"]):
        state["variable_review_incoming"] = saved["incoming"]
    for key, value in saved.get("modes", {}).items():
        if re.fullmatch(r"variable_review_custom_[a-f0-9]{8,64}", str(key)) and type(value) is bool:
            state[key] = value
    return True


def browser_checkpoint(root, actor, state, *, allowed_packs, replace=False):
    """CAS protects another tab's continuation; canonical product saves are separate."""
    scope, path = _continuation_path(root, actor, allowed_packs)
    if state.get("_browser_continuation_owner") != dw._hash(scope):
        return False
    value = _continuation_value(state, actor, allowed_packs)
    from experiments.portal.local_process_lock import locked
    from experiments.portal.scientific_definitions import _atomic
    path.parent.mkdir(parents=True, exist_ok=True)
    with locked(path.parent / ".save.lock", path.parent):
        try:
            current = _read_continuation(path, scope)
        except ValueError:
            if not replace:
                raise
            import shutil
            import uuid
            backup = path.parent / ("unreadable-" + uuid.uuid4().hex + ".json")
            dw._check_storage_paths([path, backup])
            with path.open("rb") as original, backup.open("xb") as retained:
                shutil.copyfileobj(original, retained)
                retained.flush()
                os.fsync(retained.fileno())
            current = None
        if current and current["value"] == value:
            state["_browser_continuation_revision"] = current["digest"]
            return False
        if not replace and (current["digest"] if current else None) != state.get("_browser_continuation_revision"):
            raise ValueError("Another tab saved a newer unfinished workspace. Your entries remain on this page. In Unfinished work, choose which page to resume next time.")
        record = {"schema": 1, "scope": scope, "value": value,
            "updated_at": datetime.now(timezone.utc).isoformat()}
        record["digest"] = dw._hash(record)
        raw = json.dumps(record, ensure_ascii=False, allow_nan=False).encode()
        if len(raw) > MAX_CONTINUATION_BYTES:
            raise ValueError("This unfinished workspace is too large to checkpoint. Save its variable drafts before closing the page.")
        _atomic(path, raw)
    state["_browser_continuation_revision"] = record["digest"]
    state["_browser_continuation_saved_at"] = record["updated_at"]
    return True

FIELDS = {"np_mode", "np_slug", "np_ver", "np_name", "np_code", "np_family", "np_area", "np_vendor",
          "np_modality", "np_tclass", "np_narrow", "np_cond", "np_terms", "np_old", "np_cls",
          "np_note", "np_ai", "np_by", "np_on", "np_excluded_sheets", "np_excluded_sheets_reason",
          "np_sheet_scope_binding", "np_sheet_scope_hint", "np_sheet_scope_hint_mode"}


def _field(key):
    # a file uploader's key is never a draft field: Streamlit refuses to have its value set from
    # session state, and re-assigning it crashed the New product page (walk UC1-01, 2026-09-07)
    if key.endswith("_upload"):
        return False
    return key in FIELDS or key.startswith(("np_wb", "np_column_", "design_"))


def preserve(state, actor):
    """Called before widgets: self-assignment keeps values when their page is not rendered.

    Button state and preview authorization are never restored. Actor changes discard preview
    and flow action results; drafts are private to the actor within this browser session only.
    """
    completed = state.pop("_completed_setup_actor", None)
    if completed is not None:
        saved = state.get("_form_drafts", {}).get(completed, {})
        for key in list(saved):
            if str(key).startswith("np_"):
                del saved[key]
        if completed == state.get("_draft_actor", actor):
            for key in list(state):
                if str(key).startswith("np_") and key != "np_flash":
                    del state[key]
    previous = state.get("_draft_actor", actor)
    drafts = state.setdefault("_form_drafts", {})
    saved = drafts.setdefault(previous, {})
    for key in list(state):
        if _field(str(key)):
            saved[key] = state[key]
            if previous != actor:
                del state[key]
    if previous != actor:
        for key in list(state):
            if str(key).startswith(("spec_details_", "decision_answer_")):
                state.pop(key, None)
        for key in ("np_previewed", "np_flash", "flow_result", "flow_output", "studies_flash",
                    "flow_dialog", "flow_dialog_feedback", "flow_feedback", "flow_resolution_action",
                    "portal_document", "portal_document_history",
                    "np_slug_suggested", "np_mode_suggested", "np_family_suggested", "np_code_suggested", "study_new_id",
                    "pack_suggested", "section_suggested"):
            state.pop(key, None)
    current = drafts.setdefault(actor, {})
    for key, value in current.items():
        state[key] = value
    state["_draft_actor"] = actor


# This is the registration form's private continuation, not a product record.
# Workbook controls and declarations must be supplied again against current files.
SETUP_FIELDS = {"np_mode", "np_slug", "np_ver", "np_name", "np_code", "np_family", "np_area", "np_vendor",
                "np_modality", "np_tclass", "np_narrow", "np_cond", "np_terms", "np_old", "np_note"}
SETUP_LABELS = {"np_mode": "Starting point", "np_slug": "Product slug", "np_ver": "Specification cut",
    "np_area": "Product folder group",
    "np_name": "Display name", "np_code": "Registry code", "np_family": "Condition family", "np_vendor": "Vendor",
    "np_modality": "Data modality", "np_tclass": "Tumour class", "np_narrow": "Catalogue axis",
    "np_cond": "Condition class", "np_terms": "Disease names", "np_old": "Previous cut", "np_note": "Changelog note"}
SETUP_NOTICE = ("Private unfinished setup only. Re-select the workbook and make access, classification and author/date "
                "declarations again. Saved sheet sections and exclusions can be reviewed after selecting the same workbook. "
                "Resuming does not create a product, call an assistant, validate, approve or release anything.")
MAX_SETUP_BYTES = 80_000


def setup_choices(root, allowed_packs):
    """The existing registration vocabularies, shared by restore and the widgets."""
    from experiments.portal import ui_text as ui
    from rwd_tools import oncology_registry as oncology
    from rwd_tools import product_gates as gates
    from rwd_tools import spec_lint
    policy, error = gates.read_yaml(str(Path(root) / "governance/vendor_policy.yaml"))
    if (error or not isinstance(policy, dict) or not isinstance(policy.get("vendors"), dict)
            or not policy["vendors"] or any(not isinstance(name, str) or not name.strip()
                or not isinstance(value, dict) for name, value in policy["vendors"].items())):
        raise ValueError("The vendor policy is unreadable or has invalid vendor entries. Repair the current checkout's vendor catalogue before setting up a product.")
    vendors = sorted(policy["vendors"])
    registry, error = gates.read_yaml(str(Path(root) / "products/registry.yaml"))
    if (error or not isinstance(registry, dict) or not isinstance(registry.get("tumors"), list)
            or any(not isinstance(row, dict) or not isinstance(row.get("slug"), str) or not row["slug"].strip()
                   for row in registry["tumors"])):
        raise ValueError("The product registry is unreadable or has invalid product entries. Repair the current checkout's registry before setting up a product.")
    cuts = sorted(f"products/{row.get('family') or 'oncology'}/{row['slug']}/{row.get('current_spec_version')}"
        for row in registry["tumors"])
    try:
        families = sorted(spec_lint.load_tumour_registry(root)["families"])
    except SystemExit as error:
        raise ValueError(str(error)) from None
    return {"np_mode": list(ui.NEW_PRODUCT_MODES), "np_family": families, "np_area": ["oncology", "heme", "conditions"],
        "np_vendor": vendors, "np_modality": list(gates.MODALITIES), "np_tclass": ["solid", "heme", "not_applicable"],
        "np_narrow": list(dict.fromkeys([*oncology.NARROW, "general"])), "np_cond": list(ui.CONDITION_CLASS_WORDS), "np_old": [p for p in cuts if p in allowed_packs]}


def history_key(root, actor):
    owner = hashlib.sha256((str(root) + "\0" + actor).encode()).hexdigest()[:20]
    return f"flow_assistant_history_{owner}_"


def _setup_scope(root, actor, allowed_packs):
    root = Path(root).resolve(strict=True)
    from experiments.portal.installation_storage import logical_path
    if not isinstance(actor, str) or not actor.strip() or len(actor) > 300 or any(ord(c) < 32 for c in actor):
        raise ValueError("Choose the current editing identity before saving setup.")
    if not isinstance(allowed_packs, (list, tuple, set)) or any(not isinstance(p, str) for p in allowed_packs):
        raise ValueError("Current product access is unavailable.")
    scope = {"checkout": dw._hash(str(logical_path(root))), "owner": dw._hash(actor), "access": sorted(set(allowed_packs))}
    base = Path(os.environ.get("RWDP_STATE_DIR") or root / ".portal-drafts").absolute()
    directory = base / "setup-drafts" / scope["checkout"][:12] / scope["owner"][:12]
    if directory.resolve() != directory:
        raise ValueError("The private setup location redirects to another folder.")
    from experiments.portal.installation_storage import io_path
    directory = io_path(directory)
    dw._check_storage_paths([directory / ("0" * 24 + ".json")])
    return scope, directory


def _setup_values(values):
    if not isinstance(values, dict) or not set(values) <= SETUP_FIELDS:
        raise ValueError("The saved setup contains unsupported fields.")
    if any(value is not None and (not isinstance(value, str) or len(value) > 4000 or "\0" in value)
           for value in values.values()):
        raise ValueError("Keep setup entries within the supported text size.")
    return dict(values)


def _setup_history(history):
    if not isinstance(history, list) or len(history) > 8:
        raise ValueError("The setup conversation exceeds its supported history.")
    result = []
    for turn in history:
        if (not isinstance(turn, dict) or set(turn) != {"question", "answer"}
                or any(not isinstance(value, str) or len(value) > 6000 or "\0" in value for value in turn.values())):
            raise ValueError("The saved setup conversation is malformed.")
        result.append(dict(turn))
    return result


def _setup_ingress(values, history, hint=None):
    from experiments.portal.scientific_definition_ai import _ingress
    try:
        _ingress("\n".join(str(value or "") for value in values.values()) + "\n" +
                 "\n".join(turn[part] for turn in history for part in ("question", "answer")) + "\n" +
                 (json.dumps(hint, ensure_ascii=False) if hint else ""))
    except ValueError:
        raise ValueError("Remove credentials or details about individual people before saving or resuming setup.") from None


def capture_setup(state, root, actor):
    values = _setup_values({key: state[key] for key in SETUP_FIELDS if key in state})
    history = _setup_history([{part: turn.get(part, "") for part in ("question", "answer")}
        for turn in state.get(history_key(root, actor), [])[-8:]])
    from experiments.portal import new_product_sheet_scope as sheets
    hint = sheets.capture_hint(root, state)
    provenance = setup_defaults.capture_provenance(state, actor)
    _setup_ingress(values, history, {"sheet_scope_hint": hint, "setup_defaults": provenance})
    return {"fields": values, "history": history, **({"sheet_scope_hint": hint} if hint else {}),
            **({"setup_defaults": provenance} if provenance is not None else {})}


def _setup_access_current(saved, current):
    """A new product may expand access; previous access must never be lost.

    Earlier snapshots retained only the access digest, so their readable scope
    remains exact. They cannot safely infer a subset from that one-way digest.
    """
    if (not isinstance(saved, dict) or set(saved) != {"checkout", "owner", "access"}
            or any(saved.get(key) != current[key] for key in ("checkout", "owner"))):
        return False
    access = saved["access"]
    if isinstance(access, str):
        return access == dw._hash(current["access"])
    return (isinstance(access, list) and all(isinstance(pack, str) for pack in access)
            and access == sorted(set(access)) and set(access) <= set(current["access"]))


def _read_setup(path, scope):
    if path.stat().st_size > MAX_SETUP_BYTES:
        raise ValueError("The saved setup is too large to resume.")
    value = dw._json_read(path)
    required = {"schema", "id", "scope", "fields", "history", "saved_at", "digest"}
    if (not isinstance(value, dict) or not required <= set(value) or not set(value) <= required | {"sheet_scope_hint", "setup_defaults"}
            or value.get("schema") != 1 or not _setup_access_current(value.get("scope"), scope)
            or value.get("digest") != dw._hash({k: v for k, v in value.items() if k != "digest"})
            or value.get("id") != path.stem or not isinstance(value.get("saved_at"), str)):
        raise ValueError("This saved setup changed or belongs to a different checkout, identity or product access.")
    _setup_values(value["fields"])
    _setup_history(value["history"])
    if "sheet_scope_hint" in value:
        from experiments.portal import new_product_sheet_scope as sheets
        sheets.validate_hint(value["sheet_scope_hint"])
    if "setup_defaults" in value:
        setup_defaults.validate_provenance(value["setup_defaults"])
    keys = ("scope", "fields", "history") + tuple(key for key in ("sheet_scope_hint", "setup_defaults") if key in value)
    if value["id"] != dw._hash({key: value[key] for key in keys})[:24]:
        raise ValueError("This saved setup does not match its original snapshot.")
    _setup_ingress(value["fields"], value["history"],
        {"sheet_scope_hint": value.get("sheet_scope_hint"), "setup_defaults": value.get("setup_defaults")})
    return value


def save_setup(root, actor, state, *, allowed_packs, can_write):
    """Save one explicit immutable snapshot; equal content reuses its original ID."""
    if can_write is not True:
        raise ValueError("Saving setup requires permission to start a product in this local workspace.")
    scope, directory = _setup_scope(root, actor, allowed_packs)
    payload = {"scope": scope, **capture_setup(state, root, actor)}
    if not payload["history"] and not any(value for key, value in payload["fields"].items() if key != "np_mode"):
        raise ValueError("Enter a product name, another setup detail or a setup question before saving.")
    identifier = dw._hash(payload)[:24]
    value = {"schema": 1, "id": identifier, **payload, "saved_at": datetime.now(timezone.utc).isoformat()}
    value["digest"] = dw._hash(value)
    raw = json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8")
    if len(raw) > MAX_SETUP_BYTES:
        raise ValueError("This setup is too large to save. Shorten its entries before saving.")
    from experiments.portal.local_process_lock import locked
    from experiments.portal.scientific_definitions import _atomic
    directory.mkdir(parents=True, exist_ok=True)
    with locked(directory / ".save.lock", directory):
        path = directory / (identifier + ".json")
        if path.exists():
            return _read_setup(path, scope)
        if len(list(directory.glob("*.json"))) >= 200:
            raise ValueError("This identity has 200 saved setup snapshots. Ask the workspace owner to manage its private saved history.")
        _atomic(path, raw)
    return value


def list_setups(root, actor, *, allowed_packs):
    scope, directory = _setup_scope(root, actor, allowed_packs)
    records, warnings = [], []
    files = list(directory.glob("*.json")) if directory.exists() else []
    if len(files) > 200:
        raise ValueError("The saved setup history exceeds its supported size.")
    for path in files:
        try:
            record = _read_setup(path, scope)
            records.append({"id": record["id"], "digest": record["digest"], "saved_at": record["saved_at"],
                            "name": record["fields"].get("np_name") or record["fields"].get("np_slug") or "Unfinished setup"})
        except (OSError, ValueError, TypeError, KeyError, RecursionError):
            warnings.append("A saved setup is unreadable or outside the current product access and was not offered.")
    return {"records": sorted(records, key=lambda record: record["saved_at"], reverse=True), "warnings": sorted(set(warnings))}


def load_setup(root, actor, identifier, *, allowed_packs, expected_digest):
    scope, directory = _setup_scope(root, actor, allowed_packs)
    if not isinstance(identifier, str) or not re.fullmatch(r"[0-9a-f]{24}", identifier):
        raise ValueError("Choose a saved setup from the current list.")
    value = _read_setup(directory / (identifier + ".json"), scope)
    if value["digest"] != expected_digest:
        raise ValueError("The saved setup changed. Reload the saved list before resuming.")
    return value


def resume_preview(root, actor, identifier, state, *, allowed_packs, expected_digest, choices):
    saved = load_setup(root, actor, identifier, allowed_packs=allowed_packs, expected_digest=expected_digest)
    fields = {key: saved["fields"].get(key, "" if key not in choices else None) for key in SETUP_FIELDS}
    from experiments.portal import ui_text
    fields["np_mode"] = ui_text.new_product_mode(fields["np_mode"])
    reset = []
    for key, options in choices.items():
        if fields[key] is not None and fields[key] not in options:
            if fields[key]:
                reset.append(SETUP_LABELS[key])
            fields[key] = options[0] if key == "np_mode" else None
    if fields["np_mode"] is None:
        fields["np_mode"] = choices["np_mode"][0]
    if fields["np_old"] and fields["np_old"] not in allowed_packs:
        reset.append(SETUP_LABELS["np_old"])
        fields["np_old"] = None
    before = capture_setup(state, root, actor)
    diff = [{"Field": SETUP_LABELS[key], "Current": before["fields"].get(key) or "", "Saved": value or ""}
            for key, value in sorted(fields.items()) if (before["fields"].get(key) or "") != (value or "")]
    if before["history"] != saved["history"]:
        diff.append({"Field": "Setup conversation", "Current": json.dumps(before["history"], ensure_ascii=False),
                     "Saved": json.dumps(saved["history"], ensure_ascii=False)})
    if before.get("sheet_scope_hint") != saved.get("sheet_scope_hint"):
        diff.append({"Field": "Sheet exclusions to review after workbook selection",
                     "Current": json.dumps(before.get("sheet_scope_hint") or {}, ensure_ascii=False),
                     "Saved": json.dumps(saved.get("sheet_scope_hint") or {}, ensure_ascii=False)})
    replaces = bool(before["history"] or before.get("sheet_scope_hint") or any(value for key, value in before["fields"].items() if key != "np_mode"))
    return {"id": identifier, "digest": expected_digest, "fields": fields, "history": saved["history"], "diff": diff,
            "resets": reset, "replaces": replaces, "current_digest": dw._hash(before), "choices_digest": dw._hash(choices),
            **({"setup_defaults": saved["setup_defaults"]} if "setup_defaults" in saved else {}),
            **({"sheet_scope_hint": saved["sheet_scope_hint"], "sheet_scope_hint_mode": fields.get("np_mode")}
               if saved.get("sheet_scope_hint") else {})}


def restore_setup(root, actor, state, proposal, *, allowed_packs, choices, can_write, confirmed):
    """Apply a fresh reviewed continuation before any registration widget renders."""
    if can_write is not True or confirmed is not True:
        raise ValueError("Explicitly choose to resume this setup in the current editing session.")
    current = resume_preview(root, actor, proposal["id"], state, allowed_packs=allowed_packs,
        expected_digest=proposal["digest"], choices=choices)
    if current != proposal:
        raise ValueError("Your current setup or available choices changed. Review the saved setup again.")
    for key in list(state):
        if str(key).startswith(("np_", "chat_form_", "flow_assistant_feedback")) and not str(key).endswith("_upload"):
            state.pop(key, None)
    state.update(current["fields"])
    setup_defaults.restore_provenance(state, actor, current.get("setup_defaults"))
    if current.get("sheet_scope_hint"):
        from experiments.portal import new_product_sheet_scope as sheets
        state[sheets.HINT] = sheets.validate_hint(current["sheet_scope_hint"])
        state[sheets.HINT_MODE] = current["sheet_scope_hint_mode"]
    # Explicit empty declaration values prevent the local identity default from
    # being mistaken for a declaration restored from this snapshot.
    # Explicitly reset existing widgets too: deleting their keys lets Streamlit
    # recover the previous frontend values even though the workbook was not restored.
    state.update(np_by="", np_on="", np_ai=None, np_wb="(none)", np_wb2="(none)",
                 np_wb_path="", np_wb2_path="")
    # These deliberately blank declarations are edits, not new suggestions.
    state["_np_generated_defaults"].update(np_by=None, np_on=None)
    state[history_key(root, actor)] = [{**turn, "actions": [], "source": "saved_setup"} for turn in current["history"]]
    state[history_key(root, actor) + "_restore_requested"] = True
    state.setdefault("_form_drafts", {})[actor] = {key: value for key, value in state.items() if _field(str(key))}
    return current
