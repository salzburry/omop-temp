"""Keep a failed setup visible while the researcher corrects the existing form."""
from __future__ import annotations

from pathlib import Path
import hashlib
import re

import streamlit as st

from experiments.portal import form_assistance as forms
from experiments.portal import new_product_words as words
from experiments.portal import portal_runtime
from experiments.portal import session_drafts
from experiments.portal import ui_text as ui


KEY = "np_recovery"
WORKSPACE_ISSUES = {"setup_existing_product_status_conflict", "setup_existing_registry_invalid"}


def clear():
    st.session_state.pop(KEY, None)


def _edit(section):
    record = st.session_state.get(KEY)
    if isinstance(record, dict):
        record["edit"] = section
    st.session_state.pop("np_previewed", None)


def editing(root, actor_id, section):
    """Move the existing form controls beside this owner's retained failure."""
    record = st.session_state.get(KEY)
    return (isinstance(record, dict) and record.get("owner") == _owner(root, actor_id)
            and record.get("edit") == section)


def _edit_button(label, section):
    st.button(label, key="np_recovery_edit_" + section, on_click=_edit, args=(section,))


def _request_preview():
    record = st.session_state.get(KEY)
    if isinstance(record, dict):
        record["preview_requested"] = True


def take_preview_request(root, actor_id):
    record = st.session_state.get(KEY)
    return (isinstance(record, dict) and record.get("owner") == _owner(root, actor_id)
            and record.pop("preview_requested", False))


def _ask_chat():
    # Reuse the owner-bound, one-shot chat request after a full form render.
    # The current validation supplies sanitized diagnostics; raw logs stay local.
    record = st.session_state.get(KEY) or {}
    if (record.get("failure") or {}).get("workspace"):
        forms.defer_creation("Help me resolve the current product setup error using the displayed workspace status findings. "
            "Identify the existing product and its conflicting status records, and explain the workspace owner's repair or handoff. "
            "Changing this new product's workbook or classification does not repair an existing registry conflict. "
            "Do not propose advancing a lifecycle status without its required evidence. "
            "If the current workspace check is clear, explain how to restore the required setup selections and preview again.")
        return
    forms.defer_creation("Help me resolve the current product setup error using the displayed findings and editable fields. "
        "Explain the next action I can take here in the UI, and suggest supported draft corrections where needed. "
        "If the earlier findings are stale, help me recheck the current setup first.")


def _owner(root, actor_id):
    return forms.digest([str(Path(root).resolve()), actor_id])


def _inputs(state):
    fields = session_drafts.FIELDS | {"np_sheet_domains", "np_sheet_domain_reason"}
    values = {key: state[key] for key in state if key in fields or
              str(key).startswith(("np_wb", "np_column_", "np_sheet_domain_choice_")) and not str(key).endswith("_upload")}
    for key in ("np_wb_upload", "np_wb2_upload"):
        upload = state.get(key)
        if upload is None:
            continue
        from experiments.portal.specification_attachment import MAX_UPLOAD_BYTES
        try:
            size = getattr(upload, "size", None)
            if type(size) is int and size > MAX_UPLOAD_BYTES:
                raise ValueError("Oversized upload")
            raw = upload.getvalue()  # Does not advance the upload's file pointer.
            if not isinstance(raw, bytes) or len(raw) > MAX_UPLOAD_BYTES:
                raise ValueError("Invalid upload")
            values[key] = {"name": str(upload.name), "sha256": hashlib.sha256(raw).hexdigest()}
        except (AttributeError, OSError, ValueError, TypeError):
            values[key] = {"unreadable_upload": True}
    return forms.digest(values)









def describe(output, *, phase="write", runtime_failure=None, outcome=None, current=False):
    """Only validated producer facts choose a repair; console prose is a retained log."""
    value = {"title": "Setup result needs review", "stage": "", "findings": [], "sentences": [],
        "untranslated": 0, "operational": bool(runtime_failure), "state": "unconfirmed", "runtime_failure": runtime_failure,
        "phase": phase, "typed": False, "summary": "This attempt has no verified recovery evidence. Inspect its run details and current product progress before repeating Write.",
        "setup_lock": False, "changed_files": False, "workbook": False, "mapping": False, "headers": False,
        "identity": False, "product": False, "data": False, "family": "", "workspace": False}
    if not isinstance(outcome, dict) or outcome.get("version") != 2 or runtime_failure:
        return value
    from rwd_tools import new_product
    try:
        checked = new_product.parse_outcome(outcome, outcome["returncode"])
    except (ValueError, TypeError, KeyError):
        return value
    failure = checked.failure
    if not failure:
        return value
    stage = failure["stage"]
    titles = {"arguments": "Setup inputs", "setup_access": "Waiting for setup access", "recovery": "Previous installation recovery",
        "preflight": "Setup inputs", "planning": "Setup plan", "registration": "Specification registration",
        "validation": "Staged setup checks", "extraction": "Specification extraction", "input_freshness": "Inputs changed during validation",
        "installation": "Installing the checked product", "internal": "Setup operation"}
    value.update(typed=True, title=titles[stage], stage=stage,
        findings=forms.validation_messages([item["message"] for item in failure["issues"]])[0])
    disposition, previous = failure["write_disposition"], failure["prior_recovery"]
    if disposition == "not_started" and previous in {"not_run", "absent"}:
        value.update(state="refused", summary="This attempt stopped before installing product changes. Nothing was written to the product by this attempt.")
    elif disposition == "rolled_back":
        value.update(state="rolled_back", summary="This attempt's installation changes were rolled back and the prior file bytes were restored.")
    else:
        value["summary"] = "This attempt does not establish an unchanged product. Inspect current product progress and the installation recovery state before repeating Write."
    if previous not in {"not_run", "absent"}:
        value["summary"] += " Recovery of an earlier installation also ran during this attempt."
    # A verified historical workspace failure remains useful after form restoration.
    # Current status is read again before offering recovery guidance or chat context.
    codes = {row["code"] for row in failure["issues"]}
    value["workspace"] = bool(codes & WORKSPACE_ISSUES)
    if not current:
        return value
    value.update(setup_lock="setup_lock_unavailable" in codes, changed_files="setup_inputs_changed" in codes,
        mapping=bool(codes & {"workbook_sheet_mapping_invalid", "workbook_sheets_unclassified"}),
        headers=bool(codes & {"workbook_column_mapping_invalid", "workbook_columns_unresolved", "workbook_positional_columns", "workbook_empty_requirement_sheet"}),
        workbook=bool(codes & {"workbook_input_invalid", "workbook_empty", "workbook_scope_invalid", "workbook_sheet_mapping_invalid", "workbook_column_mapping_invalid", "workbook_sheets_unclassified", "workbook_columns_unresolved", "workbook_positional_columns", "workbook_empty_requirement_sheet", "workbook_sheet_labels_collide"}),
        product=bool(codes & {"setup_family_collision", "setup_product_invalid"}))
    families = {row["details"].get("family") for row in failure["issues"] if row["code"] == "setup_family_collision"}
    if len(families) == 1:
        family = next(iter(families))
        if isinstance(family, str) and re.fullmatch(r"[a-z][a-z0-9_]*", family):
            value["family"] = family
    return value



def capture(root, actor_id, result, *, phase):
    """Retain the invocation outcome beside its log; change no setup fields."""
    if result.returncode == 0:
        clear()
        return
    output = ((result.stdout or "") + (result.stderr or "")).strip()
    outcome = getattr(result, "outcome", None)
    binding = getattr(result, "setup_binding", None)
    from rwd_tools import new_product
    try:
        if not isinstance(binding, dict):
            raise ValueError("No verified invocation binding.")
        outcome = new_product.parse_outcome(outcome, result.returncode, expected_binding=binding["expected"], request_argv=binding["argv"]).as_dict()
    except (ValueError, TypeError, KeyError):
        outcome, binding = None, None
    st.session_state[KEY] = {"owner": _owner(root, actor_id), "inputs": _inputs(st.session_state), "output": output,
        "outcome": outcome, "binding": binding,
        "failure": describe(output, phase=phase, runtime_failure=portal_runtime.failure_kind(result), outcome=outcome)}
    st.session_state.pop("np_previewed", None)


def _family_repair(root, record):
    """Offer the existing registration route only for a current, exact family collision."""
    family = record["failure"].get("family")
    if not family:
        return False
    from rwd_tools import spec_lint
    try:
        registry = spec_lint.load_tumour_registry(root)
    except (SystemExit, OSError, ValueError, TypeError):
        return False
    if family not in registry["families"]:
        return False
    if st.session_state.get("np_mode") == ui.NEW_PRODUCT_MODES[2]:
        return False
    current = str(st.session_state.get("np_slug") or "").strip()
    current_code = str(st.session_state.get("np_code") or "").strip()
    selected = (st.session_state.get("np_mode") == ui.NEW_PRODUCT_MODES[1]
                and st.session_state.get("np_family") == family)
    if selected and current and current != family and current_code != family:
        st.info(f"The form now uses the existing {family} tumour family and product identifier {current}. Preview the updated plan to check it.")
        return True
    st.write("**Correct the starting point here**")
    st.caption(f"Use the existing {family} tumour family. Choose a distinct product identifier below; this only updates your form.")
    key = "np_recovery_product_slug_" + forms.digest([record["owner"], record["inputs"], record["output"]])[:16]
    identifier = st.text_input("Distinct product identifier", value="" if current == family else current, key=key,
        help=f"Lower-case letters, digits and underscores, starting with a letter. Use your product's identifier, for example {family}_outcomes; {family} is reserved for the tumour family.").strip()
    valid = bool(re.fullmatch(r"[a-z][a-z0-9_]*", identifier)) and identifier not in registry["families"]
    if identifier and not valid:
        st.caption("Choose an identifier different from the tumour family, using lower-case letters, digits and underscores.")
    code = None
    if current_code == family:
        st.caption(f"Your registry code is also {family}. Leave the code below empty to use the new product identifier, or enter a distinct code.")
        code = st.text_input("Registry code for this product (optional)", value="", key=key + "_code",
                             help="An empty code follows the new product identifier. Other saved registry codes are kept.").strip()
        valid = valid and (not code or bool(re.fullmatch(r"[a-z][a-z0-9_]*", code)) and code not in registry["families"])
    if st.button(f"Use {family} for this product", key="np_recovery_use_family", disabled=not valid):
        # The app consumes these existing hooks before instantiating the real widgets.
        # Do not mutate widget values after rendering, or repeat the failed operation.
        st.session_state["np_mode_suggested"] = True
        st.session_state["np_family_suggested"] = family
        st.session_state["np_slug_suggested"] = identifier
        if code is not None:
            st.session_state["np_code_suggested"] = code or identifier
        st.session_state.pop("np_previewed", None)
        st.rerun()
    return True


def _lock_help(root):
    """Inspect current access without recovering a lock or repeating the setup."""
    from rwd_tools import new_product
    current = new_product.standup_status(root)
    ready = current["state"] in {"absent", "dead"} and not current.get("installation_pending")
    if ready:
        message = ("No product setup holds this lock now. Your entries are retained. "
                   "Choose Preview the plan, then Write when that preview passes.")
        st.info(message)
        st.caption("Write checks access again before making changes. Nothing retries automatically.")
    else:
        message = current["reason"]
        st.warning(message)
        st.caption("Your entries are retained. Check setup access again after the running operation finishes or the reported problem is resolved.")
    st.button("Check setup access again", key="np_recovery_check_lock",
              help="Refresh the lock status only; this does not preview, create, cancel or unlock a product.")
    return ready, message


def _workspace_help(root):
    """Read the shared status check without altering products or repeating setup."""
    from rwd_tools import new_product
    try:
        issues = new_product.existing_product_status_issues(root)
        messages, omitted = forms.validation_messages([str(issue) for issue in issues])
        if issues and not messages:
            raise ValueError("No displayable workspace diagnostic.")
    except (OSError, ValueError, TypeError):
        messages, omitted = ["The current workspace status could not be checked. Ask the workspace owner to inspect the retained setup failure report."], 0
    blocked = bool(messages)
    st.write("**Current workspace check**")
    if blocked:
        for message in messages:
            st.warning(message)
        guidance = ("Ask the workspace owner to reconcile the named existing product's registry and configuration using its reviewed lifecycle evidence. "
                    "Changing this new product's workbook, name or AI-access choice will not repair that conflict. "
                    "Do not advance a product's status just to make setup pass.")
        st.info(guidance)
    else:
        guidance = ("The existing-product status check is now clear. The failed run below is retained history. "
                    "Review your setup selections and Preview the plan before choosing Write.")
        st.success(guidance)
    if omitted:
        st.caption("Additional workspace findings are available in the retained run details.")
    st.button("Check workspace status", key="np_recovery_check_workspace",
              help="Read the shared registry and product statuses again. This does not change a status, create a product or retry a write.")
    diagnostic = "\n".join(["Product setup workspace check", *messages, guidance])
    st.download_button("Download workspace repair details", diagnostic,
        file_name="workspace-setup-repair.txt", mime="text/plain", key="np_recovery_workspace_download")
    return blocked, [*messages, guidance]


def _installation_recovery(root, *, can_write=False):
    """An explicit recovery also works after the browser/session that created it ended."""
    from rwd_tools import new_product
    if not (Path(root) / new_product.INSTALL_JOURNAL).exists():
        return
    current = new_product.standup_status(root)
    st.warning(current["reason"])
    st.caption("Recovery restores the previous complete installation, or retains a completed one. It refuses conflicting external edits. Your setup entries are kept.")
    if st.button("Recover interrupted installation", key="np_recover_installation",
                 disabled=not can_write or not current.get("recovery_allowed")):
        try:
            result = new_product.recover_install(root)
        except (OSError, ValueError) as error:
            st.error("Installation recovery stopped. " + str(error))
        else:
            clear()
            st.session_state.pop("np_previewed", None)
            st.session_state["np_installation_recovered"] = result
            st.rerun()


def render(root, actor_id, *, sheet_scope=None, can_write=False):
    _installation_recovery(root, can_write=can_write)
    recovered = st.session_state.pop("np_installation_recovered", None)
    if recovered:
        st.success("Installation recovered. Your setup entries are retained; preview them again before writing.")
    record = st.session_state.get(KEY)
    if not isinstance(record, dict):
        return
    if record.get("owner") != _owner(root, actor_id):
        clear()
        return
    previous = record["failure"]
    changed = record["inputs"] != _inputs(st.session_state)
    binding = record.get("binding")
    current, outcome = False, None
    if isinstance(binding, dict):
        from rwd_tools import new_product
        try:
            request = binding["argv"]
            outcome = new_product.parse_outcome(record["outcome"], record["outcome"]["returncode"], expected_binding=binding["expected"], request_argv=request).as_dict()
            current = (Path(request[request.index("--root") + 1]).resolve() == Path(root).resolve()
                and new_product.request_binding(request, binding["expected"]["nonce"]) == binding["expected"])
        except (OSError, ValueError, TypeError, KeyError, IndexError):
            outcome = None
    changed = changed or record.get("outcome") is not None and not current
    failure = describe(record["output"], phase=previous["phase"], runtime_failure=previous.get("runtime_failure"),
                       outcome=outcome, current=current and not changed)
    record["failure"] = failure
    with st.container(border=True):
        st.subheader("Stopped at: " + failure["title"])
        show = st.warning if failure["phase"] == "preview" else st.error
        lock_ready, lock_message = False, ""
        workspace_blocked, workspace_messages = False, []
        show(failure["summary"])
        if failure["workspace"]:
            workspace_blocked, workspace_messages = _workspace_help(root)
        elif failure["setup_lock"]:
            lock_ready, lock_message = _lock_help(root)
        elif failure["changed_files"]:
            st.info("Wait until source and workbook edits finish, then preview the current setup. Your entries are retained.")
        for sentence in failure["sentences"]:
            if sentence != words.OPERATIONAL_FAILURE:
                st.markdown("- " + sentence)
        if failure["findings"]:
            st.write("**Findings from the failed run**" if failure["workspace"] else "**What needs attention**")
            for finding in failure["findings"]:
                st.write("• " + finding)
        if changed:
            if st.session_state.get("_browser_continuation_restored"):
                st.info("Your saved setup details were restored after refresh. Workbook selections and AI-access choices are not restored. "
                        "Reselect any workbook in step 3 (include test/reference materials if needed), confirm AI access in step 4, "
                        + ("then Preview the plan after the workspace issue is resolved. " if workspace_blocked else "then Preview the plan before retrying Write. ")
                        + "The failed run retains its original inputs and report.")
            elif workspace_blocked:
                st.info("Your setup entries changed after this failed run. The current workspace conflict still needs repair; your form edits do not resolve it.")
            else:
                st.info("Your setup changed after this failed run. These are the previous findings; Preview the updated plan before trying Write again.")
        elif not failure["workspace"] and not failure["setup_lock"] and not failure["changed_files"]:
            st.caption("Your form entries are retained below. Correct the indicated input, then choose Preview the plan again. No retry runs automatically.")
        offered = failure["workspace"] or failure["setup_lock"] or failure["changed_files"] or (not changed and _family_repair(root, record))
        if failure["workbook"]:
            _edit_button("Edit the specification input (step 3)", "specification")
            selectable = any(row.get("mapping_selectable") for row in (sheet_scope or {}).get("sheets") or [])
            if failure["mapping"] and selectable:
                st.write("Use the sheet section choices below to classify the named sheets, then preview again.")
            if failure["headers"]:
                st.write("Correct the named header or column in the source workbook, then select or upload that corrected workbook in step 3. A section mapping does not rename workbook columns.")
            elif not (failure["mapping"] and selectable):
                st.write("Review the selected workbook and its sheet scope in step 3. If its source content needs correction, choose the corrected workbook there before previewing again.")
            offered = True
        if failure["identity"]:
            _edit_button("Edit classification details (step 4)", "classification")
            offered = True
        if failure["data"]:
            _edit_button("Edit data details (step 2)", "data")
            offered = True
        if failure["product"] and not offered:
            _edit_button("Edit product details (step 1)", "details")
            offered = True
        _edit_button("Edit setup inputs", "all")
        st.button("Ask chat to help resolve this error", key="np_recovery_ask_chat", on_click=_ask_chat,
                  disabled=not st.session_state.get(forms.KEY + "enabled"),
                  help="Send this setup's current findings and editable field context to the assistant. Review any suggested corrections before writing.")
        st.button("Preview setup again", key="np_recovery_preview", on_click=_request_preview,
                  disabled=workspace_blocked,
                  help="Resolve the displayed workspace conflict first." if workspace_blocked else
                       "Check the current entries once. A successful preview lets you review the plan before choosing Write.")
        if record.get("edit"):
            st.info("The selected step's editable fields are directly below this report. Your other setup entries are retained.")
            st.button("Show setup steps in their original order", key="np_recovery_edit_done",
                      on_click=_edit, args=(None,))
        if not offered:
            st.write("Ask chat to work through this error with the current setup context, or open Edit setup inputs to correct the form. Preview setup again checks your changes before Write becomes available.")
        if failure["phase"] == "write" and failure["state"] != "refused":
            st.caption("The tool did not verify whether a product was installed. Check product progress before repeating a write.")
        with st.expander("Run details for the failed setup"):
            st.code(record["output"] or "(no output)", language=None)
            st.download_button("Download setup failure report", record["output"] or "No output was returned.",
                file_name="product-setup-failure.txt", mime="text/plain", key="np_recovery_download")
        diagnostics = []  # Historical console text is available only in Run details.
        blockers = [lock_message] if failure["setup_lock"] else failure["findings"] or [*failure["sentences"]] or diagnostics or ["The setup check did not complete; inspect its retained run details."]
        if failure["changed_files"]:
            blockers = ["Checkout or workbook edits invalidated this validation run. Once edits finish, preview the unchanged form again before an explicit Write.", *failure["findings"]]
        if failure["workspace"]:
            blockers = workspace_messages
        forms.record_validation([f"{failure['title']}: {line}" for line in blockers],
            title="Product setup stopped: " + failure["title"], action_id="new_product_" + failure["phase"],
            input_digest=forms.digest([record["inputs"], _inputs(st.session_state), record["output"], lock_message]),
            primary=True, status=("blocked" if workspace_blocked else "needs_recheck" if failure["workspace"] or changed or lock_ready or failure["changed_files"] else "blocked"))
