"""Portable development review confirmation; production review stays with its review service."""
from __future__ import annotations

from pathlib import Path

import streamlit as st
from experiments.portal import review_setup
from experiments.portal import authoring_session


def _responsibilities(snapshot, reviewer):
    """Describe only the acts already attributed to this person in the review records."""
    approvals = {"source_refs.yaml": "Specification review", "CONTRACT_APPROVAL.yaml": "Scientific approval",
                 "CONFIGURATION_APPROVAL.yaml": "Configuration approval", "SEMANTIC_APPROVAL.yaml": "Semantic approval",
                 "RELEASE_APPROVAL.yaml": "Release approval", "source_adapters.yaml": "Source mapping review"}
    fields = {"classified_by": "Permission to use AI", "revised_by": "Source revision review",
              "clinically_reviewed_by": "Clinical review", "validated_by": "Candidate validation",
              "spec_qc_reviewed_by": "Independent specification review",
              "technically_reviewed_by": "Independent technical review"}
    labels = []
    for claim in snapshot["claims"]:
        if claim["who"] != reviewer:
            continue
        field = claim["field"]
        label = (approvals.get(Path(claim["file"]).name, "Recorded approval") if field == "approved_by"
                 else "Scientific decision" if field.startswith("decision:")
                 else fields.get(field, "Recorded review"))
        if label not in labels:
            labels.append(label)
    return " · ".join(labels)


def _prepare(root, pack, checkpoint):
    st.session_state.pop("review_sign_done", None)
    try:
        st.session_state["review_command_snapshot"] = review_setup.development_snapshot(root, pack, checkpoint)
        st.session_state.pop("review_command_error", None)
    except Exception as error:
        st.session_state.pop("review_command_snapshot", None)
        st.session_state["review_command_error"] = str(error)


def _confirm_here(root, pack, checkpoint, reviewer, snapshot, actor_id, actor_name, actor_email):
    basis = (reviewer, snapshot["digest"])
    if st.session_state.get("review_sign_basis") != basis:
        for key in ("review_sign_name", "review_sign_email", "review_sign_key", "review_sign_confirm", "review_sign_error"):
            st.session_state.pop(key, None)
        st.session_state["review_sign_basis"] = basis
    own_profile = str(actor_name).casefold() == reviewer.casefold()
    with st.form("review_sign_form"):
        st.text_input("Your name", value=reviewer, key="review_sign_name", disabled=True)
        email = st.text_input("Your email address", value=actor_email if own_profile else "", key="review_sign_email")
        confirm = st.checkbox(f"I am {reviewer}. I reviewed these exact records and confirm my own review.", key="review_sign_confirm")
        submitted = st.form_submit_button("Confirm review", type="primary", key="review_sign_submit")
    if submitted:
        if not confirm:
            st.session_state["review_sign_error"] = "Tick the confirmation first. No review was recorded."
        else:
            try:
                result = review_setup.confirm_development(root, pack, checkpoint, reviewer, email.strip(), snapshot["digest"],
                                                          confirmed=True, local_demo=True, can_review=True)
                if not result.get("ok", True):
                    raise review_setup.Refused(result.get("message") or "The development review could not be recorded.")
            except (review_setup.Refused, OSError, ValueError) as error:
                st.session_state["review_sign_error"] = str(error)
            else:
                st.session_state.pop("review_sign_error", None)
                st.session_state["review_sign_done"] = {"reviewer": reviewer, "record_id": result["record_id"],
                    "digest": snapshot["digest"],
                    "message": result["message"], "others": [person for person in snapshot["reviewers"]
                        if person != reviewer and person not in snapshot.get("confirmed_reviewers", [])]}
                st.session_state.pop("review_command_snapshot", None)
                st.session_state.setdefault("flow_result", {}).pop(pack, None)
                st.session_state["flow_notice"] = f"Development review confirmed for {reviewer}. Progress refreshes automatically."
                st.session_state["flow_requested_action"] = {
                    "pack": pack, "actor": actor_id, "action_id": None, "after_save": True,
                }
                st.rerun()
    if st.session_state.get("review_sign_error"):
        st.error(st.session_state["review_sign_error"])


def render(root, pack, checkpoint, actor_id, *, local_demo, can_review, can_view, actor_name="", actor_email=""):
    local_demo = authoring_session.local_review(local_demo)
    if not can_view:
        return
    profile = st.session_state.get("_portal_profile") or {}
    if not actor_email and str(profile.get("name", "")).casefold() == str(actor_name).casefold():
        actor_email = str(profile.get("email") or "")
    context = (str(root), pack, checkpoint, actor_id, local_demo, can_review, actor_name, actor_email)
    if st.session_state.get("review_command_context") != context:
        for key in list(st.session_state):
            if str(key).startswith(("review_command_", "review_sign_")):
                st.session_state.pop(key, None)
        st.session_state["review_command_context"] = context
    if not local_demo:
        from experiments.portal import reviewer_enrollment_page
        reviewer_enrollment_page.render(root, pack, checkpoint, actor_id, can_view=can_view)
        st.caption("Existing personal Git signatures are rechecked against the enrolled reviewer. If a signature is missing, the named reviewer signs the current review in their personal checkout; their private key stays there.")
        try:
            _prepared = review_setup.snapshot(root, pack, checkpoint)
        except (review_setup.Refused, OSError, ValueError) as error:
            st.info(str(error))
        else:
            _people = _prepared.get("reviewers", [])
            if actor_name in _people:
                with st.expander("Personal review signing command"):
                    st.code(review_setup.command(root, pack, checkpoint, actor_name, _prepared["digest"]), language=None)
            elif _people:
                st.info("Still to sign this exact review: " + ", ".join(_people) + ". Each reviewer signs their own recorded decision.")
        return
    st.write("**Development review**")
    st.caption("Confirm with your name and email for this development or demo workflow. Production approval uses the configured review service.")
    if not can_review and not actor_name:
        st.info("A named reviewer or administrator can confirm the recorded review.")
        return
    done = st.session_state.get("review_sign_done")
    cached = st.session_state.get("review_command_snapshot")
    completed_snapshot = (cached and cached.get("reviewers") and
                          set(cached["reviewers"]).issubset(cached.get("confirmed_reviewers", [])))
    if done or completed_snapshot:
        # A past success cannot hide a new review after source or approval changes.
        # Re-read the authoritative claims; never carry consent to different bytes.
        _prepare(root, pack, checkpoint)
        current = st.session_state.get("review_command_snapshot")
        if done and current and done.get("digest") == current["digest"] and done["reviewer"] in current.get("confirmed_reviewers", []):
            done["others"] = [person for person in current["reviewers"] if person not in current.get("confirmed_reviewers", [])]
            st.session_state["review_sign_done"] = done
            st.session_state.pop("review_command_snapshot", None)
        else:
            done = None
            st.session_state.pop("review_sign_basis", None)
            st.session_state.pop("review_sign_confirm", None)
            if current and current.get("reviewers") and not set(current["reviewers"]).issubset(current.get("confirmed_reviewers", [])):
                st.info("The current review is no longer confirmed. Review the current details and confirm again. Your earlier confirmation is not reused.")
    if done:
        st.success(f"Development review confirmed for {done['reviewer']}.")
        st.info(done["message"])
        if done["others"]:
            st.caption("Still to confirm: " + ", ".join(done["others"]) + ". Each person confirms their own work.")
            st.button("Review next person", key="review_command_prepare", on_click=_prepare, args=(root, pack, checkpoint))
        return
    if not st.session_state.get("review_command_snapshot") and not st.session_state.get("review_command_error"):
        _prepare(root, pack, checkpoint)
    if st.session_state.get("review_command_error"):
        st.warning(st.session_state["review_command_error"])
        st.button("Check review details again", key="review_command_prepare", on_click=_prepare, args=(root, pack, checkpoint))
        return
    snapshot = st.session_state.get("review_command_snapshot")
    if not snapshot:
        return
    confirmed_people = snapshot.get("confirmed_reviewers", [])
    people = [person for person in snapshot["reviewers"] if person not in confirmed_people]
    if snapshot["reviewers"] and not people:
        st.success("All named development reviews at this checkpoint are confirmed.")
        return
    if not can_review:
        people = [person for person in people if person.casefold() == str(actor_name).casefold()]
    if not people:
        if any(person.casefold() == str(actor_name).casefold() for person in confirmed_people):
            st.success("Your development review is already confirmed. The other named reviewer must confirm their own work.")
        else:
            st.info("No review is recorded under your name at this checkpoint." if not can_review else
                    "Complete the review details at this checkpoint first, including the responsible person's name.")
        st.button("Refresh review details", key="review_command_prepare", on_click=_prepare, args=(root, pack, checkpoint))
        return
    preferred = next((index for index, person in enumerate(people) if person.casefold() == str(actor_name).casefold()), 0)
    reviewer = people[0] if len(people) == 1 else st.selectbox("Who is confirming their own review?", people,
                                                           index=preferred, key="review_command_person")
    st.caption(f"Reviewer: {reviewer} · {review_setup.CHECKPOINTS[checkpoint]}")
    st.caption("Responsibility: " + _responsibilities(snapshot, reviewer))
    _confirm_here(root, pack, checkpoint, reviewer, snapshot, actor_id, actor_name, actor_email)
    with st.expander("Review details"):
        st.write("The primary scientific reviewer is responsible for the scientific decision. A separate independent reviewer "
                 "performs the checks required at that checkpoint. Each person confirms the work recorded under their own name.")
        st.text("\n".join(f"{claim['file']} · {claim['field']}" for claim in snapshot["claims"] if claim["who"] == reviewer))
        st.button("Refresh review details", key="review_command_prepare", on_click=_prepare, args=(root, pack, checkpoint))
