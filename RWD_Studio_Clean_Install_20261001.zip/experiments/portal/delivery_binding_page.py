"""Literal delivery bindings, impact, checked draft, then evidence."""
import streamlit as st

from experiments.portal import delivery_binding as backend
from experiments.portal import source_workspace as workspace
from experiments.portal import form_assistance as form_help

PREFIX = "source_ws_delivery_form_"


def _errors(result):
    for error in result.get("errors", []):
        st.error(error)
    return not result.get("ok")


def render(root, pack, actor_id, *, allowed_packs=None, local_demo=False, can_write=False, params=None, **_):
    read_args = dict(root=root, pack=pack, actor_id=actor_id, allowed_packs=allowed_packs)
    arguments = read_args | dict(local_demo=local_demo, can_write=can_write)
    enabled = local_demo is True and can_write is True
    params = params or {}
    selected = params.get("id") or params.get("proposal_id")
    selected_record = workspace.read(**read_args, record_id=selected) if selected else None
    if selected_record and _errors(selected_record):
        return None
    runtime_only = (bool(selected_record["record"]["payload"].get("runtime_only"))
                    if selected_record and selected_record["record"]["route"] == backend.ROUTE
                    else params.get("mode") == "runtime")
    prefix = PREFIX + "runtime_" if runtime_only else PREFIX
    description = backend.describe(**read_args, runtime_only=runtime_only)
    if _errors(description):
        return None
    st.write("Set the source schema, delivery cut and output schema supplied by the data expert before preparing source evidence or an AI draft. This form preserves the existing source roles and table stems."
             if runtime_only else "Declare where this product's source tables will be read. Ask the data expert for the schema, delivery cut and actual table stems; a plausible name does not establish that a table exists.")
    st.caption(description["notice"])
    if not description["supported"]:
        for blocker in description["blockers"]:
            st.warning(blocker)
        st.write("Take the requirements and existing delivery configuration to the data expert or Engineering. Union members, new source roles, layout changes and adapter bindings need their existing review workflow.")
        from experiments.portal.source_workspace_page import _ask
        _ask(arguments, action_id="source_delivery_unsupported", label="Review the unsupported delivery declaration",
             owner="Engineering", note=" ".join(description["blockers"]), key="source_ws_delivery_unsupported")
        if st.button("Review delivered source mappings", key=prefix + "mapping"):
            return {"route": "source_mapping", "params": {}}
        if st.button("Read the source requirements", key=prefix + "requirements"):
            return {"route": "source_requirements", "params": {}}
        return None
    if not enabled:
        st.info("Inspect the declaration here. Saving requires local editing access.")
    initial = description["values"]
    if selected and st.session_state.get(prefix + "parameter") != selected:
        saved = selected_record
        if not _errors(saved) and saved["record"]["route"] == backend.ROUTE:
            st.session_state[prefix + "id"] = selected
            st.session_state[prefix + "parameter"] = selected
            if not saved["stale"]:
                initial = saved["record"]["payload"]["values"]
                for name, value in initial.items():
                    st.session_state[prefix + "value_" + name] = value
                if not runtime_only:
                    st.session_state[prefix + "roles"] = saved["record"]["payload"].get("selected_roles", description["source_roles"])
                    st.session_state[prefix + "retained"] = saved["record"]["payload"].get("retained_unresolved_roles", [])
                st.session_state[prefix + "digest"] = description["inputs_sha256"]
    st.session_state.setdefault(prefix + "digest", description["inputs_sha256"])
    form_stale = st.session_state[prefix + "digest"] != description["inputs_sha256"]
    if form_stale:
        st.warning("The product changed while this form was open. Reload its current delivery before staging another proposal.")
        if st.button("Reload current delivery", key=prefix + "reload"):
            for key in list(st.session_state):
                if key.startswith(prefix):
                    del st.session_state[key]
            st.rerun()
    st.markdown("**1 · Set runtime locations**" if runtime_only else "**1 · Identify the delivery**")
    values = {}
    for name in (("schema", "cut", "output_schema") if runtime_only else ("schema", "cut")):
        item = description["fields"][name]
        values[name] = form_help.field(st.text_input, item["label"], "" if workspace._stem_unstated(initial[name]) else initial[name], binding=description["inputs_sha256"],
                                    key=prefix + "value_" + name, disabled=not enabled,
                                    help=({"schema": "Schema or catalog.schema containing this delivery, for example research_source. Use the delivered value, not a file path.",
                                           "cut": "The exact suffix/token identifying this delivery, for example 2026m06. It is not the specification version or an invented date.",
                                           "output_schema": "Schema or catalog.schema where the runtime will write outputs, for example research_outputs. Saving this name does not create a schema or grant access."}[name]))
    st.caption("Active format: " + str(description["data_format"]) + ". Existing table-name layout: " + description["layout"])
    selected_roles = None
    retained = []
    if runtime_only:
        st.markdown("**2 · Review preserved source declarations**")
        st.dataframe([{"Role": role, "Unchanged table stem": stem,
                       "Status": "unresolved placeholder" if role in description["unresolved_source_roles"] else "declared; availability not checked"}
                      for role, stem in sorted(description["source_stems"].items())], hide_index=True, width="stretch")
        if description["unresolved_source_roles"]:
            st.warning("Source table placeholders remain unresolved: " + ", ".join(description["unresolved_source_roles"]) + ". Saving runtime locations does not resolve or approve them.")
    else:
        st.markdown("**2 · Choose the sources this product will use**")
        selected_roles = st.multiselect("Source roles to include", description["source_roles"],
            default=description["source_roles"], key=prefix + "roles",
            disabled=not enabled or form_stale or bool(description["role_selection_blockers"]),
            help="Every current role starts selected. Remove one only after reviewing its consumers and absence behavior below. A required source cannot be removed while its consumers remain unresolved.")
        for blocker in description["role_selection_blockers"]:
            st.caption(blocker)
        removed = sorted(set(description["source_roles"]) - set(selected_roles))
        if removed:
            st.warning("Proposed source removals: " + ", ".join(removed) + ". Validators must confirm that this adds no unresolved source requirements; this is not an approval of missing data.")
        with st.expander("Review what these sources support", expanded=bool(removed)):
            st.table([{"Role": row["role"], "Include": row["role"] in selected_roles,
                       "Required columns": workspace._column_words(row.get("required_columns", [])),
                       "Read by": ", ".join(row.get("read_by_blocks", [])),
                       "Required by variables": ", ".join(row.get("required_by_variables", [])) or "Not recorded",
                       "When absent": workspace._dashless(row.get("when_absent", ""))}
                      for row in description["rows"] if row["role"] in description["source_roles"]])
            st.caption("These are declared consumers. An incomplete scientific contract may have additional requirements; blank cells do not prove a source is unnecessary.")
        st.write("Enter the part used as the table stem by the displayed layout. For example, under {schema}.{stem}_{refresh}, a delivered table research_source.t_enh_demo_2026m06 has stem t_enh_demo. Retain the vendor's spelling and do not append the cut twice.")
        retain_options = sorted(set(description["unresolved_source_roles"]) & set(selected_roles))
        if prefix + "retained" in st.session_state:
            # Removing a role also removes it from the possible retention choices;
            # no newly selected role is ever retained automatically.
            st.session_state[prefix + "retained"] = [role for role in st.session_state[prefix + "retained"]
                                                     if role in retain_options]
        if retain_options:
            retained = st.multiselect("Keep existing placeholders unresolved for now", retain_options,
                default=[], key=prefix + "retained", disabled=not enabled or form_stale,
                help="Choose only roles whose table stem is still unknown. Each selected role keeps its exact current placeholder and remains declared. This saves a partial draft, not source availability or approval; a blank table field alone does not retain anything.")
        if retained:
            st.warning("Partial declaration: retained placeholders remain unresolved for " + ", ".join(retained) + ". These roles are still declared and all source requirements and reviews still apply.")
        st.caption("Other table stems, including existing template names, are declarations only; table availability has not been checked.")
    for name, item in description["fields"].items():
        if not name.startswith("source:"):
            continue
        if selected_roles is not None and name.split(":", 1)[1] not in selected_roles:
            continue
        if name.split(":", 1)[1] in retained:
            values[name] = item["value"]
            st.text_input(item["label"] + " · unresolved, unchanged", value=item["value"],
                          key=prefix + "retained_value_" + name, disabled=True)
            continue
        values[name] = form_help.field(st.text_input, item["label"], "" if workspace._stem_unstated(initial[name]) else initial[name], binding=description["inputs_sha256"],
                                    key=prefix + "value_" + name, disabled=not enabled,
                                    help="This is the existing logical role's table stem. The current format and naming layout are preserved. Required columns and consumers appear in the review below.")
    with st.expander("A source role or delivery layout needs a different change"):
        st.write("If a declared table is not delivered, do not point the role at an unrelated table. The selector can remove existing declarations only when no new required-source finding results. New roles, accepting an unmet requirement, layout changes and combined schemas need scientific and Engineering review.")
        from experiments.portal.source_workspace_page import _ask
        _ask(arguments, action_id="source_delivery_scope", label="Review a source-role or delivery-layout change",
             owner="Engineering", note="Please review the required source-role or delivery-layout change for this product. State the affected roles, observed delivery and unresolved scientific impact before implementation.",
             key="source_ws_delivery_scope")
    if st.button("Preview runtime changes and run validators" if runtime_only else "Stage delivery diff and run validators", key=prefix + "stage", disabled=not enabled or form_stale):
        with st.spinner("Checking the proposed delivery against the current configuration and scientific records…"):
            result = backend.stage(**arguments, values=values, expected_digest=st.session_state[prefix + "digest"], runtime_only=runtime_only,
                                   selected_roles=sorted(selected_roles) if selected_roles is not None else None,
                                   retained_unresolved_roles=sorted(retained))
        if not _errors(result):
            st.session_state[prefix + "id"] = result["record"]["id"]
    record_id = st.session_state.get(prefix + "id")
    if record_id:
        saved = workspace.read(**read_args, record_id=record_id)
        if _errors(saved):
            return None
        record, payload = saved["record"], saved["record"]["payload"]
        st.markdown("**3 · Review the exact change and remaining findings**")
        st.write(payload["summary"])
        if payload.get("retained_unresolved_roles"):
            st.warning("Unresolved placeholders retained in this partial draft: " + ", ".join(payload["retained_unresolved_roles"]) + ". Saving does not resolve their table locations or availability.")
        for file in payload["files"]:
            st.code(file["diff"], language="diff")
        st.dataframe([{"Role": item["role"], "Current table": item["before"], "Proposed table": item["after"],
                       "Declaration status": item.get("declaration_status", "declared; availability not checked"),
                       "Engine reads": "yes" if item["engine_reads"] else "no declared read",
                       "Required columns": workspace._column_words(item["required_columns"]),
                       "Expected grain": "not declared yet" if item["expected_grain"] in ("", "(not declared)") else item["expected_grain"],
                       "When absent": workspace._dashless(item["when_absent"]),
                       "Read by": ", ".join(item["read_by_blocks"]),
                       "Required by": ", ".join(item["required_by_variables"])} for item in payload["impact"]],
                     hide_index=True, width="stretch")
        if not payload["consumer_links_complete"]:
            st.info("Consumer links are incomplete or absent in the current scientific contract. Empty cells do not establish that there is no impact.")
        st.caption("Impact lists declared links only. A missing or incomplete scientific record may hide additional consumers.")
        st.write("Changing the delivery requires fresh source evidence and runtime checks for every affected role. Study exclusions and scientific definitions are separate records; no scientific meaning is inferred from a table name.")
        if not payload["all_checks_passed"]:
            st.warning("The full configuration/scientific checks have not passed. Identical pre-existing findings remain unresolved; saving only the delivery declaration does not clear them.")
        for check in payload["checks"]:
            with st.expander(check["validator"] + (": passed" if check["passed"] else ": unresolved findings")):
                for error in check["errors"]:
                    st.write(error)
                if check.get("note"):
                    st.caption(check["note"])
        for error in payload["new_errors"]:
            st.error("New or unreadable validator finding: " + error)
        stale = (saved["stale"] or payload["values"] != values
                 or payload.get("retained_unresolved_roles", []) != sorted(retained))
        if stale:
            st.warning("This preview no longer matches the current form or product. Stage and review the current answers before saving.")
        if record["state"] == "delivery_saved_pending_review":
            st.success("Runtime locations saved. Source placeholders and reviews remain pending." if runtime_only
                       else "Partial delivery saved. Retained placeholders, source availability and reviews remain unresolved." if payload.get("retained_unresolved_roles")
                       else "Draft delivery saved. Source and scientific review remain pending.")
            if st.button("Prepare evidence for this delivery", key=prefix + "evidence"):
                return {"route": "source_evidence", "params": {}}
        else:
            confirmed = st.checkbox("I reviewed the runtime changes and unresolved source and scientific findings and want to save these draft locations." if runtime_only
                                    else "I reviewed this delivery diff and its unresolved findings and want to save the draft declaration.",
                                    key=prefix + "confirm_" + record_id, disabled=not enabled or stale or not payload["can_save"])
            if st.button("Save reviewed runtime locations" if runtime_only else "Save reviewed delivery draft", key=prefix + "save", disabled=not enabled or stale or not payload["can_save"] or not confirmed):
                with st.spinner("Rechecking the reviewed diff before saving this draft…"):
                    result = backend.save(**arguments, record_id=record_id, confirmed=confirmed)
                if not _errors(result):
                    st.session_state[prefix + "digest"] = result["record"]["inputs_sha256"]
                    if result.get("warning"):
                        st.session_state["source_ws_warning"] = result["warning"]
                        return {"route": "source_evidence", "params": {}, "changed": True}
                    return {"route": backend.ROUTE, "params": {"id": record_id} | ({"mode": "runtime"} if runtime_only else {}), "changed": True}
    return None
