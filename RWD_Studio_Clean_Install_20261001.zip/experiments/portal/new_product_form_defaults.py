"""Visible setup suggestions; explicit researcher edits always take precedence."""
from datetime import date
import os
import re

SUGGESTED_SETUP_FIELDS = {"np_slug", "np_code", "np_tclass", "np_narrow", "np_cond"}
DEFAULT_CONTROLS = ("_np_catalogue_family", "_np_slug_user_owned", "_np_code_user_owned", "_np_identifier_input", "_np_condition_context")


def validate_provenance(value):
    """A bounded suggestion history, never a declaration or permission."""
    required = {"generated", "family", "slug_owned", "code_owned"}
    if (not isinstance(value, dict) or not required <= set(value) or not set(value) <= required | {"identifier_input", "condition"}
            or not isinstance(value["generated"], dict)
            or not set(value["generated"]) <= SUGGESTED_SETUP_FIELDS
            or any(item is not None and (not isinstance(item, str) or len(item) > 4000 or "\0" in item)
                   for item in value["generated"].values())
            or not isinstance(value["family"], str) or len(value["family"]) > 4000 or "\0" in value["family"]
            or type(value["slug_owned"]) is not bool or type(value["code_owned"]) is not bool
            or ("identifier_input" in value and (not isinstance(value["identifier_input"], str)
                or len(value["identifier_input"]) > 4000 or "\0" in value["identifier_input"]))
            or ("condition" in value and value["condition"] not in (None, "oncology", "non_oncology"))):
        raise ValueError("The saved setup suggestion history is malformed.")
    return {**value, "generated": dict(value["generated"])}


def capture_provenance(state, actor):
    if state.get("_np_defaults_actor") != actor:
        return None
    return validate_provenance({
        "generated": {key: value for key, value in (state.get("_np_generated_defaults") or {}).items()
                      if key in SUGGESTED_SETUP_FIELDS},
        "family": state.get("_np_catalogue_family") or "",
        "slug_owned": bool(state.get("_np_slug_user_owned")),
        "code_owned": bool(state.get("_np_code_user_owned")),
        **({"identifier_input": state["_np_identifier_input"]} if "_np_identifier_input" in state else {}),
        **({"condition": state["_np_condition_context"]} if "_np_condition_context" in state else {}),
    })


def restore_provenance(state, actor, value):
    # Missing history in an older draft is ambiguous: keep its fields as edits.
    value = validate_provenance(value) if value is not None else {
        "generated": {key: None for key in SUGGESTED_SETUP_FIELDS if key in state}, "family": "",
        "slug_owned": "np_slug" in state, "code_owned": "np_code" in state}
    bind(state, actor)
    generated = {key: item for key, item in (state.get("_np_generated_defaults") or {}).items()
                 if key not in SUGGESTED_SETUP_FIELDS}
    state["_np_generated_defaults"] = {**generated, **value["generated"]}
    state["_np_catalogue_family"] = value["family"]
    state["_np_slug_user_owned"] = value["slug_owned"]
    state["_np_code_user_owned"] = value["code_owned"]
    state.pop("_np_identifier_input", None)
    if "identifier_input" in value:
        state["_np_identifier_input"] = value["identifier_input"]
    state["_np_condition_context"] = value.get("condition", state.get("np_cond"))


def discover_workbooks(root):
    """Browse authoring inputs without walking generated installs or runtimes."""
    ignored = {".git", ".history", "__pycache__", "node_modules", "venv", "wheelvenv",
               ".pytest_cache", ".mypy_cache", ".ruff_cache", ".portal-drafts", ".portal-uploads",
               "tmp", "dist", "build", "outputs", "spark-warehouse", "_rehearsal"}
    found = []
    for directory, children, files in os.walk(root, followlinks=False):
        children[:] = [name for name in children
                       if name not in ignored and not name.startswith(".venv")
                       and not os.path.islink(os.path.join(directory, name))
                       and not os.path.isfile(os.path.join(directory, name, "pyvenv.cfg"))]
        for name in files:
            if name.lower().endswith((".xlsx", ".xlsm")):
                found.append(os.path.relpath(os.path.join(directory, name), root).replace(os.sep, "/"))
    return sorted(found)


def workbook_is_reference(path):
    """Group known repository evidence folders; this says nothing about approval."""
    parts = str(path or "").replace("\\", "/").casefold().split("/")
    evidence = {"fixtures", "sandbox", "examples", "tests", "test", "tmp", "dist", "build", "uat-evidence"}
    return bool(evidence.intersection(parts[:-1])) or any(
        parts[index:index + 2] == ["docs", "research"] for index in range(len(parts) - 1))


def workbook_picker_paths(paths, *, include_references=False, selected=""):
    """Filter browsing without replacing a previously selected workbook.

    The caller filters access before discovery and rechecks the returned selection.
    Keeping a missing selection lets Preview explain it instead of choosing a new file.
    """
    visible = {str(path) for path in paths if include_references or not workbook_is_reference(path)}
    if str(selected).lower().endswith((".xlsx", ".xlsm")):
        visible.add(str(selected))
    return sorted(visible)


def workbook_picker_label(path):
    return f"Test/reference materials · {path}" if workbook_is_reference(path) else path


def identifier(value):
    value = re.sub(r"_+", "_", re.sub(r"[^a-z0-9]+", "_", str(value or "").strip().lower())).strip("_")
    return "product_" + value if value and value[0].isdigit() else value


def _suggest(state, key, value):
    generated = dict(state.get("_np_generated_defaults") or {})
    current = state.get(key)
    # A cleared or manually changed suggestion is an edit, including an empty value.
    editable = key not in state or (current == generated.get(key) if key in generated else not current)
    if editable:
        if current != value:
            state[key] = value
        generated[key] = value
        state["_np_generated_defaults"] = generated
    return state.get(key)


def bind(state, actor):
    """Keep automatic-following metadata private to the selected profile."""
    previous = state.get("_np_defaults_actor")
    if previous == actor:
        return
    owners = dict(state.get("_np_generated_by_actor") or {})
    if previous is not None:
        owners[previous] = dict(state.get("_np_generated_defaults") or {})
    controls = dict(state.get("_np_default_controls_by_actor") or {})
    if previous is not None:
        controls[previous] = {key: state[key] for key in DEFAULT_CONTROLS if key in state}
    for key in DEFAULT_CONTROLS:
        state.pop(key, None)
    state.update(controls.get(actor) or {})
    state["_np_generated_defaults"] = dict(owners.get(actor) or {})
    state["_np_generated_by_actor"] = owners
    state["_np_default_controls_by_actor"] = controls
    state["_np_defaults_actor"] = actor


def identifiers(state, *, name="", previous_slug=""):
    generated = dict(state.get("_np_generated_defaults") or {})
    before_slug = str(state.get("np_slug") or "").strip()
    before_code = str(state.get("np_code") or "").strip()
    generated_slug = str(generated.get("np_slug") or "").strip()
    generated_code = str(generated.get("np_code") or "").strip()
    # A code follows the generated slug while the researcher is still using
    # the name suggestion.  Once they type a slug, keep the registry code
    # stable until they edit it explicitly; changing tumour family must never
    # silently rewrite an identifier they chose.
    slug_is_generated = not before_slug or before_slug == generated_slug
    if before_slug and generated_slug and before_slug != generated_slug:
        state["_np_slug_user_owned"] = True
    if before_code and generated_code and before_code != generated_code:
        state["_np_code_user_owned"] = True
    source = previous_slug or identifier(name)
    # A tumour-derived suggestion remains current on unrelated widget reruns.
    # Only an actual name/previous-cut change proposes a new identifier.
    if state.get("_np_identifier_input") != source or "np_slug" not in state:
        _suggest(state, "np_slug", source)
    state["_np_identifier_input"] = source
    if not state.get("_np_slug_user_owned") and slug_is_generated:
        _suggest(state, "np_code", identifier(state.get("np_slug")))
    elif "np_code" not in state:
        state["np_code"] = identifier(state.get("np_slug"))


def catalogue(root, state, family):
    # Keep family-dependent suggestions coherent when the person changes the
    # tumour in the same draft.  Streamlit reruns with the new selectbox value,
    # so remember the family used for the previous suggestion pass and move
    # only values that were still generated from that family.  A researcher
    # who typed a different slug/code keeps that explicit edit.
    previous_family = state.get("_np_catalogue_family")
    previous_generated = dict(state.get("_np_generated_defaults") or {})
    if family and previous_family and family != previous_family:
        version = str(state.get("np_ver") or "").strip()
        replacement_slug = f"{family}_{version or 'program'}"
        old_slug = str(state.get("np_slug") or "").strip()
        old_code = str(state.get("np_code") or "").strip()
        generated_slug = str(previous_generated.get("np_slug") or "").strip()
        generated_code = str(previous_generated.get("np_code") or "").strip()
        # Only values that still equal the exact suggestion recorded on the
        # previous pass may move with the tumour.  A prefix is not proof that
        # a person accepted the suggestion: `gist_my_study` is a valid custom
        # slug and must survive a switch to mCRC.
        slug_is_generated = old_slug in {generated_slug, previous_family}
        # A short code equal to the family itself may be an intentional
        # registry identity (the original form used that value), so preserve
        # it.  Longer generated values such as ``gist_program`` still follow
        # a family switch when the researcher did not edit the code field.
        code_is_generated = old_code in {generated_code, generated_slug, old_slug}
        if old_code == previous_family and generated_code == previous_family:
            code_is_generated = False
        # `identifiers()` records ownership as soon as the researcher changes
        # the suggestion.  Keep that explicit edit authoritative even if an
        # older saved draft did not retain the generated-default metadata.
        if state.get("_np_slug_user_owned"):
            slug_is_generated = False
            code_is_generated = False
        if slug_is_generated:
            state["np_slug"] = replacement_slug
            generated_slug = replacement_slug
        if code_is_generated and not state.get("_np_code_user_owned"):
            state["np_code"] = replacement_slug
            generated_code = replacement_slug
        if slug_is_generated or code_is_generated:
            generated = dict(state.get("_np_generated_defaults") or {})
            if slug_is_generated:
                generated["np_slug"] = generated_slug
            if code_is_generated:
                generated["np_code"] = generated_code
            state["_np_generated_defaults"] = generated
    declared = {}
    if family:
        from rwd_tools import new_product
        declared = new_product.catalogue_choices(root, family)
    for key, value in (("np_tclass", declared.get("tumor_class")),
                       ("np_narrow", declared.get("narrow")),
                       ("np_cond", declared.get("condition_class", "oncology") if declared else None)):
        # Unknown families never acquire guessed classifications; explicit
        # overrides remain drafts when a family changes.
        _suggest(state, key, value)
    state["_np_catalogue_family"] = family or ""
    return declared


def condition(state, condition_class):
    """Reset only classifications and generated family suggestions when the domain changes."""
    previous = state.get("_np_condition_context")
    stale_oncology = condition_class == "non_oncology" and state.get("np_tclass") in {"solid", "heme"}
    changed = previous in {"oncology", "non_oncology"} and previous != condition_class
    if changed or stale_oncology:
        generated = dict(state.get("_np_generated_defaults") or {})
        if state.get("_np_catalogue_family"):
            for field, ownership in (("np_slug", "_np_slug_user_owned"), ("np_code", "_np_code_user_owned")):
                if not state.get(ownership) and state.get(field) == generated.get(field):
                    state.pop(field, None)
                    generated.pop(field, None)
        state["_np_catalogue_family"] = ""
        state.pop("_np_identifier_input", None)
        for field in ("np_family", "np_tclass", "np_narrow", "np_area"):
            state[field] = None
            generated.pop(field, None)
        state["_np_generated_defaults"] = generated
        state.pop("np_previewed", None)
    if condition_class == "non_oncology":
        # These describe absence of oncology classification, not clinical rules.
        state.update(np_tclass="not_applicable", np_narrow="general", np_area="conditions")
    elif state.get("np_area") not in {"oncology", "heme"}:
        state["np_area"] = "oncology"
    state["_np_condition_context"] = condition_class
    return changed or stale_oncology


def attribution(state, actor, *, today=None):
    _suggest(state, "np_by", str(actor.get("name") or "").strip())
    _suggest(state, "np_on", (today or date.today()).isoformat())
