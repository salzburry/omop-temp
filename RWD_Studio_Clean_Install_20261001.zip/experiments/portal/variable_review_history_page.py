"""On-demand, verified review history; ordinary editor reruns stay lightweight."""
import hashlib
import json
import math
import streamlit as st
from experiments.portal import variable_review_workflow as workflow


def render(root, pack, actor_id, report, *, allowed_packs, local_demo, can_write):
    count = report.get("history_count", len(report.get("history", [])))
    key = "variable_review_history_" + hashlib.sha256(json.dumps(
        [str(root), pack, actor_id, allowed_packs, report["state_digest"]], sort_keys=True).encode()).hexdigest()[:16]
    with st.expander("Review history and download"):
        st.caption(f"{count} recorded events. Older events are archived automatically; archiving preserves every event and does not approve this product.")
        if st.button("Refresh saved information from disk", key=key + "refresh"):
            from pathlib import Path
            from experiments.portal import variable_review_snapshot
            variable_review_snapshot.clear(Path(root).resolve() / pack)
            st.rerun()
        if not count:
            return False
        page = st.number_input("History page", min_value=1, max_value=max(1, math.ceil(count / 50)), value=1, step=1, key=key + "page")
        if st.button("Load and verify history page", key=key + "load"):
            st.session_state[key + "audit"] = workflow.read_history(root, pack, actor_id,
                allowed_packs=allowed_packs, offset=(page - 1) * 50, limit=50)
        audit = st.session_state.get(key + "audit")
        if audit:
            if not audit.get("ok"):
                st.error(" ".join(audit.get("errors", [])))
            else:
                st.caption("Archive hashes and ordering were checked when this page was loaded.")
                st.json(audit["history"], expanded=False)
        if st.button("Prepare complete history download", key=key + "prepare"):
            complete = workflow.read_history(root, pack, actor_id, allowed_packs=allowed_packs)
            if not complete.get("ok"):
                st.error(" ".join(complete.get("errors", [])))
            else:
                st.session_state[key + "download"] = json.dumps({"version": 1, "pack": pack,
                    "state_digest": complete["state_digest"], "events": complete["history"]},
                    ensure_ascii=False, sort_keys=True, indent=2).encode("utf-8")
        if key + "download" in st.session_state:
            st.download_button("Download complete review history", st.session_state[key + "download"],
                file_name="review-history.json", mime="application/json", key=key + "download_button", on_click="ignore")
        if st.button("Archive older events now", key=key + "archive",
                disabled=not (local_demo and can_write and len(report.get("history", [])) > 50)):
            result = workflow.archive_history(root, pack, actor_id,
                expected_input_digest=report["input_digest"], expected_state_digest=report["state_digest"],
                allowed_packs=allowed_packs, local_demo=local_demo, can_write=can_write)
            if result.get("ok"):
                st.session_state["variable_review_notice"] = result["message"]
                return result.get("changed", False)
            st.error(" ".join(result.get("errors", [])))
    return False
