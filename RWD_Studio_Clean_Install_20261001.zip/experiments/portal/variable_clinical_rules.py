"""Reviewed clinical choices lowered into the existing native clinical stages.

This is a bounded compiler, not an interpreter for scientific prose. It reads
the supplied configuration (whose pack accessor may load YAML), never source
data or writes. Source columns have one authority: the row's source mapping;
semantic roles here refer to its logical column keys.
"""
from __future__ import annotations

from copy import deepcopy
from engine.record_windows import read_window, window_days, window_fields
import json
import math
import re

from experiments.portal.variable_review_consistency import canonical_type
from experiments.portal import variable_native_instruments as instruments

OPERATORS = {
    "categorical": "Categorical characteristic",
    "panel_categories": "Named assessment categories",
    "panel_bands": "Named measurement bands",
    "lab_value": "Numeric laboratory measurement",
    "baseline_ecog": "Baseline ECOG",
    "custom": "Custom rule — implementation needed",
}
FAMILIES = {"categorical": "Categorical characteristic", "biomarker": "Biomarker",
            "laboratory": "Laboratory", "response": "Recorded response",
            "performance_status": "Performance status", "custom": "Custom"}
_FAMILY = {"categorical": {"categorical"},
           "panel_categories": {"biomarker", "laboratory", "response"},
           "panel_bands": {"biomarker", "laboratory", "response"},
           "lab_value": {"laboratory"}, "baseline_ecog": {"performance_status"},
           "custom": {"custom"}}
_PANELS = {"biomarker": "biomarkers", "laboratory": "labs", "response": "response"}
_ID = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")
_COMMON = {"version", "family", "operator", "output_stem", "result", "column_roles", "window_days", "window"}
_SELECT = {"pick", "tie_break", "same_date_conflict", "priority"}
_ALLOWED = {
    "categorical": _COMMON | _SELECT | {"groups"},
    "panel_categories": _COMMON | _SELECT | {"groups", "match", "match_any", "units", "emit_date", "conflict_rules"},
    "panel_bands": _COMMON | _SELECT | {"bands", "match", "match_any", "units", "emit_date", "value_cast"},
    "lab_value": _COMMON | {"match", "units", "value_cast", "value_tiebreak", "positive_only",
                            "present_label", "missing_label", "unknown_label"},
    "baseline_ecog": _COMMON | {"tie_break", "equidistant", "value_codes", "missing_code", "missing_label"},
    "custom": _COMMON | {"custom_notes"},
    "": _COMMON | {"custom_notes"},
}
_FIELDS = set().union(*_ALLOWED.values())
_MATCHERS = {"from_prefixes", "from_equals_ci", "from_startswith_ci", "from_contains_ci"}
_BOUNDS = {"min", "min_excl", "max", "max_excl"}
_EMPTY = (None, "", [], {})
_CAST_TYPES = {"double": "double", "int": "integer", "bigint": "long"}


def selection(row):
    return deepcopy(row.get("clinical_rule") or (row.get("values") or {}).get("clinical_rule") or {})


def assistant_contract(current):
    """Bounded model guidance for the selected editor; validation stays server-side."""
    from experiments.portal import variable_review_family as families

    if not isinstance(current, dict) or len(current) != 1:
        raise ValueError("Choose one calculation before asking for calculation suggestions.")
    kind = next(iter(current))
    value = current[kind]
    contract = {"envelope": kind, "mode": "complete replacement of this calculation only",
                "review": "Draft suggestion only. Preserve supplied review identity/date exactly. Source mapping, saving and approval remain separate.",
                "unknown": "Ask a question instead of inventing missing scientific choices, source names or instrument citations."}
    if kind == "family":
        if not isinstance(value, dict) or value.get("name") != families.NAME:
            raise ValueError("Choose the treatment-line family first.")
        contract.update({"allowed": sorted(families.FIELDS), "name": families.NAME,
                         "value_shape": {"family": {"name": "treatment_line", "line_number": "integer", "attribute": "offered attribute", "numbering": "offered numbering"}},
                         "line_number": "positive integer", "attribute": list(families.ATTRIBUTES.values()),
                         "numbering": list(families.NUMBERING.values()),
                         "required": "name, line_number, attribute, numbering; diagnosis also requires relationship, window and tie-break; custom requires custom_attribute.",
                         "capability": "Diagnosis and custom attributes can be drafted but still require an implementation handoff. Regimen/start_date/delivered_end_date/last_activity_date already have engine support; their source and product settings still need review."})
        return contract
    if kind != "clinical_rule" or not isinstance(value, dict):
        raise ValueError("Choose a supported clinical calculation first.")
    op = value.get("operator")
    if op not in {*OPERATORS, *instruments.SPECS} or op == "custom":
        raise ValueError("Choose a supported calculation template; free text does not define an executable calculation.")
    contract.update({"operator": op, "family": value.get("family"), "version": 1,
                     "output_stem": "letter-led identifier; selected result determines emitted column and data type",
                     "locked": "Keep operator and family. Keep existing nonblank column_roles and native.source; source mapping is edited separately."})
    if instruments.is_native(value):
        contract["allowed"] = ["version", "operator", "family", "output_stem", "result", "native"]
        contract["result"] = [r[0] for r in instruments.RESULTS[op]]
        contract["native_fields"] = sorted(instruments.FIELDS[op])
        contract["native_common"] = "native.name equals output_stem; source/columns are logical identifiers, not SQL; retain existing source/input column references. clinically_reviewed_by and review_date must remain exactly as supplied (including absence). Instrument and citation must come from evidence."
        if op in {"value_in_window", "time_to_event"}:
            from engine.config_schema import schema
            from copy import deepcopy
            defs = schema()["$defs"]
            key = "recordValue" if op == "value_in_window" else "timeToEvent"
            contract["native_schema"] = {"$ref": "#/$defs/" + key, "$defs": {
                name: deepcopy(defs[name]) for name in ("recordValue", "timeToEvent", "eventCandidate",
                "observationValue", "observationFilter", "observationDateBasis", "anchoredRecordWindow")}}
            contract["required"] = "Complete native_schema. Retain declared scientific choices; leave unsupported or unstated choices for the reviewer. Anchors name actual assembled DATE columns, not guessed labels."
        elif op == "risk_score":
            contract["tables"] = {"components": "[{name,column,bands OR values}]; bands rows: min/min_excl/max/max_excl or when=fallthrough (not missing), points integer; values rows: from_equals_ci/from_prefixes string lists or when=missing/fallthrough, points integer",
                                  "categories": "[{min/min_excl/max/max_excl,label,code integer}]; cover all attainable scores without overlap",
                                  "incomplete": "{label,code integer}; points and total must fit int32"}
        else:
            module = instruments.module(op)
            enum_fields = {"serial_marker": {"reference": "REFERENCES", "direction": "DIRECTIONS", "event_date": "EVENT_DATES", "same_day": "SAME_DAY", "series_scope": "SERIES_SCOPES"},
                           "rt_course": {"mode": "MODES"}, "dose_exposure": {"reduce": "REDUCES"},
                           "modality_relation": {"relation": "RELATIONS"}}[op]
            contract["choices"] = {field: list(getattr(module, name)) for field, name in enum_fields.items()}
            contract["required"] = {
                "serial_marker": "source, marker_column, date_column, series_scope, reference, direction, event_date, same_day, positive threshold_pct and/or threshold_abs, positive confirm_after_days; instrument and citation",
                "rt_course": "source, mode; abstracted: start_column,end_column; sessionised: date_column,positive gap_days,instrument,citation",
                "dose_exposure": "source,drug_column,dose_column,unit_column,date_column,drugs string list,unit,window_days_before,window_days_after,reduce",
                "modality_relation": "relation,a_start_column,b_start_column; optional a_end_column,b_end_column; overlaps_within and starts_after_within require nonnegative window_days; precedes takes no window_days"}[op]
        return contract
    contract["allowed"] = sorted(_ALLOWED[op])
    contract["window_days"] = "[integer lower,integer upper] inclusive relative to cohort index; null only for deliberately unbounded ends; ECOG both finite; categorical at least one finite"
    contract["window"] = "Alternative to window_days (never supply both): {anchor: index_date, start: integer or null, end: integer or null, unit: day, include_start: boolean, include_end: boolean}. Each variable owns its window. Do not infer missing boundaries or convert calendar months to days."
    contract["column_roles"] = "{value,date,analyte,unit}: existing logical source-column keys; mapping to actual data is reviewed separately"
    contract["result"] = {"categorical": ["label", "code"], "panel_categories": ["label", "code", "date"], "panel_bands": ["label", "code", "date"], "lab_value": ["label", "value", "date"], "baseline_ecog": ["label", "code"]}[op]
    if op in {"categorical", "panel_categories", "panel_bands"}:
        contract["selection"] = {"pick": ["nearest", "earliest", "latest", "priority"], "tie_break": ["prior", "later"],
                                 "same_date_conflict": ["deterministic", "refuse", "priority"] + (["resolve"] if op == "panel_categories" else []),
                                 "priority": "ordered list of every group label only when priority is selected"}
        contract["groups" if op != "panel_bands" else "bands"] = (
            "Rows have label and unique int32 code. Observed groups have nonempty from_equals_ci/from_prefixes/from_startswith_ci/from_contains_ci string lists; include when=missing and when=fallthrough rows."
            if op != "panel_bands" else "Rows have label,unique int32 code and finite min/min_excl/max/max_excl boundaries; no overlaps; include when=fallthrough row.")
    if op.startswith("panel_"):
        contract["panel"] = "match string OR match_any string list for delivered analyte; emit_date boolean; selected date requires emit_date=true"
    if op == "panel_categories":
        contract["conflict_rules"] = "Only for same_date_conflict=resolve and pick=nearest: [{between:[two distinct observed labels],resolve:one declared label}]. Supply all required pairs."
    if op in {"panel_bands", "lab_value"}:
        contract["measurement"] = "units nonempty string list; value_cast double/int/bigint; no implied unit conversion"
    if op == "lab_value":
        contract["laboratory"] = "match analyte string, value_tiebreak highest/lowest, positive_only boolean, distinct present_label,missing_label,optional unknown_label"
    if op == "baseline_ecog":
        contract["ecog"] = "output_stem=ecog; tie_break earliest_date/latest_date; equidistant worst_value/date; worst_value requires earliest_date; value_codes maps supplied grade strings plus Unknown to unique int32 codes; missing_label distinct, missing_code integer"
    return contract


def validate_assistant_update(proposed, *, current):
    """Validate a complete atomic draft, without supplying approvals or bindings."""
    contract = assistant_contract(current)
    kind = contract["envelope"]
    if not isinstance(proposed, dict) or set(proposed) != {kind} or not isinstance(proposed[kind], dict) or not proposed[kind]:
        raise ValueError("Suggest one complete calculation object; partial fields and clearing a calculation are not supported.")
    def plain(value, depth=0):
        if depth > 12:
            raise ValueError("The calculation suggestion is nested too deeply.")
        if isinstance(value, dict):
            if any(type(key) is not str for key in value):
                raise ValueError("Calculation field names must be text.")
            for child in value.values(): plain(child, depth + 1)
        elif isinstance(value, list):
            if len(value) > 500: raise ValueError("A calculation table exceeds 500 rows.")
            for child in value: plain(child, depth + 1)
        elif value is not None and type(value) not in (str, int, float, bool):
            raise ValueError("Calculation suggestions must contain plain JSON values.")
    plain(proposed)
    try:
        if len(json.dumps(proposed, allow_nan=False).encode("utf-8")) > 24000:
            raise ValueError("The calculation suggestion exceeds 24000 bytes.")
    except (TypeError, ValueError, RecursionError) as error:
        raise ValueError("Use a bounded calculation with finite JSON values.") from error
    value, previous = proposed[kind], current[kind]
    if kind == "family":
        from experiments.portal import variable_review_family as families
        checked = families.validate(value)
        errors = families.issues({"family": checked})
    else:
        if value.get("operator") != previous.get("operator") or value.get("family") != previous.get("family"):
            raise ValueError("The suggestion must use the calculation template currently selected.")
        checked = validate(value)
        if checked != value:
            raise ValueError("The suggestion includes stale or unread calculation fields; send only this template's fields.")
        for role, column in (previous.get("column_roles") or {}).items():
            if column and (value.get("column_roles") or {}).get(role) != column:
                raise ValueError("Existing source-column roles must be preserved; edit source mapping separately.")
        if instruments.is_native(checked):
            before, after = previous.get("native") or {}, checked.get("native") or {}
            for field in ("clinically_reviewed_by", "review_date"):
                if (field in before) != (field in after) or before.get(field) != after.get(field):
                    raise ValueError("AI suggestions cannot add, remove or change reviewer identity or review date.")
            if before.get("source") and after.get("source") != before["source"]:
                raise ValueError("Keep the selected source; source mapping is reviewed separately.")
            if checked["operator"] in {"value_in_window", "time_to_event"}:
                def mapped_columns(item, path=()):
                    result = {}
                    if isinstance(item, dict):
                        for k, v in item.items():
                            if k in {"column", "columns", "unit_column"} and v:
                                result[path + (k,)] = v
                            else:
                                result.update(mapped_columns(v, path + (k,)))
                    elif isinstance(item, list):
                        for index, entry in enumerate(item):
                            key = entry.get("name", index) if isinstance(entry, dict) else index
                            result.update(mapped_columns(entry, path + (key,)))
                    return result
                after_columns = mapped_columns(after)
                if any(after_columns.get(path) != column for path, column in mapped_columns(before).items()):
                    raise ValueError("Keep existing input-column references; edit source mapping separately.")
            for field, column in before.items():
                if field.endswith("_column") and column and after.get(field) != column:
                    raise ValueError("Keep existing input-column references; edit source mapping separately.")
            previous_components = {c.get("name"): c.get("column") for c in before.get("components") or [] if isinstance(c, dict)}
            proposed_components = {c.get("name"): c.get("column") for c in after.get("components") or []}
            for name, column in previous_components.items():
                if column and proposed_components.get(name) != column:
                    raise ValueError("Keep each existing score component's input column; edit its mapping separately.")
            if checked["operator"] not in instruments.DERIVED and not after.get("source"):
                raise ValueError("Choose the logical source before requesting complete instrument parameters.")
            errors = instruments.issues({"clinical_rule": checked}, require_review=False)
        else:
            errors = _missing(checked)
    if errors:
        raise ValueError("Complete these calculation choices before proposing it: " + " ".join(errors))
    return {kind: deepcopy(checked)}


def assistant_diff(before, after):
    """Show every changed leaf, including removals and ordered table changes."""
    absent = object()
    result = []
    def display(value):
        if value is absent: return "Not set"
        if value is None: return "Unbounded / not set"
        if isinstance(value, bool): return "Yes" if value else "No"
        if value == "": return "Blank"
        return str(value)
    def walk(old, new, path):
        if isinstance(old, dict) or isinstance(new, dict):
            left = old if isinstance(old, dict) else {}
            right = new if isinstance(new, dict) else {}
            for key in sorted(set(left) | set(right)):
                walk(left.get(key, absent), right.get(key, absent), path + [key.replace("_", " ")])
        elif isinstance(old, list) or isinstance(new, list):
            left = old if isinstance(old, list) else []
            right = new if isinstance(new, list) else []
            for index in range(max(len(left), len(right))):
                label = ("Start", "End")[index] if path and path[-1] == "window days" and index < 2 else "Row " + str(index + 1)
                walk(left[index] if index < len(left) else absent, right[index] if index < len(right) else absent, path + [label])
        elif type(old) is not type(new) or old != new:
            result.append({"Field": " · ".join(path), "Current": display(old), "Suggested": display(new)})
    walk(before, after, [])
    return result


def workbook_calculation_schema():
    """Typed input to the workbook compiler; never a model-authored SQL field."""
    node = {"$ref": "#/$defs/workbookCalculationNode"}
    scalar = {"type": ["string", "number", "boolean", "null"]}
    fields = {
        "op": {"enum": ["column", "literal", "date", "study_constant", "completed_years",
                         "bands", "date_bound", "coalesce", "date_diff", "divide", "cast",
                         "compare", "and", "or", "not", "is_missing", "when"]},
        "name": {"type": "string"}, "value": {"anyOf": [node, scalar]},
        "birth": node, "at": node, "min": node, "max": node,
        "values": {"type": "array", "items": node, "minItems": 1, "maxItems": 32},
        "from": node, "to": node, "left": node, "right": node,
        "by": {"type": "number"}, "type": {"enum": ["integer", "long", "number", "string", "date"]},
        "operator": {"enum": ["eq", "ne", "lt", "le", "gt", "ge"]},
        "condition": node, "then": node, "else": node, "otherwise": scalar,
        "bands": {"type": "array", "minItems": 1, "maxItems": 32,
                  "items": {"type": "object", "required": ["label"], "additionalProperties": False,
                            "properties": {"label": scalar, **{key: {"type": "number"} for key in _BOUNDS}}}},
    }
    required = {"column": ["name"], "literal": ["value"], "date": ["value"],
                "study_constant": ["name"], "completed_years": ["birth", "at"],
                "bands": ["value", "bands", "otherwise"], "date_bound": ["value"],
                "coalesce": ["values"], "date_diff": ["from", "to"], "divide": ["value", "by"],
                "cast": ["value", "type"], "compare": ["left", "operator", "right"],
                "and": ["values"], "or": ["values"], "not": ["value"],
                "is_missing": ["value"], "when": ["condition", "then", "else"]}
    return {"type": "object", "required": ["name", "requires", "calculation"], "additionalProperties": False,
            "properties": {"name": {"type": "string", "pattern": "^[A-Za-z][A-Za-z0-9_]{0,127}$"},
                           "requires": {"type": "array", "minItems": 1, "uniqueItems": True,
                                        "items": {"type": "string", "pattern": "^[A-Za-z][A-Za-z0-9_]{0,127}$"}},
                           "calculation": node},
            "$defs": {"workbookCalculationNode": {
                "type": "object", "required": ["op"], "properties": fields, "additionalProperties": False,
                "oneOf": [{"properties": {"op": {"const": op}}, "required": keys}
                          for op, keys in required.items()]}}}


def compile_workbook_calculation(item):
    """Lower bounded typed choices to the existing ADS expression executor.

    No source values, approvals or arbitrary functions enter this compiler.
    The native expression/dependency checks and Spark type analysis still run.
    """
    from datetime import date
    from engine.codelists import sql_str
    from engine.sql_expressions import STUDY_TOKENS, errors as expression_errors

    identifier = re.compile(r"^[A-Za-z][A-Za-z0-9_]{0,127}$")
    if not isinstance(item, dict) or set(item) != {"name", "requires", "calculation"}:
        raise ValueError("A typed ADS calculation needs only name, requires and calculation.")
    if not isinstance(item["name"], str) or not identifier.fullmatch(item["name"]):
        raise ValueError("A calculation output needs a plain column identifier.")
    requires = item["requires"]
    if (not isinstance(requires, list) or not 1 <= len(requires) <= 64
            or any(not isinstance(value, str) or not identifier.fullmatch(value) for value in requires)
            or len({value.casefold() for value in requires}) != len(requires)):
        raise ValueError("requires must name each input column once, using plain identifiers.")
    refs, count = set(), 0

    def literal(value):
        if value is None:
            return "NULL"
        if type(value) is bool:
            return "TRUE" if value else "FALSE"
        if type(value) in (int, float):
            if abs(value) > 2**53 or not math.isfinite(value):
                raise ValueError("Calculation numbers must be finite and exactly representable within 2**53.")
            return str(value)
        if isinstance(value, str) and len(value) <= 1000 and not any(ord(c) < 32 or c in "{}" for c in value):
            return sql_str(value)
        raise ValueError("Use a bounded literal value, not executable text or a study-token string.")

    def visit(value, depth=0):
        nonlocal count
        count += 1
        if count > 128 or depth > 10 or not isinstance(value, dict):
            raise ValueError("Calculations support at most 128 nodes and ten nested levels.")
        op = value.get("op")
        if not isinstance(op, str):
            raise ValueError("A typed calculation needs a named operation.")
        shape = {
            "column": {"name"}, "literal": {"value"}, "date": {"value"}, "study_constant": {"name"},
            "completed_years": {"birth", "at"}, "bands": {"value", "bands", "otherwise"},
            "coalesce": {"values"}, "date_diff": {"from", "to"}, "divide": {"value", "by"},
            "cast": {"value", "type"}, "compare": {"left", "operator", "right"},
            "and": {"values"}, "or": {"values"}, "not": {"value"}, "is_missing": {"value"},
            "when": {"condition", "then", "else"}}
        if op == "date_bound":
            if not {"op", "value"} <= set(value) or set(value) - {"op", "value", "min", "max"} or not ({"min", "max"} & set(value)):
                raise ValueError("date_bound needs a value and at least one explicit inclusive bound.")
        elif op not in shape or set(value) != shape[op] | {"op"}:
            raise ValueError("Unknown operation or incomplete/extra typed calculation fields: " + str(op))
        child = lambda key: visit(value[key], depth + 1)
        if op == "column":
            name = value["name"]
            if not isinstance(name, str) or not identifier.fullmatch(name):
                raise ValueError("Calculation inputs must use plain column identifiers.")
            refs.add(name.casefold())
            return "`" + name + "`"
        if op == "literal":
            return literal(value["value"])
        if op == "date":
            text = value["value"]
            if not isinstance(text, str) or date.fromisoformat(text).isoformat() != text:
                raise ValueError("Use a real ISO calendar date.")
            return "DATE " + sql_str(text)
        if op == "study_constant":
            if not isinstance(value["name"], str) or value["name"] not in STUDY_TOKENS:
                raise ValueError("Use a declared native study-date constant.")
            return "{" + value["name"] + "}"
        if op == "completed_years":
            birth, at = child("birth"), child("at")
            return (f"(year({at}) - year({birth}) - CASE WHEN "
                    f"month({at})*100 + day({at}) < month({birth})*100 + day({birth}) THEN 1 ELSE 0 END)")
        if op in {"coalesce", "and", "or"}:
            values = value["values"]
            if not isinstance(values, list) or not 2 <= len(values) <= 32:
                raise ValueError(op + " needs 2–32 typed operands.")
            args = [visit(v, depth + 1) for v in values]
            return "coalesce(" + ", ".join(args) + ")" if op == "coalesce" else "(" + (" " + op.upper() + " ").join(args) + ")"
        if op == "date_diff":
            return f"datediff({child('to')}, {child('from')})"
        if op == "divide":
            divisor = value["by"]
            if type(divisor) not in (int, float) or divisor == 0:
                raise ValueError("divide.by must be a finite, nonzero numeric constant.")
            return f"(cast({child('value')} AS double) / {literal(divisor)})"
        if op == "cast":
            types = {"integer": "int", "long": "bigint", "number": "double", "string": "string", "date": "date"}
            if not isinstance(value["type"], str) or value["type"] not in types:
                raise ValueError("Choose a supported primitive cast type.")
            return f"try_cast({child('value')} AS {types[value['type']]})"
        if op == "compare":
            operators = {"eq": "=", "ne": "<>", "lt": "<", "le": "<=", "gt": ">", "ge": ">="}
            if not isinstance(value["operator"], str) or value["operator"] not in operators:
                raise ValueError("Choose a supported typed comparison.")
            return f"({child('left')} {operators[value['operator']]} {child('right')})"
        if op == "not":
            return f"(NOT {child('value')})"
        if op == "is_missing":
            return f"({child('value')} IS NULL)"
        if op == "when":
            return f"(CASE WHEN {child('condition')} THEN {child('then')} ELSE {child('else')} END)"
        if op == "date_bound":
            source = child("value")
            conditions = [f"{source} {sign} {child(key)}" for key, sign in (("min", ">="), ("max", "<=")) if key in value]
            return "(CASE WHEN " + " AND ".join(conditions) + f" THEN {source} ELSE NULL END)"
        source, parts, intervals = child("value"), [], []
        bands = value["bands"]
        if not isinstance(bands, list) or not 1 <= len(bands) <= 32:
            raise ValueError("bands needs 1–32 explicit numeric ranges.")
        for band in bands:
            if (not isinstance(band, dict) or "label" not in band or set(band) - (_BOUNDS | {"label"})
                    or not (_BOUNDS & set(band)) or {"min", "min_excl"} <= set(band) or {"max", "max_excl"} <= set(band)):
                raise ValueError("Each band needs a label and unambiguous numeric bounds.")
            for key in _BOUNDS & set(band):
                if type(band[key]) not in (int, float):
                    raise ValueError("Band bounds must be finite numbers.")
                literal(band[key])
            low, high = band.get("min", band.get("min_excl", -math.inf)), band.get("max", band.get("max_excl", math.inf))
            low_closed, high_closed = "min" in band, "max" in band
            if low > high or low == high and not (low_closed and high_closed):
                raise ValueError("Band bounds define an empty range.")
            for old_low, old_high, old_lc, old_hc in intervals:
                if not (high < old_low or high == old_low and not (high_closed and old_lc)
                        or old_high < low or old_high == low and not (old_hc and low_closed)):
                    raise ValueError("Numeric bands overlap; review their boundaries.")
            intervals.append((low, high, low_closed, high_closed))
            condition = " AND ".join(f"{source} {sign} {literal(band[key])}" for key, sign in
                                      (("min", ">="), ("min_excl", ">"), ("max", "<="), ("max_excl", "<")) if key in band)
            parts.append(f"WHEN {condition} THEN {literal(band['label'])}")
        return "(CASE " + " ".join(parts) + f" ELSE {literal(value['otherwise'])} END)"

    expr = visit(item["calculation"])
    if refs != {name.casefold() for name in requires}:
        raise ValueError("requires must exactly match the calculation's input columns.")
    if len(expr.encode("utf-8")) > 12000:
        raise ValueError("The compiled calculation exceeds the expression size limit.")
    failures = expression_errors(expr, where="typed calculation", requires=requires)
    if failures:
        raise ValueError(" ".join(failures))
    return {"name": item["name"], "requires": list(requires), "expr": expr}


def resolve_native_ecog_selection(item, block, *, shadowed_columns=()):
    """Translate the exact native grade-or-null filter through its proven code map.

    This changes only the input column of an equivalent typed calculation. The
    caller must supply the effective native baseline_ecog block and any competing
    ecog/ecogn producers. Unrecognized or ambiguous choices remain unchanged so
    the ordinary compiler and dependency guards can report them.
    """
    original = deepcopy(item)
    if (not isinstance(item, dict) or item.get("name") != "ecog" or item.get("requires") != ["ecog"]
            or not isinstance(block, dict)
            or not isinstance(shadowed_columns, (tuple, list, set, frozenset))
            or any(not isinstance(name, str) for name in shadowed_columns)
            or {name.strip().casefold() for name in shadowed_columns} & {"ecog", "ecogn"}):
        return original
    column = {"op": "column", "name": "ecog"}
    tree = item.get("calculation")
    if (not isinstance(tree, dict) or set(tree) != {"op", "condition", "then", "else"}
            or tree["op"] != "when" or tree["then"] != column
            or tree["else"] != {"op": "literal", "value": None}):
        return original
    condition = tree["condition"]
    if (not isinstance(condition, dict) or set(condition) != {"op", "values"}
            or condition["op"] != "or" or not isinstance(condition["values"], list)
            or len(condition["values"]) != 5):
        return original
    grades = []
    for predicate in condition["values"]:
        if (not isinstance(predicate, dict) or set(predicate) != {"op", "operator", "left", "right"}
                or predicate["op"] != "compare" or predicate["operator"] != "eq"):
            return original
        left, right = predicate["left"], predicate["right"]
        literal = right if left == column else left if right == column else None
        if (not isinstance(literal, dict) or set(literal) != {"op", "value"}
                or literal["op"] != "literal" or not isinstance(literal["value"], str)):
            return original
        grades.append(literal["value"])
    if set(grades) != {"0", "1", "2", "3", "4"}:
        return original
    codes, missing_label = block.get("value_codes"), block.get("missing_label")
    if (not isinstance(codes, dict) or not 6 <= len(codes) <= 100
            or not set(grades) | {"Unknown"} <= codes.keys()
            or not isinstance(missing_label, str) or not missing_label.strip() or missing_label in codes):
        return original
    for label in codes:
        if (not isinstance(label, str) or label != "Unknown" and
                (not re.fullmatch(r"0|[1-9][0-9]{0,9}", label) or int(label) >= 2**31)):
            return original
    try:
        _text(missing_label, "Missing ECOG label")
        for code in [*codes.values(), block.get("missing_code")]:
            _code(code, "Native ECOG code")
        if len(set(codes.values())) != len(codes) or block["missing_code"] in codes.values():
            return original
        compile_workbook_calculation(item)
        calculation = {"op": "literal", "value": None}
        for grade in reversed(sorted(grades)):
            calculation = {"op": "when", "condition": {"op": "compare", "operator": "eq",
                "left": {"op": "column", "name": "ecogn"},
                "right": {"op": "literal", "value": codes[grade]}},
                "then": {"op": "literal", "value": grade}, "else": calculation}
        result = {"name": "ecog", "requires": ["ecogn"], "calculation": calculation}
        compile_workbook_calculation(result)
    except (ValueError, TypeError):
        return original
    return result


def _text(value, name, *, identifier=False, multiline=False):
    if not isinstance(value, str) or len(value) > 12000 or any((ord(c) < 32 and not (multiline and c in "\n\r\t")) or 127 <= ord(c) <= 159 for c in value):
        raise ValueError(f"{name} must be plain text without control characters (at most 12000 characters).")
    if identifier and value and (len(value) > 128 or not _ID.fullmatch(value)):
        raise ValueError(f"{name} must start with a letter and contain only letters, digits and underscores.")


def _strings(value, name):
    if not isinstance(value, list) or len(value) > 500:
        raise ValueError(f"{name} must be a list of at most 500 text choices.")
    for item in value:
        _text(item, name)
        if not item.strip():
            raise ValueError(f"{name} cannot contain a blank choice.")
    if len(value) != len(set(value)):
        raise ValueError(f"{name} contains duplicate choices.")


def _code(value, name):
    if type(value) is not int or not -(2**31) <= value < 2**31:
        raise ValueError(f"{name} must be a 32-bit whole number.")


def _groups(value, name):
    if not isinstance(value, list) or len(value) > 500:
        raise ValueError(f"{name} must be a list of at most 500 groups.")
    labels, codes, markers, intervals, exact = set(), set(), set(), [], {}
    for group in value:
        allowed = {"label", "code", "when"} | (_MATCHERS if name == "groups" else _BOUNDS)
        if not isinstance(group, dict) or set(group) - allowed:
            raise ValueError(f"{name} contains an unsupported field; use the offered category or boundary choices.")
        if "label" in group:
            _text(group["label"], f"{name} label")
            if group["label"] and group["label"] in labels:
                raise ValueError(f"{name} labels must be unique.")
            labels.add(group["label"])
        if "code" in group and group["code"] is not None:
            _code(group["code"], f"{name} code")
            if group["code"] in codes:
                raise ValueError(f"{name} codes must be unique.")
            codes.add(group["code"])
        marker = group.get("when")
        if marker not in (None, "", "missing", "fallthrough") or (name == "bands" and marker == "missing"):
            raise ValueError(f"{name} has an unsupported missing-value rule.")
        if marker:
            if marker in markers or (set(group) - {"label", "code", "when"}):
                raise ValueError(f"{name} needs unique missing/fallthrough rows without matching values or boundaries.")
            markers.add(marker)
        for key in _MATCHERS & set(group):
            _strings(group[key], key)
            if key in {"from_startswith_ci", "from_contains_ci"} and any("%" in s or "_" in s for s in group[key]):
                raise ValueError("Prefix and substring choices cannot contain SQL wildcard characters; use exact matching.")
            if key in {"from_prefixes", "from_equals_ci"}:
                for raw in group[key]:
                    token = raw.casefold()  # A conservative refusal avoids ambiguous mixed case policies.
                    if token in exact and exact[token] != group.get("label"):
                        raise ValueError("A raw category is assigned to more than one group.")
                    exact[token] = group.get("label")
        for key in _BOUNDS & set(group):
            if type(group[key]) not in (int, float) or not math.isfinite(group[key]):
                raise ValueError("Band boundaries must be finite numbers, not text or boolean values.")
        if {"min", "min_excl"} <= set(group) or {"max", "max_excl"} <= set(group):
            raise ValueError("Use either an inclusive or an exclusive boundary at each end of a band.")
        if name == "bands" and not marker and _BOUNDS & set(group):
            lo = group.get("min", group.get("min_excl", -math.inf))
            hi = group.get("max", group.get("max_excl", math.inf))
            lc, hc = "min_excl" not in group, "max_excl" not in group
            if lo > hi or (lo == hi and not (lc and hc)):
                raise ValueError("A band has reversed boundaries or contains no possible value.")
            for a, b, ac, bc in intervals:
                low, high = max(lo, a), min(hi, b)
                touching = low == high and (low != lo or lc) and (low != a or ac) and (high != hi or hc) and (high != b or bc)
                if low < high or touching:
                    raise ValueError("Numeric bands overlap; choose distinct boundaries.")
            intervals.append((lo, hi, lc, hc))


def validate(value, allow_incomplete=True):
    """Return detached structured metadata; unfinished choices are valid drafts."""
    if instruments.is_native(value):
        return instruments.validate(value, allow_incomplete=allow_incomplete)
    if not isinstance(value, dict) or set(value) - _FIELDS:
        raise ValueError("The clinical rule contains an unsupported field.")
    if not value:
        return {}
    try:
        encoded = json.dumps(value, allow_nan=False)
    except (TypeError, ValueError, RecursionError) as error:
        raise ValueError("Clinical rules must contain finite JSON values.") from error
    if len(encoded.encode("utf-8")) > 256 * 1024:
        raise ValueError("The clinical rule exceeds the 256 KiB limit.")
    if type(value.get("version")) is not int or value["version"] != 1:
        raise ValueError("Choose clinical rule version 1.")
    op, family = value.get("operator", ""), value.get("family", "")
    if not isinstance(op, str) or op not in _ALLOWED:
        raise ValueError("Choose a supported clinical operation or Custom rule.")
    if not isinstance(family, str) or family not in {"", *FAMILIES}:
        raise ValueError("Choose a clinical family from the list.")
    if op and family and family not in _FAMILY[op]:
        raise ValueError("The clinical family does not match its selected operation.")
    stale = [key for key in set(value) - _ALLOWED[op] if value[key] not in _EMPTY]
    if stale:
        raise ValueError("Clear choices from the previous clinical operation: " + ", ".join(sorted(stale)) + ".")
    out = {key: deepcopy(item) for key, item in value.items() if key in _ALLOWED[op]}
    for key in ("output_stem", "result", "match", "value_cast", "pick", "tie_break", "same_date_conflict",
                "value_tiebreak", "present_label", "missing_label", "unknown_label", "equidistant", "custom_notes"):
        if key in out:
            _text(out[key], key, identifier=key == "output_stem", multiline=key == "custom_notes")
    enums = {"result": {"label", "code", "value", "date"}, "value_cast": set(_CAST_TYPES),
             "pick": {"nearest", "earliest", "latest", "priority"},
             "same_date_conflict": {"deterministic", "refuse", "priority", "resolve"},
             "value_tiebreak": {"lowest", "highest"}, "equidistant": {"date", "worst_value"},
             "tie_break": {"earliest_date", "latest_date"} if op == "baseline_ecog" else {"prior", "later"}}
    for key, choices in enums.items():
        if out.get(key) and out[key] not in choices:
            raise ValueError(f"Choose {key} from: {', '.join(sorted(choices))}.")
    if out.get("same_date_conflict") == "resolve" and op != "panel_categories":
        raise ValueError("Explicit conflict resolution is supported only for panel categories.")
    for key in ("emit_date", "positive_only"):
        if key in out and type(out[key]) is not bool:
            raise ValueError(f"{key} must be an explicit yes/no choice.")
    if "window_days" in out:
        window = out["window_days"]
        if not isinstance(window, list) or len(window) != 2 or any(x is not None and (type(x) is not int or abs(x) > 365250) for x in window):
            raise ValueError("The eligible window needs two whole-day boundaries (or an open boundary).")
        if None not in window and window[0] > window[1]:
            raise ValueError("The eligible window starts after it ends.")
    if "window" in out:
        read_window(out)
    roles = out.get("column_roles", {})
    if not isinstance(roles, dict) or set(roles) - {"value", "date", "analyte", "unit"}:
        raise ValueError("Choose supported source roles: value, date, analyte and unit.")
    for key, logical in roles.items():
        _text(logical, f"Source role {key}", identifier=True)
    possible = {"value", "date"} | ({"analyte", "unit"} if op in {"panel_categories", "panel_bands", "lab_value"} else set())
    if any(v and k not in possible for k, v in roles.items()):
        raise ValueError("Clear source roles that the selected clinical operation does not read.")
    if roles.get("unit") and not out.get("units"):
        raise ValueError("A unit role without selected units would not restrict the measurement; choose units or clear that role.")
    for key in ("units", "match_any", "priority"):
        if key in out:
            _strings(out[key], key)
    if out.get("match") and out.get("match_any"):
        raise ValueError("Choose one analyte name or a list of analyte names, not both.")
    for key in ("groups", "bands"):
        if key in out:
            _groups(out[key], key)
    if "conflict_rules" in out:
        if not isinstance(out["conflict_rules"], list) or len(out["conflict_rules"]) > 500:
            raise ValueError("Conflict resolutions must be a list of at most 500 rules.")
        seen = set()
        for rule in out["conflict_rules"]:
            if not isinstance(rule, dict) or set(rule) != {"between", "resolve"}:
                raise ValueError("Each conflict rule needs between and resolve choices.")
            _strings(rule["between"], "Conflicting labels")
            _text(rule["resolve"], "Conflict resolution")
            if len(rule["between"]) != 2:
                raise ValueError("Choose two distinct conflicting labels.")
            pair = tuple(sorted(rule["between"]))
            if pair in seen:
                raise ValueError("A conflicting pair has more than one resolution.")
            seen.add(pair)
        if out["conflict_rules"] and out.get("same_date_conflict") != "resolve":
            raise ValueError("Conflict rules require the explicit resolve choice.")
    if "value_codes" in out:
        if not isinstance(out["value_codes"], dict) or len(out["value_codes"]) > 100:
            raise ValueError("ECOG codes must be a mapping of labels to whole-number codes.")
        for label, code in out["value_codes"].items():
            _text(label, "ECOG label")
            if label != "Unknown" and not re.fullmatch(r"[0-9]+", label):
                raise ValueError("ECOG labels must be nonnegative integer grades or Unknown.")
            if code is not None:
                _code(code, "ECOG code")
        codes = [code for code in out["value_codes"].values() if code is not None]
        if len(set(codes)) != len(codes):
            raise ValueError("ECOG codes must be unique.")
    if "missing_code" in out and out["missing_code"] is not None:
        _code(out["missing_code"], "Missing code")
        if out["missing_code"] in (out.get("value_codes") or {}).values():
            raise ValueError("The missing ECOG code must differ from the observed-value codes.")
    if not allow_incomplete:
        missing = _missing(out)
        if missing:
            raise ValueError(" ".join(missing))
    return out


def _missing(rule):
    if instruments.is_native(rule):
        return instruments.issues({"clinical_rule": rule})
    if not rule:
        return []
    op = rule.get("operator")
    if not op:
        return ["Choose the clinical operation."]
    if op == "custom":
        return ["This custom clinical rule needs an implementation handoff; free text is not executable."]
    result = []
    for key in ("family", "output_stem", "result"):
        if not rule.get(key):
            result.append(f"Choose {key.replace('_', ' ')} for this clinical rule.")
    if "window_days" not in rule and "window" not in rule:
        result.append("Choose the eligible record window in whole days relative to cohort index.")
    elif op == "baseline_ecog" and None in window_days(rule):
        result.append("Baseline ECOG needs a finite day boundary at both ends.")
    elif op == "categorical" and window_days(rule) == [None, None]:
        result.append("A categorical clinical rule needs at least one finite day boundary to exclude undated records.")
    if op in {"categorical", "panel_categories", "panel_bands"}:
        needed = ("pick", "same_date_conflict") + (("tie_break",) if rule.get("pick") in {"nearest", "priority"} else ())
        for key in needed:
            if not rule.get(key):
                result.append(f"Choose {key.replace('_', ' ')} for record selection.")
        key = "bands" if op == "panel_bands" else "groups"
        groups = rule.get(key) or []
        if not groups:
            result.append(f"Define the {key} and their output codes.")
        elif any(not g.get("label") or g.get("code") is None for g in groups):
            result.append(f"Each {key} row needs a label and integer output code.")
        if not any(g.get("when") == "fallthrough" for g in groups):
            result.append("Add a fallthrough group for values outside the declared categories or bands.")
        if key == "groups" and not any(g.get("when") == "missing" for g in groups):
            result.append("Add a missing group for a record whose value is null (different from no eligible record).")
        if not any(not g.get("when") for g in groups):
            result.append("Add at least one observed category or numeric band.")
        if any(not g.get("when") and not any(g.get(k) for k in _MATCHERS) for g in groups) and key == "groups":
            result.append("Choose the raw values that each observed category matches.")
        if key == "bands" and any(not g.get("when") and not _BOUNDS.intersection(g) for g in groups):
            result.append("Each numeric band needs at least one finite boundary.")
        labels = {g.get("label") for g in groups if g.get("label")}
        if rule.get("pick") == "priority" or rule.get("same_date_conflict") == "priority":
            if set(rule.get("priority") or []) != labels:
                result.append("Order every group label in the explicit priority list.")
        elif rule.get("priority"):
            result.append("Clear priority labels or choose priority selection; these labels would otherwise be ignored.")
        if rule.get("same_date_conflict") == "resolve" and rule.get("pick") != "nearest":
            result.append("Explicit same-day conflict resolution supports nearest-date selection only; choose nearest or request an implementation handoff.")
        from engine.stages.clinical import selection_errors, value_matcher_errors
        result.extend(selection_errors({}, {key: value for key, value in rule.items() if value not in _EMPTY}))
        if key == "groups":
            result.extend(value_matcher_errors(groups))
    if op in {"panel_categories", "panel_bands", "lab_value"} and not (rule.get("match") or rule.get("match_any")):
        result.append("Choose the delivered analyte or assessment name to match.")
    if op in {"panel_bands", "lab_value"}:
        if not rule.get("value_cast"):
            result.append("Choose the numeric cast for the measurement.")
        if not rule.get("units"):
            result.append("Declare the allowed measurement units; unit conversion is not implicit.")
    if op in {"panel_categories", "panel_bands"} and "emit_date" not in rule:
        result.append("Choose whether to emit the selected assessment date.")
    if op == "lab_value":
        for key in ("value_tiebreak", "present_label", "missing_label"):
            if not rule.get(key):
                result.append(f"Choose {key.replace('_', ' ')} for the laboratory measurement.")
        if "positive_only" not in rule:
            result.append("Choose whether zero and negative measurement values are eligible.")
        labels = [rule.get(k) for k in ("present_label", "missing_label", "unknown_label") if rule.get(k)]
        if len(labels) != len(set(labels)):
            result.append("Present, missing and unknown laboratory labels must differ.")
    if op == "baseline_ecog":
        if rule.get("output_stem") and rule["output_stem"] != "ecog":
            result.append("The native baseline ECOG operation emits ecog and ecogn; use output stem ecog.")
        for key in ("tie_break", "equidistant", "missing_label"):
            if not rule.get(key):
                result.append(f"Choose {key.replace('_', ' ')} for baseline ECOG.")
        if rule.get("equidistant") == "worst_value" and rule.get("tie_break") == "latest_date":
            result.append("Worst-grade equidistant ECOG uses earliest date as its final tie; choose earliest_date.")
        if rule.get("missing_code") is None:
            result.append("Choose the missing ECOG code.")
        codes = rule.get("value_codes") or {}
        if not codes or "Unknown" not in codes or not any(k != "Unknown" for k in codes):
            result.append("Map the expected ECOG grades and the Unknown label to output codes.")
        if any(code is None for code in codes.values()):
            result.append("Choose a whole-number output code for every listed ECOG grade and Unknown.")
        if rule.get("missing_label") in codes:
            result.append("The missing ECOG label must differ from observed grades and Unknown.")
    outputs = {"categorical": {"label", "code"}, "panel_categories": {"label", "code", "date"},
               "panel_bands": {"label", "code", "date"}, "lab_value": {"label", "value", "date"},
               "baseline_ecog": {"label", "code"}}
    if rule.get("result") and rule["result"] not in outputs[op]:
        result.append("The selected clinical operation does not emit that result kind.")
    if rule.get("result") == "date" and op in {"panel_categories", "panel_bands"} and not rule.get("emit_date"):
        result.append("Enable the selected assessment date before choosing a date result.")
    return list(dict.fromkeys(result))


def required_roles(rule):
    """Semantic roles only; each maps to an existing logical source-column key."""
    if instruments.is_native(rule):
        return instruments.requires(rule)
    rule = validate(rule)
    if not rule or rule.get("operator") in {"", None, "custom"}:
        return []
    roles = ["value", "date"]
    if rule["operator"] in {"panel_categories", "panel_bands", "lab_value"}:
        roles.append("analyte")
        if rule.get("units"):
            roles.append("unit")
    return roles


def emitted_columns(rule):
    if instruments.is_native(rule):
        return instruments.emitted_columns(rule)
    rule = validate(rule)
    op, stem = rule.get("operator"), rule.get("output_stem")
    if not stem or op not in _FAMILY or op == "custom":
        return []
    out = [{"name": stem, "type": "string", "result": "label"}]
    if op == "lab_value":
        out += [{"name": stem + "v", "type": _CAST_TYPES.get(rule.get("value_cast"), "double"), "result": "value"},
                {"name": stem + "dt", "type": "date", "result": "date"}]
    else:
        out.append({"name": stem + "n", "type": "integer", "result": "code"})
        if op in {"panel_categories", "panel_bands"} and rule.get("emit_date"):
            out.append({"name": stem + "dt", "type": "date", "result": "date"})
    return out


def issues(row):
    if instruments.is_native(selection(row)):
        return instruments.issues({**row, "clinical_rule": selection(row)})
    try:
        rule = validate(selection(row))
    except ValueError as error:
        return [str(error)]
    result = _missing(rule)
    expected = next((c["type"] for c in emitted_columns(rule) if c["result"] == rule.get("result")), None)
    actual = ((row.get("values") or {}).get("output") or {}).get("type")
    if expected and actual not in (None, "", "TODO") and canonical_type(actual) != expected:
        result.append(f"This clinical result needs data type {expected}; the row currently uses {actual}.")
    return result


def source_issues(row):
    if instruments.is_native(selection(row)):
        return instruments.source_issues({**row, "clinical_rule": selection(row)})
    try:
        rule = validate(selection(row))
        roles = required_roles(rule)
    except ValueError as error:
        return [str(error)]
    if not roles:
        return []
    source = (row.get("values") or {}).get("source") or {}
    columns = source.get("columns") or {}
    columns = columns if isinstance(columns, dict) else {}
    result = []
    if source.get("kind") != "vendor":
        result.append("Choose an existing data column as the source of this native clinical operation.")
    alias = source.get("logical_table")
    if not isinstance(alias, str) or not _ID.fullmatch(alias):
        result.append("Choose one declared logical source alias for this clinical rule.")
    if not isinstance(columns.get("patientid"), str) or not _ID.fullmatch(columns["patientid"]):
        result.append("Map the patientid source column for this clinical rule.")
    for role in roles:
        logical = (rule.get("column_roles") or {}).get(role)
        if not logical or logical not in columns or not isinstance(columns[logical], str) or not _ID.fullmatch(columns[logical]):
            result.append(f"Map clinical role '{role}' to a declared logical source column and its delivered column.")
    if rule.get("operator") == "baseline_ecog":
        if alias != "baseline_ecog":
            result.append("Baseline ECOG reads the baseline_ecog source alias.")
        for role, fixed in {"value": "ecogvalue", "date": "ecogdate"}.items():
            if (rule.get("column_roles") or {}).get(role) != fixed:
                result.append(f"Baseline ECOG requires role {role} to use logical column {fixed}; configure its delivered adapter separately.")
    return result


def scientific_updates(value):
    if instruments.is_native(value):
        return instruments.scientific_updates(value)
    rule = validate(value)
    result = {"clinical_rule": rule}
    if not rule or _missing(rule):
        return result
    expected = next(c for c in emitted_columns(rule) if c["result"] == rule["result"])
    op = rule["operator"]
    reviewed_window = read_window(rule)
    selection_text = ("Nearest numeric measurement; equal distances prefer the earlier date, then the " + rule["value_tiebreak"] + " numeric value."
                      if op == "lab_value" else
                      (f"Nearest ECOG; equal distances use {rule['equidistant']}; date tie {rule['tie_break']}; same date prefers worst grade."
                       if op == "baseline_ecog" else
                       f"Select {rule['pick']}; " + (f"date preference {rule['tie_break']}; " if rule.get("pick") in {"nearest", "priority"} else "") + f"same-date conflict {rule['same_date_conflict']}."))
    result.update({"output.type": expected["type"], "grain": "One value per patient within each cohort",
                   "anchor": "Cohort index date", "window": reviewed_window.describe(),
                   "record_selection": selection_text, "tie_break": selection_text,
                   "derivation": f"Native {op}: return the {rule['result']} result. " + selection_text})
    return result


def _native(rule, source):
    op, roles, stem = rule["operator"], rule["column_roles"], rule["output_stem"]
    selection_settings = {k: deepcopy(rule[k]) for k in _SELECT if k in rule and rule[k] not in _EMPTY}
    if op == "categorical":
        return "categoricals", {"name": stem, "source": source["logical_table"], "column": roles["value"],
            "date_column": roles["date"], **window_fields(rule), "groups": rule["groups"], **selection_settings}, None
    if op == "baseline_ecog":
        block = {k: deepcopy(rule[k]) for k in ("tie_break", "value_codes", "missing_code", "missing_label")}
        block.update(window_fields(rule))
        if rule["equidistant"] == "worst_value":
            block["equidistant"] = "worst_value"
        return "baseline_ecog", None, block
    block = {"source": source["logical_table"], "name_column": roles["analyte"],
             "value_column": roles["value"], "date_column": roles["date"], **window_fields(rule)}
    if rule.get("units"):
        block["unit_column"] = roles["unit"]
    item = {"name": stem}
    for key in ("match", "match_any", "units"):
        if rule.get(key):
            item[key] = deepcopy(rule[key])
    if op == "lab_value":
        block.update({k: deepcopy(rule[k]) for k in ("value_cast", "present_label", "missing_label")})
        if rule.get("unknown_label"):
            block["unknown_label"] = rule["unknown_label"]
        item.update(tiebreak=rule["value_tiebreak"], positive_only=rule["positive_only"])
        return "lab_values", item, block
    block["emit_date"] = rule["emit_date"]
    item.update(selection_settings)
    key = "bands" if op == "panel_bands" else "groups"
    item[key] = deepcopy(rule[key])
    for key in ("value_cast", "conflict_rules"):
        if rule.get(key):
            item[key] = deepcopy(rule[key])
    return _PANELS[rule["family"]], item, block


def _clinical(cfg):
    return cfg.pack("clinical") if callable(getattr(cfg, "pack", None)) else (getattr(cfg, "clinical", {}) or {})


def ecog_product_choice(cfg):
    """Expose the current product's exact single-source rule for explicit UI reuse.

    This reads configuration, not patient data or approval. Only native identities
    are supplied here; clinical windows, codes and missingness come from the pack.
    """
    result = {"ready": False, "rule": {}, "source": {}, "issues": []}
    try:
        from engine.config import canonical_physical
        from rwd_tools import source_check
        block = deepcopy(_clinical(cfg).get("baseline_ecog") or {})
        if not block:
            raise ValueError("No baseline ECOG rule is declared in this product. Enter its scientific choices in Edit details.")
        keys = {"window", "window_days", "tie_break", "equidistant", "value_codes", "missing_code", "missing_label"}
        rule = {key: deepcopy(value) for key, value in block.items() if key in keys}
        rule.update(version=1, operator="baseline_ecog", family="performance_status", output_stem="ecog",
                    result="label", column_roles={"value": "ecogvalue", "date": "ecogdate"})
        # Omission is the existing native date-first policy, not a new default.
        if "equidistant" not in block:
            rule["equidistant"] = "date"
        validate(rule, allow_incomplete=False)
        if getattr(cfg, "source_union", None):
            raise ValueError("This product combines source schemas. Keep its existing ECOG rule and review the mapping in Sources.")
        aliases = getattr(cfg, "sources", {}) or {}
        if "baseline_ecog" not in aliases:
            raise ValueError("Declare the baseline ECOG table and patient, grade and assessment-date columns in Sources.")
        physical = canonical_physical(cfg, "baseline_ecog")
        columns = {name: physical.get(name, name) for name in ("patientid", "ecogvalue", "ecogdate")}
        source = {"kind": "vendor", "logical_table": "baseline_ecog",
                  "physical_stem": source_check.config_base(cfg, "baseline_ecog"), "columns": columns}
        if any(not name or re.search(r"(?:^|[^a-z0-9])(?:replace_me|todo|tbd|undecided)(?:$|[^a-z0-9])", name.casefold())
               for name in [source["physical_stem"], *columns.values()]):
            raise ValueError("Replace the placeholder ECOG table or column mapping in Sources before reusing this rule.")
        row = {"values": {"source": source}, "clinical_rule": rule}
        problems = source_issues(row) + _config_issues(row, rule, cfg)
        if problems:
            raise ValueError("; ".join(problems))
        result.update(ready=True, rule=rule, source=source)
    except (ValueError, TypeError, KeyError, AttributeError) as error:
        result["issues"] = [str(error)]
    return result


def _config_issues(row, rule, cfg):
    from engine.config import canonical_physical
    source = row["values"]["source"]
    alias = source["logical_table"]
    sources = getattr(cfg, "sources", {}) or {}
    if alias not in sources:
        return [f"Source alias {alias} is not declared in this product configuration."]
    why = []
    from engine.validate import adapter_rename_conflicts
    why.extend(adapter_rename_conflicts(cfg))
    declared_stem = source.get("physical_stem")
    if declared_stem:
        # Use the same table-base contract as the source selector and its
        # review checks. A deployment layout can add prefixes, and a reviewer
        # may retain an accepted refresh suffix on the selected table name.
        from rwd_tools import source_check
        expected_stem = source_check.config_base(cfg, alias)
        selected_stem = source_check.CUT.sub("", str(declared_stem).strip().casefold())
        if selected_stem != expected_stem.casefold():
            why.append(f"Source alias {alias} now points to {expected_stem}; refresh the reviewed source table mapping.")
    actual = canonical_physical(cfg, alias)
    for logical in ["patientid", *[rule["column_roles"][k] for k in required_roles(rule)]]:
        physical = source["columns"][logical]
        if physical.casefold() != actual.get(logical.casefold(), logical.casefold()):
            why.append(f"Source {alias}.{logical} is mapped to {physical} in the review but the configured adapter reads {actual.get(logical.casefold(), logical)}.")
    if rule["operator"] == "baseline_ecog":
        block = _clinical(cfg).get("baseline_ecog") or {}
        if block.get("union_source"):
            why.append("The configured ECOG rule combines another source; this single-source clinical rule cannot replace that reviewed union.")
        if any(c.get("ecog_line_match") for c in (getattr(cfg, "cohorts", []) or [])):
            why.append("A cohort requires ECOG-to-treatment-line matching; this bounded baseline rule needs an explicit implementation handoff.")
    return why


def _existing_outputs(clinical):
    out = {}
    for item in clinical.get("categoricals") or []:
        if item.get("name"):
            out[("categoricals", item["name"])] = [item["name"], item["name"] + "n"]
    from engine.clinical_panels import iter_panels
    for block, _label, settings in iter_panels(clinical):
        for item in settings.get("panel") or []:
            if item.get("name"):
                name = item["name"]
                out[(block, name)] = ([name, name + "v", name + "dt"] if block == "lab_values" else
                    [name, name + "n"] + ([name + "dt"] if settings.get("emit_date") else []))
    if clinical.get("baseline_ecog"):
        out[("baseline_ecog", "ecog")] = ["ecog", "ecogn"]
    return out


def compile_rows(rows, cfg):
    """Prepare whole-block JSON-pointer replacements without mutating cfg or rows.

    A single blocker makes the returned operations empty: partial installation
    must not suggest that the reviewed clinical list has been compiled in full.
    """
    rows = list(rows)
    all_rows = rows
    native_result = instruments.compile_rows(rows, cfg)
    rows = [row for row in rows if not instruments.is_native(selection(row))]
    result = {"operations": [], "rows": [], "blockers": []}
    prepared = []
    raw = getattr(cfg, "raw", {}) or {}
    active = "variables/clinical.yaml" in (raw.get("variables") or [])
    try:
        clinical = deepcopy(_clinical(cfg)) if active else {}
        load_error = ""
    except (ValueError, KeyError, OSError, TypeError) as error:
        clinical, load_error = {}, f"The active clinical variable pack could not be read: {error}"

    def block(row, message):
        result["blockers"].append({"item_id": row.get("item_id", ""), "variable_id": row.get("variable_id", ""), "message": message})

    for row in rows:
        if not selection(row):
            continue
        report = {"item_id": row.get("item_id", ""), "variable_id": row.get("variable_id", ""),
                  "status": "blocked", "emitted_columns": [], "read_roles": []}
        result["rows"].append(report)
        output = (row.get("values") or {}).get("output") or {}
        if output.get("role") == "excluded":
            report["status"] = "excluded"
            continue
        try:
            rule = validate(selection(row))
        except ValueError as error:
            block(row, str(error))
            continue
        report["emitted_columns"] = emitted_columns(rule)
        why = issues(row) + source_issues(row)
        if not active:
            why.append("Activate variables/clinical.yaml in the product configuration before compiling clinical rules.")
        if load_error:
            why.append(load_error)
        if output.get("role") not in {"published", "internal"}:
            why.append("Choose a published or internal variable output for this clinical calculation; it emits data columns, not metadata.")
        if not why:
            why += _config_issues(row, rule, cfg)
            expected = next(c for c in emitted_columns(rule) if c["result"] == rule["result"])
            if output.get("physical_name") != expected["name"]:
                why.append(f"The native {rule['result']} output is {expected['name']}; align the reviewed output name explicitly.")
            if canonical_type(output.get("type")) != expected["type"]:
                why.append(f"The native output {expected['name']} needs declared data type {expected['type']}.")
            projection = (raw.get("publication") or {}).get("columns")
            if isinstance(projection, list) and expected["name"].casefold() not in {str(name).casefold() for name in projection}:
                why.append(f"Native column {expected['name']} is excluded by publication.columns. Review the publication list in Configuration.")
        if why:
            for message in dict.fromkeys(why):
                block(row, message)
            continue
        source = row["values"]["source"]
        native_block, item, settings = _native(rule, source)
        report["emitted_columns"] = emitted_columns(rule)
        report["read_roles"] = [{"role": k, "source": source["logical_table"], "column": rule["column_roles"][k],
                                 "physical": source["columns"][rule["column_roles"][k]]} for k in required_roles(rule)]
        report["read_roles"].insert(0, {"role": "patientid", "source": source["logical_table"], "column": "patientid", "physical": source["columns"]["patientid"]})
        prepared.append((row, rule, native_block, item, settings, report))
    existing = _existing_outputs(clinical)
    owners = {}
    for owner, names in existing.items():
        for name in names:
            owners.setdefault(name.casefold(), set()).add(owner)
    try:
        from engine.validate import emitted_variables
        reserved = set(emitted_variables(cfg))
    except (AttributeError, TypeError, KeyError):
        reserved = set()  # Lightweight callers still receive exact clinical collision checks.
    tracked = {name for names in existing.values() for name in names}
    reserved -= tracked
    # emitted_variables is a label-level catalogue. The physical ADS also has
    # these native keys, helper fields and paired codes; none can be overwritten
    # by a new clinical name just because the catalogue lists only its label.
    reserved.update({"patientid", "index_date", "cohort", "cohortn", "cohortu", "cohortun",
        "lotcat", "lotcatn", "treat_flag", "data_product_id", "data_refresh", "spec_version",
        "advanceddiagnosisdate", "age", "agegrl", "agegrln", "race", "racen", "eth", "ethn",
        "regionl", "regionln", "practic", "practicn", "f_death", "dthdt", "dthfl", "fu_enddt",
        "fued", "dthfufl_dur", "dthfufl", "dth_before_fued"})
    if clinical.get("staging"):
        reserved.update({"stage", "stagen"})
    if clinical.get("vitals"):
        reserved.update({"height", "heightdt", "weight", "weightdt", "bmi", "bmigrl", "bmigrln"})
    for column in (clinical.get("passthrough") or {}).get("columns") or []:
        if column.get("bands"):
            reserved.add(str(column.get("as", column.get("column"))) + "n")
    # ECOG is native even when its block is absent.
    reserved -= {"ecog"}
    owners.setdefault("ecog", set()).add(("baseline_ecog", "ecog"))
    owners.setdefault("ecogn", set()).add(("baseline_ecog", "ecog"))
    seen = {}
    for row, rule, name, item, settings, report in prepared:
        owner = (name, rule["output_stem"])
        signature = (item, settings)
        if owner in seen and seen[owner] != signature:
            block(row, f"Two reviewed clinical rules disagree on native output stem {owner[1]}.")
        seen[owner] = signature
        for column in report["emitted_columns"]:
            key = column["name"].casefold()
            if owners.get(key, set()) - {owner} or key in {n.casefold() for n in reserved}:
                block(row, f"Native output {column['name']} collides with another configured output, including generated suffixes.")
            owners.setdefault(key, set()).add(owner)
    targets = {}
    for row, rule, name, item, settings, report in prepared:
        targets.setdefault(name, []).append((row, rule, item, settings, report))
    for name, items in targets.items():
        if name == "baseline_ecog":
            new = deepcopy(clinical.get(name) or {})
            new.pop("equidistant", None)
            new.pop("window", None)
            new.pop("window_days", None)
            new.update(items[0][3])
        elif name == "categoricals":
            new = deepcopy(clinical.get(name) or [])
            for row, rule, item, _, _ in items:
                index = next((i for i, old in enumerate(new) if old.get("name") == item["name"]), None)
                if index is None:
                    new.append(item)
                elif set(new[index]) - (set(item) | {"window", "window_days"}):
                    block(row, f"Existing categorical {item['name']} has additional native settings; review them before replacing this rule.")
                else:
                    new[index] = item
        else:
            from engine.clinical_panels import update as update_panel
            try:
                new = update_panel(clinical.get(name), name, [(item, settings) for _row, _rule, item, settings, _report in items])
            except ValueError as error:
                for row, *_ in items:
                    block(row, str(error))
                continue
        result["operations"].append({"path": "variables/clinical.yaml", "pointer": "/" + name, "value": new})
    for key in ("operations", "rows", "blockers"):
        result[key].extend(native_result[key])
    if native_result["rows"]:
        result["blockers"].extend(instruments.dependency_issues(all_rows, cfg, result))
        output_owners = {}
        for row in all_rows:
            rule = selection(row)
            if not rule or (row.get("values", {}).get("output") or {}).get("role") == "excluded":
                continue
            identity = (rule.get("operator"), rule.get("family"), rule.get("output_stem"))
            for column in emitted_columns(rule):
                name = column["name"].casefold()
                if name in output_owners and output_owners[name] != identity:
                    block(row, "Two reviewed calculations would overwrite output " + column["name"] + ".")
                output_owners[name] = identity
    if result["blockers"]:
        result["operations"] = []
    else:
        for report in result["rows"]:
            if report["status"] != "excluded":
                report["status"] = "compiled"
    return result
