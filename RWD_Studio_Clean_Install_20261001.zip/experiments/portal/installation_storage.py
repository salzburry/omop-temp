"""One persistent installation boundary for a single hosted authoring service.

The operator mounts durable storage; this module validates its layout, keeps
private areas separate from the Git workspace, and verifies offline backups.
It does not claim that a directory is durable merely because it exists.
"""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import tempfile
import uuid
import zipfile

MARKER = 'installation.json'
ROOT_ENV = 'RWDP_DATA_ROOT'
HOSTED_ENV = 'RWD_PORTAL_HOSTED_AUTHORING'
AREAS = ('workspace', 'state', 'sources')
MAX_MANIFEST = 16 * 1024 * 1024


def _safe(path):
    path = Path(path).absolute()
    if path.resolve() != path:
        raise ValueError('Installation storage cannot redirect through symbolic links.')
    return path


def logical_path(path):
    """One canonical spelling for identifiers, independent of Windows I/O syntax."""
    path = Path(path).resolve()
    text = str(path)
    if os.name == 'nt' and text.startswith('\\\\?\\'):
        text = '\\\\' + text[8:] if text[:8].casefold() == '\\\\?\\unc\\' else text[4:]
    return Path(text)


def io_path(path):
    """Use Windows extended paths for I/O after validating the logical path.

    Keep normal paths in scope identifiers, records and the UI. The prefix only
    removes Win32's legacy path-length limit; it grants no different access.
    """
    path = _safe(path)
    if os.name != 'nt':
        return path
    text = str(path)
    if text.startswith('\\\\?\\'):
        return path
    return Path('\\\\?\\UNC\\' + text[2:] if text.startswith('\\\\') else '\\\\?\\' + text)


def _hash(raw):
    return hashlib.sha256(raw).hexdigest()


def initialize(data_root):
    """Register an explicitly prepared persistent volume and its Git workspace."""
    root = _safe(data_root)
    workspace = _safe(root / 'workspace')
    source_install = ((workspace / 'experiments/portal/app.py').is_file()
                      and (workspace / 'platform/engine/build_ads.py').is_file())
    if not source_install:
        if any((workspace / entry).exists() for entry in ('experiments/portal/app.py', 'platform/engine/build_ads.py')):
            raise ValueError('The workspace contains an incomplete source installation. Use the complete source checkout or keep application code in the installed package.')
        # A wheel owns executable code; the mounted workspace owns authoring data.
        # Initializing a volume never copies code, invents reviewer identities or
        # supplies source evidence for an otherwise incomplete workspace.
        import yaml
        from rwd_services import package_asset
        registry = _safe(workspace / 'products/registry.yaml')
        governance = _safe(workspace / 'governance')
        if not registry.is_file() or not governance.is_dir():
            raise ValueError('Prepare DATA_ROOT/workspace with its products/registry.yaml and governance directory, then install the application package; a source checkout is also supported.')
        if registry.stat().st_size > 1024 * 1024:
            raise ValueError('The product registry exceeds the installation metadata limit.')
        try:
            document = yaml.safe_load(registry.read_bytes())
        except yaml.YAMLError as error:
            raise ValueError('Repair the product registry before initializing this installation.') from error
        if not isinstance(document, dict) or not isinstance(document.get('tumors'), list):
            raise ValueError('The product registry must declare its tumors list; use an empty list for a new installation.')
        for entry in ('experiments/portal/app.py', 'platform/engine/build_ads.py'):
            package_asset(entry)
    target = root / MARKER
    if target.exists():
        return layout(root)
    for area in AREAS:
        _safe(root / area).mkdir(parents=True, exist_ok=True)
    record = {'version': 1, 'installation_id': uuid.uuid4().hex,
              'layout': {area: area for area in AREAS}, 'deployment': 'single_authoring_host'}
    from experiments.portal import local_process_lock as locks
    with locks.locked(root / '.initialize.lock', root):
        if target.exists():
            return layout(root)
        fd, temporary = tempfile.mkstemp(prefix='.installation-', suffix='.tmp', dir=root)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as handle:
                json.dump(record, handle, indent=2)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, target)
        finally:
            Path(temporary).unlink(missing_ok=True)
    return layout(root)


def layout(data_root):
    root = _safe(data_root)
    target = _safe(root / MARKER)
    if not target.is_file() or target.stat().st_size > 8192:
        raise ValueError('Initialize the persistent installation with installation_storage.py init before enabling hosted editing.')
    value = json.loads(target.read_bytes())
    if (value.get('version') != 1 or value.get('layout') != {area: area for area in AREAS}
            or value.get('deployment') != 'single_authoring_host'
            or not isinstance(value.get('installation_id'), str)
            or len(value['installation_id']) != 32
            or any(c not in '0123456789abcdef' for c in value['installation_id'])):
        raise ValueError('The installation descriptor is invalid; restore its verified backup.')
    paths = {area: _safe(root / area) for area in AREAS}
    if any(not path.is_dir() for path in paths.values()):
        raise ValueError('Restore the complete installation: workspace, state and sources are required.')
    return {**value, 'root': root, **paths}


def configure(source_root, environ=None):
    """Resolve the managed workspace before importing modules with state globals."""
    env = os.environ if environ is None else environ
    hosted = env.get(HOSTED_ENV) == '1'
    if not env.get(ROOT_ENV):
        if hosted:
            raise ValueError('Hosted editing requires RWDP_DATA_ROOT on an operator-provisioned persistent volume.')
        return {'workspace': Path(source_root).resolve(), 'hosted_authoring': False}
    info = layout(env[ROOT_ENV])
    if hosted and any(env.get(key) == '1' for key in ('RWD_PORTAL_DEVELOPMENT', 'RWD_PORTAL_LOCAL_DEMO', 'RWD_PORTAL_LOCAL_WORKSPACE')):
        raise ValueError('Hosted editing uses the forwarded authenticated identity. Remove local/demo identity flags.')
    for key, area in (('RWDP_STATE_DIR', 'state'), ('RWD_SOURCE_WORKSPACE_DIR', 'sources')):
        if env.get(key) and Path(env[key]).resolve() != info[area]:
            raise ValueError(f'{key} must use the installation {area} directory; split storage is not supported in a managed installation.')
        env[key] = str(info[area])
    env['RWDP_INSTALLATION_ID'] = info['installation_id']
    return {**info, 'hosted_authoring': hosted}


def workspace_key(root, *, fallback=None):
    """Stable private-object namespace across restoring a managed installation."""
    path = Path(root).resolve()
    if path.name == 'workspace' and (path.parent / MARKER).is_file():
        return layout(path.parent)['installation_id'][:16]
    return fallback or _hash(str(logical_path(path)).encode())[:16]


@contextmanager
def lease(data_root):
    """One authoring process or offline maintenance operation per installation."""
    from experiments.portal import local_process_lock as locks
    info = layout(data_root)
    with locks.locked(info['root'] / '.authoring.lock', info['root']):
        yield info


def _inventory(info):
    paths = [info['root'] / MARKER]
    for area in AREAS:
        for path in info[area].rglob('*'):
            _safe(path)
            if not path.is_file() or path.name.endswith(('.lock', '.tmp', '.pyc')):
                continue
            if any(part in {'__pycache__', '.pytest_cache', '.venv', '.venv313', 'node_modules'} for part in path.relative_to(info[area]).parts):
                continue
            paths.append(path)
    return {path.relative_to(info['root']).as_posix(): _hash(path.read_bytes()) for path in sorted(paths)}


def backup(data_root, output):
    """Verified offline backup. Refuse while the authoring process holds its lease."""
    target = _safe(output)
    info = layout(data_root)
    # The hosted process may not have opened a browser session yet, so the
    # normal authoring lease is not sufficient to tell whether a live server
    # can mutate the installation.  Its receipt is the durable launch signal.
    receipt_path = info['root'] / '.hosted-process.json'
    if receipt_path.is_file():
        try:
            receipt = json.loads(receipt_path.read_text(encoding='utf-8'))
            from experiments.portal import local_process_lock
            alive = local_process_lock.process_alive(receipt)
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            raise ValueError('The hosted portal receipt cannot be checked safely. Stop the portal and inspect the installation before taking a backup.') from None
        if alive is True:
            raise ValueError('The installation is in use by a running portal. Stop it with launch_hosted --stop before taking a backup.')
        if alive is None:
            raise ValueError('The hosted portal owner cannot be verified safely. Stop it and inspect the receipt before taking a backup.')
    if target.is_relative_to(info['root']):
        raise ValueError('Save installation backups outside the installation directory.')
    if target.exists():
        raise FileExistsError('Choose a new backup filename; verified backups are never overwritten.')
    with lease(data_root):
        before = _inventory(info)
        fd, temporary = tempfile.mkstemp(prefix='.backup-', suffix='.tmp', dir=target.parent)
        os.close(fd)
        try:
            with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED) as archive:
                for name, digest in before.items():
                    raw = (info['root'] / name).read_bytes()
                    if _hash(raw) != digest:
                        raise ValueError('Installation changed during backup; stop its workers and retry with a new backup filename.')
                    archive.writestr(name, raw)
                archive.writestr('BACKUP_MANIFEST.json', json.dumps({'version': 1,
                    'installation_id': info['installation_id'], 'files': before}, sort_keys=True))
            if _inventory(info) != before:
                raise ValueError('Installation changed during backup. Stop its workers before retrying.')
            verify_backup(temporary)
            with open(temporary, 'r+b') as handle:
                os.fsync(handle.fileno())
            # Publish only a fully verified archive, with no replacement race.
            if os.name == 'nt':
                os.rename(temporary, target)
            else:
                os.link(temporary, target)
        finally:
            Path(temporary).unlink(missing_ok=True)
        return {'files': len(before), 'sha256': _hash(target.read_bytes()), 'backup': str(target)}


def verify_backup(path):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(set(n.casefold() for n in names)) or 'BACKUP_MANIFEST.json' not in names:
            raise ValueError('The backup has duplicate files or no manifest.')
        if archive.getinfo('BACKUP_MANIFEST.json').file_size > MAX_MANIFEST:
            raise ValueError('The backup manifest exceeds its limit.')
        manifest = json.loads(archive.read('BACKUP_MANIFEST.json'))
        files = manifest.get('files')
        if manifest.get('version') != 1 or not isinstance(files, dict) or set(files) != set(names) - {'BACKUP_MANIFEST.json'}:
            raise ValueError('The backup inventory is invalid.')
        for name, digest in files.items():
            relative = PurePosixPath(name)
            if (not relative.parts or name != relative.as_posix() or relative.is_absolute() or '..' in relative.parts or '\\' in name or ':' in name
                    or (name != MARKER and relative.parts[0] not in AREAS)):
                raise ValueError('The backup contains an unsafe file location.')
            if archive.getinfo(name).file_size > 1024 * 1024 * 1024:
                raise ValueError('A backup member exceeds its supported size.')
            if _hash(archive.read(name)) != digest:
                raise ValueError('The backup does not match its recorded content hashes.')
        return manifest


def restore(archive_path, destination):
    """Restore only into a fresh directory; existing installations are never overlaid."""
    manifest = verify_backup(archive_path)
    target = _safe(destination)
    if target.exists():
        raise ValueError('Restore into a new directory; existing installations are never overwritten.')
    target.mkdir(parents=True)
    with zipfile.ZipFile(archive_path) as archive:
        for name in manifest['files']:
            path = _safe(target / name)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(archive.read(name))
    for area in AREAS:
        (target / area).mkdir(exist_ok=True)
    info = layout(target)
    return {'root': str(target), 'installation_id': info['installation_id'], 'files': len(manifest['files'])}


def main(argv=None):
    """Run one storage operation and return a useful JSON error, never a traceback."""
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['init', 'check', 'backup', 'restore'])
    parser.add_argument('--data-root', required=True)
    parser.add_argument('--archive')
    args = parser.parse_args(argv)
    if args.command in {'backup', 'restore'} and not args.archive:
        parser.error('--archive is required for backup/restore')
    try:
        result = (initialize(args.data_root) if args.command == 'init' else layout(args.data_root)
                  if args.command == 'check' else backup(args.data_root, args.archive)
                  if args.command == 'backup' else restore(args.archive, args.data_root))
    except (OSError, ValueError, TypeError, KeyError, zipfile.BadZipFile) as error:
        print(json.dumps({'ok': False, 'error': str(error) or type(error).__name__}, indent=2))
        return 1
    print(json.dumps({'ok': True, **result} if isinstance(result, dict) else result, default=str, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
