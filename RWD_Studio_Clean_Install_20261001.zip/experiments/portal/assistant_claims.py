"""Reject unsupported action receipts in model-authored conversational prose.

This is a defensive language check, not an authorization mechanism. Actual
results still come only from typed application operations, never this prose.
"""
import re
import unicodedata

_FIRST_PERSON = re.compile(
    r"\b(?:i|we)\s+(?:(?:have|just|successfully|already|now)\s+)*"
    r"(?:saved|approved|signed|released|published|committed|staged|deleted|removed|"
    r"updated|changed|applied|executed|ran|built|completed|verified|validated|enrolled)\b", re.I)
_PASSIVE = re.compile(
    r"\b(?:the|this|your|all)\s+(?:(?:selected|requested|scientific|source|output|"
    r"current|reviewed)\s+)*(?:variables?|definitions?|mapping|draft|product|dataset|"
    r"configuration|changes?|files?|reviews?|results?)\s+"
    r"(?:(?:is|are|was|were|has been|have been)\s+)(?:(?:now|successfully|already)\s+)*"
    r"(?:saved|approved|signed|released|published|committed|staged|updated|applied|"
    r"verified|validated|complete|ready for release)\b", re.I)
_CHECK = re.compile(
    r"\b(?:(?:the|all|your|these)\s+)?(?:validation|checks?|tests?|build)\s+"
    r"(?:(?:has|have|is|are|was|were)\s+)?(?:(?:now|successfully|already)\s+)*"
    r"(?:passed|succeeded|complete|completed|successful)\b", re.I)
_CONDITIONAL = re.compile(r"\b(?:if|when|once|unless|until|whether|ensure|confirm|check that)\b[^.!?;]*$", re.I)


def unsupported_completion(text):
    """Identify affirmative completion claims; retain questions/conditional advice.

Verified operation results should be rendered from their application receipt
separately. A model never gets permission to issue its own completion receipt.
"""
    value = unicodedata.normalize('NFKC', str(text)).replace('\u2019', "'")
    value = re.sub(r"\b(I|we)'ve\b", r'\1 have', value, flags=re.I)
    value = re.sub(r'[*_`]', '', value)
    for sentence in re.split(r'(?<=[.!?;])\s+|\n+', value):
        for pattern in (_FIRST_PERSON, _PASSIVE, _CHECK):
            for match in pattern.finditer(sentence):
                prefix = sentence[:match.start()]
                if sentence.rstrip().endswith('?') or _CONDITIONAL.search(prefix):
                    continue
                return True
    return False
