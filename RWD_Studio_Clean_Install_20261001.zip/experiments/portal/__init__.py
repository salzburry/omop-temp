"""Portal package; importing it performs no path setup or workspace mutation."""
