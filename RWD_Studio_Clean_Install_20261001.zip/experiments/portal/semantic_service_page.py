"""Explicit advanced graph actions; ordinary knowledge browsing stays lightweight."""
from __future__ import annotations

import streamlit as st

PREFIX = 'semantic_service_'


def render(root, pack, actor_id, *, allowed_packs):
    from experiments.portal import authoring_session
    from experiments.portal import semantic_export_workspace as exports
    from rwd_services import semantic_execution, semantic_query
    context = (str(root), pack, actor_id, tuple(sorted(allowed_packs or [])))
    if st.session_state.get(PREFIX + 'context') != context:
        for key in list(st.session_state):
            if str(key).startswith(PREFIX):
                st.session_state.pop(key, None)
        st.session_state[PREFIX + 'context'] = context
    if not st.toggle('Query or prepare configuration from a saved graph', key=PREFIX + 'open'):
        return
    current = exports.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not current.get('ok'):
        st.info('Prepare a current reviewed semantic export before using these tools.')
        return
    versions = {item['id']: item for item in current['versions']}
    if not versions:
        st.info('Save a SHACL-validated version in the semantic export workflow first.')
        return
    version = st.selectbox('Saved graph version', list(versions), key=PREFIX + 'version',
        format_func=lambda value: versions[value]['created_at'] + ' · ' + value[:8])
    binding = (version, current['input_digest'])
    if st.session_state.get(PREFIX + 'binding') != binding:
        st.session_state[PREFIX + 'binding'] = binding
        st.session_state.pop(PREFIX + 'query_result', None)
        st.session_state.pop(PREFIX + 'compilation', None)
        st.session_state.pop(PREFIX + 'confirm', None)
        st.session_state.pop(PREFIX + 'staged', None)
    with st.expander('Ask the graph'):
        st.caption('Read this product’s asserted graph, or inspect optional OWL 2 RL inferences. Inference does not validate clinical meaning or change configuration.')
        query = st.text_area('SELECT or ASK query', value='SELECT ?subject ?predicate ?object WHERE { ?subject ?predicate ?object } LIMIT 25',
            key=PREFIX + 'query', max_chars=12000)
        inference = st.checkbox('Include OWL 2 RL inferred statements', key=PREFIX + 'inference')
        if st.session_state.get(PREFIX + 'query_basis') != (query, inference):
            st.session_state[PREFIX + 'query_basis'] = (query, inference)
            st.session_state.pop(PREFIX + 'query_result', None)
        if st.button('Run graph query', key=PREFIX + 'run_query'):
            with st.spinner('Reading the exact saved graph…'):
                st.session_state[PREFIX + 'query_result'] = semantic_query.query(root, pack, actor_id, version, query,
                    inference=inference, allowed_packs=allowed_packs)
        result = st.session_state.get(PREFIX + 'query_result')
        if result:
            if result['ok']:
                st.caption(result['notice'])
                if result['kind'] == 'ASK':
                    st.write('Query result: ' + str(result['boolean']))
                else:
                    st.dataframe([{key: (value or {}).get('value') for key, value in row.items()} for row in result['rows']],
                        hide_index=True, width='stretch')
                    if result['truncated']:
                        st.info('More matches exist. Narrow the query to inspect the remaining results.')
                st.caption(f"{result['asserted_triples']} asserted triples · {result['inferred_triples']} inferred triples")
            else:
                for error in result['errors']:
                    st.error(error)
    with st.expander('Prepare configuration from this graph'):
        st.caption('This verifies the graph’s rule digests against the current approved canonical definitions and completed source/output reviews. Graph edits and inferred statements cannot author new calculations.')
        if st.button('Preview graph configuration', key=PREFIX + 'preview'):
            st.session_state.pop(PREFIX + 'confirm', None)
            with st.spinner('Verifying canonical rules and configuration…'):
                st.session_state[PREFIX + 'compilation'] = semantic_execution.prepare(root, pack, actor_id, version,
                    allowed_packs=allowed_packs)
        compilation = st.session_state.get(PREFIX + 'compilation')
        if not compilation:
            return
        if not compilation['ok']:
            for error in compilation['errors']:
                st.error(error)
            return
        st.dataframe(compilation['rules'], hide_index=True, width='stretch')
        for change in compilation['plan']['files']:
            st.write(change.get('path', 'Configuration change'))
            st.code(change.get('diff') or change.get('after', ''), language='diff')
        st.caption(compilation['notice'])
        if not compilation['plan']['can_stage']:
            st.info('The supported configuration already matches. Continue with its normal validation workflow.')
            return
        permitted = authoring_session.can_edit()
        confirmed = st.checkbox('I reviewed this exact graph and configuration diff.', key=PREFIX + 'confirm', disabled=not permitted)
        if st.button('Stage configuration for review', key=PREFIX + 'stage', disabled=not permitted or not confirmed):
            result = semantic_execution.stage(root, pack, actor_id, version,
                expected_compilation_digest=compilation['compilation_digest'], confirmed=True,
                local_demo=True, can_write=True, allowed_packs=allowed_packs)
            if result['ok']:
                st.session_state[PREFIX + 'staged'] = result['proposal_id']
                st.success('Configuration proposal staged for review. No configuration was installed or executed.')
                st.caption('Proposal: ' + result['proposal_id'])
                for warning in result.get('warnings', []):
                    st.warning(warning)
            else:
                for error in result['errors']:
                    st.error(error)
        if st.session_state.get(PREFIX + 'staged') and st.button('Open staged configuration proposal', key=PREFIX + 'open_staged'):
            return {'route': 'plan_changes', 'params': {'proposal_id': st.session_state[PREFIX + 'staged'], 'intent': 'configuration'}}
