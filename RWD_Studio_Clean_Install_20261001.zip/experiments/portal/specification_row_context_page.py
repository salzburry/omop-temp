"""Small repair controls for rows that describe a document rather than a variable."""
import hashlib

import streamlit as st
from experiments.portal import specification_row_context as context

PREFIX = "spec_row_context_"


def _key(root, pack, actor_id, item_id):
    return PREFIX + hashlib.sha256(repr((str(root), pack, actor_id, item_id)).encode()).hexdigest()[:20]


def _form(root, pack, actor_id, row, *, restore, local_demo, can_write, allowed_packs):
    key = _key(root, pack, actor_id, row["item_id"]) + ("_restore" if restore else "_classify")
    cached = st.session_state.get(key + "_snapshot")
    if cached is None:
        cached = context.describe(root, pack, actor_id, row["item_id"], allowed_packs=allowed_packs)
        st.session_state[key + "_snapshot"] = cached
    if not cached.get("ok"):
        for error in cached.get("errors", []):
            st.warning(error)
    else:
        st.caption("Source citation: " + row["item_id"])
        if cached.get("cited"):
            st.info("A contract record already cites this row. Review that record before changing this classification.")
        elif not cached.get("can_restore" if restore else "can_classify"):
            st.info("This row already has another recorded disposition. Review that decision before changing it here.")
        else:
            reason = st.text_input("Why should this row return to the variable list?" if restore else "Why is this document metadata?",
                                   key=key + "_reason", disabled=not (local_demo and can_write))
            if st.button("Restore as variable" if restore else "This row is document metadata", key=key + "_save",
                         disabled=not (local_demo and can_write)):
                result = context.save(root, pack, actor_id, row["item_id"], reason,
                    expected_digest=cached["digest"], allowed_packs=allowed_packs,
                    local_demo=local_demo, can_write=can_write, restore=restore)
                if result.get("ok"):
                    st.session_state.pop(key + "_snapshot", None)
                    st.success(result["message"])
                    return bool(result.get("changed"))
                for error in result.get("errors", []):
                    st.error(error)
    if st.button("Reload row classification", key=key + "_reload"):
        st.session_state.pop(key + "_snapshot", None)
        st.rerun()
    return False


def render(root, pack, actor_id, row, *, local_demo, can_write, allowed_packs=None):
    with st.expander("Is this row document metadata rather than a variable?", expanded=False):
        st.caption("Use this for document or dataset descriptions. The original source row and citation stay available; you can restore the variable later.")
        return _form(root, pack, actor_id, row, restore=False, local_demo=local_demo,
                     can_write=can_write, allowed_packs=allowed_packs)


def render_context_rows(root, pack, actor_id, rows, *, local_demo, can_write, allowed_packs=None):
    if not rows:
        return False
    with st.expander(f"Document metadata ({len(rows)})", expanded=False):
        options = {row["item_id"]: row for row in rows}
        key = _key(root, pack, actor_id, "context-list")
        if st.session_state.get(key) not in options:
            st.session_state.pop(key, None)
        selected = st.selectbox("Inspect a metadata row", list(options), key=key,
                                format_func=lambda item: f"{options[item]['variable_id']} · {item}")
        row = options[selected]
        st.write(row.get("definition") or row.get("variable_id") or "Source row")
        if row.get("context_reason"):
            st.caption("Reason: " + row["context_reason"])
        if row.get("context_handled_by"):
            st.caption(row["context_handled_by"])
        if row.get("context_stale"):
            st.warning("The source row changed after it was classified. It is back in the variable list until reviewed again.")
        return _form(root, pack, actor_id, row, restore=True, local_demo=local_demo,
                     can_write=can_write, allowed_packs=allowed_packs)
