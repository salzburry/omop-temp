"""Human editing of existing, declared workflow records; validation remains authoritative."""
from __future__ import annotations

import copy
from collections import Counter
from contextlib import ExitStack
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import re
import tempfile
import uuid

import yaml

from rwd_tools import contract_lint as cl
from rwd_tools import flow
from experiments.portal import specification_details as details

MAX_BYTES = 512 * 1024
NOTICE = "Saving records your draft edit. It does not authenticate an approval, seal an event, prove scientific validity, run a build or release a product. Check status after saving."
SECRET_FIELDS = {"password", "access_token", "refresh_token", "client_secret", "private_key", "privatekey", "credentials", "credential", "api_key", "token", "secret", "authorization", "ssh_private_key", "gpg_private_key"}
PROTECTED_FIELDS = {"object_uuid", "signature", "signatures", "countersignature", "countersignatures", "key_id"}
EXCLUDED = {"source_refs.yaml", "handoff/decision_answers"}
SECRET_FILES = {"allowed_signers.yaml", "signing_keys.yaml", "private_key.yaml", "public_key.yaml", "secrets.yaml", "credentials.yaml"}


def _fail(message):
    return {"ok": False, "changed": False, "errors": [str(message)], "paths": [], "fields": [], "text": "", "digest": "", "notice": NOTICE}


def _scope(root, pack, action, path, allowed_packs):
    # Reuse canonical pack/scope checks; source_refs itself need not exist.
    source, pack = details._paths(root, pack, allowed_packs)
    root, product = Path(root).resolve(), source.parent
    aid = action.get("id") if isinstance(action, dict) else action
    menu = [item for items in flow.acts(pack, str(root)).values() for item in items]
    current = next((item for item in menu if item["id"] == aid and item["kind"] == flow.PERSON), None)
    if current is None:
        raise details._Invalid("This workflow action is no longer available for human record editing. Check status again.")
    declared = str(current.get("path") or "").replace("\\", "/")
    paths = []
    if declared.startswith(pack + "/"):
        relative = declared[len(pack) + 1:]
        if relative not in EXCLUDED and not relative.startswith("handoff/decision_answers/"):
            paths.append(relative)
    if aid == "g2_draft":
        paths = ["handoff/FUNCTIONAL_CONTRACT.md"]
    if aid == "g2_registers":
        paths = ["handoff/DECISIONS.md", "handoff/SPEC_QC_FINDINGS.md"]
    if aid == "g4_author":
        paths = [file.relative_to(product).as_posix() for directory in ("config", "variables", "codelists")
                 for file in sorted((product / directory).rglob("*.yaml"))]
    if aid == "g4_publication":
        pipeline = product / "config/pipeline.yaml"
        if pipeline.is_file() and "publication" in (_read(pipeline)[2] or {}):
            from engine.config import PUBLICATION_LOCATION_MESSAGE
            raise details._Invalid(PUBLICATION_LOCATION_MESSAGE + " In Other resolution steps, choose Prepare the build rules, "
                "select config/pipeline.yaml and Document, remove only the publication section, then confirm and save. "
                "Return to Review the delivered columns to select and confirm the list in config/data_product.yaml.")
    paths = [p for p in paths if Path(p).suffix.lower() in {".yaml", ".yml", ".md", ".txt"}
             and p != "source_refs.yaml" and Path(p).name.lower() not in SECRET_FILES]
    if not paths:
        raise details._Invalid("This action has no supported product record to edit here. Use its dedicated form or preparation action.")
    requested = str(path or (pack + "/" + paths[0])).replace("\\", "/")
    relative = requested[len(pack) + 1:] if requested.startswith(pack + "/") else requested
    if relative not in paths:
        raise details._Invalid("The requested file is outside this workflow action's declared product records.")
    target = product / relative
    if target.resolve() != target or not target.is_file():
        raise details._Invalid("The selected workflow record is missing or redirects elsewhere. Prepare it through the declared template or scaffold action before editing.")
    return root, pack, product, target, [pack + "/" + p for p in paths]


def _yaml(text):
    if any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(text)):
        raise details._Invalid("YAML aliases need a data expert's review before this record can be edited.")
    doc = yaml.load(text, Loader=details._StrictLoader)
    if not isinstance(doc, (dict, list)):
        raise details._Invalid("A workflow YAML record must contain a mapping or list.")
    return doc


def _walk(value, at=(), depth=0):
    if depth > 15:
        raise details._Invalid("The record is nested too deeply for this editor.")
    if isinstance(value, dict):
        for key, child in value.items():
            if str(key).lower().replace("-", "_") in SECRET_FIELDS:
                raise details._Invalid("This record contains credential fields and must be handled in its secure configuration workflow.")
            yield from _walk(child, (*at, key), depth + 1)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from _walk(child, (*at, index), depth + 1)
    else:
        if not isinstance(value, (str, int, float, bool, datetime.date, type(None))):
            raise details._Invalid("The YAML record contains an unsupported scalar value.")
        if isinstance(value, float) and not math.isfinite(value):
            raise details._Invalid("Numeric fields must be finite values.")
        yield at, value


def _read(path):
    if path.resolve() != path:
        raise details._Invalid("The record redirects to another location.")
    with path.open("rb") as handle:
        raw = handle.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise details._Invalid("This record exceeds the editor's 512 KB limit.")
    text = raw.decode("utf-8")
    if "PRIVATE KEY-----" in text:
        raise details._Invalid("Private signing material cannot be read or edited through this workflow.")
    doc = _yaml(text) if path.suffix.lower() in {".yaml", ".yml"} else None
    leaves = list(_walk(doc)) if doc is not None else []
    if len(leaves) > 2000:
        raise details._Invalid("The YAML record exceeds this editor's 2,000-field limit.")
    return raw, text, doc, leaves


def _description(root, pack, path, paths, raw, text, doc, leaves):
    fields = [{"id": json.dumps(at, separators=(",", ":")), "path": list(at),
               "label": " / ".join(str(part) for part in at), "value": value,
               "kind": "bool" if isinstance(value, bool) else "number" if isinstance(value, (int, float)) else "date" if isinstance(value, datetime.date) else "text",
               "editable": not any(str(part).lower() in PROTECTED_FIELDS for part in at)} for at, value in leaves]
    return {"ok": True, "pack": pack, "path": path.relative_to(root).as_posix(), "paths": paths,
            "format": "yaml" if doc is not None else "markdown" if path.suffix.lower() == ".md" else "text",
            "text": text, "digest": hashlib.sha256(raw).hexdigest(), "fields": fields, "errors": [], "notice": NOTICE}


def describe(root, pack, action, path=None, allowed_packs=None):
    try:
        root, pack, product, target, paths = _scope(root, pack, action, path, allowed_packs)
        result = _description(root, pack, target, paths, *_read(target))
        if (action.get("id") if isinstance(action, dict) else action) == "g4_publication":
            result["publication"] = _publication_context(root, product)
        return result
    except (details._Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError, KeyError) as error:
        return _fail(str(error) if isinstance(error, details._Invalid) else "The workflow record could not be read safely.")


def _scaffold_metadata_plan(root, pack, allowed_packs):
    from rwd_tools import new_product
    from experiments.portal import authoring_session
    authoring_session.check_scope(root, pack)
    base, pack, product, _target, _paths = _scope(root, pack, "g4_author", None, allowed_packs)
    if not pack.startswith("products/"):
        raise details._Invalid("Scaffold metadata repair belongs to a registered product.")
    registry_path = base / "products/registry.yaml"
    registry_raw, _text, registry, _leaves = _read(registry_path)
    if not isinstance(registry, dict) or not isinstance(registry.get("tumors"), list):
        raise details._Invalid("The product registry must contain its declared product list before repairing metadata.")
    family, slug = pack.split("/")[1:3]
    entries = [row for row in registry.get("tumors", []) if isinstance(row, dict)
               and row.get("slug") == slug and row.get("family", "oncology") == family]
    if len(entries) != 1 or not isinstance(entries[0].get("name"), str):
        raise details._Invalid("The product needs one unambiguous registered identity before repairing its metadata.")
    name = entries[0]["name"].strip()
    files, inputs = [], {"products/registry.yaml": hashlib.sha256(registry_raw).hexdigest()}
    relatives = ["config/data_product.yaml", *(f"variables/{role}.yaml" for role in ("demographics", "clinical", "treatment", "outcomes"))]
    configuration = None
    for relative in relatives:
        path = product / relative
        if not path.exists() and relative.startswith("variables/"):
            inputs[pack + "/" + relative] = None
            continue
        raw, text, document, _leaves = _read(path)
        if not isinstance(document, dict):
            raise details._Invalid("Scaffold metadata requires a YAML mapping.")
        inputs[pack + "/" + relative] = hashlib.sha256(raw).hexdigest()
        if relative == "config/data_product.yaml":
            configuration = document
            if document.get("data_product_id") != slug + "_rwdp" or document.get("name") not in {name + " RWDP", "REPLACE_ME RWDP"}:
                raise details._Invalid("The registered product identity differs from its configuration. Review that identity before repairing metadata.")
        after, changes = new_product.scaffold_metadata_text(text, relative, slug=slug, name=name)
        if changes:
            if document.get("status") != "scaffold":
                raise details._Invalid("Only scaffold metadata can be initialized here. Review an active file through its normal change workflow.")
            files.append({"path": relative, "before": text, "after": after,
                          "changes": [{"field": key, "before": document[key], "after": value} for key, value in changes.items()]})
    if files and (configuration.get("status") != "scaffold" or configuration.get("request_type") != "new_product"):
        raise details._Invalid("Only a fresh product scaffold can use this metadata repair; existing cuts need their normal change review.")
    digest = hashlib.sha256(json.dumps({"pack": pack, "identity": {"slug": slug, "name": name}, "inputs": inputs}, sort_keys=True).encode()).hexdigest()
    return base, product, files, inputs, digest


def scaffold_metadata_preview(root, pack, *, allowed_packs=None):
    """Read-only exact metadata diff; no scientific setting is proposed or approved."""
    try:
        _base, _product, files, _inputs, digest = _scaffold_metadata_plan(root, pack, allowed_packs)
        return {"ok": True, "needed": bool(files), "digest": digest, "files": files, "errors": [],
                "notice": "These edits fill product labels only. Scientific rules, runtime locations and approval status stay unchanged."}
    except (OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, KeyError) as error:
        return {"ok": False, "needed": False, "digest": "", "files": [], "errors": [str(error)]}


def repair_scaffold_metadata(root, pack, actor_id, *, expected_digest, confirmed=False,
                             local_demo=False, can_review=False, allowed_packs=None):
    """Confirm one pinned metadata-only draft transaction using the existing installer."""
    from rwd_tools import new_product
    from experiments.portal import authoring_session
    try:
        if local_demo is not True or can_review is not True or confirmed is not True:
            raise details._Invalid("Confirm the metadata preview in an authorized draft-editing session before saving.")
        if not isinstance(actor_id, str) or not actor_id.strip() or len(actor_id) > 200 or any(ord(c) < 32 for c in actor_id):
            raise details._Invalid("An identified draft editor is required.")
        authoring_session.check_scope(root, pack, actor_id)
        authoring_session.require_edit()
        with new_product._standup_guard(root), ExitStack() as locks:
            if (Path(root).resolve() / new_product.INSTALL_JOURNAL).exists():
                raise details._Invalid("An earlier installation needs recovery before a new metadata edit can be saved.")
            base, product, files, inputs, digest = _scaffold_metadata_plan(root, pack, allowed_packs)
            if expected_digest != digest:
                raise details._Invalid("The product or its registered identity changed. Reload the metadata preview.")
            if not files:
                return {"ok": True, "changed": False, "errors": [], "paths": []}
            for file in files:
                target = product / file["path"]
                lock = target.with_name("." + target.name + ".portal-edit.lock")
                descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
                locks.callback(lock.unlink, missing_ok=True)
                locks.callback(os.close, descriptor)
            receipt_relative = pack + "/.portal-drafts/scaffold-metadata/" + uuid.uuid4().hex + ".json"
            receipt = {"version": 1, "pack": pack, "actor": actor_id.strip(), "input_digest": digest,
                "recorded_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "approved": False, "released": False,
                "files": [{"path": file["path"], "before_sha256": inputs[pack + "/" + file["path"]],
                           "after_sha256": hashlib.sha256(file["after"].encode()).hexdigest(), "changes": file["changes"]} for file in files]}
            expected = {pack + "/" + file["path"]: inputs[pack + "/" + file["path"]] for file in files}
            expected[receipt_relative] = None
            with tempfile.TemporaryDirectory(prefix="rwd-scaffold-metadata-") as temporary:
                staged = Path(temporary).resolve()
                for file in files:
                    target = staged / pack / file["path"]
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(file["after"].encode("utf-8"))
                target = staged / receipt_relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(json.dumps(receipt, indent=2), encoding="utf-8")
                if _scaffold_metadata_plan(root, pack, allowed_packs)[4] != digest:
                    raise details._Invalid("The product changed while preparing its metadata. Reload the preview.")
                authoring_session.check_scope(root, pack, actor_id)
                authoring_session.require_edit()
                new_product.install(base, staged, list(expected), _guarded=True, expected_before=expected)
            return {"ok": True, "changed": True, "errors": [], "paths": list(expected), "receipt": receipt_relative,
                    "approved": False, "released": False}
    except (OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, KeyError) as error:
        return {"ok": False, "changed": False, "errors": [str(error)], "paths": []}


def _omission_mapping(text, path, value=None, *, remove=False):
    """Replace one declared YAML entry, preserving text outside that entry."""
    document = _yaml(text)
    parent = document
    for part in path[:-1]:
        if not isinstance(parent, dict) or part not in parent:
            raise details._Invalid("The optional output mapping is missing or ambiguous.")
        parent = parent[part]
    if remove and len(path) > 1 and isinstance(parent, dict) and set(parent) == {path[-1]}:
        return _omission_mapping(text, path[:-1], {})
    node = yaml.compose(text)
    for key in path[:-1]:
        if not isinstance(node, yaml.MappingNode):
            raise details._Invalid("The optional output settings need an ordinary YAML mapping.")
        matches = [child for name, child in node.value if name.value == key]
        if len(matches) != 1:
            raise details._Invalid("The optional output mapping is missing or ambiguous.")
        node = matches[0]
    if not isinstance(node, yaml.MappingNode) or node.flow_style:
        raise details._Invalid("Optional output settings in flow-style mappings need the normal configuration editor.")
    pairs = [(name, child) for name, child in node.value if name.value == path[-1]]
    if not pairs:
        if remove:
            return text
        if len(path) != 1:
            raise details._Invalid("The optional output setting cannot be added in this layout.")
        return text + ("" if text.endswith("\n") else "\n") + yaml.safe_dump({path[-1]: value}, sort_keys=False)
    key, old = pairs[0]
    start = text.rfind("\n", 0, key.start_mark.index) + 1
    if text[start:key.start_mark.index].strip():
        raise details._Invalid("The optional output entry cannot be changed independently.")
    tail = old
    while isinstance(tail, (yaml.MappingNode, yaml.SequenceNode)) and not tail.flow_style and tail.value:
        tail = tail.value[-1][1] if isinstance(tail, yaml.MappingNode) else tail.value[-1]
    end = tail.end_mark.index
    if tail.end_mark.column != 0:
        newline = text.find("\n", end)
        end = len(text) if newline < 0 else newline + 1
    replacement = "" if remove else yaml.safe_dump({path[-1]: value}, sort_keys=False)
    if replacement and key.start_mark.column:
        replacement = "".join(" " * key.start_mark.column + line for line in replacement.splitlines(keepends=True))
    result = text[:start] + replacement + text[end:]
    updated = copy.deepcopy(document)
    parent = updated
    for part in path[:-1]:
        parent = parent[part]
    if remove:
        del parent[path[-1]]
    else:
        parent[path[-1]] = value
    if _yaml(result) != updated:
        raise details._Invalid("The proposed omission would change another YAML setting.")
    return result


def _treatment_omission_checks(product):
    from engine.config import load_config
    from engine import validate as native
    from rwd_tools import contract_binding as binding
    from experiments.portal import configuration_proposals as proposals
    cfg = load_config(product / "config/data_product.yaml")
    contract = product / "handoff/FUNCTIONAL_CONTRACT.md"
    if contract.is_file():
        text = _read(contract)[1]
        malformed = cl.table_shape_errors(text)
        for record in cl.typed_records(text, keep_unnamed=True):
            malformed.extend(cl.typed_errors(record))
            if record.axis("requirement") == "approved":
                raise details._Invalid("An approved scientific definition needs its normal change-review workflow.")
        if malformed:
            raise details._Invalid("Read the current contract before omitting outputs: " + " ".join(malformed))
    result = proposals._unfinished_native_checks(product)
    result["omitted_outputs"] = (native._omitted_treatment_problems(cfg) + native._omitted_survival_problems(cfg)
        + native._omitted_demographics_problems(cfg) + native._omitted_native_treatment_problems(cfg))
    result["binding"] = binding.check(str(product), binding.pack_yaml(str(product)))[0]
    result["completeness"] = binding._completeness_errors(str(product))[0]
    # Native exception text can include this private staging directory. Retain
    # the exact finding and product-relative filename across independent checks.
    prefixes = {str(product) + os.sep, product.as_posix() + "/"}
    prefixes.update(prefix.replace("\\", "\\\\") for prefix in tuple(prefixes))
    normalized = {}
    for name, findings in result.items():
        normalized[name] = []
        for finding in findings:
            message = str(finding)
            for prefix in sorted(prefixes, key=len, reverse=True):
                message = message.replace(prefix, "")
            normalized[name].append(message)
    return normalized


def _treatment_omission_snapshot(base, product):
    from experiments.portal import configuration_proposals as proposals, workflow_outputs
    references = workflow_outputs.declared_references(product, proposals._read)
    locks = {product / "handoff/.FUNCTIONAL_CONTRACT.md.portal-definition.lock",
        product / "config/.data_product.yaml.portal-edit.lock", product / "variables/.treatment.yaml.portal-edit.lock",
        product / "variables/.clinical.yaml.portal-edit.lock", product / "variables/.outcomes.yaml.portal-edit.lock",
        product / "variables/.demographics.yaml.portal-edit.lock"}
    files = {path for path in proposals._tree_files(product) if path not in locks and
        (not workflow_outputs.is_saved_output(path.relative_to(base).as_posix()) or path.resolve() in references)}
    for rel in (*proposals.SHARED_INPUTS, "work", "refreshes"):
        path = proposals._safe(base / rel)
        if path.is_dir():
            files.update(item for item in proposals._tree_files(path) if
                (item.name == proposals.study_pin.PINS if rel == "work" else item.suffix.lower() in {".yaml", ".yml", ".json"}))
        else:
            files.add(path)
    return hashlib.sha256(json.dumps({path.relative_to(base).as_posix(): proposals._fingerprint(path) if path.is_file() else None
        for path in sorted(files)}, sort_keys=True).encode()).hexdigest()


def _treatment_omission_engine_code():
    from engine import config as engine_config
    from rwd_tools import contract_binding
    result = {}
    for name, directory in (("runtime", Path(engine_config.__file__).resolve().parent), ("binding", contract_binding._engine_dir())):
        if directory is None:
            raise details._Invalid("The complete engine readers are unavailable for this preview.")
        directory = Path(directory).resolve()
        files = sorted(directory.rglob("*.py"))
        if not files:
            raise details._Invalid("The complete engine readers are unavailable for this preview.")
        result[name] = {path.relative_to(directory).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
    return result


def _treatment_omission_plan(root, pack, actor_id, omit_line_categories, omit_treatment_status, allowed_packs,
        omit_legacy_survival=False, omit_legacy_demographics=False, omit_legacy_treatment=False):
    from experiments.portal import authoring_session, configuration_proposals as proposals, source_workspace
    from engine import validate as native, config as engine_config, config_schema
    from rwd_tools import contract_binding
    selections = (omit_line_categories, omit_treatment_status, omit_legacy_survival, omit_legacy_demographics, omit_legacy_treatment)
    if any(type(value) is not bool for value in selections) or not any(selections):
        raise details._Invalid("Choose the optional template calculations to omit explicitly.")
    if not isinstance(actor_id, str) or not actor_id.strip() or len(actor_id) > 200 or any(ord(c) < 32 for c in actor_id):
        raise details._Invalid("An identified draft editor is required.")
    authoring_session.check_scope(root, pack, actor_id)
    base, pack, product, _target, _paths = _scope(root, pack, "g4_author", None, allowed_packs)
    if not pack.startswith("products/"):
        raise details._Invalid("Optional output setup belongs to a product draft, not a reference example.")
    config_raw, config_text, config, _ = _read(product / "config/data_product.yaml")
    if not isinstance(config, dict):
        raise details._Invalid("The product configuration must be a mapping before optional outputs can be reviewed.")
    if config.get("status") not in {"scaffold", "draft"} or config.get("request_type") != "new_product":
        raise details._Invalid("Only an unapproved new product draft can omit outputs here. Use normal configuration change review for an existing product.")
    maturity = product / "handoff/MATURITY.yaml"
    if not maturity.is_file():
        raise details._Invalid("Restore the product's draft maturity record before reviewing optional outputs.")
    document = _read(maturity)[2]
    if not isinstance(document, dict):
        raise details._Invalid("The product maturity record must be a readable mapping.")
    if (document.get("configuration") not in {"not_started", "draft"}
            or document.get("contract") not in {"not_started", "draft", "coverage_complete"}):
        raise details._Invalid("Only explicit, unapproved draft maturity can use this setup. Reviewed products need their normal change workflow before removing an output.")
    inputs = source_workspace._inputs(base, product)
    validation_snapshot = _treatment_omission_snapshot(base, product)
    code = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in {
        "editor": Path(__file__), "native": Path(native.__file__), "binding": Path(contract_binding.__file__),
        "contract": Path(cl.__file__), "configuration": Path(engine_config.__file__),
        "schema_reader": Path(config_schema.__file__), "schema": Path(config_schema.__file__).with_suffix(".json"),
        "preview": Path(proposals.__file__), "source_inputs": Path(source_workspace.__file__)}.items()}
    code["engine_sources"] = _treatment_omission_engine_code()
    files = []
    after_config = config_text
    if omit_line_categories or omit_legacy_treatment:
        relative = "variables/treatment.yaml"
        _raw, before_text, treatment, _ = _read(product / relative)
        if not isinstance(treatment, dict) or treatment.get("status") not in {"scaffold", "draft"}:
            raise details._Invalid("The treatment pack is no longer an unapproved draft.")
        after = before_text
        if omit_legacy_treatment:
            for key in treatment:
                if key not in engine_config.PACK_METADATA and key != "enabled":
                    after = _omission_mapping(after, [key], remove=True)
            after = _omission_mapping(after, ["enabled"], False)
        else:
            after = _omission_mapping(after, ["line_category_codelist"], remove=True)
            after = _omission_mapping(after, ["line_categories_enabled"], False)
        if after != before_text:
            files.append({"path": relative, "before": before_text, "after": after})
        if "treatment_categories" in (config.get("codelists") or {}):
            after_config = _omission_mapping(after_config, ["codelists", "treatment_categories"], remove=True)
    if omit_treatment_status or omit_legacy_treatment:
        after_config = _omission_mapping(after_config, ["treatment_status"], {"enabled": False})
    if omit_legacy_demographics:
        relative = "variables/demographics.yaml"
        _raw, before_text, settings, _ = _read(product / relative)
        if not isinstance(settings, dict) or settings.get("status") not in {"scaffold", "draft"}:
            raise details._Invalid("The demographics pack must be an unapproved draft.")
        after = before_text
        for key in settings:
            if key not in engine_config.PACK_METADATA and key != "enabled":
                after = _omission_mapping(after, [key], remove=True)
        after = _omission_mapping(after, ["enabled"], False)
        if after != before_text:
            files.append({"path": relative, "before": before_text, "after": after})
    if omit_legacy_survival:
        for relative in ("variables/clinical.yaml", "variables/outcomes.yaml"):
            _raw, before_text, settings, _ = _read(product / relative)
            if not isinstance(settings, dict) or settings.get("status") not in {"scaffold", "draft"}:
                raise details._Invalid("The clinical and outcomes packs must both be unapproved drafts.")
            if relative == "variables/clinical.yaml":
                after = _omission_mapping(before_text, ["death_date_imputation"], {"enabled": False})
            else:
                emits = settings.get("emits", [])
                if not isinstance(emits, list) or not all(isinstance(name, str) for name in emits):
                    raise details._Invalid("Review the outcomes output list before omitting template survival.")
                after = _omission_mapping(before_text, ["minimum_followup_enabled"], False)
                after = _omission_mapping(after, ["min_followup_days"], remove=True)
                after = _omission_mapping(after, ["visit_recency_days"], remove=True)
                after = _omission_mapping(after, ["overall_survival"], {})
                after = _omission_mapping(after, ["emits"], [name for name in emits if name not in {"id3mosfu", "os"}])
            if after != before_text:
                files.append({"path": relative, "before": before_text, "after": after})
    if after_config != config_text:
        files.append({"path": "config/data_product.yaml", "before": config_text, "after": after_config})
    with tempfile.TemporaryDirectory(prefix="rwd-optional-treatment-") as temporary:
        shadow = proposals._candidate(base, product, {"pack": pack, "files": []}, Path(temporary).resolve())
        before = _treatment_omission_checks(shadow)
        for file in files:
            (shadow / file["path"]).write_bytes(file["after"].encode("utf-8"))
        if omit_legacy_treatment and "lot" in config:
            candidate_cfg = engine_config.load_config(shadow / "config/data_product.yaml")
            if not engine_config.native_lot_required(candidate_cfg):
                after_config = _omission_mapping(after_config, ["lot"], remove=True)
                config_file = next((file for file in files if file["path"] == "config/data_product.yaml"), None)
                if config_file is None:
                    config_file = {"path": "config/data_product.yaml", "before": config_text}
                    files.append(config_file)
                config_file["after"] = after_config
                (shadow / config_file["path"]).write_bytes(after_config.encode("utf-8"))
        after = _treatment_omission_checks(shadow)
    blocking = list(after["omitted_outputs"])
    for key, errors in after.items():
        blocking.extend((Counter(map(str, errors)) - Counter(map(str, before[key]))).elements())
    if (source_workspace._inputs(base, product) != inputs or _treatment_omission_snapshot(base, product) != validation_snapshot
            or _treatment_omission_engine_code() != code["engine_sources"]):
        raise details._Invalid("The product or its shared review inputs changed during the preview. Reload it.")
    digest = hashlib.sha256(json.dumps({"pack": pack, "actor": actor_id, "inputs": inputs, "code": code,
        "validation_snapshot": validation_snapshot,
        "omit_line_categories": omit_line_categories, "omit_treatment_status": omit_treatment_status,
        "omit_legacy_survival": omit_legacy_survival, "omit_legacy_demographics": omit_legacy_demographics,
        "omit_legacy_treatment": omit_legacy_treatment}, sort_keys=True).encode()).hexdigest()
    return base, product, {"ok": True, "can_save": not blocking, "needed": bool(files), "digest": digest,
        "files": files, "errors": list(dict.fromkeys(blocking)), "checks": {"before": before, "after": after},
        "remaining_findings": [{"check": key, "message": str(error)} for key, errors in after.items() for error in errors],
        "notice": "This omits only the selected template calculations from an unapproved draft. Any required replacement calculations must still be drafted and reviewed. No approval or release is created."}, inputs


def treatment_omission_preview(root, pack, actor_id, *, omit_line_categories=False, omit_treatment_status=False,
        omit_legacy_survival=False, omit_legacy_demographics=False, omit_legacy_treatment=False, allowed_packs=None):
    try:
        return _treatment_omission_plan(root, pack, actor_id, omit_line_categories, omit_treatment_status,
            allowed_packs, omit_legacy_survival, omit_legacy_demographics, omit_legacy_treatment)[2]
    except (OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, KeyError, RecursionError) as error:
        return {"ok": False, "can_save": False, "needed": False, "digest": "", "files": [], "errors": [str(error)]}


def save_treatment_omission(root, pack, actor_id, *, expected_digest, omit_line_categories=False,
        omit_treatment_status=False, omit_legacy_survival=False, omit_legacy_demographics=False,
        omit_legacy_treatment=False, confirmed=False, local_demo=False, can_review=False, allowed_packs=None):
    from rwd_tools import new_product
    from experiments.portal import authoring_session, scientific_definitions
    try:
        if local_demo is not True or can_review is not True or confirmed is not True:
            raise details._Invalid("Confirm the displayed output omissions in an authorized local draft-editing session.")
        authoring_session.check_scope(root, pack, actor_id)
        authoring_session.require_edit()
        with new_product._standup_guard(root), ExitStack() as locks:
            if (Path(root).resolve() / new_product.INSTALL_JOURNAL).exists():
                raise details._Invalid("Recover the earlier installation before changing this draft.")
            base, product, preview, inputs = _treatment_omission_plan(root, pack, actor_id, omit_line_categories,
                omit_treatment_status, allowed_packs, omit_legacy_survival, omit_legacy_demographics, omit_legacy_treatment)
            if preview["digest"] != expected_digest or not preview["can_save"]:
                raise details._Invalid("Reload the omission preview and resolve its current findings before saving.")
            if not preview["needed"]:
                return {"ok": True, "changed": False, "approved": False, "released": False, "errors": []}
            lock_paths = [scientific_definitions._contract_lock(product)] + [
                (product / file["path"]).with_name("." + Path(file["path"]).name + ".portal-edit.lock") for file in preview["files"]]
            for lock in lock_paths:
                descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
                locks.callback(lock.unlink, missing_ok=True)
                locks.callback(os.close, descriptor)
            receipt_relative = pack + "/.portal-drafts/treatment-omissions/" + uuid.uuid4().hex + ".json"
            receipt = {"version": 1, "pack": pack, "actor": actor_id, "input_digest": expected_digest,
                "recorded_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "approved": False, "released": False,
                "omit_line_categories": omit_line_categories, "omit_treatment_status": omit_treatment_status,
                "omit_legacy_survival": omit_legacy_survival, "omit_legacy_demographics": omit_legacy_demographics,
                "omit_legacy_treatment": omit_legacy_treatment,
                "files": [{**file, "before_sha256": inputs[pack + "/" + file["path"]],
                    "after_sha256": hashlib.sha256(file["after"].encode()).hexdigest()} for file in preview["files"]],
                "checks": preview["checks"], "remaining_findings": preview["remaining_findings"]}
            expected = {pack + "/" + file["path"]: inputs[pack + "/" + file["path"]] for file in preview["files"]}
            expected[receipt_relative] = None
            with tempfile.TemporaryDirectory(prefix="rwd-treatment-omission-save-") as temporary:
                staged = Path(temporary).resolve()
                for file in preview["files"]:
                    target = staged / pack / file["path"]
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(file["after"].encode("utf-8"))
                receipt_file = staged / receipt_relative
                receipt_file.parent.mkdir(parents=True, exist_ok=True)
                receipt_file.write_text(json.dumps(receipt, indent=2), encoding="utf-8")
                latest = _treatment_omission_plan(root, pack, actor_id, omit_line_categories, omit_treatment_status,
                    allowed_packs, omit_legacy_survival, omit_legacy_demographics, omit_legacy_treatment)[2]
                if latest["digest"] != expected_digest or not latest["can_save"]:
                    raise details._Invalid("The product changed while preparing the omission. Reload the preview.")
                authoring_session.check_scope(root, pack, actor_id)
                authoring_session.require_edit()
                new_product.install(base, staged, list(expected), _guarded=True, expected_before=expected)
            return {"ok": True, "changed": True, "approved": False, "released": False, "errors": [], "receipt": receipt_relative}
    except (OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, KeyError, RecursionError) as error:
        return {"ok": False, "changed": False, "approved": False, "released": False, "errors": [str(error)]}


def _publication_context(root, product):
    from engine.config import load_config
    from engine.stages.assemble import PUBLICATION_MANDATORY
    from experiments.portal import source_workspace
    from rwd_tools import contract_binding

    inputs = source_workspace._inputs(root, product)
    cfg = load_config(product / "config/data_product.yaml", overrides={
        "run.refresh": "x", "run.source_schema": "x", "run.output_schema": "x"})
    mandatory = list(PUBLICATION_MANDATORY)
    available = sorted(contract_binding._execution_output_names(cfg) | set(mandatory))
    publication = cfg.raw.get("publication")
    if publication is not None and not isinstance(publication, dict):
        raise details._Invalid("The publication section must be a mapping before its columns can be selected.")
    current = (publication or {}).get("columns")
    if current is not None and (not isinstance(current, list) or not all(isinstance(item, str) for item in current)):
        raise details._Invalid("The publication columns must be a list of column names before they can be selected.")
    current = [name.strip().lower() for name in current] if current is not None else None
    contract = product / "handoff/FUNCTIONAL_CONTRACT.md"
    promised = sorted({name.lower() for record in cl.typed_records(contract.read_text(encoding="utf-8"))
        if record.output.get("role", "").strip() != "excluded"
        and (record.output.get("role", "").strip() == "published"
             or record.publish.get("ads", "").strip() in {"configured", "required"})
        for name in record.physical_names()}) if contract.exists() else []
    if source_workspace._inputs(root, product) != inputs:
        raise details._Invalid("The build rules or definitions changed while reading the delivered columns. Reload them.")
    return {"available": available, "mandatory": mandatory, "promised": promised, "current": current,
            "digest": hashlib.sha256(json.dumps(inputs, sort_keys=True).encode()).hexdigest()}


def _publication_text(original, columns):
    """Change only the publication list, preserving unrelated bytes and comments."""
    from experiments.portal.configuration_proposals import _insert_mapping_entry
    from experiments.portal.lifecycle_workspace import _own_end

    document = _yaml(original)
    if not isinstance(document, dict) or document.get("publication") is not None and not isinstance(document["publication"], dict):
        raise details._Invalid("The configuration and its publication section must be mappings.")
    expected = copy.deepcopy(document)
    expected["publication"] = {**(expected.get("publication") or {}), "columns": columns}
    tree = yaml.compose(original, Loader=details._StrictLoader)
    node = next((child for key, child in tree.value if key.value == "publication"), None)
    encoded = json.dumps(columns, ensure_ascii=False)
    if node is None:
        result = _insert_mapping_entry(original, tree, "publication", '{columns: ' + encoded + '}')
    elif isinstance(node, yaml.ScalarNode):
        prefix = " " if original[node.start_mark.index - 1:node.start_mark.index] == ":" else ""
        result = original[:node.start_mark.index] + prefix + '{columns: ' + encoded + '}' + original[node.end_mark.index:]
    else:
        value = next((child for key, child in node.value if key.value == "columns"), None)
        if value is None:
            result = _insert_mapping_entry(original, node, "columns", encoded)
        else:
            prefix = " " if original[value.start_mark.index - 1:value.start_mark.index] == ":" else ""
            # A block sequence may start at the same indentation as its key.
            # A flow sequence on the following line must be indented further.
            column_key = next(key for key, child in node.value if key.value == "columns")
            if (not getattr(value, "flow_style", False)
                    and value.start_mark.line > column_key.start_mark.line
                    and value.start_mark.column <= column_key.start_mark.column):
                prefix = " " * (column_key.start_mark.column + 2 - value.start_mark.column)
            result = original[:value.start_mark.index] + prefix + encoded + original[_own_end(value):]
    if _yaml(result) != expected:
        raise details._Invalid("The column selection would change another configuration value. Nothing was saved.")
    return result


def _same_type(old, new):
    if old is None:
        return new is None or isinstance(new, str)
    return type(old) is type(new)


def _scalar_edits(original, updates, by_id, expected):
    tree = yaml.compose(original, Loader=details._StrictLoader)
    replacements = []
    newline = "\r\n" if "\r\n" in original else "\n"
    for fid, value in updates.items():
        at, _old = by_id[fid]
        node = tree
        for part in at:
            if isinstance(node, yaml.MappingNode):
                node = next(child for key, child in node.value if key.value == part)
            elif isinstance(node, yaml.SequenceNode) and isinstance(part, int):
                node = node.value[part]
            else:
                raise details._Invalid("This YAML field cannot be changed without rewriting another structure.")
        if not isinstance(node, yaml.ScalarNode):
            raise details._Invalid("Only literal scalar values can be edited in the field view.")
        encoded = value.isoformat() if isinstance(value, datetime.date) else json.dumps(value, ensure_ascii=False)
        prefix = " " if node.start_mark.index and original[node.start_mark.index - 1] == ":" else ""
        suffix = newline if node.style in {"|", ">"} and original[node.start_mark.index:node.end_mark.index].endswith("\n") else ""
        replacements.append((node.start_mark.index, node.end_mark.index, prefix + encoded + suffix))
    result = original
    for start, end, value in sorted(replacements, reverse=True):
        result = result[:start] + value + result[end:]
    if _yaml(result) != expected:
        raise details._Invalid("This field edit would change another YAML value. Nothing was saved.")
    return result


def save(root, pack, action, path, *, expected_digest, text=None, updates=None, confirmed=False, local_demo,
         can_review, allowed_packs=None, receipt=None, build_id=None, candidate_path=None,
         publication_columns=None, expected_publication_digest=None):
    if local_demo is not True or can_review is not True or confirmed is not True:
        return _fail("Saving a workflow record requires reviewer access in a local session and your explicit confirmation of the edit.")
    if sum(value is not None for value in (text, updates, publication_columns)) != 1:
        return _fail("Provide either document text or field edits for one record.")
    if not isinstance(expected_digest, str) or not re.fullmatch(r"[0-9a-f]{64}", expected_digest):
        return _fail("Reload the current record before saving; its starting checksum is required.")
    lock_fd = None
    lock_path = temporary = None
    try:
        root, pack, product, target, paths = _scope(root, pack, action, path, allowed_packs)
        lock_path = target.with_name("." + target.name + ".portal-edit.lock")
        lock_fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        raw, original, doc, leaves = _read(target)
        if hashlib.sha256(raw).hexdigest() != expected_digest:
            raise details._Invalid("This record changed while the editor was open. Reload and compare the current version before saving.")
        if publication_columns is not None:
            from types import SimpleNamespace
            from engine.stages.assemble import publication_projection
            if (action.get("id") if isinstance(action, dict) else action) != "g4_publication":
                raise details._Invalid("Column selection belongs to the delivered-columns workflow action.")
            publication = _publication_context(root, product)
            if publication["digest"] != expected_publication_digest:
                raise details._Invalid("The build rules or contract changed while selecting columns. Reload and review the current outputs before saving.")
            if not isinstance(publication_columns, list) or not all(isinstance(name, str) for name in publication_columns):
                raise details._Invalid("Select column names from the available engine outputs.")
            columns, errors = publication_projection(SimpleNamespace(raw={"publication": {"columns": publication_columns}}), publication["available"])
            if errors:
                raise details._Invalid(" ".join(errors))
            text = _publication_text(original, columns)
        if updates is not None:
            if doc is None or not isinstance(updates, dict):
                raise details._Invalid("Field edits are supported only for YAML records.")
            by_id = {json.dumps(at, separators=(",", ":")): (at, value) for at, value in leaves}
            edited = copy.deepcopy(doc)
            for fid, value in updates.items():
                if fid not in by_id:
                    raise details._Invalid("A field changed or no longer exists. Reload before editing it.")
                at, old = by_id[fid]
                if not _same_type(old, value):
                    raise details._Invalid("A field edit changed its YAML type. Use the document view for an intentional structural change.")
                node = edited
                for key in at[:-1]:
                    node = node[key]
                node[at[-1]] = value
            text = _scalar_edits(original, updates, by_id, edited)
        if not isinstance(text, str) or not text.strip() or len(text.encode("utf-8")) > MAX_BYTES or any(ord(c) < 32 and c not in "\n\r\t" for c in text):
            raise details._Invalid("Enter a nonempty text record within the 512 KB limit, without control characters.")
        if "PRIVATE KEY-----" in text:
            raise details._Invalid("Private signing material cannot be saved in a workflow record.")
        new_doc = _yaml(text) if doc is not None else None
        new_leaves = list(_walk(new_doc)) if new_doc is not None else []
        if len(new_leaves) > 2000:
            raise details._Invalid("The YAML record exceeds this editor's 2,000-field limit.")
        if doc is not None and type(new_doc) is not type(doc):
            raise details._Invalid("The YAML record's top-level structure must remain the same kind.")
        if receipt is not None:
            from experiments.portal import workflow_forms
            aid = action.get("id") if isinstance(action, dict) else action
            if aid not in {"g5_validate", "g6_approve"} or target.name != "RELEASE_APPROVAL.yaml":
                raise details._Invalid("The selected candidate binding belongs to its release approval record.")
            candidate = workflow_forms.candidate_context(root, pack, receipt=receipt, build_id=build_id,
                candidate_path=candidate_path, allowed_packs=allowed_packs)
            if not candidate["ok"]:
                raise details._Invalid(" ".join(candidate["errors"]))
            if not isinstance(new_doc, dict) or any(new_doc.get(key) != value for key, value in candidate["digests"].items()):
                raise details._Invalid("The approval edits must name the selected build and its exact manifest digest. Correct both candidate identity fields before saving this review.")
        protected = lambda values: {json.dumps(at): value for at, value in values if any(str(part).lower() in PROTECTED_FIELDS for part in at)}
        if protected(leaves) != protected(new_leaves):
            raise details._Invalid("Event identifiers and signature fields belong to their governed tools and cannot be edited here.")
        if target.name == "DECISIONS.md":
            errors = cl.decision_register_errors(text, pack)
            if errors:
                raise details._Invalid("The decision table is malformed: " + " ".join(errors))
            old_rows, new_rows, statuses = cl.decision_rows(original), cl.decision_rows(text), cl.decision_status(original)
            if any(new_rows.get(did) != row for did, row in old_rows.items() if statuses.get(did) != "OPEN"):
                raise details._Invalid("An existing closed decision cannot be overwritten or removed. Create a new question and use the decision revision workflow.")
        replacement = text.encode("utf-8")
        if replacement == raw:
            return {**_description(root, pack, target, paths, raw, original, doc, leaves), "changed": False}
        with tempfile.NamedTemporaryFile(mode="wb", prefix=".workflow-record-", suffix=".tmp", dir=target.parent, delete=False) as handle:
            temporary = Path(handle.name)
            handle.write(replacement)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, target.stat().st_mode)
        current_root, current_pack, _product, current_target, _paths = _scope(root, pack, action, path, allowed_packs)
        if current_root != root or current_pack != pack or current_target != target or _read(target)[0] != raw:
            raise details._Invalid("This workflow record changed during the save. Reload before trying again.")
        if publication_columns is not None and _publication_context(root, product)["digest"] != expected_publication_digest:
            raise details._Invalid("The build rules or contract changed during the save. Reload before trying again.")
        if receipt is not None:
            current_candidate = workflow_forms.candidate_context(root, pack, receipt=receipt, build_id=build_id,
                candidate_path=candidate_path, allowed_packs=allowed_packs)
            if not current_candidate["ok"] or current_candidate["inputs"] != candidate["inputs"]:
                raise details._Invalid("The selected candidate evidence changed during the save. Reload and review its current identity.")
        os.replace(temporary, target)
        temporary = None
        return {**_description(root, pack, target, paths, replacement, text, new_doc, new_leaves), "changed": True}
    except FileExistsError:
        return _fail("Another edit is in progress for this record. Wait for it to finish, then reload.")
    except (details._Invalid, OSError, ValueError, TypeError, UnicodeError, yaml.YAMLError, RecursionError, KeyError) as error:
        return _fail(str(error) if isinstance(error, details._Invalid) else "The record could not be saved safely. The original file was retained.")
    finally:
        if temporary is not None:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
        if lock_fd is not None:
            os.close(lock_fd)
            try:
                lock_path.unlink(missing_ok=True)
            except OSError:
                pass
