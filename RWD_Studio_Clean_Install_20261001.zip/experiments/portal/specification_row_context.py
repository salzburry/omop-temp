"""Explicit, reversible document-context classifications in the canonical register.

The source extraction and its citations stay intact. Contract scaffold/coverage
consume the same spec_dispositions.yaml entry as the variable review queues.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile

import yaml
from rwd_tools import contract_scaffold as scaffold
from rwd_tools import contract_lint as cl
from experiments.portal import specification_details as details
from rwd_tools.spec_context_binding import BOUND as _BOUND, binding as _binding
from rwd_tools.spec_extract import requirement_rows, row_item_id

REGISTER = "handoff/spec_dispositions.yaml"


def _hash(value):
    raw = value if isinstance(value, bytes) else json.dumps(value, sort_keys=True, ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _known_rows(data):
    rows = []
    for raw in requirement_rows(data):
        definition, notes = scaffold._definition_and_notes(raw)
        rows.append({"item_id": row_item_id(raw), "variable_id": scaffold._scalar(raw.get("variable", "")),
                     "definition": definition, "notes": notes, "tab": raw.get("tab") or raw.get("domain"),
                     "row": raw["row"], "spec_fields": raw.get("fields") if isinstance(raw.get("fields"), dict) else {}})
    if len({row["item_id"] for row in rows}) != len(rows):
        raise ValueError("The extraction repeats a row citation. Repair the extraction before classifying document metadata.")
    return rows


def _read_register(product):
    from experiments.portal import scientific_definitions as definitions
    path = definitions._safe(Path(product) / REGISTER)
    raw = definitions._read(path) if path.exists() else b""
    text = raw.decode("utf-8")
    doc = yaml.load(text, Loader=details._StrictLoader) if text.strip() else {"items": {}}
    if not isinstance(doc, dict) or not isinstance(doc.get("items"), dict):
        raise ValueError("The specification disposition register must contain an items mapping before a row can be classified.")
    entries = doc["items"]
    canonical = scaffold.declared_dispositions(str(product))
    if set(entries) != set(canonical):
        raise ValueError("The disposition register uses unsupported row keys. Use quoted source-row citations before editing it here.")
    for item, entry in entries.items():
        if not isinstance(entry, dict) or not all(isinstance(key, str) and isinstance(value, str) for key, value in entry.items()):
            raise ValueError("Disposition entries must use the existing text-field schema.")
        if set(entry) - {"disposition", "handled_by", "note", "duplicate_of", "decision_id", "approved_by"}:
            raise ValueError("The disposition register contains unsupported entry fields. Review it before editing metadata rows.")
        if entry.get("disposition") != canonical[item].get("disposition"):
            raise ValueError("The disposition register cannot be read consistently by the existing coverage checks.")
    return path, raw, text, doc


def _validate(product, entries, rows, blocks):
    known = {row["item_id"] for row in rows}
    cited = {}
    for block in blocks:
        for ref in cl._list(block, "spec_refs") or []:
            for domain, number in scaffold.spec_ref_rows(ref):
                cited.setdefault((domain, number), []).append(cl._scalar(block, "variable_id") or "record")
    errors = scaffold.validate_dispositions(str(product), entries, known, cited=cited,
        row_text={row["item_id"]: " ".join((str(row.get("definition") or ""), str(row.get("notes") or ""))) for row in rows})
    if errors:
        raise ValueError("The specification disposition needs attention: " + "; ".join(errors))


def apply_context_dispositions(root, product, rows, blocks):
    """Filter valid context entries from normalized definition rows, retaining evidence."""
    _path, _raw, _text, doc = _read_register(product)
    contexts = {item: entry for item, entry in doc["items"].items() if entry.get("disposition") == "context"}
    if not contexts:
        return rows, []
    # Other dispositions remain governed by their existing workflows. This
    # repair action classifies document context only, never study exclusions.
    from experiments.portal import scientific_definitions as definitions
    known_rows = _known_rows(definitions._json(definitions._read(Path(product) / "spec_pipeline/out/extracted.json")))
    stale_items = scaffold.context_binding_issues(str(product), contexts)
    _validate(product, {item: entry for item, entry in contexts.items() if item not in stale_items}, known_rows, blocks)
    remaining, inspected = [], []
    for row in rows:
        entry = contexts.get(row["item_id"])
        if entry is None:
            remaining.append(row)
            continue
        match = _BOUND.match(entry.get("note", ""))
        stale = row["item_id"] in stale_items
        evidence = {key: deepcopy(value) for key, value in row.items() if key != "existing"}
        evidence.update(context_reason=match[2] if match else entry.get("note", ""),
                        context_handled_by=entry.get("handled_by", ""), context_stale=stale)
        inspected.append(evidence)
        if stale:
            remaining.append({**row, "context_stale": True})
    return remaining, inspected


def _load(root, pack, actor_id, item_id, allowed_packs):
    from experiments.portal import scientific_definitions as definitions
    product, pack, _owner, _folder = definitions._scope(root, pack, actor_id, allowed_packs)
    if not pack.startswith("products/"):
        raise ValueError("Create a working product before changing a source-row classification.")
    if not isinstance(actor_id, str) or not actor_id.strip() or len(actor_id) > 200 or any(ord(c) < 32 for c in actor_id):
        raise ValueError("Choose the current name and email profile before classifying this row.")
    before = definitions._snapshot(product)
    extraction = definitions._json(definitions._read(product / "spec_pipeline/out/extracted.json"))
    rows = _known_rows(extraction)
    row = next((item for item in rows if item["item_id"] == item_id), None)
    if row is None:
        raise ValueError("Choose a source row from the current specification.")
    text = definitions._read(product / "handoff/FUNCTIONAL_CONTRACT.md").decode("utf-8")
    blocks = list(cl.records(text))
    cited = any(item_id in (cl._list(block, "spec_refs") or []) or
                any(f"{domain}:{number}" == item_id for ref in cl._list(block, "spec_refs") or [] for domain, number in scaffold.spec_ref_rows(ref))
                for block in blocks)
    path, raw, register_text, document = _read_register(product)
    entry = document["items"].get(item_id)
    if definitions._snapshot(product) != before:
        raise ValueError("The product changed while this row loaded. Reload the classification.")
    return {"product": product, "pack": pack, "row": row, "rows": rows, "blocks": blocks, "cited": cited,
            "path": path, "raw": raw, "text": register_text, "document": document, "entry": entry,
            "digest": _hash({"product": before, "actor": actor_id.strip(), "item_id": item_id})}


def _fail(error):
    return {"ok": False, "changed": False, "errors": [str(error)], "approval_created": False}


def decision_links(root, pack, actor_id, *, allowed_packs=None):
    """Current source-row question links, including repair choices for retired links."""
    try:
        from experiments.portal import scientific_definitions as definitions
        product, pack, _owner, _folder = definitions._scope(root, pack, actor_id, allowed_packs)
        if not (product / REGISTER).is_file():
            return {"ok": True, "rows": [], "errors": []}
        before = definitions._snapshot(product)
        _path, _raw, _text, document = _read_register(product)
        entries = {item: entry for item, entry in document["items"].items() if entry.get("decision_id")}
        if not entries:
            return {"ok": True, "rows": [], "errors": []}
        register = definitions._read(product / "handoff/DECISIONS.md").decode("utf-8")
        questions, statuses = cl.decision_rows(register), cl.decision_status(register)
        source_rows = _known_rows(definitions._json(definitions._read(product / "spec_pipeline/out/extracted.json")))
        source_index = {row["item_id"]: row for row in source_rows}
        cited, _labels = scaffold.contract_citations(str(product / "handoff/FUNCTIONAL_CONTRACT.md"))
        candidates = scaffold.disposition_decisions(str(product), {did: {"decision_id": did} for did in questions})
        rows = []
        for item, entry in entries.items():
            source_row = source_index.get(item)
            if source_row is None:
                raise ValueError(f"{item} no longer exists in the current extraction. Review the revised specification before changing its question link.")
            did = entry["decision_id"]
            current = candidates.get(did, {"status": "MISSING", "errors": ["The linked question is missing. Choose its replacement or raise a new question."]})
            errors = scaffold.validate_dispositions(str(product), {item: entry}, set(source_index), cited=cited,
                row_text={item: " ".join((source_row["definition"], source_row["notes"]))})
            choices = []
            for candidate, question in questions.items():
                cited = {f"{domain}:{number}" for token in re.findall(r"[0-9A-Za-z._]+:\d+(?:-\d+)?", cl.decision_evidence(question))
                         for domain, number in scaffold.spec_ref_rows(token)}
                if item in cited and statuses.get(candidate) in {"OPEN", "RESOLVED"} and not candidates[candidate]["errors"]:
                    choices.append({"id": candidate, "question": cl.decision_question(question), "status": statuses[candidate]})
            rows.append({"item_id": item, "variable": source_row["variable_id"], "decision_id": did,
                         "status": current["status"], "answer": current.get("answer", ""),
                         "disposition": entry["disposition"], "handled_by": entry.get("handled_by", ""),
                         "errors": errors, "choices": choices,
                         "digest": _hash({"product": before, "actor": actor_id.strip(), "item_id": item}),
                         "cited": any((domain, number) in cited for domain, number in scaffold.spec_ref_rows(item))})
        if definitions._snapshot(product) != before:
            raise ValueError("The product changed while its linked questions loaded. Reload the current questions.")
        return {"ok": True, "rows": rows, "errors": []}
    except (OSError, ValueError, TypeError, KeyError, AttributeError, RecursionError, yaml.YAMLError) as error:
        return {**_fail(error), "rows": []}


def relink_decision(root, pack, actor_id, item_id, decision_id, *, expected_digest,
                    confirmed=False, allowed_packs=None, local_demo=False, can_write=False):
    """Repair one explicit question link; leave its classification and every other row intact."""
    temporary = None
    try:
        if local_demo is not True or can_write is not True or confirmed is not True:
            raise ValueError("Review and confirm the replacement question before changing this link.")
        state = _load(root, pack, actor_id, item_id, allowed_packs)
        with details.source_edit_lock(root, state["product"] / "source_refs.yaml"):
            state = _load(root, pack, actor_id, item_id, allowed_packs)
            if state["digest"] != expected_digest:
                raise ValueError("The source row or decision evidence changed. Reload the linked questions before saving.")
            existing = state["entry"]
            if not existing or not existing.get("decision_id") or state["cited"]:
                raise ValueError("This row has no repairable standalone decision link. Review its contract record instead.")
            options = decision_links(root, pack, actor_id, allowed_packs=allowed_packs)
            current = next((row for row in options.get("rows", []) if row["item_id"] == item_id), None)
            if not options.get("ok") or not current or decision_id not in {choice["id"] for choice in current["choices"]}:
                raise ValueError("Choose a current question that explicitly cites this specification row.")
            entry = {**existing, "decision_id": decision_id}
            _validate(state["product"], {item_id: entry}, state["rows"], state["blocks"])
            candidate = _replace_entry(state["text"], item_id, entry, "")
            expected = deepcopy(state["document"])
            expected["items"][item_id] = entry
            if yaml.load(candidate, Loader=details._StrictLoader) != expected:
                raise ValueError("The edit would change another disposition. Nothing was changed.")
            descriptor, name = tempfile.mkstemp(prefix=".decision-link-", suffix=".tmp", dir=state["path"].parent)
            temporary = Path(name)
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(candidate.encode("utf-8"))
                handle.flush()
                os.fsync(handle.fileno())
            if _load(root, pack, actor_id, item_id, allowed_packs)["digest"] != expected_digest:
                raise ValueError("The source row or decision evidence changed during this save. Reload before trying again.")
            os.replace(temporary, state["path"])
            temporary = None
        return {"ok": True, "changed": True, "errors": [], "approval_created": False,
                "message": "Question link updated. The row's classification is preserved; its scientific review and implementation remain separate."}
    except (OSError, ValueError, TypeError, KeyError, AttributeError, RecursionError, yaml.YAMLError) as error:
        return _fail(error)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def describe(root, pack, actor_id, item_id, *, allowed_packs=None):
    try:
        state = _load(root, pack, actor_id, item_id, allowed_packs)
        entry = state["entry"]
        context = bool(entry and entry.get("disposition") == "context")
        bound = _BOUND.match(entry.get("note", "")) if context else None
        return {"ok": True, "errors": [], "digest": state["digest"], "row": state["row"],
                "is_context": context, "can_classify": not state["cited"] and (entry is None or context),
                "can_restore": context and not state["cited"], "cited": state["cited"],
                "reason": bound[2] if bound else (entry or {}).get("note", ""),
                "handled_by": (entry or {}).get("handled_by", ""),
                "stale": bool(bound and bound[1] != _binding(state["row"])), "approval_created": False}
    except (OSError, ValueError, TypeError, KeyError, AttributeError, RecursionError, yaml.YAMLError) as error:
        return _fail(error)


def _entry_text(item_id, entry, newline):
    lines = ["  " + json.dumps(item_id, ensure_ascii=False) + ":"]
    lines += ["    " + key + ": " + json.dumps(value, ensure_ascii=False) for key, value in entry.items()]
    return newline.join(lines) + newline


def _replace_entry(text, item_id, entry, audit):
    newline = "\r\n" if "\r\n" in text else "\n"
    if not text.strip():
        return "# Explicit classifications of specification rows; source citations remain unchanged." + newline + "items:" + newline + _entry_text(item_id, entry, newline)
    node = yaml.compose(text)
    items_key, items = next((key, value) for key, value in node.value if key.value == "items")
    lines = text.splitlines(keepends=True)
    found = next(((key, value) for key, value in items.value if key.value == item_id), None)
    if found:
        key, value = found
        start = key.start_mark.line
        last = value.value[-1][1] if value.value else value
        end = last.end_mark.line + (last.end_mark.column > 0)
        replacement = _entry_text(item_id, entry, newline) if entry else "  # " + audit + newline
        if len(items.value) == 1 and not entry:
            # Retain a mapping when the final entry is restored.
            replacement += "  {}" + newline
        return "".join(lines[:start]) + replacement + "".join(lines[end:])
    if items.flow_style:
        start = items.start_mark.line
        heading = "items:" + newline if start == items_key.start_mark.line else ""
        return "".join(lines[:start]) + heading + _entry_text(item_id, entry, newline) + "".join(lines[items.end_mark.line + 1:])
    index = items.end_mark.line
    return "".join(lines[:index]) + _entry_text(item_id, entry, newline) + "".join(lines[index:])


def save(root, pack, actor_id, item_id, reason, *, expected_digest, allowed_packs=None,
         local_demo=False, can_write=False, restore=False):
    """Record the person's context decision; a restore removes only that context entry."""
    temporary = None
    try:
        if local_demo is not True or can_write is not True:
            raise ValueError("Classifying a source row requires an authorized local editing session.")
        if not isinstance(reason, str) or not reason.strip() or len(reason) > 2000 or any(ord(c) < 32 for c in reason):
            raise ValueError("Explain this classification in one line (up to 2,000 characters).")
        state = _load(root, pack, actor_id, item_id, allowed_packs)
        with details.source_edit_lock(root, state["product"] / "source_refs.yaml"):
            state = _load(root, pack, actor_id, item_id, allowed_packs)
            if state["digest"] != expected_digest:
                raise ValueError("The product or row changed. Reload its current source before saving this classification.")
            if state["cited"]:
                raise ValueError("An existing contract record cites this row. Review that record before changing its source-row classification.")
            existing = state["entry"]
            if existing and existing.get("disposition") != "context":
                raise ValueError("This row already has another disposition. Review that decision before classifying it as document metadata.")
            if restore and not existing:
                raise ValueError("This row is already available as a variable.")
            now = datetime.now(timezone.utc).isoformat(timespec="seconds")
            audit = f"Restored {item_id} as a variable by {actor_id.strip()} at {now}. Reason: {reason.strip()}"
            entry = None if restore else {
                "disposition": "context",
                "handled_by": f"Original specification context at {item_id}; classified by {actor_id.strip()} at {now}",
                "note": f"Portal document metadata [row-sha256:{_binding(state['row'])}]. Reason: {reason.strip()}",
            }
            proposed = deepcopy(state["document"]["items"])
            if restore:
                proposed.pop(item_id)
            else:
                proposed[item_id] = entry
            _validate(state["product"], proposed, state["rows"], state["blocks"])
            candidate = _replace_entry(state["text"], item_id, entry, audit)
            parsed = yaml.load(candidate, Loader=details._StrictLoader)
            if parsed.get("items") != proposed:
                raise ValueError("The existing register layout cannot be updated without changing another decision. Nothing was changed.")
            descriptor, name = tempfile.mkstemp(prefix=".context-", suffix=".tmp", dir=state["path"].parent)
            temporary = Path(name)
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(candidate.encode("utf-8"))
                handle.flush()
                os.fsync(handle.fileno())
            if _load(root, pack, actor_id, item_id, allowed_packs)["digest"] != expected_digest:
                raise ValueError("The product changed while saving. Reload the source row and try again.")
            os.replace(temporary, state["path"])
            temporary = None
        return {"ok": True, "changed": True, "errors": [], "restored": restore, "approval_created": False,
                "message": "Restored this row to the variable list." if restore else "Kept this row as document metadata. Its source and citation remain available."}
    except (OSError, ValueError, TypeError, KeyError, AttributeError, RecursionError, yaml.YAMLError) as error:
        return _fail(error)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
