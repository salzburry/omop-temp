"""Bounded structured diagnostics outside the application checkout.

Command arguments, environments, clinical rows, prompts and tool output are
never logged here. Output hashes and OS error codes retain a correlation trail
without making operational logs a second patient-data or credential store.
"""
from datetime import datetime, timezone
import hashlib
import json
import logging
import sys
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import traceback
import threading
import uuid

_HANDLER_LOCK = threading.Lock()


def identifier():
    return uuid.uuid4().hex


def event(operation_id, event_name, **fields):
    try:
        try:
            from rwd_services.observability import record_runtime_event
            record_runtime_event(event_name, fields)
        except ImportError:
            pass  # Legacy standalone CLIs still retain their structured log.
        directory = Path(os.environ.get('RWDP_STATE_DIR') or
            Path(os.environ.get('LOCALAPPDATA') or Path.home()) / 'RwdPortal') / 'runtime-logs'
        if directory.resolve() != directory.absolute():
            return
        directory.mkdir(parents=True, exist_ok=True)
        target = directory / ('runtime-' + str(os.getpid()) + '.jsonl')
        logger = logging.getLogger('rwd.runtime.' + hashlib.sha256(str(target).encode()).hexdigest()[:16])
        with _HANDLER_LOCK:
            if not logger.handlers:
                logger.setLevel(logging.INFO)
                logger.propagate = False
                handler = RotatingFileHandler(target, maxBytes=1024 * 1024, backupCount=2, encoding='utf-8', delay=True)
                handler.setFormatter(logging.Formatter('%(message)s'))
                logger.addHandler(handler)
                if os.environ.get('RWDP_OBSERVABILITY_STDOUT') == '1':
                    cloud = logging.StreamHandler(sys.stdout)
                    cloud.setFormatter(logging.Formatter('%(message)s'))
                    logger.addHandler(cloud)
            try:
                logger.info(json.dumps({'at': datetime.now(timezone.utc).isoformat(), 'operation_id': operation_id,
                    'event': event_name, 'pid': os.getpid(), **fields}, ensure_ascii=True, default=str))
            finally:
                # Windows cannot remove/restore a workspace while a long-lived
                # logger holds its file open. One event owns one short handle;
                # the same rotating handler reopens in append mode next time.
                for handler in logger.handlers:
                    if isinstance(handler, RotatingFileHandler):
                        handler.close()
    except (OSError, ValueError):
        pass  # Failure to write diagnostics cannot change a scientific result.


def exception(operation_id, error):
    causes = []
    seen = set()
    while error is not None and id(error) not in seen:
        seen.add(id(error))
        causes.append({'type': type(error).__name__, 'errno': getattr(error, 'errno', None),
            'winerror': getattr(error, 'winerror', None), 'os_reason': getattr(error, 'strerror', None),
            'frames': [{'file': Path(frame.filename).name, 'line': frame.lineno, 'function': frame.name}
                for frame in traceback.extract_tb(error.__traceback__)[-15:]]})
        error = error.__cause__ or error.__context__
    event(operation_id, 'exception', causes=causes)


def output_identity(value):
    raw = str(value or '').encode('utf-8')
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
