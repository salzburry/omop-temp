"""Scoped human editing for existing scientific workflow records."""
from pathlib import Path
import datetime
import difflib
import hashlib

import streamlit as st

from experiments.portal import workflow_record_editor as editor


def clear():
    for key in list(st.session_state):
        if str(key).startswith("workflow_record_"):
            st.session_state.pop(key, None)


def _remember(path, field_id=None, key=None):
    drafts = dict(st.session_state.get("workflow_record_drafts") or {})
    entry = dict(drafts[path])
    if field_id is None:
        entry["text"] = st.session_state.get("workflow_record_text", "")
    else:
        values = dict(entry.get("values") or {})
        values[field_id] = st.session_state.get(key)
        entry["values"] = values
    entry["dirty"] = True
    drafts[path] = entry
    st.session_state["workflow_record_drafts"] = drafts
    st.session_state["workflow_record_confirm"] = False


def render_scaffold_metadata(root, pack, actor_id, *, local_demo, can_review, can_view, allowed_packs=None):
    """Preview known product-label placeholders without exposing scientific fields."""
    if not can_view:
        return False
    preview = editor.scaffold_metadata_preview(root, pack, allowed_packs=allowed_packs)
    if not preview.get("ok") or not preview.get("needed"):
        return False
    prefix = "scaffold_metadata_" + hashlib.sha256((str(Path(root).resolve()) + pack + actor_id + preview["digest"]).encode()).hexdigest()[:20]
    enabled = local_demo is True and can_review is True
    with st.expander("Complete the product labels", expanded=True):
        st.caption(preview["notice"])
        st.table([{"File": file["path"], "Field": change["field"], "Current": change["before"], "Proposed": change["after"]}
                  for file in preview["files"] for change in file["changes"]])
        confirmed = st.checkbox("I reviewed these product labels and want to save them as a draft.", key=prefix + "confirm", disabled=not enabled)
        if st.button("Save product labels", key=prefix + "save", disabled=not enabled or not confirmed):
            result = editor.repair_scaffold_metadata(root, pack, actor_id, expected_digest=preview["digest"],
                confirmed=confirmed, local_demo=local_demo, can_review=can_review, allowed_packs=allowed_packs)
            if result.get("ok"):
                st.success("Product labels saved. Scientific rules and execution setup still need their own checks.")
                return bool(result.get("changed"))
            for error in result.get("errors", []):
                st.error(str(error))
    return False


def render_treatment_omission(root, pack, actor_id, *, local_demo, can_review, can_view, allowed_packs=None):
    """Explicit optional-output draft preview; never run a model or approve science."""
    if not can_view:
        return False
    prefix = "optional_treatment_" + hashlib.sha256((str(Path(root).resolve()) + pack + actor_id).encode()).hexdigest()[:20]
    enabled = local_demo is True and can_review is True
    with st.expander("Optional template calculations", expanded=False):
        st.caption("For a new, unapproved draft only. Omit an output only when this study does not request it. Existing definitions and dependent rules are checked before saving.")
        categories = st.checkbox("This study does not request line-of-therapy categories", key=prefix + "categories", disabled=not enabled)
        status = st.checkbox("This study does not request treated / untreated status", key=prefix + "status", disabled=not enabled)
        survival = st.checkbox("Draft survival from this workbook instead of the template calculations", key=prefix + "survival", disabled=not enabled)
        st.caption("The survival option removes the template's minimum-follow-up flag, death imputation and survival calculation. It preserves other clinical fields and any separately drafted calculations; required survival rules still need review before a build.")
        demographics = st.checkbox("Draft demographics from this workbook instead of the template calculations", key=prefix + "demographics", disabled=not enabled)
        st.caption("The demographics option removes the template's age, age groups, race, ethnicity, region, practice and socioeconomic mappings. It preserves separately drafted calculations, including later age and age-group rules. Required outputs and their source inputs still need review before a build.")
        treatment = st.checkbox("Draft treatment from this workbook instead of the template calculations", key=prefix + "treatment", disabled=not enabled)
        st.caption("The treatment option removes the template's line variables, line counts, categories and treated / untreated status. It preserves separately drafted source copies and later calculations. An independently required line index retains its normalization settings; other inactive line settings are removed. Remaining source and output dependencies must pass review.")
        choices = (categories, status, survival, demographics, treatment)
        if st.button("Preview output omissions", key=prefix + "preview", disabled=not enabled or not any(choices)):
            st.session_state[prefix + "result"] = editor.treatment_omission_preview(root, pack, actor_id,
                omit_line_categories=categories, omit_treatment_status=status, omit_legacy_survival=survival,
                omit_legacy_demographics=demographics, omit_legacy_treatment=treatment, allowed_packs=allowed_packs)
            st.session_state[prefix + "choices"] = choices
        preview = st.session_state.get(prefix + "result")
        if not preview or st.session_state.get(prefix + "choices") != choices:
            return False
        for error in preview.get("errors", []):
            st.warning(error)
        if not preview.get("ok"):
            return False
        st.caption(preview["notice"])
        for file in preview["files"]:
            st.write(file["path"])
            st.code("".join(difflib.unified_diff(file["before"].splitlines(keepends=True), file["after"].splitlines(keepends=True), fromfile="Current", tofile="Draft")), language="diff")
        if preview.get("remaining_findings"):
            with st.expander("Checks still requiring attention"):
                st.json(preview["remaining_findings"])
        confirm_key = prefix + preview["digest"] + "confirm"
        confirmed = st.checkbox("I reviewed these omissions and want to save the configuration as an unapproved draft.", key=confirm_key,
            disabled=not enabled or not preview.get("can_save") or not preview.get("needed"))
        if st.button("Save output omissions", key=prefix + "save", disabled=not enabled or not confirmed or not preview.get("can_save") or not preview.get("needed")):
            result = editor.save_treatment_omission(root, pack, actor_id, expected_digest=preview["digest"],
                omit_line_categories=categories, omit_treatment_status=status, confirmed=confirmed, local_demo=local_demo,
                omit_legacy_survival=survival, omit_legacy_demographics=demographics, omit_legacy_treatment=treatment,
                can_review=can_review, allowed_packs=allowed_packs)
            if result.get("ok"):
                st.session_state.pop(prefix + "result", None)
                st.success("Output omissions saved as a draft. Continue the scientific and configuration reviews before building or releasing.")
                return bool(result.get("changed"))
            for error in result.get("errors", []):
                st.error(error)
    return False


def render(root, pack, action, actor_id, *, path=None, local_demo, can_review, can_view,
           receipt=None, build_id=None):
    if not can_view:
        clear()
        st.warning("You no longer have access to this workflow record.")
        return False
    if (action.get("id") if isinstance(action, dict) else action) == "g4_author":
        if render_scaffold_metadata(root, pack, actor_id, local_demo=local_demo, can_review=can_review,
                                    can_view=can_view, allowed_packs=[pack]):
            clear()
            return True
    publication_action = (action.get("id") if isinstance(action, dict) else action) == "g4_publication"
    context = (str(Path(root).resolve()), pack, actor_id, receipt, build_id, publication_action)
    previous = st.session_state.get("workflow_record_context")
    changed_context = previous is not None and previous[:5] != context[:5]
    if previous != context:
        clear()
        st.session_state["workflow_record_context"] = context
    candidate_path, candidate = None, None
    if receipt is not None:
        from experiments.portal import workflow_forms_page
        candidate_path, candidate = workflow_forms_page._candidate_selection(root, pack,
            prefix="workflow_record_", receipt=receipt, build_id=build_id)
        if not candidate["ok"]:
            return False
    probe = editor.describe(root, pack, action, path, allowed_packs=[pack])
    st.write("**Choose the delivered columns**" if probe.get("publication") else "**Edit the workflow record**")
    if not probe.get("ok"):
        for error in probe.get("errors") or ["The workflow record is unavailable."]:
            st.warning(str(error))
        return False
    paths = probe["paths"]
    if st.session_state.get("workflow_record_selected") not in paths:
        st.session_state["workflow_record_selected"] = probe["path"]
    selected = st.selectbox("Record", paths, key="workflow_record_selected", format_func=lambda value: value[len(pack) + 1:])
    if selected != probe["path"]:
        probe = editor.describe(root, pack, action, selected, allowed_packs=[pack])
        if not probe.get("ok"):
            for error in probe.get("errors") or ["The record could not be read."]:
                st.warning(str(error))
            return False
    drafts = dict(st.session_state.get("workflow_record_drafts") or {})
    if selected not in drafts:
        drafts[selected] = {"description": probe, "text": probe["text"], "values": {}, "dirty": False,
                            "mode": "Columns" if probe.get("publication") else "Fields" if probe["format"] == "yaml" else "Document"}
        st.session_state["workflow_record_drafts"] = drafts
    draft = drafts[selected]
    description = draft["description"]
    if candidate is not None:
        identities = {field["path"][0]: field["value"] for field in description["fields"] if len(field["path"]) == 1}
        if any(identities.get(key) != value for key, value in candidate["digests"].items()):
            st.warning("This saved approval names a different candidate. Correct its build ID and manifest digest below, and enter the people and dates who reviewed this selected build.")
        with st.expander("Selected candidate identity", expanded=True):
            st.table([{"Field": key, "Required value": value} for key, value in candidate["digests"].items()])
    if st.session_state.get("workflow_record_active") != selected:
        for key in list(st.session_state):
            if str(key).startswith("workflow_record_value_") or key in {"workflow_record_text", "workflow_record_mode", "workflow_record_group", "workflow_record_confirm"}:
                st.session_state.pop(key, None)
        st.session_state["workflow_record_active"] = selected
    enabled = local_demo is True and can_review is True and not changed_context
    if not enabled:
        st.info("Saving this record requires reviewer access in a local session.")
    st.caption(editor.NOTICE)
    if probe["digest"] != description["digest"]:
        st.warning("This record changed outside the editor. Your draft is retained; reload and compare before saving.")
    publication = description.get("publication")
    missing_publication_notice = None
    mode = "Document"
    if publication:
        mode = "Columns"
        st.caption("Required identity and provenance columns: " + ", ".join(publication["mandatory"]))
        st.caption("Choose the other engine outputs this product should deliver. ‘Contract promise’ marks a saved definition; it does not approve that definition.")
        current = publication["current"] or []
        choices = [name for name in publication["available"] if name not in publication["mandatory"]]
        key = "workflow_record_value_publication_columns"
        st.session_state.setdefault(key, draft["values"].get("publication.columns", list(dict.fromkeys(name for name in current if name in choices))))
        chosen = st.multiselect("Additional delivered columns", choices, key=key, disabled=not enabled,
            format_func=lambda name: name + (" · Contract promise" if name in publication["promised"] else ""),
            on_change=_remember, args=(selected, "publication.columns", key))
        columns = [*publication["mandatory"], *chosen]
        if publication["current"] is None:
            missing_publication_notice = st.empty()
            missing_publication_notice.info("No delivered-column list is saved yet. Choose the clinical outputs explicitly before saving.")
        unavailable = sorted(set(current) - set(publication["available"]))
        if unavailable:
            st.warning("The current list names outputs this engine configuration does not produce: " + ", ".join(unavailable) + ". Saving the selection removes these names.")
        missing = sorted(set(publication["promised"]) - set(columns))
        if missing:
            st.warning("Contract promises absent from this selection: " + ", ".join(missing) + ". Review the definitions or build rules; the binding check remains authoritative.")
        if probe.get("publication", {}).get("digest") != publication["digest"]:
            st.warning("The build rules or definitions changed. Reload and review the current outputs before saving.")
        st.write("Delivered order: " + ", ".join(columns))
    elif description["format"] == "yaml":
        st.session_state.setdefault("workflow_record_mode", draft["mode"])
        if draft["dirty"]:
            st.session_state["workflow_record_mode"] = draft["mode"]
        mode = st.radio("Editing view", ["Fields", "Document"], horizontal=True, key="workflow_record_mode", disabled=draft["dirty"])
        draft["mode"] = mode
        if draft["dirty"]:
            st.caption("Save or reload before switching editing views. Your unsaved work is retained.")
    if mode == "Document":
        st.session_state.setdefault("workflow_record_text", draft["text"])
        st.text_area("Scientific record" if description["format"] != "yaml" else "YAML document — add, remove or revise sections explicitly",
                     key="workflow_record_text", height=450, disabled=not enabled, on_change=_remember, args=(selected,))
    elif mode == "Fields":
        groups = {}
        for field in description["fields"]:
            at = field["path"]
            group = " / ".join(str(part) for part in (at[:2] if len(at) > 1 and isinstance(at[1], int) else at[:1])) or "Record"
            groups.setdefault(group, []).append(field)
        if not groups:
            st.info("This YAML record has no scalar fields. Switch to Document to add its intended sections.")
        else:
            if st.session_state.get("workflow_record_group") not in groups:
                st.session_state["workflow_record_group"] = next(iter(groups))
            group = st.selectbox("Section", list(groups), key="workflow_record_group")
            for field in groups[group]:
                fid = field["id"]
                key = "workflow_record_value_" + hashlib.sha256((selected + fid).encode()).hexdigest()[:20]
                current = draft["values"].get(fid, field["value"])
                st.text(field["label"])
                if field["kind"] == "bool":
                    st.session_state.setdefault(key, bool(current))
                    st.checkbox("Value", key=key, disabled=not enabled or not field["editable"], on_change=_remember, args=(selected, fid, key))
                else:
                    st.session_state.setdefault(key, "" if current is None else str(current))
                    st.text_input("Value", key=key, disabled=not enabled or not field["editable"], on_change=_remember, args=(selected, fid, key))
    st.checkbox("I reviewed these edits and want to save this record. This does not authenticate or release it.", key="workflow_record_confirm", disabled=not enabled)
    if st.button("Save record", key="workflow_record_save", type="primary", disabled=not enabled):
        try:
            arguments = {"text": st.session_state.get("workflow_record_text", draft["text"])} if mode == "Document" else {"updates": {}}
            if mode == "Columns":
                arguments = {"publication_columns": columns, "expected_publication_digest": publication["digest"]}
            elif mode == "Fields":
                by_id = {field["id"]: field for field in description["fields"]}
                for fid, value in draft["values"].items():
                    field = by_id[fid]
                    if field["kind"] == "number":
                        value = int(value) if isinstance(field["value"], int) else float(value)
                    elif field["kind"] == "date":
                        value = datetime.date.fromisoformat(value)
                    elif field["value"] is None and value == "":
                        value = None
                    if value != field["value"]:
                        arguments["updates"][fid] = value
            result = editor.save(root, pack, action, selected, expected_digest=description["digest"],
                                 confirmed=st.session_state.get("workflow_record_confirm", False), local_demo=local_demo,
                                 can_review=can_review and can_view, allowed_packs=[pack],
                                 receipt=receipt, build_id=build_id, candidate_path=candidate_path, **arguments)
            if result.get("ok"):
                changed = bool(result.get("changed"))
                if mode == "Columns":
                    if missing_publication_notice is not None:
                        missing_publication_notice.empty()
                    result = editor.describe(root, pack, action, selected, allowed_packs=[pack])
                    if not result.get("ok"):
                        drafts.pop(selected, None)
                        st.session_state["workflow_record_drafts"] = drafts
                        st.warning("The selection was saved, but its current build rules could not be reread. Reload before editing again.")
                        return changed
                drafts[selected] = {"description": result, "text": result["text"], "values": {}, "dirty": False, "mode": mode}
                st.session_state["workflow_record_drafts"] = drafts
                st.success("Draft record saved. Check status to validate its scientific and workflow requirements.")
                return changed
            for error in result.get("errors") or ["The record could not be saved."]:
                st.error(str(error))
        except (ValueError, TypeError, KeyError):
            st.error("Enter a valid number or ISO date for the edited field. Your draft is retained.")
    if st.button("Reload record", key="workflow_record_reload", help="Discard this record's unsaved draft and read its current bytes."):
        drafts.pop(selected, None)
        st.session_state["workflow_record_drafts"] = drafts
        st.session_state.pop("workflow_record_active", None)
        st.rerun()
    return False
