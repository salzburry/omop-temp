"""Scoped, stale-safe treatment code-list proposals; never activation or approval."""
from __future__ import annotations

from experiments.portal import configuration_proposals as proposals
from experiments.portal import design_workspace as workspace
from experiments.portal import treatment_codelist_rules as rules
from engine.config import load_config


def describe(root, pack, actor_id, *, allowed_packs):
    try:
        base, name, _owner, _directory = workspace._store(root, pack, actor_id, allowed_packs)
        path = base / name
        cfg = load_config(path / "config/data_product.yaml")
        if cfg.raw.get("codelists", {}).get("treatment_categories") != rules.FILE:
            raise proposals.Invalid("This editor supports the product's standard treatment_categories code list. Reconcile its configuration binding with the data expert before editing.")
        document = proposals._parse(proposals._read(path / rules.FILE).decode("utf-8"))
        if not isinstance(document, dict) or not isinstance(document.get("categories"), list):
            raise proposals.Invalid("Repair the treatment code-list structure before editing its categories.")
        description = workspace.describe(base, name)
        if description["errors"]:
            raise proposals.Invalid(" ".join(description["errors"]))
        return {"ok": True, "document": document, "baseline_sha256": description["baseline_sha256"],
                "snapshot_sha256": proposals._snapshot(base, path), "description": description, "errors": []}
    except (ValueError, OSError, KeyError, TypeError) as exc:
        return proposals._failure(exc)


def stage(root, pack, actor_id, *, document, expected_snapshot, expected_baseline,
          allowed_packs, local_demo=False, can_write=False):
    current = describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not current["ok"]:
        return current
    if not expected_snapshot or current["snapshot_sha256"] != expected_snapshot or current["baseline_sha256"] != expected_baseline:
        return proposals._failure(proposals.Invalid("The product changed after you opened the code list. Reload current evidence; your entries can be kept for comparison."))
    try:
        checked = rules.validate(document, before=current["document"])
        desc = current["description"]
        brief = workspace.build_plan(desc, retained=[r["variable_id"] for r in desc["rows"]], additions=[],
            purpose=checked["review_sources"]["rationale"], studies=[],
            target_source=desc["source"]["vendor"], target_modality=desc["source"]["modality"])
        return proposals.stage(root, pack, brief, configuration_changes=[{"ref": rules.REF, "value": checked}],
            study_exclusions=[], actor_id=actor_id, local_demo=local_demo, can_write=can_write,
            allowed_packs=allowed_packs, expected_baseline=expected_baseline, expected_snapshot=expected_snapshot)
    except (ValueError, OSError, KeyError, TypeError) as exc:
        return proposals._failure(proposals.Invalid(str(exc)))
