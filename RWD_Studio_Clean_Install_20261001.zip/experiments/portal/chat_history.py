"""Bounded private chat snapshots, separate from workflow jobs and product files.

Identity comes from the portal's resolved actor. Local/demo mode is attribution,
not authentication. Revision checks and empty snapshots prevent an older browser
or in-flight answer from restoring a conversation that was cleared elsewhere.
"""
from __future__ import annotations

import copy
import json
import os
from pathlib import Path
import tempfile
import uuid

from experiments.portal import design_workspace as design
from experiments.portal import session_drafts

MAX_BYTES = 256_000
TURN_FIELDS = {"id", "question", "answer", "actions", "note", "source", "context_window",
               "context_reference", "knowledge", "evidence_ids", "specialist", "specialist_context",
               "proposal_validation"}
PROPOSAL_VALIDATION_STATUSES = {"blocked", "validated_draft", "no_proposal"}
PROPOSAL_VALIDATION_CODES = {"json_syntax", "reply_shape", "proposal_invalid", "context_changed",
    "deadline", "timeout", "provider_error", "invalid_response", "context_budget", "cost_budget", "attempt_limit"}


class Changed(ValueError):
    """Another session changed or cleared this conversation."""


def proposal_validation(value):
    """Normalize answer-time technical checks, never scientific approval evidence."""
    if not isinstance(value, dict):
        return None
    status, attempts, repaired = (value.get(name) for name in ("status", "attempts", "repaired"))
    findings, codes = value.get("findings"), value.get("codes", [])
    if (not isinstance(status, str) or status not in PROPOSAL_VALIDATION_STATUSES
            or type(attempts) is not int or not 0 <= attempts <= 2 or type(repaired) is not bool
            or not isinstance(findings, list) or len(findings) > 6
            or any(not isinstance(finding, str) for finding in findings)
            or not isinstance(codes, list) or len(codes) > 2
            or any(not isinstance(code, str) or code not in PROPOSAL_VALIDATION_CODES for code in codes)):
        return None
    from experiments.portal import form_assistance
    from experiments.portal import scientific_definition_ai as ai
    messages, _omitted = form_assistance.validation_messages(findings)
    clean = []
    for message in messages:
        try:
            ai._ingress(message)
        except ai.Invalid:
            message = "Restricted information was omitted from a draft-check detail."
        if message not in clean:
            clean.append(message)
    return {"status": status, "attempts": attempts, "repaired": repaired,
            "findings": clean, "codes": list(dict.fromkeys(codes))}


def _scope(root, pack, actor, allowed_packs, channel):
    from experiments.portal import authoring_session
    current = authoring_session.CURRENT.get()
    if current is not None:
        name = str(pack or "").replace("\\", "/")
        if (str(Path(root).resolve()) != current.root or not isinstance(actor, str)
                or actor.strip() != current.actor
                or not isinstance(allowed_packs, (list, tuple, set))
                or any(not isinstance(p, str) or p not in current.packs for p in allowed_packs)
                or (name and name not in current.packs)):
            raise ValueError("This conversation is outside the authenticated user or product scope.")
    owner, setup_directory = session_drafts._setup_scope(root, actor, allowed_packs)
    name = design._pack_path(root, pack, allowed_packs)[2] if pack else ""
    if not isinstance(channel, str) or not channel or len(channel) > 100:
        raise ValueError("Choose a supported conversation.")
    scope = {"checkout": owner["checkout"], "owner": owner["owner"], "pack": name,
             "channel": channel, "access": sorted(set(allowed_packs))}
    directory = setup_directory.parent.parent.parent / "chat-history" / scope["checkout"][:12] / scope["owner"][:12]
    path = directory / (design._hash([name, channel])[:24] + ".json")
    if path.resolve() != path:
        raise ValueError("The private chat location redirects to another folder.")
    design._check_storage_paths([path])
    return scope, path


def _turns(turns):
    from experiments.portal import flow_assistant
    from experiments.portal import scientific_definition_ai as ai
    if not isinstance(turns, list) or len(turns) > flow_assistant.MAX_CONVERSATION_TURNS:
        raise ValueError("The conversation exceeds its supported history.")
    result = []
    for turn in turns:
        if (not isinstance(turn, dict) or not {"question", "answer"} <= set(turn)
                or not all(isinstance(turn[name], str) for name in ("question", "answer"))):
            raise ValueError("The saved conversation is malformed.")
        for name in ("actions", "evidence_ids"):
            if name in turn and (not isinstance(turn[name], list) or any(not isinstance(value, str) for value in turn[name])):
                raise ValueError("The saved conversation contains malformed references.")
        for name in ("context_window", "context_reference", "knowledge", "specialist", "specialist_context"):
            if turn.get(name) is not None and not isinstance(turn[name], dict):
                raise ValueError("The saved conversation contains malformed context.")
        clean = {name: copy.deepcopy(value) for name, value in turn.items() if name in TURN_FIELDS}
        if turn.get("proposal_validation") is not None:
            checked = proposal_validation(turn["proposal_validation"])
            if checked is None:
                raise ValueError("The saved conversation contains malformed proposal checks.")
            clean["proposal_validation"] = checked
        else:
            clean.pop("proposal_validation", None)
        result.append(clean)
    raw = json.dumps(result, ensure_ascii=False, allow_nan=False)
    if len(raw.encode("utf-8")) > MAX_BYTES - 4000:
        raise ValueError("This conversation is too large to save privately.")
    # Use the same ingress guard as saved setup and model-bound conversation.
    ai._ingress(raw + "\n" + ai._plain(result))
    return result


def _read(path, scope):
    if not path.exists():
        return {"revision": None, "turns": [], "scope": scope}
    if path.stat().st_size > MAX_BYTES:
        raise ValueError("The saved conversation is too large to read.")
    value = design._json_read(path)
    if (not isinstance(value, dict) or set(value) != {"schema", "scope", "revision", "turns", "digest"}
            or value.get("schema") != 1 or not isinstance(value.get("scope"), dict)
            or set(value["scope"]) != set(scope)
            or any(value["scope"].get(name) != scope[name] for name in scope if name != "access")
            or not isinstance(value.get("revision"), str) or len(value["revision"]) != 32
            or value.get("digest") != design._hash({name: data for name, data in value.items() if name != "digest"})):
        raise ValueError("The saved conversation changed or belongs to another profile or product.")
    value["turns"] = _turns(value["turns"])
    return value


def _write(path, scope, turns):
    # Scope was checked before acquiring the conversation lock. Personal chat
    # persistence does not grant permission to edit scientific product records.
    value = {"schema": 1, "scope": scope, "revision": uuid.uuid4().hex, "turns": turns}
    value["digest"] = design._hash(value)
    raw = json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8")
    if len(raw) > MAX_BYTES:
        raise ValueError("This conversation is too large to save privately.")
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="wb", dir=path.parent, prefix=".chat-history-", suffix=".tmp", delete=False) as handle:
            temporary = Path(handle.name)
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        if path.resolve() != path:
            raise ValueError("The private chat location redirects to another folder.")
        design._check_storage_paths([path])
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    return value


def load(root, pack, actor, *, allowed_packs, channel="flow_assistant_"):
    scope, path = _scope(root, pack, actor, allowed_packs, channel)
    shared = _shared(root, pack, actor, allowed_packs)
    if shared is not None:
        from rwd_services import storage_chat
        return _shared_call(storage_chat.load, shared, channel, allowed_packs, _turns)
    current = _read(path, scope)
    if current["scope"]["access"] != scope["access"]:
        # References can mention other permitted products. Revocation discards
        # them permanently, even if the original grant is later restored.
        from experiments.portal.local_process_lock import locked
        with locked(path.with_suffix(".lock"), path.parent):
            current = _read(path, scope)
            if current["scope"]["access"] != scope["access"]:
                current = _write(path, scope, [])
    return current


def save(root, pack, actor, turns, *, allowed_packs, expected_revision, channel="flow_assistant_"):
    scope, path = _scope(root, pack, actor, allowed_packs, channel)
    clean = _turns(turns)
    shared = _shared(root, pack, actor, allowed_packs)
    if shared is not None:
        from rwd_services import storage_chat
        return _shared_call(storage_chat.save, shared, channel, allowed_packs, clean, expected_revision, _turns)
    current = _read(path, scope)
    if current["revision"] == expected_revision and current["scope"] == scope and current["turns"] == clean:
        return current
    from experiments.portal.local_process_lock import locked
    path.parent.mkdir(parents=True, exist_ok=True)
    with locked(path.with_suffix(".lock"), path.parent):
        current = _read(path, scope)
        if current["revision"] != expected_revision or current["scope"] != scope:
            raise Changed("This conversation changed in another session. Review its latest messages before asking again.")
        return current if current["turns"] == clean else _write(path, scope, clean)


def clear(root, pack, actor, *, allowed_packs, channel="flow_assistant_"):
    scope, path = _scope(root, pack, actor, allowed_packs, channel)
    shared = _shared(root, pack, actor, allowed_packs)
    if shared is not None:
        from rwd_services import storage_chat
        return _shared_call(storage_chat.clear, shared, channel, allowed_packs, _turns)
    from experiments.portal.local_process_lock import locked
    path.parent.mkdir(parents=True, exist_ok=True)
    with locked(path.with_suffix(".lock"), path.parent):
        # Keep a new empty revision, even when already empty. In-flight answers
        # are now stale and cannot repopulate the cleared transcript.
        return _write(path, scope, [])


def _shared(root, pack, actor, allowed_packs):
    from rwd_services import lakebase, storage
    if lakebase.backend() == "file":
        return None
    # No local persistence fallback when a shared database was explicitly chosen.
    return storage.for_request(root, str(pack or "").replace("\\", "/"), actor, allowed_packs=allowed_packs)


def _shared_call(function, *args):
    from rwd_services import storage
    try:
        return function(*args)
    except storage.Changed as error:
        raise Changed(str(error)) from None
