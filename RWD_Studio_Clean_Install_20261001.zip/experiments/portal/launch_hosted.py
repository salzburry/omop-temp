"""Start authenticated authoring from an explicitly managed persistent workspace.

The hosted launcher owns the process it replaces with Streamlit.  A small,
identity-bound receipt makes ``--stop`` safe and lets a restart clean up a
dead receipt without guessing from a port or killing an unrelated service.
"""
import argparse
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import uuid
import urllib.error
import urllib.request

from experiments.portal import installation_storage as storage
from rwd_services import workspace_root, package_asset

PROCESS_RECEIPT = '.hosted-process.json'


def _receipt_path(data_root):
    return Path(data_root).resolve() / PROCESS_RECEIPT


def _write_receipt(data_root, port, identity=None):
    from experiments.portal import local_process_lock
    identity = identity or local_process_lock.process_identity()
    path = _receipt_path(data_root)
    record = {'version': 1, **identity, 'port': port, 'started_at': time.time()}
    temporary = path.with_name('.' + uuid.uuid4().hex + '.tmp')
    try:
        temporary.write_text(json.dumps(record, separators=(',', ':')), encoding='utf-8')
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
    return path


def _read_receipt(data_root):
    path = _receipt_path(data_root)
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
    except FileNotFoundError:
        return None
    except (OSError, ValueError, TypeError, RecursionError):
        raise ValueError('The hosted process receipt is unreadable. Inspect or remove it only after confirming no hosted portal is running.')
    if (not isinstance(value, dict) or value.get('version') != 1
            or not isinstance(value.get('pid'), int) or value['pid'] <= 0
            or not isinstance(value.get('start'), str) or not value['start']
            or not isinstance(value.get('host'), str) or not value['host']):
        raise ValueError('The hosted process receipt is invalid. Inspect it before starting or stopping the service.')
    return value


def _port_served(port):
    """Return True only when the hosted health endpoint answers on loopback."""
    if type(port) is not int or not 1 <= port <= 65535:
        return False
    try:
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/_stcore/health', timeout=0.8) as response:
            return response.status == 200
    except (OSError, urllib.error.URLError, urllib.error.HTTPError):
        return False


def _wait_port_closed(port, timeout=10):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not _port_served(port):
            # A health request can race the listener teardown. Confirm the TCP
            # endpoint is no longer accepting connections before reporting stop.
            try:
                with socket.create_connection(('127.0.0.1', port), timeout=0.2):
                    pass
            except OSError:
                return True
        time.sleep(0.15)
    return not _port_served(port)


def _stop(data_root):
    """Stop only the hosted process whose OS identity was recorded at launch."""
    from experiments.portal import local_process_lock
    info = storage.layout(data_root)
    path = _receipt_path(info['root'])
    receipt = _read_receipt(info['root'])
    if receipt is None:
        return {'ok': True, 'status': 'not_running', 'data_root': str(info['root'])}
    alive = local_process_lock.process_alive(receipt)
    if alive is None:
        raise ValueError('The hosted process owner cannot be verified safely. Preserve the receipt and inspect the process before retrying.')
    if not alive:
        if _port_served(receipt.get('port')):
            raise ValueError('The hosted receipt owner is gone but its port is still serving. Inspect the remaining process before removing the receipt or starting another service.')
        path.unlink(missing_ok=True)
        return {'ok': True, 'status': 'stale_receipt_removed', 'data_root': str(info['root'])}
    pid = receipt['pid']
    if pid == os.getpid():
        raise ValueError('The stop command cannot stop itself.')
    if os.name == 'nt':
        result = subprocess.run(['taskkill', '/PID', str(pid), '/T', '/F'], capture_output=True,
                                text=True, timeout=15, creationflags=subprocess.CREATE_NO_WINDOW)
        if result.returncode != 0 and local_process_lock.process_alive(receipt) is not False:
            raise ValueError('The hosted process could not be stopped safely. Inspect its owner and retry.')
    else:
        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline and local_process_lock.process_alive(receipt) is True:
            time.sleep(0.1)
        if local_process_lock.process_alive(receipt) is True:
            os.kill(pid, signal.SIGKILL)
    if local_process_lock.process_alive(receipt) is not False:
        raise ValueError('The hosted process did not exit after the stop request. Preserve the receipt and inspect it before retrying.')
    if not _wait_port_closed(receipt.get('port')):
        raise ValueError('The hosted process exited but its port is still serving. Inspect the remaining process before retrying.')
    path.unlink(missing_ok=True)
    return {'ok': True, 'status': 'stopped', 'pid': pid, 'data_root': str(info['root'])}


def _prepare_start(info, port):
    """Reject a live owned process and replace only a verified dead receipt."""
    from experiments.portal import local_process_lock
    path = _receipt_path(info['root'])
    receipt = _read_receipt(info['root'])
    if receipt is not None:
        alive = local_process_lock.process_alive(receipt)
        if alive is None:
            raise ValueError('A hosted process receipt exists but its owner cannot be verified. Inspect it before starting another service.')
        if alive:
            running_port = receipt.get('port')
            suffix = f' on port {running_port}' if isinstance(running_port, int) else ''
            raise ValueError(f'A hosted portal is already running{suffix}. Use --stop before starting another one.')
        path.unlink(missing_ok=True)
    return _write_receipt(info['root'], port)


def command(data_root, *, port=8517):
    from experiments.portal.theme import streamlit_arguments
    if type(port) is not int or not 1 <= port <= 65535:
        raise ValueError('Choose a valid server port.')
    env = dict(os.environ, RWDP_DATA_ROOT=str(Path(data_root).resolve()), RWD_PORTAL_HOSTED_AUTHORING='1')
    info = storage.configure(workspace_root(__file__), env)
    if not env.get('RWD_PORTAL_BOOTSTRAP_ADMIN') and not (info['state'] / 'users.json').is_file():
        raise ValueError('Set RWD_PORTAL_BOOTSTRAP_ADMIN to the first authenticated administrator principal before first launch.')
    env['RWD_PORTAL_WORKSPACE_ROOT'] = str(info['workspace'])
    argv = [sys.executable, '-I', '-m', 'streamlit', 'run', str(package_asset('experiments/portal/app.py')),
            '--server.address=127.0.0.1', '--server.port=' + str(port), '--server.headless=true',
            '--server.fileWatcherType=none', '--browser.gatherUsageStats=false', *streamlit_arguments()]
    return argv, env, info['workspace']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root', required=True)
    parser.add_argument('--port', type=int, default=8517)
    parser.add_argument('--stop', action='store_true', help='Stop only the hosted portal previously started for this data root.')
    parser.add_argument('--check-only', action='store_true', help='Check the isolated runtime and identity setup without starting the hosted portal.')
    args = parser.parse_args()
    try:
        if args.stop:
            print(json.dumps(_stop(args.data_root), indent=2))
            return 0
        argv, env, workspace = command(args.data_root, port=args.port)
        from experiments.portal import launch_portal
        checked = launch_portal.inspect_environment(workspace, python=sys.executable, environ=env)
        if not checked['ok']:
            print(json.dumps(checked, indent=2))
            return 1
        preflight = {'ok': True, 'status': 'checked' if args.check_only else 'preflight_passed',
                     'data_root': str(Path(args.data_root).resolve()), 'workspace': str(workspace),
                     'runtime_mode': checked['runtime_mode'], 'interpreter': checked['interpreter'],
                     'environment_profile': checked['environment_profile'],
                     'identity_setup': checked.get('identity_setup') or
                        {'ready': False, 'why': 'Identity setup was not checked by the selected runtime.'}}
        print(json.dumps(preflight, indent=2), flush=True)
        if args.check_only:
            return 0
        info = storage.layout(args.data_root)
        receipt = _prepare_start(info, args.port)
        os.chdir(workspace)
        if os.name == 'nt':
            # os.execve replaces the launcher process on POSIX, but Windows
            # starts Streamlit as a child and leaves the recorded PID dead.
            # Keep the launcher as the owner so --stop can terminate the
            # complete process tree and verify that the port closed.
            flags = subprocess.CREATE_NEW_PROCESS_GROUP
            child = subprocess.Popen(argv, cwd=workspace, env=env, creationflags=flags)
            from experiments.portal import local_process_lock
            child_receipt = _write_receipt(info['root'], args.port,
                                           local_process_lock.process_identity(child.pid))
            if child_receipt != receipt:
                receipt.unlink(missing_ok=True)
            try:
                returncode = child.wait()
            finally:
                receipt.unlink(missing_ok=True)
            raise SystemExit(returncode)
        os.execve(sys.executable, argv, env)
    except (OSError, ValueError) as error:
        # A duplicate start, invalid installation or unsafe stop is an
        # expected operator refusal. Keep it machine-readable for the portal
        # and scripts instead of emitting a traceback.
        print(json.dumps({'ok': False, 'error': str(error)}, indent=2))
        return 1
    except BaseException:
        if 'receipt' in locals():
            receipt.unlink(missing_ok=True)
        raise


if __name__ == "__main__":
    raise SystemExit(main())
