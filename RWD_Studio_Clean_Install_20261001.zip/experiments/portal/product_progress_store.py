"""Compact last-checked progress for navigation; never a gate authority.

Only six presentation rows are persisted. Reopening this summary never places
an old gate result in flow_result or authorizes an execution/release action.
"""
import hashlib
import json
import os
from pathlib import Path
import tempfile

from experiments.portal import installation_storage as storage


def _path(root, state_dir, pack):
    from experiments.portal import authoring_session
    authoring_session.check_scope(root, pack)
    base = storage._safe(Path(state_dir)) / 'last-checked-progress' / storage.workspace_key(root)
    return storage._safe(base / (hashlib.sha256(pack.encode()).hexdigest() + '.json'))


def _valid(value, pack):
    from experiments.portal import stage_model
    rows = value.get('rows') if isinstance(value, dict) else None
    return (value.get('version') == 1 and value.get('pack') == pack
        and isinstance(value.get('checked_at'), str) and len(value['checked_at']) <= 100
        and isinstance(rows, list) and len(rows) == 6
        and all(isinstance(row, dict) and row.get('gate') == i
            and row.get('state') in stage_model.STATES and row.get('label') == stage_model.LABELS[i]
            and type(row.get('blockers')) is int and row['blockers'] >= 0
            and isinstance(row.get('why'), str) for i, row in enumerate(rows, 1)))


def read(root, state_dir, pack):
    try:
        path = storage.io_path(_path(root, state_dir, pack))
        if not path.is_file() or path.stat().st_size > 16384:
            return None
        value = json.loads(path.read_bytes())
        return value if _valid(value, pack) else None
    except (OSError, ValueError, TypeError, AttributeError):
        return None


def remember(root, state_dir, pack, rows, checked_at):
    value = {'version': 1, 'pack': pack, 'rows': rows, 'checked_at': str(checked_at or '')}
    if not _valid(value, pack):
        return False
    if read(root, state_dir, pack) == value:
        return True
    path = storage.io_path(_path(root, state_dir, pack))
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.progress-', suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            json.dump(value, handle)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)
    return True
