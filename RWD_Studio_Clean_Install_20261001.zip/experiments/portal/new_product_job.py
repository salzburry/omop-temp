"""Keep the explicitly requested product write independent of Streamlit reruns."""
from __future__ import annotations

from pathlib import Path
import re
import subprocess
import sys
import uuid

from experiments.portal import portal_jobs as jobs
from experiments.portal import portal_runtime

ACTION = "new_product_apply"
JOB_KEY = "new-product"
OPTIONS = {
    "--next-cut-of", "--change-class", "--change-note", "--code", "--name", "--vendor",
    "--tumor-class", "--spec-version", "--family", "--broad", "--narrow", "--condition-class",
    "--modality", "--disease-terms", "--tumour-family", "--ai-classification", "--classified-by",
    "--classified-date", "--workbook", "--exclude-sheet", "--exclude-sheet-reason",
    "--sheet-domain", "--sheet-domain-reason",
    "--column-map", "--column-map-reason", "--column-map-origin",
}


def _arguments(argv, allowed_packs):
    # The saved request selects only the canonical product command. Neither a
    # different executable nor a checkout override can enter a worker journal.
    if (not isinstance(argv, (list, tuple)) or not argv or len(argv) > 1001 or
            any(not isinstance(part, str) for part in argv) or
            not re.fullmatch(r"[a-z][a-z0-9_]*", argv[0]) or len(argv) % 2 != 1):
        raise ValueError("Preview the current product inputs before requesting Write.")
    for option, value in zip(argv[1::2], argv[2::2]):
        if option not in OPTIONS or value.startswith("--"):
            raise ValueError("Use the reviewed product fields without command or checkout overrides.")
        if option == "--next-cut-of" and value not in (allowed_packs or []):
            raise ValueError("The previous product is outside your current access.")
    return list(argv)



def _command(root, argv, *, apply=False, timeout_s=90, nonce=None):
    from rwd_tools import new_product
    request = [*argv, *(["--apply"] if apply else []), "--root", str(Path(root).resolve())]
    nonce = nonce or uuid.uuid4().hex
    try:
        binding = new_product.request_binding(request, nonce)
    except (OSError, ValueError) as error:
        return portal_runtime.CommandResult([], 1, stderr="The setup inputs cannot be read consistently. Inspect the selected workbook and preview again. " + str(error))
    command = [sys.executable, "-I", "-m", "rwd_tools.new_product", "--request-nonce", nonce, *argv, "--json",
               *(["--apply"] if apply else []), "--root", str(Path(root).resolve())]
    completed = portal_runtime.run(command, cwd=str(root), timeout_s=timeout_s)
    if portal_runtime.failure_kind(completed) is not None:
        completed.outcome = None
        return completed
    try:
        outcome = new_product.parse_outcome(completed.stdout or "", completed.returncode, expected_binding=binding, request_argv=request)
        if outcome.returncode == 0 and outcome.state != ("written" if apply else "preview"):
            raise ValueError("The product worker completed a different operation from the one requested.")
    except (ValueError, TypeError) as error:
        failed = portal_runtime.CommandResult(command, completed.returncode or 1, completed.stdout or "",
            "The setup result could not be verified. Inspect current product progress before retrying Write. "
            + str(error) + ("\n" + completed.stderr if completed.stderr else ""))
        failed.outcome = None
        return failed
    answer = portal_runtime.CommandResult(command, outcome.returncode, outcome.stdout, outcome.stderr)
    answer.outcome = outcome.as_dict()
    answer.setup_binding = {"expected": binding, "argv": request}
    return answer


def preview(root, argv, *, allowed_packs=None, timeout_s=90):
    return _command(root, _arguments(argv, allowed_packs), timeout_s=timeout_s)


def execute(root, actor_id, *, argv, request_id, launch_context=None, allowed_packs=None):
    argv = _arguments(argv, allowed_packs)
    if not isinstance(request_id, str) or not re.fullmatch(r"[a-f0-9]{32}", request_id):
        raise ValueError("Use the current explicitly requested product write.")
    portal_runtime.job_progress("Staging the reviewed product and running its validators. Clearing chat does not cancel this work.")
    result = _command(root, argv, apply=True, timeout_s=1800, nonce=request_id)
    return {"ok": result.returncode == 0, "returncode": result.returncode,
            "stdout": result.stdout or "", "stderr": result.stderr or "",
            "failure_kind": portal_runtime.failure_kind(result), "outcome": getattr(result, "outcome", None),
            "setup_binding": getattr(result, "setup_binding", None)}



def current(root, actor_id, *, allowed_packs=None):
    rows = jobs.recent(root, actor_id, action=ACTION, job_key=JOB_KEY, allowed_packs=allowed_packs)
    return rows[0] if rows else None


def context(root, actor_id, state, *, allowed_packs=None):
    """Bind completion to the form and saved brief reviewed when Write was clicked."""
    from experiments.portal import conversation_intake
    from experiments.portal import new_product_recovery
    scope, directory = conversation_intake._scope(root, "", actor_id, allowed_packs or [])
    brief = conversation_intake._read(directory, scope, actor_id)
    return {"form_digest": new_product_recovery._inputs(state),
            "brief_revision": (brief or {}).get("revision")}


def start(root, actor_id, argv, *, can_write=False, allowed_packs=None, launch_context=None):
    argv = _arguments(argv, allowed_packs)
    return jobs.start(root, actor_id, action=ACTION, job_key=JOB_KEY,
        arguments={"argv": argv, "request_id": uuid.uuid4().hex, "launch_context": launch_context},
        confirmed=True, can_write=can_write, allowed_packs=allowed_packs)



def result(row):
    from rwd_tools import new_product
    def unverified(message, output=""):
        answer = portal_runtime.CommandResult([], 1, output,
            "The saved setup result could not be verified. Inspect current product progress before retrying. " + message)
        answer.outcome = None
        return answer
    if not isinstance(row, dict) or not isinstance(row.get("result"), dict):
        return unverified("This attempt did not retain a complete tool result.")
    saved = row["result"]
    if (type(saved.get("returncode")) is not int or not isinstance(saved.get("stdout", ""), str)
            or not isinstance(saved.get("stderr", ""), str)):
        return unverified("The recorded result fields are incomplete.", saved.get("stdout", "") if isinstance(saved.get("stdout", ""), str) else "")
    kind = saved.get("failure_kind")
    if kind is not None and (type(kind) is not str or kind not in {"timeout", "start", "cancelled"}):
        return unverified("The recorded runtime failure type is invalid.", saved.get("stdout", ""))
    if saved["returncode"] == 0 and kind is not None:
        return unverified("A runtime interruption cannot establish a completed write.", saved.get("stdout", ""))
    answer = portal_runtime.CommandResult([], saved["returncode"], saved.get("stdout", ""), saved.get("stderr", ""),
                                          failure_kind=kind)
    answer.outcome = None
    if answer.returncode == 0 and saved.get("outcome") is None:
        return unverified("This older setup result has no verified written-file inventory.", answer.stdout)
    if saved.get("outcome") is not None:
        try:
            document = saved["outcome"]
            if not isinstance(document, dict):
                raise ValueError("The saved outcome is not a structured record.")
            binding = saved.get("setup_binding")
            expected = binding.get("expected") if isinstance(binding, dict) else None
            if document.get("version") == 2 and expected is None:
                raise ValueError("Saved setup outcome has no retained invocation binding.")
            outcome = new_product.parse_outcome(document, answer.returncode, expected_binding=expected,
                request_argv=binding.get("argv") if isinstance(binding, dict) else None)
            if expected is not None:
                request = binding.get("argv")
                arguments, root = row.get("arguments"), row.get("root")
                if (not isinstance(root, str) or not root or not isinstance(arguments, dict)
                        or not isinstance(arguments.get("argv"), list)
                        or any(not isinstance(value, str) for value in arguments["argv"])
                        or not isinstance(request, list) or request.count("--root") != 1
                        or request.index("--root") + 1 >= len(request)
                        or Path(request[request.index("--root") + 1]).resolve() != Path(root).resolve()
                        or request != [*arguments["argv"], "--apply", "--root", root]
                        or expected["nonce"] != arguments.get("request_id")):
                    raise ValueError("Saved setup outcome belongs to another request scope.")
                answer.setup_binding = binding
            if answer.returncode == 0 and outcome.state != "written":
                raise ValueError("Saved setup result does not identify a completed write.")
            answer.outcome = outcome.as_dict()
        except (ValueError, TypeError, KeyError, IndexError, OSError) as error:
            return unverified(str(error), answer.stdout)
    return answer


def acknowledge(root, actor_id, row, *, allowed_packs=None):
    """Retain successful output without reopening the same product on every visit."""
    owned = jobs.read(root, actor_id, row["id"], allowed_packs=allowed_packs)
    if owned["status"] == "completed":
        jobs._update(jobs._path(root, actor_id, row["id"]), {"result_acknowledged": True},
                     only_status={"completed"})


def render_progress(root, actor_id, *, allowed_packs=None, can_write=False):
    import streamlit as st

    @st.fragment(run_every="2s")
    def progress():
        row = current(root, actor_id, allowed_packs=allowed_packs)
        if row is None:
            return
        if row["status"] in jobs.TERMINAL:
            st.rerun()
        st.caption(jobs.ACTIONS[ACTION] + " · " + row["status"])
        st.write(row["progress"])
        st.caption("You may leave this page or close Streamlit. Reopening New product restores this progress and its saved result.")
        if st.button("Refresh setup progress", key="np_job_refresh"):
            st.rerun()
        st.caption("Clearing the conversation keeps this setup running. Its result will appear here when it finishes.")

    progress()
