"""Small, read-only helpers for telling a researcher when generated evidence needs a refresh.

The existing pipeline owns the authoritative byte-for-byte ``--check``. Verify a new set of input
and artifact bytes once, then reuse that result while those bytes and the runner are unchanged.
Installation timestamps do not establish drift. This helper never writes a product.
"""
from __future__ import annotations

from collections import OrderedDict
import hashlib
import importlib
import os
from pathlib import Path
import sys
from threading import Lock


ARTIFACTS = ("extracted.json", "lint.json", "SPEC_FINDINGS.txt", "COVERAGE.md",
             "scaffold.json", "SCAFFOLDED_RECORDS.md", "ENUMERATION_CANDIDATES.yaml")


_CACHE = OrderedDict()
_CACHE_LOCK = Lock()


def _fingerprint(root, product):
    from experiments.portal import flow_guidance

    source = flow_guidance.source_revision(root, product.relative_to(root).as_posix())
    if source is None:
        return None
    paths = [product / "spec_pipeline/out" / name for name in ARTIFACTS]
    paths += [root / "governance" / name for name in
              ("tumour_registry.yaml", "spec_sheet_map.yaml", "ai_boundary.yaml")]
    # Coverage also consumes dispositions, decisions and their saved review bindings.
    handoff = product / "handoff"
    paths += sorted(path for path in handoff.rglob("*") if path.is_file())
    if len(paths) > 256:
        return None
    # The child uses the installed pipeline. A code change invalidates a previous check too.
    for name in ("run_spec_pipeline", "spec_extract", "spec_lint", "contract_scaffold",
                 "spec_codelists", "contract_lint", "source_manifest", "product_gates"):
        paths.append(Path(importlib.import_module("rwd_tools." + name).__file__).resolve())
    paths.append(Path(importlib.import_module("rwd_services").__file__).resolve())
    digest = hashlib.sha256(source.encode())
    total = 0
    for path in paths:
        if path.resolve() != path:
            return None
        digest.update(str(path).encode())
        if not path.exists():
            digest.update(b"missing")
            continue
        if not path.is_file() or path.stat().st_size > 32 * 1024 * 1024:
            return None
        raw = path.read_bytes()
        total += len(raw)
        if total > 64 * 1024 * 1024:
            return None
        digest.update(hashlib.sha256(raw).digest())
    return digest.hexdigest()


def _run_check(root, pack):
    from experiments.portal import portal_runtime
    from rwd_services import run_workflow_command

    result = run_workflow_command(
        [sys.executable, "platform/tools/run_spec_pipeline.py", pack, "--check", "--require-generated"],
        issuer="rwd_tools.run_spec_pipeline", runner=portal_runtime.run, cwd=root, timeout_s=30)
    if portal_runtime.failure_kind(result) or not result.workflow_outcome_verified:
        return "unavailable"
    if result.returncode == 0:
        return "current"
    if any(issue.code == "generated_evidence_stale" for issue in result.workflow_issues):
        return "stale"
    return "unavailable"


def inspect(root: str | os.PathLike[str], pack: str) -> dict:
    """Return a bounded freshness summary for a canonical pack.

    ``state`` is one of ``current``, ``missing``, ``stale`` or ``unavailable``.  The summary is
    bound to this workspace, product, source, authored inputs, artifacts and pipeline code.
    """
    try:
        product = (Path(root).resolve() / str(pack).replace("/", os.sep)).resolve()
        base = Path(root).resolve()
        product.relative_to(base)
    except (OSError, ValueError, TypeError):
        return {"state": "unavailable", "missing": [], "stale_inputs": [], "message": ""}
    out = product / "spec_pipeline" / "out"
    missing = [name for name in ARTIFACTS if not (out / name).is_file()]
    if missing:
        return {"state": "missing", "missing": missing, "stale_inputs": [],
                "message": "Generated specification evidence has not been prepared yet."}
    state = "unavailable"
    try:
        fingerprint = _fingerprint(base, product)
        if fingerprint is not None:
            key = (str(base), product.relative_to(base).as_posix(), fingerprint)
            with _CACHE_LOCK:
                state = _CACHE.get(key)
            if state is None:
                state = _run_check(key[0], key[1])
                if _fingerprint(base, product) != fingerprint:
                    state = "unavailable"
                if state in {"current", "stale"}:
                    with _CACHE_LOCK:
                        _CACHE[key] = state
                        while len(_CACHE) > 32:
                            _CACHE.popitem(last=False)
    except (OSError, ValueError, TypeError, KeyError):
        state = "unavailable"
    messages = {"current": "Generated specification evidence is current for the saved inputs.",
                "stale": "Generated specification evidence is out of date with a saved input.",
                "unavailable": "Generated specification evidence could not be verified."}
    return {"state": state, "missing": [], "stale_inputs": [], "message": messages[state]}


def researcher_message(summary: dict) -> str:
    """Plain-language action copy for the researcher-facing banner."""
    state = summary.get("state")
    if state == "stale":
        return ("Your saved change is kept, but the review outline still describes the previous inputs. "
                "Refresh the generated evidence before continuing.")
    if state == "missing":
        return "Prepare the generated specification evidence before reviewing definitions."
    return ""
