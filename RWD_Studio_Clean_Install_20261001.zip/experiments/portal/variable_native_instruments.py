"""Typed review adapters for existing native instrument stages.

No coefficients, eligibility windows or clinical instruments are supplied here.
The saved native block is validated by the very stage that will execute it.
"""
from copy import deepcopy
import importlib
import json
import re

from experiments.portal.variable_review_consistency import canonical_type
from engine.stages import record_calculations

GOVERNED = {"instrument", "citation", "clinically_reviewed_by", "review_date"}
SPECS = {
    "value_in_window": ("outcomes", "record_values", "A value within a date window"),
    "time_to_event": ("outcomes", "time_to_events", "Time until an event or censor date"),
    "risk_score": ("outcomes", "risk_scores", "Points-based risk score"),
    "serial_marker": ("outcomes", "serial_markers", "Confirmed change in serial measurements"),
    "rt_course": ("treatment", "rt_courses", "Radiotherapy courses"),
    "dose_exposure": ("treatment", "dose_exposures", "Dose exposure"),
    "modality_relation": ("outcomes", "modality_relations", "Relationship between dated episodes"),
}
FIELDS = {
    "value_in_window": record_calculations.VALUE_FIELDS,
    "time_to_event": record_calculations.EVENT_FIELDS,
    "risk_score": {"name", "components", "categories", "incomplete"} | GOVERNED,
    "serial_marker": {"name", "source", "marker_column", "date_column", "series_scope", "reference", "direction", "threshold_pct", "threshold_abs", "confirm_after_days", "event_date", "same_day"} | GOVERNED,
    "rt_course": {"name", "source", "mode", "start_column", "end_column", "date_column", "gap_days"} | GOVERNED,
    "dose_exposure": {"name", "source", "drug_column", "dose_column", "unit_column", "date_column", "drugs", "unit", "window_days_before", "window_days_after", "reduce"},
    "modality_relation": {"name", "relation", "a_start_column", "a_end_column", "b_start_column", "b_end_column", "window_days"},
}
RESULTS = {
    "value_in_window": [("value", "", "double"), ("date", "dt", "date"), ("count", "n", "integer"), ("status", "status", "string")],
    "time_to_event": [("time", "", "double"), ("date", "dt", "date"), ("flag", "fl", "integer"), ("event_reason", "event", "string"), ("censor_reason", "censor", "string"), ("status", "status", "string")],
    "risk_score": [("value", "", "integer"), ("label", "gr", "string"), ("code", "grn", "integer")],
    "serial_marker": [("date", "", "date"), ("flag", "fl", "integer")],
    "rt_course": [("flag", "fl", "integer"), ("count", "n", "integer"), ("start_date", "dt", "date"), ("end_date", "enddt", "date")],
    "dose_exposure": [("value", "", "double")],
    "modality_relation": [("flag", "", "integer")],
}
DERIVED = {"risk_score", "modality_relation", "time_to_event"}
IDENTIFIER = re.compile(r"[A-Za-z][A-Za-z0-9_]{0,127}")


def module(operator):
    if operator in {"value_in_window", "time_to_event"}:
        return record_calculations
    return importlib.import_module("engine.stages." + operator)


def is_native(rule):
    return isinstance(rule, dict) and rule.get("operator") in SPECS


def _shape(native, operator):
    if not isinstance(native, dict) or set(native) - FIELDS[operator]:
        raise ValueError("This instrument contains fields the native calculation does not read.")
    def walk(value, depth=0):
        if depth > 12:
            raise ValueError("Instrument settings are nested too deeply.")
        if isinstance(value, dict):
            if len(value) > 1000 or any(not isinstance(key, str) for key in value):
                raise ValueError("Instrument fields must be a bounded text-keyed mapping.")
            for child in value.values(): walk(child, depth + 1)
        elif isinstance(value, list):
            if len(value) > 1000: raise ValueError("Instrument lists exceed 1000 entries.")
            for child in value: walk(child, depth + 1)
        elif isinstance(value, str) and (len(value) > 12000 or any(ord(c) < 32 and c not in "\n\r\t" for c in value)):
            raise ValueError("Instrument text must be plain text of at most 12000 characters.")
    walk(native)
    for field in ("components", "categories", "drugs"):
        if field in native and not isinstance(native[field], list):
            raise ValueError(field + " must be a list of reviewed choices.")
    if any(not isinstance(drug, str) or not drug.strip() for drug in native.get("drugs", [])):
        raise ValueError("Drug choices must be nonempty text names, not numbers or nested objects.")
    text_fields = GOVERNED | {"reference", "direction", "series_scope", "event_date", "same_day",
                              "mode", "reduce", "unit", "relation"}
    for field in text_fields & set(native):
        if native[field] is not None and not isinstance(native[field], str):
            raise ValueError(field + " must be text, not a number or nested object.")
    for field in {"threshold_pct", "threshold_abs", "confirm_after_days", "gap_days", "window_days", "window_days_before", "window_days_after"} & set(native):
        if native[field] is not None and type(native[field]) not in (int, float):
            raise ValueError(field + " must be a number, not text or a yes/no choice.")
    for field, value in native.items():
        if field in {"name", "source"} or field.endswith("_column"):
            if value not in (None, "") and (not isinstance(value, str) or not IDENTIFIER.fullmatch(value)):
                raise ValueError(field + " needs a letter-led column or source identifier.")
    if operator == "risk_score":
        for component in native.get("components") or []:
            if not isinstance(component, dict) or set(component) - {"name", "column", "bands", "values"}:
                raise ValueError("Risk components need name, column and one points table.")
            for field in ("bands", "values"):
                if field in component and not isinstance(component[field], list):
                    raise ValueError("Risk component " + field + " must be a table.")
            for name in ("name", "column"):
                if component.get(name) and not IDENTIFIER.fullmatch(str(component[name])):
                    raise ValueError("Risk component " + name + " must be an identifier.")
            for band in component.get("bands") or []:
                if not isinstance(band, dict) or set(band) - {"min", "min_excl", "max", "max_excl", "when", "points"}:
                    raise ValueError("Numeric points must contain bounds, points and optional fallthrough only.")
            for group in component.get("values") or []:
                if not isinstance(group, dict) or set(group) - {"from_prefixes", "from_equals_ci", "when", "points"}:
                    raise ValueError("Category points need exact matching values or a missing case.")
                for field in {"from_prefixes", "from_equals_ci"} & set(group):
                    if not isinstance(group[field], list) or any(not isinstance(item, str) or not item.strip() for item in group[field]):
                        raise ValueError("Risk category matching values must be lists of nonempty text.")
        for category in native.get("categories") or []:
            if not isinstance(category, dict) or set(category) - {"min", "min_excl", "max", "max_excl", "label", "code"}:
                raise ValueError("Risk categories need numeric boundaries, label and code.")
        if native.get("incomplete") is not None and (not isinstance(native["incomplete"], dict) or set(native["incomplete"]) - {"label", "code"}):
            raise ValueError("The incomplete-risk result needs only label and code.")


def validate(rule, allow_incomplete=True):
    if not isinstance(rule, dict) or set(rule) - {"version", "operator", "family", "output_stem", "result", "native"}:
        raise ValueError("Use only the versioned native instrument fields.")
    if type(rule.get("version")) is not int or rule["version"] != 1 or rule.get("operator") not in SPECS:
        raise ValueError("Choose a version 1 native instrument.")
    if rule.get("family") != rule["operator"]:
        raise ValueError("The instrument family must match its operation.")
    try:
        raw = json.dumps(rule, allow_nan=False).encode()
    except (TypeError, ValueError, RecursionError) as error:
        raise ValueError("Instrument settings must be finite JSON values.") from error
    if len(raw) > 256 * 1024: raise ValueError("Instrument settings exceed 256 KiB.")
    if rule.get("output_stem") and not IDENTIFIER.fullmatch(str(rule["output_stem"])):
        raise ValueError("The instrument output name must start with a letter.")
    if rule.get("result") and rule["result"] not in result_names(rule):
        raise ValueError("Choose one of this instrument's delivered results.")
    _shape(rule.get("native", {}), rule["operator"])
    if rule.get("native", {}).get("name") and rule["native"]["name"] != rule.get("output_stem"):
        raise ValueError("The native instrument and reviewed output stem must agree.")
    result = deepcopy(rule)
    if not allow_incomplete:
        missing = issues({"clinical_rule": result})
        if missing: raise ValueError(" ".join(missing))
    return result


def native(rule, alias=None):
    item = deepcopy(rule.get("native") or {})
    item["name"] = rule.get("output_stem", "")
    if rule["operator"] not in DERIVED:
        item["source"] = alias or item.get("source") or "review_source"
    return item


def emitted_columns(rule):
    stem = rule.get("output_stem")
    if stem and rule["operator"] in {"value_in_window", "time_to_event"}:
        item = native(rule)
        # An incomplete value draft still needs the correct companion outputs.
        if rule["operator"] == "value_in_window":
            item.setdefault("source", "review_source")
        adapter = item.get("adapter")
        if adapter == "baseline_ecog":
            return [{"name": "ecog", "type": "string", "result": "label"},
                    {"name": "ecogn", "type": "integer", "result": "code"}]
        if adapter == "lab_values":
            return [{"name": stem, "type": "double", "result": "value"},
                    {"name": stem[:-1] + "dt", "type": "date", "result": "date"},
                    {"name": stem[:-1], "type": "string", "result": "status"}]
        if adapter == "psa_timepoints":
            return [{"name": stem, "type": "double", "result": "value"}]
        if adapter == "overall_survival":
            return record_calculations.output_columns(item)[:1]
        if adapter == "progression":
            # The incumbent overall-cohort NULL column widens the union to double.
            return [{"name": stem, "type": "double", "result": "time"},
                    {"name": stem + "dt", "type": "date", "result": "date"},
                    {"name": stem + "fl", "type": "integer", "result": "flag"}]
        return record_calculations.output_columns(item)
    return [{"name": stem + suffix, "type": dtype, "result": result}
            for result, suffix, dtype in RESULTS[rule["operator"]]] if stem else []


def result_names(rule):
    if rule.get("native", {}).get("adapter"):
        return {column["result"] for column in emitted_columns(rule)}
    return {entry[0] for entry in RESULTS[rule["operator"]]}


def requires(rule):
    item, operator = native(rule), rule["operator"]
    if operator == "modality_relation":
        return [item[k] for k in ("a_start_column", "a_end_column", "b_start_column", "b_end_column") if item.get(k)]
    return module(operator).requires(item)


def issues(row, *, require_review=True):
    rule = row.get("clinical_rule") or {}
    try:
        validate(rule)
        check = module(rule["operator"]).instrument_errors
        review_option = {"require_review": require_review} if rule["operator"] in {"risk_score", "serial_marker", "rt_course"} else {}
        result = check(native(rule), **review_option)
        if rule["operator"] == "risk_score":
            components = (rule.get("native") or {}).get("components") or []
            ranges = []
            for component in components:
                points = [entry.get("points") for entry in (component.get("bands") or component.get("values") or [])]
                if any(type(value) is not int for value in points):
                    result.append("The guided risk-score editor supports whole-number points only. "
                                  "Fractional or decimal points need an engineering handoff that preserves "
                                  "the exact decimal output type; they are never rounded here.")
                    break
                if points:
                    ranges.append((min(points), max(points)))
            low_total = high_total = 0
            overflow = False
            for low, high in ranges:
                low_total += low
                high_total += high
                overflow |= low < -(2 ** 31) or high > 2 ** 31 - 1 or low_total < -(2 ** 31) or high_total > 2 ** 31 - 1
            if overflow:
                result.append("This points table can exceed the guided editor's 32-bit whole-number result. "
                              "Use an engineering handoff to declare and verify a larger exact output type.")
            codes = [entry.get("code") for entry in (rule["native"].get("categories") or [])]
            codes.append((rule["native"].get("incomplete") or {}).get("code"))
            if any(value is not None and (type(value) is not int or not -(2 ** 31) <= value <= 2 ** 31 - 1) for value in codes):
                result.append("Use whole-number category codes within the supported integer range. "
                              "Decimal code literals need an engineering handoff for their exact output type; they are not rounded.")
    except (ValueError, TypeError, KeyError, OverflowError) as error:
        return [str(error)]
    if not rule.get("result"): result.append("Choose which result to deliver.")
    expected = next((c for c in emitted_columns(rule) if c["result"] == rule.get("result")), None)
    actual = ((row.get("values") or {}).get("output") or {}).get("type")
    actual_type = str(actual).lower().replace(" ", "") if expected and expected["type"].startswith("decimal(") else canonical_type(actual)
    if expected and actual not in (None, "", "TODO") and actual_type != expected["type"]:
        result.append("This result needs data type " + expected["type"] + ".")
    return result


def source_issues(row):
    rule = row.get("clinical_rule") or {}
    source = (row.get("values") or {}).get("source") or {}
    if rule["operator"] in DERIVED:
        return [] if source.get("kind") == "derived" else ["Choose Calculated from other variables for this instrument."]
    result = []
    if source.get("kind") != "vendor": result.append("Choose Existing data column for this instrument.")
    if not source.get("logical_table"): result.append("Choose this instrument's source table.")
    for name in ["patientid", *requires(rule)]:
        value = (source.get("columns") or {}).get(name)
        if not isinstance(value, str) or not IDENTIFIER.fullmatch(value):
            result.append("Map the source column " + name + ".")
    declared = (rule.get("native") or {}).get("source")
    if declared and declared != source.get("logical_table"):
        result.append("The instrument's named source differs from the reviewed source table.")
    return result


def scientific_updates(rule):
    rule = validate(rule)
    result = {"clinical_rule": rule}
    if issues({"clinical_rule": rule}): return result
    output = next(c for c in emitted_columns(rule) if c["result"] == rule["result"])
    result.update({"output.type": output["type"], "grain": "One value per patient within each cohort",
                   "anchor": "Cohort index date where the instrument declares an index window",
                   "window": "Explicit native instrument settings", "record_selection": "As defined in the reviewed instrument",
                   "tie_break": "As defined in the reviewed instrument",
                   "derivation": SPECS[rule["operator"]][2] + ": deliver " + rule["result"] +
                       " using the complete reviewed instrument settings. Coefficients, selection choices and provenance remain in the structured rule."})
    if (rule.get("native") or {}).get("unit"):
        result["units"] = rule["native"]["unit"]
    if rule["operator"] == "value_in_window":
        from engine.record_windows import parse_window
        item = rule["native"]
        result.update(anchor=item["window"]["anchor"],
                      window=parse_window(item["window"], allow_named_anchor=True).describe(),
                      record_selection=item["select"], tie_break=json.dumps(item["tie_break"], sort_keys=True),
                      missing=json.dumps(item["missing"], sort_keys=True),
                      derivation=f"Read {item['value']['column']} as {item['value']['type']} from {item['source']}; "
                          f"use {item['date_basis']['combine']} of {', '.join(item['date_basis']['columns'])}; "
                          f"select {item['select']} inside the stated window. Apply the complete filters and missing-value choices in the attached typed rule.")
        if item["value"].get("transform"):
            result["units"] = item["value"]["transform"]["output_unit"]
        if item["value"].get("valid_range"):
            result["derivation"] += " Usable values after unit conversion: " + json.dumps(item["value"]["valid_range"], sort_keys=True) + ". Excluded values retain source-existence evidence."
    elif rule["operator"] == "time_to_event":
        item = rule["native"]
        result.update(anchor=item["start"], record_selection=item["event_selection"],
                      tie_break="Same day: " + item["same_day"],
                      window="Event offsets: " + json.dumps(item["events"], sort_keys=True),
                      units=item["time_unit"], derivation=f"Measure {item['time_unit']} from {item['start']}; "
                          f"event selection {item['event_selection']}, censor selection {item['censor_selection']}; "
                          f"same-day precedence {item['same_day']}; {item['day_count']} day count divided by {item['days_per_unit']}. " +
                          ("Follow-up eligibility comes from the contract-bound product preparation. " if item['min_followup_days'] is None else
                           f"Minimum follow-up {item['min_followup_days']} days, policy {item['short_followup']}. ") +
                          "Event offsets and censor reasons are retained in the attached typed rule.")
    if rule["operator"] in {"value_in_window", "time_to_event"} and rule["native"].get("publication"):
        result["derivation"] += " Numeric publication: " + json.dumps(rule["native"]["publication"], sort_keys=True) + "."
    return result


def compile_rows(rows, cfg):
    from engine.config import canonical_physical
    from engine.validate import emitted_variables
    result = {"operations": [], "rows": [], "blockers": []}
    rows = [row for row in rows if is_native(row.get("clinical_rule") or {})]
    if not rows:
        return result
    targets, seen, outputs = {}, {}, {}
    known = set(emitted_variables(cfg)) | {"patientid", "index_date", "cohort", "cohortn", "age", "race", "ecogn"}
    def block(row, message):
        result["blockers"].append({"item_id": row.get("item_id", ""), "variable_id": row.get("variable_id", ""), "message": message})
    for row in rows:
        rule = row.get("clinical_rule") or {}
        if not is_native(rule): continue
        report = {"item_id": row.get("item_id", ""), "variable_id": row.get("variable_id", ""), "status": "blocked", "emitted_columns": emitted_columns(rule), "read_roles": requires(rule)}
        result["rows"].append(report)
        output = (row.get("values") or {}).get("output") or {}
        if output.get("role") == "excluded":
            report["status"] = "excluded"
            continue
        why = issues(row) + source_issues(row)
        role, key, _ = SPECS[rule["operator"]]
        path = "variables/" + role + ".yaml"
        if path not in (getattr(cfg, "raw", {}).get("variables") or []):
            why.append("Activate " + path + " before compiling this instrument.")
        expected = next((c for c in emitted_columns(rule) if c["result"] == rule.get("result")), None)
        if expected and output.get("physical_name") != expected["name"]:
            why.append("Use the delivered physical output name " + expected["name"] + ".")
        if output.get("role") not in {"published", "internal"}: why.append("Choose a published or internal output.")
        source = row.get("values", {}).get("source", {})
        alias = source.get("logical_table")
        if rule["operator"] not in DERIVED and not source_issues(row):
            if alias not in cfg.sources:
                why.append("The reviewed source alias is not configured.")
            else:
                from engine.validate import adapter_rename_conflicts
                why.extend(adapter_rename_conflicts(cfg))
                mapping = canonical_physical(cfg, alias)
                if source.get("physical_stem"):
                    from rwd_tools import source_check
                    expected_stem = source_check.config_base(cfg, alias)
                    selected_stem = source_check.CUT.sub("", str(source["physical_stem"]).strip().casefold())
                    if selected_stem != expected_stem.casefold():
                        why.append("The reviewed source table differs from the active configured table.")
                for name in ["patientid", *requires(rule)]:
                    if source["columns"][name].casefold() != mapping.get(name.casefold(), name.casefold()):
                        why.append("The reviewed mapping of " + name + " differs from the configured adapter.")
        try:
            existing = deepcopy(cfg.pack(role).get(key) or [])
            if not isinstance(existing, list): raise ValueError("The target instrument block must be a list.")
            item = native(rule, alias)
            prior = next((old for old in existing if old.get("name") == item["name"]), None)
            if prior and set(prior) - set(item): why.append("The existing native instrument has additional settings; review them before replacement.")
        except (ValueError, TypeError, KeyError) as error:
            why.append(str(error)); existing, item, prior = [], native(rule, alias), None
        identity = (role, key, rule.get("output_stem"))
        if identity in seen and seen[identity] != item: why.append("Two reviewed rows disagree on the same native instrument.")
        seen[identity] = item
        prior_outputs = module(rule["operator"]).emitted([prior]) if prior else set()
        if item.get("adapter"):
            prior_outputs |= {c["name"] for c in report["emitted_columns"]}
            why.extend(record_calculations.adapter_errors(cfg, item))
        if rule["operator"] == "risk_score" and prior: prior_outputs.add(prior["name"] + "grn")
        for emitted in report["emitted_columns"]:
            name = emitted["name"]
            folded = name.casefold()
            if folded in {n.casefold() for n in known - prior_outputs} or folded in outputs and outputs[folded] != identity:
                why.append("Native output " + name + " collides with an existing output.")
            outputs[folded] = identity
        if why:
            for message in why: block(row, message)
            continue
        target = targets.setdefault((path, key), existing)
        index = next((i for i, old in enumerate(target) if old.get("name") == item["name"]), None)
        if index is None: target.append(item)
        else: target[index] = item
        report["status"] = "compiled"
    for (path, key), value in targets.items():
        result["operations"].append({"path": path, "pointer": "/" + key, "value": value})
    from rwd_tools import reviewed_variable_record as reviewed
    contexts = {}
    adapters = deepcopy(cfg.pack("outcomes").get("calculation_adapters") or {})
    for row in rows:
        rule = row["clinical_rule"]
        adapter = (rule.get("native") or {}).get("adapter")
        if adapter:
            names = adapters.setdefault(adapter, [])
            if rule["output_stem"] not in names: names.append(rule["output_stem"])
        for ref, value in row.get("configuration", {}).items():
            try:
                path, pointer = reviewed.configuration_pointer(ref)
                if ref in contexts and contexts[ref]["value"] != value:
                    raise ValueError("Two reviewed rows disagree on " + ref)
                contexts[ref] = {"path": path, "pointer": pointer, "value": deepcopy(value)}
            except ValueError as error:
                block(row, str(error))
    result["operations"].extend(contexts.values())
    if any((row["clinical_rule"].get("native") or {}).get("adapter") for row in rows):
        result["operations"].append({"path": "variables/outcomes.yaml", "pointer": "/calculation_adapters", "value": adapters})
    if result["blockers"]: result["operations"] = []
    return result


def dependency_issues(rows, cfg, compiled):
    """Respect the actual build order; later stage outputs cannot feed risk scores."""
    from engine.validate import emitted_variables
    available = set(emitted_variables(cfg)) | {"patientid", "index_date", "cohort", "cohortn", "age", "race", "ecogn"}
    staged_outputs = {}
    for row in rows:
        rule = row.get("clinical_rule") or {}
        if not rule: continue
        from experiments.portal import variable_clinical_rules
        staged_outputs.setdefault(rule["operator"], set()).update(c["name"] for c in variable_clinical_rules.emitted_columns(rule))
    later_than_risk = set()
    for operator, (role, key, _) in SPECS.items():
        existing = cfg.pack(role).get(key) or []
        outputs = module(operator).emitted(existing)
        if operator == "risk_score": outputs |= {item["name"] + "grn" for item in existing if item.get("name")}
        later_than_risk |= outputs
    non_native = set().union(*(values for operator, values in staged_outputs.items() if operator not in SPECS), set())
    all_staged = set().union(*staged_outputs.values(), set())
    result = []
    # The new primitives run after the older instruments, values first and then
    # events. Validate the staged order, including anchors produced by a value.
    from copy import deepcopy
    staged = deepcopy(cfg.pack("outcomes"))
    for operation in compiled.get("operations", []):
        if operation["path"] == "variables/outcomes.yaml":
            staged[operation["pointer"].lstrip("/")] = operation["value"]
    class Proposed:
        def pack(self, role):
            return staged if role == "outcomes" else cfg.pack(role)
    new_outputs = set().union(*(record_calculations.emitted(staged.get(key)) for key in record_calculations.KEYS))
    # Existing collisions were checked while compiling each row. Keep earlier
    # staged operators available without making a new rule its own producer.
    earlier_staged = set().union(*(values for op, values in staged_outputs.items() if op not in {"value_in_window", "time_to_event"}), set())
    for message in (record_calculations.dependency_errors(Proposed(), (available - new_outputs) | earlier_staged)
                    + record_calculations.earlier_stage_errors(Proposed())):
        result.append({"item_id": "", "variable_id": "", "message": message})
    for row in rows:
        rule = row.get("clinical_rule") or {}
        if rule.get("operator") not in DERIVED or rule.get("operator") == "time_to_event" or ((row.get("values") or {}).get("output") or {}).get("role") == "excluded": continue
        if rule["operator"] == "risk_score":
            known = (available - later_than_risk) | non_native
        else:
            own = staged_outputs.get("modality_relation", set()) | module("modality_relation").emitted(cfg.pack("outcomes").get("modality_relations") or [])
            known = (available | all_staged) - own
        missing = sorted(set(requires(rule)) - known)
        if missing:
            result.append({"item_id": row.get("item_id", ""), "variable_id": row.get("variable_id", ""),
                           "message": "This calculation reads columns unavailable at its execution step: " + ", ".join(missing) + "."})
    return result
