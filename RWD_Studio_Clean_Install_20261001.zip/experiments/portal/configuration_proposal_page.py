"""Review isolated configuration proposals without changing the live product.

The editor is offered to any product whose files carry a supported setting; it never
names a product. A product with none simply does not show this section.
"""
from __future__ import annotations

import hashlib
import json
import math
import uuid
from copy import deepcopy
from datetime import date
from pathlib import Path

import streamlit as st

from experiments.portal import configuration_proposals as proposals
from experiments.portal import form_assistance as form_help


def _workbook_policy_settings(root, pack, actor_id, *, permitted, local_demo, can_write, allowed_packs, prefix, active, current_context):
    """Explicit product defaults replace repeated per-column publication questions."""
    captured = (current_context.get("context") or {}).get("drafting_policy")
    loaded = ({"ok": True, **captured, "input_digest": current_context["input_digest"]}
              if isinstance(captured, dict) and "policy_digest" in captured else
              proposals.workbook_drafting_policy(root, pack, actor_id=actor_id, allowed_packs=allowed_packs))
    if not loaded.get("ok"):
        _show_errors(loaded, "Shared drafting choices could not be read. Existing drafts remain available.")
        return
    policy = loaded.get("policy") or {}
    configured = loaded.get("configured") is True
    key = prefix + "policy_" + str(loaded.get("policy_digest") or "new")[:16] + "_"
    labels = {"ads": "Analytic dataset (ADS)", "dictionary": "Data dictionary",
              "dashboard": "Dashboard", "tfl": "Tables, figures and listings"}
    roles = {"published": "Include in the selected outputs", "internal": "Use only during preparation"}
    with st.expander("Shared choices for this product", expanded=not configured):
        st.caption("Set these once for unfinished column definitions. Explicit variable choices and reviewed definitions keep their own settings. These choices do not approve a definition or release an output.")
        editable = bool(permitted and not active)
        role = st.selectbox("How should new data columns be used?", list(roles),
            index=list(roles).index(policy["default_output_role"]) if policy.get("default_output_role") in roles else None,
            placeholder="Choose a use", format_func=roles.get, disabled=not editable, key=key + "role")
        destinations = st.multiselect("Default output destinations", list(labels),
            default=[value for value in policy.get("destinations", []) if value in labels],
            format_func=labels.get, disabled=not editable, key=key + "destinations")
        naming = st.selectbox("Default output names", ["preserve_physical_name"],
            index=0 if policy.get("naming_rule") == "preserve_physical_name" else None,
            placeholder="Choose how to name outputs", format_func=lambda _value: "Keep the variable's data column name",
            disabled=not editable, key=key + "naming")
        st.caption("Different names or destinations can still be entered for individual variables. Parameters and document context are not turned into data columns.")
        chosen = {"destinations": destinations, "naming_rule": naming, "default_output_role": role}
        conflict = role == "internal" and "ads" in destinations
        complete = bool(role and naming and (role == "internal" or destinations) and not conflict)
        if conflict:
            st.info("An internal preparation column cannot also be a delivered ADS column. Remove ADS or choose to include the column in outputs.")
        if active:
            st.caption("Shared choices can be changed after the current drafting job finishes or is cancelled.")
        if st.button("Save shared drafting choices", key=key + "save", disabled=not (editable and complete)):
            result = proposals.save_workbook_drafting_policy(root, pack, actor_id=actor_id, policy=chosen,
                expected_input_digest=loaded["input_digest"], expected_policy_digest=loaded["policy_digest"],
                local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
            if result.get("ok"):
                st.session_state[prefix + "policy_notice"] = "Shared choices saved. A new draft will use them; earlier drafts retain their original settings."
                st.rerun()
            else:
                _show_errors(result, "Shared choices were not saved. Your entries are retained; reload the latest product before trying again.")


def _workbook_revalidation(root, pack, actor_id, candidate_id, candidate, current_context, *,
        permitted, local_demo, can_write, allowed_packs, active, prefix):
    """Explicitly compare an old packet with today's inputs; never apply it."""
    with st.expander("Check this saved draft against current inputs", expanded=True):
        st.caption("Keep the saved proposal and answers while checking them again. Older drafts do not record enough detail to distinguish a source change from a software change. Review every saved choice against the current inputs before creating a current private copy.")
        available = bool(permitted and current_context.get("ok") and not active)
        if active:
            st.caption("Wait for the running drafting job to finish before checking this saved draft.")
        preview_key = prefix + "revalidation_preview_" + candidate_id
        if st.button("Preview checks against current inputs", key=prefix + "revalidation_preview_button_" + candidate_id,
                disabled=not available):
            try:
                st.session_state[preview_key] = proposals.preview_workbook_candidate_revalidation(root, pack,
                    actor_id=actor_id, candidate_id=candidate_id, expected_digest=candidate["digest"],
                    local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
            except (ValueError, OSError) as error:
                st.session_state[preview_key] = {"ok": False,
                    "errors": form_help.validation_messages([str(error)])[0]}
        preview = st.session_state.get(preview_key)
        if not preview:
            return
        if not preview.get("ok"):
            _show_errors(preview, "This draft could not be checked. Its proposal and answers are still saved.")
            return
        if (preview.get("candidate_id") != candidate_id or preview.get("parent_candidate_digest") != candidate.get("digest")
                or preview.get("input_digest") != current_context.get("input_digest")):
            st.warning("The inputs or saved draft changed after this preview. Preview the checks again; your saved proposal and answers are retained.")
            return
        fresh = preview.get("candidate") or {}
        with st.expander("Current workbook requirements and source settings"):
            context = preview.get("current_context") or current_context.get("context") or {}
            st.dataframe([{"Specification row": row.get("item_id", ""),
                "Variable": row.get("variable_id", ""),
                "Current source rule": (row.get("evidence") or {}).get("required_rule", "")}
                for row in context.get("rows", [])], hide_index=True, width="stretch")
            st.json({"source_settings": context.get("source_bindings") or {},
                "native_configuration": context.get("native_configuration") or {}})
        answers = (preview.get("reconfirmation") or {}).get("answers") or []
        pending_answers = (preview.get("reconfirmation") or {}).get("pending_answers") or []
        st.caption(f"{len(answers)} saved answers are retained. Checking them again does not approve them.")
        if pending_answers:
            st.caption(f"{len(pending_answers)} saved answers have not yet been incorporated into the draft. They remain pending for explicit continuation.")
        if answers:
            with st.expander("Review all saved answers", expanded=True):
                st.dataframe([{"Specification row": answer.get("item_id", ""),
                    "Question": answer.get("question", ""), "Saved answer": answer.get("answer", ""),
                    "State": "Not yet incorporated" if answer in pending_answers else "Saved answer"}
                    for answer in answers], hide_index=True, width="stretch")
        st.write("Current technical checks")
        checks = preview.get("checks") or fresh.get("checks") or []
        st.dataframe([{"Check": check.get("validator", ""),
            "Result": "Not completed" if not check.get("completed") else "Passed" if check.get("passed") else "Needs attention",
            "Findings": len(check.get("errors") or [])} for check in checks], hide_index=True, width="stretch")
        with st.expander("Review current findings and exact draft changes", expanded=True):
            st.json({"coverage": fresh.get("coverage"), "checks": checks,
                "findings": preview.get("findings") or fresh.get("findings") or [],
                "questions": fresh.get("questions") or [],
                "question_changes": preview.get("question_changes") or [],
                "provenance_findings": preview.get("provenance_findings") or []})
            for file in preview.get("files") or fresh.get("files") or []:
                st.caption(file["path"])
                st.code(file.get("diff") or "No change", language="diff")
        if preview.get("errors"):
            _show_errors(preview, "Resolve these issues before creating a current private copy.")
        confirm_key = prefix + "revalidation_confirm_" + hashlib.sha256(json.dumps([
            candidate_id, candidate.get("digest"), preview.get("input_digest"), preview.get("preview_digest")]).encode()).hexdigest()[:24]
        confirmation = preview.get("confirmation_text") or "I checked every saved choice and answer against the current workbook and source settings and reaffirm them for this unapproved draft."
        can_save = bool(available and preview.get("can_save") and preview.get("preview_digest"))
        confirmed = st.checkbox(confirmation, key=confirm_key, disabled=not can_save)
        st.caption("This creates a separate private draft with current checks. It makes no model request, changes no product files and records no scientific, source or release approval. Unfinished requirements remain unfinished.")
        if st.button("Create current private draft", key=prefix + "revalidation_save_" + candidate_id,
                disabled=not (can_save and confirmed)):
            try:
                saved = proposals.revalidate_workbook_candidate(root, pack, actor_id=actor_id,
                    candidate_id=candidate_id, expected_digest=candidate["digest"],
                    expected_input_digest=preview["input_digest"], expected_preview_digest=preview["preview_digest"],
                    confirmed=True, local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
            except (ValueError, OSError) as error:
                saved = {"ok": False, "errors": form_help.validation_messages([str(error)])[0]}
            if saved.get("ok") and saved.get("candidate_id"):
                st.session_state[prefix + "open_candidate"] = saved["candidate_id"]
                st.session_state[prefix + "revalidation_notice"] = "A current private draft was created. The earlier draft is retained; review the current checks before continuing. No product changes or approvals were made."
                st.session_state.pop(preview_key, None)
                st.rerun()
            else:
                _show_errors(saved, "The current private draft was not created. Your saved proposal and answers are retained.")


def _workbook_retained_answers(candidate, current_context, questions):
    """Restore exact, currently bound answers as editable input, never decisions."""
    from experiments.portal import scientific_definition_ai as ai
    current_digest = current_context.get("input_digest")
    if (not current_context.get("ok") or not isinstance(current_digest, str) or not current_digest
            or candidate.get("input_digest") != current_digest):
        return {}
    records = {row["item_id"]: row for row in (candidate.get("proposal") or {}).get("records", [])}
    current_items = {row["item_id"] for row in (current_context.get("context") or {}).get("rows", [])}
    origins = ai._workbook_saved_origins(records, candidate,
        context=current_context.get("context") or {}, input_digest=current_digest)
    restored = {}
    for question in questions:
        item_id, identifier = question.get("item_id"), question.get("id")
        origin = origins.get(item_id) or {}
        if (item_id not in current_items or origin.get("kind") not in {"owner_answer", "model_draft", "unknown"}
                or origin.get("record_sha256") != ai._hash(records[item_id])
                or origin.get("source_input_digest") != current_digest):
            continue
        fields = question.get("fields", [question["field"]] if isinstance(question.get("field"), str) else [])
        if not isinstance(fields, list) or any(not isinstance(field, str) for field in fields):
            continue
        fields = fields or ["*"]
        choices = question.get("choices", [])
        if not isinstance(choices, list) or any(not isinstance(choice, str) for choice in choices):
            continue
        pending = origin.get("pending_owner_answers", [])
        if not isinstance(pending, list) or any(not isinstance(answer, dict) for answer in pending):
            continue
        pending = [answer for answer in pending if answer.get("id") == identifier]
        if not pending and origin.get("kind") == "unknown":
            continue
        saved = pending or [answer for answer in origin.get("owner_answers", []) if isinstance(answer, dict) and answer.get("id") == identifier]
        matches = [answer for answer in saved if answer.get("item_id") == item_id
            and answer.get("question") == question.get("question") and answer.get("choices") == choices
            and answer.get("fields") == fields and isinstance(answer.get("answer"), str)
            and 0 < len(answer["answer"]) <= 1000 and answer["answer"] == answer["answer"].strip()]
        if len(saved) == len(matches) == 1:
            restored[identifier] = {"answer": matches[0]["answer"], "pending": bool(pending)}
    return restored


def _workbook_answer_revisions(candidate, current_context, questions):
    """Review new or retained explicit scopes on current private owner choices."""
    from experiments.portal import scientific_definition_ai as ai
    current_digest = current_context.get("input_digest")
    if (not current_context.get("ok") or not isinstance(current_digest, str) or not current_digest
            or candidate.get("input_digest") != current_digest):
        return {}
    records = {row["item_id"]: row for row in (candidate.get("proposal") or {}).get("records", [])}
    sources = {row["item_id"]: row for row in (current_context.get("context") or {}).get("rows", [])}
    origins = ai._workbook_saved_origins(records, candidate,
        context=current_context.get("context") or {}, input_digest=current_digest)
    revisions = {}
    for question in questions:
        item_id = question.get("item_id")
        fields = question.get("fields", [question["field"]] if isinstance(question.get("field"), str) else [])
        if item_id not in records or item_id not in sources:
            continue
        origin = origins.get(item_id) or {}
        if origin.get("kind") in {"existing_record", "approved_record"}:
            if fields in ([], ["*"]):
                revisions[question["id"]] = {"locked": True}
            continue
        protected = origin.get("owner_fields", ["*"] if origin.get("kind") == "owner_answer" else [])
        if (origin.get("kind") not in {"owner_answer", "model_draft"}
                or origin.get("record_sha256") != ai._hash(records[item_id])
                or origin.get("source_input_digest") != current_digest
                or not isinstance(protected, list) or not protected
                or any(not isinstance(field, str) for field in protected)):
            continue
        if not ai.workbook_answer_revision_allowed(question, origin):
            continue
        options = ai.workbook_answer_update_fields(current_context.get("write_schema") or {})
        selected_fields = [] if fields in ([], ["*"]) else list(fields)
        if any(field not in options for field in selected_fields):
            continue
        revisions[question["id"]] = {"locked": False, "item_id": item_id,
            "protected_fields": protected, "record": records[item_id],
            "options": options, "selected_fields": selected_fields,
            "binding": ai._hash([candidate.get("digest"), current_digest, records[item_id], question])[:24]}
    return revisions


def _workbook_failed_attempt_answers(job, root, pack, actor_id, candidate, current_context, questions, *, candidate_id, allowed_packs):
    """Recover only this current private packet's exact rejected submission."""
    arguments, result = job.get("arguments") or {}, job.get("result") or {}
    digest = current_context.get("input_digest")
    if (not isinstance(candidate_id, str) or not candidate_id
            or not current_context.get("ok") or not digest or candidate.get("input_digest") != digest
            or job.get("actor") != actor_id or job.get("root") != str(Path(root).resolve())
            or job.get("restored_at_new_path") or job.get("action") != "workbook_draft"
            or job.get("job_key") != "workbook-draft:" + pack or job.get("status") != "failed"
            or pack not in (allowed_packs or []) or pack not in job.get("allowed_packs", [])
            or any(item not in (allowed_packs or []) for item in job.get("allowed_packs", []))
            or arguments.get("pack") != pack or arguments.get("candidate_id") != candidate_id
            or arguments.get("expected_input_digest") != digest
            or result.get("ok") is not False or result.get("changed") is not False
            or result.get("retained_previous_candidate") is not True
            or result.get("candidate_id") != candidate_id):
        return {}
    submitted = arguments.get("answers")
    if not isinstance(submitted, dict) or not submitted or len(submitted) > len(questions):
        return {}
    current = {question.get("id"): question for question in questions}
    if len(current) != len(questions) or any(identifier not in current for identifier in submitted):
        return {}
    revisions = _workbook_answer_revisions(candidate, current_context, questions)
    recovered = {}
    for identifier, value in submitted.items():
        question = current[identifier]
        if (question.get("kind") in {"source", "source_correction", "source_qc"}
                or identifier != proposals._digest(proposals._encode([
                    question.get("item_id"), question.get("question"), question.get("choices", [])]))[:24]):
            return {}
        revision = revisions.get(identifier)
        if revision and revision.get("locked"):
            return {}
        fields = None
        if isinstance(value, dict):
            if set(value) != {"answer", "update_fields"} or not revision:
                return {}
            fields = value["update_fields"]
            if (not isinstance(fields, list) or not fields or any(not isinstance(field, str) for field in fields)
                    or len(set(fields)) != len(fields) or any(field not in revision["options"] for field in fields)):
                return {}
            value = value["answer"]
        elif revision:
            return {}
        if not isinstance(value, str) or not 0 < len(value) <= 1000 or value != value.strip():
            return {}
        recovered[identifier] = {"answer": value, "update_fields": fields}
    return recovered


def _workbook_restore_failed_answers(root, pack, actor_id, candidate, current_context, questions, history, *,
        candidate_id, permitted, active, prefix, allowed_packs):
    from experiments.portal import portal_jobs as jobs
    if not permitted or active:
        return
    attempts = [(job, _workbook_failed_attempt_answers(job, root, pack, actor_id, candidate, current_context,
        questions, candidate_id=candidate_id, allowed_packs=allowed_packs)) for job in history]
    eligible = next(((job, answers) for job, answers in attempts if answers), None)
    if not eligible:
        return
    job, answers = eligible
    st.caption(f"The previous failed attempt kept {len(answers)} submitted answers. Restore them if this form was reset. "
        "This replaces entries for those questions with the saved text and field choices for review; nothing is submitted.")
    if not st.button("Restore answers from previous attempt", key=prefix + "restore_attempt_" + candidate_id):
        return
    try:
        fresh_job = jobs.read(root, actor_id, job["id"], allowed_packs=allowed_packs)
        fresh_context = proposals.workbook_context(root, pack, actor_id=actor_id, allowed_packs=allowed_packs)
        loaded = proposals.load_workbook_candidate(root, pack, candidate_id=candidate_id,
            actor_id=actor_id, allowed_packs=allowed_packs)
        if (not loaded.get("ok") or loaded.get("stale") or loaded.get("candidate_id") != candidate_id
                or fresh_job.get("digest") != job.get("digest")
                or loaded["candidate"].get("digest") != candidate.get("digest")):
            raise ValueError("The saved attempt or draft changed. Reload the current draft before restoring answers.")
        answers = _workbook_failed_attempt_answers(fresh_job, root, pack, actor_id, loaded["candidate"],
            fresh_context, questions, candidate_id=candidate_id, allowed_packs=allowed_packs)
        if not answers:
            raise ValueError("The saved answers no longer match this draft and its current inputs. Nothing was restored.")
        revisions = _workbook_answer_revisions(candidate, fresh_context, questions)
        by_id = {question["id"]: question for question in questions}
        for identifier, saved in answers.items():
            key = prefix + candidate_id
            options = [option for option in by_id[identifier].get("choices", [])
                if isinstance(option, str) and option not in {"Not decided", "Enter an answer"}]
            value = saved["answer"]
            st.session_state[key + "_answer_" + identifier] = value if value in options else "Enter an answer"
            st.session_state[key + "_text_" + identifier] = value if value not in options else ""
            if saved["update_fields"] is not None:
                st.session_state[key + "_update_fields_" + identifier + "_" + revisions[identifier]["binding"]] = saved["update_fields"]
        st.success("Previous answers and field choices restored for review. Edit them if needed, then explicitly choose Continue with my answers. No model request or approval was made.")
    except (ValueError, OSError):
        st.warning("The saved attempt could not be restored against the current draft and inputs. Nothing was submitted; reload this draft and review its saved answers.")


def _workbook_update_field_label(field):
    labels = {"source": "Source", "derivation": "Calculation", "window": "Window",
        "missing": "Missing values", "record_selection": "Record selection", "tie_break": "Ties",
        "output": "Output naming", "acceptance": "Acceptance checks",
        "cohort_applicability": "Applicable cohorts", "implementation_refs": "Implementation links"}
    if "#/" in field:
        return "Configuration: " + field.split("#/", 1)[1].replace("_", " ").replace("/", " / ") + " (" + field + ")"
    parts = field.split(".")
    label = labels.get(parts[0], parts[0].replace("_", " ").capitalize())
    if len(parts) > 1:
        label += " / " + " / ".join(part.replace("_", " ") for part in parts[1:])
    return label + " (" + field + ")"


def _workbook_private_corrections(root, pack, actor_id, candidate_id, candidate, current_context, *,
        permitted, local_demo, can_write, allowed_packs, active, stale, prefix, variable_names):
    """Add explicit correction questions without editing or applying the proposal."""
    if stale:
        return
    eligible = proposals.workbook_row_correction_items(candidate, current_context)
    if not eligible:
        return
    binding = hashlib.sha256(json.dumps([candidate.get("digest"), current_context.get("input_digest"), eligible]).encode()).hexdigest()[:24]
    editable = bool(permitted and current_context.get("ok") and not active)
    with st.expander("Request a correction in this private draft"):
        st.caption("Choose the draft variables you want to revise. This adds correction questions to a separate private draft and keeps the earlier draft and saved answers. Then answer each question and choose which fields the assistant may change. No model request, product edit or approval happens here.")
        selected = st.multiselect("Draft variables to correct", eligible,
            format_func=lambda item: str(variable_names.get(item, item)) + " · " + item,
            key=prefix + "correction_rows_" + candidate_id + "_" + binding, disabled=not editable)
        if active:
            st.caption("Wait for the running drafting job to finish before requesting a correction.")
        if st.button("Request correction", key=prefix + "request_correction_" + candidate_id,
                     disabled=not (editable and selected)):
            try:
                result = proposals.request_workbook_row_corrections(root, pack, actor_id=actor_id,
                    candidate_id=candidate_id, item_ids=list(selected),
                    expected_candidate_digest=candidate["digest"], expected_input_digest=current_context["input_digest"],
                    confirmed=True, local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
            except (ValueError, OSError) as error:
                result = {"ok": False, "errors": form_help.validation_messages([str(error)])[0]}
            if result.get("ok") and result.get("candidate_id"):
                st.session_state[prefix + "open_candidate"] = result["candidate_id"]
                st.session_state[prefix + "correction_notice"] = (
                    "Correction questions added to a new private draft. Choose the fields to change and answer the questions below. "
                    "The earlier draft and saved answers are retained. No product changes or approvals were made.")
                st.rerun()
            else:
                _show_errors(result, "Correction questions could not be added. Your saved draft and answers are retained.")


def render_workbook_drafting(root, pack, actor_id, *, local_demo=False, can_write=False, allowed_packs=None):
    """Draft all source rows through a saved job, then review one exact packet."""
    from experiments.portal import scientific_definition_ai as ai
    from experiments.portal import portal_jobs as jobs
    from experiments.portal import portal_jobs_page as job_page
    from experiments.portal import authoring_session
    prefix = "workbook_draft_" + hashlib.sha256(json.dumps([str(root), pack, actor_id]).encode()).hexdigest()[:16] + "_"
    job_key = "workbook-draft:" + pack
    authority = authoring_session.CURRENT.get()
    permitted = bool(local_demo and can_write and (authority is None or "agent" in authority.permissions))
    st.subheader("Draft the whole workbook")
    st.caption("The assistant prepares a separate contract and configuration for every extracted requirement. Review the complete draft before applying it; scientific approvals remain separate.")
    try:
        context = proposals.workbook_context(root, pack, actor_id=actor_id, allowed_packs=allowed_packs)
        catalogue = proposals.list_workbook_candidates(root, pack, actor_id=actor_id, allowed_packs=allowed_packs)
        history = jobs.recent(root, actor_id, action="workbook_draft", job_key=job_key, allowed_packs=allowed_packs)
    except (ValueError, OSError) as error:
        _show_errors({"errors": form_help.validation_messages([str(error)])[0]}, "This workbook's draft inputs are unavailable.")
        return
    active = bool(history and history[0]["status"] in {"queued", "running"})
    notice = st.session_state.pop(prefix + "policy_notice", None)
    if notice:
        st.success(notice)
    revalidation_notice = st.session_state.pop(prefix + "revalidation_notice", None)
    if revalidation_notice:
        st.success(revalidation_notice)
    omission_notice = st.session_state.pop(prefix + "omission_notice", None)
    if omission_notice:
        st.success(omission_notice)
    correction_notice = st.session_state.pop(prefix + "correction_notice", None)
    if correction_notice:
        st.success(correction_notice)
    if context.get("ok"):
        from experiments.portal import workflow_record_page
        if workflow_record_page.render_scaffold_metadata(root, pack, actor_id,
                local_demo=local_demo, can_review=can_write and not active,
                can_view=True, allowed_packs=allowed_packs):
            st.rerun()
        if context.get("optional_treatment_outputs") and workflow_record_page.render_treatment_omission(
                root, pack, actor_id, local_demo=local_demo, can_review=can_write and not active,
                can_view=True, allowed_packs=allowed_packs):
            st.session_state[prefix + "omission_notice"] = (
                "Output omissions saved as an unapproved draft. Continue the scientific and configuration reviews. "
                "No approval or release was recorded.")
            st.rerun()
        pending_setup = context.get("unresolved_execution_setup") or {}
        if pending_setup:
            st.info("Execution setup still needs " + ", ".join(pending_setup.values())
                + ". The assistant can draft the science now, but the complete draft cannot pass its checks until these are declared.")
            if st.button("Prepare execution setup", key=prefix + "execution_setup", disabled=active):
                return {"route": "source_delivery", "params": {"mode": "runtime"}}
        if st.button("Review build rules", key=prefix + "build_rules", disabled=not permitted or active):
            return {"route": "progress", "params": {"action_id": "g4_author"}}
        _workbook_policy_settings(root, pack, actor_id, permitted=permitted, local_demo=local_demo,
            can_write=can_write, allowed_packs=allowed_packs, prefix=prefix, active=active, current_context=context)
    provider = None
    try:
        if ai.selected_provider():
            provider = ai._provider(root)
    except (ValueError, OSError, ai.vscode.BridgeError):
        pass
    connected = bool(provider and provider.get("configured"))
    if connected:
        st.caption(f"Selected assistant: {provider['provider']} · {provider['model']}")
    else:
        st.info("Connect an assistant under Assistant connection to request a draft. Saved drafts remain available below.")
    if context.get("ok"):
        st.write(f"{context.get('row_count', 0)} extracted requirements will be accounted for, including existing definitions and open questions.")
    else:
        _show_errors(context, "Review the workbook's current source checks before drafting.")
    source_access_required = any(item.get("code") == "source_ai_access_required"
                                 for item in context.get("findings", []))
    if source_access_required:
        if context.get("source_access_details"):
            with st.expander("Source access check details"):
                st.text(context["source_access_details"])
        if st.button("Review extracted source access", key=prefix + "source_access"):
            return {"route": "extracted_source_review", "params": {}}
    elif not context.get("ok") or any(item.get("kind") == "source" for item in context.get("findings", [])):
        if st.button("Correct specification inputs", key=prefix + "source_inputs"):
            return {"route": "progress", "params": {"action_id": "g1_extract"}}
    st.caption("Run limit: up to 64 requirements, 32 model calls and 15 minutes. Technical repairs share this budget. The provider's published price estimate is capped at $2 when available; VS Code does not supply a price estimate.")

    def start(candidate_id=None, answers=None, *, deterministic_only=False):
        try:
            arguments = {"pack": pack, "expected_input_digest": context["input_digest"],
                "provider_id": None if deterministic_only else provider["provider_id"],
                "captured_model": None if deterministic_only else provider["model"],
                "local_demo": local_demo, "can_write": can_write,
                "candidate_id": candidate_id, "answers": answers or {}, "request_id": uuid.uuid4().hex}
            if deterministic_only:
                arguments["deterministic_only"] = True
            jobs.start(root, actor_id, action="workbook_draft", job_key=job_key,
                arguments=arguments,
                confirmed=True, can_write=permitted, allowed_packs=allowed_packs)
            st.rerun()
        except (ValueError, OSError) as error:
            _show_errors({"errors": form_help.validation_messages([str(error)])[0]}, "The draft could not start. Your current work is retained.")

    enabled = permitted and connected and context.get("ok") is True and not active
    if not permitted:
        st.caption("An editor with assistant access can start a workbook draft.")
    if active:
        st.caption("A workbook draft is running. You can keep reviewing variables while it finishes.")
    if st.button("Start a new workbook draft", key=prefix + "start", disabled=not enabled):
        start()

    @st.fragment(run_every=3 if active else None)
    def progress_panel():
        result = job_page.render(root, actor_id, action="workbook_draft", job_key=job_key,
            can_write=permitted, allowed_packs=allowed_packs, key=prefix + "job")
        if result:
            token = hashlib.sha256(json.dumps(result, sort_keys=True, default=str).encode()).hexdigest()
            if st.session_state.get(prefix + "last_result") != token:
                st.session_state[prefix + "last_result"] = token
                if result.get("candidate_id"):
                    st.session_state[prefix + "open_candidate"] = result["candidate_id"]
                st.rerun()
            for message in result.get("errors") or []:
                st.warning(str(message))
    progress_panel()

    entries = catalogue.get("candidates") or []
    labels = {entry["candidate_id"]: entry.get("label") or
        (str(entry.get("created_at") or entry["candidate_id"][:12]) + " · " +
         ("Ready for review" if entry.get("ready") else "Needs attention")) for entry in entries}
    if not labels:
        return
    requested = st.session_state.pop(prefix + "open_candidate", None)
    if requested in labels:
        st.session_state[prefix + "selected"] = requested
    if st.session_state.get(prefix + "selected") not in labels:
        st.session_state[prefix + "selected"] = next(iter(labels))
    candidate_id = st.selectbox("Saved workbook draft", list(labels), format_func=labels.get, key=prefix + "selected")
    loaded = proposals.load_workbook_candidate(root, pack, candidate_id=candidate_id,
        actor_id=actor_id, allowed_packs=allowed_packs)
    if not loaded.get("ok"):
        _show_errors(loaded, "This saved workbook draft is unavailable.")
        return
    candidate = loaded["candidate"]
    stale = bool(loaded.get("stale"))
    summary = next((version for version in reversed(candidate.get("versions") or [])
        if version.get("phase") == "run_summary"), {})
    budget_issue = ai.workbook_budget_issue(candidate, provider)
    if budget_issue:
        if stale:
            prior_limit = (summary.get("limits") or {}).get("request_bytes")
            recorded = f" Its recorded connection limit was {prior_limit:,} bytes." if type(prior_limit) is int else ""
            current_limit = ai._workbook_request_limit(provider["provider_id"], provider.get("instance")) if connected else None
            current = f" The selected connection now allows {current_limit:,} bytes." if current_limit is not None else ""
            recovery = (" In VS Code run Developer: Restart Extension Host, then RWD Portal: Connect Chat Model."
                if connected and provider["provider_id"] == "vscode" and current_limit < ai.WORKBOOK_REQUEST_BYTES
                and not budget_issue["retry_ready"] else "")
            st.warning("Previous drafting attempt: a complete request exceeded its model connection limit."
                + recorded + current + recovery
                + " The current request has not been measured again. Review the current inputs and connection before starting a new draft; this saved draft cannot be continued or applied.")
        else:
            (st.info if budget_issue["retry_ready"] else st.warning)(budget_issue["message"])
    budget_rows = budget_issue["item_ids"] if budget_issue else set()

    def connection_placeholder(item_id, question):
        return item_id in budget_rows and (question.get("question") if isinstance(question, dict) else question) == ai._WORKBOOK_UNFINISHED
    if stale:
        st.warning("The current inputs or drafting software differ from this saved draft. Check the saved choices against current inputs below, or start a new draft.")
        _workbook_revalidation(root, pack, actor_id, candidate_id, candidate, context, permitted=permitted,
            local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs, active=active, prefix=prefix)
    if candidate.get("ready") and not stale and not budget_issue:
        st.success("The contract and configuration passed their technical checks. Review the proposed science and changes below.")
    else:
        st.info("This draft is incomplete. Its missing requirements and questions remain visible; it cannot be applied yet.")
    rows = (candidate.get("proposal") or {}).get("records") or []
    variable_names = {row["item_id"]: row.get("variable_id") or row["item_id"]
        for row in (context.get("context") or {}).get("rows", [])}
    variable_names.update({row["item_id"]: row["values"]["variable_id"] for row in rows
        if (row.get("values") or {}).get("variable_id")})
    st.dataframe([{"Specification row": row.get("item_id"),
        "Variable": variable_names.get(row.get("item_id"), row.get("item_id", "Unresolved requirement")),
        "Proposed logic": (row.get("values") or {}).get("derivation", "Kept from existing record, or awaiting a choice"),
        "Open questions": sum(not connection_placeholder(row.get("item_id"), question)
            for question in row.get("questions") or [])} for row in rows], hide_index=True, width="stretch")
    findings = candidate.get("findings") or []
    if findings:
        with st.expander("Requirements and checks needing attention", expanded=not budget_issue):
            st.dataframe([{"Row": item.get("item_id", ""), "Check": item.get("code", ""),
                "Finding": item.get("message", ""), "Next step": "Technical repair" if item.get("repairable") else "Review the source or scientific choice"}
                if isinstance(item, dict) else {"Finding": str(item)} for item in findings], hide_index=True, width="stretch")
    pending = summary.get("pending_item_ids") or []
    if pending and not stale:
        st.caption(f"{len(pending)} requirements have not been drafted yet. Continuing keeps the completed rows and starts a new bounded request.")
        if st.button("Continue unfinished draft", key=prefix + "resume_" + candidate_id,
                     disabled=not enabled or bool(budget_issue and not budget_issue["retry_ready"])):
            start(candidate_id)
    questions = [question for question in candidate.get("questions") or []
                 if not connection_placeholder(question.get("item_id"), question)]
    correction_rows = ai._workbook_correction_ids({row["item_id"]: row for row in rows}, candidate,
        context=context.get("context") or {}, schema=context.get("write_schema") or {},
        input_digest=context.get("input_digest")) if not stale else set()
    if correction_rows and not pending and not stale:
        st.caption(f"{len(correction_rows)} AI-drafted requirements have corrections supported by the current source or compiler. Reviewed choices and your answers are preserved.")
        if st.button("Correct AI draft from source", key=prefix + "correct_ai_" + candidate_id,
                     disabled=not (permitted and context.get("ok") and not active)):
            start(candidate_id, deterministic_only=True)
    repairable_rows = ai._workbook_repairable_ids({row["item_id"]: row for row in rows}, candidate)
    if repairable_rows and not pending and not stale:
        st.caption("Retrying technical repairs keeps the saved scientific choices. Questions still need your answer.")
        if st.button("Retry technical repairs", key=prefix + "repair_" + candidate_id, disabled=not enabled):
            start(candidate_id)
    _workbook_private_corrections(root, pack, actor_id, candidate_id, candidate, context,
        permitted=permitted, local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs,
        active=active, stale=stale, prefix=prefix, variable_names=variable_names)
    if findings and not stale:
        affected = list(dict.fromkeys(item.get("item_id") for item in findings
            if isinstance(item, dict) and item.get("item_id")))
        if not affected:
            affected = [row["item_id"] for row in rows]
        if affected:
            with st.expander("Correct a variable yourself", expanded=not questions and not pending):
                st.caption("Open the variable editor to correct the product's definition. Saving changes the inputs, so a new workbook draft will need to use that correction.")
                correction = st.selectbox("Variable to correct", affected,
                    format_func=lambda item: variable_names.get(item, item), key=prefix + "correct_" + candidate_id)
                if st.button("Open variable editor", key=prefix + "edit_" + candidate_id):
                    return {"route": "variable_review", "params": {"phase": "science", "item_id": correction,
                        "close_workbook_draft": True}}
    answers, revision_rows = {}, {}
    if questions and not stale:
        _workbook_restore_failed_answers(root, pack, actor_id, candidate, context, questions, history,
            candidate_id=candidate_id, permitted=permitted, active=active, prefix=prefix, allowed_packs=allowed_packs)
        retained_answers = _workbook_retained_answers(candidate, context, questions)
        answer_revisions = _workbook_answer_revisions(candidate, context, questions)
        output_questions, scientific_questions = [], []
        for question in questions:
            fields = proposals._workbook_question_fields(question, variable_names.get(question.get("item_id"), ""))
            (output_questions if fields else scientific_questions).append(question)
        groups = []
        if scientific_questions:
            groups.append(("Answer open scientific questions", scientific_questions, True))
        if output_questions:
            st.caption(f"{len(output_questions)} questions concern output choices. Use Shared choices for this product above, or answer individual exceptions below.")
            groups.append(("Output choices for individual variables", output_questions, False))
        for title, grouped_questions, expanded in groups:
            with st.expander(title, expanded=expanded):
                for question in grouped_questions:
                    identifier = question["id"]
                    st.write(str(variable_names.get(question.get("item_id"), question.get("item_id", ""))) + " · " + question["question"])
                    if question.get("kind") in {"source", "source_correction", "source_qc"}:
                        st.caption("Correct this in the specification/source editor, then start a new workbook draft.")
                        continue
                    options = question.get("choices") or []
                    options = list(dict.fromkeys(value for value in options if isinstance(value, str)
                        and value not in {"Not decided", "Enter an answer"}))
                    answer_key = prefix + candidate_id + "_answer_" + identifier
                    text_key = prefix + candidate_id + "_text_" + identifier
                    retained_entry = retained_answers.get(identifier) or {}
                    retained = retained_entry.get("answer")
                    if retained is not None and answer_key not in st.session_state and text_key not in st.session_state:
                        st.session_state[answer_key] = retained if retained in options else "Enter an answer"
                        if retained not in options:
                            st.session_state[text_key] = retained
                    choice = st.selectbox("Your answer", ["Not decided", *options, "Enter an answer"],
                        key=answer_key)
                    if choice == "Enter an answer":
                        choice = st.text_area("Clarify this choice", max_chars=1000,
                            key=text_key).strip()
                    if retained is not None and choice == retained:
                        st.caption("Saved answer not yet incorporated into this draft. Review or edit it, then choose Continue with my answers to submit it again."
                            if retained_entry.get("pending") else
                            "Saved answer restored for review. You can edit it; nothing is submitted until you choose Continue with my answers.")
                    if choice and choice != "Not decided":
                        revision = answer_revisions.get(identifier)
                        if revision and revision["locked"]:
                            st.caption("This definition belongs to an existing or approved record. Use its variable editor and review process; this answer cannot unlock it.")
                        elif revision:
                            revision_rows[question["item_id"]] = {key: revision[key]
                                for key in ("protected_fields", "record")}
                            with st.expander("Allow changes to these fields", expanded=False):
                                st.caption("Earlier answers protect this definition. Choose the fields this answer may revise; all other protected fields stay unchanged. Inspect the current values under Review the exact contract and YAML changes.")
                                if revision["selected_fields"]:
                                    st.caption("Your previously selected fields are restored for review. Change them if needed; Continue submits the new scope.")
                                update_fields = st.multiselect("Fields the assistant may update for this answer",
                                    revision["options"], default=revision["selected_fields"], format_func=_workbook_update_field_label,
                                    key=prefix + candidate_id + "_update_fields_" + identifier + "_" + revision["binding"],
                                    disabled=not enabled)
                            if update_fields:
                                answers[identifier] = {"answer": choice, "update_fields": update_fields}
                            else:
                                st.caption("This answer is not included yet. Select the fields it may update; you can still continue with other answered questions.")
                        else:
                            answers[identifier] = choice
        if st.button("Continue with my answers", key=prefix + "continue_" + candidate_id,
                     disabled=not (enabled and answers)):
            start(candidate_id, answers)
    with st.expander("Review the exact contract and YAML changes"):
        if revision_rows:
            st.caption("Current protected definitions for the answers above. Selecting revision fields does not change these values or approve the draft.")
            st.json(revision_rows)
        for file in candidate.get("files") or []:
            st.caption(file["path"])
            st.code(file.get("diff") or "No change", language="diff")
    with st.expander("Draft checks and attempt history"):
        if candidate.get("compiler_translations"):
            st.caption("The compiler translated equivalent execution details below. Scientific choices and approvals are unchanged.")
        st.json({"coverage": candidate.get("coverage"), "compiler_translations": candidate.get("compiler_translations", []), "versions": [
            {key: version[key] for key in ("version", "phase", "item_ids", "calls", "findings", "pending_item_ids", "elapsed_seconds", "repairs")
             if key in version} for version in candidate.get("versions") or []]})
        st.caption("Download the draft below for complete retained proposals and request fingerprints.")
    review_key = prefix + "review_" + candidate["digest"]
    reviewed = st.checkbox("I reviewed this contract and configuration draft, including every proposed scientific choice.",
        key=review_key, disabled=not (permitted and candidate.get("ready") and not stale and not budget_issue))
    if st.button("Apply reviewed workbook draft", key=prefix + "apply_" + candidate_id,
        disabled=not (permitted and reviewed and candidate.get("ready") and not stale and not active and not budget_issue)):
        applied = proposals.adopt_workbook_candidate(root, pack, candidate_id=candidate_id, actor_id=actor_id,
            expected_digest=candidate["digest"], confirmed=True, local_demo=local_demo,
            can_write=can_write, allowed_packs=allowed_packs)
        if applied.get("ok"):
            st.session_state.setdefault("flow_result", {}).pop(pack, None)
            st.session_state["variable_review_refresh_table"] = True
            st.session_state["variable_review_notice"] = "The reviewed workbook draft was applied. Continue the existing scientific, source and release reviews."
            st.rerun()
        else:
            _show_errors(applied, "This draft could not be applied. Your existing product is retained.")
    if not candidate.get("ready"):
        with st.expander("Save selected rows as unfinished work"):
            st.caption("Keep completed new definitions while you finish product setup. This does not approve them or mark their implementation complete. Existing definitions stay in their row editor; unanswered rows remain in this saved candidate.")
            choices = {row["item_id"]: row["values"].get("variable_id", row["item_id"])
                for row in candidate.get("proposal", {}).get("records", [])
                if isinstance(row.get("values"), dict) and not row.get("questions")}
            selected = st.multiselect("New definitions to save unfinished", list(choices),
                format_func=lambda item: choices[item] + " · " + item,
                key=prefix + "unfinished_rows_" + candidate_id, disabled=stale or active or not permitted)
            draft_key = prefix + "unfinished_preview_" + candidate_id
            if st.button("Preview unfinished save", key=prefix + "unfinished_preview_button_" + candidate_id,
                         disabled=not (selected and permitted and not stale and not active and not budget_issue)):
                st.session_state[draft_key] = proposals.preview_unfinished_workbook_candidate(root, pack,
                    actor_id=actor_id, candidate_id=candidate_id, expected_digest=candidate["digest"],
                    selected_item_ids=selected, allowed_packs=allowed_packs)
            draft = st.session_state.get(draft_key)
            if draft and draft.get("candidate_digest") == candidate["digest"] and draft.get("selected_item_ids") == sorted(selected):
                st.caption(str(len(draft["selected_item_ids"])) + " selected; " + str(len(draft["skipped_item_ids"])) + " left in the saved candidate. All saved definitions remain unapproved, unverified and not implemented.")
                if draft.get("errors"):
                    _show_errors(draft, "These selected rows cannot be saved yet.")
                for file in draft.get("files", []):
                    st.caption(file["path"])
                    st.code(file.get("diff") or "No change", language="diff")
                if draft.get("remaining_findings"):
                    st.write("Still required before a build")
                    st.dataframe(draft["remaining_findings"], hide_index=True, use_container_width=True)
                confirmed = st.checkbox("I reviewed these changes and want to save them as unfinished work.",
                    key=prefix + "unfinished_confirm_" + draft["digest"],
                    disabled=not (draft.get("can_save") and permitted and not stale and not active))
                if st.button("Save unfinished workbook draft", key=prefix + "unfinished_save_" + candidate_id,
                             disabled=not (confirmed and draft.get("can_save") and permitted and not stale and not active)):
                    applied = proposals.save_unfinished_workbook_candidate(root, pack, actor_id=actor_id,
                        candidate_id=candidate_id, expected_digest=candidate["digest"], selected_item_ids=selected,
                        expected_preview_digest=draft["digest"], confirmed=True, local_demo=local_demo,
                        can_write=can_write, allowed_packs=allowed_packs)
                    if applied.get("ok"):
                        st.session_state.setdefault("flow_result", {}).pop(pack, None)
                        st.session_state["variable_review_refresh_table"] = True
                        st.session_state["variable_review_notice"] = applied.get("warning") or applied["notice"]
                        st.session_state.pop(draft_key, None)
                        st.rerun()
                    else:
                        _show_errors(applied, "The unfinished draft was not saved.")
            elif draft and not draft.get("ok"):
                _show_errors(draft, "These selected rows cannot be saved yet.")
    st.download_button("Download workbook draft and findings", json.dumps(candidate, indent=2, ensure_ascii=False),
        file_name="workbook_draft_" + candidate_id[:12] + ".json", mime="application/json", key=prefix + "download_" + candidate_id)


def selection_context(root, pack, actor_id, local_demo, can_write, allowed_packs):
    """The page and its guide identify the same explicitly opened proposal."""
    context = hashlib.sha256(json.dumps([str(root), pack, actor_id, local_demo, can_write,
                                        sorted(allowed_packs) if allowed_packs is not None else None]).encode()).hexdigest()
    return context, "configuration_proposal_" + context


def _restore_for_revision(pack, proposal, description, supported, guided, revision_metadata_key):
    """Copy a displayed snapshot into unsaved widgets, before this run renders them."""
    prefix = f"design_{pack}_"
    plan = proposal["brief"]
    st.session_state[prefix + "purpose"] = plan["purpose"]
    st.session_state[prefix + "studies"] = "\n".join(plan["studies"])
    st.session_state[prefix + "baseline"] = proposal["baseline_sha256"]
    st.session_state[prefix + "source"] = plan["source"]["proposed"]["vendor"]
    st.session_state[prefix + "modality"] = plan["source"]["proposed"]["modality"]
    st.session_state[prefix + "additions"] = plan["added"]
    st.session_state[prefix + "domains"] = sorted({row["domain"] for row in description["rows"]})
    st.session_state[prefix + "excluded"] = list(plan["removed"])
    settings = {change["ref"]: change["value"] for change in proposal["configuration_changes"] if change["ref"] in supported}
    st.session_state[prefix + "proposal_selected_settings"] = list(settings)
    cohort_changes = {c["ref"].split("#/", 1)[1]: c["value"]
                      for c in proposal["configuration_changes"] if c["ref"] in proposals.COHORT_REFS}
    st.session_state[prefix + "proposal_cohort_restore"] = {
        "baseline": proposal["baseline_sha256"], "values": cohort_changes}
    for ref, (_label, kind, value) in supported.items():
        field = hashlib.sha256(ref.encode()).hexdigest()[:12]
        st.session_state[prefix + "proposal_" + field + "_change"] = ref in settings
        st.session_state[prefix + "proposal_" + field + "_value"] = _widget_value(settings.get(ref, value), kind)
    exclusions = {row["study"]: row["variables"] for row in proposal["study_exclusions"]}
    for study in plan["studies"]:
        field = hashlib.sha256(study.encode()).hexdigest()[:12]
        st.session_state[prefix + "proposal_study_" + field] = exclusions.get(study, [])
    if guided:
        st.session_state["plan_guide_baseline"] = proposal["baseline_sha256"]
        if plan["removed"] or plan["added"] or plan["source_changed"]:
            st.session_state["plan_guide_intent"] = "revision"
    # These inputs belong to a new proposal, not a saved definition revision.
    st.session_state.pop(revision_metadata_key, None)
    st.session_state.pop(revision_metadata_key.replace("revision_saved_", "configuration_import_", 1), None)


def _value(text, kind):
    """Only explicitly entered structured values become configuration changes."""
    if kind == "lot_numbering":
        if text not in proposals.LOT_NUMBERING_CHOICES:
            raise ValueError("Choose a treatment line numbering rule.")
        return text
    if kind in {"integer", "int", "positive_integer"}:
        return int(text)
    if kind in {"number", "float"}:
        value = float(text)
        if not math.isfinite(value):
            raise ValueError("Enter a finite number.")
        return value
    return text.strip()


def _widget_value(value, kind):
    if kind == "positive_integer":
        if type(value) is int:
            return value if value >= 1 else None
        if isinstance(value, str) and value.isdecimal() and int(value) >= 1:
            return int(value)
        return None
    if kind == "lot_numbering":
        return value if value in proposals.LOT_NUMBERING_CHOICES else None
    return str(value)


def _parameter_field(parameter, *, value_key, selected, binding):
    kind = parameter["kind"]
    st.session_state[value_key] = _widget_value(st.session_state.get(value_key, parameter["value"]), kind)
    common = {"key": value_key, "disabled": not selected, "binding": binding}
    if kind == "lot_numbering":
        labels = {"linenumber": "Delivered line number (linenumber)",
                  "new_lot_n": "Chronological numbering after filters (new_lot_n)"}
        value = form_help.field(st.selectbox, parameter["label"], list(proposals.LOT_NUMBERING_CHOICES),
            index=None, format_func=labels.get, **common)
        st.caption("One numbering rule applies to the whole product, including treatment-line cohorts. If omitted, the engine uses new_lot_n.")
        return value
    if kind == "positive_integer":
        value = form_help.field(st.number_input, parameter["label"], min_value=1, step=1, value=None, **common)
        st.caption("The engine prepares its standard treatment fields for every line from 1 through this number.")
        return value
    return form_help.field(st.text_input, parameter["label"], **common)


def _show_errors(result, fallback):
    for error in result.get("errors") or [fallback]:
        st.error(str(error))


def _eligibility_leaves(rule):
    rows = []
    def walk(value, path):
        if value is None:
            return
        for group in ("all", "any"):
            if group in value:
                for index, child in enumerate(value[group]):
                    walk(child, (*path, group, index))
                return
        rows.append((path, value))
    for section in ("include", "exclude"):
        walk(rule.get(section), (section,))
    return rows


def _eligibility_comparison(operator):
    return {"eq": "Equals", "ne": "Does not equal", "in": "Is one of", "not_in": "Is not one of",
            "is_missing": "Is missing", "is_present": "Is present", "ge": "At least", "gt": "Greater than",
            "le": "At most", "lt": "Less than", "between": "Between (inclusive)"}.get(operator, operator)


def _eligibility_value(kind, choices, current, key):
    """Typed values, with explicit custom entry when declared codes are absent."""
    if kind == "boolean":
        return st.selectbox("Value", [True, False], index=([True, False].index(current) if type(current) is bool else None),
                            format_func=lambda value: "Yes" if value else "No", key=key)
    if kind == "date":
        existing = date.fromisoformat(current) if isinstance(current, str) and current else None
        value = st.date_input("Date", value=existing, min_value=date(1900, 1, 1), max_value=date(2200, 12, 31), key=key)
        return value.isoformat() if value else None
    if kind in {"integer", "number"}:
        value = int(current) if kind == "integer" and current is not None else float(current) if current is not None else None
        return st.number_input("Value", value=value, step=1 if kind == "integer" else 1.0, key=key)
    if choices:
        options = list(dict.fromkeys(str(value) for value in choices))
        selected = st.selectbox("Value", [*options, None], index=options.index(current) if current in options else len(options),
                                format_func=lambda value: "Enter another value" if value is None else value, key=key + "_choice")
        if selected is not None:
            return selected
    value = st.text_input("Exact value", value=current if isinstance(current, str) else "", key=key)
    if value:
        return value
    blank = st.checkbox("Match an empty text value", value=current == "", key=key + "_empty")
    return "" if blank else None


def _reset_eligibility_condition(key, pending=None):
    if pending is not None:
        pending.clear()
    for name in list(st.session_state):
        if name == key + "_selected" or name.startswith((key + "_field_", key + "_edit_", key + "_section_")):
            st.session_state.pop(name, None)


def _eligibility_editor(row, fields, *, key, pending_state):
    from engine.sql_expressions import eligibility_errors
    # Only draft field choices survive navigation. Buttons and review actions
    # are never restored or replayed by this continuation.
    for suffix, value in pending_state.get("widgets", {}).items():
        if suffix == "_selected" or suffix.startswith(("_field_", "_edit_", "_section_")):
            st.session_state.setdefault(key + suffix, value)
    with st.expander("Patient inclusion and exclusion"):
        rule = row.get("eligibility")
        if rule is None:
            st.caption("This cohort currently uses its index-event rules only.")
            if st.button("Add patient eligibility rules", key=key + "_add"):
                row["eligibility"] = {"version": 1, "include": None, "exclude": None, "missing": None}
                st.rerun()
            return []
        st.caption("These rules filter patients using values calculated for this cohort's index date. "
                   "Review each variable's timing and definition before selecting it.")
        st.caption("Only declared outputs supported by the current configuration are offered. "
                   "For a missing variable, finish its definition and executable configuration first.")
        policies = {"exclude": "Exclude the patient", "include": "Include the patient", "error": "Stop the build for review"}
        rule["missing"] = st.selectbox("If missing values leave eligibility undecided", list(policies),
            index=list(policies).index(rule["missing"]) if rule.get("missing") in policies else None,
            format_func=policies.get, key=key + "_missing")
        modes = {}
        for section, default in (("include", "all"), ("exclude", "any")):
            node = rule.get(section)
            mode = next((name for name in ("all", "any") if isinstance(node, dict) and name in node), default)
            modes[section] = st.selectbox("Include when" if section == "include" else "Exclude when", ["all", "any"],
                index=["all", "any"].index(mode), format_func=lambda value: "All conditions match" if value == "all" else "Any condition matches", key=key + "_" + section + "_mode")
            if node is not None and modes[section] != mode:
                rule[section] = {modes[section]: node[mode] if mode in node else [node]}
        leaves = _eligibility_leaves(rule)
        summary = st.container()
        labels = {str(index): f"{path[0].title()} · {item['field']} · {_eligibility_comparison(item['operator'])}" for index, (path, item) in enumerate(leaves)}
        if st.session_state.get(key + "_selected", "new") not in {"new", *labels}:
            _reset_eligibility_condition(key, pending_state)
        selected = st.selectbox("Condition to edit", ["new", *labels],
            format_func=lambda value: "Add a condition" if value == "new" else labels[value], key=key + "_selected",
            disabled=bool(pending_state.get("unfinished")))
        path, current = (None, {}) if selected == "new" else leaves[int(selected)]
        section = st.selectbox("Use this condition to", ["include", "exclude"],
            index=0 if path is None or path[0] == "include" else 1,
            format_func=lambda value: "Include patients" if value == "include" else "Exclude patients", key=key + "_section_" + selected,
            disabled=path is not None)
        field_key = key + "_field_" + selected
        names = list(fields)
        if current.get("field") and current["field"] not in names:
            names.append(current["field"])
        field = st.selectbox("Variable", names, index=names.index(current["field"]) if current.get("field") in names else None,
            format_func=lambda value: value + " · " + fields[value]["label"] if value in fields else value + " (definition unavailable; replace)", key=field_key)
        candidate, failures = None, []
        if field in fields:
            kind = fields[field]["type"]
            if field != current.get("field") or kind != current.get("type"):
                current = {}
            st.caption("Declared type: " + kind)
            operators = ["eq", "ne", "in", "not_in", "is_missing", "is_present"]
            if kind in {"integer", "number", "date"}:
                operators += ["ge", "gt", "le", "lt", "between"]
            op_labels = {operator: _eligibility_comparison(operator) for operator in operators}
            edit_key = key + "_edit_" + selected + "_" + field
            op = st.selectbox("Comparison", list(op_labels), index=list(op_labels).index(current["operator"]) if current.get("operator") in op_labels else None,
                              format_func=op_labels.get, key=edit_key + "_op")
            if op:
                candidate = {"field": field, "type": kind, "operator": op}
                value_key = edit_key + "_" + op
                if op == "between":
                    values = current.get("values") if current.get("operator") == op else [None, None]
                    left, right = st.columns(2)
                    with left:
                        st.caption("From, inclusive")
                        lower = _eligibility_value(kind, [], values[0], value_key + "_lo")
                    with right:
                        st.caption("Through, inclusive")
                        upper = _eligibility_value(kind, [], values[1], value_key + "_hi")
                    candidate["values"] = [lower, upper]
                elif op in {"in", "not_in"}:
                    options = fields[field].get("values") or []
                    previous = current.get("values", []) if current.get("operator") == op else []
                    chosen = st.multiselect("Declared values", list(dict.fromkeys([*options, *previous])), default=previous, key=value_key + "_codes")
                    custom = st.text_area("Additional values, one per line", key=value_key + "_custom")
                    try:
                        values = [int(value) if kind == "integer" else float(value) if kind == "number" else
                                  {"true": True, "false": False}[value.lower()] if kind == "boolean" else value
                                  for value in custom.splitlines() if value.strip()]
                        candidate["values"] = [*chosen, *values]
                    except (ValueError, KeyError):
                        failures.append("Each additional value must match the variable's declared type.")
                elif op not in {"is_missing", "is_present"}:
                    candidate["value"] = _eligibility_value(kind, fields[field].get("values", []), current.get("value"), value_key)
                failures += eligibility_errors({"version": 1, "include": candidate, "exclude": None, "missing": "exclude"})
        elif field:
            failures.append("Select a currently declared variable before saving this condition.")
        for failure in failures:
            st.info(failure)
        if st.button("Add condition" if path is None else "Update condition", key=key + "_save_" + selected,
                     disabled=candidate is None or bool(failures)):
            if path is None:
                node = rule.get(section)
                if node is None:
                    rule[section] = {modes[section]: [candidate]}
                elif modes[section] in node:
                    node[modes[section]].append(candidate)
                else:
                    rule[section] = {modes[section]: [node, candidate]}
            else:
                target = rule
                for component in path[:-1]:
                    target = target[component]
                target[path[-1]] = candidate
            _reset_eligibility_condition(key, pending_state)
            st.rerun()
        original = {} if path is None else leaves[int(selected)][1]
        pending = bool(field) if path is None else candidate != original
        if pending:
            st.info("Add or update this condition before staging the proposal, or clear this condition's unsaved edits.")
        pending_state["unfinished"] = pending
        pending_state["widgets"] = {name[len(key):]: deepcopy(st.session_state[name]) for name in st.session_state
            if name == key + "_selected" or name.startswith((key + "_field_", key + "_edit_", key + "_section_"))}
        st.button("Clear condition edits", key=key + "_clear", on_click=_reset_eligibility_condition, args=(key, pending_state))
        if path is not None and st.button("Remove condition", key=key + "_remove_" + selected):
            target = rule
            for component in path[:-1]:
                target = target[component]
            if isinstance(target, list):
                target.pop(path[-1])
            else:
                target[path[-1]] = None
            def clean(node):
                if node is None:
                    return None
                for mode in ("all", "any"):
                    if mode in node:
                        children = [value for child in node[mode] if (value := clean(child)) is not None]
                        return {mode: children} if children else None
                return node
            for name in ("include", "exclude"):
                rule[name] = clean(rule[name])
            st.session_state.pop(key + "_selected", None)
            _reset_eligibility_condition(key, pending_state)
            st.rerun()
        with st.expander("Group conditions"):
            side = st.selectbox("Rule list", ["include", "exclude"], key=key + "_group_side")
            node = rule.get(side) or {}
            mode = next((name for name in ("all", "any") if name in node), None)
            children = node.get(mode, [])
            group_key = key + "_group_indexes"
            if group_key in st.session_state:
                st.session_state[group_key] = [index for index in st.session_state[group_key] if 0 <= index < len(children)]
            indexes = st.multiselect("Conditions to group", list(range(len(children))),
                format_func=lambda value: f"{value + 1}: " + children[value].get("field", "condition group"), key=group_key)
            match = st.selectbox("Within this group require", ["all", "any"], key=key + "_group_match")
            if st.button("Group selected conditions", key=key + "_group", disabled=len(indexes) < 2 or pending):
                first = min(indexes)
                combined = {match: [children[index] for index in sorted(indexes)]}
                rule[side] = {mode: [combined if index == first else child for index, child in enumerate(children) if index == first or index not in indexes]}
                st.session_state.pop(key + "_group_indexes", None)
                _reset_eligibility_condition(key, pending_state)
                st.rerun()
        with summary:
            st.dataframe([{"Use": path[0].title(), "Variable": item["field"], "Comparison": _eligibility_comparison(item["operator"]),
                           "Value": str(item.get("value", item.get("values", ""))),
                           "Group path": " / ".join(str(value) for value in path[1:])}
                          for path, item in _eligibility_leaves(rule)], hide_index=True, width="stretch")
        if st.button("Remove all eligibility rules", key=key + "_remove_all"):
            row.pop("eligibility", None)
            _reset_eligibility_condition(key, pending_state)
            for suffix in ("_missing", "_include_mode", "_exclude_mode", "_group_side", "_group_indexes", "_group_match"):
                st.session_state.pop(key + suffix, None)
            st.rerun()
        return ["Finish or clear the unsaved eligibility condition before staging."] if pending else []


def _cohort_fields(data, *, key):
    """Edit existing native cohort anchors; preserve identities and hidden settings."""
    state_key = key + "_draft"
    if state_key not in st.session_state:
        st.session_state[state_key] = {name: deepcopy(data[name]) for name in ("cohorts", "index_dates")}
    draft = st.session_state[state_key]
    cohorts, models = draft["cohorts"], draft["index_dates"]
    summary = st.container()
    labels = {c["id"]: c["label"] for c in cohorts}
    selected = st.selectbox("Cohort to edit", list(labels), format_func=labels.get, key=key + "_selected")
    row = next(c for c in cohorts if c["id"] == selected)
    widget = key + "_" + selected
    line_keys = ("lot_number", "diag", "maintenance", "ecog_line_match")
    line_choices = draft.setdefault("_line_choices", {})
    if row["index"] == "lot_start_date":
        line_choices[selected] = {name: deepcopy(row[name]) for name in line_keys if name in row}
    anchors = list(models) + (["lot_start_date"] if data["has_lot"] else [])
    event = st.selectbox("Index event", anchors, index=anchors.index(row["index"]),
                         format_func=lambda value: "Treatment line start" if value == "lot_start_date" else value.replace("_", " "),
                         key=widget + "_anchor")
    previous_event = row["index"]
    row["index"] = event
    if event == "lot_start_date":
        if previous_event != event:
            for name, value in line_choices.get(selected, {}).items():
                row[name] = deepcopy(value)
        row["lot_number"] = st.number_input("Treatment line", min_value=1, step=1,
                                            value=row.get("lot_number", 1), key=widget + "_line")
        diagnosis = row.get("diag", "advanced_diagnosis_date")
        selected_diagnosis = st.selectbox("Required diagnosis date", list(models),
                                    index=list(models).index(diagnosis) if diagnosis in models else None,
                                    format_func=lambda value: value.replace("_", " "), key=widget + "_diag")
        if "diag" in row or selected_diagnosis != "advanced_diagnosis_date":
            row["diag"] = selected_diagnosis
        policies = {"All lines": None, "Maintenance only": True, "Exclude maintenance": False}
        policy = next(label for label, value in policies.items() if value is row.get("maintenance"))
        chosen = st.selectbox("Maintenance", list(policies), index=list(policies).index(policy), key=widget + "_maintenance")
        if policies[chosen] is None:
            row.pop("maintenance", None)
        else:
            row["maintenance"] = policies[chosen]
        model = selected_diagnosis
        line_choices[selected] = {name: deepcopy(row[name]) for name in line_keys if name in row}
    else:
        row.pop("lot_number", None)
        if previous_event == "lot_start_date":
            row.pop("diag", None)
            row.pop("maintenance", None)
        if row.get("ecog_line_match"):
            if st.checkbox("Use ECOG relative to this new index date", key=widget + "_ecog_rematch"):
                row.pop("ecog_line_match", None)
            else:
                st.info("This cohort currently ties ECOG to a treatment line. Confirm its new index-date matching before staging.")
        model = event
    general = data.get("condition_class") == "non_oncology"
    if not general:
        settings = list(dict.fromkeys(["", *data["line_settings"], row.get("line_setting", "")]))
        setting = st.selectbox("Treatment setting", settings,
                               index=settings.index(row.get("line_setting", "")),
                               format_func=lambda value: value or "Use product setting", key=widget + "_setting")
        if setting:
            row["line_setting"] = setting
        else:
            row.pop("line_setting", None)
    if model in models:
        rule = models[model]
        obsolete = [column for column in rule["of"] if column not in data["index_columns"]]
        options = list(dict.fromkeys([*data["index_columns"], *obsolete]))
        rule["of"] = st.multiselect("Date columns for this index rule", options,
                                     default=rule["of"], key=key + "_model_" + model,
                                     format_func=lambda value: value + " (no longer declared; replace)" if value not in data["index_columns"] else value)
        if any(column not in data["index_columns"] for column in rule["of"]):
            st.warning("Replace the no-longer-declared date columns before staging, or reset to the current saved cohort settings.")
        st.caption("Index date uses the latest non-missing date across these columns in each source row. "
                   "One selected column uses that column. This shared rule also affects other cohorts that select it.")
    st.caption(f"Configured index source: {data['index_source']}. Columns are declared configuration inputs; source review still applies.")
    with summary:
        st.dataframe([{"Cohort": c["label"], "Index event": c["index"],
                       **({} if general else {"Treatment line": str(c.get("lot_number", "—"))})}
                      for c in cohorts], hide_index=True, width="stretch")
    st.caption("Current saved enrollment window. Proposed date changes below appear in the staged review diff.")
    st.table([{"When": "Enrollment starts", "Date": str(data["start"])},
              {"When": "Index event must occur on or between these dates", "Date": "↓"},
              {"When": "Enrollment ends", "Date": str(data["end"])}])
    st.write("Include patients with a parseable index date inside this inclusive enrollment window.")
    if event == "lot_start_date":
        st.write("For a treatment-line cohort, both the line start and the selected diagnosis date must be in the window.")
    st.caption("Enrollment dates can be changed under Shared-product settings. Other eligibility criteria need a supported rule; "
               "the patient eligibility editor below filters calculated variables. Distinct patient index dates remain distinct episodes.")
    pending = draft.setdefault("_pending_eligibility", {})
    _eligibility_editor(row, data.get("eligibility_fields", {}), key=widget + "_eligibility",
                        pending_state=pending.setdefault(selected, {}))
    draft["_eligibility_issues"] = [f"Finish or clear the unsaved eligibility condition in {labels[cid]} before staging."
        for cid, state in pending.items() if state.get("unfinished") and cid in labels]
    return deepcopy(cohorts), deepcopy(models)


def _reset_cohort_widgets(key):
    for field in list(st.session_state):
        if field.startswith(key + "_") and field != key + "_enabled":
            st.session_state.pop(field, None)


def _cohort_editor(root, pack, expected_baseline, context, *, enabled):
    """The existing proposal/review path owns persistence and activation."""
    with st.expander("Cohort and index event"):
        key = f"design_{pack}_proposal_cohort_" + context + "_" + expected_baseline
        restore_key = f"design_{pack}_proposal_cohort_restore"
        restore = st.session_state.get(restore_key) or {}
        restore_values = None
        if restore and restore.get("baseline") == expected_baseline:
            restore_values = deepcopy(restore.get("values") or {})
            for old_key in list(st.session_state):
                if old_key.startswith(key + "_"):
                    st.session_state.pop(old_key, None)
            st.session_state[key + "_enabled"] = bool(restore_values)
            st.session_state.pop(restore_key, None)
        if not st.checkbox("Change a cohort or index rule",
                           key=key + "_enabled", disabled=not enabled):
            return [], []
        st.button("Reset to saved cohort settings", key=key + "_reset", disabled=not enabled,
                  on_click=_reset_cohort_widgets, args=(key,),
                  help="Discard these unsaved cohort/index choices and reload this product's current saved configuration.")
        try:
            data = proposals.cohort_editor(root, pack)
            if restore_values is not None:
                data.update(restore_values)
            cohorts, models = _cohort_fields(data, key=key)
            changes = proposals.cohort_changes(root, pack, cohorts, models)
            return changes, list(st.session_state[key + "_draft"].get("_eligibility_issues") or [])
        except (OSError, ValueError, TypeError, KeyError) as exc:
            st.info(f"Cohort settings need attention: {exc}")
            return [], [str(exc)]


def _reopen_variable_review(root, pack, actor_id, *, allowed_packs, key):
    if st.button("Review current variable table", key=key):
        from experiments.portal import variable_review_workflow
        from experiments.portal import connected_workflow_page as navigation
        report = variable_review_workflow.describe(root, pack, actor_id, allowed_packs=allowed_packs)
        phase = report.get("current_phase", "science")
        if phase == "complete":
            phase = "output"
        if phase not in {"science", "source", "output"}:
            phase = "science"
        navigation.open_route("variable_review", pack, actor_id, params={"phase": phase, "action": "review"})


def _reviewed_definitions(proposal, context):
    records = proposal.get("variable_review_records")
    if not records:
        return
    prefix = "configuration_records_" + context + "_" + proposal["proposal_id"]
    panel = st.expander("Reviewed definitions behind this proposal", key=prefix, on_change="rerun")
    if not panel.open:
        return
    with panel:
        st.caption("These are the definitions saved with this proposal. They preserve the requested work for engineering and do not confer approval.")
        st.dataframe([{"Variable": row["variable_id"], "Reviewed logic": row["values"].get("derivation", ""),
            "Physical column": row["values"].get("output", {}).get("physical_name", ""),
            "Published name": row["values"].get("output", {}).get("target_published_name", "")}
            for row in records], hide_index=True, width="stretch")
        labels = {row["item_id"]: row["variable_id"] + " · " + row["item_id"] for row in records}
        selected = st.selectbox("Reviewed variable details", list(labels), format_func=labels.get, key=prefix + "_row")
        row = next(row for row in records if row["item_id"] == selected)
        st.write(row["definition"])
        st.json({"Specification values": row["spec_values"], "Source mapping": row["values"].get("source", {}),
                 "Family choices": row["family"], "Master definition": row["master_name"],
                 "Reviewed fields": row["values"]})


def _shared_key(root, pack, actor_id, local_demo, can_write, allowed_packs, suffix):
    context, _ = selection_context(root, pack, actor_id, local_demo, can_write, allowed_packs)
    return "configuration_branch_" + context + "_" + suffix


def render_shared(root, pack, actor_id, *, local_demo, can_write, allowed_packs, key):
    """The same read-only handoff and explicit canonical restage on both pages."""
    prefix = _shared_key(root, pack, actor_id, local_demo, can_write, allowed_packs, key)
    panel = st.expander("Proposal handoffs saved in this branch", key=prefix + "_open", on_change="rerun")
    if not panel.open:
        return
    with panel:
        listing = proposals.list_shared(root, pack, actor_id=actor_id, allowed_packs=allowed_packs,
            page=st.session_state.get(prefix + "_page", 0))
        for error in listing.get("errors", []):
            st.warning(error)
        page = listing.get("page", 0)
        st.caption(f"Page {page + 1} · {listing.get('total', 0)} branch handoffs. Each opened handoff is checked against the current product.")
        prev, following = st.columns(2)
        if prev.button("Previous handoffs", key=prefix + "_previous", disabled=page == 0):
            st.session_state[prefix + "_page"] = page - 1
            st.rerun()
        if following.button("More handoffs", key=prefix + "_next", disabled=not listing.get("has_next")):
            st.session_state[prefix + "_page"] = page + 1
            st.rerun()
        rows = listing.get("records") or []
        if not rows:
            st.info("No readable handoffs on this page.")
            return
        labels = {row["packet_id"]: (row["purpose"] or "Configuration proposal") + " · " + row["packet_id"][:8] for row in rows}
        if st.session_state.get(prefix + "_selected") not in labels:
            st.session_state[prefix + "_selected"] = next(iter(labels))
        selected = st.selectbox("Branch proposal handoff", list(labels), format_func=labels.get, key=prefix + "_selected")
        loaded = proposals.load_shared(root, pack, packet_id=selected, actor_id=actor_id, allowed_packs=allowed_packs)
        if not loaded.get("ok"):
            _show_errors(loaded, "The branch handoff could not be opened.")
            return
        _shared_packet(root, pack, actor_id, loaded, local_demo=local_demo, can_write=can_write,
                       allowed_packs=allowed_packs, prefix=prefix)


def _shared_packet(root, pack, actor_id, loaded, *, local_demo, can_write, allowed_packs, prefix):
    packet, proposal = loaded["packet"], loaded["packet"]["proposal"]
    st.info(proposals.SHARED_NOTICE)
    st.write(proposal["purpose"])
    if loaded.get("line_endings_changed"):
        st.caption("Git changed text line endings only. The diff below is the original handoff; restaging binds this checkout's exact current bytes and requires fresh checks.")
    for entry in proposal["files"]:
        st.caption(entry["path"])
        st.code(entry["diff"], language="diff")
    _impact(proposal["impact"])
    st.write("**Study-only exclusions preserved in this handoff**")
    if proposal["study_exclusions"]:
        st.table(proposal["study_exclusions"])
    else:
        st.caption("None recorded.")
    st.write("**Engineering work still required**")
    if proposal["engineering_handoff"]:
        st.json(proposal["engineering_handoff"])
    else:
        st.caption("No unsupported changes requested in this snapshot.")
    with st.expander("Historical validator results — fresh checks are required here"):
        st.json(packet["validation"] or {"status": "not_run"})
    with st.expander("Exact branch handoff record"):
        st.caption(f"Proposal {proposal['proposal_id']} · handoff {packet['packet_id']} · digest {packet['digest']}")
        st.code(json.dumps(packet, indent=2, ensure_ascii=False), language="json")
    current_key = prefix + "_" + loaded["digest"]
    if loaded["stale"]:
        st.warning("The product baseline changed. Review the conflicts below and continue in a fresh editable plan.")
        if any(c["ref"] in proposals.CODELIST_REFS for c in proposal["configuration_changes"]):
            st.caption("Reopen the treatment editor to retain the code-list conditions in a fresh proposal.")
            if st.button("Revise treatment code list", key=current_key + "_codes", disabled=not (local_demo and can_write)):
                from experiments.portal import connected_workflow_page as navigation
                navigation.open_route("treatment_codelists", pack, actor_id, params={"packet_id": packet["packet_id"]})
            return
        revision = proposals.shared_revision_preview(root, pack, packet_id=packet["packet_id"], actor_id=actor_id, allowed_packs=allowed_packs)
        if not revision.get("ok"):
            _show_errors(revision, "The current revision could not be prepared.")
            return
        st.write("**Current product compared with the requested intent**")
        if revision["settings"]:
            st.dataframe(revision["settings"], hide_index=True, width="stretch")
        if revision["conflicts"]:
            st.table(revision["conflicts"])
        else:
            st.caption("No removed definitions or selected-setting conflicts detected. Review the updated product context before continuing.")
        for entry in revision["files"]:
            st.code(entry["diff"], language="diff")
        _impact(revision["impact"])
        for error in revision["errors"]:
            st.warning(error)
        st.info(revision["notice"])
        confirmed = st.checkbox("I reviewed these conflicts and want to copy this intent into an unfinished revision.", key=current_key + "_" + revision["digest"] + "_revise_confirm")
        if st.button("Continue this intent in the current product", key=current_key + "_revise", disabled=not (confirmed and local_demo and can_write)):
            fresh = proposals.shared_revision_preview(root, pack, packet_id=packet["packet_id"], actor_id=actor_id, allowed_packs=allowed_packs)
            if not fresh.get("ok") or fresh["digest"] != revision["digest"]:
                st.error("The handoff or current product changed. Review the current conflicts again.")
                return
            context, selection_key = selection_context(root, pack, actor_id, local_demo, can_write, allowed_packs)
            _restore_for_revision(pack, fresh["restore"], proposals.dw.describe(root, pack), proposals.supported_parameters(root, pack), True, "revision_saved_" + context)
            st.session_state.pop(selection_key, None)
            st.session_state["configuration_import_" + context] = {"unsupported_changes": fresh["unsupported_changes"], "notice": fresh["notice"], "conflicts": fresh["conflicts"]}
            from experiments.portal import connected_workflow_page as navigation
            navigation.open_route("plan_changes", pack, actor_id, params={"intent": "revision"})
        return
    confirmed = st.checkbox("I reviewed this handoff and want a new local proposal. Its previous checks and reviews are not carried forward.", key=current_key + "_confirm")
    if st.button("Restage this handoff here", key=current_key + "_restage", disabled=not (local_demo and can_write and confirmed)):
        result = proposals.restage_shared(root, pack, packet_id=packet["packet_id"], actor_id=actor_id,
            expected_digest=loaded["digest"], expected_baseline=loaded["baseline_sha256"], confirmed=confirmed,
            local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
        if result.get("ok"):
            from experiments.portal import connected_workflow_page as navigation
            navigation.open_route("plan_changes", pack, actor_id, params={"proposal_id": result["proposal_id"]})
        else:
            _show_errors(result, "The handoff could not be restaged.")


def render_engineering_request(root, pack, handoff_id, actor_id, *, local_demo, can_write, allowed_packs):
    prefix = _shared_key(root, pack, actor_id, local_demo, can_write, allowed_packs, handoff_id)
    panel = st.expander("Exact proposal for this engineering request", key=prefix + "_details_open", on_change="rerun")
    if not panel.open:
        return
    with panel:
        loaded = proposals.load_engineering_request(root, pack, handoff_id, actor_id=actor_id, allowed_packs=allowed_packs)
        if not loaded.get("ok"):
            _show_errors(loaded, "The exact proposal could not be opened.")
            return
        _shared_packet(root, pack, actor_id, loaded, local_demo=local_demo, can_write=can_write,
            allowed_packs=allowed_packs, prefix=prefix)


def _request_engineering(root, pack, proposal_id, actor_id, *, local_demo, can_write, allowed_packs):
    preview = proposals.share_preview(root, pack, proposal_id=proposal_id, actor_id=actor_id, allowed_packs=allowed_packs)
    if not preview.get("ok"):
        _show_errors(preview, "Reopen a current proposal before handing it to Engineering.")
        return
    prefix = _shared_key(root, pack, actor_id, local_demo, can_write, allowed_packs, "engineering_" + preview["digest"])
    with st.expander("Hand this exact proposal to Engineering"):
        st.caption("The engineer receives the full reviewed diff, source request, study exclusions and packet identity. Its shared packet can travel in your Git branch; unfinished drafts and reviewer decisions remain private.")
        with st.expander("Exact engineering handoff record"):
            st.code(json.dumps(preview["packet"], indent=2, ensure_ascii=False), language="json")
        note = form_help.field(st.text_area, "What should the engineer resolve?", key=prefix + "_note", binding=(pack, proposal_id, preview["digest"]))
        confirmed = st.checkbox("I reviewed this exact proposal and confirm its contents may be shared with Engineering in my branch.", key=prefix + "_confirm")
        if st.button("Hand this reviewed proposal to Engineering", key=prefix + "_send", disabled=not (local_demo and can_write and confirmed and note.strip())):
            result = proposals.request_engineering(root, pack, proposal_id=proposal_id, actor_id=actor_id,
                expected_digest=preview["digest"], note=note, confirmed=confirmed, local_demo=local_demo,
                can_write=can_write, allowed_packs=allowed_packs)
            if result.get("ok"):
                st.success("Handed to Engineering with the exact proposal. Open Handoffs and requests to follow its response; Save work to my branch shares the reviewed packet.")
            else:
                _show_errors(result, "The engineering request could not be saved.")


def _share_current(root, pack, proposal_id, actor_id, *, local_demo, can_write, allowed_packs):
    with st.expander("Save a reviewed proposal handoff to my branch"):
        st.caption("This copies only the selected proposal, its declared impact and historical checks into a reviewable handoff file. Private drafts and reviewer decisions stay private.")
        preview = proposals.share_preview(root, pack, proposal_id=proposal_id, actor_id=actor_id, allowed_packs=allowed_packs)
        if not preview.get("ok"):
            _show_errors(preview, "A current proposal is required before preparing a branch handoff.")
            return
        st.info(proposals.SHARED_NOTICE)
        packet, proposal = preview["packet"], preview["packet"]["proposal"]
        st.write(proposal["purpose"])
        st.caption("Configuration files: " + (", ".join(entry["path"] for entry in proposal["files"]) or "none")
                   + f". Study exclusions: {len(proposal['study_exclusions'])}. Engineering items: {len(proposal['engineering_handoff'])}.")
        check = packet["validation"] or {}
        st.caption("Historical proposal checks: " + ("review-submission requirements met; remaining product findings are retained."
            if check.get("passed") else "findings remain unresolved." if check else "not run."))
        with st.expander("Exact handoff record"):
            st.code(json.dumps(packet, indent=2, ensure_ascii=False), language="json")
        prefix = _shared_key(root, pack, actor_id, local_demo, can_write, allowed_packs, preview["digest"])
        confirmed = st.checkbox("I reviewed this exact handoff and confirm its contents may be shared in my Git branch.", key=prefix + "_share_confirm")
        if st.button("Save proposal handoff", key=prefix + "_share", disabled=not (local_demo and can_write and confirmed)):
            result = proposals.share(root, pack, proposal_id=proposal_id, actor_id=actor_id, expected_digest=preview["digest"],
                confirmed=confirmed, local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
            if result.get("ok"):
                st.success("Saved the reviewed handoff. Use Save work to my branch to inspect and commit its file. In another checkout, open Plan changes or Review requests to restage it and run fresh validators.")
            else:
                _show_errors(result, "The proposal handoff could not be saved.")


def _consumer_table(rows, *, registry=False):
    """Keep nested pin records out of the main study-impact table."""
    def words(value, fallback="Not declared"):
        return str(value) if isinstance(value, (str, int, float)) and str(value).strip() else fallback
    result = []
    decisions = {"reuse": "reuse", "reconsider": "review a study-specific definition", "exclude": "exclude in this study"}
    for row in rows:
        if registry:
            citations = [words(cite.get("product")) + " · " + words(cite.get("spec_version"))
                         for cite in row.get("cites_release") or [] if isinstance(cite, dict)]
            result.append({"Study": words(row.get("study")), "Cited products and versions": "; ".join(citations) or "Not declared"})
            continue
        definitions = []
        for definition in row.get("definitions") or []:
            if isinstance(definition, dict):
                identifier = definition.get("variable_id") or definition.get("variable")
                decision = definition.get("decision")
                choice = decisions.get(decision, words(decision, "decision not recorded")) if isinstance(decision, str) else "decision not recorded"
                definitions.append(words(identifier) + ": " + choice)
        follow_up = []
        if row.get("status") == "unreadable":
            follow_up.append("Repair the unreadable study selection")
        if row.get("stale"):
            follow_up.append("Review changed product definitions or settings")
        if row.get("build_stale"):
            follow_up.append("Recheck the selected build")
        if row.get("superseded"):
            follow_up.append("Review the newer product version")
        result.append({"Study": words(row.get("study")), "Selected version": words(row.get("spec_version")),
                       "Study choice": "Product selected" if row.get("status") == "pinned" else words(row.get("status")).replace("_", " "),
                       "Definition choices": "; ".join(definitions) or "No per-definition choices recorded",
                       "Follow-up": "; ".join(follow_up) or "No recorded change detected"})
    return result


def _impact(impact):
    st.write("**Declared dependency and consumer impact**")
    st.caption("This report uses declared dependencies and registered consumers. Reviewers must assess any undeclared dependencies.")
    labels = {"direct_variables": "Directly affected definitions", "dependent_variables": "Definitions that depend on them",
              "dependencies": "Declared definition dependencies", "external_dependencies": "Dependencies outside this contract",
              "consumers": "Studies pinned to this product", "registry_consumers": "Studies citing this product in the registry",
              "shared_removed": "Requested shared-product removals", "study_dependency_conflicts": "Study-only dependency conflicts"}
    for name, value in impact.items():
        if name == "capabilities":
            if value:
                with st.expander("Declared engine capability details"):
                    st.json(value)
            continue
        if name in {"notes", "errors"}:
            for item in value:
                (st.warning if name == "errors" else st.caption)(str(item))
            continue
        label = labels.get(name, str(name).replace("_", " ").capitalize())
        if isinstance(value, list):
            st.write(f"{label}:" if value else f"{label}: none declared")
            if value and all(isinstance(row, dict) for row in value):
                if name in {"consumers", "registry_consumers"}:
                    st.dataframe(_consumer_table(value, registry=name == "registry_consumers"), hide_index=True, width="stretch")
                    with st.expander("Recorded study pin details" if name == "consumers" else "Recorded registry citation details"):
                        st.json(value)
                else:
                    st.dataframe(value, hide_index=True, width="stretch")
            elif value:
                st.write(", ".join(str(item) for item in value))
        elif isinstance(value, dict):
            st.write(f"{label}:")
            st.json(value)
        else:
            st.write(f"{label}: {value}")


def render(root, pack, brief, *, expected_baseline, baseline_changed=False,
           actor_id="", local_demo=False, can_write=False, allowed_packs=None, guided=False, initial_proposal_id=None):
    try:
        supported = proposals.supported_parameters(root, pack)
    except (OSError, ValueError) as exc:
        st.error(f"Supported configuration settings could not be read: {exc}")
        return
    if not supported:
        return
    st.subheader("Propose settings for review" if guided else "4. Stage a configuration proposal")
    if st.button("Edit treatment code lists", key="configuration_treatment_codelists"):
        from experiments.portal import connected_workflow_page as navigation
        navigation.open_route("treatment_codelists", pack, actor_id)
    st.caption("Enter supported settings explicitly. Each staged proposal preserves a before-and-after diff, "
               "study exclusions, and an engineering handoff. Submission requests review; it does not approve or release a product.")
    st.write("Choose a setting below and stage your proposal. Review the saved changes, run the validators, "
             "then submit for review when every required check passes.")
    prefix = f"design_{pack}_proposal_"
    context, metadata_key = selection_context(root, pack, actor_id, local_demo, can_write, allowed_packs)
    imported = st.session_state.get("configuration_import_" + context) or {}
    if initial_proposal_id and st.session_state.get(metadata_key + "_incoming") != initial_proposal_id:
        st.session_state.pop("configuration_import_" + context, None)
        imported = {}
        st.session_state[metadata_key] = initial_proposal_id
        st.session_state[metadata_key + "_incoming"] = initial_proposal_id
    notice_key = metadata_key + "_notice"
    if st.session_state.get(notice_key):
        st.success(st.session_state.pop(notice_key))

    parameters = [{"ref": ref, "label": label, "kind": kind, "value": value}
                  for ref, (label, kind, value) in supported.items()]
    changes, input_errors = _cohort_editor(root, pack, expected_baseline, context,
        enabled=bool(actor_id and local_demo and can_write and not baseline_changed))
    with st.expander("Supported shared-product settings", expanded=True):
        st.caption("Select a setting to change it. Free-text scientific definitions are preserved for engineering review.")
        chosen_refs = None
        if guided:
            labels = {p["ref"]: p["label"] for p in parameters}
            chosen_refs = form_help.field(st.multiselect, "Settings to change", list(labels), key=prefix + "selected_settings", format_func=labels.get, binding=(pack, expected_baseline),
                help="Choose one or more settings. Only your selected settings will appear in the proposal diff.")
            if not chosen_refs:
                st.caption("Choose a setting above to see its current value and enter your proposed value.")
        for parameter in parameters:
            if guided and parameter["ref"] not in chosen_refs:
                continue
            field = hashlib.sha256(parameter["ref"].encode()).hexdigest()[:12]
            selected = True if guided else st.checkbox("Change " + parameter["label"], key=prefix + field + "_change")
            value_key = prefix + field + "_value"
            value = _parameter_field(parameter, value_key=value_key, selected=selected,
                binding=(pack, expected_baseline, parameter["ref"], parameter["kind"], parameter["value"]))
            st.caption(f"Current value: {parameter['value']}")
            if guided and str(parameter["value"]) == "REPLACE_ME":
                st.caption("This value is still unspecified. Enter the value agreed for the intended product; the validator will check its format and consistency.")
            if selected:
                try:
                    changes.append({"ref": parameter["ref"], "value": _value(value, parameter["kind"])})
                except (TypeError, ValueError, OverflowError):
                    input_errors.append(f"Enter a valid {parameter['kind']} for {parameter['label']}.")
    for error in input_errors:
        st.info(error)
    if imported:
        st.info(imported["notice"])
        if imported["conflicts"]:
            with st.expander("Conflicts reviewed when this intent was restored"):
                st.table(imported["conflicts"])
        if imported["unsupported_changes"]:
            st.warning("These settings remain engineering requests. They are preserved with this revision and cannot execute as configuration changes.")
            st.json(imported["unsupported_changes"])
            keep = st.checkbox("Keep these unsupported setting requests in this proposal", value=True, key="configuration_import_keep_" + context)
            if keep:
                changes.extend(imported["unsupported_changes"])

    exclusions = []
    with st.expander("Study-only exclusions") if not guided else __import__("contextlib").nullcontext():
      if not guided:
        st.caption("Choose removed variables that should be excluded only for a named study. "
                   "These stay separate from shared-product settings and do not remove engine outputs.")
        removed = brief.get("removed") or []
        # The brief validator reports duplicate names. Render one widget per name
        # while that input is being corrected, without changing the saved brief.
        studies = list(dict.fromkeys(brief.get("studies") or []))
        if not removed or not studies:
            st.info("Name the intended studies and select variables to remove above to record study-only exclusions.")
        for study in studies:
            field = hashlib.sha256(study.encode()).hexdigest()[:12]
            key = prefix + "study_" + field
            if key in st.session_state:
                st.session_state[key] = [identifier for identifier in st.session_state[key] if identifier in removed]
            selected = form_help.field(st.multiselect, f"Exclude only in {study}", removed, key=key, binding=(pack, expected_baseline, study))
            if selected:
                exclusions.append({"study": study, "variables": selected})

    enabled = bool(actor_id and local_demo and can_write)
    has_changes = bool(changes or brief.get("removed") or brief.get("added") or brief.get("source_changed"))
    if not enabled:
        st.info("Staging, validation, and submission require a local editing session with permission to change this product.")
    if st.button("Stage configuration proposal", key=f"configuration_stage_{pack}",
                 disabled=not enabled or baseline_changed or bool(input_errors) or not has_changes or not brief.get("purpose")):
        result = proposals.stage(root, pack, brief, configuration_changes=changes, study_exclusions=exclusions,
                                 expected_baseline=expected_baseline, actor_id=actor_id, local_demo=local_demo,
                                 can_write=can_write, allowed_packs=allowed_packs)
        if result.get("ok"):
            st.session_state[metadata_key] = result["proposal_id"]
            st.session_state[notice_key] = "Configuration proposal staged. Review its exact changes and run validators before submitting for review."
            st.rerun()
        else:
            _show_errors(result, "The configuration proposal could not be staged.")
            st.session_state[metadata_key + "_refused"] = True    # the earlier proposal's results are labelled as such (walk UC3-P2-5)

    if not actor_id:
        return
    catalog = proposals.list_proposals(root, pack, actor_id=actor_id, allowed_packs=allowed_packs)
    for error in catalog.get("errors") or []:
        st.warning(str(error))
    entries = catalog.get("proposals") or []
    if entries:
        with st.expander("Your staged configuration proposals"):
            labels = {entry["proposal_id"]: f"{entry.get('purpose') or 'Configuration proposal'} · {entry['proposal_id'][:8]}" for entry in entries}
            key = prefix + "saved_choice"
            if st.session_state.get(key) not in labels:
                st.session_state[key] = next(iter(labels))
            choice = st.selectbox("Staged proposal", list(labels), key=key, format_func=labels.get)
            if st.button("Open staged proposal", key=f"configuration_open_{pack}"):
                st.session_state.pop("configuration_import_" + context, None)
                st.session_state[metadata_key] = choice
                st.rerun()
    proposal_id = st.session_state.get(metadata_key)
    if not proposal_id:
        return
    loaded = proposals.load(root, pack, proposal_id=proposal_id, actor_id=actor_id, allowed_packs=allowed_packs)
    if not loaded.get("ok"):
        _show_errors(loaded, "The staged proposal could not be opened.")
        return
    proposal = loaded["proposal"]
    st.subheader("Review staged proposal")
    st.write(f"Proposal {proposal_id[:8]} · {proposal.get('status', 'staged').replace('_', ' ')}")
    st.caption("You are reviewing this saved snapshot. Changes in the plan above need to be staged as a new proposal.")
    if proposal.get("variable_review_binding"):
        st.caption("Prepared from the completed scientific, source and output tables. Changes to those reviews or their inputs require a fresh proposal.")
        _reopen_variable_review(root, pack, actor_id, allowed_packs=allowed_packs,
            key="configuration_review_variables_" + context + "_" + proposal_id)
    _reviewed_definitions(proposal, context)
    if proposal.get("purpose"):
        st.write(proposal["purpose"])
    stale = bool(loaded.get("stale"))
    if stale:
        st.warning("The reviewed variable table, source product or declared consumer impact changed. Stage a new proposal from the current baseline before submission.")
    description = proposals.dw.describe(root, pack)
    if any(c["ref"] in proposals.CODELIST_REFS for c in proposal["configuration_changes"]):
        if st.button("Revise treatment code list", key=f"configuration_revise_codes_{pack}", disabled=not enabled):
            from experiments.portal import connected_workflow_page as navigation
            navigation.open_route("treatment_codelists", pack, actor_id, params={"proposal_id": proposal_id})
    else:
        st.button("Revise this proposal", key=f"configuration_revise_{pack}",
              disabled=not enabled or stale or bool(description["errors"]),
              help="Restore this proposal's inputs above. Edit them and stage a new snapshot; the existing proposal and review remain unchanged.",
              on_click=_restore_for_revision,
              args=(pack, proposal, description, supported, guided, "revision_saved_" + context))
    for warning in proposal.get("warnings") or []:
        st.warning(str(warning))
    for error in proposal.get("errors") or []:
        st.warning(str(error))

    st.write("**Before-and-after configuration diff**")
    files = proposal.get("files") or []
    if not files:
        st.info("No supported shared-product configuration changes are staged. Review the study exclusions and engineering handoff below.")
    for file in files:
        st.caption(file["path"])
        st.code(file["diff"], language="diff")
        with st.expander("Full before-and-after configuration: " + file["path"]):
            left, right = st.columns(2)
            with left:
                st.caption("Before")
                st.code(file["before"], language="yaml")
            with right:
                st.caption("Proposed after")
                st.code(file["after"], language="yaml")
    _impact(proposal.get("impact") or {})
    st.write("**Study-only exclusions**")
    if proposal.get("study_exclusions"):
        st.table(proposal["study_exclusions"])
    else:
        st.caption("No study-only exclusions are included in this proposal.")
    st.write("**Engineering handoff**")
    handoff = proposal.get("engineering_handoff") or []
    if handoff:
        st.warning("Unsupported derivations remain an engineering handoff. No derivation logic is generated by this proposal.")
        st.dataframe(handoff, hide_index=True, width="stretch")
        st.info("This work is done by the engineering team. Hand it over below so it has an owner and a status; "
                "to submit the supported settings independently, stage a separate proposal without these unresolved derivations.")
        _request_engineering(root, pack, proposal_id, actor_id, local_demo=local_demo,
                             can_write=can_write, allowed_packs=allowed_packs)
    else:
        st.caption("No unsupported derivation changes are requested.")

    validation = loaded.get("validation") or {}
    if loaded.get("validation_error"):
        st.warning("The saved validation receipt could not be verified, so submission is disabled. The staged proposal is intact.")
        if stale:
            st.caption("Stage a new proposal from the current baseline to check the current product and consumer inputs.")
        elif loaded.get("submission"):
            st.caption("The existing submitted review request and its evidence are retained. Use Revise this proposal to stage and validate a new snapshot.")
        elif not enabled:
            st.caption("Open a local editing session with permission to change this product, then run the proposal validators.")
        else:
            st.caption("Choose Run proposal validators below to replace the unusable receipt with fresh results. The proposal and product are unchanged.")
        with st.expander("Why the previous validation cannot be used"):
            st.text(loaded["validation_error"])
    if validation:
        st.write("**Existing validator results**")
        if any(check.get("pre_existing") and not check.get("passed") for check in validation.get("checks") or []):
            st.warning("The full product checks have not passed. Unchanged existing findings remain open; this proposal can only request review of the supported change.")
        if st.session_state.pop(metadata_key + "_refused", None):
            st.caption("The last stage attempt was refused, so these results belong to the previously staged proposal.")
        for check in validation.get("checks") or []:
            if check.get("passed"):
                st.success(f"{check['validator']}: passed")
            elif check.get("pre_existing"):
                st.warning(f"{check['validator']}: failed before this change too (the product's own open work; it does not block this proposal)")
            else:
                st.error(f"{check['validator']}: failed")
            findings = check.get("errors") or []
            if findings:
                with st.expander(f"{check['validator']}: read {len(findings)} finding(s)"):
                    for error in findings:
                        st.text(str(error))
            if check.get("note"):
                st.caption(check["note"])
        for caveat in validation.get("caveats") or []:
            st.info(caveat)
        for error in validation.get("errors") or []:
            st.error(str(error))
        if not validation.get("passed"):
            st.info("Submission is blocked by the findings above. Correct a supported setting in the form, stage a new proposal, "
                    "and run validators again. Contract, mapping, and engine findings need the product's data expert; "
                    "staging a parameter change does not complete those requirements.")
    elif not loaded.get("validation_error") and not loaded.get("submission"):
        st.info("Run the existing validators on the staged proposal before submitting it for review.")
    submission = loaded.get("submission")
    action_args = dict(proposal_id=proposal_id, actor_id=actor_id, local_demo=local_demo,
                       can_write=can_write, allowed_packs=allowed_packs)
    if st.button("Run proposal validators", key=f"configuration_validate_{pack}",
                 disabled=not enabled or stale or bool(submission)):
        result = proposals.validate(root, pack, **action_args)
        if result.get("ok"):
            st.session_state[notice_key] = ("Proposal checks completed and the review-submission requirements are satisfied. Review all remaining product findings below."
                                           if result.get("passed") else "Proposal validators ran. Resolve their findings before submission.")
            st.rerun()
        else:
            _show_errors(result, "The proposal validators could not run.")
    can_submit = loaded.get("can_submit") is True
    if st.button("Submit proposal for review", key=f"configuration_submit_{pack}",
                 disabled=not enabled or not can_submit or bool(submission)):
        result = proposals.submit(root, pack, **action_args)
        if result.get("ok"):
            st.session_state[notice_key] = "Submitted the staged configuration proposal for review. No approval or release was recorded."
            st.rerun()
        else:
            _show_errors(result, "The configuration proposal could not be submitted for review.")
    if submission:
        st.success("This configuration proposal was submitted for review. Approval and release remain separate decisions.")
        # THE AUTHOR SEES THE REVIEW (2026-09-07): the receipt names the published request, so the
        # reviewer's decision and the later apply and validate acts are shown here, by name and date.
        if loaded.get("review_request"):
            from experiments.portal import review_inbox
            request = review_inbox.load_request(root, pack, request_id=loaded["review_request"], actor_id=actor_id,
                                                allowed_packs=allowed_packs)
            if request.get("ok"):
                st.write(f"**Review request {request['request_id'][:8]}: {request['status_words']}**")
                for line in request["history"]:
                    st.write(line)
                if request["proposal_state"] != "intact":
                    st.warning("The submitted snapshot no longer matches this proposal, so it cannot be accepted. Stage and submit the current proposal again.")
            else:
                _show_errors(request, "The review request for this proposal could not be opened.")
    st.download_button("Download staged configuration proposal", json.dumps(proposal, indent=2, ensure_ascii=False),
                       file_name=f"configuration_proposal_{proposal_id[:8]}.json", mime="application/json",
                       key=f"configuration_download_{pack}")
    _share_current(root, pack, proposal_id, actor_id, local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
