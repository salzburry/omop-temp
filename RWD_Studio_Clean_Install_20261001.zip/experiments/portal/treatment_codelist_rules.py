"""Bounded authoring of the native, ordered treatment category code list.

This is a configuration editor, not a terminology membership service. Source
column bindings and code-system declarations remain owned by the data expert.
"""
from __future__ import annotations

from copy import deepcopy
import json
import re

from engine.codelists import compile_case
from engine.vocabularies import code_errors

FILE = "codelists/treatment_categories.yaml"
REF = FILE + "#/document"
EDITABLE = {"name", "description", "version", "status", "categories", "review_sources"}
OPERATORS = {
    "equals": "Treatment name equals", "like_any": "Treatment name matches a pattern",
    "category_equals": "Drug category equals", "is_null": "Treatment name is missing",
    "code_in": "Code is in this list", "code_prefix_any": "Code starts with",
    "always": "All remaining treatments",
}


def _text(value, label, maximum=2000):
    if not isinstance(value, str) or not value.strip() or len(value) > maximum or any(ord(c) < 32 and c not in "\n\r\t" for c in value):
        raise ValueError(f"Enter {label} as non-empty text (up to {maximum} characters).")
    if re.search(r"REPLACE_ME|\bTODO\b", value, re.I):
        raise ValueError(f"Replace the template placeholder in {label}.")
    return value


def _match(value, match_on, depth=0):
    if depth > 8 or not isinstance(value, dict) or len(value) != 1:
        raise ValueError("Each treatment condition needs one supported matching operation, with at most eight nested levels.")
    op, item = next(iter(value.items()))
    if op in {"all_of", "any_of"}:
        if not isinstance(item, list) or not 1 <= len(item) <= 100:
            raise ValueError("A combined treatment condition needs a non-empty list of conditions.")
        for child in item:
            if child == {"always": True}:
                raise ValueError("Use the remaining-treatments condition only as the final category.")
            _match(child, match_on, depth + 1)
    elif op in {"is_null", "always"}:
        if item is not True:
            raise ValueError(f"{op} must be explicitly true.")
    elif op in {"like_any", "code_in", "code_prefix_any"}:
        if not isinstance(item, list) or not 1 <= len(item) <= 2000:
            raise ValueError(f"{op} needs a non-empty list; enter one value per line.")
        for entry in item:
            _text(entry, "matching value", 500)
            if op == "code_in":
                errors = code_errors(match_on.get("code_system"), entry)
                if errors:
                    raise ValueError(" ".join(errors))
            if op == "code_prefix_any" and any(c in entry for c in "%_'\\"):
                raise ValueError("Enter literal code prefixes without wildcards or quotes.")
    elif op in {"equals", "category_equals", "regexp"}:
        _text(item, "matching value", 2000)
    else:
        raise ValueError(f"Unsupported treatment matching operation: {op}.")


def validate(value, *, before):
    """Validate the exact ordered document while preserving non-editor metadata."""
    if not isinstance(value, dict) or not isinstance(before, dict):
        raise ValueError("The treatment code list must be a mapping.")
    try:
        encoded = json.dumps(value, allow_nan=False)
    except (ValueError, TypeError, RecursionError) as exc:
        raise ValueError("Use literal, finite treatment code-list settings.") from exc
    if len(encoded.encode()) > 512 * 1024:
        raise ValueError("Split this code list into a smaller review (maximum 512 KiB).")
    if {k: v for k, v in value.items() if k not in EDITABLE} != {k: v for k, v in before.items() if k not in EDITABLE}:
        raise ValueError("Keep this product's code-list identity, source bindings and existing provenance unchanged. Use source configuration to change delivered columns.")
    for field in ("name", "description", "version"):
        _text(value.get(field), field)
    if value.get("status") != "active":
        raise ValueError("Review and replace all template categories before preparing an active configuration proposal.")
    sources = value.get("review_sources")
    if not isinstance(sources, dict) or set(sources) != {"source", "rationale"}:
        raise ValueError("Record the source or specification citation and the reason for this code-list change.")
    for key in sources:
        _text(sources[key], key)
    match_on = value.get("match_on") or {}
    if not isinstance(match_on, dict):
        raise ValueError("Repair the code list's source-column declarations first.")
    for field in ("name_column", "drug_category_column", "code_column", "name_source", "category_source"):
        if field in match_on and not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", str(match_on[field])):
            raise ValueError(f"Repair match_on.{field}: choose a plain logical column or source identifier.")
    categories = value.get("categories")
    if not isinstance(categories, list) or not 1 <= len(categories) <= 2000:
        raise ValueError("Add at least one treatment category, including the final remaining-treatments category.")
    codes, fallback = set(), []
    for index, category in enumerate(categories):
        if not isinstance(category, dict) or not {"code", "label", "match"} <= set(category):
            raise ValueError(f"Category {index + 1} needs an output code, label and condition.")
        code = category["code"]
        if type(code) is not int or not -(2**31) <= code < 2**31:
            raise ValueError(f"Category {index + 1} needs a whole-number output code within the engine's integer range.")
        if code in codes:
            raise ValueError(f"Output code {code} is repeated. Give each category its own code.")
        codes.add(code)
        _text(category["label"], f"category {index + 1} label", 500)
        _match(category["match"], match_on)
        if category["match"] == {"always": True}:
            fallback.append(index)
    if fallback != [len(categories) - 1]:
        raise ValueError("Include exactly one remaining-treatments category and move it to the last position. The first matching category wins.")
    compile_case(value)  # The same pure compiler used by treatment.categorize_line.
    return deepcopy(value)
