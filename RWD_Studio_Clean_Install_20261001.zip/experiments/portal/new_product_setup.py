"""Explain compatibility of the existing registration choices before Preview."""
from __future__ import annotations

from pathlib import Path

from rwd_tools import new_product
from rwd_tools import product_gates
from rwd_tools import spec_lint
from experiments.portal import ui_text as ui

LABELS = {"np_tclass": "Tumour class", "np_narrow": "Catalogue axis"}


def describe(root, state, sheet_scope):
    result = {"family": "", "blockers": [], "warnings": [], "suggestions": {}, "matches": False}
    if state.get("np_mode") != ui.NEW_PRODUCT_MODES[2] and state.get("np_cond") == "non_oncology":
        result["warnings"].append(ui.NON_ONCOLOGY_SETUP_HELP)
    if state.get("np_mode") != ui.NEW_PRODUCT_MODES[2] and state.get("np_vendor") == "cota" and state.get("np_tclass") == "solid":
        result["warnings"].append("The existing vendor catalogue suggests COTA haematological products; your tumour class is solid. Review the selected vendor and tumour class before Preview. This suggestion does not block setup.")
    if state.get("np_mode") != ui.NEW_PRODUCT_MODES[2] and state.get("np_vendor"):
        policy, error = product_gates.read_yaml(str(Path(root) / "governance/vendor_policy.yaml"))
        vendor = ((policy or {}).get("vendors") or {}).get(state["np_vendor"]) if not error and isinstance(policy, dict) else None
        if isinstance(vendor, dict) and vendor.get("schema_evidence") == product_gates.PENDING_SCHEMA_EVIDENCE:
            result["warnings"].append(f"{state['np_vendor']}: only a claims draft can be registered. Delivery terms and the source-evidence route still need source-owner review. Registration grants no source access, profiling, AI eligibility or execution.")
            if state.get("np_modality") == "ehr":
                result["blockers"].append("This vendor has no supported EHR source adapter or reviewed evidence route. Retain an unfinished setup until those capabilities are added and validated.")
    try:
        mode = state.get("np_mode")
        family = state.get("np_family") if mode == ui.NEW_PRODUCT_MODES[1] else None
        if mode == ui.NEW_PRODUCT_MODES[2] and state.get("np_old"):
            registry, error = product_gates.read_yaml(str(Path(root) / "products/registry.yaml"))
            if not error:
                row = next((row for row in (registry or {}).get("tumors", []) if isinstance(row, dict)
                    and f"products/{row.get('family') or 'oncology'}/{row.get('slug')}/{row.get('current_spec_version')}" == state["np_old"]), {})
                family = row.get("tumour_key") or row.get("slug")
        registry = spec_lint.load_tumour_registry(root)
        if mode != ui.NEW_PRODUCT_MODES[2]:
            named = set()
            disease_fields = ("np_slug", "np_name", "np_terms") if mode == ui.NEW_PRODUCT_MODES[0] else ("np_slug", "np_name")
            for key in disease_fields:
                named.update(spec_lint.names_non_oncology(str(state.get(key) or "").replace("_", " "), registry=registry))
            if named and state.get("np_cond") != "non_oncology":
                result["blockers"].append("These disease names identify " + ", ".join(sorted(named)) +
                    ". Choose the independent condition class for a non-oncology product; keep the actual disease names.")
                return result
        family = registry["aliases"].get(family, family)
        if mode == ui.NEW_PRODUCT_MODES[0] and (sheet_scope or {}).get("ok"):
            known = [value for value in ((sheet_scope or {}).get("population") or {}).get("families", [])
                     if value in registry["families"]]
            if known:
                result["blockers"].append("This workbook names an existing condition family: " + ", ".join(known) +
                    ". Choose the registered-condition starting point and the matching family and condition class. A new product can reuse that identity without creating a competing disease definition.")
                return result
        if family not in registry["families"]:
            return result
        condition_class = registry.get("condition_classes", {}).get(family, "oncology")
        if mode != ui.NEW_PRODUCT_MODES[2] and state.get("np_cond") and state["np_cond"] != condition_class:
            result["blockers"].append(f"The selected condition {family} is registered as {condition_class}. Choose its matching condition class or another condition; changing the label does not change its identity.")
            return result
        result["family"] = family
        if mode != ui.NEW_PRODUCT_MODES[2]:
            expected = new_product.catalogue_choices(root, family)
            for field, key in (("tumor_class", "np_tclass"), ("narrow", "np_narrow")):
                value = expected.get(field)
                if value and state.get(key) != value:
                    result["suggestions"][key] = value
                    if state.get(key):
                        text = f"The catalogue records {family} under {LABELS[key]}: {value}; your entry is {state[key]}."
                        result["warnings"].append(text + " Review this classification; the catalogue suggestion is available below. This suggestion does not block setup.")
        scope = sheet_scope or {}
        population = scope.get("population") or {}
        if scope.get("ok"):
            found = population.get("families", [])
            if family in found:
                result["matches"] = True
            elif found or population.get("non_oncology"):
                named = ", ".join(found + population.get("non_oncology", []))
                result["blockers"].append(f"This workbook's population names {named}, but the selected condition is {family}. Choose the workbook for {family}, or correct the selected condition before Preview. Leaving out additional sheets does not fix this mismatch.")
            else:
                result["warnings"].append(
                    f"The current population check could not identify {family} in this workbook. "
                    "This check uses the study-population statement, not a required list of output variables. "
                    "In the workbook sheet controls, map the sheet containing that statement to study_population. "
                    "If the statement was removed from Excel, restore it as document context and upload the revised workbook. "
                    "Optional output variables can remain removed. Preview checks the current workbook; no disease match is assumed.")
    except (OSError, ValueError, TypeError, AttributeError, KeyError, SystemExit):
        result["blockers"].append("The condition registry or catalogue could not be checked. Restore a readable registry in this checkout before Preview.")
    return result


def context(result):
    """Only current registration choices and check summaries belong in setup chat."""
    return {**result, "suggestions": {LABELS[key]: value for key, value in result["suggestions"].items()},
        "guidance": "Use these current checks to explain the next step. Catalogue and vendor classifications are suggestions only; the person may keep a product-specific choice within its actual condition class. A workbook mismatch is corrected in the workbook or condition selector, not by approval/disposition evidence. Do not change source classification or invent missing information. Independent conditions start with no oncology rules and need explicit supported configuration and scientific review; never change its condition class or disease names merely to pass registration."}


def render(result):
    import streamlit as st
    from experiments.portal import form_assistance as forms
    if not result.get("family") and not result["blockers"] and not result["warnings"]:
        return []
    st.write("**Check your setup**")
    for message in result["blockers"]:
        st.error(message)
    for message in result["warnings"]:
        st.warning(message)
    if result["matches"]:
        st.caption(f"The workbook population names {result['family']}. Full extraction and scientific review still follow.")
    if result["suggestions"]:
        st.caption("Catalogue suggestions: " + "; ".join(f"{LABELS[key]}: {value}" for key, value in result["suggestions"].items()))
        if st.button("Review catalogue suggestions", key="np_review_catalogue"):
            public = forms.context()
            rows = [{"id": field["id"], "value": result["suggestions"][key]}
                    for field in (public or {}).get("fields", []) for key, label in LABELS.items()
                    if key in result["suggestions"] and field["label"] == label]
            if rows:
                forms.stage({"scope": public["scope"], "fields": rows}, public=public)
                st.rerun()
            else:
                st.info("Use the displayed catalogue suggestions in the matching fields above.")
    return ["resolve the setup compatibility findings"] if result["blockers"] else []
