"""Authenticated administrator enrollment for existing reviewer-owned public keys."""
from datetime import datetime, timezone
import hashlib
import copy
import difflib
import json
import os
from pathlib import Path
import tempfile
import uuid
import shutil
import subprocess
import yaml

from experiments.portal import authoring_session
from experiments.portal import identity
from rwd_tools import reviewer_identity_store as store
from rwd_tools import approval_identity


def _administrator(root):
    current = authoring_session.CURRENT.get()
    if (current is None or current.mode != "hosted" or identity.mode(os.environ) != "hosted"
            or "manage_users" not in current.permissions or current.root != str(Path(root).resolve())):
        raise ValueError("Enrollment requires a signed-in hosted administrator with user-management permission; demo profiles and command-line calls cannot enroll reviewers.")
    candidates = [u for u in store.current_roster(root)
        if (str(u.get("email") or u.get("name")) == current.actor or store.principal(u) == current.actor.casefold())]
    if len(candidates) != 1 or candidates[0].get("role") != "admin" or not store.principal(candidates[0]):
        raise ValueError("The current authenticated principal is no longer a registered administrator.")
    return candidates[0]


def describe(root):
    _administrator(root)
    value, revision = store.read(root)
    registry, errors = approval_identity.registry(str(root))
    if errors:
        raise ValueError("Repair the public signer registry: " + "; ".join(errors))
    keys = approval_identity.person_keys(registry)
    users = [u for u in store.current_roster(root) if store.principal(u) and u.get("role") in store.REVIEW_ROLES]
    _path, _raw, _doc, registry_revision = _public_registry(root)
    return {"path": str(store.location(root)[0]), "revision": revision, "events": value["events"],
        "registry_revision": registry_revision,
        "reviewers": [{"name": u.get("name"), "principal": store.principal(u),
            "keys": sorted(k for k, who in keys.items() if who == u.get("name"))} for u in users]}


def _public_registry(root):
    from experiments.portal import review_setup
    base = Path(root).resolve()
    path = base / approval_identity.REGISTRY
    if path.resolve() != path or not path.is_file() or path.stat().st_size > 2 * 1024 * 1024:
        raise ValueError("Restore the bounded public-key registry inside this workspace before registering a key.")
    raw = path.read_bytes()
    try:
        doc = review_setup._load(raw)
    except (ValueError, yaml.YAMLError) as error:
        raise ValueError("The public-key registry could not be read safely. Restore its reviewed structure before registering a key.") from error
    approval_identity._ssh_signer_lines(doc)
    return path, raw, doc, hashlib.sha256(raw).hexdigest()


def public_key_preview(public_key):
    """Show only normalized public material; private keys and SSH options are refused."""
    value = approval_identity.ssh_public_key(public_key.strip() if isinstance(public_key, str) else public_key)
    if value["algorithm"] != "ssh-ed25519":
        raise ValueError("Choose an Ed25519 public key for the current personal signing workflow.")
    return value


def register_public_key(root, *, reviewer_principal, public_key, reason, expected_registry_revision, confirmed=False):
    """An independent hosted administrator records a public key; no enrollment, signing or commit."""
    admin = _administrator(root)
    if confirmed is not True or not isinstance(reason, str) or not 10 <= len(reason.strip()) <= 1000:
        raise ValueError("Confirm the independently checked public key and record how you checked it (10–1000 characters).")
    material = public_key_preview(public_key)
    program = shutil.which("ssh-keygen")
    if not program:
        raise ValueError("OpenSSH is needed to check this public key. Ask the installation administrator to enable ssh-keygen.")
    with tempfile.TemporaryDirectory(prefix="rwd-public-key-check-") as directory:
        public_path = Path(directory) / "reviewer.pub"
        public_path.write_text(material["public_key"] + "\n", encoding="utf-8")
        try:
            result = subprocess.run([program, "-lf", str(public_path), "-E", "sha256"],
                                    capture_output=True, text=True, timeout=15)
        except (OSError, subprocess.TimeoutExpired) as error:
            raise ValueError("The public key check could not finish. Retry after the installation administrator checks OpenSSH.") from error
        if result.returncode or material["key_id"] not in result.stdout.split():
            raise ValueError("OpenSSH could not validate this public key. Select the reviewer's complete public key.")
    reviewer_principal = str(reviewer_principal).strip().casefold()
    trust_path, _ = store.location(root)
    trust_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    from experiments.portal import local_process_lock as locks
    from experiments.portal import lifecycle_workspace
    from experiments.portal import review_setup
    with locks.locked(trust_path.parent / "reviewer-key-registration.lock", trust_path.parent):
        admin = _administrator(root)
        users = [u for u in store.current_roster(root) if store.principal(u) == reviewer_principal]
        if len(users) != 1 or users[0].get("role") not in store.REVIEW_ROLES:
            raise ValueError("Choose one current named reviewer from the authenticated roster.")
        person = users[0]
        if reviewer_principal == store.principal(admin) or person.get("name") == admin.get("name"):
            raise ValueError("A different authenticated administrator must register the reviewer's public key.")
        path, original, doc, revision = _public_registry(root)
        if not isinstance(expected_registry_revision, str) or revision != expected_registry_revision:
            raise ValueError("The public-key register changed. Refresh it and review the current entries before saving.")
        fingerprint = material["key_id"]
        if fingerprint in approval_identity.ineligible_keys(doc):
            raise ValueError("This key is recorded as ineligible and cannot become a person's review key.")
        existing = [entry for entry in doc.get("signers", []) if entry.get("key_id") == fingerprint]
        if existing:
            raise ValueError("This public key is already registered. Review its existing identity and purpose; it cannot be reassigned or registered twice.")
        history, _ = store.read(root)
        if any(event["key_id"] == fingerprint for event in history["events"]):
            raise ValueError("This key already has enrollment or revocation history. Restore and review its existing registration instead of reassigning it.")
        entry = {"key_id": fingerprint, "identity": person["name"], "email": reviewer_principal,
                 "attests": approval_identity.PERSON_REVIEW,
                 "registered_date": datetime.now(timezone.utc).date().isoformat(),
                 "registered_by": admin["name"], "registered_by_principal": store.principal(admin),
                 "registration_reason": " ".join(reason.split()), "public_key": material["public_key"]}
        text = lifecycle_workspace._registry_with_entry(original.decode("utf-8-sig"), entry,
                    collection="signers", identifier="key_id", label="public key")
        output = text.encode("utf-8")
        if original.startswith(b"\xef\xbb\xbf"):
            output = b"\xef\xbb\xbf" + output
        approval_identity._ssh_signer_lines(review_setup._load(output))
        _administrator(root)
        if path.read_bytes() != original:
            raise ValueError("The public-key register changed while saving. Refresh it before trying again.")
        review_setup._atomic(path, output)
    return {"ok": True, "key_id": fingerprint, "reviewer": person["name"],
            "registry_revision": hashlib.sha256(output).hexdigest(),
            "message": "Public key registered. Record the registry change in history, then enroll the verified reviewer identity. No clinical approval or signature was created."}


def public_key_history(root, *, reviewer_principal, key_id):
    """Review only one administrator's pending addition; never sweep other registry edits."""
    admin = _administrator(root)
    from experiments.portal import review_setup
    from experiments.portal import reviewed_history
    from experiments.portal import lifecycle_workspace
    base = Path(root).resolve()
    _path, raw, current, revision = _public_registry(base)
    users = [u for u in store.current_roster(base) if store.principal(u) == reviewer_principal]
    entries = [entry for entry in current.get("signers", []) if entry.get("key_id") == key_id]
    if len(users) != 1 or len(entries) != 1 or users[0].get("role") not in store.REVIEW_ROLES:
        raise ValueError("Select one current reviewer and their registered public key before reviewing history.")
    person, entry = users[0], entries[0]
    review_setup._registry_entry(raw, key_id, entry.get("public_key", ""), person["name"], reviewer_principal)
    if reviewer_principal == store.principal(admin) or person.get("name") == admin.get("name"):
        raise ValueError("A different authenticated administrator must record this public-key registration.")
    head = reviewed_history._git(base, ["rev-parse", "--verify", "HEAD"]).stdout.decode().strip()
    branch = reviewed_history._git(base, ["symbolic-ref", "--quiet", "HEAD"], check=False).stdout.decode().strip()
    if not branch:
        raise ValueError("Choose a named Git branch before recording the public-key registration.")
    size = reviewed_history._git(base, ["cat-file", "-s", head + ":" + approval_identity.REGISTRY], check=False)
    if size.returncode or not size.stdout.strip().isdigit() or int(size.stdout) > 2 * 1024 * 1024:
        raise ValueError("Restore the reviewed public-key registry in Git history before recording a new registration.")
    before = reviewed_history._git(base, ["show", head + ":" + approval_identity.REGISTRY]).stdout
    prior = review_setup._load(before)
    approval_identity._ssh_signer_lines(prior)
    try:
        review_setup._registry_entry(before, key_id, entry["public_key"], person["name"], reviewer_principal)
    except review_setup.Refused:
        recorded = False
    else:
        recorded = True
    basis = {"root": str(base), "head": head, "branch": branch, "key_id": key_id,
        "reviewer_principal": reviewer_principal, "administrator": store.principal(admin), "records": []}
    if not recorded:
        if entry.get("registered_by_principal") != store.principal(admin):
            raise ValueError("The administrator who checked and registered this key must review and record its pending addition.")
        expected = copy.deepcopy(prior)
        expected["signers"] = [*(prior.get("signers") or []), entry]
        expected_raw = lifecycle_workspace._registry_with_entry(before.decode("utf-8-sig"), entry,
            collection="signers", identifier="key_id", label="public key").encode("utf-8")
        if before.startswith(b"\xef\xbb\xbf"):
            expected_raw = b"\xef\xbb\xbf" + expected_raw
        if current != expected or raw != expected_raw:
            raise ValueError("Other public-key registry changes are pending. This action records only one new registration; "
                             "review those other changes, including comments or formatting, through the administrator's governed change workflow first. Nothing was recorded.")
        basis["records"] = [{"path": approval_identity.REGISTRY, "sha256": revision, "state": "changed"}]
    diff = "" if recorded else "".join(difflib.unified_diff(before.decode("utf-8-sig").splitlines(keepends=True),
        raw.decode("utf-8-sig").splitlines(keepends=True), fromfile="HEAD/" + approval_identity.REGISTRY,
        tofile="reviewed/" + approval_identity.REGISTRY))
    return {**basis, "digest": hashlib.sha256(json.dumps(basis, sort_keys=True).encode()).hexdigest(),
            "recorded": recorded, "diff": diff}


def record_public_key_history(root, *, reviewer_principal, key_id, expected_digest, confirmed=False):
    """An explicit administrator action records exactly the previewed public addition."""
    _administrator(root)
    if confirmed is not True:
        raise ValueError("Review and confirm the exact public-key registration diff before recording it.")
    from experiments.portal import reviewed_history
    def snapshot(base, _scope):
        return public_key_history(base, reviewer_principal=reviewer_principal, key_id=key_id)
    result = reviewed_history.commit(root, "reviewer-public-key", "Record independently checked reviewer public key",
        expected_digest=expected_digest, _snapshot=snapshot)
    return {"ok": True, **result, "message": "Public-key registration recorded in history. Continue with independent identity enrollment. "
            "No clinical approval or signature was created." + result["notice"]}


def save(root, *, reviewer_principal, key_id, reason, expected_revision, confirmed=False, revoke=False):
    if confirmed is not True or not isinstance(reason, str) or not 10 <= len(reason.strip()) <= 1000:
        raise ValueError("Confirm the independently checked principal/key mapping and record how you checked it (10–1000 characters).")
    reason = " ".join(reason.split())
    admin = _administrator(root)
    reviewer_principal = str(reviewer_principal).strip().casefold()
    if reviewer_principal == store.principal(admin):
        raise ValueError("A different authenticated administrator must enroll or revoke this reviewer's key; self-enrollment is not allowed.")
    path, _ = store.location(root)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    from experiments.portal import local_process_lock as locks
    with locks.locked(path.with_suffix(".lock"), path.parent):
        admin = _administrator(root)
        value, revision = store.read(root)
        if revision != expected_revision:
            raise ValueError("Reviewer enrollment changed. Refresh and review the current record before saving.")
        users = [u for u in store.current_roster(root) if store.principal(u) == reviewer_principal]
        if len(users) != 1 or users[0].get("role") not in store.REVIEW_ROLES:
            raise ValueError("Choose one current named reviewer from the authenticated roster.")
        person = users[0]
        if person.get("name") == admin.get("name"):
            raise ValueError("Enrollment requires a different person, not another profile for the administrator.")
        registry, errors = approval_identity.registry(str(root))
        if errors or approval_identity.person_keys(registry).get(key_id) != person.get("name"):
            raise ValueError("Choose this reviewer's existing person_review public-key fingerprint. Register their public key first; no key is created here.")
        if any((e["key_id"] == key_id and (e["principal"] != reviewer_principal or e["name"] != person["name"]))
                or (e["principal"] == reviewer_principal and e["name"] != person["name"]) for e in value["events"]):
            raise ValueError("This key or principal already belongs to a different named identity. Review the identity history instead of relabelling it.")
        event = {"id": uuid.uuid4().hex, "principal": reviewer_principal, "name": person["name"],
            "key_id": key_id, "by": store.principal(admin), "at": datetime.now(timezone.utc).isoformat(),
            "status": "revoked" if revoke else "enrolled", "reason": reason.strip()}
        value["events"].append(event)
        raw = json.dumps(value, indent=2, allow_nan=False).encode()
        if len(raw) > 4 * 1024 * 1024:
            raise ValueError("The protected enrollment history is full; archive it with the installation administrator.")
        fd, temporary = tempfile.mkstemp(prefix=".enrollment-", dir=path.parent)
        try:
            with os.fdopen(fd, "wb") as handle:
                handle.write(raw); handle.flush(); os.fsync(handle.fileno())
            os.replace(temporary, path)
        finally:
            Path(temporary).unlink(missing_ok=True)
    return {"ok": True, "event": event, "path": str(path)}
