"""A small, explicit origin choice before editing a variable's representation.

Returns staged choices only. The owning review writer is responsible for atomic
save, source validation and stale-input checks. No joins or line selectors are
inferred from the variable's name.
"""
from copy import deepcopy

import streamlit as st

from experiments.portal import variable_review_options as options
from experiments.portal.variable_review_consistency import canonical_type
from experiments.portal.variable_review_controls import TYPE_LABELS


ORIGINS = {"": "Not decided", "vendor": "Existing data column",
           "derived": "Calculated from other fields", "setting": "Study setting / fixed value",
           "other": "Other source situation"}
OTHER_KINDS = {"pending_mapping": "Source mapping still needed", "unavailable": "Not available in the data"}
CUSTOM = "__enter_custom_name__"


def _text(value):
    return value.strip() if isinstance(value, str) and value.strip().casefold() not in {
        "todo", "tbd", "replace_me", "undecided", "none", "null", "n/a"} else ""


def _pick(label, values, current, *, key, disabled=False, labels=None):
    working = _text(st.session_state.get(key, current))
    choices = list(dict.fromkeys(["", *[_text(value) for value in values if _text(value)],
                                 *([current] if current else []), *([working] if working else [])]))
    current = current if current in choices else ""
    choices = [value for value in choices if value != CUSTOM] + [CUSTOM]
    selected = st.selectbox(label, choices, index=choices.index(current), key=key, disabled=disabled,
                        format_func=lambda value: "Type a name..." if value == CUSTOM else
                            (labels or {}).get(value, value) if value else "Choose a name") or ""
    if selected == CUSTOM:
        return st.text_input("Enter " + label.lower(), value=current, key=key + "_custom", disabled=disabled).strip()
    return selected


def render(root, pack, actor_id, row, *, key, permitted, allowed_packs=None):
    """Stage source kind and an optional complete primary-column mapping."""
    source = deepcopy((row.get("values") or {}).get("source") or {})
    if not isinstance(source, dict):
        source = {}
    current_kind = _text(source.get("kind"))
    initial = (current_kind if current_kind in {"vendor", "derived"} else "setting"
               if current_kind in {"parameter", "constant"} else "other" if current_kind else "")
    chosen = st.selectbox("Where does this variable come from?", list(ORIGINS), index=list(ORIGINS).index(initial),
                          format_func=ORIGINS.get, key=key + "kind", disabled=not permitted)
    kind = chosen
    if chosen == "setting":
        kind = current_kind if current_kind in {"parameter", "constant"} else "parameter"
    elif chosen == "other":
        current_other = current_kind if current_kind in OTHER_KINDS else "pending_mapping"
        kind = st.selectbox("Source situation", list(OTHER_KINDS), index=list(OTHER_KINDS).index(current_other),
                            format_func=OTHER_KINDS.get, key=key + "other", disabled=not permitted)
    managed_kind = bool(kind or current_kind)
    result = {"updates": {"source.kind": kind} if managed_kind else {}, "source_link": None, "suggested_type": "",
              "type_requested": False, "managed_kind": managed_kind, "issues": []}
    if chosen == "derived":
        st.caption("Choose its inputs and calculation in the definition below.")
    elif chosen == "setting":
        st.caption("Use this product's own value below.")
    if chosen != "vendor":
        return result

    metadata = options.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not metadata.get("ok"):
        st.caption("The source list is unavailable. You can type the table and column names.")
    tables = metadata.get("tables") or []
    table_lookup = {item["alias"]: item for item in tables if isinstance(item, dict) and item.get("alias")}
    current_alias, current_stem = _text(source.get("logical_table")), _text(source.get("physical_stem"))
    alias_labels = {alias: alias + (" · " + table["physical_stem"] if table.get("physical_stem") and table["physical_stem"] != alias else "")
                    for alias, table in table_lookup.items()}
    alias = _pick("Source table", table_lookup, current_alias, key=key + "table", disabled=not permitted, labels=alias_labels)
    table = table_lookup.get(alias, {})
    stems = table.get("table_stems") or []
    if alias == current_alias and current_stem:
        stem = current_stem
    elif len(stems) == 1:
        stem = stems[0]
    else:
        stem = ""
    if len(stems) > 1 or alias and not table:
        stem = _pick("Data table name", stems, current_stem if alias == current_alias else "",
                     key=key + "physical_" + alias, disabled=not permitted)
    elif stem:
        st.caption("Table: " + stem)

    original_columns = source.get("columns") or {}
    if not isinstance(original_columns, dict) or any(not isinstance(role, str) or not isinstance(column, str)
                                                    for role, column in original_columns.items()):
        result["issues"].append("This source has an older column mapping. Edit it in Sources before replacing individual columns.")
        st.info(result["issues"][0])
        return result
    # A simple new variable gets its result role. Existing multi-role mappings
    # and family variables require the person to name which role they edit.
    complex_mapping = bool(row.get("family")) or bool(original_columns and set(original_columns) != {"value"})
    role = "value"
    columns = deepcopy(original_columns)
    if complex_mapping:
        with st.expander("Source mapping details"):
            if columns:
                st.dataframe([{"Used for": role, "Column": column} for role, column in columns.items()], hide_index=True, width="stretch")
            choices = list(dict.fromkeys([*columns, *table.get("column_roles", [])]))
            role = _pick("Which field are you linking?", choices, "", key=key + "role", disabled=not permitted)
            st.caption("Other column links and treatment-line choices are kept.")
    current_column = _text(columns.get(role))
    offered = metadata.get("columns_by_table", {}).get(stem, table.get("columns") or [])
    if metadata.get("imported_tables") and not stem:
        offered = []
    column = _pick("Source column", offered, current_column, key=key + "column_" + role,
                   disabled=not permitted or not bool(role) or bool(metadata.get("imported_tables") and not stem))
    if stem in (metadata.get("delivered_columns") or {}) and column:
        from experiments.portal.source_table_intake import COLUMN_IDENTIFIER
        if not COLUMN_IDENTIFIER.fullmatch(column):
            st.info("This is the exact uploaded header. Map it to a supported column identifier in Sources before saving an executable mapping.")
    if role:
        if column:
            columns[role] = column
        else:
            columns.pop(role, None)
    staged = {"source.logical_table": alias, "source.physical_stem": stem, "source.columns": columns}
    original = {"source.logical_table": current_alias, "source.physical_stem": current_stem,
                "source.columns": original_columns}
    if complex_mapping and original_columns and (alias, stem) != (current_alias, current_stem):
        message = "This variable uses several source fields. Change its table in Sources so every existing column link can be reviewed together."
        result["issues"].append(message)
        st.warning(message)
    elif staged != original:
        result["source_link"] = staged
    if not (alias and stem and role and column) and (alias or stem or column):
        st.caption("Choose a table and column to link them; incomplete choices can stay as a draft.")

    declared = metadata.get("column_types_by_table", {}).get(stem, {}).get(column)
    if not declared and stem == table.get("physical_stem"):
        declared = table.get("column_types", {}).get(column)
    observed = metadata.get("observed_column_types_by_table", {}).get(stem, {}).get(column)
    suggested = canonical_type(declared or observed)
    if suggested and column and role:
        result["suggested_type"] = suggested
        st.caption(("Declared source type: " if declared else "Suggested type from uploaded TSV: ") + TYPE_LABELS.get(suggested, suggested))
        binding = [alias, stem, role, column, suggested]
        requested = st.button("Apply suggested type", key=key + "apply_type", disabled=not permitted)
        if requested:
            st.session_state[key + "applied_type"] = binding
        result["type_requested"] = requested
        if requested:
            st.caption("Source type applied. You can change it below before saving.")
    return result
