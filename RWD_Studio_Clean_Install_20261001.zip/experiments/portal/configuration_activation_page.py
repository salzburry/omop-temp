"""Explicit last step from a reviewed candidate to working configuration."""
import streamlit as st
from experiments.portal import configuration_activation as activation


def render(root, pack, actor_id, *, request_id, allowed_packs, can_write, state=None):
    if state is None:
        state = activation.describe(root, pack, actor_id, request_id=request_id, allowed_packs=allowed_packs)
    if state.get('used'):
        st.success('This reviewed configuration was put into use for the product.')
        if not state['receipt']['current_files_match']:
            st.info('Some configuration files have changed since then. Open the current checks before further review.')
        st.caption(activation.NOTICE)
        return state
    if not state.get('ready'):
        for error in state.get('errors', []):
            st.info(error)
        if state.get('recovery_required'):
            if st.button('Open setup recovery', key='configuration_recovery_' + request_id):
                st.session_state.pop('connected_workflow', None)
                st.session_state['section_suggested'] = 'New product'
                st.rerun()
        return state
    st.subheader('Use the reviewed configuration')
    st.caption(activation.NOTICE)
    key = 'configuration_use_' + request_id + '_' + state['expected_digest'][:12]
    confirmed = st.checkbox('I reviewed these changes and want to use them for this product.', key=key + '_confirm')
    if not can_write:
        st.caption('A product editor must put this configuration into use.')
    if st.button('Use reviewed configuration', key=key + '_apply', disabled=not can_write or not confirmed):
        with st.spinner('Rechecking and recording the reviewed configuration…'):
            result = activation.use(root, pack, actor_id, request_id=request_id, allowed_packs=allowed_packs,
                expected_digest=state['expected_digest'], confirmed=confirmed, can_write=can_write)
        if result['ok']:
            st.rerun()
        for error in result.get('errors', []):
            st.error(error)
        for check in result.get('checks', []):
            if check.get('passed') is not True:
                st.write(check.get('validator', 'Configuration check'))
                for error in check.get('errors', []):
                    st.error(str(error))
    return state
