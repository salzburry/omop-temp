"""Prepare extraction evidence and record an explicit human AI-access decision."""
from datetime import date
from pathlib import Path

import streamlit as st

from experiments.portal import scientific_definition_source as source


_PREFIX = "definition_source_"
_CLASSES = {
    "sponsor_ai_eligible": "Sponsor AI may read this extracted material",
    "vendor_restricted": "Vendor material: AI access restricted",
    "restricted_derived": "Derived material: AI access restricted",
}
_LABELS = {
    "classified_by": "Access classifier's name",
    "classified_date": "Classification date",
    "approved_by": "Extracted material reviewer's name",
    "approval_date": "Extracted material review date",
}
_NOW = "Review now"
_HISTORICAL = "Historical or different person"


def _clear():
    for key in list(st.session_state):
        if str(key).startswith(_PREFIX):
            st.session_state.pop(key, None)


def _errors(result):
    from experiments.portal import form_assistance
    form_assistance.record_validation(result.get("errors") or [], title="Extracted specification validation", action_id="g2_draft",
        input_digest=result.get("input_digest") or "")
    for error in result.get("errors") or []:
        st.error(str(error))


def _inherited_sentence(inherited):
    """Describe only the decision actually recorded on the workbook."""
    return ("Uses the workbook's AI decision: sponsor AI eligible, classified by "
            + str(inherited.get("classified_by") or "") + " on " + str(inherited.get("classified_date") or "")
            + "; approved by " + str(inherited.get("approved_by") or "") + " on "
            + str(inherited.get("approval_date") or "") + ".")


def _unconfirm():
    st.session_state[_PREFIX + "confirmed"] = False


def _change_mode():
    _unconfirm()
    values = (st.session_state.get(_PREFIX + "snapshot") or {}).get("values") or {}
    selected = values.get("ai_classification") if st.session_state.get(_PREFIX + "mode") == _HISTORICAL else None
    st.session_state[_PREFIX + "ai_classification"] = selected if selected in _CLASSES else None


def _source_rows(rows):
    """Show source values as recorded, including rows without a variable label."""
    result = []
    for row in rows:
        fields = row.get("fields") if isinstance(row.get("fields"), dict) else {}
        result.append({"Variable": row.get("variable") or "", "Definition": fields.get("definition") or "",
                       "Values": fields.get("values") or "", "Time window": fields.get("time_period") or fields.get("time_window") or "",
                       "Notes": fields.get("notes") or "", "Sheet": row.get("tab") or row.get("domain") or "",
                       "Row": str(row.get("row") or ""), "Source text": row.get("text") or ""})
    return result


def _review_form(description, enabled, actor_name, review_date, details_holder, body_holder):
    """Display the exact proposed reviewer/date before the person confirms them."""
    values = description.get("values") or {}
    has_recorded_review = any(values.get(field) for field in _LABELS)
    with details_holder:
        mode = st.radio("Review timing", [_NOW, _HISTORICAL],
                        index=1 if has_recorded_review or not actor_name else 0,
                        key=_PREFIX + "mode", on_change=_change_mode, disabled=not enabled)
        if mode == _HISTORICAL:
            history = {}
            for field, label in _LABELS.items():
                history[field] = st.text_input(label, value=str(values.get(field) or ""), key=_PREFIX + field,
                    placeholder="YYYY-MM-DD" if field.endswith("date") else "Enter the person's actual name",
                    help="Use the person and date actually recorded for this decision.",
                    disabled=not enabled, on_change=_unconfirm)
        st.caption("Saving records the review you confirm. It does not authenticate a signature, approve scientific definitions or release a product.")
    with body_holder:
        selected = values.get("ai_classification") if mode == _HISTORICAL else None
        options = list(_CLASSES)
        classification = st.selectbox("What may AI read?", options,
            index=options.index(selected) if selected in options else None,
            format_func=lambda value: _CLASSES[value], key=_PREFIX + "ai_classification",
            disabled=not enabled, on_change=_unconfirm,
            help="Choose the decision you made after reviewing this extraction. Restricted material remains blocked for assisted drafting.")
        if mode == _NOW:
            updates = {"classified_by": actor_name, "classified_date": review_date,
                       "approved_by": actor_name, "approval_date": review_date}
            if actor_name:
                st.write(f"Reviewer and access classifier: **{actor_name}** · Date: **{review_date}**")
            else:
                st.info("Choose a profile with your name, or enter the actual reviewer and dates under Details.")
            label = "I reviewed this source and confirm this access decision, my displayed name and today's date."
        else:
            updates = history
            st.caption("The reviewer and dates entered under Details will be recorded exactly as shown.")
            label = "I reviewed this source and confirm the access decision, people and dates entered under Details."
        confirmed = st.checkbox(label, key=_PREFIX + "confirmed", disabled=not enabled)
    return {"ai_classification": classification or "", **updates}, confirmed


def render(root, pack, *, local_demo, can_write, can_review, allowed_packs=None, actor_id="", actor_name="", on_continue=None):
    """Return true after an intentional successful save; rendering never writes."""
    actor_name = actor_name.strip() if isinstance(actor_name, str) else ""
    review_date = date.today().isoformat()
    scope = None if allowed_packs is None else tuple(sorted(str(value) for value in allowed_packs))
    context = (str(Path(root).resolve()), pack, actor_id, actor_name, review_date,
               bool(can_write), bool(can_review), bool(local_demo), scope)
    previous_context = st.session_state.get(_PREFIX + "context")
    context_changed = previous_context is not None and previous_context != context
    if previous_context != context:
        _clear()
        st.session_state[_PREFIX + "context"] = context
    if _PREFIX + "snapshot" not in st.session_state:
        st.session_state[_PREFIX + "snapshot"] = source.describe(root, pack, allowed_packs=allowed_packs)
    description = st.session_state[_PREFIX + "snapshot"]
    st.write("**Source for AI-assisted definitions**")
    material = description.get("material") or {}
    st.text("Source: " + str(material.get("path_or_link") or "spec_pipeline/out/extracted.json"))
    if context_changed:
        st.info("The product or profile changed. Review the current source and confirm again before saving.")
    if not description.get("ok"):
        _errors(description)
    elif description.get("ready"):
        st.success("The extracted source meets the current drafting eligibility checks. Continue with your definition below.")
    inherited = bool(description.get("inherited_from_parent") or
                     (not description.get("registered") and description.get("inheritance_available")))
    if inherited:
        st.write(_inherited_sentence(description.get("inherited") or {}))

    preview = None
    with st.expander("Review source"):
        if st.button("Show extracted content", key=_PREFIX + "preview", disabled=not description.get("ok")):
            preview = source.preview(root, pack, expected_digest=description.get("digest"), allowed_packs=allowed_packs)
            if preview.get("ok"):
                st.dataframe(_source_rows(preview["rows"]), hide_index=True, width="stretch")
            else:
                _errors(preview)

    body_holder = st.container()
    details_holder = st.expander("Details")
    with details_holder:
        if preview and preview.get("ok"):
            st.caption("Raw extracted source")
            st.code(preview["text"], language="json")
        st.caption("Review status: " + str(material.get("status") or "pending"))
        if description.get("registration_preview"):
            st.code(description["registration_preview"], language="yaml")
        for reason in description.get("reasons") or []:
            st.write(str(reason))
        has_decision = inherited or bool(description.get("ready"))
        replace_decision = st.checkbox("Record a different decision", key=_PREFIX + "different",
                                       on_change=_unconfirm, disabled=can_review is not True) if has_decision else False
        if has_decision and description.get("values"):
            for field, label in _LABELS.items():
                if description["values"].get(field):
                    st.text(label + ": " + description["values"][field])
    needs_review = not has_decision or replace_decision
    can_prepare = local_demo is True and (description.get("registered") or can_write is True)
    enabled = bool(description.get("ok")) and can_prepare and can_review is True and not context_changed
    updates, confirmed = None, False
    if needs_review and can_review is True:
        updates, confirmed = _review_form(description, enabled, actor_name, review_date, details_holder, body_holder)
    elif needs_review:
        with body_holder:
            st.info("An authorized reviewer must confirm AI access before assisted drafting. Saving prepares the source with review pending.")
    if not description.get("registered"):
        with body_holder:
            st.caption("Saving also prepares the current extraction automatically.")
    action_enabled = bool(description.get("ok")) and can_prepare and not context_changed
    if not description.get("registered"):
        action_enabled = action_enabled and bool(description.get("registration_available"))
    if needs_review and description.get("registered") and can_review is not True:
        action_enabled = False
    with details_holder:
        if st.button("Reload extracted source status", key=_PREFIX + "reload"):
            _clear()
            st.rerun()
    label = ("Continue" if description.get("registered") and not needs_review else
             "Prepare source" if needs_review and can_review is not True else "Save and continue")
    if st.button(label, key=_PREFIX + "save", type="primary", disabled=not action_enabled) and action_enabled:
        if updates is not None and (not confirmed or any(not value.strip() for value in updates.values())):
            _errors({"errors": ["Choose an access decision, complete the reviewer details and confirm the review before saving."]})
            return False
        current = description
        if current.get("registered") and updates is None:
            current = source.describe(root, pack, allowed_packs=allowed_packs)
            if not current.get("ok"):
                _errors(current)
                return False
            if current.get("digest") != description.get("digest"):
                _errors({"errors": ["The source or extraction changed. Reload under Details and review the current version before continuing."]})
                return False
            if not current.get("ready"):
                _errors({"errors": current.get("reasons") or ["The current source still needs attention. Check Details before continuing."]})
                return False
            st.info("The current source is already prepared. Continue with the scientific definition.")
            if callable(on_continue):
                on_continue()
            return False
        if not current.get("registered"):
            current = source.register(root, pack, expected_digest=description["digest"],
                local_demo=local_demo, can_write=can_write, allowed_packs=allowed_packs)
            if not current.get("ok"):
                _errors(current)
                return False
            # Registration changes source_refs.yaml. Use only its new snapshot for
            # the second guarded write; the original digest cannot authorize it.
            st.session_state[_PREFIX + "snapshot"] = current
        if updates is not None:
            result = source.record_review(root, pack, updates, expected_digest=current["digest"], confirmed=confirmed,
                local_demo=local_demo, can_review=can_review, allowed_packs=allowed_packs)
            if not result.get("ok"):
                _errors(result)
                return False
            current = result
        _clear()
        if current.get("ready"):
            st.success("Source saved. Continue with the scientific definition.")
        elif updates is not None:
            st.success("Source review recorded. Check the remaining drafting requirements under Details.")
        else:
            st.success("Source prepared. Review is still pending; an authorized reviewer must confirm AI access.")
        return True
    return False
