"""Local approval-event signing with an explicitly selected registered key."""
from pathlib import Path

import streamlit as st

from experiments.portal import approval_attestation as backend
from experiments.portal import handoffs
from experiments.portal import authoring_session

PREFIX = "approval_attestation_"


def render(root, pack, actor_id, *, local_demo, can_review, can_view, allowed_packs=None):
    authority = authoring_session.CURRENT.get()
    local_session = bool(authority and authority.mode in {"local", "demo"})
    context = (str(Path(root).resolve()), pack, actor_id, local_demo, can_review, can_view,
               authority.mode if authority else None, tuple(sorted(authority.permissions)) if authority else (),
               tuple(sorted(allowed_packs or [])))
    if st.session_state.get(PREFIX + "context") != context:
        for key in list(st.session_state):
            if key.startswith(PREFIX):
                del st.session_state[key]
        st.session_state[PREFIX + "context"] = context
    st.write("**Sign the recorded approval event**")
    st.caption(backend.NOTICE)
    st.info(backend.identity.IDENTITY_EVIDENCE_REQUIRED)
    if not can_view:
        st.warning("You no longer have access to this product's approval event.")
        return False
    report = backend.describe(root, pack, actor_id, allowed_packs=allowed_packs)
    if not report["ok"]:
        for error in report["errors"]:
            st.error(error)
        return False
    st.write("Approved build: " + (report["approval"]["approved_build_id"] or "Not recorded"))
    st.write("Named release approver: " + (report["approval"]["approved_by"] or "Not recorded"))
    with st.expander("Exact approval event being signed"):
        st.write("Event digest: " + (report["event_sha256"] or "No sealed event"))
        st.write("Approved candidate digest: " + (report["approval"]["approved_manifest_sha256"] or "Not recorded"))
    for finding in report["findings"]:
        st.warning(finding)
    if report["trust"] == "authenticated":
        st.success("The existing approval event has a verified registered-key signature.")
    if not report["keys"]:
        st.info("No active release-signing key is registered. Its owner or Administrator must add the public Ed25519 key, key ID, named person, registration details and active status to governance/SIGNING_KEYS.yaml. The private key stays with its owner.")
        if st.button("Ask Administrator to register a review key", key=PREFIX + "key_handoff",
                     disabled=not (local_demo and can_review)):
            try:
                doc = handoffs.create(root, pack, title="Register a release approval signing key", owner="Administrator",
                    note="Please arrange the reviewer's explicit public-key registration in governance/SIGNING_KEYS.yaml, using the existing Ed25519 ledger key format. The private key must remain outside the checkout. No approval or publication is requested by registering the key.",
                    requested_by=actor_id, action_id="register_release_signing_key", allowed_packs=allowed_packs,
                    local_demo=local_demo, can_view=can_view)
                st.success("Key registration requested from Administrator. Return to this step after the public key is registered.")
                st.caption("Tracked handoff: " + doc["id"])
                return True
            except (handoffs.Refused, OSError, ValueError) as error:
                st.error(str(error))
        return False
    if not local_session:
        st.info("Sign this approval event in your own local checkout. The hosted portal never reads your private key.")
        with st.expander("Personal approval-event signing command"):
            st.write("On your computer, open the checkout containing these exact approval records and inspect the "
                     "sealed event digest shown above. Replace the two placeholders with your registered key ID "
                     "and private-key file outside that checkout, then run this command in PowerShell or a POSIX shell.")
            st.code("python -m rwd_tools.approval_record --root . --countersign '" + pack
                    + "' --form release --key-id '<registered-key-id>' "
                      "--private-key '<private-key-file-outside-your-checkout>'", language=None)
            st.caption("Bring the signed public event and updated checkpoint back through your reviewed Git workflow, "
                       "then check this event again. Do not copy the private key to the hosted installation.")
        return False
    keys = {item["key_id"]: item for item in report["keys"]}
    editable = backend.local_signing_allowed(root, pack, actor_id, authoring_enabled=local_demo, can_review=can_review)
    selected = st.selectbox("Your registered signing key", list(keys), index=None, key=PREFIX + "key",
        format_func=lambda key: f"{key} · {keys[key]['person']}", placeholder="Choose your own registered key", disabled=not editable)
    path = st.text_input("Private-key file on this computer", key=PREFIX + "path",
        disabled=not editable,
        help="Canonical ledger format: 32 raw bytes or 64 hex characters. This is separate from the SSH key used for Git review history. Keep it outside the checkout; it is read only when you explicitly sign.")
    st.caption("Only the file path is entered here. No private key is uploaded, saved in product records or displayed.")
    previous = st.session_state.get(PREFIX + "basis")
    basis = (report["digest"], selected, path)
    if previous is not None and previous != basis:
        st.session_state[PREFIX + "confirm"] = False
        if previous[0] != report["digest"]:
            st.warning("The evidence changed. Review the current event before confirming its signature.")
    st.session_state[PREFIX + "basis"] = basis
    name = keys[selected]["person"] if selected else "the registered key owner"
    confirmed = st.checkbox(f"I am {name}. I reviewed this exact approval event and this signature is mine.", key=PREFIX + "confirm", disabled=not editable)
    if not editable:
        st.info("A reviewer can sign this approval event. Your current role can inspect its evidence.")
    if st.button("Sign this approval event", key=PREFIX + "sign", disabled=not (
            editable and selected and path.strip() and confirmed and not report["findings"])):
        result = backend.attest(root, pack, actor_id, expected_digest=report["digest"], key_id=selected,
            private_key_path=path, confirmed=confirmed, local_demo=local_demo, can_review=can_review,
            allowed_packs=allowed_packs)
        if not result["ok"]:
            for error in result["errors"]:
                st.error(error)
            return False
        if result.get("warning"):
            st.warning(result["warning"])
        elif not result["changed"]:
            st.info("This key already signed the exact approval event. No additional signature was recorded. Independent reviewer identity evidence is still required.")
        else:
            st.success("Approval-event signature recorded and verified. No build was published.")
        return bool(result["changed"])
    return False
