"""Read the authorized products that saved an exact master-version link.

Usage is draft history, not an equivalence guess or an approval. The scan never
follows a lineage's origin paths: those records are compared by validated digest.
"""
from __future__ import annotations

from pathlib import Path

import yaml

from experiments.portal import portal_packs
from rwd_tools import product_gates
from experiments.portal import scientific_definitions as definitions
from experiments.portal import variable_review_lineage as lineage
from experiments.portal import variable_review_workflow as workflow

MAX_PRODUCTS = 500
_READ_ERRORS = (ValueError, TypeError, KeyError, AttributeError, OSError,
                RecursionError, yaml.YAMLError, definitions.dw._DraftError)


def _empty(*, ok=True):
    return {"ok": ok, "rows": [], "warnings": [], "errors": [], "count": 0,
            "scanned": 0, "truncated": False, "draft_only": True,
            "approval_created": False}


def _name(value):
    return str(value).replace("\\", "/").strip("/")


def _registered_version(entry, pack):
    if not isinstance(entry, dict):
        return False
    cut = pack.rsplit("/", 1)[-1]
    versions = {str(entry.get("current_spec_version") or "")}
    versions.update(str(item.get("spec_version") or "")
                    for item in entry.get("lineage") or entry.get("versions") or [] if isinstance(item, dict))
    return cut in versions


def _relationship(link, target):
    if lineage.validate(link):
        return None
    depth = 0
    while link is not None:
        if link["content_digest"] == target:
            return "direct" if depth == 0 else "inherited"
        ancestry = link["lineage"]
        link = ancestry["parent"] if ancestry else None
        depth += 1
    return None


def _identifiers(product):
    """Only the current extraction supplies a fallback label for a saved row."""
    path = definitions._safe(product / "spec_pipeline/out/extracted.json")
    if not path.exists():
        return {}
    data = definitions._json(definitions._read(path))
    if not isinstance(data, dict) or not isinstance(data.get("rows"), list):
        raise ValueError("The specification extraction cannot supply row names.")
    return {definitions.row_item_id(row): str(row.get("variable") or "")
            for row in definitions.requirement_rows(data)}


def describe(root, pack, actor_id, *, item_id, allowed_packs=None):
    """Find direct and inherited uses of the selected row's saved master link.

    Only registered product packs in the caller's access scope are opened.
    Missing historic links are reported as untracked, never reconstructed from
    today's master name. A bounded scan reports its own incompleteness.
    """
    result = _empty()
    try:
        root = Path(root).resolve()
        _product, pack, _owner, _folder = definitions._scope(root, pack, actor_id, allowed_packs)
        report = workflow.describe(root, pack, actor_id, allowed_packs=allowed_packs)
        if not report.get("ok"):
            result.update(ok=False, errors=["Open a valid variable review before checking where its master is used."])
            return result
        row = next((row for row in report.get("rows", []) if row.get("item_id") == item_id), None)
        if row is None:
            result.update(ok=False, errors=["Select a variable from the current product before checking usage."])
            return result
        target = row.get("master_link")
        if target is None:
            result["warnings"].append("This variable has no saved master-version link. Older choices cannot be traced by name alone.")
            return result
        if lineage.validate(target):
            result.update(ok=False, errors=["The selected variable's saved master link is invalid. Repair its recorded history before checking usage."])
            return result
        # Catalogue discovery and registry lookup may read these shared paths.
        # Refuse redirected roots/files before invoking either reader.
        for namespace in ("products", "fixtures"):
            definitions._safe(root / namespace)
            definitions._safe(root / namespace / "registry.yaml")
        catalogue = portal_packs.catalogue(str(root))
        access = None if allowed_packs is None else {_name(value).casefold() for value in allowed_packs}
        candidates = {_name(value) for value in [*catalogue.get("products", []), *catalogue.get("superseded", [])]
                      if isinstance(value, str) and _name(value).startswith("products/")}
        if access is not None:
            candidates = {value for value in candidates if value.casefold() in access}
        # Always inspect the selected product first when it belongs to the
        # registered product catalogue, including when the scan is truncated.
        candidates = sorted(candidates, key=lambda value: (value.casefold() != pack.casefold(), value.casefold()))
        if len(candidates) > MAX_PRODUCTS:
            result["truncated"] = True
            result["warnings"].append(f"Usage is incomplete: only the first {MAX_PRODUCTS} accessible products were checked.")
        skipped = legacy = stale = unnamed = 0
        current_names = {item["item_id"]: item.get("variable_id", "") for item in report.get("rows", [])}
        for candidate in candidates[:MAX_PRODUCTS]:
            try:
                product, canonical, _owner, _folder = definitions._scope(root, candidate, actor_id, allowed_packs)
                if not _registered_version(product_gates.registry_entry(str(root), canonical), canonical):
                    continue
                result["scanned"] += 1
                path = definitions._safe(product / workflow.STORE)
                if not path.exists():
                    continue
                digest = workflow._input_digest(root, product)
                state, _state_digest = workflow._load(path, canonical, digest)
                stale += state["input_digest"] != digest
                matches = []
                for saved_id, saved in state["rows"].items():
                    link = saved.get("master_link")
                    if link is None:
                        legacy += bool(saved.get("updates", {}).get("master_name"))
                        continue
                    relationship = _relationship(link, target["content_digest"])
                    if relationship:
                        matches.append((saved_id, saved, link, relationship))
                names = current_names if canonical.casefold() == pack.casefold() else _identifiers(product) if matches else {}
                for saved_id, saved, link, relationship in matches:
                    variable = saved.get("updates", {}).get("variable_id") or names.get(saved_id) or ""
                    if not isinstance(variable, str) or not variable:
                        variable = saved_id
                        unnamed += 1
                    result["rows"].append({"pack": canonical, "variable_id": variable, "item_id": saved_id,
                        "relationship": relationship, "master_name": link["master_name"],
                        "version": link["declared_version"] or link["content_digest"][:12]})
            except _READ_ERRORS:
                # Never echo paths, names, identifiers or parser messages from
                # failed candidates, including access failures or symlinks.
                skipped += 1
        if skipped:
            result["warnings"].append("Some accessible product histories could not be checked. The usage list may be incomplete.")
        if legacy:
            result["warnings"].append("Older saved choices without master-version links are not included; matching names do not establish shared history.")
        if stale:
            result["warnings"].append("Some saved histories refer to changed product inputs. Usage shows recorded links and does not establish current review approval.")
        if unnamed:
            result["warnings"].append("Some recorded links no longer have a current variable name; their specification row identifiers are shown.")
        result["rows"].sort(key=lambda item: (item["pack"].casefold() != pack.casefold(), item["pack"].casefold(), item["variable_id"].casefold(), item["item_id"]))
        result["count"] = len(result["rows"])
        return result
    except _READ_ERRORS:
        result.update(ok=False, errors=["Usage could not be checked within the current product access. No files were changed."])
        return result
