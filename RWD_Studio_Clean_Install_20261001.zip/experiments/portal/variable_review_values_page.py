"""Structured, explicitly confirmed interpretation of the current Values cell."""
from __future__ import annotations

from copy import deepcopy
from datetime import date
import hashlib
import json

import pandas as pd
import streamlit as st

from rwd_tools import spec_value_interpretation as interpretation
from experiments.portal import form_assistance as form_help
from experiments.portal import ui_text
from experiments.portal.variable_review_consistency import canonical_type

KINDS = {"unknown": "Choose what these values describe", "bands": "Numeric bands / age groups",
         "flag": "Flag / yes-no choices", "ordinal": "Ordered levels", "codes": "Allowed codes",
         "continuous": "Continuous value with units", "date": "Date", "text": "Text"}
FORMATS = {"unknown": "Choose a type", "categorical": "Categories", "continuous": "Number",
           "date": "Date", "flag": "Yes or no", "text": "Text"}
CATEGORIES = {"codes": "Names or codes", "bands": "Number ranges", "ordinal": "Ordered values"}
TYPES = {"string": "Text / category", "integer": "Whole number", "long": "Large whole number",
         "double": "Decimal number", "boolean": "True / false", "date": "Date", "timestamp": "Date and time"}
FLAG_PRESETS = {
    "yes_no": ("Yes / No", "string", [{"code": "Yes", "label": "Yes"}, {"code": "No", "label": "No"}]),
    "one_zero": ("1 = Yes, 0 = No", "integer", [{"code": 1, "label": "Yes"}, {"code": 0, "label": "No"}]),
    "boolean": ("True / False", "boolean", [{"code": True, "label": "True"}, {"code": False, "label": "False"}]),
}
MANAGED = {"output.type", "output.codes", "units", "output.nullable"}
_UNSET = object()


def current_value(row):
    """Return editable answers, keeping manual defaults out of source evidence."""
    saved = row.get("value_interpretation")
    if saved and not row.get("value_interpretation_issues"):
        return deepcopy(saved.get("value") or {"kind": "unknown"})
    proposal = row.get("value_proposal") or {}
    if str(proposal.get("raw") or "").strip():
        value = deepcopy(proposal.get("value") or {"kind": "unknown"})
        nullable = ((row.get("values") or {}).get("output") or {}).get("nullable")
        if row.get("value_interpretation_issues") and type(nullable) is bool:
            value["missing_allowed"] = nullable
        return value
    values = row.get("values") or {}
    output = values.get("output") or {}
    declared = output.get("type")
    datatype = declared if declared in TYPES else canonical_type(declared)
    codes = output.get("codes")
    # Existing explicit codes are answers, not a reason to infer an algorithm,
    # threshold or yes/no meaning merely from their count.
    if isinstance(codes, list) and codes:
        code_rows = [deepcopy(item) if isinstance(item, dict) else {"code": item, "label": str(item)} for item in codes]
        kind = "flag" if datatype == "boolean" else "codes"
        value = {"kind": kind, "data_type": datatype or "string", "codes": code_rows}
    else:
        kind = {"string": "text", "integer": "continuous", "long": "continuous", "double": "continuous",
                "boolean": "flag", "date": "date", "timestamp": "date"}.get(datatype, "unknown")
        value = {"kind": kind, "data_type": datatype or "string"}
        if kind == "flag":
            value["codes"] = [{"code": True, "label": "True"}, {"code": False, "label": "False"}]
    if value["kind"] == "continuous" and isinstance(values.get("units"), str):
        value["unit"] = values["units"]
    if type(output.get("nullable")) is bool:
        value["missing_allowed"] = output["nullable"]
    return value


def _token(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()[:16]


def _editing_value(current, previous_edit, kind):
    """Keep each type's unfinished answers when the researcher explores types."""
    previous_value = previous_edit.get("value") or {}
    previous_kind = previous_value.get("kind")
    drafts = deepcopy(previous_edit.get("drafts") or {})
    if previous_kind:
        drafts[previous_kind] = deepcopy(previous_value)
    revision = previous_edit.get("revision", 0) + int(bool(previous_kind and previous_kind != kind))
    compatible_codes = {"flag", "codes", "ordinal"}
    if previous_kind == kind or previous_kind in compatible_codes and kind in compatible_codes:
        value = {**deepcopy(previous_value), "kind": kind}
    elif kind in drafts:
        value = deepcopy(drafts[kind])
    else:
        value = deepcopy(current) if current.get("kind") == kind else {"kind": kind}
    return value, revision, drafts


def _table_records(table):
    # Pandas can use NaN for a blank numeric cell; the review store accepts
    # explicit JSON nulls, never non-finite numbers.
    return json.loads(table.to_json(orient="records")) if isinstance(table, pd.DataFrame) else table


def _table_basis(key, rows):
    # Streamlit forbids assigning data-editor widget state. Keep editable rows
    # separately, and reconstruct the input only when the widget remounts.
    # While mounted, preserve its original input so its row diffs apply once.
    if key + "_table_widget" not in st.session_state or key + "_table_basis" not in st.session_state:
        st.session_state[key + "_table_basis"] = deepcopy(st.session_state.get(key + "_table_current", rows))
    return deepcopy(st.session_state[key + "_table_basis"])


def _table_saved(key, table, *, assist=None, disabled=False):
    records = _table_records(table)
    st.session_state[key + "_table_current"] = deepcopy(records)
    if assist:
        def remount():
            st.session_state.pop(key + '_table_widget', None)
            st.session_state.pop(key + '_table_basis', None)
        form_help.table(assist[0], key=key + '_table_current', value=records,
                        columns=assist[1], binding=key, on_change=remount, disabled=disabled)
    return records


def _bands(value, key, disabled):
    columns = ["label", "lower", "upper", "lower_inclusive", "upper_inclusive"]
    rows = value.get("bands") or [{"label": "", "lower": None, "upper": None,
                                     "lower_inclusive": False, "upper_inclusive": False}]
    table_key = key + "bands"
    frame = pd.DataFrame(_table_basis(table_key, rows), columns=columns)
    for name in ("lower", "upper"):
        frame[name] = pd.to_numeric(frame[name], errors="coerce").astype("float64")
    for name in ("lower_inclusive", "upper_inclusive"):
        frame[name] = frame[name].fillna(False).astype(bool)
    st.caption("Name each group and set its limits. Leave From or To empty for no limit. Tick Include to keep that boundary in the group.")
    return _table_saved(table_key, st.data_editor(frame, num_rows="dynamic", hide_index=True, width="stretch",
        disabled=disabled, key=table_key + "_table_widget", column_config={
            "label": st.column_config.TextColumn("Group name", required=True),
            "lower": st.column_config.NumberColumn("From"),
            "upper": st.column_config.NumberColumn("To"),
            "lower_inclusive": st.column_config.CheckboxColumn("Include From"),
            "upper_inclusive": st.column_config.CheckboxColumn("Include To")}), disabled=disabled,
        assist=('Category ranges', {'label': 'text', 'lower': 'number', 'upper': 'number',
                                   'lower_inclusive': 'boolean', 'upper_inclusive': 'boolean'}))


def _codes(value, key, disabled):
    original = value.get("codes") or []
    rows = [{"include": True, "code": str(item.get("code", "")), "label": str(item.get("label", ""))}
            for item in original]
    if not rows:
        rows = [{"include": True, "code": "", "label": ""}]
    st.caption("Keep the choices you need. Untick a row to remove it, or add a row for a new choice.")
    table_key = key + "codes"
    edited = st.data_editor(pd.DataFrame(_table_basis(table_key, rows)), num_rows="dynamic", hide_index=True, width="stretch",
        disabled=disabled, key=table_key + "_table_widget", column_config={
            "include": st.column_config.CheckboxColumn("Use", default=True),
            "code": st.column_config.TextColumn("Code", required=True),
            "label": st.column_config.TextColumn("Meaning", required=True)})
    result = []
    for item in _table_saved(table_key, edited, disabled=disabled,
            assist=('Allowed codes and meanings', {'include': 'boolean', 'code': 'text', 'label': 'text'})):
        if item.get("include") is not False:
            code = str(item.get("code") or "")
            if value.get("data_type") in {"integer", "long", "double", "boolean"}:
                try:
                    if value["data_type"] == "boolean":
                        code = {"true": True, "false": False}.get(code.casefold(), code)
                    else:
                        code = float(code) if value["data_type"] == "double" else int(code)
                except ValueError:
                    pass  # Validation displays the problem without discarding the edit.
            result.append({"code": code, "label": str(item.get("label") or code)})
    return result


def render_source_details(row, *, proposal=None, saved=None, model_suggestion=None):
    """Keep original evidence and saved review history in one optional place."""
    proposal = proposal or row.get("value_proposal") or {}
    saved = saved or row.get("value_interpretation")
    with st.expander("Original source and review history", expanded=False):
        citation = proposal.get("citation") or {}
        source = " · ".join(str(citation[name]) for name in ("sheet", "tab", "cell", "item_id") if citation.get(name))
        st.caption("Source: " + (source or str(row.get("item_id", ""))))
        if row.get("definition"):
            st.text("Specification wording: " + ui_text.display_line_breaks(row["definition"]))
        spec_values = row.get("spec_values") or {}
        if isinstance(spec_values, dict):
            original_values = "\n".join(f"{name} = {value}" for name, value in spec_values.items()
                if str(name).strip().lower().replace("_", " ") in
                {"value", "values", "codes", "allowed values", "time period"} and value not in (None, ""))
        else:
            original_values = str(spec_values)
        if original_values:
            st.text("Current specification values / codes: " + ui_text.display_line_breaks(original_values))
        if saved:
            confirmation = saved.get("confirmation") or {}
            st.caption("Last saved by " + str(confirmation.get("actor_id", "reviewer")) + " · " + str(confirmation.get("at", "")))
        origin = (saved if saved and not model_suggestion else proposal).get("origin") or {}
        if origin.get("kind") == "model":
            st.caption("Suggested by " + " · ".join(str(origin.get(name, "")) for name in ("provider", "model", "version")))
        elif proposal and not str(proposal.get("raw") or "").strip():
            st.caption("The workbook does not declare Values for this row. Type and value choices are entered during review; no source text is inferred.")
        elif proposal:
            st.caption("Initial choices came from the workbook's Values text. Saving keeps that original text unchanged.")
        findings = (row.get("phase_issues") or {}).get("science", row.get("issues") or [])
        if findings:
            st.caption("Findings from the last saved scientific review; saving rechecks the edited answers.")
            for finding in findings:
                st.caption(str(finding.get("message", finding)) if isinstance(finding, dict) else str(finding))


def render(row, *, key, permitted, root=None, pack=None, actor_id=None, report=None, allowed_packs=None, local_demo=False, requested_type=None, requested_missingness=_UNSET, requested_value=None, on_discard_suggestion=None):
    """Show the relevant editor immediately; the parent's Save confirms it."""
    proposal = row.get("value_proposal")
    if row.get("value_proposal_error"):
        st.warning(row["value_proposal_error"])
    for issue in row.get("value_interpretation_issues") or []:
        st.warning("Review these values again: " + str(issue))
    if not proposal:
        return None
    base_proposal = proposal
    model_suggestion = st.session_state.get(key + "model_suggestion")
    if model_suggestion:
        proposal = model_suggestion["value_proposal"]
    saved = row.get("value_interpretation")
    current = deepcopy(proposal.get("value") or {"kind": "unknown"}) if model_suggestion else current_value(row)
    if requested_value is not None:
        # A calculation adoption remounts these existing controls. This is an
        # unsaved seed, never a fabricated reviewed interpretation or source.
        current = deepcopy(requested_value)
    manual = not str(base_proposal.get("raw") or "").strip()
    if manual:
        st.caption("No values were specified in Excel. Choose the type and any allowed values here; they will be saved as your review choices.")
    else:
        st.text("Workbook values: " + ui_text.display_line_breaks(proposal.get("raw", "")))
    draft_key = key + _token(proposal.get("proposal_digest")) + "_"
    if requested_missingness is not _UNSET:
        # The parent supplies this only when the owner of the mapping changes.
        # Retain it until a format exposes the missingness control.
        st.session_state[draft_key + "pending_missingness"] = {"value": requested_missingness}
    current_kind = current.get("kind", "unknown")
    initial_format = "categorical" if current_kind in CATEGORIES else current_kind
    if initial_format not in FORMATS:
        initial_format = "unknown"
    requested_format = {"string": "text", "integer": "continuous", "long": "continuous",
                        "double": "continuous", "boolean": "flag", "date": "date", "timestamp": "date"}.get(requested_type)
    current_format = st.session_state.get(draft_key + "kind", initial_format)
    compatible_formats = {"string": {"text", "categorical", "flag"},
                          "integer": {"continuous", "categorical", "flag"},
                          "long": {"continuous", "categorical"}, "double": {"continuous", "categorical"},
                          "boolean": {"flag"}, "date": {"date"}, "timestamp": {"date"}}
    if current_format in compatible_formats.get(requested_type, set()):
        # A text column may contain named categories, and integers may be
        # ordered codes. A storage hint must not erase those reviewed meanings.
        requested_format = current_format
    if requested_format:
        st.session_state[draft_key + "kind"] = requested_format
    st.session_state.setdefault(draft_key + "kind", initial_format)
    mode = form_help.field(st.selectbox, "Type of value", list(FORMATS), index=0,
        format_func=FORMATS.get, key=draft_key + "kind", disabled=not permitted)
    kind = mode
    if mode == "categorical":
        st.session_state.setdefault(draft_key + "categories",
            current_kind if current_kind in CATEGORIES else next(iter(CATEGORIES)))
        kind = form_help.field(st.radio, "How are the groups defined?", list(CATEGORIES),
            index=0,
            format_func=CATEGORIES.get, key=draft_key + "categories", horizontal=True, disabled=not permitted)
    previous_edit = st.session_state.get(draft_key + "edit_state") or {}
    value, revision, type_drafts = _editing_value(current, previous_edit, kind)
    # A compatible format switch starts a fresh grid with the currently edited
    # codes. Old widget row-diffs must not be replayed on that new starting list.
    editing_key = draft_key + kind + "_" + (f"edit{revision}_" if revision else "")
    flag_pending = False
    has_flag_codes = any(item.get("code") is not None and str(item["code"]).strip()
                         for item in value.get("codes") or []) if kind == "flag" else False
    if kind == "flag" and has_flag_codes:
        # A preset is a one-time choice. If the user later removes every code,
        # do not silently repopulate them from a hidden selector's old value.
        st.session_state.pop(editing_key + "flag_preset", None)
    if kind == "flag" and not has_flag_codes:
        preset = form_help.field(st.selectbox, "How should yes/no answers be recorded?",
            ["", *FLAG_PRESETS, "custom"], key=editing_key + "flag_preset", disabled=not permitted,
            format_func=lambda choice: FLAG_PRESETS[choice][0] if choice in FLAG_PRESETS else
                "Enter my own choices" if choice == "custom" else "Choose an answer format")
        flag_pending = not preset
        if preset in FLAG_PRESETS:
            _, datatype, codes = FLAG_PRESETS[preset]
            value.update(data_type=datatype, codes=deepcopy(codes))
            st.session_state[editing_key + "type"] = datatype
            for suffix in ("_table_widget", "_table_basis", "_table_current"):
                st.session_state.pop(editing_key + "codes" + suffix, None)
        elif flag_pending:
            st.info("Choose how to record yes/no answers, or enter your own choices.")
    default_type = value.get("data_type") or {"bands": "string", "codes": "string", "flag": "string",
        "ordinal": "integer", "continuous": "double", "date": "date", "text": "string"}.get(kind, "string")
    type_options = {"bands": ["string"], "text": ["string"], "date": ["date", "timestamp"],
        "continuous": ["double", "integer", "long"], "codes": ["string", "integer", "long", "double"],
        "ordinal": ["string", "integer", "long", "double"], "flag": ["string", "boolean", "integer"]}.get(kind, ["string"])
    value["data_type"] = default_type if default_type in type_options else type_options[0]
    if requested_type in type_options:
        value["data_type"] = requested_type
        st.session_state[editing_key + "type"] = requested_type
    st.session_state.setdefault(editing_key + "type", value["data_type"])
    with st.expander("Storage details", expanded=False):
        st.caption("The usual storage type is already selected. Change it only when a specific encoding is required.")
        value["data_type"] = form_help.field(st.selectbox, "Storage type", type_options,
            index=0, format_func=TYPES.get,
            key=editing_key + "type", disabled=not permitted or len(type_options) == 1)
    if kind == "bands":
        value["bands"] = _bands(value, editing_key, not permitted)
    elif kind in {"flag", "ordinal", "codes"} and not flag_pending:
        value["codes"] = _codes(value, editing_key, not permitted)
    elif kind == "continuous":
        options = ["", "%", "Months", "Days", "Years", "mg/day", "mg", "kg", "Other unit"]
        current_unit = value.get("unit", "")
        st.session_state.setdefault(editing_key + "unit_choice",
            current_unit if current_unit in options else "Other unit")
        selected = form_help.field(st.selectbox, "Unit", options, index=0,
            key=editing_key + "unit_choice", disabled=not permitted,
            format_func=lambda unit: unit or "No unit stated")
        value["unit"] = form_help.field(st.text_input, "Other unit", value=current_unit if current_unit not in options else "",
            key=editing_key + "unit_custom", disabled=not permitted) if selected == "Other unit" else selected
        left, right = st.columns(2)
        value["minimum"] = form_help.field(left.number_input, "Smallest allowed value (optional)", value=value.get("minimum"),
            key=editing_key + "minimum", disabled=not permitted)
        value["maximum"] = form_help.field(right.number_input, "Largest allowed value (optional)", value=value.get("maximum"),
            key=editing_key + "maximum", disabled=not permitted)
    elif kind == "date":
        specific = st.checkbox("Use one fixed date", value=bool(value.get("literal")),
            key=editing_key + "specific_date", disabled=not permitted)
        if specific:
            chosen_date = st.date_input("Date", value=date.fromisoformat(value["literal"]) if value.get("literal") else None,
                key=editing_key + "literal", disabled=not permitted)
            value["literal"] = chosen_date.isoformat() if chosen_date else ""
            st.caption("A fixed date is applied only to a Product setting or Fixed value variable.")
        else:
            value.pop("literal", None)
            source_kind = (row.get("values", {}).get("source") or {}).get("kind")
            if source_kind in {"parameter", "constant"}:
                st.caption("Saving clears this product's fixed date. Change the variable kind if the date should come from data instead.")
            else:
                st.caption("Each record can have its own date. Connect its source during source review.")
    elif kind == "text":
        st.caption("Any text is allowed. There is no fixed list of categories.")
    if kind != "unknown":
        pending_missing = st.session_state.pop(draft_key + "pending_missingness", None)
        if pending_missing is not None:
            requested = pending_missing["value"]
            st.session_state[editing_key + "missing"] = ("allowed" if requested is True else
                                                          "not_allowed" if requested is False else "unspecified")
        st.session_state.setdefault(editing_key + "missing", "allowed" if value.get("missing_allowed") is True
            else "not_allowed" if value.get("missing_allowed") is False else "unspecified")
        nullable = form_help.field(st.selectbox, "Can it be blank?", ["unspecified", "allowed", "not_allowed"],
            index=0,
            format_func=lambda item: {"unspecified": "Not decided — keep the current answer", "allowed": "Yes", "not_allowed": "No"}[item],
            key=editing_key + "missing", disabled=not permitted)
        value["missing_allowed"] = {"unspecified": None, "allowed": True, "not_allowed": False}[nullable]
    type_drafts[kind] = deepcopy(value)
    st.session_state[draft_key + "edit_state"] = {
        "value": deepcopy(value), "revision": revision, "drafts": type_drafts}
    active = not (manual and kind == "unknown")
    issues = ["Choose how yes/no answers should be recorded."] if flag_pending else interpretation.validate(value) if active else []
    for issue in issues if not flag_pending else []:
        st.warning(issue)
    fields = interpretation.fields_for_value(value) if active and not issues else {}
    if not manual and base_proposal.get("value", {}).get("kind") == "unknown" and root is not None:
        if st.button("Help choose the type", key=key + "suggest", disabled=not permitted):
            from experiments.portal import variable_review_values_ai
            with st.spinner("Reading the workbook values…"):
                result = variable_review_values_ai.suggest(root, pack, actor_id, row["item_id"],
                    expected_input_digest=report["input_digest"], expected_state_digest=report["state_digest"],
                    allowed_packs=allowed_packs, local_demo=local_demo, can_write=permitted)
            if result.get("ok"):
                st.session_state[key + "model_suggestion"] = result
                st.rerun()
            for error in result.get("errors") or []:
                st.error(str(error))
    if model_suggestion and st.button("Discard suggestion", key=key + "discard", disabled=not permitted):
        st.session_state.pop(key + "model_suggestion", None)
        if on_discard_suggestion:
            on_discard_suggestion()
        st.rerun()
    render_source_details(row, proposal=proposal, saved=saved, model_suggestion=model_suggestion)
    return {"active": active, "mode": mode, "value": value, "fields": fields, "confirmed": active and not issues, "issues": issues,
            "model_proposal": model_suggestion.get("proposal") if model_suggestion else None}
