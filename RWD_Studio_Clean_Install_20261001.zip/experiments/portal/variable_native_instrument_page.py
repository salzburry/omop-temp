"""Guided fields for native instruments; no code/JSON authoring and no defaults."""
from copy import deepcopy
import streamlit as st
from experiments.portal import variable_review_controls as controls
from experiments.portal import variable_native_instruments as native

ENUMS = {
    "series_scope": ("from_index", "full_history"), "reference": ("nadir", "baseline"),
    "direction": ("rise", "fall"), "event_date": ("first_qualifying", "confirming"),
    "same_day": ("lowest_first", "highest_first"), "mode": ("abstracted", "sessionised"),
    "reduce": ("sum", "first", "last"),
    "relation": ("overlaps_within", "starts_after_within", "precedes"),
}
NUMBERS = {"threshold_pct", "threshold_abs", "confirm_after_days", "gap_days", "window_days_before", "window_days_after", "window_days"}


def calculation_timeline(item):
    """Accessible schematic from validated choices, never hypothetical patient dates."""
    from html import escape
    from engine.stages.record_calculations import instrument_errors
    from engine.record_windows import parse_window
    if instrument_errors(item):
        return None
    height = 105
    if "window" in item:
        w = parse_window(item["window"], allow_named_anchor=True)
        values = [v for v in (w.start, w.end, 0) if v is not None]
        low, high = min(values), max(values)
        span = max(high - low, 1)
        at = lambda n: 65 + 470 * (n - low) / span
        left, right = (at(w.start) if w.start is not None else 30), (at(w.end) if w.end is not None else 570)
        anchor = at(0)
        lower = "any earlier day" if w.start is None else f"day {w.start:+d} ({'included' if w.include_start else 'excluded'})"
        upper = "any later day" if w.end is None else f"day {w.end:+d} ({'included' if w.include_end else 'excluded'})"
        summary = f"Relative to {w.anchor}: {lower} to {upper}. Select {item['select']}. Ties: {item['tie_break']['date']} date, then {item['tie_break']['value']} value."
        marks = f'<line x1="{left}" y1="48" x2="{right}" y2="48" stroke="#075985" stroke-width="8"/>'
        for pos, included, bound in [(left,w.include_start,w.start),(right,w.include_end,w.end)]:
            if bound is not None:
                marks += f'<circle cx="{pos}" cy="48" r="6" fill="{"#075985" if included else "white"}" stroke="#075985" stroke-width="2"/>'
            else:
                marks += f'<text x="{pos}" y="52" text-anchor="middle" fill="#075985">{"←" if pos == left else "→"}</text>'
        marks += f'<line x1="{anchor}" x2="{anchor}" y1="25" y2="70" stroke="#111827" stroke-width="2"/><text x="{anchor}" y="90" text-anchor="middle">Day 0</text>'
    else:
        summary = f"Start: {item['start']}. "
        for group in ("events", "censors"):
            summary += group.capitalize() + ": " + "; ".join(
                f"{e['name']} ({e['column']}) " + ("eligible dates supplied by source preparation" if e['offset_days'] is None else
                    f"{'on or after' if e['include_offset'] else 'strictly after'} day {e['offset_days']}")
                for e in item[group]) + ". "
        summary += (f"Select {item['event_selection']} event and {item['censor_selection']} censor; {item['same_day']} wins on the same day. " +
                    ("Follow-up eligibility is applied by the product's source preparation. " if item['min_followup_days'] is None else
                     f"Minimum follow-up: {item['min_followup_days']} days ({item['short_followup'].replace('_', ' ')}). ") +
                    f"{item['day_count'].capitalize()} days / {item['days_per_unit']} = {item['time_unit']} output.")
        entries = [(kind, entry) for kind in ("events", "censors") for entry in item[kind]]
        limit = max([1] + [entry["offset_days"] for _, entry in entries if entry["offset_days"] is not None])
        visible = entries[:8]
        height = 70 + 28 * len(visible)
        marks = '<text x="15" y="20">Eligibility thresholds — not observed event dates</text>'
        for i, (kind, entry) in enumerate(visible):
            y = 48 + 28 * i
            x = 230 + 270 * entry["offset_days"] / limit if entry["offset_days"] is not None else 545
            label = entry['name'][:27] + (" (event)" if kind == "events" else " (censor)")
            marks += f'<text x="15" y="{y+4}" font-size="12">{escape(label)}</text><line x1="230" x2="565" y1="{y}" y2="{y}" stroke="#64748b"/>'
            fill = '#075985' if entry['include_offset'] else 'white'
            if kind == 'events':
                marks += f'<path d="M {x} {y-7} L {x-6} {y+6} L {x+6} {y+6} Z" fill="{fill}" stroke="#075985" stroke-width="2"/>'
            else:
                marks += f'<rect x="{x-5}" y="{y-5}" width="10" height="10" fill="{fill}" stroke="#075985" stroke-width="2"/>'
        marks += f'<text x="230" y="{height-5}" text-anchor="middle" font-size="11">Day 0</text><text x="500" y="{height-5}" text-anchor="middle" font-size="11">Day {limit}</text>'
        if any(entry['offset_days'] is None for _, entry in visible):
            summary += "Markers at the far right mean eligibility was prepared upstream, not an assumed day offset. "
        if item.get('adapter') == 'overall_survival':
            summary += "Existing prostate policy is retained: the death flag selects death or follow-up. A death after follow-up is still used pending the Science decision OS-AFTER-CENSOR. "
    bounds = item.get("value", {}).get("valid_range")
    if bounds:
        limits = []
        for name, direction in (("minimum", "above"), ("maximum", "below")):
            if bounds[name] is not None:
                limits.append(f"{direction}{' or equal to' if bounds['include_' + name] else ''} {bounds[name]}")
        summary += " Use values " + " and ".join(limits) + " after unit conversion."
    if item.get("publication"):
        pub = item["publication"]
        summary += f" Publish {pub['precision']} total digits with {pub['scale']} decimal places; round half up and refuse overflow."
    # Text is visible as well as an accessible description; colour is supplementary.
    import base64
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 {height}" '
           'style="color:#111827;fill:currentColor;background:white">'
           f'<title>Calculation timeline</title><desc>{escape(summary)}</desc>{marks}</svg>')
    # Streamlit sanitizes inline SVG out of st.html. A self-contained SVG image
    # survives that sanitizer without scripts or external resource requests.
    data = base64.b64encode(svg.encode("utf-8")).decode("ascii")
    return (f'<figure style="margin:0"><img role="img" alt="{escape(summary, quote=True)}" '
            f'src="data:image/svg+xml;base64,{data}" style="width:100%;max-height:{height+10}px"/>'
            f'<figcaption>{escape(summary)}</figcaption></figure>')


def _bounds(record):
    return {"lower": record.get("min", record.get("min_excl")), "upper": record.get("max", record.get("max_excl")),
            "include_lower": "min" in record, "include_upper": "max" in record}


def _native_bounds(row):
    return {("min" if row.get("include_lower") else "min_excl"): row["lower"] for _ in [0] if row.get("lower") is not None} | {
            ("max" if row.get("include_upper") else "max_excl"): row["upper"] for _ in [0] if row.get("upper") is not None}


def _risk_tables(item, key, permitted):
    from experiments.portal.variable_clinical_rule_page import _grid
    st.caption("Use whole-number points here. Fractional scores need an engineering handoff to preserve their exact decimal result.")
    point_rows = []
    for component in item.get("components") or []:
        kind = "Number ranges" if component.get("bands") else "Categories"
        for entry in component.get("bands") or component.get("values") or []:
            point_rows.append({"component": component.get("name", ""), "column": component.get("column", ""),
                "kind": kind, "values": "\n".join(entry.get("from_equals_ci", entry.get("from_prefixes", []))),
                "case_sensitive": "from_prefixes" in entry, "points": entry.get("points"),
                "special": entry.get("when", ""), **_bounds(entry)})
    st.write("Component points")
    columns = {"component": st.column_config.TextColumn("Component"), "column": st.column_config.TextColumn("Input column"),
        "kind": st.column_config.SelectboxColumn("Match using", options=["Number ranges", "Categories"]),
        "values": st.column_config.TextColumn("Category values · one per line"),
        "case_sensitive": st.column_config.CheckboxColumn("Match case"),
        "lower": st.column_config.NumberColumn("From"), "include_lower": st.column_config.CheckboxColumn("Include From"),
        "upper": st.column_config.NumberColumn("To"), "include_upper": st.column_config.CheckboxColumn("Include To"),
        "points": st.column_config.NumberColumn("Points", step=1),
        "special": st.column_config.SelectboxColumn("Special case", options=["", "missing", "fallthrough"])}
    rows = _grid(point_rows, key + "points", permitted, columns,
                 numeric=("lower", "upper", "points"), boolean=("include_lower", "include_upper", "case_sensitive"))
    grouped, problems = {}, []
    for row in rows:
        if not any(row.get(key) for key in ("component", "column", "values")) and row.get("points") is None: continue
        identity = row.get("component") or ""
        kind = "bands" if row.get("kind") == "Number ranges" else "values"
        component = grouped.setdefault(identity, {"name": identity, "column": row.get("column") or "", kind: []})
        if component["column"] != (row.get("column") or "") or kind not in component:
            problems.append("Each component must use one input column and one match type."); continue
        points = row.get("points")
        entry = {"points": int(points) if isinstance(points, float) and points.is_integer() else points}
        if row.get("special"): entry["when"] = row["special"]
        elif kind == "bands": entry.update(_native_bounds(row))
        else: entry["from_prefixes" if row.get("case_sensitive") else "from_equals_ci"] = [v.strip() for v in str(row.get("values") or "").splitlines() if v.strip()]
        component[kind].append(entry)
    item["components"] = list(grouped.values())
    st.write("Categories for the total points")
    category_columns = {"label": st.column_config.TextColumn("Risk category"), "code": st.column_config.NumberColumn("Code", step=1),
        "lower": st.column_config.NumberColumn("From"), "include_lower": st.column_config.CheckboxColumn("Include From"),
        "upper": st.column_config.NumberColumn("To"), "include_upper": st.column_config.CheckboxColumn("Include To")}
    categories = [{"label": c.get("label", ""), "code": c.get("code"), **_bounds(c)} for c in item.get("categories") or []]
    edited = _grid(categories, key + "categories", permitted, category_columns,
                   numeric=("code", "lower", "upper"), boolean=("include_lower", "include_upper"))
    item["categories"] = [{"label": r.get("label") or "", "code": int(r["code"]) if isinstance(r.get("code"), float) and r["code"].is_integer() else r.get("code"), **_native_bounds(r)} for r in edited if r.get("label") or r.get("code") is not None]
    incomplete = item.get("incomplete") or {}
    item["incomplete"] = {"label": st.text_input("Category when a component is missing", value=incomplete.get("label", ""), key=key + "missing_label", disabled=not permitted),
                          "code": st.number_input("Missing-category code", value=incomplete.get("code"), step=1, key=key + "missing_code", disabled=not permitted)}
    return problems


def _record_fields(item, operator, columns, key, permitted):
    """The same closed field set used by AI proposals, YAML and execution."""
    def choose(label, value, options, suffix):
        labels = {"refuse": "Stop and show the problem", "missing": "Treat as missing", "exclude": "Leave out",
                  "ignore": "Use the available dates", "require_all": "Require every date", "single": "Use the one date column",
                  "priority": "Use the listed order", "null": "Leave the result blank", "retain_events": "Keep observed events",
                  "elapsed": "Days between the dates", "inclusive": "Count both the start and end day",
                  "blank": "Leave blank", "value": "Use a chosen value"}
        return st.selectbox(label, options, index=options.index(value) if value in options else None,
                            format_func=lambda v: ("Yes" if v else "No") if type(v) is bool else labels.get(v, str(v).replace("_", " ").capitalize()),
                            key=key + suffix, disabled=not permitted)
    def column(label, value, suffix, anchors=False):
        offered = list(dict.fromkeys((["index_date", "line_start", "diagnosis_date"] if anchors else []) + columns))
        return controls.render_choice(label, value or "", {c: c for c in offered}, key=key + suffix, disabled=not permitted)
    def number(label, value, suffix):
        return st.number_input(label, value=value, step=1, key=key + suffix, disabled=not permitted)
    if operator == "value_in_window":
        with st.expander("1. Value and dates", expanded=True):
            value, date = deepcopy(item.get("value") or {}), deepcopy(item.get("date_basis") or {})
            value["column"] = column("Value column", value.get("column"), "value_col")
            value["type"] = choose("Value type", value.get("type"), ["integer", "double", "string"], "value_type")
            value["invalid"] = choose("If a value cannot be read", value.get("invalid"), ["refuse", "missing"], "value_invalid")
            date["columns"] = controls.render_multi("Record date columns", date.get("columns", []), columns, key=key + "date_columns", disabled=not permitted)
            date["combine"] = choose("Date to use", date.get("combine"), ["single", "earliest", "latest"], "date_combine")
            date["nulls"] = choose("When a date column is empty", date.get("nulls"), ["ignore", "require_all"], "date_nulls")
            date["invalid"] = choose("If a date cannot be read", date.get("invalid"), ["refuse", "exclude"], "date_invalid")
            date["precision"] = choose("Date precision", date.get("precision"), ["day"], "date_precision")
            item.update(value=value, date_basis=date)
        with st.expander("2. Window and which record to use"):
            w, tie = deepcopy(item.get("window") or {}), deepcopy(item.get("tie_break") or {})
            w["anchor"] = column("Anchor date column", w.get("anchor"), "anchor", True)
            st.caption("Choose a date already available for this patient and cohort. Named anchors need a mapped or earlier calculated date.")
            w["start"] = number("First day relative to anchor (blank = unbounded)", w.get("start"), "start")
            w["end"] = number("Last day relative to anchor (blank = unbounded)", w.get("end"), "end")
            w["include_start"] = choose("Include first day", w.get("include_start"), [True, False], "include_start")
            w["include_end"] = choose("Include last day", w.get("include_end"), [True, False], "include_end")
            w["unit"] = choose("Window unit", w.get("unit"), ["day"], "window_unit")
            item["window"] = w
            item["select"] = choose("Which result", item.get("select"), ["closest", "earliest", "latest", "minimum", "maximum", "count", "any"], "select")
            tie["date"] = choose("If dates are equally suitable", tie.get("date"), ["earliest", "latest"], "tie_date")
            tie["value"] = choose("If values still tie", tie.get("value"), ["lowest", "highest", "refuse"], "tie_value")
            if value.get("type") == "string":
                st.caption("For text, lowest/highest means alphabetic order. It does not rank clinical severity.")
            item["tie_break"] = tie
            item["null_values"] = choose("Include records with an empty value", item.get("null_values"), ["include", "exclude"], "null_values")
        with st.expander("3. Matching records and missing values"):
            filters = deepcopy(item.get("filters") or [])
            count = st.number_input("Number of record filters", min_value=0, max_value=100, value=len(filters), step=1, key=key + "filter_count", disabled=not permitted)
            filters = (filters + [{} for _ in range(count)])[:count]
            for i, f in enumerate(filters):
                f["column"] = column(f"Filter {i+1} column", f.get("column"), f"filter_col{i}")
                f["operator"] = choose(f"Filter {i+1} comparison", f.get("operator"), ["in", "not_in", "is_null", "is_not_null"], f"filter_op{i}")
                if f["operator"] in {"is_null", "is_not_null"}:
                    f["values"] = []
                else:
                    original = f.get("values", [])
                    text = controls.render_multi(f"Filter {i+1} values", [str(v) for v in original], [str(v) for v in original], key=key + f"filter_values{i}", disabled=not permitted)
                    dtype = "number" if original and type(original[0]) in (int, float) else "boolean" if original and type(original[0]) is bool else "text"
                    dtype = choose(f"Filter {i+1} value type", dtype, ["text", "number", "boolean"], f"filter_type{i}")
                    try:
                        if dtype == "boolean" and any(v.casefold() not in {"true", "false"} for v in text):
                            raise ValueError("Use true or false for boolean filter values")
                        f["values"] = [float(v) for v in text] if dtype == "number" else [v.casefold() == "true" for v in text] if dtype == "boolean" else text
                    except ValueError:
                        st.warning("Filter values must match the chosen type.")
                        f["values"] = []
            item["filters"] = filters
            missing = deepcopy(item.get("missing") or {})
            dtype = "integer" if item.get("select") in {"count", "any"} else value.get("type")
            for state in ("no_record", "out_of_window", "present_null", "no_anchor"):
                label = state.replace("_", " ").capitalize()
                mode = choose(label, "blank" if state in missing and missing[state] is None else "value" if state in missing else None, ["blank", "value"], "missing_" + state)
                if mode == "blank":
                    missing[state] = None
                elif mode == "value":
                    current = missing.get(state)
                    if dtype == "string":
                        missing[state] = st.text_input(label + " replacement", value=current or "", key=key + state + "replacement", disabled=not permitted)
                    else:
                        missing[state] = st.number_input(label + " replacement", value=(float(current) if current is not None else None) if dtype == "double" else current, step=0.1 if dtype == "double" else 1, key=key + state + "replacement", disabled=not permitted)
                else:
                    missing.pop(state, None)
            item["missing"] = missing
        with st.expander("Usable values (optional)"):
            enabled = st.checkbox("Limit usable values", value="valid_range" in value, key=key + "valid_range", disabled=not permitted)
            if enabled:
                bounds = deepcopy(value.get("valid_range") or {})
                for field in ("minimum", "maximum"):
                    bounds[field] = st.number_input(field.capitalize() + " usable value (blank means unbounded)",
                        value=float(bounds[field]) if bounds.get(field) is not None else None, key=key + "range_" + field, disabled=not permitted)
                    bounds["include_" + field] = choose("Include the " + field, bounds.get("include_" + field), [True, False], "range_include_" + field)
                value["valid_range"] = bounds
                st.caption("Applied after unit conversion. An unusable result still counts as a recorded test.")
            else:
                value.pop("valid_range", None)
        with st.expander("Unit conversion (optional)"):
            enabled = st.checkbox("Apply a reviewed scale and offset", value="transform" in value, key=key + "transform", disabled=not permitted)
            if enabled:
                t = deepcopy(value.get("transform") or {})
                for f in ("scale", "offset"):
                    t[f] = st.number_input(f.capitalize(), value=float(t[f]) if t.get(f) is not None else None, key=key + f, disabled=not permitted)
                for f in ("input_unit", "output_unit"):
                    t[f] = controls.render_choice(f.replace("_", " ").capitalize(), t.get(f, ""), {u:u for u in ["mg", "g", "mg/dL", "mmol/L"]}, key=key + f, disabled=not permitted)
                t["unit_column"] = column("Unit column", t.get("unit_column"), "unit_column")
                value["transform"] = t
            else:
                value.pop("transform", None)
    else:
        item["start"] = column("Time starts at", item.get("start"), "event_start", True)
        for group in ("events", "censors"):
            with st.expander("Events" if group == "events" else "Censor dates", expanded=group == "events"):
                existing = deepcopy(item.get(group) or [])
                count = st.number_input("Number of " + group, min_value=1, max_value=100, value=max(1, len(existing)), step=1, key=key + group + "count", disabled=not permitted)
                entries = (existing + [{} for _ in range(count)])[:count]
                for i, entry in enumerate(entries):
                    prefix = group + str(i)
                    entry["name"] = st.text_input(f"{group.capitalize()} {i+1} reason", value=entry.get("name", ""), key=key + prefix + "name", disabled=not permitted)
                    entry["column"] = column(f"{group.capitalize()} {i+1} date column", entry.get("column"), prefix + "column", True)
                    entry["offset_days"] = number(f"{group.capitalize()} {i+1} earliest day after start", entry.get("offset_days"), prefix + "offset")
                    entry["include_offset"] = choose(f"{group.capitalize()} {i+1} include that day", entry.get("include_offset"), [True, False], prefix + "include")
                item[group] = entries
        with st.expander("How dates are compared"):
            for field, options in {"event_selection":["earliest", "priority"], "censor_selection":["earliest", "latest", "priority"], "same_day":["event", "censor"], "short_followup":["null", "retain_events"], "day_count":["elapsed", "inclusive"], "time_unit":["day", "month"], "missing_dates":["null", "refuse"]}.items():
                item[field] = choose(field.replace("_", " ").capitalize(), item.get(field), options, field)
            item["min_followup_days"] = number("Minimum follow-up days", item.get("min_followup_days"), "min_fu")
            item["days_per_unit"] = st.number_input("Days per time unit", value=float(item["days_per_unit"]) if item.get("days_per_unit") is not None else None, key=key + "divisor", disabled=not permitted)
            st.caption("Priority uses the listed order. Month output needs a reviewed divisor; no calendar conversion is assumed.")
    with st.expander("Published number precision (optional)"):
        enabled = st.checkbox("Publish a fixed decimal type", value="publication" in item, key=key + "publication", disabled=not permitted)
        if enabled:
            pub = deepcopy(item.get("publication") or {})
            for field, label, low in (("precision", "Total digits", 1), ("scale", "Decimal places", 0)):
                pub[field] = st.number_input(label, min_value=low, max_value=38, value=pub.get(field), step=1, key=key + "publication_" + field, disabled=not permitted)
            pub.update(type="decimal", rounding="half_up", overflow="refuse")
            item["publication"] = pub
            st.caption("Rounds the final result half up. Values that exceed the type's capacity stop the build.")
        else:
            item.pop("publication", None)
    preview = calculation_timeline(item)
    if preview:
        st.html(preview)


def render(row, rule, *, key, permitted):
    operator = rule["operator"]
    item = deepcopy(rule.get("native") or {})
    original_keys = set(item)
    source = (row.get("values") or {}).get("source") or {}
    columns = list((source.get("columns") or {}).keys()) if isinstance(source.get("columns"), dict) else []
    st.caption("Supply this product's calculation rules. No published instrument or clinical coefficients are filled in automatically.")
    st.caption({
        "value_in_window": "Pick records relative to a stated date, then choose one value or a count.",
        "time_to_event": "Compare qualifying event and censor dates. Each must already be a reviewed patient date.",
        "risk_score": "This adds discrete component points and classifies the total. Continuous weighted prediction models need a separate implementation.",
        "serial_marker": "Use a source containing one marker's dated measurements. This tests a confirmed change; it does not filter mixed analytes or calculate a rate.",
        "rt_course": "Outputs describe the first course and the total course count. Treatment intent and per-course details require separate definitions.",
        "dose_exposure": "Only the selected drug names and one stated unit are included. Dose conversion and dose changes over time require separate calculations.",
        "modality_relation": "This compares two dated episodes already on the patient record. It does not infer treatment intent."
    }[operator])
    rule["output_stem"] = st.text_input("Output name for this instrument", value=rule.get("output_stem", row.get("variable_id", "").lower()), key=key + "stem", disabled=not permitted)
    item["name"] = rule["output_stem"]
    results = sorted(native.result_names(rule))
    rule["result"] = st.selectbox("Result to deliver", results, index=results.index(rule["result"]) if rule.get("result") in results else None,
                                  format_func=lambda v: v.replace("_", " ").capitalize(), key=key + "result", disabled=not permitted) or ""
    if operator in native.DERIVED:
        st.caption("This calculation uses columns already assembled for the patient. Select Calculated from other variables as its origin.")
    else:
        st.caption("Link an existing source table above; its logical column names are offered here. Sources review checks the delivered names.")
        # A legacy explicit source is kept for mismatch checking, never silently rebound.
        if item.get("source") and source.get("logical_table") and item["source"] != source["logical_table"]:
            st.warning("This saved instrument still names source " + item["source"] + ".")
            if st.button("Use the source table selected above", key=key + "use_selected_source", disabled=not permitted):
                item["source"] = source["logical_table"]
    problems = []
    if operator == "risk_score": problems.extend(_risk_tables(item, key, permitted))
    fields = sorted(native.FIELDS[operator] - {"name", "source", "components", "categories", "incomplete"} - native.GOVERNED)
    if operator in {"value_in_window", "time_to_event"}:
        _record_fields(item, operator, columns, key, permitted)
        fields = []
    if operator == "rt_course":
        mode = st.selectbox("Course records", list(ENUMS["mode"]), index=list(ENUMS["mode"]).index(item["mode"]) if item.get("mode") in ENUMS["mode"] else None,
                            format_func=lambda v: {"abstracted": "Dates already identify each course", "sessionised": "Group sessions using a gap"}[v], key=key + "mode", disabled=not permitted)
        item["mode"] = mode or ""
        active = {"start_column", "end_column"} if mode == "abstracted" else {"date_column", "gap_days"} if mode == "sessionised" else set()
        for old in {"start_column", "end_column", "date_column", "gap_days"} - active: item.pop(old, None)
        fields = sorted(active)
    for field in fields:
        label = field.replace("_", " ").capitalize()
        if field in ENUMS:
            options = list(ENUMS[field])
            item[field] = st.selectbox(label, options, index=options.index(item[field]) if item.get(field) in options else None, key=key + field, disabled=not permitted) or ""
        elif field in NUMBERS:
            if field == "window_days" and item.get("relation") == "precedes":
                item.pop(field, None); continue
            integer = field not in {"threshold_pct", "threshold_abs"}
            value = item.get(field)
            if value is not None: value = int(value) if integer else float(value)
            entered = st.number_input(label, value=value, step=1 if integer else 0.1, key=key + field, disabled=not permitted)
            if entered is None: item.pop(field, None)
            else: item[field] = entered
        elif field == "drugs":
            item[field] = controls.render_multi("Drug names to include", item.get(field, []), item.get(field, []), key=key + field, disabled=not permitted)
        elif field.endswith("_column") or field == "unit":
            choices = {name: name for name in columns} if field.endswith("_column") else {name: name for name in ["mg", "mg/m2", "mg/kg", "g", "Gy"]}
            item[field] = controls.render_choice(label, item.get(field, ""), choices, key=key + field, disabled=not permitted)
        else:
            item[field] = st.text_input(label, value=item.get(field, ""), key=key + field, disabled=not permitted)
    if operator in {"risk_score", "serial_marker"} or operator == "rt_course" and item.get("mode") == "sessionised":
        with st.expander("Instrument reference and reviewer"):
            for field in ("instrument", "citation", "clinically_reviewed_by", "review_date"):
                item[field] = st.text_input(field.replace("_", " ").capitalize(), value=item.get(field, ""), key=key + field, disabled=not permitted,
                                           help="YYYY-MM-DD" if field == "review_date" else None)
            st.caption("These fields document the instrument. Saving them does not approve or sign the product.")
    item = {field: value for field, value in item.items() if field in original_keys or value not in (None, "")}
    rule["native"] = item
    updates = {"clinical_rule": rule}
    try:
        updates.update(native.scientific_updates(rule))
        remaining = native.issues({**row, "clinical_rule": rule})
        if remaining and operator in {"value_in_window", "time_to_event"}:
            st.caption("Complete the remaining choices before saving.")
            with st.expander("Choices still needed"):
                for issue in remaining: st.caption(issue)
        else:
            for issue in remaining: st.caption(issue)
    except (ValueError, TypeError) as error:
        problems.append(str(error))
    output = next((c for c in native.emitted_columns(rule) if c["result"] == rule.get("result")), None)
    if output: st.info("Delivered field: " + output["name"] + " · " + controls.TYPE_LABELS.get(output["type"], output["type"]))
    if problems:
        updates["_ui_issues"] = problems
        for issue in problems: st.warning(issue)
    return updates
