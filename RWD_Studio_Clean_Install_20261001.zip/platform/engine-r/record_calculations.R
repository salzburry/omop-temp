# Independent R compiler for typed observation and time-to-event records.
# Plans contain Spark SQL plus bounded refusal queries. No patient rows are
# brought into R to calculate values; sparklyr executes the entire plan.

rc_fields <- function(x, required, optional = character()) {
  if (!is.list(x) || anyDuplicated(names(x)) || !all(required %in% names(x)) ||
      any(!names(x) %in% c(required, optional))) stop("Invalid calculation fields: ", paste(required, collapse=", "))
}
rc_enum <- function(x, values) {
  if (!is.character(x) || length(x)!=1L || is.na(x) || !x %in% values) stop("Invalid calculation choice")
}
rc_id <- function(x) {
  if (!is.character(x) || length(x)!=1L || is.na(x) || !grepl("^[A-Za-z][A-Za-z0-9_]{0,127}$", x))
    stop("Invalid calculation identifier")
  paste0("`", x, "`")
}
# Existing engine frames can carry private columns (for example _lastvisit).
# These names come from the inspected Spark schema, not an authored rule.
rc_frame_column <- function(x) {
  if (!is.character(x) || length(x)!=1L || is.na(x) || !nzchar(x) || grepl("[[:cntrl:]]",x))
    stop("Invalid frame column")
  paste0("`",gsub("`","``",x,fixed=TRUE),"`")
}
rc_num <- function(x, integer=FALSE, low=-Inf, high=Inf) {
  if (!is.numeric(x) || length(x)!=1L || !is.finite(x) || x<low || x>high || (integer && x!=trunc(x)))
    stop("Invalid calculation number")
}
rc_bool <- function(x) {
  if (!is.logical(x) || length(x)!=1L || is.na(x)) stop("Calculation inclusion must be boolean")
}
rc_array <- function(x, minimum=0L) {
  if (!(is.list(x) || is.atomic(x)) || !is.null(names(x)) || length(x)<minimum || length(x)>1000L)
    stop("Invalid calculation list")
}
rc_literal <- function(x) {
  if (is.null(x)) return("NULL")
  if (length(x)!=1L || is.na(x)) stop("Invalid calculation literal")
  if (is.logical(x)) return(if (x) "TRUE" else "FALSE")
  if (is.numeric(x)) {rc_num(x); return(format(x, digits=17, scientific=FALSE, trim=TRUE))}
  if (!is.character(x)) stop("Invalid calculation literal")
  # Hex UTF-8 avoids dependence on SQL quote/backslash settings.
  paste0("decode(unhex('", paste(format(charToRaw(enc2utf8(x))),collapse=""), "'),'UTF-8')")
}
rc_value_kind <- function(x) "window" %in% names(x) || "source" %in% names(x)
rc_outputs <- function(x) paste0(x$name, if (rc_value_kind(x)) c("","dt","n","status") else c("","dt","fl","event","censor","status"))
rc_dependencies <- function(x) if (rc_value_kind(x)) x$window$anchor else unique(c(x$start,
  vapply(c(x$events,x$censors),function(e)e$column,"")))

rc_standalone <- function(items) Filter(function(x) is.null(x$adapter), items)
rc_for_adapter <- function(cfg, adapter, name=NULL) {
  if(!"outcomes" %in% cfg_roles(cfg)) return(NULL)
  p <- cfg_pack(cfg,"outcomes")
  items <- Filter(function(x) identical(x$adapter,adapter) && (is.null(name) || identical(x$name,name)),
                  c(p$record_values,p$time_to_events))
  if(length(items)>1L) stop("Duplicate adapter calculation")
  declared <- unlist(p$calculation_adapters[[adapter]])
  if(!length(items) && ((is.null(name) && length(declared)) || (!is.null(name) && name %in% declared)))
    stop("Required typed calculation missing; legacy fallback retired")
  if(length(items)) {
    if(!items[[1]]$name %in% declared) stop("Typed calculation has no mandatory adapter declaration")
    rc_validate(items[[1]]); rc_adapter_check(cfg,items[[1]]); items[[1]]
  } else NULL
}

rc_adapter_check <- function(cfg,x) {
  p <- cfg_pack(cfg,"outcomes"); a <- x$adapter; n <- x$name
  c <- if("clinical" %in% cfg_roles(cfg)) cfg_pack(cfg,"clinical") else list()
  refuse <- function() stop("Unsupported or inconsistent source adapter: ",a,".",n)
  if(a %in% c("baseline_ecog","lab_values","psa_timepoints") && x$window$anchor!="index_date") refuse()
  if(a=="baseline_ecog") {
    if(n!="ecog_grade" || x$source!="baseline_ecog" || !identical(unlist(x$date_basis$columns),"ecogdate") ||
       x$value$column!="ecogvalue" || x$value$type!="integer" || !is.null(c[[a]]$equidistant)) refuse()
  } else if(a=="lab_values") {
    matches <- list()
    for(b in clinical_panel_instances(c[[a]])) for(i in b$panel)
      if(paste0(i$name,"v")==n) matches[[length(matches)+1L]] <- list(block=b,item=i)
    if(length(matches)!=1L) refuse()
    b <- matches[[1]]$block; i <- matches[[1]]$item
    if(x$source!=b$source || length(i$units) || length(i$unit_conversions) ||
       !is.null(x$window$start) || !is.null(x$window$end)) refuse()
  } else if(a=="psa_timepoints") {
    points <- Filter(function(i) identical(i$name,n),c[[a]]$points)
    if(length(points)!=1L || !is.null(points[[1]]$anchor) || x$source!=c[[a]]$source) refuse()
  } else {
    prefix <- if(a=="overall_survival") "os" else "pfs"
    columns <- if(prefix=="os") "os_death" else c("pfs_progression","pfs_death")
    if(!length(p[[a]]) || n!=prefix || x$start!=paste0(prefix,"_start") ||
       !identical(vapply(x$events,function(e)e$column,""),columns) ||
       !identical(vapply(x$censors,function(e)e$column,""),paste0(prefix,"_censor")) || !is.null(x$min_followup_days)) refuse()
    if(prefix=="pfs") {
      policy <- if(identical(p[[a]]$semantics,"contract")) "priority" else "earliest"
      if(x$event_selection!=policy || x$events[[1]]$offset_days!=p[[a]]$exclusion_days || x$events[[1]]$include_offset) refuse()
    }
    for(e in c(x$censors,tail(x$events,1L))) if(!is.null(e$offset_days)) refuse()
  }
  invisible(TRUE)
}

rc_check_adapters <- function(cfg) {
  p <- cfg_pack(cfg,"outcomes"); declared <- character(); bound <- character()
  for(a in names(p$calculation_adapters)) {
    names <- p$calculation_adapters[[a]]; rc_array(names,1L)
    if(anyDuplicated(unlist(names))) stop("Duplicate adapter declaration")
    declared <- c(declared,paste(a,unlist(names),sep="/"))
  }
  for(x in c(p$record_values,p$time_to_events)) if(!is.null(x$adapter)) {
    rc_adapter_check(cfg,x); bound <- c(bound,paste(x$adapter,x$name,sep="/"))
  }
  if(anyDuplicated(bound) || !setequal(bound,declared)) stop("Typed adapter declarations and calculations differ; legacy fallback retired")
  invisible(TRUE)
}

rc_validate <- function(x) {
  rc_id(x$name)
  if (rc_value_kind(x)) {
    rc_fields(x,c("name","source","date_basis","filters","window","value","select","tie_break","null_values","missing"),c("publication","adapter"))
    if(!is.null(x$adapter)) rc_enum(x$adapter,c("baseline_ecog","lab_values","psa_timepoints"))
    rc_id(x$source)
    w <- x$window
    rc_fields(w,c("anchor","start","end","unit","include_start","include_end"))
    rc_id(w$anchor); rc_enum(w$unit,"day"); rc_bool(w$include_start); rc_bool(w$include_end)
    for (v in list(w$start,w$end)) if (!is.null(v)) rc_num(v,TRUE,-365250,365250)
    if (!is.null(w$start) && !is.null(w$end) && w$start+as.integer(!w$include_start)>w$end-as.integer(!w$include_end)) stop("Empty calculation window")
    d <- x$date_basis
    rc_fields(d,c("columns","combine","nulls","invalid","precision")); rc_array(d$columns,1L)
    invisible(lapply(d$columns,rc_id)); if (anyDuplicated(unlist(d$columns))) stop("Duplicate date columns")
    rc_enum(d$combine,c("single","earliest","latest")); rc_enum(d$nulls,c("ignore","require_all"))
    rc_enum(d$invalid,c("refuse","exclude")); rc_enum(d$precision,"day")
    if (d$combine=="single" && length(d$columns)!=1L) stop("Single date requires one column")
    rc_array(x$filters)
    for (f in x$filters) {
      rc_fields(f,c("column","operator","values")); rc_id(f$column)
      rc_enum(f$operator,c("in","not_in","is_null","is_not_null")); rc_array(f$values)
      if ((f$operator %in% c("in","not_in")) != (length(f$values)>0L)) stop("Filter values disagree with operator")
      kinds <- vapply(f$values,function(v) {rc_literal(v); if(is.null(v)) stop("Null filter literal"); if(is.numeric(v)) "number" else typeof(v)},"")
      if (length(unique(kinds))>1L) stop("Filter literals must share a type")
    }
    v <- x$value; rc_fields(v,c("column","type","invalid"),c("transform","valid_range")); rc_id(v$column)
    rc_enum(v$type,c("integer","double","string")); rc_enum(v$invalid,c("refuse","missing"))
    rc_enum(x$select,c("closest","earliest","latest","minimum","maximum","count","any"))
    if ("valid_range" %in% names(v)) {
      b <- v$valid_range; rc_fields(b,c("minimum","maximum","include_minimum","include_maximum"))
      if(v$type=="string") stop("valid_range requires numeric values")
      rc_bool(b$include_minimum); rc_bool(b$include_maximum)
      for(n in list(b$minimum,b$maximum)) if(!is.null(n)) rc_num(n)
      if(is.null(b$minimum) && is.null(b$maximum)) stop("valid_range needs a bound")
      if(!is.null(b$minimum) && !is.null(b$maximum) && (b$minimum>b$maximum ||
         (b$minimum==b$maximum && !(b$include_minimum && b$include_maximum)))) stop("Empty valid_range")
    }
    if (x$select %in% c("minimum","maximum") && v$type=="string") stop("Numeric selection requires numeric values")
    rc_fields(x$tie_break,c("date","value")); rc_enum(x$tie_break$date,c("earliest","latest"))
    rc_enum(x$tie_break$value,c("lowest","highest","refuse")); rc_enum(x$null_values,c("include","exclude"))
    rc_fields(x$missing,c("no_record","out_of_window","present_null","no_anchor"))
    dtype <- if(x$select %in% c("count","any")) "integer" else v$type
    for (literal in x$missing) if (!is.null(literal)) {
      rc_literal(literal)
      if(dtype=="string") {if(!is.character(literal)) stop("Missing value must be string")}
      else rc_num(literal,dtype=="integer",if(dtype=="integer") -2147483648 else -Inf,if(dtype=="integer") 2147483647 else Inf)
    }
    if ("transform" %in% names(v)) {
      t <- v$transform; rc_fields(t,c("scale","offset","input_unit","output_unit","unit_column"))
      if(v$type!="double") stop("Transform requires double output")
      rc_num(t$scale); rc_num(t$offset); rc_id(t$unit_column)
      for(u in list(t$input_unit,t$output_unit)) if(!is.character(u) || length(u)!=1L || is.na(u) || !nzchar(u)) stop("Unit must be named")
    }
  } else {
    rc_fields(x,c("name","start","events","censors","event_selection","censor_selection","same_day","min_followup_days","short_followup","day_count","time_unit","days_per_unit","missing_dates"),c("publication","adapter"))
    if(!is.null(x$adapter)) rc_enum(x$adapter,c("overall_survival","progression"))
    if(is.null(x$adapter) && (is.null(x$min_followup_days) || any(vapply(c(x$events,x$censors),function(e) is.null(e$offset_days),logical(1)))))
      stop("Null thresholds require an upstream eligibility adapter")
    rc_id(x$start)
    for (entries in list(x$events,x$censors)) {
      rc_array(entries,1L)
      for(e in entries) {rc_fields(e,c("name","column","offset_days","include_offset")); rc_id(e$name); rc_id(e$column); if(!is.null(e$offset_days)) rc_num(e$offset_days,TRUE,0,365250); rc_bool(e$include_offset)}
      if(anyDuplicated(tolower(vapply(entries,function(e)e$name,"")))) stop("Duplicate event/censor reasons")
    }
    rc_enum(x$event_selection,c("earliest","priority")); rc_enum(x$censor_selection,c("earliest","latest","priority"))
    rc_enum(x$same_day,c("event","censor")); if(!is.null(x$min_followup_days)) rc_num(x$min_followup_days,TRUE,0,365250)
    rc_enum(x$short_followup,c("null","retain_events")); rc_enum(x$day_count,c("elapsed","inclusive"))
    rc_enum(x$time_unit,c("day","month")); rc_num(x$days_per_unit)
    if(x$days_per_unit<=0 || (x$time_unit=="day" && x$days_per_unit!=1)) stop("Invalid time divisor")
    rc_enum(x$missing_dates,c("null","refuse"))
  }
  if("publication" %in% names(x)) {
    p <- x$publication; rc_fields(p,c("type","precision","scale","rounding","overflow"))
    rc_enum(p$type,"decimal"); rc_enum(p$rounding,"half_up"); rc_enum(p$overflow,"refuse")
    rc_num(p$precision,TRUE,1,38); rc_num(p$scale,TRUE,0,p$precision)
    if(rc_value_kind(x) && x$value$type=="string" && !x$select %in% c("count","any")) stop("Decimal publication needs numeric result")
  }
  invisible(TRUE)
}

rc_publish <- function(x, query, checks, columns) {
  if(is.null(x$publication)) return(list(sql=query,checks=checks))
  p <- x$publication; name <- rc_id(x$name)
  dtype <- paste0("decimal(",p$precision,",",p$scale,")")
  cast <- paste0("try_cast(",name," AS ",dtype,")")
  checks[[length(checks)+1L]] <- list(sql=paste0("SELECT 1 FROM (",query,") publication WHERE ",name,
    " IS NOT NULL AND ",cast," IS NULL LIMIT 1"),reason=paste("publication overflow for",dtype))
  outputs <- vapply(columns,function(n) if(n==x$name) paste(cast,"AS",name) else rc_frame_column(n),"")
  list(sql=paste0("SELECT ",paste(outputs,collapse=", ")," FROM (",query,") publication"),checks=checks)
}

rc_dates <- function(schema, columns) {
  for(n in columns) if(is.null(schema[[n]]) || !tolower(schema[[n]]) %in% c("date","datetype"))
    stop(n," must be an available DATE column")
}
rc_list_sql <- function(xs) paste(xs,collapse=", ")
rc_choose <- function(xs, fun) if(length(xs)==1L) xs[[1]] else paste0(fun,"(",rc_list_sql(xs),")")

rc_value_plan <- function(x, frame_sql, source_sql, frame_schema, source_schema, cohort_keys=FALSE) {
  rc_validate(x); rc_dates(frame_schema,c("index_date",x$window$anchor))
  if(cohort_keys) rc_dates(source_schema,"index_date")
  needed <- unique(c("patientid",unlist(x$date_basis$columns),x$value$column,
    vapply(x$filters,function(f)f$column,""),x$value$transform$unit_column))
  if(length(setdiff(needed,names(source_schema)))) stop("Missing source columns: ",paste(setdiff(needed,names(source_schema)),collapse=", "))
  filters <- vapply(x$filters,function(f) {
    q <- rc_id(f$column)
    switch(f$operator, is_null=paste(q,"IS NULL"), is_not_null=paste(q,"IS NOT NULL"),
      paste(q,if(f$operator=="not_in") "NOT IN" else "IN", "(",rc_list_sql(vapply(f$values,rc_literal,"")),")"))
  },"")
  dates <- vapply(x$date_basis$columns,function(n) {
    q <- rc_id(n); typ <- tolower(source_schema[[n]])
    parsed <- paste0("try_cast(",q," AS DATE)")
    if(typ %in% c("string","stringtype")) return(paste0("CASE WHEN ",q," RLIKE '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' AND length(",q,")=10 THEN ",parsed," END"))
    if(!typ %in% c("date","datetype","timestamp","timestamptype")) stop("Source date must be a full date or timestamp")
    parsed
  },"")
  invalid <- paste(vapply(seq_along(dates),function(j) paste0("(",rc_id(x$date_basis$columns[[j]])," IS NOT NULL AND (",dates[[j]],") IS NULL)"),""),collapse=" OR ")
  date <- rc_choose(dates,if(x$date_basis$combine=="earliest") "least" else "greatest")
  complete <- if(x$date_basis$nulls=="require_all") paste0(" AND ",paste(paste0("(",dates,") IS NOT NULL"),collapse=" AND ")) else ""
  date <- paste0("CASE WHEN NOT (",invalid,")",complete," THEN ",date," END")
  v <- x$value; q <- rc_id(v$column); parsed <- paste0("try_cast(",q," AS ",v$type,")")
  if(v$type=="integer") parsed <- paste0("CASE WHEN try_cast(",q," AS DOUBLE)=cast(",parsed," AS DOUBLE) THEN ",parsed," END")
  finite <- function(p) paste0("NOT isnan(",p,") AND abs(",p,") != cast('Infinity' AS DOUBLE)")
  if(v$type=="double") parsed <- paste0("CASE WHEN ",finite(parsed)," THEN ",parsed," END")
  source_keys <- if(cohort_keys) "patientid,index_date" else "patientid"
  index_join <- if(cohort_keys) " AND s.index_date=b.index_date" else ""
  ctes <- c(paste0("base AS (",frame_sql,")"), paste0("filtered AS (SELECT s.* FROM (",source_sql,") s INNER JOIN (SELECT DISTINCT ",source_keys," FROM base) b ON s.patientid=b.patientid",index_join,if(length(filters)) paste0(" WHERE ",paste(filters,collapse=" AND ")), ")"))
  checks <- list()
  add_check <- function(pred, reason) checks[[length(checks)+1L]] <<- list(sql=paste0("WITH ",rc_list_sql(ctes)," SELECT 1 FROM filtered WHERE ",pred," LIMIT 1"),reason=reason)
  if(x$date_basis$invalid=="refuse") add_check(invalid,"invalid source date")
  if(v$invalid=="refuse") add_check(paste0(q," IS NOT NULL AND (",parsed,") IS NULL"),"unusable value")
  if(!is.null(v$transform)) {
    t <- v$transform; unit <- rc_id(t$unit_column)
    add_check(paste0(unit," IS NULL OR ",unit," != ",rc_literal(t$input_unit)),"mixed or missing units")
    parsed <- paste0("((",parsed,")*",rc_literal(t$scale),"+",rc_literal(t$offset),")")
    add_check(paste0("(",parsed,") IS NOT NULL AND NOT (",finite(parsed),")"),"unit conversion produced non-finite value")
  }
  ctes <- c(ctes,paste0("records AS (SELECT ",source_keys,", ",date," AS rd, ",parsed," AS rv, 1 AS rec FROM filtered)"))
  acceptable <- "TRUE"
  if(!is.null(v$valid_range)) {
    b <- v$valid_range; predicates <- character()
    if(!is.null(b$minimum)) predicates <- c(predicates,paste("r.rv",if(b$include_minimum) ">=" else ">",rc_literal(b$minimum)))
    if(!is.null(b$maximum)) predicates <- c(predicates,paste("r.rv",if(b$include_maximum) "<=" else "<",rc_literal(b$maximum)))
    acceptable <- paste0("r.rv IS NULL OR (",paste(predicates,collapse=" AND "),")")
  }
  anchor <- paste0("b.",rc_id(x$window$anchor)); gap <- paste0("datediff(r.rd,",anchor,")")
  eligible <- c("r.rd IS NOT NULL",paste(anchor,"IS NOT NULL"))
  w <- x$window
  if(!is.null(w$start)) eligible <- c(eligible,paste(gap,if(w$include_start) ">=" else ">",rc_literal(w$start)))
  if(!is.null(w$end)) eligible <- c(eligible,paste(gap,if(w$include_end) "<=" else "<",rc_literal(w$end)))
  ctes <- c(ctes,paste0("joined AS (SELECT b.patientid,b.index_date,",anchor," AS anchor,r.rd,r.rv,r.rec,(",acceptable,") AS acceptable,abs(",gap,") AS gap, (",paste(eligible,collapse=" AND "),") AS eligible FROM base b LEFT JOIN records r ON b.patientid=r.patientid",if(cohort_keys) " AND b.index_date=r.index_date", ")"))
  keys <- "patientid,index_date"
  ctes <- c(ctes,paste0("counts AS (SELECT ",keys,",count(rec) AS records,sum(CASE WHEN eligible THEN 1 ELSE 0 END) AS candidates,sum(CASE WHEN eligible AND acceptable THEN 1 ELSE 0 END) AS accepted,sum(CASE WHEN eligible AND acceptable AND rv IS NOT NULL THEN 1 ELSE 0 END) AS usable FROM joined GROUP BY ",keys,")"))
  order <- c(switch(x$select,closest="gap ASC",earliest="rd ASC",latest="rd DESC",minimum="rv ASC NULLS LAST",maximum="rv DESC NULLS LAST",character()), paste("rd",if(x$tie_break$date=="earliest") "ASC" else "DESC"))
  ctes <- c(ctes,paste0("candidates AS (SELECT * FROM joined WHERE eligible AND acceptable",if(x$null_values=="exclude") " AND rv IS NOT NULL",")"))
  if(x$tie_break$value=="refuse" && !x$select %in% c("count","any")) checks[[length(checks)+1L]] <- list(
    sql=paste0("WITH ",rc_list_sql(ctes),", ranked AS (SELECT *,dense_rank() OVER(PARTITION BY ",keys," ORDER BY ",rc_list_sql(order),") AS rk FROM candidates) SELECT 1 FROM ranked WHERE rk=1 GROUP BY ",keys," HAVING count(DISTINCT named_struct('v',rv))>1 LIMIT 1"),reason="conflicting tied values")
  order <- c(order,paste("rv",if(x$tie_break$value=="highest") "DESC" else "ASC","NULLS LAST"))
  ctes <- c(ctes,paste0("picked AS (SELECT *,row_number() OVER(PARTITION BY ",keys," ORDER BY ",rc_list_sql(order),") AS rn FROM candidates)"))
  n <- if(x$null_values=="exclude") "c.usable" else "c.accepted"
  status <- paste0("CASE ",if(x$select %in% c("count","any")) paste0("WHEN ",n,">0 THEN 'present' "),"WHEN b.",rc_id(w$anchor)," IS NULL THEN 'no_anchor' WHEN c.records=0 THEN 'no_record' WHEN c.candidates=0 THEN 'out_of_window' WHEN p.rv IS NULL THEN 'present_null' ELSE 'present' END")
  val <- switch(x$select,count=n,any=paste0("CASE WHEN ",n,">0 THEN 1 ELSE 0 END"),"p.rv")
  for(state in names(x$missing)) val <- paste0("CASE WHEN (",status,")=",rc_literal(state)," THEN ",rc_literal(x$missing[[state]])," ELSE ",val," END")
  dtype <- if(x$select %in% c("count","any")) "integer" else v$type
  output <- c(paste0("cast(",val," AS ",dtype,")"),if(x$select %in% c("count","any")) "cast(NULL AS DATE)" else "p.rd","cast(c.candidates AS INT)",status)
  query <- paste0("WITH ",rc_list_sql(ctes)," SELECT b.*,",rc_list_sql(paste(output,"AS",vapply(rc_outputs(x),rc_id,"")))," FROM base b LEFT JOIN counts c ON b.patientid=c.patientid AND b.index_date=c.index_date LEFT JOIN picked p ON b.patientid=p.patientid AND b.index_date=p.index_date AND p.rn=1")
  rc_publish(x,query,checks,c(names(frame_schema),rc_outputs(x)))
}

rc_event_plan <- function(x, frame_sql, frame_schema) {
  rc_validate(x); rc_dates(frame_schema,rc_dependencies(x))
  if(length(intersect(c("_rwd_event","_rwd_censor","_rwd_wins","_rwd_end"),tolower(names(frame_schema)))))
    stop("Reserved calculation scratch columns already exist")
  start <- rc_id(x$start)
  choose <- function(entries,policy) {
    candidates <- lapply(seq_along(entries),function(i) {
      e <- entries[[i]]; col <- rc_id(e$column)
      valid <- if(is.null(e$offset_days)) paste(col,"IS NOT NULL") else paste0("datediff(",col,",",start,")",if(e$include_offset) ">=" else ">",rc_literal(e$offset_days))
      paste0("CASE WHEN ",valid," THEN named_struct('date',",col,",'priority',",i,",'reason',",rc_literal(e$name),") END")
    })
    if(policy!="latest") return(rc_choose(candidates,if(policy=="priority") "coalesce" else "least"))
    latest <- rc_choose(paste0("(",candidates,").date"),"greatest")
    rc_choose(paste0("CASE WHEN (",candidates,").date=",latest," THEN ",candidates," END"),"coalesce")
  }
  ctes <- c(paste0("base AS (",frame_sql,")"),paste0("chosen AS (SELECT *,",choose(x$events,x$event_selection)," AS _rwd_event,",choose(x$censors,x$censor_selection)," AS _rwd_censor FROM base)"),
    paste0("wins AS (SELECT *, (_rwd_event IS NOT NULL AND (_rwd_censor IS NULL OR _rwd_event.date",if(x$same_day=="event") "<=" else "<","_rwd_censor.date)) AS _rwd_wins FROM chosen)"),
    "ended AS (SELECT *,CASE WHEN _rwd_wins THEN _rwd_event.date ELSE _rwd_censor.date END AS _rwd_end FROM wins)")
  short <- if(is.null(x$min_followup_days)) "FALSE" else paste0("datediff(_rwd_end,",start,")<",rc_literal(x$min_followup_days),if(x$short_followup=="retain_events") " AND NOT _rwd_wins")
  valid <- paste0(start," IS NOT NULL AND _rwd_end IS NOT NULL AND NOT (",short,")")
  status <- paste0("CASE WHEN ",start," IS NULL THEN 'no_start' WHEN _rwd_end IS NULL THEN 'no_end' WHEN ",short," THEN 'short_followup' WHEN _rwd_wins THEN 'event' ELSE 'censored' END")
  duration <- paste0("cast((datediff(_rwd_end,",start,")+",as.integer(x$day_count=="inclusive"),")/",rc_literal(x$days_per_unit)," AS DOUBLE)")
  outputs <- c(paste0("CASE WHEN ",valid," THEN ",duration," END"),paste0("CASE WHEN ",valid," THEN _rwd_end END"),paste0("cast(CASE WHEN ",valid," THEN CASE WHEN _rwd_wins THEN 1 ELSE 0 END END AS INT)"),
    paste0("CASE WHEN ",valid," AND _rwd_wins THEN _rwd_event.reason END"),paste0("CASE WHEN ",valid," AND NOT _rwd_wins THEN _rwd_censor.reason END"),status)
  query <- paste0("WITH ",rc_list_sql(ctes)," SELECT ",rc_list_sql(c(vapply(names(frame_schema),rc_frame_column,""),paste(outputs,"AS",vapply(rc_outputs(x),rc_id,""))))," FROM ended")
  checks <- if(x$missing_dates=="refuse") list(list(sql=paste0("WITH ",rc_list_sql(ctes)," SELECT 1 FROM ended WHERE ",start," IS NULL OR _rwd_end IS NULL LIMIT 1"),reason="no valid start/end date")) else list()
  rc_publish(x,query,checks,c(names(frame_schema),rc_outputs(x)))
}

rc_schema <- function(frame) {
  schema <- sparklyr::sdf_schema(frame)
  setNames(lapply(schema,function(x) x$type),vapply(schema,function(x)x$name,""))
}
rc_execute <- function(frame, plan) {
  sc <- sparklyr::spark_connection(frame)
  query <- function(sql) dplyr::tbl(sc, dbplyr::sql(sql))
  for(check in plan$checks) if(nrow(dplyr::collect(query(check$sql)))) stop("CALCULATION REFUSED: ",check$reason)
  query(plan$sql)
}
record_value_build <- function(source, frame, item, cohort_keys=FALSE) rc_execute(frame,rc_value_plan(item,
  as.character(dbplyr::sql_render(frame)),as.character(dbplyr::sql_render(source)),rc_schema(frame),rc_schema(source),cohort_keys))
time_to_event_build <- function(frame, item) rc_execute(frame,rc_event_plan(item,
  as.character(dbplyr::sql_render(frame)),rc_schema(frame)))

record_calculations_build <- function(src, frame, cfg) {
  rc_check_adapters(cfg)
  pack <- cfg_pack(cfg,"outcomes")
  items <- rc_standalone(c(pack$record_values,pack$time_to_events))
  if(!length(items)) return(frame)
  available <- tolower(colnames(frame))
  for(x in items) {
    rc_validate(x)
    if(length(setdiff(tolower(rc_dependencies(x)),available))) stop("Unavailable calculation date dependencies; put producers first")
    if(length(intersect(tolower(rc_outputs(x)),available))) stop("Calculation output collision")
    available <- c(available,tolower(rc_outputs(x)))
  }
  sql <- as.character(dbplyr::sql_render(frame))
  rc_execute(frame,list(sql=sql,checks=list(list(sql=paste0("SELECT 1 FROM (",sql,") b GROUP BY patientid,index_date HAVING count(*)>1 OR patientid IS NULL OR index_date IS NULL LIMIT 1"),reason="Calculations require one non-null patient/index row"))))
  for(x in items) {
    if(rc_value_kind(x)) {
      if(is.null(src[[x$source]])) stop("Missing calculation source: ",x$source)
      frame <- record_value_build(src[[x$source]],frame,x)
    } else frame <- time_to_event_build(frame,x)
  }
  frame
}

rc_check_earlier_consumers <- function(cfg) {
  pack <- cfg_pack(cfg,"outcomes")
  outputs <- tolower(unlist(lapply(rc_standalone(c(pack$record_values,pack$time_to_events)),rc_outputs)))
  if(!length(outputs)) return(invisible(TRUE))
  clinical <- if("clinical" %in% cfg_roles(cfg)) cfg_pack(cfg,"clinical") else list()
  for(item in c(clinical$derived,pack$ads_derived))
    if(length(intersect(tolower(unlist(item$requires)),outputs)))
      stop("Derived expression reads a typed calculation before it executes")
  for(n in c("event_flag","death_anchor","censor_anchor","gate"))
    if(length(intersect(tolower(pack$overall_survival[[n]]),outputs)))
      stop("Overall survival reads a typed calculation before it executes")
  invisible(TRUE)
}
