"""Managed-runtime entry points; importing them never starts a build."""
