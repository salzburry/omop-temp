"""Product-scoped dictionary additions from reviewed configuration.

The shared catalogue remains unchanged. New names have a conservative internal
delivery policy until their audiences are reviewed separately. Matching master
entries retain their existing applicability, privacy and audience restrictions.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import math
import re

_NAME = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")
_SHA = re.compile(r"^[0-9a-f]{64}$")
STORAGE_TYPES = {"string", "integer", "long", "double", "boolean", "date", "timestamp"}
DISPLAY_TYPES = {"string", "categorical", "numeric", "date", "timestamp", "flag", "time_to_event"}
_ENTRY = {"code", "label", "category", "type", "data_type", "definition", "units", "codes", "rule",
          "provenance", "published_name", "audiences", "pii", "catalog_code", "catalog_digest", "destinations"}
_REQUIRED = _ENTRY - {"catalog_code", "catalog_digest", "destinations"}
_PROVENANCE = {"item_id", "variable_id", "product_id", "master_name", "master_digest", "review_digest", "rule_digest"}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False).encode("utf-8")).hexdigest()


def _text(value, label, limit=16000):
    if not isinstance(value, str) or len(value) > limit or any((ord(c) < 32 and c not in "\n\r\t") or 127 <= ord(c) <= 159 for c in value):
        raise ValueError(f"Product dictionary {label} must be bounded text without unsupported control characters.")


def _literal(value, depth=0):
    if depth > 32:
        raise ValueError("Product dictionary metadata is nested too deeply.")
    if isinstance(value, dict):
        if len(value) > 1000 or any(not isinstance(key, str) for key in value):
            raise ValueError("Product dictionary metadata needs bounded mappings with text keys.")
        for key, child in value.items():
            _text(key, "field name", 160)
            _literal(child, depth + 1)
    elif isinstance(value, list):
        if len(value) > 1000:
            raise ValueError("Product dictionary metadata contains too many values.")
        for child in value:
            _literal(child, depth + 1)
    elif isinstance(value, str):
        _text(value, "value")
    elif type(value) in (bool, int, float, type(None)):
        if type(value) is float and not math.isfinite(value):
            raise ValueError("Product dictionary numbers must be finite.")
    else:
        raise ValueError("Product dictionary metadata must be finite JSON.")


def validate_overlay(value):
    if not isinstance(value, dict) or set(value) != {"version", "variables"} or type(value.get("version")) is not int or value["version"] != 1:
        raise ValueError("Product dictionary overlay requires version 1 and a variables list.")
    _literal(value)
    if len(json.dumps(value, ensure_ascii=False).encode("utf-8")) > 1024 * 1024:
        raise ValueError("Product dictionary overlay exceeds the 1 MiB limit.")
    entries = value["variables"]
    if not isinstance(entries, list) or len(entries) > 1000:
        raise ValueError("Product dictionary variables must be a list of at most 1000 entries.")
    names = set()
    for entry in entries:
        if not isinstance(entry, dict) or not _REQUIRED <= set(entry) or set(entry) - _ENTRY:
            raise ValueError("A product dictionary variable contains unsupported or missing fields.")
        code = entry["code"]
        if not isinstance(code, str) or len(code) > 128 or not _NAME.fullmatch(code):
            raise ValueError("Product dictionary code must be the actual physical variable identifier.")
        if code.casefold() in names:
            raise ValueError(f"Product dictionary code {code} is repeated; resolve conflicting definitions.")
        names.add(code.casefold())
        for key in ("label", "category", "definition", "published_name"):
            _text(entry[key], key)
        if not entry["label"].strip() or not entry["definition"].strip() or not entry["category"].strip():
            raise ValueError(f"Product dictionary {code} needs a label, category and reviewed definition.")
        if entry["published_name"] and not _NAME.fullmatch(entry["published_name"]):
            raise ValueError("A dictionary published name is an identifier, not a replacement for its physical code.")
        if not isinstance(entry["data_type"], str) or not isinstance(entry["type"], str) or entry["data_type"] not in STORAGE_TYPES or entry["type"] not in DISPLAY_TYPES:
            raise ValueError(f"Product dictionary {code} needs explicit supported display and storage types.")
        if entry["audiences"] != ["internal"] or entry["pii"] is not True:
            raise ValueError("New product dictionary metadata must remain internal-only until audience/privacy review is implemented.")
        destinations = entry.get("destinations", {"dictionary": "configured", "dashboard": "excluded"})
        if not isinstance(destinations, dict) or set(destinations) != {"dictionary", "dashboard"} or destinations.get("dictionary") != "configured" or destinations.get("dashboard") not in ("configured", "excluded"):
            raise ValueError("Product dictionary destinations require dictionary configured and an explicit dashboard choice.")
        if not isinstance(entry["units"], list) or any(not isinstance(unit, str) or not unit.strip() for unit in entry["units"]):
            raise ValueError(f"Product dictionary {code} units must be a list of nonblank unit names.")
        if not isinstance(entry["codes"], list):
            raise ValueError(f"Product dictionary {code} categories must be a list.")
        seen_codes = set()
        for category in entry["codes"]:
            if not isinstance(category, dict) or set(category) != {"code", "label"} or not isinstance(category["label"], str):
                raise ValueError(f"Product dictionary {code} categories need a code and label.")
            if type(category["code"]) not in {str, int, float, bool}:
                raise ValueError(f"Product dictionary {code} category code must be a scalar value.")
            token = json.dumps(category["code"], sort_keys=True)
            if token in seen_codes:
                raise ValueError(f"Product dictionary {code} repeats a category code.")
            seen_codes.add(token)
        if not isinstance(entry["rule"], dict):
            raise ValueError(f"Product dictionary {code} rule must be structured metadata.")
        provenance = entry["provenance"]
        if not isinstance(provenance, dict) or set(provenance) - _PROVENANCE or not (_PROVENANCE - {"master_digest", "rule_digest"}) <= set(provenance):
            raise ValueError(f"Product dictionary {code} needs its reviewed-row provenance.")
        for key, item in provenance.items():
            _text(item, "provenance " + key)
        for key in ("review_digest", "master_digest", "rule_digest"):
            if key in provenance and not _SHA.fullmatch(provenance[key]):
                raise ValueError(f"Product dictionary {code} has an invalid {key}.")
        reviewed = entry["rule"].get("reviewed_variable")
        if reviewed is not None:
            if not isinstance(reviewed, dict) or reviewed.get("version") != 1:
                raise ValueError("The dictionary needs a versioned reviewed-variable record.")
            exact = hashlib.sha256(json.dumps(reviewed, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()
            if provenance.get("rule_digest") != exact:
                raise ValueError("The dictionary scientific rule differs from its reviewed digest.")
            if reviewed.get("item_id") != provenance["item_id"] or reviewed.get("variable_id") != provenance["variable_id"]:
                raise ValueError("The dictionary scientific rule belongs to a different variable.")
            if (reviewed.get("values", {}).get("output") or {}).get("physical_name") != code:
                raise ValueError("The dictionary scientific rule names a different physical output.")
            for field in ("clinical_rule", "family"):
                if field in entry["rule"] and entry["rule"][field] != reviewed.get(field, {}):
                    raise ValueError("The dictionary rule summary differs from its complete reviewed rule.")
        if not provenance["item_id"] or not provenance["variable_id"]:
            raise ValueError(f"Product dictionary {code} needs its originating review row.")
        if ("catalog_code" in entry) != ("catalog_digest" in entry):
            raise ValueError(f"Product dictionary {code} must pin both the matched catalogue name and digest.")
        if "catalog_code" in entry and (not isinstance(entry["catalog_code"], str) or not _NAME.fullmatch(entry["catalog_code"]) or not _SHA.fullmatch(str(entry["catalog_digest"]))):
            raise ValueError(f"Product dictionary {code} has an invalid catalogue reference.")
    return deepcopy(value)


def matching_entry(catalog, code):
    """Find one exact master name or one explicit line template, never spelling similarity."""
    from .dictionary import _emitted
    entries = catalog.get("variables") or []
    exact = [entry for entry in entries if str(entry.get("code", "")).casefold() == code.casefold()]
    if len(exact) > 1:
        raise ValueError(f"The shared catalogue repeats code {code}; resolve the naming conflict.")
    if exact:
        return exact[0]
    templates = [entry for entry in entries if entry.get("line_template") and _emitted(entry, {code.casefold()})]
    if len(templates) > 1:
        raise ValueError(f"More than one master line template matches {code}.")
    return templates[0] if templates else None


def _compatible(master, entry):
    actual = entry["data_type"]
    if master.get("data_type") and master["data_type"] != actual:
        return False
    declared = master.get("type")
    accepted = {"numeric": {"integer", "long", "double"}, "time_to_event": {"integer", "long", "double"},
                "categorical": {"string", "integer", "long", "boolean"}, "flag": {"string", "integer", "long", "boolean"},
                "date": {"date"}, "timestamp": {"timestamp"}, "string": {"string"}}
    return declared not in accepted or actual in accepted[declared]


def merge(cfg, catalog):
    """Return a detached effective catalogue, refusing stale/conflicting master names."""
    if not isinstance(catalog, dict) or not isinstance(catalog.get("variables", []), list):
        raise ValueError("The shared variable catalogue must contain a variables list.")
    result = deepcopy(catalog)
    overlay = (getattr(cfg, "raw", {}) or {}).get("dictionary_overlay")
    if overlay is None:
        return result
    overlay = validate_overlay(overlay)
    result.setdefault("variables", [])
    for entry in overlay["variables"]:
        code = entry["code"]
        master = matching_entry(catalog, code)
        if master is not None:
            if entry.get("catalog_code") != master.get("code") or entry.get("catalog_digest") != digest(master):
                raise ValueError(f"Product dictionary {code} conflicts with a changed or unreviewed master catalogue entry; refresh its variable review.")
            if not _compatible(master, entry):
                raise ValueError(f"Product dictionary {code} storage type conflicts with the master catalogue definition.")
        elif "catalog_code" in entry:
            raise ValueError(f"The pinned master catalogue entry for {code} is missing; refresh its variable review.")
        merged = deepcopy(entry)
        merged.update(applies_to="all", product_dictionary=True)
        if master is not None:
            # Keep the shared definition's delivery restrictions. Product rule
            # details enrich it; they cannot lower PII or broaden its audiences.
            for key in ("label", "category", "type", "applies_to", "pii", "audiences"):
                if key in master:
                    merged[key] = deepcopy(master[key])
                elif key in {"pii", "audiences"}:
                    merged.pop(key, None)
        exact_index = next((i for i, existing in enumerate(result["variables"])
                            if str(existing.get("code", "")).casefold() == code.casefold()), None)
        if exact_index is None:
            result["variables"].append(merged)
        else:
            # Other master metadata (ledger, clinical semantics) survives too.
            result["variables"][exact_index] = {**result["variables"][exact_index], **merged}
    return result


def dictionary_coverage(cfg, catalog, columns, *, tumor=None, audiences=None):
    """Requested fields absent from the ADS or the visible internal dictionary."""
    overlay = (getattr(cfg, "raw", {}) or {}).get("dictionary_overlay")
    if overlay is None:
        return []
    entries = validate_overlay(overlay)["variables"]
    actual = {str(code).casefold() for code in columns}
    from .dictionary import DEFAULT_AUDIENCES, _applies
    audience_specs = audiences if audiences is not None else DEFAULT_AUDIENCES
    internal = audience_specs.get("internal")
    documented = {str(entry.get("code", "")).casefold() for entry in catalog.get("variables", [])
        if internal is not None and _applies(entry, tumor)
        and "internal" in entry.get("audiences", list(audience_specs))
        and not (internal.get("drop_pii", False) and entry.get("pii"))}
    return sorted(entry["code"] for entry in entries if entry["code"].casefold() not in actual or entry["code"].casefold() not in documented)


def for_dashboard(catalog):
    """Apply reviewed dashboard destinations without affecting legacy catalogue rows."""
    result = deepcopy(catalog)
    result["variables"] = [entry for entry in result.get("variables", []) if not entry.get("product_dictionary")
                           or (entry.get("destinations") or {}).get("dashboard") == "configured"]
    return result
