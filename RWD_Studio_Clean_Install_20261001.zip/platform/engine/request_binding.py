"""Assert a portal request matches the exact deployed product build inputs."""
from pathlib import Path, PurePosixPath
import re


def validate(root, config_path, actual_digest, *, pack='', config_sha256='', request_id=''):
    # Scheduled jobs without a portal request retain the existing governed path.
    if not any((pack, config_sha256, request_id)):
        return None
    if (not all(isinstance(value, str) and value for value in (pack, config_sha256, request_id))
            or not re.fullmatch(r'[a-f0-9]{64}', config_sha256)
            or not re.fullmatch(r'(?:[a-f0-9]{24}|[a-f0-9]{32,64})', request_id)):
        raise ValueError('The portal build request is incomplete or malformed.')
    relative = PurePosixPath(pack)
    if (relative.is_absolute() or '..' in relative.parts or '\\' in pack or ':' in pack
            or len(relative.parts) != 4 or relative.parts[0] != 'products'
            or relative.as_posix() != pack):
        raise ValueError('The portal request names an invalid product path.')
    root = Path(root).resolve()
    expected = (root / pack / 'config/data_product.yaml').resolve()
    if not expected.is_relative_to(root) or expected != Path(config_path).resolve():
        raise ValueError('The requested product differs from the deployed build configuration.')
    if actual_digest != config_sha256:
        raise ValueError('The deployed configuration changed after this request. Prepare a fresh build from the current review.')
    return {'pack': pack, 'config_sha256': config_sha256, 'request_id': request_id}
