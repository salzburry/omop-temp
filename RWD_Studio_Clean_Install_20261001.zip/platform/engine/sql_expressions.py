"""Bounded scalar Spark expressions, checked before and during a build.

SQLGlot parses the exact Spark dialect at configuration time. It is not Spark's
type analyser: runtime ``analyse`` also resolves the expression against the real
frame schema, without collecting rows. Authored SQL is never rewritten.
"""
from __future__ import annotations

import re
import math
from copy import deepcopy
from datetime import date

from sqlglot import exp, parse
from sqlglot.errors import ParseError, SqlglotError

STUDY_TOKENS = frozenset({"index_start", "index_end", "index_period_start",
                          "index_period_end", "observation_end", "data_cutoff"})
# Structural nodes and deterministic scalar functions supported by these four
# configuration fields. Aggregate/window/subquery/UDF semantics need a dedicated
# reviewed operator; accepting any parseable SQL would not establish that support.
NODES = frozenset("""
column identifier literal null boolean paren var datatype datatypeparam
add sub mul div intdiv mod neg pow eq neq gt gte lt lte nullsafeeq nullsafeneq
and or not is in between like ilike escape
case if cast trycast coalesce nullif ifnull greatest least
abs ceil floor round sign sqrt exp ln log log2 log10 power
lower upper length trim ltrim rtrim substring substr concat concatws
replace regexp_replace regexpreplace regexplike regexpilike regexpextract
year month day dayofmonth dayofweek dayofyear quarter hour minute second
datediff timestampdiff tsordstodate tsordstotimestamp tsordsadd dateadd
datesub addmonths lastday monthsbetween datetrunc timestamptrunc
timetostr strtodate strtotime unixtotime timetounix
""".split())
_TOKEN = re.compile(r"\{([A-Za-z_][A-Za-z0-9_]*)\}")

ELIGIBILITY_TYPES = frozenset({"integer", "number", "string", "date", "boolean"})
ELIGIBILITY_OPERATORS = frozenset({"eq", "ne", "gt", "ge", "lt", "le", "in", "not_in", "between", "is_missing", "is_present"})


def eligibility_plan(rule, *, available=None):
    """Compile typed cohort predicates; no authored SQL or patient-data reads.

    Predicates use this cohort's calculated values and three-valued logic until
    the final missing-value decision. The same plan is checked again at runtime.
    """
    if not isinstance(rule, dict) or set(rule) != {"version", "include", "exclude", "missing"}:
        raise ValueError("Eligibility needs version, include, exclude and an explicit missing-value policy.")
    if type(rule["version"]) is not int or rule["version"] != 1:
        raise ValueError("Eligibility version must be 1.")
    if rule["missing"] not in ("exclude", "include", "error"):
        raise ValueError("Choose whether indeterminate eligibility excludes, includes, or stops the build.")
    columns, count = {}, 0

    def literal(value, kind):
        valid = ((kind == "integer" and type(value) is int and -(2**63) <= value < 2**63)
                 or (kind == "number" and ((type(value) is int and -(2**63) <= value < 2**63)
                                            or (type(value) is float and math.isfinite(value))))
                 or (kind == "boolean" and type(value) is bool)
                 or (kind == "string" and isinstance(value, str) and len(value) <= 2000
                     and not any(ord(c) < 32 for c in value)))
        if kind == "date" and isinstance(value, str):
            try:
                valid = date.fromisoformat(value).isoformat() == value
            except ValueError:
                valid = False
        if not valid:
            raise ValueError(f"Eligibility values must be literal {kind} values of the declared type.")

    def node(value, depth=0):
        nonlocal count
        count += 1
        if count > 200 or depth > 6 or not isinstance(value, dict):
            raise ValueError("Eligibility supports at most 200 conditions and six group levels.")
        if set(value) in ({"all"}, {"any"}):
            key = next(iter(value))
            if not isinstance(value[key], list) or not value[key] or len(value[key]) > 100:
                raise ValueError("Each eligibility group needs 1–100 conditions.")
            for child in value[key]:
                node(child, depth + 1)
            return
        field, kind, op = (value.get(key) for key in ("field", "type", "operator"))
        if not isinstance(field, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,127}", field):
            raise ValueError("Choose an eligibility field using its delivered variable identifier.")
        if kind not in ELIGIBILITY_TYPES or op not in ELIGIBILITY_OPERATORS:
            raise ValueError(f"Eligibility {field}: choose a supported type and comparison.")
        expected = {"field", "type", "operator"}
        if op in {"in", "not_in", "between"}:
            expected.add("values")
            values = value.get("values")
            if not isinstance(values, list) or not 1 <= len(values) <= 100:
                raise ValueError(f"Eligibility {field}: choose 1–100 literal values.")
            for item in values:
                literal(item, kind)
            if op == "between" and (len(values) != 2 or kind not in {"integer", "number", "date"} or values[0] > values[1]):
                raise ValueError(f"Eligibility {field}: an inclusive range needs two ordered numbers or dates.")
        elif op not in {"is_missing", "is_present"}:
            expected.add("value")
            literal(value.get("value"), kind)
        if op in {"gt", "ge", "lt", "le"} and kind not in {"integer", "number", "date"}:
            raise ValueError(f"Eligibility {field}: ordered comparisons require a number or date.")
        if set(value) != expected:
            raise ValueError(f"Eligibility {field}: the comparison has unexpected or missing fields.")
        previous = columns.setdefault(field, kind)
        if previous != kind or any(name.casefold() == field.casefold() and name != field for name in columns):
            raise ValueError(f"Eligibility {field}: use one exact identifier and type throughout the rule.")

    for key in ("include", "exclude"):
        if rule[key] is not None:
            node(rule[key])
    if not columns:
        raise ValueError("Add an inclusion or exclusion condition, or remove the eligibility rule.")
    if available is not None and set(columns) - set(available):
        raise ValueError("Eligibility columns are unavailable: " + ", ".join(sorted(set(columns) - set(available))) + ". Prepare or map these variables first.")
    return {"rule": deepcopy(rule), "columns": columns}


def eligibility_errors(rule, *, where="eligibility", available=None):
    try:
        eligibility_plan(rule, available=available)
        return []
    except (ValueError, TypeError, OverflowError) as error:
        return [f"{where}: {error}"]


def apply_eligibility(frame, rule):
    """Filter membership before cohort union, using typed Spark literals.

    Missing columns/types stop before a job. Values retain their own cohort's
    index context. This action does not collect patient values into Python.
    """
    if rule is None:
        return frame
    from pyspark.sql import functions as F
    from pyspark.sql import types as T
    plan = eligibility_plan(rule, available=frame.columns)
    schema = {field.name: field.dataType for field in frame.schema.fields}
    if len(schema) != len(frame.columns) or len({name.casefold() for name in schema}) != len(schema):
        raise ValueError("Eligibility requires unambiguous output column names.")
    for name, kind in plan["columns"].items():
        families = {"integer": T.IntegralType, "number": T.NumericType, "string": T.StringType,
                    "boolean": T.BooleanType, "date": T.DateType}
        if not isinstance(schema[name], families[kind]):
            raise ValueError(f"Eligibility {name}: expected {kind}, found {schema[name].simpleString()}. Fix its typed source or calculation first.")

    def atom(value):
        if "all" in value or "any" in value:
            key = "all" if "all" in value else "any"
            result = F.lit(key == "all")
            for child in value[key]:
                result = result & atom(child) if key == "all" else result | atom(child)
            return result
        column = F.col(value["field"])
        if isinstance(schema[value["field"]], (T.FloatType, T.DoubleType)):
            column = F.when(F.isnan(column), F.lit(None)).otherwise(column)
        op = value["operator"]
        if op == "is_missing":
            return column.isNull()
        if op == "is_present":
            return column.isNotNull()
        def lit(item):
            return F.lit(date.fromisoformat(item) if value["type"] == "date" else item)
        if op in {"in", "not_in"}:
            predicate = column.isin([lit(item) for item in value["values"]])
            return ~predicate if op == "not_in" else predicate
        if op == "between":
            return (column >= lit(value["values"][0])) & (column <= lit(value["values"][1]))
        other = lit(value["value"])
        return {"eq": lambda: column == other, "ne": lambda: column != other,
                "gt": lambda: column > other, "ge": lambda: column >= other,
                "lt": lambda: column < other, "le": lambda: column <= other}[op]()

    include = F.lit(True) if rule["include"] is None else atom(rule["include"])
    exclude = F.lit(False) if rule["exclude"] is None else atom(rule["exclude"])
    eligible = include & ~exclude
    unknown = (F.raise_error(F.lit("Eligibility cannot be decided because a required value is missing")).cast("boolean")
               if rule["missing"] == "error" else F.lit(rule["missing"] == "include"))
    return frame.filter(F.coalesce(eligible, unknown))


def _parsed(sql, where):
    if not isinstance(sql, str) or not sql.strip():
        raise ValueError(f"{where}: enter one non-empty Spark expression.")
    if len(sql.encode("utf-8")) > 32_768:
        raise ValueError(f"{where}: expression exceeds 32 KiB; use a reviewed calculation operator.")
    unknown = set(_TOKEN.findall(sql)) - STUDY_TOKENS
    if unknown:
        raise ValueError(f"{where}: unknown study token(s): {', '.join(sorted(unknown))}.")
    prepared = _TOKEN.sub("'2000-01-01'", sql)
    try:
        trees = [tree for tree in parse(prepared, dialect="spark") if tree is not None]
    except ParseError as error:
        detail = error.errors[0].get("description", "invalid syntax") if error.errors else "invalid syntax"
        raise ValueError(f"{where}: invalid Spark expression ({detail}).") from error
    except (SqlglotError, RecursionError) as error:
        raise ValueError(f"{where}: invalid or excessively nested Spark expression.") from error
    if len(trees) != 1:
        raise ValueError(f"{where}: use one scalar expression, without SQL statements.")
    tree = trees[0]
    nodes = list(tree.walk())
    if len(nodes) > 2_048:
        raise ValueError(f"{where}: expression is too complex; split it into reviewed outputs.")
    for node in nodes:
        if node.key not in NODES:
            label = node.name if isinstance(node, exp.Anonymous) else node.key
            raise ValueError(f"{where}: unsupported expression operation '{label}'; use a supported "
                             "scalar function or a reviewed calculation operator. Subqueries, "
                             "statements, aggregates, windows and external functions are not supported here.")
        if isinstance(node, exp.Column) and (node.table or node.db or node.catalog):
            raise ValueError(f"{where}: reference delivered column names directly, without table qualifiers.")
    return tree


def references(sql, *, where="expression"):
    """Exact column identifiers from a bounded Spark-dialect expression."""
    return {column.name for column in _parsed(sql, where).find_all(exp.Column)}


def errors(sql, *, where="expression", requires=None, implicit=(), available=None):
    """Pure configuration checks; omitted legacy requires are inferred from AST."""
    try:
        refs = references(sql, where=where)
    except ValueError as error:
        return [str(error)]
    messages = []
    if requires is not None:
        if not isinstance(requires, list) or not all(isinstance(c, str) and c.strip() for c in requires):
            return [f"{where}.requires: choose a list of input column names."]
        declared = {c.casefold() for c in requires} | {c.casefold() for c in implicit}
        absent = sorted(c for c in refs if c.casefold() not in declared)
        if absent:
            messages.append(f"{where}: add referenced column(s) to requires: {', '.join(absent)}.")
    if available is not None:
        columns = {str(c).casefold() for c in available}
        absent = sorted(c for c in (refs | set(requires or [])) if c.casefold() not in columns)
        if absent:
            messages.append(f"{where}: required input column(s) are unavailable: {', '.join(absent)}. "
                            "Map these columns or correct the calculation before running.")
    return messages


def analyse(frame, sql, *, where="expression", requires=None, implicit=(), predicate=False):
    """Resolve exact original SQL against real Spark types; no data action/write."""
    problems = errors(sql, where=where, requires=requires, implicit=implicit,
                      available=frame.columns)
    if problems:
        raise ValueError("; ".join(problems))
    from pyspark.sql import functions as F
    try:
        field = frame.select(F.expr(sql).alias("_review_expression")).schema.fields[0]
    except Exception as error:
        # Analysis errors can include the query plan. Return the bounded error class,
        # not raw source paths or an entire plan; the field/inputs remain actionable.
        kind = error.getCondition() if callable(getattr(error, "getCondition", None)) else type(error).__name__
        raise ValueError(f"{where}: Spark cannot resolve the expression's columns or types ({kind}). "
                         "Check the selected input columns, date casts and function arguments.") from error
    if predicate and field.dataType.typeName() != "boolean":
        raise ValueError(f"{where}: the filter must return true/false; this expression returns "
                         f"{field.dataType.simpleString()}.")
    return field.dataType


def clinical_errors(items, *, available=None, optional=None):
    if items is None:
        return []
    if not isinstance(items, list):
        return ["clinical.derived must be a list of named expressions."]
    result, seen = [], set()
    have = None if available is None else set(available)
    optional = {str(key).casefold(): value for key, value in (optional or {}).items()}
    for index, item in enumerate(items):
        where = f"clinical.derived[{index}]"
        if not isinstance(item, dict):
            result.append(f"{where} must be a mapping.")
            continue
        name = item.get("name")
        if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", name):
            result.append(f"{where}.name must be a variable identifier.")
        elif name.casefold() in seen:
            result.append(f"{where}.name duplicates '{name}'.")
        else:
            seen.add(name.casefold())
        result += errors(item.get("expr"), where=where, requires=item.get("requires"),
                         implicit=("index_date",), available=have)
        try:
            refs = references(item.get("expr"), where=where)
        except ValueError:
            refs = set()  # The normal expression check already reports malformed SQL.
        required = item.get("requires") or []
        if isinstance(required, list):
            refs |= {value for value in required if isinstance(value, str)}
        for column in sorted(refs):
            if column.casefold() in optional:
                result.append(f"{where}.requires: '{column}' is produced only by optional "
                              f"{optional[column.casefold()]}; mark its source mapping required "
                              "or change the calculation. An optional output may be absent, "
                              "even when the expression handles null values.")
        if have is not None and isinstance(name, str):
            have.add(name)  # Native clinical expressions execute in list order.
            optional.pop(name.casefold(), None)
    return result
