"""Whole-day observation windows shared by clinical rules and their editor.

Offsets belong to each variable/block. Legacy window_days is inclusive and
index-relative. Normalization is read-only; it never supplies a clinical window
for a record which did not declare one.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class RecordWindow:
    anchor: str
    start: int | None
    end: int | None
    unit: str
    include_start: bool
    include_end: bool

    def offsets(self) -> list[int | None]:
        """Lower exclusive DATE boundaries to equivalent inclusive day offsets."""
        return [None if self.start is None else self.start + (not self.include_start),
                None if self.end is None else self.end - (not self.include_end)]

    def document(self) -> dict:
        return asdict(self)

    def describe(self) -> str:
        if self.include_start and self.include_end:
            return f"Inclusive whole-day window [{self.start}, {self.end}] relative to {self.anchor_description()}"
        left = "unbounded" if self.start is None else f"day {self.start} ({'included' if self.include_start else 'excluded'})"
        right = "unbounded" if self.end is None else f"day {self.end} ({'included' if self.include_end else 'excluded'})"
        return f"Whole-day window from {left} to {right} relative to {self.anchor_description()}"

    def anchor_description(self) -> str:
        return "cohort index" if self.anchor == "index_date" else self.anchor


def parse_window(value: dict, *, allow_named_anchor: bool = False) -> RecordWindow:
    fields = set(RecordWindow.__dataclass_fields__)
    if not isinstance(value, dict) or set(value) != fields:
        raise ValueError("Window needs anchor, start, end, unit, include_start and include_end only.")
    import re
    if not isinstance(value['anchor'], str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,127}", value['anchor']):
        raise ValueError("Window anchor must name a date column.")
    if value['anchor'] != 'index_date' and not allow_named_anchor:
        raise ValueError("This observation window supports anchor index_date: use the reviewed cohort index. Other anchors need a supported calculation.")
    if value['unit'] != 'day':
        raise ValueError("Observation windows use whole days; calendar months must not be converted silently.")
    for field in ('start', 'end'):
        bound = value[field]
        if bound is not None and (type(bound) is not int or abs(bound) > 365250):
            raise ValueError("Window boundaries must be whole days (within 365250) or null for unbounded.")
    for field in ('include_start', 'include_end'):
        if type(value[field]) is not bool:
            raise ValueError("Window boundary inclusion must be true or false.")
    window = RecordWindow(**value)
    lo, hi = window.offsets()
    if lo is not None and hi is not None and lo > hi:
        raise ValueError("The window starts after it ends or contains no whole day. Review its boundaries.")
    return window


def read_window(block: dict, *, allow_named_anchor: bool = False) -> RecordWindow | None:
    """Read either spelling; simultaneous declarations are refused, never guessed."""
    for item in block.get('panel') or []:
        if isinstance(item, dict) and ('window' in item or 'window_days' in item):
            raise ValueError("Put each different window in its own panel instance settings.")
    if 'window' in block:
        if 'window_days' in block:
            raise ValueError("Choose window or window_days, not both, for this variable.")
        # PSA already supports a separate source anchor. Do not label that as index.
        if block.get('anchor'):
            raise ValueError("A separate anchor cannot be combined with an index-date window.")
        return parse_window(block['window'], allow_named_anchor=allow_named_anchor)
    legacy = block.get('window_days')
    if legacy is None:
        return None
    if not isinstance(legacy, (list, tuple)) or len(legacy) != 2:
        raise ValueError("window_days needs two whole-day boundaries [start, end].")
    return parse_window(dict(anchor='index_date', start=legacy[0], end=legacy[1],
                             unit='day', include_start=True, include_end=True))


def window_days(block: dict, *, required=False, finite=False) -> list[int | None]:
    window = read_window(block)
    if window is None:
        if required:
            raise ValueError("Choose an observation window for this variable.")
        return [None, None]
    days = window.offsets()
    if finite and None in days:
        raise ValueError("This calculation needs a finite day boundary at both ends.")
    return days


def window_fields(block: dict) -> dict:
    """Keep the reviewed spelling when compiling an existing draft."""
    window_days(block, required=True)
    window = read_window(block)
    return {'window': window.document()} if 'window' in block else {'window_days': window.offsets()}


def clinical_window_errors(clinical: dict, *, structured_only=False) -> list[str]:
    """Validate supported placements before execution, including panel instances."""
    from engine.clinical_panels import iter_panels

    blocks = [('baseline_ecog', clinical.get('baseline_ecog'), True),
              ('comorbidity_index', clinical.get('comorbidity_index'), True)]
    blocks += [(f'categoricals[{i}]', b, False) for i, b in enumerate(clinical.get('categoricals') or [])]
    blocks += [(label, b, False) for _, label, b in iter_panels(clinical)]
    blocks += [(f'psa_timepoints.points[{i}]', p, True)
               for i, p in enumerate((clinical.get('psa_timepoints') or {}).get('points') or [])]
    errors = []
    for label, block, finite in blocks:
        if not isinstance(block, dict):
            continue  # Structural schema reports malformed blocks.
        if 'window' in block or (not structured_only and 'window_days' in block):
            try:
                window_days(block, finite=finite)
            except ValueError as exc:
                errors.append(f'clinical.{label}: {exc}')
        for i, item in enumerate(block.get('panel') or []):
            if isinstance(item, dict) and ('window' in item or 'window_days' in item):
                errors.append(f'clinical.{label}.panel[{i}]: put each different window in its own panel instance settings.')
    return errors
