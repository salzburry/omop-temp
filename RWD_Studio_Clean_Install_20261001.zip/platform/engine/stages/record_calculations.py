"""Typed observations and time-to-event rules over each assembled cohort.

Source records retain their own grain until reduced to (patientid, index_date).
Anchors are explicit DATE columns on that cohort, including outputs of earlier
rules. No disease-specific thresholds, windows or censoring choices live here.
"""
from __future__ import annotations

from engine.record_windows import parse_window

KEYS = ("record_values", "time_to_events")
VALUE_FIELDS = {"name", "source", "date_basis", "filters", "window", "value", "select",
                "tie_break", "null_values", "missing", "publication", "adapter"}
EVENT_FIELDS = {"name", "start", "events", "censors", "event_selection", "censor_selection",
                "same_day", "min_followup_days", "short_followup", "day_count", "time_unit",
                "days_per_unit", "missing_dates", "publication", "adapter"}


def standalone(items):
    """Adapter-bound rules execute at their existing stage, never a second time."""
    return [item for item in (items or []) if not item.get("adapter")]


def for_adapter(cfg, adapter, name=None):
    if hasattr(cfg, "roles") and "outcomes" not in cfg.roles():
        return None
    items = [item for key in KEYS for item in cfg.pack("outcomes").get(key) or []
             if item.get("adapter") == adapter and (name is None or item["name"] == name)]
    if len(items) > 1:
        raise ValueError(f"{adapter}: more than one calculation owns {name or 'this adapter'}")
    declared = cfg.pack("outcomes").get("calculation_adapters", {}).get(adapter, [])
    declared = [declared] if isinstance(declared, str) else declared
    if not items and (name in declared or name is None and declared):
        raise ValueError(f"{adapter}: required typed calculation is missing; the legacy path is retired for this product")
    if items:
        if items[0]["name"] not in declared:
            raise ValueError(f"{adapter}: the typed calculation has no mandatory adapter declaration")
        _checked(items[0])
        problems = adapter_errors(cfg, items[0])
        if problems:
            raise ValueError("; ".join(problems))
    return items[0] if items else None


def kind(item):
    return "recordValue" if "window" in item or "source" in item else "timeToEvent"


def instrument_errors(item, where="calculation", *, require_review=True):
    from engine.config_schema import _Validator, _message, _json_view, schema
    try:
        document = _json_view(item)
        base = schema()
        selected = {"$defs": base["$defs"], "$ref": "#/$defs/" + kind(item)}
        errors = [_message(error, (where,)) for error in _Validator(selected).iter_errors(document)]
        if errors:
            return errors
        if kind(item) == "recordValue":
            parse_window(item["window"], allow_named_anchor=True)
            date = item["date_basis"]
            if date["combine"] == "single" and len(date["columns"]) != 1:
                errors.append(f"{where}.date_basis.single requires exactly one column")
            value = item["value"]
            if item["select"] in {"minimum", "maximum"} and value["type"] not in {"integer", "double"}:
                errors.append(f"{where}: minimum/maximum requires a numeric value")
            if "transform" in value and value["type"] != "double":
                errors.append(f"{where}: scale/offset transformation requires double output")
            bounds = value.get("valid_range")
            if bounds:
                if value["type"] == "string":
                    errors.append(f"{where}: valid_range requires a numeric value")
                lo, hi = bounds["minimum"], bounds["maximum"]
                if lo is None and hi is None:
                    errors.append(f"{where}: valid_range needs at least one bound")
                if lo is not None and hi is not None and (lo > hi or
                        (lo == hi and not (bounds["include_minimum"] and bounds["include_maximum"]))):
                    errors.append(f"{where}: empty valid_range")
            for f in item["filters"]:
                if f["values"] and len({"number" if type(v) in {int, float} else type(v).__name__ for v in f["values"]}) > 1:
                    errors.append(f"{where}: filter values must have one type")
            dtype = "integer" if item["select"] in {"count", "any"} else value["type"]
            for field, literal in item["missing"].items():
                if literal is None:
                    continue
                valid = (isinstance(literal, str) if dtype == "string" else
                         type(literal) is int and -(2**31) <= literal < 2**31 if dtype == "integer" else
                         type(literal) in {int, float})
                if not valid:
                    errors.append(f"{where}.missing.{field} must be null or a {dtype} literal")
        else:
            if not item.get("adapter") and (item["min_followup_days"] is None or
                    any(e["offset_days"] is None for e in item["events"] + item["censors"])):
                errors.append(f"{where}: choose follow-up and offsets; null thresholds require a declared upstream eligibility adapter")
            if item["time_unit"] == "day" and item["days_per_unit"] != 1:
                errors.append(f"{where}: day output requires days_per_unit=1")
            for field in ("events", "censors"):
                names = [entry["name"].casefold() for entry in item[field]]
                if len(names) != len(set(names)):
                    errors.append(f"{where}.{field}: reasons must have distinct names")
        publication = item.get("publication")
        if publication:
            if publication["scale"] > publication["precision"]:
                errors.append(f"{where}: publication scale must not exceed precision")
            if kind(item) == "recordValue" and item["value"]["type"] == "string" and item["select"] not in {"count", "any"}:
                errors.append(f"{where}: decimal publication requires a numeric result")
        return errors
    except (ValueError, TypeError, KeyError) as error:
        return [f"{where}: {error}"]


def errors(cfg):
    result = []
    for key in KEYS:
        items = cfg.pack("outcomes").get(key) or []
        if not isinstance(items, list):
            result.append(f"outcomes.{key} must be a list")
            continue
        for i, item in enumerate(items):
            result.extend(instrument_errors(item, f"outcomes.{key}[{i}]"))
    if result:
        return result
    bound = {}
    for key in KEYS:
        for item in cfg.pack("outcomes").get(key) or []:
            if not isinstance(item, dict) or not item.get("adapter"):
                continue
            pair = (item["adapter"], item.get("name"))
            if pair in bound:
                result.append(f"Repeated adapter calculation {pair}")
            bound[pair] = item
    declarations = cfg.pack("outcomes").get("calculation_adapters", {})
    if not isinstance(declarations, dict):
        return ["calculation_adapters must be a mapping of adapter names to calculation lists"]
    declared = set()
    for adapter, names in declarations.items():
        if not isinstance(names, list) or not names or any(not isinstance(n, str) for n in names) or len(set(names)) != len(names):
            result.append(f"calculation_adapters.{adapter} needs distinct calculation names")
            continue
        declared.update((adapter, name) for name in names)
    if set(bound) != declared:
        result.append("Typed adapter declarations and calculations differ; missing rules cannot fall back to legacy calculations")
    for item in bound.values():
        result.extend(adapter_errors(cfg, item))
    return result


def adapter_errors(cfg, item):
    """Refuse unsupported source/presentation adapters, never approximate them.

    These adapters preserve a migrated product's source preparation. They are not
    alternate implementations of its selector or duration calculation.
    """
    adapter, name = item["adapter"], item["name"]
    clinical = cfg.pack("clinical") if "clinical" in cfg.roles() else {}
    outcome = cfg.pack("outcomes")
    reason = None
    if adapter == "baseline_ecog":
        blk = clinical.get(adapter) or {}
        if (name != "ecog_grade" or item["source"] != "baseline_ecog" or
            item["date_basis"]["columns"] != ["ecogdate"] or item["value"]["column"] != "ecogvalue" or
            item["value"]["type"] != "integer" or blk.get("equidistant")):
            reason = "ECOG adapter requires its integer grade and date-first ties"
    elif adapter == "lab_values":
        from engine.clinical_panels import iter_panels
        matches = [(blk, p) for _, _, blk in iter_panels(clinical, ("lab_values",))
                   for p in blk.get("panel", []) if p["name"] + "v" == name]
        if len(matches) != 1:
            reason = "lab adapter must own exactly one declared panel output"
        else:
            blk, panel = matches[0]
            if (item["source"] != blk["source"] or panel.get("units") or panel.get("unit_conversions") or
                item["window"]["start"] is not None or item["window"]["end"] is not None):
                reason = "lab adapter currently supports unbounded panels without unit conversions"
    elif adapter == "psa_timepoints":
        blk = clinical.get(adapter) or {}
        matches = [p for p in blk.get("points", []) if p["name"] == name]
        if len(matches) != 1 or matches[0].get("anchor") or item["source"] != blk.get("source"):
            reason = "PSA adapter requires one index-relative declared timepoint"
    else:
        prefix = "os" if adapter == "overall_survival" else "pfs"
        cols = [prefix + "_death"] if prefix == "os" else ["pfs_progression", "pfs_death"]
        if (not outcome.get(adapter) or name != prefix or item["start"] != prefix + "_start" or
            [x["column"] for x in item["events"]] != cols or
            [x["column"] for x in item["censors"]] != [prefix + "_censor"] or
            item["min_followup_days"] is not None):
            reason = "endpoint adapter requires its declared prepared dates and upstream follow-up eligibility"
        elif prefix == "pfs":
            expected = "priority" if outcome[adapter].get("semantics") == "contract" else "earliest"
            if (item["event_selection"] != expected or item["events"][0]["offset_days"] != outcome[adapter]["exclusion_days"] or
                item["events"][0]["include_offset"]):
                reason = "rwPFS rule disagrees with its progression eligibility or decision-staged event order"
        if not reason and any(x["offset_days"] is not None for x in item["censors"] + item["events"][-1:]):
            reason = "legacy endpoint adapter must retain unbounded prepared death/censor dates until reviewed"
    if adapter in {"baseline_ecog", "lab_values", "psa_timepoints"} and item["window"]["anchor"] != "index_date":
        reason = "this source adapter is index-relative"
    return [f"{adapter}.{name}: {reason}"] if reason else []


def output_columns(item):
    name = item.get("name", "")
    if kind(item) == "recordValue":
        dtype = "integer" if item.get("select") in {"count", "any"} else item.get("value", {}).get("type", "double")
        fields = [("value", "", dtype), ("date", "dt", "date"),
                  ("count", "n", "integer"), ("status", "status", "string")]
    else:
        fields = [("time", "", "double"), ("date", "dt", "date"), ("flag", "fl", "integer"),
                  ("event_reason", "event", "string"), ("censor_reason", "censor", "string"),
                  ("status", "status", "string")]
    if item.get("publication"):
        import math
        pub = item["publication"]
        digits = [pub.get(k) for k in ("precision", "scale")] if isinstance(pub, dict) else []
        # Draft editors call this before all choices are filled. Execution still
        # requires the complete schema through _checked().
        complete = len(digits) == 2 and all(type(n) in {int, float} and math.isfinite(n) and n == int(n) for n in digits)
        dtype = f"decimal({int(digits[0])},{int(digits[1])})" if complete else "decimal"
        fields[0] = (fields[0][0], "", dtype)
    return [{"name": name + suffix, "type": dtype, "result": result} for result, suffix, dtype in fields]


def _publish(F, frame, item):
    """Only the selected result is rounded; overflow never becomes missing data."""
    if not item.get("publication"):
        return frame
    name = item["name"]
    dtype = output_columns(item)[0]["type"]
    cast = F.expr(f"try_cast(`{name}` as {dtype})")
    if frame.where(F.col(name).isNotNull() & cast.isNull()).limit(1).count():
        raise ValueError(f"{name}: publication overflow for {dtype}")
    return frame.withColumn(name, cast)


def emitted(items):
    return {col["name"] for item in (items or []) for col in output_columns(item)}


def requires(item):
    """Long-source columns for an observation; assembled columns for an event."""
    if kind(item) == "recordValue":
        return sorted((set(item.get("date_basis", {}).get("columns", [])) |
                      {item.get("value", {}).get("column", "")} |
                      {f.get("column", "") for f in item.get("filters", [])} |
                      {item.get("value", {}).get("transform", {}).get("unit_column", "")}) - {""})
    return sorted({item.get("start", "")} | {entry.get("column", "")
                  for key in ("events", "censors") for entry in item.get(key, [])} - {""})


def dependencies(item):
    return [item.get("window", {}).get("anchor", "")] if kind(item) == "recordValue" else requires(item)


def dependency_errors(cfg, available):
    available = {name.casefold() for name in available}
    result = []
    for key in KEYS:
        for item in standalone(cfg.pack("outcomes").get(key)):
            if instrument_errors(item):
                continue
            absent = set(name.casefold() for name in dependencies(item)) - available
            overlap = {name.casefold() for name in emitted([item])} & available
            if absent:
                result.append(f"outcomes.{key}[{item['name']}]: unavailable date dependencies {', '.join(sorted(absent))}; put their producers first")
            if overlap:
                result.append(f"outcomes.{key}[{item['name']}]: output collision {', '.join(sorted(overlap))}")
            available.update(name.casefold() for name in emitted([item]))
    return result


def earlier_stage_errors(cfg):
    """Late outputs cannot be consumed by stages that have already executed."""
    outputs = set().union(*(emitted(standalone(cfg.pack("outcomes").get(key))) for key in KEYS))
    if not outputs:
        return []
    checks = []
    for role, key in (("clinical", "derived"), ("outcomes", "ads_derived")):
        for item in cfg.pack(role).get(key) or []:
            checks.append((f"{role}.{key}[{item.get('name')}]", item.get("requires") or []))
    outcomes = cfg.pack("outcomes")
    for item in outcomes.get("risk_scores") or []:
        checks.append(("outcomes.risk_scores", [part.get("column") for part in item.get("components") or []]))
    for item in outcomes.get("modality_relations") or []:
        checks.append(("outcomes.modality_relations", [item.get(k) for k in ("a_start_column", "a_end_column", "b_start_column", "b_end_column")]))
    survival = outcomes.get("overall_survival") or {}
    checks.append(("outcomes.overall_survival", [survival.get(k) for k in ("event_flag", "death_anchor", "censor_anchor", "gate")]))
    folded = {name.casefold() for name in outputs}
    return [f"{where}: reads {name} before its typed calculation executes; use an earlier producer or a time_to_events consumer"
            for where, names in checks for name in names if isinstance(name, str) and name.casefold() in folded]


def reads(cfg):
    from . import read
    result = []
    for item in cfg.pack("outcomes").get("record_values") or []:
        bad = instrument_errors(item)
        if bad:
            raise ValueError("; ".join(bad))
        result.append(read(item["source"], ["patientid", *requires(item)],
                           "outcomes.record_values." + item["name"]))
    return result


def _checked(item):
    bad = instrument_errors(item)
    if bad:
        raise ValueError("CALCULATION REFUSED: " + "; ".join(bad))


def _dates(frame, columns, where):
    from pyspark.sql.types import DateType
    for name in columns:
        if name not in frame.columns:
            raise ValueError(f"{where}: date column {name} is unavailable at this step")
        if not isinstance(frame.schema[name].dataType, DateType):
            raise ValueError(f"{where}: {name} must be a DATE; review its source date parser first")


def value_in_window(F, source, frame, item, *, cohort_keys=False):
    """Select deterministically; flags/counts distinguish no record from null value."""
    from pyspark.sql import Window
    _checked(item)
    name, w = item["name"], parse_window(item["window"], allow_named_anchor=True)
    _dates(frame, [w.anchor, "index_date"], name)
    needed = {"patientid", *requires(item)}
    if needed - set(source.columns):
        raise ValueError(f"{name}: source columns missing: {sorted(needed - set(source.columns))}")
    keys = ["patientid", "index_date"]
    source_keys = keys if cohort_keys else ["patientid"]
    if cohort_keys:
        _dates(source, ["index_date"], name)
    rows = source
    for condition in item["filters"]:
        col, op, vals = F.col(condition["column"]), condition["operator"], condition["values"]
        predicate = {"in": lambda: col.isin(vals), "not_in": lambda: ~col.isin(vals),
                     "is_null": col.isNull, "is_not_null": col.isNotNull}[op]()
        rows = rows.where(predicate)
    basis = item["date_basis"]
    from pyspark.sql.types import StringType, DateType, TimestampType
    date_cols = []
    for column in basis["columns"]:
        dtype = source.schema[column].dataType
        parsed_date = F.expr(f"try_cast(`{column}` as date)")
        if isinstance(dtype, StringType):
            parsed_date = F.when(F.col(column).rlike(r"^\d{4}-\d{2}-\d{2}$") & (F.length(F.col(column)) == 10), parsed_date)
        elif not isinstance(dtype, (DateType, TimestampType)):
            raise ValueError(f"{name}: {column} needs a full date or timestamp, not {dtype}")
        date_cols.append(parsed_date)
    invalid = F.lit(False)
    for column, parsed in zip(basis["columns"], date_cols):
        invalid = invalid | (F.col(column).isNotNull() & parsed.isNull())
    # Restrict error checks to this cohort's patients; unrelated records cannot
    # make this cohort fail. Bad source values are never silently repaired.
    rows = rows.join(frame.select(*source_keys).distinct(), source_keys, "inner")
    if basis["invalid"] == "refuse" and rows.where(invalid).limit(1).count():
        raise ValueError(f"{name}: invalid source date; correct it or explicitly exclude invalid dates")
    date = date_cols[0] if len(date_cols) == 1 else (F.least(*date_cols) if basis["combine"] == "earliest" else F.greatest(*date_cols))
    date = F.when(~invalid, date)
    if basis["nulls"] == "require_all":
        complete = F.lit(True)
        for col in date_cols:
            complete = complete & col.isNotNull()
        date = F.when(complete, date)
    value = item["value"]
    dtype = value["type"]
    parsed = F.expr(f"try_cast(`{value['column']}` as {dtype})")
    # Spark integer casts truncate decimals. Refuse that loss as a failed cast.
    if dtype == "integer":
        number = F.expr(f"try_cast(`{value['column']}` as double)")
        parsed = F.when(number == parsed.cast("double"), parsed)
    if dtype == "double":
        parsed = F.when(~F.isnan(parsed) & (F.abs(parsed) != float("inf")), parsed)
    if value["invalid"] == "refuse" and rows.where(F.col(value["column"]).isNotNull() & parsed.isNull()).limit(1).count():
        raise ValueError(f"{name}: unusable {dtype} value; review the value parser")
    transform = value.get("transform")
    if transform:
        unit = F.col(transform["unit_column"])
        if rows.where(unit.isNull() | (unit != transform["input_unit"])).limit(1).count():
            raise ValueError(f"{name}: mixed or missing units; filter to the reviewed input unit before conversion")
        parsed = parsed * F.lit(transform["scale"]) + F.lit(transform["offset"])
        finite = ~F.isnan(parsed) & (F.abs(parsed) != float("inf"))
        if rows.where(parsed.isNotNull() & ~finite).limit(1).count():
            raise ValueError(f"{name}: unit conversion produced a non-finite value")
    rows = rows.select(*source_keys, date.alias("_date"), parsed.alias("_value"), F.lit(1).alias("_record"))
    acceptable = F.lit(True)
    bounds = value.get("valid_range")
    if bounds:
        col = F.col("_value")
        if bounds["minimum"] is not None:
            acceptable = acceptable & (col >= bounds["minimum"] if bounds["include_minimum"] else col > bounds["minimum"])
        if bounds["maximum"] is not None:
            acceptable = acceptable & (col <= bounds["maximum"] if bounds["include_maximum"] else col < bounds["maximum"])
        acceptable = col.isNull() | acceptable
    # Preserve source existence, but exclude out-of-range values before ranking.
    rows = rows.withColumn("_acceptable", acceptable)
    base = frame.select(*keys, F.col(w.anchor).alias("_anchor"))
    rows = base.join(rows, source_keys, "left")
    lo, hi = w.offsets()
    eligible = F.col("_date").isNotNull() & F.col("_anchor").isNotNull()
    gap = F.datediff("_date", "_anchor")
    if lo is not None:
        eligible = eligible & (gap >= lo)
    if hi is not None:
        eligible = eligible & (gap <= hi)
    rows = rows.withColumn("_eligible", eligible).withColumn("_gap", F.abs(gap))
    counts = rows.groupBy(*keys).agg(F.count("_record").alias("_records"),
        F.sum(F.when(eligible, 1).otherwise(0)).alias("_candidates"),
        F.sum(F.when(eligible & F.col("_acceptable"), 1).otherwise(0)).alias("_accepted"),
        F.sum(F.when(eligible & F.col("_acceptable") & F.col("_value").isNotNull(), 1).otherwise(0)).alias("_usable"))
    candidates = rows.where("_eligible AND _acceptable")
    if item["null_values"] == "exclude":
        candidates = candidates.where(F.col("_value").isNotNull())
    select, tie = item["select"], item["tie_break"]
    order = {"closest": [F.col("_gap").asc()], "earliest": [F.col("_date").asc()],
             "latest": [F.col("_date").desc()], "minimum": [F.col("_value").asc_nulls_last()],
             "maximum": [F.col("_value").desc_nulls_last()], "count": [], "any": []}[select]
    order.append(F.col("_date").asc() if tie["date"] == "earliest" else F.col("_date").desc())
    partition = Window.partitionBy(*keys).orderBy(*order)
    if tie["value"] == "refuse" and select not in {"count", "any"}:
        first = candidates.withColumn("_rank", F.dense_rank().over(partition)).where("_rank=1")
        # struct keeps null as a distinct candidate value.
        if first.groupBy(*keys).agg(F.countDistinct(F.struct("_value")).alias("_n")).where("_n>1").limit(1).count():
            raise ValueError(f"{name}: conflicting tied values; choose an explicit value tie-break")
    order.append(F.col("_value").desc_nulls_last() if tie["value"] == "highest" else F.col("_value").asc_nulls_last())
    selected = candidates.withColumn("_rank", F.row_number().over(Window.partitionBy(*keys).orderBy(*order)))
    selected = selected.where("_rank=1").select(*keys, "_date", "_value")
    result = base.join(counts, keys, "left").join(selected, keys, "left")
    status = (F.when(F.col("_anchor").isNull(), "no_anchor")
              .when(F.col("_records") == 0, "no_record")
              .when(F.col("_candidates") == 0, "out_of_window")
              .when(F.col("_value").isNull(), "present_null").otherwise("present"))
    n = F.col("_usable") if item["null_values"] == "exclude" else F.col("_accepted")
    if select in {"count", "any"}:
        delivered = n if select == "count" else F.when(n > 0, 1).otherwise(0)
        status = F.when(n > 0, "present").otherwise(status)
        # Explicit missing policies still apply to an absent/out-of-window source.
    else:
        delivered = F.col("_value")
    result = result.withColumn("_status", status)
    for state, replacement in item["missing"].items():
        delivered = F.when(F.col("_status") == state, F.lit(replacement)).otherwise(delivered)
    out_type = "integer" if select in {"count", "any"} else dtype
    result = result.select(*keys, delivered.cast(out_type).alias(name),
        (F.lit(None).cast("date") if select in {"count", "any"} else F.col("_date")).alias(name + "dt"),
        F.col("_candidates").cast("integer").alias(name + "n"), F.col("_status").alias(name + "status"))
    return frame.join(_publish(F, result, item), keys, "left")


def time_to_event(F, frame, item):
    _checked(item)
    name, start = item["name"], F.col(item["start"])
    _dates(frame, requires(item), name)

    def choose(entries, policy):
        candidates = []
        for i, entry in enumerate(entries):
            col = F.col(entry["column"])
            days = F.datediff(col, start)
            valid = col.isNotNull() if entry["offset_days"] is None else (days >= entry["offset_days"] if entry["include_offset"] else days > entry["offset_days"])
            candidates.append(F.when(valid, F.struct(col.alias("date"), F.lit(i).alias("priority"), F.lit(entry["name"]).alias("reason"))))
        if policy == "priority":
            return F.coalesce(*candidates)
        # Struct ordering picks the earliest listed reason when dates tie.
        if policy == "earliest":
            return F.least(*candidates) if len(candidates) > 1 else candidates[0]
        latest_date = F.greatest(*(c["date"] for c in candidates)) if len(candidates) > 1 else candidates[0]["date"]
        return F.coalesce(*(F.when(c["date"] == latest_date, c) for c in candidates))

    event = choose(item["events"], item["event_selection"])
    censor = choose(item["censors"], item["censor_selection"])
    work = frame.withColumn("_rwd_event", event).withColumn("_rwd_censor", censor)
    e, c = F.col("_rwd_event"), F.col("_rwd_censor")
    wins = e.isNotNull() & (c.isNull() | (e["date"] <= c["date"] if item["same_day"] == "event" else e["date"] < c["date"]))
    end = F.when(wins, e["date"]).otherwise(c["date"])
    event_flag = F.when(wins, 1).otherwise(0)
    elapsed = F.datediff(end, start)
    short = F.lit(False) if item["min_followup_days"] is None else elapsed < item["min_followup_days"]
    if item["short_followup"] == "retain_events":
        short = short & ~wins
    status = (F.when(start.isNull(), "no_start").when(end.isNull(), "no_end")
              .when(short, "short_followup").when(wins, "event").otherwise("censored"))
    if item["missing_dates"] == "refuse" and work.where(start.isNull() | end.isNull()).limit(1).count():
        raise ValueError(f"{name}: no valid start/end date for one or more cohort members")
    valid = start.isNotNull() & end.isNotNull() & ~short
    duration = (elapsed + (1 if item["day_count"] == "inclusive" else 0)) / F.lit(item["days_per_unit"])
    result = (work.withColumn(name, F.when(valid, duration).cast("double"))
            .withColumn(name + "dt", F.when(valid, end))
            .withColumn(name + "fl", F.when(valid, event_flag).cast("integer"))
            .withColumn(name + "event", F.when(valid & wins, e["reason"]))
            .withColumn(name + "censor", F.when(valid & ~wins, c["reason"]))
            .withColumn(name + "status", status).drop("_rwd_event", "_rwd_censor"))
    return _publish(F, result, item)


def build(F, sources, frame, cfg):
    bad = errors(cfg)
    if bad:
        raise ValueError("CALCULATIONS REFUSED: " + "; ".join(bad))
    bad = dependency_errors(cfg, frame.columns)
    if bad:
        raise ValueError("CALCULATIONS REFUSED: " + "; ".join(bad))
    items = [(key, item) for key in KEYS for item in standalone(cfg.pack("outcomes").get(key))]
    if not items:
        return frame
    if {"_rwd_event", "_rwd_censor"} & set(frame.columns):
        raise ValueError("Reserved calculation scratch columns already exist")
    if frame.groupBy("patientid", "index_date").count().where("count > 1").limit(1).count():
        raise ValueError("Calculations require one row per patient and cohort index date")
    if frame.where(F.col("patientid").isNull() | F.col("index_date").isNull()).limit(1).count():
        raise ValueError("Calculations require non-null patient and cohort index keys")
    for key, item in items:
        if key == "record_values":
            if item["source"] not in sources:
                raise ValueError(f"{item['name']}: missing source {item['source']}")
            frame = value_in_window(F, sources[item["source"]], frame, item)
        else:
            frame = time_to_event(F, frame, item)
    return frame
