"""Stage: treatment variables. Ports trt_var_creation().

The per-line category (lotcat / lotcatn) is compiled from codelists/treatment_categories.yaml
via engine.codelists.compile_case — first-match-wins, exactly like the R case_when. new_lot_n
comes from the shared lot stage. Line-count banding and prior-taxane params live in
variables/treatment.yaml.

Built per cohort against that cohort's index rows: `base` is one row per patient per cohort
(overall -> 1 index/patient; lotN -> the line-N index), so the per-line frames (one row per
patient after de-dup) are attached on patientid without leaking lines across cohort index rows.
"""
from __future__ import annotations

from engine import grain

from engine.codelists import compile_case
from engine.config import line_categories_enabled, native_treatment_enabled
from . import lot as lot_stage


def _lot_bands_case(bands, col, key="label"):
    """CASE over lot_count_bands (eq/ge with a fallthrough). Builds lotngrl / lotngrln."""
    def q(s):
        return "'" + str(s).replace("'", "''") + "'"
    whens, default = [], None
    for b in bands:
        out = q(b[key]) if key == "label" else str(b[key])
        if b.get("when") == "fallthrough":
            default = out
            continue
        conds = []
        if "eq" in b:
            conds.append(f"{col} = {b['eq']}")
        if "ge" in b:
            conds.append(f"{col} >= {b['ge']}")
        if conds:
            whens.append(f"WHEN {' AND '.join(conds)} THEN {out}")
    tail = f" ELSE {default}" if default is not None else ""
    return "CASE " + " ".join(whens) + tail + " END"


def categorize_line(df, codelist, label_col="lotcat", code_col="lotcatn"):
    """Add lotcat/lotcatn columns to a per-line DataFrame using the compiled CASE."""
    from pyspark.sql import functions as F
    label_sql, code_sql = compile_case(codelist)
    return (df.withColumn(label_col, F.expr(label_sql))
              .withColumn(code_col, F.expr(code_sql)))


def line_cols(i, maint=False):
    """Per-line column names emitted by build() for line i — the SINGLE source of truth so consumers
    (engine/stages/outcomes.py line outcomes) reference the SAME names. Mirrored in engine-r/stages.R.

      name     lot{i}     linename
      start    lot{i}sd   line start (startdate)
      end      lot{i}ld   line end (enddate)
      lastdate lot{i}ed   line "last activity" = max drug-episode date (R `loted`); the time-to-event
                          outcomes (vis120/TTD/TTNT) key off THIS, not the enddate.

    `maint=True` returns the MAINTENANCE-line variants (lot{i}m / lot{i}msd / lot{i}mld / lot{i}med),
    emitted only for tumors with maintenance cohorts so a lot{i}m cohort's maintenance line is
    described by its own columns (the non-maintenance lot{i}* prefers the non-maintenance row).
    """
    s = "m" if maint else ""
    return {"name": f"lot{i}{s}", "start": f"lot{i}{s}sd",
            "end": f"lot{i}{s}ld", "lastdate": f"lot{i}{s}ed", "dur": f"lot{i}{s}dur",
            "cat": f"lot{i}{s}cat", "catn": f"lot{i}{s}catn"}


def emitted_line_columns(cfg):
    """Every per-line lot{i}* column the treatment stage emits for a tumor: the base set (name / start /
    end / last-activity / category / category-code) for lines 1..max_lines, plus the lot{i}m* maintenance
    variants when the tumor has maintenance cohorts. SINGLE source of truth shared by build()'s per-line
    loop, validate.emitted_variables, and the catalog `line_template` expansion (tests/test_catalog.py),
    so the ADS contract for these columns can't drift from what the engine emits."""
    if not native_treatment_enabled(cfg):
        return []
    maxl = int(cfg.pack("treatment").get("max_lines", 0))
    maint = any(c.get("maintenance") is not None for c in cfg.cohorts)
    cols = []
    for i in range(1, maxl + 1):
        cols += [v for k, v in line_cols(i, False).items() if line_categories_enabled(cfg) or k not in {"cat", "catn"}]
        if maint:
            cols += [v for k, v in line_cols(i, True).items() if line_categories_enabled(cfg) or k not in {"cat", "catn"}]
    return cols


def emitted_count_columns(cfg):
    """Actual treatment count columns, independent of the per-line publication limit.

    The treatment build always creates lotn from the declared LOT source and
    adds the label/code pair only when lot_count_bands is configured. A missing
    band block is not an active count-group capability.
    """
    from engine.config import is_non_oncology
    if is_non_oncology(cfg) or not native_treatment_enabled(cfg) or "lot" not in cfg.sources:
        return []
    columns = ["lotn"]
    if cfg.pack("treatment").get("lot_count_bands"):
        columns.extend(("lotngrl", "lotngrln"))
    return columns


def _drug_category_column(codelist):
    """Source column the classifier's `category_equals` reads — config-driven (match_on.drug_category_column),
    default 'detaileddrugcategory'. Same resolution the compiler (codelists.compile_case) and validate.py use,
    so the treatment stage can't hardcode a name the rest of the pipeline lets a codelist override."""
    return (codelist.get("match_on") or {}).get("drug_category_column", "detaileddrugcategory")


def _category_equals_values(codelist):
    """Drug-category values the classifier tests via `category_equals`, in codelist order (first-match-wins),
    lower-cased to match the compiled predicate. Empty when the codelist never uses category_equals."""
    vals = []
    for cat in codelist.get("categories", []):
        v = (cat.get("match") or {}).get("category_equals")
        if v is not None:
            v = str(v).lower()
            if v not in vals:
                vals.append(v)
    return vals


def _line_frame(F, Window, rows, i, maint, mc, epi, codelist, telemetry=None, cohort=None):
    """One deterministic per-line frame: pick a single line-i row (prefer non-maintenance then
    earliest start for the lot{i}* set; maintenance rows only for lot{i}m*), attach the last-activity
    date (lot{i}ed), and emit name/start/end/lastdate/cat/catn under the maint-aware names.
    Telemetry (opt-in): the candidate pool is this line's rows; a same-start-date tie is decided by
    the maintenance-first / earliest-end / name order this function owns."""
    c = line_cols(i, maint)
    cat_col = _drug_category_column(codelist) if codelist is not None else None
    order = []
    if not maint and mc in rows.columns:
        order.append(F.col(mc).asc_nulls_last())          # 'False' < 'True' -> non-maintenance first
    order += [F.col("startdate").asc_nulls_last(), F.col("enddate").asc_nulls_last(),
              F.col("linename").asc_nulls_last()]
    # `detaileddrugcategory` LAST. Every other emitted field is either in the order above or keyed
    # on the constant `linenumber`, but the LOT-native category is neither — so when the
    # `drug_episode` aggregate supplies none and two line-i rows agree on maintenance, start, end
    # and name, the published `cat`/`catn` came from whichever row the shuffle placed first.
    if cat_col and cat_col in rows.columns:
        order.append(F.col(cat_col).asc_nulls_last())
    if telemetry is not None:
        telemetry.record_selection(F, rows, ("patientid",), "startdate",
                                   cohort, "treatment_lines", c["name"])
    pick = (rows.withColumn("_rn", F.row_number().over(Window.partitionBy("patientid").orderBy(*order)))
            .filter(F.col("_rn") == 1))
    if epi is not None and "linenumber" in pick.columns:
        # epi is already scoped to this cohort's setting (build() filters drug_episode before aggregating),
        # and lot_norm is single-setting too, so the join keys on (patientid, linenumber) — the same grain
        # the pre-B1 loted join used. Drop the LOT-native category ONLY when the episode aggregate supplies
        # its own (avoids an ambiguous column AND lets episode win); if epi carries no category — a pack
        # whose drug_episode lacks detaileddrugcategory — keep the LOT-native one instead of losing it.
        if cat_col in epi.columns and cat_col in pick.columns:
            pick = pick.drop(cat_col)
        pick = pick.join(epi, ["patientid", "linenumber"], "left")
        lastdate = F.coalesce(F.col("_lastdate"), F.col("enddate"))
    else:
        lastdate = F.col("enddate")
    # the drug-category column feeds the (unchanged) category classifier; source it from the episode join
    # when present, else a typed null so the compiled CASE stays valid for a tumor without drug-episode data.
    columns = ["patientid",
                       F.col("linename").alias(c["name"]),
                       F.col("startdate").alias(c["start"]),
                       F.col("enddate").alias(c["end"]),
                       lastdate.alias(c["lastdate"]),
                       # lot{i}dur (days) keys off lot{i}ed (last-activity), which falls back to the line
                       # enddate when the line has no drug-episode row — so dur is enddate-based, not null,
                       # in that case (deliberate, same fallback as lot{i}ed; the spec computes it from loted).
                       (F.datediff(lastdate, F.col("startdate")) + 1).alias(c["dur"])]
    if codelist is not None:
        cat_val = F.col(cat_col) if cat_col in pick.columns else F.lit(None).cast("string")
        columns += ["linename", cat_val.alias(cat_col)]
    line = pick.select(*columns)
    if codelist is not None:
        line = categorize_line(line, codelist, label_col=c["cat"], code_col=c["catn"])
        line = line.drop("linename", cat_col)
    if telemetry is not None:
        # output_rows = patients WITH this line (the frame is left-joined by the caller), so
        # non_null vs output_rows reads "of the lines picked, how many carry a name"
        telemetry.record_selection_outputs(F, line, [(c["name"], c["name"])],
                                           cohort, "treatment_lines")
    return line


def _taxane_pred(likes):
    """SQL predicate: linename matches ANY taxane LIKE pattern (lower-cased). Mirrored in cases.R
    (taxane_pred) and proven byte-identical in tests/test_r_parity.py."""
    return " OR ".join(f"lower(linename) LIKE '{str(x).lower()}'" for x in likes)


def _prior_taxane(F, trt, idx, lot_norm, src, pt, cohort):
    """prior_tax_mcrpc (cohort-aware) [+ prior_tax_pre_mcrpc when a pre-mCRPC line source is set].

    prior_tax_mcrpc: for a line cohort N>=2, 'Yes' if any PRIOR mCRPC line (new_lot_n in 1..N-1) is a
    taxane, else 'No'; the 1L cohort is NA (no prior line); the overall cohort is 'No'. (R keys a
    case_when on coh_flag x new_lot_n, then fills NA->No for non-1L — this computes the filled value
    directly. new_lot_n < N already implies the line started on/before the line-N index.)
    prior_tax_pre_mcrpc (optional): 'Yes' if any line in the configured pre-mCRPC line source started
    on/before index and is a taxane, else 'No'. Skipped unless `pre_mcrpc_source` names a declared
    source (the R's enh_pros_pano_non_mcrpc) — so other tumors / an unmapped source simply omit it.
    """
    yes, no = pt.get("yes_label", "Yes"), pt.get("no_label", "No")
    pred = _taxane_pred(pt["drug_name_like_any"])
    ln = (cohort or {}).get("lot_number")
    if ln is None:                                       # overall cohort -> No
        trt = trt.withColumn("prior_tax_mcrpc", F.lit(no))
    elif ln == 1:                                        # 1L cohort -> not applicable (NA)
        trt = trt.withColumn("prior_tax_mcrpc", F.lit(None).cast("string"))
    else:                                                # N>=2: any prior line (1..N-1) a taxane?
        prior = (lot_norm.filter((F.col("new_lot_n") >= 1) & (F.col("new_lot_n") < ln))
                 .filter(F.expr(f"({pred})"))
                 .select("patientid").distinct().withColumn("_ptm", F.lit(1)))
        trt = (trt.join(prior, "patientid", "left")
               .withColumn("prior_tax_mcrpc",
                           F.when(F.col("_ptm").isNotNull(), F.lit(yes)).otherwise(F.lit(no)))
               .drop("_ptm"))

    pre_name = pt.get("pre_mcrpc_source")
    if pre_name and pre_name in src:                     # optional pre-mCRPC lines table
        pre = src[pre_name].select("patientid", "linename", "startdate")
        ppt = (idx.select("patientid", "index_date").join(pre, "patientid", "inner")
               .filter(F.col("startdate") <= F.col("index_date"))
               .filter(F.expr(f"({pred})"))
               .select("patientid").distinct().withColumn("_ptp", F.lit(1)))
        trt = (trt.join(ppt, "patientid", "left")
               .withColumn("prior_tax_pre_mcrpc",
                           F.when(F.col("_ptp").isNotNull(), F.lit(yes)).otherwise(F.lit(no)))
               .drop("_ptp"))
    return trt


def _prior_pred(fl):
    """SQL predicate for a generic prior-treatment flag: `like_any` (OR of linename LIKE) or `all_of`
    (AND of like_any groups — e.g. NHA AND ADT present in the same line). linename is lower-cased.
    Mirrored in engine-r/stages.R::prior_pred."""
    def likes(xs):
        return " OR ".join(f"lower(linename) LIKE '{str(x).lower()}'" for x in xs)
    if fl.get("all_of"):
        return " AND ".join(f"({likes(grp)})" for grp in fl["all_of"])
    return likes(fl["like_any"])



def _prior_treatments_episode(F, trt, idx, src, ptcfg, yes, no):
    """The G-PRIOR-TX episode model: flags read DRUG-EPISODE rows STRICTLY before index (an
    episode ON index day is not prior - the ledger's acceptance), at episode/regimen
    granularity. `like_any`/`all_of` test the episode drug name (all_of within ONE line:
    NHA-and-ADT means one regimen carried both); `category_equals` tests the declared
    category column (chemo is a delivered CATEGORY, not a name list somebody maintains);
    `monotherapy: true` requires a line whose prior episodes ALL match - a PARP beside a
    taxane is not PARP monotherapy. Declared means present: absent sources or columns
    refuse by name. == engine-r/stages.R::treatment_prior_treatments_episode."""
    esrc = ptcfg["source"]
    de = src.get(esrc)
    if de is None:
        raise ValueError(f"BUILD REFUSED - prior_treatments reads source {esrc!r}, which "
                         f"this run was not given ({sorted(src)}).")
    nc, dc = ptcfg.get("name_column"), ptcfg.get("date_column")
    if not (nc and dc):
        raise ValueError("prior_treatments: the episode model needs `name_column` and "
                         "`date_column` - a source with unnamed columns reads nothing.")
    cat_col = ptcfg.get("category_column")
    flags = ptcfg["flags"]
    need_line = any(f.get("monotherapy") or f.get("all_of") for f in flags)
    need_cols = ["patientid", nc, dc] + ([cat_col] if any(
        f.get("category_equals") for f in flags) and cat_col else []) + (
        ["linenumber"] if need_line else [])
    missing = [c for c in need_cols if c and c not in de.columns]
    if missing:
        raise ValueError(f"BUILD REFUSED - {esrc!r} lacks column(s) {missing} that the "
                         f"declared prior-treatment flags read.")
    pre = (idx.select("patientid", "index_date").join(de, "patientid", "inner")
           .filter(F.col(dc) < F.col("index_date")))     # STRICT: on-index is not prior

    def _likes(xs):
        return " OR ".join(f"lower({nc}) LIKE '{str(x).lower()}'" for x in xs)

    for fl in flags:
        ce = fl.get("category_equals")
        if ce is not None:
            if not cat_col:
                raise ValueError(f"{fl['name']}: category_equals is declared and the block "
                                 f"names no `category_column` - a category filter cannot "
                                 f"read an unnamed column.")
            pred = f"lower({cat_col}) = '{str(ce).lower()}'"
        else:
            pred = _likes(fl.get("like_any") or [x for g in fl.get("all_of") for x in g])
        if fl.get("all_of"):
            # every group matched WITHIN ONE LINE - a regimen that carried both
            aggs = [F.max(F.expr(f"CASE WHEN ({_likes(g)}) THEN 1 ELSE 0 END"))
                    .alias(f"_g{j}") for j, g in enumerate(fl["all_of"])]
            per = pre.groupBy("patientid", "index_date", "linenumber").agg(*aggs)
            cond = " AND ".join(f"_g{j} = 1" for j in range(len(fl["all_of"])))
            hit = per.filter(F.expr(cond)).select("patientid", "index_date").distinct()
        elif fl.get("monotherapy"):
            # a line whose PRIOR episodes ALL match: min over the line = 1
            per = (pre.groupBy("patientid", "index_date", "linenumber")
                   .agg(F.min(F.expr(f"CASE WHEN ({pred}) THEN 1 ELSE 0 END")).alias("_all")))
            hit = per.filter(F.col("_all") == 1).select("patientid", "index_date").distinct()
        else:
            hit = pre.filter(F.expr(f"({pred})")).select("patientid", "index_date").distinct()
        hit = hit.withColumn("_h", F.lit(1))
        trt = (trt.join(hit, ["patientid", "index_date"], "left")
               .withColumn(fl["name"],
                           F.when(F.col("_h").isNotNull(), F.lit(yes)).otherwise(F.lit(no)))
               .drop("_h"))
    return trt

def _prior_treatments(F, trt, idx, src, cfg, ptcfg):
    """Generic prior-treatment Yes/No flags (prostate PRIOR_PLUVICTO / PARP / CHEMO / DOCETAXEL /
    ABIRATERONE / ARPI / NHA_ADT): for each flag, Yes if the patient has ANY line of therapy (ANY
    setting) that started on/before index and matches the flag's predicate, else No. Cohort-independent
    — 'prior to index' spans both the mHSPC and mCRPC settings, so the LOT model is read with NO setting
    filter. == engine-r/stages.R::treatment_prior_treatments.
    """
    from . import lot as lot_stage
    yes, no = ptcfg.get("yes_label", "Yes"), ptcfg.get("no_label", "No")
    if ptcfg.get("source"):
        # G-PRIOR-TX: a declared source selects the episode model; no declaration keeps the
        # legacy LOT-name model below byte-identical for every other pack
        return _prior_treatments_episode(F, trt, idx, src, ptcfg, yes, no)
    lot_all = lot_stage.normalized(src, None,            # ALL settings (prior tx spans mHSPC + mCRPC)
                                   exclude_settings=cfg.lot_exclude_settings,
                                   line_number_col=cfg.lot_line_number_col,
                                   maintenance_column=cfg.lot_maintenance_column)
    pre = (idx.select("patientid", "index_date").join(lot_all, "patientid", "inner")
           .filter(F.col("startdate") <= F.col("index_date")))
    for fl in ptcfg["flags"]:
        hit = (pre.filter(F.expr(f"({_prior_pred(fl)})")).select("patientid", "index_date").distinct()
               .withColumn("_h", F.lit(1)))
        trt = (trt.join(hit, ["patientid", "index_date"], "left")
               .withColumn(fl["name"], F.when(F.col("_h").isNotNull(), F.lit(yes)).otherwise(F.lit(no)))
               .drop("_h"))
    return trt


def _conmed_exposures(F, trt, idx, src, ccfg):
    """Concomitant / supportive-care medication exposure Yes/No flags (prostate BP / CSF / STEROID):
    for each flag, Yes if the patient has ANY matching medication record (optionally within window_days
    of index; null/null = any time), else No — by drug-name LIKE patterns over a medication source. The
    whole block is skipped if the source or its name column is absent (config-level, so all cohorts in a
    product agree -> column-aligned). == engine-r/stages.R::treatment_conmed_exposures.
    """
    csrc = src.get(ccfg.get("source"))
    nc, dc = ccfg.get("name_column"), ccfg.get("date_column")
    if csrc is None or nc not in csrc.columns:
        return trt
    yes, no = ccfg.get("yes_label", "Yes"), ccfg.get("no_label", "No")
    lo, hi = (ccfg.get("window_days") or [None, None])
    pulled = idx.select("patientid", "index_date").join(csrc, "patientid", "inner")
    if dc in csrc.columns and lo is not None:
        pulled = pulled.filter(F.col(dc) >= F.expr(f"date_add(index_date, {lo})"))
    if dc in csrc.columns and hi is not None:
        pulled = pulled.filter(F.col(dc) <= F.expr(f"date_add(index_date, {hi})"))
    for fl in ccfg["flags"]:
        pred = " OR ".join(f"lower({nc}) LIKE '{str(p).lower()}'" for p in fl["like_any"])
        hit = (pulled.filter(F.expr(f"({pred})")).select("patientid", "index_date").distinct()
               .withColumn("_h", F.lit(1)))
        trt = (trt.join(hit, ["patientid", "index_date"], "left")
               .withColumn(fl["name"], F.when(F.col("_h").isNotNull(), F.lit(yes)).otherwise(F.lit(no)))
               .drop("_h"))
    return trt


def _setting_line_columns(F, src, idx, cfg, slc):
    """Per-SETTING line columns (LOT*_MHSPC / LOT*_MCRPC): for each configured setting, the chosen line
    attributes (sd=start / ed=end / name) per line number, suffixed _<setting-lowercased>, so EVERY
    cohort carries both settings' line detail regardless of its own setting. The LOT is renumbered within
    each setting (the same per-setting model the line cohorts use). == engine-r/stages.R::
    treatment_setting_line_columns.
    """
    from . import lot as lot_stage
    col_map = {"sd": "startdate", "ed": "enddate", "name": "linename"}
    attrs = [a for a in slc.get("attributes", ["sd", "name"]) if a in col_map]
    lines_cfg = slc.get("lines", 2)
    de = src.get("drug_episode")
    out = idx.select("patientid", "index_date")
    for setting in slc.get("settings", []):
        suffix = str(setting).lower()
        # G-PER-SETTING-LOT: `lines` may map per setting (2 mHSPC / 4 mCRPC). A setting the
        # map does not name is REFUSED, never defaulted - a count nobody declared is not 2.
        if isinstance(lines_cfg, dict):
            if setting not in lines_cfg:
                raise ValueError(
                    f"treatment.setting_line_columns: `lines` maps per setting and names no "
                    f"entry for {setting!r} - declare it or use a single shared count.")
            n_lines = int(lines_cfg[setting])
        else:
            n_lines = int(lines_cfg)
        norm = lot_stage.normalized(src, setting, exclude_settings=cfg.lot_exclude_settings,
                                    line_number_col=cfg.lot_line_number_col,
                                    maintenance_column=cfg.lot_maintenance_column)
        # G-SETTING-LOT-ED: the setting columns' `ed` carries the SAME contract the main
        # lot{i}ed has since B1 - the latest drug-episode date within the line, setting-scoped,
        # coalesced to the LOT enddate when the line has no episodes; without a usable
        # drug_episode source the enddate fallback stands (a tumor/vendor lacking episode
        # data still builds). A configured setting with no linesetting column to scope by
        # REFUSES rather than combining episodes across settings - B1's own refusal.
        if "ed" in attrs and de is not None and {"linenumber", "episodedate"} <= set(de.columns):
            if "linesetting" not in de.columns:
                raise ValueError(
                    f"treatment.setting_line_columns: setting {setting!r} is configured but "
                    f"drug_episode has no 'linesetting' column to scope the per-line ed "
                    f"aggregate - this would combine episodes across settings.")
            epi = (de.filter(F.col("linesetting") == setting)
                   .groupBy("patientid", "linenumber")
                   .agg(F.max("episodedate").alias("_ep_ed")))
            norm = (norm.join(epi, ["patientid", "linenumber"], "left")
                    .withColumn("_sl_ed", F.coalesce(F.col("_ep_ed"), F.col("enddate"))))
        else:
            norm = norm.withColumn("_sl_ed", F.col("enddate"))
        for i in range(1, n_lines + 1):
            sels = [F.col("patientid")] + [
                F.col("_sl_ed" if a == "ed" else col_map[a]).alias(f"lot{i}{a}_{suffix}")
                for a in attrs]
            li = grain.one_row_per_key(F, norm.filter(F.col("new_lot_n") == i).select(*sels),
                                       ["patientid"])
            out = out.join(li, "patientid", "left")
    return out


def uses_category_equals(match) -> bool:
    """True when a codelist match tree reads the drug-category column (category_equals) anywhere."""
    if not isinstance(match, dict):
        return False
    if "category_equals" in match:
        return True
    return any(uses_category_equals(sub) for k in ("all_of", "any_of")
               for sub in (match.get(k) or []))


def reads(cfg):
    """The treatment reads. drug_episode is engine-guarded BOTH ways it is consumed — lot{i}ed
    falls back to the line end date and the per-line category to NULL — so both reads are
    declared with their degrade named (an external review found the hardcoded `src.get(
    "drug_episode")` matched no declaration anywhere). Its columns are demanded only in the
    configurations that consume them: line outcomes on, or a codelist using category_equals."""
    if not native_treatment_enabled(cfg):
        return []
    from . import lot as lot_stage
    from . import read
    out = []
    roles = cfg.roles()
    trt_cfg = cfg.pack("treatment") if "treatment" in roles else {}
    ptm = trt_cfg.get("prior_treatments") or {}
    if ptm.get("source"):
        _cols = ["patientid", ptm.get("name_column"), ptm.get("date_column")]
        if any(f.get("category_equals") for f in ptm.get("flags") or []):
            _cols.append(ptm.get("category_column"))
        if any(f.get("monotherapy") or f.get("all_of") for f in ptm.get("flags") or []):
            _cols.append("linenumber")
        out.append(read(ptm["source"], _cols, "treatment.prior_treatments"))
    pt = trt_cfg.get("prior_taxane") or {}
    if pt.get("pre_mcrpc_source"):
        out.append(read(pt["pre_mcrpc_source"], ["patientid", "linename", "startdate"],
                        "treatment.prior_taxane"))
    ce = trt_cfg.get("conmed_exposures") or {}
    if ce.get("flags"):
        lo, hi = (ce.get("window_days") or [None, None])
        windowed = lo is not None or hi is not None
        out.append(read(ce.get("source"),
                        ["patientid", ce.get("name_column")]
                        + ([ce.get("date_column")] if windowed else []),
                        "treatment.conmed_exposures",
                        optional=([] if windowed else [ce.get("date_column")])))
    setting = ["linesetting"] if lot_stage.uses_line_setting(cfg) else []
    if (("outcomes" in roles and cfg.pack("outcomes").get("line_outcomes"))
            or (not line_categories_enabled(cfg) and int(cfg.pack("treatment").get("max_lines", 0)) > 0)):
        out.append(read("drug_episode", ["patientid", "linenumber", "episodedate"] + setting,
                        "treatment.line_last_activity", required=False,
                        when_absent="per-line last-activity (lot{i}ed) falls back to the line "
                                    "end date — vis120/TTD/TTNT then key off a coarser date"))
    try:
        cl = (cfg.codelist("treatment_categories") or {}) if line_categories_enabled(cfg) else {}
    except KeyError:                          # no codelist registered — nothing reads the category
        cl = {}
    if any(uses_category_equals(c.get("match")) for c in cl.get("categories", [])):
        cat_col = (cl.get("match_on") or {}).get("drug_category_column", "detaileddrugcategory")
        out.append(read("drug_episode",
                        ["patientid", "linenumber", "episodedate", cat_col] + setting,
                        "treatment.line_category", required=False,
                        when_absent="the per-line drug category is NULL, so category_equals "
                                    "matches nothing — lotcatn falls through"))
    return out


def build(src, idx, cfg, cohort=None, telemetry=None):
    if not native_treatment_enabled(cfg):
        return idx.select("patientid", "index_date")
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window

    # cohort LABEL for the opt-in telemetry rows only — nothing below branches on it
    _cid = (cohort or {}).get("id") or str((cohort or {}).get("cohortn"))
    trt_cfg = cfg.pack("treatment")
    codelist = cfg.codelist("treatment_categories") if line_categories_enabled(cfg) else None

    base = idx.select("patientid", "index_date")        # 1 row / patient within this cohort
    # Same LOT model as the index stage (line_number / exclude_settings) so the per-line lot<i>*
    # columns are numbered the same way the line cohorts are. No maintenance filter here (all lines).
    line_setting = (cohort or {}).get("line_setting", cfg.lot_line_setting)   # effective setting (or None)
    lot_norm = lot_stage.normalized(src, line_setting,
                                    exclude_settings=cfg.lot_exclude_settings,    # per-cohort setting
                                    line_number_col=cfg.lot_line_number_col,      # (dual-setting products)
                                    maintenance_column=cfg.lot_maintenance_column)

    # Per-line drug-episode aggregate (one row per patient+linenumber), feeding TWO things:
    #   * loted -> lot{i}ed : the latest drug-episode date within the line (max episodedate), which the
    #     outcomes time-to-event family keys off; and
    #   * detaileddrugcategory : the delivered data carries the drug category on the DrugEpisode table,
    #     NOT on LOT, so the per-line chemotherapy indicator (does ANY episode on this line have
    #     detaileddrugcategory='chemotherapy'?) is aggregated here and joined onto the line. That single
    #     synthesized column feeds lotcatn=9 "Other chemotherapy-containing" via the UNCHANGED codelist
    #     `category_equals: chemotherapy` (LOWER(detaileddrugcategory)='chemotherapy').
    # SETTING GRAIN (config-driven, not physical-column-driven): the aggregate must be scoped to the SAME
    # setting model as lot_norm, or an mHSPC line and an mCRPC line that share a linenumber would collide.
    # When a line setting is configured, FILTER drug_episode to it (mirroring lot_norm) and aggregate by
    # (patientid, linenumber); lot_norm is already single-setting, so the join keys on (patientid,
    # linenumber). When NO setting is configured (heme/COTA), aggregate + join on (patientid, linenumber)
    # as before — do NOT introduce linesetting just because the physical source happens to carry it (that
    # would fan out against a LOT frame that lacks it). OPTIONAL: without the drug_episode source (or its
    # columns) lot{i}ed falls back to the line enddate and the category is null, so a tumor/vendor lacking
    # drug-episode data still builds. Filtering before groupBy also shrinks the scan per cohort.
    de = src.get("drug_episode")
    epi = None
    if de is not None and {"linenumber", "episodedate"} <= set(de.columns):
        de_cols = set(de.columns)
        if line_setting is not None:
            # a setting IS configured -> the aggregate MUST be scoped to it. Fail loudly rather than
            # silently combine episodes across settings (preflight normally catches this, but stages can
            # be invoked directly, bypassing it).
            if "linesetting" not in de_cols:
                raise ValueError(
                    f"treatment stage: line setting {line_setting!r} is configured but drug_episode has "
                    "no 'linesetting' column to scope the per-line aggregate — this would combine episodes "
                    "across settings. Add linesetting to drug_episode, or clear the line setting.")
            de = de.filter(F.col("linesetting") == line_setting)   # scope to this cohort's setting
        # The drug-category column AND the values the classifier tests are BOTH config (the codelist), not
        # literals: read the column from match_on.drug_category_column and the values from every
        # category_equals — so a codelist that renames the column or uses a different category value stays
        # consistent between this aggregate and the compiled category_equals predicate.
        cat_col = _drug_category_column(codelist) if codelist is not None else None
        cat_values = _category_equals_values(codelist) if codelist is not None else []
        have_cat = cat_col in de_cols and bool(cat_values)
        aggs = [F.max("episodedate").alias("_lastdate")]
        if have_cat:
            # one per-line indicator per category_equals value, matched EXACTLY as the compiled predicate
            # (LOWER(cat_col) = value) so a flagged line satisfies that category once the value is joined on.
            for j, v in enumerate(cat_values):
                aggs.append(F.max(F.when(F.lower(F.col(cat_col)) == v, F.lit(1)).otherwise(F.lit(0)))
                            .alias(f"_hascat{j}"))
        epi = de.groupBy("patientid", "linenumber").agg(*aggs)
        if have_cat:
            # synthesize cat_col = the FIRST category_equals value present on the line (codelist order keeps
            # first-match-wins), else NULL — the value comes from config, never a hardcoded literal.
            synth = F.lit(None).cast("string")
            for j in range(len(cat_values) - 1, -1, -1):
                synth = F.when(F.col(f"_hascat{j}") == 1, F.lit(cat_values[j])).otherwise(synth)
            epi = epi.withColumn(cat_col, synth).drop(*[f"_hascat{j}" for j in range(len(cat_values))])
        # When drug_episode has NO category column (or the codelist uses no category_equals), epi carries
        # only _lastdate, so _line_frame keeps any LOT-native category instead of nulling it — the episode
        # aggregate is authoritative for the category ONLY when it actually sources one.

    # max LOT count per patient (lotn) + banding (lotngrl/lotngrln from config lot_count_bands).
    w = Window.partitionBy("patientid")
    lotn = (base.join(lot_norm.select("patientid", "new_lot_n"), "patientid", "left")
                # coalesce 0: raw LOTN=0 for the untreated is a REQUIREMENT (G-LOTN-ZERO,
                # scope question open, the =0 half is not); the bands already read null as
                # the fallthrough "0" - this aligns the raw column. Mirrored in stages.R.
                .withColumn("lotn", F.coalesce(F.max("new_lot_n").over(w), F.lit(0)))
                .select("patientid", "index_date", "lotn").distinct())
    bands = trt_cfg.get("lot_count_bands")
    if bands:
        lotn = (lotn.withColumn("lotngrl", F.expr(_lot_bands_case(bands, "lotn", "label")))
                    .withColumn("lotngrln", F.expr(_lot_bands_case(bands, "lotn", "code"))))

    # Per-line columns lot1..lot{max_lines}. For the linenumber model (OC/EC) a single line N can
    # have BOTH a non-maintenance and a maintenance row. lot{i}* picks ONE DETERMINISTICALLY (prefer
    # non-maintenance, then earliest start) — backward-compatible and stable. For tumors WITH
    # maintenance cohorts we ALSO emit lot{i}m* describing the maintenance row, so a lot{i}m cohort
    # (which indexes off the maintenance line) is described by its own columns instead of the
    # non-maintenance line's. (For the prostate new_lot_n model there's one row/line and no
    # maintenance column, so this is the same single lot{i}* as before.)
    mc = cfg.lot_maintenance_column
    emit_maint = mc in lot_norm.columns and any(c.get("maintenance") is not None for c in cfg.cohorts)
    trt = base
    for i in range(1, trt_cfg["max_lines"] + 1):
        li = lot_norm.filter(F.col("new_lot_n") == i)
        trt = trt.join(_line_frame(F, Window, li, i, False, mc, epi, codelist,
                                   telemetry=telemetry, cohort=_cid), "patientid", "left")
        if emit_maint:
            li_m = li.filter(F.col(mc) == "True")
            trt = trt.join(_line_frame(F, Window, li_m, i, True, mc, epi, codelist,
                                       telemetry=telemetry, cohort=_cid), "patientid", "left")

    # prior taxane (docetaxel/cabazitaxel) flags — cohort-aware, prostate-specific (optional config).
    pt = trt_cfg.get("prior_taxane")
    if pt and cohort is not None:
        trt = _prior_taxane(F, trt, idx, lot_norm, src, pt, cohort)

    # Generic prior-treatment flags (PRIOR_*) — cohort-independent (any prior line, any setting). Optional.
    ptm = trt_cfg.get("prior_treatments")
    if ptm and ptm.get("flags"):
        trt = _prior_treatments(F, trt, idx, src, cfg, ptm)

    # Concomitant/supportive-med exposure flags (BP / CSF / STEROID) — cohort-independent. Optional.
    cm = trt_cfg.get("conmed_exposures")
    if cm and cm.get("flags"):
        trt = _conmed_exposures(F, trt, idx, src, cm)

    # Per-setting line columns (LOT*_MHSPC / LOT*_MCRPC) — cohort-independent (both settings). Optional.
    slc = trt_cfg.get("setting_line_columns")
    if slc and slc.get("settings"):
        trt = trt.join(_setting_line_columns(F, src, idx, cfg, slc), ["patientid", "index_date"], "left")

    return trt.join(lotn, ["patientid", "index_date"], "left")
