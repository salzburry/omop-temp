"""Distribute this engine's Python code to classic or Connect Spark workers.

The native UDFs capture their reviewed instrument settings, so they need Python
modules only. Product files, source data, credentials and local paths are never
packaged. Installed worker dependencies remain the runtime's responsibility.
"""
from __future__ import annotations

import hashlib
import io
from pathlib import Path
import tempfile
import threading
import weakref
import zipfile

_LOCK = threading.RLock()
_DIRECTORY = None
_SESSIONS = weakref.WeakKeyDictionary()
MAX_FILES = 512
MAX_BYTES = 16 * 1024 * 1024


def needed(cfg):
    return bool((cfg.pack('outcomes') or {}).get('serial_markers') or
                (cfg.pack('outcomes') or {}).get('modality_relations') or
                (cfg.pack('treatment') or {}).get('rt_courses') or
                (cfg.pack('treatment') or {}).get('dose_exposures'))


def archive_bytes(directory=None):
    """Deterministic, bounded Python-only engine archive; never a product tree."""
    root = Path(directory or Path(__file__).parent).resolve()
    entries, size = [], 0
    for path in sorted(root.rglob('*.py')):
        relative = path.relative_to(root)
        if '__pycache__' in relative.parts or any(part.startswith('.') for part in relative.parts):
            continue
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            raise ValueError('Engine worker code must stay inside its installed package.')
        raw = path.read_bytes()
        size += len(raw)
        entries.append(('engine/' + relative.as_posix(), raw))
        if len(entries) > MAX_FILES or size > MAX_BYTES:
            raise ValueError('Engine worker code exceeds the bounded package size.')
    if not any(name == 'engine/__init__.py' for name, _ in entries):
        raise ValueError('The installed engine package is incomplete: __init__.py is missing.')
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, raw in entries:
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o444 << 16
            archive.writestr(info, raw)
    return buffer.getvalue()


def prepare(spark):
    """Ship the exact installed modules once per Spark context and code revision."""
    global _DIRECTORY
    raw = archive_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    try:
        context = spark.sparkContext
    except (AttributeError, RuntimeError, NotImplementedError):
        context = None
    owner = context if context is not None else spark
    with _LOCK:
        previous = _SESSIONS.get(owner)
        if previous == digest:
            return digest
        if previous is not None:
            raise ValueError('Engine code changed while this Spark session was running. Start a new Spark session before building; reused Python workers may still hold the previous modules.')
        if _DIRECTORY is None:
            _DIRECTORY = tempfile.TemporaryDirectory(prefix='rwdp-spark-code-')
        path = Path(_DIRECTORY.name) / ('engine_' + digest + '.zip')
        if not path.exists():
            path.write_bytes(raw)
        elif hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError('The temporary Spark engine package changed. Restart this build session.')
        if context is not None:
            context.addPyFile(str(path))
        else:
            # Connect uploads the code to its remote session; it must not assume
            # the driver's local filesystem exists on executors.
            upload = getattr(spark, 'addArtifacts', None) or getattr(spark, 'addArtifact', None)
            if not callable(upload):
                raise ValueError('This Spark runtime cannot distribute engine code. Install the matching engine package on its workers or use a Spark runtime with Python artifact support.')
            upload(str(path), pyfile=True)
        _SESSIONS[owner] = digest
    return digest
