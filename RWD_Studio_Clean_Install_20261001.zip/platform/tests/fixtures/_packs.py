"""Materialise a fixture pack as a PRODUCT, in a temp root.

`prostate/202607` was a real second spec revision that never became a product: unregistered, never
built, never released. It lived in `products/` only because several suites need a pack that has a
CONTRACT and NO CONFIG — Gate 2 done, Gate 4 not started — which is the shape a set of fail-closed
rules are about: an empty section over an empty denominator, an unstarted config reported as drift,
and which records carry to a new spec revision.

Keeping it in `products/` made it a fake product that every gate sweep, demo and status page had to
carry and explain. It now lives here, and the suites that need it DISCOVERED as a product copy it
into a temp root — real packs alongside it, because most of those assertions are about a CONTRAST
("some pack has a config and some does not") and a root holding only the fixture would make half of
each one vacuous in the direction that matters.
"""
import atexit
import os
import shutil
import tempfile
from rwd_services import workspace_root

FIXTURES = os.path.dirname(os.path.abspath(__file__))
REPO = str(workspace_root(__file__))

PARKED_REL = "platform/tests/fixtures/prostate_202607"
PARKED = os.path.join(REPO, PARKED_REL)
AS_PRODUCT = "products/oncology/prostate/202607"

_SKIP = shutil.ignore_patterns("__pycache__", "reference")
_ROOT = None


def repo_with_fixture_pack(tmp):
    """A temp repo root: the real `products/` and `governance/`, plus the parked pack.

    The pack is materialised TWICE, and both are load-bearing. `AS_PRODUCT` is what
    `product_gates.products()` has to discover — the whole reason a suite asks for this root.
    `PARKED_REL` is where `governance/precedents.yaml` cites it, and those citations have to resolve
    against this root as well; without it `precedents.load()` reports broken citations here and
    reads as a store that has gone stale.
    """
    root = os.path.join(tmp, "repo")
    #  rides along since the physical move: the vendor and source-key derivations
    # read both roots, and a temp root without the fixture packs would derive from a fraction
    # of the tumours the real one does.
    for top in ("products", "fixtures", "governance"):
        shutil.copytree(os.path.join(REPO, top), os.path.join(root, top), ignore=_SKIP)
    for rel in (AS_PRODUCT, PARKED_REL):
        shutil.copytree(PARKED, os.path.join(root, *rel.split("/")), ignore=_SKIP)
    # The as-product pack gets a PRODUCTS registry entry: the live products registry is empty
    # since the physical move, and a materialised product without one has no vendor - which is
    # not the state this root exists to model. This mirrors exactly what standing a real pack
    # up looks like: the pack under products/, its entry in products/registry.yaml.
    reg = os.path.join(root, "products", "registry.yaml")
    with open(reg, encoding="utf-8") as fh:
        doc = fh.read()
    doc = doc.replace("tumors: []",
                      'tumors:\n  - { code: mcrpc, slug: prostate, vendor: flatiron, '
                      'tumor_class: solid, status: scaffold, current_spec_version: "202607" }',
                      1)
    with open(reg, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(doc)
    return root


def materialised_root():
    """The same root for every caller in a process — the copy is ~6 MB and three suites want it."""
    global _ROOT
    if _ROOT is None:
        tmp = tempfile.mkdtemp(prefix="rwdp-fixture-pack-")
        atexit.register(shutil.rmtree, tmp, ignore_errors=True)
        _ROOT = repo_with_fixture_pack(tmp)
    return _ROOT
