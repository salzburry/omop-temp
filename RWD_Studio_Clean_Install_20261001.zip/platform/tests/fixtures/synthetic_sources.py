"""Tiny synthetic source frames for ANY configured product — the ONE definition.

There were two. `tools/smoke_prostate.py` carried a copy whose own docstring said it was "copied
verbatim from platform/tests/test_smoke_spark.py", and by the time anyone checked the two had
DIVERGED — `_synth_src` 37 lines against 48, `_augment` 7 against 9. So the standalone demo built a
different dataset than the one CI proves, and its output would have been shown as evidence of a
build nobody had verified. Exactly the failure docs/ENGINEERING.md opens with, in the one place where the
result gets put on a screen.

DRIVEN BY THE CONFIG, never by a tumour name. The declared sources, the index model's `of` columns,
the distinct cohort line settings and the preflight contract's `required_columns()` decide what gets
built, so a new product is covered by being configured rather than by editing this file.

MEANINGFUL where the stages key on it (line setting, race, death granularity), "1" or a date
everywhere else — enough for the closest-to-index panel paths to actually execute.

Import-safe without pyspark: everything that needs it is imported inside the functions.
"""
from datetime import date, timedelta


SQL_TYPES = {name: name for name in ("string", "int", "bigint", "double", "float", "date", "boolean", "smallint", "tinyint")}


def sql_cell(value, kind):
    """Encode a typed synthetic value; never interpolate an unescaped SQL string."""
    sql_type = SQL_TYPES[kind]
    if value is None:
        return f"CAST(NULL AS {sql_type})"
    if kind == "date":
        return f"DATE'{date.fromisoformat(str(value)).isoformat()}'"
    if kind in {"int", "bigint", "smallint", "tinyint"}:
        return f"CAST({int(value)} AS {sql_type})"
    if kind in {"double", "float"}:
        return f"CAST('{float(value)!r}' AS {sql_type})"
    if kind == "boolean":
        return "true" if value else "false"
    # Hex preserves apostrophes, backslashes, newlines and Unicode regardless of
    # Spark's escapedStringLiterals setting. No fixture value becomes SQL syntax.
    return f"CAST(X'{str(value).encode('utf-8').hex()}' AS STRING)"


def frame(spark, table):
    """The conformance fixture's typed SQL VALUES constructor, shared by all lanes.

    Local Python rows otherwise launch a worker for every source partition. The
    composed Windows golden spent most of its execution waiting for those workers;
    these identical literal rows stay in the JVM. Actual engine stages are unchanged.
    """
    columns, kinds, rows = table["columns"], table["types"], table["rows"]
    if not columns or len(columns) != len(kinds) or any(len(row) != len(columns) for row in rows):
        raise ValueError("Synthetic row widths must match the declared columns and types.")
    for kind in kinds:
        if kind not in SQL_TYPES:
            raise ValueError(f"Unsupported synthetic SQL type: {kind}")
    quoted = ["`" + column.replace("`", "``") + "`" for column in columns]
    if not rows:
        casts = ", ".join(f"CAST(NULL AS {SQL_TYPES[kind]}) AS {column}" for column, kind in zip(quoted, kinds))
        return spark.sql(f"SELECT {casts} WHERE 1=0")
    values = ", ".join("(" + ", ".join(sql_cell(value, kind) for value, kind in zip(row, kinds)) + ")" for row in rows)
    return spark.sql(f"SELECT * FROM (VALUES {values}) AS t({', '.join(quoted)})")


def rows_frame(spark, rows, columns, *, types=None):
    """Infer only the simple fixture types; explicit types support all-null columns."""
    if types is None:
        types = []
        for index in range(len(columns)):
            values = [row[index] for row in rows if row[index] is not None]
            if not values:
                raise ValueError("An empty or all-null fixture column needs an explicit type.")
            kinds = {"boolean" if isinstance(value, bool) else "bigint" if isinstance(value, int)
                     else "double" if isinstance(value, float) else "date" if isinstance(value, date)
                     else "string" if isinstance(value, str) else "unsupported" for value in values}
            if len(kinds) != 1 or "unsupported" in kinds:
                raise ValueError("Synthetic fixture columns must have one supported type.")
            types.append(kinds.pop())
    return frame(spark, {"columns": columns, "types": types, "rows": rows})


def checkpoint_sources(frames):
    """Short JVM leaves for literal fixtures, retaining their exact values and schema.

    The seven-cohort UAT otherwise spends minutes in Catalyst DeduplicateRelations
    walking repeated augmentation/SQL alias trees before it can execute a row.
    A lazy local checkpoint truncates that fixture lineage without Python transport
    or an eager job for each tiny source. The owning Spark session releases blocks.
    Production source readers and all derivation stages remain unchanged.
    """
    return {name: source.localCheckpoint(eager=False) for name, source in frames.items()}


def augment(df, cols, d1):
    """Add every column `cols` names that `df` lacks. A date-named column gets a date, else "1"."""
    from pyspark.sql import functions as F
    have = {c.lower() for c in df.columns}
    for c in cols:
        if c.lower() not in have:
            # a date-named column gets a date (covers dateofmetastasis / *date), else "1"
            is_date = "date" in c.lower() and "granularity" not in c.lower()
            df = df.withColumn(c, F.lit(d1) if is_date else F.lit("1"))
    return df


def stage_probe(groups):
    """The delivered-style sub-stage this fixture feeds `groupstage`, or None.

    A NAMED FUNCTION so the regression test can call it instead of recomputing it. The test that
    guarded this value re-derived the token selection itself and asserted on its own arithmetic —
    which passes forever, whatever the fixture does. Two copies of a rule, and the one under test
    was the copy.
    """
    tokens = [str(v).strip() for g in (groups or [])
              for v in (g.get("from_prefixes") or g.get("from_startswith_ci") or [])
              if str(v).strip()]
    if not tokens:
        return None
    # The first token that reads as a STAGE, not merely the first token — prostate lists a `0`
    # group first, and `0B1` is visually junk where `IB1` is a sub-stage a reader recognises.
    first = next((v for v in tokens if any(c.isalpha() for c in v)), tokens[0])
    return f"{first}B1"


def sources(s, cfg):
    """{source name: DataFrame} covering every source `cfg` declares."""
    from pyspark.sql import functions as F
    from engine.validate import required_columns        # deferred: needs pyyaml (present by now)
    d1, d2 = date(2020, 1, 1), date(2020, 6, 1)
    # one LOT line per DISTINCT cohort line_setting, so a dual-setting product's mHSPC AND mCRPC line
    # cohorts each have data (a single global-setting line would never exercise lot1_mhspc indexing).
    settings = sorted({c.get("line_setting") for c in cfg.cohorts} - {None}) or [cfg.lot_line_setting or "x"]
    # ...AND one dedicated patient per configured LINE cohort, reaching exactly that cohort's line
    # in that cohort's setting, with the MAINTENANCE variant on line N when the cohort asks for it.
    # An SIT proved what the single-line fixture could not show: every 2L+/maintenance cohort of
    # OC, EC, DLBCL and mCRC built STRUCTURALLY and carried ZERO rows — `lot.normalized` filters
    # `ismaintenancetherapy == "True"/"False"`, which the fixture never wrote, and no patient ever
    # reached line 2 — and the smoke asserted only "builds without error", so the line-cohort code
    # paths had no row-level coverage at all. The smoke now asserts every configured cohort is
    # non-empty, and these patients are what makes that assertion satisfiable.
    lot_rows = [("p1", "drug", st, d1, 1, d2, "chemotherapy", "False") for st in settings]
    for c in cfg.cohorts:
        n = c.get("lot_number")
        if not n:
            continue
        st = c.get("line_setting", cfg.lot_line_setting) or settings[0]
        pid = f"pc{c['cohortn']}"
        for i in range(1, int(n) + 1):
            start = d1 + timedelta(days=30 * (i - 1))
            maint = "True" if (i == int(n) and c.get("maintenance")) else "False"
            lot_rows.append((pid, "drug", st, start, i, start + timedelta(days=20),
                             "chemotherapy", maint))
    table = {
        "lot": (["patientid", "linename", "linesetting", "startdate", "linenumber", "enddate",
                 "detaileddrugcategory", "ismaintenancetherapy"],
                lot_rows),
        "demographics": (["patientid", "birthyear", "race", "ethnicity"],
                         [("p1", "1960", "White", "Not Hispanic or Latino")]),
        "mortality": (["patientid", "dateofdeath"], [("p1", "2021-01")]),
        "baseline_ecog": (["patientid", "ecogdate", "ecogvalue"], [("p1", d1, "1")]),
        "visit": (["patientid", "visitdate"], [("p1", d2)]),
        "telemed": (["patientid", "visitdate"], [("p1", d2)]),
        "orals": (["patientid", "enddate", "startdategranularity"], [("p1", d2, "Month")]),
        "alphabet": (["patientid", "administrationdate"], [("p1", d2)]),
        "provenge": (["patientid", "startdate"], [("p1", d2)]),
    }
    req = required_columns(cfg)
    # staging reads `groupstage` from its source (default the index source); required_columns()
    # doesn't list it, so make sure that source carries it too.
    stcfg = cfg.pack("clinical").get("staging") or {}
    stage_value = None
    if stcfg.get("groups"):
        st_src = stcfg.get("source", cfg.index_source)
        req.setdefault(st_src, ["patientid"]).append("groupstage")
        # A DELIVERED-STYLE SUB-STAGE, not the generic "1" `augment` would otherwise supply.
        #
        # This mattered more than it looks. With "1" the value matches no group and lands in the
        # fallthrough, so the build printed `stage=CHECK/99` — which proves the fallthrough works
        # and nothing else. It was read (by me, on a page shown to somebody) as proof of
        # G-STAGE-PREFIX, the gap where `IB1` should collapse to `I`. A fixture that cannot
        # distinguish "unmapped value" from "prefix operator missing" must not be cited for either.
        #
        # Derived from the pack's OWN first configured stage token plus a sub-stage suffix, so it
        # is realistic for any tumour rather than a prostate literal. Under `from_prefixes` (exact
        # IN) it falls through — the real gap, visible. Under `from_startswith_ci` it resolves —
        # the fix, equally visible. Either way the cell now means something.
        # The first token that reads as a STAGE, not merely the first token. Prostate lists a `0`
        # group first, so "first configured" gave `0B1` — arithmetically the same demonstration and
        # visually junk, which is worse than useless on a page: a reader dismisses it as bad data
        # rather than seeing a delivered sub-stage the configuration cannot classify. Preferring a
        # token containing a letter gives `IB1`, and falls back to the first for a value set that
        # has no such token.
        stage_value = stage_probe(stcfg["groups"])

    src = {}
    for name in cfg.sources:
        cols, rows = table.get(name, (["patientid"], [("p1",)]))
        df = augment(rows_frame(s, rows, cols), req.get(name, []), d1)
        if stage_value and name == stcfg.get("source", cfg.index_source):
            df = df.withColumn("groupstage", F.lit(stage_value))
        src[name] = df

    # Index source: patientid + the union of every index_dates model's `of` columns, with EACH model
    # materialized as a column (advanceddiagnosisdate / hspcdiagnosisdate / …) exactly as sources.load
    # does — so a dual-setting product's mHSPC cohorts resolve their setting-specific anchor.
    isrc = cfg.index_source
    allof = sorted({c.lower() for rule in (cfg.index_dates or {}).values() for c in (rule.get("of") or [])})
    # EVERY minted patient, not just p1: a line cohort's index INNER-joins the setting's diagnosis
    # date, so a per-cohort LOT patient absent from the index source indexes nothing and the cohort
    # is empty again — the exact silence the per-cohort patients exist to end.
    pids = ["p1"] + [f"pc{c['cohortn']}" for c in cfg.cohorts if c.get("lot_number")]
    idf = rows_frame(s, [tuple([p] + [d1] * len(allof)) for p in pids], ["patientid"] + allof)
    for key, rule in (cfg.index_dates or {}).items():
        cols = [c.lower() for c in (rule.get("of") or [])]
        if cols:
            expr = F.greatest(*[F.col(c) for c in cols]) if len(cols) > 1 else F.col(cols[0])
            idf = idf.withColumn(key.replace("_", ""), expr)
    idf = augment(idf, req.get(isrc, []), d1)
    if stage_value and stcfg.get("source", cfg.index_source) == isrc:
        idf = idf.withColumn("groupstage", F.lit(stage_value))
    src[isrc] = idf
    return checkpoint_sources(src)


def session(app="rwdp-synthetic"):
    """A local Spark tuned for this fixture, and the one non-obvious setting explained.

    NO AUTO-BROADCAST. The 7-cohort production-union build died with `OutOfMemoryError: Java heap
    space` inside `UnsafeHashedRelation.read` — DESERIALISING BROADCAST HASH RELATIONS, not
    processing data. These sources are a handful of rows, so every one of them is under the
    broadcast threshold; the build joins them dozens of times, and in `local[1]` the driver and the
    executor are the same JVM holding every relation at once. More heap only moves the cliff.

    It does NOT weaken anything. Broadcast-vs-sort-merge is a PHYSICAL plan choice; the join
    semantics, and so every row and column produced, are identical. Production builds its own
    session on a real cluster and is untouched.

    NO 22MB PLAN STRINGS. The second OOM in this harness was not data either. The prostate
    seven-cohort union's ANALYZED PLAN measures 22,473,531 characters over 54,241 nodes — measured,
    on this fixture, at commit 8304ab4 — because `build_ads` repeats the LOT and treatment work once
    per cohort before unioning. Adaptive execution stringifies the physical plan on every plan
    update to post it to the SQL listener, and building that string is where the driver died:
    `OutOfMemoryError` inside `StringConcat.toString` under `QueryExecution.explainString`, not in
    any operator. Capping the rendered length costs nothing real — nobody reads a 22MB plan — and
    removes a cliff that has nothing to do with what is being tested.

    It is a HARNESS fix and not a masked defect: the plan size is a genuine finding, it is what the
    reusable patient-line dimension exists to reduce, and production builds its own session on a
    real cluster. What it must not do is let a suite's PASS depend on which other suites ran first.
    """
    from pyspark.sql import SparkSession
    # `spark.driver.memory` here is a SILENT NO-OP in a python-launched local gateway: the JVM
    # is already running when builder configs apply, so the heap stays at Spark's 1g default.
    # Discovered by the first real local execution (the seven-cohort build OOMed at 1g while
    # this line said 3g). Set PYSPARK_SUBMIT_ARGS="--driver-memory 4g pyspark-shell" in the
    # ENVIRONMENT instead — the gateway reads that before launch. The config stays for the
    # spark-submit path, where it does work.
    return (SparkSession.builder.master("local[1]").appName(app)
            .config("spark.sql.shuffle.partitions", "1")
            .config("spark.driver.memory", "3g")
            .config("spark.sql.autoBroadcastJoinThreshold", "-1")
            .config("spark.sql.maxPlanStringLength", "16384")
            # THE FOUR PRODUCTION PINS, so a suite tests the dialect production runs rather than
            # whichever the installed Spark defaults to. `resources/products.yml` sets the same
            # four on every cluster and `test_runtime_pinning.py` holds the two lists together.
            # Without these, CI's Spark 4 ran ANSI-on against a production cluster that runs
            # ANSI-off: a cast that nulls in production raised in CI, on identical data.
            .config("spark.sql.session.timeZone", "UTC")
            .config("spark.sql.ansi.enabled", "false")
            .config("spark.sql.legacy.timeParserPolicy", "CORRECTED")
            .config("spark.sql.caseSensitive", "false")
            .getOrCreate())
