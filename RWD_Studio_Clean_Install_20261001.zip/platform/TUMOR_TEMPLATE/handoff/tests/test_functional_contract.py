#!/usr/bin/env python3
"""<TUMOR> <YYYYMM> — the shared functional-contract lint, run against this product.

The shared invariants live in `platform/tools/contract_lint.py` and are product-agnostic. This file
supplies only what is genuinely this product's: where it is, and how much it currently has.

FLOORS are parser-regression guards. A silent parser break looks exactly like "the file got smaller",
so the numbers are stated rather than inferred. Raise them as the product grows; never lower one to
make a run pass — a drop is the signal.

Run: python3 test_functional_contract.py (or pytest).
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PRODUCT = os.path.dirname(os.path.dirname(HERE))


from rwd_tools.contract_lint import main, run

# Start at zero: a new product genuinely has no decisions, gaps OR RECORDS yet — the template ships
# FUNCTIONAL_CONTRACT.md empty on purpose, and a floor of one record turned every freshly copied
# pack red before its first `contract_record.py --apply` (eleventh verdict). Raise each floor as the
# product grows: `records: 1` the day the first record lands.
FLOORS = {"decisions": 0, "gaps": 0, "records": 0}


def test_functional_contract():
    contract = os.path.join(PRODUCT, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(contract):
        # Nothing to lint yet. A product folder can legitimately exist before its contract does; a red
        # test here would say "broken" where the truth is "not started".
        import pytest
        pytest.skip("no handoff/FUNCTIONAL_CONTRACT.md yet — contract not started for this product")
    errors, n = run(PRODUCT, FLOORS)
    assert not errors, "\n".join([f"{len(errors)} contract-lint violation(s):"] + errors)
    assert n >= FLOORS["records"], f"only {n} records parsed"


if __name__ == "__main__":
    sys.exit(main(PRODUCT, FLOORS))
