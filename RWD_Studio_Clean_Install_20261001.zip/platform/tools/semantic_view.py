#!/usr/bin/env python3
"""The tumour's semantic view — one conceptual layer, per-dataset implementations, ruled pooling.

    python3 platform/tools/semantic_view.py fixtures/oncology/prostate/202606
    python3 platform/tools/semantic_view.py <pack> --format json
    python3 platform/tools/semantic_view.py <pack> --pooling rwpfs flatiron optum_mc

WHY THIS EXISTS. "Define a tumour-specific semantic view (cohorts + key variables + derivation
rules); each dataset gets its own implementation; everyone designs against the same spec." The
pack already IS that: the contract carries the variables and their derivations, the source
contract carries the implementation, the registry carries the vendor. This tool assembles the
view — and adds the one axis the pitch leaves out, which decides whether the idea is safe:
CROSS-DATASET EQUIVALENCE. Two implementations of one variable are not automatically the same
construct (EHR-documented progression vs claims-proxied progression), and a layer that maps
both to one name without saying so manufactures false comparability.

So pooling is FAIL-CLOSED: a (variable, source, source) pair has the state a ruling in
governance/EQUIVALENCE_RULINGS.yaml gives it, and NO ruling means NOT ESTABLISHED — do not
pool, route the question to Science/DataExpert. Rulings are a named person's dated act; this tool reads
them and never writes one, exactly as the naming registry treats its rulings.
"""
import argparse
import json
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))

from rwd_tools import contract_lint as cl # noqa: E402
from rwd_tools import product_gates as pg # noqa: E402
from rwd_tools.spec_extract import repo_relative # noqa: E402

RULINGS = os.path.join(ROOT, "governance", "EQUIVALENCE_RULINGS.yaml")
VOCAB = ("same_construct", "accepted_proxy", "not_comparable")
# decision_id REQUIRED: the reasoning and its authentication surface live in the decisions
# register — an equivalence ruling floating free of it is a scientific position with no record
# of how it was reached.
NEED = ("variable", "source_a", "source_b", "ruling", "ruled_by", "ruling_date",
        "decision_id", "decision_object_uuid", "decision_event_sha256")
# decision_pack + decision_row_sha256 remain SUPPLEMENTARY provenance - checked when
# present, never the primary semantic authority (the sealed decision event is).


STATUS_WORDS = ("OPEN", "RESOLVED", "WITHDRAWN", "SUPERSEDED")


def _known_decision_ids(root=ROOT, pack_scope=None):
    """{decision id: {"statuses": set, "text": every register row's own words, lowered}}
    — the vocabulary a ruling's decision_id must come from, WITH the status cell (thirty-fifth: an
    existing but OPEN decision approved an equivalence), AND the row text (the verdict's
    update: an unrelated RESOLVED decision authorized an arbitrary pair — a decision that
    never mentions the variable it is said to have settled settled nothing about it)."""
    import glob as _glob # noqa: PLC0415
    ids = {}
    scopes = None if pack_scope is None else {str(p).replace("\\", "/").strip("/") for p in pack_scope}
    for base in ("products", "fixtures"):
        registers = (_glob.glob(os.path.join(root, base, "*", "*", "*", "handoff", "DECISIONS.md"))
                     if scopes is None else [os.path.join(root, p, "handoff", "DECISIONS.md")
                                             for p in sorted(scopes) if p.startswith(base + "/")])
        for reg in registers:
            try:
                text = open(reg, encoding="utf-8").read()
            except OSError:
                continue
            for line in text.splitlines():
                mline = re.match(r"^\|\s*([A-Z][A-Z0-9-]{2,})\s*\|", line)
                if not mline:
                    continue
                cells = [c.strip() for c in line.strip().strip("|").split("|")]
                status = cells[-1].upper() if cells else ""
                info = ids.setdefault(mline.group(1), {"statuses": set(), "text": ""})
                info["statuses"].add(status if status in STATUS_WORDS else "")
                info["text"] += " " + line.lower()
    return ids


def _register_row(pack, did, root=ROOT):
    """The register row for `did` in `pack`'s own DECISIONS.md, or None — {status,
    question, text}. a follow-up review: a ruling could cite any register anywhere, so
    the binding names the PACK whose register carries the reasoning, and the row is read
    from exactly there."""
    reg = os.path.join(root, pack, "handoff", "DECISIONS.md")
    try:
        text = open(reg, encoding="utf-8").read()
    except OSError:
        return None
    for line in text.splitlines():
        m = re.match(r"^\|\s*(" + re.escape(did) + r")\s*\|", line)
        if not m:
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        status = cells[-1].upper() if cells else ""
        return {"status": status if status in STATUS_WORDS else "",
                "question": cells[1] if len(cells) > 1 else "",
                "row": line.strip(),
                "text": line.lower()}
    return None


def decision_row_digest(pack, did, root=ROOT):
    """sha256 over the register row's question cell as it stands — what a ruling's
    `decision_row_sha256` must equal, so a ruling can never outlive the question it
    relied on (the same discipline the answer forms carry as question_sha256)."""
    import hashlib # noqa: PLC0415
    row = _register_row(pack, did, root=root)
    if row is None:
        return None
    return hashlib.sha256(row["row"].encode("utf-8")).hexdigest()


def rulings(path=None, known_ids=None, root=None, pack_scope=None):
    """(accepted rulings, problems). Every refusal is a PROBLEM, never a silent not-count —
    a malformed ruling that quietly stopped counting would un-rule a pair nobody re-asked.
    `known_ids` is the decision vocabulary; None scans the live registers."""
    root = ROOT if root is None else root
    path = RULINGS if path is None else path
    doc, err = pg.read_yaml(path)
    if err:
        return [], [f"{repo_relative(path)}: {err}"]
    good, problems = [], []
    if known_ids is None and (doc or {}).get("rulings"):
        known_ids = _known_decision_ids(root=root, pack_scope=pack_scope)
    scopes = None if pack_scope is None else {str(p).replace("\\", "/").strip("/") for p in pack_scope}
    for i, r in enumerate((doc or {}).get("rulings") or []):
        # A scoped projection cannot inspect another product's decision register
        # or sealed events merely because its concept has the same name.
        if scopes is not None and (not isinstance(r, dict) or r.get("decision_pack") not in scopes):
            continue
        where = f"ruling[{i}]"
        missing = [f for f in NEED if not str(r.get(f) or "").strip()]
        if missing:
            problems.append(f"{where}: leaves {', '.join(missing)} unstated — a ruling names "
                            f"the variable, both sources, the word, the person and the date")
            continue
        if r["ruling"] not in VOCAB:
            problems.append(f"{where}: ruling {r['ruling']!r} is not in the vocabulary "
                            f"{VOCAB} — an invented word is not a ruling")
            continue
        why = pg.not_a_person(r["ruled_by"])
        if why:
            problems.append(f"{where}: ruled_by {r['ruled_by']!r}: {why}")
            continue
        why = pg.bad_date(r["ruling_date"])
        if why:
            problems.append(f"{where}: ruling_date {r['ruling_date']!r}: {why}")
            continue
        if r["ruling"] == "accepted_proxy" and not str(r.get("note") or "").strip():
            problems.append(f"{where}: accepted_proxy with no note — a proxy without its "
                            f"documented divergence is a same_construct claim wearing a hedge")
            continue
        # THE PRIMARY AUTHORITY IS THE SEALED DECISION EVENT (ratified design): the
        # answer carries a STRUCTURED equivalence_outcome in this same closed vocabulary,
        # sealed in the ledger, and agreement is machine-checked - outcome, variable and
        # source pair - with no prose interpretation anywhere.
        from rwd_tools import event_ledger as _el                                          # noqa: PLC0415
        d_obj = str(r.get("decision_object_uuid") or "")
        d_sha = str(r.get("decision_event_sha256") or "")
        if not _el.UUID4.match(d_obj):
            problems.append(f"{where}: decision_object_uuid is not a uuid4")
            continue
        newest = None
        for _seq, _fn in _el._event_files(root, d_obj):
            _ev, _err = _el.read_event(root, d_obj, _fn)
            if not _err and isinstance(_ev, dict) and _ev.get("action") != "attested":
                newest = _ev
        if newest is None:
            problems.append(f"{where}: decision object {d_obj} holds no lifecycle event "
                            f"- seal the answer first (decision_record record-event)")
            continue
        if str(newest.get("object_kind")) != "decision":
            problems.append(f"{where}: {d_obj} is a {newest.get('object_kind')}, not a "
                            f"decision")
            continue
        if str(newest.get("event_sha256")) != d_sha:
            problems.append(f"{where}: the decision moved past this ruling's reference "
                            f"(head {str(newest.get('event_sha256'))[:12]}..., ruling "
                            f"cites {d_sha[:12]}...) - superseded or re-answered; re-read "
                            f"the decision and re-rule against its current head")
            continue
        if str(newest.get("action")) != "answered":
            problems.append(f"{where}: the decision's newest act is "
                            f"{newest.get('action')!r} - a superseded or withdrawn "
                            f"decision authorizes nothing")
            continue
        eq = (newest.get("payload") or {}).get("equivalence")
        if not isinstance(eq, dict) or not str(eq.get("equivalence_outcome") or ""):
            problems.append(f"{where}: the sealed answer carries no structured "
                            f"equivalence_outcome - the decision was not answered as an "
                            f"equivalence question; raise or re-answer it with the "
                            f"structured block")
            continue
        if str(eq.get("equivalence_outcome")) != str(r["ruling"]):
            problems.append(f"{where}: outcome disagreement - the sealed answer says "
                            f"{eq.get('equivalence_outcome')!r} and this ruling says "
                            f"{r['ruling']!r}; the ruling records the decision, never "
                            f"overrides it")
            continue
        if str(eq.get("variable")).strip().lower() != str(r["variable"]).strip().lower():
            problems.append(f"{where}: the sealed answer settles variable "
                            f"{eq.get('variable')!r}, not {r['variable']!r}")
            continue
        want_pair = {str(eq.get("source_a")).strip().lower(),
                     str(eq.get("source_b")).strip().lower()}
        got_pair = {str(r["source_a"]).strip().lower(),
                    str(r["source_b"]).strip().lower()}
        if want_pair != got_pair:
            problems.append(f"{where}: the sealed answer settles the source pair "
                            f"{sorted(want_pair)}, not {sorted(got_pair)}")
            continue
        # WHICH DEFINITIONS were compared (programme item 2). Two vendor names say where; the
        # definition ids say WHAT — `rwpfs == rwpfs` is a spelling, `RWDP:RWPFS:v3` against
        # `RWDP:RWPFS_PROXY:v1` is a claim. Optional until every product registers its
        # definitions; when stated, each must be registered, and when the sealed answer names
        # them too, the ruling must agree with the answer.
        d_a, d_b = str(r.get("definition_a") or "").strip(), str(r.get("definition_b") or "").strip()
        sealed_defs = {str(eq.get("definition_a") or "").strip(), str(eq.get("definition_b") or "").strip()} - {""}
        if d_a or d_b:
            from rwd_tools import decision_record as _drec                                 # noqa: PLC0415
            bad = _drec.equivalence_definition_errors({"definition_a": d_a, "definition_b": d_b}, root)
            if bad:
                problems.append(f"{where}: {bad[0]}")
                continue
            if sealed_defs and sealed_defs != {d_a, d_b}:
                problems.append(f"{where}: the sealed answer compared {sorted(sealed_defs)}, this ruling "
                                f"names {sorted({d_a, d_b})} — the ruling records the decision, never overrides it")
                continue
        elif sealed_defs:
            problems.append(f"{where}: the sealed answer compared {sorted(sealed_defs)} and this ruling "
                            f"names no definitions — a ruling records the decision in full; carry both ids")
            continue
        r = dict(r, trust="unsigned")   # an immutable UNSIGNED assertion until keys exist
        if known_ids is not None:
            rid = str(r.get("decision_id"))
            if rid not in known_ids:
                problems.append(f"{where}: decision_id {rid!r} resolves to no "
                                f"decision in any register — a ruling citing reasoning "
                                f"nobody recorded rules on nothing")
                continue
            # a bare-id set is the unit-test vocabulary (statuses/text unknown, skipped);
            # the live scan supplies {id: {statuses, text}}: RESOLUTION is required
            # (earlier review: the unrelated, OPEN STUDY-WINDOW approved an
            # equivalence) and the row must MENTION the ruling's variable (the verdict's
            # update: any resolved decision authorized any pair — a register row that
            # never names the variable settled nothing about it). Full payload binding
            # (source pair, version, question digest) stays the named next tranche.
            info = known_ids[rid] if isinstance(known_ids, dict) else None
            if isinstance(info, (set, frozenset)): # unit shorthand: statuses only
                info = {"statuses": set(info), "text": None}
            statuses = (info or {}).get("statuses", {"RESOLVED"})
            if "RESOLVED" not in statuses:
                shown = ", ".join(sorted(s for s in statuses if s)) or "of unstated status"
                problems.append(f"{where}: decision_id {rid} is {shown} in every register "
                                f"that records it — an unsettled question authorizes no "
                                f"equivalence; record the answer first "
                                f"(decision_record.py --apply), then rule")
                continue
            if info is not None and info.get("text") is not None and \
                    str(r["variable"]).strip().lower() not in str(info["text"]):
                problems.append(f"{where}: decision {rid} never mentions "
                                f"{str(r['variable'])!r} in any register that records it "
                                f"— a decision that does not name the variable settled "
                                f"nothing about it; cite the decision that did, or raise "
                                f"one")
                continue
        # THE PACK-SCOPED BINDING (a follow-up review: any register anywhere could stand
        # behind any pair). The ruling names the pack whose register carries the
        # reasoning; the row is read from exactly there, must be RESOLVED there, must
        # mention the variable there, and the ruling carries the sha256 of the question
        # cell AS THE RULER READ IT — the answer-form discipline, so a register edit
        # after the ruling is a named divergence, never silent drift.
        pack_rel = str(r.get("decision_pack") or "").strip().replace("\\", "/")
        if not pack_rel and not str(r.get("decision_row_sha256") or ""):
            good.append(r)
            continue
        row = _register_row(pack_rel, str(r.get("decision_id")), root=root)
        if row is None:
            problems.append(f"{where}: decision_pack {pack_rel!r} holds no register row "
                            f"for {r.get('decision_id')} — the pack that owns the "
                            f"reasoning is the one a ruling must cite")
            continue
        if row["status"] != "RESOLVED":
            problems.append(f"{where}: {r.get('decision_id')} is "
                            f"{row['status'] or 'of unstated status'} in {pack_rel}'s own "
                            f"register — an unsettled question authorizes no equivalence")
            continue
        unnamed = [fld for fld in ("variable", "source_a", "source_b")
                   if str(r[fld]).strip().lower() not in row["text"]]
        if unnamed:
            problems.append(f"{where}: {pack_rel}'s row for {r.get('decision_id')} never "
                            f"mentions {', '.join(repr(str(r[f])) for f in unnamed)} — a "
                            f"decision that names neither the variable nor BOTH sources "
                            f"settled nothing about this pair (a review probe authorized "
                            f"an unrelated pair off a row that never mentioned it)")
            continue
        import hashlib # noqa: PLC0415
        want = hashlib.sha256(row["row"].encode("utf-8")).hexdigest()
        if str(r.get("decision_row_sha256")).lower() != want:
            problems.append(f"{where}: decision_row_sha256 does not match the register's "
                            f"row for {r.get('decision_id')} — the row (question, answer, "
                            f"approver, date or status) moved after the ruling, or the "
                            f"digest was never read from it; re-read the register and "
                            f"re-state it (semantic_view.py {pack_rel} --decision-digest "
                            f"{r.get('decision_id')})")
            continue
        good.append(r)
    # ONE RULING PER (variable, pair), DECIDED OVER THE WHOLE FILE. The earlier check refused the
    # SECOND ruling it met and kept the first, so file order decided which of two valid rulings
    # won — `same_construct` then `not_comparable` pooled, the reverse did not (the external
    # review's order-dependence probe). Now every ruling on a conflicted pair is refused, and the
    # pair reads as CONFLICTED until a person supersedes one of them.
    counts = {}
    for g in good:
        counts[_pair_id(g)] = counts.get(_pair_id(g), 0) + 1
    kept = []
    for g in good:
        pid = _pair_id(g)
        if counts[pid] > 1:
            problems.append(f"ruling for `{g['variable']}` across {sorted(pid[1])} ({g['ruling']}): "
                            f"{counts[pid]} rulings stand on this pair — a conflict a person resolves "
                            f"by superseding all but one, not an ordering the file decides")
            continue
        kept.append(g)
    return kept, problems


def _pair_id(r):
    return (str(r["variable"]).lower(), frozenset({str(r["source_a"]).lower(), str(r["source_b"]).lower()}))


def conflicted_pairs(path=None, root=None):
    """{(variable, {a, b})} the file rules more than once — read from the register's own text so
    `pooling` can name a conflict without re-running the ladder for every pair."""
    path = RULINGS if path is None else path
    doc, err = pg.read_yaml(path)
    counts = {}
    for r in ((doc or {}).get("rulings") or []) if not err else []:
        try:
            counts[_pair_id(r)] = counts.get(_pair_id(r), 0) + 1
        except (KeyError, TypeError, AttributeError):
            continue
    return {pid for pid, n in counts.items() if n > 1}


def pooling(variable, source_a, source_b, ruled=None, conflicts=None, definitions=None):
    """The pair's state. A recorded ruling, CONFLICTED (two rulings stand), or NOT ESTABLISHED —
    never a verdict of this tool's own. Order-insensitive: (flatiron, optum) and (optum,
    flatiron) are one question.

    `definitions` is {implementation: definition_id | None} — what each side's
    config/implementations.yaml claims for this variable (programme item 3). A ruling that names
    the two definitions it compared APPLIES ONLY to implementations claiming exactly those: a
    ruling over `RWDP:RWPFS:v3` and `RWDP:RWPFS_PROXY:v1` says nothing about a dataset that now
    implements `RWDP:RWPFS:v4`, or one that has not said what it implements. A ruling naming no
    definitions applies as recorded, and the claims ride along for the reader."""
    if ruled is None:
        ruled, _p = rulings()
    if conflicts is None:
        conflicts = conflicted_pairs()
    want = {str(source_a).lower(), str(source_b).lower()}
    v = str(variable).lower()
    claimed = {str(k).lower(): str(d) for k, d in (definitions or {}).items() if d}
    defs = {s: claimed.get(s) for s in sorted(want)}
    if (v, frozenset(want)) in conflicts:
        return {"state": "conflicted", "variable": v, "sources": sorted(want), "definitions": defs,
                "question": f"`{v}` across {sorted(want)[0]} and {sorted(want)[1]} carries more than one "
                            f"ruling in governance/EQUIVALENCE_RULINGS.yaml. Do not pool: a person "
                            f"supersedes all but one before any comparison stands."}
    for r in ruled:
        if (str(r["variable"]).lower() == v
                and {str(r["source_a"]).lower(), str(r["source_b"]).lower()} == want):
            named = {str(r.get("definition_a") or ""), str(r.get("definition_b") or "")} - {""}
            if named:
                unclaimed = [s for s in sorted(want) if s not in claimed]
                got = {claimed[s] for s in want if s in claimed}
                if unclaimed or got != named:
                    why = (f"{', '.join(unclaimed)} claims no definition for `{v}` (config/implementations.yaml)"
                           if unclaimed else f"these implementations claim {' and '.join(sorted(got))}")
                    return {"state": "not_established", "variable": v, "sources": sorted(want),
                            "definitions": defs,
                            "ruling_on_record": {k: r.get(k) for k in
                                                 ("ruling", "ruled_by", "ruling_date", "definition_a", "definition_b")},
                            "question": f"The ruling on record ({r['ruling']}, {r['ruled_by']}, {r['ruling_date']}) "
                                        f"compared {' and '.join(sorted(named))}; {why}. Do not pool: a ruling "
                                        f"applies to the definitions actually implemented — claim them in "
                                        f"config/implementations.yaml, or rule on the pair as implemented."}
            return dict(r, state=r["ruling"], definitions=defs)
    a, b = sorted(want)
    shown = ""
    if defs[a] and defs[b]:
        shown = (f" Both claim {defs[a]}." if defs[a] == defs[b]
                 else f" {a} claims {defs[a]}, {b} claims {defs[b]}.")
    return {"state": "not_established", "variable": v,
            "sources": sorted(want), "definitions": defs,
            "question": f"Is `{v}` the same construct in {a} and {b}?{shown} Do not pool until "
                        f"DataExpert/Science record the ruling in governance/EQUIVALENCE_RULINGS.yaml."}


def implementations(pack):
    """{dataset: source_status} — the datasets that implement this pack's TUMOUR. The
    registry's vendor is the first; a second arrives as a typed adapter set
    (config/source_adapters.yaml, its `dataset:` label); and a SIBLING PRODUCT sharing the
    tumour_key (dlbcl_cota_ehr beside dlbcl_optum_claims) contributes its vendor too — which
    is exactly when the equivalence axis below goes live. Without the sibling rung, two
    products of one tumour never generated the comparability question that guards pooling
    across their sources."""
    from rwd_tools import source_adapter as sa # noqa: PLC0415
    from rwd_tools import source_manifest as sm # noqa: PLC0415
    rel = repo_relative(pack)
    entry = pg.registry_entry(ROOT, rel) or {}
    slug = str(entry.get("slug") or "").lower()
    vendor = str(entry.get("vendor") or "unregistered").lower()
    # ONE IDENTITY NAMESPACE: the current pack was keyed by VENDOR and
    # its siblings by SLUG, so the same EHR/claims pair had two different identities depending
    # on which side rendered the view — and one equivalence ruling could not reliably apply in
    # both directions. Everything with a product identity keys by SLUG; a typed adapter keys
    # by its dataset label, because a dataset is not a product.
    me = slug or vendor
    impls = {me: {"source_status": f"this pack ({vendor}) — "
                                   + (sm.source_status(pack) or "unregistered")}}
    ad = sa.check(pack)
    if ad.get("state") == "checked" and ad.get("dataset"):
        ds = str(ad["dataset"]).lower()
        impls.setdefault(ds, {})["source_status"] = (
            "adapter with problems — fix before trusting" if ad["problems"]
            else "typed adapter declared")
    key = str(pg.tumour_key_for(ROOT, slug) or slug)
    # PRODUCTS NEVER PAIR WITH FIXTURES: exercise material is not an implementation of a
    # governed product's tumour. A fixture pack may still see fixture siblings — that is
    # what exercising the axis on reference material means.
    bases = ("products",) if rel.replace("\\", "/").startswith("products/") \
        else ("products", "fixtures")
    if slug and key:
        for base in bases:
            reg, err = pg.read_yaml(os.path.join(ROOT, base, "registry.yaml"))
            if err:
                continue
            for t_ in (reg or {}).get("tumors") or []:
                if not isinstance(t_, dict) or str(t_.get("slug") or "").lower() == slug:
                    continue
                sib = str(t_.get("slug") or "").lower()
                if sib and str(pg.tumour_key_for(ROOT, sib) or sib) == key:
                    # KEYED BY THE SIBLING'S SLUG: two modality products
                    # on one vendor collapsed into one entry, erasing exactly the
                    # EHR-vs-claims pair the equivalence axis exists for. The status says
                    # what this IS — a registry declaration, never variable-level
                    # implementation evidence; per-variable proof is the sibling's own
                    # contract to give, and `view` requires it before pairing.
                    v = str(t_.get("vendor") or "unregistered").lower()
                    mod = str(t_.get("modality") or "ehr").lower()
                    impls.setdefault(sib, {}).update(
                        sibling=True,
                        source_status=(
                            f"sibling product {sib} ({v}/{mod}) — registry-declared, NOT "
                            f"variable-level implementation evidence; same tumour, its own "
                            f"source, and equivalence is a ruling, never an assumption"))
    # WHICH DEFINITION EACH IMPLEMENTATION CLAIMS (programme item 3). A dataset says, per
    # contract variable, the registered analytical definition it implements
    # (config/implementations.yaml, reviewed by a person); the view carries the claim on the
    # implementation that made it — this pack's own entry, or its typed adapter when the file's
    # dataset label is the adapter's — and reads each sibling's claims from the sibling's own
    # current pack. A file that does not resolve claims NOTHING and says why.
    claims, label, problems = claimed_definitions(pack)
    owner = label if (label and label in impls and label != me) else me
    impls[owner]["definitions"] = claims
    impls[owner]["implementation_problems"] = problems
    for k, d in impls.items():
        if d.get("sibling"):
            sp = _sibling_pack(k)
            d["definitions"], _l, d["implementation_problems"] = claimed_definitions(sp) if sp else ({}, "", [])
    return impls


def claimed_definitions(pack):
    """({variable_id (lower): definition_id}, dataset label, [problem]) — what a pack's
    config/implementations.yaml claims. Absent is an EMPTY claim; a file the register or the
    contract refuses claims nothing and carries the reasons, because a claim that does not
    resolve binds no implementation to any definition."""
    from rwd_tools import definition_registry as dr # noqa: PLC0415
    root = dr.checkout_root(pack)
    rel = repo_relative(pack, root)
    doc, problems = dr.implementations(rel, root)
    if problems or not doc:
        return {}, "", problems
    label = str(doc.get("dataset") or "").lower()
    errs = dr.implementation_errors(rel, root)
    if errs:
        return {}, label, errs
    return ({str(i.get("variable") or "").lower(): str(i.get("definition") or "")
             for i in doc.get("implements") or [] if i.get("variable") and i.get("definition")},
            label, [])


def _sibling_pack(slug):
    """The registered CURRENT pack of a slug that carries a contract — products shadow fixtures —
    or None. A placeholder `current_spec_version` names nothing."""
    current = ""
    for base in ("products", "fixtures"):
        reg, err = pg.read_yaml(os.path.join(ROOT, base, "registry.yaml"))
        if err:
            continue
        for t_ in (reg or {}).get("tumors") or []:
            if isinstance(t_, dict) and str(t_.get("slug") or "").lower() == slug:
                current = str(t_.get("current_spec_version") or "")
                break
        if current:
            break
    if not re.fullmatch(r"\d{6}", current):
        return None
    import glob as _glob # noqa: PLC0415
    for base in ("products", "fixtures"):
        # ANY family, from the shape — `oncology` was hardcoded here,
        # so a heme or rare product silently vanished from reuse analysis
        hits = sorted(_glob.glob(os.path.join(ROOT, base, "*", slug, current, "handoff",
                                              "FUNCTIONAL_CONTRACT.md")))
        if hits:
            return os.path.dirname(os.path.dirname(hits[0])) # products shadow fixtures
    return None


def _sibling_variables(slug):
    """The variable names a sibling product IMPLEMENTS, lowercased — evidence, not presence.

    Three eligibility rungs, each one an audit probe (thirty-first: a bare registry row
    generated 202 pooling questions; thirty-second: an obsolete contract whose 199 rows were
    all not_implemented generated 199 more):

      * the REGISTERED CURRENT version only — never every version ever committed, and a
        placeholder `current_spec_version` (YYYYMM) names nothing;
      * products shadow fixtures — the first root with the pack wins;
      * the record's implementation axis must say `implemented` or `partial` — a stated
        intention is not an implementation, and a contract of not_implemented rows
        implements nothing."""
    from rwd_tools import contract_lint as cl # noqa: PLC0415
    names = set()
    sp = _sibling_pack(slug)
    if not sp:
        return names
    for block in cl.records(cl.read(os.path.join(sp, "handoff", "FUNCTIONAL_CONTRACT.md"))):
        impl = (cl._kv(cl._inline(block, "status"), "implementation") or "").strip()
        if impl not in ("implemented", "partial"):
            continue
        vid = (cl._scalar(block, "variable_id") or "").strip().lower()
        phys = (cl._kv(cl._inline(block, "output"), "physical_name") or "").lower()
        names.update(x for x in (vid, phys) if x)
    return names


def view(pack):
    """The semantic view: every contract variable with its derivation, implementations, and
    equivalence posture. Absence is stated — a record with no derivation says so."""
    contract = os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(contract):
        sys.exit(f"no contract at {repo_relative(contract)} — a semantic view without the "
                 f"contract would be a list of names, which is not a semantic layer")
    impls = implementations(pack)
    sib_vars = {k: _sibling_variables(k) for k in impls if impls[k].get("sibling")}
    ruled, problems = rulings()
    conflicts = conflicted_pairs()
    rows = []
    for block in cl.records(cl.read(contract)):
        vid = (cl._scalar(block, "variable_id") or "").strip()
        if not vid:
            continue
        out = cl._inline(block, "output")
        name = (cl._kv(out, "physical_name") or "").lower()
        pairs = []
        # A PAIR NEEDS EVIDENCE ON BOTH SIDES — INCLUDING THIS ONE (earlier review: a
        # registry-declared sibling with no contract generated 202 questions; thirty-third:
        # the current pack qualified automatically, so a not_implemented row here still
        # paired with an implemented sibling row). A sibling enters a variable's pair only
        # when its own contract carries the variable IMPLEMENTED; this pack's entries enter
        # only when THIS row's implementation axis says so too.
        impl_here = (cl._kv(cl._inline(block, "status"), "implementation") or "").strip()
        eligible = [k for k in sorted(impls)
                    if (impls[k].get("sibling")
                        and {name, vid.lower()} & sib_vars.get(k, set()))
                    or (not impls[k].get("sibling")
                        and impl_here in ("implemented", "partial"))]
        defs = {k: (impls[k].get("definitions") or {}).get(vid.lower())
                or (impls[k].get("definitions") or {}).get(name) for k in eligible}
        for i, a in enumerate(eligible):
            for b in eligible[i + 1:]:
                pairs.append(pooling(name or vid.lower(), a, b, ruled, conflicts, definitions=defs))
        rows.append({
            "variable_id": vid,
            "name": name or "(no physical_name stated)",
            "type": cl._kv(out, "type") or "?",
            "name_status": cl._kv(out, "name_status") or "?",
            "derivation": (cl._scalar(block, "derivation")
                           or cl._inline(block, "derivation") or "").strip()
                          or "(the record states no derivation)",
            # this VARIABLE'S implementations, not the pack-level map (earlier review:
            # the global map was copied onto every row, so a registry-only sibling read as
            # implementing all 202 variables while pairing with none of them)
            "implementations": {k: impls[k] for k in eligible},
            "definitions": defs, # what each eligible implementation claims for THIS variable
            "equivalence": pairs, # empty with one dataset — nothing to pool is not a pass
        })
    open_pairs = [p for r in rows for p in r["equivalence"] if p["state"] in ("not_established", "conflicted")]
    return {"pack": repo_relative(pack), "implementations": impls,
            "variables": rows, "ruling_problems": problems,
            "implementation_problems": {k: d["implementation_problems"] for k, d in impls.items()
                                        if d.get("implementation_problems")},
            "open_equivalence_questions": len(open_pairs)}


def render(v):
    L = ["=" * 96,
         f"  SEMANTIC VIEW — {v['pack']}",
         f"  implementations: " + ", ".join(f"{k} ({d['source_status']})"
                                            for k, d in sorted(v["implementations"].items())),
         "=" * 96, ""]
    if v["ruling_problems"]:
        L += ["  RULING PROBLEMS (fix the file before trusting any pooling state):"]
        L += [f"    - {p}" for p in v["ruling_problems"]] + [""]
    for k, probs in sorted((v.get("implementation_problems") or {}).items()):
        L += [f"  IMPLEMENTATION CLAIMS OF {k} DO NOT RESOLVE (the dataset claims nothing until they do):"]
        L += [f"    - {p}" for p in probs] + [""]
    for r in v["variables"]:
        L.append(f"  {r['variable_id']:<28} {r['name']:<24} {r['type']:<10} "
                 f"name_status: {r['name_status']}")
        L.append(f"      {r['derivation'][:150]}")
        if any((r.get("definitions") or {}).values()):
            L.append("      definitions: " + ", ".join(f"{k}={d or '(none claimed)'}"
                                                       for k, d in sorted(r["definitions"].items())))
        for p in r["equivalence"]:
            if p["state"] == "not_established":
                L.append(f"      POOLING NOT ESTABLISHED across {p['sources']} — "
                         f"{p['question']}")
            elif p["state"] == "conflicted":
                L.append(f"      POOLING CONFLICTED across {p['sources']} — {p['question']}")
            else:
                L.append(f"      {p['state']} across [{p['source_a']}, {p['source_b']}] "
                         f"({p['ruled_by']}, {p['ruling_date']})")
    n2 = sum(1 for r in v["variables"] if len(r["implementations"]) > 1)
    L += ["", f"  {len(v['variables'])} variable(s); "
              f"{len(v['implementations'])} implementation(s); "
              f"{v['open_equivalence_questions']} open equivalence question(s)"
              + ("" if n2 else " (one dataset today — the axis activates with the second)"),
          "=" * 96]
    return "\n".join(L)




def record_ruling(root, index, now_utc, path=None):
    """Seal ONE accepted ruling into the event ledger - the ruler's act, recorded.

    The entry must first pass `rulings()` whole (including agreement with its sealed
    decision event); the sealed payload is the canonical entry, so the YAML entry becomes
    a PROJECTION the claims composition can prove. The actor is transcribed from
    `ruled_by` - an immutable UNSIGNED assertion until signing keys exist.
    Returns (event, None) or (None, why)."""
    from rwd_tools import event_ledger as el                                            # noqa: PLC0415
    p = path or os.path.join(root, "governance", "EQUIVALENCE_RULINGS.yaml")
    doc, err = pg.read_yaml(p)
    if err:
        return None, f"{p}: {err}"
    entries = (doc or {}).get("rulings") or []
    if not (0 <= index < len(entries)):
        return None, f"{p}: no ruling at index {index}"
    good, problems = rulings(p, root=root)
    mine = [x for x in problems if f"ruling[{index}]" in x]
    if mine:
        return None, "the ruling does not validate - seal nothing: " + "; ".join(mine)
    r = entries[index]
    obj = str(r.get("object_uuid") or "") or None
    prev = ""
    if obj:
        try:
            _seq, prev = el.head_of(root, obj)
        except el.LedgerError as e:
            return None, str(e)
    payload = {k: str(r.get(k) or "") for k in NEED + ("note",)}
    for k in ("definition_a", "definition_b"):       # which definitions were compared, when stated
        if str(r.get(k) or "").strip():
            payload[k] = str(r.get(k)).strip()
    who = str(r.get("ruled_by"))
    actor = {"subject_id": who, "identity_provider": "typed", "display_name": who,
             "role": "rwb", "trust_level": "typed"}
    try:
        event = el.append_event(
            root, object_uuid=obj, object_kind="equivalence_ruling", action="registered",
            actor=actor, occurred_at=now_utc, payload=payload,
            expected_previous_event_sha256=prev,
            idempotency_key=f"ruling:{r.get('decision_id')}:{el.payload_digest(payload)[:16]}")
    except el.LedgerError as e:
        return None, str(e)
    if obj is None:
        entries[index]["object_uuid"] = event["object_uuid"]
        import yaml as _yaml                                             # noqa: PLC0415
        _yaml.safe_dump(doc, open(p, "w", encoding="utf-8", newline="\n"),
                        sort_keys=False)
    return event, None


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack")
    ap.add_argument("--format", choices=("text", "json"), default="text")
    ap.add_argument("--pooling", nargs=3, metavar=("VARIABLE", "SOURCE_A", "SOURCE_B"),
                    help="the ruled state (or NOT ESTABLISHED) for one variable across two "
                         "datasets")
    ap.add_argument("--decision-digest", metavar="DECISION_ID",
                    help="print the sha256 a ruling's decision_row_sha256 must carry for "
                         "this pack's register row — read it, never guess it")
    a = ap.parse_args(argv)
    if a.decision_digest:
        d = decision_row_digest(a.pack, a.decision_digest)
        if d is None:
            print(f"{a.pack}: no register row for {a.decision_digest}")
            return 1
        print(d)
        return 0
    if a.pooling:
        print(json.dumps(pooling(*a.pooling), indent=2, sort_keys=True))
        return 0
    v = view(a.pack)
    print(json.dumps(v, indent=2, sort_keys=True) if a.format == "json" else render(v))
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
