#!/usr/bin/env python3
"""Lift the VALUE ENUMERATIONS a specification states, as CANDIDATE EVIDENCE for the executable YAML.

This output is NOT executable configuration and no engine reads it. It is the machine-checkable record
of what the specification literally says, so that DataExpert's approved `variables/` YAML can be compared
against the source instead of trusted. Promotion to executable YAML is a human act, because it requires
deciding the things the spec does not state: numeric codes, fallthrough behaviour, operators, ranges,
source mappings and output names.

This is the one part of the contract-to-YAML step that can be generated rather than written, and the
reason is worth stating precisely.

The contract SUMMARIZES: `derivation: "STATE→region map (codes 1-5, PR→Other region)"`. The YAML
ENUMERATES: fifty-two state codes. Generating the YAML from the contract is impossible — the codes are
not in it. But they ARE in the specification row, verbatim, and that row is already extracted with its
original Excel coordinates. So the enumeration can be lifted from the source rather than retyped.

That matters because retyping is where this repo's worst defect came from: an unanchored find/replace
turned the state code `DE` into the word `Implementation` inside a list of two-letter codes, and it
survived review because it still read like prose.

What it does NOT generate, and must not: windows, tie-breaks, record selection, source mappings,
operators. Those are the contract's judgment fields, they are not enumerations, and on prostate 202607
twenty-eight of the fifty-three records are still blocked on an Science decision. This tool lifts values;
it decides nothing.

Two mapping shapes are recognised, plus separately marked literal-list evidence:

  membership   `if STATE in ('ME' 'VT' ...) then ='Northeast'; else if ...`   -> labelled value lists
  numeric map  `1 = Positive, 2 = Negative, 3 = VUS`                          -> code/label pairs
  literal list `White,Black or African American,Asian,Other,Unknown`         -> cited literals requiring review

Read from the DEFINITION cell first, and from the VALUES cell when the definition yields nothing. The
Values column is where Science writes the enumeration outright — `1='Yes'<br>0='No';<br>missing` — and it
went unread, so a variable whose codes were stated in the one column named for them produced no
candidate and the comparison against the approved YAML said nothing about it. Definition wins where
both state codes: it carries the branch labels and the missing-value branch, and a Values cell read
over the top of it would replace a rule with a summary of one.

A Values cell is taken only when EVERY segment of it is accounted for — as a code pair, or as a bare
`missing`/`null`/`.` recorded as `missing_permitted`. One unaccounted segment yields nothing, and the
segments are quoted in the finding.

Anything else is REPORTED, not guessed. A half-parsed enumeration is worse than none: it looks complete.
Every run states its coverage, in the file as well as the console: `unparsed` rows were NOT CHECKED,
which a list made otherwise of matches does not say on its own.

    python3 platform/tools/spec_codelists.py <extracted.json> [--out FILE]

stdlib only.
"""
import argparse
import csv
import json
import os
import re
import sys

# `in ('ME' 'VT' 'NH') then ='Northeast'` — quoted tokens, then the label the branch assigns.
MEMBERSHIP = re.compile(
    r"in\s*\(\s*((?:'[^']+'[\s,]*)+)\)\s*then\s*=?\s*'([^']+)'", re.I)
# `1 = Positive, 2 = Negative` / `1=IHC | 2=FISH` — a code, an equals, a label up to the next separator.
NUMERIC_MAP = re.compile(
    r"(?<![\d.])(\d{1,2})\s*=\s*'?([A-Za-z0-9><=][^,;|<]{0,40}?)'?\s*(?=[,;|]|<br>|$)")
TOKEN = re.compile(r"'([^']+)'")
# `else if STATE is missing then ='Missing'` — a branch with a PREDICATE instead of a member list. The
# first version dropped these entirely, so the generated REGION1 had five branches where the spec states
# six, and the omission was invisible because what remained looked complete.
PREDICATE = re.compile(r"(?:else\s+)?if\s+(\w+)\s+is\s+(missing|null)\s*then\s*=?\s*'([^']+)'", re.I)


def membership_lists(text):
    """Branches of an if/else-if chain, in the order the spec writes them.

    Each is either a MEMBER list or a PREDICATE. Both are branches of one rule and dropping either
    misrepresents the rule — a chain with the missing-value branch removed reads as complete.
    """
    out = []
    for values, label in MEMBERSHIP.findall(text):
        toks = TOKEN.findall(values)
        if toks:
            out.append({"label": label.strip(), "members": toks})
    for col, kind, label in PREDICATE.findall(text):
        out.append({"label": label.strip(), "predicate": f"{col.lower()}_is_{kind.lower()}"})
    return out


def _definition_pairs(text):
    return [(int(code), label.strip()) for code, label in NUMERIC_MAP.findall(text)]


def _conflicting_codes(pairs):
    labels = {}
    for code, label in pairs:
        labels.setdefault(code, [])
        if label not in labels[code]:
            labels[code].append(label)
    return [f"code {code} has conflicting labels: " + " and ".join(json.dumps(label, ensure_ascii=False) for label in values)
            for code, values in labels.items() if len(values) > 1]


def _yaml_text(value):
    """JSON string quoting is valid YAML; escape YAML's extra line/control chars.

    Keep ordinary Unicode intact (including supplementary characters) so YAML
    readers do not receive JSON surrogate-pair escapes as separate characters.
    """
    encoded = json.dumps(value, ensure_ascii=False)
    return re.sub(r"[\x7f-\x9f\u2028\u2029\ud800-\udfff\ufffe\uffff]",
                  lambda match: "\\u" + format(ord(match[0]), "04x"), encoded)


def numeric_map(text):
    """[(code, label)] for a `1 = X, 2 = Y` map, requiring the codes to run contiguously.

    The completeness test is the point: a partial map parsed from a truncated row would produce a
    codelist that silently drops categories.

    The run may start at 0 or at 1. It was 1-only, which refused every `1='Yes' 0='No'` flag in the
    specification — the most common enumeration Science writes — as if it were truncated. Contiguity is
    what catches truncation; where the run starts is a convention, and this spec uses both.
    """
    pairs = _definition_pairs(text)
    if _conflicting_codes(pairs):
        return []
    seen, out = set(), []
    for code, label in pairs:
        if code not in seen:
            seen.add(code)
            out.append((code, label))
    out.sort()
    if len(out) < 2:
        return []
    start = out[0][0]
    if start not in (0, 1) or [c for c, _ in out] != list(range(start, start + len(out))):
        return []
    return out


# A Values cell segment that states missing is PERMITTED rather than naming a code: `missing`, `null`,
# or SAS's `.`. It is not a code and must not be given one, but dropping it makes a two-value flag out
# of a three-state field.
BARE_MISSING = re.compile(r"^\s*(?:missing|null|\.)\s*$", re.I)
# One segment of a Values cell: a code, an equals, and the rest of the segment as its label. Anchored
# at both ends, because the segment has already been cut out — a global regex with lookaheads has to
# guess where a label stops, and that guess is what a label containing the terminator defeats.
VALUE_PAIR = re.compile(r"^\s*(\d{1,2})\s*=\s*'?(.+?)'?\s*$")
# The separators Science uses, most distinctive first. ONE style per cell, chosen by what the cell
# contains: prostate writes `1='Yes'<br>0='No';` and ovarian writes `• 1=Northeast • 2=Midwest •`.
# Splitting on all of them at once destroys `• 1=<150,000/uL •`, where the comma is inside a label —
# and splitting on none of them leaves a global regex guessing where each label ends.
VALUE_SEPARATORS = ("•", "|", ";", ",")


def _value_parts(cell):
    """Parse each Values segment, preserving repeated codes for conflict checks."""
    cell = re.sub(r"\s+", " ", cell or "").strip()
    if not cell:
        return [], False, []
    sep = next((c for c in VALUE_SEPARATORS if c in cell), None)
    if sep is None:
        return [], False, []
    pairs, missing_stated, unaccounted = [], False, []
    for seg in cell.split(sep):
        seg = seg.strip().strip("".join(VALUE_SEPARATORS)).strip()
        if not seg:
            continue
        if BARE_MISSING.match(seg):
            missing_stated = True
            continue
        match = VALUE_PAIR.match(seg)
        if match:
            pairs.append((int(match.group(1)), match.group(2).strip()))
        else:
            unaccounted.append(seg.strip()[:60])
    return pairs, missing_stated, unaccounted


def _literal_values(cell):
    """Preserve a delimited Values list, without interpreting codes or ranges.

    This weaker evidence shape never becomes code/label pairs. Ambiguous or
    mixed notation is reported for review rather than partially tokenized.
    """
    text = re.sub(r"\s+", " ", cell or "").strip()
    sep = next((c for c in VALUE_SEPARATORS if c in text), None)
    slash_ranges = None
    if sep is None and " / " in text:
        # A slash also appears in units, dates and division. Only a complete list
        # of explicit range labels is safe to lift at this boundary; no predicates
        # or numeric output codes are generated from these labels.
        parts = re.split(r"\s+/\s+", text)
        range_label = r"(?:[<>]=?\s*\d+|[≤≥]\s*\d+|\d+\s*[-–]\s*\d+|\d+\s*\+)"
        if len(parts) >= 2 and all(re.fullmatch(range_label, part.strip()) for part in parts):
            slash_ranges = parts
            sep = " / "
        else:
            return None, ["A slash may mean a date, unit or calculation; confirm the complete value list."]
    if sep is None:
        return None, []
    if sep == "," and re.search(r"\d,\d{3}(?:\D|$)", text):
        return None, ["A comma may be a thousands separator; confirm the intended categories or thresholds."]
    try:
        if slash_ranges is not None:
            parts = slash_ranges
        elif sep == ",":
            quote = "'" if text.lstrip().startswith("'") else '"'
            parts = next(csv.reader([text], delimiter=sep, quotechar=quote, skipinitialspace=True, strict=True))
        else:
            parts = text.split(sep)
    except csv.Error:
        return None, ["The quoted value list is incomplete; confirm each intended value."]
    parts = [part.strip().strip(";|•").strip() for part in parts]
    parts = [part[1:-1] if len(part) >= 2 and part[0] == part[-1] and part[0] in "\"'" else part for part in parts]
    parts = [part for part in parts if part]
    if len(parts) < 2:
        return None, ["A separated Values cell did not yield two complete values; confirm its meaning."]
    if any(len(part) > 160 or part.count("(") != part.count(")")
           or re.search(r"\b(?:if|then|else|when|including|such as|and numeric|numeric of|header shows|full list|not enumerated|no standalone|used as)\b|\be\.g\b|(?<![<>!])=(?![=>])", part, re.I)
           or re.fullmatch(r"(?:date|numeric|number|integer|continuous)(?:\s*\([^)]*\))?", part, re.I)
           for part in parts):
        return None, ["The Values cell mixes a list with instructions or coding; review the complete source cell."]
    return {"literals": parts}, []


def values_cell(cell):
    """({pairs, missing_stated}, unaccounted) for a Values cell that enumerates codes.

    The Values column is where Science writes the enumeration outright — `1='Yes'<br>0='No';<br>missing` —
    and it was never read: only the Definition cell was. So a variable whose codes are stated in the
    one column named for them produced no candidate at all, and the comparison against the approved
    YAML said nothing about it either way.

    Every segment must be accounted for — as a code pair, or as a bare missing token. A cell that is
    two-thirds parseable yields NOTHING, with the unaccounted segments returned so the finding can
    quote them: an enumeration missing a category looks exactly like a complete one, which is the
    failure this whole tool is arranged against.

    That rule is what makes the per-segment reading safe, and it earns its keep on the real workbooks:

      `1=Yes, 0=No, missing (header shows 1=Yes, 0=missing)`   the spec contradicts itself; the
                                                               trailing segments do not parse, so
                                                               nothing is lifted and the text is quoted
      `• 1 = Overall OC: Index at Init • Diag • 2 = ...`        a label CONTAINS the separator, so
                                                               `Diag` is left over and the cell is
                                                               refused rather than half-read
      `• 'Present' • 'Unknown' • (and numeric 1=Present, ...)`  a string enumeration with a
                                                               parenthesised numeric one; reading
                                                               either would be choosing for the reader
    """
    # Excel cells carry hard line breaks, and a segment quoted back with one in it wraps mid-token in
    # the console and mid-value in the YAML. Collapsing whitespace changes no code and no label.
    pairs, missing_stated, unaccounted = _value_parts(cell)
    if not pairs:
        return _literal_values(cell)       # retain literal evidence; do not invent code/label pairs
    conflicts = _conflicting_codes(pairs)
    if conflicts:
        return None, conflicts + unaccounted
    if unaccounted:
        return None, unaccounted

    # Contiguity, the same completeness test the definition path uses: a run may start at 0 or 1 and
    # may not skip. An identical repeated pair is one entry; conflicting labels
    # have already been refused rather than silently choosing the first.
    seen, out = set(), []
    for code, label in pairs:
        if code not in seen:
            seen.add(code)
            out.append((code, label))
    out.sort()
    start_ = out[0][0]
    if len(out) < 2 or start_ not in (0, 1) or \
            [c for c, _ in out] != list(range(start_, start_ + len(out))):
        return None, [f"codes {sorted(c for c, _ in out)} are not a complete run from 0 or 1"]
    return {"pairs": out, "missing_stated": missing_stated}, []


def extract(rows):
    found, skipped = [], []
    for r in rows:
        if not r.get("domain"):
            continue
        text = (r.get("fields", {}).get("definition") or "").replace("<br>", "|")
        vals = (r.get("fields", {}).get("values") or "").replace("<br>", "|")
        if not (text or vals):
            continue
        definition_conflicts = _conflicting_codes(_definition_pairs(text))
        values_conflicts = _conflicting_codes(_value_parts(vals)[0])
        if definition_conflicts or values_conflicts:
            conflicts = (["Definition: " + conflict for conflict in definition_conflicts]
                         + ["Values: " + conflict for conflict in values_conflicts])
            skipped.append({"item_id": r["item_id"], "variable": r["variable"],
                            "hash": r.get("content_hash", ""), "why": "Resolve conflicting code labels before generating a candidate. " + "; ".join(conflicts),
                            "definition_cell": r.get("fields", {}).get("definition") or "",
                            "values_cell": r.get("fields", {}).get("values") or ""})
            continue
        mem = membership_lists(text)
        num = numeric_map(text)
        # DEFINITION first, VALUES only as a fallback. Where both state codes the definition is the
        # richer source — it carries the branch labels and the missing-value branch — and reading the
        # Values cell over the top of it would replace a rule with a summary of one.
        cell, unaccounted = (None, []) if (mem or num) else values_cell(vals)
        if mem:
            found.append({"item_id": r["item_id"], "variable": r["variable"], "kind": "membership",
                          "hash": r.get("content_hash", ""), "values": mem, "from": "definition"})
        elif num:
            found.append({"item_id": r["item_id"], "variable": r["variable"], "kind": "numeric_map",
                          "hash": r.get("content_hash", ""), "values": num, "from": "definition"})
        elif cell and "literals" in cell:
            found.append({"item_id": r["item_id"], "variable": r["variable"], "kind": "literal_values",
                          "hash": r.get("content_hash", ""), "values": [{"literal": value} for value in cell["literals"]],
                          "from": "values", "values_cell": r.get("fields", {}).get("values") or "",
                          "review_required": True,
                          "why": "Confirm categories, codes and any threshold boundaries in variable review. Literal source text does not establish an executable mapping."})
        elif cell:
            found.append({"item_id": r["item_id"], "variable": r["variable"], "kind": "numeric_map",
                          "hash": r.get("content_hash", ""), "values": cell["pairs"], "from": "values",
                          "missing_stated": cell["missing_stated"]})
        else:
            # Looks enumerated but did not parse cleanly — say so rather than emitting a partial list.
            # WHICH trigger fired is part of the finding: "does not match a recognised shape" is true
            # of every row here and tells the next reader nothing about where to look. A row caught by
            # the membership trigger has an `in (...)` the MEMBERSHIP pattern would not take; a row
            # caught by the code trigger has an `N = label` the NUMERIC_MAP pattern would not take.
            # Those are different repairs to this parser.
            # BOTH cells. Scanning only the definition left a row whose Values cell plainly tries
            # to enumerate — `'Present' • 'Unknown' • (and numeric 1=Present, …)` — reported nowhere
            # at all, which reads as "nothing to see" rather than "not checked".
            both = text + " " + vals
            saw = [name for name, pat in (
                ("membership `in (…)`", r"\bin\s*\("),
                ("numeric `N = label`", r"\d\s*=\s*[A-Za-z]"),
                # A Values cell that is a bare list of codes — `1,2,3` — with the labels only in the
                # definition. Nothing to lift, but the row IS an enumeration and a reader comparing
                # this file against the approved YAML has to know it was not covered.
                ("a bare code list with no labels", r"^\s*\d+(?:\s*,\s*\d+)+\s*$"))
                   if re.search(pat, both, re.M)]
            if unaccounted:
                # The sharpest case: the Values cell DOES enumerate, and one segment of it could not
                # be accounted for. Quote the segments, because "not checked" that names what to look
                # at is a task, and "not checked" on its own is a shrug.
                skipped.append({"item_id": r["item_id"], "variable": r["variable"],
                                "why": "The Values cell needs review before an enumeration can be used: " + " · ".join(unaccounted),
                                "hash": r.get("content_hash", ""),
                                "values_cell": r.get("fields", {}).get("values") or ""})
            elif saw:
                skipped.append({"item_id": r["item_id"], "variable": r["variable"],
                                "why": "looks like an enumeration (" + " and ".join(saw) +
                                       ") but does not match a recognised shape",
                                "values_cell": re.sub(r"\s+", " ", vals).strip()})
    return found, skipped


def coverage(rows, found, skipped):
    """What the run looked at, so a clean list cannot be read as a complete one.

    `unparsed` rows sit in a report otherwise made of matches, and a reader comparing this against the
    approved YAML sees a list of agreements and one line that is not obviously a hole. It is a hole:
    the row was NOT checked, which is not the same as checked-and-clean, and nothing downstream
    distinguishes them. So the count is stated as its own fact rather than left to be inferred from a
    list somebody has to notice is shorter than it should be.
    """
    considered = len(found) + len(skipped)
    result = {"rows_read": len(rows), "considered": considered,
              "lifted": len(found), "unparsed": len(skipped)}
    pending = sum(bool(item.get("review_required")) for item in found)
    if pending:
        result["needs_review"] = pending
    return result


def provenance(product, source):
    """Extraction binding and a pointer to live document/review metadata.

    Issuing a document ID or recording its review does not change the extracted
    values. Those mutable details belong to the material register; current source
    and approval checks remain separate from generated candidate evidence.
    """
    lines = [f"# source: {source}"]
    if not product:
        return lines
    try:
        from rwd_tools import source_manifest
        src_id = source_manifest.pipeline_source_id(product)
        lines = [f"# extracted from: {source}"]
        if src_id:
            lines.append(f"# source material: {src_id} (source_refs.yaml)")
        lines.append("# authoritative document and review details: source_refs.yaml (current record)")
        lines.append("# This candidate evidence does not establish source approval. Check current review")
        lines.append("# details in source_refs.yaml and authenticated approval evidence in Progress and next step.")
    except Exception as exc:                                        # noqa: BLE001
        lines.append(f"# source identity: could not be read ({exc.__class__.__name__})")
    return lines


def to_yaml(found, skipped, source, product=None):
    L = ["# GENERATED by platform/tools/spec_codelists.py.",
         "# Do not hand-edit: regenerate. Every block names the spec row it was lifted from, so any",
         "# value here can be walked back to the original Excel coordinates.",
         "#",
         "# CANDIDATE EVIDENCE — not executable configuration. No engine reads this file. It records what",
         "# the specification literally states so the approved variables/ YAML can be COMPARED against the",
         "# source. Promotion is a human act: numeric codes for membership branches, fallthrough",
         "# behaviour, operators, source mappings and output names are NOT stated here because the spec",
         "# does not state them.",
         "#"] + provenance(product, source) + [""]
    # Coverage in the FILE, not only on the console. The console line is seen by whoever ran the
    # tool; the comparison against the approved YAML is done against this file, often by somebody
    # else, later, and a list of matches with no denominator reads as a complete one.
    L.append("coverage:")
    L.append(f"  lifted: {len(found)}")
    L.append(f"  unparsed: {len(skipped)}    # produced no candidate — NOT checked, "
             f"which is not the same as clean")
    pending = sum(bool(item.get("review_required")) for item in found)
    if pending:
        L.append(f"  needs_review: {pending}    # literal evidence only; coding and thresholds are not confirmed")
    L.append("")
    L.append("unparsed:" if skipped else "unparsed: []")
    for s in skipped:
        L.append(f"  - spec_ref: {s['item_id']}")
        L.append(f"    variable: {_yaml_text(s['variable'])}")
        L.append(f"    why: {_yaml_text(s['why'])}")
        # The Values cell verbatim. A row nothing could be lifted from still has to be compared
        # against the approved YAML, and this is what a person compares it to — without it the entry
        # says only that somebody should go and open the workbook.
        if s.get("values_cell"):
            L.append(f"    values_cell: {_yaml_text(s['values_cell'])}")
        if s.get("definition_cell"):
            L.append(f"    definition_cell: {_yaml_text(s['definition_cell'])}")
        if s.get("hash"):
            L.append(f"    source_hash: {_yaml_text(s['hash'])}")
    L.append("")
    L.append("enumerations:" if found else "enumerations: {}")
    used_keys = set()
    name_counts = {}
    for item in found:
        name = item["variable"].lower()
        name_counts[name] = name_counts.get(name, 0) + 1
    for f in found:
        name = f["variable"].lower()
        key = name if name_counts[name] == 1 else name + "__" + re.sub(r"[^A-Za-z0-9_]", "_", f["item_id"])
        base_key, number = key, 2
        while key in used_keys:
            key, number = base_key + "_" + str(number), number + 1
        used_keys.add(key)
        L.append(f"\n  # {f['item_id']}  ({f['variable']})   content hash {f['hash']}")
        yaml_key = key if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key) else _yaml_text(key)
        L.append(f"  {yaml_key}:")
        if key != name:
            L.append(f"    variable: {_yaml_text(f['variable'])}")
        L.append(f"    spec_ref: {f['item_id']}")
        L.append(f"    kind: {f['kind']}")
        # WHICH cell it came from. A candidate lifted from the Definition carries the rule; one lifted
        # from the Values column carries only the code list, and a reader checking an operator or a
        # window against it would be checking against a cell that never stated one.
        L.append(f"    lifted_from: {f.get('from', 'definition')}")
        if f.get("missing_stated"):
            # The Values cell listed `missing` beside the codes. NOT given a code — the spec does not
            # state one — but recorded, because a flag that permits missing and one that does not are
            # different fields and the code pairs alone cannot tell them apart.
            L.append("    missing_permitted: stated_by_the_spec")
        if f.get("review_required"):
            L.append("    review_required: true")
            L.append(f"    why: {_yaml_text(f['why'])}")
            L.append(f"    source_hash: {_yaml_text(f['hash'])}")
            L.append(f"    values_cell: {_yaml_text(f['values_cell'])}")
        L.append("    values:")
        if f["kind"] == "literal_values":
            for value in f["values"]:
                L.append(f"      - {{ literal: {_yaml_text(value['literal'])} }}")
            L.append("    numeric_codes: not_stated_by_the_spec")
            L.append("    range_rules: not_interpreted")
        elif f["kind"] == "membership":
            for br in f["values"]:
                if "members" in br:
                    members = ", ".join(_yaml_text(member) for member in br["members"])
                    L.append(f'      - {{ label: {_yaml_text(br["label"])}, members: [{members}] }}')
                else:
                    predicate = br["predicate"]
                    quoted = predicate if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*_is_(missing|null)", predicate) else _yaml_text(predicate)
                    L.append(f'      - {{ label: {_yaml_text(br["label"])}, predicate: {quoted} }}')
            # NO numeric codes. The spec states the branch ORDER, not a code per branch — REGION1N says
            # only "Numeric of REGION1". Numbering them here would be a plausible convention invented by
            # a parser and then indistinguishable from a stated requirement.
            L.append("    numeric_codes: not_stated_by_the_spec")
        else:
            for code, label in f["values"]:
                L.append(f'      - {{ code: {code}, label: {_yaml_text(label)} }}')
            L.append("    numeric_codes: stated_by_the_spec")
    return "\n".join(L) + "\n"


def main(argv):
    ap = argparse.ArgumentParser(description="Lift value enumerations from an extracted spec.")
    ap.add_argument("extracted")
    ap.add_argument("--out")
    ap.add_argument("--product", help="pack directory for the extraction's source material ID "
                                      "and the location of current document/review details")
    a = ap.parse_args(argv)
    # The pack directory is the natural thing to hand this, because every OTHER tool in the pipeline
    # takes one. It takes the extraction FILE, and argparse's answer to a directory is whatever
    # `open()` raises — `IsADirectoryError` on Linux, `PermissionError` on Windows — neither of which
    # names the argument or says what would have been right.
    if os.path.isdir(a.extracted):
        cand = os.path.join(a.extracted, "spec_pipeline", "out", "extracted.json")
        sys.exit(f"{a.extracted} is a directory. This tool takes the extraction FILE, not the pack.\n"
                 f"  {sys.argv[0]} {cand if os.path.exists(cand) else '<pack>/spec_pipeline/out/extracted.json'}"
                 f" --product {a.extracted}" +
                 ("" if os.path.exists(cand) else
                  f"\n\n{cand} does not exist yet — run run_spec_pipeline.py on the pack first."))
    with open(a.extracted, encoding="utf-8") as fh:
        data = json.load(fh)
    found, skipped = extract(data["rows"])
    cov = coverage(data["rows"], found, skipped)

    print(f"enumerations lifted   {len(found)}")
    for f in found:
        if f["kind"] == "membership":
            n = sum(len(b.get("members", [1])) for b in f["values"])
            shape = f"{len(f['values'])} branch(es), {n} value(s)"
        elif f["kind"] == "literal_values":
            shape = f"{len(f['values'])} literal value(s); NEEDS REVIEW"
        else:
            shape = f"{len(f['values'])} code(s)"
        print(f"   {f['item_id']:<18} {f['variable'][:20]:<20} {f['kind']:<12} {shape}")
    if skipped:
        print(f"\nlooked enumerated, NOT lifted   {len(skipped)}")
        for s in skipped[:10]:
            print(f"   {s['item_id']:<18} {s['variable'][:20]:<20} {s['why']}")
        print("   A partial enumeration is worse than none — these need a person, not a better regex.")

    # The coverage line goes LAST, under whichever list ran long, because it is the sentence that says
    # how to read the ones above it.
    print(f"\ncoverage: {cov['rows_read']} spec row(s) read · {cov['considered']} looked enumerated · "
          f"{cov['lifted']} lifted · {cov.get('needs_review', 0)} literal lists NEED REVIEW · {cov['unparsed']} NOT CHECKED")
    if cov["unparsed"]:
        print(f"   {cov['unparsed']} row(s) produced no candidate, so comparing this file against the "
              f"approved YAML says nothing about them either way.")

    if a.out:
        with open(a.out, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(to_yaml(found, skipped, data["extraction"]["target"], a.product))
        print(f"\n-> {a.out}")
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
