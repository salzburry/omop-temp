#!/usr/bin/env python3
"""ONE schema for slot, concept, product output, measurement and mapping.

    python3 platform/tools/registry_schema.py            # print the vocabularies
    python3 platform/tools/registry_schema.py --check    # GATE: exit 1 if a vocabulary is broken

WHY THIS FILE EXISTS. The registry and the reconciler each grew their own words for the same
things, and nothing defined the transformation between them. The registry said `unit_policy` and
`selection`; the contract said `units`, `record_selection` and `tie_break`. Both were plausible,
neither was canonical, and `MEASUREMENT_KEYS` sat in `oncology_registry` declared and never read by
anything — so the "measurement exchange" the reconciler advertises had no schema at all and could
not have been performed. Two vocabularies with no mapping is not an exchange; it is two lists.

WHAT IS CANONICAL AND WHAT IS A DIALECT. `MEASUREMENT` below is the canonical set. The registry
dialect and the contract dialect each map INTO it, and a field with no counterpart on the other
side is named in `ONE_WAY` rather than quietly dropped — because the interesting cases are exactly
those. The contract carries `tie_break`; the registry has nowhere to put it. The registry carries
`specimen`; no contract record states one. Both facts are worth reading, and a mapping that only
listed the fields that happen to correspond would hide them.

A REQUIREMENT ROW IS NOT A PRODUCT OUTPUT, and conflating them is how a reconciliation reports a
number that means nothing. A contract row can be a published column, an internal helper the ADS
never carries, a control the programmer must honour, a metadata requirement, or something
explicitly excluded. Prostate's RWPFS is `role: excluded, ads: excluded`, its own note says "not an
emitted variable" — and it was proposed as a match to a published concept purely because the
spelling agreed. `OUTPUT_ROLES` is what stops that: a row is classified before it is matched, and
an excluded row is never proposed as the realisation of anything.

AND ONE CONCEPT IS OFTEN SEVERAL ROWS. A laboratory concept generates a value, a date, a unit
check, a status flag and a derived category — five requirement rows, one clinical idea. Counting
rows as concepts made "103 registry gaps" a number about the specification's drafting rather than
about oncology. `RELATIONS` is the vocabulary for saying which of the five a row is, so the count
can be taken at the level it means something.

NOTHING HERE DECIDES ANYTHING. This module holds vocabularies and the transformations between
them, and refuses malformed ones. Which relation a row has, and whether a match is right, are
rulings a person makes.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))


# --- measurement: the one canonical vocabulary --------------------------------------------------

# HOW A CONCEPT IS MEASURED, canonically. A definition says what a thing MEANS; these say how it is
# obtained, and a template carrying the first without the second is reusable only in the sense that
# a blank form is. Every one of these is a question a study programmer must have answered before
# they can write the code, which is the test for whether a key belongs on this list.
MEASUREMENT = ("value_type",       # date, integer, code, free text
               "units",            # the unit AND the policy for converting into it
               "specimen",         # what the measurement is taken on, where that is a choice
               "anchor",           # the event or date the window is measured from
               "window",           # the eligible interval relative to the anchor
               "record_selection",  # which record when several qualify in the window
               "tie_break",        # how ties inside that selection are resolved
               "grain",            # what one row is
               "derivation")       # the rule, stated so it can be checked against code

# THE REGISTRY DIALECT -> canonical. The registry describes a slot's measurement in the reference
# inventory's words. Two of them differ from the contract's for no reason beyond who wrote them
# first, and this is where that is settled rather than argued.
REGISTRY_MEASUREMENT = {
    "value_type": "value_type",
    "unit_policy": "units",                 # the registry named the policy, the contract the unit
    "specimen": "specimen",
    "anchor": "anchor",
    "window": "window",
    "selection": "record_selection",        # the registry's one word for a two-part question
    "derivation": "derivation",
}

# THE CONTRACT DIALECT -> canonical. Identity throughout: the contract's spelling is the canonical
# one wherever the two disagreed, because the contract is the governed artefact and the registry is
# a reference shelf. Renaming the governed side to suit the shelf would be the wrong way round.
CONTRACT_MEASUREMENT = {
    "anchor": "anchor",
    "window": "window",
    "record_selection": "record_selection",
    "tie_break": "tie_break",
    "units": "units",
    "grain": "grain",
    "derivation": "derivation",
}

# WHAT ONE SIDE CAN SAY AND THE OTHER CANNOT. Declared, because these are the fields where an
# exchange genuinely loses something, and a mapping that omitted them would read as complete.
ONE_WAY = {
    "tie_break": "the contract states it; the registry's `selection` folds selection and "
                 "tie-break into one word, so a registry concept cannot carry a tie-break and a "
                 "confirmed match must take it from the contract side",
    "specimen": "the registry can state it; no contract record does, so this travels registry -> "
                "contract only",
    "value_type": "the registry can state it; the contract carries type on `output.type` rather "
                  "than as a measurement field, so the two are read from different places",
}


def canonical_measurement(dialect, d):
    """{canonical key: value} — one side's measurement fields, in the canonical vocabulary.

    UNMAPPED KEYS ARE AN ERROR, NOT A SKIP. A field this does not know is either a new measurement
    key nobody added to `MEASUREMENT`, or a typo; both are worth stopping for, and silently
    dropping either is how a window goes missing between two tools that both looked fine.
    """
    table = {"registry": REGISTRY_MEASUREMENT, "contract": CONTRACT_MEASUREMENT}[dialect]
    out, unknown = {}, []
    for k, v in (d or {}).items():
        if v in (None, "", [], {}):
            continue
        if str(k) not in table:
            unknown.append(str(k))
            continue
        out[table[str(k)]] = v
    return out, unknown


# --- what a contract row IS, before anything is matched to it -----------------------------------

# WHAT KIND OF THING A REQUIREMENT ROW DESCRIBES. Read from the contract's own `output.role` and
# `publish.ads`, which it already states on all 202 records — this vocabulary is not invented here,
# it is the contract's, named so the reconciler can act on it.
OUTPUT_ROLES = ("published",      # a column the product emits and a reader receives
                "internal",       # a helper the pipeline computes and the ADS does not carry
                "control",        # an instruction to the programmer; ships no column
                "metadata",       # describes the delivery rather than a patient
                "excluded",       # explicitly not emitted
                "unstated")       # the row does not say, which is itself a finding

# WHICH ROLES MAY BE PROPOSED AS THE REALISATION OF A CLINICAL CONCEPT. A concept is a clinical
# idea the product publishes; binding one to a row that ships no column would put a definition,
# window and units behind something no reader ever receives.
MATCHABLE_ROLES = ("published", "internal", "unstated")


def row_role(block):
    """(role, ads) — what the contract says this row is. Its own words, not an inference.

    `unstated` IS A RESULT. A row with no `output.role` is not assumed published; it is named, and
    it stays matchable because the omission is a gap in the contract rather than evidence the row
    ships nothing.
    """
    from rwd_tools import contract_lint as cl                                            # noqa: PLC0415
    o, p = cl._inline(block, "output"), cl._inline(block, "publish")
    role = (cl._kv(o, "role") or "").strip().lower() or "unstated"
    ads = (cl._kv(p, "ads") or "").strip().lower() or "unstated"
    return (role if role in OUTPUT_ROLES else "unstated"), ads


# --- how a row relates to the concept it is grouped under ---------------------------------------

# WHAT A ROW IS TO A CLINICAL CONCEPT. One laboratory concept generates a value, a date, a unit
# check, a status flag and a derived category: five rows, one idea. Until a row can say WHICH of
# those it is, a count of unmatched rows is a statement about how the specification was drafted and
# not about oncology, and "103 registry gaps" was exactly that number.
RELATIONS = ("realises",        # this row IS the concept's published form
             "component_of",    # a part of it: the date, the unit, the status flag
             "derives",         # computed from it: a category, a band, a change from baseline
             "supports",        # needed to compute it and not itself the concept
             "technical_only",  # a delivery or schema requirement, not clinical
             "control_only")    # an instruction to the programmer; ships nothing

# ONLY ONE OF THEM MAKES A ROW THE CONCEPT. The others are true statements about a relationship and
# must not be counted as coverage: a concept whose only contract presence is a `supports` row is
# not published by this product.
COVERING_RELATIONS = ("realises",)


# --- what a module file may contain --------------------------------------------------------------

# A SLOT: the reusable position. Everything here is a property of the position rather than of any
# one cancer's answer to it, which is the test for whether a key belongs on the slot.
SLOT_FIELDS = ("slot", "clinical_role", "applicability", "repeat", "tier", "module",
               "parameters", "why_concepts_differ", "concepts", "predicted_gap", "caveat",
               "basis", "measurement")

# A CONCEPT: what one cancer means by that position, and what it publishes for it.
CONCEPT_FIELDS = ("concept", "shape", "shape_change_reason", "realises", "definition",
                  "source_requirements", "implementation", "evidence", "parameter_values",
                  "derivation", "measurement")

# WHICH CONCEPT FIELDS ARE RE-KEYED FROM THE INVENTORY AND MAY NOT BE HAND-EDITED. These are the
# fields `registry_enrich` regenerates, and its `--check` compares them against `INVENTORY.yaml`
# byte for byte. Everything else in a module is authored here and is nobody's copy.
DERIVED_CONCEPT_FIELDS = ("definition", "source_requirements", "implementation", "evidence")


# --- which surface a row is on, and therefore which gap it counts against --------------------------

# FOUR DIFFERENT QUESTIONS THAT WERE BEING ANSWERED WITH ONE NUMBER. "How much of this product does
# the registry cover" has no single answer, because "this product" is four different sets:
#
#   ads_configured  what the ADS carries TODAY. The only set a reader actually receives.
#   published       what the contract INTENDS to publish, including rows whose ADS surface is still
#                   undecided or proposed. Larger than what ships.
#   internal        helpers the pipeline computes and the ADS does not carry. They can SUPPORT or
#                   DERIVE a concept and must never be counted as its published realisation.
#   matchable       everything a concept may legitimately bind to at all.
#
# Reporting one figure over `matchable` and calling it "columns this pack ships" overstated the
# denominator by 29 rows: 183 matchable against 154 actually configured. Both numbers are true and
# they answer different questions, so all four are computed and none is the headline.
SURFACES = ("ads_configured", "published", "internal", "matchable")

# WHICH SURFACES MAY CARRY A PUBLISHED REALISATION. An internal row is deliberately absent: the
# schema has always said `internal` is "a helper the pipeline computes and the ADS does not carry",
# and counting one as a concept's realisation claims the product publishes something no reader gets.
REALISABLE_SURFACES = ("ads_configured", "published")


def row_surfaces(role, ads):
    """The set of surfaces one contract row belongs to. A row is on several at once by design."""
    role, ads = str(role or "").lower(), str(ads or "").lower()
    out = set()
    if role in MATCHABLE_ROLES:
        out.add("matchable")
    if role == "published":
        out.add("published")
        if ads == "configured":
            out.add("ads_configured")
    if role == "internal":
        out.add("internal")
    return out


def may_realise(role, ads):
    """(bool, why) — may a concept's PUBLISHED realisation be bound to this row?"""
    surfaces = row_surfaces(role, ads)
    if surfaces & set(REALISABLE_SURFACES):
        return True, ""
    if "internal" in surfaces:
        return False, ("the contract calls this row `internal` — a helper the ADS does not carry. "
                       "It may `support` or `derive` a concept; calling it the concept's published "
                       "realisation claims the product publishes something no reader receives")
    return False, (f"role {role!r} is not a publishable surface, so nothing here can be a "
                   f"concept's published realisation")


# --- can this row and this concept be the same measurement? ----------------------------------------

# A CONSTRAINT WITH NO DATA IS NOT A CONSTRAINT, and pretending otherwise is worse than omitting it.
# Each rule below says what it needs on BOTH sides; where one side is silent the verdict is
# `not_evaluable`, which is reported separately and NEVER counted as a pass. Today four of the nine
# can run and five cannot, because the registry carries no measurement detail at all — and the count
# of what cannot run is the work-list for filling it.
#
# `hard` means a FAIL removes the candidate from `proposed`. A soft rule records a caution a
# reviewer should read and does not remove anything.
# `keys` NAMES WHICH CANONICAL MEASUREMENT KEYS EACH RULE READS, declared rather than inferred
# from the rule name. A worklist that guessed by substring mapped `anchor` to
# `care_phase_applies` because that rule's prose mentions the word — and then told a reader
# that filling `anchor` would unblock the wrong check.
CONSTRAINTS = (
    {"rule": "role_permits_realisation", "hard": True, "keys": (),
     "needs": "contract `output.role` (stated on every row); nothing from the registry",
     "why": "an internal helper cannot be a concept's published realisation"},
    # THE TWO DIRECTIONS ARE NOT SYMMETRIC, and treating them as one rule was wrong in a way worth
    # recording. A `once` concept on a grain keyed by line IS repeated — that is arithmetic. But a
    # `per_line` concept on `[patientid, index_date, cohortn]` is NOT necessarily flattened: in the
    # prostate contract COHORTN 3-7 ARE the lines (1L mHSPC, 1L mCRPC, 2L mCRPC, 3L mCRPC), so the
    # line is carried by the cohort key. As one hard rule this failed ECOG, OS, TTNT and TSST —
    # four bindings this repository had already certified as correct. A hard constraint that blocks
    # right answers is worse than the loose matching it replaced, so only the arithmetic direction
    # is hard and the other is a caution.
    {"rule": "grain_not_repeated", "hard": True, "keys": ("grain",),
     "needs": "contract `grain` (stated on every row) and slot `repeat` (stated on every slot)",
     "why": "a once-per-patient concept on a per-line grain is published once per line"},
    {"rule": "grain_carries_repetition", "hard": False, "keys": ("grain",),
     "needs": "contract `grain` and slot `repeat`",
     "why": "a per-line concept needs a grain that separates the lines — often a cohort key rather "
            "than a line number, which is why this is a caution and not a refusal"},
    {"rule": "one_realisation_per_slot", "hard": True, "keys": (),
     "needs": "the rulings already made; nothing from either document",
     "why": "two rows realising one concept means the product publishes it twice"},
    {"rule": "one_realisation_per_row", "hard": True, "keys": (),
     "needs": "the rulings already made",
     "why": "a row that realises two concepts is two measurements in one column"},
    {"rule": "value_type_agrees", "hard": True, "keys": ("value_type",),
     "needs": "contract `output.type` (stated) AND a datatype on the concept or its master "
              "(NOT STATED — 0 of 37 masters carry one)",
     "why": "a date concept bound to a string column is caught by nothing downstream"},
    {"rule": "units_agree", "hard": True, "keys": ("units",),
     "needs": "contract `units` (stated) AND concept `units` (NOT STATED — 0 of 61)",
     "why": "months against days looks right and is wrong by a factor of thirty"},
    {"rule": "specimen_agrees", "hard": True, "keys": ("specimen",),
     "needs": "concept `specimen` (NOT STATED — 0 of 61); no contract field carries one",
     "why": "serum and plasma are different measurements of the same analyte"},
    {"rule": "care_phase_applies", "hard": False, "keys": (),
     "needs": "slot `applicability` (stated on every slot) AND a care phase on the row (NOT "
              "STATED — the contract gives anchor and window as prose, and inferring a phase from "
              "prose is the guess this layer exists to avoid)",
     "why": "a baseline concept bound to an on-treatment column measures a different moment"},
    {"rule": "anchor_window_agree", "hard": False, "keys": ("anchor", "window"),
     "needs": "contract `anchor`/`window` (stated) AND concept `anchor`/`window` (NOT STATED — 0 "
              "of 61)",
     "why": "the same concept measured in two windows gives two different numbers"},
)

HARD_RULES = tuple(c["rule"] for c in CONSTRAINTS if c["hard"])

# WHAT A GRAIN THAT VARIES PER LINE OF THERAPY LOOKS LIKE. Read from the contract's own grain keys
# rather than guessed: prostate writes `[patientid, linenumber, linesetting]` for per-line rows and
# `[patientid, index_date, cohortn]` for one-row-per-patient-index rows.
LINE_KEYS = ("linenumber", "linesetting", "lotn", "line_number", "line")

# A COHORT KEY CAN CARRY THE LINE WITHOUT NAMING IT. Prostate's COHORTN 3-7 are 1L mHSPC, 1L mCRPC,
# 2L mCRPC and 3L mCRPC — so `[patientid, index_date, cohortn]` IS per-line, expressed through the
# cohort. Treating its absence of a line key as a flattening is what made the hard version of this
# rule reject four correct bindings.
COHORT_KEYS = ("cohortn", "cohortu", "cohortun", "cohort")


def _grain_keys(grain):
    return {t.strip().strip("[]").lower() for t in str(grain or "").split(",") if t.strip()}


# HOW A DATATYPE IS SPELLED ON EACH SIDE. The contract writes `output.type`; a concept writes a
# canonical `value_type`. Both are free text written by people, so they are normalised to a small
# family rather than compared literally — "double" and "float" are the same claim, and refusing a
# match on the spelling would be a rule that fires on vocabulary instead of on meaning.
_TYPE_FAMILY = {
    "date": "date", "datetime": "date", "timestamp": "date",
    "int": "number", "integer": "number", "double": "number", "float": "number",
    "decimal": "number", "numeric": "number", "number": "number", "months": "number",
    "days": "number", "years": "number",
    "str": "text", "string": "text", "varchar": "text", "char": "text", "code": "text",
    "categorical": "text", "boolean": "flag", "bool": "flag", "flag": "flag",
}


def type_family(text):
    """The datatype family a stated type belongs to, or None when it states nothing usable."""
    words = re.split(r"[^a-z]+", str(text or "").lower())
    fams = {_TYPE_FAMILY[w] for w in words if w in _TYPE_FAMILY}
    # A COMPOUND TYPE IS NOT A FAMILY. The contract writes `"string / integer"` where one column
    # carries two things; calling that either one would be a guess.
    return fams.pop() if len(fams) == 1 else None


def _norm_units(text):
    """A unit, reduced for comparison. `n/a` and friends state nothing and are not a unit."""
    t = " ".join(str(text or "").lower().split()).strip(' "')
    if not t or t in ("n/a", "na", "none", "todo", "unstated", "-"):
        return None
    return t.replace("(", "").replace(")", "")


def compatibility(row, candidate, taken_slots=(), taken_rows=()):
    """[{rule, verdict, why}] — can this row and this concept be the same measurement?

    THREE VERDICTS, AND THE THIRD IS THE POINT. `pass` and `fail` are ordinary. `not_evaluable`
    means one side states nothing, and it is kept distinct from `pass` because collapsing them is
    how a layer with no measurement data comes to look fully constrained. Five of the nine rules
    return it on every pair today.
    """
    out = []
    for spec in CONSTRAINTS:
        rule = spec["rule"]
        verdict, why = "not_evaluable", spec["needs"]

        if rule == "role_permits_realisation":
            okay, reason = may_realise(row.get("role"), row.get("ads"))
            verdict, why = ("pass", "") if okay else ("fail", reason)

        elif rule == "grain_not_repeated":
            # THE ARITHMETIC DIRECTION, and the only one safe to make hard. A concept measured ONCE
            # per patient, published on a grain keyed by line, is published once per line.
            repeat = str(candidate.get("repeat") or "").lower()
            keys = _grain_keys(row.get("grain"))
            if not repeat or not keys or keys <= {"todo", "dataset"}:
                verdict, why = "not_evaluable", "the row or the slot states no usable grain/repeat"
            elif repeat == "once" and keys & set(LINE_KEYS):
                verdict, why = "fail", (
                    f"the slot is measured once per patient and this column's grain is per line "
                    f"({sorted(keys & set(LINE_KEYS))}) — the concept would be repeated")
            else:
                verdict, why = "pass", ""

        elif rule == "grain_carries_repetition":
            # THE OTHER DIRECTION, DELIBERATELY SOFT. A `per_line` concept on
            # `[patientid, index_date, cohortn]` is not necessarily flattened: in this contract
            # COHORTN 3-7 ARE the lines, so the cohort key carries the repetition. Made hard, this
            # failed ECOG, OS, TTNT and TSST — four bindings already certified correct.
            repeat = str(candidate.get("repeat") or "").lower()
            keys = _grain_keys(row.get("grain"))
            if repeat != "per_line" or not keys or keys <= {"todo", "dataset"}:
                verdict, why = "not_evaluable", "only asked of a per-line slot with a stated grain"
            elif keys & set(LINE_KEYS):
                verdict, why = "pass", ""
            elif keys & set(COHORT_KEYS):
                verdict, why = "caution", (
                    f"the slot repeats per line and the grain names no line key, but it does name "
                    f"{sorted(keys & set(COHORT_KEYS))} — check that the cohort separates the "
                    f"lines, as it does here (cohorts 3-7 are 1L/2L/3L)")
            else:
                verdict, why = "caution", (
                    f"the slot repeats per line and this column's grain is {sorted(keys)} — check "
                    f"which line the value belongs to")

        elif rule == "one_realisation_per_slot":
            clash = candidate.get("slot") in set(taken_slots)
            verdict = "fail" if clash else "pass"
            why = "" if not clash else (f"{candidate.get('slot')} is already realised by another "
                                        f"row — a concept published twice is two columns claiming "
                                        f"to be one measurement")

        elif rule == "one_realisation_per_row":
            clash = row.get("row") in set(taken_rows)
            verdict = "fail" if clash else "pass"
            why = "" if not clash else ("this row already realises a different concept — one "
                                        "column cannot be two measurements")

        elif rule == "value_type_agrees":
            # THE CONTRACT CARRIES ITS TYPE ON `output.type`, NOT AS A MEASUREMENT FIELD — which
            # is exactly why `ONE_WAY` names `value_type`: the two sides state one fact in two
            # places, and a rule that looked for it in the same place on both would never fire.
            lhs = type_family(row.get("output_type"))
            rhs = type_family((candidate.get("measurement") or {}).get("value_type"))
            if lhs is None or rhs is None:
                verdict = "not_evaluable"
                why = ("the contract states no usable `output.type`" if lhs is None
                       else "the concept states no `value_type`")
            elif lhs == rhs:
                verdict, why = "pass", ""
            else:
                verdict, why = "fail", (f"the column is {lhs!r} and the concept is {rhs!r} — a "
                                        f"date concept published as text is caught by nothing "
                                        f"downstream")

        elif rule == "units_agree":
            lhs = _norm_units(row.get("units") or (row.get("measurement") or {}).get("units"))
            rhs = _norm_units((candidate.get("measurement") or {}).get("units"))
            if lhs is None or rhs is None:
                verdict = "not_evaluable"
                why = ("the contract states no units" if lhs is None
                       else "the concept states no units")
            elif lhs == rhs:
                verdict, why = "pass", ""
            else:
                verdict, why = "fail", (f"the column reports {lhs!r} and the concept is defined in "
                                        f"{rhs!r} — months against days looks right and is wrong "
                                        f"by a factor of thirty")

        elif rule == "specimen_agrees":
            lhs = _norm_units((row.get("measurement") or {}).get("specimen"))
            rhs = _norm_units((candidate.get("measurement") or {}).get("specimen"))
            if lhs is None or rhs is None:
                verdict = "not_evaluable"
                why = ("no contract field carries a specimen" if lhs is None
                       else "the concept states no specimen")
            elif lhs == rhs:
                verdict, why = "pass", ""
            else:
                verdict, why = "fail", (f"the column is measured on {lhs!r} and the concept on "
                                        f"{rhs!r} — serum and plasma are different measurements "
                                        f"of the same analyte")

        elif rule == "care_phase_applies":
            phases = {str(a).strip().lower() for a in (candidate.get("applicability") or []) if a}
            stated = str((row.get("measurement") or {}).get("care_phase") or "").strip().lower()
            if not phases or not stated:
                verdict = "not_evaluable"
                why = ("the slot states no applicability" if not phases
                       else "the contract states no care phase for this row; anchor and window are "
                            "prose, and inferring a phase from prose is the guess this layer "
                            "exists to avoid")
            elif stated in phases or "any" in phases:
                verdict, why = "pass", ""
            else:
                verdict, why = "caution", (f"the row is measured at {stated!r} and the slot applies "
                                           f"at {sorted(phases)} — a baseline concept bound to an "
                                           f"on-treatment column measures a different moment")

        elif rule == "anchor_window_agree":
            # BOTH KEYS, TOGETHER. An anchor without its window states half a measurement, and
            # crediting them separately would report a rule as answerable when it is not.
            pairs = []
            for key in ("anchor", "window"):
                lhs = _norm_units(row.get(key) or (row.get("measurement") or {}).get(key))
                rhs = _norm_units((candidate.get("measurement") or {}).get(key))
                pairs.append((key, lhs, rhs))
            if any(l is None or r is None for _k, l, r in pairs):
                verdict = "not_evaluable"
                why = ("the two sides do not both state an anchor AND a window; an anchor without "
                       "its window is half a measurement")
            else:
                differ = [k for k, l, r in pairs if l != r]
                verdict = "caution" if differ else "pass"
                why = "" if not differ else (
                    f"the two sides state different {' and '.join(differ)} — the same concept "
                    f"measured in two windows gives two different numbers")

        out.append({"rule": rule, "verdict": verdict, "hard": spec["hard"],
                    "why": why or spec["why"]})
    return out


def blocking(verdicts):
    """The hard rules this pairing FAILED. A candidate with any of these may not be proposed."""
    return [v["rule"] for v in verdicts if v["hard"] and v["verdict"] == "fail"]


def unevaluable(verdicts):
    return [v["rule"] for v in verdicts if v["verdict"] == "not_evaluable"]


# --- actual schemas for the documents, not just vocabularies for their values ----------------------

# WHY VOCABULARY CONSTANTS WERE NOT ENOUGH. `MEASUREMENT`, `RELATIONS` and `OUTPUT_ROLES` say what a
# VALUE may be. Nothing said what a DOCUMENT must contain, so a module with no `basis`, a ruling with
# no `rationale`, a seed with no `status` and a reconciliation missing an entire bucket were all
# well-formed as far as any code here could tell — each caller re-derived its own idea of the shape
# with `.get()` and a default, and a missing key read exactly like an empty one.
#
# THE VERDICTS AND THE RELATIONS LIVE HERE TOO, so there is one list. `template_reconcile` used to
# own `VERDICTS`, which is the same two-lists-and-a-hope that produced two measurement vocabularies.
VERDICTS = ("confirmed", "rejected", "deferred")


def F(kind, required=False, values=None, item=None, nullable=False, note=""):
    """One field's rule. Deliberately small: a schema nobody can read is not a schema."""
    return {"kind": kind, "required": required, "values": values, "item": item,
            "nullable": nullable, "note": note}


_CONCEPT = {
    "concept": F("str", required=True, note="what this cancer MEANS by the slot"),
    "shape": F("str", note="the inventory master this concept is an instance of"),
    "shape_change_reason": F("str", note="required when shape differs from the inventory's"),
    "realises": F("str_or_list", required=True, note="the product variable(s) it publishes"),
    "definition": F("str", note="DERIVED from INVENTORY.yaml; do not hand-edit"),
    "source_requirements": F("str", note="DERIVED"),
    "implementation": F("map", item={"class": F("str", required=True), "via": F("str")},
                        note="DERIVED"),
    "evidence": F("list", item=F("str"), note="DERIVED — citations"),
    "parameter_values": F("map", note="a person's answers to the slot's parameters"),
    "measurement": F("map", note="canonical measurement keys; authored, never derived"),
    "derivation": F("str", note="authored"),
}

_SLOT = {
    "slot": F("str", required=True),
    "clinical_role": F("str", required=True, note="without it two same-shaped concepts are "
                                                  "indistinguishable"),
    "applicability": F("list", required=True, item=F("str"), note="care phases; vocabulary from "
                                                                  "oncology_registry.APPLICABILITY"),
    "repeat": F("str", values=("once", "per_line", "as_indicated", "serial")),
    "parameters": F("map", note="what the slot leaves each cancer to pin"),
    "why_concepts_differ": F("str"),
    "concepts": F("map_of", item=_CONCEPT),
    "predicted_gap": F("str", note="required when a slot has no concepts"),
    "caveat": F("str"),
    "measurement": F("map"),
    "basis": F("str", required=True, note="a tier assignment with no stated reason cannot be "
                                          "reviewed"),
}

_RULING = {
    "variable_id": F("str", required=True),
    "slot": F("str", required=True),
    # `unstated` IS ADMITTED, and only for a ruling that is not a confirmation. Rejecting a
    # pairing does not require asserting what relation it would have had — the reviewer is saying
    # "not this", not "this, of kind X". A CONFIRMATION is different and is checked separately in
    # `template_reconcile.rulings`: confirming with no stated relation is ambiguous about the one
    # thing that decides whether coverage closes.
    "relation": F("str", required=True, values=RELATIONS + ("unstated",)),
    "verdict": F("str", required=True, values=VERDICTS),
    "decided_by": F("str", required=True, note="a confirmation nobody signed is not a person's act"),
    "decided_on": F("date", required=True),
    "rationale": F("str", required=True, note="a ruling with no reason cannot be reviewed or "
                                              "revisited"),
    # PER-RULING, NOT PER-DOCUMENT. A digest over the whole registry went stale for every ruling
    # whenever any module changed — so an unrelated cancer's edit sent every ruling back, and a
    # reviewer facing spurious re-reviews restamps without reading. This covers only what THIS
    # ruling rests on: its contract row, its slot's module, and the catalogue axes that chose that
    # module.
    "subject_digest": F("str", required=True,
                        note="what THIS ruling was decided against; without it the ruling can "
                             "never be known to be stale"),
}

_CONSTRAINT = {
    "rule": F("str", required=True),
    "verdict": F("str", required=True, values=("fail", "caution")),
    "why": F("str", required=True),
}

_CANDIDATE = {
    "slot": F("str", required=True),
    "module": F("str", required=True),
    "concept": F("str", nullable=True),
    "evidence": F("str", required=True),
    "score": F("num", required=True),
    "subject_digest": F("str", note="paste into a ruling; binds it to THIS row and THIS slot"),
    "registry_shape": F("str"),
    "registry_repeat": F("str", values=("once", "per_line", "as_indicated", "serial")),
    "registry_applicability": F("list", item=F("str")),
    "shared_terms": F("list", item=F("str")),
    "predicted_gap": F("str"),
    "blocked_by": F("list", item=F("str"), note="hard rules this pairing FAILED"),
    "not_evaluable": F("list", item=F("str"),
                       note="rules neither side carries the data to answer — never a pass"),
    "constraints": F("list", item=_CONSTRAINT),
    "comparison": F("list", item={
        "key": F("str", required=True),
        "stated_by": F("str", required=True,
                       values=("both", "contract_only", "registry_only")),
        "contract": F("str"), "registry": F("str")},
        note="what each document states about the same measurement question, key by key"),
}

_RECON_ROW = {
    "variable_id": F("str", required=True),
    "row": F("int", required=True),
    "role": F("str", required=True, values=OUTPUT_ROLES),
    "ads": F("str", required=True),
    "surfaces": F("list", item=F("str")),
    "canonical_output": F("str"),
    "output_type": F("str", nullable=True),
    "why": F("str"),
    "measurement": F("map"),
    "measurement_unstated": F("list", item=F("str")),
    "unevaluable_constraints": F("list", item=F("str"),
                                 note="rules no candidate on this row could answer"),
    "ruling": F("map"),
    # DERIVED, NOT SELF-DECLARED: whether the ruled slot was among the row's candidates is a fact
    # the tool knows, and asking a person to restate it invites a mismatch with the evidence.
    "selection_origin": F("str", values=("matcher_proposed", "reviewer_override")),
    "rulings": F("list", note="every ruling touching this row, with its derived selection_origin"),
    "candidates": F("list", required=True, item=_CANDIDATE),
    "disposition": F("str", nullable=True, values=VERDICTS),
    "decided_by": F("str", nullable=True),
}

_SEED_DECISION = {
    "slot": F("str", required=True),
    "decision": F("str", required=True, values=("accept", "decline", "defer")),
    "decided_by": F("str", required=True),
    "decided_on": F("date", required=True),
    "rationale": F("str", required=True),
    "subject_digest": F("str", required=True),
    "proposed_variable_name": F("str", note="what the spec row would be called, if accepted"),
}

SCHEMAS = {
    # WHAT A PERSON DID WITH EACH SLOT THE SEED OFFERED. A separate file because the seed itself is
    # generated and byte-checked — it carried `decision:` fields and comments inviting an edit that
    # the gate then made impossible, so following the instruction turned CI red.
    "seed_decisions": {
        "cancer": F("str", required=True),
        "decisions": F("list", required=True, item=_SEED_DECISION),
    },
    "module": {
        "module": F("str", required=True),
        "status": F("str", required=True),
        "reviewed_by": F("str", required=True, nullable=True),
        "reviewed_on": F("str", required=True, nullable=True),
        "derived_from": F("str", required=True),
        "derived_by": F("str", required=True),
        "derived_digest": F("str", required=True),
        "entries": F("list", required=True, item=_SLOT),
    },
    "rulings": {
        "cancer": F("str", required=True, note="binds the decisions to an indication"),
        "rulings": F("list", required=True, item=_RULING),
    },
    "seed": {
        "cancer": F("str", required=True),
        "status": F("str", required=True, values=("proposed",),
                    note="a seed is never anything else; Gate 2 approves the contract written FROM it"),
        "accepted_by": F("str", required=True, nullable=True),
        "accepted_on": F("str", required=True, nullable=True),
        "slots_offered": F("int", required=True),
        "slots_prompting": F("int", required=True),
        "inputs_digest": F("str", required=True),
        "inputs": F("map", required=True),
        "slots": F("list", required=True,
                   note="each carries the subject_digest a decision on it must quote"),
    },
    "reconciliation": {
        "cancer": F("str", required=True),
        "contract_rows": F("int", required=True),
        "canonical_outputs": F("int", required=True),
        "template_concepts": F("int", required=True),
        "predicted_gaps": F("int", required=True),
        "confirmed_by": F("str", required=True, nullable=True,
                          note="this file never confirms; see TEMPLATE_RULINGS.yaml"),
        "confirmed_on": F("str", required=True, nullable=True),
        "inputs_digest": F("str", required=True),
        "inputs": F("map", required=True),
        "surfaces": F("map", note="per-surface row/output/gap counts"),
        "confirmed": F("list", required=True, item=_RECON_ROW),
        "proposed": F("list", required=True, item=_RECON_ROW),
        "ambiguous": F("list", required=True, item=_RECON_ROW),
        "incompatible": F("list", required=True, item=_RECON_ROW,
                          note="strong name evidence AND a failed hard rule"),
        "possible": F("list", required=True, item=_RECON_ROW),
        "unmatched": F("list", required=True, item=_RECON_ROW),
        "not_matchable": F("list", required=True, item=_RECON_ROW),
        "template_only": F("list", required=True, item=F("str")),
        "template_only_hinted": F("list", required=True, item=F("str")),
    },
}


def _kind_ok(kind, v):
    if kind == "str":
        return isinstance(v, str)
    if kind == "num":
        return isinstance(v, (int, float)) and not isinstance(v, bool)
    if kind == "int":
        return isinstance(v, int) and not isinstance(v, bool)
    if kind == "list":
        return isinstance(v, list)
    if kind in ("map", "map_of"):
        return isinstance(v, dict)
    if kind == "str_or_list":
        return isinstance(v, (str, list))
    if kind == "date":
        return isinstance(v, str) and bool(re.match(r"^\d{4}-\d{2}-\d{2}$", v)) \
            or hasattr(v, "isoformat")
    return True


def validate(name, doc, where=""):
    """[problem] — everything wrong with one document. [] is a pass.

    UNKNOWN KEYS ARE REFUSED, not ignored. A misspelled `rationale` that silently becomes an extra
    field is the same class of defect as a missing one, and harder to see: the file LOOKS complete.
    """
    schema = SCHEMAS[name] if isinstance(name, str) else name
    out = []
    tag = f"{where}: " if where else ""
    if not isinstance(doc, dict):
        return [f"{tag}not a mapping ({type(doc).__name__})"]

    for key, spec in sorted(schema.items()):
        if key not in doc:
            if spec["required"]:
                out.append(f"{tag}{key} is required and absent"
                           + (f" — {spec['note']}" if spec["note"] else ""))
            continue
        v = doc[key]
        if v is None:
            if not spec["nullable"]:
                out.append(f"{tag}{key} is null and may not be")
            continue
        if not _kind_ok(spec["kind"], v):
            out.append(f"{tag}{key} should be {spec['kind']}, got {type(v).__name__}")
            continue
        if spec["values"] and str(v) not in [str(x) for x in spec["values"]]:
            out.append(f"{tag}{key}={v!r} is not one of {tuple(spec['values'])}")
        item = spec["item"]
        if item and spec["kind"] == "list":
            for i, el in enumerate(v):
                if isinstance(item, dict) and "kind" in item:
                    if el is not None and not _kind_ok(item["kind"], el):
                        out.append(f"{tag}{key}[{i}] should be {item['kind']}")
                else:
                    out += validate(item, el, f"{tag}{key}[{i}]".rstrip())
        elif item and spec["kind"] == "map_of":
            for k, el in sorted(v.items()):
                out += validate(item, el, f"{tag}{key}.{k}")
        elif item and spec["kind"] == "map":
            out += validate(item, v, f"{tag}{key}")

    for key in sorted(doc):
        if key not in schema:
            out.append(f"{tag}{key!r} is not a field of the {name if isinstance(name, str) else 'nested'} "
                       f"schema — a key nothing reads is either a typo or an undeclared field")
    return out


def yaml_scalar(v):
    """One YAML scalar that reloads as the value it was written from. THE only one.

    THERE WERE TWO, AND ONE OF THEM WAS WRONG. `registry_enrich` round-trips through a real YAML
    dumper; the seed writer used `value or "null"`, which turns the perfectly good answers `0`,
    `false` and `""` into `null` — so a reviewer who pinned a lookback of 0 months read back that
    nobody had pinned anything. A falsey value is an answer, and `or` cannot tell it from an absent
    one. Every artefact now goes through here.
    """
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return repr(v)
    s = str(v)
    unsafe = (not s or s[0].isdigit() or s[0] in '-?:,[]{}#&*!|>\'%@`\\"'
              or s[0] in (' ', chr(9))
              or s.lower() in ("null", "true", "false", "yes", "no", "on", "off", "~")
              or s != s.strip() or ':' in s or '#' in s)
    if not unsafe:
        return s
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"') + '"'


def schema_errors():
    """Problems with the vocabularies themselves. [] is a pass.

    A SCHEMA THAT CONTRADICTS ITSELF FAILS EVERY CONSUMER AT ONCE, so it is checked first and
    cheaply: every dialect must map into the canonical set, no canonical key may be unreachable
    without being declared one-way, and the two role lists must agree.
    """
    out = []
    for name, table in (("registry", REGISTRY_MEASUREMENT), ("contract", CONTRACT_MEASUREMENT)):
        for src, dst in sorted(table.items()):
            if dst not in MEASUREMENT:
                out.append(f"{name} dialect maps {src!r} to {dst!r}, which is not a canonical "
                           f"measurement key")
    reachable = set(REGISTRY_MEASUREMENT.values()) | set(CONTRACT_MEASUREMENT.values())
    for k in MEASUREMENT:
        if k not in reachable and k not in ONE_WAY:
            out.append(f"canonical key {k!r} is reachable from neither dialect and is not declared "
                       f"in ONE_WAY — an unreachable key is a key nothing can ever fill")
    for k in ONE_WAY:
        if k not in MEASUREMENT:
            out.append(f"ONE_WAY names {k!r}, which is not a canonical measurement key")
    for r in MATCHABLE_ROLES:
        if r not in OUTPUT_ROLES:
            out.append(f"MATCHABLE_ROLES names {r!r}, which is not an output role")
    for r in COVERING_RELATIONS:
        if r not in RELATIONS:
            out.append(f"COVERING_RELATIONS names {r!r}, which is not a relation")
    if set(DERIVED_CONCEPT_FIELDS) - set(CONCEPT_FIELDS):
        out.append("a derived concept field is not a concept field: "
                   f"{sorted(set(DERIVED_CONCEPT_FIELDS) - set(CONCEPT_FIELDS))}")
    return out



@dataclass(frozen=True)
class RegistryFinding:
    """One independently evaluated registry or catalogue consistency failure."""
    check: str
    message: str
    details: dict[str, str] = field(default_factory=dict)




def _registry_findings(checks, selected):
    from yaml import YAMLError
    names = tuple(checks) if selected is None else tuple(selected)
    if len(set(names)) != len(names) or any(name not in checks for name in names):
        raise ValueError("Choose distinct registered consistency checks.")
    findings = []
    for name in names:
        try:
            findings.extend(checks[name]() or [])
        except (OSError, ValueError, TypeError, KeyError, AttributeError, IndexError, YAMLError) as error:
            findings.append(RegistryFinding(name, str(error)))
    return findings


def product_registry_findings(root, *, selected_checks=None) -> list[RegistryFinding]:
    """Check current workspace data; no source-checkout test files are needed."""
    from pathlib import Path
    from engine.config import load_yaml, load_config, product_config, product_dir
    from engine import validate
    from rwd_tools import product_gates
    PRODUCTS = Path(root).resolve(strict=True) / 'products'
    REGISTRY = PRODUCTS / 'registry.yaml'
    VALID_STATUS = {'active', 'scaffold', 'planned'}

    def _tumors():
        out = [dict(t, _root='products') for t in load_yaml(REGISTRY)['tumors']]
        fx = REGISTRY.parent.parent / 'fixtures' / 'registry.yaml'
        if fx.exists():
            out += [dict(t, _root='fixtures') for t in load_yaml(fx).get('tumors') or []]
        return out

    def _check_registry_well_formed():
        policy = load_yaml(PRODUCTS.parent / 'governance/vendor_policy.yaml')
        policy_errors = product_gates.vendor_policy_errors(str(PRODUCTS.parent))
        if not not policy_errors:
            raise ValueError('Vendor policy: ' + '; '.join(policy_errors))
        slugs = set()
        for t in _tumors():
            for k in ('code', 'name', 'slug', 'status', 'vendor', 'tumor_class'):
                if not k in t:
                    raise ValueError(f"registry entry missing '{k}': {t}")
            if not t['status'] in VALID_STATUS:
                raise ValueError(f"bad status {t['status']!r} in {t}")
            if not t['vendor'] in policy['vendors']:
                raise ValueError(f'bad vendor in {t}')
            if not product_gates.pack_modality(t)[1] is None:
                raise ValueError(f'bad modality in {t}')
            condition = str(t.get('condition_class', 'oncology')).strip().lower()
            classes = {'oncology': {'solid', 'heme'}, 'non_oncology': {'not_applicable'}}
            if condition not in classes or t['tumor_class'] not in classes[condition]:
                raise ValueError(f"{t['slug']}: condition_class {condition!r} and tumor_class {t['tumor_class']!r} "
                                 "must be oncology with solid/heme, or non_oncology with not_applicable")
            if condition == 'non_oncology' and t.get('family') != 'conditions':
                raise ValueError(f"{t['slug']}: non_oncology products use family: conditions")
            if not t['slug'] not in slugs:
                raise ValueError(f"duplicate slug: {t['slug']}")
            slugs.add(t['slug'])

    def _check_cota_tumors_are_heme():
        for t in _tumors():
            if t['vendor'] == 'cota' and t.get('condition_class', 'oncology') == 'oncology':
                if not t['tumor_class'] == 'heme':
                    raise ValueError(f'COTA tumor not heme: {t}')

    def _check_active_tumors_have_a_config():
        for t in _tumors():
            if t['status'] != 'active':
                continue
            cfg_path = product_config(PRODUCTS.parent / t['_root'], t['slug'])
            if not cfg_path.exists():
                raise ValueError(f"active tumor '{t['code']}' has no config at {cfg_path}")

    def _check_tumors_with_config_lint_clean():
        for t in _tumors():
            if 'current_spec_version' not in t:
                continue
            cfg_path = product_config(PRODUCTS.parent / t['_root'], t['slug'])
            if not cfg_path.exists():
                continue
            cfg = load_config(cfg_path)
            modality, bad = product_gates.pack_modality(t)
            if not bad is None:
                raise ValueError(bad)
            for field in ('vendor', 'tumor_class', 'condition_class'):
                default = 'oncology' if field == 'condition_class' else None
                if cfg.raw.get(field, default) != t.get(field, default):
                    raise ValueError(f"{t['code']}: {modality} {field} differs between configuration and registry")
            if modality == 'claims':
                if not t['status'] == 'scaffold':
                    raise ValueError(f"{t['code']}: claims execution is not implemented; keep this product scaffold")
                if not cfg.raw.get('data_product_id'):
                    raise ValueError(f"{t['code']}: claims product identity is missing")
                rel = cfg_path.parent.parent.relative_to(PRODUCTS.parent).as_posix()
                probs = product_gates.maturity_errors(str(PRODUCTS.parent), rel)
            else:
                probs = validate.problems(cfg, strict=False)
            if not probs == []:
                raise ValueError(f"{t['code']} config problems: {probs}")

    def _check_registry_status_matches_config_status():
        conflicts = []
        for t in _tumors():
            if 'current_spec_version' not in t:
                continue
            cfg_path = product_config(PRODUCTS.parent / t['_root'], t['slug'])
            if not cfg_path.exists():
                continue
            cstatus = load_yaml(cfg_path).get('status')
            if not cstatus == t['status']:
                conflicts.append(RegistryFinding(
                    'registry_status_matches_config_status',
                    f"{t['code']}: registry status '{t['status']}' != config status '{cstatus}'",
                    {"product": str(t['slug']), "product_code": str(t['code']),
                     "pack": cfg_path.parent.parent.relative_to(PRODUCTS.parent).as_posix(),
                     "registry_status": str(t['status']), "config_status": str(cstatus),
                     "registry_file": t['_root'] + '/registry.yaml',
                     "config_file": cfg_path.relative_to(PRODUCTS.parent).as_posix()}))
        return conflicts

    def _check_no_two_packs_share_an_output_table():
        """Every release name — staging, versioned tables, views, the __release pointer, the promotion
        lock — derives from run.output_table, correctly parameterized per product. But nothing checked
        two packs don't DECLARE the same table: a copy-pasted pipeline.yaml pointed at another
        product's table would publish over its views with every other guard passing."""
        seen = {}
        for t in _tumors():
            if 'current_spec_version' not in t:
                continue
            cfg = load_config(product_config(PRODUCTS.parent / t['_root'], t['slug']))
            table = (cfg.raw.get('run') or {}).get('output_table')
            if not table or 'REPLACE_ME' in str(table):
                continue
            if not table not in seen:
                raise ValueError(f"{t['code']} and {seen[table]} both declare run.output_table {table!r} — one product's release would silently publish over the other's views")
            seen[table] = t['code']

    def _check_registry_lineage_matches_config():
        for t in _tumors():
            if 'current_spec_version' not in t:
                continue
            cfg = load_config(product_config(PRODUCTS.parent / t['_root'], t['slug']))
            spec = cfg.spec_version
            if not spec == t['current_spec_version']:
                raise ValueError(f"{t['code']}: config spec {spec} != registry current_spec_version {t['current_spec_version']}")
            if 'current_output_table' in t:
                if not t['current_output_table'] == (cfg.raw.get('run') or {}).get('output_table'):
                    raise ValueError(f"{t['code']}: registry output table {t['current_output_table']} != config run.output_table")
            if t.get('lineage'):
                cur = [ln for ln in t['lineage'] if ln.get('spec_version') == t['current_spec_version']]
                if not (cur and cur[0].get('status') == 'active'):
                    raise ValueError(f"{t['code']}: current_spec_version {t['current_spec_version']} has no active lineage entry")

    def _check_active_product_packs_are_not_scaffold():
        for t in _tumors():
            if t['status'] != 'active':
                continue
            root = product_dir(PRODUCTS.parent / t['_root'], t['slug'])
            raw = load_yaml(root / 'config' / 'data_product.yaml')
            rels = list(raw.get('variables') or []) + list((raw.get('codelists') or {}).values())
            for rel in rels:
                pack = load_yaml(root / rel)
                if not pack.get('status') != 'scaffold':
                    raise ValueError(f"{t['code']} is active but composes scaffold pack/codelist '{rel}'")
    checks = {'registry_well_formed': _check_registry_well_formed, 'cota_tumors_are_heme': _check_cota_tumors_are_heme, 'active_tumors_have_a_config': _check_active_tumors_have_a_config, 'tumors_with_config_lint_clean': _check_tumors_with_config_lint_clean, 'registry_status_matches_config_status': _check_registry_status_matches_config_status, 'no_two_packs_share_an_output_table': _check_no_two_packs_share_an_output_table, 'registry_lineage_matches_config': _check_registry_lineage_matches_config, 'active_product_packs_are_not_scaffold': _check_active_product_packs_are_not_scaffold}
    return _registry_findings(checks, selected_checks)


def product_catalog_findings(root, *, selected_checks=None) -> list[RegistryFinding]:
    """Check current workspace data; no source-checkout test files are needed."""
    from pathlib import Path
    from engine.config import load_yaml, product_config, product_dir
    PRODUCTS = Path(root).resolve(strict=True) / 'products'
    REGISTRY = PRODUCTS / 'registry.yaml'
    CATALOG = PRODUCTS / 'metadata' / 'catalog.yaml'
    DASHBOARD = PRODUCTS / '_reporting' / 'dashboard' / 'dashboard_vars.yaml'

    def _catalog():
        return load_yaml(CATALOG)

    def _registered_codes():
        codes = {t['code'] for t in load_yaml(REGISTRY)['tumors']}
        fx = REGISTRY.parent.parent / 'fixtures' / 'registry.yaml'
        if fx.exists():
            codes |= {t['code'] for t in load_yaml(fx).get('tumors') or []}
        return codes

    def _declared_codes(cat, field):
        values = cat.get(field, [])
        if not isinstance(values, list):
            raise ValueError(f'catalog {field} must be a list')
        if not all((isinstance(code, str) and code.strip() == code and code for code in values)):
            raise ValueError(f'catalog {field} must contain non-empty code strings')
        if not len(values) == len(set(values)):
            raise ValueError(f'duplicate catalog {field} code')
        return set(values)

    def _check_catalog_well_formed():
        cat = _catalog()
        if not 'tumor_codes' in cat:
            raise ValueError('catalog must declare tumor_codes, including [] for an empty installation')
        _declared_codes(cat, 'tumor_codes')
        _declared_codes(cat, 'reference_tumor_codes')
        codes = set()
        for v in cat['variables']:
            for k in ('code', 'category', 'label', 'applies_to'):
                if not k in v:
                    raise ValueError(f"catalog variable missing '{k}': {v}")
            if not v['code'] not in codes:
                raise ValueError(f"duplicate catalog code: {v['code']}")
            codes.add(v['code'])

    def _check_applies_to_codes_are_registered():
        reg = _registered_codes()
        cat = _catalog()
        installed = _declared_codes(cat, 'tumor_codes')
        if not installed <= reg:
            raise ValueError(f'catalog tumor_codes not in registry: {installed - reg}')
        if not reg <= installed:
            raise ValueError(f'registry tumors missing from catalog tumor_codes: {reg - installed}')
        known = reg | _declared_codes(cat, 'reference_tumor_codes')
        for v in cat['variables']:
            a = v['applies_to']
            if a == 'all':
                continue
            if not (isinstance(a, list) and a):
                raise ValueError(f"variable '{v['code']}' applies_to must be 'all' or a non-empty list")
            bad = set(a) - known
            if not not bad:
                raise ValueError(f"variable '{v['code']}' applies_to unknown tumor(s): {bad}")

    def _check_dashboard_variables_resolve_to_catalog():
        catalog_codes = {v['code'] for v in _catalog()['variables']}
        dash = load_yaml(DASHBOARD)
        for panel in dash['panels']:
            for var in panel['variables']:
                if not var in catalog_codes:
                    raise ValueError(f"dashboard panel '{panel['id']}' references unknown variable '{var}'")

    def _check_catalog_documents_every_emitted_variable():
        from engine.config import load_config
        from engine.validate import emitted_variables
        from engine.dictionary import _applies, _emitted
        from engine.product_catalog import merge
        from engine.stages.assemble import PUBLICATION_MANDATORY
        from rwd_tools.contract_binding import CODE_COLUMN_SUFFIX, _configured_publication
        master = _catalog()
        _fx = REGISTRY.parent.parent / 'fixtures' / 'registry.yaml'
        _tumors = [dict(t, _root='products') for t in load_yaml(REGISTRY)['tumors']] + ([dict(t, _root='fixtures') for t in load_yaml(_fx).get('tumors') or []] if _fx.exists() else [])
        for t in _tumors:
            slug, tcode = (t.get('slug'), t.get('code'))
            if not (slug and tcode and t.get('current_spec_version')):
                continue
            pack_root = product_dir(PRODUCTS.parent / t['_root'], slug).parent
            if not pack_root.exists():
                continue
            for sv in sorted((d.name for d in pack_root.iterdir() if (d / 'config' / 'data_product.yaml').exists())):
                cfg = load_config(product_config(PRODUCTS.parent / t['_root'], slug, spec_version=sv))
                cat = merge(cfg, master)
                labels = emitted_variables(cfg)
                emitted = labels
                companions = {}
                publication = _configured_publication(cfg)
                if publication is not None:
                    # The canonical projection checks actual configured outputs,
                    # duplicates and mandatory identity before narrowing coverage.
                    # Only engine identity keys already outside the catalogue's
                    # label-level inventory retain that existing boundary.
                    emitted = set(publication) - (set(PUBLICATION_MANDATORY) - labels)
                    # Only real native companions omitted by the label inventory
                    # use the existing binder convention. A custom passthrough or
                    # derived name ending in n is itself in labels and cannot borrow
                    # another variable's documentation.
                    companions = {name: name[:-len(CODE_COLUMN_SUFFIX)] for name in emitted
                                  if name not in labels and name.endswith(CODE_COLUMN_SUFFIX)
                                  and name[:-len(CODE_COLUMN_SUFFIX)] in labels
                                  and name[:-len(CODE_COLUMN_SUFFIX)] in publication}

                def entries_for(name):
                    entries = [entry for entry in cat['variables'] if _emitted(entry, {name.lower()})]
                    return [entry for entry in entries if not entry.get('line_template')] or entries

                missing = set()
                for name in emitted:
                    entries = entries_for(name)
                    if not entries and name in companions:
                        entries = entries_for(companions[name])
                    if not any(_applies(entry, tcode) for entry in entries):
                        missing.add(name)
                if not not missing:
                    raise ValueError(f"{slug}/{sv}: emitted but uncataloged for '{tcode}': {sorted(missing)}")

    def _check_catalog_ledger_fields_well_formed():
        import re
        cat = _catalog()
        codes = _registered_codes() | _declared_codes(cat, 'reference_tumor_codes')
        STATUS = {'implemented', 'planned', 'deprecated'}
        for v in cat['variables']:
            for field in ('introduced_in', 'deprecated_in'):
                if field in v:
                    if not (isinstance(v[field], dict) and v[field]):
                        raise ValueError(f"{v['code']}.{field} must be a non-empty map")
                    for code, ver in v[field].items():
                        if not code in codes:
                            raise ValueError(f"{v['code']}.{field}: unknown tumor code '{code}'")
                        if not re.match('^\\d{6}$', str(ver)):
                            raise ValueError(f"{v['code']}.{field}[{code}]: '{ver}' not YYYYMM")
            if 'status' in v:
                if not v['status'] in STATUS:
                    raise ValueError(f"{v['code']}.status '{v['status']}' not in {sorted(STATUS)}")
    checks = {'catalog_well_formed': _check_catalog_well_formed, 'applies_to_codes_are_registered': _check_applies_to_codes_are_registered, 'dashboard_variables_resolve_to_catalog': _check_dashboard_variables_resolve_to_catalog, 'catalog_documents_every_emitted_variable': _check_catalog_documents_every_emitted_variable, 'catalog_ledger_fields_well_formed': _check_catalog_ledger_fields_well_formed}
    return _registry_findings(checks, selected_checks)


def main(argv=None):
    from rwd_tools.console import use_utf8                                          # noqa: PLC0415
    use_utf8()
    import argparse                                                       # noqa: PLC0415
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("--check", action="store_true", help="GATE: exit 1 on a broken vocabulary")
    ap.add_argument("--check-products", action="store_true", help="Check installed product registries and configurations")
    ap.add_argument("--check-catalog", action="store_true", help="Check master catalogue coverage and registry consistency")
    ap.add_argument("--root", default=ROOT, help="Authoring workspace for product and catalogue checks")
    ap.add_argument("--json", action="store_true", help="Emit typed consistency findings")
    a = ap.parse_args(argv)
    if a.check_products or a.check_catalog:
        findings = []
        if a.check_products:
            findings.extend(product_registry_findings(a.root))
        if a.check_catalog:
            findings.extend(product_catalog_findings(a.root))
        if a.json:
            import json
            from dataclasses import asdict
            print(json.dumps({"ok": not findings, "findings": [asdict(item) for item in findings]}))
        else:
            for item in findings:
                print(f"REFUSED {item.check}: {item.message}", file=sys.stderr)
            if not findings:
                print("Registry consistency checks passed.")
        return 1 if findings else 0
    if a.json:
        ap.error("--json requires --check-products or --check-catalog")

    print("canonical measurement")
    for k in MEASUREMENT:
        frm = [d for d, t in (("registry", REGISTRY_MEASUREMENT),
                              ("contract", CONTRACT_MEASUREMENT)) if k in t.values()]
        print(f"    {k:<18} from {', '.join(frm) if frm else '(neither)'}")
    print("")
    print("one-way, and why")
    for k, why in sorted(ONE_WAY.items()):
        print(f"    {k:<18} {why}")
    print("")
    print(f"output roles       {', '.join(OUTPUT_ROLES)}")
    print(f"  matchable        {', '.join(MATCHABLE_ROLES)}")
    print(f"relations          {', '.join(RELATIONS)}")
    print(f"  covering         {', '.join(COVERING_RELATIONS)}")

    errs = schema_errors()
    if errs:
        print("", file=sys.stderr)
        print(f"REFUSED — {len(errs)} problem(s) with the schema itself:", file=sys.stderr)
        for e in errs:
            print(f"  {e}", file=sys.stderr)
        return 1
    if a.check:
        print("")
        print("ok — both dialects map into one canonical measurement vocabulary")
    return 0


if __name__ == "__main__":
    sys.exit(main())
