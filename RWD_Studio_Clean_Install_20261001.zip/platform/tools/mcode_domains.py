#!/usr/bin/env python3
"""Which mCODE STU4 profile is a concept's DOMAIN — the ruling, and the gate that keeps it true.

    python3 platform/tools/mcode_domains.py                  # the map, and what it abstains on
    python3 platform/tools/mcode_domains.py --check          # GATE: exit 1 on a broken ruling
    python3 platform/tools/mcode_domains.py --format json
    python3 platform/tools/mcode_domains.py --unmapped       # masters with no profile, and why

WHY THIS EXISTS, MEASURED. `semantic_export.template()` emitted a concept's domain like this:

    node["rwdp:domain"] = str(master["category"])

`category` is one of SEVEN hand-made labels — `staging_histology`, `comorbidity_labs`,
`eligibility_index`, `biomarkers`, `demographics`, `outcomes`, `treatment` — carried on 37 masters
in `governance/reference/variable_inventory/INVENTORY.yaml`, a file whose own header reads
`status: reference_only` and describes itself as "a drafting AID, never a specification". So the
published domain of every concept in the semantic graph was a private vocabulary invented here,
sourced from a shelf that explicitly disclaims authority, and unresolvable by anyone outside this
repository.

Meanwhile `governance/reference/mcode_stu4/DICTIONARY.json` already carries 38 HL7 profiles, 417
elements and 103 value sets, each profile with a canonical FHIR URL — `ECOG Performance Status
Profile` at http://hl7.org/fhir/us/mcode/StructureDefinition/mcode-ecog-performance-status. That
is exactly a domain vocabulary, published by a standards body, and it was being used for nothing:
`semantic_export.py` contained ZERO occurrences of the string "mcode".

This file is the ruling that connects the two, and the gate that stops it drifting.

IT MAPS THE DOMAIN, IT DOES NOT REPLACE IT. An earlier cut emitted the profile as `rwdp:domain`
itself, and that model loses the domain of every concept mCODE does not type — eighteen of the
thirty-seven masters here. mCODE profiles describe how oncology information is represented in
FHIR; they are not a taxonomy for analytical data-product domains, and a derived endpoint or a
study construct is not a gap in mCODE so much as a thing outside its scope. So the programme's
own analytic domain stays authoritative and this ruling is published beside it, as
`rwdp:mcodeProfile` with its label, confidence and caveat.

ABSTENTION IS A RESULT, AND IT IS A THIRD OF THE MAP. mCODE types CLINICAL FACTS. It has no profile
for a derived time-to-event outcome (rwPFS, TTNT, overall survival as an analysis endpoint), for a
study-design construct (index date, cohort eligibility, data continuity), or for an administrative
attribute (payer, practice setting). Those masters map to NOTHING and say so in `why_none`, which is
a finding about the boundary between mCODE and real-world study design — not a gap to be filled.
A forced mapping would be strictly worse than a null: it would publish a false domain on a concept
that a downstream consumer would then trust. `--unmapped` prints them so the boundary stays visible.

THE PROFILE TITLE IS CHECKED AGAINST THE EXTRACT, EVERY RUN. `map_errors()` refuses a title that is
not byte-exact in DICTIONARY.json. That is what makes this survive an mCODE version bump: when STU5
renames or drops a profile, `--check` fails loudly and names the entries to re-rule, instead of the
graph quietly emitting a domain that no longer exists. The same discipline `umls_relations` uses for
a UMLS release, pointed at the other standard.

THE CODES ARE NOT IN THE DICTIONARY, AND TWO RULINGS WERE WRONG BECAUSE OF IT. `DICTIONARY.json`
carries each value set as a TITLE AND DESCRIPTION ONLY; the 2,626 bound codes live beside it in
`VALUE_SET_CODES.json`. So a search of the dictionary for "microsatellite" or "fusion" returns
nothing and is structurally incapable of returning anything — which reads exactly like proof that
mCODE does not type the concept. Two masters were nearly filed that way: the Tumor Marker Test
Value Set actually carries 50 rearrangement codes, 22 fusion codes and three microsatellite codes,
including `81695-9 Microsatellite instability [Interpretation]`. ANY claim that mCODE lacks a
concept must be checked against the EXPANSION, not the dictionary. The binding content is the
operative constraint, not the value set's prose — that same value set describes itself as measuring
protein levels "downstream from RNA protein synthesis" while its expansion is full of
molecular-genetics codes.

AND THE EXPANSION DOES NOT PROVE ABSENCE EITHER. `VALUE_SET_CODES.json` enumerates 74 of the
dictionary's 103 value sets, and none of the EXTERNAL ones a binding reaches by URI — `hgnc-vs`,
`LL1971-2`, `hgvs-vs`. So a gene symbol returning zero across all 2,626 codes proves nothing about
whether mCODE can name that gene: `Genomic Variant Profile > Component > Value` binds `hgnc-vs`
extensibly and can carry any HGNC symbol. TRIPLE_NEGATIVE_STATUS was first filed as an abstention
on exactly that reasoning, and it was wrong twice over — HRR_PANEL and IPSSM_GENE_PANEL had
already been ruled onto that profile for genes with the same zero count.

THE RULE, THEN, IS A SEQUENCE: check the element BINDINGS in DICTIONARY.json first, then the
expansion in VALUE_SET_CODES.json, and only claim mCODE lacks a concept when both come back
empty AND no element's binding could carry it.

CONFIDENCE IS RECORDED, NOT AVERAGED AWAY. `exact` means the profile IS the concept; `partial` means
it covers part of it and `caveat` says which part is uncovered. A reviewer reads the caveats first —
they are where this map is most likely to be wrong.

TOOLS PROPOSE, PEOPLE RULE. `mcode_crosswalk.py` proposes candidates from prose and code overlap;
this file is where a proposal becomes a decision, and every entry carries the basis it was decided
on. Nothing here is generated at build time.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))

REFERENCE = os.path.join(ROOT, "governance", "reference", "mcode_stu4")
DICTIONARY = os.path.join(REFERENCE, "DICTIONARY.json")
CODES = os.path.join(REFERENCE, "VALUE_SET_CODES.json")
MAP_PATH = os.path.join(REFERENCE, "DOMAIN_MAP.yaml")
INVENTORY = os.path.join(ROOT, "governance", "reference", "variable_inventory", "INVENTORY.yaml")

# What a mapping may claim about itself. `none` is not a weaker `weak` — it is the statement that
# mCODE does not type this kind of thing at all, which is a different assertion and is checked
# differently (it requires `why_none` and forbids a profile).
CONFIDENCE = ("exact", "strong", "partial", "weak", "none")

# WHO STANDS BEHIND THE RULING. `proposed` is the honest state of a map a machine drafted, however
# carefully; `approved` requires a named person and a date, and NOTHING here may write those —
# the same bar EQUIVALENCE_RULINGS.yaml and LOCAL_RELATIONS.yaml set. A proposed map is usable and
# says so; it must never be able to pass as reviewed.
STATUSES = ("proposed", "approved")


def dictionary_digest(path=DICTIONARY):
    """sha256 of the mCODE extract this ruling was decided against.

    PINNED BECAUSE THE RULING IS ONLY TRUE OF ONE DICTIONARY. Every `basis` in the map cites a
    profile description, an element or a bound code; re-extract mCODE and any of those can move
    under it. Comparing the digest turns "this map is stale" from something a reader has to suspect
    into something `--check` states. `mcode_dictionary.py` proves the extract reproduces from the
    workbook; this proves the ruling was made against THAT extract.
    """
    try:
        with open(path, "rb") as fh:
            return hashlib.sha256(fh.read()).hexdigest()
    except OSError:
        return ""


def profiles(path=DICTIONARY):
    """{title: {"url", "description"}} for every profile the committed extract carries.

    THE EXTRACT, never the workbook. The workbook is licensed and deliberately outside the
    checkout (see mcode_dictionary's docstring); the extract is what the repository keeps and what
    every other consumer here reads, so a title that is valid for this map is a title the rest of
    the programme can also resolve.
    """
    try:
        with open(path, encoding="utf-8") as fh:
            doc = json.load(fh)
    except (OSError, ValueError):
        return {}
    return {str(p.get("title")): {"url": str(p.get("url") or ""),
                                  "description": str(p.get("description") or "")}
            for p in (doc.get("profiles") or []) if p.get("title")}


def codes_digest(path=CODES):
    """sha256 of the mCODE VALUE-SET EXPANSION this ruling was decided against.

    A SECOND PIN, BECAUSE THE DICTIONARY DIGEST DOES NOT COVER THE CODES. `DICTIONARY.json` holds
    value sets as title and description only; the 2,626 bound codes live in `VALUE_SET_CODES.json`.
    The rulings that most depend on the expansion are exactly the ones an adversarial pass had to
    CORRECT — GENE_REARRANGEMENT and GENOMIC_SIGNATURE were first filed as "mCODE does not type
    this" on the strength of a dictionary search that could not have found a code. Their bases now
    cite `81695-9`, `78205-2` and the rest by number.

    So pinning the dictionary alone would leave every code-citing ruling free to go stale in
    silence. `mcode_dictionary.py --check` has the same shape of gap one layer down: it
    byte-compares DICTIONARY.json and never VALUE_SET_CODES.json, so "current" is a claim about
    half the extract.
    """
    try:
        with open(path, "rb") as fh:
            return hashlib.sha256(fh.read()).hexdigest()
    except OSError:
        return ""


def load(path=MAP_PATH):
    """(doc, [problem]) — the ruling as written. Absent is empty, never an exception.

    Through `product_gates.read_yaml` like every other governed file here: a duplicate key or an
    impossible date is a GATE RESULT, not a traceback out of whatever happened to read it first.
    """
    from rwd_tools import product_gates as pg                                            # noqa: PLC0415
    if not os.path.exists(path):
        return {}, []
    doc, err = pg.read_yaml(path)
    if err:
        return {}, [f"{os.path.basename(path)}: {err}"]
    return doc or {}, []


def masters(path=INVENTORY):
    """[master name] — the concepts a domain is assigned to, in inventory order."""
    from rwd_tools import product_gates as pg                                            # noqa: PLC0415
    doc, err = pg.read_yaml(path)
    if err or not isinstance(doc, dict):
        return []
    return [str(m.get("name")) for m in (doc.get("master") or []) if m.get("name")]


_FAM_CACHE = {}


def family_variables(path=INVENTORY):
    """{master: {variable name}} — every tumour variable that hangs off each master.

    The membership a fan-out ruling has to cover. Read from the inventory rather than passed in,
    because the whole failure this guards is a caller supplying a list from memory.

    CACHED ON MTIME, like `semantic_binding._inventory()` and for the same reason: `map_errors`
    calls this on every invocation and the test suite calls `map_errors` dozens of times, so
    reparsing a 350 KB YAML each time took the suite from seconds to minutes. Keyed on mtime, so an
    edit during a long-lived process is still picked up.
    """
    try:
        stamp = os.path.getmtime(path)
    except OSError:
        return {}
    if _FAM_CACHE.get("stamp") == stamp and _FAM_CACHE.get("path") == path:
        return _FAM_CACHE["fam"]
    from rwd_tools import product_gates as pg                                            # noqa: PLC0415
    doc, err = pg.read_yaml(path)
    if err or not isinstance(doc, dict):
        return {}
    out = {}
    for _tumour, body in (doc.get("tumours") or {}).items():
        for v in ((body or {}).get("variables") or []):
            m, n = v.get("master"), v.get("name")
            if m and n:
                out.setdefault(str(m), set()).add(str(n))
    _FAM_CACHE.update({"stamp": stamp, "path": path, "fam": out})
    return out


def map_errors(doc=None, prof=None, known=None):
    """Problems with the ruling. [] is a pass, and `--check` exits on it.

    EVERY CLAIM IS CHECKED AGAINST THE EXTRACT rather than against itself. A map that validated
    only its own shape would pass on the day mCODE renamed a profile out from under it, which is
    the one moment this gate exists for.
    """
    doc = doc if doc is not None else load()[0]
    prof = prof if prof is not None else profiles()
    fam = family_variables()
    problems = []
    if not prof:
        return ["DICTIONARY.json carries no profiles — a title cannot be checked against anything"]

    entries = (doc or {}).get("masters")
    if not isinstance(entries, dict) or not entries:
        return [f"{os.path.basename(MAP_PATH)}: no `masters` mapping — the ruling is empty"]

    # WHAT THE RULING WAS DECIDED AGAINST, and who has stood behind it.
    status = str(doc.get("status") or "")
    if status not in STATUSES:
        problems.append(f"status {status!r} is not one of {STATUSES}")
    if status == "approved":
        # NOTHING MACHINE-WRITABLE MAY CLAIM THIS. An approved map without a named person and a
        # date is the one shape that would let a draft pass as reviewed.
        for field in ("approved_by", "approved_on"):
            v = str(doc.get(field) or "").strip()
            from rwd_tools import product_gates as _pg                                   # noqa: PLC0415
            if not v or _pg.unstated(v):
                problems.append(f"status is `approved` but {field} is {v or 'empty'!r} — an "
                                f"approval names a person and a date, or it is not one")
    for field, fn, fname in (("mcode_dictionary_sha256", dictionary_digest, "DICTIONARY.json"),
                             ("mcode_codes_sha256", codes_digest, "VALUE_SET_CODES.json")):
        pinned = str(doc.get(field) or "").strip()
        now = fn()
        if not pinned:
            problems.append(f"no `{field}` — the ruling does not say which {fname} it was "
                            f"decided against, so nothing can tell you it is stale")
        elif not now:
            # AN UNCOMPUTABLE DIGEST IS A FAILURE, NOT A SKIP. This read `elif now and ...`, so a
            # missing or unreadable extract made the comparison vanish and the gate passed — the
            # pin stopped being checked at exactly the moment it mattered most. A dependency this
            # ruling cannot read is a dependency it cannot claim to have been decided against.
            problems.append(f"{fname} cannot be read, so `{field}` cannot be checked — a pin "
                            f"nothing can verify is not a pin. Restore the extract or rebuild it")
        elif pinned != now:
            problems.append(f"{field} is {pinned[:12]}... and {fname} is now {now[:12]}... — "
                            f"the extract changed under this ruling. Re-review the map and repin")

    for name, rec in entries.items():
        if not isinstance(rec, dict):
            problems.append(f"{name}: not a mapping")
            continue
        problems.extend(_entry_errors(name, rec, prof))
        # PER-VARIABLE RULINGS, checked by the SAME rules as a master. A variable-level abstention
        # still has to say why and a partial still has to say what it misses, or the finer grain
        # would quietly be the looser gate.
        for var, vrec in (rec.get("variables") or {}).items():
            if not isinstance(vrec, dict):
                problems.append(f"{name}.{var}: not a mapping")
                continue
            problems.extend(_entry_errors(f"{name}.{var}", vrec, prof))
        # EVERY MEMBER, OR THE FAMILY IS NOT RULED. A fan-out master abstains at family level, so
        # any member it does not name has NO domain and nobody decided that — exactly the silence
        # the master-level completeness check already refuses, one grain down. This was missing,
        # and it let GENOMIC_SIGNATURE ship ruling 6 of its 9 members while `--check` said ok:
        # MSI, MSI_MMR_STATUS and TRIPLE_NEGATIVE_STATUS were never asked about, because the list
        # of members came from a person's memory instead of from the inventory. An external audit
        # found it; the gate did not.
        if rec.get("variables"):
            members = (fam or {}).get(name, set())
            ruled = {str(v) for v in (rec.get("variables") or {})}
            for missing in sorted(members - ruled):
                problems.append(f"{name}.{missing}: the inventory carries this variable in a "
                                f"fan-out family and the map does not rule on it — decide it, or "
                                f"abstain with a reason")
            for extra in sorted(ruled - members):
                problems.append(f"{name}.{extra}: ruled on, but no such variable hangs off this "
                                f"master in INVENTORY.yaml")
        if rec.get("variables") and rec.get("profile") not in (None, "", "null"):
            # TWO ANSWERS TO ONE QUESTION. A family that needs per-variable rulings is a family
            # with no single domain; keeping a master-level profile beside them means a consumer
            # reading only the master gets an answer its own members contradict.
            problems.append(f"{name}: rules per variable AND names a master-level profile "
                            f"{rec.get('profile')!r} — a family that splits has no single domain")

    # ...and the other direction: a master the map never mentions has no domain and nobody decided
    # that. Silence here would read as an abstention that was never actually made.
    known = known if known is not None else masters()
    for name in known:
        if name not in entries:
            problems.append(f"{name}: the inventory carries this master and the map does not rule "
                            f"on it — decide it, or abstain with a reason")
    for name in entries:
        if known and name not in known:
            problems.append(f"{name}: ruled on, but no such master in INVENTORY.yaml")
    return problems


def _entry_errors(tag, rec, prof):
    """The rules one ruling must satisfy, whether it is a master's or a variable's."""
    out = []
    title = rec.get("profile")
    conf = str(rec.get("confidence") or "")
    if conf not in CONFIDENCE:
        out.append(f"{tag}: confidence {conf!r} is not one of {CONFIDENCE}")
    if title in (None, "", "null"):
        # AN ABSTENTION MUST SAY WHY. Otherwise a considered "mCODE does not type this" and a row
        # nobody got to are the same two characters in the file.
        if not str(rec.get("why_none") or "").strip():
            out.append(f"{tag}: abstains with no `why_none` — an unexplained null is "
                       f"indistinguishable from an unfinished one")
        if conf != "none":
            out.append(f"{tag}: abstains but claims confidence {conf!r}")
    else:
        if str(title) not in prof:
            out.append(f"{tag}: {title!r} is not a profile in DICTIONARY.json — mCODE may have "
                       f"renamed it, or the title is mistyped. Re-rule this entry")
        if conf == "none":
            out.append(f"{tag}: names a profile but claims confidence 'none'")
        if conf == "partial" and not str(rec.get("caveat") or "").strip():
            out.append(f"{tag}: partial with no `caveat` — a reader cannot tell which part of "
                       f"the concept the profile does not cover")
    if not str(rec.get("basis") or "").strip():
        out.append(f"{tag}: no `basis` — a ruling with no stated reason cannot be reviewed")
    return out


def variable_domains(name, doc=None, prof=None):
    """{variable: ruling-or-None} where a family splits, else {}.

    WHY THIS GRAIN EXISTS, MEASURED. A master-level ruling is safe only when the family is one
    construct with different instances — 32 genes are all "gene variant status", 11 staging
    systems are all "cancer stage", and one profile is right for every member. Two masters are not
    like that, and an external review caught both:

      BIOMARKER_TEST_CONTEXT   PSMA_PET is nuclear-medicine IMAGING and mCODE STU4 has no imaging
                               profile at all (no PET, no radiology, no scan), while
                               NGS_PANEL_TESTING is Genomic Region Studied, PD_L1_TESTING_RESULT is
                               a tumour-marker IHC read, and MUTATION_TESTING_PERFORMED is a
                               Genomics Report. One domain on that family is a false domain on most
                               of its members.
      TUMOR_MARKER_VALUE       CA125 and PSA are tumour markers, CTDNA is a Genomic Variant, and
                               SERUM_EPO and TESTOSTERONE are routine chemistry that mCODE defers
                               to US Core entirely — so `exact` on the family was wrong twice over.

    So those families abstain and their members are ruled one at a time. A member ruled to nothing
    is `None` here: RULED, and ruled as "mCODE does not type it", which is not the same as absent.
    """
    doc = doc if doc is not None else load()[0]
    prof = prof if prof is not None else profiles()
    rec = ((doc or {}).get("masters") or {}).get(str(name))
    if not isinstance(rec, dict):
        return {}
    out = {}
    for var, vrec in (rec.get("variables") or {}).items():
        if not isinstance(vrec, dict):
            continue
        title = vrec.get("profile")
        if title in (None, "", "null") or str(title) not in prof:
            out[str(var)] = None
            continue
        out[str(var)] = {"profile": str(title), "url": prof[str(title)]["url"],
                         "confidence": str(vrec.get("confidence") or ""),
                         "caveat": str(vrec.get("caveat") or "")}
    return out


def fanout_masters(doc=None):
    """[master] whose members were ruled one at a time because the family has no single domain."""
    doc = doc if doc is not None else load()[0]
    return sorted(n for n, r in ((doc or {}).get("masters") or {}).items()
                  if isinstance(r, dict) and r.get("variables"))


def domain_for(name, doc=None, prof=None):
    """{"profile", "url", "confidence", "caveat"} for one master, or None where mCODE abstains.

    THE ONE LOOKUP. Every consumer goes through here so that "what is this concept's domain" has
    exactly one answer, and an unmapped master returns None rather than a plausible default — a
    default is how a concept acquires a domain nobody assigned it.
    """
    doc = doc if doc is not None else load()[0]
    prof = prof if prof is not None else profiles()
    rec = ((doc or {}).get("masters") or {}).get(str(name))
    if not isinstance(rec, dict):
        return None
    title = rec.get("profile")
    if title in (None, "", "null") or str(title) not in prof:
        return None
    return {"profile": str(title), "url": prof[str(title)]["url"],
            "confidence": str(rec.get("confidence") or ""),
            "caveat": str(rec.get("caveat") or "")}


def unmapped(doc=None, known=None):
    """[(master, why)] — where mCODE does not type this concept, with the reason recorded.

    Reported rather than filtered out: the set of things mCODE cannot describe is the honest
    boundary between an oncology FHIR profile and a real-world-evidence study design, and it is
    more useful to a reader than another row in the mapped table.
    """
    doc = doc if doc is not None else load()[0]
    entries = (doc or {}).get("masters") or {}
    out = []
    for name in (known if known is not None else masters()):
        rec = entries.get(name)
        if isinstance(rec, dict) and rec.get("profile") in (None, "", "null"):
            out.append((name, str(rec.get("why_none") or "")))
    return out


def report(doc=None):
    """The map as a person reads it: what is typed, how confidently, and what is not."""
    doc = doc if doc is not None else load()[0]
    prof, known = profiles(), masters()
    entries = (doc or {}).get("masters") or {}
    lines = []
    by_profile = {}
    for name in known:
        d = domain_for(name, doc, prof)
        if d:
            by_profile.setdefault(d["profile"], []).append((name, d["confidence"]))

    mapped_n = sum(len(v) for v in by_profile.values())
    lines.append(f"mCODE DOMAIN MAP — {mapped_n} of {len(known)} master(s) typed by "
                 f"{len(by_profile)} of {len(prof)} mCODE STU4 profile(s)")
    conf_n = {}
    for v in by_profile.values():
        for _n, c in v:
            conf_n[c] = conf_n.get(c, 0) + 1
    if conf_n:
        lines.append("  " + ", ".join(f"{conf_n[c]} {c}" for c in CONFIDENCE if c in conf_n))
    lines.append("")
    for title in sorted(by_profile):
        lines.append(f"  {title}")
        for name, conf in sorted(by_profile[title]):
            rec = entries.get(name) or {}
            note = f"  — {rec['caveat']}" if conf == "partial" and rec.get("caveat") else ""
            lines.append(f"      {name:<26} {conf}{note}")
    gaps = unmapped(doc, known)
    if gaps:
        lines.append("")
        lines.append(f"  NOT TYPED BY mCODE ({len(gaps)}) — a boundary, not a backlog:")
        for name, why in gaps:
            lines.append(f"      {name:<26} {why}")
    return "\n".join(lines)


def main(argv=None):
    from rwd_tools.console import use_utf8                                          # noqa: PLC0415
    use_utf8()
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("--check", action="store_true",
                    help="GATE: exit non-zero on a profile title mCODE no longer carries, an "
                         "abstention with no reason, or a master nobody ruled on")
    ap.add_argument("--unmapped", action="store_true",
                    help="only the masters mCODE does not type, and why")
    ap.add_argument("--format", choices=("text", "json"), default="text")
    a = ap.parse_args(argv)

    doc, probs = load()
    if probs:
        for p in probs:
            print(p)
        return 1

    if a.format == "json":
        prof, known = profiles(), masters()
        out = {"mapped": {n: domain_for(n, doc, prof) for n in known if domain_for(n, doc, prof)},
               "unmapped": {n: w for n, w in unmapped(doc, known)},
               "problems": map_errors(doc, prof, known)}
        print(json.dumps(out, indent=1, ensure_ascii=False))
        return 1 if (a.check and out["problems"]) else 0

    if a.unmapped:
        for name, why in unmapped(doc):
            print(f"{name:<26} {why}")
        return 0

    print(report(doc))
    errs = map_errors(doc)
    if errs:
        print("")
        print(f"REFUSED — {len(errs)} problem(s) with the ruling:")
        for e in errs:
            print(f"  {e}")
        return 1 if a.check else 0
    if a.check:
        print("")
        print("ok — every ruling names a profile this mCODE extract still carries")
    return 0


if __name__ == "__main__":
    sys.exit(main())
