"""Content bindings for explicit portal document-context classifications (stdlib only)."""
import hashlib
import json
import re

BOUND = re.compile(r"^Portal document metadata \[row-sha256:([a-f0-9]{64})\]\. Reason: (.*)$")
PREFIX = "Portal document metadata [row-sha256:"


def binding(row):
    fields = {key: row.get(key) for key in ("item_id", "variable_id", "definition", "notes", "tab", "row", "spec_fields")}
    return hashlib.sha256(json.dumps(fields, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


def stale_items(declared, rows):
    """Legacy dispositions retain their existing rules; new portal markers bind source text."""
    known = {row["item_id"]: row for row in rows}
    stale = {}
    for item, entry in declared.items():
        note = entry.get("note", "")
        if entry.get("disposition") != "context" or not note.startswith(PREFIX):
            continue
        match = BOUND.match(note)
        if not match or item not in known or match[1] != binding(known[item]):
            stale[item] = f"{item}: document metadata classification is stale; review the current source row and classify it again or restore it as a variable"
    return stale
