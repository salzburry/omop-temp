#!/usr/bin/env python3
"""The exploration lane — counts-only feasibility queries that RECORD every definition they assume.

    python3 platform/tools/quick_counts.py <pack> --frame <tsv> --by region1 \\
        --where "cohort=C2" --log-dir ~/rwdp-quick-counts
    python3 platform/tools/quick_counts.py <pack> --synthetic 60 --by cohort --log-dir ~/qc
    python3 platform/tools/quick_counts.py <pack> --intake ~/rwdp-quick-counts

WHY THIS EXISTS. Feasibility sizing ("is this cohort even big enough to bother") does not need
six gates — it needs a fast count. What it must NOT do is silently invent definitions: every
column a query touches either resolves against the cross-pack naming registry (the pack defined
it, or the engine emits it) or is an ASSUMPTION, and an assumption is demand evidence the
decision loop should see. So the lane runs on three rules, all fail-closed:

  1. COUNTS ONLY. The output is totals and group sizes — never a row, never an id. Groups below
     the small-cell floor are pooled and reported as suppressed, the same floor the profiler
     applies (a PLACEHOLDER for the approved organisational threshold — data_profiler.R:43).
  2. ASSUMPTIONS ARE LOGGED OR THE QUERY DOES NOT RUN. A query touching a name no contract and
     no engine stage carries must state what it means by it (--assume name="meaning") and carry
     a --log-dir OUTSIDE the checkout; the assumption lands in the intake ledger. Refusing to
     count is the design: an unlogged assumption is a silent definition, which is the failure
     this lane exists to prevent.
  3. NOTHING HERE IS EVIDENCE. Every output is stamped `lane: exploration`. `--intake`
     summarises the ledger — which names people keep assuming, how often, with what meanings —
     as DEMAND for the decision loop; a person phrases the question (answer-decisions owns that
     path) and this tool writes nothing under any pack's handoff/.

The frame the counts run over is wherever the data is allowed to be — this tool prints counts
and stores none of the frame. `--synthetic` builds a deterministic fake frame for the shape.
"""
import argparse
import json
import os
import re
import sys
from datetime import datetime, timezone

TOOLS = os.path.dirname(os.path.abspath(__file__))

from rwd_tools import naming_registry                                                      # noqa: E402
from rwd_tools import pack_run                                                             # noqa: E402
from rwd_tools.spec_extract import pack_path, repo_relative                           # noqa: E402

MIN_CELL = 11          # small-cell floor — keep in step with data_profiler.R `min_cell`

# WHAT MAY BE A DIMENSION (ninth review, P0). `--by` took any column and printed its values once a
# group reached the floor — twelve event rows for one person printed that person's identifier. A
# dimension is now an APPROVED CATEGORICAL VARIABLE OF THIS PACK: declared in the pack's contract
# with a categorical type, and not an identifier, quasi-identifier, date or free text by name —
# refused independently of cell size, and the refusal never echoes a value.
# the grain keys themselves (`ptid`, `patid`, `pid`) and every `<prefix>id`/key/hash spelling are
# identifiers (second review: `--where ptid=<id>` was a per-person membership oracle)
IDENTIFIER_RE = re.compile(r"(^|_)(pt|pat|p|enrol|enrolee|subj|pers|person|member|acct|account|rec|record|mrn|guid|uu)?"
                           r"(id|ids|uid|guid|key|hash|token|no|num|number|mrn|ssn|nhs|zip|zipcode|postcode|npi|name|"
                           r"address|phone|email|dob|dod)($|_)|patient|member|enrol|subject|person", re.I)
# the repository's own suffix grammar for dates (`xdt`, `xdd`, `xyr`, `deathdt`, `indexdd`) is a date too
DATE_RE = re.compile(r"(^|_)(date|dt|dd|yr|time|year|month|day)($|_)|(date|dt|dd|yr|dtm)$|^(dt|dd|yr)_", re.I)
CATEGORICAL_TYPES = {"string", "character", "factor", "categorical", "code", "flag", "logical", "boolean", "text"}
FREE_TEXT_RE = re.compile(r"note|comment|text|desc|remark|narrative", re.I)
GRAIN_KEYS = ("patientid", "patient_id", "ptid", "person_id", "patid", "enrolid")
# EVERY SHOWN COUNT IS ROUNDED (tenth review: two individually allowed queries recovered a suppressed
# cell by subtraction, 12 - 11 = 1). Rounding to a base bounds what differencing can recover to the
# base; the floor still decides what is shown at all, on the raw values.
ROUND_TO = 10          # the floor's own scale (second review: a base below the floor made 10 mean {11, 12})


def _rounded(n):
    return 0 if n == 0 else int(round(n / ROUND_TO) * ROUND_TO) or ROUND_TO


def _floored(n):
    """A count for the answer: rounded when it clears the floor, `<floor` otherwise; never exact."""
    return _rounded(n) if n >= MIN_CELL or n == 0 else f"<{MIN_CELL}"
GRAINS = ("patient", "event")


_ID_ALLOW = {"valid", "invalid", "paid", "unpaid", "void", "avoid", "solid", "liquid", "acid", "rapid", "grid", "fluid",
             "hybrid", "bid", "lipid", "thyroid", "opioid", "steroid", "eyelid", "mid", "amid", "aid", "said", "laid",
             "maid", "raid", "kid", "did", "hid", "lid", "rid", "skid", "squid", "vivid", "lucid", "timid", "humid",
             "morbid", "comorbid", "stupid", "carotid", "parotid", "orchid", "androidkey"}


def looks_like_identifier(col) -> bool:
    """Identifier by name: the regex, the tool's own grain keys, or any `...id`/`...key` spelling
    outside a short allowlist of ordinary words (second review: `ptid`, `patid`, `encounterid`,
    `claimid`, `siteid`, `hicn`, `beneid`, `provid` passed the boundary-only rule)."""
    c = str(col or "").strip().lower()
    if not c:
        return False
    if c in GRAIN_KEYS or IDENTIFIER_RE.search(c):
        return True
    if c in _ID_ALLOW:
        return False
    # quasi-identifier stems at a token start with NO trailing boundary (zipcode5, ssn4, hashcode,
    # rowhash, deviceserial, birthyear): the boundary rule above needs `_` or the end after the stem
    if re.search(r"(^|_)(zip|postal|postcode|ssn|fingerprint|birth)|serial|hash(code|key|id|val|_|$)", c):
        return True
    return bool(re.search(r"(id|ids|uid|key|keys|hicn|npi)$", c))


def approved_dimension(pack, col, registry=None):
    """(ok, why) — may `col` group a count for `pack`? Name rules first (they need no registry),
    then the pack's own contract: defined for THIS pack, with a categorical declared type."""
    c = str(col or "").strip().lower()
    if not c:
        return False, "no dimension named"
    if looks_like_identifier(c):
        return False, f"`{c}` is an identifier or quasi-identifier by name; identifiers never group a count"
    if DATE_RE.search(c):
        return False, f"`{c}` is a date; a date is not a dimension (bin it in the pack's contract first)"
    if FREE_TEXT_RE.search(c):
        return False, f"`{c}` looks like free text; free text is not a dimension"
    reg = naming_registry.registry() if registry is None else registry
    rec = reg.get(c)
    pack_rel = repo_relative(pack_path(pack))
    if rec is None or pack_rel not in (rec.get("packs") or {}):
        return False, (f"`{c}` is not defined for this pack ({pack_rel}) — a dimension is a variable of the "
                       f"pack's own contract, not a column that happens to be in the frame")
    declared = sorted(t for t, packs in (rec.get("types") or {}).items() if pack_rel in packs)
    if not declared:
        return False, f"`{c}` has no declared type in this pack's contract; only a categorical variable groups a count"
    if not set(declared) & CATEGORICAL_TYPES:
        return False, f"`{c}` is not categorical in this pack's contract (declared {', '.join(declared)})"
    return True, f"`{c}` is a {'/'.join(declared)} variable of {pack_rel}"


def filter_column_ok(col):
    """(ok, why) — may `col` FILTER a count? The name rules of a dimension apply (review of the
    ninth review: `--where patientid=...` selected one person and printed that person's cells);
    a filter column need not be a categorical variable, but it is never an identifier, a date or
    free text. The value is never part of the answer."""
    c = str(col or "").strip().lower()
    if looks_like_identifier(c):
        return False, f"`{c}` is an identifier or quasi-identifier by name; a filter on it selects a person"
    if DATE_RE.search(c):
        return False, f"`{c}` is a date; filter by a calendar window declared in the pack's contract instead"
    if FREE_TEXT_RE.search(c):
        return False, f"`{c}` looks like free text; free text neither filters nor groups a count"
    return True, ""


def shown_filters(pack, where):
    """The filters as the answer may state them: the value rides along only when the column is an
    approved categorical dimension of the pack; otherwise the value is withheld (a filter value on an
    unknown column can be anything, including an identifier)."""
    out = []
    for col, op, val in where:
        ok, _why = approved_dimension(pack, col)
        # a category label is short and carries no run of digits; anything else is withheld even on
        # an approved dimension (second review: an identifier typed as a dimension's value rode along)
        label_like = bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 _.+-]{0,30}", str(val))) and not re.search(r"\d{4,}", str(val))
        out.append(f"{col}{op}{val}" if ok and label_like else f"{col}{op}<value withheld>")
    return out


def resolve_for_pack(names, pack, registry=None):
    """{name: {"resolution": defined|other_pack|assumption, ...}} — `defined` means THIS pack's
    contract (or the engine) carries the name; a name another pack defines is `other_pack`, and a
    count over it would be a count against the wrong product (ninth review)."""
    reg = naming_registry.registry() if registry is None else registry
    pack_rel = repo_relative(pack_path(pack))
    out = {}
    for n in sorted({str(n).lower() for n in names}):
        rec = reg.get(n)
        if rec is not None and (pack_rel in (rec.get("packs") or {}) or rec.get("engine")):
            out[n] = {"resolution": "defined", "engine": bool(rec.get("engine")),
                      "packs": [pack_rel] if pack_rel in (rec.get("packs") or {}) else []}
        elif rec is not None:
            out[n] = {"resolution": "other_pack", "packs": sorted(rec.get("packs") or {}),
                      "note": f"`{n}` is defined by another pack, not by {pack_rel}; a count over it here is "
                              f"a count against the wrong product"}
        else:
            near = sorted(k for k in reg if naming_registry._near(n, k))
            out[n] = {"resolution": "assumption", "near": near,
                      "note": (f"no contract and no engine stage carries `{n}`"
                               + (f"; the registry carries {', '.join(near)} — is one of those the "
                                  f"standard spelling?" if near else ""))}
    return out


def frame_identity(path, rows_hint=None):
    """sha256 and row count of the frame file — the count's binding to WHAT was counted."""
    import hashlib  # noqa: PLC0415
    h = hashlib.sha256()
    n = -1
    with open(path, "rb") as fh:
        for line in fh:
            h.update(line)
            if line.strip():
                n += 1
    return h.hexdigest(), max(n, 0)


def grain_check(rows, grain, key):
    """(ok, why, distinct) — a claimed `patient` grain must be one row per id; `event` allows repeats.
    The ids are counted and never returned."""
    n, blank, ids = 0, 0, set()
    for r in rows:
        n += 1
        v = str(r.get(key, "")).strip()
        if v:
            ids.add(v)
        else:
            blank += 1
    # A ROW OF NOBODY IS NOT A ROW OF ANYONE (eleventh verdict): blank ids collapsed to one id "",
    # so one blank row passed patient grain as a distinct patient and a frame of blanks passed
    # event grain outright. Refused before the grain comparison, digit-free like every refusal here.
    if blank:
        return False, f"the frame has rows with no value under `{key}` — a row of nobody is not a row of anyone", len(ids)
    if grain == "patient" and len(ids) != n:
        return False, f"the frame is not one row per patient (more rows than distinct ids under `{key}`)", len(ids)
    return True, f"{grain} grain", len(ids)
LEDGER = "assumptions.jsonl"
BANNER = ("NON-EVIDENCE GRADE — exploration lane. Counts carry no approved definition unless "
          "the name resolves to the registry; nothing here is a verdict, and nothing here "
          "reaches a gate.")


def parse_where(clauses):
    """[(column, op, value)] from "col=value" / "col!=value" — anything else is refused, because
    a clause this lane cannot parse is a definition it would otherwise silently drop."""
    out = []
    for c in clauses or []:
        m = re.fullmatch(r"\s*([A-Za-z_][A-Za-z0-9_]*)\s*(!?=)\s*(.*?)\s*", c)
        if not m:
            # the clause is not echoed: whatever it held could be a value (second review)
            sys.exit("cannot parse a --where clause — the lane takes `col=value` or `col!=value`; "
                     "anything richer is a definition that belongs in a pack, not a flag")
        out.append((m.group(1).lower(), m.group(2), m.group(3)))
    return out


def resolve(names, registry=None):
    """{name: {"resolution": defined|assumption, ...}} — every touched column against the
    cross-pack registry. A near-miss on a registered name is NAMED in the result so the
    recommendation ("the standard spelling already exists") rides with the count."""
    reg = naming_registry.registry() if registry is None else registry
    out = {}
    for n in sorted({n.lower() for n in names}):
        rec = reg.get(n)
        if rec is not None:
            out[n] = {"resolution": "defined", "engine": rec["engine"],
                      "packs": sorted(rec["packs"])}
            continue
        near = sorted(k for k in reg if naming_registry._near(n, k))
        out[n] = {"resolution": "assumption",
                  "near": near,
                  "note": (f"no contract and no engine stage carries `{n}`"
                           + (f"; the registry carries {', '.join(near)} — is one of those the "
                              f"standard spelling?" if near else ""))}
    return out


def counts(rows, by=None, where=(), key=None):
    """total + per-group sizes over an iterable of dict rows, small cells pooled. Pure: the
    caller owns where the rows came from; this function never sees more than it counts.
    THE FLOOR COUNTS PEOPLE WHEN IT CAN (review of the ninth review): at event grain twelve rows
    of one person reached the row floor and printed that person's cell; with `key` (the grain
    key column) a cell must also cover MIN_CELL distinct ids to be shown."""
    total = 0
    total_ids = set()
    groups = {}
    group_ids = {}
    for r in rows:
        keep = True
        for col, op, val in where:
            have = str(r.get(col, "")).strip()
            keep = (have == val) if op == "=" else (have != val)
            if not keep:
                break
        if not keep:
            continue
        total += 1
        if key:
            total_ids.add(str(r.get(key, "")).strip())
        if by:
            g = str(r.get(by, "")).strip() or "(empty)"
            groups[g] = groups.get(g, 0) + 1
            if key:
                group_ids.setdefault(g, set()).add(str(r.get(key, "")).strip())

    def _wide(g, v):
        return v >= MIN_CELL and (not key or len(group_ids.get(g, ())) >= MIN_CELL)
    shown = {k: v for k, v in groups.items() if _wide(k, v)}
    supp = {k: v for k, v in groups.items() if not _wide(k, v)}
    people_ok = (not key) or len(total_ids) >= MIN_CELL or total == 0
    # COMPLEMENTARY SUPPRESSION. With exactly one group under the floor, the exact total minus
    # the exact shown groups recovers the hidden cell by subtraction — the floor protects
    # nothing. So a lone suppressed cell drags the SMALLEST shown group into the pool with it:
    # subtraction then yields only the pooled pair's sum, never an individual cell.
    if len(supp) == 1 and shown:
        k = min(shown, key=lambda g: (shown[g], g))
        supp[k] = shown.pop(k)
    pooled = sum(supp.values())
    out = {"total": _rounded(total) if (total >= MIN_CELL and people_ok) or total == 0 else f"<{MIN_CELL}",
           "rounding": f"every shown count is rounded to the nearest {ROUND_TO}; the small-cell floor ({MIN_CELL}) "
                       f"is applied to the exact values first"}
    if by:
        out["by"] = {"column": by, "groups": {k: _rounded(v) for k, v in sorted(shown.items())},
                     "suppressed_values": len(supp),
                     "suppressed_rows": _rounded(pooled) if pooled >= MIN_CELL or pooled == 0
                     else f"<{MIN_CELL}"}
    return out


def read_frame(path):
    with open(path, encoding="utf-8") as fh:
        hdr = [h.strip().lower() for h in fh.readline().rstrip("\n").split("\t")]
        # THE HEADER MEANS WHAT IT SAYS OR NOTHING IS COUNTED (eleventh verdict): dict(zip()) kept
        # the LAST of two columns under one name and re-labelled a shifted row's cells silently
        if "" in hdr or len(set(hdr)) != len(hdr):
            sys.exit("REFUSED — the frame's header repeats a column name or leaves one unnamed; a count "
                     "over a column that may mean two things is a count of nothing in particular")
        for i, line in enumerate(fh, start=2):
            if not line.strip():                   # a blank line is not a row of anything
                continue
            cells = line.rstrip("\n").split("\t")
            if len(cells) != len(hdr):             # the cells are not echoed: any of them could be a value
                sys.exit(f"REFUSED — ragged row at line {i}: {len(cells)} cell(s) against {len(hdr)} header "
                         f"column(s); a shifted or missing cell counts the wrong column")
            yield dict(zip(hdr, cells))


def parse_steps(specs):
    """[(label, [(col, op, value)])] from repeated --step "label: col=value" (or a bare clause).

    A step is a criterion of the attrition table — one row of it — and it takes exactly the grammar
    a filter takes: `col=value` / `col!=value`, several joined with `&`. Anything richer (a window,
    a look-back, a count of visits) is a DEFINITION and belongs in a pack, so it is refused here
    with the same words as an unparseable filter — never silently skipped.
    """
    out = []
    for i, s in enumerate(specs or [], start=1):
        label, _, body = s.partition(":") if ":" in s and "=" not in s.split(":", 1)[0] else ("", "", s)
        clauses = [c for c in body.split("&") if c.strip()]
        if not clauses:
            sys.exit(f"--step {i}: names no criterion — the form is \"label: col=value\"")
        out.append((label.strip() or f"step {i}", parse_where(clauses)))
    return out


def attrition(rows, steps, key=None):
    """[{step, remaining, dropped}] — criteria applied IN ORDER, each row of the table counting what
    is left (people when the frame has a grain key, rows otherwise) under the same floor and
    rounding as every count here, and what the step dropped, floored the same way. Nothing else:
    no id, no value, no per-group cell (eleventh verdict: criterion-level attrition was the one
    feasibility artifact the lane did not produce)."""
    def _n(rs):
        return len({str(r.get(key, "")).strip() for r in rs}) if key else len(rs)
    kept = list(rows)
    out = [{"step": "frame", "remaining": _floored(_n(kept)), "dropped": 0}]
    for label, where in steps:
        before = _n(kept)
        nxt = []
        for r in kept:
            keep = True
            for col, op, val in where:
                have = str(r.get(col, "")).strip()
                keep = (have == val) if op == "=" else (have != val)
                if not keep:
                    break
            if keep:
                nxt.append(r)
        kept = nxt
        after = _n(kept)
        out.append({"step": label, "remaining": _floored(after), "dropped": _floored(before - after)})
    return out


def synthetic(n, columns):
    """A deterministic fake frame — three cycling values per named column, for the SHAPE only."""
    for i in range(n):
        yield {c: f"v{(i + j) % 3 + 1}" for j, c in enumerate(sorted(columns))}


def check_ledger(log_dir, resolved, meanings, asked_by=""):
    """Refuse, before any frame is read, a query whose assumptions could not be logged — and
    return the names that would be. The WRITE happens in `log_assumptions` once the count ran:
    a refused request is not demand evidence (eleventh verdict: three refused runs each counted
    as a session of demand for `site`)."""
    assumed = [n for n, r in resolved.items() if r["resolution"] == "assumption"]
    if not assumed:
        return []
    if asked_by:
        from rwd_tools import product_gates as pg                     # noqa: PLC0415
        why = pg.not_a_person(asked_by)
        if why:
            sys.exit(f"--asked-by {asked_by!r}: {why}. Demand is attributed to a person, "
                     f"not a team — the pilot's askers are named.")
    if not log_dir:
        sys.exit("ASSUMPTIONS UNLOGGED — this query touches "
                 + ", ".join(f"`{n}`" for n in assumed)
                 + ", which no contract and no engine stage defines. Pass --log-dir (outside "
                   "the checkout) so the assumed definitions land in the intake ledger, and "
                   "--assume name=\"what you mean by it\" for each. The exploration lane "
                   "records what it had to assume, or it does not run.")
    missing = [n for n in assumed if n not in meanings]
    if missing:
        sys.exit("UNSTATED ASSUMPTION — say what you mean: "
                 + " ".join(f'--assume {n}="…"' for n in missing))
    pack_run.restricted_dir(log_dir, what="the assumption intake ledger")   # refused inside the checkout
    return assumed


def log_assumptions(log_dir, pack, resolved, meanings, asked, asked_by=""):
    """Append the assumed definitions to the intake ledger, outside the checkout. Assumptions
    with no stated meaning are refused: "I assumed something" is not demand evidence — and in
    the participation pilot, neither is an anonymous one: --asked-by names WHO needs the
    definition, so the docket can weigh demand by asker, and a team name is refused the same
    way it is refused everywhere else in this repository."""
    assumed = check_ledger(log_dir, resolved, meanings, asked_by)
    if not assumed:
        return 0
    root = pack_run.restricted_dir(log_dir, what="the assumption intake ledger")
    os.makedirs(root, exist_ok=True)
    with open(os.path.join(root, LEDGER), "a", encoding="utf-8", newline="\n") as fh:
        for n in assumed:
            fh.write(json.dumps({"name": n, "meaning": meanings[n],
                                 "pack": repo_relative(pack_path(pack)), "asked": asked,
                                 "asked_by": asked_by,
                                 "near": resolved[n].get("near", []),
                                 "at": datetime.now(timezone.utc).isoformat(timespec="seconds")},
                                sort_keys=True) + "\n")
    return len(assumed)


def intake(log_dir):
    """The demand summary: which names sessions keep assuming, how often, with what meanings.
    A report a person routes into the decision loop — this tool never phrases the question."""
    path = os.path.join(os.path.realpath(os.path.expanduser(log_dir)), LEDGER)
    if not os.path.exists(path):
        return {"ledger": path, "entries": 0, "names": {}}
    by_name = {}
    n = 0
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            e = json.loads(line)
            n += 1
            d = by_name.setdefault(e["name"], {"sessions": 0, "meanings": [], "packs": set(),
                                               "near": set(), "askers": set()})
            d["sessions"] += 1
            if e["meaning"] not in d["meanings"]:
                d["meanings"].append(e["meaning"])
            d["packs"].add(e["pack"])
            d["near"].update(e.get("near", []))
            d["askers"].add(e.get("asked_by") or "(unattributed)")
    for d in by_name.values():
        d["packs"] = sorted(d["packs"])
        d["near"] = sorted(d["near"])
        d["askers"] = sorted(d["askers"])
    return {"ledger": path, "entries": n,
            "names": dict(sorted(by_name.items(), key=lambda kv: -kv[1]["sessions"])),
            "note": "route the recurring names into the decision loop (answer-decisions owns "
                    "the path) — a name assumed twice with two meanings is the naming failure "
                    "arriving on schedule"}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack", nargs="?")
    ap.add_argument("--frame", help="TSV to count over (wherever the data is allowed to live)")
    ap.add_argument("--synthetic", type=int, help="deterministic fake frame of N rows instead")
    ap.add_argument("--by", help="group the count by this column — an approved categorical variable of the pack")
    ap.add_argument("--cut", help="the data cut the frame comes from (required with --frame), e.g. 2023Q4")
    ap.add_argument("--grain", choices=list(GRAINS), help="what one frame row is (required with --frame)")
    ap.add_argument("--where", action="append", help="col=value / col!=value (repeatable)")
    ap.add_argument("--step", action="append", metavar='"LABEL: col=value[&col!=value]"',
                    help="a criterion of the attrition table, applied in order after --where "
                         "(repeatable); the answer gains an `attrition` list of remaining/dropped per step")
    ap.add_argument("--assume", action="append", default=[],
                    help='name="meaning" for every column the registry does not carry')
    ap.add_argument("--log-dir", help="intake ledger dir, outside the checkout")
    ap.add_argument("--asked-by", default="",
                    help="who is asking (a person's name, never a team) — attributed on every "
                         "logged assumption so the docket can weigh demand by asker")
    ap.add_argument("--intake", metavar="LOG_DIR",
                    help="summarise the assumption ledger instead of counting")
    a = ap.parse_args(argv)

    if a.intake:
        print(json.dumps(intake(a.intake), indent=2))
        return 0
    if not a.pack:
        sys.exit("a pack is required — resolution runs against its registry entries")
    # THE PACK EXISTS, OR NOTHING IS COUNTED (ninth review: a nonexistent pack with synthetic counts
    # exited 0 — a plausible number against no product)
    from rwd_tools import product_gates as pg                                     # noqa: PLC0415
    pack_rel = repo_relative(pack_path(a.pack))      # checkout-relative, whatever the cwd
    if pack_rel not in set(pg.all_packs(pg.repo_root())):
        sys.exit(f"{pack_rel!r} is not a registered pack — counts bind to a product that exists")
    if bool(a.frame) == bool(a.synthetic):
        sys.exit("exactly one of --frame / --synthetic says what to count")
    if a.synthetic is not None and a.synthetic < MIN_CELL:
        sys.exit(f"--synthetic needs at least {MIN_CELL} rows (the small-cell floor); {a.synthetic} is not a frame")
    if a.frame and (not a.cut or not a.grain):
        sys.exit("a real frame needs its identity: --cut names the data cut (e.g. 2023Q4) and --grain says "
                 "what one row is (patient | event) — a count with neither is a number about nothing")
    if a.grain and a.grain not in GRAINS:
        sys.exit(f"--grain must be one of {GRAINS}")

    where = parse_where(a.where)
    steps = parse_steps(a.step)
    touched = [c for c, _o, _v in where] + [c for _l, ws in steps for c, _o, _v in ws] \
        + ([a.by.lower()] if a.by else [])
    if not touched:
        sys.exit("nothing to resolve — name at least one column via --by or --where")
    if a.by:
        ok, why = approved_dimension(pack_rel, a.by)
        if not ok:
            sys.exit(f"REFUSED dimension — {why}")
    for col, _op, _val in where + [w for _l, ws in steps for w in ws]:
        ok, why = filter_column_ok(col)
        if not ok:
            sys.exit(f"REFUSED filter — {why}")                # the value is never echoed
    meanings = {}
    for s in a.assume:
        m = re.fullmatch(r'\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*"?(.+?)"?\s*', s)
        if not m:
            sys.exit(f'cannot parse --assume {s!r} — the form is name="meaning"')
        meanings[m.group(1).lower()] = m.group(2)
    resolved = resolve_for_pack(touched, pack_rel)
    wrong = [n for n, r in resolved.items() if r["resolution"] == "other_pack"]
    if wrong:
        sys.exit("REFUSED — " + "; ".join(resolved[n]["note"] for n in wrong))
    asked = {"by": a.by, "where": shown_filters(pack_rel, where),     # values only on approved dimensions
             "steps": [{"step": lbl, "where": shown_filters(pack_rel, ws)} for lbl, ws in steps]}
    # THE LEDGER'S PRECONDITIONS ARE CHECKED HERE; THE LINE IS WRITTEN ONLY ONCE THE COUNT RAN
    # (eleventh verdict: three refused requests each counted as demand for `site`)
    check_ledger(a.log_dir, resolved, meanings, a.asked_by)

    _entry = pg.registry_entry(pg.repo_root(), pack_rel) or {}
    identity = {"pack": pack_rel, "spec_version": pack_rel.rsplit("/", 1)[-1],
                "registry_status": str(_entry.get("status") or "?"),
                "pack_role": str(_entry.get("role") or "product"),      # a fixture's count is exercise, never evidence
                "asked_by": a.asked_by or None,
                "cut": a.cut, "grain": a.grain or ("synthetic" if a.synthetic else None),
                "dimension": (a.by.lower() if a.by else None), "filters": asked["where"]}
    if a.synthetic:
        rows = list(synthetic(a.synthetic, touched))
        identity.update({"frame_sha256": None, "frame_rows": _floored(len(rows))})
    else:
        # THE FRAME IS PATIENT-LEVEL DATA OF THIS PACK, OR IT IS NOT COUNTED: a grain key column
        # must exist (a profile or metadata TSV has none), and the frame's identity rides along
        if not os.path.isfile(a.frame):
            sys.exit("REFUSED — --frame does not name a readable file")   # the path is not echoed
        with open(a.frame, encoding="utf-8") as fh:
            hdr = [h.strip().lower() for h in fh.readline().rstrip("\n").split("\t")]
        key = next((k for k in GRAIN_KEYS if k in hdr), None)
        # A COLUMN ABSENT FROM THE FRAME IS REFUSED, NOT COUNTED AS EMPTY (review of the ninth
        # review: a filter or dimension that never applied still appeared in the identity)
        absent = [c for c in touched if c not in hdr]
        if absent:
            sys.exit(f"REFUSED — column(s) not in the frame: {', '.join(absent)}; the frame's columns are the "
                     f"only ones a count can use")
        if key is None:
            unknown = [h for h in hdr if resolve_for_pack([h], pack_rel)[h]["resolution"] != "defined"]
            sys.exit(f"REFUSED — the frame has no patient identifier column ({', '.join(GRAIN_KEYS)}) and "
                     f"these headers are not this pack's variables: {', '.join(unknown[:12])}. Is this "
                     f"patient-level analytic data of {pack_rel}?")
        rows = list(read_frame(a.frame))
        ok, why, distinct = grain_check(rows, a.grain, key)
        if not ok:
            sys.exit(f"REFUSED — {why}")
        digest, nrows = frame_identity(a.frame)
        identity.update({"frame_sha256": digest, "frame_rows": _floored(nrows), "grain_key": key,
                         "distinct_patients": _floored(distinct),
                         "unregistered_columns": [h for h in hdr if h != key
                                                  and resolve_for_pack([h], pack_rel)[h]["resolution"] != "defined"]})
    logged = log_assumptions(a.log_dir, a.pack, resolved, meanings, asked, a.asked_by)
    result = {"lane": "exploration", "banner": BANNER, "pack": pack_rel, "identity": identity,
              "asked": asked, "resolution": resolved,
              "assumptions_logged": logged,
              "counts": counts(rows, by=(a.by.lower() if a.by else None), where=where,
                               key=(None if a.synthetic else key))}
    if steps:
        # the table starts from the --where'd frame: the steps are what a person would apply next
        base = [r for r in rows if all(((str(r.get(c, "")).strip() == v) if o == "=" else
                                        (str(r.get(c, "")).strip() != v)) for c, o, v in where)]
        result["attrition"] = attrition(base, steps, key=(None if a.synthetic else key))
    if a.synthetic:
        result["frame"] = f"SYNTHETIC ({a.synthetic} deterministic rows) — the shape, not facts"
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
