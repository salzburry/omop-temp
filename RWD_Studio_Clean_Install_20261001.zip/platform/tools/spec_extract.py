#!/usr/bin/env python3
"""Extract an Science program specification into structured, traceable rows.

This is the deterministic capture step of the governed workflow (governance/WORKFLOW.md, Gate 2).
It reads the approved specification and emits one record per spec row, carrying the ORIGINAL Excel
coordinates so every downstream claim can be walked back to the source.

Three readers, one output shape:

  * .xlsx        the production path — reads the approved workbook directly with openpyxl
  * .tsv, or <spec dir>/*.tsv    tab-separated tabs, one file per sheet. What a sponsor sends when
                 the specification is maintained somewhere other than Excel, or exported from it
                 without the workbook itself changing hands. Needs no third-party library, diffs in
                 review, and carries true row numbers like the workbook does.
  * <spec dir>/*.md      the per-tab path — reads per-tab markdown files,
                 which is what exists when the workbook itself cannot be brought into the repo

A DIRECTORY may hold `.tsv` or `.md`, not both. Two spellings of the same tab is the drift this
pipeline exists to prevent, and which one won would depend on `sorted()`.

The extractor does not rewrite scientific cell contents. It resolves column-role synonyms and
explicit product-local header/column choices, retaining the original coordinates and values,
because every semantic transformation is an opportunity to silently corrupt a requirement — a real
incident in this repo replaced the state code 'DE' with the word 'Implementation' via an unanchored
find/replace. Cell TEXT comes out as it went in, typos included.

It is not literally byte-verbatim, and the difference matters when qualifying it for a new workbook:

  * cells are read as `str(value).strip()`, so leading/trailing whitespace is dropped and a typed date
    or number becomes Python's string form of it
  * the workbook is opened `data_only=True`, so a formula cell yields its CACHED result — and yields
    blank if the file was never opened by Excel after the formula was written. A blank cache is
    REPORTED (`workbook_structure.formula_no_value`); a STALE one cannot be. Excel stores `<f>` and
    `<v>` side by side and this reads the `<v>` without consulting the `<f>`, so a formula edited
    and never recalculated publishes the OLD number as the specification's value — `=90*3` with a
    cached `180` extracts as `180`, and nothing in the file distinguishes that from a correct
    cache. Telling them apart means EVALUATING the formula, which an extractor that performs no
    transformation must not start doing. It is a limit, not a bug, and the only defence is a person
    recalculating the workbook before it is registered.
    `test_adversarial_extraction.py` holds a worked counter-example.
  * the header is the first row with at least two recognized short column labels, falling back to
    the first row with three populated cells for unknown layouts. A confirmed product-local header
    row overrides detection; unknown layouts remain a human structure decision.
  * comments, merged spans, hidden rows/columns and formatting-as-meaning are not READ — but
    they are REPORTED per sheet in `extraction.workbook_structure`, because a cell that is blank for a
    structural reason is indistinguishable from one the spec left blank

These are the qualification boundary: unknown layouts require an explicit structure choice rather
than an inferred scientific interpretation.

Each row carries a content hash and an item id of the form `<citation-domain>:<row>`.
For one sheet per domain this is the existing `<domain>:<row>` form. Multiple sheets
sharing a domain use `<domain>.s<sheet-key-hash>:<row>`; the logical `domain`, original
worksheet label and Excel row number remain separate, unchanged source fields.

That id is a SOURCE COORDINATE, not a stable cross-revision identifier. It is what lets a reader open
the approved workbook and land on the exact line, and it is stable for as long as the workbook is. It
is NOT stable across spec revisions: if Science inserts a row, every later coordinate shifts. The content
hash survives row movement but cannot substitute — identical text legitimately recurs on a sheet, and
the hash changes if the sheet is renamed. Matching items across revisions needs domain + variable name
+ content hash + old and new coordinates together, with ambiguous matches reviewed by a person.
`spec_diff.carry` implements exactly that recipe: an intact hash at a new coordinate is NEW_REF, a
changed row with a unique same-name row is RE-DRAFT with a named successor to re-read, and anything
ambiguous is a person's choice. Do not read `<domain>:<row>` itself as a matcher.

    python3 platform/tools/spec_extract.py <product-dir> [--out FILE]
    python3 platform/tools/spec_extract.py <workbook.xlsx> [--out FILE]

stdlib + PyYAML; openpyxl only for the .xlsx path.
"""
import argparse
import hashlib
import json
import os
import re
import sys
from rwd_services import finding, WorkflowRefusal, workflow_main, record_workflow_issues

EXTRACTOR_VERSION = "1.8"      # 1.8 product-local column maps, header synonyms and cell provenance.
                               # 1.7 the mid-sheet header switch ALSO fires on canonical-field
                               #     density (three or more short label cells resolving via
                               #     column_key), so a second table whose header does NOT repeat
                               #     the current header's first cell reads under its OWN columns.
                               #     Found live on the first real mCRC run: 3.DataPrep holds three
                               #     sections with three different first cells (`Data source`,
                               #     `Study Time Period`, `#`), Section A's header claimed every
                               #     row beneath, no Definition column resolved, and all nine
                               #     study-period records scaffolded as required_rule TODO while
                               #     the rule text sat in the workbook;
                               # 1.6 header_candidates in workbook_structure (density-detected
                               #     mid-sheet second-table headers, short-label cells only);
                               # 1.1 workbook_structure; 1.2 content_hash covers the field map;
                               # 1.5 sheet_key_collisions + fatal on a domain-resolving collision;
                               # 1.3 mid-file header switch (a tab may hold two tables) + the
                               #     per-source shape report (skipped lines, row gaps, cell counts);
                               # 1.4 the xlsx reader learned the SAME header switch (it had only ever
                               #     been in the markdown reader, so a second table on a real
                               #     worksheet was read under the first table's columns), plus
                               #     sheet_state, expected_sheets_empty, display_differs and the
                               #     positional-fallback coordinates.
                               #
                               # BUMP THIS WHENEVER EXTRACTION OUTPUT CAN CHANGE. It is carried into
                               # `extraction_fingerprint`, which a registered ai_extraction records;
                               # leaving it still while behaviour moves lets an approval given over
                               # one extractor's output silently describe another's. An external
                               # review caught exactly that on this branch: 1.3 shipped a changed
                               # xlsx reader, and OC's committed extraction lost 7 phantom rows and
                               # re-headed 20 more under a version that claimed to be the old one.

# `# Data Prep (3.Data Prep)` -> tab label `3.Data Prep`. The label lives in the file, never in this
# script: tab names differ per product (prostate `5A. Demos`, ovarian `5.Demographics`) and hardcoding
# one product's labels produces citations that resolve nowhere for every other product.
TAB_IN_HEADER = re.compile(r"^#\s+.*?\(([^)]+)\)\s*$")

# Canonical column names, resolved from the tab's own header row.
#
# Columns are named, not positional: Science puts them in a different order on every tab (`3.Data Prep`
# has no Time Period column, `4.StudyPop` has both Section and Time Period ahead of Variable) and
# labels the same content differently across products. Reading by position is what broke before —
# the earlier positional guess read the `Time Period` cell as the variable name on 192 of 200
# prostate rows, and downstream picked `Label` where it wanted `Definition` on 148 of 200.
#
# Unrecognised columns (QC initials, Date Modified, Origin, Evidence) resolve to nothing and are simply
# not surfaced; they remain in `cells`/`text`, so nothing is lost.
#
# Matching is by KEYWORD, tried in this order, because an exact synonym list would need extending for
# every product: prostate writes `Definition` and `Values`, ovarian writes `Definition / EDM derivation`
# and `Values / codes`. Order carries the precedence — `Variable Label` is a label, not a variable, and
# `Code Lists Group` is a codelist pointer, not a value set — so keep the specific rules above the
# general ones.
COLUMN_RULES = [
    ("code list", "codelist_group"), ("codelist", "codelist_group"), ("code group", "codelist_group"),
    ("label", "label"),
    ("variable", "variable"),
    ("definition", "definition"), ("derivation", "definition"), ("description", "definition"),
    ("note", "notes"),
    ("time period", "time_period"), ("timepoint", "time_period"), ("time point", "time_period"),
    ("value", "values"), ("code", "values"),
    ("section", "section"),
    ("source", "source"),
]

# Exact synonyms are intentionally conservative. These identify a column's role,
# never infer a scientific rule or replace a workbook's own values.
COLUMN_ALIASES = {
    "item": "variable", "variable name": "variable", "identifier": "variable",
    "variable id": "variable", "field name": "variable", "name": "variable",
    "rule": "definition", "logic": "definition", "formula": "definition",
    "window": "time_period", "eligible window": "time_period", "baseline window": "time_period",
    "allowed values": "values", "response options": "values", "categories": "values",
    "data origin": "source", "origin table": "source",
}
CANONICAL_COLUMNS = tuple(dict.fromkeys([key for _, key in COLUMN_RULES]))


def parse_column_map(value):
    """Validate product-local COLUMN_MAP JSON; return exact sheet labels and Excel letters.

    Shape: {sheet: {header_row: 3, columns: {variable: "B", definition: "D"}}}.
    header_row is optional. When columns are supplied they are authoritative;
    omitted fields remain unassigned. A header-only choice retains synonyms.
    No cell contents are edited.
    """
    if value in (None, ""):
        return {}
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except (ValueError, TypeError) as error:
            raise ValueError("COLUMN_MAP must contain a JSON object of worksheet column choices.") from error
    if not isinstance(value, dict) or len(value) > 100:
        raise ValueError("COLUMN_MAP must map up to 100 worksheet names to their column choices.")
    out, keys = {}, set()
    for sheet, choice in value.items():
        if not isinstance(sheet, str) or not sheet.strip() or len(sheet) > 31 or any(ord(c) < 32 for c in sheet):
            raise ValueError("Column mappings must name an exact worksheet in the workbook.")
        if sheet_key(sheet) in keys:
            raise ValueError("Column mappings repeat an equivalent worksheet name.")
        keys.add(sheet_key(sheet))
        if not isinstance(choice, dict) or set(choice) - {"header_row", "columns"}:
            raise ValueError("A worksheet column mapping contains an unsupported setting.")
        header = choice.get("header_row")
        if header is not None and (isinstance(header, bool) or not isinstance(header, int) or not 1 <= header <= 1048576):
            raise ValueError("Choose a valid Excel row number for the column headers.")
        columns = choice.get("columns", {})
        if not isinstance(columns, dict) or any(key not in CANONICAL_COLUMNS for key in columns):
            raise ValueError("Choose a supported specification field for every mapped column.")
        if "columns" in choice and "variable" not in columns:
            raise ValueError("Choose the Variable column when confirming a worksheet's field mapping.")
        normalized = {}
        for field, column in columns.items():
            if isinstance(column, int) and not isinstance(column, bool) and 1 <= column <= 16384:
                column = _column_letter(column)
            if not isinstance(column, str) or not re.fullmatch(r"[A-Za-z]{1,3}", column) or _column_number(column) > 16384:
                raise ValueError("Choose an Excel column letter from A through XFD.")
            normalized[field] = column.upper()
        if len(set(normalized.values())) != len(normalized):
            raise ValueError("Each source column can map to only one specification field.")
        if not normalized and header is None:
            raise ValueError("Choose at least a header row or one specification column.")
        out[sheet] = {**({"header_row": header} if header is not None else {}),
                      **({"columns": normalized} if "columns" in choice else {})}
    return out


def _column_letter(number):
    result = ""
    while number:
        number, remainder = divmod(number - 1, 26)
        result = chr(65 + remainder) + result
    return result


def _column_number(letter):
    number = 0
    for char in letter.upper():
        number = number * 26 + ord(char) - 64
    return number


def coordinate_free_key(row):
    """Exact content/field identity independent of worksheet label and row coordinate.

    Only a numeric first cell explicitly headed Row is removed. A '#' or an Item
    column is content. Field assignments remain part of the key so remapping an
    unchanged cell into a different meaning never counts as an unchanged rule.
    """
    header, cells = list(row.get("header") or []), list(row.get("cells") or [])
    if not header or not cells or row.get("vendor_redacted"):
        return None
    fields = dict(row.get("fields") or {})
    expected_hash = _hash(row.get("tab") or "", " | ".join(cells),
                          ";".join(f"{key}={fields[key]}" for key in sorted(fields)))
    if row.get("content_hash") != expected_hash:
        # A stale/tampered row cannot use a derived key to override its digest.
        return None
    if "variable" not in fields and not row.get("column_overrides"):
        # Older captures knew Item by positional fallback. Recognizing the same
        # exact source cell as Variable now is structure normalization only.
        source = next((cells[i] for i, label in enumerate(header)
                       if column_key(label) == "variable" and i < len(cells)), None)
        if source is not None and source == row.get("variable"):
            fields["variable"] = source
    if str(header[0]).strip().lower() == "row" and str(cells[0]).strip().isdigit():
        header, cells = header[1:], cells[1:]
    return json.dumps([header, cells, fields], ensure_ascii=False, sort_keys=True)


def _hash(*parts):
    return hashlib.sha256("\x1f".join(p or "" for p in parts).encode("utf-8")).hexdigest()[:12]


def _norm(s):
    return re.sub(r"\s+", " ", (s or "").strip().lower())


def row_variable(fields, cells):
    """The row's variable name.

    A tab whose header names the Variable column is authoritative — including when that cell is blank,
    which legitimately marks a note or continuation row. Falling back to position there would resurrect
    the bug this resolver exists to remove.
    """
    if "variable" in fields:
        return fields["variable"].strip()
    return next((c for c in cells[:3] if c and not c.isdigit()), "")


def column_key(header_cell):
    """The canonical field a header cell names, or None. The single place COLUMN_RULES is applied."""
    name = _norm(header_cell)
    if name in COLUMN_ALIASES:
        return COLUMN_ALIASES[name]
    return next((k for kw, k in COLUMN_RULES if kw in name), None)


def header_fields(cells):
    """The canonical fields a row's SHORT, label-shaped cells name — the header-density predicate.

    One predicate, two consumers that must agree: `starts_new_table` uses it to ADOPT a mid-sheet
    header, and `workbook_structure` uses it to REPORT the same rows so a person verifies each
    split. The short-label filter is the calibration: `column_key` matches by substring, so a prose
    data cell containing "definition", "source" and "values" once counted as three fields and an
    ordinary requirement row read as a header. A header cell is a short label; a rule is a
    sentence — cells longer than 24 characters do not count.
    """
    return {k for k in (column_key(str(c)) for c in cells or []
                        if str(c or "").strip() and len(_norm(str(c))) <= 24) if k}


def named_fields(header, cells, collisions=None):
    """{canonical column -> verbatim cell}, empty when the header names nothing recognisable.

    Values are returned exactly as extracted. This resolver decides only WHICH cell a column is, never
    what the cell says.

    First match wins, and when two VISIBLE headers resolve to the same field that silently picks one:
    `Definition` beside `EDM Derivation`, or `Current Rule` beside `Definition`, are shapes a new
    tumour's workbook can carry. The loser is recorded in `collisions` so a person chooses, rather than
    the resolver guessing by column order. The hidden-column shadow check already proved this failure
    mode is real; this is the same thing in plain sight.
    """
    out, seen = {}, {}
    for i, h in enumerate(header or []):
        if i >= len(cells):
            break
        key = column_key(h)
        if not key:
            continue
        if key in out:
            if collisions is not None:
                collisions.append({"field": key, "kept_header": seen[key][0],
                                   "kept_column": seen[key][1], "other_header": str(h).strip(),
                                   "other_column": i + 1})
            continue
        out[key], seen[key] = cells[i], (str(h).strip(), i + 1)
    return out


def unmapped_columns(row):
    """[(header label, verbatim cell)] for this row's columns that resolved to NO canonical field.

    THE one answer to "what did `fields` drop". `named_fields` above keeps only cells whose header
    matches a COLUMN_RULES keyword and silently skips the rest, and `columns_unresolved` in the
    extraction block does not cover this: it asks only whether `variable` and `definition` resolved
    somewhere on the tab, so a sheet can report nothing wrong while four of its columns reach no
    consumer.

    That is not hypothetical. The ovarian workbook carries `Origin`, `Evidence`, `Status` and `Owner`
    on every requirement sheet — `ADDITIVE (not in prior spec)`, `first-pass [verify]`,
    `DEFER/proposed`, `Epi-confirmed vs source (ratify)`. None matches a keyword, so none is in
    `fields`, and a drafter reading a rendered row cannot tell a settled requirement from one still
    marked for verification. The content was preserved in `cells` all along; nothing showed it.

    Blank cells and blank headers are skipped: an unnamed empty column is not withheld information.
    """
    header, cells = row.get("header") or [], row.get("cells") or []
    out = []
    for i, h in enumerate(header):
        if i >= len(cells):
            break
        label = str(h).strip()
        value = str(cells[i] or "").strip()
        if not label or not value or column_key(h):
            continue
        out.append((label, " ".join(value.split())))
    return out


def extraction_fingerprint(sources, rows):
    """One value identifying THIS extraction, over the source bytes and every row's content.

    `<domain>:<row>` is a COORDINATE, not an identity. When Science edits the text of a rule in place the
    id does not move, so a half-regenerated `out/` — extraction rerun, lint and scaffold left behind —
    still cites ids that all exist, and any check comparing id sets sees one coherent run. The
    content_hash is what moved, and nothing was comparing it.

    Over the source checksums, the extractor version and `item_id=content_hash` for every row in
    extraction order. Sorted nothing: row order is already deterministic and a reorder IS a different
    extraction. Carried unchanged into lint.json and scaffold.json so a consumer compares one value
    instead of reimplementing this.
    """
    parts = [EXTRACTOR_VERSION]
    parts += [f'{s.get("file", "")}={s.get("sha256", "")}' for s in (sources or [])]
    parts += [f'{r["item_id"]}={r["content_hash"]}' for r in rows]
    return hashlib.sha256("\x1f".join(parts).encode("utf-8")).hexdigest()[:16]


def _tab_label(text, fallback):
    for line in text.splitlines():
        if line.startswith("# "):
            m = TAB_IN_HEADER.match(line.strip())
            return (m.group(1).strip() if m else line[2:].strip()) or fallback
    return fallback


def starts_new_table(cells, header):
    """Does this row begin a SECOND table on the same tab, under the current `header`?

    ONE RULE, TWO READERS. The markdown reader has switched headers mid-tab since prostate's
    dataprep sheet was found carrying a build-parameters table and a situations table; the .xlsx
    reader did not, and kept the FIRST header for the rest of the worksheet. So reading the same
    specification through the two paths gave different answers: direct Excel ingestion read the
    second table's rows under the first table's column meanings — an `Action` cell landing under
    `definition` — and produced entirely plausible output. An external review found it, and the
    prostate Data Prep sheet has exactly that shape at around row 25.

    Two copies of a table-detection rule is how the two come to disagree, which is the reason this
    is a function rather than a second `if` in the xlsx loop.

    DELIBERATELY NARROW: two shapes and nothing looser.

      * A row whose FIRST cell repeats the current header's first cell — prostate's Data Prep
        carries `Row | ...` twice, and this rule has read it correctly since 1.3/1.4.
      * A row whose cells name THREE OR MORE canonical fields in short, label-shaped cells
        (`header_fields`). Found live on the first real mCRC run: 3.DataPrep holds three sections
        whose headers have three DIFFERENT first cells (`Data source`, `Study Time Period`, `#`),
        so the first rule never fired — Section A's three columns silently claimed every row of
        Sections B and C, no Definition column resolved, and every scaffolded record under them
        came back `required_rule: TODO` with the rule text sitting in the workbook.

    A data row with a mistyped row number must NOT be promoted to a header, because that remaps
    every row after it — a far worse failure than the one being fixed, and silent in the same way.
    Data cells are values and sentences, not short canonical labels, so the density rule refuses
    them; the same predicate ran report-only through 1.6 and produced zero hits on the live
    prostate and ovarian workbooks after the short-label calibration. Every density adoption is
    still REPORTED (`workbook_structure.header_candidates`, a HIGH lint finding) for a person to
    verify the split.
    """
    if not header or not cells:
        return False
    first = str(cells[0] or "").strip().lower()
    if first and first == str(header[0] or "").strip().lower():
        return True
    return len(header_fields(cells)) >= 3


def read_markdown_tab(path):
    """(tab, rows, shape) from one spec tab. A row is a markdown table line whose first cell is the
    Excel row.

    A tab may hold MORE THAN ONE table: prostate's dataprep sheet carries a build-parameters table
    and a situations table, each with its own header. A mid-file line that `starts_new_table` says
    is a header — first cell repeating the current header's, or three-plus canonical fields in
    short label cells — becomes the active header. Before the first rule, the second header was
    dropped and its rows were read under the FIRST table's columns, so `study_period:25` carried
    `section: '1'` and its Situation cell as `label`; the rules stay narrow so a data row with a
    mistyped row number is NOT promoted (that would remap every row after it) and lands in the
    shape report instead.

    The shape report is the anti-silent-loss half: every `|` line the reader did not consume as a
    row, header or separator is named with its line number; row-number jumps and rows whose cell
    count disagrees with their header are counted. The extraction stays green — whether a gap is
    hidden rows in the workbook or a lost line in the transcription is a question for a person —
    but the question is now ASKED (spec_lint turns each into a finding) instead of unaskable."""
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    tab = _tab_label(text, os.path.splitext(os.path.basename(path))[0])
    header, rows = [], []
    shape = {"skipped_lines": [], "row_gaps": [], "width_mismatches": [], "tables": 0}
    for lineno, line in enumerate(text.splitlines(), start=1):
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if not cells:
            continue
        if cells[0].isdigit():
            n = int(cells[0])
            if header and len(cells) != len(header):
                shape["width_mismatches"].append(
                    {"row": n, "cells": len(cells), "header_cells": len(header)})
            if rows and n != rows[-1]["row"] + 1:
                shape["row_gaps"].append([rows[-1]["row"], n])
            rows.append({"tab": tab, "row": n, "cells": cells[1:],
                         "header": header[1:] if header else []})
        elif set("".join(cells)) <= set("-: "):
            continue                            # separator
        elif not header or starts_new_table(cells, header):
            header = cells                      # the first header, or a second table's
            shape["tables"] += 1
        else:
            shape["skipped_lines"].append({"line": lineno, "text": line[:160]})
    return tab, rows, shape


def read_tsv_tab(path):
    """(tab, rows, shape) from one tab-separated sheet, in the shape `read_xlsx` produces for one
    sheet. The shape block is structural (`tables` only): a TSV row is a file line, so there are no
    row-number gaps to name, blank lines are skipped by the format's own rule, and trailing-cell
    variance is Excel's export behaviour rather than a transcription loss.

    The tab name is the file's stem — a `.tsv` has no sheet, and inventing one from the content would
    be the extractor guessing, which it does not do anywhere else. Row numbers are the FILE's line
    numbers, so a finding still points at something a person can open and count to, exactly as an Excel
    row number does.

    Header detection is `read_xlsx`'s rule, not a second one: the first line with three or more
    populated cells. A sheet exported to TSV keeps its title and subtitle lines, and those are
    `pre_header` for the same reason they are in a workbook — positionally known to sit above the
    table, so downstream classifies them without pattern-matching prose.

    No `csv` dialect sniffing and no quote handling beyond the module's: a specification cell that
    contains a tab has been mangled before it got here, and guessing a delimiter is the kind of
    cleanup the header of this file refuses.
    """
    with open(path, encoding="utf-8-sig") as fh:
        text = fh.read()
    tab = _tab_label(text, os.path.splitext(os.path.basename(path))[0])
    header, rows, tables = [], [], 0
    for idx, line in enumerate(text.splitlines(), start=1):
        cells = [c.strip() for c in line.rstrip("\n").split("\t")]
        if not any(cells):
            continue
        # The first header, or a SECOND table's — the same shared rule the other two readers
        # apply, because an exported sheet keeps whatever section structure the workbook had.
        if (not header and sum(1 for c in cells if c) >= 3) or starts_new_table(cells, header):
            header = cells
            tables += 1
            continue
        rows.append({"tab": tab, "row": idx, "cells": cells, "header": header,
                     "pre_header": not header})
    return tab, rows, {"skipped_lines": [], "row_gaps": [], "width_mismatches": [],
                       "tables": tables}


# A NUMBER FORMAT THAT CHANGES THE NUMBER. Matched against the format string openpyxl reports, with
# any `[Red]`-style condition and the currency/locale bracket stripped, and the four section forms
# (`positive;negative;zero;text`) reduced to the positive section — that is the one a threshold uses.
_PCT_FMT = re.compile(r"%")
_DECIMALS_FMT = re.compile(r"^[^.eE]*\.(0+)[^eE]*$")


def displayed_differently(cell):
    """What Excel SHOWS for this cell when that is not what this reader takes, else "".

    Measured on openpyxl, not assumed, because it silently converts some formats and not others:

      0%       a threshold typed as `5%` is STORED as 0.05, and openpyxl returns 0.05. The workbook
               says 5%, the extraction says 0.05, and a hundred-fold difference sits between what a
               reviewer approved and what the contract states.
      0.00     a cell holding 0.0034567 under a two-decimal format DISPLAYS `0.00`. The extraction
               takes the full precision — digits the reviewer could not see on screen at all.
      dates    openpyxl DOES convert these to `datetime`, so the value is right and only the
               rendering differs. Not reported: the extraction is unambiguous and a finding on every
               date cell is a finding everyone learns to ignore.
      0.00E+00 scientific notation is the same number either way. Not reported.

    So this reports the two cases where the NUMBER differs, and stays quiet on the ones where only
    the rendering does. Strings, blanks and booleans carry no format meaning and return "".
    """
    value, fmt = cell.value, (cell.number_format or "General")
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return ""
    fmt = re.sub(r"\[[^\]]*\]", "", str(fmt)).split(";")[0].strip()
    if _PCT_FMT.search(fmt):
        # `{:g}` rather than a fixed precision: 0.05 -> `5%`, not `5.0000%`.
        return f"{value * 100:g}%"
    m = _DECIMALS_FMT.match(fmt)
    if m:
        places = len(m.group(1))
        shown = f"{value:.{places}f}"
        if float(shown) != float(value):
            return shown
    return ""


def workbook_structure(path):
    """Structural facts about a workbook that make a cell EMPTY for a reason other than being empty.

    Measured, not assumed. A blank derivation cell reads identically whether the spec says nothing or
    whether the value is behind a formula with no cached result, or was swallowed by a merge. Both were
    silent: the row still becomes a spec item and a contract gets written from a blank rule.

      formula_no_value   openpyxl reads `data_only=True`, so a formula whose file was never re-saved by
                         Excel yields blank. The cell LOOKS empty and is not.
      merged             a merge keeps the anchor's value and blanks the rest of the range, so a merge
                         reaching across the Definition column deletes that column for those rows
      hidden_rows        usually retired content; extracted today as an ordinary requirement
      shadowing_cols     a HIDDEN column whose header names a canonical field. First match wins, so a
                         hidden `Definition (superseded)` sitting left of the visible `Definition`
                         supplies the rule
      validation_lists   a dropdown IS the value enumeration, and none of it is in the cell
      comments           Science's caveat frequently lives here rather than in Additional Notes
      display_differs    the cell's NUMBER FORMAT makes Excel show one number and this reader take
                         another — see `displayed_differently`. The reviewer approved what the
                         workbook displayed; the contract gets what it stored

    Reported per sheet; `spec_lint` turns them into findings. Nothing is dropped on this basis — what a
    hidden row means is a person's call, and silently discarding it would trade one silent loss for
    another.
    """
    import openpyxl
    formulas = openpyxl.load_workbook(path, data_only=False)
    # CLOSED, and on Windows that is correctness rather than hygiene. openpyxl holds the .xlsx
    # open until told otherwise, so a caller reading a workbook out of a temporary directory
    # cannot then delete it: `PermissionError: [WinError 32] the process cannot access the file
    # because it is being used by another process`. Ten tests failed on exactly that, on
    # Windows only — one of the two platforms CI runs — and the leak is this tool's, not
    # theirs. It leaks in production too; there it simply has no cleanup step to trip over.
    cached = openpyxl.load_workbook(path, data_only=True)
    try:
        out = {}
        for ws in formulas.worksheets:
            cw = cached[ws.title]
            # A merge is reported unless it is a BANNER, and a banner is full width AND ONE ROW TALL.
            #
            # The width half of that test was here from the start, for a good reason: a full-width merge
            # has no other column on its row to lose, and without the exemption the ovarian workbook
            # produced six HIGH findings for its A1:K1 titles — a finding everyone learns to ignore is
            # worse than no finding.
            #
            # THE HEIGHT HALF WAS MISSING, and an adversarial workbook found it. A merge blanks every
            # non-anchor cell in its RECTANGLE, so a full-width merge spanning three rows deletes two
            # entire requirement rows and keeps only the anchor's text. `A6:H8` over three real rows
            # reported NOTHING — `workbook_structure` returned `{}` — while two requirements vanished
            # and the extractor emitted rows with no item_id and no text. Silent loss of a requirement
            # is the exact failure this function exists to make impossible, and the shape that caused it
            # is ordinary: a section banner somebody dragged down over the rows beneath it.
            #
            # A banner is one row. Anything taller is swallowing content, however wide it is.
            partial = [str(r) for r in ws.merged_cells.ranges
                       if not (r.min_col == 1 and r.max_col >= ws.max_column and r.min_row == r.max_row)]
            # Only hidden columns that can SHADOW a field are reported. A hidden QC-initials column loses
            # nothing and is not worth a finding; a hidden column the resolver would read as `definition` is.
            header = next((r for r in ws.iter_rows(values_only=True)
                           if sum(1 for c in r if c not in (None, "")) >= 3), ())
            shadowing = []
            for i, cell in enumerate(header, start=1):
                key = column_key("" if cell is None else str(cell))
                letter = openpyxl.utils.get_column_letter(i)
                if key and ws.column_dimensions[letter].hidden:
                    shadowing.append(f"{letter} ({str(cell).strip()!r} -> {key})")
            # A SECOND TABLE'S HEADER, MID-SHEET, detected by CANONICAL-FIELD DENSITY. Since 1.7 the
            # reader ADOPTS these rows (`starts_new_table` applies the same predicate), so the rows
            # beneath are read under their own columns — this report is how a person VERIFIES each
            # split, because a wrongly adopted header remaps every row after it. Density does not
            # care what the first cell says: any row past the header whose cells resolve to three or
            # more canonical fields via column_key is named here.
            hdr_idx = next((i for i, r in enumerate(ws.iter_rows(values_only=True), start=1)
                            if sum(1 for c in r if c not in (None, "")) >= 3), 0)
            first_cell = ""
            if hdr_idx:
                hdr_row = next(r for i, r in enumerate(ws.iter_rows(values_only=True), start=1)
                               if i == hdr_idx)
                first_cell = next((_norm(str(c)) for c in hdr_row if c not in (None, "")), "")
            header_candidates = []
            for i, r in enumerate(ws.iter_rows(values_only=True), start=1):
                if i <= hdr_idx:
                    continue
                # a mid-sheet header whose FIRST cell repeats the main header's is the second-table
                # shape the extractor already handles correctly — flagging it would teach people to
                # ignore this finding; only a header that does NOT repeat it is silently misread
                cand_first = next((_norm(str(c)) for c in r if c not in (None, "")), "")
                if cand_first and cand_first == first_cell:
                    continue
                keys = header_fields(r)
                if len(keys) >= 3:
                    header_candidates.append(f"row {i} ({', '.join(sorted(keys))})")
            facts = {"formula_no_value": [], "merged": partial,
                     "hidden_rows": [i for i, d in ws.row_dimensions.items() if d.hidden],
                     "shadowing_cols": shadowing,
                     "header_candidates": header_candidates,
                     # THE SHEET'S OWN VISIBILITY, which was the one structural fact this reported
                     # nothing about. Hidden ROWS were reported and a hidden SHEET was not, so a
                     # requirement sheet somebody hid — or set `veryHidden`, which Excel's own UI will
                     # not re-show — extracted exactly like a visible one and nothing said so. A
                     # reviewer comparing the workbook on screen against the extraction would not find
                     # the sheet to check. `visible` is the ordinary case and is not reported.
                     "sheet_state": [] if ws.sheet_state == "visible" else [ws.sheet_state],
                     "display_differs": [],
                     "validation_lists": [], "comments": []}
            for row in ws.iter_rows():
                for c in row:
                    if isinstance(c.value, str) and c.value.startswith("=") and cw[c.coordinate].value is None:
                        facts["formula_no_value"].append(c.coordinate)
                    if c.comment is not None:
                        facts["comments"].append(c.coordinate)
                    shown = displayed_differently(cw[c.coordinate])
                    if shown:
                        facts["display_differs"].append(f"{c.coordinate} shows {shown} and extracts as "
                                                        f"{cw[c.coordinate].value!r}")
            for dv in ws.data_validations.dataValidation:
                if dv.type == "list":
                    facts["validation_lists"].append({"cells": str(dv.sqref), "values": dv.formula1})
            if any(facts.values()):
                out[ws.title.strip()] = {k: v for k, v in facts.items() if v}
    finally:
        formulas.close()
        cached.close()
    return out


def validate_sheet_titles(names):
    """Use the same legal sheet labels in read-only preview and full extraction."""
    for name in names:
        if (not isinstance(name, str) or not name.strip() or len(name) > 31
                or re.search(r"[\\/*?:\[\]]", name) or any(ord(char) < 32 for char in name)):
            raise ValueError("The workbook has an invalid worksheet name. Rename sheets to 1–31 characters "
                             "without \\, /, *, ?, :, [ or ], then save a plain Excel workbook and upload it again.")


def _header_index(rows, explicit=None):
    if explicit is not None:
        if explicit > len(rows) or not any(rows[explicit - 1]):
            raise ValueError("The selected header row is empty or outside this worksheet. Choose its current header row.")
        return explicit
    # Prefer recognizable column labels over a multi-cell title/banner. Unknown
    # layouts remain visible through the historical fallback and mapping UI.
    for index, cells in enumerate(rows, 1):
        if len(header_fields(cells)) >= 2:
            return index
    return next((index for index, cells in enumerate(rows, 1) if sum(bool(cell) for cell in cells) >= 3), None)


def inspect_columns(path, column_map=None):
    """Bounded, read-only header candidates and source samples for a mapping editor."""
    import openpyxl
    mappings = {sheet_key(name): value for name, value in parse_column_map(column_map).items()}
    workbook = openpyxl.load_workbook(path, data_only=True, read_only=True, keep_links=False)
    try:
        validate_sheet_titles(workbook.sheetnames)
        unknown = set(mappings) - {sheet_key(name) for name in workbook.sheetnames}
        if unknown:
            raise ValueError("A saved column mapping names a worksheet that is absent from this workbook. Review the mapping for this cut.")
        out = []
        for sheet in workbook.worksheets:
            sheet.reset_dimensions()
            config = mappings.get(sheet_key(sheet.title), {})
            if int(config.get("header_row") or 0) > 10000 or any(
                    _column_number(value) > 200 for value in config.get("columns", {}).values()):
                raise ValueError("The workbook mapping preview supports the portal's limit of 10,000 rows and 200 columns.")
            # Workbook uploads have their own XML size limits; this preview
            # additionally bounds rows/columns shown to people or a model.
            limit = min(max(int(config.get("header_row") or 0) + 5, 100), 10000)
            rows = []
            max_column = max([100, *[_column_number(value) for value in config.get("columns", {}).values()]])
            for row in sheet.iter_rows(min_row=1, max_row=limit, max_col=max_column, values_only=True):
                rows.append(["" if cell is None else str(cell).strip() for cell in row])
            index = _header_index(rows, config.get("header_row"))
            header = rows[index - 1] if index else []
            if any(not any(values[_column_number(column) - 1] for values in rows)
                   for column in config.get("columns", {}).values()):
                raise ValueError("A chosen source column is empty in this worksheet. Review its current column mapping.")
            override = {_column_number(column) - 1: field for field, column in config.get("columns", {}).items()}
            columns = [{"letter": _column_letter(i + 1), "header": cell,
                        "suggested": override.get(i) if override else column_key(cell),
                        "samples": [{"cell": f"{_column_letter(i + 1)}{number}", "value": values[i] if i < len(values) else ""}
                                    for number, values in list(enumerate(rows, 1))[index:index + 5]]}
                       for i, cell in enumerate(header) if cell or i in override]
            out.append({"name": sheet.title, "header_row": index, "columns": columns,
                        "preview_rows": [{"row": number, "cells": cells[:max(
                            (i + 1 for i, value in enumerate(cells) if value), default=0)]}
                            for number, cells in enumerate(rows, 1) if any(cells)][:20],
                        "header_candidates": [{"row": number, "cells": cells}
                            for number, cells in enumerate(rows, 1) if len(header_fields(cells)) >= 2][:20],
                        "mapping": config})
        return out
    finally:
        workbook.close()


def read_xlsx(path, header_row=None, *, read_only=False, sheets=None, column_map=None):
    """Rows from every sheet of the approved workbook, verbatim, with true Excel row numbers."""
    try:
        import openpyxl
    except ImportError:
        sys.exit("openpyxl is required for the .xlsx path: pip install openpyxl")
    mappings = {sheet_key(name): value for name, value in parse_column_map(column_map).items()}
    if not read_only:
        # Full openpyxl loading rejects illegal titles itself, while its read-only
        # mode silently accepts them. Check metadata first for one clear failure.
        probe = openpyxl.load_workbook(path, read_only=True, keep_links=False)
        try:
            validate_sheet_titles(probe.sheetnames)
        finally:
            probe.close()
    wb = openpyxl.load_workbook(path, data_only=True, read_only=read_only, keep_links=not read_only)
    try:
        validate_sheet_titles(wb.sheetnames)
        unknown = set(mappings) - {sheet_key(name) for name in wb.sheetnames}
        if unknown:
            raise ValueError("A saved column mapping names a worksheet that is absent from this workbook. Review the mapping for this cut.")
        out = []
        for ws in wb.worksheets:
            if sheets is not None and sheet_key(ws.title) not in sheets:
                continue
            if read_only:
                # The early portal check has already bounded actual XML cells.
                # Ignore untrusted declared dimensions and merged-cell grids.
                ws.reset_dimensions()
            config = mappings.get(sheet_key(ws.title), {})
            typed_rows = list(ws.iter_rows(values_only=True))
            raw_rows = [["" if cell is None else str(cell) for cell in row] for row in typed_rows]
            trimmed = [[cell.strip() for cell in row] for row in raw_rows]
            first_header = _header_index(trimmed, config.get("header_row", header_row))
            header, current_header_row = [], None
            for idx, cells in enumerate(trimmed, start=1):
                if not any(cells):
                    continue
                # The header is the first row with several populated cells; everything after it is data.
                if idx == first_header:
                    header = cells
                    current_header_row = idx
                    if any(_column_number(value) > len(cells) for value in config.get("columns", {}).values()):
                        raise ValueError("A chosen column is outside this worksheet. Review its current columns.")
                    continue
                # ...AND A SECOND TABLE ON THE SAME SHEET GETS ITS OWN HEADER, by the same rule the
                # markdown reader uses. Without this the first table's column meanings were applied to
                # every row below it, so a second table's `Action` column was read as `definition` and
                # the output looked entirely reasonable. The prostate Data Prep sheet has this shape.
                if header and starts_new_table(cells, header):
                    header = cells
                    current_header_row = idx
                    continue
                # A populated row ABOVE the table header is a sheet title, subtitle or row-count line, not a
                # requirement. Recording that positionally-known fact here is what lets downstream classify
                # it without pattern-matching its prose.
                out.append({"tab": ws.title.strip(), "row": idx, "cells": cells, "header": header,
                            "raw_cells": raw_rows[idx - 1], "header_row": current_header_row,
                            "source_types": [type(cell).__name__ for cell in typed_rows[idx - 1]],
                            "column_overrides": config.get("columns", {}) if current_header_row == first_header else {},
                            "pre_header": not header})
    finally:
        wb.close()
    return out


def parse_domains(spec):
    """`sheet=domain,sheet=domain` -> {sheet_lower: domain}. See governance/SPEC_DOMAINS.md."""
    out = {}
    for pair in (spec or "").split(","):
        if "=" in pair:
            k, v = pair.split("=", 1)
            out[sheet_key(k)] = v.strip()
    return out


def parse_ignore(spec):
    """`sheet,sheet` -> {sheet_lower}. A PRODUCT's declaration that these sheets carry no requirements.

    The per-pack counterpart to DOMAINS, and it exists for the same reason. The shared map is Science's
    template — a label there means the same thing in every tumour's workbook — so a sheet only one
    workbook ships does not belong in it. Ovarian 202606's `9.PROC PSOC Strategy` has no counterpart
    in any other product; putting it in the repo-wide ignored list would declare it non-requirement
    material for every product and every future version, silently, including the next ovarian spec
    where somebody might want it in scope.

    Scoping it to the pack means a later version starts unclassified again and has to be ruled on
    afresh — which is right: a scope decision is made about a specification, not about a sheet name.
    """
    return {sheet_key(s) for s in (spec or "").split(",") if s.strip()}


REPO_MARKER = os.path.join("platform", "tools")


def repo_root(start):
    """Resolve explicitly selected authoring data or the containing workspace."""
    from rwd_services import workspace_root
    try:
        return str(workspace_root(start, required=True))
    except ValueError:
        return None


def repo_relative(path, root=None):
    """A path as a checkout-relative id: forward slashes, no checkout prefix.

    Two callers, one concept. Generated files are byte-compared by `--check`, so an absolute path there
    makes the comparison mean "was this regenerated on the same machine, in the same directory" rather
    than "is this current" — it passes locally and fails on every other checkout. And every gate tool
    identifies a pack this way, because `fixtures/oncology/prostate/202606` is what the registry, the
    maturity map and the evidence routes are all keyed on.

    `root` names the checkout to measure against; omitted, it is found by walking up from the path.

    **`os.path.relpath` RAISES when the two are on different Windows drives**, and that is not an exotic
    case: a GitHub runner checks out to `D:` and puts temporary directories on `C:`, so every tool
    handed a path outside its checkout died with `ValueError: path is on mount 'C:', start on mount
    'D:'` — 91 of them in one CI run. POSIX has no drives, so the same situation answered `../../tmp/x`
    and nothing ever noticed the assumption.

    A path outside the checkout gets its ABSOLUTE form, on both platforms. "Not in this checkout" is
    the true answer; `../../tmp/x` is that same answer written as though it were a pack id, which is
    what let the assumption hide.
    """
    p = os.path.abspath(path)
    base = os.path.abspath(root) if root else repo_root(p)
    if not base:
        return os.path.basename(p.rstrip(os.sep)).replace(os.sep, "/")
    try:
        rel = os.path.relpath(p, base)
    except ValueError:                       # different drive: not under this checkout at all
        return p.replace(os.sep, "/")
    if rel.split(os.sep, 1)[0] == os.pardir:
        return p.replace(os.sep, "/")
    return rel.replace(os.sep, "/")


def pack_path(path, root=None):
    """An absolute directory for a pack argument, resolved the way the repository names packs.

    Absolute as given; a relative path that exists from the current directory as that; otherwise
    against the checkout root. `fixtures/oncology/prostate/202606` is a CHECKOUT-relative id — it
    is what the registry, the maturity map and every gate key on — and CI runs the suites from
    `platform/`, so a tool that resolved it against the current directory refused a registered pack
    as unregistered in exactly the environment that proves it (eleventh verdict, second pass:
    quick_counts and the contract drafting path were red from `platform/` and green from the root).
    """
    p = str(path or "")
    if os.path.isabs(p):
        return os.path.normpath(p)
    if os.path.isdir(p):
        return os.path.abspath(p)
    base = os.path.abspath(root) if root else repo_root(__file__)
    return os.path.normpath(os.path.join(base, p)) if base else os.path.abspath(p)


def inside_checkout(path, root):
    """Whether `path` resolves to somewhere at or under the checkout at `root`.

    HERE BECAUSE IT IS PATH ARITHMETIC AND THIS MODULE OWNS THAT, and because of what depends on the
    answer. `pack_run.restricted_dir` refuses an output directory inside the repository — a profile or
    a schema report in the tree is readable by every indexing tool and agent on the machine — and
    `doctor.py` must ask the same question to tell somebody their output directory is unusable.

    `pack_run` cannot serve that: it imports `product_gates` and `engine.config`, both of which import
    yaml, so `doctor.py`'s check crashed with an ImportError traceback on a machine with no PyYAML —
    the exact machine it exists to diagnose, and before it had printed a single row. This module is
    stdlib-only, so the one predicate is reachable with nothing installed.

    `realpath` on both sides, so a symlinked checkout or a `~` cannot walk around the refusal.
    """
    p = os.path.realpath(os.path.expanduser(str(path)))
    base = os.path.realpath(os.path.expanduser(str(root)))
    return p == base or p.startswith(base + os.sep)


SHEET_MAP = os.path.join("governance", "spec_sheet_map.yaml")
SHEET_LINE = re.compile(r'^\s*"([^"]+)"\s*:\s*([a-z_]+)\s*$')
_WS = re.compile(r"\s+")


def sheet_key(label):
    """The comparison key for an Excel tab label: casefolded, with ALL whitespace removed.

    Every comparison of a tab against the sheet map goes through here — the map's own keys, the domain
    lookup, `ignored`, the product IGNORE and an explicit `--tabs` list. One function, because a tab
    that is "classified" under one spelling and "unclassified" under another is the exact state this
    map exists to make impossible.

    Whitespace is REMOVED rather than collapsed because the difference that costs is inside the label,
    not around it: `5B. ClinChars` and `5B.ClinChars` are the same tab typed by two people, and under
    strip-and-lower they are two different keys. The one that missed dropped an entire domain — 96
    requirement rows extracted as unclassified — and the symptom (no `clinical` anywhere downstream)
    names nothing that would lead a reader back to a space.

    Normalising merges keys, so `shared_sheet_map` refuses a merge that changes an answer.
    """
    return _WS.sub("", str(label)).casefold()


def citation_domain(row):
    """The citation namespace, distinct from a row's logical scientific domain.

    Single-sheet domains retain their existing citations. When a workbook has
    multiple sheets for one domain, the extractor records a sheet-qualified
    namespace so row 2 on one sheet cannot cite row 2 on another.
    """
    return row.get("citation_domain") or row.get("domain") or row.get("tab")


def row_item_id(row):
    """One source-row identifier shared by extraction, drafting and review."""
    return f"{citation_domain(row)}:{row['row']}"


def shared_sheet_map(start=None):
    """The repo-wide sheet map: `{"sheets": {...}, "ignored": {...}}`, keyed by `sheet_key`.

    Both halves matter. Without the ignored list, "this sheet holds no requirements" and "nobody has
    looked at this sheet yet" are the same state — absence — and a new requirement-bearing sheet is
    skipped in silence.

    Raises on a key collision that carries two different answers. Normalisation is only safe while it
    merges spellings of ONE ruling; two labels that normalise together and disagree would resolve by
    file order, which is invisible in the output and is the drift this file exists to prevent.
    """
    base = start if start is not None else repo_root(__file__)
    if not base:
        return {"sheets": {}, "ignored": {}}
    d = os.path.abspath(base)
    while True:
        path = os.path.join(d, SHEET_MAP)
        if os.path.isfile(path):
            out = {"sheets": {}, "ignored": {}}
            labels, section = {}, None
            with open(path, encoding="utf-8") as fh:
                for line in fh:
                    body = line.split("#", 1)[0]
                    head = re.match(r"^(sheets|ignored):\s*$", body)
                    if head:
                        section = head.group(1)
                        continue
                    m = SHEET_LINE.match(body)
                    if not (m and section):
                        continue
                    label, value, key = m.group(1), m.group(2), sheet_key(m.group(1))
                    prior = labels.get(key)
                    if prior and (prior[0] != section or prior[1] != value):
                        raise ValueError(
                            f"{SHEET_MAP}: {prior[2]!r} ({prior[0]}: {prior[1]}) and {label!r} "
                            f"({section}: {value}) both normalise to {key!r} but say different "
                            f"things. Tab labels are compared with whitespace removed and case "
                            f"folded, so these are one key — decide which ruling it carries.")
                    labels[key] = (section, value, label)
                    out[section][key] = value
            return out
        parent = os.path.dirname(d)
        if parent == d:
            return {"sheets": {}, "ignored": {}}
        d = parent


def shared_domains(start=None):
    """Just the sheet -> domain half of the shared map."""
    return shared_sheet_map(start)["sheets"]


# Rows that are structure, not requirements. Scaffolding these would inflate the contract with records
# for section banners — the traceability model classifies them as `context` instead. Rows found ABOVE a
# sheet's table header (`pre_header`) are classified the same way, by position rather than by prose.
CONTEXT_RE = re.compile(r"^\s*(section\s+[a-z]\b|processing\s*:|note\s+to\s+programmer)", re.I)

# A blank Variable cell does NOT by itself mean "not a requirement". A blank variable is respected
# because it can mark a continuation row — the rest of a long derivation, a second branch, an extra
# value. Calling every such row `context` would drop those silently, so a blank-variable row is context
# only when it carries almost no text; anything substantive is left for a person to classify.
CONTEXT_MAX_CHARS = 25


def is_context(row):
    """True only for rows that are STRUCTURE: above the table header, or a recognised banner.

    Lives here, not in contract_scaffold which is its main caller, because it reads only this module's
    row shape and because the extractor needs it: a banner row has no variable name to resolve, so
    warning that its variable came from cell position is crying wolf, and six such warnings teach a
    reader to skip the one that matters. contract_scaffold imports it — a second copy would agree today
    and diverge on the first change to what counts as a banner, with "needs a contract record" and
    "does not" on either side of the disagreement.
    """
    if row.get("pre_header"):
        return True
    var = row["variable"]
    if CONTEXT_RE.match(var):
        return True
    if var:
        return False
    body = " ".join(c for c in row["cells"] if c.strip()).strip()
    return len(body) <= CONTEXT_MAX_CHARS


def requirement_rows(data, tabs=None):
    """The rows that carry requirements.

    An explicit `tabs` list wins. Otherwise it is every row with a DOMAIN — a domain is exactly the
    statement "this sheet holds requirements", which is why no product has to restate the tab list.
    A spec with no domain mapping at all falls back to every row rather than silently scanning nothing.
    """
    if tabs:
        keep = {sheet_key(x) for x in tabs}
        return [r for r in data["rows"] if sheet_key(r["tab"]) in keep]
    if any(r.get("domain") for r in data["rows"]):
        return [r for r in data["rows"] if r.get("domain")]
    return data["rows"]


def extract(target, domains=None, ignore=None, column_map=None):
    """Extract from a product directory (spec tabs) or a single .xlsx workbook.

    `ignore` is the PRODUCT's set of sheets declared to carry no requirements, on top of the shared
    map's `ignored:`. See parse_ignore.
    """
    domains = domains or {}
    ignore = ignore or set()
    column_map = parse_column_map(column_map)
    rows, sources, structure = [], [], {}
    # None means NOT DETERMINED — the per-tab paths have no workbook to enumerate — and is
    # deliberately not [] , which would claim the workbook has no sheets.
    sheet_names = None
    if os.path.isdir(target):
        # A CONVENIENCE for running this by hand on a PACK directory; the pipeline never relies on it,
        # because run_spec_pipeline.sh resolves the registered material through source_refs.yaml and
        # passes the spec directory itself. A list, not one literal: packs spell this folder
        # differently (`prog_spec/`, `ref/prog_spec/`, `Program Specification/`), and a single
        # hardcoded path silently found nothing on every pack that did not match it.
        nested = next((os.path.join(target, d) for d in
                       ("prog_spec", os.path.join("ref", "prog_spec"), "Program Specification")
                       if os.path.isdir(os.path.join(target, d))), None)
        spec_dir = nested or target
        names = sorted(os.listdir(spec_dir))
        mds = [n for n in names if n.endswith(".md")]
        tsvs = [n for n in names if n.endswith(".tsv")]
        # ONE FORMAT PER DIRECTORY. A folder holding both is two spellings of the same tabs, and which
        # one produced a record would depend on the order this loop happens to run in — invisible in
        # the output, and the exact drift the pipeline exists to prevent one level up.
        if mds and tsvs:
            sys.exit(f"{spec_dir}: holds BOTH .md and .tsv tabs ({len(mds)} and {len(tsvs)}). One "
                     f"format per spec directory — two stand-ins of one tab is a record whose "
                     f"source depends on sort order. Keep the authoritative set and remove the other.")
        readers = {".md": read_markdown_tab, ".tsv": read_tsv_tab}
        for fn in names:
            ext = os.path.splitext(fn)[1].lower()
            if ext not in readers:
                continue
            path = os.path.join(spec_dir, fn)
            tab, tab_rows, tab_shape = readers[ext](path)
            if not tab_rows:
                continue
            rows.extend(tab_rows)
            with open(path, "rb") as fh:
                sources.append({"file": fn, "tab": tab, "rows": len(tab_rows),
                                "sha256": hashlib.sha256(fh.read()).hexdigest()[:16],
                                "shape": tab_shape})
    elif target.lower().endswith(".tsv"):
        tab, rows, tab_shape = read_tsv_tab(target)
        with open(target, "rb") as fh:
            sources.append({"file": os.path.basename(target), "tab": tab, "rows": len(rows),
                            "sha256": hashlib.sha256(fh.read()).hexdigest()[:16],
                            "shape": tab_shape})
    else:
        rows = read_xlsx(target, column_map=column_map)
        structure = workbook_structure(target)
        # EVERY SHEET THE WORKBOOK HAS, not just the ones that produced rows. Everything below is
        # derived from `rows`, so a requirement-bearing sheet that is EMPTY or header-only produces
        # no row, appears in no list, and disappears entirely — it cannot even be `unclassified`,
        # because that is computed from rows too. A sheet nobody extracted and a sheet that does not
        # exist were the same answer.
        #
        # NOT wrapped in a try. The two calls above already opened this same file, so openpyxl
        # imports and the workbook parses by the time this runs; anything raising here is a defect,
        # and catching it would file that defect as `None` — "not determined" — which reads as an
        # honest absence and suppresses the finding below. `read_only` because only the names are
        # wanted and the cell tree has been built twice already.
        import openpyxl
        _probe = openpyxl.load_workbook(target, read_only=True)
        try:
            sheet_names = [n.strip() for n in _probe.sheetnames]
        finally:
            _probe.close()      # see workbook_structure: an open workbook pins the file
        with open(target, "rb") as fh:
            sources.append({"file": os.path.basename(target), "tab": "(workbook)", "rows": len(rows),
                            "sha256": hashlib.sha256(fh.read()).hexdigest()[:16]})

    # DEFERRED, not top-level: `product_gates` imports `repo_root` from this module and
    # `source_manifest` imports `product_gates`, so a module-level import here is a cycle. The
    # redactor has to live with `vendor_prose` — detection and removal sharing one marker list is the
    # whole point — so the import moves rather than the function.
    from rwd_tools import source_manifest as sm                                    # noqa: E402

    actual_tabs = sheet_names if sheet_names is not None else sorted({r["tab"] for r in rows})
    domain_tabs = {}
    for tab in actual_tabs:
        domain = domains.get(sheet_key(tab))
        if domain:
            domain_tabs.setdefault(domain, set()).add(tab)
    multiple_sheets = {domain for domain, tabs in domain_tabs.items() if len(tabs) > 1}
    collisions = {}
    for r in rows:
        body = " | ".join(r["cells"])
        r["text"] = body
        # The hash covers WHAT the cells say AND WHICH FIELD each one is. Over the cell text alone,
        # swapping the `Definition` and `Additional Notes` column headers left the row byte-identical
        # while the cell the contract reads as the derivation changed — invisible to I15, which claims
        # a record is bound to the text it was written from.
        seen_headers = collisions.setdefault(r["tab"], [])
        overrides = r.get("column_overrides") or {}
        header = r.get("header") or []
        effective_header = ["" for _ in header] if overrides else list(header)
        for field, column in overrides.items():
            index = _column_number(column) - 1
            while index >= len(effective_header):
                effective_header.append("")
            effective_header[index] = field.replace("_", " ")
        fields = named_fields(effective_header, r["cells"], seen_headers)
        # codelist_group is not itself a synonym: explicit choices are the
        # authoritative assignment, independent of display/header spelling.
        fields.update({field: r["cells"][_column_number(column) - 1]
                       for field, column in overrides.items() if _column_number(column) <= len(r["cells"])})
        if r.get("header_row"):
            field_sources = {}
            raw_cells = r.get("raw_cells", r["cells"])
            for index, cell in enumerate(effective_header):
                key = next((field for field, column in overrides.items() if _column_number(column) - 1 == index), column_key(cell))
                if key and key in fields and key not in field_sources and index < len(raw_cells):
                    raw_value = raw_cells[index]
                    field_sources[key] = {"sheet": r["tab"], "cell": f"{_column_letter(index + 1)}{r['row']}",
                        "header_cell": f"{_column_letter(index + 1)}{r['header_row']}",
                        "header": header[index] if index < len(header) else "", "raw_value": raw_value,
                        "source_type": (r.get("source_types") or ["str"] * len(raw_cells))[index],
                        "raw_sha256": hashlib.sha256(raw_value.encode("utf-8")).hexdigest(),
                        "parser": "confirmed_column_map" if key in overrides else "header_synonym",
                        "parser_version": EXTRACTOR_VERSION}
            r["field_sources"] = field_sources
        r["content_hash"] = _hash(r["tab"], body,
                                  ";".join(f"{k}={fields[k]}" for k in sorted(fields)))
        # Cite by DOMAIN, not by the workbook's own sheet label: sheet names differ per product and per
        # revision (prostate "5B. ClinChars" vs ovarian "6.Clinical characteristics" for the same
        # content), so a sheet-based citation stops resolving the moment Science renames a tab.
        r["domain"] = domains.get(sheet_key(r["tab"]), "")
        if r["domain"] in multiple_sheets:
            r["citation_domain"] = r["domain"] + ".s" + hashlib.sha256(sheet_key(r["tab"]).encode("utf-8")).hexdigest()[:12]
        r["item_id"] = row_item_id(r)
        f = fields
        r["fields"] = f
        r["variable"] = row_variable(f, r["cells"])
        # VENDOR DOCUMENTATION IS REDACTED HERE, AND ONLY AFTER content_hash IS TAKEN.
        #
        # `extracted.json` is what AI reads; the stand-in in the pack's `prog_spec/` is what a
        # human reads and what the Gate 1 attestation is against. Where Science's specification quotes a
        # vendor's documentation, the stand-in faithfully reproduces it — correctly — and the
        # derived artifact must not. Sanitizing the stand-in instead would break the very
        # fidelity `attested_against_sha256` records.
        #
        # ORDER IS THE WHOLE TRICK. The hash above covers the ORIGINAL cells, so `spec_digest` still
        # binds a contract record to the real specification text and I15 still catches Science editing a
        # rule in place. Redacting before hashing would have silently changed every digest on the BP
        # family and failed I15 on five records that were correct.
        redacted = []
        for i, cell in enumerate(r["cells"]):
            clean, markers = sm.redact_vendor_prose(cell, f'{r["item_id"]} cell {i}')
            if markers:
                r["cells"][i] = clean
                if "raw_cells" in r:
                    r["raw_cells"][i] = sm.redact_vendor_prose(r["raw_cells"][i], r["item_id"])[0]
                redacted += markers
        if redacted:
            # A COUNT, not the marker names — see `redact_vendor_prose`. A field carrying the marker
            # strings would put them back into the very file the redaction just cleaned.
            r["vendor_redacted"] = len(redacted)
            r["text"] = " | ".join(r["cells"])
            r["fields"] = {k: sm.redact_vendor_prose(v, r["item_id"])[0] if isinstance(v, str) else v
                           for k, v in f.items()}
            for source in r.get("field_sources", {}).values():
                clean, markers = sm.redact_vendor_prose(source["raw_value"], r["item_id"])
                if markers:
                    source["original_raw_sha256"] = source["raw_sha256"]
                    source["raw_value"] = clean
                    source["raw_sha256"] = hashlib.sha256(clean.encode("utf-8")).hexdigest()
                    source["sanitized"] = True

    by_header = sum(1 for r in rows if "variable" in r["fields"])

    # A requirement-bearing tab (one with a domain) whose header names no variable or no definition
    # column means this workbook uses a label the keyword rules do not know. Every row on that tab then
    # comes out missing that field — quietly, because the rows themselves are still well-formed. Name it
    # here so a new product finds out on its first run instead of downstream.
    resolved, unresolved = {}, []
    for r in rows:
        if r["domain"]:
            resolved.setdefault(r["tab"], set()).update(r["fields"])
    for tab, keys in sorted(resolved.items()):
        missing = [k for k in ("variable", "definition") if k not in keys]
        if missing:
            unresolved.append({"tab": tab, "missing": missing})

    # A sheet with no domain is either declared non-requirement material, or nobody has classified it.
    # Those are different states and only one of them is safe to skip. The declaration can come from
    # the shared map (Science's template, every product) or from this pack's own IGNORE (a sheet only this
    # workbook ships) — but a sheet in NEITHER is unclassified, whichever file could have said so.
    ignored = set(shared_sheet_map().get("ignored", {})) | ignore
    unclassified = sorted({r["tab"] for r in rows
                           if not r["domain"] and sheet_key(r["tab"]) not in ignored})
    # Recorded so the ruling is visible in the artifact a reviewer diffs. A per-product exclusion that
    # only existed in pipeline.conf would take a sheet out of scope and leave the evidence silent
    # about it, which is the same shape as never having looked.
    product_ignored = sorted({r["tab"] for r in rows
                              if not r["domain"] and sheet_key(r["tab"]) in ignore})

    # A REQUIREMENT-BEARING SHEET THAT PRODUCED NOTHING. Every list above is derived from `rows`, so
    # a sheet that is empty, header-only, or whose rows all failed to parse contributes none and
    # cannot appear in any of them — not even as `unclassified`. "Nobody extracted this sheet" and
    # "this sheet does not exist" were the same answer, which is the shape an external review named:
    # coverage is computed from extracted rows, so a missing expected sheet disappears rather than
    # failing.
    #
    # A sheet in the shared map's `sheets:` is requirement-bearing BY THAT FACT — the map's own
    # header says so — which is why no new per-pack declaration is invented here. One expected-domain
    # contract already exists; this reads it.
    #
    # Reported, not raised. Whether an empty requirement sheet is a workbook Science shipped that way or
    # a transcription that lost a tab is a person's question, and `spec_lint` turns the entry into a
    # finding. What must not happen is the sheet vanishing.
    #
    # The key is ABSENT, not [], when no workbook was enumerated — the per-tab path has no sheets, so
    # there was nothing to check, and `[]` there would read as "every expected sheet produced rows".
    # Manufacturing a clean result out of a check that never ran is the same defect this entry is
    # for, pointed the other way. A reader must handle the key's absence as "not determined".
    mapped = set(shared_sheet_map().get("sheets", {})) | set(domains)
    produced = {sheet_key(r["tab"]) for r in rows}
    expected_empty = (sorted(n for n in sheet_names
                             if sheet_key(n) in mapped and sheet_key(n) not in produced)
                      if sheet_names is not None else None)

    # TWO TABS, ONE KEY. Every classification and every citation goes through `sheet_key`, which
    # folds case and strips ALL whitespace — that is what makes '5.Demographics ' match the map.
    # The same folding means Excel will happily hold '8.Outcomes' AND '8.outcomes ' as two sheets
    # this pipeline cannot tell apart: both take the same domain, and their rows then share
    # `domain:row` item_ids — an adversarial run produced two DIFFERENT requirements both citable
    # as `outcomes:2`, listed twice in coverage with nothing naming the clash. A citation that can
    # mean either of two rules is worse than no citation, so this is computed over every label the
    # extraction saw (all workbook sheets when one was enumerated; the produced tabs otherwise) and
    # a domain-resolving collision is FATAL in main() — there is no correct reading to fall back
    # to, and no bypass flag, because the only fix is renaming a tab or ruling one out by IGNORE.
    _labels = sheet_names if sheet_names is not None else sorted({r["tab"] for r in rows})
    _by_key = {}
    for _l in _labels:
        _by_key.setdefault(sheet_key(_l), []).append(_l)
    sheet_key_collisions = [{"key": k, "labels": sorted(set(v)),
                             "domain": (domains or {}).get(k, "")}
                            for k, v in sorted(_by_key.items()) if len(set(v)) > 1]

    # The same count over the rows that BECOME requirements. `variable_by_position` spans every row in
    # the workbook, and a real .xlsx carries 15-odd cover, changelog, delta and review-decision sheets
    # that have no Variable column at all — so on the first ovarian run it read `461 of 828 fell back
    # to position`, a figure that is alarming, unactionable, and mostly noise from sheets nothing ever
    # scans. Whether a POSITIONAL read reached a contract record is the question, and it was the one
    # number not on the page. Through requirement_rows() so this stays the same definition of
    # "requirement-bearing" the scaffold and the coverage report use.
    # Banner rows excluded: they have no variable name to resolve, so "took it from cell position" is
    # true and meaningless. On the first ovarian run all 18 positional requirement rows were banners —
    # six warnings, none actionable, which is how a reader learns to skip the seventh.
    req = requirement_rows({"rows": rows})
    req_by_position = {}
    # ...AND WHERE THEY ARE. The per-tab count says "10 rows on 3.DataPrep took the variable from
    # cell position"; it does not say WHICH, so acting on it means re-deriving the extractor's own
    # answer by eye against a 40-row sheet. An external review asked for the coordinates and it is
    # right: a warning a reader cannot act on without redoing the work is a warning they skip.
    req_by_position_rows = []
    for r in req:
        if "variable" not in r["fields"] and not is_context(r):
            req_by_position[r["tab"]] = req_by_position.get(r["tab"], 0) + 1
            req_by_position_rows.append({"tab": r["tab"], "row": r["row"],
                                         "variable": (r.get("variable") or "")[:60]})

    # Every header label that reached no canonical field, per requirement tab. `columns_unresolved`
    # above answers only "did variable and definition resolve"; a workbook can satisfy that and still
    # drop four columns of disposition state into `cells` where nothing reads them. Sorted, because
    # these artifacts are byte-compared for drift.
    dropped = {}
    for r in rows:
        if not r["domain"]:
            continue
        for label, _ in unmapped_columns(r):
            dropped.setdefault(r["tab"], set()).add(label)

    from rwd_tools import source_manifest as sm                                    # noqa: E402  (cycle: see above)

    return {"extraction": {
        "extractor_version": EXTRACTOR_VERSION,
        # An additive citation schema for a previously ambiguous input shape.
        # Single-sheet artifacts retain their exact version and bytes; the
        # fingerprint below binds every qualified item id when this is used.
        **({"citation_schema": "sheet-qualified-v1"} if multiple_sheets else {}),
        "target": repo_relative(target),
        "sources": sources,
        # One value over the source bytes AND every row's content_hash, carried into lint.json and
        # scaffold.json. An in-place spec edit moves this; it does not move any item_id.
        "fingerprint": extraction_fingerprint(sources, rows),
        # WHAT THE REDACTOR DID, AND UNDER WHICH POLICY. This artifact is separately governed — a human
        # approves it for AI use — and an approval has to be over something. The policy digest is what
        # makes it revocable by change rather than by memory: weaken `governance/ai_boundary.yaml` and
        # fewer cells are removed, so the approval given under the old policy no longer describes this
        # file and Gate 1 says so. The counts are the visible half, for a person reading the record.
        "redaction": {"policy_sha256": sm.redaction_policy_sha256(),
                      "cells_redacted": sum(r.get("vendor_redacted", 0) for r in rows),
                      "rows_redacted": sum(1 for r in rows if r.get("vendor_redacted"))},
        "row_count": len(rows),
        "variable_by_header": by_header,        # rows whose variable came from a named column
        "variable_by_position": len(rows) - by_header,
        "requirement_row_count": len(req),
        # Per requirement tab, so the fix is a header rule for a named sheet rather than a hunt.
        "variable_by_position_tabs": [{"tab": t, "rows": n}
                                      for t, n in sorted(req_by_position.items())],
        # The same rows, addressably. Sorted because these artifacts are byte-compared for drift.
        "variable_by_position_rows": sorted(req_by_position_rows,
                                            key=lambda d: (d["tab"], d["row"])),
        "columns_unresolved": unresolved,      # requirement tabs whose header names an unknown label
        # Columns present in the workbook that no COLUMN_RULES keyword claims, so they exist only in
        # `cells`. Not an error — a workbook may carry columns this framework has no field for — but
        # it must be VISIBLE, because the alternative is content silently reaching no reader.
        "columns_dropped": [{"tab": t, "labels": sorted(v)} for t, v in sorted(dropped.items())],
        # Two VISIBLE headers resolving to one canonical field. First-match-wins picked one silently.
        # Per SHEET and sorted: a set of dicts iterates in an order that is not a serialization
        # contract, and these artifacts are byte-compared for drift — with two ambiguities the file
        # could differ between runs. Dormant while no pack has one, which is exactly when it would
        # first bite.
        "columns_ambiguous": sorted(
            ({"tab": tab, **dict(c)} for tab, cs in collisions.items()
             for c in {tuple(sorted(x.items())) for x in cs}),
            key=lambda c: (c["tab"], c["field"], c["other_column"])),
        "tabs": sorted({r["tab"] for r in rows}),
        "domains": sorted({r["domain"] for r in rows if r["domain"]}),
        "unmapped_tabs": sorted({r["tab"] for r in rows if not r["domain"]}),
        # sheets in NEITHER half of the shared map nor this pack's IGNORE — must be classified,
        # never silently skipped
        "unclassified_tabs": unclassified,
        # sheets THIS pack declared non-requirement, as opposed to the shared map's template-wide list
        "product_ignored_tabs": product_ignored,
        # sheets the shared map calls requirement-bearing that yielded ZERO rows. The key is ABSENT —
        # not [] — on the per-tab paths, which have no workbook whose sheets could be enumerated: see
        # where it is computed. Absent means "not determined", [] means "determined, and none".
        **({} if expected_empty is None else {"expected_sheets_empty": expected_empty}),
        # labels that fold to ONE sheet key — [{key, labels, domain}] — computed on every path, so
        # [] means "checked, none". A domain-resolving entry is fatal in main(): rows from both
        # labels would share domain:row item_ids and every citation to them is ambiguous.
        "sheet_key_collisions": sheet_key_collisions,
        # cells that are blank for a STRUCTURAL reason, per sheet: a formula with no cached result, a
        # merge that swallowed a column, a hidden row, a dropdown holding the value list. Empty for the
        # per-tab path, which has no such structure to lose.
        "workbook_structure": structure,
    }, "rows": rows}


def integrity_failures(data):
    """Reasons this extraction must not be used to GENERATE governed code, or [].

    THE DISTINCTION THIS DRAWS. Every item below is already reported — as a console warning, a
    finding, or a field in the artifact — and reporting was the right default while the pipeline's
    job was discovery: a person reads the warning, judges it, and proceeds. It is the wrong default
    the moment the extraction becomes the input to generated configuration, because then "reported
    and nobody acted" and "nothing to report" produce the same code.

    So this is a MODE, not a new severity. Discovery keeps the warnings. `--strict` refuses.

    Each entry names a way the extraction's MEANING is unstable, not merely untidy:

      positional      a requirement row whose variable came from cell position. Reordering a column
                      in the workbook then renames the requirement, silently, and the generated
                      config changes meaning with no diff anywhere that a reviewer reads.
      expected_empty  a sheet the shared map calls requirement-bearing that yielded zero rows. The
                      branch that added this made it a finding; a finding nothing fails on is how a
                      lost tab reaches a contract. Absence is the whole defect.
      unresolved      a requirement tab that resolves no variable or definition column at all — the
                      rows exist and nothing on them is addressable as a rule.
      unclassified    a sheet in neither half of the shared map nor the pack's IGNORE. Reachable
                      here only under --allow-unclassified, which is exactly the combination that
                      must not generate: "extract anyway" is a discovery decision.

    Merged ranges are deliberately NOT here. `workbook_structure` reports them and `spec_lint` ranks
    them HIGH, but a merge that swallowed nothing is common and harmless in real workbooks, and a
    strict mode that refuses every banner would be switched off within a week — which costs more
    than the four it would catch.
    """
    e = data.get("extraction") or {}
    out = []
    pos = e.get("variable_by_position_rows") or []
    if pos:
        where = ", ".join(f"{c['tab']}:{c['row']}" for c in pos[:8])
        out.append(finding("workbook_positional_columns", f"{len(pos)} requirement row(s) took the variable from CELL POSITION rather than a "
                   f"named column ({where}{' ...' if len(pos) > 8 else ''}) — a reordered column would "
                   f"silently rename the requirement. Name the column in COLUMN_RULES, or record an "
                   f"explicit per-sheet mapping, before generating from this extraction."))
    empty = e.get("expected_sheets_empty")
    if empty:
        out.append(finding("workbook_empty_requirement_sheet", f"requirement-bearing sheet(s) that produced ZERO rows: {', '.join(empty)} — the "
                   f"shared map says they carry requirements and the extraction has none from them"))
    for u in e.get("columns_unresolved") or []:
        out.append(finding("workbook_columns_unresolved", f"tab {u['tab']!r} resolves no {' or '.join(u['missing'])} column — its rows carry "
                   f"nothing addressable as a rule", sheet=u['tab']))
    if e.get("unclassified_tabs"):
        out.append(finding("workbook_sheets_unclassified", f"unclassified sheet(s) {', '.join(e['unclassified_tabs'])} were extracted anyway "
                   f"under --allow-unclassified — 'proceed without classifying' is a discovery "
                   f"decision and cannot stand behind generated code"))
    # ALL collisions here, not only the domain-resolving ones main() already refuses: two ignored
    # twins collide harmlessly today, but governed mode is where "harmless today" is not a reason,
    # and a workbook carrying case/space twin labels is an authoring accident in every case.
    for c in e.get("sheet_key_collisions") or []:
        out.append(finding("workbook_sheet_labels_collide", f"sheet labels {', '.join(repr(l) for l in c['labels'])} fold to ONE key "
                   f"{c['key']!r}" + (f" (domain {c['domain']})" if c["domain"] else "") +
                   " — this pipeline cannot tell them apart, and rows from both would share "
                   "item ids. Rename a tab, or rule one out by IGNORE."))
    return out

def empty_extraction_error(target, data, listdir=os.listdir):
    """The message for an extraction that captured NOTHING, or None when it captured something.

    Zero rows is not an extraction — it is the extractor reporting that it read no specification, and
    it has to say so by failing. Left as a success it flowed the whole way down the pipeline: the lint
    found no defects in nothing, coverage listed nothing undispositioned, the scaffold wrote nought
    records, and `--check` then compared seven empty artifacts against seven identical empty artifacts
    and printed `OK — all 7 generated artifacts are current`. Every step was truthful about its own
    input and the sequence was a green light over an empty folder.

    Here rather than in the runner because the CLI is the one boundary every caller crosses —
    run_spec_pipeline, and the six by-hand PowerShell calls in START_HERE.md §4 that exist precisely
    for the machine that cannot run the runner. `extract()` itself stays a pure function so a caller
    testing a fixture tab can still ask it about an empty one.
    """
    if data["extraction"]["row_count"]:
        return None
    if not os.path.isdir(target):
        return (f"{target}: read 0 requirement rows. The workbook opened, so this is not a missing "
                f"file — no sheet in it yielded rows. Check the sheet names against "
                f"governance/spec_sheet_map.yaml.")
    names = sorted(listdir(target))
    mds = [n for n in names if n.endswith(".md")]
    nested = [d for d in ("prog_spec", os.path.join("ref", "prog_spec"), "Program Specification")
              if os.path.isdir(os.path.join(target, d))]
    if nested:
        return (f"{target}: read 0 requirement rows from {os.path.join(target, nested[0])!r}. "
                f"Point the registered material at the spec folder itself, or put the specification "
                f"in that folder.")
    tsvs = [n for n in names if n.endswith(".tsv")]
    if mds:
        detail = (f"the {len(mds)} .md file(s) there ({', '.join(mds[:3])}"
                  f"{' ...' if len(mds) > 3 else ''}) carry no `|`-delimited requirement table")
    elif tsvs:
        detail = (f"the {len(tsvs)} .tsv file(s) there ({', '.join(tsvs[:3])}"
                  f"{' ...' if len(tsvs) > 3 else ''}) yielded no rows below a header — a tab needs a "
                  f"header line of three or more populated columns, then its rows")
    else:
        detail = (f"it holds no .md or .tsv files at all "
                  f"({len(names)} entr{'y' if len(names) == 1 else 'ies'})")
    return (f"{target}: read 0 requirement rows — {detail}. Put the specification workbook or its "
            f"spec tabs there and register the path in source_refs.yaml. A placeholder note "
            f"is not a specification.")


# A variable NAME as Science writes one: an uppercase-led token, no spaces, of the shape `AGEGR1N`,
# `HRR_INDEX_TESTN`, `TTNT`. Deliberately narrow. Prose in a cover page's first column ("Purpose",
# "Version") would match a looser rule, and a check that fires on every ignored sheet is a check
# people learn to skip.
VARIABLE_NAME = re.compile(r"^[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)*$")
# One or two variable-shaped cells is a heading or a stray mention. This is the count above which a
# sheet is claiming to be a variable list.
#
# Calibrated against the sheet the question is actually about. Ovarian's `9.PROC PSOC Strategy` — the
# one sheet any pack has ruled out by its own IGNORE — has 28 rows, 25 of which resolve a Variable
# column, and TWO of those hold a variable-shaped name. It is a strategy narrative that happens to
# have a Variable column, and the recorded ruling is right. Every other ignored sheet in that workbook
# resolves no Variable column at all. So the separation this threshold has to make is 2 against a real
# variable list's dozens, which is a wide gap rather than a fine judgement.
REQUIREMENT_SHAPED_MIN = 5


def requirement_shaped_ignored(rows, ignored):
    """[(tab, how many rows name a variable)] for IGNORED sheets that look like variable lists.

    The unclassified check protects one direction only. A sheet nobody classified is caught; a sheet
    classified WRONGLY is not, and it is the worse of the two: `requirement_rows` keeps only rows with
    a domain, so the linter never reads an ignored sheet, coverage never counts it, and the
    unclassified check excludes it by construction. One line in the shared `ignored:` map, or in a
    pack's IGNORE, takes a requirements tab out of scope permanently and nothing ever says so.

    Reported, never fatal. A ruling that a sheet is out of scope is a decision somebody made and
    recorded, and this does not overturn it — it puts the decision next to what it costs, which is
    what the unclassified message does for the other direction.

    Reads the sheet's OWN header, through the same resolver every other caller uses: a row counts
    only when its tab resolves a `variable` column and that cell holds a variable-shaped name. A
    positional guess would report every sheet whose first column happens to be short and uppercase.
    """
    out, by_tab = [], {}
    for r in rows:
        if r.get("domain") or sheet_key(r["tab"]) not in ignored:
            continue
        by_tab.setdefault(r["tab"], []).append(r)
    for tab, tab_rows in by_tab.items():
        named = sum(1 for r in tab_rows
                    if "variable" in (r.get("fields") or {})
                    and VARIABLE_NAME.match(str(r.get("variable") or "").strip()))
        if named >= REQUIREMENT_SHAPED_MIN:
            out.append((tab, named))
    return out


def unclassified_row_counts(data):
    """{unclassified tab: how many of its rows went unscanned}.

    The label alone does not say what skipping a sheet costs — an unclassified cover page and an
    unclassified 96-row requirements tab are the same string without the number.
    """
    tabs = set(data["extraction"].get("unclassified_tabs") or [])
    counts = {t: 0 for t in tabs}
    for r in data.get("rows", []):
        if r["tab"] in tabs:
            counts[r["tab"]] += 1
    return counts


def unclassified_error(data):
    """The message for an extraction that skipped a sheet nobody classified, or None when there is none.

    Fatal by default, which is the opposite of how this started. The warning was already printed — it
    was one line among the positional, header and skipped-sheet lines, and the reader who most needs it
    is the one running a new workbook for the first time, when every line is unfamiliar. A sheet in
    neither half of the map is the extractor saying it does not know whether it just dropped a cover
    page or a requirements tab, and continuing past that produces evidence whose scope nobody stated.

    The failure it prevents is not hypothetical and not cheap: one tab label the map spelled with an
    extra space took an entire domain out of an extraction, and the symptom appeared far downstream as
    records that would not resolve, naming nothing that led back to the cause.

    `--allow-unclassified` still exists, because ruling on the sheets is sometimes the very next step
    and being unable to look at the rows first is its own trap. It is an explicit argument on the
    command line, which is the difference that matters: the scope gap is then something a person chose,
    and it is in the shell history.
    """
    tabs = data["extraction"].get("unclassified_tabs") or []
    if not tabs:
        return None
    # Counted from `rows` rather than stored beside the labels. The count is a fact the rows already
    # carry, and a stored second copy is one more thing that can disagree with them.
    counts = unclassified_row_counts(data)
    lines = [f"  {t!r}: {counts.get(t, 0)} row(s) NOT scanned" for t in tabs]
    return ("UNCLASSIFIED SHEET(S) — the extraction skipped them and cannot say whether that was "
            "right:\n" + "\n".join(lines) + "\n\n"
            "A sheet must be classified by one of three files before its rows count as out of scope:\n"
            "  governance/spec_sheet_map.yaml  `sheets:`   Science ships it across products and it carries "
            "requirements\n"
            "  governance/spec_sheet_map.yaml  `ignored:`  Science ships it across products and it carries "
            "none\n"
            "  <pack>/spec_pipeline/pipeline.conf  IGNORE   only this workbook ships it\n\n"
            "Labels are matched with case folded and ALL whitespace removed, so a spacing difference "
            "is not the cause here — the label is genuinely absent from all three.\n"
            "Pass --allow-unclassified to extract anyway; the sheets stay unscanned and the artifact "
            "records which ones.")


def main(argv):
    ap = argparse.ArgumentParser(description="Extract an Science program spec into structured rows.")
    ap.add_argument("target", help="the spec directory (or a pack dir: prog_spec/, ref/prog_spec/, Program Specification/), or a single .xlsx workbook or .tsv tab")
    ap.add_argument("--out", help="write JSON here (default stdout)")
    ap.add_argument("--domains", help="sheet=domain,... OVERRIDES on top of governance/spec_sheet_map.yaml "
                                      "(normally empty — the shared map already covers Science's sheets)")
    ap.add_argument("--column-map", default="", help="Product-local JSON mapping worksheet header rows and canonical fields to Excel columns")
    ap.add_argument("--ignore", help="sheet,... this PRODUCT declares carry no requirements — for a "
                                     "sheet only this workbook ships. A sheet Science ships across "
                                     "products belongs in the shared map's `ignored:` instead")
    ap.add_argument("--allow-unclassified", action="store_true",
                    help="extract even though a sheet is in neither half of the shared map nor this "
                         "pack's IGNORE. Its rows stay unscanned — this states that is intended")
    ap.add_argument("--strict", action="store_true",
                    help="GOVERNED MODE: exit non-zero if anything makes this extraction's meaning "
                         "unstable — a variable read from cell position, a requirement sheet that "
                         "produced no rows, a tab with no resolvable variable/definition column, or "
                         "a sheet extracted unclassified. All of these are warnings by default, "
                         "which is right for discovery and wrong once the extraction generates code")
    a = ap.parse_args(argv)

    # Shared map first, then the product's own DOMAINS on top: a product overrides or extends the
    # repo-wide vocabulary, it does not have to restate it.
    domains = dict(shared_domains(), **parse_domains(a.domains))
    try:
        data = extract(a.target, domains, parse_ignore(a.ignore), parse_column_map(a.column_map))
    except (OSError, ValueError) as error:
        message = f"REFUSED — extraction was not written: {error}"
        print(message, file=sys.stderr)
        record_workflow_issues([finding("workbook_input_invalid", message)])
        return 1
    empty = empty_extraction_error(a.target, data)
    if empty:
        raise WorkflowRefusal([finding("workbook_empty", empty)])
    # FATAL, always, with NO bypass flag — unlike unclassified, where looking at the rows first is a
    # legitimate next step, there is no legitimate next step over two requirement tabs one key
    # cannot tell apart: every classification applies to both and their rows share item ids, so any
    # artifact written from this state carries ambiguous citations. The only fixes live in the
    # workbook (rename a tab) or the classification files (rule one out), never in a flag.
    _clash = [c for c in data["extraction"]["sheet_key_collisions"] if c["domain"]]
    if _clash:
        raise WorkflowRefusal([finding("workbook_sheet_labels_collide", "SHEET LABELS COLLIDE — two tabs fold to one sheet key, and their rows would "
                 "share `domain:row` item ids, so a citation to either could mean the other:\n"
                 + "\n".join(f"  {', '.join(repr(l) for l in c['labels'])} -> key {c['key']!r} "
                             f"(domain {c['domain']})" for c in _clash) + "\n\n"
                 "Labels are matched with case folded and ALL whitespace removed. Rename one tab in "
                 "the workbook, or declare one non-requirement (shared map `ignored:` or this "
                 "pack's IGNORE) so only one can produce rows.")])
    if not a.allow_unclassified:
        unclassified = unclassified_error(data)
        if unclassified:
            raise WorkflowRefusal([finding("workbook_sheets_unclassified", unclassified)])
    text = json.dumps(data, indent=1)
    if a.out:
        with open(a.out, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
        e = data["extraction"]
        print(f"extracted {e['row_count']} rows from {len(e['sources'])} source(s) -> {a.out}")
        for s in e["sources"]:
            print(f"   {s['tab']:<18} {s['rows']:>4} rows   sha {s['sha256']}   {s['file']}")
        # Reported over REQUIREMENT rows, because that is where a positional read can reach a contract
        # record. The whole-workbook ratio is in the artifact for anyone who wants it; on the console
        # it buried the number that decides anything under the cover and changelog sheets.
        req_n = e["requirement_row_count"]
        by_pos = sum(t["rows"] for t in e["variable_by_position_tabs"])
        print(f"   variable column resolved by header on {req_n - by_pos}/{req_n} requirement rows"
              f"   ({e['row_count'] - req_n} row(s) on non-requirement sheets, not scanned)")
        for t in e["variable_by_position_tabs"]:
            print(f"   POSITIONAL  tab {t['tab']!r}: {t['rows']} row(s) took the variable from cell "
                  f"position — its header names no column COLUMN_RULES recognises. A reordered column "
                  f"silently renames the requirement.")
            for c in e.get("variable_by_position_rows", []):
                if c["tab"] == t["tab"]:
                    print(f"                 row {c['row']}: {c['variable']!r}")
        for u in e.get("columns_unresolved", []):
            print(f"   WARNING  tab {u['tab']!r} resolves no {' or '.join(u['missing'])} column — "
                  f"this workbook names it something COLUMN_RULES does not know")
        if e.get("domains"):
            print("   domains: " + ", ".join(e["domains"]))
        ignored_tabs = [t for t in e.get("unmapped_tabs", []) if t not in e.get("unclassified_tabs", [])]
        if ignored_tabs:
            # The pack's own exclusions get a count, not a standing banner per sheet. A line repeated
            # on every run for a decision already recorded in pipeline.conf, DECISIONS.md and
            # extracted.json is noise, and noise is what teaches a reader to skim past the line above
            # it — which is the UNCLASSIFIED warning that actually needs acting on. The count keeps the
            # fact that a pack-level ruling exists visible without restating it.
            own = len(e.get("product_ignored_tabs", []))
            print(f"   skipped {len(ignored_tabs)} declared non-requirement sheet(s)"
                  + (f", {own} by this pack's IGNORE" if own else "") + ": "
                  + ", ".join(ignored_tabs[:4]) + (" ..." if len(ignored_tabs) > 4 else ""))
        # REPORTED, not stored. Every other line here restates a fact about the workbook;
        # this one is a judgement against a threshold, and freezing a judgement into the artifact
        # would mean that tuning the threshold changes bytes that sit under a recorded approval.
        # It is recomputable from the artifact — `unmapped_tabs` minus `unclassified_tabs` is the
        # ignored set — so nothing is lost by leaving it out.
        for tab, named in sorted(requirement_shaped_ignored(
                data["rows"], set(shared_sheet_map().get("ignored", {})) | parse_ignore(a.ignore)),
                key=lambda t: -t[1]):
            print(f"   IGNORED SHEET LOOKS LIKE A VARIABLE LIST  {tab!r}: {named} row(s) name a "
                  f"variable, and none of them is scanned. If that ruling is right, nothing to do — "
                  f"it is recorded. If it is not, this sheet's requirements are out of scope "
                  f"permanently and silently.")
        for tab in e.get("unclassified_tabs", []):
            # Only reachable under --allow-unclassified; without it the extraction has already failed.
            print(f"   UNCLASSIFIED SHEET  {tab!r} — {unclassified_row_counts(data).get(tab, 0)}"
                  f" row(s) NOT scanned. In neither half of governance/spec_sheet_map.yaml nor this "
                  f"pack's IGNORE, and --allow-unclassified said to proceed anyway.")
    else:
        sys.stdout.write(text)

    # LAST, and after the artifact is written. A strict refusal is about whether this extraction may
    # GENERATE, not about whether it could be produced — withholding the file would also withhold the
    # evidence naming what is wrong with it, and the person fixing a positional column needs to read
    # the rows it lists.
    if a.strict:
        bad = integrity_failures(data)
        if bad:
            sys.stderr.write("\nEXTRACTION IS NOT GOVERNED-MODE CLEAN — refusing under --strict.\n"
                             "Every item below is a warning in discovery mode; under --strict they "
                             "are refusals, because generated code cannot carry an unstable meaning:\n")
            for b in bad:
                sys.stderr.write(f"  ! {b}\n")
            record_workflow_issues(bad)
            return 1
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(workflow_main(main, sys.argv[1:], issuer="rwd_tools.spec_extract"))
