#!/usr/bin/env python3
"""Resolve every engine-coverage CLAIM to the code, config key, output and test behind it.

    python3 platform/tools/capability_registry.py            # validate + write CAPABILITIES.md
    python3 platform/tools/capability_registry.py --check     # validate + byte-compare, exit 1 on drift

WHY THIS EXISTS. `governance/reference/variable_inventory/INVENTORY.yaml` carries a `coverage:
{class, via}` on every variable, and `inventory_coverage.py` checks that claim for SHAPE only: a
class from the enum and a non-empty sentence. Nothing checked that the sentence was TRUE. An
external review found LINE_OF_THERAPY counted as `engine_family` when `stages/lot.py` only
normalises a table the vendor derived — a wrong claim that had passed every check in the repository,
because every check was reading the claim rather than the code. Re-classing that one entry fixed the
count and left the mechanism: the next wrong claim would be just as invisible.

`platform/capabilities.yaml` is the missing half. For each master family the inventory does NOT
class as a whole-family engine gap, it names the config key a pack authors, the Python and R symbols
that read it, the columns it publishes, and the tests that exercise it. This tool refuses the
registry unless every one of those RESOLVES:

  * the master family is a real entry in the inventory;
  * every non-gap coverage class the inventory assigns to that family is claimed by some capability,
    and no capability claims a class the inventory never assigns — so the two files cannot drift;
  * every named Python module exists and DEFINES the named symbol (AST, not import: a registry that
    had to import PySpark to check itself would be unrunnable in CI's pure-Python job);
  * every named R symbol is defined in the named R file;
  * every named test file exists and defines the named test;
  * the config key's leaf appears in the reading module — a config surface no engine code reads is
    exactly the contract-and-config-agree-while-the-engine-reads-neither failure this repo has
    already paid for once, and the check is cheap;
  * `upstream_required` capabilities name the table the VENDOR must deliver, and nothing else does;
  * every capability declares a VERIFICATION state PER ENGINE, and may only claim
    `component_parity` when it names a test that actually runs both engines.

VERIFICATION IS PER ENGINE, because the registry's first version was not and said something false.
It listed a Python symbol and an R symbol side by side and reported the capability as resolved — so
`clinical.comorbidity_index` read as implemented in both while R applied the supersedes hierarchy
sequentially and cast fractional weights to int, returning 4 where Python returned 3. Every registry
check passed. Naming a symbol is not evidence that it computes the same thing.

WHAT IT STILL DOES NOT DO. It proves the parts exist, that they are wired to each other, and — where
`component_parity` is claimed — that a named test compares what the two engines COMPILE or COMPUTE.
Shared stage fixtures exist; a stage claim must cite one declaring that family. This checks
evidence scope, not whether the declaration or expected clinical result is correct. It does
not prove the code is correct against clinical intent, that a test is a GOOD test, or that the
emitted column list is complete. A capability entry is a checked claim, not a verified one, and
CAPABILITIES.md says so in its header.
"""
from __future__ import annotations

import argparse
import ast
import sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
from rwd_services import workspace_root
REPO = workspace_root(__file__)
PLATFORM = REPO / "platform"
from rwd_services import package_asset
REGISTRY = PLATFORM / "capabilities.yaml"
if not REGISTRY.exists():
    REGISTRY = package_asset("platform/capabilities.yaml")
RENDER = PLATFORM / "CAPABILITIES.md"
INVENTORY = REPO / "governance" / "reference" / "variable_inventory" / "INVENTORY.yaml"

# The classes a capability can answer. `engine_gap` is deliberately absent: a gap is the ABSENCE of
# a capability, and an entry claiming to implement one would be a contradiction the registry should
# not be able to express.
SUPPORTABLE = ("engine_family", "config_expressible", "upstream_required")

# Where a config key is authored, by its first segment. `data_product` is the pack's ROOT config;
# every other prefix is a variables/ pack ROLE (the file stem engine/config.py::pack looks up).
ROOT_PREFIX = "data_product"
ROLES = ("demographics", "clinical", "treatment", "outcomes")

R_DEF = "{sym} <- function"

# HOW FAR EACH ENGINE HAS BEEN PROVEN for this capability, weakest first. A capability names one
# state per engine, and the state is a claim the tool checks what it can:
#
#   absent             this engine does not implement the capability at all
#   declared           the symbol exists; nothing here executes it
#   unit_tested        a named test exercises THIS engine's implementation
#   component_parity   a named test runs BOTH engines over the same input and compares what they
#                      COMPILE or COMPUTE — SQL strings, helper return values
#   stage_conformance  a named test runs a shared ROW FIXTURE through both engines' stages and
#                      compares the OUTPUT: values, nulls, types, schema, tie cases
#
# WHY THE TOP STATE WAS SPLIT. It used to be one state called `cross_engine_conformance`, described
# as "runs BOTH engines over the same input and compares" — and ten capabilities claimed it on
# evidence that compares helper FUNCTIONS. `test_r_parity.py` contains no Spark at all: it compares
# compiled SQL and function returns, which is real evidence and not the same evidence. The CI
# workflow header says so in its own words — it "does NOT execute the stage dataflow (the
# reads/joins/windows/aggregations), which is mirrored by convention + review, not run
# cross-engine" — so the registry was making a claim the workflow it depends on already disclaimed.
#
# `component_parity` is what the parity suite proves and is a genuine bar: it is what caught the
# CCI supersedes/weights divergence. `stage_conformance` was authored as deliberately UNREACHABLE --
# nothing claimed it, and nothing could until a shared-fixture harness existed and its R half had
# actually run. Both conditions are now met: the harness is `tests/test_stage_conformance.py`, and
# the CI R lane executed it green on 2026-08-30 with `--require-r` (13 of 13 cases, both engines
# executed), after which the operator flipped the families that cite it. A name that overstates its
# evidence is worse than a missing level, because it is the one a reader trusts -- which is why the
# gate below still refuses the claim from any entry that cites no test in STAGE_SUITE.
VERIFICATION = ("absent", "declared", "unit_tested", "component_parity", "stage_conformance")
# The suite that runs R against Python. A parity claim must cite a test in it.
CONFORMANCE_SUITE = "platform/tests/test_r_parity.py"

# The stage-conformance harness: one row fixture through BOTH engines' stages, canonical
# outputs diffed. A `stage_conformance` claim must cite a test here — and the state is
# FLIPPED BY A PERSON only after the CI R lane has EXECUTED that test green (--require-r);
# this tool cannot run R, so citing the test is the necessary condition it can check.
STAGE_SUITE = "platform/tests/test_stage_conformance.py"
# States that require a cited test in CONFORMANCE_SUITE.
PARITY_STATES = ("component_parity", "stage_conformance")


def _n_stage(caps) -> int:
    """How many capabilities claim `stage_conformance` on their R side.

    Computed, never asserted in prose. The legend used to end "and no family claims it yet",
    which was true when written and false the moment the operator flipped the families that cite
    the harness -- while the same document went on to print the count. A generated document that
    contradicts its own generated numbers is worse than a stale one: the reader cannot tell which
    half to believe.
    """
    return sum(1 for c in caps if (c.get("verification") or {}).get("r") == "stage_conformance")


def _strict_load(path: Path):
    """Through `strict_yaml`, which owns both the duplicate-key refusal AND the utf-8 read."""
    from engine.strict_yaml import strict_load_path                     # noqa: PLC0415
    return strict_load_path(path)


def load():
    return _strict_load(REGISTRY)


def inventory_classes(doc=None) -> dict:
    """{master family -> set of coverage classes the overlays assign it}."""
    if doc is None:
        doc = _strict_load(INVENTORY)
    out = {}
    for entry in (doc.get("tumours") or {}).values():
        for v in entry.get("variables") or []:
            if isinstance(v.get("master"), str):
                out.setdefault(v["master"], set()).add((v.get("coverage") or {}).get("class"))
    return out


def _defined_names(py: Path) -> set:
    """Module-level def / async def / class / assignment names in a Python file.

    AST, never import: engine/stages/*.py import PySpark at call time but the registry has to be
    checkable in CI's pure-Python job, where no Spark exists.
    """
    tree = ast.parse(py.read_text(encoding="utf-8"))
    names = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(node.name)
        elif isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name):
                    names.add(t.id)
    return names


def _referenced_names(py: Path) -> set:
    """Every string constant and attribute name anywhere in a Python file.

    Both, because a config key reaches the engine two ways: `clin_cfg.get("comorbidity_index")` (a
    string) and `cfg.study` (an attribute the Config class exposes). Reading only strings would
    report the root blocks as unread.
    """
    tree = ast.parse(py.read_text(encoding="utf-8"))
    out = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            out.add(node.value)
        elif isinstance(node, ast.Attribute):
            out.add(node.attr)
    return out


def _test_names(path: Path) -> set:
    return {n.name for n in ast.parse(path.read_text(encoding="utf-8")).body
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}


def _stage_families(tests):
    """The scope declared by cited row fixtures, never inferred from a shared symbol."""
    families = set()
    prefix = STAGE_SUITE + "::test_conformance_"
    for node in tests:
        if not isinstance(node, str) or not node.startswith(prefix):
            continue
        name = node[len(prefix):]
        if not name.isidentifier():
            continue
        path = REPO / "platform/tests/conformance" / (name + ".yaml")
        if path.is_file():
            fixture = _strict_load(path)
            if isinstance(fixture, dict) and isinstance(fixture.get("families"), list):
                families.update(value for value in fixture["families"] if isinstance(value, str))
    return families


def config_file_for(key: str) -> str | None:
    """The pack-relative file a dotted config key is authored in, or None if the prefix is unknown."""
    head = key.split(".", 1)[0]
    if head == ROOT_PREFIX:
        return "config/data_product.yaml"
    if head in ROLES:
        return f"variables/{head}.yaml"
    return None


def registry_errors(doc, inv_classes) -> list:
    out = []
    caps = doc.get("capabilities") or []
    if not caps:
        return ["capabilities.yaml declares no capabilities — an empty registry resolves every "
                "claim vacuously, which is the failure it exists to prevent"]

    seen_ids = set()
    claimed = {}                       # master -> set of classes some capability answers
    for cap in caps:
        cid = str(cap.get("id") or "").strip()
        if not cid:
            out.append("a capability has no id")
            continue
        if cid in seen_ids:
            out.append(f"{cid}: duplicate capability id")
        seen_ids.add(cid)

        master = str(cap.get("master") or "").strip()
        if master not in inv_classes:
            out.append(f"{cid}: master '{master}' is not a family any inventory overlay "
                       f"instantiates — a capability for nothing")
        supports = cap.get("supports") or []
        bad = [s for s in supports if s not in SUPPORTABLE]
        if bad or not supports:
            out.append(f"{cid}: supports {supports or '[]'} must be a non-empty subset of "
                       f"{list(SUPPORTABLE)}")
        else:
            claimed.setdefault(master, set()).update(supports)
        if not str(cap.get("summary") or "").strip():
            out.append(f"{cid}: empty summary")

        # --- upstream_required names the table the vendor must deliver ---------------------------
        up = str(cap.get("upstream_table") or "").strip()
        if "upstream_required" in supports and not up:
            out.append(f"{cid}: supports upstream_required but names no upstream_table — the whole "
                       f"point of the class is WHICH table the vendor must deliver")
        if up and "upstream_required" not in supports:
            out.append(f"{cid}: names upstream_table '{up}' without supporting upstream_required")

        # --- code resolves ------------------------------------------------------------------------
        py_names = set()
        pys = cap.get("python") or []
        if not pys:
            out.append(f"{cid}: no python implementation named")
        for impl in pys:
            rel = str(impl.get("module") or "")
            sym = str(impl.get("symbol") or "")
            path = REPO / rel
            if not path.exists():
                out.append(f"{cid}: python module {rel} does not exist")
                continue
            defined = _defined_names(path)
            if sym not in defined:
                out.append(f"{cid}: {rel} does not define '{sym}'")
            py_names |= _referenced_names(path)

        # NO PLACEHOLDERS (operator ruling, 2026-08-28): every capability the Python engine
        # executes must name its R implementation. A Python-only entry is a variable the R
        # engine silently does not compute — the R column read "—" for 13 families whose R
        # code had existed inline in clinical_build all along, and nothing demanded the claim.
        if pys and not (cap.get("r") or []):
            out.append(f"{cid}: python implementation named and no R implementation — the R "
                       f"engine holds parity for every capability Python executes; name the R "
                       f"symbol (inline loops live in clinical_build) or the entry is a "
                       f"placeholder this registry refuses")

        for impl in (cap.get("r") or []):
            rel = str(impl.get("file") or "")
            sym = str(impl.get("symbol") or "")
            path = REPO / rel
            if not path.exists():
                out.append(f"{cid}: R file {rel} does not exist")
                continue
            if R_DEF.format(sym=sym) not in path.read_text(encoding="utf-8"):
                out.append(f"{cid}: {rel} does not define '{sym}'")

        # --- config keys resolve, and the engine reads them ---------------------------------------
        keys = cap.get("config_keys") or []
        if not keys:
            out.append(f"{cid}: no config_keys — a capability nothing can be configured into is "
                       f"not reachable from a pack")
        for key in keys:
            if config_file_for(str(key)) is None:
                out.append(f"{cid}: config key '{key}' has no known home — the first segment must "
                           f"be '{ROOT_PREFIX}' or a pack role {list(ROLES)}")
                continue
            leaf = str(key).split(".")[-1]
            if py_names and leaf not in py_names:
                out.append(f"{cid}: no named python module mentions '{leaf}' — a config key no "
                           f"engine code reads is a block a pack can author, lint clean, and "
                           f"never get the variable from")

        # --- verification, PER ENGINE ---------------------------------------------------------------
        # The registry's first version reported a capability as resolved when a Python symbol and an
        # R symbol both existed. `clinical.comorbidity_index` passed every check while the two
        # engines returned different scores. A symbol is not a proof, so the claim is now explicit
        # and graded, and the strongest grade is checked against the suite that can support it.
        ver = cap.get("verification") or {}
        if not isinstance(ver, dict) or set(ver) != {"python", "r"}:
            out.append(f"{cid}: verification must name BOTH engines — "
                       f"{{python: <state>, r: <state>}} from {list(VERIFICATION)}. A capability "
                       f"that does not say how far each engine is proven is the claim that hid a "
                       f"live divergence")
        else:
            tests = cap.get("tests") or []
            for eng, state in sorted(ver.items()):
                if state not in VERIFICATION:
                    out.append(f"{cid}: verification.{eng} {state!r} not in {list(VERIFICATION)}")
                    continue
                if eng == "r" and state == "absent" and (cap.get("r") or []):
                    out.append(f"{cid}: verification.r is `absent` but an R symbol is named — "
                               f"either the R side exists or it does not")
                if eng == "r" and state != "absent" and not (cap.get("r") or []):
                    out.append(f"{cid}: verification.r is {state!r} with no R symbol named")
                if state == "component_parity" and \
                        not any(str(t).startswith(CONFORMANCE_SUITE) for t in tests):
                    out.append(f"{cid}: claims {state} for {eng} but cites no test "
                               f"in {CONFORMANCE_SUITE} — the only suite that compares what the "
                               f"two engines COMPILE over the same input. A same-language unit "
                               f"test cannot detect the divergence this state rules out")
                # `stage_conformance` is earned by the harness that runs one row fixture through
                # BOTH engines' stages — the claim must cite its test, and the state is flipped
                # by a person only after the CI R lane has EXECUTED that test green. Citing the
                # test is the necessary condition this tool can check without an R runtime.
                if state == "stage_conformance" and \
                        not any(str(t).startswith(STAGE_SUITE) for t in tests):
                    out.append(f"{cid}: claims stage_conformance for {eng} but cites no test in "
                               f"{STAGE_SUITE} — the only suite that runs a shared row fixture "
                               f"through both engines' stages and diffs the outputs. The state "
                               f"is a claim about THAT evidence, executed green, or it is the "
                               f"renaming this refusal exists to stop")
                elif state == "stage_conformance" and master not in _stage_families(tests):
                    out.append(f"{cid}: claims stage_conformance for {eng}, but no cited row fixture "
                               f"declares family {master}. Shared engine machinery does not establish "
                               "family-specific output conformance; retain a weaker verification state.")
            if ver.get("python") == "absent":
                out.append(f"{cid}: verification.python is `absent` — the Python engine is the one "
                           f"that builds every product, so a capability it does not implement is "
                           f"an engine gap, not a capability")

        # --- outputs and tests --------------------------------------------------------------------
        if not (cap.get("emits") or []):
            out.append(f"{cid}: emits nothing — name the published columns, or the capability "
                       f"cannot be checked against an ADS")
        tests = cap.get("tests") or []
        if not tests:
            out.append(f"{cid}: names no test")
        for node in tests:
            rel, _, tname = str(node).partition("::")
            path = REPO / rel
            if not path.exists():
                out.append(f"{cid}: test file {rel} does not exist")
            elif not tname:
                out.append(f"{cid}: test '{node}' names no test function")
            elif tname not in _test_names(path):
                out.append(f"{cid}: {rel} does not define '{tname}'")

    # --- the two files agree, in BOTH directions -------------------------------------------------
    for master, classes in sorted(inv_classes.items()):
        wanted = {c for c in classes if c in SUPPORTABLE}
        if not wanted:
            continue                                   # whole-family engine gap: no capability owed
        got = claimed.get(master, set())
        missing = wanted - got
        extra = got - wanted
        if missing:
            out.append(f"{master}: the inventory claims {sorted(missing)} but no capability answers "
                       f"it — either add the capability or re-class the variables")
        if extra:
            out.append(f"{master}: capabilities claim {sorted(extra)} that no inventory variable "
                       f"asks for")
    for master in sorted(set(claimed) - set(inv_classes)):
        out.append(f"{master}: capabilities exist for a family the inventory does not instantiate")
    from rwd_tools.review_capability_registry import errors as review_errors
    out.extend(review_errors(doc, root=REPO))
    return out


def render_md(doc, inv_classes) -> str:
    caps = doc.get("capabilities") or []
    lines = [
        "# Platform capabilities — what each coverage claim resolves to",
        "",
        "**GENERATED from `platform/capabilities.yaml` by `platform/tools/capability_registry.py`",
        "— edit the registry, then regenerate. `--check` refuses a stale copy.**",
        "",
        "`governance/reference/variable_inventory/COVERAGE.md` says which CLASS a variable's",
        "coverage falls in. This file says what that class RESOLVES to: the config key a pack",
        "authors, the engine symbols that read it, the columns it publishes and the tests that",
        "exercise it. The registry tool refuses any entry whose module, symbol, config key, output",
        "or test does not resolve, and refuses the pair of files if they disagree about which",
        "classes a family answers.",
        "",
        "**A capability entry is a CHECKED claim, not a verified one.** Every part is proven to",
        "exist and to be wired to the others. Nothing here proves the code is correct against",
        "clinical intent, that the named test is a good test, or that `emits` lists every column the",
        "family publishes.",
        "These are historical verification declarations. Generating this registry does not run",
        "Python, R or Spark. For the current branch and configuration, inspect the current implementation runtime receipt:",
        "its selected tests, versions, pass/fail/skip counts and actual R comparison markers determine what executed.",
        "This registry indexes inventory master families, not every engine stage or module. An unlisted stage has no readiness claim here.",
        "Tests of shared machinery do not establish each clinical family's configured output. See the individual limits below.",
        "",
        "**Verification is stated PER ENGINE, because this file's first version was not and said",
        "something false.** It listed a Python symbol and an R symbol side by side and reported the",
        "capability resolved — so `clinical.comorbidity_index` read as implemented in both while R",
        "applied the supersedes hierarchy sequentially and truncated fractional weights, returning 4",
        "where Python returned 3. Naming a symbol is not evidence that it computes the same thing.",
        "",
        "| state | meaning |",
        "|---|---|",
        "| `absent` | this engine does not implement the capability |",
        "| `declared` | the symbol exists; no family-specific execution claim is recorded |",
        "| `unit_tested` | a named test exercises THIS engine's implementation |",
        "| `component_parity` | a named test runs BOTH engines over the same input and compares "
        "what they COMPILE or COMPUTE (SQL strings, helper returns) |",
        "| `stage_conformance` | a shared ROW FIXTURE run through both engines' stages, outputs "
        "compared cell-by-cell. The harness is `platform/tests/test_stage_conformance.py` + "
        "`conformance/*.yaml` (one parsed fixture feeds both engines; the R half runs under "
        "sparklyr and SKIPS LOUDLY where R is absent). **A family may claim this state only "
        "after the R half has EXECUTED green** — a skip is not a pass. "
        + (f"{_n_stage(caps)} of {len(caps)} capabilities claim it |" if _n_stage(caps)
           else "No family claims it yet |"),
        "",
        f"| family | classes | config key | python | R | declared verification (py / R) | tests |",
        "|---|---|---|---|---|---|---|",
    ]
    for cap in sorted(caps, key=lambda c: (c.get("master", ""), c.get("id", ""))):
        keys = ", ".join(f"`{k}`" for k in (cap.get("config_keys") or []))
        py = ", ".join(f"`{i['symbol']}`" for i in (cap.get("python") or []))
        r = ", ".join(f"`{i['symbol']}`" for i in (cap.get("r") or [])) or "—"
        classes = ", ".join(sorted(cap.get("supports") or []))
        v = cap.get("verification") or {}
        short = {"stage_conformance": "stage", "component_parity": "component", "unit_tested": "unit",
                 "declared": "**declared only**", "absent": "—"}
        ver = f"{short.get(v.get('python'), '?')} / {short.get(v.get('r'), '?')}"
        lines.append(f"| **{cap.get('master')}** | {classes} | {keys} | {py} | {r} | {ver} | "
                     f"{len(cap.get('tests') or [])} |")

    n_conf = sum(1 for c in caps if (c.get("verification") or {}).get("r")
                 in PARITY_STATES)
    n_decl = sum(1 for c in caps if (c.get("verification") or {}).get("r") == "declared")
    lines += ["",
              f"**{n_decl} of {len(caps)} capabilities declare no family-specific R execution evidence** "
              f"(`declared only`). Tests may execute their shared R symbols for other families; that "
              f"does not establish these families' configured outputs. Review each entry's limits and "
              f"the actual runtime receipts before using a result. {n_conf} cite component or stage comparisons."]
    lines += ["", "## Per capability", ""]
    for cap in sorted(caps, key=lambda c: (c.get("master", ""), c.get("id", ""))):
        lines.append(f"### `{cap.get('id')}` — {cap.get('master')}")
        lines.append("")
        lines.append(cap.get("summary", "").strip())
        lines.append("")
        if cap.get("upstream_table"):
            lines.append(f"- **UPSTREAM REQUIRED** — the vendor must deliver `"
                         f"{cap['upstream_table']}`; the engine does not build it.")
        for key in (cap.get("config_keys") or []):
            lines.append(f"- config `{key}` — authored in `{config_file_for(key)}`")
        for impl in (cap.get("python") or []):
            lines.append(f"- python `{impl['symbol']}` in `{impl['module']}`")
        for impl in (cap.get("r") or []):
            lines.append(f"- R `{impl['symbol']}` in `{impl['file']}`")
        lines.append(f"- emits {', '.join('`' + e + '`' for e in (cap.get('emits') or []))}")
        for node in (cap.get("tests") or []):
            lines.append(f"- test `{node}`")
        if cap.get("limits"):
            lines.append(f"- **limits** — {cap['limits'].strip()}")
        lines.append("")

    gaps = sorted(m for m, cs in inv_classes.items() if not {c for c in cs if c in SUPPORTABLE})
    lines += [
        "## Families with no capability",
        "",
        ("Every master family the inventory instantiates has a capability entry."
         if not gaps else
         "These families are classed `engine_gap` in every overlay that instantiates them, so no "
         "capability is owed — see COVERAGE.md for what each one needs:"),
        "",
    ]
    for m in gaps:
        lines.append(f"- **{m}**")
    return "\n".join(lines).rstrip() + "\n"


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true",
                    help="validate and byte-compare CAPABILITIES.md; exit 1 on any problem or drift")
    a = ap.parse_args(argv)
    doc = load()
    inv = inventory_classes()
    errors = registry_errors(doc, inv)
    if errors:
        for e in errors:
            print(f"  FAIL {e}")
        return 1
    want = render_md(doc, inv)
    if a.check:
        have = RENDER.read_text(encoding="utf-8") if RENDER.exists() else None
        if have != want:
            print("DRIFT — CAPABILITIES.md is stale; regenerate with: "
                  "python3 platform/tools/capability_registry.py")
            return 1
        print(f"current — {len(doc['capabilities'])} capabilities resolve and CAPABILITIES.md "
              f"matches")
        return 0
    RENDER.write_text(want, encoding="utf-8", newline="\n")
    print(f"OK — {len(doc['capabilities'])} capabilities resolve; wrote {RENDER}")
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main(sys.argv[1:]))
