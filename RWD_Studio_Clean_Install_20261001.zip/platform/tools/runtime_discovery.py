"""Read-only discovery shared by local runtime consumers; standard library only."""
from __future__ import annotations

import os
from pathlib import Path
import re
import shutil
import sys

# OSS lanes are compatibility experiments, not replicas of the managed build.
PROFILES = {
    "local-spark4": {"python": "3.13", "pyspark": "4.0.4", "java": "17",
        "kind": "oss", "notice": "Local maintenance lane; not the deployment runtime."},
    "dbr154-oss": {"python": "3.11.11", "pyspark": "3.5.0", "java": "17",
        "kind": "oss", "deployment_target": "Databricks Runtime 15.4 LTS",
        "notice": "OSS Spark/Python compatibility only. Managed Databricks patches, Linux, Java8, Photon, Unity Catalog and cloud permissions are not reproduced."},
    "dbr154-oss-java8": {"python": "3.11.11", "pyspark": "3.5.0", "java": "8",
        "java_version": "1.8.0_412", "java_vendor": "Azul Systems, Inc.",
        "java_runtime_version": "1.8.0_412-b08", "java_vm_version_prefix": "25.412-b08",
        "kind": "oss", "deployment_target": "Databricks Runtime 15.4 LTS",
        "notice": "OSS Spark/Python/Zulu version compatibility only. Managed Databricks patches, Linux, Photon, Unity Catalog and cloud permissions are not reproduced."},
}


def runtime_profile(name, *, spark=None):
    """Inspect exact installed versions without starting a JVM or changing defaults."""
    from importlib import metadata
    import platform
    if name not in PROFILES:
        raise ValueError("Choose a declared runtime profile: " + ", ".join(PROFILES))
    expected = dict(PROFILES[name])
    actual = {"python": platform.python_version(), "os": platform.system(),
              "executable": sys.executable}
    for module in ("pyspark", "delta-spark", "numpy", "pandas", "pyarrow", "sqlglot"):
        try:
            actual[module] = metadata.version(module)
        except metadata.PackageNotFoundError:
            actual[module] = None
    errors = []
    python = expected["python"]
    if not (actual["python"] == python or (python.count(".") == 1 and actual["python"].startswith(python + "."))):
        errors.append(f"Profile {name} requires Python {python}; found {actual['python']}.")
    if actual["pyspark"] != expected["pyspark"]:
        errors.append(f"Profile {name} requires PySpark {expected['pyspark']}; found {actual['pyspark']}.")
    if spark is not None:
        actual.update(spark=spark.version, master=spark.sparkContext.master,
                      java=spark.sparkContext._jvm.java.lang.System.getProperty("java.version"),
                      java_vendor=spark.sparkContext._jvm.java.lang.System.getProperty("java.vendor"),
                      java_runtime_version=spark.sparkContext._jvm.java.lang.System.getProperty("java.runtime.version"),
                      java_vm_version=spark.sparkContext._jvm.java.lang.System.getProperty("java.vm.version"))
        if actual["spark"] != expected["pyspark"]:
            errors.append("The active Spark session differs from the selected installed runtime.")
        java_major = actual["java"].split('.')[1] if actual['java'].startswith('1.') else actual['java'].split('.')[0]
        if java_major != expected["java"]:
            errors.append(f"This OSS lane requires Java {expected['java']}; found {actual['java']}.")
        for key, actual_key in (("java_version", "java"), ("java_vendor", "java_vendor"),
                                ("java_runtime_version", "java_runtime_version")):
            if key in expected and actual[actual_key] != expected[key]:
                errors.append(f"This OSS lane requires {key} {expected[key]}; found {actual[actual_key]}.")
        if expected.get('java_vm_version_prefix') and not actual['java_vm_version'].startswith(expected['java_vm_version_prefix']):
            errors.append('The active Java VM build differs from the declared compatibility profile.')
    return {"schema_version": 1, "profile": name, "expected": expected, "actual": actual,
            "status": "mismatch" if errors else "matched", "errors": errors,
            "spark_executed": spark is not None, "managed_databricks_verified": False}


def require_r():
    """The existing conformance switch also requires R in shared parity checks."""
    return (os.environ.get("RWDP_CONFORMANCE_REQUIRE_R") == "1"
            or os.environ.get("RWDP_REQUIRE_R") == "1" or "--require-r" in sys.argv)


def find_rscript():
    """Locate an existing R executable without executing it or changing settings."""
    direct = shutil.which("Rscript")
    if direct:
        return direct
    roots = []
    if os.environ.get("R_HOME"):
        roots.append(Path(os.environ["R_HOME"]))
    local = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData/Local")
    for parent in (local / "RwdPortal/R", local / "Programs/R", Path(os.environ.get("ProgramFiles", "C:/Program Files")) / "R"):
        if parent.is_dir():
            roots.extend(sorted(parent.glob("R-*"), key=lambda p: tuple(int(n) for n in re.findall(r"\d+", p.name)), reverse=True))
    for home in roots:
        for relative in ("bin/Rscript.exe", "bin/x64/Rscript.exe", "bin/Rscript"):
            path = home / relative
            if path.is_file():
                return str(path)
    return None
