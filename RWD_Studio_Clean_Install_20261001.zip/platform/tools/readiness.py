"""Five verdicts about one pack, reported separately and never collapsed into one.

WHY FIVE AND NOT ONE. A UAT of this repository found that individual commands can each look green
for different reasons, and that a reader assembling them by hand reaches a conclusion no single
tool stated. The opposite failure is worse: a single OVERALL verdict would have to pick one of five
incompatible questions to answer, and whichever it picked, the other four would be read as having
been answered too. `--list-config-declared` was renamed for exactly that reason — a name that
implied buildability while meaning "declares a configuration".

So this prints five, always, side by side:

  STRUCTURAL   do the generated artefacts still re-derive, and does the contract parse and lint?
               A machine question with a machine answer. It can be green on a pack nobody has
               approved, and that is not a contradiction - it means the plumbing is sound.

  STAKEHOLDER  have the named human acts happened - an approved specification, approved
               requirements, answered decisions, an approved configuration, a signed meaning?
               This is the one that gates everything downstream and the one no tool can advance.

  EXECUTABLE   are the declared requirements accounted for and their calculations configured,
               with strict native validation and specification/configuration comparisons?

  SEMANTIC     is the meaning declared, signed and exportable, or merely proposed?

  RELEASE      the six gates, through `releasable()`. Derived from the four above plus the
               implementation axis; never stored.

WHAT A GREEN IN ONE DOES NOT MEAN. Structural green says the artefacts are current, not that the
product is right. Executable green covers configuration checks; source connectivity, runtime
execution and scientific approval still require their own evidence.
Only RELEASE speaks to whether a governed cut may be published, and it is the last line for that
reason.

NOTHING HERE IS A GATE. Every verdict is read from the module that owns it, so this tool cannot
disagree with `status.py`, `product_gates` or `releasable()` - if it ever does, it is wrong and
they are right. It exists to put five answers on one page without merging them.
"""
from __future__ import annotations

import argparse
import os
import sys


from rwd_tools.spec_extract import repo_relative                                  # noqa: E402

from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))

# A verdict is one of these, and `nothing_to_check` is a real answer rather than a polite zero:
# a pack with no contract has no structural claim to verify, and reporting that as `pass` is the
# absence-reads-as-clean failure this repository keeps finding in its own tools.
VERDICTS = ("pass", "blocked", "not_started", "nothing_to_check", "unreadable")


def _v(state, reasons):
    return {"verdict": state, "reasons": list(reasons)}


def structural(root, pack):
    """Do the generated artefacts re-derive, and does the contract lint?"""
    from rwd_tools import contract_lint                                                  # noqa: PLC0415
    rel = repo_relative(pack, root)
    contract = os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(contract):
        return _v("nothing_to_check",
                  [f"{rel}: no handoff/FUNCTIONAL_CONTRACT.md — nothing has been traced from a "
                   f"specification, so there is no structure to verify"])
    try:
        # `run` returns (errors, record_count) - unpacked, because treating the TUPLE as a list of
        # errors printed "[]" and "202" as though they were two findings.
        errs, records = contract_lint.run(pack)
    except Exception as exc:                     # noqa: BLE001 - unreadable IS the verdict
        return _v("unreadable", [f"{rel}: contract could not be linted ({type(exc).__name__}: {exc})"])
    if errs:
        return _v("blocked", [str(e) for e in errs][:8])
    return _v("pass", [f"{records} record(s), every invariant passes — the plumbing is sound, "
                       f"which is a different question from whether anybody approved it"])


def stakeholder(root, pack):
    """The human acts. This is the verdict no tool can advance."""
    from rwd_tools import product_gates as pg                                            # noqa: PLC0415
    from rwd_tools import source_manifest as sm                                          # noqa: PLC0415
    rel = repo_relative(pack, root)
    m = pg.maturity(pack)
    why = []
    src = sm.source_status(pack)
    if src != "approved":
        why.append(f"specification is {src or 'unregistered'!r}, not `approved`")
    if str(m.get("contract")) != "approved":
        why.append(f"contract is {m.get('contract')!r}, not `approved`")
    if str(m.get("configuration")) != "approved":
        why.append(f"configuration is {m.get('configuration')!r}, not `approved`")
    # ...AND THE UNATTRIBUTED ANSWERS, which are not visible in any maturity word. A RESOLVED
    # decision with nobody behind it is an answer the register cannot attribute to a person.
    by_dec = pg.unaccountable_resolutions(pack, rel, by_decision=True)
    if by_dec:
        why.append(f"{len(by_dec)} RESOLVED decision(s) with nobody recorded behind them: "
                   f"{', '.join(sorted(by_dec))}")
    approval = os.path.join(pack, *pg.SEMANTIC_APPROVAL.split("/"))
    stated = pg.semantic_approval_errors(pack, rel)
    if stated:
        why += [f"semantic approval: {e}" for e in stated[:3]]
    elif not os.path.exists(approval):
        why.append("no semantic approval — nobody has signed for what this product's variables mean "
                   "(which is correct while it binds nothing)")
    if not why:
        return _v("pass", [])
    return _v("blocked" if src or m.get("contract") != "not_started" else "not_started", why)


def executable(root, pack):
    """Read executable completeness from the same service used before approval."""
    from rwd_tools import product_gates
    rel = repo_relative(pack, root)
    cfgdir = os.path.join(pack, "config")
    if not os.path.isdir(cfgdir):
        return _v("nothing_to_check", [f"{rel}: no config/ — nothing to run"])
    try:
        errors = product_gates.configuration_execution_errors(pack, rel)
    except Exception as exc:  # An unavailable check cannot report successful execution readiness.
        return _v("unreadable", [f"{rel}: configuration completeness could not be read ({type(exc).__name__})."])
    if errors:
        return _v("blocked", [str(error) for error in errors])
    return _v("pass", ["Configured requirements passed the execution checks. Source connectivity, "
                       "an actual build and scientific approval need their own evidence."])


def semantic(root, pack):
    """Is the meaning declared and signed, or proposed?"""
    from rwd_tools import semantic_binding as sb                                         # noqa: PLC0415
    rel = repo_relative(pack, root)
    try:
        r = sb.report(pack)
    except Exception as exc:                     # noqa: BLE001
        return _v("unreadable", [f"{rel}: {type(exc).__name__}: {exc}"])
    if not r.get("variables_declared"):
        return _v("nothing_to_check",
                  [f"{rel}: declares no governed variables, so no binding was examined"])
    errs = sb.errors(pack)
    why = [str(e) for e in errs][:6]
    if not r.get("variables_bound"):
        why.append(f"0 of {r['variables_declared']} variables are bound — the meaning is proposed, "
                   f"not stated")
    return _v("pass" if not why else "blocked", why)


def release(root, pack):
    """The six gates, through their owner."""
    from rwd_tools import source_manifest as sm                                          # noqa: PLC0415
    rel = repo_relative(pack, root)
    ok, why = sm.releasable(root, rel)
    return _v("pass" if ok else "blocked", [str(w) for w in why][:8])


LENSES = (("STRUCTURAL", structural), ("STAKEHOLDER", stakeholder), ("EXECUTABLE", executable),
          ("SEMANTIC", semantic), ("RELEASE", release))


def assess(root, pack):
    """{lens: {verdict, reasons}} — five answers, never merged."""
    return {name: fn(root, pack) for name, fn in LENSES}


def render(root, pack, full=False):
    rel = repo_relative(pack, root)
    L = ["=" * 78, f"  READINESS — {rel}", "=" * 78,
         "  Five separate questions. A pass in one says nothing about the others; only RELEASE",
         "  speaks to whether a governed cut may be published.", ""]
    got = assess(root, pack)
    for name, _fn in LENSES:
        r = got[name]
        L.append(f"  {name:<12} {r['verdict'].upper()}")
        for reason in (r["reasons"] if full else r["reasons"][:3]):
            for i, line in enumerate(_wrap(reason)):
                L.append(("      · " if i == 0 else "        ") + line)
        if not full and len(r["reasons"]) > 3:
            L.append(f"      … and {len(r['reasons']) - 3} more (--full)")
        L.append("")
    L.append("  No overall verdict is printed, deliberately: whichever of these five it chose to")
    L.append("  answer, the other four would be read as answered too.")
    return "\n".join(L)


def _wrap(text, width=66):
    words, line, out = str(text).split(), "", []
    for w in words:
        if len(line) + len(w) + 1 > width:
            out.append(line)
            line = w
        else:
            line = (line + " " + w).strip()
    if line:
        out.append(line)
    return out or [""]


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("pack", nargs="?")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--full", action="store_true", help="every reason, not the first three")
    ap.add_argument("--json", metavar="PATH")
    a = ap.parse_args(argv)

    from rwd_tools import product_gates as pg                                            # noqa: PLC0415
    if a.all or not a.pack:
        packs = [os.path.join(ROOT, r) for r in pg.all_packs(ROOT)]
    else:
        p = a.pack if os.path.isabs(a.pack) else os.path.join(ROOT, a.pack)
        if not os.path.isdir(p):
            sys.exit(f"{a.pack}: no such product directory. Nothing was assessed — this is a "
                     f"refusal, not a clean result.")
        packs = [p]

    out = {}
    for p in packs:
        out[repo_relative(p, ROOT)] = assess(ROOT, p)
        print(render(ROOT, p, full=a.full))
    if a.json:
        import json                                                       # noqa: PLC0415
        with open(a.json, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(out, fh, indent=1, ensure_ascii=False)
        print(f"wrote {a.json}")
    # EXIT 0 WHATEVER THE VERDICTS. This reports; it does not gate. `product_gates --check-maturity`
    # and `source_manifest --check` are the gates, and a second thing exiting non-zero on the same
    # facts would be a gate nobody declared.
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    raise SystemExit(main())
