"""Find the Java runtime a local Spark needs, without any system setting (2026-09-07).

The synthetic build (local_smoke.py) runs an in-process Spark, which needs a JDK 17 or 21. A
person's laptop rarely has one on PATH, and the portal must never change PATH or the registry. So
the JDK may live in the person's own application-data folder, unpacked there once
(``%LOCALAPPDATA%\\RwdPortal\\jdk\\jdk-17...``), and this module finds it: JAVA_HOME when it is set
and valid, else ``java`` on PATH (pyspark finds it itself), else the newest JDK under that folder.
``ensure()`` exports JAVA_HOME into this process for the build; nothing outside the process changes.
"""
from __future__ import annotations

import os
import re
import shutil
from pathlib import Path

_VERSION = re.compile(r"jdk-?(\d+)")


def user_jdk_dir():
    base = ((os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Local"))
            if os.name == "nt" else
            (os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share")))
    return Path(base) / "RwdPortal" / "jdk"


def _valid(home):
    if not home:
        return False
    java = Path(home) / "bin" / ("java.exe" if os.name == "nt" else "java")
    return java.is_file()


def _candidates(folder):
    try:
        entries = [p for p in Path(folder).iterdir() if p.is_dir() and _valid(p)]
    except OSError:
        return []

    def version(path):
        m = _VERSION.search(path.name)
        return int(m.group(1)) if m else 0
    return sorted(entries, key=version, reverse=True)


def discover(folder=None):
    """The JAVA_HOME to use, or "" when none is known. The environment's own setting wins; a java on
    PATH needs no JAVA_HOME; else the newest JDK unpacked under the user folder."""
    env = os.environ.get("JAVA_HOME", "")
    if _valid(env):
        return str(Path(env))
    if shutil.which("java"):
        return ""
    for candidate in _candidates(folder or user_jdk_dir()):
        return str(candidate)
    return ""


def worker_python():
    """The Python a Spark executor starts for its workers: this interpreter, never a bare `python`
    (on Windows that name can be the Store's install stub, and the worker never connects back)."""
    import sys  # noqa: PLC0415
    for name in ("PYSPARK_PYTHON", "PYSPARK_DRIVER_PYTHON"):
        os.environ.setdefault(name, sys.executable)
    # Configure the authentication socket timeout and worker reuse while preserving
    # existing submit options. This does not extend Spark 4.0.4's separate 10-second
    # initial simple-worker accept deadline, which precedes authentication. A
    # connect-back timeout alone does not identify the cause of slow worker startup.
    wanted = ["--conf", "spark.python.authenticate.socketTimeout=180s", "--conf", "spark.python.worker.reuse=true"]
    current = os.environ.get("PYSPARK_SUBMIT_ARGS", "").strip()
    if "--driver-memory" not in current:
        # the session builder's own driver-memory setting is a no-op once the gateway JVM is up
        # (platform/tests/fixtures/synthetic_sources.py explains); the seven-cohort build needs
        # more than Spark's 1g default, so the gateway is launched with 3g unless told otherwise
        wanted = ["--driver-memory", "3g", *wanted]
    if "spark.python.authenticate.socketTimeout" not in current:
        head = current.replace("pyspark-shell", "").strip()
        os.environ["PYSPARK_SUBMIT_ARGS"] = " ".join(part for part in (head, " ".join(wanted), "pyspark-shell") if part)
    return os.environ["PYSPARK_PYTHON"]


def ensure():
    """Export JAVA_HOME (when a user-folder JDK is the only one) and the worker Python into this
    process; returns the JAVA_HOME in use or ""."""
    worker_python()
    windows_hadoop()
    if os.environ.get("JAVA_HOME") and not _valid(os.environ["JAVA_HOME"]):
        os.environ.pop("JAVA_HOME", None)
    if _valid(os.environ.get("JAVA_HOME", "")) or shutil.which("java"):
        return os.environ.get("JAVA_HOME", "")
    home = discover()
    if home:
        os.environ["JAVA_HOME"] = home
        os.environ["PATH"] = str(Path(home) / "bin") + os.pathsep + os.environ.get("PATH", "")
    return home


def windows_hadoop():
    """Discover an installed Windows helper before Spark starts its JVM.

    This only sets this process's environment. It does not install or emulate
    Hadoop utilities; runtimes that do not need local Hadoop remain usable when
    no helper is installed. Callers requiring local filesystem operations can
    require a nonempty result before starting their session.
    """
    if os.name != "nt":
        return ""
    import importlib.util
    candidates = [Path(os.environ["HADOOP_HOME"])] if os.environ.get("HADOOP_HOME") else []
    spec = importlib.util.find_spec("pyspark")
    if spec and spec.origin:
        candidates.append(Path(spec.origin).parent / "tmp" / "hadoop")
    for directory in candidates:
        if (directory / "bin" / "winutils.exe").is_file():
            os.environ["HADOOP_HOME"] = str(directory)
            return str(directory)
    return ""


def words():
    """One sentence for a page: where a JDK was found, or what a person does once."""
    home = discover()
    if home:
        return f"Java runtime: {Path(home).name} in your application-data folder."
    if shutil.which("java"):
        return "Java runtime: found on this computer."
    return ("No Java runtime is available for a local build. Ask your data expert to unpack a JDK 17 once under "
            "your application-data folder (RwdPortal\\jdk); nothing else on the computer changes.")
