#!/usr/bin/env python3
"""Serve the governed read tools over MCP, for any Model Context Protocol client.

    python platform/tools/mcp_server.py            # stdio JSON-RPC, newline-delimited

A thin transport: the read surfaces become MCP tools, so VS Code, Claude Desktop or
any MCP client gets the same answers the CLI tools print — assembled by the tools that
own each number, never by the model.

Six of them report COMMITTED state. Three — `lint`, `pipeline_check`, `readiness` — RUN a
gate and report what it found, which is what a chat client needs to do the work the VS Code
session does. Running a check is not an act: each shells out to a report or a `--check`, and
none writes to the checkout.

No write path is on the wire. `READ_TOOLS` is a closed list, pinned by a guard test in
both directions: a write-shaped name cannot be exposed, and a client asking for one gets
a JSON-RPC error. Approvals, answers and promotions stay a person's keyboard acts — that
boundary is not a limitation of this transport, it is the thing the repository is for.

Stdlib only; the MCP stdio transport needs no SDK.
"""
from __future__ import annotations

import json
import os
import sys

TOOLS_DIR = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))

PROTOCOL = "2024-11-05"
DEFAULT_PACK = "fixtures/oncology/prostate/202606"

PACK_ARG = {"type": "string",
            "description": f"pack path relative to the checkout (default {DEFAULT_PACK})"}


def _rel(args):
    """The confined pack path, back as a repo-RELATIVE spelling for a command line.

    `repo_relative`, NEVER bare `os.path.relpath`: the latter RAISES on Windows when the two paths
    sit on different drives, and this repository has crashed on exactly that six confirmed times --
    `test_bare_os_path_relpath_in_tools_only_ever_decreases` is a ratchet standing over the count.
    A server that dies mid-session because a checkout is on D: and a temp dir on C: is the worst
    possible way to learn that lesson a seventh time.
    """
    from rwd_tools.spec_extract import repo_relative # noqa: PLC0415
    return repo_relative(_pack(args), ROOT)


def _pack(args):
    """The pack argument, resolved and CONFINED to the checkout's two pack roots.

    `realpath`, not `abspath`: a junction or symlink inside a pack root could point
    anywhere, and a prefix check over the unresolved spelling would follow it out."""
    rel = str(args.get("pack") or DEFAULT_PACK).replace("\\", "/").strip("/")
    ap = os.path.realpath(os.path.join(ROOT, rel))
    inside = any(ap.startswith(os.path.realpath(os.path.join(ROOT, base)) + os.sep)
                 for base in ("products", "fixtures"))
    if not inside or not os.path.isdir(ap):
        raise ValueError(f"{rel!r} is not a pack under products/ or fixtures/ — refusing rather "
                         f"than reading elsewhere")
    return ap


def _tree_state():
    """One honest line about WHAT was read: the working tree at a commit, dirty or not.

    Appended to every answer: this server reads the working tree, and an answer that
    did not say so would let a client caption mutable bytes as a committed state."""
    import subprocess # noqa: PLC0415
    try:
        r1 = subprocess.run(["git", "-C", ROOT, "rev-parse", "--short", "HEAD"],
                            capture_output=True, text=True, encoding="utf-8")
        r2 = subprocess.run(["git", "-C", ROOT, "status", "--porcelain"],
                            capture_output=True, text=True, encoding="utf-8")
        # A FAILED git COMMAND IS NOT A CLEAN TREE. Both results used to be read as strings
        # regardless of exit status, so a failure printed "commit ?, clean" — a provenance line
        # asserting exactly what it could not know (second audit).
        if r1.returncode != 0 or r2.returncode != 0:
            return ("[answered from the working tree; git could not identify the commit or its "
                    "cleanliness — treat this answer as UNVERSIONED]")
        sha, dirty = r1.stdout.strip(), r2.stdout.strip()
        n = len(dirty.splitlines()) if dirty else 0
        return (f"[answered from the WORKING TREE at commit {sha}"
                + (f" + {n} uncommitted change(s)]" if n else ", clean]"))
    except OSError:
        return "[answered from the working tree; git unavailable to identify the commit]"


def t_pack_status(args):
    """Where one pack stands: the six gates, the blockers, who owes the next action."""
    from rwd_tools import status # noqa: PLC0415
    return status.render(ROOT, _pack(args))


def t_portfolio(args):
    """Every pack, one line each — products first, reference fixtures labelled."""
    from rwd_tools import product_gates as pg # noqa: PLC0415
    from rwd_tools import status # noqa: PLC0415
    prods, fixes = pg.products(ROOT), pg.fixture_packs(ROOT)
    lines = ["GOVERNED PRODUCTS:" if prods else
             "GOVERNED PRODUCTS: none — every pack here is a reference fixture."]
    lines += [status.one_line(ROOT, os.path.join(ROOT, p)) for p in prods]
    if fixes:
        lines.append("REFERENCE FIXTURES (exercise material — never deploy, never release):")
        lines += [status.one_line(ROOT, os.path.join(ROOT, p)) for p in fixes]
    return "\n".join(lines)


def t_open_questions(args):
    """The ranked open-question page as COMMITTED — the register's own generated view."""
    p = os.path.join(_pack(args), "handoff", "SCIENCE_QUESTIONS.md")
    if not os.path.exists(p):
        return ("this pack keeps no ranked question page — it has no decision register yet, "
                "which is a fact about the pack, not an empty queue")
    with open(p, encoding="utf-8") as fh:
        return fh.read()


def _source_words(pack, variable_id):
    """Two plain lines after a definition's status line: where the variable's data comes from, and
    what evidence says the delivery supplies it. Assembled from the record's own source and status
    cells and the pack's declared table stems; a mapping is never judged here, only reported as the
    record states it (an epidemiologist's walk found the definition view silent about its source)."""
    import re # noqa: PLC0415
    from rwd_tools import contract_lint as cl # noqa: PLC0415
    from rwd_tools import product_gates as pg # noqa: PLC0415
    import yaml # noqa: PLC0415
    try:
        text = cl.read(os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md"))
        rec = next((r for r in cl.typed_records(text) if r.variable_id == variable_id), None)
    except (OSError, ValueError, SystemExit):
        return []
    if rec is None:
        return []

    def inline(value):
        try:
            doc = yaml.safe_load(str(value or ""))
        except yaml.YAMLError:
            return {}
        return doc if isinstance(doc, dict) else {}

    kind = rec.source_kind()
    words = {"vendor": "vendor data",
             "invalid": "a source whose kind cannot be read; the contract lint reports it",
             "derived": "derived from other variables of this product; no delivered table is read for it",
             "parameter": "a build parameter from the product's configuration; no delivered table is read for it",
             "constant": "a constant value; no delivered table is read for it",
             "unavailable": "declared unavailable in this product; its gap record says why",
             "pending_mapping": "not chosen yet; the mapping is pending"}
    if kind not in ("vendor", "invalid"):
        return ["source: " + words.get(kind, kind) + "."]
    stems = {}
    doc, _err = pg.read_yaml(os.path.join(pack, "config", "data_product.yaml"))
    for role, entry in (((doc or {}).get("sources") or {}) if isinstance(doc, dict) else {}).items():
        stem = entry if isinstance(entry, str) else (entry or {}).get("table", "")
        if stem:
            stems[str(role)] = str(stem)
    source, roles, columns, record_stem = rec.source or {}, [], [], ""
    inputs = inline(source.get("inputs"))
    if inputs:
        for role, mapping in inputs.items():
            roles.append(str(role))
            if isinstance(mapping, dict):
                columns += [f"{physical} ({logical})" for logical, physical in mapping.items()]
    else:
        logical = str(source.get("logical_table") or "").strip().strip('"')
        for part in re.split(r"\s*(?:\+|∪|,)\s*", logical) if logical else []:
            part = re.sub(r"\(.*?\)", "", part).strip().lower().replace(" ", "_")
            if part:
                roles.append(part)
        record_stem = str(source.get("physical_stem") or "").strip()
        if cl.NOT_VENDOR.match(record_stem):
            record_stem = ""
        columns += [f"{physical} ({logical})" for logical, physical in inline(source.get("columns")).items()]
    if record_stem:
        tables = ", ".join(roles) + f" (the record names the delivered table {record_stem})"
    else:
        tables = ", ".join(f"{role} (delivered as {stems[role]})" if role in stems else f"{role} (no delivered table declared)"
                           for role in roles)
    line = "source: " + words[kind] + (" from " + tables if tables else " from a table the record does not name")
    line += ("; columns " + ", ".join(columns) if columns else "") + "."
    mapping, live, coarse = rec.axis("source_mapping"), rec.axis("live_schema_check"), rec.axis("source")
    if mapping == "human_confirmed":
        judged = "a person has confirmed that these columns mean this variable"
    elif mapping == "proposed":
        judged = "the mapping of these columns to this variable is proposed and not yet confirmed by a person"
    elif coarse:
        # the record's coarse source status, in a reader's words (walk RW4-N09: "the older single
        # axis" named the contract's history, not the source)
        judged = "the source is recorded as " + {
            "unverified": "not yet verified", "verified": "verified",
            "dictionary_only": "checked against the data dictionary only",
            "unavailable": "unavailable in the delivery"}.get(coarse, str(coarse).replace("_", " "))
    else:
        judged = "nobody has judged the mapping yet"
    checked = {"passed": "the delivered data was checked and carries these columns",
               "failed": "the check of the delivered data failed for these columns"}.get(
                   live, "the delivered data has not been checked against this definition yet")
    return [line, f"evidence: {judged}; {checked}."]


def t_definition(args):
    """One variable's definition — the contract record's own words — or the pack's summary."""
    from rwd_tools import definitions_page as dp # noqa: PLC0415
    pack = _pack(args)
    m = dp.model(pack)
    want = str(args.get("variable") or "").strip().upper()
    head = (f"{m['name']} — {len(m['rows'])} definition(s), requirement axis {m['req_counts']}"
            + (" [REFERENCE FIXTURE — nothing here is clinically approved]"
               if m["role"] == "fixture" else ""))
    if not want:
        return head + "\nvariables: " + ", ".join(r["published"] for r in m["rows"])
    for r in m["rows"]:
        if want in (r["published"].upper(), r["id"].upper()):
            dec = "; ".join(f"{d} ({s})" for d, s in r["decisions"]) or "none"
            return (f"{head}\n\n{r['published']}  [{r['domain']} · {', '.join(r['spec_refs'])}]\n"
                    f"definition: {r['definition']}\n"
                    f"computed: {r['derivation'] or '(see definition)'}\n"
                    f"codes: {r['codes'] or '—'} · physical: {r['physical'] or '—'}\n"
                    f"status: requirement={r['requirement']}, "
                    f"implementation={r['implementation']}\n"
                    + "".join(line + "\n" for line in _source_words(pack, r["id"]))
                    + f"governing decisions: {dec}")
    return f"{head}\n\nno variable named {want!r} in this pack's contract"


def t_search(args):
    """Federated search over the governed surfaces, every hit labelled by its authority domain."""
    from rwd_tools import knowledge_search as ks # noqa: PLC0415
    terms = [w for w in str(args.get("query") or "").split() if w]
    if not terms:
        raise ValueError("give a query")
    hits = ks.search(terms)
    out = ["NOTHING BELOW IS AN APPROVAL — every hit is labelled by what it may settle."]
    for h in hits[:25]:
        # every hit carries where it came from (a pack or a register), its state and its detail —
        # the first renderer read `text`/`snippet`, fields the hits never had (ninth review)
        where = str(h.get("where") or "")
        out.append(f"[{h.get('kind')}/{h.get('domain', '?')}]" + (f" {where}" if where else "")
                   + (f" ({h.get('state')})" if h.get("state") else "")
                   + f" {h.get('title') or h.get('id') or ''} — "
                   + f"{str(h.get('detail') or '')[:200]}")
    if len(hits) > 25:
        out.append(f"... and {len(hits) - 25} more (narrow the query)")
    return "\n".join(out) if len(out) > 1 else "no hits"


def t_decision_packet(args):
    """One open decision's page — question, evidence, blast radius, its answer form's path.

    ONE at a time, deliberately: pass decision_id. Without it you get the ranked ids only —
    the full packet is for handing to the answerer, not for pasting whole into a chat."""
    from rwd_tools import decision_packet as dpk # noqa: PLC0415
    pack = _pack(args)
    items, note = dpk.packet(pack, ROOT)
    if note:
        return note
    want = str(args.get("decision_id") or "").strip().upper()
    if not want:
        return ("open decisions, ranked — ask for ONE by decision_id:\n"
                + "\n".join(f"  {d['id']}  blocks {len(d.get('blocks') or [])} record(s)"
                            for d in items))
    for d in items:
        if d["id"].upper() == want:
            form = d.get("form") or {}
            recs = ", ".join(d.get("blocks") or []) or "none"
            return (f"{d['id']}\nquestion: {d.get('question')}\n"
                    f"evidence: {d.get('evidence')}\nblocks: {recs}\n"
                    f"answer form: {form.get('path')} "
                    f"({'exists' if form.get('exists') else 'not scaffolded yet'})\n"
                    f"Recording the answer is a person's act on that form — no tool and no "
                    f"model types it.")
    return f"no OPEN decision {want!r} — ask without decision_id for the ranked list"


def _gate(argv, timeout=900):
    """Run one gate tool exactly as CI runs it, and hand back what it printed.

    SHELLED OUT ON PURPOSE, though several of these expose importable functions. The server's
    contract is that every answer is assembled by the tool that owns the number, and running the
    same command line CI runs is the strongest available form of that: a divergence between what
    this surface reports and what CI reports would have to be a difference in the tool, not in how
    two callers drove it. It also keeps a gate tool's imports out of the long-lived server process.

    NOTHING HERE WRITES TO THE CHECKOUT. Each command is a report or a `--check`: `contract_lint`
    reads, `run_spec_pipeline --check` regenerates into a temporary directory and compares, and
    `pilot_readiness` reports. That is the line this surface does not cross -- see the module
    docstring: running a check is not an act, and the acts stay a person's.
    """
    import subprocess # noqa: PLC0415
    try:
        r = subprocess.run([sys.executable] + argv, cwd=ROOT, capture_output=True,
                           encoding="utf-8", errors="replace", timeout=timeout,
                           env=dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8"))
    except subprocess.TimeoutExpired:
        return f"the gate did not finish within {timeout}s — it was stopped, not failed"
    out = ((r.stdout or "") + (r.stderr or "")).strip()
    # A NON-ZERO EXIT IS A VERDICT, NOT AN ERROR. These tools exit 1 to say "this pack fails this
    # gate", which is exactly the answer a stakeholder asked for; swallowing it into a protocol
    # error would turn a governed refusal into a broken tool.
    return out or f"(the gate printed nothing; exit {r.returncode})"


def t_lint(args):
    """Run the contract lint against a pack, live — every invariant, as CI runs it."""
    return _gate(["platform/tools/contract_lint.py", _rel(args)])


def t_pipeline_check(args):
    """Regenerate the spec pipeline into a temp dir and report whether the committed
    artifacts are current. Answers 'is this pack's extraction stale?' without touching it."""
    return _gate(["platform/tools/run_spec_pipeline.py", _rel(args), "--check"])


def t_readiness(args):
    """Run the pilot-readiness report for a pack, live."""
    return _gate(["platform/tools/pilot_readiness.py", _rel(args)])


def t_dictionary(args):
    """The data dictionary PREVIEW: every contract record's published name, type, domain, the two
    status axes a consumer cares about and the requirement in the specification's own words —
    from the contract, with no data behind it (audit item 7: a scientist could not see what a
    product WOULD carry without a build). Assembly, never judgement: definitions_page owns the
    model, this renders one table."""
    from rwd_tools import definitions_page as dp  # noqa: PLC0415
    m = dp.model(_pack(args))
    head = (f"{m['name']} — data dictionary PREVIEW from the contract, {len(m['rows'])} variable(s), "
            f"requirement axis {m['req_counts']}; no data behind it"
            + (" [REFERENCE FIXTURE — nothing here is clinically approved]" if m["role"] == "fixture" else ""))
    lines = [head, "", "| variable | type | domain | requirement | implementation | required rule |",
             "|---|---|---|---|---|---|"]
    for r in m["rows"]:
        rule = " ".join(str(r.get("definition") or "").split())[:110]
        lines.append(f"| {r['published']} | {r.get('type') or ''} | {r.get('domain') or ''} | "
                     f"{r.get('requirement') or ''} | {r.get('implementation') or ''} | {rule} |")
    return "\n".join(lines)


# THE CLOSED SURFACE. Names, handlers and schemas — a tool absent here does not exist on the
# wire, and the guard test holds this list free of every write-shaped name in the repository.
READ_TOOLS = {
    "pack_status": (t_pack_status, "Where one pack stands: gates, blockers, who acts next.",
                    {"pack": PACK_ARG}),
    "portfolio": (t_portfolio, "Every pack, one line each; fixtures labelled as fixtures.", {}),
    "open_questions": (t_open_questions,
                       "The committed ranked open-question page for a pack.", {"pack": PACK_ARG}),
    "definition": (t_definition,
                   "A variable's definition in the contract's own words (or the pack summary).",
                   {"pack": PACK_ARG, "variable": {"type": "string",
                    "description": "published variable name, e.g. REGION1"}}),
    "dictionary": (t_dictionary,
                   "The data dictionary PREVIEW — every contract variable with type, domain, status "
                   "and required rule, from the contract, no data behind it.", {"pack": PACK_ARG}),
    "search": (t_search,
               "Search decisions, contracts, capabilities and literature; hits carry their "
               "authority domain and nothing found is an approval.",
               {"query": {"type": "string", "description": "search words"}}),
    "decision_packet": (t_decision_packet,
                        "ONE open decision's question/evidence/blast-radius page.",
                        {"pack": PACK_ARG, "decision_id": {"type": "string",
                         "description": "e.g. OUTCOME-COHORT-MAP; omit for the ranked ids"}}),
    # THE GATES, RUN. Everything above reports committed state; these three EXECUTE a gate and say
    # what it found, which is what "run it and do all the gates" asks for from a chat client. They
    # remain reads in the sense that matters: none writes to the checkout, and none is an act.
    "lint": (t_lint, "Run the contract lint against a pack, live — every invariant, as CI runs "
                     "it. A non-zero verdict is the answer, not an error.", {"pack": PACK_ARG}),
    "pipeline_check": (t_pipeline_check,
                       "Regenerate the spec pipeline into a temporary directory and report "
                       "whether the pack's committed artifacts are current.", {"pack": PACK_ARG}),
    "readiness": (t_readiness, "Run the pilot-readiness report for a pack, live.",
                  {"pack": PACK_ARG}),
}


def _tool_defs():
    return [{"name": n, "description": desc,
             "inputSchema": {"type": "object", "properties": props,
                             "required": [k for k in props if k == "query"]}}
            for n, (_fn, desc, props) in sorted(READ_TOOLS.items())]


def _handle(msg):
    """One JSON-RPC request -> one response dict, or None for a notification."""
    method, msg_id = msg.get("method"), msg.get("id")
    if method == "initialize":
        return {"jsonrpc": "2.0", "id": msg_id, "result": {
            "protocolVersion": PROTOCOL,
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "rwdp-governed-tools", "version": "1.0.0"},
            "instructions": ("Read-only governed surfaces. Every answer is assembled by the "
                            "repository's own tools; no write path exists on this server — "
                            "approvals, answers and promotions are a person's acts at a "
                            "keyboard, and the tools refuse them from anyone else.")}}
    if msg_id is None:
        return None # notifications: initialized, cancelled…
    if method == "ping":
        return {"jsonrpc": "2.0", "id": msg_id, "result": {}}
    if method == "tools/list":
        return {"jsonrpc": "2.0", "id": msg_id, "result": {"tools": _tool_defs()}}
    if method == "tools/call":
        params = msg.get("params") or {}
        # WRONG-SHAPED PARAMS ARE -32602 (invalid params), not a -32603 internal error surfacing
        # from an AttributeError three frames down (third audit)
        # `arguments` may be absent or None; anything else that is not an object is invalid —
        # `""` and `[]` used to be normalised to {} (fourth audit)
        if not isinstance(params, dict) or (
                "arguments" in params and params["arguments"] is not None
                and not isinstance(params["arguments"], dict)):
            return {"jsonrpc": "2.0", "id": msg_id, "error": {
                "code": -32602, "message": "invalid params: `params` must be an object with a "
                                           "`name` string and an `arguments` object"}}
        name = str(params.get("name") or "")
        entry = READ_TOOLS.get(name)
        if entry is None:
            return {"jsonrpc": "2.0", "id": msg_id, "error": {
                "code": -32602,
                "message": f"unknown tool {name!r} — this server exposes only the read-only "
                           f"surfaces: {', '.join(sorted(READ_TOOLS))}"}}
        try:
            # stdout IS the transport: any print() from an imported tool would corrupt the
            # JSON-RPC stream, so tool execution runs with stdout captured
            import contextlib # noqa: PLC0415
            import io as _io # noqa: PLC0415
            buf = _io.StringIO()
            with contextlib.redirect_stdout(buf):
                text = entry[0](params.get("arguments") or {})
            stray = buf.getvalue().strip()
            if stray:
                text = text + "\n\n[tool stdout]\n" + stray
            text = text + "\n\n" + _tree_state()
            return {"jsonrpc": "2.0", "id": msg_id, "result": {
                "content": [{"type": "text", "text": text}], "isError": False}}
        except Exception as e: # noqa: BLE001
            return {"jsonrpc": "2.0", "id": msg_id, "result": {
                "content": [{"type": "text", "text": f"refused: {e}"}], "isError": True}}
    return {"jsonrpc": "2.0", "id": msg_id,
            "error": {"code": -32601, "message": f"method {method!r} not supported"}}


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        # JSON-RPC 2.0 §5.1: a parse error and an invalid request are ANSWERED (-32700 / -32600),
        # never silently dropped — a client that sent garbage must learn so, and a `jsonrpc`
        # field that is missing or "1.0" is not this protocol (second audit).
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            sys.stdout.write(json.dumps({"jsonrpc": "2.0", "id": None, "error": {
                "code": -32700, "message": "parse error: request is not valid JSON"}}) + "\n")
            sys.stdout.flush()
            continue
        if not isinstance(msg, dict) or msg.get("jsonrpc") != "2.0":
            sys.stdout.write(json.dumps({"jsonrpc": "2.0",
                                         "id": msg.get("id") if isinstance(msg, dict) else None,
                                         "error": {"code": -32600, "message":
                                                   "invalid request: a JSON-RPC 2.0 object with "
                                                   "\"jsonrpc\": \"2.0\" is required"}}) + "\n")
            sys.stdout.flush()
            continue
        try:
            resp = _handle(msg)
        except Exception as e: # noqa: BLE001 — the transport must outlive a bug
            resp = {"jsonrpc": "2.0", "id": msg.get("id"),
                    "error": {"code": -32603, "message": f"internal error: {e}"}}
        if resp is not None:
            sys.stdout.write(json.dumps(resp) + "\n")
            sys.stdout.flush()
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    if any(x in ("-h", "--help") for x in sys.argv[1:]):
        # a JSON-RPC server over stdio never returns on its own; --help used to read stdin forever
        print(__doc__.splitlines()[0])
        print(f"usage: mcp_server.py   (a JSON-RPC server over stdio, no flags; {len(READ_TOOLS)} read-only tools: "
              + ", ".join(sorted(READ_TOOLS)) + ")")
        sys.exit(0)
    sys.exit(main())
