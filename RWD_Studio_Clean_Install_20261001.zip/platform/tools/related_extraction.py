"""Read-only, schema-driven extraction of related objects from specification rows.

The supported declarative DSL is documented in governance/schemas/
rwd_related_extraction.yaml. This layer organizes explicit source evidence; it
does not infer clinical logic, approve definitions, or generate executable rules.
Malformed schema/input raises ValueError. Readable evidence returns ok=True;
valid=False means its typed fields, identities or references need review.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import date
import hashlib
import json
from pathlib import Path
import re

import yaml

from rwd_tools.spec_extract import is_context, requirement_rows

from rwd_services import package_asset
DEFAULT_SCHEMA = package_asset("governance/schemas/rwd_related_extraction.yaml")
_TYPES = {"string", "integer", "number", "boolean", "date", "string_list"}
_IDENTIFIER = r"[A-Za-z_][A-Za-z0-9_.:]*"
_RANGE_IDENTIFIER = r"[A-Z_][A-Z0-9_.:]*"
_PLACEHOLDER = re.compile(r"\b(?:TODO|TBD|REPLACE_ME\w*)\b", re.I)
_MONTHS = {name: i for i, name in enumerate(
    ("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"), 1)}


class _UniqueKeyLoader(yaml.SafeLoader):
    """A schema must not silently replace an earlier rule with a duplicate key."""

    def construct_mapping(self, node, deep=False):
        self.flatten_mapping(node)
        seen = set()
        for key_node, _ in node.value:
            key = self.construct_object(key_node, deep=deep)
            try:
                if key in seen:
                    raise yaml.constructor.ConstructorError(None, None, f"Duplicate schema key: {key}", key_node.start_mark)
                seen.add(key)
            except TypeError as exc:
                raise yaml.constructor.ConstructorError(None, None, "Schema keys must be scalar", key_node.start_mark) from exc
        return super().construct_mapping(node, deep=deep)


def _canonical(value):
    try:
        return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise ValueError("Input and schema must contain finite JSON-compatible values.") from exc


def _hash(value):
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def _keys(value, allowed, label):
    if not isinstance(value, dict) or set(value) - set(allowed):
        raise ValueError(f"Malformed {label}; supported keys: {', '.join(allowed)}.")


def _path(value):
    return isinstance(value, str) and bool(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*", value))


def _schema(schema):
    _canonical(schema)
    _keys(schema, ("version", "id", "entities", "links"), "schema")
    if type(schema.get("version")) is not int or schema["version"] != 1 or not isinstance(schema.get("id"), str) or not schema["id"].strip():
        raise ValueError("Schema requires version: 1 and a nonempty id.")
    entities, links = schema.get("entities"), schema.get("links", [])
    if not isinstance(entities, list) or not entities or not isinstance(links, list):
        raise ValueError("Schema entities must be a nonempty list and links must be a list.")
    names = set()
    for entity in entities:
        _keys(entity, ("type", "select", "key", "unique_key", "fields"), "entity")
        name = entity.get("type")
        if not isinstance(name, str) or not name.strip() or name in names or not _path(entity.get("key")):
            raise ValueError("Each entity needs a unique nonempty type and a source key path.")
        names.add(name)
        if "unique_key" in entity and type(entity["unique_key"]) is not bool:
            raise ValueError("unique_key must be boolean.")
        select = entity.get("select", {})
        _keys(select, ("domains", "variables", "fields_present"), "selector")
        for key, values in select.items():
            if not isinstance(values, list) or not values or any(not isinstance(v, str) or not v for v in values):
                raise ValueError("Selector values must be nonempty lists of strings.")
            if key == "fields_present" and any(not _path(v) for v in values):
                raise ValueError("fields_present entries must be source paths.")
        fields = entity.get("fields")
        if not isinstance(fields, dict) or not fields:
            raise ValueError("Entity fields must be a nonempty mapping.")
        for field, rule in fields.items():
            if not isinstance(field, str) or not field:
                raise ValueError("Field names must be nonempty strings.")
            _keys(rule, ("source", "type", "required", "check_placeholders"), "field rule")
            if not _path(rule.get("source")) or not isinstance(rule.get("type"), str) or rule["type"] not in _TYPES:
                raise ValueError(f"Field {field} needs a source path and supported type.")
            if any(k in rule and type(rule[k]) is not bool for k in ("required", "check_placeholders")):
                raise ValueError("required and check_placeholders must be boolean.")
    for link in links:
        _keys(link, ("kind", "source_type", "target_type", "mode", "source_field", "parser", "dependency"), "link")
        if (not isinstance(link.get("kind"), str) or not link["kind"]
                or any(not isinstance(link.get(k), str) or link[k] not in names for k in ("source_type", "target_type"))):
            raise ValueError("Link requires a kind and declared source/target types.")
        if not isinstance(link.get("mode"), str) or link["mode"] not in {"same_row", "reference"}:
            raise ValueError("Link mode must be same_row or reference.")
        if "dependency" in link and type(link["dependency"]) is not bool:
            raise ValueError("Link dependency must be boolean.")
        if link["mode"] == "reference":
            fields = next(e["fields"] for e in entities if e["type"] == link["source_type"])
            if (not isinstance(link.get("source_field"), str) or link["source_field"] not in fields
                    or not isinstance(link.get("parser"), str) or link["parser"] not in {"identifier", "list", "named_range"}):
                raise ValueError("Reference links require a declared source_field and supported parser.")
        elif "source_field" in link or "parser" in link:
            raise ValueError("same_row links do not accept source_field or parser.")
    return schema


def load_schema(path=None):
    """Load and validate the bounded DSL; no dynamic imports or schema execution."""
    try:
        data = yaml.load(Path(path or DEFAULT_SCHEMA).read_text(encoding="utf-8"), Loader=_UniqueKeyLoader)
    except (OSError, UnicodeError, yaml.YAMLError) as exc:
        raise ValueError(f"Cannot read related-object extraction schema: {exc}") from exc
    return _schema(data)


def _source(row, path):
    value = row
    for key in path.split("."):
        if not isinstance(value, dict) or key not in value:
            return None
        value = value[key]
    return value


def _blank(value):
    return value is None or value == "" or value == [] or (isinstance(value, str) and not value.strip())


def _citation(row, field):
    return {"item_id": row["item_id"], "tab": row["tab"], "row": row["row"], "field": field}


def _typed(value, kind):
    if kind == "string":
        if not isinstance(value, str):
            raise ValueError("expected text")
        return value
    if kind == "date":
        if not isinstance(value, str):
            raise ValueError("expected a date string")
        value = value.strip()
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
            return date.fromisoformat(value).isoformat()
        match = re.fullmatch(r"(\d{2})-([A-Za-z]{3})-(\d{4})", value)
        if match and match[2].lower() in _MONTHS:
            return date(int(match[3]), _MONTHS[match[2].lower()], int(match[1])).isoformat()
        raise ValueError("use YYYY-MM-DD or dd-Mon-YYYY with a four-digit year")
    if kind == "boolean":
        if type(value) is bool:
            return value
        if isinstance(value, str) and value.strip().lower() in {"true", "false"}:
            return value.strip().lower() == "true"
        raise ValueError("expected true or false")
    if kind == "string_list":
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except ValueError as exc:
                raise ValueError("expected a JSON or native string array") from exc
        if not isinstance(value, list) or any(not isinstance(v, str) or not v.strip() for v in value):
            raise ValueError("expected an array of nonempty strings")
        return list(value)
    if type(value) is bool or not isinstance(value, (str, int, float)):
        raise ValueError(f"expected {kind}")
    value = str(value).strip()
    pattern = r"[+-]?\d+" if kind == "integer" else r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?"
    if not re.fullmatch(pattern, value):
        raise ValueError(f"expected {kind}")
    number = int(value) if kind == "integer" else float(value)
    _canonical(number)
    return number


def _references(raw, parser):
    if _blank(raw):
        return []
    if parser == "list":
        values = _typed(raw, "string_list")
    elif parser == "named_range":
        match = re.fullmatch(fr"\s*({_RANGE_IDENTIFIER})\s*[-–]\s*({_RANGE_IDENTIFIER})\s*", raw) if isinstance(raw, str) else None
        return list(dict.fromkeys(match.groups())) if match else []
    else:
        values = [raw]
    if any(not isinstance(v, str) or not re.fullmatch(_IDENTIFIER, v.strip()) for v in values):
        raise ValueError("references must be exact identifiers, not prose")
    return list(dict.fromkeys(v.strip() for v in values))


def extract(data: dict, schema: dict | None = None):
    """Extract typed objects and exact, independently validated relationships."""
    schema = load_schema() if schema is None else _schema(schema)
    _canonical(data)
    if not isinstance(data, dict) or not isinstance(data.get("rows"), list):
        raise ValueError("Extraction input requires a rows list.")
    for row in data["rows"]:
        if (not isinstance(row, dict) or not isinstance(row.get("fields"), dict)
                or any(not isinstance(row.get(k), str) for k in ("variable", "tab", "item_id"))
                or not row["tab"].strip() or not row["item_id"].strip()
                or type(row.get("row")) is not int or row["row"] < 1
                or ("domain" in row and not isinstance(row["domain"], str))
                or ("cells" in row and (not isinstance(row["cells"], list) or any(not isinstance(v, str) for v in row["cells"])))):
            raise ValueError("Each source row needs variable, tab, positive row, item_id and fields; cells must be text.")
    rows = [r for r in requirement_rows(data) if not is_context({**r, "cells": r.get("cells", [str(v) for v in r["fields"].values()])})]
    rows = sorted(rows, key=lambda r: (r["tab"], r["row"], r["item_id"], _canonical(r)))
    objects, relationships, issues = [], [], []
    by_type, by_key, by_row, object_rows = defaultdict(list), defaultdict(list), defaultdict(list), {}
    occurrence, coordinates, item_ids = Counter(), Counter(), Counter()

    def issue(code, message, obj=None, field="", row=None):
        row = row if row is not None else object_rows[obj["id"]][1]
        issues.append({"code": code, "message": message, "object_id": obj["id"] if obj else "", "item_id": row["item_id"], "field": field, "severity": "error"})

    for row in rows:
        coordinates[(row["tab"], row["row"])] += 1
        item_ids[row["item_id"]] += 1
    for row in rows:
        if coordinates[(row["tab"], row["row"])] > 1 or item_ids[row["item_id"]] > 1:
            issue("source_coordinate_collision", "Source coordinate or item_id occurs more than once; rows were kept separate.", field="item_id", row=row)
        fingerprint = _hash(row)
        occurrence[fingerprint] += 1
        row_token = (fingerprint, occurrence[fingerprint])
        for entity in schema["entities"]:
            select = entity.get("select", {})
            if ("domains" in select and row.get("domain") not in select["domains"]
                    or "variables" in select and row["variable"] not in select["variables"]
                    or any(_blank(_source(row, path)) for path in select.get("fields_present", []))):
                continue
            key = _source(row, entity["key"])
            obj = {"id": "object-" + _hash([entity["type"], row_token])[:24], "type": entity["type"],
                   "key": key.strip() if isinstance(key, str) else "", "fields": {}, "raw_fields": {},
                   "citations": [_citation(row, entity["key"])]}
            objects.append(obj)
            object_rows[obj["id"]] = (row_token, row)
            by_type[obj["type"]].append(obj)
            by_key[(obj["type"], obj["key"])].append(obj)
            by_row[(row_token, obj["type"])].append(obj)
            if not obj["key"]:
                issue("missing_key", "Object key must be nonempty text.", obj, entity["key"])
            for name, rule in entity["fields"].items():
                raw = _source(row, rule["source"])
                obj["raw_fields"][name] = json.loads(_canonical(raw))
                obj["fields"][name] = None
                citation = _citation(row, rule["source"])
                if citation not in obj["citations"]:
                    obj["citations"].append(citation)
                if _blank(raw):
                    if rule.get("required"):
                        issue("required_field", f"{name} is required by the extraction schema.", obj, rule["source"])
                    continue
                try:
                    obj["fields"][name] = _typed(raw, rule["type"])
                except ValueError as exc:
                    issue("invalid_type", f"{name}: {exc}", obj, rule["source"])
                if rule.get("check_placeholders") and _PLACEHOLDER.search(str(raw)):
                    issue("unresolved_placeholder", f"{name} contains an unresolved TODO, TBD or REPLACE_ME.", obj, rule["source"])
    for entity in schema["entities"]:
        if entity.get("unique_key"):
            for obj in by_type[entity["type"]]:
                if obj["key"] and len(by_key[(obj["type"], obj["key"])]) > 1:
                    issue("duplicate_key", f"{obj['type']} identifier {obj['key']} occurs more than once; choose its meaning explicitly.", obj, entity["key"])
    dependency_ids = set()
    for link_index, link in enumerate(schema.get("links", [])):
        for obj in by_type[link["source_type"]]:
            row_token, row = object_rows[obj["id"]]
            if link["mode"] == "same_row":
                candidates = by_row[(row_token, link["target_type"])]
                references = [(candidate["key"], [candidate]) for candidate in candidates]
                citations = obj["citations"][:1]
            else:
                field = link["source_field"]
                entity = next(e for e in schema["entities"] if e["type"] == obj["type"])
                source_path = entity["fields"][field]["source"]
                citations = [_citation(row, source_path)]
                try:
                    refs = _references(obj["raw_fields"][field], link["parser"])
                except ValueError as exc:
                    issue("invalid_reference", str(exc), obj, source_path)
                    continue
                references = [(ref, by_key[(link["target_type"], ref)]) for ref in refs]
            for ref, candidates in references:
                status = "resolved" if len(candidates) == 1 else "ambiguous" if candidates else "missing"
                target = candidates[0]["id"] if len(candidates) == 1 else ""
                if link.get("dependency") and target == obj["id"]:
                    status = "self_reference"
                rel = {"id": "link-" + _hash([link_index, obj["id"], ref, target])[:24], "source_id": obj["id"],
                       "target_id": target, "kind": link["kind"], "reference": ref, "status": status,
                       "candidates": [c["id"] for c in candidates], "citations": citations}
                relationships.append(rel)
                if link.get("dependency") and target:
                    dependency_ids.add(rel["id"])
                if status != "resolved":
                    issue("reference_" + status, f"{link['kind']}: {ref} is {status.replace('_', ' ')}.", obj, citations[0]["field"])
    graph = defaultdict(set)
    for rel in relationships:
        if rel["id"] in dependency_ids and rel["status"] == "resolved":
            graph[rel["source_id"]].add(rel["target_id"])
    lookup = {obj["id"]: obj for obj in objects}
    for rel in relationships:
        if rel["id"] not in dependency_ids or rel["status"] != "resolved":
            continue
        pending, visited = [rel["target_id"]], set()
        while pending:
            node = pending.pop()
            if node == rel["source_id"]:
                rel["status"] = "cycle"
                issue("reference_cycle", f"{rel['kind']} participates in a dependency cycle.", lookup[rel["source_id"]], rel["citations"][0]["field"])
                break
            if node not in visited:
                visited.add(node)
                pending.extend(graph[node] - visited)
    return {"ok": True, "valid": not any(i["severity"] == "error" for i in issues), "schema_id": schema["id"],
            "source_fingerprint": _hash(data), "objects": objects, "relationships": relationships, "issues": issues,
            "counts": {"objects": len(objects), "relationships": len(relationships),
                       "resolved": sum(r["status"] == "resolved" for r in relationships), "issues": len(issues)}}
