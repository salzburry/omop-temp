#!/usr/bin/env python3
"""The standing definitions page — every contract record's definition, for stakeholder review.

    python3 platform/tools/definitions_page.py <pack> --out <file outside the checkout>
    python3 platform/tools/definitions_page.py <pack> --summary

ASSEMBLY, NEVER JUDGEMENT — the same constitution as `decision_packet` and `status`. Every word
on the page comes from a governed file through the reader that owns it: the definition text is
the contract record's own `required_rule` (the specification's words), the status chips are the
record's own status axes, the decision states are read live from the register through
`contract_lint`'s one reader, and the pack's ROLE comes from its registry. This file re-derives
nothing and writes nothing into the pack.

WHY `--out` REFUSES A PATH INSIDE THE CHECKOUT: `repo_hygiene` reports every committed `*.html`
as a saved web page, and the packet's `--out` carries the same rule for the same reason. The
page is a REVIEW SURFACE, not repository content — it is regenerated from the governed files
whenever they move, so a committed copy is a copy free to go stale.

THE BANNER IS NOT DECORATION. A `role: fixture` pack renders under a banner saying so, because
The quiet part, said plainly: walkthrough output must never be described as clinically
approved. The banner is derived from the registry, never asserted here.

stdlib only (plus PyYAML through the readers).
"""
from __future__ import annotations

import argparse
import datetime
import html
import json
import os
import subprocess
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))

from rwd_tools import contract_lint as cl                                              # noqa: E402
from rwd_tools import product_gates as pg                                              # noqa: E402
from rwd_tools.spec_extract import citation_domain, repo_relative                 # noqa: E402

# The requirement axis, rendered as a chip. A word outside this vocabulary renders as itself in
# the neutral style — shown, never normalised to the nearest known value.
REQ_CHIP = {"approved": "ok", "draft": "warn", "decision_required": "blocked",
            "not_started": "na"}


def _yaml_map(s):
    import yaml                                                          # noqa: PLC0415
    try:
        doc = yaml.safe_load(s or "")
        return doc if isinstance(doc, dict) else {}
    except Exception:                                                    # noqa: BLE001
        return {}


def _commit(root):
    try:
        r = subprocess.run(["git", "-C", root, "rev-parse", "--short", "HEAD"],
                           capture_output=True, text=True, encoding="utf-8")
        return r.stdout.strip() if r.returncode == 0 else "(no git)"
    except OSError:
        return "(no git)"


def model(pack, root=ROOT):
    """Everything the page shows, as data — one dict per record, plus the pack header facts."""
    rel = repo_relative(os.path.abspath(pack), root)
    contract = os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md")
    if not os.path.exists(contract):
        raise SystemExit(f"{rel}: no handoff/FUNCTIONAL_CONTRACT.md — there are no definitions "
                         f"to show, which is a fact worth a different page than an empty one")
    text = cl.read(contract)

    reg_path = os.path.join(pack, "handoff", "DECISIONS.md")
    dstatus = cl.decision_status(cl.read(reg_path)) if os.path.exists(reg_path) else {}

    entry = pg.registry_entry(root, rel) or {}
    role = str(entry.get("role") or "").strip() or "product"

    extraction = os.path.join(pack, "spec_pipeline", "out", "extracted.json")
    logical_domains = {}
    if os.path.exists(extraction):
        with open(extraction, encoding="utf-8") as stream:
            data = json.load(stream)
        logical_domains = {citation_domain(row): row["domain"] for row in data.get("rows", []) if row.get("domain")}

    rows, domains = [], []
    for block in cl.records(text):
        vid = cl._scalar(block, "variable_id")
        if not vid:
            continue
        out = _yaml_map(cl._scalar(block, "output"))
        st = _yaml_map(cl._scalar(block, "status"))
        missing = _yaml_map(cl._scalar(block, "missing"))
        refs = cl._list(block, "spec_refs") or []
        domain = (refs[0].split(":", 1)[0] if refs and ":" in refs[0]
                  else (refs[0] if refs else "unreferenced"))
        domain = logical_domains.get(domain, domain)
        if domain not in domains:
            domains.append(domain)
        rows.append({
            "id": str(vid),
            "published": str(out.get("target_published_name") or vid),
            "physical": str(out.get("physical_name") or ""),
            "role": str(out.get("role") or ""),
            "codes": out.get("codes"),
            "type": str(out.get("type") or ""),
            "domain": domain,
            "spec_refs": refs,
            "definition": cl._scalar(block, "required_rule") or "",
            "derivation": cl._scalar(block, "derivation") or "",
            "missing": missing,
            "units": cl._scalar(block, "units") or "",
            "cohorts": cl._scalar(block, "cohort_applicability") or "",
            "requirement": str(st.get("requirement") or ""),
            "implementation": str(st.get("implementation") or ""),
            "decisions": [(d, str(dstatus.get(d) or "?").upper())
                          for d in (cl._list(block, "decision_ids") or [])],
        })

    req_counts = {}
    for r in rows:
        req_counts[r["requirement"] or "(unstated)"] = \
            req_counts.get(r["requirement"] or "(unstated)", 0) + 1
    open_ids = sorted(d for d, s in dstatus.items() if s == "OPEN")
    return {"rel": rel, "name": str(entry.get("name") or rel), "role": role,
            "vendor": str(entry.get("vendor") or ""), "commit": _commit(root),
            "generated": datetime.date.today().isoformat(),
            "rows": rows, "domains": domains, "req_counts": req_counts,
            "open_decisions": open_ids}


def _codes_str(codes):
    if not codes:
        return ""
    if isinstance(codes, dict):
        return "; ".join(f"{k} = {v}" for k, v in codes.items())
    return str(codes)


def _def_html(s):
    """The definition, escaped — the ONLY markup that survives is the record's own <br>."""
    return html.escape(str(s)).replace("&lt;br&gt;", "<br>")


def render(m):
    e = html.escape
    fixture = m["role"] == "fixture"
    chips = " ".join(
        f'<span class="chip {REQ_CHIP.get(k, "na")}">{e(k)}&nbsp;{v}</span>'
        for k, v in sorted(m["req_counts"].items(), key=lambda kv: -kv[1]))

    sections = []
    for d in m["domains"]:
        sec = [f'<h2 id="{e(d)}">{e(d)} <span class="dim">'
               f'{sum(1 for r in m["rows"] if r["domain"] == d)} definition(s)</span></h2>']
        for r in (x for x in m["rows"] if x["domain"] == d):
            dec = "".join(
                f'<span class="chip {"blocked" if s == "OPEN" else "na"}">{e(i)} · {e(s)}</span>'
                for i, s in r["decisions"])
            meta = [("published as", r["published"]), ("physical column", r["physical"]),
                    ("codes", _codes_str(r["codes"])), ("units", r["units"]),
                    ("cohorts", r["cohorts"]), ("spec", ", ".join(r["spec_refs"]))]
            metas = "".join(f"<div><dt>{e(k)}</dt><dd>{e(v)}</dd></div>"
                            for k, v in meta if v)
            mis = r["missing"]
            mis_html = ""
            if isinstance(mis, dict) and mis:
                mis_html = ('<div><dt>when missing</dt><dd>'
                            + "; ".join(f"{e(str(k))}: {e(str(v))}" for k, v in mis.items())
                            + "</dd></div>")
            deriv = (f'<p class="deriv"><span class="dt">how it is computed</span> '
                     f'{_def_html(r["derivation"])}</p>' if r["derivation"] else "")
            sec.append(
                f'<article class="card" data-search="{e((r["id"] + " " + r["published"] + " " + r["physical"] + " " + str(r["definition"])).lower())}">'
                f'<header><h3>{e(r["published"])}</h3>'
                f'<span class="chip {REQ_CHIP.get(r["requirement"], "na")}">{e(r["requirement"] or "unstated")}</span>'
                f'<span class="chip na">{e(r["implementation"] or "—")}</span>{dec}</header>'
                f'<p class="def">{_def_html(r["definition"])}</p>{deriv}'
                f'<dl class="meta">{metas}{mis_html}</dl>'
                f"</article>")
        sections.append("\n".join(sec))

    nav = " ".join(f'<a href="#{e(d)}">{e(d)}</a>' for d in m["domains"])
    banner = ""
    if fixture:
        banner = ('<div class="banner">REFERENCE FIXTURE — this pack exercises the platform. '
                  "Nothing on this page is clinically approved and nothing from it releases; "
                  "the production pack is stood up fresh from the approved workbook.</div>")
    opens = ""
    if m["open_decisions"]:
        opens = (f'<p class="opens"><strong>{len(m["open_decisions"])} open decision(s)</strong> '
                 f'govern parts of these definitions: '
                 f'{e(", ".join(m["open_decisions"]))}. A definition citing one is settled only '
                 f"when a named person records the answer.</p>")

    return f"""<title>{e(m["name"])} Definitions</title>
<style>
:root{{--bg:#f7f8f8;--card:#ffffff;--ink:#20242a;--dim:#68707c;--rule:#dfe3e7;
--accent:#0e6b5c;--ok-bg:#e3f2e9;--ok-ink:#1c6b3c;--warn-bg:#faf0d9;--warn-ink:#8a6410;
--blocked-bg:#fbe6e4;--blocked-ink:#a33529;--na-bg:#eceef1;--na-ink:#5a626e}}
@media (prefers-color-scheme:dark){{:root:not([data-theme="light"]){{--bg:#16181c;--card:#1e2126;
--ink:#e6e8ea;--dim:#98a0ab;--rule:#31363d;--accent:#4fc2ae;--ok-bg:#173527;--ok-ink:#7fd6a2;
--warn-bg:#393013;--warn-ink:#e3bd66;--blocked-bg:#3d1f1b;--blocked-ink:#f09a8d;
--na-bg:#282c33;--na-ink:#a7aeb9}}}}
:root[data-theme="dark"]{{--bg:#16181c;--card:#1e2126;--ink:#e6e8ea;--dim:#98a0ab;--rule:#31363d;
--accent:#4fc2ae;--ok-bg:#173527;--ok-ink:#7fd6a2;--warn-bg:#393013;--warn-ink:#e3bd66;
--blocked-bg:#3d1f1b;--blocked-ink:#f09a8d;--na-bg:#282c33;--na-ink:#a7aeb9}}
body{{background:var(--bg);color:var(--ink);margin:0;padding:2rem 1.25rem 4rem;
font:15px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}}
main{{max-width:56rem;margin:0 auto}}
h1{{font-size:1.5rem;margin:0 0 .25rem;text-wrap:balance}}
h2{{font-size:1.05rem;margin:2.2rem 0 .6rem;color:var(--accent);
text-transform:uppercase;letter-spacing:.06em}}
h3{{font-size:1rem;margin:0;font-family:ui-monospace,"SF Mono",Consolas,monospace}}
.sub{{color:var(--dim);margin:0 0 1rem}}
.banner{{background:var(--warn-bg);color:var(--warn-ink);border:1px solid var(--rule);
border-radius:8px;padding:.7rem .9rem;margin:1rem 0;font-weight:600}}
.opens{{color:var(--dim);font-size:.9rem}}
.chips{{display:flex;flex-wrap:wrap;gap:.4rem;margin:.5rem 0 1rem}}
.chip{{display:inline-block;border-radius:999px;padding:.08rem .55rem;font-size:.72rem;
font-weight:600;background:var(--na-bg);color:var(--na-ink);white-space:nowrap}}
.chip.ok{{background:var(--ok-bg);color:var(--ok-ink)}}
.chip.warn{{background:var(--warn-bg);color:var(--warn-ink)}}
.chip.blocked{{background:var(--blocked-bg);color:var(--blocked-ink)}}
nav{{display:flex;flex-wrap:wrap;gap:.35rem .8rem;font-size:.85rem;margin:.6rem 0 1.2rem}}
nav a{{color:var(--accent);text-decoration:none}}
nav a:hover{{text-decoration:underline}}
input#q{{width:100%;box-sizing:border-box;padding:.55rem .8rem;border:1px solid var(--rule);
border-radius:8px;background:var(--card);color:var(--ink);font:inherit}}
input#q:focus{{outline:2px solid var(--accent);outline-offset:1px}}
.card{{background:var(--card);border:1px solid var(--rule);border-radius:10px;
padding:.9rem 1rem;margin:.6rem 0}}
.card header{{display:flex;flex-wrap:wrap;align-items:center;gap:.45rem;margin-bottom:.45rem}}
.def{{margin:.2rem 0;white-space:normal}}
.deriv{{margin:.4rem 0 0;color:var(--dim);font-size:.9rem}}
.deriv .dt{{font-weight:600;color:var(--accent)}}
dl.meta{{display:grid;grid-template-columns:repeat(auto-fit,minmax(15rem,1fr));
gap:.25rem .9rem;margin:.6rem 0 0;font-size:.85rem}}
dl.meta div{{display:flex;gap:.4rem;min-width:0}}
dl.meta dt{{color:var(--dim);font-weight:600;white-space:nowrap}}
dl.meta dt::after{{content:":"}}
dl.meta dd{{margin:0;overflow-wrap:anywhere;
font-family:ui-monospace,"SF Mono",Consolas,monospace;font-size:.83rem}}
.dim{{color:var(--dim);font-weight:400;font-size:.8rem}}
footer{{color:var(--dim);font-size:.8rem;margin-top:2.5rem;border-top:1px solid var(--rule);
padding-top:.8rem}}
@media (prefers-reduced-motion:no-preference){{html{{scroll-behavior:smooth}}}}
</style>
<main>
<h1>{e(m["name"])} — variable definitions</h1>
<p class="sub">{len(m["rows"])} definitions across {len(m["domains"])} domains ·
pack <code>{e(m["rel"])}</code>{(" · vendor " + e(m["vendor"])) if m["vendor"] else ""}</p>
{banner}
<div class="chips">{chips}</div>
{opens}
<input id="q" type="search" placeholder="Filter definitions — name, column, or any word of the rule…"
 aria-label="Filter definitions">
<nav>{nav}</nav>
{"".join(sections)}
<footer>GENERATED by <code>platform/tools/definitions_page.py</code> from
<code>{e(m["rel"])}/handoff/FUNCTIONAL_CONTRACT.md</code> at commit <code>{e(m["commit"])}</code>
on {e(m["generated"])} — do not edit; regenerate instead. Every definition above is the
contract record's own wording; statuses and decision states are read live from the governed
registers.</footer>
</main>
<script>
(function(){{var q=document.getElementById('q');if(!q)return;
q.addEventListener('input',function(){{var t=q.value.trim().toLowerCase();
document.querySelectorAll('.card').forEach(function(c){{
c.style.display=(!t||(c.getAttribute('data-search')||'').indexOf(t)>=0)?'':'none';}});
document.querySelectorAll('h2').forEach(function(h){{var any=false,n=h.nextElementSibling;
while(n&&n.tagName!=='H2'){{if(n.classList&&n.classList.contains('card')&&n.style.display!=='none')any=true;n=n.nextElementSibling;}}
h.style.display=(!t||any)?'':'none';}});}});}})();
</script>
"""


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack", help="path to a product or fixture pack")
    ap.add_argument("--out", help="write the HTML page here — refused inside the checkout")
    ap.add_argument("--summary", action="store_true", help="print the counts and exit")
    a = ap.parse_args(argv)
    if not os.path.isdir(a.pack):
        sys.exit(f"{a.pack}: no such pack directory. Nothing was rendered — this is a refusal, "
                 f"not an empty page.")
    m = model(os.path.abspath(a.pack))
    line = (f"{m['rel']}: {len(m['rows'])} definition(s), {len(m['domains'])} domain(s), "
            f"requirement axis {m['req_counts']}, {len(m['open_decisions'])} open decision(s)"
            + (" [ROLE: FIXTURE]" if m["role"] == "fixture" else ""))
    print(line)
    if a.summary and not a.out:
        return 0
    if not a.out:
        sys.exit("give --out <file outside the checkout> (or --summary). The page is a review "
                 "surface, not repository content.")
    out_abs = os.path.abspath(a.out)
    if (out_abs + os.sep).startswith(os.path.abspath(ROOT) + os.sep):
        sys.exit(f"--out {a.out} is inside the checkout — repo_hygiene reports every committed "
                 f"page as a saved web page, and a committed copy is free to go stale. Put it "
                 f"under your home directory instead.")
    with open(out_abs, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(render(m))
    print(f"wrote {out_abs}")
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
