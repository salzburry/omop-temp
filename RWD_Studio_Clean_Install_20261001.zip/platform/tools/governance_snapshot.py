#!/usr/bin/env python3
"""The six-gate standing of every pack, computed ONCE by a job so an app never computes it.

    python3 platform/tools/governance_snapshot.py --out /mnt/artifacts/results/snapshot.json
    python3 platform/tools/governance_snapshot.py --check /mnt/artifacts/results/snapshot.json

WHY THIS EXISTS, IN THE NUMBERS THE APP ALREADY MEASURED. `app/serve.py` computes its pages by
running the governed tools per request. Its own comments record what that costs: the cold board
took 66-116s, the cold flow render 78s — past the old 60s cap — "and every later request paid the
whole price again; concurrent requests each spawned their own subprocess and starved each other
past the timeout". Warming every pack at startup serialized ~24 heavy renders behind the first
visitor, and an external review measured status at 201s under that load, which is why the warm
pass was narrowed to the startable packs. A stakeholder opening a Domino app does not wait 78
seconds, and an app that re-warms on every restart pays it again on every restart.

The memo in `serve.py` already states the property that licenses this file: every heavy page is a
PURE FUNCTION OF THE SERVED COMMIT. If that is true — and `_proven()` refuses to serve the moment
the tree stops matching the commit — then the work can be done ONCE, by a job, and shipped as an
artifact, instead of being redone inside every app replica. That is the split a Domino deployment
wants: a Job builds the snapshot on each refresh, the App loads it and renders.

IT IS A RUNTIME ARTIFACT AND NEVER A COMMITTED ONE, and `--out` REFUSES a path inside the
checkout. `status.py --json` states the reason in its own help: a result carrying `evaluated_at`
cannot be byte-compared by a `--check`, "and a generated file that drifts every run teaches people
to ignore drift". Committing this would do exactly that, and `serve.py` already holds the matching
rule — every page it renders lands in a temp directory outside the tree, per the restricted-output
rule. On Domino this belongs in the job's artifact directory, the same place the upstream data
snapshots land.

IT RE-DERIVES NOTHING. Every gate state, blocker, measure and record state below is `status.py`'s,
which is itself an assembler over the tools that own each gate. This file enumerates packs, calls
that, and adds the provenance a consumer needs to refuse a stale answer. A snapshot that recounted
anything would be a second implementation of whichever tool owns that count, and the failure mode
is that it eventually reports a product to be in better shape than it is.

FAIL CLOSED, TWICE OVER. The snapshot records the commit it was built from AND whether the tree was
dirty at the time, because a snapshot built from a modified tree is NOT a pure function of a commit
and the whole argument above stops holding. `snapshot_errors()` is what a consumer calls before
trusting one; `serve.py` refusing a stale or dirty snapshot is the point, not an inconvenience.

A PACK THAT CANNOT BE READ IS NAMED, NEVER SKIPPED — `status.py`'s own discipline, for its own
reason: "a pack this tool cannot read is a finding about that pack, and a status page that quietly
omitted it would report fewer problems than exist." They land in `unreadable`, and a consumer that
renders the snapshot must show them.

READ-ONLY over the repository: it writes exactly one file, at the path given, outside the tree.

stdlib only (plus PyYAML, through the tools it calls).
"""
import argparse
import json
import os
import subprocess
import sys
from datetime import datetime, timezone

from rwd_services import workspace_root

ROOT = str(workspace_root(__file__))

from rwd_tools import product_gates  # noqa: E402
from rwd_tools import status         # noqa: E402

# Bumped when the SHAPE changes in a way a consumer must notice. A consumer refuses a schema it
# does not know rather than reading a familiar key out of an unfamiliar document.
SCHEMA = 1


def _git(*args, root=None):
    """git output, or None. A repository question this cannot answer is not guessed at."""
    r = subprocess.run(["git", *args], cwd=root or ROOT, capture_output=True, text=True,
                       encoding="utf-8")
    return (r.stdout or "").strip() if r.returncode == 0 else None


def provenance(generated_at=None, *, root=None):
    """What commit this was built from, and whether the tree still matched it.

    `dirty` is not decoration. The pure-function-of-the-commit argument is the only reason a
    snapshot may be reused at all, and it is FALSE for a modified tree. Recording it lets the
    consumer make that call instead of inheriting a silent assumption.
    """
    porcelain = _git("status", "--porcelain", root=root)
    return {"commit": _git("rev-parse", "HEAD", root=root),
            "commit_short": _git("rev-parse", "--short", "HEAD", root=root),
            "dirty": bool(porcelain) if porcelain is not None else None,
            "generated_at": generated_at or datetime.now(timezone.utc).isoformat(
                timespec="seconds")}


def packs(root=None):
    """Every pack this snapshot covers, products first, then reference fixtures.

    Enumerated through `product_gates`, which owns discovery and finds a pack BY SHAPE rather than
    by a fixed glob depth — the reason is recorded there: an added grouping level once made every
    pack under it vanish silently from a `products/*/*/*` glob while every CI loop stayed green.
    """
    root = root or ROOT
    return ([(p, "product") for p in product_gates.products(root)]
            + [(p, "fixture") for p in product_gates.fixture_packs(root)])


def build(root=None, generated_at=None):
    """The whole snapshot: provenance, one entry per pack, and the packs that could not be read."""
    root = root or ROOT
    out = {"schema": SCHEMA, "provenance": provenance(generated_at, root=root), "packs": {}, "unreadable": {},
           # WHO ACTS AT EACH GATE, taken from the one place that defines it. status.py says so in
           # its own words: "WHO ACTS is the exception, and it is defined ONCE, in `OWNER` below.
           # No module owns the gate→role map today; governance/WORKFLOW.md states it in prose,
           # and this is the machine-readable form of exactly that prose." A renderer that typed
           # its own role labels would be a second answer to a question that already has one.
           "owners": {str(k): v for k, v in status.OWNER.items()}}
    for rel, kind in packs(root):
        full = os.path.join(root, rel)
        try:
            with status.evaluation(root, full):
                current = status.payload(root, full)
                out["packs"][rel] = {"kind": kind,
                    **{key: current[key] for key in ('gates', 'measures', 'demonstrated', 'records')},
                    "next_action": status.next_action(root, full)}
        except Exception as e:                                    # noqa: BLE001
            # NAMED, never skipped — status.py's rule, for status.py's reason.
            out["unreadable"][rel] = f"{type(e).__name__}: {e}"
    return out


def same_commit(a, b):
    """Do these two strings name the same commit? git abbreviates, so they need not be equal.

    FOUND END TO END, NOT BY A UNIT TEST. The snapshot records `git rev-parse HEAD` (full, 40
    hex) while `serve.py`'s provenance carries the ABBREVIATED sha, so the first real page load
    refused itself: "describes commit df4b6a69b00b, the served commit is df4b6a6". The unit test
    could not see it because it used one form on both sides of the comparison — the reason an
    end-to-end run exists.

    A short sha IS a prefix of the long one, which is exactly git's own rule, so prefix matching
    is the correct comparison rather than a lenient one. Seven hex characters is git's default
    abbreviation and the floor here: below that a "prefix match" stops identifying a commit.
    """
    if not isinstance(a, str) or not isinstance(b, str) or not a or not b:
        return False
    short, long_ = (a, b) if len(a) <= len(b) else (b, a)
    return len(short) >= 7 and long_.startswith(short)


def snapshot_errors(snap, root, commit, allow_dirty=False):
    """[why this snapshot must not be trusted] — a consumer calls this BEFORE rendering it.

    `commit` is the commit the consumer is serving. A snapshot from another commit describes a
    different tree, and rendering it under the serving commit's footer would put stale gate states
    on screen over a clean provenance line — the precise failure `serve.py`'s `_proven()` exists to
    prevent, arriving by a different door.

    `root` AND `commit` ARE REQUIRED, WITH NO DEFAULT, and that is the whole defence. They were
    keyword arguments defaulting to None, and the staleness test read `if commit and ...` — so a
    caller who simply forgot the argument got a CLEAN VERDICT ON A STALE SNAPSHOT, silently. The
    first probe written against this function did exactly that and passed a snapshot stamped with
    a forty-zero commit. A check that quietly does not run is worse than no check, because it
    reports the same thing as a check that ran and found nothing; making the argument required
    turns that omission into a TypeError at the call site, immediately and loudly. Pass
    `commit=None` deliberately to say "I have no commit", and it is reported as unchecked rather
    than passed over.
    """
    out = []
    if not isinstance(snap, dict):
        return [f"snapshot is {type(snap).__name__}, not an object"]
    if type(snap.get("schema")) is not int or snap.get("schema") != SCHEMA:
        out.append(f"schema is {snap.get('schema')!r}, this reader knows {SCHEMA}")
    prov = snap.get("provenance")
    if not isinstance(prov, dict):
        out.append("no provenance block — the commit it describes is unknown")
        return out
    built_commit = prov.get("commit")
    if not built_commit:
        out.append("provenance carries no commit — staleness cannot be judged")
    elif not isinstance(built_commit, str):
        out.append("provenance commit is not a string — staleness cannot be judged")
    if prov.get("dirty") is True and not allow_dirty:
        out.append("built from a MODIFIED tree, so it is not a pure function of any commit — "
                   "rebuild it from a clean checkout")
    if prov.get("dirty") is None:
        out.append("whether the tree was clean was not recorded — treat as unusable")
    elif not isinstance(prov.get("dirty"), bool):
        out.append("provenance dirty must be a boolean — whether the tree was clean is malformed")
    if commit is None:
        # SAID, NOT SKIPPED. The consumer explicitly has no commit to compare against, so the
        # staleness question is OPEN — and an open question is reported, never silently answered
        # in the affirmative.
        out.append("no serving commit was supplied, so whether this snapshot is stale could not "
                   "be judged — pass the commit the app is serving")
    elif not isinstance(commit, str):
        out.append("the serving commit is not a string — staleness cannot be judged")
    elif isinstance(built_commit, str) and built_commit and not same_commit(built_commit, commit):
        out.append(f"describes commit {built_commit[:12]}, the served commit is {commit[:12]}")
    unreadable = snap.get("unreadable", {})
    if not isinstance(unreadable, dict):
        out.append("unreadable must be an object mapping pack paths to their errors")
        unreadable = {}
    if "owners" in snap and not isinstance(snap["owners"], dict):
        out.append("owners must be an object mapping gates to their owners")
    if not isinstance(snap.get("packs"), dict):
        out.append("no packs object")
    elif not snap["packs"] and not snap.get("unreadable"):
        out.append("covers no packs at all — an empty snapshot is a refusal, not a clean result")
    if isinstance(snap.get("packs"), dict):
        # Validate the containers the portal and agent actually iterate. A JSON object
        # at the top level does not establish that a pack entry can be rendered.
        for rel, entry in snap["packs"].items():
            if not isinstance(rel, str):
                out.append("packs contains a non-string pack path")
            if not isinstance(entry, dict):
                out.append(f"{rel}: pack entry is not an object")
                continue
            for field, shape in (("gates", list), ("measures", dict),
                                 ("demonstrated", list), ("records", dict)):
                if field not in entry or (field == "records" and entry[field] is None):
                    continue  # status.record_states returns None for an absent contract
                if not isinstance(entry[field], shape):
                    out.append(f"{rel}: {field} must be a {shape.__name__}")
            for field in ("gates", "demonstrated"):
                if not isinstance(entry.get(field), list):
                    continue
                for index, row in enumerate(entry[field]):
                    if not isinstance(row, dict):
                        out.append(f"{rel}: {field}[{index}] is not an object")
                    elif field == "gates" and "blockers" in row and not isinstance(row["blockers"], list):
                        out.append(f"{rel}: gates[{index}].blockers must be a list")
    if any(not isinstance(rel, str) for rel in unreadable):
        out.append("unreadable contains a non-string pack path")
    if root is not None and isinstance(snap.get("packs"), dict):
        # THE SET MUST MATCH WHAT THIS CHECKOUT HOLDS. A snapshot missing a pack renders a shorter
        # board than the truth, which is the same silent-omission failure discovery is designed
        # against — and neither side is trusted blindly: each is checked against the other.
        here = {rel for rel, _ in packs(root)}
        covered = {rel for rel in set(snap["packs"]) | set(unreadable) if isinstance(rel, str)}
        for rel in sorted(here - covered):
            out.append(f"{rel} exists in this checkout but is absent from the snapshot")
        for rel in sorted(covered - here):
            out.append(f"{rel} is in the snapshot but not in this checkout")
    return out


def load(path, root, commit, allow_dirty=False):
    """(snapshot, errors). A file that will not parse is an ERROR, never an empty snapshot.

    Returning `{}` for unreadable JSON is the fail-open this repository has been bitten by
    elsewhere: an empty document reads as "nothing to report" and a board renders clean.
    """
    try:
        with open(path, encoding="utf-8") as fh:
            snap = json.load(fh)
    except OSError as e:
        return None, [f"{path}: cannot be read — {e}"]
    except ValueError as e:
        return None, [f"{path}: is not valid JSON — {e}"]
    return snap, snapshot_errors(snap, root=root, commit=commit, allow_dirty=allow_dirty)


def out_path_errors(path, root=None):
    """[why this is not a legal destination] — asked BEFORE the build, never after.

    Separate from `write()` for a reason a test found immediately: building takes minutes (219s
    for 13 packs, measured), and a refusal that arrives after that work has been done is a refusal
    nobody will wait for. Everything knowable up front is checked up front.
    """
    root = os.path.abspath(root or ROOT)
    full = os.path.abspath(path)
    try:
        inside = os.path.commonpath([full, root]) == root
    except ValueError:                    # different drives on Windows — plainly outside
        inside = False
    if inside:
        return [f"{path} is inside the checkout — this is a runtime artifact and committing one "
                f"that changes every run teaches people to ignore drift (status.py --json says so "
                f"for the same reason). Write it to the job's artifact directory instead."]
    parent = os.path.dirname(full)
    if parent and not os.path.isdir(parent):
        return [f"{parent} does not exist"]
    return []


def write(snap, path, root=None):
    """Write the snapshot. Returns [] or the refusals — the path is re-checked, not assumed."""
    problems = out_path_errors(path, root)
    if problems:
        return problems
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)   # the state dir may not exist yet
    with open(os.path.abspath(path), "w", encoding="utf-8", newline="\n") as fh:
        fh.write(json.dumps(snap, indent=1, default=str))
    return []


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Build (or check) the six-gate snapshot an app loads instead of computing.")
    ap.add_argument("--out", help="where to write it — MUST be outside the checkout")
    ap.add_argument("--check", metavar="PATH",
                    help="validate an existing snapshot against this checkout and say why not")
    ap.add_argument("--allow-dirty", action="store_true",
                    help="build from (or accept) a modified tree — for local development only; "
                         "the result is not a pure function of any commit and says so")
    a = ap.parse_args(argv)

    if a.check:
        snap, errs = load(a.check, root=ROOT, commit=_git("rev-parse", "HEAD"),
                          allow_dirty=a.allow_dirty)
        if errs:
            print("", file=sys.stderr)
            print(f"REFUSED — {len(errs)} problem(s):", file=sys.stderr)
            for e in errs:
                print(f"  {e}", file=sys.stderr)
            return 1
        prov = snap["provenance"]
        print(f"ok — {len(snap['packs'])} pack(s) at {prov['commit_short']}, "
              f"built {prov['generated_at']}")
        if snap.get("unreadable"):
            print(f"  {len(snap['unreadable'])} pack(s) could not be read when it was built")
        return 0

    if not a.out:
        ap.error("give --out (to build) or --check PATH (to validate)")

    # EVERYTHING KNOWABLE BEFORE THE WORK IS CHECKED BEFORE THE WORK. Both of these once ran
    # after `build()`, which meant an illegal path and a modified tree were each reported four
    # minutes late; the first test written against this file timed out on exactly that.
    problems = out_path_errors(a.out, ROOT)
    if _git("status", "--porcelain") and not a.allow_dirty:
        problems.append("the tree is modified, so this snapshot would not be a pure function of "
                        "any commit; that property is the only reason an app may reuse it. "
                        "Commit, stash, or pass --allow-dirty for local work.")
    if problems:
        print("", file=sys.stderr)
        print(f"REFUSED — {len(problems)} problem(s):", file=sys.stderr)
        for p in problems:
            print(f"  {p}", file=sys.stderr)
        return 1

    snap = build(ROOT)
    problems = write(snap, a.out, ROOT)
    if problems:
        print("", file=sys.stderr)
        print(f"REFUSED — {len(problems)} problem(s):", file=sys.stderr)
        for p in problems:
            print(f"  {p}", file=sys.stderr)
        return 1
    prov = snap["provenance"]
    print(f"wrote {a.out}")
    print(f"  {len(snap['packs'])} pack(s) at {prov['commit_short']}")
    for rel, why in sorted(snap["unreadable"].items()):
        print(f"  COULD NOT BE READ: {rel} — {why}")
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    raise SystemExit(main())
