#!/usr/bin/env python3
"""Can this machine run this package, and what can it not do?

    python platform/tools/doctor.py            # every check, and what each missing thing costs
    python platform/tools/doctor.py --quiet     # only what is wrong

WHY THIS EXISTS. The first thing a colleague does with a clone is run something, and the first way
this repository fails a stranger is not a bug — it is a missing dependency, an unwritable output
directory or a console code page, each of which surfaces as a traceback several steps into a tool
that had nothing to do with it. `pip install -r requirements.txt` failing is legible; `openpyxl`
missing is a stack trace from inside a dictionary renderer.

TWO KINDS OF FINDING, and conflating them is what makes an environment check useless:

  REQUIRED   nothing works without it. The exit code is non-zero and the demo will not run.
  OPTIONAL   something specific does not work. PySpark's absence is not a defect — the engine
             stages are one of five things this package does — but "optional" printed alone tells
             you nothing, so each says WHICH capability you do not have.

DERIVES THE REQUIREMENT LIST FROM requirements.txt rather than restating it. A second list here
would agree on the day it was written and drift the first time a dependency moved, and it would
drift in the direction of reporting green.

stdlib only, deliberately: a dependency check that cannot run without its dependencies is a joke
somebody has to debug at the worst possible moment.
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))

from rwd_tools import console                                                             # noqa: E402
from rwd_tools.runtime_discovery import find_rscript                                 # noqa: E402

OK, MISSING, LIMITED = "ok", "MISSING", "limited"

# The floor the code is written against, and the reason, so raising it is a decision rather than a
# drift. The backend retains its Python 3.11 floor; local application setup uses
# Python 3.13. Installed packages and executable prerequisites are checked below.
MIN_PYTHON = (3, 11)
# Maintenance release containing SPARK-53759 (Windows Python 3.12+ worker shutdown).
SPARK_VERSION = "4.0.4"
SUPPORTED_JAVA = (17, 21)

# WHAT AN OPTIONAL PIECE BUYS, in the terms of this repository's own steps. "PySpark: not installed"
# is a fact nobody can act on; "you cannot run the engine stages" is the same fact as a decision.
OPTIONAL = (
    ("pyspark", "import", "run the engine stage suites or build an ADS off-cluster",
     f'python -m pip install "pyspark=={SPARK_VERSION}"'),
    ("Rscript", "exe", "parse-check the R engine, run R<->Python parity, or run the data profiler",
     "install R (r-base-core)"),
    ("databricks", "exe", "deploy or run the Asset Bundle",
     "https://docs.databricks.com/en/dev-tools/cli/index.html"),
)


def requirements(path=None):
    """[(distribution, import name)] from requirements.txt — the file pip is pointed at, not a copy.

    The import name is not the distribution name for every package here, and guessing it by
    lowercasing is how a check reports a missing dependency that is installed. Only the ones that
    differ are listed; everything else imports under its own name.
    """
    other_name = {"pyyaml": "yaml"}
    path = path or os.path.join(ROOT, "platform", "requirements.txt")
    out = []
    if not os.path.exists(path):
        return out
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.split("#")[0].strip()
            if not line:
                continue
            dist = re.split(r"[<>=!~\[]", line)[0].strip()
            if dist:
                out.append((dist, other_name.get(dist.lower(), dist.replace("-", "_"))))
    return out


def _importable(name):
    import importlib.util
    try:
        return importlib.util.find_spec(name) is not None
    except (ImportError, ValueError):
        return False


def checks(out_dir=None):
    """[(status, subject, detail, what to do)] — every check, in the order a reader needs them.

    ORDERED BY WHAT BLOCKS WHAT. The interpreter before the packages it imports, the packages before
    the checkout that uses them, the checkout before the output directory the tools write to. A
    report that leads with a console code page while Python is too old has buried the answer.
    """
    rows = []

    have = sys.version_info[:3]
    rows.append((OK if have >= MIN_PYTHON else MISSING, "Python",
                 f"{'.'.join(map(str, have))} at {sys.executable}",
                 "" if have >= MIN_PYTHON
                 else f"this package needs {'.'.join(map(str, MIN_PYTHON))} or newer"))

    wanted = requirements()
    if not wanted:
        rows.append((MISSING, "requirements.txt", "not found beside platform/",
                     "this checkout is incomplete — re-clone it"))
    for dist, module in wanted:
        rows.append((OK if _importable(module) else MISSING, dist,
                     f"import {module}", "" if _importable(module)
                     else "pip install -r platform/requirements.txt"))

    # THE CHECKOUT ITSELF. Several tools read git state — the deployment tree refuses to bind a
    # release to a dirty or unresolvable HEAD — so "is this a git repository at all" is a question
    # the walkthrough's answer depends on, and a downloaded zip is a real way to arrive here.
    rows.append((OK if shutil.which("git") else MISSING, "git", "on PATH",
                 "" if shutil.which("git") else "install git — the packaging steps read HEAD"))
    if shutil.which("git"):
        code, head = _git("rev-parse", "--short", "HEAD")
        rows.append((OK if code == 0 else LIMITED, "git HEAD", head or "not a git repository",
                     "" if code == 0 else
                     "the packaging steps report instead of scoring — clone rather than download"))

    # WHERE RESTRICTED OUTPUT GOES. `pack_run.restricted_dir` REFUSES a path inside the checkout, and
    # that refusal is a control rather than an inconvenience: a profile or a schema report in the
    # tree is readable by every indexing tool and agent on the machine. So the question is not "can
    # I write" but "do I have somewhere outside the repository to write to".
    target = out_dir or os.path.join(os.path.expanduser("~"), "rwdp-out")
    rows.append(_safely(_writable, "output directory", target))

    rows.append(_safely(_console, "console encoding"))

    for name, kind, capability, fix in OPTIONAL:
        present = (_importable(name) if kind == "import" else
                   bool(find_rscript()) if name == "Rscript" else bool(shutil.which(name)))
        rows.append((OK if present else LIMITED, name,
                     ("executable located; execution and R packages not checked" if name == "Rscript" else "installed")
                     if present else f"absent — you cannot {capability}",
                     "" if present else fix))

    rows.append(_safely(_spark_runtime, "local spark"))
    rows.append(_safely(_checkout_location, "checkout location"))
    return rows


# Sync roots by ENVIRONMENT VARIABLE, not by folder name: corporate OneDrive is redirected and
# renamed per tenant ("OneDrive - <org>"), so matching the literal string misses the deployments
# most likely to have the problem. The name check stays as a fallback for the ones that set no
# variable.
SYNC_ENV = ("OneDrive", "OneDriveCommercial", "OneDriveConsumer", "Dropbox")
SYNC_NAMES = ("onedrive", "dropbox", "google drive", "my drive", "box sync", "icloud")


def _checkout_location():
    """Is this checkout inside a sync folder or on a network path?

    A REPORT, NOT A REFUSAL. The tools all work from a synced folder — slowly, and with two
    failure modes that never announce themselves as location problems: the sync filter
    intercepts every read and write, so git and the suites crawl; and when two machines touch
    the clone, OneDrive writes "conflicted copy" duplicates INSIDE .git, which corrupts the
    repository quietly. Both get attributed to something else, which is exactly why this check
    exists — nobody leaves a repo in OneDrive on purpose, they leave it there because the
    default redirects Documents and nothing ever says so.
    """
    root = os.path.realpath(ROOT)
    low = root.lower()
    for var in SYNC_ENV:
        base = os.environ.get(var, "")
        if base and low.startswith(os.path.realpath(base).lower() + os.sep):
            return (LIMITED, "checkout location",
                    f"inside {var} ({root}) — sync filters slow every git and file operation, "
                    f"and .git can accumulate 'conflicted copy' duplicates that corrupt the "
                    f"repository silently",
                    "clone to a plain local path and delete this copy — keeping two checkouts "
                    "is how edits land in one tree while checks read the other")
    hit = next((n for n in SYNC_NAMES if n in low), None)
    if hit:
        return (LIMITED, "checkout location",
                f"path contains '{hit}' ({root}) — if that is a sync folder, every git and file "
                f"operation goes through its filter and .git can collect conflict copies",
                "clone to a plain local path if it is synced")
    if root.startswith("\\\\") or low.startswith("//"):
        return (LIMITED, "checkout location",
                f"on a network path ({root}) — every file the tools read crosses the network, and "
                f"git's locking is unreliable over SMB",
                "clone to a local disk")
    return (OK, "checkout location", f"local, unsynced ({root})", "")


def _spark_runtime():
    """Check prerequisites without starting a Spark session or scoring a build.

    Spark 4.0.4 includes the Python 3.12+ Windows worker fix from SPARK-53759.
    Spark supports Python 3.9+ and Java 17+. The repository retains a stricter
    Python floor and supports Java 17 or 21 for its pipeline. Probe the selected
    Java and worker interpreter rather than
    treating a Python minor version as evidence of a worker failure or success.
    Actual scientific output checks remain in the existing synthetic build suites.
    """
    if not _importable("pyspark"):
        return (LIMITED, "local spark", "pyspark absent — governance demo unaffected; "
                "no engine stage or synthetic build runs on this machine",
                f'python -m pip install "pyspark=={SPARK_VERSION}"')
    try:
        import pyspark                                                    # noqa: PLC0415
    except (ImportError, OSError):
        return (LIMITED, "local spark", "pyspark is installed but could not import",
                "finish or repair the environment installation before running a local build")
    py = ".".join(str(v) for v in sys.version_info[:3])
    if sys.version_info[:2] < MIN_PYTHON:
        return (LIMITED, "local spark", f"python {py} is below the backend requirement",
                "use the Python 3.13 environment selected for this application")
    if pyspark.__version__ != SPARK_VERSION:
        return (LIMITED, "local spark",
                f"pyspark {pyspark.__version__} differs from the tested engine pin {SPARK_VERSION}",
                f'python -m pip install "pyspark=={SPARK_VERSION}"')
    try:
        from rwd_tools import java_home                                                  # noqa: PLC0415
        java_home.ensure()          # a JDK unpacked under the person's application-data folder counts (2026-09-07)
    except ImportError:
        pass
    java_home_path = os.environ.get("JAVA_HOME", "")
    java = os.path.join(java_home_path, "bin", "java.exe" if os.name == "nt" else "java")
    java = java if java_home_path and os.path.isfile(java) else shutil.which("java")
    if not java:
        return (LIMITED, "local spark",
                f"pyspark {pyspark.__version__} imports but NO JVM is reachable "
                f"(JAVA_HOME unset, no `java` on PATH) — imports prove packaging, not "
                f"execution; governance demo unaffected",
                "install a JDK 17 (Temurin zip needs no admin) and set JAVA_HOME")
    try:
        probe = console.run([java, "-version"], timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        return (LIMITED, "local spark",
                "Java was located but its version check could not complete",
                "check the selected Java installation and retry; this pipeline supports Java 17 or 21")
    version = re.search(r'(?:openjdk|java) version "(?:1\.)?(\d+)',
                        (probe.stdout or "") + (probe.stderr or ""))
    if probe.returncode != 0 or not version or int(version.group(1)) not in SUPPORTED_JAVA:
        return (LIMITED, "local spark", "a supported Java 17 or 21 runtime was not verified",
                "select a working JDK 17 or 21 with JAVA_HOME")
    worker = os.environ.get("PYSPARK_PYTHON") or sys.executable
    try:
        probe = console.run([worker, "-c", "import sys; print('%s.%s' % sys.version_info[:2])"], timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        return (LIMITED, "local spark", "the selected Python worker could not start",
                "set PYSPARK_PYTHON to this application's Python executable and retry")
    expected = ".".join(str(v) for v in sys.version_info[:2])
    if probe.returncode != 0 or (probe.stdout or "").strip() != expected:
        return (LIMITED, "local spark", f"the Python worker does not match driver Python {expected}",
                "set PYSPARK_PYTHON and PYSPARK_DRIVER_PYTHON to this application's Python executable")
    detail = (f"python {py}, pyspark {pyspark.__version__}, Java {version.group(1)}, "
              f"matching Python {expected} worker; prerequisites available; Spark execution not checked")
    return (OK, "local spark", detail,
            "run the existing local synthetic build to verify worker execution and expected outputs")


def _safely(check, subject, *args):
    """Run one check; turn any explosion into a ROW rather than a traceback.

    A DIAGNOSTIC MAY NOT DIE OF THE THING IT DIAGNOSES. The output-directory check imported a module
    that imports yaml, so on a machine with no PyYAML this tool exited with an ImportError traceback
    having printed nothing — the person is told nothing, least of all that PyYAML is what is missing.
    That specific import is gone; this makes the class of failure impossible rather than that one
    instance of it, because the next check somebody adds will reach for something too.

    Reported as MISSING, not swallowed: a check that could not run has not passed.
    """
    try:
        return check(*args)
    except Exception as err:                                  # noqa: BLE001 — deliberate, see above
        return (MISSING, subject, f"the check itself failed: {type(err).__name__}: {err}",
                "this is a defect in doctor.py — report it with the line above")


def _git(*args):
    if not shutil.which("git"):
        return 1, ""
    p = console.run(["git", "-C", ROOT] + list(args), capture_output=True)
    return p.returncode, (p.stdout or "").strip()


def _writable(target):
    """Whether restricted output has somewhere to go — CREATING NOTHING on the way to the answer.

    A first version called `os.makedirs` and left the directory behind, including one inside the
    checkout while it was busy deciding that directory was not allowed. A check with a side effect is
    not a check: run it twice and the second run is answering a question about the first.

    So it walks UP to the nearest existing ancestor and probes there. That is the same question — a
    path is creatable exactly when some ancestor of it is writable — asked without making anything.
    """
    # `spec_extract.inside_checkout`, NOT `pack_run.restricted_dir`. Same predicate, same owner — but
    # `pack_run` imports product_gates and engine.config, both of which import yaml, so asking it
    # crashed this tool with an ImportError on a machine with no PyYAML. That is the exact machine
    # this tool exists to diagnose, and it died before printing the row that says PyYAML is missing.
    from rwd_tools.spec_extract import inside_checkout
    resolved = os.path.realpath(os.path.expanduser(target))
    if inside_checkout(resolved, ROOT):
        return (MISSING, "output directory", f"{resolved} is inside the checkout",
                "choose a directory outside the repository — restricted output may not be committed")
    exists = resolved
    while not os.path.isdir(exists):
        parent = os.path.dirname(exists)
        if parent == exists:                         # walked off the top of the filesystem
            return (MISSING, "output directory", f"{resolved} has no existing parent",
                    "pass --out-dir a path whose parent exists")
        exists = parent
    if not os.access(exists, os.W_OK):
        return (MISSING, "output directory", f"{resolved} is not writable ({exists} is read-only)",
                "pass --out-dir somewhere you can write")
    note = "" if exists == resolved else f" (will be created under {exists})"
    return (OK, "output directory", f"{resolved} is writable and outside the checkout{note}", "")


def _console():
    """Whether this console can DISPLAY what the tools print, after they have configured it.

    `console.use_utf8()` has already run by the time this is reached from `__main__`, so what is
    measured is the state a tool actually prints into — not the interpreter's default, which is what
    a check written the obvious way would report and which the tools override.

    LIMITED, never MISSING. `errors="replace"` means an undisplayable character costs one glyph, not
    the report; a code page is a display concern and refusing to run over one would be theatre.
    """
    enc = getattr(sys.stdout, "encoding", None) or "unknown"
    sample = "— · «»"
    try:
        sample.encode(enc)
    except (UnicodeEncodeError, LookupError):
        return (LIMITED, "console encoding", f"{enc} cannot show {sample!r} — glyphs are replaced",
                "on Windows: chcp 65001, or read the tools' --out files instead of the terminal")
    return (OK, "console encoding", f"{enc} shows every character the tools print", "")


def report(rows, quiet=False):
    """The rows as text. Returns the number of REQUIRED failures — the thing the exit code is."""
    bad = [r for r in rows if r[0] == MISSING]
    limited = [r for r in rows if r[0] == LIMITED]
    width = max([len(r[1]) for r in rows] + [10])
    lines = []
    if not quiet:
        lines.append(f"environment for {ROOT}")
        lines.append("")
        for status, subject, detail, _fix in rows:
            mark = {OK: "  ok ", MISSING: "  !! ", LIMITED: "  -- "}[status]
            lines.append(f"{mark}{subject:<{width}}  {detail}")
        lines.append("")
    if bad:
        lines.append(f"{len(bad)} REQUIRED thing(s) missing — the demo will not run:")
        for _s, subject, detail, fix in bad:
            lines.append(f"   {subject}: {detail}")
            if fix:
                lines.append(f"      -> {fix}")
    if limited and not quiet:
        # "absent" was right while every LIMITED row was a missing optional dependency; the
        # checkout-location row is a CONDITION, not an absence, and calling it absent would make
        # the one finding people most need to act on read like a package they chose not to install.
        lines.append(f"{len(limited)} limitation(s). Everything else still runs:")
        for _s, subject, detail, fix in limited:
            lines.append(f"   {subject}: {detail}")
            if fix:
                lines.append(f"      -> {fix}")
    if not bad:
        spark = next((r for r in rows if r[1] == "local spark"), None)
        lines.append("")
        lines.append("READY for the GOVERNANCE demo (pure-python tools). "
                     "Next: python platform/tools/demo.py fixtures/oncology/prostate/202606")
        if spark is not None:
            lines.append("Local Spark: " + ("prerequisites available — " if spark[0] == OK else "NOT verified — ")
                         + spark[2])
    print("\n".join(lines))
    return len(bad)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("--out-dir", help="where restricted output would go (default ~/rwdp-out). "
                                      "Checked for being writable and OUTSIDE the checkout.")
    ap.add_argument("--quiet", action="store_true", help="print only what is wrong")
    ap.add_argument("--json", action="store_true", help="print a versioned machine-readable readiness report")
    a = ap.parse_args(argv)
    rows = checks(a.out_dir)
    if a.json:
        result = structured_report(rows)
        print(json.dumps(result, sort_keys=True, ensure_ascii=True))
        return result["exit_code"]
    return 1 if report(rows, a.quiet) else 0


def structured_report(rows):
    """Version 1 diagnostic contract. Ready means prerequisites, not execution."""
    checks = [{"status": {OK: "ok", MISSING: "missing", LIMITED: "limited"}[status],
               "subject": subject, "reason": reason, "action": action}
              for status, subject, reason, action in rows]
    required_ready = not any(row["status"] == "missing" for row in checks)
    spark = next((row for row in checks if row["subject"] == "local spark"), None)
    local_spark = {"ready": bool(spark and spark["status"] == "ok"),
                   "status": spark["status"] if spark else "not_checked",
                   "reason": spark["reason"] if spark else "Local Spark prerequisites were not checked.",
                   "action": spark["action"] if spark else "Run doctor.py again and inspect its local Spark check.",
                   "execution_checked": False}
    return {"schema_version": 1, "ready": required_ready, "exit_code": 0 if required_ready else 1,
            "checks": checks, "local_spark": local_spark}


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
