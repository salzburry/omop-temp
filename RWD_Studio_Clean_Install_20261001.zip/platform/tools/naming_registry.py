#!/usr/bin/env python3
"""The cross-pack variable-name registry: one shelf of what things are called, and the drift gate.

    python3 platform/tools/naming_registry.py                # the registry + the unruled docket
    python3 platform/tools/naming_registry.py --format json

WHY THIS EXISTS. Specifications are written by different people, and two of them will name one
concept two ways — `agegrp` here, `age_group` there. Nothing refused that: the engine-owned
column names are standard by construction, but pack-authored names (passthroughs, derived items,
panel flags) were convention only, and the first sweep of this tool found live drift the
convention had already let through (a pack's `region1`/`region1n` beside the engine's
`regionl`/`regionln` — digit one against letter el).

WHAT IT DOES. Compiles every pack's contract `output` axis (physical_name / name_status, through
contract_lint's own parsers) plus the engine's emitted names into one registry, then flags
NEAR-MISSES: two names close enough to be one concept spelled twice, that are NOT twins under
the repo's own suffix grammar (label/code `x`/`xn`, date `xdt`, year `xyr`, flag `xfl`,
duration `xdur`, type/diagnosis-date `xtype`/`xdd`, banded `xgr1`/`xgrl`(+`n`), and per-setting
`x_<setting>` variants — those are the standard WORKING, never drift).

WHAT IT NEVER DOES. It never decides that two names are the same concept, and it never renames
anything. A flagged pair is a QUESTION, and the answer is a human ruling recorded in
governance/NAMING_RULINGS.yaml — signed, dated, one of a closed vocabulary:

    rulings:
      - {a: agegrp, b: age_group, ruling: use_existing,     # the new name yields to the standard
         standard: age_group, decision_id: NAME-1, ruled_by: A Person, ruling_date: 2026-01-01}
        # ruling vocabulary: use_existing | distinct_concepts | alias_accepted

A pair with no ruling is OPEN WORK the docket reports; a ruling that is not a named person's
dated act does not count. A ruling on a pair covers the pair's twin families too (ruling on
(cohort, cohortu) also settles (cohortn, cohortun)) — one question, one answer, not four.
Contradictory current rulings keep that family open. An explicitly reviewed replacement
appends `supersedes: [<ruling_ref(old_record)>, ...]`, naming every conflicting current record.
Exact-content references work for existing records without modifying them; history remains.
A missing, unrelated or already superseded reference cannot close the question.

THE OTHER AXIS IS TIME, and it is `governance/NAME_LIFECYCLE.yaml`. The registry is built from
what packs carry TODAY, so a name dropped at the next cut leaves no trace — and nothing would
stop the same spelling being minted later for a different concept, quietly re-pointing every
citation ever written against the old meaning. That file records retirements (successor, the
variable ids the name was retired from, the person and date) and enterprise identifier bindings;
`--retire <name>` prints the draft. The checks report a retired name that came back carrying a
NEW variable id as reuse, an unfinished migration as unfinished, a successor no pack defines as
dangling, and two names claiming one IRI as the same collision in identifier space.

stdlib + the repo's own readers. AI drafts questions; the naming UI saves a person's explicit
reviewed supersession. Neither the registry nor AI chooses a clinical naming decision.
"""
import argparse
import glob
import json
import os
import re
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))

from rwd_tools import contract_lint as cl                                             # noqa: E402

RULINGS_PATH = os.path.join(ROOT, "governance", "NAMING_RULINGS.yaml")
RULING_KINDS = ("use_existing", "distinct_concepts", "alias_accepted")
LIFECYCLE_PATH = os.path.join(ROOT, "governance", "NAME_LIFECYCLE.yaml")

# THE RATCHET, and it is what turns this tool from a report into a gate. Until now `main()` exited
# 0 with the docket full: 258 names, 29 unruled near-miss pairs, 0 rulings. Nothing in CI ran it
# and no gate imported it, so a thirtieth collision cost nothing and the docket only ever grew.
#
# REFUSING ALL 29 TODAY WOULD BE A GATE NOBODY COULD PASS, and a gate people route around is worse
# than none. So the known pairs are recorded here as a floor, exactly as `source_check`'s legacy
# allowlist is: `write_baseline` can SHRINK this file and never grow it, so clearing a pair is one
# command and adding one is a hand edit that shows up in review. A NEW pair fails.
#
# A BASELINED PAIR IS UNRULED, NOT ACCEPTED. This file records that nobody has decided yet; it is
# not a decision. The decision goes in NAMING_RULINGS.yaml, with a named person and a date, and
# ruling a pair is what removes it from here.
BASELINE_PATH = os.path.join(ROOT, "governance", "NAMING_BASELINE.yaml")


def _pair_key(a, b):
    """One key per unordered pair, so `x ~ y` and `y ~ x` are the same collision."""
    return "~".join(sorted((str(a).strip().lower(), str(b).strip().lower())))


def baseline():
    """({pair key}, [problem]) from the recorded floor. Absent is an EMPTY floor, not a pass.

    A missing file means every open pair is new, which is the strict reading and the safe one: the
    alternative is a deleted baseline silently disabling the gate.
    """
    from rwd_tools.product_gates import read_yaml                                # noqa: PLC0415
    if not os.path.exists(BASELINE_PATH):
        # A DELETED FLOOR MUST NOT DISABLE THE GATE. Every open pair then reads as new, which fails
        # loudly, rather than an empty floor quietly meaning "nothing to check".
        return set(), []
    doc, err = read_yaml(BASELINE_PATH)     # the ONE governed-YAML reader: a parse failure is a
    if err:                                 # finding, never a traceback out of a gate
        return set(), [f"NAMING_BASELINE.yaml: {err}"]
    doc = doc or {}
    keys, seen, problems = set(), set(), []
    for i, e in enumerate(doc.get("pairs") or []):
        if not isinstance(e, dict) or not e.get("a") or not e.get("b"):
            problems.append(f"pairs[{i}]: needs both `a` and `b`")
            continue
        k = _pair_key(e["a"], e["b"])
        if k in seen:
            problems.append(f"pairs[{i}]: {k} is recorded twice")
            continue
        seen.add(k)
        keys.add(k)
    return keys, problems


def baseline_findings(d, floor):
    """([pair above the floor], [floor entry no longer open]) for a docket and a recorded floor."""
    open_keys = {_pair_key(f["a"], f["b"]): f for f in d.get("open") or []}
    fresh = [open_keys[k] for k in sorted(set(open_keys) - set(floor))]
    stale = sorted(set(floor) - set(open_keys))
    return fresh, stale


def gate_errors(d=None, floor=None):
    """Everything that must FAIL a build, or []. The tool's exit code is a function of this.

    FOUR CLASSES, and they are not the same kind of thing. A malformed ruling, a lifecycle finding
    and a type conflict are DEFECTS in what somebody wrote, refused outright. A new near-miss pair
    is a QUESTION nobody has answered, refused only because it is new — the ones already on the
    floor are equally unanswered and equally not this change's fault.
    """
    d = docket() if d is None else d
    floor = baseline()[0] if floor is None else floor
    out = [f"RULING PROBLEM: {p}" for p in d.get("ruling_problems") or []]
    out += [f"{f['kind']}: {f['detail']}" for f in d.get("lifecycle") or []]
    out += [f"TYPE CONFLICT: {c['question']}" for c in d.get("type_conflicts") or []]
    fresh, _stale = baseline_findings(d, floor)
    for f in fresh:
        out.append(f"NEW NAMING COLLISION: {f['a']} ~ {f['b']} "
                   f"[{', '.join(f['a_where'][:2])} vs {', '.join(f['b_where'][:2])}] — rule it in "
                   f"governance/NAMING_RULINGS.yaml, or rename. It is not on the recorded floor, "
                   f"so this change introduced it.")
    return out


def write_baseline(d=None, seed=False):
    """Rewrite the floor, keeping ONLY pairs that are still open. It can never grow.

    That asymmetry is the whole mechanism, and it is the rule `source_check.write_legacy_allowlist`
    states for its own allowlist: if regenerating could add a pair, the floor becomes a cache of
    whatever is broken today and the gate stops meaning anything. Clearing a pair is one command;
    adding one is a hand edit somebody has to defend in review.

    SEEDING IS A DIFFERENT ACT AND IS DONE ONCE. A shrink-only file cannot create itself, so the
    first write takes the pairs that were already open when the gate was introduced. `--seed` is
    refused once the file exists, because from then on the only honest way to add a pair is to
    write the line and let a reviewer see it.
    """
    d = docket() if d is None else d
    floor, _p = baseline()
    open_keys = {_pair_key(f["a"], f["b"]): f for f in d.get("open") or []}
    if seed:
        if os.path.exists(BASELINE_PATH):
            raise RuntimeError(
                f"{os.path.basename(BASELINE_PATH)} already exists — seeding again would let a "
                f"new collision be regenerated onto the floor, which is the one thing the floor "
                f"exists to prevent. Rule the pair, rename, or add the line by hand.")
        keep = sorted(open_keys)
    else:
        keep = sorted(set(floor) & set(open_keys))
    lines = [
        "# The near-miss name pairs that were already open when the naming gate was introduced.",
        "#",
        "# A PAIR HERE IS UNRULED, NOT ACCEPTED. This file records that nobody has decided whether",
        "# two similar names are one concept or two; it is not the decision. The decision belongs in",
        "# governance/NAMING_RULINGS.yaml with a named person and a date, and recording one is what",
        "# removes the pair from here.",
        "#",
        "# THIS FILE CAN ONLY SHRINK. `naming_registry.py --write-baseline` keeps only pairs that are",
        "# still open and never adds one, so a NEW collision fails the gate and cannot be regenerated",
        "# away. Adding a line by hand is possible and is meant to be visible in review.",
        "",
        "pairs:",
    ]
    for k in keep:
        f = open_keys[k]
        lines.append(f"  - a: {f['a']}")
        lines.append(f"    b: {f['b']}")
        lines.append(f"    where: {', '.join(f['a_where'][:2])} vs {', '.join(f['b_where'][:2])}")
    if not keep:
        lines[-1] = "pairs: []"
    return "\n".join(lines) + "\n"
# An absolute http(s) identifier and nothing else. A bare word, a file path or a CURIE prefix
# resolves differently depending on who reads it, which is the one thing an identifier may not do.
IRI_RE = re.compile(r"^https?://[^\s<>\"{}|\\^`]+$")

# One-step twin suffixes: `x` and `x<suffix>` are the SAME concept's conventional variants.
# Single-step on purpose — `agegr1` and `agegrl` both band age, but neither is the other plus a
# twin suffix, and they are exactly the digit/letter drift this tool exists to catch.
TWIN_SUFFIXES = ("n", "dt", "yr", "fl", "dur", "type", "dd", "ddyr")
_BANDED = re.compile(r"(gr\d+n?|grln?)$")


def _twin(a: str, b: str) -> bool:
    """True when one name is the other plus one conventional suffix (order-free)."""
    a, b = a.replace("_", ""), b.replace("_", "")
    if len(a) > len(b):
        a, b = b, a
    if not b.startswith(a):
        return False
    rest = b[len(a):]
    return rest in TWIN_SUFFIXES or bool(_BANDED.fullmatch(rest))


def _strip_twin(name: str) -> str:
    """One twin-strip step, for ruling inheritance (cohortn -> cohort)."""
    n = name.replace("_", "")
    m = _BANDED.search(n)
    if m:
        return n[: m.start()]
    for s in sorted(TWIN_SUFFIXES, key=len, reverse=True):
        if n.endswith(s) and len(n) > len(s):
            return n[: -len(s)]
    return n


def _near(a: str, b: str) -> bool:
    """Two names close enough to be one concept spelled twice — and not convention twins.

    Shared leading TOKENS are dropped first so a family prefix cannot manufacture closeness
    (`prior_abiraterone` / `prior_arpi` compare `abiraterone` vs `arpi`: distinct) while a
    per-setting suffix cannot hide it (`lot1sd_mcrpc` / `lot1sd_mhspc` compare the settings:
    distinct). What remains flags on normalized equality (`agegrp` vs `age_grp`) or a common
    prefix of >= 4 characters covering >= 60% of the shorter remainder.
    """
    if a == b or _twin(a, b):
        return False
    ta, tb = a.split("_"), b.split("_")
    i = 0
    while i < min(len(ta), len(tb)) and ta[i] == tb[i]:
        i += 1
    ra, rb = "".join(ta[i:]), "".join(tb[i:])
    if not ra or not rb:                       # one is the other's token prefix outright
        ra, rb = a.replace("_", ""), b.replace("_", "")
    if ra == rb:
        return True
    if _twin(ra, rb):
        return False
    j = 0
    while j < min(len(ra), len(rb)) and ra[j] == rb[j]:
        j += 1
    return j >= 4 and j / min(len(ra), len(rb)) >= 0.6


def registry(root=ROOT) -> dict:
    """{name: {"packs": {pack: name_status}, "engine": bool, "variable_ids": [...]}} over every
    versioned pack's contract output axis plus the engine's own emitted names."""
    from engine.config import load_config                                     # noqa: PLC0415
    from engine import validate as ev                                              # noqa: PLC0415
    out: dict = {}
    # BOTH roots: the naming gate is an exercise surface, and a pack keeps owing its names when
    # it crosses the products/fixtures boundary (product_gates.all_packs states the principle).
    for p in sorted(glob.glob(os.path.join(root, "products", "*", "*", "*",
                                           "config", "data_product.yaml"))
                    + glob.glob(os.path.join(root, "fixtures", "*", "*", "*",
                                             "config", "data_product.yaml"))):
        from rwd_tools.spec_extract import repo_relative                         # noqa: PLC0415
        pack = repo_relative(os.path.dirname(os.path.dirname(p)), root)
        try:
            cfg = load_config(p)
            for n in ev.emitted_variables(cfg):
                rec = out.setdefault(str(n).lower(), {"packs": {}, "engine": False,
                                                      "variable_ids": [], "types": {}})
                rec["engine"] = True
        except Exception:                     # noqa: BLE001 — a broken pack owns its own lint
            pass
        cmd = os.path.join(os.path.dirname(os.path.dirname(p)), "handoff",
                           "FUNCTIONAL_CONTRACT.md")
        if not os.path.exists(cmd):
            continue
        for block in cl.records(cl.read(cmd)):
            body = cl._inline(block, "output")
            name = cl._kv(body, "physical_name")
            if not name or name.lower() in ("n/a", "tbd", "none"):
                continue
            rec = out.setdefault(name.lower(), {"packs": {}, "engine": False,
                                                "variable_ids": [], "types": {}})
            rec["packs"][pack] = cl._kv(body, "name_status") or "?"
            vid = cl._scalar(block, "variable_id")
            if vid and vid not in rec["variable_ids"]:
                rec["variable_ids"].append(vid)
            # the declared FORMAT rides with the name: `agegrp` character in one spec and
            # numeric in another is the same standardization failure one field over
            declared = (cl._kv(body, "type") or "").strip().lower()
            if declared and declared not in ("n/a", "tbd"):
                rec["types"].setdefault(declared, []).append(pack)
    return out


def ruling_ref(record):
    """Portable exact-content reference; historical entries need no rewritten IDs."""
    import hashlib
    return hashlib.sha256(json.dumps(record, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()


def ruling_family(a, b):
    return tuple(sorted(_strip_twin(str(name).strip().lower()) for name in (a, b)))


def review_rulings(doc):
    """Resolve explicit append-only supersession; contradictory current heads stay open."""
    from rwd_tools.product_gates import bad_date, not_a_person, unstated
    rows, problems, known, heads, invalid_families = [], [], {}, set(), set()
    if not isinstance(doc, dict) or not isinstance(doc.get("rulings", []), list):
        return {"current": [], "history": [], "conflicts": [], "problems": ["NAMING_RULINGS.yaml needs a rulings list."]}
    for i, r in enumerate(doc.get("rulings") or []):
        tag = f"NAMING_RULINGS.yaml rulings[{i}]"
        if not isinstance(r, dict) or not all(isinstance(r.get(k), str) and r[k].strip() for k in ("a", "b")):
            problems.append(f"{tag}: must be a mapping naming both `a` and `b`")
            continue
        family = ruling_family(r["a"], r["b"])
        error = None
        if r["a"].strip().lower() == r["b"].strip().lower():
            error = "the pair must contain two distinct physical names"
        elif r.get("ruling") not in RULING_KINDS:
            error = f"ruling {r.get('ruling')!r} is not one of {', '.join(RULING_KINDS)}"
        else:
            for field, check in (("ruled_by", not_a_person), ("ruling_date", bad_date)):
                value = r.get(field)
                why = "is not set" if unstated(value) else check(value)
                if why:
                    error = f"{field} {why} — a ruling is a named person's dated act, or it is not a ruling"
                    break
        if not error and r["ruling"] == "use_existing" and str(r.get("standard") or "").strip().lower() not in {r["a"].strip().lower(), r["b"].strip().lower()}:
            error = "use_existing must explicitly choose one of this pair's names as standard"
        refs = r.get("supersedes", [])
        if not error and (not isinstance(refs, list) or any(not isinstance(ref, str) for ref in refs) or len(refs) != len(set(refs))):
            error = "supersedes must list distinct exact prior ruling references"
        if not error and any(ref not in known or ref not in heads or known[ref]["family"] != family for ref in refs):
            error = "supersedes must name current earlier rulings of this same naming family; missing, stale or unrelated references are not a resolution"
        if error:
            problems.append(f"{tag}: {error}")
            invalid_families.add(family)
            continue
        try:
            ref = ruling_ref(r)
        except (ValueError, TypeError, RecursionError):
            problems.append(f"{tag}: the ruling contains unreadable or recursive metadata")
            invalid_families.add(family)
            continue
        rows.append({"ref": ref, "record": r, "family": family})
        known[ref] = rows[-1]
        heads.difference_update(refs)
        heads.add(ref)
    conflicts, blocked = [], set(invalid_families)
    families = sorted({row["family"] for row in rows})
    for family in families:
        current = [row for ref, row in known.items() if ref in heads and row["family"] == family]
        choices = {(row["record"]["ruling"], str(row["record"].get("standard") or "").strip().lower()
                    if row["record"]["ruling"] == "use_existing" else "") for row in current}
        if len(choices) > 1:
            blocked.add(family)
            conflicts.append({"family": list(family), "references": [row["ref"] for row in current],
                              "records": [row["record"] for row in current]})
            problems.append("NAMING_RULINGS.yaml: conflicting current rulings for " + " / ".join(family)
                + "; review one replacement that explicitly supersedes every conflicting current reference")
    return {"current": [row["record"] for ref, row in known.items() if ref in heads and row["family"] not in blocked],
            "history": [{**row, "state": "superseded" if row["ref"] not in heads else "unresolved" if row["family"] in blocked else "current"} for row in rows],
            "conflicts": conflicts, "problems": problems}


def ruling_review(path=RULINGS_PATH):
    from rwd_tools.product_gates import read_yaml
    if not os.path.exists(path):
        return review_rulings({"rulings": []})
    doc, err = read_yaml(path)
    if err:
        return {"current": [], "history": [], "conflicts": [], "problems": [f"NAMING_RULINGS.yaml: {err}"]}
    return review_rulings(doc or {})


def rulings(path=RULINGS_PATH):
    """Only unambiguous current rulings cover the docket; history remains in the file."""
    report = ruling_review(path)
    return report["current"], report["problems"]


def lifecycle(path=LIFECYCLE_PATH):
    """([entry], [problem]) — the recorded facts about single names, validated the same way a
    ruling is: a retirement or an identifier binding that is not a named person's dated act does
    not count, and says so."""
    from rwd_tools.product_gates import bad_date, not_a_person, read_yaml, unstated   # noqa: PLC0415
    if not os.path.exists(path):
        return [], []
    doc, err = read_yaml(path)
    if err:
        return [], [f"NAME_LIFECYCLE.yaml: {err}"]
    good, problems, seen, by_iri = [], [], set(), {}
    for i, e in enumerate(doc.get("names") or []):
        tag = f"NAME_LIFECYCLE.yaml names[{i}]"
        if not isinstance(e, dict) or unstated(e.get("name")):
            problems.append(f"{tag}: must be a mapping naming a `name`")
            continue
        name = str(e["name"]).strip().lower()
        if name in seen:
            problems.append(f"{tag}: `{name}` is recorded twice — one name, one lifecycle, or "
                            f"which entry governs depends on file order")
            continue
        seen.add(name)
        ok = True
        if str(e.get("status") or "").strip() == "deprecated":
            if unstated(e.get("replaced_by")):
                problems.append(f"{tag}: `{name}` is deprecated with no `replaced_by` — name the "
                                f"successor, or `none` when the concept itself is gone")
                ok = False
            for field, check in (("retired_by", not_a_person), ("retirement_date", bad_date)):
                v = e.get(field)
                why = "is not set" if unstated(v) else check(v)
                if why:
                    problems.append(f"{tag}: {field} {why} — retiring a name is a named person's "
                                    f"dated act, or it is not a retirement")
                    ok = False
                    break
        elif not unstated(e.get("status")):
            problems.append(f"{tag}: status {e.get('status')!r} is not recorded here — the only "
                            f"status this file carries is `deprecated`; an active name needs no "
                            f"entry")
            ok = False
        if not unstated(e.get("iri")):
            iri = str(e["iri"]).strip()
            if not IRI_RE.match(iri):
                problems.append(f"{tag}: iri {iri!r} is not an absolute http(s) identifier")
                ok = False
            elif iri in by_iri:
                problems.append(f"{tag}: `{name}` and `{by_iri[iri]}` both claim {iri} — two "
                                f"names, one identifier is the collision the mint-once rule "
                                f"forbids, in identifier space")
                ok = False
            else:
                by_iri[iri] = name
            for field, check in (("registered_by", not_a_person),
                                 ("registration_date", bad_date)):
                v = e.get(field)
                why = "is not set" if unstated(v) else check(v)
                if why:
                    problems.append(f"{tag}: {field} {why} — an identifier binding records WHO "
                                    f"bound this name to that IRI, and when")
                    ok = False
                    break
        if ok:
            good.append(e)
    return good, problems


def lifecycle_findings(reg, entries):
    """Findings where the recorded lifecycle disagrees with what the packs actually carry.

    MINT ONCE, NEVER REUSE is the property being defended. A retired name that comes back
    carrying a variable id it was never retired from is not a stale reference — it is the same
    spelling meaning something new, and every decision, precedent and citation written against
    the old meaning now reads as though it were about the new one. Nothing else in this
    repository can see that: the registry is built from what packs carry TODAY, so the old
    meaning left no trace to disagree with.
    """
    out = []
    for e in entries:
        if str(e.get("status") or "") != "deprecated":
            continue
        name = str(e["name"]).strip().lower()
        rec = reg.get(name)
        was = {str(v) for v in (e.get("was") or [])}
        successor = str(e.get("replaced_by") or "").strip().lower()
        if successor and successor != "none" and successor not in reg:
            out.append({"kind": "DANGLING_SUCCESSOR", "name": name,
                        "detail": f"`{name}` was retired in favour of `{successor}`, which no "
                                  f"pack defines — the migration points at nothing"})
        if not rec:
            continue                       # retired and gone: the ordinary, finished case
        live = {str(v) for v in (rec.get("variable_ids") or [])}
        fresh = sorted(live - was)
        if fresh:
            out.append({"kind": "NAME_REUSED", "name": name,
                        "detail": f"`{name}` was retired from {sorted(was) or '(unrecorded)'} and "
                                  f"now carries {fresh} — one spelling, two meanings; every "
                                  f"citation written against the old one silently reads as the "
                                  f"new. Mint a different name for the new concept"})
        elif live:
            until = str(e.get("migration_until") or "").strip()
            out.append({"kind": "MIGRATION_UNFINISHED", "name": name,
                        "detail": f"`{name}` is deprecated and still carried by "
                                  f"{sorted(live)} in {sorted(rec.get('packs') or {})}"
                                  + (f" (migration window to {until})" if until else
                                     " with no migration window stated")})
    return sorted(out, key=lambda f: (f["kind"], f["name"]))


def retire_draft(name, root=ROOT):
    """The draft entry for retiring `name`, machine half filled. PRINTS — a person fills the
    judgment fields and commits it, exactly as with every other ruling here."""
    reg = registry(root)
    rec = reg.get(str(name).strip().lower())
    if not rec:
        return (f"# `{name}` is not in the registry — nothing to retire. A name no pack carries\n"
                f"# and no entry records has never existed as far as this repository knows.")
    ids = ", ".join(sorted(str(v) for v in rec.get("variable_ids") or [])) or "# UNRECORDED"
    return "\n".join([
        f"# Append to governance/NAME_LIFECYCLE.yaml under `names:` — then fill the TODOs.",
        f"# `{name}` is carried by: {', '.join(sorted(rec.get('packs') or {})) or 'the engine'}",
        f"  - name: {str(name).strip().lower()}",
        f"    status: deprecated",
        f"    replaced_by: TODO            # the successor name, or `none`",
        f"    was: [{ids}]",
        f"    decision_id: TODO",
        f"    retired_by: TODO             # a person's name",
        f"    retirement_date: TODO        # YYYY-MM-DD",
    ])


def docket(root=ROOT) -> dict:
    """{"open": [pair-finding], "ruled": n, "ruling_problems": [...]} — the near-miss pairs no
    valid ruling covers. A ruling covers its pair AND the pair's one-step twin families."""
    reg = registry(root)
    good, ruling_problems = rulings()
    covered = set()
    for r in good:
        covered.add(frozenset((str(r["a"]).strip().lower(), str(r["b"]).strip().lower())))
        covered.add(frozenset(ruling_family(r["a"], r["b"])))
    names = sorted(reg)
    authored = [n for n in names if not reg[n]["engine"]]
    open_pairs, ruled = [], 0
    seen = set()
    for a in authored:
        for b in names:
            if a == b or not _near(a, b):
                continue
            key = frozenset((a, b))
            if key in seen:
                continue
            seen.add(key)
            if key in covered or frozenset((_strip_twin(a), _strip_twin(b))) in covered:
                ruled += 1
                continue
            open_pairs.append({
                "a": a, "b": b,
                "a_where": sorted(reg[a]["packs"]) + (["engine"] if reg[a]["engine"] else []),
                "b_where": sorted(reg[b]["packs"]) + (["engine"] if reg[b]["engine"] else []),
                "question": f"are '{a}' and '{b}' one concept spelled twice? If so, which "
                            f"spelling is the standard — record `use_existing` naming it; if "
                            f"they are genuinely different things, record `distinct_concepts`."})
    # SAME NAME, CONFLICTING DECLARED TYPES — the format half of the same failure: one spec
    # writes the concept as character labels, another as numeric codes, under one name. No
    # ruling file for these: the fix is a contract revision on whichever record is wrong, so
    # each stays open until the records agree.
    type_conflicts = []
    for n in sorted(reg):
        types = reg[n].get("types") or {}
        if len(types) > 1:
            spellings = "; ".join(f"{ty} in {', '.join(sorted(set(pk)))}"
                                  for ty, pk in sorted(types.items()))
            type_conflicts.append({
                "name": n, "types": {ty: sorted(set(pk)) for ty, pk in types.items()},
                "question": f"'{n}' is declared with conflicting formats ({spellings}) — which "
                            f"is the standard? Revise the divergent record(s); a code twin "
                            f"(`{n}n`) is the convention when both a label and a code are "
                            f"needed."})
    life, life_problems = lifecycle()
    return {"open": sorted(open_pairs, key=lambda f: (f["a"], f["b"])),
            "type_conflicts": type_conflicts,
            "ruled": ruled, "ruling_problems": ruling_problems + life_problems,
            "lifecycle": lifecycle_findings(reg, life),
            "identifiers": sum(1 for e in life if e.get("iri"))}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    ap.add_argument("--format", choices=("text", "json"), default="text")
    ap.add_argument("--retire", metavar="NAME",
                    help="print the draft NAME_LIFECYCLE.yaml entry for retiring a name; a "
                         "person fills the judgment fields and commits it")
    ap.add_argument("--check", action="store_true",
                    help="GATE: exit non-zero on a malformed ruling, a lifecycle finding, a type "
                         "conflict, or a near-miss pair not on the recorded floor")
    ap.add_argument("--write-baseline", action="store_true",
                    help="rewrite the floor, keeping only pairs still open. It can never grow")
    ap.add_argument("--seed-baseline", action="store_true",
                    help="create the floor from the pairs open today. Refused once it exists")
    a = ap.parse_args(argv)
    if a.write_baseline or a.seed_baseline:
        try:
            body = write_baseline(seed=a.seed_baseline)
        except RuntimeError as e:
            print(e)
            return 1
        with open(BASELINE_PATH, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(body)
        print(f"wrote {BASELINE_PATH} ({body.count('  - a:')} pair(s) on the floor)")
        return 0
    if a.check:
        errs = gate_errors()
        floor, floor_problems = baseline()
        errs = [f"NAMING_BASELINE.yaml: {p}" for p in floor_problems] + errs
        if errs:
            print(f"NAMING GATE — {len(errs)} problem(s):")
            for e in errs:
                print(f"  {e}")
            return 1
        _stale = baseline_findings(docket(), floor)[1]
        print(f"naming gate clean — {len(floor)} pair(s) on the recorded floor"
              + (f", {len(_stale)} now resolved (run --write-baseline)" if _stale else ""))
        return 0
    if a.retire:
        print(retire_draft(a.retire))
        return 0
    reg = registry()
    d = docket()
    if a.format == "json":
        print(json.dumps({"registry_size": len(reg), **d}, indent=1, sort_keys=True))
    else:
        engine_n = sum(1 for r in reg.values() if r["engine"])
        print(f"NAMING REGISTRY — {len(reg)} names ({engine_n} engine-owned), "
              f"{d['ruled']} pair(s) ruled, {len(d['open'])} OPEN, "
              f"{d['identifiers']} enterprise identifier(s) recorded")
        for p in d["ruling_problems"]:
            print(f"  RULING PROBLEM: {p}")
        for f in d["lifecycle"]:
            print(f"  {f['kind']}: {f['detail']}")
        for f in d["open"]:
            print(f"  {f['a']:<24} ~ {f['b']:<24} "
                  f"[{','.join(f['a_where'][:2])} vs {','.join(f['b_where'][:2])}]")
        for c in d["type_conflicts"]:
            print(f"  TYPE CONFLICT: {c['name']} — "
                  + "; ".join(f"{ty} ({', '.join(pk)})" for ty, pk in sorted(c["types"].items())))
        if d["open"]:
            print("\nEach pair is a QUESTION for DataExpert/Science — record the answer in "
                  "governance/NAMING_RULINGS.yaml (named person, real date). No tool and no "
                  "AI session rules on it.")
    return 1 if d["ruling_problems"] else 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(main())
