#!/usr/bin/env python3
"""Derive each definition's CANONICAL SIGNATURE from the approved config — no new authoring surface.

    python3 platform/tools/definition_signature.py <pack>
    python3 platform/tools/definition_signature.py <pack> --json OUT.json
    python3 platform/tools/definition_signature.py --all          # every pack, summary

THE PROBLEM THIS SOLVES. `semantic_export.py --template` mints one `rwdp:Definition` per
(tumour, master family), so mCRC's BRAF_V600E, KRAS_G12C, KRAS_MUT, NRAS_MUT and RAS_WILD_TYPE
are ONE identifier — and the slot that would tell them apart, `gene`, is emitted as
`slotUnstated`. Across the inventory, 251 of 509 variables have no distinct leaf definition: 90
collapse into a sibling and 161 have no master family at all. A definition identity that cannot
separate two different genes is not an identity.

WHY THE SIGNATURE IS DERIVED AND NOT AUTHORED. The obvious fix — have a clinician fill the slots
per definition — does not survive contact with this programme: there is no clinician to hand, and
every new tumour (HNSCC, then the blood cancers) arrives with a whole new biomarker set. A model
that needs a clinical author per definition gets slower with each tumour, which is backwards.

It is also unnecessary, because the values are ALREADY in the approved config:

    panel:                          gene            <- match: "HER2"
      - name: her2                  timing          <- window_days: [null, 14]
        match: "HER2"               variant_scope   <- the from_equals_ci value lists
        groups:                     missing_policy  <- the `when: fallthrough` group
          - {code: 1, label: Positive, from_equals_ci: [Positive]}
          - {code: 3, label: Unknown, when: fallthrough}

DataExpert approved that YAML. That WAS the act. This computes a digest over it and mints nothing new, so
a new tumour's panel produces new signatures the moment its config is approved — no extra step,
and the cost per tumour does not grow.

WHAT IS IN THE SIGNATURE, AND WHAT IS DELIBERATELY NOT. The signature carries the SEMANTIC subtree
— what counts as positive, the window, the bands, the codes, the missing policy. It excludes every
PHYSICAL binding: the source role, the column names, the table. That split is not tidiness. The
same definition can be obtained two ways on two deliveries — a vendor that reports KRAS and NRAS as
separate columns has pan-RAS wild-type as a DERIVATION, while a vendor that reports RAS status
directly has it as a READ — and both must resolve to the SAME definition or the two datasets can
never be compared. Where the value came from belongs to the implementation; what it means belongs
here.

AN UNFILLABLE SLOT PRODUCES NO SIGNATURE. Every master family declares its slots in
`INVENTORY.yaml`; this fills them from config and REFUSES to emit a digest when any one is
unresolved, naming which. A digest over a partial signature is worse than none: it looks like an
identity, it is stable, and two genuinely different definitions can share it. So `slotUnstated`
stops being a permanent placeholder and becomes a measurement — the count of slots this pack's
config does not yet pin.

Deterministic: sorted keys, no clock, canonical JSON. Same config in, same digest out, on any
machine. stdlib + pyyaml. No Spark, no engine import, no network.
"""
from __future__ import annotations

import argparse
import glob
import hashlib
import json
import os
import sys

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root
ROOT = str(workspace_root(__file__))

from rwd_tools.spec_extract import repo_relative # noqa: E402

INVENTORY = os.path.join(ROOT, "governance", "reference", "variable_inventory", "INVENTORY.yaml")

# Keys that name WHERE a value is stored rather than WHAT it means. Stripped from every signature,
# at any depth, because a definition that changed when a vendor renamed a column would make the
# same construct on two deliveries look like two constructs — the exact comparison this exists to
# enable. They are the implementation's identity, not the definition's.
PHYSICAL_KEYS = frozenset({
    "source", "name_column", "value_column", "date_column", "unit_column", "code_column",
    "drug_category_column", "line_number_column", "line_start_column", "line_end_column",
    "maintenance_column", "surgery_flag_column", "surgery_date_column", "init_date_column",
    "size_column", "event_flag", "death_anchor", "censor_anchor", "height_test", "weight_test",
    "table", "role", "stem", "column", "columns", "from", "passthrough",
})


# EVERY FAMILY INVENTED ITS OWN SPELLING FOR "TIME PERIOD LIMIT". Nineteen uses of `window_days`,
# plus `mcrpc_window`, `pfi_window_days`, `death_followup_window_days`, `exclusion_days`,
# `threshold_months`, `min_followup_days` and `visit_recency_days`. Two consequences, and both are
# the reason this table exists:
#
# A STUDY CANNOT SAY "this variable, limited to one year" GENERICALLY. It has to add another
# family-specific key, which is engine work every time — and "HCRU over the first year" and
# "dose response over N months" are ordinary study asks, not exotic ones.
#
# TWO FAMILIES EXPRESSING THE SAME WINDOW PRODUCE DIFFERENT SIGNATURES, so the digest cannot
# tell you they agree. Normalising is what makes `[365, 395]` in one family and a 12-month
# threshold in another comparable at all.
#
# A PAIR CARRIES ITS OWN DIRECTION; A SCALAR DOES NOT. `[-14, 0]` is plainly a lookback and
# `[365, 395]` plainly a landmark, but a bare `120` says nothing about which side of the index it
# falls on — that is family knowledge, so it is declared here rather than guessed. A period key
# this table does not know leaves the slot UNRESOLVED, which suppresses the digest.
PERIOD_KEYS = {
    "window": ("index_date", None, "days"),
    "window_days": ("index_date", None, "days"),
    "mcrpc_window": ("index_date", None, "days"),
    "pfi_window_days": ("line_end", "after", "days"),
    "death_followup_window_days": ("last_activity", "after", "days"),
    "min_followup_days": ("index_date", "after", "days"),
    "visit_recency_days": ("index_date", "after", "days"),
    "exclusion_days": ("index_date", "before", "days"),
    "threshold_months": ("line_end", "after", "months"),
}


def _role(lower, upper):
    """Which side of the anchor the window sits on. DERIVED from the bounds, never authored —
    an authored role can disagree with the numbers, and then one of them is a lie."""
    if lower is None:
        return "unbounded_before" if (upper is None or upper >= 0) else "before"
    if upper is None:
        return "unbounded_after" if lower >= 0 else "spans_index"
    if lower <= 0 and upper <= 0:
        return "baseline"
    if lower >= 0 and upper >= 0:
        return "followup"
    return "straddles_index"


def normalise_period(key, value, cfg):
    """One family's period expression as `(role, canonical)`, or None when this table cannot read it.

    Canonical form is always days relative to a named anchor, so `threshold_months: 6` and a
    365-day window become comparable. Months convert with the PACK'S OWN `days_per_month` —
    30.4375 in every pack today, but reading it rather than assuming it is what keeps "six months"
    from silently meaning two different spans if a pack ever states a different one.
    """
    declared_anchor = None
    if key == "window":
        from engine.record_windows import parse_window
        try:
            window = parse_window(value, allow_named_anchor=True)
            declared_anchor = window.anchor
            value = window.offsets()
        except ValueError:
            return None
    spec = PERIOD_KEYS.get(key)
    if spec is None:
        return None
    anchor, direction, unit = spec
    if declared_anchor and declared_anchor != "index_date":
        anchor = declared_anchor
    per_month = cfg.get("days_per_month") or 30.4375
    scale = (lambda v: None if v is None else round(float(v) * float(per_month), 4)) \
        if unit == "months" else (lambda v: None if v is None else float(v))

    if isinstance(value, (list, tuple)):
        if len(value) != 2:
            return None
        lower, upper = scale(value[0]), scale(value[1])
    elif isinstance(value, (int, float)):
        span = scale(value)
        if direction == "before":
            lower, upper = -span, 0.0
        elif direction == "after":
            lower, upper = 0.0, span
        else:
            return None # a bare number with no declared direction is unreadable
    else:
        return None
    return _role(lower, upper), {"anchor": anchor, "lower_days": lower, "upper_days": upper}


def periods(block, cfg):
    """({role: canonical period}, [unreadable key, ...]) for one config block.

    KEYED BY ROLE, because baseline and follow-up are different questions about the same variable
    and a study routinely sets them independently — a biomarker read before index, an outcome
    counted after it. Collapsing both into one `window` made them impossible to state separately.
    """
    out, unreadable = {}, []
    if "window" in (block or {}) and "window_days" in block:
        return {}, ["window and window_days compete"]
    for key in sorted(block or {}):
        if key not in PERIOD_KEYS:
            continue
        got = normalise_period(key, block[key], cfg)
        if got is None:
            unreadable.append(key)
            continue
        role, canonical = got
        # Two keys landing on one role in one block would silently overwrite; report instead.
        if role in out and out[role] != canonical:
            unreadable.append(f"{key} (a second, different {role} period)")
            continue
        out[role] = canonical
    return out, unreadable


def _load(path):
    # THE ONE READER, shared with every gate. PyYAML resolves an ISO-shaped scalar to a date and
    # raises a plain ValueError on an impossible one, so a bad date is not a YAMLError — getting
    # that right per caller is what this helper exists to stop.
    from rwd_tools import product_gates as pg # noqa: PLC0415
    doc, err = pg.read_yaml(path)
    if err:
        raise ValueError(f"{path}: {err}")
    return doc or {}


def pack_config(pack):
    """{block name: block} across the pack's variables/*.yaml, plus its root config.

    Merged into one namespace because a family's config lives wherever the engine reads it —
    `biomarkers` under clinical, `overall_survival` under outcomes — and a caller asking for a
    family should not have to know which file that is.
    """
    out = {}
    for path in sorted(glob.glob(os.path.join(pack, "variables", "*.yaml"))):
        for key, val in _load(path).items():
            if key not in ("pack_id", "name", "description", "owner", "version", "status"):
                out.setdefault(key, val)
    root = os.path.join(pack, "config", "data_product.yaml")
    if os.path.exists(root):
        for key, val in _load(root).items():
            out.setdefault("root:" + str(key), val)
    return out


def semantic(node):
    """`node` with every physical binding removed, recursively — the meaning-bearing part."""
    if isinstance(node, dict):
        return {k: semantic(v) for k, v in sorted(node.items()) if k not in PHYSICAL_KEYS}
    if isinstance(node, list):
        return [semantic(v) for v in node]
    return node


def digest(sig):
    """The canonical digest. Sorted keys and no whitespace, so it is a property of the CONTENT."""
    return hashlib.sha256(
        json.dumps(sig, sort_keys=True, separators=(",", ":"),
                   ensure_ascii=False).encode("utf-8")).hexdigest()


# (master family) -> how to find its definitions in a pack's config.
#
# `block` the config key the engine reads for this family.
# `fanout` when set, the block holds a LIST at this key and each entry is its OWN definition —
# which is the whole point for biomarkers: five genes in one panel are five definitions,
# not one. `label` names the entry's identifying key.
# `slots` slot name -> where its value comes from. `item:` reads the fan-out entry, `block:`
# reads the enclosing block. A slot with no rule here is UNRESOLVED and suppresses the
# signature rather than being quietly skipped.
FAMILIES = {
    "GENE_VARIANT_STATUS": {
        "block": "biomarkers", "fanout": "panel", "label": "name",
        "slots": {"gene": "item:match", "variant_scope": "item:groups",
                  "missing_policy": "item:groups", "timing": "period:",
                  "method": "block:value_matcher"},
    },
    "GENE_REARRANGEMENT": {
        "block": "biomarkers", "fanout": "panel", "label": "name",
        "slots": {"gene": "item:match", "partner_scope": "item:groups",
                  "missing_policy": "item:groups", "timing": "period:",
                  "method": "block:value_matcher"},
    },
    "PROTEIN_EXPRESSION": {
        "block": "biomarkers", "fanout": "panel", "label": "name",
        "slots": {"analyte": "item:match", "positivity_threshold": "item:groups",
                  "timing": "period:", "method": "block:value_matcher"},
    },
    "GENOMIC_SIGNATURE": {
        "block": "biomarkers", "fanout": "panel", "label": "name",
        "slots": {"signature": "item:match", "threshold": "item:groups",
                  "timing": "period:", "method": "block:value_matcher"},
    },
    "ECOG_PS": {
        "block": "baseline_ecog",
        "slots": {"window": "period:"},
    },
    "BMI_BSA": {
        "block": "vitals",
        "slots": {"bands": "block:bmi_bands", "methods": "block:bmi_method",
                  "pairing": "block:bsa_method"},
    },
    "CANCER_STAGE_GROUP": {
        "block": "staging",
        "slots": {"collapse": "block:groups", "system": "block:groups",
                  "timing": "block:groups"},
    },
    "AGEGR1": {
        "block": "age_bands",
        "slots": {"bands": "block:"},
    },
}


def _slot_value(rule, block, item, cfg=None):
    """The config value a slot rule points at, or `_MISSING` when the config does not carry it."""
    where, _, key = str(rule).partition(":")
    if where == "period":
        # THE NORMALISED PERIODS, KEYED BY ROLE — not the raw key. Two families spelling the same
        # window differently must produce the SAME signature, or the digest cannot tell you they
        # agree, which is most of the point of having one.
        got, unreadable = periods(block, cfg or {})
        if unreadable or not got:
            return _MISSING
        return got
    src = item if where == "item" else block
    if src is None:
        return _MISSING
    if not key:
        return semantic(src)
    if not isinstance(src, dict) or key not in src:
        return _MISSING
    return semantic(src[key])


_MISSING = object()


def _fold(name):
    """A name reduced to letters and digits, for matching a config label to an inventory name."""
    return "".join(c for c in str(name or "").lower() if c.isalnum())


def signatures(pack):
    """[definition, ...] for every family this pack configures, signed or explicitly unsigned.

    A FAN-OUT FAMILY IS DRIVEN BY THE CONFIG, NOT BY THE FAMILY LIST. The first cut iterated
    families and then the panel, which produced the cross-product: `er` appeared as a
    GENE_VARIANT_STATUS, a PROTEIN_EXPRESSION and a GENOMIC_SIGNATURE at once. ER is a protein
    expression and nothing else. So each panel entry is resolved to the ONE inventory variable it
    corresponds to, and that variable's master is the family — the inventory is what knows.

    THE MISMATCHES ARE THE OUTPUT, not an obstacle. Endometrial's panel declares five entries and
    its overlay declares seven biomarker variables, and they do not line up: the config splits
    `ER_PR` into `er` and `pr`, folds MMR and MSI into one `mmr_msi` entry across two different
    families, configures `pdl1` which the inventory never names, and never configures POLE, P53 or
    MOLSUBTYPE. Nothing in this repository compares those two lists today. Both directions are
    reported, because a panel entry with no variable is an unpublished column and a variable with
    no panel entry is a promise the build cannot keep.
    """
    from rwd_tools import variables_scaffold as vs # noqa: PLC0415
    slug = os.path.basename(os.path.dirname(os.path.abspath(pack)))
    cfg = pack_config(pack)
    inv = _load(INVENTORY)
    declared = {m["name"]: (m.get("parameter_slots") or {})
                for m in (inv.get("master") or []) if m.get("name")}
    # registry tumour_key first, then the shared mapping
    from rwd_tools import product_gates as _pg # noqa: PLC0415
    _tkey = _pg.tumour_key_for(ROOT, slug) or vs.SLUG_TO_OVERLAY.get(slug, slug)
    overlay = ((inv.get("tumours") or {}).get(_tkey) or {})
    var_master = {str(v["name"]): v.get("master")
                  for v in (overlay.get("variables") or []) if v.get("name")}
    by_fold = {_fold(n): n for n in var_master}
    try:
        instantiated = vs.instantiated_masters(slug)
    except SystemExit:
        instantiated = set()

    out, fanned = [], set()
    # --- fan-out families: one definition per configured panel entry -----------------------------
    for block_name in sorted({r["block"] for r in FAMILIES.values() if r.get("fanout")}):
        block = cfg.get(block_name)
        if block is None:
            continue
        key = next(r["fanout"] for r in FAMILIES.values() if r.get("fanout")
                   and r["block"] == block_name)
        label_key = next(r["label"] for r in FAMILIES.values() if r.get("fanout")
                         and r["block"] == block_name)
        for n, item in enumerate(block.get(key) or []):
            label = str(item.get(label_key) or n)
            hit = by_fold.get(_fold(label))
            master = var_master.get(hit) if hit else None
            rec = {"leaf": label, "config": f"{block_name}.{key}", "inventory_variable": hit}
            if not master:
                out.append(dict(rec, master=None, signed=False,
                                why="this panel entry matches no variable in the tumour's "
                                    "inventory overlay, so no family declares what it must pin"))
                continue
            fanned.add(master)
            rules = FAMILIES.get(master)
            if not rules:
                out.append(dict(rec, master=master, signed=False,
                                why=f"no extraction rule for {master}"))
                continue
            out.append(dict(rec, **_sign(master, declared.get(master) or {}, rules, block,
                                        item, cfg)))
    # --- single-block families -------------------------------------------------------------------
    for master in sorted(instantiated):
        rules = FAMILIES.get(master)
        if rules is None:
            out.append({"master": master, "leaf": None, "signed": False,
                        "why": "no extraction rule: this tool does not yet know which config "
                               "block carries this family, so it cannot fill any slot"})
            continue
        if rules.get("fanout"):
            if master not in fanned:
                out.append({"master": master, "leaf": None, "signed": False,
                            "why": f"the inventory instantiates this family but no "
                                   f"`{rules['block']}.{rules['fanout']}` entry resolves to it, "
                                   f"so the build publishes nothing for it"})
            continue
        block = cfg.get(rules["block"])
        if block is None:
            # THE PACK DOES NOT CONFIGURE IT. Not a defect and not a signature — mCRC declares
            # five gene variables and no `biomarkers` block, so there is nothing to sign.
            out.append({"master": master, "leaf": None, "signed": False,
                        "why": f"the pack declares no `{rules['block']}` block, so no config "
                               f"pins this family's meaning"})
            continue
        out.append(dict(_sign(master, declared.get(master) or {}, rules, block, None, cfg),
                        leaf=None, config=rules["block"]))
    return out


def _sign(master, slots, rules, block, item, cfg=None):
    """Fill every declared slot from config, or refuse and name what is missing."""
    sig, unresolved = {}, []
    for slot in sorted(slots):
        rule = rules["slots"].get(slot)
        val = _slot_value(rule, block, item, cfg) if rule else _MISSING
        if val is _MISSING:
            unresolved.append(slot)
        else:
            sig[slot] = val
    rec = {"master": master, "slots_declared": sorted(slots), "slots_unresolved": unresolved}
    if unresolved:
        # NO DIGEST OVER A PARTIAL SIGNATURE. It would look like an identity, be stable, and let
        # two genuinely different definitions share it — the failure this replaces.
        rec.update(signed=False,
                   why=f"{len(unresolved)} slot(s) the config does not pin: "
                       f"{', '.join(unresolved)}")
    else:
        rec.update(signed=True, signature=sig, digest=digest(sig))
    return rec


def report(pack):
    rows = signatures(pack)
    signed = [r for r in rows if r.get("signed")]
    return {
        # ONE helper, shared with every other gate tool. A hand-built relative id raises when the
        # path is on another drive, which on Windows is not hypothetical.
        "pack": repo_relative(pack, ROOT),
        "definitions_signed": len(signed),
        # FAMILIES, not rows. A panel entry that matches no inventory variable has `master: None`
        # - it names no family at all - and counting it here inflated "family/families unsigned"
        # with rows that are a different finding entirely. Reported separately below.
        "families_unsigned": len([r for r in rows if not r.get("signed") and r.get("master")]),
        "entries_without_a_family": len([r for r in rows
                                         if not r.get("signed") and not r.get("master")]),
        "distinct_digests": len({r["digest"] for r in signed}),
        "rows": rows,
    }


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("pack", nargs="?")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--json")
    a = ap.parse_args(argv)

    packs = ([p for p in sorted(glob.glob(os.path.join(ROOT, "products/*/*/*"))
                               + glob.glob(os.path.join(ROOT, "fixtures/*/*/*")))
              if os.path.isdir(os.path.join(p, "variables"))] if a.all
             else [os.path.abspath(a.pack)] if a.pack else [])
    if not packs:
        print("give a pack directory, or --all", file=sys.stderr)
        return 2

    reports = [report(p) for p in packs]
    if a.json:
        with open(a.json, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(reports, fh, indent=1, ensure_ascii=False, sort_keys=False)
        print(f"wrote {a.json}")

    for rep in reports:
        _orphan = rep.get("entries_without_a_family") or 0
        print(f"\n{rep['pack']} — {rep['definitions_signed']} definition(s) signed, "
              f"{rep['distinct_digests']} distinct, {rep['families_unsigned']} family/families "
              f"unsigned"
              + (f", {_orphan} panel entr" + ("y" if _orphan == 1 else "ies")
                 + " matching no family" if _orphan else ""))
        for r in rep["rows"]:
            if r.get("signed"):
                leaf = f" :: {r['leaf']}" if r.get("leaf") else ""
                print(f"  signed    {r['master']}{leaf}  {r['digest'][:12]}")
            else:
                leaf = f" :: {r['leaf']}" if r.get("leaf") else ""
                # `master` is None for a panel entry that matches no inventory variable, and
                # printing it unguarded put the Python literal `None` where a family name goes -
                # a reader cannot tell that from a family somebody called "None".
                print(f"  UNSIGNED  {r['master'] or '(no family)'}{leaf}  — {r['why']}")
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    raise SystemExit(main())
