"""Portable email confirmations for an explicitly enabled development portal.

These records are never consumed by production approval_identity verification.
They bind a demonstration review to product bytes, not to a machine or a key.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re

from rwd_tools import approval_identity as identity
from rwd_tools.person_rules import not_a_person

RECORD = "handoff/DEVELOPMENT_REVIEWS.json"
CHECKPOINTS = ("source", "science", "release")
MAX_BYTES = 32 * 1024 * 1024


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _read(path):
    if path.resolve() != path or not path.is_file():
        raise ValueError("A review input is unavailable. Refresh the review details after repairing it.")
    with path.open("rb") as handle:
        raw = handle.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise ValueError("A review input is too large to confirm through this form.")
    return raw


def product(root, pack):
    root = Path(root).resolve()
    pack = str(pack).replace("\\", "/")
    if not re.fullmatch(r"(?:products|fixtures)/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/\d{6}", pack):
        raise ValueError("Choose a product before confirming its review.")
    path = root / pack
    if path.resolve() != path or not path.is_dir():
        raise ValueError("The selected product is unavailable or redirects elsewhere.")
    return root, pack, path


def bucket(relative):
    if relative.endswith("/source_refs.yaml"):
        return "source"
    if relative.endswith("/RELEASE_APPROVAL.yaml"):
        return "release"
    return "science"


def snapshot(root, pack, checkpoint):
    root, pack, path = product(root, pack)
    if checkpoint not in CHECKPOINTS:
        raise ValueError("Choose a valid review checkpoint.")
    claims = []
    for relative, _governs, fields in identity.approval_files(str(root)):
        relative = relative.replace("\\", "/")
        if not relative.startswith(pack + "/") or bucket(relative) != checkpoint:
            continue
        _read(root / relative)
        actors, ok = identity.actors_in(str(root / relative))
        if not ok:
            raise ValueError("A review record could not be read. Correct its details before confirming.")
        primary = {name.casefold().replace("_", " ").strip() for name in actors.get("approved_by", set())}
        for independent_field in ("spec_qc_reviewed_by", "technically_reviewed_by", "validated_by"):
            independent = {name.casefold().replace("_", " ").strip() for name in actors.get(independent_field, set())}
            if primary & independent:
                raise ValueError("Choose different people for the primary and independent reviews. Edit the review details, then refresh this form.")
        for field, names in sorted(actors.items()):
            if not (identity._is_approving(field, fields) or field in {"spec_qc_reviewed_by", "technically_reviewed_by"}):
                continue
            claims.extend({"file": relative, "field": field, "who": name} for name in sorted(names))
    files = {claim["file"] for claim in claims}
    # Later scientific work must not invalidate a completed source access review.
    directories = ["prog_spec"] if checkpoint == "source" else ["prog_spec", "config", "variables", "codelists", "handoff", "spec_pipeline/out"]
    for directory in directories:
        base = path / directory
        if base.exists() and base.resolve() != base:
            raise ValueError("A review input directory redirects elsewhere.")
        if base.is_dir():
            for entry in base.rglob("*"):
                relative = entry.relative_to(root).as_posix()
                if relative == f"{pack}/{RECORD}" or entry.name.startswith("."):
                    continue
                if checkpoint == "science" and entry.name == "RELEASE_APPROVAL.yaml":
                    continue
                if entry.suffix.lower() in {".yaml", ".yml", ".json", ".md", ".csv", ".tsv", ".xlsx"} and entry.is_file():
                    files.add(relative)
    if (path / "source_refs.yaml").is_file():
        files.add(f"{pack}/source_refs.yaml")
    if len(files) > 2000:
        raise ValueError("This review has too many inputs for one confirmation.")
    hashes = {relative: _sha(_read(root / relative)) for relative in sorted(files)}
    data = {"pack": pack, "checkpoint": checkpoint, "claims": claims, "files": hashes}
    data["digest"] = _sha(json.dumps(data, sort_keys=True).encode())
    data["reviewers"] = sorted({claim["who"] for claim in claims if not not_a_person(claim["who"])})
    return data


def records(root, pack):
    _root, _pack, path = product(root, pack)
    record = path / RECORD
    if not record.exists():
        return {"version": 1, "development_only": True, "reviews": []}
    doc = json.loads(_read(record))
    if (not isinstance(doc, dict) or doc.get("version") != 1 or doc.get("development_only") is not True
            or not isinstance(doc.get("reviews"), list) or not all(isinstance(row, dict) for row in doc["reviews"])):
        raise ValueError("The development review record needs repair before another confirmation can be saved.")
    return doc


def confirmed_claims(root, pack):
    """Current demo claims only; missing, malformed and stale records grant nothing."""
    accepted = set()
    try:
        reviews = records(root, pack)["reviews"]
        snapshots = {}
        candidates = []
        for row in reviews:
            checkpoint = row.get("checkpoint")
            if checkpoint not in CHECKPOINTS or row.get("development_only") is not True:
                continue
            if checkpoint not in snapshots:
                snapshots[checkpoint] = snapshot(root, pack, checkpoint)
            current = snapshots[checkpoint]
            if (row.get("digest") != current["digest"] or row.get("reviewer") not in current["reviewers"]
                    or not isinstance(row.get("email"), str) or not re.fullmatch(r"[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+", row["email"])):
                continue
            candidates.append((row, current))
        owners = {}
        for row, _current in candidates:
            owners.setdefault((row["checkpoint"], row["email"].strip().casefold()), set()).add(row["reviewer"])
        for row, current in candidates:
            if len(owners[(row["checkpoint"], row["email"].strip().casefold())]) != 1:
                continue
            accepted.update((claim["file"], claim["field"], claim["who"]) for claim in current["claims"] if claim["who"] == row["reviewer"])
    except (ValueError, OSError, TypeError, RecursionError):
        return set()
    return accepted
