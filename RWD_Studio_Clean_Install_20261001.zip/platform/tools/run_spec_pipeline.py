#!/usr/bin/env python3
"""The shared deterministic spec pipeline. One script, parameterized per product.

    extract  -> the registered spec material becomes structured rows with Excel coordinates
    lint     -> deterministic defect scan, ranked HIGH / INFO
    coverage -> every spec item and its disposition (Gate 2 completeness evidence)
    scaffold -> one contract record per specification row
    values   -> candidate enumerations, as EVIDENCE to compare approved YAML against

Everything written to <product>/spec_pipeline/out/ is GENERATED. Regenerate it; never hand-edit it;
treat a stale out/ as evidence of nothing.

    python3 platform/tools/run_spec_pipeline.py <product-dir>
    python3 platform/tools/run_spec_pipeline.py <product-dir> --check    # fail if any artifact drifted
    python3 platform/tools/run_spec_pipeline.py <product-dir> --strict   # Gate 2: coverage must be complete

`run_spec_pipeline.sh` is a one-line wrapper around this. The orchestration lives HERE because the
shell version was the only bash in the workflow: every other tool is pure Python, so on a machine
without bash — a Windows checkout doing UAT — Gate 2 generation and the `--check` drift verification
CI depends on were simply unreachable. Two runners would be two definitions of the pipeline, which is
the failure this repo keeps paying for, so the shell script delegates rather than duplicating.

stdlib only.
"""
import argparse
import filecmp
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

TOOLS = os.path.dirname(os.path.abspath(__file__))
from rwd_services import workspace_root, run_workflow_command, WorkflowRefusal, workflow_main, finding
ROOT = str(workspace_root(__file__))

from rwd_tools.spec_extract import repo_relative                                       # noqa: E402

# Every artifact the pipeline writes. `--check` compares ALL of them: a change to the lint can leave
# SPEC_FINDINGS.txt and SCAFFOLDED_RECORDS.md stale while COVERAGE.md stays byte-identical, and
# partial drift protection reads as full protection.
EXTRACTED = "extracted.json"
LINT_JSON = "lint.json"
FINDINGS = "SPEC_FINDINGS.txt"
COVERAGE = "COVERAGE.md"
SCAFFOLD_JSON = "scaffold.json"
RECORDS = "SCAFFOLDED_RECORDS.md"
ENUMERATIONS = "ENUMERATION_CANDIDATES.yaml"
ARTIFACTS = (EXTRACTED, LINT_JSON, FINDINGS, COVERAGE, SCAFFOLD_JSON, RECORDS, ENUMERATIONS)

# The exit code for "this pack has generated NOTHING", under --require-generated. Its own code and
# not a bare 1, because the two states need different words from a caller: DRIFT means the artifacts
# disagree with the source and somebody must regenerate, while this means there is nothing to
# disagree — no claim has been made yet. `demo.py` renders this one as NO EVIDENCE rather than as a
# failing gate, which is what its neighbouring gates already say about such a pack.
NOTHING_GENERATED = 3

CONF_LINE = re.compile(r'^\s*([A-Z_]+)\s*=\s*(.*?)\s*$')


def read_conf(path):
    """pipeline.conf as {KEY: value}.

    PARSED, not sourced. The shell version ran `source "$CONF"`, so a pack's own config file was
    executed as bash — this reads `KEY=value` and nothing else, which is both portable and narrower.
    """
    conf = {"TUMOR": "", "SPEC_SOURCE_ID": "", "TABS": "", "DOMAINS": "", "IGNORE": "", "COLUMN_MAP": ""}
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            # COLUMN_MAP is JSON data, not shell syntax. Keep # characters and
            # embedded quotes in worksheet labels; remove only one outer quote.
            match = CONF_LINE.match(line)
            if match and match.group(1) == "COLUMN_MAP":
                value = match.group(2).strip()
                if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
                    value = value[1:-1]
                conf["COLUMN_MAP"] = value
                continue
            line = line.split("#", 1)[0] if not line.lstrip().startswith("#") else ""
            m = CONF_LINE.match(line)
            if m:
                conf[m.group(1)] = m.group(2).strip().strip('"').strip("'")
    return conf


def refuse_wrong_workbook(product, conf, lint_path):
    """Refuse from the disease validator's categories; its prose is diagnostic only."""
    with open(lint_path, encoding="utf-8") as fh:
        lint = json.load(fh)

    def refuse(code, message):
        raise WorkflowRefusal([finding(code, message, gate=2)])

    def unverified():
        diagnostics = []
        if isinstance(lint, dict):
            raw_findings = lint.get("findings")
            if isinstance(raw_findings, list):
                diagnostics.extend(str(item.get("detail", "")) for item in raw_findings
                                   if isinstance(item, dict) and item.get("kind") == "DECLARED_DISEASE")
            raw_applicability = lint.get("applicability")
            if isinstance(raw_applicability, dict) and isinstance(raw_applicability.get("reasons"), list):
                diagnostics.extend(str(item) for item in raw_applicability["reasons"])
        diagnostic_text = " Reported diagnostics: " + "; ".join(diagnostics[:3]) if diagnostics else ""
        refuse("workbook_identity_unverified",
               f"{product}: workbook identity evidence is unverified. The saved lint report lacks "
               "a recognized disease-check result. Regenerate the specification check and review "
               "the workbook's study-population statement and sheet mapping before continuing. "
               "An unknown or older diagnostic does not establish a different disease." + diagnostic_text)

    if not isinstance(lint, dict):
        unverified()
    findings = lint.get("findings")
    applicability = lint.get("applicability")
    if (not isinstance(findings, list) or not all(isinstance(item, dict) for item in findings)
            or not isinstance(applicability, dict)
            or applicability.get("declared_disease") not in ("applied", "not_applicable")):
        unverified()
    coded_notes = applicability.get("reason_codes", [])
    if (not isinstance(coded_notes, list)
            or not all(isinstance(item, dict) and set(item) == {"check", "code"}
                       and isinstance(item["check"], str) and isinstance(item["code"], str)
                       for item in coded_notes)):
        unverified()
    disease_notes = [item["code"] for item in coded_notes if item["check"] == "declared_disease"]
    wrong = [item for item in findings if item.get("kind") == "DECLARED_DISEASE"]
    if applicability["declared_disease"] == "not_applicable":
        if (len(disease_notes) != 1 or disease_notes[0] not in {"tumor_not_supplied", "tumor_family_unknown"}
                or wrong):
            unverified()
        refuse("workbook_tumor_unregistered",
                 f"{product}/spec_pipeline/pipeline.conf: TUMOR={conf.get('TUMOR', '')!r} resolves to no tumour "
                 f"family in governance/tumour_registry.yaml, so the checks that tell this workbook "
                 f"from another tumour's cannot run, and a pipeline that cannot tell must not "
                 f"generate. Register this condition under `families` or `aliases` with its own "
                 f"disease terms and condition class; calculation support is checked separately. "
                 f"Do not relabel the condition to pass workbook identity checks.")
    if disease_notes:
        unverified()
    if wrong:
        codes = [item.get("reason_code") for item in wrong]
        missing_codes = {"population_statement_missing", "population_identity_unresolved"}
        known_codes = missing_codes | {"population_disease_mismatch"}
        if not all(isinstance(code, str) and code in known_codes for code in codes):
            unverified()
        details = "; ".join(f"{item.get('item_id', '(unknown row)')}: {item.get('detail', '')}"
                            for item in wrong[:3])
        if all(code in missing_codes for code in codes):
            refuse("workbook_population_unidentified",
                     f"{product}: cannot identify the study population for {conf.get('TUMOR') or 'this product'} — "
                     + details
                     + ". This does not establish a different disease or require a fixed set of output variables. "
                       "Review the workbook sheet mapping: the sheet containing the study-population statement "
                       "must be mapped to study_population. Keep that statement as document context even when "
                       "optional variables are removed. If the statement was deleted from Excel, restore it in "
                       "the specification and upload the revised workbook. Then run Preview or Check again.")
        if not all(code == "population_disease_mismatch" for code in codes):
            unverified()
        refuse("workbook_disease_mismatch",
                 f"{product}: the registered workbook declares another disease's population — "
                 + details
                 + f". This is the wrong material for this pack, not a defect to disposition: "
                   f"register the right workbook in source_refs.yaml, or stand that tumour up as "
                   f"its own pack.")


def refuse_digest_mismatch(product, material_id, src):
    """The bytes the extractor reads are the bytes the registration records, or nothing is extracted.

    A next cut copied from the previous pack carried the old workbook's sha256 beside the new
    workbook's path, and the pipeline extracted from the new bytes and reported success — Gate 1
    said MISMATCH separately, but the artifacts the contract is drafted from were already derived
    from a document no registration described (twelfth verdict, Journey B). An UNSTATED digest is
    allowed (a pending rehearsal has none); a stated one must match.
    """
    from rwd_tools import source_manifest as sm                                              # noqa: PLC0415
    mat = next((m for m in (sm.materials(product) or []) if m.get("material_id") == material_id), None)
    recorded = str((mat or {}).get("sha256") or "").strip()
    if not recorded or sm.unstated(recorded):
        return
    actual = sm.sha256(src)
    if actual.lower() != recorded.lower():
        sys.exit(f"{product}/source_refs.yaml: material '{material_id}' records sha256 {recorded[:16]}… "
                 f"but {src} hashes to {actual[:16]}… — the file changed under the registration, and "
                 f"an extraction from bytes no registration describes is not the approved specification. "
                 f"Re-register the document (revision, sha256, approval) before extracting; "
                 f"`source_manifest.py --record-digest` fills only an UNSTATED digest, on purpose.")


def run(argv, out=None):
    """One tool call. Non-zero exits the pipeline: a step that failed must not leave the NEXT step
    reading a half-written file and reporting success over it.

    When the output is CAPTURED, the child's stdout encoding is pinned to UTF-8. The parent's
    `encoding="utf-8"` above governs nothing here — the child writes to the file descriptor itself,
    and picks its own encoding from the locale, which on Windows is the ANSI codepage. SPEC_FINDINGS.txt
    carries `—` and `•`; those became cp1252 0x97/0x95 on Windows against UTF-8 three-byte sequences
    on Linux, so `--check` reported drift on a file whose text was identical. lint.json escaped it only
    because json.dumps is ASCII-only by default — an accident, not a property to rely on.

    Scoped to the capture: forcing it on the console path too would change what an interactive terminal
    renders, and the byte-determinism this exists for is only owed by files.
    """
    env = dict(os.environ, PYTHONIOENCODING="utf-8", RWD_PORTAL_WORKSPACE_ROOT=ROOT)
    with (open(out, "w", encoding="utf-8", newline="\n") if out else _Null()) as fh:
        module = "rwd_tools." + os.path.splitext(os.path.basename(argv[0]))[0]
        command = [sys.executable, "-I", "-m", module, *argv[1:]]
        if module == "rwd_tools.spec_extract":
            r = run_workflow_command(command, issuer=module, runner=subprocess.run,
                                     stdout=(fh if out else None), env=env)
            if r.returncode or not r.workflow_outcome_verified:
                raise WorkflowRefusal(r.workflow_issues, r.returncode or 1)
        else:
            r = subprocess.run(command, stdout=(fh if out else None), env=env)
    if r.returncode:
        sys.exit(r.returncode)


class _Null:
    def __enter__(self):
        return None

    def __exit__(self, *a):
        return False


def normalize_newlines(paths):
    """Rewrite generated artifacts with LF, whatever platform produced them.

    `.gitattributes` stores and checks these out as LF on every platform, but Python's text mode on
    Windows writes `\\r\\n`, and the two tools whose stdout is redirected here translate in the CHILD
    process where the parent's `newline=` cannot reach. So a Windows run regenerated seven
    byte-different files and `--check` reported DRIFT on all seven against a checkout that was
    perfectly current — indistinguishable from someone having edited them.

    Done HERE, once, over the artifact list this module already owns, rather than at each of the four
    writers: three of them could set `newline="\\n"` and the redirected pair could not, so the invariant
    would hold in three places and quietly not in the fourth. It runs before the comparison, so
    generate and check normalize the same way — a normalizer that only touched the temp side would
    leave `--check` judging LF against CRLF and calling it drift forever.
    """
    for p in paths:
        with open(p, "rb") as fh:
            raw = fh.read()
        lf = raw.replace(b"\r\n", b"\n")
        if lf != raw:
            with open(p, "wb") as fh:
                fh.write(lf)


def pack_argument_error(product, conf_path):
    """The message for an argument that is not a pack, or None when it is one.

    The pipeline takes the PACK DIRECTORY and resolves the specification through its
    source_refs.yaml. Handing it the workbook instead is the natural mistake — it is the file the
    pipeline reads, and every other tool on a developer's path takes the file it reads — and the bare
    `missing <arg>/spec_pipeline/pipeline.conf` that resulted names a path nobody typed, inside a
    .xlsx, which reads as the tool being broken rather than as the argument being wrong.

    Never accept the spec path as an alternative form. Naming it on the command line would make "what
    was approved" and "what was extracted" two facts nothing reconciles: a pack could approve workbook
    A and, on the day someone typed a different path, extract B. The indirection IS the control.
    """
    if os.path.isfile(conf_path):
        return None
    what = ("does not exist" if not os.path.exists(product) else
            "is a file" if os.path.isfile(product) else
            "has no spec_pipeline/pipeline.conf")
    # Walk up for an ancestor that IS a pack — for the workbook case that is the pack containing it,
    # which is exactly what should have been passed. Keyed on the same file the runner requires, so
    # this does not become a second definition of what a pack is.
    d = os.path.dirname(product) if os.path.isfile(product) else product
    while True:
        if os.path.isfile(os.path.join(d, "spec_pipeline", "pipeline.conf")):
            # `repo_relative` never raises; `os.path.relpath` does, across Windows drives. This is
            # the "did you mean" on a path the user already got wrong — turning a helpful hint into
            # a ValueError is the worst possible moment to crash.
            hint = f"\nDid you mean:  {repo_relative(d, os.getcwd())}"
            break
        parent = os.path.dirname(d)
        if parent == d:
            hint = ""
            break
        d = parent
    return (f"{product} {what} — the pipeline takes the PACK directory, not the specification.\n"
            f"The spec is named by the pack's source_refs.yaml (via SPEC_SOURCE_ID in "
            f"pipeline.conf), never on the command line: that is what keeps what was approved and "
            f"what was extracted a single fact.{hint}")


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("product", help="the PACK directory (the one holding source_refs.yaml), "
                                    "not the specification file")
    ap.add_argument("--check", action="store_true",
                    help="regenerate to a temp dir and fail if any committed artifact differs")
    ap.add_argument("--strict", action="store_true",
                    help="Gate 2: coverage must resolve every specification item")
    ap.add_argument("--allow-unclassified", action="store_true",
                    help="pass through to spec_extract: run even though a workbook sheet is in "
                         "neither half of the shared map nor this pack's IGNORE")
    ap.add_argument("--require-generated", action="store_true",
                    help="with --check: a pack that has NEVER generated fails instead of passing. "
                         "The default is right for a repo-wide sweep, where a pack that has "
                         "generated nothing has claimed nothing; use this wherever the extraction "
                         "is the thing being gated or demonstrated, so that only 'all artifacts "
                         "are current' passes")
    a = ap.parse_args(argv)

    product = os.path.abspath(a.product)
    conf_path = os.path.join(product, "spec_pipeline", "pipeline.conf")
    bad_arg = pack_argument_error(product, conf_path)
    if bad_arg:
        sys.exit(bad_arg)
    conf = read_conf(conf_path)

    # SPEC_SOURCE_ID names a material_id from source_refs.yaml — NOT a path. Restating the path here
    # made "what was approved" and "what was extracted" two independently maintained facts, so a pack
    # could approve workbook A and extract B.
    if not conf["SPEC_SOURCE_ID"]:
        sys.exit(f"{conf_path}: SPEC_SOURCE_ID is required — name a material_id from source_refs.yaml")
    # The template ships placeholders. Saying WHICH one is unfilled beats a check that silently does
    # nothing because TUMOR is still literally "<slug>".
    for key in ("TUMOR", "SPEC_SOURCE_ID"):
        if "<" in conf[key]:
            sys.exit(f"{conf_path}: {key} is still the template placeholder {conf[key]}")

    committed = os.path.join(product, "spec_pipeline", "out")

    # NEVER GENERATED IS NOT DRIFT — and this has to be decided BEFORE the source is resolved,
    # because a pack that has never extracted is exactly the pack whose workbook may not be
    # registered yet. A new tumour gets its pipeline.conf when the pack is created and its
    # source_refs.yaml when a person classifies the workbook, and between those two moments
    # `--check` was reporting "source_refs.yaml does not exist" and exiting 1 — turning CI red for a
    # pack that has generated nothing, claimed nothing, and cannot be stale.
    #
    # Same rule `variables_scaffold --check` already applies, for the same reason it gives: a check
    # that is permanently red on a legitimate state is a check people stop running. An out/ that
    # EXISTS is a claim of currency and is verified in full below, source resolution included; a
    # PARTIAL out/ (some artifacts, not all) is drift and still fails.
    if a.check and all(not os.path.exists(os.path.join(committed, f)) for f in ARTIFACTS):
        print(f"never generated — {committed} holds none of the {len(ARTIFACTS)} artifacts; nothing "
              f"to be stale. Register the source, then generate with: "
              f'python platform/tools/run_spec_pipeline.py "{a.product}"')
        # ...UNLESS THE CALLER SAID ABSENCE IS NOT ACCEPTABLE. Exiting 0 here is right for a
        # repo-wide sweep, where a pack that has generated nothing has claimed nothing. It is wrong
        # wherever the extraction is the thing being demonstrated or gated: an external review put
        # it plainly — only "OK — all 7 generated artifacts are current" is a passing control, and
        # anything saying "never generated" proves nothing. Before this flag the two printed
        # different words and returned the same status, so a demo script checking the exit code
        # could not tell them apart.
        return NOTHING_GENERATED if a.require_generated else 0

    # EVERY RUN GENERATES INTO A TEMP DIR (2026-09-07, UNSAFE-05). The generate path used to
    # write straight into the committed out/: extracted.json and lint.json had landed there
    # before `refuse_wrong_workbook` read the lint and exited, so a refused run left out/ holding
    # two artifacts from the wrong workbook beside five from the last good run, while the message
    # said nothing had been generated. Now the whole set is produced here and copied into out/
    # only when every stage succeeded; a refusal at any stage leaves out/ byte-identical.
    out = tempfile.mkdtemp()
    # `run()` calls sys.exit on a failed stage, so on a pack that cannot extract, the rmtree at the
    # end of the comparison was never reached and the temp dir survived. That was survivable while
    # --check was something a human typed occasionally; `spec_slice` now runs it before every slice,
    # so a broken new pack leaked one directory per attempt. atexit rather than try/finally because
    # the exits come from inside `run`, several frames down.
    import atexit
    atexit.register(shutil.rmtree, out, ignore_errors=True)
    if a.check:
        # Said up front because the paths printed below are a temp dir, and reading `--check` as "run
        # it" then watching seven artifacts appear under C:\...\Temp\ looks like the tool put the
        # output in the wrong place. It has to write elsewhere: a verifier that regenerated OVER the
        # files it compares against can never report drift.
        print(f"--check: VERIFYING {committed} against a fresh run in a temp dir. "
              f"Nothing under {product} is written. Drop --check to generate.", flush=True)

    # The extractor reads the REGISTERED material, resolved through source_refs.yaml. It fails loudly
    # rather than falling back to a path nobody approved.
    from rwd_tools import source_manifest
    rel = source_manifest.resolve(os.path.abspath(os.path.join(ROOT, product)), conf["SPEC_SOURCE_ID"])
    if "<" in rel:
        sys.exit(f"{product}/source_refs.yaml: material '{conf['SPEC_SOURCE_ID']}' still has the "
                 f"template path '{rel}' — register the real workbook (or stand-in) first.")
    src = rel if os.path.isabs(rel) else os.path.join(ROOT, rel)
    if not os.path.exists(src):
        sys.exit(f"{product}/source_refs.yaml: material '{conf['SPEC_SOURCE_ID']}' points at "
                 f"'{rel}', which does not exist.")
    refuse_digest_mismatch(product, conf["SPEC_SOURCE_ID"], src)

    tabs = ["--tabs", conf["TABS"]] if conf["TABS"] else []
    j = lambda name: os.path.join(out, name)                                  # noqa: E731
    strict = ["--strict"] if a.strict else []

    allow = ["--allow-unclassified"] if a.allow_unclassified else []
    # `--strict` reaches the EXTRACTOR too, not only the scaffold. It has always meant "governed
    # mode: this must be complete", and coverage completeness was only half of that — an extraction
    # can be perfectly covered and still rest on ten variables read from cell position and a mapped
    # sheet that produced nothing. Both halves now refuse under the same flag, because a caller
    # asking for governed mode is asking about the whole pipeline, not one stage of it.
    run([os.path.join(TOOLS, "spec_extract.py"), src, "--out", j(EXTRACTED),
         "--domains", conf["DOMAINS"], "--ignore", conf["IGNORE"], "--column-map", conf["COLUMN_MAP"], *allow, *strict])
    run([os.path.join(TOOLS, "spec_lint.py"), j(EXTRACTED), "--tumor", conf["TUMOR"],
         *tabs, "--format", "json"], out=j(LINT_JSON))
    refuse_wrong_workbook(product, conf, j(LINT_JSON))
    run([os.path.join(TOOLS, "spec_lint.py"), j(EXTRACTED), "--tumor", conf["TUMOR"], *tabs],
        out=j(FINDINGS))
    run([os.path.join(TOOLS, "contract_scaffold.py"), j(EXTRACTED), "--product", product,
         "--lint", j(LINT_JSON), "--coverage", j(COVERAGE), "--out", j(SCAFFOLD_JSON),
         "--records", j(RECORDS), *strict, *tabs])
    # Generated for every pack, even when empty — run outside the pipeline these could go stale while
    # every drift check stayed green.
    run([os.path.join(TOOLS, "spec_codelists.py"), j(EXTRACTED), "--product", product,
         "--out", j(ENUMERATIONS)], out=os.devnull)

    # Before the comparison, and on the generate path too, so an artifact is the same bytes wherever
    # it was produced. Drift must mean the CONTENT changed, never that the author ran Windows.
    normalize_newlines([j(f) for f in ARTIFACTS])

    if not a.check:
        # The run succeeded: the whole set moves into out/, each file through a sibling temp
        # file and os.replace, so an interrupted copy leaves each artifact either old or new and
        # never half-written. Nothing under the pack was touched before this line.
        os.makedirs(committed, exist_ok=True)
        for f in ARTIFACTS:
            staging = os.path.join(committed, f + ".tmp")
            shutil.copyfile(j(f), staging)
            os.replace(staging, os.path.join(committed, f))
        shutil.rmtree(out, ignore_errors=True)
        return 0

    missing = [f for f in ARTIFACTS if not os.path.exists(os.path.join(committed, f))]
    stale = [f for f in ARTIFACTS if f not in missing
             and not filecmp.cmp(j(f), os.path.join(committed, f), shallow=False)]
    shutil.rmtree(out, ignore_errors=True)
    # Never generated and generated-then-drifted both fail, but they are different mistakes and
    # "regenerate" is only advice for the second. On a pack whose out/ does not exist yet, every
    # artifact is listed as stale, which reads as seven things having changed.
    if len(missing) == len(ARTIFACTS):
        # Unreachable from the CLI — the never-generated case returns 0 far above, before the source
        # is resolved. Kept because `run()` can leave a partial temp dir on a stage failure, and a
        # comparison that found nothing must not fall through to "OK, all current".
        sys.stderr.write(f"NOT GENERATED: {committed} holds none of the {len(ARTIFACTS)} artifacts. "
                         f"Run without --check first.\n")
        return 1
    if missing or stale:
        from rwd_services import record_workflow_issues
        message = ((f"MISSING: {' '.join(missing)}. " if missing else "")
            + (f"DRIFT: stale generated artifact(s) — {' '.join(stale)}. " if stale else "")
            + "Regenerate with run_spec_pipeline.\n")
        record_workflow_issues([finding("generated_evidence_stale", message.rstrip(), gate=2)])
        sys.stderr.write(message)
        return 1
    print(f"OK — all {len(ARTIFACTS)} generated artifacts are current")
    return 0


if __name__ == "__main__":
    from rwd_tools.console import use_utf8
    use_utf8()
    sys.exit(workflow_main(main, sys.argv[1:], issuer="rwd_tools.run_spec_pipeline"))
